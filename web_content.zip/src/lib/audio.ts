import { clamp } from "./util";

export const SAMPLE_RATE = 48000;
export const BANDS = 128;
export const WAVE_POINTS = 512;

export interface AudioFrame {
  bands: Float32Array; // 0..1 log-spaced spectrum
  wave: Float32Array; // -1..1 time-domain samples
  bass: number;
  mid: number;
  treble: number;
  level: number;
}

export function newFrame(): AudioFrame {
  return {
    bands: new Float32Array(BANDS),
    wave: new Float32Array(WAVE_POINTS),
    bass: 0,
    mid: 0,
    treble: 0,
    level: 0,
  };
}

/** Real radix-2 FFT based analyser that works on a decoded AudioBuffer at any time position
 *  (used identically by the live preview and the offline export renderer). */
export class Analyzer {
  readonly N = 2048;
  readonly buffer: AudioBuffer;
  private mono: Float32Array;
  private win: Float32Array;
  private cosT: Float32Array;
  private sinT: Float32Array;
  private rev: Uint32Array;
  private re: Float32Array;
  private im: Float32Array;
  private mag: Float32Array;
  private lo: Float32Array;
  private hi: Float32Array;

  constructor(buffer: AudioBuffer) {
    this.buffer = buffer;
    const n = buffer.length;
    const mono = new Float32Array(n);
    const ch = buffer.numberOfChannels;
    for (let c = 0; c < ch; c++) {
      const d = buffer.getChannelData(c);
      for (let i = 0; i < n; i++) mono[i] += d[i] / ch;
    }
    this.mono = mono;
    const N = this.N;
    this.win = new Float32Array(N);
    for (let i = 0; i < N; i++) this.win[i] = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (N - 1));
    this.cosT = new Float32Array(N / 2);
    this.sinT = new Float32Array(N / 2);
    for (let i = 0; i < N / 2; i++) {
      this.cosT[i] = Math.cos((2 * Math.PI * i) / N);
      this.sinT[i] = -Math.sin((2 * Math.PI * i) / N);
    }
    this.rev = new Uint32Array(N);
    const bits = Math.log2(N);
    for (let i = 0; i < N; i++) {
      let r = 0;
      for (let b = 0; b < bits; b++) if (i & (1 << b)) r |= 1 << (bits - 1 - b);
      this.rev[i] = r;
    }
    this.re = new Float32Array(N);
    this.im = new Float32Array(N);
    this.mag = new Float32Array(N / 2 + 1);
    const fmin = 40;
    const fmax = Math.min(16000, buffer.sampleRate / 2 - 100);
    const bw = buffer.sampleRate / N;
    this.lo = new Float32Array(BANDS);
    this.hi = new Float32Array(BANDS);
    for (let i = 0; i < BANDS; i++) {
      this.lo[i] = (fmin * Math.pow(fmax / fmin, i / BANDS)) / bw;
      this.hi[i] = (fmin * Math.pow(fmax / fmin, (i + 1) / BANDS)) / bw;
    }
  }

  get duration() {
    return this.buffer.duration;
  }

  private fft() {
    const { re, im, N, cosT, sinT } = this;
    for (let size = 2; size <= N; size <<= 1) {
      const half = size >> 1;
      const step = N / size;
      for (let i = 0; i < N; i += size) {
        for (let j = 0, k = 0; j < half; j++, k += step) {
          const a = i + j;
          const b = a + half;
          const tr = re[b] * cosT[k] - im[b] * sinT[k];
          const ti = re[b] * sinT[k] + im[b] * cosT[k];
          re[b] = re[a] - tr;
          im[b] = im[a] - ti;
          re[a] += tr;
          im[a] += ti;
        }
      }
    }
  }

  /** Analyse the audio around file-time `t` (seconds). */
  frame(t: number, out: AudioFrame): AudioFrame {
    const N = this.N;
    const sr = this.buffer.sampleRate;
    const start = Math.floor(t * sr) - N / 2;
    const { re, im, mono, win, rev } = this;
    let sum = 0;
    for (let i = 0; i < N; i++) {
      const idx = start + i;
      const s = idx >= 0 && idx < mono.length ? mono[idx] : 0;
      sum += s * s;
      re[rev[i]] = s * win[i];
      im[rev[i]] = 0;
    }
    this.fft();
    const mag = this.mag;
    for (let k = 0; k <= N / 2; k++) {
      const a = Math.sqrt(re[k % N] * re[k % N] + im[k % N] * im[k % N]) / (N / 4);
      const db = 20 * Math.log10(a + 1e-9);
      mag[k] = clamp((db + 85) / 75, 0, 1);
    }
    const bands = out.bands;
    for (let i = 0; i < BANDS; i++) {
      const lo = this.lo[i],
        hi = this.hi[i];
      let v: number;
      if (hi - lo < 1) {
        const c = (lo + hi) / 2;
        const f = Math.floor(c);
        const fr = c - f;
        v = mag[f] * (1 - fr) + mag[Math.min(f + 1, N / 2)] * fr;
      } else {
        v = 0;
        for (let k = Math.ceil(lo); k <= Math.floor(hi); k++) if (mag[k] > v) v = mag[k];
      }
      v = clamp(v + (i / BANDS) * 0.2, 0, 1);
      bands[i] = Math.pow(v, 1.6);
    }
    const wave = out.wave;
    for (let i = 0; i < WAVE_POINTS; i++) {
      const idx = start + N / 4 + i * 2;
      const a = idx >= 0 && idx < mono.length ? mono[idx] : 0;
      const b = idx + 1 >= 0 && idx + 1 < mono.length ? mono[idx + 1] : 0;
      wave[i] = (a + b) / 2;
    }
    const avg = (a: number, b: number) => {
      let s = 0;
      for (let i = a; i < b; i++) s += bands[i];
      return s / (b - a);
    };
    out.bass = avg(0, 26);
    out.mid = avg(26, 80);
    out.treble = avg(80, BANDS);
    out.level = clamp(Math.sqrt(sum / N) * 3, 0, 1);
    return out;
  }
}

let decodeCtx: OfflineAudioContext | null = null;
export async function decodeAudio(data: ArrayBuffer): Promise<AudioBuffer> {
  // a fresh offline context per decode keeps memory simple and always resamples to 48 kHz
  decodeCtx = new OfflineAudioContext(2, 1, SAMPLE_RATE);
  return decodeCtx.decodeAudioData(data);
}

export function computePeaks(buf: AudioBuffer, n = 1400): Float32Array {
  const out = new Float32Array(n);
  const ch = buf.numberOfChannels;
  const len = buf.length;
  const per = len / n;
  for (let c = 0; c < ch; c++) {
    const d = buf.getChannelData(c);
    for (let i = 0; i < n; i++) {
      const a = Math.floor(i * per);
      const b = Math.min(len, Math.floor((i + 1) * per));
      const stride = Math.max(1, Math.floor((b - a) / 64));
      let m = 0;
      for (let k = a; k < b; k += stride) {
        const v = Math.abs(d[k]);
        if (v > m) m = v;
      }
      if (m > out[i]) out[i] = m;
    }
  }
  return out;
}

/** Synthesises a 32 s electronic demo loop locally (no network, no bundled copyrighted audio). */
let demoPromise: Promise<AudioBuffer> | null = null;
export function getDemoTrack(): Promise<AudioBuffer> {
  if (demoPromise) return demoPromise;
  demoPromise = (async () => {
    const bpm = 124;
    const beat = 60 / bpm;
    const bars = 16;
    const dur = bars * 4 * beat;
    const ctx = new OfflineAudioContext(2, Math.ceil(dur * SAMPLE_RATE), SAMPLE_RATE);
    const master = ctx.createGain();
    master.gain.value = 0.8;
    const comp = ctx.createDynamicsCompressor();
    master.connect(comp);
    comp.connect(ctx.destination);

    const noiseBuf = ctx.createBuffer(1, SAMPLE_RATE, SAMPLE_RATE);
    const nd = noiseBuf.getChannelData(0);
    let seed = 12345;
    for (let i = 0; i < nd.length; i++) {
      seed = (seed * 1664525 + 1013904223) >>> 0;
      nd[i] = (seed / 4294967296) * 2 - 1;
    }
    const noise = (t: number, len: number, type: BiquadFilterType, freq: number, vol: number, q = 1) => {
      const s = ctx.createBufferSource();
      s.buffer = noiseBuf;
      const f = ctx.createBiquadFilter();
      f.type = type;
      f.frequency.value = freq;
      f.Q.value = q;
      const g = ctx.createGain();
      g.gain.setValueAtTime(vol, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + len);
      s.connect(f).connect(g).connect(master);
      s.start(t, 0, len + 0.05);
    };
    const tone = (t: number, len: number, type: OscillatorType, freq: number, vol: number, cutoff: number, detune = 0) => {
      const o = ctx.createOscillator();
      o.type = type;
      o.frequency.value = freq;
      o.detune.value = detune;
      const f = ctx.createBiquadFilter();
      f.type = "lowpass";
      f.frequency.setValueAtTime(cutoff, t);
      f.frequency.exponentialRampToValueAtTime(Math.max(120, cutoff * 0.25), t + len);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(vol, t + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0008, t + len);
      o.connect(f).connect(g).connect(master);
      o.start(t);
      o.stop(t + len + 0.05);
    };
    const midi = (n: number) => 440 * Math.pow(2, (n - 69) / 12);
    const prog = [57, 53, 48, 55]; // Am F C G roots
    const chords = [
      [57, 60, 64],
      [53, 57, 60],
      [48, 52, 55],
      [55, 59, 62],
    ];
    const arp = [0, 7, 12, 7, 15, 12, 7, 3];
    for (let bar = 0; bar < bars; bar++) {
      const t0 = bar * 4 * beat;
      const ci = bar % 4;
      const intro = bar < 2;
      // kick (4 on the floor)
      for (let b = 0; b < 4; b++) {
        const t = t0 + b * beat;
        const o = ctx.createOscillator();
        o.type = "sine";
        o.frequency.setValueAtTime(160, t);
        o.frequency.exponentialRampToValueAtTime(42, t + 0.14);
        const g = ctx.createGain();
        g.gain.setValueAtTime(1, t);
        g.gain.exponentialRampToValueAtTime(0.001, t + 0.42);
        o.connect(g).connect(master);
        o.start(t);
        o.stop(t + 0.45);
      }
      if (intro) continue;
      // clap / snare
      for (const b of [1, 3]) noise(t0 + b * beat, 0.18, "bandpass", 1800, 0.55, 0.8);
      // hats
      for (let e = 0; e < 8; e++) noise(t0 + e * beat * 0.5 + beat * 0.25, 0.05, "highpass", 8000, e % 2 ? 0.28 : 0.18);
      // sub bass off-beat
      for (let e = 0; e < 4; e++) tone(t0 + e * beat + beat * 0.5, beat * 0.45, "sawtooth", midi(prog[ci] - 24), 0.45, 600);
      // arpeggio
      if (bar >= 4) {
        for (let s = 0; s < 16; s++) {
          const n = chords[ci][0] + 12 + arp[s % 8];
          tone(t0 + s * beat * 0.25, beat * 0.3, "square", midi(n), 0.08, 3200);
        }
      }
      // pad
      if (bar >= 2) {
        for (const n of chords[ci]) {
          tone(t0, beat * 4, "sawtooth", midi(n), 0.05, 1800, -8);
          tone(t0, beat * 4, "sawtooth", midi(n), 0.05, 1800, 8);
        }
      }
    }
    return ctx.startRendering();
  })();
  return demoPromise;
}

/** Playback transport. Positions are in file seconds. */
export class AudioPlayer {
  ctx: AudioContext;
  gain: GainNode;
  buffer: AudioBuffer | null = null;
  private src: AudioBufferSourceNode | null = null;
  private startCtx = 0;
  private startPos = 0;
  playing = false;
  private end = 0;
  onEnded: (() => void) | null = null;

  constructor() {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    this.ctx = new AC({ sampleRate: SAMPLE_RATE });
    this.gain = this.ctx.createGain();
    this.gain.connect(this.ctx.destination);
  }

  setBuffer(b: AudioBuffer | null) {
    this.stop();
    this.buffer = b;
  }

  setVolume(v: number) {
    this.gain.gain.value = v;
  }

  get position() {
    if (!this.playing) return this.startPos;
    const lat = (this.ctx as AudioContext & { outputLatency?: number }).outputLatency || this.ctx.baseLatency || 0;
    return this.startPos + Math.max(0, this.ctx.currentTime - this.startCtx - lat);
  }

  async play(from: number, end: number) {
    if (!this.buffer) return;
    this.stopSource();
    if (this.ctx.state !== "running") await this.ctx.resume();
    const src = this.ctx.createBufferSource();
    src.buffer = this.buffer;
    src.connect(this.gain);
    const dur = Math.max(0.05, end - from);
    src.start(0, from, dur);
    src.onended = () => {
      if (this.src === src && this.playing) {
        this.playing = false;
        this.startPos = end;
        this.onEnded?.();
      }
    };
    this.src = src;
    this.startCtx = this.ctx.currentTime;
    this.startPos = from;
    this.end = end;
    this.playing = true;
  }

  pause() {
    if (!this.playing) return;
    const p = this.position;
    this.stopSource();
    this.playing = false;
    this.startPos = Math.min(p, this.end);
  }

  seek(pos: number) {
    this.startPos = pos;
    if (this.playing) this.play(pos, this.end);
  }

  private stopSource() {
    if (this.src) {
      const s = this.src;
      this.src = null;
      try {
        s.onended = null;
        s.stop();
      } catch {
        /* already stopped */
      }
    }
  }

  stop() {
    this.stopSource();
    this.playing = false;
    this.startPos = 0;
  }

  dispose() {
    this.stop();
    this.ctx.close().catch(() => {});
  }
}
