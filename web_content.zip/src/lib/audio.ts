import { FFmpeg } from "@ffmpeg/ffmpeg";
import { FFMPEG_CORE } from "./catalog";
import { fetchWithCache } from "./modelManager";

let ff: FFmpeg | null = null;
let ffBusy: Promise<FFmpeg> | null = null;

/** Load the cached (or freshly downloaded) FFmpeg WASM core exactly once. */
export async function ensureFFmpeg(
  onProg?: (loaded: number, total: number) => void
): Promise<FFmpeg> {
  if (ff) return ff;
  if (ffBusy) return ffBusy;
  const noProg = () => {};
  ffBusy = (async () => {
    const instance = new FFmpeg();
    const js = await fetchWithCache(FFMPEG_CORE.base + FFMPEG_CORE.js, onProg ?? noProg);
    const jsText = await js.text();
    const jsUrl = URL.createObjectURL(new Blob([jsText], { type: "text/javascript" }));
    const wasm = await fetchWithCache(FFMPEG_CORE.base + FFMPEG_CORE.wasm, onProg ?? noProg);
    const wasmUrl = URL.createObjectURL(new Blob([wasm], { type: "application/wasm" }));
    instance.on("log", () => {
      /* keep console quiet */
    });
    await instance.load({ coreURL: jsUrl, coreWASMURL: wasmUrl } as any);
    ff = instance;
    return instance;
  })();
  ffBusy.catch(() => {
    ffBusy = null;
  });
  return ffBusy;
}

function resample(buf: AudioBuffer): Promise<Float32Array> {
  if (buf.sampleRate === 16000 && buf.numberOfChannels === 1)
    return Promise.resolve(buf.getChannelData(0) as Float32Array);
  const target = Math.max(1600, Math.ceil(buf.duration * 16000));
  const off = new OfflineAudioContext(1, target, 16000);
  const src = off.createBufferSource();
  src.buffer = buf;
  src.connect(off.destination);
  src.start(0);
  return off.startRendering().then((r) => r.getChannelData(0));
}

export async function decodeAndResample16k(ab: ArrayBuffer): Promise<Float32Array> {
  const Ctx: typeof AudioContext =
    window.AudioContext || (window as any).webkitAudioContext;
  const ctx = new Ctx();
  try {
    const buf = await ctx.decodeAudioData(ab);
    return await resample(buf);
  } finally {
    ctx.close().catch(() => {});
  }
}

function s16toF32(bytes: Uint8Array): Float32Array {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const n = Math.floor(bytes.byteLength / 2);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) out[i] = dv.getInt16(i * 2, true) / 32768;
  return out;
}

function extOf(name: string): string {
  const i = name.lastIndexOf(".");
  return i >= 0 ? name.slice(i).toLowerCase().slice(0, 8) : ".bin";
}

export interface ExtractResult {
  pcm: Float32Array;
  via: "native" | "ffmpeg";
  seconds: number;
}

/**
 * Extract mono 16 kHz PCM from a local media file.
 * 1) Tries the browser's native decoder (fast; covers MP3/WAV/OGG/FLAC and
 *    AAC-in-MP4 in Chrome/Safari).
 * 2) Falls back to FFmpeg WASM for containers/codecs the browser cannot
 *    decode (MKV, MOV, Opus-in-MP4 on some browsers, …).
 */
export async function extractAudio16k(
  file: Blob,
  onPhase: (phase: string, progress: number, detail?: string) => void,
  signal?: AbortSignal
): Promise<ExtractResult> {
  onPhase("native", 0.3, "Trying browser decoder…");
  try {
    const ab = await file.arrayBuffer();
    const pcm = await decodeAndResample16k(ab);
    onPhase("native", 1, "Browser decoder OK");
    return { pcm, via: "native", seconds: pcm.length / 16000 };
  } catch (e) {
    if (signal?.aborted) throw e;
    onPhase("ffmpeg", 0.05, "Browser decoder failed — using FFmpeg…");
  }
  try {
    const instance = await ensureFFmpeg(() =>
      onPhase("ffmpeg", 0.05, "Downloading FFmpeg engine…")
    );
    if (signal?.aborted) throw new Error("aborted");
    const inName = "in" + extOf((file as File).name ?? "media.bin");
    await instance.writeFile(
      inName,
      new Uint8Array(await file.arrayBuffer())
    );
    const progHandler = (p: any) => {
      const pr = Math.max(0, Math.min(1, p?.progress ?? 0));
      onPhase("ffmpeg", 0.1 + pr * 0.9, "Extracting audio track…");
    };
    instance.on("progress", progHandler);
    try {
      const code = await instance.exec([
        "-i", inName,
        "-vn",
        "-ac", "1",
        "-ar", "16000",
        "-f", "s16le",
        "out.pcm",
      ]);
      if (code !== 0) throw new Error(`FFmpeg exited with code ${code}`);
      const raw = (await instance.readFile("out.pcm")) as unknown as
        | Uint8Array
        | ArrayBuffer;
      const bytes =
        raw instanceof Uint8Array
          ? raw
          : new Uint8Array(raw as ArrayBuffer);
      const pcm = s16toF32(bytes);
      onPhase("ffmpeg", 1, "Audio extracted with FFmpeg");
      return { pcm, via: "ffmpeg", seconds: pcm.length / 16000 };
    } finally {
      instance.off("progress", progHandler);
      try {
        await instance.deleteFile(inName);
      } catch {
        /* ignore */
      }
      try {
        await instance.deleteFile("out.pcm");
      } catch {
        /* ignore */
      }
    }
  } catch (e: any) {
    throw new Error(
      "Could not extract audio from this file (" +
        String(e?.message || e) +
        "). If the format/codec is not supported, convert the file to MP4 (H.264 + AAC) or MP3 and retry. Make sure the FFmpeg media engine is installed in Models."
    );
  }
}
