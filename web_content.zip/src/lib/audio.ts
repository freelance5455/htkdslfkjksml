let ctx: AudioContext | null = null;
let muted = false;
let master: GainNode | null = null;

function ac(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    ctx = new Ctor();
    master = ctx.createGain();
    master.gain.value = 0.22;
    master.connect(ctx.destination);
  }
  return ctx;
}

export function setMuted(next: boolean) {
  muted = next;
  if (master && ctx) {
    master.gain.setTargetAtTime(next ? 0 : 0.22, ctx.currentTime, 0.05);
  }
}

export async function unlockAudio() {
  const c = ac();
  if (!c) return;
  if (c.state === "suspended") await c.resume();
}

export function tone(
  freq: number,
  dur: number,
  type: OscillatorType = "sine",
  gain = 0.12,
  slide?: number,
) {
  if (muted) return;
  const c = ac();
  if (!c || !master) return;
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, c.currentTime);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, slide), c.currentTime + dur);
  g.gain.setValueAtTime(gain, c.currentTime);
  g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + dur);
  o.connect(g);
  g.connect(master);
  o.start();
  o.stop(c.currentTime + dur + 0.02);
}

export function playTakeoff() {
  tone(180, 0.35, "triangle", 0.08, 420);
}

export function playTick() {
  tone(880, 0.04, "square", 0.03);
}

export function playCash() {
  tone(520, 0.12, "sine", 0.1, 740);
  setTimeout(() => tone(780, 0.16, "sine", 0.08), 70);
}

export function playCrash() {
  if (muted) return;
  const c = ac();
  if (!c || !master) return;
  const bufferSize = 2 * c.sampleRate * 0.28;
  const buffer = c.createBuffer(1, bufferSize, c.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < bufferSize; i++) {
    data[i] = (Math.random() * 2 - 1) * (1 - i / bufferSize);
  }
  const src = c.createBufferSource();
  src.buffer = buffer;
  const f = c.createBiquadFilter();
  f.type = "lowpass";
  f.frequency.setValueAtTime(900, c.currentTime);
  f.frequency.exponentialRampToValueAtTime(80, c.currentTime + 0.28);
  const g = c.createGain();
  g.gain.setValueAtTime(0.28, c.currentTime);
  g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + 0.3);
  src.connect(f);
  f.connect(g);
  g.connect(master);
  src.start();
  tone(90, 0.4, "sine", 0.14, 40);
}
