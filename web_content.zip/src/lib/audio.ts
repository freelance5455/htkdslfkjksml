import { ayahAudioUrl, reciterById } from "@/data/reciters";
import type { Surah } from "@/lib/quran";

const CACHE = "tawbah-audio-v1";
let cancelFlag = false;

export function cancelAudioDownload() {
  cancelFlag = true;
}

export async function cachedAudioUrl(url: string): Promise<string | null> {
  if (typeof caches === "undefined") return null;
  const cache = await caches.open(CACHE);
  const hit = await cache.match(url);
  if (!hit) return null;
  const blob = await hit.blob();
  return URL.createObjectURL(blob);
}

async function putUrl(url: string): Promise<void> {
  const cache = await caches.open(CACHE);
  if (await cache.match(url)) return;
  const res = await fetch(url);
  if (!res.ok) throw new Error("تعذر تنزيل ملف التلاوة");
  await cache.put(url, res);
}

export async function downloadSurah(
  reciterId: string,
  surah: Surah,
  onProgress: (done: number, total: number) => void,
): Promise<"done" | "cancelled"> {
  cancelFlag = false;
  const folder = reciterById(reciterId).folder;
  let i = 0;
  for (const ayah of surah.ayahs) {
    if (cancelFlag) return "cancelled";
    await putUrl(ayahAudioUrl(folder, surah.n, ayah.a));
    i += 1;
    onProgress(i, surah.ayahs.length);
  }
  return "done";
}

export async function downloadSurahList(
  reciterId: string,
  surahs: Surah[],
  onProgress: (label: string) => void,
): Promise<"done" | "cancelled"> {
  for (const surah of surahs) {
    onProgress(`سورة ${surah.ar}`);
    const result = await downloadSurah(reciterId, surah, (done, total) => {
      onProgress(`سورة ${surah.ar} · ${done}/${total}`);
    });
    if (result === "cancelled") return "cancelled";
  }
  return "done";
}

export async function clearAudioCache(): Promise<void> {
  if (typeof caches === "undefined") return;
  await caches.delete(CACHE);
}

export async function storageEstimate(): Promise<number | null> {
  if (!navigator.storage?.estimate) return null;
  const e = await navigator.storage.estimate();
  return e.usage ?? null;
}
