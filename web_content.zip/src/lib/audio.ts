import type { Surah } from "@/content/types";

export type Reciter = {
  id: string;
  name: string;
  everyayah: string;
  islamic: string;
};

export const RECITERS: Reciter[] = [
  { id: "alafasy", name: "مشاري راشد العفاسي", everyayah: "Alafasy_128kbps", islamic: "ar.alafasy" },
  { id: "husary", name: "محمود خليل الحصري", everyayah: "Husary_128kbps", islamic: "ar.husary" },
  { id: "sudais", name: "عبد الرحمن السديس", everyayah: "Abdurrahmaan_As-Sudais_192kbps", islamic: "ar.abdurrahmaansudais" },
  { id: "minshawi", name: "محمد صديق المنشاوي", everyayah: "Minshawy_Murattal_128kbps", islamic: "ar.minshawi" },
];

export function getReciter(id: string): Reciter {
  return RECITERS.find((r) => r.id === id) ?? RECITERS[0];
}

export function ayahAudioUrls(reciter: Reciter, surahId: number, ayah: number, global: number): string[] {
  const s = String(surahId).padStart(3, "0");
  const a = String(ayah).padStart(3, "0");
  return [
    `https://everyayah.com/data/${reciter.everyayah}/${s}${a}.mp3`,
    `https://cdn.islamic.network/quran/audio/128/${reciter.islamic}/${global}.mp3`,
  ];
}

export function surahAudioUrls(reciter: Reciter, surahId: number): string[] {
  const s = String(surahId).padStart(3, "0");
  return [
    `https://download.quranicaudio.com/quran/${reciter.id === "alafasy" ? "mishaari_raashid_al_3afaasee" : reciter.id === "husary" ? "mahmood_khaleel_al-husaree_kwt" : reciter.id === "sudais" ? "abdurrahmaan_as-sudays" : "muhammad_siddeeq_al-minshaawee"}/${s}.mp3`,
    `https://cdn.islamic.network/quran/audio-surah/128/${reciter.islamic}/${surahId}.mp3`,
  ];
}

const CACHE = "rafeeq-audio-v1";

export async function cachedUrl(urls: string[]): Promise<string> {
  if (typeof caches === "undefined") return urls[0];
  try {
    const cache = await caches.open(CACHE);
    for (const url of urls) {
      const hit = await cache.match(url);
      if (hit) return url;
    }
  } catch {
    /* private mode */
  }
  return urls[0];
}

export async function downloadUrls(urls: string[]): Promise<boolean> {
  if (typeof caches === "undefined") return false;
  const cache = await caches.open(CACHE);
  for (const url of urls) {
    try {
      const res = await fetch(url, { mode: "cors" });
      if (res.ok) {
        await cache.put(url, res);
        return true;
      }
    } catch {
      continue;
    }
  }
  return false;
}

export async function downloadSurahAyahs(
  reciter: Reciter,
  surah: Surah,
  onProgress?: (done: number, total: number) => void,
): Promise<number> {
  let ok = 0;
  for (let i = 0; i < surah.ayahs.length; i++) {
    const a = surah.ayahs[i];
    const saved = await downloadUrls(ayahAudioUrls(reciter, surah.id, a.n, a.g));
    if (saved) ok += 1;
    onProgress?.(i + 1, surah.ayahs.length);
  }
  return ok;
}

export type PlayerStatus = {
  playing: boolean;
  surahId: number | null;
  ayah: number | null;
  title: string;
  repeatLeft: number;
  mode: "idle" | "ayah" | "surah" | "speech";
};

type Listener = (s: PlayerStatus) => void;

class AudioEngine {
  private audio = typeof Audio !== "undefined" ? new Audio() : null;
  private listeners = new Set<Listener>();
  private queue: { surahId: number; ayah: number; global: number; title: string }[] = [];
  private index = 0;
  private repeats = 1;
  private remaining = 1;
  private reciter = RECITERS[0];
  status: PlayerStatus = { playing: false, surahId: null, ayah: null, title: "", repeatLeft: 0, mode: "idle" };
  private onAyah: ((surahId: number, ayah: number) => void) | null = null;

  constructor() {
    if (!this.audio) return;
    this.audio.preload = "auto";
    this.audio.addEventListener("ended", () => this.next());
    this.audio.addEventListener("error", () => this.fallbackOrNext());
  }

  subscribe(fn: Listener) {
    this.listeners.add(fn);
    fn(this.status);
    return () => {
      this.listeners.delete(fn);
    };
  }

  setAyahHandler(fn: ((surahId: number, ayah: number) => void) | null) {
    this.onAyah = fn;
  }

  private emit() {
    for (const fn of this.listeners) fn(this.status);
    this.syncMedia();
  }

  private syncMedia() {
    if (typeof navigator === "undefined" || !navigator.mediaSession) return;
    navigator.mediaSession.metadata = new MediaMetadata({
      title: this.status.title || "رفيق",
      artist: this.reciter.name,
      album: "القرآن الكريم",
    });
    navigator.mediaSession.playbackState = this.status.playing ? "playing" : "paused";
  }

  setReciter(id: string) {
    this.reciter = getReciter(id);
  }

  pause() {
    this.audio?.pause();
    this.status = { ...this.status, playing: false };
    this.emit();
  }

  toggle() {
    if (!this.audio) return;
    if (this.status.playing) this.pause();
    else {
      void this.audio.play().then(() => {
        this.status = { ...this.status, playing: true };
        this.emit();
      });
    }
  }

  stop() {
    if (this.audio) {
      this.audio.pause();
      this.audio.removeAttribute("src");
    }
    this.queue = [];
    this.status = { playing: false, surahId: null, ayah: null, title: "", repeatLeft: 0, mode: "idle" };
    this.emit();
  }

  async playAyah(opts: {
    surahId: number;
    ayah: number;
    global: number;
    title: string;
    reciterId: string;
    repeat?: number;
    continueSurah?: Surah | null;
  }) {
    this.setReciter(opts.reciterId);
    this.repeats = Math.max(1, opts.repeat ?? 1);
    this.remaining = this.repeats;
    if (opts.continueSurah) {
      this.queue = opts.continueSurah.ayahs
        .filter((a) => a.n >= opts.ayah)
        .map((a) => ({
          surahId: opts.surahId,
          ayah: a.n,
          global: a.g,
          title: `${opts.title} — ${a.n}`,
        }));
    } else {
      this.queue = [{ surahId: opts.surahId, ayah: opts.ayah, global: opts.global, title: opts.title }];
    }
    this.index = 0;
    this.status.mode = opts.continueSurah ? "surah" : "ayah";
    await this.loadCurrent();
  }

  private async loadCurrent() {
    const item = this.queue[this.index];
    if (!item || !this.audio) return;
    const urls = ayahAudioUrls(this.reciter, item.surahId, item.ayah, item.global);
    this.audio.dataset.fallbacks = JSON.stringify(urls.slice(1));
    this.audio.src = await cachedUrl(urls);
    this.status = {
      playing: true,
      surahId: item.surahId,
      ayah: item.ayah,
      title: item.title,
      repeatLeft: this.remaining,
      mode: this.status.mode,
    };
    this.onAyah?.(item.surahId, item.ayah);
    this.emit();
    try {
      await this.audio.play();
    } catch {
      this.status = { ...this.status, playing: false };
      this.emit();
    }
  }

  private async fallbackOrNext() {
    if (!this.audio) return;
    const raw = this.audio.dataset.fallbacks;
    if (raw) {
      const list = JSON.parse(raw) as string[];
      if (list.length) {
        this.audio.dataset.fallbacks = JSON.stringify(list.slice(1));
        this.audio.src = list[0];
        try {
          await this.audio.play();
          return;
        } catch {
          /* continue */
        }
      }
    }
    this.next();
  }

  private next() {
    this.remaining -= 1;
    if (this.remaining > 0) {
      void this.loadCurrent();
      return;
    }
    this.remaining = this.repeats;
    this.index += 1;
    if (this.index >= this.queue.length) {
      this.stop();
      return;
    }
    void this.loadCurrent();
  }

  speak(text: string, title: string) {
    if (typeof window === "undefined" || !window.speechSynthesis) return false;
    this.pause();
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "ar-SA";
    u.rate = 0.9;
    u.onend = () => {
      this.status = { playing: false, surahId: null, ayah: null, title: "", repeatLeft: 0, mode: "idle" };
      this.emit();
    };
    this.status = { playing: true, surahId: null, ayah: null, title, repeatLeft: 1, mode: "speech" };
    this.emit();
    window.speechSynthesis.speak(u);
    return true;
  }

  stopSpeech() {
    if (typeof window !== "undefined") window.speechSynthesis?.cancel();
  }
}

export const audioEngine = new AudioEngine();
