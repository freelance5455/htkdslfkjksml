import { Language } from '../types';

export const TRANSLATIONS: Record<Language, Record<string, string>> = {
  EN: {
    platformName: 'LankaPaperHub',
    tagline: 'The Ultimate Sri Lankan Past Papers & Educational Repository',
    subtagline: 'Empowering Grade 6 - A/L Students and Teachers across all 9 Provinces with verified papers, marking schemes, community learning & AI assistance.',
    
    // Navigation
    navHome: 'Papers',
    navUpload: 'Upload Paper',
    navAiAssistant: 'AI Study Helper',
    navCommunity: 'Community',
    navLeaderboard: 'Leaderboard',
    navAdmin: 'Admin Panel',
    navProfile: 'My Profile',
    navMessages: 'Messages',
    
    // Actions & Buttons
    searchPlaceholder: 'Search by paper title, subject, school, or year...',
    aiSearchPlaceholder: '✨ AI Search: Try "2023 Royal College Combined Maths 3rd term test with marking scheme"...',
    uploadBtn: 'Upload Paper',
    downloadBtn: 'Download Paper',
    previewBtn: 'PDF Preview',
    bookmarkBtn: 'Bookmark',
    shareBtn: 'Share',
    reportBtn: 'Report File',
    filterTitle: 'Filter Papers',
    resetFilters: 'Reset Filters',
    applyFilters: 'Apply Filters',
    loginBtn: 'Sign In',
    registerBtn: 'Register',
    logoutBtn: 'Sign Out',
    
    // Filter labels
    grade: 'Grade Level',
    subject: 'Subject',
    medium: 'Medium',
    year: 'Year',
    province: 'Province',
    school: 'School',
    paperType: 'Paper Type',
    fileFormat: 'File Format',
    sortBy: 'Sort By',
    
    // Sort options
    newest: 'Newest First',
    popular: 'Most Viewed',
    trending: 'Trending Now',
    downloads: 'Most Downloaded',
    
    // Paper details
    hasAnswers: 'Answers Included',
    hasMarkingScheme: 'Marking Scheme Included',
    viewsCount: 'Views',
    downloadCount: 'Downloads',
    uploadedBy: 'Uploaded by',
    uploadedDate: 'Uploaded Date',
    fileSize: 'File Size',
    pagesCount: 'Pages',
    
    // Role Badges
    roleGuest: 'Guest',
    roleStudent: 'Student',
    roleTeacher: 'Teacher',
    roleModerator: 'Moderator',
    roleAdmin: 'Administrator',
    roleSuperAdmin: 'Super Administrator',
    
    // Community
    createPost: 'Create Community Post',
    postPlaceholder: 'Share exam tips, request papers, or start a study discussion with fellow Sri Lankan students...',
    addPoll: 'Add Poll',
    vote: 'Vote',
    comments: 'Comments',
    like: 'Like',
    pinnedAnnouncement: 'Pinned Admin Announcement',
    
    // AI Assistant
    aiAssistantTitle: 'LankaPaperHub AI Exam Assistant',
    aiAssistantSubtitle: 'Ask Gemini AI for paper summaries, topic breakdowns, exam tips, or practice quiz questions based on Sri Lankan syllabus.',
    aiAskBtn: 'Generate AI Breakdown',
    
    // Admin
    adminTitle: 'Enterprise Administration Dashboard',
    pendingUploads: 'Pending Upload Approvals',
    approve: 'Approve Paper',
    reject: 'Reject',
    banUser: 'Ban User',
    userManagement: 'Manage Platform Users',
    systemLogs: 'System Audit Logs',
    
    // Gamification
    gamificationPoints: 'Points',
    level: 'Level',
    topContributors: 'Top Contributors Leaderboard',
    badges: 'Badges & Honors',
    
    // Status
    statusApproved: 'Approved',
    statusPending: 'Pending Review',
    statusRejected: 'Rejected'
  },
  SI: {
    platformName: 'ලංකා පේපර් හබ්',
    tagline: 'ශ්‍රී ලංකාවේ ප්‍රමුඛතම පසුගිය විභාග ප්‍රශ්න පත්‍ර එකතුව',
    subtagline: '6 ශ්‍රේණියේ සිට උසස් පෙළ දක්වා සියලුම පළාත් 9 හි සිසුන් සහ ගුරුවරුන් සඳහා වන ප්‍රශ්න පත්‍ර, ලකුණු දීමේ පටිපාටි සහ AI සහායක පද්ධතිය.',
    
    // Navigation
    navHome: 'ප්‍රශ්න පත්‍ර',
    navUpload: 'ප්‍රශ්න පත්‍ර එක්කරන්න',
    navAiAssistant: 'AI අධ්‍යයන සහායක',
    navCommunity: 'සමාජ සමූහය',
    navLeaderboard: 'ප්‍රමුඛ පුවරුව',
    navAdmin: 'පරිපාලන පුවරුව',
    navProfile: 'මගේ ගිණුම',
    navMessages: 'පණිවිඩ',
    
    // Actions & Buttons
    searchPlaceholder: 'මාතෘකාව, විෂය, පාසල හෝ වර්ෂය මගින් සොයන්න...',
    aiSearchPlaceholder: '✨ AI සෙවුම: "2023 කොළඹ රාජකීය විද්‍යාලයේ සංයුක්ත ගණිතය 3 වන වාර ප්‍රශ්න පත්‍රය"...',
    uploadBtn: 'ප්‍රශ්න පත්‍රයක් එක් කරන්න',
    downloadBtn: 'බාගත කරන්න',
    previewBtn: 'පූර්ව දර්ශනය',
    bookmarkBtn: 'සුරකින්න',
    shareBtn: 'බෙදාගන්න',
    reportBtn: 'වාර්තා කරන්න',
    filterTitle: 'පෙරහන',
    resetFilters: 'යළි සකසන්න',
    applyFilters: 'පෙරහන යොදන්න',
    loginBtn: 'ඇතුළු වන්න',
    registerBtn: 'ලියාපදිංචි වන්න',
    logoutBtn: 'නික්ම යන්න',
    
    // Filter labels
    grade: 'ශ්‍රේණිය',
    subject: 'විෂය',
    medium: 'මාධ්‍යය',
    year: 'වර්ෂය',
    province: 'පළාත',
    school: 'පාසල',
    paperType: 'ප්‍රශ්න පත්‍ර වර්ගය',
    fileFormat: 'ගොනු ආකෘතිය',
    sortBy: 'පිළිවෙල',
    
    // Sort options
    newest: 'අලුත්ම ප්‍රශ්න පත්‍ර',
    popular: 'වැඩිම පිරිසක් නැරඹූ',
    trending: 'ජනප්‍රියම',
    downloads: 'වැඩිම වාර ගණනක් බාගත කළ',
    
    // Paper details
    hasAnswers: 'පිළිතුරු ඇතුළත්ය',
    hasMarkingScheme: 'ලකුණු දීමේ පටිපාටිය ඇතුළත්ය',
    viewsCount: 'නැරඹීම්',
    downloadCount: 'බාගත කිරීම්',
    uploadedBy: 'එක් කළේ',
    uploadedDate: 'එක් කළ දිනය',
    fileSize: 'ගොනුවේ ප්‍රමාණය',
    pagesCount: 'පිටු ගණන',
    
    // Role Badges
    roleGuest: 'අමුත්තා',
    roleStudent: 'ශිෂ්‍යයා',
    roleTeacher: 'ගුරුවරයා',
    roleModerator: 'මධ්‍යස්ථකරු',
    roleAdmin: 'පරිපාලක',
    roleSuperAdmin: 'ප්‍රධාන පරිපාලක',
    
    // Community
    createPost: 'සමූහයට සටහනක් එක් කරන්න',
    postPlaceholder: 'විභාග උපදෙස්, ප්‍රශ්න පත්‍ර ඉල්ලීම් හෝ පාඩම් කරුණු සාකච්ඡා කරන්න...',
    addPoll: 'ඡන්ද විමසීමක් එක් කරන්න',
    vote: 'ඡන්දය දෙන්න',
    comments: 'අදහස්',
    like: 'කැමැත්ත',
    pinnedAnnouncement: 'ප්‍රධාන නිවේදනය',
    
    // AI Assistant
    aiAssistantTitle: 'ලංකා පේපර් හබ් AI විභාග සහායක',
    aiAssistantSubtitle: 'ශ්‍රී ලංකා විෂය නිර්දේශයට අනුව ප්‍රශ්න පත්‍ර සාරාංශ, පාඩම් කරුණු සහ AI පුහුණු ප්‍රශ්න ලබා ගන්න.',
    aiAskBtn: 'AI විශ්ලේෂණය ලබාගන්න',
    
    // Admin
    adminTitle: 'ප්‍රධාන පරිපාලන පුවරුව',
    pendingUploads: 'අනුමැතිය සඳහා ඇති ප්‍රශ්න පත්‍ර',
    approve: 'අනුමත කරන්න',
    reject: 'ප්‍රතික්ෂේප කරන්න',
    banUser: 'තහනම් කරන්න',
    userManagement: 'පරිශීලක කළමනාකරණය',
    systemLogs: 'පද්ධති සටහන්',
    
    // Gamification
    gamificationPoints: 'ලකුණු',
    level: 'මට්ටම',
    topContributors: 'ඉහළම දායකයින්ගේ පුවරුව',
    badges: 'සම්මාන සහ පදක්කම්',
    
    // Status
    statusApproved: 'අනුමතයි',
    statusPending: 'සලකා බලමින් පවතී',
    statusRejected: 'ප්‍රතික්ෂේපිතයි'
  }
};
