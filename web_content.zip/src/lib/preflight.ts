import type { Project, ValidationIssue } from "@/types";
import { buildTimeline } from "@/lib/timeline";

export interface PreflightOptions {
  availableMedia?: Set<string>;
  requireAudio?: boolean;
  expectedDuration?: number;
}

export function requiredMediaIds(project: Project): string[] {
  const ids = [
    project.design.background.imageId,
    project.design.brand.logoId,
    project.timing.backgroundMusicId,
    ...project.questions.flatMap((q) => [
      q.questionAudioId,
      q.optionsAudioId,
      q.combinedAudioId,
      q.answerAudioId,
      q.imageId,
    ]),
  ].filter((id): id is string => Boolean(id));
  return [...new Set(ids)];
}

export function validateProject(project: Project, options: PreflightOptions = {}): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  const timing = project.timing;
  const requireAudio = options.requireAudio ?? timing.requireAudio;
  const available = options.availableMedia;

  if (!project.questions.length) {
    issues.push({ level: "error", message: "لا يوجد أي سؤال في المشروع. أضف سؤالًا واحدًا على الأقل قبل التصدير." });
  }

  project.questions.forEach((question, index) => {
    const label = `السؤال ${index + 1}`;
    if (!question.question.trim()) {
      issues.push({ level: "error", message: `${label}: نص السؤال فارغ.`, questionId: question.id, field: "question" });
    }
    if (!Array.isArray(question.options) || question.options.length !== 4) {
      issues.push({ level: "error", message: `${label}: يجب توفير أربعة خيارات بالضبط.`, questionId: question.id, field: "options" });
    } else {
      question.options.forEach((option, optionIndex) => {
        if (!option.trim()) {
          issues.push({
            level: "error",
            message: `${label}: الخيار ${optionIndex + 1} فارغ.`,
            questionId: question.id,
            field: `option-${optionIndex}`,
          });
        }
      });
    }
    if (!Number.isInteger(question.correct) || question.correct < 0 || question.correct > 3) {
      issues.push({
        level: "error",
        message: `${label}: لم تُحدَّد إجابة صحيحة واحدة. حدّد الخيار الصحيح.`,
        questionId: question.id,
        field: "correct",
      });
    }
    if (!Number.isFinite(question.thinkSec) || question.thinkSec < 1) {
      issues.push({
        level: "warning",
        message: `${label}: مدة التفكير أقل من ثانية، سيُعتمد حد أدنى ثانية واحدة.`,
        questionId: question.id,
        field: "thinkSec",
      });
    }
    if (timing.audioMode === "combined") {
      if (!question.combinedAudioId) {
        issues.push({
          level: requireAudio ? "error" : "warning",
          message: `${label}: وضع «ملف واحد» مختار لكن لا يوجد ملف صوت موحّد. سيُستخدم وقت صامت.`,
          questionId: question.id,
          field: "combinedAudio",
        });
      }
    } else if (requireAudio && (!question.questionAudioId || !question.optionsAudioId)) {
      issues.push({
        level: "error",
        message: `${label}: ملف صوت السؤال وملف صوت الخيارات مطلوبان وفق إعداداتك الحالية.`,
        questionId: question.id,
        field: "audio-required",
      });
    } else if (!question.questionAudioId && !question.optionsAudioId) {
      issues.push({
        level: "warning",
        message: `${label}: لا يوجد صوت للسؤال أو الخيارات. سيُستخدم وقت قراءة صامت وفق الإعدادات.`,
        questionId: question.id,
        field: "audio",
      });
    }

    const checks: [string | null, string][] = [
      [question.questionAudioId, "صوت السؤال"],
      [question.optionsAudioId, "صوت الخيارات"],
      [question.combinedAudioId, "الصوت الموحّد"],
      [question.answerAudioId, "صوت الإجابة"],
      [question.imageId, "صورة السؤال"],
    ];
    for (const [id, role] of checks) {
      if (!id) continue;
      if (!project.media[id]) {
        issues.push({
          level: "error",
          message: `${label}: ${role} مرتبط بالمشروع لكن بياناته مفقودة. أعد رفع الملف.`,
          questionId: question.id,
        });
      } else if (available && !available.has(id)) {
        issues.push({
          level: "error",
          message: `${label}: ${role} («${project.media[id].name}») غير متاح في التخزين المحلي. أعد رفعه أو استورد المشروع كاملًا.`,
          questionId: question.id,
        });
      }
    }
  });

  for (const [id, role] of [
    [project.timing.backgroundMusicId, "الموسيقى الخلفية"],
    [project.design.background.imageId, "خلفية التصميم"],
    [project.design.brand.logoId, "الشعار"],
  ] as const) {
    if (!id) continue;
    if (!project.media[id]) {
      issues.push({ level: "warning", message: `${role}: البيانات مفقودة من المشروع وسيتم تجاهلها.` });
    } else if (available && !available.has(id)) {
      issues.push({ level: "warning", message: `${role}: الملف «${project.media[id].name}» لم يعد متاحًا وسيتم تجاهله.` });
    }
  }

  const width = project.exportSettings.width;
  const height = project.exportSettings.height;
  if (!Number.isFinite(width) || !Number.isFinite(height) || width < 256 || height < 256) {
    issues.push({ level: "error", message: "أبعاد الفيديو غير صالحة. الحد الأدنى 256 بكسل لكل بُعد." });
  } else if (width % 2 !== 0 || height % 2 !== 0) {
    issues.push({ level: "error", message: "يجب أن تكون أبعاد الفيديو أرقامًا زوجية لترميز H.264. عدّل العرض أو الارتفاع." });
  }
  if (width > 3840 || height > 3840) {
    issues.push({ level: "warning", message: "الأبعاد كبيرة جدًا وقد تفشل على الهواتف. يُنصح بأبعاد 1080p كحد أقصى." });
  }
  if (![24, 25, 30].includes(project.exportSettings.fps)) {
    issues.push({ level: "error", message: "معدل الإطارات غير مدعوم. اختر 24 أو 25 أو 30 إطارًا في الثانية." });
  }

  const timeline = buildTimeline(project);
  if (timeline.totalDuration > 180) {
    issues.push({
      level: "warning",
      message: `مدة الفيديو ${Math.round(timeline.totalDuration)} ثانية. قد تستهلك الذاكرة على الهاتف؛ صدّر على جهاز كمبيوتر أو اخفض الأبعاد.`,
    });
  }
  if (timeline.totalDuration > 360) {
    issues.push({
      level: "error",
      message: "تجاوزت مدة الفيديو 6 دقائق، وهو الحد الأقصى الآمن للتصدير المحلي في هذه النسخة. قصّر الأسئلة أو قسّم المشروع.",
    });
  }
  if (timeline.totalDuration < 1) {
    issues.push({ level: "warning", message: "مدة الفيديو أقل من ثانية واحدة. راجع إعدادات التوقيت." });
  }
  return issues;
}

export function issueSummary(issues: ValidationIssue[]): { errors: number; warnings: number } {
  return {
    errors: issues.filter((issue) => issue.level === "error").length,
    warnings: issues.filter((issue) => issue.level === "warning").length,
  };
}
