import { create } from "zustand";
import { persist } from "zustand/middleware";

export type PrayerKey = "fajr" | "dhuhr" | "asr" | "maghrib" | "isha";
export type Fav = { id: string; kind: string; title: string; text?: string; href?: string };
export type Bookmark = { surah: number; ayah: number; at: number };

export type PrayerToggle = { notify: boolean; adhan: boolean };

const prayers: PrayerKey[] = ["fajr", "dhuhr", "asr", "maghrib", "isha"];

function defaultPerPrayer(): Record<PrayerKey, PrayerToggle> {
  return {
    fajr: { notify: true, adhan: true },
    dhuhr: { notify: true, adhan: true },
    asr: { notify: true, adhan: true },
    maghrib: { notify: true, adhan: true },
    isha: { notify: true, adhan: true },
  };
}

export type Prefs = {
  theme: "light" | "dark";
  fontScale: number;
  reciterId: string;
  playbackRate: number;
  volume: number;
  calcMethod: string;
  madhab: "shafi" | "hanafi";
  cityId: string;
  coords: { lat: number; lng: number; label: string } | null;
  adjustments: Record<PrayerKey | "sunrise", number>;
  notifEnabled: boolean;
  preMinutes: number;
  perPrayer: Record<PrayerKey, PrayerToggle>;
  adhanVolume: number;
  mutedUntil: number | null;
  iqamaNotify: boolean;
  iqamaDelay: number;
  bookmarks: Bookmark[];
  favorites: Fav[];
  lastRead: { surah: number; ayah: number; page: number } | null;
  readPages: number[];
  khatma: { dailyPages: number; startDate: string; startPage: number } | null;
  wardHour: number;
  adhkarLog: Record<string, { date: string; count: number }>;
  sunnahLog: Record<string, string>;
  tasbeeh: {
    phrase: string;
    count: number;
    goal: number;
    sound: boolean;
    vibrate: boolean;
    today: string;
    todayCount: number;
    history: { date: string; count: number }[];
    customs: string[];
  };
  quizLog: { cat: string; score: number; total: number; at: number }[];
  cachedAudio: Record<string, number[]>;
  goals: { ayahs: number; tasbeeh: number };
  todayRead: { date: string; ayahs: number; pages: number };
  alertsFired: string[];
  setTheme: (t: "light" | "dark") => void;
  setFontScale: (n: number) => void;
  patch: (p: Partial<Prefs>) => void;
  toggleBookmark: (surah: number, ayah: number) => void;
  toggleFav: (fav: Fav) => void;
  isFav: (id: string) => boolean;
  markPage: (page: number, ayahsOnPage: number) => void;
  bumpAdhkar: (id: string, date: string, step?: number) => void;
  toggleSunnah: (id: string, date: string) => void;
  tasbeehTap: (date: string) => void;
  tasbeehReset: (date: string) => void;
  setTasbeehPhrase: (phrase: string) => void;
  addQuiz: (row: { cat: string; score: number; total: number }) => void;
  markCached: (reciterId: string, surah: number) => void;
  clearCachedAudio: () => void;
  rememberAlert: (key: string) => void;
  replaceAll: (state: Partial<Prefs>) => void;
};

function applyTheme(theme: "light" | "dark") {
  if (typeof document === "undefined") return;
  document.documentElement.classList.toggle("dark", theme === "dark");
}

const zeroAdj = { fajr: 0, sunrise: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 };

export const usePrefs = create<Prefs>()(
  persist(
    (set, get) => ({
      theme: "light",
      fontScale: 1,
      reciterId: "alafasy",
      playbackRate: 1,
      volume: 1,
      calcMethod: "UmmAlQura",
      madhab: "shafi",
      cityId: "makkah",
      coords: null,
      adjustments: { ...zeroAdj },
      notifEnabled: false,
      preMinutes: 10,
      perPrayer: defaultPerPrayer(),
      adhanVolume: 1,
      mutedUntil: null,
      iqamaNotify: false,
      iqamaDelay: 15,
      bookmarks: [],
      favorites: [],
      lastRead: null,
      readPages: [],
      khatma: null,
      wardHour: 8,
      adhkarLog: {},
      sunnahLog: {},
      tasbeeh: {
        phrase: "سبحان الله",
        count: 0,
        goal: 100,
        sound: false,
        vibrate: true,
        today: "",
        todayCount: 0,
        history: [],
        customs: [],
      },
      quizLog: [],
      cachedAudio: {},
      goals: { ayahs: 20, tasbeeh: 100 },
      todayRead: { date: "", ayahs: 0, pages: 0 },
      alertsFired: [],
      setTheme: (t) => {
        applyTheme(t);
        set({ theme: t });
      },
      setFontScale: (n) => set({ fontScale: Math.min(1.7, Math.max(0.85, n)) }),
      patch: (p) => set(p),
      toggleBookmark: (surah, ayah) => {
        const list = get().bookmarks;
        const i = list.findIndex((b) => b.surah === surah && b.ayah === ayah);
        if (i >= 0) set({ bookmarks: list.filter((_, idx) => idx !== i) });
        else set({ bookmarks: [{ surah, ayah, at: Date.now() }, ...list].slice(0, 400) });
      },
      toggleFav: (fav) => {
        const list = get().favorites;
        if (list.some((f) => f.id === fav.id)) set({ favorites: list.filter((f) => f.id !== fav.id) });
        else set({ favorites: [fav, ...list].slice(0, 500) });
      },
      isFav: (id) => get().favorites.some((f) => f.id === id),
      markPage: (page, ayahsOnPage) => {
        const today = new Date();
        const key = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
        const read = new Set(get().readPages);
        const fresh = !read.has(page);
        read.add(page);
        const prev = get().todayRead;
        const base = prev.date === key ? prev : { date: key, ayahs: 0, pages: 0 };
        set({
          readPages: [...read].sort((a, b) => a - b),
          todayRead: fresh
            ? { date: key, ayahs: base.ayahs + ayahsOnPage, pages: base.pages + 1 }
            : base,
        });
      },
      bumpAdhkar: (id, date, step = 1) => {
        const cur = get().adhkarLog[id];
        const count = cur && cur.date === date ? cur.count + step : step;
        set({ adhkarLog: { ...get().adhkarLog, [id]: { date, count: Math.max(0, count) } } });
      },
      toggleSunnah: (id, date) => {
        const log = { ...get().sunnahLog };
        if (log[id] === date) delete log[id];
        else log[id] = date;
        set({ sunnahLog: log });
      },
      tasbeehTap: (date) => {
        const t = get().tasbeeh;
        const same = t.today === date;
        const todayCount = (same ? t.todayCount : 0) + 1;
        const history = same
          ? t.history.map((h) => (h.date === date ? { date, count: todayCount } : h))
          : [{ date, count: todayCount }, ...t.history.filter((h) => h.date !== date)].slice(0, 120);
        if (!history.some((h) => h.date === date)) history.unshift({ date, count: todayCount });
        set({
          tasbeeh: {
            ...t,
            count: t.count + 1,
            today: date,
            todayCount,
            history,
          },
        });
      },
      tasbeehReset: (date) => {
        const t = get().tasbeeh;
        set({
          tasbeeh: {
            ...t,
            count: 0,
            today: date,
            todayCount: t.today === date ? 0 : t.todayCount,
          },
        });
      },
      setTasbeehPhrase: (phrase) => set({ tasbeeh: { ...get().tasbeeh, phrase, count: 0 } }),
      addQuiz: (row) =>
        set({ quizLog: [{ ...row, at: Date.now() }, ...get().quizLog].slice(0, 80) }),
      markCached: (reciterId, surah) => {
        const cur = get().cachedAudio[reciterId] || [];
        if (cur.includes(surah)) return;
        set({ cachedAudio: { ...get().cachedAudio, [reciterId]: [...cur, surah].sort((a, b) => a - b) } });
      },
      clearCachedAudio: () => set({ cachedAudio: {} }),
      rememberAlert: (key) => set({ alertsFired: [key, ...get().alertsFired].slice(0, 40) }),
      replaceAll: (state) => set(state),
    }),
    {
      name: "tawbah",
      version: 1,
      onRehydrateStorage: () => (state) => {
        if (state?.theme) applyTheme(state.theme);
      },
    },
  ),
);

export const PRAYER_KEYS = prayers;
