import { Chess, DEFAULT_POSITION, type Color } from "chess.js";

export type Mark = "best" | "excellent" | "good" | "inaccuracy" | "mistake" | "blunder";

export function classify(lossCp: number, isBest: boolean): Mark {
  if (isBest || lossCp <= 15) return "best";
  if (lossCp < 45) return "excellent";
  if (lossCp < 90) return "good";
  if (lossCp < 160) return "inaccuracy";
  if (lossCp < 300) return "mistake";
  return "blunder";
}

export const MARK_GLYPH: Record<Mark, string> = {
  best: "",
  excellent: "!",
  good: "",
  inaccuracy: "?!",
  mistake: "?",
  blunder: "??",
};

export function formatEval(cp: number | null, mate: number | null) {
  if (mate != null) {
    if (mate === 0) return "Mate";
    return mate > 0 ? `+M${mate}` : `-M${Math.abs(mate)}`;
  }
  if (cp == null) return "0.0";
  const pawns = cp / 100;
  const sign = pawns > 0 ? "+" : "";
  return `${sign}${pawns.toFixed(1)}`;
}

export function evalShare(cp: number | null, mate: number | null) {
  let score = cp ?? 0;
  if (mate != null) score = mate === 0 ? 0 : mate > 0 ? 1800 : -1800;
  const clamped = Math.max(-900, Math.min(900, score));
  return 50 + (clamped / 900) * 46;
}

export function resultOf(chess: Chess) {
  if (chess.isCheckmate()) {
    const winner = chess.turn() === "w" ? "Black" : "White";
    return {
      text: `Checkmate · ${winner} wins`,
      pgn: winner === "White" ? "1-0" : "0-1",
    };
  }
  if (chess.isStalemate()) return { text: "Stalemate · draw", pgn: "1/2-1/2" };
  if (chess.isThreefoldRepetition()) return { text: "Threefold repetition · draw", pgn: "1/2-1/2" };
  if (chess.isInsufficientMaterial()) return { text: "Insufficient material · draw", pgn: "1/2-1/2" };
  if (chess.isDrawByFiftyMoves()) return { text: "Fifty-move rule · draw", pgn: "1/2-1/2" };
  if (chess.isDraw()) return { text: "Draw", pgn: "1/2-1/2" };
  return { text: "", pgn: "*" };
}

export function pgnResultToken(result: string | null) {
  if (!result) return "*";
  if (result.includes("White wins")) return "1-0";
  if (result.includes("Black wins")) return "0-1";
  if (/draw|stalemate/i.test(result)) return "1/2-1/2";
  return "*";
}

export function buildPgn(input: {
  startFen: string;
  sans: string[];
  player: Color;
  botElo: number;
  result: string | null;
}) {
  const chess = input.startFen === DEFAULT_POSITION ? new Chess() : new Chess(input.startFen);
  if (input.startFen !== DEFAULT_POSITION) {
    chess.setHeader("FEN", input.startFen);
    chess.setHeader("SetUp", "1");
  }
  for (const san of input.sans) chess.move(san);
  const youWhite = input.player === "w";
  const bot = `Halden ${input.botElo}`;
  chess.setHeader("Event", "Halden");
  chess.setHeader("Site", "Halden");
  chess.setHeader("Date", new Date().toISOString().slice(0, 10).replaceAll("-", "."));
  chess.setHeader("White", youWhite ? "You" : bot);
  chess.setHeader("Black", youWhite ? bot : "You");
  chess.setHeader("Result", pgnResultToken(input.result));
  return chess.pgn({ maxWidth: 76 });
}

export function strengthLabel(elo: number, floor: number, ceiling: number, engineReady: boolean) {
  if (!engineReady || elo < floor) {
    if (elo < 400) return "Built-in beginner";
    if (elo < 800) return "Built-in casual";
    if (elo < floor) return "Built-in club player";
  }
  if (elo > ceiling) return "Stockfish, full strength";
  return "Stockfish, strength limited";
}
