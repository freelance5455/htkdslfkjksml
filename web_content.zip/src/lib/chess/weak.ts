import { Chess, type Move, type PieceSymbol } from "chess.js";

const VAL: Record<PieceSymbol, number> = {
  p: 100,
  n: 320,
  b: 330,
  r: 500,
  q: 900,
  k: 0,
};

/** Piece-square tables, index 0 = a8, white's point of view. Mirrored for black. */
const PST: Record<PieceSymbol, number[]> = {
  p: [
    0, 0, 0, 0, 0, 0, 0, 0, 50, 50, 50, 50, 50, 50, 50, 50, 10, 10, 20, 30, 30, 20, 10, 10, 5, 5, 10,
    25, 25, 10, 5, 5, 0, 0, 0, 20, 20, 0, 0, 0, 5, -5, -10, 0, 0, -10, -5, 5, 5, 10, 10, -20, -20, 10,
    10, 5, 0, 0, 0, 0, 0, 0, 0, 0,
  ],
  n: [
    -50, -40, -30, -30, -30, -30, -40, -50, -40, -20, 0, 0, 0, 0, -20, -40, -30, 0, 10, 15, 15, 10, 0,
    -30, -30, 5, 15, 20, 20, 15, 5, -30, -30, 0, 15, 20, 20, 15, 0, -30, -30, 5, 10, 15, 15, 10, 5, -30,
    -40, -20, 0, 5, 5, 0, -20, -40, -50, -40, -30, -30, -30, -30, -40, -50,
  ],
  b: [
    -20, -10, -10, -10, -10, -10, -10, -20, -10, 0, 0, 0, 0, 0, 0, -10, -10, 0, 5, 10, 10, 5, 0, -10,
    -10, 5, 5, 10, 10, 5, 5, -10, -10, 0, 10, 10, 10, 10, 0, -10, -10, 10, 10, 10, 10, 10, 10, -10, -10,
    5, 0, 0, 0, 0, 5, -10, -20, -10, -10, -10, -10, -10, -10, -20,
  ],
  r: [
    0, 0, 0, 0, 0, 0, 0, 0, 5, 10, 10, 10, 10, 10, 10, 5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0,
    0, -5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, 0, 0, 0, 5, 5,
    0, 0, 0,
  ],
  q: [
    -20, -10, -10, -5, -5, -10, -10, -20, -10, 0, 0, 0, 0, 0, 0, -10, -10, 0, 5, 5, 5, 5, 0, -10, -5,
    0, 5, 5, 5, 5, 0, -5, 0, 0, 5, 5, 5, 5, 0, -5, -10, 5, 5, 5, 5, 5, 0, -10, -10, 0, 5, 0, 0,
    0, 0, -10, -20, -10, -10, -5, -5, -10, -10, -20,
  ],
  k: [
    -30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50,
    -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40, -30, -20, -30, -30, -40, -40, -30, -30, -20,
    -10, -20, -20, -20, -20, -20, -20, -10, 20, 20, 0, 0, 0, 0, 20, 20, 20, 30, 10, 0, 0, 10, 30, 20,
  ],
};

const BOOK_LINES = [
  "e4 e5 Nf3 Nc6 Bb5 a6",
  "e4 e5 Nf3 Nc6 Bc4 Bc5",
  "e4 e5 Nf3 Nc6 Bc4 Nf6",
  "e4 c5 Nf3 d6 d4 cxd4 Nxd4",
  "e4 c5 Nf3 Nc6 d4",
  "e4 e6 d4 d5",
  "e4 c6 d4 d5",
  "e4 e5 Nf3 Nf6",
  "d4 d5 c4 e6",
  "d4 d5 c4 c6",
  "d4 Nf6 c4 g6",
  "d4 Nf6 c4 e6",
  "d4 d5 Nf3 Nf6",
  "Nf3 d5 d4",
  "c4 e5 Nc3 Nf6",
];

function uciOf(move: Move) {
  return `${move.from}${move.to}${move.promotion ?? ""}`;
}

function bookReplies() {
  const map = new Map<string, string[]>();
  for (const line of BOOK_LINES) {
    const chess = new Chess();
    for (const san of line.split(" ")) {
      const key = chess.fen().split(" ").slice(0, 4).join(" ");
      let move: Move;
      try {
        move = chess.move(san);
      } catch {
        break;
      }
      const list = map.get(key) ?? [];
      const uci = uciOf(move);
      if (!list.includes(uci)) list.push(uci);
      map.set(key, list);
    }
  }
  return map;
}

const BOOK = bookReplies();

function bookUci(fen: string, elo: number) {
  if (elo < 380) return null;
  const options = BOOK.get(fen.split(" ").slice(0, 4).join(" "));
  if (!options?.length) return null;
  const use = elo > 900 ? 0.9 : elo > 600 ? 0.62 : 0.35;
  if (Math.random() > use) return null;
  return options[Math.floor(Math.random() * options.length)];
}

function spec(move: Move) {
  return { from: move.from, to: move.to, promotion: move.promotion };
}

function evalWhite(fen: string) {
  const placement = fen.split(" ")[0] ?? "";
  let rank = 0;
  let file = 0;
  let score = 0;
  for (const ch of placement) {
    if (ch === "/") {
      rank += 1;
      file = 0;
      continue;
    }
    if (ch >= "1" && ch <= "8") {
      file += Number(ch);
      continue;
    }
    const color = ch === ch.toUpperCase() ? "w" : "b";
    const type = ch.toLowerCase() as PieceSymbol;
    const idx = (color === "w" ? rank : 7 - rank) * 8 + file;
    const val = VAL[type] + (PST[type][idx] ?? 0);
    score += color === "w" ? val : -val;
    file += 1;
  }
  return score;
}

function sideEval(chess: Chess) {
  const white = evalWhite(chess.fen());
  return chess.turn() === "w" ? white : -white;
}

function ordered(chess: Chess) {
  const moves = chess.moves({ verbose: true });
  const victim: Record<PieceSymbol, number> = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };
  return moves.sort((a, b) => score(b) - score(a));

  function score(move: Move) {
    let value = 0;
    if (move.captured) value += 10 * victim[move.captured] - victim[move.piece];
    if (move.promotion === "q") value += 8;
    return value;
  }
}

function search(chess: Chess, elo: number) {
  const depth = elo < 550 ? 1 : 2;
  const maxNodes = elo < 450 ? 500 : elo < 850 ? 4000 : 14000;
  let nodes = 0;

  const scoreMove = (depthLeft: number, alphaIn: number, beta: number, ply: number): number => {
    if (nodes++ > maxNodes) return sideEval(chess);
    if (chess.isCheckmate()) return -100000 + ply;
    if (chess.isDraw()) return 0;
    if (depthLeft === 0) return quiesce(alphaIn, beta, ply, 0);

    let alpha = alphaIn;
    const moves = ordered(chess);
    if (!moves.length) return chess.inCheck() ? -100000 + ply : 0;
    for (const move of moves) {
      chess.move(spec(move));
      const score = -scoreMove(depthLeft - 1, -beta, -alpha, ply + 1);
      chess.undo();
      if (score > alpha) alpha = score;
      if (alpha >= beta) break;
    }
    return alpha;
  };

  const quiesce = (alphaIn: number, beta: number, ply: number, qdepth: number): number => {
    if (nodes++ > maxNodes) return sideEval(chess);
    if (chess.isCheckmate()) return -100000 + ply;
    if (chess.isDraw()) return 0;
    const check = chess.inCheck();
    let alpha = alphaIn;
    if (!check) {
      const stand = sideEval(chess);
      if (stand >= beta) return beta;
      if (stand > alpha) alpha = stand;
      if (qdepth >= 2) return alpha;
    }
    const moves = ordered(chess).filter((move) => check || move.captured || move.promotion);
    if (!moves.length) return alpha;
    for (const move of moves) {
      chess.move(spec(move));
      const score = -quiesce(-beta, -alpha, ply + 1, qdepth + 1);
      chess.undo();
      if (score > alpha) alpha = score;
      if (alpha >= beta) break;
    }
    return alpha;
  };

  const root = ordered(chess).map((move) => {
    chess.move(spec(move));
    const score = depth <= 1 ? -sideEval(chess) : -scoreMove(depth - 1, -1000000, 1000000, 1);
    chess.undo();
    return { move, score };
  });
  root.sort((a, b) => b.score - a.score);
  return root;
}

function pick(scored: { move: Move; score: number }[], elo: number) {
  if (!scored.length) throw new Error("No scored moves");
  if (scored.length === 1) return scored[0].move;
  const randomP = elo < 180 ? 0.85 : elo < 400 ? 0.42 : elo < 700 ? 0.16 : elo < 1000 ? 0.06 : 0.015;
  if (Math.random() < randomP) {
    const pool =
      elo > 650
        ? scored.filter((row) => row.score > -50000 && row.score >= scored[0].score - 180)
        : scored;
    const choices = pool.length ? pool : scored;
    const span = elo < 400 ? choices.length : Math.min(choices.length, 5);
    return choices[Math.floor(Math.random() * span)].move;
  }
  const temp = Math.max(8, (1100 - elo) / 12 + 8);
  const pool = scored.filter((row) => row.score >= scored[0].score - temp * 3);
  const band = pool.length ? pool : scored.slice(0, 2);
  const max = band[0].score;
  const weights = band.map((row) => Math.exp((row.score - max) / temp));
  let roll = Math.random() * weights.reduce((sum, weight) => sum + weight, 0);
  for (let i = 0; i < band.length; i += 1) {
    roll -= weights[i];
    if (roll <= 0) return band[i].move;
  }
  return band[0].move;
}

export function weakUci(fen: string, elo: number) {
  const chess = new Chess(fen);
  const moves = chess.moves({ verbose: true });
  if (!moves.length) throw new Error("No legal moves");
  const booked = bookUci(fen, elo);
  if (booked && moves.some((move) => uciOf(move) === booked)) return booked;
  if (elo < 280) {
    const captures = moves.filter((move) => move.captured);
    const pool = captures.length && Math.random() < 0.35 ? captures : moves;
    return uciOf(pool[Math.floor(Math.random() * pool.length)]);
  }
  const scored = search(chess, elo);
  if (!scored.length) return uciOf(moves[0]);
  return uciOf(pick(scored, elo));
}

export function thinkDelay(elo: number) {
  if (elo < 400) return 180 + Math.random() * 220;
  if (elo < 1000) return 260 + Math.random() * 320;
  return 320 + Math.random() * 380;
}
