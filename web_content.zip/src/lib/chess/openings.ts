import { Chess, DEFAULT_POSITION } from "chess.js";

const LINES: [string, string][] = [
  ["e4", "King's Pawn"],
  ["e4 e5", "Open Game"],
  ["e4 e5 Nf3", "King's Knight"],
  ["e4 e5 Nf3 Nc6", "King's Knight Opening"],
  ["e4 e5 Nf3 Nc6 Bc4", "Italian Game"],
  ["e4 e5 Nf3 Nc6 Bc4 Bc5", "Giuoco Piano"],
  ["e4 e5 Nf3 Nc6 Bc4 Bc5 c3", "Giuoco Piano"],
  ["e4 e5 Nf3 Nc6 Bc4 Nf6", "Two Knights Defense"],
  ["e4 e5 Nf3 Nc6 Bc4 Be7", "Hungarian Defense"],
  ["e4 e5 Nf3 Nc6 Bb5", "Ruy Lopez"],
  ["e4 e5 Nf3 Nc6 Bb5 a6", "Ruy Lopez, Morphy"],
  ["e4 e5 Nf3 Nc6 Bb5 Nf6", "Ruy Lopez, Berlin"],
  ["e4 e5 Nf3 Nf6", "Petrov Defense"],
  ["e4 e5 Nf3 d6", "Philidor Defense"],
  ["e4 e5 Nf3 Nc6 d4", "Scotch Game"],
  ["e4 e5 f4", "King's Gambit"],
  ["e4 c5", "Sicilian Defense"],
  ["e4 c5 Nf3", "Sicilian Defense"],
  ["e4 c5 Nf3 d6", "Sicilian Defense"],
  ["e4 c5 Nf3 d6 d4", "Open Sicilian"],
  ["e4 c5 Nf3 Nc6", "Sicilian, Old Sicilian"],
  ["e4 c5 c3", "Sicilian, Alapin"],
  ["e4 c5 Nc3", "Closed Sicilian"],
  ["e4 e6", "French Defense"],
  ["e4 e6 d4", "French Defense"],
  ["e4 c6", "Caro-Kann"],
  ["e4 c6 d4", "Caro-Kann"],
  ["e4 d5", "Scandinavian Defense"],
  ["e4 d6", "Pirc Defense"],
  ["e4 g6", "Modern Defense"],
  ["e4 Nf6", "Alekhine Defense"],
  ["d4", "Queen's Pawn"],
  ["d4 d5", "Closed Game"],
  ["d4 d5 c4", "Queen's Gambit"],
  ["d4 d5 c4 e6", "Queen's Gambit Declined"],
  ["d4 d5 c4 c6", "Slav Defense"],
  ["d4 d5 c4 dxc4", "Queen's Gambit Accepted"],
  ["d4 Nf6", "Indian Defense"],
  ["d4 Nf6 c4", "Indian Game"],
  ["d4 Nf6 c4 e6", "Nimzo / Queen's Indian family"],
  ["d4 Nf6 c4 g6", "King's Indian / Grünfeld family"],
  ["d4 Nf6 Nf3", "Indian, flexible"],
  ["d4 f5", "Dutch Defense"],
  ["c4", "English Opening"],
  ["c4 e5", "English, reversed Sicilian"],
  ["c4 c5", "English, symmetrical"],
  ["Nf3", "Réti / Zukertort"],
  ["Nf3 d5", "Réti"],
  ["Nf3 Nf6", "Réti"],
];

function keyOf(fen: string) {
  return fen.split(" ").slice(0, 4).join(" ");
}

const BOOK = new Map<string, string>();

for (const [moves, name] of LINES) {
  const chess = new Chess();
  let ok = true;
  for (const san of moves.split(" ")) {
    try {
      chess.move(san);
    } catch {
      ok = false;
      break;
    }
  }
  if (ok) BOOK.set(keyOf(chess.fen()), name);
}

export function openingName(startFen: string, sans: string[]): string | null {
  if (startFen !== DEFAULT_POSITION) return null;
  const chess = new Chess();
  let name: string | null = null;
  for (const san of sans) {
    try {
      chess.move(san);
    } catch {
      break;
    }
    const hit = BOOK.get(keyOf(chess.fen()));
    if (hit) name = hit;
  }
  return name;
}
