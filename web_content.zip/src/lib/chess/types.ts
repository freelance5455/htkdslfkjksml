export type Difficulty = "beginner" | "intermediate" | "advanced";

export type DurationSec = 3 | 5 | 10 | 15;

export const DURATIONS: DurationSec[] = [3, 5, 10, 15];

export const DEFAULT_DURATION: Record<Difficulty, DurationSec> = {
  beginner: 10,
  intermediate: 5,
  advanced: 3,
};

export function isDifficulty(value: unknown): value is Difficulty {
  return value === "beginner" || value === "intermediate" || value === "advanced";
}

export function isDuration(value: unknown): value is DurationSec {
  return value === 3 || value === 5 || value === 10 || value === 15;
}
