import { Chess, type Move, type PieceSymbol, type Square } from "chess.js";
import type { Difficulty } from "./types";
import { allSquares, isLegalPosition, type BoardPiece } from "./position";

export type GeneratedPosition = {
  fen: string;
  ply: number;
  pieceCount: number;
  turn: "w" | "b";
  source: "played" | "fallback";
};

export const SHOWCASE_FEN =
  "r1bq1rk1/pp2ppbp/2np1np1/2p5/4P3/2NP1NP1/PPP2PBP/R1BQ1RK1 w - - 0 8";

const FALLBACKS: Record<Difficulty, string[]> = {
  beginner: [
    "4k3/8/2n1p3/8/3B4/4P3/5P2/4K3 w - - 0 1",
    "6k1/5pp1/8/3N4/2B5/8/5P2/6K1 w - - 0 1",
    "4kb2/6p1/4n3/8/3P4/8/6P1/4K3 w - - 0 1",
    "6k1/4pp2/3n4/8/3B4/8/4PP2/6K1 w - - 0 1",
    "2r1k3/8/4n3/3p4/4P3/5N2/8/4K3 w - - 0 1",
    "4k3/pp3p2/8/8/3N4/8/5P2/4K3 w - - 0 1",
  ],
  intermediate: [
    "r1bq1rk1/pp2ppbp/2np1np1/2p5/4P3/2NP1NP1/PPP2PBP/R1BQ1RK1 w - - 0 8",
    "r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/3P1N2/PPP2PPP/RNBQK2R w KQkq - 4 5",
    "rnbqkb1r/pp2pppp/3p1n2/2p5/4P3/2N2N2/PPPP1PPP/R1BQKB1R w KQkq - 2 4",
    "rnbq1rk1/ppp1ppbp/3p1np1/8/2PPP3/2N2N2/PP3PPP/R1BQKB1R w KQ - 0 6",
  ],
  advanced: [
    "r1bqk2r/pp1n1ppp/2pbpn2/3p4/3P4/2NBPN2/PPP2PPP/R1BQK2R w KQkq - 2 7",
    "r1bq1rk1/2ppbppp/p1n2n2/1p2p3/4P3/1B1P1N2/PPP2PPP/RNBQR1K1 w - - 0 9",
    "rnbq1rk1/ppp1ppbp/3p1np1/8/2PPP3/2N2N2/PP3PPP/R1BQKB1R w KQ - 0 6",
    "r1bq1rk1/pp2ppbp/2np1np1/2p5/4P3/2NP1NP1/PPP2PBP/R1BQ1RK1 w - - 0 8",
  ],
};

const START_MAP = piecesOf(new Chess());

function rand(min: number, max: number) {
  return min + Math.floor(Math.random() * (max - min + 1));
}

function shuffle<T>(items: T[]): T[] {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const swap = copy[i];
    copy[i] = copy[j] as T;
    copy[j] = swap as T;
  }
  return copy;
}

function weighted<T>(items: T[], weight: (item: T) => number): T {
  let total = 0;
  const weights = items.map((item) => {
    const value = Math.max(0.001, weight(item));
    total += value;
    return value;
  });
  let roll = Math.random() * total;
  for (let i = 0; i < items.length; i++) {
    roll -= weights[i] ?? 0;
    if (roll <= 0) return items[i] as T;
  }
  return items[items.length - 1] as T;
}

type Summary = {
  w: number;
  b: number;
  total: number;
  wq: number;
  bq: number;
  removable: { sq: Square; type: PieceSymbol; color: BoardPiece["color"] }[];
};

function inspect(chess: Chess): Summary {
  const summary: Summary = { w: 0, b: 0, total: 0, wq: 0, bq: 0, removable: [] };
  const board = chess.board();
  for (let rank = 0; rank < 8; rank++) {
    for (let file = 0; file < 8; file++) {
      const piece = board[rank]?.[file];
      if (!piece) continue;
      summary.total += 1;
      if (piece.color === "w") summary.w += 1;
      else summary.b += 1;
      if (piece.type === "q") {
        if (piece.color === "w") summary.wq += 1;
        else summary.bq += 1;
      }
      if (piece.type === "k") continue;
      summary.removable.push({
        sq: `${"abcdefgh"[file]}${8 - rank}` as Square,
        type: piece.type,
        color: piece.color,
      });
    }
  }
  return summary;
}

function piecesOf(chess: Chess) {
  const map = new Map<string, string>();
  for (const square of allSquares()) {
    const piece = chess.get(square);
    if (piece) map.set(square, `${piece.color}${piece.type}`);
  }
  return map;
}

function displacedCount(chess: Chess) {
  const map = piecesOf(chess);
  let diff = 0;
  for (const square of allSquares()) {
    if ((map.get(square) ?? "") !== (START_MAP.get(square) ?? "")) diff += 1;
  }
  return diff;
}

function scoreMove(move: Move, ply: number, captureBias: number) {
  let weight = 0.55 + Math.random();
  const early = ply < 18;
  if (move.piece === "n" || move.piece === "b") weight += early ? 2.5 : 0.55;
  if (move.piece === "p" && "cde".includes(move.to[0] ?? "")) weight += early ? 1.4 : 0.25;
  if (move.isKingsideCastle() || move.isQueensideCastle()) weight += 5;
  if (move.piece === "k" && !move.isKingsideCastle() && !move.isQueensideCastle()) weight *= 0.12;
  if (move.piece === "q" && ply < 10) weight *= 0.32;
  if (move.piece === "r" && ply < 14 && !move.isCapture()) weight *= 0.4;
  if (move.isCapture()) weight *= captureBias;
  return weight;
}

const BOOKS: string[][] = [
  ["e4", "e5", "Nf3", "Nc6", "Bb5", "a6", "Ba4", "Nf6", "O-O", "Be7", "Re1", "b5", "Bb3", "d6", "c3", "O-O", "h3", "Nb8", "d4"],
  ["d4", "Nf6", "c4", "g6", "Nc3", "Bg7", "e4", "d6", "Nf3", "O-O", "Be2", "e5", "O-O", "Nc6", "d5", "Ne7"],
  ["e4", "c5", "Nf3", "d6", "d4", "cxd4", "Nxd4", "Nf6", "Nc3", "a6", "Be3", "e5", "Nb3", "Be6", "f3", "Be7", "Qd2", "O-O"],
  ["e4", "e5", "Nf3", "Nc6", "Bc4", "Bc5", "c3", "Nf6", "d3", "d6", "O-O", "O-O", "Bb3", "a6", "Nbd2", "Be6", "Re1"],
  ["d4", "d5", "c4", "e6", "Nc3", "Nf6", "Nf3", "Be7", "Bf4", "O-O", "e3", "b6", "cxd5", "exd5", "Bd3", "Bb7", "O-O"],
  ["Nf3", "Nf6", "c4", "g6", "Nc3", "Bg7", "g3", "O-O", "Bg2", "d6", "O-O", "e5", "d3", "Nc6", "Rb1", "a5"],
  ["e4", "e6", "d4", "d5", "Nc3", "Nf6", "Bg5", "Be7", "e5", "Nfd7", "Bxe7", "Qxe7", "f4", "O-O", "Nf3", "c5"],
  ["e4", "c6", "d4", "d5", "Nc3", "dxe4", "Nxe4", "Bf5", "Ng3", "Bg6", "h4", "h6", "Nf3", "Nd7", "h5", "Bh7", "Bd3"],
  ["d4", "d5", "Nf3", "Nf6", "e3", "e6", "Bd3", "c5", "c3", "Nc6", "O-O", "Bd6", "Nbd2", "O-O", "dxc5", "Bxc5"],
  ["e4", "g6", "d4", "Bg7", "Nc3", "d6", "f4", "Nf6", "Nf3", "O-O", "Bd3", "Nc6", "O-O"],
  ["d4", "d5", "c4", "dxc4", "Nf3", "Nf6", "e3", "e6", "Bxc4", "c5", "O-O", "a6", "Qe2", "b5"],
  ["e4", "e5", "Nf3", "Nc6", "Bb5", "Nf6", "O-O", "Nxe4", "d4", "Nd6", "Bxc6", "dxc6", "dxe5", "Nf5", "Qxd8", "Kxd8"],
];

function playBook(minPly: number, maxPly: number, extra: number): { chess: Chess; ply: number } | null {
  const line = BOOKS[Math.floor(Math.random() * BOOKS.length)];
  if (!line) return null;
  const chess = new Chess();
  const target = Math.min(line.length, rand(minPly, Math.max(minPly, maxPly)));
  let ply = 0;
  for (const san of line) {
    if (ply >= target) break;
    const moved = chess.move(san);
    if (!moved) return null;
    ply += 1;
    if (chess.isCheckmate() || chess.isStalemate()) return null;
  }
  for (let i = 0; i < extra; i++) {
    const moves = chess.moves({ verbose: true }).filter((move) => {
      if (move.isCapture() || move.isPromotion()) return false;
      if (move.piece === "q") return false;
      if (move.piece === "k" && !move.isKingsideCastle() && !move.isQueensideCastle()) return false;
      return true;
    });
    if (moves.length === 0) break;
    const chosen = weighted(moves, (move) => scoreMove(move, ply, 0.2));
    chess.move({ from: chosen.from, to: chosen.to, promotion: chosen.promotion });
    ply += 1;
    if (chess.isCheckmate() || chess.isStalemate()) return null;
  }
  return { chess, ply };
}

function tryRemove(chess: Chess, square: Square): Chess | null {
  const next = new Chess(chess.fen());
  const piece = next.get(square);
  if (!piece || piece.type === "k") return null;
  next.remove(square);
  const fen = next.fen();
  if (!isLegalPosition(fen)) return null;
  return new Chess(fen);
}

function stripTo(chess: Chess, target: number): Chess | null {
  let current = chess;
  let guard = 48;
  while (inspect(current).total > target && guard > 0) {
    guard -= 1;
    const summary = inspect(current);
    if (summary.removable.length === 0) return null;
    let pool = summary.removable;
    if (summary.w > summary.b + 1) {
      const side = pool.filter((piece) => piece.color === "w");
      if (side.length > 0) pool = side;
    } else if (summary.b > summary.w + 1) {
      const side = pool.filter((piece) => piece.color === "b");
      if (side.length > 0) pool = side;
    }
    const order: PieceSymbol[] = ["q", "r", "n", "b", "p"];
    let chosen = pool;
    for (const type of order) {
      const ofType = pool.filter((piece) => piece.type === type);
      if (ofType.length > 0) {
        chosen = ofType;
        break;
      }
    }
    const pick = chosen[Math.floor(Math.random() * chosen.length)];
    if (!pick) return null;
    const removed = tryRemove(current, pick.sq);
    if (removed) {
      current = removed;
      continue;
    }
    let progressed = false;
    for (const candidate of shuffle(summary.removable)) {
      const alt = tryRemove(current, candidate.sq);
      if (!alt) continue;
      current = alt;
      progressed = true;
      break;
    }
    if (!progressed) return null;
  }
  return inspect(current).total <= target ? current : null;
}

function pack(chess: Chess, ply: number, source: GeneratedPosition["source"]): GeneratedPosition {
  return {
    fen: chess.fen(),
    ply,
    pieceCount: inspect(chess).total,
    turn: chess.turn(),
    source,
  };
}

function acceptable(chess: Chess, difficulty: Difficulty) {
  if (!isLegalPosition(chess.fen())) return false;
  if (chess.isCheckmate() || chess.isStalemate()) return false;
  const summary = inspect(chess);
  if (summary.wq > 1 || summary.bq > 1) return false;
  if (difficulty === "beginner") {
    return (
      summary.total >= 6 &&
      summary.total <= 10 &&
      summary.w >= 2 &&
      summary.b >= 2 &&
      !chess.inCheck()
    );
  }
  if (difficulty === "intermediate") {
    return (
      summary.total >= 24 &&
      summary.total <= 32 &&
      summary.w >= 10 &&
      summary.b >= 10 &&
      displacedCount(chess) >= 8
    );
  }
  return (
    summary.total >= 28 &&
    summary.w >= 13 &&
    summary.b >= 13 &&
    summary.wq >= 1 &&
    summary.bq >= 1 &&
    displacedCount(chess) >= 10
  );
}

function fallback(difficulty: Difficulty): GeneratedPosition {
  const choices = FALLBACKS[difficulty];
  const fen = choices[Math.floor(Math.random() * choices.length)] ?? choices[0] ?? SHOWCASE_FEN;
  return pack(new Chess(fen), 0, "fallback");
}

function generateOrFallback(difficulty: Difficulty): GeneratedPosition {
  for (let attempt = 0; attempt < 40; attempt++) {
    if (difficulty === "beginner") {
      const played = playBook(8, 14, 0);
      if (!played) continue;
      const stripped = stripTo(played.chess, rand(6, 9));
      if (!stripped || !acceptable(stripped, difficulty)) continue;
      return pack(stripped, played.ply, "played");
    }
    if (difficulty === "intermediate") {
      const played = playBook(10, 18, rand(0, 3));
      if (!played || !acceptable(played.chess, difficulty)) continue;
      return pack(played.chess, played.ply, "played");
    }
    const played = playBook(12, 19, rand(0, 2));
    if (!played || !acceptable(played.chess, difficulty)) continue;
    return pack(played.chess, played.ply, "played");
  }
  return fallback(difficulty);
}

export function generatePosition(difficulty: Difficulty): GeneratedPosition {
  try {
    return generateOrFallback(difficulty);
  } catch {
    return fallback(difficulty);
  }
}
