import { Chess } from "chess.js";

export interface EngineLine {
  multipv: number;
  depth: number;
  cp: number | null;
  mate: number | null;
  pvSan: string[];
  pvUci: string[];
}

const ENGINE_URL = "/engines/stockfish-19-lite-single.js";

function pvToSan(fen: string, uciMoves: string[]) {
  const chess = new Chess(fen);
  const sans: string[] = [];
  for (const uci of uciMoves.slice(0, 12)) {
    if (uci.length < 4) break;
    try {
      const move = chess.move({
        from: uci.slice(0, 2),
        to: uci.slice(2, 4),
        promotion: uci[4],
      });
      sans.push(move.san);
    } catch {
      break;
    }
  }
  return sans;
}

function parseInfo(line: string, fen: string): EngineLine | null {
  if (!line.startsWith("info ") || !line.includes(" pv ")) return null;
  if (line.includes(" lowerbound") || line.includes(" upperbound")) return null;
  const score = line.match(/\bscore (cp|mate) (-?\d+)/);
  if (!score) return null;
  const depth = Number(line.match(/\bdepth (\d+)/)?.[1] ?? 0);
  const multipv = Number(line.match(/\bmultipv (\d+)/)?.[1] ?? 1);
  const turn = fen.split(" ")[1] === "b" ? "b" : "w";
  const raw = Number(score[2]);
  let cp: number | null = null;
  let mate: number | null = null;
  if (score[1] === "mate") mate = turn === "w" ? raw : -raw;
  else cp = turn === "w" ? raw : -raw;
  const pvUci = line.split(" pv ")[1]?.trim().split(/\s+/) ?? [];
  return { multipv, depth, cp, mate, pvUci, pvSan: pvToSan(fen, pvUci) };
}

type Listener = (line: string) => void;

class UciEngine {
  private worker: Worker | null = null;
  private listeners = new Set<Listener>();
  private chain: Promise<unknown> = Promise.resolve();
  private searching = false;
  private infoFn: Listener | null = null;
  private startPromise: Promise<void> | null = null;
  eloMin = 1320;
  eloMax = 3190;
  failed = false;

  start() {
    if (this.startPromise) return this.startPromise;
    if (typeof Worker === "undefined") {
      this.failed = true;
      this.startPromise = Promise.reject(new Error("Workers are unavailable"));
      return this.startPromise;
    }
    const worker = new Worker(ENGINE_URL);
    this.worker = worker;
    worker.onmessage = (event: MessageEvent) => {
      const line = typeof event.data === "string" ? event.data : "";
      if (!line) return;
      if (line.startsWith("bestmove")) this.searching = false;
      for (const listener of [...this.listeners]) listener(line);
    };
    worker.onerror = () => {
      this.failed = true;
    };
    this.startPromise = this.enqueue(() => this.handshake()).catch((error) => {
      this.failed = true;
      throw error;
    });
    return this.startPromise;
  }

  interrupt() {
    this.clearInfo();
    if (this.worker && this.searching) this.send("stop");
  }

  bestMove(fen: string, opts: { elo: number; movetime: number }) {
    return this.enqueue(() => this.bestMoveJob(fen, opts));
  }

  evalOnce(fen: string, movetime: number) {
    return this.enqueue(() => this.evalJob(fen, movetime));
  }

  analyze(fen: string, onLines: (lines: EngineLine[]) => void) {
    return this.enqueue(() => this.analyzeJob(fen, onLines));
  }

  private enqueue<T>(job: () => Promise<T>) {
    const run = this.chain.then(job, job);
    this.chain = run.then(
      () => undefined,
      () => undefined,
    );
    return run;
  }

  private send(command: string) {
    this.worker?.postMessage(command);
  }

  private wait(test: (line: string) => boolean, ms: number) {
    return new Promise<string>((resolve, reject) => {
      const timer = setTimeout(() => {
        this.listeners.delete(listener);
        reject(new Error("Engine timed out"));
      }, ms);
      const listener: Listener = (line) => {
        if (!test(line)) return;
        clearTimeout(timer);
        this.listeners.delete(listener);
        resolve(line);
      };
      this.listeners.add(listener);
    });
  }

  private clearInfo() {
    if (!this.infoFn) return;
    this.listeners.delete(this.infoFn);
    this.infoFn = null;
  }

  private async handshake() {
    const ready = this.wait((line) => line === "readyok", 20000);
    const listen: Listener = (line) => {
      const match = line.match(/^option name UCI_Elo type spin default \d+ min (\d+) max (\d+)/);
      if (match) {
        this.eloMin = Number(match[1]);
        this.eloMax = Number(match[2]);
      }
      if (line === "uciok") {
        this.send("setoption name Hash value 16");
        this.send("isready");
      }
    };
    this.listeners.add(listen);
    this.send("uci");
    await ready;
    this.listeners.delete(listen);
  }

  private async stopSearch() {
    if (!this.searching) return;
    const pending = this.wait((line) => line.startsWith("bestmove"), 10000);
    this.send("stop");
    try {
      await pending;
    } catch {
      this.searching = false;
    }
    this.clearInfo();
  }

  private async ready() {
    this.send("isready");
    await this.wait((line) => line === "readyok", 8000);
  }

  private async configureStrength(elo: number | null) {
    const limited = elo != null && elo >= this.eloMin && elo <= this.eloMax;
    this.send(`setoption name UCI_LimitStrength value ${limited ? "true" : "false"}`);
    if (limited && elo != null) this.send(`setoption name UCI_Elo value ${Math.round(elo)}`);
    await this.ready();
  }

  private async bestMoveJob(fen: string, opts: { elo: number; movetime: number }) {
    this.clearInfo();
    await this.stopSearch();
    const limited = opts.elo >= this.eloMin && opts.elo <= this.eloMax ? opts.elo : null;
    await this.configureStrength(limited);
    this.send("setoption name MultiPV value 1");
    await this.ready();
    this.send(`position fen ${fen}`);
    this.searching = true;
    this.send(`go movetime ${opts.movetime}`);
    const line = await this.wait((row) => row.startsWith("bestmove"), opts.movetime + 15000);
    this.searching = false;
    const uci = line.split(/\s+/)[1];
    if (!uci || uci === "(none)") throw new Error("No move");
    return uci;
  }

  private async evalJob(fen: string, movetime: number) {
    this.clearInfo();
    await this.stopSearch();
    await this.configureStrength(null);
    this.send("setoption name MultiPV value 1");
    await this.ready();
    this.send(`position fen ${fen}`);
    const turn = fen.split(" ")[1] === "b" ? "b" : "w";
    let cp = 0;
    let mate: number | null = null;
    const listen: Listener = (line) => {
      const score = line.match(/\bscore (cp|mate) (-?\d+)/);
      if (!score || !line.startsWith("info ")) return;
      if (score[1] === "mate") mate = Number(score[2]);
      else {
        mate = null;
        cp = Number(score[2]);
      }
    };
    this.listeners.add(listen);
    this.searching = true;
    this.send(`go movetime ${movetime}`);
    const best = await this.wait((line) => line.startsWith("bestmove"), movetime + 12000);
    this.listeners.delete(listen);
    this.searching = false;
    const bestUci = best.split(/\s+/)[1];
    let whiteCp: number;
    if (mate != null) {
      const matePlies: number = mate;
      const sign = matePlies > 0 ? 1 : -1;
      const stm = sign * (100000 - Math.min(80, Math.abs(matePlies)) * 40);
      whiteCp = turn === "w" ? stm : -stm;
    } else {
      whiteCp = turn === "w" ? cp : -cp;
    }
    return {
      whiteCp,
      bestUci: bestUci && bestUci !== "(none)" ? bestUci : null,
    };
  }

  private async analyzeJob(fen: string, onLines: (lines: EngineLine[]) => void) {
    this.clearInfo();
    await this.stopSearch();
    await this.configureStrength(null);
    this.send("setoption name MultiPV value 3");
    await this.ready();
    this.send(`position fen ${fen}`);
    const bucket = new Map<number, EngineLine>();
    this.infoFn = (line) => {
      if (line.startsWith("bestmove")) {
        this.searching = false;
        this.clearInfo();
        return;
      }
      const parsed = parseInfo(line, fen);
      if (!parsed) return;
      bucket.set(parsed.multipv, parsed);
      onLines([...bucket.values()].sort((a, b) => a.multipv - b.multipv));
    };
    this.listeners.add(this.infoFn);
    this.searching = true;
    this.send("go depth 14 movetime 2200");
  }
}

export const engine = new UciEngine();

export function thinkMs(elo: number) {
  if (elo < 1600) return 280;
  if (elo < 2000) return 450;
  if (elo < 2400) return 700;
  if (elo < 2800) return 1000;
  if (elo < 3200) return 1400;
  if (elo < 3600) return 1800;
  return 2300;
}
