import { Chess, type Color, type PieceSymbol, type Square } from "chess.js";

export type BoardPiece = { color: Color; type: PieceSymbol };
export type BoardMap = Partial<Record<Square, BoardPiece>>;

export const FILES = ["a", "b", "c", "d", "e", "f", "g", "h"] as const;

const ROLE: Record<PieceSymbol, string> = {
  k: "king",
  q: "queen",
  r: "rook",
  b: "bishop",
  n: "knight",
  p: "pawn",
};

export function allSquares(): Square[] {
  const squares: Square[] = [];
  for (let rank = 8; rank >= 1; rank--) {
    for (const file of FILES) squares.push(`${file}${rank}` as Square);
  }
  return squares;
}

export function samePiece(a?: BoardPiece | null, b?: BoardPiece | null) {
  if (!a && !b) return true;
  if (!a || !b) return false;
  return a.color === b.color && a.type === b.type;
}

export function pieceName(piece: BoardPiece) {
  return `${piece.color === "w" ? "White" : "Black"} ${ROLE[piece.type]}`;
}

export function piecesFromChess(chess: Chess): BoardMap {
  const map: BoardMap = {};
  const board = chess.board();
  for (let rank = 0; rank < 8; rank++) {
    for (let file = 0; file < 8; file++) {
      const piece = board[rank]?.[file];
      if (!piece) continue;
      const square = `${FILES[file]}${8 - rank}` as Square;
      map[square] = { color: piece.color, type: piece.type };
    }
  }
  return map;
}

export function piecesFromFen(fen: string): BoardMap {
  return piecesFromChess(new Chess(fen));
}

export function isLightSquare(square: string) {
  const file = square.charCodeAt(0) - 97;
  const rank = Number(square[1]);
  return (file + rank) % 2 === 0;
}

/** A position is usable only if it can be loaded and the side not to move is not in check. */
export function isLegalPosition(fen: string): boolean {
  let chess: Chess;
  try {
    chess = new Chess(fen);
  } catch {
    return false;
  }
  const parts = chess.fen().split(" ");
  parts[1] = chess.turn() === "w" ? "b" : "w";
  parts[3] = "-";
  try {
    if (new Chess(parts.join(" ")).inCheck()) return false;
  } catch {
    return false;
  }
  const kings: Square[] = [];
  for (const square of allSquares()) {
    if (chess.get(square)?.type === "k") kings.push(square);
  }
  if (kings.length !== 2) return false;
  const [a, b] = kings;
  if (!a || !b) return false;
  const fileGap = Math.abs(a.charCodeAt(0) - b.charCodeAt(0));
  const rankGap = Math.abs(Number(a[1]) - Number(b[1]));
  return fileGap > 1 || rankGap > 1;
}

export type MistakeKind = "missing" | "wrong" | "extra";

export type Mistake = {
  square: Square;
  kind: MistakeKind;
  expected: BoardPiece | null;
  actual: BoardPiece | null;
};

export type Score = {
  correct: number;
  missing: number;
  incorrect: number;
  extras: number;
  total: number;
  accuracy: number;
  correctSquares: Square[];
  mistakes: Mistake[];
};

export function scorePosition(expected: BoardMap, actual: BoardMap): Score {
  let correct = 0;
  let missing = 0;
  let wrong = 0;
  let extras = 0;
  let total = 0;
  const correctSquares: Square[] = [];
  const mistakes: Mistake[] = [];

  for (const square of allSquares()) {
    const want = expected[square] ?? null;
    const got = actual[square] ?? null;
    if (want) total += 1;
    if (samePiece(want, got)) {
      if (want) {
        correct += 1;
        correctSquares.push(square);
      }
      continue;
    }
    if (want && !got) {
      missing += 1;
      mistakes.push({ square, kind: "missing", expected: want, actual: null });
    } else if (want && got) {
      wrong += 1;
      mistakes.push({ square, kind: "wrong", expected: want, actual: got });
    } else if (got) {
      extras += 1;
      mistakes.push({ square, kind: "extra", expected: null, actual: got });
    }
  }

  const accuracy =
    total === 0 ? 0 : Math.max(0, Math.round((correct / (total + extras)) * 100));

  return {
    correct,
    missing,
    incorrect: wrong + extras,
    extras,
    total,
    accuracy,
    correctSquares,
    mistakes,
  };
}

export function formatClock(ms: number) {
  const safe = Math.max(0, ms);
  const totalSeconds = safe / 1000;
  if (totalSeconds < 60) return `${totalSeconds.toFixed(1)}s`;
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = Math.floor(totalSeconds % 60);
  return `${minutes}:${String(seconds).padStart(2, "0")}`;
}
