import { Chess, DEFAULT_POSITION, type Color, type PieceSymbol, type Square } from "chess.js";
import { create } from "zustand";
import { classify, buildPgn, resultOf, type Mark } from "@/lib/chess/format";
import { playMoveSound, unlockAudio } from "@/lib/chess/sound";
import { engine, thinkMs, type EngineLine } from "@/lib/chess/uci";
import { thinkDelay, weakUci } from "@/lib/chess/weak";

const STORAGE_KEY = "halden.v1";

export interface Ann {
  mark: Mark;
  loss: number;
  bestSan?: string;
}

export interface SavedGame {
  id: string;
  at: number;
  pgn: string;
  label: string;
}

interface Persist {
  botElo: number;
  player: Color;
  hints: boolean;
  archive: SavedGame[];
}

export interface StudioState {
  mode: "play" | "review";
  startFen: string;
  sans: string[];
  fens: string[];
  cursor: number;
  player: Color;
  botElo: number;
  orientation: Color;
  over: boolean;
  result: string | null;
  anns: (Ann | null)[];
  reviewing: boolean;
  reviewIndex: number;
  hints: boolean;
  thinking: boolean;
  engineReady: boolean;
  engineError: string | null;
  lines: EngineLine[];
  selected: Square | null;
  promo: { from: Square; to: Square } | null;
  archive: SavedGame[];
  notationError: string | null;
  boot: () => void;
  onPosition: () => void;
  newGame: (player?: Color) => void;
  setElo: (elo: number) => void;
  flip: () => void;
  step: (delta: number) => void;
  goto: (cursor: number) => void;
  takeback: () => void;
  resign: () => void;
  setHints: (hints: boolean) => void;
  setMode: (mode: "play" | "review") => void;
  handleSquare: (square: Square) => void;
  tryMove: (from: Square, to: Square, promotion?: PieceSymbol) => void;
  choosePromotion: (piece: PieceSymbol) => void;
  cancelPromo: () => void;
  loadNotation: (text: string) => void;
  reviewGame: () => void;
  cancelReview: () => void;
  playFromHere: () => void;
  saveCurrent: () => void;
}

let botGen = 0;
let reviewGen = 0;
let activeFen: string | null = null;
let booted = false;
let lastSaved = "";

function readPersist(): Partial<Persist> {
  if (typeof window === "undefined") return {};
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    const data = JSON.parse(raw) as Partial<Persist>;
    return data ?? {};
  } catch {
    return {};
  }
}

function writePersist(state: StudioState) {
  if (typeof window === "undefined") return;
  const data: Persist = {
    botElo: state.botElo,
    player: state.player,
    hints: state.hints,
    archive: state.archive.slice(0, 20),
  };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

function canHuman(state: StudioState) {
  if (state.thinking || state.reviewing || state.promo) return false;
  const chess = new Chess(state.fens[state.cursor]);
  if (chess.isGameOver()) return false;
  if (state.mode === "play") {
    if (state.over) return false;
    if (state.cursor !== state.fens.length - 1) return false;
    if (chess.turn() !== state.player) return false;
  }
  return true;
}

async function chooseUci(fen: string, elo: number, engineReady: boolean) {
  const floor = engine.eloMin;
  if (elo >= floor && !engine.failed) {
    try {
      if (!engineReady) await engine.start();
      if (!engine.failed) return await engine.bestMove(fen, { elo, movetime: thinkMs(elo) });
    } catch {
      return weakUci(fen, Math.min(elo, 1800));
    }
  }
  const started = performance.now();
  const uci = weakUci(fen, elo);
  const wait = thinkDelay(elo) - (performance.now() - started);
  if (wait > 0) await new Promise((resolve) => setTimeout(resolve, wait));
  return uci;
}

export const useStudio = create<StudioState>((set, get) => ({
  mode: "play",
  startFen: DEFAULT_POSITION,
  sans: [],
  fens: [DEFAULT_POSITION],
  cursor: 0,
  player: "w",
  botElo: 1400,
  orientation: "w",
  over: false,
  result: null,
  anns: [],
  reviewing: false,
  reviewIndex: 0,
  hints: false,
  thinking: false,
  engineReady: false,
  engineError: null,
  lines: [],
  selected: null,
  promo: null,
  archive: [],
  notationError: null,

  boot: () => {
    if (booted) return;
    booted = true;
    const saved = readPersist();
    const player = saved.player === "b" ? "b" : "w";
    const botElo =
      typeof saved.botElo === "number" ? Math.max(100, Math.min(4000, Math.round(saved.botElo))) : 1400;
    set({
      player,
      orientation: player,
      botElo,
      hints: Boolean(saved.hints),
      archive: Array.isArray(saved.archive) ? saved.archive.slice(0, 20) : [],
    });
    void engine
      .start()
      .then(() => {
        if (!engine.failed) set({ engineReady: true });
        else set({ engineError: "Stockfish did not start. Opponents use the built-in player." });
      })
      .catch(() => {
        set({ engineError: "Stockfish did not start. Opponents use the built-in player." });
      });
  },

  onPosition: () => {
    const state = get();
    const chess = new Chess(state.fens[state.cursor]);
    const botTurn =
      state.mode === "play" &&
      !state.over &&
      !state.reviewing &&
      state.cursor === state.fens.length - 1 &&
      !chess.isGameOver() &&
      chess.turn() !== state.player;
    if (botTurn) {
      if (!state.thinking) void requestBot();
      return;
    }
    if (!state.thinking) syncEngine();
  },

  newGame: (player) => {
    const state = get();
    saveIfNeeded(state);
    botGen += 1;
    reviewGen += 1;
    activeFen = null;
    engine.interrupt();
    const side = player ?? state.player;
    set({
      mode: "play",
      player: side,
      orientation: side,
      startFen: DEFAULT_POSITION,
      sans: [],
      fens: [DEFAULT_POSITION],
      cursor: 0,
      over: false,
      result: null,
      anns: [],
      reviewing: false,
      thinking: false,
      lines: [],
      selected: null,
      promo: null,
      notationError: null,
    });
  },

  setElo: (elo) => set({ botElo: Math.max(100, Math.min(4000, Math.round(elo))) }),

  flip: () => set((state) => ({ orientation: state.orientation === "w" ? "b" : "w" })),

  step: (delta) => {
    const state = get();
    const next = Math.max(0, Math.min(state.fens.length - 1, state.cursor + delta));
    set({ cursor: next, selected: null, promo: null });
  },

  goto: (cursor) => {
    const state = get();
    set({
      cursor: Math.max(0, Math.min(state.fens.length - 1, cursor)),
      selected: null,
      promo: null,
    });
  },

  takeback: () => {
    const state = get();
    botGen += 1;
    engine.interrupt();
    if (state.mode !== "play") {
      set({
        cursor: Math.max(0, state.cursor - 1),
        thinking: false,
        selected: null,
        promo: null,
      });
      return;
    }
    const tip = new Chess(state.fens[state.fens.length - 1]);
    const drop = tip.turn() === state.player ? Math.min(2, state.sans.length) : Math.min(1, state.sans.length);
    const sans = state.sans.slice(0, state.sans.length - drop);
    const fens = state.fens.slice(0, sans.length + 1);
    set({
      sans,
      fens,
      cursor: sans.length,
      over: false,
      result: null,
      anns: [],
      thinking: false,
      selected: null,
      promo: null,
      lines: [],
    });
    activeFen = null;
  },

  resign: () => {
    const state = get();
    if (state.mode !== "play" || state.over || state.sans.length === 0) return;
    botGen += 1;
    engine.interrupt();
    const winner = state.player === "w" ? "Black" : "White";
    set({ over: true, result: `Resigned · ${winner} wins`, thinking: false, selected: null, promo: null });
    saveIfNeeded(get());
  },

  setHints: (hints) => {
    activeFen = null;
    set({ hints, lines: hints ? get().lines : [] });
  },

  setMode: (mode) => {
    if (mode === get().mode) return;
    botGen += 1;
    reviewGen += 1;
    activeFen = null;
    engine.interrupt();
    set({ mode, thinking: false, reviewing: false, selected: null, promo: null, lines: [] });
  },

  handleSquare: (square) => {
    unlockAudio();
    const state = get();
    if (!canHuman(state)) return;
    const chess = new Chess(state.fens[state.cursor]);
    if (state.selected) {
      const hits = chess.moves({ square: state.selected, verbose: true }).some((move) => move.to === square);
      if (hits) {
        get().tryMove(state.selected, square);
        return;
      }
    }
    const piece = chess.get(square);
    if (piece && piece.color === chess.turn()) set({ selected: square });
    else set({ selected: null });
  },

  tryMove: (from, to, promotion) => {
    unlockAudio();
    const state = get();
    if (!canHuman(state)) return;
    const chess = new Chess(state.fens[state.cursor]);
    const moves = chess.moves({ square: from, verbose: true }).filter((move) => move.to === to);
    if (!moves.length) {
      set({ selected: null });
      return;
    }
    if (moves.some((move) => move.promotion) && !promotion) {
      set({ promo: { from, to }, selected: null });
      return;
    }
    const chosen = promotion ? (moves.find((move) => move.promotion === promotion) ?? moves[0]) : moves[0];
    commitSan(chosen.san);
  },

  choosePromotion: (piece) => {
    const promo = get().promo;
    if (!promo) return;
    set({ promo: null });
    get().tryMove(promo.from, promo.to, piece);
  },

  cancelPromo: () => set({ promo: null }),

  loadNotation: (text) => {
    const trimmed = text.trim();
    if (!trimmed) {
      set({ notationError: "Paste a PGN or a FEN first." });
      return;
    }
    botGen += 1;
    reviewGen += 1;
    activeFen = null;
    engine.interrupt();
    try {
      const looksLikeFen = trimmed.includes("/") && !trimmed.startsWith("[") && !/\d+\./.test(trimmed);
      if (looksLikeFen) {
        const chess = new Chess(trimmed);
        const fen = chess.fen();
        const over = chess.isGameOver();
        set({
          mode: "review",
          startFen: fen,
          sans: [],
          fens: [fen],
          cursor: 0,
          over,
          result: over ? resultOf(chess).text : null,
          anns: [],
          reviewing: false,
          thinking: false,
          lines: [],
          selected: null,
          promo: null,
          notationError: null,
        });
        return;
      }
      const chess = new Chess();
      chess.loadPgn(trimmed, { strict: false });
      const headers = chess.getHeaders();
      const startFen = headers.SetUp === "1" && headers.FEN ? headers.FEN : DEFAULT_POSITION;
      const sans = chess.history();
      const replay = startFen === DEFAULT_POSITION ? new Chess() : new Chess(startFen);
      const fens = [replay.fen()];
      for (const san of sans) {
        replay.move(san);
        fens.push(replay.fen());
      }
      const over = replay.isGameOver();
      set({
        mode: "review",
        startFen: fens[0],
        sans,
        fens,
        cursor: fens.length - 1,
        over,
        result: over ? resultOf(replay).text : headers.Result && headers.Result !== "*" ? headers.Result : null,
        anns: [],
        reviewing: false,
        thinking: false,
        lines: [],
        selected: null,
        promo: null,
        notationError: null,
        player: replay.turn(),
        orientation: replay.turn(),
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Could not read that notation.";
      set({ notationError: message });
    }
  },

  reviewGame: () => {
    const state = get();
    if (!state.sans.length || state.reviewing || !state.engineReady || engine.failed) return;
    reviewGen += 1;
    const gen = reviewGen;
    botGen += 1;
    activeFen = null;
    engine.interrupt();
    set({
      mode: "review",
      reviewing: true,
      reviewIndex: 0,
      anns: [],
      thinking: false,
      lines: [],
      selected: null,
      promo: null,
    });
    void runReview(gen);
  },

  cancelReview: () => {
    reviewGen += 1;
    set({ reviewing: false });
  },

  playFromHere: () => {
    const state = get();
    const fen = state.fens[state.cursor];
    const chess = new Chess(fen);
    botGen += 1;
    reviewGen += 1;
    activeFen = null;
    engine.interrupt();
    const over = chess.isGameOver();
    set({
      mode: "play",
      startFen: fen,
      sans: [],
      fens: [fen],
      cursor: 0,
      over,
      result: over ? resultOf(chess).text : null,
      anns: [],
      reviewing: false,
      thinking: false,
      lines: [],
      selected: null,
      promo: null,
      orientation: state.player,
    });
  },

  saveCurrent: () => saveIfNeeded(get(), true),
}));

function commitSan(san: string) {
  const state = useStudio.getState();
  const chess = new Chess(state.fens[state.cursor]);
  let move;
  try {
    move = chess.move(san);
  } catch {
    return;
  }
  const sans = state.sans.slice(0, state.cursor).concat(move.san);
  const fens = state.fens.slice(0, state.cursor + 1).concat(chess.fen());
  const over = chess.isGameOver();
  const result = over ? resultOf(chess).text : null;
  const kind = chess.inCheck() ? "check" : move.isCapture() ? "capture" : "move";
  playMoveSound(kind);
  activeFen = null;
  useStudio.setState({
    sans,
    fens,
    cursor: fens.length - 1,
    over: state.mode === "play" ? over : over,
    result,
    anns: [],
    selected: null,
    promo: null,
    lines: [],
  });
  if (over && state.mode === "play") saveIfNeeded(useStudio.getState());
}

async function requestBot() {
  const state = useStudio.getState();
  const fen = state.fens[state.cursor];
  const gen = ++botGen;
  activeFen = null;
  engine.interrupt();
  useStudio.setState({ thinking: true, lines: [], selected: null, promo: null });
  try {
    const uci = await chooseUci(fen, state.botElo, useStudio.getState().engineReady);
    if (gen !== botGen) return;
    if (useStudio.getState().fens[useStudio.getState().cursor] !== fen) return;
    const chess = new Chess(fen);
    const move = chess.move({
      from: uci.slice(0, 2),
      to: uci.slice(2, 4),
      promotion: uci[4] as PieceSymbol | undefined,
    });
    commitSan(move.san);
  } catch {
    /* leave the position if the engine has nothing */
  } finally {
    if (gen === botGen) useStudio.setState({ thinking: false });
  }
}

function syncEngine() {
  const state = useStudio.getState();
  if (state.reviewing || state.thinking || !state.engineReady || engine.failed) return;
  const fen = state.fens[state.cursor];
  const chess = new Chess(fen);
  const want =
    state.mode === "review" ||
    (state.hints &&
      state.mode === "play" &&
      !state.over &&
      state.cursor === state.fens.length - 1 &&
      chess.turn() === state.player);
  if (!want) {
    if (activeFen) {
      activeFen = null;
      engine.interrupt();
      useStudio.setState({ lines: [] });
    }
    return;
  }
  if (activeFen === fen) return;
  activeFen = fen;
  const token = fen;
  void engine.analyze(fen, (lines) => {
    if (activeFen !== token) return;
    if (useStudio.getState().fens[useStudio.getState().cursor] !== token) return;
    useStudio.setState({ lines });
  });
}

async function runReview(gen: number) {
  const state = useStudio.getState();
  const anns: (Ann | null)[] = [];
  const chess = state.startFen === DEFAULT_POSITION ? new Chess() : new Chess(state.startFen);
  for (let i = 0; i < state.sans.length; i += 1) {
    if (gen !== reviewGen) return;
    useStudio.setState({ reviewIndex: i + 1, cursor: i });
    let before: { whiteCp: number; bestUci: string | null };
    try {
      before = await engine.evalOnce(chess.fen(), 170);
    } catch {
      anns.push(null);
      try {
        chess.move(state.sans[i]);
      } catch {
        break;
      }
      continue;
    }
    if (gen !== reviewGen) return;
    let bestSan: string | undefined;
    if (before.bestUci && before.bestUci.length >= 4) {
      const probe = new Chess(chess.fen());
      try {
        bestSan = probe.move({
          from: before.bestUci.slice(0, 2),
          to: before.bestUci.slice(2, 4),
          promotion: before.bestUci[4],
        }).san;
      } catch {
        bestSan = undefined;
      }
    }
    const mover = chess.turn();
    const beforeWhite = before.whiteCp;
    let played;
    try {
      played = chess.move(state.sans[i]);
    } catch {
      break;
    }
    let afterWhite = beforeWhite;
    try {
      const after = await engine.evalOnce(chess.fen(), 120);
      afterWhite = after.whiteCp;
    } catch {
      afterWhite = beforeWhite;
    }
    if (gen !== reviewGen) return;
    const loss = Math.max(0, mover === "w" ? beforeWhite - afterWhite : afterWhite - beforeWhite);
    anns.push({
      mark: classify(loss, bestSan === played.san),
      loss,
      bestSan,
    });
    useStudio.setState({ anns: [...anns], cursor: i + 1 });
  }
  if (gen !== reviewGen) return;
  useStudio.setState({
    reviewing: false,
    cursor: useStudio.getState().fens.length - 1,
  });
}

function saveIfNeeded(state: StudioState, force = false) {
  if (!state.sans.length && state.startFen === DEFAULT_POSITION) return;
  let pgn = "";
  try {
    pgn = buildPgn({
      startFen: state.startFen,
      sans: state.sans,
      player: state.player,
      botElo: state.botElo,
      result: state.result,
    });
  } catch {
    return;
  }
  if (!force && pgn === lastSaved) return;
  lastSaved = pgn;
  const label = `${state.sans.length} plies${state.result ? ` · ${state.result}` : ""}`;
  const entry: SavedGame = {
    id: `${Date.now()}`,
    at: Date.now(),
    pgn,
    label,
  };
  useStudio.setState({ archive: [entry, ...useStudio.getState().archive].slice(0, 20) });
}

if (typeof window !== "undefined") {
  useStudio.subscribe((state, prev) => {
    if (
      state.botElo !== prev.botElo ||
      state.player !== prev.player ||
      state.hints !== prev.hints ||
      state.archive !== prev.archive
    ) {
      writePersist(state);
    }
  });
}
