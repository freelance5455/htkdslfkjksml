export type SimSample = {
  app: string;
  domain: string;
  proto: "HTTPS" | "DNS" | "TCP" | "UDP";
  bytes: number;
  weight: number;
};

export const BASELINE_TRAFFIC: SimSample[] = [
  { app: "WhatsApp", domain: "g.whatsapp.net", proto: "HTTPS", bytes: 8400, weight: 8 },
  { app: "WhatsApp", domain: "whatsapp.com", proto: "DNS", bytes: 120, weight: 4 },
  { app: "Chrome", domain: "google.de", proto: "HTTPS", bytes: 22000, weight: 6 },
  { app: "Chrome", domain: "www.google.com", proto: "DNS", bytes: 180, weight: 5 },
  { app: "Instagram", domain: "instagram.com", proto: "HTTPS", bytes: 54000, weight: 4 },
  { app: "System", domain: "connectivitycheck.gstatic.com", proto: "HTTPS", bytes: 640, weight: 3 },
  { app: "Telekom", domain: "telekom.de", proto: "HTTPS", bytes: 4100, weight: 2 },
  { app: "Gmail", domain: "gmail.com", proto: "HTTPS", bytes: 12000, weight: 3 },
  { app: "Spotify", domain: "spotify.com", proto: "HTTPS", bytes: 180000, weight: 2 },
  { app: "Play Store", domain: "play.google.com", proto: "HTTPS", bytes: 9300, weight: 2 },
  { app: "Clock", domain: "time.android.com", proto: "UDP", bytes: 96, weight: 2 },
  { app: "Maps", domain: "maps.google.com", proto: "HTTPS", bytes: 28000, weight: 2 },
  { app: "Outlook", domain: "outlook.office.com", proto: "HTTPS", bytes: 16000, weight: 1 },
  { app: "DHL", domain: "dhl.de", proto: "HTTPS", bytes: 7200, weight: 1 },
  { app: "System", domain: "dns.google", proto: "DNS", bytes: 84, weight: 3 },
];

export const ATTACK_SAMPLES: SimSample[] = [
  { app: "Chrome", domain: "sparkasse-login-check.tk", proto: "HTTPS", bytes: 2400, weight: 1 },
  { app: "SMS-Link", domain: "dhl-paket-sendung.net", proto: "HTTPS", bytes: 1800, weight: 1 },
  { app: "Chrome", domain: "paypal-konto-update.com", proto: "HTTPS", bytes: 3100, weight: 1 },
  { app: "Mail", domain: "appleid-verify-login.com", proto: "HTTPS", bytes: 1500, weight: 1 },
  { app: "Chrome", domain: "telekom-kundencenter.xyz", proto: "HTTPS", bytes: 2100, weight: 1 },
  { app: "WhatsApp", domain: "elster-steuerauskunft.click", proto: "HTTPS", bytes: 900, weight: 1 },
  { app: "Chrome", domain: "secure-paypal-de.net", proto: "HTTPS", bytes: 2600, weight: 1 },
];

function pickWeighted(list: SimSample[]): SimSample {
  const sum = list.reduce((a, b) => a + b.weight, 0);
  let r = Math.random() * sum;
  for (const item of list) {
    r -= item.weight;
    if (r <= 0) return item;
  }
  return list[0]!;
}

export function nextBaseline(): SimSample {
  const s = pickWeighted(BASELINE_TRAFFIC);
  const jitter = 0.6 + Math.random() * 0.8;
  return { ...s, bytes: Math.round(s.bytes * jitter) };
}

export function nextAttack(): SimSample {
  return ATTACK_SAMPLES[Math.floor(Math.random() * ATTACK_SAMPLES.length)]!;
}
