export const DEFAULT_TITLE = "WordPad Features";

export const DEFAULT_HTML = `<h1>WordPad Features</h1>
<p class="lede">A school-friendly map of every main WordPad command. Edit this page, then tap Convert to Link to share it as a URL.</p>
<h2>File</h2>
<ol>
<li><strong>New</strong> — Creates a new document.</li>
<li><strong>Open</strong> — Opens an existing document.</li>
<li><strong>Save</strong> — Saves the document.</li>
<li><strong>Save As</strong> — Saves the document with a new name or location.</li>
<li><strong>Print</strong> — Prints the document.</li>
<li><strong>Print Preview</strong> — Shows how the document will look when printed.</li>
</ol>
<h2>Clipboard and editing</h2>
<ol start="7">
<li><strong>Cut</strong> — Removes selected text and places it on the clipboard.</li>
<li><strong>Copy</strong> — Copies selected text to the clipboard.</li>
<li><strong>Paste</strong> — Inserts copied or cut text.</li>
<li><strong>Undo</strong> — Reverses the last action.</li>
<li><strong>Redo</strong> — Restores an action that was undone.</li>
</ol>
<h2>Font and paragraph</h2>
<ol start="12">
<li><strong>Font</strong> — Changes the typeface of text.</li>
<li><strong>Font Size</strong> — Changes the size of text.</li>
<li><strong>Bold</strong> — Makes text darker and thicker.</li>
<li><strong>Italic</strong> — Slants the text.</li>
<li><strong>Underline</strong> — Places a line below text.</li>
<li><strong>Text Color</strong> — Changes the color of text.</li>
<li><strong>Text Highlighting</strong> — Highlights text.</li>
<li><strong>Text Alignment</strong> — Aligns text to the left, center, or right.</li>
<li><strong>Bullets</strong> — Creates a bulleted list.</li>
<li><strong>Line Spacing</strong> — Adjusts the space between lines.</li>
</ol>
<h2>Insert and view</h2>
<ol start="22">
<li><strong>Insert Picture</strong> — Adds a picture to the document.</li>
<li><strong>Insert Date and Time</strong> — Inserts the current date and/or time.</li>
<li><strong>Find</strong> — Searches for specific words or text.</li>
<li><strong>Page Setup</strong> — Sets paper size, margins, and page orientation.</li>
<li><strong>Zoom</strong> — Makes the document appear larger or smaller on screen.</li>
</ol>
<h2>File formats</h2>
<ul>
<li><strong>RTF</strong> — Rich Text Format</li>
<li><strong>TXT</strong> — Plain text</li>
<li><strong>DOCX</strong> — Word document (on some versions)</li>
<li><strong>ODT</strong> — OpenDocument Text (on some versions)</li>
</ul>
<p>Microsoft removed WordPad from Windows 11 version 24H2 and later, so newer Windows installations may not have it. PadLink keeps the same tools in the browser — including PNG, PDF, and a shareable link.</p>
<h2>Parts of the window</h2>
<ul>
<li><strong>Title bar</strong> — Shows the document name.</li>
<li><strong>Quick Access toolbar</strong> — New, Open, Save, Undo, Redo.</li>
<li><strong>Ribbon</strong> — Home and View commands.</li>
<li><strong>Home tab</strong> — Clipboard, font, paragraph, and insert tools.</li>
<li><strong>View tab</strong> — Zoom, word wrap, and ruler.</li>
<li><strong>Ruler</strong> — Margins and indents.</li>
<li><strong>Document area</strong> — Where you type.</li>
<li><strong>Status bar</strong> — Zoom and document info.</li>
</ul>`;

export const WINDOW_PARTS: { name: string; role: string }[] = [
  { name: "Title bar", role: "Shows the document name and window controls." },
  { name: "Quick Access", role: "New, Open, Save, Undo, and Redo sit here for one-tap use." },
  { name: "Ribbon", role: "The command strip. Home holds writing tools; View holds zoom." },
  { name: "Home tab", role: "Clipboard, font, paragraph, and insert groups." },
  { name: "View tab", role: "Zoom, word wrap, and ruler." },
  { name: "Ruler", role: "Sets left and right margins on the page." },
  { name: "Document area", role: "The page where you type, format, and drop pictures." },
  { name: "Status bar", role: "Word count, save state, and zoom." },
];

export const FONTS = [
  "Source Serif 4",
  "Georgia",
  "Times New Roman",
  "Instrument Sans",
  "Arial",
  "Calibri",
  "Verdana",
  "Courier New",
];

export const FONT_SIZES = ["12", "14", "16", "18", "20", "24", "32", "40"];

export const INK_COLORS = [
  { name: "Ink", value: "#1c1917" },
  { name: "Navy", value: "#1e3a5f" },
  { name: "Forest", value: "#2f5d4e" },
  { name: "Brick", value: "#9b3d32" },
  { name: "Sepia", value: "#5c4d3c" },
  { name: "Cream", value: "#faf8f5" },
];

export const HIGHLIGHTS = [
  { name: "Sage", value: "#dce8e2" },
  { name: "Sky", value: "#d4e0ea" },
  { name: "Rose", value: "#edd8d6" },
  { name: "Sand", value: "#efe6d2" },
  { name: "Linen", value: "#e7e0d4" },
  { name: "Clear", value: "transparent" },
];

export const SPACING = [
  { name: "1.0", value: "1.15" },
  { name: "1.15", value: "1.3" },
  { name: "1.5", value: "1.5" },
  { name: "2.0", value: "2" },
];
