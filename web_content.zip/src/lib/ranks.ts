/* The ladder of minds. Titles are not ranks of skill — they are
   classifications of cognition. */

export interface MindTitle {
  min: number;
  title: string;
  epithet: string;
  cls: string; // historical class comparison
}

export const TITLES: MindTitle[] = [
  { min: 0, title: "The Unformed", epithet: "Raw ore entering the crucible", cls: "" },
  { min: 60, title: "Awakening", epithet: "First cracks in the ceiling", cls: "Novice Class" },
  { min: 130, title: "Adept", epithet: "Patterns begin to obey", cls: "Apprentice Class" },
  { min: 220, title: "Scholar of Chaos", epithet: "Order extracted from noise", cls: "Scholar Class" },
  { min: 320, title: "Patternbinder", epithet: "Structure is your playground", cls: "Mendel Class" },
  { min: 430, title: "Polymath", epithet: "Domains fuse into weaponry", cls: "Curie Class" },
  { min: 550, title: "Mastermind", epithet: "Thought ten moves deep", cls: "Turing Class" },
  { min: 680, title: "Grand Visionary", epithet: "Imagination made tangible", cls: "Feynman Class" },
  { min: 820, title: "Crucible Sovereign", epithet: "The chamber answers to you", cls: "Einstein Class" },
  { min: 980, title: "Apex Mind", epithet: "Cognition beyond taxonomy", cls: "Da Vinci Class" },
];

export function titleFor(mindIndex: number): MindTitle {
  let current = TITLES[0];
  for (const t of TITLES) if (mindIndex >= t.min) current = t;
  return current;
}

export function nextTitle(mindIndex: number): MindTitle | null {
  for (const t of TITLES) if (mindIndex < t.min) return t;
  return null;
}

/* Historical benchmark entities seeded into the Hall — fixed poles
   for mortal minds to measure themselves against. */
export const BENCHMARKS: {
  alias: string;
  c: number; i: number; p: number;
  ring: number;
}[] = [
  { alias: "Benchmark — Leonardo", c: 985, i: 960, p: 940, ring: 25 },
  { alias: "Benchmark — Tesla", c: 930, i: 990, p: 900, ring: 24 },
  { alias: "Benchmark — Einstein", c: 910, i: 985, p: 935, ring: 24 },
  { alias: "Benchmark — Curie", c: 850, i: 905, p: 960, ring: 22 },
  { alias: "Benchmark — Turing", c: 865, i: 870, p: 985, ring: 23 },
  { alias: "Benchmark — Feynman", c: 940, i: 945, p: 915, ring: 22 },
  { alias: "Benchmark — Hypatia", c: 880, i: 860, p: 930, ring: 20 },
  { alias: "Benchmark — Ramanujan", c: 830, i: 915, p: 990, ring: 21 },
];
