"use client";

import { useEffect, useState } from "react";

const SYNC_EVENT = "lia:local-state";

/**
 * useState backed by localStorage.
 * - Starts with `initial` on the server and the first client render (no hydration mismatch),
 *   then loads the saved value after mount and persists every change.
 * - Every instance using the same key stays in sync (e.g. a progress badge updates
 *   when a lesson is ticked elsewhere on the page), and across browser tabs.
 */
export function useLocalState<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(initial);
  const [ready, setReady] = useState(false);

  // Load after mount.
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(key);
      if (raw !== null) {
        setValue(JSON.parse(raw) as T);
      }
    } catch {
      // Corrupted or unavailable storage: keep the initial value.
    }
    setReady(true);
  }, [key]);

  // Listen for updates from other instances / tabs.
  useEffect(() => {
    const readFromStorage = () => {
      try {
        const raw = window.localStorage.getItem(key);
        if (raw === null) return;
        setValue((prev) => (JSON.stringify(prev) === raw ? prev : (JSON.parse(raw) as T)));
      } catch {
        // ignore
      }
    };
    const onCustom = (e: Event) => {
      if ((e as CustomEvent<string>).detail === key) readFromStorage();
    };
    const onStorage = (e: StorageEvent) => {
      if (e.key === key) readFromStorage();
    };
    window.addEventListener(SYNC_EVENT, onCustom);
    window.addEventListener("storage", onStorage);
    return () => {
      window.removeEventListener(SYNC_EVENT, onCustom);
      window.removeEventListener("storage", onStorage);
    };
  }, [key]);

  // Persist + notify other instances.
  useEffect(() => {
    if (!ready) return;
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
      window.dispatchEvent(new CustomEvent(SYNC_EVENT, { detail: key }));
    } catch {
      // Storage may be full or disabled (private mode); ignore.
    }
  }, [key, value, ready]);

  return [value, setValue, ready] as const;
}
