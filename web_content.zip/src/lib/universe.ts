export type CoinMeta = {
  symbol: string; // BTCUSDT
  base: string; // BTC
  name: string;
  hebrewName: string;
  sector: string; // סקטור למפת חום
  cgId: string; // CoinGecko id
};

export const COIN_UNIVERSE: CoinMeta[] = [
  { symbol: "BTCUSDT", base: "BTC", name: "Bitcoin", hebrewName: "ביטקוין", sector: "מטבעות ליבה", cgId: "bitcoin" },
  { symbol: "ETHUSDT", base: "ETH", name: "Ethereum", hebrewName: "את'ריום", sector: "מטבעות ליבה", cgId: "ethereum" },
  { symbol: "BNBUSDT", base: "BNB", name: "BNB", hebrewName: "בי-אן-בי", sector: "בורסות", cgId: "binancecoin" },
  { symbol: "SOLUSDT", base: "SOL", name: "Solana", hebrewName: "סולנה", sector: "שכבה 1", cgId: "solana" },
  { symbol: "XRPUSDT", base: "XRP", name: "XRP", hebrewName: "ריפל", sector: "תשלומים", cgId: "ripple" },
  { symbol: "ADAUSDT", base: "ADA", name: "Cardano", hebrewName: "קרדנו", sector: "שכבה 1", cgId: "cardano" },
  { symbol: "AVAXUSDT", base: "AVAX", name: "Avalanche", hebrewName: "אוולנץ'", sector: "שכבה 1", cgId: "avalanche-2" },
  { symbol: "DOTUSDT", base: "DOT", name: "Polkadot", hebrewName: "פולקדוט", sector: "תשתיות", cgId: "polkadot" },
  { symbol: "TRXUSDT", base: "TRX", name: "TRON", hebrewName: "טרון", sector: "שכבה 1", cgId: "tron" },
  { symbol: "LINKUSDT", base: "LINK", name: "Chainlink", hebrewName: "צ'יינלינק", sector: "תשתיות", cgId: "chainlink" },
  { symbol: "LTCUSDT", base: "LTC", name: "Litecoin", hebrewName: "לייטקוין", sector: "תשלומים", cgId: "litecoin" },
  { symbol: "NEARUSDT", base: "NEAR", name: "NEAR Protocol", hebrewName: "ניר", sector: "שכבה 1", cgId: "near" },
  { symbol: "ARBUSDT", base: "ARB", name: "Arbitrum", hebrewName: "ארביטרום", sector: "שכבה 2", cgId: "arbitrum" },
  { symbol: "OPUSDT", base: "OP", name: "Optimism", hebrewName: "אופטימיזם", sector: "שכבה 2", cgId: "optimism" },
  { symbol: "APTUSDT", base: "APT", name: "Aptos", hebrewName: "אפטוס", sector: "שכבה 1", cgId: "aptos" },
  { symbol: "SUIUSDT", base: "SUI", name: "Sui", hebrewName: "סואי", sector: "שכבה 1", cgId: "sui" },
  { symbol: "INJUSDT", base: "INJ", name: "Injective", hebrewName: "אינג'קטיב", sector: "DeFi", cgId: "injective-protocol" },
  { symbol: "UNIUSDT", base: "UNI", name: "Uniswap", hebrewName: "יוניסוואפ", sector: "DeFi", cgId: "uniswap" },
  { symbol: "AAVEUSDT", base: "AAVE", name: "Aave", hebrewName: "אאבה", sector: "DeFi", cgId: "aave" },
  { symbol: "ATOMUSDT", base: "ATOM", name: "Cosmos", hebrewName: "קוסמוס", sector: "תשתיות", cgId: "cosmos" },
  { symbol: "FILUSDT", base: "FIL", name: "Filecoin", hebrewName: "פיילקוין", sector: "תשתיות", cgId: "filecoin" },
  { symbol: "FETUSDT", base: "FET", name: "Artificial Superintelligence", hebrewName: "פץ'", sector: "בינה מלאכותית", cgId: "fetch-ai" },
  { symbol: "RENDERUSDT", base: "RENDER", name: "Render", hebrewName: "רנדר", sector: "בינה מלאכותית", cgId: "render-token" },
  { symbol: "TAOUSDT", base: "TAO", name: "Bittensor", hebrewName: "ביטנסור", sector: "בינה מלאכותית", cgId: "bittensor" },
  { symbol: "DOGEUSDT", base: "DOGE", name: "Dogecoin", hebrewName: "דוג'קוין", sector: "ממים", cgId: "dogecoin" },
  { symbol: "SHIBUSDT", base: "SHIB", name: "Shiba Inu", hebrewName: "שיבה אינו", sector: "ממים", cgId: "shiba-inu" },
  { symbol: "PEPEUSDT", base: "PEPE", name: "Pepe", hebrewName: "פפה", sector: "ממים", cgId: "pepe" },
  { symbol: "WIFUSDT", base: "WIF", name: "dogwifhat", hebrewName: "ויף", sector: "ממים", cgId: "dogwifcoin" },
  { symbol: "SEIUSDT", base: "SEI", name: "Sei", hebrewName: "סיי", sector: "שכבה 1", cgId: "sei-network" },
  { symbol: "TIAUSDT", base: "TIA", name: "Celestia", hebrewName: "סלסטיה", sector: "תשתיות", cgId: "celestia" },
];

export const SYMBOLS = COIN_UNIVERSE.map((c) => c.symbol);

export const metaFor = (symbol: string): CoinMeta => {
  const found = COIN_UNIVERSE.find((c) => c.symbol === symbol);
  return (
    found ?? {
      symbol,
      base: symbol.replace("USDT", ""),
      name: symbol,
      hebrewName: symbol,
      sector: "אחר",
      cgId: symbol.replace("USDT", "").toLowerCase(),
    }
  );
};
