import type { Candle } from "./indicators";
import { COIN_UNIVERSE, SYMBOLS, metaFor } from "./universe";

export type MarketSource = "bybit" | "binance" | "binance-mirror" | "mexc" | "coingecko" | "none";

export type Ticker = {
  symbol: string;
  price: number;
  change24h: number;
  high24h: number;
  low24h: number;
  volume24h: number; // turnover in USDT
};

export type OrderBookLevel = { price: number; qty: number };
export type OrderBook = { bids: OrderBookLevel[]; asks: OrderBookLevel[] };
export type TapeTrade = { price: number; qty: number; side: "Buy" | "Sell"; time: number };

export type Sourced<T> = { data: T; source: MarketSource; degraded: boolean; error?: string };

const BYBIT = "https://api.bybit.com";
const BINANCE = "https://api.binance.com";
const BINANCE_MIRROR = "https://data-api.binance.vision";
const MEXC = "https://api.mexc.com";
const COINGECKO = "https://api.coingecko.com/api/v3";

const n = (v: unknown, f = 0) => {
  const x = typeof v === "number" ? v : Number(v);
  return Number.isFinite(x) ? x : f;
};

type CacheEntry = { at: number; value: unknown };
const globalCache = globalThis as typeof globalThis & { __marketCache?: Map<string, CacheEntry> };
const cache: Map<string, CacheEntry> = globalCache.__marketCache ?? new Map();
globalCache.__marketCache = cache;

function getCache<T>(key: string, ttlMs: number): T | null {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return hit.value as T;
  return null;
}
function setCache(key: string, value: unknown) {
  cache.set(key, { at: Date.now(), value });
}

export async function fetchJson<T>(url: string, timeoutMs = 7000): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      cache: "no-store",
      headers: { accept: "application/json", "user-agent": "crypto-scanner/1.0" },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return (await res.json()) as T;
  } finally {
    clearTimeout(timer);
  }
}

/** ניסיון מקורות בזה אחר זה (Failover) */
async function tryChain<T>(
  attempts: { source: MarketSource; run: () => Promise<T> }[],
): Promise<Sourced<T>> {
  let lastError = "";
  for (let i = 0; i < attempts.length; i++) {
    try {
      const data = await attempts[i].run();
      return { data, source: attempts[i].source, degraded: i > 0 };
    } catch (err) {
      lastError = err instanceof Error ? err.message : String(err);
    }
  }
  throw new Error(lastError || "all market sources failed");
}

/* ------------------------------ TICKERS ------------------------------ */

type BybitTickerResp = {
  retCode: number;
  result?: { list?: Array<Record<string, string>> };
};

async function bybitTickers(): Promise<Ticker[]> {
  const json = await fetchJson<BybitTickerResp>(`${BYBIT}/v5/market/tickers?category=linear`);
  if (json.retCode !== 0) throw new Error(`bybit retCode ${json.retCode}`);
  const list = Array.isArray(json.result?.list) ? json.result!.list! : [];
  const wanted = new Set(SYMBOLS);
  const out = list
    .filter((t) => wanted.has(String(t.symbol)))
    .map((t) => ({
      symbol: String(t.symbol),
      price: n(t.lastPrice),
      change24h: n(t.price24hPcnt) * 100,
      high24h: n(t.highPrice24h),
      low24h: n(t.lowPrice24h),
      volume24h: n(t.turnover24h),
    }));
  if (out.length === 0) throw new Error("bybit empty tickers");
  return out;
}

async function binanceTickers(host: string): Promise<Ticker[]> {
  const symbolsParam = encodeURIComponent(JSON.stringify(SYMBOLS));
  const json = await fetchJson<Array<Record<string, string>>>(
    `${host}/api/v3/ticker/24hr?symbols=${symbolsParam}`,
    9000,
  );
  const list = Array.isArray(json) ? json : [];
  const out = list.map((t) => ({
    symbol: String(t.symbol),
    price: n(t.lastPrice),
    change24h: n(t.priceChangePercent),
    high24h: n(t.highPrice),
    low24h: n(t.lowPrice),
    volume24h: n(t.quoteVolume),
  }));
  if (out.length === 0) throw new Error("binance empty tickers");
  return out;
}

async function coingeckoTickers(): Promise<Ticker[]> {
  const ids = COIN_UNIVERSE.map((c) => c.cgId).join(",");
  const json = await fetchJson<Array<Record<string, unknown>>>(
    `${COINGECKO}/coins/markets?vs_currency=usd&ids=${ids}&price_change_percentage=24h`,
    9000,
  );
  const list = Array.isArray(json) ? json : [];
  const out = list.map((c) => {
    const meta = COIN_UNIVERSE.find((m) => m.cgId === String(c.id));
    return {
      symbol: meta?.symbol ?? `${String(c.symbol ?? "").toUpperCase()}USDT`,
      price: n(c.current_price),
      change24h: n(c.price_change_percentage_24h),
      high24h: n(c.high_24h),
      low24h: n(c.low_24h),
      volume24h: n(c.total_volume),
    };
  });
  if (out.length === 0) throw new Error("coingecko empty tickers");
  return out;
}

export async function getTickers(): Promise<Sourced<Ticker[]>> {
  const cached = getCache<Sourced<Ticker[]>>("tickers", 8000);
  if (cached) return cached;
  try {
    const res = await tryChain<Ticker[]>([
      { source: "bybit", run: bybitTickers },
      { source: "binance", run: () => binanceTickers(BINANCE) },
      { source: "binance-mirror", run: () => binanceTickers(BINANCE_MIRROR) },
      { source: "mexc", run: () => binanceTickers(MEXC) },
      { source: "coingecko", run: coingeckoTickers },
    ]);
    setCache("tickers", res);
    return res;
  } catch (err) {
    const stale = cache.get("tickers")?.value as Sourced<Ticker[]> | undefined;
    if (stale) return { ...stale, degraded: true };
    return {
      data: [],
      source: "none",
      degraded: true,
      error: err instanceof Error ? err.message : "market offline",
    };
  }
}

/** מצב הקאש הנוכחי ללא קריאת רשת - עבור בדיקת בריאות מהירה */
export function peekTickerStatus(): { source: MarketSource; degraded: boolean; ageMs: number; count: number } {
  const hit = cache.get("tickers");
  const value = hit?.value as Sourced<Ticker[]> | undefined;
  return {
    source: value?.source ?? "none",
    degraded: value?.degraded ?? true,
    ageMs: hit ? Date.now() - hit.at : Number.POSITIVE_INFINITY,
    count: Array.isArray(value?.data) ? value!.data.length : 0,
  };
}

export async function getTicker(symbol: string): Promise<Ticker | null> {
  const all = await getTickers();
  return all.data.find((t) => t.symbol === symbol) ?? null;
}

/* ------------------------------ KLINES ------------------------------ */

const BYBIT_INTERVAL: Record<string, string> = { "15m": "15", "1h": "60", "4h": "240", "1d": "D" };

async function bybitKlines(symbol: string, interval: string, limit: number): Promise<Candle[]> {
  const iv = BYBIT_INTERVAL[interval] ?? "60";
  const json = await fetchJson<BybitTickerResp & { result?: { list?: string[][] } }>(
    `${BYBIT}/v5/market/kline?category=linear&symbol=${symbol}&interval=${iv}&limit=${limit}`,
  );
  const list = Array.isArray(json.result?.list) ? (json.result!.list as unknown as string[][]) : [];
  if (list.length === 0) throw new Error("bybit empty klines");
  return list
    .map((k) => ({
      time: n(k[0]),
      open: n(k[1]),
      high: n(k[2]),
      low: n(k[3]),
      close: n(k[4]),
      volume: n(k[5]),
    }))
    .sort((a, b) => a.time - b.time);
}

async function binanceKlines(host: string, symbol: string, interval: string, limit: number): Promise<Candle[]> {
  const json = await fetchJson<unknown[][]>(
    `${host}/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`,
    9000,
  );
  const list = Array.isArray(json) ? json : [];
  if (list.length === 0) throw new Error("binance empty klines");
  return list.map((k) => ({
    time: n(k[0]),
    open: n(k[1]),
    high: n(k[2]),
    low: n(k[3]),
    close: n(k[4]),
    volume: n(k[5]),
  }));
}

async function coingeckoKlines(symbol: string, limit: number): Promise<Candle[]> {
  const meta = metaFor(symbol);
  const json = await fetchJson<{ prices?: number[][]; total_volumes?: number[][] }>(
    `${COINGECKO}/coins/${meta.cgId}/market_chart?vs_currency=usd&days=14`,
    9000,
  );
  const prices = Array.isArray(json.prices) ? json.prices : [];
  const vols = Array.isArray(json.total_volumes) ? json.total_volumes : [];
  if (prices.length === 0) throw new Error("coingecko empty chart");
  const candles: Candle[] = prices.map((p, i) => {
    const price = n(p[1]);
    const prev = n(prices[i - 1]?.[1], price);
    return {
      time: n(p[0]),
      open: prev,
      high: Math.max(prev, price),
      low: Math.min(prev, price),
      close: price,
      volume: n(vols[i]?.[1]),
    };
  });
  return candles.slice(-limit);
}

export async function getKlines(symbol: string, interval = "1h", limit = 200): Promise<Sourced<Candle[]>> {
  const key = `kline:${symbol}:${interval}:${limit}`;
  const cached = getCache<Sourced<Candle[]>>(key, 45000);
  if (cached) return cached;
  try {
    const res = await tryChain<Candle[]>([
      { source: "bybit", run: () => bybitKlines(symbol, interval, limit) },
      { source: "binance", run: () => binanceKlines(BINANCE, symbol, interval, limit) },
      { source: "binance-mirror", run: () => binanceKlines(BINANCE_MIRROR, symbol, interval, limit) },
      { source: "mexc", run: () => binanceKlines(MEXC, symbol, interval, limit) },
      { source: "coingecko", run: () => coingeckoKlines(symbol, limit) },
    ]);
    setCache(key, res);
    return res;
  } catch (err) {
    const stale = cache.get(key)?.value as Sourced<Candle[]> | undefined;
    if (stale) return { ...stale, degraded: true };
    return { data: [], source: "none", degraded: true, error: err instanceof Error ? err.message : "no klines" };
  }
}

/* ------------------------------ ORDER BOOK ------------------------------ */

async function bybitOrderBook(symbol: string, limit: number): Promise<OrderBook> {
  const json = await fetchJson<{ retCode: number; result?: { b?: string[][]; a?: string[][] } }>(
    `${BYBIT}/v5/market/orderbook?category=linear&symbol=${symbol}&limit=${limit}`,
  );
  if (json.retCode !== 0) throw new Error("bybit orderbook error");
  const b = Array.isArray(json.result?.b) ? json.result!.b! : [];
  const a = Array.isArray(json.result?.a) ? json.result!.a! : [];
  if (b.length === 0 && a.length === 0) throw new Error("bybit empty book");
  return {
    bids: b.map((x) => ({ price: n(x[0]), qty: n(x[1]) })),
    asks: a.map((x) => ({ price: n(x[0]), qty: n(x[1]) })),
  };
}

async function binanceOrderBook(host: string, symbol: string, limit: number): Promise<OrderBook> {
  const json = await fetchJson<{ bids?: string[][]; asks?: string[][] }>(
    `${host}/api/v3/depth?symbol=${symbol}&limit=${Math.min(limit, 100)}`,
    9000,
  );
  const bids = Array.isArray(json.bids) ? json.bids : [];
  const asks = Array.isArray(json.asks) ? json.asks : [];
  if (bids.length === 0 && asks.length === 0) throw new Error("binance empty book");
  return {
    bids: bids.map((x) => ({ price: n(x[0]), qty: n(x[1]) })),
    asks: asks.map((x) => ({ price: n(x[0]), qty: n(x[1]) })),
  };
}

export async function getOrderBook(symbol: string, limit = 25): Promise<Sourced<OrderBook>> {
  const key = `book:${symbol}:${limit}`;
  const cached = getCache<Sourced<OrderBook>>(key, 1500);
  if (cached) return cached;
  try {
    const res = await tryChain<OrderBook>([
      { source: "bybit", run: () => bybitOrderBook(symbol, limit) },
      { source: "binance", run: () => binanceOrderBook(BINANCE, symbol, limit) },
      { source: "binance-mirror", run: () => binanceOrderBook(BINANCE_MIRROR, symbol, limit) },
      { source: "mexc", run: () => binanceOrderBook(MEXC, symbol, limit) },
    ]);
    setCache(key, res);
    return res;
  } catch (err) {
    return {
      data: { bids: [], asks: [] },
      source: "none",
      degraded: true,
      error: err instanceof Error ? err.message : "no book",
    };
  }
}

/* ------------------------------ TRADE TAPE ------------------------------ */

async function bybitTrades(symbol: string, limit: number): Promise<TapeTrade[]> {
  const json = await fetchJson<{ retCode: number; result?: { list?: Array<Record<string, string>> } }>(
    `${BYBIT}/v5/market/recent-trade?category=linear&symbol=${symbol}&limit=${limit}`,
  );
  if (json.retCode !== 0) throw new Error("bybit trades error");
  const list = Array.isArray(json.result?.list) ? json.result!.list! : [];
  if (list.length === 0) throw new Error("bybit empty trades");
  return list.map((t) => ({
    price: n(t.price),
    qty: n(t.size),
    side: t.side === "Sell" ? "Sell" : "Buy",
    time: n(t.time),
  }));
}

async function binanceTrades(host: string, symbol: string, limit: number): Promise<TapeTrade[]> {
  const json = await fetchJson<Array<Record<string, unknown>>>(
    `${host}/api/v3/trades?symbol=${symbol}&limit=${limit}`,
    9000,
  );
  const list = Array.isArray(json) ? json : [];
  if (list.length === 0) throw new Error("binance empty trades");
  return list
    .map((t) => ({
      price: n(t.price),
      qty: n(t.qty),
      side: (t.isBuyerMaker ? "Sell" : "Buy") as "Buy" | "Sell",
      time: n(t.time),
    }))
    .sort((a, b) => b.time - a.time);
}

export async function getTrades(symbol: string, limit = 40): Promise<Sourced<TapeTrade[]>> {
  const key = `trades:${symbol}`;
  const cached = getCache<Sourced<TapeTrade[]>>(key, 1500);
  if (cached) return cached;
  try {
    const res = await tryChain<TapeTrade[]>([
      { source: "bybit", run: () => bybitTrades(symbol, limit) },
      { source: "binance", run: () => binanceTrades(BINANCE, symbol, limit) },
      { source: "binance-mirror", run: () => binanceTrades(BINANCE_MIRROR, symbol, limit) },
      { source: "mexc", run: () => binanceTrades(MEXC, symbol, limit) },
    ]);
    setCache(key, res);
    return res;
  } catch (err) {
    return { data: [], source: "none", degraded: true, error: err instanceof Error ? err.message : "no trades" };
  }
}

/* ------------------------------ FEAR & GREED ------------------------------ */

export type FearGreed = { value: number; classification: string; hebrew: string; updatedAt: number };

const fngHebrew = (v: number) => {
  if (v <= 24) return "פחד קיצוני";
  if (v <= 44) return "פחד";
  if (v <= 55) return "ניטרלי";
  if (v <= 74) return "חמדנות";
  return "חמדנות קיצונית";
};

export async function getFearGreed(): Promise<Sourced<FearGreed>> {
  const cached = getCache<Sourced<FearGreed>>("fng", 120000);
  if (cached) return cached;
  try {
    const json = await fetchJson<{ data?: Array<{ value?: string; value_classification?: string; timestamp?: string }> }>(
      "https://api.alternative.me/fng/?limit=1",
    );
    const item = Array.isArray(json.data) ? json.data[0] : undefined;
    const value = n(item?.value, 50);
    const res: Sourced<FearGreed> = {
      data: {
        value,
        classification: String(item?.value_classification ?? "Neutral"),
        hebrew: fngHebrew(value),
        updatedAt: n(item?.timestamp) * 1000 || Date.now(),
      },
      source: "coingecko",
      degraded: false,
    };
    setCache("fng", res);
    return res;
  } catch (err) {
    const stale = cache.get("fng")?.value as Sourced<FearGreed> | undefined;
    if (stale) return { ...stale, degraded: true };
    return {
      data: { value: 50, classification: "Unavailable", hebrew: "אין נתונים", updatedAt: Date.now() },
      source: "none",
      degraded: true,
      error: err instanceof Error ? err.message : "fng offline",
    };
  }
}

/* ------------------------------ GLOBAL / RESEARCH ------------------------------ */

export type GlobalStats = { totalMarketCap: number; totalVolume: number; btcDominance: number; marketCapChange24h: number };

export async function getGlobalStats(): Promise<Sourced<GlobalStats>> {
  const cached = getCache<Sourced<GlobalStats>>("global", 120000);
  if (cached) return cached;
  try {
    const json = await fetchJson<{
      data?: {
        total_market_cap?: Record<string, number>;
        total_volume?: Record<string, number>;
        market_cap_percentage?: Record<string, number>;
        market_cap_change_percentage_24h_usd?: number;
      };
    }>(`${COINGECKO}/global`, 9000);
    const d = json.data ?? {};
    const res: Sourced<GlobalStats> = {
      data: {
        totalMarketCap: n(d.total_market_cap?.usd),
        totalVolume: n(d.total_volume?.usd),
        btcDominance: n(d.market_cap_percentage?.btc),
        marketCapChange24h: n(d.market_cap_change_percentage_24h_usd),
      },
      source: "coingecko",
      degraded: false,
    };
    setCache("global", res);
    return res;
  } catch (err) {
    return {
      data: { totalMarketCap: 0, totalVolume: 0, btcDominance: 0, marketCapChange24h: 0 },
      source: "none",
      degraded: true,
      error: err instanceof Error ? err.message : "global offline",
    };
  }
}

export type CoinFundamentals = {
  symbol: string;
  name: string;
  marketCap: number;
  fdv: number;
  circulatingSupply: number;
  totalSupply: number;
  maxSupply: number;
  supplyInflation: number;
  onChainVolume: number;
  volumeToMcap: number;
  activeWallets: number;
  developerActivity: number;
  communityScore: number;
  sentimentUp: number;
  ath: number;
  athChangePct: number;
  categories: string[];
  description: string;
};

export async function getFundamentals(symbol: string): Promise<Sourced<CoinFundamentals | null>> {
  const meta = metaFor(symbol);
  const key = `fund:${symbol}`;
  const cached = getCache<Sourced<CoinFundamentals | null>>(key, 300000);
  if (cached) return cached;
  try {
    const json = await fetchJson<Record<string, unknown>>(
      `${COINGECKO}/coins/${meta.cgId}?localization=false&tickers=false&market_data=true&community_data=true&developer_data=true&sparkline=false`,
      12000,
    );
    const md = (json.market_data ?? {}) as Record<string, unknown>;
    const dev = (json.developer_data ?? {}) as Record<string, unknown>;
    const community = (json.community_data ?? {}) as Record<string, unknown>;
    const price = n((md.current_price as Record<string, unknown>)?.usd);
    const circ = n(md.circulating_supply);
    const total = n(md.total_supply, circ);
    const max = n(md.max_supply, total);
    const mcap = n((md.market_cap as Record<string, unknown>)?.usd, price * circ);
    const vol = n((md.total_volume as Record<string, unknown>)?.usd);
    const fdv = n((md.fully_diluted_valuation as Record<string, unknown>)?.usd, price * (max || total || circ));
    const descObj = (json.description ?? {}) as Record<string, unknown>;
    const res: Sourced<CoinFundamentals | null> = {
      data: {
        symbol,
        name: String(json.name ?? meta.name),
        marketCap: mcap,
        fdv,
        circulatingSupply: circ,
        totalSupply: total,
        maxSupply: max,
        supplyInflation: total > 0 && circ > 0 ? ((total - circ) / circ) * 100 : 0,
        onChainVolume: vol,
        volumeToMcap: mcap > 0 ? (vol / mcap) * 100 : 0,
        activeWallets: n(community.twitter_followers) + n(community.reddit_subscribers),
        developerActivity: n(dev.commit_count_4_weeks),
        communityScore: n(json.community_score),
        sentimentUp: n(json.sentiment_votes_up_percentage, 50),
        ath: n((md.ath as Record<string, unknown>)?.usd),
        athChangePct: n((md.ath_change_percentage as Record<string, unknown>)?.usd),
        categories: Array.isArray(json.categories) ? (json.categories as string[]).filter(Boolean).slice(0, 6) : [],
        description: String((descObj.en as string) ?? "").replace(/<[^>]*>/g, "").slice(0, 600),
      },
      source: "coingecko",
      degraded: false,
    };
    setCache(key, res);
    return res;
  } catch (err) {
    return { data: null, source: "none", degraded: true, error: err instanceof Error ? err.message : "no fundamentals" };
  }
}

export async function getUsdIlsRate(): Promise<number> {
  const cached = getCache<number>("usdils", 600000);
  if (cached) return cached;
  try {
    const json = await fetchJson<{ rates?: Record<string, number> }>(
      "https://api.frankfurter.app/latest?from=USD&to=ILS",
      7000,
    );
    const rate = n(json.rates?.ILS, 3.7);
    setCache("usdils", rate);
    return rate;
  } catch {
    return 3.7;
  }
}
