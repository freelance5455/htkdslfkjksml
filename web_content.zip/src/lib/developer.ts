/**
 * Developer credit for MATCH CRICKET.
 * Attribution only — no contact details and no hiring/enquiry channels.
 */
export const DEVELOPER = {
  name: "Manan Haider",
  tagline: "Developed by",
} as const;
