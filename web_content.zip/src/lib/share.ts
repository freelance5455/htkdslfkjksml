export async function shareText(title: string, text: string) {
  const payload = `${title}\n\n${text}\n\n— رفيق`;
  try {
    if (navigator.share) {
      await navigator.share({ title, text: payload });
      return;
    }
  } catch {
    /* cancelled */
    return;
  }
  await navigator.clipboard.writeText(payload);
}
