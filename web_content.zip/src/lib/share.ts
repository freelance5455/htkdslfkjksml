export type PadDoc = {
  v: 1;
  t: string;
  h: string;
};

function bytesToB64url(bytes: Uint8Array) {
  let bin = "";
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]!);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function b64urlToBytes(token: string) {
  const pad = "=".repeat((4 - (token.length % 4)) % 4);
  const b64 = (token + pad).replace(/-/g, "+").replace(/_/g, "/");
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

async function gzipB64(text: string) {
  const bytes = new TextEncoder().encode(text);
  const stream = new Blob([bytes]).stream().pipeThrough(new CompressionStream("gzip"));
  const buf = await new Response(stream).arrayBuffer();
  return bytesToB64url(new Uint8Array(buf));
}

async function gunzipB64(token: string) {
  const bytes = b64urlToBytes(token);
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("gzip"));
  const buf = await new Response(stream).arrayBuffer();
  return new TextDecoder().decode(buf);
}

export async function encodePad(doc: PadDoc): Promise<string> {
  const json = JSON.stringify(doc);
  try {
    if (typeof CompressionStream !== "undefined") {
      return `p1.${await gzipB64(json)}`;
    }
  } catch {
    /* fall through */
  }
  return `r1.${encodeURIComponent(json)}`;
}

export async function decodePad(token: string): Promise<PadDoc | null> {
  try {
    if (token.startsWith("p1.")) {
      const json = await gunzipB64(token.slice(3));
      return JSON.parse(json) as PadDoc;
    }
    if (token.startsWith("r1.")) {
      return JSON.parse(decodeURIComponent(token.slice(3))) as PadDoc;
    }
  } catch {
    return null;
  }
  return null;
}

export function readTokenFromLocation(): string | null {
  const hash = window.location.hash.replace(/^#/, "");
  if (hash.startsWith("d=")) {
    return decodeURIComponent(hash.slice(2));
  }
  const hp = new URLSearchParams(hash);
  const fromHash = hp.get("d");
  if (fromHash) return fromHash;
  return new URLSearchParams(window.location.search).get("d");
}

export function buildShareUrl(token: string) {
  const url = new URL(window.location.href);
  url.search = "";
  url.hash = `d=${token}`;
  return url.toString();
}

const STORAGE_KEY = "padlink:doc";

export function saveLocal(doc: PadDoc) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(doc));
  } catch {
    /* quota */
  }
}

export function loadLocal(): PadDoc | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as PadDoc;
    if (parsed && parsed.v === 1 && typeof parsed.h === "string") return parsed;
  } catch {
    return null;
  }
  return null;
}
