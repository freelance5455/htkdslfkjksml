import { frameFilter, type EditRecipe } from "@/lib/recipe";

let grainTile: HTMLCanvasElement | null = null;

function tile() {
  if (grainTile) return grainTile;
  const canvas = document.createElement("canvas");
  canvas.width = 160;
  canvas.height = 160;
  const ctx = canvas.getContext("2d");
  if (!ctx) return canvas;
  const image = ctx.createImageData(160, 160);
  for (let i = 0; i < image.data.length; i += 4) {
    const v = Math.random() * 255;
    image.data[i] = v;
    image.data[i + 1] = v;
    image.data[i + 2] = v;
    image.data[i + 3] = 255;
  }
  ctx.putImageData(image, 0, 0);
  grainTile = canvas;
  return canvas;
}

function bars(w: number, h: number, enabled: boolean) {
  if (!enabled) return 0;
  if (w >= h) return Math.max(0, (h - Math.min(h, w / 2.35)) / 2);
  return h * 0.07;
}

function wrap(ctx: CanvasRenderingContext2D, text: string, maxWidth: number) {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let line = "";
  for (const word of words) {
    const next = line ? `${line} ${word}` : word;
    if (ctx.measureText(next).width > maxWidth && line) {
      lines.push(line);
      line = word;
    } else {
      line = next;
    }
  }
  if (line) lines.push(line);
  return lines.slice(0, 3);
}

function fadeAmount(outputTime: number, outputDuration: number, recipe: EditRecipe) {
  let amount = 1;
  if (recipe.fadeIn > 0) amount = Math.min(amount, outputTime / recipe.fadeIn);
  if (recipe.fadeOut > 0) amount = Math.min(amount, (outputDuration - outputTime) / recipe.fadeOut);
  return Math.max(0, Math.min(1, amount));
}

export function drawFrame(
  ctx: CanvasRenderingContext2D,
  video: HTMLVideoElement,
  recipe: EditRecipe,
  sourceTime: number,
  clipStart: number,
  clipEnd: number,
) {
  const w = ctx.canvas.width;
  const h = ctx.canvas.height;
  const span = Math.max(0.001, clipEnd - clipStart);
  const progress = Math.max(0, Math.min(1, (sourceTime - clipStart) / span));
  const outputDuration = span / recipe.speed;
  const outputTime = progress * outputDuration;
  const fade = fadeAmount(outputTime, outputDuration, recipe);
  const zoom = 1 + (recipe.zoom - 1) * progress;
  const vw = video.videoWidth || w;
  const vh = video.videoHeight || h;
  const scale = Math.max(w / vw, h / vh) * zoom;
  const dw = vw * scale;
  const dh = vh * scale;

  ctx.save();
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, w, h);
  ctx.filter = frameFilter(recipe);
  ctx.drawImage(video, (w - dw) / 2, (h - dh) / 2, dw, dh);
  ctx.filter = "none";

  if (recipe.vignette > 0) {
    const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.25, w / 2, h / 2, Math.max(w, h) * 0.72);
    g.addColorStop(0, "rgba(0,0,0,0)");
    g.addColorStop(1, `rgba(0,0,0,${recipe.vignette})`);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  }

  if (recipe.grain > 0) {
    ctx.globalAlpha = recipe.grain;
    const noise = tile();
    const ox = Math.round((sourceTime * 48) % 40);
    const oy = Math.round((sourceTime * 36) % 40);
    ctx.drawImage(noise, -ox, -oy, w + 40, h + 40);
    ctx.globalAlpha = 1;
  }

  const bar = bars(w, h, recipe.letterbox);
  if (bar > 0) {
    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, w, bar);
    ctx.fillRect(0, h - bar, w, bar);
  }

  const showTitle =
    (recipe.title || recipe.subtitle) && progress >= recipe.titleStart && progress <= recipe.titleEnd;
  if (showTitle) {
    const windowSpan = Math.max(0.001, recipe.titleEnd - recipe.titleStart);
    const local = (progress - recipe.titleStart) / windowSpan;
    const titleFade = Math.min(1, local / 0.18, (1 - local) / 0.18);
    ctx.save();
    ctx.globalAlpha = Math.max(0, titleFade);
    ctx.fillStyle = "#f3f2ef";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.shadowColor = "rgba(0,0,0,0.7)";
    ctx.shadowBlur = Math.max(8, w * 0.02);
    const pictureTop = bar;
    const pictureH = h - bar * 2;
    if (recipe.title) {
      const size = Math.max(22, Math.round(w * 0.078));
      ctx.font = `560 ${size}px Fraunces, Georgia, serif`;
      const lines = wrap(ctx, recipe.title, w * 0.82);
      const cy = pictureTop + pictureH * 0.42 - ((lines.length - 1) * size * 1.15) / 2;
      lines.forEach((line, index) => {
        ctx.fillText(line, w / 2, cy + index * size * 1.15);
      });
    }
    if (recipe.subtitle) {
      const size = Math.max(14, Math.round(w * 0.038));
      ctx.font = `500 ${size}px Outfit, sans-serif`;
      ctx.fillText(recipe.subtitle, w / 2, pictureTop + pictureH * 0.58);
    }
    ctx.restore();
  }

  const caption = recipe.captions.find((item) => progress >= item.start && progress <= item.end);
  if (caption) {
    const size = Math.max(15, Math.round(w * 0.04));
    ctx.font = `500 ${size}px Outfit, sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    const lines = wrap(ctx, caption.text, w * 0.8);
    const lineH = size * 1.25;
    const blockH = lines.length * lineH + size * 0.7;
    const blockW = Math.min(w * 0.86, Math.max(...lines.map((line) => ctx.measureText(line).width)) + size);
    const x = (w - blockW) / 2;
    const y = h - bar - blockH - size * 0.7;
    ctx.fillStyle = "rgba(12,12,13,0.72)";
    ctx.beginPath();
    ctx.roundRect(x, y, blockW, blockH, 10);
    ctx.fill();
    ctx.fillStyle = "#f3f2ef";
    lines.forEach((line, index) => {
      ctx.fillText(line, w / 2, y + size * 0.55 + index * lineH);
    });
  }

  if (fade < 0.999) {
    ctx.fillStyle = `rgba(0,0,0,${1 - fade})`;
    ctx.fillRect(0, 0, w, h);
  }
  ctx.restore();
}
