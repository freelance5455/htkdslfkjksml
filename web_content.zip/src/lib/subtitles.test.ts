import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { activeCue, matchSubtitleFilename, parseSubtitles, shiftCues } from "./subtitles.ts";

describe("parseSubtitles", () => {
  it("parses SRT blocks and skips junk", () => {
    const src = `1
00:00:01,000 --> 00:00:04,000
Hello

not a cue

2
00:00:05,500 --> 00:00:07,000
Second line
`;
    const cues = parseSubtitles(src);
    assert.equal(cues.length, 2);
    assert.equal(cues[0]?.text, "Hello");
    assert.equal(cues[0]?.start, 1);
    assert.equal(cues[1]?.start, 5.5);
  });

  it("parses VTT and strips tags", () => {
    const src = `WEBVTT

00:00:00.000 --> 00:00:02.000
<b>Hi</b>
`;
    const cues = parseSubtitles(src);
    assert.equal(cues.length, 1);
    assert.equal(cues[0]?.text, "Hi");
  });

  it("does not throw on empty or malformed input", () => {
    assert.deepEqual(parseSubtitles(""), []);
    assert.deepEqual(parseSubtitles("WEBVTT\n\n00:00:01 --> nope"), []);
  });
});

describe("shiftCues / activeCue", () => {
  const cues = parseSubtitles(`1\n00:00:01,000 --> 00:00:02,000\nA\n`);
  it("shifts by delay", () => {
    const shifted = shiftCues(cues, 0.5);
    assert.equal(shifted[0]?.start, 1.5);
  });
  it("finds the active cue", () => {
    assert.equal(activeCue(cues, 1.2)?.text, "A");
    assert.equal(activeCue(cues, 0), undefined);
  });
});

describe("matchSubtitleFilename", () => {
  it("matches by stem", () => {
    assert.equal(matchSubtitleFilename("Movie.mp4", "Movie.srt"), true);
    assert.equal(matchSubtitleFilename("Movie.mp4", "Other.srt"), false);
  });
});
