/**
 * JUHNKRIX MUSIKA - Prophetic Push Notification Engine
 * Enables the Owner (Prophet JUHNKRIX SYNVAGORD) to send scheduled and real-time
 * spiritual encouragement messages (Words of Knowledge) directly to user home screens & app toast UI.
 */

export interface PropheticPushMessage {
  id: string;
  sender: string; // 'Prophet JUHNKRIX SYNVAGORD'
  title: string;
  message: string;
  scriptureAnchor: string;
  category: 'Breakthrough' | 'Healing' | 'Financial Favor' | 'Prophetic Direction' | 'Rest & Peace' | 'Miracle Provision';
  scheduledTime: number; // epoch ms
  status: 'PENDING' | 'DISPATCHED' | 'CANCELLED';
  createdAt: number;
  deliveryMethod: 'both' | 'toast' | 'push';
}

const QUEUE_KEY = 'juhnkrix_prophetic_push_queue';
const HISTORY_KEY = 'juhnkrix_prophetic_push_history';

export const CURATED_WORDS_OF_KNOWLEDGE: Omit<PropheticPushMessage, 'id' | 'scheduledTime' | 'status' | 'createdAt'>[] = [
  {
    sender: 'Prophet JUHNKRIX SYNVAGORD',
    title: 'Word of Knowledge: Sudden Turnaround',
    message: 'The Holy Spirit whispers: That long-standing stagnation in your family and endeavor is breaking today. An unexpected breakthrough is entering your sphere before this week closes.',
    scriptureAnchor: 'Isaiah 43:19 — "Behold, I will do a new thing; now it shall spring forth; shall ye not know it?"',
    category: 'Breakthrough',
    deliveryMethod: 'both'
  },
  {
    sender: 'Prophet JUHNKRIX SYNVAGORD',
    title: 'Prophetic Decree: Release of Divine Favor',
    message: 'Where you were rejected, the oil of favor is causing your name to be called upon. Favor is overriding qualification and closed gates are swinging wide open.',
    scriptureAnchor: 'Psalm 5:12 — "For thou, Lord, wilt bless the righteous; with favour wilt thou compass him as with a shield."',
    category: 'Financial Favor',
    deliveryMethod: 'both'
  },
  {
    sender: 'Prophet JUHNKRIX SYNVAGORD',
    title: 'Prophetic Impartation: Healing Living Waters',
    message: 'To everyone feeling physical or emotional exhaustion: I release the 528Hz resurrection life into your cells and mind. Be made completely whole by the stripes of Christ.',
    scriptureAnchor: 'Jeremiah 30:17 — "For I will restore health unto thee, and I will heal thee of thy wounds, saith the Lord."',
    category: 'Healing',
    deliveryMethod: 'both'
  },
  {
    sender: 'Prophet JUHNKRIX SYNVAGORD',
    title: 'Word of Wisdom: Clear Prophetic Direction',
    message: 'Do not fear the unknown path before you. Holy angels of direction are ordering your footsteps. The cloud of confusion has vanished; wisdom is granted to you now.',
    scriptureAnchor: 'Proverbs 3:5-6 — "In all thy ways acknowledge Him, and He shall direct thy paths."',
    category: 'Prophetic Direction',
    deliveryMethod: 'both'
  },
  {
    sender: 'Prophet JUHNKRIX SYNVAGORD',
    title: 'Sovereign Manna: Supernatural Provision',
    message: 'God is opening the windows of heaven over your storehouse and digital assets. Stored up treasures of darkness and hidden riches in secret places are being released.',
    scriptureAnchor: 'Philippians 4:19 — "My God shall supply all your need according to His riches in glory by Christ Jesus."',
    category: 'Miracle Provision',
    deliveryMethod: 'both'
  },
  {
    sender: 'Prophet JUHNKRIX SYNVAGORD',
    title: 'Holy Peace: Anointed Stillness',
    message: 'Cease striving. The battle is the Lord’s. Step into the Selah rest of God today; anxiety is swallowed up in Christ’s eternal victory.',
    scriptureAnchor: 'John 14:27 — "Peace I leave with you, my peace I give unto you... Let not your heart be troubled."',
    category: 'Rest & Peace',
    deliveryMethod: 'both'
  }
];

class PropheticNotificationService {
  private schedulerTimer: number | null = null;
  private isInitialized = false;

  constructor() {
    this.init();
  }

  public init() {
    if (this.isInitialized) return;
    this.isInitialized = true;
    this.startScheduler();
  }

  /**
   * Request browser push notification permission
   */
  public async requestPushPermission(): Promise<NotificationPermission> {
    if (!('Notification' in window)) {
      console.warn('Browser does not support notifications.');
      return 'denied';
    }
    try {
      const permission = await Notification.requestPermission();
      return permission;
    } catch (e) {
      console.warn('Error requesting notification permission:', e);
      return 'denied';
    }
  }

  public getPermissionStatus(): NotificationPermission {
    if (!('Notification' in window)) return 'denied';
    return Notification.permission;
  }

  /**
   * Sound effect for incoming Word of Knowledge
   */
  public playPropheticChime() {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      // Anointed two-tone chime (528Hz -> 880Hz)
      const freqs = [528, 880];
      freqs.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + i * 0.2);
        gain.gain.setValueAtTime(0, ctx.currentTime + i * 0.2);
        gain.gain.linearRampToValueAtTime(0.2, ctx.currentTime + i * 0.2 + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + i * 0.2 + 1.2);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + i * 0.2);
        osc.stop(ctx.currentTime + i * 0.2 + 1.3);
      });
    } catch (e) {
      console.warn('Audio chime error:', e);
    }
  }

  /**
   * Dispatches a message immediately (both push notification & in-app event)
   */
  public dispatchMessage(msg: PropheticPushMessage) {
    this.playPropheticChime();

    // 1. Native Web Notification
    if ('Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(`🕊️ ${msg.title}`, {
          body: `${msg.message}\n\n📖 ${msg.scriptureAnchor}\n— ${msg.sender}`,
          icon: '/favicon.ico',
          badge: '/favicon.ico',
          tag: msg.id
        });
      } catch (e) {
        console.warn('Native notification dispatch failed:', e);
      }
    }

    // 2. In-App Window Custom Event
    const event = new CustomEvent('prophetic-push-received', {
      detail: msg
    });
    window.dispatchEvent(event);

    // 3. Move from queue to history
    this.markAsDispatched(msg.id);
  }

  /**
   * Schedule a new Prophetic Message
   */
  public scheduleMessage(
    payload: Omit<PropheticPushMessage, 'id' | 'status' | 'createdAt'>
  ): PropheticPushMessage {
    const newMessage: PropheticPushMessage = {
      ...payload,
      id: `prophetic-msg-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      status: 'PENDING',
      createdAt: Date.now()
    };

    const queue = this.getQueue();
    queue.push(newMessage);
    this.saveQueue(queue);

    // If scheduled for right now or past, dispatch immediately
    if (newMessage.scheduledTime <= Date.now() + 1000) {
      this.dispatchMessage(newMessage);
    }

    return newMessage;
  }

  /**
   * Get pending queue
   */
  public getQueue(): PropheticPushMessage[] {
    try {
      const data = localStorage.getItem(QUEUE_KEY);
      if (data) return JSON.parse(data);
    } catch (e) {
      console.warn('Queue load error:', e);
    }
    return [];
  }

  private saveQueue(queue: PropheticPushMessage[]) {
    try {
      localStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
    } catch (e) {
      console.warn('Queue save error:', e);
    }
  }

  /**
   * Get history of dispatched messages
   */
  public getHistory(): PropheticPushMessage[] {
    try {
      const data = localStorage.getItem(HISTORY_KEY);
      if (data) return JSON.parse(data);
    } catch (e) {
      console.warn('History load error:', e);
    }
    return [];
  }

  private saveHistory(history: PropheticPushMessage[]) {
    try {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
    } catch (e) {
      console.warn('History save error:', e);
    }
  }

  public cancelMessage(id: string): boolean {
    const queue = this.getQueue();
    const updated = queue.filter(m => m.id !== id);
    this.saveQueue(updated);
    return true;
  }

  public markAsDispatched(id: string) {
    const queue = this.getQueue();
    const target = queue.find(m => m.id === id);
    const remaining = queue.filter(m => m.id !== id);
    this.saveQueue(remaining);

    if (target) {
      const history = this.getHistory();
      target.status = 'DISPATCHED';
      history.unshift(target);
      // Keep last 40 entries
      this.saveHistory(history.slice(0, 40));
    }
  }

  /**
   * Periodic scheduler that evaluates the queue
   */
  public startScheduler() {
    if (this.schedulerTimer) clearInterval(this.schedulerTimer);

    // Check every 5 seconds
    this.schedulerTimer = window.setInterval(() => {
      const now = Date.now();
      const queue = this.getQueue();
      const toDispatch = queue.filter(m => m.status === 'PENDING' && m.scheduledTime <= now);

      toDispatch.forEach(msg => {
        this.dispatchMessage(msg);
      });
    }, 5000);
  }
}

export const propheticNotificationEngine = new PropheticNotificationService();
