import { NextResponse } from "next/server";
import { DatabaseNotConfiguredError } from "@/db";

/**
 * Internal, machine-readable error codes.
 *
 * These are for developers, server logs and client-side branching only.
 * They are NEVER rendered in the scorer UI, which shows no connection or
 * synchronisation status text at all.
 */
export type ApiErrorCode =
  | "DATABASE_NOT_CONFIGURED"
  | "DATABASE_UNAVAILABLE"
  | "DATABASE_CONNECTION_FAILED"
  | "VALIDATION_ERROR"
  | "NOT_FOUND";

export function apiError(code: ApiErrorCode, message: string, status: number, extra?: object) {
  return NextResponse.json({ success: false, error: code, message, ...extra }, { status });
}

/**
 * Converts a database failure into a structured response.
 *
 * The payload carries `cloudAvailable: false` so the client can silently fall
 * back to local-first operation. No configuration details, environment
 * variable names or administrator instructions are returned to the browser —
 * the full diagnostic is written to the server log instead.
 */
export function databaseErrorResponse(error: unknown) {
  const notConfigured = error instanceof DatabaseNotConfiguredError;
  const code: ApiErrorCode = notConfigured
    ? "DATABASE_NOT_CONFIGURED"
    : "DATABASE_UNAVAILABLE";

  // Developer diagnostics — server-side only.
  console.error(
    `[match-cricket] ${code}:`,
    notConfigured ? "DATABASE_URL is not set in this environment." : error,
  );

  return NextResponse.json(
    {
      success: false,
      error: code,
      // Neutral, user-safe wording. The UI does not display this string.
      message: "Saved on this device.",
      cloudAvailable: false,
    },
    { status: 503 },
  );
}
