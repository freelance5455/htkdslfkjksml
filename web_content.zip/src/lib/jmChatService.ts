// Country/Alphabet Filtering, Real-time Online/Offline Indicators, and WhatsApp-Style E2EE Groups.

import { COUNTRIES_195 as ALL_WORLD_COUNTRIES, getAllCountryNames, getCountryFlag } from './countries';

export interface JMChatUser {
  id: string;
  name: string;
  avatar: string;
  country: string;
  city: string;
  role: string;
  bio: string;
  isOnline: boolean;
  lastSeen: string;
  businessSector: string;
  connectionStatus: 'NONE' | 'PENDING_INCOMING' | 'PENDING_OUTGOING' | 'CONNECTED' | 'REJECTED';
  connectionRequestMessage?: string;
  unreadCount?: number;
}

export interface JMChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  text: string;
  timestamp: string;
  isEndToEndEncrypted: boolean;
  status: 'sent' | 'delivered' | 'read';
  messageType: 'text' | 'voice_note' | 'business_deal' | 'prayer_note' | 'file';
  attachmentUrl?: string;
  attachmentName?: string;
  attachmentSize?: string;
  attachmentType?: 'image' | 'document' | 'other';
  isPinned?: boolean;
  pinnedAt?: string;
  pinnedBy?: string;
  transactionAmount?: string;
}

export interface JMChatGroup {
  id: string;
  name: string;
  avatar: string;
  description: string;
  memberCount: number;
  isEndToEndEncrypted: boolean;
  lastMessage?: string;
  lastMessageTime?: string;
  unreadCount: number;
  adminName: string;
  tags: string[];
}

const CHAT_USERS_STORAGE_KEY = 'jm_chat_believer_roster_v2';
const CHAT_MESSAGES_STORAGE_KEY = 'jm_chat_messages_vault_v2';
const CHAT_GROUPS_STORAGE_KEY = 'jm_chat_groups_vault_v2';

export const INITIAL_CHAT_USERS: JMChatUser[] = [
  {
    id: 'user-ng-01',
    name: 'Brother Emmanuel Adebayo',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    country: 'Nigeria',
    city: 'Lagos',
    role: 'Kingdom Tech Entrepreneur & JMC Miner',
    bio: 'Pioneering decentralized Christian streaming & carrier billing infrastructure across West Africa.',
    isOnline: true,
    lastSeen: 'Online',
    businessSector: 'Fintech & Cloud Mining',
    connectionStatus: 'CONNECTED'
  },
  {
    id: 'user-uk-02',
    name: 'Sister Grace Henderson',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    country: 'United Kingdom',
    city: 'London',
    role: 'Global Trade Consultant & Intercessor',
    bio: 'Connecting sovereign gospel believers with verified licensed financial exchanges worldwide.',
    isOnline: true,
    lastSeen: 'Online',
    businessSector: 'Commodities & Digital Assets',
    connectionStatus: 'CONNECTED'
  },
  {
    id: 'user-us-03',
    name: 'Pastor Michael Jenkins',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    country: 'United States',
    city: 'Atlanta',
    role: 'Apostolic Network Overseer',
    bio: 'Leading multi-state prayer altars and spiritual gospel broadcast ministries.',
    isOnline: false,
    lastSeen: 'Offline (Seen 18m ago)',
    businessSector: 'Faith Media & Broadcasting',
    connectionStatus: 'PENDING_INCOMING',
    connectionRequestMessage: 'Pastor Michael Jenkins wants to be your friend and business partner, click on the ACCEPT button to connect with the user or click on the REJECT button to decline or revoke the friend and business partner request'
  },
  {
    id: 'user-ca-04',
    name: 'David Osei-Bonsu',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    country: 'Canada',
    city: 'Toronto',
    role: 'P2P Mesh Network Engineer',
    bio: 'Dedicated to hardware zero-fill cryptography and sovereign offline gospel distribution.',
    isOnline: true,
    lastSeen: 'Online',
    businessSector: 'Decentralized Infrastructure',
    connectionStatus: 'NONE'
  },
  {
    id: 'user-ke-05',
    name: 'Elder Samuel Kipchoge',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
    country: 'Kenya',
    city: 'Nairobi',
    role: 'East African Agricultural Exporter',
    bio: 'Expanding fair trade Kingdom business networks across the Great Lakes region.',
    isOnline: false,
    lastSeen: 'Offline (Seen 2h ago)',
    businessSector: 'Agro-Allied & Supply Chain',
    connectionStatus: 'NONE'
  },
  {
    id: 'user-ng-06',
    name: 'Chioma Okonkwo',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    country: 'Nigeria',
    city: 'Abuja',
    role: 'Real Estate Developer & JMC Treasury Partner',
    bio: 'Building sovereign residential sanctuaries and prophetic retreat centers.',
    isOnline: true,
    lastSeen: 'Online',
    businessSector: 'Real Estate & Construction',
    connectionStatus: 'NONE'
  },
  {
    id: 'user-za-07',
    name: 'Deacon John Mark',
    avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150&auto=format&fit=crop&q=80',
    country: 'South Africa',
    city: 'Johannesburg',
    role: 'Mining Hardware Architect',
    bio: 'Engineering high-efficiency Stratum ASIC miners and renewable solar power nodes.',
    isOnline: false,
    lastSeen: 'Offline (Seen 45m ago)',
    businessSector: 'Hardware & Energy',
    connectionStatus: 'NONE'
  },
  {
    id: 'user-gh-08',
    name: 'Evangelist Kwame Mensah',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
    country: 'Ghana',
    city: 'Accra',
    role: 'Worship Producer & Sound Engineer',
    bio: 'Recording 528Hz soaking frequencies and gospel albums in West Africa.',
    isOnline: true,
    lastSeen: 'Online',
    businessSector: 'Music Production & Mastering',
    connectionStatus: 'NONE'
  },
  {
    id: 'user-de-09',
    name: 'Hannah Weber',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    country: 'Germany',
    city: 'Berlin',
    role: 'Cryptographic Security Auditor',
    bio: 'Auditing smart contracts and zero-knowledge privacy layers for European Kingdom believers.',
    isOnline: true,
    lastSeen: 'Online',
    businessSector: 'Cybersecurity & Cryptography',
    connectionStatus: 'NONE'
  },
  {
    id: 'user-us-10',
    name: 'Minister Sarah Vance',
    avatar: 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?w=150&auto=format&fit=crop&q=80',
    country: 'United States',
    city: 'Dallas',
    role: 'Kingdom Angel Investor',
    bio: 'Funding innovative Christian technologies, gospel media, and sovereign banking apps.',
    isOnline: false,
    lastSeen: 'Offline (Seen 5m ago)',
    businessSector: 'Venture Capital & Finance',
    connectionStatus: 'NONE'
  }
];

export const INITIAL_GROUPS: JMChatGroup[] = [
  {
    id: 'group-001',
    name: '👑 JUHNKRIX Kingdom Believers Global',
    avatar: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=150&auto=format&fit=crop&q=80',
    description: 'Official global community fellowship of Prophet JUHNKRIX SYNVAGORD. Daily worship, prophetic prayers, and testimonies.',
    memberCount: 42180,
    isEndToEndEncrypted: true,
    lastMessage: 'Prophet Juhnkrix: "The glory of the Lord is resting mightily upon every believer today!"',
    lastMessageTime: '10:42 AM',
    unreadCount: 3,
    adminName: 'Prophet JUHNKRIX SYNVAGORD',
    tags: ['General', 'Worship', 'Global']
  },
  {
    id: 'group-002',
    name: '💎 JMC Crypto Miners & Investors Alliance',
    avatar: 'https://images.unsplash.com/photo-1621416894569-0f39ed31d247?w=150&auto=format&fit=crop&q=80',
    description: 'Decentralized JMC mining optimization, Stratum pool sync, carrier billing tips, and treasury discussions.',
    memberCount: 18950,
    isEndToEndEncrypted: true,
    lastMessage: 'Emmanuel Adebayo: "Difficulty adjustment complete! Hashrate peaking at 48.2 TH/s."',
    lastMessageTime: '11:15 AM',
    unreadCount: 0,
    adminName: 'Emmanuel Adebayo',
    tags: ['Crypto', 'Mining', 'JMC']
  },
  {
    id: 'group-003',
    name: '📈 Global Sovereign Trade & Business Partners',
    avatar: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=150&auto=format&fit=crop&q=80',
    description: 'High-trust B2B Christian enterprise, cross-border settlements, exchange liquidity, and verified partnerships.',
    memberCount: 9420,
    isEndToEndEncrypted: true,
    lastMessage: 'Sister Grace: "New liquidity pool established on verified tier-1 licensed exchange."',
    lastMessageTime: '09:30 AM',
    unreadCount: 1,
    adminName: 'Grace Henderson',
    tags: ['Trade', 'Business', 'Finance']
  },
  {
    id: 'group-004',
    name: '🕊️ Prophetic Intercessors & Soaking Fellowship',
    avatar: 'https://images.unsplash.com/photo-1507692049790-de58290a4334?w=150&auto=format&fit=crop&q=80',
    description: '24/7 Spiritual prayer altar, 528Hz soaking frequencies, healing intercession, and divine decrees.',
    memberCount: 31200,
    isEndToEndEncrypted: true,
    lastMessage: 'Pastor Michael: "Praying for divine health and financial breakthrough across all nations."',
    lastMessageTime: 'Yesterday',
    unreadCount: 0,
    adminName: 'Pastor Michael Jenkins',
    tags: ['Prayer', 'Soaking', 'Spiritual']
  }
];

export class JMChatService {
  private users: JMChatUser[] = [];
  private groups: JMChatGroup[] = [];
  private messages: Record<string, JMChatMessage[]> = {};
  private listeners: Array<() => void> = [];

  constructor() {
    this.loadState();
  }

  private loadState() {
    try {
      const savedUsers = localStorage.getItem(CHAT_USERS_STORAGE_KEY);
      this.users = savedUsers ? JSON.parse(savedUsers) : INITIAL_CHAT_USERS;
    } catch {
      this.users = INITIAL_CHAT_USERS;
    }

    try {
      const savedGroups = localStorage.getItem(CHAT_GROUPS_STORAGE_KEY);
      this.groups = savedGroups ? JSON.parse(savedGroups) : INITIAL_GROUPS;
    } catch {
      this.groups = INITIAL_GROUPS;
    }

    try {
      const savedMsgs = localStorage.getItem(CHAT_MESSAGES_STORAGE_KEY);
      this.messages = savedMsgs ? JSON.parse(savedMsgs) : this.generateSeedMessages();
    } catch {
      this.messages = this.generateSeedMessages();
    }
  }

  private saveState() {
    try {
      localStorage.setItem(CHAT_USERS_STORAGE_KEY, JSON.stringify(this.users));
      localStorage.setItem(CHAT_GROUPS_STORAGE_KEY, JSON.stringify(this.groups));
      localStorage.setItem(CHAT_MESSAGES_STORAGE_KEY, JSON.stringify(this.messages));
    } catch {}
    this.notify();
  }

  private generateSeedMessages(): Record<string, JMChatMessage[]> {
    return {
      'user-ng-01': [
        {
          id: 'msg-ng-01',
          conversationId: 'user-ng-01',
          senderId: 'user-ng-01',
          senderName: 'Brother Emmanuel Adebayo',
          senderAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
          text: 'Shalom my beloved brother! The 528Hz gospel audio stream is sounding super clear on our Lagos offline node.',
          timestamp: '10:14 AM',
          isEndToEndEncrypted: true,
          status: 'read',
          messageType: 'text'
        },
        {
          id: 'msg-ng-02',
          conversationId: 'user-ng-01',
          senderId: 'me',
          senderName: 'You (JUHNKRIX Believer)',
          senderAvatar: '/favicon.svg',
          text: 'Praise the Lord Emmanuel! How is the JMC mining hashrate performing on the Carrier node today?',
          timestamp: '10:18 AM',
          isEndToEndEncrypted: true,
          status: 'read',
          messageType: 'text'
        },
        {
          id: 'msg-ng-03',
          conversationId: 'user-ng-01',
          senderId: 'user-ng-01',
          senderName: 'Brother Emmanuel Adebayo',
          senderAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
          text: 'We reached 1.2 JMC per hour with zero network drops! Truly sovereign.',
          timestamp: '10:20 AM',
          isEndToEndEncrypted: true,
          status: 'read',
          messageType: 'text'
        }
      ],
      'group-001': [
        {
          id: 'grp-01',
          conversationId: 'group-001',
          senderId: 'prophet',
          senderName: 'Prophet JUHNKRIX SYNVAGORD',
          senderAvatar: '/favicon.svg',
          text: 'Beloved Kingdom family, welcome to our end-to-end encrypted global sanctuary. Speak peace, exchange honest trade, and lift up one another.',
          timestamp: '08:00 AM',
          isEndToEndEncrypted: true,
          status: 'read',
          messageType: 'text'
        },
        {
          id: 'grp-02',
          conversationId: 'group-001',
          senderId: 'user-uk-02',
          senderName: 'Sister Grace Henderson',
          senderAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
          text: 'Amen Prophet! Connected directly from London. The presence of God is tangible.',
          timestamp: '08:24 AM',
          isEndToEndEncrypted: true,
          status: 'read',
          messageType: 'text'
        }
      ]
    };
  }

  public getUsers(): JMChatUser[] {
    return [...this.users];
  }

  public getGroups(): JMChatGroup[] {
    return [...this.groups];
  }

  public getMessages(conversationId: string): JMChatMessage[] {
    return this.messages[conversationId] || [];
  }

  public getCountries(): string[] {
    return ['All Countries', ...getAllCountryNames()];
  }

  public ensureCountryUsers(countryName: string) {
    if (!countryName || countryName === 'All Countries') return;
    const existing = this.users.filter(u => u.country.toLowerCase() === countryName.toLowerCase());
    if (existing.length >= 2) return;

    const countryMeta = ALL_WORLD_COUNTRIES.find(c => c.name.toLowerCase() === countryName.toLowerCase());
    const cityName = countryMeta?.capital || (countryMeta as any)?.majorCity || 'Central Sanctuary';
    const flag = countryMeta?.flag || '🌐';

    const sampleAvatars = [
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80'
    ];

    const code = countryMeta?.code.toLowerCase() || 'node';
    const newBelievers: JMChatUser[] = [
      {
        id: `user-${code}-${Date.now()}-1`,
        name: `Deacon Caleb (${countryName})`,
        avatar: sampleAvatars[Math.floor(Math.random() * sampleAvatars.length)],
        country: countryName,
        city: cityName,
        role: `Kingdom Business Ambassador & Believer (${flag} ${countryName})`,
        bio: `Faithful believer spreading the prophetic anointing and trading on the JUHNKRIX decentralized network in ${cityName}.`,
        isOnline: true,
        lastSeen: 'Online',
        businessSector: 'Kingdom Commerce & Digital Assets',
        connectionStatus: 'NONE'
      },
      {
        id: `user-${code}-${Date.now()}-2`,
        name: `Sister Joy (${countryName})`,
        avatar: sampleAvatars[Math.floor(Math.random() * sampleAvatars.length)],
        country: countryName,
        city: cityName,
        role: `Prophetic Intercessor & Enterprise Partner (${flag} ${countryName})`,
        bio: `Active prayer altar coordinator and verified trade partner serving ${countryName}.`,
        isOnline: false,
        lastSeen: 'Offline (Seen 12m ago)',
        businessSector: 'Faith Media & Agriculture',
        connectionStatus: 'NONE'
      }
    ];

    this.users.push(...newBelievers);
    this.saveState();
  }

  /**
   * Search users by name, query text, country filter, or alphabetical starting letter
   */
  public searchUsers(query: string, country?: string, alphabet?: string): JMChatUser[] {
    if (country && country !== 'All Countries') {
      this.ensureCountryUsers(country);
    }

    return this.users.filter((user) => {
      // Country filter
      if (country && country !== 'All Countries' && user.country.toLowerCase() !== country.toLowerCase()) {
        return false;
      }

      // Alphabetical filter (A-Z)
      if (alphabet && alphabet !== 'ALL') {
        const firstLetter = user.name.trim().charAt(0).toUpperCase();
        if (firstLetter !== alphabet.toUpperCase()) {
          return false;
        }
      }

      // Text Query filter
      if (query.trim()) {
        const q = query.toLowerCase().trim();
        const matches =
          user.name.toLowerCase().includes(q) ||
          user.city.toLowerCase().includes(q) ||
          user.country.toLowerCase().includes(q) ||
          user.role.toLowerCase().includes(q) ||
          user.businessSector.toLowerCase().includes(q);
        if (!matches) return false;
      }

      return true;
    });
  }

  /**
   * Send a Connection Request to a target user
   */
  public sendConnectionRequest(targetUserId: string): { success: boolean; message: string } {
    const idx = this.users.findIndex(u => u.id === targetUserId);
    if (idx === -1) return { success: false, message: 'User not found.' };

    const targetUser = this.users[idx];
    targetUser.connectionStatus = 'PENDING_OUTGOING';
    this.users[idx] = targetUser;
    this.saveState();

    // Trigger notification on target side
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('juhnkrix_chat_connection_requested', {
        detail: {
          targetUserId: targetUser.id,
          targetUserName: targetUser.name,
          message: `${targetUser.name} wants to be your friend and business partner, click on the ACCEPT button to connect with the user or click on the REJECT button to decline or revoke the friend and business partner request`
        }
      }));
    }

    return {
      success: true,
      message: `Connection request sent to ${targetUser.name}! They will be notified to ACCEPT or REJECT.`
    };
  }

  /**
   * Accept an incoming connection request
   */
  public acceptConnection(targetUserId: string): { success: boolean; message: string } {
    const idx = this.users.findIndex(u => u.id === targetUserId);
    if (idx === -1) return { success: false, message: 'User not found.' };

    const targetUser = this.users[idx];
    targetUser.connectionStatus = 'CONNECTED';
    targetUser.connectionRequestMessage = undefined;
    this.users[idx] = targetUser;

    // Initialize welcome E2EE message
    if (!this.messages[targetUserId]) {
      this.messages[targetUserId] = [
        {
          id: `e2ee-init-${Date.now()}`,
          conversationId: targetUserId,
          senderId: 'system',
          senderName: 'JUHNKRIX E2EE Protocol',
          senderAvatar: '/favicon.svg',
          text: `🔒 Direct end-to-end encryption established with ${targetUser.name}. All chats, communications, and business transactions between you are fully private and encrypted.`,
          timestamp: 'Just now',
          isEndToEndEncrypted: true,
          status: 'read',
          messageType: 'text'
        }
      ];
    }

    this.saveState();

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('juhnkrix_chat_connection_accepted', {
        detail: {
          targetUserId: targetUser.id,
          targetUserName: targetUser.name,
          message: `✓ You and ${targetUser.name} are now connected as friends and business partners!`
        }
      }));
    }

    return {
      success: true,
      message: `✓ You and ${targetUser.name} are now connected as friends and business partners!`
    };
  }

  /**
   * Reject an incoming connection request
   */
  public rejectConnection(targetUserId: string): { success: boolean; message: string } {
    const idx = this.users.findIndex(u => u.id === targetUserId);
    if (idx === -1) return { success: false, message: 'User not found.' };

    const targetUser = this.users[idx];
    targetUser.connectionStatus = 'REJECTED';
    targetUser.connectionRequestMessage = undefined;
    this.users[idx] = targetUser;
    this.saveState();

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('juhnkrix_chat_connection_rejected', {
        detail: {
          targetUserId: targetUser.id,
          targetUserName: targetUser.name,
          message: `Connection request with ${targetUser.name} was rejected.`
        }
      }));
    }

    return {
      success: true,
      message: `Connection request with ${targetUser.name} was declined.`
    };
  }

  /**
   * Send a message inside a 1-on-1 or group chat
   */
  public sendMessage(
    conversationId: string,
    text: string,
    messageType: 'text' | 'voice_note' | 'business_deal' | 'prayer_note' = 'text',
    attachmentUrl?: string
  ): JMChatMessage {
    const list = this.messages[conversationId] || [];
    const newMsg: JMChatMessage = {
      id: `msg-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      conversationId,
      senderId: 'me',
      senderName: 'You (JUHNKRIX Believer)',
      senderAvatar: '/favicon.svg',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isEndToEndEncrypted: true,
      status: 'delivered',
      messageType,
      attachmentUrl
    };

    list.push(newMsg);
    this.messages[conversationId] = list;

    // Update group last message if conversation is a group
    const grp = this.groups.find(g => g.id === conversationId);
    if (grp) {
      grp.lastMessage = `You: ${text}`;
      grp.lastMessageTime = newMsg.timestamp;
    }

    this.saveState();

    // Simulate realistic E2EE response after 1.5 seconds if 1-on-1 chat
    if (!conversationId.startsWith('group-')) {
      const partner = this.users.find(u => u.id === conversationId);
      if (partner && partner.isOnline) {
        setTimeout(() => {
          this.simulatePartnerReply(partner, conversationId);
        }, 1500);
      }
    }

    return newMsg;
  }

  private simulatePartnerReply(partner: JMChatUser, conversationId: string) {
    const replies = [
      `Amen! Receiving your message with divine peace. The Lord bless your business and investments!`,
      `Thank you my partner! Let us continue building sovereign wealth for the Kingdom.`,
      `Hallelujah! Our E2EE connection is unbroken and secure on JUHNKRIX MUSIKA network.`,
      `Glory to God! Looking forward to finalizing our JMC trade agreement.`
    ];
    const replyText = replies[Math.floor(Math.random() * replies.length)];

    const replyMsg: JMChatMessage = {
      id: `reply-${Date.now()}`,
      conversationId,
      senderId: partner.id,
      senderName: partner.name,
      senderAvatar: partner.avatar,
      text: replyText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isEndToEndEncrypted: true,
      status: 'read',
      messageType: 'text'
    };

    const list = this.messages[conversationId] || [];
    list.push(replyMsg);
    this.messages[conversationId] = list;
    this.saveState();
  }

  /**
   * Create a new E2EE Group Chat
   */
  public createGroup(name: string, description: string, avatar?: string, tags: string[] = ['Kingdom']): JMChatGroup {
    const defaultAvatars = [
      'https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=150&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=150&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=150&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=150&auto=format&fit=crop&q=80'
    ];
    const selectedAvatar = avatar || defaultAvatars[Math.floor(Math.random() * defaultAvatars.length)];

    const newGroup: JMChatGroup = {
      id: `group-${Date.now()}`,
      name: name.startsWith('👥') ? name : `👥 ${name}`,
      avatar: selectedAvatar,
      description,
      memberCount: 1,
      isEndToEndEncrypted: true,
      lastMessage: 'Group created with end-to-end encryption.',
      lastMessageTime: 'Just now',
      unreadCount: 0,
      adminName: 'You (Creator)',
      tags
    };

    this.groups.unshift(newGroup);
    this.messages[newGroup.id] = [
      {
        id: `sys-grp-${Date.now()}`,
        conversationId: newGroup.id,
        senderId: 'system',
        senderName: 'JUHNKRIX E2EE Protocol',
        senderAvatar: '/favicon.svg',
        text: `🔒 Messages and calls are end-to-end encrypted. No one outside of this group, not even JUHNKRIX MUSIKA, can read or listen to them.`,
        timestamp: 'Just now',
        isEndToEndEncrypted: true,
        status: 'read',
        messageType: 'text'
      }
    ];

    this.saveState();
    return newGroup;
  }

  public updateGroupAvatar(groupId: string, newAvatar: string): { success: boolean; message: string } {
    const idx = this.groups.findIndex(g => g.id === groupId);
    if (idx === -1) return { success: false, message: 'Group not found.' };

    this.groups[idx].avatar = newAvatar;
    this.saveState();

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('juhnkrix_group_avatar_updated', {
        detail: {
          groupId,
          newAvatar,
          message: `✓ Group avatar successfully updated and synchronized across the decentralized network!`
        }
      }));
    }

    return {
      success: true,
      message: `✓ Group avatar successfully updated and synchronized across the decentralized network!`
    };
  }

  /**
   * Pin a specific message in a chat or group thread (persisted in local storage)
   */
  public pinMessage(conversationId: string, messageId: string, pinnedBy: string = 'You'): boolean {
    const list = this.messages[conversationId];
    if (!list) return false;

    const msg = list.find(m => m.id === messageId);
    if (!msg) return false;

    msg.isPinned = true;
    msg.pinnedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    msg.pinnedBy = pinnedBy;

    this.saveState();

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('juhnkrix_message_pinned', {
        detail: {
          conversationId,
          messageId,
          pinnedMessage: msg,
          message: `📌 Message pinned for all group participants!`
        }
      }));
    }

    return true;
  }

  /**
   * Unpin a specific message
   */
  public unpinMessage(conversationId: string, messageId: string): boolean {
    const list = this.messages[conversationId];
    if (!list) return false;

    const msg = list.find(m => m.id === messageId);
    if (!msg) return false;

    msg.isPinned = false;
    msg.pinnedAt = undefined;
    msg.pinnedBy = undefined;

    this.saveState();

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('juhnkrix_message_unpinned', {
        detail: { conversationId, messageId }
      }));
    }

    return true;
  }

  /**
   * Get all pinned messages for a conversation
   */
  public getPinnedMessages(conversationId: string): JMChatMessage[] {
    const list = this.messages[conversationId] || [];
    return list.filter(m => m.isPinned);
  }

  /**
   * Mark all unread messages in conversation as read and propagate status
   */
  public markConversationRead(conversationId: string, readerId: string = 'me'): void {
    const list = this.messages[conversationId];
    if (!list || list.length === 0) return;

    let hasChanges = false;
    list.forEach(msg => {
      if (msg.status !== 'read' && msg.senderId !== readerId) {
        msg.status = 'read';
        hasChanges = true;
      }
    });

    if (hasChanges) {
      this.saveState();
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('juhnkrix_messages_read', {
          detail: { conversationId, readerId }
        }));
      }
    }
  }

  /**
   * Send a secure E2EE file/document/image message
   */
  public sendFileMessage(
    conversationId: string,
    fileData: {
      name: string;
      sizeFormatted: string;
      dataUrl: string;
      type: 'image' | 'document';
      caption?: string;
    }
  ): JMChatMessage {
    const list = this.messages[conversationId] || [];
    const fallbackText = fileData.caption?.trim()
      ? fileData.caption.trim()
      : fileData.type === 'image'
      ? `📷 Secure E2EE Image: ${fileData.name}`
      : `📄 Secure E2EE Document: ${fileData.name}`;

    const newMsg: JMChatMessage = {
      id: `msg-file-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      conversationId,
      senderId: 'me',
      senderName: 'You (JUHNKRIX Believer)',
      senderAvatar: '/favicon.svg',
      text: fallbackText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isEndToEndEncrypted: true,
      status: 'delivered',
      messageType: 'file',
      attachmentUrl: fileData.dataUrl,
      attachmentName: fileData.name,
      attachmentSize: fileData.sizeFormatted,
      attachmentType: fileData.type
    };

    list.push(newMsg);
    this.messages[conversationId] = list;

    // Update group last message if conversation is a group
    const grp = this.groups.find(g => g.id === conversationId);
    if (grp) {
      grp.lastMessage = `You: Shared ${fileData.type === 'image' ? 'photo' : 'document'} (${fileData.name})`;
      grp.lastMessageTime = newMsg.timestamp;
    }

    this.saveState();

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('juhnkrix_file_message_sent', {
        detail: { conversationId, message: newMsg }
      }));
    }

    return newMsg;
  }

  public subscribe(cb: () => void): () => void {
    this.listeners.push(cb);
    return () => {
      this.listeners = this.listeners.filter(l => l !== cb);
    };
  }

  private notify() {
    this.listeners.forEach(cb => cb());
  }
}

export const jmChatService = new JMChatService();
