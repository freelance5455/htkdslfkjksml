export const BRASILIA = "America/Sao_Paulo";

export type ClockParts = {
  hour: string;
  minute: string;
  second: string;
  weekday: string;
  day: string;
  month: string;
  monthShort: string;
  year: string;
};

export function clockParts(date: Date, timeZone: string): ClockParts {
  const full = new Intl.DateTimeFormat("pt-BR", {
    timeZone,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
    hourCycle: "h23",
  }).formatToParts(date);

  const pick = (type: Intl.DateTimeFormatPartTypes) =>
    full.find((part) => part.type === type)?.value ?? "";

  const monthShort = new Intl.DateTimeFormat("pt-BR", {
    timeZone,
    month: "short",
  })
    .format(date)
    .replace(".", "");

  return {
    hour: pick("hour"),
    minute: pick("minute"),
    second: pick("second"),
    weekday: pick("weekday"),
    day: pick("day"),
    month: pick("month"),
    monthShort,
    year: pick("year"),
  };
}

/** Civil date in a timezone, as YYYY-MM-DD. */
export function zonedIso(date: Date, timeZone: string): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(date);
}

export function dateFromIso(iso: string): Date {
  const [year, month, day] = iso.split("-").map(Number);
  return new Date(year, month - 1, day, 12, 0, 0, 0);
}

export function addDaysIso(iso: string, days: number): string {
  const date = dateFromIso(iso);
  date.setDate(date.getDate() + days);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function diffDays(fromIso: string, toIso: string): number {
  const [y1, m1, d1] = fromIso.split("-").map(Number);
  const [y2, m2, d2] = toIso.split("-").map(Number);
  const start = Date.UTC(y1, m1 - 1, d1);
  const end = Date.UTC(y2, m2 - 1, d2);
  return Math.round((end - start) / 86_400_000);
}

export function formatLongDate(iso: string): string {
  return new Intl.DateTimeFormat("pt-BR", {
    weekday: "long",
    day: "numeric",
    month: "long",
  }).format(dateFromIso(iso));
}

export function formatShortDate(iso: string): string {
  return new Intl.DateTimeFormat("pt-BR", {
    day: "numeric",
    month: "short",
  })
    .format(dateFromIso(iso))
    .replace(".", "");
}

export type IsoWeek = { year: number; week: number };

export function isoWeek(iso: string): IsoWeek {
  const date = dateFromIso(iso);
  const utc = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const day = utc.getUTCDay() || 7;
  utc.setUTCDate(utc.getUTCDate() + 4 - day);
  const yearStart = new Date(Date.UTC(utc.getUTCFullYear(), 0, 1));
  const week = Math.ceil(((utc.getTime() - yearStart.getTime()) / 86_400_000 + 1) / 7);
  return { year: utc.getUTCFullYear(), week };
}

/** Monday–Sunday range containing this civil date. */
export function weekBounds(iso: string): { start: string; end: string } {
  const date = dateFromIso(iso);
  const dow = date.getDay();
  const mondayOffset = dow === 0 ? -6 : 1 - dow;
  const start = addDaysIso(iso, mondayOffset);
  return { start, end: addDaysIso(start, 6) };
}

export function sentenceCase(value: string): string {
  if (!value) return value;
  return value.charAt(0).toLocaleUpperCase("pt-BR") + value.slice(1);
}

export function localTimeZone(): string {
  return Intl.DateTimeFormat().resolvedOptions().timeZone || BRASILIA;
}
