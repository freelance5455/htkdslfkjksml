// ============================================================
// AI CREATOR STUDIO — FAST MULTIMODAL GENERATOR ENGINE
// Ultra-fast parallel generation for Video, Image, and Audio
// ============================================================

import type {
  Project,
  ContentBrief,
  Script,
  ScriptSection,
  Storyboard,
  StoryboardScene,
  MediaAsset,
  Timeline,
  AITask,
  AnalyzedRequest,
  Platform,
  ContentType,
  OutputFormat,
} from "@/types";
import type { VideoEngineId } from "@/types/video";
import type { ImageEngineId, ImageVisualStyle } from "@/types/image";
import type { AudioEngineId, AudioVoiceId, MusicGenreId } from "@/types/audio";
import { generateId, sleep } from "@/lib/utils";
import { saveProject, getProject } from "@/lib/storage";
import { analyzeRequestAsync } from "@/lib/analyzer";
import { generateBrief, generateScript, generateStoryboard, generateTimeline, createWorkflowTasks, getWelcomeChatMessage } from "@/lib/orchestrator";
import { generateImageWithEngine } from "@/lib/imageEngine";
import { generateTTSAudio, generateMusicAudio } from "@/lib/audioEngine";
import { generateVideoWithEngine } from "@/lib/videoEngine";
import { CONTENT_TYPE_LABELS } from "@/constants";

export interface FastGeneratorOptions {
  videoEngine?: VideoEngineId;
  imageEngine?: ImageEngineId;
  imageStyle?: ImageVisualStyle;
  audioEngine?: AudioEngineId;
  voiceId?: AudioVoiceId;
  musicGenre?: MusicGenreId;
  generateVideos?: boolean;
  generateImages?: boolean;
  generateAudio?: boolean;
  platform?: Platform;
  aspectRatio?: "16:9" | "9:16" | "1:1" | "4:5";
  contentType?: ContentType;
  outputFormat?: OutputFormat;
  onProgress?: (stage: string, percent: number, details?: string) => void;
}

/**
 * Creates a complete project from prompt in seconds, generating Script, Storyboard,
 * and executing parallel batch generation for Images, Audio (TTS + Music), and Videos.
 */
export async function generateFullProjectFast(
  prompt: string,
  options: FastGeneratorOptions = {}
): Promise<Project> {
  const {
    videoEngine = "veo-2",
    imageEngine = "imagen-3",
    imageStyle = "CINEMATIC",
    audioEngine = "gemini-tts",
    voiceId = "kore",
    musicGenre = "CINEMATIC_ORCHESTRAL",
    generateVideos = true,
    generateImages = true,
    generateAudio = true,
    platform: selectedPlatform,
    aspectRatio: selectedAspectRatio,
    contentType: selectedContentType,
    outputFormat: selectedOutputFormat,
    onProgress,
  } = options;

  const now = new Date().toISOString();

  // STAGE 1: Fast Analysis & Blueprint
  onProgress?.("Analisando pedido com Gemini 3.7 Flash...", 15, "Definindo nicho, formato e tom");
  const analyzed: AnalyzedRequest = await analyzeRequestAsync(prompt);

  const targetPlatform: Platform = selectedPlatform && selectedPlatform !== "GENERAL"
    ? selectedPlatform
    : analyzed.platform;

  const targetContentType: ContentType = selectedContentType || (
    selectedAspectRatio === "9:16" ? "SHORT" :
    targetPlatform === "TIKTOK" ? "TIKTOK_VIDEO" :
    targetPlatform === "INSTAGRAM" && selectedAspectRatio === "9:16" ? "REEL" :
    targetPlatform === "INSTAGRAM" && selectedAspectRatio === "1:1" ? "INSTAGRAM_POST" :
    analyzed.contentType
  );

  const targetOutputFormat: OutputFormat = selectedOutputFormat || (
    selectedAspectRatio === "9:16" || targetPlatform === "TIKTOK" || targetContentType === "SHORT" || targetContentType === "REEL"
      ? "SHORTS_1080p"
      : selectedAspectRatio === "1:1" || targetContentType === "INSTAGRAM_POST"
      ? "INSTAGRAM_SQUARE"
      : "YOUTUBE_1080p"
  );

  const effectiveAspectRatio: "16:9" | "9:16" | "1:1" | "4:5" = selectedAspectRatio || (
    targetOutputFormat === "SHORTS_1080p" || targetPlatform === "TIKTOK" || targetContentType === "SHORT" || targetContentType === "REEL"
      ? "9:16"
      : targetOutputFormat === "INSTAGRAM_SQUARE"
      ? "1:1"
      : "16:9"
  );

  const projectId = generateId();
  const title = analyzed.topic && analyzed.topic.length > 5
    ? analyzed.topic.split(" ").slice(0, 6).join(" ")
    : `Projeto ${CONTENT_TYPE_LABELS[targetContentType] || "Vídeo"}`;

  let project: Project = {
    id: projectId,
    title,
    description: prompt,
    status: "GENERATING",
    contentType: targetContentType,
    platform: targetPlatform,
    outputFormats: [targetOutputFormat],
    analyzedRequest: analyzed,
    assets: [],
    characters: [],
    tasks: [],
    versions: [],
    conversation: [],
    tags: analyzed.requirements || [],
    settings: {
      language: analyzed.language || "PT_BR",
      outputFormat: targetOutputFormat,
      targetDuration: analyzed.duration || (effectiveAspectRatio === "9:16" ? 60 : 120),
      autoEdit: true,
      autoSubtitles: true,
      watermark: false,
    },
    createdAt: now,
    updatedAt: now,
  };

  // STAGE 2: Build Brief, Script, and Storyboard structure rapidly
  onProgress?.("Estruturando Roteiro & Cenas de Storyboard...", 30, "Gerando estrutura narrativa de alta conversão");
  
  const brief = generateBrief(project);
  brief.status = "APPROVED";
  project.brief = brief;

  const script = generateScript(project);
  script.status = "APPROVED";
  project.script = script;

  const storyboard = generateStoryboard(project);
  storyboard.status = "APPROVED";
  project.storyboard = storyboard;

  project.timeline = generateTimeline(project);
  project.tasks = createWorkflowTasks(project);
  project.conversation = [getWelcomeChatMessage(project)];

  const scenes = storyboard.scenes;
  const assets: MediaAsset[] = [];

  // STAGE 3: Parallel High-Speed Generation of Images, Audio, and Video
  onProgress?.("Gerando mídias em paralelo (Vídeo, Imagem e Áudio)...", 50, `Processando ${scenes.length} cenas simultaneamente`);

  // 3.1 Parallel Images Promise
  const imagesPromise = generateImages
    ? Promise.all(
        scenes.map(async (scene) => {
          try {
            const imgPrompt = scene.imagePrompt || `${project.title}, ${scene.visualDescription}`;
            const res = await generateImageWithEngine({
              prompt: imgPrompt,
              engine: imageEngine,
              aspectRatio: project.settings.outputFormat === "9:16" ? "9:16" : "16:9",
              resolution: "1080p",
              style: imageStyle,
              sceneId: scene.id,
              sceneNumber: scene.sceneNumber,
              projectId: project.id,
              projectTitle: project.title,
            });
            return { sceneId: scene.id, result: res };
          } catch (err) {
            console.warn(`[FastGen] Erro na imagem cena ${scene.sceneNumber}:`, err);
            return null;
          }
        })
      )
    : Promise.resolve([]);

  // 3.2 Parallel Audio Promise (TTS for each scene + Background Music)
  const audioPromise = generateAudio
    ? Promise.all([
        // Narration for all scenes
        ...scenes.map(async (scene) => {
          try {
            const textToSpeak = scene.narration || scene.visualDescription || project.title;
            const res = await generateTTSAudio({
              text: textToSpeak,
              engine: audioEngine,
              voiceId,
              tone: "DOCUMENTARY_NARRATOR",
              sceneId: scene.id,
              sceneNumber: scene.sceneNumber,
              sectionTitle: `Cena ${scene.sceneNumber}`,
              projectId: project.id,
              projectTitle: project.title,
            });
            return { type: "TTS" as const, sceneId: scene.id, result: res };
          } catch (err) {
            console.warn(`[FastGen] Erro no TTS cena ${scene.sceneNumber}:`, err);
            return null;
          }
        }),
        // Background Music
        (async () => {
          try {
            const musicRes = await generateMusicAudio({
              genre: musicGenre,
              duration: brief.duration || 60,
              projectId: project.id,
              sceneId: scenes[0]?.id,
            });
            return { type: "MUSIC" as const, sceneId: undefined, result: musicRes };
          } catch (err) {
            console.warn("[FastGen] Erro na trilha de música:", err);
            return null;
          }
        })(),
      ])
    : Promise.resolve([]);

  // 3.3 Parallel Video Promise
  const videoPromise = generateVideos
    ? Promise.all(
        scenes.map(async (scene, i) => {
          try {
            const vidPrompt = scene.videoPrompt || scene.visualDescription || `Cena ${scene.sceneNumber}`;
            const res = await generateVideoWithEngine({
              engine: videoEngine,
              prompt: vidPrompt,
              cameraMotion: i === 0 ? "PAN_RIGHT" : i % 2 === 0 ? "ORBIT" : "ZOOM_IN",
              cameraAngle: "WIDE",
              style: "CINEMATIC",
              duration: Math.min(scene.duration || 6, 10),
              aspectRatio: effectiveAspectRatio === "9:16" ? "9:16" : effectiveAspectRatio === "1:1" ? "1:1" : "16:9",
              resolution: "1080p",
              fps: 30,
              sceneId: scene.id,
              sceneNumber: scene.sceneNumber,
              projectId: project.id,
              projectTitle: project.title,
            });
            return { sceneId: scene.id, result: res };
          } catch (err) {
            console.warn(`[FastGen] Erro no vídeo cena ${scene.sceneNumber}:`, err);
            return null;
          }
        })
      )
    : Promise.resolve([]);

  // Wait for all concurrent media pipelines to complete
  onProgress?.("Sincronizando mídias e timeline...", 80, "Consolidando renders, áudio e vídeo");
  const [imageResults, audioResults, videoResults] = await Promise.all([
    imagesPromise,
    audioPromise,
    videoPromise,
  ]);

  // STAGE 4: Attach generated media to scenes and MediaAssets
  const updatedScenes: StoryboardScene[] = scenes.map((scene) => {
    const imgMatch = imageResults.find((r) => r?.sceneId === scene.id);
    const vidMatch = videoResults.find((r) => r?.sceneId === scene.id);

    const imageUrl = imgMatch?.result?.imageUrl || scene.imageUrl;
    const videoUrl = vidMatch?.result?.videoUrl || scene.videoUrl;

    if (imgMatch?.result) {
      assets.push({
        id: imgMatch.result.id,
        projectId: project.id,
        projectTitle: project.title,
        type: "IMAGE",
        name: `Imagem Cena ${scene.sceneNumber}`,
        url: imgMatch.result.imageUrl,
        thumbnailUrl: imgMatch.result.thumbnailUrl,
        status: "COMPLETED",
        prompt: imgMatch.result.prompt,
        provider: imgMatch.result.engineName,
        model: imgMatch.result.engine,
        createdAt: imgMatch.result.createdAt,
      });
    }

    if (vidMatch?.result) {
      assets.push({
        id: vidMatch.result.id,
        projectId: project.id,
        projectTitle: project.title,
        type: "VIDEO",
        name: `Vídeo Cena ${scene.sceneNumber} — ${vidMatch.result.engineName}`,
        url: vidMatch.result.videoUrl,
        thumbnailUrl: vidMatch.result.thumbnailUrl,
        status: "COMPLETED",
        prompt: vidMatch.result.prompt,
        provider: vidMatch.result.engineName,
        model: vidMatch.result.engine,
        duration: vidMatch.result.duration,
        createdAt: vidMatch.result.createdAt,
      });
    }

    return {
      ...scene,
      imageUrl: imageUrl || vidMatch?.result?.thumbnailUrl,
      videoUrl: videoUrl,
      status: "COMPLETED" as const,
    };
  });

  // Attach audio assets
  audioResults.forEach((item) => {
    if (!item?.result) return;
    const isMusic = item.type === "MUSIC";
    assets.push({
      id: item.result.id,
      projectId: project.id,
      projectTitle: project.title,
      type: isMusic ? "MUSIC" : "VOICE",
      name: item.result.title || (isMusic ? "Trilha Sonora" : "Narração de Cena"),
      url: item.result.audioUrl,
      status: "COMPLETED",
      provider: item.result.engineName,
      model: item.result.engine,
      duration: item.result.duration,
      createdAt: item.result.createdAt,
    });
  });

  // Update tasks to completed
  const completedTasks: AITask[] = project.tasks.map((task) => ({
    ...task,
    status: "COMPLETED" as const,
    progress: 100,
    completedAt: new Date().toISOString(),
  }));

  project = {
    ...project,
    status: "COMPLETED",
    storyboard: {
      ...storyboard,
      scenes: updatedScenes,
      status: "APPROVED",
    },
    assets,
    tasks: completedTasks,
    updatedAt: new Date().toISOString(),
  };

  saveProject(project);

  onProgress?.("Projeto completo gerado com sucesso!", 100, "Vídeo, imagem e áudio prontos para reprodução");
  return project;
}

/**
 * Rapidly generates all missing media (Images, Voiceover, Videos) for an existing project in parallel.
 */
export async function generateAllMediaFast(
  project: Project,
  options: FastGeneratorOptions = {},
  onProgress?: (stage: string, percent: number) => void
): Promise<Project> {
  const {
    videoEngine = "veo-2",
    imageEngine = "imagen-3",
    imageStyle = "CINEMATIC",
    audioEngine = "gemini-tts",
    voiceId = "kore",
    musicGenre = "CINEMATIC_ORCHESTRAL",
  } = options;

  if (!project.storyboard || !project.storyboard.scenes.length) {
    return project;
  }

  const scenes = project.storyboard.scenes;
  onProgress?.("Iniciando geração paralela ultra rápida...", 20);

  // 1. Parallel Images
  const imgPromises = scenes.map((scene) =>
    generateImageWithEngine({
      prompt: scene.imagePrompt || scene.visualDescription || project.title,
      engine: imageEngine,
      aspectRatio: project.settings.outputFormat === "9:16" ? "9:16" : "16:9",
      resolution: "1080p",
      style: imageStyle,
      sceneId: scene.id,
      sceneNumber: scene.sceneNumber,
      projectId: project.id,
      projectTitle: project.title,
    }).catch(() => null)
  );

  // 2. Parallel TTS Voice & Music
  const audioPromises = scenes.map((scene) =>
    generateTTSAudio({
      text: scene.narration || scene.visualDescription || project.title,
      engine: audioEngine,
      voiceId,
      sceneId: scene.id,
      sceneNumber: scene.sceneNumber,
      sectionTitle: `Cena ${scene.sceneNumber}`,
      projectId: project.id,
      projectTitle: project.title,
    }).catch(() => null)
  );
  const musicPromise = generateMusicAudio({
    genre: musicGenre,
    duration: project.brief?.duration || 60,
    projectId: project.id,
  }).catch(() => null);

  // 3. Parallel Videos
  const vidPromises = scenes.map((scene, idx) =>
    generateVideoWithEngine({
      engine: videoEngine,
      prompt: scene.videoPrompt || scene.visualDescription || `Cena ${scene.sceneNumber}`,
      cameraMotion: idx === 0 ? "PAN_RIGHT" : idx % 2 === 0 ? "ORBIT" : "ZOOM_IN",
      duration: Math.min(scene.duration || 6, 10),
      aspectRatio: project.settings.outputFormat === "9:16" ? "9:16" : "16:9",
      resolution: "1080p",
      sceneId: scene.id,
      sceneNumber: scene.sceneNumber,
      projectId: project.id,
      projectTitle: project.title,
    }).catch(() => null)
  );

  onProgress?.("Processando inteligência multimodal...", 60);

  const [images, ttsAudios, music, videos] = await Promise.all([
    Promise.all(imgPromises),
    Promise.all(audioPromises),
    musicPromise,
    Promise.all(vidPromises),
  ]);

  onProgress?.("Montando projeto e salvando...", 90);

  const newAssets: MediaAsset[] = [...(project.assets || [])];

  const updatedScenes = scenes.map((scene, idx) => {
    const img = images[idx];
    const vid = videos[idx];

    if (img) {
      newAssets.push({
        id: img.id,
        projectId: project.id,
        projectTitle: project.title,
        type: "IMAGE",
        name: `Imagem Cena ${scene.sceneNumber}`,
        url: img.imageUrl,
        thumbnailUrl: img.thumbnailUrl,
        status: "COMPLETED",
        provider: img.engineName,
        model: img.engine,
        createdAt: img.createdAt,
      });
    }

    if (vid) {
      newAssets.push({
        id: vid.id,
        projectId: project.id,
        projectTitle: project.title,
        type: "VIDEO",
        name: `Vídeo Cena ${scene.sceneNumber}`,
        url: vid.videoUrl,
        thumbnailUrl: vid.thumbnailUrl,
        status: "COMPLETED",
        provider: vid.engineName,
        model: vid.engine,
        duration: vid.duration,
        createdAt: vid.createdAt,
      });
    }

    return {
      ...scene,
      imageUrl: img?.imageUrl || scene.imageUrl,
      videoUrl: vid?.videoUrl || scene.videoUrl,
      status: "COMPLETED" as const,
    };
  });

  ttsAudios.forEach((tts) => {
    if (tts) {
      newAssets.push({
        id: tts.id,
        projectId: project.id,
        projectTitle: project.title,
        type: "VOICE",
        name: tts.title,
        url: tts.audioUrl,
        status: "COMPLETED",
        provider: tts.engineName,
        model: tts.engine,
        duration: tts.duration,
        createdAt: tts.createdAt,
      });
    }
  });

  if (music) {
    newAssets.push({
      id: music.id,
      projectId: project.id,
      projectTitle: project.title,
      type: "MUSIC",
      name: music.title,
      url: music.audioUrl,
      status: "COMPLETED",
      provider: music.engineName,
      model: music.engine,
      duration: music.duration,
      createdAt: music.createdAt,
    });
  }

  const updatedProject: Project = {
    ...project,
    storyboard: {
      ...project.storyboard,
      scenes: updatedScenes,
    },
    assets: newAssets,
    status: "COMPLETED",
    updatedAt: new Date().toISOString(),
  };

  saveProject(updatedProject);
  onProgress?.("Todas as mídias foram geradas com sucesso!", 100);
  return updatedProject;
}
