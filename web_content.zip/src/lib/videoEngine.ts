import type {
  VideoEngineId,
  VideoGenerationRequest,
  VideoGenerationResult,
  CameraMotionType,
  CameraAngle,
  VisualLightingStyle,
} from "@/types/video";
import type { Project, StoryboardScene, MediaAsset } from "@/types";
import { saveProject, getProject } from "@/lib/storage";
import { generateId } from "@/lib/utils";

// --- OTIMIZAR PROMPT COM GEMINI 3.7 FLASH ---
export async function optimizeVideoPrompt(params: {
  rawPrompt: string;
  engine?: VideoEngineId;
  cameraMotion?: CameraMotionType;
  cameraAngle?: CameraAngle;
  style?: VisualLightingStyle;
}): Promise<{
  prompt: string;
  negativePrompt?: string;
  cameraDirectives?: string;
  lightingSetup?: string;
}> {
  try {
    const res = await fetch("/api/video/optimize-prompt", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
    });
    const data = await res.json();
    if (data.success) {
      return {
        prompt: data.prompt,
        negativePrompt: data.negativePrompt,
        cameraDirectives: data.cameraDirectives,
        lightingSetup: data.lightingSetup,
      };
    }
  } catch (err) {
    console.error("Erro ao chamar API de otimização de prompt:", err);
  }

  return {
    prompt: `${params.rawPrompt}, cinematic 8k, master shot, ${params.cameraMotion || "PAN_RIGHT"}, ${params.style || "CINEMATIC"}`,
    negativePrompt: "blurry, low quality, artifacts, distorted",
  };
}

// --- GERAR VÍDEO COM MOTOR AI ---
export async function generateVideoWithEngine(
  request: VideoGenerationRequest
): Promise<VideoGenerationResult> {
  try {
    const res = await fetch("/api/video/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(request),
    });
    const data = await res.json();
    if (data.success && data.data) {
      const result: VideoGenerationResult = data.data;

      // Se estiver vinculado a um projeto, sincronizar no Storyboard e Assets
      if (request.projectId) {
        attachVideoToProject(request.projectId, result, request.sceneId);
      }

      return result;
    }
    throw new Error(data.error || "Falha na geração de vídeo");
  } catch (err) {
    console.error("Erro no motor de vídeo:", err);
    throw err;
  }
}

// --- VINCULAR VÍDEO GERADO AO PROJETO E BIBLIOTECA ---
export function attachVideoToProject(
  projectId: string,
  videoResult: VideoGenerationResult,
  sceneId?: string
): Project | null {
  const project = getProject(projectId);
  if (!project) return null;

  // 1. Atualizar a cena no Storyboard se aplicável
  let updatedScenes = project.storyboard?.scenes || [];
  if (sceneId && project.storyboard) {
    updatedScenes = project.storyboard.scenes.map((scene: StoryboardScene) => {
      if (scene.id === sceneId) {
        return {
          ...scene,
          videoUrl: videoResult.videoUrl,
          imageUrl: scene.imageUrl || videoResult.thumbnailUrl,
          status: "COMPLETED" as const,
        };
      }
      return scene;
    });
  }

  // 2. Criar novo MediaAsset
  const newAsset: MediaAsset = {
    id: videoResult.id,
    projectId: project.id,
    projectTitle: project.title,
    type: "VIDEO",
    name: `Cena ${videoResult.sceneNumber || 1} — ${videoResult.engineName}`,
    url: videoResult.videoUrl,
    thumbnailUrl: videoResult.thumbnailUrl,
    status: "COMPLETED",
    prompt: videoResult.prompt,
    provider: videoResult.engineName,
    model: videoResult.engine,
    duration: videoResult.duration,
    format: videoResult.aspectRatio,
    createdAt: videoResult.createdAt,
    metadata: {
      resolution: videoResult.resolution,
      fps: videoResult.fps,
      cameraMotion: videoResult.cameraMotion,
      style: videoResult.style,
      optimizedPrompt: videoResult.optimizedPrompt,
    },
  };

  // 3. Atualizar projeto
  const existingAssets = project.assets || [];
  const updatedProject: Project = {
    ...project,
    storyboard: project.storyboard
      ? {
          ...project.storyboard,
          scenes: updatedScenes,
        }
      : undefined,
    assets: [newAsset, ...existingAssets.filter((a) => a.id !== newAsset.id)],
    updatedAt: new Date().toISOString(),
  };

  saveProject(updatedProject);
  return updatedProject;
}

// --- GERAR EM LOTE PARA TODAS AS CENAS DO STORYBOARD (PARALELISMO VELOZ) ---
export async function generateBatchStoryboardVideos(
  project: Project,
  engine: VideoEngineId,
  onProgress?: (current: number, total: number, sceneNumber: number) => void
): Promise<Project> {
  if (!project.storyboard || !project.storyboard.scenes.length) {
    return project;
  }

  const scenes = project.storyboard.scenes;
  const total = scenes.length;
  let completedCount = 0;

  // Process all scenes in parallel with high-throughput concurrency
  const results = await Promise.all(
    scenes.map(async (scene, i) => {
      try {
        const result = await generateVideoWithEngine({
          engine,
          prompt: scene.videoPrompt || scene.visualDescription || `Cena ${scene.sceneNumber}`,
          cameraMotion: i === 0 ? "PAN_RIGHT" : i % 2 === 0 ? "ORBIT" : "ZOOM_IN",
          cameraAngle: "WIDE",
          style: "CINEMATIC",
          motionStrength: 7,
          duration: Math.min(scene.duration || 6, 10),
          aspectRatio: project.settings.outputFormat === "9:16" ? "9:16" : "16:9",
          resolution: "1080p",
          fps: 30,
          sceneId: scene.id,
          sceneNumber: scene.sceneNumber,
          projectId: project.id,
          projectTitle: project.title,
        });

        completedCount++;
        if (onProgress) {
          onProgress(completedCount, total, scene.sceneNumber);
        }

        return { sceneId: scene.id, result };
      } catch (e) {
        console.error(`Erro ao gerar cena ${scene.sceneNumber}:`, e);
        return null;
      }
    })
  );

  let currentProject = getProject(project.id) || project;
  for (const item of results) {
    if (item && item.result) {
      const updated = attachVideoToProject(project.id, item.result, item.sceneId);
      if (updated) currentProject = updated;
    }
  }

  return currentProject;
}
