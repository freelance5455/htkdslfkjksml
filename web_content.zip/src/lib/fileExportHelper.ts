/**
 * JUHNKRIX MUSIKA - Device Storage Folder Selector & Export Helper
 * Re-exports fileExporter for seamless compatibility across the applet.
 */

import { fileExporter } from './fileExporter';

export async function exportFileToDeviceFolder(filename: string, content: string | Blob | Uint8Array, mimeType: string = 'application/octet-stream'): Promise<boolean> {
  try {
    const res = await fileExporter.exportFile(content, {
      suggestedName: filename,
      mimeType
    });
    return res.success;
  } catch (err: any) {
    if (err.message?.includes('cancelled')) {
      return false;
    }
    console.warn("Export helper fallback:", err);
    return false;
  }
}
