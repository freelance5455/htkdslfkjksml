import {
  AA,
  ACCENTS,
  BACKGROUNDS,
  CARD_STYLES,
  DETAIL,
  DENSITIES,
  FPS_TARGETS,
  GRAPHICS,
  MOTIONS,
  PRESETS,
  SCALE,
  THEMES,
  WIDGETS,
  freshState,
  isFpsTarget,
  type ClickPreset,
  type ClickerConfig,
  type Game,
  type Persisted,
  type WidgetId,
} from "@/lib/model";

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function asString(value: unknown, max: number, fallback = "") {
  return typeof value === "string" ? value.slice(0, max) : fallback;
}

function asBool(value: unknown, fallback = false) {
  return typeof value === "boolean" ? value : fallback;
}

function asNumber(value: unknown, min: number, max: number, fallback: number) {
  if (typeof value !== "number" || !Number.isFinite(value)) return fallback;
  return Math.min(max, Math.max(min, value));
}

function oneOf<T extends string>(value: unknown, allowed: readonly T[], fallback: T): T {
  return typeof value === "string" && (allowed as readonly string[]).includes(value) ? (value as T) : fallback;
}

function readGame(value: unknown): Game | null {
  if (!isRecord(value) || typeof value.id !== "string" || typeof value.name !== "string") return null;
  const name = value.name.trim().slice(0, 60);
  if (!name) return null;
  const target = typeof value.fpsTarget === "number" && isFpsTarget(value.fpsTarget) ? value.fpsTarget : 60;
  const image = typeof value.image === "string" && value.image.startsWith("data:image/") && value.image.length < 400_000
    ? value.image
    : null;
  return {
    id: value.id.slice(0, 80),
    name,
    launchUrl: asString(value.launchUrl, 500),
    notes: asString(value.notes, 2000),
    image,
    preset: oneOf(value.preset, PRESETS, "balanced"),
    graphics: oneOf(value.graphics, GRAPHICS, "medium"),
    fpsTarget: target,
    resolutionScale: oneOf(value.resolutionScale, SCALE, "native"),
    shadows: oneOf(value.shadows, DETAIL, "low"),
    effects: oneOf(value.effects, DETAIL, "low"),
    aa: oneOf(value.aa, AA, "fxaa"),
    vsync: value.vsync === "off" ? "off" : "on",
  };
}

function readPoints(value: unknown): ClickerConfig["points"] {
  if (!Array.isArray(value)) return [];
  return value.slice(0, 12).flatMap((point) => {
    if (!isRecord(point) || typeof point.id !== "string") return [];
    return [
      {
        id: point.id.slice(0, 80),
        label: asString(point.label, 40, "Point"),
        x: asNumber(point.x, 0, 100, 50),
        y: asNumber(point.y, 0, 100, 50),
        delayMs: Math.round(asNumber(point.delayMs, 50, 60000, 500)),
      },
    ];
  });
}

function readClicker(value: unknown, fallback: ClickerConfig): ClickerConfig {
  if (!isRecord(value)) return fallback;
  const points = readPoints(value.points);
  return {
    intervalMs: Math.round(asNumber(value.intervalMs, 50, 60000, fallback.intervalMs)),
    repeat: Math.round(asNumber(value.repeat, 0, 9999, fallback.repeat)),
    durationSec: Math.round(asNumber(value.durationSec, 0, 86400, fallback.durationSec)),
    mode: value.mode === "sequence" ? "sequence" : "single",
    points: points.length > 0 ? points : fallback.points,
  };
}

export function exportBackup(state: Persisted) {
  return {
    app: "frameforge-booyah",
    version: 1 as const,
    exportedAt: new Date().toISOString(),
    state,
  };
}

export function parseBackup(raw: unknown): { ok: true; data: Persisted } | { ok: false; error: string } {
  if (!isRecord(raw)) return { ok: false, error: "That file is not a FrameForge backup." };
  if (raw.app !== "frameforge-booyah" || raw.version !== 1 || !isRecord(raw.state)) {
    return { ok: false, error: "This file is not a FrameForge BOOYAH v1 backup." };
  }
  const base = freshState();
  const state = raw.state;
  if (!Array.isArray(state.games)) return { ok: false, error: "The backup is missing the game list." };
  const games = state.games.map(readGame).filter((game): game is Game => game !== null);
  if (games.length !== state.games.length) return { ok: false, error: "One of the saved games could not be read." };
  const ids = new Set(games.map((game) => game.id));
  if (ids.size !== games.length) return { ok: false, error: "The backup has duplicate game ids." };

  const selected = typeof state.selectedGameId === "string" && ids.has(state.selectedGameId) ? state.selectedGameId : (games[0]?.id ?? null);

  const rawWidgets = Array.isArray(state.widgets) ? state.widgets : null;
  const widgets = rawWidgets
    ? WIDGETS.map((widget) => {
        const found = rawWidgets.find((item) => isRecord(item) && item.id === widget.id);
        return { id: widget.id, visible: found && isRecord(found) ? asBool(found.visible, true) : true };
      })
    : base.widgets;
  const ordered: { id: WidgetId; visible: boolean }[] = [];
  if (rawWidgets) {
    for (const item of rawWidgets) {
      if (!isRecord(item) || typeof item.id !== "string") continue;
      const known = WIDGETS.find((widget) => widget.id === item.id);
      if (!known || ordered.some((widget) => widget.id === known.id)) continue;
      ordered.push({ id: known.id, visible: asBool(item.visible, true) });
    }
  }
  for (const widget of widgets) {
    if (!ordered.some((item) => item.id === widget.id)) ordered.push(widget);
  }

  const fpsLogs = Array.isArray(state.fpsLogs)
    ? state.fpsLogs.slice(0, 200).flatMap((entry) => {
        if (!isRecord(entry) || typeof entry.id !== "string" || typeof entry.measuredFps !== "number") return [];
        if (!isFpsTarget(entry.targetFps as number)) return [];
        const measured = Math.round(entry.measuredFps);
        if (measured < 1 || measured > 1000) return [];
        return [
          {
            id: entry.id.slice(0, 80),
            gameId: typeof entry.gameId === "string" && ids.has(entry.gameId) ? entry.gameId : null,
            measuredFps: measured,
            targetFps: entry.targetFps as (typeof FPS_TARGETS)[number],
            refreshHz: typeof entry.refreshHz === "number" ? entry.refreshHz : null,
            note: asString(entry.note, 200),
            at: asNumber(entry.at, 0, 9e15, Date.now()),
          },
        ];
      })
    : [];

  const compares = Array.isArray(state.compares)
    ? state.compares.slice(0, 100).flatMap((entry) => {
        if (!isRecord(entry) || typeof entry.id !== "string" || typeof entry.measuredFps !== "number") return [];
        const measured = Math.round(entry.measuredFps);
        if (measured < 1 || measured > 1000) return [];
        return [
          {
            id: entry.id.slice(0, 80),
            label: asString(entry.label, 60, "Untitled run"),
            gameId: typeof entry.gameId === "string" && ids.has(entry.gameId) ? entry.gameId : null,
            preset: asString(entry.preset, 40, "Custom"),
            measuredFps: measured,
            targetFps: asNumber(entry.targetFps, 1, 1000, 60),
            note: asString(entry.note, 200),
            at: asNumber(entry.at, 0, 9e15, Date.now()),
          },
        ];
      })
    : [];

  const notes = Array.isArray(state.notes)
    ? state.notes.slice(0, 100).flatMap((entry) => {
        if (!isRecord(entry) || typeof entry.id !== "string") return [];
        const title = asString(entry.title, 80).trim();
        if (!title) return [];
        return [
          {
            id: entry.id.slice(0, 80),
            title,
            body: asString(entry.body, 2000),
            gameId: typeof entry.gameId === "string" && ids.has(entry.gameId) ? entry.gameId : null,
            at: asNumber(entry.at, 0, 9e15, Date.now()),
          },
        ];
      })
    : [];

  const clickPresets: ClickPreset[] = Array.isArray(state.clickPresets)
    ? state.clickPresets.slice(0, 30).flatMap((entry) => {
        if (!isRecord(entry) || typeof entry.id !== "string") return [];
        const name = asString(entry.name, 40).trim();
        if (!name) return [];
        return [{ id: entry.id.slice(0, 80), name, ...readClicker(entry, base.clicker) }];
      })
    : base.clickPresets;

  let refreshSample: Persisted["refreshSample"] = null;
  if (isRecord(state.refreshSample) && typeof state.refreshSample.displayHz === "number") {
    refreshSample = {
      displayHz: Math.round(asNumber(state.refreshSample.displayHz, 1, 300, 60)),
      rawHz: asNumber(state.refreshSample.rawHz, 1, 300, state.refreshSample.displayHz),
      frames: Math.round(asNumber(state.refreshSample.frames, 0, 100000, 0)),
      at: asNumber(state.refreshSample.at, 0, 9e15, Date.now()),
      snapped: asBool(state.refreshSample.snapped),
    };
  }

  const thermal: Record<string, boolean> = {};
  if (isRecord(state.thermal)) {
    for (const [key, value] of Object.entries(state.thermal)) {
      if (typeof value === "boolean") thermal[key.slice(0, 40)] = value;
    }
  }
  const tutorialsSeen: Record<string, boolean> = {};
  if (isRecord(state.tutorialsSeen)) {
    for (const [key, value] of Object.entries(state.tutorialsSeen)) {
      if (typeof value === "boolean") tutorialsSeen[key.slice(0, 40)] = value;
    }
  }

  const session = isRecord(state.session)
    ? {
        running: asBool(state.session.running),
        startedAt: typeof state.session.startedAt === "number" ? state.session.startedAt : null,
        accumulatedMs: Math.max(0, asNumber(state.session.accumulatedMs, 0, 1e12, 0)),
      }
    : base.session;

  return {
    ok: true,
    data: {
      theme: oneOf(state.theme, THEMES, "dark"),
      accent: oneOf(state.accent, ACCENTS.map((item) => item.id), "crimson"),
      background: oneOf(state.background, BACKGROUNDS.map((item) => item.id), "graphite"),
      density: oneOf(state.density, DENSITIES, "comfortable"),
      motion: oneOf(state.motion, MOTIONS, "subtle"),
      cardStyle: oneOf(state.cardStyle, CARD_STYLES, "poster"),
      keepAwake: asBool(state.keepAwake),
      widgets: ordered,
      selectedGameId: selected,
      games,
      session,
      fpsLogs,
      compares,
      notes,
      clicker: readClicker(state.clicker, base.clicker),
      clickPresets,
      refreshSample,
      thermal,
      tutorialsSeen,
    },
  };
}
