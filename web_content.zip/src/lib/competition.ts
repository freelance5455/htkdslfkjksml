import type { MatchFormat, MatchState, Player } from "./types";
import { oversStr, playerPerformance, strikeRate, teamOfPlayer } from "./engine";

/**
 * Leagues & Tournaments.
 *
 * The competition layer is a pure consumer of completed matches: the existing
 * scoring engine remains the single source of truth for runs, wickets, balls,
 * extras, player statistics and the match result. Nothing here re-scores a
 * match — standings, NRR, leaderboards and knockout progression are all
 * derived from the recorded match states.
 */

export type CompetitionType = "league" | "tournament";

/** Tournament shapes supported by the fixture generator. */
export type CompetitionFormat =
  | "single-round-robin"
  | "double-round-robin"
  | "group-knockout"
  | "knockout";

export type FixtureStatus = "scheduled" | "live" | "completed" | "abandoned" | "postponed";

export type CompTeam = {
  id: string;
  name: string;
  logo?: string;
  captain?: string;
  viceCaptain?: string;
  wicketKeeper?: string;
  /** Squad; a Playing XI is chosen per match by the scorer. */
  players: Player[];
  /** Group label for group-stage competitions, e.g. "A". */
  group?: string;
};

export type Fixture = {
  id: string;
  competitionId: string;
  /** Sequential fixture number shown to users. */
  number: number;
  round: string;
  group?: string;
  /** Null until a knockout slot is filled by a qualifying team. */
  teamAId: string | null;
  teamBId: string | null;
  /** Placeholder text while a knockout slot is undecided, e.g. "Winner QF1". */
  teamAPlaceholder?: string;
  teamBPlaceholder?: string;
  date?: string;
  time?: string;
  venue?: string;
  overs: number;
  status: FixtureStatus;
  /** Id of the match in the scoring engine once scoring has started. */
  matchId?: string;
  /** Cached result summary so lists render without replaying events. */
  resultText?: string;
  winnerTeamId?: string | null;
};

export type PointsConfig = {
  win: number;
  tie: number;
  noResult: number;
  loss: number;
};

export type Competition = {
  id: string;
  name: string;
  type: CompetitionType;
  format: CompetitionFormat;
  season?: string;
  location?: string;
  organizer?: string;
  startDate?: string;
  endDate?: string;
  oversFormat: MatchFormat;
  overs: number;
  ballType?: string;
  logo?: string;
  teams: CompTeam[];
  fixtures: Fixture[];
  points: PointsConfig;
  /** Number of groups for group-stage tournaments. */
  groupCount?: number;
  /** Teams qualifying from each group. */
  qualifyPerGroup?: number;
  /** Manually chosen by the organizer once the final is done. */
  playerOfTournament?: string | null;
  createdAt: number;
  updatedAt: number;
  rev: number;
  syncedRev: number;
};

export const DEFAULT_POINTS: PointsConfig = { win: 2, tie: 1, noResult: 1, loss: 0 };

/* ------------------------------------------------------------------ */
/* Ids                                                                 */
/* ------------------------------------------------------------------ */

export function newId(): string {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  const bytes = new Uint8Array(16);
  if (typeof crypto !== "undefined" && typeof crypto.getRandomValues === "function") {
    crypto.getRandomValues(bytes);
  } else {
    for (let i = 0; i < 16; i++) bytes[i] = Math.floor(Math.random() * 256);
  }
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

/* ------------------------------------------------------------------ */
/* Fixture generation                                                  */
/* ------------------------------------------------------------------ */

/**
 * Round-robin pairing using the circle method, so every team plays every
 * other exactly once per cycle with a balanced spread of rounds.
 */
function roundRobinRounds(ids: string[]): { a: string; b: string }[][] {
  const teams = [...ids];
  if (teams.length < 2) return [];
  const bye = teams.length % 2 === 1;
  if (bye) teams.push("__BYE__");

  const n = teams.length;
  const rounds: { a: string; b: string }[][] = [];
  const rotation = teams.slice(1);

  for (let r = 0; r < n - 1; r++) {
    const pairs: { a: string; b: string }[] = [];
    const order = [teams[0], ...rotation];
    for (let i = 0; i < n / 2; i++) {
      const a = order[i];
      const b = order[n - 1 - i];
      if (a !== "__BYE__" && b !== "__BYE__") {
        // Alternate home/away for a fairer spread.
        pairs.push(r % 2 === 0 ? { a, b } : { a: b, b: a });
      }
    }
    rounds.push(pairs);
    rotation.unshift(rotation.pop() as string);
  }
  return rounds;
}

type GenOpts = {
  competitionId: string;
  teams: CompTeam[];
  format: CompetitionFormat;
  overs: number;
  venue?: string;
  startDate?: string;
  groupCount?: number;
  qualifyPerGroup?: number;
};

function nextPow2(n: number): number {
  let p = 1;
  while (p < n) p *= 2;
  return p;
}

const ROUND_NAME: Record<number, string> = {
  2: "Final",
  4: "Semi Final",
  8: "Quarter Final",
  16: "Round of 16",
  32: "Round of 32",
};

function roundLabel(slots: number): string {
  return ROUND_NAME[slots] ?? `Round of ${slots}`;
}

/** Generates the complete fixture list for a competition. */
export function generateFixtures(opts: GenOpts): Fixture[] {
  const { competitionId, teams, format, overs, venue, startDate } = opts;
  const fixtures: Fixture[] = [];
  let n = 0;
  const dayMs = 24 * 60 * 60 * 1000;
  const base = startDate ? new Date(startDate).getTime() : Date.now();

  const push = (f: Omit<Fixture, "id" | "number" | "competitionId" | "overs" | "status">) => {
    n += 1;
    fixtures.push({
      id: newId(),
      competitionId,
      number: n,
      overs,
      status: "scheduled",
      venue,
      date: new Date(base + (n - 1) * dayMs).toISOString().slice(0, 10),
      ...f,
    });
  };

  if (format === "single-round-robin" || format === "double-round-robin") {
    const rounds = roundRobinRounds(teams.map((t) => t.id));
    rounds.forEach((pairs, i) =>
      pairs.forEach((p) =>
        push({ round: `Round ${i + 1}`, teamAId: p.a, teamBId: p.b }),
      ),
    );
    if (format === "double-round-robin") {
      rounds.forEach((pairs, i) =>
        pairs.forEach((p) =>
          // Reverse fixture in the return leg.
          push({ round: `Round ${rounds.length + i + 1}`, teamAId: p.b, teamBId: p.a }),
        ),
      );
    }
    return fixtures;
  }

  if (format === "group-knockout") {
    const groupCount = Math.max(1, opts.groupCount ?? 2);
    const groups: Record<string, string[]> = {};
    teams.forEach((t, i) => {
      const label = t.group ?? String.fromCharCode(65 + (i % groupCount));
      (groups[label] ??= []).push(t.id);
    });

    for (const [label, ids] of Object.entries(groups).sort()) {
      roundRobinRounds(ids).forEach((pairs) =>
        pairs.forEach((p) =>
          push({ round: `Group ${label}`, group: label, teamAId: p.a, teamBId: p.b }),
        ),
      );
    }

    // Knockout bracket seeded by group position; slots filled on qualification.
    const qualifiers = Object.keys(groups).length * Math.max(1, opts.qualifyPerGroup ?? 2);
    const slots = Math.max(2, nextPow2(qualifiers));
    addKnockoutRounds(push, slots, Object.keys(groups).sort(), opts.qualifyPerGroup ?? 2);
    return fixtures;
  }

  // Straight knockout from the registered teams.
  const slots = Math.max(2, nextPow2(teams.length));
  const seeded = [...teams.map((t) => t.id), ...Array(slots - teams.length).fill(null)];
  let roundSlots = slots;
  let matchIdx = 0;
  const firstRound = roundLabel(roundSlots);
  for (let i = 0; i < slots / 2; i++) {
    matchIdx += 1;
    push({
      round: firstRound,
      teamAId: seeded[i] ?? null,
      teamBId: seeded[slots - 1 - i] ?? null,
      teamAPlaceholder: seeded[i] ? undefined : "TBD",
      teamBPlaceholder: seeded[slots - 1 - i] ? undefined : "Bye",
    });
  }
  roundSlots /= 2;
  let prevLabel = firstRound;
  while (roundSlots >= 2) {
    const label = roundLabel(roundSlots);
    for (let i = 0; i < roundSlots / 2; i++) {
      push({
        round: label,
        teamAId: null,
        teamBId: null,
        teamAPlaceholder: `Winner ${prevLabel} ${i * 2 + 1}`,
        teamBPlaceholder: `Winner ${prevLabel} ${i * 2 + 2}`,
      });
    }
    prevLabel = label;
    roundSlots /= 2;
  }
  return fixtures;
}

function addKnockoutRounds(
  push: (f: Omit<Fixture, "id" | "number" | "competitionId" | "overs" | "status">) => void,
  slots: number,
  groupLabels: string[],
  qualifyPerGroup: number,
) {
  let roundSlots = slots;
  const first = roundLabel(roundSlots);

  // Standard cross-group seeding: 1st of one group meets the lowest qualifier
  // of another, so group winners avoid each other early.
  const seeds: { a: string; b: string }[] = [];
  const pool: string[] = [];
  for (const g of groupLabels) {
    for (let pos = 1; pos <= qualifyPerGroup; pos++) pool.push(`${ordinal(pos)} Group ${g}`);
  }
  for (let i = 0; i < pool.length / 2; i++) {
    seeds.push({ a: pool[i], b: pool[pool.length - 1 - i] });
  }

  for (let i = 0; i < roundSlots / 2; i++) {
    const s = seeds[i];
    push({
      round: first,
      teamAId: null,
      teamBId: null,
      teamAPlaceholder: s?.a ?? "TBD",
      teamBPlaceholder: s?.b ?? "TBD",
    });
  }

  let prev = first;
  roundSlots /= 2;
  while (roundSlots >= 2) {
    const label = roundLabel(roundSlots);
    for (let i = 0; i < roundSlots / 2; i++) {
      push({
        round: label,
        teamAId: null,
        teamBId: null,
        teamAPlaceholder: `Winner ${prev} ${i * 2 + 1}`,
        teamBPlaceholder: `Winner ${prev} ${i * 2 + 2}`,
      });
    }
    prev = label;
    roundSlots /= 2;
  }
}

function ordinal(n: number): string {
  return n === 1 ? "1st" : n === 2 ? "2nd" : n === 3 ? "3rd" : `${n}th`;
}

/* ------------------------------------------------------------------ */
/* Standings + Net Run Rate                                            */
/* ------------------------------------------------------------------ */

export type Standing = {
  teamId: string;
  team: string;
  played: number;
  won: number;
  lost: number;
  tied: number;
  noResult: number;
  points: number;
  runsFor: number;
  oversFor: number;
  runsAgainst: number;
  oversAgainst: number;
  nrr: number;
  group?: string;
};

/**
 * Overs faced, per the standard NRR rule: a side bowled out counts as having
 * faced its FULL quota of overs, not the balls it actually used.
 */
function oversFaced(runs: number, legalBalls: number, wickets: number, squad: number, maxOvers: number) {
  const allOut = wickets >= squad - 1;
  return allOut ? maxOvers : legalBalls / 6;
}

/** Match outcome in competition terms. */
export type CompResult = {
  teamAId: string;
  teamBId: string;
  /** null = tie or no result. */
  winnerTeamId: string | null;
  noResult: boolean;
  tied: boolean;
  aRuns: number;
  aOvers: number;
  bRuns: number;
  bOvers: number;
  resultText: string;
};

/** Extracts a competition result from a completed match state. */
export function resultFromMatch(
  state: MatchState,
  teamAId: string,
  teamBId: string,
  nameToId: Record<string, string>,
  maxOvers: number,
): CompResult | null {
  if (state.status !== "completed") return null;

  const squadA = state.setup.playersPerTeam ?? 11;
  const [i1, i2] = state.innings;

  const stat = (inn: typeof i1) => ({
    runs: inn.runs,
    overs: oversFaced(inn.runs, inn.legalBalls, inn.wickets, squadA, maxOvers),
    team: inn.battingTeam,
  });
  const s1 = stat(i1);
  const s2 = stat(i2);

  const byTeam: Record<string, { runs: number; overs: number }> = {};
  byTeam[nameToId[s1.team] ?? teamAId] = { runs: s1.runs, overs: s1.overs };
  byTeam[nameToId[s2.team] ?? teamBId] = { runs: s2.runs, overs: s2.overs };

  const winnerTeamId = state.winner ? (nameToId[state.winner] ?? null) : null;
  const tied = state.outcome?.kind === "tie";

  return {
    teamAId,
    teamBId,
    winnerTeamId,
    noResult: false,
    tied,
    aRuns: byTeam[teamAId]?.runs ?? 0,
    aOvers: byTeam[teamAId]?.overs ?? 0,
    bRuns: byTeam[teamBId]?.runs ?? 0,
    bOvers: byTeam[teamBId]?.overs ?? 0,
    resultText: state.result ?? "",
  };
}

/** Builds the points table from every completed fixture result. */
export function computeStandings(
  comp: Competition,
  results: Map<string, CompResult>,
): Standing[] {
  const rows = new Map<string, Standing>();
  for (const t of comp.teams) {
    rows.set(t.id, {
      teamId: t.id,
      team: t.name,
      played: 0,
      won: 0,
      lost: 0,
      tied: 0,
      noResult: 0,
      points: 0,
      runsFor: 0,
      oversFor: 0,
      runsAgainst: 0,
      oversAgainst: 0,
      nrr: 0,
      group: t.group,
    });
  }

  for (const f of comp.fixtures) {
    // Only league/group matches contribute to the points table.
    if (f.round.startsWith("Group") === false && comp.format.includes("knockout")) continue;
    const res = results.get(f.id);
    if (!res) continue;
    const a = rows.get(res.teamAId);
    const b = rows.get(res.teamBId);
    if (!a || !b) continue;

    a.played += 1;
    b.played += 1;
    a.runsFor += res.aRuns;
    a.oversFor += res.aOvers;
    a.runsAgainst += res.bRuns;
    a.oversAgainst += res.bOvers;
    b.runsFor += res.bRuns;
    b.oversFor += res.bOvers;
    b.runsAgainst += res.aRuns;
    b.oversAgainst += res.aOvers;

    if (res.noResult) {
      a.noResult += 1;
      b.noResult += 1;
      a.points += comp.points.noResult;
      b.points += comp.points.noResult;
    } else if (res.tied || !res.winnerTeamId) {
      a.tied += 1;
      b.tied += 1;
      a.points += comp.points.tie;
      b.points += comp.points.tie;
    } else {
      const w = rows.get(res.winnerTeamId);
      const l = res.winnerTeamId === res.teamAId ? b : a;
      if (w) {
        w.won += 1;
        w.points += comp.points.win;
      }
      l.lost += 1;
      l.points += comp.points.loss;
    }
  }

  for (const r of rows.values()) {
    // Standard NRR: (runs scored / overs faced) − (runs conceded / overs bowled).
    const forRate = r.oversFor > 0 ? r.runsFor / r.oversFor : 0;
    const againstRate = r.oversAgainst > 0 ? r.runsAgainst / r.oversAgainst : 0;
    r.nrr = r.played > 0 ? forRate - againstRate : 0;
  }

  return [...rows.values()].sort(
    (x, y) => y.points - x.points || y.nrr - x.nrr || y.won - x.won || x.team.localeCompare(y.team),
  );
}

/* ------------------------------------------------------------------ */
/* Competition-wide player statistics                                  */
/* ------------------------------------------------------------------ */

export type BattingLeader = {
  name: string;
  team: string;
  matches: number;
  innings: number;
  runs: number;
  balls: number;
  highest: number;
  notOuts: number;
  fours: number;
  sixes: number;
  fifties: number;
  hundreds: number;
  average: number;
  strikeRate: number;
};

export type BowlingLeader = {
  name: string;
  team: string;
  matches: number;
  balls: number;
  runs: number;
  wickets: number;
  maidens: number;
  dots: number;
  economy: number;
  bestWickets: number;
  bestRuns: number;
};

export type FieldingLeader = {
  name: string;
  team: string;
  catches: number;
  runOuts: number;
  stumpings: number;
};

export type Leaderboards = {
  batting: BattingLeader[];
  bowling: BowlingLeader[];
  fielding: FieldingLeader[];
};

/** Aggregates every completed match into competition-wide statistics. */
export function computeLeaderboards(states: MatchState[]): Leaderboards {
  const bat = new Map<string, BattingLeader>();
  const bowl = new Map<string, BowlingLeader>();
  const field = new Map<string, FieldingLeader>();

  for (const state of states) {
    const seen = new Set<string>();
    for (const inn of state.innings) {
      for (const b of inn.batters) {
        const team = teamOfPlayer(state.setup, b.name);
        const row =
          bat.get(b.name) ??
          {
            name: b.name,
            team,
            matches: 0,
            innings: 0,
            runs: 0,
            balls: 0,
            highest: 0,
            notOuts: 0,
            fours: 0,
            sixes: 0,
            fifties: 0,
            hundreds: 0,
            average: 0,
            strikeRate: 0,
          };
        if (b.balls > 0 || b.runs > 0 || b.out) row.innings += 1;
        row.runs += b.runs;
        row.balls += b.balls;
        row.fours += b.fours;
        row.sixes += b.sixes;
        if (!b.out) row.notOuts += 1;
        if (b.runs > row.highest) row.highest = b.runs;
        if (b.runs >= 100) row.hundreds += 1;
        else if (b.runs >= 50) row.fifties += 1;
        bat.set(b.name, row);
        seen.add(b.name);
      }

      for (const b of inn.bowlers) {
        const team = teamOfPlayer(state.setup, b.name);
        const row =
          bowl.get(b.name) ??
          {
            name: b.name,
            team,
            matches: 0,
            balls: 0,
            runs: 0,
            wickets: 0,
            maidens: 0,
            dots: 0,
            economy: 0,
            bestWickets: -1,
            bestRuns: 0,
          };
        row.balls += b.balls;
        row.runs += b.runs;
        row.wickets += b.wickets;
        row.maidens += b.maidens;
        row.dots += b.dots;
        if (
          b.wickets > row.bestWickets ||
          (b.wickets === row.bestWickets && b.runs < row.bestRuns)
        ) {
          row.bestWickets = b.wickets;
          row.bestRuns = b.runs;
        }
        bowl.set(b.name, row);
        seen.add(b.name);
      }

      for (const f of inn.fielding) {
        const team = teamOfPlayer(state.setup, f.name);
        const row =
          field.get(f.name) ?? { name: f.name, team, catches: 0, runOuts: 0, stumpings: 0 };
        row.catches += f.catches;
        row.runOuts += f.runOuts;
        row.stumpings += f.stumpings;
        field.set(f.name, row);
        seen.add(f.name);
      }
    }
    for (const name of seen) {
      const b = bat.get(name);
      if (b) b.matches += 1;
      const w = bowl.get(name);
      if (w) w.matches += 1;
    }
  }

  for (const r of bat.values()) {
    const dismissals = r.innings - r.notOuts;
    r.average = dismissals > 0 ? r.runs / dismissals : r.runs;
    r.strikeRate = strikeRate(r.runs, r.balls);
  }
  for (const r of bowl.values()) {
    r.economy = r.balls > 0 ? (r.runs * 6) / r.balls : 0;
    if (r.bestWickets < 0) r.bestWickets = 0;
  }

  return {
    batting: [...bat.values()].sort((a, b) => b.runs - a.runs || b.strikeRate - a.strikeRate),
    bowling: [...bowl.values()].sort((a, b) => b.wickets - a.wickets || a.economy - b.economy),
    fielding: [...field.values()].sort(
      (a, b) =>
        b.catches + b.runOuts + b.stumpings - (a.catches + a.runOuts + a.stumpings),
    ),
  };
}

/** Headline performers for the competition dashboard. */
export function topPerformers(lb: Leaderboards, states: MatchState[]) {
  const qualifiedBat = lb.batting.filter((b) => b.balls >= 10);
  const qualifiedBowl = lb.bowling.filter((b) => b.balls >= 12);

  let highestScore: { name: string; runs: number; balls: number } | null = null;
  for (const s of states) {
    for (const inn of s.innings) {
      for (const b of inn.batters) {
        if (!highestScore || b.runs > highestScore.runs) {
          highestScore = { name: b.name, runs: b.runs, balls: b.balls };
        }
      }
    }
  }

  return {
    topRunScorer: lb.batting[0] ?? null,
    mostWickets: lb.bowling[0] ?? null,
    highestScore,
    bestBowling: [...lb.bowling].sort(
      (a, b) => b.bestWickets - a.bestWickets || a.bestRuns - b.bestRuns,
    )[0] ?? null,
    bestStrikeRate:
      [...qualifiedBat].sort((a, b) => b.strikeRate - a.strikeRate)[0] ?? null,
    bestEconomy: [...qualifiedBowl].sort((a, b) => a.economy - b.economy)[0] ?? null,
    mostSixes: [...lb.batting].sort((a, b) => b.sixes - a.sixes)[0] ?? null,
    mostFours: [...lb.batting].sort((a, b) => b.fours - a.fours)[0] ?? null,
  };
}

export function formatOvers(balls: number): string {
  return oversStr(balls);
}

/** Per-player competition summary used by the player profile view. */
export function competitionPlayerSummary(states: MatchState[], name: string) {
  return states
    .map((s) => playerPerformance(s, name))
    .filter((p) => p.batting || p.bowling || p.fielding);
}
