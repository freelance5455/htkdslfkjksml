import { AUDIO_EXTS, VIDEO_EXTS } from "@/lib/constants";
import { extensionOf } from "@/lib/utils";

export type Probe = {
  kind: "video" | "audio" | "subtitle" | "unknown";
  mime: string;
  playable: boolean;
  reason?: string;
  canPlay: "" | "maybe" | "probably";
};

const MIME_BY_EXT: Record<string, string> = {
  mp4: "video/mp4",
  m4v: "video/mp4",
  webm: "video/webm",
  ogv: "video/ogg",
  ogg: "video/ogg",
  mov: "video/quicktime",
  mkv: "video/x-matroska",
  avi: "video/x-msvideo",
  "3gp": "video/3gpp",
  m3u8: "application/vnd.apple.mpegurl",
  mp3: "audio/mpeg",
  wav: "audio/wav",
  m4a: "audio/mp4",
  aac: "audio/aac",
  flac: "audio/flac",
  opus: "audio/ogg",
  oga: "audio/ogg",
  weba: "audio/webm",
  srt: "application/x-subrip",
  vtt: "text/vtt",
};

const HARD_NO = new Set(["mkv", "avi", "3gp"]);

export function sniffKind(name: string, mime = ""): Probe["kind"] {
  const ext = extensionOf(name);
  if (ext === "srt" || ext === "vtt") return "subtitle";
  if (mime.startsWith("video/") || VIDEO_EXTS.has(ext)) return "video";
  if (mime.startsWith("audio/") || AUDIO_EXTS.has(ext)) return "audio";
  return "unknown";
}

export function mimeFor(name: string, mime = ""): string {
  if (mime && mime !== "application/octet-stream") return mime;
  return MIME_BY_EXT[extensionOf(name)] ?? mime ?? "application/octet-stream";
}

/**
 * Ask the actual browser whether it can decode this type.
 * Never claims hardware/software decoder modes the web platform cannot select.
 */
export function probePlayback(name: string, mime = ""): Probe {
  const ext = extensionOf(name);
  const kind = sniffKind(name, mime);
  const resolved = mimeFor(name, mime);

  if (kind === "subtitle") {
    return { kind, mime: resolved, playable: true, canPlay: "probably" };
  }
  if (kind === "unknown") {
    return {
      kind,
      mime: resolved,
      playable: false,
      canPlay: "",
      reason: "This file is not a recognised audio or video type.",
    };
  }

  if (typeof document === "undefined") {
    return { kind, mime: resolved, playable: true, canPlay: "maybe" };
  }

  const el = document.createElement(kind === "audio" ? "audio" : "video");
  let canPlay: Probe["canPlay"] = "";
  try {
    canPlay = (el.canPlayType(resolved) || "") as Probe["canPlay"];
    if (!canPlay && resolved.includes("/")) {
      const generic = `${kind}/${ext === "mp4" || ext === "m4v" || ext === "m4a" ? "mp4" : ext}`;
      canPlay = (el.canPlayType(generic) || "") as Probe["canPlay"];
    }
  } catch {
    canPlay = "";
  }

  if (ext === "m3u8") {
    const hlsNative = canPlay === "probably" || canPlay === "maybe";
    return {
      kind,
      mime: resolved,
      playable: hlsNative,
      canPlay,
      reason: hlsNative
        ? undefined
        : "HLS (.m3u8) is not decoded by this browser. Use an MP4 or WebM URL, or Safari.",
    };
  }

  if (HARD_NO.has(ext) && !canPlay) {
    return {
      kind,
      mime: resolved,
      playable: false,
      canPlay,
      reason: `${ext.toUpperCase()} is not decoded by this browser. Convert to MP4 or WebM for playback.`,
    };
  }

  if (!canPlay && HARD_NO.has(ext)) {
    return {
      kind,
      mime: resolved,
      playable: false,
      canPlay,
      reason: `${ext.toUpperCase()} is not decoded by this browser. Convert to MP4 or WebM for playback.`,
    };
  }

  const playable = canPlay === "probably" || canPlay === "maybe" || (!HARD_NO.has(ext) && (ext === "mp4" || ext === "webm" || ext === "mp3" || ext === "wav" || ext === "ogg" || ext === "m4a"));

  return {
    kind,
    mime: resolved,
    playable,
    canPlay,
    reason: playable
      ? undefined
      : `This browser reports no decoder for ${resolved || ext || "this file"}.`,
  };
}

export function decoderDescription(): string {
  return "Browser auto";
}

export function decoderHelp(): string {
  return "The browser chooses a hardware or software decoder. UPLAY.IND cannot force HW / SW / HW+ modes the way a native Android player can — claiming otherwise would be fake.";
}
