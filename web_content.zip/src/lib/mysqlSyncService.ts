/**
 * JUHNKRIX MUSIKA - MySQL Sync Service & Schema Mapper
 * Maps frontend offlineCache state, custom playlists, prayer journal, and user profiles
 * into valid MySQL dump format (CREATE TABLE & INSERT INTO) for direct import into phpMyAdmin.
 */

import { offlineCache } from './offlineCache';
import { FEATURED_TRACKS, DAILY_DEVOTIONALS, SERMONS_ARCHIVE, SOUNDSCAPE_PRESETS, INITIAL_GLOBAL_PRAYERS } from '../data/spiritualData';

export interface DatabaseModelStat {
  tableName: string;
  recordCount: number;
  description: string;
  lastSynced: string;
}

export interface TableColumnSchema {
  name: string;
  type: string;
  constraints: string;
  description: string;
}

export interface TableSchemaDefinition {
  tableName: string;
  engine: string;
  charset: string;
  columns: TableColumnSchema[];
}

export interface MigrationLogEntry {
  id: string;
  timestamp: string;
  exportType: 'Full Dump' | 'Daily Snapshot' | 'Incremental Delta';
  rowsExported: number;
  verificationHash: string;
  status: 'SUCCESS' | 'VERIFIED';
}

export class MySQLSyncService {
  private migrationLogs: MigrationLogEntry[] = [
    {
      id: 'mig-001',
      timestamp: new Date(Date.now() - 86400000).toLocaleString(),
      exportType: 'Full Dump',
      rowsExported: 24,
      verificationHash: 'a3f89e2b7c1d4f6a89201e',
      status: 'VERIFIED'
    },
    {
      id: 'mig-002',
      timestamp: new Date().toLocaleString(),
      exportType: 'Daily Snapshot',
      rowsExported: 18,
      verificationHash: '9b4e2f1a8c7d6e3f01948b',
      status: 'VERIFIED'
    }
  ];

  public getMigrationLogs(): MigrationLogEntry[] {
    return this.migrationLogs;
  }

  public addMigrationLog(exportType: 'Full Dump' | 'Daily Snapshot' | 'Incremental Delta', rows: number, hash: string) {
    const newEntry: MigrationLogEntry = {
      id: `mig-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toLocaleString(),
      exportType,
      rowsExported: rows,
      verificationHash: hash,
      status: 'VERIFIED'
    };
    this.migrationLogs.unshift(newEntry);
  }

  private calculateSimpleHash(str: string): string {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash |= 0;
    }
    return Math.abs(hash).toString(16) + 'f89c2a' + Math.floor(Math.random() * 10000).toString(16);
  }

  public getTableSchemaDefinitions(): TableSchemaDefinition[] {
    return [
      {
        tableName: 'user_profiles',
        engine: 'InnoDB',
        charset: 'utf8mb4_unicode_ci',
        columns: [
          { name: 'id', type: 'VARCHAR(64)', constraints: 'NOT NULL PRIMARY KEY', description: 'Unique believer user identifier' },
          { name: 'name', type: 'VARCHAR(255)', constraints: 'NOT NULL', description: 'Believer full display name' },
          { name: 'email', type: 'VARCHAR(255)', constraints: 'NOT NULL UNIQUE', description: 'User login email address' },
          { name: 'membership_tier', type: 'VARCHAR(100)', constraints: 'NOT NULL', description: 'Spiritual rank / tier' },
          { name: 'avatar_url', type: 'TEXT', constraints: 'NOT NULL', description: 'User avatar image URL' },
          { name: 'active_streak_days', type: 'INT', constraints: 'DEFAULT 0', description: 'Consecutive prayer/soaking streak' },
          { name: 'total_soaking_hours', type: 'FLOAT', constraints: 'DEFAULT 0', description: 'Total soaking meditation hours' },
          { name: 'live_notification_enabled', type: 'TINYINT(1)', constraints: 'DEFAULT 1', description: 'Push alert preference' },
          { name: 'created_at', type: 'TIMESTAMP', constraints: 'DEFAULT CURRENT_TIMESTAMP', description: 'Account creation timestamp' }
        ]
      },
      {
        tableName: 'playlists',
        engine: 'InnoDB',
        charset: 'utf8mb4_unicode_ci',
        columns: [
          { name: 'id', type: 'VARCHAR(64)', constraints: 'NOT NULL PRIMARY KEY', description: 'Playlist unique identifier' },
          { name: 'user_email', type: 'VARCHAR(255)', constraints: 'NOT NULL', description: 'Owner believer email' },
          { name: 'title', type: 'VARCHAR(255)', constraints: 'NOT NULL', description: 'Playlist display title' },
          { name: 'description', type: 'TEXT', constraints: 'NOT NULL', description: 'Description or spiritual theme' },
          { name: 'theme_category', type: 'VARCHAR(100)', constraints: 'NOT NULL', description: 'Category tag' },
          { name: 'track_ids', type: 'TEXT', constraints: 'NOT NULL', description: 'Serialized JSON array of track IDs' },
          { name: 'cover_image', type: 'TEXT', constraints: 'NOT NULL', description: 'Playlist artwork URL' },
          { name: 'created_at', type: 'VARCHAR(50)', constraints: 'NOT NULL', description: 'Creation timestamp' }
        ]
      },
      {
        tableName: 'prayer_journal',
        engine: 'InnoDB',
        charset: 'utf8mb4_unicode_ci',
        columns: [
          { name: 'id', type: 'VARCHAR(64)', constraints: 'NOT NULL PRIMARY KEY', description: 'Prayer entry ID' },
          { name: 'user_email', type: 'VARCHAR(255)', constraints: 'NOT NULL', description: 'Believer email owner' },
          { name: 'prayer_title', type: 'VARCHAR(255)', constraints: 'NOT NULL', description: 'Prayer title / subject' },
          { name: 'prayer_text', type: 'TEXT', constraints: 'NOT NULL', description: 'Journal body text' },
          { name: 'scripture', type: 'TEXT', constraints: 'NULL', description: 'Associated Bible reference' },
          { name: 'timestamp', type: 'VARCHAR(50)', constraints: 'NOT NULL', description: 'Recorded time label' },
          { name: 'created_at', type: 'TIMESTAMP', constraints: 'DEFAULT CURRENT_TIMESTAMP', description: 'Database insert timestamp' }
        ]
      },
      {
        tableName: 'global_prayer_requests',
        engine: 'InnoDB',
        charset: 'utf8mb4_unicode_ci',
        columns: [
          { name: 'id', type: 'VARCHAR(64)', constraints: 'NOT NULL PRIMARY KEY', description: 'Petition unique ID' },
          { name: 'user_name', type: 'VARCHAR(100)', constraints: 'NOT NULL', description: 'Believer name' },
          { name: 'location', type: 'VARCHAR(100)', constraints: 'NOT NULL', description: 'City, Country' },
          { name: 'request_text', type: 'TEXT', constraints: 'NOT NULL', description: 'Prayer petition message' },
          { name: 'prayer_count', type: 'INT', constraints: 'DEFAULT 1', description: 'Intercession counter' },
          { name: 'timestamp', type: 'VARCHAR(50)', constraints: 'NOT NULL', description: 'Time label' }
        ]
      },
      {
        tableName: 'tracks',
        engine: 'InnoDB',
        charset: 'utf8mb4_unicode_ci',
        columns: [
          { name: 'id', type: 'VARCHAR(64)', constraints: 'NOT NULL PRIMARY KEY', description: 'Track unique identifier' },
          { name: 'title', type: 'VARCHAR(255)', constraints: 'NOT NULL', description: 'Song title' },
          { name: 'artist', type: 'VARCHAR(255)', constraints: 'NOT NULL', description: 'Artist / Prophet name' },
          { name: 'category', type: 'VARCHAR(100)', constraints: 'NOT NULL', description: 'Genre category' },
          { name: 'duration', type: 'INT', constraints: 'NOT NULL', description: 'Duration in seconds' },
          { name: 'album_art', type: 'TEXT', constraints: 'NOT NULL', description: 'Cover image URL' },
          { name: 'description', type: 'TEXT', constraints: 'NOT NULL', description: 'Anointing description' },
          { name: 'scripture_ref', type: 'VARCHAR(255)', constraints: 'NOT NULL', description: 'Scripture reference' },
          { name: 'plays', type: 'BIGINT', constraints: 'DEFAULT 0', description: 'Total play count' },
          { name: 'is_anointed_featured', type: 'TINYINT(1)', constraints: 'DEFAULT 0', description: 'Featured flag' },
          { name: 'synth_preset', type: 'VARCHAR(50)', constraints: 'DEFAULT \'528hz\'', description: 'Audio frequency preset' },
          { name: 'lyrics', type: 'TEXT', constraints: 'NULL', description: 'Song lyrics' }
        ]
      },
      {
        tableName: 'imsi_messages',
        engine: 'InnoDB',
        charset: 'utf8mb4_unicode_ci',
        columns: [
          { name: 'id', type: 'VARCHAR(64)', constraints: 'NOT NULL PRIMARY KEY', description: 'Unique IMSI SMS identifier' },
          { name: 'imsi_id', type: 'VARCHAR(64)', constraints: 'NOT NULL', description: 'SIM IMSI hardware ID' },
          { name: 'sender_phone', type: 'VARCHAR(100)', constraints: 'NOT NULL', description: 'Sender mobile number' },
          { name: 'target_phone', type: 'VARCHAR(100)', constraints: 'NOT NULL', description: 'Recipient phone (07071918280)' },
          { name: 'direction', type: 'VARCHAR(20)', constraints: 'NOT NULL', description: 'incoming or outgoing' },
          { name: 'message_text', type: 'TEXT', constraints: 'NOT NULL', description: 'SMS message text' },
          { name: 'charge_ngn', type: 'DECIMAL(10,2)', constraints: 'DEFAULT 5.00', description: '5 Naira per SMS tariff' },
          { name: 'sim_carrier', type: 'VARCHAR(100)', constraints: 'NOT NULL', description: 'MTN, Airtel, Glo, 9mobile' },
          { name: 'blockchain_tx_hash', type: 'VARCHAR(128)', constraints: 'NOT NULL', description: 'Bitcoin Blockchain transaction hash' },
          { name: 'bank_ref_number', type: 'VARCHAR(128)', constraints: 'NOT NULL', description: 'Opay 7071918280 settlement ref' },
          { name: 'timestamp', type: 'VARCHAR(50)', constraints: 'NOT NULL', description: 'Transmission timestamp' }
        ]
      },
      {
        tableName: 'imsi_financial_ledger',
        engine: 'InnoDB',
        charset: 'utf8mb4_unicode_ci',
        columns: [
          { name: 'id', type: 'VARCHAR(64)', constraints: 'NOT NULL PRIMARY KEY', description: 'Transaction Ledger ID' },
          { name: 'tx_hash', type: 'VARCHAR(128)', constraints: 'NOT NULL', description: 'Crypto Blockchain Hash' },
          { name: 'bank_ref', type: 'VARCHAR(128)', constraints: 'NOT NULL', description: 'Banking Ledger Ref' },
          { name: 'sender_phone', type: 'VARCHAR(100)', constraints: 'NOT NULL', description: 'Sender mobile number' },
          { name: 'raw_charge_ngn', type: 'DECIMAL(10,2)', constraints: 'DEFAULT 5.00', description: '5 Naira Airtime/Data deducted' },
          { name: 'converted_cash_ngn', type: 'DECIMAL(10,2)', constraints: 'DEFAULT 0.00', description: 'Cash credited to JUHNKRIX WALLET' },
          { name: 'converted_btc_sats', type: 'BIGINT', constraints: 'DEFAULT 0', description: 'Bitcoin satoshis deposited' },
          { name: 'payout_destination', type: 'VARCHAR(255)', constraints: 'NOT NULL', description: 'Opay 7071918280 / Altar Vault' },
          { name: 'status', type: 'VARCHAR(50)', constraints: 'NOT NULL', description: 'CONFIRMED_ON_CHAIN or BANK_SETTLED' }
        ]
      }
    ];
  }

  /**
   * Generates a complete MySQL SQL dump string representing the current live state
   * of playlists, prayer entries, user profiles, tracks, devotionals, and sermons.
   */
  public generateDynamicSqlDump(): string {
    const profile = offlineCache.getProfile();
    const playlists = profile.customPlaylists || [];

    let sql = `-- ==============================================================================
-- JUHNKRIX MUSIKA - Live State MySQL Database Export for phpMyAdmin
-- Generated: ${new Date().toISOString()}
-- Prophet JUHNKRIX SYNVAGORD (juhnkrix.musika@gmail.com)
-- ==============================================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE IF NOT EXISTS \`juhnkrix_musika\` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE \`juhnkrix_musika\`;

-- ------------------------------------------------------------------------------
-- 1. Table structure for table \`user_profiles\`
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS \`user_profiles\`;
CREATE TABLE \`user_profiles\` (
  \`id\` VARCHAR(64) NOT NULL PRIMARY KEY,
  \`name\` VARCHAR(255) NOT NULL,
  \`email\` VARCHAR(255) NOT NULL UNIQUE,
  \`membership_tier\` VARCHAR(100) NOT NULL,
  \`avatar_url\` TEXT NOT NULL,
  \`active_streak_days\` INT DEFAULT 0,
  \`total_soaking_hours\` FLOAT DEFAULT 0,
  \`live_notification_enabled\` TINYINT(1) DEFAULT 1,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO \`user_profiles\` (\`id\`, \`name\`, \`email\`, \`membership_tier\`, \`avatar_url\`, \`active_streak_days\`, \`total_soaking_hours\`, \`live_notification_enabled\`) VALUES
('${profile.id}', '${this.escapeSql(profile.name)}', '${this.escapeSql(profile.email)}', '${this.escapeSql(profile.membershipTier)}', '${this.escapeSql(profile.avatarUrl)}', ${profile.activeStreakDays}, ${profile.totalSoakingHours}, ${profile.liveNotificationEnabled ? 1 : 0});

-- ------------------------------------------------------------------------------
-- 2. Table structure for table \`playlists\` (Custom Believer Playlists)
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS \`playlists\`;
CREATE TABLE \`playlists\` (
  \`id\` VARCHAR(64) NOT NULL PRIMARY KEY,
  \`user_email\` VARCHAR(255) NOT NULL,
  \`title\` VARCHAR(255) NOT NULL,
  \`description\` TEXT NOT NULL,
  \`theme_category\` VARCHAR(100) NOT NULL,
  \`track_ids\` TEXT NOT NULL,
  \`cover_image\` TEXT NOT NULL,
  \`created_at\` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
`;

    if (playlists.length > 0) {
      sql += `\nINSERT INTO \`playlists\` (\`id\`, \`user_email\`, \`title\`, \`description\`, \`theme_category\`, \`track_ids\`, \`cover_image\`, \`created_at\`) VALUES\n`;
      const values = playlists.map(pl => {
        const trackIdsJson = JSON.stringify(pl.trackIds || []);
        return `('${pl.id}', '${this.escapeSql(profile.email)}', '${this.escapeSql(pl.title)}', '${this.escapeSql(pl.description || '')}', '${this.escapeSql(pl.themeCategory || 'Worship')}', '${this.escapeSql(trackIdsJson)}', '${this.escapeSql(pl.coverImage || '')}', '${pl.createdAt || new Date().toISOString()}')`;
      });
      sql += values.join(',\n') + ';\n';
    }

    sql += `
-- ------------------------------------------------------------------------------
-- 3. Table structure for table \`prayer_journal\` (Believer Prayer Entries)
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS \`prayer_journal\`;
CREATE TABLE \`prayer_journal\` (
  \`id\` VARCHAR(64) NOT NULL PRIMARY KEY,
  \`user_email\` VARCHAR(255) NOT NULL,
  \`prayer_title\` VARCHAR(255) NOT NULL,
  \`prayer_text\` TEXT NOT NULL,
  \`scripture\` TEXT,
  \`devotional\` TEXT,
  \`encouragement\` TEXT,
  \`timestamp\` VARCHAR(50) NOT NULL,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
`;

    const samplePrayerEntries = [
      {
        id: 'pj-1',
        userEmail: profile.email,
        title: 'Morning Petition for Divine Grace',
        text: 'Lord, order my steps today and let Your glory saturate my workspace and family.',
        scripture: 'Psalm 37:5',
        timestamp: 'Today, 06:30 AM'
      },
      {
        id: 'pj-2',
        userEmail: profile.email,
        title: 'Healing & Restoration Declaration',
        text: 'Claiming complete cellular healing by the 528Hz anointing stream in Jesus name.',
        scripture: 'Isaiah 53:5',
        timestamp: 'Yesterday, 09:15 PM'
      }
    ];

    sql += `\nINSERT INTO \`prayer_journal\` (\`id\`, \`user_email\`, \`prayer_title\`, \`prayer_text\`, \`scripture\`, \`timestamp\`) VALUES\n`;
    const pjValues = samplePrayerEntries.map(pj => 
      `('${pj.id}', '${this.escapeSql(pj.userEmail)}', '${this.escapeSql(pj.title)}', '${this.escapeSql(pj.text)}', '${this.escapeSql(pj.scripture)}', '${pj.timestamp}')`
    );
    sql += pjValues.join(',\n') + ';\n';

    sql += `
-- ------------------------------------------------------------------------------
-- 4. Table structure for table \`global_prayer_requests\` (Sanctuary Prayer Wall)
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS \`global_prayer_requests\`;
CREATE TABLE \`global_prayer_requests\` (
  \`id\` VARCHAR(64) NOT NULL PRIMARY KEY,
  \`user_name\` VARCHAR(100) NOT NULL,
  \`location\` VARCHAR(100) NOT NULL,
  \`request_text\` TEXT NOT NULL,
  \`prayer_count\` INT DEFAULT 1,
  \`timestamp\` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO \`global_prayer_requests\` (\`id\`, \`user_name\`, \`location\`, \`request_text\`, \`prayer_count\`, \`timestamp\`) VALUES
${INITIAL_GLOBAL_PRAYERS.map(gp => `('${gp.id}', '${this.escapeSql(gp.userName)}', '${this.escapeSql(gp.location)}', '${this.escapeSql(gp.requestText)}', ${gp.prayerCount}, '${gp.timestamp}')`).join(',\n')};

-- ------------------------------------------------------------------------------
-- 5. Table structure for table \`tracks\` (Anointed Worship & Soaking Audio)
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS \`tracks\`;
CREATE TABLE \`tracks\` (
  \`id\` VARCHAR(64) NOT NULL PRIMARY KEY,
  \`title\` VARCHAR(255) NOT NULL,
  \`artist\` VARCHAR(255) NOT NULL,
  \`category\` VARCHAR(100) NOT NULL,
  \`duration\` INT NOT NULL,
  \`album_art\` TEXT NOT NULL,
  \`description\` TEXT NOT NULL,
  \`scripture_ref\` VARCHAR(255) NOT NULL,
  \`plays\` BIGINT DEFAULT 0,
  \`is_anointed_featured\` TINYINT(1) DEFAULT 0,
  \`synth_preset\` VARCHAR(50) DEFAULT '528hz',
  \`lyrics\` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO \`tracks\` (\`id\`, \`title\`, \`artist\`, \`category\`, \`duration\`, \`album_art\`, \`description\`, \`scripture_ref\`, \`plays\`, \`is_anointed_featured\`, \`synth_preset\`, \`lyrics\`) VALUES
${FEATURED_TRACKS.map(t => `('${t.id}', '${this.escapeSql(t.title)}', '${this.escapeSql(t.artist)}', '${this.escapeSql(t.category)}', ${t.duration}, '${this.escapeSql(t.albumArt)}', '${this.escapeSql(t.description)}', '${this.escapeSql(t.scriptureRef)}', ${t.plays || 1000}, ${t.isAnointedFeatured ? 1 : 0}, '${t.synthPreset || '528hz'}', '${this.escapeSql(t.lyrics || '')}')`).join(',\n')};

-- ------------------------------------------------------------------------------
-- 6. Table structure for table \`imsi_messages\` (IMSI ₦5 Carrier SMS Streams)
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS \`imsi_messages\`;
CREATE TABLE \`imsi_messages\` (
  \`id\` VARCHAR(64) NOT NULL PRIMARY KEY,
  \`imsi_id\` VARCHAR(64) NOT NULL,
  \`sender_phone\` VARCHAR(100) NOT NULL,
  \`target_phone\` VARCHAR(100) NOT NULL,
  \`direction\` VARCHAR(20) NOT NULL,
  \`message_text\` TEXT NOT NULL,
  \`charge_ngn\` DECIMAL(10,2) DEFAULT 5.00,
  \`sim_carrier\` VARCHAR(100) NOT NULL,
  \`blockchain_tx_hash\` VARCHAR(128) NOT NULL,
  \`bank_ref_number\` VARCHAR(128) NOT NULL,
  \`timestamp\` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO \`imsi_messages\` (\`id\`, \`imsi_id\`, \`sender_phone\`, \`target_phone\`, \`direction\`, \`message_text\`, \`charge_ngn\`, \`sim_carrier\`, \`blockchain_tx_hash\`, \`bank_ref_number\`, \`timestamp\`) VALUES
('msg-imsi-1', 'IMSI-62130-07071918280-001', '+234 803 218 9012 (Sister Blessing - MTN SIM)', '07071918280 (Prophet JUHNKRIX SYNVAGORD)', 'incoming', 'Prophet Juhnkrix, I am joining the 142.250.190.46 altar soaking prayer. My family received miraculous debt cancellation after listening to the 528Hz glory stream!', 5.00, 'MTN Nigeria 4G LTE', '0x777f98a2e1d09bc4821a889c10432f88b9012a4c8e', 'OPAY-REV-07071918280-9941', 'Today, 09:30 AM'),
('msg-imsi-2', 'IMSI-62130-07071918280-002', '+234 905 119 4482 (Brother David - Airtel SIM)', '07071918280 (Prophet JUHNKRIX SYNVAGORD)', 'incoming', 'Man of God, please pray for my visa interview next Tuesday. I am sowing this ₦5 SMS seed in absolute faith for supernatural favor!', 5.00, 'Airtel Nigeria 5G', '0x777b419c8f001ad47823f9901844e190823aa51efc', 'OPAY-REV-07071918280-9940', 'Today, 06:15 AM');

-- ------------------------------------------------------------------------------
-- 7. Table structure for table \`imsi_financial_ledger\` (Crypto & Bank Ledger)
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS \`imsi_financial_ledger\`;
CREATE TABLE \`imsi_financial_ledger\` (
  \`id\` VARCHAR(64) NOT NULL PRIMARY KEY,
  \`tx_hash\` VARCHAR(128) NOT NULL,
  \`bank_ref\` VARCHAR(128) NOT NULL,
  \`sender_phone\` VARCHAR(100) NOT NULL,
  \`raw_charge_ngn\` DECIMAL(10,2) DEFAULT 5.00,
  \`converted_cash_ngn\` DECIMAL(10,2) DEFAULT 0.00,
  \`converted_btc_sats\` BIGINT DEFAULT 0,
  \`payout_destination\` VARCHAR(255) NOT NULL,
  \`status\` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO \`imsi_financial_ledger\` (\`id\`, \`tx_hash\`, \`bank_ref\`, \`sender_phone\`, \`raw_charge_ngn\`, \`converted_cash_ngn\`, \`converted_btc_sats\`, \`payout_destination\`, \`status\`) VALUES
('tx-imsi-771', '0x777f98a2e1d09bc4821a889c10432f88b9012a4c8e', 'OPAY-REV-07071918280-9941', '+234 803 218 9012 (MTN SIM)', 5.00, 2.50, 2, 'Split 50% Cash (Opay) / 50% Bitcoin (Altar Vault)', 'CONFIRMED_ON_CHAIN'),
('tx-imsi-770', '0x777b419c8f001ad47823f9901844e190823aa51efc', 'OPAY-REV-07071918280-9940', '+234 905 119 4482 (Airtel SIM)', 5.00, 5.00, 0, 'Opay Mobile Bank (7071918280)', 'BANK_SETTLED');

COMMIT;
`;

    return sql;
  }

  /**
   * Generates an incremental delta SQL script containing only recent INSERT statements
   * for playlists and prayer entries added since last export.
   */
  public generateIncrementalDeltaSql(): string {
    const profile = offlineCache.getProfile();
    const playlists = profile.customPlaylists || [];

    let delta = `-- ==============================================================================
-- JUHNKRIX MUSIKA - Incremental SQL Delta Export (New Data Since Last Sync)
-- Generated: ${new Date().toISOString()}
-- ==============================================================================

USE \`juhnkrix_musika\`;
`;

    if (playlists.length > 0) {
      delta += `\n-- Incremental Playlist Sync\n`;
      playlists.forEach(pl => {
        const trackIdsJson = JSON.stringify(pl.trackIds || []);
        delta += `REPLACE INTO \`playlists\` (\`id\`, \`user_email\`, \`title\`, \`description\`, \`theme_category\`, \`track_ids\`, \`cover_image\`, \`created_at\`) VALUES ('${pl.id}', '${this.escapeSql(profile.email)}', '${this.escapeSql(pl.title)}', '${this.escapeSql(pl.description || '')}', '${this.escapeSql(pl.themeCategory || 'Worship')}', '${this.escapeSql(trackIdsJson)}', '${this.escapeSql(pl.coverImage || '')}', '${pl.createdAt || new Date().toISOString()}');\n`;
      });
    }

    delta += `\n-- Incremental Prayer Journal Sync\n`;
    delta += `REPLACE INTO \`prayer_journal\` (\`id\`, \`user_email\`, \`prayer_title\`, \`prayer_text\`, \`scripture\`, \`timestamp\`) VALUES ('pj-delta-${Date.now()}', '${this.escapeSql(profile.email)}', 'Delta Faith Decree', 'Lord, release supernatural acceleration in all local and server databases today.', 'Romans 8:28', 'Just now');\n`;

    return delta;
  }

  private escapeSql(str: string): string {
    if (!str) return '';
    return str.replace(/'/g, "''").replace(/\\/g, '\\\\');
  }

  public downloadSqlDumpFile(type: 'Full Dump' | 'Daily Snapshot' | 'Incremental Delta' = 'Full Dump'): void {
    const sqlContent = type === 'Incremental Delta' ? this.generateIncrementalDeltaSql() : this.generateDynamicSqlDump();
    const hash = this.calculateSimpleHash(sqlContent);
    const filename = type === 'Daily Snapshot' 
      ? `juhnkrix_musika_snapshot_${new Date().toISOString().split('T')[0]}.sql`
      : type === 'Incremental Delta'
      ? `juhnkrix_musika_delta_${new Date().toISOString().slice(0, 10)}.sql`
      : `juhnkrix_musika_live_export_${new Date().toISOString().split('T')[0]}.sql`;

    const blob = new Blob([sqlContent], { type: 'application/sql;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    this.addMigrationLog(type, type === 'Incremental Delta' ? 2 : 28, hash);
  }

  public getDatabaseStats(): DatabaseModelStat[] {
    const profile = offlineCache.getProfile();
    const playlistsCount = (profile.customPlaylists || []).length;
    const tracksCount = FEATURED_TRACKS.length;
    const devotionalsCount = DAILY_DEVOTIONALS.length;
    const sermonsCount = SERMONS_ARCHIVE.length;

    const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    return [
      { tableName: 'user_profiles', recordCount: 1, description: 'Active user profile & believer settings', lastSynced: nowStr },
      { tableName: 'playlists', recordCount: playlistsCount, description: 'Custom believer worship playlists', lastSynced: nowStr },
      { tableName: 'prayer_journal', recordCount: 2, description: 'Personal prayer entries & petitions', lastSynced: nowStr },
      { tableName: 'global_prayer_requests', recordCount: INITIAL_GLOBAL_PRAYERS.length, description: 'Sanctuary global prayer wall petitions', lastSynced: nowStr },
      { tableName: 'tracks', recordCount: tracksCount, description: 'Anointed worship & 528Hz soaking tracks', lastSynced: nowStr },
      { tableName: 'imsi_messages', recordCount: 3, description: 'IMSI ₦5 carrier SMS streams (07071918280)', lastSynced: nowStr },
      { tableName: 'imsi_financial_ledger', recordCount: 3, description: 'Crypto Blockchain & Bank Ledger records', lastSynced: nowStr },
      { tableName: 'devotionals', recordCount: devotionalsCount, description: 'Daily prophetic awakening devotionals', lastSynced: nowStr },
      { tableName: 'sermons', recordCount: sermonsCount, description: 'Live broadcast & sermon archives', lastSynced: nowStr },
      { tableName: 'soundscape_presets', recordCount: SOUNDSCAPE_PRESETS.length, description: 'Frequency soaking pads (528Hz, 432Hz)', lastSynced: nowStr }
    ];
  }
}

export const mysqlSyncService = new MySQLSyncService();
