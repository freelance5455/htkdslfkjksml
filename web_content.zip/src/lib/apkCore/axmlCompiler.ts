import type { ApkBuildConfig } from '../../types/apk.ts';
import { concatBytes, padTo4Bytes, writeUtf16Le } from './bytes.ts';

const CHUNK_RES_XML_TYPE = 0x0003;
const CHUNK_RES_STRING_POOL_TYPE = 0x0001;
const CHUNK_RES_XML_RESOURCE_MAP_TYPE = 0x0180;
const CHUNK_RES_XML_START_NAMESPACE_TYPE = 0x0100;
const CHUNK_RES_XML_END_NAMESPACE_TYPE = 0x0101;
const CHUNK_RES_XML_START_ELEMENT_TYPE = 0x0102;
const CHUNK_RES_XML_END_ELEMENT_TYPE = 0x0103;

const TYPE_REFERENCE = 0x01;
const TYPE_STRING = 0x03;
const TYPE_INT_DEC = 0x10;
const TYPE_INT_HEX = 0x11;
const TYPE_INT_BOOLEAN = 0x12;

const ANDROID_ATTR_IDS: Record<string, number> = {
  theme: 0x01010000,
  label: 0x01010001,
  icon: 0x01010002,
  name: 0x01010003,
  exported: 0x01010010,
  screenOrientation: 0x0101001e,
  configChanges: 0x0101001f,
  value: 0x01010024,
  minSdkVersion: 0x0101020c,
  versionCode: 0x0101021b,
  versionName: 0x0101021c,
  targetSdkVersion: 0x01010270,
  hardwareAccelerated: 0x010102d3,
  usesCleartextTraffic: 0x010104ec,
};

interface AxmlAttr {
  ns: string | null;
  name: string;
  rawValue: string | null;
  dataType: number;
  data: number;
}

interface AxmlNode {
  tag: string;
  attrs: AxmlAttr[];
  children: AxmlNode[];
}

function encodeUtf16PoolString(str: string): Uint8Array {
  const charLen = str.length;
  const buf = new Uint8Array(2 + charLen * 2 + 2);
  const view = new DataView(buf.buffer);
  view.setUint16(0, charLen, true);
  writeUtf16Le(buf, 2, str);
  view.setUint16(2 + charLen * 2, 0, true);
  return buf;
}

function buildStringPoolChunk(strings: string[]): Uint8Array {
  const stringBuffers = strings.map(encodeUtf16PoolString);
  const offsets: number[] = [];
  let cursor = 0;
  for (const b of stringBuffers) {
    offsets.push(cursor);
    cursor += b.length;
  }
  const rawStringData = padTo4Bytes(concatBytes(stringBuffers));
  const headerSize = 28;
  const offsetsSize = strings.length * 4;
  const stringsStart = headerSize + offsetsSize;
  const totalSize = stringsStart + rawStringData.length;

  const header = new Uint8Array(headerSize);
  const hv = new DataView(header.buffer);
  hv.setUint16(0, CHUNK_RES_STRING_POOL_TYPE, true);
  hv.setUint16(2, headerSize, true);
  hv.setUint32(4, totalSize, true);
  hv.setUint32(8, strings.length, true);
  hv.setUint32(12, 0, true);
  hv.setUint32(16, 0, true);
  hv.setUint32(20, stringsStart, true);
  hv.setUint32(24, 0, true);

  const offsetBuf = new Uint8Array(offsetsSize);
  const ov = new DataView(offsetBuf.buffer);
  offsets.forEach((off, i) => ov.setUint32(i * 4, off, true));

  return concatBytes([header, offsetBuf, rawStringData]);
}

function mapOrientationToInt(orientation: ApkBuildConfig['orientation']): number {
  switch (orientation) {
    case 'landscape':
      return 0;
    case 'portrait':
      return 1;
    default:
      return -1;
  }
}

function getAllManifestPermissions(config: ApkBuildConfig): string[] {
  const list = config.permissions.map((p) => `android.permission.${p}`);
  if (config.enablePlayBilling) {
    list.push('com.android.vending.BILLING');
  }
  if (config.enableAdMob) {
    list.push('com.google.android.gms.permission.AD_ID');
  }
  if (config.enableLaunchEvents && config.launchWebhookUrl.trim()) {
    if (!list.includes('android.permission.INTERNET')) {
      list.unshift('android.permission.INTERNET');
    }
  }
  return Array.from(new Set(list));
}

export function buildManifestXmlText(config: ApkBuildConfig): string {
  const themeRef = config.fullscreen
    ? '@android:style/Theme.Material.Light.NoActionBar.Fullscreen'
    : '@android:style/Theme.Material.Light.NoActionBar';
  const activityClass = `${config.packageId}.WebAppActivity`;

  const perms = getAllManifestPermissions(config)
    .map((p) => `    <uses-permission android:name="${p}" />`)
    .join('\n');

  const adMobMeta =
    config.enableAdMob && config.adMobAppId.trim()
      ? `\n        <meta-data\n            android:name="com.google.android.gms.ads.APPLICATION_ID"\n            android:value="${config.adMobAppId.trim()}" />\n`
      : '';

  return `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="${config.packageId}"
    android:versionCode="${config.versionCode}"
    android:versionName="${config.versionName}">

    <uses-sdk
        android:minSdkVersion="${config.minSdkVersion}"
        android:targetSdkVersion="${config.targetSdkVersion}" />

${perms}

    <application
        android:label="@string/app_name"
        android:icon="@mipmap/ic_launcher"
        android:hardwareAccelerated="true"
        android:usesCleartextTraffic="${config.allowCleartextTraffic}"
        android:theme="${themeRef}">${adMobMeta}

        <activity
            android:name="${activityClass}"
            android:exported="true"
            android:screenOrientation="${config.orientation}"
            android:configChanges="orientation|screenSize|keyboardHidden|screenLayout|smallestScreenSize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`;
}

export function compileBinaryManifest(config: ApkBuildConfig): Uint8Array {
  const ANDROID_NS = 'http://schemas.android.com/apk/res/android';
  const activityClass = `${config.packageId}.WebAppActivity`;
  const themeResId = config.fullscreen ? 0x01030230 : 0x0103022f;
  const configChangesMask = 0x0fb0;

  const permissions = getAllManifestPermissions(config);
  const appChildren: AxmlNode[] = [];

  if (config.enableAdMob && config.adMobAppId.trim()) {
    appChildren.push({
      tag: 'meta-data',
      attrs: [
        {
          ns: ANDROID_NS,
          name: 'name',
          rawValue: 'com.google.android.gms.ads.APPLICATION_ID',
          dataType: TYPE_STRING,
          data: 0,
        },
        {
          ns: ANDROID_NS,
          name: 'value',
          rawValue: config.adMobAppId.trim(),
          dataType: TYPE_STRING,
          data: 0,
        },
      ],
      children: [],
    });
  }

  appChildren.push({
    tag: 'activity',
    attrs: [
      {
        ns: ANDROID_NS,
        name: 'name',
        rawValue: activityClass,
        dataType: TYPE_STRING,
        data: 0,
      },
      {
        ns: ANDROID_NS,
        name: 'exported',
        rawValue: null,
        dataType: TYPE_INT_BOOLEAN,
        data: -1,
      },
      {
        ns: ANDROID_NS,
        name: 'screenOrientation',
        rawValue: null,
        dataType: TYPE_INT_DEC,
        data: mapOrientationToInt(config.orientation),
      },
      {
        ns: ANDROID_NS,
        name: 'configChanges',
        rawValue: null,
        dataType: TYPE_INT_HEX,
        data: configChangesMask,
      },
    ],
    children: [
      {
        tag: 'intent-filter',
        attrs: [],
        children: [
          {
            tag: 'action',
            attrs: [
              {
                ns: ANDROID_NS,
                name: 'name',
                rawValue: 'android.intent.action.MAIN',
                dataType: TYPE_STRING,
                data: 0,
              },
            ],
            children: [],
          },
          {
            tag: 'category',
            attrs: [
              {
                ns: ANDROID_NS,
                name: 'name',
                rawValue: 'android.intent.category.LAUNCHER',
                dataType: TYPE_STRING,
                data: 0,
              },
            ],
            children: [],
          },
        ],
      },
    ],
  });

  const root: AxmlNode = {
    tag: 'manifest',
    attrs: [
      {
        ns: ANDROID_NS,
        name: 'versionCode',
        rawValue: null,
        dataType: TYPE_INT_DEC,
        data: config.versionCode,
      },
      {
        ns: ANDROID_NS,
        name: 'versionName',
        rawValue: config.versionName,
        dataType: TYPE_STRING,
        data: 0,
      },
      {
        ns: null,
        name: 'package',
        rawValue: config.packageId,
        dataType: TYPE_STRING,
        data: 0,
      },
    ],
    children: [
      {
        tag: 'uses-sdk',
        attrs: [
          {
            ns: ANDROID_NS,
            name: 'minSdkVersion',
            rawValue: null,
            dataType: TYPE_INT_DEC,
            data: config.minSdkVersion,
          },
          {
            ns: ANDROID_NS,
            name: 'targetSdkVersion',
            rawValue: null,
            dataType: TYPE_INT_DEC,
            data: config.targetSdkVersion,
          },
        ],
        children: [],
      },
      ...permissions.map<AxmlNode>((perm) => ({
        tag: 'uses-permission',
        attrs: [
          {
            ns: ANDROID_NS,
            name: 'name',
            rawValue: perm,
            dataType: TYPE_STRING,
            data: 0,
          },
        ],
        children: [],
      })),
      {
        tag: 'application',
        attrs: [
          {
            ns: ANDROID_NS,
            name: 'theme',
            rawValue: null,
            dataType: TYPE_REFERENCE,
            data: themeResId,
          },
          {
            ns: ANDROID_NS,
            name: 'label',
            rawValue: null,
            dataType: TYPE_REFERENCE,
            data: 0x7f010000,
          },
          {
            ns: ANDROID_NS,
            name: 'icon',
            rawValue: null,
            dataType: TYPE_REFERENCE,
            data: 0x7f020000,
          },
          {
            ns: ANDROID_NS,
            name: 'hardwareAccelerated',
            rawValue: null,
            dataType: TYPE_INT_BOOLEAN,
            data: -1,
          },
          {
            ns: ANDROID_NS,
            name: 'usesCleartextTraffic',
            rawValue: null,
            dataType: TYPE_INT_BOOLEAN,
            data: config.allowCleartextTraffic ? -1 : 0,
          },
        ],
        children: appChildren,
      },
    ],
  };

  const attrEntries = Object.entries(ANDROID_ATTR_IDS).sort((a, b) => a[1] - b[1]);
  const stringPool: string[] = [];
  const stringMap = new Map<string, number>();

  const intern = (s: string): number => {
    const existing = stringMap.get(s);
    if (existing !== undefined) return existing;
    const idx = stringPool.length;
    stringPool.push(s);
    stringMap.set(s, idx);
    return idx;
  };

  const resourceIds: number[] = [];
  for (const [attrName, resId] of attrEntries) {
    intern(attrName);
    resourceIds.push(resId);
  }

  intern('android');
  intern(ANDROID_NS);

  const collectStrings = (node: AxmlNode) => {
    intern(node.tag);
    for (const attr of node.attrs) {
      intern(attr.name);
      if (attr.ns) intern(attr.ns);
      if (attr.rawValue !== null) intern(attr.rawValue);
    }
    node.children.forEach(collectStrings);
  };
  collectStrings(root);

  const stringPoolChunk = buildStringPoolChunk(stringPool);

  const resMapChunk = new Uint8Array(8 + resourceIds.length * 4);
  const rmv = new DataView(resMapChunk.buffer);
  rmv.setUint16(0, CHUNK_RES_XML_RESOURCE_MAP_TYPE, true);
  rmv.setUint16(2, 8, true);
  rmv.setUint32(4, resMapChunk.length, true);
  resourceIds.forEach((id, i) => rmv.setUint32(8 + i * 4, id, true));

  const chunks: Uint8Array[] = [];
  let lineNum = 1;

  const nsPrefixIdx = intern('android');
  const nsUriIdx = intern(ANDROID_NS);

  const startNs = new Uint8Array(24);
  const snsv = new DataView(startNs.buffer);
  snsv.setUint16(0, CHUNK_RES_XML_START_NAMESPACE_TYPE, true);
  snsv.setUint16(2, 16, true);
  snsv.setUint32(4, 24, true);
  snsv.setUint32(8, lineNum, true);
  snsv.setInt32(12, -1, true);
  snsv.setInt32(16, nsPrefixIdx, true);
  snsv.setInt32(20, nsUriIdx, true);
  chunks.push(startNs);

  const emitNode = (node: AxmlNode) => {
    lineNum += 1;
    const startLine = lineNum;
    const tagIdx = intern(node.tag);
    const attrCount = node.attrs.length;
    const startElemSize = 36 + attrCount * 20;
    const startElem = new Uint8Array(startElemSize);
    const sev = new DataView(startElem.buffer);
    sev.setUint16(0, CHUNK_RES_XML_START_ELEMENT_TYPE, true);
    sev.setUint16(2, 16, true);
    sev.setUint32(4, startElemSize, true);
    sev.setUint32(8, startLine, true);
    sev.setInt32(12, -1, true);
    sev.setInt32(16, -1, true);
    sev.setInt32(20, tagIdx, true);
    sev.setUint16(24, 20, true);
    sev.setUint16(26, 20, true);
    sev.setUint16(28, attrCount, true);
    sev.setUint16(30, 0, true);
    sev.setUint16(32, 0, true);
    sev.setUint16(34, 0, true);

    node.attrs.forEach((attr, idx) => {
      const off = 36 + idx * 20;
      const nsIdx = attr.ns ? intern(attr.ns) : -1;
      const nameIdx = intern(attr.name);
      const rawValIdx = attr.rawValue !== null ? intern(attr.rawValue) : -1;
      const dataVal = attr.dataType === TYPE_STRING ? rawValIdx : attr.data;

      sev.setInt32(off, nsIdx, true);
      sev.setInt32(off + 4, nameIdx, true);
      sev.setInt32(off + 8, rawValIdx, true);
      sev.setUint16(off + 12, 8, true);
      sev.setUint8(off + 14, 0);
      sev.setUint8(off + 15, attr.dataType);
      sev.setInt32(off + 16, dataVal | 0, true);
    });

    chunks.push(startElem);
    node.children.forEach(emitNode);

    const endElem = new Uint8Array(24);
    const eev = new DataView(endElem.buffer);
    eev.setUint16(0, CHUNK_RES_XML_END_ELEMENT_TYPE, true);
    eev.setUint16(2, 16, true);
    eev.setUint32(4, 24, true);
    eev.setUint32(8, lineNum, true);
    eev.setInt32(12, -1, true);
    eev.setInt32(16, -1, true);
    eev.setInt32(20, tagIdx, true);
    chunks.push(endElem);
  };

  emitNode(root);

  const endNs = new Uint8Array(24);
  const ensv = new DataView(endNs.buffer);
  ensv.setUint16(0, CHUNK_RES_XML_END_NAMESPACE_TYPE, true);
  ensv.setUint16(2, 16, true);
  ensv.setUint32(4, 24, true);
  ensv.setUint32(8, lineNum + 1, true);
  ensv.setInt32(12, -1, true);
  ensv.setInt32(16, nsPrefixIdx, true);
  ensv.setInt32(20, nsUriIdx, true);
  chunks.push(endNs);

  const body = concatBytes([stringPoolChunk, resMapChunk, ...chunks]);
  const xmlHeader = new Uint8Array(8);
  const xhv = new DataView(xmlHeader.buffer);
  xhv.setUint16(0, CHUNK_RES_XML_TYPE, true);
  xhv.setUint16(2, 8, true);
  xhv.setUint32(4, 8 + body.length, true);

  return concatBytes([xmlHeader, body]);
}
