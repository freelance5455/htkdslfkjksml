import type { ApkBuildConfig } from '../../types/apk.ts';

function escapeHtml(input: string): string {
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function buildDeveloperAboutHtml(config: ApkBuildConfig): string {
  const d = config.developer;
  const links = [
    { label: 'Official Website', url: d.websiteUrl },
    { label: 'GitHub', url: d.githubUrl },
    { label: 'X / Twitter', url: d.xTwitterUrl },
    { label: 'YouTube', url: d.youtubeUrl },
    { label: 'Discord Community', url: d.discordUrl },
    { label: 'Instagram', url: d.instagramUrl },
    { label: 'TikTok', url: d.tiktokUrl },
    { label: 'Privacy Policy', url: d.privacyPolicyUrl },
    { label: 'Terms of Service', url: d.termsUrl },
  ].filter((item) => item.url && item.url.trim().length > 0);

  const linkItems = links
    .map(
      (l) =>
        `<a class="link-row" href="${escapeHtml(l.url.trim())}" target="_blank" rel="noopener noreferrer"><span>${escapeHtml(l.label)}</span><span class="arrow">→</span></a>`
    )
    .join('\n      ');

  const emailLink = d.supportEmail.trim()
    ? `<a class="link-row" href="mailto:${escapeHtml(d.supportEmail.trim())}"><span>Support Email (${escapeHtml(d.supportEmail.trim())})</span><span class="arrow">→</span></a>`
    : '';

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>About ${escapeHtml(d.developerName || config.appName)}</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: system-ui, -apple-system, sans-serif; }
    body { background: #f8fafc; color: #0f172a; padding: 24px 16px; max-width: 540px; margin: 0 auto; }
    .card { background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; }
    .head { padding: 20px; border-bottom: 1px solid #e2e8f0; }
    h1 { font-size: 18px; font-weight: 700; }
    .sub { font-size: 13px; color: #64748b; margin-top: 4px; }
    .link-row { display: flex; justify-content: space-between; align-items: center; padding: 14px 20px; border-bottom: 1px solid #f1f5f9; text-decoration: none; color: #0f172a; font-size: 14px; font-weight: 500; }
    .link-row:last-child { border-bottom: 0; }
    .arrow { color: #64748b; }
    .back { display: inline-block; margin-top: 16px; font-size: 13px; color: #16a34a; text-decoration: none; font-weight: 600; }
  </style>
</head>
<body>
  <div class="card">
    <div class="head">
      <h1>${escapeHtml(d.developerName || config.appName)}</h1>
      <div class="sub">${escapeHtml(config.appName)} · v${escapeHtml(config.versionName)} (${config.packageId})</div>
    </div>
    <div>
      ${emailLink}
      ${linkItems || '<div class="link-row"><span>No external developer links configured.</span></div>'}
    </div>
  </div>
  <a class="back" href="index.html">← Back to App</a>
</body>
</html>`;
}

export function injectSplashIntoHtml(html: string, config: ApkBuildConfig): string {
  const s = config.splash;
  if (!s.enabled) return html;

  const headline = escapeHtml(s.headline || config.appName);
  const tagline = escapeHtml(s.tagline || '');
  const logoImg =
    s.customLogoBase64Png || config.iconBase64Png
      ? `<img src="data:image/png;base64,${(s.customLogoBase64Png || config.iconBase64Png || '').replace(/^data:image\/\w+;base64,/, '')}" alt="" style="width:${s.logoScale === 'lg' ? 96 : s.logoScale === 'sm' ? 56 : 76}px;height:${s.logoScale === 'lg' ? 96 : s.logoScale === 'sm' ? 56 : 76}px;border-radius:18px;object-fit:cover;" />`
      : '';

  const spinnerCss = s.showSpinner
    ? `<style>@keyframes w2aSpin{to{transform:rotate(360deg)}}</style><div style="width:22px;height:22px;border:2.5px solid rgba(255,255,255,0.28);border-top-color:${escapeHtml(s.textColor)};border-radius:50%;animation:w2aSpin .8s linear infinite;margin-top:16px;"></div>`
    : '';

  const splashOverlay = `<div id="web2apk-splash" style="position:fixed;inset:0;z-index:2147483647;background:${escapeHtml(s.backgroundColor)};color:${escapeHtml(s.textColor)};display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:24px;font-family:system-ui,-apple-system,sans-serif;transition:opacity 240ms ease;">
  ${logoImg}
  <div style="font-size:20px;font-weight:700;margin-top:14px;">${headline}</div>
  ${tagline ? `<div style="font-size:13px;opacity:0.8;margin-top:6px;max-width:260px;">${tagline}</div>` : ''}
  ${spinnerCss}
</div>
<script>(function(){var el=document.getElementById('web2apk-splash');if(!el)return;setTimeout(function(){el.style.opacity='0';setTimeout(function(){if(el.parentNode)el.parentNode.removeChild(el);},260);},${Math.max(300, Math.min(8000, s.durationMs))});})();</script>`;

  if (/<body[^>]*>/i.test(html)) {
    return html.replace(/<body([^>]*)>/i, `<body$1>\n${splashOverlay}`);
  }
  return `${splashOverlay}\n${html}`;
}
