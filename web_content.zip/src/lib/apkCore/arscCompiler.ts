import { concatBytes, padTo4Bytes, writeUtf16Le } from './bytes.ts';

const RES_STRING_POOL_TYPE = 0x0001;
const RES_TABLE_TYPE = 0x0002;
const RES_TABLE_PACKAGE_TYPE = 0x0200;
const RES_TABLE_TYPE_TYPE = 0x0201;
const RES_TABLE_TYPE_SPEC_TYPE = 0x0202;

const TYPE_STRING = 0x03;

function encodeUtf16PoolString(str: string): Uint8Array {
  const charLen = str.length;
  const buf = new Uint8Array(2 + charLen * 2 + 2);
  const view = new DataView(buf.buffer);
  view.setUint16(0, charLen, true);
  writeUtf16Le(buf, 2, str);
  view.setUint16(2 + charLen * 2, 0, true);
  return buf;
}

function buildStringPool(strings: string[]): Uint8Array {
  const stringBuffers = strings.map(encodeUtf16PoolString);
  const offsets: number[] = [];
  let cursor = 0;
  for (const b of stringBuffers) {
    offsets.push(cursor);
    cursor += b.length;
  }
  const rawData = padTo4Bytes(concatBytes(stringBuffers));
  const headerSize = 28;
  const stringsStart = headerSize + strings.length * 4;
  const totalSize = stringsStart + rawData.length;

  const header = new Uint8Array(headerSize);
  const hv = new DataView(header.buffer);
  hv.setUint16(0, RES_STRING_POOL_TYPE, true);
  hv.setUint16(2, headerSize, true);
  hv.setUint32(4, totalSize, true);
  hv.setUint32(8, strings.length, true);
  hv.setUint32(12, 0, true);
  hv.setUint32(16, 0, true);
  hv.setUint32(20, stringsStart, true);
  hv.setUint32(24, 0, true);

  const offsetsBuf = new Uint8Array(strings.length * 4);
  const ov = new DataView(offsetsBuf.buffer);
  offsets.forEach((off, i) => ov.setUint32(i * 4, off, true));

  return concatBytes([header, offsetsBuf, rawData]);
}

function buildSingleEntryTypeChunks(
  typeId: number,
  keyIndex: number,
  globalStringIndex: number
): Uint8Array {
  const specChunk = new Uint8Array(20);
  const sv = new DataView(specChunk.buffer);
  sv.setUint16(0, RES_TABLE_TYPE_SPEC_TYPE, true);
  sv.setUint16(2, 16, true);
  sv.setUint32(4, 20, true);
  sv.setUint8(8, typeId);
  sv.setUint8(9, 0);
  sv.setUint16(10, 0, true);
  sv.setUint32(12, 1, true);
  sv.setUint32(16, 0, true);

  const headerSize = 84;
  const entryOffsetsSize = 4;
  const entrySize = 16;
  const entriesStart = headerSize + entryOffsetsSize;
  const totalSize = entriesStart + entrySize;

  const typeChunk = new Uint8Array(totalSize);
  const tv = new DataView(typeChunk.buffer);
  tv.setUint16(0, RES_TABLE_TYPE_TYPE, true);
  tv.setUint16(2, headerSize, true);
  tv.setUint32(4, totalSize, true);
  tv.setUint8(8, typeId);
  tv.setUint8(9, 0);
  tv.setUint16(10, 0, true);
  tv.setUint32(12, 1, true);
  tv.setUint32(16, entriesStart, true);
  tv.setUint32(20, 64, true);
  tv.setUint32(headerSize, 0, true);

  tv.setUint16(entriesStart, 8, true);
  tv.setUint16(entriesStart + 2, 0, true);
  tv.setUint32(entriesStart + 4, keyIndex, true);

  tv.setUint16(entriesStart + 8, 8, true);
  tv.setUint8(entriesStart + 10, 0);
  tv.setUint8(entriesStart + 11, TYPE_STRING);
  tv.setUint32(entriesStart + 12, globalStringIndex, true);

  return concatBytes([specChunk, typeChunk]);
}

export function compileResourcesArsc(packageId: string, appName: string): Uint8Array {
  const globalStrings = buildStringPool([appName, 'res/mipmap/ic_launcher.png']);
  const typeStrings = buildStringPool(['string', 'mipmap']);
  const keyStrings = buildStringPool(['app_name', 'ic_launcher']);

  const type1Chunks = buildSingleEntryTypeChunks(1, 0, 0);
  const type2Chunks = buildSingleEntryTypeChunks(2, 1, 1);

  const packageHeaderSize = 288;
  const typeStringsOffset = packageHeaderSize;
  const keyStringsOffset = typeStringsOffset + typeStrings.length;
  const packageBody = concatBytes([typeStrings, keyStrings, type1Chunks, type2Chunks]);
  const packageTotalSize = packageHeaderSize + packageBody.length;

  const pkgHeader = new Uint8Array(packageHeaderSize);
  const pv = new DataView(pkgHeader.buffer);
  pv.setUint16(0, RES_TABLE_PACKAGE_TYPE, true);
  pv.setUint16(2, packageHeaderSize, true);
  pv.setUint32(4, packageTotalSize, true);
  pv.setUint32(8, 0x7f, true);

  writeUtf16Le(pkgHeader, 12, packageId.slice(0, 127));

  pv.setUint32(268, typeStringsOffset, true);
  pv.setUint32(272, 2, true);
  pv.setUint32(276, keyStringsOffset, true);
  pv.setUint32(280, 2, true);
  pv.setUint32(284, 0, true);

  const pkgChunk = concatBytes([pkgHeader, packageBody]);

  const tableHeaderSize = 12;
  const tableTotalSize = tableHeaderSize + globalStrings.length + pkgChunk.length;
  const tableHeader = new Uint8Array(tableHeaderSize);
  const thv = new DataView(tableHeader.buffer);
  thv.setUint16(0, RES_TABLE_TYPE, true);
  thv.setUint16(2, tableHeaderSize, true);
  thv.setUint32(4, tableTotalSize, true);
  thv.setUint32(8, 1, true);

  return concatBytes([tableHeader, globalStrings, pkgChunk]);
}
