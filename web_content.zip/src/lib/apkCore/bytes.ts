const utf8Encoder = new TextEncoder();

export function concatBytes(chunks: Uint8Array[]): Uint8Array {
  let total = 0;
  for (const c of chunks) total += c.length;
  const out = new Uint8Array(total);
  let offset = 0;
  for (const c of chunks) {
    out.set(c, offset);
    offset += c.length;
  }
  return out;
}

export function utf8ToBytes(str: string): Uint8Array {
  return utf8Encoder.encode(str);
}

export function writeAscii(buf: Uint8Array, offset: number, str: string): void {
  for (let i = 0; i < str.length; i++) {
    buf[offset + i] = str.charCodeAt(i) & 0xff;
  }
}

export function writeUtf16Le(buf: Uint8Array, offset: number, str: string): void {
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  for (let i = 0; i < str.length; i++) {
    view.setUint16(offset + i * 2, str.charCodeAt(i), true);
  }
}

export function bytesToBinaryString(bytes: Uint8Array): string {
  let out = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    const slice = bytes.subarray(i, Math.min(i + chunk, bytes.length));
    out += String.fromCharCode(...slice);
  }
  return out;
}

export function binaryStringToBytes(bin: string): Uint8Array {
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) {
    out[i] = bin.charCodeAt(i) & 0xff;
  }
  return out;
}

export function base64ToBytes(base64: string): Uint8Array {
  const cleaned = base64.replace(/^data:[^;]+;base64,/, '').trim();
  const bin = atob(cleaned);
  return binaryStringToBytes(bin);
}

export function padTo4Bytes(bytes: Uint8Array): Uint8Array {
  const rem = bytes.length % 4;
  if (rem === 0) return bytes;
  return concatBytes([bytes, new Uint8Array(4 - rem)]);
}
