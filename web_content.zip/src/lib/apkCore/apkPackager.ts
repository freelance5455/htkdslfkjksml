import JSZip from 'jszip';
import forge from 'node-forge';
import type { ApkBuildConfig, BuildArtifactSummary } from '../../types/apk.ts';
import {
  base64ToBytes,
  binaryStringToBytes,
  bytesToBinaryString,
  utf8ToBytes,
} from './bytes.ts';
import { buildManifestXmlText, compileBinaryManifest } from './axmlCompiler.ts';
import { compileResourcesArsc } from './arscCompiler.ts';
import { compileClassesDex } from './dexCompiler.ts';
import { buildDeveloperAboutHtml, injectSplashIntoHtml } from './htmlGenerators.ts';

interface KeystoreIdentity {
  privateKeyPem: string;
  certificatePem: string;
  fingerprintSha256: string;
}

const keystoreCache = new Map<string, KeystoreIdentity>();

function sha256Hex(bytes: Uint8Array): string {
  const md = forge.md.sha256.create();
  md.update(bytesToBinaryString(bytes));
  return md.digest().toHex();
}

function sha256Base64(bytes: Uint8Array): string {
  const md = forge.md.sha256.create();
  md.update(bytesToBinaryString(bytes));
  return forge.util.encode64(md.digest().getBytes());
}

function getOrCreateSigningIdentity(orgName: string, alias: string): KeystoreIdentity {
  const cacheKey = `${orgName}::${alias}`;
  const existing = keystoreCache.get(cacheKey);
  if (existing) return existing;

  const keys = forge.pki.rsa.generateKeyPair(2048);
  const cert = forge.pki.createCertificate();
  cert.publicKey = keys.publicKey;
  cert.serialNumber = forge.util.bytesToHex(forge.random.getBytesSync(8));
  cert.validity.notBefore = new Date(Date.now() - 86400000);
  cert.validity.notAfter = new Date();
  cert.validity.notAfter.setFullYear(cert.validity.notBefore.getFullYear() + 25);

  const attrs = [
    { name: 'commonName', value: alias || 'Web2APK Release' },
    { name: 'organizationName', value: orgName || 'Web2APK Studio' },
    { name: 'countryName', value: 'US' },
  ];
  cert.setSubject(attrs);
  cert.setIssuer(attrs);
  cert.setExtensions([
    { name: 'basicConstraints', cA: true },
    { name: 'keyUsage', keyCertSign: true, digitalSignature: true },
  ]);
  cert.sign(keys.privateKey, forge.md.sha256.create());

  const certAsn1 = forge.pki.certificateToAsn1(cert);
  const certDerBytes = binaryStringToBytes(forge.asn1.toDer(certAsn1).getBytes());
  const fingerprintSha256 = sha256Hex(certDerBytes)
    .match(/.{2}/g)!
    .join(':')
    .toUpperCase();

  const identity: KeystoreIdentity = {
    privateKeyPem: forge.pki.privateKeyToPem(keys.privateKey),
    certificatePem: forge.pki.certificateToPem(cert),
    fingerprintSha256,
  };
  keystoreCache.set(cacheKey, identity);
  return identity;
}

function signApkV1(
  entries: { path: string; data: Uint8Array }[],
  identity: KeystoreIdentity
): { manifestMf: Uint8Array; certSf: Uint8Array; certRsa: Uint8Array } {
  const manifestLines: string[] = [
    'Manifest-Version: 1.0',
    'Built-By: Web2APK Studio',
    'Created-By: Web2APK Binary Packager 1.0',
    '',
  ];

  const sfEntryBlocks: string[] = [];

  for (const entry of entries) {
    const entryDigest = sha256Base64(entry.data);
    const section = `Name: ${entry.path}\r\nSHA-256-Digest: ${entryDigest}\r\n\r\n`;
    manifestLines.push(
      `Name: ${entry.path}`,
      `SHA-256-Digest: ${entryDigest}`,
      ''
    );
    const sectionDigest = sha256Base64(utf8ToBytes(section));
    sfEntryBlocks.push(`Name: ${entry.path}\r\nSHA-256-Digest: ${sectionDigest}\r\n\r\n`);
  }

  const manifestText = manifestLines.join('\r\n');
  const manifestMf = utf8ToBytes(manifestText);
  const manifestDigest = sha256Base64(manifestMf);

  const mainAttrEnd = manifestText.indexOf('\r\n\r\n') + 4;
  const mainAttrDigest = sha256Base64(utf8ToBytes(manifestText.slice(0, mainAttrEnd)));

  const sfText =
    `Signature-Version: 1.0\r\n` +
    `Created-By: Web2APK Binary Packager 1.0\r\n` +
    `SHA-256-Digest-Manifest: ${manifestDigest}\r\n` +
    `SHA-256-Digest-Manifest-Main-Attributes: ${mainAttrDigest}\r\n` +
    `\r\n` +
    sfEntryBlocks.join('');
  const certSf = utf8ToBytes(sfText);

  const p7 = forge.pkcs7.createSignedData();
  p7.content = forge.util.createBuffer(bytesToBinaryString(certSf));
  const cert = forge.pki.certificateFromPem(identity.certificatePem);
  const privKey = forge.pki.privateKeyFromPem(identity.privateKeyPem);
  p7.addCertificate(cert);
  p7.addSigner({
    key: privKey,
    certificate: cert,
    digestAlgorithm: forge.pki.oids.sha256,
    authenticatedAttributes: [
      { type: forge.pki.oids.contentType, value: forge.pki.oids.data },
      { type: forge.pki.oids.messageDigest },
    ],
  });
  p7.sign({ detached: true });

  const certRsa = binaryStringToBytes(forge.asn1.toDer(p7.toAsn1()).getBytes());

  return { manifestMf, certSf, certRsa };
}

export interface BuiltApkBytesResult {
  apkBytes: Uint8Array;
  summary: Omit<BuildArtifactSummary, 'gradleSizeBytes'>;
}

export async function buildSignedApkBinary(
  config: ApkBuildConfig,
  buildId: string,
  fallbackIconFactory?: (themeColor: string) => Uint8Array
): Promise<BuiltApkBytesResult> {
  const manifestBin = compileBinaryManifest(config);
  const manifestXmlPreview = buildManifestXmlText(config);
  const resourcesArsc = compileResourcesArsc(config.packageId, config.appName);
  const classesDex = compileClassesDex(config);

  let iconPng: Uint8Array;
  if (config.iconBase64Png && config.iconBase64Png.trim().length > 0) {
    iconPng = base64ToBytes(config.iconBase64Png);
  } else if (fallbackIconFactory) {
    iconPng = fallbackIconFactory(config.themeColor);
  } else {
    throw new Error('Launcher icon PNG data is required.');
  }

  const unsignedEntries: { path: string; data: Uint8Array; store?: boolean }[] = [
    { path: 'AndroidManifest.xml', data: manifestBin },
    { path: 'classes.dex', data: classesDex },
    { path: 'resources.arsc', data: resourcesArsc, store: true },
    { path: 'res/mipmap/ic_launcher.png', data: iconPng, store: true },
  ];

  if (config.sourceMode === 'code') {
    const raw = config.rawHtmlCode?.trim() || '<!DOCTYPE html><html><body></body></html>';
    const finalHtml = injectSplashIntoHtml(raw, config);
    unsignedEntries.push({
      path: 'assets/index.html',
      data: utf8ToBytes(finalHtml),
    });
  } else if (config.sourceMode === 'html') {
    if (config.htmlFiles.length === 0) {
      throw new Error('At least one HTML file is required when building in HTML Bundle mode.');
    }
    const entryName = config.htmlEntryFile || 'index.html';
    for (const file of config.htmlFiles) {
      const safePath = file.path.replace(/^\/+/, '').replace(/\.\.\//g, '');
      let data = base64ToBytes(file.contentBase64);
      if (safePath === entryName && config.splash.enabled) {
        const text = new TextDecoder().decode(data);
        data = utf8ToBytes(injectSplashIntoHtml(text, config));
      }
      unsignedEntries.push({
        path: `assets/${safePath}`,
        data,
      });
    }
  }

  if (config.developer.includeAboutPageInAssets) {
    unsignedEntries.push({
      path: 'assets/developer.html',
      data: utf8ToBytes(buildDeveloperAboutHtml(config)),
    });
  }

  const identity = getOrCreateSigningIdentity(config.signingOrg, config.signingAlias);
  const { manifestMf, certSf, certRsa } = signApkV1(unsignedEntries, identity);

  const zip = new JSZip();
  for (const entry of unsignedEntries) {
    zip.file(entry.path, entry.data, {
      compression: entry.store ? 'STORE' : 'DEFLATE',
      compressionOptions: entry.store ? undefined : { level: 9 },
    });
  }
  zip.file('META-INF/MANIFEST.MF', manifestMf, { compression: 'DEFLATE' });
  zip.file('META-INF/CERT.SF', certSf, { compression: 'DEFLATE' });
  zip.file('META-INF/CERT.RSA', certRsa, { compression: 'DEFLATE' });

  const apkBytes = await zip.generateAsync({
    type: 'uint8array',
    platform: 'UNIX',
  });

  const sha256 = sha256Hex(apkBytes);

  const allEntries = [
    ...unsignedEntries.map((e) => ({
      path: e.path,
      sizeBytes: e.data.length,
      compression: e.store ? 'STORE' : 'DEFLATE',
    })),
    { path: 'META-INF/MANIFEST.MF', sizeBytes: manifestMf.length, compression: 'DEFLATE' },
    { path: 'META-INF/CERT.SF', sizeBytes: certSf.length, compression: 'DEFLATE' },
    { path: 'META-INF/CERT.RSA', sizeBytes: certRsa.length, compression: 'DEFLATE' },
  ];

  return {
    apkBytes,
    summary: {
      id: buildId,
      createdAt: new Date().toISOString(),
      appName: config.appName,
      packageId: config.packageId,
      versionName: config.versionName,
      versionCode: config.versionCode,
      sourceMode: config.sourceMode,
      sourceTarget:
        config.sourceMode === 'url'
          ? config.websiteUrl
          : config.sourceMode === 'code'
            ? 'Direct HTML Code (index.html)'
            : config.htmlEntryFile || 'index.html',
      apkSizeBytes: apkBytes.length,
      sha256,
      signingFingerprint: identity.fingerprintSha256,
      manifestXmlPreview,
      entries: allEntries,
    },
  };
}
