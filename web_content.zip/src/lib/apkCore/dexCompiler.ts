import forge from 'node-forge';
import type { ApkBuildConfig } from '../../types/apk.ts';
import {
  binaryStringToBytes,
  bytesToBinaryString,
  concatBytes,
  utf8ToBytes,
  writeAscii,
} from './bytes.ts';

function writeUleb128(value: number): Uint8Array {
  const bytes: number[] = [];
  let v = value >>> 0;
  do {
    let b = v & 0x7f;
    v >>>= 7;
    if (v !== 0) b |= 0x80;
    bytes.push(b);
  } while (v !== 0);
  return new Uint8Array(bytes);
}

function encodeMutf8StringData(str: string): Uint8Array {
  const lenPrefix = writeUleb128(str.length);
  const utf8 = utf8ToBytes(str);
  return concatBytes([lenPrefix, utf8, new Uint8Array([0])]);
}

function adler32(data: Uint8Array): number {
  const MOD = 65521;
  let a = 1;
  let b = 0;
  for (let i = 0; i < data.length; i++) {
    a = (a + data[i]) % MOD;
    b = (b + a) % MOD;
  }
  return ((b << 16) | a) >>> 0;
}

function compareUtf16(a: string, b: string): number {
  const len = Math.min(a.length, b.length);
  for (let i = 0; i < len; i++) {
    const ca = a.charCodeAt(i);
    const cb = b.charCodeAt(i);
    if (ca !== cb) return ca - cb;
  }
  return a.length - b.length;
}

interface ProtoDef {
  shorty: string;
  retType: string;
  params: string[];
}

interface MethodDef {
  classType: string;
  name: string;
  protoKey: string;
}

function makeProtoKey(retType: string, params: string[]): string {
  return `${retType}|${params.join(',')}`;
}

function shortyChar(desc: string): string {
  if (desc === 'V' || desc === 'Z' || desc === 'I') return desc;
  return 'L';
}

export function compileClassesDex(config: ApkBuildConfig): Uint8Array {
  const activityClassDesc = `L${config.packageId.replace(/\./g, '/')}/WebAppActivity;`;
  const targetUrl =
    config.sourceMode === 'url'
      ? config.websiteUrl
      : config.sourceMode === 'code'
        ? 'file:///android_asset/index.html'
        : `file:///android_asset/${config.htmlEntryFile || 'index.html'}`;
  const customUa = config.customUserAgent.trim();

  const protos: ProtoDef[] = [
    { shorty: 'V', retType: 'V', params: [] },
    { shorty: 'VL', retType: 'V', params: ['Landroid/os/Bundle;'] },
    { shorty: 'VL', retType: 'V', params: ['Landroid/content/Context;'] },
    { shorty: 'L', retType: 'Landroid/webkit/WebSettings;', params: [] },
    { shorty: 'VZ', retType: 'V', params: ['Z'] },
    { shorty: 'VL', retType: 'V', params: ['Landroid/webkit/WebViewClient;'] },
    { shorty: 'VL', retType: 'V', params: ['Ljava/lang/String;'] },
    { shorty: 'VL', retType: 'V', params: ['Landroid/view/View;'] },
  ];

  const methods: MethodDef[] = [
    { classType: 'Landroid/app/Activity;', name: '<init>', protoKey: makeProtoKey('V', []) },
    {
      classType: 'Landroid/app/Activity;',
      name: 'onCreate',
      protoKey: makeProtoKey('V', ['Landroid/os/Bundle;']),
    },
    {
      classType: 'Landroid/app/Activity;',
      name: 'setContentView',
      protoKey: makeProtoKey('V', ['Landroid/view/View;']),
    },
    {
      classType: 'Landroid/webkit/WebView;',
      name: '<init>',
      protoKey: makeProtoKey('V', ['Landroid/content/Context;']),
    },
    {
      classType: 'Landroid/webkit/WebView;',
      name: 'getSettings',
      protoKey: makeProtoKey('Landroid/webkit/WebSettings;', []),
    },
    {
      classType: 'Landroid/webkit/WebView;',
      name: 'setWebViewClient',
      protoKey: makeProtoKey('V', ['Landroid/webkit/WebViewClient;']),
    },
    {
      classType: 'Landroid/webkit/WebView;',
      name: 'loadUrl',
      protoKey: makeProtoKey('V', ['Ljava/lang/String;']),
    },
    {
      classType: 'Landroid/webkit/WebSettings;',
      name: 'setJavaScriptEnabled',
      protoKey: makeProtoKey('V', ['Z']),
    },
    {
      classType: 'Landroid/webkit/WebSettings;',
      name: 'setDomStorageEnabled',
      protoKey: makeProtoKey('V', ['Z']),
    },
    {
      classType: 'Landroid/webkit/WebSettings;',
      name: 'setBuiltInZoomControls',
      protoKey: makeProtoKey('V', ['Z']),
    },
    {
      classType: 'Landroid/webkit/WebSettings;',
      name: 'setDisplayZoomControls',
      protoKey: makeProtoKey('V', ['Z']),
    },
    ...(customUa
      ? [
          {
            classType: 'Landroid/webkit/WebSettings;',
            name: 'setUserAgentString',
            protoKey: makeProtoKey('V', ['Ljava/lang/String;']),
          },
        ]
      : []),
    {
      classType: 'Landroid/webkit/WebViewClient;',
      name: '<init>',
      protoKey: makeProtoKey('V', []),
    },
    { classType: activityClassDesc, name: '<init>', protoKey: makeProtoKey('V', []) },
    {
      classType: activityClassDesc,
      name: 'onCreate',
      protoKey: makeProtoKey('V', ['Landroid/os/Bundle;']),
    },
  ];

  const strSet = new Set<string>([
    targetUrl,
    'WebAppActivity.java',
    activityClassDesc,
    'Landroid/app/Activity;',
    'Landroid/os/Bundle;',
    'Landroid/content/Context;',
    'Landroid/view/View;',
    'Landroid/webkit/WebView;',
    'Landroid/webkit/WebSettings;',
    'Landroid/webkit/WebViewClient;',
    'Ljava/lang/String;',
    'V',
    'Z',
  ]);
  if (customUa) strSet.add(customUa);
  for (const p of protos) {
    strSet.add(shortyChar(p.retType) + p.params.map(shortyChar).join(''));
    strSet.add(p.retType);
    p.params.forEach((pt) => strSet.add(pt));
  }
  for (const m of methods) {
    strSet.add(m.classType);
    strSet.add(m.name);
  }

  const sortedStrings = Array.from(strSet).sort(compareUtf16);
  const strIdx = (s: string): number => sortedStrings.indexOf(s);

  const typeSet = new Set<string>([
    activityClassDesc,
    'Landroid/app/Activity;',
    'Landroid/os/Bundle;',
    'Landroid/content/Context;',
    'Landroid/view/View;',
    'Landroid/webkit/WebView;',
    'Landroid/webkit/WebSettings;',
    'Landroid/webkit/WebViewClient;',
    'Ljava/lang/String;',
    'V',
    'Z',
  ]);
  const sortedTypes = Array.from(typeSet).sort((a, b) => strIdx(a) - strIdx(b));
  const typeIdx = (t: string): number => sortedTypes.indexOf(t);

  const protoMap = new Map<string, ProtoDef>();
  for (const p of protos) {
    protoMap.set(makeProtoKey(p.retType, p.params), p);
  }
  const sortedProtos = Array.from(protoMap.entries())
    .sort((a, b) => {
      const ra = typeIdx(a[1].retType);
      const rb = typeIdx(b[1].retType);
      if (ra !== rb) return ra - rb;
      const minLen = Math.min(a[1].params.length, b[1].params.length);
      for (let i = 0; i < minLen; i++) {
        const pa = typeIdx(a[1].params[i]);
        const pb = typeIdx(b[1].params[i]);
        if (pa !== pb) return pa - pb;
      }
      return a[1].params.length - b[1].params.length;
    })
    .map(([key, def]) => ({ key, def }));
  const protoIdx = (key: string): number => sortedProtos.findIndex((p) => p.key === key);

  const sortedMethods = [...methods].sort((a, b) => {
    const ca = typeIdx(a.classType);
    const cb = typeIdx(b.classType);
    if (ca !== cb) return ca - cb;
    const na = strIdx(a.name);
    const nb = strIdx(b.name);
    if (na !== nb) return na - nb;
    return protoIdx(a.protoKey) - protoIdx(b.protoKey);
  });
  const methodIdx = (classType: string, name: string, protoKey: string): number =>
    sortedMethods.findIndex(
      (m) => m.classType === classType && m.name === name && m.protoKey === protoKey
    );

  const initInsns: number[] = [
    0x1070,
    methodIdx('Landroid/app/Activity;', '<init>', makeProtoKey('V', [])),
    0x0000,
    0x000e,
  ];

  const jsVal = config.enableJavaScript ? 1 : 0;
  const domVal = config.enableDomStorage ? 1 : 0;
  const zoomVal = config.enableZoomControls ? 1 : 0;

  const onCreateInsns: number[] = [
    0x206f,
    methodIdx('Landroid/app/Activity;', 'onCreate', makeProtoKey('V', ['Landroid/os/Bundle;'])),
    0x0054,
    0x0022,
    typeIdx('Landroid/webkit/WebView;'),
    0x2070,
    methodIdx('Landroid/webkit/WebView;', '<init>', makeProtoKey('V', ['Landroid/content/Context;'])),
    0x0040,
    0x106e,
    methodIdx('Landroid/webkit/WebView;', 'getSettings', makeProtoKey('Landroid/webkit/WebSettings;', [])),
    0x0000,
    0x010c,
    ((jsVal & 0xf) << 12) | 0x0212,
    0x206e,
    methodIdx('Landroid/webkit/WebSettings;', 'setJavaScriptEnabled', makeProtoKey('V', ['Z'])),
    0x0021,
    ((domVal & 0xf) << 12) | 0x0212,
    0x206e,
    methodIdx('Landroid/webkit/WebSettings;', 'setDomStorageEnabled', makeProtoKey('V', ['Z'])),
    0x0021,
    ((zoomVal & 0xf) << 12) | 0x0212,
    0x206e,
    methodIdx('Landroid/webkit/WebSettings;', 'setBuiltInZoomControls', makeProtoKey('V', ['Z'])),
    0x0021,
    0x0212,
    0x206e,
    methodIdx('Landroid/webkit/WebSettings;', 'setDisplayZoomControls', makeProtoKey('V', ['Z'])),
    0x0021,
  ];

  if (customUa) {
    const uaIdx = strIdx(customUa);
    onCreateInsns.push(
      0x031a,
      uaIdx,
      0x206e,
      methodIdx(
        'Landroid/webkit/WebSettings;',
        'setUserAgentString',
        makeProtoKey('V', ['Ljava/lang/String;'])
      ),
      0x0031
    );
  }

  onCreateInsns.push(
    0x0322,
    typeIdx('Landroid/webkit/WebViewClient;'),
    0x1070,
    methodIdx('Landroid/webkit/WebViewClient;', '<init>', makeProtoKey('V', [])),
    0x0003,
    0x206e,
    methodIdx(
      'Landroid/webkit/WebView;',
      'setWebViewClient',
      makeProtoKey('V', ['Landroid/webkit/WebViewClient;'])
    ),
    0x0030,
    0x031a,
    strIdx(targetUrl),
    0x206e,
    methodIdx('Landroid/webkit/WebView;', 'loadUrl', makeProtoKey('V', ['Ljava/lang/String;'])),
    0x0030,
    0x206e,
    methodIdx('Landroid/app/Activity;', 'setContentView', makeProtoKey('V', ['Landroid/view/View;'])),
    0x0004,
    0x000e
  );

  const headerSize = 0x70;
  const stringIdsOff = headerSize;
  const stringIdsSize = sortedStrings.length;
  const typeIdsOff = stringIdsOff + stringIdsSize * 4;
  const typeIdsSize = sortedTypes.length;
  const protoIdsOff = typeIdsOff + typeIdsSize * 4;
  const protoIdsSize = sortedProtos.length;
  const methodIdsOff = protoIdsOff + protoIdsSize * 12;
  const methodIdsSize = sortedMethods.length;
  const classDefsOff = methodIdsOff + methodIdsSize * 8;
  const classDefsSize = 1;
  const dataOff = classDefsOff + classDefsSize * 32;

  const dataChunks: Uint8Array[] = [];
  let cursor = dataOff;

  const alignData = (alignment: number) => {
    const rem = cursor % alignment;
    if (rem !== 0) {
      const pad = alignment - rem;
      dataChunks.push(new Uint8Array(pad));
      cursor += pad;
    }
  };

  const protoParamOffs = new Map<string, number>();
  for (const p of sortedProtos) {
    if (p.def.params.length === 0) {
      protoParamOffs.set(p.key, 0);
      continue;
    }
    alignData(4);
    protoParamOffs.set(p.key, cursor);
    const tl = new Uint8Array(4 + p.def.params.length * 2);
    const tlv = new DataView(tl.buffer);
    tlv.setUint32(0, p.def.params.length, true);
    p.def.params.forEach((pt, idx) => tlv.setUint16(4 + idx * 2, typeIdx(pt), true));
    dataChunks.push(tl);
    cursor += tl.length;
  }

  const makeCodeItem = (
    regs: number,
    ins: number,
    outs: number,
    insns: number[]
  ): Uint8Array => {
    const item = new Uint8Array(16 + insns.length * 2);
    const iv = new DataView(item.buffer);
    iv.setUint16(0, regs, true);
    iv.setUint16(2, ins, true);
    iv.setUint16(4, outs, true);
    iv.setUint16(6, 0, true);
    iv.setUint32(8, 0, true);
    iv.setUint32(12, insns.length, true);
    insns.forEach((word, i) => iv.setUint16(16 + i * 2, word & 0xffff, true));
    return item;
  };

  alignData(4);
  const initCodeOff = cursor;
  const initCodeItem = makeCodeItem(1, 1, 1, initInsns);
  dataChunks.push(initCodeItem);
  cursor += initCodeItem.length;

  alignData(4);
  const onCreateCodeOff = cursor;
  const onCreateCodeItem = makeCodeItem(6, 2, 2, onCreateInsns);
  dataChunks.push(onCreateCodeItem);
  cursor += onCreateCodeItem.length;

  const stringDataOffs: number[] = [];
  for (const s of sortedStrings) {
    stringDataOffs.push(cursor);
    const sd = encodeMutf8StringData(s);
    dataChunks.push(sd);
    cursor += sd.length;
  }

  const classDataOff = cursor;
  const directInitIdx = methodIdx(activityClassDesc, '<init>', makeProtoKey('V', []));
  const virtualOnCreateIdx = methodIdx(
    activityClassDesc,
    'onCreate',
    makeProtoKey('V', ['Landroid/os/Bundle;'])
  );

  const classDataBuf = concatBytes([
    writeUleb128(0),
    writeUleb128(0),
    writeUleb128(1),
    writeUleb128(1),
    writeUleb128(directInitIdx),
    writeUleb128(0x10001),
    writeUleb128(initCodeOff),
    writeUleb128(virtualOnCreateIdx),
    writeUleb128(0x0004),
    writeUleb128(onCreateCodeOff),
  ]);
  dataChunks.push(classDataBuf);
  cursor += classDataBuf.length;

  alignData(4);
  const mapOff = cursor;
  const mapItems: { type: number; size: number; offset: number }[] = [
    { type: 0x0000, size: 1, offset: 0 },
    { type: 0x0001, size: stringIdsSize, offset: stringIdsOff },
    { type: 0x0002, size: typeIdsSize, offset: typeIdsOff },
    { type: 0x0003, size: protoIdsSize, offset: protoIdsOff },
    { type: 0x0005, size: methodIdsSize, offset: methodIdsOff },
    { type: 0x0006, size: classDefsSize, offset: classDefsOff },
    {
      type: 0x1001,
      size: sortedProtos.filter((p) => p.def.params.length > 0).length,
      offset: protoParamOffs.get(
        sortedProtos.find((p) => p.def.params.length > 0)!.key
      )!,
    },
    { type: 0x2000, size: 1, offset: classDataOff },
    { type: 0x2001, size: 2, offset: initCodeOff },
    { type: 0x2002, size: stringIdsSize, offset: stringDataOffs[0] },
    { type: 0x1000, size: 1, offset: mapOff },
  ];

  const mapListBuf = new Uint8Array(4 + mapItems.length * 12);
  const mlv = new DataView(mapListBuf.buffer);
  mlv.setUint32(0, mapItems.length, true);
  mapItems.forEach((mi, idx) => {
    const off = 4 + idx * 12;
    mlv.setUint16(off, mi.type, true);
    mlv.setUint16(off + 2, 0, true);
    mlv.setUint32(off + 4, mi.size, true);
    mlv.setUint32(off + 8, mi.offset, true);
  });
  dataChunks.push(mapListBuf);
  cursor += mapListBuf.length;

  const fileSize = cursor;
  const dataSize = fileSize - dataOff;
  const dex = new Uint8Array(fileSize);
  const dv = new DataView(dex.buffer);

  writeAscii(dex, 0, 'dex\n035\0');
  dv.setUint32(32, fileSize, true);
  dv.setUint32(36, headerSize, true);
  dv.setUint32(40, 0x12345678, true);
  dv.setUint32(44, 0, true);
  dv.setUint32(48, 0, true);
  dv.setUint32(52, mapOff, true);
  dv.setUint32(56, stringIdsSize, true);
  dv.setUint32(60, stringIdsOff, true);
  dv.setUint32(64, typeIdsSize, true);
  dv.setUint32(68, typeIdsOff, true);
  dv.setUint32(72, protoIdsSize, true);
  dv.setUint32(76, protoIdsOff, true);
  dv.setUint32(80, 0, true);
  dv.setUint32(84, 0, true);
  dv.setUint32(88, methodIdsSize, true);
  dv.setUint32(92, methodIdsOff, true);
  dv.setUint32(96, classDefsSize, true);
  dv.setUint32(100, classDefsOff, true);
  dv.setUint32(104, dataSize, true);
  dv.setUint32(108, dataOff, true);

  stringDataOffs.forEach((off, i) => dv.setUint32(stringIdsOff + i * 4, off, true));
  sortedTypes.forEach((t, i) => dv.setUint32(typeIdsOff + i * 4, strIdx(t), true));

  sortedProtos.forEach((p, i) => {
    const off = protoIdsOff + i * 12;
    const shorty = shortyChar(p.def.retType) + p.def.params.map(shortyChar).join('');
    dv.setUint32(off, strIdx(shorty), true);
    dv.setUint32(off + 4, typeIdx(p.def.retType), true);
    dv.setUint32(off + 8, protoParamOffs.get(p.key) || 0, true);
  });

  sortedMethods.forEach((m, i) => {
    const off = methodIdsOff + i * 8;
    dv.setUint16(off, typeIdx(m.classType), true);
    dv.setUint16(off + 2, protoIdx(m.protoKey), true);
    dv.setUint32(off + 4, strIdx(m.name), true);
  });

  dv.setUint32(classDefsOff, typeIdx(activityClassDesc), true);
  dv.setUint32(classDefsOff + 4, 0x0001, true);
  dv.setUint32(classDefsOff + 8, typeIdx('Landroid/app/Activity;'), true);
  dv.setUint32(classDefsOff + 12, 0xffffffff, true);
  dv.setUint32(classDefsOff + 16, strIdx('WebAppActivity.java'), true);
  dv.setUint32(classDefsOff + 20, 0, true);
  dv.setUint32(classDefsOff + 24, classDataOff, true);
  dv.setUint32(classDefsOff + 28, 0, true);

  dex.set(concatBytes(dataChunks), dataOff);

  const mdSha1 = forge.md.sha1.create();
  mdSha1.update(bytesToBinaryString(dex.subarray(32)));
  const sha1Bytes = binaryStringToBytes(mdSha1.digest().getBytes());
  dex.set(sha1Bytes, 12);

  const sum = adler32(dex.subarray(12));
  dv.setUint32(8, sum, true);

  return dex;
}
