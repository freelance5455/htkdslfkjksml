import JSZip from 'jszip';
import type { ApkBuildConfig } from '../../types/apk.ts';
import { base64ToBytes, utf8ToBytes } from './bytes.ts';
import { buildManifestXmlText } from './axmlCompiler.ts';
import { buildDeveloperAboutHtml } from './htmlGenerators.ts';

function escapeKotlinString(input: string): string {
  return input.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\$/g, '\\$');
}

function escapeXml(input: string): string {
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export async function buildGradleProjectZip(
  config: ApkBuildConfig,
  fallbackIconFactory?: (themeColor: string) => Uint8Array
): Promise<Uint8Array> {
  const zip = new JSZip();
  const pkgPath = config.packageId.replace(/\./g, '/');
  const targetUrl =
    config.sourceMode === 'url'
      ? config.websiteUrl
      : config.sourceMode === 'code'
        ? 'file:///android_asset/index.html'
        : `file:///android_asset/${config.htmlEntryFile || 'index.html'}`;

  const projectSlug =
    config.appName
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '') || 'web2apk-app';

  zip.file(
    'settings.gradle.kts',
    `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "${escapeKotlinString(projectSlug)}"
include(":app")
`
  );

  zip.file(
    'build.gradle.kts',
    `plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.0" apply false
}
`
  );

  zip.file(
    'gradle.properties',
    `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
android.nonTransitiveRClass=true
`
  );

  const extraDeps: string[] = [];
  if (config.enablePlayBilling) {
    extraDeps.push('    implementation("com.android.billingclient:billing-ktx:7.0.0")');
  }
  if (config.enableAdMob) {
    extraDeps.push('    implementation("com.google.android.gms:play-services-ads:23.3.0")');
  }
  if (config.enableLaunchEvents && config.enableFirebaseAnalytics) {
    extraDeps.push('    implementation(platform("com.google.firebase:firebase-bom:33.2.0"))');
    extraDeps.push('    implementation("com.google.firebase:firebase-analytics-ktx")');
  }

  zip.file(
    'app/build.gradle.kts',
    `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "${config.packageId}"
    compileSdk = ${Math.max(config.targetSdkVersion, 34)}

    defaultConfig {
        applicationId = "${config.packageId}"
        minSdk = ${config.minSdkVersion}
        targetSdk = ${config.targetSdkVersion}
        versionCode = ${config.versionCode}
        versionName = "${escapeKotlinString(config.versionName)}"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
${extraDeps.join('\n')}
}
`
  );

  zip.file(
    'app/proguard-rules.pro',
    `-keepattributes *Annotation*
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
`
  );
  zip.file('app/src/main/AndroidManifest.xml', buildManifestXmlText(config));

  zip.file(
    'app/src/main/res/values/strings.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">${escapeXml(config.appName)}</string>
</resources>
`
  );

  zip.file(
    'app/src/main/res/values/colors.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="brand_primary">${config.themeColor}</color>
</resources>
`
  );

  const imports: string[] = [
    'import android.annotation.SuppressLint',
    'import android.content.Context',
    'import android.graphics.Color',
    'import android.os.Bundle',
    'import android.os.Handler',
    'import android.os.Looper',
    'import android.util.TypedValue',
    'import android.view.Gravity',
    'import android.view.View',
    'import android.webkit.JavascriptInterface',
    'import android.webkit.WebChromeClient',
    'import android.webkit.WebResourceRequest',
    'import android.webkit.WebSettings',
    'import android.webkit.WebView',
    'import android.webkit.WebViewClient',
    'import android.widget.FrameLayout',
    'import android.widget.ImageView',
    'import android.widget.LinearLayout',
    'import android.widget.ProgressBar',
    'import android.widget.TextView',
    'import androidx.activity.OnBackPressedCallback',
    'import androidx.appcompat.app.AppCompatActivity',
    'import androidx.swiperefreshlayout.widget.SwipeRefreshLayout',
  ];

  if (config.enablePlayBilling) {
    imports.push(
      'import com.android.billingclient.api.AcknowledgePurchaseParams',
      'import com.android.billingclient.api.BillingClient',
      'import com.android.billingclient.api.BillingClientStateListener',
      'import com.android.billingclient.api.BillingFlowParams',
      'import com.android.billingclient.api.BillingResult',
      'import com.android.billingclient.api.ConsumeParams',
      'import com.android.billingclient.api.Purchase',
      'import com.android.billingclient.api.PurchasesUpdatedListener',
      'import com.android.billingclient.api.QueryProductDetailsParams',
      'import com.android.billingclient.api.QueryPurchasesParams'
    );
  }

  if (config.enableAdMob) {
    imports.push(
      'import com.google.android.gms.ads.AdRequest',
      'import com.google.android.gms.ads.AdSize',
      'import com.google.android.gms.ads.AdView',
      'import com.google.android.gms.ads.LoadAdError',
      'import com.google.android.gms.ads.MobileAds',
      'import com.google.android.gms.ads.interstitial.InterstitialAd',
      'import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback',
      'import com.google.android.gms.ads.rewarded.RewardedAd',
      'import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback'
    );
  }

  if (config.enableLaunchEvents && config.launchWebhookUrl.trim()) {
    imports.push(
      'import java.io.OutputStreamWriter',
      'import java.net.HttpURLConnection',
      'import java.net.URL',
      'import kotlin.concurrent.thread'
    );
  }

  const customUaLine = config.customUserAgent.trim()
    ? `        webView.settings.userAgentString = "${escapeKotlinString(config.customUserAgent.trim())}"`
    : '';

  const consumableSkus = config.billingProducts
    .filter((p) => p.type === 'consumable')
    .map((p) => `"${escapeKotlinString(p.sku)}"`)
    .join(', ');

  const billingFields = config.enablePlayBilling
    ? `    private var billingClient: BillingClient? = null
    private val consumableSkus = setOf(${consumableSkus})`
    : '';

  const adMobFields = config.enableAdMob
    ? `    private var bannerAdView: AdView? = null
    private var interstitialAd: InterstitialAd? = null
    private var rewardedAd: RewardedAd? = null`
    : '';

  const removeAdsSkuLiteral = escapeKotlinString(
    config.removeAdsSku.trim() || 'remove_ads_lifetime'
  );

  const billingInitBlock = config.enablePlayBilling
    ? `
        val purchasesUpdatedListener = PurchasesUpdatedListener { billingResult, purchases ->
            val ok = billingResult.responseCode == BillingClient.BillingResponseCode.OK
            if (ok && purchases != null) {
                for (purchase in purchases) {
                    if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
                        val sku = purchase.products.firstOrNull() ?: ""
                        if (${config.enableRemoveAds} && sku == "${removeAdsSkuLiteral}") {
                            markAdsRemoved()
                        }
                        if (consumableSkus.contains(sku)) {
                            val consumeParams = ConsumeParams.newBuilder()
                                .setPurchaseToken(purchase.purchaseToken)
                                .build()
                            billingClient?.consumeAsync(consumeParams) { _, _ ->
                                webView.post {
                                    webView.evaluateJavascript(
                                        "window.dispatchEvent(new CustomEvent('android:currencyGranted',{detail:{sku:'$sku'}}));",
                                        null
                                    )
                                }
                            }
                        } else if (!purchase.isAcknowledged) {
                            val ackParams = AcknowledgePurchaseParams.newBuilder()
                                .setPurchaseToken(purchase.purchaseToken)
                                .build()
                            billingClient?.acknowledgePurchase(ackParams) {}
                        }
                    }
                }
            }
            val count = purchases?.size ?: 0
            webView.post {
                webView.evaluateJavascript(
                    "window.dispatchEvent(new CustomEvent('android:purchaseResult',{detail:{ok:$ok,count:$count}}));",
                    null
                )
            }
        }
        billingClient = BillingClient.newBuilder(this)
            .setListener(purchasesUpdatedListener)
            .enablePendingPurchases()
            .build()
        billingClient?.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK && ${config.enableRemoveAds}) {
                    billingClient?.queryPurchasesAsync(
                        QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build()
                    ) { _, list ->
                        if (list.any { it.products.contains("${removeAdsSkuLiteral}") && it.purchaseState == Purchase.PurchaseState.PURCHASED }) {
                            runOnUiThread { markAdsRemoved() }
                        }
                    }
                }
            }
            override fun onBillingServiceDisconnected() {}
        })`
    : '';

  const adMobInitBlock = config.enableAdMob
    ? `
        val adsRemoved = getSharedPreferences("web2apk_prefs", Context.MODE_PRIVATE).getBoolean("ads_removed", false)
        if (!adsRemoved) {
            MobileAds.initialize(this) {}
            loadInterstitialAd()
            loadRewardedAd()
        }`
    : '';

  const launchEventBlock = config.enableLaunchEvents
    ? `
        val prefs = getSharedPreferences("web2apk_events", Context.MODE_PRIVATE)
        val isFirstLaunch = !prefs.getBoolean("has_launched_before", false)
        if (isFirstLaunch) {
            prefs.edit().putBoolean("has_launched_before", true).apply()
        }${
          config.launchWebhookUrl.trim()
            ? `
        thread {
            try {
                val conn = URL("${escapeKotlinString(config.launchWebhookUrl.trim())}").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json")
                conn.doOutput = true
                val body = """{"event":"app_launch","packageId":"${config.packageId}","versionCode":${config.versionCode},"isFirstLaunch":$isFirstLaunch}"""
                OutputStreamWriter(conn.outputStream).use { it.write(body) }
                conn.responseCode
                conn.disconnect()
            } catch (_: Exception) {}
        }`
            : ''
        }`
    : '';

  const pageFinishedHook = config.enableLaunchEvents
    ? `
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    val launchPayload = """{"packageId":"${config.packageId}","versionName":"${escapeKotlinString(config.versionName)}","versionCode":${config.versionCode},"events":${JSON.stringify(config.customLaunchEvents)}}"""
                    view?.evaluateJavascript(
                        "window.dispatchEvent(new CustomEvent('android:launch',{detail:$launchPayload}));",
                        null
                    )
                }`
    : '';

  const mainContentSetup =
    config.enableAdMob && config.showBottomBanner && config.adMobBannerUnitId.trim()
      ? `
        val contentContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val webContainer = ${
          config.pullToRefresh
            ? `SwipeRefreshLayout(this).apply {
            addView(webView)
            setOnRefreshListener {
                webView.reload()
                isRefreshing = false
            }
        }`
            : 'webView'
        }
        contentContainer.addView(webContainer, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        val adsRemovedNow = getSharedPreferences("web2apk_prefs", Context.MODE_PRIVATE).getBoolean("ads_removed", false)
        if (!adsRemovedNow) {
            bannerAdView = AdView(this).apply {
                setAdSize(AdSize.BANNER)
                adUnitId = "${escapeKotlinString(config.adMobBannerUnitId.trim())}"
                loadAd(AdRequest.Builder().build())
            }
            contentContainer.addView(bannerAdView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.CENTER_HORIZONTAL
            })
        }`
      : config.pullToRefresh
        ? `val contentContainer = SwipeRefreshLayout(this).apply {
            addView(webView)
            setOnRefreshListener {
                webView.reload()
                isRefreshing = false
            }
        }`
        : `val contentContainer = webView`;

  const splashSection = config.splash.enabled
    ? `
        val rootFrame = FrameLayout(this)
        rootFrame.addView(contentContainer, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        val splashOverlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("${escapeKotlinString(config.splash.backgroundColor)}"))
            setPadding(48, 48, 48, 48)
        }
        val logoSizePx = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            ${config.splash.logoScale === 'lg' ? '96f' : config.splash.logoScale === 'sm' ? '56f' : '76f'},
            resources.displayMetrics
        ).toInt()
        val splashLogo = ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            layoutParams = LinearLayout.LayoutParams(logoSizePx, logoSizePx)
        }
        val splashTitle = TextView(this).apply {
            text = "${escapeKotlinString(config.splash.headline || config.appName)}"
            setTextColor(Color.parseColor("${escapeKotlinString(config.splash.textColor)}"))
            textSize = 20f
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 0)
        }
        splashOverlay.addView(splashLogo)
        splashOverlay.addView(splashTitle)
        ${
          config.splash.tagline.trim()
            ? `val splashTagline = TextView(this).apply {
            text = "${escapeKotlinString(config.splash.tagline.trim())}"
            setTextColor(Color.parseColor("${escapeKotlinString(config.splash.textColor)}"))
            alpha = 0.8f
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 0)
        }
        splashOverlay.addView(splashTagline)`
            : ''
        }
        ${
          config.splash.showSpinner
            ? `val spinner = ProgressBar(this).apply {
            setPadding(0, 32, 0, 0)
        }
        splashOverlay.addView(spinner)`
            : ''
        }
        rootFrame.addView(splashOverlay, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        setContentView(rootFrame)

        Handler(Looper.getMainLooper()).postDelayed({
            splashOverlay.animate().alpha(0f).setDuration(250L).withEndAction {
                rootFrame.removeView(splashOverlay)
            }.start()
        }, ${Math.max(300, Math.min(8000, config.splash.durationMs))}L)`
    : `
        setContentView(contentContainer)`;

  const adMobHelpers = config.enableAdMob
    ? `
    private fun markAdsRemoved() {
        getSharedPreferences("web2apk_prefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("ads_removed", true)
            .apply()
        bannerAdView?.visibility = View.GONE
        interstitialAd = null
        rewardedAd = null
    }

    private fun loadInterstitialAd() {
        if (getSharedPreferences("web2apk_prefs", Context.MODE_PRIVATE).getBoolean("ads_removed", false)) return
        val unitId = "${escapeKotlinString(config.adMobInterstitialUnitId.trim())}"
        if (unitId.isEmpty()) return
        InterstitialAd.load(this, unitId, AdRequest.Builder().build(), object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) { interstitialAd = ad }
            override fun onAdFailedToLoad(err: LoadAdError) { interstitialAd = null }
        })
    }

    private fun loadRewardedAd() {
        val unitId = "${escapeKotlinString(config.adMobRewardedUnitId.trim())}"
        if (unitId.isEmpty()) return
        RewardedAd.load(this, unitId, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) { rewardedAd = ad }
            override fun onAdFailedToLoad(err: LoadAdError) { rewardedAd = null }
        })
    }`
    : '';

  const bridgeClass = `
    inner class AndroidNativeBridge {
        @JavascriptInterface
        fun purchase(sku: String, productType: String = "inapp") {${
          config.enablePlayBilling
            ? `
            val client = billingClient ?: return
            val type = if (productType == "subs") BillingClient.ProductType.SUBS else BillingClient.ProductType.INAPP
            val product = QueryProductDetailsParams.Product.newBuilder()
                .setProductId(sku)
                .setProductType(type)
                .build()
            val params = QueryProductDetailsParams.newBuilder()
                .setProductList(listOf(product))
                .build()
            client.queryProductDetailsAsync(params) { _, list ->
                val details = list.firstOrNull() ?: return@queryProductDetailsAsync
                runOnUiThread {
                    val flowParams = BillingFlowParams.newBuilder()
                        .setProductDetailsParamsList(
                            listOf(BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(details).build())
                        )
                        .build()
                    client.launchBillingFlow(this@WebAppActivity, flowParams)
                }
            }`
            : ''
        }
        }

        @JavascriptInterface
        fun removeAds() {
            purchase("${removeAdsSkuLiteral}", "inapp")
        }

        @JavascriptInterface
        fun hasRemovedAds(): Boolean {
            return getSharedPreferences("web2apk_prefs", Context.MODE_PRIVATE).getBoolean("ads_removed", false)
        }

        @JavascriptInterface
        fun openDeveloperInfo() {
            runOnUiThread {
                webView.loadUrl("file:///android_asset/developer.html")
            }
        }

        @JavascriptInterface
        fun showInterstitial() {${
          config.enableAdMob
            ? `
            if (hasRemovedAds()) return
            runOnUiThread {
                interstitialAd?.show(this@WebAppActivity)
                loadInterstitialAd()
            }`
            : ''
        }
        }

        @JavascriptInterface
        fun showRewardedAd() {${
          config.enableAdMob
            ? `
            runOnUiThread {
                rewardedAd?.show(this@WebAppActivity) { reward ->
                    webView.evaluateJavascript(
                        "window.dispatchEvent(new CustomEvent('android:adReward',{detail:{amount:${'$'}{reward.amount},type:'${'$'}{reward.type}'}}));",
                        null
                    )
                }
                loadRewardedAd()
            }`
            : ''
        }
        }
    }`;

  zip.file(
    `app/src/main/java/${pkgPath}/WebAppActivity.kt`,
    `package ${config.packageId}

${imports.join('\n')}

class WebAppActivity : AppCompatActivity() {

    private lateinit var webView: WebView
${billingFields}
${adMobFields}

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.parseColor("${config.themeColor}")
${billingInitBlock}
${adMobInitBlock}
${launchEventBlock}

        webView = WebView(this).apply {
            settings.javaScriptEnabled = ${config.enableJavaScript}
            settings.domStorageEnabled = ${config.enableDomStorage}
            settings.builtInZoomControls = ${config.enableZoomControls}
            settings.displayZoomControls = false
            settings.mixedContentMode = ${
              config.allowCleartextTraffic
                ? 'WebSettings.MIXED_CONTENT_ALWAYS_ALLOW'
                : 'WebSettings.MIXED_CONTENT_NEVER_ALLOW'
            }
            settings.allowFileAccess = true
            settings.allowContentAccess = true
${customUaLine}
            addJavascriptInterface(AndroidNativeBridge(), "AndroidNative")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean = false${pageFinishedHook}
            }
            webChromeClient = WebChromeClient()
        }

        ${mainContentSetup}
        ${splashSection}

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        webView.loadUrl("${escapeKotlinString(targetUrl)}")
    }
${adMobHelpers}
${bridgeClass}
}
`
  );

  let iconPng: Uint8Array;
  if (config.iconBase64Png && config.iconBase64Png.trim().length > 0) {
    iconPng = base64ToBytes(config.iconBase64Png);
  } else if (fallbackIconFactory) {
    iconPng = fallbackIconFactory(config.themeColor);
  } else {
    throw new Error('Launcher icon PNG data is required.');
  }
  zip.file('app/src/main/res/mipmap/ic_launcher.png', iconPng);

  if (config.sourceMode === 'code') {
    const raw = config.rawHtmlCode?.trim() || '<!DOCTYPE html><html><body></body></html>';
    zip.file('app/src/main/assets/index.html', utf8ToBytes(raw));
  } else if (config.sourceMode === 'html') {
    for (const file of config.htmlFiles) {
      const safePath = file.path.replace(/^\/+/, '').replace(/\.\.\//g, '');
      zip.file(`app/src/main/assets/${safePath}`, base64ToBytes(file.contentBase64));
    }
  }

  if (config.developer.includeAboutPageInAssets) {
    zip.file('app/src/main/assets/developer.html', utf8ToBytes(buildDeveloperAboutHtml(config)));
  }

  zip.file(
    'README.md',
    `# ${config.appName} — Android Source Project

Generated by Web2APK Studio.

## Build with Gradle
\`\`\`bash
gradle assembleRelease
\`\`\`
Or open this directory directly in **Android Studio** and run **Build > Generate Signed Bundle / APK**.

## Native JavaScript Bridge
Inside your HTML or website JavaScript:
- \`window.addEventListener('android:launch', (e) => console.log(e.detail))\`
- \`window.AndroidNative.purchase('pro_upgrade', 'inapp')\`
- \`window.AndroidNative.removeAds()\` / \`window.AndroidNative.hasRemovedAds()\`
- \`window.AndroidNative.showInterstitial()\` / \`window.AndroidNative.showRewardedAd()\`
- \`window.AndroidNative.openDeveloperInfo()\`
`
  );

  return zip.generateAsync({ type: 'uint8array', compression: 'DEFLATE' });
}
