import { collection, doc, getDocs, limit, query, serverTimestamp, writeBatch } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { ProductGender } from '../types/store';

export const HERO_CAMPAIGN_IMAGE = '/src/assets/images/hero_fashion_campaign_1795712582725.jpg';

export const CATEGORY_IMAGES = {
  jacket: '/src/assets/images/product_mens_tailored_jacket_1795712582591.jpg',
  dress: '/src/assets/images/product_womens_silk_dress_1795712583481.jpg',
  hoodie: '/src/assets/images/product_minimal_hoodie_1795712582722.jpg',
  denim: '/src/assets/images/product_selvedge_denim_1795712582798.jpg',
  traditional: '/src/assets/images/product_traditional_wear_1795712583209.jpg',
};

export interface SeedCategory {
  id: string;
  name: string;
  slug: string;
  description: string;
  displayOrder: number;
  isActive: boolean;
}

export interface SeedProduct {
  id: string;
  name: string;
  description: string;
  price: number;
  discountPrice: number;
  category: string;
  gender: ProductGender;
  sizes: string[];
  colors: string[];
  stock: number;
  imageUrl: string;
  isNewArrival: boolean;
  isBestSeller: boolean;
  isActive: boolean;
}

export const DEFAULT_CATEGORIES: SeedCategory[] = [
  { id: 'cat-mens-fashion', name: "Men's Fashion", slug: 'mens-fashion', description: 'Tailored menswear essentials and outerwear.', displayOrder: 1, isActive: true },
  { id: 'cat-womens-fashion', name: "Women's Fashion", slug: 'womens-fashion', description: 'Contemporary silhouettes and fluid tailoring.', displayOrder: 2, isActive: true },
  { id: 'cat-t-shirts', name: 'T-Shirts', slug: 't-shirts', description: 'Heavyweight combed organic cotton tees.', displayOrder: 3, isActive: true },
  { id: 'cat-shirts', name: 'Shirts', slug: 'shirts', description: 'Crisp poplin, Oxford, and linen button-downs.', displayOrder: 4, isActive: true },
  { id: 'cat-jeans', name: 'Jeans', slug: 'jeans', description: 'Japanese selvedge and relaxed raw denim.', displayOrder: 5, isActive: true },
  { id: 'cat-hoodies', name: 'Hoodies', slug: 'hoodies', description: 'Structured heavyweight loopback fleece.', displayOrder: 6, isActive: true },
  { id: 'cat-jackets', name: 'Jackets', slug: 'jackets', description: 'Architectural wool coats and overshirts.', displayOrder: 7, isActive: true },
  { id: 'cat-dresses', name: 'Dresses', slug: 'dresses', description: 'Silk bias-cut and tailored midi dresses.', displayOrder: 8, isActive: true },
  { id: 'cat-traditional-wear', name: 'Traditional Wear', slug: 'traditional-wear', description: 'Handloom silk-linen kurtas and ceremonial attire.', displayOrder: 9, isActive: true },
];

export const DEFAULT_PRODUCTS: SeedProduct[] = [
  {
    id: 'prod-atelier-wool-overshirt',
    name: 'Atelier Boiled Wool Overshirt Jacket',
    description: 'Cut from Italian boiled merino wool in a structured boxy silhouette. Features concealed horn buttons, twin patch chest pockets, and soft brushed lining for effortless layering.',
    price: 1999,
    discountPrice: 1599,
    category: 'Jackets',
    gender: 'Men',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Charcoal', 'Onyx Black'],
    stock: 24,
    imageUrl: CATEGORY_IMAGES.jacket,
    isNewArrival: true,
    isBestSeller: true,
    isActive: true,
  },
  {
    id: 'prod-noir-bias-silk-dress',
    name: 'Noir Bias-Cut Mulberry Silk Midi Dress',
    description: 'Draped from 22-momme mulberry silk with an asymmetric cowl neckline and fluid bias-cut skirt that skims the silhouette with natural luster.',
    price: 2499,
    discountPrice: 1999,
    category: 'Dresses',
    gender: 'Women',
    sizes: ['XS', 'S', 'M', 'L'],
    colors: ['Onyx Black', 'Midnight'],
    stock: 18,
    imageUrl: CATEGORY_IMAGES.dress,
    isNewArrival: true,
    isBestSeller: true,
    isActive: true,
  },
  {
    id: 'prod-slate-heavyweight-hoodie',
    name: 'Studio 520GSM Heavyweight Loopback Hoodie',
    description: 'Engineered from 100% organic loopback cotton fleece with dropped shoulders, double-lined structured hood, and tonal matte metal drawcord tips.',
    price: 1499,
    discountPrice: 1199,
    category: 'Hoodies',
    gender: 'Unisex',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Slate Grey', 'Alabaster', 'Onyx Black'],
    stock: 42,
    imageUrl: CATEGORY_IMAGES.hoodie,
    isNewArrival: true,
    isBestSeller: true,
    isActive: true,
  },
  {
    id: 'prod-selvedge-indigo-jeans',
    name: 'Kyoto 14oz Raw Selvedge Straight Jeans',
    description: 'Woven on vintage shuttle looms using long-staple indigo cotton. Classic mid-rise straight leg finished with copper rivets and chain-stitched hems.',
    price: 1799,
    discountPrice: 0,
    category: 'Jeans',
    gender: 'Men',
    sizes: ['30', '32', '34', '36'],
    colors: ['Raw Indigo', 'Washed Onyx'],
    stock: 30,
    imageUrl: CATEGORY_IMAGES.denim,
    isNewArrival: false,
    isBestSeller: true,
    isActive: true,
  },
  {
    id: 'prod-handloom-ivory-kurta-set',
    name: 'Heritage Handloom Silk-Linen Kurta Ensemble',
    description: 'Artisanal ivory handloom kurta adorned with delicate tonal Chikankari embroidery along the placket, paired with pleated wide-leg trousers and a woven stole.',
    price: 2299,
    discountPrice: 1899,
    category: 'Traditional Wear',
    gender: 'Women',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Ivory Silk', 'Warm Sand'],
    stock: 16,
    imageUrl: CATEGORY_IMAGES.traditional,
    isNewArrival: true,
    isBestSeller: false,
    isActive: true,
  },
  {
    id: 'prod-crisp-poplin-tailored-shirt',
    name: 'Milanese Crisp Cotton Poplin Shirt',
    description: 'High-density two-ply Egyptian cotton poplin shirt with architectural collar stand, mother-of-pearl buttons, and tailored curved hem.',
    price: 1299,
    discountPrice: 999,
    category: 'Shirts',
    gender: 'Men',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Optical White', 'Slate Blue'],
    stock: 35,
    imageUrl: CATEGORY_IMAGES.denim,
    isNewArrival: true,
    isBestSeller: false,
    isActive: true,
  },
  {
    id: 'prod-supima-architectural-tee',
    name: 'Essential 300GSM Supima Box Tee',
    description: 'Dense, breathable Supima cotton jersey with a high-ribbed crew collar and clean tailored drape designed for daily uniform dressing.',
    price: 699,
    discountPrice: 549,
    category: 'T-Shirts',
    gender: 'Unisex',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Optical White', 'Onyx Black', 'Stone'],
    stock: 60,
    imageUrl: CATEGORY_IMAGES.jacket,
    isNewArrival: false,
    isBestSeller: true,
    isActive: true,
  },
  {
    id: 'prod-double-faced-trench-coat',
    name: 'Belted Double-Faced Cashmere Blend Coat',
    description: 'Full-length tailored overcoat in double-faced virgin wool and cashmere with notched lapels, tonal waist belt, and clean welt pockets.',
    price: 3499,
    discountPrice: 2899,
    category: "Women's Fashion",
    gender: 'Women',
    sizes: ['XS', 'S', 'M', 'L'],
    colors: ['Onyx Black', 'Ivory'],
    stock: 12,
    imageUrl: HERO_CAMPAIGN_IMAGE,
    isNewArrival: true,
    isBestSeller: true,
    isActive: true,
  },
  {
    id: 'prod-pleated-wool-trouser-set',
    name: 'Tailored Merino Pleated Menswear Set',
    description: 'Relaxed single-pleat virgin wool trousers matched with an unstructured minimalist overshirt for sharp monochrome proportions.',
    price: 2699,
    discountPrice: 2199,
    category: "Men's Fashion",
    gender: 'Men',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Charcoal', 'Obsidian'],
    stock: 20,
    imageUrl: CATEGORY_IMAGES.jacket,
    isNewArrival: false,
    isBestSeller: false,
    isActive: true,
  },
];

export const DEFAULT_STORE_SETTINGS = {
  storeName: 'Fashion Hub',
  storeAddress: 'Assam Badarpur Fashion Hub',
  supportEmail: 'concierge@fashionhub-atelier.com',
  announcementText: 'Complimentary Express Delivery on Orders Over ₹999 · Flagship: Assam Badarpur Fashion Hub',
  freeShippingThreshold: 999,
  standardShippingFee: 60,
  onlinePaymentEnabled: false,
};

export async function seedInitialCatalogIfEmpty(): Promise<{ seededProducts: number; seededCategories: number }> {
  let seededProducts = 0;
  let seededCategories = 0;

  try {
    const prodSnap = await getDocs(query(collection(db, 'products'), limit(1)));
    const catSnap = await getDocs(query(collection(db, 'categories'), limit(1)));
    const settingsSnap = await getDocs(query(collection(db, 'settings'), limit(1)));

    const batch = writeBatch(db);
    let hasWrites = false;

    if (catSnap.empty) {
      for (const cat of DEFAULT_CATEGORIES) {
        batch.set(doc(db, 'categories', cat.id), {
          ...cat,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        seededCategories++;
      }
      hasWrites = true;
    }

    if (prodSnap.empty) {
      for (const prod of DEFAULT_PRODUCTS) {
        batch.set(doc(db, 'products', prod.id), {
          ...prod,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        seededProducts++;
      }
      hasWrites = true;
    }

    if (settingsSnap.empty) {
      batch.set(doc(db, 'settings', 'storeConfig'), {
        ...DEFAULT_STORE_SETTINGS,
        updatedAt: serverTimestamp(),
      });
      hasWrites = true;
    }

    if (hasWrites) {
      await batch.commit();
    }

    return { seededProducts, seededCategories };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'products/categories/settings');
  }
}
