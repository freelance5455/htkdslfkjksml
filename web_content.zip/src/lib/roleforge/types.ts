export type ProseDensity = "breve" | "equilibrada" | "literaria";
export type Autonomy = "contenida" | "viva" | "impredecible";
export type Mode = "apertura" | "turno" | "aliento";

export type Clock = {
  day: number;
  minute: number;
  label: string;
};

export type Place = {
  id: string;
  name: string;
  note: string;
};

export type Character = {
  id: string;
  name: string;
  role: string;
  appearance: string;
  personality: string;
  voice: string;
  knowledge: string;
  motivations: string;
  limits: string;
  goal: string;
  secret: string;
  mood: string;
  agenda: string;
  place: string;
  opinion: number;
  bondNote: string;
  origin: "forjado" | "surgido";
  weight: "principal" | "menor";
};

export type Original = {
  name: string;
  pronouns: string;
  appearance: string;
  voice: string;
  background: string;
  goal: string;
  trait: string;
};

export type Entry = {
  id: string;
  at: number;
  kind: "jugador" | "narracion" | "dialogo" | "aparte";
  speaker: string | null;
  text: string;
};

export type Memory = {
  id: string;
  at: number;
  summary: string;
  importance: number;
  who: string[];
};

export type Chronicle = {
  id: string;
  at: number;
  summary: string;
  who: string[];
  seen: boolean;
};

export type Campaign = {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  universe: string;
  premise: string;
  tone: string;
  rules: string;
  boundaries: string;
  prose: ProseDensity;
  autonomy: Autonomy;
  clock: Clock;
  places: Place[];
  oc: Original;
  cast: Character[];
  scene: {
    place: string;
    atmosphere: string;
    summary: string;
    present: string[];
  };
  threads: string[];
  entries: Entry[];
  memories: Memory[];
  chronicle: Chronicle[];
  undo: Omit<Campaign, "undo"> | null;
};

export type Beat = {
  kind: "narracion" | "dialogo" | "aparte";
  speaker: string | null;
  text: string;
};

export type NarrationResult = {
  beats: Beat[];
  escena: {
    lugar: string;
    atmosfera: string;
    resumen: string;
    presentes: string[];
  };
  reloj: { minutos: number; etiqueta: string };
  personajes: Array<{
    nombre: string;
    animo: string;
    lugar: string;
    agenda: string;
    opinion: number;
    conocimiento: string;
    vinculo: string;
    motivo: string;
  }>;
  memorias: Array<{ resumen: string; importancia: number; quienes: string[] }>;
  fueraDeEscena: Array<{ resumen: string; quienes: string[] }>;
  hilos: string[];
  lugaresNuevos: Array<{ nombre: string; nota: string }>;
};

export type ForgeSuggestion = {
  titulo: string;
  lugares: Array<{ nombre: string; nota: string }>;
  reparto: Array<{
    nombre: string;
    rol: string;
    apariencia: string;
    personalidad: string;
    voz: string;
    conocimientos: string;
    motivaciones: string;
    limites: string;
    objetivo: string;
    secreto: string;
    lugar: string;
  }>;
};

export const DEFAULT_BOUNDARIES =
  "Sin sexo explícito. Si hay violencia, se narra con contención y sin recrearse en el daño. Nada de contenido sexual que involucre a menores.";
