import assert from "node:assert/strict";
import test from "node:test";
import { applyNarration, createCampaign } from "./apply.ts";
import { parseNarration } from "./parse.ts";

test("lee JSON con valla markdown y alias", () => {
  const result = parseNarration(`\`\`\`json
{"beats":[{"tipo":"dialogo","hablante":"Nerea","texto":"No te debo la llave."}],"escena":{"place":"El muelle","present":["Nerea"]},"reloj":{"minutes":12,"label":"mediodía"},"personajes":[{"name":"Nerea","opinion":1,"mood":"tensa"}],"memorias":[{"summary":"Nerea niega la llave","importance":3}],"fueraDeEscena":[],"hilos":["la llave"]}
\`\`\``);
  assert.ok(result);
  assert.equal(result.beats[0]?.kind, "dialogo");
  assert.equal(result.beats[0]?.speaker, "Nerea");
  assert.equal(result.escena.lugar, "El muelle");
  assert.equal(result.reloj.minutos, 12);
  assert.equal(result.personajes[0]?.opinion, 1);
});

test("aplica el turno sin hablar por el OC y mueve la opinión", () => {
  const campaign = createCampaign({
    title: "Marea",
    universe: "Puerto",
    premise: "Alguien robó el cuaderno de bitácora.",
    tone: "seco",
    rules: "",
    boundaries: "",
    prose: "breve",
    autonomy: "viva",
    oc: { name: "Sol", pronouns: "ella", appearance: "", voice: "", background: "", goal: "", trait: "" },
    places: [{ name: "El muelle", note: "" }],
    cast: [],
  });
  const parsed = parseNarration(
    JSON.stringify({
      beats: [
        { kind: "narracion", speaker: null, text: "La madera está caliente." },
        { kind: "dialogo", speaker: "Nerea", text: "Llegas tarde." },
      ],
      escena: { lugar: "El muelle", atmosfera: "sal", resumen: "Nerea espera.", presentes: ["Nerea"] },
      reloj: { minutos: 15, etiqueta: "mañana" },
      personajes: [{ nombre: "Nerea", animo: "seca", lugar: "El muelle", agenda: "Vigila el cuaderno", opinion: 1, conocimiento: "Sol preguntó por el cuaderno", vinculo: "Desconfía", motivo: "Esconder el cuaderno" }],
      memorias: [{ resumen: "Nerea vigila el cuaderno.", importancia: 2, quienes: ["Nerea"] }],
      fueraDeEscena: [{ resumen: "El farero apaga una lámpara de más.", quienes: ["El farero"] }],
      hilos: ["el cuaderno"],
      lugaresNuevos: [],
    }),
  );
  assert.ok(parsed);
  const next = applyNarration(campaign, parsed, { mode: "turno", playerText: "Me acerco sin saludar." });
  assert.equal(next.entries[0]?.kind, "jugador");
  assert.equal(next.entries[0]?.text, "Me acerco sin saludar.");
  assert.equal(next.cast[0]?.name, "Nerea");
  assert.equal(next.cast[0]?.opinion, 1);
  assert.equal(next.cast[0]?.origin, "surgido");
  assert.equal(next.scene.place, "El muelle");
  assert.equal(next.chronicle.length, 1);
  assert.equal(next.chronicle[0]?.seen, false);
  assert.ok(next.undo);
  assert.equal(next.clock.minute, 9 * 60 + 15);
});
