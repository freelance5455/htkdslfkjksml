import type { Clock } from "./types.ts";

export function norm(value: string): string {
  return value
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/\p{M}/gu, "");
}

export function sameName(a: string, b: string): boolean {
  const left = norm(a);
  const right = norm(b);
  return left.length > 0 && left === right;
}

export function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

export function uid(): string {
  return crypto.randomUUID();
}

export function formatClock(clock: Clock): string {
  const hour = Math.floor(clock.minute / 60);
  const minute = clock.minute % 60;
  const hh = String(hour).padStart(2, "0");
  const mm = String(minute).padStart(2, "0");
  const label = clock.label.trim();
  return `Día ${clock.day} · ${hh}:${mm}${label ? ` · ${label}` : ""}`;
}

export function opinionLabel(value: number): string {
  if (value <= -4) return "Hostil";
  if (value <= -2) return "Frío";
  if (value === -1) return "Cauteloso";
  if (value === 0) return "Neutro";
  if (value === 1) return "Atento";
  if (value <= 3) return "Cercano";
  return "Leal";
}

export function clip(value: string, max: number): string {
  const text = value.trim();
  if (text.length <= max) return text;
  return `${text.slice(0, max - 1).trimEnd()}…`;
}
