import { createServerFn } from "@tanstack/react-start";
import { parseNarration, parseSuggestion } from "./parse.ts";
import { buildNarrationMessages, buildSuggestMessages } from "./prompt.ts";
import type { Campaign, ForgeSuggestion, Mode, NarrationResult } from "./types.ts";

type ChatMessage = { role: "system" | "user" | "assistant"; content: string };

const MODES: Mode[] = ["apertura", "turno", "aliento"];

function asRecord(value: unknown): Record<string, unknown> | null {
  if (value && typeof value === "object" && !Array.isArray(value)) return value as Record<string, unknown>;
  return null;
}

function requireCampaign(value: unknown): Campaign {
  const row = asRecord(value);
  const oc = asRecord(row?.oc);
  if (!row || typeof row.id !== "string" || !oc || typeof oc.name !== "string" || !oc.name.trim()) {
    throw new Error("La partida está incompleta.");
  }
  const encoded = JSON.stringify(row);
  if (encoded.length > 350_000) throw new Error("Esta partida pesa demasiado para enviarla de una vez.");
  return row as Campaign;
}

async function complete(messages: ChatMessage[], maxTokens: number): Promise<{ ok: true; text: string } | { ok: false; error: string }> {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) {
    return { ok: false, error: "La narración con IA no está disponible en este entorno." };
  }

  let response: Response;
  try {
    response = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        temperature: 0.85,
        max_tokens: maxTokens,
        response_format: { type: "json_object" },
        messages,
      }),
    });
  } catch {
    return { ok: false, error: "No hubo conexión con el narrador. Inténtalo otra vez." };
  }

  if (!response.ok) {
    let detail = "";
    try {
      const errBody = (await response.json()) as { error?: string; code?: string };
      detail = `${errBody.code ?? ""} ${errBody.error ?? ""}`;
    } catch {
      detail = "";
    }
    if (response.status === 401 || response.status === 403 || /credit|spending-limit|subscription/i.test(detail)) {
      return {
        ok: false,
        error:
          "No hay créditos de IA disponibles, así que no se escribió una escena falsa. Cuando la cuenta tenga acceso, este mismo botón enciende la historia.",
      };
    }
    return { ok: false, error: `El narrador respondió con un error (${response.status}).` };
  }

  const body = (await response.json()) as { choices?: Array<{ message?: { content?: string } }> };
  const text = body.choices?.[0]?.message?.content ?? "";
  if (!text.trim()) return { ok: false, error: "El narrador devolvió una escena vacía." };
  return { ok: true, text };
}

export const narrateTurn = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const row = asRecord(input);
    const mode = row?.mode;
    if (typeof mode !== "string" || !MODES.includes(mode as Mode)) throw new Error("Modo de escena desconocido.");
    const playerText = typeof row?.playerText === "string" ? row.playerText.trim().slice(0, 2000) : "";
    if (mode === "turno" && !playerText) throw new Error("Escribe lo que hace o dice tu personaje.");
    return { mode: mode as Mode, playerText, campaign: requireCampaign(row?.campaign) };
  })
  .handler(async ({ data }): Promise<{ ok: true; result: NarrationResult } | { ok: false; error: string }> => {
    const messages = buildNarrationMessages(data);
    const first = await complete(messages, data.mode === "aliento" ? 1100 : 1500);
    if (!first.ok) return first;

    let result = parseNarration(first.text);
    if (!result) {
      const retry = await complete(
        [
          ...messages,
          { role: "assistant", content: first.text.slice(0, 4000) },
          { role: "user", content: "Eso no era JSON válido. Devuelve únicamente el objeto JSON pedido, sin markdown." },
        ],
        1200,
      );
      if (!retry.ok) return { ok: false, error: "La escena no se pudo leer. Inténtalo de nuevo." };
      result = parseNarration(retry.text);
    }

    if (!result) return { ok: false, error: "La escena no se pudo leer. Inténtalo de nuevo." };
    const usable = result.beats.length > 0 || (data.mode === "aliento" && result.fueraDeEscena.length > 0);
    if (!usable) return { ok: false, error: "La escena volvió vacía. Reformula el gesto de tu personaje." };
    return { ok: true, result };
  });

export const suggestCast = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const row = asRecord(input);
    const premise = typeof row?.premise === "string" ? row.premise.trim().slice(0, 1200) : "";
    if (premise.length < 12) throw new Error("Cuéntame un poco más la premisa antes de forjar el reparto.");
    return {
      universe: typeof row?.universe === "string" ? row.universe.slice(0, 200) : "",
      premise,
      tone: typeof row?.tone === "string" ? row.tone.slice(0, 240) : "",
      rules: typeof row?.rules === "string" ? row.rules.slice(0, 600) : "",
      ocName: typeof row?.ocName === "string" ? row.ocName.slice(0, 80) : "",
      boundaries: typeof row?.boundaries === "string" ? row.boundaries.slice(0, 400) : "",
    };
  })
  .handler(async ({ data }): Promise<{ ok: true; suggestion: ForgeSuggestion } | { ok: false; error: string }> => {
    const first = await complete(buildSuggestMessages(data), 1200);
    if (!first.ok) return first;
    const suggestion = parseSuggestion(first.text);
    if (suggestion) return { ok: true, suggestion };
    return { ok: false, error: "El reparto no se pudo leer. Inténtalo de nuevo." };
  });
