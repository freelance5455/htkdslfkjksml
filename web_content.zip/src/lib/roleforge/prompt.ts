import type { Campaign, Mode } from "./types.ts";
import { clip, sameName } from "./text.ts";

type Msg = { role: "system" | "user"; content: string };

const SYSTEM = `Eres el director narrativo de Roleforge. El jugador interpreta únicamente a su personaje original (OC). Tú interpretas el mundo, el tiempo, los lugares y todos los demás personajes.

Reglas duras:
- Nunca escribas acciones, decisiones, pensamientos ni diálogos del OC. Si el jugador no lo declaró, su personaje no lo dijo ni lo hizo.
- No ofrezcas menús numerados ni preguntes "¿qué haces?".
- Cada personaje conserva su personalidad, su voz, lo que sabe, lo que ignora, sus motivaciones y sus límites. No los conviertas en un coro pendiente del protagonista.
- Pueden callar, mentir, cambiar de opinión, ocultar algo, quererse, traicionarse y perseguir un objetivo propio.
- Quien no está en el lugar de la escena no habla en los beats. Su vida va en fueraDeEscena. Un aparte solo si el OC puede percibirlo (ruido, carta, rumor que le llega).
- No contradigas la memoria, el reloj, el lugar ni los hechos recientes.
- Respeta las reglas del universo, el tono y los límites de contenido. Si el jugador empuja contra ellos, el mundo lo desvía dentro de la ficción, sin sermón ni aviso de sistema.
- Escribe en español, con prosa concreta y sensorial. Nada de clichés vacíos ("el aire se cargó de misterio", "el destino", "un escalofrío le recorrió la espalda").
- Los diálogos suenan a gente distinta. No expliques la emoción si el gesto ya la dice.
- Lo inesperado vale solo cuando cabe en este mundo y en lo ya ocurrido.

Responde solo con un objeto JSON, sin markdown, con esta forma exacta:
{
  "beats": [{"kind":"narracion|dialogo|aparte","speaker":null,"text":"..."}],
  "escena": {"lugar":"","atmosfera":"","resumen":"","presentes":[""]},
  "reloj": {"minutos":15,"etiqueta":""},
  "personajes": [{"nombre":"","animo":"","lugar":"","agenda":"","opinion":0,"conocimiento":"","vinculo":"","motivo":""}],
  "memorias": [{"resumen":"","importancia":2,"quienes":[""]}],
  "fueraDeEscena": [{"resumen":"","quienes":[""]}],
  "hilos": [""],
  "lugaresNuevos": [{"nombre":"","nota":""}]
}

kind dialogo usa speaker con el nombre del personaje, nunca el del OC. narracion lleva speaker null.
opinion es un delta entero entre -2 y 2, y 0 si no hay causa.
personajes incluye solo a quien actuó o cambió.
memorias son hechos nuevos que un director debe recordar, no un resumen de todo.
fueraDeEscena queda vacío si nadie hizo nada lejos del OC.
No repitas en beats lo que pongas en fueraDeEscena.`;

function densityLine(prose: Campaign["prose"]): string {
  if (prose === "breve") return "Densidad breve: un latido de narración corto y diálogos de una o dos frases. Máximo 3 beats.";
  if (prose === "literaria") return "Densidad literaria: prosa cuidada y concreta, sin adornar de más. Máximo 4 beats.";
  return "Densidad equilibrada: una narración legible y diálogos con aire. Máximo 4 beats.";
}

function autonomyLine(autonomy: Campaign["autonomy"]): string {
  if (autonomy === "contenida") return "Autonomía contenida: casi no uses fueraDeEscena. El mundo reacciona sobre todo a lo que provoca el OC.";
  if (autonomy === "impredecible") return "Autonomía impredecible: permite un secreto, un desvío o un hecho lejos del OC, siempre con causa. Máximo un fueraDeEscena.";
  return "Autonomía viva: los personajes tienen agenda propia. Como mucho un hecho fuera de escena, y solo si nace de lo que ya quieren.";
}

function modeLine(mode: Mode, playerText: string): string {
  if (mode === "apertura") {
    return playerText
      ? `Modo apertura. Abre la historia in medias res incorporando SOLO este primer gesto del OC, sin ampliarlo: «${playerText}». No resuelvas el conflicto. No hables en su voz más allá de esa frase.`
      : "Modo apertura. Abre in medias res: lugar, una presión concreta y al menos una presencia si hay alguien que pueda estar ahí. No resuelvas nada. No hables como el OC. Termina en un instante que espera su gesto, sin preguntarle al jugador.";
  }
  if (mode === "aliento") {
    return "Modo aliento. El jugador no actúa y el OC no hace nada. Avanza un poco la vida de los demás. Prioriza fueraDeEscena. Como mucho un aparte que el OC podría notar. Cero diálogos del OC.";
  }
  return `Modo turno. El OC acaba de declarar, literalmente: «${playerText}». Interpreta eso como acción y diálogo suyos. No lo embellezcas ni le añadas heroísmo, y no escribas más palabras en su boca.`;
}

function sheet(campaign: Campaign, name: string): string {
  const present = campaign.scene.present.some((who) => sameName(who, name)) || sameName(campaign.scene.place, campaign.cast.find((c) => sameName(c.name, name))?.place ?? "");
  const character = campaign.cast.find((item) => sameName(item.name, name));
  if (!character) return "";
  if (character.weight === "menor" && !present) {
    return `- ${character.name} (menor, ${character.role || "sin rol"}). Lugar: ${character.place || "desconocido"}. Ánimo: ${character.mood}. Agenda: ${character.agenda}. Objetivo: ${character.goal}`;
  }
  return [
    `- ${character.name} [${character.weight}] ${character.role}`,
    `  Apariencia: ${clip(character.appearance, 180) || "—"}`,
    `  Personalidad: ${clip(character.personality, 180) || "—"}`,
    `  Voz: ${clip(character.voice, 120) || "—"}`,
    `  Sabe: ${clip(character.knowledge, 180) || "—"}`,
    `  Quiere: ${clip(character.motivations, 160) || "—"} / objetivo: ${clip(character.goal, 140) || "—"}`,
    `  No hará: ${clip(character.limits, 140) || "—"}`,
    `  Secreto (el OC no lo sabe salvo que la escena lo revele): ${clip(character.secret, 160) || "—"}`,
    `  Lugar: ${character.place || "—"} · Ánimo: ${character.mood} · Opinión del OC (${campaign.oc.name}): ${character.opinion}`,
    `  Agenda ahora: ${clip(character.agenda, 160) || "—"}`,
    `  Vínculo: ${clip(character.bondNote, 140) || "—"}`,
  ].join("\n");
}

export function buildNarrationMessages(input: { mode: Mode; playerText: string; campaign: Campaign }): Msg[] {
  const { campaign, mode, playerText } = input;
  const recent = campaign.entries.slice(-10).map((entry) => {
    const who = entry.kind === "jugador" ? campaign.oc.name : entry.kind === "narracion" ? "Narración" : entry.speaker || "Alguien";
    return `${who}: ${clip(entry.text, 420)}`;
  });
  const memories = [...campaign.memories]
    .sort((a, b) => b.importance - a.importance || b.at - a.at)
    .slice(0, 12)
    .map((memory) => `- (${memory.importance}) ${clip(memory.summary, 220)}`);
  const chronicle = campaign.chronicle.slice(-4).map((event) => `- ${clip(event.summary, 200)}`);
  const cast = campaign.cast.map((character) => sheet(campaign, character.name)).filter(Boolean);
  const places = campaign.places.map((place) => `- ${place.name}${place.note ? `: ${clip(place.note, 140)}` : ""}`);

  const body = [
    `OC — el único personaje del jugador: ${campaign.oc.name} (${campaign.oc.pronouns || "sin pronombres declarados"}).`,
    `Apariencia: ${clip(campaign.oc.appearance, 200) || "—"}`,
    `Voz: ${clip(campaign.oc.voice, 140) || "—"}`,
    `Historia: ${clip(campaign.oc.background, 280) || "—"}`,
    `Rasgo: ${clip(campaign.oc.trait, 140) || "—"}`,
    `Quiere: ${clip(campaign.oc.goal, 180) || "—"}`,
    ``,
    `Universo: ${clip(campaign.universe, 120) || "—"}`,
    `Premisa: ${clip(campaign.premise, 500) || "—"}`,
    `Tono: ${clip(campaign.tone, 200) || "—"}`,
    `Reglas: ${clip(campaign.rules, 700) || "Sin reglas extra."}`,
    `Límites de contenido: ${clip(campaign.boundaries, 400)}`,
    densityLine(campaign.prose),
    autonomyLine(campaign.autonomy),
    ``,
    `Reloj: día ${campaign.clock.day}, minuto ${campaign.clock.minute} (${campaign.clock.label}).`,
    `Lugar actual: ${campaign.scene.place || "sin fijar"}.`,
    `Atmósfera: ${campaign.scene.atmosphere || "—"}`,
    `Resumen de la escena: ${campaign.scene.summary || "Aún no hay escena."}`,
    `Presentes: ${campaign.scene.present.join(", ") || "aún no definidos"}.`,
    ``,
    `Lugares:`,
    places.join("\n") || "- (ninguno todavía)",
    ``,
    `Reparto:`,
    cast.join("\n") || "- (todavía no hay nadie más; puedes hacer surgir una presencia menor si la premisa lo pide)",
    ``,
    `Hilos abiertos: ${campaign.threads.join(" | ") || "ninguno"}`,
    ``,
    `Memoria del director:`,
    memories.join("\n") || "- (vacía)",
    ``,
    `Crónica lejos del OC:`,
    chronicle.join("\n") || "- (nada registrado)",
    ``,
    `Hechos recientes, en orden:`,
    recent.join("\n") || "- (la historia no ha empezado)",
    ``,
    modeLine(mode, playerText),
  ].join("\n");

  return [
    { role: "system", content: SYSTEM },
    { role: "user", content: body },
  ];
}

export function buildSuggestMessages(input: {
  universe: string;
  premise: string;
  tone: string;
  rules: string;
  ocName: string;
  boundaries: string;
}): Msg[] {
  return [
    {
      role: "system",
      content: `Forjas el reparto inicial de una partida de Roleforge. No escribas la escena. Devuelve solo JSON:
{"titulo":"","lugares":[{"nombre":"","nota":""}],"reparto":[{"nombre":"","rol":"","apariencia":"","personalidad":"","voz":"","conocimientos":"","motivaciones":"","limites":"","objetivo":"","secreto":"","lugar":""}]}
Tres lugares concretos y tres personajes que no sean el OC. Cada uno quiere algo distinto, guarda un secreto útil y tiene un límite. Nada de taberna genérica salvo que la premisa sea esa. Español, específico, sin clichés. Respeta los límites de contenido.`,
    },
    {
      role: "user",
      content: [
        `OC que NO debes duplicar: ${input.ocName || "sin nombre"}`,
        `Universo: ${clip(input.universe, 160)}`,
        `Premisa: ${clip(input.premise, 700)}`,
        `Tono: ${clip(input.tone, 200)}`,
        `Reglas: ${clip(input.rules, 400)}`,
        `Límites: ${clip(input.boundaries, 300)}`,
      ].join("\n"),
    },
  ];
}
