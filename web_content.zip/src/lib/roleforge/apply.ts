import type { Campaign, Character, Chronicle, Entry, Memory, Mode, NarrationResult, Place } from "./types.ts";
import { DEFAULT_BOUNDARIES } from "./types.ts";
import { clamp, norm, sameName, uid } from "./text.ts";

export function blankCharacter(partial?: Partial<Character>): Character {
  return {
    id: uid(),
    name: "",
    role: "",
    appearance: "",
    personality: "",
    voice: "",
    knowledge: "",
    motivations: "",
    limits: "",
    goal: "",
    secret: "",
    mood: "Expectante",
    agenda: "Sigue con su propia vida.",
    place: "",
    opinion: 0,
    bondNote: "",
    origin: "forjado",
    weight: "principal",
    ...partial,
  };
}

export function createCampaign(input: {
  title: string;
  universe: string;
  premise: string;
  tone: string;
  rules: string;
  boundaries: string;
  prose: Campaign["prose"];
  autonomy: Campaign["autonomy"];
  oc: Campaign["oc"];
  places: Array<Pick<Place, "name" | "note">>;
  cast: Character[];
}): Campaign {
  const now = Date.now();
  const places = input.places
    .map((place) => ({ id: uid(), name: place.name.trim(), note: place.note.trim() }))
    .filter((place) => place.name);
  const cast = input.cast
    .map((character) => ({
      ...character,
      name: character.name.trim(),
      place: character.place.trim() || places[0]?.name || "",
    }))
    .filter((character) => character.name && !sameName(character.name, input.oc.name));

  return {
    id: uid(),
    title: input.title.trim() || input.universe.trim() || "Partida sin título",
    createdAt: now,
    updatedAt: now,
    universe: input.universe.trim(),
    premise: input.premise.trim(),
    tone: input.tone.trim(),
    rules: input.rules.trim(),
    boundaries: input.boundaries.trim() || DEFAULT_BOUNDARIES,
    prose: input.prose,
    autonomy: input.autonomy,
    clock: { day: 1, minute: 9 * 60, label: "mañana" },
    places,
    oc: {
      name: input.oc.name.trim(),
      pronouns: input.oc.pronouns.trim(),
      appearance: input.oc.appearance.trim(),
      voice: input.oc.voice.trim(),
      background: input.oc.background.trim(),
      goal: input.oc.goal.trim(),
      trait: input.oc.trait.trim(),
    },
    cast,
    scene: {
      place: places[0]?.name ?? "",
      atmosphere: "",
      summary: "",
      present: [],
    },
    threads: [],
    entries: [],
    memories: [],
    chronicle: [],
    undo: null,
  };
}

function snapshot(campaign: Campaign): Omit<Campaign, "undo"> {
  const { undo: _undo, ...rest } = campaign;
  return rest;
}

function ensurePlace(places: Place[], name: string, note = ""): Place[] {
  const trimmed = name.trim();
  if (!trimmed) return places;
  if (places.some((place) => sameName(place.name, trimmed))) return places;
  return [...places, { id: uid(), name: trimmed, note: note.trim() }];
}

function appendKnowledge(current: string, extra: string): string {
  const next = extra.trim();
  if (!next) return current;
  if (norm(current).includes(norm(next))) return current;
  const joined = current.trim() ? `${current.trim()}\n${next}` : next;
  return joined.slice(0, 700);
}

function isOc(campaign: Campaign, name: string): boolean {
  return sameName(name, campaign.oc.name);
}

function touchCharacter(campaign: Campaign, cast: Character[], update: NarrationResult["personajes"][number]): Character[] {
  if (isOc(campaign, update.nombre)) return cast;
  const index = cast.findIndex((character) => sameName(character.name, update.nombre));
  if (index === -1) {
    return [
      ...cast,
      blankCharacter({
        name: update.nombre,
        role: "Presencia surgida en la escena",
        knowledge: update.conocimiento,
        motivations: update.motivo,
        goal: update.motivo,
        mood: update.animo || "Indefinido",
        agenda: update.agenda || "Acaba de entrar en la historia.",
        place: update.lugar || campaign.scene.place,
        opinion: update.opinion,
        bondNote: update.vinculo,
        origin: "surgido",
        weight: "menor",
      }),
    ];
  }
  const current = cast[index]!;
  const next: Character = {
    ...current,
    mood: update.animo || current.mood,
    place: update.lugar || current.place,
    agenda: update.agenda || current.agenda,
    opinion: clamp(current.opinion + update.opinion, -5, 5),
    knowledge: appendKnowledge(current.knowledge, update.conocimiento),
    bondNote: update.vinculo || current.bondNote,
    goal: update.motivo || current.goal,
    motivations: update.motivo || current.motivations,
  };
  return cast.map((character, i) => (i === index ? next : character));
}

function capEntries(entries: Entry[]): Entry[] {
  if (entries.length <= 180) return entries;
  return [...entries.slice(0, 2), ...entries.slice(-160)];
}

function capMemories(memories: Memory[]): Memory[] {
  if (memories.length <= 48) return memories;
  const newest = memories.slice(-8);
  const older = memories.slice(0, -8);
  older.sort((a, b) => b.importance - a.importance || b.at - a.at);
  return [...older.slice(0, 40), ...newest];
}

export function applyNarration(
  campaign: Campaign,
  result: NarrationResult,
  meta: { mode: Mode; playerText: string },
): Campaign {
  const now = Date.now();
  let places = campaign.places;
  for (const place of result.lugaresNuevos) places = ensurePlace(places, place.nombre, place.nota);

  const scenePlace = result.escena.lugar || campaign.scene.place;
  places = ensurePlace(places, scenePlace);

  let cast = campaign.cast;
  for (const update of result.personajes) cast = touchCharacter({ ...campaign, scene: { ...campaign.scene, place: scenePlace } }, cast, update);

  const namedPresent = result.escena.presentes.filter((name) => !isOc(campaign, name));
  cast = cast.map((character) => {
    if (namedPresent.some((name) => sameName(name, character.name)) && scenePlace) {
      return { ...character, place: scenePlace };
    }
    return character;
  });

  const present = [
    campaign.oc.name,
    ...cast.filter((character) => scenePlace && sameName(character.place, scenePlace)).map((character) => character.name),
  ].filter((name, index, all) => name && all.findIndex((other) => sameName(other, name)) === index);

  const entries: Entry[] = [...campaign.entries];
  if ((meta.mode === "turno" || meta.mode === "apertura") && meta.playerText.trim()) {
    entries.push({
      id: uid(),
      at: now,
      kind: "jugador",
      speaker: campaign.oc.name,
      text: meta.playerText.trim(),
    });
  }
  for (const beat of result.beats) {
    entries.push({
      id: uid(),
      at: now,
      kind: beat.kind,
      speaker: beat.kind === "narracion" ? null : beat.speaker,
      text: beat.text,
    });
  }

  const minutes = result.reloj.minutos || (meta.mode === "aliento" ? 20 : 8);
  let minute = campaign.clock.minute + minutes;
  let day = campaign.clock.day;
  while (minute >= 1440) {
    minute -= 1440;
    day += 1;
  }

  const memories: Memory[] = [
    ...campaign.memories,
    ...result.memorias.map((memory) => ({
      id: uid(),
      at: now,
      summary: memory.resumen,
      importance: memory.importancia,
      who: memory.quienes,
    })),
  ];

  const chronicle: Chronicle[] = [
    ...campaign.chronicle,
    ...result.fueraDeEscena.map((event) => ({
      id: uid(),
      at: now,
      summary: event.resumen,
      who: event.quienes,
      seen: false,
    })),
  ].slice(-40);

  return {
    ...campaign,
    updatedAt: now,
    places,
    cast,
    clock: {
      day,
      minute,
      label: result.reloj.etiqueta || campaign.clock.label,
    },
    scene: {
      place: scenePlace,
      atmosphere: result.escena.atmosfera || campaign.scene.atmosphere,
      summary: result.escena.resumen || campaign.scene.summary,
      present,
    },
    threads: result.hilos.length > 0 ? result.hilos : campaign.threads,
    entries: capEntries(entries),
    memories: capMemories(memories),
    chronicle,
    undo: snapshot(campaign),
  };
}

export function restoreUndo(campaign: Campaign): Campaign | null {
  if (!campaign.undo) return null;
  return { ...campaign.undo, undo: null, updatedAt: Date.now() };
}

export function addManualMemory(campaign: Campaign, summary: string): Campaign {
  const text = summary.trim();
  if (!text) return campaign;
  return {
    ...campaign,
    updatedAt: Date.now(),
    memories: capMemories([
      ...campaign.memories,
      { id: uid(), at: Date.now(), summary: text.slice(0, 280), importance: 3, who: [] },
    ]),
  };
}

export function markChronicleSeen(campaign: Campaign): Campaign {
  if (!campaign.chronicle.some((event) => !event.seen)) return campaign;
  return {
    ...campaign,
    chronicle: campaign.chronicle.map((event) => ({ ...event, seen: true })),
  };
}
