import { useEffect, useState } from "react";
import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Campaign } from "./types.ts";

type ForgeState = {
  campaigns: Campaign[];
  upsert: (campaign: Campaign) => void;
  remove: (id: string) => void;
};

export const useForge = create<ForgeState>()(
  persist(
    (set) => ({
      campaigns: [],
      upsert: (campaign) =>
        set((state) => {
          const exists = state.campaigns.some((item) => item.id === campaign.id);
          return {
            campaigns: exists
              ? state.campaigns.map((item) => (item.id === campaign.id ? campaign : item))
              : [campaign, ...state.campaigns],
          };
        }),
      remove: (id) => set((state) => ({ campaigns: state.campaigns.filter((item) => item.id !== id) })),
    }),
    { name: "roleforge.v1", version: 1 },
  ),
);

export function useHydrated(): boolean {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    if (useForge.persist.hasHydrated()) {
      setReady(true);
      return;
    }
    return useForge.persist.onFinishHydration(() => setReady(true));
  }, []);
  return ready;
}
