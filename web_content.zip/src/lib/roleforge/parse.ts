import type { Beat, ForgeSuggestion, NarrationResult } from "./types.ts";
import { clamp } from "./text.ts";

function asRecord(value: unknown): Record<string, unknown> {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    return value as Record<string, unknown>;
  }
  return {};
}

function asArray(value: unknown): unknown[] {
  return Array.isArray(value) ? value : [];
}

function str(value: unknown): string {
  if (typeof value === "string") return value.trim();
  if (typeof value === "number" && Number.isFinite(value)) return String(value);
  return "";
}

function num(value: unknown, fallback = 0): number {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim()) {
    const parsed = Number(value.replace(",", "."));
    if (Number.isFinite(parsed)) return parsed;
  }
  return fallback;
}

function kindOf(value: unknown): Beat["kind"] {
  const raw = str(value)
    .toLowerCase()
    .normalize("NFD")
    .replace(/\p{M}/gu, "");
  if (raw.startsWith("dialog") || raw === "habla" || raw === "speech") return "dialogo";
  if (raw.startsWith("aparte") || raw.startsWith("rumor") || raw.startsWith("indirect")) return "aparte";
  return "narracion";
}

function extractJson(raw: string): unknown {
  const trimmed = raw.trim().replace(/^\uFEFF/, "");
  const fenced = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const body = fenced?.[1]?.trim() ?? trimmed;
  const start = body.indexOf("{");
  const end = body.lastIndexOf("}");
  if (start === -1 || end <= start) throw new Error("sin objeto");
  return JSON.parse(body.slice(start, end + 1));
}

function beatFrom(value: unknown): Beat | null {
  const row = asRecord(value);
  const text = str(row.text ?? row.texto ?? row.content ?? row.contenido).slice(0, 1200);
  if (!text) return null;
  const kind = kindOf(row.kind ?? row.tipo ?? row.type);
  const speaker = str(row.speaker ?? row.hablante ?? row.personaje ?? row.nombre).slice(0, 80);
  if (kind === "narracion") return { kind, speaker: null, text };
  return { kind, speaker: speaker || "Alguien", text };
}

export function parseNarration(raw: string): NarrationResult | null {
  let parsed: unknown;
  try {
    parsed = extractJson(raw);
  } catch {
    return null;
  }
  const obj = asRecord(parsed);
  const escena = asRecord(obj.escena ?? obj.scene);
  const reloj = asRecord(obj.reloj ?? obj.clock);

  let beats = asArray(obj.beats ?? obj.latidos ?? obj.mensajes)
    .map(beatFrom)
    .filter((beat): beat is Beat => beat !== null)
    .slice(0, 6);

  const prosa = str(obj.prosa ?? obj.narracion ?? obj.texto);
  if (beats.length === 0 && prosa) {
    beats = [{ kind: "narracion", speaker: null, text: prosa.slice(0, 1200) }];
  }

  const personajes = asArray(obj.personajes ?? obj.characters)
    .map((item) => {
      const row = asRecord(item);
      const nombre = str(row.nombre ?? row.name).slice(0, 80);
      if (!nombre) return null;
      return {
        nombre,
        animo: str(row.animo ?? row.mood).slice(0, 80),
        lugar: str(row.lugar ?? row.place ?? row.location).slice(0, 80),
        agenda: str(row.agenda).slice(0, 240),
        opinion: clamp(Math.round(num(row.opinion ?? row.opinionDelta ?? row.delta)), -2, 2),
        conocimiento: str(row.conocimiento ?? row.knowledge).slice(0, 240),
        vinculo: str(row.vinculo ?? row.bond).slice(0, 240),
        motivo: str(row.motivo ?? row.goal).slice(0, 240),
      };
    })
    .filter((item): item is NonNullable<typeof item> => item !== null)
    .slice(0, 12);

  const memorias = asArray(obj.memorias ?? obj.memories)
    .map((item) => {
      const row = asRecord(item);
      const resumen = str(row.resumen ?? row.summary ?? row.texto).slice(0, 280);
      if (!resumen) return null;
      return {
        resumen,
        importancia: clamp(Math.round(num(row.importancia ?? row.importance, 2)), 1, 3),
        quienes: asArray(row.quienes ?? row.who).map((name) => str(name)).filter(Boolean).slice(0, 6),
      };
    })
    .filter((item): item is NonNullable<typeof item> => item !== null)
    .slice(0, 4);

  const fueraDeEscena = asArray(obj.fueraDeEscena ?? obj.fuera_de_escena ?? obj.offscreen)
    .map((item) => {
      const row = asRecord(item);
      const resumen = str(row.resumen ?? row.summary ?? row.texto).slice(0, 280);
      if (!resumen) return null;
      return {
        resumen,
        quienes: asArray(row.quienes ?? row.who).map((name) => str(name)).filter(Boolean).slice(0, 6),
      };
    })
    .filter((item): item is NonNullable<typeof item> => item !== null)
    .slice(0, 3);

  const hilos = asArray(obj.hilos ?? obj.threads)
    .map((item) => str(item).slice(0, 160))
    .filter(Boolean)
    .slice(0, 6);

  const lugaresNuevos = asArray(obj.lugaresNuevos ?? obj.lugares_nuevos)
    .map((item) => {
      const row = asRecord(item);
      const nombre = str(row.nombre ?? row.name).slice(0, 80);
      if (!nombre) return null;
      return { nombre, nota: str(row.nota ?? row.note).slice(0, 200) };
    })
    .filter((item): item is NonNullable<typeof item> => item !== null)
    .slice(0, 4);

  return {
    beats,
    escena: {
      lugar: str(escena.lugar ?? escena.place ?? escena.location).slice(0, 80),
      atmosfera: str(escena.atmosfera ?? escena.atmosphere).slice(0, 180),
      resumen: str(escena.resumen ?? escena.summary).slice(0, 320),
      presentes: asArray(escena.presentes ?? escena.present)
        .map((name) => str(name).slice(0, 80))
        .filter(Boolean)
        .slice(0, 10),
    },
    reloj: {
      minutos: clamp(Math.round(num(reloj.minutos ?? reloj.minutes, 10)), 0, 180),
      etiqueta: str(reloj.etiqueta ?? reloj.label).slice(0, 80),
    },
    personajes,
    memorias,
    fueraDeEscena,
    hilos,
    lugaresNuevos,
  };
}

export function parseSuggestion(raw: string): ForgeSuggestion | null {
  let parsed: unknown;
  try {
    parsed = extractJson(raw);
  } catch {
    return null;
  }
  const obj = asRecord(parsed);
  const lugares = asArray(obj.lugares ?? obj.places)
    .map((item) => {
      const row = asRecord(item);
      const nombre = str(row.nombre ?? row.name).slice(0, 80);
      if (!nombre) return null;
      return { nombre, nota: str(row.nota ?? row.note).slice(0, 200) };
    })
    .filter((item): item is NonNullable<typeof item> => item !== null)
    .slice(0, 4);

  const reparto = asArray(obj.reparto ?? obj.personajes ?? obj.characters)
    .map((item) => {
      const row = asRecord(item);
      const nombre = str(row.nombre ?? row.name).slice(0, 80);
      if (!nombre) return null;
      return {
        nombre,
        rol: str(row.rol ?? row.role).slice(0, 80),
        apariencia: str(row.apariencia ?? row.appearance).slice(0, 240),
        personalidad: str(row.personalidad ?? row.personality).slice(0, 240),
        voz: str(row.voz ?? row.voice).slice(0, 160),
        conocimientos: str(row.conocimientos ?? row.knowledge).slice(0, 240),
        motivaciones: str(row.motivaciones ?? row.motivations).slice(0, 240),
        limites: str(row.limites ?? row.limits).slice(0, 200),
        objetivo: str(row.objetivo ?? row.goal).slice(0, 200),
        secreto: str(row.secreto ?? row.secret).slice(0, 200),
        lugar: str(row.lugar ?? row.place).slice(0, 80),
      };
    })
    .filter((item): item is NonNullable<typeof item> => item !== null)
    .slice(0, 4);

  if (reparto.length === 0 && lugares.length === 0) return null;
  return {
    titulo: str(obj.titulo ?? obj.title).slice(0, 80),
    lugares,
    reparto,
  };
}
