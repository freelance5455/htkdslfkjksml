import type { DesignConfig, Project, QuestionScene } from "@/types";

export interface RenderAssets {
  images: Map<string, HTMLImageElement>;
}

const clamp = (value: number, min = 0, max = 1) => Math.min(max, Math.max(min, value));
const easeOut = (t: number) => 1 - Math.pow(1 - clamp(t), 3);

export function toArabicDigits(value: string | number): string {
  const map = ["٠", "١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩"];
  return String(value).replace(/\d/g, (d) => map[Number(d)]);
}

function withAlpha(color: string, alpha: number): string {
  const clean = color.trim();
  if (/^#[0-9a-f]{6}$/i.test(clean)) {
    const r = parseInt(clean.slice(1, 3), 16);
    const g = parseInt(clean.slice(3, 5), 16);
    const b = parseInt(clean.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${clamp(alpha)})`;
  }
  if (/^#[0-9a-f]{3}$/i.test(clean)) {
    const r = parseInt(clean[1] + clean[1], 16);
    const g = parseInt(clean[2] + clean[2], 16);
    const b = parseInt(clean[3] + clean[3], 16);
    return `rgba(${r}, ${g}, ${b}, ${clamp(alpha)})`;
  }
  return clean;
}

function contrastText(color: string): string {
  if (!/^#[0-9a-f]{6}$/i.test(color)) return "#ffffff";
  const r = parseInt(color.slice(1, 3), 16) / 255;
  const g = parseInt(color.slice(3, 5), 16) / 255;
  const b = parseInt(color.slice(5, 7), 16) / 255;
  const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  return lum > 0.55 ? "#062015" : "#ffffff";
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const radius = Math.max(0, Math.min(r, w / 2, h / 2));
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
}

function setFont(ctx: CanvasRenderingContext2D, size: number, weight: number, font: string) {
  ctx.font = `${weight} ${size}px "${font}", "IBM Plex Sans Arabic", "Segoe UI", sans-serif`;
}

function wrapText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] {
  const clean = (text || "").trim();
  if (!clean) return [""];
  const words = clean.split(/\s+/);
  const lines: string[] = [];
  let line = "";
  for (const word of words) {
    const test = line ? `${line} ${word}` : word;
    if (ctx.measureText(test).width > maxWidth && line) {
      lines.push(line);
      line = word;
    } else {
      line = test;
    }
  }
  if (line) lines.push(line);
  return lines.slice(0, 8);
}

function lineHeightFor(size: number, factor: number) {
  return size * (factor || 1.35);
}

function drawCover(ctx: CanvasRenderingContext2D, image: HTMLImageElement, x: number, y: number, w: number, h: number) {
  const scale = Math.max(w / image.naturalWidth, h / image.naturalHeight);
  const iw = image.naturalWidth * scale;
  const ih = image.naturalHeight * scale;
  ctx.drawImage(image, x + (w - iw) / 2, y + (h - ih) / 2, iw, ih);
}

function drawBackground(
  ctx: CanvasRenderingContext2D,
  design: DesignConfig,
  scene: QuestionScene,
  assets: RenderAssets,
  width: number,
  height: number,
) {
  const bg = design.background;
  ctx.fillStyle = bg.kind === "color" ? bg.colorA : "#0a0a0d";
  ctx.fillRect(0, 0, width, height);

  if (bg.kind === "gradient") {
    const angle = ((bg.angle || 155) * Math.PI) / 180;
    const dx = Math.cos(angle) * width;
    const dy = Math.sin(angle) * height;
    const gradient = ctx.createLinearGradient(
      width / 2 - dx / 2,
      height / 2 - dy / 2,
      width / 2 + dx / 2,
      height / 2 + dy / 2,
    );
    gradient.addColorStop(0, bg.colorA);
    gradient.addColorStop(1, bg.colorB);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
  }

  const image = scene.question.imageId ? assets.images.get(scene.question.imageId) : bg.imageId ? assets.images.get(bg.imageId) : undefined;
  if (image) {
    drawCover(ctx, image, 0, 0, width, height);
    ctx.fillStyle = `rgba(4, 5, 8, ${clamp((bg.overlay ?? 55) / 100, 0.1, 0.92)})`;
    ctx.fillRect(0, 0, width, height);
  }

  if (bg.glow) {
    const gold = ctx.createRadialGradient(width * 0.82, height * 0.06, 0, width * 0.82, height * 0.06, width * 0.8);
    gold.addColorStop(0, "rgba(217, 182, 90, 0.17)");
    gold.addColorStop(0.5, "rgba(217, 182, 90, 0.04)");
    gold.addColorStop(1, "rgba(217, 182, 90, 0)");
    ctx.fillStyle = gold;
    ctx.fillRect(0, 0, width, height);
    const mint = ctx.createRadialGradient(width * 0.12, height * 0.92, 0, width * 0.12, height * 0.92, width * 0.75);
    mint.addColorStop(0, "rgba(87, 220, 150, 0.09)");
    mint.addColorStop(1, "rgba(87, 220, 150, 0)");
    ctx.fillStyle = mint;
    ctx.fillRect(0, 0, width, height);
  }

  if (bg.grid) {
    const step = Math.max(28, Math.min(width, height) / 22);
    ctx.strokeStyle = "rgba(255,255,255,0.026)";
    ctx.lineWidth = 1;
    for (let x = step; x < width; x += step) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = step; y < height; y += step) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }
  }

  const vignette = ctx.createRadialGradient(width / 2, height * 0.45, Math.min(width, height) * 0.3, width / 2, height * 0.45, Math.max(width, height) * 0.78);
  vignette.addColorStop(0, "rgba(0,0,0,0)");
  vignette.addColorStop(1, "rgba(0,0,0,0.5)");
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, width, height);
}

function drawBrand(
  ctx: CanvasRenderingContext2D,
  project: Project,
  scene: QuestionScene,
  assets: RenderAssets,
  width: number,
  height: number,
  progress: number,
  local: number,
) {
  const s = Math.min(width, height) / 1080;
  const design = project.design;
  const margin = width * 0.055;
  const top = height * 0.042;
  const logo = design.brand.logoId ? assets.images.get(design.brand.logoId) : undefined;
  if (logo) {
    const box = 46 * s;
    ctx.save();
    ctx.globalAlpha = clamp(design.brand.opacity / 100, 0.2, 1);
    roundRect(ctx, width - margin - box, top, box, box, 12 * s);
    ctx.clip();
    drawCover(ctx, logo, width - margin - box, top, box, box);
    ctx.restore();
  } else {
    const box = 40 * s;
    const x = width - margin - box;
    roundRect(ctx, x, top, box, box, 12 * s);
    const mark = ctx.createLinearGradient(x, top, x + box, top + box);
    mark.addColorStop(0, "#f4e5b8");
    mark.addColorStop(1, "#c49b3d");
    ctx.fillStyle = mark;
    ctx.fill();
    ctx.fillStyle = "#161205";
    setFont(ctx, 22 * s, 800, "Tajawal");
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("Q", x + box / 2, top + box / 2 + 1 * s);
  }
  if (design.brand.show) {
    ctx.save();
    ctx.globalAlpha = clamp(design.brand.opacity / 100, 0.2, 1);
    ctx.textAlign = "right";
    ctx.textBaseline = "middle";
    ctx.fillStyle = "#e8e4d9";
    setFont(ctx, 22 * s, 700, design.typography.font);
    ctx.fillText(design.brand.text || project.name, width - margin - (logo ? 58 : 52) * s, top + (logo ? 23 : 20) * s);
    ctx.fillStyle = "rgba(255,255,255,0.4)";
    setFont(ctx, 13 * s, 400, design.typography.font);
    ctx.fillText(`السؤال ${toArabicDigits(scene.index + 1)} من ${toArabicDigits(project.questions.length)}`, width - margin, top + 48 * s);
    ctx.restore();
  }

  if (design.brand.showProgress) {
    const y = height * 0.026;
    const barWidth = width - margin * 2;
    ctx.fillStyle = "rgba(255,255,255,0.09)";
    roundRect(ctx, margin, y, barWidth, 3 * s, 3 * s);
    ctx.fill();
    ctx.fillStyle = "rgba(217,182,90,0.8)";
    roundRect(ctx, width - margin - barWidth * clamp(progress), y, Math.max(2, barWidth * clamp(progress)), 3 * s, 3 * s);
    ctx.fill();
  }

  if (local >= scene.timings.revealStart - 0.1) {
    const e = easeOut((local - scene.timings.revealStart + 0.1) / 0.35);
    const label = scene.question.options[scene.question.correct] || "الإجابة الصحيحة";
    ctx.save();
    ctx.globalAlpha *= e;
    setFont(ctx, 19 * s, 600, design.typography.font);
    const pillW = Math.min(width - margin * 2, Math.max(180 * s, ctx.measureText(label).width + 108 * s));
    const pillH = 38 * s;
    const x = width / 2 - pillW / 2;
    const y = top + 6 * s;
    roundRect(ctx, x, y, pillW, pillH, 99);
    ctx.fillStyle = withAlpha(design.options.correctColor, 0.14);
    ctx.fill();
    ctx.strokeStyle = withAlpha(design.options.correctColor, 0.45);
    ctx.lineWidth = 1 * s;
    ctx.stroke();
    ctx.fillStyle = design.options.correctColor;
    ctx.beginPath();
    ctx.arc(x + 22 * s, y + pillH / 2, 8 * s, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#062015";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    setFont(ctx, 11 * s, 800, "Tajawal");
    ctx.fillText("✓", x + 22 * s, y + pillH / 2 + 0.5);
    ctx.fillStyle = design.options.correctColor;
    setFont(ctx, 17 * s, 600, design.typography.font);
    ctx.fillText(label, x + pillW - 22 * s, y + pillH / 2 + 1, pillW - 52 * s);
    ctx.restore();
  }
}

function optionLetter(design: DesignConfig, index: number): string {
  const styles = {
    arabic: ["أ", "ب", "ج", "د"],
    latin: ["A", "B", "C", "D"],
    numbers: ["1", "2", "3", "4"],
    none: ["", "", "", ""],
  } as const;
  return styles[design.options.letters][index] ?? "";
}

function drawOptions(
  ctx: CanvasRenderingContext2D,
  project: Project,
  scene: QuestionScene,
  local: number,
  x: number,
  top: number,
  width: number,
  s: number,
  maxHeight: number,
) {
  const design = project.design;
  const options = design.options;
  const typo = design.typography;
  const gap = Math.max(6, options.gap) * s;
  const landscape = project.exportSettings.width > project.exportSettings.height * 1.2;
  const columns = landscape ? 2 : 1;
  const cardW = columns === 2 ? (width - gap) / 2 : width;
  const fontSize = Math.max(18, typo.optionSize) * s;
  const padding = Math.max(10, options.padding) * s;
  const letterSize = fontSize * 1.35;
  const textWidth = cardW - padding * 2 - (options.letters === "none" ? 0 : letterSize + 14 * s);
  ctx.textAlign = typo.align === "center" ? "center" : "right";
  setFont(ctx, fontSize, typo.optionWeight, typo.font);
  const wrapped = scene.question.options.map((text) => {
    ctx.textAlign = "right";
    setFont(ctx, fontSize, typo.optionWeight, typo.font);
    return wrapText(ctx, text || "الخيار", textWidth).slice(0, 3);
  });
  const heights = wrapped.map((lines) => Math.max(64 * s, lines.length * lineHeightFor(fontSize, 1.3) + padding * 1.35));
  const rowHeights = columns === 2
    ? [Math.max(heights[0], heights[1]), Math.max(heights[2], heights[3])]
    : heights;
  const totalHeight = rowHeights.reduce((total, h) => total + h, 0) + gap * (rowHeights.length - 1);
  if (totalHeight > maxHeight) {
    ctx.save();
  }
  const reveal = local >= scene.timings.revealStart;
  const revealT = reveal ? easeOut((local - scene.timings.revealStart) / Math.max(0.2, 0.5 / design.motion.speed)) : 0;
  const boxes: { x: number; y: number; w: number; h: number }[] = [];
  let cursorY = top;
  let cardIndex = 0;
  for (let row = 0; row < (columns === 2 ? 2 : 4); row++) {
    const rowHeight = rowHeights[row];
    const rowCount = columns === 2 ? 2 : 1;
    for (let col = 0; col < rowCount; col++) {
      const index = row * rowCount + col;
      const appearDelay = design.motion.entrance === "none" ? 0 : index * (0.16 / Math.max(0.5, design.motion.speed));
      const appearAt = scene.timings.optionsStart + appearDelay;
      let appear = local < appearAt ? 0 : easeOut((local - appearAt) / (0.45 / Math.max(0.5, design.motion.speed)));
      if (reveal) appear = 1;
      const rtlCol = columns === 2 ? (col === 0 ? 1 : 0) : 0;
      const cardX = x + rtlCol * (cardW + gap);
      const slideOffset = design.motion.entrance === "slide" ? (1 - appear) * 40 * s : design.motion.entrance === "rise" ? (1 - appear) * 26 * s : 0;
      const scale = design.motion.entrance === "zoom" ? 0.96 + 0.04 * appear : 1;
      const cardY = cursorY + slideOffset;
      const cardH = rowHeight;
      const correct = questionCorrectIndex(scene);
      const isCorrect = index === correct;
      const dimmed = reveal && !isCorrect;
      ctx.save();
      ctx.globalAlpha *= appear * (dimmed ? clamp(options.dimOpacity / 100, 0.12, 1) : 1);
      const cx = cardX + cardW / 2;
      const cy = cardY + cardH / 2;
      ctx.translate(cx, cy);
      ctx.scale(scale, scale);
      ctx.translate(-cx, -cy);
      if (isCorrect && reveal) {
        ctx.shadowColor = withAlpha(options.correctColor, 0.75);
        ctx.shadowBlur = (18 + Math.sin(revealT * Math.PI) * 20) * s * (design.motion.reveal === "glow" ? 1 : 0.2);
      } else if (options.shadow) {
        ctx.shadowColor = "rgba(0,0,0,0.4)";
        ctx.shadowBlur = 22 * s;
        ctx.shadowOffsetY = 8 * s;
      }
      roundRect(ctx, cardX, cardY, cardW, cardH, options.radius * s);
      if (isCorrect && reveal) {
        const fill = ctx.createLinearGradient(cardX, cardY, cardX + cardW, cardY + cardH);
        fill.addColorStop(0, withAlpha(options.correctColor, 0.95));
        fill.addColorStop(1, withAlpha(options.correctColor, 0.72));
        ctx.fillStyle = fill;
      } else {
        ctx.fillStyle = withAlpha(options.fill, clamp(options.fillOpacity / 100, 0, 0.8));
      }
      ctx.fill();
      ctx.shadowColor = "transparent";
      ctx.shadowBlur = 0;
      ctx.shadowOffsetY = 0;
      const borderColor = isCorrect && reveal ? options.correctColor : withAlpha(options.borderColor, isCorrect && reveal ? 0.8 : 0.13);
      ctx.strokeStyle = borderColor;
      ctx.lineWidth = Math.max(1, options.borderWidth * s);
      ctx.stroke();

      if (isCorrect && reveal && design.motion.reveal === "pulse") {
        ctx.strokeStyle = withAlpha(options.correctColor, 0.45 * (1 - revealT));
        ctx.lineWidth = 2 * s;
        ctx.beginPath();
        ctx.roundRect(cardX - 8 * s * revealT, cardY - 8 * s * revealT, cardW + 16 * s * revealT, cardH + 16 * s * revealT, (options.radius + 8) * s);
        ctx.stroke();
      }

      const textColor = isCorrect && reveal ? contrastText(options.correctColor) : typo.optionColor;
      const showLetter = options.letters !== "none";
      let textX = cardX + cardW - padding;
      if (showLetter) {
        const bx = cardX + cardW - padding - letterSize / 2;
        const by = cardY + cardH / 2;
        ctx.beginPath();
        ctx.arc(bx, by, letterSize / 2, 0, Math.PI * 2);
        ctx.fillStyle = isCorrect && reveal ? "rgba(0,0,0,0.18)" : "rgba(255,255,255,0.075)";
        ctx.fill();
        ctx.strokeStyle = isCorrect && reveal ? "rgba(0,0,0,0.22)" : "rgba(255,255,255,0.11)";
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.fillStyle = isCorrect && reveal ? contrastText(options.correctColor) : "#e7cf94";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        setFont(ctx, fontSize * 0.82, 700, design.typography.font);
        ctx.fillText(isCorrect && reveal && options.showCheck ? "✓" : optionLetter(design, index), bx, by + 1);
        textX = bx - letterSize / 2 - 14 * s;
      }
      ctx.fillStyle = textColor;
      ctx.textBaseline = "middle";
      setFont(ctx, fontSize, typo.optionWeight, typo.font);
      const lines = wrapped[index];
      const startY = cardY + cardH / 2 - ((lines.length - 1) * lineHeightFor(fontSize, 1.3)) / 2;
      lines.forEach((line, lineIndex) => {
        if (typo.align === "center" && !showLetter) {
          ctx.textAlign = "center";
          ctx.fillText(line, cardX + cardW / 2, startY + lineIndex * lineHeightFor(fontSize, 1.3));
        } else {
          ctx.textAlign = "right";
          ctx.fillText(line, textX, startY + lineIndex * lineHeightFor(fontSize, 1.3));
        }
      });
      ctx.restore();
      boxes.push({ x: cardX, y: cardY, w: cardW, h: cardH });
      cardIndex++;
    }
    cursorY += rowHeight + gap;
  }
  if (totalHeight > maxHeight) ctx.restore();
  return totalHeight;
}

function questionCorrectIndex(scene: QuestionScene): number {
  return scene.question.correct >= 0 && scene.question.correct < 4 ? scene.question.correct : -1;
}

function drawQuestion(
  ctx: CanvasRenderingContext2D,
  project: Project,
  scene: QuestionScene,
  local: number,
  x: number,
  top: number,
  width: number,
  s: number,
  maxHeight: number,
) {
  const design = project.design;
  const typo = design.typography;
  const padding = 26 * s;
  let size = Math.max(26, typo.questionSize) * s;
  const maxTextWidth = width - padding * 2;
  let lines: string[] = [];
  for (let attempt = 0; attempt < 9; attempt++) {
    setFont(ctx, size, typo.questionWeight, typo.font);
    ctx.textAlign = "right";
    lines = wrapText(ctx, scene.question.question || "أضف نص السؤال من محرر الأسئلة", maxTextWidth);
    const height = lines.length * lineHeightFor(size, typo.lineHeight);
    if (height <= maxHeight - 54 * s || size <= 30 * s) break;
    size -= 4 * s;
  }
  const textHeight = lines.length * lineHeightFor(size, typo.lineHeight);
  const cardHeight = textHeight + padding * 2 + 44 * s;
  const appear = easeOut((local - 0.02) / (0.5 / Math.max(0.5, design.motion.speed)));
  ctx.save();
  ctx.globalAlpha *= clamp(appear);
  if (design.content.showCard) {
    ctx.save();
    ctx.shadowColor = "rgba(0,0,0,0.35)";
    ctx.shadowBlur = 40 * s;
    ctx.shadowOffsetY = 16 * s;
    roundRect(ctx, x, top, width, cardHeight, 28 * s);
    const cardFill = ctx.createLinearGradient(x, top, x, top + cardHeight);
    cardFill.addColorStop(0, "rgba(255,255,255,0.075)");
    cardFill.addColorStop(1, "rgba(255,255,255,0.028)");
    ctx.fillStyle = cardFill;
    ctx.fill();
    ctx.shadowColor = "transparent";
    ctx.strokeStyle = "rgba(255,255,255,0.12)";
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.restore();
  }
  let headerY = top + (design.content.showCard ? padding + 6 * s : 12 * s);
  if (design.content.showQuestionNumber) {
    const chipLabel = `السؤال ${toArabicDigits(scene.index + 1)}`;
    setFont(ctx, 15 * s, 600, typo.font);
    const chipW = ctx.measureText(chipLabel).width + 34 * s;
    roundRect(ctx, x + width - padding - chipW, headerY - 12 * s, chipW, 26 * s, 99);
    ctx.fillStyle = "rgba(217,182,90,0.12)";
    ctx.fill();
    ctx.strokeStyle = "rgba(217,182,90,0.28)";
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.fillStyle = "#e7cf94";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(chipLabel, x + width - padding - chipW / 2, headerY + 1 * s);
    ctx.strokeStyle = "rgba(255,255,255,0.1)";
    ctx.beginPath();
    ctx.moveTo(x + padding, headerY);
    ctx.lineTo(x + width - padding - chipW - 16 * s, headerY);
    ctx.stroke();
    headerY += 34 * s;
  }
  ctx.fillStyle = typo.questionColor;
  ctx.textBaseline = "middle";
  setFont(ctx, size, typo.questionWeight, typo.font);
  lines.forEach((line, index) => {
    ctx.textAlign = typo.align === "center" ? "center" : "right";
    const lineX = typo.align === "center" ? x + width / 2 : x + width - padding;
    ctx.fillText(line, lineX, headerY + size * 0.6 + index * lineHeightFor(size, typo.lineHeight));
  });
  ctx.restore();
  return cardHeight;
}

function drawTimer(
  ctx: CanvasRenderingContext2D,
  project: Project,
  scene: QuestionScene,
  local: number,
  width: number,
  height: number,
  s: number,
) {
  const design = project.design;
  const timer = design.timer;
  if (!timer.visible) return;
  const reveal = local >= scene.timings.revealStart;
  const thinking = local >= scene.timings.thinkingStart;
  if (!thinking && !reveal) return;
  const think = Math.max(0.5, scene.timings.revealStart - scene.timings.thinkingStart);
  const elapsed = Math.max(0, local - scene.timings.thinkingStart);
  const remaining = Math.max(0, think - elapsed);
  const p = clamp(1 - remaining / think);
  const x = (timer.x / 100) * width;
  const y = (timer.y / 100) * height;
  const color = reveal ? project.design.options.correctColor : timer.color;
  ctx.save();
  ctx.translate(x, y);
  if (timer.style === "ring") {
    const radius = Math.max(30, timer.size / 2) * s;
    ctx.beginPath();
    ctx.arc(0, 0, radius, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(8,9,12,0.72)";
    ctx.fill();
    ctx.lineWidth = Math.max(4, 7 * s);
    ctx.strokeStyle = timer.trackColor;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(0, 0, radius, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * (1 - p));
    ctx.strokeStyle = color;
    ctx.lineCap = "round";
    ctx.stroke();
    ctx.fillStyle = reveal ? color : "#f3efe3";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    if (reveal) {
      setFont(ctx, radius * 0.9, 800, design.typography.font);
      ctx.fillText("✓", 0, 2 * s);
    } else {
      setFont(ctx, radius * 0.72, 700, design.typography.font);
      ctx.fillText(toArabicDigits(Math.ceil(remaining)), 0, 1 * s);
      setFont(ctx, 11 * s, 400, design.typography.font);
      ctx.fillStyle = "rgba(255,255,255,0.45)";
      ctx.fillText("ثانية", 0, radius * 0.52);
    }
  } else if (timer.style === "bar") {
    const barWidth = Math.max(200, timer.size * 3) * s;
    roundRect(ctx, -barWidth / 2, -8 * s, barWidth, 8 * s, 99);
    ctx.fillStyle = "rgba(255,255,255,0.12)";
    ctx.fill();
    roundRect(ctx, -barWidth / 2, -8 * s, barWidth * (1 - p), 8 * s, 99);
    ctx.fillStyle = color;
    ctx.fill();
    ctx.fillStyle = "#f3efe3";
    ctx.textAlign = "center";
    setFont(ctx, 15 * s, 600, design.typography.font);
    ctx.fillText(reveal ? "الإجابة الصحيحة ✓" : `متبقي ${toArabicDigits(Math.ceil(remaining))} ثوانٍ`, 0, -22 * s);
  } else {
    const label = reveal ? "الإجابة الصحيحة" : `متبقي ${toArabicDigits(Math.ceil(remaining))} ث`;
    setFont(ctx, 20 * s, 600, design.typography.font);
    const pillW = Math.max(140 * s, ctx.measureText(label).width + 64 * s);
    roundRect(ctx, -pillW / 2, -28 * s, pillW, 56 * s, 99);
    ctx.fillStyle = "rgba(8,9,12,0.75)";
    ctx.fill();
    ctx.strokeStyle = withAlpha(color, 0.45);
    ctx.lineWidth = 1.5 * s;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(-pillW / 2 + 26 * s, 0, 5 * s, 0, Math.PI * 2);
    ctx.fillStyle = color;
    ctx.fill();
    ctx.fillStyle = "#f5f1e6";
    ctx.textAlign = "center";
    setFont(ctx, 18 * s, 600, design.typography.font);
    ctx.fillText(label, 10 * s, 1 * s);
  }
  ctx.restore();
}

function drawFooter(ctx: CanvasRenderingContext2D, project: Project, width: number, height: number, s: number) {
  ctx.save();
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillStyle = "rgba(255,255,255,0.3)";
  setFont(ctx, 14 * s, 400, project.design.typography.font);
  const text = project.design.brand.show ? project.name : "";
  if (text) ctx.fillText(text, width / 2, height - 28 * s);
  ctx.restore();
}

export function renderFrame(
  ctx: CanvasRenderingContext2D,
  project: Project,
  scene: QuestionScene,
  assets: RenderAssets,
  globalTime: number,
  width: number,
  height: number,
) {
  const local = Math.max(0, globalTime - scene.timings.start);
  const s = Math.min(width, height) / 1080;
  const design = project.design;
  const progress = project.questions.length
    ? (scene.index + clamp(local / Math.max(0.3, scene.timings.duration))) / project.questions.length
    : 0;

  ctx.save();
  ctx.clearRect(0, 0, width, height);
  const fadeIn = 0.4 / Math.max(0.5, design.motion.speed);
  const fadeOut = 0.3 / Math.max(0.5, design.motion.speed);
  let alpha = 1;
  let dx = 0;
  let zoom = 1;
  if (design.motion.transition !== "none") {
    if (local < fadeIn) {
      const p = easeOut(local / fadeIn);
      alpha = p;
      if (design.motion.transition === "slide") dx = (1 - p) * -80 * s;
      if (design.motion.transition === "zoom") zoom = 0.94 + 0.06 * p;
    }
    if (scene.timings.duration - local < fadeOut) {
      const p = clamp((scene.timings.duration - local) / fadeOut);
      alpha *= p;
      if (design.motion.transition === "slide") dx = (1 - p) * 80 * s;
      if (design.motion.transition === "zoom") zoom = 0.94 + 0.06 * p;
    }
  }
  ctx.globalAlpha = alpha;
  ctx.translate(width / 2 + dx, height / 2);
  ctx.scale(zoom, zoom);
  ctx.translate(-width / 2, -height / 2);

  drawBackground(ctx, design, scene, assets, width, height);
  drawBrand(ctx, project, scene, assets, width, height, progress, local);

  const contentWidth = Math.min(width * (design.content.width / 100), width * 0.9);
  const cx = (design.content.x / 100) * width;
  const cy = (design.content.y / 100) * height;
  const x = cx - contentWidth / 2;
  const landscape = width > height * 1.2;
  const maxQuestionHeight = Math.min(height * (landscape ? 0.3 : 0.36), 420 * s);
  const timerSpace = design.timer.visible ? 100 * s : 30 * s;
  const maxOptionsHeight = Math.max(140 * s, Math.min(height * 0.56, height - cy - timerSpace + height * 0.18));
  const measureCtx = ctx;
  let qsize = Math.max(26, design.typography.questionSize) * s;
  measureCtx.textAlign = "right";
  setFont(measureCtx, qsize, design.typography.questionWeight, design.typography.font);
  let qlines = wrapText(measureCtx, scene.question.question || "أضف نص السؤال من محرر الأسئلة", contentWidth - 52 * s);
  for (let i = 0; i < 9; i++) {
    if (qlines.length * lineHeightFor(qsize, design.typography.lineHeight) <= maxQuestionHeight - 54 * s || qsize <= 30 * s) break;
    qsize -= 4 * s;
    setFont(measureCtx, qsize, design.typography.questionWeight, design.typography.font);
    qlines = wrapText(measureCtx, scene.question.question || "أضف نص السؤال من محرر الأسئلة", contentWidth - 52 * s);
  }
  const questionCardHeight = design.content.showCard
    ? qlines.length * lineHeightFor(qsize, design.typography.lineHeight) + 52 * s + 44 * s
    : qlines.length * lineHeightFor(qsize, design.typography.lineHeight) + 40 * s;

  const optionSize = Math.max(18, design.typography.optionSize) * s;
  const optionPadding = Math.max(10, design.options.padding) * s;
  setFont(ctx, optionSize, design.typography.optionWeight, design.typography.font);
  const optionTextWidth = (landscape ? (contentWidth - design.options.gap * s) / 2 : contentWidth) - optionPadding * 2 - optionSize * 1.5;
  const optionLines = scene.question.options.map((text) => wrapText(ctx, text || "الخيار", Math.max(60, optionTextWidth)).slice(0, 3));
  const heights = optionLines.map((lines) => Math.max(64 * s, lines.length * lineHeightFor(optionSize, 1.3) + optionPadding * 1.35));
  const rows = landscape ? [Math.max(heights[0], heights[1]), Math.max(heights[2], heights[3])] : heights;
  const optionsHeight = rows.reduce((total, h) => total + h, 0) + Math.max(6, design.options.gap) * s * (rows.length - 1);
  const groupGap = 26 * s;
  const totalHeight = questionCardHeight + groupGap + optionsHeight;
  let top = cy - totalHeight / 2;
  top = Math.max(height * 0.12, Math.min(height - timerSpace - totalHeight - 20 * s, top));
  drawQuestion(ctx, project, scene, local, x, top, contentWidth, s, maxQuestionHeight);
  drawOptions(ctx, project, scene, local, x, top + questionCardHeight + groupGap, contentWidth, s, maxOptionsHeight);
  drawTimer(ctx, project, scene, local, width, height, s);
  drawFooter(ctx, project, width, height, s);
  ctx.restore();
}

export function drawStaticPreview(
  canvas: HTMLCanvasElement,
  project: Project,
  scene: QuestionScene,
  assets: RenderAssets,
  atLocal: number,
) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  canvas.width = project.exportSettings.width;
  canvas.height = project.exportSettings.height;
  renderFrame(ctx, project, scene, assets, scene.timings.start + atLocal, project.exportSettings.width, project.exportSettings.height);
}
