import { jalaaliMonthLength, toGregorian, toJalaali } from "jalaali-js";

export const MONTHS = [
  "فروردین",
  "اردیبهشت",
  "خرداد",
  "تیر",
  "مرداد",
  "شهریور",
  "مهر",
  "آبان",
  "آذر",
  "دی",
  "بهمن",
  "اسفند",
] as const;

const WEEKDAYS = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"] as const;

export const BASE_HOURS = { morning: 9, evening: 8 } as const;
export const KIND_LABEL = { morning: "صبح", evening: "عصر" } as const;

export type Kind = keyof typeof BASE_HOURS;

export type Entry = {
  id: string;
  iso: string;
  kind: Kind;
  overtime: number;
  note: string;
};

export type Model = {
  entries: Entry[];
  hourlyRate: string;
  fxRate: string;
};

export const DEFAULT_HOURLY = "4.5";
export const DEFAULT_FX = "905.52";

const STORAGE_KEY = "nobat-ledger-v1";

const fmtQty = new Intl.NumberFormat("fa-IR", {
  maximumFractionDigits: 2,
  useGrouping: false,
});
const fmtInt = new Intl.NumberFormat("fa-IR", {
  maximumFractionDigits: 0,
  useGrouping: false,
});
const fmtMoney = new Intl.NumberFormat("fa-IR", {
  maximumFractionDigits: 2,
});
const fmtRial = new Intl.NumberFormat("fa-IR", {
  maximumFractionDigits: 0,
});

export function formatQty(n: number) {
  return fmtQty.format(round2(n));
}

export function formatInt(n: number) {
  return fmtInt.format(Math.round(n));
}

export function formatMoney(n: number) {
  return fmtMoney.format(round2(n));
}

export function formatRial(n: number) {
  return fmtRial.format(Math.round(n));
}

function round2(n: number) {
  return Math.round(n * 100) / 100;
}

export function normalizeDigits(input: string) {
  const persian = "۰۱۲۳۴۵۶۷۸۹";
  const arabic = "٠١٢٣٤٥٦٧٨٩";
  let value = input
    .replace(/[۰-۹]/g, (ch) => String(persian.indexOf(ch)))
    .replace(/[٠-٩]/g, (ch) => String(arabic.indexOf(ch)))
    .replace(/\s/g, "")
    .replace(/٫/g, ".");
  if (value.includes(",") && !value.includes(".")) value = value.replace(",", ".");
  return value.replace(/[,٬]/g, "");
}

export function parseAmount(input: string): number | null {
  const cleaned = normalizeDigits(input);
  if (!/^\d+(\.\d*)?$/.test(cleaned)) return null;
  const n = Number(cleaned.endsWith(".") ? cleaned.slice(0, -1) : cleaned);
  if (!Number.isFinite(n)) return null;
  return n;
}

export function todayIso() {
  const now = new Date();
  return padIso(now.getFullYear(), now.getMonth() + 1, now.getDate());
}

export function padIso(y: number, m: number, d: number) {
  return `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}

export function toJalaliParts(iso: string) {
  const [y, m, d] = iso.split("-").map(Number);
  return toJalaali(y!, m!, d!);
}

export function isoFromJalali(jy: number, jm: number, jd: number) {
  const { gy, gm, gd } = toGregorian(jy, jm, jd);
  return padIso(gy, gm, gd);
}

export function addDays(iso: string, days: number) {
  const [y, m, d] = iso.split("-").map(Number);
  const dt = new Date(Date.UTC(y!, m! - 1, d!));
  dt.setUTCDate(dt.getUTCDate() + days);
  return padIso(dt.getUTCFullYear(), dt.getUTCMonth() + 1, dt.getUTCDate());
}

export function weekdayName(iso: string) {
  const [y, m, d] = iso.split("-").map(Number);
  const day = new Date(Date.UTC(y!, m! - 1, d!)).getUTCDay();
  return WEEKDAYS[day] ?? "";
}

export function formatJalaliDate(iso: string) {
  const { jy, jm, jd } = toJalaliParts(iso);
  return `${weekdayName(iso)} ${formatInt(jd)} ${MONTHS[jm - 1]} ${formatInt(jy)}`;
}

export function shiftMonth(jy: number, jm: number, delta: number) {
  let index = jm - 1 + delta;
  let year = jy;
  while (index < 0) {
    index += 12;
    year -= 1;
  }
  while (index > 11) {
    index -= 12;
    year += 1;
  }
  return { jy: year, jm: index + 1 };
}

export function monthLength(jy: number, jm: number) {
  return jalaaliMonthLength(jy, jm);
}

export function entryHours(entry: Entry) {
  return BASE_HOURS[entry.kind] + entry.overtime;
}

export function summarize(entries: Entry[]) {
  let morningCount = 0;
  let eveningCount = 0;
  let overtime = 0;
  for (const entry of entries) {
    if (entry.kind === "morning") morningCount += 1;
    else eveningCount += 1;
    overtime += entry.overtime;
  }
  const morningHours = morningCount * BASE_HOURS.morning;
  const eveningHours = eveningCount * BASE_HOURS.evening;
  return {
    morningCount,
    eveningCount,
    morningHours,
    eveningHours,
    overtime: round2(overtime),
    totalHours: round2(morningHours + eveningHours + overtime),
    count: entries.length,
  };
}

export function income(totalHours: number, hourly: number, fx: number) {
  const iqd = totalHours * hourly;
  const irr = iqd * fx;
  return { iqd, irr, toman: irr / 10 };
}

export function inMonth(iso: string, jy: number, jm: number) {
  const j = toJalaliParts(iso);
  return j.jy === jy && j.jm === jm;
}

function isKind(value: unknown): value is Kind {
  return value === "morning" || value === "evening";
}

function isEntry(value: unknown): value is Entry {
  if (!value || typeof value !== "object") return false;
  const entry = value as Entry;
  return (
    typeof entry.id === "string" &&
    typeof entry.iso === "string" &&
    /^\d{4}-\d{2}-\d{2}$/.test(entry.iso) &&
    isKind(entry.kind) &&
    typeof entry.overtime === "number" &&
    Number.isFinite(entry.overtime) &&
    entry.overtime >= 0 &&
    typeof entry.note === "string"
  );
}

export function loadModel(): Model {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { entries: [], hourlyRate: DEFAULT_HOURLY, fxRate: DEFAULT_FX };
    const parsed = JSON.parse(raw) as Partial<Model>;
    return {
      entries: Array.isArray(parsed.entries) ? parsed.entries.filter(isEntry) : [],
      hourlyRate: typeof parsed.hourlyRate === "string" ? parsed.hourlyRate : DEFAULT_HOURLY,
      fxRate: typeof parsed.fxRate === "string" ? parsed.fxRate : DEFAULT_FX,
    };
  } catch {
    return { entries: [], hourlyRate: DEFAULT_HOURLY, fxRate: DEFAULT_FX };
  }
}

export function saveModel(model: Model) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(model));
}

export function summaryText(input: {
  title: string;
  morningCount: number;
  eveningCount: number;
  morningHours: number;
  eveningHours: number;
  overtime: number;
  totalHours: number;
  hourly: number | null;
  fx: number | null;
  iqd: number | null;
  irr: number | null;
}) {
  const lines = [
    `خلاصه کارکرد ${input.title}`,
    `شیفت صبح: ${formatInt(input.morningCount)} × ${formatInt(BASE_HOURS.morning)} = ${formatQty(input.morningHours)} ساعت`,
    `شیفت عصر: ${formatInt(input.eveningCount)} × ${formatInt(BASE_HOURS.evening)} = ${formatQty(input.eveningHours)} ساعت`,
    `اضافه‌کاری: ${formatQty(input.overtime)} ساعت`,
    `ساعت کل کارکرد: ${formatQty(input.totalHours)}`,
  ];
  if (input.hourly != null && input.iqd != null) {
    lines.push(
      `درآمد: ${formatQty(input.totalHours)} × ${formatQty(input.hourly)} = ${formatMoney(input.iqd)} دینار عراق`,
    );
  }
  if (input.fx != null && input.irr != null) {
    lines.push(
      `ریال ایران: ${formatRial(input.irr)} (هر دینار = ${formatMoney(input.fx)} ریال)`,
    );
    lines.push(`معادل تومان: ${formatRial(input.irr / 10)}`);
  }
  return lines.join("\n");
}
