// Local Storage & IndexedDB Vault Storage Manager

export interface VaultPhoto {
  id: string;
  name: string;
  url: string; // Base64 data URL
  date: string;
  size?: string;
  bytes?: number;
}

export interface VaultVideo {
  id: string;
  name: string;
  url: string;
  thumbnail?: string;
  date: string;
  size?: string;
  bytes?: number;
}

export interface VaultNote {
  id: string;
  title: string;
  content: string;
  date: string;
}

export interface RecycleItem {
  id: string;
  type: 'photo' | 'video' | 'note';
  deletedAt: number;
  data: any;
}

export interface UserSession {
  isLoggedIn: boolean;
  username: string;
  email: string;
  connected: boolean;
  loginMethod?: string;
}

export interface CloudBackupState {
  lastBackupDate: string;
  autoBackup: boolean;
  backupOwnerEmail?: string;
}

const STORAGE_KEY_PHOTOS = 'calc_vault_photos_v4';
const STORAGE_KEY_VIDEOS = 'calc_vault_videos_v4';
const STORAGE_KEY_NOTES = 'calc_vault_notes_v4';
const STORAGE_KEY_RECYCLE = 'calc_vault_recycle_v4';
const STORAGE_KEY_AUTH = 'calc_vault_auth_v4';
const STORAGE_KEY_BACKUP = 'calc_vault_backup_v4';
const STORAGE_KEY_PIN = 'calculator_pro_master_pin_v3';
const STORAGE_KEY_FIRST_OPEN = 'calculator_pro_first_time_flag_v3';

// IndexedDB for large local video blobs
const IDB_NAME = 'calc_vault_videos_db';
const IDB_STORE = 'videos';

function openIndexedDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(IDB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(IDB_STORE)) {
        db.createObjectStore(IDB_STORE);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function saveVideoBlob(id: string, file: Blob): Promise<void> {
  try {
    const db = await openIndexedDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      const store = tx.objectStore(IDB_STORE);
      const req = store.put(file, id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error('Error saving video to IndexedDB:', err);
  }
}

export async function getVideoBlob(id: string): Promise<Blob | null> {
  try {
    const db = await openIndexedDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(IDB_STORE, 'readonly');
      const store = tx.objectStore(IDB_STORE);
      const req = store.get(id);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error('Error reading video from IndexedDB:', err);
    return null;
  }
}

export async function deleteVideoBlob(id: string): Promise<void> {
  try {
    const db = await openIndexedDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      const store = tx.objectStore(IDB_STORE);
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error('Error deleting video from IndexedDB:', err);
  }
}

// Master PIN
export function getMasterPin(): string {
  try {
    return localStorage.getItem(STORAGE_KEY_PIN) || '';
  } catch {
    return '';
  }
}

export function setMasterPin(pin: string): void {
  try {
    localStorage.setItem(STORAGE_KEY_PIN, pin);
    localStorage.setItem(STORAGE_KEY_FIRST_OPEN, 'done');
  } catch (err) {
    console.error('Failed to set master pin:', err);
  }
}

export function isFirstTimeOpen(): boolean {
  try {
    const pin = getMasterPin();
    if (pin && pin.trim().length > 0) return false;
    return localStorage.getItem(STORAGE_KEY_FIRST_OPEN) !== 'done';
  } catch {
    return true;
  }
}

export function markFirstTimeOpenCompleted(): void {
  try {
    localStorage.setItem(STORAGE_KEY_FIRST_OPEN, 'done');
  } catch {
    // ignore
  }
}

// Photos
export function getLocalPhotos(): VaultPhoto[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY_PHOTOS);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function saveLocalPhotos(photos: VaultPhoto[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_PHOTOS, JSON.stringify(photos));
  } catch (e) {
    console.warn('LocalStorage quota, truncating older photos:', e);
    try {
      localStorage.setItem(STORAGE_KEY_PHOTOS, JSON.stringify(photos.slice(0, 20)));
    } catch {}
  }
}

// Videos
export function getLocalVideos(): VaultVideo[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY_VIDEOS);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function saveLocalVideos(videos: VaultVideo[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_VIDEOS, JSON.stringify(videos));
  } catch (e) {
    console.error('Failed to save videos:', e);
  }
}

// Notes
export function getLocalNotes(): VaultNote[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY_NOTES);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function saveLocalNotes(notes: VaultNote[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_NOTES, JSON.stringify(notes));
  } catch (e) {
    console.error('Failed to save notes:', e);
  }
}

// Recycle Bin
export function getRecycleBin(): RecycleItem[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY_RECYCLE);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function saveRecycleBin(items: RecycleItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_RECYCLE, JSON.stringify(items));
  } catch (e) {
    console.error('Failed to save recycle bin:', e);
  }
}

// User Session
export function getUserSession(): UserSession {
  try {
    const data = localStorage.getItem(STORAGE_KEY_AUTH);
    return data
      ? JSON.parse(data)
      : {
          isLoggedIn: false,
          username: '',
          email: '',
          connected: false,
        };
  } catch {
    return {
      isLoggedIn: false,
      username: '',
      email: '',
      connected: false,
    };
  }
}

export function saveUserSession(session: UserSession): void {
  try {
    localStorage.setItem(STORAGE_KEY_AUTH, JSON.stringify(session));
  } catch (e) {
    console.error('Failed to save session:', e);
  }
}

// Cloud Backup State
export function getBackupState(): CloudBackupState {
  try {
    const data = localStorage.getItem(STORAGE_KEY_BACKUP);
    return data
      ? JSON.parse(data)
      : {
          lastBackupDate: 'Never',
          autoBackup: false,
        };
  } catch {
    return {
      lastBackupDate: 'Never',
      autoBackup: false,
    };
  }
}

export function saveBackupState(state: CloudBackupState): void {
  try {
    localStorage.setItem(STORAGE_KEY_BACKUP, JSON.stringify(state));
  } catch (e) {
    console.error('Failed to save backup state:', e);
  }
}

// Convert Blob to Base64 Data URL
export function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

// Convert Base64 Data URL to Blob
export function dataUrlToBlob(dataUrl: string): Blob {
  try {
    const parts = dataUrl.split(',');
    const mime = parts[0].match(/:(.*?);/)?.[1] || 'application/octet-stream';
    const binary = atob(parts[1]);
    const len = binary.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return new Blob([bytes], { type: mime });
  } catch {
    return new Blob([], { type: 'application/octet-stream' });
  }
}
