import { ChatSession } from '../types/chat';
import { authClient } from './authClient';

function getStorageKey(): string {
  const user = authClient.getStoredUser();
  return user ? `onyxmind_chat_sessions_${user.id}` : 'onyxmind_chat_sessions_guest';
}

function getActiveSessionKey(): string {
  const user = authClient.getStoredUser();
  return user ? `onyxmind_active_session_${user.id}` : 'onyxmind_active_session_guest';
}

export const storage = {
  getLocalSessions(): ChatSession[] {
    try {
      const data = localStorage.getItem(getStorageKey());
      if (!data) return [];
      return JSON.parse(data);
    } catch (e) {
      console.error('Error reading local sessions', e);
      return [];
    }
  },

  setLocalSessions(sessions: ChatSession[]) {
    try {
      localStorage.setItem(getStorageKey(), JSON.stringify(sessions));
    } catch (e) {
      console.error('Error saving local sessions', e);
    }
  },

  getActiveSessionId(): string | null {
    try {
      return localStorage.getItem(getActiveSessionKey());
    } catch {
      return null;
    }
  },

  setActiveSessionId(id: string) {
    try {
      localStorage.setItem(getActiveSessionKey(), id);
    } catch {}
  },

  // Remote Database Operations with User Authorization
  async fetchServerSessions(): Promise<ChatSession[]> {
    try {
      const res = await authClient.fetchWithAuth('/api/chats');
      if (!res.ok) throw new Error('Failed to fetch from server');
      const data = await res.json();
      if (Array.isArray(data)) {
        this.setLocalSessions(data);
        return data;
      }
      return [];
    } catch (err) {
      console.warn('Falling back to local sessions:', err);
      return this.getLocalSessions();
    }
  },

  async createServerSession(session: ChatSession): Promise<ChatSession> {
    try {
      const res = await authClient.fetchWithAuth('/api/chats', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(session),
      });
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      console.error('Failed to create session on server', e);
    }
    return session;
  },

  async updateServerSession(session: ChatSession): Promise<void> {
    try {
      await authClient.fetchWithAuth(`/api/chats/${session.id}/sync`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: session.messages, title: session.title }),
      });
    } catch (e) {
      console.error('Failed to sync session with server', e);
    }
  },

  async deleteServerSession(sessionId: string): Promise<void> {
    try {
      await authClient.fetchWithAuth(`/api/chats/${sessionId}`, {
        method: 'DELETE',
      });
    } catch (e) {
      console.error('Failed to delete session on server', e);
    }
  },

  async deleteServerMessage(sessionId: string, messageId: string): Promise<void> {
    try {
      await authClient.fetchWithAuth(`/api/chats/${sessionId}/messages/${messageId}`, {
        method: 'DELETE',
      });
    } catch (e) {
      console.error('Failed to delete message on server', e);
    }
  },

  clearLocalSessions() {
    try {
      localStorage.removeItem(getStorageKey());
      localStorage.removeItem(getActiveSessionKey());
    } catch (e) {
      console.error('Error clearing local sessions', e);
    }
  },

  async clearAllServerSessions(): Promise<void> {
    try {
      await authClient.fetchWithAuth('/api/chats', {
        method: 'DELETE',
      });
      this.clearLocalSessions();
    } catch (e) {
      console.error('Failed to clear sessions on server', e);
    }
  },

  async clearServerMessages(sessionId: string): Promise<void> {
    try {
      await authClient.fetchWithAuth(`/api/chats/${sessionId}/messages`, {
        method: 'DELETE',
      });
    } catch (e) {
      console.error('Failed to clear messages on server', e);
    }
  },
};
