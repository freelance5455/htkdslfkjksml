import { ProjectItem, HistoryItem } from "../types";

const PROJECTS_KEY = "vew_projects_v1";
const HISTORY_KEY = "vew_history_v1";
const SETTINGS_KEY = "vew_settings_v1";

export interface AppSettings {
  backendUrl: string;
  language: string;
  theme: "dark" | "light";
  autoSave: boolean;
  notifications: boolean;
  downloadLocation: string;
}

const DEFAULT_SETTINGS: AppSettings = {
  backendUrl: "",
  language: "English",
  theme: "dark",
  autoSave: true,
  notifications: true,
  downloadLocation: "Internal Storage / VEW Studio",
};

export const Storage = {
  getProjects(): ProjectItem[] {
    try {
      const data = localStorage.getItem(PROJECTS_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveProject(project: Omit<ProjectItem, "id" | "createdAt" | "lastModified">): ProjectItem {
    const projects = this.getProjects();
    const newProject: ProjectItem = {
      ...project,
      id: `proj_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      createdAt: Date.now(),
      lastModified: Date.now(),
    };
    projects.unshift(newProject);
    try {
      localStorage.setItem(PROJECTS_KEY, JSON.stringify(projects));
    } catch (e) {
      console.error("Storage error:", e);
    }
    return newProject;
  },

  updateProject(id: string, updates: Partial<ProjectItem>): boolean {
    const projects = this.getProjects();
    const idx = projects.findIndex((p) => p.id === id);
    if (idx === -1) return false;
    projects[idx] = { ...projects[idx], ...updates, lastModified: Date.now() };
    try {
      localStorage.setItem(PROJECTS_KEY, JSON.stringify(projects));
      return true;
    } catch {
      return false;
    }
  },

  deleteProject(id: string): boolean {
    const projects = this.getProjects().filter((p) => p.id !== id);
    try {
      localStorage.setItem(PROJECTS_KEY, JSON.stringify(projects));
      return true;
    } catch {
      return false;
    }
  },

  getHistory(): HistoryItem[] {
    try {
      const data = localStorage.getItem(HISTORY_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  addHistory(item: Omit<HistoryItem, "id" | "createdAt">): HistoryItem {
    const history = this.getHistory();
    const newItem: HistoryItem = {
      ...item,
      id: `hist_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      createdAt: Date.now(),
    };
    history.unshift(newItem);
    if (history.length > 100) history.pop();
    try {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
    } catch (e) {
      console.error("History storage error:", e);
    }
    return newItem;
  },

  updateHistory(id: string, updates: Partial<HistoryItem>): void {
    const history = this.getHistory();
    const idx = history.findIndex((h) => h.id === id);
    if (idx !== -1) {
      history[idx] = { ...history[idx], ...updates };
      try {
        localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
      } catch {}
    }
  },

  deleteHistory(id: string): void {
    const history = this.getHistory().filter((h) => h.id !== id);
    try {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
    } catch {}
  },

  clearHistory(): void {
    try {
      localStorage.removeItem(HISTORY_KEY);
    } catch {}
  },

  getSettings(): AppSettings {
    try {
      const data = localStorage.getItem(SETTINGS_KEY);
      return data ? { ...DEFAULT_SETTINGS, ...JSON.parse(data) } : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  },

  saveSettings(settings: AppSettings): void {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch (e) {
      console.error("Settings save error:", e);
    }
  },
};
