import type {
  Subject,
  TaskItem,
  NoteItem,
  PomodoroSettings,
  ChatMessage,
  StudyAlarm,
} from '../types';

const KEYS = {
  subjects: 'nuzakir_subjects_v1',
  clearedSeedSubjects: 'nuzakir_cleared_seed_subjects_v1',
  tasks: 'nuzakir_tasks_v1',
  notes: 'nuzakir_notes_v1',
  pomodoro: 'nuzakir_pomodoro_v1',
  aiChat: 'nuzakir_ai_chat_v1',
  theme: 'nuzakir_theme_v1',
  solvedQuizzes: 'nuzakir_solved_quizzes_v1',
  readContent: 'nuzakir_read_content_v1',
  pomodoroSessions: 'nuzakir_pomodoro_sessions_v1',
  understoodAi: 'nuzakir_understood_ai_v1',
  askedAi: 'nuzakir_asked_ai_v1',
  alarms: 'nuzakir_alarms_v1',
};

const SEEDED_SUBJECT_IDS = new Set(['subj-math', 'subj-physics', 'subj-arabic']);
const STARTER_SUBJECTS: Subject[] = [];

const STARTER_TASKS: TaskItem[] = [
  {
    id: 'task-1',
    title: 'حل تمارين الفصل الثالث في الرياضيات',
    subjectName: 'الرياضيات',
    done: false,
    priority: 'high',
    createdAt: Date.now(),
  },
  {
    id: 'task-2',
    title: 'مراجعة قوانين الحركة والمقذوفات',
    subjectName: 'الفيزياء',
    done: false,
    priority: 'normal',
    createdAt: Date.now() - 1000,
  },
];

const STARTER_NOTES: NoteItem[] = [
  {
    id: 'note-1',
    title: 'قواعد سريعة في المشتقات',
    subjectTag: 'الرياضيات',
    content:
      'مشتقة الثابت تساوي صفراً.\nمشتقة س^ن = ن × س^(ن-1).\nلا تنسَ تطبيق قاعدة السلسلة عند الدوال المركبة.',
    color: 'purple',
    updatedAt: Date.now(),
  },
];

function readJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (raw === null) {
      localStorage.setItem(key, JSON.stringify(fallback));
      return fallback;
    }
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function writeJson<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (err) {
    console.error('Failed to persist to localStorage:', err);
  }
}

export function loadSubjects(): Subject[] {
  const list = readJson<Subject[]>(KEYS.subjects, STARTER_SUBJECTS);
  try {
    if (localStorage.getItem(KEYS.clearedSeedSubjects) !== '1') {
      const cleaned = list.filter((s) => !SEEDED_SUBJECT_IDS.has(s.id));
      localStorage.setItem(KEYS.subjects, JSON.stringify(cleaned));
      localStorage.setItem(KEYS.clearedSeedSubjects, '1');
      return cleaned;
    }
  } catch {
    // ignore storage access issues
  }
  return list;
}

export function saveSubjects(subjects: Subject[]): void {
  writeJson(KEYS.subjects, subjects);
}

export function loadTasks(): TaskItem[] {
  return readJson<TaskItem[]>(KEYS.tasks, STARTER_TASKS);
}

export function saveTasks(tasks: TaskItem[]): void {
  writeJson(KEYS.tasks, tasks);
}

export function loadNotes(): NoteItem[] {
  return readJson<NoteItem[]>(KEYS.notes, STARTER_NOTES);
}

export function saveNotes(notes: NoteItem[]): void {
  writeJson(KEYS.notes, notes);
}

export function loadPomodoroSettings(): PomodoroSettings {
  return readJson<PomodoroSettings>(KEYS.pomodoro, {
    studyMinutes: 25,
    breakMinutes: 5,
  });
}

export function savePomodoroSettings(settings: PomodoroSettings): void {
  writeJson(KEYS.pomodoro, settings);
}

export function loadAiChatHistory(): ChatMessage[] {
  return readJson<ChatMessage[]>(KEYS.aiChat, []);
}

export function saveAiChatHistory(messages: ChatMessage[]): void {
  writeJson(KEYS.aiChat, messages.slice(-30));
}

export function loadTheme(): 'light' | 'dark' {
  try {
    const val = localStorage.getItem(KEYS.theme);
    return val === 'dark' ? 'dark' : 'light';
  } catch {
    return 'light';
  }
}

export function saveTheme(theme: 'light' | 'dark'): void {
  try {
    localStorage.setItem(KEYS.theme, theme);
  } catch {
    // ignore
  }
}

export function loadSolvedQuizIds(): string[] {
  return readJson<string[]>(KEYS.solvedQuizzes, []);
}

export function saveSolvedQuizIds(ids: string[]): void {
  writeJson(KEYS.solvedQuizzes, ids);
}

export function loadReadContentIds(): string[] {
  return readJson<string[]>(KEYS.readContent, []);
}

export function saveReadContentIds(ids: string[]): void {
  writeJson(KEYS.readContent, ids);
}

export function loadPomodoroSessionsCount(): number {
  return readJson<number>(KEYS.pomodoroSessions, 0);
}

export function savePomodoroSessionsCount(count: number): void {
  writeJson(KEYS.pomodoroSessions, count);
}

export function loadUnderstoodAiIds(): string[] {
  return readJson<string[]>(KEYS.understoodAi, []);
}

export function saveUnderstoodAiIds(ids: string[]): void {
  writeJson(KEYS.understoodAi, ids);
}

export function loadAskedAiIds(): string[] {
  return readJson<string[]>(KEYS.askedAi, []);
}

export function saveAskedAiIds(ids: string[]): void {
  writeJson(KEYS.askedAi, ids);
}

export function loadAlarms(): StudyAlarm[] {
  return readJson<StudyAlarm[]>(KEYS.alarms, []);
}

export function saveAlarms(alarms: StudyAlarm[]): void {
  writeJson(KEYS.alarms, alarms);
}
