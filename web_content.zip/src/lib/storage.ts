const SCORES_KEY = "vazhbar.scores.v1";
const PROGRESS_KEY = "vazhbar.progress.v1";
const PREFS_KEY = "vazhbar.prefs.v1";

export interface ScoreEntry {
  id: string;
  name: string;
  score: number;
  lesson: string;
  lessonTitle: string;
  mode: string;
  difficulty: string;
  words: number;
  accuracy: number;
  mastered: number;
  date: number;
}

export interface WordProgress {
  correct: number;
  wrong: number;
  mastered: boolean;
}

export type ProgressMap = Record<string, WordProgress>;

export interface Prefs {
  sound: boolean;
  voice: boolean;
  lessonId: string;
  mode: string;
  difficulty: string;
  name: string;
}

function safeParse<T>(raw: string | null, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function loadScores(): ScoreEntry[] {
  if (typeof localStorage === "undefined") return [];
  const list = safeParse<ScoreEntry[]>(localStorage.getItem(SCORES_KEY), []);
  return Array.isArray(list) ? list : [];
}

export function saveScore(entry: ScoreEntry): ScoreEntry[] {
  const list = loadScores();
  list.push(entry);
  list.sort((a, b) => b.score - a.score || b.mastered - a.mastered);
  const trimmed = list.slice(0, 50);
  try {
    localStorage.setItem(SCORES_KEY, JSON.stringify(trimmed));
  } catch {
    /* storage full / unavailable — ignore */
  }
  return trimmed;
}

export function clearScores() {
  try {
    localStorage.removeItem(SCORES_KEY);
  } catch {
    /* ignore */
  }
}

export function loadProgress(): ProgressMap {
  if (typeof localStorage === "undefined") return {};
  return safeParse<ProgressMap>(localStorage.getItem(PROGRESS_KEY), {});
}

export function saveProgress(map: ProgressMap) {
  try {
    localStorage.setItem(PROGRESS_KEY, JSON.stringify(map));
  } catch {
    /* ignore */
  }
}

export function recordWord(
  lessonId: string,
  wordId: string,
  correct: boolean,
): ProgressMap {
  const map = loadProgress();
  const key = `${lessonId}:${wordId}`;
  const prev = map[key] ?? { correct: 0, wrong: 0, mastered: false };
  const next: WordProgress = {
    correct: prev.correct + (correct ? 1 : 0),
    wrong: prev.wrong + (correct ? 0 : 1),
    mastered: prev.mastered || correct,
  };
  map[key] = next;
  saveProgress(map);
  return map;
}

export function lessonMasteredCount(lessonId: string, wordIds: string[]): number {
  const map = loadProgress();
  return wordIds.filter((id) => map[`${lessonId}:${id}`]?.mastered).length;
}

export function loadPrefs(): Prefs {
  const fallback: Prefs = {
    sound: true,
    voice: true,
    lessonId: "l8",
    mode: "tap",
    difficulty: "normal",
    name: "",
  };
  if (typeof localStorage === "undefined") return fallback;
  const stored = safeParse<Partial<Prefs>>(localStorage.getItem(PREFS_KEY), {});
  const merged = { ...fallback, ...stored };
  if (!["tap", "type", "meaning"].includes(merged.mode)) merged.mode = fallback.mode;
  if (!["easy", "normal", "hard"].includes(merged.difficulty))
    merged.difficulty = fallback.difficulty;
  if (typeof merged.name !== "string") merged.name = "";
  return merged;
}

export function savePrefs(prefs: Prefs) {
  try {
    localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
  } catch {
    /* ignore */
  }
}
