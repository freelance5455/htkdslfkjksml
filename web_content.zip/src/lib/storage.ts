// ============================================================
// AI CREATOR STUDIO — DATA PERSISTENCE & DATABASE CLIENT
// Server-backed Database (Source of Truth) with Local Cache Fallback
// ============================================================

import type { Project, Idea, CalendarEvent, BrandKit, CreatorMemory, MediaAsset } from "@/types";
import { generateId } from "@/lib/utils";
import { getAuthToken } from "@/lib/auth";

const KEYS = {
  projects: "acs_projects",
  initialized: "acs_projects_initialized_v2",
  ideas: "acs_ideas",
  calendar: "acs_calendar",
  brandKit: "acs_brand_kit",
  memory: "acs_creator_memory",
  library: "acs_media_library",
  synced: "acs_server_synced_v1",
  externalVideos: "acs_external_videos",
  clones: "acs_clones_history",
};

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function save<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (err) {
    console.warn(`[Storage] Failed to save key "${key}" to localStorage:`, err);
  }
}

function getHeaders(): Record<string, string> {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
  };
  const token = getAuthToken();
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }
  return headers;
}

// Initial seed projects for offline bootstrap
const INITIAL_PROJECTS: Project[] = [
  {
    id: "proj-seed-1",
    title: "Animais Mais Lindos Cantando: O Show da Fazendinha Mágica",
    description: "Vídeo musical alegre e educativo de animais fofos cantando e dançando juntos na natureza encantada",
    status: "COMPLETED",
    contentType: "CHILDREN_VIDEO",
    platform: "YOUTUBE",
    outputFormats: ["YOUTUBE_1080p", "SHORTS_1080p", "INSTAGRAM_PORTRAIT", "TIKTOK_PORTRAIT"],
    tags: ["infantil", "musica", "animais", "kids", "cantando", "fofura"],
    characters: [],
    brief: {
      id: "brief-seed-1",
      title: "Animais Mais Lindos Cantando — Especial da Natureza",
      concept: "Uma apresentação musical colorida e animada com animais fofinhos cantando uma melodia alegre sobre a harmonia da fazenda e da floresta.",
      targetAudience: "Crianças de 2 a 8 anos e famílias",
      tone: "Alegre, acolhedor, vibrante, musical e mágico",
      keyPoints: [
        "Apresentação dos animais cantores (pato, gatinho, coelho e passarinho)",
        "Refrão contagiante e ritmo dançante",
        "Cores brilhantes e cenários naturais ensolarados",
        "Mensagem de amizade e alegria",
      ],
      duration: 180,
      visualStyle: "3D Animation Pixar/Disney style, ultra colorful, soft warm lighting, cute animal faces",
      narrativeArc: "O sol nasce na fazenda, os animais acordam e começam a afinar seus instrumentos para o grande concerto da manhã.",
      status: "APPROVED",
    },
    script: {
      id: "script-seed-1",
      scenes: [
        {
          id: "sc-1",
          number: 1,
          visual: "Plano geral da fazenda mágica ao nascer do sol com flores brilhantes e o galinho afinando a voz no celeiro.",
          audio: "Efeito sonoro de passarinhos cantando e acordes suaves de violão acústico.",
          narration: "Bom dia, amiguinhos! Hoje é um dia muito especial no vale dos animais cantores!",
          duration: 15,
        },
        {
          id: "sc-2",
          number: 2,
          visual: "Um patinho amarelo com cartola e um coelhinho fofo cantando no microfone feito de girassol.",
          audio: "Quá-quá melodioso e ritmo de xilofone animado.",
          narration: "Vem com a gente cantar a canção mais fofa do mundo!",
          duration: 25,
        },
        {
          id: "sc-3",
          number: 3,
          visual: "Todos os animais juntos dançando em roda no gramado com borboletas luminosas voando ao redor.",
          audio: "Refrão completo orquestrado com palmas e coro infantil.",
          narration: "A natureza é nossa festa, vem dançar sem parar!",
          duration: 35,
        },
      ],
      estimatedDuration: 180,
    },
    storyboard: {
      id: "sb-seed-1",
      scenes: [
        {
          id: "scene-1",
          sceneNumber: 1,
          description: "Cenário idílico com o sol nascendo e um coro de animais fofos afinando a voz com microfones florais",
          prompt: "Cute Pixar style cartoon animals singing in a sunny flower field, vibrant colors, morning golden hour light, highly detailed 3D render",
          imageUrl: "https://images.unsplash.com/photo-1535268647677-300dbf3d78d1?w=800&auto=format&fit=crop&q=80",
          videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
          duration: 15,
        },
        {
          id: "scene-2",
          sceneNumber: 2,
          description: "Close-up do patinho amarelo sorridente e um coelho felpudo cantando com expressão de pura alegria",
          prompt: "Close up of adorable fluffy bunny and yellow duckling singing with tiny microphones in fantasy meadow, Disney Pixar style, 8k",
          imageUrl: "https://images.unsplash.com/photo-1583337130417-3346a1be7dee?w=800&auto=format&fit=crop&q=80",
          videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
          duration: 25,
        },
        {
          id: "scene-3",
          sceneNumber: 3,
          description: "Grande final com todos os animais abraçados cantando sob um arco-íris brilhante",
          prompt: "Ensemble of cute baby animals singing together under a bright magical rainbow, confetti, warm celebration, 3d animation render",
          imageUrl: "https://images.unsplash.com/photo-1548767797-d8c844163c4c?w=800&auto=format&fit=crop&q=80",
          videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
          duration: 35,
        },
      ],
    },
    assets: [
      { id: "asset-1", projectId: "proj-seed-1", type: "VIDEO", status: "COMPLETED", name: "Cena 1 - Nascer do Sol na Fazenda", duration: 15, url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4", createdAt: new Date(Date.now() - 2 * 86400000).toISOString() },
      { id: "asset-2", projectId: "proj-seed-1", type: "VOICE", status: "COMPLETED", name: "Narração Infantil & Canção Musical", duration: 60, url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4", createdAt: new Date(Date.now() - 2 * 86400000).toISOString() },
      { id: "asset-3", projectId: "proj-seed-1", type: "IMAGE", status: "COMPLETED", name: "Thumbnail Oficial - Animais Cantores", url: "https://images.unsplash.com/photo-1535268647677-300dbf3d78d1?w=800&auto=format&fit=crop&q=80", createdAt: new Date(Date.now() - 2 * 86400000).toISOString() },
    ],
    tasks: [
      { id: "task-1", projectId: "proj-seed-1", title: "Definir Conceito & Briefing Musical", status: "DONE", phase: "BRIEFING" },
      { id: "task-2", projectId: "proj-seed-1", title: "Escrever Roteiro Rítmico Infantil", status: "DONE", phase: "SCRIPTING" },
      { id: "task-3", projectId: "proj-seed-1", title: "Gerar Storyboard 3D Pixar", status: "DONE", phase: "STORYBOARDING" },
      { id: "task-4", projectId: "proj-seed-1", title: "Renderizar Vídeos Wan 2.1 & Áudio", status: "DONE", phase: "GENERATING" },
      { id: "task-5", projectId: "proj-seed-1", title: "Aprovação Final e Masterização", status: "DONE", phase: "COMPLETED" },
    ],
    versions: [],
    conversation: [],
    settings: { language: "PT_BR", outputFormat: "YOUTUBE_1080p", autoEdit: true, autoSubtitles: true, watermark: false },
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 2 * 86400000).toISOString(),
  },
  {
    id: "proj-seed-2",
    title: "Short: 5 Fatos Surpreendentes Sobre o Espaço e o Cosmos",
    description: "Cria um Short para YouTube sobre curiosidades científicas e buracos negros",
    status: "COMPLETED",
    contentType: "SHORT",
    platform: "YOUTUBE",
    outputFormats: ["SHORTS_1080p", "TIKTOK_PORTRAIT", "INSTAGRAM_PORTRAIT"],
    tags: ["curiosidades", "ciencia", "shorts", "espaco", "astronomia"],
    characters: [],
    brief: {
      id: "brief-seed-2",
      title: "5 Fatos Surpreendentes Sobre o Espaço Cósmico",
      concept: "Short vertical dinâmico e impactante revelando segredos do cosmos, buracos negros e dimensões do universo.",
      targetAudience: "Jovens e adultos curiosos, entusiastas de astronomia e ciência",
      tone: "Eletrizante, dinâmico, misterioso e científico",
      keyPoints: [
        "O silêncio absoluto no vácuo espacial",
        "A tempestade de diamantes em Netuno e Urano",
        "O buraco negro supermassivo no centro da Via Láctea",
        "A maior estrela conhecida que engoliria Saturno",
        "Chamada para inscrição e curiosidade final",
      ],
      duration: 60,
      visualStyle: "CGI Ultra-Realista 8K estilo Interestelar e NASA, nebulosas brilhantes e horizonte de eventos",
      narrativeArc: "Gancho imediato -> Revelações cósmicas -> Clímax -> CTA",
      status: "APPROVED",
    },
    script: {
      id: "script-seed-2",
      scenes: [
        {
          id: "sc-2-1",
          number: 1,
          visual: "Zoom hiperveloz através da escuridão do espaço rumo a um buraco negro pulsante com disco de acreção em chamas.",
          audio: "Som grave de impacto cinematográfico com sintetizador espacial tenso.",
          narration: "Você sabia que no centro da nossa galáxia existe um monstro gravitacional 4 milhões de vezes maior que o Sol?",
          duration: 15,
        },
        {
          id: "sc-2-2",
          number: 2,
          visual: "Nuvem de partículas de diamantes caindo em um planeta gasoso azul-turquesa sob raios cósmicos reluzentes.",
          audio: "Trilha eletrônica acelerada e efeito sonoro de cristalização estelar.",
          narration: "Em Netuno chove diamantes maciços do tamanho de montanhas inteiras todos os dias!",
          duration: 20,
        },
        {
          id: "sc-2-3",
          number: 3,
          visual: "A Terra encolhendo ao lado de uma estrela hipergigante vermelha incandescente com texto de inscrição brilhante.",
          audio: "Batida musical com sub-grave potente e sino de alerta.",
          narration: "E se você acha a Terra grande, veja esta estrela! Inscreva-se para mais viagens pelo cosmos!",
          duration: 25,
        },
      ],
      estimatedDuration: 60,
    },
    storyboard: {
      id: "sb-seed-2",
      scenes: [
        {
          id: "scene-2-1",
          sceneNumber: 1,
          description: "Buraco negro supermassivo girando em alta velocidade no espaço sideral com lente gravitacional curva",
          prompt: "Supermassive black hole with glowing fiery accretion disk, gravitational lensing effect, interstellar movie style, ultra realistic 8k render",
          imageUrl: "https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=800&auto=format&fit=crop&q=80",
          videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
          duration: 15,
        },
        {
          id: "scene-2-2",
          sceneNumber: 2,
          description: "Planeta Netuno com chuva de pedras preciosas e cristais de diamante sob atmosfera turbulenta",
          prompt: "Deep space cinematic shot of Neptune with diamond crystal rain falling through deep blue gas clouds, hyperdetailed",
          imageUrl: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&auto=format&fit=crop&q=80",
          videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
          duration: 20,
        },
        {
          id: "scene-2-3",
          sceneNumber: 3,
          description: "Comparativo de escala astronômica cósmica de estrelas gigantescas avermelhadas na imensidão",
          prompt: "Gigantic hypergiant red star cosmic scale comparison with planets, starry galaxy backdrop, photorealistic astronomy visual",
          imageUrl: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=800&auto=format&fit=crop&q=80",
          videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
          duration: 25,
        },
      ],
    },
    assets: [
      { id: "asset-4", projectId: "proj-seed-2", type: "VIDEO", status: "COMPLETED", name: "Cena Espaço 4K - Buraco Negro", duration: 15, url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4", createdAt: new Date(Date.now() - 1 * 86400000).toISOString() },
      { id: "asset-5", projectId: "proj-seed-2", type: "VOICE", status: "COMPLETED", name: "Locução Curiosidades Espaciais", duration: 60, url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4", createdAt: new Date(Date.now() - 1 * 86400000).toISOString() },
      { id: "asset-6", projectId: "proj-seed-2", type: "IMAGE", status: "COMPLETED", name: "Thumbnail Cosmos Vertical", url: "https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=800&auto=format&fit=crop&q=80", createdAt: new Date(Date.now() - 1 * 86400000).toISOString() },
    ],
    tasks: [
      { id: "task-2-1", projectId: "proj-seed-2", title: "Curadoria de Fatos do Cosmos", status: "DONE", phase: "BRIEFING" },
      { id: "task-2-2", projectId: "proj-seed-2", title: "Roteiro de Retenção Acelerada", status: "DONE", phase: "SCRIPTING" },
      { id: "task-2-3", projectId: "proj-seed-2", title: "Geração de Cenas Espaciais 8K", status: "DONE", phase: "STORYBOARDING" },
      { id: "task-2-4", projectId: "proj-seed-2", title: "Renderização do Short Vertical", status: "DONE", phase: "GENERATING" },
    ],
    versions: [],
    conversation: [],
    settings: { language: "PT_BR", outputFormat: "SHORTS_1080p", autoEdit: true, autoSubtitles: true, watermark: false },
    createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 1 * 86400000).toISOString(),
  },
];

// --- SERVER ASYNC INITIALIZATION & SYNC ---
export async function syncWithServer(): Promise<void> {
  try {
    // 1. Ingest any local client data to the server if first run
    const localProjects = load<Project[]>(KEYS.projects, []);
    const localIdeas = load<Idea[]>(KEYS.ideas, []);
    const localCalendar = load<CalendarEvent[]>(KEYS.calendar, []);
    const localMedia = load<MediaAsset[]>(KEYS.library, []);

    if (localProjects.length > 0 || localIdeas.length > 0) {
      await fetch("/api/db/sync-from-local", {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify({
          projects: localProjects,
          ideas: localIdeas,
          calendar: localCalendar,
          mediaLibrary: localMedia,
        }),
      });
    }

    // 2. Refresh local cache with latest server database source of truth
    const res = await fetch("/api/db/projects", { headers: getHeaders() });
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data.data) && data.data.length > 0) {
        save(KEYS.projects, data.data);
      }
    }
  } catch (err) {
    console.warn("[Storage] Server sync background warning:", err);
  }
}

// Auto-trigger background server sync
if (typeof window !== "undefined") {
  setTimeout(() => {
    syncWithServer();
  }, 1000);
}

// --- PROJECTS ---
export function getProjects(): Project[] {
  if (typeof window === "undefined") return INITIAL_PROJECTS;
  const isInit = localStorage.getItem(KEYS.initialized);
  if (!isInit) {
    save(KEYS.projects, INITIAL_PROJECTS);
    localStorage.setItem(KEYS.initialized, "true");
    return INITIAL_PROJECTS;
  }
  return load<Project[]>(KEYS.projects, []);
}

export function getProject(id: string): Project | undefined {
  return getProjects().find((p) => p.id === id);
}

export function saveProject(project: Project): void {
  const projects = getProjects();
  const idx = projects.findIndex((p) => p.id === project.id);
  const updated = { ...project, updatedAt: new Date().toISOString() };
  if (idx >= 0) projects[idx] = updated;
  else projects.unshift(updated);
  save(KEYS.projects, projects);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("acs_projects_changed", { detail: { project: updated } }));
  }

  // Asynchronously persist to server DB
  fetch("/api/db/projects", {
    method: "POST",
    headers: getHeaders(),
    body: JSON.stringify(updated),
  }).catch((err) => console.warn("[Storage] Remote saveProject error:", err));
}

export function deleteProject(id: string): void {
  const current = getProjects();
  const filtered = current.filter((p) => p.id !== id);
  save(KEYS.projects, filtered);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("acs_projects_changed", { detail: { deletedId: id } }));
  }

  fetch(`/api/db/projects/${id}`, {
    method: "DELETE",
    headers: getHeaders(),
  }).catch((err) => console.warn("[Storage] Remote deleteProject error:", err));
}

// --- EXTERNAL VIDEOS ---
export interface ExternalVideoItem {
  id: string;
  source:
    | "GALLERY"
    | "YOUTUBE"
    | "TIKTOK"
    | "INSTAGRAM"
    | "FEBSPOT"
    | "RUMBLE"
    | "BILIBILI"
    | "DAILYMOTION"
    | "VIMEO"
    | "UOL_MAIS"
    | "SAPO_VIDEOS"
    | "URL";
  title: string;
  videoUrl: string;
  thumbnailUrl: string;
  duration?: number;
  width?: number;
  height?: number;
  fileSize?: number;
  originalName?: string;
  extractedDescription?: string;
  tags?: string[];
  createdAt: string;
}

export function getExternalVideos(): ExternalVideoItem[] {
  return load<ExternalVideoItem[]>(KEYS.externalVideos, [
    {
      id: "ext-sample-1",
      source: "GALLERY",
      title: "Câmera do Celular - Gravação Natureza 4K",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
      thumbnailUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&auto=format&fit=crop&q=80",
      duration: 15,
      width: 1920,
      height: 1080,
      originalName: "VID_20260907_120401.mp4",
      extractedDescription: "Vídeo gravado via smartphone em alta definição. Pronto para cortes dinâmicos e narração de IA.",
      tags: ["galeria", "celular", "natureza", "4k"],
      createdAt: new Date().toISOString(),
    },
    {
      id: "ext-sample-2",
      source: "YOUTUBE",
      title: "YouTube Shorts - Descoberta Científica Espacial",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
      thumbnailUrl: "https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=800&auto=format&fit=crop&q=80",
      duration: 30,
      width: 1080,
      height: 1920,
      originalName: "youtube.com/shorts/cosmos_viral_01",
      extractedDescription: "Corte viral sobre fenômenos do universo extraído de canal de astronomia.",
      tags: ["youtube", "shorts", "ciencia", "viral"],
      createdAt: new Date(Date.now() - 3600000).toISOString(),
    },
    {
      id: "ext-sample-rumble",
      source: "RUMBLE",
      title: "Rumble - O Avanço da Inteligência Artificial em 2026",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      thumbnailUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80",
      duration: 60,
      width: 1920,
      height: 1080,
      originalName: "rumble.com/v3x89a-ia-futuro",
      extractedDescription: "Debate e documentário independente sobre automação e inteligência artificial.",
      tags: ["rumble", "ia", "tecnologia", "independente"],
      createdAt: new Date(Date.now() - 7200000).toISOString(),
    },
    {
      id: "ext-sample-bilibili",
      source: "BILIBILI",
      title: "Bilibili - Animação Visual & Efeitos 3D Futuristas",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
      thumbnailUrl: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=800&auto=format&fit=crop&q=80",
      duration: 45,
      width: 1920,
      height: 1080,
      originalName: "bilibili.com/video/BV1ab411c7d",
      extractedDescription: "Showcase visual e edição de animação criativa importada do Bilibili.",
      tags: ["bilibili", "animacao", "danmaku", "criativo"],
      createdAt: new Date(Date.now() - 10800000).toISOString(),
    },
    {
      id: "ext-sample-vimeo",
      source: "VIMEO",
      title: "Vimeo Staff Pick - Cinematografia Urbana & Cores",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
      thumbnailUrl: "https://images.unsplash.com/photo-1536240478700-b869070f9279?w=800&auto=format&fit=crop&q=80",
      duration: 75,
      width: 1920,
      height: 1080,
      originalName: "vimeo.com/channels/staffpicks/891234",
      extractedDescription: "Fotografia cinematográfica com graduação de cor refinada e alta taxa de bits.",
      tags: ["vimeo", "cinema", "4k", "producao"],
      createdAt: new Date(Date.now() - 14400000).toISOString(),
    },
    {
      id: "ext-sample-dailymotion",
      source: "DAILYMOTION",
      title: "Dailymotion - Resumo Tecnológico Semanal",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4",
      thumbnailUrl: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80",
      duration: 50,
      width: 1920,
      height: 1080,
      originalName: "dailymotion.com/video/x89tech",
      extractedDescription: "Cobertura de lançamentos digitais e robótica com narrativa jornalística.",
      tags: ["dailymotion", "tech", "noticias", "resumo"],
      createdAt: new Date(Date.now() - 18000000).toISOString(),
    },
    {
      id: "ext-sample-febspot",
      source: "FEBSPOT",
      title: "FebSpot - Monetização de Conteúdo & Vídeos Virais",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
      thumbnailUrl: "https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=800&auto=format&fit=crop&q=80",
      duration: 40,
      width: 1920,
      height: 1080,
      originalName: "febspot.com/video/99124",
      extractedDescription: "Vídeo monetizado na rede FebSpot pronto para distribuição e compartilhamento.",
      tags: ["febspot", "monetizacao", "criadores", "video"],
      createdAt: new Date(Date.now() - 21600000).toISOString(),
    },
    {
      id: "ext-sample-uol",
      source: "UOL_MAIS",
      title: "UOL Mais (Vol Mais) - Destaques do Empreendedorismo BR",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
      thumbnailUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop&q=80",
      duration: 55,
      width: 1920,
      height: 1080,
      originalName: "mais.uol.com.br/view/1782341",
      extractedDescription: "Reportagem em vídeo sobre inovação e modelos de negócios digitais no Brasil.",
      tags: ["uol_mais", "vol_mais", "negocios", "brasil"],
      createdAt: new Date(Date.now() - 25200000).toISOString(),
    },
    {
      id: "ext-sample-sapo",
      source: "SAPO_VIDEOS",
      title: "SAPO Vídeos - Criadores de Conteúdo em Portugal",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      thumbnailUrl: "https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?w=800&auto=format&fit=crop&q=80",
      duration: 35,
      width: 1920,
      height: 1080,
      originalName: "videos.sapo.pt/bF3e99J01",
      extractedDescription: "Vídeo destaque do portal SAPO Vídeos Portugal com foco em cultura e inovação.",
      tags: ["sapo_videos", "portugal", "criadores", "sapo"],
      createdAt: new Date(Date.now() - 28800000).toISOString(),
    },
  ]);
}

export function saveExternalVideo(item: ExternalVideoItem): void {
  const list = getExternalVideos();
  const idx = list.findIndex((x) => x.id === item.id);
  if (idx >= 0) list[idx] = item;
  else list.unshift(item);
  save(KEYS.externalVideos, list);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("acs_external_videos_changed"));
  }
}

export function deleteExternalVideo(id: string): void {
  const list = getExternalVideos().filter((x) => x.id !== id);
  save(KEYS.externalVideos, list);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("acs_external_videos_changed"));
  }
}

// --- CLONES HISTORY ---
export interface CloneRecord {
  id: string;
  type: "CHANNEL" | "VIDEO" | "MUSIC" | "PLATFORM";
  name: string;
  sourceUrlOrRef: string;
  resultSummary: string;
  details: Record<string, unknown>;
  associatedProjectId?: string;
  createdAt: string;
}

export function getClonesHistory(): CloneRecord[] {
  return load<CloneRecord[]>(KEYS.clones, []);
}

export function saveCloneRecord(record: CloneRecord): void {
  const list = getClonesHistory();
  const idx = list.findIndex((x) => x.id === record.id);
  if (idx >= 0) list[idx] = record;
  else list.unshift(record);
  save(KEYS.clones, list);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("acs_clones_changed"));
  }
}

export function deleteCloneRecord(id: string): void {
  const list = getClonesHistory().filter((x) => x.id !== id);
  save(KEYS.clones, list);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("acs_clones_changed"));
  }
}

// --- IDEAS ---
export function getIdeas(): Idea[] {
  return load<Idea[]>(KEYS.ideas, []);
}

export function saveIdea(idea: Idea): void {
  const ideas = getIdeas();
  const idx = ideas.findIndex((i) => i.id === idea.id);
  if (idx >= 0) ideas[idx] = idea;
  else ideas.unshift(idea);
  save(KEYS.ideas, ideas);

  fetch("/api/db/ideas", {
    method: "POST",
    headers: getHeaders(),
    body: JSON.stringify(idea),
  }).catch((err) => console.warn("[Storage] Remote saveIdea error:", err));
}

export function deleteIdea(id: string): void {
  save(KEYS.ideas, getIdeas().filter((i) => i.id !== id));

  fetch(`/api/db/ideas/${id}`, {
    method: "DELETE",
    headers: getHeaders(),
  }).catch((err) => console.warn("[Storage] Remote deleteIdea error:", err));
}

// --- CALENDAR ---
export function getCalendarEvents(): CalendarEvent[] {
  return load<CalendarEvent[]>(KEYS.calendar, []);
}

export function saveCalendarEvent(event: CalendarEvent): void {
  const events = getCalendarEvents();
  const idx = events.findIndex((e) => e.id === event.id);
  if (idx >= 0) events[idx] = event;
  else events.push(event);
  save(KEYS.calendar, events);

  fetch("/api/db/calendar", {
    method: "POST",
    headers: getHeaders(),
    body: JSON.stringify(event),
  }).catch((err) => console.warn("[Storage] Remote saveCalendarEvent error:", err));
}

export function deleteCalendarEvent(id: string): void {
  save(KEYS.calendar, getCalendarEvents().filter((e) => e.id !== id));

  fetch(`/api/db/calendar/${id}`, {
    method: "DELETE",
    headers: getHeaders(),
  }).catch((err) => console.warn("[Storage] Remote deleteCalendarEvent error:", err));
}

// --- BRAND KIT ---
export function getBrandKit(): BrandKit {
  return load<BrandKit>(KEYS.brandKit, {
    id: generateId(),
    name: "Sadraque Ngola Brand",
    colors: [
      { name: "Primária", value: "#3b82f6", role: "primary" },
      { name: "Secundária", value: "#8b5cf6", role: "secondary" },
      { name: "Destaque", value: "#f59e0b", role: "accent" },
      { name: "Fundo", value: "#08080f", role: "background" },
    ],
    fonts: [
      { name: "Space Grotesk", role: "heading" },
      { name: "Inter", role: "body" },
    ],
    contentPreferences: [],
    updatedAt: new Date().toISOString(),
  });
}

export function saveBrandKit(kit: BrandKit): void {
  const updated = { ...kit, updatedAt: new Date().toISOString() };
  save(KEYS.brandKit, updated);

  fetch("/api/db/brandkit", {
    method: "POST",
    headers: getHeaders(),
    body: JSON.stringify(updated),
  }).catch((err) => console.warn("[Storage] Remote saveBrandKit error:", err));
}

// --- CREATOR MEMORY ---
export function getCreatorMemory(): CreatorMemory {
  return load<CreatorMemory>(KEYS.memory, {
    language: "PT_BR",
    defaultPlatform: "YOUTUBE",
    preferredStyle: "Dinâmico e moderno",
    preferredTone: "ENERGETIC",
    defaultOutputFormat: "YOUTUBE_1080p",
    contentPreferences: [],
    updatedAt: new Date().toISOString(),
  });
}

export function saveCreatorMemory(memory: CreatorMemory): void {
  const updated = { ...memory, updatedAt: new Date().toISOString() };
  save(KEYS.memory, updated);

  fetch("/api/db/memory", {
    method: "POST",
    headers: getHeaders(),
    body: JSON.stringify(updated),
  }).catch((err) => console.warn("[Storage] Remote saveCreatorMemory error:", err));
}

// --- MEDIA ASSETS & UPLOAD ---
export function getMediaLibrary(): MediaAsset[] {
  return load<MediaAsset[]>(KEYS.library, []);
}

export function saveMediaAsset(asset: MediaAsset): void {
  const lib = getMediaLibrary();
  const idx = lib.findIndex((a) => a.id === asset.id);
  if (idx >= 0) lib[idx] = asset;
  else lib.unshift(asset);
  save(KEYS.library, lib);

  fetch("/api/db/media", {
    method: "POST",
    headers: getHeaders(),
    body: JSON.stringify(asset),
  }).catch((err) => console.warn("[Storage] Remote saveMediaAsset error:", err));
}

export function deleteMediaAsset(id: string): void {
  save(KEYS.library, getMediaLibrary().filter((a) => a.id !== id));

  fetch(`/api/db/media/${id}`, {
    method: "DELETE",
    headers: getHeaders(),
  }).catch((err) => console.warn("[Storage] Remote deleteMediaAsset error:", err));
}

// Real File Upload to Server Cloud Storage
export async function uploadFileToStorage(
  file: File | Blob,
  filename: string,
  type = "MEDIA",
  projectId?: string
): Promise<{ success: boolean; asset?: MediaAsset; url?: string; error?: string }> {
  try {
    const reader = new FileReader();
    const dataBase64Promise = new Promise<string>((resolve, reject) => {
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });

    const dataBase64 = await dataBase64Promise;

    const res = await fetch("/api/storage/upload", {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify({
        filename,
        mimeType: file.type || "application/octet-stream",
        dataBase64,
        type,
        projectId,
      }),
    });

    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || "Erro no upload para o storage" };
    }

    // Cache local asset
    saveMediaAsset(data.asset);
    return { success: true, asset: data.asset, url: data.url };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Falha na transmissão do arquivo";
    console.error("[Storage] Upload failed:", msg);
    return { success: false, error: msg };
  }
}
