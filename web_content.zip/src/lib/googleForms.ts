import { getGoogleAccessToken } from './firebase';

export interface GoogleFormField {
  questionId?: string;
  title: string;
  type: string;
  required?: boolean;
  options?: string[];
}

export interface GoogleFormDetails {
  formId: string;
  info: {
    title: string;
    description?: string;
    documentTitle?: string;
  };
  responderUri: string;
  revisionId?: string;
  items?: Array<{
    itemId: string;
    title: string;
    description?: string;
    questionItem?: {
      question: {
        questionId: string;
        required?: boolean;
        choiceQuestion?: {
          type: string;
          options: Array<{ value: string }>;
        };
        textQuestion?: {
          paragraph?: boolean;
        };
        scaleQuestion?: {
          low: number;
          high: number;
          lowLabel?: string;
          highLabel?: string;
        };
      };
    };
  }>;
}

export interface GoogleFormResponseAnswer {
  questionId: string;
  textAnswers?: {
    answers: Array<{ value: string }>;
  };
}

export interface GoogleFormResponseItem {
  responseId: string;
  createTime: string;
  lastSubmittedTime: string;
  answers?: Record<string, GoogleFormResponseAnswer>;
}

export interface GoogleFormResponsesResult {
  responses?: GoogleFormResponseItem[];
  nextPageToken?: string;
}

export interface GoogleDriveFormItem {
  id: string;
  name: string;
  webViewLink?: string;
  createdTime?: string;
  modifiedTime?: string;
}

/**
 * List Google Forms belonging to the user from Google Drive
 */
export async function listUserGoogleForms(): Promise<GoogleDriveFormItem[]> {
  const token = await getGoogleAccessToken();
  if (!token) throw new Error('يرجى تسجيل الدخول بحساب Google أولاً.');

  const query = encodeURIComponent("mimeType = 'application/vnd.google-apps.form' and trashed = false");
  const url = `https://www.googleapis.com/drive/v3/files?q=${query}&fields=files(id,name,webViewLink,createdTime,modifiedTime)&pageSize=30&orderBy=modifiedTime desc`;

  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error?.message || `فشل في جلب النماذج (${res.status})`);
  }

  const data = await res.json();
  return data.files || [];
}

/**
 * Get Google Form details and questions by form ID
 */
export async function getGoogleFormDetails(formId: string): Promise<GoogleFormDetails> {
  const token = await getGoogleAccessToken();
  if (!token) throw new Error('يرجى تسجيل الدخول بحساب Google أولاً.');

  const safeFormId = encodeURIComponent(formId.trim());
  const res = await fetch(`https://forms.googleapis.com/v1/forms/${safeFormId}`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error?.message || `فشل في جلب تفاصيل النموذج (${res.status})`);
  }

  return await res.json();
}

/**
 * Get responses for a given Google Form
 */
export async function getGoogleFormResponses(formId: string): Promise<GoogleFormResponsesResult> {
  const token = await getGoogleAccessToken();
  if (!token) throw new Error('يرجى تسجيل الدخول بحساب Google أولاً.');

  const safeFormId = encodeURIComponent(formId.trim());
  const res = await fetch(`https://forms.googleapis.com/v1/forms/${safeFormId}/responses`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error?.message || `فشل في جلب ردود النموذج (${res.status})`);
  }

  return await res.json();
}

/**
 * Create a new Google Form with title and optional starter questions
 */
export async function createGoogleForm(
  title: string,
  description?: string,
  questions?: Array<{ title: string; type: 'RADIO' | 'CHECKBOX' | 'TEXT'; options?: string[] }>
): Promise<GoogleFormDetails> {
  const token = await getGoogleAccessToken();
  if (!token) throw new Error('يرجى تسجيل الدخول بحساب Google أولاً.');

  // 1. Create form
  const createRes = await fetch('https://forms.googleapis.com/v1/forms', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      info: {
        title: title.trim(),
        documentTitle: title.trim(),
      },
    }),
  });

  if (!createRes.ok) {
    const errorData = await createRes.json().catch(() => ({}));
    throw new Error(errorData.error?.message || `فشل في إنشاء النموذج (${createRes.status})`);
  }

  const createdForm: GoogleFormDetails = await createRes.json();
  const formId = createdForm.formId;

  // 2. Batch update to add description and questions if provided
  const requests: any[] = [];

  if (description) {
    requests.push({
      updateFormInfo: {
        info: {
          description,
        },
        updateMask: 'description',
      },
    });
  }

  if (questions && questions.length > 0) {
    questions.forEach((q, index) => {
      if (q.type === 'TEXT') {
        requests.push({
          createItem: {
            item: {
              title: q.title,
              questionItem: {
                question: {
                  required: true,
                  textQuestion: {
                    paragraph: false,
                  },
                },
              },
            },
            location: {
              index,
            },
          },
        });
      } else {
        requests.push({
          createItem: {
            item: {
              title: q.title,
              questionItem: {
                question: {
                  required: true,
                  choiceQuestion: {
                    type: q.type,
                    options: (q.options || ['نعم', 'لا']).map((opt) => ({ value: opt })),
                  },
                },
              },
            },
            location: {
              index,
            },
          },
        });
      }
    });
  }

  if (requests.length > 0) {
    const updateRes = await fetch(
      `https://forms.googleapis.com/v1/forms/${encodeURIComponent(formId)}:batchUpdate`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ requests }),
      }
    );

    if (updateRes.ok) {
      return await getGoogleFormDetails(formId);
    }
  }

  return createdForm;
}
