import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { members, squads } from "@/db/schema";

export const SESSION_COOKIE = "marvel_squad_session";
export const LEGACY_SESSION_COOKIE = "marvel_squad_id";
export const SESSION_MAX_AGE = 60 * 60 * 24 * 365 * 2; // 2 anni

export type SessionPayload = {
  id: number;
  squadCode: string;
  squadName: string;
  memberCode: string;
  name: string;
  avatar: string;
  color: string;
};

function encode(payload: SessionPayload) {
  return Buffer.from(JSON.stringify(payload), "utf8").toString("base64url");
}

function decode(raw: string): SessionPayload | null {
  // Formato legacy: conteneva solo l'id del membro.
  if (/^\d+$/.test(raw)) {
    const id = Number.parseInt(raw, 10);
    if (!Number.isFinite(id)) return null;
    return { id, squadCode: "", squadName: "", memberCode: "", name: "Eroe", avatar: "🦸", color: "#e62429" };
  }
  try {
    const parsed = JSON.parse(Buffer.from(raw, "base64url").toString("utf8")) as Partial<SessionPayload>;
    if (typeof parsed?.id !== "number") return null;
    return {
      id: parsed.id,
      squadCode: typeof parsed.squadCode === "string" ? parsed.squadCode : "",
      squadName: typeof parsed.squadName === "string" ? parsed.squadName : "",
      memberCode: typeof parsed.memberCode === "string" ? parsed.memberCode : "",
      name: typeof parsed.name === "string" ? parsed.name : "Eroe",
      avatar: typeof parsed.avatar === "string" ? parsed.avatar : "🦸",
      color: typeof parsed.color === "string" ? parsed.color : "#e62429",
    };
  } catch {
    return null;
  }
}

export function makeSessionToken(payload: SessionPayload) {
  return encode(payload);
}

export async function setSessionCookie(payload: SessionPayload) {
  const store = await cookies();
  store.set(SESSION_COOKIE, encode(payload), {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_MAX_AGE,
  });
}

export async function clearSessionCookie() {
  const store = await cookies();
  store.delete(SESSION_COOKIE);
}

type SessionRow = { member: typeof members.$inferSelect; squad: typeof squads.$inferSelect };

async function findByMemberCode(code: string): Promise<SessionRow | null> {
  const rows = await db
    .select({ member: members, squad: squads })
    .from(members)
    .innerJoin(squads, eq(members.squadId, squads.id))
    .where(eq(members.code, code))
    .limit(1);
  return rows[0] ?? null;
}

/**
 * Recupera la sessione. Se il database è stato ripristinato (o il membro non
 * esiste più) la sessione viene ricostruita in automatico dal cookie: l'utente
 * non viene mai buttato fuori.
 */
export async function getSessionMember(): Promise<SessionRow | null> {
  const store = await cookies();
  const raw = store.get(SESSION_COOKIE)?.value ?? store.get(LEGACY_SESSION_COOKIE)?.value ?? null;
  return getSessionFromToken(raw);
}

/**
 * Risolve la sessione partendo da un token: funziona sia con il cookie sia con
 * il token inviato dall'header (per i browser che bloccano i cookie).
 */
export async function getSessionFromToken(raw: string | null | undefined): Promise<SessionRow | null> {
  if (!raw) return null;

  const payload = decode(raw);
  if (!payload) return null;

  const byId = await db
    .select({ member: members, squad: squads })
    .from(members)
    .innerJoin(squads, eq(members.squadId, squads.id))
    .where(eq(members.id, payload.id))
    .limit(1);

  if (byId[0] && (!payload.squadCode || byId[0].squad.code === payload.squadCode)) {
    if (!payload.memberCode) {
      // Sessione in formato legacy: la aggiorno al nuovo formato.
      try {
        await setSessionCookie({
          id: byId[0].member.id,
          squadCode: byId[0].squad.code,
          squadName: byId[0].squad.name,
          memberCode: byId[0].member.code,
          name: byId[0].member.name,
          avatar: byId[0].member.avatar,
          color: byId[0].member.color,
        });
      } catch {
        // in un Server Component non possiamo scrivere cookie: ci pensa il middleware
      }
    }
    return byId[0];
  }

  if (!payload.memberCode) return null;
  const memberCode: string = payload.memberCode;

  const byCode = await findByMemberCode(memberCode);
  if (byCode) return byCode;

  if (!payload.squadCode) return null;
  const squadCode: string = payload.squadCode;

  try {
    let squad = (
      await db.select().from(squads).where(eq(squads.code, squadCode)).limit(1)
    )[0];

    if (!squad) {
      const inserted = await db
        .insert(squads)
        .values({
          name: payload.squadName || `Squadra di ${payload.name}`,
          code: squadCode,
        })
        .onConflictDoNothing()
        .returning();
      squad =
        inserted[0] ??
        (await db.select().from(squads).where(eq(squads.code, squadCode)).limit(1))[0];
    }

    if (!squad) return null;

    let member = (
      await db.select().from(members).where(eq(members.code, memberCode)).limit(1)
    )[0];

    if (!member) {
      const inserted = await db
        .insert(members)
        .values({
          squadId: squad.id,
          name: payload.name,
          avatar: payload.avatar,
          color: payload.color,
          code: memberCode,
        })
        .onConflictDoNothing()
        .returning();
      member =
        inserted[0] ??
        (await db.select().from(members).where(eq(members.code, memberCode)).limit(1))[0];
    }

    if (!member) return null;
    return { member, squad };
  } catch (error) {
    console.error("session recovery failed", error);
    return null;
  }
}

/**
 * Risolve la sessione da una richiesta HTTP: prima l'header x-marvel-session
 * (token salvato nel browser), poi il cookie.
 */
export async function getSessionFromRequest(request: Request): Promise<SessionRow | null> {
  const headerToken = request.headers.get("x-marvel-session");
  if (headerToken) {
    const fromHeader = await getSessionFromToken(headerToken);
    if (fromHeader) return fromHeader;
  }
  return getSessionMember();
}
