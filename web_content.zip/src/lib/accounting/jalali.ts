const FA = "۰۱۲۳۴۵۶۷۸۹";
const EN = "0123456789";

export function toFaDigits(value: string | number): string {
  return String(value).replace(/\d/g, (d) => FA[Number(d)] ?? d);
}

export function toEnDigits(value: string): string {
  let out = "";
  for (const ch of value) {
    const i = FA.indexOf(ch);
    out += i >= 0 ? EN[i] : ch;
  }
  return out;
}

export function gregorianToJalali(gy: number, gm: number, gd: number): [number, number, number] {
  const g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  const gy2 = gm > 2 ? gy + 1 : gy;
  let days =
    355666 +
    365 * gy +
    Math.floor((gy2 + 3) / 4) -
    Math.floor((gy2 + 99) / 100) +
    Math.floor((gy2 + 399) / 400) +
    gd +
    g_d_m[gm - 1];
  let jy = -1595 + 33 * Math.floor(days / 12053);
  days %= 12053;
  jy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    jy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  const jm = days < 186 ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30);
  const jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
  return [jy, jm, jd];
}

export function jalaliToGregorian(jy: number, jm: number, jd: number): [number, number, number] {
  jy += 1595;
  let days =
    -355668 +
    365 * jy +
    Math.floor(jy / 33) * 8 +
    Math.floor(((jy % 33) + 3) / 4) +
    jd +
    (jm < 7 ? (jm - 1) * 31 : (jm - 7) * 30 + 186);
  let gy = 400 * Math.floor(days / 146097);
  days %= 146097;
  if (days > 36524) {
    gy += 100 * Math.floor(--days / 36524);
    days %= 36524;
    if (days >= 365) days++;
  }
  gy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    gy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  let gd = days + 1;
  const sal_a = [
    0,
    31,
    (gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0 ? 29 : 28,
    31,
    30,
    31,
    30,
    31,
    31,
    30,
    31,
    30,
    31,
  ];
  let gm = 0;
  for (gm = 1; gm <= 12 && gd > sal_a[gm]; gm++) gd -= sal_a[gm];
  return [gy, gm, gd];
}

export function jalaliMonthDays(jy: number, jm: number): number {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  const leaps = [1, 5, 9, 13, 17, 22, 26, 30];
  return leaps.includes(jy % 33) ? 30 : 29;
}

export function pad2(n: number): string {
  return n < 10 ? `0${n}` : String(n);
}

export function formatJalaliParts(jy: number, jm: number, jd: number, fa = true): string {
  const s = `${jy}/${pad2(jm)}/${pad2(jd)}`;
  return fa ? toFaDigits(s) : s;
}

export function isoToJalali(iso: string, fa = true): string {
  const [y, m, d] = iso.slice(0, 10).split("-").map(Number);
  if (!y || !m || !d) return iso;
  const [jy, jm, jd] = gregorianToJalali(y, m, d);
  return formatJalaliParts(jy, jm, jd, fa);
}

export function dateToIso(date: Date): string {
  const y = date.getFullYear();
  const m = pad2(date.getMonth() + 1);
  const d = pad2(date.getDate());
  return `${y}-${m}-${d}`;
}

export function dateToJalali(date: Date, fa = true): string {
  const [jy, jm, jd] = gregorianToJalali(date.getFullYear(), date.getMonth() + 1, date.getDate());
  return formatJalaliParts(jy, jm, jd, fa);
}

export function jalaliToIso(jy: number, jm: number, jd: number): string {
  const [gy, gm, gd] = jalaliToGregorian(jy, jm, jd);
  return `${gy}-${pad2(gm)}-${pad2(gd)}`;
}

export function parseJalaliInput(value: string): string | null {
  const clean = toEnDigits(value).replace(/[^\d/]/g, "");
  const m = clean.match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/);
  if (!m) return null;
  const jy = Number(m[1]);
  const jm = Number(m[2]);
  const jd = Number(m[3]);
  if (jm < 1 || jm > 12 || jd < 1 || jd > jalaliMonthDays(jy, jm)) return null;
  return jalaliToIso(jy, jm, jd);
}

export function isoToJalaliTuple(iso: string): [number, number, number] {
  const [y, m, d] = iso.slice(0, 10).split("-").map(Number);
  return gregorianToJalali(y, m, d);
}

export function formatJalaliDateTime(date: Date, fa = true): string {
  const d = dateToJalali(date, fa);
  const t = `${pad2(date.getHours())}:${pad2(date.getMinutes())}`;
  return `${d} - ${fa ? toFaDigits(t) : t}`;
}

export const JALALI_MONTHS = [
  "فروردین",
  "اردیبهشت",
  "خرداد",
  "تیر",
  "مرداد",
  "شهریور",
  "مهر",
  "آبان",
  "آذر",
  "دی",
  "بهمن",
  "اسفند",
];

export const JALALI_WEEKDAYS = ["ش", "ی", "د", "س", "چ", "پ", "ج"];

export function fiscalYearOfIso(iso: string): number {
  const [jy] = isoToJalaliTuple(iso);
  return jy;
}

export function fyRange(code: number): { start: string; end: string } {
  return {
    start: jalaliToIso(code, 1, 1),
    end: jalaliToIso(code, 12, jalaliMonthDays(code, 12)),
  };
}

export function addDaysIso(iso: string, days: number): string {
  const dt = new Date(`${iso}T12:00:00`);
  dt.setDate(dt.getDate() + days);
  return dateToIso(dt);
}

export function todayIso(): string {
  return dateToIso(new Date());
}
