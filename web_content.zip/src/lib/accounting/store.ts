import { create } from "zustand";
import { persist } from "zustand/middleware";
import { blendCost, payLabel, priceDraft } from "./engine";
import { TODAY } from "./jalali";
import { RECIPES } from "./recipes";
import { buildSeed, trainingProducts } from "./seed";
import type { Draft, Invoice, JournalEntry, JournalLine, Product, Result, StockMove, View } from "./types";

const seed = buildSeed();

export function emptyDraft(): Draft {
  return {
    kind: "sale",
    date: TODAY,
    partyId: null,
    lines: [],
    discountMode: "amount",
    discountValue: 0,
    taxEnabled: true,
    shipping: 0,
    packing: 0,
    otherCost: 0,
    settlement: "full",
    method: "cash",
    splitCash: 0,
  };
}

function nid(prefix: string) {
  return prefix + Math.random().toString(36).slice(2, 9);
}

function balanced(lines: JournalLine[]) {
  const debit = lines.reduce((s, l) => s + l.debit, 0);
  const credit = lines.reduce((s, l) => s + l.credit, 0);
  return debit === credit && debit > 0;
}

type Persisted = {
  settings: typeof seed.settings;
  products: typeof seed.products;
  parties: typeof seed.parties;
  entries: typeof seed.entries;
  moves: typeof seed.moves;
  invoices: Invoice[];
  assets: typeof seed.assets;
  seq: typeof seed.seq;
};

type LedgerState = Persisted & {
  view: View;
  draft: Draft;
  focusInvoiceId: string | null;
  setView: (view: View) => void;
  patchDraft: (patch: Partial<Draft>) => void;
  resetDraft: (partyId?: string | null) => void;
  addLine: (productId: string) => void;
  setLineQty: (productId: string, qty: number) => void;
  setLinePrice: (productId: string, price: number) => void;
  applyVoiceLines: (partyId: string | null, lines: { productId: string; qty: number }[]) => void;
  postDraft: () => Result;
  setFocus: (id: string | null) => void;
  addProduct: (input: { name: string; group: string; unit: string; price: number; cost: number; qty: number; minQty: number; barcode: string }) => Result;
  updateProduct: (id: string, patch: Partial<Product>) => void;
  adjustStock: (productId: string, counted: number) => Result;
  addParty: (input: { name: string; phone: string }) => Result;
  postPurchase: (input: {
    date: string;
    partyId: string | null;
    lines: { productId: string; qty: number; cost: number }[];
    taxed: boolean;
    pay: "cash" | "bank" | "credit";
  }) => Result;
  postReceipt: (input: { date: string; partyId: string; amount: number; toBank: boolean }) => Result;
  postPayment: (input: { date: string; partyId: string; amount: number; fromBank: boolean }) => Result;
  postExpense: (input: { date: string; amount: number; desc: string; fromBank: boolean }) => Result;
  postTransfer: (input: { date: string; amount: number; toBank: boolean }) => Result;
  postDepreciation: (assetId: string) => Result;
  postProduction: (recipeId: string, qty: number) => Result;
  postManual: (input: { date: string; desc: string; lines: { accountCode: string; debit: number; credit: number }[] }) => Result;
  importCsv: (text: string) => Result;
  importRows: (rows: string[][]) => Result;
  loadTraining: () => Result;
  updateSettings: (patch: Partial<Persisted["settings"]>) => void;
  resetDemo: () => void;
};

function pushEntry(
  state: Persisted,
  partial: Omit<JournalEntry, "id" | "number" | "status">,
): { entries: JournalEntry[]; seq: Persisted["seq"] } {
  const entry: JournalEntry = {
    ...partial,
    id: nid("e"),
    number: String(state.seq.entry),
    status: "posted",
  };
  return { entries: [...state.entries, entry], seq: { ...state.seq, entry: state.seq.entry + 1 } };
}

export const useLedger = create<LedgerState>()(
  persist(
    (set, get) => ({
      ...seed,
      invoices: [],
      view: "home",
      draft: emptyDraft(),
      focusInvoiceId: null,
      setView: (view) => set({ view }),
      patchDraft: (patch) => set({ draft: { ...get().draft, ...patch } }),
      resetDraft: (partyId) => set({ draft: { ...emptyDraft(), partyId: partyId ?? null } }),
      addLine: (productId) => {
        const p = get().products.find((x) => x.id === productId);
        if (!p) return;
        const lines = get().draft.lines.slice();
        const hit = lines.find((l) => l.productId === productId);
        if (hit) hit.qty += 1;
        else lines.push({ productId, qty: 1, price: p.price });
        set({ draft: { ...get().draft, lines } });
      },
      setLineQty: (productId, qty) => {
        const lines = get()
          .draft.lines.map((l) => (l.productId === productId ? { ...l, qty } : l))
          .filter((l) => l.qty > 0);
        set({ draft: { ...get().draft, lines } });
      },
      setLinePrice: (productId, price) => {
        const lines = get().draft.lines.map((l) => (l.productId === productId ? { ...l, price } : l));
        set({ draft: { ...get().draft, lines } });
      },
      applyVoiceLines: (partyId, voiced) => {
        const products = get().products;
        const lines = get().draft.lines.slice();
        for (const v of voiced) {
          const p = products.find((x) => x.id === v.productId);
          if (!p) continue;
          const hit = lines.find((l) => l.productId === v.productId);
          if (hit) hit.qty += v.qty;
          else lines.push({ productId: v.productId, qty: v.qty, price: p.price });
        }
        set({
          draft: { ...get().draft, kind: "sale", partyId: partyId ?? get().draft.partyId, lines },
          view: "invoice",
        });
      },
      postDraft: () => {
        const s = get();
        const priced = priceDraft(s.draft, s.products, s.settings);
        if (!priced.lines.length) return { ok: false, message: "حداقل یک کالا به فاکتور اضافه کنید." };
        if (priced.total <= 0) return { ok: false, message: "مبلغ فاکتور باید بیشتر از صفر باشد." };
        if (s.draft.settlement === "credit" && !s.draft.partyId) {
          return { ok: false, message: "برای فروش نسیه، مشتری را انتخاب کنید." };
        }
        const party = s.parties.find((p) => p.id === s.draft.partyId);
        const number = s.seq.invoice;
        const invoiceId = nid("inv");
        const invoice: Invoice = {
          id: invoiceId,
          number,
          date: s.draft.date,
          partyName: party?.name ?? "مشتری متفرقه",
          partyPhone: party?.phone ?? "",
          kind: s.draft.kind,
          lines: priced.lines.map((l) => ({ name: l.name, qty: l.qty, price: l.price, amount: l.amount })),
          gross: priced.gross,
          discount: priced.discount,
          tax: priced.tax,
          extras: priced.extras,
          total: priced.total,
          payLabel: s.draft.kind === "proforma" ? "پیش‌فاکتور" : payLabel(s.draft),
          status: s.draft.kind === "proforma" ? "draft" : "posted",
        };
        if (s.draft.kind === "proforma") {
          set({
            invoices: [invoice, ...s.invoices],
            seq: { ...s.seq, invoice: number + 1 },
            focusInvoiceId: invoiceId,
          });
          return { ok: true, message: "پیش‌فاکتور ذخیره شد و در دفاتر ننشست.", invoiceId };
        }
        const desc = party ? `فروش به ${party.name}` : "فروش نقدی";
        const lines: JournalLine[] = [];
        const tag = `فاکتور ${number}`;
        if (s.draft.settlement === "credit") {
          lines.push({ accountCode: "1200", debit: priced.total, credit: 0, desc: tag, partyId: party?.id });
        } else if (s.draft.settlement === "multi") {
          const cash = Math.max(0, Math.min(Math.round(s.draft.splitCash), priced.total));
          const bank = priced.total - cash;
          if (cash) lines.push({ accountCode: "1100", debit: cash, credit: 0, desc: tag + " نقد" });
          if (bank) lines.push({ accountCode: "1110", debit: bank, credit: 0, desc: tag + " بانک" });
        } else if (s.draft.method === "card") {
          lines.push({ accountCode: "1110", debit: priced.total, credit: 0, desc: tag });
        } else {
          lines.push({ accountCode: "1100", debit: priced.total, credit: 0, desc: tag });
        }
        const sales = priced.net + priced.extras;
        if (sales) lines.push({ accountCode: "4100", debit: 0, credit: sales, desc: tag });
        if (priced.tax) lines.push({ accountCode: "2200", debit: 0, credit: priced.tax, desc: "مالیات " + tag });
        if (priced.cogs) {
          lines.push({ accountCode: "5100", debit: priced.cogs, credit: 0, desc: "بهای " + tag });
          lines.push({ accountCode: "1300", debit: 0, credit: priced.cogs, desc: "خروج " + tag });
        }
        if (!balanced(lines)) return { ok: false, message: "سند نامتوازن شد و ثبت نشد." };
        const moved = pushEntry(s, { date: s.draft.date, desc, source: "sale", ref: invoiceId, lines });
        const stock: StockMove[] = priced.lines.map((l) => ({
          id: nid("m"),
          date: s.draft.date,
          productId: l.productId,
          qty: -l.qty,
          cost: l.cost,
          ref: invoiceId,
          kind: "sale",
        }));
        const products = s.products.map((p) => {
          const q = priced.lines.filter((l) => l.productId === p.id).reduce((a, l) => a + l.qty, 0);
          return q ? { ...p, qty: p.qty - q } : p;
        });
        const negative = products.some((p) => p.qty < 0);
        set({
          products,
          entries: moved.entries,
          moves: [...s.moves, ...stock],
          invoices: [invoice, ...s.invoices],
          seq: { ...moved.seq, invoice: number + 1 },
          focusInvoiceId: invoiceId,
          draft: emptyDraft(),
        });
        return {
          ok: true,
          message: negative ? "فاکتور ثبت شد. موجودی یک کالا منفی شده؛ در کنترل روزانه ببینید." : "فاکتور ثبت و سند دوبل صادر شد.",
          invoiceId,
        };
      },
      setFocus: (id) => set({ focusInvoiceId: id }),
      addProduct: (input) => {
        const name = input.name.trim();
        if (!name) return { ok: false, message: "نام کالا لازم است." };
        if (input.price <= 0) return { ok: false, message: "قیمت فروش را وارد کنید." };
        const s = get();
        const product: Product = {
          id: nid("p"),
          name,
          barcode: input.barcode.trim() || "626" + String(Date.now()).slice(-8),
          group: input.group || "سایر",
          unit: input.unit || "عدد",
          icon: "package",
          qty: 0,
          price: Math.round(input.price),
          cost: Math.round(input.cost || Math.round(input.price * 0.7)),
          minQty: input.minQty || 0,
        };
        let products = [...s.products, product];
        let entries = s.entries;
        let moves = s.moves;
        let seq = s.seq;
        if (input.qty > 0) {
          const value = input.qty * product.cost;
          const moved = pushEntry({ ...s, seq }, {
            date: TODAY,
            desc: "موجودی اولیه " + name,
            source: "adjust",
            lines: [
              { accountCode: "1300", debit: value, credit: 0, desc: "ورود اول دوره" },
              { accountCode: "3100", debit: 0, credit: value, desc: "از محل سرمایه" },
            ],
          });
          entries = moved.entries;
          seq = moved.seq;
          products = products.map((p) => (p.id === product.id ? { ...p, qty: input.qty } : p));
          moves = [...moves, { id: nid("m"), date: TODAY, productId: product.id, qty: input.qty, cost: product.cost, ref: "opening", kind: "opening" }];
        }
        set({ products, entries, moves, seq });
        return { ok: true, message: "کالا ثبت شد." };
      },
      updateProduct: (id, patch) => {
        set({
          products: get().products.map((p) => (p.id === id ? { ...p, ...patch, id: p.id, qty: p.qty } : p)),
        });
      },
      adjustStock: (productId, counted) => {
        const s = get();
        const p = s.products.find((x) => x.id === productId);
        if (!p) return { ok: false, message: "کالا پیدا نشد." };
        const diff = Math.round(counted) - p.qty;
        if (diff === 0) return { ok: false, message: "موجودی تغییری نکرده." };
        const value = Math.abs(diff) * p.cost;
        const lines: JournalLine[] =
          diff > 0
            ? [
                { accountCode: "1300", debit: value, credit: 0, desc: "اضافه انبارش " + p.name },
                { accountCode: "3100", debit: 0, credit: value, desc: "اصلاح موجودی" },
              ]
            : [
                { accountCode: "3100", debit: value, credit: 0, desc: "کسری انبارش " + p.name },
                { accountCode: "1300", debit: 0, credit: value, desc: "اصلاح موجودی" },
              ];
        const moved = pushEntry(s, { date: TODAY, desc: "اصلاح موجودی " + p.name, source: "adjust", lines });
        set({
          entries: moved.entries,
          seq: moved.seq,
          products: s.products.map((x) => (x.id === p.id ? { ...x, qty: Math.round(counted) } : x)),
          moves: [...s.moves, { id: nid("m"), date: TODAY, productId: p.id, qty: diff, cost: p.cost, ref: "adjust", kind: "adjust" }],
        });
        return { ok: true, message: "موجودی اصلاح و سند صادر شد." };
      },
      addParty: (input) => {
        const name = input.name.trim();
        if (name.length < 2) return { ok: false, message: "نام شخص را کامل‌تر بنویسید." };
        set({ parties: [...get().parties, { id: nid("c"), name, phone: input.phone.trim() }] });
        return { ok: true, message: "شخص ثبت شد." };
      },
      postPurchase: (input) => {
        const s = get();
        const clean = input.lines
          .map((l) => ({ productId: l.productId, qty: Math.round(l.qty), cost: Math.round(l.cost) }))
          .filter((l) => l.productId && l.qty > 0 && l.cost > 0);
        if (!clean.length) return { ok: false, message: "حداقل یک ردیف خرید با تعداد و بها لازم است." };
        if (input.pay === "credit" && !input.partyId) return { ok: false, message: "برای خرید نسیه، فروشنده را انتخاب کنید." };
        const party = s.parties.find((x) => x.id === input.partyId);
        const picked = clean.map((l) => ({ ...l, product: s.products.find((p) => p.id === l.productId) }));
        if (picked.some((l) => !l.product)) return { ok: false, message: "یکی از کالاها پیدا نشد." };
        const net = picked.reduce((sum, l) => sum + l.qty * l.cost, 0);
        const tax = input.taxed ? Math.round((net * s.settings.taxRate) / 100) : 0;
        const total = net + tax;
        const creditAccount = input.pay === "bank" ? "1110" : input.pay === "credit" ? "2100" : "1100";
        const creditDesc = input.pay === "bank" ? "پرداخت از بانک" : input.pay === "credit" ? "خرید نسیه" : "پرداخت از صندوق";
        const lines: JournalLine[] = [{ accountCode: "1300", debit: net, credit: 0, desc: "ورود خرید" }];
        if (tax) lines.push({ accountCode: "1400", debit: tax, credit: 0, desc: "مالیات خرید" });
        lines.push({
          accountCode: creditAccount,
          debit: 0,
          credit: total,
          desc: creditDesc,
          partyId: input.pay === "credit" ? party?.id : undefined,
        });
        if (!balanced(lines)) return { ok: false, message: "سند خرید نامتوازن است." };
        const moved = pushEntry(s, {
          date: input.date,
          desc: "خرید " + picked.map((l) => l.product!.name).slice(0, 2).join("، ") + (party ? " از " + party.name : ""),
          source: "purchase",
          lines,
        });
        let products = s.products.slice();
        const stock: StockMove[] = [];
        for (const line of picked) {
          const current = products.find((p) => p.id === line.productId)!;
          const cost = blendCost(current.qty, current.cost, line.qty, line.cost);
          products = products.map((p) => (p.id === line.productId ? { ...p, qty: p.qty + line.qty, cost } : p));
          stock.push({
            id: nid("m"),
            date: input.date,
            productId: line.productId,
            qty: line.qty,
            cost: line.cost,
            ref: "purchase",
            kind: "purchase",
          });
        }
        set({ entries: moved.entries, seq: moved.seq, products, moves: [...s.moves, ...stock] });
        return { ok: true, message: "خرید ثبت شد. موجودی و میانگین بها به‌روز شد." };
      },
      postReceipt: (input) => {
        const s = get();
        const party = s.parties.find((p) => p.id === input.partyId);
        if (!party) return { ok: false, message: "شخص را انتخاب کنید." };
        if (input.amount <= 0) return { ok: false, message: "مبلغ دریافت را وارد کنید." };
        const amount = Math.round(input.amount);
        const account = input.toBank ? "1110" : "1100";
        const moved = pushEntry(s, {
          date: input.date,
          desc: "دریافت از " + party.name,
          source: "receipt",
          lines: [
            { accountCode: account, debit: amount, credit: 0, desc: "دریافت" },
            { accountCode: "1200", debit: 0, credit: amount, desc: "تسویه دریافتنی", partyId: party.id },
          ],
        });
        set({ entries: moved.entries, seq: moved.seq });
        return { ok: true, message: "دریافت ثبت شد." };
      },
      postPayment: (input) => {
        const s = get();
        const party = s.parties.find((p) => p.id === input.partyId);
        if (!party) return { ok: false, message: "شخص را انتخاب کنید." };
        if (input.amount <= 0) return { ok: false, message: "مبلغ پرداخت را وارد کنید." };
        const amount = Math.round(input.amount);
        const account = input.fromBank ? "1110" : "1100";
        const moved = pushEntry(s, {
          date: input.date,
          desc: "پرداخت به " + party.name,
          source: "payment",
          lines: [
            { accountCode: "2100", debit: amount, credit: 0, desc: "تسویه پرداختنی", partyId: party.id },
            { accountCode: account, debit: 0, credit: amount, desc: "پرداخت" },
          ],
        });
        set({ entries: moved.entries, seq: moved.seq });
        return { ok: true, message: "پرداخت ثبت شد." };
      },
      postExpense: (input) => {
        const s = get();
        if (input.amount <= 0 || !input.desc.trim()) return { ok: false, message: "شرح و مبلغ هزینه لازم است." };
        const amount = Math.round(input.amount);
        const account = input.fromBank ? "1110" : "1100";
        const moved = pushEntry(s, {
          date: input.date,
          desc: input.desc.trim(),
          source: "expense",
          lines: [
            { accountCode: "5200", debit: amount, credit: 0, desc: input.desc.trim() },
            { accountCode: account, debit: 0, credit: amount, desc: "پرداخت هزینه" },
          ],
        });
        set({ entries: moved.entries, seq: moved.seq });
        return { ok: true, message: "هزینه ثبت شد." };
      },
      postTransfer: (input) => {
        const s = get();
        if (input.amount <= 0) return { ok: false, message: "مبلغ انتقال را وارد کنید." };
        const amount = Math.round(input.amount);
        const lines: JournalLine[] = input.toBank
          ? [
              { accountCode: "1110", debit: amount, credit: 0, desc: "واریز به بانک" },
              { accountCode: "1100", debit: 0, credit: amount, desc: "برداشت از صندوق" },
            ]
          : [
              { accountCode: "1100", debit: amount, credit: 0, desc: "واریز به صندوق" },
              { accountCode: "1110", debit: 0, credit: amount, desc: "برداشت از بانک" },
            ];
        const moved = pushEntry(s, {
          date: input.date,
          desc: input.toBank ? "انتقال صندوق به بانک" : "انتقال بانک به صندوق",
          source: "transfer",
          lines,
        });
        set({ entries: moved.entries, seq: moved.seq });
        return { ok: true, message: "انتقال ثبت شد." };
      },
      postDepreciation: (assetId) => {
        const s = get();
        const asset = s.assets.find((a) => a.id === assetId);
        if (!asset) return { ok: false, message: "دارایی پیدا نشد." };
        const monthly = Math.round(asset.cost / asset.months);
        const remain = asset.cost - asset.accumulated;
        if (remain <= 0) return { ok: false, message: "این دارایی کاملاً مستهلک شده." };
        const amount = Math.min(monthly, remain);
        const moved = pushEntry(s, {
          date: TODAY,
          desc: "استهلاک " + asset.name,
          source: "depreciation",
          lines: [
            { accountCode: "5300", debit: amount, credit: 0, desc: "هزینه استهلاک ماه" },
            { accountCode: "2300", debit: 0, credit: amount, desc: "استهلاک انباشته" },
          ],
        });
        set({
          entries: moved.entries,
          seq: moved.seq,
          assets: s.assets.map((a) => (a.id === asset.id ? { ...a, accumulated: a.accumulated + amount } : a)),
        });
        return { ok: true, message: "استهلاک این ماه ثبت شد." };
      },
      postProduction: (recipeId, qty) => {
        const s = get();
        const recipe = RECIPES.find((r) => r.id === recipeId);
        if (!recipe || qty <= 0) return { ok: false, message: "تعداد تولید را وارد کنید." };
        const needs = recipe.inputs.map((inp) => {
          const p = s.products.find((x) => x.name === inp.name);
          return { inp, p, need: inp.qty * qty };
        });
        if (needs.some((n) => !n.p)) return { ok: false, message: "مواد اولیه در کالاها پیدا نشد." };
        const short = needs.find((n) => n.p!.qty < n.need);
        if (short) return { ok: false, message: `موجودی ${short.p!.name} برای این تولید کافی نیست.` };
        const cost = needs.reduce((sum, n) => sum + n.need * n.p!.cost, 0);
        let out = s.products.find((p) => p.name === recipe.name);
        let products = s.products.slice();
        if (!out) {
          out = {
            id: nid("p"),
            name: recipe.name,
            barcode: "626300" + recipe.id.slice(0, 6),
            group: "تولید",
            unit: "عدد",
            icon: recipe.icon,
            qty: 0,
            price: recipe.price,
            cost: Math.round(cost / qty),
            minQty: 2,
          };
          products = [...products, out];
        }
        const outId = out.id;
        const unitCost = Math.round(cost / qty);
        const blended = blendCost(out.qty, out.cost, qty, unitCost);
        products = products.map((p) => {
          const need = needs.find((n) => n.p!.id === p.id);
          if (need) return { ...p, qty: p.qty - need.need };
          if (p.id === outId) return { ...p, qty: p.qty + qty, cost: blended };
          return p;
        });
        const moves: StockMove[] = [
          ...needs.map((n) => ({
            id: nid("m"),
            date: TODAY,
            productId: n.p!.id,
            qty: -n.need,
            cost: n.p!.cost,
            ref: recipe.id,
            kind: "consume" as const,
          })),
          { id: nid("m"), date: TODAY, productId: outId, qty, cost: unitCost, ref: recipe.id, kind: "produce" },
        ];
        const moved = pushEntry(s, {
          date: TODAY,
          desc: "تولید " + recipe.name,
          source: "production",
          lines: [
            { accountCode: "1300", debit: cost, credit: 0, desc: "کالای ساخته‌شده" },
            { accountCode: "1300", debit: 0, credit: cost, desc: "مصرف مواد" },
          ],
        });
        set({ products, moves: [...s.moves, ...moves], entries: moved.entries, seq: moved.seq });
        return { ok: true, message: "تولید ثبت شد. ارزش موجودی جابه‌جا شد و تراز دست نخورد." };
      },
      postManual: (input) => {
        const s = get();
        const lines: JournalLine[] = input.lines
          .map((l) => ({
            accountCode: l.accountCode,
            debit: Math.round(l.debit || 0),
            credit: Math.round(l.credit || 0),
            desc: input.desc.trim() || "سند دستی",
          }))
          .filter((l) => l.debit > 0 || l.credit > 0);
        if (lines.length < 2) return { ok: false, message: "حداقل دو ردیف برای سند لازم است." };
        if (lines.some((l) => l.debit > 0 && l.credit > 0)) return { ok: false, message: "در هر ردیف فقط بدهکار یا بستانکار را پر کنید." };
        if (!balanced(lines)) return { ok: false, message: "جمع بدهکار و بستانکار برابر نیست." };
        const moved = pushEntry(s, { date: input.date, desc: input.desc.trim() || "سند دستی", source: "manual", lines });
        set({ entries: moved.entries, seq: moved.seq });
        return { ok: true, message: "سند دستی در دفتر روزنامه نشست." };
      },
      importCsv: (text) => get().importRows(parseCsv(text)),
      importRows: (rows) => {
        if (rows.length < 2) return { ok: false, message: "فایل خالی است یا سطر عنوان ندارد." };
        const head = rows[0].map((c) => c.replace(/\s/g, "").toLowerCase());
        const idx = (names: string[]) => head.findIndex((h) => names.some((n) => h.includes(n)));
        const iName = idx(["نام", "name", "شرح", "کالا"]);
        const iQty = idx(["موجود", "تعداد", "qty"]);
        const iPrice = idx(["قیمت", "فروش", "price"]);
        const iCost = idx(["بها", "تمام", "cost", "خرید"]);
        const iGroup = idx(["گروه", "group"]);
        const iBarcode = idx(["بارکد", "barcode", "کد"]);
        const iUnit = idx(["واحد", "unit"]);
        const iMin = idx(["حداقل", "min"]);
        if (iName < 0) return { ok: false, message: "ستون «نام» در فایل پیدا نشد." };
        const s = get();
        let products = s.products.slice();
        let added = 0;
        let value = 0;
        const newMoves: StockMove[] = [];
        for (const row of rows.slice(1)) {
          const name = (row[iName] ?? "").trim();
          if (!name || products.some((p) => p.name === name)) continue;
          const qty = Math.round(Number(String(row[iQty] ?? "0").replace(/[^\d.-]/g, "")) || 0);
          const price = Math.round(Number(String(row[iPrice] ?? "0").replace(/[^\d.-]/g, "")) || 0);
          const costRaw = iCost >= 0 ? Math.round(Number(String(row[iCost] ?? "0").replace(/[^\d.-]/g, "")) || 0) : 0;
          const cost = costRaw || Math.round(price * 0.7) || 1000;
          const product: Product = {
            id: nid("p"),
            name,
            barcode: (iBarcode >= 0 ? row[iBarcode] : "") || "626" + String(800000 + added),
            group: (iGroup >= 0 ? row[iGroup] : "") || "سایر",
            unit: (iUnit >= 0 ? row[iUnit] : "") || "عدد",
            icon: "package",
            qty: Math.max(0, qty),
            price: price || cost,
            cost,
            minQty: iMin >= 0 ? Math.round(Number(row[iMin]) || 0) : 5,
          };
          products = [...products, product];
          if (product.qty > 0) {
            value += product.qty * product.cost;
            newMoves.push({ id: nid("m"), date: TODAY, productId: product.id, qty: product.qty, cost: product.cost, ref: "import", kind: "opening" });
          }
          added += 1;
        }
        if (!added) return { ok: false, message: "کالای جدیدی در فایل نبود." };
        let entries = s.entries;
        let seq = s.seq;
        if (value > 0) {
          const moved = pushEntry({ ...s, seq }, {
            date: TODAY,
            desc: "ورود موجودی از اکسل",
            source: "adjust",
            lines: [
              { accountCode: "1300", debit: value, credit: 0, desc: "کالاهای فایل" },
              { accountCode: "3100", debit: 0, credit: value, desc: "از محل سرمایه" },
            ],
          });
          entries = moved.entries;
          seq = moved.seq;
        }
        set({ products, entries, moves: [...s.moves, ...newMoves], seq });
        return { ok: true, message: `${added} کالا از فایل وارد شد.` };
      },
      loadTraining: () => {
        const s = get();
        const extras = trainingProducts().filter((p) => !s.products.some((x) => x.name === p.name));
        if (!extras.length) return { ok: false, message: "فایل آموزشی قبلاً وارد شده است." };
        const value = extras.reduce((sum, p) => sum + p.qty * p.cost, 0);
        const moved = pushEntry(s, {
          date: TODAY,
          desc: "ورود فایل آموزشی کالا",
          source: "adjust",
          lines: [
            { accountCode: "1300", debit: value, credit: 0, desc: "کالاهای آموزشی" },
            { accountCode: "3100", debit: 0, credit: value, desc: "از محل سرمایه" },
          ],
        });
        const moves: StockMove[] = extras.map((p) => ({
          id: nid("m"),
          date: TODAY,
          productId: p.id,
          qty: p.qty,
          cost: p.cost,
          ref: "training",
          kind: "opening",
        }));
        set({
          products: [...s.products, ...extras],
          entries: moved.entries,
          seq: moved.seq,
          moves: [...s.moves, ...moves],
        });
        return { ok: true, message: `فایل آموزشی خوانده شد: ${s.products.length + extras.length} کالا و ${s.parties.length} مشتری.` };
      },
      updateSettings: (patch) => set({ settings: { ...get().settings, ...patch } }),
      resetDemo: () => {
        const fresh = buildSeed();
        set({
          ...fresh,
          invoices: [],
          view: "home",
          draft: emptyDraft(),
          focusInvoiceId: null,
        });
      },
    }),
    {
      name: "kaseba-ledger-v1",
      partialize: (s) => ({
        settings: s.settings,
        products: s.products,
        parties: s.parties,
        entries: s.entries,
        moves: s.moves,
        invoices: s.invoices,
        assets: s.assets,
        seq: s.seq,
      }),
      merge: (persisted, current) => {
        if (!persisted || typeof persisted !== "object") return current;
        const p = persisted as Partial<Persisted>;
        if (!Array.isArray(p.products) || !Array.isArray(p.entries) || !p.settings || !p.seq) return current;
        return {
          ...current,
          ...p,
          view: "home",
          draft: emptyDraft(),
          focusInvoiceId: null,
        };
      },
    },
  ),
);

export function parseCsv(text: string) {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;
  const src = text.replace(/^\uFEFF/, "");
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (quoted) {
      if (ch === '"') {
        if (src[i + 1] === '"') {
          cell += '"';
          i += 1;
        } else quoted = false;
      } else cell += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === "," || ch === ";" || ch === "\t") {
      row.push(cell.trim());
      cell = "";
    } else if (ch === "\n") {
      row.push(cell.trim());
      rows.push(row);
      row = [];
      cell = "";
    } else if (ch !== "\r") cell += ch;
  }
  if (cell.length || row.length) {
    row.push(cell.trim());
    rows.push(row);
  }
  return rows.filter((r) => r.some((c) => c));
}

export function productsCsv(products: Product[]) {
  const head = ["نام", "بارکد", "گروه", "واحد", "موجودی", "قیمت", "بهای تمام‌شده", "حداقل"];
  const lines = products.map((p) => [p.name, p.barcode, p.group, p.unit, p.qty, p.price, p.cost, p.minQty].join(","));
  return "\uFEFF" + [head.join(","), ...lines].join("\n");
}

export async function rowsFromFile(file: File) {
  const lower = file.name.toLowerCase();
  if (lower.endsWith(".xlsx") || lower.endsWith(".xls")) {
    const XLSX = await import("xlsx");
    const data = new Uint8Array(await file.arrayBuffer());
    const book = XLSX.read(data, { type: "array" });
    const sheet = book.Sheets[book.SheetNames[0]];
    if (!sheet) return [];
    const grid = XLSX.utils.sheet_to_json<(string | number | boolean | null)[]>(sheet, {
      header: 1,
      raw: false,
      defval: "",
    });
    return grid
      .map((row) => (Array.isArray(row) ? row : []).map((cell) => String(cell ?? "").trim()))
      .filter((row) => row.some((cell) => cell));
  }
  return parseCsv(await file.text());
}
