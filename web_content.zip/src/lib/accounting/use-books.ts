import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  bootstrapCompany,
  getDashboard,
  getHealth,
  getJournalBook,
  getPartyCard,
  getStatements,
  getTrialBalance,
  listAudit,
  listChecks,
  listOperations,
} from "./actions";
import type { AccountRow, CashAccountRow } from "./types";
import type { Books } from "./engine";

export function useBootstrap() {
  return useQuery({
    queryKey: ["bootstrap"],
    queryFn: () => bootstrapCompany(),
  });
}

export function booksFromBootstrap(data: NonNullable<ReturnType<typeof useBootstrap>["data"]>): Books {
  const accountsById = new Map<string, AccountRow>();
  const accountsByCode = new Map<string, AccountRow>();
  for (const a of data.accounts) {
    const row: AccountRow = {
      id: a.id,
      code: a.code,
      name: a.name,
      level: a.level,
      parentId: null,
      groupCode: a.groupCode as AccountRow["groupCode"],
      nature: a.nature as "debit" | "credit",
      isPostable: a.isPostable,
      isActive: true,
      floatingType: a.floatingType as AccountRow["floatingType"],
    };
    accountsById.set(row.id, row);
    accountsByCode.set(row.code, row);
  }
  const cashById = new Map<string, CashAccountRow>();
  for (const c of data.cashAccounts) {
    cashById.set(c.id, {
      id: c.id,
      accountId: c.accountId,
      name: c.name,
      kind: c.kind as CashAccountRow["kind"],
      bankName: c.bankName,
      accountNumber: c.accountNumber,
      isActive: true,
    });
  }
  return { accountsById, accountsByCode, cashById };
}

export function useDashboard() {
  return useQuery({ queryKey: ["dashboard"], queryFn: () => getDashboard() });
}

export function useOperations(filters: { from?: string; to?: string; opType?: string; q?: string }) {
  return useQuery({
    queryKey: ["operations", filters],
    queryFn: () => listOperations({ data: filters }),
  });
}

export function useTrial(from: string, to: string) {
  return useQuery({
    queryKey: ["trial", from, to],
    queryFn: () => getTrialBalance({ data: { from, to } }),
  });
}

export function useStatements(from: string, to: string) {
  return useQuery({
    queryKey: ["statements", from, to],
    queryFn: () => getStatements({ data: { from, to } }),
  });
}

export function useJournalBook(from: string, to: string) {
  return useQuery({
    queryKey: ["journal-book", from, to],
    queryFn: () => getJournalBook({ data: { from, to } }),
  });
}

export function useParties() {
  return useQuery({ queryKey: ["parties"], queryFn: () => getPartyCard() });
}

export function useChecks() {
  return useQuery({ queryKey: ["checks"], queryFn: () => listChecks() });
}

export function useAudit() {
  return useQuery({ queryKey: ["audit"], queryFn: () => listAudit() });
}

export function useHealth() {
  return useQuery({ queryKey: ["health"], queryFn: () => getHealth() });
}

export function useInvalidateBooks() {
  const qc = useQueryClient();
  return () =>
    qc.invalidateQueries({
      predicate: (q) => true,
    });
}
