import type { AccountType } from "./types";

export const CHART: { code: string; name: string; type: AccountType }[] = [
  { code: "1100", name: "صندوق", type: "asset" },
  { code: "1110", name: "بانک", type: "asset" },
  { code: "1200", name: "حساب‌های دریافتنی", type: "asset" },
  { code: "1300", name: "موجودی کالا", type: "asset" },
  { code: "1400", name: "مالیات ارزش افزوده خرید", type: "asset" },
  { code: "1500", name: "دارایی ثابت", type: "asset" },
  { code: "2100", name: "حساب‌های پرداختنی", type: "liability" },
  { code: "2200", name: "مالیات ارزش افزوده فروش", type: "liability" },
  { code: "2300", name: "استهلاک انباشته", type: "liability" },
  { code: "3100", name: "سرمایه", type: "equity" },
  { code: "4100", name: "فروش", type: "income" },
  { code: "5100", name: "بهای تمام‌شده", type: "expense" },
  { code: "5200", name: "هزینه‌های عمومی", type: "expense" },
  { code: "5300", name: "هزینه استهلاک", type: "expense" },
];

export function accountName(code: string) {
  return CHART.find((a) => a.code === code)?.name ?? code;
}

export function accountType(code: string) {
  return CHART.find((a) => a.code === code)?.type ?? "asset";
}

export function isDebitNature(code: string) {
  const t = accountType(code);
  return t === "asset" || t === "expense";
}

export const SOURCE_LABEL: Record<string, string> = {
  opening: "افتتاحیه",
  sale: "فروش",
  purchase: "خرید",
  receipt: "دریافت",
  payment: "پرداخت",
  expense: "هزینه",
  transfer: "انتقال",
  depreciation: "استهلاک",
  production: "تولید",
  adjust: "اصلاح",
  manual: "سند دستی",
};

export const GROUPS = [
  "نوشیدنی",
  "خواربار",
  "بهداشت",
  "تنقلات",
  "لوازم‌التحریر",
  "الکتریکی",
  "لبنیات",
  "کنسرو",
  "تولید",
  "سایر",
];
