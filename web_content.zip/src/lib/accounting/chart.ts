import type { AccountType, Nature } from "./types";

export type ChartSeed = {
  code: string;
  name: string;
  level: 1 | 2 | 3 | 4;
  parent?: string;
  type: AccountType;
  nature: Nature;
  isCash?: boolean;
  isBank?: boolean;
  isParty?: boolean;
  partyKind?: string;
  sourceKind?: "cash" | "bank" | "petty";
  bankName?: string;
};

const IRANIAN_BANKS: { code: string; name: string }[] = [
  { code: "1121", name: "بانک ملی ایران" },
  { code: "1122", name: "بانک ملت" },
  { code: "1123", name: "بانک صادرات ایران" },
  { code: "1124", name: "بانک تجارت" },
  { code: "1125", name: "بانک سپه" },
  { code: "1126", name: "بانک رفاه کارگران" },
  { code: "1127", name: "بانک کشاورزی" },
  { code: "1128", name: "بانک مسکن" },
  { code: "1129", name: "بانک پارسیان" },
  { code: "1130", name: "بانک سامان" },
];

export const CHART: ChartSeed[] = [
  { code: "1", name: "دارایی‌ها", level: 1, type: "asset", nature: "debit" },
  { code: "2", name: "بدهی‌ها", level: 1, type: "liability", nature: "credit" },
  { code: "3", name: "سرمایه", level: 1, type: "equity", nature: "credit" },
  { code: "4", name: "درآمدها", level: 1, type: "income", nature: "credit" },
  { code: "5", name: "بهای تمام‌شده", level: 1, type: "cogs", nature: "debit" },
  { code: "6", name: "هزینه‌ها", level: 1, type: "expense", nature: "debit" },
  { code: "8", name: "حساب‌های انتظامی", level: 1, type: "memorandum", nature: "debit" },
  { code: "9", name: "حساب‌های کنترلی", level: 1, type: "control", nature: "debit" },

  { code: "11", name: "موجودی نقد و بانک", level: 2, parent: "1", type: "asset", nature: "debit" },
  { code: "12", name: "حساب‌ها و اسناد دریافتنی", level: 2, parent: "1", type: "asset", nature: "debit" },
  { code: "13", name: "موجودی کالا", level: 2, parent: "1", type: "asset", nature: "debit" },
  { code: "14", name: "پیش‌پرداخت‌ها و سپرده‌ها", level: 2, parent: "1", type: "asset", nature: "debit" },
  { code: "15", name: "دارایی‌های ثابت", level: 2, parent: "1", type: "asset", nature: "debit" },

  { code: "21", name: "حساب‌ها و اسناد پرداختنی", level: 2, parent: "2", type: "liability", nature: "credit" },
  { code: "22", name: "مالیات، بیمه و حقوق", level: 2, parent: "2", type: "liability", nature: "credit" },
  { code: "23", name: "پیش‌دریافت‌ها و سایر بدهی‌ها", level: 2, parent: "2", type: "liability", nature: "credit" },

  { code: "31", name: "حقوق صاحبان سرمایه", level: 2, parent: "3", type: "equity", nature: "credit" },

  { code: "41", name: "درآمد عملیاتی", level: 2, parent: "4", type: "income", nature: "credit" },
  { code: "43", name: "سایر درآمدها", level: 2, parent: "4", type: "income", nature: "credit" },

  { code: "51", name: "بهای کالای فروش‌رفته", level: 2, parent: "5", type: "cogs", nature: "debit" },

  { code: "61", name: "هزینه‌های عملیاتی", level: 2, parent: "6", type: "expense", nature: "debit" },
  { code: "69", name: "هزینه‌های مالی و سایر", level: 2, parent: "6", type: "expense", nature: "debit" },

  { code: "111", name: "صندوق", level: 3, parent: "11", type: "asset", nature: "debit" },
  { code: "112", name: "بانک‌ها", level: 3, parent: "11", type: "asset", nature: "debit" },
  { code: "113", name: "تنخواه", level: 3, parent: "11", type: "asset", nature: "debit" },
  { code: "121", name: "حساب‌های دریافتنی", level: 3, parent: "12", type: "asset", nature: "debit", isParty: true, partyKind: "customer" },
  { code: "122", name: "اسناد دریافتنی", level: 3, parent: "12", type: "asset", nature: "debit" },
  { code: "131", name: "موجودی کالا", level: 3, parent: "13", type: "asset", nature: "debit" },
  { code: "141", name: "پیش‌پرداخت‌ها", level: 3, parent: "14", type: "asset", nature: "debit" },
  { code: "142", name: "سپرده‌ها", level: 3, parent: "14", type: "asset", nature: "debit" },
  { code: "151", name: "دارایی ثابت", level: 3, parent: "15", type: "asset", nature: "debit" },
  { code: "152", name: "استهلاک انباشته", level: 3, parent: "15", type: "contra", nature: "credit" },

  { code: "211", name: "حساب‌های پرداختنی", level: 3, parent: "21", type: "liability", nature: "credit", isParty: true, partyKind: "supplier" },
  { code: "212", name: "اسناد پرداختنی", level: 3, parent: "21", type: "liability", nature: "credit" },
  { code: "221", name: "مالیات پرداختنی", level: 3, parent: "22", type: "liability", nature: "credit" },
  { code: "222", name: "بیمه پرداختنی", level: 3, parent: "22", type: "liability", nature: "credit" },
  { code: "223", name: "حقوق پرداختنی", level: 3, parent: "22", type: "liability", nature: "credit" },
  { code: "231", name: "پیش‌دریافت‌ها", level: 3, parent: "23", type: "liability", nature: "credit" },
  { code: "239", name: "سایر بدهی‌ها", level: 3, parent: "23", type: "liability", nature: "credit" },

  { code: "311", name: "سرمایه", level: 3, parent: "31", type: "equity", nature: "credit" },
  { code: "321", name: "برداشت", level: 3, parent: "31", type: "equity", nature: "debit" },
  { code: "331", name: "سود و زیان انباشته", level: 3, parent: "31", type: "equity", nature: "credit" },
  { code: "341", name: "سود و زیان جاری", level: 3, parent: "31", type: "equity", nature: "credit" },

  { code: "411", name: "فروش", level: 3, parent: "41", type: "income", nature: "credit" },
  { code: "412", name: "درآمد خدمات", level: 3, parent: "41", type: "income", nature: "credit" },
  { code: "413", name: "تخفیفات فروش", level: 3, parent: "41", type: "contra", nature: "debit" },
  { code: "431", name: "درآمد حمل", level: 3, parent: "43", type: "income", nature: "credit" },
  { code: "439", name: "سایر درآمدها", level: 3, parent: "43", type: "income", nature: "credit" },

  { code: "511", name: "بهای تمام‌شده کالای فروش‌رفته", level: 3, parent: "51", type: "cogs", nature: "debit" },
  { code: "512", name: "بهای خدمات ارائه‌شده", level: 3, parent: "51", type: "cogs", nature: "debit" },
  { code: "521", name: "تخفیفات خرید", level: 3, parent: "51", type: "contra", nature: "credit" },

  { code: "611", name: "حقوق و دستمزد", level: 3, parent: "61", type: "expense", nature: "debit" },
  { code: "612", name: "اجاره", level: 3, parent: "61", type: "expense", nature: "debit" },
  { code: "613", name: "آب و برق و گاز", level: 3, parent: "61", type: "expense", nature: "debit" },
  { code: "614", name: "حمل", level: 3, parent: "61", type: "expense", nature: "debit" },
  { code: "615", name: "بازاریابی", level: 3, parent: "61", type: "expense", nature: "debit" },
  { code: "616", name: "تبلیغات", level: 3, parent: "61", type: "expense", nature: "debit" },
  { code: "617", name: "تعمیرات", level: 3, parent: "61", type: "expense", nature: "debit" },
  { code: "618", name: "استهلاک", level: 3, parent: "61", type: "expense", nature: "debit" },
  { code: "691", name: "هزینه بانکی", level: 3, parent: "69", type: "expense", nature: "debit" },
  { code: "692", name: "هزینه مالی", level: 3, parent: "69", type: "expense", nature: "debit" },
  { code: "699", name: "سایر هزینه‌ها", level: 3, parent: "69", type: "expense", nature: "debit" },

  {
    code: "1111",
    name: "وجه نقد صندوق",
    level: 4,
    parent: "111",
    type: "asset",
    nature: "debit",
    isCash: true,
    sourceKind: "cash",
  },
  {
    code: "1131",
    name: "تنخواه گردان",
    level: 4,
    parent: "113",
    type: "asset",
    nature: "debit",
    sourceKind: "petty",
  },
  { code: "1211", name: "مشتریان", level: 4, parent: "121", type: "asset", nature: "debit", isParty: true, partyKind: "customer" },
  { code: "1221", name: "چک‌های دریافتنی", level: 4, parent: "122", type: "asset", nature: "debit" },
  { code: "1311", name: "موجودی کالا", level: 4, parent: "131", type: "asset", nature: "debit" },
  { code: "1411", name: "پیش‌پرداخت تأمین‌کنندگان", level: 4, parent: "141", type: "asset", nature: "debit", isParty: true, partyKind: "supplier" },
  { code: "1511", name: "اثاثه و تجهیزات", level: 4, parent: "151", type: "asset", nature: "debit" },
  { code: "1521", name: "استهلاک انباشته دارایی ثابت", level: 4, parent: "152", type: "contra", nature: "credit" },
  { code: "2111", name: "تأمین‌کنندگان", level: 4, parent: "211", type: "liability", nature: "credit", isParty: true, partyKind: "supplier" },
  { code: "2121", name: "چک‌های پرداختنی", level: 4, parent: "212", type: "liability", nature: "credit" },
  { code: "2211", name: "مالیات بر ارزش افزوده پرداختنی", level: 4, parent: "221", type: "liability", nature: "credit" },
  { code: "2221", name: "بیمه تأمین اجتماعی پرداختنی", level: 4, parent: "222", type: "liability", nature: "credit" },
  { code: "2231", name: "حقوق پرداختنی کارکنان", level: 4, parent: "223", type: "liability", nature: "credit", isParty: true, partyKind: "employee" },
  { code: "2311", name: "پیش‌دریافت از مشتریان", level: 4, parent: "231", type: "liability", nature: "credit", isParty: true, partyKind: "customer" },
  { code: "3111", name: "سرمایه اولیه", level: 4, parent: "311", type: "equity", nature: "credit" },
  { code: "3211", name: "برداشت شرکا", level: 4, parent: "321", type: "equity", nature: "debit", isParty: true, partyKind: "partner" },
  { code: "3311", name: "سود و زیان انباشته", level: 4, parent: "331", type: "equity", nature: "credit" },
  { code: "3411", name: "سود و زیان جاری", level: 4, parent: "341", type: "equity", nature: "credit" },
  { code: "4111", name: "فروش کالا", level: 4, parent: "411", type: "income", nature: "credit" },
  { code: "4121", name: "درآمد خدمات", level: 4, parent: "412", type: "income", nature: "credit" },
  { code: "4131", name: "تخفیفات فروش", level: 4, parent: "413", type: "contra", nature: "debit" },
  { code: "4311", name: "درآمد حمل", level: 4, parent: "431", type: "income", nature: "credit" },
  { code: "4391", name: "سایر درآمدها", level: 4, parent: "439", type: "income", nature: "credit" },
  { code: "5111", name: "بهای تمام‌شده کالای فروش‌رفته", level: 4, parent: "511", type: "cogs", nature: "debit" },
  { code: "5211", name: "تخفیفات خرید", level: 4, parent: "521", type: "contra", nature: "credit" },
  { code: "6111", name: "حقوق و دستمزد", level: 4, parent: "611", type: "expense", nature: "debit" },
  { code: "6121", name: "اجاره", level: 4, parent: "612", type: "expense", nature: "debit" },
  { code: "6131", name: "آب و برق و گاز", level: 4, parent: "613", type: "expense", nature: "debit" },
  { code: "6141", name: "هزینه حمل", level: 4, parent: "614", type: "expense", nature: "debit" },
  { code: "6151", name: "بازاریابی", level: 4, parent: "615", type: "expense", nature: "debit" },
  { code: "6161", name: "تبلیغات", level: 4, parent: "616", type: "expense", nature: "debit" },
  { code: "6171", name: "تعمیرات", level: 4, parent: "617", type: "expense", nature: "debit" },
  { code: "6181", name: "استهلاک", level: 4, parent: "618", type: "expense", nature: "debit" },
  { code: "6911", name: "کارمزد بانکی", level: 4, parent: "691", type: "expense", nature: "debit" },
  { code: "6921", name: "هزینه مالی", level: 4, parent: "692", type: "expense", nature: "debit" },
  { code: "6991", name: "سایر هزینه‌ها", level: 4, parent: "699", type: "expense", nature: "debit" },

  ...IRANIAN_BANKS.map((b) => ({
    code: b.code,
    name: b.name,
    level: 4 as const,
    parent: "112",
    type: "asset" as const,
    nature: "debit" as const,
    isBank: true,
    sourceKind: "bank" as const,
    bankName: b.name,
  })),
];

export const CODES = {
  CASH: "1111",
  PETTY: "1131",
  AR: "1211",
  NR: "1221",
  INVENTORY: "1311",
  PREPAID: "1411",
  FIXED: "1511",
  ACCUM_DEP: "1521",
  AP: "2111",
  NP: "2121",
  TAX: "2211",
  INSURANCE: "2221",
  WAGES_PAY: "2231",
  UNEARNED: "2311",
  CAPITAL: "3111",
  DRAW: "3211",
  RE: "3311",
  CURRENT_PL: "3411",
  SALES: "4111",
  SERVICE: "4121",
  SALES_DISC: "4131",
  SHIP_INCOME: "4311",
  OTHER_INCOME: "4391",
  COGS: "5111",
  PURCHASE_DISC: "5211",
  WAGES: "6111",
  RENT: "6121",
  UTILITIES: "6131",
  SHIP_EXP: "6141",
  MARKETING: "6151",
  ADS: "6161",
  REPAIRS: "6171",
  DEPR: "6181",
  BANK_FEE: "6911",
  FINANCE: "6921",
  OTHER_EXP: "6991",
} as const;

export const EXPENSE_CODES = [
  { code: CODES.WAGES, name: "حقوق و دستمزد" },
  { code: CODES.RENT, name: "اجاره" },
  { code: CODES.UTILITIES, name: "آب و برق و گاز" },
  { code: CODES.SHIP_EXP, name: "حمل" },
  { code: CODES.MARKETING, name: "بازاریابی" },
  { code: CODES.ADS, name: "تبلیغات" },
  { code: CODES.REPAIRS, name: "تعمیرات" },
  { code: CODES.DEPR, name: "استهلاک" },
  { code: CODES.BANK_FEE, name: "کارمزد بانکی" },
  { code: CODES.FINANCE, name: "هزینه مالی" },
  { code: CODES.OTHER_EXP, name: "سایر هزینه‌ها" },
];

export const INCOME_CODES = [
  { code: CODES.SALES, name: "فروش کالا" },
  { code: CODES.SERVICE, name: "درآمد خدمات" },
  { code: CODES.SHIP_INCOME, name: "درآمد حمل" },
  { code: CODES.OTHER_INCOME, name: "سایر درآمدها" },
];
