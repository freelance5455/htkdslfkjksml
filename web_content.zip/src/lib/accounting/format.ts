const nf = new Intl.NumberFormat("fa-IR");

export function toman(n: number) {
  const v = Math.round(n || 0);
  const sign = v < 0 ? "−" : "";
  return sign + nf.format(Math.abs(v));
}

export function faNum(n: number) {
  return nf.format(Math.round(n || 0));
}

export function maskPhone(phone: string) {
  const d = phone.replace(/\s/g, "");
  if (d.length < 8) return d;
  return d.slice(0, 4) + "••••" + d.slice(-2);
}

export function parseAmount(raw: string) {
  const digits = raw.replace(/[^\d]/g, "");
  if (!digits) return 0;
  return Number(digits);
}
