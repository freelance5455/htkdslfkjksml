import { toFaDigits } from "./jalali";

export function money(value: unknown): number {
  if (typeof value === "number") return Number.isFinite(value) ? Math.round(value) : 0;
  if (typeof value === "string") {
    const n = Number(value.replace(/,/g, "").trim());
    return Number.isFinite(n) ? Math.round(n) : 0;
  }
  return 0;
}

export function formatRial(value: unknown, fa = true): string {
  const n = money(value);
  const sign = n < 0 ? "-" : "";
  const body = Math.abs(n).toLocaleString("en-US");
  const s = `${sign}${body}`;
  return fa ? toFaDigits(s) : s;
}

export function formatRialUnit(value: unknown, fa = true): string {
  return `${formatRial(value, fa)} ریال`;
}

export function parseAmount(raw: string): number {
  const n = Number(raw.replace(/[^\d.-]/g, "").replace(/,/g, ""));
  return Number.isFinite(n) ? Math.round(n) : 0;
}

export function assertPositive(n: number, label: string) {
  if (!(n > 0)) throw new Error(`${label} باید بزرگ‌تر از صفر باشد.`);
}

export function roundMoney(n: number): number {
  return Math.round(n);
}
