export type Recipe = {
  id: string;
  name: string;
  price: number;
  icon: string;
  inputs: { name: string; qty: number }[];
};

export const RECIPES: Recipe[] = [
  {
    id: "pack-health",
    name: "پک بهداشتی خانواده",
    price: 165000,
    icon: "package",
    inputs: [
      { name: "مایع لباسشویی ۲.۵ لیتری", qty: 1 },
      { name: "دستمال کاغذی ۲۰۰ برگ", qty: 1 },
      { name: "صابون دستشویی", qty: 2 },
    ],
  },
  {
    id: "pack-write",
    name: "پک تحریر دانش‌آموزی",
    price: 145000,
    icon: "notebook",
    inputs: [
      { name: "بسته خودکار آبی", qty: 1 },
      { name: "دفتر ۱۰۰ برگ", qty: 1 },
    ],
  },
  {
    id: "pack-tea",
    name: "پک پذیرایی چای",
    price: 185000,
    icon: "leaf",
    inputs: [
      { name: "چای سیاه ۵۰۰ گرمی", qty: 1 },
      { name: "قند شکسته ۲ کیلویی", qty: 1 },
    ],
  },
];
