import assert from "node:assert/strict";
import test from "node:test";
import { applyDiscount, assertBalanced, buildJournal, computeInvoiceTotals } from "./engine.ts";
import type { CompanySettings } from "./types.ts";

const settings: CompanySettings = {
  name: "t",
  legalName: "t",
  fiscalYearCode: "1405",
  salesShipping: "income",
  purchaseShipping: "inventory",
  inventoryMethod: "perpetual",
  role: "admin",
};

const cash = { id: "s1", accountCode: "1111", kind: "cash" as const, name: "صندوق" };

test("complementary discount percent fills amount", () => {
  const d = applyDiscount(100_000_000, "percent", 5, 0);
  assert.equal(d.amount, 5_000_000);
  assert.equal(d.percent, 5);
});

test("complementary discount amount fills percent", () => {
  const d = applyDiscount(100_000_000, "amount", 0, 5_000_000);
  assert.equal(d.percent, 5);
});

test("invoice formula net = gross - discount + shipping", () => {
  const t = computeInvoiceTotals({
    lines: [{ itemId: "i", qty: 2, unitPrice: 50_000_000 }],
    discountMode: "percent",
    discountPercent: 5,
    shipping: 2_000_000,
  });
  assert.equal(t.gross, 100_000_000);
  assert.equal(t.discountAmount, 5_000_000);
  assert.equal(t.net, 97_000_000);
});

test("cash sale journal is balanced", () => {
  const lines = buildJournal(
    {
      type: "sale",
      date: "2026-09-26",
      settlement: "cash",
      sourceId: "s1",
      discountMode: "percent",
      discountPercent: 5,
      shipping: 2_000_000,
      lines: [{ itemId: "i1", qty: 1, unitPrice: 100_000_000 }],
    },
    {
      settings,
      source: cash,
      itemsById: { i1: { id: "i1", purchasePrice: 40_000_000, name: "x" } },
    },
  );
  assertBalanced(lines);
  const debit = lines.reduce((s, l) => s + l.debit, 0);
  const credit = lines.reduce((s, l) => s + l.credit, 0);
  assert.equal(debit, credit);
});

test("unbalanced journal throws", () => {
  assert.throws(() => assertBalanced([{ accountCode: "1", debit: 10, credit: 0, description: "x" }]));
});
