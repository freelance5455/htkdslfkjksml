export type AccountType = "asset" | "liability" | "equity" | "income" | "expense";

export type Product = {
  id: string;
  name: string;
  barcode: string;
  group: string;
  unit: string;
  icon: string;
  qty: number;
  price: number;
  cost: number;
  minQty: number;
};

export type Party = {
  id: string;
  name: string;
  phone: string;
};

export type JournalLine = {
  accountCode: string;
  debit: number;
  credit: number;
  desc: string;
  partyId?: string;
};

export type EntrySource =
  | "opening"
  | "sale"
  | "purchase"
  | "receipt"
  | "payment"
  | "expense"
  | "transfer"
  | "depreciation"
  | "production"
  | "adjust"
  | "manual";

export type JournalEntry = {
  id: string;
  number: string;
  date: string;
  desc: string;
  source: EntrySource;
  status: "posted";
  ref?: string;
  lines: JournalLine[];
};

export type StockKind = "opening" | "sale" | "purchase" | "produce" | "consume" | "adjust";

export type StockMove = {
  id: string;
  date: string;
  productId: string;
  qty: number;
  cost: number;
  ref: string;
  kind: StockKind;
};

export type InvoiceLine = {
  name: string;
  qty: number;
  price: number;
  amount: number;
};

export type Invoice = {
  id: string;
  number: number;
  date: string;
  partyName: string;
  partyPhone: string;
  kind: "sale" | "proforma";
  lines: InvoiceLine[];
  gross: number;
  discount: number;
  tax: number;
  extras: number;
  total: number;
  payLabel: string;
  status: "posted" | "draft";
};

export type Asset = {
  id: string;
  name: string;
  cost: number;
  months: number;
  accumulated: number;
  acquired: string;
};

export type Settings = {
  shopName: string;
  phone: string;
  address: string;
  economicCode: string;
  taxRate: number;
};

export type PayMethod = "cash" | "card" | "cheque" | "other";
export type Settlement = "full" | "multi" | "credit";

export type Draft = {
  kind: "sale" | "proforma";
  date: string;
  partyId: string | null;
  lines: { productId: string; qty: number; price: number }[];
  discountMode: "amount" | "percent";
  discountValue: number;
  taxEnabled: boolean;
  shipping: number;
  packing: number;
  otherCost: number;
  settlement: Settlement;
  method: PayMethod;
  splitCash: number;
};

export type View =
  | "home"
  | "goods"
  | "parties"
  | "invoice"
  | "assistant"
  | "ops"
  | "books"
  | "excel"
  | "treasury"
  | "assets"
  | "production"
  | "purchase"
  | "control"
  | "settings"
  | "more";

export type Result = { ok: boolean; message: string; invoiceId?: string };
