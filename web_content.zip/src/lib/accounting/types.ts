export const OP_TYPES = [
  "receipt",
  "receipt_other",
  "payment",
  "payment_other",
  "transfer",
  "sale_cash",
  "sale_credit",
  "sale_mixed",
  "sale_return",
  "purchase_cash",
  "purchase_credit",
  "purchase_return",
  "sale_discount",
  "purchase_discount",
  "expense_cash",
  "expense_payable",
  "income",
  "check_receive",
  "check_pay",
  "check_collect",
  "check_return",
  "capital_in",
  "draw",
  "petty_fund",
  "petty_settle",
  "prepay",
  "advance",
  "payroll",
  "manual",
  "adjustment",
  "reversal",
  "opening",
  "closing",
] as const;

export type OpType = (typeof OP_TYPES)[number];

export type PartyKind =
  | "customer"
  | "supplier"
  | "employee"
  | "shareholder"
  | "bank"
  | "government"
  | "other";

export type AccountGroup =
  | "asset"
  | "liability"
  | "equity"
  | "income"
  | "cogs"
  | "expense"
  | "contra"
  | "control";

export type AccountRow = {
  id: string;
  code: string;
  name: string;
  level: number;
  parentId: string | null;
  groupCode: AccountGroup;
  nature: "debit" | "credit";
  isPostable: boolean;
  isActive: boolean;
  floatingType: "none" | "party" | "bank" | "cost_center" | "project";
};

export type PartyRow = {
  id: string;
  code: string;
  name: string;
  kind: PartyKind;
  phone: string | null;
  address: string | null;
  isActive: boolean;
};

export type CashAccountRow = {
  id: string;
  accountId: string;
  name: string;
  kind: "cash" | "bank" | "petty";
  bankName: string | null;
  accountNumber: string | null;
  isActive: boolean;
};

export type JournalLineDraft = {
  accountId: string;
  accountCode?: string;
  accountName?: string;
  partyId?: string | null;
  cashAccountId?: string | null;
  debit: number;
  credit: number;
  description?: string;
};

export type PostingInput = {
  opType: OpType;
  date: string;
  amount: number;
  description: string;
  partyId?: string;
  cashAccountId?: string;
  destCashAccountId?: string;
  expenseAccountId?: string;
  incomeAccountId?: string;
  inventoryAccountId?: string;
  cogsAmount?: number;
  cashPortion?: number;
  discountAmount?: number;
  freightAmount?: number;
  checkNumber?: string;
  checkDueDate?: string;
  checkBankName?: string;
  lines?: JournalLineDraft[];
  originalId?: string;
  reason?: string;
};

export type OperationRow = {
  id: string;
  number: string;
  opType: OpType;
  opDate: string;
  description: string | null;
  partyId: string | null;
  partyName: string | null;
  cashAccountId: string | null;
  destCashAccountId: string | null;
  amount: number;
  status: "posted" | "deleted" | "reversed";
  journalId: string | null;
  journalNumber: string | null;
  originalId: string | null;
  createdAt: string;
  dayStatus: "open" | "closed";
};

export type JournalRow = {
  id: string;
  number: string;
  journalDate: string;
  description: string | null;
  journalType: string;
  operationId: string | null;
  operationNumber: string | null;
  status: string;
  debitTotal: number;
  creditTotal: number;
  lines: Array<JournalLineDraft & { id: string; lineNo: number }>;
};

export type TrialBalanceRow = {
  accountId: string;
  code: string;
  name: string;
  level: number;
  groupCode: string;
  openingDebit: number;
  openingCredit: number;
  turnoverDebit: number;
  turnoverCredit: number;
  balanceDebit: number;
  balanceCredit: number;
};
