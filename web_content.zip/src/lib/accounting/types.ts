export const OPERATION_TYPES = [
  "receipt",
  "payment",
  "transfer",
  "sale",
  "sale_return",
  "purchase",
  "purchase_return",
  "expense",
  "income",
  "receipt_invoice",
  "receipt_other",
  "payment_invoice",
  "payment_other",
  "check_in",
  "check_out",
  "check_collect",
  "check_bounce",
  "transfer_cash_bank",
  "transfer_banks",
  "petty_in",
  "petty_settle",
  "manual",
  "adjustment",
  "reversal",
  "capital_in",
  "draw",
  "payroll",
  "insurance",
  "tax",
  "depreciation",
  "prepaid",
  "unearned",
  "opening",
  "closing",
] as const;

export type OperationType = (typeof OPERATION_TYPES)[number];

export type AccountType =
  | "asset"
  | "liability"
  | "equity"
  | "income"
  | "cogs"
  | "expense"
  | "contra"
  | "control"
  | "memorandum";

export type Nature = "debit" | "credit";
export type DiscountMode = "percent" | "amount";
export type Settlement = "cash" | "bank" | "credit" | "mixed";
export type JournalKind =
  | "normal"
  | "opening"
  | "closing"
  | "adjusting"
  | "reversal"
  | "manual";
export type RecordStatus = "posted" | "deleted" | "voided" | "superseded";
export type DayStatus = "open" | "closed";
export type Role =
  | "admin"
  | "finance"
  | "accountant"
  | "cashier"
  | "sales"
  | "auditor";

export type Account = {
  id: string;
  code: string;
  name: string;
  level: number;
  parentId: string | null;
  type: AccountType;
  nature: Nature;
  isCash: boolean;
  isBank: boolean;
  isParty: boolean;
  partyKind: string | null;
  isActive: boolean;
};

export type Party = {
  id: string;
  code: string;
  name: string;
  tradeName: string;
  phone: string;
  mobile: string;
  address: string;
  nationalId: string;
  isCustomer: boolean;
  isSupplier: boolean;
  isEmployee: boolean;
  isPartner: boolean;
  isOther: boolean;
  isActive: boolean;
  notes: string;
};

export type Item = {
  id: string;
  code: string;
  name: string;
  barcode: string;
  unit: string;
  category: string;
  subcategory: string;
  purchasePrice: number;
  salePrice: number;
  isActive: boolean;
  notes: string;
};

export type FinancialSource = {
  id: string;
  kind: "cash" | "bank" | "petty";
  name: string;
  bankName: string;
  branch: string;
  accountNo: string;
  iban: string;
  cardNo: string;
  accountId: string;
  isActive: boolean;
  notes: string;
};

export type InvoiceLineInput = {
  itemId: string;
  description?: string;
  qty: number;
  unitPrice: number;
};

export type OperationInput = {
  type: OperationType;
  date: string;
  partyId?: string;
  sourceId?: string;
  destSourceId?: string;
  description?: string;
  amount?: number;
  shipping?: number;
  discountPercent?: number;
  discountAmount?: number;
  discountMode?: DiscountMode;
  settlement?: Settlement;
  cashAmount?: number;
  expenseAccountCode?: string;
  incomeAccountCode?: string;
  lines?: InvoiceLineInput[];
  manualLines?: { accountId: string; partyId?: string; debit: number; credit: number; description?: string }[];
  checkNumber?: string;
  checkDueDate?: string;
  checkBankSourceId?: string;
  originalJournalId?: string;
  invoiceNo?: string;
  reason?: string;
};

export type JournalLineDraft = {
  accountCode: string;
  accountId?: string;
  partyId?: string;
  sourceId?: string;
  description: string;
  debit: number;
  credit: number;
};

export type CompanySettings = {
  name: string;
  legalName: string;
  fiscalYearCode: string;
  salesShipping: "income" | "expense" | "receivable";
  purchaseShipping: "inventory" | "expense";
  inventoryMethod: "perpetual" | "periodic";
  role: Role;
};

export type InvoiceTotals = {
  gross: number;
  discountAmount: number;
  discountPercent: number;
  discountMode: DiscountMode;
  shipping: number;
  net: number;
};

export const OP_LABELS: Record<OperationType, string> = {
  receipt: "دریافت",
  payment: "پرداخت",
  transfer: "انتقال",
  sale: "فروش",
  sale_return: "برگشت از فروش",
  purchase: "خرید",
  purchase_return: "برگشت از خرید",
  expense: "هزینه",
  income: "درآمد",
  receipt_invoice: "دریافت بابت فاکتور",
  receipt_other: "دریافت خارج از فاکتور",
  payment_invoice: "پرداخت بابت فاکتور",
  payment_other: "پرداخت خارج از فاکتور",
  check_in: "دریافت چک",
  check_out: "پرداخت چک",
  check_collect: "وصول چک",
  check_bounce: "برگشت چک",
  transfer_cash_bank: "انتقال صندوق و بانک",
  transfer_banks: "انتقال بین بانک‌ها",
  petty_in: "واریز به تنخواه",
  petty_settle: "تسویه تنخواه",
  manual: "سند دستی",
  adjustment: "سند اصلاحی",
  reversal: "سند برگشتی",
  capital_in: "واریز سرمایه",
  draw: "برداشت مالک",
  payroll: "حقوق و دستمزد",
  insurance: "بیمه",
  tax: "مالیات",
  depreciation: "استهلاک",
  prepaid: "پیش‌پرداخت",
  unearned: "پیش‌دریافت",
  opening: "افتتاحیه",
  closing: "اختتامیه",
};

export const ROLE_LABELS: Record<Role, string> = {
  admin: "مدیر سیستم",
  finance: "مدیر مالی",
  accountant: "حسابدار",
  cashier: "صندوقدار",
  sales: "کاربر فروش",
  auditor: "ناظر",
};
