export type VoiceProduct = { id: string; name: string };
export type VoiceParty = { id: string; name: string };

export type VoiceItem = { product: VoiceProduct; qty: number };

export type VoiceCommand = {
  intent: "sale" | "purchase" | "stock" | "unknown";
  party: VoiceParty | null;
  items: VoiceItem[];
};

const NUMS: Record<string, number> = {
  یک: 1,
  یه: 1,
  دو: 2,
  سه: 3,
  چهار: 4,
  پنج: 5,
  شش: 6,
  هفت: 7,
  هشت: 8,
  نه: 9,
  ده: 10,
  یازده: 11,
  دوازده: 12,
};

const CLASSIFIERS = new Set(["تا", "عدد", "دونه", "دانه", "عددِ"]);

export function normFa(input: string) {
  return input
    .replace(/[يی]/g, "ی")
    .replace(/ك/g, "ک")
    .replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)))
    .replace(/[^\u0600-\u06FFa-zA-Z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function bestByName<T extends { name: string }>(query: string, list: T[]): T | null {
  const q = normFa(query);
  if (!q) return null;
  let best: T | null = null;
  let score = 0;
  for (const item of list) {
    const n = normFa(item.name);
    let s = 0;
    if (n.includes(q) || q.includes(n)) s = Math.min(n.length, q.length) + 2;
    const words = q.split(" ").filter((w) => w.length > 1);
    const hit = words.filter((w) => n.includes(w)).length;
    if (hit > 0) s = Math.max(s, hit);
    if (s > score) {
      score = s;
      best = item;
    }
  }
  return score > 0 ? best : null;
}

export function parseCommand(raw: string, products: VoiceProduct[], parties: VoiceParty[]): VoiceCommand {
  const t = normFa(raw);
  let intent: VoiceCommand["intent"] = "unknown";
  if (/(موجودی|چند تا دارم|چقدر دارم)/.test(t)) intent = "stock";
  else if (t.includes("خرید")) intent = "purchase";
  else if (/(فروش|فاکتور)/.test(t)) intent = "sale";

  let rest = t
    .replace(/پیش فاکتور|فاکتور|فروش|خرید|موجودی|چند تا دارم|چقدر دارم/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  let party: VoiceParty | null = null;
  const sorted = [...parties].sort((a, b) => b.name.length - a.name.length);
  for (const p of sorted) {
    const pn = normFa(p.name);
    if (pn && rest.includes(pn)) {
      party = p;
      rest = rest.replace(pn, " ");
      break;
    }
  }
  if (!party) {
    for (const p of sorted) {
      const last = normFa(p.name).split(" ").pop() ?? "";
      if (last.length >= 3 && rest.includes(last)) {
        party = p;
        rest = rest.replace(last, " ");
        break;
      }
    }
  }

  rest = rest.replace(/\s+/g, " ").trim();

  const tokens = rest.split(" ").filter((tok) => tok && tok !== "به" && tok !== "برای" && tok !== "از" && tok !== "را");
  const items: { query: string; qty: number }[] = [];
  let buf: string[] = [];
  const flush = (qty: number) => {
    const query = buf.join(" ").trim();
    buf = [];
    if (query) items.push({ query, qty });
  };

  for (let i = 0; i < tokens.length; i++) {
    const tok = tokens[i];
    const n = NUMS[tok] ?? (/^\d+$/.test(tok) ? Number(tok) : null);
    if (n != null) {
      flush(n);
      if (tokens[i + 1] && CLASSIFIERS.has(tokens[i + 1])) i++;
    } else if (!CLASSIFIERS.has(tok)) {
      buf.push(tok);
    }
  }
  if (buf.length && (intent === "stock" || items.length === 0)) {
    items.push({ query: buf.join(" "), qty: 1 });
  }

  const matched: VoiceItem[] = [];
  for (const it of items) {
    const product = bestByName(it.query, products);
    if (product) matched.push({ product, qty: it.qty });
  }

  return { intent, party, items: matched };
}
