import { addDays, TODAY } from "./jalali";
import type { Asset, JournalEntry, JournalLine, Party, Product, Settings, StockMove } from "./types";

export const SETTINGS: Settings = {
  shopName: "آفیس‌باز",
  phone: "۰۵۱-۳۸۴۴۱۱۰۰",
  address: "مشهد، بلوار وکیل‌آباد",
  economicCode: "۱۴۰۵۸۴۲۱۹۰۰",
  taxRate: 10,
};

type Cat = Omit<Product, "qty"> & { finalQty: number };

const CATALOG: Cat[] = [
  { id: "p01", name: "آب معدنی ۱.۵ لیتری", barcode: "626100000001", group: "نوشیدنی", unit: "عدد", icon: "droplets", price: 32000, cost: 21000, minQty: 10, finalQty: 8 },
  { id: "p02", name: "چای سیاه ۵۰۰ گرمی", barcode: "626100000002", group: "نوشیدنی", unit: "عدد", icon: "leaf", price: 28500, cost: 19000, minQty: 20, finalQty: 15 },
  { id: "p03", name: "برنج ایرانی ۵ کیلویی", barcode: "626100000003", group: "خواربار", unit: "عدد", icon: "wheat", price: 385000, cost: 310000, minQty: 6, finalQty: 22 },
  { id: "p04", name: "روغن مایع ۱.۵ لیتری", barcode: "626100000004", group: "خواربار", unit: "عدد", icon: "flask", price: 42000, cost: 34000, minQty: 8, finalQty: 29 },
  { id: "p05", name: "رب گوجه‌فرنگی ۸۰۰ گرمی", barcode: "626100000005", group: "خواربار", unit: "عدد", icon: "flame", price: 45500, cost: 30000, minQty: 8, finalQty: 36 },
  { id: "p06", name: "مایع لباسشویی ۲.۵ لیتری", barcode: "626100000006", group: "بهداشت", unit: "عدد", icon: "spray", price: 52000, cost: 37000, minQty: 8, finalQty: 43 },
  { id: "p07", name: "دستمال کاغذی ۲۰۰ برگ", barcode: "626100000007", group: "بهداشت", unit: "عدد", icon: "layers", price: 59500, cost: 40000, minQty: 10, finalQty: 50 },
  { id: "p08", name: "شکلات تخته‌ای", barcode: "626100000008", group: "تنقلات", unit: "عدد", icon: "candy", price: 67000, cost: 45000, minQty: 12, finalQty: 57 },
  { id: "p09", name: "بسته خودکار آبی", barcode: "626100000009", group: "لوازم‌التحریر", unit: "بسته", icon: "pen", price: 68500, cost: 42000, minQty: 10, finalQty: 64 },
  { id: "p10", name: "مسواک متوسط", barcode: "626100000010", group: "بهداشت", unit: "عدد", icon: "brush", price: 242000, cost: 150000, minQty: 6, finalQty: 40 },
  { id: "p11", name: "لامپ LED دوازده وات", barcode: "626100000011", group: "الکتریکی", unit: "عدد", icon: "bulb", price: 266000, cost: 175000, minQty: 4, finalQty: 18 },
  { id: "p12", name: "شیر کم‌چرب ۱ لیتری", barcode: "626100000012", group: "لبنیات", unit: "عدد", icon: "milk", price: 38000, cost: 29000, minQty: 8, finalQty: 24 },
  { id: "p13", name: "ماکارونی ۷۰۰ گرمی", barcode: "626100000013", group: "خواربار", unit: "عدد", icon: "pasta", price: 44500, cost: 28000, minQty: 8, finalQty: 33 },
  { id: "p14", name: "تن ماهی ۱۸۰ گرمی", barcode: "626100000014", group: "کنسرو", unit: "عدد", icon: "fish", price: 89000, cost: 62000, minQty: 8, finalQty: 27 },
  { id: "p15", name: "قند شکسته ۲ کیلویی", barcode: "626100000015", group: "خواربار", unit: "عدد", icon: "cube", price: 72000, cost: 54000, minQty: 6, finalQty: 16 },
  { id: "p16", name: "صابون دستشویی", barcode: "626100000016", group: "بهداشت", unit: "عدد", icon: "spark", price: 35000, cost: 18000, minQty: 10, finalQty: 48 },
  { id: "p17", name: "باتری قلمی دو عددی", barcode: "626100000017", group: "الکتریکی", unit: "بسته", icon: "battery", price: 56000, cost: 34000, minQty: 6, finalQty: 21 },
  { id: "p18", name: "دفتر ۱۰۰ برگ", barcode: "626100000018", group: "لوازم‌التحریر", unit: "عدد", icon: "notebook", price: 48000, cost: 27000, minQty: 8, finalQty: 30 },
];

export const PARTIES: Party[] = [
  { id: "pa", name: "تأمین کالای پارس", phone: "09121000010" },
  { id: "hk", name: "حسین کریمی", phone: "09122000004" },
  { id: "ra", name: "رضا اکبری", phone: "09120000008" },
  { id: "sa", name: "سمیه احمدی", phone: "09120000006" },
  { id: "om", name: "سوپرمارکت امید", phone: "09123000009" },
  { id: "se", name: "شرکت پخش سپهر", phone: "09123000005" },
  { id: "ar", name: "علی رضایی", phone: "09123000001" },
  { id: "ba", name: "فروشگاه بهار", phone: "09123000003" },
  { id: "mm", name: "مریم محمدی", phone: "09120000002" },
  { id: "ay", name: "پخش مواد غذایی آریا", phone: "09123000007" },
];

const AR: Record<string, number> = {
  sa: 640000,
  om: 980000,
  ar: 850000,
  ba: 1250000,
};

const AP: Record<string, number> = {
  pa: 1648000,
  hk: 320000,
  se: 3750000,
  ay: 2232000,
};

export const ASSETS: Asset[] = [
  { id: "as1", name: "یخچال ویترینی", cost: 85000000, months: 60, accumulated: 14166670, acquired: "2025-11-06" },
  { id: "as2", name: "صندوق فروشگاهی", cost: 24000000, months: 36, accumulated: 4000002, acquired: "2025-08-01" },
];

const TRAINING_NAMES = [
  "شکر یک کیلویی",
  "نمک یددار",
  "ماست پرچرب ۹۰۰ گرمی",
  "پنیر ۴۰۰ گرمی",
  "دوغ گازدار",
  "آبمیوه پرتقال",
  "بیسکویت ساقه",
  "چیپس نمکی",
  "پفک خانواده",
  "کنسرو لوبیا",
  "سرکه سفید",
  "آبلیمو",
  "مربا هویج",
  "عسل ۹۰۰ گرمی",
  "چای کیسه‌ای",
  "قهوه فوری",
  "پودر لباسشویی",
  "مایع ظرفشویی",
  "شامپو خانواده",
  "خمیردندان",
  "پوشک بچه",
  "دستمال توالت",
  "فویل آلومینیومی",
  "کیسه فریزر",
  "لامپ شمعی",
  "شارژر موبایل",
  "کابل USB",
  "دفتر مشق",
  "مداد مشکی",
  "پاک‌کن",
  "چسب ماتیکی",
  "دستکش یکبارمصرف",
];

export function trainingProducts(): Product[] {
  return TRAINING_NAMES.map((name, i) => {
    const price = 18000 + ((i * 4700) % 140000);
    const qty = 12 + ((i * 5) % 40);
    return {
      id: "t" + String(i + 1).padStart(2, "0"),
      name,
      barcode: "626200000" + String(i + 1).padStart(3, "0"),
      group: i % 5 === 0 ? "بهداشت" : i % 5 === 1 ? "خواربار" : i % 5 === 2 ? "نوشیدنی" : i % 5 === 3 ? "الکتریکی" : "لوازم‌التحریر",
      unit: "عدد",
      icon: "package",
      qty,
      price,
      cost: Math.round(price * 0.68),
      minQty: 5,
    };
  });
}

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function L(accountCode: string, debit: number, credit: number, desc: string, partyId?: string): JournalLine {
  const line: JournalLine = { accountCode, debit: Math.round(debit), credit: Math.round(credit), desc };
  if (partyId) line.partyId = partyId;
  return line;
}

export type World = {
  settings: Settings;
  products: Product[];
  parties: Party[];
  entries: JournalEntry[];
  moves: StockMove[];
  assets: Asset[];
  seq: { entry: number; invoice: number };
};

export function buildSeed(): World {
  const rand = mulberry32(14051106);
  const sold: Record<string, number> = {};
  const bought: Record<string, number> = {};
  const days: { date: string; items: { id: string; qty: number; price: number; cost: number }[] }[] = [];
  const cheap = CATALOG.slice(0, 12);

  for (let ago = 14; ago >= 1; ago--) {
    const date = addDays(TODAY, -ago);
    const count = 1 + Math.floor(rand() * 2);
    const items: { id: string; qty: number; price: number; cost: number }[] = [];
    for (let k = 0; k < count; k++) {
      const pool = rand() < 0.82 ? cheap : CATALOG;
      const p = pool[Math.floor(rand() * pool.length)];
      const qty = 1 + Math.floor(rand() * 2);
      items.push({ id: p.id, qty, price: p.price, cost: p.cost });
      sold[p.id] = (sold[p.id] ?? 0) + qty;
    }
    days.push({ date, items });
  }

  const purchaseId = "p07";
  const purchaseQty = 10;
  const purchaseDate = addDays(TODAY, -6);
  bought[purchaseId] = purchaseQty;

  const products: Product[] = CATALOG.map((p) => {
    const opening = p.finalQty - (bought[p.id] ?? 0) + (sold[p.id] ?? 0);
    return {
      id: p.id,
      name: p.name,
      barcode: p.barcode,
      group: p.group,
      unit: p.unit,
      icon: p.icon,
      qty: p.finalQty,
      price: p.price,
      cost: p.cost,
      minQty: p.minQty,
      ...(opening < 0 ? {} : {}),
    };
  });

  const openingQty = (id: string) => {
    const p = CATALOG.find((x) => x.id === id)!;
    return p.finalQty - (bought[id] ?? 0) + (sold[id] ?? 0);
  };

  const moves: StockMove[] = [];
  let mi = 1;
  const openDate = addDays(TODAY, -21);
  for (const p of CATALOG) {
    const q = openingQty(p.id);
    if (q !== 0) {
      moves.push({ id: "m" + mi++, date: openDate, productId: p.id, qty: q, cost: p.cost, ref: "opening", kind: "opening" });
    }
  }

  const entries: JournalEntry[] = [];
  let ei = 100;
  const push = (date: string, desc: string, source: JournalEntry["source"], lines: JournalLine[], ref?: string) => {
    const debit = lines.reduce((s, l) => s + l.debit, 0);
    const credit = lines.reduce((s, l) => s + l.credit, 0);
    if (debit !== credit) {
      throw new Error(`سند نامتوازن: ${desc} ${debit} / ${credit}`);
    }
    entries.push({ id: "e" + ei, number: String(ei), date, desc, source, status: "posted", ref, lines });
    ei += 1;
  };

  const invValue = CATALOG.reduce((s, p) => s + openingQty(p.id) * p.cost, 0);
  const fixed = ASSETS.reduce((s, a) => s + a.cost, 0);
  const accum = ASSETS.reduce((s, a) => s + a.accumulated, 0);
  const cash0 = 18500000;
  const bank0 = 26400000;
  const ar = Object.values(AR).reduce((s, n) => s + n, 0);
  const ap = Object.values(AP).reduce((s, n) => s + n, 0);
  const equity = cash0 + bank0 + ar + invValue + fixed - ap - accum;

  const openLines: JournalLine[] = [
    L("1100", cash0, 0, "موجودی اول دوره صندوق"),
    L("1110", bank0, 0, "موجودی اول دوره بانک"),
    L("1300", invValue, 0, "موجودی اول دوره کالا"),
    L("1500", fixed, 0, "بهای تمام‌شده دارایی ثابت"),
  ];
  for (const [id, amount] of Object.entries(AR)) {
    const name = PARTIES.find((p) => p.id === id)!.name;
    openLines.push(L("1200", amount, 0, "مانده اول دوره " + name, id));
  }
  for (const [id, amount] of Object.entries(AP)) {
    const name = PARTIES.find((p) => p.id === id)!.name;
    openLines.push(L("2100", 0, amount, "مانده اول دوره " + name, id));
  }
  openLines.push(L("2300", 0, accum, "استهلاک انباشته اول دوره"));
  openLines.push(L("3100", 0, equity, "سرمایه اول دوره"));
  push(openDate, "سند افتتاحیه", "opening", openLines, "opening");

  for (const day of days) {
    let net = 0;
    let cogs = 0;
    for (const item of day.items) {
      net += item.qty * item.price;
      cogs += item.qty * item.cost;
      moves.push({
        id: "m" + mi++,
        date: day.date,
        productId: item.id,
        qty: -item.qty,
        cost: item.cost,
        ref: "day-" + day.date,
        kind: "sale",
      });
    }
    const tax = Math.round(net * 0.1);
    const total = net + tax;
    push(day.date, "فروش نقدی روزانه", "sale", [
      L("1100", total, 0, "دریافت فروش نقدی"),
      L("4100", 0, net, "فروش کالا"),
      L("2200", 0, tax, "مالیات فروش"),
      L("5100", cogs, 0, "بهای تمام‌شده فروش"),
      L("1300", 0, cogs, "خروج موجودی"),
    ]);

    if (day.date === purchaseDate) {
      const pp = CATALOG.find((p) => p.id === purchaseId)!;
      const pNet = purchaseQty * pp.cost;
      const pTax = Math.round(pNet * 0.1);
      moves.push({
        id: "m" + mi++,
        date: purchaseDate,
        productId: purchaseId,
        qty: purchaseQty,
        cost: pp.cost,
        ref: "purchase-seed",
        kind: "purchase",
      });
      push(purchaseDate, "خرید نقدی " + pp.name, "purchase", [
        L("1300", pNet, 0, "ورود کالا"),
        L("1400", pTax, 0, "مالیات خرید"),
        L("1100", 0, pNet + pTax, "پرداخت از صندوق"),
      ]);
    }
  }

  for (const p of products) {
    const q = moves.filter((m) => m.productId === p.id).reduce((s, m) => s + m.qty, 0);
    if (q !== p.qty) throw new Error(`مغایرت کاردکس ${p.name}: ${q} در برابر ${p.qty}`);
  }

  return {
    settings: SETTINGS,
    products,
    parties: PARTIES,
    entries,
    moves,
    assets: ASSETS.map((a) => ({ ...a })),
    seq: { entry: ei, invoice: 1 },
  };
}
