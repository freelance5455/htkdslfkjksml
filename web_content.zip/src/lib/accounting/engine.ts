import { CODES } from "./chart";
import type { AccountRow, CashAccountRow, JournalLineDraft, PostingInput } from "./types";

export class AccountingError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "AccountingError";
  }
}

export type Books = {
  accountsById: Map<string, AccountRow>;
  accountsByCode: Map<string, AccountRow>;
  cashById: Map<string, CashAccountRow>;
};

function acc(books: Books, code: string) {
  const a = books.accountsByCode.get(code);
  if (!a) throw new AccountingError(`حساب ${code} در کدینگ یافت نشد.`);
  if (!a.isActive) throw new AccountingError(`حساب ${a.name} غیرفعال است.`);
  return a;
}

function cashAcc(books: Books, cashId?: string) {
  if (!cashId) throw new AccountingError("منبع مالی انتخاب نشده است.");
  const c = books.cashById.get(cashId);
  if (!c || !c.isActive) throw new AccountingError("منبع مالی نامعتبر است.");
  const a = books.accountsById.get(c.accountId);
  if (!a) throw new AccountingError("حساب منبع مالی در کدینگ نیست.");
  return { cash: c, account: a };
}

function line(
  account: AccountRow,
  debit: number,
  credit: number,
  extra?: Partial<JournalLineDraft>,
): JournalLineDraft {
  return {
    accountId: account.id,
    accountCode: account.code,
    accountName: account.name,
    debit: Math.round(debit),
    credit: Math.round(credit),
    partyId: extra?.partyId ?? null,
    cashAccountId: extra?.cashAccountId ?? null,
    description: extra?.description,
  };
}

export function assertBalanced(lines: JournalLineDraft[]) {
  const d = lines.reduce((s, l) => s + l.debit, 0);
  const c = lines.reduce((s, l) => s + l.credit, 0);
  if (d !== c) {
    throw new AccountingError(
      `سند نامتوازن است. بدهکار ${d.toLocaleString("en-US")} ≠ بستانکار ${c.toLocaleString("en-US")}`,
    );
  }
  if (d === 0) throw new AccountingError("مبلغ سند نمی‌تواند صفر باشد.");
  for (const l of lines) {
    if (l.debit < 0 || l.credit < 0) throw new AccountingError("مبلغ منفی غیرمجاز است.");
    if (l.debit > 0 && l.credit > 0) throw new AccountingError("یک ردیف نمی‌تواند همزمان بدهکار و بستانکار باشد.");
    if (!l.accountId) throw new AccountingError("حساب نامعتبر در ردیف سند.");
  }
}

export function buildJournalLines(input: PostingInput, books: Books): JournalLineDraft[] {
  if (input.opType !== "manual" && input.opType !== "adjustment") {
    if (!input.amount || input.amount <= 0) throw new AccountingError("مبلغ باید بزرگ‌تر از صفر باشد.");
  }

  const amt = Math.round(input.amount || 0);
  const desc = input.description?.trim() || undefined;
  let lines: JournalLineDraft[] = [];

  const cash = () => cashAcc(books, input.cashAccountId);
  const dest = () => cashAcc(books, input.destCashAccountId);

  switch (input.opType) {
    case "receipt": {
      const { account, cash: ca } = cash();
      if (!input.partyId) throw new AccountingError("شخص (مشتری) الزامی است.");
      lines = [
        line(account, amt, 0, { cashAccountId: ca.id, description: desc }),
        line(acc(books, CODES.AR), 0, amt, { partyId: input.partyId, description: desc }),
      ];
      break;
    }
    case "receipt_other": {
      const { account, cash: ca } = cash();
      const income = input.incomeAccountId
        ? books.accountsById.get(input.incomeAccountId) ?? acc(books, CODES.OTHER_INCOME)
        : acc(books, CODES.OTHER_INCOME);
      lines = [
        line(account, amt, 0, { cashAccountId: ca.id, description: desc }),
        line(income, 0, amt, { partyId: input.partyId, description: desc }),
      ];
      break;
    }
    case "payment": {
      const { account, cash: ca } = cash();
      if (!input.partyId) throw new AccountingError("شخص (تأمین‌کننده) الزامی است.");
      lines = [
        line(acc(books, CODES.AP), amt, 0, { partyId: input.partyId, description: desc }),
        line(account, 0, amt, { cashAccountId: ca.id, description: desc }),
      ];
      break;
    }
    case "payment_other": {
      const { account, cash: ca } = cash();
      const exp = input.expenseAccountId
        ? books.accountsById.get(input.expenseAccountId) ?? acc(books, CODES.OTHER_EXP)
        : acc(books, CODES.OTHER_EXP);
      lines = [
        line(exp, amt, 0, { partyId: input.partyId, description: desc }),
        line(account, 0, amt, { cashAccountId: ca.id, description: desc }),
      ];
      break;
    }
    case "transfer": {
      const from = cash();
      const to = dest();
      if (from.cash.id === to.cash.id) throw new AccountingError("مبدأ و مقصد انتقال یکسان است.");
      lines = [
        line(to.account, amt, 0, { cashAccountId: to.cash.id, description: desc }),
        line(from.account, 0, amt, { cashAccountId: from.cash.id, description: desc }),
      ];
      break;
    }
    case "sale_cash": {
      const { account, cash: ca } = cash();
      lines = [
        line(account, amt, 0, { cashAccountId: ca.id, partyId: input.partyId, description: desc }),
        line(acc(books, CODES.SALES), 0, amt, { partyId: input.partyId, description: desc }),
      ];
      break;
    }
    case "sale_credit": {
      if (!input.partyId) throw new AccountingError("مشتری برای فروش نسیه الزامی است.");
      lines = [
        line(acc(books, CODES.AR), amt, 0, { partyId: input.partyId, description: desc }),
        line(acc(books, CODES.SALES), 0, amt, { partyId: input.partyId, description: desc }),
      ];
      break;
    }
    case "sale_mixed": {
      if (!input.partyId) throw new AccountingError("مشتری برای فروش ترکیبی الزامی است.");
      const cashAmt = Math.round(input.cashPortion ?? 0);
      const creditAmt = amt - cashAmt;
      if (cashAmt < 0 || creditAmt < 0) throw new AccountingError("سهم نقدی نامعتبر است.");
      if (cashAmt === 0 && creditAmt === 0) throw new AccountingError("مبلغ فروش صفر است.");
      if (cashAmt > 0) {
        const { account, cash: ca } = cash();
        lines.push(line(account, cashAmt, 0, { cashAccountId: ca.id, partyId: input.partyId }));
      }
      if (creditAmt > 0) {
        lines.push(line(acc(books, CODES.AR), creditAmt, 0, { partyId: input.partyId }));
      }
      lines.push(line(acc(books, CODES.SALES), 0, amt, { partyId: input.partyId, description: desc }));
      break;
    }
    case "sale_return": {
      if (input.cashAccountId) {
        const { account, cash: ca } = cash();
        lines = [
          line(acc(books, CODES.SALES_RETURN), amt, 0, { partyId: input.partyId, description: desc }),
          line(account, 0, amt, { cashAccountId: ca.id, partyId: input.partyId }),
        ];
      } else {
        if (!input.partyId) throw new AccountingError("مشتری برای برگشت نسیه الزامی است.");
        lines = [
          line(acc(books, CODES.SALES_RETURN), amt, 0, { partyId: input.partyId, description: desc }),
          line(acc(books, CODES.AR), 0, amt, { partyId: input.partyId }),
        ];
      }
      break;
    }
    case "purchase_cash": {
      const { account, cash: ca } = cash();
      const inv = input.inventoryAccountId
        ? books.accountsById.get(input.inventoryAccountId) ?? acc(books, CODES.INVENTORY)
        : acc(books, CODES.INVENTORY);
      lines = [
        line(inv, amt, 0, { partyId: input.partyId, description: desc }),
        line(account, 0, amt, { cashAccountId: ca.id }),
      ];
      break;
    }
    case "purchase_credit": {
      if (!input.partyId) throw new AccountingError("تأمین‌کننده برای خرید نسیه الزامی است.");
      const inv = input.inventoryAccountId
        ? books.accountsById.get(input.inventoryAccountId) ?? acc(books, CODES.INVENTORY)
        : acc(books, CODES.INVENTORY);
      lines = [
        line(inv, amt, 0, { partyId: input.partyId, description: desc }),
        line(acc(books, CODES.AP), 0, amt, { partyId: input.partyId }),
      ];
      break;
    }
    case "purchase_return": {
      if (input.cashAccountId) {
        const { account, cash: ca } = cash();
        lines = [
          line(account, amt, 0, { cashAccountId: ca.id }),
          line(acc(books, CODES.INVENTORY), 0, amt, { partyId: input.partyId, description: desc }),
        ];
      } else {
        if (!input.partyId) throw new AccountingError("تأمین‌کننده الزامی است.");
        lines = [
          line(acc(books, CODES.AP), amt, 0, { partyId: input.partyId }),
          line(acc(books, CODES.INVENTORY), 0, amt, { partyId: input.partyId, description: desc }),
        ];
      }
      break;
    }
    case "sale_discount": {
      if (!input.partyId) throw new AccountingError("مشتری الزامی است.");
      lines = [
        line(acc(books, CODES.SALES_DISCOUNT), amt, 0, { partyId: input.partyId, description: desc }),
        line(acc(books, CODES.AR), 0, amt, { partyId: input.partyId }),
      ];
      break;
    }
    case "purchase_discount": {
      if (!input.partyId) throw new AccountingError("تأمین‌کننده الزامی است.");
      lines = [
        line(acc(books, CODES.AP), amt, 0, { partyId: input.partyId }),
        line(acc(books, CODES.OTHER_INCOME), 0, amt, { partyId: input.partyId, description: desc }),
      ];
      break;
    }
    case "expense_cash": {
      const { account, cash: ca } = cash();
      const exp = input.expenseAccountId
        ? books.accountsById.get(input.expenseAccountId)
        : acc(books, CODES.OTHER_EXP);
      if (!exp) throw new AccountingError("حساب هزینه نامعتبر است.");
      lines = [
        line(exp, amt, 0, { description: desc }),
        line(account, 0, amt, { cashAccountId: ca.id }),
      ];
      break;
    }
    case "expense_payable": {
      const exp = input.expenseAccountId
        ? books.accountsById.get(input.expenseAccountId)
        : acc(books, CODES.OTHER_EXP);
      if (!exp) throw new AccountingError("حساب هزینه نامعتبر است.");
      lines = [
        line(exp, amt, 0, { partyId: input.partyId, description: desc }),
        line(acc(books, CODES.AP), 0, amt, { partyId: input.partyId }),
      ];
      break;
    }
    case "income": {
      const { account, cash: ca } = cash();
      const inc = input.incomeAccountId
        ? books.accountsById.get(input.incomeAccountId)
        : acc(books, CODES.OTHER_INCOME);
      if (!inc) throw new AccountingError("حساب درآمد نامعتبر است.");
      lines = [
        line(account, amt, 0, { cashAccountId: ca.id, partyId: input.partyId }),
        line(inc, 0, amt, { partyId: input.partyId, description: desc }),
      ];
      break;
    }
    case "check_receive": {
      if (!input.partyId) throw new AccountingError("شخص برای دریافت چک الزامی است.");
      lines = [
        line(acc(books, CODES.NOTES_REC), amt, 0, { partyId: input.partyId, description: desc }),
        line(acc(books, CODES.AR), 0, amt, { partyId: input.partyId }),
      ];
      break;
    }
    case "check_pay": {
      if (!input.partyId) throw new AccountingError("شخص برای پرداخت چک الزامی است.");
      lines = [
        line(acc(books, CODES.AP), amt, 0, { partyId: input.partyId }),
        line(acc(books, CODES.NOTES_PAY), 0, amt, { partyId: input.partyId, description: desc }),
      ];
      break;
    }
    case "check_collect": {
      const { account, cash: ca } = cash();
      lines = [
        line(account, amt, 0, { cashAccountId: ca.id, description: desc }),
        line(acc(books, CODES.NOTES_REC), 0, amt, { partyId: input.partyId }),
      ];
      break;
    }
    case "check_return": {
      if (!input.partyId) throw new AccountingError("شخص برای برگشت چک الزامی است.");
      lines = [
        line(acc(books, CODES.AR), amt, 0, { partyId: input.partyId, description: desc }),
        line(acc(books, CODES.NOTES_REC), 0, amt, { partyId: input.partyId }),
      ];
      break;
    }
    case "capital_in": {
      const { account, cash: ca } = cash();
      lines = [
        line(account, amt, 0, { cashAccountId: ca.id, description: desc }),
        line(acc(books, CODES.CAPITAL), 0, amt, { partyId: input.partyId }),
      ];
      break;
    }
    case "draw": {
      const { account, cash: ca } = cash();
      lines = [
        line(acc(books, CODES.DRAWINGS), amt, 0, { partyId: input.partyId, description: desc }),
        line(account, 0, amt, { cashAccountId: ca.id }),
      ];
      break;
    }
    case "petty_fund": {
      const from = cash();
      const petty = books.accountsByCode.get(CODES.PETTY);
      if (!petty) throw new AccountingError("حساب تنخواه یافت نشد.");
      lines = [
        line(petty, amt, 0, { description: desc }),
        line(from.account, 0, amt, { cashAccountId: from.cash.id }),
      ];
      break;
    }
    case "petty_settle": {
      const exp = input.expenseAccountId
        ? books.accountsById.get(input.expenseAccountId)
        : acc(books, CODES.OTHER_EXP);
      if (!exp) throw new AccountingError("حساب هزینه نامعتبر است.");
      lines = [
        line(exp, amt, 0, { description: desc }),
        line(acc(books, CODES.PETTY), 0, amt),
      ];
      break;
    }
    case "prepay": {
      const { account, cash: ca } = cash();
      lines = [
        line(acc(books, CODES.PREPAID), amt, 0, { partyId: input.partyId, description: desc }),
        line(account, 0, amt, { cashAccountId: ca.id }),
      ];
      break;
    }
    case "advance": {
      const { account, cash: ca } = cash();
      lines = [
        line(account, amt, 0, { cashAccountId: ca.id, partyId: input.partyId }),
        line(acc(books, CODES.UNEARNED), 0, amt, { partyId: input.partyId, description: desc }),
      ];
      break;
    }
    case "payroll": {
      const { account, cash: ca } = cash();
      lines = [
        line(acc(books, CODES.WAGES), amt, 0, { description: desc }),
        line(account, 0, amt, { cashAccountId: ca.id }),
      ];
      break;
    }
    case "manual":
    case "adjustment": {
      if (!input.lines?.length) throw new AccountingError("ردیف‌های سند دستی الزامی است.");
      lines = input.lines.map((l) => {
        const a = books.accountsById.get(l.accountId);
        if (!a || !a.isPostable) throw new AccountingError("حساب ردیف سند نامعتبر است.");
        return line(a, l.debit, l.credit, {
          partyId: l.partyId,
          cashAccountId: l.cashAccountId,
          description: l.description ?? desc,
        });
      });
      break;
    }
    case "reversal": {
      if (!input.lines?.length) throw new AccountingError("سند برگشتی بدون ردیف است.");
      lines = input.lines.map((l) => {
        const a = books.accountsById.get(l.accountId);
        if (!a) throw new AccountingError("حساب سند اصلی نامعتبر است.");
        return line(a, l.credit, l.debit, {
          partyId: l.partyId,
          cashAccountId: l.cashAccountId,
          description: l.description ?? desc,
        });
      });
      break;
    }
    case "opening":
    case "closing": {
      if (!input.lines?.length) throw new AccountingError("ردیف‌های سند افتتاحیه/اختتامیه الزامی است.");
      lines = input.lines.map((l) => {
        const a = books.accountsById.get(l.accountId);
        if (!a) throw new AccountingError("حساب نامعتبر.");
        return line(a, l.debit, l.credit, { partyId: l.partyId, description: l.description ?? desc });
      });
      break;
    }
    default:
      throw new AccountingError("نوع عملیات پشتیبانی نمی‌شود.");
  }

  if (input.freightAmount && input.freightAmount > 0) {
    const fr = Math.round(input.freightAmount);
    if (input.opType.startsWith("purchase")) {
      lines.push(line(acc(books, CODES.FREIGHT), fr, 0, { description: "هزینه حمل" }));
      if (input.cashAccountId) {
        const { account, cash: ca } = cash();
        lines.push(line(account, 0, fr, { cashAccountId: ca.id }));
      } else {
        lines.push(line(acc(books, CODES.AP), 0, fr, { partyId: input.partyId }));
      }
    }
  }

  if (input.cogsAmount && input.cogsAmount > 0 && input.opType.startsWith("sale") && input.opType !== "sale_return") {
    const cogs = Math.round(input.cogsAmount);
    lines.push(line(acc(books, CODES.COGS), cogs, 0, { description: "بهای تمام‌شده" }));
    lines.push(line(acc(books, CODES.INVENTORY), 0, cogs));
  }
  if (input.cogsAmount && input.cogsAmount > 0 && input.opType === "sale_return") {
    const cogs = Math.round(input.cogsAmount);
    lines.push(line(acc(books, CODES.INVENTORY), cogs, 0));
    lines.push(line(acc(books, CODES.COGS), 0, cogs, { description: "برگشت بهای تمام‌شده" }));
  }

  assertBalanced(lines);
  return lines;
}

export function splitBalance(nature: "debit" | "credit", raw: number) {
  if (nature === "debit") {
    return raw >= 0
      ? { debit: raw, credit: 0 }
      : { debit: 0, credit: Math.abs(raw) };
  }
  return raw >= 0
    ? { debit: 0, credit: raw }
    : { debit: Math.abs(raw), credit: 0 };
}
