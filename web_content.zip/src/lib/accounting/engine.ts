import { accountName, isDebitNature } from "./chart";
import { addDays, TODAY } from "./jalali";
import type { Draft, JournalEntry, Party, Product, Settings, StockMove } from "./types";

export type PricedLine = {
  productId: string;
  name: string;
  qty: number;
  price: number;
  cost: number;
  amount: number;
};

export type PricedDraft = {
  lines: PricedLine[];
  gross: number;
  discount: number;
  net: number;
  tax: number;
  extras: number;
  total: number;
  cogs: number;
};

export function priceDraft(draft: Draft, products: Product[], settings: Settings): PricedDraft {
  const lines: PricedLine[] = [];
  for (const line of draft.lines) {
    const p = products.find((x) => x.id === line.productId);
    if (!p || line.qty <= 0) continue;
    const price = Math.round(line.price);
    lines.push({
      productId: p.id,
      name: p.name,
      qty: line.qty,
      price,
      cost: p.cost,
      amount: line.qty * price,
    });
  }
  const gross = lines.reduce((s, l) => s + l.amount, 0);
  const rawDiscount =
    draft.discountMode === "percent" ? Math.round((gross * draft.discountValue) / 100) : Math.round(draft.discountValue);
  const discount = Math.max(0, Math.min(gross, rawDiscount || 0));
  const net = gross - discount;
  const tax = draft.taxEnabled ? Math.round((net * settings.taxRate) / 100) : 0;
  const extras = Math.round(draft.shipping + draft.packing + draft.otherCost);
  const total = net + tax + extras;
  const cogs = lines.reduce((s, l) => s + l.qty * l.cost, 0);
  return { lines, gross, discount, net, tax, extras, total, cogs };
}

export function entryTotals(entry: JournalEntry) {
  const debit = entry.lines.reduce((s, l) => s + l.debit, 0);
  const credit = entry.lines.reduce((s, l) => s + l.credit, 0);
  return { debit, credit, ok: debit === credit && debit > 0 };
}

export type TrialRow = {
  code: string;
  name: string;
  debit: number;
  credit: number;
};

export function trialOf(entries: JournalEntry[]) {
  const map = new Map<string, { debit: number; credit: number }>();
  for (const e of entries) {
    for (const l of e.lines) {
      const cur = map.get(l.accountCode) ?? { debit: 0, credit: 0 };
      cur.debit += l.debit;
      cur.credit += l.credit;
      map.set(l.accountCode, cur);
    }
  }
  const rows: TrialRow[] = [];
  let debit = 0;
  let credit = 0;
  for (const [code, v] of map) {
    const net = v.debit - v.credit;
    const rowDebit = net > 0 ? net : 0;
    const rowCredit = net < 0 ? -net : 0;
    if (rowDebit === 0 && rowCredit === 0) continue;
    rows.push({ code, name: accountName(code), debit: rowDebit, credit: rowCredit });
    debit += rowDebit;
    credit += rowCredit;
  }
  rows.sort((a, b) => a.code.localeCompare(b.code));
  return { rows, debit, credit, ok: debit === credit };
}

export function accountBalance(entries: JournalEntry[], code: string) {
  let debit = 0;
  let credit = 0;
  for (const e of entries) {
    for (const l of e.lines) {
      if (l.accountCode !== code) continue;
      debit += l.debit;
      credit += l.credit;
    }
  }
  const natural = isDebitNature(code) ? debit - credit : credit - debit;
  return { debit, credit, natural };
}

export type LedgerLine = {
  id: string;
  date: string;
  number: string;
  desc: string;
  debit: number;
  credit: number;
  balance: number;
};

export function ledgerOf(entries: JournalEntry[], code: string): LedgerLine[] {
  const rows: LedgerLine[] = [];
  let bal = 0;
  const sorted = [...entries].sort((a, b) => a.date.localeCompare(b.date) || a.number.localeCompare(b.number));
  for (const e of sorted) {
    for (const l of e.lines) {
      if (l.accountCode !== code) continue;
      bal += isDebitNature(code) ? l.debit - l.credit : l.credit - l.debit;
      rows.push({
        id: e.id + code + rows.length,
        date: e.date,
        number: e.number,
        desc: l.desc || e.desc,
        debit: l.debit,
        credit: l.credit,
        balance: bal,
      });
    }
  }
  return rows;
}

export type PartyRow = {
  id: string;
  name: string;
  phone: string;
  net: number;
  label: string;
};

export function partyRows(entries: JournalEntry[], parties: Party[]): PartyRow[] {
  return parties.map((p) => {
    let ar = 0;
    let ap = 0;
    for (const e of entries) {
      for (const l of e.lines) {
        if (l.partyId !== p.id) continue;
        if (l.accountCode === "1200") ar += l.debit - l.credit;
        if (l.accountCode === "2100") ap += l.credit - l.debit;
      }
    }
    const net = ar - ap;
    const label = net > 0 ? "بدهکار به شما" : net < 0 ? "شما بدهکارید" : "تسویه";
    return { id: p.id, name: p.name, phone: p.phone, net, label };
  });
}

export function partySummary(rows: PartyRow[]) {
  const debtors = rows.reduce((s, r) => s + (r.net > 0 ? r.net : 0), 0);
  const creditors = rows.reduce((s, r) => s + (r.net < 0 ? -r.net : 0), 0);
  return { debtors, creditors, balance: creditors - debtors };
}

export function sumInRange(entries: JournalEntry[], from: string, to: string, pick: (e: JournalEntry) => number) {
  return entries.filter((e) => e.date >= from && e.date <= to).reduce((s, e) => s + pick(e), 0);
}

export function monthStart(iso: string) {
  const [y, m] = iso.split("-").map(Number);
  if (m === 11) return `${y}-10-23`;
  return addDays(iso, -14);
}

export type Kpis = {
  sales: number;
  purchases: number;
  receipts: number;
  payments: number;
  cogs: number;
  profit: number;
  expenses: number;
  low: number;
  negative: number;
  drafts: number;
  docs: number;
  cash: number;
  bank: number;
  balanced: boolean;
};

export function kpisOf(
  entries: JournalEntry[],
  products: Product[],
  draftCount: number,
): Kpis {
  const from = "2026-10-23";
  const to = TODAY;
  const inMonth = entries.filter((e) => e.date >= from && e.date <= to);
  const credit = (code: string) =>
    inMonth.reduce((s, e) => s + e.lines.filter((l) => l.accountCode === code).reduce((a, l) => a + l.credit - l.debit, 0), 0);
  const debit = (code: string) =>
    inMonth.reduce((s, e) => s + e.lines.filter((l) => l.accountCode === code).reduce((a, l) => a + l.debit - l.credit, 0), 0);
  const sales = Math.max(0, credit("4100"));
  const cogs = Math.max(0, debit("5100"));
  const purchases = inMonth
    .filter((e) => e.source === "purchase")
    .reduce((s, e) => s + e.lines.filter((l) => l.accountCode === "1300").reduce((a, l) => a + l.debit, 0), 0);
  const receipts = inMonth
    .filter((e) => e.source === "receipt")
    .reduce((s, e) => s + e.lines.reduce((a, l) => a + l.debit, 0), 0);
  const payments = inMonth
    .filter((e) => e.source === "payment")
    .reduce((s, e) => s + e.lines.reduce((a, l) => a + l.credit, 0), 0);
  const expenses = Math.max(0, debit("5200") + debit("5300"));
  const tb = trialOf(entries);
  return {
    sales,
    purchases,
    receipts,
    payments,
    cogs,
    profit: sales - cogs,
    expenses,
    low: products.filter((p) => p.qty <= p.minQty).length,
    negative: products.filter((p) => p.qty < 0).length,
    drafts: draftCount,
    docs: entries.length,
    cash: accountBalance(entries, "1100").natural,
    bank: accountBalance(entries, "1110").natural,
    balanced: tb.ok,
  };
}

export function salesSeries(entries: JournalEntry[]) {
  const days: { date: string; sales: number }[] = [];
  for (let i = 13; i >= 0; i--) {
    const date = addDays(TODAY, -i);
    const sales = entries
      .filter((e) => e.date === date)
      .reduce((s, e) => s + e.lines.filter((l) => l.accountCode === "4100").reduce((a, l) => a + l.credit - l.debit, 0), 0);
    days.push({ date, sales: Math.max(0, sales) });
  }
  return days;
}

export function kardexValue(products: Product[]) {
  return products.reduce((s, p) => s + p.qty * p.cost, 0);
}

export function moveQty(moves: StockMove[], productId: string) {
  return moves.filter((m) => m.productId === productId).reduce((s, m) => s + m.qty, 0);
}

export function payLabel(draft: Draft) {
  if (draft.settlement === "credit") return "نسیه";
  if (draft.settlement === "multi") return "چند روش";
  if (draft.method === "card") return "کارتخوان";
  if (draft.method === "cheque") return "چک";
  if (draft.method === "other") return "سایر";
  return "نقدی";
}

export function blendCost(oldQty: number, oldCost: number, addQty: number, addCost: number) {
  if (addQty <= 0) return oldCost;
  if (oldQty <= 0) return addCost;
  return Math.round((oldQty * oldCost + addQty * addCost) / (oldQty + addQty));
}
