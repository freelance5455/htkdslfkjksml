import { CODES } from "./chart";
import { money, roundMoney } from "./format";
import type {
  CompanySettings,
  DiscountMode,
  InvoiceLineInput,
  InvoiceTotals,
  JournalLineDraft,
  OperationInput,
  OperationType,
} from "./types";

export class AccountingError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "AccountingError";
  }
}

export function applyDiscount(
  gross: number,
  mode: DiscountMode,
  percent: number,
  amount: number,
): { percent: number; amount: number; mode: DiscountMode } {
  const g = roundMoney(gross);
  if (g <= 0) return { percent: 0, amount: 0, mode };
  if (mode === "percent") {
    const p = Math.max(0, percent);
    if (p > 100) throw new AccountingError("درصد تخفیف نمی‌تواند بیش از ۱۰۰ باشد.");
    return { percent: p, amount: roundMoney((g * p) / 100), mode };
  }
  const a = Math.max(0, roundMoney(amount));
  if (a > g) throw new AccountingError("مبلغ تخفیف نمی‌تواند از مبلغ ناخالص بیشتر باشد.");
  const p = Math.round((a / g) * 10000) / 100;
  return { percent: p, amount: a, mode };
}

export function reconcileDiscount(
  gross: number,
  mode: DiscountMode | undefined,
  percent: number | undefined,
  amount: number | undefined,
): { percent: number; amount: number; mode: DiscountMode } {
  const hasP = percent != null && percent !== 0;
  const hasA = amount != null && amount !== 0;
  const resolved: DiscountMode = mode ?? (hasA && !hasP ? "amount" : "percent");
  const computed = applyDiscount(gross, resolved, percent ?? 0, amount ?? 0);
  if (hasP && hasA && resolved === "percent") {
    const expected = applyDiscount(gross, "percent", percent ?? 0, 0).amount;
    if (Math.abs(expected - (amount ?? 0)) > 1) {
      throw new AccountingError("مبلغ تخفیف با درصد تخفیف سازگار نیست.");
    }
  }
  if (hasP && hasA && resolved === "amount") {
    const expected = applyDiscount(gross, "amount", 0, amount ?? 0).percent;
    if (Math.abs(expected - (percent ?? 0)) > 0.05) {
      throw new AccountingError("درصد تخفیف با مبلغ تخفیف سازگار نیست.");
    }
  }
  return computed;
}

export function computeInvoiceTotals(input: {
  lines?: InvoiceLineInput[];
  amount?: number;
  shipping?: number;
  discountPercent?: number;
  discountAmount?: number;
  discountMode?: DiscountMode;
}): InvoiceTotals {
  const grossFromLines = (input.lines ?? []).reduce(
    (s, l) => s + roundMoney(money(l.qty) * money(l.unitPrice)),
    0,
  );
  const gross = grossFromLines > 0 ? grossFromLines : roundMoney(money(input.amount));
  const disc = reconcileDiscount(
    gross,
    input.discountMode,
    input.discountPercent,
    input.discountAmount,
  );
  const shipping = Math.max(0, roundMoney(money(input.shipping)));
  const net = gross - disc.amount + shipping;
  if (net < 0) throw new AccountingError("مبلغ نهایی نمی‌تواند منفی باشد.");
  return {
    gross,
    discountAmount: disc.amount,
    discountPercent: disc.percent,
    discountMode: disc.mode,
    shipping,
    net,
  };
}

export function assertBalanced(lines: JournalLineDraft[], tolerance = 0) {
  const debit = lines.reduce((s, l) => s + money(l.debit), 0);
  const credit = lines.reduce((s, l) => s + money(l.credit), 0);
  if (Math.abs(debit - credit) > tolerance) {
    throw new AccountingError(
      `سند نامتوازن است. بدهکار ${debit.toLocaleString("en-US")} ≠ بستانکار ${credit.toLocaleString("en-US")}`,
    );
  }
  if (debit === 0) throw new AccountingError("مبلغ سند نمی‌تواند صفر باشد.");
  for (const l of lines) {
    if (l.debit < 0 || l.credit < 0) throw new AccountingError("مبلغ منفی غیرمجاز است.");
    if (l.debit > 0 && l.credit > 0) throw new AccountingError("یک ردیف نمی‌تواند همزمان بدهکار و بستانکار باشد.");
    if (l.debit === 0 && l.credit === 0) throw new AccountingError("ردیف بدون مبلغ مجاز نیست.");
  }
}

type SourceRef = { id: string; accountCode: string; kind: "cash" | "bank" | "petty"; name: string };
type ItemRef = { id: string; purchasePrice: number; name: string };

export type EngineContext = {
  settings: CompanySettings;
  source?: SourceRef;
  dest?: SourceRef;
  itemsById: Record<string, ItemRef>;
};

function line(
  accountCode: string,
  debit: number,
  credit: number,
  description: string,
  extra?: { partyId?: string; sourceId?: string },
): JournalLineDraft {
  return {
    accountCode,
    debit: roundMoney(debit),
    credit: roundMoney(credit),
    description,
    partyId: extra?.partyId,
    sourceId: extra?.sourceId,
  };
}

function requireSource(ctx: EngineContext, label = "منبع مالی"): SourceRef {
  if (!ctx.source) throw new AccountingError(`${label} انتخاب نشده است.`);
  return ctx.source;
}

function requireParty(input: OperationInput) {
  if (!input.partyId) throw new AccountingError("شخص انتخاب نشده است.");
  return input.partyId;
}

function settlementDr(
  input: OperationInput,
  ctx: EngineContext,
  amount: number,
  desc: string,
): JournalLineDraft[] {
  const settlement = input.settlement ?? "cash";
  if (settlement === "credit") {
    return [line(CODES.AR, amount, 0, desc, { partyId: requireParty(input) })];
  }
  if (settlement === "mixed") {
    const cash = roundMoney(money(input.cashAmount));
    if (cash <= 0 || cash >= amount) throw new AccountingError("مبلغ نقدی تسویه ترکیبی نامعتبر است.");
    const src = requireSource(ctx);
    return [
      line(src.accountCode, cash, 0, desc, { sourceId: src.id }),
      line(CODES.AR, amount - cash, 0, desc, { partyId: requireParty(input) }),
    ];
  }
  const src = requireSource(ctx);
  return [line(src.accountCode, amount, 0, desc, { sourceId: src.id })];
}

function settlementCr(
  input: OperationInput,
  ctx: EngineContext,
  amount: number,
  desc: string,
): JournalLineDraft[] {
  const settlement = input.settlement ?? "cash";
  if (settlement === "credit") {
    return [line(CODES.AP, 0, amount, desc, { partyId: requireParty(input) })];
  }
  if (settlement === "mixed") {
    const cash = roundMoney(money(input.cashAmount));
    if (cash <= 0 || cash >= amount) throw new AccountingError("مبلغ نقدی تسویه ترکیبی نامعتبر است.");
    const src = requireSource(ctx);
    return [
      line(src.accountCode, 0, cash, desc, { sourceId: src.id }),
      line(CODES.AP, 0, amount - cash, desc, { partyId: requireParty(input) }),
    ];
  }
  const src = requireSource(ctx);
  return [line(src.accountCode, 0, amount, desc, { sourceId: src.id })];
}

function cogsLines(input: OperationInput, ctx: EngineContext, desc: string, reverse = false): JournalLineDraft[] {
  if (ctx.settings.inventoryMethod !== "perpetual") return [];
  const cost = (input.lines ?? []).reduce((s, l) => {
    const item = ctx.itemsById[l.itemId];
    const unitCost = item ? money(item.purchasePrice) : 0;
    return s + roundMoney(money(l.qty) * unitCost);
  }, 0);
  if (cost <= 0) return [];
  if (reverse) {
    return [
      line(CODES.INVENTORY, cost, 0, desc),
      line(CODES.COGS, 0, cost, desc),
    ];
  }
  return [
    line(CODES.COGS, cost, 0, desc),
    line(CODES.INVENTORY, 0, cost, desc),
  ];
}

function reverseLines(lines: JournalLineDraft[]): JournalLineDraft[] {
  return lines.map((l) => ({
    ...l,
    debit: l.credit,
    credit: l.debit,
  }));
}

function buildSale(input: OperationInput, ctx: EngineContext): JournalLineDraft[] {
  const t = computeInvoiceTotals(input);
  const desc = input.description || "فروش";
  const out: JournalLineDraft[] = [];
  out.push(...settlementDr(input, ctx, t.net, desc));
  if (t.discountAmount) out.push(line(CODES.SALES_DISC, t.discountAmount, 0, desc));
  if (t.gross) out.push(line(CODES.SALES, 0, t.gross, desc));
  if (t.shipping) {
    if (ctx.settings.salesShipping === "expense") {
      out.push(line(CODES.SHIP_EXP, t.shipping, 0, desc));
      const src = requireSource(ctx);
      out.push(line(src.accountCode, 0, t.shipping, "پرداخت حمل فروش", { sourceId: src.id }));
    } else {
      out.push(line(CODES.SHIP_INCOME, 0, t.shipping, desc));
    }
  }
  out.push(...cogsLines(input, ctx, "بهای تمام‌شده فروش"));
  return out.filter((l) => l.debit + l.credit > 0);
}

function buildPurchase(input: OperationInput, ctx: EngineContext): JournalLineDraft[] {
  const t = computeInvoiceTotals(input);
  const desc = input.description || "خرید";
  const shipInv = ctx.settings.purchaseShipping === "inventory";
  const out: JournalLineDraft[] = [];
  if (t.gross) out.push(line(CODES.INVENTORY, t.gross, 0, desc));
  if (t.shipping) out.push(line(shipInv ? CODES.INVENTORY : CODES.SHIP_EXP, t.shipping, 0, "هزینه حمل خرید"));
  if (t.discountAmount) out.push(line(CODES.PURCHASE_DISC, 0, t.discountAmount, desc));
  out.push(...settlementCr(input, ctx, t.net, desc));
  return out.filter((l) => l.debit + l.credit > 0);
}

export function buildJournal(input: OperationInput, ctx: EngineContext): JournalLineDraft[] {
  const type = input.type;
  const desc = input.description || type;
  const amount = roundMoney(money(input.amount));
  let lines: JournalLineDraft[] = [];

  switch (type) {
    case "sale":
      lines = buildSale(input, ctx);
      break;
    case "sale_return":
      lines = reverseLines(buildSale(input, ctx));
      break;
    case "purchase":
      lines = buildPurchase(input, ctx);
      break;
    case "purchase_return":
      lines = reverseLines(buildPurchase(input, ctx));
      break;
    case "receipt":
    case "receipt_invoice":
    case "receipt_other": {
      const src = requireSource(ctx);
      const party = requireParty(input);
      if (amount <= 0) throw new AccountingError("مبلغ دریافت نامعتبر است.");
      lines = [
        line(src.accountCode, amount, 0, desc, { sourceId: src.id }),
        line(CODES.AR, 0, amount, desc, { partyId: party }),
      ];
      break;
    }
    case "payment":
    case "payment_invoice":
    case "payment_other": {
      const src = requireSource(ctx);
      const party = requireParty(input);
      if (amount <= 0) throw new AccountingError("مبلغ پرداخت نامعتبر است.");
      lines = [
        line(CODES.AP, amount, 0, desc, { partyId: party }),
        line(src.accountCode, 0, amount, desc, { sourceId: src.id }),
      ];
      break;
    }
    case "expense": {
      const src = requireSource(ctx, "منبع پرداخت هزینه");
      const code = input.expenseAccountCode || CODES.OTHER_EXP;
      if (amount <= 0) throw new AccountingError("مبلغ هزینه نامعتبر است.");
      const settlement = input.settlement ?? "cash";
      lines = [line(code, amount, 0, desc)];
      if (settlement === "credit") {
        lines.push(line(CODES.AP, 0, amount, desc, { partyId: requireParty(input) }));
      } else {
        lines.push(line(src.accountCode, 0, amount, desc, { sourceId: src.id }));
      }
      break;
    }
    case "income": {
      const src = requireSource(ctx);
      const code = input.incomeAccountCode || CODES.OTHER_INCOME;
      if (amount <= 0) throw new AccountingError("مبلغ درآمد نامعتبر است.");
      lines = [
        line(src.accountCode, amount, 0, desc, { sourceId: src.id }),
        line(code, 0, amount, desc),
      ];
      break;
    }
    case "transfer":
    case "transfer_cash_bank":
    case "transfer_banks": {
      const src = requireSource(ctx, "مبدأ");
      if (!ctx.dest) throw new AccountingError("مقصد انتقال انتخاب نشده است.");
      if (src.id === ctx.dest.id) throw new AccountingError("مبدأ و مقصد نمی‌توانند یکسان باشند.");
      if (amount <= 0) throw new AccountingError("مبلغ انتقال نامعتبر است.");
      lines = [
        line(ctx.dest.accountCode, amount, 0, desc, { sourceId: ctx.dest.id }),
        line(src.accountCode, 0, amount, desc, { sourceId: src.id }),
      ];
      break;
    }
    case "petty_in": {
      const src = requireSource(ctx, "منبع تأمین تنخواه");
      if (amount <= 0) throw new AccountingError("مبلغ تنخواه نامعتبر است.");
      lines = [
        line(CODES.PETTY, amount, 0, desc),
        line(src.accountCode, 0, amount, desc, { sourceId: src.id }),
      ];
      break;
    }
    case "petty_settle": {
      const code = input.expenseAccountCode || CODES.OTHER_EXP;
      if (amount <= 0) throw new AccountingError("مبلغ تسویه تنخواه نامعتبر است.");
      lines = [
        line(code, amount, 0, desc),
        line(CODES.PETTY, 0, amount, desc),
      ];
      break;
    }
    case "check_in": {
      const party = requireParty(input);
      if (amount <= 0) throw new AccountingError("مبلغ چک نامعتبر است.");
      lines = [
        line(CODES.NR, amount, 0, desc, { partyId: party }),
        line(CODES.AR, 0, amount, desc, { partyId: party }),
      ];
      break;
    }
    case "check_out": {
      const party = requireParty(input);
      if (amount <= 0) throw new AccountingError("مبلغ چک نامعتبر است.");
      lines = [
        line(CODES.AP, amount, 0, desc, { partyId: party }),
        line(CODES.NP, 0, amount, desc, { partyId: party }),
      ];
      break;
    }
    case "check_collect": {
      const src = requireSource(ctx, "حساب بانکی وصول");
      if (amount <= 0) throw new AccountingError("مبلغ وصول چک نامعتبر است.");
      lines = [
        line(src.accountCode, amount, 0, desc, { sourceId: src.id }),
        line(CODES.NR, 0, amount, desc, { partyId: input.partyId }),
      ];
      break;
    }
    case "check_bounce": {
      const party = requireParty(input);
      if (amount <= 0) throw new AccountingError("مبلغ برگشت چک نامعتبر است.");
      lines = [
        line(CODES.AR, amount, 0, desc, { partyId: party }),
        line(CODES.NR, 0, amount, desc, { partyId: party }),
      ];
      break;
    }
    case "capital_in": {
      const src = requireSource(ctx);
      if (amount <= 0) throw new AccountingError("مبلغ سرمایه نامعتبر است.");
      lines = [
        line(src.accountCode, amount, 0, desc, { sourceId: src.id }),
        line(CODES.CAPITAL, 0, amount, desc, { partyId: input.partyId }),
      ];
      break;
    }
    case "draw": {
      const src = requireSource(ctx);
      if (amount <= 0) throw new AccountingError("مبلغ برداشت نامعتبر است.");
      lines = [
        line(CODES.DRAW, amount, 0, desc, { partyId: input.partyId }),
        line(src.accountCode, 0, amount, desc, { sourceId: src.id }),
      ];
      break;
    }
    case "payroll": {
      if (amount <= 0) throw new AccountingError("مبلغ حقوق نامعتبر است.");
      lines = [
        line(CODES.WAGES, amount, 0, desc, { partyId: input.partyId }),
        line(CODES.WAGES_PAY, 0, amount, desc, { partyId: input.partyId }),
      ];
      break;
    }
    case "insurance": {
      if (amount <= 0) throw new AccountingError("مبلغ بیمه نامعتبر است.");
      const src = ctx.source;
      lines = [
        line(CODES.WAGES, amount, 0, desc),
        src
          ? line(src.accountCode, 0, amount, desc, { sourceId: src.id })
          : line(CODES.INSURANCE, 0, amount, desc),
      ];
      break;
    }
    case "tax": {
      if (amount <= 0) throw new AccountingError("مبلغ مالیات نامعتبر است.");
      const src = ctx.source;
      lines = [
        line(CODES.OTHER_EXP, amount, 0, desc),
        src
          ? line(src.accountCode, 0, amount, desc, { sourceId: src.id })
          : line(CODES.TAX, 0, amount, desc),
      ];
      break;
    }
    case "depreciation": {
      if (amount <= 0) throw new AccountingError("مبلغ استهلاک نامعتبر است.");
      lines = [
        line(CODES.DEPR, amount, 0, desc),
        line(CODES.ACCUM_DEP, 0, amount, desc),
      ];
      break;
    }
    case "prepaid": {
      const src = requireSource(ctx);
      if (amount <= 0) throw new AccountingError("مبلغ پیش‌پرداخت نامعتبر است.");
      lines = [
        line(CODES.PREPAID, amount, 0, desc, { partyId: input.partyId }),
        line(src.accountCode, 0, amount, desc, { sourceId: src.id }),
      ];
      break;
    }
    case "unearned": {
      const src = requireSource(ctx);
      if (amount <= 0) throw new AccountingError("مبلغ پیش‌دریافت نامعتبر است.");
      lines = [
        line(src.accountCode, amount, 0, desc, { sourceId: src.id }),
        line(CODES.UNEARNED, 0, amount, desc, { partyId: input.partyId }),
      ];
      break;
    }
    case "manual":
    case "adjustment":
    case "reversal":
    case "opening":
    case "closing": {
      const raw = input.manualLines ?? [];
      if (!raw.length) throw new AccountingError("ردیف‌های سند دستی خالی است.");
      lines = raw.map((l) => ({
        accountCode: "",
        accountId: l.accountId,
        partyId: l.partyId,
        debit: roundMoney(money(l.debit)),
        credit: roundMoney(money(l.credit)),
        description: l.description || desc,
      }));
      break;
    }
    default:
      throw new AccountingError("نوع عملیات پشتیبانی نمی‌شود.");
  }

  if (type !== "manual" && type !== "adjustment" && type !== "reversal" && type !== "opening" && type !== "closing") {
    assertBalanced(lines);
  } else {
    assertBalanced(lines);
  }
  return lines;
}

export function isInvoiceType(type: OperationType): boolean {
  return ["sale", "sale_return", "purchase", "purchase_return"].includes(type);
}

export function journalKindFor(type: OperationType): "normal" | "opening" | "closing" | "adjusting" | "reversal" | "manual" {
  if (type === "opening") return "opening";
  if (type === "closing") return "closing";
  if (type === "adjustment") return "adjusting";
  if (type === "reversal") return "reversal";
  if (type === "manual") return "manual";
  return "normal";
}
