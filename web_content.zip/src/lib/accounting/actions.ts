import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import { CHART, CODES } from "./chart";
import { AccountingError, buildJournalLines, splitBalance, type Books } from "./engine";
import { fiscalBounds, jalaliYearOf, padSeq, todayIso, uid } from "./format";
import type {
  AccountRow,
  CashAccountRow,
  JournalLineDraft,
  OpType,
  OperationRow,
  PartyKind,
  PartyRow,
  PostingInput,
  TrialBalanceRow,
} from "./types";

function num(v: unknown) {
  if (v == null || v === "") return 0;
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : 0;
}

function fail(e: unknown): never {
  if (e instanceof AccountingError) throw e;
  throw e;
}

type Sql = Awaited<ReturnType<typeof getSql>>;

async function loadBooks(sql: Sql, userId: string): Promise<Books> {
  const accounts = await sql<{
    id: string;
    code: string;
    name: string;
    level: number;
    parent_id: string | null;
    group_code: string;
    nature: string;
    is_postable: boolean;
    is_active: boolean;
    floating_type: string;
  }>`select * from accounts where user_id = ${userId}`;
  const cash = await sql<{
    id: string;
    account_id: string;
    name: string;
    kind: string;
    bank_name: string | null;
    account_number: string | null;
    is_active: boolean;
  }>`select * from cash_accounts where user_id = ${userId}`;
  const accountsById = new Map<string, AccountRow>();
  const accountsByCode = new Map<string, AccountRow>();
  for (const a of accounts) {
    const row: AccountRow = {
      id: a.id,
      code: a.code,
      name: a.name,
      level: a.level,
      parentId: a.parent_id,
      groupCode: a.group_code as AccountRow["groupCode"],
      nature: a.nature as "debit" | "credit",
      isPostable: a.is_postable,
      isActive: a.is_active,
      floatingType: a.floating_type as AccountRow["floatingType"],
    };
    accountsById.set(row.id, row);
    accountsByCode.set(row.code, row);
  }
  const cashById = new Map<string, CashAccountRow>();
  for (const c of cash) {
    cashById.set(c.id, {
      id: c.id,
      accountId: c.account_id,
      name: c.name,
      kind: c.kind as CashAccountRow["kind"],
      bankName: c.bank_name,
      accountNumber: c.account_number,
      isActive: c.is_active,
    });
  }
  return { accountsById, accountsByCode, cashById };
}

async function audit(
  sql: Sql,
  userId: string,
  action: string,
  entity: string,
  entityId?: string,
  extra?: { old?: unknown; next?: unknown; reason?: string; actorName?: string },
) {
  await sql`insert into audit_logs (id, user_id, actor_id, actor_name, action, entity, entity_id, old_value, new_value, reason)
    values (${uid()}, ${userId}, ${userId}, ${extra?.actorName ?? null}, ${action}, ${entity}, ${entityId ?? null},
      ${extra?.old ? JSON.stringify(extra.old) : null}, ${extra?.next ? JSON.stringify(extra.next) : null}, ${extra?.reason ?? null})`;
}

async function currentFy(sql: Sql, userId: string) {
  const rows = await sql<{
    id: string;
    code: string;
    name: string;
    start_date: string;
    end_date: string;
    status: string;
  }>`select * from fiscal_years where user_id = ${userId} and is_current = true limit 1`;
  if (!rows[0]) throw new AccountingError("سال مالی فعال یافت نشد.");
  return rows[0];
}

async function ensureDay(sql: Sql, userId: string, fyId: string, date: string) {
  const existing = await sql<{ id: string; status: string }>`
    select id, status from fiscal_days where user_id = ${userId} and day_date = ${date}::date`;
  if (existing[0]) return existing[0];
  const id = uid();
  await sql`insert into fiscal_days (id, user_id, fiscal_year_id, day_date, status)
    values (${id}, ${userId}, ${fyId}, ${date}::date, 'open')`;
  return { id, status: "open" };
}

function assertDateInFy(date: string, fy: { start_date: string; end_date: string }) {
  if (date < fy.start_date || date > fy.end_date) {
    throw new AccountingError("تاریخ خارج از سال مالی جاری است.");
  }
}

async function insertPosted(
  sql: Sql,
  userId: string,
  input: PostingInput,
  journalType: string,
) {
  const fy = await currentFy(sql, userId);
  assertDateInFy(input.date, fy);
  const day = await ensureDay(sql, userId, fy.id, input.date);
  if (day.status === "closed" && journalType !== "adjustment" && journalType !== "reversal") {
    throw new AccountingError("این روز بسته است. اصلاح فقط با سند اصلاحی مجاز است.");
  }
  const books = await loadBooks(sql, userId);
  const lines = buildJournalLines(input, books);
  const opId = uid();
  const jvId = uid();
  const seqOp = await sql<{ last_value: number }>`
    update sequences set last_value = last_value + 1
    where user_id = ${userId} and fiscal_year_id = ${fy.id} and kind = 'op'
    returning last_value`;
  const seqJv = await sql<{ last_value: number }>`
    update sequences set last_value = last_value + 1
    where user_id = ${userId} and fiscal_year_id = ${fy.id} and kind = 'jv'
    returning last_value`;
  const opNo = `OP-${fy.code}-${padSeq(seqOp[0]?.last_value ?? 1)}`;
  const jvNo = `JV-${fy.code}-${padSeq(seqJv[0]?.last_value ?? 1)}`;
  const extra = JSON.stringify({
    checkNumber: input.checkNumber,
    checkDueDate: input.checkDueDate,
    checkBankName: input.checkBankName,
    cashPortion: input.cashPortion,
    cogsAmount: input.cogsAmount,
    freightAmount: input.freightAmount,
  });
  const debit = lines.reduce((s, l) => s + l.debit, 0);
  const credit = lines.reduce((s, l) => s + l.credit, 0);
  if (debit !== credit) throw new AccountingError("کنترل توازن ناموفق بود.");

  await sql.query(
    `insert into operations (id, user_id, fiscal_year_id, day_id, number, op_type, op_date, description, party_id,
      cash_account_id, dest_cash_account_id, amount, status, journal_id, original_id, extra_json, created_by)
     values ($1,$2,$3,$4,$5,$6,$7::date,$8,$9,$10,$11,$12,'posted',$13,$14,$15,$2)`,
    [
      opId,
      userId,
      fy.id,
      day.id,
      opNo,
      input.opType,
      input.date,
      input.description || null,
      input.partyId || null,
      input.cashAccountId || null,
      input.destCashAccountId || null,
      amt(input),
      jvId,
      input.originalId || null,
      extra,
    ],
  );
  await sql.query(
    `insert into journals (id, user_id, fiscal_year_id, day_id, number, journal_date, description, journal_type,
      operation_id, original_journal_id, status, created_by)
     values ($1,$2,$3,$4,$5,$6::date,$7,$8,$9,$10,'posted',$2)`,
    [jvId, userId, fy.id, day.id, jvNo, input.date, input.description || null, journalType, opId, input.originalId || null],
  );
  for (let i = 0; i < lines.length; i += 1) {
    const l = lines[i];
    await sql.query(
      `insert into journal_lines (id, user_id, journal_id, line_no, account_id, party_id, cash_account_id, debit, credit, description)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
      [
        uid(),
        userId,
        jvId,
        i + 1,
        l.accountId,
        l.partyId || null,
        l.cashAccountId || null,
        l.debit,
        l.credit,
        l.description ?? input.description ?? null,
      ],
    );
  }

  if (input.opType === "check_receive" || input.opType === "check_pay") {
    await sql`insert into checks (id, user_id, number, kind, party_id, bank_name, amount, issue_date, due_date, status, operation_id)
      values (${uid()}, ${userId}, ${input.checkNumber || opNo}, ${input.opType === "check_receive" ? "receivable" : "payable"},
        ${input.partyId || null}, ${input.checkBankName || null}, ${amt(input)}, ${input.date}::date,
        ${input.checkDueDate || input.date}::date, ${input.opType === "check_receive" ? "in_hand" : "issued"}, ${opId})`;
  }

  await audit(sql, userId, "Create", "operation", opId, { next: { opNo, jvNo, type: input.opType, amount: amt(input) } });
  return { operationId: opId, journalId: jvId, operationNumber: opNo, journalNumber: jvNo, lines };
}

function amt(input: PostingInput) {
  if (input.lines?.length) return input.lines.reduce((s, l) => s + l.debit, 0);
  return Math.round(input.amount || 0);
}

async function seedIfNeeded(sql: Sql, userId: string) {
  const existing = await sql<{ seeded: boolean }>`select seeded from company_settings where user_id = ${userId}`;
  if (existing[0]?.seeded) {
    const fy = await currentFy(sql, userId);
    await ensureDay(sql, userId, fy.id, todayIso());
    return;
  }

  await sql`delete from journal_lines where user_id = ${userId}`;
  await sql`delete from journals where user_id = ${userId}`;
  await sql`delete from operations where user_id = ${userId}`;
  await sql`delete from checks where user_id = ${userId}`;
  await sql`delete from daily_closings where user_id = ${userId}`;
  await sql`delete from fiscal_days where user_id = ${userId}`;
  await sql`delete from sequences where user_id = ${userId}`;
  await sql`delete from cash_accounts where user_id = ${userId}`;
  await sql`delete from parties where user_id = ${userId}`;
  await sql`delete from accounts where user_id = ${userId}`;
  await sql`delete from fiscal_years where user_id = ${userId}`;

  const today = todayIso();
  const year = jalaliYearOf(today);
  const bounds = fiscalBounds(year);
  const fyId = uid();

  await sql`insert into company_settings (user_id, company_name, company_name_en, seeded)
    values (${userId}, 'بازرگانی خراسانی', 'MR,KHORASANI', false)
    on conflict (user_id) do nothing`;
  await sql`insert into fiscal_years (id, user_id, code, name, start_date, end_date, status, is_current)
    values (${fyId}, ${userId}, ${String(year)}, ${"سال مالی " + year}, ${bounds.start}::date, ${bounds.end}::date, 'open', true)`;
  await sql`insert into sequences (user_id, fiscal_year_id, kind, last_value) values
    (${userId}, ${fyId}, 'op', 0), (${userId}, ${fyId}, 'jv', 0)`;

  const idByCode = new Map<string, string>();
  for (const def of CHART) {
    const id = uid();
    idByCode.set(def.code, id);
    const parent = def.parent ? idByCode.get(def.parent) ?? null : null;
    await sql`insert into accounts (id, user_id, code, name, level, parent_id, group_code, nature, is_postable, is_active, floating_type)
      values (${id}, ${userId}, ${def.code}, ${def.name}, ${def.level}, ${parent}, ${def.group}, ${def.nature},
        ${Boolean(def.postable)}, true, ${def.floating ?? "none"})`;
  }

  const cashId = uid();
  const bank1 = uid();
  const bank2 = uid();
  const petty = uid();
  await sql`insert into cash_accounts (id, user_id, account_id, name, kind, bank_name, account_number) values
    (${cashId}, ${userId}, ${idByCode.get(CODES.CASH)!}, 'صندوق اصلی', 'cash', null, null),
    (${bank1}, ${userId}, ${idByCode.get(CODES.BANK_MELI)!}, 'بانک ملی — جاری شرکت', 'bank', 'بانک ملی', '۰۱۰۸۴۲۲۹۳۳'),
    (${bank2}, ${userId}, ${idByCode.get(CODES.BANK_MELLAT)!}, 'بانک ملت — جاری شرکت', 'bank', 'بانک ملت', '۴۵۷۸۱۲۳۰۰۱'),
    (${petty}, ${userId}, ${idByCode.get(CODES.PETTY)!}, 'تنخواه گردان دفتر', 'petty', null, null)`;

  const parties: { id: string; code: string; name: string; kind: PartyKind; phone: string; address: string }[] = [
    { id: uid(), code: "C-001", name: "فروشگاه زنجیره‌ای سپهر", kind: "customer", phone: "021-88901234", address: "تهران، سعادت‌آباد" },
    { id: uid(), code: "C-002", name: "شرکت آریا صنعت", kind: "customer", phone: "021-44556677", address: "کرج، شهرک صنعتی" },
    { id: uid(), code: "C-003", name: "بازرگانی پارس کالا", kind: "customer", phone: "031-32221100", address: "اصفهان" },
    { id: uid(), code: "C-004", name: "کلینیک نور", kind: "customer", phone: "021-22001122", address: "تهران، نیاوران" },
    { id: uid(), code: "S-001", name: "صنایع کاسپین", kind: "supplier", phone: "013-33334455", address: "رشت" },
    { id: uid(), code: "S-002", name: "پخش البرز", kind: "supplier", phone: "026-33550011", address: "کرج" },
    { id: uid(), code: "E-001", name: "واحد منابع انسانی", kind: "employee", phone: "021-1000", address: "دفتر مرکزی" },
    { id: uid(), code: "H-001", name: "شریک — خراسانی", kind: "shareholder", phone: "021-1001", address: "دفتر مرکزی" },
  ];
  for (const p of parties) {
    await sql`insert into parties (id, user_id, code, name, kind, phone, address) values
      (${p.id}, ${userId}, ${p.code}, ${p.name}, ${p.kind}, ${p.phone}, ${p.address})`;
  }

  const cust = (code: string) => parties.find((p) => p.code === code)!.id;
  const shift = (n: number) => {
    const d = new Date();
    d.setDate(d.getDate() + n);
    const z = (v: number) => String(v).padStart(2, "0");
    return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`;
  };

  const post = (input: PostingInput, jt = "auto") => insertPosted(sql, userId, input, jt);

  await post(
    {
      opType: "opening",
      date: bounds.start < today ? bounds.start : today,
      amount: 0,
      description: "سند افتتاحیه سال مالی — مانده حساب‌های دائمی",
      lines: [
        { accountId: idByCode.get(CODES.CASH)!, debit: 80_000_000, credit: 0, cashAccountId: cashId },
        { accountId: idByCode.get(CODES.BANK_MELI)!, debit: 3_500_000_000, credit: 0, cashAccountId: bank1 },
        { accountId: idByCode.get(CODES.BANK_MELLAT)!, debit: 1_200_000_000, credit: 0, cashAccountId: bank2 },
        { accountId: idByCode.get(CODES.PETTY)!, debit: 20_000_000, credit: 0, cashAccountId: petty },
        { accountId: idByCode.get(CODES.INVENTORY)!, debit: 800_000_000, credit: 0 },
        { accountId: idByCode.get(CODES.AR)!, debit: 150_000_000, credit: 0, partyId: cust("C-001") },
        { accountId: idByCode.get(CODES.AP)!, debit: 0, credit: 90_000_000, partyId: cust("S-001") },
        { accountId: idByCode.get(CODES.CAPITAL)!, debit: 0, credit: 5_660_000_000 },
      ],
    },
    "opening",
  );

  await post({ opType: "sale_cash", date: shift(-9), amount: 42_000_000, description: "فروش نقدی فاکتور ۱۲۴۰", cashAccountId: cashId, partyId: cust("C-004") });
  await post({ opType: "sale_credit", date: shift(-8), amount: 186_000_000, description: "فروش نسیه فاکتور ۱۲۴۱", partyId: cust("C-001") });
  await post({ opType: "purchase_credit", date: shift(-8), amount: 95_000_000, description: "خرید کالا از کاسپین", partyId: cust("S-001") });
  await post({ opType: "receipt", date: shift(-7), amount: 80_000_000, description: "دریافت بابت فاکتور قبلی", partyId: cust("C-001"), cashAccountId: bank1 });
  await post({ opType: "expense_cash", date: shift(-6), amount: 25_000_000, description: "اجاره دفتر مهر", cashAccountId: bank1, expenseAccountId: idByCode.get("610201") });
  await post({ opType: "sale_mixed", date: shift(-5), amount: 120_000_000, cashPortion: 40_000_000, description: "فروش ترکیبی فاکتور ۱۲۴۴", partyId: cust("C-002"), cashAccountId: bank2 });
  await post({ opType: "payment", date: shift(-4), amount: 40_000_000, description: "پرداخت علی‌الحساب به کاسپین", partyId: cust("S-001"), cashAccountId: bank1 });
  await post({ opType: "transfer", date: shift(-3), amount: 15_000_000, description: "انتقال بانک ملی به صندوق", cashAccountId: bank1, destCashAccountId: cashId });
  await post({ opType: "sale_cash", date: shift(-2), amount: 67_500_000, description: "فروش بانکی فاکتور ۱۲۴۸", cashAccountId: bank2, partyId: cust("C-003") });
  await post({ opType: "check_receive", date: shift(-2), amount: 50_000_000, description: "چک دریافتی سررسید ۱۰ روزه", partyId: cust("C-002"), checkNumber: "784512", checkDueDate: shift(10), checkBankName: "صادرات" });
  await post({ opType: "petty_fund", date: shift(-1), amount: 8_000_000, description: "شارژ تنخواه", cashAccountId: cashId });
  await post({ opType: "expense_cash", date: shift(-1), amount: 4_200_000, description: "قبض برق و اینترنت", cashAccountId: petty, expenseAccountId: idByCode.get("610301") });
  await post({ opType: "sale_credit", date: today, amount: 98_000_000, description: "فروش نسیه امروز — فاکتور ۱۲۵۰", partyId: cust("C-003") });
  await post({ opType: "receipt", date: today, amount: 35_000_000, description: "دریافت نقدی از کلینیک نور", partyId: cust("C-004"), cashAccountId: cashId });
  await post({ opType: "purchase_cash", date: today, amount: 22_000_000, description: "خرید نقدی ملزومات", cashAccountId: bank1, partyId: cust("S-002") });
  await post({ opType: "income", date: today, amount: 6_500_000, description: "درآمد خدمات مشاوره", cashAccountId: bank2, incomeAccountId: idByCode.get(CODES.SERVICES), partyId: cust("C-002") });

  await sql`update company_settings set seeded = true where user_id = ${userId}`;
  await audit(sql, userId, "Create", "fiscal_year", fyId, { next: { year, seeded: true } });
}

const postingSchema = z.object({
  opType: z.string(),
  date: z.string(),
  amount: z.number().optional().default(0),
  description: z.string().optional().default(""),
  partyId: z.string().optional(),
  cashAccountId: z.string().optional(),
  destCashAccountId: z.string().optional(),
  expenseAccountId: z.string().optional(),
  incomeAccountId: z.string().optional(),
  cogsAmount: z.number().optional(),
  cashPortion: z.number().optional(),
  discountAmount: z.number().optional(),
  freightAmount: z.number().optional(),
  checkNumber: z.string().optional(),
  checkDueDate: z.string().optional(),
  checkBankName: z.string().optional(),
  originalId: z.string().optional(),
  reason: z.string().optional(),
  lines: z
    .array(
      z.object({
        accountId: z.string(),
        debit: z.number(),
        credit: z.number(),
        partyId: z.string().nullable().optional(),
        cashAccountId: z.string().nullable().optional(),
        description: z.string().optional(),
      }),
    )
    .optional(),
});

export const bootstrapCompany = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    try {
      await seedIfNeeded(sql, context.userId);
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      throw new AccountingError(`خطا در آماده‌سازی دفاتر: ${msg}`);
    }
    const settings = await sql<{ company_name: string; company_name_en: string }>`
      select company_name, company_name_en from company_settings where user_id = ${context.userId}`;
    const fy = await currentFy(sql, context.userId);
    const day = await ensureDay(sql, context.userId, fy.id, todayIso());
    const accounts = await sql<{ id: string; code: string; name: string; level: number; group_code: string; nature: string; is_postable: boolean; floating_type: string }>`
      select id, code, name, level, group_code, nature, is_postable, floating_type from accounts where user_id = ${context.userId} order by code`;
    const parties = await sql<{ id: string; code: string; name: string; kind: string; phone: string | null; address: string | null; is_active: boolean }>`
      select id, code, name, kind, phone, address, is_active from parties where user_id = ${context.userId} and is_active = true order by code`;
    const cash = await sql<{ id: string; account_id: string; name: string; kind: string; bank_name: string | null; account_number: string | null }>`
      select id, account_id, name, kind, bank_name, account_number from cash_accounts where user_id = ${context.userId} and is_active = true`;
    return {
      companyName: settings[0]?.company_name ?? "بازرگانی خراسانی",
      companyNameEn: settings[0]?.company_name_en ?? "MR,KHORASANI",
      fiscalYear: fy,
      today: todayIso(),
      todayStatus: day.status,
      accounts: accounts.map((a) => ({
        id: a.id,
        code: a.code,
        name: a.name,
        level: a.level,
        groupCode: a.group_code,
        nature: a.nature,
        isPostable: a.is_postable,
        floatingType: a.floating_type,
      })),
      parties: parties.map((p) => ({
        id: p.id,
        code: p.code,
        name: p.name,
        kind: p.kind as PartyRow["kind"],
        phone: p.phone,
        address: p.address,
        isActive: p.is_active,
      })),
      cashAccounts: cash.map((c) => ({
        id: c.id,
        accountId: c.account_id,
        name: c.name,
        kind: c.kind,
        bankName: c.bank_name,
        accountNumber: c.account_number,
        isActive: true,
      })),
    };
  });

export const postOperation = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((raw: unknown) => postingSchema.parse(raw))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await seedIfNeeded(sql, context.userId);
    try {
      const jt =
        data.opType === "manual"
          ? "manual"
          : data.opType === "adjustment"
            ? "adjustment"
            : data.opType === "reversal"
              ? "reversal"
              : "auto";
      return await insertPosted(sql, context.userId, data as PostingInput, jt);
    } catch (e) {
      fail(e);
    }
  });

export const previewJournal = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((raw: unknown) => postingSchema.parse(raw))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await seedIfNeeded(sql, context.userId);
    const books = await loadBooks(sql, context.userId);
    try {
      const lines = buildJournalLines(data as PostingInput, books);
      const debit = lines.reduce((s, l) => s + l.debit, 0);
      const credit = lines.reduce((s, l) => s + l.credit, 0);
      return { lines, debit, credit, balanced: debit === credit };
    } catch (e) {
      fail(e);
    }
  });

export const listOperations = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((raw: unknown) =>
    z
      .object({
        from: z.string().optional(),
        to: z.string().optional(),
        opType: z.string().optional(),
        status: z.string().optional(),
        q: z.string().optional(),
      })
      .parse(raw ?? {}),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await seedIfNeeded(sql, context.userId);
    const from = data.from || "1900-01-01";
    const to = data.to || "2100-01-01";
    const rows = await sql<{
      id: string;
      number: string;
      op_type: string;
      op_date: string;
      description: string | null;
      party_id: string | null;
      party_name: string | null;
      cash_account_id: string | null;
      dest_cash_account_id: string | null;
      amount: string;
      status: string;
      journal_id: string | null;
      journal_number: string | null;
      original_id: string | null;
      created_at: string;
      day_status: string;
    }>`select o.id, o.number, o.op_type, o.op_date::text, o.description, o.party_id, p.name as party_name,
        o.cash_account_id, o.dest_cash_account_id, o.amount::text, o.status, o.journal_id, j.number as journal_number,
        o.original_id, o.created_at::text, d.status as day_status
      from operations o
      left join parties p on p.id = o.party_id
      left join journals j on j.id = o.journal_id
      join fiscal_days d on d.id = o.day_id
      where o.user_id = ${context.userId}
        and o.op_date between ${from}::date and ${to}::date
        and (${data.opType ?? null}::text is null or o.op_type = ${data.opType ?? null})
        and (${data.status ?? null}::text is null or o.status = ${data.status ?? null})
      order by o.op_date desc, o.created_at desc
      limit 400`;
    const q = (data.q ?? "").trim();
    return rows
      .filter((r) => {
        if (!q) return true;
        const blob = `${r.number} ${r.description ?? ""} ${r.party_name ?? ""} ${r.journal_number ?? ""} ${r.amount}`.toLowerCase();
        return blob.includes(q.toLowerCase());
      })
      .map(
        (r): OperationRow => ({
          id: r.id,
          number: r.number,
          opType: r.op_type as OpType,
          opDate: r.op_date,
          description: r.description,
          partyId: r.party_id,
          partyName: r.party_name,
          cashAccountId: r.cash_account_id,
          destCashAccountId: r.dest_cash_account_id,
          amount: num(r.amount),
          status: r.status as OperationRow["status"],
          journalId: r.journal_id,
          journalNumber: r.journal_number,
          originalId: r.original_id,
          createdAt: r.created_at,
          dayStatus: r.day_status as "open" | "closed",
        }),
      );
  });

export const softDeleteOperation = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((raw: unknown) => z.object({ id: z.string(), reason: z.string().min(2) }).parse(raw))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<{ id: string; status: string; journal_id: string | null; day_id: string; number: string }>`
      select id, status, journal_id, day_id, number from operations where id = ${data.id} and user_id = ${context.userId}`;
    const op = rows[0];
    if (!op) throw new AccountingError("عملیات یافت نشد.");
    const day = await sql<{ status: string }>`select status from fiscal_days where id = ${op.day_id} and user_id = ${context.userId}`;
    if (day[0]?.status === "closed") {
      throw new AccountingError("روز بسته است. حذف مستقیم مجاز نیست — از سند اصلاحی استفاده کنید.");
    }
    if (op.status === "deleted") throw new AccountingError("این رکورد قبلاً حذف منطقی شده است.");
    await sql`update operations set status = 'deleted', deleted_at = now(), deleted_by = ${context.userId}, delete_reason = ${data.reason}
      where id = ${op.id} and user_id = ${context.userId}`;
    if (op.journal_id) {
      await sql`update journals set status = 'deleted' where id = ${op.journal_id} and user_id = ${context.userId}`;
    }
    await audit(sql, context.userId, "Delete", "operation", op.id, { old: { number: op.number, status: op.status }, reason: data.reason });
    return { ok: true };
  });

export const reverseOperation = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((raw: unknown) => z.object({ id: z.string(), reason: z.string().min(2) }).parse(raw))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await seedIfNeeded(sql, context.userId);
    const ops = await sql<{ id: string; journal_id: string | null; op_type: string; amount: string; description: string | null }>`
      select id, journal_id, op_type, amount::text, description from operations where id = ${data.id} and user_id = ${context.userId}`;
    const op = ops[0];
    if (!op?.journal_id) throw new AccountingError("سند مرتبط یافت نشد.");
    const lines = await sql<{ account_id: string; party_id: string | null; cash_account_id: string | null; debit: string; credit: string; description: string | null }>`
      select account_id, party_id, cash_account_id, debit::text, credit::text, description from journal_lines
      where journal_id = ${op.journal_id} and user_id = ${context.userId} order by line_no`;
    const result = await insertPosted(
      sql,
      context.userId,
      {
        opType: "reversal",
        date: todayIso(),
        amount: num(op.amount),
        description: `برگشت ${op.description ?? ""} — ${data.reason}`,
        originalId: op.id,
        reason: data.reason,
        lines: lines.map((l) => ({
          accountId: l.account_id,
          debit: num(l.debit),
          credit: num(l.credit),
          partyId: l.party_id,
          cashAccountId: l.cash_account_id,
          description: l.description ?? undefined,
        })),
      },
      "reversal",
    );
    await sql`update operations set status = 'reversed' where id = ${op.id} and user_id = ${context.userId}`;
    await audit(sql, context.userId, "Create Adjustment", "operation", result.operationId, {
      old: { original: op.id },
      reason: data.reason,
    });
    return result;
  });

export const getDashboard = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await seedIfNeeded(sql, context.userId);
    const today = todayIso();
    const fy = await currentFy(sql, context.userId);
    const day = await ensureDay(sql, context.userId, fy.id, today);

    const bal = await sql<{ code: string; name: string; nature: string; group_code: string; debit: string; credit: string }>`
      select a.code, a.name, a.nature, a.group_code, coalesce(sum(jl.debit),0)::text as debit, coalesce(sum(jl.credit),0)::text as credit
      from accounts a
      left join journal_lines jl on jl.account_id = a.id
      left join journals j on j.id = jl.journal_id and j.status = 'posted' and j.user_id = a.user_id
      where a.user_id = ${context.userId} and a.is_postable = true
      group by a.code, a.name, a.nature, a.group_code`;

    const byCode = Object.fromEntries(bal.map((b) => [b.code, num(b.debit) - num(b.credit)]));
    const cash = byCode[CODES.CASH] ?? 0;
    const bank = (byCode[CODES.BANK_MELI] ?? 0) + (byCode[CODES.BANK_MELLAT] ?? 0);
    const petty = byCode[CODES.PETTY] ?? 0;
    const ar = byCode[CODES.AR] ?? 0;
    const ap = -(byCode[CODES.AP] ?? 0);
    const notesRec = byCode[CODES.NOTES_REC] ?? 0;
    const notesPay = -(byCode[CODES.NOTES_PAY] ?? 0);

    const income = bal.filter((b) => b.group_code === "income").reduce((s, b) => s + (num(b.credit) - num(b.debit)), 0);
    const cogs = bal.filter((b) => b.group_code === "cogs").reduce((s, b) => s + (num(b.debit) - num(b.credit)), 0);
    const expense = bal.filter((b) => b.group_code === "expense").reduce((s, b) => s + (num(b.debit) - num(b.credit)), 0);

    const todayOps = await sql<{ op_type: string; amount: string }>`
      select op_type, amount::text from operations
      where user_id = ${context.userId} and op_date = ${today}::date and status = 'posted'`;

    const sumType = (...types: string[]) =>
      todayOps.filter((o) => types.includes(o.op_type)).reduce((s, o) => s + num(o.amount), 0);
    const salesToday =
      sumType("sale_cash", "sale_credit", "sale_mixed") - sumType("sale_return", "sale_discount");
    const receiptsToday = sumType("receipt", "receipt_other", "check_collect");
    const paymentsToday = sumType("payment", "payment_other");
    const expenseToday = sumType("expense_cash", "expense_payable", "payroll", "petty_settle");

    const series = await sql<{ d: string; op_type: string; amount: string }>`
      select op_date::text as d, op_type, amount::text
      from operations
      where user_id = ${context.userId} and status = 'posted' and op_date >= (current_date - 13)
      order by op_date`;

    const byDay: Record<string, { sales: number; receipts: number; payments: number; expense: number }> = {};
    for (let i = 13; i >= 0; i -= 1) {
      const dt = new Date();
      dt.setDate(dt.getDate() - i);
      const z = (v: number) => String(v).padStart(2, "0");
      const key = `${dt.getFullYear()}-${z(dt.getMonth() + 1)}-${z(dt.getDate())}`;
      byDay[key] = { sales: 0, receipts: 0, payments: 0, expense: 0 };
    }
    for (const r of series) {
      const bucket = byDay[r.d];
      if (!bucket) continue;
      const a = num(r.amount);
      if (["sale_cash", "sale_credit", "sale_mixed"].includes(r.op_type)) bucket.sales += a;
      if (r.op_type === "sale_return") bucket.sales -= a;
      if (["receipt", "receipt_other", "check_collect"].includes(r.op_type)) bucket.receipts += a;
      if (["payment", "payment_other"].includes(r.op_type)) bucket.payments += a;
      if (["expense_cash", "expense_payable", "payroll"].includes(r.op_type)) bucket.expense += a;
    }

    const topAr = await sql<{ name: string; bal: string }>`
      select p.name, coalesce(sum(jl.debit - jl.credit),0)::text as bal
      from parties p
      join journal_lines jl on jl.party_id = p.id
      join journals j on j.id = jl.journal_id and j.status = 'posted'
      join accounts a on a.id = jl.account_id and a.code = ${CODES.AR}
      where p.user_id = ${context.userId}
      group by p.name
      having coalesce(sum(jl.debit - jl.credit),0) > 0
      order by coalesce(sum(jl.debit - jl.credit),0) desc
      limit 5`;

    const topAp = await sql<{ name: string; bal: string }>`
      select p.name, coalesce(sum(jl.credit - jl.debit),0)::text as bal
      from parties p
      join journal_lines jl on jl.party_id = p.id
      join journals j on j.id = jl.journal_id and j.status = 'posted'
      join accounts a on a.id = jl.account_id and a.code = ${CODES.AP}
      where p.user_id = ${context.userId}
      group by p.name
      having coalesce(sum(jl.credit - jl.debit),0) > 0
      order by coalesce(sum(jl.credit - jl.debit),0) desc
      limit 5`;

    return {
      today,
      todayStatus: day.status,
      fiscalYear: fy.code,
      cash,
      bank,
      petty,
      liquid: cash + bank + petty,
      ar,
      ap,
      notesRec,
      notesPay,
      salesToday,
      receiptsToday,
      paymentsToday,
      expenseToday,
      netCashToday: receiptsToday - paymentsToday - expenseToday,
      income,
      cogs,
      expense,
      gross: income - cogs,
      net: income - cogs - expense,
      series: Object.entries(byDay).map(([date, v]) => ({ date, ...v })),
      topDebtors: topAr.map((r) => ({ name: r.name, amount: num(r.bal) })),
      topCreditors: topAp.map((r) => ({ name: r.name, amount: num(r.bal) })),
    };
  });

export const getTrialBalance = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((raw: unknown) => z.object({ from: z.string(), to: z.string() }).parse(raw ?? { from: "1900-01-01", to: "2100-01-01" }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await seedIfNeeded(sql, context.userId);
    const rows = await sql<{
      id: string;
      code: string;
      name: string;
      level: number;
      group_code: string;
      nature: string;
      open_d: string;
      open_c: string;
      turn_d: string;
      turn_c: string;
    }>`select a.id, a.code, a.name, a.level, a.group_code, a.nature,
        coalesce(sum(case when j.journal_date < ${data.from}::date then jl.debit else 0 end),0)::text as open_d,
        coalesce(sum(case when j.journal_date < ${data.from}::date then jl.credit else 0 end),0)::text as open_c,
        coalesce(sum(case when j.journal_date between ${data.from}::date and ${data.to}::date then jl.debit else 0 end),0)::text as turn_d,
        coalesce(sum(case when j.journal_date between ${data.from}::date and ${data.to}::date then jl.credit else 0 end),0)::text as turn_c
      from accounts a
      left join journal_lines jl on jl.account_id = a.id
      left join journals j on j.id = jl.journal_id and j.status = 'posted' and j.user_id = a.user_id
      where a.user_id = ${context.userId} and a.is_postable = true
      group by a.id, a.code, a.name, a.level, a.group_code, a.nature
      order by a.code`;
    const mapped: TrialBalanceRow[] = rows.map((r) => {
      const openRaw =
        r.nature === "debit" ? num(r.open_d) - num(r.open_c) : num(r.open_c) - num(r.open_d);
      const open = splitBalance(r.nature as "debit" | "credit", openRaw);
      const endRaw =
        r.nature === "debit"
          ? num(r.open_d) + num(r.turn_d) - num(r.open_c) - num(r.turn_c)
          : num(r.open_c) + num(r.turn_c) - num(r.open_d) - num(r.turn_d);
      const end = splitBalance(r.nature as "debit" | "credit", endRaw);
      return {
        accountId: r.id,
        code: r.code,
        name: r.name,
        level: r.level,
        groupCode: r.group_code,
        openingDebit: open.debit,
        openingCredit: open.credit,
        turnoverDebit: num(r.turn_d),
        turnoverCredit: num(r.turn_c),
        balanceDebit: end.debit,
        balanceCredit: end.credit,
      };
    });
    const totals = mapped.reduce(
      (s, r) => {
        s.openingDebit += r.openingDebit;
        s.openingCredit += r.openingCredit;
        s.turnoverDebit += r.turnoverDebit;
        s.turnoverCredit += r.turnoverCredit;
        s.balanceDebit += r.balanceDebit;
        s.balanceCredit += r.balanceCredit;
        return s;
      },
      { openingDebit: 0, openingCredit: 0, turnoverDebit: 0, turnoverCredit: 0, balanceDebit: 0, balanceCredit: 0 },
    );
    return {
      rows: mapped.filter(
        (r) =>
          r.openingDebit ||
          r.openingCredit ||
          r.turnoverDebit ||
          r.turnoverCredit ||
          r.balanceDebit ||
          r.balanceCredit,
      ),
      totals,
      difference: totals.balanceDebit - totals.balanceCredit,
    };
  });

export const getStatements = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((raw: unknown) => z.object({ from: z.string(), to: z.string() }).parse(raw))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await seedIfNeeded(sql, context.userId);
    const rows = await sql<{ code: string; name: string; group_code: string; nature: string; d: string; c: string }>`
      select a.code, a.name, a.group_code, a.nature, coalesce(sum(jl.debit),0)::text as d, coalesce(sum(jl.credit),0)::text as c
      from accounts a
      left join journal_lines jl on jl.account_id = a.id
      left join journals j on j.id = jl.journal_id and j.status = 'posted' and j.user_id = a.user_id
        and j.journal_date between ${data.from}::date and ${data.to}::date
      where a.user_id = ${context.userId} and a.is_postable = true
      group by a.code, a.name, a.group_code, a.nature
      order by a.code`;
    const pick = (g: string) =>
      rows
        .filter((r) => r.group_code === g)
        .map((r) => {
          const raw = r.nature === "credit" ? num(r.c) - num(r.d) : num(r.d) - num(r.c);
          return { code: r.code, name: r.name, amount: raw };
        })
        .filter((r) => r.amount !== 0);
    const asOf = await sql<{ code: string; name: string; group_code: string; nature: string; d: string; c: string }>`
      select a.code, a.name, a.group_code, a.nature, coalesce(sum(jl.debit),0)::text as d, coalesce(sum(jl.credit),0)::text as c
      from accounts a
      left join journal_lines jl on jl.account_id = a.id
      left join journals j on j.id = jl.journal_id and j.status = 'posted' and j.user_id = a.user_id
        and j.journal_date <= ${data.to}::date
      where a.user_id = ${context.userId} and a.is_postable = true
      group by a.code, a.name, a.group_code, a.nature
      order by a.code`;
    const pickAsOf = (groups: string[]) =>
      asOf
        .filter((r) => groups.includes(r.group_code))
        .map((r) => {
          const raw = r.nature === "credit" ? num(r.c) - num(r.d) : num(r.d) - num(r.c);
          return { code: r.code, name: r.name, amount: raw, group: r.group_code };
        })
        .filter((r) => r.amount !== 0);

    const income = pick("income");
    const cogs = pick("cogs");
    const expense = pick("expense");
    const incomeSum = income.reduce((s, r) => s + r.amount, 0);
    const cogsSum = cogs.reduce((s, r) => s + r.amount, 0);
    const expSum = expense.reduce((s, r) => s + r.amount, 0);
    const net = incomeSum - cogsSum - expSum;

    const ops = await sql<{ op_type: string; amount: string }>`
      select op_type, amount::text from operations
      where user_id = ${context.userId} and status = 'posted' and op_date between ${data.from}::date and ${data.to}::date`;
    const sum = (...t: string[]) => ops.filter((o) => t.includes(o.op_type)).reduce((s, o) => s + num(o.amount), 0);

    return {
      pnl: {
        income,
        cogs,
        expense,
        incomeSum,
        cogsSum,
        expSum,
        gross: incomeSum - cogsSum,
        net,
      },
      balanceSheet: {
        assets: pickAsOf(["asset", "contra"]),
        liabilities: pickAsOf(["liability"]),
        equity: pickAsOf(["equity"]),
        net,
      },
      cashFlow: {
        receipts: sum("receipt", "receipt_other", "sale_cash", "check_collect", "income", "capital_in", "advance"),
        payments: sum("payment", "payment_other", "purchase_cash", "expense_cash", "payroll", "draw", "prepay"),
        transfers: sum("transfer", "petty_fund"),
      },
    };
  });

export const getJournalBook = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((raw: unknown) => z.object({ from: z.string(), to: z.string(), accountId: z.string().optional() }).parse(raw))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await seedIfNeeded(sql, context.userId);
    const rows = await sql<{
      journal_id: string;
      number: string;
      journal_date: string;
      jdesc: string | null;
      journal_type: string;
      status: string;
      line_no: number;
      code: string;
      aname: string;
      party_name: string | null;
      debit: string;
      credit: string;
      ldesc: string | null;
      op_number: string | null;
    }>`select j.id as journal_id, j.number, j.journal_date::text, j.description as jdesc, j.journal_type, j.status,
        jl.line_no, a.code, a.name as aname, p.name as party_name, jl.debit::text, jl.credit::text, jl.description as ldesc,
        o.number as op_number
      from journals j
      join journal_lines jl on jl.journal_id = j.id
      join accounts a on a.id = jl.account_id
      left join parties p on p.id = jl.party_id
      left join operations o on o.id = j.operation_id
      where j.user_id = ${context.userId}
        and j.journal_date between ${data.from}::date and ${data.to}::date
        and (${data.accountId ?? null}::text is null or jl.account_id = ${data.accountId ?? null})
      order by j.journal_date, j.number, jl.line_no`;
    return rows.map((r) => ({
      journalId: r.journal_id,
      number: r.number,
      date: r.journal_date,
      journalDescription: r.jdesc,
      journalType: r.journal_type,
      status: r.status,
      lineNo: r.line_no,
      accountCode: r.code,
      accountName: r.aname,
      partyName: r.party_name,
      debit: num(r.debit),
      credit: num(r.credit),
      lineDescription: r.ldesc,
      operationNumber: r.op_number,
    }));
  });

export const getLedger = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((raw: unknown) =>
    z.object({ accountId: z.string(), from: z.string(), to: z.string(), partyId: z.string().optional() }).parse(raw),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await seedIfNeeded(sql, context.userId);
    const acc = await sql<{ name: string; code: string; nature: string }>`
      select name, code, nature from accounts where id = ${data.accountId} and user_id = ${context.userId}`;
    if (!acc[0]) throw new AccountingError("حساب یافت نشد.");
    const open = await sql<{ d: string; c: string }>`
      select coalesce(sum(jl.debit),0)::text as d, coalesce(sum(jl.credit),0)::text as c
      from journal_lines jl join journals j on j.id = jl.journal_id
      where jl.user_id = ${context.userId} and j.status = 'posted' and jl.account_id = ${data.accountId}
        and j.journal_date < ${data.from}::date
        and (${data.partyId ?? null}::text is null or jl.party_id = ${data.partyId ?? null})`;
    const lines = await sql<{
      date: string;
      number: string;
      description: string | null;
      party_name: string | null;
      debit: string;
      credit: string;
    }>`select j.journal_date::text as date, j.number, coalesce(jl.description, j.description) as description,
        p.name as party_name, jl.debit::text, jl.credit::text
      from journal_lines jl
      join journals j on j.id = jl.journal_id
      left join parties p on p.id = jl.party_id
      where jl.user_id = ${context.userId} and j.status = 'posted' and jl.account_id = ${data.accountId}
        and j.journal_date between ${data.from}::date and ${data.to}::date
        and (${data.partyId ?? null}::text is null or jl.party_id = ${data.partyId ?? null})
      order by j.journal_date, j.number`;
    const openingRaw =
      acc[0].nature === "debit" ? num(open[0]?.d) - num(open[0]?.c) : num(open[0]?.c) - num(open[0]?.d);
    let running = acc[0].nature === "debit" ? num(open[0]?.d) - num(open[0]?.c) : num(open[0]?.c) - num(open[0]?.d);
    const mapped = lines.map((l) => {
      const d = num(l.debit);
      const c = num(l.credit);
      running += acc[0].nature === "debit" ? d - c : c - d;
      return { ...l, debit: d, credit: c, balance: running };
    });
    return {
      account: acc[0],
      opening: openingRaw,
      lines: mapped,
      turnoverDebit: mapped.reduce((s, l) => s + l.debit, 0),
      turnoverCredit: mapped.reduce((s, l) => s + l.credit, 0),
      closing: running,
    };
  });

export const getPartyCard = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await seedIfNeeded(sql, context.userId);
    const rows = await sql<{
      id: string;
      code: string;
      name: string;
      kind: string;
      phone: string | null;
      address: string | null;
      last_date: string | null;
      op_count: number;
      sales: string;
      purchases: string;
      receipts: string;
      payments: string;
      ar: string;
      ap: string;
    }>`select p.id, p.code, p.name, p.kind, p.phone, p.address,
        max(o.op_date)::text as last_date,
        count(distinct o.id)::int as op_count,
        coalesce(sum(case when o.op_type in ('sale_cash','sale_credit','sale_mixed') and o.status='posted' then o.amount else 0 end),0)::text as sales,
        coalesce(sum(case when o.op_type in ('purchase_cash','purchase_credit') and o.status='posted' then o.amount else 0 end),0)::text as purchases,
        coalesce(sum(case when o.op_type in ('receipt','receipt_other') and o.status='posted' then o.amount else 0 end),0)::text as receipts,
        coalesce(sum(case when o.op_type in ('payment','payment_other') and o.status='posted' then o.amount else 0 end),0)::text as payments,
        coalesce((select sum(jl.debit - jl.credit) from journal_lines jl join journals j on j.id = jl.journal_id join accounts a on a.id = jl.account_id
          where jl.party_id = p.id and j.status='posted' and a.code = ${CODES.AR}),0)::text as ar,
        coalesce((select sum(jl.credit - jl.debit) from journal_lines jl join journals j on j.id = jl.journal_id join accounts a on a.id = jl.account_id
          where jl.party_id = p.id and j.status='posted' and a.code = ${CODES.AP}),0)::text as ap
      from parties p
      left join operations o on o.party_id = p.id and o.user_id = p.user_id
      where p.user_id = ${context.userId}
      group by p.id, p.code, p.name, p.kind, p.phone, p.address
      order by p.code`;
    return rows.map((r) => ({
      id: r.id,
      code: r.code,
      name: r.name,
      kind: r.kind,
      phone: r.phone,
      address: r.address,
      lastDate: r.last_date,
      opCount: r.op_count,
      sales: num(r.sales),
      purchases: num(r.purchases),
      receipts: num(r.receipts),
      payments: num(r.payments),
      ar: num(r.ar),
      ap: num(r.ap),
    }));
  });

export const createParty = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((raw: unknown) =>
    z.object({
      name: z.string().min(2),
      kind: z.string(),
      phone: z.string().optional(),
      address: z.string().optional(),
    }).parse(raw),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await seedIfNeeded(sql, context.userId);
    const n = await sql<{ c: number }>`select count(*)::int as c from parties where user_id = ${context.userId}`;
    const code = `${data.kind.slice(0, 1).toUpperCase()}-${String((n[0]?.c ?? 0) + 1).padStart(3, "0")}`;
    const id = uid();
    await sql`insert into parties (id, user_id, code, name, kind, phone, address)
      values (${id}, ${context.userId}, ${code}, ${data.name}, ${data.kind}, ${data.phone ?? null}, ${data.address ?? null})`;
    await audit(sql, context.userId, "Create", "party", id, { next: data });
    return { id, code };
  });

export const createAccount = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((raw: unknown) =>
    z.object({
      code: z.string().min(1),
      name: z.string().min(2),
      parentCode: z.string(),
      nature: z.enum(["debit", "credit"]),
      groupCode: z.string(),
      floatingType: z.string().optional(),
    }).parse(raw),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await seedIfNeeded(sql, context.userId);
    const parent = await sql<{ id: string; level: number }>`
      select id, level from accounts where user_id = ${context.userId} and code = ${data.parentCode}`;
    if (!parent[0]) throw new AccountingError("حساب والد یافت نشد.");
    if (parent[0].level >= 4) throw new AccountingError("عمیق‌تر از سطح تفصیلی مجاز نیست.");
    const id = uid();
    await sql`insert into accounts (id, user_id, code, name, level, parent_id, group_code, nature, is_postable, is_active, floating_type)
      values (${id}, ${context.userId}, ${data.code}, ${data.name}, ${parent[0].level + 1}, ${parent[0].id},
        ${data.groupCode}, ${data.nature}, true, true, ${data.floatingType ?? "none"})`;
    await audit(sql, context.userId, "Modify Account", "account", id, { next: data });
    return { id };
  });

export const listChecks = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await seedIfNeeded(sql, context.userId);
    const rows = await sql<{
      id: string; number: string; kind: string; party_name: string | null; bank_name: string | null;
      amount: string; issue_date: string | null; due_date: string | null; status: string; operation_id: string | null;
    }>`select c.id, c.number, c.kind, p.name as party_name, c.bank_name, c.amount::text, c.issue_date::text, c.due_date::text, c.status, c.operation_id
      from checks c left join parties p on p.id = c.party_id
      where c.user_id = ${context.userId} order by c.due_date nulls last`;
    return rows.map((r) => ({ ...r, amount: num(r.amount) }));
  });

export const updateCheckStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((raw: unknown) => z.object({ id: z.string(), status: z.string() }).parse(raw))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`update checks set status = ${data.status} where id = ${data.id} and user_id = ${context.userId}`;
    await audit(sql, context.userId, "Edit", "check", data.id, { next: { status: data.status } });
    return { ok: true };
  });

export const closeDay = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((raw: unknown) => z.object({ date: z.string(), confirm: z.literal(true) }).parse(raw))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await seedIfNeeded(sql, context.userId);
    const fy = await currentFy(sql, context.userId);
    const day = await ensureDay(sql, context.userId, fy.id, data.date);
    if (day.status === "closed") throw new AccountingError("این روز قبلاً بسته شده است.");

    const unbalanced = await sql<{ number: string; d: string; c: string }>`
      select j.number, coalesce(sum(jl.debit),0)::text as d, coalesce(sum(jl.credit),0)::text as c
      from journals j join journal_lines jl on jl.journal_id = j.id
      where j.user_id = ${context.userId} and j.day_id = ${day.id} and j.status = 'posted'
      group by j.number
      having coalesce(sum(jl.debit),0) <> coalesce(sum(jl.credit),0)`;
    if (unbalanced.length) {
      throw new AccountingError(`اسناد نامتوازن: ${unbalanced.map((u) => u.number).join("، ")}`);
    }
    const badCash = await sql<{ n: number }>`
      select count(*)::int as n from operations
      where user_id = ${context.userId} and day_id = ${day.id} and status = 'posted'
        and op_type in ('receipt','payment','sale_cash','expense_cash','income')
        and cash_account_id is null`;
    if ((badCash[0]?.n ?? 0) > 0) throw new AccountingError("دریافت/پرداخت بدون منبع مالی وجود دارد.");

    const ops = await sql`select number, op_type, amount::text, description from operations where user_id = ${context.userId} and day_id = ${day.id} and status = 'posted'`;
    const pkg = {
      date: data.date,
      fiscalYear: fy.code,
      operationCount: ops.length,
      closedAt: new Date().toISOString(),
    };
    const { jy, jm, jd } = (await import("./format")).isoToJalali(data.date);
    const backupName = `MR-KHORASANI-Backup-${jy}-${String(jm).padStart(2, "0")}-${String(jd).padStart(2, "0")}`;
    const closeId = uid();
    await sql`insert into daily_closings (id, user_id, day_id, closed_by, package_json, backup_name)
      values (${closeId}, ${context.userId}, ${day.id}, ${context.userId}, ${JSON.stringify({ ...pkg, operations: ops })}, ${backupName})`;
    await sql`update fiscal_days set status = 'closed' where id = ${day.id} and user_id = ${context.userId}`;
    await audit(sql, context.userId, "Close Day", "fiscal_day", day.id, { next: { date: data.date, closeId, backupName } });
    return { closeId, backupName, packageJson: JSON.stringify({ ...pkg, operations: ops }) };
  });

export const requestReopenDay = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((raw: unknown) => z.object({ date: z.string(), phrase: z.string() }).parse(raw))
  .handler(async ({ context, data }) => {
    if (data.phrase.trim() !== "بازگشایی") {
      throw new AccountingError("برای تأیید، عبارت «بازگشایی» را وارد کنید.");
    }
    const sql = await getSql();
    const day = await sql<{ id: string; status: string }>`
      select id, status from fiscal_days where user_id = ${context.userId} and day_date = ${data.date}::date`;
    if (!day[0] || day[0].status !== "closed") throw new AccountingError("روز بسته‌ای برای این تاریخ نیست.");
    await sql`update fiscal_days set status = 'open' where id = ${day[0].id} and user_id = ${context.userId}`;
    await audit(sql, context.userId, "Reopen Day", "fiscal_day", day[0].id, { reason: "درخواست اصلاح روز بسته‌شده" });
    return { ok: true };
  });

export const exportBackup = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await seedIfNeeded(sql, context.userId);
    const operations = await sql`select * from operations where user_id = ${context.userId}`;
    const journals = await sql`select * from journals where user_id = ${context.userId}`;
    const lines = await sql`select * from journal_lines where user_id = ${context.userId}`;
    const accounts = await sql`select * from accounts where user_id = ${context.userId}`;
    const parties = await sql`select * from parties where user_id = ${context.userId}`;
    const checks = await sql`select * from checks where user_id = ${context.userId}`;
    const auditLogs = await sql`select * from audit_logs where user_id = ${context.userId} order by occurred_at desc limit 2000`;
    const closings = await sql`select id, backup_name, closed_at::text from daily_closings where user_id = ${context.userId}`;
    await audit(sql, context.userId, "Backup", "system", undefined);
    return {
      generatedAt: new Date().toISOString(),
      payload: JSON.stringify({ operations, journals, lines, accounts, parties, checks, auditLogs, closings }),
    };
  });

export const listAudit = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await seedIfNeeded(sql, context.userId);
    const rows = await sql<{
      id: string; action: string; entity: string; entity_id: string | null; occurred_at: string;
      old_value: string | null; new_value: string | null; reason: string | null;
    }>`select id, action, entity, entity_id, occurred_at::text, old_value, new_value, reason
      from audit_logs where user_id = ${context.userId} order by occurred_at desc limit 300`;
    return rows;
  });

export const getHealth = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await seedIfNeeded(sql, context.userId);
    const today = todayIso();
    const ops = await sql<{ n: number }>`select count(*)::int as n from operations where user_id = ${context.userId} and op_date = ${today}::date and status='posted'`;
    const jv = await sql<{ n: number }>`select count(*)::int as n from journals where user_id = ${context.userId} and status='posted'`;
    const unbal = await sql<{ n: number }>`
      select count(*)::int as n from (
        select j.id from journals j join journal_lines jl on jl.journal_id = j.id
        where j.user_id = ${context.userId} and j.status='posted'
        group by j.id having sum(jl.debit) <> sum(jl.credit)
      ) t`;
    const openDays = await sql<{ n: number }>`select count(*)::int as n from fiscal_days where user_id = ${context.userId} and status='open'`;
    const closedDays = await sql<{ n: number }>`select count(*)::int as n from fiscal_days where user_id = ${context.userId} and status='closed'`;
    const lastBackup = await sql<{ backup_name: string; closed_at: string }>`
      select backup_name, closed_at::text from daily_closings where user_id = ${context.userId} order by closed_at desc limit 1`;
    const auditN = await sql<{ n: number }>`select count(*)::int as n from audit_logs where user_id = ${context.userId}`;
    return {
      opsToday: ops[0]?.n ?? 0,
      journals: jv[0]?.n ?? 0,
      unbalanced: unbal[0]?.n ?? 0,
      openDays: openDays[0]?.n ?? 0,
      closedDays: closedDays[0]?.n ?? 0,
      lastBackup: lastBackup[0] ?? null,
      auditEvents: auditN[0]?.n ?? 0,
      syncPending: 0,
    };
  });

export const searchBooks = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((raw: unknown) => z.object({ q: z.string() }).parse(raw))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await seedIfNeeded(sql, context.userId);
    const q = `%${data.q}%`;
    const parties = await sql<{ id: string; name: string; code: string }>`
      select id, name, code from parties where user_id = ${context.userId} and (name ilike ${q} or code ilike ${q}) limit 8`;
    const ops = await sql<{ id: string; number: string; description: string | null }>`
      select id, number, description from operations where user_id = ${context.userId} and (number ilike ${q} or description ilike ${q}) limit 8`;
    const acc = await sql<{ id: string; code: string; name: string }>`
      select id, code, name from accounts where user_id = ${context.userId} and (code ilike ${q} or name ilike ${q}) limit 8`;
    return [
      ...parties.map((p) => ({ id: p.id, title: `${p.code} — ${p.name}`, kind: "شخص", to: "/parties" })),
      ...ops.map((o) => ({ id: o.id, title: `${o.number} ${o.description ?? ""}`, kind: "عملیات", to: "/operations" })),
      ...acc.map((a) => ({ id: a.id, title: `${a.code} ${a.name}`, kind: "حساب", to: "/accounts" })),
    ];
  });
