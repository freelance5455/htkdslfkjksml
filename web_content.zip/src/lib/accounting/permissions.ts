import type { OperationType, Role } from "./types";

const ALL: Role[] = ["admin", "finance", "accountant", "cashier", "sales", "auditor"];

const MATRIX: Record<string, Role[]> = {
  view: ALL,
  post: ["admin", "finance", "accountant", "cashier", "sales"],
  sale: ["admin", "finance", "accountant", "sales"],
  purchase: ["admin", "finance", "accountant"],
  cash: ["admin", "finance", "accountant", "cashier"],
  transfer: ["admin", "finance", "accountant", "cashier"],
  journal_manual: ["admin", "finance", "accountant"],
  close_day: ["admin", "finance"],
  reopen_request: ["admin", "finance"],
  adjustment: ["admin", "finance", "accountant"],
  accounts_edit: ["admin", "finance"],
  users: ["admin"],
  backup: ["admin", "finance"],
  restore: ["admin"],
  export: ALL,
  settings: ["admin", "finance"],
};

export function can(role: Role, action: keyof typeof MATRIX): boolean {
  return MATRIX[action]?.includes(role) ?? false;
}

export function canPostType(role: Role, type: OperationType): boolean {
  if (role === "auditor") return false;
  if (role === "admin" || role === "finance" || role === "accountant") return true;
  if (role === "cashier") {
    return [
      "receipt",
      "payment",
      "transfer",
      "transfer_cash_bank",
      "transfer_banks",
      "petty_in",
      "petty_settle",
      "check_in",
      "check_out",
      "check_collect",
      "check_bounce",
      "receipt_invoice",
      "receipt_other",
      "payment_invoice",
      "payment_other",
    ].includes(type);
  }
  if (role === "sales") {
    return ["sale", "sale_return", "receipt", "receipt_invoice", "receipt_other", "check_in"].includes(type);
  }
  return false;
}
