import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { clamp, extensionOf, formatBytes, formatDuration, parentFolder } from "./utils.ts";

describe("formatDuration", () => {
  it("formats mm:ss and h:mm:ss", () => {
    assert.equal(formatDuration(65), "1:05");
    assert.equal(formatDuration(3661), "1:01:01");
    assert.equal(formatDuration(-1), "—");
  });
});

describe("formatBytes", () => {
  it("uses binary steps", () => {
    assert.equal(formatBytes(512), "512 B");
    assert.equal(formatBytes(2048), "2.0 KB");
  });
});

describe("path helpers", () => {
  it("reads extension and folder", () => {
    assert.equal(extensionOf("Film.MP4"), "mp4");
    assert.equal(parentFolder("Movies/Film.mp4"), "Movies");
    assert.equal(parentFolder("Film.mp4"), "Root");
  });
});

describe("clamp", () => {
  it("bounds a number", () => {
    assert.equal(clamp(5, 0, 1), 1);
    assert.equal(clamp(-2, 0, 1), 0);
  });
});
