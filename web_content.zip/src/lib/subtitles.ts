import type { Cue } from "@/lib/media-types";

function parseTimestamp(raw: string): number {
  const cleaned = raw.trim().replace(",", ".");
  const parts = cleaned.split(":");
  if (parts.length < 2) {
    const n = Number.parseFloat(cleaned);
    return Number.isFinite(n) ? n : 0;
  }
  const secParts = (parts[parts.length - 1] ?? "0").split(".");
  const seconds = Number.parseInt(secParts[0] ?? "0", 10) || 0;
  const frac = secParts[1] ? Number.parseFloat(`0.${secParts[1]}`) : 0;
  const minutes = Number.parseInt(parts[parts.length - 2] ?? "0", 10) || 0;
  const hours = parts.length > 2 ? Number.parseInt(parts[0] ?? "0", 10) || 0 : 0;
  return hours * 3600 + minutes * 60 + seconds + frac;
}

function splitBlocks(text: string): string[] {
  return text.replace(/\r/g, "").split(/\n{2,}/);
}

/**
 * Parse SRT or VTT into cues. Malformed blocks are skipped, never thrown.
 */
export function parseSubtitles(source: string): Cue[] {
  if (!source || typeof source !== "string") return [];
  let body = source.replace(/^\uFEFF/, "");
  if (body.slice(0, 6).toUpperCase() === "WEBVTT") {
    const headerEnd = body.indexOf("\n");
    body = headerEnd >= 0 ? body.slice(headerEnd + 1) : "";
    body = body.replace(/^(NOTE|STYLE|REGION)[\s\S]*?(?=\n\n|$)/gm, "");
  }
  const cues: Cue[] = [];
  for (const block of splitBlocks(body)) {
    const lines = block.split("\n").map((l) => l.trim()).filter(Boolean);
    if (lines.length === 0) continue;
    let idx = 0;
    if (lines[0] && !lines[0].includes("-->") && /^[\w-]+$/.test(lines[0])) {
      idx = 1;
    }
    const timing = lines[idx];
    if (!timing || !timing.includes("-->")) continue;
    const [startRaw, endRaw] = timing.split("-->").map((s) => s.trim().split(" ")[0]);
    if (!startRaw || !endRaw) continue;
    const start = parseTimestamp(startRaw);
    const end = parseTimestamp(endRaw);
    if (!(end > start)) continue;
    const text = lines
      .slice(idx + 1)
      .join("\n")
      .replace(/<[^>]+>/g, "")
      .trim();
    if (!text) continue;
    cues.push({ start, end, text });
  }
  return cues.sort((a, b) => a.start - b.start);
}

export function shiftCues(cues: Cue[], delaySec: number): Cue[] {
  if (!delaySec) return cues;
  return cues.map((c) => ({
    ...c,
    start: Math.max(0, c.start + delaySec),
    end: Math.max(0, c.end + delaySec),
  }));
}

export function activeCue(cues: Cue[], time: number): Cue | undefined {
  if (!cues.length) return undefined;
  let lo = 0;
  let hi = cues.length - 1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    const c = cues[mid]!;
    if (time < c.start) hi = mid - 1;
    else if (time > c.end) lo = mid + 1;
    else return c;
  }
  return undefined;
}

export function matchSubtitleFilename(mediaName: string, subtitleName: string): boolean {
  const strip = (n: string) => n.replace(/\.[^.]+$/, "").toLowerCase();
  const a = strip(mediaName);
  const b = strip(subtitleName);
  return a === b || b.startsWith(a) || a.startsWith(b);
}

export async function readSubtitleFile(file: File): Promise<Cue[]> {
  try {
    const text = await file.text();
    return parseSubtitles(text);
  } catch {
    return [];
  }
}
