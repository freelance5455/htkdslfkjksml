import type { Cue, TransWord } from "../types";

export function pad(n: number, l = 2): string {
  return String(n).padStart(l, "0");
}

export function fmtSRT(t: number): string {
  const ms = Math.max(0, Math.round(t * 1000));
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  return `${pad(h)}:${pad(m)}:${pad(s)},${pad(ms % 1000, 3)}`;
}

export function fmtVTT(t: number): string {
  return fmtSRT(t).replace(",", ".");
}

export function fmtClock(t: number): string {
  const s = Math.max(0, Math.floor(t));
  return `${pad(Math.floor(s / 60))}:${pad(s % 60)}`;
}

function parseTime(s: string): number {
  const m = s
    .trim()
    .match(/(?:(\d+):)?(\d{1,2}):(\d{1,2})[.,](\d{1,3})/);
  if (!m) return -1;
  if (m[1] !== undefined)
    return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / Math.pow(10, m[4].length);
  return +m[2] * 60 + +m[3] + +m[4] / Math.pow(10, m[4].length);
}

function cleanText(s: string): string {
  return s.replace(/\s+/g, " ").trim();
}

export function parseSRT(src: string): Cue[] {
  const clean = src.replace(/^\uFEFF/, "").replace(/\r/g, "");
  const blocks = clean.split(/\n{2,}/);
  const cues: Cue[] = [];
  for (const b of blocks) {
    const lines = b.split("\n").filter((l) => l.trim() !== "");
    if (!lines.length) continue;
    let idx = 0;
    if (/^\d+$/.test(lines[0].trim())) idx = 1;
    const tl = lines[idx] ?? "";
    const mm = tl.split("-->");
    if (mm.length !== 2) continue;
    const start = parseTime(mm[0]);
    const end = parseTime(mm[1]);
    if (start < 0 || end < 0) continue;
    const text = cleanText(lines.slice(idx + 1).join(" "));
    if (text) cues.push({ start, end: Math.max(end, start + 0.3), text });
  }
  return cues.sort((a, b) => a.start - b.start);
}

export function parseVTT(src: string): Cue[] {
  const clean = src.replace(/^\uFEFF/, "").replace(/\r/g, "");
  const blocks = clean.split(/\n{2,}/);
  const cues: Cue[] = [];
  for (const b of blocks) {
    const lines = b.split("\n").filter((l) => l.trim() !== "");
    if (!lines.length) continue;
    if (/^(WEBVTT|NOTE|STYLE|REGION)\b/.test(lines[0])) continue;
    const tl = lines.find((l) => l.includes("-->"));
    if (!tl) continue;
    const mm = tl.split("-->");
    if (mm.length !== 2) continue;
    const start = parseTime(mm[0]);
    const end = parseTime(mm[1]);
    if (start < 0 || end < 0) continue;
    const rest = lines.slice(lines.indexOf(tl) + 1).join(" ");
    const text = cleanText(rest);
    if (text) cues.push({ start, end: Math.max(end, start + 0.3), text });
  }
  return cues.sort((a, b) => a.start - b.start);
}

export function parseASS(src: string): Cue[] {
  const cues: Cue[] = [];
  for (const raw of src.replace(/\r/g, "").split("\n")) {
    const line = raw.trim();
    if (!/^Dialogue:\s*/i.test(line)) continue;
    const parts = line.replace(/^Dialogue:\s*/i, "").split(",");
    if (parts.length < 9) continue;
    const start = parseTime(parts[1]);
    const end = parseTime(parts[2]);
    if (start < 0 || end < 0) continue;
    let text = parts.slice(8).join(",");
    text = text.replace(/\{[^}]*\}/g, " ").replace(/\\N/g, " ").replace(/\\h/g, " ");
    text = cleanText(text);
    if (text && text !== "Comment")
      cues.push({ start, end: Math.max(end, start + 0.3), text });
  }
  return cues.sort((a, b) => a.start - b.start);
}

export function parseSubtitles(src: string): { cues: Cue[]; format: string } {
  const s = src.replace(/^\uFEFF/, "");
  let cues: Cue[] = [];
  let format = "srt";
  if (/^WEBVTT/m.test(s)) {
    cues = parseVTT(s);
    format = "vtt";
  } else if (/^\[Script Info\]/m.test(s) || /^Format:\s*Dialogue/im.test(s)) {
    cues = parseASS(s);
    format = "ass";
  }
  if (cues.length === 0) {
    const a = parseSRT(s);
    if (a.length > 0) {
      cues = a;
      format = "srt";
    }
  }
  return { cues, format };
}

export function toSRT(cues: Cue[]): string {
  return cues
    .map(
      (c, i) =>
        `${i + 1}\n${fmtSRT(c.start)} --> ${fmtSRT(c.end)}\n${c.text}`
    )
    .join("\n\n");
}

export function toVTT(cues: Cue[]): string {
  return (
    "WEBVTT\n\n" +
    cues
      .map((c) => `${fmtVTT(c.start)} --> ${fmtVTT(c.end)}\n${c.text}`)
      .join("\n\n")
  );
}

const ARABIC_RE = /[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]/;
const URDU_SPECIFIC = /[ٹڈڻںےھڑںۓ]/;

export function isUrduScript(text: string): boolean {
  let ar = 0;
  let other = 0;
  for (const ch of text) {
    if (/\s/.test(ch)) continue;
    if (ARABIC_RE.test(ch)) ar++;
    else other++;
  }
  const tot = ar + other;
  return tot > 0 && ar / tot > 0.5;
}

/** Best-effort source language guess from script (used when Whisper runs in auto-detect). */
export function guessLang(text: string): string {
  let cyr = 0,
    dev = 0,
    ara = 0,
    urdSp = 0,
    cjk = 0,
    kana = 0,
    beng = 0,
    latin = 0;
  for (const ch of text) {
    const c = ch.codePointAt(0)!;
    if (c >= 0x0400 && c <= 0x04ff) cyr++;
    else if (c >= 0x0900 && c <= 0x097f) dev++;
    else if (c >= 0x0600 && c <= 0x06ff) {
      ara++;
      if (URDU_SPECIFIC.test(ch)) urdSp++;
    } else if (c >= 0x4e00 && c <= 0x9fff) cjk++;
    else if ((c >= 0x3040 && c <= 0x309f) || (c >= 0x30a0 && c <= 0x30ff)) kana++;
    else if (c >= 0x0980 && c <= 0x09ff) beng++;
    else if (
      (c >= 0x41 && c <= 0x5a) ||
      (c >= 0x61 && c <= 0x7a) ||
      (c >= 0xc0 && c <= 0x24f)
    )
      latin++;
  }
  if (kana > cjk * 0.2) return "ja";
  if (cjk > 0) return "zh";
  if (dev > 0) return "hi";
  if (beng > 0) return "bn";
  if (cyr > 0) return "ru";
  if (ara > 0) return urdSp / ara > 0.04 ? "ur" : "ar";
  if (latin > 0) return "en"; // ambiguous Latin scripts default to English
  return "en";
}

export interface Seg {
  start: number;
  end: number;
  text: string;
}

const SENT_END = /[.!?۔…:؛]/;

export function buildSegments(words: TransWord[]): Seg[] {
  const segs: Seg[] = [];
  let cur: TransWord[] = [];
  const flush = () => {
    if (!cur.length) return;
    segs.push({
      start: cur[0].s,
      end: Math.min(
        Math.max(cur[cur.length - 1].e, cur[0].s + 0.6),
        cur[0].s + 9
      ),
      text: cur
        .map((w) => w.t)
        .join(" ")
        .replace(/\s+/g, " ")
        .trim(),
    });
    cur = [];
  };
  for (const w of words) {
    if (!w.t.trim()) continue;
    const prev = cur[cur.length - 1];
    if (
      cur.length > 0 &&
      (w.s - (prev.e ?? prev.s) > 0.9 ||
        w.s - cur[0].s > 5.5 ||
        cur.length >= 9 ||
        (cur.length >= 2 && SENT_END.test(prev.t.trim().slice(-1))))
    )
      flush();
    cur.push(w);
  }
  flush();
  return segs.filter((s) => s.text.length > 0);
}

export function normalizeKey(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim();
}

export function downloadText(name: string, content: string, mime = "text/plain;charset=utf-8") {
  const blob = new Blob(["\uFEFF" + content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
