/**
 * "نموذج أ" — shared definitions used by the form page and the API route.
 * Keep this file free of server-only imports so it can run in the browser.
 */

export const GOVERNORATES = [
  "دمشق",
  "ريف دمشق",
  "حلب",
  "حمص",
  "حماة",
  "اللاذقية",
  "طرطوس",
  "إدلب",
  "دير الزور",
  "الرقة",
  "الحسكة",
  "درعا",
  "السويداء",
  "القنيطرة",
] as const;

export const ROLES = ["إمام", "خطيب", "مدرّس", "طالب علم", "موظف", "متطوع", "أخرى"] as const;

export const REQUEST_TYPES = ["طلب تسجيل", "طلب درس أو محاضرة", "اقتراح تطوير", "شكوى أو ملاحظة"] as const;

export type FormAInput = {
  fullName: string;
  phone: string;
  email: string;
  governorate: string;
  mosqueName: string;
  role: string;
  requestType: string;
  details: string;
};

export type FormAErrors = Partial<Record<keyof FormAInput, string>>;

const PHONE_RE = /^[0-9+\s-]{8,20}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function validateFormA(input: FormAInput): FormAErrors {
  const errors: FormAErrors = {};
  if (input.fullName.trim().length < 3) errors.fullName = "الرجاء إدخال الاسم الكامل (٣ أحرف على الأقل).";
  if (!PHONE_RE.test(input.phone.trim())) errors.phone = "رقم الهاتف غير صحيح.";
  if (input.email.trim() && !EMAIL_RE.test(input.email.trim())) errors.email = "البريد الإلكتروني غير صحيح.";
  if (!(GOVERNORATES as readonly string[]).includes(input.governorate)) errors.governorate = "اختر المحافظة.";
  if (!(ROLES as readonly string[]).includes(input.role)) errors.role = "اختر الصفة.";
  if (!(REQUEST_TYPES as readonly string[]).includes(input.requestType)) errors.requestType = "اختر نوع الطلب.";
  if (input.mosqueName.trim().length > 160) errors.mosqueName = "اسم الجامع طويل جداً.";
  if (input.details.trim().length < 10) errors.details = "الرجاء كتابة التفاصيل (١٠ أحرف على الأقل).";
  if (input.details.length > 2000) errors.details = "التفاصيل طويلة جداً (الحد ٢٠٠٠ حرف).";
  return errors;
}
