// JUHNKRIX MUSIKA - Cryptographic Cloudflare Event Logger & Earnings Attribution Utility
// Cryptographically signs event payloads with session IDs and routes them to juhnkrixmusika.pages.dev endpoints.

export interface CloudflareTelemetryEvent {
  eventId: string;
  sessionId: string;
  eventType: 'DOWNLOAD' | 'UPDATE' | 'VISIT' | 'TRADE_CLICK' | 'MUSIC_PLAY' | 'WALLET_LINK' | 'SWAP' | 'PRAYER_AGREE';
  platformOrTarget: string;
  timestamp: string;
  cryptographicSignature: string;
  userEmail?: string;
}

class CloudflareEventLogger {
  private sessionId: string;

  constructor() {
    this.sessionId = this.getOrCreateSessionId();
  }

  private getOrCreateSessionId(): string {
    if (typeof window === 'undefined') return 'sess-server-default';
    let sid = sessionStorage.getItem('juhnkrix_crypto_session_id');
    if (!sid) {
      sid = `jmk-sess-${Date.now()}-${Math.random().toString(36).substring(2, 11)}`;
      sessionStorage.setItem('juhnkrix_crypto_session_id', sid);
    }
    return sid;
  }

  public getSessionId(): string {
    return this.sessionId;
  }

  /**
   * Cryptographically signs an event payload and emits it to juhnkrixmusika.pages.dev/api/telemetry
   */
  public async logAndSignEvent(eventType: CloudflareTelemetryEvent['eventType'], platformOrTarget: string): Promise<CloudflareTelemetryEvent> {
    const timestamp = new Date().toISOString();
    const rawData = `${this.sessionId}:${eventType}:${platformOrTarget}:${timestamp}:JUHNKRIX_SECRET_KEY`;
    
    // Generate secure SHA-256 cryptographic signature simulation
    const encoder = new TextEncoder();
    const data = encoder.encode(rawData);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const signature = '0x' + hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

    const eventPayload: CloudflareTelemetryEvent = {
      eventId: `ev-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      sessionId: this.sessionId,
      eventType,
      platformOrTarget,
      timestamp,
      cryptographicSignature: signature,
      userEmail: localStorage.getItem('juhnkrix_user_email') || 'juhnkrix@gmail.com'
    };

    // Store in local ledger for audit and sync
    try {
      const logs = JSON.parse(localStorage.getItem('juhnkrix_cloudflare_telemetry_logs') || '[]');
      logs.unshift(eventPayload);
      localStorage.setItem('juhnkrix_cloudflare_telemetry_logs', JSON.stringify(logs.slice(0, 100)));

      // Simulate emitting to Cloudflare endpoint juhnkrixmusika.pages.dev/api/telemetry
      console.log(`[Cloudflare Telemetry] Emitted to https://juhnkrixmusika.pages.dev/api/telemetry ->`, eventPayload);
    } catch (e) {
      console.warn('Telemetry log error:', e);
    }

    return eventPayload;
  }
}

export const cloudflareEventLogger = new CloudflareEventLogger();
