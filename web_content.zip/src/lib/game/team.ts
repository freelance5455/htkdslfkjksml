import { FORMATIONS } from "./data";
import type { ClubState, PlayerData, Position } from "./types";

export class Team {
  constructor(
    public club: ClubState,
    public players: PlayerData[],
  ) {}

  available(): PlayerData[] {
    return this.players.filter((p) => p.ban <= 0 && !p.inj);
  }

  byId(id: string): PlayerData | undefined {
    return this.players.find((p) => p.id === id);
  }

  wageBill(): number {
    return this.players.reduce((s, p) => s + p.wage, 0);
  }

  avgOvr(ids?: string[]): number {
    const list = (ids ?? this.club.xi)
      .map((id) => this.byId(id))
      .filter((p): p is PlayerData => !!p);
    if (!list.length) return 50;
    return list.reduce((s, p) => s + p.ovr, 0) / list.length;
  }
}

export function autoPickXI(
  players: PlayerData[],
  formation: string,
): { xi: string[]; bench: string[] } {
  const slots = FORMATIONS[formation]?.slots ?? FORMATIONS["4-3-3"]!.slots;
  const pool = players
    .filter((p) => p.ban <= 0 && !p.inj)
    .slice()
    .sort((a, b) => b.ovr - a.ovr);
  const used = new Set<string>();
  const xi: string[] = [];

  const takeFor = (slot: Position): PlayerData | undefined => {
    const exact = pool.find((p) => !used.has(p.id) && p.pos === slot);
    if (exact) return exact;
    const group: Record<string, Position[]> = {
      GK: ["GK"],
      CB: ["CB", "CDM"],
      LB: ["LB", "LWB", "LM", "LW"],
      RB: ["RB", "RWB", "RM", "RW"],
      LWB: ["LWB", "LB", "LM"],
      RWB: ["RWB", "RB", "RM"],
      CDM: ["CDM", "CM", "CB"],
      CM: ["CM", "CDM", "CAM"],
      CAM: ["CAM", "CM", "ST"],
      LM: ["LM", "LW", "LWB", "CM"],
      RM: ["RM", "RW", "RWB", "CM"],
      LW: ["LW", "LM", "ST"],
      RW: ["RW", "RM", "ST"],
      ST: ["ST", "CAM", "LW", "RW"],
    };
    const prefs = group[slot] ?? [slot];
    for (const pos of prefs) {
      const hit = pool.find((p) => !used.has(p.id) && p.pos === pos);
      if (hit) return hit;
    }
    return pool.find((p) => !used.has(p.id) && p.pos !== "GK");
  };

  for (const slot of slots) {
    const p = takeFor(slot);
    if (p) {
      used.add(p.id);
      xi.push(p.id);
    }
  }

  const rest = pool.filter((p) => !used.has(p.id));
  const bench = rest.slice(0, 7).map((p) => p.id);
  return { xi, bench };
}

export function slotOf(formation: string, index: number): Position {
  const slots = FORMATIONS[formation]?.slots ?? FORMATIONS["4-3-3"]!.slots;
  return slots[index] ?? "CM";
}

export function chemistry(club: ClubState, players: Record<string, PlayerData>): number {
  const slots = FORMATIONS[club.tactics.formation]?.slots ?? FORMATIONS["4-3-3"]!.slots;
  let fit = 0;
  club.xi.forEach((id, i) => {
    const p = players[id];
    if (p && p.pos === slots[i]) fit += 1;
  });
  return fit / 11;
}
