export const NAMES: Record<string, { first: string[]; last: string[] }> = {
  TUR: {
    first: [
      "Mehmet", "Ahmet", "Mustafa", "Emre", "Burak", "Yusuf", "Ozan", "Kerem",
      "Arda", "Cenk", "Hakan", "Serdar", "Uğur", "Caner", "Barış", "Mert",
      "Enes", "Oğuzhan", "İrfan", "Tayyip", "Doruk", "Kaan", "Eren", "Berkay",
      "Onur", "Tolga", "Volkan", "İsmail", "Ömer", "Salih",
    ],
    last: [
      "Yılmaz", "Kaya", "Demir", "Şahin", "Çelik", "Yıldız", "Aydın", "Öztürk",
      "Arslan", "Doğan", "Kilic", "Aslan", "Koç", "Polat", "Aksoy", "Erdoğan",
      "Çetin", "Acar", "Kurt", "Özdemir", "Güneş", "Karaca", "Bulut", "Yavuz",
      "Tekin", "Sarı", "Uçar", "Ekinci", "Bozkurt", "Güler",
    ],
  },
  ENG: {
    first: [
      "Jack", "Harry", "James", "Oliver", "George", "Charlie", "Thomas", "Callum",
      "Mason", "Ryan", "Luke", "Adam", "Ben", "Jake", "Nathan", "Sam", "Joe",
      "Alex", "Daniel", "Matthew", "Lewis", "Owen", "Finley", "Reece", "Harvey",
    ],
    last: [
      "Smith", "Jones", "Taylor", "Brown", "Wilson", "Wright", "Johnson", "Walker",
      "Robinson", "Thompson", "White", "Hall", "Green", "Harris", "Clarke",
      "Edwards", "Cooper", "Harrison", "Ward", "Baker", "Shaw", "Brooks", "Reed",
      "Foster", "Bennett",
    ],
  },
  ESP: {
    first: [
      "Carlos", "Diego", "Pablo", "Sergio", "Javier", "Álvaro", "Mario", "Hugo",
      "Adrián", "Iván", "Raúl", "Iker", "Marc", "Unai", "Aitor", "Ander",
      "Pedri", "Nico", "Dani", "Álex", "Jordi", "Ferran", "Rodri", "Lamine",
      "Pau",
    ],
    last: [
      "García", "Rodríguez", "González", "Fernández", "López", "Martínez",
      "Sánchez", "Pérez", "Gómez", "Ruiz", "Díaz", "Álvarez", "Moreno", "Muñoz",
      "Alonso", "Gutiérrez", "Romero", "Navarro", "Torres", "Domínguez", "Vazquez",
      "Ramos", "Gil", "Serrano", "Blanco",
    ],
  },
  ITA: {
    first: [
      "Marco", "Luca", "Andrea", "Matteo", "Francesco", "Alessandro", "Giovanni",
      "Lorenzo", "Davide", "Simone", "Federico", "Riccardo", "Nicola", "Stefano",
      "Paolo", "Gianluca", "Daniele", "Fabio", "Roberto", "Antonio", "Manuel",
      "Samuele", "Tommaso", "Edoardo", "Filippo",
    ],
    last: [
      "Rossi", "Russo", "Ferrari", "Esposito", "Bianchi", "Romano", "Colombo",
      "Ricci", "Marino", "Greco", "Bruno", "Gallo", "Conti", "De Luca", "Mancini",
      "Costa", "Giordano", "Rizzo", "Lombardi", "Moretti", "Barbieri", "Fontana",
      "Santoro", "Mariani", "Rinaldi",
    ],
  },
  GER: {
    first: [
      "Leon", "Lukas", "Paul", "Jonas", "Finn", "Noah", "Felix", "Maximilian",
      "Tim", "Jan", "Niklas", "Tobias", "Florian", "Julian", "David", "Erik",
      "Simon", "Philipp", "Kevin", "Mario", "Sven", "Lars", "Nico", "Fabian",
      "Dennis",
    ],
    last: [
      "Müller", "Schmidt", "Schneider", "Fischer", "Weber", "Meyer", "Wagner",
      "Becker", "Hoffmann", "Schäfer", "Koch", "Bauer", "Richter", "Klein",
      "Wolf", "Schröder", "Neumann", "Schwarz", "Zimmermann", "Braun", "Krüger",
      "Hofmann", "Hartmann", "Lange", "Werner",
    ],
  },
  FRA: {
    first: [
      "Hugo", "Louis", "Gabriel", "Arthur", "Lucas", "Jules", "Léo", "Adam",
      "Raphaël", "Maël", "Nathan", "Théo", "Paul", "Nolan", "Tom", "Enzo",
      "Mathis", "Clément", "Antoine", "Maxime", "Kylian", "Karim", "Amine",
      "Yanis", "Sacha",
    ],
    last: [
      "Martin", "Bernard", "Thomas", "Petit", "Robert", "Richard", "Durand",
      "Dubois", "Moreau", "Laurent", "Simon", "Michel", "Lefebvre", "Leroy",
      "Roux", "David", "Bertrand", "Morel", "Fournier", "Girard", "Bonnet",
      "Dupont", "Lambert", "Fontaine", "Rousseau",
    ],
  },
  POR: {
    first: [
      "João", "Miguel", "Rafael", "Diogo", "Gonçalo", "Tiago", "André", "Pedro",
      "Bruno", "Ricardo", "Nuno", "Fábio", "Rúben", "Bernardo", "Francisco",
      "Afonso", "Daniel", "Eduardo", "Sérgio", "Paulo", "Luis", "Gustavo",
      "Renato", "Cristiano", "Vítor",
    ],
    last: [
      "Silva", "Santos", "Ferreira", "Pereira", "Oliveira", "Costa", "Rodrigues",
      "Martins", "Jesus", "Sousa", "Fernandes", "Gonçalves", "Gomes", "Lopes",
      "Marques", "Almeida", "Alves", "Ribeiro", "Pinto", "Carvalho", "Teixeira",
      "Moreira", "Correia", "Mendes", "Nunes",
    ],
  },
  BRA: {
    first: [
      "Lucas", "Gabriel", "Matheus", "Pedro", "João", "Rafael", "Felipe", "Bruno",
      "Gustavo", "Thiago", "André", "Diego", "Caio", "Vinicius", "Rodrygo",
      "Marcos", "Paulo", "Daniel", "Eduardo", "Leonardo", "Igor", "Alex",
      "Renato", "Danilo", "Everton",
    ],
    last: [
      "Silva", "Santos", "Oliveira", "Souza", "Rodrigues", "Ferreira", "Alves",
      "Pereira", "Lima", "Gomes", "Costa", "Ribeiro", "Martins", "Carvalho",
      "Almeida", "Lopes", "Soares", "Fernandes", "Vieira", "Barbosa", "Rocha",
      "Dias", "Nascimento", "Moreira", "Mendes",
    ],
  },
  ARG: {
    first: [
      "Santiago", "Mateo", "Juan", "Nicolás", "Franco", "Lautaro", "Julián",
      "Facundo", "Gonzalo", "Leandro", "Ángel", "Exequiel", "Rodrigo", "Paulo",
      "Emiliano", "Lisandro", "Nahuel", "Enzo", "Thiago", "Valentín", "Agustín",
      "Maximiliano", "Cristian", "Lucas", "Guido",
    ],
    last: [
      "González", "Rodríguez", "Fernández", "López", "Martínez", "García",
      "Pérez", "Romero", "Sánchez", "Díaz", "Álvarez", "Torres", "Ruiz",
      "Ramírez", "Flores", "Acosta", "Benítez", "Herrera", "Medina", "Castro",
      "Vargas", "Morales", "Ortiz", "Rojas", "Silva",
    ],
  },
  NED: {
    first: [
      "Daan", "Sem", "Luuk", "Lars", "Bram", "Finn", "Jesse", "Milan", "Noah",
      "Thijs", "Sven", "Jordy", "Dirk", "Memphis", "Cody", "Xavi", "Ryan",
      "Steven", "Daley", "Virgil", "Matthijs", "Frenkie", "Donny", "Wout", "Teun",
    ],
    last: [
      "de Jong", "de Boer", "van Dijk", "van Persie", "Janssen", "Bakker",
      "Visser", "Smit", "de Vries", "Meijer", "Mulder", "Bos", "Vos", "Hendriks",
      "Dekker", "Brouwer", "Prins", "Willems", "Koster", "Peters", "Gerritsen",
      "Hermans", "Kuipers", "Schouten", "Berghuis",
    ],
  },
  BEL: {
    first: [
      "Noah", "Liam", "Arthur", "Louis", "Lucas", "Adam", "Victor", "Jules",
      "Finn", "Leon", "Thibaut", "Eden", "Kevin", "Romelu", "Youri", "Axel",
      "Leander", "Hans", "Dries", "Michy", "Loïs", "Amadou", "Charles", "Orel",
      "Alexis",
    ],
    last: [
      "Peeters", "Janssens", "Maes", "Jacobs", "Mertens", "Willems", "Claes",
      "Goossens", "Wouters", "De Smet", "Vermeulen", "Pauwels", "Lambert",
      "Dumont", "Leclercq", "Simon", "Martin", "Dubois", "Laurent", "Petit",
      "Witsel", "Hazard", "De Bruyne", "Courtois", "Lukaku",
    ],
  },
  CRO: {
    first: [
      "Luka", "Ivan", "Marko", "Josip", "Mateo", "Filip", "Ante", "Domagoj",
      "Mario", "Nikola", "Duje", "Borna", "Marin", "Karlo", "Toni", "Andrej",
      "Bruno", "Dario", "Stipe", "Vedran", "Igor", "Zvonimir", "Darijo", "Milan",
      "Dino",
    ],
    last: [
      "Horvat", "Kovačević", "Babić", "Marić", "Jurić", "Novak", "Kovačić",
      "Perić", "Šimić", "Božić", "Marković", "Petrović", "Tomić", "Jukić",
      "Vidović", "Barišić", "Pavić", "Vuković", "Kralj", "Matić", "Kovač",
      "Brozović", "Modrić", "Rakitić", "Lovren",
    ],
  },
};

const FALLBACK_NATIONS = ["BRA", "ARG", "CRO", "NED", "BEL"] as const;

export function nationPool(code: string): { first: string[]; last: string[] } {
  return NAMES[code] ?? NAMES.ENG!;
}

export function pickNationForClub(clubCountry: string, rngNext: () => number): string {
  if (rngNext() < 0.62) return clubCountry;
  if (rngNext() < 0.5) return FALLBACK_NATIONS[Math.floor(rngNext() * FALLBACK_NATIONS.length)]!;
  const keys = Object.keys(NAMES);
  return keys[Math.floor(rngNext() * keys.length)]!;
}
