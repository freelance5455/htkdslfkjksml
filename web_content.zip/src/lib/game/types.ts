export const SAVE_VERSION = 1;
export const SAVE_KEY = "onbir-save-v1";
export const SAVE_BACKUP_KEY = "onbir-save-v1-bak";

export type Position =
  | "GK"
  | "CB"
  | "LB"
  | "RB"
  | "LWB"
  | "RWB"
  | "CDM"
  | "CM"
  | "CAM"
  | "LM"
  | "RM"
  | "LW"
  | "RW"
  | "ST";

export type Comp = "league" | "UCL" | "UEL" | "UECL";
export type PlayStyle = "short" | "counter" | "long";
export type PressLine = "low" | "mid" | "high";
export type Mentality = "defensive" | "balanced" | "attacking";
export type ScreenId =
  | "squad"
  | "tactics"
  | "transfer"
  | "europe"
  | "medical"
  | "club"
  | "match";

export type Objective = "title" | "top4" | "europe" | "mid" | "survive" | "promote";

export type InjuryKind = "muscle" | "ankle" | "hamstring" | "acl";

export interface Injury {
  kind: InjuryKind;
  label: string;
  weeksLeft: number;
  originalWeeks: number;
}

export interface PlayerData {
  id: string;
  clubId: string;
  name: string;
  nation: string;
  age: number;
  pos: Position;
  ovr: number;
  pot: number;
  growth: number;
  energy: number;
  morale: number;
  value: number;
  wage: number;
  yellows: number;
  matchYellows: number;
  ban: number;
  inj: Injury | null;
  form: number;
  goals: number;
  assists: number;
  apps: number;
  ratingSum: number;
  listed: boolean;
  askingPrice: number;
  regen: boolean;
}

export interface Tactics {
  formation: string;
  style: PlayStyle;
  press: PressLine;
  mentality: Mentality;
}

export interface ClubState {
  id: string;
  name: string;
  short: string;
  league: string;
  country: string;
  rep: number;
  colors: [string, string];
  stadium: string;
  cap: number;
  balance: number;
  tactics: Tactics;
  xi: string[];
  bench: string[];
  morale: number;
  pts: number;
  pld: number;
  w: number;
  d: number;
  l: number;
  gf: number;
  ga: number;
  medical: number;
  academy: number;
  training: number;
  sponsorId: string;
  european: Comp | null;
  europeSeed: number;
  npc: boolean;
}

export interface Fixture {
  id: string;
  week: number;
  comp: Comp;
  round: string;
  homeId: string;
  awayId: string;
  homeGoals: number | null;
  awayGoals: number | null;
  played: boolean;
  group?: string;
  twoLeg?: boolean;
  leg?: 1 | 2;
  aggKey?: string;
}

export interface MatchEvent {
  minute: number;
  kind: "text" | "goal" | "chance" | "yellow" | "red" | "injury" | "sub" | "ht" | "ft";
  side?: "home" | "away";
  playerId?: string;
  playerName?: string;
  text: string;
}

export interface SideStats {
  shots: number;
  onTarget: number;
  possession: number;
  fouls: number;
  corners: number;
  yellows: number;
  reds: number;
  xg: number;
}

export interface LiveMatch {
  fixtureId: string;
  homeId: string;
  awayId: string;
  minute: number;
  stoppage: number;
  homeGoals: number;
  awayGoals: number;
  events: MatchEvent[];
  stats: { home: SideStats; away: SideStats };
  phase: "first" | "ht" | "second" | "ft";
  homeXI: string[];
  awayXI: string[];
  homeBench: string[];
  awayBench: string[];
  subsUsed: number;
  comp: Comp;
  round: string;
  scorers: { minute: number; name: string; side: "home" | "away" }[];
}

export interface TransferOffer {
  id: string;
  playerId: string;
  fromId: string;
  toId: string;
  amount: number;
  wage: number;
  status: "pending" | "accepted" | "rejected";
}

export interface NewsItem {
  id: string;
  week: number;
  title: string;
  body: string;
  tone: "neutral" | "good" | "bad";
}

export interface CountryRank {
  code: string;
  name: string;
  fiveYear: number[];
  seasonPts: number;
  seasonMatches: number;
}

export interface EuropeGroup {
  comp: Comp;
  name: string;
  clubIds: string[];
}

export interface GameState {
  version: number;
  season: number;
  week: number;
  maxWeek: number;
  manager: string;
  clubId: string;
  created: boolean;
  board: number;
  objective: Objective;
  sacked: boolean;
  clubs: Record<string, ClubState>;
  players: Record<string, PlayerData>;
  fixtures: Fixture[];
  live: LiveMatch | null;
  transfers: TransferOffer[];
  news: NewsItem[];
  countries: CountryRank[];
  groups: EuropeGroup[];
  uid: number;
  seed: number;
  transferOpen: boolean;
  seasonOver: boolean;
  inboxCount: number;
}

export interface CreateClubInput {
  name: string;
  short: string;
  stadium: string;
  primary: string;
  secondary: string;
  budget: number;
  manager: string;
}

export interface LeagueDef {
  id: string;
  name: string;
  country: string;
  tier: number;
  size: number;
}
