export type Pos =
  | "GK"
  | "RB"
  | "RWB"
  | "CB"
  | "LB"
  | "LWB"
  | "CDM"
  | "CM"
  | "CAM"
  | "RM"
  | "LM"
  | "RW"
  | "LW"
  | "CF"
  | "ST";

export type Foot = "right" | "left";
export type Personality =
  | "professional"
  | "ambitious"
  | "loyal"
  | "fiery"
  | "calm"
  | "determined";

export type Role = "starter" | "rotation" | "bench";
export type CardTier = "bronze" | "silver" | "gold" | "icon" | "legend";

export type Pattern = "s" | "ss" | "sd" | "sh" | "sc" | "c" | "cr";
export type Emblem = "star" | "crown" | "eagle" | "lion" | "shieldStar" | "diamond";

export type Screen =
  | "menu"
  | "create"
  | "team"
  | "career"
  | "match"
  | "load"
  | "achievements"
  | "howto"
  | "settings";

export type CareerView =
  | "panel"
  | "profile"
  | "attributes"
  | "stats"
  | "training"
  | "matches"
  | "calendar"
  | "club"
  | "manager"
  | "teammates"
  | "transfers"
  | "agent"
  | "contract"
  | "finance"
  | "national"
  | "trophies"
  | "history"
  | "life"
  | "social";

export type AttrKey = string;

export type Attrs = Record<string, number>;

export type Team = {
  id: string;
  name: string;
  country: string;
  leagueId: string;
  power: number;
  c1: string;
  c2: string;
  pattern: Pattern;
  emblem?: Emblem;
};

export type League = {
  id: string;
  name: string;
  country: string;
  prestige: number;
};

export type Teammate = {
  id: string;
  first: string;
  last: string;
  pos: Pos;
  ovr: number;
  age: number;
  nat: string;
};

export type Player = {
  firstName: string;
  lastName: string;
  displayName: string;
  nat: string;
  nat2: string;
  dob: string;
  foot: Foot;
  pos: Pos;
  pos2: Pos | "";
  height: number;
  weight: number;
  number: number;
  archetype: string;
  personality: Personality;
  attrs: Attrs;
  overall: number;
  potential: number;
  growthRate: number;
  peakAge: number;
  injurySusceptibility: number;
  professionalism: number;
  consistency: number;
  fitness: number;
  morale: number;
  form: number;
  fatigue: number;
  happiness: number;
  energy: number;
  stress: number;
  confidence: number;
  popularity: number;
  reputation: number;
};

export type Manager = {
  first: string;
  last: string;
  trust: number;
  style: string;
};

export type Contract = {
  years: number;
  weeklyWage: number;
  appearanceBonus: number;
  goalBonus: number;
  assistBonus: number;
  signedWeek: number;
};

export type Finances = {
  balance: number;
  weeklyWage: number;
  monthlyIncome: number;
  monthlyExpenses: number;
};

export type SeasonStats = {
  apps: number;
  starts: number;
  goals: number;
  assists: number;
  shots: number;
  keyPasses: number;
  tackles: number;
  minutes: number;
  yellowCards: number;
  redCards: number;
  motm: number;
  ratingSum: number;
  avgRating: number;
};

export type Fixture = {
  week: number;
  home: string;
  away: string;
  cup?: boolean;
};

export type MatchResult = {
  week: number;
  home: string;
  away: string;
  hg: number;
  ag: number;
  rating: number;
  goals: number;
  assists: number;
  minutes: number;
  motm: boolean;
  yellow: boolean;
  red: boolean;
  shots: number;
  keyPasses: number;
  tackles: number;
  role: Role;
  cup?: boolean;
};

export type TableRow = {
  teamId: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  gf: number;
  ga: number;
  pts: number;
};

export type NewsItem = {
  id: string;
  week: number;
  title: string;
  body: string;
  kind: "match" | "transfer" | "club" | "life" | "social" | "national";
};

export type WorldTransfer = {
  id: string;
  week: number;
  name: string;
  pos: Pos;
  ovr: number;
  age: number;
  nat: string;
  fromId: string;
  toId: string;
  fee: number;
  rumor: boolean;
  record: boolean;
};

export type ClubInterest = {
  teamId: string;
  week: number;
};

export type Injury = {
  name: string;
  weeksLeft: number;
} | null;

export type Trophy = {
  id: string;
  name: string;
  season: string;
  team: string;
};

export type HistoryEvent = {
  week: number;
  season: string;
  text: string;
};

export type Agent = {
  first: string;
  last: string;
  cut: number;
};

export type Training = {
  focus: string;
  intensity: "low" | "mid" | "high";
};

export type LifeState = {
  home: number;
  car: number;
  relationship: "single" | "dating" | "engaged" | "married";
  partnerName: string;
  togetherWeeks: number;
  kids: number;
  family: number;
  friends: number;
  business: number;
  events: { week: number; text: string }[];
};

export type GramPost = {
  id: string;
  userId: string;
  scene: string;
  caption: string;
  likes: number;
  liked: boolean;
  comments: { userId: string; text: string }[];
  week: number;
  time: string;
  location: string;
  hashtags: string[];
  mentions: string[];
  saved: boolean;
};

export type GramUser = {
  id: string;
  username: string;
  displayName: string;
  bio: string;
  verified: boolean;
  followers: number;
  following: number;
  hue: number;
  npc: boolean;
  role?: "agent" | "manager" | "teammate" | "fan" | "media" | "club";
};

export type GramStory = {
  id: string;
  userId: string;
  scene: string;
  text: string;
  seen: boolean;
};

export type GramNotif = {
  id: string;
  kind: "like" | "comment" | "follow" | "mention";
  userId: string;
  text: string;
  unread: boolean;
  week: number;
};

export type GramMsg = {
  id: string;
  from: "me" | "them";
  text: string;
  time: string;
};

export type GramThread = {
  userId: string;
  messages: GramMsg[];
  unread: number;
};

export type Offer = {
  id: string;
  teamId: string;
  kind: "loan" | "transfer";
  fee: number;
  wage: number;
  years: number;
  managerName: string;
  week: number;
  status: "open" | "accepted" | "declined";
};

export type SocialState = {
  setup: boolean;
  username: string;
  displayName: string;
  bio: string;
  hue: number;
  verified: boolean;
  followers: number;
  followingCount: number;
  posts: GramPost[];
  stories: GramStory[];
  users: GramUser[];
  activity: GramNotif[];
  threads: GramThread[];
  followingIds: string[];
  savedIds: string[];
};

export type CareerState = {
  slot: number;
  version: number;
  player: Player;
  clubId: string;
  leagueId: string;
  season: string;
  date: string;
  week: number;
  seasonIndex: number;
  seasonStats: SeasonStats;
  careerHistory: HistoryEvent[];
  trophies: Trophy[];
  awards: string[];
  news: NewsItem[];
  teammates: Teammate[];
  manager: Manager;
  finances: Finances;
  contract: Contract;
  agent: Agent;
  training: Training;
  transferInterest: ClubInterest[];
  notifications: string[];
  achievements: string[];
  worldTransfers: WorldTransfer[];
  life: LifeState;
  injury: Injury;
  lastResult: MatchResult | null;
  social: SocialState;
  socialLastEvent: string;
  fixtures: Fixture[];
  table: TableRow[];
  matchLog: MatchResult[];
  role: Role;
  offers: Offer[];
};

export type SaveSlotMeta = {
  slot: number;
  occupied: boolean;
  name?: string;
  club?: string;
  ovr?: number;
  week?: number;
  season?: string;
};
