import type { PlayerData, Position } from "./types";
import { clamp } from "./format";
import { RNG } from "./rng";
import { NAMES, pickNationForClub } from "./names";

export class Player {
  constructor(public d: PlayerData) {}

  available(): boolean {
    return this.d.ban <= 0 && !this.d.inj;
  }

  effective(slot: Position): number {
    let r = this.d.ovr;
    if (this.d.pos !== slot) r *= 0.8;
    r *= 0.72 + this.d.energy / 280;
    r *= 0.9 + this.d.form / 500;
    r *= 0.92 + this.d.morale / 625;
    if (this.d.inj) r *= 0.35;
    return r;
  }

  avgRating(): number {
    if (this.d.apps <= 0) return 6.5;
    return this.d.ratingSum / this.d.apps;
  }
}

export function playerValue(ovr: number, age: number, pot: number): number {
  const ageMod = age < 23 ? 1.25 : age > 32 ? 0.42 : 1 - Math.max(0, age - 27) * 0.045;
  const potMod = 1 + Math.max(0, pot - ovr) / 40;
  return Math.max(80_000, Math.round((ovr - 52) ** 2 * 85_000 * ageMod * potMod));
}

export function playerWage(ovr: number, age: number): number {
  const base = Math.max(800, Math.round((ovr - 40) ** 2 * 14));
  return age > 32 ? Math.round(base * 0.85) : base;
}

export function makePlayer(
  rng: RNG,
  clubId: string,
  clubCountry: string,
  pos: Position,
  ovr: number,
  ageBias?: "youth" | "prime" | "vet",
  id?: string,
): PlayerData {
  let age = rng.int(19, 32);
  if (ageBias === "youth") age = rng.int(16, 21);
  if (ageBias === "vet") age = rng.int(31, 37);
  if (ageBias === "prime") age = rng.int(24, 29);
  ovr = clamp(Math.round(ovr + rng.int(-2, 2)), 46, 94);
  let pot = ovr + rng.int(0, age < 23 ? 14 : age < 28 ? 6 : 2);
  if (age >= 30) pot = ovr;
  pot = clamp(pot, ovr, 95);
  const nation = pickNationForClub(clubCountry, () => rng.next());
  const pool = NAMES[nation] ?? NAMES.ENG!;
  const name = `${rng.pick(pool.first)} ${rng.pick(pool.last)}`;
  const growth = Number((0.35 + rng.float(0, 0.55) + (age < 21 ? 0.2 : 0)).toFixed(2));
  return {
    id: id ?? "",
    clubId,
    name,
    nation,
    age,
    pos,
    ovr,
    pot,
    growth,
    energy: rng.int(86, 100),
    morale: rng.int(62, 88),
    value: playerValue(ovr, age, pot),
    wage: playerWage(ovr, age),
    yellows: 0,
    matchYellows: 0,
    ban: 0,
    inj: null,
    form: rng.int(48, 72),
    goals: 0,
    assists: 0,
    apps: 0,
    ratingSum: 0,
    listed: false,
    askingPrice: 0,
    regen: false,
  };
}

const SQUAD_SHAPE: Array<[Position, number, "youth" | "prime" | "vet" | undefined, number]> = [
  ["GK", 1, "prime", 2],
  ["GK", 1, "youth", -8],
  ["CB", 2, "prime", 0],
  ["CB", 1, "vet", -4],
  ["CB", 1, "youth", -9],
  ["LB", 1, "prime", -1],
  ["LB", 1, "youth", -8],
  ["RB", 1, "prime", -1],
  ["RB", 1, "youth", -8],
  ["CDM", 1, "prime", -1],
  ["CM", 2, "prime", 0],
  ["CM", 1, "youth", -8],
  ["CAM", 1, "prime", -1],
  ["LM", 1, undefined, -3],
  ["RM", 1, undefined, -3],
  ["LW", 1, "prime", -1],
  ["RW", 1, "prime", -1],
  ["ST", 2, "prime", 1],
  ["ST", 1, "youth", -7],
];

export function generateSquad(
  rng: RNG,
  clubId: string,
  country: string,
  rep: number,
  nextId: () => string,
): PlayerData[] {
  const out: PlayerData[] = [];
  const used = new Set<string>();
  for (const [pos, count, bias, delta] of SQUAD_SHAPE) {
    for (let i = 0; i < count; i++) {
      const p = makePlayer(rng, clubId, country, pos, rep + delta, bias, nextId());
      let guard = 0;
      while (used.has(p.name) && guard++ < 12) {
        const pool = NAMES[p.nation] ?? NAMES.ENG!;
        p.name = `${rng.pick(pool.first)} ${rng.pick(pool.last)}`;
      }
      used.add(p.name);
      p.value = playerValue(p.ovr, p.age, p.pot);
      p.wage = playerWage(p.ovr, p.age);
      out.push(p);
    }
  }
  return out;
}

export function applyXp(p: PlayerData, matchPts: number): void {
  if (p.ovr >= p.pot) return;
  if (p.age >= 30) return;
  const xp =
    matchPts *
    p.growth *
    (1 + (p.pot - p.ovr) / 20) *
    (p.age < 23 ? 1.5 : 1);
  const gain = xp / 28;
  if (gain >= 1) {
    p.ovr = Math.min(p.pot, p.ovr + Math.floor(gain));
    p.value = playerValue(p.ovr, p.age, p.pot);
    p.wage = playerWage(p.ovr, p.age);
  } else if (Math.random() < gain) {
    p.ovr = Math.min(p.pot, p.ovr + 1);
    p.value = playerValue(p.ovr, p.age, p.pot);
    p.wage = playerWage(p.ovr, p.age);
  }
}

export function seasonDecay(p: PlayerData, rng: RNG): void {
  p.age += 1;
  if (p.age >= 30) {
    const drop = p.age >= 34 ? rng.int(2, 4) : rng.int(1, 2);
    p.ovr = Math.max(48, p.ovr - drop);
    p.pot = Math.max(p.ovr, p.pot - drop);
    p.value = playerValue(p.ovr, p.age, p.pot);
    p.wage = playerWage(p.ovr, p.age);
  }
  p.yellows = 0;
  p.goals = 0;
  p.assists = 0;
  p.apps = 0;
  p.ratingSum = 0;
  p.form = 55;
  p.energy = 100;
}
