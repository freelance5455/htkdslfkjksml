import { YouthAcademy } from "./academy";
import {
  CLUB_RAW,
  COUNTRY_SEED,
  DEFAULT_TACTICS,
  LEAGUES,
  NPC_CLUBS,
  SPONSORS,
} from "./data";
import { clamp } from "./format";
import { InjuryManager } from "./injury";
import { MatchEngine } from "./match";
import { generateSquad, seasonDecay } from "./player";
import { RNG } from "./rng";
import { persist, readSave } from "./save";
import { autoPickXI } from "./team";
import { TransferMarket } from "./transfer";
import type {
  ClubState,
  Comp,
  CountryRank,
  CreateClubInput,
  Fixture,
  GameState,
  PlayerData,
  Tactics,
} from "./types";
import { SAVE_VERSION } from "./types";
import { groupTable, UEFARankingSystem } from "./uefa";

const UPGRADE_COST = [0, 0, 2_000_000, 5_500_000, 13_000_000, 28_000_000];

function slugId(short: string, used: Set<string>): string {
  const base = "c_" + short.toLowerCase().replace(/[^a-z0-9]/g, "");
  let id = base;
  let n = 2;
  while (used.has(id)) {
    id = `${base}${n}`;
    n += 1;
  }
  used.add(id);
  return id;
}

function capFromRep(rep: number): number {
  return Math.round((16000 + (rep - 48) * 1100) / 500) * 500;
}

function roundRobin(ids: string[]): [string, string][][] {
  const teams = ids.slice();
  if (teams.length % 2 === 1) teams.push("BYE");
  const n = teams.length;
  const rounds = n - 1;
  const half = n / 2;
  const days: [string, string][][] = [];
  const arr = teams.slice();
  for (let r = 0; r < rounds; r++) {
    const pairs: [string, string][] = [];
    for (let i = 0; i < half; i++) {
      const t1 = arr[i]!;
      const t2 = arr[n - 1 - i]!;
      if (t1 !== "BYE" && t2 !== "BYE") {
        pairs.push(r % 2 === 0 ? [t1, t2] : [t2, t1]);
      }
    }
    days.push(pairs);
    const last = arr.pop()!;
    arr.splice(1, 0, last);
  }
  const second = days.map((day) => day.map(([h, a]) => [a, h] as [string, string]));
  return days.concat(second);
}

function objectiveFor(club: ClubState): GameState["objective"] {
  if (club.league === "TUR2") return "promote";
  if (club.rep >= 88) return "title";
  if (club.rep >= 82) return "top4";
  if (club.rep >= 74) return "europe";
  if (club.rep >= 64) return "mid";
  return "survive";
}

export class Game {
  state: GameState;
  rng: RNG;
  match = new MatchEngine();
  injuries = new InjuryManager();
  uefa = new UEFARankingSystem();
  market = new TransferMarket();
  academy = new YouthAcademy();

  constructor(state: GameState) {
    this.state = state;
    this.rng = new RNG(state.seed);
  }

  static fromSave(): Game | null {
    const s = readSave();
    if (!s) return null;
    return new Game(s);
  }

  static newCareer(clubName: string, manager: string): Game {
    return Game.build({ clubName, manager });
  }

  static createClub(input: CreateClubInput): Game {
    return Game.build({ created: input, manager: input.manager });
  }

  private static build(opts: {
    clubName?: string;
    created?: CreateClubInput;
    manager: string;
  }): Game {
    const seed = (Date.now() ^ Math.floor(Math.random() * 1e9)) >>> 0;
    const rng = new RNG(seed);
    let uid = 1;
    const nextId = () => `p_${uid++}`;
    const used = new Set<string>();
    const clubs: Record<string, ClubState> = {};
    const players: Record<string, PlayerData> = {};

    const makeClub = (
      name: string,
      short: string,
      league: string,
      country: string,
      rep: number,
      colors: [string, string],
      stadium: string,
      npc: boolean,
    ): ClubState => {
      const id = slugId(short, used);
      const club: ClubState = {
        id,
        name,
        short,
        league,
        country,
        rep,
        colors,
        stadium,
        cap: capFromRep(rep),
        balance: Math.round(rep * (npc ? 0.4 : league === "TUR2" ? 0.28 : 1.05) * 1_000_000),
        tactics: { ...DEFAULT_TACTICS },
        xi: [],
        bench: [],
        morale: rng.int(58, 78),
        pts: 0,
        pld: 0,
        w: 0,
        d: 0,
        l: 0,
        gf: 0,
        ga: 0,
        medical: league.startsWith("TUR") ? 2 : 3,
        academy: Math.max(1, Math.round((rep - 50) / 12)),
        training: Math.max(1, Math.round((rep - 48) / 14)),
        sponsorId: rep >= 88 ? "tech" : rep >= 80 ? "airline" : rep >= 70 ? "bank" : "local",
        european: null,
        europeSeed: 0,
        npc,
      };
      clubs[id] = club;
      const squad = generateSquad(rng, id, country, rep, nextId);
      for (const p of squad) players[p.id] = p;
      const pick = autoPickXI(squad, club.tactics.formation);
      club.xi = pick.xi;
      club.bench = pick.bench;
      return club;
    };

    for (const league of LEAGUES) {
      for (const raw of CLUB_RAW[league.id] ?? []) {
        makeClub(raw[0], raw[1], league.id, league.country, raw[3], [raw[4], raw[5]], raw[2], false);
      }
    }
    for (const n of NPC_CLUBS) {
      makeClub(n[0], n[1], `NPC_${n[2]}`, n[2], n[4], [n[5], n[6]], n[3], true);
    }

    let userId = "";
    if (opts.clubName) {
      const found = Object.values(clubs).find((c) => c.name === opts.clubName);
      userId = found?.id ?? "";
    }
    if (opts.created) {
      const weakest = Object.values(clubs)
        .filter((c) => c.league === "TUR2")
        .sort((a, b) => a.rep - b.rep)[0];
      if (weakest) {
        weakest.name = opts.created.name;
        weakest.short = opts.created.short.slice(0, 4).toUpperCase();
        weakest.stadium = opts.created.stadium;
        weakest.colors = [opts.created.primary, opts.created.secondary];
        weakest.balance = opts.created.budget;
        weakest.rep = 52;
        weakest.medical = 1;
        weakest.academy = 1;
        weakest.training = 1;
        weakest.sponsorId = "local";
        weakest.cap = 12000;
        userId = weakest.id;
      }
    }
    if (!userId) {
      userId =
        Object.values(clubs).find((c) => c.name === "Galatasaray")?.id ??
        Object.values(clubs)[0]!.id;
    }

    const countries: CountryRank[] = COUNTRY_SEED.map(([code, name, five]) => ({
      code,
      name,
      fiveYear: five.slice(),
      seasonPts: 0,
      seasonMatches: 0,
    }));

    const state: GameState = {
      version: SAVE_VERSION,
      season: 2026,
      week: 1,
      maxWeek: 42,
      manager: opts.manager || "Teknik Direktör",
      clubId: userId,
      created: !!opts.created,
      board: 64,
      objective: "mid",
      sacked: false,
      clubs,
      players,
      fixtures: [],
      live: null,
      transfers: [],
      news: [],
      countries,
      groups: [],
      uid,
      seed: rng.seed,
      transferOpen: true,
      seasonOver: false,
      inboxCount: 0,
    };
    const game = new Game(state);
    const user = game.user();
    game.state.board = user.rep >= 84 ? 58 : 70;
    game.state.objective = objectiveFor(user);
    game.buildSeason();
    game.pushNews(
      "Sezon açıldı",
      `${user.name} teknik direktörlüğüne hoş geldiniz. Hedef: ${game.objectiveText()}.`,
      "neutral",
    );
    game.save();
    return game;
  }

  user(): ClubState {
    return this.state.clubs[this.state.clubId]!;
  }

  userPlayers(): PlayerData[] {
    return Object.values(this.state.players)
      .filter((p) => p.clubId === this.state.clubId)
      .sort((a, b) => b.ovr - a.ovr);
  }

  save() {
    this.state.seed = this.rng.seed;
    persist(this.state);
  }

  pushNews(title: string, body: string, tone: "neutral" | "good" | "bad") {
    this.state.news.unshift({
      id: `n_${this.state.uid++}`,
      week: this.state.week,
      title,
      body,
      tone,
    });
    if (this.state.news.length > 50) this.state.news.length = 50;
    this.state.inboxCount += 1;
  }

  objectiveText(): string {
    const map: Record<string, string> = {
      title: "Şampiyonluk",
      top4: "İlk 4",
      europe: "Avrupa kupası",
      mid: "Lig ortası",
      survive: "Kümede kalmak",
      promote: "Süper Lig'e çıkmak",
    };
    return map[this.state.objective] ?? "";
  }

  leagueTable(leagueId: string) {
    return Object.values(this.state.clubs)
      .filter((c) => c.league === leagueId)
      .sort((a, b) => b.pts - a.pts || b.gf - b.ga - (a.gf - a.ga) || b.gf - a.gf);
  }

  nextUserFixture(): Fixture | undefined {
    return this.state.fixtures
      .filter((f) => !f.played && (f.homeId === this.state.clubId || f.awayId === this.state.clubId))
      .sort((a, b) => a.week - b.week || a.id.localeCompare(b.id))[0];
  }

  weekFixtures(week = this.state.week): Fixture[] {
    return this.state.fixtures.filter((f) => f.week === week);
  }

  setTactics(t: Partial<Tactics>) {
    const club = this.user();
    club.tactics = { ...club.tactics, ...t };
    if (t.formation) {
      const pick = autoPickXI(this.userPlayers(), t.formation);
      club.xi = pick.xi;
      club.bench = pick.bench;
    }
    this.syncLiveTactics();
    this.save();
  }

  syncLiveTactics() {
    const live = this.state.live;
    if (!live || live.phase === "ft") return;
    const userIsHome = live.homeId === this.state.clubId;
    if (userIsHome) live.homeXI = this.user().xi.slice();
    else live.awayXI = this.user().xi.slice();
  }

  setSlot(index: number, playerId: string) {
    const club = this.user();
    const p = this.state.players[playerId];
    if (!p || p.clubId !== club.id) return;
    if (p.inj || p.ban > 0) return;
    const cur = club.xi[index];
    const inXi = club.xi.indexOf(playerId);
    const inBench = club.bench.indexOf(playerId);
    if (inXi >= 0) {
      club.xi[inXi] = cur ?? playerId;
      club.xi[index] = playerId;
    } else {
      club.xi[index] = playerId;
      if (inBench >= 0) {
        if (cur) club.bench[inBench] = cur;
        else club.bench.splice(inBench, 1);
      } else if (cur) {
        club.bench.unshift(cur);
        if (club.bench.length > 7) club.bench.length = 7;
      }
    }
    this.save();
  }

  swap(aId: string, bId: string) {
    const club = this.user();
    const ia = club.xi.indexOf(aId);
    const ib = club.xi.indexOf(bId);
    const ba = club.bench.indexOf(aId);
    const bb = club.bench.indexOf(bId);
    if (ia >= 0 && ib >= 0) {
      club.xi[ia] = bId;
      club.xi[ib] = aId;
    } else if (ia >= 0 && bb >= 0) {
      club.xi[ia] = bId;
      club.bench[bb] = aId;
    } else if (ib >= 0 && ba >= 0) {
      club.xi[ib] = aId;
      club.bench[ba] = bId;
    }
    this.save();
  }

  startMatch(fixtureId?: string): string | null {
    const fx = fixtureId
      ? this.state.fixtures.find((f) => f.id === fixtureId)
      : this.nextUserFixture();
    if (!fx) return "Oynanacak maç yok.";
    if (fx.played) return "Bu maç oynandı.";
    if (fx.week > this.state.week) return "Bu maç henüz gelmedi.";
    const user = this.user();
    const pick = autoPickXI(this.userPlayers(), user.tactics.formation);
    if (user.xi.length < 11) {
      user.xi = pick.xi;
      user.bench = pick.bench;
    }
    user.xi = user.xi.filter((id) => {
      const p = this.state.players[id];
      return p && !p.inj && p.ban <= 0;
    });
    if (user.xi.length < 11) {
      const filled = autoPickXI(this.userPlayers(), user.tactics.formation);
      user.xi = filled.xi;
      user.bench = filled.bench;
    }
    if (user.xi.length < 8) return "Yeterli sağlıklı oyuncu yok.";
    this.state.live = this.match.createLive(this.state, fx.id, this.rng);
    this.save();
    return null;
  }

  stepMinute() {
    const live = this.state.live;
    if (!live) return;
    this.match.stepMinute(this.state, live, this.rng);
    if (live.phase === "ft") this.onFullTime();
    this.save();
  }

  continueSecondHalf() {
    const live = this.state.live;
    if (!live) return;
    this.match.startSecondHalf(live);
    this.save();
  }

  skipMatch() {
    const live = this.state.live;
    if (!live) {
      const err = this.startMatch();
      if (err) return err;
    }
    const l = this.state.live!;
    let guard = 0;
    while (l.phase !== "ft" && guard++ < 200) {
      if (l.phase === "ht") this.match.startSecondHalf(l);
      this.match.stepMinute(this.state, l, this.rng);
    }
    this.onFullTime();
    this.save();
    return null;
  }

  sub(outId: string, inId: string): string | null {
    const live = this.state.live;
    if (!live) return "Maç yok.";
    const err = this.match.sub(this.state, live, outId, inId);
    this.save();
    return err;
  }

  private onFullTime() {
    const live = this.state.live;
    if (!live) return;
    const user = this.user();
    const hg = live.homeGoals;
    const ag = live.awayGoals;
    const userHome = live.homeId === user.id;
    const userGoals = userHome ? hg : ag;
    const oppGoals = userHome ? ag : hg;
    const won = userGoals > oppGoals;
    const draw = userGoals === oppGoals;
    const gdFav = user.rep - (this.state.clubs[userHome ? live.awayId : live.homeId]?.rep ?? 70);
    if (won) this.state.board = clamp(this.state.board + (gdFav < -8 ? 8 : 4), 0, 100);
    else if (draw) this.state.board = clamp(this.state.board + (gdFav > 10 ? -3 : 1), 0, 100);
    else this.state.board = clamp(this.state.board - (gdFav > 8 ? 9 : 5), 0, 100);
    const sponsor = SPONSORS.find((s) => s.id === user.sponsorId);
    if (won && sponsor) user.balance += sponsor.winBonus;
    const gate = Math.round(user.cap * 0.72 * (18 + user.rep / 8));
    user.balance += gate;
    this.addEuropePoints(live);
    if (this.state.board < 12) {
      this.state.sacked = true;
      this.pushNews("Görevine son", "Yönetim kurulu güvenoyunu geri çekti.", "bad");
    }
  }

  addEuropePoints(live: {
    comp: Comp;
    homeId: string;
    awayId: string;
    homeGoals: number;
    awayGoals: number;
  }) {
    if (live.comp === "league") return;
    const home = this.state.clubs[live.homeId]!;
    const away = this.state.clubs[live.awayId]!;
    const resultPts = (g: number, o: number) => (g > o ? 2 : g === o ? 1 : 0);
    this.uefa.addResult(this.state.countries, home.country, resultPts(live.homeGoals, live.awayGoals), 1);
    this.uefa.addResult(this.state.countries, away.country, resultPts(live.awayGoals, live.homeGoals), 1);
  }

  private creditEurope(f: Fixture) {
    if (f.comp === "league" || !f.played || f.homeGoals == null || f.awayGoals == null) return;
    this.addEuropePoints({
      comp: f.comp,
      homeId: f.homeId,
      awayId: f.awayId,
      homeGoals: f.homeGoals,
      awayGoals: f.awayGoals,
    });
  }

  closeMatchAndAdvance() {
    this.state.live = null;
    this.resolveWeekIfDone();
    this.save();
  }

  resolveWeekIfDone() {
    const pending = this.state.fixtures.filter(
      (f) =>
        f.week === this.state.week &&
        !f.played &&
        (f.homeId === this.state.clubId || f.awayId === this.state.clubId),
    );
    if (pending.length) return;
    for (const f of this.state.fixtures) {
      if (f.week === this.state.week && !f.played) {
        this.match.simQuiet(this.state, f.id, this.rng);
        const done = this.state.fixtures.find((x) => x.id === f.id);
        if (done) this.creditEurope(done);
      }
    }
    this.tickWeek();
  }

  simRestOfWeek() {
    for (const f of this.state.fixtures) {
      if (f.week !== this.state.week || f.played) continue;
      if (f.homeId === this.state.clubId || f.awayId === this.state.clubId) {
        const live = this.match.createLive(this.state, f.id, this.rng);
        this.state.live = live;
        this.skipMatch();
        this.state.live = null;
      } else {
        this.match.simQuiet(this.state, f.id, this.rng);
        const done = this.state.fixtures.find((x) => x.id === f.id);
        if (done) this.creditEurope(done);
      }
    }
    this.tickWeek();
    this.save();
  }

  private tickWeek() {
    const user = this.user();
    const squad = this.userPlayers();
    const rec = this.injuries.tickWeek(squad, user.medical);
    for (const p of rec) {
      this.pushNews("Revir", `${p.name} antrenmanlara döndü.`, "good");
    }
    for (const p of Object.values(this.state.players)) {
      if (p.ban > 0) p.ban -= 1;
      const recov = 9 + (this.state.clubs[p.clubId]?.training ?? 1) * 2 + 6;
      p.energy = clamp(p.energy + recov, 12, 100);
    }
    user.balance -= squad.reduce((s, p) => s + p.wage, 0);
    const sp = SPONSORS.find((s) => s.id === user.sponsorId);
    if (sp) user.balance += sp.weekly;
    user.balance += Math.round(user.rep * 4000);
    if (this.state.transferOpen) this.market.cpuWindow(this.state, this.rng);
    this.maybeKnockoutDraw();
    this.advanceKnockouts();
    this.state.week += 1;
    this.state.transferOpen = this.state.week <= 4 || (this.state.week >= 20 && this.state.week <= 23);
    if (this.state.week > this.state.maxWeek) this.endSeason();
    else {
      const next = this.nextUserFixture();
      if (next) {
        const opp = this.state.clubs[next.homeId === user.id ? next.awayId : next.homeId];
        this.pushNews("Sıradaki maç", `${next.round}: ${opp?.name ?? "Rakip"}`, "neutral");
      }
    }
  }

  private maybeKnockoutDraw() {
    if (this.state.week !== 12) return;
    for (const comp of ["UCL", "UEL", "UECL"] as Comp[]) {
      const groups = this.state.groups.filter((g) => g.comp === comp);
      const first: string[] = [];
      const second: string[] = [];
      for (const g of groups) {
        const t = groupTable(g, this.state.fixtures, this.state.clubs);
        if (t[0]) first.push(t[0].id);
        if (t[1]) second.push(t[1].id);
      }
      const r16 =
        comp === "UCL"
          ? [...first, ...second]
          : comp === "UEL"
            ? [...first, ...this.thirdOf("UCL")]
            : [...first, ...this.thirdOf("UEL")];
      const unique = [...new Set(r16)].slice(0, 16);
      while (unique.length < 16 && second.length) unique.push(second.pop()!);
      const shuffled = this.rng.shuffle(unique);
      for (let i = 0; i < 8; i++) {
        const a = shuffled[i * 2];
        const b = shuffled[i * 2 + 1];
        if (!a || !b) continue;
        this.state.fixtures.push({
          id: `fx_${this.state.uid++}`,
          week: 16,
          comp,
          round: "Son 16",
          homeId: a,
          awayId: b,
          homeGoals: null,
          awayGoals: null,
          played: false,
        });
      }
      this.pushNews(
        `${comp} kuraları`,
        "Gruplar bitti. 3. olanlar alt kupa R16'ya düştü.",
        "neutral",
      );
    }
  }

  private thirdOf(comp: Comp): string[] {
    const groups = this.state.groups.filter((g) => g.comp === comp);
    const third: string[] = [];
    for (const g of groups) {
      const t = groupTable(g, this.state.fixtures, this.state.clubs);
      if (t[2]) third.push(t[2].id);
    }
    return third;
  }

  advanceKnockouts() {
    const rounds: Array<{ from: string; to: string; week: number }> = [
      { from: "Son 16", to: "Çeyrek final", week: 20 },
      { from: "Çeyrek final", to: "Yarı final", week: 24 },
      { from: "Yarı final", to: "Final", week: 28 },
    ];
    for (const comp of ["UCL", "UEL", "UECL"] as Comp[]) {
      for (const r of rounds) {
        const played = this.state.fixtures.filter(
          (f) => f.comp === comp && f.round === r.from && f.played,
        );
        const already = this.state.fixtures.some((f) => f.comp === comp && f.round === r.to);
        if (already || played.length < 2) continue;
        if (played.some((f) => f.week >= this.state.week)) continue;
        const winners = played
          .map((f) => {
            if ((f.homeGoals ?? 0) > (f.awayGoals ?? 0)) return f.homeId;
            if ((f.awayGoals ?? 0) > (f.homeGoals ?? 0)) return f.awayId;
            return this.rng.chance(0.5) ? f.homeId : f.awayId;
          })
          .filter(Boolean);
        if (winners.length < 2) continue;
        if (winners.length % 2 === 1) winners.pop();
        for (let i = 0; i < winners.length; i += 2) {
          this.state.fixtures.push({
            id: `fx_${this.state.uid++}`,
            week: r.week,
            comp,
            round: r.to,
            homeId: winners[i]!,
            awayId: winners[i + 1]!,
            homeGoals: null,
            awayGoals: null,
            played: false,
          });
        }
      }
    }
  }

  bid(playerId: string, amount: number, wage: number) {
    const r = this.market.bid(this.state, this.rng, playerId, amount, wage);
    if (r.ok) this.pushNews("Transfer", r.message, "good");
    this.save();
    return r;
  }

  sell(playerId: string) {
    const r = this.market.sell(this.state, this.rng, playerId);
    if (r.ok) this.pushNews("Satış", r.message, "neutral");
    this.save();
    return r;
  }

  listPlayer(id: string, price: number) {
    this.market.listPlayer(this.state, id, price);
    this.save();
  }

  upgrade(kind: "medical" | "academy" | "training" | "stadium"): string | null {
    const c = this.user();
    if (kind === "stadium") {
      const cost = Math.round(c.cap * 420);
      if (c.balance < cost) return "Bütçe yetersiz.";
      c.balance -= cost;
      c.cap += 4000;
      this.pushNews("Tesis", `Stadyum kapasitesi ${c.cap.toLocaleString("tr-TR")} oldu.`, "good");
      this.save();
      return null;
    }
    const lvl = c[kind];
    if (lvl >= 5) return "Maksimum seviye.";
    const cost = UPGRADE_COST[lvl + 1] ?? 30_000_000;
    if (c.balance < cost) return "Bütçe yetersiz.";
    c.balance -= cost;
    c[kind] = lvl + 1;
    this.pushNews("Tesis", `${kind} seviyesi ${c[kind]} oldu.`, "good");
    this.save();
    return null;
  }

  setSponsor(id: string): string | null {
    const sp = SPONSORS.find((s) => s.id === id);
    if (!sp) return "Sponsor yok.";
    const c = this.user();
    const needMap: Record<string, number> = {
      none: 0,
      local: 0,
      bank: 68,
      airline: 76,
      tech: 86,
    };
    const need = needMap[id] ?? 0;
    if (c.rep < need && id !== "local" && id !== "none") return "İtibar yetersiz.";
    c.sponsorId = id;
    this.save();
    return null;
  }

  buildSeason() {
    this.state.fixtures = [];
    this.state.groups = [];
    for (const c of Object.values(this.state.clubs)) {
      if (c.npc) continue;
      c.pts = c.pld = c.w = c.d = c.l = c.gf = c.ga = 0;
      c.european = null;
    }
    for (const league of LEAGUES) {
      const ids = Object.values(this.state.clubs)
        .filter((c) => c.league === league.id)
        .map((c) => c.id);
      const days = roundRobin(ids);
      days.forEach((pairs, i) => {
        const week = Math.min(1 + i, 38);
        for (const [h, a] of pairs) {
          this.state.fixtures.push({
            id: `fx_${this.state.uid++}`,
            week,
            comp: "league",
            round: `${week}. Hafta`,
            homeId: h,
            awayId: a,
            homeGoals: null,
            awayGoals: null,
            played: false,
          });
        }
      });
    }
    this.seedEurope();
    this.state.maxWeek = 42;
  }

  private seedEurope() {
    const ranked = this.uefa.ranked(this.state.countries);
    const taken = new Set<string>();
    const ucl: string[] = [];
    const uel: string[] = [];
    const uecl: string[] = [];
    const domestic = (code: string) =>
      Object.values(this.state.clubs)
        .filter((c) => c.country === code && !c.npc && c.league.endsWith("1"))
        .sort((a, b) => b.rep - a.rep);
    const npcOf = (code: string) =>
      Object.values(this.state.clubs)
        .filter((c) => c.country === code && c.npc)
        .sort((a, b) => b.rep - a.rep);

    ranked.forEach((country, idx) => {
      const q = this.uefa.quota(idx + 1);
      const pool = [...domestic(country.code), ...npcOf(country.code)].filter((c) => !taken.has(c.id));
      const take = (n: number, bucket: string[], comp: Comp) => {
        let k = 0;
        for (const c of pool) {
          if (k >= n) break;
          if (taken.has(c.id)) continue;
          taken.add(c.id);
          bucket.push(c.id);
          c.european = comp;
          k += 1;
        }
      };
      take(q.uclD + q.uclQ, ucl, "UCL");
      take(q.uel, uel, "UEL");
      take(q.uecl, uecl, "UECL");
    });

    const fill = (bucket: string[], comp: Comp, n: number) => {
      const extras = Object.values(this.state.clubs)
        .filter((c) => !taken.has(c.id) && (c.npc || c.league.endsWith("1")))
        .sort((a, b) => b.rep - a.rep);
      for (const c of extras) {
        if (bucket.length >= n) break;
        taken.add(c.id);
        bucket.push(c.id);
        c.european = comp;
      }
    };
    fill(ucl, "UCL", 32);
    fill(uel, "UEL", 32);
    fill(uecl, "UECL", 32);

    this.makeGroups("UCL", ucl.slice(0, 32), [6, 7, 8, 9, 10, 11]);
    this.makeGroups("UEL", uel.slice(0, 32), [6, 7, 8, 9, 10, 11]);
    this.makeGroups("UECL", uecl.slice(0, 32), [6, 7, 8, 9, 10, 11]);
  }

  private makeGroups(comp: Comp, ids: string[], weeks: number[]) {
    const seeded = ids
      .map((id) => this.state.clubs[id]!)
      .filter(Boolean)
      .sort((a, b) => b.rep - a.rep);
    const groups: string[][] = Array.from({ length: 8 }, () => []);
    seeded.forEach((c, i) => {
      const g = i % 8;
      groups[g]!.push(c.id);
      c.europeSeed = i + 1;
    });
    const names = "ABCDEFGH";
    groups.forEach((clubIds, gi) => {
      const name = names[gi]!;
      this.state.groups.push({ comp, name, clubIds });
      const rr = roundRobin(clubIds);
      rr.slice(0, 6).forEach((pairs, di) => {
        const week = weeks[di] ?? 11;
        for (const [h, a] of pairs) {
          this.state.fixtures.push({
            id: `fx_${this.state.uid++}`,
            week,
            comp,
            round: `Grup ${name}`,
            homeId: h,
            awayId: a,
            homeGoals: null,
            awayGoals: null,
            played: false,
            group: name,
          });
        }
      });
    });
  }

  endSeason() {
    const user = this.user();
    const table = this.leagueTable(user.league);
    const pos = table.findIndex((c) => c.id === user.id) + 1;
    let ok = false;
    switch (this.state.objective) {
      case "title":
        ok = pos === 1;
        break;
      case "top4":
        ok = pos <= 4;
        break;
      case "europe":
        ok = pos <= 7;
        break;
      case "mid":
        ok = pos <= 12;
        break;
      case "survive":
        ok = pos <= table.length - 3;
        break;
      case "promote":
        ok = pos <= 3;
        break;
    }
    this.state.board = clamp(this.state.board + (ok ? 12 : -22), 0, 100);
    this.pushNews(
      "Sezon bitti",
      `${user.name} ligi ${pos}. sırada bitirdi. Hedef ${ok ? "tutturuldu" : "tutturulamadı"}.`,
      ok ? "good" : "bad",
    );
    if (this.state.board < 18) {
      this.state.sacked = true;
      this.pushNews("Kovuldunuz", "Yönetim yeni bir isimle devam edecek.", "bad");
    }
    this.promoteRelegate();
    for (const p of Object.values(this.state.players)) seasonDecay(p, this.rng);
    const kids = this.academy.intake(this.state, this.rng, user);
    if (kids.length) {
      this.pushNews(
        "Akademi",
        kids.map((k) => `${k.name} (${k.pos} ${k.ovr}/${k.pot})`).join(", ") + " A takıma çıktı.",
        "good",
      );
    }
    this.uefa.rollYear(this.state.countries);
    this.state.season += 1;
    this.state.week = 1;
    this.state.seasonOver = false;
    this.state.objective = objectiveFor(user);
    const pick = autoPickXI(this.userPlayers(), user.tactics.formation);
    user.xi = pick.xi;
    user.bench = pick.bench;
    this.buildSeason();
    this.save();
  }

  private promoteRelegate() {
    const tur1 = this.leagueTable("TUR1");
    const tur2 = this.leagueTable("TUR2");
    const down = tur1.slice(-3);
    const up = tur2.slice(0, 3);
    for (const c of down) c.league = "TUR2";
    for (const c of up) c.league = "TUR1";
    if (down.some((c) => c.id === this.state.clubId)) {
      this.pushNews("Küme düşme", "Süper Lig'e veda.", "bad");
      this.state.objective = "promote";
    }
    if (up.some((c) => c.id === this.state.clubId)) {
      this.pushNews("Tebrikler", "Süper Lig'e yükseldiniz.", "good");
      this.state.objective = "survive";
    }
  }

  takeJob(clubId: string) {
    const c = this.state.clubs[clubId];
    if (!c || c.npc) return;
    this.state.clubId = clubId;
    this.state.sacked = false;
    this.state.board = 62;
    this.state.objective = objectiveFor(c);
    const pick = autoPickXI(
      Object.values(this.state.players).filter((p) => p.clubId === clubId),
      c.tactics.formation,
    );
    c.xi = pick.xi;
    c.bench = pick.bench;
    this.pushNews("Yeni görev", `${c.name} ile anlaştınız.`, "good");
    this.save();
  }

  availableJobs(): ClubState[] {
    return Object.values(this.state.clubs)
      .filter((c) => !c.npc && c.id !== this.state.clubId && c.rep < 88)
      .sort((a, b) => b.rep - a.rep)
      .slice(0, 8);
  }
}
