import { POSITIONS } from "../constants";
import { TEAM_SQUADS } from "../data/squads";
import { NAMES } from "../data/names";
import { TEAM_BY_ID } from "../data/teams";
import { hashSeed, irand, mulberry32, pick } from "../rng";
import type { Pos, Teammate } from "../types";

const FALLBACK_POS: Pos[] = [
  "GK", "GK", "RB", "CB", "CB", "CB", "LB", "CDM", "CM", "CM", "CAM", "RM", "LM", "RW", "LW", "ST", "ST", "CF",
];

export function generateSquad(teamId: string): Teammate[] {
  const existing = TEAM_SQUADS[teamId];
  if (existing && existing.length >= 14) return existing.map((p) => ({ ...p }));
  const team = TEAM_BY_ID[teamId];
  const rng = mulberry32(hashSeed(teamId + "_squad"));
  const pool = NAMES[team?.country === "Turkiye" ? "TUR" : team?.country === "England" ? "ENG" : countryNat(team?.country)] || NAMES.ENG;
  const out: Teammate[] = [];
  for (let i = 0; i < 16; i++) {
    const pos = FALLBACK_POS[i] ?? pick(rng, POSITIONS).id;
    const ovr = clampOvr(team?.power ?? 62, pos, rng);
    out.push({
      id: teamId + "_g" + i,
      first: pick(rng, pool.first),
      last: pick(rng, pool.last),
      pos,
      ovr,
      age: irand(rng, 18, 34),
      nat: pool === NAMES.ENG ? "ENG" : Object.keys(NAMES).find((k) => NAMES[k] === pool) || "ENG",
    });
  }
  return out;
}

function countryNat(c?: string): string {
  const map: Record<string, string> = {
    Spain: "ESP",
    Germany: "GER",
    Italy: "ITA",
    France: "FRA",
    Turkiye: "TUR",
    Azerbaijan: "AZE",
    Netherlands: "NED",
    Portugal: "POR",
    Brazil: "BRA",
    Argentina: "ARG",
    USA: "USA",
    Belgium: "BEL",
    Scotland: "SCO",
    England: "ENG",
  };
  return map[c || ""] || "ENG";
}

function clampOvr(power: number, pos: Pos, rng: () => number): number {
  const jitter = Math.floor(rng() * 10) - 5;
  const gkBias = pos === "GK" ? -2 : 0;
  return Math.max(48, Math.min(92, power - 6 + jitter + gkBias));
}

export function computeRole(playerOvr: number, teamPower: number, form: number): "starter" | "rotation" | "bench" {
  const gap = playerOvr + (form - 60) * 0.08 - teamPower;
  if (gap >= -4) return "starter";
  if (gap >= -11) return "rotation";
  return "bench";
}
