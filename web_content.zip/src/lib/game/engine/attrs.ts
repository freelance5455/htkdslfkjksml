import { ALL_ATTRS, POS_WEIGHTS } from "../constants";
import type { Attrs, CardTier, Pos } from "../types";
import { clamp } from "../rng";

export function blankAttrs(base = 55): Attrs {
  const a: Attrs = {};
  for (const k of ALL_ATTRS) a[k] = base;
  return a;
}

export function calcOverall(pos: Pos, attrs: Attrs): number {
  const w = POS_WEIGHTS[pos] || POS_WEIGHTS.CM;
  let sum = 0;
  let tot = 0;
  for (const [k, weight] of Object.entries(w)) {
    sum += (attrs[k] ?? 55) * weight;
    tot += weight;
  }
  const extra =
    ((attrs.stamina ?? 55) + (attrs.reactions ?? 55) + (attrs.composure ?? 55)) / 3;
  const raw = tot ? sum / tot : 55;
  return clamp(Math.round(raw * 0.88 + extra * 0.12), 40, 99);
}

export function tierOf(ovr: number): CardTier {
  if (ovr >= 90) return "legend";
  if (ovr >= 85) return "icon";
  if (ovr >= 78) return "gold";
  if (ovr >= 70) return "silver";
  return "bronze";
}

export function applyGrowth(attrs: Attrs, key: string, delta: number): Attrs {
  const next = { ...attrs, [key]: clamp((attrs[key] ?? 55) + delta, 1, 99) };
  return next;
}
