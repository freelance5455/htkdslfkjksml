import { TEAM_BY_ID } from "../data/teams";
import { clamp, irand, mulberry32 } from "../rng";
import type { CareerState, MatchResult, Pos, Role } from "../types";

export type MomentKind = "attack" | "defense" | "mid";

export type MomentOption = {
  id: string;
  label: string;
  attr: string;
  success: string;
  fail: string;
  tone: "goal" | "key" | "miss" | "warn" | "concede";
  onSuccess?: Partial<Record<"goals" | "assists" | "shots" | "keyPasses" | "tackles" | "yellow", number>>;
  onFail?: Partial<Record<"shots" | "yellow" | "concede", number>>;
};

export type MatchMoment = {
  minute: number;
  zone: MomentKind;
  prompt: string;
  options: MomentOption[];
};

const ATTACK: MomentOption[] = [
  { id: "shot", label: "Sut Cek", attr: "finishing", success: "Aglar sarsildi.", fail: "Kaleci tuttu.", tone: "goal", onSuccess: { goals: 1, shots: 1 }, onFail: { shots: 1 } },
  { id: "thru", label: "Ara Pasi", attr: "passing", success: "Kilit pas, gol pozisyonu.", fail: "Pas kesildi.", tone: "key", onSuccess: { assists: 1, keyPasses: 1 } },
  { id: "drib", label: "Top Sur", attr: "dribbling", success: "Iki adami gecti.", fail: "Topu kaptirdi.", tone: "key", onSuccess: { shots: 1 }, onFail: { concede: 0 } },
  { id: "cross", label: "Orta Yap", attr: "crossing", success: "Muthisem orta, kafa golü.", fail: "Orta disari.", tone: "goal", onSuccess: { assists: 1, keyPasses: 1 } },
];

const DEFENSE: MomentOption[] = [
  { id: "stand", label: "Ayakta Mudahale", attr: "standingTackle", success: "Topu temiz kaptin.", fail: "Gectiler.", tone: "key", onSuccess: { tackles: 1 }, onFail: { concede: 1 } },
  { id: "slide", label: "Kayarak Mudahale", attr: "slidingTackle", success: "Kayarak kesti.", fail: "Gec kaldin, sari kart.", tone: "warn", onSuccess: { tackles: 1 }, onFail: { yellow: 1, concede: 1 } },
  { id: "pos", label: "Pozisyon Al", attr: "defensiveAwareness", success: "Hucumu yavaslattin.", fail: "Bosluk biraktin.", tone: "key" },
  { id: "foul", label: "Taktik Faul", attr: "aggression", success: "Faul, tehlike bitti.", fail: "Sari kart.", tone: "warn", onFail: { yellow: 1 } },
];

const MID: MomentOption[] = [
  { id: "give", label: "Veren-Alan", attr: "passing", success: "Temiz pas zinciri.", fail: "Pas geri donmedi.", tone: "key", onSuccess: { keyPasses: 1 } },
  { id: "carry", label: "Top Sur", attr: "dribbling", success: "Ortaya tasidi.", fail: "Pres altinda kaybetti.", tone: "key" },
  { id: "safe", label: "Guvenli Pas", attr: "passing", success: "Top korundu.", fail: "Geri pas kisa kaldi.", tone: "key" },
  { id: "long", label: "Ara Pasi", attr: "longPassing", success: "Derinlemesine pas.", fail: "Uzun pas israf.", tone: "key", onSuccess: { keyPasses: 1 } },
];

export function startChance(trust: number, role: Role): number {
  const base = clamp((trust / 100) * 1.25, 0.12, 0.97);
  if (role === "starter") return clamp(base + 0.18, 0.35, 0.97);
  if (role === "rotation") return clamp(base, 0.22, 0.8);
  return clamp(base * 0.45, 0.12, 0.4);
}

export function pickMoments(count: number, seed: number): MatchMoment[] {
  const rng = mulberry32(seed);
  const out: MatchMoment[] = [];
  for (let i = 0; i < count; i++) {
    const minute = 4 + Math.floor(((i + rng()) / count) * 84);
    const r = rng();
    const zone: MomentKind = r < 0.38 ? "attack" : r < 0.7 ? "mid" : "defense";
    const pool = zone === "attack" ? ATTACK : zone === "defense" ? DEFENSE : MID;
    const opts = shuffle(pool, rng).slice(0, 3 + (rng() > 0.5 ? 1 : 0));
    const prompt =
      zone === "attack"
        ? "Ceza sahasina girdin. Ne yaparsin?"
        : zone === "defense"
          ? "Rakip hucumda. Mudahele et."
          : "Orta sahada top sende.";
    out.push({ minute, zone, prompt, options: opts });
  }
  return out.sort((a, b) => a.minute - b.minute);
}

function shuffle<T>(arr: T[], rng: () => number): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const t = a[i]!;
    a[i] = a[j]!;
    a[j] = t;
  }
  return a;
}

export function chanceOf(attr: number, form: number, fatigue: number): number {
  return clamp((attr / 100) * 0.72 + (form / 100) * 0.2 - (fatigue / 200) * 0.1 + 0.08, 0.12, 0.92);
}

export function expectedGoals(homePow: number, awayPow: number, home: boolean): number {
  const ratio = homePow / Math.max(1, awayPow);
  const base = home ? 1.45 : 1.15;
  return clamp(base * Math.pow(ratio, 1.15), 0.4, 3.4);
}

function poissonLike(lambda: number, rng: () => number): number {
  let n = 0;
  const limit = 8;
  for (let i = 0; i < limit; i++) if (rng() < lambda / (i + 1.6)) n++;
  return n;
}

export function simAutoMatch(state: CareerState, homeId: string, awayId: string, cup = false): MatchResult {
  const rng = mulberry32(state.week * 997 + hash(homeId + awayId));
  const home = TEAM_BY_ID[homeId];
  const away = TEAM_BY_ID[awayId];
  const hp = (home?.power ?? 70) + (state.clubId === homeId ? (state.player.form - 60) * 0.05 : 0);
  const ap = (away?.power ?? 70) + (state.clubId === awayId ? (state.player.form - 60) * 0.05 : 0);
  let hg = poissonLike(expectedGoals(hp, ap, true), rng);
  let ag = poissonLike(expectedGoals(ap, hp, false), rng);
  const meHome = state.clubId === homeId;
  const role = state.role;
  const starts = role === "starter" || (role === "rotation" && rng() < 0.55);
  const minutes = starts ? irand(rng, 72, 94) : role === "bench" ? irand(rng, 8, 28) : irand(rng, 35, 70);
  const pos = state.player.pos;
  let goals = 0;
  let assists = 0;
  let shots = 0;
  let keyPasses = 0;
  let tackles = 0;
  const att = state.player.attrs;
  const finishP = (att.finishing ?? 55) / 140;
  if (isFwd(pos) && minutes > 20 && rng() < finishP) {
    goals = rng() < 0.22 ? 2 : 1;
    shots = goals + irand(rng, 1, 3);
    if (meHome) hg = Math.max(hg, goals);
    else ag = Math.max(ag, goals);
  } else if (minutes > 25) {
    shots = irand(rng, 0, isFwd(pos) ? 4 : 2);
    if (rng() < (att.passing ?? 55) / 180) assists = 1;
    keyPasses = irand(rng, 0, 3);
    tackles = irand(rng, 0, isDef(pos) ? 5 : 2);
  }
  let rating = 6.2 + (state.player.form - 60) * 0.015 + (starts ? 0.3 : -0.2);
  rating += goals * 0.7 + assists * 0.4 + (shots > 2 ? 0.15 : 0);
  const won = (meHome && hg > ag) || (!meHome && ag > hg);
  const draw = hg === ag;
  if (won) rating += 0.25;
  if (draw) rating += 0.05;
  rating = clamp(Math.round(rating * 10) / 10, 4.8, 9.7);
  const yellow = rng() < 0.12;
  const red = rng() < 0.015;
  const motm = rating >= 8.3 && (goals > 0 || assists > 0 || rating >= 8.8);
  return {
    week: state.week,
    home: homeId,
    away: awayId,
    hg,
    ag,
    rating,
    goals,
    assists,
    minutes,
    motm,
    yellow,
    red,
    shots,
    keyPasses,
    tackles,
    role,
    cup,
  };
}

export function applyResultToTable(
  table: CareerState["table"],
  homeId: string,
  awayId: string,
  hg: number,
  ag: number,
) {
  const next = table.map((r) => ({ ...r }));
  const h = next.find((r) => r.teamId === homeId);
  const a = next.find((r) => r.teamId === awayId);
  if (!h || !a) return next;
  h.played++;
  a.played++;
  h.gf += hg;
  h.ga += ag;
  a.gf += ag;
  a.ga += hg;
  if (hg > ag) {
    h.won++;
    h.pts += 3;
    a.lost++;
  } else if (ag > hg) {
    a.won++;
    a.pts += 3;
    h.lost++;
  } else {
    h.drawn++;
    a.drawn++;
    h.pts++;
    a.pts++;
  }
  return next;
}

function isFwd(p: Pos) {
  return p === "ST" || p === "CF" || p === "LW" || p === "RW";
}
function isDef(p: Pos) {
  return p === "CB" || p === "LB" || p === "RB" || p === "CDM" || p === "LWB" || p === "RWB";
}

function hash(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

export const AMBIENT = [
  "Orta sahada tempo dustu.",
  "Tribunler ritim tutuyor.",
  "Korner bayragi kalkti.",
  "Hoca kenardan bagiriyor.",
  "Pres yukseldi.",
  "Top disari, aut vurusu.",
  "Hava topu... stoper cikardi.",
  "Hizli cikis denendi.",
];
