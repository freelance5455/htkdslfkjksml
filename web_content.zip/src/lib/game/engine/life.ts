import { CARS, HOMES } from "../constants";
import { PARTNER_FIRST } from "../data/names";
import { clamp, irand, pick, uid } from "../rng";
import type { CareerState } from "../types";

export function logLife(state: CareerState, text: string) {
  state.life.events.unshift({ week: state.week, text });
  state.life.events = state.life.events.slice(0, 10);
}

export function rest(state: CareerState): CareerState {
  const s = structuredClone(state);
  s.player.energy = clamp(s.player.energy + 20, 0, 100);
  s.player.fatigue = clamp(s.player.fatigue - 15, 0, 100);
  s.player.happiness = clamp(s.player.happiness + 2, 0, 100);
  logLife(s, "Dinlendin.");
  return s;
}

export function familyVisit(state: CareerState): CareerState {
  const s = structuredClone(state);
  s.life.family = clamp(s.life.family + 8, 0, 100);
  s.player.happiness = clamp(s.player.happiness + 6, 0, 100);
  logLife(s, "Aile ziyareti.");
  return s;
}

export function friendsOut(state: CareerState): CareerState {
  const s = structuredClone(state);
  s.life.friends = clamp(s.life.friends + 8, 0, 100);
  s.player.happiness = clamp(s.player.happiness + 5, 0, 100);
  logLife(s, "Arkadaslarla bulustun.");
  return s;
}

export function gym(state: CareerState): CareerState {
  const s = structuredClone(state);
  s.player.fitness = clamp(s.player.fitness + 5, 0, 100);
  s.player.energy = clamp(s.player.energy - 8, 0, 100);
  s.player.stress = clamp(s.player.stress - 5, 0, 100);
  logLife(s, "Spor salonu.");
  return s;
}

export function spend(state: CareerState, cost: number, apply: (s: CareerState) => void, label: string): CareerState | string {
  if (state.finances.balance < cost) return "Yetersiz bakiye.";
  const s = structuredClone(state);
  s.finances.balance -= cost;
  apply(s);
  logLife(s, label);
  return s;
}

export function party(state: CareerState) {
  return spend(state, 20_000, (s) => {
    s.player.happiness = clamp(s.player.happiness + 12, 0, 100);
    s.player.popularity = clamp(s.player.popularity + 2, 0, 100);
  }, "Parti verdin.");
}

export function vacation(state: CareerState) {
  return spend(state, 50_000, (s) => {
    s.player.happiness = clamp(s.player.happiness + 15, 0, 100);
    s.player.stress = clamp(s.player.stress - 25, 0, 100);
    s.player.energy = clamp(s.player.energy + 20, 0, 100);
  }, "Tatile ciktin.");
}

export function donate(state: CareerState) {
  return spend(state, 10_000, (s) => {
    s.player.reputation = clamp(s.player.reputation + 2, 0, 100);
    s.player.happiness = clamp(s.player.happiness + 5, 0, 100);
  }, "Bagis yaptin.");
}

export function invest(state: CareerState) {
  return spend(state, 200_000, (s) => {
    const add = irand(Math.random, 5000, 15000);
    s.finances.monthlyIncome += add;
    s.life.business += 1;
  }, "Is yatirimi.");
}

export function buyHome(state: CareerState, level: number) {
  const h = HOMES[level];
  if (!h) return "Gecersiz.";
  if (state.life.home >= level) return "Zaten bu seviyede.";
  return spend(state, h.cost, (s) => {
    s.life.home = level;
    if (level >= 3 && !s.achievements.includes("mansion")) s.achievements.push("mansion");
  }, h.tr + " alindi.");
}

export function buyCar(state: CareerState, level: number) {
  const c = CARS[level];
  if (!c) return "Gecersiz.";
  if (state.life.car >= level) return "Zaten bu seviyede.";
  return spend(state, c.cost, (s) => {
    s.life.car = level;
  }, c.tr + " alindi.");
}

export function startDating(state: CareerState): CareerState {
  const s = structuredClone(state);
  s.life.relationship = "dating";
  s.life.partnerName = pick(Math.random, PARTNER_FIRST);
  s.life.togetherWeeks = 0;
  logLife(s, s.life.partnerName + " ile tanistin.");
  return s;
}

export function propose(state: CareerState): CareerState {
  const s = structuredClone(state);
  if (Math.random() < 0.85) {
    s.life.relationship = "engaged";
    logLife(s, "Evlenme teklifi kabul edildi.");
  } else {
    s.player.happiness = clamp(s.player.happiness - 8, 0, 100);
    logLife(s, "Teklif reddedildi. Zaman lazim.");
  }
  return s;
}

export function marry(state: CareerState): CareerState {
  const s = structuredClone(state);
  s.life.relationship = "married";
  s.player.happiness = clamp(s.player.happiness + 12, 0, 100);
  if (!s.achievements.includes("married")) s.achievements.push("married");
  logLife(s, "Evlendiniz.");
  return s;
}

export function breakUp(state: CareerState): CareerState {
  const s = structuredClone(state);
  s.life.relationship = "single";
  s.life.partnerName = "";
  s.player.happiness = clamp(s.player.happiness - 10, 0, 100);
  logLife(s, "Ayrildiniz.");
  return s;
}

export function haveChild(state: CareerState): CareerState {
  const s = structuredClone(state);
  s.life.kids += 1;
  s.player.happiness = clamp(s.player.happiness + 15, 0, 100);
  s.player.stress = clamp(s.player.stress + 10, 0, 100);
  logLife(s, "Cocuk sahibi oldunuz.");
  return s;
}

export function weeklyLife(state: CareerState): CareerState {
  const s = structuredClone(state);
  if (s.life.relationship !== "single") s.life.togetherWeeks += 1;
  if (Math.random() < 0.3) {
    const roll = Math.random();
    if (roll < 0.25) {
      s.player.popularity = clamp(s.player.popularity + 1, 0, 100);
      logLife(s, "Taraftarlar seni destekliyor.");
    } else if (roll < 0.5) {
      s.player.reputation = clamp(s.player.reputation + 1, 0, 100);
      logLife(s, "Basin senden bahsetti.");
    } else if (roll < 0.75) {
      const bonus = irand(Math.random, 1000, 5000);
      s.finances.balance += bonus;
      logLife(s, "Sponsor teklifi: £" + bonus);
    } else if (s.life.relationship !== "single") {
      s.player.happiness = clamp(s.player.happiness + 3, 0, 100);
      logLife(s, "Partnerinle kaliteli zaman.");
    }
  }
  if (Math.random() < 0.15 && !s.injury) {
    s.injury = { name: pick(Math.random, ["Kasik agrisi", "Burkulma", "Hafif zorlanma"]), weeksLeft: 1 };
    s.player.fitness = clamp(s.player.fitness - 12, 20, 100);
    logLife(s, "Hafif sakatlik: " + s.injury.name);
    s.news.unshift({
      id: uid("n"),
      week: s.week,
      title: "Sakatlik uyarisi",
      body: s.player.displayName + " " + s.injury.name.toLowerCase() + " ile idman kacti.",
      kind: "life",
    });
  }
  return s;
}
