import { INTENSITY, TRAINING_FOCI } from "../constants";
import { STARS } from "../data/stars";
import { TEAM_BY_ID, TEAMS, teamsInLeague } from "../data/teams";
import { addDays, ageFromDob } from "../format";
import { clamp, irand, pick, uid } from "../rng";
import type { CareerState, MatchResult, WorldTransfer } from "../types";
import { calcOverall } from "./attrs";
import { applyResultToTable, simAutoMatch } from "./match";
import { weeklySocial } from "./social";
import { weeklyLife } from "./life";
import { computeRole, generateSquad } from "./squad";
import { wageFor } from "./create";

export type WeekOpts = { autoMatch: boolean };

export function applyTraining(state: CareerState): CareerState {
  const s = structuredClone(state);
  const focus = TRAINING_FOCI.find((f) => f.id === s.training.focus) || TRAINING_FOCI[0]!;
  const inten = INTENSITY[s.training.intensity];
  const age = ageFromDob(s.player.dob, s.date);
  const ageMult = age < s.player.peakAge ? 1.3 : 0.5;
  if (focus.id !== "recover") {
    for (const key of focus.attrs) {
      if (Math.random() < 0.15 * inten.mult) {
        const gain = (Math.random() < 0.5 ? 1 : 2) * (ageMult > 1 ? 1 : 1);
        const scaled = Math.max(1, Math.round(gain * ageMult * s.player.growthRate * (inten.mult >= 1 ? 1 : 0.8)));
        const cur = s.player.attrs[key] ?? 55;
        if (cur < s.player.potential && cur < 94) {
          s.player.attrs[key] = clamp(cur + scaled, 1, 99);
        }
      }
    }
  }
  s.player.fatigue = clamp(s.player.fatigue + (focus.id === "recover" ? -20 : inten.fatigue), 0, 100);
  s.player.fitness = clamp(s.player.fitness + 8, 0, 100);
  s.player.fatigue = clamp(s.player.fatigue - 25, 0, 100);
  s.player.energy = clamp(s.player.energy + 30, 0, 100);
  s.player.stress = clamp(s.player.stress - 5, 0, 100);
  s.player.overall = calcOverall(s.player.pos, s.player.attrs);
  return s;
}

export function currentFixture(state: CareerState) {
  return state.fixtures.find((f) => f.week === state.week && (f.home === state.clubId || f.away === state.clubId));
}

export function applyMatchResult(state: CareerState, res: MatchResult): CareerState {
  const s = structuredClone(state);
  s.lastResult = res;
  s.matchLog.unshift(res);
  s.table = applyResultToTable(s.table, res.home, res.away, res.hg, res.ag);
  const meHome = res.home === s.clubId;
  const gf = meHome ? res.hg : res.ag;
  const ga = meHome ? res.ag : res.hg;
  const won = gf > ga;
  const draw = gf === ga;
  s.seasonStats.apps += 1;
  if (res.minutes >= 60) s.seasonStats.starts += 1;
  s.seasonStats.goals += res.goals;
  s.seasonStats.assists += res.assists;
  s.seasonStats.shots += res.shots;
  s.seasonStats.keyPasses += res.keyPasses;
  s.seasonStats.tackles += res.tackles;
  s.seasonStats.minutes += res.minutes;
  s.seasonStats.ratingSum += res.rating;
  s.seasonStats.avgRating = Math.round((s.seasonStats.ratingSum / s.seasonStats.apps) * 10) / 10;
  if (res.yellow) s.seasonStats.yellowCards += 1;
  if (res.red) s.seasonStats.redCards += 1;
  if (res.motm) s.seasonStats.motm += 1;
  s.finances.balance += s.contract.appearanceBonus;
  s.finances.balance += res.goals * s.contract.goalBonus;
  s.finances.balance += res.assists * s.contract.assistBonus;
  s.player.form = clamp(s.player.form + (res.rating - 6.5) * 3, 20, 99);
  s.player.morale = clamp(s.player.morale + (won ? 6 : draw ? 1 : -5) + res.goals * 2, 10, 100);
  s.player.confidence = clamp(s.player.confidence + (res.rating - 6.8) * 2, 10, 100);
  s.player.fatigue = clamp(s.player.fatigue + 12, 0, 100);
  const deltaTrust = res.rating >= 7.5 ? 3 : res.rating >= 6.5 ? 1 : -3;
  s.manager.trust = clamp(s.manager.trust + deltaTrust, 5, 99);
  s.role = computeRole(s.player.overall, TEAM_BY_ID[s.clubId]?.power ?? 70, s.player.form);
  const opp = TEAM_BY_ID[meHome ? res.away : res.home];
  s.news.unshift({
    id: uid("n"),
    week: s.week,
    title: TEAM_BY_ID[res.home]?.name + " " + res.hg + "-" + res.ag + " " + TEAM_BY_ID[res.away]?.name,
    body:
      s.player.displayName +
      " " +
      res.minutes +
      " dk, reyting " +
      res.rating.toFixed(1) +
      (res.goals ? ", " + res.goals + " gol" : "") +
      (opp ? ". Rakip: " + opp.name : ""),
    kind: "match",
  });
  s.careerHistory.unshift({
    week: s.week,
    season: s.season,
    text: (won ? "Galibiyet" : draw ? "Beraberlik" : "Maglubiyet") + " " + res.hg + "-" + res.ag,
  });
  if (!s.achievements.includes("first_match")) s.achievements.push("first_match");
  if (res.goals > 0 && !s.achievements.includes("first_goal")) s.achievements.push("first_goal");
  if (res.motm && !s.achievements.includes("motm")) s.achievements.push("motm");
  if (s.social.setup) {
    s.social.followers += Math.round(40 + res.rating * 12 + res.goals * 80);
    if (s.social.followers >= 1000 && !s.achievements.includes("1k")) s.achievements.push("1k");
    if (s.social.followers >= 10000) {
      s.social.verified = true;
      if (!s.achievements.includes("verified")) s.achievements.push("verified");
    }
  }
  s.news = s.news.slice(0, 40);
  s.matchLog = s.matchLog.slice(0, 60);
  return s;
}

function simRestOfLeague(state: CareerState): CareerState {
  const s = structuredClone(state);
  const weekFx = s.fixtures.filter((f) => f.week === s.week);
  for (const f of weekFx) {
    if (f.home === s.clubId || f.away === s.clubId) continue;
    const rngRes = simAutoMatch({ ...s, clubId: "___" }, f.home, f.away);
    s.table = applyResultToTable(s.table, f.home, f.away, rngRes.hg, rngRes.ag);
  }
  return s;
}

function worldTransfers(state: CareerState): WorldTransfer[] {
  const n = irand(Math.random, 2, 5);
  const out: WorldTransfer[] = [];
  for (let i = 0; i < n; i++) {
    const star = pick(Math.random, STARS);
    const from = pick(Math.random, TEAMS);
    let to = pick(Math.random, TEAMS);
    let guard = 0;
    while (to.id === from.id && guard++ < 8) to = pick(Math.random, TEAMS);
    const free = Math.random() < 0.08;
    const fee = free ? 0 : Math.round((star.ovr - 70) * 4_000_000 * (0.8 + Math.random()));
    out.push({
      id: uid("wt"),
      week: state.week,
      name: star.name,
      pos: star.pos,
      ovr: star.ovr,
      age: star.age,
      nat: star.nat,
      fromId: from.id,
      toId: to.id,
      fee,
      rumor: Math.random() < 0.3,
      record: fee >= 150_000_000,
    });
  }
  return out;
}

function maybeInterest(state: CareerState): CareerState {
  const s = structuredClone(state);
  if (Math.random() < 0.1) {
    const stronger = TEAMS.filter((t) => t.power > (TEAM_BY_ID[s.clubId]?.power ?? 70) && t.id !== s.clubId);
    if (stronger.length) {
      const club = pick(Math.random, stronger);
      s.transferInterest.unshift({ teamId: club.id, week: s.week });
      s.news.unshift({
        id: uid("n"),
        week: s.week,
        title: club.name + " seni izliyor",
        body: "Scout raporlari " + s.player.displayName + " icin olumlu.",
        kind: "transfer",
      });
    }
  }
  if (s.player.overall >= 68 && s.player.form >= 55 && Math.random() < 0.1) {
    const club = pick(
      Math.random,
      TEAMS.filter((t) => t.id !== s.clubId),
    );
    s.offers.unshift({
      id: uid("of"),
      teamId: club.id,
      kind: Math.random() < 0.3 ? "loan" : "transfer",
      fee: Math.round(s.player.overall * 120000 * (0.6 + Math.random())),
      wage: Math.round(wageFor(s.player.overall, club.power) * (1.05 + Math.random() * 0.3)),
      years: 3,
      managerName: club.name + " menajeri",
      week: s.week,
      status: "open",
    });
    s.news.unshift({
      id: uid("n"),
      week: s.week,
      title: "Menajer DM atti",
      body: club.name + " teklif gonderdi.",
      kind: "transfer",
    });
    if (s.social.threads) {
      s.social.threads.unshift({
        userId: "offer_" + club.id,
        unread: 1,
        messages: [
          {
            id: uid("m"),
            from: "them",
            text:
              "Merhaba, " +
              club.name +
              " adina yaziyorum. " +
              (Math.random() < 0.3 ? "Kiralik" : "Transfer") +
              " teklifimiz var. Konusalim mi?",
            time: "Az once",
          },
        ],
      });
    }
  }
  s.transferInterest = s.transferInterest.slice(0, 12);
  s.offers = s.offers.slice(0, 10);
  return s;
}

export function acceptOffer(state: CareerState, offerId: string): CareerState {
  const s = structuredClone(state);
  const offer = s.offers.find((o) => o.id === offerId);
  if (!offer) return s;
  offer.status = "accepted";
  const team = TEAM_BY_ID[offer.teamId];
  if (!team) return s;
  s.clubId = team.id;
  s.leagueId = team.leagueId;
  s.teammates = generateSquad(team.id);
  s.contract.weeklyWage = offer.wage;
  s.contract.years = offer.years;
  s.contract.signedWeek = s.week;
  s.finances.weeklyWage = offer.wage;
  s.role = computeRole(s.player.overall, team.power, s.player.form);
  const ids = teamsInLeague(team.leagueId).map((t) => t.id);
  s.table = ids.map((teamId) => ({
    teamId,
    played: 0,
    won: 0,
    drawn: 0,
    lost: 0,
    gf: 0,
    ga: 0,
    pts: 0,
  }));
  s.careerHistory.unshift({ week: s.week, season: s.season, text: team.name + " transferi tamam." });
  s.news.unshift({
    id: uid("n"),
    week: s.week,
    title: "Imza atildi",
    body: s.player.displayName + " " + team.name + " formasini giyiyor.",
    kind: "transfer",
  });
  return s;
}

export function declineOffer(state: CareerState, offerId: string): CareerState {
  const s = structuredClone(state);
  s.offers = s.offers.map((o) => (o.id === offerId ? { ...o, status: "declined" } : o));
  return s;
}

function endSeasonIfNeeded(state: CareerState): CareerState {
  const maxWeek = state.fixtures.reduce((m, f) => Math.max(m, f.week), 1);
  if (state.week < maxWeek) return state;
  const s = structuredClone(state);
  const sorted = [...s.table].sort((a, b) => b.pts - a.pts || b.gf - b.ga - (a.gf - a.ga));
  const me = sorted.findIndex((r) => r.teamId === s.clubId);
  const champ = TEAM_BY_ID[sorted[0]?.teamId || ""];
  if (me === 0 && champ) {
    s.trophies.push({
      id: uid("tr"),
      name: (TEAM_BY_ID[s.clubId] ? s.leagueId : "Lig") + " sampiyonlugu",
      season: s.season,
      team: TEAM_BY_ID[s.clubId]?.name || "",
    });
  }
  s.seasonIndex += 1;
  const start = 2026 + s.seasonIndex;
  s.season = start + "/" + String(start + 1).slice(2);
  s.week = 1;
  s.date = start + "-08-15";
  s.seasonStats = {
    apps: 0,
    starts: 0,
    goals: 0,
    assists: 0,
    shots: 0,
    keyPasses: 0,
    tackles: 0,
    minutes: 0,
    yellowCards: 0,
    redCards: 0,
    motm: 0,
    ratingSum: 0,
    avgRating: 0,
  };
  const ids = teamsInLeague(s.leagueId).map((t) => t.id);
  s.table = ids.map((teamId) => ({
    teamId,
    played: 0,
    won: 0,
    drawn: 0,
    lost: 0,
    gf: 0,
    ga: 0,
    pts: 0,
  }));
  s.news.unshift({
    id: uid("n"),
    week: 1,
    title: "Yeni sezon",
    body: s.season + " basliyor. Gecen sene lig sirasi: " + (me + 1) + ".",
    kind: "club",
  });
  return s;
}

export function wrapWeek(state: CareerState): CareerState {
  let s = simRestOfLeague(state);
  s.worldTransfers = [...worldTransfers(s), ...s.worldTransfers].slice(0, 40);
  s = maybeInterest(s);
  s = weeklyLife(s);
  s.social = weeklySocial(s);
  s.finances.balance += s.finances.weeklyWage;
  if (s.week % 4 === 0) {
    s.finances.balance += s.finances.monthlyIncome;
    s.finances.balance -= s.finances.monthlyExpenses;
  }
  s.week += 1;
  s.date = addDays(s.date, 7);
  s.role = computeRole(s.player.overall, TEAM_BY_ID[s.clubId]?.power ?? 70, s.player.form);
  s = endSeasonIfNeeded(s);
  s.notifications = ["Hafta " + s.week + " · " + s.date, ...s.notifications].slice(0, 12);
  return s;
}

export function preparePlay(state: CareerState): CareerState {
  let s = applyTraining(state);
  if (s.injury) {
    s.injury.weeksLeft -= 1;
    if (s.injury.weeksLeft <= 0) s.injury = null;
  }
  return s;
}

export function advanceWeek(state: CareerState): { state: CareerState; result?: MatchResult } {
  let s = preparePlay(state);
  const fx = currentFixture(s);
  let result: MatchResult | undefined;
  if (fx && !s.injury) {
    result = simAutoMatch(s, fx.home, fx.away, !!fx.cup);
    s = applyMatchResult(s, result);
  }
  s = wrapWeek(s);
  return { state: s, result };
}
