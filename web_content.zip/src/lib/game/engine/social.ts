import { clamp, irand, pick, uid } from "../rng";
import { TEAM_BY_ID, TEAMS } from "../data/teams";
import type { CareerState, GramPost, GramUser, Player, SocialState } from "../types";

const NPC: Omit<GramUser, "id">[] = [
  { username: "fabio_wire", displayName: "Fabio Romano", bio: "Here we go.", verified: true, followers: 12_400_000, following: 210, hue: 210, npc: true, role: "media" },
  { username: "goalzone", displayName: "GoalZone", bio: "Gol arsivi.", verified: true, followers: 8_200_000, following: 40, hue: 12, npc: true, role: "media" },
  { username: "skypitch", displayName: "Sky Pitch News", bio: "Breaking.", verified: true, followers: 6_100_000, following: 80, hue: 200, npc: true, role: "media" },
  { username: "pitchside", displayName: "Pitchside FC", bio: "The game.", verified: true, followers: 4_400_000, following: 12, hue: 30, npc: true, role: "media" },
  { username: "uclnights", displayName: "Night of Cups", bio: "Avrupa geceleri.", verified: true, followers: 9_000_000, following: 8, hue: 250, npc: true, role: "media" },
  { username: "skillreel", displayName: "433 Reel", bio: "Ayak bilegi.", verified: true, followers: 15_000_000, following: 3, hue: 0, npc: true, role: "media" },
  { username: "bleach_pitch", displayName: "Terrace Report", bio: "POV: 90+3", verified: true, followers: 7_200_000, following: 20, hue: 18, npc: true, role: "media" },
  { username: "transferguru", displayName: "Transfer Guru", bio: "Medical done.", verified: true, followers: 3_100_000, following: 400, hue: 160, npc: true, role: "media" },
  { username: "tacticalmind", displayName: "Tactical Mind", bio: "4-3-3 evrimi.", verified: true, followers: 1_200_000, following: 90, hue: 190, npc: true, role: "media" },
  { username: "ballonwire", displayName: "Ballon Wire", bio: "Shortlist.", verified: true, followers: 2_400_000, following: 15, hue: 45, npc: true, role: "media" },
  { username: "terrace_talk", displayName: "Terrace Talk", bio: "Away days.", verified: true, followers: 890_000, following: 300, hue: 140, npc: true, role: "fan" },
  { username: "ultrasvoice", displayName: "Ultras Voice", bio: "TIFO.", verified: true, followers: 640_000, following: 50, hue: 355, npc: true, role: "fan" },
  { username: "statsman", displayName: "StatsMan", bio: "xG yalan soylemez.", verified: true, followers: 1_800_000, following: 22, hue: 175, npc: true, role: "media" },
];

const CAPTIONS: Record<string, string[]> = {
  goal: [
    "Aglar sarsildi. Isi bitirdik.",
    "Bir an. Bir vurus. Uc puan.",
    "Bu gece bunun icin oynuyoruz.",
  ],
  train: ["Sabah seansi. Detaylar onemli.", "Ter, tekrar, ritim.", "Sessiz gunler, gurultulu maclar."],
  matchday: ["Forma sirtta. Stad isiklari.", "Mac gunu. Nefes tut.", "Tunel. Grovl. Islik."],
  team: ["Soyunma odasi. Kardeslik.", "Biz. Sadece biz.", "Hafta ici is, pazar odul."],
  life: ["Saha disi, kafa ici.", "Sehir sessiz, kafa degil.", "Kisa bir nefes."],
  deal: ["Kalem, kagit, gelecek.", "Yeni sayfa.", "Imza atildi."],
  cup: ["Gumus parliyor.", "Bir gece, bir kupa.", "Final havasi."],
  sign: ["Hos geldin, yeni adres.", "Forma numarasi hazir.", "Bu sehir, bu renkler."],
  press: ["Mikrofonlar, ayni soru.", "Sahada konusulur.", "Basin gunu."],
};

export function initSocial(player: Player): SocialState {
  const me: GramUser = {
    id: "me",
    username: slug(player.displayName),
    displayName: player.displayName,
    bio: player.pos + " · " + player.nat,
    verified: false,
    followers: 240 + player.overall * 12,
    following: 48,
    hue: 150,
    npc: false,
  };
  const users: GramUser[] = [
    me,
    ...NPC.map((n, i) => ({ ...n, id: "npc_" + i })),
  ];
  const posts: GramPost[] = NPC.slice(0, 6).map((n, i) => ({
    id: uid("p"),
    userId: "npc_" + i,
    scene: ["matchday", "goal", "press", "train", "cup", "deal"][i % 6]!,
    caption: n.bio + " " + (["Here we go.", "Top 10 this week.", "Title race.", "The debate.", "Cup nights.", "Skill reel."][i % 6] || ""),
    likes: 12000 + i * 4300,
    liked: false,
    comments: [
      { userId: "npc_10", text: "Bu sezon baska." },
      { userId: "npc_11", text: "Tribun bunu bekliyordu." },
    ],
    week: 1,
    time: "2sa",
    location: "",
    hashtags: ["football", "matchday"],
    mentions: [],
    saved: false,
  }));
  return {
    setup: false,
    username: me.username,
    displayName: me.displayName,
    bio: me.bio,
    hue: 150,
    verified: false,
    followers: me.followers,
    followingCount: 48,
    posts,
    stories: [
      { id: uid("s"), userId: "me", scene: "life", text: "Hazirlik", seen: false },
      { id: uid("s"), userId: "npc_0", scene: "deal", text: "Incoming...", seen: false },
      { id: uid("s"), userId: "npc_7", scene: "sign", text: "Medical", seen: false },
    ],
    users,
    activity: [],
    threads: [
      {
        userId: "npc_0",
        unread: 1,
        messages: [{ id: uid("m"), from: "them", text: "Sakin ol, dogru adimlari konusuruz.", time: "1sa" }],
      },
    ],
    followingIds: ["npc_0", "npc_1", "npc_7"],
    savedIds: [],
  };
}

export function slug(s: string): string {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "")
    .slice(0, 16) || "player";
}

export function weeklySocial(state: CareerState): SocialState {
  const social = structuredClone(state.social);
  const n = 1 + (Math.random() > 0.5 ? 1 : 0);
  const lines = [
    { u: 0, t: "Here we go. Transfer news incoming.", sc: "deal" },
    { u: 1, t: "Top 10 goals of the week.", sc: "goal" },
    { u: 2, t: "BREAKING: title race heats up.", sc: "press" },
    { u: 3, t: "The GOAT debate continues.", sc: "press" },
    { u: 4, t: "The cup nights we live for.", sc: "cup" },
    { u: 5, t: "Skill moves that broke ankles.", sc: "train" },
    { u: 6, t: "POV: you scored in the 90th minute.", sc: "goal" },
    { u: 7, t: "Medical completed. Announcement soon.", sc: "sign" },
    { u: 8, t: "Why the modern 4-3-3 is evolving.", sc: "press" },
    { u: 9, t: "30-man shortlist incoming.", sc: "press" },
    { u: 10, t: "Away days hit different.", sc: "matchday" },
    { u: 11, t: "TIFO tonight is MASSIVE.", sc: "cup" },
    { u: 12, t: "xG doesn't lie.", sc: "press" },
  ];
  for (let i = 0; i < n; i++) {
    const L = pick(Math.random, lines);
    social.posts.unshift({
      id: uid("p"),
      userId: "npc_" + L.u,
      scene: L.sc,
      caption: L.t,
      likes: irand(Math.random, 4000, 180000),
      liked: false,
      comments: [{ userId: "npc_10", text: "Bu dogru." }],
      week: state.week,
      time: "Az once",
      location: "",
      hashtags: ["football"],
      mentions: [],
      saved: false,
    });
  }
  if (social.posts.length > 40) social.posts = social.posts.slice(0, 40);
  if (Math.random() < 0.35) {
    social.activity.unshift({
      id: uid("a"),
      kind: "follow",
      userId: "npc_" + irand(Math.random, 0, 12),
      text: "seni takip etmeye basladi",
      unread: true,
      week: state.week,
    });
    social.followers += irand(Math.random, 8, 80);
  }
  return social;
}

export function composePost(
  state: CareerState,
  scene: string,
  caption: string,
  hashtags: string[],
  mentions: string[],
): SocialState {
  const social = structuredClone(state.social);
  const reach = estimateReach(social.followers, scene);
  social.posts.unshift({
    id: uid("p"),
    userId: "me",
    scene,
    caption,
    likes: Math.round(reach * 0.08),
    liked: false,
    comments: [],
    week: state.week,
    time: "Az once",
    location: TEAM_BY_ID[state.clubId]?.name || "",
    hashtags,
    mentions,
    saved: false,
  });
  social.followers += Math.round(reach * 0.01);
  return social;
}

export function estimateReach(followers: number, scene: string): number {
  const m = scene === "goal" ? 2.4 : scene === "cup" ? 1.8 : scene === "matchday" ? 1.4 : 1;
  return Math.round(followers * (0.12 + Math.random() * 0.25) * m);
}

export function reachLabel(n: number, followers: number): string {
  const r = n / Math.max(1, followers);
  if (r > 0.7) return "Viral";
  if (r > 0.35) return "Yuksek";
  if (r > 0.15) return "Iyi";
  return "Sinirli";
}

export function captionsFor(scene: string, last?: CareerState["lastResult"]): string[] {
  const base = CAPTIONS[scene] || CAPTIONS.life!;
  if (scene === "goal" && last && last.goals > 0) {
    return [last.goals + " gol. Is bitti.", ...base];
  }
  return base;
}

export function dmReply(text: string, role?: GramUser["role"]): string {
  const t = text.toLowerCase();
  if (/selam|merhaba|hey|sa\b/.test(t)) return pick(Math.random, ["Selam, nasilsin?", "Iyidir, saha sonrasi yaz.", "Hey. Hazir misin?"]);
  if (/tesekkur|sagol|saol/.test(t)) return "Rica ederim.";
  if (/antrenman|idman/.test(t)) return pick(Math.random, ["Sabah seansinda gorusuruz.", "Yuk yuksek, gel."]);
  if (/mac|gol|form/.test(t)) return pick(Math.random, ["Form yerindeyse is biter.", "Gol zaten gelecek.", "Mac gunu konusuruz."]);
  if (/kabul|red|teklif|transfer|kulup/.test(t) && (role === "agent" || role === "manager"))
    return pick(Math.random, ["Numaralari konusuruz.", "Sakin ol, dogru kulubu bekleyelim.", "Bu teklif ciddi."]);
  if (/maas|para|sozlesme/.test(t) && role === "agent") return "Butceyi ben hesaplarim. Sen sahaya bak.";
  if (/\?/.test(t)) return "Dusunecegim. Sonra donerim.";
  if (/harika|efsane|aslan|god/.test(t)) return pick(Math.random, ["Tesekkurler.", "Saha konusur."]);
  if (role === "agent") return "Sen futboluna odaklan.";
  if (role === "manager") return "Antrenmana odaklan.";
  if (role === "teammate") return "Aynen kanka.";
  if (role === "fan") return "MUAZZAM.";
  return pick(Math.random, ["Tamamdir.", "Gorusuruz.", "Not ettim."]);
}

export function syncClubUser(state: CareerState): GramUser {
  const team = TEAM_BY_ID[state.clubId];
  return {
    id: "club",
    username: (team?.id || "club").replace(/-/g, ""),
    displayName: team?.name || "Kulup",
    bio: "Resmi hesap",
    verified: true,
    followers: (team?.power || 70) * 80_000,
    following: 40,
    hue: 220,
    npc: true,
    role: "club",
  };
}

export function randomClub(): string {
  return TEAMS[Math.floor(Math.random() * TEAMS.length)]!.id;
}

export function milestoneAt(n: number): number | null {
  const ms = [100, 1000, 10000, 100000, 1000000];
  for (const m of ms) if (n >= m) return m;
  return null;
}

export function applyFollowers(social: SocialState, add: number): SocialState {
  const before = social.followers;
  social.followers = clamp(social.followers + add, 0, 50_000_000);
  if (social.followers >= 10000) social.verified = true;
  social.users = social.users.map((u) => (u.id === "me" ? { ...u, followers: social.followers, verified: social.verified } : u));
  void before;
  return social;
}
