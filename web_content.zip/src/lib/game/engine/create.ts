import { ALL_ATTRS, ARCHETYPES } from "../constants";
import { AGENT_FIRST, AGENT_LAST, MANAGER_FIRST, MANAGER_LAST } from "../data/names";
import { TEAM_BY_ID, teamsInLeague } from "../data/teams";
import { blankAttrs, calcOverall } from "./attrs";
import { computeRole, generateSquad } from "./squad";
import { initSocial } from "./social";
import { clamp, irand, mulberry32, pick, uid } from "../rng";
import type { CareerState, Player, Pos, TableRow } from "../types";

export type CreateDraft = {
  firstName: string;
  lastName: string;
  displayName: string;
  nat: string;
  nat2: string;
  dob: string;
  foot: "right" | "left";
  pos: Pos;
  pos2: Pos | "";
  height: number;
  weight: number;
  number: number;
  archetype: string;
  personality: Player["personality"];
  attrs: Record<string, number>;
  points: number;
};

export function defaultDraft(): CreateDraft {
  return {
    firstName: "Arda",
    lastName: "Yilmaz",
    displayName: "A. Yilmaz",
    nat: "TUR",
    nat2: "",
    dob: "2005-03-12",
    foot: "right",
    pos: "CAM",
    pos2: "",
    height: 178,
    weight: 72,
    number: 10,
    archetype: "play",
    personality: "ambitious",
    attrs: blankAttrs(55),
    points: 30,
  };
}

export function buildPlayer(d: CreateDraft): Player {
  const rng = mulberry32(Date.now() % 1_000_000);
  const attrs = { ...blankAttrs(55), ...d.attrs };
  for (const k of ALL_ATTRS) if (attrs[k] == null) attrs[k] = 55;
  const overall = calcOverall(d.pos, attrs);
  const potential = clamp(overall + irand(rng, 15, 30), overall + 4, 95);
  const profMap: Record<Player["personality"], number> = {
    professional: 88,
    ambitious: 74,
    loyal: 80,
    fiery: 62,
    calm: 78,
    determined: 84,
  };
  return {
    firstName: d.firstName.trim() || "Oyuncu",
    lastName: d.lastName.trim() || "Yeni",
    displayName: d.displayName.trim() || (d.firstName[0] || "O") + ". " + (d.lastName || "Yeni"),
    nat: d.nat,
    nat2: d.nat2,
    dob: d.dob,
    foot: d.foot,
    pos: d.pos,
    pos2: d.pos2,
    height: d.height,
    weight: d.weight,
    number: d.number,
    archetype: d.archetype || ARCHETYPES[0]!.id,
    personality: d.personality,
    attrs,
    overall,
    potential,
    growthRate: 0.75 + rng() * 0.5,
    peakAge: irand(rng, 27, 31),
    injurySusceptibility: 0.3 + rng() * 0.5,
    professionalism: profMap[d.personality],
    consistency: 0.5 + rng() * 0.4,
    fitness: 100,
    morale: 75,
    form: 60,
    fatigue: 10,
    happiness: 75,
    energy: 100,
    stress: 20,
    confidence: 65,
    popularity: 20,
    reputation: 25,
  };
}

export function wageFor(ovr: number, teamPower: number): number {
  return Math.round((Math.max(0, ovr - 48) * 420 + teamPower * 70) / 50) * 50;
}

export function generateFixtures(teamIds: string[]): CareerState["fixtures"] {
  const ids = teamIds.slice();
  if (ids.length % 2 === 1) ids.push("BYE");
  const n = ids.length;
  const rounds = n - 1;
  const half = n / 2;
  const rotating = ids.slice(1);
  const fixtures: CareerState["fixtures"] = [];
  for (let r = 0; r < rounds; r++) {
    const round = [ids[0]!, ...rotating];
    for (let i = 0; i < half; i++) {
      const a = round[i]!;
      const b = round[n - 1 - i]!;
      if (a === "BYE" || b === "BYE") continue;
      const home = r % 2 === 0 ? a : b;
      const away = r % 2 === 0 ? b : a;
      fixtures.push({ week: r + 1, home, away });
    }
    rotating.unshift(rotating.pop()!);
  }
  const firstHalf = fixtures.slice();
  const offset = rounds;
  for (const f of firstHalf) {
    fixtures.push({ week: f.week + offset, home: f.away, away: f.home });
  }
  return fixtures;
}

export function emptyTable(ids: string[]): TableRow[] {
  return ids.map((teamId) => ({
    teamId,
    played: 0,
    won: 0,
    drawn: 0,
    lost: 0,
    gf: 0,
    ga: 0,
    pts: 0,
  }));
}

export function startCareer(player: Player, clubId: string, slot: number): CareerState {
  const team = TEAM_BY_ID[clubId]!;
  const leagueId = team.leagueId;
  const clubs = teamsInLeague(leagueId);
  const ids = clubs.map((c) => c.id);
  const rng = mulberry32(slot * 999 + player.overall * 13);
  const wage = wageFor(player.overall, team.power);
  const role = computeRole(player.overall, team.power, player.form);
  return {
    slot,
    version: 25,
    player,
    clubId,
    leagueId,
    season: "2026/27",
    date: "2026-08-15",
    week: 1,
    seasonIndex: 0,
    seasonStats: {
      apps: 0,
      starts: 0,
      goals: 0,
      assists: 0,
      shots: 0,
      keyPasses: 0,
      tackles: 0,
      minutes: 0,
      yellowCards: 0,
      redCards: 0,
      motm: 0,
      ratingSum: 0,
      avgRating: 0,
    },
    careerHistory: [{ week: 1, season: "2026/27", text: player.displayName + ", " + team.name + " ile anlasti." }],
    trophies: [],
    awards: [],
    news: [
      {
        id: uid("n"),
        week: 1,
        title: "Yeni imza",
        body: team.name + ", " + player.displayName + " ile sozlesme imzaladi.",
        kind: "club",
      },
    ],
    teammates: generateSquad(clubId),
    manager: {
      first: pick(rng, MANAGER_FIRST),
      last: pick(rng, MANAGER_LAST),
      trust: irand(rng, 55, 70),
      style: pick(rng, ["4-3-3", "4-2-3-1", "3-5-2", "4-4-2"]),
    },
    finances: {
      balance: Math.round(wage * 8),
      weeklyWage: wage,
      monthlyIncome: 0,
      monthlyExpenses: 400,
    },
    contract: {
      years: 3,
      weeklyWage: wage,
      appearanceBonus: 1500,
      goalBonus: 5000,
      assistBonus: 2500,
      signedWeek: 1,
    },
    agent: { first: pick(rng, AGENT_FIRST), last: pick(rng, AGENT_LAST), cut: 8 },
    training: { focus: "balanced", intensity: "mid" },
    transferInterest: [],
    notifications: ["Kariyer basladi. Ilk antrenmanini planla."],
    achievements: [],
    worldTransfers: [],
    life: {
      home: 0,
      car: 0,
      relationship: "single",
      partnerName: "",
      togetherWeeks: 0,
      kids: 0,
      family: 50,
      friends: 45,
      business: 0,
      events: [{ week: 1, text: "Kiralik daireye yerlestin." }],
    },
    injury: null,
    lastResult: null,
    social: initSocial(player),
    socialLastEvent: "",
    fixtures: generateFixtures(ids),
    table: emptyTable(ids),
    matchLog: [],
    role,
    offers: [],
  };
}


