import type { ClubState, Comp, CountryRank, EuropeGroup, Fixture, GameState } from "./types";

export type AccessBand = "top4" | "mid" | "seven" | "low";

export class UEFARankingSystem {
  ranked(countries: CountryRank[]): CountryRank[] {
    return countries
      .slice()
      .sort((a, b) => this.total(b) - this.total(a) || b.seasonPts - a.seasonPts);
  }

  total(c: CountryRank): number {
    return c.fiveYear.reduce((s, x) => s + x, 0);
  }

  seasonCoeff(c: CountryRank): number {
    if (c.seasonMatches <= 0) return 0;
    return c.seasonPts / c.seasonMatches;
  }

  band(rank: number): AccessBand {
    if (rank <= 4) return "top4";
    if (rank <= 6) return "mid";
    if (rank <= 10) return "seven";
    return "low";
  }

  quota(rank: number): { uclD: number; uclQ: number; uel: number; uecl: number } {
    const b = this.band(rank);
    if (b === "top4") return { uclD: 4, uclQ: 0, uel: 2, uecl: 1 };
    if (b === "mid") return { uclD: 2, uclQ: 1, uel: 2, uecl: 1 };
    if (b === "seven") return { uclD: 0, uclQ: 2, uel: 1, uecl: 2 };
    return { uclD: 0, uclQ: 1, uel: 1, uecl: 2 };
  }

  addResult(countries: CountryRank[], country: string, pts: number, matches = 1) {
    const c = countries.find((x) => x.code === country);
    if (!c) return;
    c.seasonPts += pts;
    c.seasonMatches += matches;
  }

  rollYear(countries: CountryRank[]) {
    for (const c of countries) {
      const sc = Number(this.seasonCoeff(c).toFixed(3));
      c.fiveYear = [...c.fiveYear.slice(1), sc];
      c.seasonPts = 0;
      c.seasonMatches = 0;
    }
  }
}

export function groupTable(
  group: EuropeGroup,
  fixtures: Fixture[],
  clubs: Record<string, ClubState>,
): Array<{ id: string; name: string; pld: number; w: number; d: number; l: number; gf: number; ga: number; pts: number }> {
  const rows = group.clubIds.map((id) => ({
    id,
    name: clubs[id]?.name ?? id,
    pld: 0,
    w: 0,
    d: 0,
    l: 0,
    gf: 0,
    ga: 0,
    pts: 0,
  }));
  const map = new Map(rows.map((r) => [r.id, r]));
  for (const f of fixtures) {
    if (!f.played || f.comp !== group.comp || f.group !== group.name) continue;
    if (f.homeGoals == null || f.awayGoals == null) continue;
    const h = map.get(f.homeId);
    const a = map.get(f.awayId);
    if (!h || !a) continue;
    h.pld += 1;
    a.pld += 1;
    h.gf += f.homeGoals;
    h.ga += f.awayGoals;
    a.gf += f.awayGoals;
    a.ga += f.homeGoals;
    if (f.homeGoals > f.awayGoals) {
      h.w += 1;
      h.pts += 3;
      a.l += 1;
    } else if (f.awayGoals > f.homeGoals) {
      a.w += 1;
      a.pts += 3;
      h.l += 1;
    } else {
      h.d += 1;
      a.d += 1;
      h.pts += 1;
      a.pts += 1;
    }
  }
  return rows.sort(
    (a, b) =>
      b.pts - a.pts ||
      b.gf - b.ga - (a.gf - a.ga) ||
      b.gf - a.gf,
  );
}

export function europeRoundLabel(week: number): { compPhase: string; weekKind: string } {
  if (week <= 4) return { compPhase: "Ön eleme", weekKind: "playoff" };
  if (week <= 12) return { compPhase: "Grup", weekKind: "group" };
  if (week <= 16) return { compPhase: "Son 16", weekKind: "r16" };
  if (week <= 20) return { compPhase: "Çeyrek", weekKind: "qf" };
  if (week <= 24) return { compPhase: "Yarı", weekKind: "sf" };
  return { compPhase: "Final", weekKind: "final" };
}

export const COMP_ORDER: Comp[] = ["UCL", "UEL", "UECL"];
