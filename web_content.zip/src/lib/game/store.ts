import { create } from "zustand";
import type { CareerState, CareerView, Screen } from "./types";
import { defaultDraft, buildPlayer, startCareer, type CreateDraft } from "./engine/create";
import { listSlots, loadSlot, saveSlot } from "./save";
import { acceptOffer, advanceWeek, applyMatchResult, currentFixture, declineOffer, preparePlay, wrapWeek } from "./engine/week";
import { TEAM_BY_ID, TEAMS, teamsInLeague } from "./data/teams";
import type { MatchResult } from "./types";
import { isSoundEnabled, setSoundEnabled, unlockSound } from "./sound";
import { ARCHETYPES } from "./constants";
import { irand, pick } from "./rng";

export type Toast = { id: number; text: string; kind?: "ok" | "bad" };

type Store = {
  hydrated: boolean;
  screen: Screen;
  view: CareerView;
  drawer: boolean;
  sound: boolean;
  draft: CreateDraft;
  createStep: number;
  offers: string[];
  career: CareerState | null;
  toast: Toast | null;
  savedFlash: boolean;
  pendingMatch: { home: string; away: string } | null;
  hydrate: () => void;
  setScreen: (s: Screen) => void;
  setView: (v: CareerView) => void;
  setDrawer: (v: boolean) => void;
  toggleSound: () => void;
  setDraft: (p: Partial<CreateDraft>) => void;
  setStep: (n: number) => void;
  shuffleClubs: () => void;
  startFromClub: (clubId: string, slot: number) => void;
  load: (slot: number) => void;
  save: () => void;
  quit: () => void;
  setTraining: (focus: string, intensity: CareerState["training"]["intensity"]) => void;
  weekAdvance: (autoMatch: boolean) => void;
  finishPlayedMatch: (res: MatchResult) => void;
  setCareer: (c: CareerState) => void;
  takeOffer: (id: string, yes: boolean) => void;
  flash: (text: string, kind?: Toast["kind"]) => void;
};

function lowMidClubs(): string[] {
  const pool = TEAMS.filter((t) => t.power >= 52 && t.power <= 78);
  const out: string[] = [];
  const used = new Set<string>();
  let n = 0;
  while (out.length < 3 && n < 40) {
    n++;
    const t = pick(Math.random, pool);
    if (!used.has(t.id)) {
      used.add(t.id);
      out.push(t.id);
    }
  }
  return out;
}

let toastN = 1;

export const useGame = create<Store>((set, get) => ({
  hydrated: false,
  screen: "menu",
  view: "panel",
  drawer: false,
  sound: true,
  draft: defaultDraft(),
  createStep: 1,
  offers: ["bir-vil", "ist-kan", "lyo-n"],
  career: null,
  toast: null,
  savedFlash: false,
  pendingMatch: null,
  hydrate: () => {
    unlockSound();
    set({ hydrated: true, sound: isSoundEnabled(), offers: lowMidClubs() });
  },
  setScreen: (screen) => set({ screen, drawer: false }),
  setView: (view) => set({ view, drawer: false }),
  setDrawer: (drawer) => set({ drawer }),
  toggleSound: () => {
    const next = !get().sound;
    setSoundEnabled(next);
    set({ sound: next });
  },
  setDraft: (p) => {
    const draft = { ...get().draft, ...p };
    if (p.pos) {
      const ok = ARCHETYPES.filter((a) => a.pos.includes(p.pos!));
      if (ok.length && !ok.some((a) => a.id === draft.archetype)) draft.archetype = ok[0]!.id;
    }
    set({ draft });
  },
  setStep: (createStep) => set({ createStep }),
  shuffleClubs: () => set({ offers: lowMidClubs() }),
  startFromClub: (clubId, slot) => {
    const player = buildPlayer(get().draft);
    const career = startCareer(player, clubId, slot);
    saveSlot(career);
    set({ career, screen: "career", view: "panel", createStep: 1 });
  },
  load: (slot) => {
    const career = loadSlot(slot);
    if (!career) return;
    set({ career, screen: "career", view: "panel" });
  },
  save: () => {
    const c = get().career;
    if (!c) return;
    saveSlot(c);
    set({ savedFlash: true });
    setTimeout(() => set({ savedFlash: false }), 1400);
  },
  quit: () => {
    const c = get().career;
    if (c) saveSlot(c);
    set({ career: null, screen: "menu", view: "panel", drawer: false });
  },
  setTraining: (focus, intensity) => {
    const c = get().career;
    if (!c) return;
    set({ career: { ...c, training: { focus, intensity } } });
  },
  weekAdvance: (autoMatch) => {
    const c = get().career;
    if (!c) return;
    const fx = currentFixture(c);
    if (!autoMatch && fx && !c.injury) {
      const trained = preparePlay(c);
      set({ career: trained, pendingMatch: { home: fx.home, away: fx.away }, screen: "match" });
      return;
    }
    const out = advanceWeek(c);
    saveSlot(out.state);
    const res = out.result;
    const gd = res ? (res.home === out.state.clubId ? res.hg - res.ag : res.ag - res.hg) : 0;
    set({
      career: out.state,
      toast: res
        ? {
            id: toastN++,
            text: TEAM_BY_ID[res.home]?.name + " " + res.hg + "-" + res.ag + " " + TEAM_BY_ID[res.away]?.name,
            kind: gd > 0 ? "ok" : gd < 0 ? "bad" : "ok",
          }
        : { id: toastN++, text: "Hafta ilerledi", kind: "ok" },
    });
  },
  finishPlayedMatch: (res) => {
    const c = get().career;
    if (!c) return;
    const s = wrapWeek(applyMatchResult(c, res));
    saveSlot(s);
    set({ career: s, screen: "career", view: "panel", pendingMatch: null });
  },
  setCareer: (career) => {
    set({ career });
    saveSlot(career);
  },
  takeOffer: (id, yes) => {
    const c = get().career;
    if (!c) return;
    const next = yes ? acceptOffer(c, id) : declineOffer(c, id);
    saveSlot(next);
    set({ career: next });
  },
  flash: (text, kind) => set({ toast: { id: toastN++, text, kind } }),
}));

export function suggestedSlot(): number {
  const slots = listSlots();
  const empty = slots.find((s) => !s.occupied);
  return empty ? empty.slot : 0;
}

export { listSlots, TEAM_BY_ID, teamsInLeague, irand };
