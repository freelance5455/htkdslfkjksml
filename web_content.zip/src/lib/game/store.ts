import { create } from "zustand";
import type { CreateClubInput, ScreenId } from "./types";
import { Game } from "./game";
import { clearSave, hasSave } from "./save";

type Speed = 1 | 2;

interface GameStore {
  ready: boolean;
  hasSave: boolean;
  game: Game | null;
  screen: ScreenId;
  tick: number;
  selectedId: string | null;
  swapFrom: string | null;
  toast: string | null;
  speed: Speed;
  bidPlayer: string | null;
  hydrate: () => void;
  bump: () => void;
  flash: (msg: string) => void;
  startClub: (name: string, manager: string) => void;
  createClub: (input: CreateClubInput) => void;
  continueSave: () => void;
  newGame: () => void;
  setScreen: (s: ScreenId) => void;
  setSelected: (id: string | null) => void;
  setSwapFrom: (id: string | null) => void;
  setSpeed: (s: Speed) => void;
  setBidPlayer: (id: string | null) => void;
}

export const useGame = create<GameStore>((set, get) => ({
  ready: false,
  hasSave: false,
  game: null,
  screen: "match",
  tick: 0,
  selectedId: null,
  swapFrom: null,
  toast: null,
  speed: 1,
  bidPlayer: null,
  hydrate: () => {
    set({ ready: true, hasSave: hasSave(), game: Game.fromSave() });
  },
  bump: () => set({ tick: get().tick + 1, game: get().game }),
  flash: (msg) => {
    set({ toast: msg });
    window.setTimeout(() => {
      if (get().toast === msg) set({ toast: null });
    }, 2400);
  },
  startClub: (name, manager) => {
    const game = Game.newCareer(name, manager);
    set({ game, screen: "match", hasSave: true, tick: get().tick + 1 });
  },
  createClub: (input) => {
    const game = Game.createClub(input);
    set({ game, screen: "match", hasSave: true, tick: get().tick + 1 });
  },
  continueSave: () => {
    const game = Game.fromSave();
    if (game) set({ game, screen: "match", hasSave: true });
  },
  newGame: () => {
    clearSave();
    set({ game: null, hasSave: false, screen: "match" });
  },
  setScreen: (screen) => set({ screen, selectedId: null, swapFrom: null }),
  setSelected: (selectedId) => set({ selectedId }),
  setSwapFrom: (swapFrom) => set({ swapFrom }),
  setSpeed: (speed) => set({ speed }),
  setBidPlayer: (bidPlayer) => set({ bidPlayer }),
}));
