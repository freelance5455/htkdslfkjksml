import { makePlayer, playerValue, playerWage } from "./player";
import { RNG } from "./rng";
import type { ClubState, GameState, PlayerData, Position } from "./types";

const POS: Position[] = ["GK", "CB", "LB", "RB", "CDM", "CM", "CAM", "LW", "RW", "ST"];

export class YouthAcademy {
  intake(state: GameState, rng: RNG, club: ClubState): PlayerData[] {
    const n = club.academy >= 5 ? 3 : club.academy >= 3 ? 2 : 1;
    const born: PlayerData[] = [];
    for (let i = 0; i < n; i++) {
      const pos = rng.pick(POS);
      const ovr = 48 + club.academy * 3 + rng.int(0, 6);
      const p = makePlayer(rng, club.id, club.country, pos, ovr, "youth", `p_${state.uid++}`);
      p.regen = true;
      p.pot = Math.min(93, ovr + 8 + club.academy * 3 + rng.int(0, 6));
      p.value = playerValue(p.ovr, p.age, p.pot);
      p.wage = playerWage(p.ovr, p.age);
      p.name = p.name + " Jr.";
      state.players[p.id] = p;
      born.push(p);
    }
    return born;
  }
}
