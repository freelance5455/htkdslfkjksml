import type { Personality, Pos } from "./types";

export const SAVE_VERSION = 25;
export const SAVE_PREFIX = "fc_career_";
export const SOUND_KEY = "fc_sound";
export const LANG_KEY = "fc_lang";

export const POSITIONS: { id: Pos; tr: string; group: string }[] = [
  { id: "GK", tr: "Kaleci", group: "Kaleci" },
  { id: "RB", tr: "Sag Bek", group: "Defans" },
  { id: "RWB", tr: "Sag Kanat Bek", group: "Defans" },
  { id: "CB", tr: "Stoper", group: "Defans" },
  { id: "LB", tr: "Sol Bek", group: "Defans" },
  { id: "LWB", tr: "Sol Kanat Bek", group: "Defans" },
  { id: "CDM", tr: "Defansif Orta Saha", group: "Orta" },
  { id: "CM", tr: "Merkez Orta Saha", group: "Orta" },
  { id: "CAM", tr: "Ofansif Orta Saha", group: "Orta" },
  { id: "RM", tr: "Sag Kanat Orta", group: "Orta" },
  { id: "LM", tr: "Sol Kanat Orta", group: "Orta" },
  { id: "RW", tr: "Sag Kanat", group: "Hucum" },
  { id: "LW", tr: "Sol Kanat", group: "Hucum" },
  { id: "CF", tr: "Geri Cekilmis Forvet", group: "Hucum" },
  { id: "ST", tr: "Santrafor", group: "Hucum" },
];

export const POS_TR: Record<Pos, string> = Object.fromEntries(
  POSITIONS.map((p) => [p.id, p.tr]),
) as Record<Pos, string>;

export const COUNTRIES: { id: string; name: string; flag: string }[] = [
  { id: "ENG", name: "England", flag: "ENG" },
  { id: "ESP", name: "Spain", flag: "ESP" },
  { id: "FRA", name: "France", flag: "FRA" },
  { id: "GER", name: "Germany", flag: "GER" },
  { id: "ITA", name: "Italy", flag: "ITA" },
  { id: "NED", name: "Netherlands", flag: "NED" },
  { id: "POR", name: "Portugal", flag: "POR" },
  { id: "BRA", name: "Brazil", flag: "BRA" },
  { id: "ARG", name: "Argentina", flag: "ARG" },
  { id: "TUR", name: "Turkiye", flag: "TUR" },
  { id: "AZE", name: "Azerbaijan", flag: "AZE" },
  { id: "BEL", name: "Belgium", flag: "BEL" },
  { id: "CRO", name: "Croatia", flag: "CRO" },
  { id: "DEN", name: "Denmark", flag: "DEN" },
  { id: "SWE", name: "Sweden", flag: "SWE" },
  { id: "NOR", name: "Norway", flag: "NOR" },
  { id: "POL", name: "Poland", flag: "POL" },
  { id: "JPN", name: "Japan", flag: "JPN" },
  { id: "KOR", name: "Korea", flag: "KOR" },
  { id: "USA", name: "USA", flag: "USA" },
  { id: "MEX", name: "Mexico", flag: "MEX" },
  { id: "MAR", name: "Morocco", flag: "MAR" },
  { id: "SEN", name: "Senegal", flag: "SEN" },
  { id: "NGA", name: "Nigeria", flag: "NGA" },
  { id: "GHA", name: "Ghana", flag: "GHA" },
];

export const COUNTRY_NAME: Record<string, string> = Object.fromEntries(
  COUNTRIES.map((c) => [c.id, c.name]),
);

export const ATTRIBUTE_GROUPS: { id: string; tr: string; keys: { key: string; tr: string }[] }[] = [
  {
    id: "phy",
    tr: "Fiziksel",
    keys: [
      { key: "pace", tr: "Hiz" },
      { key: "acceleration", tr: "Ivme" },
      { key: "agility", tr: "Ceviklik" },
      { key: "balance", tr: "Denge" },
      { key: "jumping", tr: "Sicrama" },
      { key: "stamina", tr: "Dayaniklilik" },
      { key: "strength", tr: "Guc" },
      { key: "reactions", tr: "Reaksiyon" },
    ],
  },
  {
    id: "tec",
    tr: "Teknik",
    keys: [
      { key: "ballControl", tr: "Top Kontrolu" },
      { key: "dribbling", tr: "Dribling" },
      { key: "firstTouch", tr: "Ilk Dokunus" },
      { key: "passing", tr: "Pas" },
      { key: "crossing", tr: "Orta" },
      { key: "heading", tr: "Kafa" },
      { key: "longShots", tr: "Uzaktan Sut" },
      { key: "volleys", tr: "Vole" },
      { key: "curve", tr: "Falso" },
      { key: "freeKick", tr: "Serbest Vurus" },
      { key: "penalties", tr: "Penalti" },
      { key: "longPassing", tr: "Uzun Pas" },
    ],
  },
  {
    id: "men",
    tr: "Zihinsel",
    keys: [
      { key: "vision", tr: "Gorus" },
      { key: "composure", tr: "Sogukkanlilik" },
      { key: "decisions", tr: "Karar" },
      { key: "concentration", tr: "Konsantrasyon" },
      { key: "aggression", tr: "Agresiflik" },
      { key: "workRate", tr: "Is Bitirme" },
      { key: "teamwork", tr: "Takim Oyunu" },
      { key: "leadership", tr: "Liderlik" },
      { key: "flair", tr: "Yetenek Gosterisi" },
    ],
  },
  {
    id: "def",
    tr: "Defans",
    keys: [
      { key: "tackling", tr: "Mudahale" },
      { key: "standingTackle", tr: "Ayakta Mudahale" },
      { key: "slidingTackle", tr: "Kayarak Mudahale" },
      { key: "interceptions", tr: "Top Kesme" },
      { key: "marking", tr: "Markaj" },
      { key: "defensiveAwareness", tr: "Defansif Farkindalik" },
    ],
  },
  {
    id: "att",
    tr: "Hucum",
    keys: [
      { key: "finishing", tr: "Bitiricilik" },
      { key: "shotPower", tr: "Sut Gucu" },
      { key: "offTheBall", tr: "Topsuz Kosu" },
      { key: "attackPosition", tr: "Hucum Pozisyonu" },
      { key: "weakFoot", tr: "Zayif Ayak" },
    ],
  },
  {
    id: "gk",
    tr: "Kalecilik",
    keys: [
      { key: "gkDiving", tr: "Kurtaris" },
      { key: "gkHandling", tr: "Top Tutma" },
      { key: "gkKicking", tr: "Uzaklastirma" },
      { key: "gkReflexes", tr: "Refleks" },
      { key: "gkPositioning", tr: "Kaleci Pozisyonu" },
    ],
  },
];

export const ALL_ATTRS = ATTRIBUTE_GROUPS.flatMap((g) => g.keys.map((k) => k.key));

export const ALLOC_ATTRS = [
  "pace",
  "acceleration",
  "agility",
  "stamina",
  "strength",
  "jumping",
  "ballControl",
  "dribbling",
  "passing",
  "finishing",
  "firstTouch",
  "crossing",
  "shotPower",
  "heading",
  "vision",
  "composure",
  "decisions",
  "concentration",
  "workRate",
  "tackling",
  "interceptions",
  "marking",
  "defensiveAwareness",
  "standingTackle",
];

export const ATTR_TR: Record<string, string> = Object.fromEntries(
  ATTRIBUTE_GROUPS.flatMap((g) => g.keys.map((k) => [k.key, k.tr])),
);

export const POS_WEIGHTS: Record<Pos, Record<string, number>> = {
  GK: { gkDiving: 5, gkHandling: 5, gkReflexes: 5, gkPositioning: 4, gkKicking: 2, reactions: 3, composure: 2 },
  CB: { marking: 4, tackling: 4, heading: 3, strength: 3, defensiveAwareness: 4, jumping: 2, composure: 2, passing: 1 },
  RB: { pace: 3, stamina: 3, tackling: 3, crossing: 2, defensiveAwareness: 3, marking: 2, passing: 2, acceleration: 2 },
  LB: { pace: 3, stamina: 3, tackling: 3, crossing: 2, defensiveAwareness: 3, marking: 2, passing: 2, acceleration: 2 },
  RWB: { pace: 4, stamina: 4, crossing: 3, dribbling: 2, tackling: 2, passing: 2, acceleration: 2 },
  LWB: { pace: 4, stamina: 4, crossing: 3, dribbling: 2, tackling: 2, passing: 2, acceleration: 2 },
  CDM: { tackling: 4, interceptions: 4, passing: 3, stamina: 3, defensiveAwareness: 3, strength: 2, decisions: 2, marking: 2 },
  CM: { passing: 4, stamina: 3, vision: 3, ballControl: 3, decisions: 3, tackling: 2, longPassing: 2, workRate: 2 },
  CAM: { vision: 4, passing: 4, ballControl: 3, dribbling: 3, finishing: 2, composure: 2, flair: 2, longShots: 2 },
  RM: { pace: 4, crossing: 3, dribbling: 3, passing: 3, stamina: 3, acceleration: 2, ballControl: 2 },
  LM: { pace: 4, crossing: 3, dribbling: 3, passing: 3, stamina: 3, acceleration: 2, ballControl: 2 },
  RW: { pace: 4, dribbling: 4, finishing: 3, crossing: 3, acceleration: 3, ballControl: 2, flair: 2 },
  LW: { pace: 4, dribbling: 4, finishing: 3, crossing: 3, acceleration: 3, ballControl: 2, flair: 2 },
  CF: { finishing: 4, ballControl: 3, vision: 3, offTheBall: 3, passing: 3, dribbling: 2, composure: 2, shotPower: 2 },
  ST: { finishing: 5, shotPower: 4, offTheBall: 4, attackPosition: 3, heading: 3, pace: 3, composure: 2, strength: 2 },
};

export const ARCHETYPES: { id: string; tr: string; pos: Pos[] }[] = [
  { id: "box", tr: "Kutu Kutuya Orta Saha", pos: ["CM", "CDM"] },
  { id: "play", tr: "Oyun Kurucu", pos: ["CAM", "CM"] },
  { id: "winger", tr: "Kanat Oyuncusu", pos: ["LW", "RW", "LM", "RM"] },
  { id: "inside", tr: "Ic Forvet", pos: ["LW", "RW", "CF"] },
  { id: "target", tr: "Pivot Forvet", pos: ["ST", "CF"] },
  { id: "poacher", tr: "Golcu", pos: ["ST", "CF"] },
  { id: "press", tr: "Pres Forveti", pos: ["ST", "CF", "LW", "RW"] },
  { id: "destroyer", tr: "Top Kapici", pos: ["CDM", "CM"] },
  { id: "deep", tr: "Derin Oyun Kurucu", pos: ["CDM", "CM"] },
  { id: "wingback", tr: "Ofansif Bek", pos: ["LB", "RB", "LWB", "RWB"] },
  { id: "stopper", tr: "Kesici Stoper", pos: ["CB"] },
  { id: "sweeper", tr: "Supurucu Kaleci", pos: ["GK"] },
];

export const PERSONALITIES: { id: Personality; tr: string }[] = [
  { id: "professional", tr: "Profesyonel" },
  { id: "ambitious", tr: "Hirslı" },
  { id: "loyal", tr: "Sadik" },
  { id: "fiery", tr: "Atesli" },
  { id: "calm", tr: "Sakin" },
  { id: "determined", tr: "Kararli" },
];

export const TRAINING_FOCI: { id: string; tr: string; attrs: string[] }[] = [
  { id: "balanced", tr: "Dengeli", attrs: ["ballControl", "passing", "decisions", "stamina"] },
  { id: "attack", tr: "Hucum", attrs: ["finishing", "shotPower", "offTheBall", "dribbling"] },
  { id: "defense", tr: "Defans", attrs: ["tackling", "interceptions", "marking", "defensiveAwareness"] },
  { id: "physical", tr: "Fiziksel", attrs: ["strength", "stamina", "pace", "jumping"] },
  { id: "tech", tr: "Teknik", attrs: ["dribbling", "ballControl", "firstTouch", "passing"] },
  { id: "mental", tr: "Zihinsel", attrs: ["vision", "composure", "decisions", "concentration"] },
  { id: "recover", tr: "Toparlanma", attrs: [] },
];

export const INTENSITY: Record<"low" | "mid" | "high", { tr: string; mult: number; fatigue: number }> = {
  low: { tr: "Dusuk", mult: 0.6, fatigue: 8 },
  mid: { tr: "Orta", mult: 1, fatigue: 18 },
  high: { tr: "Yuksek", mult: 1.6, fatigue: 30 },
};

export const HOMES = [
  { id: 0, tr: "Kiralik Daire", cost: 0 },
  { id: 1, tr: "Sehir Dairesi", cost: 250_000 },
  { id: 2, tr: "Banliyo Evi", cost: 800_000 },
  { id: 3, tr: "Luks Malikane", cost: 3_000_000 },
];

export const CARS = [
  { id: 0, tr: "Araba Yok", cost: 0 },
  { id: 1, tr: "Ikinci El", cost: 8_000 },
  { id: 2, tr: "Spor Araba", cost: 90_000 },
  { id: 3, tr: "Luks Sedan", cost: 250_000 },
  { id: 4, tr: "Super Spor Koleksiyon", cost: 1_500_000 },
];

export const ACHIEVEMENTS: { id: string; tr: string; desc: string }[] = [
  { id: "first_match", tr: "Ilk Mac", desc: "Ilk macina cik" },
  { id: "first_goal", tr: "Ilk Gol", desc: "Ilk golunu at" },
  { id: "first_post", tr: "Ilk Paylasim", desc: "Sosyal paylasim yap" },
  { id: "1k", tr: "1K Takipci", desc: "1000 takipciye ulas" },
  { id: "verified", tr: "Dogrulanmis", desc: "10.000 takipciye ulas" },
  { id: "motm", tr: "Macin Adami", desc: "MOTM ol" },
  { id: "first_dm", tr: "Sosyal Kelebek", desc: "Ilk DM'ini gonder" },
  { id: "story", tr: "Hikaye Anlaticisi", desc: "Hikaye paylas" },
  { id: "married", tr: "Aile Babasi", desc: "Evlen" },
  { id: "mansion", tr: "Luks Hayat", desc: "Malikane al" },
];

export const SCENES = [
  { id: "goal", tr: "GOL" },
  { id: "train", tr: "Antrenman" },
  { id: "matchday", tr: "Mac Gunu" },
  { id: "team", tr: "Takim" },
  { id: "life", tr: "Yasam" },
  { id: "deal", tr: "Anlasma" },
  { id: "cup", tr: "Kupa" },
  { id: "sign", tr: "Imza" },
  { id: "press", tr: "Basin" },
];

export function attrCost(from: number, to: number): number {
  if (to <= from) return 0;
  let c = 0;
  for (let v = from; v < to; v++) {
    if (v < 65) c += 1;
    else if (v < 75) c += 2;
    else if (v < 85) c += 3;
    else c += 5;
  }
  return c;
}

export function attrRefund(from: number, to: number): number {
  return attrCost(to, from);
}
