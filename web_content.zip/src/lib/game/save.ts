import { SAVE_BACKUP_KEY, SAVE_KEY, SAVE_VERSION, type GameState } from "./types";

export function persist(state: GameState): boolean {
  try {
    const prev = localStorage.getItem(SAVE_KEY);
    if (prev) localStorage.setItem(SAVE_BACKUP_KEY, prev);
    localStorage.setItem(SAVE_KEY, JSON.stringify(state));
    return true;
  } catch {
    return false;
  }
}

export function readSave(): GameState | null {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as GameState;
    if (!parsed || typeof parsed !== "object") return null;
    if (parsed.version !== SAVE_VERSION) return migrate(parsed);
    return parsed;
  } catch {
    try {
      const bak = localStorage.getItem(SAVE_BACKUP_KEY);
      if (!bak) return null;
      return JSON.parse(bak) as GameState;
    } catch {
      return null;
    }
  }
}

export function clearSave() {
  try {
    localStorage.removeItem(SAVE_KEY);
  } catch {
    /* ignore */
  }
}

function migrate(s: GameState): GameState {
  s.version = SAVE_VERSION;
  return s;
}

export function hasSave(): boolean {
  try {
    return !!localStorage.getItem(SAVE_KEY);
  } catch {
    return false;
  }
}
