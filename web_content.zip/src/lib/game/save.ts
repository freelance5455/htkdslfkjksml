import { SAVE_PREFIX, SAVE_VERSION } from "./constants";
import type { CareerState, SaveSlotMeta } from "./types";

export function slotKey(slot: number): string {
  return SAVE_PREFIX + slot;
}

export function listSlots(): SaveSlotMeta[] {
  return [0, 1, 2].map((slot) => {
    const raw = safeGet(slotKey(slot));
    if (!raw) return { slot, occupied: false };
    try {
      const parsed = JSON.parse(raw) as { version?: number; state?: CareerState };
      const s = parsed.state;
      if (!s?.player) return { slot, occupied: false };
      return {
        slot,
        occupied: true,
        name: s.player.displayName,
        club: s.clubId,
        ovr: s.player.overall,
        week: s.week,
        season: s.season,
      };
    } catch {
      return { slot, occupied: false };
    }
  });
}

export function loadSlot(slot: number): CareerState | null {
  const raw = safeGet(slotKey(slot));
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw) as { version?: number; state?: CareerState };
    const s = parsed.state;
    if (!s?.player) return null;
    s.slot = slot;
    s.version = SAVE_VERSION;
    return s;
  } catch {
    return null;
  }
}

export function saveSlot(state: CareerState): boolean {
  const payload = JSON.stringify({ slot: state.slot, version: SAVE_VERSION, state });
  try {
    localStorage.setItem(slotKey(state.slot), payload);
    return true;
  } catch {
    return false;
  }
}

export function clearSlot(slot: number) {
  try {
    localStorage.removeItem(slotKey(slot));
  } catch {
    /* ignore */
  }
}

function safeGet(key: string): string | null {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}
