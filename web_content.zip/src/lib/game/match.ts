import { FORMATIONS } from "./data";
import { clamp } from "./format";
import { InjuryManager } from "./injury";
import { applyXp } from "./player";
import { RNG } from "./rng";
import { chemistry } from "./team";
import type {
  ClubState,
  GameState,
  LiveMatch,
  MatchEvent,
  PlayerData,
  SideStats,
  Tactics,
} from "./types";

function emptyStats(): SideStats {
  return {
    shots: 0,
    onTarget: 0,
    possession: 50,
    fouls: 0,
    corners: 0,
    yellows: 0,
    reds: 0,
    xg: 0,
  };
}

export function tacticMod(a: Tactics, b: Tactics): number {
  let m = 1;
  if (a.style === "counter" && b.press === "high") m += 0.07;
  if (a.style === "short" && b.press === "low") m += 0.05;
  if (a.style === "long" && b.press === "mid") m += 0.03;
  if (a.press === "high" && b.style === "short") m += 0.04;
  if (a.mentality === "attacking") m += 0.04;
  if (a.mentality === "defensive") m -= 0.03;
  if (a.press === "high") m += 0.02;
  return m;
}

export function sideStrength(
  club: ClubState,
  players: Record<string, PlayerData>,
  xi: string[],
  opp: Tactics,
  home: boolean,
): number {
  const slots = FORMATIONS[club.tactics.formation]?.slots ?? FORMATIONS["4-3-3"]!.slots;
  let sum = 0;
  let n = 0;
  xi.forEach((id, i) => {
    const p = players[id];
    if (!p || p.inj || p.ban > 0) return;
    let r = p.ovr;
    if (p.pos !== slots[i]) r *= 0.8;
    r *= 0.74 + p.energy / 250;
    r *= 0.9 + p.form / 500;
    r *= 0.92 + p.morale / 600;
    sum += r;
    n += 1;
  });
  let avg = n ? sum / n : 55;
  avg *= 0.94 + chemistry(club, players) * 0.08;
  avg *= 0.96 + club.morale / 1400;
  avg *= tacticMod(club.tactics, opp);
  if (home) avg *= 1.07;
  return avg;
}

const BUILD = [
  "orta sahada topu çeviriyor.",
  "sağ kanattan bindirme yaptı.",
  "derinlemesine bir pas denedi.",
  "presle topu kazandı.",
  "korner kazandı.",
  "ceza sahası yayında toplandı.",
];
const MISS = [
  "şut! Kaleci kurtardı.",
  "kafa vuruşu auta gidiyor.",
  "uzak mesafeden denedi, dışarı.",
  "kaçan fırsat! Kaleciye takıldı.",
  "direkten döndü!",
  "son anda savundu.",
];

export class MatchEngine {
  injuries = new InjuryManager();

  createLive(
    state: GameState,
    fixtureId: string,
    rng: RNG,
  ): LiveMatch {
    const fx = state.fixtures.find((f) => f.id === fixtureId)!;
    const home = state.clubs[fx.homeId]!;
    const away = state.clubs[fx.awayId]!;
    return {
      fixtureId,
      homeId: home.id,
      awayId: away.id,
      minute: 0,
      stoppage: rng.int(1, 4),
      homeGoals: 0,
      awayGoals: 0,
      events: [
        {
          minute: 0,
          kind: "text",
          text: `Hakem düdüğü çaldı. ${home.name} — ${away.name} başlıyor.`,
        },
      ],
      stats: { home: emptyStats(), away: emptyStats() },
      phase: "first",
      homeXI: home.xi.slice(),
      awayXI: away.xi.slice(),
      homeBench: home.bench.slice(),
      awayBench: away.bench.slice(),
      subsUsed: 0,
      comp: fx.comp,
      round: fx.round,
      scorers: [],
    };
  }

  push(live: LiveMatch, ev: MatchEvent) {
    live.events.unshift(ev);
    if (live.events.length > 80) live.events.length = 80;
  }

  onField(live: LiveMatch, side: "home" | "away"): string[] {
    return side === "home" ? live.homeXI : live.awayXI;
  }

  pickAttacker(
    state: GameState,
    ids: string[],
    rng: RNG,
  ): PlayerData | undefined {
    const atk = ids
      .map((id) => state.players[id])
      .filter((p): p is PlayerData => !!p && !p.inj);
    const fw = atk.filter((p) => ["ST", "LW", "RW", "CAM"].includes(p.pos));
    const pool = fw.length ? fw : atk;
    if (!pool.length) return undefined;
    const w = pool.map((p) => p.ovr * p.ovr);
    let t = w.reduce((s, x) => s + x, 0);
    let r = rng.float(0, t);
    for (let i = 0; i < pool.length; i++) {
      r -= w[i]!;
      if (r <= 0) return pool[i];
    }
    return pool[0];
  }

  stepMinute(state: GameState, live: LiveMatch, rng: RNG): void {
    if (live.phase === "ht" || live.phase === "ft") return;
    live.minute += 1;
    const end = live.phase === "first" ? 45 : 90 + live.stoppage;
    if (live.phase === "first" && live.minute === 45) {
      this.push(live, {
        minute: 45,
        kind: "ht",
        text: `İlk yarı sona erdi. ${this.scoreLine(state, live)}`,
      });
      live.phase = "ht";
      return;
    }
    if (live.phase === "second" && live.minute >= end) {
      this.finish(state, live, rng);
      return;
    }

    const home = state.clubs[live.homeId]!;
    const away = state.clubs[live.awayId]!;
    const hs = sideStrength(home, state.players, live.homeXI, away.tactics, true);
    const as = sideStrength(away, state.players, live.awayXI, home.tactics, false);
    const tot = hs + as;
    live.stats.home.possession = Math.round((hs / tot) * 100);
    live.stats.away.possession = 100 - live.stats.home.possession;

    this.drain(state, live);

    if (rng.chance(0.07)) {
      const side: "home" | "away" = rng.chance(hs / tot) ? "home" : "away";
      const club = side === "home" ? home : away;
      this.push(live, {
        minute: live.minute,
        kind: "text",
        side,
        text: `${live.minute}' ${club.name} ${rng.pick(BUILD)}`,
      });
    }

    const chanceP = 0.105;
    if (rng.chance(chanceP)) {
      const attackHome = rng.chance(hs / tot);
      this.resolveChance(state, live, rng, attackHome ? "home" : "away", hs, as);
    }

    if (rng.chance(0.028)) this.resolveFoul(state, live, rng);
    this.resolveInjury(state, live, rng);
  }

  resolveChance(
    state: GameState,
    live: LiveMatch,
    rng: RNG,
    side: "home" | "away",
    hs: number,
    as: number,
  ) {
    const atk = side === "home" ? hs : as;
    const def = side === "home" ? as : hs;
    const stats = side === "home" ? live.stats.home : live.stats.away;
    const club = state.clubs[side === "home" ? live.homeId : live.awayId]!;
    const p = this.pickAttacker(state, this.onField(live, side), rng);
    stats.shots += 1;
    const xg = clamp(0.06 + (atk - def) / 220 + rng.float(0, 0.12), 0.04, 0.42);
    stats.xg += xg;
    const onT = rng.chance(0.38 + xg);
    if (onT) stats.onTarget += 1;
    if (rng.chance(0.22)) stats.corners += 1;
    if (onT && rng.chance(xg * 1.35)) {
      if (side === "home") live.homeGoals += 1;
      else live.awayGoals += 1;
      if (p) {
        p.goals += 1;
        p.form = clamp(p.form + 6, 0, 100);
        p.morale = clamp(p.morale + 4, 0, 100);
      }
      live.scorers.push({
        minute: live.minute,
        name: p?.name ?? club.short,
        side,
      });
      this.push(live, {
        minute: live.minute,
        kind: "goal",
        side,
        playerId: p?.id,
        playerName: p?.name,
        text: `${live.minute}' GOL! ${p?.name ?? club.name} ağları havalandırdı. ${this.scoreLine(state, live)}`,
      });
    } else {
      this.push(live, {
        minute: live.minute,
        kind: "chance",
        side,
        playerId: p?.id,
        playerName: p?.name,
        text: `${live.minute}' ${p?.name ?? club.name} ${rng.pick(MISS)}`,
      });
    }
  }

  resolveFoul(state: GameState, live: LiveMatch, rng: RNG) {
    const side: "home" | "away" = rng.chance(0.5) ? "home" : "away";
    const ids = this.onField(live, side);
    const p = ids.map((id) => state.players[id]).filter((x): x is PlayerData => !!x && !x.inj);
    if (!p.length) return;
    const pl = rng.pick(p);
    const stats = side === "home" ? live.stats.home : live.stats.away;
    stats.fouls += 1;
    const already = pl.matchYellows > 0;
    if (rng.chance(already ? 0.22 : 0.08) || rng.chance(0.035)) {
      const secondYellow = already && rng.chance(0.55);
      const straightRed = !secondYellow && rng.chance(0.18);
      if (straightRed || secondYellow) {
        pl.matchYellows = 0;
        pl.ban = straightRed ? 2 : 1;
        if (live.comp === "league") pl.yellows = 0;
        stats.reds += 1;
        this.sendOff(live, side, pl.id);
        this.push(live, {
          minute: live.minute,
          kind: "red",
          side,
          playerId: pl.id,
          playerName: pl.name,
          text: `${live.minute}' KIRMIZI! ${pl.name} ${secondYellow ? "ikinci sarıdan" : "doğrudan"} oyun dışı. ${straightRed ? "2" : "1"} maç ceza.`,
        });
      } else {
        pl.matchYellows += 1;
        if (live.comp === "league") {
          pl.yellows += 1;
          if (pl.yellows >= 4) {
            pl.ban = Math.max(pl.ban, 1);
            pl.yellows = 0;
          }
        }
        stats.yellows += 1;
        this.push(live, {
          minute: live.minute,
          kind: "yellow",
          side,
          playerId: pl.id,
          playerName: pl.name,
          text: `${live.minute}' Sarı kart. ${pl.name} defterine yazıldı.${pl.ban ? " 4 sarı — 1 maç ceza." : ""}`,
        });
      }
    }
  }

  sendOff(live: LiveMatch, side: "home" | "away", id: string) {
    const xi = this.onField(live, side);
    const i = xi.indexOf(id);
    if (i >= 0) xi.splice(i, 1);
  }

  resolveInjury(state: GameState, live: LiveMatch, rng: RNG) {
    const userId = state.clubId;
    for (const side of ["home", "away"] as const) {
      const clubId = side === "home" ? live.homeId : live.awayId;
      const club = state.clubs[clubId]!;
      const ids = this.onField(live, side).slice();
      for (const id of ids) {
        const p = state.players[id];
        if (!p) continue;
        const inj = this.injuries.rollDuringMatch(p, rng);
        if (!inj) continue;
        p.inj = inj;
        p.energy = Math.max(10, p.energy - 25);
        const bench = side === "home" ? live.homeBench : live.awayBench;
        const sub = bench
          .map((bid) => state.players[bid])
          .filter((x): x is PlayerData => !!x && !x.inj && x.ban <= 0)
          .sort((a, b) => b.ovr - a.ovr)[0];
        let extra = `${inj.label} (${inj.weeksLeft} hf).`;
        if (sub && live.subsUsed < 5) {
          const xi = this.onField(live, side);
          const idx = xi.indexOf(id);
          if (idx >= 0) xi[idx] = sub.id;
          const bi = bench.indexOf(sub.id);
          if (bi >= 0) bench.splice(bi, 1);
          if (clubId === userId) live.subsUsed += 1;
          extra += ` ${sub.name} oyuna giriyor.`;
        } else {
          this.sendOff(live, side, id);
          extra += " Yerine kimse giremedi.";
        }
        this.push(live, {
          minute: live.minute,
          kind: "injury",
          side,
          playerId: p.id,
          playerName: p.name,
          text: `${live.minute}' Sakatlık! ${p.name} yerde kaldı. ${extra}`,
        });
        return;
      }
    }
  }

  drain(state: GameState, live: LiveMatch) {
    for (const id of [...live.homeXI, ...live.awayXI]) {
      const p = state.players[id];
      if (p) p.energy = Math.max(12, p.energy - (p.age >= 33 ? 0.28 : 0.2));
    }
  }

  scoreLine(state: GameState, live: LiveMatch): string {
    const h = state.clubs[live.homeId]!.short;
    const a = state.clubs[live.awayId]!.short;
    return `${h} ${live.homeGoals}–${live.awayGoals} ${a}`;
  }

  startSecondHalf(live: LiveMatch) {
    if (live.phase !== "ht") return;
    live.phase = "second";
    live.stoppage = 2 + Math.floor(Math.random() * 4);
    this.push(live, {
      minute: 45,
      kind: "text",
      text: "İkinci yarı başladı.",
    });
  }

  sub(
    state: GameState,
    live: LiveMatch,
    outId: string,
    inId: string,
  ): string | null {
    if (live.phase === "ft") return "Maç bitti.";
    const userIsHome = live.homeId === state.clubId;
    const xi = userIsHome ? live.homeXI : live.awayXI;
    const bench = userIsHome ? live.homeBench : live.awayBench;
    if (live.subsUsed >= 5) return "Beş değişiklik hakkınız doldu.";
    const oi = xi.indexOf(outId);
    const ii = bench.indexOf(inId);
    if (oi < 0 || ii < 0) return "Geçersiz değişiklik.";
    const outP = state.players[outId];
    const inP = state.players[inId];
    if (!inP || inP.inj || inP.ban > 0) return "Oyuncu maça çıkamaz.";
    xi[oi] = inId;
    bench[ii] = outId;
    live.subsUsed += 1;
    this.push(live, {
      minute: live.minute,
      kind: "sub",
      side: userIsHome ? "home" : "away",
      text: `${live.minute}' Değişiklik: ${outP?.name} çıkıyor, ${inP.name} giriyor.`,
    });
    return null;
  }

  finish(state: GameState, live: LiveMatch, rng: RNG) {
    live.phase = "ft";
    this.push(live, {
      minute: live.minute,
      kind: "ft",
      text: `Maç bitti. ${this.scoreLine(state, live)}`,
    });
    this.applyResult(state, live, rng, true);
  }

  applyResult(state: GameState, live: LiveMatch, rng: RNG, userMatch: boolean) {
    const fx = state.fixtures.find((f) => f.id === live.fixtureId);
    if (fx) {
      fx.played = true;
      fx.homeGoals = live.homeGoals;
      fx.awayGoals = live.awayGoals;
    }
    const home = state.clubs[live.homeId]!;
    const away = state.clubs[live.awayId]!;
    this.table(home, away, live.homeGoals, live.awayGoals, live.comp);
    this.postPlayers(state, live, rng, "home", userMatch);
    this.postPlayers(state, live, rng, "away", userMatch);
    this.morale(home, away, live.homeGoals, live.awayGoals);
  }

  table(home: ClubState, away: ClubState, hg: number, ag: number, comp: string) {
    if (comp !== "league") return;
    home.pld += 1;
    away.pld += 1;
    home.gf += hg;
    home.ga += ag;
    away.gf += ag;
    away.ga += hg;
    if (hg > ag) {
      home.w += 1;
      home.pts += 3;
      away.l += 1;
    } else if (ag > hg) {
      away.w += 1;
      away.pts += 3;
      home.l += 1;
    } else {
      home.d += 1;
      away.d += 1;
      home.pts += 1;
      away.pts += 1;
    }
  }

  morale(home: ClubState, away: ClubState, hg: number, ag: number) {
    if (hg > ag) {
      home.morale = clamp(home.morale + 6, 20, 100);
      away.morale = clamp(away.morale - 5, 20, 100);
    } else if (ag > hg) {
      away.morale = clamp(away.morale + 6, 20, 100);
      home.morale = clamp(home.morale - 5, 20, 100);
    } else {
      home.morale = clamp(home.morale + 1, 20, 100);
      away.morale = clamp(away.morale + 1, 20, 100);
    }
  }

  postPlayers(
    state: GameState,
    live: LiveMatch,
    rng: RNG,
    side: "home" | "away",
    userMatch: boolean,
  ) {
    const ids = this.onField(live, side);
    const hg = live.homeGoals;
    const ag = live.awayGoals;
    const won =
      (side === "home" && hg > ag) || (side === "away" && ag > hg);
    const draw = hg === ag;
    const matchPts = won ? 3 : draw ? 1 : 0;
    for (const id of ids) {
      const p = state.players[id];
      if (!p) continue;
      p.apps += 1;
      p.matchYellows = 0;
      const rating = clamp(
        6.2 + (won ? 0.6 : draw ? 0.2 : -0.2) + rng.float(-0.4, 0.8),
        5.2,
        9.4,
      );
      p.ratingSum += rating;
      p.form = clamp(p.form + (won ? 3 : draw ? 0 : -2), 20, 100);
      p.morale = clamp(p.morale + (won ? 2 : draw ? 0 : -2), 20, 100);
      p.energy = clamp(p.energy - rng.int(8, 16), 12, 100);
      if (userMatch || p.clubId === state.clubId) applyXp(p, matchPts + rating / 8);
    }
  }

  simQuiet(state: GameState, fixtureId: string, rng: RNG): void {
    const fx = state.fixtures.find((f) => f.id === fixtureId);
    if (!fx || fx.played) return;
    const home = state.clubs[fx.homeId]!;
    const away = state.clubs[fx.awayId]!;
    const hs = sideStrength(home, state.players, home.xi, away.tactics, true);
    const as = sideStrength(away, state.players, away.xi, home.tactics, false);
    const hg = this.poisson(rng, clamp(1.05 + (hs - as) / 28, 0.25, 3.6));
    const ag = this.poisson(rng, clamp(0.9 + (as - hs) / 30, 0.2, 3.2));
    const live: LiveMatch = {
      fixtureId,
      homeId: home.id,
      awayId: away.id,
      minute: 90,
      stoppage: 3,
      homeGoals: hg,
      awayGoals: ag,
      events: [],
      stats: { home: emptyStats(), away: emptyStats() },
      phase: "ft",
      homeXI: home.xi.slice(),
      awayXI: away.xi.slice(),
      homeBench: home.bench.slice(),
      awayBench: away.bench.slice(),
      subsUsed: 0,
      comp: fx.comp,
      round: fx.round,
      scorers: [],
    };
    this.maybeQuietCards(state, live, rng);
    this.applyResult(state, live, rng, false);
  }

  maybeQuietCards(state: GameState, live: LiveMatch, rng: RNG) {
    for (const id of [...live.homeXI, ...live.awayXI]) {
      const p = state.players[id];
      if (!p) continue;
      if (live.comp === "league" && rng.chance(0.12)) {
        p.yellows += 1;
        if (p.yellows >= 4) {
          p.ban = Math.max(p.ban, 1);
          p.yellows = 0;
        }
      }
      if (rng.chance(0.012)) p.ban = Math.max(p.ban, 2);
      const inj = this.injuries.rollDuringMatch(p, rng);
      if (inj) p.inj = inj;
    }
  }

  poisson(rng: RNG, lambda: number): number {
    const L = Math.exp(-lambda);
    let k = 0;
    let p = 1;
    do {
      k += 1;
      p *= rng.next();
    } while (p > L && k < 10);
    return k - 1;
  }
}
