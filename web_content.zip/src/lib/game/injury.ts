import { INJURY_TABLE } from "./data";
import { RNG } from "./rng";
import type { Injury, InjuryKind, PlayerData } from "./types";

const MEDICAL_REDUCTION = [0, 0, 0.1, 0.18, 0.26, 0.35];

export class InjuryManager {
  pickKind(rng: RNG): InjuryKind {
    const total = Object.values(INJURY_TABLE).reduce((s, x) => s + x.weight, 0);
    let roll = rng.float(0, total);
    for (const [kind, row] of Object.entries(INJURY_TABLE)) {
      roll -= row.weight;
      if (roll <= 0) return kind as InjuryKind;
    }
    return "muscle";
  }

  rollDuringMatch(player: PlayerData, rng: RNG): Injury | null {
    let p = 0.00115;
    if (player.energy < 70) p *= 1 + (70 - player.energy) / 16;
    if (player.energy < 50) p *= 1.85;
    if (player.age >= 33) p *= 1.25;
    if (!rng.chance(p)) return null;
    return this.create(this.pickKind(rng), rng, 1);
  }

  create(kind: InjuryKind, rng: RNG, medicalLevel: number): Injury {
    const row = INJURY_TABLE[kind]!;
    const base = rng.int(row.minW, row.maxW);
    const red = MEDICAL_REDUCTION[medicalLevel] ?? 0;
    const weeks = Math.max(1, Math.round(base * (1 - red)));
    return { kind, label: row.label, weeksLeft: weeks, originalWeeks: weeks };
  }

  tickWeek(players: PlayerData[], medicalLevel: number): PlayerData[] {
    const recovered: PlayerData[] = [];
    const red = MEDICAL_REDUCTION[medicalLevel] ?? 0;
    for (const p of players) {
      if (!p.inj) continue;
      const extra = red > 0 && Math.random() < red * 0.35 ? 1 : 0;
      p.inj.weeksLeft -= 1 + extra;
      if (p.inj.weeksLeft <= 0) {
        p.inj = null;
        p.energy = Math.min(100, p.energy + 18);
        recovered.push(p);
      }
    }
    return recovered;
  }
}
