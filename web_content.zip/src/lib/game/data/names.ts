export const NAMES: Record<string, { first: string[]; last: string[] }> = {
  ENG: {
    first: ["Jack", "Harry", "Mason", "Callum", "Jamie", "Oliver", "Noah", "Theo", "Reece", "Jude", "Cole", "Marcus", "Declan", "Bukayo", "Phil"],
    last: ["Walker", "Rice", "Palmer", "Foden", "Kane", "Sterling", "Mount", "James", "Shaw", "White", "Gordon", "Watkins", "Wilson", "Trippier", "Pope"],
  },
  ESP: {
    first: ["Carlos", "Pablo", "Diego", "Alvaro", "Sergio", "Iker", "Unai", "Mikel", "Pedri", "Ferran", "Dani", "Rodri", "Gavi", "Nico", "Aymeric"],
    last: ["Garcia", "Rodriguez", "Hernandez", "Gonzalez", "Fernandez", "Lopez", "Martinez", "Sanchez", "Perez", "Ruiz", "Diaz", "Moreno", "Alonso", "Navas", "Torres"],
  },
  FRA: {
    first: ["Hugo", "Kylian", "Antoine", "NGolo", "Paul", "Karim", "Ousmane", "Eduardo", "Aurelien", "Warren", "Randal", "Bradley", "Mike", "Theo", "Kingsley"],
    last: ["Mbappe", "Griezmann", "Kante", "Pogba", "Benzema", "Dembele", "Camavinga", "Tchouameni", "Zaire", "Kolo", "Barcola", "Maignan", "Hernandez", "Coman", "Nkunku"],
  },
  GER: {
    first: ["Manuel", "Joshua", "Jamal", "Leroy", "Thomas", "Leon", "Kai", "Florian", "Niclas", "Serge", "Antonio", "Mats", "Ilkay", "Toni", "Marco"],
    last: ["Neuer", "Kimmich", "Musiala", "Sane", "Muller", "Goretzka", "Havertz", "Wirtz", "Fullkrug", "Gnabry", "Rudiger", "Hummels", "Gundogan", "Kroos", "Reus"],
  },
  ITA: {
    first: ["Gianluigi", "Federico", "Nicolo", "Alessandro", "Lorenzo", "Ciro", "Giacomo", "Sandro", "Giorgio", "Marco", "Andrea", "Matteo", "Davide", "Stefano", "Riccardo"],
    last: ["Donnarumma", "Chiesa", "Barella", "Bastoni", "Insigne", "Immobile", "Raspadori", "Tonali", "Chiellini", "Verratti", "Pirlo", "Darmian", "Frattesi", "Sensi", "Orsolini"],
  },
  NED: {
    first: ["Virgil", "Frenkie", "Memphis", "Cody", "Xavi", "Matthijs", "Denzel", "Steven", "Daley", "Jurrien", "Ryan", "Wout", "Teun", "Quincy", "Noa"],
    last: ["van Dijk", "de Jong", "Depay", "Gakpo", "Simons", "de Ligt", "Dumfries", "Bergwijn", "Blind", "Timber", "Gravenberch", "Weghorst", "Koopmeiners", "Promes", "Lang"],
  },
  POR: {
    first: ["Cristiano", "Bruno", "Bernardo", "Diogo", "Rafael", "Joao", "Ruben", "Goncalo", "Pedro", "Nuno", "Ricardo", "Andre", "Renato", "Otavio", "Vitinha"],
    last: ["Ronaldo", "Fernandes", "Silva", "Jota", "Leao", "Cancelo", "Dias", "Ramos", "Neto", "Mendes", "Pereira", "Gomes", "Sanches", "Carvalho", "Ferreira"],
  },
  BRA: {
    first: ["Neymar", "Vinicius", "Rodrygo", "Casemiro", "Alisson", "Marquinhos", "Endrick", "Raphinha", "Gabriel", "Richarlison", "Lucas", "Thiago", "Ederson", "Danilo", "Antony"],
    last: ["Junior", "Goes", "Santos", "Becker", "Jesus", "Martinelli", "Magalhaes", "Silva", "Oliveira", "Pereira", "Costa", "Almeida", "Rocha", "Nascimento", "Souza"],
  },
  ARG: {
    first: ["Lionel", "Julian", "Lautaro", "Enzo", "Alexis", "Emiliano", "Cristian", "Nicolas", "Angel", "Paulo", "Lisandro", "Exequiel", "Giovani", "Leandro", "Rodrigo"],
    last: ["Messi", "Alvarez", "Martinez", "Fernandez", "Mac Allister", "Romero", "Otamendi", "Di Maria", "Dybala", "Tagliafico", "Palacios", "Lo Celso", "De Paul", "Paredes", "Correa"],
  },
  TUR: {
    first: ["Hakan", "Cengiz", "Kerem", "Arda", "Irfan", "Ozan", "Ugurcan", "Cenk", "Yusuf", "Baris", "Ferdi", "Ismail", "Abdulkadir", "Kenan", "Orkun"],
    last: ["Calhanoglu", "Under", "Akturkoglu", "Guler", "Kahveci", "Tufan", "Cakir", "Tosun", "Yazici", "Yilmaz", "Kadioglu", "Yuksek", "Omur", "Yildiz", "Kokcu"],
  },
  AZE: {
    first: ["Mahir", "Ramil", "Emin", "Tural", "Elvin", "Vugar", "Araz", "Renat", "Namik", "Farid", "Javid", "Ruslan", "Orkhan", "Sabuhi", "Kamran"],
    last: ["Emreli", "Sheydayev", "Mahmudov", "Huseynov", "Mustafayev", "Aliyev", "Mammadov", "Dadashov", "Qurbanov", "Ismayilov", "Hasanov", "Nadirov", "Badalov", "Ahmadov", "Karimov"],
  },
  BEL: {
    first: ["Thibaut", "Kevin", "Romelu", "Eden", "Youri", "Axel", "Leandro", "Amadou", "Jeremy", "Dries", "Toby", "Jan", "Hans", "Michy", "Charles"],
    last: ["Courtois", "De Bruyne", "Lukaku", "Hazard", "Tielemans", "Witsel", "Trossard", "Onana", "Doku", "Mertens", "Alderweireld", "Vertonghen", "Vanaken", "Batshuayi", "De Ketelaere"],
  },
  CRO: {
    first: ["Luka", "Ivan", "Mario", "Josko", "Marcelo", "Andrej", "Borna", "Mateo", "Nikola", "Ante", "Duje", "Dominik", "Josip", "Bruno", "Lovro"],
    last: ["Modric", "Perisic", "Pasalic", "Gvardiol", "Brozovic", "Kramaric", "Sosa", "Kovacic", "Vlasic", "Rebic", "Caleta", "Livakovic", "Juranovic", "Petkovic", "Majer"],
  },
  DEN: {
    first: ["Christian", "Pierre", "Kasper", "Rasmus", "Andreas", "Joakim", "Jonas", "Victor", "Mikkel", "Mathias", "Simon", "Thomas", "Martin", "Jesper", "Yussuf"],
    last: ["Eriksen", "Hojbjerg", "Schmeichel", "Hojlund", "Christensen", "Maehle", "Wind", "Kristiansen", "Damsgaard", "Jensen", "Kjaer", "Delaney", "Braithwaite", "Lindstrom", "Poulsen"],
  },
  SWE: {
    first: ["Zlatan", "Dejan", "Alexander", "Emil", "Victor", "Ludwig", "Kristoffer", "Robin", "Jens", "Mattias", "Sebastian", "Albin", "Gustaf", "Filip", "Isak"],
    last: ["Ibrahimovic", "Kulusevski", "Isak", "Forsberg", "Lindelof", "Augustinsson", "Olsson", "Olsen", "Stryger", "Svanberg", "Larsson", "Ekdal", "Nilsson", "Helander", "Kiese"],
  },
  NOR: {
    first: ["Erling", "Martin", "Alexander", "Martin", "Sander", "Kristoffer", "Andreas", "Morten", "Ola", "Fredrik", "Jorgen", "Leo", "Oscar", "Tobias", "Patrick"],
    last: ["Haaland", "Odegaard", "Sorloth", "Dahlin", "Berge", "Ajer", "Hanche", "Thorsby", "Nyland", "Aursnes", "Strand", "Ostigard", "Bob", "Bjornebye", "Berg"],
  },
  POL: {
    first: ["Robert", "Wojciech", "Piotr", "Arkadiusz", "Jakub", "Grzegorz", "Kamil", "Bartosz", "Sebastian", "Przemyslaw", "Karol", "Nicola", "Mateusz", "Tomasz", "Lukasz"],
    last: ["Lewandowski", "Szczesny", "Zielinski", "Milik", "Kiwior", "Krychowiak", "Grosicki", "Bereszynski", "Szymanski", "Frankowski", "Swiderski", "Zalewski", "Puchacz", "Kedziora", "Skorupski"],
  },
  JPN: {
    first: ["Takefusa", "Kaoru", "Wataru", "Takehiro", "Daichi", "Takumi", "Junya", "Ritsu", "Yuto", "Maya", "Hiroki", "Ao", "Keito", "Yukinari", "Koki"],
    last: ["Kubo", "Mitoma", "Endo", "Tomiyasu", "Kamada", "Minamino", "Ito", "Doan", "Nagatomo", "Yoshida", "Sakai", "Tanaka", "Nakamura", "Sugawara", "Machida"],
  },
  KOR: {
    first: ["Son", "Kim", "Lee", "Hwang", "Cho", "Jung", "Park", "Kang", "Oh", "Hong", "Nam", "Seo", "Min", "Woo", "Jae"],
    last: ["Heung-min", "Min-jae", "Kang-in", "Hee-chan", "Gue-sung", "Woo-young", "Ji-sung", "In-beom", "Hyun-gyu", "Chul", "Tae-hee", "Young-woo", "Jae-sung", "Sung-yueng", "Sung-min"],
  },
  USA: {
    first: ["Christian", "Weston", "Tyler", "Giovanni", "Timothy", "Yun", "Sergino", "Antonee", "Walker", "Brenden", "Ricardo", "Matt", "Zack", "Jordan", "Miles"],
    last: ["Pulisic", "McKennie", "Adams", "Reyna", "Weah", "Musah", "Dest", "Robinson", "Zimmerman", "Aaronson", "Pepi", "Turner", "Steffen", "Morris", "Robinson"],
  },
  MEX: {
    first: ["Hirving", "Raul", "Edson", "Guillermo", "Jesus", "Hector", "Andres", "Cesar", "Uriel", "Luis", "Diego", "Santiago", "Erick", "Johan", "Roberto"],
    last: ["Lozano", "Jimenez", "Alvarez", "Ochoa", "Corona", "Herrera", "Guardado", "Montes", "Antuna", "Chavez", "Lainez", "Gimenez", "Gutierrez", "Vasquez", "Alvarado"],
  },
  MAR: {
    first: ["Achraf", "Hakim", "Yassine", "Sofyan", "Noussair", "Azzedine", "Youssef", "Romain", "Nayef", "Selim", "Amine", "Ilias", "Sofiane", "Abde", "Bilal"],
    last: ["Hakimi", "Ziyech", "Bounou", "Amrabat", "Mazraoui", "Ounahi", "En-Nesyri", "Saiss", "Aguerd", "Amallah", "Harit", "Chair", "Boufal", "Ezzalzouli", "El Khannouss"],
  },
  SEN: {
    first: ["Sadio", "Kalidou", "Edouard", "Ismaila", "Iliman", "Nicolas", "Boulaye", "Cheikhou", "Pape", "Krepin", "Famara", "Abdoulaye", "Ibrahima", "Pathé", "Moussa"],
    last: ["Mane", "Koulibaly", "Mendy", "Sarr", "Ndiaye", "Jackson", "Dia", "Kouyate", "Sarr", "Diatta", "Diedhiou", "Diallo", "Konate", "Ciss", "Niakhate"],
  },
  NGA: {
    first: ["Victor", "Wilfred", "Alex", "Kelechi", "Samuel", "Ademola", "Joe", "Calvin", "Taiwo", "Victor", "William", "Semi", "Kenneth", "Ahmed", "Moses"],
    last: ["Osimhen", "Ndidi", "Iwobi", "Iheanacho", "Chukwueze", "Lookman", "Gomez", "Bassey", "Awoniyi", "Boniface", "Troost-Ekong", "Ajayi", "Omeruo", "Musa", "Simon"],
  },
  GHA: {
    first: ["Mohammed", "Thomas", "Jordan", "Inaki", "Antoine", "Kamaldeen", "Daniel", "Alexander", "Andre", "Osman", "Joseph", "Richmond", "Felix", "Baba", "Tariq"],
    last: ["Kudus", "Partey", "Ayew", "Williams", "Semenyo", "Sulemana", "Amartey", "Djiku", "Ayew", "Bukari", "Paintsil", "Boakye", "Afena", "Rahman", "Lamptey"],
  },
  SCO: {
    first: ["Andrew", "John", "Scott", "Callum", "Ryan", "James", "Kieran", "Stuart", "Billy", "Kenny", "Lewis", "Craig", "Aaron", "Liam", "Greg"],
    last: ["Robertson", "McGinn", "McTominay", "McGregor", "Christie", "Forrest", "Tierney", "Armstrong", "Gilmour", "McLean", "Ferguson", "Gordon", "Hickey", "Cooper", "Taylor"],
  },
};

export const NAT_FOR_COUNTRY: Record<string, string[]> = {
  England: ["ENG", "SCO", "IRL", "WAL", "NGA", "GHA", "JAM"],
  Spain: ["ESP", "ARG", "BRA", "FRA", "MAR"],
  Germany: ["GER", "AUT", "SUI", "FRA", "TUR"],
  Italy: ["ITA", "ARG", "BRA", "CRO", "FRA"],
  France: ["FRA", "SEN", "CIV", "MAR", "ALG", "CMR"],
  Turkiye: ["TUR", "GER", "AZE", "NED"],
  Azerbaijan: ["AZE", "TUR", "GEO", "RUS"],
  Netherlands: ["NED", "SUR", "BEL", "MAR"],
  Portugal: ["POR", "BRA", "CPV", "ANG"],
  Brazil: ["BRA", "ARG", "URU", "PAR"],
  Argentina: ["ARG", "URU", "CHI", "COL"],
  USA: ["USA", "MEX", "CAN", "JAM"],
  Belgium: ["BEL", "FRA", "NED", "COD"],
  Scotland: ["SCO", "ENG", "NIR", "IRL"],
};

export const MANAGER_FIRST = ["Pep", "Carlo", "Jurgen", "Mikel", "Diego", "Erik", "Antonio", "Unai", "Luciano", "Roberto", "Mauricio", "Xabi", "Thomas", "Vincent", "Arne"];
export const MANAGER_LAST = ["Guardiola", "Ancelotti", "Klopp", "Arteta", "Simeone", "ten Hag", "Conte", "Emery", "Spalletti", "De Zerbi", "Pochettino", "Alonso", "Tuchel", "Kompany", "Slot"];
export const AGENT_FIRST = ["Jorge", "Mino", "Jonathan", "Kia", "Paulo", "Volkan", "Hasan", "Pini"];
export const AGENT_LAST = ["Mendes", "Raiola", "Barnett", "Joorabchian", "Futre", "Demirel", "Yildirim", "Zahavi"];
export const PARTNER_FIRST = ["Elif", "Sofia", "Maya", "Lara", "Aylin", "Nina", "Elena", "Clara", "Leyla", "Amelia", "Nora", "Iris"];
