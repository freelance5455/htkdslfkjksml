import type { Pos, Teammate } from "../types";

type P = [string, string, Pos, number];

function squad(id: string, rows: P[], nats: string[] = ["ENG"]): Teammate[] {
  return rows.map((r, i) => ({
    id: id + "_" + i,
    first: r[0],
    last: r[1],
    pos: r[2],
    ovr: r[3],
    age: 22 + ((i * 3) % 12),
    nat: nats[i % nats.length] ?? "ENG",
  }));
}

export const TEAM_SQUADS: Record<string, Teammate[]> = {
  "man-sky": squad("man-sky", [
    ["Edersson", "", "GK", 88], ["Kyle", "Walkers", "RB", 84], ["Ruben", "Dias", "CB", 87],
    ["John", "Stones", "CB", 85], ["Josko", "Gvardiol", "LB", 85], ["Rodri", "", "CDM", 89],
    ["Kevin", "De Bruyn", "CAM", 90], ["Bernardo", "Silva", "CM", 87], ["Phil", "Foden", "LW", 87],
    ["Erling", "Hollan", "ST", 91], ["Jeremy", "Doku", "LW", 84], ["Jack", "Grealish", "LW", 82],
    ["Mateo", "Kovacic", "CM", 84], ["Nathan", "Ake", "CB", 82], ["Stefan", "Ortega", "GK", 82],
  ], ["BRA", "ENG", "POR", "ENG", "CRO", "ESP", "BEL", "POR", "ENG", "NOR", "BEL", "ENG", "CRO", "NED", "GER"]),
  "man-red": squad("man-red", [
    ["Andre", "Onan", "GK", 82], ["Diogo", "Dalot", "RB", 82], ["Lisandro", "Martines", "CB", 84],
    ["Raphael", "Varan", "CB", 85], ["Luke", "Shaw", "LB", 82], ["Casemiro", "", "CDM", 85],
    ["Bruno", "Fernandes", "CAM", 87], ["Mason", "Mount", "CM", 82], ["Marcus", "Rashford", "LW", 84],
    ["Rasmus", "Hojlund", "ST", 82], ["Alejandro", "Garnacho", "LW", 81], ["Antony", "Santos", "RW", 80],
    ["Christian", "Eriksen", "CAM", 82], ["Victor", "Lindelof", "CB", 80], ["Altay", "Bayindir", "GK", 78],
  ], ["CMR", "POR", "ARG", "FRA", "ENG", "BRA", "POR", "ENG", "ENG", "DEN", "ARG", "BRA", "DEN", "SWE", "TUR"]),
  "lon-gun": squad("lon-gun", [
    ["David", "Raya", "GK", 84], ["Ben", "White", "RB", 82], ["William", "Saliba", "CB", 86],
    ["Gabriel", "Magalhaes", "CB", 86], ["Oleksandr", "Zinchenko", "LB", 81], ["Declan", "Rice", "CDM", 86],
    ["Martin", "Odegaard", "CAM", 87], ["Kai", "Havertz", "CAM", 84], ["Bukayo", "Saka", "RW", 86],
    ["Gabriel", "Jesus", "ST", 83], ["Gabriel", "Martinelli", "LW", 84], ["Leandro", "Trossard", "LW", 82],
    ["Thomas", "Partey", "CDM", 83], ["Jurrien", "Timber", "RB", 82], ["Aaron", "Ramsdale", "GK", 82],
  ], ["ESP", "ENG", "FRA", "BRA", "UKR", "ENG", "NOR", "GER", "ENG", "BRA", "BRA", "BEL", "GHA", "NED", "ENG"]),
  "mer-red": squad("mer-red", [
    ["Alison", "Becker", "GK", 88], ["Trent", "Alexander", "RB", 86], ["Virgil", "van Dijki", "CB", 88],
    ["Ibrahima", "Konate", "CB", 84], ["Andy", "Robertson", "LB", 85], ["Wataru", "Endo", "CDM", 81],
    ["Alexis", "Mac Allister", "CM", 85], ["Dominik", "Szoboszlai", "CAM", 85], ["Mohamed", "Sala", "RW", 88],
    ["Darwin", "Nunez", "ST", 83], ["Luis", "Diaz", "LW", 85], ["Cody", "Gakpo", "LW", 83],
    ["Ryan", "Gravenberch", "CM", 82], ["Joe", "Gomez", "CB", 80], ["Caoimhin", "Kelleher", "GK", 80],
  ], ["BRA", "ENG", "NED", "FRA", "SCO", "JPN", "ARG", "HUN", "EGY", "URU", "COL", "NED", "NED", "ENG", "IRL"]),
  "lon-royal": squad("lon-royal", [
    ["Robert", "Sanchez", "GK", 82], ["Reece", "James", "RB", 85], ["Thiago", "Silva", "CB", 84],
    ["Levi", "Colwill", "CB", 82], ["Marc", "Cucurella", "LB", 82], ["Moises", "Caicedo", "CDM", 84],
    ["Enzo", "Fernandez", "CM", 84], ["Cole", "Palmer", "CAM", 85], ["Raheem", "Sterling", "LW", 83],
    ["Nicolas", "Jackson", "ST", 82], ["Noni", "Madueke", "RW", 80], ["Conor", "Gallagher", "CM", 82],
    ["Mykhailo", "Mudryk", "LW", 80], ["Benoit", "Badiashile", "CB", 80], ["Djordje", "Petrovic", "GK", 78],
  ]),
  "n-lon-w": squad("n-lon-w", [
    ["Guglielmo", "Vicario", "GK", 82], ["Pedro", "Porro", "RB", 83], ["Cristian", "Romero", "CB", 86],
    ["Micky", "van de Ven", "CB", 83], ["Destiny", "Udogie", "LB", 82], ["Yves", "Bissouma", "CDM", 82],
    ["James", "Maddison", "CAM", 85], ["Pape", "Sarr", "CM", 81], ["Son", "Heung-min", "LW", 86],
    ["Richarlison", "", "ST", 82], ["Brennan", "Johnson", "RW", 81], ["Dejan", "Kulusevski", "CAM", 83],
    ["Pierre-Emile", "Hojbjerg", "CDM", 81], ["Radu", "Dragusin", "CB", 78], ["Fraser", "Forster", "GK", 78],
  ]),
  "new-mag": squad("new-mag", [
    ["Nick", "Pope", "GK", 84], ["Kieran", "Trippier", "RB", 83], ["Fabian", "Schar", "CB", 82],
    ["Sven", "Botman", "CB", 82], ["Dan", "Burn", "LB", 78], ["Bruno", "Guimaraes", "CM", 84],
    ["Joelinton", "", "CM", 82], ["Joe", "Willock", "CM", 80], ["Anthony", "Gordon", "LW", 82],
    ["Alexander", "Isak", "ST", 84], ["Miguel", "Almiron", "RW", 80], ["Sean", "Longstaff", "CM", 79],
    ["Jamaal", "Lascelles", "CB", 78], ["Callum", "Wilson", "ST", 82], ["Martin", "Dubravka", "GK", 78],
  ]),
  "bir-vil": squad("bir-vil", [
    ["Emiliano", "Martinez", "GK", 85], ["Matty", "Cash", "RB", 80], ["Ezri", "Konsa", "CB", 82],
    ["Pau", "Torres", "CB", 82], ["Lucas", "Digne", "LB", 80], ["Boubacar", "Kamara", "CDM", 82],
    ["Douglas", "Luiz", "CM", 83], ["John", "McGinn", "CM", 82], ["Leon", "Bailey", "RW", 82],
    ["Ollie", "Watkins", "ST", 84], ["Moussa", "Diaby", "RW", 82], ["Youri", "Tielemans", "CM", 82],
    ["Diego", "Carlos", "CB", 80], ["Jhon", "Duran", "ST", 78], ["Robin", "Olsen", "GK", 78],
  ]),
  "mad-bla": squad("mad-bla", [
    ["Thibaut", "Courtois", "GK", 89], ["Dani", "Carvajal", "RB", 85], ["Antonio", "Rudiger", "CB", 86],
    ["Eder", "Militao", "CB", 84], ["Ferland", "Mendy", "LB", 83], ["Aurelien", "Tchouameni", "CDM", 84],
    ["Federico", "Valverde", "CM", 87], ["Jude", "Bellingham", "CAM", 89], ["Vinicius", "Junior", "LW", 89],
    ["Kylian", "Mbappe", "ST", 91], ["Rodrygo", "Goes", "RW", 86], ["Luka", "Modric", "CM", 87],
    ["Eduardo", "Camavinga", "CM", 84], ["Dani", "Ceballos", "CM", 80], ["Andriy", "Lunin", "GK", 80],
  ], ["BEL", "ESP", "GER", "BRA", "FRA", "FRA", "URU", "ENG", "BRA", "FRA", "BRA", "CRO", "FRA", "ESP", "UKR"]),
  "bar-bla": squad("bar-bla", [
    ["Marc-Andre", "ter Stegen", "GK", 86], ["Jules", "Kounde", "RB", 84], ["Ronald", "Araujo", "CB", 86],
    ["Pau", "Cubarsi", "CB", 80], ["Alejandro", "Balde", "LB", 82], ["Frenkie", "de Jong", "CM", 85],
    ["Pedri", "", "CM", 86], ["Ilkay", "Gundogan", "CAM", 85], ["Lamine", "Yamal", "RW", 87],
    ["Robert", "Lewandowski", "ST", 88], ["Raphinha", "", "LW", 84], ["Ferran", "Torres", "RW", 82],
    ["Oriol", "Romeu", "CDM", 80], ["Andreas", "Christensen", "CB", 82], ["Inaki", "Pena", "GK", 80],
  ]),
  "mad-roj": squad("mad-roj", [
    ["Jan", "Oblak", "GK", 87], ["Nahuel", "Molina", "RB", 81], ["Jose Maria", "Gimenez", "CB", 84],
    ["Robin", "Le Normand", "CB", 83], ["Reinildo", "Mandava", "LB", 80], ["Koke", "", "CM", 83],
    ["Rodrigo", "De Paul", "CM", 83], ["Pablo", "Barrios", "CM", 80], ["Antoine", "Griezmann", "CF", 86],
    ["Alvaro", "Morata", "ST", 83], ["Samuel", "Lino", "LW", 80], ["Marcos", "Llorente", "RB", 82],
    ["Stefan", "Savic", "CB", 82], ["Angel", "Correa", "CF", 80], ["Horatiu", "Moldovan", "GK", 78],
  ]),
  "mun-red": squad("mun-red", [
    ["Manuel", "Neuer", "GK", 87], ["Joshua", "Kimmich", "RB", 87], ["Dayot", "Upamecano", "CB", 84],
    ["Kim", "Min-jae", "CB", 82], ["Alphonso", "Davies", "LB", 85], ["Leon", "Goretzka", "CM", 84],
    ["Konrad", "Laimer", "CM", 82], ["Jamal", "Musiala", "CAM", 86], ["Leroy", "Sane", "RW", 85],
    ["Harry", "Kane", "ST", 89], ["Thomas", "Muller", "CAM", 85], ["Kingsley", "Coman", "LW", 84],
    ["Eric", "Dier", "CB", 78], ["Raphael", "Guerreiro", "LB", 82], ["Sven", "Ulreich", "GK", 78],
  ]),
  "dor-yel": squad("dor-yel", [
    ["Gregor", "Kobel", "GK", 85], ["Julian", "Ryerson", "RB", 80], ["Nico", "Schlotterbeck", "CB", 83],
    ["Mats", "Hummels", "CB", 82], ["Ramy", "Bensebaini", "LB", 80], ["Emre", "Can", "CDM", 82],
    ["Marcel", "Sabitzer", "CM", 82], ["Julian", "Brandt", "CAM", 84], ["Karim", "Adeyemi", "LW", 81],
    ["Serhou", "Guirassy", "ST", 84], ["Donyell", "Malen", "RW", 82], ["Marco", "Reus", "CAM", 84],
    ["Salih", "Ozcan", "CDM", 78], ["Niklas", "Sule", "CB", 82], ["Alexander", "Meyer", "GK", 78],
  ]),
  "mil-ner": squad("mil-ner", [
    ["Yann", "Sommer", "GK", 85], ["Denzel", "Dumfries", "RB", 83], ["Alessandro", "Bastoni", "CB", 85],
    ["Francesco", "Acerbi", "CB", 82], ["Federico", "Dimarco", "LB", 83], ["Nicolo", "Barella", "CM", 86],
    ["Hakan", "Calhanoglu", "CDM", 85], ["Henrikh", "Mkhitaryan", "CM", 82], ["Lautaro", "Martinez", "ST", 87],
    ["Marcus", "Thuram", "ST", 84], ["Alexis", "Sanchez", "CF", 80], ["Matteo", "Darmian", "RB", 80],
    ["Stefan", "de Vrij", "CB", 82], ["Davide", "Frattesi", "CM", 82], ["Emil", "Audero", "GK", 78],
  ]),
  "mil-ros": squad("mil-ros", [
    ["Mike", "Maignan", "GK", 85], ["Davide", "Calabria", "RB", 81], ["Fikayo", "Tomori", "CB", 84],
    ["Malick", "Thiaw", "CB", 80], ["Theo", "Hernandez", "LB", 85], ["Ismael", "Bennacer", "CDM", 82],
    ["Tijjani", "Reijnders", "CM", 82], ["Ruben", "Loftus-Cheek", "CAM", 83], ["Rafael", "Leao", "LW", 85],
    ["Olivier", "Giroud", "ST", 82], ["Christian", "Pulisic", "RW", 83], ["Yunus", "Musah", "CM", 79],
    ["Simon", "Kjaer", "CB", 80], ["Noah", "Okafor", "LW", 78], ["Marco", "Sportiello", "GK", 78],
  ]),
  "tor-bia": squad("tor-bia", [
    ["Wojciech", "Szczesny", "GK", 84], ["Andrea", "Cambiaso", "RB", 80], ["Gleison", "Bremer", "CB", 86],
    ["Federico", "Gatti", "CB", 80], ["Alex", "Sandro", "LB", 80], ["Manuel", "Locatelli", "CM", 82],
    ["Adrien", "Rabiot", "CM", 83], ["Weston", "McKennie", "CM", 80], ["Federico", "Chiesa", "RW", 84],
    ["Dusan", "Vlahovic", "ST", 85], ["Kenan", "Yildiz", "CAM", 78], ["Filip", "Kostic", "LB", 82],
    ["Danilo", "Silva", "CB", 82], ["Arkadiusz", "Milik", "ST", 80], ["Mattia", "Perin", "GK", 80],
  ]),
  "nap-azz": squad("nap-azz", [
    ["Alex", "Meret", "GK", 82], ["Giovanni", "Di Lorenzo", "RB", 83], ["Amir", "Rrahmani", "CB", 83],
    ["Kim", "Min-jae", "CB", 84], ["Mathias", "Olivera", "LB", 80], ["Stanislav", "Lobotka", "CDM", 84],
    ["Andre-Frank", "Anguissa", "CM", 83], ["Piotr", "Zielinski", "CAM", 84], ["Matteo", "Politano", "RW", 82],
    ["Victor", "Osimhen", "ST", 86], ["Khvicha", "Kvaratskhelia", "LW", 85], ["Jesper", "Lindstrom", "RW", 78],
    ["Giacomo", "Raspadori", "CF", 80], ["Juan", "Jesus", "CB", 80], ["Pierluigi", "Gollini", "GK", 78],
  ]),
  "par-sg": squad("par-sg", [
    ["Gianluigi", "Donnarumma", "GK", 87], ["Achraf", "Hakimi", "RB", 85], ["Marquinhos", "", "CB", 85],
    ["Milan", "Skriniar", "CB", 82], ["Lucas", "Hernandez", "LB", 82], ["Vitinha", "", "CDM", 84],
    ["Manuel", "Ugarte", "CDM", 82], ["Warren", "Zaire-Emery", "CM", 83], ["Ousmane", "Dembele", "RW", 85],
    ["Kylian", "Mbappe", "ST", 91], ["Bradley", "Barcola", "LW", 81], ["Randal", "Kolo Muani", "ST", 82],
    ["Lee", "Kang-in", "CAM", 82], ["Danilo", "Pereira", "CB", 80], ["Keylor", "Navas", "GK", 80],
  ]),
  "mon-aco": squad("mon-aco", [
    ["Philipp", "Kohn", "GK", 80], ["Vanderson", "", "RB", 80], ["Guillermo", "Maripan", "CB", 82],
    ["Mohamed", "Salisu", "CB", 80], ["Caio", "Henrique", "LB", 80], ["Youssouf", "Fofana", "CDM", 83],
    ["Denis", "Zakaria", "CM", 83], ["Aleksandr", "Golovin", "CAM", 84], ["Maghnes", "Akliouche", "CAM", 80],
    ["Folarin", "Balogun", "ST", 82], ["Takumi", "Minamino", "LW", 80], ["Eliesse", "Ben Seghir", "LW", 78],
    ["Soungoutou", "Magassa", "CDM", 78], ["Thilo", "Kehrer", "CB", 80], ["Radoslaw", "Majecki", "GK", 78],
  ]),
  "mar-sei": squad("mar-sei", [
    ["Pau", "Lopez", "GK", 82], ["Jonathan", "Clauss", "RB", 82], ["Chancel", "Mbemba", "CB", 82],
    ["Leonardo", "Balerdi", "CB", 80], ["Renan", "Lodi", "LB", 80], ["Valentin", "Rongier", "CM", 82],
    ["Jordan", "Veretout", "CM", 82], ["Amine", "Harit", "CAM", 82], ["Pierre-Emerick", "Aubameyang", "ST", 82],
    ["Ismaila", "Sarr", "RW", 81], ["Iliman", "Ndiaye", "LW", 80], ["Azzedine", "Ounahi", "CM", 80],
    ["Samuel", "Gigot", "CB", 80], ["Faris", "Moumbagna", "ST", 78], ["Ruben", "Blanco", "GK", 78],
  ]),
  "lyo-n": squad("lyo-n", [
    ["Anthony", "Lopes", "GK", 82], ["Clinton", "Mata", "RB", 78], ["Duje", "Caleta-Car", "CB", 82],
    ["Jake", "O'Brien", "CB", 78], ["Nicolas", "Tagliafico", "LB", 80], ["Maxence", "Caqueret", "CM", 82],
    ["Corentin", "Tolisso", "CM", 82], ["Rayan", "Cherki", "CAM", 80], ["Alexandre", "Lacazette", "ST", 82],
    ["Ernest", "Nuamah", "LW", 78], ["Ainsley", "Maitland-Niles", "RB", 78], ["Mama", "Balde", "RW", 78],
    ["Orel", "Mangala", "CDM", 78], ["Remy", "Riou", "GK", 78], ["Said", "Benrahma", "LW", 78],
  ]),
  "ist-asl": squad("ist-asl", [
    ["Fernando", "Muslera", "GK", 82], ["Sacha", "Boey", "RB", 82], ["Davinson", "Sanchez", "CB", 82],
    ["Victor", "Nelsson", "CB", 80], ["Angelino", "", "LB", 82], ["Lucas", "Torreira", "CDM", 83],
    ["Kerem", "Demirbay", "CM", 82], ["Dries", "Mertens", "CAM", 82], ["Hakim", "Ziyech", "RW", 84],
    ["Mauro", "Icardi", "ST", 85], ["Kerem", "Akturkoglu", "LW", 83], ["Baris", "Alper Yilmaz", "RW", 80],
    ["Sergio", "Oliveira", "CM", 80], ["Abdulkerim", "Bardakci", "CB", 78], ["Gunay", "Guvenc", "GK", 78],
  ], ["URU", "FRA", "COL", "DEN", "ESP", "URU", "GER", "BEL", "MAR", "ARG", "TUR", "TUR", "POR", "TUR", "TUR"]),
  "ist-kan": squad("ist-kan", [
    ["Dominik", "Livakovic", "GK", 82], ["Bright", "Osayi-Samuel", "RB", 82], ["Alexander", "Djiku", "CB", 82],
    ["Ferdi", "Kadioglu", "LB", 82], ["Ismail", "Yuksek", "CDM", 80], ["Fred", "", "CM", 83],
    ["Irfan Can", "Kahveci", "CAM", 82], ["Sebastian", "Szymanski", "CAM", 83], ["Dusan", "Tadic", "RW", 83],
    ["Edin", "Dzeko", "ST", 83], ["Cengiz", "Under", "RW", 81], ["Yusuf", "Kahveci", "CM", 78],
    ["Jayden", "Oosterwolde", "LB", 78], ["Leonardo", "Bonucci", "CB", 80], ["Irfan Can", "Egribayat", "GK", 78],
  ]),
  "ist-kar": squad("ist-kar", [
    ["Mert", "Gunok", "GK", 81], ["Jonas", "Svensson", "RB", 79], ["Omar", "Colley", "CB", 80],
    ["Necip", "Uysal", "CB", 78], ["Arthur", "Masuaku", "LB", 80], ["Gedson", "Fernandes", "CM", 80],
    ["Salih", "Ucan", "CM", 79], ["Rachid", "Ghezzal", "CAM", 80], ["Cenk", "Tosun", "ST", 79],
    ["Vincent", "Aboubakar", "ST", 81], ["Semih", "Kilicsoy", "ST", 76], ["Alex", "Oxlade-Chamberlain", "CM", 80],
    ["Daniel", "Amartey", "CB", 78], ["Bakhtiyor", "Zaynutdinov", "LB", 78], ["Ersin", "Destanoglu", "GK", 78],
  ]),
  "trb-fir": squad("trb-fir", [
    ["Ugurcan", "Cakir", "GK", 83], ["Jens", "Stryger", "RB", 78], ["Stefano", "Denswil", "CB", 79],
    ["Taha", "Tepe", "CB", 76], ["Eren", "Elmali", "LB", 78], ["Berat", "Ozdemir", "CDM", 78],
    ["Enis", "Bardhi", "CM", 81], ["Edin", "Visca", "RW", 82], ["Anastasios", "Bakasetas", "CAM", 82],
    ["Paul", "Onuachu", "ST", 82], ["Trezeguet", "", "LW", 81], ["Thomas", "Meunier", "RB", 80],
    ["Batista", "Mendy", "CB", 78], ["Ozan", "Tufan", "CM", 78], ["Ugurcan", "Cakir", "GK", 83],
  ]),
  "bil-lio": squad("bil-lio", [
    ["Unai", "Simon", "GK", 85], ["Oscar", "de Marcos", "RB", 78], ["Dani", "Vivian", "CB", 82],
    ["Aitor", "Paredes", "CB", 78], ["Yuri", "Berchiche", "LB", 79], ["Mikel", "Vesga", "CDM", 78],
    ["Mikel", "Merino", "CM", 84], ["Oihan", "Sancet", "CAM", 82], ["Inaki", "Williams", "RW", 82],
    ["Gorka", "Guruzeta", "ST", 79], ["Nico", "Williams", "LW", 82], ["Alex", "Berenguer", "RW", 78],
    ["Inigo", "Ruiz de Galarreta", "CM", 78], ["Yeray", "Alvarez", "CB", 80], ["Julen", "Agirrezabala", "GK", 76],
  ]),
  "san-seb": squad("san-seb", [
    ["Alex", "Remiro", "GK", 84], ["Hamari", "Traore", "RB", 79], ["Igor", "Zubeldia", "CB", 80],
    ["Robin", "Le Normand", "CB", 82], ["Aihen", "Munoz", "LB", 78], ["Martin", "Zubimendi", "CDM", 84],
    ["Mikel", "Merino", "CM", 83], ["Brais", "Mendez", "CAM", 82], ["Takefusa", "Kubo", "RW", 83],
    ["Mikel", "Oyarzabal", "CF", 83], ["Ander", "Barrenetxea", "LW", 80], ["Benat", "Turrientes", "CM", 78],
    ["Jon", "Pacheco", "CB", 78], ["Umar", "Sadiq", "ST", 80], ["Andoni", "Zubiaurre", "GK", 72],
  ]),
  "vil-yel": squad("vil-yel", [
    ["Filip", "Jorgensen", "GK", 82], ["Kiko", "Femenia", "RB", 78], ["Raul", "Albiol", "CB", 80],
    ["Logan", "Costa", "CB", 78], ["Alfonso", "Pedraza", "LB", 79], ["Dani", "Parejo", "CM", 83],
    ["Etienne", "Capoue", "CDM", 80], ["Alex", "Baena", "CAM", 83], ["Yeremy", "Pino", "RW", 80],
    ["Gerard", "Moreno", "ST", 83], ["Alexander", "Sorloth", "ST", 82], ["Manu", "Trigueros", "CM", 78],
    ["Jorge", "Cuenca", "CB", 78], ["Aissa", "Mandi", "CB", 80], ["Pepe", "Reina", "GK", 76],
  ]),
};

export function displayName(p: Teammate): string {
  return (p.first + " " + p.last).trim();
}
