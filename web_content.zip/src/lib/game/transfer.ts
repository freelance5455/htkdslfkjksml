import { playerWage } from "./player";
import { RNG } from "./rng";
import { autoPickXI } from "./team";
import type { GameState, PlayerData, TransferOffer } from "./types";

export class TransferMarket {
  list(state: GameState): PlayerData[] {
    const out: PlayerData[] = [];
    for (const p of Object.values(state.players)) {
      if (p.clubId === state.clubId) continue;
      const club = state.clubs[p.clubId];
      if (!club || club.npc) continue;
      if (p.listed || p.ovr >= 78 || p.age >= 32 || p.age <= 21) out.push(p);
    }
    return out.sort((a, b) => b.ovr - a.ovr);
  }

  bid(
    state: GameState,
    rng: RNG,
    playerId: string,
    amount: number,
    wage: number,
  ): { ok: boolean; message: string } {
    const p = state.players[playerId];
    if (!p) return { ok: false, message: "Oyuncu bulunamadı." };
    if (p.clubId === state.clubId) return { ok: false, message: "Kendi oyuncunuz." };
    const user = state.clubs[state.clubId]!;
    if (!state.transferOpen) return { ok: false, message: "Transfer dönemi kapalı." };
    if (amount > user.balance) return { ok: false, message: "Bütçe yetersiz." };
    const want = p.value * (p.ovr >= 82 || (p.age < 23 && p.pot >= 84) ? 1.22 : 1.0);
    const wageOk = wage >= playerWage(p.ovr, p.age) * 0.9;
    const accept =
      amount >= want * 0.92 &&
      wageOk &&
      rng.chance(0.72 + Math.min(0.25, (amount - want) / Math.max(1, want)));
    const offer: TransferOffer = {
      id: `t_${state.uid++}`,
      playerId,
      fromId: p.clubId,
      toId: state.clubId,
      amount,
      wage,
      status: accept ? "accepted" : "rejected",
    };
    state.transfers.unshift(offer);
    if (state.transfers.length > 40) state.transfers.length = 40;
    if (!accept) {
      return {
        ok: false,
        message: amount < want * 0.8 ? `${p.name} için teklif çok düşük.` : "Kulüp teklifi reddetti.",
      };
    }
    user.balance -= amount;
    const from = state.clubs[p.clubId];
    if (from) from.balance += amount;
    p.clubId = user.id;
    p.wage = wage;
    p.listed = false;
    p.morale = Math.min(100, p.morale + 8);
    this.repairSquad(state, from?.id);
    this.repairSquad(state, user.id);
    return { ok: true, message: `${p.name} kadroya katıldı.` };
  }

  sell(
    state: GameState,
    rng: RNG,
    playerId: string,
  ): { ok: boolean; message: string; amount: number } {
    const p = state.players[playerId];
    const user = state.clubs[state.clubId]!;
    if (!p || p.clubId !== user.id) return { ok: false, message: "Oyuncu sizde değil.", amount: 0 };
    const squad = Object.values(state.players).filter((x) => x.clubId === user.id);
    if (squad.length <= 18) return { ok: false, message: "Kadro 18'in altına inemez.", amount: 0 };
    const amount = Math.round(p.value * rng.float(0.78, 1.05));
    const buyers = Object.values(state.clubs).filter(
      (c) => c.id !== user.id && !c.npc && c.league.endsWith("1"),
    );
    const buyer = rng.pick(buyers);
    user.balance += amount;
    p.clubId = buyer.id;
    p.listed = false;
    this.repairSquad(state, user.id);
    this.repairSquad(state, buyer.id);
    return {
      ok: true,
      message: `${p.name} ${buyer.name} takımına gitti.`,
      amount,
    };
  }

  listPlayer(state: GameState, playerId: string, price: number) {
    const p = state.players[playerId];
    if (!p || p.clubId !== state.clubId) return;
    p.listed = true;
    p.askingPrice = price;
  }

  cpuWindow(state: GameState, rng: RNG) {
    const listed = Object.values(state.players).filter(
      (p) => p.listed && p.clubId === state.clubId,
    );
    for (const p of listed) {
      if (!rng.chance(0.28)) continue;
      const offer = Math.round((p.askingPrice || p.value) * rng.float(0.9, 1.08));
      const user = state.clubs[state.clubId]!;
      const buyers = Object.values(state.clubs).filter((c) => c.id !== user.id && !c.npc);
      if (!buyers.length) continue;
      const buyer = rng.pick(buyers);
      user.balance += offer;
      p.clubId = buyer.id;
      p.listed = false;
      state.news.unshift({
        id: `n_${state.uid++}`,
        week: state.week,
        title: "Satış tamam",
        body: `${p.name} ${buyer.name} kulübüne ${offer.toLocaleString("tr-TR")} € bedelle transfer oldu.`,
        tone: "good",
      });
      this.repairSquad(state, user.id);
    }
  }

  repairSquad(state: GameState, clubId?: string) {
    if (!clubId) return;
    const club = state.clubs[clubId];
    if (!club) return;
    const players = Object.values(state.players).filter((p) => p.clubId === clubId);
    const pick = autoPickXI(players, club.tactics.formation);
    club.xi = pick.xi;
    club.bench = pick.bench;
  }
}
