const TR_MONTHS = [
  "Oca",
  "Şub",
  "Mar",
  "Nis",
  "May",
  "Haz",
  "Tem",
  "Ağu",
  "Eyl",
  "Eki",
  "Kas",
  "Ara",
];

export function money(n: number): string {
  const sign = n < 0 ? "-" : "";
  const v = Math.abs(n);
  if (v >= 1_000_000_000) return `${sign}€${(v / 1_000_000_000).toFixed(2)}Mr`;
  if (v >= 1_000_000) return `${sign}€${(v / 1_000_000).toFixed(1)}M`;
  if (v >= 1_000) return `${sign}€${(v / 1_000).toFixed(0)}B`;
  return `${sign}€${Math.round(v)}`;
}

export function clamp(n: number, a: number, b: number): number {
  return Math.max(a, Math.min(b, n));
}

export function seasonDate(season: number, week: number): string {
  const start = new Date(Date.UTC(season, 7, 10));
  start.setUTCDate(start.getUTCDate() + (week - 1) * 7);
  return `${start.getUTCDate()} ${TR_MONTHS[start.getUTCMonth()]} ${start.getUTCFullYear()}`;
}

export function posLabel(pos: string): string {
  return pos;
}

export function ovrTone(ovr: number): string {
  if (ovr >= 86) return "text-ok";
  if (ovr >= 78) return "text-fg";
  if (ovr >= 70) return "text-muted";
  return "text-faint";
}

export function confTone(n: number): string {
  if (n >= 70) return "text-ok";
  if (n >= 40) return "text-warn";
  return "text-danger";
}

export function energyTone(n: number): string {
  if (n >= 75) return "bg-ok";
  if (n >= 50) return "bg-warn";
  return "bg-danger";
}

export function leagueName(id: string): string {
  const map: Record<string, string> = {
    ENG1: "Premier League",
    ESP1: "La Liga",
    ITA1: "Serie A",
    GER1: "Bundesliga",
    FRA1: "Ligue 1",
    POR1: "Primeira Liga",
    TUR1: "Süper Lig",
    TUR2: "TFF 1. Lig",
  };
  return map[id] ?? id;
}

export function countryName(code: string): string {
  const map: Record<string, string> = {
    ENG: "İngiltere",
    ESP: "İspanya",
    ITA: "İtalya",
    GER: "Almanya",
    FRA: "Fransa",
    POR: "Portekiz",
    TUR: "Türkiye",
    NED: "Hollanda",
    BEL: "Belçika",
    SCO: "İskoçya",
    AUT: "Avusturya",
    SUI: "İsviçre",
    GRE: "Yunanistan",
    CZE: "Çekya",
    DEN: "Danimarka",
    CRO: "Hırvatistan",
    SRB: "Sırbistan",
    UKR: "Ukrayna",
    BRA: "Brezilya",
    ARG: "Arjantin",
  };
  return map[code] ?? code;
}

export function compLabel(comp: string): string {
  if (comp === "UCL") return "Şampiyonlar Ligi";
  if (comp === "UEL") return "Avrupa Ligi";
  if (comp === "UECL") return "Konferans Ligi";
  return "Lig";
}

export function objectiveLabel(o: string): string {
  const map: Record<string, string> = {
    title: "Şampiyonluk",
    top4: "İlk 4 / Şampiyonlar Ligi",
    europe: "Avrupa kupası",
    mid: "Orta sıra",
    survive: "Küme düşmemek",
    promote: "Üst lige çıkmak",
  };
  return map[o] ?? o;
}
