export function fmtNum(n: number): string {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(n >= 10_000_000 ? 0 : 1).replace(".0", "") + "M";
  if (n >= 10_000) return Math.round(n / 1000) + "B";
  if (n >= 1000) return (n / 1000).toFixed(1).replace(".0", "") + "B";
  return String(Math.round(n));
}

export function fmtMoney(n: number): string {
  const abs = Math.abs(n);
  const sign = n < 0 ? "-" : "";
  if (abs >= 1_000_000) return sign + "£" + (abs / 1_000_000).toFixed(abs >= 10_000_000 ? 0 : 1).replace(".0", "") + "M";
  if (abs >= 1000) return sign + "£" + Math.round(abs / 1000) + "B";
  return sign + "£" + Math.round(abs);
}

export function fmtFee(n: number): string {
  if (n <= 0) return "Bedelsiz";
  if (n >= 1_000_000) return "€" + (n / 1_000_000).toFixed(n >= 10_000_000 ? 0 : 1).replace(".0", "") + "M";
  return "€" + Math.round(n / 1000) + "B";
}

export function cardTier(ovr: number): "bronze" | "silver" | "gold" | "icon" | "legend" {
  if (ovr >= 90) return "legend";
  if (ovr >= 85) return "icon";
  if (ovr >= 78) return "gold";
  if (ovr >= 70) return "silver";
  return "bronze";
}

export function attrColor(v: number): string {
  if (v >= 90) return "var(--stat-legend)";
  if (v >= 80) return "var(--stat-gold)";
  if (v >= 70) return "var(--stat-ok)";
  if (v >= 60) return "var(--stat-mid)";
  return "var(--stat-low)";
}

export function ratingColor(r: number): string {
  if (r >= 8.5) return "var(--stat-legend)";
  if (r >= 7.5) return "var(--stat-gold)";
  if (r >= 6.5) return "var(--stat-ok)";
  if (r >= 5.5) return "var(--stat-mid)";
  return "var(--stat-low)";
}

export function ageFromDob(dob: string, date: string): number {
  const a = new Date(dob + "T00:00:00");
  const b = new Date(date + "T00:00:00");
  let age = b.getFullYear() - a.getFullYear();
  const m = b.getMonth() - a.getMonth();
  if (m < 0 || (m === 0 && b.getDate() < a.getDate())) age -= 1;
  return age;
}

export function addDays(iso: string, days: number): string {
  const d = new Date(iso + "T00:00:00");
  d.setDate(d.getDate() + days);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return y + "-" + m + "-" + day;
}

export function trDate(iso: string): string {
  const [y, m, d] = iso.split("-");
  return d + "." + m + "." + y;
}
