let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let enabled = true;

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC({ latencyHint: "interactive" });
    master = ctx.createGain();
    master.gain.value = 0.18;
    master.connect(ctx.destination);
  }
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

export function unlockSound() {
  const c = getCtx();
  if (c && c.state === "suspended") void c.resume();
}

export function setSoundEnabled(on: boolean) {
  enabled = on;
  try {
    localStorage.setItem("fc_sound", on ? "1" : "0");
  } catch {
    /* ignore */
  }
}

export function isSoundEnabled(): boolean {
  if (typeof window === "undefined") return true;
  try {
    const v = localStorage.getItem("fc_sound");
    if (v === "0") return false;
  } catch {
    /* ignore */
  }
  return enabled;
}

function beep(freq: number, dur: number, type: OscillatorType, vol = 0.4, slide = 0) {
  if (!isSoundEnabled()) return;
  const c = getCtx();
  if (!c || !master) return;
  const t = c.currentTime;
  const o = c.createOscillator();
  const g = c.createGain();
  const f = c.createBiquadFilter();
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
  f.type = "lowpass";
  f.frequency.value = 2400;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol, t + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(f);
  f.connect(g);
  g.connect(master);
  o.start(t);
  o.stop(t + dur + 0.02);
}

export const Sound = {
  click() {
    beep(720, 0.05, "square", 0.22);
  },
  tap() {
    beep(520, 0.04, "triangle", 0.18);
  },
  pop() {
    beep(880, 0.08, "sine", 0.28, 200);
  },
  follow() {
    beep(660, 0.07, "sine", 0.24);
    setTimeout(() => beep(990, 0.09, "sine", 0.2), 70);
  },
  milestone() {
    beep(523, 0.12, "sine", 0.3);
    setTimeout(() => beep(659, 0.12, "sine", 0.28), 90);
    setTimeout(() => beep(784, 0.18, "sine", 0.3), 180);
  },
  kick() {
    beep(140, 0.12, "sine", 0.5, -80);
  },
  whistle() {
    beep(1800, 0.22, "square", 0.12);
  },
  goal() {
    beep(392, 0.1, "triangle", 0.32);
    setTimeout(() => beep(523, 0.12, "triangle", 0.3), 80);
    setTimeout(() => beep(659, 0.2, "triangle", 0.34), 170);
  },
  success() {
    beep(880, 0.08, "sine", 0.24);
    setTimeout(() => beep(1174, 0.12, "sine", 0.22), 80);
  },
  fail() {
    beep(220, 0.16, "sawtooth", 0.18, -80);
  },
  card() {
    beep(240, 0.14, "square", 0.2);
  },
  dm() {
    beep(1040, 0.06, "sine", 0.2);
    setTimeout(() => beep(1320, 0.08, "sine", 0.16), 60);
  },
};
