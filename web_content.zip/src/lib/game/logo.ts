import type { Emblem, Pattern, Team } from "./types";

function emblemPath(kind: Emblem | undefined, c: string): string {
  if (!kind) return "";
  if (kind === "star")
    return `<polygon points="50,28 54,40 67,40 56,48 60,60 50,52 40,60 44,48 33,40 46,40" fill="${c}"/>`;
  if (kind === "crown")
    return `<path d="M34 52 L34 40 L42 48 L50 34 L58 48 L66 40 L66 52 Z" fill="${c}"/>`;
  if (kind === "eagle")
    return `<path d="M50 34 C40 40 32 46 30 54 C40 50 44 52 50 60 C56 52 60 50 70 54 C68 46 60 40 50 34 Z" fill="${c}"/>`;
  if (kind === "lion")
    return `<path d="M42 38 C42 30 58 30 58 38 L60 50 C60 58 40 58 40 50 Z M46 42 H48 M52 42 H54" fill="${c}"/>`;
  if (kind === "shieldStar")
    return `<polygon points="50,32 54,42 64,42 56,48 59,58 50,52 41,58 44,48 36,42 46,42" fill="${c}"/>`;
  return `<rect x="44" y="38" width="12" height="12" transform="rotate(45 50 44)" fill="${c}"/>`;
}

function patternFill(p: Pattern, c1: string, c2: string): string {
  if (p === "ss")
    return `<rect x="5" y="5" width="90" height="110" fill="${c1}"/><rect x="20" y="5" width="12" height="110" fill="${c2}"/><rect x="44" y="5" width="12" height="110" fill="${c2}"/><rect x="68" y="5" width="12" height="110" fill="${c2}"/>`;
  if (p === "sd")
    return `<rect x="5" y="5" width="90" height="110" fill="${c1}"/><path d="M5 20 L95 115 L80 115 L5 35 Z" fill="${c2}"/><path d="M20 5 L95 85 L95 70 L35 5 Z" fill="${c2}"/>`;
  if (p === "sh")
    return `<rect x="5" y="5" width="90" height="55" fill="${c1}"/><rect x="5" y="55" width="90" height="60" fill="${c2}"/>`;
  if (p === "sc")
    return `<rect x="5" y="5" width="90" height="110" fill="${c1}"/><rect x="44" y="5" width="12" height="110" fill="${c2}"/><rect x="5" y="52" width="90" height="12" fill="${c2}"/>`;
  if (p === "c" || p === "cr")
    return `<rect x="5" y="5" width="90" height="110" fill="${c1}"/><circle cx="50" cy="52" r="22" fill="${c2}"/>`;
  return `<rect x="5" y="5" width="90" height="110" fill="${c1}"/>`;
}

const SHIELD = "M50 5 L95 20 L95 62 Q95 100 50 115 Q5 100 5 62 L5 20 Z";

export function teamLogoSvg(team: Team, size = 64): string {
  const clip = "s" + team.id.replace(/[^a-z0-9]/g, "");
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 120" width="${size}" height="${Math.round(size * 1.2)}" aria-hidden="true">
    <defs><clipPath id="${clip}"><path d="${SHIELD}"/></clipPath></defs>
    <path d="${SHIELD}" fill="${team.c1}" stroke="rgba(255,255,255,0.28)" stroke-width="2.4"/>
    <g clip-path="url(#${clip})">${patternFill(team.pattern, team.c1, team.c2)}</g>
    <path d="${SHIELD}" fill="none" stroke="rgba(0,0,0,0.35)" stroke-width="1.2"/>
    ${emblemPath(team.emblem, team.c2 === "#FFFFFF" || team.c2 === "#FDE100" ? team.c2 : "#F0EEE8")}
  </svg>`;
}
