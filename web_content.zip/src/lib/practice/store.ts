import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import {
  clampText,
  EMPTY_GRATITUDE,
  MAX_SAVED,
  todayKey,
  type Gratitude,
  type Kind,
  type MeritEntry,
  type SavedMantra,
  type SitLog,
  type AbstainDay,
  type AbstainMark,
} from "@/lib/practice/model";

const memoryStorage = {
  getItem: () => null,
  setItem: () => {},
  removeItem: () => {},
};

export interface PracticeState {
  selectedMantra: string;
  customMantra: string;
  savedMantras: SavedMantra[];
  dailyChantGoal: number;
  woodOn: boolean;
  bellOn: boolean;
  breathGuide: boolean;
  chantByDate: Record<string, Record<string, number>>;
  merits: MeritEntry[];
  vows: Record<string, string>;
  gratitudes: Record<string, Gratitude>;
  sits: SitLog[];
  abstainByDate: Record<string, AbstainDay>;
  abstainReason: string;
  addChant: (mantraId: string, n: number) => void;
  setSelectedMantra: (id: string) => void;
  setCustomMantra: (text: string) => void;
  addSavedMantra: (text: string) => string;
  removeSavedMantra: (id: string) => void;
  setGoal: (n: number) => void;
  setWoodOn: (on: boolean) => void;
  setBellOn: (on: boolean) => void;
  setBreathGuide: (on: boolean) => void;
  addMerit: (input: {
    kind: Kind;
    categoryId: string;
    label: string;
    points: number;
    note: string;
  }) => void;
  removeMerit: (id: string) => void;
  setVow: (date: string, text: string) => void;
  setGratitude: (date: string, patch: Partial<Gratitude>) => void;
  addSit: (input: { seconds: number; planned: number; finished: boolean }) => void;
  setAbstain: (date: string, patch: Partial<AbstainDay>) => void;
  setAbstainReason: (text: string) => void;
}

export const usePractice = create<PracticeState>()(
  persist(
    (set) => ({
      selectedMantra: "amitabha",
      customMantra: "",
      savedMantras: [],
      dailyChantGoal: 108,
      woodOn: true,
      bellOn: true,
      breathGuide: true,
      chantByDate: {},
      merits: [],
      vows: {},
      gratitudes: {},
      sits: [],
      abstainByDate: {},
      abstainReason: "",
      addChant: (mantraId, n) =>
        set((s) => {
          const date = todayKey();
          const day = { ...(s.chantByDate[date] ?? {}) };
          const next = Math.max(0, (day[mantraId] ?? 0) + n);
          if (next === 0) delete day[mantraId];
          else day[mantraId] = next;
          return { chantByDate: { ...s.chantByDate, [date]: day } };
        }),
      setSelectedMantra: (id) => set({ selectedMantra: id }),
      setCustomMantra: (text) => set({ customMantra: clampText(text, 40) }),
      addSavedMantra: (text) => {
        const next = clampText(text.trim(), 40);
        let id = "";
        set((s) => {
          if (!next || s.savedMantras.length >= MAX_SAVED) return s;
          const existing = s.savedMantras.find((item) => item.text === next);
          if (existing) {
            id = existing.id;
            return s;
          }
          id = "c-" + crypto.randomUUID();
          return { savedMantras: [...s.savedMantras, { id, text: next }] };
        });
        return id;
      },
      removeSavedMantra: (id) =>
        set((s) => ({
          savedMantras: s.savedMantras.filter((item) => item.id !== id),
          selectedMantra: s.selectedMantra === id ? "amitabha" : s.selectedMantra,
        })),
      setGoal: (n) => set({ dailyChantGoal: n }),
      setWoodOn: (on) => set({ woodOn: on }),
      setBellOn: (on) => set({ bellOn: on }),
      setBreathGuide: (on) => set({ breathGuide: on }),
      addMerit: (input) =>
        set((s) => ({
          merits: [
            {
              id: crypto.randomUUID(),
              date: todayKey(),
              kind: input.kind,
              categoryId: input.categoryId,
              label: input.label,
              points: input.points,
              note: clampText(input.note.trim(), 80),
              at: Date.now(),
            },
            ...s.merits,
          ].slice(0, 400),
        })),
      removeMerit: (id) => set((s) => ({ merits: s.merits.filter((e) => e.id !== id) })),
      setVow: (date, text) =>
        set((s) => {
          const vows = { ...s.vows };
          const next = clampText(text, 160);
          if (!next.trim()) delete vows[date];
          else vows[date] = next;
          return { vows };
        }),
      setGratitude: (date, patch) =>
        set((s) => {
          const prev = s.gratitudes[date] ?? EMPTY_GRATITUDE;
          const items = patch.items
            ? (patch.items.map((item) => clampText(item, 80)) as [string, string, string])
            : prev.items;
          const next: Gratitude = {
            items,
            reflection:
              patch.reflection !== undefined ? clampText(patch.reflection, 240) : prev.reflection,
            dedication:
              patch.dedication !== undefined ? clampText(patch.dedication, 80) : prev.dedication,
            updatedAt: Date.now(),
          };
          const meaningful =
            next.items.some((item) => item.trim()) ||
            next.reflection.trim() ||
            next.dedication.trim();
          const gratitudes = { ...s.gratitudes };
          if (!meaningful) delete gratitudes[date];
          else gratitudes[date] = next;
          return { gratitudes };
        }),
      addSit: (input) =>
        set((s) => ({
          sits: [
            {
              id: crypto.randomUUID(),
              date: todayKey(),
              seconds: input.seconds,
              planned: input.planned,
              finished: input.finished,
              at: Date.now(),
            },
            ...s.sits,
          ].slice(0, 400),
        })),
      setAbstain: (date, patch) =>
        set((s) => {
          const prev = s.abstainByDate[date] ?? { mark: null, note: "", checks: [] as string[] };
          const mark = (patch.mark === undefined ? prev.mark : patch.mark) as AbstainMark | null;
          const note = patch.note === undefined ? prev.note : clampText(patch.note, 80);
          const checks = patch.checks === undefined ? prev.checks : patch.checks;
          const next: AbstainDay = { mark, note, checks };
          const abstainByDate = { ...s.abstainByDate };
          if (!next.mark && !next.note.trim() && next.checks.length === 0) delete abstainByDate[date];
          else abstainByDate[date] = next;
          return { abstainByDate };
        }),
      setAbstainReason: (text) => set({ abstainReason: clampText(text, 160) }),
    }),
    {
      name: "xintian-v1",
      skipHydration: true,
      storage: createJSONStorage(() =>
        typeof window === "undefined" ? memoryStorage : localStorage,
      ),
      partialize: (s) => ({
        selectedMantra: s.selectedMantra,
        customMantra: s.customMantra,
        savedMantras: s.savedMantras,
        dailyChantGoal: s.dailyChantGoal,
        woodOn: s.woodOn,
        bellOn: s.bellOn,
        breathGuide: s.breathGuide,
        chantByDate: s.chantByDate,
        merits: s.merits,
        vows: s.vows,
        gratitudes: s.gratitudes,
        sits: s.sits,
        abstainByDate: s.abstainByDate,
        abstainReason: s.abstainReason,
      }),
      version: 1,
      migrate: (persisted) => {
        const state = persisted as {
          customMantra?: string;
          selectedMantra?: string;
          savedMantras?: SavedMantra[];
          chantByDate?: Record<string, Record<string, number>>;
        };
        if (!state.savedMantras) state.savedMantras = [];
        const legacy = state.customMantra?.trim();
        if (legacy && !state.savedMantras.some((item) => item.text === legacy) && state.savedMantras.length < MAX_SAVED) {
          const id = "c-legacy";
          state.savedMantras = [{ id, text: legacy.slice(0, 40) }, ...state.savedMantras];
          if (state.selectedMantra === "custom") state.selectedMantra = id;
          if (state.chantByDate) {
            for (const day of Object.values(state.chantByDate)) {
              if (!day.custom) continue;
              day[id] = (day[id] ?? 0) + day.custom;
              delete day.custom;
            }
          }
        }
        return state as typeof persisted;
      },
    },
  ),
);

export type SitPhase = "idle" | "running" | "paused" | "done";

interface SitSession {
  phase: SitPhase;
  plannedSec: number;
  endsAt: number | null;
  remainMs: number;
  logged: boolean;
  elapsedSec: number;
  start: (minutes: number) => void;
  pause: () => void;
  resume: () => void;
  end: (mode: "complete" | "keep" | "discard") => void;
  close: () => void;
}

export const useSit = create<SitSession>((set, get) => ({
  phase: "idle",
  plannedSec: 10 * 60,
  endsAt: null,
  remainMs: 0,
  logged: false,
  elapsedSec: 0,
  start: (minutes) =>
    set({
      phase: "running",
      plannedSec: minutes * 60,
      endsAt: Date.now() + minutes * 60 * 1000,
      remainMs: minutes * 60 * 1000,
      logged: false,
      elapsedSec: 0,
    }),
  pause: () => {
    const s = get();
    if (s.phase !== "running" || s.endsAt == null) return;
    set({
      phase: "paused",
      remainMs: Math.max(0, s.endsAt - Date.now()),
      endsAt: null,
    });
  },
  resume: () => {
    const s = get();
    if (s.phase !== "paused") return;
    set({ phase: "running", endsAt: Date.now() + s.remainMs });
  },
  end: (mode) => {
    const s = get();
    if (s.phase === "idle") return;
    if (mode === "discard") {
      set({ phase: "idle", logged: false, endsAt: null, remainMs: 0, elapsedSec: 0 });
      return;
    }
    if (s.logged && s.phase === "done") return;
    const remain =
      s.phase === "running" && s.endsAt != null ? Math.max(0, s.endsAt - Date.now()) : s.remainMs;
    const seconds =
      mode === "complete"
        ? s.plannedSec
        : Math.max(0, Math.round((s.plannedSec * 1000 - remain) / 1000));
    if (!s.logged && seconds >= 30) {
      usePractice.getState().addSit({
        seconds,
        planned: s.plannedSec,
        finished: mode === "complete",
      });
    }
    set({ phase: "done", logged: seconds >= 30, endsAt: null, remainMs: 0, elapsedSec: seconds });
  },
  close: () => set({ phase: "idle", logged: false, endsAt: null, remainMs: 0, elapsedSec: 0 }),
}));
