export type Tab = "today" | "chant" | "ledger" | "abstain" | "vow" | "thanks" | "sit";

export type Kind = "merit" | "fault";

export interface SavedMantra {
  id: string;
  text: string;
}

export interface Mantra {
  id: string;
  name: string;
  text: string;
}

export const MAX_SAVED = 4;

export interface Rubric {
  id: string;
  label: string;
  points: number;
  hint: string;
}

export interface MeritEntry {
  id: string;
  date: string;
  kind: Kind;
  categoryId: string;
  label: string;
  points: number;
  note: string;
  at: number;
}

export interface Gratitude {
  items: [string, string, string];
  reflection: string;
  dedication: string;
  updatedAt: number;
}

export interface SitLog {
  id: string;
  date: string;
  seconds: number;
  planned: number;
  finished: boolean;
  at: number;
}

export type AbstainMark = "kept" | "slipped";

export interface AbstainDay {
  mark: AbstainMark | null;
  note: string;
  checks: string[];
}

export const ABSTAIN_WAYS = [
  { id: "chant", label: "念頭來時，先念一聲佛" },
  { id: "sleep", label: "早些安歇，不熬夜看手機" },
  { id: "away", label: "避開會引動心的畫面" },
  { id: "move", label: "起身走動，或做一件小事" },
  { id: "exercise", label: "多運動。身動了，心便穩些" },
  { id: "diet", label: "少吃糖，飲食清淡，心便不那麼躁" },
  { id: "remember", label: "想起自己為何要守" },
] as const;

export const MALA = 108;

export const GOALS = [108, 500, 1000, 3000, 10000] as const;

export const SIT_MINUTES = [5, 10, 15, 20, 30, 45] as const;

export const MANTRAS: Mantra[] = [
  { id: "amitabha", name: "南無阿彌陀佛", text: "南無阿彌陀佛" },
  { id: "guanyin", name: "南無觀世音菩薩", text: "南無觀世音菩薩" },
  { id: "ksitigarbha", name: "南無地藏菩薩", text: "南無地藏菩薩" },
  { id: "mani", name: "六字大明咒", text: "嗡嘛呢唄咪吽" },
];

export const MERITS: Rubric[] = [
  { id: "help", label: "助人", points: 3, hint: "具體幫了別人一個忙" },
  { id: "give", label: "布施", points: 5, hint: "錢財、時間，或一句好話" },
  { id: "patience", label: "忍辱", points: 3, hint: "火起了，沒有發出去" },
  { id: "family", label: "孝親", points: 5, hint: "照料，或好好聽家人說話" },
  { id: "honest", label: "誠實", points: 2, hint: "本可以圓過去，卻沒有" },
  { id: "early", label: "早起", points: 2, hint: "比習慣更早起身" },
  { id: "meal", label: "素食", points: 2, hint: "這一餐，沒有傷生" },
  { id: "read", label: "讀經", points: 3, hint: "讀了一段經，或一段論" },
  { id: "speech", label: "好話", points: 2, hint: "讚歎、安慰，或止住是非" },
  { id: "body", label: "惜身", points: 2, hint: "喝水、走動，沒有暴食" },
  { id: "other-m", label: "其他善", points: 1, hint: "一件小小的善" },
];

export const FAULTS: Rubric[] = [
  { id: "lie", label: "妄語", points: 3, hint: "說了不實的話" },
  { id: "anger", label: "嗔心", points: 3, hint: "對人發怒，或心裡罵人" },
  { id: "greed", label: "貪念", points: 2, hint: "抓著不放，明知不必" },
  { id: "sloth", label: "懈怠", points: 2, hint: "該做的事，一再拖過" },
  { id: "waste", label: "浪費", points: 2, hint: "食物、時間，或金錢" },
  { id: "harsh", label: "惡口", points: 3, hint: "一句話，刺傷了人" },
  { id: "distract", label: "散亂", points: 1, hint: "本要修持，心卻走了" },
  { id: "other-f", label: "其他過", points: 1, hint: "一件想記得的過失" },
];

export const VOW_PRESETS = [
  "願我今日身口意清淨，不傷害任何人。",
  "願我看見習氣時，先停一下，再回應。",
  "願我對身邊的人，多一分耐心。",
  "願我好好吃飯、喝水、休息，珍惜這個身體。",
  "願今日所做的小事，都能利益眾生。",
];

export const DEDICATION_PRESETS = [
  "願此功德，回向一切眾生離苦得樂。",
  "願家人平安，煩惱輕一分。",
  "願今日過失到此為止，明日重新開始。",
];

const LINES = [
  "不必一次改掉一生。先守住這一念。",
  "念頭來了，可以看見，不必跟著走。",
  "功過不是分數，是一面照見自己的鏡子。",
  "守住今天，比想得很遠更要緊。",
  "靜坐不是清空。是讓念頭自己走過去。",
  "一聲佛號，就把散掉的心收回來。",
  "做得少不要緊。記得做，就有用。",
  "對自己誠實，比看起來精進更要緊。",
];

export const EMPTY_GRATITUDE: Gratitude = {
  items: ["", "", ""],
  reflection: "",
  dedication: "",
  updatedAt: 0,
};

const WEEK = ["週日", "週一", "週二", "週三", "週四", "週五", "週六"];

export function todayKey(d = new Date()) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function shiftDate(key: string, delta: number) {
  const [y, m, d] = key.split("-").map(Number);
  const dt = new Date(y, (m ?? 1) - 1, d ?? 1);
  dt.setDate(dt.getDate() + delta);
  return todayKey(dt);
}

export function labelOfKey(key: string, now = new Date()) {
  const [y, m, d] = key.split("-").map(Number);
  const dt = new Date(y, (m ?? 1) - 1, d ?? 1);
  const week = WEEK[dt.getDay()] ?? "";
  if (y !== now.getFullYear()) return `${y}年${m}月${d}日 ${week}`;
  return `${m}月${d}日 ${week}`;
}

export function formatChineseDate(d = new Date()) {
  return `${d.getMonth() + 1}月${d.getDate()}日 ${WEEK[d.getDay()]}`;
}

export function formatClock(ms: number) {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function formatTime(ts: number) {
  const d = new Date(ts);
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

export function formatMinutes(seconds: number) {
  const m = Math.max(0, Math.round(seconds / 60));
  if (m < 60) return `${m} 分鐘`;
  const h = Math.floor(m / 60);
  const r = m % 60;
  return r ? `${h} 小時 ${r} 分` : `${h} 小時`;
}

export type DayPart = "morning" | "day" | "evening";

export function dayPart(d = new Date()): DayPart {
  const h = d.getHours();
  if (h < 11) return "morning";
  if (h < 17) return "day";
  return "evening";
}

export function greeting(part: DayPart) {
  if (part === "morning") return { title: "早安", sub: "晨光還早，先安頓這一念。" };
  if (part === "day") return { title: "今日", sub: "不必趕。把心放在眼前。" };
  return { title: "晚安", sub: "今天到這裡，可以放下了。" };
}

export function lineFor(dateKey: string) {
  const n = Number(dateKey.replaceAll("-", ""));
  const i = Number.isFinite(n) ? Math.abs(n) % LINES.length : 0;
  return LINES[i] ?? LINES[0];
}

export function mantraById(id: string) {
  return MANTRAS.find((m) => m.id === id) ?? MANTRAS[0];
}

export function dayCounts(map: Record<string, Record<string, number>>, date: string) {
  return map[date] ?? {};
}

export function sumCounts(counts: Record<string, number>) {
  return Object.values(counts).reduce((n, v) => n + v, 0);
}

export function mantraTotal(map: Record<string, Record<string, number>>, id: string) {
  let n = 0;
  for (const day of Object.values(map)) n += day[id] ?? 0;
  return n;
}

export function allTotal(map: Record<string, Record<string, number>>) {
  let n = 0;
  for (const day of Object.values(map)) n += sumCounts(day);
  return n;
}

export function lastDays(n: number, today = todayKey()) {
  const keys: string[] = [];
  for (let i = n - 1; i >= 0; i--) keys.push(shiftDate(today, -i));
  return keys;
}

export function netOf(entries: MeritEntry[]) {
  return entries.reduce((n, e) => n + (e.kind === "merit" ? e.points : -e.points), 0);
}

export function formatNet(n: number) {
  if (n > 0) return `+${n}`;
  if (n < 0) return `−${Math.abs(n)}`;
  return "0";
}

export function gratitudeDone(g: Gratitude | undefined) {
  if (!g) return false;
  return g.items.some((item) => item.trim().length > 0);
}

export function isPracticed(
  input: {
    chantByDate: Record<string, Record<string, number>>;
    vows: Record<string, string>;
    gratitudes: Record<string, Gratitude>;
    sits: SitLog[];
    merits: MeritEntry[];
    abstainByDate?: Record<string, AbstainDay>;
  },
  date: string,
) {
  if (sumCounts(dayCounts(input.chantByDate, date)) > 0) return true;
  if ((input.vows[date] ?? "").trim()) return true;
  if (gratitudeDone(input.gratitudes[date])) return true;
  if (input.sits.some((sit) => sit.date === date && sit.seconds >= 30)) return true;
  if (input.merits.some((entry) => entry.date === date)) return true;
  if (input.abstainByDate?.[date]?.mark) return true;
  return false;
}

export function streakOf(
  input: Parameters<typeof isPracticed>[0],
  today = todayKey(),
) {
  let cursor = isPracticed(input, today) ? today : shiftDate(today, -1);
  let n = 0;
  while (isPracticed(input, cursor)) {
    n += 1;
    cursor = shiftDate(cursor, -1);
    if (n > 5000) break;
  }
  return n;
}

export function abstainStreak(map: Record<string, AbstainDay>, today = todayKey()) {
  const todayMark = map[today]?.mark;
  if (todayMark === "slipped") return 0;
  let cursor = todayMark === "kept" ? today : shiftDate(today, -1);
  let n = 0;
  while (map[cursor]?.mark === "kept") {
    n += 1;
    cursor = shiftDate(cursor, -1);
    if (n > 5000) break;
  }
  return n;
}

export function clampText(value: string, max: number) {
  return [...value].slice(0, max).join("");
}
