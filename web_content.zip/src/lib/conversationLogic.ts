export interface ConversationalIntent {
  isConfusionSimpler: boolean;
  isExplainDifferently: boolean;
  isWhyOrElaborate: boolean;
  isExampleRequest: boolean;
  isRepeatedQuestion: boolean;
  isHumorOrCasual: boolean;
  requestedLength: 'shorter' | 'longer' | null;
  hasPronounReference: boolean;
  isLikelyUnclearFragment: boolean;
}

function normalizeForComparison(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function analyzeConversationalIntent(
  message: string,
  history: Array<{ role: 'user' | 'assistant'; content: string }> = [],
): ConversationalIntent {
  const trimmed = message.trim();
  const lower = trimmed.toLowerCase();
  const normalizedCurrent = normalizeForComparison(trimmed);

  const isConfusionSimpler =
    /\b(didn'?t|did not|don'?t|do not|not|nahi|nhi|na)\s*(understand|get it|clear|samajh|smjh|samjha)\b/i.test(
      lower,
    ) ||
    /\b(samajh\s*(nahi|nhi|na)\s*(aaya|aya)|smjh\s*(ni|nhi)\s*(aya|aaya)|confus(ed|ing)|too\s*(hard|complex|technical)|in\s*simple\s*(words|terms|language)|simpler|simplify|aasaan|asan\s*bhasha)\b/i.test(
      lower,
    ) ||
    /(समझ नहीं|नहीं समझ|आसान भाषा|सरल शब्दों)/.test(trimmed);

  const isExplainDifferently =
    /\b(explain\s*(it\s*)?again|say\s*(that\s*)?again|different\s*(way|example|angle)|another\s*(way|explanation)|dobara\s*(batao|btao|samjhao|smjhao|bolo|bol)|phir\s*se\s*(batao|btao|samjhao|smjhao|bolo)|firse\s*(batao|btao|samjhao|smjhao|bolo)|ek\s*baari?\s*aur)\b/i.test(
      lower,
    ) || /(फिर से|दोबारा बताओ|दोबारा समझाओ)/.test(trimmed);

  const isExampleRequest =
    /\b(example|examples|for instance|show me how|demo|udaaharan|udaharan|misaal)\b/i.test(lower) ||
    /(उदाहरण)/.test(trimmed);

  const isWhyOrElaborate =
    /^(why|how|really|and|then|so|kyu|kyun|kyon|kaise|aur)\??!*$/i.test(trimmed) ||
    /\b(tell\s*me\s*more|go\s*on|continue|elaborate|more\s*details?|aur\s*batao|aur\s*bta|aage\s*batao|detail\s*mein|vistaar)\b/i.test(
      lower,
    ) ||
    /(और बताओ|क्यों|कैसे)\??/.test(trimmed);

  const hasPronounReference =
    trimmed.split(/\s+/).length <= 12 &&
    /\b(that|this|it|those|these|previous one|last one|above|same thing|ye|yeh|woh|wo|iska|uska|uske|iske|isme|usme)\b/i.test(
      lower,
    );

  const recentUserTurns = history
    .filter((h) => h.role === 'user')
    .slice(-8)
    .map((h) => normalizeForComparison(h.content))
    .filter(Boolean);

  const isRepeatedQuestion =
    normalizedCurrent.length >= 2 && recentUserTurns.includes(normalizedCurrent);

  const isHumorOrCasual =
    /\b(haha+|hehe+|lol+|lmao|rofl|joke|funny|kidding|sarcasm|mazak|mazaak|hasao|bore|bakwas|chill|bro|yaar|dude|buddy)\b/i.test(
      lower,
    ) || /[😂🤣😄😜🙃]/u.test(trimmed);

  let requestedLength: 'shorter' | 'longer' | null = null;
  if (
    /\b(shorter|short|brief|tldr|tl;dr|quick|chhota|kam\s*shabdon|summarize|summary)\b/i.test(lower)
  ) {
    requestedLength = 'shorter';
  } else if (
    /\b(longer|detailed|in\s*detail|deep\s*dive|thorough|elaborate|full\s*explanation|vistaar|detail\s*mein)\b/i.test(
      lower,
    )
  ) {
    requestedLength = 'longer';
  }

  const words = normalizedCurrent.split(' ').filter(Boolean);
  const isLikelyUnclearFragment =
    history.length === 0 &&
    words.length <= 2 &&
    !isConfusionSimpler &&
    !isExplainDifferently &&
    !isExampleRequest &&
    !isHumorOrCasual &&
    !/^(hi|hey|hello|namaste|yo|help|time|date|thanks|thank you|bye|ok|okay)$/i.test(
      normalizedCurrent,
    ) &&
    trimmed.length <= 8;

  return {
    isConfusionSimpler,
    isExplainDifferently,
    isWhyOrElaborate,
    isExampleRequest,
    isRepeatedQuestion,
    isHumorOrCasual,
    requestedLength,
    hasPronounReference,
    isLikelyUnclearFragment,
  };
}

export function buildTurnIntentDirective(intent: ConversationalIntent): string | null {
  const hints: string[] = [];

  if (intent.isConfusionSimpler) {
    hints.push(
      'TURN HINT: The user did not understand the prior point—re-explain the previous topic in much simpler, everyday words with a relatable analogy.',
    );
  } else if (intent.isExplainDifferently) {
    hints.push(
      'TURN HINT: The user wants it explained again—use a fresh angle or completely different explanation instead of repeating the earlier wording.',
    );
  }

  if (intent.isExampleRequest) {
    hints.push(
      'TURN HINT: Provide a clear, concrete example directly connected to the current topic in the conversation.',
    );
  }

  if (intent.isWhyOrElaborate || intent.hasPronounReference) {
    hints.push(
      'TURN HINT: This is a contextual follow-up—resolve references ("that", "this", "it", "why", "ye", "woh") from the immediate prior messages and continue seamlessly.',
    );
  }

  if (intent.isRepeatedQuestion) {
    hints.push(
      'TURN HINT: The user repeated an earlier question—answer it again cleanly, helpfully, and directly without pointing out that it was repeated.',
    );
  }

  if (intent.isHumorOrCasual) {
    hints.push(
      'TURN HINT: Light, humorous, or casual tone detected—respond warmly and naturally, matching the vibe without sounding stiff.',
    );
  }

  if (intent.requestedLength === 'shorter') {
    hints.push('TURN HINT: User asked for a shorter reply—keep it ultra-concise (1-2 sentences).');
  } else if (intent.requestedLength === 'longer') {
    hints.push('TURN HINT: User asked for a deeper/longer explanation—provide structured depth.');
  }

  if (intent.isLikelyUnclearFragment) {
    hints.push(
      'TURN HINT: Input looks very brief or incomplete—infer the most helpful interpretation or ask ONE short, natural clarification question.',
    );
  }

  return hints.length > 0 ? hints.join('\n') : null;
}
