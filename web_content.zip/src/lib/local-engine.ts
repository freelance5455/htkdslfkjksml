/** Deterministic helpers. These are not AI — answers are computed on device. */

const BN_DIGITS = "০১২৩৪৫৬৭৮৯";

export function normalizeDigits(input: string): string {
  return input.replace(/[০-৯]/g, (d) => String(BN_DIGITS.indexOf(d)));
}

export function formatNumber(n: number): string | null {
  if (!Number.isFinite(n)) return null;
  const rounded = Math.round(n * 1e8) / 1e8;
  return new Intl.NumberFormat("bn-BD", { maximumFractionDigits: 8 }).format(rounded);
}

function soften(raw: string): string {
  let s = normalizeDigits(raw).trim();
  s = s.replace(/[?？!！।]+$/g, "").trim();
  s = s.replace(/^(?:বলো|বলুন|calculate|what is|what's|কত)\s+/i, "");
  s = s.replace(/\s*(?:কত|কতো|হয়|হবে)\s*$/i, "");
  return s.replace(/\s+/g, " ").trim();
}

type Tok = number | string;

function tokenize(input: string): Tok[] | null {
  const s = input.replace(/×/g, "*").replace(/÷/g, "/").replace(/\s+/g, "");
  if (!s || !/^[\d.+\-*/%^()a-z]+$/i.test(s)) return null;
  const out: Tok[] = [];
  let i = 0;
  while (i < s.length) {
    const ch = s[i]!;
    if (/[0-9.]/.test(ch)) {
      let j = i + 1;
      while (j < s.length && /[0-9.]/.test(s[j]!)) j++;
      const num = Number(s.slice(i, j));
      if (!Number.isFinite(num)) return null;
      out.push(num);
      i = j;
      continue;
    }
    if (/[a-z]/i.test(ch)) {
      let j = i + 1;
      while (j < s.length && /[a-z]/i.test(s[j]!)) j++;
      out.push(s.slice(i, j).toLowerCase());
      i = j;
      continue;
    }
    out.push(ch);
    i++;
  }
  return out;
}

function evalMath(expr: string): number | null {
  const tokens = tokenize(expr);
  if (!tokens || tokens.length === 0) return null;
  let i = 0;
  const peek = () => tokens[i];
  const eat = () => tokens[i++];

  function parseAdd(): number {
    let left = parseMul();
    while (peek() === "+" || peek() === "-") {
      const op = eat();
      const right = parseMul();
      left = op === "+" ? left + right : left - right;
    }
    return left;
  }
  function parseMul(): number {
    let left = parsePow();
    while (peek() === "*" || peek() === "/") {
      const op = eat();
      const right = parsePow();
      if (op === "/" && right === 0) throw new Error("div0");
      left = op === "*" ? left * right : left / right;
    }
    return left;
  }
  function parsePow(): number {
    const base = parseUnary();
    if (peek() === "^") {
      eat();
      return base ** parsePow();
    }
    return base;
  }
  function parseUnary(): number {
    if (peek() === "+") {
      eat();
      return parseUnary();
    }
    if (peek() === "-") {
      eat();
      return -parseUnary();
    }
    if (peek() === "sqrt" || peek() === "abs") {
      const fn = eat();
      const inner = parseUnary();
      return fn === "sqrt" ? Math.sqrt(inner) : Math.abs(inner);
    }
    if (peek() === "(") {
      eat();
      const v = parseAdd();
      if (eat() !== ")") throw new Error("paren");
      return percent(v);
    }
    if (typeof peek() === "number") {
      const n = eat() as number;
      return percent(n);
    }
    throw new Error("token");
  }
  function percent(n: number): number {
    if (peek() === "%") {
      eat();
      return n / 100;
    }
    return n;
  }

  try {
    const value = parseAdd();
    if (i !== tokens.length || !Number.isFinite(value)) return null;
    return value;
  } catch {
    return null;
  }
}

const LENGTH: Record<string, number> = {
  mm: 0.001,
  cm: 0.01,
  m: 1,
  km: 1000,
  inch: 0.0254,
  ft: 0.3048,
  mi: 1609.344,
};

const WEIGHT: Record<string, number> = {
  mg: 0.001,
  g: 1,
  kg: 1000,
  lb: 453.59237,
  oz: 28.3495,
};

const VOLUME: Record<string, number> = {
  ml: 1,
  l: 1000,
  gal: 3785.411784,
};

const DATA: Record<string, number> = {
  b: 1,
  kb: 1024,
  mb: 1024 ** 2,
  gb: 1024 ** 3,
};

/** Dhaka customary land measure. Other districts differ — answers say so. */
const LAND_SQFT: Record<string, number> = {
  sqft: 1,
  shotok: 435.6,
  katha: 720,
  bigha: 14400,
  acre: 43560,
};

const UNIT_ALIAS: Record<string, { dim: "len" | "w" | "vol" | "data" | "temp" | "land"; id: string }> = {
  mm: { dim: "len", id: "mm" },
  millimeter: { dim: "len", id: "mm" },
  মিলিমিটার: { dim: "len", id: "mm" },
  cm: { dim: "len", id: "cm" },
  centimeter: { dim: "len", id: "cm" },
  সেন্টিমিটার: { dim: "len", id: "cm" },
  সেমি: { dim: "len", id: "cm" },
  m: { dim: "len", id: "m" },
  meter: { dim: "len", id: "m" },
  metre: { dim: "len", id: "m" },
  মিটার: { dim: "len", id: "m" },
  km: { dim: "len", id: "km" },
  kilometer: { dim: "len", id: "km" },
  kilometre: { dim: "len", id: "km" },
  কিমি: { dim: "len", id: "km" },
  কিলোমিটার: { dim: "len", id: "km" },
  inch: { dim: "len", id: "inch" },
  in: { dim: "len", id: "inch" },
  ইঞ্চি: { dim: "len", id: "inch" },
  ft: { dim: "len", id: "ft" },
  foot: { dim: "len", id: "ft" },
  feet: { dim: "len", id: "ft" },
  ফুট: { dim: "len", id: "ft" },
  mi: { dim: "len", id: "mi" },
  mile: { dim: "len", id: "mi" },
  miles: { dim: "len", id: "mi" },
  মাইল: { dim: "len", id: "mi" },
  mg: { dim: "w", id: "mg" },
  g: { dim: "w", id: "g" },
  gram: { dim: "w", id: "g" },
  গ্রাম: { dim: "w", id: "g" },
  kg: { dim: "w", id: "kg" },
  kilogram: { dim: "w", id: "kg" },
  কেজি: { dim: "w", id: "kg" },
  কিলোগ্রাম: { dim: "w", id: "kg" },
  lb: { dim: "w", id: "lb" },
  pound: { dim: "w", id: "lb" },
  পাউন্ড: { dim: "w", id: "lb" },
  oz: { dim: "w", id: "oz" },
  ounce: { dim: "w", id: "oz" },
  ml: { dim: "vol", id: "ml" },
  millilitre: { dim: "vol", id: "ml" },
  মিলি: { dim: "vol", id: "ml" },
  l: { dim: "vol", id: "l" },
  liter: { dim: "vol", id: "l" },
  litre: { dim: "vol", id: "l" },
  লিটার: { dim: "vol", id: "l" },
  gal: { dim: "vol", id: "gal" },
  gallon: { dim: "vol", id: "gal" },
  গ্যালন: { dim: "vol", id: "gal" },
  b: { dim: "data", id: "b" },
  byte: { dim: "data", id: "b" },
  kb: { dim: "data", id: "kb" },
  mb: { dim: "data", id: "mb" },
  gb: { dim: "data", id: "gb" },
  c: { dim: "temp", id: "c" },
  celcius: { dim: "temp", id: "c" },
  celsius: { dim: "temp", id: "c" },
  সেলসিয়াস: { dim: "temp", id: "c" },
  f: { dim: "temp", id: "f" },
  fahrenheit: { dim: "temp", id: "f" },
  ফারেনহাইট: { dim: "temp", id: "f" },
  k: { dim: "temp", id: "k" },
  kelvin: { dim: "temp", id: "k" },
  sqft: { dim: "land", id: "sqft" },
  বর্গফুট: { dim: "land", id: "sqft" },
  shotok: { dim: "land", id: "shotok" },
  decimal: { dim: "land", id: "shotok" },
  শতাংশ: { dim: "land", id: "shotok" },
  শতক: { dim: "land", id: "shotok" },
  katha: { dim: "land", id: "katha" },
  কাঠা: { dim: "land", id: "katha" },
  bigha: { dim: "land", id: "bigha" },
  বিঘা: { dim: "land", id: "bigha" },
  acre: { dim: "land", id: "acre" },
  একর: { dim: "land", id: "acre" },
};

const TABLES = { len: LENGTH, w: WEIGHT, vol: VOLUME, data: DATA, land: LAND_SQFT };

function lookupUnit(raw: string) {
  const key = raw.trim().toLowerCase().replace(/°/g, "");
  return UNIT_ALIAS[key] ?? UNIT_ALIAS[raw.trim()] ?? null;
}

function convertTemp(value: number, from: string, to: string): number | null {
  const toC = (v: number, u: string) => (u === "c" ? v : u === "f" ? ((v - 32) * 5) / 9 : v - 273.15);
  const fromC = (c: number, u: string) => (u === "c" ? c : u === "f" ? (c * 9) / 5 + 32 : c + 273.15);
  if (!["c", "f", "k"].includes(from) || !["c", "f", "k"].includes(to)) return null;
  return fromC(toC(value, from), to);
}

function tryUnit(s: string): string | null {
  const m = s.match(
    /^(-?[\d.]+)\s*([^\d\s]+)\s*(?:to|in|into|কে|এ|থেকে|হলে|→|->|=)?\s*([^\d\s]+)$/i,
  );
  if (!m) return null;
  const value = Number(m[1]);
  const from = lookupUnit(m[2] ?? "");
  const to = lookupUnit(m[3] ?? "");
  if (!from || !to || from.dim !== to.dim || !Number.isFinite(value)) return null;
  let out: number;
  if (from.dim === "temp") {
    const t = convertTemp(value, from.id, to.id);
    if (t === null) return null;
    out = t;
  } else {
    const table = TABLES[from.dim];
    out = (value * table[from.id]!) / table[to.id]!;
  }
  const pretty = formatNumber(out);
  if (!pretty) return null;
  const note =
    from.dim === "land"
      ? "\n\nঢাকার প্রচলিত হিসাব: ১ কাঠা = ৭২০ বর্গফুট, ১ বিঘা = ২০ কাঠা। অন্য এলাকায় কাঠা আলাদা হতে পারে।"
      : "";
  return `তাৎক্ষণিক রূপান্তর (অনলাইন AI নয়)\n\n${formatNumber(value)} ${m[2]} = ${pretty} ${m[3]}${note}`;
}

function tryPercent(s: string): string | null {
  const of = s.match(/^([\d.]+)\s*%\s*(?:of|এর)\s*([\d.]+)$/i);
  if (of) {
    const p = Number(of[1]);
    const base = Number(of[2]);
    const pretty = formatNumber((base * p) / 100);
    return pretty ? `তাৎক্ষণিক হিসাব (অনলাইন AI নয়)\n\n${formatNumber(base)}-এর ${formatNumber(p)}% = ${pretty}` : null;
  }
  const rev = s.match(/^([\d.]+)\s*(?:টাকার|টাকায়|এর)\s*([\d.]+)\s*%$/i);
  if (rev) {
    const base = Number(rev[1]);
    const p = Number(rev[2]);
    const pretty = formatNumber((base * p) / 100);
    return pretty ? `তাৎক্ষণিক হিসাব (অনলাইন AI নয়)\n\n${formatNumber(base)}-এর ${formatNumber(p)}% = ${pretty}` : null;
  }
  const off = s.match(/^([\d.]+)\s*(?:টাকায়|টাকার|টাকা)?\s*([\d.]+)\s*%\s*(?:ছাড়|discount)$/i);
  if (off) {
    const base = Number(off[1]);
    const p = Number(off[2]);
    const saved = (base * p) / 100;
    const pay = base - saved;
    const a = formatNumber(saved);
    const b = formatNumber(pay);
    return a && b
      ? `তাৎক্ষণিক হিসাব (অনলাইন AI নয়)\n\nছাড় ${a}। দিতে হবে ${b}।`
      : null;
  }
  return null;
}

function tryExpression(s: string): string | null {
  if (!/^[\d.\s+\-*/%^()a-z×÷]+$/i.test(s)) return null;
  if (!/\d/.test(s)) return null;
  const value = evalMath(s);
  if (value === null) return null;
  const pretty = formatNumber(value);
  if (!pretty) return null;
  return `তাৎক্ষণিক হিসাব (অনলাইন AI নয়)\n\n= ${pretty}`;
}

/** Returns a full reply when the message can be answered without the model. */
export function tryLocal(raw: string): string | null {
  const s = soften(raw);
  if (!s || s.length > 200) return null;
  return tryPercent(s) ?? tryUnit(s) ?? tryExpression(s);
}

export function countText(text: string) {
  const chars = [...text].length;
  const charsNoSpace = [...text.replace(/\s/g, "")].length;
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  const lines = text ? text.split(/\r?\n/).length : 0;
  const minutes = Math.max(1, Math.round(words / 180)) ;
  return { chars, charsNoSpace, words, lines, minutes: words === 0 ? 0 : minutes };
}

export function utf8ToBase64(text: string): string {
  const bytes = new TextEncoder().encode(text);
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin);
}

export function base64ToUtf8(b64: string): string {
  const bin = atob(b64.trim());
  const bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
  return new TextDecoder().decode(bytes);
}

export function prettyJson(text: string): { ok: true; text: string } | { ok: false; error: string } {
  try {
    return { ok: true, text: JSON.stringify(JSON.parse(text), null, 2) };
  } catch {
    return { ok: false, error: "এটি বৈধ JSON নয়।" };
  }
}

export function makePassword(length: number, symbols: boolean): string {
  const alphabet = symbols
    ? "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%*"
    : "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
  const size = Math.min(64, Math.max(8, Math.round(length)));
  const buf = new Uint32Array(size);
  crypto.getRandomValues(buf);
  return Array.from(buf, (n) => alphabet[n % alphabet.length]).join("");
}

export function dateSpan(from: string, to: string): string | null {
  const a = new Date(`${from}T00:00:00`);
  const b = new Date(`${to}T00:00:00`);
  if (Number.isNaN(a.getTime()) || Number.isNaN(b.getTime())) return null;
  const ms = b.getTime() - a.getTime();
  const days = Math.round(ms / 86400000);
  const sign = days < 0 ? "আগে" : "পরে";
  const abs = Math.abs(days);
  const weeks = Math.floor(abs / 7);
  const rem = abs % 7;
  return `${formatNumber(abs)} দিন (${formatNumber(weeks)} সপ্তাহ ${formatNumber(rem)} দিন)। শেষ তারিখটি প্রথমটির ${sign}।`;
}
