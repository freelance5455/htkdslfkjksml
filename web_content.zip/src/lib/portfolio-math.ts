import { findCatalog } from "./catalog";
import { inflationFactor } from "./inflation";
import type {
  AssetClass,
  CapitalPlan,
  Currency,
  Fx,
  FxPoint,
  Goal,
  Holding,
  MarketPoint,
  MarketSnapshot,
  PortfolioState,
  Subscription,
} from "./types";

export type PositionView = {
  holding: Holding;
  price: number;
  native: number;
  huf: number;
  usd: number;
  costHuf: number;
  pricePnlHuf: number;
  fxPnlHuf: number;
  totalPnlHuf: number;
};

export function fxToHuf(currency: Currency, fx: Fx): number {
  if (currency === "HUF") return 1;
  if (currency === "EUR") return fx.eurHuf;
  if (currency === "GBP") return fx.gbpHuf;
  return fx.usdHuf;
}

export function unitPrice(holding: Holding, market: MarketSnapshot): number {
  if (holding.assetClass === "keszpenz") return 1;
  const quote = market.quotes[holding.symbol];
  if (quote && quote.price > 0) return quote.price;
  if (holding.manualPrice && holding.manualPrice > 0) return holding.manualPrice;
  const known = findCatalog(holding.symbol);
  if (known) return known.fallback;
  return holding.avgCost || 0;
}

export function viewHolding(holding: Holding, market: MarketSnapshot): PositionView {
  const fx = market.fx;
  const price = unitPrice(holding, market);
  const nowFx = fxToHuf(holding.currency, fx);
  const costFx = holding.costFxToHuf > 0 ? holding.costFxToHuf : nowFx;
  const native = holding.quantity * price;
  const huf = native * nowFx;
  const costHuf = holding.quantity * holding.avgCost * costFx;
  const pricePnlHuf = holding.quantity * (price - holding.avgCost) * costFx;
  const fxPnlHuf = holding.quantity * price * (nowFx - costFx);
  return {
    holding,
    price,
    native,
    huf,
    usd: fx.usdHuf > 0 ? huf / fx.usdHuf : 0,
    costHuf,
    pricePnlHuf,
    fxPnlHuf,
    totalPnlHuf: huf - costHuf,
  };
}

export function viewsOf(state: PortfolioState, groupId?: string): PositionView[] {
  return state.holdings
    .filter((holding) => !groupId || holding.groupId === groupId)
    .map((holding) => viewHolding(holding, state.market));
}

export function sumViews(rows: PositionView[]) {
  return rows.reduce(
    (acc, row) => {
      acc.huf += row.huf;
      acc.usd += row.usd;
      acc.costHuf += row.costHuf;
      acc.pricePnlHuf += row.pricePnlHuf;
      acc.fxPnlHuf += row.fxPnlHuf;
      return acc;
    },
    { huf: 0, usd: 0, costHuf: 0, pricePnlHuf: 0, fxPnlHuf: 0 },
  );
}

export type Bucket = {
  id: string;
  label: string;
  huf: number;
  usd: number;
};

export function allocation(state: PortfolioState, mode: "class" | "group"): Bucket[] {
  const rows = viewsOf(state);
  const map = new Map<string, Bucket>();
  for (const row of rows) {
    const id = mode === "class" ? row.holding.assetClass : row.holding.groupId;
    const label =
      mode === "class"
        ? classLabel(row.holding.assetClass)
        : (state.groups.find((group) => group.id === id)?.name ?? "Csoport nélkül");
    const prev = map.get(id) ?? { id, label, huf: 0, usd: 0 };
    prev.huf += row.huf;
    prev.usd += row.usd;
    map.set(id, prev);
  }
  return [...map.values()].sort((a, b) => b.huf - a.huf);
}

function classLabel(assetClass: AssetClass): string {
  if (assetClass === "etf") return "ETF";
  if (assetClass === "reszveny") return "Részvény";
  if (assetClass === "kripto") return "Kripto";
  return "Készpénz";
}

export function toHuf(amount: number, currency: Currency, fx: Fx): number {
  return amount * fxToHuf(currency, fx);
}

export function monthlySubscriptionHuf(item: Subscription, fx: Fx): number {
  const huf = toHuf(item.amount, item.currency, fx);
  if (item.cadence === "heti") return (huf * 52) / 12;
  if (item.cadence === "eves") return huf / 12;
  return huf;
}

export function subscriptionTotals(items: Subscription[], fx: Fx) {
  const active = items.filter((item) => item.active);
  const monthly = active.reduce((sum, item) => sum + monthlySubscriptionHuf(item, fx), 0);
  const wasteful = active
    .filter((item) => item.wasteful)
    .reduce((sum, item) => sum + monthlySubscriptionHuf(item, fx), 0);
  return { monthly, annual: monthly * 12, wastefulMonthly: wasteful, wastefulAnnual: wasteful * 12 };
}

export function goalCurrentHuf(goal: Goal, state: PortfolioState): number {
  const rows = viewsOf(state).filter(
    (row) => goal.groupIds.length === 0 || goal.groupIds.includes(row.holding.groupId),
  );
  return sumViews(rows).huf;
}

export function goalTargetHuf(goal: Goal, state: PortfolioState, today: string): number {
  const nominal = toHuf(goal.target, goal.currency, state.market.fx);
  if (!goal.real) return nominal;
  const base = state.inflationBase || state.capitalPlan.startDate;
  return nominal * inflationFactor(base, today);
}

export function realHuf(nominal: number, base: string, today: string): number {
  const factor = inflationFactor(base, today);
  if (factor <= 0) return nominal;
  return nominal / factor;
}

function nearest<T extends { date: string }>(series: T[], date: string): T | null {
  let best: T | null = null;
  for (const point of series) {
    if (point.date <= date) best = point;
    else break;
  }
  return best ?? series[0] ?? null;
}

function fxOn(market: MarketSnapshot, date: string): Fx {
  const point = nearest(market.fxHistory, date);
  if (!point) return market.fx;
  return { usdHuf: point.usdHuf, eurHuf: point.eurHuf, gbpHuf: point.gbpHuf };
}

function securityHufAt(holding: Holding, date: string, market: MarketSnapshot): number | null {
  if (holding.assetClass === "keszpenz") return null;
  const series: MarketPoint[] = market.history[holding.symbol] ?? [];
  const point = nearest(series, date);
  if (!point) return null;
  const fx = fxOn(market, date);
  if (fx.usdHuf <= 0) return null;
  return holding.quantity * point.usd * fx.usdHuf;
}

export function cashHuf(state: PortfolioState): number {
  return sumViews(viewsOf(state).filter((row) => row.holding.assetClass === "keszpenz")).huf;
}

export type CapitalPoint = { date: string; toke: number; ertek: number | null };

export function capitalSeries(state: PortfolioState, today: string): CapitalPoint[] {
  const plan: CapitalPlan = state.capitalPlan;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(plan.startDate)) return [];
  const start = new Date(`${plan.startDate}T00:00:00`);
  const end = new Date(`${today}T00:00:00`);
  if (Number.isNaN(start.getTime()) || start > end) return [];
  const cash = cashHuf(state);
  const points: CapitalPoint[] = [];
  const cursor = new Date(start.getFullYear(), start.getMonth(), 1);
  let index = 0;
  while (cursor <= end && index < 180) {
    const date = toIso(cursor);
    let securities = 0;
    let priced = 0;
    for (const holding of state.holdings) {
      const value = securityHufAt(holding, date, state.market);
      if (value == null) continue;
      securities += value;
      priced += 1;
    }
    points.push({
      date,
      toke: plan.initialHuf + index * plan.monthlyHuf,
      ertek: priced > 0 ? securities + cash : null,
    });
    cursor.setMonth(cursor.getMonth() + 1);
    index += 1;
  }
  if (points.length) {
    const totals = sumViews(viewsOf(state));
    points[points.length - 1] = {
      ...points[points.length - 1],
      date: today,
      ertek: totals.huf,
    };
  }
  return points;
}

export type ClassPoint = {
  date: string;
  etf: number | null;
  reszveny: number | null;
  kripto: number | null;
};

export function classUsdSeries(state: PortfolioState): ClassPoint[] {
  const classes: Array<Exclude<AssetClass, "keszpenz">> = ["etf", "reszveny", "kripto"];
  const dates = new Set<string>();
  for (const holding of state.holdings) {
    if (holding.assetClass === "keszpenz") continue;
    for (const point of state.market.history[holding.symbol] ?? []) dates.add(point.date);
  }
  const sorted = [...dates].sort();
  return sorted.map((date) => {
    const row: ClassPoint = { date, etf: 0, reszveny: 0, kripto: 0 };
    const seen: Record<string, number> = { etf: 0, reszveny: 0, kripto: 0 };
    for (const holding of state.holdings) {
      if (holding.assetClass === "keszpenz") continue;
      const point = nearest(state.market.history[holding.symbol] ?? [], date);
      if (!point) continue;
      row[holding.assetClass] = (row[holding.assetClass] ?? 0) + holding.quantity * point.usd;
      seen[holding.assetClass] += 1;
    }
    for (const key of classes) {
      if (!seen[key]) row[key] = null;
    }
    return row;
  });
}

export function investedToDate(plan: CapitalPlan, today: string): number {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(plan.startDate)) return plan.initialHuf;
  const start = new Date(`${plan.startDate}T00:00:00`);
  const end = new Date(`${today}T00:00:00`);
  if (Number.isNaN(start.getTime()) || end < start) return plan.initialHuf;
  const months =
    (end.getFullYear() - start.getFullYear()) * 12 + (end.getMonth() - start.getMonth());
  return plan.initialHuf + Math.max(0, months) * plan.monthlyHuf;
}

export function yearsToTarget(
  present: number,
  monthly: number,
  target: number,
  annualReturnPct: number,
): number | null {
  if (present >= target) return 0;
  if (target <= 0) return 0;
  const r = annualReturnPct / 100 / 12;
  if (monthly <= 0 && r <= 0) return null;
  if (Math.abs(r) < 1e-8) {
    if (monthly <= 0) return null;
    return (target - present) / monthly / 12;
  }
  const base = present + monthly / r;
  if (base <= 0) return null;
  const ratio = (target + monthly / r) / base;
  if (ratio <= 0) return null;
  const months = Math.log(ratio) / Math.log(1 + r);
  if (!Number.isFinite(months) || months < 0) return null;
  return months / 12;
}

function toIso(date: Date): string {
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${date.getFullYear()}-${month}-${day}`;
}

export function addMonthsIso(iso: string, months: number): string {
  const date = new Date(`${iso}T00:00:00`);
  if (Number.isNaN(date.getTime())) return iso;
  date.setMonth(date.getMonth() + Math.round(months));
  return toIso(date);
}

export function applyTrade(holdings: Holding[], tx: {
  side: "vetel" | "eladas";
  symbol: string;
  name: string;
  assetClass: AssetClass;
  currency: Currency;
  groupId: string;
  quantity: number;
  price: number;
  fxToHuf: number;
  yahoo?: string;
  gecko?: string;
}): Holding[] {
  const index = holdings.findIndex(
    (holding) =>
      holding.symbol === tx.symbol &&
      holding.groupId === tx.groupId &&
      holding.assetClass === tx.assetClass,
  );
  if (tx.side === "vetel") {
    if (index === -1) {
      return [
        ...holdings,
        {
          id: crypto.randomUUID(),
          symbol: tx.symbol,
          name: tx.name,
          assetClass: tx.assetClass,
          currency: tx.currency,
          groupId: tx.groupId,
          quantity: tx.quantity,
          avgCost: tx.price,
          costFxToHuf: tx.fxToHuf,
          yahoo: tx.yahoo,
          gecko: tx.gecko,
        },
      ];
    }
    const current = holdings[index];
    const quantity = current.quantity + tx.quantity;
    const avgCost = quantity ? (current.quantity * current.avgCost + tx.quantity * tx.price) / quantity : 0;
    const costFx = quantity
      ? (current.quantity * current.costFxToHuf + tx.quantity * tx.fxToHuf) / quantity
      : tx.fxToHuf;
    return holdings.map((holding, i) =>
      i === index ? { ...current, quantity, avgCost, costFxToHuf: costFx, name: tx.name || current.name } : holding,
    );
  }
  if (index === -1) return holdings;
  const current = holdings[index];
  const quantity = current.quantity - tx.quantity;
  if (quantity <= 1e-8) return holdings.filter((_, i) => i !== index);
  return holdings.map((holding, i) => (i === index ? { ...current, quantity } : holding));
}
