import { createServerFn } from "@tanstack/react-start";

const UA = "AetherConsole/1.0 (tablet multimedia screen)";

export type PlaceHit = { id: string; label: string; lat: number; lon: number };

export type TrackHit = {
  id: string;
  title: string;
  author: string;
  duration: number;
};

export type LineString = {
  type: "LineString";
  coordinates: [number, number][];
};

export type RouteInfo = {
  distanceM: number;
  durationS: number;
  geometry: LineString;
};

const PIPED = ["https://api.piped.private.coffee"];

function asNumber(value: unknown): number | null {
  const number = typeof value === "number" ? value : Number(value);
  return Number.isFinite(number) ? number : null;
}

function clampQuery(value: unknown): string {
  if (typeof value !== "string") throw new Error("Consulta inválida");
  const query = value.trim().slice(0, 100);
  if (query.length < 2) throw new Error("Escribe al menos 2 caracteres");
  return query;
}

function coord(value: unknown, min: number, max: number): number {
  const number = asNumber(value);
  if (number == null || number < min || number > max) throw new Error("Coordenadas inválidas");
  return number;
}

async function getJson(url: string): Promise<unknown> {
  const response = await fetch(url, {
    headers: { Accept: "application/json", "User-Agent": UA },
    signal: AbortSignal.timeout(9000),
  });
  if (!response.ok) throw new Error(String(response.status));
  return response.json();
}

export const searchPlaces = createServerFn({ method: "GET" })
  .validator((data: { q: string }) => ({ q: clampQuery(data?.q) }))
  .handler(async ({ data }): Promise<{ ok: true; hits: PlaceHit[] } | { ok: false; error: string }> => {
    try {
      const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&limit=6&q=${encodeURIComponent(data.q)}`;
      const json = await getJson(url);
      if (!Array.isArray(json)) return { ok: true, hits: [] };
      const hits: PlaceHit[] = [];
      for (const row of json) {
        if (!row || typeof row !== "object") continue;
        const record = row as Record<string, unknown>;
        const lat = asNumber(record.lat);
        const lon = asNumber(record.lon);
        const label = typeof record.display_name === "string" ? record.display_name : "";
        if (lat == null || lon == null || !label) continue;
        hits.push({
          id: String(record.place_id ?? `${lat},${lon}`),
          label: label.split(",").slice(0, 3).join(",").trim(),
          lat,
          lon,
        });
      }
      return { ok: true, hits };
    } catch {
      return { ok: false, error: "No se pudo buscar el lugar. Inténtalo de nuevo." };
    }
  });

export const reversePlace = createServerFn({ method: "GET" })
  .validator((data: { lat: number; lon: number }) => ({
    lat: coord(data?.lat, -90, 90),
    lon: coord(data?.lon, -180, 180),
  }))
  .handler(async ({ data }): Promise<{ ok: true; label: string } | { ok: false; error: string }> => {
    try {
      const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=14&addressdetails=1&lat=${data.lat}&lon=${data.lon}`;
      const json = await getJson(url);
      if (!json || typeof json !== "object") return { ok: false, error: "sin lugar" };
      const record = json as Record<string, unknown>;
      const address =
        record.address && typeof record.address === "object"
          ? (record.address as Record<string, unknown>)
          : {};
      const parts = [
        address.suburb,
        address.neighbourhood,
        address.city,
        address.town,
        address.village,
        address.state,
      ].filter((part): part is string => typeof part === "string" && part.length > 0);
      const label = [...new Set(parts)].slice(0, 2).join(", ");
      return { ok: true, label: label || (typeof record.name === "string" ? record.name : "Tu zona") };
    } catch {
      return { ok: false, error: "sin lugar" };
    }
  });

export const routeDrive = createServerFn({ method: "GET" })
  .validator((data: { fromLat: number; fromLon: number; toLat: number; toLon: number }) => ({
    fromLat: coord(data?.fromLat, -90, 90),
    fromLon: coord(data?.fromLon, -180, 180),
    toLat: coord(data?.toLat, -90, 90),
    toLon: coord(data?.toLon, -180, 180),
  }))
  .handler(async ({ data }): Promise<{ ok: true; route: RouteInfo } | { ok: false; error: string }> => {
    try {
      const url = `https://router.project-osrm.org/route/v1/driving/${data.fromLon},${data.fromLat};${data.toLon},${data.toLat}?overview=full&geometries=geojson`;
      const json = (await getJson(url)) as {
        routes?: Array<{ distance?: number; duration?: number; geometry?: LineString }>;
      };
      const route = json.routes?.[0];
      if (!route?.geometry || route.geometry.type !== "LineString" || !Array.isArray(route.geometry.coordinates)) {
        return { ok: false, error: "No hay ruta en coche entre estos puntos." };
      }
      return {
        ok: true,
        route: {
          distanceM: route.distance ?? 0,
          durationS: route.duration ?? 0,
          geometry: route.geometry,
        },
      };
    } catch {
      return { ok: false, error: "El cálculo de ruta no respondió." };
    }
  });

export const searchTracks = createServerFn({ method: "GET" })
  .validator((data: { q: string }) => ({ q: clampQuery(data?.q) }))
  .handler(async ({ data }): Promise<{ ok: true; tracks: TrackHit[] } | { ok: false; error: string }> => {
    for (const host of PIPED) {
      try {
        const url = `${host}/search?q=${encodeURIComponent(data.q)}&filter=music_songs`;
        const json = (await getJson(url)) as { items?: unknown[] };
        if (!Array.isArray(json.items)) continue;
        const tracks: TrackHit[] = [];
        for (const item of json.items) {
          if (!item || typeof item !== "object") continue;
          const record = item as Record<string, unknown>;
          if (record.type !== "stream" || typeof record.url !== "string" || typeof record.title !== "string") {
            continue;
          }
          const id = new URL(record.url, "https://example.com").searchParams.get("v");
          if (!id) continue;
          tracks.push({
            id,
            title: record.title,
            author: typeof record.uploaderName === "string" ? record.uploaderName : "YouTube",
            duration: typeof record.duration === "number" ? record.duration : 0,
          });
          if (tracks.length >= 12) break;
        }
        if (tracks.length > 0) return { ok: true, tracks };
      } catch {
        continue;
      }
    }
    return {
      ok: false,
      error: "YouTube Music no respondió. Prueba de nuevo o abre el enlace directo.",
    };
  });
