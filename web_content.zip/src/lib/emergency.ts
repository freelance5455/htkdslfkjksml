const EMERGENCY = new Set([
  "911",
  "112",
  "999",
  "000",
  "100",
  "101",
  "102",
  "108",
  "1091",
  "190",
  "110",
]);

export function digitsOnly(value: string): string {
  return value.replace(/\D/g, "");
}

export function normalizeNumber(value: string): string {
  const trimmed = value.trim();
  if (!trimmed) return "";
  const plus = trimmed.startsWith("+");
  const digits = digitsOnly(trimmed);
  return plus ? `+${digits}` : digits;
}

export function last10(value: string): string {
  const d = digitsOnly(value);
  return d.slice(-10);
}

export function numbersMatch(a: string, b: string): boolean {
  const da = digitsOnly(a);
  const db = digitsOnly(b);
  if (!da || !db) return false;
  if (da === db) return true;
  return last10(da) === last10(db) && last10(da).length >= 7;
}

export function isEmergencyNumber(value: string): boolean {
  const d = digitsOnly(value);
  if (!d) return false;
  if (EMERGENCY.has(d)) return true;
  if (d.startsWith("911") && d.length <= 4) return true;
  return false;
}

export function formatPhone(value: string): string {
  const n = value.trim();
  if (!n) return "";
  const d = digitsOnly(n);
  if (n.startsWith("+91") && d.length === 12) {
    return `+91 ${d.slice(2, 7)} ${d.slice(7)}`;
  }
  if (n.startsWith("+") && d.length > 4) {
    return `+${d.slice(0, d.length - 10)} ${d.slice(-10, -5)} ${d.slice(-5)}`.replace(
      /\s+/g,
      " ",
    );
  }
  if (d.length === 10) return `${d.slice(0, 5)} ${d.slice(5)}`;
  return n;
}
