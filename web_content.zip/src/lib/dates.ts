import {
  addDays,
  differenceInCalendarDays,
  eachDayOfInterval,
  format,
  isAfter,
  isBefore,
  isSameDay,
  parseISO,
  startOfDay,
} from "date-fns";
import { ptBR } from "date-fns/locale";
import type { DailyLog, Settings, Weekday } from "./types";

export const PROJECT_START = startOfDay(new Date(2026, 8, 21));
export const PROJECT_END = startOfDay(new Date(2026, 11, 30));
export const PROJECT_DAYS = 101;

export const WEEKDAYS: Weekday[] = [
  "segunda",
  "terca",
  "quarta",
  "quinta",
  "sexta",
  "sabado",
  "domingo",
];

export const WEEKDAY_LABEL: Record<Weekday, string> = {
  segunda: "Segunda",
  terca: "Terça",
  quarta: "Quarta",
  quinta: "Quinta",
  sexta: "Sexta",
  sabado: "Sábado",
  domingo: "Domingo",
};

const JS_DAY_TO_KEY: Weekday[] = [
  "domingo",
  "segunda",
  "terca",
  "quarta",
  "quinta",
  "sexta",
  "sabado",
];

export function toDateKey(d: Date) {
  return format(d, "yyyy-MM-dd");
}

export function parseDateKey(key: string) {
  return startOfDay(parseISO(key));
}

export function weekdayFromDate(d: Date): Weekday {
  return JS_DAY_TO_KEY[d.getDay()] ?? "segunda";
}

export function weekdayFromKey(key: string): Weekday {
  return weekdayFromDate(parseDateKey(key));
}

export function formatLongDate(d: Date | string) {
  const date = typeof d === "string" ? parseDateKey(d) : d;
  return format(date, "d 'de' MMMM yyyy", { locale: ptBR });
}

export function formatShortDate(d: Date | string) {
  const date = typeof d === "string" ? parseDateKey(d) : d;
  return format(date, "dd/MM/yyyy");
}

export function formatWeekdayDate(d: Date | string) {
  const date = typeof d === "string" ? parseDateKey(d) : d;
  return format(date, "EEEE, d MMM", { locale: ptBR });
}

export function projectDayNumber(d: Date) {
  const date = startOfDay(d);
  if (isBefore(date, PROJECT_START)) return 0;
  if (isAfter(date, PROJECT_END)) return PROJECT_DAYS;
  return differenceInCalendarDays(date, PROJECT_START) + 1;
}

export function isInProject(d: Date) {
  const date = startOfDay(d);
  return !isBefore(date, PROJECT_START) && !isAfter(date, PROJECT_END);
}

export function allProjectDates() {
  return eachDayOfInterval({ start: PROJECT_START, end: PROJECT_END }).map(
    toDateKey,
  );
}

export function daysUntil(target: Date, from: Date) {
  return differenceInCalendarDays(startOfDay(target), startOfDay(from));
}

export function projectProgressPct(d: Date) {
  if (isBefore(startOfDay(d), PROJECT_START)) return 0;
  const n = projectDayNumber(d);
  return Math.round((n / PROJECT_DAYS) * 100);
}

export function emptyLog(date: string): DailyLog {
  return {
    date,
    skinCare: { cleansing: false, moisturizer: false, sunscreen: false },
    waterMl: 0,
    sleepHours: null,
    food: {
      completeMeals: false,
      fruitsVeggies: false,
      protein: false,
      reducedUltra: false,
    },
    posture: false,
    workout: false,
    notes: "",
    extraHabits: {},
  };
}

export type DayStatus = "complete" | "partial" | "empty";

export function getDayChecks(log: DailyLog | undefined, settings: Settings) {
  if (!log) {
    return {
      skinCare: false,
      water: false,
      sleep: false,
      food: false,
      posture: false,
      workout: false,
      extras: [] as { id: string; name: string; done: boolean }[],
      doneCount: 0,
      total: 6 + settings.extraHabits.length,
    };
  }
  const skinCare =
    log.skinCare.cleansing &&
    log.skinCare.moisturizer &&
    log.skinCare.sunscreen;
  const water = log.waterMl >= settings.waterGoalMl;
  const sleep =
    log.sleepHours != null && log.sleepHours >= settings.sleepGoalHours;
  const food =
    log.food.completeMeals &&
    log.food.fruitsVeggies &&
    log.food.protein &&
    log.food.reducedUltra;
  const extras = settings.extraHabits.map((h) => ({
    ...h,
    done: Boolean(log.extraHabits[h.id]),
  }));
  const flags = [skinCare, water, sleep, food, log.posture, log.workout];
  const doneCount =
    flags.filter(Boolean).length + extras.filter((e) => e.done).length;
  return {
    skinCare,
    water,
    sleep,
    food,
    posture: log.posture,
    workout: log.workout,
    extras,
    doneCount,
    total: 6 + extras.length,
  };
}

export function getDayStatus(
  log: DailyLog | undefined,
  settings: Settings,
): DayStatus {
  if (!log) return "empty";
  const c = getDayChecks(log, settings);
  if (c.doneCount === 0 && log.waterMl === 0 && log.sleepHours == null) {
    return "empty";
  }
  if (c.doneCount >= c.total) return "complete";
  return "partial";
}

export function countHabitMarks(log: DailyLog | undefined) {
  if (!log) return 0;
  let n = 0;
  if (log.skinCare.cleansing) n += 1;
  if (log.skinCare.moisturizer) n += 1;
  if (log.skinCare.sunscreen) n += 1;
  if (log.waterMl > 0) n += 1;
  if (log.sleepHours != null) n += 1;
  if (log.food.completeMeals) n += 1;
  if (log.food.fruitsVeggies) n += 1;
  if (log.food.protein) n += 1;
  if (log.food.reducedUltra) n += 1;
  if (log.posture) n += 1;
  if (log.workout) n += 1;
  n += Object.values(log.extraHabits).filter(Boolean).length;
  return n;
}

export function computeStreak(
  logs: Record<string, DailyLog>,
  settings: Settings,
  today: Date,
) {
  let cursor = startOfDay(today);
  if (getDayStatus(logs[toDateKey(cursor)], settings) === "empty") {
    cursor = addDays(cursor, -1);
  }
  let streak = 0;
  while (true) {
    const key = toDateKey(cursor);
    const status = getDayStatus(logs[key], settings);
    if (status === "empty") break;
    streak += 1;
    cursor = addDays(cursor, -1);
    if (streak > 400) break;
  }
  return streak;
}

export function isToday(d: Date | string, today: Date) {
  const date = typeof d === "string" ? parseDateKey(d) : d;
  return isSameDay(date, today);
}
