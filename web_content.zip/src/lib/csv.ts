import { AnswerOption } from '../types';

export const parseCSV = (csvText: string): Record<number, AnswerOption> => {
  const lines = csvText.split('\n');
  const result: Record<number, AnswerOption> = {};
  
  lines.forEach(line => {
    if (!line.trim()) return;
    const parts = line.split(',');
    if (parts.length >= 2) {
      const qNum = parseInt(parts[0].trim());
      const ans = parts[1].trim().toUpperCase();
      
      if (!isNaN(qNum) && qNum >= 1 && qNum <= 180) {
        if (['A', 'B', 'C', 'D'].includes(ans)) {
          result[qNum] = ans as AnswerOption;
        } else {
          result[qNum] = '';
        }
      }
    }
  });
  
  return result;
};

// Helper to generate mock CSV content for testing
export const generateMockCSV = (seed: number = 0): string => {
  const options = ['A', 'B', 'C', 'D', ''];
  let csv = '';
  for (let i = 1; i <= 180; i++) {
    // Generate some pseudo-random answers
    const rand = (Math.sin(seed + i) * 10000) - Math.floor(Math.sin(seed + i) * 10000);
    let ans = '';
    if (rand > 0.1) {
       ans = options[Math.floor(rand * 4)];
    }
    csv += `${i},${ans}\n`;
  }
  return csv;
};
