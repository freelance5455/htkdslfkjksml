import { findCatalog } from "./catalog";
import { parseNum } from "./lightyear";
import type { AssetClass, Currency, ParsedRow, PortfolioState } from "./types";

const CLASSES = new Set<AssetClass>(["etf", "reszveny", "kripto", "keszpenz"]);
const CURRENCIES = new Set<Currency>(["HUF", "USD", "EUR", "GBP"]);

function splitCsvLine(line: string): string[] {
  const cells: string[] = [];
  let current = "";
  let quoted = false;
  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];
    if (quoted) {
      if (char === '"' && line[i + 1] === '"') {
        current += '"';
        i += 1;
      } else if (char === '"') quoted = false;
      else current += char;
    } else if (char === '"') quoted = true;
    else if (char === ",") {
      cells.push(current.trim());
      current = "";
    } else current += char;
  }
  cells.push(current.trim());
  return cells;
}

function asCurrency(value: string | undefined, fallback: Currency): Currency {
  const upper = (value ?? "").toUpperCase();
  return CURRENCIES.has(upper as Currency) ? (upper as Currency) : fallback;
}

function asClass(value: string | undefined, fallback: AssetClass): AssetClass {
  const lower = (value ?? "").toLowerCase();
  if (lower === "stock" || lower === "részvény" || lower === "reszveny") return "reszveny";
  if (lower === "crypto" || lower === "kripto") return "kripto";
  if (lower === "cash" || lower === "készpénz" || lower === "keszpenz") return "keszpenz";
  if (CLASSES.has(lower as AssetClass)) return lower as AssetClass;
  return fallback;
}

export function parseIbkr(text: string): ParsedRow[] {
  const lines = text.split(/\r?\n/).filter((line) => line.trim());
  let headers: string[] | null = null;
  const rows: ParsedRow[] = [];
  for (const line of lines) {
    const cells = splitCsvLine(line);
    if (cells[0] !== "Positions") continue;
    if (cells[1] === "Header") {
      headers = cells.map((cell) => cell.toLowerCase());
      continue;
    }
    if (cells[1] !== "Data" || !headers) continue;
    const discriminator = cells[2]?.toLowerCase();
    if (discriminator && discriminator !== "summary" && headers[2] === "datadiscriminator") continue;
    const pick = (name: string) => {
      const index = headers!.findIndex((header) => header === name);
      return index >= 0 ? cells[index] : "";
    };
    const symbol = pick("symbol").toUpperCase();
    if (!symbol || symbol === "TOTAL" || symbol.includes("TOTAL")) continue;
    const quantity = parseNum(pick("quantity"));
    if (quantity == null || quantity === 0) continue;
    const currency = asCurrency(pick("currency"), "USD");
    const close = parseNum(pick("close price")) ?? parseNum(pick("market price"));
    const known = findCatalog(symbol);
    rows.push({
      key: `ibkr:${symbol}:${currency}`,
      symbol: known?.symbol ?? symbol,
      name: known?.name ?? symbol,
      assetClass: known?.assetClass ?? (pick("asset class").toLowerCase().includes("cash") ? "keszpenz" : "reszveny"),
      currency: known?.currency ?? currency,
      quantity: Math.abs(quantity),
      price: close,
      warning: known ? undefined : "A szimbólum nincs a katalógusban.",
    });
  }
  return rows;
}

export function parseGenericCsv(text: string): ParsedRow[] {
  const lines = text.split(/\r?\n/).filter((line) => line.trim());
  if (!lines.length) return [];
  const headers = splitCsvLine(lines[0]).map((cell) => cell.toLowerCase());
  const index = (names: string[]) => headers.findIndex((header) => names.includes(header));
  const symbolIndex = index(["symbol", "szimbólum", "szimbolum", "ticker"]);
  const qtyIndex = index(["quantity", "qty", "mennyiség", "mennyiseg", "darab"]);
  if (symbolIndex < 0 || qtyIndex < 0) return [];
  const nameIndex = index(["name", "név", "nev"]);
  const classIndex = index(["assetclass", "class", "osztály", "osztaly"]);
  const currencyIndex = index(["currency", "deviza", "ccy"]);
  const priceIndex = index(["price", "ár", "ar", "close", "avgcost", "avg"]);
  const groupIndex = index(["group", "csoport"]);
  const rows: ParsedRow[] = [];
  for (const line of lines.slice(1)) {
    const cells = splitCsvLine(line);
    const symbol = (cells[symbolIndex] ?? "").toUpperCase();
    const quantity = parseNum(cells[qtyIndex] ?? "");
    if (!symbol || quantity == null) continue;
    const known = findCatalog(symbol);
    const currency = asCurrency(cells[currencyIndex], known?.currency ?? "USD");
    rows.push({
      key: `csv:${symbol}:${cells[groupIndex] ?? ""}`,
      symbol,
      name: cells[nameIndex] || known?.name || symbol,
      assetClass: asClass(cells[classIndex], known?.assetClass ?? "reszveny"),
      currency,
      quantity,
      price: priceIndex >= 0 ? parseNum(cells[priceIndex] ?? "") : null,
      warning: cells[groupIndex] ? `Csoport a fájlban: ${cells[groupIndex]}` : undefined,
    });
  }
  return rows;
}

export function parseImportCsv(text: string): ParsedRow[] {
  if (/Positions\s*,\s*Header/i.test(text) || text.includes('"Positions"')) {
    const ibkr = parseIbkr(text);
    if (ibkr.length) return ibkr;
  }
  return parseGenericCsv(text);
}

function csvCell(value: string | number): string {
  const text = String(value);
  if (/[",\n]/.test(text)) return `"${text.replace(/"/g, '""')}"`;
  return text;
}

export function holdingsCsv(state: PortfolioState): string {
  const header = ["symbol", "name", "assetClass", "currency", "group", "quantity", "avgCost", "costFxToHuf"];
  const lines = [header.join(",")];
  for (const holding of state.holdings) {
    const group = state.groups.find((item) => item.id === holding.groupId)?.name ?? "";
    lines.push(
      [
        holding.symbol,
        holding.name,
        holding.assetClass,
        holding.currency,
        group,
        holding.quantity,
        holding.avgCost,
        holding.costFxToHuf,
      ]
        .map(csvCell)
        .join(","),
    );
  }
  return lines.join("\n");
}

export function backupJson(state: PortfolioState): string {
  const { market, ...rest } = state;
  return JSON.stringify({ app: "szamvetes", version: 1, state: { ...rest, market: { ...market, history: {}, fxHistory: [] } } }, null, 2);
}
