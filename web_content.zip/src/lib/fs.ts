import type { FS, FSNode } from "./types";

let counter = 0;
export function uid(prefix = "id"): string {
  counter += 1;
  return `${prefix}_${Date.now().toString(36)}${counter.toString(36)}${Math.random().toString(36).slice(2, 6)}`;
}

const SEED: Record<string, string> = {
  "README.md": `# pocket-notes

A tiny offline-first notes app built to test mobile agents.

- src/App.tsx — shell + routing
- src/components/NoteList.tsx — list & search
- src/store/notes.ts — persistence

Run it with \`npm run dev\`.
`,
  "package.json": `{
  "name": "pocket-notes",
  "private": true,
  "version": "0.3.1",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build"
  },
  "dependencies": {
    "react": "^19.0.0",
    "react-dom": "^19.0.0"
  },
  "devDependencies": {
    "vite": "^7.3.7",
    "@vitejs/plugin-react": "^5.1.1",
    "typescript": "^5.9.3"
  }
}
`,
  "vite.config.ts": `import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({ plugins: [react()] });
`,
  "index.html": `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>pocket notes</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`,
  "src/main.tsx": `import { createRoot } from "react-dom/client";
import App from "./App";
import "./styles.css";

createRoot(document.getElementById("root")!).render(<App />);
`,
  "src/App.tsx": `import { useState } from "react";
import NoteList from "./components/NoteList";

export default function App() {
  const [query, setQuery] = useState("");
  const [view, setView] = useState("all");
  return (
    <main className="petal-app">
      <header className="petal-nav"><a href="#home" className="petal-logo"><span className="petal-symbol">p</span>petal<span className="logo-dot">.</span></a><span className="petal-nav-note">a little space for you</span></header>
      <section className="petal-intro" id="home"><div className="petal-eyebrow"><span /> THOUGHTS, MEET POSSIBILITY</div><h1>Little notes.<br /><em>Room to bloom.</em></h1><p>Collect the thoughts, plans, and tiny sparks<br />that make your day a little brighter.</p><div className="petal-flower" aria-hidden="true"><i /><i /><i /><i /><b /></div></section>
      <section className="petal-content"><div className="petal-section-title"><h2>Your little collection</h2><span>MAKE YOURSELF AT HOME</span></div><div className="petal-controls"><div className="petal-tabs"><button className={view === "all" ? "active" : ""} onClick={() => setView("all")}>All notes</button><button className={view === "favorites" ? "active" : ""} onClick={() => setView("favorites")}>Favorites</button></div><input aria-label="Search notes" placeholder="Find a thought..." value={query} onChange={e => setQuery(e.target.value)} /></div><NoteList query={query} favorites={view === "favorites"} /></section>
      <footer className="petal-footer"><span>Small things. Beautifully kept.</span><span>Made with a little care.</span></footer>
    </main>
  );
}
`,
  "src/components/NoteList.tsx": `import { useState } from "react";
type Note = { id: string; title: string; body: string; favorite: boolean; color: string };
const initial: Note[] = [
  { id: "1", title: "A little reminder", body: "You don't have to have it all figured out to make something wonderful.", favorite: true, color: "rose" },
  { id: "2", title: "Ideas worth keeping", body: "A tiny bookshop. A Sunday playlist. That thing I keep meaning to build.", favorite: false, color: "lilac" },
  { id: "3", title: "The good things", body: "Slow mornings, fresh pages, and starting before you're ready.", favorite: false, color: "sage" },
];
export default function NoteList({ query, favorites = false }: { query: string; favorites?: boolean }) {
  const [notes, setNotes] = useState(initial);
  const [selected, setSelected] = useState<string | null>(null);
  const rows = notes.filter(n => (!favorites || n.favorite) && (n.title + n.body).toLowerCase().includes(query.toLowerCase()));
  return <><div className="petal-notes">{rows.map(note => <article key={note.id} className={"petal-note " + note.color}><div className="note-meta"><span>A SPACE TO THINK</span><button aria-label={note.favorite ? "Unfavorite " + note.title : "Favorite " + note.title} onClick={() => setNotes(current => current.map(n => n.id === note.id ? { ...n, favorite: !n.favorite } : n))}>{note.favorite ? "*" : "+"}</button></div><button className="note-open" onClick={() => setSelected(selected === note.id ? null : note.id)}><h3>{note.title}</h3><p>{note.body}</p></button>{selected === note.id && <textarea aria-label={"Edit " + note.title} value={note.body} onChange={e => setNotes(current => current.map(n => n.id === note.id ? { ...n, body: e.target.value } : n))} />}<span className="note-bottom">A little thought, safely kept.</span></article>)}</div>{rows.length === 0 && <p className="petal-empty">No thoughts here yet. Let's add one.</p>}<button className="petal-add" onClick={() => { const note = { id: String(Date.now()), title: "A new beginning", body: "Click this note to write your next idea.", favorite: false, color: "lilac" }; setNotes(current => [...current, note]); setSelected(note.id); }}>+ <span>A fresh little note</span></button></>;
}
`,
  "src/styles.css": `:root{font-family:Georgia,'Times New Roman',serif;color:#403645;background:#fffdfb;font-synthesis:none}*{box-sizing:border-box}body{margin:0}.petal-app{max-width:1000px;margin:auto;padding:0 25px}.petal-nav{height:68px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #efe9eb}.petal-logo{font:600 23px/1 system-ui;text-decoration:none;color:#443b48;letter-spacing:-1px;display:flex;align-items:center;gap:6px}.logo-dot{color:#bb8ba8;margin-left:-5px}.petal-symbol{display:grid;place-items:center;font:italic 22px Georgia;width:25px;height:27px;border-radius:10px;background:#f0e3ed;color:#a27ca8}.petal-nav-note{font:9px system-ui;color:#a89ba3}.petal-intro{padding:48px 0 33px;position:relative;border-bottom:1px solid #efe9eb}.petal-eyebrow{display:flex;align-items:center;gap:6px;font:8px system-ui;letter-spacing:1.3px;color:#a490a1}.petal-eyebrow span{width:5px;height:5px;border-radius:50%;background:#c497ad}.petal-intro h1{font-size:37px;line-height:1.15;font-weight:400;letter-spacing:-1.3px;margin:18px 0}.petal-intro em{font-weight:400;color:#ad7f9b}.petal-intro p{font:10px/1.8 system-ui;color:#aa98a0;margin-top:15px}.petal-flower{position:absolute;right:0;top:55px;width:53px;height:53px;opacity:.7;transform:rotate(-15deg)}.petal-flower i{position:absolute;left:18px;top:0;width:19px;height:28px;border-radius:50%;background:#efdfeb;transform-origin:50% 100%}.petal-flower i:nth-child(2){transform:rotate(90deg)}.petal-flower i:nth-child(3){transform:rotate(180deg)}.petal-flower i:nth-child(4){transform:rotate(270deg)}.petal-flower b{position:absolute;left:20px;top:21px;width:13px;height:13px;border-radius:50%;background:#d4b7ce}.petal-content{padding:25px 0 30px}.petal-section-title{display:flex;justify-content:space-between;align-items:center}.petal-section-title h2{font-size:17px;font-weight:400;letter-spacing:-.5px}.petal-section-title>span{font:6px system-ui;letter-spacing:1px;color:#b09fa9}.petal-controls{display:flex;align-items:center;justify-content:space-between;margin:10px 0 17px;gap:10px}.petal-tabs{display:flex;gap:6px}.petal-tabs button{font:8px system-ui;white-space:nowrap;color:#a99ba6;border:0;background:transparent;padding:6px 9px;border-radius:6px;cursor:pointer}.petal-tabs .active{background:#f0e7f0;color:#a07aa5}.petal-controls input{width:110px;min-width:0;background:transparent;border:0;border-bottom:1px solid #eee4e9;font:8px system-ui;padding:6px 3px;color:#8f7987;outline:none}.petal-controls input::placeholder{color:#b6a9af}.petal-notes{display:grid;gap:11px}.petal-note{padding:16px;border-radius:11px}.rose{background:#f9eff0}.lilac{background:#f2eef7}.sage{background:#eff3ed}.note-meta{display:flex;justify-content:space-between;align-items:center;color:#b39daa;font:6px system-ui;letter-spacing:1px}.note-meta button{border:0;background:#ffffff80;color:#ac8a9c;border-radius:5px;width:20px;height:20px;cursor:pointer;font-size:12px}.note-open{display:block;text-align:left;width:100%;padding:0;border:0;background:transparent;cursor:pointer;color:inherit}.note-open h3{font-size:17px;font-weight:400;margin:7px 0 9px;letter-spacing:-.3px}.note-open p{font:9px/1.8 system-ui;color:#a18f9d;max-width:240px;margin:0 0 18px}.note-bottom{font:7px system-ui;color:#b9a9b4}.petal-note textarea{width:100%;resize:vertical;padding:8px;font:11px/1.7 system-ui;color:#775e70;background:#ffffff70;border:1px solid #e4d7e3;border-radius:6px;margin-bottom:12px}.petal-add{width:100%;border:1px dashed #e3d5e1;background:transparent;border-radius:9px;padding:15px;font:12px system-ui;color:#b08ca8;cursor:pointer;margin-top:15px}.petal-add span{font-size:9px;margin-left:5px}.petal-footer{display:flex;justify-content:space-between;padding:18px 0;border-top:1px solid #efe9eb;font:7px system-ui;color:#b9a7b1}.petal-empty{font:12px system-ui;color:#a18898;text-align:center;padding:20px}@media(min-width:600px){.petal-app{padding:0 60px}.petal-intro{padding:65px 0}.petal-intro h1{font-size:60px}.petal-flower{right:35px;top:80px;transform:scale(1.8) rotate(-15deg)}.petal-notes{grid-template-columns:repeat(3,1fr)}.petal-nav-note{font-size:11px}.petal-intro p{font-size:13px}.petal-section-title>span{font-size:8px}.note-open p{font-size:11px}.note-open h3{font-size:21px}.petal-controls input{width:180px;font-size:11px}.petal-tabs button{font-size:11px}}
`,
  "notes/ideas.md": `# Ideas

- voice-to-prompt composer
- diff review before every write
- per-folder permissions instead of global
`,
};

export function seedFS(rootName = "pocket-notes"): FS {
  const rootId = "root";
  const nodes: Record<string, FSNode> = {
    [rootId]: {
      id: rootId,
      name: rootName,
      type: "dir",
      parentId: null,
      children: [],
      updatedAt: Date.now(),
    },
  };
  const ensureDir = (path: string[]): string => {
    let cur = rootId;
    let acc = "";
    for (const part of path) {
      acc = acc ? `${acc}/${part}` : part;
      const existing = nodes[cur].children?.find(
        (c) => nodes[c].name === part && nodes[c].type === "dir",
      );
      if (existing) {
        cur = existing;
      } else {
        const id = uid("d");
        nodes[id] = {
          id,
          name: part,
          type: "dir",
          parentId: cur,
          children: [],
          updatedAt: Date.now(),
        };
        nodes[cur].children = [...(nodes[cur].children ?? []), id];
        cur = id;
      }
    }
    return cur;
  };
  for (const [path, content] of Object.entries(SEED)) {
    const parts = path.split("/");
    const name = parts.pop()!;
    const parentId = parts.length ? ensureDir(parts) : rootId;
    const id = uid("f");
    nodes[id] = {
      id,
      name,
      type: "file",
      parentId,
      content,
      updatedAt: Date.now(),
    };
    nodes[parentId].children = [...(nodes[parentId].children ?? []), id];
  }
  sortNodes(nodes, rootId);
  return { nodes, rootId };
}

export function sortNodes(nodes: Record<string, FSNode>, id: string) {
  const n = nodes[id];
  if (!n?.children) return;
  nodes[id] = {
    ...n,
    children: [...n.children].sort((a, b) => {
      const A = nodes[a];
      const B = nodes[b];
      if (!A || !B) return 0;
      if (A.type !== B.type) return A.type === "dir" ? -1 : 1;
      return A.name.localeCompare(B.name);
    }),
  };
}

export function childrenOf(fs: FS, id: string): FSNode[] {
  const n = fs.nodes[id];
  if (!n?.children) return [];
  return n.children.map((c) => fs.nodes[c]).filter(Boolean);
}

export function pathOf(fs: FS, id: string): string {
  const parts: string[] = [];
  let cur: FSNode | undefined = fs.nodes[id];
  while (cur && cur.parentId !== null) {
    parts.unshift(cur.name);
    cur = fs.nodes[cur.parentId];
  }
  return parts.join("/");
}

export function displayPath(fs: FS, id: string, workspacePath: string): string {
  return `${workspacePath}/${pathOf(fs, id)}`;
}

export function findPath(fs: FS, rel: string): FSNode | null {
  const clean = rel.replace(/^\/+|\/+$/g, "");
  if (!clean) return fs.nodes[fs.rootId];
  let cur: string = fs.rootId;
  for (const part of clean.split("/")) {
    if (part === "." || part === "") continue;
    if (part === "..") {
      const p = fs.nodes[cur]?.parentId;
      if (!p) return null;
      cur = p;
      continue;
    }
    const next = fs.nodes[cur]?.children?.find(
      (c) => fs.nodes[c]?.name.toLowerCase() === part.toLowerCase(),
    );
    if (!next) return null;
    cur = next;
  }
  return fs.nodes[cur] ?? null;
}

export function parentPathOf(rel: string): { dir: string; name: string } {
  const clean = rel.replace(/^\/+/, "");
  const idx = clean.lastIndexOf("/");
  if (idx === -1) return { dir: "", name: clean };
  return { dir: clean.slice(0, idx), name: clean.slice(idx + 1) };
}

export function uniqueName(fs: FS, parentId: string, name: string): string {
  const siblings = fs.nodes[parentId]?.children ?? [];
  const taken = new Set(siblings.map((c) => fs.nodes[c]?.name.toLowerCase()));
  if (!taken.has(name.toLowerCase())) return name;
  const dot = name.lastIndexOf(".");
  const base = dot > 0 ? name.slice(0, dot) : name;
  const ext = dot > 0 ? name.slice(dot) : "";
  let i = 2;
  while (taken.has(`${base}-${i}${ext}`.toLowerCase())) i += 1;
  return `${base}-${i}${ext}`;
}

export function isDescendant(
  fs: FS,
  maybeChild: string,
  ancestor: string,
): boolean {
  let cur: string | null | undefined = maybeChild;
  while (cur) {
    if (cur === ancestor) return true;
    cur = fs.nodes[cur]?.parentId;
  }
  return false;
}

export function mkdir(
  fs: FS,
  parentId: string,
  name: string,
): { fs: FS; id: string } {
  const id = uid("d");
  const nodes = { ...fs.nodes };
  nodes[id] = {
    id,
    name: uniqueName(fs, parentId, name),
    type: "dir",
    parentId,
    children: [],
    updatedAt: Date.now(),
  };
  nodes[parentId] = {
    ...nodes[parentId],
    children: [...(nodes[parentId].children ?? []), id],
  };
  sortNodes(nodes, parentId);
  return { fs: { nodes, rootId: fs.rootId }, id };
}

export function writeFile(
  fs: FS,
  parentId: string,
  name: string,
  content: string,
): { fs: FS; id: string } {
  const existing = fs.nodes[parentId]?.children?.find(
    (c) => fs.nodes[c]?.name.toLowerCase() === name.toLowerCase(),
  );
  if (existing) return { fs: updateFile(fs, existing, content), id: existing };
  const id = uid("f");
  const nodes = { ...fs.nodes };
  nodes[id] = {
    id,
    name,
    type: "file",
    parentId,
    content,
    updatedAt: Date.now(),
  };
  nodes[parentId] = {
    ...nodes[parentId],
    children: [...(nodes[parentId].children ?? []), id],
  };
  sortNodes(nodes, parentId);
  return { fs: { nodes, rootId: fs.rootId }, id };
}

export function updateFile(fs: FS, id: string, content: string): FS {
  const nodes = { ...fs.nodes };
  nodes[id] = { ...nodes[id], content, updatedAt: Date.now() };
  return { nodes, rootId: fs.rootId };
}

export function removeNode(fs: FS, id: string): FS {
  const nodes = { ...fs.nodes };
  const target = nodes[id];
  if (!target) return fs;
  const purge = (nodeId: string) => {
    const n = nodes[nodeId];
    if (!n) return;
    n.children?.forEach(purge);
    delete nodes[nodeId];
  };
  purge(id);
  if (target.parentId) {
    const p = nodes[target.parentId];
    if (p) {
      nodes[target.parentId] = {
        ...p,
        children: (p.children ?? []).filter((c) => c !== id),
      };
    }
  }
  return { nodes, rootId: fs.rootId };
}

export function renameNode(fs: FS, id: string, name: string): FS {
  const nodes = { ...fs.nodes };
  const node = nodes[id];
  if (!node?.parentId) return fs;
  if (node.name === name) return fs;
  nodes[id] = {
    ...node,
    name: uniqueName(fs, node.parentId, name),
    updatedAt: Date.now(),
  };
  sortNodes(nodes, node.parentId);
  return { nodes, rootId: fs.rootId };
}

export function moveNode(
  fs: FS,
  id: string,
  newParentId: string,
): { fs: FS; name: string } {
  const nodes = { ...fs.nodes };
  const node = nodes[id];
  if (!node?.parentId || nodes[newParentId]?.type !== "dir")
    throw new Error("Invalid move destination.");
  if (isDescendant(fs, newParentId, id))
    throw new Error("A folder cannot be moved into itself.");
  if (node.parentId === newParentId) return { fs, name: node.name };
  const name = uniqueName(fs, newParentId, node.name);
  const oldParent = nodes[node.parentId!];
  nodes[node.parentId!] = {
    ...oldParent,
    children: (oldParent.children ?? []).filter((c) => c !== id),
  };
  nodes[id] = { ...node, parentId: newParentId, name, updatedAt: Date.now() };
  nodes[newParentId] = {
    ...nodes[newParentId],
    children: [...(nodes[newParentId].children ?? []), id],
  };
  sortNodes(nodes, newParentId);
  return { fs: { nodes, rootId: fs.rootId }, name };
}

export function searchFS(
  fs: FS,
  query: string,
  limit = 40,
): { id: string; path: string; line?: number; snippet?: string }[] {
  const out: { id: string; path: string; line?: number; snippet?: string }[] =
    [];
  const q = query.toLowerCase().trim();
  if (!q) return out;
  const walk = (id: string) => {
    const n = fs.nodes[id];
    if (!n) return;
    if (n.type === "file") {
      const p = pathOf(fs, id);
      if (n.name.toLowerCase().includes(q)) out.push({ id, path: p });
      const content = n.content ?? "";
      const lines = content.split("\n");
      lines.forEach((l, i) => {
        if (out.length >= limit) return;
        if (l.toLowerCase().includes(q))
          out.push({
            id,
            path: p,
            line: i + 1,
            snippet: l.trim().slice(0, 120),
          });
      });
    }
    n.children?.forEach(walk);
  };
  walk(fs.rootId);
  return out.slice(0, limit);
}

export function langOf(name: string): string {
  const ext = name.split(".").pop()?.toLowerCase() ?? "";
  const map: Record<string, string> = {
    ts: "ts",
    tsx: "tsx",
    js: "js",
    jsx: "jsx",
    json: "json",
    css: "css",
    html: "html",
    md: "md",
    py: "py",
    kt: "kotlin",
    java: "java",
    rs: "rust",
    go: "go",
    sh: "sh",
    yml: "yaml",
    yaml: "yaml",
    svg: "svg",
    txt: "text",
  };
  return map[ext] ?? ext ?? "text";
}

export function statLine(fs: FS, id: string): string {
  const n = fs.nodes[id];
  if (!n) return "";
  if (n.binary) return "Excluded from text workspace";
  if (n.type === "dir") return `${n.children?.length ?? 0} items`;
  const lines = (n.content ?? "").split("\n").length;
  const bytes = new Blob([n.content ?? ""]).size;
  return `${lines} lines · ${bytes < 1024 ? `${bytes} B` : `${(bytes / 1024).toFixed(1)} KB`}`;
}

export function safePath(input: string, allowRoot = false): string {
  if (/^[a-z]:|^[/\\]|\0/i.test(input))
    throw new Error("Use a path relative to the workspace.");
  const parts = input
    .replace(/\\/g, "/")
    .split("/")
    .filter((p) => p && p !== ".");
  if (parts.some((p) => p === ".." || /[<>:"|?*\x00-\x1f]/.test(p))) {
    throw new Error("This path is not allowed. Stay inside the workspace.");
  }
  if (!parts.length && !allowRoot)
    throw new Error("Choose a file or folder, not the workspace root.");
  return parts.join("/");
}

export function ensureDirs(fs: FS, path: string): { fs: FS; id: string } {
  let working = fs;
  let id = fs.rootId;
  for (const part of safePath(path, true).split("/").filter(Boolean)) {
    const node = childrenOf(working, id).find((n) => n.name === part);
    if (node?.type === "file")
      throw new Error(`${part} is a file, not a folder.`);
    if (node) id = node.id;
    else {
      const made = mkdir(working, id, part);
      working = made.fs;
      id = made.id;
    }
  }
  return { fs: working, id };
}

export function emptyFS(name: string): FS {
  return {
    rootId: "root",
    nodes: {
      root: {
        id: "root",
        name,
        type: "dir",
        parentId: null,
        children: [],
        updatedAt: Date.now(),
      },
    },
  };
}
