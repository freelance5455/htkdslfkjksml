export type OfflinePack = {
  id: string;
  kind: "chapter" | "exam";
  title: string;
  savedAt: number;
};

export type PendingSync =
  | { type: "lesson"; subjectId: string; chapterId: string }
  | { type: "quiz"; subjectId: string; chapterId: string; answers: number[] }
  | { type: "exam"; examId: string; answers: number[] };

const DB_NAME = "henok-education";
const DB_VERSION = 1;
const PACKS = "packs";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(PACKS)) {
        db.createObjectStore(PACKS, { keyPath: "id" });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function requestToPromise<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function savePack(pack: OfflinePack & { payload: unknown }) {
  const db = await openDb();
  const tx = db.transaction(PACKS, "readwrite");
  await requestToPromise(tx.objectStore(PACKS).put(pack));
}

export async function removePack(id: string) {
  const db = await openDb();
  const tx = db.transaction(PACKS, "readwrite");
  await requestToPromise(tx.objectStore(PACKS).delete(id));
}

export async function listPacks(): Promise<OfflinePack[]> {
  const db = await openDb();
  const tx = db.transaction(PACKS, "readonly");
  const rows = await requestToPromise(tx.objectStore(PACKS).getAll());
  return (rows as OfflinePack[]).map(({ id, kind, title, savedAt }) => ({
    id,
    kind,
    title,
    savedAt,
  }));
}

export async function hasPack(id: string) {
  const db = await openDb();
  const tx = db.transaction(PACKS, "readonly");
  const row = await requestToPromise(tx.objectStore(PACKS).get(id));
  return Boolean(row);
}

const QUEUE_KEY = "henok-sync-queue";
const MIRROR_KEY = "henok-progress-mirror";

export type MirrorRow = {
  kind: "lesson" | "quiz" | "exam";
  itemId: string;
  score: number | null;
  total: number | null;
  completed: boolean;
};

export function readQueue(): PendingSync[] {
  try {
    const raw = localStorage.getItem(QUEUE_KEY);
    return raw ? (JSON.parse(raw) as PendingSync[]) : [];
  } catch {
    return [];
  }
}

export function writeQueue(items: PendingSync[]) {
  localStorage.setItem(QUEUE_KEY, JSON.stringify(items));
}

export function enqueue(item: PendingSync) {
  const items = readQueue().filter((existing) => syncKey(existing) !== syncKey(item));
  items.push(item);
  writeQueue(items);
}

export function syncKey(item: PendingSync) {
  if (item.type === "exam") return `exam:${item.examId}`;
  return `${item.type}:${item.subjectId}/${item.chapterId}`;
}

export function readMirror(): MirrorRow[] {
  try {
    const raw = localStorage.getItem(MIRROR_KEY);
    return raw ? (JSON.parse(raw) as MirrorRow[]) : [];
  } catch {
    return [];
  }
}

export function writeMirror(rows: MirrorRow[]) {
  localStorage.setItem(MIRROR_KEY, JSON.stringify(rows));
}

export function upsertMirror(row: MirrorRow) {
  const rows = readMirror().filter(
    (existing) => !(existing.kind === row.kind && existing.itemId === row.itemId),
  );
  rows.push(row);
  writeMirror(rows);
  return rows;
}
