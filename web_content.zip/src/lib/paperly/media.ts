const IMAGE_LIMIT = 500_000;
const FILE_LIMIT = 900_000;

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("تعذر قراءة الصورة"));
    image.src = src;
  });
}

function readFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("تعذر قراءة الملف"));
    reader.readAsDataURL(file);
  });
}

function draw(image: HTMLImageElement, maxEdge: number, quality: number): string {
  const scale = Math.min(1, maxEdge / Math.max(image.width, image.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(image.width * scale));
  canvas.height = Math.max(1, Math.round(image.height * scale));
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("تعذرت معالجة الصورة");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL("image/jpeg", quality);
}

export async function compressImage(file: File): Promise<string> {
  if (!file.type.startsWith("image/")) throw new Error("الملف ليس صورة");
  const original = await readFile(file);
  const image = await loadImage(original);
  let maxEdge = 1600;
  let quality = 0.82;
  let url = draw(image, maxEdge, quality);
  while (url.length > IMAGE_LIMIT && quality > 0.45) {
    quality = Math.round((quality - 0.1) * 100) / 100;
    maxEdge = Math.round(maxEdge * 0.85);
    url = draw(image, maxEdge, quality);
  }
  if (url.length > IMAGE_LIMIT) throw new Error("الصورة كبيرة جدًا حتى بعد الضغط");
  return url;
}

export async function readAttachment(file: File): Promise<{ src: string; name: string; mime: string; size: number }> {
  if (file.size > FILE_LIMIT) throw new Error("الملف أكبر من الحد (حوالي 900 ك.ب). ارفع نسخة أصغر.");
  const src = await readFile(file);
  if (src.length > 1_200_000) throw new Error("الملف أكبر من الحد بعد الترميز");
  return { src, name: file.name || "ملف", mime: file.type || "application/octet-stream", size: file.size };
}

export function isTextFile(file: File): boolean {
  return file.type.startsWith("text/") || /\.(txt|md|markdown|csv)$/i.test(file.name);
}

export function isProjectFile(file: File): boolean {
  return file.type === "application/json" || /\.json$/i.test(file.name);
}
