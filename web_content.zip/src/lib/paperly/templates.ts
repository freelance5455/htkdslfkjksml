import type { ProjectDoc } from "./model";

export const FAMILIES = [
  "editorial",
  "academic",
  "magazine",
  "soft",
  "noir",
  "bold",
  "desert",
  "sea",
] as const;

export type Family = (typeof FAMILIES)[number];

export const FAMILY_LABEL: Record<Family, string> = {
  editorial: "تحريري",
  academic: "أكاديمي",
  magazine: "مجلة",
  soft: "هادئ",
  noir: "ليلي",
  bold: "جريء",
  desert: "صحراوي",
  sea: "بحري",
};

export const LAYOUTS = [
  "center",
  "band",
  "split",
  "frame",
  "masthead",
  "rail",
  "seal",
  "window",
  "poster",
  "rules",
  "blocks",
  "editorial",
] as const;

export type LayoutId = (typeof LAYOUTS)[number];

export const LAYOUT_LABEL: Record<LayoutId, string> = {
  center: "منتصف",
  band: "شريط",
  split: "منقسم",
  frame: "إطار",
  masthead: "ترويسة",
  rail: "حافة",
  seal: "ختم",
  window: "نافذة",
  poster: "ملصق",
  rules: "مسطّر",
  blocks: "كتل",
  editorial: "عمود",
};

export const PATTERNS = [
  "none",
  "dots",
  "lines",
  "grid",
  "diamonds",
  "arcs",
  "rings",
  "cross",
  "waves",
] as const;

export type PatternId = (typeof PATTERNS)[number];

export const PATTERN_LABEL: Record<PatternId, string> = {
  none: "بدون",
  dots: "نقاط",
  lines: "خطوط",
  grid: "شبكة",
  diamonds: "معين",
  arcs: "أقواس",
  rings: "حلقات",
  cross: "تقاطع",
  waves: "موج",
};

export type Template = {
  id: string;
  name: string;
  family: Family;
  layout: LayoutId;
  pattern: PatternId;
  angle: number;
  font: "amiri" | "plex";
  c1: string;
  c2: string;
  paper: string;
  ink: string;
  accent: string;
  on1: string;
  on2: string;
  onGrad: string;
};

const ADJ = [
  "هادئ",
  "حبري",
  "عتيق",
  "واضح",
  "دافئ",
  "صارم",
  "رقيق",
  "واسع",
  "مختصر",
  "ملكي",
  "ليلي",
  "حريري",
  "دقيق",
  "نظيف",
  "ثقيل",
  "مفتوح",
  "عتيق الظل",
  "قريب",
  "بعيد",
  "راسخ",
];

const NOUN = ["دفتر", "غلاف", "طراز", "مجلد", "كراس", "إصدار", "ديوان", "بيان", "سجل", "متن", "غلاف داخلي", "عدد"];

const BIASED: Record<Family, LayoutId[]> = {
  editorial: ["editorial", "rules", "rail", "frame", "band"],
  academic: ["rules", "seal", "frame", "center", "editorial"],
  magazine: ["masthead", "poster", "band", "window", "split"],
  soft: ["band", "center", "window", "frame", "seal"],
  noir: ["center", "poster", "split", "blocks", "rail"],
  bold: ["poster", "blocks", "split", "masthead", "center"],
  desert: ["band", "editorial", "window", "rules", "frame"],
  sea: ["center", "band", "rail", "seal", "window"],
};

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hashSeed(seed: string): number {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i += 1) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function hslHex(h: number, s: number, l: number): string {
  const sat = Math.max(0, Math.min(100, s)) / 100;
  const light = Math.max(0, Math.min(100, l)) / 100;
  const a = sat * Math.min(light, 1 - light);
  const f = (n: number) => {
    const k = (n + h / 30) % 12;
    const color = light - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
    return Math.round(255 * color)
      .toString(16)
      .padStart(2, "0");
  };
  return `#${f(0)}${f(8)}${f(4)}`;
}

function lum(hex: string): number {
  const n = Number.parseInt(hex.slice(1), 16);
  const channel = (c: number) => {
    const s = c / 255;
    return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
  };
  return 0.2126 * channel((n >> 16) & 255) + 0.7152 * channel((n >> 8) & 255) + 0.0722 * channel(n & 255);
}

function on(hex: string): string {
  return lum(hex) > 0.45 ? "#1c1916" : "#f6f1e8";
}

function mix(a: string, b: string): string {
  const pa = Number.parseInt(a.slice(1), 16);
  const pb = Number.parseInt(b.slice(1), 16);
  const ch = (shift: number) => {
    const va = (pa >> shift) & 255;
    const vb = (pb >> shift) & 255;
    return Math.round(va * 0.5 + vb * 0.5)
      .toString(16)
      .padStart(2, "0");
  };
  return `#${ch(16)}${ch(8)}${ch(0)}`;
}

function isLayout(value: LayoutId | "waves"): value is LayoutId {
  return (LAYOUTS as readonly string[]).includes(value);
}

function pickLayout(family: Family, rnd: () => number): LayoutId {
  if (rnd() < 0.38) return LAYOUTS[Math.floor(rnd() * LAYOUTS.length)];
  const set = BIASED[family].filter(isLayout);
  return set[Math.floor(rnd() * set.length)];
}

function pickPattern(rnd: () => number): PatternId {
  if (rnd() < 0.18) return "none";
  return PATTERNS[1 + Math.floor(rnd() * (PATTERNS.length - 1))];
}

function palette(family: Family, rnd: () => number) {
  const hue = Math.floor(rnd() * 360);
  const drift = rnd() * 18 - 9;
  let c1 = "#1c1916";
  let c2 = "#8c3a2f";
  let paper = "#f4f0e6";
  let ink = "#1c1916";
  let accent = "#8c3a2f";
  if (family === "editorial") {
    c1 = hslHex(24 + drift, 24, 16 + rnd() * 8);
    c2 = hslHex(18 + drift, 42, 38);
    paper = hslHex(36, 32, 93);
    ink = hslHex(24, 12, 12);
    accent = c2;
  } else if (family === "academic") {
    c1 = hslHex(208 + drift, 38, 24);
    c2 = hslHex(205 + drift, 28, 42);
    paper = "#f3f6f8";
    ink = "#17212b";
    accent = c1;
  } else if (family === "magazine") {
    c1 = "#141311";
    c2 = hslHex(hue, 58, 46);
    paper = "#f7f4ef";
    ink = "#161412";
    accent = c2;
  } else if (family === "soft") {
    c1 = hslHex(hue, 28, 62);
    c2 = hslHex((hue + 24) % 360, 22, 78);
    paper = hslHex(hue, 30, 95);
    ink = hslHex(hue, 18, 18);
    accent = hslHex(hue, 36, 38);
  } else if (family === "noir") {
    c1 = hslHex(hue, 10, 8 + rnd() * 6);
    c2 = hslHex(hue, 8, 18);
    paper = "#f3efe6";
    ink = "#f4efe6";
    accent = hslHex(hue, 18, 72);
  } else if (family === "bold") {
    c1 = hslHex(hue, 58, 32);
    c2 = hslHex((hue + 32) % 360, 52, 46);
    paper = "#f6f3ee";
    ink = "#1a1714";
    accent = c1;
  } else if (family === "desert") {
    c1 = hslHex(28 + drift, 46, 28);
    c2 = hslHex(36 + drift, 42, 58);
    paper = hslHex(38, 42, 92);
    ink = "#2a2118";
    accent = hslHex(16, 52, 36);
  } else {
    c1 = hslHex(188 + drift, 42, 22);
    c2 = hslHex(172 + drift, 36, 42);
    paper = "#f2f6f5";
    ink = "#14211f";
    accent = c1;
  }
  return { c1, c2, paper, ink, accent, on1: on(c1), on2: on(c2), onGrad: on(mix(c1, c2)) };
}

export function contrastOn(hex: string): string {
  if (!/^#[0-9a-fA-F]{6}$/.test(hex)) return "#1c1916";
  return on(hex);
}

export function mixHex(a: string, b: string): string {
  if (!/^#[0-9a-fA-F]{6}$/.test(a) || !/^#[0-9a-fA-F]{6}$/.test(b)) return /^#[0-9a-fA-F]{6}$/.test(a) ? a : "#1c1916";
  return mix(a, b);
}

function familyFromSeed(seed: string): Family | null {
  return FAMILIES.find((family) => seed.startsWith(`${family}-`)) ?? null;
}

export function templateFromSeed(seed: string): Template {
  const rnd = mulberry32(hashSeed(seed || "editorial-1"));
  const forced = familyFromSeed(seed);
  const family = forced ?? FAMILIES[Math.floor(rnd() * FAMILIES.length)];
  if (forced) rnd();
  const layout = pickLayout(family, rnd);
  const pattern = pickPattern(rnd);
  const colors = palette(family, rnd);
  const name = `${ADJ[Math.floor(rnd() * ADJ.length)]} ${NOUN[Math.floor(rnd() * NOUN.length)]}`;
  const angle = Math.round(rnd() * 360);
  const font: Template["font"] = rnd() > 0.42 ? "amiri" : "plex";
  return { id: seed || "editorial-1", name, family, layout, pattern, angle, font, ...colors };
}

export function templateSeeds(family: Family | "all", page: number, count = 18): string[] {
  const start = page * count;
  const prefix = family === "all" ? "all" : family;
  return Array.from({ length: count }, (_, index) => `${prefix}-${start + index}`);
}

export function randomSeed(): string {
  const family = FAMILIES[Math.floor(Math.random() * FAMILIES.length)];
  return `${family}-r${Math.random().toString(36).slice(2, 8)}`;
}

export function applyTemplateColors(doc: ProjectDoc, template: Template): ProjectDoc {
  return {
    ...doc,
    templateId: template.id,
    settings: {
      ...doc.settings,
      font: template.font,
      ink: contrastOn(template.paper),
      paper: template.paper,
      accent: template.accent,
    },
    cover: {
      ...doc.cover,
      layout: template.layout,
      pattern: template.pattern,
      color1: template.c1,
      color2: template.c2,
      angle: template.angle,
      ink: template.ink,
      paper: template.paper,
    },
  };
}

export function isLayoutId(value: string): value is LayoutId {
  return (LAYOUTS as readonly string[]).includes(value);
}

export function isPatternId(value: string): value is PatternId {
  return (PATTERNS as readonly string[]).includes(value);
}
