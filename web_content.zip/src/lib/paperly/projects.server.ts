import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { sanitizeDoc, type ProjectDoc } from "./model";

export type ProjectSummary = { id: string; name: string; updatedAt: string };

function assertId(id: string): string {
  if (typeof id !== "string" || !/^[a-zA-Z0-9_-]{6,80}$/.test(id)) {
    throw new Error("معرّف غير صالح");
  }
  return id;
}

export const listProjects = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<ProjectSummary[]> => {
    const sql = await getSql();
    const rows = await sql<{ id: string; name: string; updated_at: string }>`
      select id, name, to_char(updated_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as updated_at
      from projects
      where user_id = ${context.userId}
      order by updated_at desc
      limit 100
    `;
    return rows.map((row) => ({ id: row.id, name: row.name, updatedAt: String(row.updated_at) }));
  });

export const getProject = createServerFn({ method: "GET" })
  .validator((id: string) => assertId(id))
  .middleware([authMiddleware])
  .handler(async ({ context, data: id }): Promise<ProjectDoc> => {
    const sql = await getSql();
    const rows = await sql<{ doc: string }>`
      select doc from projects where id = ${id} and user_id = ${context.userId}
    `;
    if (!rows[0]) throw new Error("المشروع غير موجود");
    let raw: unknown = rows[0].doc;
    if (typeof raw === "string") {
      try {
        raw = JSON.parse(raw);
      } catch {
        throw new Error("تعذر قراءة المشروع");
      }
    }
    const parsed = sanitizeDoc(raw);
    if (!parsed) throw new Error("تعذر قراءة المشروع");
    return parsed.doc;
  });

export const saveProject = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const parsed = sanitizeDoc(input);
    if (!parsed) throw new Error("مشروع غير صالح");
    if (JSON.stringify(parsed.doc).length > 5_500_000) throw new Error("المشروع أكبر من الحد المسموح");
    return parsed;
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const doc = data.doc;
    const payload = JSON.stringify(doc);
    await sql`
      insert into projects (id, user_id, name, doc, updated_at)
      values (${doc.id}, ${context.userId}, ${doc.name}, ${payload}, to_timestamp(${doc.updatedAt / 1000}))
      on conflict (id) do update
      set name = excluded.name,
          doc = excluded.doc,
          updated_at = excluded.updated_at
      where projects.user_id = ${context.userId}
        and projects.updated_at <= excluded.updated_at
    `;
    const rows = await sql<{ id: string }>`
      select id from projects where id = ${doc.id} and user_id = ${context.userId}
    `;
    if (!rows[0]) throw new Error("تعذر حفظ المشروع");
    return { id: doc.id, warnings: data.warnings, updatedAt: doc.updatedAt };
  });

export const deleteProject = createServerFn({ method: "POST" })
  .validator((id: string) => assertId(id))
  .middleware([authMiddleware])
  .handler(async ({ context, data: id }) => {
    const sql = await getSql();
    await sql`delete from projects where id = ${id} and user_id = ${context.userId}`;
    return { id };
  });
