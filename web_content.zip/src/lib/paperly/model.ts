import { applyTemplateColors, templateFromSeed, type Template } from "./templates";

export const DOC_TYPES = [
  "book",
  "magazine",
  "report",
  "research",
  "portfolio",
  "story",
  "poetry",
  "newsletter",
  "blank",
] as const;

export type DocType = (typeof DOC_TYPES)[number];

export const TYPE_LABEL: Record<DocType, string> = {
  book: "كتاب",
  magazine: "مجلة",
  report: "تقرير",
  research: "بحث",
  portfolio: "أعمال",
  story: "قصة",
  poetry: "شعر",
  newsletter: "نشرة",
  blank: "فارغ",
};

export const BLOCK_KINDS = [
  "chapter",
  "heading",
  "text",
  "quote",
  "image",
  "file",
  "list",
  "pagebreak",
] as const;

export type BlockKind = (typeof BLOCK_KINDS)[number];

export const BLOCK_LABEL: Record<BlockKind, string> = {
  chapter: "فصل",
  heading: "عنوان",
  text: "فقرة",
  quote: "اقتباس",
  image: "صورة",
  file: "ملف",
  list: "قائمة",
  pagebreak: "فاصل صفحة",
};

export type Block = {
  id: string;
  kind: BlockKind;
  title?: string;
  text?: string;
  src?: string;
  caption?: string;
  fileName?: string;
  fileMime?: string;
  fileSize?: number;
  items?: string[];
};

export type Cover = {
  title: string;
  subtitle: string;
  author: string;
  image: string;
  layout: string;
  pattern: string;
  color1: string;
  color2: string;
  angle: number;
  ink: string;
  paper: string;
};

export type Settings = {
  margin: number;
  fontSize: number;
  lineHeight: number;
  pageNumbers: boolean;
  font: "amiri" | "plex";
  ink: string;
  paper: string;
  accent: string;
};

export type ProjectDoc = {
  id: string;
  version: 3;
  name: string;
  type: DocType;
  templateId: string;
  settings: Settings;
  cover: Cover;
  blocks: Block[];
  updatedAt: number;
};

export type RenderBlock = Block & {
  sourceId: string;
  continued?: boolean;
  continues?: boolean;
};

export type Page =
  | { kind: "cover" }
  | { kind: "toc"; entries: { id: string; title: string; page: number }[] }
  | { kind: "content"; blocks: RenderBlock[] };

export const PAGE_W = 794;
export const PAGE_H = 1123;

const LEGACY_THEMES: Record<string, string> = {
  classic: "desert-2",
  elegant: "editorial-1",
  midnight: "noir-4",
  soft: "soft-1",
  editorial: "editorial-4",
  academic: "academic-2",
  modern: "bold-6",
};

export function uid(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `id-${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
}

function clamp(n: number, min: number, max: number, fallback: number) {
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

function asString(value: unknown, max: number): string {
  if (typeof value !== "string") return "";
  return value.slice(0, max);
}

function isDocType(value: string): value is DocType {
  return (DOC_TYPES as readonly string[]).includes(value);
}

function isKind(value: string): value is BlockKind {
  return (BLOCK_KINDS as readonly string[]).includes(value);
}

const IMAGE_SRC = /^data:image\/(png|jpeg|jpg|webp);base64,[a-z0-9+/=\s]+$/i;
const FILE_SRC = /^data:[a-z0-9.+-]+\/[a-z0-9.+-]+;base64,[a-z0-9+/=\s]+$/i;

export function sanitizeDoc(input: unknown): { doc: ProjectDoc; warnings: string[] } | null {
  if (!input || typeof input !== "object") return null;
  const raw = input as Record<string, unknown>;
  const warnings: string[] = [];
  const id = asString(raw.id, 80).trim();
  if (!/^[a-zA-Z0-9_-]{6,80}$/.test(id)) return null;

  const typeRaw = asString(raw.type, 40);
  const type: DocType = isDocType(typeRaw) ? typeRaw : "book";
  const templateId = asString(raw.templateId, 80) || "editorial-1";
  const template = templateFromSeed(templateId);

  const settingsRaw = (raw.settings && typeof raw.settings === "object" ? raw.settings : {}) as Record<string, unknown>;
  const coverRaw = (raw.cover && typeof raw.cover === "object" ? raw.cover : {}) as Record<string, unknown>;

  const settings: Settings = {
    margin: clamp(Number(settingsRaw.margin), 40, 120, 72),
    fontSize: clamp(Number(settingsRaw.fontSize), 13, 28, 18),
    lineHeight: clamp(Number(settingsRaw.lineHeight), 1.35, 2.4, 1.85),
    pageNumbers: settingsRaw.pageNumbers !== false,
    font: settingsRaw.font === "plex" ? "plex" : "amiri",
    ink: hex(settingsRaw.ink, template.ink),
    paper: hex(settingsRaw.paper, template.paper),
    accent: hex(settingsRaw.accent, template.accent),
  };

  let image = asString(coverRaw.image, 520_000);
  if (image && !IMAGE_SRC.test(image)) {
    image = "";
    warnings.push("أُزيلت صورة غلاف غير مدعومة");
  }

  const cover: Cover = {
    title: asString(coverRaw.title, 180) || "بدون عنوان",
    subtitle: asString(coverRaw.subtitle, 240),
    author: asString(coverRaw.author, 160),
    image,
    layout: asString(coverRaw.layout, 40) || template.layout,
    pattern: asString(coverRaw.pattern, 40) || template.pattern,
    color1: hex(coverRaw.color1, template.c1),
    color2: hex(coverRaw.color2, template.c2),
    angle: clamp(Number(coverRaw.angle), 0, 360, template.angle),
    ink: hex(coverRaw.ink, template.ink),
    paper: hex(coverRaw.paper, template.paper),
  };

  const blocksIn = Array.isArray(raw.blocks) ? raw.blocks.slice(0, 300) : [];
  const seen = new Set<string>();
  const blocks: Block[] = [];
  for (const item of blocksIn) {
    if (!item || typeof item !== "object") continue;
    const b = item as Record<string, unknown>;
    const kindRaw = asString(b.kind, 40);
    if (!isKind(kindRaw)) continue;
    let bid = asString(b.id, 80);
    if (!/^[a-zA-Z0-9_~.-]{4,80}$/.test(bid) || seen.has(bid)) bid = uid();
    seen.add(bid);
    const block: Block = { id: bid, kind: kindRaw };
    if (kindRaw === "chapter" || kindRaw === "heading") block.title = asString(b.title, 300);
    if (kindRaw === "chapter" || kindRaw === "heading" || kindRaw === "text" || kindRaw === "quote") {
      block.text = asString(b.text, 100_000);
    }
    if (kindRaw === "image") {
      const src = asString(b.src, 520_000);
      if (src && IMAGE_SRC.test(src)) block.src = src;
      else if (src) warnings.push("أُزيلت صورة أكبر من الحد أو بصيغة غير مدعومة");
      block.caption = asString(b.caption, 300);
    }
    if (kindRaw === "file") {
      const src = asString(b.src, 1_200_000);
      if (src && FILE_SRC.test(src)) block.src = src;
      else if (src) warnings.push("أُزيل ملف غير مدعوم");
      block.fileName = asString(b.fileName, 180) || "ملف";
      block.fileMime = asString(b.fileMime, 120);
      block.fileSize = clamp(Number(b.fileSize), 0, 2_000_000, 0);
      block.caption = asString(b.caption, 300);
    }
    if (kindRaw === "list") {
      const items = Array.isArray(b.items) ? b.items : [];
      block.items = items.slice(0, 80).map((x) => asString(x, 500)).filter((x) => x.length > 0);
      block.title = asString(b.title, 300);
    }
    blocks.push(block);
  }

  const name = asString(raw.name, 120).trim() || `${TYPE_LABEL[type]} جديد`;
  const updatedAt = clamp(Number(raw.updatedAt), 0, Date.now() + 86_400_000, Date.now());

  return {
    doc: {
      id,
      version: 3,
      name,
      type,
      templateId,
      settings,
      cover,
      blocks,
      updatedAt,
    },
    warnings,
  };
}

function hex(value: unknown, fallback: string): string {
  if (typeof value === "string" && /^#[0-9a-fA-F]{6}$/.test(value)) return value.toLowerCase();
  return fallback;
}

export function fresh(type: DocType = "book"): ProjectDoc {
  const seed =
    type === "magazine"
      ? "magazine-3"
      : type === "research"
        ? "academic-2"
        : type === "poetry"
          ? "soft-5"
          : type === "report"
            ? "editorial-6"
            : "editorial-1";
  const base = blank(type, seed);
  return applyTemplateColors(base, templateFromSeed(seed));
}

function blank(type: DocType, seed: string): ProjectDoc {
  const t = templateFromSeed(seed);
  return {
    id: uid(),
    version: 3,
    name: `${TYPE_LABEL[type]} جديد`,
    type,
    templateId: t.id,
    settings: {
      margin: 72,
      fontSize: type === "poetry" ? 20 : 18,
      lineHeight: type === "poetry" ? 2 : 1.85,
      pageNumbers: true,
      font: t.font,
      ink: t.ink,
      paper: t.paper,
      accent: t.accent,
    },
    cover: {
      title: defaultTitle(type),
      subtitle: defaultSubtitle(type),
      author: "اسم المؤلف",
      image: "",
      layout: t.layout,
      pattern: t.pattern,
      color1: t.c1,
      color2: t.c2,
      angle: t.angle,
      ink: t.ink,
      paper: t.paper,
    },
    blocks: starterBlocks(type),
    updatedAt: Date.now(),
  };
}

function defaultTitle(type: DocType): string {
  switch (type) {
    case "magazine":
      return "اسم المجلة";
    case "report":
      return "عنوان التقرير";
    case "research":
      return "عنوان البحث";
    case "portfolio":
      return "معرض الأعمال";
    case "story":
      return "عنوان القصة";
    case "poetry":
      return "ديوان";
    case "newsletter":
      return "النشرة";
    case "blank":
      return "مستند";
    default:
      return "عنوان الكتاب";
  }
}

function defaultSubtitle(type: DocType): string {
  switch (type) {
    case "research":
      return "ملخص ومسألة البحث";
    case "report":
      return "تقرير موجز";
    case "poetry":
      return "مجموعة قصائد";
    default:
      return "العنوان الفرعي";
  }
}

function starterBlocks(type: DocType): Block[] {
  if (type === "blank") return [{ id: uid(), kind: "text", text: "" }];
  if (type === "poetry") {
    return [
      { id: uid(), kind: "heading", title: "القصيدة الأولى", text: "" },
      { id: uid(), kind: "text", text: "اكتب البيت هنا\nثم البيت الذي يليه\nوسطرًا ثالثًا إن شئت" },
      { id: uid(), kind: "heading", title: "القصيدة الثانية", text: "" },
      { id: uid(), kind: "text", text: "الصق القصيدة كاملة، كل بيت في سطر." },
    ];
  }
  if (type === "report" || type === "research") {
    return [
      {
        id: uid(),
        kind: "chapter",
        title: type === "research" ? "المقدمة" : "الملخص",
        text: "اكتب الفكرة الرئيسية هنا. يمكنك اللصق من أي محرر، وستُقسَّم الفقرات إلى صفحات عند التصدير.",
      },
      {
        id: uid(),
        kind: "heading",
        title: "النقاط الأساسية",
        text: "",
      },
      { id: uid(), kind: "list", title: "", items: ["النقطة الأولى", "النقطة الثانية", "النقطة الثالثة"] },
      { id: uid(), kind: "quote", text: "اقتباس أو نتيجة تريد إبرازها." },
    ];
  }
  return [
    {
      id: uid(),
      kind: "chapter",
      title: "الفصل الأول",
      text: "ابدأ الكتابة هنا، أو الصق نصًا طويلًا من الحافظة. الفقرات الطويلة تُقسَّم تلقائيًا على صفحات بحجم A4.",
    },
    {
      id: uid(),
      kind: "chapter",
      title: "الفصل الثاني",
      text: "أضف صورًا بالسحب والإفلات، أو أرفق ملفات تبقى قابلة للتنزيل من داخل المستند.",
    },
  ];
}

export function textToBlocks(raw: string): Block[] {
  const text = raw.replace(/\r\n/g, "\n").trim();
  if (!text) return [];
  const parts = text.split(/\n{2,}/);
  const blocks: Block[] = [];
  for (const part of parts) {
    const lines = part.split("\n");
    const first = lines[0]?.trim() ?? "";
    if (/^#\s+/.test(first)) {
      blocks.push({
        id: uid(),
        kind: "chapter",
        title: first.replace(/^#\s+/, "").slice(0, 300),
        text: lines.slice(1).join("\n").trim(),
      });
      continue;
    }
    if (/^##\s+/.test(first)) {
      blocks.push({
        id: uid(),
        kind: "heading",
        title: first.replace(/^##\s+/, "").slice(0, 300),
        text: lines.slice(1).join("\n").trim(),
      });
      continue;
    }
    if (lines.length > 0 && lines.every((line) => /^\s*>\s?/.test(line))) {
      blocks.push({
        id: uid(),
        kind: "quote",
        text: lines.map((line) => line.replace(/^\s*>\s?/, "")).join("\n"),
      });
      continue;
    }
    if (lines.length > 1 && lines.every((line) => /^\s*[-•–]\s+/.test(line))) {
      blocks.push({
        id: uid(),
        kind: "list",
        items: lines.map((line) => line.replace(/^\s*[-•–]\s+/, "").trim()).filter(Boolean),
      });
      continue;
    }
    if (
      lines.length === 1 &&
      first.length > 0 &&
      first.length <= 48 &&
      !/[.!?؟،]/.test(first) &&
      /^(فصل|الباب|القسم)\s+/.test(first)
    ) {
      blocks.push({ id: uid(), kind: "chapter", title: first, text: "" });
      continue;
    }
    blocks.push({ id: uid(), kind: "text", text: part.trim() });
  }
  return blocks;
}

export function parseProject(input: unknown): { doc: ProjectDoc; warnings: string[] } | null {
  if (!input || typeof input !== "object") return null;
  const raw = input as Record<string, unknown>;
  if (raw.version === 3 && raw.cover && raw.settings) return sanitizeDoc(raw);

  const typeRaw = asString(raw.type, 40);
  const type: DocType = isDocType(typeRaw) ? typeRaw : "book";
  const theme = asString(raw.theme, 40);
  const templateId = LEGACY_THEMES[theme] || "editorial-1";
  const template = templateFromSeed(templateId);
  const coverRaw = (raw.cover && typeof raw.cover === "object" ? raw.cover : {}) as Record<string, unknown>;
  const settingsRaw = (raw.settings && typeof raw.settings === "object" ? raw.settings : {}) as Record<string, unknown>;
  const migrated = {
    id: asString(raw.id, 80) || uid(),
    version: 3,
    name: asString(raw.name, 120) || `${TYPE_LABEL[type]}`,
    type,
    templateId,
    settings: {
      margin: Number(settingsRaw.margin) || 72,
      fontSize: Number(settingsRaw.fontSize) || 18,
      lineHeight: Number(settingsRaw.lineHeight) || 1.9,
      pageNumbers: settingsRaw.pageNumbers !== false,
      font: template.font,
      ink: template.ink,
      paper: template.paper,
      accent: template.accent,
    },
    cover: {
      title: asString(coverRaw.title, 180) || defaultTitle(type),
      subtitle: asString(coverRaw.subtitle, 240),
      author: asString(coverRaw.author, 160),
      image: asString(coverRaw.image, 520_000),
      layout: template.layout,
      pattern: template.pattern,
      color1: hex(coverRaw.color1, template.c1),
      color2: hex(coverRaw.color2, template.c2),
      angle: Number(coverRaw.shadeAngle ?? coverRaw.angle) || template.angle,
      ink: template.ink,
      paper: template.paper,
    },
    blocks: Array.isArray(raw.blocks) ? raw.blocks : [],
    updatedAt: Number(raw.updatedAt) || Date.now(),
  };
  return sanitizeDoc(migrated);
}

function charsPerLine(fontSize: number, innerW: number) {
  return Math.max(8, Math.floor(innerW / (fontSize * 0.62)));
}

function textHeight(text: string, fontSize: number, lineHeight: number, innerW: number, extra = 0) {
  const cpl = charsPerLine(fontSize, innerW);
  const lines = (text || "").split("\n");
  if (!text) return extra;
  let count = 0;
  for (const line of lines) count += Math.max(1, Math.ceil(line.length / cpl));
  return count * fontSize * lineHeight + extra;
}

export function measureBlock(block: RenderBlock, doc: ProjectDoc, innerW: number): number {
  const fs = doc.settings.fontSize;
  const lh = doc.settings.lineHeight;
  switch (block.kind) {
    case "chapter":
      return textHeight(block.title || "", fs * 1.7, 1.35, innerW, block.title ? 18 : 0) + textHeight(block.text || "", fs, lh, innerW, block.text ? 12 : 0);
    case "heading":
      return textHeight(block.title || "", fs * 1.25, 1.35, innerW, block.title ? 12 : 0) + textHeight(block.text || "", fs, lh, innerW, block.text ? 8 : 0);
    case "text":
      return textHeight(block.text || " ", fs, lh, innerW, 12);
    case "quote":
      return textHeight(block.text || " ", fs, lh, innerW, 28);
    case "list":
      return (block.items?.length ? block.items : [""]).reduce(
        (sum, item) => sum + textHeight(item, fs, lh, innerW, 8),
        block.title ? 36 : 8,
      );
    case "image":
      return 400 + (block.caption ? 32 : 8);
    case "file":
      return 108;
    default:
      return 20;
  }
}

function toRender(block: Block, extra: Partial<RenderBlock> = {}): RenderBlock {
  return { ...block, sourceId: block.id, ...extra };
}

export function paginate(doc: ProjectDoc): Page[] {
  const margin = doc.settings.margin;
  const innerW = PAGE_W - margin * 2;
  const innerH = PAGE_H - margin * 2 - (doc.settings.pageNumbers ? 36 : 12);
  const content: { kind: "content"; blocks: RenderBlock[] }[] = [];
  let bucket: RenderBlock[] = [];
  let used = 0;

  const flush = () => {
    if (!bucket.length) return;
    content.push({ kind: "content", blocks: bucket });
    bucket = [];
    used = 0;
  };

  const place = (block: RenderBlock) => {
    const height = Math.min(measureBlock(block, doc, innerW), innerH);
    if (bucket.length && used + height > innerH) flush();
    bucket.push(block);
    used += height;
  };

  for (const block of doc.blocks) {
    if (block.kind === "pagebreak") {
      flush();
      continue;
    }
    for (const part of splitBlock(block, doc, innerW, innerH)) place(part);
  }
  flush();

  const heads = doc.blocks.some((block) => block.kind === "chapter" || block.kind === "heading");
  const pages: Page[] = [{ kind: "cover" }];
  const firstContent = heads ? 3 : 2;
  if (heads) {
    const entries: { id: string; title: string; page: number }[] = [];
    content.forEach((page, index) => {
      for (const block of page.blocks) {
        if ((block.kind === "chapter" || block.kind === "heading") && !block.continued) {
          entries.push({
            id: block.sourceId,
            title: block.title?.trim() || "بدون عنوان",
            page: firstContent + index,
          });
        }
      }
    });
    pages.push({ kind: "toc", entries });
  }
  if (content.length) pages.push(...content);
  else pages.push({ kind: "content", blocks: [] });
  return pages;
}

function splitBlock(block: Block, doc: ProjectDoc, innerW: number, innerH: number): RenderBlock[] {
  const whole = toRender(block);
  if (measureBlock(whole, doc, innerW) <= innerH) return [whole];
  if (block.kind === "list" && block.items && block.items.length > 1) {
    const out: RenderBlock[] = [];
    let items: string[] = [];
    const push = (continued: boolean) => {
      if (!items.length) return;
      out.push(toRender({ ...block, items: [...items] }, { id: continued ? `${block.id}~${out.length}` : block.id, continued, title: continued ? "" : block.title }));
      items = [];
    };
    for (const item of block.items) {
      const trial = toRender({ ...block, items: [...items, item], title: items.length ? "" : block.title }, { continued: out.length > 0 });
      if (items.length && measureBlock(trial, doc, innerW) > innerH) push(out.length > 0);
      items.push(item);
    }
    push(out.length > 0);
    return out.map((part, index) => ({ ...part, continues: index < out.length - 1 }));
  }
  if (!block.text || !["chapter", "heading", "text", "quote"].includes(block.kind)) return [whole];

  const parts: RenderBlock[] = [];
  let rest = block.text;
  let guard = 0;
  while (rest.length && guard < 80) {
    guard += 1;
    const first = parts.length === 0;
    let lo = 1;
    let hi = rest.length;
    let best = 1;
    while (lo <= hi) {
      const mid = Math.floor((lo + hi) / 2);
      const trial = toRender(
        { ...block, text: rest.slice(0, mid), title: first ? block.title : "" },
        { continued: !first },
      );
      if (measureBlock(trial, doc, innerW) <= innerH) {
        best = mid;
        lo = mid + 1;
      } else hi = mid - 1;
    }
    let cut = best;
    if (cut < rest.length) {
      const window = rest.slice(0, cut);
      const breakAt = Math.max(window.lastIndexOf("\n"), window.lastIndexOf(" "));
      if (breakAt > cut * 0.55) cut = breakAt + 1;
    }
    if (cut < 1) cut = 1;
    parts.push(
      toRender(
        { ...block, text: rest.slice(0, cut).trimEnd(), title: first ? block.title : "" },
        { id: first ? block.id : `${block.id}~${parts.length}`, continued: !first },
      ),
    );
    rest = rest.slice(cut).replace(/^\s+/, "");
  }
  return parts.map((part, index) => ({ ...part, continues: index < parts.length - 1 }));
}

export function moveBlock(blocks: Block[], id: string, dir: -1 | 1): Block[] {
  const index = blocks.findIndex((block) => block.id === id);
  const next = index + dir;
  if (index < 0 || next < 0 || next >= blocks.length) return blocks;
  const copy = blocks.slice();
  const [item] = copy.splice(index, 1);
  copy.splice(next, 0, item);
  return copy;
}

export function applyTemplate(doc: ProjectDoc, template: Template): ProjectDoc {
  return applyTemplateColors({ ...doc, templateId: template.id, updatedAt: Date.now() }, template);
}

export function formatBytes(size: number): string {
  if (!size) return "";
  if (size < 1024) return `${size} ب`;
  if (size < 1024 * 1024) return `${Math.round(size / 1024)} ك.ب`;
  return `${(size / (1024 * 1024)).toFixed(1)} م.ب`;
}
