export async function downloadPdf(
  root: HTMLElement,
  name: string,
  onProgress?: (current: number, total: number) => void,
): Promise<void> {
  const sheets = [...root.querySelectorAll<HTMLElement>(".sheet")];
  if (!sheets.length) throw new Error("لا توجد صفحات للتصدير");
  await document.fonts.ready;
  const [{ jsPDF }, html2canvasMod] = await Promise.all([import("jspdf"), import("html2canvas")]);
  const html2canvas = html2canvasMod.default;
  const host = document.createElement("div");
  host.setAttribute("aria-hidden", "true");
  host.style.cssText = "position:fixed;left:-12000px;top:0;width:794px;background:#fff;z-index:-1;";
  document.body.appendChild(host);
  const pdf = new jsPDF({ unit: "mm", format: "a4", orientation: "portrait", compress: true });
  try {
    for (let index = 0; index < sheets.length; index += 1) {
      onProgress?.(index + 1, sheets.length);
      const clone = sheets[index].cloneNode(true) as HTMLElement;
      clone.style.transform = "none";
      clone.style.zoom = "1";
      clone.style.margin = "0";
      clone.querySelectorAll(".is-selected").forEach((node) => node.classList.remove("is-selected"));
      host.appendChild(clone);
      await new Promise((resolve) => requestAnimationFrame(() => resolve(null)));
      const canvas = await html2canvas(clone, {
        scale: 2,
        backgroundColor: "#ffffff",
        useCORS: true,
        logging: false,
        width: 794,
        height: 1123,
        windowWidth: 1200,
      });
      const image = canvas.toDataURL("image/jpeg", 0.92);
      if (index > 0) pdf.addPage();
      pdf.addImage(image, "JPEG", 0, 0, 210, 297, undefined, "FAST");
      host.removeChild(clone);
    }
  } finally {
    host.remove();
  }
  const safe = (name || "paperly").replace(/[\\/:*?"<>|]/g, "-").trim() || "paperly";
  pdf.save(`${safe}.pdf`);
}
