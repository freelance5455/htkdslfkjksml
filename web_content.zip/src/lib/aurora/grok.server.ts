import { createHash, randomBytes } from "node:crypto";
import type { AuroraResponse, ChatTurn, Citation } from "./types";

const CHAT_MODEL = "grok-4.7";
const IMAGE_MODEL = "grok-imagine-image";
const CHAT_LIMIT = 40;
const IMAGE_LIMIT = 4;
const GLOBAL_CHAT = 240;
const GLOBAL_IMAGE = 30;

type Bucket = { chat: number; image: number };

const salt = randomBytes(16).toString("hex");
const buckets = new Map<string, Bucket>();
const globalUse: Bucket = { chat: 0, image: 0 };
let globalHour = hourStamp();

function hourStamp() {
  return Math.floor(Date.now() / 3_600_000);
}

function sweep() {
  const hour = hourStamp();
  if (hour !== globalHour) {
    globalHour = hour;
    globalUse.chat = 0;
    globalUse.image = 0;
    buckets.clear();
  }
}

function visitorKey(request: Request) {
  const forwarded = request.headers.get("x-forwarded-for") ?? "";
  const ip = forwarded.split(",")[0]?.trim() || "self";
  return createHash("sha256")
    .update(`${salt}|${hourStamp()}|${ip}`)
    .digest("hex")
    .slice(0, 24);
}

function take(request: Request, kind: "chat" | "image", weight: number): string | null {
  sweep();
  const cap = kind === "chat" ? CHAT_LIMIT : IMAGE_LIMIT;
  const globalCap = kind === "chat" ? GLOBAL_CHAT : GLOBAL_IMAGE;
  if (globalUse[kind] + weight > globalCap) {
    return "Aurora is busy right now. Try again in a little while.";
  }
  const key = visitorKey(request);
  const bucket = buckets.get(key) ?? { chat: 0, image: 0 };
  if (bucket[kind] + weight > cap) {
    return kind === "image"
      ? "Picture creates are paused for this visit. Talk still works, or try again later."
      : "This visit has used its share of replies. Try again later. Shred does not reset it.";
  }
  bucket[kind] += weight;
  globalUse[kind] += weight;
  buckets.set(key, bucket);
  return null;
}

function systemPrompt(notes: string) {
  const pinned = notes.replace(/\s+/g, " ").trim().slice(0, 800);
  return [
    "You are Aurora, a direct creative and technical assistant.",
    "The person is anonymous. Do not ask who they are. Do not infer, request, or mention their location, identity, or device.",
    "Help with writing, code, planning, analysis, design, and ideas. Be concrete. Skip filler and stock disclaimers on ordinary requests. Match their language.",
    "You only know this conversation and the session notes. There is no account and nothing persists after the thread is cleared.",
    "When sources are present, use them and keep their links. Never invent sources, quotes, or numbers.",
    pinned ? `Session notes the person pinned: ${pinned}` : "Session notes: none.",
  ].join("\n");
}

function json(body: AuroraResponse, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "content-type": "application/json",
      "cache-control": "no-store",
      "referrer-policy": "no-referrer",
      "permissions-policy": "geolocation=()",
    },
  });
}

function safeDetail(status: number, raw: string) {
  const text = raw.replace(/sk-[a-zA-Z0-9_-]+/g, "").slice(0, 180);
  if (status === 429) return "The model is busy. Try again in a moment.";
  if (/safety|content.?policy|violate|not allowed|moderat/i.test(text)) {
    return "That request was refused.";
  }
  if (status === 400) return "The model could not take that request.";
  return "Aurora could not finish that. Try again.";
}

async function readUpstream(res: Response) {
  try {
    return await res.text();
  } catch {
    return "";
  }
}

function citationsFrom(value: unknown): Citation[] {
  const found: Citation[] = [];
  const push = (url: unknown, title?: unknown) => {
    if (typeof url !== "string" || !/^https?:\/\//i.test(url)) return;
    const name = typeof title === "string" && title.trim() ? title.trim() : url;
    if (!found.some((item) => item.url === url)) found.push({ url, title: name.slice(0, 140) });
  };
  const walk = (node: unknown) => {
    if (!node || typeof node !== "object") return;
    if (Array.isArray(node)) {
      for (const item of node) walk(item);
      return;
    }
    const record = node as Record<string, unknown>;
    if (record.type === "url_citation") push(record.url, record.title);
    if (typeof record.url === "string" && (record.title || record.type === "url_citation")) {
      push(record.url, record.title);
    }
    for (const nested of Object.values(record)) {
      if (nested && typeof nested === "object") walk(nested);
    }
  };
  walk(value);
  return found.slice(0, 8);
}

function textFromResponse(data: unknown): { text: string; citations: Citation[] } {
  if (!data || typeof data !== "object") return { text: "", citations: [] };
  const record = data as Record<string, unknown>;
  const choices = record.choices;
  if (Array.isArray(choices) && choices[0] && typeof choices[0] === "object") {
    const message = (choices[0] as { message?: { content?: unknown; refusal?: unknown } }).message;
    const content = typeof message?.content === "string" ? message.content : "";
    const refusal = typeof message?.refusal === "string" ? message.refusal : "";
    return { text: content || refusal, citations: citationsFrom(record.citations) };
  }
  let text = "";
  const output = record.output;
  if (Array.isArray(output)) {
    for (const item of output) {
      if (!item || typeof item !== "object") continue;
      const message = item as { type?: string; content?: unknown };
      if (message.type !== "message" || !Array.isArray(message.content)) continue;
      for (const part of message.content) {
        if (!part || typeof part !== "object") continue;
        const chunk = part as { text?: unknown };
        if (typeof chunk.text === "string") text += chunk.text;
      }
    }
  }
  return { text, citations: citationsFrom(data) };
}

async function postJson(path: string, body: unknown, timeoutMs: number) {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return { ok: false as const, status: 503, raw: "missing" };
  const run = () =>
    fetch(`https://api.x.ai${path}`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(timeoutMs),
    });
  let res = await run();
  if (res.status === 429 || res.status >= 500) {
    res = await run();
  }
  const raw = await readUpstream(res);
  if (!res.ok) return { ok: false as const, status: res.status, raw };
  try {
    return { ok: true as const, data: JSON.parse(raw) as unknown };
  } catch {
    return { ok: false as const, status: 502, raw: "" };
  }
}

function cleanTurns(turns: ChatTurn[]) {
  return turns
    .filter((turn) => (turn.role === "user" || turn.role === "assistant") && turn.content.trim())
    .slice(-12)
    .map((turn) => ({
      role: turn.role,
      content: turn.content.trim().slice(0, 4000),
    }));
}

async function chat(turns: ChatTurn[], notes: string, web: boolean, deep: boolean): Promise<AuroraResponse> {
  const messages = [{ role: "system" as const, content: systemPrompt(notes) }, ...cleanTurns(turns)];
  if (web) {
    const searched = await postJson(
      "/v1/responses",
      {
        model: CHAT_MODEL,
        store: false,
        max_output_tokens: deep ? 1800 : 1100,
        reasoning: { effort: deep ? "high" : "low" },
        tools: [{ type: "web_search" }],
        input: messages,
      },
      deep ? 70_000 : 45_000,
    );
    if (searched.ok) {
      const parsed = textFromResponse(searched.data);
      if (parsed.text.trim()) {
        return { ok: true, kind: "chat", text: parsed.text.trim(), citations: parsed.citations };
      }
    }
  }
  const completed = await postJson(
    "/v1/chat/completions",
    {
      model: CHAT_MODEL,
      messages,
      max_tokens: deep ? 1100 : 800,
      reasoning_effort: deep ? "high" : "low",
      temperature: 0.7,
    },
    deep ? 70_000 : 40_000,
  );
  if (!completed.ok) return { ok: false, error: safeDetail(completed.status, completed.raw) };
  const parsed = textFromResponse(completed.data);
  if (!parsed.text.trim()) return { ok: false, error: "Aurora came back empty. Try rephrasing." };
  return { ok: true, kind: "chat", text: parsed.text.trim(), citations: parsed.citations };
}

async function image(prompt: string): Promise<AuroraResponse> {
  const generated = await postJson(
    "/v1/images/generations",
    {
      model: IMAGE_MODEL,
      prompt: prompt.slice(0, 2000),
      n: 1,
      response_format: "b64_json",
    },
    90_000,
  );
  if (!generated.ok) return { ok: false, error: safeDetail(generated.status, generated.raw) };
  const data = generated.data as { data?: { b64_json?: string; mime_type?: string }[] };
  const first = data.data?.[0];
  if (!first?.b64_json) return { ok: false, error: "No picture came back. Try a different description." };
  const mime = first.mime_type && /^image\/(png|jpeg|webp)$/.test(first.mime_type) ? first.mime_type : "image/png";
  return { ok: true, kind: "image", image: `data:${mime};base64,${first.b64_json}`, mime };
}

type Incoming = {
  kind?: unknown;
  messages?: unknown;
  notes?: unknown;
  web?: unknown;
  deep?: unknown;
  prompt?: unknown;
};

export async function handleAurora(request: Request): Promise<Response> {
  if (!process.env.XAI_API_KEY) {
    return json({ ok: false, error: "Aurora's model is not available in this environment." }, 503);
  }
  let body: Incoming;
  try {
    body = (await request.json()) as Incoming;
  } catch {
    return json({ ok: false, error: "That request was not readable." }, 400);
  }

  if (body.kind === "image") {
    const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
    if (prompt.length < 2 || prompt.length > 2000) {
      return json({ ok: false, error: "Describe the picture in a few words, under 2000 characters." }, 400);
    }
    const limited = take(request, "image", 1);
    if (limited) return json({ ok: false, error: limited }, 429);
    try {
      return json(await image(prompt));
    } catch {
      return json({ ok: false, error: "The picture request timed out. Try again." }, 504);
    }
  }

  if (body.kind !== "chat" || !Array.isArray(body.messages)) {
    return json({ ok: false, error: "Unknown request." }, 400);
  }
  const turns: ChatTurn[] = [];
  for (const item of body.messages) {
    if (!item || typeof item !== "object") continue;
    const record = item as { role?: unknown; content?: unknown };
    if ((record.role !== "user" && record.role !== "assistant") || typeof record.content !== "string") continue;
    turns.push({ role: record.role, content: record.content });
  }
  if (!turns.some((turn) => turn.role === "user")) {
    return json({ ok: false, error: "Say something first." }, 400);
  }
  const notes = typeof body.notes === "string" ? body.notes : "";
  const web = body.web === true;
  const deep = body.deep === true;
  const limited = take(request, "chat", deep ? 2 : 1);
  if (limited) return json({ ok: false, error: limited }, 429);
  try {
    return json(await chat(turns, notes, web, deep));
  } catch {
    return json({ ok: false, error: "The reply timed out. Try again, or turn Deep off." }, 504);
  }
}
