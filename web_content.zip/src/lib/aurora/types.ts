export type ChatTurn = {
  role: "user" | "assistant";
  content: string;
};

export type Citation = {
  url: string;
  title: string;
};

export type AuroraOk =
  | { ok: true; kind: "chat"; text: string; citations: Citation[] }
  | { ok: true; kind: "image"; image: string; mime: string };

export type AuroraErr = { ok: false; error: string };

export type AuroraResponse = AuroraOk | AuroraErr;
