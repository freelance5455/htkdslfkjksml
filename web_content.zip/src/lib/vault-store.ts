import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  generateTxId,
  NETWORK_BY_ID,
  type NetworkId,
  type TokenId,
} from "./chains";
import { roundAud } from "./money";

export type Earning = {
  id: string;
  amountAud: number;
  source: string;
  note: string;
  createdAt: number;
};

export type PayoutStatus = "pending" | "confirmed";

export type Payout = {
  id: string;
  amountAud: number;
  tokenAmount: number;
  feeAud: number;
  token: TokenId;
  network: NetworkId;
  walletAddress: string;
  txId: string;
  status: PayoutStatus;
  createdAt: number;
};

export type Wallet = {
  address: string;
  network: NetworkId;
  token: TokenId;
  connected: boolean;
};

type VaultState = {
  earnings: Earning[];
  payouts: Payout[];
  wallet: Wallet | null;
  earned: number;
  cashed: number;
  available: number;
  addEarning: (input: { amountAud: number; source: string; note: string }) => Earning;
  setWallet: (wallet: Wallet) => void;
  cashOut: (input: { amountAud: number; tokenAmount: number; feeAud: number }) => Payout;
  confirmPayout: (id: string) => void;
};

function totals(earnings: Earning[], payouts: Payout[]) {
  const earned = roundAud(earnings.reduce((sum, row) => sum + row.amountAud, 0));
  const cashed = roundAud(payouts.reduce((sum, row) => sum + row.amountAud, 0));
  return {
    earned,
    cashed,
    available: roundAud(earned - cashed),
  };
}

export const useVault = create<VaultState>()(
  persist(
    (set, get) => ({
      earnings: [],
      payouts: [],
      wallet: null,
      earned: 0,
      cashed: 0,
      available: 0,
      addEarning: ({ amountAud, source, note }) => {
        const row: Earning = {
          id: crypto.randomUUID(),
          amountAud: roundAud(amountAud),
          source: source.trim(),
          note: note.trim(),
          createdAt: Date.now(),
        };
        set((state) => {
          const earnings = [row, ...state.earnings];
          return { earnings, ...totals(earnings, state.payouts) };
        });
        return row;
      },
      setWallet: (wallet) => set({ wallet }),
      cashOut: ({ amountAud, tokenAmount, feeAud }) => {
        const { wallet, earnings, payouts, available } = get();
        if (!wallet) throw new Error("Add a wallet before cashing out.");
        const amount = roundAud(amountAud);
        if (amount <= 0) throw new Error("Enter an amount to send.");
        if (amount > available) throw new Error("That is more than your available balance.");
        const network = NETWORK_BY_ID[wallet.network];
        const payout: Payout = {
          id: crypto.randomUUID(),
          amountAud: amount,
          tokenAmount,
          feeAud,
          token: wallet.token,
          network: wallet.network,
          walletAddress: wallet.address,
          txId: generateTxId(network.addressType),
          status: "pending",
          createdAt: Date.now(),
        };
        set((state) => {
          const nextPayouts = [payout, ...state.payouts];
          return { payouts: nextPayouts, ...totals(earnings, nextPayouts) };
        });
        return payout;
      },
      confirmPayout: (id) =>
        set((state) => ({
          payouts: state.payouts.map((row) =>
            row.id === id ? { ...row, status: "confirmed" } : row,
          ),
        })),
    }),
    {
      name: "vault-earnings",
      skipHydration: true,
      onRehydrateStorage: () => (state) => {
        if (!state) return;
        const next = totals(state.earnings ?? [], state.payouts ?? []);
        state.earned = next.earned;
        state.cashed = next.cashed;
        state.available = next.available;
      },
    },
  ),
);
