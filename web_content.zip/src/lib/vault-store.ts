import { create } from "zustand";
import { persist } from "zustand/middleware";
import { hashPassword, randomSalt } from "@/lib/crypto";
import { BUILTIN_BOOKS, type Book } from "@/lib/library";

export const SESSION_KEY = "taynaya-polka-session";
const STORE_KEY = "taynaya-polka";

export type AppTab = "shelf" | "mine" | "more";
export type ReaderTheme = "paper" | "sepia" | "night";

export type Progress = {
  percent: number;
  updatedAt: number;
};

export type Settings = {
  fontSize: number;
  readerTheme: ReaderTheme;
};

type VaultState = {
  hydrated: boolean;
  salt: string | null;
  hash: string | null;
  unlocked: boolean;
  customBooks: Book[];
  progress: Record<string, Progress>;
  settings: Settings;
  openBookId: string | null;
  adding: boolean;
  settingsOpen: boolean;
  tab: AppTab;
  hydrate: () => void;
  setup: (password: string) => Promise<void>;
  unlock: (password: string) => Promise<boolean>;
  lock: () => void;
  changePassword: (oldPassword: string, nextPassword: string) => Promise<boolean>;
  resetVault: () => void;
  openBook: (id: string) => void;
  closeBook: () => void;
  setProgress: (id: string, percent: number) => void;
  addBook: (input: { title: string; author: string; text: string }) => string;
  removeBook: (id: string) => void;
  setSettings: (patch: Partial<Settings>) => void;
  setAdding: (value: boolean) => void;
  setSettingsOpen: (value: boolean) => void;
  setTab: (tab: AppTab) => void;
};

function markSession(open: boolean) {
  if (typeof sessionStorage === "undefined") return;
  if (open) sessionStorage.setItem(SESSION_KEY, "1");
  else sessionStorage.removeItem(SESSION_KEY);
}

export const useVault = create<VaultState>()(
  persist(
    (set, get) => ({
      hydrated: false,
      salt: null,
      hash: null,
      unlocked: false,
      customBooks: [],
      progress: {},
      settings: { fontSize: 20, readerTheme: "paper" },
      openBookId: null,
      adding: false,
      settingsOpen: false,
      tab: "shelf",

      hydrate: () => {
        const session =
          typeof sessionStorage !== "undefined" && sessionStorage.getItem(SESSION_KEY) === "1";
        const { hash } = get();
        set({ hydrated: true, unlocked: Boolean(hash && session) });
      },

      setup: async (password) => {
        const salt = randomSalt();
        const hash = await hashPassword(password, salt);
        markSession(true);
        set({ salt, hash, unlocked: true });
      },

      unlock: async (password) => {
        const { salt, hash } = get();
        if (!salt || !hash) return false;
        const next = await hashPassword(password, salt);
        const ok = next === hash;
        if (ok) {
          markSession(true);
          set({ unlocked: true });
        }
        return ok;
      },

      lock: () => {
        markSession(false);
        set({ unlocked: false, openBookId: null, adding: false, settingsOpen: false, tab: "shelf" });
      },

      changePassword: async (oldPassword, nextPassword) => {
        const ok = await get().unlock(oldPassword);
        if (!ok) return false;
        const salt = randomSalt();
        const hash = await hashPassword(nextPassword, salt);
        set({ salt, hash });
        return true;
      },

      resetVault: () => {
        markSession(false);
        set({
          salt: null,
          hash: null,
          unlocked: false,
          customBooks: [],
          progress: {},
          settings: { fontSize: 20, readerTheme: "paper" },
          openBookId: null,
          adding: false,
          settingsOpen: false,
          tab: "shelf",
        });
      },

      openBook: (id) => set({ openBookId: id, adding: false, settingsOpen: false }),
      closeBook: () => set({ openBookId: null }),
      setProgress: (id, percent) =>
        set((s) => ({
          progress: {
            ...s.progress,
            [id]: { percent: Math.min(100, Math.max(0, Math.round(percent))), updatedAt: Date.now() },
          },
        })),
      addBook: ({ title, author, text }) => {
        const id = `custom-${crypto.randomUUID()}`;
        const book: Book = {
          id,
          title: title.trim(),
          author: author.trim() || "Без автора",
          years: new Date().getFullYear().toString(),
          kind: "prose",
          blurb: text.trim().slice(0, 140),
          cover: "custom",
          text: text.trim(),
          custom: true,
        };
        set((s) => ({ customBooks: [book, ...s.customBooks], adding: false, openBookId: id }));
        return id;
      },
      removeBook: (id) =>
        set((s) => {
          const progress = { ...s.progress };
          delete progress[id];
          return {
            customBooks: s.customBooks.filter((b) => b.id !== id),
            progress,
            openBookId: s.openBookId === id ? null : s.openBookId,
          };
        }),
      setSettings: (patch) => set((s) => ({ settings: { ...s.settings, ...patch } })),
      setAdding: (adding) => set({ adding, settingsOpen: adding ? false : get().settingsOpen }),
      setSettingsOpen: (settingsOpen) => set({ settingsOpen, adding: settingsOpen ? false : get().adding }),
      setTab: (tab) => set({ tab, adding: false, settingsOpen: false }),
    }),
    {
      name: STORE_KEY,
      skipHydration: true,
      partialize: (s) => ({
        salt: s.salt,
        hash: s.hash,
        customBooks: s.customBooks,
        progress: s.progress,
        settings: s.settings,
      }),
    },
  ),
);

export function selectBooks(state: { customBooks: Book[] }): Book[] {
  return [...state.customBooks, ...BUILTIN_BOOKS];
}

export function findBook(books: Book[], id: string | null): Book | undefined {
  if (!id) return undefined;
  return books.find((b) => b.id === id);
}
