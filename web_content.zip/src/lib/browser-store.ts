import { create } from "zustand";
import { persist } from "zustand/middleware";
import { DEFAULT_HOMEPAGE } from "@/lib/constants";
import { idbAll, idbClear, idbPut } from "@/lib/idb";
import type { BrowserHistoryEntry } from "@/lib/media-types";
import { slugId } from "@/lib/utils";

export type BrowserTab = {
  id: string;
  url: string;
  title: string;
  loading: boolean;
  blocked: boolean;
};

type BrowserState = {
  tabs: BrowserTab[];
  activeId: string;
  history: BrowserHistoryEntry[];
  address: string;
  ready: boolean;
  hydrateHistory: () => Promise<void>;
  setAddress: (address: string) => void;
  navigate: (raw: string, searchPrefix: string, remember: boolean) => void;
  setTabMeta: (id: string, partial: Partial<BrowserTab>) => void;
  newTab: () => void;
  closeTab: (id: string) => void;
  activate: (id: string) => void;
  back: () => void;
  forward: () => void;
  reload: () => void;
  home: (homepage: string) => void;
  clearHistory: () => Promise<void>;
  stacks: Record<string, { list: string[]; index: number }>;
};

function emptyTab(): BrowserTab {
  return { id: slugId(), url: DEFAULT_HOMEPAGE, title: "Home", loading: false, blocked: false };
}

function normalizeUrl(raw: string, searchPrefix: string): string {
  const value = raw.trim();
  if (!value) return DEFAULT_HOMEPAGE;
  if (/^https?:\/\//i.test(value)) return value;
  if (value.includes(" ") || !value.includes(".")) {
    return `${searchPrefix}${encodeURIComponent(value)}`;
  }
  return `https://${value}`;
}

export const useBrowser = create<BrowserState>()(
  persist(
    (set, get) => {
      const first = emptyTab();
      return {
        tabs: [first],
        activeId: first.id,
        history: [],
        address: first.url,
        ready: false,
        stacks: { [first.id]: { list: [first.url], index: 0 } },
        hydrateHistory: async () => {
          try {
            const history = await idbAll<BrowserHistoryEntry>("history");
            history.sort((a, b) => b.visitedAt - a.visitedAt);
            set({ history, ready: true });
          } catch {
            set({ ready: true });
          }
        },
        setAddress: (address) => set({ address }),
        navigate: (raw, searchPrefix, remember) => {
          const url = normalizeUrl(raw, searchPrefix);
          const { activeId, tabs, stacks } = get();
          const stack = stacks[activeId] ?? { list: [url], index: 0 };
          const list = [...stack.list.slice(0, stack.index + 1), url];
          const index = list.length - 1;
          const nextTabs = tabs.map((t) =>
            t.id === activeId ? { ...t, url, loading: true, blocked: false, title: url } : t,
          );
          set({
            tabs: nextTabs,
            address: url,
            stacks: { ...stacks, [activeId]: { list, index } },
          });
          if (remember) {
            const entry: BrowserHistoryEntry = {
              id: slugId(),
              url,
              title: url,
              visitedAt: Date.now(),
            };
            void idbPut("history", entry);
            set({ history: [entry, ...get().history].slice(0, 200) });
          }
        },
        setTabMeta: (id, partial) => {
          set({
            tabs: get().tabs.map((t) => (t.id === id ? { ...t, ...partial } : t)),
          });
        },
        newTab: () => {
          const tab = emptyTab();
          set({
            tabs: [...get().tabs, tab],
            activeId: tab.id,
            address: tab.url,
            stacks: { ...get().stacks, [tab.id]: { list: [tab.url], index: 0 } },
          });
        },
        closeTab: (id) => {
          const tabs = get().tabs.filter((t) => t.id !== id);
          if (tabs.length === 0) {
            const tab = emptyTab();
            set({
              tabs: [tab],
              activeId: tab.id,
              address: tab.url,
              stacks: { [tab.id]: { list: [tab.url], index: 0 } },
            });
            return;
          }
          const activeId = get().activeId === id ? tabs[tabs.length - 1]!.id : get().activeId;
          const active = tabs.find((t) => t.id === activeId)!;
          set({ tabs, activeId, address: active.url });
        },
        activate: (id) => {
          const tab = get().tabs.find((t) => t.id === id);
          if (!tab) return;
          set({ activeId: id, address: tab.url });
        },
        back: () => {
          const { activeId, stacks, tabs } = get();
          const stack = stacks[activeId];
          if (!stack || stack.index <= 0) return;
          const index = stack.index - 1;
          const url = stack.list[index]!;
          set({
            stacks: { ...stacks, [activeId]: { ...stack, index } },
            address: url,
            tabs: tabs.map((t) => (t.id === activeId ? { ...t, url } : t)),
          });
        },
        forward: () => {
          const { activeId, stacks, tabs } = get();
          const stack = stacks[activeId];
          if (!stack || stack.index >= stack.list.length - 1) return;
          const index = stack.index + 1;
          const url = stack.list[index]!;
          set({
            stacks: { ...stacks, [activeId]: { ...stack, index } },
            address: url,
            tabs: tabs.map((t) => (t.id === activeId ? { ...t, url } : t)),
          });
        },
        reload: () => {
          const { activeId, tabs } = get();
          set({
            tabs: tabs.map((t) => (t.id === activeId ? { ...t, loading: true, url: t.url } : t)),
          });
        },
        home: (homepage) => {
          get().navigate(homepage, homepage, false);
        },
        clearHistory: async () => {
          await idbClear("history");
          set({ history: [] });
        },
      };
    },
    {
      name: "uplay-ind-browser-tabs",
      partialize: (s) => ({
        tabs: s.tabs.map((t) => ({ ...t, loading: false })),
        activeId: s.activeId,
        address: s.address,
        stacks: s.stacks,
      }),
    },
  ),
);
