/**
 * Shared, dependency-free date / money helpers used by both the server and the
 * client. All "day" values are plain `YYYY-MM-DD` strings in local time and all
 * "month" values are `YYYY-MM` strings so nothing drifts across timezones.
 */

export const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export const SPEND_CATEGORIES = [
  "Food",
  "Transport",
  "Shopping",
  "Bills",
  "Health",
  "Fun",
  "Home",
  "Education",
  "Tech",
  "Other",
] as const;

export const EARN_CATEGORIES = [
  "Salary",
  "Freelance",
  "Business",
  "Investment",
  "Gift",
  "Refund",
  "Other",
] as const;

export const BILL_CATEGORIES = [
  "Electricity",
  "Water",
  "Fuel",
  "Internet",
  "Rent",
  "Phone",
  "Insurance",
  "Subscription",
  "Loan",
  "Custom",
] as const;

export const CURRENCIES: { code: string; symbol: string; label: string; decimals: number }[] = [
  { code: "USD", symbol: "$", label: "US Dollar", decimals: 2 },
  { code: "EUR", symbol: "€", label: "Euro", decimals: 2 },
  { code: "GBP", symbol: "£", label: "British Pound", decimals: 2 },
  { code: "INR", symbol: "₹", label: "Indian Rupee", decimals: 2 },
  { code: "LKR", symbol: "Rs", label: "Sri Lankan Rupee", decimals: 2 },
  { code: "AUD", symbol: "A$", label: "Australian Dollar", decimals: 2 },
  { code: "CAD", symbol: "C$", label: "Canadian Dollar", decimals: 2 },
  { code: "JPY", symbol: "¥", label: "Japanese Yen", decimals: 0 },
  { code: "AED", symbol: "د.إ", label: "UAE Dirham", decimals: 2 },
  { code: "NGN", symbol: "₦", label: "Nigerian Naira", decimals: 2 },
  { code: "ZAR", symbol: "R", label: "South African Rand", decimals: 2 },
  { code: "BRL", symbol: "R$", label: "Brazilian Real", decimals: 2 },
  { code: "PKR", symbol: "₨", label: "Pakistani Rupee", decimals: 2 },
];

export function currencyMeta(code?: string | null) {
  return CURRENCIES.find((c) => c.code === code) ?? CURRENCIES[0]!;
}

export function formatMoney(
  value: number,
  code?: string | null,
  opts?: { decimals?: boolean; sign?: boolean },
) {
  const meta = currencyMeta(code);
  const decimals = opts?.decimals === false ? 0 : meta.decimals;
  const abs = Math.abs(Number.isFinite(value) ? value : 0);
  const body = abs.toLocaleString("en-US", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
  const sign = value < 0 ? "−" : opts?.sign ? "+" : "";
  return `${sign}${meta.symbol}${body}`;
}

export function formatCompact(value: number, code?: string | null) {
  const meta = currencyMeta(code);
  const abs = Math.abs(value);
  if (abs >= 1_000_000) return `${value < 0 ? "−" : ""}${meta.symbol}${(abs / 1_000_000).toFixed(1)}M`;
  if (abs >= 1_000) return `${value < 0 ? "−" : ""}${meta.symbol}${(abs / 1_000).toFixed(1)}k`;
  return formatMoney(value, code, { decimals: abs % 1 !== 0 });
}

export function pad(n: number) {
  return n < 10 ? `0${n}` : String(n);
}

export function toDayKey(d: Date) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function todayKey() {
  return toDayKey(new Date());
}

export function monthKeyOf(day: string) {
  return day.slice(0, 7);
}

export function currentMonthKey() {
  return todayKey().slice(0, 7);
}

export function parseDay(day: string) {
  const [y, m, d] = day.split("-").map(Number);
  return new Date(y ?? 1970, (m ?? 1) - 1, d ?? 1);
}

export function parseMonth(month: string) {
  const [y, m] = month.split("-").map(Number);
  return new Date(y ?? 1970, (m ?? 1) - 1, 1);
}

export function shiftMonth(month: string, delta: number) {
  const d = parseMonth(month);
  d.setMonth(d.getMonth() + delta);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
}

export function shiftDay(day: string, delta: number) {
  const d = parseDay(day);
  d.setDate(d.getDate() + delta);
  return toDayKey(d);
}

export function daysInMonth(month: string) {
  const d = parseMonth(month);
  return new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
}

export function monthLabel(month: string, style: "long" | "short" = "long") {
  const d = parseMonth(month);
  return d.toLocaleDateString("en-US", {
    month: style === "long" ? "long" : "short",
    year: "numeric",
  });
}

export function monthShort(month: string) {
  return parseMonth(month).toLocaleDateString("en-US", { month: "short" });
}

export function dayLabel(day: string) {
  const d = parseDay(day);
  return d.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
}

export function relativeDay(day: string) {
  const today = todayKey();
  if (day === today) return "Today";
  if (day === shiftDay(today, -1)) return "Yesterday";
  if (day === shiftDay(today, 1)) return "Tomorrow";
  const d = parseDay(day);
  const sameYear = d.getFullYear() === new Date().getFullYear();
  return d.toLocaleDateString("en-US", {
    weekday: sameYear ? undefined : "short",
    month: "short",
    day: "numeric",
    year: sameYear ? undefined : "numeric",
  });
}

export function monthRange(month: string) {
  const count = daysInMonth(month);
  return Array.from({ length: count }, (_, i) => `${month}-${pad(i + 1)}`);
}

/** Calendar grid (6 weeks max) for a month, honouring the week start setting. */
export function monthGrid(month: string, weekStart = 0) {
  const first = parseMonth(month);
  const offset = (first.getDay() - weekStart + 7) % 7;
  const start = new Date(first);
  start.setDate(first.getDate() - offset);
  const total = Math.max(35, Math.ceil((offset + daysInMonth(month)) / 7) * 7);
  return Array.from({ length: total }, (_, i) => {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    const day = toDayKey(d);
    return {
      day,
      dateNum: d.getDate(),
      weekday: d.getDay(),
      inMonth: monthKeyOf(day) === month,
      isToday: day === todayKey(),
    };
  });
}

export function orderedWeekdays(weekStart = 0) {
  return Array.from({ length: 7 }, (_, i) => WEEKDAYS[(i + weekStart) % 7]!);
}

/** Google Calendar "create event" deep link. */
export function googleCalendarUrl(opts: {
  title: string;
  day: string;
  details?: string;
  location?: string;
}) {
  const next = shiftDay(opts.day, 1).replace(/-/g, "");
  const start = opts.day.replace(/-/g, "");
  const params = new URLSearchParams({
    action: "TEMPLATE",
    text: opts.title,
    dates: `${start}/${next}`,
    details: opts.details ?? "",
    location: opts.location ?? "",
  });
  return `https://calendar.google.com/calendar/render?${params.toString()}`;
}

export function buildIcs(events: { title: string; day: string; description?: string }[]) {
  const lines = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Keep Tracked//Finance//EN",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
  ];
  for (const e of events) {
    const next = shiftDay(e.day, 1).replace(/-/g, "");
    lines.push(
      "BEGIN:VEVENT",
      `UID:${e.day}-${Math.random().toString(36).slice(2)}@keeptracked.app`,
      `DTSTAMP:${new Date().toISOString().replace(/[-:]/g, "").split(".")[0]}Z`,
      `DTSTART;VALUE=DATE:${e.day.replace(/-/g, "")}`,
      `DTEND;VALUE=DATE:${next}`,
      `SUMMARY:${e.title.replace(/([,;])/g, " ")}`,
      `DESCRIPTION:${(e.description ?? "").replace(/([,;])/g, " ")}`,
      "END:VEVENT",
    );
  }
  lines.push("END:VCALENDAR");
  return lines.join("\r\n");
}

export function downloadText(filename: string, text: string, mime = "text/plain") {
  if (typeof document === "undefined") return;
  const blob = new Blob([text], { type: `${mime};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
