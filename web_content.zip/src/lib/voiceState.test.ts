import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildPreferredMicConstraints,
  clampVadSensitivity,
  computeAudioRms,
  evaluateVadFrame,
  getVadSensitivityLabel,
  getVoiceStatusLabel,
  isDuplicateSubmission,
  isListeningActive,
  mapSpeechRecognitionLang,
  mapTtsLang,
  normalizeConversationHistory,
  shouldAcceptSpeechTranscript,
  shouldSpeakReply,
  stripMarkdownForSpeech,
  vadSensitivityToRmsThreshold,
  vadThresholdToDb,
} from './voiceState';

test('isListeningActive and status labels stay honest when voice listening is off', () => {
  assert.equal(isListeningActive('off'), false);
  assert.equal(isListeningActive('permission_prompt'), false);
  assert.equal(isListeningActive('error'), false);

  assert.equal(isListeningActive('listening'), true);
  assert.equal(isListeningActive('processing'), true);
  assert.equal(isListeningActive('speaking'), true);

  assert.equal(getVoiceStatusLabel('off').toLowerCase().includes('listening'), false);
  assert.equal(getVoiceStatusLabel('error').toLowerCase().includes('listening'), false);
  assert.equal(getVoiceStatusLabel('permission_prompt').toLowerCase().includes('listening'), false);
  assert.match(getVoiceStatusLabel('listening'), /listening/i);
});

test('buildPreferredMicConstraints uses built-in default audio without external deviceId', () => {
  const constraints = buildPreferredMicConstraints();
  assert.equal(constraints.video, false);
  assert.equal(typeof constraints.audio, 'object');
  const audio = constraints.audio as MediaTrackConstraints;
  assert.equal(audio.echoCancellation, true);
  assert.equal(audio.noiseSuppression, true);
  assert.equal(audio.autoGainControl, true);
  assert.equal(audio.deviceId, undefined);
});

test('speech recognition and TTS locale mapping supports Hindi, Hinglish, and English', () => {
  assert.equal(mapSpeechRecognitionLang('hindi'), 'hi-IN');
  assert.equal(mapSpeechRecognitionLang('hinglish'), 'en-IN');
  assert.equal(mapSpeechRecognitionLang('auto'), 'en-IN');
  assert.equal(mapSpeechRecognitionLang('english'), 'en-US');

  assert.equal(mapTtsLang('hindi'), 'hi-IN');
  assert.equal(mapTtsLang('hinglish'), 'en-IN');
});

test('stripMarkdownForSpeech removes markdown syntax and summarizes code blocks cleanly', () => {
  const input = '## Steps\n- Run `npm test`\n**Done!**\n```ts\nconst x = 1;\n```';
  const spoken = stripMarkdownForSpeech(input);
  assert.equal(spoken.includes('`'), false);
  assert.equal(spoken.includes('**'), false);
  assert.equal(spoken.includes('##'), false);
  assert.match(spoken, /Run npm test/);
  assert.match(spoken, /shown the code on your screen/i);
});

test('VAD sensitivity maps monotonically to RMS thresholds and filters noisy frames', () => {
  assert.equal(clampVadSensitivity(0), 10);
  assert.equal(clampVadSensitivity(120), 95);
  assert.equal(clampVadSensitivity(Number.NaN), 55);

  const noisyRoomThreshold = vadSensitivityToRmsThreshold(20);
  const balancedThreshold = vadSensitivityToRmsThreshold(55);
  const quietRoomThreshold = vadSensitivityToRmsThreshold(90);

  // Lower sensitivity => higher RMS threshold to filter ambient background noise
  assert.ok(noisyRoomThreshold > balancedThreshold);
  assert.ok(balancedThreshold > quietRoomThreshold);
  assert.ok(vadThresholdToDb(noisyRoomThreshold) > vadThresholdToDb(quietRoomThreshold));

  assert.equal(getVadSensitivityLabel(25), 'Noisy room');
  assert.equal(getVadSensitivityLabel(55), 'Balanced');
  assert.equal(getVadSensitivityLabel(85), 'Quiet room');

  // Ambient fan noise (~0.025 RMS) triggers in quiet-room mode (85), ignored in noisy-room mode (20)
  const ambientRms = computeAudioRms([0.025, -0.025, 0.025, -0.025]);
  assert.equal(evaluateVadFrame(ambientRms, 20, false).voiceDetected, false);
  assert.equal(evaluateVadFrame(ambientRms, 85, false).voiceDetected, true);

  // Hysteresis keeps already-active speech sustained just below the start threshold
  const startThreshold = vadSensitivityToRmsThreshold(55);
  assert.equal(evaluateVadFrame(startThreshold * 0.8, 55, false).voiceDetected, false);
  assert.equal(evaluateVadFrame(startThreshold * 0.8, 55, true).voiceDetected, true);
});

test('shouldAcceptSpeechTranscript suppresses low-confidence noise in noisy-room mode', () => {
  assert.equal(
    shouldAcceptSpeechTranscript({ transcript: 'uh', confidence: 0.4, vadSensitivity: 25 }),
    false,
  );
  assert.equal(
    shouldAcceptSpeechTranscript({ transcript: 'Hey Jarvis', confidence: 0.88, vadSensitivity: 25 }),
    true,
  );
  // When browser leaves confidence unset (0/undefined), valid transcripts still pass
  assert.equal(
    shouldAcceptSpeechTranscript({ transcript: 'Explain REST API', confidence: 0, vadSensitivity: 25 }),
    true,
  );
  assert.equal(
    shouldAcceptSpeechTranscript({ transcript: '   ', confidence: 0.99, vadSensitivity: 85 }),
    false,
  );
  assert.equal(
    shouldAcceptSpeechTranscript({ transcript: '...', confidence: 0.99, vadSensitivity: 85 }),
    false,
  );
});

test('shouldSpeakReply respects mute state and ignores empty text', () => {
  assert.equal(shouldSpeakReply(false, 'Water boils at 100 degrees Celsius.'), true);
  assert.equal(shouldSpeakReply(true, 'Water boils at 100 degrees Celsius.'), false);
  assert.equal(shouldSpeakReply(false, '   '), false);
});

test('isDuplicateSubmission blocks hardware bounce while allowing intentional repeated questions', () => {
  const prev = { text: 'Explain   REST API', at: 1000 };
  assert.equal(isDuplicateSubmission(prev, 'explain rest api', 1200), true);
  assert.equal(isDuplicateSubmission(prev, 'explain rest api', 1500), false);
  assert.equal(isDuplicateSubmission(prev, 'Different question', 1100), false);
  assert.equal(isDuplicateSubmission(null, 'Hello', 1200), false);
});

test('normalizeConversationHistory merges consecutive roles, drops empty turns, and trims leading model turns', () => {
  const normalized = normalizeConversationHistory([
    { role: 'assistant', content: 'Orphaned greeting' },
    { role: 'user', content: 'First question' },
    { role: 'assistant', content: '   ' },
    { role: 'user', content: 'Follow-up after cancelled turn' },
    { role: 'assistant', content: 'Combined reply' },
  ]);
  assert.deepEqual(normalized, [
    { role: 'user', text: 'First question\nFollow-up after cancelled turn' },
    { role: 'model', text: 'Combined reply' },
  ]);
});
