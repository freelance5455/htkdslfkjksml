export type ScanOutcome = "ok" | "duplicate" | "not-enrolled" | "unknown";
