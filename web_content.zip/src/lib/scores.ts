import type { ScoreEntry } from "@/game/types";

const SCORES_KEY = "sarab.scores.v1";
const NAME_KEY = "sarab.name.v1";
const MUTE_KEY = "sarab.muted.v1";
const MAX_ENTRIES = 8;

function isEntry(value: unknown): value is ScoreEntry {
  if (!value || typeof value !== "object") return false;
  const e = value as Record<string, unknown>;
  return (
    typeof e.id === "string" &&
    typeof e.name === "string" &&
    typeof e.score === "number" &&
    typeof e.date === "string"
  );
}

export function loadScores(): ScoreEntry[] {
  try {
    const raw = localStorage.getItem(SCORES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter(isEntry)
      .map((e) => ({
        ...e,
        kills: Number(e.kills) || 0,
        shards: Number(e.shards) || 0,
        cycles: Number(e.cycles) || 1,
        time: Number(e.time) || 0,
      }))
      .sort((a, b) => b.score - a.score)
      .slice(0, MAX_ENTRIES);
  } catch {
    return [];
  }
}

export function persistScores(entries: ScoreEntry[]) {
  try {
    localStorage.setItem(SCORES_KEY, JSON.stringify(entries.slice(0, MAX_ENTRIES)));
  } catch {
    /* storage may be unavailable */
  }
}

export function addScore(
  entries: ScoreEntry[],
  entry: ScoreEntry,
): { entries: ScoreEntry[]; rank: number | null } {
  const next = [...entries, entry].sort((a, b) => b.score - a.score).slice(0, MAX_ENTRIES);
  awaitPersist(next);
  const index = next.findIndex((e) => e.id === entry.id);
  return { entries: next, rank: index >= 0 ? index + 1 : null };
}

export function renameScore(entries: ScoreEntry[], id: string, name: string): ScoreEntry[] {
  const next = entries.map((e) => (e.id === id ? { ...e, name: name || "مسافر" } : e));
  awaitPersist(next);
  return next;
}

function awaitPersist(entries: ScoreEntry[]) {
  persistScores(entries);
}

export function removeScore(entries: ScoreEntry[], id: string): ScoreEntry[] {
  const next = entries.filter((e) => e.id !== id);
  awaitPersist(next);
  return next;
}

export function loadName(): string {
  try {
    return localStorage.getItem(NAME_KEY) || "مسافر";
  } catch {
    return "مسافر";
  }
}

export function persistName(name: string) {
  try {
    localStorage.setItem(NAME_KEY, name);
  } catch {
    /* noop */
  }
}

export function loadMuted(): boolean {
  try {
    return localStorage.getItem(MUTE_KEY) === "1";
  } catch {
    return false;
  }
}

export function persistMuted(muted: boolean) {
  try {
    localStorage.setItem(MUTE_KEY, muted ? "1" : "0");
  } catch {
    /* noop */
  }
}

export function formatScore(score: number): string {
  return new Intl.NumberFormat("en-US").format(Math.max(0, Math.round(score)));
}

export function formatTime(seconds: number): string {
  const s = Math.max(0, Math.floor(seconds));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}:${String(r).padStart(2, "0")}`;
}

export function newId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}
