export type SaveMode = "download" | "gallery";

export type SaveProgress = {
  loaded: number;
  total: number;
  ratio: number;
};

function proxyUrl(sourceUrl: string, filename: string): string {
  const params = new URLSearchParams({ src: sourceUrl, name: filename });
  return `/api/file?${params.toString()}`;
}

async function fetchSource(
  sourceUrl: string,
  filename: string,
  signal?: AbortSignal,
): Promise<Response> {
  try {
    const direct = await fetch(sourceUrl, {
      signal,
      headers: { Accept: "*/*" },
    });
    if (direct.ok) return direct;
  } catch (error) {
    if (signal?.aborted) throw error;
  }
  return fetch(proxyUrl(sourceUrl, filename), {
    signal,
    headers: { Accept: "*/*" },
  });
}

function guessTotal(response: Response): number {
  const length = Number(
    response.headers.get("content-length") ||
      response.headers.get("estimated-content-length") ||
      0,
  );
  return Number.isFinite(length) && length > 0 ? length : 0;
}

async function blobFromResponse(
  response: Response,
  onProgress?: (progress: SaveProgress) => void,
  signal?: AbortSignal,
): Promise<Blob> {
  const total = guessTotal(response);
  if (!response.body) {
    const blob = await response.blob();
    onProgress?.({ loaded: blob.size, total: blob.size, ratio: 1 });
    return blob;
  }

  const reader = response.body.getReader();
  const chunks: BlobPart[] = [];
  let loaded = 0;

  const abort = () => {
    void reader.cancel();
  };
  signal?.addEventListener("abort", abort, { once: true });

  try {
    while (true) {
      if (signal?.aborted) throw new DOMException("Aborted", "AbortError");
      const { done, value } = await reader.read();
      if (done) break;
      if (value) {
        const copy = new Uint8Array(value.byteLength);
        copy.set(value);
        chunks.push(copy);
        loaded += value.byteLength;
        onProgress?.({
          loaded,
          total,
          ratio: total ? Math.min(0.99, loaded / total) : 0,
        });
      }
    }
  } finally {
    signal?.removeEventListener("abort", abort);
  }

  const blob = new Blob(chunks, {
    type: response.headers.get("content-type") || undefined,
  });
  onProgress?.({ loaded: blob.size, total: total || blob.size, ratio: 1 });
  return blob;
}

function triggerAnchorDownload(href: string, filename: string) {
  const anchor = document.createElement("a");
  anchor.href = href;
  anchor.download = filename;
  anchor.rel = "noopener";
  anchor.style.display = "none";
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
}

async function shareOrDownload(
  blob: Blob,
  filename: string,
  mime: string,
  mode: SaveMode,
): Promise<"shared" | "downloaded"> {
  const type = blob.type && blob.type !== "application/octet-stream" ? blob.type : mime;
  const file = new File([blob], filename, { type });

  if (mode === "gallery") {
    const payload = { files: [file], title: filename };
    if (typeof navigator.canShare === "function" && navigator.canShare(payload)) {
      await navigator.share(payload);
      return "shared";
    }
  }

  const objectUrl = URL.createObjectURL(blob);
  try {
    triggerAnchorDownload(objectUrl, filename);
  } finally {
    window.setTimeout(() => URL.revokeObjectURL(objectUrl), 30_000);
  }
  return "downloaded";
}

export async function saveMediaFile(options: {
  sourceUrl: string;
  filename: string;
  mime: string;
  mode: SaveMode;
  onProgress?: (progress: SaveProgress) => void;
  signal?: AbortSignal;
}): Promise<"shared" | "downloaded"> {
  const { sourceUrl, filename, mime, mode, onProgress, signal } = options;
  try {
    const response = await fetchSource(sourceUrl, filename, signal);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    const blob = await blobFromResponse(response, onProgress, signal);
    return await shareOrDownload(blob, filename, mime, mode);
  } catch (error) {
    if (signal?.aborted) throw error;
    if (mode === "download") {
      triggerAnchorDownload(sourceUrl, filename);
      onProgress?.({ loaded: 1, total: 1, ratio: 1 });
      return "downloaded";
    }
    throw error;
  }
}
