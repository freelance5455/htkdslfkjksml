import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type { PrepareResult, PreviewResult } from "./cobalt.server";

const qualitySchema = z.enum(["1080p", "720p", "480p"]);

const previewSchema = z.object({
  url: z.string().min(4).max(2000),
});

const prepareSchema = z.object({
  url: z.string().min(4).max(2000),
  quality: qualitySchema,
  audioOnly: z.boolean(),
});

export const previewMediaFn = createServerFn({ method: "POST" })
  .validator(previewSchema)
  .handler(async ({ data }): Promise<PreviewResult> => {
    const { previewMedia } = await import("./cobalt.server");
    return previewMedia(data.url);
  });

export const prepareMediaFn = createServerFn({ method: "POST" })
  .validator(prepareSchema)
  .handler(async ({ data }): Promise<PrepareResult> => {
    const { prepareMedia } = await import("./cobalt.server");
    return prepareMedia(data);
  });
