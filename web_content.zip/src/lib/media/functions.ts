import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { resolveMediaUrl } from "./resolve.server";

const Input = z.object({
  url: z.string().trim().min(6).max(2000),
  mode: z.enum(["video", "audio"]),
  quality: z.enum(["1080", "720", "480"]),
});

export const resolveMedia = createServerFn({ method: "POST" })
  .validator(Input)
  .handler(async ({ data }) => {
    return resolveMediaUrl(data);
  });
