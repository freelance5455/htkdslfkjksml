const COBALT_MESSAGES: Record<string, string> = {
  "error.api.fetch.empty":
    "Não foi possível ler este link. Confira se o post é público e tente de novo.",
  "error.api.fetch.fail":
    "A plataforma recusou o acesso. Tente outro link ou tente de novo em instantes.",
  "error.api.fetch.critical":
    "Falha ao buscar o vídeo. Tente novamente daqui a pouco.",
  "error.api.youtube.login":
    "O YouTube bloqueou esta tentativa. Espere um instante e tente de novo.",
  "error.api.youtube.disabled_main_instance":
    "YouTube está indisponível neste momento. Tente de novo em instantes.",
  "error.api.rate_exceeded":
    "Muita gente baixando agora. Espere alguns segundos e tente de novo.",
  "error.api.service.unsupported": "Este tipo de link ainda não é suportado.",
  "error.api.service.disabled": "Este serviço está temporariamente desligado.",
  "error.api.link.invalid": "Este link não parece válido.",
  "error.api.link.unsupported":
    "Cole um link do YouTube, TikTok ou Instagram.",
  "error.api.content.video.unavailable":
    "Este vídeo não está disponível para download.",
  "error.api.content.post.unavailable":
    "Este post não está disponível. Pode ser privado ou ter sido apagado.",
  "error.api.content.too_long":
    "Este vídeo é longo demais para processar agora.",
  "error.api.auth.jwt.missing": "Instância ocupada. Tentando outra rota…",
  "error.api.auth.key.invalid": "Instância ocupada. Tentando outra rota…",
};

export function messageForCobaltCode(code: string | undefined): string {
  if (!code) return "Não foi possível preparar o download. Tente de novo.";
  return (
    COBALT_MESSAGES[code] ??
    "Não foi possível preparar o download. Tente outro link ou tente de novo."
  );
}

export function messageForUnknownLink(): string {
  return "Cole um link do YouTube, TikTok ou Instagram.";
}
