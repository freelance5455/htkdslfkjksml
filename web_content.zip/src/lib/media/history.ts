import type { Platform, Quality } from "./detect";

const KEY = "puro-history-v1";
const MAX = 12;

export type HistoryItem = {
  id: string;
  url: string;
  title: string;
  platform: Platform;
  thumbnail?: string;
  filename: string;
  audioOnly: boolean;
  quality: Quality;
  at: number;
};

function canUseStorage(): boolean {
  return typeof window !== "undefined" && typeof localStorage !== "undefined";
}

export function loadHistory(): HistoryItem[] {
  if (!canUseStorage()) return [];
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as HistoryItem[];
    if (!Array.isArray(parsed)) return [];
    return parsed.slice(0, MAX);
  } catch {
    return [];
  }
}

export function saveHistory(items: HistoryItem[]): void {
  if (!canUseStorage()) return;
  try {
    localStorage.setItem(KEY, JSON.stringify(items.slice(0, MAX)));
  } catch {
    // quota / private mode
  }
}

export function pushHistory(
  items: HistoryItem[],
  next: Omit<HistoryItem, "id" | "at">,
): HistoryItem[] {
  const item: HistoryItem = {
    ...next,
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    at: Date.now(),
  };
  const deduped = items.filter(
    (entry) => !(entry.url === item.url && entry.audioOnly === item.audioOnly),
  );
  const updated = [item, ...deduped].slice(0, MAX);
  saveHistory(updated);
  return updated;
}

export function clearHistory(): HistoryItem[] {
  saveHistory([]);
  return [];
}
