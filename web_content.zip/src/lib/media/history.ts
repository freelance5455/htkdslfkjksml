import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Platform } from "./types";

export type HistoryEntry = {
  id: string;
  url: string;
  title: string;
  platform: Platform;
  thumbnail: string | null;
  savedAt: number;
};

type HistoryState = {
  items: HistoryEntry[];
  remember: (entry: Omit<HistoryEntry, "id" | "savedAt">) => void;
  remove: (id: string) => void;
  clear: () => void;
};

export const useHistory = create<HistoryState>()(
  persist(
    (set, get) => ({
      items: [],
      remember: (entry) => {
        const next: HistoryEntry = {
          ...entry,
          id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          savedAt: Date.now(),
        };
        const rest = get().items.filter((item) => item.url !== entry.url);
        set({ items: [next, ...rest].slice(0, 30) });
      },
      remove: (id) => set({ items: get().items.filter((item) => item.id !== id) }),
      clear: () => set({ items: [] }),
    }),
    { name: "puro-history" },
  ),
);
