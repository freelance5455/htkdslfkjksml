import {
  detectPlatform,
  extractYoutubeId,
  mimeFromFilename,
  normalizeUrl,
  qualityToCobalt,
  youtubeThumbnail,
  type Platform,
  type Quality,
} from "./detect";
import { messageForCobaltCode, messageForUnknownLink } from "./errors";

const INSTANCE_CANDIDATES = [
  "https://rue-cobalt.xenon.zone",
  "https://cobaltapi.cjs.nz",
];

const USER_AGENT =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36";

type CobaltProcessBody = {
  url: string;
  downloadMode: "auto" | "audio";
  videoQuality?: string;
  audioFormat?: "mp3";
  audioBitrate?: "128" | "192" | "320";
  filenameStyle: "pretty";
  youtubeVideoCodec?: "h264";
  youtubeVideoContainer?: "mp4";
  alwaysProxy?: boolean;
  disableMetadata?: boolean;
};

type CobaltOk = {
  status: "tunnel" | "redirect";
  url: string;
  filename?: string;
};

type CobaltPicker = {
  status: "picker";
  picker?: Array<{ type?: string; url?: string; filename?: string }>;
  audio?: string;
};

type CobaltErr = {
  status: "error";
  error?: { code?: string; context?: { service?: string } };
};

type CobaltResponse = CobaltOk | CobaltPicker | CobaltErr | { status: string };

export type PrepareResult =
  | {
      ok: true;
      platform: Platform;
      title: string;
      author?: string;
      thumbnail?: string;
      filename: string;
      downloadUrl: string;
      mime: string;
      audioOnly: boolean;
      quality: Quality;
    }
  | { ok: false; message: string; code?: string };

export type PreviewResult =
  | {
      ok: true;
      platform: Platform;
      title: string;
      author?: string;
      thumbnail?: string;
    }
  | { ok: false; message: string };

const AUTH_CODES = new Set([
  "error.api.auth.jwt.missing",
  "error.api.auth.jwt.invalid",
  "error.api.auth.key.invalid",
  "error.api.auth.turnstile.missing",
  "error.api.auth.turnstile.invalid",
]);

function stripSlash(url: string): string {
  return url.replace(/\/+$/, "");
}

async function readJson(response: Response): Promise<unknown> {
  const text = await response.text();
  if (!text) return null;
  try {
    return JSON.parse(text) as unknown;
  } catch {
    return null;
  }
}

async function cobaltPost(
  instance: string,
  body: CobaltProcessBody,
  timeoutMs: number,
): Promise<CobaltResponse> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(`${stripSlash(instance)}/`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        "User-Agent": USER_AGENT,
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    const json = (await readJson(response)) as CobaltResponse | null;
    if (!json || typeof json !== "object") {
      return { status: "error", error: { code: "error.api.fetch.fail" } };
    }
    return json;
  } finally {
    clearTimeout(timer);
  }
}

function isAllowedTunnel(url: string): boolean {
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== "https:") return false;
    const allowed = INSTANCE_CANDIDATES.some((instance) => {
      const host = new URL(instance).hostname;
      return parsed.hostname === host;
    });
    if (!allowed) return false;
    return parsed.pathname === "/tunnel" || parsed.pathname.startsWith("/tunnel");
  } catch {
    return false;
  }
}

function isAllowedRedirect(url: string): boolean {
  try {
    const parsed = new URL(url);
    return parsed.protocol === "https:";
  } catch {
    return false;
  }
}

function defaultFilename(
  platform: Platform,
  audioOnly: boolean,
  quality: Quality,
): string {
  const ext = audioOnly ? "mp3" : "mp4";
  const tag = audioOnly ? "audio" : quality;
  return `puro-${platform}-${tag}.${ext}`;
}

async function fetchOembed(url: string): Promise<{
  title?: string;
  author?: string;
  thumbnail?: string;
}> {
  const platform = detectPlatform(url);
  let endpoint: string | null = null;
  if (platform === "youtube") {
    endpoint = `https://www.youtube.com/oembed?url=${encodeURIComponent(url)}&format=json`;
  } else if (platform === "tiktok") {
    endpoint = `https://www.tiktok.com/oembed?url=${encodeURIComponent(url)}`;
  }
  if (!endpoint) return {};
  try {
    const response = await fetch(endpoint, {
      headers: { "User-Agent": USER_AGENT, Accept: "application/json" },
      signal: AbortSignal.timeout(6000),
    });
    if (!response.ok) return {};
    const json = (await response.json()) as {
      title?: string;
      author_name?: string;
      thumbnail_url?: string;
    };
    return {
      title: json.title,
      author: json.author_name,
      thumbnail: json.thumbnail_url,
    };
  } catch {
    return {};
  }
}

function fallbackPreview(url: string, platform: Platform) {
  if (platform === "youtube") {
    const id = extractYoutubeId(url);
    return {
      title: "Vídeo do YouTube",
      thumbnail: id ? youtubeThumbnail(id) : undefined,
    };
  }
  if (platform === "tiktok") {
    return { title: "Vídeo do TikTok" };
  }
  return { title: "Vídeo do Instagram" };
}

export async function previewMedia(rawUrl: string): Promise<PreviewResult> {
  const url = normalizeUrl(rawUrl);
  const platform = detectPlatform(url);
  if (!platform) {
    return { ok: false, message: messageForUnknownLink() };
  }
  const meta = await fetchOembed(url);
  const fallback = fallbackPreview(url, platform);
  return {
    ok: true,
    platform,
    title: meta.title || fallback.title,
    author: meta.author,
    thumbnail: meta.thumbnail || fallback.thumbnail,
  };
}

export async function prepareMedia(input: {
  url: string;
  quality: Quality;
  audioOnly: boolean;
}): Promise<PrepareResult> {
  const url = normalizeUrl(input.url);
  const platform = detectPlatform(url);
  if (!platform) {
    return { ok: false, message: messageForUnknownLink() };
  }

  const body: CobaltProcessBody = input.audioOnly
    ? {
        url,
        downloadMode: "audio",
        audioFormat: "mp3",
        audioBitrate: "128",
        filenameStyle: "pretty",
        alwaysProxy: true,
      }
    : {
        url,
        downloadMode: "auto",
        videoQuality: qualityToCobalt(input.quality),
        filenameStyle: "pretty",
        youtubeVideoCodec: "h264",
        youtubeVideoContainer: "mp4",
        alwaysProxy: true,
      };

  let lastCode: string | undefined;
  let lastMessage: string | undefined;

  for (const instance of INSTANCE_CANDIDATES) {
    let result: CobaltResponse;
    try {
      result = await cobaltPost(instance, body, 18000);
    } catch {
      lastMessage = "Falha de conexão. Tentando outra rota…";
      continue;
    }

    if (result.status === "error") {
      const code = (result as CobaltErr).error?.code;
      lastCode = code;
      lastMessage = messageForCobaltCode(code);
      if (code && AUTH_CODES.has(code)) continue;
      if (code === "error.api.youtube.login") continue;
      if (code === "error.api.rate_exceeded") continue;
      continue;
    }

    let fileUrl: string | undefined;
    let filename: string | undefined;

    if (result.status === "tunnel" || result.status === "redirect") {
      const ok = result as CobaltOk;
      fileUrl = ok.url;
      filename = ok.filename;
    } else if (result.status === "picker") {
      const picker = result as CobaltPicker;
      const video = picker.picker?.find((item) => item.type === "video" && item.url);
      const first = picker.picker?.find((item) => item.url);
      const chosen = video ?? first;
      fileUrl = chosen?.url ?? picker.audio;
      filename = chosen?.filename;
      if (!fileUrl) {
        lastMessage = "Este post não tem um vídeo para baixar.";
        continue;
      }
    } else {
      lastMessage = "Resposta inesperada do servidor de mídia.";
      continue;
    }

    if (!fileUrl) {
      lastMessage = "Não veio um arquivo para baixar.";
      continue;
    }

    const allowed =
      result.status === "tunnel"
        ? isAllowedTunnel(fileUrl)
        : isAllowedRedirect(fileUrl);
    if (!allowed) {
      lastMessage = "Origem do arquivo não reconhecida.";
      continue;
    }

    const meta = await fetchOembed(url);
    const fallback = fallbackPreview(url, platform);
    const safeName =
      filename?.replace(/[/\\?%*:|"<>]/g, "-") ||
      defaultFilename(platform, input.audioOnly, input.quality);

    return {
      ok: true,
      platform,
      title: meta.title || fallback.title,
      author: meta.author,
      thumbnail: meta.thumbnail || fallback.thumbnail,
      filename: safeName,
      downloadUrl: fileUrl,
      mime: mimeFromFilename(safeName, input.audioOnly),
      audioOnly: input.audioOnly,
      quality: input.quality,
    };
  }

  return {
    ok: false,
    message:
      lastMessage ||
      "Não foi possível preparar o download agora. Tente de novo em instantes.",
    code: lastCode,
  };
}

export function isTrustedDownloadUrl(url: string): boolean {
  return isAllowedTunnel(url) || isAllowedRedirect(url);
}
