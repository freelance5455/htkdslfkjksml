import type {
  DownloadMode,
  MediaItem,
  MediaKind,
  Quality,
  ResolveResult,
} from "./types";
import {
  detectPlatform,
  ensureHttp,
  instagramShortcode,
  needsCanonicalize,
  normalizeWatchUrl,
  parseUrl,
  unsupportedReason,
  youtubeVideoId,
} from "./platforms";
import { sealTicket } from "./ticket";

const BROWSER_UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";

const COBALT_INSTANCES = [
  "https://rue-cobalt.xenon.zone",
  "https://cobaltapi.cjs.nz",
];

type CobaltResponse = {
  status?: string;
  url?: string;
  filename?: string;
  picker?: Array<{ type?: string; url?: string; thumb?: string }>;
  audio?: string;
  audioFilename?: string;
  error?: { code?: string };
};

function cobaltErrorMessage(code: string | undefined, platform: string): string {
  switch (code) {
    case "error.api.fetch.empty":
    case "error.api.fetch.fail":
      return platform === "instagram"
        ? "Não achei esse post. Confere se o link é público — perfil privado e stories expirados não abrem."
        : "Não achei esse vídeo. Confere se o link é público e ainda está no ar.";
    case "error.api.youtube.login":
      return "O YouTube bloqueou a leitura agora. Espera uns segundos e tenta de novo.";
    case "error.api.link.unsupported":
      return "Esse tipo de link não dá pra salvar.";
    case "error.api.content.video.unavailable":
      return "Esse vídeo está indisponível.";
    case "error.api.content.post.unavailable":
      return "Esse post não está mais disponível.";
    default:
      return "Não deu pra abrir esse link agora. Tenta de novo em instantes.";
  }
}

async function fetchJson(
  url: string,
  init: RequestInit,
  timeoutMs = 14000,
): Promise<{ ok: boolean; status: number; json: unknown }> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      ...init,
      signal: ctrl.signal,
      redirect: "follow",
    });
    const text = await res.text();
    try {
      return { ok: res.ok, status: res.status, json: JSON.parse(text) as unknown };
    } catch {
      return { ok: false, status: res.status, json: null };
    }
  } catch {
    return { ok: false, status: 0, json: null };
  } finally {
    clearTimeout(timer);
  }
}

async function canonicalize(url: string): Promise<string> {
  if (!needsCanonicalize(url)) return url;
  try {
    const res = await fetch(url, {
      method: "GET",
      redirect: "follow",
      headers: { "User-Agent": BROWSER_UA, Accept: "text/html" },
      signal: AbortSignal.timeout(8000),
    });
    return res.url || url;
  } catch {
    return url;
  }
}

function safeFilename(name: string, ext: string): string {
  const stem = name
    .replace(/\.[a-z0-9]{2,5}$/i, "")
    .replace(/[^\p{L}\p{N}\s._-]+/gu, "")
    .trim()
    .slice(0, 72);
  return `${stem || "video-puro"}.${ext}`;
}

function mimeFor(filename: string, kind: MediaKind): string {
  const lower = filename.toLowerCase();
  if (lower.endsWith(".mp3")) return "audio/mpeg";
  if (lower.endsWith(".m4a")) return "audio/mp4";
  if (lower.endsWith(".webm")) return kind === "audio" ? "audio/webm" : "video/webm";
  if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
  if (lower.endsWith(".png")) return "image/png";
  if (lower.endsWith(".webp")) return "image/webp";
  if (kind === "audio") return "audio/mpeg";
  if (kind === "photo") return "image/jpeg";
  return "video/mp4";
}

function refererFor(mediaUrl: string, platform: string): string | undefined {
  if (mediaUrl.includes("/tunnel")) return undefined;
  if (platform === "youtube") return "https://www.youtube.com/";
  if (platform === "tiktok") return "https://www.tiktok.com/";
  if (platform === "instagram") return "https://www.instagram.com/";
  return undefined;
}

function toItem(opts: {
  url: string;
  filename: string;
  kind: MediaKind;
  title: string;
  author: string;
  thumbnail: string | null;
  duration: number | null;
  platform: ReturnType<typeof detectPlatform>;
  pageUrl: string;
}): MediaItem {
  const filename = safeFilename(opts.filename, extOf(opts.filename, opts.kind));
  return {
    kind: opts.kind,
    title: opts.title || "Vídeo",
    author: opts.author || "",
    thumbnail: opts.thumbnail,
    duration: opts.duration,
    platform: opts.platform,
    filename,
    mime: mimeFor(filename, opts.kind),
    token: sealTicket({
      url: opts.url,
      filename,
      mime: mimeFor(filename, opts.kind),
      referer: refererFor(opts.url, opts.platform),
    }),
    pageUrl: opts.pageUrl,
  };
}

function extOf(filename: string, kind: MediaKind): string {
  const m = filename.toLowerCase().match(/\.([a-z0-9]{2,5})$/);
  if (m) return m[1];
  if (kind === "audio") return "mp3";
  if (kind === "photo") return "jpg";
  return "mp4";
}

async function cobaltOnce(
  instance: string,
  url: string,
  mode: DownloadMode,
  quality: Quality,
): Promise<CobaltResponse | null> {
  const result = await fetchJson(
    `${instance.replace(/\/$/, "")}/`,
    {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        "User-Agent": BROWSER_UA,
      },
      body: JSON.stringify({
        url,
        videoQuality: quality,
        youtubeVideoCodec: "h264",
        youtubeVideoContainer: "mp4",
        downloadMode: mode === "audio" ? "audio" : "auto",
        filenameStyle: "pretty",
        alwaysProxy: true,
      }),
    },
    16000,
  );
  if (!result.json || typeof result.json !== "object") return null;
  return result.json as CobaltResponse;
}

function isAuthError(code: string | undefined): boolean {
  return !!code && code.startsWith("error.api.auth");
}

async function fromCobalt(
  url: string,
  mode: DownloadMode,
  quality: Quality,
  platform: ReturnType<typeof detectPlatform>,
  pageUrl: string,
  meta: { title?: string; author?: string; thumbnail?: string | null; duration?: number | null },
): Promise<ResolveResult> {
  let lastCode: string | undefined;
  for (const instance of COBALT_INSTANCES) {
    let data = await cobaltOnce(instance, url, mode, quality);
    if (!data && instance === COBALT_INSTANCES[0]) {
      data = await cobaltOnce(instance, url, mode, quality);
    }
    if (!data) continue;
    const code = data.error?.code;
    if (isAuthError(code) || code === "error.api.youtube.login") {
      lastCode = code;
      continue;
    }
    if (data.status === "error") {
      lastCode = code;
      continue;
    }
    if (data.status === "tunnel" || data.status === "redirect") {
      if (!data.url) continue;
      const filename = data.filename || (mode === "audio" ? "audio-puro.mp3" : "video-puro.mp4");
      const kind: MediaKind = mode === "audio" ? "audio" : "video";
      return {
        ok: true,
        item: toItem({
          url: data.url,
          filename,
          kind,
          title: meta.title || filename.replace(/\.[a-z0-9]+$/i, ""),
          author: meta.author || "",
          thumbnail: meta.thumbnail ?? null,
          duration: meta.duration ?? null,
          platform,
          pageUrl,
        }),
        extras: [],
      };
    }
    if (data.status === "picker" && data.picker?.length) {
      const extras: MediaItem[] = [];
      let main: MediaItem | null = null;
      for (const entry of data.picker) {
        if (!entry.url) continue;
        const kind: MediaKind =
          entry.type === "photo" ? "photo" : mode === "audio" ? "audio" : "video";
        const filename =
          kind === "photo" ? "foto-puro.jpg" : kind === "audio" ? "audio-puro.mp3" : "video-puro.mp4";
        const item = toItem({
          url: entry.url,
          filename,
          kind,
          title: meta.title || "Post",
          author: meta.author || "",
          thumbnail: entry.thumb || meta.thumbnail || null,
          duration: meta.duration ?? null,
          platform,
          pageUrl,
        });
        if (!main && kind !== "photo") main = item;
        else extras.push(item);
      }
      if (mode === "audio" && data.audio) {
        return {
          ok: true,
          item: toItem({
            url: data.audio,
            filename: data.audioFilename || "audio-puro.mp3",
            kind: "audio",
            title: meta.title || "Áudio",
            author: meta.author || "",
            thumbnail: meta.thumbnail ?? null,
            duration: meta.duration ?? null,
            platform,
            pageUrl,
          }),
          extras: [],
        };
      }
      if (!main) main = extras.shift() ?? null;
      if (!main) continue;
      return { ok: true, item: main, extras };
    }
  }
  return { ok: false, message: cobaltErrorMessage(lastCode, platform) };
}

type TikwmData = {
  code?: number;
  msg?: string;
  data?: {
    title?: string;
    duration?: number;
    cover?: string;
    play?: string;
    hdplay?: string;
    music?: string;
    images?: string[];
    author?: { nickname?: string; unique_id?: string };
  };
};

async function fromTikwm(
  url: string,
  mode: DownloadMode,
  pageUrl: string,
): Promise<ResolveResult | null> {
  const result = await fetchJson(
    `https://tikwm.com/api/?url=${encodeURIComponent(url)}&hd=1`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
        "User-Agent": BROWSER_UA,
        Referer: "https://www.tikwm.com/",
      },
    },
    12000,
  );
  const body = result.json as TikwmData | null;
  if (!body || body.code !== 0 || !body.data) return null;
  const data = body.data;
  const title = data.title?.trim() || "Vídeo do TikTok";
  const author = data.author?.nickname || data.author?.unique_id || "";
  const thumbnail = data.cover || null;
  const duration = typeof data.duration === "number" ? data.duration : null;

  if (data.images && data.images.length > 0 && mode === "video") {
    const items = data.images.map((imageUrl, index) =>
      toItem({
        url: imageUrl,
        filename: `tiktok-${index + 1}.jpg`,
        kind: "photo",
        title,
        author,
        thumbnail: imageUrl,
        duration: null,
        platform: "tiktok",
        pageUrl,
      }),
    );
    const first = items[0];
    if (!first) return null;
    return { ok: true, item: first, extras: items.slice(1) };
  }

  if (mode === "audio") {
    if (!data.music) return null;
    return {
      ok: true,
      item: toItem({
        url: data.music,
        filename: "tiktok-audio.mp3",
        kind: "audio",
        title,
        author,
        thumbnail,
        duration,
        platform: "tiktok",
        pageUrl,
      }),
      extras: [],
    };
  }

  const videoUrl = data.hdplay || data.play;
  if (!videoUrl) return null;
  return {
    ok: true,
    item: toItem({
      url: videoUrl,
      filename: "tiktok.mp4",
      kind: "video",
      title,
      author,
      thumbnail,
      duration,
      platform: "tiktok",
      pageUrl,
    }),
    extras: [],
  };
}

async function youtubeMeta(id: string): Promise<{
  title?: string;
  author?: string;
  thumbnail?: string | null;
}> {
  const result = await fetchJson(
    `https://www.youtube.com/oembed?url=${encodeURIComponent(`https://www.youtube.com/watch?v=${id}`)}&format=json`,
    { headers: { Accept: "application/json", "User-Agent": BROWSER_UA } },
    8000,
  );
  const json = result.json as {
    title?: string;
    author_name?: string;
    thumbnail_url?: string;
  } | null;
  if (!json) {
    return { thumbnail: `https://i.ytimg.com/vi/${id}/hqdefault.jpg` };
  }
  return {
    title: json.title,
    author: json.author_name,
    thumbnail: json.thumbnail_url || `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
  };
}

async function tiktokMeta(url: string): Promise<{
  title?: string;
  author?: string;
  thumbnail?: string | null;
}> {
  const result = await fetchJson(
    `https://www.tiktok.com/oembed?url=${encodeURIComponent(url)}`,
    { headers: { Accept: "application/json", "User-Agent": BROWSER_UA } },
    8000,
  );
  const json = result.json as {
    title?: string;
    author_name?: string;
    thumbnail_url?: string;
  } | null;
  if (!json) return {};
  return {
    title: json.title,
    author: json.author_name,
    thumbnail: json.thumbnail_url ?? null,
  };
}

export async function resolveMediaUrl(input: {
  url: string;
  mode: DownloadMode;
  quality: Quality;
}): Promise<ResolveResult> {
  const raw = ensureHttp(input.url);
  const parsed = parseUrl(raw);
  if (!parsed || (parsed.protocol !== "http:" && parsed.protocol !== "https:")) {
    return { ok: false, message: "Cola um link válido, começando com https://" };
  }

  const blocked = unsupportedReason(raw);
  if (blocked) return { ok: false, message: blocked };

  const canonical = await canonicalize(raw);
  const pageUrl = normalizeWatchUrl(canonical);
  const platform = detectPlatform(pageUrl);
  const mode = input.mode;
  const quality = input.quality;

  if (platform === "unknown") {
    return {
      ok: false,
      message: "Por enquanto abro YouTube, TikTok e Instagram. Cola o link do vídeo.",
    };
  }

  if (platform === "tiktok") {
    const tikwm = await fromTikwm(pageUrl, mode, pageUrl);
    if (tikwm?.ok) return tikwm;
    const oembed = await tiktokMeta(pageUrl);
    return fromCobalt(pageUrl, mode, quality, platform, pageUrl, oembed);
  }

  if (platform === "youtube") {
    const id = youtubeVideoId(pageUrl);
    if (!id) {
      return { ok: false, message: "Não reconheci o vídeo nesse link do YouTube." };
    }
    const watch = `https://www.youtube.com/watch?v=${id}`;
    const meta = await youtubeMeta(id);
    const result = await fromCobalt(watch, mode, quality, platform, watch, meta);
    if (result.ok) return result;
    const retry = await fromCobalt(pageUrl, mode, quality, platform, watch, meta);
    return retry.ok ? retry : result;
  }

  if (platform === "instagram") {
    const code = instagramShortcode(pageUrl);
    const targets = Array.from(
      new Set(
        [
          pageUrl,
          code ? `https://www.instagram.com/reel/${code}/` : null,
          code ? `https://www.instagram.com/p/${code}/` : null,
        ].filter((value): value is string => !!value),
      ),
    );
    let last: ResolveResult | null = null;
    for (const target of targets) {
      const result = await fromCobalt(target, mode, quality, platform, target, {
        title: "Instagram",
        thumbnail: null,
      });
      if (result.ok) return result;
      last = result;
    }
    return (
      last ?? {
        ok: false,
        message:
          "Não achei esse post. Confere se o link é público — perfil privado e stories expirados não abrem.",
      }
    );
  }

  return fromCobalt(pageUrl, mode, quality, platform, pageUrl, {});
}
