export type Platform =
  | "youtube"
  | "tiktok"
  | "instagram"
  | "x"
  | "facebook"
  | "unknown";

export type MediaKind = "video" | "audio" | "photo";
export type Quality = "1080" | "720" | "480";
export type DownloadMode = "video" | "audio";

export type MediaItem = {
  kind: MediaKind;
  title: string;
  author: string;
  thumbnail: string | null;
  duration: number | null;
  platform: Platform;
  filename: string;
  mime: string;
  token: string;
  pageUrl: string;
};

export type ResolveResult =
  | { ok: true; item: MediaItem; extras: MediaItem[] }
  | { ok: false; message: string };
