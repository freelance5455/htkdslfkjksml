import { createCipheriv, createDecipheriv, createHash, randomBytes } from "node:crypto";

const SECRET = "puro-media-ticket-v1";

export type Ticket = {
  url: string;
  filename: string;
  mime: string;
  referer?: string;
  exp: number;
};

function key() {
  return createHash("sha256").update(SECRET).digest();
}

export function sealTicket(input: Omit<Ticket, "exp">, ttlMs = 20 * 60 * 1000): string {
  const payload: Ticket = { ...input, exp: Date.now() + ttlMs };
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key(), iv);
  const enc = Buffer.concat([
    cipher.update(JSON.stringify(payload), "utf8"),
    cipher.final(),
  ]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, enc]).toString("base64url");
}

export function openTicket(token: string): Ticket | null {
  try {
    const buf = Buffer.from(token, "base64url");
    if (buf.length < 29) return null;
    const iv = buf.subarray(0, 12);
    const tag = buf.subarray(12, 28);
    const enc = buf.subarray(28);
    const decipher = createDecipheriv("aes-256-gcm", key(), iv);
    decipher.setAuthTag(tag);
    const json = Buffer.concat([decipher.update(enc), decipher.final()]).toString("utf8");
    const ticket = JSON.parse(json) as Ticket;
    if (!ticket?.url || ticket.exp < Date.now()) return null;
    if (!/^https?:\/\//i.test(ticket.url)) return null;
    return ticket;
  } catch {
    return null;
  }
}

export function isBlockedHost(raw: string): boolean {
  let u: URL;
  try {
    u = new URL(raw);
  } catch {
    return true;
  }
  if (u.protocol !== "https:" && u.protocol !== "http:") return true;
  const host = u.hostname.toLowerCase().replace(/^\[|\]$/g, "");
  if (
    host === "localhost" ||
    host.endsWith(".local") ||
    host === "0.0.0.0" ||
    host === "::1" ||
    host === "metadata.google.internal"
  ) {
    return true;
  }
  if (/^(127\.|10\.|192\.168\.|169\.254\.|0\.)/.test(host)) return true;
  const m = host.match(/^172\.(\d+)\./);
  if (m) {
    const n = Number(m[1]);
    if (n >= 16 && n <= 31) return true;
  }
  return false;
}
