import type { Project, QuestionScene, SceneAudioClip, Timeline } from "@/types";

function seconds(ms: number, min = 0): number {
  return Math.max(min, (Number.isFinite(ms) ? ms : 0) / 1000);
}

/**
 * مصدر التوقيت الوحيد للمعاينة والتصدير.
 * كل مدة مبنية على مدة الملف الصوتي الفعلية + إعدادات المستخدم، دون تأخيرات عشوائية.
 */
export function buildTimeline(project: Project): Timeline {
  const timing = project.timing;
  const warnings: string[] = [];
  let cursor = 0;
  let hasAudio = false;
  const scenes: QuestionScene[] = [];

  project.questions.forEach((question, index) => {
    const voice = Math.max(0, Math.min(1, timing.voiceVolume / 100));
    const clips: SceneAudioClip[] = [];
    const combined = question.combinedAudioId ? project.media[question.combinedAudioId] : undefined;
    const questionAudio = question.questionAudioId ? project.media[question.questionAudioId] : undefined;
    const optionsAudio = question.optionsAudioId ? project.media[question.optionsAudioId] : undefined;
    const answerAudio = question.answerAudioId ? project.media[question.answerAudioId] : undefined;
    const useCombined = Boolean(timing.audioMode === "combined" && combined);

    let questionDuration = 0;
    let optionsDuration = 0;
    let optionsStart = 0;
    let thinkingStart = 0;

    if (useCombined && combined) {
      const combinedDuration = Math.max(0.2, combined.duration ?? 0);
      const split = Math.max(10, Math.min(95, timing.combinedSplit)) / 100;
      optionsStart = combinedDuration * split;
      questionDuration = optionsStart;
      optionsDuration = combinedDuration - optionsStart;
      thinkingStart = combinedDuration + seconds(timing.optionsHoldMs);
      clips.push({ id: `${question.id}_combined`, role: "question", mediaId: combined.id, start: 0, duration: combinedDuration, volume: voice });
      hasAudio = true;
    } else {
      questionDuration = questionAudio?.duration ?? seconds(timing.questionSilentMs, 0.8);
      optionsDuration = optionsAudio?.duration ?? seconds(timing.optionsSilentMs, 0.8);
      optionsStart = questionDuration + seconds(timing.questionHoldMs);
      thinkingStart = optionsStart + optionsDuration + seconds(timing.optionsHoldMs);
      if (questionAudio && questionAudio.duration) {
        clips.push({ id: `${question.id}_q`, role: "question", mediaId: questionAudio.id, start: 0, duration: questionAudio.duration, volume: voice });
        hasAudio = true;
      }
      if (optionsAudio && optionsAudio.duration) {
        clips.push({
          id: `${question.id}_o`,
          role: "options",
          mediaId: optionsAudio.id,
          start: optionsStart,
          duration: optionsAudio.duration,
          volume: voice,
        });
        hasAudio = true;
      }
      if (!questionAudio?.["duration"]) {
        warnings.push(`السؤال ${index + 1}: لا يوجد صوت للسؤال — سيُستخدم وقت قراءة صامت.`);
      }
      if (!optionsAudio?.["duration"]) {
        warnings.push(`السؤال ${index + 1}: لا يوجد صوت للخيارات — سيُستخدم وقت صامت.`);
      }
    }

    const thinkSec = Math.max(1, Math.min(120, question.thinkSec || timing.defaultThinkSec));
    const revealStart = thinkingStart + thinkSec;
    const answerDuration = answerAudio?.duration ?? 0;
    if (answerAudio?.duration) hasAudio = true;
    const revealDuration = Math.max(seconds(question.revealHoldMs, 0.8), answerDuration + 0.25);
    if (answerAudio && answerAudio.duration) {
      clips.push({
        id: `${question.id}_a`,
        role: "answer",
        mediaId: answerAudio.id,
        start: revealStart,
        duration: answerAudio.duration,
        volume: voice,
      });
    }
    const duration = revealStart + revealDuration + seconds(timing.nextHoldMs, 0);

    scenes.push({
      questionId: question.id,
      index,
      question,
      timings: {
        start: cursor,
        duration,
        optionsStart,
        thinkingStart,
        revealStart,
        revealDuration,
        end: cursor + duration,
      },
      audio: clips,
    });
    cursor += duration;
  });

  if (!hasAudio && project.questions.length > 0) {
    warnings.push("لا توجد ملفات صوتية مرتبطة بالمشروع. سيُصدَّر الفيديو بصوت صامت.");
  }

  return { scenes, totalDuration: cursor, hasAudio, warnings };
}

export function sceneAt(timeline: Timeline, time: number): { scene: QuestionScene; local: number } | null {
  if (timeline.scenes.length === 0) return null;
  const clamped = Math.max(0, Math.min(timeline.totalDuration - 0.001, time));
  for (const scene of timeline.scenes) {
    if (clamped >= scene.timings.start && clamped < scene.timings.end) {
      return { scene, local: clamped - scene.timings.start };
    }
  }
  const last = timeline.scenes[timeline.scenes.length - 1];
  return { scene: last, local: Math.max(0, clamped - last.timings.start) };
}

export type PhaseKey = "question" | "options" | "thinking" | "reveal" | "outro";

export function phaseAt(scene: QuestionScene, local: number): { key: PhaseKey; label: string } {
  if (local >= scene.timings.revealStart) return { key: "reveal", label: "الإجابة الصحيحة" };
  if (local >= scene.timings.thinkingStart) return { key: "thinking", label: "وقت التفكير" };
  if (local >= scene.timings.optionsStart) return { key: "options", label: "قراءة الخيارات" };
  return { key: "question", label: "قراءة السؤال" };
}

export function sceneDurations(project: Project): number[] {
  return buildTimeline(project).scenes.map((scene) => scene.timings.duration);
}

export function formatClock(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return "00:00";
  const total = Math.ceil(seconds);
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function estimatedFileSize(project: Project): number {
  const timeline = buildTimeline(project);
  const bitrate = project.exportSettings.videoBitrate + project.exportSettings.audioBitrate;
  return Math.round((timeline.totalDuration * bitrate) / 8);
}
