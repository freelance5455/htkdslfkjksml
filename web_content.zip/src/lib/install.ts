import { useEffect, useState } from "react";

interface InstallPrompt extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

let pendingPrompt: InstallPrompt | null = null;
window.addEventListener("beforeinstallprompt", (event) => {
  event.preventDefault();
  pendingPrompt = event as InstallPrompt;
  window.dispatchEvent(new Event("topecode-install-ready"));
});

export function useAppInstall() {
  const [prompt, setPrompt] = useState<InstallPrompt | null>(
    () => pendingPrompt,
  );
  const [installed, setInstalled] = useState(
    () => matchMedia("(display-mode: standalone)").matches,
  );
  useEffect(() => {
    const ready = () => setPrompt(pendingPrompt);
    const done = () => {
      setInstalled(true);
      setPrompt(null);
    };
    window.addEventListener("topecode-install-ready", ready);
    window.addEventListener("appinstalled", done);
    return () => {
      window.removeEventListener("topecode-install-ready", ready);
      window.removeEventListener("appinstalled", done);
    };
  }, []);
  const install = async () => {
    if (!prompt) return false;
    await prompt.prompt();
    const choice = await prompt.userChoice;
    pendingPrompt = null;
    setPrompt(null);
    return choice.outcome === "accepted";
  };
  return { available: !!prompt, installed, install };
}
