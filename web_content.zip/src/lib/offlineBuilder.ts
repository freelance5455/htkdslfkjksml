import type { ApkBuildConfig, BuildArtifactSummary } from '../types/apk';
import { buildSignedApkBinary } from './apkCore/apkPackager';
import { buildGradleProjectZip } from './apkCore/gradlePackager';
import { renderMonogramIconBase64 } from './iconCanvas';

export function validateConfigLocally(config: ApkBuildConfig): string | null {
  if (!config.appName || config.appName.trim().length === 0) {
    return 'Application name is required.';
  }
  if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(config.packageId)) {
    return 'Package ID must follow reverse-domain notation (e.g. com.company.app).';
  }
  if (!config.versionName || config.versionName.trim().length === 0) {
    return 'Version name is required.';
  }
  if (!Number.isInteger(config.versionCode) || config.versionCode < 1) {
    return 'Version code must be a positive integer.';
  }
  if (config.sourceMode === 'url') {
    try {
      const parsed = new URL(config.websiteUrl);
      if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
        return 'Website URL must start with http:// or https://.';
      }
    } catch {
      return 'Please enter a valid Website URL.';
    }
  } else if (config.sourceMode === 'code') {
    if (!config.rawHtmlCode || config.rawHtmlCode.trim().length === 0) {
      return 'Please paste or write HTML code before compiling.';
    }
  } else if (config.htmlFiles.length === 0) {
    return 'Please provide at least one HTML file for HTML Bundle mode.';
  }
  return null;
}

export async function compileApkOfflineInBrowser(
  config: ApkBuildConfig
): Promise<BuildArtifactSummary> {
  const err = validateConfigLocally(config);
  if (err) throw new Error(err);

  const iconBase64 =
    config.iconBase64Png ||
    renderMonogramIconBase64(config.appName, config.themeColor, 192);

  const normalizedConfig: ApkBuildConfig = {
    ...config,
    iconBase64Png: iconBase64,
  };

  const buildId =
    typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
      ? `offline-${crypto.randomUUID()}`
      : `offline-${Date.now()}`;

  const [{ apkBytes, summary }, gradleBytes] = await Promise.all([
    buildSignedApkBinary(normalizedConfig, buildId),
    buildGradleProjectZip(normalizedConfig),
  ]);

  const apkBlob = new Blob([apkBytes as BlobPart], {
    type: 'application/vnd.android.package-archive',
  });
  const gradleBlob = new Blob([gradleBytes as BlobPart], {
    type: 'application/zip',
  });

  const apkBlobUrl = URL.createObjectURL(apkBlob);
  const gradleBlobUrl = URL.createObjectURL(gradleBlob);

  return {
    ...summary,
    gradleSizeBytes: gradleBytes.length,
    builtOffline: true,
    apkBlobUrl,
    gradleBlobUrl,
  };
}
