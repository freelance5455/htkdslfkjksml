"use client";

import { useSyncExternalStore } from "react";

export type ToastTone = "earn" | "spend" | "neutral" | "error";
export interface Toast {
  id: number;
  text: string;
  tone: ToastTone;
}

let toasts: Toast[] = [];
const EMPTY: Toast[] = [];
const listeners = new Set<() => void>();
let seq = 0;

function emit() {
  listeners.forEach((l) => l());
}

export function pushToast(text: string, tone: ToastTone = "neutral") {
  const id = (seq += 1);
  toasts = [...toasts, { id, text, tone }];
  emit();
  setTimeout(() => {
    toasts = toasts.filter((t) => t.id !== id);
    emit();
  }, 2600);
  return id;
}

function subscribe(cb: () => void) {
  listeners.add(cb);
  return () => listeners.delete(cb);
}

export function useToasts() {
  return useSyncExternalStore(
    subscribe,
    () => toasts,
    () => EMPTY,
  );
}
