import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { plans, subscriptions, users } from "@/db/schema";
import { ensureBootstrap } from "./settings";

export type PublicPlan = {
  key: string;
  name: string;
  tagline: string;
  priceCents: number;
  currency: string;
  interval: string;
  monthlyLimit: number;
  features: string[];
  sortOrder: number;
};

export async function getPlans(): Promise<PublicPlan[]> {
  await ensureBootstrap();
  const rows = await db.select().from(plans).orderBy(asc(plans.sortOrder), asc(plans.priceCents));
  return rows.map((p) => ({
    key: p.key,
    name: p.name,
    tagline: p.tagline,
    priceCents: p.priceCents,
    currency: p.currency,
    interval: p.interval,
    monthlyLimit: p.monthlyLimit,
    features: Array.isArray(p.features) ? p.features : [],
    sortOrder: p.sortOrder,
  }));
}

export async function getPlan(key: string): Promise<PublicPlan | null> {
  const all = await getPlans();
  return all.find((p) => p.key === key) ?? all.find((p) => p.key === "free") ?? null;
}

export function formatPrice(cents: number, currency = "USD", interval = "month"): string {
  if (cents <= 0) return "Free";
  const value = (cents / 100).toFixed(2).replace(/\.00$/, "");
  return `$${value}/${interval === "month" ? "mo" : interval}`;
}

/** Effective monthly allowance for a user, combining plan limit + settings bonus. */
export function effectiveLimit(planLimit: number, freeLimitBonus: number, planKey: string): number {
  if (planKey !== "free") return planLimit;
  return planLimit + Math.max(0, freeLimitBonus);
}

/**
 * Simulated billing provider. In production this would be swapped for a Stripe
 * checkout session; the app only needs `activateSubscription` to be called by a
 * verified webhook.
 */
export async function activateSubscription(userId: number, planKey: string, amountCents: number) {
  const now = new Date();
  const periodEnd = new Date(now);
  periodEnd.setMonth(periodEnd.getMonth() + 1);

  await db
    .update(subscriptions)
    .set({ status: "canceled" })
    .where(eq(subscriptions.userId, userId));

  await db.insert(subscriptions).values({
    userId,
    planKey,
    status: "active",
    amountCents,
    currentPeriodStart: now,
    currentPeriodEnd: periodEnd,
  });

  await db.update(users).set({ planKey }).where(eq(users.id, userId));

  return { currentPeriodEnd: periodEnd };
}

export async function getActiveSubscription(userId: number) {
  const rows = await db
    .select()
    .from(subscriptions)
    .where(eq(subscriptions.userId, userId))
    .orderBy(asc(subscriptions.createdAt));
  const active = rows.filter((r) => r.status === "active").pop();
  return active ?? null;
}
