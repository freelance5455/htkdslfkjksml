import { transform } from "sucrase";
import type { FS } from "./types";
import { pathOf } from "./fs";

export interface PreviewBuild {
  html: string;
  fileCount: number;
  entry: string;
  session: string;
}
const serialize = (value: unknown) =>
  JSON.stringify(value)
    .replace(/</g, "\\u003c")
    .replace(/\u2028/g, "\\u2028")
    .replace(/\u2029/g, "\\u2029");
const script = (code: string) =>
  `<script>${code.replace(/<\/script/gi, "<\\/script")}</script>`;

export function compilePreview(
  fs: FS,
  runtime: string,
  session: string,
): PreviewBuild {
  const files = Object.fromEntries(
    Object.values(fs.nodes)
      .filter(
        (node) =>
          node.type === "file" &&
          !node.binary &&
          !/(^|\/)(\.env($|\.)|credentials|id_rsa)|\.(pem|key)$/i.test(
            pathOf(fs, node.id),
          ),
      )
      .map((node) => [pathOf(fs, node.id), node.content ?? ""]),
  );
  const htmlSource = files["index.html"];
  const htmlEntry = htmlSource
    ?.match(/<script\b[^>]*src=["']([^"']+\.(?:tsx?|jsx?))["'][^>]*>/i)?.[1]
    ?.replace(/^\//, "");
  const entry =
    htmlEntry ??
    [
      "src/main.tsx",
      "src/main.jsx",
      "src/main.ts",
      "src/main.js",
      "src/index.tsx",
      "src/index.jsx",
      "src/App.tsx",
      "src/App.jsx",
      "index.js",
    ].find((path) => path in files);
  if (!entry && !htmlSource)
    throw new Error(
      "No browser entry found. Create index.html, src/main.tsx, or src/App.tsx to run a preview.",
    );
  const modules: Record<string, string> = {};
  for (const [path, content] of Object.entries(files)) {
    if (
      !/\.[jt]sx?$/.test(path) ||
      /(^|\/)(vite\.config|next\.config|tailwind\.config|postcss\.config|.*\.test|.*\.spec)\./.test(
        path,
      )
    )
      continue;
    try {
      modules[path] = transform(content, {
        transforms: ["typescript", "jsx", "imports"],
        jsxRuntime: "classic",
        production: true,
        filePath: path,
      }).code;
    } catch (error) {
      throw new Error(
        `${path}: ${error instanceof Error ? error.message : "Syntax could not be compiled."}`,
      );
    }
  }
  const bridge = `const __session=${serialize(session)};
const __report=(kind,message)=>parent.postMessage({source:'topecode-preview',session:__session,kind,message:String(message).slice(0,6000)},'*');
window.addEventListener('error',e=>__report('error',e.message));
window.addEventListener('unhandledrejection',e=>__report('error',e.reason?.message||e.reason));
for(const kind of ['log','warn','error']){const original=console[kind];console[kind]=(...args)=>{original.apply(console,args);__report(kind,args.map(a=>typeof a==='string'?a:JSON.stringify(a)).join(' '));};}
document.addEventListener('submit',e=>e.preventDefault());
document.addEventListener('click',e=>{const a=e.target.closest?.('a');if(a?.href&&!a.getAttribute('href')?.startsWith('#')){e.preventDefault();__report('log','Navigation blocked in sandbox: '+a.getAttribute('href'));}});
`;
  let markup =
    htmlSource ??
    '<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1" /></head><body><div id="root"></div></body></html>';
  markup = markup.replace(
    /(<img\b[^>]*src=["'])([^"']+)(["'])/gi,
    (tag, prefix: string, path: string, suffix: string) => {
      const normalized = path.replace(/^\.\//, "").replace(/^\//, "");
      return normalized.endsWith(".svg") && files[normalized]
        ? prefix +
            "data:image/svg+xml;charset=utf-8," +
            encodeURIComponent(files[normalized]) +
            suffix
        : tag;
    },
  );
  markup = markup.replace(
    /<script\b[^>]*src=["'][^"']+["'][^>]*>[\s\S]*?<\/script>/gi,
    "",
  );
  markup = markup.replace(
    /<link\b[^>]*href=["']([^"']+\.css)["'][^>]*>/gi,
    (_tag, url: string) =>
      `<style>${(files[url.replace(/^\//, "")] ?? "").replace(/<\/style/gi, "<\\/style")}</style>`,
  );
  const policy = `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval' blob:; style-src 'unsafe-inline'; img-src data: blob:; font-src data:; connect-src 'none'; form-action 'none'; base-uri 'none';" />`;
  const boot = `
const __files=${serialize(files)}, __codes=${serialize(modules)}, __cache={};
const {React,createRoot,JSXRuntime,Icons}=window.__topecodeRuntime;
const __storage={};const __memoryStorage={getItem:k=>__storage[k]??null,setItem:(k,v)=>{__storage[k]=String(v)},removeItem:k=>{delete __storage[k]},clear:()=>{for(const k in __storage)delete __storage[k]}};
try{Object.defineProperty(window,'localStorage',{value:__memoryStorage});Object.defineProperty(window,'sessionStorage',{value:__memoryStorage});}catch{}
const __builtins={react:React,'react-dom/client':{createRoot},'react-dom':{createRoot},'react/jsx-runtime':JSXRuntime,'react/jsx-dev-runtime':JSXRuntime,'lucide-react':Icons};
function __resolve(id,from){
if(id in __builtins)return id;
if(!id.startsWith('.')&&!id.startsWith('/')&&!id.startsWith('@/'))throw Error('Package "'+id+'" is not bundled in this browser runtime. Use React, plain CSS and local modules, or export to a native runtime.');
const parts=(id.startsWith('@/')?'src/'+id.slice(2):id.startsWith('/')?id.slice(1):from.slice(0,from.lastIndexOf('/')+1)+id).split('/'),out=[];
for(const p of parts){if(!p||p==='.')continue;if(p==='..')out.pop();else out.push(p);}const path=out.join('/');
for(const p of [path,path+'.tsx',path+'.ts',path+'.jsx',path+'.js',path+'.json',path+'/index.tsx',path+'/index.ts',path+'/index.jsx',path+'/index.js'])if(p in __files)return p;
throw Error('Cannot resolve "'+id+'" from '+from);}
function __load(id,from=''){
const path=from?__resolve(id,from):id;if(path in __builtins)return __builtins[path];if(__cache[path])return __cache[path].exports;
const module={exports:{}};__cache[path]=module;
if(path.endsWith('.css')){const style=document.createElement('style');style.textContent=__files[path];document.head.appendChild(style);return module.exports;}
if(path.endsWith('.json'))return module.exports=JSON.parse(__files[path]);
if(path.endsWith('.svg'))return module.exports='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(__files[path]);
if(!__codes[path])throw Error('Unsupported browser module: '+path);
try{new Function('require','module','exports','React','process',__codes[path]+'\\n//# sourceURL='+path)(p=>__load(p,path),module,module.exports,React,{env:{NODE_ENV:'development'}});}catch(e){throw Error(path+': '+e.message);}
return module.exports;}
try {
${entry ? `const loaded=__load(${serialize(entry)});` : ""}
${entry && /\/App\.[jt]sx?$/.test(entry) ? "createRoot(document.getElementById('root')).render(React.createElement(loaded.default));" : ""}
setTimeout(()=>__report('ready',${serialize(entry ?? "index.html")}),80);
} catch(error){__report('error',error.message);const root=document.getElementById('root')||document.body;root.textContent=error.message;root.style.cssText='font:13px/1.7 monospace;color:#a33;padding:20px;white-space:pre-wrap';}
`;
  const head = policy + script(bridge) + script(runtime);
  markup = /<head[^>]*>/i.test(markup)
    ? markup.replace(/<head[^>]*>/i, (tag) => tag + head)
    : `<head>${head}</head>` + markup;
  markup = /<\/body>/i.test(markup)
    ? markup.replace(/<\/body>/i, script(boot) + "</body>")
    : markup + script(boot);
  return {
    html: markup,
    fileCount: Object.keys(modules).length,
    entry: entry ?? "index.html",
    session,
  };
}
