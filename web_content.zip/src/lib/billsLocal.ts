"use client";

import { currentMonthKey, monthLabel, shiftMonth, todayKey } from "./calendar";
import { dueDateFor, statusFor, round } from "./billsCore";
import type { BillView, PeriodView } from "./types";
import type { LocalData } from "./localdb";

/**
 * On-device version of the period engine: walks every bill from its start
 * month to next month, recomputes carry-over of unpaid remainders and keeps
 * the stored period rows in sync. Mutates `data` in place.
 */
export function syncPeriodsLocal(data: LocalData) {
  const currentPeriod = currentMonthKey();
  const horizon = shiftMonth(currentPeriod, 1);

  for (const bill of data.bills) {
    const start = bill.startMonth < currentPeriod ? bill.startMonth : currentPeriod;
    let cursor = start;
    let carry = 0;
    let guard = 0;

    while (cursor <= horizon && guard < 180) {
      guard += 1;
      const row = data.billPeriods.find((p) => p.billId === bill.id && p.period === cursor);
      const paid = round(
        data.billPayments
          .filter((p) => p.billId === bill.id && p.period === cursor)
          .reduce((s, p) => s + p.amount, 0),
      );
      const baseDue = round(bill.amount);
      const due = round(baseDue + carry);
      const dueDate = dueDateFor(cursor, bill.dueDay);
      const status = statusFor({ period: cursor, due, paid, currentPeriod, dueDate });

      if (!row) {
        data.billPeriods.push({
          id: data.seq.period,
          billId: bill.id,
          period: cursor,
          baseDue,
          carry: round(carry),
          paid,
          status,
          updatedAt: new Date().toISOString(),
        });
        data.seq.period += 1;
      } else if (
        Math.abs(row.baseDue - baseDue) > 0.005 ||
        Math.abs(row.carry - round(carry)) > 0.005 ||
        Math.abs(row.paid - paid) > 0.005 ||
        row.status !== status
      ) {
        row.baseDue = baseDue;
        row.carry = round(carry);
        row.paid = paid;
        row.status = status;
        row.updatedAt = new Date().toISOString();
      }
      carry = bill.autoCarry ? round(Math.max(0, due - paid)) : 0;
      cursor = shiftMonth(cursor, 1);
    }
  }
}

export function billViewsLocal(data: LocalData): BillView[] {
  syncPeriodsLocal(data);
  const currentPeriod = currentMonthKey();

  return [...data.bills]
    .sort((a, b) => a.name.localeCompare(b.name))
    .map((bill) => {
      const periods: PeriodView[] = data.billPeriods
        .filter((p) => p.billId === bill.id)
        .map((p) => {
          const due = round(p.baseDue + p.carry);
          return {
            period: p.period,
            label: monthLabel(p.period),
            baseDue: p.baseDue,
            carry: p.carry,
            due,
            paid: p.paid,
            remaining: round(Math.max(0, due - p.paid)),
            status: p.status as PeriodView["status"],
            dueDay: dueDateFor(p.period, bill.dueDay),
          };
        })
        .sort((a, b) => b.period.localeCompare(a.period));

      const current =
        periods.find((p) => p.period === currentPeriod) ??
        periods[0] ?? {
          period: currentPeriod,
          label: monthLabel(currentPeriod),
          baseDue: bill.amount,
          carry: 0,
          due: bill.amount,
          paid: 0,
          remaining: bill.amount,
          status: "upcoming" as const,
          dueDay: dueDateFor(currentPeriod, bill.dueDay),
        };

      const payments = data.billPayments
        .filter((p) => p.billId === bill.id)
        .sort((a, b) => b.paidAt.localeCompare(a.paidAt))
        .map((p) => ({ id: p.id, period: p.period, amount: p.amount, note: p.note, paidAt: p.paidAt }));

      return {
        id: bill.id,
        name: bill.name,
        category: bill.category,
        amount: bill.amount,
        dueDay: bill.dueDay,
        startMonth: bill.startMonth,
        active: bill.active,
        autoCarry: bill.autoCarry,
        note: bill.note,
        currentPeriod,
        periods,
        current,
        totalRemaining: round(
          periods.filter((p) => p.period <= currentPeriod).reduce((s, p) => s + p.remaining, 0),
        ),
        totalPaid: round(payments.reduce((s, p) => s + p.amount, 0)),
        overdue: periods.some((p) => p.status === "overdue"),
        payments,
      };
    });
}

export { todayKey };
