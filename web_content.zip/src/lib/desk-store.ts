import { create } from "zustand";
import { persist } from "zustand/middleware";
import { composeMuse } from "@/lib/muse";
import {
  activeChapter,
  blankStory,
  seedStory,
  uid,
  type Chapter,
  type Character,
  type DeskTone,
  type MuseHint,
  type Place,
  type Story,
  type Thread,
} from "@/lib/story";

type Selection = { start: number; end: number; text: string };

type UiState = {
  pane: "write" | "desk" | "muse";
  focus: boolean;
  selection: Selection;
  caret: { start: number; end: number; stamp: number } | null;
  setPane: (pane: UiState["pane"]) => void;
  setFocus: (focus: boolean) => void;
  setSelection: (selection: Selection) => void;
  placeCaret: (start: number, end: number) => void;
};

export const useUi = create<UiState>((set) => ({
  pane: "write",
  focus: false,
  selection: { start: 0, end: 0, text: "" },
  caret: null,
  setPane: (pane) => set({ pane }),
  setFocus: (focus) => set({ focus }),
  setSelection: (selection) => set({ selection }),
  placeCaret: (start, end) => set({ caret: { start, end, stamp: Date.now() } }),
}));

type DeskState = {
  desk: DeskTone;
  activeId: string;
  stories: Story[];
  setDesk: (desk: DeskTone) => void;
  setActive: (id: string) => void;
  patchStory: (id: string, patch: Partial<Story>) => void;
  updateChapter: (storyId: string, chapterId: string, patch: Partial<Chapter>) => void;
  addChapter: (storyId: string) => void;
  removeChapter: (storyId: string, chapterId: string) => void;
  addStory: (story: Story) => void;
  deleteStory: (id: string) => void;
  addCharacter: (storyId: string) => void;
  patchCharacter: (storyId: string, characterId: string, patch: Partial<Character>) => void;
  removeCharacter: (storyId: string, characterId: string) => void;
  addPlace: (storyId: string) => void;
  patchPlace: (storyId: string, placeId: string, patch: Partial<Place>) => void;
  removePlace: (storyId: string, placeId: string) => void;
  addThread: (storyId: string) => void;
  patchThread: (storyId: string, threadId: string, patch: Partial<Thread>) => void;
  removeThread: (storyId: string, threadId: string) => void;
  askMuse: (instruction: string, hint: MuseHint, echo?: boolean) => void;
  insertProse: (text: string) => void;
  undoInsert: () => void;
};

function mapStory(stories: Story[], id: string, fn: (story: Story) => Story): Story[] {
  return stories.map((story) => (story.id === id ? fn(story) : story));
}

function withTouch(story: Story, patch: Partial<Story>): Story {
  return { ...story, ...patch, updatedAt: Date.now() };
}

const seed = seedStory();

export const useDesk = create<DeskState>()(
  persist(
    (set, get) => ({
      desk: "day",
      activeId: seed.id,
      stories: [seed],
      setDesk: (desk) => set({ desk }),
      setActive: (id) => {
        useUi.getState().setSelection({ start: 0, end: 0, text: "" });
        set({ activeId: id });
      },
      patchStory: (id, patch) =>
        set((state) => ({
          stories: mapStory(state.stories, id, (story) => withTouch(story, patch)),
        })),
      updateChapter: (storyId, chapterId, patch) =>
        set((state) => ({
          stories: mapStory(state.stories, storyId, (story) =>
            withTouch(story, {
              chapters: story.chapters.map((chapter) =>
                chapter.id === chapterId ? { ...chapter, ...patch } : chapter,
              ),
            }),
          ),
        })),
      addChapter: (storyId) =>
        set((state) => ({
          stories: mapStory(state.stories, storyId, (story) => {
            const chapter: Chapter = {
              id: uid(),
              title: `Chapter ${story.chapters.length + 1}`,
              body: "",
            };
            return withTouch(story, {
              chapters: [...story.chapters, chapter],
              activeChapterId: chapter.id,
            });
          }),
        })),
      removeChapter: (storyId, chapterId) =>
        set((state) => ({
          stories: mapStory(state.stories, storyId, (story) => {
            if (story.chapters.length < 2) return story;
            const chapters = story.chapters.filter((chapter) => chapter.id !== chapterId);
            const activeChapterId =
              story.activeChapterId === chapterId ? chapters[0]!.id : story.activeChapterId;
            return withTouch(story, { chapters, activeChapterId });
          }),
        })),
      addStory: (story) =>
        set((state) => ({
          stories: [story, ...state.stories],
          activeId: story.id,
        })),
      deleteStory: (id) =>
        set((state) => {
          const stories = state.stories.filter((story) => story.id !== id);
          if (!stories.length) {
            const fresh = blankStory();
            return { stories: [fresh], activeId: fresh.id };
          }
          const activeId = state.activeId === id ? stories[0]!.id : state.activeId;
          return { stories, activeId };
        }),
      addCharacter: (storyId) =>
        set((state) => ({
          stories: mapStory(state.stories, storyId, (story) =>
            withTouch(story, {
              characters: [
                ...story.characters,
                {
                  id: uid(),
                  name: "New person",
                  pronouns: "they",
                  role: "",
                  desire: "",
                  fear: "",
                  voice: "",
                  age: null,
                },
              ],
            }),
          ),
        })),
      patchCharacter: (storyId, characterId, patch) =>
        set((state) => ({
          stories: mapStory(state.stories, storyId, (story) =>
            withTouch(story, {
              characters: story.characters.map((character) =>
                character.id === characterId ? { ...character, ...patch } : character,
              ),
            }),
          ),
        })),
      removeCharacter: (storyId, characterId) =>
        set((state) => ({
          stories: mapStory(state.stories, storyId, (story) =>
            withTouch(story, {
              characters: story.characters.filter((character) => character.id !== characterId),
            }),
          ),
        })),
      addPlace: (storyId) =>
        set((state) => ({
          stories: mapStory(state.stories, storyId, (story) =>
            withTouch(story, {
              places: [...story.places, { id: uid(), name: "New place", detail: "" }],
            }),
          ),
        })),
      patchPlace: (storyId, placeId, patch) =>
        set((state) => ({
          stories: mapStory(state.stories, storyId, (story) =>
            withTouch(story, {
              places: story.places.map((place) => (place.id === placeId ? { ...place, ...patch } : place)),
            }),
          ),
        })),
      removePlace: (storyId, placeId) =>
        set((state) => ({
          stories: mapStory(state.stories, storyId, (story) =>
            withTouch(story, {
              places: story.places.filter((place) => place.id !== placeId),
            }),
          ),
        })),
      addThread: (storyId) =>
        set((state) => ({
          stories: mapStory(state.stories, storyId, (story) =>
            withTouch(story, {
              threads: [...story.threads, { id: uid(), text: "", open: true }],
            }),
          ),
        })),
      patchThread: (storyId, threadId, patch) =>
        set((state) => ({
          stories: mapStory(state.stories, storyId, (story) =>
            withTouch(story, {
              threads: story.threads.map((thread) => (thread.id === threadId ? { ...thread, ...patch } : thread)),
            }),
          ),
        })),
      removeThread: (storyId, threadId) =>
        set((state) => ({
          stories: mapStory(state.stories, storyId, (story) =>
            withTouch(story, {
              threads: story.threads.filter((thread) => thread.id !== threadId),
            }),
          ),
        })),
      askMuse: (instruction, hint, echo = true) => {
        const state = get();
        const story = state.stories.find((item) => item.id === state.activeId);
        if (!story) return;
        const chapter = activeChapter(story);
        const selection = useUi.getState().selection.text;
        const avoid = story.messages
          .filter((message) => message.role === "muse")
          .slice(-3)
          .map((message) => message.text)
          .join("\n");
        const nonce = (Date.now() + story.messages.length) % 100000;
        const draft = composeMuse({
          story,
          chapterBody: chapter.body,
          selection,
          instruction,
          nonce,
          hint,
          avoid,
        });
        const userText = instruction.trim() || "Continue the scene.";
        const userMsg = {
          id: uid(),
          role: "user" as const,
          text: userText,
          insertable: false,
          instruction,
          hint,
          nonce,
        };
        const museMsg = {
          id: uid(),
          role: "muse" as const,
          text: draft.text,
          insertable: draft.insertable,
          instruction,
          hint,
          nonce: nonce + 1,
        };
        set({
          stories: mapStory(state.stories, story.id, (current) =>
            withTouch(current, {
              messages: [...current.messages, ...(echo ? [userMsg] : []), museMsg].slice(-40),
            }),
          ),
        });
        useUi.getState().setPane("muse");
      },
      insertProse: (text) => {
        const state = get();
        const story = state.stories.find((item) => item.id === state.activeId);
        if (!story) return;
        const chapter = activeChapter(story);
        const { start, end } = useUi.getState().selection;
        const body = chapter.body;
        const bounded = end > start && start >= 0 && end <= body.length;
        const next = bounded
          ? body.slice(0, start) + text + body.slice(end)
          : `${body.replace(/\s*$/, "")}${body.trim() ? "\n\n" : ""}${text}`;
        const cursor = bounded ? start + text.length : next.length;
        set({
          stories: mapStory(state.stories, story.id, (current) =>
            withTouch(current, {
              snapshots: [...current.snapshots, body].slice(-20),
              chapters: current.chapters.map((item) =>
                item.id === chapter.id ? { ...item, body: next } : item,
              ),
            }),
          ),
        });
        useUi.getState().setSelection({ start: cursor, end: cursor, text: "" });
        useUi.getState().placeCaret(cursor, cursor);
        useUi.getState().setPane("write");
        useUi.getState().setFocus(false);
      },
      undoInsert: () => {
        const state = get();
        const story = state.stories.find((item) => item.id === state.activeId);
        if (!story || !story.snapshots.length) return;
        const body = story.snapshots[story.snapshots.length - 1]!;
        const chapter = activeChapter(story);
        set({
          stories: mapStory(state.stories, story.id, (current) =>
            withTouch(current, {
              snapshots: current.snapshots.slice(0, -1),
              chapters: current.chapters.map((item) =>
                item.id === chapter.id ? { ...item, body } : item,
              ),
            }),
          ),
        });
      },
    }),
    { name: "vellum-desk-v1" },
  ),
);

export function useActiveStory(): Story | undefined {
  return useDesk((state) => state.stories.find((story) => story.id === state.activeId));
}
