/**
 * SEO Helper for dynamic Open Graph and Twitter metadata updates.
 */
let sharePrefix = localStorage.getItem('juhnkrix_share_prefix') || 'Hear this anointed word:';

export const getSharePrefix = () => sharePrefix;
export const setSharePrefix = (prefix: string) => { 
    sharePrefix = prefix; 
    localStorage.setItem('juhnkrix_share_prefix', prefix);
};

export function updateSocialMetadata(title: string, description: string, image: string, url: string) {
  // Update document title
  document.title = title;

  // Update standard meta description
  const metaDesc = document.querySelector('meta[name="description"]');
  if (metaDesc) metaDesc.setAttribute('content', description);

  // Update Open Graph tags
  const ogTitle = document.querySelector('meta[property="og:title"]');
  if (ogTitle) ogTitle.setAttribute('content', title);
  
  const ogDesc = document.querySelector('meta[property="og:description"]');
  if (ogDesc) ogDesc.setAttribute('content', description);
  
  const ogImage = document.querySelector('meta[property="og:image"]');
  if (ogImage) ogImage.setAttribute('content', image);
  
  const ogUrl = document.querySelector('meta[property="og:url"]');
  if (ogUrl) ogUrl.setAttribute('content', url);

  // Update Twitter tags
  const twitterTitle = document.querySelector('meta[name="twitter:title"]');
  if (twitterTitle) twitterTitle.setAttribute('content', title);
  
  const twitterDesc = document.querySelector('meta[name="twitter:description"]');
  if (twitterDesc) twitterDesc.setAttribute('content', description);
  
  const twitterImage = document.querySelector('meta[name="twitter:image"]');
  if (twitterImage) twitterImage.setAttribute('content', twitterImage.getAttribute('content') || image);

  console.log('[SEO] Meta tags updated for:', title);
}
