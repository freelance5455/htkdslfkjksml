import { create } from "zustand";
import { persist } from "zustand/middleware";
import { FRAMEWORKS, UPDATES, osLabel, type FileKind, type OsId } from "@/lib/eframe/catalog";

export type RecentFile = {
  id: string;
  name: string;
  path: string;
  kind: FileKind;
  size: string;
  modifiedAt: string;
  body: string;
};

export type RecentApp = {
  id: string;
  name: string;
  publisher: string;
  openedAt: string;
  running: boolean;
};

export type TrackedUpdate = "installed" | "planned";

export type BackupImage = {
  id: string;
  name: string;
  createdAt: string;
  os: OsId;
  previous: OsId | null;
  frameworks: string[];
  updates: Record<string, TrackedUpdate>;
};

export type LogEntry = {
  id: string;
  at: string;
  text: string;
};

type RecordState = {
  machineName: string;
  currentOs: OsId;
  previousOs: OsId | null;
  files: RecentFile[];
  apps: RecentApp[];
  frameworks: string[];
  updates: Record<string, TrackedUpdate>;
  backups: BackupImage[];
  log: LogEntry[];
};

type Actions = {
  rename: (name: string) => void;
  touchFile: (id: string) => void;
  addFile: (input: { name: string; kind: FileKind }) => void;
  removeFile: (id: string) => void;
  launchApp: (id: string) => void;
  quitApp: (id: string) => void;
  addApp: (name: string) => void;
  installFramework: (id: string) => void;
  removeFramework: (id: string) => void;
  trackUpdate: (id: string, state: TrackedUpdate) => void;
  clearUpdate: (id: string) => void;
  createBackup: (name: string) => void;
  deleteBackup: (id: string) => void;
  restoreBackup: (id: string) => void;
  restorePrevious: () => void;
  upgradeTo: (os: OsId, label: string) => void;
  reset: () => void;
};

export type EframeState = RecordState & Actions;

function uid(prefix: string) {
  return `${prefix}-${Math.random().toString(36).slice(2, 8)}`;
}

function frameworkName(id: string) {
  return FRAMEWORKS.find((item) => item.id === id)?.name ?? id;
}

function updateName(id: string) {
  const item = UPDATES.find((update) => update.id === id);
  return item ? `${item.kb} · ${item.title}` : id;
}

const seed: RecordState = {
  machineName: "Desk",
  currentOs: "win11",
  previousOs: "win10",
  files: [
    {
      id: "f-notes",
      name: "Quarterly notes.txt",
      path: "C:\\Users\\Public\\Documents\\Quarterly notes.txt",
      kind: "note",
      size: "4 KB",
      modifiedAt: "2026-11-08T15:00:00.000Z",
      body: "Router closet still runs the old image. Keep the Windows 10 backup until the desk finishes the 11 upgrade. Do not delete the XP recovery disc in the drawer.",
    },
    {
      id: "f-sheet",
      name: "House inventory.xlsx",
      path: "C:\\Users\\Public\\Documents\\House inventory.xlsx",
      kind: "sheet",
      size: "86 KB",
      modifiedAt: "2026-10-29T15:00:00.000Z",
      body: "Sheet: rooms, serial numbers, and which PC last opened the file. The den desktop is the one Eframe is tracking.",
    },
    {
      id: "f-photo",
      name: "Porch scan.png",
      path: "C:\\Users\\Public\\Pictures\\Porch scan.png",
      kind: "image",
      size: "2.4 MB",
      modifiedAt: "2026-09-14T15:00:00.000Z",
      body: "A flat scan of the porch, saved from Photos. No edit history beyond the crop on September 14.",
    },
    {
      id: "f-zip",
      name: "Drivers-2019.zip",
      path: "C:\\Users\\Public\\Downloads\\Drivers-2019.zip",
      kind: "archive",
      size: "140 MB",
      modifiedAt: "2019-06-02T15:00:00.000Z",
      body: "Chipset and audio drivers packed before the Windows 10 install. Leave the archive intact if you restore that system.",
    },
  ],
  apps: [
    {
      id: "explorer",
      name: "File Explorer",
      publisher: "Microsoft",
      openedAt: "2026-11-11T18:00:00.000Z",
      running: false,
    },
    {
      id: "edge",
      name: "Microsoft Edge",
      publisher: "Microsoft",
      openedAt: "2026-11-12T14:00:00.000Z",
      running: true,
    },
    {
      id: "notepad",
      name: "Notepad",
      publisher: "Microsoft",
      openedAt: "2026-11-08T15:10:00.000Z",
      running: false,
    },
    {
      id: "photos",
      name: "Photos",
      publisher: "Microsoft",
      openedAt: "2026-09-14T16:00:00.000Z",
      running: false,
    },
    {
      id: "terminal",
      name: "Terminal",
      publisher: "Microsoft",
      openedAt: "2026-08-02T12:00:00.000Z",
      running: false,
    },
    {
      id: "mail",
      name: "Mail",
      publisher: "Microsoft",
      openedAt: "2026-11-01T09:00:00.000Z",
      running: false,
    },
  ],
  frameworks: ["net481", "vcredist", "directx", "webview2"],
  updates: {},
  backups: [
    {
      id: "bk-before-11",
      name: "Before Windows 11",
      createdAt: "2025-10-20T12:00:00.000Z",
      os: "win10",
      previous: "win81",
      frameworks: ["net481", "vcredist", "directx", "webview2"],
      updates: {},
    },
  ],
  log: [
    { id: "l1", at: "2021-10-05T12:00:00.000Z", text: "Installed Windows 10 22H2." },
    { id: "l2", at: "2025-10-20T12:00:00.000Z", text: "Saved backup “Before Windows 11”." },
    { id: "l3", at: "2025-11-02T12:00:00.000Z", text: "Upgraded to Windows 11 24H2. Previous system is Windows 10." },
  ],
};

function withLog(state: RecordState, text: string): Pick<RecordState, "log"> {
  const entry: LogEntry = { id: uid("log"), at: new Date().toISOString(), text };
  return { log: [entry, ...state.log].slice(0, 16) };
}

export const useEframe = create<EframeState>()(
  persist(
    (set) => ({
      ...seed,
      rename: (name) => set({ machineName: name.trim() || "Desk" }),
      touchFile: (id) =>
        set((state) => ({
          files: state.files.map((file) =>
            file.id === id ? { ...file, modifiedAt: new Date().toISOString() } : file,
          ),
          ...withLog(state, `Opened ${state.files.find((file) => file.id === id)?.name ?? "a file"}.`),
        })),
      addFile: ({ name, kind }) =>
        set((state) => {
          const clean = name.trim() || "Untitled";
          const file: RecentFile = {
            id: uid("file"),
            name: clean,
            path: `C:\\Users\\Public\\Documents\\${clean}`,
            kind,
            size: "1 KB",
            modifiedAt: new Date().toISOString(),
            body: "Added on this PC record. Nothing has been written to a real disk.",
          };
          return { files: [file, ...state.files], ...withLog(state, `Added ${clean}.`) };
        }),
      removeFile: (id) =>
        set((state) => ({
          files: state.files.filter((file) => file.id !== id),
          ...withLog(state, `Removed ${state.files.find((file) => file.id === id)?.name ?? "a file"} from recent files.`),
        })),
      launchApp: (id) =>
        set((state) => ({
          apps: state.apps.map((app) =>
            app.id === id ? { ...app, running: true, openedAt: new Date().toISOString() } : app,
          ),
          ...withLog(state, `Launched ${state.apps.find((app) => app.id === id)?.name ?? "an app"}.`),
        })),
      quitApp: (id) =>
        set((state) => ({
          apps: state.apps.map((app) => (app.id === id ? { ...app, running: false } : app)),
          ...withLog(state, `Closed ${state.apps.find((app) => app.id === id)?.name ?? "an app"}.`),
        })),
      addApp: (name) =>
        set((state) => {
          const clean = name.trim();
          if (!clean) return state;
          const app: RecentApp = {
            id: uid("app"),
            name: clean,
            publisher: "Installed on this record",
            openedAt: new Date().toISOString(),
            running: false,
          };
          return { apps: [app, ...state.apps], ...withLog(state, `Added ${clean} to recent apps.`) };
        }),
      installFramework: (id) =>
        set((state) => ({
          frameworks: state.frameworks.includes(id) ? state.frameworks : [...state.frameworks, id],
          ...withLog(state, `Installed ${frameworkName(id)}.`),
        })),
      removeFramework: (id) =>
        set((state) => ({
          frameworks: state.frameworks.filter((item) => item !== id),
          ...withLog(state, `Removed ${frameworkName(id)}.`),
        })),
      trackUpdate: (id, status) =>
        set((state) => ({
          updates: { ...state.updates, [id]: status },
          ...withLog(
            state,
            status === "installed"
              ? `Installed ${updateName(id)}.`
              : `Saved ${updateName(id)} to the plan.`,
          ),
        })),
      clearUpdate: (id) =>
        set((state) => {
          const updates = { ...state.updates };
          delete updates[id];
          return { updates, ...withLog(state, `Cleared ${updateName(id)}.`) };
        }),
      createBackup: (name) =>
        set((state) => {
          const image: BackupImage = {
            id: uid("bk"),
            name: name.trim() || "Manual backup",
            createdAt: new Date().toISOString(),
            os: state.currentOs,
            previous: state.previousOs,
            frameworks: [...state.frameworks],
            updates: { ...state.updates },
          };
          return {
            backups: [image, ...state.backups],
            ...withLog(state, `Saved backup “${image.name}”.`),
          };
        }),
      deleteBackup: (id) =>
        set((state) => ({
          backups: state.backups.filter((backup) => backup.id !== id),
          ...withLog(state, "Deleted a backup image."),
        })),
      restoreBackup: (id) =>
        set((state) => {
          const image = state.backups.find((backup) => backup.id === id);
          if (!image) return state;
          return {
            currentOs: image.os,
            previousOs: image.previous,
            frameworks: [...image.frameworks],
            updates: { ...image.updates },
            ...withLog(state, `Restored backup “${image.name}”.`),
          };
        }),
      restorePrevious: () =>
        set((state) => {
          if (!state.previousOs) return state;
          const nextCurrent = state.previousOs;
          const nextPrevious = state.currentOs;
          return {
            currentOs: nextCurrent,
            previousOs: nextPrevious,
            ...withLog(state, `Restored ${osLabel(nextCurrent)}. ${osLabel(nextPrevious)} is now the previous system.`),
          };
        }),
      upgradeTo: (os, label) =>
        set((state) => ({
          previousOs: state.currentOs,
          currentOs: os,
          ...withLog(state, `${label}. Previous system kept for restore.`),
        })),
      reset: () => set({ ...seed, log: [...seed.log] }),
    }),
    { name: "eframe-record", skipHydration: true },
  ),
);
