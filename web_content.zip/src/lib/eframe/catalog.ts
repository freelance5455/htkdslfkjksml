export type OsId = "xp" | "vista" | "win7" | "win8" | "win81" | "win10" | "win11";

export type OsInfo = {
  id: OsId;
  name: string;
  edition: string;
  build: string;
  released: string;
  support: "Unsupported" | "ESU" | "Supported";
  note: string;
};

export const OS: Record<OsId, OsInfo> = {
  xp: {
    id: "xp",
    name: "Windows XP",
    edition: "Professional SP3",
    build: "2600",
    released: "2001",
    support: "Unsupported",
    note: "Extended support ended April 8, 2014. Microsoft later shipped a few out-of-band fixes.",
  },
  vista: {
    id: "vista",
    name: "Windows Vista",
    edition: "Service Pack 2",
    build: "6002",
    released: "2007",
    support: "Unsupported",
    note: "Extended support ended April 11, 2017.",
  },
  win7: {
    id: "win7",
    name: "Windows 7",
    edition: "Professional SP1",
    build: "7601",
    released: "2009",
    support: "Unsupported",
    note: "Extended support ended January 14, 2020. Paid ESU ended in January 2023.",
  },
  win8: {
    id: "win8",
    name: "Windows 8",
    edition: "Pro",
    build: "9200",
    released: "2012",
    support: "Unsupported",
    note: "Support ended January 12, 2016. The supported move is the update to Windows 8.1.",
  },
  win81: {
    id: "win81",
    name: "Windows 8.1",
    edition: "Pro",
    build: "9600",
    released: "2013",
    support: "Unsupported",
    note: "Extended support ended January 10, 2023.",
  },
  win10: {
    id: "win10",
    name: "Windows 10",
    edition: "22H2",
    build: "19045",
    released: "2015",
    support: "ESU",
    note: "Consumer support ended October 14, 2025. Enrolled devices can still take Extended Security Updates and some out-of-band fixes.",
  },
  win11: {
    id: "win11",
    name: "Windows 11",
    edition: "24H2",
    build: "26100",
    released: "2021",
    support: "Supported",
    note: "Current system on this record. Newer servicing builds stay on Windows 11.",
  },
};

export const OS_ORDER: OsId[] = ["xp", "vista", "win7", "win8", "win81", "win10", "win11"];
export const UPDATE_OS: OsId[] = ["xp", "vista", "win7", "win8", "win81", "win10"];

export function osLabel(id: OsId) {
  const os = OS[id];
  return `${os.name} ${os.edition}`;
}

export type Framework = {
  id: string;
  name: string;
  version: string;
  publisher: string;
  size: string;
  summary: string;
  supports: OsId[];
};

const FROM_XP: OsId[] = ["xp", "vista", "win7", "win8", "win81", "win10", "win11"];
const FROM_7: OsId[] = ["win7", "win8", "win81", "win10", "win11"];
const FROM_10: OsId[] = ["win10", "win11"];

export const FRAMEWORKS: Framework[] = [
  {
    id: "net40",
    name: ".NET Framework 4.0",
    version: "4.0",
    publisher: "Microsoft",
    size: "48 MB",
    summary: "Last .NET Framework release that still installs on Windows XP. Many older line-of-business apps ask for it.",
    supports: FROM_XP,
  },
  {
    id: "net481",
    name: ".NET Framework 4.8.1",
    version: "4.8.1",
    publisher: "Microsoft",
    size: "74 MB",
    summary: "Final .NET Framework. Desktop apps that were never moved to modern .NET still need it. Not for XP or Vista.",
    supports: FROM_7,
  },
  {
    id: "net8",
    name: ".NET Desktop Runtime 8",
    version: "8.0",
    publisher: "Microsoft",
    size: "56 MB",
    summary: "Runtime for modern .NET desktop apps. .NET 8 reached end of support on November 10, 2026.",
    supports: FROM_10,
  },
  {
    id: "net9",
    name: ".NET Runtime 9",
    version: "9.0",
    publisher: "Microsoft",
    size: "52 MB",
    summary: ".NET 9 also reached end of support on November 10, 2026. Keep it only for apps that still require that exact runtime.",
    supports: FROM_10,
  },
  {
    id: "vcredist",
    name: "Visual C++ 2015–2022",
    version: "14.44",
    publisher: "Microsoft",
    size: "24 MB",
    summary: "Shared libraries for programs built with Visual Studio 2015 through 2022.",
    supports: FROM_7,
  },
  {
    id: "vc2010",
    name: "Visual C++ 2010",
    version: "10.0 SP1",
    publisher: "Microsoft",
    size: "11 MB",
    summary: "Older redistributable still required by some XP-era installers and hardware tools.",
    supports: FROM_XP,
  },
  {
    id: "directx",
    name: "DirectX End-User Runtime",
    version: "June 2010",
    publisher: "Microsoft",
    size: "96 MB",
    summary: "Legacy DirectX 9.0c components. Windows 10 and 11 already include DirectX 12; older games still look for this pack.",
    supports: FROM_XP,
  },
  {
    id: "webview2",
    name: "WebView2 Runtime",
    version: "Evergreen",
    publisher: "Microsoft",
    size: "138 MB",
    summary: "Embedded Edge engine used by many desktop apps. Evergreen updates itself while the OS can still reach Microsoft.",
    supports: ["win7", "win81", "win10", "win11"],
  },
  {
    id: "winappsdk",
    name: "Windows App SDK",
    version: "1.6",
    publisher: "Microsoft",
    size: "42 MB",
    summary: "WinUI 3 and related APIs. Requires Windows 10 or Windows 11.",
    supports: FROM_10,
  },
  {
    id: "xps",
    name: "XPS document components",
    version: "1.0",
    publisher: "Microsoft",
    size: "8 MB",
    summary: "Opens XPS files. Optional on Windows 10 and 11, where the feature is often off by default.",
    supports: ["win7", "win8", "win81", "win10", "win11"],
  },
];

export type UpdatePkg = {
  id: string;
  os: OsId;
  kb: string;
  title: string;
  released: string;
  severity: "Critical" | "Important" | "Servicing";
  summary: string;
};

export const UPDATES: UpdatePkg[] = [
  {
    id: "xp-sp3",
    os: "xp",
    kb: "KB936929",
    title: "Windows XP Service Pack 3",
    released: "April 2008",
    severity: "Servicing",
    summary: "The last service pack. Later out-of-band fixes expect this base.",
  },
  {
    id: "xp-ms17",
    os: "xp",
    kb: "KB4012598",
    title: "MS17-010 SMB security update",
    released: "May 2017",
    severity: "Critical",
    summary:
      "Out-of-band fix for the SMB vulnerability used by WannaCry. Microsoft published it for Windows XP after that system was already unsupported.",
  },
  {
    id: "xp-bluekeep",
    os: "xp",
    kb: "KB4500331",
    title: "Remote Desktop Services (BlueKeep)",
    released: "May 2019",
    severity: "Critical",
    summary:
      "Out-of-band fix for CVE-2019-0708. Microsoft shipped it for Windows XP and Windows Server 2003, which were out of support.",
  },
  {
    id: "vista-sp2",
    os: "vista",
    kb: "KB948465",
    title: "Windows Vista Service Pack 2",
    released: "May 2009",
    severity: "Servicing",
    summary: "Last service pack for Vista. Required before the later security-only fixes.",
  },
  {
    id: "vista-ms17",
    os: "vista",
    kb: "KB4012598",
    title: "MS17-010 SMB security update",
    released: "May 2017",
    severity: "Critical",
    summary: "Same out-of-band WannaCry fix, packaged for Windows Vista after its end of support.",
  },
  {
    id: "win7-ssu",
    os: "win7",
    kb: "KB4490628",
    title: "Servicing stack update",
    released: "March 2019",
    severity: "Servicing",
    summary: "Lets Windows 7 install later SHA-2 signed packages. Install this before newer rollups.",
  },
  {
    id: "win7-sha2",
    os: "win7",
    kb: "KB4474419",
    title: "SHA-2 code signing support",
    released: "March 2019",
    severity: "Important",
    summary: "Adds SHA-2 signing support so Windows Update can still trust packages after Microsoft dropped SHA-1.",
  },
  {
    id: "win7-ssu2",
    os: "win7",
    kb: "KB4484071",
    title: "Servicing stack update",
    released: "January 2019",
    severity: "Servicing",
    summary: "Earlier servicing stack that belongs in the same sequence as KB4474419 and KB4490628.",
  },
  {
    id: "win81-update",
    os: "win81",
    kb: "KB2919355",
    title: "Windows 8.1 Update",
    released: "April 2014",
    severity: "Important",
    summary: "The required Windows 8.1 Update. Later rollups will not install without it.",
  },
  {
    id: "win10-emudhra",
    os: "win10",
    kb: "KB5134125",
    title: "Distrust compromised eMudhra certificates",
    released: "October 26, 2026",
    severity: "Important",
    summary:
      "Out-of-band update for Windows 10 21H2 and 22H2. It removes trust in compromised certificate hierarchies on PCs that do not get automatic certificate updates.",
  },
  {
    id: "win10-certs-2027",
    os: "win10",
    kb: "Servicing note",
    title: "Update certificates expire in 2027",
    released: "October 2026",
    severity: "Servicing",
    summary:
      "Microsoft has said update-signing certificates expire on May 17, 2027 and June 19, 2027. After that, unsupported Windows can no longer use Windows Update. Windows 10 on a still-serviced or ESU channel needs the July 2026 security update or later before June 19, 2027.",
  },
];

export type UpgradePath = {
  id: string;
  from: OsId;
  to: OsId;
  kind: "In place" | "Clean install";
  title: string;
  detail: string;
  needsMemory: boolean;
  needsTpm: boolean;
};

export const UPGRADES: UpgradePath[] = [
  {
    id: "xp-7",
    from: "xp",
    to: "win7",
    kind: "Clean install",
    title: "Install Windows 7",
    detail: "Windows 7 setup does not upgrade XP in place. Programs have to be installed again on a real PC.",
    needsMemory: false,
    needsTpm: false,
  },
  {
    id: "xp-10",
    from: "xp",
    to: "win10",
    kind: "Clean install",
    title: "Install Windows 10",
    detail: "There is no direct upgrade from XP. Copy files off the PC before a real install.",
    needsMemory: true,
    needsTpm: false,
  },
  {
    id: "vista-7",
    from: "vista",
    to: "win7",
    kind: "In place",
    title: "Upgrade to Windows 7",
    detail: "Windows 7 supports an in-place upgrade from Vista when the language and edition match.",
    needsMemory: false,
    needsTpm: false,
  },
  {
    id: "7-10",
    from: "win7",
    to: "win10",
    kind: "In place",
    title: "Upgrade to Windows 10",
    detail: "In-place upgrade can keep files. Match edition and language on the real installer.",
    needsMemory: true,
    needsTpm: false,
  },
  {
    id: "7-11",
    from: "win7",
    to: "win11",
    kind: "Clean install",
    title: "Install Windows 11",
    detail: "Windows 11 has no in-place upgrade from Windows 7.",
    needsMemory: true,
    needsTpm: true,
  },
  {
    id: "8-81",
    from: "win8",
    to: "win81",
    kind: "In place",
    title: "Update to Windows 8.1",
    detail: "The supported step off Windows 8. Later upgrade paths start at 8.1.",
    needsMemory: false,
    needsTpm: false,
  },
  {
    id: "81-10",
    from: "win81",
    to: "win10",
    kind: "In place",
    title: "Upgrade to Windows 10",
    detail: "In-place upgrade from Windows 8.1.",
    needsMemory: true,
    needsTpm: false,
  },
  {
    id: "10-11",
    from: "win10",
    to: "win11",
    kind: "In place",
    title: "Upgrade to Windows 11",
    detail: "In-place when the PC has a supported processor, TPM 2.0, and Secure Boot.",
    needsMemory: true,
    needsTpm: true,
  },
];

export type FileKind = "note" | "sheet" | "image" | "archive";

export function formatWhen(iso: string) {
  const date = new Date(iso);
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${months[date.getUTCMonth()]} ${date.getUTCDate()}, ${date.getUTCFullYear()}`;
}
