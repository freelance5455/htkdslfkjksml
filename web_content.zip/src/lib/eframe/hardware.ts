export type Hardware = {
  cores: number;
  memoryGb: number | null;
  platform: string;
  architecture: string;
  bitness: string;
  model: string;
  platformVersion: string;
  brands: string;
  ua: string;
  screen: string;
  dpr: number;
  colorDepth: number;
  languages: string;
  timezone: string;
  touch: number;
  online: boolean;
  link: string | null;
};

export async function readHardware(): Promise<Hardware> {
  const nav = navigator as Navigator & {
    deviceMemory?: number;
    userAgentData?: {
      platform?: string;
      brands?: { brand: string; version: string }[];
      getHighEntropyValues?: (hints: string[]) => Promise<{
        architecture?: string;
        bitness?: string;
        model?: string;
        platformVersion?: string;
      }>;
    };
    connection?: { downlink?: number; effectiveType?: string };
  };

  let architecture = "Not reported";
  let bitness = "";
  let model = "";
  let platformVersion = "";
  try {
    const high = await nav.userAgentData?.getHighEntropyValues?.([
      "architecture",
      "bitness",
      "model",
      "platformVersion",
    ]);
    if (high?.architecture) architecture = high.architecture;
    if (high?.bitness) bitness = high.bitness;
    if (high?.model) model = high.model;
    if (high?.platformVersion) platformVersion = high.platformVersion;
  } catch {
    architecture = "Not reported";
  }

  const downlink = nav.connection?.downlink;
  const effective = nav.connection?.effectiveType;
  const link =
    downlink != null || effective
      ? [effective, downlink != null ? `${downlink} Mb/s` : null].filter(Boolean).join(" · ")
      : null;

  return {
    cores: nav.hardwareConcurrency || 0,
    memoryGb: typeof nav.deviceMemory === "number" ? nav.deviceMemory : null,
    platform: nav.userAgentData?.platform || nav.platform || "Unknown",
    architecture,
    bitness,
    model,
    platformVersion,
    brands: nav.userAgentData?.brands?.map((brand) => `${brand.brand} ${brand.version}`).join(", ") ?? "",
    ua: nav.userAgent,
    screen: `${window.screen.width} × ${window.screen.height}`,
    dpr: window.devicePixelRatio || 1,
    colorDepth: window.screen.colorDepth,
    languages: nav.languages?.join(", ") || nav.language || "Unknown",
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || "Unknown",
    touch: nav.maxTouchPoints || 0,
    online: nav.onLine,
    link,
  };
}
