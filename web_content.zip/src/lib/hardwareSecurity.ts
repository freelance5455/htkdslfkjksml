/**
 * JUHNKRIX MUSIKA - Hardware-Bound Security & Anti-Farm Protection Engine
 * 
 * Verifies a unique, cryptographic device fingerprint against the user's local storage
 * before enabling high-intensity JMC hash mining (100,000 HashRate/s).
 * Strictly prevents unauthorized hardware farm automation, botnets, and multi-instance spoofing.
 */

export interface HardwareFingerprintData {
  fingerprint: string;
  cores: number;
  memoryGb: number;
  screenResolution: string;
  platform: string;
  webGlRenderer: string;
  boundAt: string;
  status: 'VERIFIED' | 'FARM_BLOCKED' | 'PENDING';
  intensityAuthorized: 'HIGH_SPEED_100K' | 'STANDARD_MOBILE';
}

const HARDWARE_STORAGE_KEY = 'jm_hardware_bound_fingerprint';
const HARDWARE_AUDIT_LOG_KEY = 'jm_hardware_security_audit_log';

/**
 * Collects low-level hardware characteristics to build a tamper-resistant device fingerprint
 */
export async function generateDeviceHardwareFingerprint(): Promise<string> {
  if (typeof window === 'undefined') return 'JMC-HW-DEFAULT-NODE';

  const screenRes = `${window.screen?.width || 0}x${window.screen?.height || 0}x${window.screen?.colorDepth || 24}`;
  const cores = navigator.hardwareConcurrency || 4;
  const memory = (navigator as any).deviceMemory || 4;
  const platform = navigator.platform || 'unknown';
  const userAgent = navigator.userAgent || 'unknown';
  const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';

  // Extract WebGL unmasked GPU renderer info
  let webGlRenderer = 'Standard-Hardware-Renderer';
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    if (gl) {
      const debugInfo = (gl as any).getExtension('WEBGL_debug_renderer_info');
      if (debugInfo) {
        webGlRenderer = (gl as any).getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) || 'WebGL-GPU';
      }
    }
  } catch (e) {
    // Ignore canvas fallback
  }

  // Combine raw hardware traits
  const rawData = `${screenRes}|${cores}|${memory}|${platform}|${timezone}|${webGlRenderer}|JUHNKRIX-ALTAR-DECENTRALIZED-MINER`;

  // Compute SHA-256 cryptographic digest
  try {
    if (window.crypto && window.crypto.subtle) {
      const msgBuffer = new TextEncoder().encode(rawData);
      const hashBuffer = await window.crypto.subtle.digest('SHA-256', msgBuffer);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('').toUpperCase();
      return `JMC-HW-${hashHex.slice(0, 12)}-${cores}C-${memory}G`;
    }
  } catch (e) {
    // Fallback if subtle crypto is restricted
  }

  // Deterministic fallback hash
  let hash = 0;
  for (let i = 0; i < rawData.length; i++) {
    hash = ((hash << 5) - hash) + rawData.charCodeAt(i);
    hash |= 0;
  }
  const hex = Math.abs(hash).toString(16).padStart(8, '0').toUpperCase();
  return `JMC-HW-${hex}-777-${cores}C`;
}

/**
 * Verifies or registers the unique device fingerprint in local storage
 */
export async function verifyHardwareBoundStatus(): Promise<{
  isValid: boolean;
  fingerprint: string;
  data: HardwareFingerprintData;
  message: string;
}> {
  const currentFingerprint = await generateDeviceHardwareFingerprint();
  const cores = navigator.hardwareConcurrency || 4;
  const memory = (navigator as any).deviceMemory || 4;
  const screenResolution = `${window.screen?.width || 0}x${window.screen?.height || 0}`;
  const platform = navigator.platform || 'Universal';

  let webGlRenderer = 'GPU-Core';
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl');
    if (gl) {
      const ext = (gl as any).getExtension('WEBGL_debug_renderer_info');
      if (ext) webGlRenderer = (gl as any).getParameter(ext.UNMASKED_RENDERER_WEBGL) || 'GPU';
    }
  } catch (e) {}

  const storedJson = localStorage.getItem(HARDWARE_STORAGE_KEY);

  if (!storedJson) {
    // First-time authorization: Bind this physical device
    const newBinding: HardwareFingerprintData = {
      fingerprint: currentFingerprint,
      cores,
      memoryGb: memory,
      screenResolution,
      platform,
      webGlRenderer,
      boundAt: new Date().toISOString(),
      status: 'VERIFIED',
      intensityAuthorized: 'HIGH_SPEED_100K'
    };

    localStorage.setItem(HARDWARE_STORAGE_KEY, JSON.stringify(newBinding));
    logHardwareSecurityEvent('HARDWARE_BOUND_INITIALIZED', currentFingerprint, 'Physical device securely bound as 1-to-1 Altar Miner.');

    return {
      isValid: true,
      fingerprint: currentFingerprint,
      data: newBinding,
      message: 'Physical device successfully registered and hardware-bound to JM-CRYPTO node.'
    };
  }

  try {
    const storedBinding: HardwareFingerprintData = JSON.parse(storedJson);

    // Validate fingerprint matches registered physical hardware
    if (storedBinding.fingerprint === currentFingerprint) {
      return {
        isValid: true,
        fingerprint: currentFingerprint,
        data: storedBinding,
        message: 'Hardware fingerprint verified: Authorized single-device mining engagement confirmed.'
      };
    } else {
      // Possible multi-device clone or unauthorized hardware farm instance!
      logHardwareSecurityEvent(
        'HARDWARE_FARM_MISMATCH_BLOCKED',
        currentFingerprint,
        `Device signature (${currentFingerprint}) does not match authorized bound hardware (${storedBinding.fingerprint}). High-intensity mining locked.`
      );

      return {
        isValid: false,
        fingerprint: currentFingerprint,
        data: {
          ...storedBinding,
          status: 'FARM_BLOCKED'
        },
        message: 'Security Alert: Device signature mismatch! High-intensity mining restricted to prevent unauthorized hardware farm usage.'
      };
    }
  } catch (e) {
    // If parse error, re-bind securely
    const newBinding: HardwareFingerprintData = {
      fingerprint: currentFingerprint,
      cores,
      memoryGb: memory,
      screenResolution,
      platform,
      webGlRenderer,
      boundAt: new Date().toISOString(),
      status: 'VERIFIED',
      intensityAuthorized: 'HIGH_SPEED_100K'
    };
    localStorage.setItem(HARDWARE_STORAGE_KEY, JSON.stringify(newBinding));
    return {
      isValid: true,
      fingerprint: currentFingerprint,
      data: newBinding,
      message: 'Hardware-bound binding refreshed.'
    };
  }
}

/**
 * Re-binds or resets device authorization (e.g., when owner explicitly re-authorizes)
 */
export async function resetDeviceHardwareBinding(): Promise<HardwareFingerprintData> {
  const currentFingerprint = await generateDeviceHardwareFingerprint();
  const binding: HardwareFingerprintData = {
    fingerprint: currentFingerprint,
    cores: navigator.hardwareConcurrency || 4,
    memoryGb: (navigator as any).deviceMemory || 4,
    screenResolution: `${window.screen?.width || 0}x${window.screen?.height || 0}`,
    platform: navigator.platform || 'Universal',
    webGlRenderer: 'GPU-Core',
    boundAt: new Date().toISOString(),
    status: 'VERIFIED',
    intensityAuthorized: 'HIGH_SPEED_100K'
  };

  localStorage.setItem(HARDWARE_STORAGE_KEY, JSON.stringify(binding));
  logHardwareSecurityEvent('HARDWARE_REBOUND', currentFingerprint, 'Device fingerprint re-authenticated.');
  return binding;
}

/**
 * Logs security and anti-farm events into local audit storage
 */
export function logHardwareSecurityEvent(eventType: string, deviceId: string, details: string) {
  try {
    const logs = JSON.parse(localStorage.getItem(HARDWARE_AUDIT_LOG_KEY) || '[]');
    const newEntry = {
      id: `SEC-${Date.now()}`,
      timestamp: new Date().toISOString(),
      eventType,
      deviceId,
      details,
      ipNode: '127.0.0.1:3000'
    };
    logs.unshift(newEntry);
    localStorage.setItem(HARDWARE_AUDIT_LOG_KEY, JSON.stringify(logs.slice(0, 30)));
  } catch (e) {
    // Ignore logging failure
  }
}
