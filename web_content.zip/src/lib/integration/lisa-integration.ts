import { useAppStore } from "@/lib/store";
import type { CallRecord, CallSummary, LisaEvent, TakenMessage } from "@/lib/types";

/**
 * LisaIntegrationService
 *
 * On Android this is a bound, non-exported service talking only to
 * `com.lisa.assistant`, protected by a signature permission. Nothing here is a
 * public ContentProvider or exported receiver.
 *
 * In this app the same contract is local: the Lisa assistant would request
 * last call / summary / messages, and receive events as they happen.
 */
export const LisaIntegrationService = {
  isEnabled(): boolean {
    return useAppStore.getState().settings.lisaIntegrationEnabled;
  },

  lastCall(): CallRecord | undefined {
    return useAppStore.getState().calls[0];
  },

  lastCaller(): { name: string; number: string } | undefined {
    const call = this.lastCall();
    if (!call) return undefined;
    return { name: call.name, number: call.number };
  },

  lastSummary(): CallSummary | undefined {
    return useAppStore.getState().summaries[0];
  },

  messages(): TakenMessage[] {
    return useAppStore.getState().messages;
  },

  importantCalls(): CallRecord[] {
    return useAppStore.getState().calls.filter((c) => c.important || c.emergency);
  },

  history(): CallRecord[] {
    return useAppStore.getState().calls;
  },

  events(): LisaEvent[] {
    return useAppStore.getState().events;
  },
};
