export const LANGUAGE_WEIGHT: Record<string, number> = {
  javascript: 1,
  python: 2,
  bash: 3,
};

/** Plan threshold: score = compact id × language weight. */
export const SCORE_LIMIT = 1_000_000_000;

export const ALLOWED_SOURCES = ["trusted@example.com"] as const;

export type DeskMessage = {
  id: string;
  compactId: number;
  source: string;
  recipient: string;
  content: string;
  at: number;
};

export const SEED_MESSAGES: DeskMessage[] = [
  {
    id: "448140000",
    compactId: 448140000,
    source: "trusted@example.com",
    recipient: "user1",
    content: "Shift the Unix second two bits right. That number is the file name.",
    at: 448140000 * 4,
  },
  {
    id: "448140080",
    compactId: 448140080,
    source: "trusted@example.com",
    recipient: "user1",
    content: "JavaScript weighs 1, Python 2, Bash 3. A heavier weight fails the gate first.",
    at: 448140080 * 4,
  },
  {
    id: "448139900",
    compactId: 448139900,
    source: "trusted@example.com",
    recipient: "ops",
    content: "Ops keeps its own folder. Same clock, different recipient.",
    at: 448139900 * 4,
  },
];

/** Unsigned floor-divide by 4 — the arithmetic of `shr rax, 2`. */
export function shr2(n: number): number {
  if (!Number.isFinite(n) || n < 0) return 0;
  return Math.floor(n / 4);
}

export function unixSeconds(ms = Date.now()): number {
  return Math.floor(ms / 1000);
}

/** Seconds until the compact id changes. A right shift by 2 holds for 4 seconds. */
export function windowRemain(sec: number): number {
  const mod = ((sec % 4) + 4) % 4;
  return 4 - mod;
}

/** MSB-first bits. */
export function bitsFrom(n: number, width: number): number[] {
  const bits: number[] = [];
  let x = Math.floor(Math.max(0, n));
  for (let i = 0; i < width; i++) {
    bits.push(x % 2);
    x = Math.floor(x / 2);
  }
  return bits.reverse();
}

export function formatDec(n: number): string {
  return Math.floor(n).toLocaleString("en-US");
}

export function formatHex(n: number): string {
  return `0x${Math.floor(Math.max(0, n)).toString(16).toUpperCase()}`;
}

export function parseBlock(raw: string): { keyword: string; content: string } | null {
  const text = raw.replace(/\r\n/g, "\n").trim();
  const match = text.match(/^\[([a-zA-Z]+)\]([\s\S]*)$/);
  if (!match) return null;
  let content = match[2].replace(/^\n/, "");
  content = content.replace(/\nEOF\s*$/, "");
  return { keyword: match[1].toLowerCase(), content: content.trim() };
}

export function weightFor(keyword: string): number | null {
  return LANGUAGE_WEIGHT[keyword] ?? null;
}

export function priorityScore(baseId: number, keyword: string): number | null {
  const weight = weightFor(keyword);
  if (weight === null) return null;
  return baseId * weight;
}

export function gateDecision(score: number | null): "granted" | "denied" | "unknown" {
  if (score === null) return "unknown";
  return score <= SCORE_LIMIT ? "granted" : "denied";
}

export function fileId(compact: number, taken: string[]): string {
  if (!taken.includes(String(compact))) return String(compact);
  let n = 2;
  while (taken.includes(`${compact}-${n}`)) n += 1;
  return `${compact}-${n}`;
}

export function isDeskMessage(value: unknown): value is DeskMessage {
  if (!value || typeof value !== "object") return false;
  const m = value as Partial<DeskMessage>;
  return (
    typeof m.id === "string" &&
    typeof m.compactId === "number" &&
    typeof m.source === "string" &&
    typeof m.recipient === "string" &&
    typeof m.content === "string" &&
    typeof m.at === "number"
  );
}
