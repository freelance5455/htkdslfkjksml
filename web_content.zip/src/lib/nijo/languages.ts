import { StreamLanguage } from "@codemirror/language";
import { javascript } from "@codemirror/lang-javascript";
import { html } from "@codemirror/lang-html";
import { css } from "@codemirror/lang-css";
import { python } from "@codemirror/lang-python";
import { json } from "@codemirror/lang-json";
import { markdown } from "@codemirror/lang-markdown";
import { xml } from "@codemirror/lang-xml";
import { sql } from "@codemirror/lang-sql";
import { php } from "@codemirror/lang-php";
import { java } from "@codemirror/lang-java";
import { cpp } from "@codemirror/lang-cpp";
import { rust } from "@codemirror/lang-rust";
import { go } from "@codemirror/lang-go";
import { dart, kotlin, csharp, c } from "@codemirror/legacy-modes/mode/clike";
import { swift } from "@codemirror/legacy-modes/mode/swift";
import { ruby } from "@codemirror/legacy-modes/mode/ruby";
import { lua } from "@codemirror/legacy-modes/mode/lua";
import { r } from "@codemirror/legacy-modes/mode/r";
import type { Extension } from "@codemirror/state";
import type { LanguageId, OutputMode } from "./types";
import { extOf } from "@/lib/utils";

export interface LanguageMeta {
  id: LanguageId;
  label: string;
  group: "Web" | "Mobile" | "General" | "Data" | "Other";
  extensions: string[];
  output: OutputMode;
  unavailableReason?: string;
}

export const LANGUAGES: LanguageMeta[] = [
  { id: "auto", label: "Auto Detect", group: "Other", extensions: [], output: "unavailable" },
  { id: "html", label: "HTML", group: "Web", extensions: ["html", "htm"], output: "preview" },
  { id: "css", label: "CSS", group: "Web", extensions: ["css"], output: "preview" },
  { id: "javascript", label: "JavaScript", group: "Web", extensions: ["js", "mjs", "cjs"], output: "console" },
  { id: "typescript", label: "TypeScript", group: "Web", extensions: ["ts", "mts"], output: "console" },
  {
    id: "react",
    label: "React",
    group: "Web",
    extensions: ["jsx", "tsx"],
    output: "unavailable",
    unavailableReason: "React needs a bundler. Use HTML + JavaScript for in-browser preview.",
  },
  {
    id: "vue",
    label: "Vue",
    group: "Web",
    extensions: ["vue"],
    output: "unavailable",
    unavailableReason: "Vue single-file components cannot run in this browser sandbox.",
  },
  {
    id: "svelte",
    label: "Svelte",
    group: "Web",
    extensions: ["svelte"],
    output: "unavailable",
    unavailableReason: "Svelte requires a compiler that is not available here.",
  },
  {
    id: "dart",
    label: "Dart",
    group: "Mobile",
    extensions: ["dart"],
    output: "unavailable",
    unavailableReason: "Dart VM is not available in this browser.",
  },
  {
    id: "flutter",
    label: "Flutter",
    group: "Mobile",
    extensions: ["dart"],
    output: "unavailable",
    unavailableReason: "Flutter SDK is not available in this browser.",
  },
  {
    id: "kotlin",
    label: "Kotlin",
    group: "Mobile",
    extensions: ["kt", "kts"],
    output: "unavailable",
    unavailableReason: "Kotlin compiler is not available in this browser.",
  },
  {
    id: "java",
    label: "Java",
    group: "Mobile",
    extensions: ["java"],
    output: "unavailable",
    unavailableReason: "Java runtime is not available in this browser.",
  },
  {
    id: "swift",
    label: "Swift",
    group: "Mobile",
    extensions: ["swift"],
    output: "unavailable",
    unavailableReason: "Swift compiler is not available in this browser.",
  },
  {
    id: "react-native",
    label: "React Native",
    group: "Mobile",
    extensions: ["jsx", "tsx"],
    output: "unavailable",
    unavailableReason: "React Native cannot run inside a mobile browser sandbox.",
  },
  { id: "python", label: "Python", group: "General", extensions: ["py"], output: "console" },
  {
    id: "c",
    label: "C",
    group: "General",
    extensions: ["c", "h"],
    output: "unavailable",
    unavailableReason: "A C compiler is not available in this browser.",
  },
  {
    id: "cpp",
    label: "C++",
    group: "General",
    extensions: ["cpp", "cc", "cxx", "hpp"],
    output: "unavailable",
    unavailableReason: "A C++ compiler is not available in this browser.",
  },
  {
    id: "csharp",
    label: "C#",
    group: "General",
    extensions: ["cs"],
    output: "unavailable",
    unavailableReason: ".NET runtime is not available in this browser.",
  },
  {
    id: "go",
    label: "Go",
    group: "General",
    extensions: ["go"],
    output: "unavailable",
    unavailableReason: "Go toolchain is not available in this browser.",
  },
  {
    id: "rust",
    label: "Rust",
    group: "General",
    extensions: ["rs"],
    output: "unavailable",
    unavailableReason: "Rust compiler is not available in this browser.",
  },
  {
    id: "ruby",
    label: "Ruby",
    group: "General",
    extensions: ["rb"],
    output: "unavailable",
    unavailableReason: "Ruby interpreter is not available in this browser.",
  },
  { id: "php", label: "PHP", group: "General", extensions: ["php"], output: "unavailable", unavailableReason: "PHP runtime is not available in this browser." },
  {
    id: "lua",
    label: "Lua",
    group: "General",
    extensions: ["lua"],
    output: "unavailable",
    unavailableReason: "Lua runtime is not available in this browser.",
  },
  {
    id: "r",
    label: "R",
    group: "General",
    extensions: ["r"],
    output: "unavailable",
    unavailableReason: "R runtime is not available in this browser.",
  },
  { id: "sql", label: "SQL", group: "Data", extensions: ["sql"], output: "formatted" },
  { id: "json", label: "JSON", group: "Data", extensions: ["json"], output: "formatted" },
  { id: "xml", label: "XML", group: "Data", extensions: ["xml"], output: "formatted" },
  { id: "markdown", label: "Markdown", group: "Data", extensions: ["md", "markdown"], output: "markdown" },
  { id: "svg", label: "SVG", group: "Data", extensions: ["svg"], output: "svg" },
  { id: "plaintext", label: "Plain text", group: "Other", extensions: ["txt"], output: "unavailable" },
  { id: "image", label: "Image", group: "Other", extensions: ["png", "jpg", "jpeg", "gif", "webp"], output: "image" },
];

export const OPEN_ACCEPT = [
  ".html",
  ".htm",
  ".css",
  ".js",
  ".ts",
  ".jsx",
  ".tsx",
  ".py",
  ".dart",
  ".java",
  ".kt",
  ".c",
  ".cpp",
  ".h",
  ".cs",
  ".php",
  ".rb",
  ".go",
  ".rs",
  ".swift",
  ".json",
  ".xml",
  ".md",
  ".svg",
  ".vue",
  ".svelte",
  ".sql",
  ".lua",
  ".txt",
  ".zip",
].join(",");

const EXT_MAP: Record<string, LanguageId> = {};
for (const lang of LANGUAGES) {
  if (lang.id === "auto" || lang.id === "flutter" || lang.id === "react-native") continue;
  for (const ext of lang.extensions) {
    if (!EXT_MAP[ext]) EXT_MAP[ext] = lang.id;
  }
}

export function languageById(id: LanguageId): LanguageMeta {
  return LANGUAGES.find((l) => l.id === id) ?? LANGUAGES[LANGUAGES.length - 2]!;
}

export function languageFromExtension(path: string): LanguageId {
  const ext = extOf(path);
  return EXT_MAP[ext] ?? "plaintext";
}

export function languageExtension(id: LanguageId): Extension[] {
  switch (id) {
    case "html":
      return [html()];
    case "css":
      return [css()];
    case "javascript":
    case "vue":
    case "svelte":
      return [javascript()];
    case "typescript":
      return [javascript({ typescript: true })];
    case "react":
    case "react-native":
      return [javascript({ jsx: true, typescript: true })];
    case "python":
      return [python()];
    case "json":
      return [json()];
    case "markdown":
      return [markdown()];
    case "xml":
    case "svg":
      return [xml()];
    case "sql":
      return [sql()];
    case "php":
      return [php()];
    case "java":
      return [java()];
    case "cpp":
      return [cpp()];
    case "c":
      return [StreamLanguage.define(c)];
    case "rust":
      return [rust()];
    case "go":
      return [go()];
    case "dart":
    case "flutter":
      return [StreamLanguage.define(dart)];
    case "kotlin":
      return [StreamLanguage.define(kotlin)];
    case "csharp":
      return [StreamLanguage.define(csharp)];
    case "swift":
      return [StreamLanguage.define(swift)];
    case "ruby":
      return [StreamLanguage.define(ruby)];
    case "lua":
      return [StreamLanguage.define(lua)];
    case "r":
      return [StreamLanguage.define(r)];
    default:
      return [];
  }
}

export function groupedLanguages(): { group: LanguageMeta["group"]; items: LanguageMeta[] }[] {
  const order: LanguageMeta["group"][] = ["Web", "Mobile", "General", "Data", "Other"];
  return order
    .map((group) => ({
      group,
      items: LANGUAGES.filter((l) => l.group === group && l.id !== "image"),
    }))
    .filter((g) => g.items.length > 0);
}
