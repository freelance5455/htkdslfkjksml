import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { AI_HOURLY_CAP, AI_MAX_CODE_CHARS, AI_MAX_TOKENS } from "./limits";

const TASKS = ["explain", "fix", "optimize", "convert", "generate"] as const;
export type AiTask = (typeof TASKS)[number];

const inputSchema = z.object({
  task: z.enum(TASKS),
  code: z.string().max(AI_MAX_CODE_CHARS),
  language: z.string().max(40),
  prompt: z.string().max(500).optional(),
});

const SYSTEM = `You are the NIJO MOBILE coding assistant by Bouzidi Softworks.
Help people write and understand code on a phone. Be concise, accurate, and practical.
If you change code, return a fenced block with the full updated file when it is short, otherwise a focused patch.
Never invent runtime output. If you are unsure, say so.`;

function userMessage(data: z.infer<typeof inputSchema>): string {
  const ask =
    data.prompt?.trim() ||
    {
      explain: "Explain this code clearly.",
      fix: "Find and fix errors in this code.",
      optimize: "Optimize this code and explain the changes briefly.",
      convert: "Convert this code as requested, or to JavaScript if no target is given.",
      generate: "Generate the requested code.",
    }[data.task];
  return `${ask}\n\nLanguage: ${data.language}\n\nCode:\n\`\`\`\n${data.code}\n\`\`\``;
}

export const askNijoAssistant = createServerFn({ method: "POST" })
  .validator(inputSchema)
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return { ok: false as const, error: "AI assistant is not available in this environment." };
    }
    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: AI_MAX_TOKENS,
        messages: [
          { role: "system", content: SYSTEM },
          { role: "user", content: userMessage(data) },
        ],
      }),
    });
    if (!res.ok) {
      return { ok: false as const, error: "The assistant could not complete that request." };
    }
    const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    const text = body.choices?.[0]?.message?.content?.trim() ?? "";
    if (!text) return { ok: false as const, error: "The assistant returned an empty reply." };
    return { ok: true as const, text };
  });

const hourKey = "nijo-ai-hour";

export function canCallAssistant(): { ok: true } | { ok: false; error: string } {
  if (typeof window === "undefined") return { ok: false, error: "Unavailable" };
  try {
    const raw = localStorage.getItem(hourKey);
    const now = Date.now();
    const parsed = raw ? (JSON.parse(raw) as { start: number; count: number }) : { start: now, count: 0 };
    if (now - parsed.start > 60 * 60 * 1000) {
      localStorage.setItem(hourKey, JSON.stringify({ start: now, count: 0 }));
      return { ok: true };
    }
    if (parsed.count >= AI_HOURLY_CAP) {
      return { ok: false, error: "Assistant limit reached. Try again in a bit." };
    }
    return { ok: true };
  } catch {
    return { ok: true };
  }
}

export function recordAssistantCall() {
  try {
    const raw = localStorage.getItem(hourKey);
    const now = Date.now();
    const parsed = raw ? (JSON.parse(raw) as { start: number; count: number }) : { start: now, count: 0 };
    const start = now - parsed.start > 60 * 60 * 1000 ? now : parsed.start;
    const count = start === parsed.start ? parsed.count + 1 : 1;
    localStorage.setItem(hourKey, JSON.stringify({ start, count }));
  } catch {
    /* ignore */
  }
}
