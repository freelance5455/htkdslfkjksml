import type { LanguageId } from "./types";
import { languageFromExtension } from "./languages";

interface Signal {
  id: LanguageId;
  score: number;
}

function has(code: string, re: RegExp): boolean {
  return re.test(code);
}

export function detectLanguage(code: string, path?: string): LanguageId {
  const fromPath = path ? languageFromExtension(path) : "plaintext";
  if (path && fromPath !== "plaintext" && fromPath !== "image") {
    return fromPath;
  }

  const text = code.slice(0, 12_000).trim();
  if (!text) return fromPath === "plaintext" ? "javascript" : fromPath;

  const signals: Signal[] = [];

  if (/^\s*</.test(text) && /<!doctype html|<html[\s>]|<body[\s>]/i.test(text)) {
    signals.push({ id: "html", score: 10 });
  }
  if (/^\s*<svg[\s>]/i.test(text) || /xmlns="http:\/\/www\.w3\.org\/2000\/svg"/i.test(text)) {
    signals.push({ id: "svg", score: 12 });
  }
  if (/^\s*<\?xml/.test(text) || (/^\s*</.test(text) && /<\/[a-zA-Z0-9:_-]+>\s*$/.test(text) && !/<html/i.test(text))) {
    signals.push({ id: "xml", score: 6 });
  }
  if (/^\s*[{[]/.test(text)) {
    try {
      JSON.parse(text);
      signals.push({ id: "json", score: 11 });
    } catch {
      /* not json */
    }
  }
  if (has(text, /<\?php/i)) signals.push({ id: "php", score: 12 });
  if (has(text, /\b(def|import|from|print|elif|None|True|False)\b/) && has(text, /:\s*$/m)) {
    signals.push({ id: "python", score: 8 });
  }
  if (has(text, /\bfn\s+main\b|\blet\s+mut\b|\bimpl\s+|println!/)) signals.push({ id: "rust", score: 10 });
  if (has(text, /\bpackage\s+main\b|\bfunc\s+\w+\s*\(/)) signals.push({ id: "go", score: 9 });
  if (has(text, /\bStatelessWidget\b|\bStatefulWidget\b|\bWidget\s+build\(/)) {
    signals.push({ id: "flutter", score: 11 });
  }
  if (has(text, /\bvoid\s+main\s*\(\s*\)/) && has(text, /\b(dart|print)\b/)) signals.push({ id: "dart", score: 8 });
  if (has(text, /\bfun\s+\w+\s*\(|\bval\s+\w+\s*[:=]|\bcompanion object\b/)) signals.push({ id: "kotlin", score: 9 });
  if (has(text, /\bpublic\s+class\s+\w+|\bSystem\.out\.println/)) signals.push({ id: "java", score: 8 });
  if (has(text, /\bimport\s+UIKit|\bfunc\s+\w+\s*\([^)]*\)\s*\{|\bvar\s+\w+\s*:\s*\w+/)) {
    signals.push({ id: "swift", score: 7 });
  }
  if (has(text, /\busing\s+System\b|\bnamespace\s+\w+|Console\.WriteLine/)) signals.push({ id: "csharp", score: 9 });
  if (has(text, /\bSELECT\b[\s\S]*\bFROM\b/i) && !has(text, /function|const |let /)) {
    signals.push({ id: "sql", score: 8 });
  }
  if (has(text, /^#\s.+/m) && has(text, /^\s*[-*]\s/m) && !has(text, /<html/i)) {
    signals.push({ id: "markdown", score: 6 });
  }
  if (has(text, /\{[^}]*:[^}]*;/) && has(text, /[.#]?[a-zA-Z][\w-]*\s*\{/)) {
    signals.push({ id: "css", score: 7 });
  }
  if (has(text, /\b(interface|type)\s+\w+\s*[=<{]/) || has(text, /:\s*(string|number|boolean|void)\b/)) {
    signals.push({ id: "typescript", score: 8 });
  }
  if (has(text, /\b(function|const|let|var|=>|export |import )\b/)) {
    signals.push({ id: "javascript", score: 5 });
  }
  if (has(text, /\b(include|require)\b/) && has(text, /\bend\b/)) signals.push({ id: "ruby", score: 5 });
  if (has(text, /\b#include\s*<.*>/) && has(text, /\bint\s+main\s*\(/)) {
    signals.push({ id: has(text, /\bstd::|cout\s*<</) ? "cpp" : "c", score: 9 });
  }

  signals.sort((a, b) => b.score - a.score);
  return signals[0]?.id ?? (fromPath === "plaintext" ? "javascript" : fromPath);
}

export function resolveFileLanguage(language: LanguageId, content: string, path: string): LanguageId {
  if (language !== "auto") return language;
  return detectLanguage(content, path);
}
