import { createId } from "@/lib/utils";
import type { ProjectFile } from "./types";

export const SAMPLE_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>NIJO Demo</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <main class="wrap">
    <p class="eyebrow">NIJO MOBILE</p>
    <h1>Hello World</h1>
    <p class="lede">Code anywhere. Build anywhere.</p>
    <button id="go" type="button">Run a line of JS</button>
    <p id="out" class="out"></p>
  </main>
  <script src="script.js"></script>
</body>
</html>
`;

export const SAMPLE_CSS = `:root {
  color-scheme: dark;
  --ink: #eef1f6;
  --muted: #9aa3b5;
  --accent: #4d8dff;
  --bg: #0b0d12;
}

* { box-sizing: border-box; }

html, body {
  margin: 0;
  min-height: 100%;
  font-family: ui-sans-serif, system-ui, sans-serif;
  background: radial-gradient(1200px 600px at 10% -10%, #152036, var(--bg));
  color: var(--ink);
}

.wrap {
  max-width: 28rem;
  margin: 0 auto;
  padding: 3rem 1.5rem;
}

.eyebrow {
  letter-spacing: 0.18em;
  text-transform: uppercase;
  font-size: 0.7rem;
  color: var(--accent);
  margin: 0 0 0.75rem;
}

h1 {
  font-size: 2.4rem;
  letter-spacing: -0.04em;
  margin: 0 0 0.5rem;
}

.lede {
  color: var(--muted);
  margin: 0 0 1.5rem;
}

button {
  appearance: none;
  border: 0;
  border-radius: 999px;
  padding: 0.8rem 1.2rem;
  background: var(--accent);
  color: #06101e;
  font-weight: 600;
  font-size: 0.95rem;
}

.out {
  min-height: 1.4em;
  margin-top: 1rem;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  color: #9ad7b5;
}
`;

export const SAMPLE_JS = `const button = document.getElementById("go");
const out = document.getElementById("out");

button?.addEventListener("click", () => {
  const total = 75 + 75;
  out.textContent = "Total: " + total;
  console.log("Hello World");
  console.log("Total:", total);
});

console.log("NIJO preview ready");
`;

export function createSampleFiles(): ProjectFile[] {
  return [
    { id: createId(), path: "index.html", content: SAMPLE_HTML, language: "html" },
    { id: createId(), path: "style.css", content: SAMPLE_CSS, language: "css" },
    { id: createId(), path: "script.js", content: SAMPLE_JS, language: "javascript" },
  ];
}
