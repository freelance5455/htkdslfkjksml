import { css as beautifyCss, html as beautifyHtml, js as beautifyJs } from "js-beautify";
import type { LanguageId } from "./types";

export function formatCode(code: string, language: LanguageId): string {
  const options = { indent_size: 2, preserve_newlines: true, max_preserve_newlines: 2 };
  try {
    switch (language) {
      case "html":
      case "svg":
      case "xml":
      case "vue":
      case "svelte":
        return beautifyHtml(code, options);
      case "css":
        return beautifyCss(code, options);
      case "javascript":
      case "typescript":
      case "react":
      case "react-native":
        return beautifyJs(code, options);
      case "json":
        return JSON.stringify(JSON.parse(code), null, 2);
      default:
        return code;
    }
  } catch {
    return code;
  }
}
