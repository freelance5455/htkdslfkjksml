import JSZip from "jszip";
import { createId, parentPath } from "@/lib/utils";
import { detectLanguage } from "./detect";
import { languageFromExtension } from "./languages";
import { MAX_FILE_BYTES, MAX_ZIP_BYTES, shouldSkipZipPath } from "./limits";
import type { ProjectFile } from "./types";

const TEXT_EXT = new Set([
  "html",
  "htm",
  "css",
  "js",
  "mjs",
  "cjs",
  "ts",
  "tsx",
  "jsx",
  "py",
  "dart",
  "java",
  "kt",
  "kts",
  "c",
  "h",
  "cpp",
  "cc",
  "hpp",
  "cs",
  "php",
  "rb",
  "go",
  "rs",
  "swift",
  "json",
  "xml",
  "md",
  "markdown",
  "svg",
  "vue",
  "svelte",
  "sql",
  "lua",
  "txt",
  "yml",
  "yaml",
  "toml",
  "env",
  "gitignore",
]);

const IMAGE_EXT = new Set(["png", "jpg", "jpeg", "gif", "webp", "ico"]);

function ext(path: string): string {
  const base = path.split("/").pop() ?? path;
  const i = base.lastIndexOf(".");
  return i === -1 ? "" : base.slice(i + 1).toLowerCase();
}

function normalizePath(path: string): string {
  return path.replace(/\\/g, "/").replace(/^\.?\//, "");
}

export interface ZipImport {
  name: string;
  files: ProjectFile[];
  folders: string[];
}

export async function importZip(file: File): Promise<ZipImport> {
  if (file.size > MAX_ZIP_BYTES) {
    throw new Error("ZIP is too large. Keep projects under 8 MB.");
  }
  const zip = await JSZip.loadAsync(file);
  const files: ProjectFile[] = [];
  const folderSet = new Set<string>();

  const entries = Object.values(zip.files);
  for (const entry of entries) {
    const path = normalizePath(entry.name);
    if (!path || shouldSkipZipPath(path)) continue;
    if (entry.dir) {
      const dir = path.replace(/\/+$/, "");
      if (dir) folderSet.add(dir);
      continue;
    }
    const parent = parentPath(path);
    if (parent) {
      const parts = parent.split("/");
      let acc = "";
      for (const part of parts) {
        acc = acc ? `${acc}/${part}` : part;
        folderSet.add(acc);
      }
    }
    const kind = ext(path);
    if (IMAGE_EXT.has(kind)) {
      const blob = await entry.async("base64");
      if (blob.length * 0.75 > MAX_FILE_BYTES) continue;
      const mime = kind === "jpg" ? "jpeg" : kind;
      files.push({
        id: createId(),
        path,
        content: `data:image/${mime};base64,${blob}`,
        language: "image",
        binary: true,
      });
      continue;
    }
    if (!TEXT_EXT.has(kind) && kind !== "") continue;
    const content = await entry.async("string");
    if (content.length > MAX_FILE_BYTES) continue;
    const language = detectLanguage(content, path);
    files.push({
      id: createId(),
      path,
      content,
      language: language === "plaintext" ? languageFromExtension(path) : language,
    });
  }

  const name = file.name.replace(/\.zip$/i, "") || "My Project";
  return { name, files, folders: [...folderSet].sort() };
}
