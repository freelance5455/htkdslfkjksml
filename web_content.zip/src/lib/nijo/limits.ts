export const MAX_FILE_BYTES = 1_500_000;
export const MAX_PROJECT_BYTES = 4_000_000;
export const MAX_FILES = 80;
export const MAX_ZIP_BYTES = 8_000_000;
export const RUN_TIMEOUT_MS = 8_000;
export const PYTHON_LOAD_TIMEOUT_MS = 25_000;
export const AI_MAX_CODE_CHARS = 12_000;
export const AI_MAX_TOKENS = 700;
export const AI_HOURLY_CAP = 8;

export const SKIP_ZIP_PARTS = [
  "node_modules/",
  ".git/",
  "__MACOSX/",
  ".ds_store",
  "dist/",
  "build/",
  ".next/",
  "vendor/",
];

export function shouldSkipZipPath(path: string): boolean {
  const lower = path.toLowerCase();
  return SKIP_ZIP_PARTS.some((part) => lower.includes(part));
}

export function utf8Bytes(text: string): number {
  return new TextEncoder().encode(text).length;
}
