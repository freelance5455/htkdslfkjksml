export type LanguageId =
  | "auto"
  | "html"
  | "css"
  | "javascript"
  | "typescript"
  | "react"
  | "vue"
  | "svelte"
  | "dart"
  | "flutter"
  | "kotlin"
  | "java"
  | "swift"
  | "react-native"
  | "python"
  | "c"
  | "cpp"
  | "csharp"
  | "go"
  | "rust"
  | "ruby"
  | "php"
  | "lua"
  | "r"
  | "sql"
  | "json"
  | "xml"
  | "markdown"
  | "svg"
  | "plaintext"
  | "image";

export type OutputMode =
  | "preview"
  | "console"
  | "markdown"
  | "formatted"
  | "svg"
  | "image"
  | "unavailable";

export type WorkspaceTab = "editor" | "run" | "preview" | "files" | "settings";

export type PreviewDevice = "mobile" | "tablet" | "desktop";

export type ConsoleLevel = "log" | "info" | "warn" | "error" | "status" | "success";

export interface ProjectFile {
  id: string;
  path: string;
  content: string;
  language: LanguageId;
  binary?: boolean;
}

export interface ConsoleLine {
  id: string;
  level: ConsoleLevel;
  text: string;
  meta?: string;
  ts: number;
}

export interface EditorSettings {
  fontSize: number;
  theme: "dark" | "light";
  wrap: boolean;
  tabSize: 2 | 4;
}

export interface RunSnapshot {
  mode: OutputMode;
  html?: string;
  document?: string;
  status: "idle" | "running" | "ok" | "error" | "unavailable" | "timeout";
  message?: string;
  ranAt?: number;
}
