import { create } from "zustand";
import { baseName, createId, joinPath, parentPath } from "@/lib/utils";
import { detectLanguage, resolveFileLanguage } from "./detect";
import { languageFromExtension } from "./languages";
import { MAX_FILE_BYTES, MAX_FILES, MAX_PROJECT_BYTES, utf8Bytes } from "./limits";
import { createSampleFiles } from "./sample";
import type {
  ConsoleLine,
  EditorSettings,
  LanguageId,
  PreviewDevice,
  ProjectFile,
  RunSnapshot,
  WorkspaceTab,
} from "./types";

const STORAGE_KEY = "nijo-mobile-v1";

const defaultSettings: EditorSettings = {
  fontSize: 16,
  theme: "dark",
  wrap: true,
  tabSize: 2,
};

interface Persisted {
  projectName: string;
  files: ProjectFile[];
  folders: string[];
  activeFileId: string | null;
  settings: EditorSettings;
  currentDir: string;
}

export interface ProjectState extends Persisted {
  hydrated: boolean;
  tab: WorkspaceTab;
  previewDevice: PreviewDevice;
  consoleLines: ConsoleLine[];
  run: RunSnapshot;
  fullscreen: boolean;
  findOpen: boolean;
  editorViewVersion: number;
  hydrate: () => void;
  setTab: (tab: WorkspaceTab) => void;
  setDevice: (device: PreviewDevice) => void;
  setFullscreen: (value: boolean) => void;
  setFindOpen: (value: boolean) => void;
  bumpEditor: () => void;
  setActiveFile: (id: string) => void;
  setCurrentDir: (dir: string) => void;
  updateContent: (id: string, content: string) => void;
  setLanguage: (id: string, language: LanguageId) => void;
  autoDetectActive: () => LanguageId;
  createFile: (name: string, content?: string, language?: LanguageId) => string | null;
  createFolder: (name: string) => string | null;
  renameNode: (path: string, nextName: string, isFolder: boolean) => void;
  deleteNode: (path: string, isFolder: boolean) => void;
  replaceProject: (name: string, files: ProjectFile[], folders: string[]) => string | null;
  openLocalText: (filename: string, content: string) => string | null;
  setSettings: (patch: Partial<EditorSettings>) => void;
  applyTheme: () => void;
  appendConsole: (line: Omit<ConsoleLine, "id" | "ts">) => void;
  clearConsole: () => void;
  setRun: (run: RunSnapshot) => void;
  resetProject: () => void;
}

let saveTimer: ReturnType<typeof setTimeout> | null = null;

function persistSlice(state: Persisted) {
  if (typeof window === "undefined") return;
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({
          projectName: state.projectName,
          files: state.files,
          folders: state.folders,
          activeFileId: state.activeFileId,
          settings: state.settings,
          currentDir: state.currentDir,
        } satisfies Persisted),
      );
    } catch {
      /* quota */
    }
  }, 280);
}

function projectBytes(files: ProjectFile[]): number {
  return files.reduce((sum, file) => sum + utf8Bytes(file.content), 0);
}

function canFit(files: ProjectFile[], extra: string): string | null {
  if (files.length >= MAX_FILES) return "Project file limit reached.";
  if (utf8Bytes(extra) > MAX_FILE_BYTES) return "That file is too large for NIJO MOBILE.";
  if (projectBytes(files) + utf8Bytes(extra) > MAX_PROJECT_BYTES) {
    return "This project is over the storage limit.";
  }
  return null;
}

function sampleState(): Persisted {
  const files = createSampleFiles();
  return {
    projectName: "My Project",
    files,
    folders: [],
    activeFileId: files[0]?.id ?? null,
    settings: defaultSettings,
    currentDir: "",
  };
}

export const useProjectStore = create<ProjectState>((set, get) => ({
  ...sampleState(),
  hydrated: false,
  tab: "editor",
  previewDevice: "mobile",
  consoleLines: [],
  run: { mode: "preview", status: "idle" },
  fullscreen: false,
  findOpen: false,
  editorViewVersion: 0,

  hydrate: () => {
    if (get().hydrated) return;
    let next = sampleState();
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<Persisted>;
        if (Array.isArray(parsed.files) && parsed.files.length > 0) {
          next = {
            projectName: parsed.projectName || "My Project",
            files: parsed.files,
            folders: parsed.folders ?? [],
            activeFileId: parsed.activeFileId ?? parsed.files[0]?.id ?? null,
            settings: { ...defaultSettings, ...parsed.settings },
            currentDir: parsed.currentDir ?? "",
          };
        }
      }
    } catch {
      /* keep sample */
    }
    set({ ...next, hydrated: true });
    queueMicrotask(() => get().applyTheme());
  },

  setTab: (tab) => set({ tab, fullscreen: tab === "editor" ? get().fullscreen : false }),
  setDevice: (previewDevice) => set({ previewDevice }),
  setFullscreen: (fullscreen) => set({ fullscreen }),
  setFindOpen: (findOpen) => set({ findOpen }),
  bumpEditor: () => set({ editorViewVersion: get().editorViewVersion + 1 }),

  setActiveFile: (id) => set({ activeFileId: id, tab: "editor" }),
  setCurrentDir: (currentDir) => set({ currentDir }),

  updateContent: (id, content) => {
    const files = get().files.map((file) => (file.id === id ? { ...file, content } : file));
    set({ files });
    persistSlice(get());
  },

  setLanguage: (id, language) => {
    const files = get().files.map((file) => (file.id === id ? { ...file, language } : file));
    set({ files });
    persistSlice(get());
  },

  autoDetectActive: () => {
    const { files, activeFileId } = get();
    const file = files.find((f) => f.id === activeFileId);
    if (!file) return "javascript";
    const detected = detectLanguage(file.content, file.path);
    const filesNext = files.map((f) => (f.id === file.id ? { ...f, language: detected } : f));
    set({ files: filesNext });
    persistSlice(get());
    return detected;
  },

  createFile: (name, content = "", language) => {
    const trimmed = name.trim().replace(/^\/+/, "");
    if (!trimmed) return "Enter a file name.";
    const path = joinPath(get().currentDir, trimmed);
    if (get().files.some((f) => f.path === path)) return "A file with that name already exists.";
    const error = canFit(get().files, content);
    if (error) return error;
    const lang = language ?? languageFromExtension(path);
    const file: ProjectFile = {
      id: createId(),
      path,
      content,
      language: lang === "plaintext" ? "javascript" : lang,
    };
    const files = [...get().files, file];
    set({ files, activeFileId: file.id, tab: "editor" });
    persistSlice(get());
    return null;
  },

  createFolder: (name) => {
    const trimmed = name.trim().replace(/^\/+|\/+$/g, "");
    if (!trimmed) return "Enter a folder name.";
    const path = joinPath(get().currentDir, trimmed);
    if (get().folders.includes(path) || get().files.some((f) => f.path === path)) {
      return "That folder already exists.";
    }
    set({ folders: [...get().folders, path], currentDir: path });
    persistSlice(get());
    return null;
  },

  renameNode: (path, nextName, isFolder) => {
    const name = nextName.trim();
    if (!name) return;
    const nextPath = joinPath(parentPath(path), name);
    if (isFolder) {
      const folders = get().folders.map((folder) =>
        folder === path || folder.startsWith(path + "/")
          ? nextPath + folder.slice(path.length)
          : folder,
      );
      const files = get().files.map((file) =>
        file.path === path || file.path.startsWith(path + "/")
          ? { ...file, path: nextPath + file.path.slice(path.length) }
          : file,
      );
      set({
        folders,
        files,
        currentDir: get().currentDir === path ? nextPath : get().currentDir,
      });
    } else {
      const files = get().files.map((file) =>
        file.path === path ? { ...file, path: nextPath, language: languageFromExtension(nextPath) } : file,
      );
      set({ files });
    }
    persistSlice(get());
  },

  deleteNode: (path, isFolder) => {
    if (isFolder) {
      const files = get().files.filter((file) => file.path !== path && !file.path.startsWith(path + "/"));
      const folders = get().folders.filter((folder) => folder !== path && !folder.startsWith(path + "/"));
      const active = files.find((f) => f.id === get().activeFileId) ?? files[0];
      set({
        files,
        folders,
        activeFileId: active?.id ?? null,
        currentDir: get().currentDir === path ? parentPath(path) : get().currentDir,
      });
    } else {
      const files = get().files.filter((file) => file.path !== path);
      const active = files.find((f) => f.id === get().activeFileId) ?? files[0];
      set({ files, activeFileId: active?.id ?? null });
    }
    persistSlice(get());
  },

  replaceProject: (name, files, folders) => {
    if (files.length === 0) return "No files found in that project.";
    if (files.length > MAX_FILES) return "Too many files in this ZIP.";
    if (projectBytes(files) > MAX_PROJECT_BYTES) return "Project is too large to open on this device.";
    const html = files.find((f) => f.path.endsWith(".html") || f.path.endsWith(".htm"));
    set({
      projectName: name || "My Project",
      files,
      folders,
      activeFileId: html?.id ?? files[0]?.id ?? null,
      currentDir: "",
      tab: "files",
      consoleLines: [],
      run: { mode: "preview", status: "idle" },
    });
    persistSlice(get());
    return null;
  },

  openLocalText: (filename, content) => {
    const error = canFit(
      get().files.filter((f) => f.path !== joinPath(get().currentDir, filename)),
      content,
    );
    if (error) return error;
    const path = joinPath(get().currentDir, baseName(filename));
    const language = detectLanguage(content, path);
    const existing = get().files.find((f) => f.path === path);
    const file: ProjectFile = existing
      ? { ...existing, content, language }
      : { id: createId(), path, content, language };
    const files = existing
      ? get().files.map((f) => (f.id === existing.id ? file : f))
      : [...get().files, file];
    set({ files, activeFileId: file.id, tab: "editor" });
    persistSlice(get());
    return null;
  },

  setSettings: (patch) => {
    const settings = { ...get().settings, ...patch };
    set({ settings });
    persistSlice(get());
    if (patch.theme) queueMicrotask(() => get().applyTheme());
  },

  applyTheme: () => {
    if (typeof document === "undefined") return;
    document.documentElement.classList.toggle("light", get().settings.theme === "light");
  },

  appendConsole: (line) => {
    const entry: ConsoleLine = { ...line, id: createId(), ts: Date.now() };
    const consoleLines = [...get().consoleLines, entry].slice(-200);
    set({ consoleLines });
  },

  clearConsole: () => set({ consoleLines: [] }),

  setRun: (run) => set({ run }),

  resetProject: () => {
    const next = sampleState();
    set({
      ...next,
      consoleLines: [],
      run: { mode: "preview", status: "idle" },
      tab: "editor",
      currentDir: "",
    });
    persistSlice(get());
  },
}));

export function getActiveFile(): ProjectFile | undefined {
  const { files, activeFileId } = useProjectStore.getState();
  return files.find((f) => f.id === activeFileId);
}

export function resolvedLanguage(file: ProjectFile | undefined): LanguageId {
  if (!file) return "javascript";
  return resolveFileLanguage(file.language, file.content, file.path);
}
