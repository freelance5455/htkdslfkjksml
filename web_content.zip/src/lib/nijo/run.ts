import DOMPurify from "dompurify";
import { marked } from "marked";
import { languageById } from "./languages";
import { PYTHON_LOAD_TIMEOUT_MS, RUN_TIMEOUT_MS } from "./limits";
import { resolvedLanguage } from "./store";
import type { LanguageId, OutputMode, ProjectFile, RunSnapshot } from "./types";

const BRIDGE = `<script>
(function(){
  if (window.__nijo) return;
  window.__nijo = true;
  function send(type, payload){
    try { parent.postMessage(Object.assign({ source: "nijo-preview", type: type }, payload), "*"); }
    catch (e) {}
  }
  function fmt(v){
    if (typeof v === "string") return v;
    if (v instanceof Error) return v.stack || v.message;
    try { return JSON.stringify(v); } catch (e) { return String(v); }
  }
  ["log","info","warn","error"].forEach(function(level){
    var orig = console[level] ? console[level].bind(console) : function(){};
    console[level] = function(){
      var text = Array.prototype.slice.call(arguments).map(fmt).join(" ");
      send("console", { level: level, text: text });
      orig.apply(console, arguments);
    };
  });
  window.addEventListener("error", function(ev){
    send("console", { level: "error", text: ev.message, meta: ev.lineno ? ("Line " + ev.lineno) : undefined });
  });
  window.addEventListener("unhandledrejection", function(ev){
    send("console", { level: "error", text: String(ev.reason) });
  });
  send("ready", {});
})();
</script>`;

function escapeScript(code: string): string {
  return code.replace(/<\/script/gi, "<\\/script");
}

function findByRef(files: ProjectFile[], href: string, fromPath: string): ProjectFile | undefined {
  const cleaned = href.split("?")[0]?.split("#")[0] ?? href;
  const fromDir = fromPath.includes("/") ? fromPath.slice(0, fromPath.lastIndexOf("/") + 1) : "";
  const candidates = [cleaned.replace(/^\.\//, ""), fromDir + cleaned.replace(/^\.\//, ""), cleaned.replace(/^\//, "")];
  return files.find((f) => candidates.includes(f.path) || f.path.endsWith("/" + cleaned) || f.path === cleaned);
}

export function buildWebDocument(files: ProjectFile[], entry: ProjectFile): string {
  let html = entry.content;
  if (!/<html/i.test(html)) {
    html = `<!DOCTYPE html><html><head><meta charset="utf-8"/></head><body>${html}</body></html>`;
  }

  html = html.replace(
    /<link([^>]*?)href=["']([^"']+)["']([^>]*)>/gi,
    (full, pre: string, href: string, post: string) => {
      if (!/stylesheet/i.test(pre + post) && !href.endsWith(".css")) return full;
      const file = findByRef(files, href, entry.path);
      if (!file) return full;
      return `<style>\n${file.content}\n</style>`;
    },
  );

  html = html.replace(
    /<script([^>]*?)src=["']([^"']+)["']([^>]*)><\/script>/gi,
    (full, pre: string, src: string) => {
      const file = findByRef(files, src, entry.path);
      if (!file) return full;
      return `<script${pre}>\n${escapeScript(file.content)}\n</script>`;
    },
  );

  html = html.replace(/<(img|image)([^>]*?)src=["']([^"']+)["']/gi, (full, tag: string, pre: string, src: string) => {
    if (src.startsWith("data:") || src.startsWith("http")) return full;
    const file = findByRef(files, src, entry.path);
    if (!file) return full;
    return `<${tag}${pre}src="${file.content}"`;
  });

  if (/<head[\s>]/i.test(html)) {
    html = html.replace(/<head([^>]*)>/i, `<head$1>${BRIDGE}`);
  } else {
    html = BRIDGE + html;
  }
  return html;
}

function wrapCssPreview(css: string): string {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>${BRIDGE}<style>
html,body{margin:0;min-height:100%;font-family:ui-sans-serif,system-ui;background:#0b0d12;color:#eef1f6}
.preview-note{padding:24px;max-width:28rem}
${css}
</style></head><body>
<main class="preview-note">
  <h1>CSS preview</h1>
  <p>Your stylesheet is applied to this page.</p>
  <button type="button">Sample button</button>
</main>
</body></html>`;
}

function wrapJsConsole(code: string): string {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>${BRIDGE}</head><body>
<script>
try {
${escapeScript(code)}
  parent.postMessage({ source: "nijo-preview", type: "done" }, "*");
} catch (err) {
  parent.postMessage({ source: "nijo-preview", type: "console", level: "error", text: err && err.message ? err.message : String(err), meta: "Runtime error" }, "*");
  parent.postMessage({ source: "nijo-preview", type: "done" }, "*");
}
</script>
</body></html>`;
}

function stripTs(code: string): string {
  return code
    .replace(/^\s*import\s+[\s\S]*?from\s+["'][^"']+["'];?/gm, "")
    .replace(/^\s*export\s+\{[\s\S]*?\};?/gm, "")
    .replace(/\bexport\s+default\s+/g, "")
    .replace(/\bexport\s+/g, "")
    .replace(/:\s*[A-Za-z_][\w.<>,\s|&[\]']*(?=[,)=;{])/g, "")
    .replace(/\bas\s+[A-Za-z_][\w.]*/g, "")
    .replace(/interface\s+\w+\s*\{[\s\S]*?\}\s*/g, "")
    .replace(/type\s+\w+\s*=\s*[^;]+;?/g, "");
}

async function renderMarkdown(code: string): Promise<string> {
  const raw = await marked.parse(code, { async: true, gfm: true });
  const safe = DOMPurify.sanitize(raw, { USE_PROFILES: { html: true } });
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>
<style>
  html,body{margin:0;background:#0b0d12;color:#eef1f6;font-family:ui-sans-serif,system-ui;line-height:1.6}
  main{padding:20px 18px 48px;max-width:40rem;margin:0 auto}
  a{color:#4d8dff}
  pre,code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:0.9em}
  pre{background:#161a22;padding:12px;border-radius:12px;overflow:auto}
  img{max-width:100%;border-radius:12px}
  h1,h2,h3{letter-spacing:-0.03em}
</style></head><body><main>${safe}</main></body></html>`;
}

function formattedView(title: string, body: string): string {
  const escaped = body
    .replace(/&/g, "&")
    .replace(/</g, "<")
    .replace(/>/g, ">");
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>
<style>
  html,body{margin:0;background:#0b0d12;color:#d7deea}
  pre{margin:0;padding:16px;font:13px/1.6 ui-monospace,SFMono-Regular,Menlo,monospace;white-space:pre-wrap}
  .label{padding:12px 16px 0;color:#8e96a8;font:600 11px Outfit,system-ui;letter-spacing:.14em;text-transform:uppercase}
</style></head><body><div class="label">${title}</div><pre>${escaped}</pre></body></html>`;
}

function svgDocument(code: string): string {
  const svg = code.trim().startsWith("<") ? code : `<svg xmlns="http://www.w3.org/2000/svg">${code}</svg>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
<style>html,body{margin:0;background:#0b0d12;display:grid;place-items:center;min-height:100%} svg{max-width:90vw;max-height:90vh}</style>
</head><body>${svg}</body></html>`;
}

function imageDocument(src: string): string {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
<style>html,body{margin:0;background:#0b0d12;display:grid;place-items:center;min-height:100%} img{max-width:92vw;max-height:92vh;border-radius:12px}</style>
</head><body><img alt="Preview" src="${src}" /></body></html>`;
}

export interface RunPlan {
  mode: OutputMode;
  language: LanguageId;
  reason?: string;
}

export function planRun(files: ProjectFile[], active: ProjectFile | undefined): RunPlan {
  if (!active) return { mode: "unavailable", language: "plaintext", reason: "Open a file first." };
  const language = resolvedLanguage(active);
  const meta = languageById(language);
  const hasHtml = files.some((f) => f.path.endsWith(".html") || f.path.endsWith(".htm") || f.language === "html");

  if (language === "html" || language === "css" || ((language === "javascript" || language === "typescript") && hasHtml)) {
    return { mode: "preview", language };
  }
  if (language === "javascript" || language === "typescript") return { mode: "console", language };
  if (language === "python") return { mode: "console", language };
  if (language === "markdown") return { mode: "markdown", language };
  if (language === "json" || language === "xml" || language === "sql") return { mode: "formatted", language };
  if (language === "svg") return { mode: "svg", language };
  if (language === "image") return { mode: "image", language };
  return {
    mode: "unavailable",
    language,
    reason: meta.unavailableReason ?? "Execution environment unavailable",
  };
}

function htmlEntry(files: ProjectFile[], active: ProjectFile): ProjectFile {
  if (active.language === "html" || active.path.endsWith(".html") || active.path.endsWith(".htm")) return active;
  return (
    files.find((f) => f.path === "index.html" || f.path.endsWith("/index.html")) ??
    files.find((f) => f.path.endsWith(".html") || f.path.endsWith(".htm")) ??
    active
  );
}

export async function prepareRun(files: ProjectFile[], active: ProjectFile | undefined): Promise<RunSnapshot> {
  const plan = planRun(files, active);
  if (!active) return { mode: "unavailable", status: "unavailable", message: plan.reason };
  if (plan.mode === "unavailable") {
    return { mode: "unavailable", status: "unavailable", message: plan.reason, ranAt: Date.now() };
  }

  try {
    if (plan.mode === "preview") {
      if (plan.language === "css" && !files.some((f) => f.language === "html" || f.path.endsWith(".html"))) {
        return { mode: "preview", status: "ok", html: wrapCssPreview(active.content), ranAt: Date.now() };
      }
      const entry = htmlEntry(files, active);
      return { mode: "preview", status: "ok", html: buildWebDocument(files, entry), ranAt: Date.now() };
    }
    if (plan.mode === "console" && (plan.language === "javascript" || plan.language === "typescript")) {
      const code = plan.language === "typescript" ? stripTs(active.content) : active.content;
      return { mode: "console", status: "running", html: wrapJsConsole(code), ranAt: Date.now() };
    }
    if (plan.mode === "console" && plan.language === "python") {
      return { mode: "console", status: "running", message: "Loading Python runtime…", ranAt: Date.now() };
    }
    if (plan.mode === "markdown") {
      return { mode: "markdown", status: "ok", html: await renderMarkdown(active.content), ranAt: Date.now() };
    }
    if (plan.mode === "formatted") {
      let body = active.content;
      if (plan.language === "json") {
        try {
          body = JSON.stringify(JSON.parse(active.content), null, 2);
        } catch (err) {
          return {
            mode: "formatted",
            status: "error",
            message: err instanceof Error ? err.message : "Invalid JSON",
            ranAt: Date.now(),
          };
        }
      }
      return {
        mode: "formatted",
        status: "ok",
        html: formattedView(plan.language.toUpperCase(), body),
        ranAt: Date.now(),
      };
    }
    if (plan.mode === "svg") {
      return { mode: "svg", status: "ok", html: svgDocument(active.content), ranAt: Date.now() };
    }
    if (plan.mode === "image") {
      return { mode: "image", status: "ok", html: imageDocument(active.content), ranAt: Date.now() };
    }
  } catch (err) {
    return {
      mode: plan.mode,
      status: "error",
      message: err instanceof Error ? err.message : "Run failed",
      ranAt: Date.now(),
    };
  }

  return { mode: plan.mode, status: "unavailable", message: "Execution environment unavailable", ranAt: Date.now() };
}

export const RUN_TIMEOUT = RUN_TIMEOUT_MS;

type PyodideHandle = {
  setStdout: (opts: { batched: (s: string) => void }) => void;
  setStderr: (opts: { batched: (s: string) => void }) => void;
  runPythonAsync: (code: string) => Promise<unknown>;
};

let pyodidePromise: Promise<PyodideHandle> | null = null;

async function loadPyodideRuntime(): Promise<PyodideHandle> {
  const w = window as unknown as {
    loadPyodide?: (opts: { indexURL: string }) => Promise<PyodideHandle>;
  };
  if (!w.loadPyodide) {
    await new Promise<void>((resolve, reject) => {
      const script = document.createElement("script");
      script.src = "https://cdn.jsdelivr.net/pyodide/v0.27.5/full/pyodide.js";
      script.onload = () => resolve();
      script.onerror = () => reject(new Error("Could not load the Python runtime."));
      document.head.appendChild(script);
    });
  }
  const loader = (window as unknown as { loadPyodide: NonNullable<typeof w.loadPyodide> }).loadPyodide;
  return loader({ indexURL: "https://cdn.jsdelivr.net/pyodide/v0.27.5/full/" });
}

export async function runPython(code: string, onOutput: (level: "log" | "error", text: string) => void): Promise<void> {
  const timeout = new Promise<never>((_, reject) => {
    setTimeout(() => reject(new Error("Python runtime timed out.")), PYTHON_LOAD_TIMEOUT_MS);
  });
  if (!pyodidePromise) pyodidePromise = loadPyodideRuntime();
  let pyodide: PyodideHandle;
  try {
    pyodide = await Promise.race([pyodidePromise, timeout]);
  } catch (err) {
    pyodidePromise = null;
    throw err;
  }
  pyodide.setStdout({ batched: (s) => onOutput("log", s) });
  pyodide.setStderr({ batched: (s) => onOutput("error", s) });
  const execTimeout = new Promise<never>((_, reject) => {
    setTimeout(() => reject(new Error("Execution timed out.")), RUN_TIMEOUT_MS);
  });
  await Promise.race([pyodide.runPythonAsync(code), execTimeout]);
}
