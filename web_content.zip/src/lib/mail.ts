/**
 * Transactional email through Resend (https://resend.com) when RESEND_API_KEY is set.
 * Returns false when no provider is configured so callers can fall back to demo behaviour.
 */
export async function sendEmail(params: { to: string; subject: string; html: string }): Promise<boolean> {
  const key = process.env.RESEND_API_KEY;
  if (!key) return false;
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: process.env.EMAIL_FROM || "ShifaCare <onboarding@resend.dev>",
        to: [params.to],
        subject: params.subject,
        html: params.html,
      }),
    });
    return res.ok;
  } catch (err) {
    console.error("[mail] send failed", err);
    return false;
  }
}
