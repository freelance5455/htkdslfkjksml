import { formatRange, platformLabel } from "@/lib/format";
import type { Appraisal, TradeIntent } from "@/lib/types";

export function appraisalToText(
  appraisal: Appraisal,
  intent: TradeIntent,
  platform: string,
): string {
  const lines: string[] = [
    "Bruno Gaming — eFootball Account Appraisal",
    `Intent: ${intent === "buy" ? "Buy" : "Sell"} · ${platformLabel(platform)}`,
    `Tier ${appraisal.tier} · ${appraisal.tierLabel}`,
    `ပေါက်စျေး: ${formatRange(appraisal.finalMin, appraisal.finalMax)}`,
  ];
  if (appraisal.summary) lines.push(appraisal.summary);
  if (appraisal.paidCards.length) {
    lines.push("", "Paid / Special Skill:");
    for (const c of appraisal.paidCards) {
      lines.push(`- ${c.name}${c.skill ? ` (${c.skill})` : ""}${c.note ? ` — ${c.note}` : ""}`);
    }
  }
  if (appraisal.freeCards.length) {
    lines.push("", "Free / Event (စျေးမရ):");
    for (const c of appraisal.freeCards) {
      lines.push(`- ${c.name}${c.note ? ` — ${c.note}` : ""}`);
    }
  }
  if (appraisal.managers.length) {
    lines.push("", "Managers:");
    for (const c of appraisal.managers) {
      lines.push(`- ${c.name}${c.note ? ` — ${c.note}` : ""}`);
    }
  }
  if (appraisal.marketAnalysis) {
    lines.push("", "စျေးကွက်:", appraisal.marketAnalysis);
  }
  if (appraisal.strategyPoints.length) {
    lines.push("", "အကြံပြုချက်:");
    appraisal.strategyPoints.forEach((p, i) => lines.push(`${i + 1}. ${p}`));
  }
  if (appraisal.warnings.length) {
    lines.push("", "သတိပေးချက်:");
    for (const w of appraisal.warnings) lines.push(`- ${w}`);
  }
  lines.push("", "— Bruno Gaming");
  return lines.join("\n");
}
