import { create } from "zustand";
import {
  PLACES,
  placeStopId,
  todayIso,
  type Find,
  type Tour,
} from "@/lib/field";

export type SaveFindInput = {
  id: string | null;
  name: string;
  mineral: string;
  notes: string;
  date: string;
  lat: number;
  lng: number;
  keepPhotoIds: string[];
  files: File[];
};

type PhotoRow = { id: string; blob: Blob };

type FieldState = {
  ready: boolean;
  loadError: string | null;
  finds: Find[];
  tours: Tour[];
  photoUrls: Record<string, string>;
  load: () => Promise<void>;
  saveFind: (input: SaveFindInput) => Promise<string>;
  deleteFind: (id: string) => Promise<void>;
  createTour: () => Promise<string>;
  patchTour: (
    id: string,
    patch: Partial<Pick<Tour, "name" | "notes" | "date" | "fixed" | "visible">>,
  ) => Promise<void>;
  deleteTour: (id: string) => Promise<void>;
  addStop: (tourId: string, stopId: string) => Promise<boolean>;
  removeStop: (tourId: string, index: number) => Promise<void>;
  moveStop: (tourId: string, index: number, dir: -1 | 1) => Promise<void>;
  exportBackup: () => Promise<void>;
  importBackup: (file: File) => Promise<number>;
};

const MAX_PHOTOS = 6;
const urls: Record<string, string> = {};
let loadOnce: Promise<void> | null = null;
let dbPromise: Promise<IDBDatabase> | null = null;

function openDb() {
  if (typeof indexedDB === "undefined") return Promise.reject(new Error("Kein lokaler Speicher"));
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open("ader", 1);
      request.onupgradeneeded = () => {
        const db = request.result;
        for (const name of ["finds", "tours", "photos"]) {
          if (!db.objectStoreNames.contains(name)) db.createObjectStore(name, { keyPath: "id" });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => {
        dbPromise = null;
        reject(request.error ?? new Error("Speicher öffnen fehlgeschlagen"));
      };
    });
  }
  return dbPromise;
}

function requestToPromise<T>(request: IDBRequest<T>) {
  return new Promise<T>((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function transactionDone(tx: IDBTransaction) {
  return new Promise<void>((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error ?? new Error("abgebrochen"));
  });
}

async function putRow(store: string, value: unknown) {
  const db = await openDb();
  const tx = db.transaction(store, "readwrite");
  const done = transactionDone(tx);
  tx.objectStore(store).put(value);
  await done;
}

async function deleteRow(store: string, id: string) {
  const db = await openDb();
  const tx = db.transaction(store, "readwrite");
  const done = transactionDone(tx);
  tx.objectStore(store).delete(id);
  await done;
}

async function getAll<T>(store: string) {
  const db = await openDb();
  const tx = db.transaction(store, "readonly");
  const done = transactionDone(tx);
  const rows = await requestToPromise(tx.objectStore(store).getAll() as IDBRequest<T[]>);
  await done;
  return rows;
}

function rememberPhoto(id: string, blob: Blob) {
  if (urls[id]) URL.revokeObjectURL(urls[id]);
  urls[id] = URL.createObjectURL(blob);
}

function forgetPhoto(id: string) {
  if (!urls[id]) return;
  URL.revokeObjectURL(urls[id]);
  delete urls[id];
}

async function compressImage(file: File) {
  if (file.size > 15 * 1024 * 1024) throw new Error("Bild ist größer als 15 MB.");
  const bitmap = await createImageBitmap(file);
  try {
    const max = 1600;
    const scale = Math.min(1, max / Math.max(bitmap.width, bitmap.height));
    const width = Math.max(1, Math.round(bitmap.width * scale));
    const height = Math.max(1, Math.round(bitmap.height * scale));
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Bild konnte nicht verarbeitet werden.");
    ctx.drawImage(bitmap, 0, 0, width, height);
    const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/jpeg", 0.78));
    if (!blob) throw new Error("Bild konnte nicht gespeichert werden.");
    return blob;
  } finally {
    bitmap.close();
  }
}

function blobToDataUrl(blob: Blob) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}

function cleanTours(tours: Tour[], finds: Find[]) {
  const known = new Set<string>([...finds.map((find) => find.id), ...PLACES.map((place) => placeStopId(place.id))]);
  return tours.map((tour) => ({
    ...tour,
    stopIds: tour.stopIds.filter((id) => known.has(id)),
  }));
}

function isFind(value: unknown): value is Find {
  if (!value || typeof value !== "object") return false;
  const row = value as Find;
  return (
    typeof row.id === "string" &&
    typeof row.name === "string" &&
    typeof row.mineral === "string" &&
    typeof row.lat === "number" &&
    typeof row.lng === "number" &&
    Array.isArray(row.photoIds)
  );
}

function isTour(value: unknown): value is Tour {
  if (!value || typeof value !== "object") return false;
  const row = value as Tour;
  return typeof row.id === "string" && typeof row.name === "string" && Array.isArray(row.stopIds);
}

export const useField = create<FieldState>((set, get) => ({
  ready: false,
  loadError: null,
  finds: [],
  tours: [],
  photoUrls: {},

  load: () => {
    if (!loadOnce) {
      loadOnce = (async () => {
        try {
          const [finds, rawTours, photos] = await Promise.all([
            getAll<Find>("finds"),
            getAll<Tour>("tours"),
            getAll<PhotoRow>("photos"),
          ]);
          for (const photo of photos) {
            if (photo?.id && photo.blob) rememberPhoto(photo.id, photo.blob);
          }
          const tours = cleanTours(rawTours, finds);
          finds.sort((a, b) => b.createdAt - a.createdAt);
          tours.sort((a, b) => b.createdAt - a.createdAt);
          set({ ready: true, finds, tours, photoUrls: { ...urls }, loadError: null });
        } catch {
          set({
            ready: true,
            loadError: "Lokaler Speicher ist nicht erreichbar. Einträge gelten nur für diesen Besuch.",
          });
        }
      })();
    }
    return loadOnce;
  },

  saveFind: async (input) => {
    const name = input.name.trim();
    if (!name) throw new Error("Name fehlt.");
    const mineral = input.mineral.trim() || "Anderes";
    if (input.keepPhotoIds.length + input.files.length > MAX_PHOTOS) {
      throw new Error("Höchstens 6 Fotos pro Fund.");
    }
    const id = input.id ?? crypto.randomUUID();
    const previous = get().finds.find((find) => find.id === id);
    const removed = (previous?.photoIds ?? []).filter((photoId) => !input.keepPhotoIds.includes(photoId));
    const photoIds = [...input.keepPhotoIds];
    for (const file of input.files) {
      if (!file.type.startsWith("image/")) throw new Error("Bitte JPEG, PNG oder WebP.");
      const blob = await compressImage(file);
      const photoId = crypto.randomUUID();
      await putRow("photos", { id: photoId, blob });
      rememberPhoto(photoId, blob);
      photoIds.push(photoId);
    }
    for (const photoId of removed) {
      await deleteRow("photos", photoId);
      forgetPhoto(photoId);
    }
    const find: Find = {
      id,
      name,
      mineral,
      notes: input.notes.trim(),
      date: input.date,
      lat: input.lat,
      lng: input.lng,
      photoIds,
      createdAt: previous?.createdAt ?? Date.now(),
    };
    await putRow("finds", find);
    const finds = [find, ...get().finds.filter((item) => item.id !== id)].sort(
      (a, b) => b.createdAt - a.createdAt,
    );
    set({ finds, photoUrls: { ...urls }, loadError: null });
    return id;
  },

  deleteFind: async (id) => {
    const find = get().finds.find((item) => item.id === id);
    if (!find) return;
    for (const photoId of find.photoIds) {
      await deleteRow("photos", photoId);
      forgetPhoto(photoId);
    }
    await deleteRow("finds", id);
    const tours = get().tours.map((tour) =>
      tour.stopIds.includes(id) ? { ...tour, stopIds: tour.stopIds.filter((stop) => stop !== id) } : tour,
    );
    for (const tour of tours) {
      if (tour.stopIds.length !== get().tours.find((item) => item.id === tour.id)?.stopIds.length) {
        await putRow("tours", tour);
      }
    }
    set({
      finds: get().finds.filter((item) => item.id !== id),
      tours,
      photoUrls: { ...urls },
    });
  },

  createTour: async () => {
    const tour: Tour = {
      id: crypto.randomUUID(),
      name: "Neue Tour",
      notes: "",
      date: todayIso(),
      stopIds: [],
      fixed: false,
      visible: true,
      createdAt: Date.now(),
    };
    await putRow("tours", tour);
    set({ tours: [tour, ...get().tours] });
    return tour.id;
  },

  patchTour: async (id, patch) => {
    const current = get().tours.find((tour) => tour.id === id);
    if (!current) return;
    const next = { ...current, ...patch };
    await putRow("tours", next);
    set({ tours: get().tours.map((tour) => (tour.id === id ? next : tour)) });
  },

  deleteTour: async (id) => {
    await deleteRow("tours", id);
    set({ tours: get().tours.filter((tour) => tour.id !== id) });
  },

  addStop: async (tourId, stopId) => {
    const tour = get().tours.find((item) => item.id === tourId);
    if (!tour || tour.fixed || tour.stopIds.includes(stopId)) return false;
    const next = { ...tour, stopIds: [...tour.stopIds, stopId] };
    await putRow("tours", next);
    set({ tours: get().tours.map((item) => (item.id === tourId ? next : item)) });
    return true;
  },

  removeStop: async (tourId, index) => {
    const tour = get().tours.find((item) => item.id === tourId);
    if (!tour || tour.fixed) return;
    const next = { ...tour, stopIds: tour.stopIds.filter((_, i) => i !== index) };
    await putRow("tours", next);
    set({ tours: get().tours.map((item) => (item.id === tourId ? next : item)) });
  },

  moveStop: async (tourId, index, dir) => {
    const tour = get().tours.find((item) => item.id === tourId);
    if (!tour || tour.fixed) return;
    const target = index + dir;
    if (target < 0 || target >= tour.stopIds.length) return;
    const stopIds = [...tour.stopIds];
    const current = stopIds[index];
    const swap = stopIds[target];
    if (current === undefined || swap === undefined) return;
    stopIds[index] = swap;
    stopIds[target] = current;
    const next = { ...tour, stopIds };
    await putRow("tours", next);
    set({ tours: get().tours.map((item) => (item.id === tourId ? next : item)) });
  },

  exportBackup: async () => {
    const photos = await getAll<PhotoRow>("photos");
    const encoded = await Promise.all(
      photos.map(async (photo) => ({ id: photo.id, dataUrl: await blobToDataUrl(photo.blob) })),
    );
    const payload = {
      app: "ader",
      version: 1,
      finds: get().finds,
      tours: get().tours,
      photos: encoded,
    };
    const blob = new Blob([JSON.stringify(payload)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `ader-sicherung-${todayIso()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  },

  importBackup: async (file) => {
    if (file.size > 40 * 1024 * 1024) throw new Error("Sicherung ist größer als 40 MB.");
    const text = await file.text();
    const data = JSON.parse(text) as {
      finds?: unknown[];
      tours?: unknown[];
      photos?: { id?: string; dataUrl?: string }[];
    };
    if (!data || !Array.isArray(data.finds)) throw new Error("Das ist keine Ader-Sicherung.");
    const existingFinds = new Set(get().finds.map((find) => find.id));
    const existingTours = new Set(get().tours.map((tour) => tour.id));
    let added = 0;
    for (const photo of data.photos ?? []) {
      if (!photo?.id || !photo.dataUrl || urls[photo.id]) continue;
      const response = await fetch(photo.dataUrl);
      const blob = await response.blob();
      await putRow("photos", { id: photo.id, blob });
      rememberPhoto(photo.id, blob);
    }
    const finds = [...get().finds];
    for (const row of data.finds) {
      if (!isFind(row) || existingFinds.has(row.id)) continue;
      const find: Find = {
        id: row.id,
        name: row.name,
        mineral: row.mineral || "Anderes",
        notes: row.notes ?? "",
        date: row.date ?? "",
        lat: row.lat,
        lng: row.lng,
        photoIds: row.photoIds.filter((id) => typeof id === "string"),
        createdAt: row.createdAt || Date.now(),
      };
      await putRow("finds", find);
      finds.push(find);
      added += 1;
    }
    const tours = [...get().tours];
    for (const row of data.tours ?? []) {
      if (!isTour(row) || existingTours.has(row.id)) continue;
      const tour: Tour = {
        id: row.id,
        name: row.name,
        notes: row.notes ?? "",
        date: row.date ?? "",
        stopIds: row.stopIds.filter((id) => typeof id === "string"),
        fixed: Boolean(row.fixed),
        visible: row.visible !== false,
        createdAt: row.createdAt || Date.now(),
      };
      await putRow("tours", tour);
      tours.push(tour);
    }
    finds.sort((a, b) => b.createdAt - a.createdAt);
    tours.sort((a, b) => b.createdAt - a.createdAt);
    set({ finds, tours: cleanTours(tours, finds), photoUrls: { ...urls } });
    return added;
  },
}));
