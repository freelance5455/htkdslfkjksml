"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  calcReducer,
  initialCalcState,
  screenFromState,
  type CalcAction,
  type CalcState,
  type HistoryItem,
} from "./calculator";
import { KEY_MAP } from "./calc-keys";

const HISTORY_KEY = "calcora_sci_history_v1";

type Sound = "digit" | "operator" | "equals" | "function" | "error";

let audioCtx: AudioContext | null = null;
function playKeySound(kind: Sound) {
  if (typeof window === "undefined") return;
  try {
    if (!audioCtx) {
      const AC =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      audioCtx = new AC();
    }
    const ac = audioCtx;
    if (ac.state === "suspended") void ac.resume();
    const freq = { digit: 660, operator: 540, equals: 880, function: 740, error: 170 }[kind];
    const osc = ac.createOscillator();
    const gain = ac.createGain();
    osc.type = kind === "error" ? "square" : "sine";
    osc.frequency.setValueAtTime(freq, ac.currentTime);
    if (kind === "equals") osc.frequency.exponentialRampToValueAtTime(freq * 1.5, ac.currentTime + 0.09);
    gain.gain.setValueAtTime(0.0001, ac.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.07, ac.currentTime + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + (kind === "error" ? 0.25 : 0.11));
    osc.connect(gain).connect(ac.destination);
    osc.start();
    osc.stop(ac.currentTime + (kind === "error" ? 0.26 : 0.12));
  } catch {
    /* audio unsupported */
  }
}

function vibrate(ms: number) {
  if (typeof navigator !== "undefined" && "vibrate" in navigator) {
    try {
      navigator.vibrate(ms);
    } catch {
      /* ignore */
    }
  }
}

function soundFor(action: CalcAction, s: CalcState): Sound {
  if (s.error) return "error";
  if (action.type === "exe") return "equals";
  if (action.type === "insert") return /^[0-9.]$/.test(action.token) ? "digit" : "operator";
  return "function";
}

const KEYBOARD: Record<string, string> = {
  "0": "d0", "1": "d1", "2": "d2", "3": "d3", "4": "d4",
  "5": "d5", "6": "d6", "7": "d7", "8": "d8", "9": "d9",
  ".": "dot", ",": "dot", "+": "add", "-": "sub", "*": "mul", x: "mul", "/": "div",
  "^": "pow", "(": "lp", ")": "rp", Enter: "exe", "=": "exe",
  Backspace: "del", Escape: "ac", Delete: "ac",
  ArrowUp: "up", ArrowDown: "down", ArrowLeft: "left", ArrowRight: "right",
  "%": "pct", s: "sin", c: "cos", t: "tan", l: "log", n: "ln", r: "sqrt",
  p: "pi", e: "e", a: "ans",
};

export function useCalculator(opts: { keyboard?: boolean; initial?: string[] } = {}) {
  const { keyboard = false, initial } = opts;
  const [state, setState] = useState<CalcState>(() => {
    if (!initial?.length) return initialCalcState;
    return calcReducer({ ...initialCalcState, tokens: initial, cursor: initial.length }, { type: "exe" }).state;
  });
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [pressedId, setPressedId] = useState<string | null>(null);
  const stateRef = useRef(state);
  const historyRef = useRef(history);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(HISTORY_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as HistoryItem[];
        if (Array.isArray(parsed)) {
          historyRef.current = parsed;
          setHistory(parsed);
        }
      }
    } catch {
      /* ignore */
    }
  }, []);

  const dispatch = useCallback((action: CalcAction, id?: string) => {
    const res = calcReducer(stateRef.current, action, historyRef.current);
    stateRef.current = res.state;
    setState(res.state);
    playKeySound(soundFor(action, res.state));
    vibrate(res.state.error ? 60 : 12);

    if (id) {
      setPressedId(id);
      if (timer.current) clearTimeout(timer.current);
      timer.current = setTimeout(() => setPressedId(null), 150);
    }

    if (res.historyEntry) {
      const next = [res.historyEntry, ...historyRef.current].slice(0, 50);
      historyRef.current = next;
      setHistory(next);
      try {
        localStorage.setItem(HISTORY_KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
    }
  }, []);

  const pressKey = useCallback(
    (id: string) => {
      const def = KEY_MAP[id];
      if (!def) return;
      const s = stateRef.current;
      const action = s.shift && def.shiftAction ? def.shiftAction : def.action;
      dispatch(action, id);
    },
    [dispatch],
  );

  const clearHistory = useCallback(() => {
    historyRef.current = [];
    setHistory([]);
    try {
      localStorage.removeItem(HISTORY_KEY);
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    if (!keyboard) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT" || target.isContentEditable))
        return;
      if (e.key === "!") {
        e.preventDefault();
        dispatch({ type: "insert", token: "!" });
        return;
      }
      const id = KEYBOARD[e.key];
      if (!id) return;
      e.preventDefault();
      pressKey(id);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [keyboard, pressKey, dispatch]);

  const screen = useMemo(() => screenFromState(state), [state]);

  return { state, screen, history, pressKey, dispatch, clearHistory, pressedId };
}
