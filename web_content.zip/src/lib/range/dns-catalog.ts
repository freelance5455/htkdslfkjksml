export type DnsFilter = "هیچ" | "بدافزار" | "خانوادگی" | "تبلیغ";

export type DnsRegion = "جهانی" | "ایران" | "آسیا" | "اروپا" | "آمریکا" | "روسیه";

export type DnsEntry = {
  id: string;
  name: string;
  provider: string;
  primary: string;
  secondary?: string;
  region: DnsRegion;
  pubg: string;
  note: string;
  doh?: string;
  dot?: string;
  gaming: boolean;
  filter: DnsFilter;
};

export const DNS_CATALOG: DnsEntry[] = [
  {
    id: "cloudflare",
    name: "Cloudflare",
    provider: "Cloudflare",
    primary: "1.1.1.1",
    secondary: "1.0.0.1",
    region: "جهانی",
    pubg: "Anycast نزدیک؛ انتخاب پیش‌فرض بازی",
    note: "بدون فیلتر محتوا. معمولاً کم‌تاخیرترین رزولور عمومی است.",
    doh: "https://cloudflare-dns.com/dns-query",
    dot: "one.one.one.one",
    gaming: true,
    filter: "هیچ",
  },
  {
    id: "cloudflare-malware",
    name: "Cloudflare بدافزار",
    provider: "Cloudflare",
    primary: "1.1.1.2",
    secondary: "1.0.0.2",
    region: "جهانی",
    pubg: "مثل ۱.۱.۱.۱ با سد دامنه‌های مخرب",
    note: "برای بازی معمولاً لازم نیست؛ اگر دامنه‌ای باز نشد به نسخهٔ بدون فیلتر برگرد.",
    doh: "https://security.cloudflare-dns.com/dns-query",
    dot: "security.cloudflare-dns.com",
    gaming: false,
    filter: "بدافزار",
  },
  {
    id: "cloudflare-family",
    name: "Cloudflare خانواده",
    provider: "Cloudflare",
    primary: "1.1.1.3",
    secondary: "1.0.0.3",
    region: "جهانی",
    pubg: "فیلتر خانواده؛ برای پابجی توصیه نمی‌شود",
    note: "ممکن است بعضی سرویس‌ها را ببندد.",
    doh: "https://family.cloudflare-dns.com/dns-query",
    dot: "family.cloudflare-dns.com",
    gaming: false,
    filter: "خانوادگی",
  },
  {
    id: "google",
    name: "Google",
    provider: "Google Public DNS",
    primary: "8.8.8.8",
    secondary: "8.8.4.4",
    region: "جهانی",
    pubg: "پایدار و جهانی؛ خط مبنا برای مقایسه",
    note: "رزولور عمومی گوگل. لاگ سیاست خودش را دارد.",
    doh: "https://dns.google/resolve",
    dot: "dns.google",
    gaming: true,
    filter: "هیچ",
  },
  {
    id: "quad9",
    name: "Quad9",
    provider: "Quad9",
    primary: "9.9.9.9",
    secondary: "149.112.112.112",
    region: "جهانی",
    pubg: "جایگزین پیشنهادی بعد از خاموشی Mullvad DNS",
    note: "دامنه‌های مخرب را سد می‌کند. از نوامبر ۲۰۲۶ سرویس عمومی Mullvad خاموش است.",
    doh: "https://dns.quad9.net/dns-query",
    dot: "dns.quad9.net",
    gaming: true,
    filter: "بدافزار",
  },
  {
    id: "quad9-raw",
    name: "Quad9 بدون فیلتر",
    provider: "Quad9",
    primary: "9.9.9.10",
    secondary: "149.112.112.10",
    region: "جهانی",
    pubg: "همان شبکه بدون سد بدافزار",
    note: "اگر نسخهٔ محافظ چیزی را بسته باشد این را امتحان کن.",
    doh: "https://dns10.quad9.net/dns-query",
    dot: "dns10.quad9.net",
    gaming: true,
    filter: "هیچ",
  },
  {
    id: "opendns",
    name: "OpenDNS",
    provider: "Cisco",
    primary: "208.67.222.222",
    secondary: "208.67.220.220",
    region: "آمریکا",
    pubg: "لبهٔ آمریکا؛ برای کلاستر اروپا معمولاً دور است",
    note: "محافظت فیشینگ سیسکو.",
    doh: "https://doh.opendns.com/dns-query",
    gaming: false,
    filter: "بدافزار",
  },
  {
    id: "opendns-family",
    name: "OpenDNS FamilyShield",
    provider: "Cisco",
    primary: "208.67.222.123",
    secondary: "208.67.220.123",
    region: "آمریکا",
    pubg: "فیلتر خانواده",
    note: "برای بازی مناسب نیست.",
    doh: "https://doh.familyshield.opendns.com/dns-query",
    gaming: false,
    filter: "خانوادگی",
  },
  {
    id: "adguard",
    name: "AdGuard",
    provider: "AdGuard",
    primary: "94.140.14.14",
    secondary: "94.140.15.15",
    region: "جهانی",
    pubg: "تبلیغ‌گیر؛ گاهی مسیر بازی را هم لمس می‌کند",
    note: "اگر لابی دیر بالا آمد، رزولور بدون فیلتر را بگذار.",
    doh: "https://dns.adguard-dns.com/dns-query",
    dot: "dns.adguard-dns.com",
    gaming: false,
    filter: "تبلیغ",
  },
  {
    id: "adguard-family",
    name: "AdGuard خانواده",
    provider: "AdGuard",
    primary: "94.140.14.15",
    secondary: "94.140.15.16",
    region: "جهانی",
    pubg: "فیلتر خانواده",
    note: "سد محتوا دارد.",
    doh: "https://dns-family.adguard-dns.com/dns-query",
    dot: "dns-family.adguard-dns.com",
    gaming: false,
    filter: "خانوادگی",
  },
  {
    id: "controld",
    name: "Control D",
    provider: "Control D",
    primary: "76.76.2.0",
    secondary: "76.76.10.0",
    region: "جهانی",
    pubg: "رزولور آزاد بدون پروفایل شخصی",
    note: "نسخهٔ رایگان بدون فیلتر. پروفایل پولی را خودت به‌صورت سفارشی اضافه کن.",
    doh: "https://freedns.controld.com/p0",
    gaming: true,
    filter: "هیچ",
  },
  {
    id: "cleanbrowsing",
    name: "CleanBrowsing امنیت",
    provider: "CleanBrowsing",
    primary: "185.228.168.9",
    secondary: "185.228.169.9",
    region: "اروپا",
    pubg: "اروپا، با سد فیشینگ",
    note: "فیلتر امنیتی سبک.",
    doh: "https://doh.cleanbrowsing.org/doh/security-filter/",
    gaming: false,
    filter: "بدافزار",
  },
  {
    id: "cleanbrowsing-family",
    name: "CleanBrowsing خانواده",
    provider: "CleanBrowsing",
    primary: "185.228.168.168",
    secondary: "185.228.169.168",
    region: "اروپا",
    pubg: "فیلتر خانواده",
    note: "برای بازی توصیه نمی‌شود.",
    doh: "https://doh.cleanbrowsing.org/doh/family-filter/",
    gaming: false,
    filter: "خانوادگی",
  },
  {
    id: "verisign",
    name: "Verisign",
    provider: "Verisign",
    primary: "64.6.64.6",
    secondary: "64.6.65.6",
    region: "آمریکا",
    pubg: "پایدار، بیشتر آمریکا",
    note: "بدون فیلتر محتوا.",
    gaming: true,
    filter: "هیچ",
  },
  {
    id: "comodo",
    name: "Comodo Secure",
    provider: "Comodo",
    primary: "8.26.56.26",
    secondary: "8.20.247.20",
    region: "آمریکا",
    pubg: "امنیتی، نه بهینهٔ بازی",
    note: "دامنه‌های مخرب را سد می‌کند.",
    gaming: false,
    filter: "بدافزار",
  },
  {
    id: "neustar",
    name: "Neustar",
    provider: "Neustar",
    primary: "156.154.70.1",
    secondary: "156.154.71.1",
    region: "آمریکا",
    pubg: "لبهٔ آمریکا",
    note: "رزولور عمومی UltraDNS / Neustar.",
    gaming: false,
    filter: "هیچ",
  },
  {
    id: "dns-sb",
    name: "DNS.SB",
    provider: "DNS.SB",
    primary: "185.222.222.222",
    secondary: "45.11.45.11",
    region: "جهانی",
    pubg: "حریم‌خصوصی‌محور و بدون فیلتر",
    note: "گزینهٔ تمیز برای مقایسه با کلادفلر.",
    doh: "https://doh.dns.sb/dns-query",
    gaming: true,
    filter: "هیچ",
  },
  {
    id: "dnswatch",
    name: "DNS.WATCH",
    provider: "DNS.WATCH",
    primary: "84.200.69.80",
    secondary: "84.200.70.40",
    region: "اروپا",
    pubg: "آلمان؛ مسیر اروپا",
    note: "بدون سانسور و بدون لاگ ادعایی خود سرویس.",
    gaming: true,
    filter: "هیچ",
  },
  {
    id: "uncensored",
    name: "UncensoredDNS",
    provider: "UncensoredDNS",
    primary: "91.239.100.100",
    secondary: "89.233.43.71",
    region: "اروپا",
    pubg: "دانمارک",
    note: "رزولور اروپایی بدون فیلتر.",
    gaming: true,
    filter: "هیچ",
  },
  {
    id: "dns4eu",
    name: "DNS4EU",
    provider: "DNS4EU",
    primary: "86.54.11.13",
    secondary: "86.54.11.213",
    region: "اروپا",
    pubg: "اروپا، نسخهٔ بدون فیلتر",
    note: "سرویس اروپایی. نسخهٔ تبلیغ‌گیر جداست و اینجا نیست.",
    doh: "https://unfiltered.joindns4.eu/dns-query",
    dot: "unfiltered.joindns4.eu",
    gaming: true,
    filter: "هیچ",
  },
  {
    id: "yandex",
    name: "Yandex",
    provider: "Yandex",
    primary: "77.88.8.8",
    secondary: "77.88.8.1",
    region: "روسیه",
    pubg: "نزدیک مسیر شمال / شرق اروپا",
    note: "حالت پایه بدون فیلتر خانواده.",
    gaming: true,
    filter: "هیچ",
  },
  {
    id: "alidns",
    name: "AliDNS",
    provider: "Alibaba",
    primary: "223.5.5.5",
    secondary: "223.6.6.6",
    region: "آسیا",
    pubg: "چین / آسیا؛ بازیکن‌ها برای کلاستر آسیا مقایسه می‌کنند",
    note: "DNS رجیستر سرور پابجی را قفل نمی‌کند؛ فقط نام‌ها را از لبهٔ نزدیک‌تر حل می‌کند.",
    doh: "https://dns.alidns.com/resolve",
    dot: "dns.alidns.com",
    gaming: true,
    filter: "هیچ",
  },
  {
    id: "dnspod",
    name: "DNSPod",
    provider: "Tencent",
    primary: "119.29.29.29",
    secondary: "119.28.28.28",
    region: "آسیا",
    pubg: "رزولور تنسنت، ناشر پابجی موبایل",
    note: "نزدیکی به اکوسیستم تنسنت به معنی انتخاب سرور بازی نیست.",
    doh: "https://doh.pub/dns-query",
    dot: "dot.pub",
    gaming: true,
    filter: "هیچ",
  },
  {
    id: "dns114",
    name: "114DNS",
    provider: "114DNS",
    primary: "114.114.114.114",
    secondary: "114.114.115.115",
    region: "آسیا",
    pubg: "چین",
    note: "رزولور عمومی قدیمی چین.",
    gaming: true,
    filter: "هیچ",
  },
  {
    id: "cnnic",
    name: "CNNIC",
    provider: "CNNIC",
    primary: "1.2.4.8",
    secondary: "210.2.4.8",
    region: "آسیا",
    pubg: "چین",
    note: "رزولور SDNS.",
    gaming: false,
    filter: "هیچ",
  },
  {
    id: "baidu",
    name: "Baidu",
    provider: "Baidu",
    primary: "180.76.76.76",
    region: "آسیا",
    pubg: "چین",
    note: "فقط آدرس اصلی عمومی.",
    gaming: false,
    filter: "هیچ",
  },
  {
    id: "onedns",
    name: "OneDNS",
    provider: "OneDNS",
    primary: "117.50.11.11",
    secondary: "117.50.22.22",
    region: "آسیا",
    pubg: "چین",
    note: "رزولور عمومی چینی.",
    gaming: false,
    filter: "هیچ",
  },
  {
    id: "he",
    name: "Hurricane Electric",
    provider: "Hurricane Electric",
    primary: "74.82.42.42",
    region: "آمریکا",
    pubg: "آمریکا؛ اغلب دور",
    note: "یک آدرس، بدون ثانویهٔ رسمی در این فهرست.",
    gaming: false,
    filter: "هیچ",
  },
  {
    id: "level3",
    name: "Level 3",
    provider: "Level 3",
    primary: "4.2.2.1",
    secondary: "4.2.2.2",
    region: "آمریکا",
    pubg: "کلاسیک آمریکایی",
    note: "از رزولورهای قدیمی و هنوز منتشر.",
    gaming: false,
    filter: "هیچ",
  },
  {
    id: "centurylink",
    name: "CenturyLink",
    provider: "CenturyLink",
    primary: "209.244.0.3",
    secondary: "209.244.0.4",
    region: "آمریکا",
    pubg: "آمریکا",
    note: "رزولور عمومی Level 3 / CenturyLink.",
    gaming: false,
    filter: "هیچ",
  },
  {
    id: "shecan",
    name: "شکن",
    provider: "Shecan",
    primary: "178.22.122.100",
    secondary: "185.51.200.2",
    region: "ایران",
    pubg: "نزدیک‌ترین رزولور عمومی داخل ایران",
    note: "فیلتر ملی را دور نمی‌زند و همان قواعد را اعمال می‌کند. برای وای‌فای یا Private DNS با نام free.shecan.ir.",
    dot: "free.shecan.ir",
    gaming: true,
    filter: "هیچ",
  },
  {
    id: "begzar",
    name: "بگذر",
    provider: "Begzar",
    primary: "185.55.226.26",
    secondary: "185.55.225.25",
    region: "ایران",
    pubg: "رزولور ایرانی برای مقایسه با شکن",
    note: "آدرس اصلی روی dns2.begzar.ir دیده شده. اگر پاسخ نداد حذفش کن و DNS خودت را اضافه کن.",
    gaming: true,
    filter: "هیچ",
  },
];

export const REGION_FILTERS = ["همه", "بازی", "ایران", "آسیا", "اروپا", "آمریکا", "جهانی", "روسیه"] as const;

export type RegionFilter = (typeof REGION_FILTERS)[number];

export function dnsPair(entry: DnsEntry): string {
  return [entry.primary, entry.secondary].filter(Boolean).join(", ");
}

export function findDns(id: string, customs: DnsEntry[]): DnsEntry {
  return DNS_CATALOG.find((item) => item.id === id) ?? customs.find((item) => item.id === id) ?? DNS_CATALOG[0];
}

export function recommendIds(countryCode?: string): string[] {
  if (countryCode === "IR") return ["shecan", "begzar", "cloudflare", "dnspod", "alidns", "google"];
  if (countryCode && ["CN", "HK", "TW", "SG", "MY", "TH", "VN", "ID", "PH"].includes(countryCode)) {
    return ["alidns", "dnspod", "dns114", "cloudflare", "google"];
  }
  if (countryCode && ["DE", "NL", "FR", "GB", "SE", "PL", "IT", "ES", "FI", "NO", "DK", "AT", "CH"].includes(countryCode)) {
    return ["cloudflare", "quad9-raw", "dns-sb", "dns4eu", "google", "dnswatch"];
  }
  if (countryCode && ["US", "CA", "MX"].includes(countryCode)) {
    return ["cloudflare", "google", "quad9-raw", "verisign", "dns-sb"];
  }
  return ["cloudflare", "google", "quad9-raw", "dns-sb", "adguard", "opendns"];
}

const IPV4 = /^(25[0-5]|2[0-4]\d|1?\d?\d)(\.(25[0-5]|2[0-4]\d|1?\d?\d)){3}$/;

export function isIpv4(value: string): boolean {
  return IPV4.test(value.trim());
}

export function isPrivateIpv4(value: string): boolean {
  const parts = value.split(".").map(Number);
  if (parts.length !== 4 || parts.some((n) => Number.isNaN(n))) return false;
  const [a, b] = parts;
  if (a === 10 || a === 127) return true;
  if (a === 192 && b === 168) return true;
  if (a === 172 && b >= 16 && b <= 31) return true;
  return false;
}
