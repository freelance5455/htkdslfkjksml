export type Geo = {
  ip: string;
  country: string;
  countryCode: string;
  city: string;
};

export type Beacon = {
  id: string;
  name: string;
  region: string;
  url: string;
  kind: "opaque" | "doh";
};

export const PATH_BEACONS: Beacon[] = [
  {
    id: "google-edge",
    name: "لبهٔ گوگل",
    region: "جهانی",
    url: "https://www.gstatic.com/generate_204",
    kind: "opaque",
  },
  {
    id: "cf-edge",
    name: "لبهٔ کلادفلر",
    region: "جهانی",
    url: "https://www.cloudflare.com/cdn-cgi/trace",
    kind: "opaque",
  },
  {
    id: "ms-edge",
    name: "لبهٔ مایکروسافت",
    region: "جهانی",
    url: "https://www.msftconnecttest.com/connecttest.txt",
    kind: "opaque",
  },
  {
    id: "ali-edge",
    name: "AliDNS",
    region: "آسیا",
    url: "https://dns.alidns.com/resolve",
    kind: "doh",
  },
  {
    id: "tencent-edge",
    name: "DNSPod تنسنت",
    region: "آسیا",
    url: "https://doh.pub/dns-query",
    kind: "doh",
  },
];

function withTimeout(signal: AbortSignal | undefined, ms: number): AbortSignal {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  const onAbort = () => ctrl.abort();
  signal?.addEventListener("abort", onAbort);
  ctrl.signal.addEventListener("abort", () => {
    clearTimeout(timer);
    signal?.removeEventListener("abort", onAbort);
  });
  return ctrl.signal;
}

export async function measureDoH(doh: string, signal?: AbortSignal): Promise<number | null> {
  const started = performance.now();
  try {
    const url = new URL(doh);
    url.searchParams.set("name", "pubgmobile.com");
    url.searchParams.set("type", "A");
    url.searchParams.set("ct", String(Date.now()));
    const headers: HeadersInit = {};
    if (doh.includes("dns-query") || doh.includes("freedns.controld.com") || doh.includes("cleanbrowsing.org")) {
      headers.Accept = "application/dns-json";
    }
    const res = await fetch(url.toString(), {
      signal: withTimeout(signal, 5000),
      cache: "no-store",
      headers,
    });
    if (!res.ok) return null;
    await res.arrayBuffer();
    return Math.max(1, Math.round(performance.now() - started));
  } catch {
    return null;
  }
}

export async function measureOpaque(url: string, signal?: AbortSignal): Promise<number | null> {
  const started = performance.now();
  try {
    await fetch(`${url}${url.includes("?") ? "&" : "?"}ct=${Date.now()}`, {
      mode: "no-cors",
      cache: "no-store",
      signal: withTimeout(signal, 5000),
    });
    return Math.max(1, Math.round(performance.now() - started));
  } catch {
    return null;
  }
}

export async function measureBeacon(beacon: Beacon, signal?: AbortSignal): Promise<number | null> {
  if (beacon.kind === "doh") return measureDoH(beacon.url, signal);
  return measureOpaque(beacon.url, signal);
}

export async function fetchGeo(signal?: AbortSignal): Promise<Geo | null> {
  const local = withTimeout(signal, 6000);
  try {
    const res = await fetch("https://get.geojs.io/v1/ip/geo.json", { signal: local, cache: "no-store" });
    if (res.ok) {
      const data = (await res.json()) as {
        ip?: string;
        country?: string;
        country_code?: string;
        city?: string;
      };
      if (data.country_code) {
        return {
          ip: String(data.ip ?? ""),
          country: String(data.country ?? ""),
          countryCode: String(data.country_code),
          city: String(data.city ?? ""),
        };
      }
    }
  } catch {
    /* try fallback */
  }

  try {
    const res = await fetch("https://ipwho.is/", { signal: withTimeout(signal, 6000), cache: "no-store" });
    if (!res.ok) return null;
    const data = (await res.json()) as {
      success?: boolean;
      ip?: string;
      country?: string;
      country_code?: string;
      city?: string;
    };
    if (!data.success || !data.country_code) return null;
    return {
      ip: String(data.ip ?? ""),
      country: String(data.country ?? ""),
      countryCode: String(data.country_code),
      city: String(data.city ?? ""),
    };
  } catch {
    return null;
  }
}

export async function copyText(text: string): Promise<void> {
  try {
    await navigator.clipboard.writeText(text);
    return;
  } catch {
    /* fallback for webviews */
  }
  const area = document.createElement("textarea");
  area.value = text;
  area.setAttribute("readonly", "true");
  area.style.position = "fixed";
  area.style.opacity = "0";
  document.body.appendChild(area);
  area.select();
  document.execCommand("copy");
  area.remove();
}

export function downloadText(filename: string, text: string, type = "text/plain;charset=utf-8"): void {
  const blob = new Blob([text], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}
