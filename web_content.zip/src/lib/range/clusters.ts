export type Cluster = {
  id: string;
  title: string;
  hint: string;
  codes: string[];
};

export const CLUSTERS: Cluster[] = [
  {
    id: "me",
    title: "خاورمیانه",
    hint: "معمولاً دبی یا بحرین. برای ایران رایج‌ترین خوشه است، نه تضمین.",
    codes: ["IR", "IQ", "AE", "SA", "QA", "KW", "BH", "OM", "JO", "LB", "SY", "YE", "TR", "EG", "IL", "PS"],
  },
  {
    id: "asia",
    title: "آسیا",
    hint: "اغلب سنگاپور. رزولور چینی فقط مسیر نام را عوض می‌کند.",
    codes: ["SG", "MY", "ID", "TH", "VN", "PH", "HK", "TW", "CN", "MO", "KH", "LA", "MM"],
  },
  {
    id: "krjp",
    title: "کره و ژاپن",
    hint: "سئول یا توکیو.",
    codes: ["KR", "JP"],
  },
  {
    id: "in",
    title: "جنوب آسیا",
    hint: "اغلب بمبئی.",
    codes: ["IN", "PK", "BD", "LK", "NP"],
  },
  {
    id: "eu",
    title: "اروپا",
    hint: "فرانکفورت یا آمستردام.",
    codes: ["DE", "NL", "FR", "GB", "SE", "PL", "IT", "ES", "FI", "NO", "DK", "AT", "CH", "BE", "CZ", "RO", "UA", "HU", "PT", "IE", "GR", "BG", "HR", "SK", "LT", "LV", "EE", "LU", "SI"],
  },
  {
    id: "na",
    title: "آمریکای شمالی",
    hint: "ویرجینیا یا ساحل غرب.",
    codes: ["US", "CA", "MX"],
  },
  {
    id: "sa",
    title: "آمریکای جنوبی",
    hint: "اغلب سائوپائولو.",
    codes: ["BR", "AR", "CL", "CO", "PE", "VE", "UY", "EC"],
  },
  {
    id: "oc",
    title: "اقیانوسیه",
    hint: "سیدنی.",
    codes: ["AU", "NZ"],
  },
  {
    id: "af",
    title: "آفریقا",
    hint: "اغلب به اروپا یا خاورمیانه نزدیک می‌شود.",
    codes: ["ZA", "NG", "KE", "MA", "DZ", "TN", "GH", "ET"],
  },
];

const FA_COUNTRY: Record<string, string> = {
  IR: "ایران",
  IQ: "عراق",
  AE: "امارات",
  SA: "عربستان",
  QA: "قطر",
  KW: "کویت",
  BH: "بحرین",
  OM: "عمان",
  JO: "اردن",
  LB: "لبنان",
  SY: "سوریه",
  YE: "یمن",
  TR: "ترکیه",
  EG: "مصر",
  DE: "آلمان",
  NL: "هلند",
  FR: "فرانسه",
  GB: "بریتانیا",
  SE: "سوئد",
  PL: "لهستان",
  IT: "ایتالیا",
  ES: "اسپانیا",
  FI: "فنلاند",
  NO: "نروژ",
  DK: "دانمارک",
  AT: "اتریش",
  CH: "سوئیس",
  US: "آمریکا",
  CA: "کانادا",
  MX: "مکزیک",
  SG: "سنگاپور",
  MY: "مالزی",
  ID: "اندونزی",
  TH: "تایلند",
  VN: "ویتنام",
  PH: "فیلیپین",
  HK: "هنگ‌کنگ",
  TW: "تایوان",
  CN: "چین",
  KR: "کره",
  JP: "ژاپن",
  IN: "هند",
  PK: "پاکستان",
  BR: "برزیل",
  AU: "استرالیا",
  RU: "روسیه",
  UA: "اوکراین",
};

export function countryFa(code?: string, fallback?: string): string {
  if (!code) return fallback || "نامشخص";
  return FA_COUNTRY[code] ?? fallback ?? code;
}

export function clusterFor(code?: string): Cluster | null {
  if (!code) return null;
  return CLUSTERS.find((item) => item.codes.includes(code)) ?? null;
}

export const REGISTER_NOTE =
  "رجیستر را خود پابجی با UDP و موقعیت شبکه انتخاب می‌کند. این درخت خوشهٔ محتمل را از کشور خروجی اینترنتت نشان می‌دهد، نه سروری که بازی قفل کرده باشد. DNS آن را عوض نمی‌کند.";
