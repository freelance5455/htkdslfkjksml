import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { DnsEntry } from "@/lib/range/dns-catalog";
import type { Geo } from "@/lib/range/net";
import type { Mode, WgProfile } from "@/lib/range/wireguard";

export type Operator = {
  name: string;
  device: string;
  fps: number;
};

export type PingHit = {
  ms: number | null;
  at: number;
};

type RangeState = {
  mode: Mode;
  dnsId: string;
  wgId: string | null;
  profiles: WgProfile[];
  customs: DnsEntry[];
  operator: Operator;
  pings: Record<string, PingHit>;
  paths: Record<string, PingHit>;
  geo: (Geo & { at: number }) | null;
  setMode: (mode: Mode) => void;
  selectDns: (id: string) => void;
  selectWg: (id: string | null) => void;
  addProfile: (profile: WgProfile) => void;
  removeProfile: (id: string) => void;
  addCustom: (entry: DnsEntry) => void;
  removeCustom: (id: string) => void;
  setOperator: (patch: Partial<Operator>) => void;
  setPing: (id: string, ms: number | null) => void;
  setPath: (id: string, ms: number | null) => void;
  setGeo: (geo: Geo | null) => void;
};

export const useRange = create<RangeState>()(
  persist(
    (set) => ({
      mode: "both",
      dnsId: "cloudflare",
      wgId: null,
      profiles: [],
      customs: [],
      operator: {
        name: "محمد طیب بهزادی شریف",
        device: "REDMI 14C",
        fps: 40,
      },
      pings: {},
      paths: {},
      geo: null,
      setMode: (mode) => set({ mode }),
      selectDns: (dnsId) => set({ dnsId }),
      selectWg: (wgId) => set({ wgId }),
      addProfile: (profile) =>
        set((state) => ({
          profiles: [profile, ...state.profiles].slice(0, 12),
          wgId: profile.id,
        })),
      removeProfile: (id) =>
        set((state) => ({
          profiles: state.profiles.filter((item) => item.id !== id),
          wgId: state.wgId === id ? null : state.wgId,
        })),
      addCustom: (entry) =>
        set((state) => ({
          customs: [entry, ...state.customs].slice(0, 30),
          dnsId: entry.id,
        })),
      removeCustom: (id) =>
        set((state) => ({
          customs: state.customs.filter((item) => item.id !== id),
          dnsId: state.dnsId === id ? "cloudflare" : state.dnsId,
        })),
      setOperator: (patch) => set((state) => ({ operator: { ...state.operator, ...patch } })),
      setPing: (id, ms) =>
        set((state) => ({
          pings: { ...state.pings, [id]: { ms, at: Date.now() } },
        })),
      setPath: (id, ms) =>
        set((state) => ({
          paths: { ...state.paths, [id]: { ms, at: Date.now() } },
        })),
      setGeo: (geo) => set({ geo: geo ? { ...geo, at: Date.now() } : null }),
    }),
    {
      name: "sharif-range-v1",
      skipHydration: true,
    },
  ),
);
