export type Mode = "dns" | "wg" | "both";

export type ParsedWg = {
  privateKey?: string;
  address?: string;
  dns?: string;
  mtu?: string;
  publicKey?: string;
  endpoint?: string;
  allowedIps?: string;
  keepalive?: string;
  errors: string[];
};

export type WgProfile = {
  id: string;
  name: string;
  raw: string;
  createdAt: number;
};

const KEY_RE = /^[A-Za-z0-9+/]{43}=$/;

export function parseWg(raw: string): ParsedWg {
  const errors: string[] = [];
  const map: Record<string, string> = {};
  let section = "";
  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#") || trimmed.startsWith(";")) continue;
    const header = trimmed.match(/^\[(.+)]$/);
    if (header) {
      section = header[1].trim().toLowerCase();
      continue;
    }
    const kv = trimmed.match(/^([^=]+)=(.*)$/);
    if (!kv || !section) continue;
    const key = `${section}.${kv[1].trim().toLowerCase()}`;
    if (map[key] === undefined) map[key] = kv[2].trim();
  }

  const privateKey = map["interface.privatekey"];
  const publicKey = map["peer.publickey"];
  if (!privateKey) errors.push("PrivateKey داخل [Interface] نیست.");
  else if (!KEY_RE.test(privateKey)) errors.push("PrivateKey شکل کلید WireGuard را ندارد.");
  if (!publicKey) errors.push("PublicKey داخل [Peer] نیست.");
  else if (!KEY_RE.test(publicKey)) errors.push("PublicKey نامعتبر است.");
  if (!map["interface.address"]) errors.push("Address نیست.");
  if (!map["peer.endpoint"]) errors.push("Endpoint نیست.");

  return {
    privateKey,
    address: map["interface.address"],
    dns: map["interface.dns"],
    mtu: map["interface.mtu"],
    publicKey,
    endpoint: map["peer.endpoint"],
    allowedIps: map["peer.allowedips"],
    keepalive: map["peer.persistentkeepalive"],
    errors,
  };
}

export function maskKey(value?: string): string {
  if (!value) return "—";
  if (value.length < 10) return "••••";
  return `${value.slice(0, 4)}…${value.slice(-4)}`;
}

export function applyDns(raw: string, dnsValue: string): string {
  const lines = raw.replace(/\r\n/g, "\n").split("\n");
  let section: "interface" | "other" | "none" = "none";
  let wrote = false;
  const out: string[] = [];

  const flush = () => {
    if (section === "interface" && !wrote) {
      out.push(`DNS = ${dnsValue}`);
      wrote = true;
    }
  };

  for (const line of lines) {
    const trimmed = line.trim();
    if (/^\[/.test(trimmed)) {
      flush();
      section = trimmed.toLowerCase() === "[interface]" ? "interface" : "other";
      out.push(line);
      continue;
    }
    if (section === "interface" && /^dns\s*=/i.test(trimmed)) {
      if (!wrote) {
        out.push(`DNS = ${dnsValue}`);
        wrote = true;
      }
      continue;
    }
    out.push(line);
  }
  flush();
  return `${out.join("\n").replace(/\n{3,}/g, "\n\n").trim()}\n`;
}

export function confForMode(raw: string, dnsValue: string, mode: Mode): string {
  if (mode === "both") return applyDns(raw, dnsValue);
  return raw.endsWith("\n") ? raw : `${raw}\n`;
}

export function endpointHost(endpoint?: string): string {
  if (!endpoint) return "وایرگارد";
  return endpoint.replace(/:\d+$/, "");
}
