/**
 * Programmatic navigation that also works in the packaged static build.
 *
 * The static export emits flat `*.html` files, so a plain `router.push("/x")`
 * would point at a path that neither a static server nor a `file://` WebView
 * can resolve. In that build we hard-navigate to the matching file instead;
 * everywhere else the normal Next.js router is used.
 */
export function goTo(router: { push: (href: string) => void }, href: string): void {
  if (process.env.NEXT_PUBLIC_STATIC_EXPORT === "1" && typeof window !== "undefined") {
    const url = new URL(href, window.location.href);
    const path = url.pathname.replace(/\/+$/, "");
    const file = path === "" ? "index" : path.slice(1);
    window.location.assign(`${file}.html${url.search}${url.hash}`);
    return;
  }
  router.push(href);
}
