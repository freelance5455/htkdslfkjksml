export type DayKind = "upper-a" | "lower-a" | "rest" | "upper-b" | "lower-b";

export type Exercise = {
  id: string;
  name: string;
  variants?: string[];
  sets: number;
  reps: string;
  restSec: number;
  target: string;
  perSide?: boolean;
};

export type CardioBlock = {
  duration: string;
  durationHint: string;
  incline: string;
  inclineRange: [number, number];
  inclineMax: number;
  speed: string;
  note: string;
};

export type Session = {
  kind: DayKind;
  weekday: number;
  dayName: string;
  shortName: string;
  code: string;
  title: string;
  kicker: string;
  blurb: string;
  duration: string;
  isTraining: boolean;
  exercises: Exercise[];
  cardio?: CardioBlock;
};

const CARDIO_NOTE =
  "Amaç maksimum kalori yakmak değil — ağırlık performansını öldürmeden ekstra enerji harcamak. Aynı tempoda rahatladıkça süreyi uzatırız.";

export const PROGRAM: Record<number, Session> = {
  1: {
    kind: "upper-a",
    weekday: 1,
    dayName: "Pazartesi",
    shortName: "Pzt",
    code: "UA",
    title: "Upper A",
    kicker: "Üst vücut + kardiyo",
    blurb: "Göğüs, sırt, omuz ve kol. Treadmill ile kapanış.",
    duration: "70 dk",
    isTraining: true,
    exercises: [
      { id: "ua-bench", name: "Bench Press", sets: 3, reps: "6–8", restSec: 120, target: "Göğüs" },
      { id: "ua-lat", name: "Lat Pulldown", sets: 3, reps: "8–12", restSec: 90, target: "Sırt" },
      { id: "ua-incline-db", name: "Incline Dumbbell Press", sets: 3, reps: "8–12", restSec: 90, target: "Göğüs" },
      { id: "ua-row", name: "Seated Cable Row", sets: 3, reps: "8–12", restSec: 90, target: "Sırt" },
      { id: "ua-raise", name: "Lateral Raise", sets: 3, reps: "12–20", restSec: 60, target: "Omuz" },
      { id: "ua-pushdown", name: "Triceps Pushdown", sets: 2, reps: "10–15", restSec: 60, target: "Triceps" },
      { id: "ua-curl", name: "Dumbbell Curl", sets: 2, reps: "10–15", restSec: 60, target: "Biceps" },
    ],
    cardio: {
      duration: "20–25 dk",
      durationHint: "Kısa tempolu yürüyüş",
      incline: "5–7 / 12",
      inclineRange: [5, 7],
      inclineMax: 12,
      speed: "4–5 km/s",
      note: CARDIO_NOTE,
    },
  },
  2: {
    kind: "lower-a",
    weekday: 2,
    dayName: "Salı",
    shortName: "Sal",
    code: "LA",
    title: "Lower A",
    kicker: "Bacak · squat odaklı",
    blurb: "Ağır squat varyasyonu, arka zincir ve izolasyon.",
    duration: "55 dk",
    isTraining: true,
    exercises: [
      {
        id: "la-squat",
        name: "Squat",
        variants: ["Squat", "Hack Squat"],
        sets: 3,
        reps: "6–10",
        restSec: 150,
        target: "Quad",
      },
      { id: "la-rdl", name: "Romanian Deadlift", sets: 3, reps: "8–10", restSec: 120, target: "Hamstring" },
      { id: "la-press", name: "Leg Press", sets: 3, reps: "10–15", restSec: 90, target: "Quad" },
      { id: "la-curl", name: "Leg Curl", sets: 3, reps: "10–15", restSec: 75, target: "Hamstring" },
      { id: "la-ext", name: "Leg Extension", sets: 2, reps: "12–15", restSec: 60, target: "Quad" },
      { id: "la-calf", name: "Calf Raise", sets: 3, reps: "10–15", restSec: 60, target: "Baldır" },
    ],
  },
  3: {
    kind: "rest",
    weekday: 3,
    dayName: "Çarşamba",
    shortName: "Çar",
    code: "OFF",
    title: "Dinlenme",
    kicker: "Tamamen off",
    blurb: "Kaslar salonda kırılır, dinlenmede büyür.",
    duration: "—",
    isTraining: false,
    exercises: [],
  },
  4: {
    kind: "upper-b",
    weekday: 4,
    dayName: "Perşembe",
    shortName: "Per",
    code: "UB",
    title: "Upper B",
    kicker: "Üst vücut + kardiyo",
    blurb: "Incline pres ve çekiş odaklı ikinci üst gün.",
    duration: "75 dk",
    isTraining: true,
    exercises: [
      { id: "ub-incline", name: "Incline Bench Press", sets: 3, reps: "6–10", restSec: 120, target: "Göğüs" },
      {
        id: "ub-lat",
        name: "Lat Pulldown",
        variants: ["Lat Pulldown", "Pull-up"],
        sets: 3,
        reps: "8–12",
        restSec: 90,
        target: "Sırt",
      },
      { id: "ub-chest", name: "Machine Chest Press", sets: 3, reps: "8–12", restSec: 90, target: "Göğüs" },
      { id: "ub-row", name: "Chest-Supported Row", sets: 3, reps: "8–12", restSec: 90, target: "Sırt" },
      { id: "ub-raise", name: "Lateral Raise", sets: 3, reps: "12–20", restSec: 60, target: "Omuz" },
      { id: "ub-oh", name: "Overhead Triceps Extension", sets: 2, reps: "10–15", restSec: 60, target: "Triceps" },
      { id: "ub-curl", name: "Incline Dumbbell Curl", sets: 2, reps: "10–15", restSec: 60, target: "Biceps" },
    ],
    cardio: {
      duration: "25–35 dk",
      durationHint: "Biraz daha uzun yürüyüş",
      incline: "5–7 / 12",
      inclineRange: [5, 7],
      inclineMax: 12,
      speed: "4–5 km/s",
      note: CARDIO_NOTE,
    },
  },
  5: {
    kind: "rest",
    weekday: 5,
    dayName: "Cuma",
    shortName: "Cum",
    code: "OFF",
    title: "Dinlenme",
    kicker: "Tamamen off",
    blurb: "Yarın yok — sonraki seans cumartesi Lower B.",
    duration: "—",
    isTraining: false,
    exercises: [],
  },
  6: {
    kind: "lower-b",
    weekday: 6,
    dayName: "Cumartesi",
    shortName: "Cmt",
    code: "LB",
    title: "Lower B",
    kicker: "Bacak · hacim odaklı",
    blurb: "Hack / split squat, unilateral iş ve izolasyon.",
    duration: "55 dk",
    isTraining: true,
    exercises: [
      {
        id: "lb-hack",
        name: "Hack Squat",
        variants: ["Hack Squat", "Leg Press"],
        sets: 3,
        reps: "8–12",
        restSec: 120,
        target: "Quad",
      },
      { id: "lb-rdl", name: "Romanian Deadlift", sets: 3, reps: "8–12", restSec: 120, target: "Hamstring" },
      {
        id: "lb-split",
        name: "Bulgarian Split Squat",
        sets: 2,
        reps: "8–12",
        restSec: 90,
        target: "Quad",
        perSide: true,
      },
      { id: "lb-curl", name: "Seated Leg Curl", sets: 3, reps: "10–15", restSec: 75, target: "Hamstring" },
      { id: "lb-ext", name: "Leg Extension", sets: 2, reps: "12–15", restSec: 60, target: "Quad" },
      { id: "lb-calf", name: "Seated Calf Raise", sets: 3, reps: "10–15", restSec: 60, target: "Baldır" },
    ],
  },
  0: {
    kind: "rest",
    weekday: 0,
    dayName: "Pazar",
    shortName: "Paz",
    code: "OFF",
    title: "Dinlenme",
    kicker: "Haftayı kapat",
    blurb: "Yarın Upper A ile yeni hafta başlar.",
    duration: "—",
    isTraining: false,
    exercises: [],
  },
};

export const WEEK_RHYTHM = [
  { code: "UA", label: "Upper" },
  { code: "LA", label: "Lower" },
  { code: "OFF", label: "Dinlen" },
  { code: "UB", label: "Upper" },
  { code: "OFF", label: "Dinlen" },
  { code: "LB", label: "Lower" },
  { code: "OFF", label: "Dinlen" },
] as const;

export const TRAINING_DAYS_PER_WEEK = 4;

export function sessionForDate(date: Date): Session {
  return PROGRAM[date.getDay()] ?? PROGRAM[0];
}

export function nextTraining(from: Date): Session {
  for (let i = 1; i <= 7; i += 1) {
    const d = new Date(from);
    d.setDate(from.getDate() + i);
    const session = sessionForDate(d);
    if (session.isTraining) return session;
  }
  return PROGRAM[1];
}

export function formatRest(sec: number): string {
  if (sec < 60) return `${sec} sn`;
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return s === 0 ? `${m} dk` : `${m}:${String(s).padStart(2, "0")}`;
}

export function parseWeight(value: string): number {
  const n = Number(value.replace(",", "."));
  return Number.isFinite(n) ? n : 0;
}

export function sessionVolume(sets: { weight: string; reps: string; done: boolean }[]): number {
  return sets.reduce((sum, set) => {
    if (!set.done) return sum;
    const reps = Number(set.reps);
    return sum + parseWeight(set.weight) * (Number.isFinite(reps) ? reps : 0);
  }, 0);
}
