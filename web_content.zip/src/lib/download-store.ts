import { create } from "zustand";
import { probePlayback } from "@/lib/codecs";
import { idbAll, idbDelete, idbPut } from "@/lib/idb";
import { useLibrary } from "@/lib/library-store";
import type { DownloadRecord } from "@/lib/media-types";
import { basename, slugId } from "@/lib/utils";

type DownloadState = {
  items: DownloadRecord[];
  ready: boolean;
  hydrate: () => Promise<void>;
  enqueue: (url: string, name?: string) => Promise<string | null>;
  pause: (id: string) => void;
  resume: (id: string) => void;
  cancel: (id: string) => void;
  remove: (id: string) => void;
};

const controllers = new Map<string, AbortController>();
const paused = new Set<string>();

const DIRECT_EXT = /\.(mp4|webm|ogg|ogv|mp3|wav|m4a|aac|flac|opus|mov|m4v)(\?|$)/i;

function looksDirect(url: string): boolean {
  return DIRECT_EXT.test(url);
}

async function persist(rec: DownloadRecord) {
  await idbPut("downloads", rec);
}

function patch(id: string, partial: Partial<DownloadRecord>) {
  useDownloads.setState((s) => ({
    items: s.items.map((i) => (i.id === id ? { ...i, ...partial } : i)),
  }));
  const rec = useDownloads.getState().items.find((i) => i.id === id);
  if (rec) void persist(rec);
}

async function runDownload(id: string) {
  const rec = useDownloads.getState().items.find((i) => i.id === id);
  if (!rec) return;
  if (!looksDirect(rec.url) && !rec.url.startsWith("blob:")) {
    patch(id, {
      status: "error",
      error: "This is not a direct media URL. UPLAY.IND will not extract media from web pages.",
      finishedAt: Date.now(),
    });
    return;
  }
  const controller = new AbortController();
  controllers.set(id, controller);
  patch(id, { status: "running", error: undefined });
  try {
    const res = await fetch(rec.url, { signal: controller.signal });
    if (!res.ok) {
      throw new Error(`Download failed (${res.status}).`);
    }
    const type = res.headers.get("content-type") || "";
    if (type.includes("text/html")) {
      throw new Error("This URL returned a web page, not a media file. Direct media URLs only.");
    }
    const total = Number(res.headers.get("content-length") || rec.total || 0);
    if (!res.body) {
      const blob = await res.blob();
      await finishBlob(id, rec.name, blob, rec.url);
      return;
    }
    const reader = res.body.getReader();
    const chunks: BlobPart[] = [];
    let received = 0;
    while (true) {
      if (paused.has(id)) {
        controller.abort();
        patch(id, { status: "paused", received, total });
        return;
      }
      const { done, value } = await reader.read();
      if (done) break;
      if (value) {
        chunks.push(value.slice());
        received += value.byteLength;
        patch(id, { received, total });
      }
    }
    const blob = new Blob(chunks, { type: type || "application/octet-stream" });
    await finishBlob(id, rec.name, blob, rec.url);
  } catch (err) {
    if (paused.has(id)) {
      patch(id, { status: "paused" });
      return;
    }
    const message =
      err instanceof DOMException && err.name === "AbortError"
        ? undefined
        : err instanceof Error
          ? err.message
          : "Download failed.";
    const current = useDownloads.getState().items.find((i) => i.id === id);
    if (current?.status === "cancelled") return;
    patch(id, {
      status: "error",
      error: message || "Download was interrupted.",
      finishedAt: Date.now(),
    });
  } finally {
    controllers.delete(id);
  }
}

async function finishBlob(id: string, name: string, blob: Blob, url: string) {
  const filename = name || basename(url.split("?")[0] ?? "download");
  const file = new File([blob], filename, { type: blob.type });
  const probe = probePlayback(filename, blob.type);
  if (!probe.playable) {
    triggerSave(file);
    patch(id, {
      status: "done",
      received: blob.size,
      total: blob.size,
      finishedAt: Date.now(),
    });
    return;
  }
  await useLibrary.getState().addFiles([file]);
  const added = useLibrary.getState().items.find((i) => i.name === filename);
  if (added) {
    const updated = { ...added, source: "download" as const, url };
    useLibrary.setState((s) => ({
      items: s.items.map((i) => (i.id === added.id ? updated : i)),
    }));
  }
  triggerSave(file);
  patch(id, {
    status: "done",
    received: blob.size,
    total: blob.size,
    finishedAt: Date.now(),
    mediaId: added?.id,
  });
}

function triggerSave(file: File) {
  try {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(file);
    a.download = file.name;
    a.rel = "noopener";
    a.click();
    window.setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  } catch {
    /* user can still play from the library */
  }
}

function pumpQueue() {
  const { items } = useDownloads.getState();
  const running = items.filter((i) => i.status === "running").length;
  const max = 2;
  const next = items.find((i) => i.status === "queued");
  if (next && running < max) void runDownload(next.id);
}

export const useDownloads = create<DownloadState>((set, get) => ({
  items: [],
  ready: false,
  hydrate: async () => {
    try {
      const items = await idbAll<DownloadRecord>("downloads");
      set({ items, ready: true });
    } catch {
      set({ ready: true });
    }
  },
  enqueue: async (url, name) => {
    const trimmed = url.trim();
    if (!trimmed) return null;
    try {
      new URL(trimmed);
    } catch {
      return null;
    }
    if (!looksDirect(trimmed)) {
      const rec: DownloadRecord = {
        id: slugId(),
        name: name || basename(trimmed),
        url: trimmed,
        status: "error",
        received: 0,
        total: 0,
        error: "Not a direct media URL. Paste a link that ends in mp4, webm, mp3, etc.",
        startedAt: Date.now(),
        finishedAt: Date.now(),
      };
      await persist(rec);
      set({ items: [rec, ...get().items] });
      return rec.id;
    }
    const rec: DownloadRecord = {
      id: slugId(),
      name: name || basename(trimmed.split("?")[0] ?? "media"),
      url: trimmed,
      status: "queued",
      received: 0,
      total: 0,
      startedAt: Date.now(),
    };
    await persist(rec);
    set({ items: [rec, ...get().items] });
    pumpQueue();
    return rec.id;
  },
  pause: (id) => {
    paused.add(id);
    controllers.get(id)?.abort();
    patch(id, { status: "paused" });
  },
  resume: (id) => {
    paused.delete(id);
    patch(id, { status: "queued" });
    pumpQueue();
  },
  cancel: (id) => {
    paused.delete(id);
    controllers.get(id)?.abort();
    patch(id, { status: "cancelled", finishedAt: Date.now() });
  },
  remove: (id) => {
    paused.delete(id);
    controllers.get(id)?.abort();
    void idbDelete("downloads", id);
    set({ items: get().items.filter((i) => i.id !== id) });
  },
}));
