import {
  type Entry,
  type Settings,
  type Summary,
  formatEntryDate,
  formatHours,
  formatLongDate,
  inr,
} from "@/lib/hajiri/model";

const FONT = '"Noto Sans Devanagari", sans-serif';
const DISPLAY = '"Tiro Devanagari Hindi", "Noto Sans Devanagari", serif';

export type PdfSection = {
  monthLabel: string;
  entries: Entry[];
  summary: Summary;
};

type PdfArgs = {
  filename: string;
  name: string;
  place: string;
  settings: Settings;
  sections: PdfSection[];
  preparedOn: Date;
};

function el(tag: string, css: string, text?: string): HTMLElement {
  const node = document.createElement(tag);
  node.style.cssText = css;
  if (text !== undefined) node.textContent = text;
  return node;
}

function clip(text: string, max: number): string {
  const trimmed = text.trim();
  if (!trimmed) return "—";
  if (trimmed.length <= max) return trimmed;
  return `${trimmed.slice(0, max - 1)}…`;
}

function buildPage(args: PdfArgs, section: PdfSection, pageNo: number, pageCount: number): HTMLElement {
  const root = el(
    "div",
    `box-sizing:border-box;width:720px;padding:28px 28px 24px 32px;background:#fbf7ef;color:#1c1914;font-family:${FONT};font-size:14px;line-height:1.45;border-left:8px solid #8d342c;`,
  );

  const head = el("div", "display:flex;justify-content:space-between;gap:16px;align-items:flex-start;");
  const titles = el("div", "min-width:0;");
  titles.append(el("div", `font-family:${DISPLAY};font-size:32px;line-height:1.1;`, "मेरी हाजिरी"));
  titles.append(
    el("div", "margin-top:4px;font-size:16px;font-weight:700;", section.monthLabel),
  );
  if (pageCount > 1) {
    titles.append(el("div", "margin-top:2px;color:#6f675c;font-size:12px;", `पन्ना ${pageNo} / ${pageCount}`));
  }
  head.append(titles);

  const seal = el(
    "div",
    "width:58px;height:58px;border:2px solid #146047;border-radius:50%;display:flex;align-items:center;justify-content:center;flex:none;",
  );
  const sealInner = el(
    "div",
    `width:46px;height:46px;border:1px solid #146047;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#146047;font-family:${DISPLAY};font-size:18px;`,
    "हा",
  );
  seal.append(sealInner);
  head.append(seal);
  root.append(head);

  const who = el("div", "margin-top:14px;font-size:14px;");
  who.append(el("div", "", `नाम: ${args.name.trim() || "________________"}`));
  who.append(el("div", "margin-top:2px;", `जगह: ${args.place.trim() || "________________"}`));
  who.append(
    el(
      "div",
      "margin-top:2px;color:#6f675c;",
      `पूरे दिन के घंटे: ${formatHours(args.settings.dailyHours)} · पूरे दिन की मज़दूरी: ${
        args.settings.dailyWage > 0 ? inr(args.settings.dailyWage) : "नहीं लिखी"
      }`,
    ),
  );
  root.append(who);

  const rows: [string, string][] = [
    ["काम के दिन", String(section.summary.daysWorked)],
    ["छुट्टी के दिन", String(section.summary.daysOff)],
    ["घंटे किए", formatHours(section.summary.hoursWorked)],
    ["घंटे नहीं किए", formatHours(section.summary.hoursMissed)],
    ["एडवांस लिया", inr(section.summary.advance)],
  ];
  if (args.settings.dailyWage > 0) {
    rows.push(["कुल मज़दूरी", inr(section.summary.earned)]);
    rows.push([
      section.summary.remaining >= 0 ? "नहीं लिया (बाकी)" : "एडवांस ज़्यादा",
      inr(Math.abs(section.summary.remaining)),
    ]);
  }

  const summary = el("table", "width:100%;border-collapse:collapse;margin:14px 0 16px;background:#f4efe4;");
  for (const [label, value] of rows) {
    const tr = document.createElement("tr");
    const left = el("td", "padding:5px 10px;color:#6f675c;width:55%;", label);
    const right = el("td", "padding:5px 10px;text-align:right;font-weight:700;", value);
    tr.append(left, right);
    summary.append(tr);
  }
  root.append(summary);

  const table = el("table", "width:100%;border-collapse:collapse;table-layout:fixed;");
  const colgroup = document.createElement("colgroup");
  for (const width of ["24%", "14%", "14%", "18%", "30%"]) {
    const col = document.createElement("col");
    col.style.width = width;
    colgroup.append(col);
  }
  table.append(colgroup);

  const header = document.createElement("tr");
  for (const [index, label] of ["तारीख", "काम", "नहीं", "एडवांस", "नोट"].entries()) {
    const th = el(
      "th",
      `padding:7px 6px;background:#146047;color:#fbf7ef;font-size:12px;font-weight:700;text-align:${index === 0 || index === 4 ? "left" : "right"};`,
      label,
    );
    header.append(th);
  }
  table.append(header);

  for (const entry of section.entries) {
    const tr = document.createElement("tr");
    const cells = [
      formatEntryDate(entry.date),
      formatHours(entry.hoursWorked),
      formatHours(entry.hoursMissed),
      entry.advance ? inr(entry.advance) : "—",
      clip(entry.note, 28),
    ];
    cells.forEach((text, index) => {
      tr.append(
        el(
          "td",
          `padding:6px;border-bottom:1px solid #e3d7c3;font-size:12px;vertical-align:top;text-align:${index === 0 || index === 4 ? "left" : "right"};`,
          text,
        ),
      );
    });
    table.append(tr);
  }

  const total = document.createElement("tr");
  const totals = [
    "जोड़",
    formatHours(section.summary.hoursWorked),
    formatHours(section.summary.hoursMissed),
    inr(section.summary.advance),
    "",
  ];
  totals.forEach((text, index) => {
    total.append(
      el(
        "td",
        `padding:7px 6px;background:#efe6d6;font-size:12px;font-weight:700;text-align:${index === 0 ? "left" : "right"};`,
        text,
      ),
    );
  });
  table.append(total);
  root.append(table);

  const sign = el("div", "display:flex;justify-content:space-between;gap:24px;margin-top:22px;font-size:13px;");
  sign.append(el("div", "", "मज़दूर के हस्ताक्षर ________"));
  sign.append(el("div", "", "मालिक के हस्ताक्षर ________"));
  root.append(sign);
  root.append(
    el(
      "div",
      "margin-top:10px;color:#6f675c;font-size:11px;",
      `तैयार: ${formatLongDate(args.preparedOn)} · नहीं लिया = मज़दूरी − एडवांस`,
    ),
  );
  return root;
}

async function paint(node: HTMLElement): Promise<string> {
  const host = el(
    "div",
    "position:fixed;left:0;top:0;z-index:20;width:720px;background:#fbf7ef;pointer-events:none;",
  );
  host.append(node);
  document.body.append(host);
  try {
    if (document.fonts?.ready) await document.fonts.ready;
    const { domToPng } = await import("modern-screenshot");
    return await domToPng(host, {
      scale: 2,
      backgroundColor: "#fbf7ef",
      width: 720,
    });
  } finally {
    host.remove();
  }
}

function imageSize(url: string): Promise<{ w: number; h: number }> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve({ w: img.naturalWidth, h: img.naturalHeight });
    img.onerror = () => reject(new Error("pdf-image"));
    img.src = url;
  });
}

export async function downloadHajiriPdf(args: PdfArgs): Promise<void> {
  const { jsPDF } = await import("jspdf");
  const pdf = new jsPDF({ unit: "mm", format: "a4" });
  const pageW = pdf.internal.pageSize.getWidth();
  const pageH = pdf.internal.pageSize.getHeight();
  const margin = 8;
  const maxW = pageW - margin * 2;
  const maxH = pageH - margin * 2;
  const count = args.sections.length;

  for (let index = 0; index < count; index += 1) {
    const section = args.sections[index];
    const url = await paint(buildPage(args, section, index + 1, count));
    const { w, h } = await imageSize(url);
    if (index > 0) pdf.addPage();
    const scale = Math.min(maxW / w, maxH / h);
    const drawW = w * scale;
    const drawH = h * scale;
    const x = margin + (maxW - drawW) / 2;
    pdf.addImage(url, "PNG", x, margin, drawW, drawH);
  }

  pdf.save(args.filename);
}
