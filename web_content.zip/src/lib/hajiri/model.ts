export type Settings = {
  name: string;
  place: string;
  dailyHours: number;
  dailyWage: number;
};

export type Entry = {
  id: string;
  date: string;
  hoursWorked: number;
  hoursMissed: number;
  advance: number;
  note: string;
};

export type EntryDraft = {
  id?: string;
  date: string;
  hoursWorked: number;
  hoursMissed: number;
  advance: number;
  note: string;
};

export type Summary = {
  daysMarked: number;
  daysWorked: number;
  daysOff: number;
  hoursWorked: number;
  hoursMissed: number;
  advance: number;
  earned: number;
  remaining: number;
};

export const defaultSettings: Settings = {
  name: "",
  place: "",
  dailyHours: 8,
  dailyWage: 0,
};

const MONTHS = [
  "जनवरी",
  "फरवरी",
  "मार्च",
  "अप्रैल",
  "मई",
  "जून",
  "जुलाई",
  "अगस्त",
  "सितंबर",
  "अक्टूबर",
  "नवंबर",
  "दिसंबर",
];

const WEEKDAYS_SHORT = ["रवि", "सोम", "मंगल", "बुध", "गुरु", "शुक्र", "शनि"];
const WEEKDAYS = ["रविवार", "सोमवार", "मंगलवार", "बुधवार", "गुरुवार", "शुक्रवार", "शनिवार"];

export function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

export function clampHours(n: number): number {
  if (!Number.isFinite(n)) return 0;
  return round1(Math.min(24, Math.max(0, n)));
}

export function parseLoose(raw: string): number {
  const n = Number(raw);
  return Number.isFinite(n) ? n : 0;
}

export function sanitizeDecimal(raw: string): string {
  const clean = raw.replace(/[^\d.]/g, "");
  const [whole, ...rest] = clean.split(".");
  if (rest.length === 0) return whole.slice(0, 2);
  return `${whole.slice(0, 2)}.${rest.join("").slice(0, 1)}`;
}

export function sanitizeInt(raw: string): string {
  return raw.replace(/[^\d]/g, "").slice(0, 7);
}

export function formatHours(n: number): string {
  const r = round1(n);
  return Number.isInteger(r) ? String(r) : r.toFixed(1);
}

export function hoursPhrase(n: number): string {
  const label = formatHours(n);
  return label === "1" ? "1 घंटा" : `${label} घंटे`;
}

export function inr(n: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(Math.round(n));
}

export function dayEarning(hoursWorked: number, settings: Settings): number {
  if (settings.dailyHours <= 0 || settings.dailyWage <= 0 || hoursWorked <= 0) return 0;
  return Math.round((hoursWorked / settings.dailyHours) * settings.dailyWage);
}

export function summarize(entries: Entry[], settings: Settings): Summary {
  let daysWorked = 0;
  let daysOff = 0;
  let hoursWorked = 0;
  let hoursMissed = 0;
  let advance = 0;
  let earned = 0;
  for (const entry of entries) {
    if (entry.hoursWorked > 0) daysWorked += 1;
    else daysOff += 1;
    hoursWorked = round1(hoursWorked + entry.hoursWorked);
    hoursMissed = round1(hoursMissed + entry.hoursMissed);
    advance += entry.advance;
    earned += dayEarning(entry.hoursWorked, settings);
  }
  return {
    daysMarked: entries.length,
    daysWorked,
    daysOff,
    hoursWorked,
    hoursMissed,
    advance,
    earned,
    remaining: earned - advance,
  };
}

export function toMonth(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export function todayISO(d = new Date()): string {
  return `${toMonth(d)}-${String(d.getDate()).padStart(2, "0")}`;
}

export function currentMonth(d = new Date()): string {
  return toMonth(d);
}

export function shiftMonth(ym: string, delta: number): string {
  const [y, m] = ym.split("-").map(Number);
  const d = new Date(y, (m || 1) - 1 + delta, 1);
  return toMonth(d);
}

export function formatMonth(ym: string): string {
  const [y, m] = ym.split("-").map(Number);
  if (!y || !m || m < 1 || m > 12) return ym;
  return `${MONTHS[m - 1]} ${y}`;
}

export function parseISODate(iso: string): Date | null {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
  if (!match) return null;
  const y = Number(match[1]);
  const mo = Number(match[2]);
  const d = Number(match[3]);
  const dt = new Date(y, mo - 1, d);
  if (dt.getFullYear() !== y || dt.getMonth() !== mo - 1 || dt.getDate() !== d) return null;
  return dt;
}

export function weekdayShort(iso: string): string {
  const dt = parseISODate(iso);
  return dt ? WEEKDAYS_SHORT[dt.getDay()] : "";
}

export function formatEntryDate(iso: string): string {
  const dt = parseISODate(iso);
  if (!dt) return iso;
  return `${dt.getDate()} ${MONTHS[dt.getMonth()]}, ${WEEKDAYS[dt.getDay()]}`;
}

export function formatLongDate(date: Date): string {
  return `${date.getDate()} ${MONTHS[date.getMonth()]} ${date.getFullYear()}`;
}

export function dayNumber(iso: string): string {
  const dt = parseISODate(iso);
  return dt ? String(dt.getDate()) : "";
}

export function dayBadge(
  entry: Entry,
  dailyHours: number,
): { label: string; tone: "stamp" | "copper" | "ink" } {
  if (entry.hoursWorked <= 0) return { label: "छुट्टी", tone: "copper" };
  if (dailyHours > 0 && entry.hoursWorked > dailyHours + 0.05) {
    return { label: "ज़्यादा घंटे", tone: "stamp" };
  }
  if (dailyHours > 0 && entry.hoursWorked + 0.05 < dailyHours) {
    return { label: "कम घंटे", tone: "ink" };
  }
  return { label: "पूरा दिन", tone: "stamp" };
}

export function groupByMonth(entries: Entry[]): { month: string; entries: Entry[] }[] {
  const map = new Map<string, Entry[]>();
  for (const entry of entries) {
    const month = entry.date.slice(0, 7);
    const list = map.get(month);
    if (list) list.push(entry);
    else map.set(month, [entry]);
  }
  return [...map.entries()]
    .sort((a, b) => (a[0] < b[0] ? -1 : 1))
    .map(([month, list]) => ({
      month,
      entries: list.slice().sort((a, b) => (a.date < b.date ? -1 : 1)),
    }));
}

export function isEntry(value: unknown): value is Entry {
  if (!value || typeof value !== "object") return false;
  const entry = value as Entry;
  return (
    typeof entry.id === "string" &&
    typeof entry.date === "string" &&
    typeof entry.hoursWorked === "number" &&
    typeof entry.hoursMissed === "number" &&
    typeof entry.advance === "number" &&
    typeof entry.note === "string" &&
    parseISODate(entry.date) !== null
  );
}

export function cleanSettings(value: unknown): Settings {
  const raw = value && typeof value === "object" ? (value as Partial<Settings>) : {};
  const dailyHours =
    typeof raw.dailyHours === "number" && raw.dailyHours > 0
      ? Math.min(16, round1(raw.dailyHours))
      : defaultSettings.dailyHours;
  const dailyWage =
    typeof raw.dailyWage === "number" && raw.dailyWage >= 0
      ? Math.min(10_000_000, Math.round(raw.dailyWage))
      : 0;
  return {
    name: typeof raw.name === "string" ? raw.name.slice(0, 40) : "",
    place: typeof raw.place === "string" ? raw.place.slice(0, 40) : "",
    dailyHours,
    dailyWage,
  };
}
