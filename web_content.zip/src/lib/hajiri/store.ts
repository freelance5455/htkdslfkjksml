import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import {
  type Entry,
  type EntryDraft,
  type Settings,
  clampHours,
  cleanSettings,
  defaultSettings,
  isEntry,
} from "@/lib/hajiri/model";

type HajiriState = {
  settings: Settings;
  entries: Entry[];
  setSettings: (patch: Partial<Settings>) => void;
  upsertEntry: (draft: EntryDraft) => void;
  removeEntry: (id: string) => void;
  clearEntries: () => void;
};

const memory = new Map<string, string>();

const safeStorage = {
  getItem: (key: string) => {
    try {
      if (typeof localStorage === "undefined") return memory.get(key) ?? null;
      return localStorage.getItem(key);
    } catch {
      return memory.get(key) ?? null;
    }
  },
  setItem: (key: string, value: string) => {
    try {
      if (typeof localStorage === "undefined") {
        memory.set(key, value);
        return;
      }
      localStorage.setItem(key, value);
    } catch {
      memory.set(key, value);
    }
  },
  removeItem: (key: string) => {
    try {
      if (typeof localStorage === "undefined") {
        memory.delete(key);
        return;
      }
      localStorage.removeItem(key);
    } catch {
      memory.delete(key);
    }
  },
};

function newId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

function normalize(draft: EntryDraft): Entry {
  return {
    id: draft.id && draft.id.length > 0 ? draft.id : newId(),
    date: draft.date,
    hoursWorked: clampHours(draft.hoursWorked),
    hoursMissed: clampHours(draft.hoursMissed),
    advance: Math.max(0, Math.min(10_000_000, Math.round(draft.advance) || 0)),
    note: draft.note.trim().slice(0, 180),
  };
}

export const useHajiri = create<HajiriState>()(
  persist(
    (set, get) => ({
      settings: defaultSettings,
      entries: [],
      setSettings: (patch) => {
        set({ settings: cleanSettings({ ...get().settings, ...patch }) });
      },
      upsertEntry: (draft) => {
        const next = normalize(draft);
        const entries = get().entries.filter((entry) => entry.id !== next.id && entry.date !== next.date);
        set({ entries: [...entries, next] });
      },
      removeEntry: (id) => {
        set({ entries: get().entries.filter((entry) => entry.id !== id) });
      },
      clearEntries: () => set({ entries: [] }),
    }),
    {
      name: "meri-hajiri-v1",
      storage: createJSONStorage(() => safeStorage),
      merge: (persisted, current) => {
        const saved = (persisted ?? {}) as Partial<HajiriState>;
        const entries = Array.isArray(saved.entries) ? saved.entries.filter(isEntry) : [];
        return {
          ...current,
          settings: cleanSettings(saved.settings),
          entries,
        };
      },
    },
  ),
);
