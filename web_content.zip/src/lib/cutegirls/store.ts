import { create } from "zustand";
import type { PostKind } from "./model";

type Compose = { open: boolean; kind?: PostKind; group?: string | null };

type Salon = {
  tick: number;
  bump: () => void;
  compose: Compose;
  openCompose: (opts?: { kind?: PostKind; group?: string | null }) => void;
  closeCompose: () => void;
};

export const useSalon = create<Salon>((set) => ({
  tick: 0,
  bump: () => set((s) => ({ tick: s.tick + 1 })),
  compose: { open: false },
  openCompose: (opts) =>
    set({ compose: { open: true, kind: opts?.kind, group: opts?.group ?? null } }),
  closeCompose: () => set({ compose: { open: false } }),
}));
