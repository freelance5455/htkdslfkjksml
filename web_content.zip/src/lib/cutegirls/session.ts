import { createProfile } from "./api";
import { emailFor, type Role } from "./model";

const BEARER_KEY = "grok-auth.bearer-token";
const DRAFT_KEY = "cg-draft";

export type Draft = { username: string; youtubeUrl: string; role: Role };

function rememberToken(token: string | null) {
  if (!token || typeof window === "undefined") return;
  window.sessionStorage.setItem(BEARER_KEY, token);
}

async function authPost(path: string, body: object) {
  const res = await fetch(`/api/auth/${path}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    credentials: "include",
    body: JSON.stringify(body),
  });
  rememberToken(res.headers.get("set-auth-token"));
  const payload = (await res.json().catch(() => ({}))) as {
    message?: string;
    code?: string;
  };
  return { ok: res.ok, status: res.status, payload };
}

function mapAuthError(status: number, payload: { message?: string; code?: string }, mode: "in" | "up") {
  const code = payload.code ?? "";
  if (code.includes("PASSWORD_TOO_SHORT")) return "كلمة المرور قصيرة. ثمانية أحرف على الأقل.";
  if (code.includes("USER_ALREADY") || status === 422) {
    return "اسم الحساب مستخدم. جرّب اسماً آخر أو سجّل الدخول.";
  }
  if (status === 401 || code.includes("INVALID") || code.includes("PASSWORD")) {
    return mode === "in" ? "اسم الحساب أو كلمة المرور غير صحيحة." : "تعذر إنشاء الحساب.";
  }
  return mode === "in" ? "تعذر الدخول." : payload.message || "تعذر إنشاء الحساب.";
}

export function saveDraft(draft: Draft) {
  if (typeof window === "undefined") return;
  window.sessionStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
}

export function readDraft(): Draft | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.sessionStorage.getItem(DRAFT_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Draft;
    if (!parsed.username || !parsed.youtubeUrl || !parsed.role) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function clearDraft() {
  if (typeof window === "undefined") return;
  window.sessionStorage.removeItem(DRAFT_KEY);
}

export async function signUpAccount(draft: Draft, password: string) {
  saveDraft(draft);
  const res = await authPost("sign-up/email", {
    email: emailFor(draft.username),
    password,
    name: draft.username,
  });
  if (!res.ok) return { ok: false as const, error: mapAuthError(res.status, res.payload, "up") };
  const profile = await createProfile({
    data: { username: draft.username, youtubeUrl: draft.youtubeUrl, role: draft.role },
  });
  if (profile.ok) clearDraft();
  window.location.assign("/");
  return profile.ok ? { ok: true as const } : { ok: false as const, error: profile.error };
}

export async function signInAccount(username: string, password: string) {
  const res = await authPost("sign-in/email", {
    email: emailFor(username),
    password,
  });
  if (!res.ok) return { ok: false as const, error: mapAuthError(res.status, res.payload, "in") };
  window.location.assign("/");
  return { ok: true as const };
}
