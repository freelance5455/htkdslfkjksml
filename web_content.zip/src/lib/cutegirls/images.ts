export async function compressImage(file: File, maxEdge: number, maxChars: number): Promise<string> {
  if (!file.type.startsWith("image/")) throw new Error("الملف ليس صورة");
  const bitmap = await createImageBitmap(file);
  try {
    let edge = maxEdge;
    let quality = 0.86;
    let last = "";
    for (let i = 0; i < 7; i += 1) {
      const scale = Math.min(1, edge / Math.max(bitmap.width, bitmap.height));
      const w = Math.max(1, Math.round(bitmap.width * scale));
      const h = Math.max(1, Math.round(bitmap.height * scale));
      const canvas = document.createElement("canvas");
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("تعذر معالجة الصورة");
      ctx.fillStyle = "#fffdfb";
      ctx.fillRect(0, 0, w, h);
      ctx.drawImage(bitmap, 0, 0, w, h);
      last = canvas.toDataURL("image/jpeg", quality);
      if (last.length <= maxChars) return last;
      quality = Math.max(0.42, quality - 0.1);
      edge = Math.round(edge * 0.82);
    }
    if (last.length <= maxChars) return last;
    throw new Error("الصورة كبيرة حتى بعد الضغط");
  } finally {
    bitmap.close();
  }
}
