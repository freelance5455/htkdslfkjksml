export const USER_RE = /^[A-Za-z0-9][A-Za-z0-9._-]{1,22}[A-Za-z0-9]$/;

export type Role = "listener" | "creator";
export type PostKind = "vent" | "contest" | "info" | "news" | "reel" | "subliminal";
export type Surface = "home" | "reels" | "subliminals" | "group" | "user";

export const ROLES: { id: Role; label: string; hint: string }[] = [
  { id: "listener", label: "مستمع", hint: "حضور هادئ: متابعة وتفاعل" },
  { id: "creator", label: "صانع", hint: "صناعة ريلز وسيبلمنال ومسابقات" },
];

export const POST_KINDS: Record<PostKind, { label: string; hint: string }> = {
  vent: { label: "فضفضة", hint: "كلام بلا قناع" },
  contest: { label: "مسابقة", hint: "سؤال، ودعوة للمشاركة" },
  info: { label: "معلومة", hint: "شيء يستحق أن يعرفه الجميع" },
  news: { label: "نشرة اخبارية", hint: "خبر قصير من يومك" },
  reel: { label: "ميم / ريل", hint: "صورة تظهر في شريط الريلز" },
  subliminal: { label: "سيبلمنال", hint: "عنوان ووصف ورابط إن وجد" },
};

export const HOME_KINDS: PostKind[] = ["vent", "contest", "info", "news"];

export const REACTIONS = [
  { id: "gleam", label: "بريق" },
  { id: "crown", label: "تاج" },
  { id: "feather", label: "ريشة" },
  { id: "gem", label: "ماسة" },
  { id: "moon", label: "هلال" },
  { id: "bloom", label: "ورد" },
] as const;

export type ReactionId = (typeof REACTIONS)[number]["id"];

export const STICKERS = [
  { id: "cat", label: "قطة" },
  { id: "star", label: "نجمة" },
  { id: "clover", label: "برسيم" },
  { id: "note", label: "نغمة" },
  { id: "cup", label: "فنجان" },
  { id: "bird", label: "عصفور" },
  { id: "shell", label: "قوقعة" },
  { id: "sun", label: "شمس" },
] as const;

export type StickerId = (typeof STICKERS)[number]["id"];

export type FeedQuery = {
  surface: Surface;
  kind?: string;
  scope?: "all" | "following";
  slug?: string;
  username?: string;
};

export type Profile = {
  userId: string;
  username: string;
  youtubeUrl: string;
  bio: string;
  avatar: string | null;
  banner: string | null;
  role: Role;
  followers: number;
  following: number;
  isSelf: boolean;
  isFollowing: boolean;
};

export type GroupCard = {
  slug: string;
  name: string;
  blurb: string;
  forced: boolean;
  members: number;
  joined: boolean;
};

export type PostView = {
  id: string;
  userId: string;
  username: string;
  avatar: string | null;
  role: Role;
  kind: PostKind;
  title: string;
  body: string;
  media: string | null;
  link: string | null;
  groupSlug: string | null;
  groupName: string | null;
  createdAt: string;
  commentCount: number;
  reactions: Record<string, number>;
  myReaction: string | null;
};

export type CommentView = {
  id: string;
  username: string;
  avatar: string | null;
  body: string;
  sticker: string | null;
  createdAt: string;
  mine: boolean;
};

export type Person = {
  username: string;
  avatar: string | null;
  role: Role;
  bio: string;
};

export type Me = {
  profile: Profile | null;
  accountUsername: string | null;
  groups: GroupCard[];
};

export function emailFor(username: string): string {
  return `cg_${username.toLowerCase()}@cutegirls.app`;
}

export function isRole(v: string): v is Role {
  return v === "listener" || v === "creator";
}

export function isKind(v: string): v is PostKind {
  return v in POST_KINDS;
}

export function isReaction(v: string): v is ReactionId {
  return REACTIONS.some((r) => r.id === v);
}

export function isSticker(v: string): v is StickerId {
  return STICKERS.some((s) => s.id === v);
}

export function parseYoutubeChannel(input: string): { url: string; handle: string } | null {
  const trimmed = input.trim();
  if (!trimmed) return null;
  const withProto = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  let url: URL;
  try {
    url = new URL(withProto);
  } catch {
    return null;
  }
  if (url.protocol !== "https:" && url.protocol !== "http:") return null;
  const host = url.hostname.toLowerCase().replace(/^www\./, "").replace(/^m\./, "");
  if (host !== "youtube.com") return null;
  const match = url.pathname.match(/^\/@([^/?#]+)$/);
  if (!match) return null;
  let handle = match[1];
  try {
    handle = decodeURIComponent(handle);
  } catch {
    return null;
  }
  if (!USER_RE.test(handle)) return null;
  return { url: `https://www.youtube.com/@${handle}`, handle };
}

export function youtubeVideoId(input: string): string | null {
  try {
    const url = new URL(input);
    const host = url.hostname.toLowerCase().replace(/^www\./, "").replace(/^m\./, "");
    if (host === "youtu.be") {
      const id = url.pathname.split("/").filter(Boolean)[0] ?? "";
      return /^[\w-]{6,20}$/.test(id) ? id : null;
    }
    if (host !== "youtube.com") return null;
    const v = url.searchParams.get("v");
    if (v && /^[\w-]{6,20}$/.test(v)) return v;
    const path = url.pathname.match(/^\/(?:shorts|embed|live)\/([\w-]{6,20})/);
    return path?.[1] ?? null;
  } catch {
    return null;
  }
}

export function ago(iso: string): string {
  const t = new Date(iso).getTime();
  if (!Number.isFinite(t)) return "";
  const seconds = Math.max(0, Math.round((Date.now() - t) / 1000));
  if (seconds < 45) return "الآن";
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return `منذ ${minutes} د`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `منذ ${hours} س`;
  const days = Math.round(hours / 24);
  if (days < 30) return `منذ ${days} ي`;
  return new Date(iso).toLocaleDateString("ar");
}

export function roleLabel(role: Role): string {
  return role === "creator" ? "صانع" : "مستمع";
}
