import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql, type Sql } from "@/lib/db";
import {
  HOME_KINDS,
  USER_RE,
  emailFor,
  isKind,
  isReaction,
  isRole,
  isSticker,
  parseYoutubeChannel,
  type CommentView,
  type FeedQuery,
  type GroupCard,
  type Me,
  type Person,
  type PostKind,
  type PostView,
  type Profile,
  type Role,
} from "./model";

type Err = { ok: false; error: string };

function fail(error: string): Err {
  return { ok: false, error };
}

function text(value: unknown, max: number, label: string): { ok: true; value: string } | Err {
  if (typeof value !== "string") return fail(`${label} غير صالح`);
  const cleaned = value.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").trim();
  if (cleaned.length > max) return fail(`${label} أطول من المسموح`);
  return { ok: true, value: cleaned };
}

function jpeg(value: unknown, max: number): { ok: true; value: string | null } | Err {
  if (value == null || value === "") return { ok: true, value: null };
  if (typeof value !== "string" || !value.startsWith("data:image/jpeg;base64,") || value.length > max) {
    return fail("الصورة غير صالحة أو كبيرة");
  }
  return { ok: true, value };
}

async function accountUsername(sql: Sql, userId: string): Promise<string | null> {
  const rows = await sql<{ email: string }>`select email from "user" where id = ${userId} limit 1`;
  const email = rows[0]?.email ?? "";
  const match = email.match(/^cg_([a-z0-9._-]+)@cutegirls\.app$/);
  return match?.[1] ?? null;
}

async function loadGroups(sql: Sql, userId: string): Promise<GroupCard[]> {
  const rows = await sql<{
    slug: string;
    name: string;
    blurb: string;
    forced: boolean;
    members: number;
    joined: boolean;
  }>`
    select g.slug, g.name, g.blurb, g.forced,
      (select count(*) from group_members m where m.group_slug = g.slug) as members,
      exists(select 1 from group_members m where m.group_slug = g.slug and m.user_id = ${userId}) as joined
    from groups g
    order by g.sort
  `;
  return rows.map((row) => ({
    slug: row.slug,
    name: row.name,
    blurb: row.blurb,
    forced: Boolean(row.forced),
    members: Number(row.members),
    joined: Boolean(row.joined),
  }));
}

type ProfileRow = {
  user_id: string;
  username: string;
  youtube_url: string;
  bio: string;
  avatar: string | null;
  banner: string | null;
  role: Role;
};

async function profileByUser(sql: Sql, userId: string): Promise<ProfileRow | null> {
  const rows = await sql<ProfileRow>`
    select user_id, username, youtube_url, bio, avatar, banner, role
    from profiles where user_id = ${userId} limit 1
  `;
  return rows[0] ?? null;
}

function mapProfile(
  row: ProfileRow,
  counts: { followers: number; following: number },
  viewer: string,
  isFollowing: boolean,
): Profile {
  return {
    userId: row.user_id,
    username: row.username,
    youtubeUrl: row.youtube_url,
    bio: row.bio,
    avatar: row.avatar,
    banner: row.banner,
    role: row.role,
    followers: counts.followers,
    following: counts.following,
    isSelf: row.user_id === viewer,
    isFollowing,
  };
}

async function countsFor(sql: Sql, userId: string) {
  const rows = await sql<{ followers: number; following: number }>`
    select
      (select count(*) from follows where following_id = ${userId}) as followers,
      (select count(*) from follows where follower_id = ${userId}) as following
  `;
  return {
    followers: Number(rows[0]?.followers ?? 0),
    following: Number(rows[0]?.following ?? 0),
  };
}

type PostRow = {
  id: string;
  user_id: string;
  kind: PostKind;
  title: string;
  body: string;
  media: string | null;
  link: string | null;
  group_slug: string | null;
  group_name: string | null;
  created_at: string;
  username: string;
  avatar: string | null;
  role: Role;
};

async function hydrate(sql: Sql, me: string, rows: PostRow[]): Promise<PostView[]> {
  if (rows.length === 0) return [];
  const ids = rows.map((row) => row.id);
  const ph = ids.map((_, i) => `$${i + 1}`).join(", ");
  const [reactionRows, mineRows, commentRows] = await Promise.all([
    sql.query<{ post_id: string; kind: string; n: number }>(
      `select post_id, kind, count(*)::int as n from reactions where post_id in (${ph}) group by post_id, kind`,
      ids,
    ),
    sql.query<{ post_id: string; kind: string }>(
      `select post_id, kind from reactions where post_id in (${ph}) and user_id = $${ids.length + 1}`,
      [...ids, me],
    ),
    sql.query<{ post_id: string; n: number }>(
      `select post_id, count(*)::int as n from comments where post_id in (${ph}) group by post_id`,
      ids,
    ),
  ]);
  const reactions = new Map<string, Record<string, number>>();
  for (const row of reactionRows) {
    const bag = reactions.get(row.post_id) ?? {};
    bag[row.kind] = Number(row.n);
    reactions.set(row.post_id, bag);
  }
  const mine = new Map(mineRows.map((row) => [row.post_id, row.kind]));
  const comments = new Map(commentRows.map((row) => [row.post_id, Number(row.n)]));
  return rows.map((row) => ({
    id: row.id,
    userId: row.user_id,
    username: row.username,
    avatar: row.avatar,
    role: row.role,
    kind: row.kind,
    title: row.title,
    body: row.body,
    media: row.media,
    link: row.link,
    groupSlug: row.group_slug,
    groupName: row.group_name,
    createdAt: String(row.created_at),
    commentCount: comments.get(row.id) ?? 0,
    reactions: reactions.get(row.id) ?? {},
    myReaction: mine.get(row.id) ?? null,
  }));
}

const POST_SELECT = `
  select p.id, p.user_id, p.kind, p.title, p.body, p.media, p.link, p.group_slug,
         p.created_at::text as created_at,
         pr.username, pr.avatar, pr.role,
         g.name as group_name
  from posts p
  join profiles pr on pr.user_id = p.user_id
  left join groups g on g.slug = p.group_slug
`;

export const getMe = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Me> => {
    const sql = await getSql();
    const bound = await accountUsername(sql, context.userId);
    const row = await profileByUser(sql, context.userId);
    if (row) {
      await sql`
        insert into group_members (group_slug, user_id)
        values ('everyone', ${context.userId})
        on conflict do nothing
      `;
    }
    return {
      profile: row ? mapProfile(row, await countsFor(sql, row.user_id), context.userId, false) : null,
      accountUsername: bound,
      groups: await loadGroups(sql, context.userId),
    };
  });

export const createProfile = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ ok: true } | Err> => {
    const body = (data ?? {}) as Record<string, unknown>;
    const username = text(body.username, 24, "اسم الحساب");
    if (!username.ok) return username;
    if (!USER_RE.test(username.value)) {
      return fail("اسم الحساب من 3 إلى 24 حرفاً: إنجليزي، أرقام، نقطة أو شرطة.");
    }
    const channel = parseYoutubeChannel(typeof body.youtubeUrl === "string" ? body.youtubeUrl : "");
    if (!channel) return fail("ضع رابط القناة بصيغة youtube.com/@username");
    if (channel.handle.toLowerCase() !== username.value.toLowerCase()) {
      return fail("اسم الحساب يجب أن يطابق اسم قناة يوتيوب بعد @");
    }
    if (typeof body.role !== "string" || !isRole(body.role)) return fail("اختر مستمع أو صانع");
    const sql = await getSql();
    const existing = await profileByUser(sql, context.userId);
    if (existing) return { ok: true };
    const bound = await accountUsername(sql, context.userId);
    if (bound && bound !== username.value.toLowerCase()) {
      return fail("اسم الحساب مرتبط بالدخول ولا يمكن تغييره");
    }
    if (!bound) {
      const email = emailFor(username.value);
      const takenEmail = await sql<{ id: string }>`select id from "user" where lower(email) = ${email} and id <> ${context.userId} limit 1`;
      if (takenEmail.length) return fail("اسم الحساب مستخدم");
    }
    const taken = await sql<{ user_id: string }>`
      select user_id from profiles where lower(username) = ${username.value.toLowerCase()} limit 1
    `;
    if (taken.length) return fail("اسم الحساب مستخدم");
    await sql`
      insert into profiles (user_id, username, youtube_url, role)
      values (${context.userId}, ${username.value}, ${channel.url}, ${body.role})
    `;
    await sql`
      insert into group_members (group_slug, user_id)
      values ('everyone', ${context.userId})
      on conflict do nothing
    `;
    return { ok: true };
  });

export const updateProfile = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ ok: true } | Err> => {
    const body = (data ?? {}) as Record<string, unknown>;
    const bio = text(body.bio ?? "", 280, "النبذة");
    if (!bio.ok) return bio;
    if (typeof body.role !== "string" || !isRole(body.role)) return fail("اختر مستمع أو صانع");
    const avatar = jpeg(body.avatar, 220_000);
    if (!avatar.ok) return avatar;
    const banner = jpeg(body.banner, 420_000);
    if (!banner.ok) return banner;
    const sql = await getSql();
    const rows = await sql<{ user_id: string }>`
      update profiles
      set bio = ${bio.value}, role = ${body.role}, avatar = ${avatar.value}, banner = ${banner.value}
      where user_id = ${context.userId}
      returning user_id
    `;
    if (!rows.length) return fail("أنشئ الملف أولاً");
    return { ok: true };
  });

export const getProfile = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ ok: true; profile: Profile } | Err> => {
    const username = text((data as { username?: unknown })?.username, 24, "اسم الحساب");
    if (!username.ok) return username;
    const sql = await getSql();
    const rows = await sql<ProfileRow>`
      select user_id, username, youtube_url, bio, avatar, banner, role
      from profiles where lower(username) = ${username.value.toLowerCase()} limit 1
    `;
    const row = rows[0];
    if (!row) return fail("لا يوجد حساب بهذا الاسم");
    const follow = await sql<{ ok: number }>`
      select 1 as ok from follows
      where follower_id = ${context.userId} and following_id = ${row.user_id} limit 1
    `;
    return {
      ok: true,
      profile: mapProfile(row, await countsFor(sql, row.user_id), context.userId, follow.length > 0),
    };
  });

export const listConnections = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .middleware([authMiddleware])
  .handler(async ({ data }): Promise<{ ok: true; people: Person[] } | Err> => {
    const body = (data ?? {}) as Record<string, unknown>;
    const username = text(body.username, 24, "اسم الحساب");
    if (!username.ok) return username;
    const dir = body.dir === "following" ? "following" : body.dir === "followers" ? "followers" : null;
    if (!dir) return fail("اتجاه غير معروف");
    const sql = await getSql();
    const owner = await sql<{ user_id: string }>`
      select user_id from profiles where lower(username) = ${username.value.toLowerCase()} limit 1
    `;
    if (!owner[0]) return fail("لا يوجد حساب بهذا الاسم");
    const rows =
      dir === "followers"
        ? await sql<Person & { role: Role }>`
            select pr.username, pr.avatar, pr.role, pr.bio
            from follows f
            join profiles pr on pr.user_id = f.follower_id
            where f.following_id = ${owner[0].user_id}
            order by f.created_at desc
            limit 50
          `
        : await sql<Person & { role: Role }>`
            select pr.username, pr.avatar, pr.role, pr.bio
            from follows f
            join profiles pr on pr.user_id = f.following_id
            where f.follower_id = ${owner[0].user_id}
            order by f.created_at desc
            limit 50
          `;
    return { ok: true, people: rows };
  });

export const setFollow = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ ok: true; following: boolean; followers: number } | Err> => {
    const body = (data ?? {}) as Record<string, unknown>;
    const username = text(body.username, 24, "اسم الحساب");
    if (!username.ok) return username;
    const follow = Boolean(body.follow);
    const sql = await getSql();
    const me = await profileByUser(sql, context.userId);
    if (!me) return fail("أنشئ الملف أولاً");
    const target = await sql<{ user_id: string }>`
      select user_id from profiles where lower(username) = ${username.value.toLowerCase()} limit 1
    `;
    if (!target[0]) return fail("لا يوجد حساب بهذا الاسم");
    if (target[0].user_id === context.userId) return fail("لا يمكن متابعة نفسك");
    if (follow) {
      await sql`
        insert into follows (follower_id, following_id)
        values (${context.userId}, ${target[0].user_id})
        on conflict do nothing
      `;
    } else {
      await sql`
        delete from follows
        where follower_id = ${context.userId} and following_id = ${target[0].user_id}
      `;
    }
    const counts = await countsFor(sql, target[0].user_id);
    return { ok: true, following: follow, followers: counts.followers };
  });

export const searchUsers = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .middleware([authMiddleware])
  .handler(async ({ data }): Promise<{ ok: true; people: Person[] }> => {
    const raw = text((data as { q?: unknown })?.q ?? "", 40, "البحث");
    const q = raw.ok ? raw.value.replace(/[%_]/g, "") : "";
    const sql = await getSql();
    const rows = q
      ? await sql<Person>`
          select username, avatar, role, bio from profiles
          where lower(username) like ${"%" + q.toLowerCase() + "%"}
          order by username
          limit 24
        `
      : await sql<Person>`
          select username, avatar, role, bio from profiles
          order by created_at desc
          limit 12
        `;
    return { ok: true, people: rows };
  });

export const listPosts = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ ok: true; posts: PostView[] } | Err> => {
    const query = (data ?? {}) as FeedQuery;
    const sql = await getSql();
    const params: unknown[] = [];
    const conds: string[] = [];
    const add = (sqlText: string, value?: unknown) => {
      if (value === undefined) conds.push(sqlText);
      else {
        params.push(value);
        conds.push(sqlText.replace("?", `$${params.length}`));
      }
    };
    if (query.surface === "home") {
      const kind = typeof query.kind === "string" && isKind(query.kind) && HOME_KINDS.includes(query.kind) ? query.kind : null;
      if (kind) add("p.kind = ?", kind);
      else add(`p.kind in (${HOME_KINDS.map((k) => `'${k}'`).join(", ")})`);
      if (query.scope === "following") {
        params.push(context.userId);
        const me = `$${params.length}`;
        conds.push(`(p.user_id = ${me} or p.user_id in (select following_id from follows where follower_id = ${me}))`);
      }
    } else if (query.surface === "reels") {
      add("p.kind = 'reel'");
    } else if (query.surface === "subliminals") {
      add("p.kind = 'subliminal'");
    } else if (query.surface === "group") {
      const slug = text(query.slug, 32, "المجموعة");
      if (!slug.ok) return slug;
      add("p.group_slug = ?", slug.value);
    } else if (query.surface === "user") {
      const username = text(query.username, 24, "اسم الحساب");
      if (!username.ok) return username;
      add("lower(pr.username) = ?", username.value.toLowerCase());
    } else {
      return fail("عرض غير معروف");
    }
    const rows = await sql.query<PostRow>(
      `${POST_SELECT} where ${conds.join(" and ")} order by p.created_at desc limit 30`,
      params,
    );
    return { ok: true, posts: await hydrate(sql, context.userId, rows) };
  });

export const createPost = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ ok: true } | Err> => {
    const body = (data ?? {}) as Record<string, unknown>;
    if (typeof body.kind !== "string" || !isKind(body.kind)) return fail("نوع المنشور غير معروف");
    const title = text(body.title ?? "", 120, "العنوان");
    if (!title.ok) return title;
    const copy = text(body.body ?? "", 2000, "النص");
    if (!copy.ok) return copy;
    const kind = body.kind;
    if ((kind === "contest" || kind === "news" || kind === "subliminal") && !title.value) {
      return fail("العنوان مطلوب");
    }
    if (kind !== "reel" && !copy.value) return fail("اكتب شيئاً قبل النشر");
    if (kind === "reel" && !copy.value && !title.value) {
      /* caption optional if image exists */
    }
    const media = jpeg(body.media, kind === "reel" ? 520_000 : 420_000);
    if (!media.ok) return media;
    if (kind === "reel" && !media.value) return fail("أضف صورة الميم أو الريل");
    if (kind !== "reel" && kind !== "subliminal" && media.value) return fail("الصورة متاحة للريلز والسيبلمنال");
    let link: string | null = null;
    if (typeof body.link === "string" && body.link.trim()) {
      if (kind !== "subliminal") return fail("الرابط للسيبلمنال فقط");
      try {
        const url = new URL(body.link.trim());
        if (url.protocol !== "https:" && url.protocol !== "http:") return fail("الرابط غير صالح");
        link = url.toString().slice(0, 400);
      } catch {
        return fail("الرابط غير صالح");
      }
    }
    const sql = await getSql();
    const me = await profileByUser(sql, context.userId);
    if (!me) return fail("أنشئ الملف أولاً");
    let group: string | null = null;
    if (typeof body.groupSlug === "string" && body.groupSlug.trim()) {
      const slug = text(body.groupSlug, 32, "المجموعة");
      if (!slug.ok) return slug;
      const member = await sql<{ ok: number }>`
        select 1 as ok from group_members
        where group_slug = ${slug.value} and user_id = ${context.userId} limit 1
      `;
      if (!member.length) return fail("انضم إلى المجموعة قبل النشر فيها");
      group = slug.value;
    }
    const id = crypto.randomUUID();
    await sql`
      insert into posts (id, user_id, kind, title, body, media, link, group_slug)
      values (${id}, ${context.userId}, ${kind}, ${title.value}, ${copy.value}, ${media.value}, ${link}, ${group})
    `;
    return { ok: true };
  });

export const deletePost = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ ok: true } | Err> => {
    const id = text((data as { id?: unknown })?.id, 80, "المنشور");
    if (!id.ok) return id;
    const sql = await getSql();
    const rows = await sql<{ id: string }>`
      delete from posts where id = ${id.value} and user_id = ${context.userId} returning id
    `;
    if (!rows.length) return fail("لا يمكن حذف هذا المنشور");
    return { ok: true };
  });

export const setReaction = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .middleware([authMiddleware])
  .handler(async ({
    context,
    data,
  }): Promise<{ ok: true; reactions: Record<string, number>; myReaction: string | null } | Err> => {
    const body = (data ?? {}) as Record<string, unknown>;
    const id = text(body.postId, 80, "المنشور");
    if (!id.ok) return id;
    if (typeof body.kind !== "string" || !isReaction(body.kind)) return fail("لمسة غير معروفة");
    const sql = await getSql();
    const me = await profileByUser(sql, context.userId);
    if (!me) return fail("أنشئ الملف أولاً");
    const post = await sql<{ id: string }>`select id from posts where id = ${id.value} limit 1`;
    if (!post.length) return fail("المنشور غير موجود");
    const current = await sql<{ kind: string }>`
      select kind from reactions where post_id = ${id.value} and user_id = ${context.userId} limit 1
    `;
    if (current[0]?.kind === body.kind) {
      await sql`delete from reactions where post_id = ${id.value} and user_id = ${context.userId}`;
    } else {
      await sql`
        insert into reactions (post_id, user_id, kind)
        values (${id.value}, ${context.userId}, ${body.kind})
        on conflict (post_id, user_id) do update set kind = excluded.kind
      `;
    }
    const rows = await sql<{ kind: string; n: number }>`
      select kind, count(*)::int as n from reactions where post_id = ${id.value} group by kind
    `;
    const mine = await sql<{ kind: string }>`
      select kind from reactions where post_id = ${id.value} and user_id = ${context.userId} limit 1
    `;
    const reactions: Record<string, number> = {};
    for (const row of rows) reactions[row.kind] = Number(row.n);
    return { ok: true, reactions, myReaction: mine[0]?.kind ?? null };
  });

export const listComments = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ ok: true; comments: CommentView[] } | Err> => {
    const id = text((data as { postId?: unknown })?.postId, 80, "المنشور");
    if (!id.ok) return id;
    const sql = await getSql();
    const rows = await sql<{
      id: string;
      username: string;
      avatar: string | null;
      body: string;
      sticker: string | null;
      created_at: string;
      user_id: string;
    }>`
      select c.id, pr.username, pr.avatar, c.body, c.sticker, c.created_at::text as created_at, c.user_id
      from comments c
      join profiles pr on pr.user_id = c.user_id
      where c.post_id = ${id.value}
      order by c.created_at asc
      limit 80
    `;
    return {
      ok: true,
      comments: rows.map((row) => ({
        id: row.id,
        username: row.username,
        avatar: row.avatar,
        body: row.body,
        sticker: row.sticker,
        createdAt: String(row.created_at),
        mine: row.user_id === context.userId,
      })),
    };
  });

export const addComment = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ ok: true } | Err> => {
    const body = (data ?? {}) as Record<string, unknown>;
    const postId = text(body.postId, 80, "المنشور");
    if (!postId.ok) return postId;
    const copy = text(body.body ?? "", 500, "التعليق");
    if (!copy.ok) return copy;
    const sticker = typeof body.sticker === "string" && body.sticker ? body.sticker : null;
    if (sticker && !isSticker(sticker)) return fail("ملصق غير معروف");
    if (!copy.value && !sticker) return fail("اكتب تعليقاً أو اختر ملصقاً");
    const sql = await getSql();
    const me = await profileByUser(sql, context.userId);
    if (!me) return fail("أنشئ الملف أولاً");
    const post = await sql<{ id: string }>`select id from posts where id = ${postId.value} limit 1`;
    if (!post.length) return fail("المنشور غير موجود");
    await sql`
      insert into comments (id, post_id, user_id, body, sticker)
      values (${crypto.randomUUID()}, ${postId.value}, ${context.userId}, ${copy.value}, ${sticker})
    `;
    return { ok: true };
  });

export const deleteComment = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ ok: true } | Err> => {
    const id = text((data as { id?: unknown })?.id, 80, "التعليق");
    if (!id.ok) return id;
    const sql = await getSql();
    const rows = await sql<{ id: string }>`
      delete from comments where id = ${id.value} and user_id = ${context.userId} returning id
    `;
    if (!rows.length) return fail("لا يمكن حذف هذا التعليق");
    return { ok: true };
  });

export const joinGroup = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ ok: true } | Err> => {
    const slug = text((data as { slug?: unknown })?.slug, 32, "المجموعة");
    if (!slug.ok) return slug;
    const sql = await getSql();
    const me = await profileByUser(sql, context.userId);
    if (!me) return fail("أنشئ الملف أولاً");
    const group = await sql<{ slug: string }>`select slug from groups where slug = ${slug.value} limit 1`;
    if (!group.length) return fail("المجموعة غير موجودة");
    await sql`
      insert into group_members (group_slug, user_id)
      values (${slug.value}, ${context.userId})
      on conflict do nothing
    `;
    return { ok: true };
  });

export const leaveGroup = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ ok: true } | Err> => {
    const slug = text((data as { slug?: unknown })?.slug, 32, "المجموعة");
    if (!slug.ok) return slug;
    const sql = await getSql();
    const group = await sql<{ forced: boolean }>`select forced from groups where slug = ${slug.value} limit 1`;
    if (!group.length) return fail("المجموعة غير موجودة");
    if (group[0].forced) return fail("هذه المجموعة شاملة ولا تُغادر");
    await sql`delete from group_members where group_slug = ${slug.value} and user_id = ${context.userId}`;
    return { ok: true };
  });

export const listGroupMembers = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .middleware([authMiddleware])
  .handler(async ({ data }): Promise<{ ok: true; people: Person[] } | Err> => {
    const slug = text((data as { slug?: unknown })?.slug, 32, "المجموعة");
    if (!slug.ok) return slug;
    const sql = await getSql();
    const rows = await sql<Person>`
      select pr.username, pr.avatar, pr.role, pr.bio
      from group_members m
      join profiles pr on pr.user_id = m.user_id
      where m.group_slug = ${slug.value}
      order by m.joined_at asc
      limit 48
    `;
    return { ok: true, people: rows };
  });
