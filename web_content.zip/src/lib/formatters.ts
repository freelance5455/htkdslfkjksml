import { Timestamp } from 'firebase/firestore';
import { Product } from '../types/store';

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function getEffectivePrice(product: Pick<Product, 'price' | 'discountPrice'>): number {
  if (product.discountPrice > 0 && product.discountPrice < product.price) {
    return product.discountPrice;
  }
  return product.price;
}

export function getDiscountPercent(price: number, discountPrice: number): number {
  if (discountPrice <= 0 || discountPrice >= price || price <= 0) return 0;
  return Math.round(((price - discountPrice) / price) * 100);
}

export function formatDate(value?: Timestamp | Date | null): string {
  if (!value) return '—';
  const date = value instanceof Timestamp ? value.toDate() : value;
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  }).format(date);
}

export function formatDateTime(value?: Timestamp | Date | null): string {
  if (!value) return '—';
  const date = value instanceof Timestamp ? value.toDate() : value;
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date);
}

export function isValidImageUrl(url: string): boolean {
  if (!url) return false;
  if (url.startsWith('/src/assets/')) return true;
  try {
    const parsed = new URL(url);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:';
  } catch {
    return false;
  }
}

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'item';
}
