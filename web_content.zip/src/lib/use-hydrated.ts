import { useEffect, useState } from "react";
import { useStore } from "@/lib/store";

let started = false;

export function useHydrated() {
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    const finish = () => setHydrated(true);
    const unsub = useStore.persist.onFinishHydration(finish);
    if (!started) {
      started = true;
      void useStore.persist.rehydrate();
    }
    if (useStore.persist.hasHydrated()) finish();
    return unsub;
  }, []);

  return hydrated;
}
