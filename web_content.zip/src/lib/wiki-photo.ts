const cache = new Map<string, string | null>();
const AGE_KEY = "stardex-wiki-photos";

function loadLocal(): Record<string, string> {
  try {
    const raw = localStorage.getItem(AGE_KEY);
    if (!raw) return {};
    return JSON.parse(raw) as Record<string, string>;
  } catch {
    return {};
  }
}

function saveLocal(map: Record<string, string>) {
  try {
    localStorage.setItem(AGE_KEY, JSON.stringify(map));
  } catch {
    /* quota */
  }
}

export async function fetchWikiThumb(wikiTitle: string): Promise<string | null> {
  if (cache.has(wikiTitle)) return cache.get(wikiTitle) ?? null;
  const local = loadLocal();
  if (local[wikiTitle] !== undefined) {
    cache.set(wikiTitle, local[wikiTitle] || null);
    return local[wikiTitle] || null;
  }
  try {
    const title = encodeURIComponent(wikiTitle.replace(/ /g, "_"));
    const res = await fetch(
      `https://en.wikipedia.org/api/rest_v1/page/summary/${title}`,
      { headers: { accept: "application/json" } },
    );
    if (!res.ok) {
      cache.set(wikiTitle, null);
      local[wikiTitle] = "";
      saveLocal(local);
      return null;
    }
    const data = (await res.json()) as { thumbnail?: { source?: string } };
    const src = data.thumbnail?.source ?? null;
    cache.set(wikiTitle, src);
    local[wikiTitle] = src ?? "";
    saveLocal(local);
    return src;
  } catch {
    cache.set(wikiTitle, null);
    return null;
  }
}
