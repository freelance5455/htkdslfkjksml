const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

/** Convert a number (or numeric string) to Persian digits. */
export function toFa(value: number | string, pad = 0): string {
  let s = typeof value === "number" ? String(value) : value;
  if (pad > 0) s = s.padStart(pad, "0");
  return s.replace(/\d/g, (d) => FA_DIGITS[Number(d)]);
}

/** Playful message that changes as the visitor keeps tickling the chick. */
export function pokeMessage(n: number): string {
  if (n === 0) return "یه جای جیکو رو لمس کن";
  if (n < 4) return "جیـــک جیـــک!";
  if (n < 10) return "قلقلکش میاد";
  if (n < 20) return "داره حسابی خوشش میاد";
  if (n < 35) return "وای، سرگیجه گرفت";
  if (n < 60) return "دیگه شورش رو درآوردی";
  return "قهرمانِ قلقلک شدی";
}
