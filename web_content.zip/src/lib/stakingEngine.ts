// JUHNKRIX MUSIKA - Staking Engine Utility
// Handles JMC staking, APY calculations, locking periods, and 'Prophetic Rewards' multipliers.

export interface StakePosition {
  id: string;
  amount: number;
  horizonDays: number;
  apyPercent: number;
  startDate: string;
  unlockDate: string;
  propheticMultiplier: number;
  earnedRewards: number;
  status: 'ACTIVE' | 'CLAIMED' | 'UNLOCKED';
}

const STAKING_STORAGE_KEY = 'jm_sovereign_staking_positions_v1';

class StakingEngineService {
  public getStakedPositions(): StakePosition[] {
    try {
      const stored = localStorage.getItem(STAKING_STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {}

    // Default demo stake
    const defaultPositions: StakePosition[] = [
      {
        id: 'stake-001',
        amount: 1.2500,
        horizonDays: 90,
        apyPercent: 77.7,
        startDate: '2026-10-01',
        unlockDate: '2026-12-30',
        propheticMultiplier: 2.5,
        earnedRewards: 0.1450,
        status: 'ACTIVE'
      }
    ];
    localStorage.setItem(STAKING_STORAGE_KEY, JSON.stringify(defaultPositions));
    return defaultPositions;
  }

  public calculateApy(horizonDays: number): { apy: number; multiplier: number } {
    if (horizonDays >= 365) return { apy: 250.0, multiplier: 5.0 };
    if (horizonDays >= 180) return { apy: 120.0, multiplier: 3.5 };
    if (horizonDays >= 90) return { apy: 77.7, multiplier: 2.5 };
    return { apy: 35.0, multiplier: 1.5 };
  }

  public createStake(amount: number, horizonDays: number): StakePosition {
    const positions = this.getStakedPositions();
    const { apy, multiplier } = this.calculateApy(horizonDays);
    
    const now = new Date();
    const unlock = new Date();
    unlock.setDate(now.getDate() + horizonDays);

    const newPosition: StakePosition = {
      id: `stake-${Date.now()}`,
      amount,
      horizonDays,
      apyPercent: apy,
      startDate: now.toLocaleDateString(),
      unlockDate: unlock.toLocaleDateString(),
      propheticMultiplier: multiplier,
      earnedRewards: +(amount * (apy / 100) * (horizonDays / 365) * 0.05).toFixed(4),
      status: 'ACTIVE'
    };

    positions.unshift(newPosition);
    localStorage.setItem(STAKING_STORAGE_KEY, JSON.stringify(positions));
    return newPosition;
  }

  public claimRewards(positionId: string): { positions: StakePosition[]; claimedAmount: number } {
    const positions = this.getStakedPositions();
    let claimedAmount = 0;
    const updated = positions.map(pos => {
      if (pos.id === positionId && pos.earnedRewards > 0) {
        claimedAmount = pos.earnedRewards;
        return {
          ...pos,
          earnedRewards: 0
        };
      }
      return pos;
    });

    localStorage.setItem(STAKING_STORAGE_KEY, JSON.stringify(updated));
    return { positions: updated, claimedAmount };
  }
}

export const stakingEngine = new StakingEngineService();
