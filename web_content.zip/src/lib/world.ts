export type Food = {
  id: string;
  name: string;
  emoji: string;
  price: number;
  fill: number;
  /** 18+ only */
  adult?: boolean;
};

export const FOODS: Food[] = [
  { id: "pofak", name: "پفک", emoji: "🍿", price: 18, fill: 22 },
  { id: "juice", name: "آب‌میوه", emoji: "🧃", price: 22, fill: 28 },
  { id: "soda", name: "نوشابه", emoji: "🥤", price: 26, fill: 32 },
  { id: "fries", name: "سیب‌زمینی", emoji: "🍟", price: 34, fill: 44 },
  { id: "sandwich", name: "ساندویچ", emoji: "🥪", price: 46, fill: 58 },
  { id: "burger", name: "فست‌فود", emoji: "🍔", price: 58, fill: 72 },
  { id: "pizza", name: "پیتزا", emoji: "🍕", price: 72, fill: 95 },
  { id: "beer", name: "آب‌جو", emoji: "🍺", price: 64, fill: 80, adult: true },
  { id: "wine", name: "نوشیدنی کهنه", emoji: "🍷", price: 88, fill: 110, adult: true },
];

export type Car = { id: string; name: string; emoji: string; price: number; speed: number };

export const CARS: Car[] = [
  { id: "paykan", name: "پیکان", emoji: "🚗", price: 250, speed: 1 },
  { id: "pride", name: "پراید", emoji: "🚙", price: 380, speed: 1.1 },
  { id: "tiba", name: "تیبا", emoji: "🚗", price: 520, speed: 1.2 },
  { id: "samand", name: "سمند", emoji: "🚙", price: 700, speed: 1.3 },
  { id: "peugeot", name: "پژو ۴۰۵", emoji: "🚗", price: 900, speed: 1.4 },
  { id: "dena", name: "دنا", emoji: "🚙", price: 1150, speed: 1.55 },
  { id: "shahin", name: "شاهین", emoji: "🚗", price: 1450, speed: 1.7 },
  { id: "vitara", name: "ویتارا", emoji: "🚙", price: 1800, speed: 1.85 },
  { id: "sonata", name: "سوناتا", emoji: "🚘", price: 2200, speed: 2 },
  { id: "optima", name: "اپتیما", emoji: "🚘", price: 2700, speed: 2.2 },
  { id: "camry", name: "کمری", emoji: "🚘", price: 3300, speed: 2.4 },
  { id: "lexus", name: "لکسوس", emoji: "🏎️", price: 4200, speed: 2.7 },
  { id: "bmw", name: "بی‌ام‌و", emoji: "🏎️", price: 5200, speed: 3 },
  { id: "benz", name: "بنز", emoji: "🏎️", price: 6400, speed: 3.3 },
  { id: "audi", name: "آئودی", emoji: "🏎️", price: 7800, speed: 3.6 },
  { id: "range", name: "رنج‌روور", emoji: "🚙", price: 9500, speed: 3.9 },
  { id: "tesla", name: "تسلا", emoji: "⚡", price: 12000, speed: 4.3 },
  { id: "maserati", name: "مازراتی", emoji: "🏎️", price: 15000, speed: 4.7 },
  { id: "ferrari", name: "فراری", emoji: "🏎️", price: 19000, speed: 5.2 },
  { id: "porsche", name: "پورشه", emoji: "🏎️", price: 24000, speed: 6 },
];

export type Route = { id: string; label: string; emoji: string; seconds: number; pay: number; fuel: number };

export const ROUTES: Route[] = [
  { id: "short", label: "مسیر کوتاه", emoji: "🏘️", seconds: 8, pay: 90, fuel: 10 },
  { id: "mid", label: "مسیر متوسط", emoji: "🌆", seconds: 14, pay: 180, fuel: 18 },
  { id: "long", label: "مسیر طولانی", emoji: "🛣️", seconds: 22, pay: 320, fuel: 28 },
  { id: "traffic", label: "ترافیک سنگین", emoji: "🚦", seconds: 30, pay: 460, fuel: 38 },
];

export const HUB_SECTIONS = [
  { id: "jobs", title: "شغل‌ها و بازی‌ها", emoji: "💼", desc: "رفتگری، دزدی، تاکسی، دوز، قمار", tint: "#FFD166" },
  { id: "wallet", title: "کیف پول و بانک", emoji: "🏦", desc: "جیب، حساب، وام و سود روزانه", tint: "#8ECAE6" },
  { id: "farm", title: "مزرعه", emoji: "🌾", desc: "سود ساعتی و قاچاق مرغ", tint: "#A7E8A0" },
  { id: "market", title: "سوپرمارکت", emoji: "🛒", desc: "غذا بخر و توی یخچال بذار", tint: "#FFB4A2" },
  { id: "garage", title: "نمایشگاه و گاراژ", emoji: "🚗", desc: "۲۰ ماشین، بنزین و تعمیرگاه", tint: "#9BD1FF" },
  { id: "profile", title: "شناسنامه جیکو", emoji: "📋", desc: "سن، جنسیت، کد و باشگاه", tint: "#C4B5FD" },
  { id: "mars", title: "مریخ", emoji: "🔴", desc: "بلیط بخر، پرواز کن، با فضایی‌ها بجنگ", tint: "#FF9A6B" },
] as const;

export const JOB_LIST = [
  { id: "sweep", title: "رفتگری", emoji: "🧹", desc: "آشغال‌ها رو از خیابون جمع کن", pay: "۶۰ پوینت هر زباله", tint: "#A7E8A0", live: true },
  { id: "heist", title: "دزدی", emoji: "🕵️", desc: "جیب رهگذرهای شب رو بزن", pay: "۱۸۰ تا ۴۲۰ هر نفر", tint: "#FCA5A5", live: true },
  { id: "taxi", title: "مسافرکشی", emoji: "🚕", desc: "نیاز به سطح ۳، ماشین و بنزین", pay: "تا ۴۶۰ هر سفر", tint: "#FDE68A", live: false },
  { id: "dooz", title: "دوز", emoji: "⭕", desc: "با کامپیوتر دوز بازی کن", pay: "شرط ۵۰ — برد ×۲", tint: "#BFDBFE", live: false },
  { id: "casino", title: "قمار", emoji: "🎰", desc: "اسلات سه‌قرقره‌ای", pay: "تا ×۲۰ شرط", tint: "#F0ABFC", live: false },
] as const;

/* ================================================================== */
/*  MARS — ticket, weapons                                             */
/* ================================================================== */
export const MARS_TICKET = 2500;
/** seconds spent flying in each direction */
export const FLIGHT_SECONDS = 13;
export const FIGHT_SECONDS = 13;

export type Weapon = {
  id: string;
  name: string;
  emoji: string;
  price: number;
  /** damage per hit */
  dmg: number;
  /** ms between shots */
  cooldown: number;
  /** bullet travel speed (units/s) */
  speed: number;
  color: string;
  desc: string;
};

/** expensive → cheap */
export const WEAPONS: Weapon[] = [
  {
    id: "plasma",
    name: "توپ پلاسما",
    emoji: "🔱",
    price: 40000,
    dmg: 3,
    cooldown: 260,
    speed: 16,
    color: "#C77DFF",
    desc: "قوی‌ترین سلاح — هر شلیک ۳ آسیب و سرعت بالا",
  },
  {
    id: "laser",
    name: "تفنگ لیزری",
    emoji: "🔫",
    price: 12000,
    dmg: 2,
    cooldown: 340,
    speed: 13,
    color: "#4CC9F0",
    desc: "تعادل خوب بین قدرت و سرعت شلیک",
  },
  {
    id: "pistol",
    name: "کلت ساده",
    emoji: "🔧",
    price: 3000,
    dmg: 1,
    cooldown: 460,
    speed: 10,
    color: "#FFD166",
    desc: "ارزون‌ترین گزینه — برای شروع بد نیست",
  },
];
