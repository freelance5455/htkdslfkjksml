/**
 * Session-scoped File / ObjectURL registry.
 * Files cannot live in localStorage; handles may persist in IndexedDB (Chromium).
 */

const files = new Map<string, File>();
const urls = new Map<string, string>();
const handles = new Map<string, FileSystemFileHandle>();

export function setFile(id: string, file: File): string {
  files.set(id, file);
  const prev = urls.get(id);
  if (prev) URL.revokeObjectURL(prev);
  const url = URL.createObjectURL(file);
  urls.set(id, url);
  return url;
}

export function getFile(id: string): File | undefined {
  return files.get(id);
}

export function getObjectUrl(id: string): string | undefined {
  return urls.get(id);
}

export function setHandle(id: string, handle: FileSystemFileHandle): void {
  handles.set(id, handle);
}

export function getHandle(id: string): FileSystemFileHandle | undefined {
  return handles.get(id);
}

export function release(id: string): void {
  files.delete(id);
  handles.delete(id);
  const prev = urls.get(id);
  if (prev) URL.revokeObjectURL(prev);
  urls.delete(id);
}

export function releaseAll(): void {
  for (const id of [...urls.keys()]) release(id);
}

export async function fileFromHandle(handle: FileSystemFileHandle): Promise<File | null> {
  try {
    const anyHandle = handle as FileSystemFileHandle & {
      queryPermission?: (d: { mode: "read" }) => Promise<PermissionState>;
      requestPermission?: (d: { mode: "read" }) => Promise<PermissionState>;
    };
    if (anyHandle.queryPermission) {
      let state = await anyHandle.queryPermission({ mode: "read" });
      if (state !== "granted" && anyHandle.requestPermission) {
        state = await anyHandle.requestPermission({ mode: "read" });
      }
      if (state !== "granted") return null;
    }
    return await handle.getFile();
  } catch {
    return null;
  }
}
