import type { AnalyzedRequest, ContentBrief, Script, Storyboard, Project, Idea, CreatorMemory } from "@/types";

export interface GeminiStatus {
  connected: boolean;
  model: string;
  message: string;
}

// Check server-side Gemini status
export async function checkGeminiStatus(): Promise<GeminiStatus> {
  try {
    const res = await fetch("/api/gemini/status");
    if (!res.ok) throw new Error("Status endpoint failed");
    return await res.json();
  } catch {
    return {
      connected: false,
      model: "gemini-3.7-flash",
      message: "Modo inteligente local ativado.",
    };
  }
}

// Call server-side Gemini to analyze natural language prompt
export async function analyzePromptWithGemini(
  prompt: string,
  memory?: Partial<CreatorMemory>
): Promise<Partial<AnalyzedRequest> | null> {
  try {
    const res = await fetch("/api/gemini/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt, memory }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (data.success && data.data) {
      return data.data;
    }
    return null;
  } catch (err) {
    console.warn("Gemini analyze request failed, using local analyzer:", err);
    return null;
  }
}

// Call server-side Gemini to generate a Content Brief
export async function generateBriefWithGemini(
  project: Project,
  customInstructions?: string
): Promise<Partial<ContentBrief> | null> {
  try {
    const res = await fetch("/api/gemini/brief", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ project, customInstructions }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (data.success && data.data) {
      return data.data;
    }
    return null;
  } catch (err) {
    console.warn("Gemini brief request failed, using local generator:", err);
    return null;
  }
}

// Call server-side Gemini to generate a Script
export async function generateScriptWithGemini(
  project: Project,
  customPrompt?: string
): Promise<Partial<Script> | null> {
  try {
    const res = await fetch("/api/gemini/script", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ project, customPrompt }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (data.success && data.data) {
      return data.data;
    }
    return null;
  } catch (err) {
    console.warn("Gemini script request failed, using local generator:", err);
    return null;
  }
}

// Call server-side Gemini to generate Storyboard scenes
export async function generateStoryboardWithGemini(
  project: Project
): Promise<Partial<Storyboard> | null> {
  try {
    const res = await fetch("/api/gemini/storyboard", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ project }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (data.success && data.data) {
      return data.data;
    }
    return null;
  } catch (err) {
    console.warn("Gemini storyboard request failed, using local generator:", err);
    return null;
  }
}

// Call server-side Gemini for intelligent Chat Co-Pilot
export async function sendChatMessageToGemini(
  message: string,
  project: Project,
  history: Array<{ role: string; content: string }>
): Promise<string | null> {
  try {
    const res = await fetch("/api/gemini/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, project, history }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (data.success && data.content) {
      return data.content;
    }
    return null;
  } catch (err) {
    console.warn("Gemini chat request failed, using fallback:", err);
    return null;
  }
}

// Call server-side Gemini to generate Creative Content Ideas
export async function generateIdeasWithGemini(
  topic?: string,
  platform?: string,
  count = 4
): Promise<Array<{ title: string; description: string; tags: string[] }> | null> {
  try {
    const res = await fetch("/api/gemini/ideas", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ topic, platform, count }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (data.success && Array.isArray(data.data)) {
      return data.data;
    }
    return null;
  } catch (err) {
    console.warn("Gemini ideas request failed, using fallback:", err);
    return null;
  }
}
