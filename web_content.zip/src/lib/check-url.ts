import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export type UrlHealth = {
  ok: boolean;
  status: number;
  ms: number;
  checkedAt: number;
  error?: string;
};

export const checkUrlHealth = createServerFn({ method: "POST" })
  .validator(z.object({ url: z.string().min(1).max(2000) }))
  .handler(async ({ data }): Promise<UrlHealth> => {
    const started = Date.now();
    let url = data.url.trim();
    if (!/^https?:\/\//i.test(url)) url = `https://${url}`;
    try {
      const parsed = new URL(url);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
        return { ok: false, status: 0, ms: 0, checkedAt: Date.now(), error: "bad protocol" };
      }
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 8000);
      const res = await fetch(parsed.toString(), {
        method: "GET",
        redirect: "follow",
        signal: controller.signal,
        headers: {
          "User-Agent": "LakshaWatch/1.0 (uptime-monitor)",
          Accept: "text/html,application/json;q=0.9,*/*;q=0.8",
        },
      });
      clearTimeout(timer);
      return {
        ok: res.ok,
        status: res.status,
        ms: Date.now() - started,
        checkedAt: Date.now(),
      };
    } catch (err) {
      return {
        ok: false,
        status: 0,
        ms: Date.now() - started,
        checkedAt: Date.now(),
        error: err instanceof Error ? err.message : "failed",
      };
    }
  });
