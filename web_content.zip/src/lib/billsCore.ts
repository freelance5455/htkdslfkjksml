import { daysInMonth, pad, todayKey } from "./calendar";
import type { PeriodStatus } from "./types";

function round(n: number) {
  return Math.round(n * 100) / 100;
}

export function dueDateFor(month: string, dueDay: number) {
  const max = daysInMonth(month);
  return `${month}-${pad(Math.min(Math.max(1, dueDay), max))}`;
}

export function statusFor(opts: {
  period: string;
  due: number;
  paid: number;
  currentPeriod: string;
  dueDate: string;
}): PeriodStatus {
  const { period, due, paid, currentPeriod, dueDate } = opts;
  const settled = paid + 0.005 >= due;
  if (settled) return "paid";
  if (period < currentPeriod) return paid > 0 ? "partial" : "overdue";
  if (period === currentPeriod) {
    if (paid > 0) return "partial";
    return todayKey() >= dueDate ? "due" : "upcoming";
  }
  return "upcoming";
}

export { round };
