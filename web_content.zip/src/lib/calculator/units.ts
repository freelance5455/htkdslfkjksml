export type UnitCategoryId =
  | "length"
  | "area"
  | "volume"
  | "mass"
  | "temperature"
  | "speed"
  | "time"
  | "data"
  | "energy"
  | "power"
  | "pressure"
  | "angle"
  | "frequency"
  | "force"
  | "fuel";

export type LinearUnit = { id: string; label: string; toBase: number };
export type TempUnit = { id: string; label: string; kind: "C" | "F" | "K" };
export type UnitDef = LinearUnit | TempUnit;

export type Category = {
  id: UnitCategoryId;
  label: string;
  units: UnitDef[];
  temperature?: boolean;
};

function u(id: string, label: string, toBase: number): LinearUnit {
  return { id, label, toBase };
}

export const CATEGORIES: Category[] = [
  {
    id: "length",
    label: "Length",
    units: [
      u("m", "Meters", 1),
      u("km", "Kilometers", 1000),
      u("cm", "Centimeters", 0.01),
      u("mm", "Millimeters", 0.001),
      u("um", "Micrometers", 1e-6),
      u("nm", "Nanometers", 1e-9),
      u("mi", "Miles", 1609.344),
      u("yd", "Yards", 0.9144),
      u("ft", "Feet", 0.3048),
      u("in", "Inches", 0.0254),
      u("nmi", "Nautical miles", 1852),
      u("ly", "Light years", 9.4607304725808e15),
      u("au", "Astronomical units", 149597870700),
    ],
  },
  {
    id: "area",
    label: "Area",
    units: [
      u("m2", "Square meters", 1),
      u("km2", "Square kilometers", 1e6),
      u("cm2", "Square centimeters", 1e-4),
      u("mm2", "Square millimeters", 1e-6),
      u("ha", "Hectares", 1e4),
      u("ac", "Acres", 4046.8564224),
      u("mi2", "Square miles", 2.589988110336e6),
      u("ft2", "Square feet", 0.09290304),
      u("in2", "Square inches", 0.00064516),
    ],
  },
  {
    id: "volume",
    label: "Volume",
    units: [
      u("m3", "Cubic meters", 1),
      u("l", "Liters", 0.001),
      u("ml", "Milliliters", 1e-6),
      u("gal", "US gallons", 0.003785411784),
      u("qt", "US quarts", 0.000946352946),
      u("pt", "US pints", 0.000473176473),
      u("cup", "US cups", 0.0002365882365),
      u("floz", "US fl oz", 2.95735295625e-5),
      u("tbsp", "Tablespoons", 1.478676478125e-5),
      u("tsp", "Teaspoons", 4.92892159375e-6),
      u("impgal", "Imperial gallons", 0.00454609),
      u("ft3", "Cubic feet", 0.028316846592),
      u("in3", "Cubic inches", 1.6387064e-5),
    ],
  },
  {
    id: "mass",
    label: "Mass",
    units: [
      u("kg", "Kilograms", 1),
      u("g", "Grams", 0.001),
      u("mg", "Milligrams", 1e-6),
      u("t", "Metric tons", 1000),
      u("lb", "Pounds", 0.45359237),
      u("oz", "Ounces", 0.028349523125),
      u("st", "Stone", 6.35029318),
      u("ton", "US tons", 907.18474),
      u("ukton", "Imperial tons", 1016.0469088),
    ],
  },
  {
    id: "temperature",
    label: "Temperature",
    temperature: true,
    units: [
      { id: "C", label: "Celsius", kind: "C" },
      { id: "F", label: "Fahrenheit", kind: "F" },
      { id: "K", label: "Kelvin", kind: "K" },
    ],
  },
  {
    id: "speed",
    label: "Speed",
    units: [
      u("mps", "Meters/second", 1),
      u("kph", "Kilometers/hour", 1 / 3.6),
      u("mph", "Miles/hour", 0.44704),
      u("fps", "Feet/second", 0.3048),
      u("knot", "Knots", 0.514444444),
      u("c", "Speed of light", 299792458),
    ],
  },
  {
    id: "time",
    label: "Time",
    units: [
      u("s", "Seconds", 1),
      u("ms", "Milliseconds", 0.001),
      u("us", "Microseconds", 1e-6),
      u("ns", "Nanoseconds", 1e-9),
      u("min", "Minutes", 60),
      u("h", "Hours", 3600),
      u("d", "Days", 86400),
      u("wk", "Weeks", 604800),
      u("yr", "Years", 31557600),
    ],
  },
  {
    id: "data",
    label: "Data",
    units: [
      u("b", "Bits", 1),
      u("B", "Bytes", 8),
      u("kb", "Kilobits", 1e3),
      u("kib", "Kibibits", 1024),
      u("KB", "Kilobytes", 8e3),
      u("KiB", "Kibibytes", 8192),
      u("MB", "Megabytes", 8e6),
      u("MiB", "Mebibytes", 8 * 1024 * 1024),
      u("GB", "Gigabytes", 8e9),
      u("GiB", "Gibibytes", 8 * 1024 ** 3),
      u("TB", "Terabytes", 8e12),
      u("TiB", "Tebibytes", 8 * 1024 ** 4),
    ],
  },
  {
    id: "energy",
    label: "Energy",
    units: [
      u("J", "Joules", 1),
      u("kJ", "Kilojoules", 1000),
      u("cal", "Calories", 4.184),
      u("kcal", "Kilocalories", 4184),
      u("Wh", "Watt hours", 3600),
      u("kWh", "Kilowatt hours", 3.6e6),
      u("eV", "Electronvolts", 1.602176634e-19),
      u("btu", "BTU", 1055.05585262),
    ],
  },
  {
    id: "power",
    label: "Power",
    units: [
      u("W", "Watts", 1),
      u("kW", "Kilowatts", 1000),
      u("MW", "Megawatts", 1e6),
      u("hp", "Horsepower", 745.69987158227),
      u("btuh", "BTU/hour", 0.29307107017222),
    ],
  },
  {
    id: "pressure",
    label: "Pressure",
    units: [
      u("Pa", "Pascals", 1),
      u("kPa", "Kilopascals", 1000),
      u("bar", "Bar", 1e5),
      u("atm", "Atmospheres", 101325),
      u("psi", "PSI", 6894.757293168),
      u("torr", "Torr", 133.322368421),
      u("mmHg", "mmHg", 133.322368421),
    ],
  },
  {
    id: "angle",
    label: "Angle",
    units: [
      u("rad", "Radians", 1),
      u("deg", "Degrees", Math.PI / 180),
      u("grad", "Gradians", Math.PI / 200),
      u("arcmin", "Arcminutes", Math.PI / 10800),
      u("arcsec", "Arcseconds", Math.PI / 648000),
      u("turn", "Turns", Math.PI * 2),
    ],
  },
  {
    id: "frequency",
    label: "Frequency",
    units: [
      u("Hz", "Hertz", 1),
      u("kHz", "Kilohertz", 1e3),
      u("MHz", "Megahertz", 1e6),
      u("GHz", "Gigahertz", 1e9),
      u("rpm", "RPM", 1 / 60),
    ],
  },
  {
    id: "force",
    label: "Force",
    units: [
      u("N", "Newtons", 1),
      u("kN", "Kilonewtons", 1000),
      u("lbf", "Pound-force", 4.4482216152605),
      u("kgf", "Kilogram-force", 9.80665),
      u("dyn", "Dynes", 1e-5),
    ],
  },
  {
    id: "fuel",
    label: "Fuel economy",
    units: [
      u("lp100", "L/100 km", 1),
      u("mpgUS", "MPG (US)", 0),
      u("mpgUK", "MPG (UK)", 0),
      u("kpl", "km/L", 0),
    ],
  },
];

function isTemp(u: UnitDef): u is TempUnit {
  return "kind" in u;
}

function toKelvin(value: number, kind: "C" | "F" | "K"): number {
  if (kind === "K") return value;
  if (kind === "C") return value + 273.15;
  return ((value - 32) * 5) / 9 + 273.15;
}

function fromKelvin(k: number, kind: "C" | "F" | "K"): number {
  if (kind === "K") return k;
  if (kind === "C") return k - 273.15;
  return ((k - 273.15) * 9) / 5 + 32;
}

const MPG_US_PER_LP100 = 235.214583;
const MPG_UK_PER_LP100 = 282.480936;
const KPL_PER_LP100 = 100;

export function convertValue(
  value: number,
  categoryId: UnitCategoryId,
  fromId: string,
  toId: string,
): number {
  const cat = CATEGORIES.find((c) => c.id === categoryId);
  if (!cat) return value;
  const from = cat.units.find((x) => x.id === fromId);
  const to = cat.units.find((x) => x.id === toId);
  if (!from || !to) return value;

  if (cat.temperature && isTemp(from) && isTemp(to)) {
    return fromKelvin(toKelvin(value, from.kind), to.kind);
  }

  if (cat.id === "fuel") {
    const lp100 = toLp100(value, fromId);
    return fromLp100(lp100, toId);
  }

  if (!isTemp(from) && !isTemp(to)) {
    return (value * from.toBase) / to.toBase;
  }
  return value;
}

function toLp100(value: number, id: string): number {
  if (id === "lp100") return value;
  if (value === 0) return 0;
  if (id === "mpgUS") return MPG_US_PER_LP100 / value;
  if (id === "mpgUK") return MPG_UK_PER_LP100 / value;
  if (id === "kpl") return KPL_PER_LP100 / value;
  return value;
}

function fromLp100(lp100: number, id: string): number {
  if (id === "lp100") return lp100;
  if (lp100 === 0) return 0;
  if (id === "mpgUS") return MPG_US_PER_LP100 / lp100;
  if (id === "mpgUK") return MPG_UK_PER_LP100 / lp100;
  if (id === "kpl") return KPL_PER_LP100 / lp100;
  return lp100;
}

export function categoryById(id: UnitCategoryId): Category {
  return CATEGORIES.find((c) => c.id === id) ?? CATEGORIES[0]!;
}
