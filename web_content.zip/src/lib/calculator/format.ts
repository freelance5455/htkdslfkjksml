import { DISPLAY_DIGITS } from "./types";
import { D, Decimal } from "./decimal";

const GROUP = new Intl.NumberFormat("en-US");

export function formatDecimal(value: Decimal, digits = DISPLAY_DIGITS): string {
  if (!value.isFinite()) return "Error";

  const snapped = snapNearInteger(value);
  const abs = snapped.abs();

  if (abs.eq(0)) return "0";

  const tooBig = abs.gte(D(10).pow(digits));
  const tooSmall = abs.lt(D(10).pow(1 - digits));

  if (tooBig || tooSmall) {
    const exp = snapped.toExponential(Math.max(1, digits - 1), Decimal.ROUND_HALF_UP);
    return tidyExp(exp);
  }

  const sig = snapped.toSignificantDigits(digits, Decimal.ROUND_HALF_UP);
  let raw = sig.toFixed();
  if (raw.includes("e") || raw.includes("E")) {
    return tidyExp(sig.toExponential(digits - 1, Decimal.ROUND_HALF_UP));
  }

  if (raw.includes(".")) {
    raw = raw.replace(/(\.\d*?)0+$/, "$1").replace(/\.$/, "");
  }
  return groupInt(raw);
}

function snapNearInteger(value: Decimal): Decimal {
  const nearest = value.toDecimalPlaces(0, Decimal.ROUND_HALF_UP);
  if (value.minus(nearest).abs().lt("1e-14")) return nearest;
  return value;
}

function tidyExp(exp: string): string {
  const [mant, rest] = exp.split(/e/i);
  if (!mant || rest === undefined) return exp;
  const cleaned = mant.replace(/(\.\d*?)0+$/, "$1").replace(/\.$/, "");
  const sign = rest.startsWith("-") || rest.startsWith("+") ? rest[0] : "+";
  const digits = rest.replace(/^[+-]/, "").replace(/^0+/, "") || "0";
  return `${cleaned}e${sign}${digits}`;
}

function groupInt(raw: string): string {
  const neg = raw.startsWith("-");
  const body = neg ? raw.slice(1) : raw;
  const [intPart, frac] = body.split(".");
  const grouped = GROUP.format(Number(intPart));
  const out = frac !== undefined ? `${grouped}.${frac}` : grouped;
  return neg ? `−${out}` : out;
}

export function stripGrouping(display: string): string {
  return display.replace(/,/g, "").replace(/−/g, "-");
}

export function parseDisplay(display: string): Decimal {
  const raw = stripGrouping(display).trim();
  if (!raw || raw === "-" || raw === "." || raw === "-.") return D(0);
  return D(raw);
}

export function formatLive(entry: string): string {
  if (!entry) return "0";
  if (entry.includes("e") || entry.includes("E")) {
    const [mant, rest] = entry.split(/e/i);
    const sign = (rest ?? "").startsWith("-") ? "−" : "";
    const ed = (rest ?? "").replace(/^[+-]/, "") || "0";
    return `${formatLive(mant ?? "0")}e${sign || "+"}${ed}`;
  }
  const neg = entry.startsWith("-");
  const body = neg ? entry.slice(1) : entry;
  const [intPart, frac] = body.split(".");
  const grouped = (intPart || "0").replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  const out = frac !== undefined ? `${grouped}.${frac}` : grouped;
  return neg ? `−${out}` : out;
}

export function formatBase(value: bigint, base: 2 | 8 | 10 | 16, wordSize: number): string {
  const mask = (1n << BigInt(wordSize)) - 1n;
  const unsigned = value & mask;
  if (base === 10) {
    const signBit = 1n << BigInt(wordSize - 1);
    const signed = unsigned & signBit ? unsigned - (1n << BigInt(wordSize)) : unsigned;
    return signed.toString(10);
  }
  const digits = unsigned.toString(base).toUpperCase();
  if (base === 2) return groupBits(digits.padStart(wordSize, "0"), 4);
  if (base === 16) {
    const width = Math.ceil(wordSize / 4);
    return groupBits(digits.padStart(width, "0"), 4);
  }
  return digits;
}

function groupBits(s: string, n: number): string {
  const parts: string[] = [];
  for (let i = s.length; i > 0; i -= n) {
    parts.unshift(s.slice(Math.max(0, i - n), i));
  }
  return parts.join(" ");
}
