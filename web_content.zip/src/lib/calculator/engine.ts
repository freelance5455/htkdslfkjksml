import { D, type Decimal } from "./decimal";
import { evaluateTokens, lastBinaryOp, lastNumberInTokens, parenDepth, tokensToExpr } from "./eval";
import { formatDecimal, formatLive, parseDisplay, stripGrouping } from "./format";
import { applyPercent, applyUnary, constantValue } from "./functions";
import {
  CalcError,
  ERROR_LABEL,
  MAX_HISTORY,
  type AngleMode,
  type BinaryOp,
  type ConstantName,
  type HistoryItem,
  type Token,
  type UnaryFn,
} from "./types";

export type EngineState = {
  tokens: Token[];
  entry: string;
  entering: boolean;
  overwrite: boolean;
  ee: boolean;
  display: string;
  expression: string;
  error: string | null;
  memory: string;
  history: HistoryItem[];
  angle: AngleMode;
  second: boolean;
  hyp: boolean;
  lastOp: { op: BinaryOp; operand: string } | null;
};

export const initialEngine = (): EngineState => ({
  tokens: [],
  entry: "0",
  entering: false,
  overwrite: true,
  ee: false,
  display: "0",
  expression: "",
  error: null,
  memory: "0",
  history: [],
  angle: "deg",
  second: false,
  hyp: false,
  lastOp: null,
});

export type EngineAction =
  | { type: "digit"; digit: string }
  | { type: "dot" }
  | { type: "ee" }
  | { type: "op"; op: BinaryOp }
  | { type: "unary"; fn: UnaryFn }
  | { type: "const"; name: ConstantName }
  | { type: "equals" }
  | { type: "clear" }
  | { type: "allClear" }
  | { type: "backspace" }
  | { type: "sign" }
  | { type: "percent" }
  | { type: "lparen" }
  | { type: "rparen" }
  | { type: "memoryClear" }
  | { type: "memoryRecall" }
  | { type: "memoryAdd" }
  | { type: "memorySub" }
  | { type: "memoryStore" }
  | { type: "toggleSecond" }
  | { type: "toggleHyp" }
  | { type: "cycleAngle" }
  | { type: "setAngle"; angle: AngleMode }
  | { type: "load"; value: string; expr?: string }
  | { type: "clearHistory" }
  | { type: "clearError" };

export function reduce(state: EngineState, action: EngineAction, leftToRight: boolean): EngineState {
  try {
    switch (action.type) {
      case "digit":
        return inputDigit(clearErr(state), action.digit);
      case "dot":
        return inputDot(clearErr(state));
      case "ee":
        return inputEE(clearErr(state));
      case "op":
        return inputOp(clearErr(state), action.op, leftToRight);
      case "unary":
        return inputUnary(clearErr(state), action.fn);
      case "const":
        return inputConst(clearErr(state), action.name);
      case "equals":
        return inputEquals(clearErr(state), leftToRight);
      case "clear":
        return inputClear(state);
      case "allClear":
        return { ...initialEngine(), memory: state.memory, history: state.history, angle: state.angle };
      case "backspace":
        return inputBackspace(clearErr(state));
      case "sign":
        return inputSign(clearErr(state));
      case "percent":
        return inputPercent(clearErr(state));
      case "lparen":
        return inputLParen(clearErr(state));
      case "rparen":
        return inputRParen(clearErr(state), leftToRight);
      case "memoryClear":
        return { ...state, memory: "0" };
      case "memoryRecall":
        return setEntry(clearErr(state), state.memory, true);
      case "memoryAdd":
        return { ...state, memory: D(state.memory).plus(currentValue(state)).toString() };
      case "memorySub":
        return { ...state, memory: D(state.memory).minus(currentValue(state)).toString() };
      case "memoryStore":
        return { ...state, memory: currentValue(state).toString() };
      case "toggleSecond":
        return { ...state, second: !state.second };
      case "toggleHyp":
        return { ...state, hyp: !state.hyp };
      case "cycleAngle": {
        const next: AngleMode = state.angle === "deg" ? "rad" : state.angle === "rad" ? "grad" : "deg";
        return { ...state, angle: next, second: false };
      }
      case "setAngle":
        return { ...state, angle: action.angle };
      case "load":
        return setEntry(
          { ...clearErr(state), tokens: [], expression: action.expr ?? "", lastOp: null },
          action.value,
          true,
        );
      case "clearHistory":
        return { ...state, history: [] };
      case "clearError":
        return clearErr(state);
      default:
        return state;
    }
  } catch (err) {
    return fail(state, err);
  }
}

function clearErr(state: EngineState): EngineState {
  if (!state.error) return state;
  return { ...state, error: null };
}

function fail(state: EngineState, err: unknown): EngineState {
  const message =
    err instanceof CalcError ? ERROR_LABEL[err.code] : err instanceof Error ? err.message : "Error";
  return { ...state, error: message, display: "Error", overwrite: true, entering: false };
}

function currentValue(state: EngineState): Decimal {
  return parseDisplay(state.entry);
}

function paint(state: EngineState, extra: Partial<EngineState> = {}): EngineState {
  const next = { ...state, ...extra };
  if (extra.expression === undefined) {
    next.expression = next.tokens.length > 0 ? tokensToExpr(next.tokens) : next.expression;
  }
  if (!next.error) {
    try {
      next.display =
        next.entering && !next.overwrite
          ? formatLive(next.entry)
          : formatDecimal(D(stripGrouping(next.entry)));
    } catch {
      next.display = next.entry;
    }
  }
  return next;
}

function setEntry(state: EngineState, value: string, overwrite: boolean): EngineState {
  const dec = D(value);
  const entry = dec.toString();
  return paint(state, {
    entry,
    display: formatDecimal(dec),
    overwrite,
    entering: !overwrite,
    ee: false,
    error: null,
  });
}

function inputDigit(state: EngineState, digit: string): EngineState {
  if (state.overwrite || !state.entering) {
    return paint(state, {
      entry: digit,
      entering: true,
      overwrite: false,
      ee: false,
      expression: state.tokens.length ? undefined : "",
    });
  }
  if (state.ee) {
    const [mant, exp = ""] = splitEE(state.entry);
    const sign = exp.startsWith("-") ? "-" : exp.startsWith("+") ? "+" : "";
    const body = exp.replace(/^[+-]/, "");
    const nextExp = (body === "0" ? "" : body) + digit;
    if (nextExp.length > 6) return state;
    return paint(state, { entry: `${mant}e${sign}${nextExp || "0"}` });
  }
  const raw = stripGrouping(state.entry);
  if (raw.replace("-", "").replace(".", "").length >= 18) return state;
  if (raw === "0") return paint(state, { entry: digit });
  if (raw === "-0") return paint(state, { entry: `-${digit}` });
  return paint(state, { entry: raw + digit });
}

function inputDot(state: EngineState): EngineState {
  if (state.ee) return state;
  if (state.overwrite || !state.entering) {
    return paint(state, { entry: "0.", entering: true, overwrite: false });
  }
  const raw = stripGrouping(state.entry);
  if (raw.includes(".")) return state;
  return paint(state, { entry: raw + "." });
}

function inputEE(state: EngineState): EngineState {
  if (state.overwrite || !state.entering) {
    return paint(state, { entry: "1e0", entering: true, overwrite: false, ee: true });
  }
  if (state.entry.includes("e") || state.entry.includes("E")) {
    return paint(state, { ee: true });
  }
  return paint(state, { entry: `${stripGrouping(state.entry)}e0`, ee: true });
}

function splitEE(entry: string): [string, string] {
  const idx = entry.toLowerCase().lastIndexOf("e");
  if (idx < 0) return [entry, ""];
  return [entry.slice(0, idx), entry.slice(idx + 1)];
}

function commitEntry(state: EngineState): EngineState {
  const last = state.tokens[state.tokens.length - 1];
  if (last?.t === "n" && !state.entering && state.overwrite) {
    return state;
  }
  if (last?.t === "rp") return state;
  const value = currentValue(state).toString();
  return {
    ...state,
    tokens: [...state.tokens, { t: "n", v: value }],
    entering: false,
    overwrite: true,
    ee: false,
  };
}

function inputOp(state: EngineState, op: BinaryOp, _ltr: boolean): EngineState {
  let next = state;
  const last = next.tokens[next.tokens.length - 1];
  if (last?.t === "b" && (next.overwrite || !next.entering)) {
    const tokens = [...next.tokens];
    tokens[tokens.length - 1] = { t: "b", v: op };
    return paint({ ...next, tokens, lastOp: { op, operand: next.entry } });
  }
  if (!(last?.t === "rp" && (next.overwrite || !next.entering))) {
    next = commitEntry(next);
  }
  return paint({
    ...next,
    tokens: [...next.tokens, { t: "b", v: op }],
    overwrite: true,
    entering: false,
    lastOp: { op, operand: next.entry },
  });
}

function inputUnary(state: EngineState, fn: UnaryFn): EngineState {
  const mapped = mapHyp(fn, state.hyp);
  const result = applyUnary(mapped, currentValue(state), state.angle);
  return setEntry(
    { ...state, hyp: false, second: false },
    result.toString(),
    true,
  );
}

function mapHyp(fn: UnaryFn, hyp: boolean): UnaryFn {
  if (!hyp) return fn;
  const map: Partial<Record<UnaryFn, UnaryFn>> = {
    sin: "sinh",
    cos: "cosh",
    tan: "tanh",
    asin: "asinh",
    acos: "acosh",
    atan: "atanh",
    sec: "sech",
    csc: "csch",
    cot: "coth",
  };
  return map[fn] ?? fn;
}

function inputConst(state: EngineState, name: ConstantName): EngineState {
  const v = constantValue(name);
  return setEntry({ ...state, second: false }, v.toString(), true);
}

function inputEquals(state: EngineState, leftToRight: boolean): EngineState {
  if (state.lastOp && state.tokens.length === 0 && state.overwrite && !state.entering) {
    const result = evaluateTokens(
      [
        { t: "n", v: currentValue(state).toString() },
        { t: "b", v: state.lastOp.op },
        { t: "n", v: state.lastOp.operand },
      ],
      leftToRight,
    );
    return finish(state, result, `${formatDecimal(currentValue(state))} ${opLabel(state.lastOp.op)} ${formatDecimal(D(state.lastOp.operand))}`);
  }

  let tokens = state.tokens;
  const last = tokens[tokens.length - 1];
  if (!last || last.t === "b" || last.t === "lp") {
    tokens = [...tokens, { t: "n", v: currentValue(state).toString() }];
  } else if (state.entering) {
    tokens = [...tokens, { t: "n", v: currentValue(state).toString() }];
  }

  while (parenDepth(tokens) > 0) tokens = [...tokens, { t: "rp" }];

  if (tokens.length === 0) {
    return paint(state, { overwrite: true, entering: false });
  }

  const expr = tokensToExpr(tokens);
  const result = evaluateTokens(tokens, leftToRight);
  const operand = lastNumberInTokens(tokens);
  const op = lastBinaryOp(tokens);
  return finish(
    state,
    result,
    expr,
    op && operand ? { op, operand: operand.toString() } : state.lastOp,
  );
}

function opLabel(op: BinaryOp): string {
  const map: Record<BinaryOp, string> = {
    add: "+",
    sub: "−",
    mul: "×",
    div: "÷",
    pow: "^",
    root: "ʸ√",
    mod: "mod",
    nCr: "nCr",
    nPr: "nPr",
    logy: "log",
    gcd: "gcd",
    lcm: "lcm",
  };
  return map[op];
}

function finish(
  state: EngineState,
  result: Decimal,
  expr: string,
  lastOp: EngineState["lastOp"] = state.lastOp,
): EngineState {
  const formatted = formatDecimal(result);
  const item: HistoryItem = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    expression: expr,
    result: formatted,
    at: Date.now(),
  };
  return paint(state, {
    tokens: [],
    entry: result.toString(),
    display: formatted,
    expression: expr,
    overwrite: true,
    entering: false,
    ee: false,
    error: null,
    lastOp,
    history: [item, ...state.history].slice(0, MAX_HISTORY),
  });
}

function inputClear(state: EngineState): EngineState {
  if (state.error) {
    return paint({ ...state, error: null, entry: "0", overwrite: true, entering: false, ee: false });
  }
  if (state.entering && state.entry !== "0") {
    return paint(state, { entry: "0", entering: false, overwrite: true, ee: false });
  }
  return {
    ...initialEngine(),
    memory: state.memory,
    history: state.history,
    angle: state.angle,
  };
}

function inputBackspace(state: EngineState): EngineState {
  if (state.overwrite || !state.entering) return state;
  const raw = stripGrouping(state.entry);
  if (state.ee) {
    const [mant, exp = ""] = splitEE(raw);
    const sign = exp.startsWith("-") ? "-" : "";
    const body = exp.replace(/^[+-]/, "");
    if (body.length <= 1) {
      return paint(state, { entry: mant, ee: false });
    }
    return paint(state, { entry: `${mant}e${sign}${body.slice(0, -1)}` });
  }
  const next = raw.slice(0, -1);
  if (!next || next === "-" || next === "-0") {
    return paint(state, { entry: "0", entering: false, overwrite: true });
  }
  return paint(state, { entry: next });
}

function inputSign(state: EngineState): EngineState {
  if (state.ee) {
    const [mant, exp = "0"] = splitEE(stripGrouping(state.entry));
    const body = exp.replace(/^[+-]/, "") || "0";
    const nextSign = exp.startsWith("-") ? "+" : "-";
    return paint(state, { entry: `${mant}e${nextSign}${body}` });
  }
  const raw = stripGrouping(state.entry);
  if (raw.startsWith("-")) return paint(state, { entry: raw.slice(1) || "0" });
  if (raw === "0") return paint(state, { entry: "-0", entering: true, overwrite: false });
  return paint(state, { entry: `-${raw}`, entering: true, overwrite: false });
}

function inputPercent(state: EngineState): EngineState {
  const left = lastNumberInTokens(state.tokens);
  const op = lastBinaryOp(state.tokens);
  const result = applyPercent(currentValue(state), left, op);
  return setEntry(state, result.toString(), true);
}

function inputLParen(state: EngineState): EngineState {
  const last = state.tokens[state.tokens.length - 1];
  let tokens = state.tokens;
  if (last?.t === "n" || last?.t === "rp") {
    tokens = [...tokens, { t: "b", v: "mul" }];
  }
  if (state.entering && !state.overwrite) {
    tokens = [...tokens, { t: "n", v: currentValue(state).toString() }, { t: "b", v: "mul" }];
  }
  return paint({
    ...state,
    tokens: [...tokens, { t: "lp" }],
    entry: "0",
    overwrite: true,
    entering: false,
    ee: false,
  });
}

function inputRParen(state: EngineState, _leftToRight: boolean): EngineState {
  if (parenDepth(state.tokens) <= 0) return state;
  let next = state;
  const last = next.tokens[next.tokens.length - 1];
  if (!last || last.t === "b" || last.t === "lp" || next.entering) {
    next = commitEntry(next);
  }
  return paint({
    ...next,
    tokens: [...next.tokens, { t: "rp" }],
    overwrite: true,
    entering: false,
  });
}

export function memoryActive(state: EngineState): boolean {
  try {
    return !D(state.memory).eq(0);
  } catch {
    return false;
  }
}

export function canClearEntry(state: EngineState): boolean {
  return Boolean(state.error || (state.entering && state.entry !== "0") || state.display !== "0");
}
