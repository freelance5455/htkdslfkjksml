import Decimal from "decimal.js";

Decimal.set({
  precision: 24,
  rounding: Decimal.ROUND_HALF_UP,
  toExpNeg: -12,
  toExpPos: 21,
  modulo: Decimal.ROUND_FLOOR,
});

export { Decimal };

export function D(value: string | number | Decimal): Decimal {
  if (value instanceof Decimal) return value;
  if (typeof value === "number") {
    if (!Number.isFinite(value)) {
      throw new Error("non-finite");
    }
    return new Decimal(value.toString());
  }
  return new Decimal(value);
}

export const PI = Decimal.acos(D(-1));
export const E = Decimal.exp(D(1));
export const PHI = D(1).plus(D(5).sqrt()).div(2);
export const TAU = PI.mul(2);
export const LN2 = Decimal.ln(D(2));
export const SQRT2 = D(2).sqrt();
export const SPEED_OF_LIGHT = D("299792458");
export const GRAVITY = D("9.80665");
export const PLANCK = D("6.62607015e-34");
export const AVOGADRO = D("6.02214076e23");
