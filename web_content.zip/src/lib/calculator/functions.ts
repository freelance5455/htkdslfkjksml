import { CalcError, type AngleMode, type ConstantName, type UnaryFn } from "./types";
import {
  AVOGADRO,
  D,
  Decimal,
  E,
  GRAVITY,
  LN2,
  PHI,
  PI,
  PLANCK,
  SPEED_OF_LIGHT,
  SQRT2,
  TAU,
} from "./decimal";

function tidy(x: Decimal): Decimal {
  if (!x.isFinite()) throw new CalcError("overflow", "Overflow");
  const nearest = x.toDecimalPlaces(0, Decimal.ROUND_HALF_UP);
  if (x.minus(nearest).abs().lt("1e-14")) return nearest;
  return x;
}

export function toRadians(x: Decimal, angle: AngleMode): Decimal {
  if (angle === "deg") return x.mul(PI).div(180);
  if (angle === "grad") return x.mul(PI).div(200);
  return x;
}

export function fromRadians(x: Decimal, angle: AngleMode): Decimal {
  if (angle === "deg") return x.mul(180).div(PI);
  if (angle === "grad") return x.mul(200).div(PI);
  return x;
}

function requireDomain(ok: boolean, message = "Invalid input") {
  if (!ok) throw new CalcError("domain", message);
}

export function applyUnary(fn: UnaryFn, x: Decimal, angle: AngleMode): Decimal {
  switch (fn) {
    case "sin":
      return tidy(Decimal.sin(toRadians(x, angle)));
    case "cos":
      return tidy(Decimal.cos(toRadians(x, angle)));
    case "tan": {
      const c = tidy(Decimal.cos(toRadians(x, angle)));
      requireDomain(!c.eq(0), "Undefined");
      return tidy(Decimal.sin(toRadians(x, angle)).div(c));
    }
    case "asin":
      requireDomain(x.abs().lte(1));
      return tidy(fromRadians(Decimal.asin(x), angle));
    case "acos":
      requireDomain(x.abs().lte(1));
      return tidy(fromRadians(Decimal.acos(x), angle));
    case "atan":
      return tidy(fromRadians(Decimal.atan(x), angle));
    case "sinh":
      return Decimal.sinh(x);
    case "cosh":
      return Decimal.cosh(x);
    case "tanh":
      return Decimal.tanh(x);
    case "asinh":
      return Decimal.asinh(x);
    case "acosh":
      requireDomain(x.gte(1));
      return Decimal.acosh(x);
    case "atanh":
      requireDomain(x.abs().lt(1));
      return Decimal.atanh(x);
    case "sec": {
      const c = tidy(Decimal.cos(toRadians(x, angle)));
      requireDomain(!c.eq(0), "Undefined");
      return D(1).div(c);
    }
    case "csc": {
      const s = tidy(Decimal.sin(toRadians(x, angle)));
      requireDomain(!s.eq(0), "Undefined");
      return D(1).div(s);
    }
    case "cot": {
      const s = tidy(Decimal.sin(toRadians(x, angle)));
      requireDomain(!s.eq(0), "Undefined");
      return tidy(Decimal.cos(toRadians(x, angle))).div(s);
    }
    case "asec":
      requireDomain(x.abs().gte(1));
      return tidy(fromRadians(Decimal.acos(D(1).div(x)), angle));
    case "acsc":
      requireDomain(x.abs().gte(1));
      return tidy(fromRadians(Decimal.asin(D(1).div(x)), angle));
    case "acot":
      if (x.eq(0)) return tidy(fromRadians(PI.div(2), angle));
      return tidy(fromRadians(Decimal.atan(D(1).div(x)), angle));
    case "sech": {
      const c = Decimal.cosh(x);
      requireDomain(!c.eq(0));
      return D(1).div(c);
    }
    case "csch": {
      const s = Decimal.sinh(x);
      requireDomain(!s.eq(0));
      return D(1).div(s);
    }
    case "coth": {
      const s = Decimal.sinh(x);
      requireDomain(!s.eq(0));
      return Decimal.cosh(x).div(s);
    }
    case "ln":
      requireDomain(x.gt(0));
      return Decimal.ln(x);
    case "log":
      requireDomain(x.gt(0));
      return Decimal.log(x, 10);
    case "log2":
      requireDomain(x.gt(0));
      return Decimal.log(x, 2);
    case "exp":
      return Decimal.exp(x);
    case "exp10":
      return D(10).pow(x);
    case "exp2":
      return D(2).pow(x);
    case "sqrt":
      requireDomain(x.gte(0));
      return x.sqrt();
    case "cbrt":
      return cubeRoot(x);
    case "sq":
      return x.mul(x);
    case "cube":
      return x.mul(x).mul(x);
    case "inv":
      requireDomain(!x.eq(0), "Cannot divide by zero");
      return D(1).div(x);
    case "abs":
      return x.abs();
    case "floor":
      return x.floor();
    case "ceil":
      return x.ceil();
    case "round":
      return x.toDecimalPlaces(0, Decimal.ROUND_HALF_UP);
    case "frac":
      return x.minus(x.trunc());
    case "fact":
      return factorial(x);
    case "sign":
      return D(x.cmp(0));
    case "rand":
      return D(Math.random().toString());
    case "toDeg":
      return fromRadians(toRadians(x, angle), "deg");
    case "toRad":
      return toRadians(x, angle);
    case "toGrad":
      return fromRadians(toRadians(x, angle), "grad");
    case "percent":
      return x.div(100);
    case "neg":
      return x.neg();
    default:
      throw new CalcError("domain", "Unknown function");
  }
}

function cubeRoot(x: Decimal): Decimal {
  if (x.eq(0)) return D(0);
  const sign = x.isNeg() ? -1 : 1;
  return D(sign).mul(x.abs().pow(D(1).div(3)));
}

export function factorial(n: Decimal): Decimal {
  if (!n.isInteger()) throw new CalcError("domain", "Integer required");
  if (n.isNeg()) throw new CalcError("domain", "Invalid input");
  if (n.gt(1000)) throw new CalcError("overflow", "Overflow");
  let r = D(1);
  const top = n.toNumber();
  for (let i = 2; i <= top; i++) r = r.mul(i);
  return r;
}

export function nCr(n: Decimal, r: Decimal): Decimal {
  if (!n.isInteger() || !r.isInteger()) throw new CalcError("domain", "Integer required");
  if (n.isNeg() || r.isNeg() || r.gt(n)) throw new CalcError("domain", "Invalid input");
  if (r.gt(n.minus(r))) r = n.minus(r);
  let result = D(1);
  const rk = r.toNumber();
  for (let i = 1; i <= rk; i++) {
    result = result.mul(n.minus(i).plus(1)).div(i);
  }
  return result;
}

export function nPr(n: Decimal, r: Decimal): Decimal {
  if (!n.isInteger() || !r.isInteger()) throw new CalcError("domain", "Integer required");
  if (n.isNeg() || r.isNeg() || r.gt(n)) throw new CalcError("domain", "Invalid input");
  let result = D(1);
  const rk = r.toNumber();
  for (let i = 0; i < rk; i++) {
    result = result.mul(n.minus(i));
  }
  return result;
}

export function gcdDec(a: Decimal, b: Decimal): Decimal {
  if (!a.isInteger() || !b.isInteger()) throw new CalcError("domain", "Integer required");
  let x = a.abs();
  let y = b.abs();
  while (!y.eq(0)) {
    const t = y;
    y = x.mod(y);
    x = t;
  }
  return x;
}

export function lcmDec(a: Decimal, b: Decimal): Decimal {
  if (a.eq(0) || b.eq(0)) return D(0);
  return a.abs().mul(b.abs()).div(gcdDec(a, b));
}

export function applyBinary(op: string, a: Decimal, b: Decimal): Decimal {
  switch (op) {
    case "add":
      return a.plus(b);
    case "sub":
      return a.minus(b);
    case "mul":
      return a.mul(b);
    case "div":
      if (b.eq(0)) throw new CalcError("div0", "Cannot divide by zero");
      return a.div(b);
    case "pow":
      if (a.eq(0) && b.lte(0)) throw new CalcError("domain", "Invalid input");
      if (a.isNeg() && !b.isInteger()) throw new CalcError("domain", "Invalid input");
      return a.pow(b);
    case "root": {
      if (b.eq(0)) throw new CalcError("div0", "Cannot divide by zero");
      const inv = D(1).div(b);
      if (a.isNeg() && !inv.isInteger()) throw new CalcError("domain", "Invalid input");
      if (a.isNeg()) return applyUnary("neg", a.abs().pow(inv), "rad");
      return a.pow(inv);
    }
    case "mod":
      if (b.eq(0)) throw new CalcError("div0", "Cannot divide by zero");
      return a.mod(b);
    case "nCr":
      return nCr(a, b);
    case "nPr":
      return nPr(a, b);
    case "logy":
      if (a.lte(0) || a.eq(1) || b.lte(0)) throw new CalcError("domain", "Invalid input");
      return Decimal.log(b, a);
    case "gcd":
      return gcdDec(a, b);
    case "lcm":
      return lcmDec(a, b);
    default:
      throw new CalcError("syntax", "Unknown operator");
  }
}

export function constantValue(name: ConstantName): Decimal {
  switch (name) {
    case "pi":
      return PI;
    case "e":
      return E;
    case "phi":
      return PHI;
    case "tau":
      return TAU;
    case "sqrt2":
      return SQRT2;
    case "ln2":
      return LN2;
    case "c":
      return SPEED_OF_LIGHT;
    case "g":
      return GRAVITY;
    case "h":
      return PLANCK;
    case "NA":
      return AVOGADRO;
  }
}

export function applyPercent(x: Decimal, pendingLeft: Decimal | null, op: string | null): Decimal {
  if (pendingLeft && (op === "add" || op === "sub")) {
    return pendingLeft.mul(x).div(100);
  }
  return x.div(100);
}
