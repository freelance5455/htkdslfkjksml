export type Mode = "basic" | "scientific" | "programmer" | "converter";
export type Theme = "amoled" | "paper";
export type AngleMode = "deg" | "rad" | "grad";
export type NumberBase = 2 | 8 | 10 | 16;
export type WordSize = 8 | 16 | 32 | 64;

export type BinaryOp =
  | "add"
  | "sub"
  | "mul"
  | "div"
  | "pow"
  | "root"
  | "mod"
  | "nCr"
  | "nPr"
  | "logy"
  | "gcd"
  | "lcm";

export type UnaryFn =
  | "sin"
  | "cos"
  | "tan"
  | "asin"
  | "acos"
  | "atan"
  | "sinh"
  | "cosh"
  | "tanh"
  | "asinh"
  | "acosh"
  | "atanh"
  | "sec"
  | "csc"
  | "cot"
  | "asec"
  | "acsc"
  | "acot"
  | "sech"
  | "csch"
  | "coth"
  | "ln"
  | "log"
  | "log2"
  | "exp"
  | "exp10"
  | "exp2"
  | "sqrt"
  | "cbrt"
  | "sq"
  | "cube"
  | "inv"
  | "abs"
  | "floor"
  | "ceil"
  | "round"
  | "frac"
  | "fact"
  | "sign"
  | "rand"
  | "toDeg"
  | "toRad"
  | "toGrad"
  | "percent"
  | "neg";

export type ConstantName =
  | "pi"
  | "e"
  | "phi"
  | "tau"
  | "sqrt2"
  | "ln2"
  | "c"
  | "g"
  | "h"
  | "NA";

export type BitOp =
  | "and"
  | "or"
  | "xor"
  | "nand"
  | "nor"
  | "xnor"
  | "lsh"
  | "rsh"
  | "rol"
  | "ror";

export type Token =
  | { t: "n"; v: string }
  | { t: "b"; v: BinaryOp }
  | { t: "lp" }
  | { t: "rp" };

export type HistoryItem = {
  id: string;
  expression: string;
  result: string;
  at: number;
};

export type CalcErrorCode = "div0" | "domain" | "overflow" | "syntax" | "bit";

export class CalcError extends Error {
  code: CalcErrorCode;
  constructor(code: CalcErrorCode, message: string) {
    super(message);
    this.code = code;
    this.name = "CalcError";
  }
}

export const ERROR_LABEL: Record<CalcErrorCode, string> = {
  div0: "Cannot divide by zero",
  domain: "Invalid input",
  overflow: "Overflow",
  syntax: "Syntax error",
  bit: "Invalid for this base",
};

export const OP_SYMBOL: Record<BinaryOp, string> = {
  add: "+",
  sub: "−",
  mul: "×",
  div: "÷",
  pow: "^",
  root: "√",
  mod: "mod",
  nCr: "nCr",
  nPr: "nPr",
  logy: "log",
  gcd: "gcd",
  lcm: "lcm",
};

export const MAX_HISTORY = 50;
export const DISPLAY_DIGITS = 12;
