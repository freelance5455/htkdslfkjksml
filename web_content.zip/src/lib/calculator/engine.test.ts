import assert from "node:assert/strict";
import { test } from "node:test";
import { initialEngine, reduce, type EngineAction } from "./engine.ts";
import { formatDecimal, stripGrouping } from "./format.ts";
import { D } from "./decimal.ts";
import { applyUnary } from "./functions.ts";

function run(actions: EngineAction[], ltr = true) {
  let s = initialEngine();
  for (const a of actions) s = reduce(s, a, ltr);
  return s;
}

function val(s: ReturnType<typeof initialEngine>) {
  return stripGrouping(s.display);
}

test("0.1 + 0.2 = 0.3", () => {
  const s = run([
    { type: "digit", digit: "0" },
    { type: "dot" },
    { type: "digit", digit: "1" },
    { type: "op", op: "add" },
    { type: "digit", digit: "0" },
    { type: "dot" },
    { type: "digit", digit: "2" },
    { type: "equals" },
  ]);
  assert.equal(val(s), "0.3");
});

test("basic left-to-right 2 + 3 × 4 = 20", () => {
  const s = run(
    [
      { type: "digit", digit: "2" },
      { type: "op", op: "add" },
      { type: "digit", digit: "3" },
      { type: "op", op: "mul" },
      { type: "digit", digit: "4" },
      { type: "equals" },
    ],
    true,
  );
  assert.equal(val(s), "20");
});

test("scientific precedence 2 + 3 × 4 = 14", () => {
  const s = run(
    [
      { type: "digit", digit: "2" },
      { type: "op", op: "add" },
      { type: "digit", digit: "3" },
      { type: "op", op: "mul" },
      { type: "digit", digit: "4" },
      { type: "equals" },
    ],
    false,
  );
  assert.equal(val(s), "14");
});

test("sin 30 deg = 0.5", () => {
  const r = applyUnary("sin", D("30"), "deg");
  assert.equal(formatDecimal(r), "0.5");
});

test("repeat equals", () => {
  const s = run([
    { type: "digit", digit: "5" },
    { type: "op", op: "add" },
    { type: "digit", digit: "3" },
    { type: "equals" },
    { type: "equals" },
  ]);
  assert.equal(val(s), "11");
});

test("divide by zero", () => {
  const s = run([
    { type: "digit", digit: "1" },
    { type: "op", op: "div" },
    { type: "digit", digit: "0" },
    { type: "equals" },
  ]);
  assert.equal(s.display, "Error");
  assert.equal(s.error, "Cannot divide by zero");
});

test("factorial 5", () => {
  const s = run([
    { type: "digit", digit: "5" },
    { type: "unary", fn: "fact" },
  ]);
  assert.equal(val(s), "120");
});

test("percent of add", () => {
  const s = run([
    { type: "digit", digit: "5" },
    { type: "digit", digit: "0" },
    { type: "op", op: "add" },
    { type: "digit", digit: "1" },
    { type: "digit", digit: "0" },
    { type: "percent" },
    { type: "equals" },
  ]);
  assert.equal(val(s), "55");
});
