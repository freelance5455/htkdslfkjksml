import { applyBinary } from "./functions";
import { D, type Decimal } from "./decimal";
import { CalcError, type BinaryOp, type Token } from "./types";

const PREC: Record<BinaryOp, number> = {
  add: 1,
  sub: 1,
  mul: 2,
  div: 2,
  mod: 2,
  gcd: 2,
  lcm: 2,
  pow: 3,
  root: 3,
  nCr: 3,
  nPr: 3,
  logy: 3,
};

const RIGHT_ASSOC = new Set<BinaryOp>(["pow", "root"]);

export function evaluateTokens(tokens: Token[], leftToRight: boolean): Decimal {
  if (tokens.length === 0) return D(0);
  const rpn = leftToRight ? toRpnLeft(tokens) : toRpn(tokens);
  return evalRpn(rpn);
}

function toRpn(tokens: Token[]): Token[] {
  const out: Token[] = [];
  const ops: Token[] = [];
  for (const tok of tokens) {
    if (tok.t === "n") out.push(tok);
    else if (tok.t === "b") {
      while (ops.length) {
        const top = ops[ops.length - 1];
        if (!top || top.t !== "b") break;
        const pTop = PREC[top.v];
        const pCur = PREC[tok.v];
        const right = RIGHT_ASSOC.has(tok.v);
        if (pTop > pCur || (pTop === pCur && !right)) {
          out.push(ops.pop()!);
        } else break;
      }
      ops.push(tok);
    } else if (tok.t === "lp") ops.push(tok);
    else if (tok.t === "rp") {
      let found = false;
      while (ops.length) {
        const top = ops.pop()!;
        if (top.t === "lp") {
          found = true;
          break;
        }
        out.push(top);
      }
      if (!found) throw new CalcError("syntax", "Mismatched parentheses");
    }
  }
  while (ops.length) {
    const top = ops.pop()!;
    if (top.t === "lp" || top.t === "rp") throw new CalcError("syntax", "Mismatched parentheses");
    out.push(top);
  }
  return out;
}

function toRpnLeft(tokens: Token[]): Token[] {
  const out: Token[] = [];
  const ops: Token[] = [];
  for (const tok of tokens) {
    if (tok.t === "n") out.push(tok);
    else if (tok.t === "b") {
      while (ops.length && ops[ops.length - 1]?.t === "b") {
        out.push(ops.pop()!);
      }
      ops.push(tok);
    } else if (tok.t === "lp") ops.push(tok);
    else if (tok.t === "rp") {
      let found = false;
      while (ops.length) {
        const top = ops.pop()!;
        if (top.t === "lp") {
          found = true;
          break;
        }
        out.push(top);
      }
      if (!found) throw new CalcError("syntax", "Mismatched parentheses");
    }
  }
  while (ops.length) {
    const top = ops.pop()!;
    if (top.t === "lp" || top.t === "rp") throw new CalcError("syntax", "Mismatched parentheses");
    out.push(top);
  }
  return out;
}

function evalRpn(rpn: Token[]): Decimal {
  const stack: Decimal[] = [];
  for (const tok of rpn) {
    if (tok.t === "n") stack.push(D(tok.v));
    else if (tok.t === "b") {
      const b = stack.pop();
      const a = stack.pop();
      if (a === undefined || b === undefined) throw new CalcError("syntax", "Syntax error");
      stack.push(applyBinary(tok.v, a, b));
    }
  }
  if (stack.length !== 1 || !stack[0]) throw new CalcError("syntax", "Syntax error");
  return stack[0];
}

export function lastNumberInTokens(tokens: Token[]): Decimal | null {
  for (let i = tokens.length - 1; i >= 0; i--) {
    const tok = tokens[i];
    if (tok?.t === "n") return D(tok.v);
  }
  return null;
}

export function lastBinaryOp(tokens: Token[]): BinaryOp | null {
  for (let i = tokens.length - 1; i >= 0; i--) {
    const tok = tokens[i];
    if (tok?.t === "b") return tok.v;
  }
  return null;
}

export function parenDepth(tokens: Token[]): number {
  let d = 0;
  for (const tok of tokens) {
    if (tok.t === "lp") d++;
    else if (tok.t === "rp") d--;
  }
  return d;
}

export function tokensToExpr(tokens: Token[]): string {
  const bits: string[] = [];
  for (const tok of tokens) {
    if (tok.t === "n") bits.push(tok.v);
    else if (tok.t === "b") bits.push(opSym(tok.v));
    else if (tok.t === "lp") bits.push("(");
    else bits.push(")");
  }
  return bits
    .join(" ")
    .replace(/\(\s+/g, "(")
    .replace(/\s+\)/g, ")")
    .replace(/\s+\^\s+/g, "^");
}

function opSym(op: BinaryOp): string {
  const map: Record<BinaryOp, string> = {
    add: "+",
    sub: "−",
    mul: "×",
    div: "÷",
    pow: "^",
    root: "ʸ√",
    mod: "mod",
    nCr: "C",
    nPr: "P",
    logy: "log",
    gcd: "gcd",
    lcm: "lcm",
  };
  return map[op];
}
