import { CalcError, type BitOp, type NumberBase, type WordSize } from "./types";

export function maskFor(wordSize: WordSize): bigint {
  return (1n << BigInt(wordSize)) - 1n;
}

export function wrapBits(value: bigint, wordSize: WordSize): bigint {
  return value & maskFor(wordSize);
}

export function toSigned(value: bigint, wordSize: WordSize): bigint {
  const masked = wrapBits(value, wordSize);
  const signBit = 1n << BigInt(wordSize - 1);
  if (masked & signBit) return masked - (1n << BigInt(wordSize));
  return masked;
}

export function applyBitOp(op: BitOp, a: bigint, b: bigint, wordSize: WordSize): bigint {
  const mask = maskFor(wordSize);
  const x = a & mask;
  const y = b & mask;
  const w = BigInt(wordSize);
  switch (op) {
    case "and":
      return x & y;
    case "or":
      return x | y;
    case "xor":
      return x ^ y;
    case "nand":
      return ~(x & y) & mask;
    case "nor":
      return ~(x | y) & mask;
    case "xnor":
      return ~(x ^ y) & mask;
    case "lsh": {
      const s = y < 0n ? 0n : y > w ? w : y;
      return (x << s) & mask;
    }
    case "rsh": {
      const s = y < 0n ? 0n : y > w ? w : y;
      return x >> s;
    }
    case "rol": {
      const s = ((y % w) + w) % w;
      return ((x << s) | (x >> (w - s))) & mask;
    }
    case "ror": {
      const s = ((y % w) + w) % w;
      return ((x >> s) | (x << (w - s))) & mask;
    }
  }
}

export function bitNot(value: bigint, wordSize: WordSize): bigint {
  return ~value & maskFor(wordSize);
}

const BASE_DIGITS: Record<NumberBase, string> = {
  2: "01",
  8: "01234567",
  10: "0123456789",
  16: "0123456789ABCDEF",
};

export function isDigitForBase(ch: string, base: NumberBase): boolean {
  return BASE_DIGITS[base].includes(ch.toUpperCase());
}

export function parseBase(entry: string, base: NumberBase): bigint {
  const raw = entry.replace(/\s+/g, "").replace(/−/g, "-");
  if (!raw || raw === "-" || raw === "+") return 0n;
  try {
    if (base === 10) return BigInt(raw);
    const neg = raw.startsWith("-");
    const body = (neg ? raw.slice(1) : raw).toUpperCase();
    if (!body) return 0n;
    const n = BigInt(basePrefix(base) + body);
    return neg ? -n : n;
  } catch {
    throw new CalcError("bit", "Invalid number");
  }
}

function basePrefix(base: NumberBase): string {
  if (base === 2) return "0b";
  if (base === 8) return "0o";
  if (base === 16) return "0x";
  return "";
}

export function formatProgEntry(value: bigint, base: NumberBase, wordSize: WordSize, signed: boolean): string {
  const masked = wrapBits(value, wordSize);
  if (base === 10) {
    const n = signed ? toSigned(masked, wordSize) : masked;
    return n.toString(10);
  }
  const digits = masked.toString(base).toUpperCase();
  if (base === 2) return group(digits.padStart(wordSize, "0"), 4);
  if (base === 16) return group(digits.padStart(Math.ceil(wordSize / 4), "0"), 4);
  return digits;
}

function group(s: string, n: number): string {
  const parts: string[] = [];
  for (let i = s.length; i > 0; i -= n) parts.unshift(s.slice(Math.max(0, i - n), i));
  return parts.join(" ");
}

export function toggleBit(value: bigint, index: number, wordSize: WordSize): bigint {
  if (index < 0 || index >= wordSize) return wrapBits(value, wordSize);
  return wrapBits(value ^ (1n << BigInt(index)), wordSize);
}

export type IntOp = "iadd" | "isub" | "imul" | "idiv";

export function applyIntOp(op: IntOp, a: bigint, b: bigint, wordSize: WordSize): bigint {
  let r: bigint;
  switch (op) {
    case "iadd":
      r = a + b;
      break;
    case "isub":
      r = a - b;
      break;
    case "imul":
      r = a * b;
      break;
    case "idiv":
      if (b === 0n) throw new CalcError("div0", "Cannot divide by zero");
      r = a / b;
      break;
  }
  return wrapBits(r, wordSize);
}
