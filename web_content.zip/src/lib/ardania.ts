export const MODEL = "grok-4.5";
export const MAX_TOKENS = 700;
export const MAX_MESSAGES = 12;
export const MAX_CHARS = 4000;

export type ChamberId = "rada" | "maisternia" | "arkhiv";
export type Role = "user" | "assistant";

export type ChatMessage = {
  role: Role;
  content: string;
};

export type StoredMessage = ChatMessage & {
  id: string;
  createdAt: number;
};

export type Thread = {
  id: string;
  title: string;
  chamber: ChamberId;
  messages: StoredMessage[];
  updatedAt: number;
};

export type Chamber = {
  id: ChamberId;
  name: string;
  line: string;
  prompts: string[];
};

const VOICE = `Ти — Ardania, власний сервіс мислення. Не представляйся як Grok і не згадуй xAI. Голос: точний, спокійний, без лестощів і канцеляриту. Відповідай мовою користувача. Спочатку суть, потім деталі. Короткі абзаци. Не вигадуй фактів і джерел. Якщо даних бракує — назви, чого бракує, і дай найкращу робочу версію.`;

export const CHAMBERS: Chamber[] = [
  {
    id: "rada",
    name: "Рада",
    line: "Рішення, компроміси, наступний крок.",
    prompts: [
      "Чи варто зараз міняти роботу, якщо офер на 20% вищий, але команда слабша?",
      "Обери між двома способами запуску і скажи, який ризик я недооцінюю.",
    ],
  },
  {
    id: "maisternia",
    name: "Майстерня",
    line: "Тексти, плани і чернетки, які можна взяти.",
    prompts: [
      "Напиши маніфест сервісу Ardania на 80 слів для головної сторінки.",
      "Склади план першого тижня запуску невеликого ШІ-сервісу.",
    ],
  },
  {
    id: "arkhiv",
    name: "Архів",
    line: "Стискає текст до суті, пунктів і питань.",
    prompts: [
      "Стисни цю нотатку: ми запускаємо власний сервіс, три палати, без акаунтів, пам'ять лише в браузері, модель grok-4.5.",
      "Витягни рішення, факти і відкриті питання з тексту, який я зараз вставлю.",
    ],
  },
];

const CHAMBER_BRIEF: Record<ChamberId, string> = {
  rada: "Палата: Рада. Допомагає ухвалити рішення. Структура: висновок одним реченням; два-чотири аргументи; головний ризик; один конкретний наступний крок.",
  maisternia:
    "Палата: Майстерня. Робить готову річ: текст, план, структуру або чернетку. Віддавай те, що можна використати. Мінімум метакоментарів.",
  arkhiv:
    "Палата: Архів. Стискає й упорядковує. Структура: суть у двох реченнях; ключові пункти; відкриті питання; що можна відкинути.",
};

export function systemPrompt(chamber: ChamberId): string {
  return `${VOICE}\n${CHAMBER_BRIEF[chamber]}`;
}

export function isChamber(value: unknown): value is ChamberId {
  return value === "rada" || value === "maisternia" || value === "arkhiv";
}

export function chamberById(id: ChamberId): Chamber {
  return CHAMBERS.find((item) => item.id === id) ?? CHAMBERS[0];
}

export function titleFrom(text: string): string {
  const clean = text.replace(/\s+/g, " ").trim();
  if (clean.length <= 48) return clean;
  return `${clean.slice(0, 47).trimEnd()}…`;
}
