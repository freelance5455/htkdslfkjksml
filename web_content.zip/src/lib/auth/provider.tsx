import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { type ReactNode, useState } from "react";
import { Toaster } from "sonner";

export function AuthProvider({ children }: { children: ReactNode }) {
  const [client] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: { staleTime: 30_000, retry: 0, refetchOnWindowFocus: false },
        },
      }),
  );
  return (
    <QueryClientProvider client={client}>
      <div className="min-h-dvh w-full">{children}</div>
      <Toaster
        theme="dark"
        position="top-center"
        toastOptions={{
          className: "bg-raised text-fg border-border",
        }}
      />
    </QueryClientProvider>
  );
}
