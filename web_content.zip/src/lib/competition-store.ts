"use client";

import type { Competition } from "./competition";

/**
 * Offline-first storage for competitions.
 *
 * Mirrors the match store: IndexedDB with a localStorage fallback, so a
 * league can be created and run with no internet. Competition records hold
 * only structure (teams, fixtures, settings) — never duplicated scoring data.
 */

import { COMPETITION_STORE, idbTx } from "./idb";

async function tx<T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>) {
  return idbTx(COMPETITION_STORE, mode, fn);
}

const LS_KEY = "match-cricket:competitions";

function lsAll(): Record<string, Competition> {
  if (typeof window === "undefined") return {};
  try {
    return JSON.parse(window.localStorage.getItem(LS_KEY) ?? "{}");
  } catch {
    return {};
  }
}

function lsWrite(c: Competition) {
  try {
    const all = lsAll();
    all[c.id] = c;
    window.localStorage.setItem(LS_KEY, JSON.stringify(all));
  } catch {
    /* quota or disabled storage */
  }
}

export async function saveCompetition(c: Competition): Promise<Competition> {
  const next = { ...c, updatedAt: Date.now(), rev: c.rev + 1 };
  lsWrite(next);
  try {
    await tx("readwrite", (s) => s.put(next));
  } catch {
    /* localStorage mirror still holds it */
  }
  return next;
}

export async function getCompetition(id: string): Promise<Competition | null> {
  try {
    const found = await tx<Competition | undefined>("readonly", (s) => s.get(id));
    if (found) return found;
  } catch {
    /* fall through */
  }
  return lsAll()[id] ?? null;
}

export async function listCompetitions(): Promise<Competition[]> {
  let rows: Competition[] = [];
  try {
    rows = (await tx<Competition[]>("readonly", (s) => s.getAll())) ?? [];
  } catch {
    rows = [];
  }
  if (rows.length === 0) rows = Object.values(lsAll());
  return rows.sort((a, b) => b.createdAt - a.createdAt);
}

export async function deleteCompetition(id: string): Promise<void> {
  try {
    const all = lsAll();
    delete all[id];
    window.localStorage.setItem(LS_KEY, JSON.stringify(all));
  } catch {
    /* ignore */
  }
  try {
    await tx("readwrite", (s) => s.delete(id));
  } catch {
    /* ignore */
  }
}
