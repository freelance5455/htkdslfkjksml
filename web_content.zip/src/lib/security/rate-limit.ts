interface RateBucket {
  timestamps: number[];
}

const globalForRateLimit = globalThis as unknown as {
  __xrayRateBuckets?: Map<string, RateBucket>;
};

const buckets = globalForRateLimit.__xrayRateBuckets ?? new Map<string, RateBucket>();
globalForRateLimit.__xrayRateBuckets = buckets;

export function checkRateLimit(clientKey: string): { allowed: boolean; retryAfterSeconds?: number } {
  const maxPerHour = Number(process.env.RATE_LIMIT_MAX_SCANS_PER_HOUR ?? 15);
  const windowMs = 60 * 60 * 1000;
  const now = Date.now();

  const bucket = buckets.get(clientKey) ?? { timestamps: [] };
  bucket.timestamps = bucket.timestamps.filter((t) => now - t < windowMs);

  if (bucket.timestamps.length >= maxPerHour) {
    const oldest = bucket.timestamps[0];
    const retryAfterSeconds = Math.ceil((windowMs - (now - oldest)) / 1000);
    buckets.set(clientKey, bucket);
    return { allowed: false, retryAfterSeconds };
  }

  bucket.timestamps.push(now);
  buckets.set(clientKey, bucket);
  return { allowed: true };
}
