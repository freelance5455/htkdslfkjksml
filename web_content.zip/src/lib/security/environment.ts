import type { Environment, PlatformKind } from "./types";

export type BrowserInfo = { name: string; major: number | null };

export function readBrowser(ua = navigator.userAgent): BrowserInfo {
  const patterns: [RegExp, string][] = [
    [/Edg\/(\d+)/, "Edge"],
    [/OPR\/(\d+)/, "Opera"],
    [/CriOS\/(\d+)/, "Chrome"],
    [/FxiOS\/(\d+)/, "Firefox"],
    [/Firefox\/(\d+)/, "Firefox"],
    [/Chrome\/(\d+)/, "Chrome"],
    [/Version\/(\d+).+Safari\//, "Safari"],
  ];
  for (const [re, name] of patterns) {
    const match = ua.match(re);
    if (match) return { name, major: Number(match[1]) };
  }
  const brands = (
    navigator as Navigator & {
      userAgentData?: { brands?: { brand: string; version: string }[] };
    }
  ).userAgentData?.brands;
  const brand = brands?.find((item) => !/not.a.brand/i.test(item.brand) && !/chromium/i.test(item.brand));
  if (brand) {
    const major = Number(brand.version);
    return { name: brand.brand, major: Number.isFinite(major) ? major : null };
  }
  return { name: "This browser", major: null };
}

export function detectEnvironment(): Environment {
  const ua = navigator.userAgent || "";
  const platform = navigator.platform || "";
  const touch = navigator.maxTouchPoints > 1;
  const iPad = /iPad/.test(ua) || (platform === "MacIntel" && touch);
  const iPhone = /iPhone|iPod/.test(ua);
  const android = /Android/i.test(ua);

  let os: PlatformKind = "computer";
  let osLabel = "Computer";
  if (iPad) {
    os = "ios";
    osLabel = "iPad";
  } else if (iPhone) {
    os = "ios";
    osLabel = "iPhone";
  } else if (android) {
    os = "android";
    osLabel = "Android";
  } else if (/Win/.test(platform)) osLabel = "Windows";
  else if (/Mac/.test(platform)) osLabel = "Mac";
  else if (/CrOS/.test(ua)) osLabel = "Chromebook";
  else if (/Linux/.test(platform) || /Linux/.test(ua)) osLabel = "Linux";

  const shortSide = Math.min(screen.width, screen.height);
  let form: Environment["form"] = "computer";
  if (iPad) form = "tablet";
  else if (os !== "computer") form = shortSide >= 700 ? "tablet" : "phone";

  const browser = readBrowser(ua);
  const browserLabel = browser.major ? `${browser.name} ${browser.major}` : browser.name;
  const memory = (navigator as Navigator & { deviceMemory?: number }).deviceMemory;
  const connection = (
    navigator as Navigator & { connection?: { effectiveType?: string } }
  ).connection;

  const bits = [osLabel, browserLabel];
  if (typeof memory === "number" && memory > 0) bits.push(`about ${memory} GB memory`);
  if (connection?.effectiveType) bits.push(connection.effectiveType);
  if (!navigator.onLine) bits.push("offline");

  return { os, form, osLabel, browserLabel, detail: bits.join(" · ") };
}

export function pageIsFramed(): boolean {
  try {
    return window.self !== window.top;
  } catch {
    return true;
  }
}
