import type { FileReport, FileSignal, Severity } from "./types";

const HIGH = new Set([
  "exe",
  "scr",
  "bat",
  "cmd",
  "com",
  "pif",
  "msi",
  "dll",
  "vbs",
  "vbe",
  "jse",
  "wsf",
  "wsh",
  "ps1",
  "reg",
  "lnk",
  "hta",
  "cpl",
  "msc",
  "jar",
  "apk",
  "xapk",
  "apks",
  "dex",
  "elf",
]);

const SCRIPT = new Set(["js", "sh", "command"]);
const MACRO = new Set(["docm", "xlsm", "pptm", "dotm", "xltm", "potm"]);
const DISK = new Set(["iso", "img", "dmg", "pkg"]);
const LOOKS_SAFE = new Set([
  "jpg",
  "jpeg",
  "png",
  "gif",
  "webp",
  "pdf",
  "txt",
  "mp4",
  "mov",
  "mp3",
  "heic",
  "csv",
  "doc",
  "docx",
  "xls",
  "xlsx",
  "ppt",
  "pptx",
  "html",
  "htm",
]);

const RANK: Record<Severity, number> = { clear: 0, info: 1, review: 2, risk: 3 };

const FULL_READ = 8 * 1024 * 1024;

type Kind =
  | "pe"
  | "elf"
  | "zip"
  | "pdf"
  | "png"
  | "jpg"
  | "gif"
  | "webp"
  | "rar"
  | "7z"
  | "dex"
  | "macho"
  | "class"
  | "ole"
  | "script"
  | "unknown";

function starts(bytes: Uint8Array, magic: number[]): boolean {
  if (bytes.length < magic.length) return false;
  return magic.every((value, index) => bytes[index] === value);
}

function sniff(head: Uint8Array): Kind {
  if (starts(head, [0x4d, 0x5a])) return "pe";
  if (starts(head, [0x7f, 0x45, 0x4c, 0x46])) return "elf";
  if (head.length >= 4 && head[0] === 0x50 && head[1] === 0x4b && (head[2] === 0x03 || head[2] === 0x05 || head[2] === 0x07)) {
    return "zip";
  }
  if (starts(head, [0x25, 0x50, 0x44, 0x46])) return "pdf";
  if (starts(head, [0x89, 0x50, 0x4e, 0x47])) return "png";
  if (starts(head, [0xff, 0xd8, 0xff])) return "jpg";
  if (starts(head, [0x47, 0x49, 0x46])) return "gif";
  if (
    starts(head, [0x52, 0x49, 0x46, 0x46]) &&
    head.length > 12 &&
    head[8] === 0x57 &&
    head[9] === 0x45 &&
    head[10] === 0x42 &&
    head[11] === 0x50
  ) {
    return "webp";
  }
  if (starts(head, [0x52, 0x61, 0x72, 0x21])) return "rar";
  if (starts(head, [0x37, 0x7a, 0xbc, 0xaf, 0x27, 0x1c])) return "7z";
  if (starts(head, [0x64, 0x65, 0x78, 0x0a])) return "dex";
  if (starts(head, [0xca, 0xfe, 0xba, 0xbe])) return "class";
  if (
    starts(head, [0xfe, 0xed, 0xfa, 0xce]) ||
    starts(head, [0xfe, 0xed, 0xfa, 0xcf]) ||
    starts(head, [0xce, 0xfa, 0xed, 0xfe]) ||
    starts(head, [0xcf, 0xfa, 0xed, 0xfe])
  ) {
    return "macho";
  }
  if (starts(head, [0xd0, 0xcf, 0x11, 0xe0])) return "ole";
  if (head.length >= 2 && head[0] === 0x23 && head[1] === 0x21) return "script";
  return "unknown";
}

function baseName(name: string): string {
  return name.split(/[/\\]/).pop() || name;
}

function extension(name: string): string {
  const parts = baseName(name).split(".");
  if (parts.length < 2) return "";
  return parts[parts.length - 1]?.toLowerCase() ?? "";
}

export function signalsFromName(name: string): FileSignal[] {
  const signals: FileSignal[] = [];
  const parts = baseName(name).split(".");
  if (parts.length < 2) {
    signals.push({
      severity: "info",
      text: "There is no file extension. Judge it by where it came from, not by a missing name.",
    });
    return signals;
  }
  const ext = parts[parts.length - 1]?.toLowerCase() ?? "";
  const earlier = parts.slice(0, -1).map((part) => part.toLowerCase());
  const disguised =
    earlier.some((part) => LOOKS_SAFE.has(part)) && (HIGH.has(ext) || SCRIPT.has(ext) || MACRO.has(ext));
  if (disguised) {
    signals.push({
      severity: "risk",
      text: `The name is a disguise. It looks harmless, but “.${ext}” can run a program. Do not open it.`,
    });
  }
  if (HIGH.has(ext) && !disguised) {
    const android = ext === "apk" || ext === "xapk" || ext === "apks";
    signals.push({
      severity: "risk",
      text: android
        ? "This is an Android install file. Harmful apps usually arrive this way, outside the Play Store. Install it only when you trust the publisher, and check the name in Apps first."
        : `“.${ext}” can install or run a program. Open it only if you asked for this exact file and you know who sent it.`,
    });
  }
  if (SCRIPT.has(ext) && !disguised) {
    signals.push({
      severity: "review",
      text: "This is a script. It is fine if you wrote it, and a common virus shape if a stranger sent it.",
    });
  }
  if (MACRO.has(ext)) {
    signals.push({
      severity: "review",
      text: "This Office file can contain macros, which are small programs. Do not enable macros unless you were expecting the file.",
    });
  }
  if (DISK.has(ext)) {
    signals.push({
      severity: "review",
      text: "Disk images can start an installer as soon as they open. Continue only if you meant to download this.",
    });
  }
  if (ext === "html" || ext === "htm" || ext === "svg") {
    signals.push({
      severity: "info",
      text: "Opening this in a browser can run code. That is normal for a page you saved, and a trick if it arrived as an invoice or a receipt.",
    });
  }
  return signals;
}

function executableKind(kind: Kind): boolean {
  return kind === "pe" || kind === "elf" || kind === "dex" || kind === "macho" || kind === "script" || kind === "class";
}

function signalsFromKind(name: string, kind: Kind): FileSignal[] {
  if (kind === "unknown") return [];
  const ext = extension(name);
  const looksDoc = ["jpg", "jpeg", "png", "gif", "webp", "pdf", "txt", "mp3", "heic", "csv"].includes(ext);
  if (looksDoc && (executableKind(kind) || kind === "zip")) {
    const what =
      kind === "zip"
        ? "a package, often an app"
        : kind === "script"
          ? "a script"
          : "a program";
    return [
      {
        severity: "risk",
        text: `The name says “.${ext || "file"}”, but the contents are ${what}. Do not open it.`,
      },
    ];
  }
  return [];
}

const EICAR_MARK = "EIC" + "AR-STANDARD-ANTIVIRUS-TEST-FILE";

function textOf(bytes: Uint8Array): string {
  try {
    return new TextDecoder("utf-8", { fatal: false }).decode(bytes);
  } catch {
    return "";
  }
}

function contentSignals(text: string, kind: Kind, ext: string): FileSignal[] {
  const signals: FileSignal[] = [];
  if (/invoke-expression|\bpowershell\b[^\n]{0,80}-encodedcommand|\bpowershell\b[^\n]{0,40}\s-e(?:n|nc)\b/i.test(text)) {
    signals.push({
      severity: "risk",
      text: "Contains an encoded PowerShell command, a common way harmful files hide what they run.",
    });
  }
  if (/wscript\.shell|shell\.application|adodb\.stream/i.test(text)) {
    signals.push({
      severity: "risk",
      text: "Contains a Windows script that can start programs.",
    });
  }
  if (/eval\s*\([\s\S]{0,80}atob\s*\(|function\s*\(\s*\)\s*\{\s*return\s*atob/i.test(text) || (/eval\s*\(/.test(text) && /fromcharcode|atob\s*\(/i.test(text))) {
    signals.push({
      severity: "risk",
      text: "Contains hidden script built to conceal what it runs.",
    });
  }
  if (/\b(?:curl|wget)\b[^\n|]{0,160}\|\s*(?:ba)?sh\b/i.test(text) || /base64\s+-d[^\n|]{0,120}\|\s*(?:ba)?sh/i.test(text)) {
    signals.push({
      severity: "risk",
      text: "Contains a command that downloads a program and runs it immediately.",
    });
  }
  if ((MACRO.has(ext) || kind === "ole") && /autoopen|auto_open|document_open/i.test(text)) {
    signals.push({
      severity: "risk",
      text: "This document tries to run code as soon as it opens.",
    });
  }
  return signals;
}

type ZipEntry = { name: string; method: number; data: Uint8Array | null; uncompressed: number };

function walkZip(bytes: Uint8Array): ZipEntry[] {
  const entries: ZipEntry[] = [];
  if (bytes.byteLength < 30) return entries;
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let offset = 0;
  while (offset + 30 <= bytes.length && entries.length < 60) {
    if (view.getUint32(offset, true) !== 0x04034b50) break;
    const flags = view.getUint16(offset + 6, true);
    const method = view.getUint16(offset + 8, true);
    const compressed = view.getUint32(offset + 18, true);
    const uncompressed = view.getUint32(offset + 22, true);
    const nameLen = view.getUint16(offset + 26, true);
    const extraLen = view.getUint16(offset + 28, true);
    const nameStart = offset + 30;
    if (nameStart + nameLen > bytes.length) break;
    const name = textOf(bytes.subarray(nameStart, nameStart + nameLen));
    const dataStart = nameStart + nameLen + extraLen;
    if (flags & 0x8 && compressed === 0) {
      entries.push({ name, method, data: null, uncompressed });
      break;
    }
    if (dataStart > bytes.length) break;
    const dataEnd = Math.min(bytes.length, dataStart + compressed);
    const complete = dataEnd === dataStart + compressed;
    entries.push({
      name,
      method,
      data: complete ? bytes.subarray(dataStart, dataEnd) : null,
      uncompressed,
    });
    if (!complete) break;
    offset = dataEnd;
  }
  return entries;
}

function bytesBuffer(bytes: Uint8Array): ArrayBuffer {
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
}

async function inflateRaw(data: Uint8Array): Promise<Uint8Array | null> {
  const Stream = globalThis.DecompressionStream;
  if (!Stream || data.byteLength === 0 || data.byteLength > 1_500_000) return null;
  try {
    const copy = bytesBuffer(data);
    const stream = new Blob([copy]).stream().pipeThrough(new Stream("deflate-raw"));
    const buf = await new Response(stream).arrayBuffer();
    if (buf.byteLength > 6 * 1024 * 1024) return null;
    return new Uint8Array(buf);
  } catch {
    return null;
  }
}

async function packageSignals(bytes: Uint8Array, ext: string, kind: Kind): Promise<FileSignal[]> {
  if (kind !== "zip" && ext !== "apk" && ext !== "xapk" && ext !== "apks" && ext !== "zip") return [];
  const entries = walkZip(bytes);
  if (!entries.length) return [];
  const signals: FileSignal[] = [];
  const interesting = entries.filter(
    (entry) =>
      /AndroidManifest\.xml$/i.test(entry.name) ||
      /assets\/.+\.(dex|jar|apk|exe|so)$/i.test(entry.name) ||
      /(^|\/)classes\d*\.dex$/i.test(entry.name),
  );
  let corpus = "";
  for (const entry of interesting) {
    if (/assets\/.+\.(dex|jar|apk|exe)$/i.test(entry.name)) {
      signals.push({
        severity: "risk",
        text: `Hidden program inside the package (${entry.name}). Ordinary apps do not hide an installer there.`,
      });
    }
    if (!entry.data) continue;
    if (entry.method === 0) corpus += `\n${textOf(entry.data)}`;
    else if (entry.method === 8 && entry.uncompressed < 4 * 1024 * 1024) {
      const inflated = await inflateRaw(entry.data);
      if (inflated) corpus += `\n${textOf(inflated)}`;
    }
  }
  corpus += `\n${textOf(bytes.subarray(0, Math.min(bytes.length, 400_000)))}`;
  const perms: { id: string; severity: Severity; text: string }[] = [
    {
      id: "BIND_ACCESSIBILITY_SERVICE",
      severity: "risk",
      text: "This package can use Accessibility, which lets it read the screen and control other apps. Stalkerware depends on that.",
    },
    {
      id: "BIND_DEVICE_ADMIN",
      severity: "risk",
      text: "This package asks to be a device administrator, which makes it hard to remove.",
    },
    {
      id: "RECEIVE_SMS",
      severity: "review",
      text: "It can read incoming text messages, including login codes.",
    },
    {
      id: "SEND_SMS",
      severity: "review",
      text: "It can send text messages from the phone.",
    },
    {
      id: "REQUEST_INSTALL_PACKAGES",
      severity: "review",
      text: "It can ask the phone to install other apps.",
    },
  ];
  const hit = perms.filter((perm) => corpus.includes(perm.id));
  for (const perm of hit) signals.push({ severity: perm.severity, text: perm.text });
  if (hit.filter((perm) => perm.id.includes("SMS") || perm.id.includes("INSTALL")).length >= 2) {
    signals.push({
      severity: "risk",
      text: "Several high-risk permissions show up together. That pattern is typical of a harmful app, not a normal tool.",
    });
  }
  return signals;
}

function summarize(signals: FileSignal[], drill: boolean): { severity: Severity; title: string } {
  if (drill) return { severity: "info", title: "Harmless test file recognized" };
  if (signals.some((signal) => signal.severity === "risk")) {
    return { severity: "risk", title: "Harmful pattern found" };
  }
  if (signals.some((signal) => signal.severity === "review")) {
    return { severity: "review", title: "Look before you open it" };
  }
  if (signals.some((signal) => signal.severity === "info")) {
    return { severity: "info", title: "No threat pattern, with a note" };
  }
  return { severity: "clear", title: "No harmful pattern" };
}

async function sha256(bytes: Uint8Array): Promise<string | null> {
  try {
    const copy = bytesBuffer(bytes);
    const digest = await crypto.subtle.digest("SHA-256", copy);
    return [...new Uint8Array(digest)].map((value) => value.toString(16).padStart(2, "0")).join("");
  } catch {
    return null;
  }
}

function reportFrom(name: string, size: number | null, signals: FileSignal[], extra: Partial<FileReport>): FileReport {
  const drill = extra.drill ?? false;
  const summary = summarize(signals, drill);
  return {
    id: crypto.randomUUID(),
    name,
    size,
    sha256: extra.sha256 ?? null,
    partial: extra.partial ?? false,
    severity: summary.severity,
    title: summary.title,
    signals: drill
      ? [
          {
            severity: "info",
            text: "This is the industry test file used to prove a scanner is working. It is harmless, and it is not a virus on your device.",
          },
        ]
      : signals,
    drill,
  };
}

export function scanFileName(name: string): FileReport {
  const trimmed = name.trim();
  return reportFrom(trimmed || "untitled", null, signalsFromName(trimmed), {});
}

export function eicarFile(): File {
  const text = ["X5O!P%@AP[4\\PZX54(P^)7CC)7}$", "EIC", "AR-", "STANDARD-", "ANTIVIRUS-", "TEST-", "FILE!$H+H*"].join("");
  return new File([text], "eicar-test.com", { type: "application/octet-stream" });
}

export async function scanFile(file: File): Promise<FileReport> {
  const nameSignals = signalsFromName(file.name);
  const partial = file.size > FULL_READ;
  const headBlob = partial ? file.slice(0, 512 * 1024) : file;
  const head = new Uint8Array(await headBlob.arrayBuffer());
  let sample = head;
  if (partial) {
    const tail = new Uint8Array(await file.slice(Math.max(0, file.size - 256 * 1024)).arrayBuffer());
    sample = new Uint8Array(head.length + tail.length);
    sample.set(head, 0);
    sample.set(tail, head.length);
  }
  const kind = sniff(head);
  const text = textOf(sample);
  const drill = text.includes(EICAR_MARK);
  const signals = [
    ...nameSignals,
    ...signalsFromKind(file.name, kind),
    ...contentSignals(text, kind, extension(file.name)),
    ...(await packageSignals(head, extension(file.name), kind)),
  ];
  if (partial) {
    signals.push({
      severity: "info",
      text: "This file is large, so only the beginning and the end were read on this device.",
    });
  }
  const hash = !partial && file.size <= 16 * 1024 * 1024 ? await sha256(head) : null;
  return reportFrom(file.name, file.size, signals, { sha256: hash, partial, drill });
}

export function formatBytes(size: number): string {
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${Math.max(1, Math.round(size / 1024))} KB`;
  const mb = size / (1024 * 1024);
  return `${mb >= 10 ? Math.round(mb) : mb.toFixed(1)} MB`;
}
