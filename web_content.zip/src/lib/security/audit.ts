import type { Answer, AuditQuestion, PlatformKind } from "./types";

export const QUESTIONS: AuditQuestion[] = [
  {
    id: "lock",
    platforms: "all",
    prompt: "Does this device require a PIN, password, or biometrics to unlock?",
    riskIfYes: false,
    detail:
      "Set a lock. Without one, anyone holding the phone can install something, and some harmful apps are put there by a person who briefly has the device.",
    weight: 16,
  },
  {
    id: "updates",
    platforms: "all",
    prompt: "Are system updates installed, with nothing important waiting?",
    riskIfYes: false,
    detail:
      "Install the update. Harmful apps often rely on bugs that the current system version has already closed.",
    weight: 16,
  },
  {
    id: "unknown",
    platforms: "all",
    prompt: "Is there an app here you do not remember installing?",
    riskIfYes: true,
    detail:
      "Remove it. If it refuses to uninstall, it may have device-administrator rights. That is a common way stalkerware stays on a phone.",
    weight: 20,
  },
  {
    id: "booster",
    platforms: "all",
    prompt: "Is a cleaner, booster, or “virus remover” app installed?",
    riskIfYes: true,
    detail:
      "Uninstall it. Phones do not need cleaner apps. That costume is a usual way adware gets in. Use Play Protect or the iPhone’s own system instead.",
    weight: 14,
  },
  {
    id: "sideload-android",
    platforms: ["android"],
    prompt: "Do you install apps from outside the Play Store — files, links, or “unknown sources”?",
    riskIfYes: true,
    detail:
      "Turn installation from unknown sources off when you are finished. Most harmful Android apps arrive as a downloaded file, not from the store.",
    weight: 18,
  },
  {
    id: "access",
    platforms: ["android"],
    prompt: "Does an app you do not fully trust have Accessibility or Device admin turned on?",
    riskIfYes: true,
    detail:
      "Turn those off, then uninstall the app. Accessibility can read the screen and tap buttons for you. Surveillance apps depend on it.",
    weight: 22,
  },
  {
    id: "play",
    platforms: ["android"],
    prompt: "Is Google Play Protect turned on?",
    riskIfYes: false,
    detail:
      "Open the Play Store, tap your picture, then Play Protect, and turn scanning on. That is the real on-device check for harmful apps.",
    weight: 12,
  },
  {
    id: "profile",
    platforms: ["ios"],
    prompt: "Is there a profile, or an app from outside the App Store, that you did not choose?",
    riskIfYes: true,
    detail:
      "Remove unknown profiles in Settings → General → VPN & Device Management. A profile you did not install can watch traffic or push extra apps.",
    weight: 20,
  },
  {
    id: "jailbreak",
    platforms: ["ios"],
    prompt: "Is this iPhone jailbroken, or are you unsure?",
    riskIfYes: true,
    detail:
      "A jailbreak turns off core protections. If you did not do it on purpose, restore the phone or ask someone you trust for help.",
    weight: 18,
  },
  {
    id: "apple-id",
    platforms: ["ios"],
    prompt: "Do you recognize every device signed in with your Apple ID?",
    riskIfYes: false,
    detail: "Check Settings → your name. Sign out of anything unfamiliar, then change the Apple ID password.",
    weight: 12,
  },
  {
    id: "extensions",
    platforms: ["computer"],
    prompt: "Does the browser have an extension you do not remember adding?",
    riskIfYes: true,
    detail:
      "Remove it. An unknown extension can read pages, including mail and banking. On a computer, that is a common stand-in for a virus.",
    weight: 16,
  },
  {
    id: "defender",
    platforms: ["computer"],
    prompt: "Is built-in protection on — Windows Security, or the protection that comes with the Mac?",
    riskIfYes: false,
    detail: "Turn it on and let a scan finish. You do not need a second cleaner suite beside it.",
    weight: 16,
  },
  {
    id: "attachment",
    platforms: ["computer"],
    prompt: "Have you opened an installer or document that arrived in an unexpected email?",
    riskIfYes: true,
    detail:
      "Run the built-in scan, and change important passwords from a device you trust. Unexpected attachments are still how most computer viruses travel.",
    weight: 14,
  },
];

export function questionsFor(os: PlatformKind): AuditQuestion[] {
  return QUESTIONS.filter((question) => question.platforms === "all" || question.platforms.includes(os));
}

export function isRiskyAnswer(question: AuditQuestion, answer: Answer): boolean {
  return question.riskIfYes ? answer === "yes" : answer === "no";
}
