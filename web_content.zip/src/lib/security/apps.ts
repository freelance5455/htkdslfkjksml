import type { AppAssessment, Severity } from "./types";

const STALKERWARE = [
  "mspy",
  "flexispy",
  "hoverwatch",
  "thetruthspy",
  "cocospy",
  "spyic",
  "umobix",
  "kidsguard",
  "xnspy",
  "spyera",
  "pctattletale",
  "mobilespy",
  "highster",
  "spyfone",
  "letmespy",
  "theonespy",
  "spyhuman",
  "ikeymonitor",
  "spyzie",
  "mobistealth",
  "spybubble",
  "copy9",
  "ispyoo",
  "catwatchful",
  "webwatcher",
  "teensafe",
  "spyphone",
  "androidspy",
];

const MODDED = [
  "gbwhatsapp",
  "fmwhatsapp",
  "yowhatsapp",
  "ogwhatsapp",
  "whatsappplus",
  "whatsappgb",
  "instapro",
  "instagram++",
  "snapchat++",
  "youtubevanced",
  "fminstagram",
];

const BAD_CLEANERS = ["cleanmaster", "dubatterysaver", "duspeedbooster", "cmsecurity", "cheetahmobile"];

const TRUSTED = new Set([
  "whatsapp",
  "whatsappmessenger",
  "whatsappbusiness",
  "instagram",
  "chrome",
  "googlechrome",
  "safari",
  "gmail",
  "googlemaps",
  "maps",
  "youtube",
  "signal",
  "telegram",
  "bitwarden",
  "1password",
  "onepassword",
  "photos",
  "settings",
  "messages",
  "googlemessages",
  "playstore",
  "googleplay",
  "appstore",
  "firefox",
  "edge",
  "microsoftedge",
  "outlook",
  "slack",
  "zoom",
  "netflix",
  "spotify",
  "uber",
  "paypal",
  "amazon",
  "facebook",
  "messenger",
  "files",
  "camera",
  "phone",
  "contacts",
  "calendar",
  "notes",
  "findmy",
  "icloud",
]);

export type PermissionFlag = {
  id: string;
  label: string;
  severity: Severity;
  detail: string;
};

export const PERMISSION_FLAGS: PermissionFlag[] = [
  {
    id: "access",
    label: "Accessibility — it can see and tap the screen",
    severity: "risk",
    detail: "Accessibility is the tool stalkerware uses to read chats and stay hidden. Turn it off, then remove the app.",
  },
  {
    id: "admin",
    label: "Device administrator — hard to uninstall",
    severity: "risk",
    detail: "Remove the administrator right in system settings, then uninstall. Harmful apps use it so the Delete button does nothing.",
  },
  {
    id: "sms",
    label: "Read or send text messages",
    severity: "risk",
    detail: "That can catch login codes and send texts on your bill. A game, cleaner, or “update” does not need it.",
  },
  {
    id: "install",
    label: "Install unknown apps",
    severity: "risk",
    detail: "It can put more apps on the phone. Turn that permission off and delete the app that asked.",
  },
  {
    id: "hidden",
    label: "The icon disappeared after install",
    severity: "risk",
    detail: "A hidden icon is a stalkerware habit. Search settings for the name, revoke administrator, and uninstall.",
  },
  {
    id: "overlay",
    label: "Display over other apps",
    severity: "review",
    detail: "Some launchers need this. A cleaner or a random tool can use it to cover the screen with a fake login.",
  },
  {
    id: "notify",
    label: "Read notifications from other apps",
    severity: "review",
    detail: "Notification access can read private messages. Only a tool you deliberately chose, like a watch or a car display, should have it.",
  },
];

const RANK: Record<Severity, number> = { clear: 0, info: 1, review: 2, risk: 3 };

function norm(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9+]/g, "");
}

function includesName(query: string, name: string): boolean {
  const needle = norm(name);
  return needle.length >= 4 && query.includes(needle);
}

export function assessAppName(raw: string): AppAssessment | null {
  const query = raw.trim();
  if (query.length < 2) return null;
  const n = norm(query);
  if (!n) return null;

  if (TRUSTED.has(n)) {
    return {
      severity: "clear",
      title: "Official name, nothing flagged",
      detail: `${query.trim()} matches a well-known app. Install it only from the App Store or Play Store. Modded copies — Plus, GB, FM, gold — are a common place for hidden malware.`,
      steps: ["Confirm the publisher in the store listing.", "If you sideloaded a copy, delete it and install the official one."],
      percent: 99,
    };
  }

  const stalker = STALKERWARE.find((name) => includesName(n, name));
  if (stalker) {
    return {
      severity: "risk",
      title: "Known surveillance app",
      detail: `“${query.trim()}” matches ${stalker}, a product built to watch a phone: messages, location, photos, or all three. Security researchers and regulators have treated this family as stalkerware.`,
      steps: [
        "Uninstall it. If it will not leave, revoke Device admin and Accessibility first.",
        "Change mail, banking, and Apple or Google passwords from a different device.",
        "If someone else installed it, that is a safety issue, not only a phone issue.",
      ],
      percent: 18,
    };
  }

  if (MODDED.some((name) => n.includes(norm(name)))) {
    return {
      severity: "risk",
      title: "Modded app — a common malware costume",
      detail:
        "Copies of WhatsApp, Instagram, Snapchat, and YouTube with Plus, GB, FM, or similar in the name are not the official app. The extra features are often bundled with spyware or adware.",
      steps: [
        "Delete the modded app.",
        "Install the official one from the store.",
        "Change the account password, and turn on two-step verification.",
      ],
      percent: 20,
    };
  }

  if (BAD_CLEANERS.some((name) => n.includes(name))) {
    return {
      severity: "risk",
      title: "Unwanted cleaner, not real protection",
      detail:
        "This name belongs to a cleaner family that stores have removed over ads and data collection. A copy you find now is not protecting the phone.",
      steps: ["Uninstall it.", "On Android, rely on Play Protect. On iPhone, rely on the system itself."],
      percent: 22,
    };
  }

  if (/(viruscleaner|phonebooster|speedbooster|rambooster|junkcleaner|supercleaner|memorybooster|antivirusbooster|phonecleaner|batterysaver)/.test(n)) {
    return {
      severity: "review",
      title: "Cleaner name — often adware",
      detail:
        "Names like booster, junk cleaner, and virus cleaner are a usual costume for annoying or harmful apps. The phone already knows how to free space.",
      steps: [
        "If it did not come from the phone maker or the official store, uninstall it.",
        "Ignore any screen that says the phone is badly infected and demands a download.",
      ],
      percent: 64,
    };
  }

  if (/(freewifipassword|wifihack|hackwifi|credithack|freerecharge|freeairtime|winiphone)/.test(n)) {
    return {
      severity: "risk",
      title: "Too-good-to-be-true tool",
      detail: "Apps that promise free Wi-Fi passwords, free airtime, or a prize are a standard way to steal accounts or install more software.",
      steps: ["Delete it without opening it.", "If you already signed in, change that password from another device."],
      percent: 16,
    };
  }

  if (/(stalkerware|keylogger|keylog|hiddencamera|stealthmonitor)/.test(n)) {
    return {
      severity: "risk",
      title: "Name says it is for spying",
      detail: "Anything sold as a hidden camera, keylogger, or stealth monitor does not belong on a phone you want to keep private.",
      steps: ["Uninstall it.", "Check Accessibility and device administrator for leftovers."],
      percent: 18,
    };
  }

  if (n.includes("spy")) {
    return {
      severity: "review",
      title: "The name suggests spying",
      detail:
        "If this is a game or a book, you can ignore this note. If it is a tracker, a “family safety” tool you did not install, or something that hides its icon, treat it as stalkerware.",
      steps: ["Open the store page and read who publishes it.", "Remove it if you cannot explain why it is installed."],
      percent: 58,
    };
  }

  return {
    severity: "clear",
    title: "Nothing in the catalog flags this name",
    detail:
      "Aegis does not have a record of this name as a known harmful app. That is not a guarantee. What it asks to access matters more than a clean name.",
    steps: ["Check the permissions below against what the phone actually shows.", "Install only from the official store."],
      percent: null,
  };
}

export function combineAssessment(
  assessment: AppAssessment | null,
  flagIds: string[],
): AppAssessment | null {
  const flags = PERMISSION_FLAGS.filter((flag) => flagIds.includes(flag.id));
  if (!assessment && !flags.length) return null;

  const flagSeverity = flags.reduce<Severity>(
    (worst, flag) => (RANK[flag.severity] > RANK[worst] ? flag.severity : worst),
    "clear",
  );
  const base = assessment ?? {
    severity: "clear" as Severity,
    title: "Permissions you reported",
    detail: "You have not searched a name yet. These are the permissions you said the app has.",
    steps: [] as string[],
    percent: null,
  };
  if (!flags.length) return base;

  const flagPercent =
    flagSeverity === "risk" ? 20 : flagSeverity === "review" ? 66 : base.percent;
  if (RANK[flagSeverity] < RANK[base.severity]) {
    return { ...base, steps: [...base.steps, ...flags.map((flag) => flag.detail)] };
  }
  const lead = flags.find((flag) => flag.severity === flagSeverity) ?? flags[0];
  const percent =
    base.percent == null ? flagPercent : Math.min(base.percent, flagPercent ?? base.percent);
  return {
    severity: RANK[flagSeverity] > RANK[base.severity] ? flagSeverity : base.severity,
    title:
      flagSeverity === "risk"
        ? "Dangerous permission reported"
        : flagSeverity === "review" && base.severity === "clear"
          ? "Permission worth checking"
          : base.title,
    detail: [lead?.detail, base.detail].filter(Boolean).join(" "),
    steps: [...base.steps, ...flags.map((flag) => flag.detail)],
    percent,
  };
}
