import { isRiskyAnswer } from "./audit";
import type { Answer, AuditQuestion, FileReport, LinkReport, Severity } from "./types";

export function clampScore(points: number): number {
  return Math.max(0, Math.min(100, 100 - points));
}

export function devicePercent(
  browser: number,
  answers: Record<string, Answer | undefined>,
  questions: AuditQuestion[],
): number {
  const answered = questions.filter((question) => answers[question.id]);
  if (!answered.length) return browser;
  let got = 0;
  let total = 0;
  for (const question of answered) {
    total += question.weight;
    const answer = answers[question.id];
    if (answer && !isRiskyAnswer(question, answer)) got += question.weight;
  }
  const audit = total === 0 ? browser : Math.round((got / total) * 100);
  return Math.round(browser * 0.45 + audit * 0.55);
}

export function securedLabel(score: number): string {
  if (score >= 97) return "Highly secured";
  if (score >= 90) return "Secured";
  if (score >= 75) return "Mostly secured";
  if (score >= 50) return "Partly secured";
  return "Not well secured";
}

export function severityPercent(severity: Severity): number {
  if (severity === "risk") return 24;
  if (severity === "review") return 68;
  if (severity === "info") return 90;
  return 97;
}

export function listPercent(items: Severity[]): number | null {
  if (!items.length) return null;
  const scores = items.map((severity) =>
    severity === "risk" ? 18 : severity === "review" ? 62 : severity === "info" ? 90 : 100,
  );
  return Math.min(...scores);
}

export function filesPercent(files: FileReport[], links: LinkReport[]): number | null {
  return listPercent([
    ...files.filter((file) => !file.drill).map((file) => file.severity),
    ...links.map((link) => link.severity),
  ]);
}
