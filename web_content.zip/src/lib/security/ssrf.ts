import dns from "node:dns/promises";
import net from "node:net";

export class SSRFError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "SSRFError";
  }
}

const BLOCKED_HOSTNAMES = new Set([
  "localhost",
  "localhost.localdomain",
  "ip6-localhost",
  "ip6-loopback",
  "metadata.google.internal",
  "metadata",
  "169.254.169.254",
]);

const BLOCKED_SUFFIXES = [".local", ".internal", ".localhost", ".lan", ".home", ".corp"];

function ipv4ToInt(ip: string): number {
  const parts = ip.split(".").map(Number);
  if (parts.length !== 4 || parts.some((n) => Number.isNaN(n) || n < 0 || n > 255)) {
    return -1;
  }
  return ((parts[0] << 24) | (parts[1] << 16) | (parts[2] << 8) | parts[3]) >>> 0;
}

function inCidr4(ipInt: number, baseIp: string, maskBits: number): boolean {
  const baseInt = ipv4ToInt(baseIp);
  if (ipInt < 0 || baseInt < 0) return true;
  const mask = maskBits === 0 ? 0 : (~0 << (32 - maskBits)) >>> 0;
  return (ipInt & mask) === (baseInt & mask);
}

export function isPrivateOrReservedIp(rawIp: string): boolean {
  const ip = rawIp.trim().toLowerCase().replace(/^\[|\]$/g, "");

  if (net.isIPv4(ip)) {
    const n = ipv4ToInt(ip);
    if (n < 0) return true;
    const blockedRanges: [string, number][] = [
      ["0.0.0.0", 8],       // Current network
      ["10.0.0.0", 8],      // RFC1918 private
      ["100.64.0.0", 10],   // CGNAT
      ["127.0.0.0", 8],     // Loopback
      ["169.254.0.0", 16],  // Link-local & cloud metadata
      ["172.16.0.0", 12],   // RFC1918 private
      ["192.0.0.0", 24],    // IETF protocol assignments
      ["192.0.2.0", 24],    // TEST-NET-1
      ["192.168.0.0", 16],  // RFC1918 private
      ["198.18.0.0", 15],   // Benchmarking
      ["198.51.100.0", 24], // TEST-NET-2
      ["203.0.113.0", 24],  // TEST-NET-3
      ["224.0.0.0", 4],     // Multicast
      ["240.0.0.0", 4],     // Reserved / Broadcast
    ];
    return blockedRanges.some(([base, bits]) => inCidr4(n, base, bits));
  }

  if (net.isIPv6(ip)) {
    if (ip === "::" || ip === "::1") return true;
    // IPv4-mapped IPv6 (e.g. ::ffff:127.0.0.1)
    if (ip.startsWith("::ffff:")) {
      const v4 = ip.slice(7);
      if (net.isIPv4(v4)) return isPrivateOrReservedIp(v4);
      // Hex form e.g. ::ffff:7f00:0001
      const hexParts = v4.split(":");
      if (hexParts.length === 2) {
        const hi = parseInt(hexParts[0], 16);
        const lo = parseInt(hexParts[1], 16);
        if (!Number.isNaN(hi) && !Number.isNaN(lo)) {
          const reconstructed = `${(hi >> 8) & 0xff}.${hi & 0xff}.${(lo >> 8) & 0xff}.${lo & 0xff}`;
          return isPrivateOrReservedIp(reconstructed);
        }
      }
      return true;
    }
    // Unique local addresses fc00::/7 (fc.. or fd..)
    if (/^f[cd][0-9a-f]{2}:/i.test(ip)) return true;
    // Link-local fe80::/10 (fe80..febf)
    if (/^fe[89ab][0-9a-f]:/i.test(ip)) return true;
    // Multicast ff00::/8
    if (/^ff[0-9a-f]{2}:/i.test(ip)) return true;
    return false;
  }

  return true;
}

export function validateAndNormalizeUrl(rawInput: string): URL {
  const trimmed = rawInput.trim();
  if (!trimmed) {
    throw new SSRFError("Please enter a website URL.");
  }

  const withProtocol = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;

  let parsed: URL;
  try {
    parsed = new URL(withProtocol);
  } catch {
    throw new SSRFError("Invalid URL format. Please enter a valid http:// or https:// URL.");
  }

  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    throw new SSRFError(`Unsupported protocol "${parsed.protocol}". Only http and https are allowed.`);
  }

  if (parsed.username || parsed.password) {
    throw new SSRFError("URLs containing embedded credentials are not permitted.");
  }

  const hostname = parsed.hostname.toLowerCase();
  if (!hostname) {
    throw new SSRFError("URL must include a valid hostname.");
  }

  const allowLocalTest = process.env.ALLOW_LOCAL_TEST_TARGETS === "true";

  if (!allowLocalTest) {
    if (BLOCKED_HOSTNAMES.has(hostname) || BLOCKED_SUFFIXES.some((s) => hostname.endsWith(s))) {
      throw new SSRFError(`Access to internal or reserved hostname "${hostname}" is blocked.`);
    }

    if (net.isIP(hostname) && isPrivateOrReservedIp(hostname)) {
      throw new SSRFError(`Access to private or reserved IP address "${hostname}" is blocked.`);
    }
  }

  // Strip hash fragment for canonical crawling
  parsed.hash = "";
  return parsed;
}

export async function assertPublicTarget(rawUrl: string): Promise<URL> {
  const parsed = validateAndNormalizeUrl(rawUrl);
  const allowLocalTest = process.env.ALLOW_LOCAL_TEST_TARGETS === "true";
  if (allowLocalTest) {
    return parsed;
  }

  const hostname = parsed.hostname;
  if (net.isIP(hostname)) {
    if (isPrivateOrReservedIp(hostname)) {
      throw new SSRFError(`Access to private or reserved IP "${hostname}" is blocked.`);
    }
    return parsed;
  }

  let records: { address: string; family: number }[];
  try {
    records = await dns.lookup(hostname, { all: true });
  } catch {
    throw new SSRFError(`Could not resolve DNS for hostname "${hostname}".`);
  }

  if (!records || records.length === 0) {
    throw new SSRFError(`No DNS records found for "${hostname}".`);
  }

  for (const record of records) {
    if (isPrivateOrReservedIp(record.address)) {
      throw new SSRFError(
        `Hostname "${hostname}" resolved to a private or reserved IP (${record.address}), which is blocked.`
      );
    }
  }

  return parsed;
}
