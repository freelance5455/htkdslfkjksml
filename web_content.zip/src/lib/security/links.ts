import type { FileSignal, LinkReport, Severity } from "./types";

const BRANDS = [
  "paypal",
  "google",
  "apple",
  "microsoft",
  "amazon",
  "instagram",
  "whatsapp",
  "facebook",
  "netflix",
  "chase",
  "wellsfargo",
  "binance",
  "coinbase",
  "icloud",
  "outlook",
  "dropbox",
  "adobe",
  "linkedin",
  "tiktok",
  "telegram",
  "stripe",
  "venmo",
  "gmail",
  "dhl",
  "fedex",
];

const SHORTENERS = new Set([
  "bit.ly",
  "tinyurl.com",
  "t.co",
  "goo.gl",
  "ow.ly",
  "is.gd",
  "cutt.ly",
  "tiny.cc",
  "rb.gy",
  "rebrand.ly",
  "buff.ly",
]);

const RANK: Record<Severity, number> = { clear: 0, info: 1, review: 2, risk: 3 };

function fold(value: string): string {
  return value
    .toLowerCase()
    .replace(/0/g, "o")
    .replace(/1/g, "l")
    .replace(/3/g, "e")
    .replace(/5/g, "s")
    .replace(/rn/g, "m");
}

function oneExtraIsDouble(longer: string, shorter: string): boolean {
  for (let i = 0; i < longer.length; i += 1) {
    if (longer.slice(0, i) + longer.slice(i + 1) === shorter) {
      const extra = longer[i];
      return extra === longer[i - 1] || extra === longer[i + 1];
    }
  }
  return false;
}

function brandInside(label: string, brand: string): boolean {
  if (!brand || label === brand || !label.includes(brand)) return false;
  if (label.startsWith(brand) && label.length - brand.length <= 14) return true;
  if (label.endsWith(brand)) {
    const extra = label.slice(0, -brand.length);
    return /[-.]|(login|secure|account|verify|update|signin|support)/.test(extra);
  }
  return false;
}

function lookalike(label: string, brand: string): boolean {
  if (!label || label === brand) return false;
  const folded = fold(label);
  const foldedBrand = fold(brand);
  if (folded === foldedBrand) return label !== brand;
  if (Math.abs(folded.length - foldedBrand.length) !== 1) return false;
  if (folded.length > foldedBrand.length) return oneExtraIsDouble(folded, foldedBrand);
  return foldedBrand.length >= 6 && oneExtraIsDouble(foldedBrand, folded);
}

function splitHost(host: string): { label: string; subs: string[] } {
  const parts = host.toLowerCase().replace(/\.$/, "").split(".").filter(Boolean);
  const pair = parts.slice(-2).join(".");
  const multi = new Set(["co.uk", "com.au", "co.in", "com.br", "co.jp", "co.za", "com.mx"]);
  if (multi.has(pair) && parts.length >= 3) {
    return { label: parts[parts.length - 3] ?? "", subs: parts.slice(0, -3) };
  }
  if (parts.length < 2) return { label: parts[0] ?? "", subs: [] };
  return { label: parts[parts.length - 2] ?? "", subs: parts.slice(0, -2) };
}

function worst(signals: FileSignal[]): Severity {
  return signals.reduce<Severity>((best, signal) => (RANK[signal.severity] > RANK[best] ? signal.severity : best), "clear");
}

export function inspectLink(raw: string): LinkReport | null {
  const input = raw.trim();
  if (!input) return null;
  const id = crypto.randomUUID();

  if (/^(javascript|data|file|blob):/i.test(input)) {
    return {
      id,
      input,
      severity: "risk",
      title: "This link can run code",
      signals: [
        {
          severity: "risk",
          text: "The address is not a normal website. Do not open it. Links like this are used to run a script or a local file.",
        },
      ],
    };
  }

  let url: URL;
  try {
    url = new URL(input.includes("://") ? input : `https://${input}`);
  } catch {
    return {
      id,
      input,
      severity: "review",
      title: "Not a usable link",
      signals: [
        {
          severity: "review",
          text: "This could not be read as a web address. If it arrived in a text or email you were not expecting, do not open it.",
        },
      ],
    };
  }

  const signals: FileSignal[] = [];
  const host = url.hostname.toLowerCase();

  if (url.username || url.password) {
    signals.push({
      severity: "risk",
      text: "The address hides the real site behind an @ sign. Everything before the @ is a disguise. Do not open it.",
    });
  }
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host) || host.includes(":")) {
    signals.push({
      severity: "review",
      text: "The site is a raw network address, not a name. Banks and stores do not ask you to sign in that way.",
    });
  }
  if (host.includes("xn--")) {
    signals.push({
      severity: "review",
      text: "The address uses lookalike letters (punycode). Read it carefully before you type a password.",
    });
  }
  if (url.protocol === "http:") {
    signals.push({
      severity: "review",
      text: "The link is not encrypted. Do not enter a password or download an app from it.",
    });
  }

  const { label, subs } = splitHost(host);
  const foldedLabel = fold(label);
  const siteIsKnown = BRANDS.includes(label);

  for (const brand of BRANDS) {
    if (!siteIsKnown) {
      for (const sub of subs) {
        if (fold(sub) === fold(brand)) {
          signals.push({
            severity: "risk",
            text: `“${brand}” is only a subdomain. The real site is “${label}”. This is a common sign-in trap.`,
          });
        }
      }
    }
    if (!label || label === brand) continue;
    if (label.length >= 4 && lookalike(label, brand)) {
      signals.push({
        severity: "risk",
        text: `“${label}” is a lookalike of ${brand}. The real site would use the exact name. Do not sign in.`,
      });
    } else if (brandInside(foldedLabel, fold(brand))) {
      signals.push({
        severity: "risk",
        text: `The address borrows the name “${brand}” inside a longer word. Treat it as a fake unless you typed it yourself.`,
      });
    }
  }

  if (SHORTENERS.has(host)) {
    signals.push({
      severity: "review",
      text: "This is a short link. It hides where you will actually land. If a stranger sent it, do not open it.",
    });
  }

  const tld = host.split(".").pop() ?? "";
  if (["zip", "mov", "tk", "ml", "ga", "gq", "cf"].includes(tld)) {
    signals.push({
      severity: "review",
      text: `The ending “.${tld}” is often used to dress up a download or a throwaway site. Confirm you asked for this link.`,
    });
  }

  if (!signals.length) {
    const known = BRANDS.find((brand) => label === brand);
    return {
      id,
      input,
      severity: "clear",
      title: known ? "Name matches the real one" : "Nothing in the address looks disguised",
      signals: [
        {
          severity: "clear",
          text: known
            ? `The main name is exactly “${known}”. Still read the full address before you sign in — a path or a page can still be misleading.`
            : "Aegis did not see a lookalike name, a hidden @ sign, or a code link. That is not proof the page is honest.",
        },
      ],
    };
  }

  const severity = worst(signals);
  const title =
    severity === "risk" ? "Do not open this link" : severity === "review" ? "Check this link before opening" : "Link note";
  return { id, input, severity, title, signals };
}
