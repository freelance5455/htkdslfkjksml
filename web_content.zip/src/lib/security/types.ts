export type Severity = "clear" | "info" | "review" | "risk";

export type CheckResult = {
  id: string;
  title: string;
  detail: string;
  severity: Severity;
  points: number;
};

export type PlatformKind = "ios" | "android" | "computer";

export type Environment = {
  os: PlatformKind;
  form: "phone" | "tablet" | "computer";
  osLabel: string;
  browserLabel: string;
  detail: string;
};

export type DeviceReport = {
  at: number;
  environment: Environment;
  checks: CheckResult[];
  score: number;
};

export type Answer = "yes" | "no";

export type AuditQuestion = {
  id: string;
  platforms: "all" | PlatformKind[];
  prompt: string;
  riskIfYes: boolean;
  detail: string;
  weight: number;
};

export type FileSignal = {
  severity: Severity;
  text: string;
};

export type FileReport = {
  id: string;
  name: string;
  size: number | null;
  sha256: string | null;
  partial: boolean;
  severity: Severity;
  title: string;
  signals: FileSignal[];
  drill?: boolean;
};

export type LinkReport = {
  id: string;
  input: string;
  severity: Severity;
  title: string;
  signals: FileSignal[];
};

export type AppAssessment = {
  severity: Severity;
  title: string;
  detail: string;
  steps: string[];
  /** Null when a name is simply unknown — that is not a safety score. */
  percent: number | null;
};
