import { readBrowser } from "./environment";
import type { CheckResult, Severity } from "./types";

export type CheckSpec = {
  id: string;
  label: string;
  run: () => Promise<CheckResult>;
};

function found(
  id: string,
  title: string,
  detail: string,
  severity: Severity,
  points: number,
): CheckResult {
  return { id, title, detail, severity, points };
}

function withTimeout<T>(work: Promise<T>, ms: number, fallback: T): Promise<T> {
  return new Promise((resolve) => {
    const timer = setTimeout(() => resolve(fallback), ms);
    work.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      () => {
        clearTimeout(timer);
        resolve(fallback);
      },
    );
  });
}

async function checkSecure(): Promise<CheckResult> {
  const host = location.hostname;
  const local = host === "localhost" || host === "127.0.0.1" || host === "::1" || host === "[::1]";
  if (!window.isSecureContext) {
    return found(
      "secure",
      "Connection is not protected",
      "This page is not on a secure connection. On a phone or computer, don’t sign in or install apps from plain http sites, especially on public Wi-Fi.",
      "risk",
      34,
    );
  }
  if (local) {
    return found(
      "secure",
      "Secure local session",
      "The browser treats this page as secure because it is local. On the public web, use the same rule: look for the lock before you sign in or install anything.",
      "clear",
      0,
    );
  }
  return found(
    "secure",
    "Connection is protected",
    "This page is on HTTPS, so a network cannot casually read it. That is the right baseline. It is not a scan of the rest of the device.",
    "clear",
    0,
  );
}

function browserAge(name: string, major: number): { severity: Severity; points: number; phrase: string } | null {
  const compared = name === "Opera" ? major + 14 : major;
  const key = name === "Opera" ? "Chrome" : name;
  const floors: Record<string, [number, number]> = {
    Chrome: [120, 131],
    Edge: [120, 131],
    Firefox: [122, 132],
    Safari: [17, 18],
  };
  const row = floors[key];
  if (!row) return null;
  const [riskBelow, reviewBelow] = row;
  if (compared < riskBelow) {
    return { severity: "risk", points: 18, phrase: "well behind on security fixes" };
  }
  if (compared < reviewBelow) {
    return { severity: "review", points: 8, phrase: "old enough that newer fixes are missing" };
  }
  return null;
}

async function checkBrowser(): Promise<CheckResult> {
  const browser = readBrowser();
  if (browser.major == null) {
    return found(
      "browser",
      "Browser version hidden",
      "This browser did not share a version number. If it is the one that came with the phone, check the store or system settings for an update.",
      "info",
      0,
    );
  }
  const age = browserAge(browser.name, browser.major);
  if (!age) {
    return found(
      "browser",
      `${browser.name} ${browser.major} is current enough`,
      "An old browser is how a lot of “just a link” attacks still land. This one is inside a reasonable window. Keep automatic updates on.",
      "clear",
      0,
    );
  }
  return found(
    "browser",
    `${browser.name} ${browser.major} is ${age.phrase}`,
    "Update it in the App Store, Play Store, or the browser’s own menu. Security fixes ship with those updates, and harmful pages count on people skipping them.",
    age.severity,
    age.points,
  );
}

function isPrivateLan(ip: string): boolean {
  if (ip.startsWith("10.")) return true;
  if (ip.startsWith("192.168.")) return true;
  if (/^172\.(1[6-9]|2\d|3[0-1])\./.test(ip)) return true;
  if (ip.startsWith("fe80:")) return true;
  return false;
}

async function checkWebRtc(): Promise<CheckResult> {
  const RTC = window.RTCPeerConnection;
  if (!RTC) {
    return found(
      "webrtc",
      "No local-network leak from this page",
      "This browser does not offer the network check harmful pages sometimes use to see a private address.",
      "clear",
      0,
    );
  }
  const ips = new Set<string>();
  const pc = new RTC({ iceServers: [] });
  try {
    const foundIps = await withTimeout(
      new Promise<Set<string>>((resolve) => {
        pc.createDataChannel("aegis");
        pc.onicecandidate = (event) => {
          if (!event.candidate) {
            resolve(ips);
            return;
          }
          const match = event.candidate.candidate.match(
            /([0-9]{1,3}(?:\.[0-9]{1,3}){3})|([a-zA-Z0-9.-]+\.local)/,
          );
          if (match) ips.add(match[0]);
        };
        void pc.createOffer().then((offer) => pc.setLocalDescription(offer));
        setTimeout(() => resolve(ips), 1200);
      }),
      1600,
      ips,
    );
    const lan = [...foundIps].filter(isPrivateLan);
    if (lan.length) {
      return found(
        "webrtc",
        "A private network address is visible",
        `A website can see a local address (${lan[0]}) from this browser. That helps a hostile page map the network you are on. Updating the browser usually hides it.`,
        "review",
        8,
      );
    }
    const hidden = [...foundIps].some((ip) => ip.endsWith(".local"));
    return found(
      "webrtc",
      "Local network address stays hidden",
      hidden
        ? "The browser offered only a random stand-in name, not your real network address. That is what you want."
        : "Nothing in this check exposed a private network address.",
      "clear",
      0,
    );
  } catch {
    return found(
      "webrtc",
      "Network check skipped",
      "This browser blocked the local-network check. That is fine — the rest of the scan still counts.",
      "info",
      0,
    );
  } finally {
    pc.close();
  }
}

async function queryPermission(name: string): Promise<PermissionState | "unknown"> {
  try {
    if (!navigator.permissions?.query) return "unknown";
    const status = await navigator.permissions.query({ name: name as PermissionName });
    return status.state;
  } catch {
    return "unknown";
  }
}

async function checkPermissions(): Promise<CheckResult> {
  const names = ["camera", "microphone", "geolocation", "notifications", "clipboard-read"] as const;
  const granted: string[] = [];
  for (const name of names) {
    const state = await queryPermission(name);
    if (state === "granted") granted.push(name);
  }
  if (!granted.length) {
    return found(
      "permissions",
      "This page has no sensitive access",
      "Camera, microphone, location, notifications, and clipboard are not granted here. Aegis does not need them. Other sites are managed in the browser’s settings — a page cannot list those for you.",
      "clear",
      0,
    );
  }
  const labels = granted.map((name) => (name === "clipboard-read" ? "clipboard" : name)).join(", ");
  return found(
    "permissions",
    "This page already has access",
    `Granted to Aegis: ${labels}. This checkup does not use them. If you did not mean to allow that, revoke it in the browser’s site settings. Access given to other sites has to be reviewed there.`,
    "info",
    0,
  );
}

async function checkPasskeys(): Promise<CheckResult> {
  if (window.isSecureContext && "PublicKeyCredential" in window) {
    return found(
      "passkeys",
      "Passkeys are available",
      "This device can use passkeys. They are harder to steal than a login code sent by text. Prefer them for mail, banking, and your Apple or Google account.",
      "clear",
      0,
    );
  }
  return found(
    "passkeys",
    "Passkeys are not available here",
    "A current phone browser can use passkeys. They are not a virus check, but they close the kind of text-message theft harmful apps aim for.",
    "info",
    0,
  );
}

async function checkCookies(): Promise<CheckResult> {
  try {
    document.cookie = "aegis_probe=1; SameSite=Lax; path=/";
    const ok = document.cookie.includes("aegis_probe=");
    document.cookie = "aegis_probe=; Max-Age=0; path=/";
    if (!ok) {
      return found(
        "cookies",
        "Cookies are blocked",
        "This browser is refusing cookies. That is a privacy choice, not a sign of a virus. Some sign-in protections will not work until you allow them for sites you trust.",
        "info",
        0,
      );
    }
  } catch {
    return found(
      "cookies",
      "Cookies could not be checked",
      "The browser did not answer a cookie test. It does not change the rest of the result.",
      "info",
      0,
    );
  }
  return found(
    "cookies",
    "Site storage works",
    "The browser can store a normal site cookie. Aegis uses that only if you stay on this page — the checkup result is kept on this device.",
    "clear",
    0,
  );
}

export const CHECK_LABELS = [
  { id: "secure", label: "Secure connection" },
  { id: "browser", label: "Browser is current" },
  { id: "webrtc", label: "Network address privacy" },
  { id: "permissions", label: "Access this page holds" },
  { id: "passkeys", label: "Passkeys" },
  { id: "cookies", label: "Site storage" },
] as const;

const RUNNERS: Record<(typeof CHECK_LABELS)[number]["id"], () => Promise<CheckResult>> = {
  secure: checkSecure,
  browser: checkBrowser,
  webrtc: checkWebRtc,
  permissions: checkPermissions,
  passkeys: checkPasskeys,
  cookies: checkCookies,
};

export function getCheckSpecs(): CheckSpec[] {
  return CHECK_LABELS.map((item) => ({
    id: item.id,
    label: item.label,
    run: RUNNERS[item.id],
  }));
}

export async function runSpec(spec: CheckSpec): Promise<CheckResult> {
  try {
    return await spec.run();
  } catch {
    return found(
      spec.id,
      spec.label,
      "This check could not finish in this browser. The rest of the scan still counts.",
      "info",
      0,
    );
  }
}
