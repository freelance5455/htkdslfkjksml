import { PALETTES, type Palette } from "@/lib/catalog";

export function getPalette(name: string): Palette {
  return PALETTES[name] ?? PALETTES.iron;
}

export function posterStyle(name: string): React.CSSProperties {
  const palette = getPalette(name);
  return {
    backgroundImage: `linear-gradient(155deg, ${palette.from} 0%, ${palette.to} 78%)`,
  };
}

export function timeAgo(iso: string): string {
  const then = new Date(iso).getTime();
  const diff = Date.now() - then;
  const minutes = Math.round(diff / 60000);
  if (minutes < 1) return "adesso";
  if (minutes < 60) return `${minutes} min fa`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours} h fa`;
  const days = Math.round(hours / 24);
  if (days < 30) return `${days} g fa`;
  const months = Math.round(days / 30);
  return `${months} mesi fa`;
}

export function formatAvg(value: number | null): string {
  if (value === null) return "—";
  return value.toFixed(1).replace(".", ",");
}

export const AVATAR_CHOICES = [
  "🦸",
  "🕷️",
  "⚡",
  "💀",
  "🛡️",
  "🔮",
  "🐆",
  "🚀",
  "🐺",
  "💥",
  "🔥",
  "🧬",
  "🐜",
  "🌌",
  "🤖",
  "🎯",
];

export const SAGA_ORDER = ["MCU", "X-MEN", "SONY", "FOX"] as const;

export const PHASE_LABELS: Record<number, string> = {
  1: "Fase 1",
  2: "Fase 2",
  3: "Fase 3",
  4: "Fase 4",
  5: "Fase 5",
  6: "Fase 6",
};

export const DOOMSDAY_DATE = "2026-12-18T09:00:00.000Z";
