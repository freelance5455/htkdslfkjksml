"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { buildState } from "./engine";
import { getLocal, listLocal } from "./local-store";
import { getCompetition, saveCompetition } from "./competition-store";
import {
  computeLeaderboards,
  computeStandings,
  resultFromMatch,
  type Competition,
  type CompResult,
  type Fixture,
  type Standing,
} from "./competition";
import type { MatchState } from "./types";

/**
 * Loads a competition together with the live state of every match that has
 * been scored for it.
 *
 * The scoring engine stays the single source of truth: match states are
 * replayed from their recorded events and the competition layer only derives
 * standings, NRR, leaderboards and knockout progression from them.
 */
export function useCompetition(id: string, intervalMs = 4000) {
  const [comp, setComp] = useState<Competition | null>(null);
  const [states, setStates] = useState<Map<string, MatchState>>(new Map());
  const [loading, setLoading] = useState(true);
  const busy = useRef(false);

  const load = useCallback(async () => {
    if (busy.current) return;
    const c = await getCompetition(id);
    if (!c) {
      setComp(null);
      setLoading(false);
      return;
    }

    // Replay every linked match through the engine.
    const locals = await listLocal();
    const byId = new Map(locals.map((m) => [m.id, m]));
    const next = new Map<string, MatchState>();
    for (const f of c.fixtures) {
      if (!f.matchId) continue;
      const rec = byId.get(f.matchId) ?? (await getLocal(f.matchId));
      if (rec) next.set(f.id, buildState(rec.setup, rec.events, rec.awards));
    }

    // Keep cached fixture status/result in step with the engine.
    let changed = false;
    const fixtures = c.fixtures.map((f) => {
      const st = next.get(f.id);
      if (!st) return f;
      const status: Fixture["status"] = st.status === "completed" ? "completed" : "live";
      const winnerTeamId =
        st.winner != null
          ? (c.teams.find((t) => t.name === st.winner)?.id ?? null)
          : null;
      if (f.status !== status || f.resultText !== (st.result ?? undefined)) {
        changed = true;
        return { ...f, status, resultText: st.result ?? undefined, winnerTeamId };
      }
      return f;
    });

    const advanced = advanceKnockout({ ...c, fixtures }, next);
    if (changed || advanced.changed) {
      const saved = await saveCompetition({ ...c, fixtures: advanced.fixtures });
      setComp(saved);
    } else {
      setComp(c);
    }
    setStates(next);
    setLoading(false);
  }, [id]);

  useEffect(() => {
    void load();
    const t = setInterval(() => void load(), intervalMs);
    return () => clearInterval(t);
  }, [load, intervalMs]);

  const update = useCallback(
    async (patch: Partial<Competition>) => {
      busy.current = true;
      try {
        const current = await getCompetition(id);
        if (!current) return;
        const saved = await saveCompetition({ ...current, ...patch });
        setComp(saved);
      } finally {
        busy.current = false;
      }
    },
    [id],
  );

  /** Completed-match results keyed by fixture id. */
  const results = new Map<string, CompResult>();
  if (comp) {
    const nameToId: Record<string, string> = {};
    for (const t of comp.teams) nameToId[t.name] = t.id;
    for (const f of comp.fixtures) {
      const st = states.get(f.id);
      if (!st || !f.teamAId || !f.teamBId) continue;
      const r = resultFromMatch(st, f.teamAId, f.teamBId, nameToId, f.overs);
      if (r) results.set(f.id, r);
    }
  }

  const standings: Standing[] = comp ? computeStandings(comp, results) : [];
  const leaderboards = computeLeaderboards([...states.values()]);

  return { comp, states, results, standings, leaderboards, loading, update, reload: load };
}

/**
 * Fills knockout slots once the feeding matches are decided.
 *
 * Group qualifiers come from the group standings; later rounds take the
 * winner of each preceding tie. Runs on every load so the bracket stays
 * correct without any manual step.
 */
function advanceKnockout(
  comp: Competition,
  states: Map<string, MatchState>,
): { fixtures: Fixture[]; changed: boolean } {
  const fixtures = comp.fixtures.map((f) => ({ ...f }));
  let changed = false;

  const groupFixtures = fixtures.filter((f) => f.round.startsWith("Group"));
  const knockout = fixtures.filter((f) => !f.round.startsWith("Group"));
  if (knockout.length === 0) return { fixtures, changed };

  // Resolve "1st Group A" style placeholders from the group tables.
  const allGroupsDone =
    groupFixtures.length > 0 && groupFixtures.every((f) => f.status === "completed");

  if (allGroupsDone) {
    const results = new Map<string, CompResult>();
    const nameToId: Record<string, string> = {};
    for (const t of comp.teams) nameToId[t.name] = t.id;
    for (const f of groupFixtures) {
      const st = states.get(f.id);
      if (!st || !f.teamAId || !f.teamBId) continue;
      const r = resultFromMatch(st, f.teamAId, f.teamBId, nameToId, f.overs);
      if (r) results.set(f.id, r);
    }
    const table = computeStandings(comp, results);
    const byGroup = new Map<string, string[]>();
    for (const row of table) {
      const g = row.group ?? "A";
      const list = byGroup.get(g) ?? [];
      list.push(row.teamId);
      byGroup.set(g, list);
    }

    for (const f of knockout) {
      for (const side of ["A", "B"] as const) {
        const key = side === "A" ? "teamAId" : "teamBId";
        const ph = side === "A" ? f.teamAPlaceholder : f.teamBPlaceholder;
        if (f[key] || !ph) continue;
        const m = /^(\d+)\w\w Group (\w+)$/.exec(ph);
        if (!m) continue;
        const pos = Number(m[1]) - 1;
        const ids = byGroup.get(m[2]);
        const teamId = ids?.[pos];
        if (teamId) {
          f[key] = teamId;
          changed = true;
        }
      }
    }
  }

  // Feed winners forward through the bracket.
  const rounds = [...new Set(knockout.map((f) => f.round))];
  for (const round of rounds) {
    const inRound = knockout.filter((f) => f.round === round);
    inRound.forEach((f, idx) => {
      const winner = f.winnerTeamId;
      if (!winner || f.status !== "completed") return;
      const label = `Winner ${round} ${idx + 1}`;
      for (const nf of knockout) {
        if (nf.teamAPlaceholder === label && !nf.teamAId) {
          nf.teamAId = winner;
          changed = true;
        }
        if (nf.teamBPlaceholder === label && !nf.teamBId) {
          nf.teamBId = winner;
          changed = true;
        }
      }
    });
  }

  return { fixtures, changed };
}
