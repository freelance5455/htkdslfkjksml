import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import type { AskMode } from "@/lib/ask";

export type Role = "user" | "assistant";

export type ChatMessage = {
  id: string;
  role: Role;
  content: string;
  createdAt: number;
};

export type Thread = {
  id: string;
  title: string;
  projectId: string | null;
  pinned: boolean;
  updatedAt: number;
  messages: ChatMessage[];
};

export type Project = { id: string; name: string };

function uid() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}

type StudioState = {
  threads: Thread[];
  projects: Project[];
  activeId: string | null;
  mode: AskMode;
  sidebarCollapsed: boolean;
  projectFilter: string | null;
  hydrated: boolean;
  setHydrated: () => void;
  setMode: (mode: AskMode) => void;
  setSidebarCollapsed: (value: boolean) => void;
  setProjectFilter: (id: string | null) => void;
  setActive: (id: string | null) => void;
  newChat: () => string;
  addProject: (name: string) => void;
  renameThread: (id: string, title: string) => void;
  togglePin: (id: string) => void;
  deleteThread: (id: string) => void;
  assignProject: (threadId: string, projectId: string | null) => void;
  sendLocal: (text: string) => { threadId: string; messages: { role: Role; content: string }[] } | null;
  completeReply: (threadId: string, text: string) => void;
  dropLastUser: (threadId: string) => void;
};

const seedProjects: Project[] = [
  { id: "writing", name: "Writing desk" },
  { id: "research", name: "Research" },
  { id: "product", name: "Product" },
];

export const useStudio = create<StudioState>()(
  persist(
    (set, get) => ({
      threads: [],
      projects: seedProjects,
      activeId: null,
      mode: "studio",
      sidebarCollapsed: false,
      projectFilter: null,
      hydrated: false,
      setHydrated: () => set({ hydrated: true }),
      setMode: (mode) => set({ mode }),
      setSidebarCollapsed: (sidebarCollapsed) => set({ sidebarCollapsed }),
      setProjectFilter: (projectFilter) => set({ projectFilter }),
      setActive: (activeId) => set({ activeId }),
      newChat: () => {
        const id = uid();
        const thread: Thread = {
          id,
          title: "New chat",
          projectId: get().projectFilter,
          pinned: false,
          updatedAt: Date.now(),
          messages: [],
        };
        set({ threads: [thread, ...get().threads], activeId: id });
        return id;
      },
      addProject: (name) => {
        const trimmed = name.trim();
        if (!trimmed) return;
        const project = { id: uid(), name: trimmed.slice(0, 40) };
        set({ projects: [...get().projects, project], projectFilter: project.id });
      },
      renameThread: (id, title) => {
        const trimmed = title.trim().slice(0, 80);
        if (!trimmed) return;
        set({
          threads: get().threads.map((thread) => (thread.id === id ? { ...thread, title: trimmed } : thread)),
        });
      },
      togglePin: (id) => {
        set({
          threads: get().threads.map((thread) =>
            thread.id === id ? { ...thread, pinned: !thread.pinned } : thread,
          ),
        });
      },
      deleteThread: (id) => {
        const threads = get().threads.filter((thread) => thread.id !== id);
        const activeId = get().activeId === id ? (threads[0]?.id ?? null) : get().activeId;
        set({ threads, activeId });
      },
      assignProject: (threadId, projectId) => {
        set({
          threads: get().threads.map((thread) =>
            thread.id === threadId ? { ...thread, projectId } : thread,
          ),
        });
      },
      sendLocal: (text) => {
        const trimmed = text.trim();
        if (!trimmed) return null;
        let threadId = get().activeId;
        let threads = get().threads;
        if (!threadId || !threads.some((thread) => thread.id === threadId)) {
          threadId = uid();
          const created: Thread = {
            id: threadId,
            title: trimmed.slice(0, 48),
            projectId: get().projectFilter,
            pinned: false,
            updatedAt: Date.now(),
            messages: [],
          };
          threads = [created, ...threads];
        }

        const message: ChatMessage = {
          id: uid(),
          role: "user",
          content: trimmed,
          createdAt: Date.now(),
        };

        threads = threads.map((thread) => {
          if (thread.id !== threadId) return thread;
          const title = thread.messages.length === 0 ? trimmed.slice(0, 48) : thread.title;
          return {
            ...thread,
            title,
            updatedAt: Date.now(),
            messages: [...thread.messages, message],
          };
        });

        set({ threads, activeId: threadId });
        const thread = threads.find((item) => item.id === threadId);
        return {
          threadId: threadId!,
          messages: (thread?.messages ?? []).map((item) => ({ role: item.role, content: item.content })),
        };
      },
      completeReply: (threadId, text) => {
        set({
          threads: get().threads.map((thread) =>
            thread.id === threadId
              ? {
                  ...thread,
                  updatedAt: Date.now(),
                  messages: [
                    ...thread.messages,
                    { id: uid(), role: "assistant", content: text, createdAt: Date.now() },
                  ],
                }
              : thread,
          ),
        });
      },
      dropLastUser: (threadId) => {
        set({
          threads: get().threads.map((thread) => {
            if (thread.id !== threadId) return thread;
            const messages = [...thread.messages];
            const last = messages[messages.length - 1];
            if (last?.role === "user") messages.pop();
            return { ...thread, messages, title: messages.length ? thread.title : "New chat" };
          }),
        });
      },
    }),
    {
      name: "alder-pro",
      skipHydration: true,
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        threads: state.threads,
        projects: state.projects,
        activeId: state.activeId,
        mode: state.mode,
        sidebarCollapsed: state.sidebarCollapsed,
        projectFilter: state.projectFilter,
      }),
      onRehydrateStorage: () => (state) => {
        state?.setHydrated();
      },
    },
  ),
);
