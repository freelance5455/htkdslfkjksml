const DIGITS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const SUP = "⁰¹²³⁴⁵⁶⁷⁸⁹";

export const BASE_MIN = 2;
export const BASE_MAX = 36;

export function clampBase(value: number): number {
  if (!Number.isInteger(value)) return BASE_MIN;
  return Math.min(BASE_MAX, Math.max(BASE_MIN, value));
}

export function digitAlphabet(base: number): string {
  return DIGITS.slice(0, clampBase(base));
}

/** Integer written in `base` (2–36). Zero is "0"; negatives keep a leading minus. */
export function toBase(value: number, base: number): string {
  const radix = clampBase(base);
  if (!Number.isFinite(value)) return "0";
  const n = Math.trunc(value);
  if (n === 0) return "0";
  const negative = n < 0;
  let rest = Math.abs(n);
  let out = "";
  while (rest > 0) {
    out = DIGITS[rest % radix] + out;
    rest = Math.floor(rest / radix);
  }
  return negative ? `-${out}` : out;
}

/** Parse a base-N numeral. Returns null when a digit does not belong to that base. */
export function fromBase(text: string, base: number): number | null {
  if (!Number.isInteger(base) || base < BASE_MIN || base > BASE_MAX) return null;
  const raw = text.trim().toUpperCase();
  if (!raw) return null;
  const negative = raw.startsWith("-");
  const body = negative ? raw.slice(1) : raw;
  if (!body) return null;
  let value = 0;
  for (const char of body) {
    const digit = DIGITS.indexOf(char);
    if (digit < 0 || digit >= base) return null;
    value = value * base + digit;
  }
  return negative ? -value : value;
}

function superscript(n: number): string {
  return String(n)
    .split("")
    .map((d) => SUP[Number(d)] ?? "")
    .join("");
}

/** Place-value reading, e.g. base 6 value 11 (written 15) → "1×6¹ + 5×6⁰". */
export function placeValue(value: number, base: number): string {
  const radix = clampBase(base);
  const n = Math.trunc(value);
  if (n === 0) return "0";
  const negative = n < 0;
  let rest = Math.abs(n);
  const parts: string[] = [];
  let power = 0;
  while (rest > 0) {
    const digit = rest % radix;
    if (digit !== 0) {
      const glyph = DIGITS[digit];
      parts.push(power === 0 ? `${glyph}×${radix}${superscript(0)}` : `${glyph}×${radix}${superscript(power)}`);
    }
    rest = Math.floor(rest / radix);
    power += 1;
  }
  const expr = parts.reverse().join(" + ");
  return negative ? `−(${expr})` : expr;
}
