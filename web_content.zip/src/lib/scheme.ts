export interface SchoolInfo {
  ministry: string;
  school: string;
  teacher: string;
  subject: string;
  className: string;
  term: string;
  year: string;
  department: string;
  weeks: number;
  startDate: string;
}

export interface Topic {
  id: string;
  number: string;
  name: string;
  subtopics: string;
  competencies: string;
  outcomes: string;
  activities: string;
  aids: string;
  references: string;
  unsorted: string;
  selected: boolean;
}

export type RowKind = "teach" | "midterm" | "endterm" | "consolidation";

export interface WeekRow {
  id: string;
  week: number;
  date: string;
  weekText: string;
  topic: string;
  subtopic: string;
  competencies: string;
  activities: string;
  expected: string;
  methodology: string;
  aids: string;
  kind: RowKind;
  selected: boolean;
}

export interface Unit {
  topic: string;
  subtopic: string;
  competencies: string;
  outcomes: string;
  activities: string;
  aids: string;
  references: string;
  methodology: string;
}

export interface SchemeDocument {
  id: string;
  name: string;
  info: SchoolInfo;
  topics: Topic[];
  rows: WeekRow[];
  mode: "my-scheme" | "custom";
  updatedAt: string;
  notice: string;
  originalText: string;
}

export interface StoreShape {
  info: SchoolInfo;
  topics: Topic[];
  current: SchemeDocument | null;
  saved: SchemeDocument[];
  syllabusText: string;
  schemeText: string;
}

export const TEACHING_WEEKS = [1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12] as const;
export const HOMEWORK_WEEKS = [2, 4, 6, 8, 10, 12] as const;

export const COLUMNS: { key: keyof WeekRow; label: string }[] = [
  { key: "weekText", label: "Week / Date of Week Beginning" },
  { key: "topic", label: "Topic" },
  { key: "subtopic", label: "Subtopic" },
  { key: "competencies", label: "Specific Competencies" },
  { key: "activities", label: "Learning Activities" },
  { key: "expected", label: "Expected Standard" },
  { key: "methodology", label: "Lesson Methodology" },
  { key: "aids", label: "T/L Aids and References" },
];

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const STORE_KEY = "my-scheme-generator-v1";

const METHODS = [
  "Teacher exposition; Question and answer; Individual work",
  "Demonstration; Guided practice; Pair work",
  "Discussion; Group work; Individual work",
  "Question and answer; Pair work; Written exercise",
  "Teacher exposition; Demonstration; Group work",
  "Guided discovery; Discussion; Individual work",
];

export function uid(): string {
  return Math.random().toString(36).slice(2, 10) + Math.random().toString(36).slice(2, 6);
}

export function defaultInfo(): SchoolInfo {
  return {
    ministry: "MINISTRY OF EDUCATION",
    school: "",
    teacher: "",
    subject: "",
    className: "",
    term: "",
    year: "2026",
    department: "",
    weeks: 13,
    startDate: "",
  };
}

export function blankTopic(): Topic {
  return {
    id: uid(),
    number: "",
    name: "",
    subtopics: "",
    competencies: "",
    outcomes: "",
    activities: "",
    aids: "",
    references: "",
    unsorted: "",
    selected: true,
  };
}

export function sampleMathTopics(): Topic[] {
  return [
    {
      id: uid(),
      number: "1",
      name: "Coordinate geometry",
      subtopics: "The Cartesian plane\nPlotting and reading coordinates",
      competencies: "",
      outcomes: "",
      activities: "",
      aids: "",
      references: "",
      unsorted: "",
      selected: true,
    },
    {
      id: uid(),
      number: "2",
      name: "Straight line graphs",
      subtopics: "Gradient of a straight line",
      competencies: "",
      outcomes: "",
      activities: "",
      aids: "",
      references: "",
      unsorted: "",
      selected: true,
    },
    {
      id: uid(),
      number: "3",
      name: "Functions",
      subtopics: "Function notation\nEvaluating a function",
      competencies: "",
      outcomes: "",
      activities: "",
      aids: "",
      references: "",
      unsorted: "",
      selected: true,
    },
  ];
}

function isMath(subject: string): boolean {
  return /math|numeracy/i.test(subject);
}

export function addDays(iso: string, days: number): string {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
  if (!match) return "";
  const date = new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
  date.setDate(date.getDate() + days);
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${date.getFullYear()}-${month}-${day}`;
}

export function formatDMY(iso: string): string {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
  if (!match) return "";
  return `${Number(match[3])} ${MONTHS[Number(match[2]) - 1]} ${match[1]}`;
}

export function formatStamp(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  return `${date.getDate()} ${MONTHS[date.getMonth()]} ${date.getFullYear()}`;
}

export function schemeName(info: SchoolInfo): string {
  const bits = [info.subject.trim(), info.className.trim(), info.term.trim() ? `Term ${info.term.trim()}` : "", info.year.trim()].filter(Boolean);
  return bits.join(" · ") || "Untitled scheme";
}

function clampWeeks(value: number): number {
  if (!Number.isFinite(value)) return 13;
  return Math.min(20, Math.max(1, Math.round(value)));
}

function uniqueJoin(parts: string[], sep: string): string {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const part of parts) {
    const text = part.trim();
    if (!text || seen.has(text)) continue;
    seen.add(text);
    out.push(text);
  }
  return out.join(sep);
}

function splitSubs(raw: string): string[] {
  const lines = raw.split(/\n/).map((line) => line.trim()).filter(Boolean);
  if (lines.length === 1 && lines[0].includes(";")) {
    return lines[0].split(";").map((line) => line.trim()).filter(Boolean);
  }
  return lines;
}

export function topicsToUnits(topics: Topic[]): Unit[] {
  const list = topics.filter((topic) => topic.selected && topic.name.trim());
  const units: Unit[] = [];
  for (const topic of list) {
    const subs = splitSubs(topic.subtopics);
    const base = {
      topic: topic.name.trim(),
      competencies: topic.competencies,
      outcomes: topic.outcomes,
      activities: topic.activities,
      aids: topic.aids,
      references: topic.references,
      methodology: "",
    };
    if (subs.length === 0) units.push({ ...base, subtopic: "" });
    else for (const subtopic of subs) units.push({ ...base, subtopic });
  }
  return units;
}

export function rowsToUnits(rows: WeekRow[]): Unit[] {
  return rows
    .filter((row) => row.selected !== false)
    .filter((row) => row.kind !== "midterm" && row.kind !== "endterm")
    .filter((row) => !/mid-?term test|end-of-term|end of term/i.test(row.topic))
    .filter((row) => row.topic.trim() || row.subtopic.trim() || row.competencies.trim())
    .map((row) => ({
      topic: row.topic.trim(),
      subtopic: row.subtopic.trim(),
      competencies: row.competencies,
      outcomes: row.expected,
      activities: stripHomework(row.activities),
      aids: row.aids,
      references: "",
      methodology: row.methodology,
    }));
}

function suggestCompetency(unit: Unit): string {
  const focus = unit.subtopic || unit.topic || "the lesson";
  return `Suggested competency (editable — not official syllabus wording): Demonstrate understanding of ${focus} through correct working and accurate answers.`;
}

function suggestStandard(topic: string, subtopic: string): string {
  const focus = (subtopic || topic).replace(/\s+/g, " ").trim();
  const lower = focus.toLowerCase();
  let statement = `show understanding of ${lower || "the lesson"} by working examples correctly`;
  if (/cartesian|coordinate/.test(lower)) statement = "identify and plot coordinates on a Cartesian plane";
  else if (/gradient/.test(lower)) statement = "calculate the gradient of a straight line";
  else if (/function/.test(lower)) statement = "solve simple problems involving functions";
  else if (/equation/.test(lower)) statement = "solve simple equations and check the answers";
  else if (/fraction/.test(lower)) statement = "work with fractions accurately in simple problems";
  else if (/percent/.test(lower)) statement = "calculate percentages in everyday problems";
  else if (/bearing/.test(lower)) statement = "find and draw three-figure bearings";
  else if (/angle|geometr|triangle|circle/.test(lower)) statement = "find unknown angles and give reasons";
  else if (/area|perimeter|volume|mensuration/.test(lower)) statement = "calculate area, perimeter or volume using the correct units";
  else if (/probab/.test(lower)) statement = "find simple probabilities from a given situation";
  else if (/statistic|mean|median|chart|data/.test(lower)) statement = "read, organise and interpret simple data";
  else if (/algebra|simplif|expand|factor/.test(lower)) statement = "simplify algebraic expressions and show clear working";
  else if (/ratio/.test(lower)) statement = "solve simple problems involving ratio";
  else if (/indices|index laws|exponent/.test(lower)) statement = "apply the laws of indices in simple expressions";
  else if (/graph|linear/.test(lower)) statement = "draw and interpret the graph for this topic";
  return `Suggested standard (editable — not official syllabus wording): Learners should be able to ${statement}.`;
}

function suggestActivities(focus: string, slot: number, math: boolean): string {
  const item = focus.trim() || "the topic";
  const book = math ? "Mathematics textbook" : "class textbook";
  const sets = [
    [
      `Teacher demonstrates ${item} on the chalkboard with one worked example.`,
      "Learners answer oral questions to show they followed the example.",
      "Guided practice: learners work two examples with the teacher.",
      `Individual written exercise from the ${book}.`,
    ],
    [
      `Teacher exposition linking ${item} to work learners already know.`,
      "Pair work: each pair solves a short problem and explains the method.",
      "Classroom discussion of common mistakes.",
      "Individual exercise while the teacher helps learners who are stuck.",
    ],
    [
      `Demonstration of ${item}, then learners repeat the method.`,
      "Group work: groups solve a set of questions and compare answers.",
      "One learner from each group reports the method used.",
      "Short written exercise to close the lesson.",
    ],
    [
      `Question and answer to revise the key idea of ${item}.`,
      "Teacher works one harder example slowly on the chalkboard.",
      "Learners complete a graded exercise, starting with easier questions.",
      "Pairs discuss one solution before the books are handed in.",
    ],
  ];
  return sets[slot % sets.length].join("\n");
}

function suggestAids(focus: string, subject: string): string {
  const math = isMath(subject) || /coordinate|gradient|algebra|fraction|graph|angle|function/i.test(focus);
  const lower = focus.toLowerCase();
  const aids = new Set<string>(["Chalkboard and chalk", math ? "Mathematics textbook" : "Approved class textbook", "Exercise books"]);
  if (/graph|coordinate|cartesian|gradient|function|linear/.test(lower)) {
    aids.add("Graph paper");
    aids.add("Ruler");
    aids.add("Coordinate grid chart");
  }
  if (/angle|circle|construct|geometr|bearing|triangle/.test(lower)) {
    aids.add("Mathematical set (ruler, compass and protractor)");
  }
  if (/statistic|data|chart/.test(lower)) aids.add("Chart paper");
  if (/fraction|count|place value|number/.test(lower)) aids.add("Counters or bottle tops");
  const reference = math ? "Mathematics syllabus and the class textbook" : "The subject syllabus and the class textbook";
  return `${[...aids].join("; ")}. References: ${reference}; teacher's prepared notes.`;
}

function homeworkSentence(week: number, focus: string): string {
  const what = focus.trim() || "the work covered in the last two weeks";
  if (week === 6) {
    return `Homework (after Week 6): Revise the work from Weeks 1 to 5 (${what}). Attempt the practice questions set by the teacher. This homework follows the midterm checkpoint. Submit it at the next lesson.`;
  }
  if (week === 12) {
    return `Homework (after Week 12): Complete the practice exercises on ${what}. This homework is given after Week 12 and must not be left out. Submit it before end-of-term activities.`;
  }
  return `Homework (after Week ${week}): Complete the practice exercises on ${what}. Show all working neatly in your exercise book and submit it at the next lesson.`;
}

export function stripHomework(activities: string): string {
  return activities.replace(/\n*Homework \(after Week \d+\):[\s\S]*$/i, "").trim();
}

function withHomework(activities: string, week: number, focus: string, enabled: boolean): string {
  const base = stripHomework(activities);
  if (!enabled || week < 2 || week % 2 !== 0) return base;
  const line = homeworkSentence(week, focus);
  return base ? `${base}\n\n${line}` : line;
}

function focusBetween(labels: Map<number, string>, week: number): string {
  const start = week === 6 ? 1 : Math.max(1, week - 1);
  const end = week === 6 ? 5 : week;
  const parts: string[] = [];
  for (let index = start; index <= end; index += 1) {
    const label = labels.get(index);
    if (label) parts.push(label);
  }
  return uniqueJoin(parts, "; ");
}

function weekTextFor(week: number, startDate: string): { date: string; weekText: string } {
  if (!startDate) return { date: "", weekText: `Week ${week}` };
  const date = formatDMY(addDays(startDate, (week - 1) * 7));
  return { date, weekText: date ? `Week ${week}\n${date}` : `Week ${week}` };
}

function emptyRow(week: number, startDate: string, kind: RowKind): WeekRow {
  const stamped = weekTextFor(week, startDate);
  return {
    id: uid(),
    week,
    date: stamped.date,
    weekText: stamped.weekText,
    topic: "",
    subtopic: "",
    competencies: "",
    activities: "",
    expected: "",
    methodology: "",
    aids: "",
    kind,
    selected: true,
  };
}

export function blankWeek(week: number): WeekRow {
  return emptyRow(week, "", "teach");
}

export function midtermRow(weekText: string, date: string): WeekRow {
  return {
    id: uid(),
    week: 6,
    date,
    weekText,
    topic: "MIDTERM TEST",
    subtopic: "No teaching subtopic. This week is reserved for the midterm test.",
    competencies: "Learners show what they understood from the work in Weeks 1 to 5.",
    activities: [
      "Week 6 is the midterm test only.",
      "Do not teach a new topic and do not give a normal teaching subtopic this week.",
      "Administer the midterm test on the work covered in Weeks 1 to 5.",
      "Collect the scripts for marking.",
    ].join("\n"),
    expected: "Learners complete the midterm test on the work from Weeks 1 to 5.",
    methodology: "Individual work under test conditions.",
    aids: "Midterm test paper; chalkboard and chalk; answer sheets or exercise books.",
    kind: "midterm",
    selected: true,
  };
}

export function endtermRow(weekText: string, date: string): WeekRow {
  return {
    id: uid(),
    week: 13,
    date,
    weekText,
    topic: "END-OF-TERM ACTIVITIES / TEST",
    subtopic: "No normal teaching topic unless you edit this cell yourself.",
    competencies: "Learners show the standard they have reached by the end of the term.",
    activities: [
      "Week 13 is for end-of-term activities and the end-of-term test.",
      "Do not start a normal new topic unless you choose to change this cell.",
      "Learners write the end-of-term test.",
      "Mark the scripts, record the results, and give brief feedback if time allows.",
    ].join("\n"),
    expected: "Learners complete the end-of-term test and the closing activities for the term.",
    methodology: "Individual work; Teacher exposition for feedback.",
    aids: "End-of-term test paper; chalkboard and chalk; mark sheet; exercise books.",
    kind: "endterm",
    selected: true,
  };
}

function renderUnits(units: Unit[], slot: number, subject: string): Omit<WeekRow, "id" | "week" | "date" | "weekText" | "selected"> {
  const focus = uniqueJoin(units.map((unit) => unit.subtopic || unit.topic), "; ");
  const topic = uniqueJoin(units.map((unit) => unit.topic), "; ");
  const suppliedMethods = uniqueJoin(units.map((unit) => unit.methodology), "; ");
  return {
    topic,
    subtopic: uniqueJoin(units.map((unit) => unit.subtopic), "\n"),
    competencies: uniqueJoin(units.map((unit) => (unit.competencies.trim() ? unit.competencies.trim() : suggestCompetency(unit))), "\n"),
    activities: uniqueJoin(
      units.map((unit, index) => (unit.activities.trim() ? unit.activities.trim() : suggestActivities(unit.subtopic || unit.topic, slot + index, isMath(subject)))),
      "\n",
    ),
    expected: uniqueJoin(units.map((unit) => (unit.outcomes.trim() ? unit.outcomes.trim() : suggestStandard(unit.topic, unit.subtopic))), "\n"),
    methodology: suppliedMethods || METHODS[slot % METHODS.length],
    aids: uniqueJoin(
      units.map((unit) => {
        const bits = [unit.aids.trim(), unit.references.trim() ? `References: ${unit.references.trim()}` : ""].filter(Boolean);
        return bits.join("; ");
      }),
      "\n",
    ) || suggestAids(focus || topic, subject),
    kind: "teach",
  };
}

function consolidationRow(covered: string[], slot: number): Omit<WeekRow, "id" | "week" | "date" | "weekText" | "selected"> {
  const list = uniqueJoin(covered, "; ") || "the work already introduced";
  const styles = [
    {
      methodology: "Individual work; Pair work; Question and answer",
      activities: `Revision and mixed practice on: ${list}.\nThe teacher asks oral questions on the main ideas.\nLearners complete an individual exercise, then compare one solution with a partner.`,
    },
    {
      methodology: "Group work; Discussion; Teacher exposition",
      activities: `Group practice on: ${list}.\nEach group solves a short set of questions and explains the method.\nThe teacher corrects common errors on the chalkboard.`,
    },
    {
      methodology: "Demonstration; Guided practice; Individual work",
      activities: `The teacher demonstrates a harder example drawn from: ${list}.\nGuided practice follows the demonstration.\nLearners finish a written exercise on their own.`,
    },
  ];
  const style = styles[slot % styles.length];
  return {
    topic: "Practice and consolidation",
    subtopic: list,
    competencies: `Suggested competency (editable — not official syllabus wording): Apply the work already covered on ${list} to new practice questions.`,
    activities: style.activities,
    expected: `Suggested standard (editable — not official syllabus wording): Learners should be able to complete practice on ${list} with clear working.`,
    methodology: style.methodology,
    aids: suggestAids(list, ""),
    kind: "consolidation",
  };
}

function placeUnits(units: Unit[], weeks: number[]): Map<number, Unit[]> {
  const map = new Map<number, Unit[]>();
  for (const week of weeks) map.set(week, []);
  if (units.length === 0) return map;
  if (units.length <= weeks.length) {
    units.forEach((unit, index) => map.get(weeks[index])!.push(unit));
    return map;
  }
  const base = Math.floor(units.length / weeks.length);
  let extra = units.length % weeks.length;
  let cursor = 0;
  for (const week of weeks) {
    const take = base + (extra > 0 ? 1 : 0);
    if (extra > 0) extra -= 1;
    map.set(week, units.slice(cursor, cursor + take));
    cursor += take;
  }
  return map;
}

function labelOf(row: Pick<WeekRow, "topic" | "subtopic">): string {
  if (/practice and consolidation/i.test(row.topic)) return row.subtopic || row.topic;
  return [row.topic, row.subtopic].filter(Boolean).join(": ");
}

export function applyHomework(rows: WeekRow[], enabled = true): WeekRow[] {
  const labels = new Map<number, string>();
  for (const row of rows) {
    if (row.kind === "midterm" || row.kind === "endterm") continue;
    const label = labelOf(row);
    if (label) labels.set(row.week, label);
  }
  return rows.map((row) => ({
    ...row,
    activities: withHomework(row.activities, row.week, focusBetween(labels, row.week), enabled),
  }));
}

export function stampDates(rows: WeekRow[], startDate: string): WeekRow[] {
  if (!startDate) return rows;
  return rows.map((row) => {
    const stamped = weekTextFor(row.week, startDate);
    return { ...row, date: stamped.date, weekText: stamped.weekText };
  });
}

export interface GeneratedScheme {
  rows: WeekRow[];
  notice: string;
}

export function generateMyScheme(info: SchoolInfo, units: Unit[]): GeneratedScheme {
  const placed = placeUnits(units, [...TEACHING_WEEKS]);
  const covered: string[] = [];
  const draft: WeekRow[] = [];
  let slot = 0;
  let consolidations = 0;

  for (const week of TEACHING_WEEKS) {
    const group = placed.get(week) ?? [];
    const stamped = weekTextFor(week, info.startDate);
    if (group.length) {
      for (const unit of group) {
        const name = unit.subtopic ? `${unit.topic}: ${unit.subtopic}` : unit.topic;
        if (name) covered.push(name);
      }
      draft.push({
        id: uid(),
        week,
        date: stamped.date,
        weekText: stamped.weekText,
        selected: true,
        ...renderUnits(group, slot, info.subject),
      });
    } else if (covered.length) {
      draft.push({
        id: uid(),
        week,
        date: stamped.date,
        weekText: stamped.weekText,
        selected: true,
        ...consolidationRow(covered, consolidations),
      });
      consolidations += 1;
    } else {
      draft.push(emptyRow(week, info.startDate, "teach"));
    }
    slot += 1;
  }

  const week6 = weekTextFor(6, info.startDate);
  const week13 = weekTextFor(13, info.startDate);
  const rows = applyHomework(
    [...draft.filter((row) => row.week < 6), midtermRow(week6.weekText, week6.date), ...draft.filter((row) => row.week > 6), endtermRow(week13.weekText, week13.date)].sort(
      (a, b) => a.week - b.week,
    ),
    true,
  );

  const notices = [
    "MY SCHEME uses exactly 13 weeks. The eight columns stay in the set order. You can edit every cell.",
    "Week 6 is the midterm test only. Week 13 is end-of-term activities / test.",
    "Homework is written in Learning Activities after Weeks 2, 4, 6, 8, 10 and 12, including after Week 12.",
  ];
  if (units.length === 0) {
    notices.push("No topics were ticked, so the teaching weeks are blank for you to type. Nothing was invented.");
  } else {
    notices.push("Where a cell says “Suggested”, it is a draft for you to edit. It is not official syllabus wording.");
  }
  if (consolidations > 0) {
    notices.push("You had fewer topics than teaching weeks. Later weeks are practice and consolidation on your own topics. Change them if you want new work there.");
  }
  if (units.length > TEACHING_WEEKS.length) {
    notices.push("Some weeks contain more than one subtopic so that all of your topics fit into the 11 teaching weeks.");
  }
  return { rows, notice: notices.join(" ") };
}

export function generateCustomScheme(info: SchoolInfo, units: Unit[], homework: boolean): GeneratedScheme {
  const count = clampWeeks(info.weeks);
  const weeks = Array.from({ length: count }, (_, index) => index + 1);
  const placed = placeUnits(units, weeks);
  const rows = weeks.map((week, slot) => {
    const stamped = weekTextFor(week, info.startDate);
    const group = placed.get(week) ?? [];
    if (!group.length) return emptyRow(week, info.startDate, "teach");
    return {
      id: uid(),
      week,
      date: stamped.date,
      weekText: stamped.weekText,
      selected: true,
      ...renderUnits(group, slot, info.subject),
    };
  });
  return {
    rows: applyHomework(rows, homework),
    notice: homework
      ? `This scheme has ${count} weeks and the same eight columns. Homework sits in Learning Activities after every second week. Tick MY SCHEME rules if you want Week 6 kept for the midterm test and Week 13 for end-of-term work.`
      : `This scheme has ${count} weeks and the same eight columns. Homework was not added. You can type it into Learning Activities yourself.`,
  };
}

export function buildDocument(
  info: SchoolInfo,
  topics: Topic[],
  generated: GeneratedScheme,
  mode: SchemeDocument["mode"],
  originalText: string,
): SchemeDocument {
  return {
    id: uid(),
    name: schemeName(info),
    info: { ...info, weeks: mode === "my-scheme" ? 13 : clampWeeks(info.weeks) },
    topics: topics.map((topic) => ({ ...topic })),
    rows: generated.rows,
    mode,
    updatedAt: new Date().toISOString(),
    notice: generated.notice,
    originalText,
  };
}

export function documentFromRows(
  info: SchoolInfo,
  topics: Topic[],
  rows: WeekRow[],
  notice: string,
  originalText: string,
  mode: SchemeDocument["mode"],
): SchemeDocument {
  const normalised = rows.map((row, index) => ({
    ...row,
    id: row.id || uid(),
    week: row.week || index + 1,
    selected: true,
  }));
  return {
    id: uid(),
    name: schemeName(info),
    info,
    topics: topics.map((topic) => ({ ...topic })),
    rows: normalised,
    mode,
    updatedAt: new Date().toISOString(),
    notice,
    originalText,
  };
}

const SECTION_RULES: { re: RegExp; key: "competencies" | "outcomes" | "activities" | "aids" | "references" | "subtopics" }[] = [
  { re: /^specific competenc/i, key: "competencies" },
  { re: /^(?:key )?competen/i, key: "competencies" },
  { re: /^learning outcomes?/i, key: "outcomes" },
  { re: /^expected standards?/i, key: "outcomes" },
  { re: /^success criteria/i, key: "outcomes" },
  { re: /^(?:suggested )?(?:teaching and learning|learning|teaching) activities/i, key: "activities" },
  { re: /^(?:teaching and learning aids|t\/l aids|learning aids|teaching aids|teaching \/ learning aids|resources)/i, key: "aids" },
  { re: /^references?/i, key: "references" },
  { re: /^sub-?topics?/i, key: "subtopics" },
];

function matchSection(line: string): (typeof SECTION_RULES)[number]["key"] | null {
  const cleaned = line.replace(/[:.\-–—]+$/g, "").trim();
  if (cleaned.length > 64) return null;
  for (const rule of SECTION_RULES) {
    if (rule.re.test(cleaned)) return rule.key;
  }
  return null;
}

function matchTopic(line: string): { num: string; name: string } | null {
  const patterns = [
    /^(?:topic|unit|theme)\s+(\d+)\s*[:.\-–—]\s*(.+)$/i,
    /^(\d+)\.0\s+(.{2,120})$/,
    /^(\d+)\s*[:.\-–—]\s+([A-Za-z(].{1,120})$/,
  ];
  for (const pattern of patterns) {
    const match = line.match(pattern);
    if (!match) continue;
    const name = match[2].trim();
    if (name.length > 140) continue;
    if (/^\d/.test(name)) continue;
    return { num: match[1], name };
  }
  return null;
}

function matchSub(line: string): string | null {
  const numbered = line.match(/^(\d+\.\d+(?:\.\d+)?)\s+(.+)$/);
  if (numbered) return `${numbered[1]} ${numbered[2]}`.trim();
  const bullet = line.match(/^[•*\-–—]\s+(.+)$/);
  if (bullet) return bullet[1].trim();
  const letter = line.match(/^[a-z]\)\s+(.+)$/i);
  if (letter) return letter[1].trim();
  const roman = line.match(/^\([ivx]+\)\s+(.+)$/i);
  if (roman) return roman[1].trim();
  return null;
}

export function parseSyllabus(text: string): { topics: Topic[]; note: string } {
  const lines = text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  const topics: Topic[] = [];
  let current: Topic | null = null;
  let section: ReturnType<typeof matchSection> = null;

  const pushLoose = (line: string) => {
    if (!current) return;
    current.unsorted = current.unsorted ? `${current.unsorted}\n${line}` : line;
  };

  for (const line of lines) {
    const topic = matchTopic(line);
    if (topic && !matchSection(line)) {
      current = { ...blankTopic(), number: topic.num, name: topic.name };
      topics.push(current);
      section = null;
      continue;
    }
    const nextSection = matchSection(line);
    if (nextSection && current) {
      section = nextSection;
      continue;
    }
    if (!current) continue;
    if (section === "subtopics") {
      current.subtopics = current.subtopics ? `${current.subtopics}\n${matchSub(line) || line}` : matchSub(line) || line;
      continue;
    }
    if (section) {
      current[section] = current[section] ? `${current[section]}\n${line}` : line;
      continue;
    }
    const sub = matchSub(line);
    if (sub) current.subtopics = current.subtopics ? `${current.subtopics}\n${sub}` : sub;
    else pushLoose(line);
  }

  if (topics.length === 0) {
    const start = lines.findIndex((line) => /^topics?$/i.test(line.replace(/[:.\-–—]+$/g, "").trim()));
    if (start >= 0) {
      for (const line of lines.slice(start + 1)) {
        if (matchSection(line)) break;
        const topic = matchTopic(line);
        const name = topic?.name || matchSub(line) || line;
        if (name.length > 120) break;
        topics.push({ ...blankTopic(), number: topic?.num || String(topics.length + 1), name });
      }
    }
  }

  const note = topics.length
    ? `${topics.length} topic${topics.length === 1 ? "" : "s"} found. Tick the ones you want, and correct anything that was read wrongly. Nothing extra was added.`
    : "No topics were found in this text. The app has not invented any. Paste clearer text, or add topics yourself.";
  return { topics, note };
}

export function scrapeInfo(text: string): Partial<SchoolInfo> {
  const lines = text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  const grab = (pattern: RegExp): string => {
    for (const line of lines) {
      const match = line.match(pattern);
      if (!match?.[1]) continue;
      const value = match[1].trim().replace(/\s+/g, " ");
      if (value.length >= 2 && value.length <= 80) return value;
    }
    return "";
  };
  const patch: Partial<SchoolInfo> = {};
  const ministry = lines.find((line) => /^ministry of /i.test(line) && line.length <= 80);
  if (ministry) patch.ministry = ministry.replace(/\s+/g, " ");
  const school = grab(/^(?:name of school|school name|school)\s*[:\-–—]\s*(.+)$/i);
  if (school) patch.school = school;
  const teacher = grab(/^(?:teacher(?:'s)? name|teacher)\s*[:\-–—]\s*(.+)$/i);
  if (teacher && !/^name$/i.test(teacher)) patch.teacher = teacher;
  const subject = grab(/^subject\s*[:\-–—]\s*(.+)$/i);
  if (subject) patch.subject = subject;
  const className = grab(/^(?:class|grade|form)\s*[:\-–—]\s*(.+)$/i);
  if (className) patch.className = className;
  const term = grab(/^term\s*[:\-–—]\s*(.+)$/i);
  if (term) patch.term = term;
  const year = grab(/^year\s*[:\-–—]\s*(.+)$/i);
  if (year) patch.year = year;
  const department = grab(/^department\s*[:\-–—]\s*(.+)$/i);
  if (department) patch.department = department;
  return patch;
}

export function mergeInfo(base: SchoolInfo, patch: Partial<SchoolInfo>, keys: (keyof SchoolInfo)[]): SchoolInfo {
  const next = { ...base };
  for (const key of keys) {
    const value = patch[key];
    if (value === undefined || value === "") continue;
    if (key === "weeks") next.weeks = clampWeeks(Number(value));
    else next[key] = String(value);
  }
  return next;
}

type ColumnKey = "week" | "topic" | "subtopic" | "competencies" | "activities" | "expected" | "methodology" | "aids" | "homework";

function columnKey(header: string): ColumnKey | null {
  const text = header.toLowerCase().replace(/\s+/g, " ").trim();
  if (!text) return null;
  if (/homework/.test(text)) return "homework";
  if (/sub-?topic/.test(text)) return "subtopic";
  if (/competen/.test(text)) return "competencies";
  if (/activit/.test(text)) return "activities";
  if (/expected|standard|outcome/.test(text)) return "expected";
  if (/method/.test(text)) return "methodology";
  if (/aid|reference|resource/.test(text)) return "aids";
  if (/week|date/.test(text)) return "week";
  if (/topic|theme|unit/.test(text)) return "topic";
  return null;
}

function kindFromTopic(topic: string): RowKind {
  if (/mid-?term/i.test(topic)) return "midterm";
  if (/end-of-term|end of term/i.test(topic)) return "endterm";
  if (/consolidation/i.test(topic)) return "consolidation";
  return "teach";
}

export function parseDelimitedTable(text: string): string[][] {
  const lines = text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  if (lines.length < 2) return [];
  const pipes = lines.filter((line) => (line.match(/\|/g) || []).length >= 2).length;
  const tabs = lines.filter((line) => line.includes("\t")).length;
  const delim = pipes >= Math.min(3, lines.length) ? "|" : tabs >= Math.min(3, lines.length) ? "\t" : "";
  if (!delim) return [];
  return lines
    .map((line) => line.split(delim).map((cell) => cell.trim()).filter((_, index, all) => !(index === 0 && all[0] === "") && !(index === all.length - 1 && all[index] === "")))
    .filter((row) => row.filter(Boolean).length >= 2);
}

export interface InterpretedTable {
  rows: WeekRow[];
  topics: Topic[];
  note: string;
  hasWeekTable: boolean;
}

export function interpretTable(table: string[][]): InterpretedTable {
  if (table.length < 2) return { rows: [], topics: [], note: "", hasWeekTable: false };
  const header = table[0].map((cell) => columnKey(cell));
  const known = header.filter(Boolean).length;
  if (known < 2) return { rows: [], topics: [], note: "", hasWeekTable: false };

  const unused = table[0].filter((cell, index) => cell.trim() && !header[index]);
  const hasWeek = header.includes("week");
  const rows: WeekRow[] = [];
  const topicMap = new Map<string, Topic>();

  table.slice(1).forEach((cells, index) => {
    if (!cells.some((cell) => cell.trim())) return;
    const read = (key: ColumnKey) => {
      const at = header.indexOf(key);
      return at >= 0 ? (cells[at] || "").trim() : "";
    };
    const topicName = read("topic");
    const subtopic = read("subtopic");
    const homework = read("homework");
    let activities = read("activities");
    if (homework) activities = activities ? `${activities}\n\nHomework: ${homework}` : `Homework: ${homework}`;
    if (hasWeek || header.includes("topic")) {
      const weekCell = read("week");
      const weekMatch = weekCell.match(/week\s*(\d+)/i) || weekCell.match(/\b(\d{1,2})\b/);
      const week = weekMatch && Number(weekMatch[1]) <= 40 ? Number(weekMatch[1]) : index + 1;
      const dateMatch = weekCell.match(/(\d{1,2}\s+[A-Za-z]{3,9}\s+\d{4}|\d{1,2}[/-]\d{1,2}[/-]\d{2,4})/);
      rows.push({
        id: uid(),
        week,
        date: dateMatch ? dateMatch[1] : "",
        weekText: weekCell || `Week ${week}`,
        topic: topicName,
        subtopic,
        competencies: read("competencies"),
        activities,
        expected: read("expected"),
        methodology: read("methodology"),
        aids: read("aids"),
        kind: kindFromTopic(topicName),
        selected: true,
      });
    }
    if (topicName) {
      const key = topicName.toLowerCase();
      const existing = topicMap.get(key) || { ...blankTopic(), number: String(topicMap.size + 1), name: topicName };
      if (subtopic) existing.subtopics = existing.subtopics ? `${existing.subtopics}\n${subtopic}` : subtopic;
      if (!existing.competencies && read("competencies")) existing.competencies = read("competencies");
      if (!existing.outcomes && read("expected")) existing.outcomes = read("expected");
      if (!existing.activities && read("activities")) existing.activities = read("activities");
      if (!existing.aids && read("aids")) existing.aids = read("aids");
      topicMap.set(key, existing);
    }
  });

  const noteParts = [hasWeek ? "A scheme table was found." : "A topic table was found."];
  if (unused.length) noteParts.push(`These columns were kept in the original wording but not forced into the eight MY SCHEME columns: ${unused.join(", ")}.`);
  return { rows, topics: [...topicMap.values()], note: noteParts.join(" "), hasWeekTable: hasWeek && rows.length > 0 };
}

export function topicsFromRows(rows: WeekRow[]): Topic[] {
  return interpretTable([
    ["Week", "Topic", "Subtopic", "Specific Competencies", "Learning Activities", "Expected Standard", "Lesson Methodology", "T/L Aids and References"],
    ...rows.map((row) => [row.weekText, row.topic, row.subtopic, row.competencies, stripHomework(row.activities), row.expected, row.methodology, row.aids]),
  ]).topics;
}

export function escapeHtml(value: string): string {
  const amp = String.fromCharCode(38);
  return value
    .replaceAll(amp, `${amp}amp;`)
    .replaceAll("<", `${amp}lt;`)
    .replaceAll(">", `${amp}gt;`)
    .replaceAll('"', `${amp}quot;`);
}

function headingText(info: SchoolInfo): string {
  return [
    info.ministry.trim() || "MINISTRY OF EDUCATION",
    info.school.trim() || "",
    "SCHEME OF WORK",
    "",
    `Teacher: ${info.teacher}`,
    `Subject: ${info.subject}`,
    `Class: ${info.className}`,
    `Term: ${info.term}`,
    `Year: ${info.year}`,
    `Department: ${info.department}`,
  ].join("\n");
}

export function schemeToPlain(doc: SchemeDocument): string {
  const lines = [headingText(doc.info), ""];
  lines.push(COLUMNS.map((column) => column.label).join("\t"));
  for (const row of doc.rows) {
    lines.push(COLUMNS.map((column) => String(row[column.key] ?? "").replace(/\s+/g, " ").trim()).join("\t"));
  }
  return lines.join("\n");
}

export function schemeToCsv(doc: SchemeDocument): string {
  const cell = (value: string) => `"${value.replace(/"/g, '""')}"`;
  const lines = [COLUMNS.map((column) => cell(column.label)).join(",")];
  for (const row of doc.rows) lines.push(COLUMNS.map((column) => cell(String(row[column.key] ?? ""))).join(","));
  return lines.join("\n");
}

export function schemeToHtml(doc: SchemeDocument): string {
  const info = doc.info;
  const meta = [
    ["Teacher", info.teacher],
    ["Subject", info.subject],
    ["Class", info.className],
    ["Term", info.term],
    ["Year", info.year],
    ["Department", info.department],
  ];
  const body = doc.rows
    .map((row) => `<tr>${COLUMNS.map((column) => `<td>${escapeHtml(String(row[column.key] ?? "")).replace(/\n/g, "<br>")}</td>`).join("")}</tr>`)
    .join("");
  return `<div>
    <p style="text-align:center"><strong>${escapeHtml(info.ministry || "MINISTRY OF EDUCATION")}</strong></p>
    <p style="text-align:center"><strong>${escapeHtml(info.school || "")}</strong></p>
    <p style="text-align:center"><strong>SCHEME OF WORK</strong></p>
    <table style="margin:12px auto"><tbody>
      ${meta.map(([label, value]) => `<tr><td><strong>${label}:</strong> ${escapeHtml(value)}</td></tr>`).join("")}
    </tbody></table>
    <table border="1" cellspacing="0" cellpadding="4" style="border-collapse:collapse;width:100%">
      <thead><tr>${COLUMNS.map((column) => `<th>${escapeHtml(column.label)}</th>`).join("")}</tr></thead>
      <tbody>${body}</tbody>
    </table>
  </div>`;
}

export function schemeToWord(doc: SchemeDocument): string {
  return `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word"><head><meta charset="utf-8"><title>${escapeHtml(doc.name)}</title></head><body>${schemeToHtml(doc)}</body></html>`;
}

export function loadStore(): StoreShape | null {
  if (typeof localStorage === "undefined") return null;
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw) as Partial<StoreShape>;
    if (!data || typeof data !== "object") return null;
    return {
      info: { ...defaultInfo(), ...(data.info || {}) },
      topics: Array.isArray(data.topics) ? data.topics : [],
      current: data.current ?? null,
      saved: Array.isArray(data.saved) ? data.saved : [],
      syllabusText: typeof data.syllabusText === "string" ? data.syllabusText : "",
      schemeText: typeof data.schemeText === "string" ? data.schemeText : "",
    };
  } catch {
    return null;
  }
}

export function saveStore(store: StoreShape): boolean {
  try {
    const copy: StoreShape = {
      ...store,
      syllabusText: store.syllabusText.slice(0, 150000),
      schemeText: store.schemeText.slice(0, 150000),
    };
    localStorage.setItem(STORE_KEY, JSON.stringify(copy));
    return true;
  } catch {
    return false;
  }
}

export function safeFileName(info: SchoolInfo, ext: string): string {
  const base = schemeName(info).replace(/[^\w]+/g, "-").replace(/^-|-$/g, "") || "scheme-of-work";
  return `${base}.${ext}`;
}

export function selfCheck(): string[] {
  const errors: string[] = [];
  const info = { ...defaultInfo(), subject: "Mathematics", className: "Grade 10", startDate: "2026-01-12" };
  const generated = generateMyScheme(info, topicsToUnits(sampleMathTopics()));
  if (generated.rows.length !== 13) errors.push(`expected 13 rows, got ${generated.rows.length}`);
  const week6 = generated.rows.find((row) => row.week === 6);
  const week13 = generated.rows.find((row) => row.week === 13);
  if (!week6 || week6.topic !== "MIDTERM TEST") errors.push("week 6 topic");
  if (week6 && /Cartesian|Gradient|Function notation/i.test(week6.subtopic)) errors.push("week 6 has a teaching subtopic");
  if (!week13 || !week13.topic.includes("END-OF-TERM")) errors.push("week 13 topic");
  for (const week of HOMEWORK_WEEKS) {
    const row = generated.rows.find((item) => item.week === week);
    if (!row || !new RegExp(`Homework \\(after Week ${week}\\)`).test(row.activities)) errors.push(`missing homework ${week}`);
  }
  if (!/12 Jan 2026/.test(generated.rows[0]?.weekText || "")) errors.push("start date not stamped");
  const parsed = parseSyllabus(`1. Algebra\n1.1 Indices\nSpecific competencies\nApply the laws of indices\n2. Geometry\n2.1 Angles`);
  if (parsed.topics.length !== 2) errors.push(`parser topics ${parsed.topics.length}`);
  if (!/Indices/.test(parsed.topics[0]?.subtopics || "")) errors.push("parser subtopic");
  if (!/indices/i.test(parsed.topics[0]?.competencies || "")) errors.push("parser competency");
  const empty = generateMyScheme(info, []);
  if (empty.rows.filter((row) => row.kind === "teach" && row.topic).length !== 0) errors.push("invented topics");
  return errors;
}
