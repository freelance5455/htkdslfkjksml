export const NEXA_DATABASE_MIGRATION_SQL = `-- ==========================================================
-- NEXA MESSENGER COMPLETE PRODUCTION MIGRATION
-- Run this single coherent SQL script in the Supabase SQL Editor.
-- Idempotent and safe to run multiple times.
-- ==========================================================

-- Enable required extensions
create extension if not exists "uuid-ossp";
create extension if not exists "pgcrypto";

-- 1. PROFILES TABLE
create table if not exists public.profiles (
  id uuid references auth.users on delete cascade primary key,
  username text not null,
  display_name text not null,
  avatar_url text,
  bio text default '',
  last_seen timestamptz default now(),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Case-insensitive unique index on username
create unique index if not exists idx_profiles_username_lower on public.profiles (lower(username));
create index if not exists idx_profiles_last_seen on public.profiles (last_seen);

-- 2. FRIENDSHIPS TABLE
create table if not exists public.friendships (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  friend_id uuid references public.profiles(id) on delete cascade not null,
  created_at timestamptz default now() not null,
  unique(user_id, friend_id),
  constraint no_self_friend check (user_id <> friend_id)
);

create index if not exists idx_friendships_user on public.friendships (user_id);
create index if not exists idx_friendships_friend on public.friendships (friend_id);

-- 3. FRIEND REQUESTS TABLE
create table if not exists public.friend_requests (
  id uuid default gen_random_uuid() primary key,
  sender_id uuid references public.profiles(id) on delete cascade not null,
  receiver_id uuid references public.profiles(id) on delete cascade not null,
  status text not null default 'pending' check (status in ('pending', 'accepted', 'rejected', 'cancelled')),
  created_at timestamptz default now() not null,
  updated_at timestamptz default now() not null,
  unique(sender_id, receiver_id),
  constraint no_self_request check (sender_id <> receiver_id)
);

create index if not exists idx_friend_requests_receiver on public.friend_requests (receiver_id, status);
create index if not exists idx_friend_requests_sender on public.friend_requests (sender_id, status);

-- 4. BLOCKED USERS TABLE
create table if not exists public.blocked_users (
  id uuid default gen_random_uuid() primary key,
  blocker_id uuid references public.profiles(id) on delete cascade not null,
  blocked_id uuid references public.profiles(id) on delete cascade not null,
  created_at timestamptz default now() not null,
  unique(blocker_id, blocked_id),
  constraint no_self_block check (blocker_id <> blocked_id)
);

create index if not exists idx_blocked_users_blocker on public.blocked_users (blocker_id);
create index if not exists idx_blocked_users_blocked on public.blocked_users (blocked_id);

-- 5. CONVERSATIONS TABLE
create table if not exists public.conversations (
  id uuid default gen_random_uuid() primary key,
  type text not null default 'direct' check (type in ('direct', 'group')),
  created_at timestamptz default now() not null,
  updated_at timestamptz default now() not null
);

-- 6. CONVERSATION MEMBERS TABLE
create table if not exists public.conversation_members (
  id uuid default gen_random_uuid() primary key,
  conversation_id uuid references public.conversations(id) on delete cascade not null,
  user_id uuid references public.profiles(id) on delete cascade not null,
  cleared_at timestamptz,
  is_deleted boolean default false not null,
  is_pinned boolean default false not null,
  is_muted boolean default false not null,
  disappearing_duration text default 'off' check (disappearing_duration in ('off', '24h', '7d', '90d')),
  created_at timestamptz default now() not null,
  unique(conversation_id, user_id)
);

create index if not exists idx_conversation_members_user on public.conversation_members (user_id, is_deleted);
create index if not exists idx_conversation_members_conv on public.conversation_members (conversation_id);

-- 7. MESSAGES TABLE
create table if not exists public.messages (
  id uuid default gen_random_uuid() primary key,
  conversation_id uuid references public.conversations(id) on delete cascade not null,
  sender_id uuid references public.profiles(id) on delete set null,
  content text default '' not null,
  type text not null default 'text' check (type in ('text', 'image', 'video', 'file', 'voice', 'system')),
  file_name text,
  file_size bigint,
  mime_type text,
  media_path text,
  reply_to_id uuid references public.messages(id) on delete set null,
  is_view_once boolean default false not null,
  viewed_at timestamptz,
  is_edited boolean default false not null,
  is_deleted_everyone boolean default false not null,
  expires_at timestamptz,
  created_at timestamptz default now() not null,
  updated_at timestamptz default now() not null
);

create index if not exists idx_messages_conv_created on public.messages (conversation_id, created_at);
create index if not exists idx_messages_sender on public.messages (sender_id);
create index if not exists idx_messages_expires on public.messages (expires_at) where expires_at is not null;

-- 8. MESSAGE STATUS (Sent, Delivered, Read receipts)
create table if not exists public.message_status (
  id uuid default gen_random_uuid() primary key,
  message_id uuid references public.messages(id) on delete cascade not null,
  user_id uuid references public.profiles(id) on delete cascade not null,
  delivered_at timestamptz,
  read_at timestamptz,
  unique(message_id, user_id)
);

create index if not exists idx_message_status_lookup on public.message_status (message_id, user_id);

-- 9. MESSAGE REACTIONS TABLE
create table if not exists public.message_reactions (
  id uuid default gen_random_uuid() primary key,
  message_id uuid references public.messages(id) on delete cascade not null,
  user_id uuid references public.profiles(id) on delete cascade not null,
  emoji text not null,
  created_at timestamptz default now() not null,
  unique(message_id, user_id)
);

create index if not exists idx_reactions_message on public.message_reactions (message_id);

-- 10. SAVED / STARRED MESSAGES TABLE
create table if not exists public.message_saved (
  id uuid default gen_random_uuid() primary key,
  message_id uuid references public.messages(id) on delete cascade not null,
  user_id uuid references public.profiles(id) on delete cascade not null,
  created_at timestamptz default now() not null,
  unique(message_id, user_id)
);

create index if not exists idx_saved_messages_user on public.message_saved (user_id);

-- 11. MESSAGE DELETIONS FOR ME (Per-user delete)
create table if not exists public.message_deletions_for_me (
  id uuid default gen_random_uuid() primary key,
  message_id uuid references public.messages(id) on delete cascade not null,
  user_id uuid references public.profiles(id) on delete cascade not null,
  created_at timestamptz default now() not null,
  unique(message_id, user_id)
);

create index if not exists idx_msg_del_user on public.message_deletions_for_me (user_id);

-- 12. CALL HISTORY TABLE
create table if not exists public.call_history (
  id uuid default gen_random_uuid() primary key,
  caller_id uuid references public.profiles(id) on delete cascade not null,
  receiver_id uuid references public.profiles(id) on delete cascade not null,
  call_type text not null check (call_type in ('voice', 'video')),
  status text not null check (status in ('connected', 'missed', 'rejected', 'failed', 'cancelled')),
  duration_seconds integer default 0 not null,
  started_at timestamptz default now() not null,
  ended_at timestamptz,
  created_at timestamptz default now() not null
);

create index if not exists idx_call_history_caller on public.call_history (caller_id, created_at desc);
create index if not exists idx_call_history_receiver on public.call_history (receiver_id, created_at desc);

-- 13. CALL HISTORY DELETIONS FOR ME
create table if not exists public.call_history_deletions_for_me (
  id uuid default gen_random_uuid() primary key,
  call_id uuid references public.call_history(id) on delete cascade not null,
  user_id uuid references public.profiles(id) on delete cascade not null,
  created_at timestamptz default now() not null,
  unique(call_id, user_id)
);

create index if not exists idx_call_del_user on public.call_history_deletions_for_me (user_id);

-- 14. REPORTS TABLE
create table if not exists public.reports (
  id uuid default gen_random_uuid() primary key,
  reporter_id uuid references public.profiles(id) on delete cascade not null,
  reported_user_id uuid references public.profiles(id) on delete cascade not null,
  message_id uuid references public.messages(id) on delete set null,
  reason text not null,
  created_at timestamptz default now() not null
);

-- 15. USER SETTINGS TABLE
create table if not exists public.user_settings (
  user_id uuid references public.profiles(id) on delete cascade primary key,
  theme text default 'dark' not null check (theme in ('dark', 'light')),
  notifications_enabled boolean default true not null,
  read_receipts boolean default true not null,
  last_seen_privacy text default 'everyone' not null check (last_seen_privacy in ('everyone', 'friends', 'nobody')),
  updated_at timestamptz default now() not null
);

-- ==========================================================
-- STORAGE BUCKETS SETUP
-- ==========================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values 
  ('chat-media', 'chat-media', false, 52428800, null),
  ('avatars', 'avatars', true, 5242880, array['image/jpeg', 'image/png', 'image/webp', 'image/gif'])
on conflict (id) do nothing;

-- ==========================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ==========================================================
alter table public.profiles enable row level security;
alter table public.friendships enable row level security;
alter table public.friend_requests enable row level security;
alter table public.blocked_users enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.message_status enable row level security;
alter table public.message_reactions enable row level security;
alter table public.message_saved enable row level security;
alter table public.message_deletions_for_me enable row level security;
alter table public.call_history enable row level security;
alter table public.call_history_deletions_for_me enable row level security;
alter table public.reports enable row level security;
alter table public.user_settings enable row level security;

-- PROFILES POLICIES
drop policy if exists "Profiles are viewable by authenticated users" on public.profiles;
create policy "Profiles are viewable by authenticated users" 
  on public.profiles for select 
  to authenticated 
  using (true);

drop policy if exists "Users can update their own profile" on public.profiles;
create policy "Users can update their own profile" 
  on public.profiles for update 
  to authenticated 
  using (auth.uid() = id);

drop policy if exists "Users can insert their own profile" on public.profiles;
create policy "Users can insert their own profile" 
  on public.profiles for insert 
  to authenticated 
  with check (auth.uid() = id);

-- FRIENDSHIPS POLICIES
drop policy if exists "Users can view their friendships" on public.friendships;
create policy "Users can view their friendships" 
  on public.friendships for select 
  to authenticated 
  using (auth.uid() = user_id or auth.uid() = friend_id);

drop policy if exists "Users can remove their friendships" on public.friendships;
create policy "Users can remove their friendships" 
  on public.friendships for delete 
  to authenticated 
  using (auth.uid() = user_id or auth.uid() = friend_id);

drop policy if exists "Users can insert friendships" on public.friendships;
create policy "Users can insert friendships" 
  on public.friendships for insert 
  to authenticated 
  with check (auth.uid() = user_id or auth.uid() = friend_id);

-- FRIEND REQUESTS POLICIES
drop policy if exists "Users can view their friend requests" on public.friend_requests;
create policy "Users can view their friend requests" 
  on public.friend_requests for select 
  to authenticated 
  using (auth.uid() = sender_id or auth.uid() = receiver_id);

drop policy if exists "Users can create friend requests" on public.friend_requests;
create policy "Users can create friend requests" 
  on public.friend_requests for insert 
  to authenticated 
  with check (auth.uid() = sender_id);

drop policy if exists "Users can update their friend requests" on public.friend_requests;
create policy "Users can update their friend requests" 
  on public.friend_requests for update 
  to authenticated 
  using (auth.uid() = receiver_id or auth.uid() = sender_id);

drop policy if exists "Users can delete their friend requests" on public.friend_requests;
create policy "Users can delete their friend requests" 
  on public.friend_requests for delete 
  to authenticated 
  using (auth.uid() = sender_id or auth.uid() = receiver_id);

-- BLOCKED USERS POLICIES
drop policy if exists "Users can view their blocked users" on public.blocked_users;
create policy "Users can view their blocked users" 
  on public.blocked_users for select 
  to authenticated 
  using (auth.uid() = blocker_id);

drop policy if exists "Users can block users" on public.blocked_users;
create policy "Users can block users" 
  on public.blocked_users for insert 
  to authenticated 
  with check (auth.uid() = blocker_id);

drop policy if exists "Users can unblock users" on public.blocked_users;
create policy "Users can unblock users" 
  on public.blocked_users for delete 
  to authenticated 
  using (auth.uid() = blocker_id);

-- CONVERSATIONS & MEMBERS POLICIES
drop policy if exists "Members can view conversations" on public.conversations;
create policy "Members can view conversations" 
  on public.conversations for select 
  to authenticated 
  using (
    exists (
      select 1 from public.conversation_members 
      where conversation_id = public.conversations.id 
      and user_id = auth.uid()
    )
  );

drop policy if exists "Authenticated users can create conversations" on public.conversations;
create policy "Authenticated users can create conversations" 
  on public.conversations for insert 
  to authenticated 
  with check (true);

drop policy if exists "Members can view member records" on public.conversation_members;
create policy "Members can view member records" 
  on public.conversation_members for select 
  to authenticated 
  using (
    exists (
      select 1 from public.conversation_members as m 
      where m.conversation_id = public.conversation_members.conversation_id 
      and m.user_id = auth.uid()
    )
  );

drop policy if exists "Members can update their own member record" on public.conversation_members;
create policy "Members can update their own member record" 
  on public.conversation_members for update 
  to authenticated 
  using (user_id = auth.uid());

drop policy if exists "Users can insert member records" on public.conversation_members;
create policy "Users can insert member records" 
  on public.conversation_members for insert 
  to authenticated 
  with check (true);

-- MESSAGES POLICIES
drop policy if exists "Members can view non-expired messages" on public.messages;
create policy "Members can view non-expired messages" 
  on public.messages for select 
  to authenticated 
  using (
    exists (
      select 1 from public.conversation_members 
      where conversation_id = public.messages.conversation_id 
      and user_id = auth.uid()
    ) 
    and (expires_at is null or expires_at > now())
  );

drop policy if exists "Members can send messages" on public.messages;
create policy "Members can send messages" 
  on public.messages for insert 
  to authenticated 
  with check (
    sender_id = auth.uid() 
    and exists (
      select 1 from public.conversation_members 
      where conversation_id = public.messages.conversation_id 
      and user_id = auth.uid()
    )
  );

drop policy if exists "Senders can edit their messages" on public.messages;
create policy "Senders can edit their messages" 
  on public.messages for update 
  to authenticated 
  using (
    sender_id = auth.uid() 
    or exists (
      select 1 from public.conversation_members 
      where conversation_id = public.messages.conversation_id 
      and user_id = auth.uid()
    )
  );

-- MESSAGE STATUS POLICIES
drop policy if exists "Members can view message status" on public.message_status;
create policy "Members can view message status" 
  on public.message_status for select 
  to authenticated 
  using (true);

drop policy if exists "Users can insert/update their message status" on public.message_status;
create policy "Users can insert/update their message status" 
  on public.message_status for all 
  to authenticated 
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- MESSAGE REACTIONS POLICIES
drop policy if exists "Members can view reactions" on public.message_reactions;
create policy "Members can view reactions" 
  on public.message_reactions for select 
  to authenticated 
  using (true);

drop policy if exists "Users can manage their reactions" on public.message_reactions;
create policy "Users can manage their reactions" 
  on public.message_reactions for all 
  to authenticated 
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- MESSAGE SAVED (STARRED) POLICIES
drop policy if exists "Users can manage their saved messages" on public.message_saved;
create policy "Users can manage their saved messages" 
  on public.message_saved for all 
  to authenticated 
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- MESSAGE DELETIONS FOR ME POLICIES
drop policy if exists "Users can manage their message deletions" on public.message_deletions_for_me;
create policy "Users can manage their message deletions" 
  on public.message_deletions_for_me for all 
  to authenticated 
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- CALL HISTORY POLICIES
drop policy if exists "Users can view their call history" on public.call_history;
create policy "Users can view their call history" 
  on public.call_history for select 
  to authenticated 
  using (caller_id = auth.uid() or receiver_id = auth.uid());

drop policy if exists "Users can insert call history" on public.call_history;
create policy "Users can insert call history" 
  on public.call_history for insert 
  to authenticated 
  with check (caller_id = auth.uid() or receiver_id = auth.uid());

drop policy if exists "Users can update call history" on public.call_history;
create policy "Users can update call history" 
  on public.call_history for update 
  to authenticated 
  using (caller_id = auth.uid() or receiver_id = auth.uid());

-- CALL HISTORY DELETIONS FOR ME
drop policy if exists "Users can manage their call deletions" on public.call_history_deletions_for_me;
create policy "Users can manage their call deletions" 
  on public.call_history_deletions_for_me for all 
  to authenticated 
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- USER SETTINGS POLICIES
drop policy if exists "Users can manage their settings" on public.user_settings;
create policy "Users can manage their settings" 
  on public.user_settings for all 
  to authenticated 
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- STORAGE POLICIES
drop policy if exists "Public avatar access" on storage.objects;
create policy "Public avatar access" 
  on storage.objects for select 
  to public 
  using (bucket_id = 'avatars');

drop policy if exists "Authenticated users can upload avatars" on storage.objects;
create policy "Authenticated users can upload avatars" 
  on storage.objects for insert 
  to authenticated 
  with check (bucket_id = 'avatars');

drop policy if exists "Authenticated users can update avatars" on storage.objects;
create policy "Authenticated users can update avatars" 
  on storage.objects for update 
  to authenticated 
  using (bucket_id = 'avatars');

drop policy if exists "Authenticated users can read chat media" on storage.objects;
create policy "Authenticated users can read chat media" 
  on storage.objects for select 
  to authenticated 
  using (bucket_id = 'chat-media');

drop policy if exists "Authenticated users can upload chat media" on storage.objects;
create policy "Authenticated users can upload chat media" 
  on storage.objects for insert 
  to authenticated 
  with check (bucket_id = 'chat-media');

-- ==========================================================
-- SECURE POSTGRES FUNCTIONS & RPC
-- ==========================================================

-- Function: Create or get 1-on-1 direct conversation between two users
create or replace function public.create_or_get_direct_conversation(other_user_id uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  existing_conv_id uuid;
  new_conv_id uuid;
  cur_user_id uuid := auth.uid();
begin
  if cur_user_id is null then
    raise exception 'Not authenticated';
  end if;
  if cur_user_id = other_user_id then
    raise exception 'Cannot create direct chat with yourself';
  end if;

  -- Find common conversation of type 'direct' with both members
  select m1.conversation_id into existing_conv_id
  from conversation_members m1
  join conversation_members m2 on m1.conversation_id = m2.conversation_id
  join conversations c on c.id = m1.conversation_id
  where m1.user_id = cur_user_id
    and m2.user_id = other_user_id
    and c.type = 'direct'
  limit 1;

  if existing_conv_id is not null then
    -- If marked as deleted for the current user, un-delete it
    update conversation_members 
    set is_deleted = false 
    where conversation_id = existing_conv_id and user_id = cur_user_id;

    return existing_conv_id;
  end if;

  -- Create new conversation
  insert into conversations (type) values ('direct') returning id into new_conv_id;

  -- Add both members
  insert into conversation_members (conversation_id, user_id)
  values 
    (new_conv_id, cur_user_id),
    (new_conv_id, other_user_id);

  return new_conv_id;
end;
$$;

-- Function: Delete message for everyone (Sender only)
create or replace function public.delete_message_for_everyone(p_message_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  cur_user_id uuid := auth.uid();
  msg_sender uuid;
begin
  select sender_id into msg_sender from messages where id = p_message_id;

  if msg_sender is null or msg_sender <> cur_user_id then
    raise exception 'Only the sender can delete this message for everyone';
  end if;

  update messages
  set 
    content = 'This message was deleted',
    is_deleted_everyone = true,
    file_name = null,
    file_size = null,
    mime_type = null,
    media_path = null,
    updated_at = now()
  where id = p_message_id;

  return true;
end;
$$;

-- Function: Mark view-once message as viewed
create or replace function public.mark_message_viewed(p_message_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
begin
  update messages
  set viewed_at = now()
  where id = p_message_id 
    and is_view_once = true 
    and viewed_at is null;

  return true;
end;
$$;

-- Function: Clear chat for current user
create or replace function public.clear_chat_for_user(p_conversation_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  cur_user_id uuid := auth.uid();
begin
  update conversation_members
  set cleared_at = now()
  where conversation_id = p_conversation_id and user_id = cur_user_id;

  return true;
end;
$$;

-- Function: Delete chat for current user
create or replace function public.delete_chat_for_user(p_conversation_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  cur_user_id uuid := auth.uid();
begin
  update conversation_members
  set is_deleted = true, cleared_at = now()
  where conversation_id = p_conversation_id and user_id = cur_user_id;

  return true;
end;
$$;

-- Trigger: Automatically create public.profiles row when auth.users signs up
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, username, display_name, avatar_url)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1)),
    coalesce(new.raw_user_meta_data->>'display_name', new.raw_user_meta_data->>'username', split_part(new.email, '@', 1)),
    coalesce(new.raw_user_meta_data->>'avatar_url', null)
  )
  on conflict (id) do update set
    username = coalesce(excluded.username, profiles.username),
    display_name = coalesce(excluded.display_name, profiles.display_name);

  -- Insert default user settings
  insert into public.user_settings (user_id) values (new.id)
  on conflict (user_id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ==========================================================
-- REALTIME PUBLICATION
-- ==========================================================
do $$
begin
  begin
    alter publication supabase_realtime add table public.messages;
  exception when duplicate_object then null;
  end;
  begin
    alter publication supabase_realtime add table public.message_reactions;
  exception when duplicate_object then null;
  end;
  begin
    alter publication supabase_realtime add table public.conversation_members;
  exception when duplicate_object then null;
  end;
  begin
    alter publication supabase_realtime add table public.friend_requests;
  exception when duplicate_object then null;
  end;
  begin
    alter publication supabase_realtime add table public.friendships;
  exception when duplicate_object then null;
  end;
  begin
    alter publication supabase_realtime add table public.call_history;
  exception when duplicate_object then null;
  end;
  begin
    alter publication supabase_realtime add table public.profiles;
  exception when duplicate_object then null;
  end;
end $$;

-- 15. SECURE ZERO-CONFIRMATION NEXA REGISTRATION FUNCTION
-- Allows instant username+password registration directly in Supabase without sending confirmation emails.
create or replace function public.register_nexa_user(
  p_username text,
  p_display_name text,
  p_password text
)
returns jsonb
language plpgsql
security definer
set search_path = public, auth, extensions
as $$
declare
  v_user_id uuid;
  v_email text;
  v_clean_username text;
  v_encrypted_password text;
begin
  v_clean_username := lower(trim(p_username));
  
  if length(v_clean_username) < 3 or length(v_clean_username) > 24 or v_clean_username !~ '^[a-z0-9_.]+$' then
    return jsonb_build_object('success', false, 'error', 'Username must be 3-24 characters and only contain letters, numbers, underscores or periods.');
  end if;

  if exists (select 1 from public.profiles where lower(username) = v_clean_username) then
    return jsonb_build_object('success', false, 'error', 'Username @' || v_clean_username || ' is already taken.');
  end if;

  v_email := v_clean_username || '@nexa.net';

  if exists (select 1 from auth.users where email = v_email) then
    return jsonb_build_object('success', false, 'error', 'Username @' || v_clean_username || ' is already registered.');
  end if;

  v_user_id := gen_random_uuid();
  v_encrypted_password := crypt(p_password, gen_salt('bf'));

  insert into auth.users (
    instance_id,
    id,
    aud,
    role,
    email,
    encrypted_password,
    email_confirmed_at,
    recovery_sent_at,
    last_sign_in_at,
    raw_app_meta_data,
    raw_user_meta_data,
    created_at,
    updated_at,
    confirmation_token,
    email_change,
    email_change_token_new,
    recovery_token
  ) values (
    '00000000-0000-0000-0000-000000000000',
    v_user_id,
    'authenticated',
    'authenticated',
    v_email,
    v_encrypted_password,
    now(),
    now(),
    now(),
    '{"provider":"email","providers":["email"]}'::jsonb,
    jsonb_build_object('username', v_clean_username, 'display_name', trim(p_display_name)),
    now(),
    now(),
    '',
    '',
    '',
    ''
  );

  insert into public.profiles (id, username, display_name, created_at, updated_at)
  values (v_user_id, v_clean_username, trim(p_display_name), now(), now())
  on conflict (id) do update set
    username = excluded.username,
    display_name = excluded.display_name,
    updated_at = now();

  return jsonb_build_object('success', true, 'user_id', v_user_id, 'username', v_clean_username);
end;
$$;

grant execute on function public.register_nexa_user(text, text, text) to anon, authenticated, service_role;
`;
