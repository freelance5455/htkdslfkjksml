export type PriceLine = {
  id: string;
  label: string;
  detail: string;
  cents: number;
};

export type Extra = {
  id: string;
  label: string;
  cents: number;
};

export type ServiceIcon =
  | "limpeza"
  | "reparo"
  | "aula"
  | "pet"
  | "companhia"
  | "info";

export type Service = {
  id: string;
  name: string;
  need: string;
  summary: string;
  includes: string[];
  notIncluded: string[];
  icon: ServiceIcon;
  options: PriceLine[];
  extras: Extra[];
};

export const CATALOG: Service[] = [
  {
    id: "limpeza",
    name: "Limpeza da casa",
    need: "A casa acumulou e ninguém dá conta no meio da semana.",
    summary: "Piso, banheiro, cozinha e pó. Volta a dar para usar.",
    includes: ["Piso, pó e superfícies", "Banheiro e cozinha", "Lixo reunido"],
    notIncluded: ["Caixa d'água", "Produto que você não deixar aí"],
    icon: "limpeza",
    options: [
      { id: "limpeza-2h", label: "Apartamento, 2 horas", detail: "Até uns 50 m²", cents: 16000 },
      { id: "limpeza-4h", label: "Casa, 4 horas", detail: "Até uns 100 m²", cents: 28000 },
      { id: "limpeza-5h", label: "Faxina pesada, 5 horas", detail: "Acúmulo ou pós-obra leve", cents: 42000 },
    ],
    extras: [
      { id: "limpeza-janela", label: "Janelas por dentro", cents: 4000 },
      { id: "limpeza-roupa", label: "Passar uma cesta de roupa", cents: 4500 },
    ],
  },
  {
    id: "reparo",
    name: "Pequeno reparo",
    need: "Torneira, tomada, prateleira, porta. Coisa que trava o dia.",
    summary: "Um conserto doméstico, com o valor da visita fechado antes.",
    includes: ["Diagnóstico na hora", "O reparo combinado", "Teste antes de ir embora"],
    notIncluded: ["Peça de loja", "Obra, gás ou quadro elétrico"],
    icon: "reparo",
    options: [
      { id: "reparo-1", label: "Uma visita, 1 ponto", detail: "Uma torneira, uma tomada, uma porta", cents: 12000 },
      { id: "reparo-3", label: "Uma visita, até 3 pontos", detail: "Mesma casa, mesma ida", cents: 20000 },
    ],
    extras: [{ id: "reparo-fds", label: "Sábado", cents: 4000 }],
  },
  {
    id: "aula",
    name: "Aula particular",
    need: "Prova chegando, ou uma matéria que não entra.",
    summary: "Uma hora de explicação, em casa ou online, no assunto combinado.",
    includes: ["1 assunto por encontro", "Exercício junto", "O que revisar depois"],
    notIncluded: ["Trabalho feito no lugar do aluno", "Aula em grupo"],
    icon: "aula",
    options: [
      { id: "aula-1", label: "1 hora", detail: "Escola ou reforço", cents: 9000 },
      { id: "aula-4", label: "Pacote de 4 horas", detail: "Mesmo aluno, mesmo mês", cents: 32000 },
    ],
    extras: [{ id: "aula-noite", label: "Depois das 19h", cents: 1500 }],
  },
  {
    id: "pet",
    name: "Cuidado de pet",
    need: "O animal precisa sair ou de companhia enquanto você trabalha.",
    summary: "Passeio ou visita. Sem hospedagem escondida no preço.",
    includes: ["Passeio ou permanência combinada", "Água fresca", "Recado de como ele ficou"],
    notIncluded: ["Banho e tosa", "Remédio sem você entregar na mão"],
    icon: "pet",
    options: [
      { id: "pet-passeio", label: "Passeio, 40 min", detail: "Uma saída no quarteirão", cents: 4500 },
      { id: "pet-visita", label: "Visita, 3 horas", detail: "Companhia e uma saída curta", cents: 9500 },
      { id: "pet-dia", label: "Diária, 8 horas", detail: "Você viaja, ele fica em casa", cents: 16000 },
    ],
    extras: [{ id: "pet-extra", label: "Segundo animal na mesma casa", cents: 2500 }],
  },
  {
    id: "companhia",
    name: "Companhia em casa",
    need: "Quem mora só, ou um idoso que precisa de presença — não de plantão médico.",
    summary: "Conversa, recado e ajuda prática. Não é cuidado de saúde.",
    includes: ["Presença no horário", "Um recado simples (mercado ou farmácia)", "Aviso se algo sair do combinado"],
    notIncluded: ["Medicação", "Banho", "Procedimento de enfermagem"],
    icon: "companhia",
    options: [
      { id: "companhia-2h", label: "2 horas", detail: "Visita e um recado curto", cents: 9000 },
      { id: "companhia-4h", label: "Meio período", detail: "Manhã ou tarde", cents: 17000 },
    ],
    extras: [{ id: "companhia-mercado", label: "Ida ao mercado com lista", cents: 3000 }],
  },
  {
    id: "info",
    name: "Computador e Wi-Fi",
    need: "A internet caiu, o PC não liga, a impressora sumiu.",
    summary: "Visita para deixar o básico funcionando de novo.",
    includes: ["Olhada no problema combinado", "Explicação do que foi feito", "Sem vender peça no susto"],
    notIncluded: ["Notebook aberto com solda", "Recuperação de arquivo apagado"],
    icon: "info",
    options: [
      { id: "info-diag", label: "Diagnóstico, 1 hora", detail: "Wi-Fi, impressora ou PC lento", cents: 10000 },
      { id: "info-format", label: "Formatação com backup", detail: "Seus arquivos numa pasta antes", cents: 19000 },
    ],
    extras: [{ id: "info-extra", label: "Segundo aparelho na mesma visita", cents: 5000 }],
  },
];

export const PRICE_IDS = new Set(
  CATALOG.flatMap((service) => [
    ...service.options.map((option) => option.id),
    ...service.extras.map((extra) => extra.id),
  ]),
);

export function findService(id: string) {
  return CATALOG.find((service) => service.id === id);
}

export function lineCents(id: string, fallback: number, prices: Record<string, number>) {
  const custom = prices[id];
  return typeof custom === "number" && custom >= 0 ? custom : fallback;
}
