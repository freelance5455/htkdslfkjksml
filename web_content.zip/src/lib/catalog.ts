export interface ModelDef {
  id: string;
  kind: "asr" | "mt";
  repo: string;
  name: string;
  sub: string;
  approxMB: number;
  minMemGB: number;
  license: string;
  notes: string;
}

export const ASR_MODELS: ModelDef[] = [
  {
    id: "whisper-tiny",
    kind: "asr",
    repo: "Xenova/whisper-tiny",
    name: "Whisper Tiny",
    sub: "39 M params · int8 · multilingual",
    approxMB: 68,
    minMemGB: 2,
    license: "CC-BY-4.0 (OpenAI)",
    notes:
      "Fastest and lightest. Best starting point for tests and low-end phones. Accuracy is basic for accented speech.",
  },
  {
    id: "whisper-base",
    kind: "asr",
    repo: "Xenova/whisper-base",
    name: "Whisper Base",
    sub: "74 M params · int8 · multilingual",
    approxMB: 135,
    minMemGB: 3,
    license: "CC-BY-4.0 (OpenAI)",
    notes:
      "Recommended default. Better word accuracy and timestamps than Tiny on a mid-range device.",
  },
  {
    id: "whisper-small",
    kind: "asr",
    repo: "Xenova/whisper-small",
    name: "Whisper Small",
    sub: "244 M params · int8 · multilingual",
    approxMB: 280,
    minMemGB: 4,
    license: "CC-BY-4.0 (OpenAI)",
    notes:
      "Highest recognition quality in this set. Slower and heavier — needs a device with 4 GB+ RAM.",
  },
];

export const MT_MODELS: ModelDef[] = [
  {
    id: "m2m100",
    kind: "mt",
    repo: "Xenova/m2m100_418M",
    name: "M2M100 418M (int8)",
    sub: "418 M params · 41 languages → Urdu",
    approxMB: 940,
    minMemGB: 6,
    license: "MIT",
    notes:
      "Universal machine translator: any supported source language directly to Urdu script, one model. The smallest real in-browser Urdu model available today (no small ONNX en→Urdu checkpoint exists). Large — see device warning.",
  },
  {
    id: "nllb600m",
    kind: "mt",
    repo: "Xenova/nllb-200-distilled-600M",
    name: "NLLB-200 Distilled 600M (int8)",
    sub: "600 M params · 200 languages → Urdu",
    approxMB: 1000,
    minMemGB: 8,
    license: "CC-BY-NC-4.0 (NON-COMMERCIAL)",
    notes:
      "Meta NLLB family, usually better Urdu quality than M2M100, but larger and non-commercial license only. For capable devices / desktop.",
  },
];

export const FFMPEG_CORE = {
  id: "ffmpeg-core",
  name: "FFmpeg media engine",
  sub: "fallback audio extractor · WASM · LGPL",
  approxMB: 33,
  source: "unpkg.com/@ffmpeg/core@0.12.6 (official npm build)",
  base: "https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd/",
  js: "ffmpeg-core.js",
  wasm: "ffmpeg-core.wasm",
};

export interface LangDef {
  code: string;
  name: string;
  native: string;
  whisper: string;
  m2m: string;
}

export const LANGS: LangDef[] = [
  { code: "en", name: "English", native: "English", whisper: "english", m2m: "eng_Latn" },
  { code: "ur", name: "Urdu", native: "اردو", whisper: "urdu", m2m: "urd_Arab" },
  { code: "ar", name: "Arabic", native: "العربية", whisper: "arabic", m2m: "ara_Arab" },
  { code: "hi", name: "Hindi", native: "हिन्दी", whisper: "hindi", m2m: "hin_Deva" },
  { code: "es", name: "Spanish", native: "Español", whisper: "spanish", m2m: "spa_Latn" },
  { code: "fr", name: "French", native: "Français", whisper: "french", m2m: "fra_Latn" },
  { code: "de", name: "German", native: "Deutsch", whisper: "german", m2m: "deu_Latn" },
  { code: "ru", name: "Russian", native: "Русский", whisper: "russian", m2m: "rus_Cyrl" },
  { code: "tr", name: "Turkish", native: "Türkçe", whisper: "turkish", m2m: "tur_Latn" },
  { code: "zh", name: "Chinese", native: "中文", whisper: "chinese", m2m: "zho_Hans" },
  { code: "ja", name: "Japanese", native: "日本語", whisper: "japanese", m2m: "jpn_Jpan" },
  { code: "bn", name: "Bengali", native: "বাংলা", whisper: "bengali", m2m: "ben_Beng" },
  { code: "pt", name: "Portuguese", native: "Português", whisper: "portuguese", m2m: "por_Latn" },
  { code: "it", name: "Italian", native: "Italiano", whisper: "italian", m2m: "ita_Latn" },
  { code: "ko", name: "Korean", native: "한국어", whisper: "korean", m2m: "kor_Hang" },
];

export function langOf(code: string): LangDef | undefined {
  return LANGS.find((l) => l.code === code);
}

export function langName(code: string): string {
  if (code === "auto") return "Auto-detect";
  return langOf(code)?.name ?? code;
}
