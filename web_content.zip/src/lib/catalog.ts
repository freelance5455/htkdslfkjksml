export type Palette = {
  from: string;
  to: string;
  glow: string;
  emoji: string;
};

export const PALETTES: Record<string, Palette> = {
  iron: { from: "#b91c1c", to: "#450a0a", glow: "#f87171", emoji: "🤖" },
  hulk: { from: "#15803d", to: "#052e16", glow: "#4ade80", emoji: "💚" },
  cap: { from: "#1d4ed8", to: "#0b1120", glow: "#60a5fa", emoji: "🛡️" },
  thor: { from: "#7c3aed", to: "#1e1b4b", glow: "#a78bfa", emoji: "⚡" },
  avengers: { from: "#b91c1c", to: "#1e3a8a", glow: "#fbbf24", emoji: "🅰️" },
  guardians: { from: "#db2777", to: "#2e1065", glow: "#f472b6", emoji: "🚀" },
  strange: { from: "#0891b2", to: "#083344", glow: "#22d3ee", emoji: "🔮" },
  spider: { from: "#dc2626", to: "#1e1b4b", glow: "#f87171", emoji: "🕷️" },
  panther: { from: "#7c2d12", to: "#0c0a09", glow: "#f59e0b", emoji: "🐆" },
  marvel: { from: "#b45309", to: "#1c1917", glow: "#fbbf24", emoji: "⭐" },
  antman: { from: "#ca8a04", to: "#1c1917", glow: "#fde047", emoji: "🐜" },
  widow: { from: "#9f1239", to: "#111827", glow: "#fb7185", emoji: "🕸️" },
  venom: { from: "#4338ca", to: "#0f0a2e", glow: "#818cf8", emoji: "🖤" },
  xmen: { from: "#1e40af", to: "#0b1120", glow: "#60a5fa", emoji: "🧬" },
  wolverine: { from: "#b45309", to: "#1c1917", glow: "#fbbf24", emoji: "🐺" },
  deadpool: { from: "#b91c1c", to: "#111827", glow: "#f87171", emoji: "💥" },
  ff: { from: "#0369a1", to: "#082f49", glow: "#38bdf8", emoji: "🔥" },
  sony: { from: "#be123c", to: "#1f0713", glow: "#fb7185", emoji: "🕸️" },
  eternals: { from: "#0d9488", to: "#042f2e", glow: "#2dd4bf", emoji: "🌌" },
  shang: { from: "#15803d", to: "#052e16", glow: "#4ade80", emoji: "🐉" },
  multiverse: { from: "#6d28d9", to: "#1e1b4b", glow: "#c4b5fd", emoji: "🌠" },
  thunderbolts: { from: "#475569", to: "#0f172a", glow: "#94a3b8", emoji: "🎯" },
  doomsday: { from: "#7f1d1d", to: "#050505", glow: "#ef4444", emoji: "💀" },
  secretwars: { from: "#4c1d95", to: "#0b0616", glow: "#a78bfa", emoji: "🌌" },
};

export type CatalogFilm = {
  slug: string;
  title: string;
  year: number;
  phase: number;
  saga: "MCU" | "X-MEN" | "SONY" | "FOX";
  palette: keyof typeof PALETTES;
  runtime: number;
  synopsis: string;
  upcoming?: boolean;
  releaseDate?: string;
};

export const SAGA_LABELS: Record<string, string> = {
  MCU: "Marvel Cinematic Universe",
  "X-MEN": "X-Men & Deadpool",
  SONY: "Sony Spider-Man Universe",
  FOX: "Fantastic Four (Fox)",
};

export const CATALOG: CatalogFilm[] = [
  // ---------------- FASE 1 ----------------
  { slug: "iron-man", title: "Iron Man", year: 2008, phase: 1, saga: "MCU", palette: "iron", runtime: 126, synopsis: "Tony Stark costruisce un'armatura per fuggire ai suoi rapitori e diventa il primo Vendicatore." },
  { slug: "the-incredible-hulk", title: "L'Incredibile Hulk", year: 2008, phase: 1, saga: "MCU", palette: "hulk", runtime: 112, synopsis: "Bruce Banner cerca una cura mentre il generale Ross lo insegue in tutto il mondo." },
  { slug: "iron-man-2", title: "Iron Man 2", year: 2010, phase: 1, saga: "MCU", palette: "iron", runtime: 124, synopsis: "Ivan Vanko sfida Tony Stark mentre il governo vuole le sue armature." },
  { slug: "thor", title: "Thor", year: 2011, phase: 1, saga: "MCU", palette: "thor", runtime: 115, synopsis: "Il dio del tuono viene esiliato sulla Terra e impara il valore dell'umiltà." },
  { slug: "captain-america-the-first-avenger", title: "Captain America - Il Primo Vendicatore", year: 2011, phase: 1, saga: "MCU", palette: "cap", runtime: 124, synopsis: "Steve Rogers diventa un supersoldato e guida la lotta contro l'HYDRA." },
  { slug: "the-avengers", title: "The Avengers", year: 2012, phase: 1, saga: "MCU", palette: "avengers", runtime: 143, synopsis: "Loki attacca New York e i primi Vendicatori si uniscono per la prima volta." },

  // ---------------- FASE 2 ----------------
  { slug: "iron-man-3", title: "Iron Man 3", year: 2013, phase: 2, saga: "MCU", palette: "iron", runtime: 130, synopsis: "Tony Stark, senza armatura, deve fermare il Mandarino e le sue bombe umane." },
  { slug: "thor-the-dark-world", title: "Thor: The Dark World", year: 2013, phase: 2, saga: "MCU", palette: "thor", runtime: 112, synopsis: "Malekith minaccia i Nove Regni e Thor stringe un'alleanza impossibile con Loki." },
  { slug: "captain-america-the-winter-soldier", title: "Captain America: The Winter Soldier", year: 2014, phase: 2, saga: "MCU", palette: "cap", runtime: 136, synopsis: "Steve Rogers scopre che l'HYDRA si è infiltrata nello S.H.I.E.L.D." },
  { slug: "guardians-of-the-galaxy", title: "Guardiani della Galassia", year: 2014, phase: 2, saga: "MCU", palette: "guardians", runtime: 121, synopsis: "Peter Quill e una banda di criminali spaziali salvano la galassia da Ronan." },
  { slug: "avengers-age-of-ultron", title: "Avengers: Age of Ultron", year: 2015, phase: 2, saga: "MCU", palette: "avengers", runtime: 141, synopsis: "Ultron, l'IA creata da Stark, decide di estinguere l'umanità." },
  { slug: "ant-man", title: "Ant-Man", year: 2015, phase: 2, saga: "MCU", palette: "antman", runtime: 117, synopsis: "Scott Lang ruba la tuta di Hank Pym e diventa l'eroe più piccolo del mondo." },

  // ---------------- FASE 3 ----------------
  { slug: "captain-america-civil-war", title: "Captain America: Civil War", year: 2016, phase: 3, saga: "MCU", palette: "cap", runtime: 147, synopsis: "Gli accordi di Sokovia dividono i Vendicatori in due fazioni." },
  { slug: "doctor-strange", title: "Doctor Strange", year: 2016, phase: 3, saga: "MCU", palette: "strange", runtime: 115, synopsis: "Un chirurgo distrutto scopre la magia e la dimensione speculare." },
  { slug: "guardians-of-the-galaxy-vol-2", title: "Guardiani della Galassia Vol. 2", year: 2017, phase: 3, saga: "MCU", palette: "guardians", runtime: 136, synopsis: "Peter Quill incontra suo padre Ego, un pianeta vivente con piani oscuri." },
  { slug: "spider-man-homecoming", title: "Spider-Man: Homecoming", year: 2017, phase: 3, saga: "MCU", palette: "spider", runtime: 133, synopsis: "Peter Parker affronta l'Avvoltoio mentre cerca di dimostrare di essere un eroe." },
  { slug: "thor-ragnarok", title: "Thor: Ragnarok", year: 2017, phase: 3, saga: "MCU", palette: "thor", runtime: 130, synopsis: "Thor finisce su Sakaar e deve fermare Hela prima del Ragnarok." },
  { slug: "black-panther", title: "Black Panther", year: 2018, phase: 3, saga: "MCU", palette: "panther", runtime: 134, synopsis: "T'Challa difende il trono di Wakanda da Killmonger." },
  { slug: "avengers-infinity-war", title: "Avengers: Infinity War", year: 2018, phase: 3, saga: "MCU", palette: "avengers", runtime: 149, synopsis: "Thanos colleziona le Gemme dell'Infinito e metà universo cade in cenere." },
  { slug: "ant-man-and-the-wasp", title: "Ant-Man and the Wasp", year: 2018, phase: 3, saga: "MCU", palette: "antman", runtime: 118, synopsis: "Scott Lang entra nel regno quantico per salvare Janet van Dyne." },
  { slug: "captain-marvel", title: "Captain Marvel", year: 2019, phase: 3, saga: "MCU", palette: "marvel", runtime: 123, synopsis: "Carol Danvers scopre il suo passato e diventa l'eroe più potente dell'universo." },
  { slug: "avengers-endgame", title: "Avengers: Endgame", year: 2019, phase: 3, saga: "MCU", palette: "avengers", runtime: 181, synopsis: "Il viaggio nel tempo per annullare lo schiocco di Thanos e dire addio a Iron Man." },
  { slug: "spider-man-far-from-home", title: "Spider-Man: Far From Home", year: 2019, phase: 3, saga: "MCU", palette: "spider", runtime: 129, synopsis: "In gita in Europa, Peter Parker affronta Mysterio e i suoi inganni." },

  // ---------------- FASE 4 ----------------
  { slug: "black-widow", title: "Black Widow", year: 2021, phase: 4, saga: "MCU", palette: "widow", runtime: 134, synopsis: "Natasha Romanoff affronta la sua famiglia e la Stanza Rossa." },
  { slug: "shang-chi-and-the-legend-of-the-ten-rings", title: "Shang-Chi e la leggenda dei Dieci Anelli", year: 2021, phase: 4, saga: "MCU", palette: "shang", runtime: 132, synopsis: "Shang-Chi affronta suo padre e i Dieci Anelli per salvare il mondo." },
  { slug: "eternals", title: "Eternals", year: 2021, phase: 4, saga: "MCU", palette: "eternals", runtime: 156, synopsis: "Gli Eterni escono dall'ombra per fermare i Devianti." },
  { slug: "spider-man-no-way-home", title: "Spider-Man: No Way Home", year: 2021, phase: 4, saga: "MCU", palette: "spider", runtime: 148, synopsis: "Un incantesimo fallito apre il multiverso e riporta i nemici del passato." },
  { slug: "doctor-strange-in-the-multiverse-of-madness", title: "Doctor Strange nel Multiverso della Follia", year: 2022, phase: 4, saga: "MCU", palette: "multiverse", runtime: 126, synopsis: "Strange protegge America Chavez dalla Figlia di Scarlet Witch." },
  { slug: "thor-love-and-thunder", title: "Thor: Love and Thunder", year: 2022, phase: 4, saga: "MCU", palette: "thor", runtime: 119, synopsis: "Thor affronta Gorr, il Macellaio degli Dei, con Jane nei panni di Mighty Thor." },
  { slug: "black-panther-wakanda-forever", title: "Black Panther: Wakanda Forever", year: 2022, phase: 4, saga: "MCU", palette: "panther", runtime: 161, synopsis: "Wakanda piange T'Challa e affronta Namor e il regno di Talokan." },

  // ---------------- FASE 5 ----------------
  { slug: "ant-man-and-the-wasp-quantumania", title: "Ant-Man and the Wasp: Quantumania", year: 2023, phase: 5, saga: "MCU", palette: "antman", runtime: 124, synopsis: "La famiglia Lang finisce nel regno quantico e incontra Kang." },
  { slug: "guardians-of-the-galaxy-vol-3", title: "Guardiani della Galassia Vol. 3", year: 2023, phase: 5, saga: "MCU", palette: "guardians", runtime: 150, synopsis: "I Guardiani salvano Rocket dal suo passato e dall'Alto Evoluzionario." },
  { slug: "the-marvels", title: "The Marvels", year: 2023, phase: 5, saga: "MCU", palette: "marvel", runtime: 105, synopsis: "Carol, Kamala e Monica si scambiano i poteri e affrontano Dar-Benn." },
  { slug: "deadpool-and-wolverine", title: "Deadpool & Wolverine", year: 2024, phase: 5, saga: "MCU", palette: "deadpool", runtime: 128, synopsis: "Wade Wilson recluta Wolverine per salvare il suo universo dalla TVA." },
  { slug: "captain-america-brave-new-world", title: "Captain America: Brave New World", year: 2025, phase: 5, saga: "MCU", palette: "cap", runtime: 119, synopsis: "Sam Wilson nei panni di Capitan America smaschera un complotto alla Casa Bianca." },
  { slug: "thunderbolts", title: "Thunderbolts*", year: 2025, phase: 5, saga: "MCU", palette: "thunderbolts", runtime: 127, synopsis: "Antieroi e villain si uniscono per una missione suicida contro la CIA." },

  // ---------------- FASE 6 ----------------
  { slug: "the-fantastic-four-first-steps", title: "The Fantastic Four: First Steps", year: 2025, phase: 6, saga: "MCU", palette: "ff", runtime: 115, synopsis: "I Fantastici Quattro affrontano Galactus in un universo retro-futurista." },
  { slug: "spider-man-brand-new-day", title: "Spider-Man: Brand New Day", year: 2026, phase: 6, saga: "MCU", palette: "spider", runtime: 0, synopsis: "Un nuovo capitolo per Peter Parker, senza memoria del multiverso.", upcoming: true, releaseDate: "2026-07-31" },
  { slug: "avengers-doomsday", title: "Avengers: Doomsday", year: 2026, phase: 6, saga: "MCU", palette: "doomsday", runtime: 0, synopsis: "Doctor Doom spezza il multiverso e i Vendicatori tornano per l'ultima battaglia.", upcoming: true, releaseDate: "2026-12-18" },
  { slug: "avengers-secret-wars", title: "Avengers: Secret Wars", year: 2027, phase: 6, saga: "MCU", palette: "secretwars", runtime: 0, synopsis: "Il gran finale del Multiverso: ogni universo in guerra su Battleworld.", upcoming: true, releaseDate: "2027-12-17" },

  // ---------------- X-MEN / DEADPOOL ----------------
  { slug: "x-men", title: "X-Men", year: 2000, phase: 0, saga: "X-MEN", palette: "xmen", runtime: 104, synopsis: "Wolverine e Rogue entrano nella scuola di Xavier mentre Magneto minaccia l'umanità." },
  { slug: "x2", title: "X2", year: 2003, phase: 0, saga: "X-MEN", palette: "xmen", runtime: 133, synopsis: "Un attacco alla scuola degli X-Men costringe gli eroi a un'alleanza con Magneto." },
  { slug: "x-men-origini-wolverine", title: "X-Men Origini: Wolverine", year: 2009, phase: 0, saga: "X-MEN", palette: "wolverine", runtime: 107, synopsis: "Le origini di Logan, da Weapon X allo scontro con Sabretooth." },
  { slug: "x-men-l-inizio", title: "X-Men: L'inizio", year: 2011, phase: 0, saga: "X-MEN", palette: "xmen", runtime: 132, synopsis: "Charles ed Erik diventano amici prima di dividersi sulla crisi dei missili di Cuba." },
  { slug: "the-wolverine", title: "The Wolverine", year: 2013, phase: 0, saga: "X-MEN", palette: "wolverine", runtime: 126, synopsis: "Logan va in Giappone e perde la sua capacità di rigenerarsi." },
  { slug: "x-men-giorni-di-un-futuro-passato", title: "X-Men: Giorni di un futuro passato", year: 2014, phase: 0, saga: "X-MEN", palette: "xmen", runtime: 132, synopsis: "Wolverine torna nel 1973 per impedire la guerra tra mutanti e Sentinelle." },
  { slug: "deadpool", title: "Deadpool", year: 2016, phase: 0, saga: "X-MEN", palette: "deadpool", runtime: 108, synopsis: "Wade Wilson diventa Deadpool per vendicarsi di Ajax." },
  { slug: "x-men-apocalisse", title: "X-Men: Apocalisse", year: 2016, phase: 0, saga: "X-MEN", palette: "xmen", runtime: 144, synopsis: "Il primo mutante, Apocalisse, risorge e recluta i suoi Cavalieri." },
  { slug: "logan", title: "Logan", year: 2017, phase: 0, saga: "X-MEN", palette: "wolverine", runtime: 137, synopsis: "Un Logan stanco protegge Laura, una ragazzina mutante, in fuga." },
  { slug: "deadpool-2", title: "Deadpool 2", year: 2018, phase: 0, saga: "X-MEN", palette: "deadpool", runtime: 119, synopsis: "Deadpool forma la X-Force per proteggere un giovane mutante da Cable." },
  { slug: "x-men-dark-phoenix", title: "X-Men: Dark Phoenix", year: 2019, phase: 0, saga: "X-MEN", palette: "xmen", runtime: 114, synopsis: "Jean Grey assorbe la Forza Fenice e diventa una minaccia per tutti." },

  // ---------------- SONY ----------------
  { slug: "spider-man-2002", title: "Spider-Man", year: 2002, phase: 0, saga: "SONY", palette: "sony", runtime: 121, synopsis: "Peter Parker viene morso da un ragno e affronta il Goblin." },
  { slug: "spider-man-2", title: "Spider-Man 2", year: 2004, phase: 0, saga: "SONY", palette: "sony", runtime: 127, synopsis: "Peter perde i poteri mentre Doc Ock minaccia New York." },
  { slug: "spider-man-3", title: "Spider-Man 3", year: 2007, phase: 0, saga: "SONY", palette: "sony", runtime: 139, synopsis: "Il simbionte Venom e il nuovo Uomo Sabbia mettono alla prova Peter." },
  { slug: "the-amazing-spider-man", title: "The Amazing Spider-Man", year: 2012, phase: 0, saga: "SONY", palette: "sony", runtime: 136, synopsis: "Il reboot di Peter Parker contro Lizard e il mistero dei suoi genitori." },
  { slug: "the-amazing-spider-man-2", title: "The Amazing Spider-Man 2", year: 2014, phase: 0, saga: "SONY", palette: "sony", runtime: 142, synopsis: "Electro e Rhino attaccano mentre Peter cerca la verità su suo padre." },
  { slug: "venom", title: "Venom", year: 2018, phase: 0, saga: "SONY", palette: "venom", runtime: 112, synopsis: "Eddie Brock si fonde con il simbionte Venom." },
  { slug: "venom-la-furia-di-carnage", title: "Venom: La furia di Carnage", year: 2021, phase: 0, saga: "SONY", palette: "venom", runtime: 97, synopsis: "Cletus Kasady diventa Carnage e sfida Venom." },
  { slug: "morbius", title: "Morbius", year: 2022, phase: 0, saga: "SONY", palette: "venom", runtime: 104, synopsis: "Michael Morbius cerca una cura e diventa un vampiro vivente." },
  { slug: "madame-web", title: "Madame Web", year: 2024, phase: 0, saga: "SONY", palette: "sony", runtime: 116, synopsis: "Cassie Webb vede il futuro e protegge tre giovani eroine." },
  { slug: "kraven-il-cacciatore", title: "Kraven - Il Cacciatore", year: 2024, phase: 0, saga: "SONY", palette: "sony", runtime: 127, synopsis: "Sergei Kravinoff abbraccia la sua natura selvaggia e caccia i potenti." },

  // ---------------- FOX ----------------
  { slug: "fantastic-4-2005", title: "Fantastic 4", year: 2005, phase: 0, saga: "FOX", palette: "ff", runtime: 106, synopsis: "Quattro scienziati ottengono poteri dopo un esperimento andato male." },
  { slug: "fantastic-4-silver-surfer", title: "Fantastic 4: Silver Surfer", year: 2007, phase: 0, saga: "FOX", palette: "ff", runtime: 92, synopsis: "Silver Surfer arriva sulla Terra annunciando Galactus." },
  { slug: "fantastic-four-2015", title: "Fantastic Four", year: 2015, phase: 0, saga: "FOX", palette: "ff", runtime: 100, synopsis: "Il reboot cupo dei Fantastici Quattro e del Dottor Destino." },
];
