export type Slot = "color" | "hat" | "glasses" | "neck" | "buddy" | "suit";

export type Item = {
  id: string;
  name: string;
  slot: Slot;
  price: number;
  /** main colour used for the shop swatch and the 3D mesh */
  tint: string;
  /** secondary colour for the 3D mesh */
  tint2?: string;
  /** only obtainable from the prize wheel — never sold in the shop */
  wheel?: boolean;
  /** rarity badge shown on the card */
  rarity?: "rare" | "epic" | "legendary";
  /** surface finish, drives the procedural texture + NewVision™ print */
  finish?: "wool" | "fabric" | "gloss" | "leather";
};

export const SLOT_LABEL: Record<Slot, string> = {
  color: "رنگ جوجه",
  suit: "لباس",
  hat: "کلاه",
  glasses: "عینک",
  neck: "گردنی",
  buddy: "همراه",
};

export const RARITY_LABEL = {
  rare: "کمیاب",
  epic: "حماسی",
  legendary: "افسانه‌ای",
} as const;

export const RARITY_TINT = {
  rare: "#4CC9F0",
  epic: "#C77DFF",
  legendary: "#FFB703",
} as const;

export const CATALOG: Item[] = [
  /* ---------------- colours ---------------- */
  { id: "yellow", name: "زرد کلاسیک", slot: "color", price: 0, tint: "#FFC629", tint2: "#FFD84D" },
  { id: "mint", name: "سبز نعنایی", slot: "color", price: 25, tint: "#6FD6A8", tint2: "#8FE6BE" },
  { id: "bubble", name: "صورتی آدامسی", slot: "color", price: 35, tint: "#FF9ABE", tint2: "#FFB4CE" },
  { id: "sky", name: "آبی آسمانی", slot: "color", price: 45, tint: "#6FB8F2", tint2: "#93CEFA" },
  { id: "lilac", name: "یاسی", slot: "color", price: 60, tint: "#B79BF0", tint2: "#CDB6FA" },
  { id: "peach", name: "هلویی", slot: "color", price: 80, tint: "#FFA46B", tint2: "#FFBD8E" },
  { id: "snow", name: "سفید برفی", slot: "color", price: 110, tint: "#F4F1EA", tint2: "#FFFFFA" },
  { id: "midnight", name: "شب‌رنگ", slot: "color", price: 180, tint: "#5B6BA8", tint2: "#7684C4" },
  { id: "cocoa", name: "کاکائویی", slot: "color", price: 150, tint: "#B0794C", tint2: "#C99268" },

  /* ---------------- hats ---------------- */
  { id: "beanie", name: "کلاه بافتنی", slot: "hat", price: 30, tint: "#E4572E", tint2: "#FFD6C4" },
  { id: "cap", name: "کلاه کپ", slot: "hat", price: 55, tint: "#2F80ED", tint2: "#1B4F9C" },
  { id: "party", name: "کلاه جشن", slot: "hat", price: 75, tint: "#FF5D8F", tint2: "#FFE066" },
  { id: "tophat", name: "کلاه شاپو", slot: "hat", price: 120, tint: "#2A2A33", tint2: "#C0392B" },
  { id: "crown", name: "تاج طلایی", slot: "hat", price: 260, tint: "#F2C14E", tint2: "#E8453C" },

  /* ---------------- glasses ---------------- */
  { id: "round", name: "عینک گرد", slot: "glasses", price: 40, tint: "#3A2F26", tint2: "#BFE4FF" },
  { id: "shades", name: "عینک آفتابی", slot: "glasses", price: 70, tint: "#1D1D22", tint2: "#3C3C48" },
  { id: "retro", name: "عینک رترو", slot: "glasses", price: 100, tint: "#F25F5C", tint2: "#2E86AB" },
  { id: "vr", name: "هدست واقعیت مجازی", slot: "glasses", price: 220, tint: "#33353F", tint2: "#5CE1E6" },

  /* ---------------- neck ---------------- */
  { id: "bowtie", name: "پاپیون", slot: "neck", price: 35, tint: "#D7263D", tint2: "#8E1B2B" },
  { id: "scarf", name: "شال‌گردن", slot: "neck", price: 65, tint: "#2A9D8F", tint2: "#E9C46A" },
  { id: "bell", name: "قلاده زنگوله‌ای", slot: "neck", price: 95, tint: "#E63946", tint2: "#F2C14E" },
  { id: "chain", name: "زنجیر طلا", slot: "neck", price: 200, tint: "#F5C542", tint2: "#FFF1A8" },

  /* ---------------- buddies ---------------- */
  { id: "candy", name: "آب‌نبات چوبی", slot: "buddy", price: 50, tint: "#FF4D6D", tint2: "#FFFFFF" },
  { id: "balloon", name: "بادکنک", slot: "buddy", price: 90, tint: "#FF5D8F", tint2: "#FFE066" },
  { id: "backpack", name: "کوله‌پشتی", slot: "buddy", price: 130, tint: "#4C956C", tint2: "#F2C14E" },
  { id: "wings", name: "بال فرشته", slot: "buddy", price: 300, tint: "#FFFFFF", tint2: "#CFE8FF" },
];

/* ================================================================== */
/*  WHEEL-ONLY COLLECTION — never purchasable, only won                */
/* ================================================================== */
export const WHEEL_ITEMS: Item[] = [
  /* ---------------- hoodies (suit) ---------------- */
  {
    id: "hoodie_cream",
    name: "هودی پشمی کرم",
    slot: "suit",
    price: 0,
    tint: "#E8DCC8",
    tint2: "#B99B6B",
    wheel: true,
    rarity: "rare",
    finish: "wool",
  },
  {
    id: "hoodie_night",
    name: "هودی پشمی شب",
    slot: "suit",
    price: 0,
    tint: "#2B3044",
    tint2: "#7C89B8",
    wheel: true,
    rarity: "rare",
    finish: "wool",
  },
  {
    id: "hoodie_blood",
    name: "هودی پشمی خونی",
    slot: "suit",
    price: 0,
    tint: "#7A1220",
    tint2: "#FF6B6B",
    wheel: true,
    rarity: "epic",
    finish: "wool",
  },
  {
    id: "jacket_neon",
    name: "کاپشن براق نئونی",
    slot: "suit",
    price: 0,
    tint: "#0B1020",
    tint2: "#4CC9F0",
    wheel: true,
    rarity: "epic",
    finish: "gloss",
  },
  {
    id: "jacket_leather",
    name: "چرم مشکی",
    slot: "suit",
    price: 0,
    tint: "#1A1A1F",
    tint2: "#C9A227",
    wheel: true,
    rarity: "epic",
    finish: "leather",
  },
  {
    id: "hoodie_galaxy",
    name: "هودی کهکشانی",
    slot: "suit",
    price: 0,
    tint: "#1B1040",
    tint2: "#C77DFF",
    wheel: true,
    rarity: "legendary",
    finish: "gloss",
  },

  /* ---------------- horns & halos (hat) ---------------- */
  {
    id: "horns_devil",
    name: "شاخ قرمز شیطانی",
    slot: "hat",
    price: 0,
    tint: "#C1121F",
    tint2: "#FF7B00",
    wheel: true,
    rarity: "epic",
  },
  {
    id: "horns_demon",
    name: "شاخ اهریمنی مذاب",
    slot: "hat",
    price: 0,
    tint: "#2A0505",
    tint2: "#FF3B1F",
    wheel: true,
    rarity: "legendary",
  },
  {
    id: "halo",
    name: "هاله‌ی نورانی",
    slot: "hat",
    price: 0,
    tint: "#FFE9A8",
    tint2: "#FFD166",
    wheel: true,
    rarity: "epic",
  },

  /* ---------------- glasses ---------------- */
  {
    id: "visor_cyber",
    name: "ویزور سایبری",
    slot: "glasses",
    price: 0,
    tint: "#12141C",
    tint2: "#39FF88",
    wheel: true,
    rarity: "rare",
  },
  {
    id: "shades_holo",
    name: "عینک هولوگرافیک",
    slot: "glasses",
    price: 0,
    tint: "#1B1B24",
    tint2: "#FF6EC7",
    wheel: true,
    rarity: "epic",
  },

  /* ---------------- animated colours ---------------- */
  {
    id: "c_neon",
    name: "نئونی متحرک",
    slot: "color",
    price: 0,
    tint: "#00E5FF",
    tint2: "#7CFFCB",
    wheel: true,
    rarity: "epic",
  },
  {
    id: "c_galaxy",
    name: "کهکشانی متحرک",
    slot: "color",
    price: 0,
    tint: "#4C1D95",
    tint2: "#DB2777",
    wheel: true,
    rarity: "legendary",
  },
  {
    id: "c_demon",
    name: "شیطانی مذاب",
    slot: "color",
    price: 0,
    tint: "#8B0000",
    tint2: "#FF4500",
    wheel: true,
    rarity: "legendary",
  },
  {
    id: "c_holo",
    name: "هولوگرافیک رنگین‌کمان",
    slot: "color",
    price: 0,
    tint: "#FF6EC7",
    tint2: "#5AC8FA",
    wheel: true,
    rarity: "legendary",
  },

  /* ---------------- wings / aura (buddy) ---------------- */
  {
    id: "wings_demon",
    name: "بال‌های اهریمنی",
    slot: "buddy",
    price: 0,
    tint: "#3A0A0A",
    tint2: "#FF3B1F",
    wheel: true,
    rarity: "legendary",
  },
];

/** everything the game knows about, shop + wheel */
export const ALL_ITEMS: Item[] = [...CATALOG, ...WHEEL_ITEMS];

export function itemById(id: string | null | undefined) {
  if (!id) return undefined;
  return ALL_ITEMS.find((i) => i.id === id);
}

export type Upgrade = {
  id: string;
  name: string;
  desc: string;
  emoji: string;
  base: number;
  growth: number;
  max: number;
};

export const UPGRADES: Upgrade[] = [
  {
    id: "power",
    name: "قدرت کلیک",
    desc: "پوینت هر ۳ کلیک: ۱۳ تا ۲۰۰",
    emoji: "\u{1F44F}",
    base: 120,
    growth: 2.6,
    max: 5,
  },
  {
    id: "stamina",
    name: "استقامت",
    desc: "دیرتر بعد از کار خسته می‌شه",
    emoji: "\u{1F4AA}",
    base: 200,
    growth: 2.2,
    max: 5,
  },
  {
    id: "recovery",
    name: "خواب سبک",
    desc: "زمان استراحتش کوتاه‌تر می‌شه",
    emoji: "\u{23F1}",
    base: 180,
    growth: 2.1,
    max: 5,
  },
];
