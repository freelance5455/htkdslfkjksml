export const CHROMATIC_KEYS = [
  { pc: 0, id: "C", label: "C" },
  { pc: 1, id: "Db", label: "D♭" },
  { pc: 2, id: "D", label: "D" },
  { pc: 3, id: "Eb", label: "E♭" },
  { pc: 4, id: "E", label: "E" },
  { pc: 5, id: "F", label: "F" },
  { pc: 6, id: "F#", label: "F♯" },
  { pc: 7, id: "G", label: "G" },
  { pc: 8, id: "Ab", label: "A♭" },
  { pc: 9, id: "A", label: "A" },
  { pc: 10, id: "Bb", label: "B♭" },
  { pc: 11, id: "B", label: "B" },
] as const;

export type ScaleId = "major" | "minor" | "dorian" | "mixolydian" | "harmonic-minor";

export const SCALES: { id: ScaleId; name: string; intervals: number[] }[] = [
  { id: "major", name: "Major", intervals: [0, 2, 4, 5, 7, 9, 11] },
  { id: "minor", name: "Minor", intervals: [0, 2, 3, 5, 7, 8, 10] },
  { id: "dorian", name: "Dorian", intervals: [0, 2, 3, 5, 7, 9, 10] },
  { id: "mixolydian", name: "Mixolydian", intervals: [0, 2, 4, 5, 7, 9, 10] },
  { id: "harmonic-minor", name: "Harmonic minor", intervals: [0, 2, 3, 5, 7, 8, 11] },
];

export const SCALE_NUMERALS: Record<ScaleId, string[]> = {
  major: ["I", "ii", "iii", "IV", "V", "vi", "vii°"],
  minor: ["i", "ii°", "III", "iv", "v", "VI", "VII"],
  dorian: ["i", "ii", "III", "IV", "v", "vi°", "VII"],
  mixolydian: ["I", "ii", "iii°", "IV", "v", "vi", "VII"],
  "harmonic-minor": ["i", "ii°", "III+", "iv", "V", "VI", "vii°"],
};

export type Quality =
  | "maj"
  | "min"
  | "dim"
  | "aug"
  | "7"
  | "maj7"
  | "m7"
  | "m7b5"
  | "dim7"
  | "sus2"
  | "sus4"
  | "add9"
  | "6"
  | "m6";

export const QUALITY_INTERVALS: Record<Quality, number[]> = {
  maj: [0, 4, 7],
  min: [0, 3, 7],
  dim: [0, 3, 6],
  aug: [0, 4, 8],
  "7": [0, 4, 7, 10],
  maj7: [0, 4, 7, 11],
  m7: [0, 3, 7, 10],
  m7b5: [0, 3, 6, 10],
  dim7: [0, 3, 6, 9],
  sus2: [0, 2, 7],
  sus4: [0, 5, 7],
  add9: [0, 4, 7, 14],
  "6": [0, 4, 7, 9],
  m6: [0, 3, 7, 9],
};

export const QUALITY_LABELS: { id: Quality; label: string }[] = [
  { id: "maj", label: "maj" },
  { id: "min", label: "min" },
  { id: "7", label: "7" },
  { id: "maj7", label: "maj7" },
  { id: "m7", label: "m7" },
  { id: "sus4", label: "sus4" },
  { id: "sus2", label: "sus2" },
  { id: "dim", label: "dim" },
  { id: "aug", label: "aug" },
  { id: "m7b5", label: "ø7" },
  { id: "add9", label: "add9" },
  { id: "6", label: "6" },
];

const SHARP_NAMES = ["C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B"];
const FLAT_NAMES = ["C", "D♭", "D", "E♭", "E", "F", "G♭", "G", "A♭", "A", "B♭", "B"];

const FLAT_KEYS = new Set([1, 3, 5, 8, 10]);

export function prefersFlats(keyPc: number): boolean {
  return FLAT_KEYS.has(keyPc);
}

export function signatureTonic(tonic: number, scale: ScaleId): number {
  switch (scale) {
    case "minor":
    case "harmonic-minor":
      return (tonic + 3) % 12;
    case "dorian":
      return (tonic + 10) % 12;
    case "mixolydian":
      return (tonic + 5) % 12;
    default:
      return tonic;
  }
}

export function spellPc(pc: number, keyPc: number, force?: "sharp" | "flat"): string {
  const n = ((pc % 12) + 12) % 12;
  if (force === "flat" || (!force && prefersFlats(keyPc))) return FLAT_NAMES[n];
  return SHARP_NAMES[n];
}

export function scalePitchClasses(tonic: number, scale: ScaleId): number[] {
  const intervals = SCALES.find((s) => s.id === scale)?.intervals ?? SCALES[0].intervals;
  return intervals.map((i) => (tonic + i) % 12);
}

const SUFFIX_QUALITY: { suffix: string; quality: Quality }[] = [
  { suffix: "m7b5", quality: "m7b5" },
  { suffix: "maj7", quality: "maj7" },
  { suffix: "add9", quality: "add9" },
  { suffix: "dim7", quality: "dim7" },
  { suffix: "sus4", quality: "sus4" },
  { suffix: "sus2", quality: "sus2" },
  { suffix: "m7", quality: "m7" },
  { suffix: "ø7", quality: "m7b5" },
  { suffix: "ø", quality: "m7b5" },
  { suffix: "°7", quality: "dim7" },
  { suffix: "dim", quality: "dim" },
  { suffix: "aug", quality: "aug" },
  { suffix: "+", quality: "aug" },
  { suffix: "°", quality: "dim" },
  { suffix: "6", quality: "6" },
  { suffix: "9", quality: "add9" },
  { suffix: "7", quality: "7" },
];

const ROMAN_RE = /^(b|#)?(III|II|IV|VII|VI|V|I)(.*)$/i;
const DEGREE_FROM_ROMAN: Record<string, number> = {
  I: 0,
  II: 1,
  III: 2,
  IV: 3,
  V: 4,
  VI: 5,
  VII: 6,
};

export type ParsedNumeral = {
  accidental: number;
  degree: number;
  roman: string;
  isUpper: boolean;
  suffix: string;
  qualityHint: Quality | null;
};

export function parseNumeral(raw: string): ParsedNumeral | null {
  const trimmed = raw.trim();
  const match = trimmed.match(ROMAN_RE);
  if (!match) return null;
  const accidental = match[1] === "b" ? -1 : match[1] === "#" ? 1 : 0;
  const roman = match[2];
  const isUpper = roman === roman.toUpperCase();
  let rest = match[3] ?? "";
  let qualityHint: Quality | null = null;
  if (rest.startsWith("°") || rest.startsWith("o")) {
    qualityHint = rest.includes("7") ? "dim7" : "dim";
    rest = rest.replace(/^°|^o/, "");
  }
  if (rest.startsWith("+")) {
    qualityHint = "aug";
    rest = rest.slice(1);
  }
  let suffix = rest;
  if (!qualityHint && suffix) {
    const found = SUFFIX_QUALITY.find((s) => suffix.toLowerCase() === s.suffix.toLowerCase());
    if (found) qualityHint = found.quality;
  }
  return {
    accidental,
    degree: DEGREE_FROM_ROMAN[roman.toUpperCase()] ?? 0,
    roman,
    isUpper,
    suffix,
    qualityHint,
  };
}

function classifyDiatonic(tonic: number, scale: ScaleId, degree: number, sevenths: boolean): Quality {
  const pcs = scalePitchClasses(tonic, scale);
  const root = pcs[degree];
  const third = pcs[(degree + 2) % 7];
  const fifth = pcs[(degree + 4) % 7];
  const seventh = pcs[(degree + 6) % 7];
  const i3 = (third - root + 12) % 12;
  const i5 = (fifth - root + 12) % 12;
  const i7 = (seventh - root + 12) % 12;
  if (sevenths) {
    if (i3 === 4 && i5 === 7 && i7 === 11) return "maj7";
    if (i3 === 4 && i5 === 7 && i7 === 10) return "7";
    if (i3 === 3 && i5 === 7 && i7 === 10) return "m7";
    if (i3 === 3 && i5 === 6 && i7 === 10) return "m7b5";
    if (i3 === 3 && i5 === 6 && i7 === 9) return "dim7";
    if (i3 === 4 && i5 === 8) return "aug";
  }
  if (i3 === 4 && i5 === 8) return "aug";
  if (i3 === 3 && i5 === 6) return "dim";
  if (i3 === 3) return "min";
  return "maj";
}

export function qualityFromNumeral(
  parsed: ParsedNumeral,
  tonic: number,
  scale: ScaleId,
  sevenths: boolean,
): Quality {
  if (parsed.qualityHint && parsed.suffix) return parsed.qualityHint;
  if (parsed.qualityHint && !parsed.suffix) {
    if (sevenths) {
      if (parsed.qualityHint === "dim") return "m7b5";
      if (parsed.qualityHint === "aug") return "aug";
    }
    return parsed.qualityHint;
  }
  const diatonic = classifyDiatonic(tonic, scale, parsed.degree, sevenths);
  const triad = classifyDiatonic(tonic, scale, parsed.degree, false);
  if (parsed.isUpper && (triad === "min" || triad === "dim")) {
    return sevenths ? "7" : "maj";
  }
  if (!parsed.isUpper && (triad === "maj" || triad === "aug")) {
    return sevenths ? "m7" : "min";
  }
  return diatonic;
}

export type ChordSlot = {
  id: string;
  numeral: string;
  beats: number;
};

export type ResolvedChord = {
  id: string;
  numeral: string;
  symbol: string;
  quality: Quality;
  rootPc: number;
  midi: number[];
  noteNames: string[];
  beats: number;
};

export function qualitySuffix(quality: Quality): string {
  switch (quality) {
    case "maj":
      return "";
    case "min":
      return "m";
    case "dim":
      return "dim";
    case "aug":
      return "aug";
    case "7":
      return "7";
    case "maj7":
      return "maj7";
    case "m7":
      return "m7";
    case "m7b5":
      return "ø7";
    case "dim7":
      return "dim7";
    case "sus2":
      return "sus2";
    case "sus4":
      return "sus4";
    case "add9":
      return "add9";
    case "6":
      return "6";
    case "m6":
      return "m6";
  }
}

export function formatSymbol(rootPc: number, quality: Quality, keyPc: number, force?: "sharp" | "flat"): string {
  return `${spellPc(rootPc, keyPc, force)}${qualitySuffix(quality)}`;
}

function spellingFromParsed(parsed: ParsedNumeral | null): "sharp" | "flat" | undefined {
  if (!parsed) return undefined;
  if (parsed.accidental < 0) return "flat";
  if (parsed.accidental > 0) return "sharp";
  return undefined;
}

export type InstrumentId = "keys" | "nylon";

function bassForInstrument(rootPc: number, instrument: InstrumentId): number {
  const min = instrument === "nylon" ? 40 : 48;
  const max = instrument === "nylon" ? 52 : 60;
  let midi = rootPc;
  while (midi < min) midi += 12;
  while (midi > max) midi -= 12;
  return midi;
}

export function voiceChord(rootPc: number, quality: Quality, instrument: InstrumentId): number[] {
  const intervals = QUALITY_INTERVALS[quality] ?? QUALITY_INTERVALS.maj;
  const bass = bassForInstrument(rootPc, instrument);
  const core = intervals.map((i) => bass + i);
  if (instrument === "nylon") {
    const extra = [bass + 12, bass + (intervals[1] ?? 4) + 12];
    const all = [...core, ...extra];
    return [...new Set(all)].sort((a, b) => a - b);
  }
  const doubled = [...core];
  if (core.length <= 3) doubled.push(bass + 12);
  return [...new Set(doubled)].sort((a, b) => a - b);
}

export function resolveSlot(
  slot: ChordSlot,
  tonic: number,
  scale: ScaleId,
  sevenths: boolean,
  instrument: InstrumentId,
): ResolvedChord {
  const parsed = parseNumeral(slot.numeral);
  const pcs = scalePitchClasses(tonic, scale);
  const degree = parsed?.degree ?? 0;
  const accidental = parsed?.accidental ?? 0;
  const rootPc = (pcs[degree] + accidental + 12) % 12;
  const quality = parsed ? qualityFromNumeral(parsed, tonic, scale, sevenths) : "maj";
  const midi = voiceChord(rootPc, quality, instrument);
  const force = spellingFromParsed(parsed);
  const spellKey = signatureTonic(tonic, scale);
  return {
    id: slot.id,
    numeral: slot.numeral,
    symbol: formatSymbol(rootPc, quality, spellKey, force),
    quality,
    rootPc,
    midi,
    noteNames: midi.map((m) => spellPc(m, spellKey, force)),
    beats: slot.beats,
  };
}

export function resolveProgression(
  slots: ChordSlot[],
  tonic: number,
  scale: ScaleId,
  sevenths: boolean,
  instrument: InstrumentId,
): ResolvedChord[] {
  return slots.map((slot) => resolveSlot(slot, tonic, scale, sevenths, instrument));
}

export type PaletteChord = {
  numeral: string;
  symbol: string;
  quality: Quality;
  rootPc: number;
};

export function diatonicPalette(tonic: number, scale: ScaleId, sevenths: boolean): PaletteChord[] {
  const numerals = SCALE_NUMERALS[scale];
  return numerals.map((numeral) => {
    const parsed = parseNumeral(numeral);
    const pcs = scalePitchClasses(tonic, scale);
    const rootPc = parsed ? (pcs[parsed.degree] + parsed.accidental + 12) % 12 : tonic;
    const quality = parsed ? qualityFromNumeral(parsed, tonic, scale, sevenths) : "maj";
    return { numeral, symbol: formatSymbol(rootPc, quality, signatureTonic(tonic, scale), spellingFromParsed(parsed)), quality, rootPc };
  });
}

export const BORROWED_BY_SCALE: Record<ScaleId, string[]> = {
  major: ["bVII", "bVI", "bIII", "iv", "II", "III"],
  minor: ["V", "iv", "II", "bII"],
  dorian: ["I", "bVII", "iv"],
  mixolydian: ["vi", "bVII", "IV"],
  "harmonic-minor": ["v", "VII", "iv"],
};

export function borrowedPalette(tonic: number, scale: ScaleId, sevenths: boolean): PaletteChord[] {
  return BORROWED_BY_SCALE[scale].map((numeral) => {
    const parsed = parseNumeral(numeral);
    const pcs = scalePitchClasses(tonic, scale);
    const rootPc = parsed ? (pcs[parsed.degree] + parsed.accidental + 12) % 12 : tonic;
    const quality = parsed ? qualityFromNumeral(parsed, tonic, scale, sevenths) : "maj";
    return { numeral, symbol: formatSymbol(rootPc, quality, signatureTonic(tonic, scale), spellingFromParsed(parsed)), quality, rootPc };
  });
}

export type Preset = {
  id: string;
  name: string;
  hint: string;
  scale: ScaleId;
  numerals: string[];
  beats?: number;
};

export const PRESETS: Preset[] = [
  { id: "pop", name: "Pop", hint: "I–V–vi–IV", scale: "major", numerals: ["I", "V", "vi", "IV"] },
  { id: "axis", name: "Axis", hint: "vi–IV–I–V", scale: "major", numerals: ["vi", "IV", "I", "V"] },
  { id: "fifties", name: "50s", hint: "I–vi–IV–V", scale: "major", numerals: ["I", "vi", "IV", "V"] },
  { id: "classic", name: "Classic", hint: "I–IV–V–I", scale: "major", numerals: ["I", "IV", "V", "I"] },
  { id: "canon", name: "Canon", hint: "Pachelbel", scale: "major", numerals: ["I", "V", "vi", "iii", "IV", "I", "IV", "V"] },
  { id: "jazz", name: "Jazz", hint: "ii–V–I–vi", scale: "major", numerals: ["ii", "V7", "Imaj7", "vi"] },
  { id: "doowop", name: "Doo-wop", hint: "I–vi–ii–V", scale: "major", numerals: ["I", "vi", "ii", "V"] },
  { id: "creep", name: "Creep", hint: "I–III–IV–iv", scale: "major", numerals: ["I", "III", "IV", "iv"] },
  { id: "rock", name: "Rock", hint: "I–VII–IV", scale: "mixolydian", numerals: ["I", "VII", "IV"] },
  { id: "epic", name: "Epic", hint: "i–VI–III–VII", scale: "minor", numerals: ["i", "VI", "III", "VII"] },
  { id: "aeolian", name: "Aeolian", hint: "i–VII–VI–VII", scale: "minor", numerals: ["i", "VII", "VI", "VII"] },
  { id: "andalusian", name: "Andalusian", hint: "i–VII–VI–V", scale: "harmonic-minor", numerals: ["i", "VII", "VI", "V"] },
  { id: "ballad", name: "Ballad", hint: "i–VI–iv–V", scale: "harmonic-minor", numerals: ["i", "VI", "iv", "V"] },
  { id: "folk-min", name: "Folk minor", hint: "i–iv–VII–III", scale: "minor", numerals: ["i", "iv", "VII", "III"] },
  {
    id: "blues",
    name: "12-bar",
    hint: "I7–IV7–V7",
    scale: "major",
    numerals: ["I7", "I7", "I7", "I7", "IV7", "IV7", "I7", "I7", "V7", "IV7", "I7", "V7"],
  },
  { id: "amen", name: "Amen", hint: "IV–I", scale: "major", numerals: ["IV", "I"] },
];

export function slotsFromNumerals(numerals: string[], beats = 4): ChordSlot[] {
  return numerals.map((numeral, i) => ({
    id: `slot-${i}-${numeral}`,
    numeral,
    beats,
  }));
}

export function keyLabel(pc: number): string {
  return CHROMATIC_KEYS.find((k) => k.pc === pc)?.label ?? "C";
}

export function scaleName(id: ScaleId): string {
  return SCALES.find((s) => s.id === id)?.name ?? "Major";
}

export function newSlotId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `slot-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

export const DEFAULT_SLOTS: ChordSlot[] = [
  { id: "s1", numeral: "I", beats: 4 },
  { id: "s2", numeral: "V", beats: 4 },
  { id: "s3", numeral: "vi", beats: 4 },
  { id: "s4", numeral: "IV", beats: 4 },
];
