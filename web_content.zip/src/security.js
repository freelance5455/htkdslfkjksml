/* ==========================================================================
   security.js — امنیت محلی: قفل PIN + رمزگذاری خروجی پشتیبان + هش
   هیچ داده‌ای به سرور ارسال نمی‌شود؛ همه‌چیز روی دستگاه انجام می‌شود.
   ========================================================================== */

import { readLS, writeLS, KEYS } from './storage.js';

/** هش سریع (FNV-1a) برای PIN — کافی برای قفل محلی، نه رمزنگاری بانکی */
export function fastHash(str) {
  let h1 = 0x811c9dc5, h2 = 0x1b873593;
  const s = String(str);
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 16777619) >>> 0;
    h2 = Math.imul(h2 + c + i, 2654435761) >>> 0;
  }
  return (h1.toString(36) + '-' + h2.toString(36));
}

export const Security = {
  info() { return readLS(KEYS.security, { pin: null, question: null, answerHash: null, encryptExports: false }); },

  setPin(pin) {
    const info = Security.info();
    info.pin = pin ? fastHash(pin) : null;
    writeLS(KEYS.security, info);
    return true;
  },
  hasPin() { return !!Security.info().pin; },
  checkPin(pin) { return Security.info().pin === fastHash(pin); },
  clearPin() {
    const info = Security.info(); info.pin = null; writeLS(KEYS.security, info);
  },

  setRecovery(question, answer) {
    const info = Security.info();
    info.question = question || null;
    info.answerHash = answer ? fastHash(String(answer).trim().toLowerCase()) : null;
    writeLS(KEYS.security, info);
  },
  checkRecovery(answer) {
    const info = Security.info();
    return info.answerHash && info.answerHash === fastHash(String(answer || '').trim().toLowerCase());
  },
  setEncryptExports(v) {
    const info = Security.info(); info.encryptExports = !!v; writeLS(KEYS.security, info);
  },

  /** رمزگذاری متن با passphrase (XOR-Stream مبتنی بر هش + Base64) — آفلاین و بدون وابستگی */
  encryptText(plain, pass) {
    const keyBytes = streamKey(pass);
    const bytes = new TextEncoder().encode(plain);
    const out = new Uint8Array(bytes.length);
    for (let i = 0; i < bytes.length; i++) out[i] = bytes[i] ^ keyBytes[i % keyBytes.length];
    return 'BPENC1:' + bytesToB64(out);
  },
  decryptText(cipher, pass) {
    if (!String(cipher).startsWith('BPENC1:')) return cipher;
    const bytes = b64ToBytes(String(cipher).slice(7));
    const keyBytes = streamKey(pass);
    const out = new Uint8Array(bytes.length);
    for (let i = 0; i < bytes.length; i++) out[i] = bytes[i] ^ keyBytes[i % keyBytes.length];
    return new TextDecoder().decode(out);
  },
};

function streamKey(pass) {
  let seed = fastHash('bp::' + pass);
  const out = new Uint8Array(64);
  for (let i = 0; i < 64; i++) {
    seed = (Math.imul(seed ^ (seed >>> 15), 2246822519) + i) >>> 0;
    out[i] = seed & 0xff;
  }
  return out;
}
function bytesToB64(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return btoa(s);
}
function b64ToBytes(b64) {
  const s = atob(b64);
  const out = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
  return out;
}

/** ماسک کردن مبالغ حساس در حالت قفل */
export function maskAmount(str) { return String(str).replace(/[۰-۹0-9]/g, '•'); }
