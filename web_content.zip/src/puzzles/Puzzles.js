import { audioManager } from '../audio/AudioManager.js';

export class MedallionPuzzle {
  constructor() {
    this.solved = false;
    // Solutions for statues
    this.solutions = {
      lion: ['lion', 'crown', 'bird'],
      unicorn: ['twin', 'scale', 'worm'],
      maiden: ['maiden', 'bow', 'snake']
    };
    this.currentStatueProgress = {
      lion: false,
      unicorn: false,
      maiden: false
    };
  }

  solveStatue(statueType, codeArray) {
    const target = this.solutions[statueType];
    if (!target) return false;

    const isCorrect = target.every((val, idx) => val === codeArray[idx]);
    if (isCorrect) {
      this.currentStatueProgress[statueType] = true;
      audioManager.playItemPickup();

      // Check if all 3 medallion statues are unlocked
      if (
        this.currentStatueProgress.lion &&
        this.currentStatueProgress.unicorn &&
        this.currentStatueProgress.maiden
      ) {
        this.solved = true;
      }
      return true;
    }
    audioManager.playUIClick();
    return false;
  }
}

export class SafeCombinationPuzzle {
  constructor() {
    this.correctCombo = [9, 15, 7]; // Classic RE2 Safe code: Left 9, Right 15, Left 7
  }

  checkCode(combo) {
    if (
      combo[0] === this.correctCombo[0] &&
      combo[1] === this.correctCombo[1] &&
      combo[2] === this.correctCombo[2]
    ) {
      audioManager.playItemPickup();
      return true;
    }
    audioManager.playUIClick();
    return false;
  }
}
