import { useEffect, useMemo, useRef, useState } from "react";
import { getPuzzle } from "@/data/puzzles";
import { loadAdmin } from "@/game/save";
import { useGame } from "@/game/store";
import { playNotes, sfx } from "@/game/audio";
import { OverlayFrame, StarButton } from "@/ui/chrome";
import { cn } from "@/lib/utils";

export function PuzzleHost() {
  const id = useGame((s) => s.activePuzzle);
  const close = useGame((s) => s.closeModal);
  const solve = useGame((s) => s.solvePuzzle);
  const inventory = useGame((s) => s.inventory);
  const setTimeLayer = useGame((s) => s.setTimeLayer);
  const timeLayer = useGame((s) => s.timeLayer);
  const p = id ? getPuzzle(id) : undefined;
  if (!p || !id) return null;

  return (
    <OverlayFrame title={p.title} onClose={close} wide>
      <p className="mb-4 font-display text-base text-mist">{p.prompt}</p>
      {p.kind === "constellation" && id === "p_tour_fenetres" && <WindowsPuzzle onSolve={() => solve(id)} />}
      {p.kind === "constellation" && id !== "p_tour_fenetres" && (
        <ConstellationPuzzle puzzleId={id} onSolve={() => solve(id)} />
      )}
      {p.kind === "memory" && <MemoryPuzzle puzzleId={id} onSolve={() => solve(id)} />}
      {p.kind === "decrypt" && <DecryptPuzzle puzzleId={id} onSolve={() => solve(id)} />}
      {p.kind === "mist" && <MistPuzzle puzzleId={id} onSolve={() => solve(id)} />}
      {p.kind === "ghost" && <GhostPuzzle puzzleId={id} onSolve={() => solve(id)} />}
      {p.kind === "mirror" && <MirrorPuzzle puzzleId={id} onSolve={() => solve(id)} />}
      {p.kind === "rebuild" && <RebuildPuzzle onSolve={() => solve(id)} />}
      {p.kind === "sound" && <SoundPuzzle onSolve={() => solve(id)} />}
      {p.kind === "portal" && (
        <PortalPuzzle
          hasKey={inventory.includes("sablier_arrete")}
          layer={timeLayer}
          onToggle={() => setTimeLayer(timeLayer === "present" ? "past" : "present")}
          onSolve={() => solve(id)}
        />
      )}
      {p.kind === "final" && id === "p_finale" && <FinalPuzzle onSolve={() => solve(id)} />}
      {p.kind === "final" && id === "p_porte_lien" && <LienPuzzle onSolve={() => solve(id)} inventory={inventory} />}
    </OverlayFrame>
  );
}

function ConstellationPuzzle({ puzzleId, onSolve }: { puzzleId: string; onSolve: () => void }) {
  const targets =
    puzzleId === "p_porte_distance"
      ? [
          { x: 50, y: 50 },
          { x: 50, y: 28 },
          { x: 78, y: 50 },
        ]
      : [
          { x: 50, y: 22 },
          { x: 28, y: 70 },
          { x: 72, y: 70 },
        ];
  const [stars, setStars] = useState([
    { x: 20, y: 40 },
    { x: 55, y: 55 },
    { x: 80, y: 30 },
  ]);
  const drag = useRef<number | null>(null);

  const ok = stars.every((s, i) => {
    const t = targets[i]!;
    const d = Math.hypot(s.x - t.x, s.y - t.y);
    return d < 10;
  });

  return (
    <div>
      <div
        className="relative mx-auto aspect-square w-full max-w-sm touch-none rounded-lg border border-lumen/10 bg-void"
        onPointerMove={(e) => {
          if (drag.current == null) return;
          const rect = e.currentTarget.getBoundingClientRect();
          const x = ((e.clientX - rect.left) / rect.width) * 100;
          const y = ((e.clientY - rect.top) / rect.height) * 100;
          setStars((prev) => prev.map((s, i) => (i === drag.current ? { x, y } : s)));
        }}
        onPointerUp={() => {
          drag.current = null;
        }}
      >
        {targets.map((t, i) => (
          <span
            key={i}
            className="absolute size-3 -translate-x-1/2 -translate-y-1/2 rounded-full border border-lumen/25"
            style={{ left: `${t.x}%`, top: `${t.y}%` }}
          />
        ))}
        {stars.map((s, i) => (
          <button
            key={i}
            type="button"
            className="absolute size-6 -translate-x-1/2 -translate-y-1/2 rounded-full bg-lumen shadow-[0_0_12px_rgba(243,239,230,0.8)]"
            style={{ left: `${s.x}%`, top: `${s.y}%` }}
            onPointerDown={(e) => {
              e.currentTarget.setPointerCapture(e.pointerId);
              drag.current = i;
            }}
          />
        ))}
      </div>
      <StarButton variant="solid" className="mt-4 w-full" disabled={!ok} onClick={onSolve}>
        Aligner
      </StarButton>
    </div>
  );
}

function WindowsPuzzle({ onSolve }: { onSolve: () => void }) {
  const [on, setOn] = useState<boolean[]>(Array(9).fill(false));
  const goal = [1, 6, 8];
  const ok = goal.every((i) => on[i]) && on.every((v, i) => (goal.includes(i) ? v : !v));
  return (
    <div>
      <div className="mx-auto grid w-48 grid-cols-3 gap-2">
        {on.map((v, i) => (
          <button
            key={i}
            type="button"
            onClick={() => setOn((p) => p.map((x, j) => (j === i ? !x : x)))}
            className={cn("h-14 rounded-sm border border-lumen/20", v ? "bg-lumen/80" : "bg-night")}
          />
        ))}
      </div>
      <StarButton variant="solid" className="mt-4 w-full" disabled={!ok} onClick={onSolve}>
        Allumer
      </StarButton>
    </div>
  );
}

function MemoryPuzzle({ puzzleId, onSolve }: { puzzleId: string; onSolve: () => void }) {
  const seq = puzzleId === "p_porte_souvenir" ? ["△", "☽", "○", "◎", "▭"] : ["☽", "✦", "○", "☽"];
  const glyphs = puzzleId === "p_porte_souvenir" ? ["△", "☽", "○", "◎", "▭", "∞"] : ["☽", "✦", "○", "△"];
  const [phase, setPhase] = useState<"show" | "input">("show");
  const [lit, setLit] = useState<number | null>(null);
  const [input, setInput] = useState<string[]>([]);

  useEffect(() => {
    let i = 0;
    const t = window.setInterval(() => {
      if (i >= seq.length) {
        window.clearInterval(t);
        setLit(null);
        setPhase("input");
        return;
      }
      setLit(i);
      i += 1;
    }, 700);
    return () => window.clearInterval(t);
  }, [seq.length]);

  const press = (g: string) => {
    const next = [...input, g];
    setInput(next);
    if (next.length === seq.length) {
      if (next.every((v, i) => v === seq[i])) onSolve();
      else {
        sfx("error");
        setInput([]);
        setPhase("show");
      }
    }
  };

  return (
    <div>
      <p className="mb-3 text-center text-xs uppercase tracking-[0.18em] text-fog">
        {phase === "show" ? "Observe" : "Reproduis"}
      </p>
      <div className="mb-4 flex justify-center gap-2 font-display text-3xl">
        {seq.map((g, i) => (
          <span key={i} className={cn("opacity-20", phase === "show" && lit === i && "opacity-100")}>
            {g}
          </span>
        ))}
      </div>
      <div className="grid grid-cols-4 gap-2">
        {glyphs.map((g) => (
          <StarButton key={g} disabled={phase !== "input"} onClick={() => press(g)}>
            {g}
          </StarButton>
        ))}
      </div>
    </div>
  );
}

function DecryptPuzzle({ puzzleId, onSolve }: { puzzleId: string; onSolve: () => void }) {
  const lunar = ["crescent", "full", "dark"];
  const letters = ["D", "S", "A", "P", "T", "D", "L"];
  const dest = puzzleId === "p_porte_destin";
  const symbols = dest ? letters : ["crescent", "full", "dark", "star"];
  const ringCount = dest ? 7 : 3;
  const [pos, setPos] = useState(() => Array.from({ length: ringCount }, () => 0));
  const target = dest ? letters : lunar;

  const ok = pos.every((p, i) => symbols[p % symbols.length] === target[i]);

  const glyph = (s: string) => (s === "crescent" ? "☽" : s === "full" ? "●" : s === "dark" ? "○" : s === "star" ? "✦" : s);

  return (
    <div className="flex flex-col items-center gap-3">
      {pos.map((p, i) => (
        <button
          key={i}
          type="button"
          onClick={() => setPos((arr) => arr.map((v, j) => (j === i ? (v + 1) % symbols.length : v)))}
          className="flex h-12 w-full max-w-xs items-center justify-between rounded-full border border-lumen/20 px-4"
        >
          <span className="text-xs text-fog">Anneau {i + 1}</span>
          <span className="font-display text-xl">{glyph(symbols[p % symbols.length]!)}</span>
        </button>
      ))}
      <StarButton variant="solid" className="mt-2 w-full" disabled={!ok} onClick={onSolve}>
        Aligner
      </StarButton>
    </div>
  );
}

function MistPuzzle({ puzzleId, onSolve }: { puzzleId: string; onSolve: () => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [revealed, setRevealed] = useState(0);
  const text = puzzleId === "p_porte_absence" ? "IL MANQUE UNE SILHOUETTE" : "NORD-OUEST   ☽";

  useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const w = c.clientWidth;
    const h = c.clientHeight;
    c.width = w * dpr;
    c.height = h * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = "rgba(160,170,190,0.92)";
    ctx.fillRect(0, 0, w, h);
    let cleared = 0;
    const total = w * h;
    const erase = (x: number, y: number) => {
      ctx.globalCompositeOperation = "destination-out";
      ctx.beginPath();
      ctx.arc(x, y, 22, 0, Math.PI * 2);
      ctx.fill();
      cleared += 800;
      setRevealed(Math.min(1, cleared / (total * 0.18)));
    };
    const onMove = (e: PointerEvent) => {
      const r = c.getBoundingClientRect();
      erase(e.clientX - r.left, e.clientY - r.top);
    };
    c.addEventListener("pointerdown", onMove);
    c.addEventListener("pointermove", onMove);
    const refill = window.setInterval(() => {
      ctx.globalCompositeOperation = "source-over";
      ctx.fillStyle = "rgba(160,170,190,0.08)";
      ctx.fillRect(0, 0, w, h);
    }, 900);
    return () => {
      c.removeEventListener("pointerdown", onMove);
      c.removeEventListener("pointermove", onMove);
      window.clearInterval(refill);
    };
  }, []);

  return (
    <div>
      <div className="relative mx-auto h-52 w-full overflow-hidden rounded-lg border border-lumen/10">
        <p className="absolute inset-0 flex items-center justify-center font-display text-xl tracking-[0.2em] text-lumen">
          {text}
        </p>
        <canvas ref={canvasRef} className="absolute inset-0 h-full w-full touch-none" />
      </div>
      <StarButton variant="solid" className="mt-4 w-full" disabled={revealed < 0.55} onClick={onSolve}>
        Mémoriser
      </StarButton>
    </div>
  );
}

function GhostPuzzle({ puzzleId, onSolve }: { puzzleId: string; onSolve: () => void }) {
  const hard = puzzleId !== "p_foret_fantome";
  const [pos, setPos] = useState({ x: 70, y: 40, real: true, visible: false });
  const hits = useRef(0);

  useEffect(() => {
    const pulse = () => {
      const real = Math.random() > (hard ? 0.45 : 0.2);
      setPos({
        x: real ? (hard ? 22 : 74) : 20 + Math.random() * 60,
        y: 20 + Math.random() * 50,
        real,
        visible: true,
      });
      window.setTimeout(() => setPos((p) => ({ ...p, visible: false })), hard ? 420 : 700);
    };
    pulse();
    const t = window.setInterval(pulse, hard ? 1100 : 1400);
    return () => window.clearInterval(t);
  }, [hard]);

  return (
    <div
      className="relative h-56 w-full overflow-hidden rounded-lg bg-void"
      onClick={(e) => {
        if (!pos.visible) return;
        const r = e.currentTarget.getBoundingClientRect();
        const x = ((e.clientX - r.left) / r.width) * 100;
        const y = ((e.clientY - r.top) / r.height) * 100;
        if (Math.hypot(x - pos.x, y - pos.y) < 12) {
          if (pos.real) {
            hits.current += 1;
            if (hits.current >= (hard ? 2 : 1)) onSolve();
            else sfx("soft");
          } else sfx("error");
        }
      }}
    >
      {pos.visible && (
        <span
          className={cn(
            "absolute size-6 -translate-x-1/2 -translate-y-1/2 rounded-full",
            pos.real ? "bg-silver shadow-[0_0_18px_white]" : "bg-lumen/40",
          )}
          style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
        />
      )}
      <p className="absolute bottom-2 w-full text-center text-[0.65rem] uppercase tracking-wider text-fog">Touche la vraie lueur</p>
    </div>
  );
}

function MirrorPuzzle({ puzzleId, onSolve }: { puzzleId: string; onSolve: () => void }) {
  const [flipped, setFlipped] = useState(false);
  const [typed, setTyped] = useState("");
  const admin = loadAdmin();
  const accepted = (admin.puzzleAnswers?.[puzzleId] ?? ["attendent", "elles attendent", "les etoiles ne sont pas mortes elles attendent"]).map(
    (s) => s.toLowerCase(),
  );

  useEffect(() => {
    const handler = (e: DeviceOrientationEvent) => {
      if (Math.abs(e.gamma ?? 0) > 45) setFlipped(true);
    };
    window.addEventListener("deviceorientation", handler);
    return () => window.removeEventListener("deviceorientation", handler);
  }, []);

  const check = () => {
    const n = typed
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .trim();
    if (accepted.some((a) => n.includes(a))) onSolve();
    else sfx("error");
  };

  return (
    <div>
      <p
        className="mb-4 font-display text-lg tracking-wide text-lumen"
        style={{ transform: flipped ? "none" : "scaleX(-1)", direction: flipped ? "ltr" : "rtl" }}
      >
        LES ÉTOILES NE SONT PAS MORTES ELLES ATTENDENT
      </p>
      <StarButton className="mb-3 w-full" onClick={() => setFlipped((f) => !f)}>
        Retourner
      </StarButton>
      <input
        value={typed}
        onChange={(e) => setTyped(e.target.value)}
        placeholder="Ce que tu lis"
        className="mb-3 w-full rounded-md border border-lumen/15 bg-void p-3 text-sm text-lumen"
      />
      <StarButton variant="solid" className="w-full" onClick={check}>
        Confirmer
      </StarButton>
    </div>
  );
}

function RebuildPuzzle({ onSolve }: { onSolve: () => void }) {
  const goal = [0, 1, 2, 3, 4, 5, 6, 7, 8];
  const [tiles, setTiles] = useState(() => {
    const a = [...goal];
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j]!, a[i]!];
    }
    if (a.every((v, i) => v === i)) [a[0], a[1]] = [a[1]!, a[0]!];
    return a;
  });
  const [sel, setSel] = useState<number | null>(null);
  const click = (i: number) => {
    if (sel == null) setSel(i);
    else {
      setTiles((t) => {
        const n = [...t];
        [n[sel], n[i]] = [n[i]!, n[sel]!];
        return n;
      });
      setSel(null);
    }
  };
  const ok = tiles.every((v, i) => v === i);
  return (
    <div>
      <div className="mx-auto grid w-56 grid-cols-3 gap-1">
        {tiles.map((t, i) => (
          <button
            key={i}
            type="button"
            onClick={() => click(i)}
            className={cn(
              "flex h-16 items-center justify-center rounded-sm border border-lumen/15 font-display text-lg",
              sel === i ? "bg-lumen/20" : "bg-night",
            )}
          >
            {["⋆", "☾", "✦", "⌒", "◉", "⌒", "·", "☽", "⋆"][t]}
          </button>
        ))}
      </div>
      <p className="mt-2 text-center text-xs text-fog">Échange les morceaux. La lunette au centre.</p>
      <StarButton variant="solid" className="mt-3 w-full" disabled={!ok} onClick={onSolve}>
        Recomposer
      </StarButton>
    </div>
  );
}

function SoundPuzzle({ onSolve }: { onSolve: () => void }) {
  const seq = useMemo(() => [220, 440, 330, 220], []);
  const notes = [220, 330, 440, 550];
  const [input, setInput] = useState<number[]>([]);
  return (
    <div>
      <StarButton className="mb-4 w-full" onClick={() => playNotes(seq)}>
        Écouter le cristal
      </StarButton>
      <div className="grid grid-cols-4 gap-2">
        {notes.map((n, i) => (
          <StarButton
            key={n}
            onClick={() => {
              playNotes([n], 0);
              const next = [...input, n];
              setInput(next);
              if (next.length === seq.length) {
                if (next.every((v, idx) => v === seq[idx])) onSolve();
                else {
                  sfx("error");
                  setInput([]);
                }
              }
            }}
          >
            {["I", "II", "III", "IV"][i]}
          </StarButton>
        ))}
      </div>
    </div>
  );
}

function PortalPuzzle({
  hasKey,
  layer,
  onToggle,
  onSolve,
}: {
  hasKey: boolean;
  layer: string;
  onToggle: () => void;
  onSolve: () => void;
}) {
  return (
    <div>
      <p className="mb-3 text-sm text-fog">Présent : fermé. Passé : la table n'est pas vide.</p>
      <p className="mb-4 text-xs uppercase tracking-wider text-silver">Couche : {layer === "past" ? "passé" : "présent"}</p>
      <StarButton className="mb-2 w-full" onClick={onToggle}>
        Basculer
      </StarButton>
      <StarButton variant="solid" className="w-full" disabled={!hasKey} onClick={onSolve}>
        Utiliser l'heure arrêtée
      </StarButton>
    </div>
  );
}

function LienPuzzle({ onSolve, inventory }: { onSolve: () => void; inventory: string[] }) {
  const need = ["eclat_aube", "fragment_lune", "fragment_temporel", "fragment_miroir"];
  const ok = need.every((id) => inventory.includes(id) || inventory.includes("lentille_passe") || inventory.includes("lentille_naissante"));
  const hasCore = inventory.includes("lentille_passe") || (inventory.includes("lentille_naissante") && inventory.includes("fragment_temporel"));
  return (
    <div>
      <p className="mb-4 text-sm text-mist">Les fragments majeurs doivent être présents. La lentille du passé est le centre.</p>
      <StarButton variant="solid" className="w-full" disabled={!(ok || hasCore)} onClick={onSolve}>
        Relier
      </StarButton>
    </div>
  );
}

function FinalPuzzle({ onSolve }: { onSolve: () => void }) {
  const flags = useGame((s) => s.flags);
  const inventory = useGame((s) => s.inventory);
  const [h, setH] = useState(12);
  const [m, setM] = useState(0);
  const [tri, setTri] = useState([false, false, false]);
  const [word, setWord] = useState("");
  const [order, setOrder] = useState("");
  const starsReady = ["solved_seuil", "traces_found", "solved_rebuild", "solved_miroir", "act5_door", "door_lien", "false_reveal_done", "act8_understood"].every(
    (f) => flags[f],
  );
  const has = inventory.includes("cle_seuil") && inventory.includes("lentille_passe");
  const ok =
    h === 21 &&
    m === 7 &&
    tri.every(Boolean) &&
    word
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .includes("attendent") &&
    order.replace(/\s/g, "").toUpperCase() === "DSAPTDL" &&
    has &&
    starsReady;

  return (
    <div className="space-y-4">
      <p className="text-xs text-fog">L'heure du miroir. Le triangle. L'ordre des sept. Le mot du livre.</p>
      <div className="flex gap-2">
        <label className="flex-1 text-xs text-fog">
          Heure
          <input type="number" min={0} max={23} value={h} onChange={(e) => setH(Number(e.target.value))} className="mt-1 w-full rounded-md border border-lumen/15 bg-void p-2 text-lumen" />
        </label>
        <label className="flex-1 text-xs text-fog">
          Minutes
          <input type="number" min={0} max={59} value={m} onChange={(e) => setM(Number(e.target.value))} className="mt-1 w-full rounded-md border border-lumen/15 bg-void p-2 text-lumen" />
        </label>
      </div>
      <div className="flex justify-center gap-3">
        {tri.map((v, i) => (
          <button
            key={i}
            type="button"
            onClick={() => setTri((t) => t.map((x, j) => (j === i ? !x : x)))}
            className={cn("size-8 rounded-full border", v ? "bg-lumen" : "border-lumen/30")}
          />
        ))}
      </div>
      <input
        value={order}
        onChange={(e) => setOrder(e.target.value)}
        placeholder="Sept initiales"
        className="w-full rounded-md border border-lumen/15 bg-void p-2 text-sm text-lumen"
      />
      <input
        value={word}
        onChange={(e) => setWord(e.target.value)}
        placeholder="Le mot du livre"
        className="w-full rounded-md border border-lumen/15 bg-void p-2 text-sm text-lumen"
      />
      <StarButton variant="solid" className="w-full" disabled={!ok} onClick={onSolve}>
        Ouvrir le seuil
      </StarButton>
    </div>
  );
}
