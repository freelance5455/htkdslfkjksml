/**
 * GODEX Phase 4 - Process Lifecycle Manager
 * Controls process execution, monitoring, timeout cancellation, dev server lifecycle,
 * and port association.
 */

import { 
  ProcessInfo, 
  ExecutionStatus, 
  DevServerInfo, 
  DevServerState, 
  ExecutionRequest 
} from './executionTypes';
import { OutputCollector } from './outputCollector';
import { PortManager } from './portManager';

export class ProcessManager {
  private activeProcesses: Map<string, ProcessInfo> = new Map();
  private outputCollectors: Map<string, OutputCollector> = new Map();
  private timeoutHandles: Map<string, NodeJS.Timeout> = new Map();
  private currentDevServer: DevServerInfo | null = null;
  private maxConcurrentProcesses: number = 3;

  /**
   * Spawns and tracks a new process entry.
   */
  public createProcess(request: ExecutionRequest): { process: ProcessInfo; collector: OutputCollector } {
    // Check concurrent limits
    const runningCount = Array.from(this.activeProcesses.values()).filter(p => p.status === 'RUNNING').length;
    if (runningCount >= this.maxConcurrentProcesses && request.requestedBy === 'GODEX_AGENT') {
      throw new Error(`Process concurrency limit reached (${this.maxConcurrentProcesses} max concurrent agent executions).`);
    }

    const processId = request.id || `proc-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const collector = new OutputCollector();

    const procInfo: ProcessInfo = {
      id: processId,
      command: request.command,
      args: request.arguments || [],
      status: 'STARTING',
      requestedBy: request.requestedBy,
      startTime: Date.now(),
      workingDirectory: request.workingDirectory || '/project',
      ports: [],
      reason: request.reason || 'Project execution request',
      isCancelled: false,
      isTimedOut: false
    };

    this.activeProcesses.set(processId, procInfo);
    this.outputCollectors.set(processId, collector);

    // Setup timeout guard
    const timeoutMs = request.timeoutMs || 30000;
    if (timeoutMs > 0) {
      const handle = setTimeout(() => {
        this.handleTimeout(processId);
      }, timeoutMs);
      this.timeoutHandles.set(processId, handle);
    }

    return { process: procInfo, collector };
  }

  /**
   * Updates a process state to RUNNING.
   */
  public markRunning(processId: string, pid?: number) {
    const proc = this.activeProcesses.get(processId);
    if (!proc) return;
    proc.status = 'RUNNING';
    if (pid) proc.pid = pid;
  }

  /**
   * Completes a process with an exit code.
   */
  public markCompleted(processId: string, exitCode: number): ProcessInfo | undefined {
    const proc = this.activeProcesses.get(processId);
    if (!proc) return undefined;

    this.clearTimeoutHandle(processId);

    proc.endTime = Date.now();
    proc.durationMs = proc.endTime - proc.startTime;
    proc.exitCode = exitCode;

    if (proc.isTimedOut) {
      proc.status = 'TIMED_OUT';
    } else if (proc.isCancelled) {
      proc.status = 'CANCELLED';
    } else if (exitCode === 0) {
      proc.status = 'COMPLETED';
    } else {
      proc.status = 'FAILED';
    }

    PortManager.releasePortsForProcess(processId);
    return proc;
  }

  /**
   * Cancels an active process.
   */
  public cancelProcess(processId: string): boolean {
    const proc = this.activeProcesses.get(processId);
    if (!proc) return false;

    if (proc.status === 'RUNNING' || proc.status === 'STARTING') {
      proc.isCancelled = true;
      proc.status = 'CANCELLED';
      proc.endTime = Date.now();
      proc.durationMs = proc.endTime - proc.startTime;
      proc.exitCode = 130; // Standard SIGINT exit code

      const collector = this.outputCollectors.get(processId);
      if (collector) {
        collector.appendStderr(`\n[PROCESS_TERMINATED] Process cancelled by user.`);
      }

      this.clearTimeoutHandle(processId);
      PortManager.releasePortsForProcess(processId);
      return true;
    }

    return false;
  }

  /**
   * Handles process execution timeout.
   */
  private handleTimeout(processId: string) {
    const proc = this.activeProcesses.get(processId);
    if (!proc) return;

    if (proc.status === 'RUNNING' || proc.status === 'STARTING') {
      proc.isTimedOut = true;
      proc.status = 'TIMED_OUT';
      proc.endTime = Date.now();
      proc.durationMs = proc.endTime - proc.startTime;
      proc.exitCode = 124; // Standard timeout exit code

      const collector = this.outputCollectors.get(processId);
      if (collector) {
        collector.appendStderr(`\n[PROCESS_TIMEOUT] Execution exceeded configured timeout limit.`);
      }

      this.clearTimeoutHandle(processId);
      PortManager.releasePortsForProcess(processId);
    }
  }

  /**
   * Manages the Development Server lifecycle.
   */
  public setDevServerState(state: DevServerState, port: number = 5173, url?: string, pid?: number): DevServerInfo {
    if (!this.currentDevServer) {
      this.currentDevServer = {
        processId: `dev-server-${Date.now()}`,
        state,
        port,
        url: url || `http://localhost:${port}`,
        pid,
        startTime: Date.now(),
        isReady: false
      };
    } else {
      this.currentDevServer.state = state;
      this.currentDevServer.port = port;
      if (url) this.currentDevServer.url = url;
      if (pid) this.currentDevServer.pid = pid;
    }

    if (state === 'RUNNING') {
      PortManager.registerPort(port, this.currentDevServer.processId, 'Vite Development Server');
      this.currentDevServer.isReady = true;
    } else if (state === 'STOPPED' || state === 'FAILED') {
      PortManager.releasePortsForProcess(this.currentDevServer.processId);
      this.currentDevServer.isReady = false;
    }

    return { ...this.currentDevServer };
  }

  public getDevServerInfo(): DevServerInfo | null {
    return this.currentDevServer ? { ...this.currentDevServer } : null;
  }

  public getProcess(processId: string): ProcessInfo | undefined {
    return this.activeProcesses.get(processId);
  }

  public getCollector(processId: string): OutputCollector | undefined {
    return this.outputCollectors.get(processId);
  }

  public getRunningProcesses(): ProcessInfo[] {
    return Array.from(this.activeProcesses.values()).filter(p => p.status === 'RUNNING' || p.status === 'STARTING');
  }

  private clearTimeoutHandle(processId: string) {
    const handle = this.timeoutHandles.get(processId);
    if (handle) {
      clearTimeout(handle);
      this.timeoutHandles.delete(processId);
    }
  }

  public cleanup() {
    for (const handle of this.timeoutHandles.values()) {
      clearTimeout(handle);
    }
    this.timeoutHandles.clear();
    this.activeProcesses.clear();
    this.outputCollectors.clear();
    this.currentDevServer = null;
    PortManager.reset();
  }
}
