/**
 * GODEX Phase 4 - Safe Command Execution Policy Engine
 * Enforces strict workspace boundaries, blocked command signatures, review requirements,
 * path traversal guards, and privilege escalation prevention.
 */

import { 
  ExecutionPolicyResult, 
  PolicyClassification, 
  RequestedBy, 
  ExecutionRequest 
} from './executionTypes';

export class ExecutionPolicyEngine {
  private static readonly WORKSPACE_ROOT = '/project';

  // Explicitly blocked command patterns
  private static readonly BLOCKED_PATTERNS: Array<{ regex: RegExp; reason: string }> = [
    // Privilege escalation
    { regex: /(^|\s)(sudo|su|doas|pkexec)(\s|$)/i, reason: 'Privilege escalation commands are strictly forbidden.' },
    { regex: /chmod\s+([0-7]{3,4}|[+-][rwxXst]+)\s+(\/|~|\.\.)/i, reason: 'Modifying root or parent directory permissions is blocked.' },
    
    // System-level destructive operations
    { regex: /rm\s+(-[a-zA-Z]*r[a-zA-Z]*f*|-[a-zA-Z]*f[a-zA-Z]*r*)\s+(\/|\/\*|~|\.\.|\.\.\/)/i, reason: 'Destructive root or parent directory deletion is blocked.' },
    { regex: /(^|\s)(mkfs(?:\.[a-zA-Z0-9_-]+)?|fdisk|parted|dd\s+if=)(\s|$)/i, reason: 'Direct disk formatting and raw device operations are blocked.' },
    { regex: /:\(\)\{\s*:\s*\|\s*:\s*&\s*\}\s*;/i, reason: 'Fork-bomb attack patterns are strictly blocked.' },
    
    // Credential extraction & system sensitive file probes
    { regex: /(\/etc\/(shadow|passwd|master\.passwd|sudoers)|\/root\/|~?\/\.ssh\/|\.aws\/credentials|\.config\/gcloud)/i, reason: 'Access to system credential files and private key stores is blocked.' },
    
    // Remote payload piping to shell
    { regex: /(curl|wget|fetch|nc|netcat)\s+.*\|\s*(bash|sh|zsh|dash|python|perl|eval)/i, reason: 'Piping untrusted remote content into shell interpreters is blocked.' },
    
    // Network scanning & penetration tools
    { regex: /(^|\s)(nmap|masscan|hydra|aircrack|nikto|sqlmap|msfconsole)(\s|$)/i, reason: 'Network scanning and penetration testing tools are blocked.' },
    
    // Destructive database operations
    { regex: /(DROP\s+DATABASE|TRUNCATE\s+TABLE|DROP\s+TABLE\s+users|FLUSHALL)/i, reason: 'Unbounded destructive database wipe commands are blocked.' },
    
    // System-level package manager executions
    { regex: /(^|\s)(apt|apt-get|yum|apk|pacman|brew|dnf|emerge)\s+(install|remove|purge)/i, reason: 'System-level OS package manager modifications are blocked inside sandbox.' }
  ];

  // Review-required command patterns (need explicit user confirmation or review flag)
  private static readonly REVIEW_REQUIRED_PATTERNS: Array<{ regex: RegExp; reason: string }> = [
    { regex: /(^|\s)(npm|pnpm|yarn|bun)\s+(install|add|remove|upgrade|update)(\s|$)/i, reason: 'Package dependency alterations require human review.' },
    { regex: /(^|\s)(npx|pnpx|yarn\s+dlx)(\s|$)/i, reason: 'Running ephemeral NPX binaries requires review.' },
    { regex: /(^|\s)(git\s+(push|commit|rebase|reset\s+--hard|checkout\s+-f))(\s|$)/i, reason: 'Destructive or remote Git operations require explicit review.' },
    { regex: /(prisma\s+migrate|typeorm\s+migration|knex\s+migrate|alembic\s+upgrade)/i, reason: 'Database migrations require review.' },
    { regex: /(^|\s)kill(\s+-9)?\s+\d+/i, reason: 'Explicit PID killing requires confirmation.' }
  ];

  // Known safe project commands
  private static readonly SAFE_COMMAND_WHITELIST: string[] = [
    'npm test',
    'npm run test',
    'npm run build',
    'npm run lint',
    'npm run typecheck',
    'npm run dev',
    'npm start',
    'npx tsc --noEmit',
    'git status',
    'git diff',
    'git log',
    'node --version',
    'npm --version',
    'ls',
    'pwd',
    'echo'
  ];

  /**
   * Evaluates an execution request against safety policies, workspace boundaries, and classification tiers.
   */
  public static evaluate(request: ExecutionRequest): ExecutionPolicyResult {
    const rawCommand = request.command.trim();
    const args = request.arguments || [];
    const fullCommandLine = [rawCommand, ...args].join(' ').trim();
    const workingDir = request.workingDirectory || this.WORKSPACE_ROOT;

    const matchedRules: string[] = [];
    const reasons: string[] = [];

    // 1. Workspace Boundary Check & Path Traversal Prevention
    const pathCheck = this.validateWorkspaceBoundary(workingDir, fullCommandLine);
    if (!pathCheck.valid) {
      return {
        allowed: false,
        classification: 'BLOCKED',
        reasons: [pathCheck.reason],
        requiresApproval: false,
        normalizedWorkingDirectory: pathCheck.normalizedPath,
        sanitizedCommand: fullCommandLine,
        matchedRules: ['WORKSPACE_TRAVERSAL_VIOLATION']
      };
    }

    // 2. Blocked Pattern Check
    for (const item of this.BLOCKED_PATTERNS) {
      if (item.regex.test(fullCommandLine)) {
        matchedRules.push(item.reason);
        reasons.push(item.reason);
        return {
          allowed: false,
          classification: 'BLOCKED',
          reasons,
          requiresApproval: false,
          normalizedWorkingDirectory: pathCheck.normalizedPath,
          sanitizedCommand: fullCommandLine,
          matchedRules
        };
      }
    }

    // 3. Review Required Check
    let requiresApproval = false;
    for (const item of this.REVIEW_REQUIRED_PATTERNS) {
      if (item.regex.test(fullCommandLine)) {
        matchedRules.push(item.reason);
        reasons.push(item.reason);
        requiresApproval = true;
      }
    }

    if (request.requiresApproval) {
      requiresApproval = true;
    }

    // 4. Safe Whitelist & Command Classification
    const isWhitelisted = this.SAFE_COMMAND_WHITELIST.some(safe => 
      fullCommandLine === safe || fullCommandLine.startsWith(safe + ' ')
    );

    let classification: PolicyClassification = 'SAFE';
    if (requiresApproval) {
      classification = 'REVIEW_REQUIRED';
    } else if (!isWhitelisted && request.requestedBy === 'GODEX_AGENT') {
      // Unrecognized arbitrary command requested by agent defaults to review required
      if (!this.isBenignScript(fullCommandLine)) {
        classification = 'REVIEW_REQUIRED';
        requiresApproval = true;
        reasons.push('Unlisted agent command requires policy review.');
        matchedRules.push('AGENT_ARBITRARY_COMMAND_POLICY');
      }
    }

    return {
      allowed: (classification as PolicyClassification) !== 'BLOCKED',
      classification,
      reasons: reasons.length > 0 ? reasons : ['Command conforms to standard safe execution profile.'],
      requiresApproval,
      normalizedWorkingDirectory: pathCheck.normalizedPath,
      sanitizedCommand: fullCommandLine,
      matchedRules
    };
  }

  /**
   * Validates path traversal attempts and ensures directory remains inside the workspace boundary.
   */
  public static validateWorkspaceBoundary(workingDir: string, commandLine: string): {
    valid: boolean;
    normalizedPath: string;
    reason: string;
  } {
    const normalized = this.normalizePath(workingDir);

    // Reject traversal escaping workspace root
    if (normalized.startsWith('../') || normalized === '..' || (!normalized.startsWith('/project') && normalized !== '/' && normalized !== '.')) {
      if (normalized.includes('/etc') || normalized.includes('/root') || normalized.includes('/var') || normalized.includes('/home')) {
        return {
          valid: false,
          normalizedPath: normalized,
          reason: `Access outside workspace boundary is blocked: "${workingDir}".`
        };
      }
    }

    // Check for traversal in command arguments (e.g. cat ../../etc/passwd)
    const dangerousPathMatches = commandLine.match(/(\.\.\/){2,}|(\/etc\/|\/root\/|\/sys\/|\/proc\/)/gi);
    if (dangerousPathMatches) {
      return {
        valid: false,
        normalizedPath: normalized,
        reason: `Command attempts path traversal outside workspace boundary: "${dangerousPathMatches[0]}".`
      };
    }

    return {
      valid: true,
      normalizedPath: normalized || this.WORKSPACE_ROOT,
      reason: 'Workspace boundary maintained.'
    };
  }

  private static normalizePath(targetPath: string): string {
    if (!targetPath) return this.WORKSPACE_ROOT;
    const parts = targetPath.replace(/\\/g, '/').split('/');
    const stack: string[] = [];

    for (const part of parts) {
      if (!part || part === '.') continue;
      if (part === '..') {
        if (stack.length > 0) stack.pop();
      } else {
        stack.push(part);
      }
    }

    return '/' + stack.join('/');
  }

  private static isBenignScript(cmd: string): boolean {
    const benignPrefixes = [
      'npm run ',
      'npx vitest',
      'npx jest',
      'npx eslint',
      'npx prettier',
      'npx rimraf dist',
      'tsc',
      'vite build',
      'node '
    ];
    return benignPrefixes.some(p => cmd.startsWith(p));
  }
}
