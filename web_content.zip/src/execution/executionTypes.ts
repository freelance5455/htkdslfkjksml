/**
 * GODEX Phase 4 - Controlled Execution & Sandbox Engine Types
 * Clean typed contracts for processes, commands, outputs, policies, ports, and evidence.
 */

export type ExecutionStatus =
  | 'QUEUED'
  | 'STARTING'
  | 'RUNNING'
  | 'COMPLETED'
  | 'FAILED'
  | 'TIMED_OUT'
  | 'CANCELLED'
  | 'BLOCKED';

export type PolicyClassification =
  | 'SAFE'
  | 'REVIEW_REQUIRED'
  | 'BLOCKED';

export type RequestedBy =
  | 'USER'
  | 'GODEX_AGENT'
  | 'SYSTEM_VALIDATION';

export type OutputStreamType = 'STDOUT' | 'STDERR';

export type StandardProjectScript =
  | 'TEST'
  | 'BUILD'
  | 'LINT'
  | 'TYPECHECK'
  | 'DEV_SERVER'
  | 'START';

export type FailureClassification =
  | 'COMMAND_NOT_FOUND'
  | 'PERMISSION_DENIED'
  | 'TIMEOUT'
  | 'PROCESS_CRASH'
  | 'EXIT_CODE_FAILURE'
  | 'BUILD_FAILURE'
  | 'TEST_FAILURE'
  | 'LINT_FAILURE'
  | 'TYPECHECK_FAILURE'
  | 'WORKSPACE_VIOLATION'
  | 'UNKNOWN';

export type EpistemicClassification = 'KNOWN' | 'LIKELY' | 'UNKNOWN';

export type DevServerState =
  | 'STARTING'
  | 'RUNNING'
  | 'STOPPING'
  | 'STOPPED'
  | 'FAILED';

export interface ProcessStreamChunk {
  id: string;
  timestamp: number;
  stream: OutputStreamType;
  message: string;
}

export interface EnvironmentPolicy {
  allowNetwork: boolean;
  maskedKeys: string[];
  customEnv?: Record<string, string>;
  inheritSafeEnv?: boolean;
}

export interface ExecutionRequest {
  id: string;
  command: string;
  arguments?: string[];
  workingDirectory: string;
  environmentPolicy?: EnvironmentPolicy;
  timeoutMs: number;
  requestedBy: RequestedBy;
  reason: string;
  createdAt: number;
  resolvedScriptType?: StandardProjectScript;
  requiresApproval?: boolean;
  purpose?: string;
}

export interface ExecutionPolicyResult {
  allowed: boolean;
  classification: PolicyClassification;
  reasons: string[];
  requiresApproval: boolean;
  normalizedWorkingDirectory: string;
  sanitizedCommand: string;
  matchedRules: string[];
}

export interface PortInfo {
  port: number;
  processId: string;
  workspacePath: string;
  purpose: string;
  state: 'LISTENING' | 'RELEASED' | 'OCCUPIED';
  url: string;
  detectedAt: number;
}

export interface DevServerInfo {
  processId: string;
  state: DevServerState;
  port: number;
  url: string;
  pid?: number;
  startTime: number;
  isReady: boolean;
  readyCheckUrl?: string;
  lastHealthCheck?: {
    status: 'HEALTHY' | 'UNHEALTHY' | 'PENDING';
    checkedAt: number;
    latencyMs?: number;
  };
}

export interface ProcessInfo {
  id: string;
  pid?: number;
  command: string;
  args: string[];
  status: ExecutionStatus;
  requestedBy: RequestedBy;
  startTime: number;
  endTime?: number;
  durationMs?: number;
  workingDirectory: string;
  exitCode?: number;
  ports: number[];
  reason: string;
  isCancelled: boolean;
  isTimedOut: boolean;
}

export interface ExecutionEvidence {
  executionId: string;
  command: string;
  resolvedScript?: StandardProjectScript;
  status: ExecutionStatus;
  exitCode: number;
  durationMs: number;
  startedAt: number;
  finishedAt: number;
  requestedBy: RequestedBy;
  workingDirectory: string;
  outputSummary: string;
  totalStdoutLines: number;
  totalStderrLines: number;
  failureClassification?: FailureClassification;
  epistemic: {
    known: string[];
    likely: string[];
    unknown: string[];
  };
  source: 'actual_process_output' | 'ast_esbuild_sandbox';
}

export interface ExecutionResult {
  id: string;
  command: string;
  status: ExecutionStatus;
  exitCode: number;
  stdout: string;
  stderr: string;
  durationMs: number;
  chunks: ProcessStreamChunk[];
  evidence: ExecutionEvidence;
  policy: ExecutionPolicyResult;
  ports?: PortInfo[];
  error?: string;
}

export interface ExecutionError {
  code: FailureClassification;
  message: string;
  exitCode?: number;
  details?: string;
  epistemicConfidence: EpistemicClassification;
}

export type ExecutionEventListener = (event: {
  type:
    | 'EXECUTION_REQUESTED'
    | 'COMMAND_RESOLVED'
    | 'POLICY_EVALUATED'
    | 'EXECUTION_STARTED'
    | 'OUTPUT_RECEIVED'
    | 'PORT_DETECTED'
    | 'DEV_SERVER_STATE_CHANGED'
    | 'EXECUTION_COMPLETED'
    | 'EXECUTION_FAILED'
    | 'EXECUTION_CANCELLED'
    | 'EXECUTION_TIMED_OUT';
  executionId: string;
  timestamp: number;
  data: any;
}) => void;
