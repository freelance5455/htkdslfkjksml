/**
 * GODEX Phase 4 - Structured Output Collector & Streamer
 * Captures, separates, and timestamps stdout/stderr with memory-safe buffer limits,
 * live listeners for progressive streaming, and secret sanitization.
 */

import { ProcessStreamChunk, OutputStreamType } from './executionTypes';
import { EnvironmentManager } from './environmentManager';

export class OutputCollector {
  private chunks: ProcessStreamChunk[] = [];
  private stdoutLines: string[] = [];
  private stderrLines: string[] = [];
  private maxRetainedLines: number = 5000;
  private isTruncated: boolean = false;
  private listeners: Set<(chunk: ProcessStreamChunk) => void> = new Set();

  constructor(maxLines: number = 5000) {
    this.maxRetainedLines = maxLines;
  }

  /**
   * Subscribes a listener to receive progressive stream chunks in real-time.
   */
  public subscribe(listener: (chunk: ProcessStreamChunk) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  /**
   * Appends output from a specific stream (STDOUT or STDERR).
   */
  public append(stream: OutputStreamType, rawText: string) {
    if (!rawText) return;

    // Sanitize any potential secrets from the raw text
    const sanitized = EnvironmentManager.sanitizeOutput(rawText);
    const lines = sanitized.split('\n');

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      // Skip trailing empty line from split
      if (i === lines.length - 1 && line === '' && lines.length > 1) continue;

      if (stream === 'STDOUT') {
        if (this.stdoutLines.length < this.maxRetainedLines) {
          this.stdoutLines.push(line);
        } else {
          this.isTruncated = true;
        }
      } else {
        if (this.stderrLines.length < this.maxRetainedLines) {
          this.stderrLines.push(line);
        } else {
          this.isTruncated = true;
        }
      }

      const chunk: ProcessStreamChunk = {
        id: `chunk-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        timestamp: Date.now(),
        stream,
        message: line
      };

      if (this.chunks.length < this.maxRetainedLines * 2) {
        this.chunks.push(chunk);
      }

      // Notify all live streaming subscribers
      for (const listener of this.listeners) {
        try {
          listener(chunk);
        } catch {
          // Ignore subscriber errors
        }
      }
    }
  }

  public appendStdout(text: string) {
    this.append('STDOUT', text);
  }

  public appendStderr(text: string) {
    this.append('STDERR', text);
  }

  public getStdout(): string {
    return this.stdoutLines.join('\n');
  }

  public getStderr(): string {
    return this.stderrLines.join('\n');
  }

  public getChunks(): ProcessStreamChunk[] {
    return [...this.chunks];
  }

  public getTotalStdoutLines(): number {
    return this.stdoutLines.length;
  }

  public getTotalStderrLines(): number {
    return this.stderrLines.length;
  }

  public getSummary(): string {
    if (this.stderrLines.length > 0) {
      const lastErrors = this.stderrLines.slice(-5).join('; ');
      return `Stderr (${this.stderrLines.length} lines): ${lastErrors.slice(0, 200)}`;
    }

    if (this.stdoutLines.length > 0) {
      // Look for test pass lines or build success lines
      const passLine = this.stdoutLines.find(l => l.includes('passed') || l.includes('PASS') || l.includes('Built in') || l.includes('ready'));
      if (passLine) return passLine.trim();
      const lastLine = this.stdoutLines[this.stdoutLines.length - 1];
      return lastLine ? lastLine.trim().slice(0, 150) : 'Execution finished cleanly.';
    }

    return 'No output produced.';
  }

  public clear() {
    this.chunks = [];
    this.stdoutLines = [];
    this.stderrLines = [];
    this.isTruncated = false;
  }
}
