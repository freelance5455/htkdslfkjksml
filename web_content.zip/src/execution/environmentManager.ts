/**
 * GODEX Phase 4 - Environment Manager & Secret Redaction
 * Protects environment credentials, masks secret keys in logs/streams,
 * and maintains sanitized runtime execution environments.
 */

import { EnvironmentPolicy } from './executionTypes';

export class EnvironmentManager {
  private static readonly SENSITIVE_KEY_PATTERNS = [
    /API_?KEY/i,
    /SECRET/i,
    /TOKEN/i,
    /PASSWORD/i,
    /PASSWD/i,
    /DATABASE_URL/i,
    /DB_PASS/i,
    /PRIVATE_KEY/i,
    /CREDENTIAL/i,
    /AUTH/i,
    /BEARER/i,
    /SIGNING_KEY/i,
    /WEBHOOK_SECRET/i,
    /STRIPE_KEY/i,
    /AWS_SECRET/i,
    /GEMINI_API_KEY/i
  ];

  // Regex signatures for leaked secret patterns in raw text (e.g. AIza..., Bearer ..., sk_live_...)
  private static readonly VALUE_REDACTION_PATTERNS: Array<{ regex: RegExp; replaceWith: string }> = [
    { regex: /AIza[0-9A-Za-z-_]{20,45}/g, replaceWith: 'AIza[REDACTED_GOOGLE_KEY]' },
    { regex: /sk_live_[0-9a-zA-Z]{24,}/g, replaceWith: 'sk_live_[REDACTED_STRIPE_KEY]' },
    { regex: /sk_test_[0-9a-zA-Z]{24,}/g, replaceWith: 'sk_test_[REDACTED_STRIPE_KEY]' },
    { regex: /ghp_[0-9a-zA-Z]{36}/g, replaceWith: 'ghp_[REDACTED_GITHUB_TOKEN]' },
    { regex: /Bearer\s+[A-Za-z0-9\-_=]+\.[A-Za-z0-9\-_=]+\.?[A-Za-z0-9\-_.+/=]*/g, replaceWith: 'Bearer [REDACTED_JWT]' },
    { regex: /(postgres|mysql|mongodb(?:\+srv)?):\/\/[^:\s]+:([^@\s]+)@/g, replaceWith: '$1://[REDACTED_USER]:[REDACTED_PASSWORD]@' }
  ];

  private static customMaskedValues: Set<string> = new Set();

  /**
   * Registers a known sensitive value to ensure it is always masked from output streams.
   */
  public static registerSensitiveValue(val: string) {
    if (val && val.length > 5) {
      this.customMaskedValues.add(val);
    }
  }

  /**
   * Sanitizes a stream output string by masking any recognized secrets or environment values.
   */
  public static sanitizeOutput(rawText: string): string {
    if (!rawText) return '';
    let sanitized = rawText;

    // Apply known regex redactions
    for (const pattern of this.VALUE_REDACTION_PATTERNS) {
      sanitized = sanitized.replace(pattern.regex, pattern.replaceWith);
    }

    // Redact explicit registered secrets
    for (const val of this.customMaskedValues) {
      if (sanitized.includes(val)) {
        sanitized = sanitized.replaceAll(val, '********');
      }
    }

    // Redact key-value env dumps (e.g. GEMINI_API_KEY=xyz123)
    sanitized = sanitized.replace(
      /([A-Z0-9_]*(?:API_KEY|SECRET|TOKEN|PASSWORD|PASSWD|KEY)[A-Z0-9_]*)=([^\s\n\r]+)/gi,
      (_match, key) => `${key}=********`
    );

    return sanitized;
  }

  /**
   * Returns a sanitized environment map suitable for passing to execution subprocesses.
   * Strips out forbidden keys unless explicitly requested by policy.
   */
  public static createExecutionEnvironment(policy?: EnvironmentPolicy): Record<string, string> {
    const env: Record<string, string> = {
      NODE_ENV: 'development',
      PATH: '/usr/local/bin:/usr/bin:/bin',
      FORCE_COLOR: '1',
      CI: 'true'
    };

    if (policy?.customEnv) {
      for (const [k, v] of Object.entries(policy.customEnv)) {
        if (this.isSensitiveKey(k)) {
          this.registerSensitiveValue(v);
        }
        env[k] = v;
      }
    }

    return env;
  }

  /**
   * Returns a safely displayable view of environment variables for UI inspection.
   * All sensitive keys are masked with '********'.
   */
  public static getDisplayEnvironment(envRecord: Record<string, string>): Record<string, string> {
    const display: Record<string, string> = {};
    for (const [k, v] of Object.entries(envRecord)) {
      if (this.isSensitiveKey(k)) {
        display[k] = '********';
      } else {
        display[k] = v;
      }
    }
    return display;
  }

  /**
   * Checks whether a variable name corresponds to a sensitive credential or secret.
   */
  public static isSensitiveKey(key: string): boolean {
    return this.SENSITIVE_KEY_PATTERNS.some(p => p.test(key));
  }
}
