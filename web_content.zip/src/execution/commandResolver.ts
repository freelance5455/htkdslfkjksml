/**
 * GODEX Phase 4 - Command Resolver
 * Maps high-level intent / standard execution types (TEST, BUILD, LINT, TYPECHECK, DEV_SERVER)
 * to grounded commands declared in package.json or workspace configuration.
 */

import { StandardProjectScript } from './executionTypes';

export interface ResolvedCommandInfo {
  standardType?: StandardProjectScript;
  originalInput: string;
  command: string;
  args: string[];
  fullCommandLine: string;
  scriptKey?: string;
  source: 'package_json' | 'framework_default' | 'raw_command';
  explanation: string;
}

export class CommandResolver {
  /**
   * Resolves a standard project script type or raw command string into a concrete executable command.
   */
  public static resolve(
    target: StandardProjectScript | string,
    workspaceFiles: Record<string, string>
  ): ResolvedCommandInfo {
    const pkgJson = this.extractPackageJson(workspaceFiles);
    const scripts = pkgJson?.scripts || {};

    // Check if target is a standard enum
    if (this.isStandardScript(target)) {
      return this.resolveStandardScript(target as StandardProjectScript, scripts, workspaceFiles);
    }

    const trimmed = (target as string).trim();

    // Check if user or agent passed a shortcut like "test", "build", "lint", "typecheck", "dev"
    const upper = trimmed.toUpperCase();
    if (this.isStandardScript(upper)) {
      return this.resolveStandardScript(upper as StandardProjectScript, scripts, workspaceFiles);
    }

    // Check if it matches an npm script invocation like "npm test", "npm run build"
    const npmMatch = trimmed.match(/^npm\s+(?:run\s+)?([a-zA-Z0-9_\-:]+)(?:\s+(.*))?$/);
    if (npmMatch) {
      const scriptName = npmMatch[1];
      const extraArgs = npmMatch[2] ? npmMatch[2].split(/\s+/) : [];

      if (scriptName === 'test') {
        return {
          standardType: 'TEST',
          originalInput: trimmed,
          command: 'npm',
          args: ['test', ...extraArgs],
          fullCommandLine: trimmed,
          scriptKey: scripts['test'] ? 'test' : undefined,
          source: scripts['test'] ? 'package_json' : 'framework_default',
          explanation: `Resolved npm test script${scripts['test'] ? ` ("${scripts['test']}")` : ' via default test runner'}.`
        };
      }

      if (scripts[scriptName]) {
        return {
          standardType: this.mapScriptNameToStandardType(scriptName),
          originalInput: trimmed,
          command: 'npm',
          args: ['run', scriptName, ...extraArgs],
          fullCommandLine: trimmed,
          scriptKey: scriptName,
          source: 'package_json',
          explanation: `Resolved package.json script "${scriptName}" -> "${scripts[scriptName]}".`
        };
      }
    }

    // Raw command splitting
    const parts = trimmed.split(/\s+/);
    const command = parts[0] || 'echo';
    const args = parts.slice(1);

    return {
      originalInput: trimmed,
      command,
      args,
      fullCommandLine: trimmed,
      source: 'raw_command',
      explanation: `Raw command pass-through: "${trimmed}".`
    };
  }

  private static resolveStandardScript(
    type: StandardProjectScript,
    scripts: Record<string, string>,
    workspaceFiles: Record<string, string>
  ): ResolvedCommandInfo {
    switch (type) {
      case 'TEST': {
        if (scripts['test']) {
          return {
            standardType: 'TEST',
            originalInput: 'TEST',
            command: 'npm',
            args: ['test'],
            fullCommandLine: 'npm test',
            scriptKey: 'test',
            source: 'package_json',
            explanation: `Resolved package.json test script: "${scripts['test']}".`
          };
        }
        return {
          standardType: 'TEST',
          originalInput: 'TEST',
          command: 'npm',
          args: ['test'],
          fullCommandLine: 'npm test',
          source: 'framework_default',
          explanation: 'Default unit test execution runner.'
        };
      }

      case 'BUILD': {
        if (scripts['build']) {
          return {
            standardType: 'BUILD',
            originalInput: 'BUILD',
            command: 'npm',
            args: ['run', 'build'],
            fullCommandLine: 'npm run build',
            scriptKey: 'build',
            source: 'package_json',
            explanation: `Resolved package.json build script: "${scripts['build']}".`
          };
        }
        return {
          standardType: 'BUILD',
          originalInput: 'BUILD',
          command: 'npm',
          args: ['run', 'build'],
          fullCommandLine: 'npm run build',
          source: 'framework_default',
          explanation: 'Default project build bundler.'
        };
      }

      case 'LINT': {
        if (scripts['lint']) {
          return {
            standardType: 'LINT',
            originalInput: 'LINT',
            command: 'npm',
            args: ['run', 'lint'],
            fullCommandLine: 'npm run lint',
            scriptKey: 'lint',
            source: 'package_json',
            explanation: `Resolved package.json lint script: "${scripts['lint']}".`
          };
        }
        return {
          standardType: 'LINT',
          originalInput: 'LINT',
          command: 'npx',
          args: ['eslint', '.'],
          fullCommandLine: 'npx eslint .',
          source: 'framework_default',
          explanation: 'Resolved fallback linter command.'
        };
      }

      case 'TYPECHECK': {
        if (scripts['typecheck']) {
          return {
            standardType: 'TYPECHECK',
            originalInput: 'TYPECHECK',
            command: 'npm',
            args: ['run', 'typecheck'],
            fullCommandLine: 'npm run typecheck',
            scriptKey: 'typecheck',
            source: 'package_json',
            explanation: `Resolved package.json typecheck script: "${scripts['typecheck']}".`
          };
        }
        const hasTs = Object.keys(workspaceFiles).some(f => f.endsWith('.ts') || f.endsWith('.tsx') || f === 'tsconfig.json');
        return {
          standardType: 'TYPECHECK',
          originalInput: 'TYPECHECK',
          command: 'npx',
          args: ['tsc', '--noEmit'],
          fullCommandLine: 'npx tsc --noEmit',
          source: hasTs ? 'framework_default' : 'raw_command',
          explanation: 'Resolved TypeScript compiler static typecheck.'
        };
      }

      case 'DEV_SERVER':
      case 'START': {
        const scriptName = scripts['dev'] ? 'dev' : scripts['start'] ? 'start' : null;
        if (scriptName) {
          return {
            standardType: type,
            originalInput: type,
            command: 'npm',
            args: ['run', scriptName],
            fullCommandLine: `npm run ${scriptName}`,
            scriptKey: scriptName,
            source: 'package_json',
            explanation: `Resolved development server script "${scriptName}": "${scripts[scriptName]}".`
          };
        }
        return {
          standardType: type,
          originalInput: type,
          command: 'npm',
          args: ['run', 'dev'],
          fullCommandLine: 'npm run dev',
          source: 'framework_default',
          explanation: 'Default development server starter.'
        };
      }
    }
  }

  private static extractPackageJson(workspaceFiles: Record<string, string>): any | null {
    const content = workspaceFiles['package.json'] || workspaceFiles['/package.json'];
    if (!content) return null;
    try {
      return JSON.parse(content);
    } catch {
      return null;
    }
  }

  private static isStandardScript(val: string): boolean {
    return ['TEST', 'BUILD', 'LINT', 'TYPECHECK', 'DEV_SERVER', 'START'].includes(val);
  }

  private static mapScriptNameToStandardType(name: string): StandardProjectScript | undefined {
    const lower = name.toLowerCase();
    if (lower.includes('test')) return 'TEST';
    if (lower.includes('build')) return 'BUILD';
    if (lower.includes('lint')) return 'LINT';
    if (lower.includes('typecheck') || lower.includes('tsc')) return 'TYPECHECK';
    if (lower.includes('dev') || lower.includes('start')) return 'DEV_SERVER';
    return undefined;
  }
}
