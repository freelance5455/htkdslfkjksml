/**
 * GODEX Phase 4 - Port Manager & Network Binding Tracker
 * Detects listening ports from processes, manages allocations, and associates ports with process lifecycle.
 */

import { PortInfo } from './executionTypes';

export class PortManager {
  private static allocatedPorts: Map<number, PortInfo> = new Map();
  private static defaultPorts: number[] = [3000, 5173, 8080, 4173, 8000, 5000];

  // Regex patterns to detect port bindings from stdout
  private static readonly PORT_OUTPUT_PATTERNS = [
    /https?:\/\/(?:localhost|127\.0\.0\.1|0\.0\.0\.0):(\d+)/i,
    /listening\s+(?:on|at)\s+(?:port\s+)?(\d+)/i,
    /server\s+(?:running|started)\s+(?:on|at)\s+(?:port\s+)?(\d+)/i,
    /ready\s+in\s+\d+ms\s+.*:(\d+)/i,
    /port\s*[:=]\s*(\d+)/i
  ];

  /**
   * Scans process output text to automatically detect listening port bindings.
   */
  public static detectPortFromOutput(output: string, processId: string, purpose: string = 'Development Server'): PortInfo | null {
    for (const pattern of this.PORT_OUTPUT_PATTERNS) {
      const match = output.match(pattern);
      if (match && match[1]) {
        const portNumber = parseInt(match[1], 10);
        if (portNumber > 0 && portNumber < 65536) {
          return this.registerPort(portNumber, processId, purpose);
        }
      }
    }
    return null;
  }

  /**
   * Registers a port binding to a specific process ID.
   */
  public static registerPort(
    port: number,
    processId: string,
    purpose: string = 'Service',
    workspacePath: string = '/project'
  ): PortInfo {
    const existing = this.allocatedPorts.get(port);
    if (existing && existing.processId !== processId && existing.state === 'LISTENING') {
      // Mark old as released/preempted
      existing.state = 'RELEASED';
    }

    const portInfo: PortInfo = {
      port,
      processId,
      workspacePath,
      purpose,
      state: 'LISTENING',
      url: `http://localhost:${port}`,
      detectedAt: Date.now()
    };

    this.allocatedPorts.set(port, portInfo);
    return portInfo;
  }

  /**
   * Releases any ports bound to a specific process upon termination.
   */
  public static releasePortsForProcess(processId: string) {
    for (const [port, info] of this.allocatedPorts.entries()) {
      if (info.processId === processId) {
        info.state = 'RELEASED';
      }
    }
  }

  /**
   * Gets all active listening ports.
   */
  public static getActivePorts(): PortInfo[] {
    return Array.from(this.allocatedPorts.values()).filter(p => p.state === 'LISTENING');
  }

  /**
   * Gets port info for a specific process.
   */
  public static getPortForProcess(processId: string): PortInfo | undefined {
    return Array.from(this.allocatedPorts.values()).find(
      p => p.processId === processId && p.state === 'LISTENING'
    );
  }

  /**
   * Checks if a port is currently listening.
   */
  public static isPortListening(port: number): boolean {
    const info = this.allocatedPorts.get(port);
    return !!info && info.state === 'LISTENING';
  }

  /**
   * Resets all port allocations (useful during testing/sandbox reset).
   */
  public static reset() {
    this.allocatedPorts.clear();
  }
}
