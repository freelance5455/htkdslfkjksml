/**
 * GODEX Phase 4 - Execution Registry
 * Central historical log of all command executions, evidence packets, and performance metrics.
 */

import { ExecutionResult, ExecutionStatus, RequestedBy } from './executionTypes';

export class ExecutionRegistry {
  private static readonly MAX_HISTORY_ITEMS = 50;
  private static history: ExecutionResult[] = [];

  /**
   * Registers a completed or failed execution result.
   */
  public static record(result: ExecutionResult) {
    // Remove if existing with same ID (e.g. status transition updates)
    this.history = this.history.filter(h => h.id !== result.id);
    this.history.unshift(result);

    // Enforce history size limit
    if (this.history.length > this.MAX_HISTORY_ITEMS) {
      this.history = this.history.slice(0, this.MAX_HISTORY_ITEMS);
    }
  }

  /**
   * Retrieves all historical executions.
   */
  public static getAll(): ExecutionResult[] {
    return [...this.history];
  }

  /**
   * Retrieves recent executions with optional limit.
   */
  public static getRecent(limit: number = 10): ExecutionResult[] {
    return this.history.slice(0, limit);
  }

  /**
   * Retrieves executions filtered by status.
   */
  public static getByStatus(status: ExecutionStatus): ExecutionResult[] {
    return this.history.filter(h => h.status === status);
  }

  /**
   * Retrieves executions filtered by requester (e.g. 'USER' vs 'GODEX_AGENT').
   */
  public static getByRequester(requestedBy: RequestedBy): ExecutionResult[] {
    return this.history.filter(h => h.evidence.requestedBy === requestedBy);
  }

  /**
   * Finds a specific execution by ID.
   */
  public static getById(id: string): ExecutionResult | undefined {
    return this.history.find(h => h.id === id);
  }

  /**
   * Gets the most recent execution.
   */
  public static getLatest(): ExecutionResult | undefined {
    return this.history[0];
  }

  /**
   * Clears the execution history.
   */
  public static clear() {
    this.history = [];
  }
}
