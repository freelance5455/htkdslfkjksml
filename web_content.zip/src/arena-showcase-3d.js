const VERT=`precision mediump float;attribute vec3 p;attribute vec3 c;attribute float motion;uniform mat4 mvp;uniform float tick;varying vec3 color;varying float shade;void main(){vec3 position=p;if(motion>=0.0)position.y+=sin(tick*4.0+motion)*.075;gl_Position=mvp*vec4(position,1.0);color=c;shade=.55+.45*max(.0,normalize(vec3(.35,1.0,.55)).y);}`;
const FRAG=`precision mediump float;varying vec3 color;varying float shade;uniform float tick;void main(){float pulse=.91+.09*sin(tick*2.1+color.r*7.0+color.g*11.0+color.b*5.0);gl_FragColor=vec4(color*shade*pulse,1.0);}`;

const STYLE_ARCHITECTURE = {
 orbital:{roof:[8.25,6.25],segments:64,towers:4,height:2.3,angular:false},
 crystal:{roof:[7.55,6.75],segments:8,towers:8,height:3.0,angular:true},
 solar:{roof:[8.6,6.0],segments:12,towers:12,height:2.25,angular:false},
 nebula:{roof:[8.0,6.8],segments:48,towers:6,height:2.3,angular:false},
 royal:{roof:[8.35,5.9],segments:16,towers:4,height:2.55,angular:false},
 sky:{roof:[7.7,6.5],segments:10,towers:10,height:2.3,angular:false},
 volcanic:{roof:[8.7,5.8],segments:6,towers:6,height:2.7,angular:true},
 jungle:{roof:[7.9,6.9],segments:14,towers:8,height:2.3,angular:false},
 cyber:{roof:[8.15,5.65],segments:12,towers:12,height:2.3,angular:true},
 imperial:{roof:[8.45,6.35],segments:8,towers:8,height:3.3,angular:true},
 comet:{roof:[8.8,5.5],segments:20,towers:5,height:2.3,angular:false}
};

// Paramètres déterministes : chaque emplacement possède une géométrie propre,
// tout en conservant la signature visuelle de sa famille galactique.
export function getArenaArchitecture(arena={}) {
 const style=arena.style||'orbital',base=STYLE_ARCHITECTURE[style]||STYLE_ARCHITECTURE.orbital;
 const slot=Math.max(1,Math.min(60,Number(arena.slot)||1));
 const hashText=String(arena.id||arena.clubId||`arena-${slot}`);
 let hash=2166136261;for(let i=0;i<hashText.length;i++){hash^=hashText.charCodeAt(i);hash=Math.imul(hash,16777619);}
 const seed=hash>>>0,unit=(shift,mod)=>((seed>>>shift)%mod);
 const ordinal=slot-1;
 return {style,seed,slot,roofWidth:Number((base.roof[0]+ordinal*.013).toFixed(3)),roofDepth:Number((base.roof[1]+ordinal*.009).toFixed(3)),
  roofSegments:base.segments+unit(3,4)*2, towerCount:base.towers+(ordinal%3), towerHeight:Number((base.height+unit(9,7)*.11+(ordinal%5)*.025).toFixed(3)),
  towerWidth:Number((.14+unit(16,5)*.035).toFixed(3)), standScale:Number((.96+unit(21,7)*.012+(ordinal%4)*.006).toFixed(3)),
  roofPhase:Number((unit(25,16)*Math.PI/16).toFixed(5)), splitRoof:unit(29,2)===1, facadeRibs:6+unit(30,9),
  signature:[style,slot,base.angular?'poly':'oval',base.segments+unit(3,4)*2,base.towers+(ordinal%3), (base.roof[0]+ordinal*.013).toFixed(3),(base.roof[1]+ordinal*.009).toFixed(3),unit(9,7)].join(':')};
}
// Le damier reçoit exclusivement la palette d'une seule équipe : domicile OU extérieur.
// L'API accepte les deux palettes d'une rencontre et choisit celle du côté demandé.
export function getArenaTeamColors(arena={}, options={}) {
 const side=options.teamSide==='away'?'away':'home';
 const home=options.homeColors||arena.homeColors||arena.match?.home?.colors||arena.colors;
 const away=options.awayColors||arena.awayColors||arena.match?.away?.colors;
 const selected=side==='away'?(away||home):(home||away);
 return Array.isArray(selected)&&selected.length>=2?selected.slice(0,2):['#1f8fff','#b8dcff'];
}

const perspective=(f,a,n,z)=>{const t=1/Math.tan(f/2),q=1/(n-z),m=new Float32Array(16);m[0]=t/a;m[5]=t;m[10]=(z+n)*q;m[11]=-1;m[14]=2*z*n*q;return m;};
const lookAt=(e,c)=>{let z=e.map((v,i)=>v-c[i]),l=Math.hypot(...z);z=z.map(v=>v/l);let x=[z[2],0,-z[0]];l=Math.hypot(...x);x=x.map(v=>v/l);const y=[z[1]*x[2]-z[2]*x[1],z[2]*x[0]-z[0]*x[2],z[0]*x[1]-z[1]*x[0]];return new Float32Array([x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-x.reduce((s,v,i)=>s+v*e[i],0),-y.reduce((s,v,i)=>s+v*e[i],0),-z.reduce((s,v,i)=>s+v*e[i],0),1]);};
const mul=(a,b)=>{const o=new Float32Array(16);for(let j=0;j<4;j++)for(let i=0;i<4;i++)o[j*4+i]=a[i]*b[j*4]+a[4+i]*b[j*4+1]+a[8+i]*b[j*4+2]+a[12+i]*b[j*4+3];return o;};
function mesh(){const v=[];const tri=(a,b,c,col,motion=-1)=>{for(const p of[a,b,c])v.push(...p,...col,motion);};const quad=(a,b,c,d,col,motion=-1)=>{tri(a,b,c,col,motion);tri(a,c,d,col,motion);};const box=(x,y,z,w,h,d,col,motion=-1)=>{const X=x+w,Y=y+h,Z=z+d;quad([x,Y,z],[X,Y,z],[X,Y,Z],[x,Y,Z],col,motion);quad([x,y,Z],[X,y,Z],[X,y,z],[x,y,z],col.map(n=>n*.6),motion);quad([x,y,z],[X,y,z],[X,Y,z],[x,Y,z],col.map(n=>n*.72),motion);quad([X,y,Z],[x,y,Z],[x,Y,Z],[X,Y,Z],col.map(n=>n*.72),motion);quad([x,y,Z],[x,y,z],[x,Y,z],[x,Y,Z],col.map(n=>n*.52),motion);quad([X,y,z],[X,y,Z],[X,Y,Z],[X,Y,z],col.map(n=>n*.52),motion);};
const ring=(rx,rz,y,thick,col,segments=64)=>{for(let i=0;i<segments;i++){const a=i/segments*Math.PI*2,b=(i+1)/segments*Math.PI*2;const pt=(rX,rZ,t,Y)=>[Math.cos(t)*rX,Y,Math.sin(t)*rZ];quad(pt(rx,rz,a,y),pt(rx,rz,b,y),pt(rx-thick,rz-thick,b,y+.03),pt(rx-thick,rz-thick,a,y+.03),col);}};
const polygonRing=(rx,rz,y,thick,col,segments=8,phase=0)=>{for(let i=0;i<segments;i++){const a=phase+i/segments*Math.PI*2,b=phase+(i+1)/segments*Math.PI*2;const pt=(rX,rZ,t,Y)=>[Math.cos(t)*rX,Y,Math.sin(t)*rZ];quad(pt(rx,rz,a,y),pt(rx,rz,b,y),pt(rx-thick,rz-thick,b,y+.08),pt(rx-thick,rz-thick,a,y+.08),col);}};
return{v,box,ring,polygonRing,quad};}
export function createArenaShowcase3D(host,arena={},options={}){if(!host)return{available:false,destroy(){}};const canvas=document.createElement('canvas');canvas.className='arena-webgl-canvas';canvas.setAttribute('aria-label','Maquette tridimensionnelle animée de l’arène');host.append(canvas);let gl=canvas.getContext('webgl',{antialias:true,alpha:true,powerPreference:'low-power'});if(!gl){canvas.remove();return{available:false,destroy(){}};}
const shader=(type,src)=>{const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;};const program=gl.createProgram();gl.attachShader(program,shader(gl.VERTEX_SHADER,VERT));gl.attachShader(program,shader(gl.FRAGMENT_SHADER,FRAG));gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));gl.useProgram(program);
const color=(value,fallback)=>{const h=String(value||'').replace('#','');return /^[0-9a-fA-F]{6}$/.test(h)?[0,2,4].map(i=>parseInt(h.slice(i,i+2),16)/255):fallback;};const teamColors=getArenaTeamColors(arena,options);const a=color(teamColors[0],[.12,.65,.95]),b=color(teamColors[1],[.7,.3,.95]);const architecture=getArenaArchitecture(arena),style=architecture.style;const g=mesh();g.box(-7,-.9,-6.2,14,.5,12.4,[.055,.09,.17]);
// Gradins elliptiques étagés, ouverts au centre pour laisser apparaître le plateau.
[[6.0,-.38,.55],[6.7,.17,.55],[7.35,.72,.52],[7.95,1.24,.42]].forEach(([r,y,h],i)=>{const scale=architecture.standScale;g.ring(r*scale,r*.76*scale,y,.52,[.12+i*.025,.2+i*.018,.34+i*.02]);g.ring((r-.04)*scale,(r*.76-.04)*scale,y+h,.48,[.22+i*.025,.34+i*.02,.52+i*.018]);});
// Damier 10x10 : les deux cases alternent entre les deux couleurs DU MÊME club sélectionné.
// En match, options.teamSide='home' ou 'away' choisit exclusivement la palette correspondante.
g.box(-3.7,.02,-2.55,7.4,.13,5.1,[.055,.075,.12]);const tile=(base,factor)=>base.map(v=>Math.min(1,v*factor));for(let r=0;r<10;r++)for(let c=0;c<10;c++){const team=(r+c)%2?b:a,shade=tile(team,((r+c)%4===1||(r+c)%4===2)?1.02:.48);g.box(-3.45+c*.69,.16,-2.3+r*.46,.685,.025,.455,shade);}g.box(-4.05,1.78,-3.1,8.1,.18,.18,a);g.box(-4.05,1.78,2.92,8.1,.18,.18,b);g.box(-4.05,1.78,-3.1,.18,.18,6.2,a);g.box(3.87,1.78,-3.1,.18,.18,6.2,b);
// Couronne de toiture et pylônes lumineux.
const roofShape=[architecture.roofWidth,architecture.roofDepth];
const angular=['crystal','cyber','imperial','volcanic'].includes(style),segments=architecture.roofSegments;
const roof=angular?g.polygonRing.bind(g):g.ring.bind(g);roof(roofShape[0],roofShape[1],2.12,.28,a,segments,architecture.roofPhase);roof(roofShape[0]-.5,roofShape[1]-.45,2.18,.18,b,segments,architecture.roofPhase+.04);
if(architecture.splitRoof){g.box(-roofShape[0]*.42,2.22,-.16,roofShape[0]*.84,.16,.32,b);}
for(let i=0;i<architecture.facadeRibs;i++){const t=i/architecture.facadeRibs*Math.PI*2,x=Math.cos(t)*7.72,z=Math.sin(t)*5.92;g.box(x-.07,.85,z-.07,.14,.72,.14,i%2?a:b);}
// Chaque famille possède une silhouette architecturale distincte : nombre et forme des pylônes, contreforts et tours.
const towerCount=architecture.towerCount;
for(let i=0;i<towerCount;i++){const t=i/towerCount*Math.PI*2,rx=style==='jungle'?7.1:7.4,rz=style==='sky'?5.2:5.8,x=Math.cos(t)*rx,z=Math.sin(t)*rz;
 const tall=architecture.towerHeight;
 const width=architecture.towerWidth+(style==='royal'?.12:style==='crystal'?.08:0);
 g.box(x-width/2,1.5,z-width/2,width,tall,width,style==='volcanic'?[.72,.28,.16]:style==='jungle'?[.22,.55,.34]:[.58,.7,.88]);
 g.box(x-width*2,1.5+tall,z-width*1.5,width*4,.13,width*3,style==='solar'?[1,.72,.25]:[.95,.87,.64]);
 if(style==='imperial'||style==='crystal'||style==='royal')g.box(x-width,1.5+tall+.15,z-width,width*2,.65,width*2,b);
}
if(style==='solar'||style==='comet'||style==='cyber'){for(let i=0;i<segments;i++){const t=i/segments*Math.PI*2,x=Math.cos(t)*roofShape[0],z=Math.sin(t)*roofShape[1];g.box(x-.08,2.35,z-.08,.16,.08,.16,style==='solar'?[1,.78,.28]:b);}}
if(style==='jungle'){for(let i=0;i<8;i++){const t=i/8*Math.PI*2,x=Math.cos(t)*8.15,z=Math.sin(t)*6.3;g.box(x-.12,1.7,z-.12,.24,1.7,.24,[.2,.48,.3]);g.box(x-.42,3.35,z-.42,.84,.12,.84,[.16,.38,.25]);}}
// Décorations galactiques : anneaux orbitaux, balises et écran géant.
g.ring(10.1,7.7,4.15,.075,a,48);g.ring(10.45,7.95,4.28,.055,b,48);
for(let i=0;i<12;i++){const t=i/12*Math.PI*2,x=Math.cos(t)*10.25,z=Math.sin(t)*7.82;g.box(x-.13,4.18,z-.13,.26,.16,.26,i%2?a:b);}
g.box(-2.05,3.05,-6.05,4.1,1.05,.24,[.025,.055,.12]);g.box(-1.88,3.18,-5.91,1.82,.72,.045,a);g.box(.06,3.18,-5.91,1.82,.72,.045,b);
// Public stylisé : trois rangées de spectateurs animés, avec bannières aux couleurs des clubs.
for(let row=0;row<3;row++){const radius=6.85+row*.49,depth=radius*.76;for(let i=0;i<96;i++){const t=i/96*Math.PI*2,x=Math.cos(t)*radius,z=Math.sin(t)*depth,phase=(i*.618033+row*2.17)%(Math.PI*2);g.box(x-.055,.32+row*.43,z-.055,.11,.15,.11,(i+row)%2?a:b,phase);}}
for(let i=0;i<8;i++){const t=i/8*Math.PI*2,x=Math.cos(t)*8.35,z=Math.sin(t)*6.35;g.box(x-.09,1.55,z-.09,.18,.72,.18,i%2?a:b);g.box(x-.34,1.95,z-.035,.68,.42,.07,i%2?b:a);}

const buf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(g.v),gl.STATIC_DRAW);const p=gl.getAttribLocation(program,'p'),c=gl.getAttribLocation(program,'c'),motion=gl.getAttribLocation(program,'motion');gl.enableVertexAttribArray(p);gl.vertexAttribPointer(p,3,gl.FLOAT,false,28,0);gl.enableVertexAttribArray(c);gl.vertexAttribPointer(c,3,gl.FLOAT,false,28,12);gl.enableVertexAttribArray(motion);gl.vertexAttribPointer(motion,1,gl.FLOAT,false,28,24);const mvpLoc=gl.getUniformLocation(program,'mvp'),tickLoc=gl.getUniformLocation(program,'tick');let yaw=.48,pitch=.48,zoom=1,drag=null,raf=0,alive=true,last=0,introStart=performance.now();const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
function draw(now=0){if(!alive)return;if((reduced&&last===0)||(!reduced&&now-last>32)){last=now;const rect=host.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,1.25),w=Math.max(1,Math.round(rect.width*dpr)),h=Math.max(1,Math.round(rect.height*dpr));if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}gl.viewport(0,0,w,h);gl.enable(gl.DEPTH_TEST);gl.clearColor(.025,.045,.1,0);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);const introT=reduced?1:Math.min(1,Math.max(0,(now-introStart)/2600)),introEase=1-Math.pow(1-introT,3),radius=(29-8*introEase)/zoom,currentPitch=reduced?pitch:.25+.23*introEase,eye=[Math.sin(yaw)*radius,Math.sin(currentPitch)*radius*.8+3,Math.cos(yaw)*radius];gl.uniformMatrix4fv(mvpLoc,false,mul(perspective(Math.PI/4,w/h,.1,80),lookAt(eye,[0,.7,0])));gl.uniform1f(tickLoc,now/1000);gl.drawArrays(gl.TRIANGLES,0,g.v.length/6);}if(!reduced)raf=requestAnimationFrame(draw);}
const down=e=>{drag={x:e.clientX,y:e.clientY,yaw,pitch};canvas.setPointerCapture?.(e.pointerId);};const move=e=>{if(!drag)return;yaw=drag.yaw+(e.clientX-drag.x)*.008;pitch=Math.max(.12,Math.min(1.05,drag.pitch-(e.clientY-drag.y)*.006));};const up=()=>drag=null;const wheel=e=>{e.preventDefault();zoom=Math.max(.75,Math.min(1.45,zoom+(e.deltaY<0?.06:-.06)));};canvas.addEventListener('pointerdown',down);canvas.addEventListener('pointermove',move);canvas.addEventListener('pointerup',up);canvas.addEventListener('pointercancel',up);canvas.addEventListener('wheel',wheel,{passive:false});raf=requestAnimationFrame(draw);
return{available:true,canvas,reset(){yaw=.48;pitch=.48;zoom=1;},playIntro(){introStart=performance.now();},rotate(delta){yaw+=delta;},zoomBy(delta){zoom=Math.max(.75,Math.min(1.45,zoom+delta));},destroy(){alive=false;cancelAnimationFrame(raf);canvas.removeEventListener('pointerdown',down);canvas.removeEventListener('pointermove',move);canvas.removeEventListener('pointerup',up);canvas.removeEventListener('pointercancel',up);canvas.removeEventListener('wheel',wheel);canvas.remove();gl.deleteBuffer(buf);gl.deleteProgram(program);}};}
