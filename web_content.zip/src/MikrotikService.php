<?php
// Integration adapter; invoke only after VPN routing and firewall restrictions are verified.
final class MikrotikService {
 private $client;
 public function connect(string $host,int $port,string $user,string $pass): void {
  if(!class_exists(\RouterOS\Client::class)) throw new RuntimeException('Run composer install first');
  $this->client=new \RouterOS\Client(['host'=>$host,'user'=>$user,'pass'=>$pass,'port'=>$port,'timeout'=>5]);
 }
 public function identity(): array {
  if(!$this->client) throw new RuntimeException('Not connected');
  $query=new \RouterOS\Query('/system/identity/print');
  return $this->client->query($query)->read();
 }
}
