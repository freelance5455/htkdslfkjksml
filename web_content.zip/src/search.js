// Web search for the assistant, through the Mwmbl search API. Results are added to the model's context.
// The search text is the user's latest message, so it is sent to Mwmbl when Search is on.
export const MWMBL_SEARCH_URL = 'https://api.mwmbl.org/api/v1/search/';
const MAX_RESULTS = 6;

// Returns a list of results, or null when the search service cannot be used.
export async function searchWeb(query, fetchImpl = fetch) {
  const q = String(query || '').trim().slice(0, 200);
  if (!q) return [];
  let res;
  try {
    res = await fetchImpl(MWMBL_SEARCH_URL + '?s=' + encodeURIComponent(q), {
      headers: { Accept: 'application/json' },
      signal: AbortSignal.timeout(15000),
    });
  } catch {
    return null;
  }
  if (!res.ok) return null;
  const data = await res.json().catch(() => null);
  const list = Array.isArray(data) ? data : Array.isArray(data?.results) ? data.results : [];
  return list
    .slice(0, MAX_RESULTS)
    .map((r) => ({
      title: String(r?.title || '').slice(0, 160),
      url: String(r?.url || '').slice(0, 400),
      snippet: String(r?.extract || r?.description || r?.snippet || '').slice(0, 400),
    }))
    .filter((r) => /^https?:\/\//.test(r.url));
}
