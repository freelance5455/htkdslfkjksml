async function searchWeb(query) {
 if(process.env.BRAVE_SEARCH_API_KEY) {
  const r=await fetch('https://api.search.brave.com/res/v1/web/search?q='+encodeURIComponent(query)+'&count=8',{headers:{'X-Subscription-Token':process.env.BRAVE_SEARCH_API_KEY,'Accept':'application/json'}});
  if(!r.ok) throw new Error('Brave Search HTTP '+r.status);
  const d=await r.json();
  return (d.web?.results||[]).map(x=>({title:x.title||'',snippet:x.description||'',url:x.url||''})).filter(x=>x.url);
 }
 // Fallback deliberately uses the public Instant Answer API; it is not a full SERP crawler.
 const r=await fetch('https://api.duckduckgo.com/?q='+encodeURIComponent(query)+'&format=json&no_html=1&skip_disambig=1',{headers:{'User-Agent':'UniversalAI/2.0'}});
 if(!r.ok) throw new Error('DuckDuckGo HTTP '+r.status);
 const d=await r.json(), out=[];
 if(d.AbstractText) out.push({title:d.Heading||query,snippet:d.AbstractText,url:d.AbstractURL||''});
 for(const x of d.RelatedTopics||[]) {
  if(x.Text&&x.FirstURL) out.push({title:x.Text.slice(0,140),snippet:x.Text,url:x.FirstURL});
  for(const y of x.Topics||[]) if(y.Text&&y.FirstURL) out.push({title:y.Text.slice(0,140),snippet:y.Text,url:y.FirstURL});
 }
 return out.slice(0,8);
}
module.exports={searchWeb};
