import { generateSeasonCalendar } from './calendar.js';
import { createFederalCupSeason } from './federal-cup.js';
import { createGalacticCupSeason } from './galactic-cup.js';
import { createClubCupSeason } from './club-cup.js';
import { createChampionsLeagueSeason } from './champions-league.js';
import { createLunarCupSeason, LUNAR_CUP_ID } from './lunar-cup.js';
import { createIntergalacticCupSeason } from './intergalactic-cup.js';
import { createIntergalacticClubsSeason } from './intergalactic-clubs.js';
import { scheduleCompetitionCalendar } from './competition-calendar.js';

/** Prépare toutes les compétitions d'une saison sans intervention du manager. */
export function initializeSeasonCompetitions(state) {
  if (!state.calendar.fixtures.some(f => f.season === state.season && !f.competitionId)) generateSeasonCalendar(state);
  const ensure = (id, create, invalid = false) => {
    const item = state.competitions.find(c => c.id === id);
    if (!item || item.season !== state.season || item.status === 'pending' || invalid) create(state);
  };
  ensure('coupe-galactique', createGalacticCupSeason);
  ensure('coupe-des-clubs', createClubCupSeason);
  ensure('champions-league', createChampionsLeagueSeason, state.competitions.find(c => c.id === 'champions-league')?.groups?.length !== 8);
  ensure('coupe-federal', createFederalCupSeason);
  ensure(LUNAR_CUP_ID, createLunarCupSeason, !state.competitions.find(c => c.id === LUNAR_CUP_ID)?.rounds?.length);
  createIntergalacticCupSeason(state);
  createIntergalacticClubsSeason(state);
  scheduleCompetitionCalendar(state);
  return state.competitions;
}
