import type { BuiltInSoundMeta, PadZoneConfig, StoredSound } from '../types/octapad';

export const BUILT_IN_SOUNDS: BuiltInSoundMeta[] = [
  // Timli & Folk
  { id: 'dholak-ge', name: 'Dholak Ge (Bass)', category: 'Timli & Folk', color: '#06b6d4' },
  { id: 'dholak-na', name: 'Dholak Na (Treble)', category: 'Timli & Folk', color: '#22d3ee' },
  { id: 'dholak-ta', name: 'Dholak Ta (Slap)', category: 'Timli & Folk', color: '#38bdf8' },
  { id: 'timli-kick', name: 'Timli Punch Kick', category: 'Timli & Folk', color: '#0ea5e9' },
  { id: 'duff-slap', name: 'Duff Open Slap', category: 'Timli & Folk', color: '#f59e0b' },
  { id: 'manjira', name: 'Manjira Bell', category: 'Timli & Folk', color: '#fbbf24' },
  { id: 'ghunghroo', name: 'Ghunghroo Shake', category: 'Timli & Folk', color: '#eab308' },
  { id: 'tabla-ke', name: 'Tabla Ke (Mute)', category: 'Timli & Folk', color: '#14b8a6' },
  { id: 'dhol-bass', name: 'Dhol Boom', category: 'Timli & Folk', color: '#0284c7' },
  { id: 'folk-clap', name: 'Folk Group Clap', category: 'Timli & Folk', color: '#f97316' },
  { id: 'timli-tom', name: 'Timli High Tom', category: 'Timli & Folk', color: '#34d399' },
  { id: 'brass-stab', name: 'Timli Brass Hit', category: 'Timli & Folk', color: '#fb7185' },

  // Acoustic Studio
  { id: 'ac-kick', name: 'Studio Kick', category: 'Acoustic Kit', color: '#06b6d4' },
  { id: 'ac-snare', name: 'Studio Snare', category: 'Acoustic Kit', color: '#38bdf8' },
  { id: 'ac-rim', name: 'Snare Rimshot', category: 'Acoustic Kit', color: '#7dd3fc' },
  { id: 'ac-hh-closed', name: 'Closed Hi-Hat', category: 'Acoustic Kit', color: '#facc15' },
  { id: 'ac-hh-open', name: 'Open Hi-Hat', category: 'Acoustic Kit', color: '#fde047' },
  { id: 'ac-tom-hi', name: 'Rack Tom High', category: 'Acoustic Kit', color: '#34d399' },
  { id: 'ac-tom-lo', name: 'Floor Tom Deep', category: 'Acoustic Kit', color: '#10b981' },
  { id: 'ac-crash', name: 'Crash Cymbal', category: 'Acoustic Kit', color: '#fb923c' },
  { id: 'ac-ride', name: 'Ride Bell', category: 'Acoustic Kit', color: '#fdba74' },

  // 808 & Trap
  { id: '808-sub', name: '808 Sub Boom', category: '808 & Trap', color: '#06b6d4' },
  { id: '808-snare', name: 'Trap Snare', category: '808 & Trap', color: '#60a5fa' },
  { id: '808-clap', name: '808 Crisp Clap', category: '808 & Trap', color: '#f472b6' },
  { id: '808-hh', name: '808 Tick Hat', category: '808 & Trap', color: '#facc15' },
  { id: '808-oh', name: '808 Open Hat', category: '808 & Trap', color: '#fde047' },
  { id: '808-cowbell', name: '808 Cowbell', category: '808 & Trap', color: '#a78bfa' },
  { id: '808-rim', name: '808 Rim Click', category: '808 & Trap', color: '#2dd4bf' },

  // Electro & Perc
  { id: 'el-kick', name: 'Club Kick', category: 'Electro & Perc', color: '#06b6d4' },
  { id: 'el-clap', name: 'Electro Clap', category: 'Electro & Perc', color: '#f43f5e' },
  { id: 'el-shaker', name: 'Crisp Shaker', category: 'Electro & Perc', color: '#eab308' },
  { id: 'el-perc', name: 'Woodblock Perc', category: 'Electro & Perc', color: '#2dd4bf' },
  { id: 'el-zap', name: 'Laser Tom Zap', category: 'Electro & Perc', color: '#38bdf8' },
  { id: 'el-chord', name: 'House Stab', category: 'Electro & Perc', color: '#818cf8' },
];

interface ActiveVoice {
  stop: (fadeOutSec?: number) => void;
  chokeGroup: number;
  zoneKey: string;
  isLoop: boolean;
}

class OctapadAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private compressor: DynamicsCompressorNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private customBuffers = new Map<string, AudioBuffer>();
  private activeVoices: ActiveVoice[] = [];
  private masterVolume = 0.9;

  public ensureContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx({ latencyHint: 'interactive' });

      this.compressor = this.ctx.createDynamicsCompressor();
      this.compressor.threshold.setValueAtTime(-10, this.ctx.currentTime);
      this.compressor.knee.setValueAtTime(12, this.ctx.currentTime);
      this.compressor.ratio.setValueAtTime(4, this.ctx.currentTime);
      this.compressor.attack.setValueAtTime(0.002, this.ctx.currentTime);
      this.compressor.release.setValueAtTime(0.12, this.ctx.currentTime);

      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.masterVolume, this.ctx.currentTime);

      this.compressor.connect(this.masterGain);
      this.masterGain.connect(this.ctx.destination);
      this.noiseBuffer = this.createNoiseBuffer(this.ctx, 2.0);
    }

    if (this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
    return this.ctx;
  }

  public setMasterVolume(vol: number): void {
    this.masterVolume = Math.max(0, Math.min(1.2, vol));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(this.masterVolume, this.ctx.currentTime, 0.015);
    }
  }

  public async decodeAndStoreCustomSound(sound: StoredSound): Promise<AudioBuffer> {
    const ctx = this.ensureContext();
    const copy = sound.data.slice(0);
    const decoded = await ctx.decodeAudioData(copy);
    this.customBuffers.set(sound.id, decoded);
    return decoded;
  }

  public async decodeRawFile(file: File): Promise<{ buffer: AudioBuffer; arrayBuffer: ArrayBuffer }> {
    const ctx = this.ensureContext();
    const arrayBuffer = await file.arrayBuffer();
    const copy = arrayBuffer.slice(0);
    const buffer = await ctx.decodeAudioData(copy);
    return { buffer, arrayBuffer };
  }

  public registerBuffer(id: string, buffer: AudioBuffer): void {
    this.customBuffers.set(id, buffer);
  }

  public removeCustomBuffer(id: string): void {
    this.customBuffers.delete(id);
  }

  public hasCustomBuffer(id: string): boolean {
    return this.customBuffers.has(id);
  }

  public getCustomBufferDuration(id: string): number | null {
    return this.customBuffers.get(id)?.duration ?? null;
  }

  public stopChokeGroup(group: number): void {
    if (group <= 0) return;
    const remaining: ActiveVoice[] = [];
    for (const voice of this.activeVoices) {
      if (voice.chokeGroup === group) {
        voice.stop(0.018);
      } else {
        remaining.push(voice);
      }
    }
    this.activeVoices = remaining;
  }

  public releaseGateVoice(zoneKey: string): void {
    const remaining: ActiveVoice[] = [];
    for (const voice of this.activeVoices) {
      if (voice.zoneKey === zoneKey && !voice.isLoop) {
        voice.stop(0.045);
      } else {
        remaining.push(voice);
      }
    }
    this.activeVoices = remaining;
  }

  public stopAll(): void {
    for (const voice of this.activeVoices) {
      voice.stop(0.02);
    }
    this.activeVoices = [];
  }

  public playMetronomeClick(accent = false): void {
    const ctx = this.ensureContext();
    if (!this.compressor) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(accent ? 1320 : 880, now);
    osc.frequency.exponentialRampToValueAtTime(accent ? 660 : 440, now + 0.035);
    gain.gain.setValueAtTime(accent ? 0.35 : 0.22, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.045);
    osc.connect(gain);
    gain.connect(this.compressor);
    osc.start(now);
    osc.stop(now + 0.05);
  }

  public triggerZone(
    zoneKey: string,
    zone: PadZoneConfig,
    velocity = 1.0
  ): void {
    if (zone.muted) return;
    const ctx = this.ensureContext();
    if (!this.compressor) return;

    // Toggle off if already looping on same zone
    if (zone.playbackMode === 'loop') {
      const existingIdx = this.activeVoices.findIndex(
        (v) => v.zoneKey === zoneKey && v.isLoop
      );
      if (existingIdx !== -1) {
        this.activeVoices[existingIdx].stop(0.025);
        this.activeVoices.splice(existingIdx, 1);
        return;
      }
    }

    if (zone.chokeGroup > 0) {
      this.stopChokeGroup(zone.chokeGroup);
    }

    const level = Math.max(0.01, Math.min(1.3, zone.volume * velocity));
    const rate = Math.pow(2, (zone.pitch || 0) / 12);

    const voiceGain = ctx.createGain();
    voiceGain.gain.setValueAtTime(level, ctx.currentTime);

    let outputNode: AudioNode = voiceGain;
    if (typeof ctx.createStereoPanner === 'function' && Math.abs(zone.pan) > 0.01) {
      const panner = ctx.createStereoPanner();
      panner.pan.setValueAtTime(Math.max(-1, Math.min(1, zone.pan)), ctx.currentTime);
      voiceGain.connect(panner);
      panner.connect(this.compressor);
    } else {
      outputNode.connect(this.compressor);
    }

    if (zone.isCustom && this.customBuffers.has(zone.soundId)) {
      const buffer = this.customBuffers.get(zone.soundId)!;
      this.playCustomBuffer(ctx, buffer, voiceGain, zoneKey, zone, rate);
      return;
    }

    // Built-in procedural drum & percussion synthesizer
    this.playBuiltInSynth(ctx, zone.soundId, voiceGain, zoneKey, zone, rate);
  }

  private playCustomBuffer(
    ctx: AudioContext,
    buffer: AudioBuffer,
    destination: GainNode,
    zoneKey: string,
    zone: PadZoneConfig,
    rate: number
  ): void {
    const now = ctx.currentTime;
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.playbackRate.setValueAtTime(rate, now);

    const startSec = Math.max(0, Math.min(buffer.duration - 0.01, zone.startOffset * buffer.duration));
    const endSec = Math.max(startSec + 0.015, Math.min(buffer.duration, zone.endOffset * buffer.duration));
    const durSec = endSec - startSec;

    if (zone.playbackMode === 'loop') {
      source.loop = true;
      source.loopStart = startSec;
      source.loopEnd = endSec;
      source.connect(destination);
      source.start(now, startSec);
    } else {
      source.connect(destination);
      source.start(now, startSec, durSec);
    }

    const voice: ActiveVoice = {
      chokeGroup: zone.chokeGroup,
      zoneKey,
      isLoop: zone.playbackMode === 'loop',
      stop: (fadeOutSec = 0.02) => {
        try {
          const t = ctx.currentTime;
          destination.gain.cancelScheduledValues(t);
          destination.gain.setValueAtTime(destination.gain.value, t);
          destination.gain.linearRampToValueAtTime(0.0001, t + fadeOutSec);
          source.stop(t + fadeOutSec + 0.005);
        } catch {
          // voice already stopped
        }
      },
    };

    this.activeVoices.push(voice);
    source.onended = () => {
      this.activeVoices = this.activeVoices.filter((v) => v !== voice);
    };
  }

  private createNoiseBuffer(ctx: AudioContext, seconds: number): AudioBuffer {
    const length = Math.floor(ctx.sampleRate * seconds);
    const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < length; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    return buffer;
  }

  private playBuiltInSynth(
    ctx: AudioContext,
    soundId: string,
    dest: GainNode,
    zoneKey: string,
    zone: PadZoneConfig,
    rate: number
  ): void {
    const now = ctx.currentTime;
    const stopCallbacks: Array<() => void> = [];

    const registerOsc = (osc: OscillatorNode) => {
      stopCallbacks.push(() => {
        try {
          osc.stop(ctx.currentTime + 0.02);
        } catch {
          // already ended
        }
      });
    };

    const registerNoise = (src: AudioBufferSourceNode) => {
      stopCallbacks.push(() => {
        try {
          src.stop(ctx.currentTime + 0.02);
        } catch {
          // already ended
        }
      });
    };

    const spawnNoise = (duration: number, filterType: BiquadFilterType, freq: number, q = 1, gainVal = 0.7) => {
      if (!this.noiseBuffer) return;
      const src = ctx.createBufferSource();
      src.buffer = this.noiseBuffer;
      const filter = ctx.createBiquadFilter();
      filter.type = filterType;
      filter.frequency.setValueAtTime(freq * Math.min(2, Math.max(0.5, rate)), now);
      filter.Q.setValueAtTime(q, now);

      const env = ctx.createGain();
      env.gain.setValueAtTime(gainVal, now);
      env.gain.exponentialRampToValueAtTime(0.0008, now + duration);

      src.connect(filter);
      filter.connect(env);
      env.connect(dest);
      src.start(now);
      src.stop(now + duration + 0.02);
      registerNoise(src);
    };

    switch (soundId) {
      case 'dholak-ge':
      case 'dhol-bass': {
        const isDhol = soundId === 'dhol-bass';
        const osc = ctx.createOscillator();
        const env = ctx.createGain();
        osc.type = 'sine';
        const startF = (isDhol ? 155 : 210) * rate;
        const endF = (isDhol ? 56 : 78) * rate;
        osc.frequency.setValueAtTime(startF, now);
        osc.frequency.exponentialRampToValueAtTime(startF * 1.12, now + 0.035);
        osc.frequency.exponentialRampToValueAtTime(endF, now + (isDhol ? 0.34 : 0.24));

        env.gain.setValueAtTime(0.001, now);
        env.gain.linearRampToValueAtTime(1.0, now + 0.006);
        env.gain.exponentialRampToValueAtTime(0.001, now + (isDhol ? 0.42 : 0.32));

        osc.connect(env);
        env.connect(dest);
        osc.start(now);
        osc.stop(now + 0.45);
        registerOsc(osc);
        spawnNoise(0.04, 'bandpass', 420, 1.5, 0.28);
        break;
      }

      case 'dholak-na':
      case 'dholak-ta':
      case 'tabla-ke': {
        const isSlap = soundId === 'dholak-ta';
        const isMute = soundId === 'tabla-ke';
        const dur = isMute ? 0.08 : isSlap ? 0.19 : 0.24;

        const base = (isMute ? 260 : isSlap ? 390 : 340) * rate;
        [1, 1.52, 2.02].forEach((mult, idx) => {
          const osc = ctx.createOscillator();
          const env = ctx.createGain();
          osc.type = idx === 0 ? 'triangle' : 'sine';
          osc.frequency.setValueAtTime(base * mult * 1.15, now);
          osc.frequency.exponentialRampToValueAtTime(base * mult, now + 0.022);
          const amp = idx === 0 ? 0.65 : idx === 1 ? 0.32 : 0.18;
          env.gain.setValueAtTime(amp, now);
          env.gain.exponentialRampToValueAtTime(0.001, now + dur / (1 + idx * 0.35));
          osc.connect(env);
          env.connect(dest);
          osc.start(now);
          osc.stop(now + dur + 0.02);
          registerOsc(osc);
        });
        spawnNoise(isSlap ? 0.055 : 0.025, 'bandpass', 2400, 1.2, isSlap ? 0.55 : 0.25);
        break;
      }

      case 'timli-kick':
      case 'ac-kick':
      case 'el-kick':
      case '808-sub': {
        const is808 = soundId === '808-sub';
        const isClub = soundId === 'el-kick';
        const dur = is808 ? 0.65 : isClub ? 0.28 : 0.32;
        const osc = ctx.createOscillator();
        const env = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime((is808 ? 130 : isClub ? 185 : 165) * rate, now);
        osc.frequency.exponentialRampToValueAtTime((is808 ? 42 : 48) * rate, now + (is808 ? 0.14 : 0.075));

        env.gain.setValueAtTime(1.05, now);
        env.gain.exponentialRampToValueAtTime(0.001, now + dur);

        osc.connect(env);
        env.connect(dest);
        osc.start(now);
        osc.stop(now + dur + 0.02);
        registerOsc(osc);

        // Beater click
        spawnNoise(0.018, 'highpass', 1800, 0.8, is808 ? 0.15 : 0.45);
        break;
      }

      case 'duff-slap':
      case 'timli-tom':
      case 'ac-tom-hi':
      case 'ac-tom-lo':
      case 'el-zap': {
        const isDuff = soundId === 'duff-slap';
        const isZap = soundId === 'el-zap';
        const startF =
          soundId === 'ac-tom-lo'
            ? 145
            : soundId === 'ac-tom-hi'
              ? 240
              : isDuff
                ? 290
                : isZap
                  ? 720
                  : 265;
        const endF = soundId === 'ac-tom-lo' ? 72 : isZap ? 95 : 120;
        const dur = isDuff ? 0.26 : isZap ? 0.22 : 0.28;

        const osc = ctx.createOscillator();
        const env = ctx.createGain();
        osc.type = isZap ? 'sawtooth' : 'triangle';
        osc.frequency.setValueAtTime(startF * rate, now);
        osc.frequency.exponentialRampToValueAtTime(endF * rate, now + dur * 0.75);
        env.gain.setValueAtTime(0.85, now);
        env.gain.exponentialRampToValueAtTime(0.001, now + dur);
        osc.connect(env);
        env.connect(dest);
        osc.start(now);
        osc.stop(now + dur + 0.02);
        registerOsc(osc);
        if (isDuff) spawnNoise(0.06, 'bandpass', 2100, 1.3, 0.52);
        break;
      }

      case 'ac-snare':
      case '808-snare': {
        const is808 = soundId === '808-snare';
        const osc = ctx.createOscillator();
        const oscEnv = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime((is808 ? 220 : 195) * rate, now);
        osc.frequency.exponentialRampToValueAtTime(110 * rate, now + 0.09);
        oscEnv.gain.setValueAtTime(0.75, now);
        oscEnv.gain.exponentialRampToValueAtTime(0.001, now + 0.14);
        osc.connect(oscEnv);
        oscEnv.connect(dest);
        osc.start(now);
        osc.stop(now + 0.16);
        registerOsc(osc);

        spawnNoise(is808 ? 0.18 : 0.22, 'highpass', is808 ? 1400 : 1100, 0.9, 0.72);
        break;
      }

      case 'ac-rim':
      case '808-rim':
      case 'el-perc': {
        const freq = soundId === 'el-perc' ? 760 : 490;
        const osc = ctx.createOscillator();
        const env = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq * rate, now);
        osc.frequency.exponentialRampToValueAtTime(freq * 0.72 * rate, now + 0.045);
        env.gain.setValueAtTime(0.82, now);
        env.gain.exponentialRampToValueAtTime(0.001, now + 0.065);
        osc.connect(env);
        env.connect(dest);
        osc.start(now);
        osc.stop(now + 0.08);
        registerOsc(osc);
        spawnNoise(0.02, 'bandpass', 3200, 2.0, 0.35);
        break;
      }

      case 'folk-clap':
      case '808-clap':
      case 'el-clap': {
        const delays = soundId === 'folk-clap' ? [0, 0.014, 0.028, 0.045] : [0, 0.011, 0.022];
        delays.forEach((d, i) => {
          if (!this.noiseBuffer) return;
          const src = ctx.createBufferSource();
          src.buffer = this.noiseBuffer;
          const filter = ctx.createBiquadFilter();
          filter.type = 'bandpass';
          filter.frequency.setValueAtTime((1350 + i * 160) * rate, now + d);
          filter.Q.setValueAtTime(1.6, now + d);
          const env = ctx.createGain();
          const tail = i === delays.length - 1 ? 0.22 : 0.045;
          env.gain.setValueAtTime(0.001, now + d);
          env.gain.linearRampToValueAtTime(0.68, now + d + 0.003);
          env.gain.exponentialRampToValueAtTime(0.001, now + d + tail);
          src.connect(filter);
          filter.connect(env);
          env.connect(dest);
          src.start(now + d);
          src.stop(now + d + tail + 0.02);
          registerNoise(src);
        });
        break;
      }

      case 'ac-hh-closed':
      case '808-hh':
      case 'ac-hh-open':
      case '808-oh':
      case 'ghunghroo':
      case 'el-shaker': {
        const isOpen = soundId === 'ac-hh-open' || soundId === '808-oh';
        const isShaker = soundId === 'ghunghroo' || soundId === 'el-shaker';
        const dur = isOpen ? 0.42 : isShaker ? 0.14 : 0.07;

        spawnNoise(dur, 'highpass', isShaker ? 5200 : 6800, 0.7, isOpen ? 0.55 : 0.48);
        if (!isShaker) {
          [320, 480, 650].forEach((f) => {
            const osc = ctx.createOscillator();
            const env = ctx.createGain();
            osc.type = 'square';
            osc.frequency.setValueAtTime(f * 3.1 * rate, now);
            env.gain.setValueAtTime(0.08, now);
            env.gain.exponentialRampToValueAtTime(0.001, now + dur * 0.65);
            const hp = ctx.createBiquadFilter();
            hp.type = 'highpass';
            hp.frequency.setValueAtTime(5500, now);
            osc.connect(hp);
            hp.connect(env);
            env.connect(dest);
            osc.start(now);
            osc.stop(now + dur);
            registerOsc(osc);
          });
        }
        break;
      }

      case 'manjira':
      case 'ac-ride':
      case 'ac-crash':
      case '808-cowbell': {
        const isCrash = soundId === 'ac-crash';
        const isManjira = soundId === 'manjira';
        const isCowbell = soundId === '808-cowbell';
        const dur = isCrash ? 1.15 : isManjira ? 0.65 : isCowbell ? 0.28 : 0.75;

        const freqs = isManjira
          ? [1880, 2940, 4120]
          : isCowbell
            ? [540, 800]
            : [510, 790, 1180, 1690];

        freqs.forEach((f, idx) => {
          const osc = ctx.createOscillator();
          const env = ctx.createGain();
          osc.type = isCowbell ? 'square' : 'sine';
          osc.frequency.setValueAtTime(f * rate, now);
          const amp = (isCowbell ? 0.35 : 0.24) / (1 + idx * 0.35);
          env.gain.setValueAtTime(amp, now);
          env.gain.exponentialRampToValueAtTime(0.0008, now + dur / (1 + idx * 0.18));
          osc.connect(env);
          env.connect(dest);
          osc.start(now);
          osc.stop(now + dur + 0.02);
          registerOsc(osc);
        });
        if (isCrash || soundId === 'ac-ride') {
          spawnNoise(dur * 0.9, 'highpass', 4800, 0.8, isCrash ? 0.55 : 0.3);
        }
        break;
      }

      case 'brass-stab':
      case 'el-chord': {
        const isBrass = soundId === 'brass-stab';
        const chord = isBrass ? [220, 277.18, 329.63, 440] : [261.63, 311.13, 392, 466.16];
        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(3200, now);
        filter.frequency.exponentialRampToValueAtTime(750, now + 0.26);
        const env = ctx.createGain();
        env.gain.setValueAtTime(0.001, now);
        env.gain.linearRampToValueAtTime(0.55, now + 0.01);
        env.gain.exponentialRampToValueAtTime(0.001, now + 0.32);
        filter.connect(env);
        env.connect(dest);

        chord.forEach((f) => {
          const osc = ctx.createOscillator();
          osc.type = 'sawtooth';
          osc.frequency.setValueAtTime(f * rate, now);
          osc.connect(filter);
          osc.start(now);
          osc.stop(now + 0.34);
          registerOsc(osc);
        });
        break;
      }

      default: {
        const osc = ctx.createOscillator();
        const env = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(220 * rate, now);
        osc.frequency.exponentialRampToValueAtTime(90 * rate, now + 0.14);
        env.gain.setValueAtTime(0.7, now);
        env.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
        osc.connect(env);
        env.connect(dest);
        osc.start(now);
        osc.stop(now + 0.2);
        registerOsc(osc);
      }
    }

    const voice: ActiveVoice = {
      chokeGroup: zone.chokeGroup,
      zoneKey,
      isLoop: false,
      stop: (fadeOutSec = 0.02) => {
        const t = ctx.currentTime;
        dest.gain.cancelScheduledValues(t);
        dest.gain.setValueAtTime(dest.gain.value, t);
        dest.gain.linearRampToValueAtTime(0.0001, t + fadeOutSec);
        stopCallbacks.forEach((cb) => cb());
      },
    };
    this.activeVoices.push(voice);
    window.setTimeout(() => {
      this.activeVoices = this.activeVoices.filter((v) => v !== voice);
    }, 1250);
  }
}

export const audioEngine = new OctapadAudioEngine();
