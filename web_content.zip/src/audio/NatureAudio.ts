import type { Settings } from '../data/worlds';

export class NatureAudio {
  private context: AudioContext | null = null;
  private master: GainNode | null = null;
  private layers: Partial<Record<'birds' | 'water' | 'wind', GainNode>> = {};
  private noise: AudioBuffer | null = null;
  private birdTimer: ReturnType<typeof setTimeout> | null = null;
  private running = false;
  private disposed = false;
  private settings: Settings | null = null;

  private initialize() {
    if (this.context) return;
    this.context = new AudioContext();
    const ctx = this.context;
    this.master = ctx.createGain();
    this.master.gain.value = 0;
    this.master.connect(ctx.destination);
    const buffer = ctx.createBuffer(1, ctx.sampleRate * 8, ctx.sampleRate);
    const samples = buffer.getChannelData(0);
    let previous = 0;
    for (let i = 0; i < samples.length; i += 1) {
      previous = (previous + (Math.random() * 2 - 1) * 0.025) / 1.025;
      samples[i] = previous * 5;
    }
    this.noise = buffer;

    for (const name of ['water', 'wind', 'birds'] as const) {
      const layer = ctx.createGain();
      layer.connect(this.master);
      this.layers[name] = layer;
      if (name === 'birds') continue;
      const source = ctx.createBufferSource();
      source.buffer = buffer;
      source.loop = true;
      source.playbackRate.value = name === 'water' ? 1.35 : 0.7;
      const filter = ctx.createBiquadFilter();
      filter.type = name === 'water' ? 'bandpass' : 'lowpass';
      filter.frequency.value = name === 'water' ? 950 : 340;
      filter.Q.value = 0.5;
      const swell = ctx.createGain();
      swell.gain.value = name === 'water' ? 0.24 : 0.32;
      const oscillator = ctx.createOscillator();
      oscillator.frequency.value = name === 'water' ? 0.21 : 0.075;
      const depth = ctx.createGain();
      depth.gain.value = 0.1;
      oscillator.connect(depth).connect(swell.gain);
      source.connect(filter).connect(swell).connect(layer);
      oscillator.start();
      source.start();
    }
  }

  update(settings: Settings) {
    this.settings = settings;
    if (!this.context || !this.master) return;
    const at = this.context.currentTime;
    this.master.gain.setTargetAtTime(this.running ? settings.volume / 100 : 0, at, 0.2);
    for (const name of ['birds', 'water', 'wind'] as const) {
      this.layers[name]?.gain.setTargetAtTime(settings[name] / 100, at, 0.2);
    }
  }

  async start(settings: Settings) {
    if (this.disposed) return;
    this.initialize();
    this.running = true;
    this.update(settings);
    await this.context?.resume();
    if (!this.birdTimer && this.running && !this.disposed) this.scheduleBirds();
  }

  pause() {
    this.running = false;
    if (this.birdTimer) clearTimeout(this.birdTimer);
    this.birdTimer = null;
    if (this.master && this.context) this.master.gain.setTargetAtTime(0, this.context.currentTime, 0.08);
  }

  private scheduleBirds() {
    if (!this.running || this.disposed || !this.context) return;
    this.chirp();
    this.birdTimer = setTimeout(() => this.scheduleBirds(), 1600 + Math.random() * 3300);
  }

  private chirp() {
    const ctx = this.context;
    const layer = this.layers.birds;
    if (!ctx || !layer) return;
    const base = 1900 + Math.random() * 1300;
    const panner = ctx.createStereoPanner();
    panner.pan.value = (Math.random() - 0.5) * 1.6;
    panner.connect(layer);
    const notes = 3 + Math.floor(Math.random() * 4);
    for (let i = 0; i < notes; i += 1) {
      const at = ctx.currentTime + i * 0.145;
      const tone = ctx.createOscillator();
      const envelope = ctx.createGain();
      tone.type = 'sine';
      tone.frequency.setValueAtTime(base * (i % 2 ? 1.2 : 1), at);
      tone.frequency.exponentialRampToValueAtTime(base * 1.55, at + 0.035);
      tone.frequency.exponentialRampToValueAtTime(base * 0.85, at + 0.105);
      envelope.gain.setValueAtTime(0, at);
      envelope.gain.linearRampToValueAtTime(0.075, at + 0.013);
      envelope.gain.exponentialRampToValueAtTime(0.0001, at + 0.12);
      tone.connect(envelope).connect(panner);
      tone.start(at);
      tone.stop(at + 0.14);
      tone.onended = () => {
        tone.disconnect();
        envelope.disconnect();
        if (i === notes - 1) panner.disconnect();
      };
    }
  }

  footstep() {
    const ctx = this.context;
    if (!this.running || !ctx || !this.master || !this.noise || !this.settings?.footsteps) return;
    const source = ctx.createBufferSource();
    source.buffer = this.noise;
    source.playbackRate.value = 0.85 + Math.random() * 0.3;
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 450;
    const envelope = ctx.createGain();
    const at = ctx.currentTime;
    envelope.gain.setValueAtTime(0, at);
    envelope.gain.linearRampToValueAtTime(0.7, at + 0.015);
    envelope.gain.exponentialRampToValueAtTime(0.001, at + 0.19);
    source.connect(filter).connect(envelope).connect(this.master);
    source.start(at, Math.random() * 4, 0.22);
    source.onended = () => {
      source.disconnect();
      filter.disconnect();
      envelope.disconnect();
    };
  }

  dispose() {
    this.disposed = true;
    this.pause();
    void this.context?.close();
    this.context = null;
  }
}