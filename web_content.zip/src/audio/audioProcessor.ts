/**
 * Audio processing utilities for PCM data, volume normalization, and silence insertion
 */

export function base64ToInt16Array(base64: string): Int16Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return new Int16Array(bytes.buffer);
}

export function int16ArrayToBase64(int16s: Int16Array): string {
  const bytes = new Uint8Array(int16s.buffer, int16s.byteOffset, int16s.byteLength);
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export function uint8ArrayToBase64(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export function createSilenceBuffer(durationSec: number, sampleRate: number = 24000): Int16Array {
  const sampleCount = Math.max(0, Math.floor(durationSec * sampleRate));
  return new Int16Array(sampleCount);
}

/**
 * Normalizes PCM audio to prevent clipping and maximize loudness smoothly
 */
export function normalizePcm(samples: Int16Array, targetVolume: number = 1.0): Int16Array {
  if (samples.length === 0) return samples;

  let maxVal = 0;
  for (let i = 0; i < samples.length; i++) {
    const abs = Math.abs(samples[i]);
    if (abs > maxVal) maxVal = abs;
  }

  if (maxVal === 0) return samples;

  const targetPeak = 32767 * Math.min(1.0, Math.max(0.1, targetVolume));
  const multiplier = targetPeak / maxVal;

  const result = new Int16Array(samples.length);
  for (let i = 0; i < samples.length; i++) {
    const scaled = Math.round(samples[i] * multiplier);
    result[i] = Math.max(-32768, Math.min(32767, scaled));
  }
  return result;
}

/**
 * Adjusts volume of PCM samples by a percentage factor (0.0 - 1.0)
 */
export function scaleVolume(samples: Int16Array, factor: number): Int16Array {
  const clamped = Math.max(0, Math.min(1.5, factor));
  const result = new Int16Array(samples.length);
  for (let i = 0; i < samples.length; i++) {
    const val = Math.round(samples[i] * clamped);
    result[i] = Math.max(-32768, Math.min(32767, val));
  }
  return result;
}

/**
 * Merges multiple PCM chunks with silence pauses
 */
export function concatenatePcmWithPauses(
  chunks: Int16Array[],
  pauseSec: number,
  sampleRate: number = 24000
): Int16Array {
  if (chunks.length === 0) return new Int16Array(0);
  if (chunks.length === 1) return chunks[0];

  const silenceSamples = Math.floor(pauseSec * sampleRate);
  let totalLength = 0;
  for (let i = 0; i < chunks.length; i++) {
    totalLength += chunks[i].length;
    if (i < chunks.length - 1) {
      totalLength += silenceSamples;
    }
  }

  const result = new Int16Array(totalLength);
  let offset = 0;

  for (let i = 0; i < chunks.length; i++) {
    result.set(chunks[i], offset);
    offset += chunks[i].length;
    if (i < chunks.length - 1) {
      offset += silenceSamples; // Already 0s
    }
  }

  return result;
}

/**
 * Generate formatted filename according to Requirement #10:
 * YiuVoice_Telugu_YYYY-MM-DD_HH-MM.mp3
 */
export function generateYiuVoiceFilename(format: 'mp3' | 'wav' = 'mp3'): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hours = String(now.getHours()).padStart(2, '0');
  const mins = String(now.getMinutes()).padStart(2, '0');

  return `YiuVoice_Telugu_${year}-${month}-${day}_${hours}-${mins}.${format}`;
}

/**
 * Applies studio-grade DSP enhancement to 16-bit PCM samples
 */
export function applyDspEffect(
  samples: Int16Array,
  effect: 'none' | 'studio' | 'cinematic-bass' | 'vocal-warmth' | 'crisp' = 'none',
  sampleRate: number = 24000
): Int16Array {
  if (effect === 'none' || samples.length === 0) return samples;

  const len = samples.length;
  const out = new Int16Array(len);

  if (effect === 'cinematic-bass') {
    // Low frequency boost (bass resonance for movie trailers)
    let prev = 0;
    const alpha = 0.08;
    for (let i = 0; i < len; i++) {
      const s = samples[i];
      prev += alpha * (s - prev);
      const enhanced = Math.round(s + prev * 0.45);
      out[i] = Math.max(-32768, Math.min(32767, enhanced));
    }
    return normalizePcm(out, 0.98);
  }

  if (effect === 'crisp') {
    // High frequency boost (crisp articulation for Telugu consonants)
    let prev = 0;
    const alpha = 0.5;
    for (let i = 0; i < len; i++) {
      const s = samples[i];
      const hp = s - prev;
      prev = s * alpha + prev * (1 - alpha);
      const enhanced = Math.round(s + hp * 0.35);
      out[i] = Math.max(-32768, Math.min(32767, enhanced));
    }
    return normalizePcm(out, 0.98);
  }

  if (effect === 'vocal-warmth') {
    // Warm mid-range boost
    let lp1 = 0;
    let lp2 = 0;
    for (let i = 0; i < len; i++) {
      const s = samples[i];
      lp1 += 0.15 * (s - lp1);
      lp2 += 0.04 * (s - lp2);
      const mid = lp1 - lp2;
      const enhanced = Math.round(s + mid * 0.3);
      out[i] = Math.max(-32768, Math.min(32767, enhanced));
    }
    return normalizePcm(out, 0.98);
  }

  if (effect === 'studio') {
    // Studio Broadcast: soft compression + loudness maximize
    for (let i = 0; i < len; i++) {
      const x = samples[i] / 32768;
      const y = Math.tanh(x * 1.25) / 1.1;
      out[i] = Math.round(y * 32767);
    }
    return normalizePcm(out, 0.98);
  }

  return samples;
}

