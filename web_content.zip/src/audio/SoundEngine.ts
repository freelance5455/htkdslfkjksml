// Web Audio API procedural sound synthesizer for BLACKOUT: DEAD RISING

export type SurfaceType = 'concrete' | 'grass' | 'wood' | 'metal' | 'water';

class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private zombieGain: GainNode | null = null;
  private voiceGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private ambientGain: GainNode | null = null;
  private isMuted: boolean = false;
  private isMusicPlaying: boolean = false;
  private musicInterval: number | null = null;

  // Volume levels (0 to 1)
  private masterVol = 0.85;
  private sfxVol = 0.85;
  private zombieVol = 0.85;
  private voiceVol = 0.9;
  private musicVol = 0.45;

  toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : this.masterVol, this.ctx.currentTime);
    }
    return this.isMuted;
  }

  getMuted(): boolean {
    return this.isMuted;
  }

  init() {
    if (this.ctx) return;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();

      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.masterVol, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.setValueAtTime(this.sfxVol, this.ctx.currentTime);
      this.sfxGain.connect(this.masterGain);

      this.zombieGain = this.ctx.createGain();
      this.zombieGain.gain.setValueAtTime(this.zombieVol, this.ctx.currentTime);
      this.zombieGain.connect(this.masterGain);

      this.voiceGain = this.ctx.createGain();
      this.voiceGain.gain.setValueAtTime(this.voiceVol, this.ctx.currentTime);
      this.voiceGain.connect(this.masterGain);

      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.setValueAtTime(this.musicVol, this.ctx.currentTime);
      this.musicGain.connect(this.masterGain);

      this.ambientGain = this.ctx.createGain();
      this.ambientGain.gain.setValueAtTime(0.3, this.ctx.currentTime);
      this.ambientGain.connect(this.masterGain);

      this.startAmbience();
    } catch (e) {
      console.warn('AudioContext initialization failed', e);
    }
  }

  resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  setMasterVolume(val: number) {
    this.masterVol = Math.max(0, Math.min(1, val));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(this.masterVol, this.ctx.currentTime, 0.05);
    }
  }

  setSfxVolume(val: number) {
    this.sfxVol = Math.max(0, Math.min(1, val));
    if (this.sfxGain && this.ctx) {
      this.sfxGain.gain.setTargetAtTime(this.sfxVol, this.ctx.currentTime, 0.05);
    }
  }

  setZombieVolume(val: number) {
    this.zombieVol = Math.max(0, Math.min(1, val));
    if (this.zombieGain && this.ctx) {
      this.zombieGain.gain.setTargetAtTime(this.zombieVol, this.ctx.currentTime, 0.05);
    }
  }

  setVoiceVolume(val: number) {
    this.voiceVol = Math.max(0, Math.min(1, val));
    if (this.voiceGain && this.ctx) {
      this.voiceGain.gain.setTargetAtTime(this.voiceVol, this.ctx.currentTime, 0.05);
    }
  }

  setMusicVolume(val: number) {
    this.musicVol = Math.max(0, Math.min(1, val));
    if (this.musicGain && this.ctx) {
      this.musicGain.gain.setTargetAtTime(this.musicVol, this.ctx.currentTime, 0.05);
    }
  }

  private createNoiseBuffer(duration: number): AudioBuffer {
    if (!this.ctx) throw new Error('No context');
    const bufferSize = this.ctx.sampleRate * duration;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }
    return buffer;
  }

  // --- WEAPON SOUNDS ---
  playShoot(type: 'rifle' | 'shotgun' | 'pistol' | 'sniper' | 'smg' | 'lmg' | 'dmr' | 'revolver' | 'raygun', silenced = false) {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const oscGain = this.ctx.createGain();
    osc.type = type === 'raygun' ? 'sawtooth' : 'triangle';

    let startFreq = 160;
    let endFreq = 30;
    let thumpDuration = 0.15;
    let thumpVolume = 0.8;

    if (type === 'shotgun') {
      startFreq = 190;
      endFreq = 20;
      thumpDuration = 0.28;
      thumpVolume = 1.0;
    } else if (type === 'pistol') {
      startFreq = 140;
      endFreq = 40;
      thumpDuration = 0.12;
      thumpVolume = 0.6;
    } else if (type === 'revolver') {
      startFreq = 210;
      endFreq = 25;
      thumpDuration = 0.35;
      thumpVolume = 1.1;
    } else if (type === 'raygun') {
      // Futuristic sci-fi plasma pew zap
      startFreq = 880;
      endFreq = 65;
      thumpDuration = 0.22;
      thumpVolume = 1.0;
    } else if (type === 'sniper') {
      startFreq = 240;
      endFreq = 16;
      thumpDuration = 0.45;
      thumpVolume = 1.15;
    } else if (type === 'dmr') {
      startFreq = 200;
      endFreq = 24;
      thumpDuration = 0.25;
      thumpVolume = 0.95;
    } else if (type === 'lmg') {
      startFreq = 175;
      endFreq = 28;
      thumpDuration = 0.16;
      thumpVolume = 0.9;
    } else if (type === 'smg') {
      startFreq = 130;
      endFreq = 45;
      thumpDuration = 0.09;
      thumpVolume = 0.55;
    }

    if (silenced) {
      thumpVolume *= 0.35;
      thumpDuration *= 0.7;
    }

    osc.frequency.setValueAtTime(startFreq, t);
    osc.frequency.exponentialRampToValueAtTime(endFreq, t + thumpDuration);

    oscGain.gain.setValueAtTime(thumpVolume, t);
    oscGain.gain.exponentialRampToValueAtTime(0.001, t + thumpDuration);

    osc.connect(oscGain);
    oscGain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + thumpDuration);

    const noiseDuration = type === 'shotgun' ? 0.3 : type === 'sniper' ? 0.45 : type === 'smg' ? 0.1 : 0.2;
    const noiseBuffer = this.createNoiseBuffer(noiseDuration);
    const noiseSource = this.ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;

    const noiseFilter = this.ctx.createBiquadFilter();
    if (silenced) {
      noiseFilter.type = 'lowpass';
      noiseFilter.frequency.setValueAtTime(1200, t);
      noiseFilter.frequency.exponentialRampToValueAtTime(300, t + noiseDuration);
    } else {
      noiseFilter.type = 'bandpass';
      noiseFilter.frequency.setValueAtTime(type === 'shotgun' ? 1800 : 2800, t);
      noiseFilter.Q.setValueAtTime(2.0, t);
    }

    const noiseGain = this.ctx.createGain();
    const blastVol = silenced ? 0.25 : type === 'shotgun' ? 0.9 : type === 'sniper' ? 0.95 : 0.7;
    noiseGain.gain.setValueAtTime(blastVol, t);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, t + noiseDuration);

    noiseSource.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(this.sfxGain);

    noiseSource.start(t);
    noiseSource.stop(t + noiseDuration);

    setTimeout(() => {
      this.playShellClink();
    }, 180 + Math.random() * 100);
  }

  playShellClink() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    const baseFreq = 2200 + Math.random() * 800;
    osc.frequency.setValueAtTime(baseFreq, t);
    osc.frequency.exponentialRampToValueAtTime(baseFreq * 0.9, t + 0.05);

    gain.gain.setValueAtTime(0.08, t);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.05);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.05);
  }

  playReload() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;

    const osc1 = this.ctx.createOscillator();
    const gain1 = this.ctx.createGain();
    osc1.frequency.setValueAtTime(300, t);
    osc1.frequency.exponentialRampToValueAtTime(80, t + 0.08);
    gain1.gain.setValueAtTime(0.3, t);
    gain1.gain.exponentialRampToValueAtTime(0.001, t + 0.08);
    osc1.connect(gain1);
    gain1.connect(this.sfxGain);
    osc1.start(t);
    osc1.stop(t + 0.08);

    setTimeout(() => {
      if (!this.ctx || !this.sfxGain) return;
      const t2 = this.ctx.currentTime;
      const osc2 = this.ctx.createOscillator();
      const gain2 = this.ctx.createGain();
      osc2.frequency.setValueAtTime(180, t2);
      osc2.frequency.exponentialRampToValueAtTime(450, t2 + 0.1);
      gain2.gain.setValueAtTime(0.4, t2);
      gain2.gain.exponentialRampToValueAtTime(0.001, t2 + 0.1);
      osc2.connect(gain2);
      gain2.connect(this.sfxGain);
      osc2.start(t2);
      osc2.stop(t2 + 0.1);
    }, 400);

    setTimeout(() => {
      if (!this.ctx || !this.sfxGain) return;
      const t3 = this.ctx.currentTime;
      const osc3 = this.ctx.createOscillator();
      const gain3 = this.ctx.createGain();
      osc3.type = 'sawtooth';
      osc3.frequency.setValueAtTime(600, t3);
      osc3.frequency.exponentialRampToValueAtTime(350, t3 + 0.12);
      gain3.gain.setValueAtTime(0.25, t3);
      gain3.gain.exponentialRampToValueAtTime(0.001, t3 + 0.12);
      osc3.connect(gain3);
      gain3.connect(this.sfxGain);
      osc3.start(t3);
      osc3.stop(t3 + 0.12);
    }, 850);
  }

  playDryFire() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(1200, t);
    gain.gain.setValueAtTime(0.2, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.04);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.04);
  }

  playWeaponSwitch() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(450, t);
    osc.frequency.exponentialRampToValueAtTime(180, t + 0.08);
    gain.gain.setValueAtTime(0.22, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.08);
  }

  playAdsSound() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(320, t);
    osc.frequency.exponentialRampToValueAtTime(540, t + 0.07);
    gain.gain.setValueAtTime(0.12, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.07);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.07);
  }

  playScopeZoomSound() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(750, t);
    osc.frequency.exponentialRampToValueAtTime(980, t + 0.1);
    gain.gain.setValueAtTime(0.14, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.1);
  }

  // --- HIT DETECTION & DAMAGE SOUNDS ---
  playHitMarker(isHeadshot = false) {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    if (isHeadshot) {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(2600, t);
      osc.frequency.exponentialRampToValueAtTime(1400, t + 0.18);
      gain.gain.setValueAtTime(0.45, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
    } else {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(900, t);
      osc.frequency.exponentialRampToValueAtTime(450, t + 0.06);
      gain.gain.setValueAtTime(0.25, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.06);
    }

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + (isHeadshot ? 0.18 : 0.06));
  }

  playPlayerHurt() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(130, t);
    osc.frequency.exponentialRampToValueAtTime(30, t + 0.15);
    gain.gain.setValueAtTime(0.7, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.15);
  }

  // --- ZOMBIE SOUNDS (FIXED & HIGH-CLARITY AUDIO - Requirement 17) ---
  playZombieGroan(
    type: 'walker' | 'runner' | 'brute' | 'crawler' = 'walker',
    mood: 'idle' | 'chase' | 'distant' | 'attack' = 'idle',
    pan: number = 0
  ) {
    if (!this.ctx || !this.zombieGain) return;
    this.resume();
    const t = this.ctx.currentTime;

    // Dual-oscillator vocal tract formant synthesis for realistic undead groaning
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();
    const formantFilter = this.ctx.createBiquadFilter();

    osc1.type = 'sawtooth';
    osc2.type = 'triangle';

    let pitchBase = 70 + Math.random() * 35;
    let pitchEnd = 50 + Math.random() * 25;
    let dur = 0.7 + Math.random() * 0.6;
    let volume = 0.45;

    if (type === 'runner') {
      pitchBase = 145 + Math.random() * 55;
      pitchEnd = 95 + Math.random() * 35;
      dur = 0.45;
      volume = 0.5;
    } else if (type === 'brute') {
      pitchBase = 42 + Math.random() * 16;
      pitchEnd = 26;
      dur = 1.1;
      volume = 0.65;
    } else if (type === 'crawler') {
      pitchBase = 100 + Math.random() * 40;
      pitchEnd = 70;
      dur = 0.55;
      volume = 0.4;
    }

    if (mood === 'distant') {
      volume *= 0.5;
      formantFilter.frequency.setValueAtTime(320, t);
    } else if (mood === 'chase') {
      pitchBase *= 1.25;
      pitchEnd *= 1.15;
      volume *= 1.2;
      formantFilter.frequency.setValueAtTime(type === 'runner' ? 950 : 650, t);
    } else {
      formantFilter.frequency.setValueAtTime(type === 'runner' ? 850 : 500, t);
    }

    osc1.frequency.setValueAtTime(pitchBase, t);
    osc1.frequency.linearRampToValueAtTime(pitchEnd, t + dur);

    osc2.frequency.setValueAtTime(pitchBase * 1.5, t);
    osc2.frequency.linearRampToValueAtTime(pitchEnd * 1.4, t + dur);

    formantFilter.type = 'lowpass';
    formantFilter.Q.setValueAtTime(3.5, t);

    gainNode.gain.setValueAtTime(0.01, t);
    gainNode.gain.linearRampToValueAtTime(volume, t + 0.12);
    gainNode.gain.exponentialRampToValueAtTime(0.001, t + dur);

    osc1.connect(formantFilter);
    osc2.connect(formantFilter);
    formantFilter.connect(gainNode);

    if (this.ctx.createStereoPanner) {
      const panner = this.ctx.createStereoPanner();
      panner.pan.setValueAtTime(Math.max(-1, Math.min(1, pan)), t);
      gainNode.connect(panner);
      panner.connect(this.zombieGain);
    } else {
      gainNode.connect(this.zombieGain);
    }

    osc1.start(t);
    osc2.start(t);
    osc1.stop(t + dur);
    osc2.stop(t + dur);
  }

  playZombieHurt() {
    if (!this.ctx || !this.zombieGain) return;
    this.resume();
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(155 + Math.random() * 45, t);
    osc.frequency.exponentialRampToValueAtTime(65, t + 0.16);

    gain.gain.setValueAtTime(0.4, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.16);

    osc.connect(gain);
    gain.connect(this.zombieGain);
    osc.start(t);
    osc.stop(t + 0.16);
  }

  playZombieAttack() {
    if (!this.ctx || !this.zombieGain) return;
    this.resume();
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(240 + Math.random() * 40, t);
    osc.frequency.exponentialRampToValueAtTime(60, t + 0.22);

    gain.gain.setValueAtTime(0.5, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.22);

    osc.connect(gain);
    gain.connect(this.zombieGain);
    osc.start(t);
    osc.stop(t + 0.22);
  }

  playZombieDeath() {
    if (!this.ctx || !this.zombieGain) return;
    this.resume();
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(140, t);
    osc.frequency.exponentialRampToValueAtTime(32, t + 0.4);

    gain.gain.setValueAtTime(0.45, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.4);

    osc.connect(gain);
    gain.connect(this.zombieGain);
    osc.start(t);
    osc.stop(t + 0.4);
  }

  // --- NEW WAVE HORDE WARNING AUDIO (Requirement 18) ---
  playWaveWarningHorde() {
    if (!this.ctx || !this.zombieGain) return;
    this.resume();
    const t = this.ctx.currentTime;

    // Distant ominous chorus of multi-pitch howling
    const freqs = [55, 65, 80, 95, 110];
    freqs.forEach((baseF, idx) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      const filter = this.ctx!.createBiquadFilter();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(baseF, t + idx * 0.08);
      osc.frequency.linearRampToValueAtTime(baseF * 0.8, t + 1.4);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(350, t);

      gain.gain.setValueAtTime(0.001, t + idx * 0.08);
      gain.gain.linearRampToValueAtTime(0.2, t + idx * 0.08 + 0.25);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 1.5);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.zombieGain!);

      osc.start(t + idx * 0.08);
      osc.stop(t + 1.5);
    });
  }

  // --- CHARACTER VOICE LINES (Requirement 26) ---
  playCharacterVoice(action: 'reload' | 'new_wave' | 'low_health' | 'buy_weapon' | 'kill_streak' | 'barricade_repair') {
    const lines: Record<string, string[]> = {
      reload: ["Cover me, reloading!", "Changing mag!", "Dry! Need cover!"],
      new_wave: ["Hostiles approaching!", "New wave incoming, check your corners!", "They're breaking through!"],
      low_health: ["Taking heavy damage!", "Critical vitals!", "Need to fall back!"],
      buy_weapon: ["Locked and loaded.", "Got the firepower.", "Armed and ready."],
      kill_streak: ["Target down, streak active!", "Unstoppable!", "Keep them coming!"],
      barricade_repair: ["Securing this entrance!", "Barrier reinforced.", "Holding the line!"],
    };

    const pool = lines[action] || ["Engaging hostiles."];
    const phrase = pool[Math.floor(Math.random() * pool.length)];
    this.speakAnnouncement(phrase);
  }

  // --- MOVEMENT SOUNDS & SURFACE FOOTSTEPS ---
  playFootstep(surface: SurfaceType = 'concrete') {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;

    if (surface === 'water') {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(240 + Math.random() * 60, t);
      osc.frequency.exponentialRampToValueAtTime(80, t + 0.12);
      gain.gain.setValueAtTime(0.18, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);
      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(t);
      osc.stop(t + 0.12);
      return;
    }

    if (surface === 'wood') {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(140 + Math.random() * 30, t);
      osc.frequency.exponentialRampToValueAtTime(60, t + 0.08);
      gain.gain.setValueAtTime(0.14, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);
      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(t);
      osc.stop(t + 0.08);
      return;
    }

    if (surface === 'metal') {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(450 + Math.random() * 80, t);
      osc.frequency.exponentialRampToValueAtTime(200, t + 0.07);
      gain.gain.setValueAtTime(0.12, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.07);
      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(t);
      osc.stop(t + 0.07);
      return;
    }

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(95 + Math.random() * 30, t);
    osc.frequency.exponentialRampToValueAtTime(40, t + 0.06);
    gain.gain.setValueAtTime(0.1, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.06);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.06);
  }

  playSlideSound() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;

    const buffer = this.createNoiseBuffer(0.5);
    const source = this.ctx.createBufferSource();
    source.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(800, t);
    filter.frequency.exponentialRampToValueAtTime(250, t + 0.45);
    filter.Q.setValueAtTime(2.5, t);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.25, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);

    source.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);

    source.start(t);
    source.stop(t + 0.45);
  }

  playJumpSound() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(120, t);
    osc.frequency.linearRampToValueAtTime(200, t + 0.1);
    gain.gain.setValueAtTime(0.12, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.1);
  }

  playLandSound() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(110, t);
    osc.frequency.exponentialRampToValueAtTime(30, t + 0.14);
    gain.gain.setValueAtTime(0.28, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.14);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.14);
  }

  // --- BARRICADES & DOORS ---
  playBarricadeRepair() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(380, t);
    osc.frequency.exponentialRampToValueAtTime(120, t + 0.1);
    gain.gain.setValueAtTime(0.35, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.1);
  }

  playBarricadeBreak() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(200, t);
    osc.frequency.exponentialRampToValueAtTime(50, t + 0.2);
    gain.gain.setValueAtTime(0.4, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.2);
  }

  playDoorOpen() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(180, t);
    osc.frequency.linearRampToValueAtTime(320, t + 0.25);
    gain.gain.setValueAtTime(0.18, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.25);
  }

  playDoorClose() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(140, t);
    osc.frequency.exponentialRampToValueAtTime(40, t + 0.18);
    gain.gain.setValueAtTime(0.35, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.18);
  }

  // --- TACTICAL VOICEOVER & ANNOUNCER ---
  speakAnnouncement(phrase: string) {
    if (this.isMuted) return;
    try {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(phrase);
        u.pitch = 0.9;
        u.rate = 1.05;
        u.volume = this.voiceVol;
        window.speechSynthesis.speak(u);
      }
    } catch {
      // Fallback
    }
  }

  // --- FANFARE & UI ---
  playRoundStart() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;

    const notes = [130.81, 164.81, 196.00, 246.94];
    notes.forEach((freq, idx) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, t + idx * 0.18);

      gain.gain.setValueAtTime(0.001, t + idx * 0.18);
      gain.gain.linearRampToValueAtTime(0.22, t + idx * 0.18 + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.18 + 0.9);

      osc.connect(gain);
      gain.connect(this.sfxGain!);
      osc.start(t + idx * 0.18);
      osc.stop(t + idx * 0.18 + 0.9);
    });
  }

  playBuySound() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(523.25, t);
    osc.frequency.setValueAtTime(659.25, t + 0.08);
    osc.frequency.setValueAtTime(783.99, t + 0.16);
    gain.gain.setValueAtTime(0.25, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.35);
  }

  playExplosion() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const oscGain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(90, t);
    osc.frequency.exponentialRampToValueAtTime(20, t + 0.8);
    oscGain.gain.setValueAtTime(0.9, t);
    oscGain.gain.exponentialRampToValueAtTime(0.001, t + 0.8);
    osc.connect(oscGain);
    oscGain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.8);

    const noiseBuffer = this.createNoiseBuffer(0.9);
    const noiseSource = this.ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(800, t);
    filter.frequency.exponentialRampToValueAtTime(100, t + 0.9);
    const noiseGain = this.ctx.createGain();
    noiseGain.gain.setValueAtTime(0.8, t);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, t + 0.9);
    noiseSource.connect(filter);
    filter.connect(noiseGain);
    noiseGain.connect(this.sfxGain);
    noiseSource.start(t);
    noiseSource.stop(t + 0.9);
  }

  playUIClick() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1100, t);
    osc.frequency.exponentialRampToValueAtTime(700, t + 0.04);
    gain.gain.setValueAtTime(0.12, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.04);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.04);
  }

  playMenuSelect() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, t);
    osc.frequency.exponentialRampToValueAtTime(1200, t + 0.05);
    gain.gain.setValueAtTime(0.1, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.05);
  }

  // Bullet hit sound effect (Requirement 13)
  playBulletHit(surface: 'flesh' | 'headshot' | 'armor' = 'flesh') {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    if (surface === 'headshot') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(2600, t);
      osc.frequency.exponentialRampToValueAtTime(1400, t + 0.16);
      gain.gain.setValueAtTime(0.5, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.16);
    } else if (surface === 'armor') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(550, t);
      osc.frequency.exponentialRampToValueAtTime(180, t + 0.08);
      gain.gain.setValueAtTime(0.35, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);
    } else {
      // Flesh squelch
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(180, t);
      osc.frequency.exponentialRampToValueAtTime(45, t + 0.08);
      gain.gain.setValueAtTime(0.35, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);
    }

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + (surface === 'headshot' ? 0.16 : 0.08));
  }

  playMenuConfirm() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(600, t);
    osc.frequency.setValueAtTime(900, t + 0.05);
    gain.gain.setValueAtTime(0.14, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.15);
  }

  playMenuBack() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(700, t);
    osc.frequency.setValueAtTime(450, t + 0.05);
    gain.gain.setValueAtTime(0.12, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.12);
  }

  playIntroStinger() {
    if (!this.ctx || !this.sfxGain) return;
    this.resume();
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(70, t);
    osc.frequency.exponentialRampToValueAtTime(45, t + 1.6);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(500, t);
    filter.frequency.linearRampToValueAtTime(200, t + 1.6);

    gain.gain.setValueAtTime(0.001, t);
    gain.gain.linearRampToValueAtTime(0.5, t + 0.2);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 1.8);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 1.8);
  }

  // --- AMBIENCE & CINEMATIC MUSIC ---
  private startAmbience() {
    if (!this.ctx || !this.ambientGain) return;
    const osc = this.ctx.createOscillator();
    const filter = this.ctx.createBiquadFilter();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(55, this.ctx.currentTime);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(150, this.ctx.currentTime);

    osc.connect(filter);
    filter.connect(this.ambientGain);
    osc.start();
  }

  startCinematicMusic() {
    if (this.isMusicPlaying || !this.ctx || !this.musicGain) return;
    this.isMusicPlaying = true;
    this.resume();

    const scale = [73.42, 87.31, 98.00, 110.00, 130.81, 146.83];
    let noteIdx = 0;

    this.musicInterval = window.setInterval(() => {
      if (!this.ctx || !this.musicGain || !this.isMusicPlaying) return;
      const t = this.ctx.currentTime;
      const freq = scale[noteIdx % scale.length];
      noteIdx = (noteIdx + 1) % scale.length;

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, t);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(380 + Math.sin(t * 0.5) * 150, t);
      filter.Q.setValueAtTime(4.0, t);

      gain.gain.setValueAtTime(0.001, t);
      gain.gain.linearRampToValueAtTime(0.18, t + 0.1);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 1.2);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.musicGain);

      osc.start(t);
      osc.stop(t + 1.2);
    }, 450);
  }

  stopCinematicMusic() {
    this.isMusicPlaying = false;
    if (this.musicInterval) {
      clearInterval(this.musicInterval);
      this.musicInterval = null;
    }
  }
}

export const sound = new SoundEngine();
