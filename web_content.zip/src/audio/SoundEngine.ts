// Zero-dependency Web Audio API procedural automotive sound synthesizer

class SoundEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private isEngineRunning: boolean = false;

  private primaryOsc: OscillatorNode | null = null;
  private subOsc: OscillatorNode | null = null;
  private harmonicOsc: OscillatorNode | null = null;
  private engineFilter: BiquadFilterNode | null = null;
  private engineGain: GainNode | null = null;

  private skidNoiseNode: AudioBufferSourceNode | null = null;
  private skidFilter: BiquadFilterNode | null = null;
  private skidGain: GainNode | null = null;

  private nitroOsc: OscillatorNode | null = null;
  private nitroGain: GainNode | null = null;
  private lastGear: number = 1;

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (this.engineGain && this.ctx) {
      this.engineGain.gain.setTargetAtTime(muted ? 0 : 0.14, this.ctx.currentTime, 0.05);
    }
    if (this.skidGain && this.ctx && muted) {
      this.skidGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.04);
    }
    if (this.nitroGain && this.ctx && muted) {
      this.nitroGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.04);
    }
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public startEngine() {
    const ctx = this.ensureContext();
    if (!ctx || this.isEngineRunning) return;

    try {
      this.engineFilter = ctx.createBiquadFilter();
      this.engineFilter.type = 'lowpass';
      this.engineFilter.frequency.value = 320;
      this.engineFilter.Q.value = 3.5;

      this.engineGain = ctx.createGain();
      this.engineGain.gain.value = this.isMuted ? 0 : 0.12;

      this.primaryOsc = ctx.createOscillator();
      this.primaryOsc.type = 'sawtooth';
      this.primaryOsc.frequency.value = 58;

      this.subOsc = ctx.createOscillator();
      this.subOsc.type = 'triangle';
      this.subOsc.frequency.value = 29;

      this.harmonicOsc = ctx.createOscillator();
      this.harmonicOsc.type = 'square';
      this.harmonicOsc.frequency.value = 87;

      const subGain = ctx.createGain();
      subGain.gain.value = 0.65;
      const harmGain = ctx.createGain();
      harmGain.gain.value = 0.22;

      this.primaryOsc.connect(this.engineFilter);
      this.subOsc.connect(subGain);
      subGain.connect(this.engineFilter);
      this.harmonicOsc.connect(harmGain);
      harmGain.connect(this.engineFilter);

      this.engineFilter.connect(this.engineGain);
      this.engineGain.connect(ctx.destination);

      this.primaryOsc.start();
      this.subOsc.start();
      this.harmonicOsc.start();

      // Tire skid noise generator
      const bufferSize = ctx.sampleRate * 2;
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }

      this.skidNoiseNode = ctx.createBufferSource();
      this.skidNoiseNode.buffer = noiseBuffer;
      this.skidNoiseNode.loop = true;

      this.skidFilter = ctx.createBiquadFilter();
      this.skidFilter.type = 'bandpass';
      this.skidFilter.frequency.value = 1350;
      this.skidFilter.Q.value = 4.2;

      this.skidGain = ctx.createGain();
      this.skidGain.gain.value = 0;

      this.skidNoiseNode.connect(this.skidFilter);
      this.skidFilter.connect(this.skidGain);
      this.skidGain.connect(ctx.destination);
      this.skidNoiseNode.start();

      // Nitro turbine whine oscillator
      this.nitroOsc = ctx.createOscillator();
      this.nitroOsc.type = 'sine';
      this.nitroOsc.frequency.value = 440;
      this.nitroGain = ctx.createGain();
      this.nitroGain.gain.value = 0;
      this.nitroOsc.connect(this.nitroGain);
      this.nitroGain.connect(ctx.destination);
      this.nitroOsc.start();

      this.isEngineRunning = true;
    } catch {
      // Ignore audio autoplay restrictions until next user gesture
    }
  }

  public updateTelemetry(speedKmh: number, rpm: number, gear: number, isDrifting: boolean, isNitro: boolean, isActiveGameplay: boolean) {
    if (!this.isEngineRunning) {
      if (isActiveGameplay && !this.isMuted) this.startEngine();
      return;
    }
    const ctx = this.ctx;
    if (!ctx) return;

    const now = ctx.currentTime;
    if (!isActiveGameplay || this.isMuted) {
      this.engineGain?.gain.setTargetAtTime(0, now, 0.08);
      this.skidGain?.gain.setTargetAtTime(0, now, 0.05);
      this.nitroGain?.gain.setTargetAtTime(0, now, 0.05);
      return;
    }

    // Trigger subtle gear shift exhaust crackle when shifting up
    if (gear !== this.lastGear) {
      if (gear > this.lastGear && speedKmh > 40) {
        this.playGearShiftPop();
      }
      this.lastGear = gear;
    }

    const rpmNorm = Math.max(0, Math.min(1, (rpm - 1000) / 8000));
    const baseFreq = 46 + rpmNorm * 135 + (gear - 1) * 8;

    this.primaryOsc?.frequency.setTargetAtTime(baseFreq, now, 0.03);
    this.subOsc?.frequency.setTargetAtTime(baseFreq * 0.5, now, 0.03);
    this.harmonicOsc?.frequency.setTargetAtTime(baseFreq * 1.5, now, 0.03);

    const filterCutoff = 220 + rpmNorm * 950 + (isNitro ? 500 : 0);
    this.engineFilter?.frequency.setTargetAtTime(filterCutoff, now, 0.04);

    const targetGain = 0.08 + rpmNorm * 0.07 + (isNitro ? 0.03 : 0);
    this.engineGain?.gain.setTargetAtTime(targetGain, now, 0.05);

    // Drift tire squeal
    const skidVolume = isDrifting && speedKmh > 55 ? Math.min(0.09, ((speedKmh - 55) / 250) * 0.09) : 0;
    this.skidGain?.gain.setTargetAtTime(skidVolume, now, 0.05);
    if (isDrifting && this.skidFilter) {
      this.skidFilter.frequency.setTargetAtTime(1150 + (speedKmh % 400), now, 0.05);
    }

    // Nitro boost turbine spool
    const nitroVol = isNitro ? 0.065 : 0;
    this.nitroGain?.gain.setTargetAtTime(nitroVol, now, 0.06);
    if (isNitro && this.nitroOsc) {
      this.nitroOsc.frequency.setTargetAtTime(520 + rpmNorm * 480, now, 0.05);
    }
  }

  public playGearShiftPop() {
    if (this.isMuted) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(140, now);
    osc.frequency.exponentialRampToValueAtTime(42, now + 0.07);

    gain.gain.setValueAtTime(0.14, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.075);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.08);
  }

  public playCollisionImpact(intensity = 1) {
    if (this.isMuted) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(110 * Math.min(1.4, intensity), now);
    osc.frequency.exponentialRampToValueAtTime(28, now + 0.16);

    gain.gain.setValueAtTime(Math.min(0.26, 0.16 * intensity), now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.17);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.18);
  }

  public playCountdownBeep(isFinalGo = false) {
    if (this.isMuted) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(isFinalGo ? 880 : 440, now);

    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + (isFinalGo ? 0.35 : 0.18));

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + (isFinalGo ? 0.36 : 0.19));
  }

  public playLapChime(isVictory = false) {
    if (this.isMuted) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const notes = isVictory ? [523.25, 659.25, 783.99, 1046.5] : [587.33, 880];
    notes.forEach((freq, idx) => {
      const start = ctx.currentTime + idx * 0.09;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, start);

      gain.gain.setValueAtTime(0.14, start);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.28);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(start);
      osc.stop(start + 0.29);
    });
  }
}

export const soundEngine = new SoundEngine();
