/**
 * Procedural Web Audio Sound Engine for Ayush Family Adventure
 * Zero external mp3 dependencies, completely synthesized.
 */
import { CharacterId } from '../types/game';

class SoundEngine {
  private ctx: AudioContext | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private isMusicPlaying = false;
  private musicTimer: number | null = null;
  private musicStep = 0;
  public soundEnabled = true;
  public musicEnabled = true;

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();

      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = 0.22;
      this.musicGain.connect(this.ctx.destination);

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.value = 0.45;
      this.sfxGain.connect(this.ctx.destination);
    }

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setSoundEnabled(enabled: boolean) {
    this.soundEnabled = enabled;
  }

  public setMusicEnabled(enabled: boolean) {
    this.musicEnabled = enabled;
    if (!enabled && this.isMusicPlaying) {
      this.stopMusic();
    } else if (enabled && !this.isMusicPlaying) {
      this.startMusic();
    }
  }

  // Plays comical jump sound
  public playJump() {
    if (!this.soundEnabled) return;
    this.initContext();
    if (!this.ctx || !this.sfxGain) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(580, now + 0.18);

    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.2);
  }

  // Footstep light tap
  public playStep() {
    if (!this.soundEnabled) return;
    this.initContext();
    if (!this.ctx || !this.sfxGain) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(100 + Math.random() * 30, now);
    osc.frequency.exponentialRampToValueAtTime(40, now + 0.05);

    gain.gain.setValueAtTime(0.08, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.06);
  }

  // Coin collect twinkle
  public playCoin() {
    if (!this.soundEnabled) return;
    this.initContext();
    if (!this.ctx || !this.sfxGain) return;

    const now = this.ctx.currentTime;
    const freqs = [880, 1174.66, 1760]; // A5, D6, A6

    freqs.forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.05);

      gain.gain.setValueAtTime(0.25, now + idx * 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.05 + 0.15);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(now + idx * 0.05);
      osc.stop(now + idx * 0.05 + 0.16);
    });
  }

  // Star / big item collect chime
  public playStar() {
    if (!this.soundEnabled) return;
    this.initContext();
    if (!this.ctx || !this.sfxGain) return;

    const now = this.ctx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.5, 1318.51]; // C5, E5, G5, C6, E6

    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.06);

      gain.gain.setValueAtTime(0.28, now + idx * 0.06);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.06 + 0.28);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(now + idx * 0.06);
      osc.stop(now + idx * 0.06 + 0.3);
    });
  }

  // Cute animal-crossing style voice blip per character
  public playSpeechBlip(character: CharacterId) {
    if (!this.soundEnabled) return;
    this.initContext();
    if (!this.ctx || !this.sfxGain) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    let baseFreq = 420;
    let waveType: OscillatorType = 'triangle';

    switch (character) {
      case 'ayush':
        baseFreq = 380 + Math.random() * 80;
        waveType = 'triangle';
        break;
      case 'arav':
        baseFreq = 540 + Math.random() * 120; // higher energetic kid pitch
        waveType = 'sine';
        break;
      case 'akshhara':
        baseFreq = 480 + Math.random() * 100; // cheeky sister
        waveType = 'triangle';
        break;
      case 'ripin':
        baseFreq = 160 + Math.random() * 40; // deep dad voice
        waveType = 'sawtooth';
        break;
      case 'anjeeta':
        baseFreq = 320 + Math.random() * 60; // warm mom voice
        waveType = 'sine';
        break;
    }

    osc.type = waveType;
    osc.frequency.setValueAtTime(baseFreq, now);
    osc.frequency.exponentialRampToValueAtTime(baseFreq * (0.9 + Math.random() * 0.3), now + 0.06);

    gain.gain.setValueAtTime(0.12, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.07);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.07);
  }

  // Comical argument "boing / slide"
  public playComicalBoing() {
    if (!this.soundEnabled) return;
    this.initContext();
    if (!this.ctx || !this.sfxGain) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(350, now);
    osc.frequency.linearRampToValueAtTime(140, now + 0.15);
    osc.frequency.linearRampToValueAtTime(450, now + 0.3);

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.35);
  }

  // Level Complete / Victory Fanfare
  public playVictory() {
    if (!this.soundEnabled) return;
    this.initContext();
    if (!this.ctx || !this.sfxGain) return;

    const now = this.ctx.currentTime;
    // Classic cheerful victorious fanfare chord progression
    const sequence = [
      { t: 0.00, f: 523.25 }, // C5
      { t: 0.12, f: 523.25 }, // C5
      { t: 0.24, f: 523.25 }, // C5
      { t: 0.36, f: 659.25 }, // E5
      { t: 0.52, f: 783.99 }, // G5
      { t: 0.68, f: 659.25 }, // E5
      { t: 0.80, f: 1046.50 }, // C6 (long hold)
    ];

    sequence.forEach(({ t, f }, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      const duration = idx === sequence.length - 1 ? 0.65 : 0.14;

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, now + t);

      gain.gain.setValueAtTime(0.3, now + t);
      gain.gain.exponentialRampToValueAtTime(0.001, now + t + duration);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(now + t);
      osc.stop(now + t + duration);
    });
  }

  // Cheerful background music loop with tabla synth & playful melody
  public startMusic() {
    if (this.isMusicPlaying || !this.musicEnabled) return;
    this.initContext();
    this.isMusicPlaying = true;
    this.musicStep = 0;

    const tempo = 126; // cheerful BPM
    const stepInterval = (60 / tempo) / 4; // 16th note in seconds

    // Raag Bilawal / cheerful pentatonic notes in C major
    // C4, D4, E4, G4, A4, C5, D5, E5
    const melody = [
      523.25, 0, 587.33, 659.25, 0, 783.99, 659.25, 587.33,
      523.25, 659.25, 0, 783.99, 880.00, 0, 783.99, 0,
      659.25, 0, 783.99, 880.00, 1046.50, 880.00, 783.99, 659.25,
      587.33, 0, 659.25, 523.25, 0, 0, 523.25, 0,
    ];

    const bass = [
      130.81, 0, 0, 130.81, 164.81, 0, 0, 164.81,
      196.00, 0, 0, 196.00, 130.81, 0, 164.81, 196.00,
    ];

    const playNextBar = () => {
      if (!this.isMusicPlaying || !this.ctx || !this.musicGain) return;
      const now = this.ctx.currentTime;

      // 1. Synth Tabla / Percussion pattern (Dha, Dhin, Tin, Ta feel)
      const beat16 = this.musicStep % 16;
      if (beat16 === 0 || beat16 === 8) {
        // Bass drum / Bayan (pitch drop boom)
        const osc = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        osc.frequency.setValueAtTime(110, now);
        osc.frequency.exponentialRampToValueAtTime(45, now + 0.12);
        g.gain.setValueAtTime(0.22, now);
        g.gain.exponentialRampToValueAtTime(0.001, now + 0.14);
        osc.connect(g);
        g.connect(this.musicGain);
        osc.start(now);
        osc.stop(now + 0.14);
      }

      if (beat16 === 4 || beat16 === 12) {
        // Dayan snap / high tabla rim
        const osc = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(320, now);
        osc.frequency.exponentialRampToValueAtTime(280, now + 0.08);
        g.gain.setValueAtTime(0.18, now);
        g.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
        osc.connect(g);
        g.connect(this.musicGain);
        osc.start(now);
        osc.stop(now + 0.09);
      }

      // 2. Playful melody note
      const melFreq = melody[this.musicStep % melody.length];
      if (melFreq > 0) {
        const osc = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(melFreq, now);

        // light vibrato for cheerful sitar/flute vibe
        g.gain.setValueAtTime(0.12, now);
        g.gain.exponentialRampToValueAtTime(0.001, now + stepInterval * 1.8);

        osc.connect(g);
        g.connect(this.musicGain);
        osc.start(now);
        osc.stop(now + stepInterval * 1.8);
      }

      // 3. Bass line
      const bassFreq = bass[this.musicStep % bass.length];
      if (bassFreq > 0) {
        const osc = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(bassFreq, now);

        g.gain.setValueAtTime(0.15, now);
        g.gain.exponentialRampToValueAtTime(0.001, now + stepInterval * 2);

        osc.connect(g);
        g.connect(this.musicGain);
        osc.start(now);
        osc.stop(now + stepInterval * 2);
      }

      this.musicStep++;
      this.musicTimer = window.setTimeout(playNextBar, stepInterval * 1000);
    };

    playNextBar();
  }

  public stopMusic() {
    this.isMusicPlaying = false;
    if (this.musicTimer !== null) {
      clearTimeout(this.musicTimer);
      this.musicTimer = null;
    }
  }
}

export const soundEngine = new SoundEngine();
