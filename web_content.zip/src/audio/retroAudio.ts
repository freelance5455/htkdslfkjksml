/**
 * Pure Web Audio API Synthesizer for Retro Arcade Gaming
 * Zero external audio files required — ultra-reliable, zero latency, authentic 8-bit/16-bit sound!
 * Includes Light Background Chiptune Music (موسيقى خفيفة) and Dynamic Engine Revs
 */

class RetroAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private engineOsc1: OscillatorNode | null = null;
  private engineOsc2: OscillatorNode | null = null;
  private engineFilter: BiquadFilterNode | null = null;
  private engineGain: GainNode | null = null;
  private isMuted: boolean = false;
  private isMusicMuted: boolean = false;
  private isInitialized: boolean = false;
  private volume: number = 0.5;
  private musicVolume: number = 0.22;

  // Music loop state
  private musicGain: GainNode | null = null;
  private musicFilter: BiquadFilterNode | null = null;
  private musicTimer: number | null = null;
  private musicStep: number = 0;
  private isMusicPlaying: boolean = false;

  constructor() {
    // Check localStorage for preferences
    try {
      const savedMute = localStorage.getItem('chamsou_race_muted');
      if (savedMute !== null) {
        this.isMuted = savedMute === 'true';
      }
      const savedMusicMute = localStorage.getItem('chamsou_race_music_muted');
      if (savedMusicMute !== null) {
        this.isMusicMuted = savedMusicMute === 'true';
      }
      const savedVol = localStorage.getItem('chamsou_race_vol');
      if (savedVol !== null) {
        this.volume = parseFloat(savedVol) || 0.5;
      }
    } catch {
      // ignore
    }
  }

  public init() {
    if (this.isInitialized && this.ctx && this.ctx.state === 'running') return;

    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!this.ctx) {
        this.ctx = new AudioCtx();
      }
      if (this.ctx.state === 'suspended') {
        this.ctx.resume();
      }

      if (!this.masterGain && this.ctx) {
        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : this.volume, this.ctx.currentTime);
        this.masterGain.connect(this.ctx.destination);
      }

      if (!this.musicGain && this.ctx && this.masterGain) {
        this.musicGain = this.ctx.createGain();
        this.musicFilter = this.ctx.createBiquadFilter();
        this.musicFilter.type = 'lowpass';
        this.musicFilter.frequency.setValueAtTime(750, this.ctx.currentTime); // Keep it soft and warm
        this.musicGain.gain.setValueAtTime(this.isMusicMuted ? 0 : this.musicVolume, this.ctx.currentTime);

        this.musicGain.connect(this.musicFilter);
        this.musicFilter.connect(this.masterGain);
      }

      this.isInitialized = true;
    } catch (e) {
      console.warn('AudioContext init error:', e);
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    try {
      localStorage.setItem('chamsou_race_muted', String(muted));
    } catch {
      // ignore
    }

    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(muted ? 0 : this.volume, this.ctx.currentTime);
    }
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  public setMusicMuted(muted: boolean) {
    this.isMusicMuted = muted;
    try {
      localStorage.setItem('chamsou_race_music_muted', String(muted));
    } catch {
      // ignore
    }
    if (this.musicGain && this.ctx) {
      this.musicGain.gain.setValueAtTime(muted ? 0 : this.musicVolume, this.ctx.currentTime);
    }
  }

  public getIsMusicMuted(): boolean {
    return this.isMusicMuted;
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    try {
      localStorage.setItem('chamsou_race_vol', String(this.volume));
    } catch {
      // ignore
    }
    if (!this.isMuted && this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
    }
  }

  public getVolume(): number {
    return this.volume;
  }

  /**
   * LIGHT RETRO BACKGROUND MUSIC (موسيقى خفيفة)
   * Calming, cheerful Algerian retro road trip melody
   */
  public startMusic() {
    this.init();
    if (this.isMusicPlaying) return;
    this.isMusicPlaying = true;
    this.musicStep = 0;

    // Melody notes (Hz) with soft walking bass
    // Pentatonic, peaceful, rhythmic:
    // C4=261.63, D4=293.66, E4=329.63, G4=392.00, A4=440.00, C5=523.25, D5=587.33
    const leadPattern = [
      329.63, 392.00, 523.25, 392.00, 440.00, 392.00, 329.63, 293.66,
      261.63, 329.63, 392.00, 329.63, 293.66, 261.63, 293.66, 329.63,
      392.00, 440.00, 523.25, 440.00, 587.33, 523.25, 440.00, 392.00,
      329.63, 392.00, 440.00, 392.00, 329.63, 293.66, 261.63, 0
    ];

    const bassPattern = [
      130.81, 0, 130.81, 0, 146.83, 0, 146.83, 0,
      164.81, 0, 164.81, 0, 174.61, 0, 174.61, 0,
      130.81, 0, 130.81, 0, 146.83, 0, 146.83, 0,
      196.00, 0, 196.00, 0, 130.81, 0, 130.81, 0
    ];

    const stepDuration = 185; // ms per 16th note

    const playNextStep = () => {
      if (!this.isMusicPlaying || !this.ctx || !this.musicGain) return;

      const t = this.ctx.currentTime;
      const idx = this.musicStep % leadPattern.length;
      const leadFreq = leadPattern[idx];
      const bassFreq = bassPattern[idx];

      // Play soft melody lead (warm triangle)
      if (leadFreq > 0 && !this.isMusicMuted && !this.isMuted) {
        const osc = this.ctx.createOscillator();
        const noteGain = this.ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(leadFreq, t);

        // Soft attack and gentle release
        noteGain.gain.setValueAtTime(0, t);
        noteGain.gain.linearRampToValueAtTime(0.09, t + 0.02);
        noteGain.gain.exponentialRampToValueAtTime(0.002, t + 0.16);

        osc.connect(noteGain);
        noteGain.connect(this.musicGain);

        osc.start(t);
        osc.stop(t + 0.17);
      }

      // Play soft acoustic bass note
      if (bassFreq > 0 && !this.isMusicMuted && !this.isMuted) {
        const bassOsc = this.ctx.createOscillator();
        const bassNoteGain = this.ctx.createGain();

        bassOsc.type = 'sine';
        bassOsc.frequency.setValueAtTime(bassFreq, t);

        bassNoteGain.gain.setValueAtTime(0.08, t);
        bassNoteGain.gain.exponentialRampToValueAtTime(0.001, t + 0.28);

        bassOsc.connect(bassNoteGain);
        bassNoteGain.connect(this.musicGain);

        bassOsc.start(t);
        bassOsc.stop(t + 0.29);
      }

      this.musicStep++;
      this.musicTimer = window.setTimeout(playNextStep, stepDuration);
    };

    playNextStep();
  }

  public stopMusic() {
    this.isMusicPlaying = false;
    if (this.musicTimer !== null) {
      clearTimeout(this.musicTimer);
      this.musicTimer = null;
    }
  }

  public pauseMusic() {
    this.isMusicPlaying = false;
    if (this.musicTimer !== null) {
      clearTimeout(this.musicTimer);
      this.musicTimer = null;
    }
  }

  public resumeMusic() {
    if (!this.isMusicPlaying) {
      this.startMusic();
    }
  }

  /**
   * Start or sustain the engine revving sound
   */
  public updateEngine(speedRatio: number, isAccelerating: boolean, isBraking: boolean) {
    if (!this.isInitialized || !this.ctx || !this.masterGain || this.isMuted) return;

    const t = this.ctx.currentTime;

    if (!this.engineOsc1) {
      try {
        this.engineOsc1 = this.ctx.createOscillator();
        this.engineOsc2 = this.ctx.createOscillator();
        this.engineFilter = this.ctx.createBiquadFilter();
        this.engineGain = this.ctx.createGain();

        this.engineOsc1.type = 'sawtooth';
        this.engineOsc2.type = 'triangle';

        this.engineFilter.type = 'lowpass';
        this.engineFilter.frequency.setValueAtTime(320, t);
        this.engineFilter.Q.setValueAtTime(2, t);

        this.engineGain.gain.setValueAtTime(0.07, t);

        this.engineOsc1.connect(this.engineFilter);
        this.engineOsc2.connect(this.engineFilter);
        this.engineFilter.connect(this.engineGain);
        this.engineGain.connect(this.masterGain);

        this.engineOsc1.start();
        this.engineOsc2.start();
      } catch {
        return;
      }
    }

    if (this.engineOsc1 && this.engineOsc2 && this.engineFilter && this.engineGain) {
      // Calculate pitch from speed (55Hz idle to ~260Hz redline)
      const baseFreq = 55 + speedRatio * 180 + (isAccelerating ? 15 : 0) - (isBraking ? 10 : 0);
      this.engineOsc1.frequency.setTargetAtTime(Math.max(40, baseFreq), t, 0.05);
      this.engineOsc2.frequency.setTargetAtTime(Math.max(40, baseFreq * 0.5), t, 0.05);

      const filterFreq = 250 + speedRatio * 850 + (isAccelerating ? 150 : 0);
      this.engineFilter.frequency.setTargetAtTime(filterFreq, t, 0.08);

      const targetGain = 0.03 + speedRatio * 0.07;
      this.engineGain.gain.setTargetAtTime(targetGain, t, 0.05);
    }
  }

  public stopEngine() {
    if (this.engineGain && this.ctx) {
      this.engineGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.1);
    }
    setTimeout(() => {
      if (this.engineOsc1) {
        try {
          this.engineOsc1.stop();
          this.engineOsc2?.stop();
          this.engineOsc1.disconnect();
          this.engineOsc2?.disconnect();
        } catch {
          // ignore
        }
        this.engineOsc1 = null;
        this.engineOsc2 = null;
        this.engineGain = null;
        this.engineFilter = null;
      }
    }, 150);
  }

  /**
   * Algerian style Klaxon / Car Horn ("Bip-bip!")
   */
  public playHorn() {
    this.init();
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    const t = this.ctx.currentTime;
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc1.type = 'sawtooth';
    osc2.type = 'square';
    osc1.frequency.setValueAtTime(420, t);
    osc2.frequency.setValueAtTime(530, t);

    gain.gain.setValueAtTime(0, t);
    gain.gain.linearRampToValueAtTime(0.2, t + 0.02);
    gain.gain.setValueAtTime(0.2, t + 0.18);
    gain.gain.linearRampToValueAtTime(0, t + 0.22);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(this.masterGain);

    osc1.start(t);
    osc2.start(t);
    osc1.stop(t + 0.23);
    osc2.stop(t + 0.23);
  }

  /**
   * Tire screeching on sharp turn or brake
   */
  public playScreech() {
    this.init();
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(900, t);
    osc.frequency.exponentialRampToValueAtTime(400, t + 0.15);

    gain.gain.setValueAtTime(0.08, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + 0.16);
  }

  /**
   * Item collection chime (8-bit arpeggio)
   */
  public playCollect(type: 'coin' | 'nitro' | 'couscous' | 'repair') {
    this.init();
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    const t = this.ctx.currentTime;
    const notes = type === 'coin' 
      ? [523.25, 659.25, 783.99, 1046.50] // C5 E5 G5 C6
      : type === 'nitro'
      ? [440, 554.37, 659.25, 880, 1108] // Nitro power
      : [392, 523.25, 659.25, 783.99];   // Couscous warmth

    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'square';
      osc.frequency.setValueAtTime(freq, t + idx * 0.05);

      gain.gain.setValueAtTime(0.12, t + idx * 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.05 + 0.12);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(t + idx * 0.05);
      osc.stop(t + idx * 0.05 + 0.13);
    });
  }

  /**
   * Nitro turbo boost sound effect
   */
  public playNitro() {
    this.init();
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    const t = this.ctx.currentTime;
    // Frequency sweep + high filter swoosh
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(200, t);
    osc.frequency.exponentialRampToValueAtTime(950, t + 0.45);

    gain.gain.setValueAtTime(0.18, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.5);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + 0.52);
  }

  /**
   * Pothole bump / sand hazard thud
   */
  public playBump() {
    this.init();
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(140, t);
    osc.frequency.exponentialRampToValueAtTime(35, t + 0.12);

    gain.gain.setValueAtTime(0.25, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.14);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + 0.15);
  }

  /**
   * Car crash explosion sound
   */
  public playCrash() {
    this.init();
    this.stopEngine();
    this.stopMusic();
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    const t = this.ctx.currentTime;

    // 1. Bass drop oscillator
    const bass = this.ctx.createOscillator();
    const bassGain = this.ctx.createGain();
    bass.type = 'sawtooth';
    bass.frequency.setValueAtTime(180, t);
    bass.frequency.exponentialRampToValueAtTime(25, t + 0.45);
    bassGain.gain.setValueAtTime(0.4, t);
    bassGain.gain.exponentialRampToValueAtTime(0.01, t + 0.5);
    bass.connect(bassGain);
    bassGain.connect(this.masterGain);
    bass.start(t);
    bass.stop(t + 0.55);

    // 2. Synthesized white noise explosion buffer
    try {
      const bufferSize = this.ctx.sampleRate * 0.4;
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const noise = this.ctx.createBufferSource();
      noise.buffer = buffer;

      const noiseFilter = this.ctx.createBiquadFilter();
      noiseFilter.type = 'lowpass';
      noiseFilter.frequency.setValueAtTime(800, t);
      noiseFilter.frequency.linearRampToValueAtTime(80, t + 0.4);

      const noiseGain = this.ctx.createGain();
      noiseGain.gain.setValueAtTime(0.35, t);
      noiseGain.gain.exponentialRampToValueAtTime(0.01, t + 0.4);

      noise.connect(noiseFilter);
      noiseFilter.connect(noiseGain);
      noiseGain.connect(this.masterGain);

      noise.start(t);
    } catch {
      // ignore
    }
  }

  /**
   * Game start fanfare
   */
  public playStartFanfare() {
    this.init();
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    const t = this.ctx.currentTime;
    const melody = [
      { f: 392, d: 0.1 }, // G4
      { f: 523.25, d: 0.1 }, // C5
      { f: 659.25, d: 0.12 }, // E5
      { f: 783.99, d: 0.25 }  // G5
    ];

    let offset = 0;
    melody.forEach(m => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(m.f, t + offset);
      gain.gain.setValueAtTime(0.15, t + offset);
      gain.gain.exponentialRampToValueAtTime(0.005, t + offset + m.d);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(t + offset);
      osc.stop(t + offset + m.d + 0.02);
      offset += m.d + 0.03;
    });
  }

  /**
   * Game over jingle
   */
  public playGameOverJingle() {
    this.init();
    this.stopMusic();
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    const t = this.ctx.currentTime;
    const notes = [440, 415, 392, 349.23]; // descending melancholy
    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, t + idx * 0.18);
      gain.gain.setValueAtTime(0.15, t + idx * 0.18);
      gain.gain.exponentialRampToValueAtTime(0.01, t + idx * 0.18 + 0.22);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(t + idx * 0.18);
      osc.stop(t + idx * 0.18 + 0.24);
    });
  }
}

export const retroAudio = new RetroAudioEngine();
