import { Project, Track, DrumSoundType, SynthConfig, TrackFx } from '../types/daw';
import { playSynthNote, playDrumSound, buildTrackFxRack, ActiveVoice, createDistortionCurve, createImpulseResponse } from './synth';

export interface PlayheadState {
  currentBeat: number;
  bar: number;
  beatInBar: number;
  sixteenth: number;
  isPlaying: boolean;
  isRecording: boolean;
}

class DawEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private masterLimiter: DynamicsCompressorNode | null = null;
  private analyser: AnalyserNode | null = null;

  // Track channels: trackId -> { inputNode, panner, volumeNode, fxRack }
  private trackChannels = new Map<string, {
    inputNode: GainNode;
    panner: StereoPannerNode;
    volumeNode: GainNode;
    fxRack: ReturnType<typeof buildTrackFxRack>;
  }>();

  // Active polyphonic live notes
  private activeVoices = new Map<string, ActiveVoice>();

  // Sequencer loop state
  private isPlaying = false;
  private isRecording = false;
  private currentBeat = 0;
  private lastScheduledBeat = -1;
  private schedulerTimer: number | null = null;
  private startTime = 0;
  private project: Project | null = null;
  private metronomeEnabled = false;

  // State update callback
  private onPlayheadUpdate: ((state: PlayheadState) => void) | null = null;
  private onLiveRecordedNote: ((trackId: string, midi: number, startBeat: number, duration: number) => void) | null = null;
  private onLiveRecordedDrum: ((trackId: string, drum: DrumSoundType, stepIndex: number) => void) | null = null;

  constructor() {
    // Lazily initialized on first user interaction
  }

  public init() {
    if (this.ctx) return;
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    this.ctx = new AudioContextClass();

    // Master bus
    this.masterLimiter = this.ctx.createDynamicsCompressor();
    this.masterLimiter.threshold.setValueAtTime(-1.0, this.ctx.currentTime);
    this.masterLimiter.knee.setValueAtTime(3, this.ctx.currentTime);
    this.masterLimiter.ratio.setValueAtTime(12, this.ctx.currentTime);
    this.masterLimiter.attack.setValueAtTime(0.003, this.ctx.currentTime);
    this.masterLimiter.release.setValueAtTime(0.2, this.ctx.currentTime);

    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.setValueAtTime(0.85, this.ctx.currentTime);

    this.analyser = this.ctx.createAnalyser();
    this.analyser.fftSize = 64; // responsive visualizer

    this.masterLimiter.connect(this.masterGain);
    this.masterGain.connect(this.analyser);
    this.analyser.connect(this.ctx.destination);
  }

  public async resumeContext() {
    this.init();
    if (this.ctx && this.ctx.state === 'suspended') {
      await this.ctx.resume();
    }
  }

  public setProject(project: Project) {
    this.project = project;
    this.syncTracks(project.tracks);
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(project.masterVolume, this.ctx.currentTime);
    }
  }

  public setMetronome(enabled: boolean) {
    this.metronomeEnabled = enabled;
  }

  public syncTracks(tracks: Track[]) {
    this.init();
    if (!this.ctx || !this.masterLimiter) return;

    // Check for soloed tracks
    const hasSolo = tracks.some(t => t.soloed);

    tracks.forEach(track => {
      let channel = this.trackChannels.get(track.id);
      if (!channel) {
        // Create new channel strip
        const panner = this.ctx!.createStereoPanner();
        const volumeNode = this.ctx!.createGain();
        panner.connect(volumeNode);

        const fxRack = buildTrackFxRack(this.ctx!, track.fx, this.masterLimiter!);
        volumeNode.connect(fxRack.inputNode);

        const inputNode = this.ctx!.createGain();
        inputNode.connect(panner);

        channel = { inputNode, panner, volumeNode, fxRack };
        this.trackChannels.set(track.id, channel);
      }

      // Update volume, pan, mute & solo
      let effectiveVol = track.volume;
      if (track.muted || (hasSolo && !track.soloed)) {
        effectiveVol = 0;
      }

      channel.volumeNode.gain.setValueAtTime(effectiveVol, this.ctx!.currentTime);
      channel.panner.pan.setValueAtTime(track.pan, this.ctx!.currentTime);

      // Update FX parameters
      channel.fxRack.lowEq.gain.setValueAtTime(track.fx.eqLow, this.ctx!.currentTime);
      channel.fxRack.midEq.gain.setValueAtTime(track.fx.eqMid, this.ctx!.currentTime);
      channel.fxRack.highEq.gain.setValueAtTime(track.fx.eqHigh, this.ctx!.currentTime);
      channel.fxRack.distNode.curve = createDistortionCurve(track.fx.distortionDrive);
      channel.fxRack.distWetGain.gain.setValueAtTime(track.fx.distortionMix, this.ctx!.currentTime);
      channel.fxRack.delayNode.delayTime.setValueAtTime(Math.max(track.fx.delayTime, 0.05), this.ctx!.currentTime);
      channel.fxRack.delayFeedback.gain.setValueAtTime(track.fx.delayFeedback, this.ctx!.currentTime);
      channel.fxRack.delayWetGain.gain.setValueAtTime(track.fx.delayMix, this.ctx!.currentTime);
      channel.fxRack.reverbWetGain.gain.setValueAtTime(track.fx.reverbMix, this.ctx!.currentTime);
    });
  }

  public setPlayheadCallback(cb: (state: PlayheadState) => void) {
    this.onPlayheadUpdate = cb;
  }

  public setLiveRecordCallbacks(
    onNote: (trackId: string, midi: number, startBeat: number, duration: number) => void,
    onDrum: (trackId: string, drum: DrumSoundType, stepIndex: number) => void
  ) {
    this.onLiveRecordedNote = onNote;
    this.onLiveRecordedDrum = onDrum;
  }

  public getVisualizerData(): Uint8Array {
    if (!this.analyser) return new Uint8Array(32);
    const data = new Uint8Array(this.analyser.frequencyBinCount);
    this.analyser.getByteFrequencyData(data);
    return data;
  }

  public playTrackNoteLive(track: Track, midi: number, velocity = 0.8): ActiveVoice | null {
    this.resumeContext();
    if (!this.ctx) return null;

    const channel = this.trackChannels.get(track.id);
    if (!channel) return null;

    const voice = playSynthNote(
      this.ctx,
      channel.inputNode,
      midi,
      track.synthConfig,
      this.ctx.currentTime,
      undefined,
      velocity
    );

    // If recording while playing, trigger callback
    if (this.isPlaying && this.isRecording && this.onLiveRecordedNote) {
      this.onLiveRecordedNote(track.id, midi, this.currentBeat, 1.0);
    }

    return voice;
  }

  public playTrackDrumLive(track: Track, drum: DrumSoundType, velocity = 0.8) {
    this.resumeContext();
    if (!this.ctx) return;

    const channel = this.trackChannels.get(track.id);
    if (!channel) return;

    playDrumSound(this.ctx, channel.inputNode, drum, this.ctx.currentTime, velocity);

    if (this.isPlaying && this.isRecording && this.onLiveRecordedDrum) {
      const stepIn16 = Math.floor((this.currentBeat % 4) * 4);
      this.onLiveRecordedDrum(track.id, drum, stepIn16);
    }
  }

  private playMetronomeClick(time: number, isBarStart: boolean) {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(isBarStart ? 1600 : 900, time);

    gain.gain.setValueAtTime(0.25, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.04);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(time);
    osc.stop(time + 0.05);
  }

  // --- Sequencer Playback ---

  public startPlayback(record = false) {
    this.resumeContext();
    if (!this.ctx || !this.project) return;

    this.isPlaying = true;
    this.isRecording = record;
    this.startTime = this.ctx.currentTime;
    this.lastScheduledBeat = this.currentBeat - 0.001;

    this.runScheduler();
  }

  public stopPlayback() {
    this.isPlaying = false;
    this.isRecording = false;
    if (this.schedulerTimer !== null) {
      window.cancelAnimationFrame(this.schedulerTimer);
      this.schedulerTimer = null;
    }
    this.currentBeat = this.project?.loopStart || 0;
    this.emitPlayhead();
  }

  public pausePlayback() {
    this.isPlaying = false;
    this.isRecording = false;
    if (this.schedulerTimer !== null) {
      window.cancelAnimationFrame(this.schedulerTimer);
      this.schedulerTimer = null;
    }
    this.emitPlayhead();
  }

  public seekBeat(beat: number) {
    this.currentBeat = Math.max(0, beat);
    this.lastScheduledBeat = this.currentBeat - 0.001;
    this.emitPlayhead();
  }

  private runScheduler = () => {
    if (!this.isPlaying || !this.ctx || !this.project) return;

    const bpm = this.project.bpm;
    const secondsPerBeat = 60 / bpm;
    const lookahead = 0.15; // schedule 150ms ahead
    const now = this.ctx.currentTime;

    const loopStart = this.project.loopStart;
    const loopEnd = this.project.loopEnd || 16;
    const isLooping = this.project.isLooping;

    // Advance currentBeat according to real elapsed time
    const scheduleUntilTime = now + lookahead;
    const scheduleUntilBeat = this.currentBeat + (lookahead / secondsPerBeat);

    // Schedule all notes & drums between lastScheduledBeat and scheduleUntilBeat
    const startB = this.lastScheduledBeat;
    const endB = scheduleUntilBeat;

    this.project.tracks.forEach(track => {
      const channel = this.trackChannels.get(track.id);
      if (!channel) return;

      track.clips.forEach(clip => {
        // Handle synth notes
        if (clip.notes && clip.notes.length > 0) {
          clip.notes.forEach(note => {
            const noteSongBeat = clip.startBeat + note.startBeat;
            if (noteSongBeat > startB && noteSongBeat <= endB) {
              const delayInBeats = noteSongBeat - this.currentBeat;
              const noteTime = now + delayInBeats * secondsPerBeat;
              const noteDurationSec = note.durationBeats * secondsPerBeat;

              playSynthNote(
                this.ctx!,
                channel.inputNode,
                note.pitch,
                track.synthConfig,
                noteTime,
                noteDurationSec,
                note.velocity
              );
            }
          });
        }

        // Handle drum steps
        if (clip.drumSteps && clip.drumSteps.length > 0) {
          clip.drumSteps.forEach(step => {
            // 16 steps per 4 beats => 1 step = 0.25 beat
            const stepSongBeat = clip.startBeat + step.step * 0.25;
            if (stepSongBeat > startB && stepSongBeat <= endB) {
              const delayInBeats = stepSongBeat - this.currentBeat;
              const stepTime = now + delayInBeats * secondsPerBeat;

              playDrumSound(
                this.ctx!,
                channel.inputNode,
                step.drum,
                stepTime,
                step.velocity
              );
            }
          });
        }
      });
    });

    // Schedule Metronome
    if (this.metronomeEnabled) {
      const nextBeatInt = Math.floor(startB) + 1;
      for (let b = nextBeatInt; b <= endB; b++) {
        if (b > startB && b <= endB) {
          const delayInBeats = b - this.currentBeat;
          const clickTime = now + delayInBeats * secondsPerBeat;
          this.playMetronomeClick(clickTime, b % 4 === 0);
        }
      }
    }

    this.lastScheduledBeat = endB;

    // Advance clock smoothly
    const frameElapsed = 1 / 60;
    this.currentBeat += (frameElapsed / secondsPerBeat);

    // Loop check
    if (isLooping && this.currentBeat >= loopEnd) {
      const overshoot = this.currentBeat - loopEnd;
      this.currentBeat = loopStart + overshoot;
      this.lastScheduledBeat = this.currentBeat - 0.001;
    }

    this.emitPlayhead();
    this.schedulerTimer = window.requestAnimationFrame(this.runScheduler);
  };

  private emitPlayhead() {
    if (!this.onPlayheadUpdate) return;
    const bar = Math.floor(this.currentBeat / 4) + 1;
    const beatInBar = Math.floor(this.currentBeat % 4) + 1;
    const sixteenth = Math.floor((this.currentBeat % 1) * 4) + 1;

    this.onPlayheadUpdate({
      currentBeat: this.currentBeat,
      bar,
      beatInBar,
      sixteenth,
      isPlaying: this.isPlaying,
      isRecording: this.isRecording,
    });
  }

  // --- Offline WAV Exporter ---

  public async exportProjectWav(
    project: Project,
    onProgress?: (percent: number) => void
  ): Promise<Blob> {
    const bpm = project.bpm;
    const secondsPerBeat = 60 / bpm;
    const songBeats = project.loopEnd || 16;
    const totalDurationSec = songBeats * secondsPerBeat + 1.5; // +1.5s tail for reverb/delay
    const sampleRate = 44100;
    const totalFrames = Math.ceil(sampleRate * totalDurationSec);

    const offlineCtx = new OfflineAudioContext(2, totalFrames, sampleRate);

    // Master bus in offline context
    const masterLimiter = offlineCtx.createDynamicsCompressor();
    masterLimiter.threshold.setValueAtTime(-1.0, 0);
    masterLimiter.knee.setValueAtTime(3, 0);
    masterLimiter.ratio.setValueAtTime(12, 0);
    masterLimiter.attack.setValueAtTime(0.003, 0);
    masterLimiter.release.setValueAtTime(0.2, 0);

    const masterGain = offlineCtx.createGain();
    masterGain.gain.setValueAtTime(project.masterVolume, 0);

    masterLimiter.connect(masterGain);
    masterGain.connect(offlineCtx.destination);

    const hasSolo = project.tracks.some(t => t.soloed);

    // Build tracks in offline context
    project.tracks.forEach(track => {
      let effVol = track.volume;
      if (track.muted || (hasSolo && !track.soloed)) {
        effVol = 0;
      }
      if (effVol === 0) return;

      const panner = offlineCtx.createStereoPanner();
      panner.pan.setValueAtTime(track.pan, 0);

      const volNode = offlineCtx.createGain();
      volNode.gain.setValueAtTime(effVol, 0);
      panner.connect(volNode);

      const fxRack = buildTrackFxRack(offlineCtx, track.fx, masterLimiter);
      volNode.connect(fxRack.inputNode);

      const inputNode = offlineCtx.createGain();
      inputNode.connect(panner);

      // Schedule all notes
      track.clips.forEach(clip => {
        if (clip.notes) {
          clip.notes.forEach(note => {
            const noteBeat = clip.startBeat + note.startBeat;
            if (noteBeat < songBeats) {
              const noteTime = noteBeat * secondsPerBeat;
              const durSec = note.durationBeats * secondsPerBeat;
              playSynthNote(offlineCtx, inputNode, note.pitch, track.synthConfig, noteTime, durSec, note.velocity);
            }
          });
        }

        if (clip.drumSteps) {
          clip.drumSteps.forEach(step => {
            const stepBeat = clip.startBeat + step.step * 0.25;
            if (stepBeat < songBeats) {
              const stepTime = stepBeat * secondsPerBeat;
              playDrumSound(offlineCtx, inputNode, step.drum, stepTime, step.velocity);
            }
          });
        }
      });
    });

    if (onProgress) onProgress(30);

    const renderedBuffer = await offlineCtx.startRendering();
    if (onProgress) onProgress(80);

    const wavBlob = audioBufferToWav(renderedBuffer);
    if (onProgress) onProgress(100);

    return wavBlob;
  }
}

// Convert AudioBuffer to 16-bit PCM stereo WAV Blob
function audioBufferToWav(buffer: AudioBuffer): Blob {
  const numChannels = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;
  const length = buffer.length * numChannels * 2 + 44;
  const out = new DataView(new ArrayBuffer(length));

  function writeString(view: DataView, offset: number, string: string) {
    for (let i = 0; i < string.length; i++) {
      view.setUint8(offset + i, string.charCodeAt(i));
    }
  }

  // RIFF identifier
  writeString(out, 0, 'RIFF');
  // file length
  out.setUint32(4, 36 + buffer.length * numChannels * 2, true);
  // RIFF type
  writeString(out, 8, 'WAVE');
  // format chunk identifier
  writeString(out, 12, 'fmt ');
  // format chunk length
  out.setUint32(16, 16, true);
  // sample format (1 = PCM)
  out.setUint16(20, 1, true);
  // channel count
  out.setUint16(22, numChannels, true);
  // sample rate
  out.setUint32(24, sampleRate, true);
  // byte rate (sampleRate * blockAlign)
  out.setUint32(28, sampleRate * numChannels * 2, true);
  // block align (channel count * bytes per sample)
  out.setUint16(32, numChannels * 2, true);
  // bits per sample
  out.setUint16(34, 16, true);
  // data chunk identifier
  writeString(out, 36, 'data');
  // data chunk length
  out.setUint32(40, buffer.length * numChannels * 2, true);

  // Write interleaved PCM samples
  let offset = 44;
  const channels: Float32Array[] = [];
  for (let c = 0; c < numChannels; c++) {
    channels.push(buffer.getChannelData(c));
  }

  for (let i = 0; i < buffer.length; i++) {
    for (let c = 0; c < numChannels; c++) {
      let sample = Math.max(-1, Math.min(1, channels[c][i]));
      // 16-bit signed integer
      sample = sample < 0 ? sample * 0x8000 : sample * 0x7FFF;
      out.setInt16(offset, sample, true);
      offset += 2;
    }
  }

  return new Blob([out.buffer], { type: 'audio/wav' });
}

export const engine = new DawEngine();
