import { Mp3Encoder } from '@breezystack/lamejs';

/**
 * Encodes raw 16-bit mono or stereo PCM audio samples into a genuine MP3 Blob or Uint8Array
 */
export function encodePcmToMp3(
  samples: Int16Array,
  sampleRate: number = 24000,
  bitrate: number = 192,
  channels: number = 1
): Uint8Array {
  // Clamp bitrate to supported Lame values
  const validBitrate = [32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320].includes(bitrate)
    ? bitrate
    : 192;

  const encoder = new Mp3Encoder(channels, sampleRate, validBitrate);
  const mp3Chunks: Uint8Array[] = [];

  // Lamejs expects chunks (e.g. 1152 samples)
  const chunkSize = 1152;
  for (let i = 0; i < samples.length; i += chunkSize) {
    const chunk = samples.subarray(i, i + chunkSize);
    const mp3buf = encoder.encodeBuffer(chunk);
    if (mp3buf.length > 0) {
      mp3Chunks.push(new Uint8Array(mp3buf));
    }
  }

  const endChunk = encoder.flush();
  if (endChunk.length > 0) {
    mp3Chunks.push(new Uint8Array(endChunk));
  }

  // Concatenate all chunks into a single Uint8Array
  const totalLength = mp3Chunks.reduce((acc, curr) => acc + curr.length, 0);
  const result = new Uint8Array(totalLength);
  let offset = 0;
  for (const chunk of mp3Chunks) {
    result.set(chunk, offset);
    offset += chunk.length;
  }

  return result;
}

/**
 * Creates a valid WAV file buffer from 16-bit PCM samples
 */
export function encodePcmToWav(
  samples: Int16Array,
  sampleRate: number = 24000,
  channels: number = 1
): Uint8Array {
  const byteRate = sampleRate * channels * 2;
  const blockAlign = channels * 2;
  const dataSize = samples.length * 2;
  const buffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buffer);

  // RIFF identifier
  writeString(view, 0, 'RIFF');
  // RIFF chunk length
  view.setUint32(4, 36 + dataSize, true);
  // RIFF type
  writeString(view, 8, 'WAVE');
  // format chunk identifier
  writeString(view, 12, 'fmt ');
  // format chunk length
  view.setUint32(16, 16, true);
  // sample format (raw PCM)
  view.setUint16(20, 1, true);
  // channel count
  view.setUint16(22, channels, true);
  // sample rate
  view.setUint32(24, sampleRate, true);
  // byte rate
  view.setUint32(28, byteRate, true);
  // block align
  view.setUint16(32, blockAlign, true);
  // bits per sample
  view.setUint16(34, 16, true);
  // data chunk identifier
  writeString(view, 36, 'data');
  // data chunk length
  view.setUint32(40, dataSize, true);

  // Write PCM audio data
  let offset = 44;
  for (let i = 0; i < samples.length; i++, offset += 2) {
    view.setInt16(offset, samples[i], true);
  }

  return new Uint8Array(buffer);
}

function writeString(view: DataView, offset: number, string: string) {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}
