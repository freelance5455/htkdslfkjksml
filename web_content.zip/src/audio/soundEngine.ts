import { COMMENTARY_LINES } from '../i18n/translations';
import { AudioSettings, CommentaryEvent, Language } from '../types/game';

export interface SoundtrackTrack {
  id: string;
  title: string;
  bpm: number;
  rootHz: number;
  chords: number[][];
  melody: number[];
  bass: number[];
  style: 'anthem' | 'samba' | 'champions' | 'festival';
}

// Catchy football-themed menu anthems (melody values in semitones relative to rootHz, -1 = rest)
export const SOUNDTRACK_TRACKS: SoundtrackTrack[] = [
  {
    id: 'anthem',
    title: 'É Campeão! · Hino da Arena',
    bpm: 124,
    rootHz: 130.81, // C3
    style: 'anthem',
    // I - V - vi - IV iconic stadium progression (C - G - Am - F)
    chords: [
      [0, 4, 7, 12],
      [7, 11, 14, 19],
      [9, 12, 16, 21],
      [5, 9, 12, 17],
    ],
    // 32-step catchy football brass/chant hook ("Olé, Olé, Olé, Campeão!")
    melody: [
      12, -1, 16, 19, -1, 19, 16, 12,
      14, -1, 19, 17, 16, 14, 12, -1,
      21, -1, 19, 16, -1, 16, 14, 12,
      17, 17, 16, 14, 12, -1, 19, -1,
    ],
    bass: [
      0, 0, 12, 0, 0, 7, 12, 0,
      7, 7, 19, 7, 7, 14, 11, 7,
      9, 9, 21, 9, 9, 16, 12, 9,
      5, 5, 17, 5, 5, 9, 12, 7,
    ],
  },
  {
    id: 'samba',
    title: 'Olé Brasil · Batucada do Estádio',
    bpm: 118,
    rootHz: 146.83, // D3
    style: 'samba',
    chords: [
      [0, 4, 7, 10],
      [5, 9, 12, 14],
      [7, 11, 14, 17],
      [0, 4, 7, 12],
    ],
    melody: [
      12, 14, 16, -1, 19, -1, 16, 14,
      17, -1, 16, 14, 12, -1, 9, -1,
      14, 16, 19, -1, 21, 19, 17, 14,
      16, -1, 14, 12, 12, -1, -1, 19,
    ],
    bass: [
      0, -1, 7, 0, 0, 7, 10, 7,
      5, -1, 12, 5, 5, 12, 9, 5,
      7, -1, 14, 7, 7, 14, 11, 7,
      0, -1, 7, 12, 0, 7, 0, -1,
    ],
  },
  {
    id: 'champions',
    title: 'Noite de Decisão · Hino dos Campeões',
    bpm: 126,
    rootHz: 110.0, // A2
    style: 'champions',
    chords: [
      [0, 3, 7, 12],
      [8, 12, 15, 20],
      [3, 7, 10, 15],
      [7, 11, 14, 19],
    ],
    melody: [
      12, -1, -1, 15, 19, -1, 17, 15,
      20, -1, 19, 15, 12, -1, -1, -1,
      15, -1, 17, 19, 22, -1, 19, 15,
      19, 17, 15, 14, 12, -1, 19, -1,
    ],
    bass: [
      0, 0, 0, 12, 0, 0, 7, 0,
      8, 8, 8, 20, 8, 8, 15, 8,
      3, 3, 3, 15, 3, 3, 10, 3,
      7, 7, 7, 19, 7, 11, 14, 7,
    ],
  },
  {
    id: 'festival',
    title: 'Festa na Arquibancada · Gol de Placa',
    bpm: 128,
    rootHz: 164.81, // E3
    style: 'festival',
    chords: [
      [0, 4, 7, 12],
      [9, 12, 16, 21],
      [5, 9, 12, 17],
      [7, 11, 14, 19],
    ],
    melody: [
      19, -1, 16, 12, 14, 16, 19, -1,
      21, -1, 19, 16, 14, -1, 12, -1,
      17, 17, 16, 14, 12, 14, 16, -1,
      19, -1, 21, 19, 24, -1, 19, -1,
    ],
    bass: [
      0, 12, 0, 12, 0, 12, 7, 12,
      9, 21, 9, 21, 9, 16, 12, 9,
      5, 17, 5, 17, 5, 12, 9, 5,
      7, 19, 7, 19, 7, 14, 11, 7,
    ],
  },
];

class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;

  // Menu soundtrack loop
  private seqTimer: number | null = null;
  private step = 0;

  // In-match continuous stadium crowd ("Torcida")
  private inMatch = false;
  private matchPaused = false;
  private crowdExcitement = 0.25;
  private crowdBedGain: GainNode | null = null;
  private crowdFilterMid: BiquadFilterNode | null = null;
  private crowdSources: AudioNode[] = [];
  private crowdTimer: number | null = null;
  private crowdBeat = 0;
  private noiseBuffer: AudioBuffer | null = null;

  private settings: AudioSettings = {
    musicEnabled: true,
    sfxEnabled: true,
    commentaryEnabled: true,
    volume: 0.65,
    trackIndex: 0,
  };
  private lastSpeechTime = 0;
  private lastChanceCrowdTime = 0;
  private onCaption?: (text: string) => void;

  public setCaptionListener(cb?: (text: string) => void) {
    this.onCaption = cb;
  }

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.musicGain = this.ctx.createGain();
      this.sfxGain = this.ctx.createGain();

      this.musicGain.connect(this.masterGain);
      this.sfxGain.connect(this.masterGain);
      this.masterGain.connect(this.ctx.destination);
      this.applyVolumes();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  private getPinkNoiseBuffer(ctx: AudioContext): AudioBuffer {
    if (this.noiseBuffer && this.noiseBuffer.sampleRate === ctx.sampleRate) {
      return this.noiseBuffer;
    }
    const seconds = 4;
    const length = ctx.sampleRate * seconds;
    const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
    const data = buffer.getChannelData(0);

    // Paul Kellet's pink noise filter for warm, natural stadium crowd texture
    let b0 = 0;
    let b1 = 0;
    let b2 = 0;
    let b3 = 0;
    let b4 = 0;
    let b5 = 0;
    let b6 = 0;
    for (let i = 0; i < length; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      b3 = 0.86650 * b3 + white * 0.3104856;
      b4 = 0.55000 * b4 + white * 0.5329522;
      b5 = -0.7616 * b5 - white * 0.0168980;
      const pink = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.065;
      b6 = white * 0.115926;
      data[i] = Math.max(-0.95, Math.min(0.95, pink));
    }

    // Crossfade last 250ms into first 250ms so looping is 100% seamless
    const fadeSamples = Math.floor(ctx.sampleRate * 0.25);
    for (let i = 0; i < fadeSamples; i++) {
      const t = i / fadeSamples;
      const tailIdx = length - fadeSamples + i;
      const blended = data[i] * t + data[tailIdx] * (1 - t);
      data[i] = blended;
      data[tailIdx] = blended;
    }

    this.noiseBuffer = buffer;
    return buffer;
  }

  public unlock() {
    this.ensureContext();
    this.syncPlaybackMode();
  }

  public setMatchState(inMatch: boolean, paused = false) {
    const changed = this.inMatch !== inMatch || this.matchPaused !== paused;
    this.inMatch = inMatch;
    this.matchPaused = paused;
    if (changed) {
      this.syncPlaybackMode();
    }
  }

  public setCrowdExcitement(level: number) {
    this.crowdExcitement = Math.max(0.1, Math.min(1, level));
    if (!this.ctx || !this.crowdBedGain || !this.crowdFilterMid) return;
    const now = this.ctx.currentTime;
    const targetGain = 0.13 + this.crowdExcitement * 0.14;
    const targetFreq = 480 + this.crowdExcitement * 360;
    this.crowdBedGain.gain.setTargetAtTime(targetGain, now, 0.35);
    this.crowdFilterMid.frequency.setTargetAtTime(targetFreq, now, 0.35);
  }

  public updateSettings(next: AudioSettings) {
    const prevMusic = this.settings.musicEnabled;
    const prevTrack = this.settings.trackIndex;
    const prevSfx = this.settings.sfxEnabled;
    this.settings = { ...next };
    this.applyVolumes();

    if (
      !this.inMatch &&
      this.settings.musicEnabled &&
      (!prevMusic || prevTrack !== this.settings.trackIndex || this.seqTimer === null)
    ) {
      if (this.ctx) this.startMusicLoop();
    } else if (!this.settings.musicEnabled || this.inMatch) {
      this.stopMusicLoop();
    }

    if (this.inMatch && !this.matchPaused && this.settings.sfxEnabled && !prevSfx) {
      if (this.ctx) this.startCrowdAmbience();
    } else if (!this.settings.sfxEnabled || !this.inMatch || this.matchPaused) {
      this.stopCrowdAmbience();
    }
  }

  private syncPlaybackMode() {
    if (!this.ctx) return;
    this.applyVolumes();

    // Menu music plays in Menu only; Stadium Crowd plays during active Match
    if (!this.inMatch && this.settings.musicEnabled) {
      if (this.seqTimer === null) this.startMusicLoop();
    } else {
      this.stopMusicLoop();
    }

    if (this.inMatch && !this.matchPaused && this.settings.sfxEnabled) {
      if (this.crowdTimer === null) this.startCrowdAmbience();
    } else {
      this.stopCrowdAmbience();
    }
  }

  private applyVolumes() {
    if (!this.ctx || !this.masterGain || !this.musicGain || !this.sfxGain) return;
    const now = this.ctx.currentTime;
    this.masterGain.gain.setTargetAtTime(this.settings.volume, now, 0.03);
    this.musicGain.gain.setTargetAtTime(!this.inMatch && this.settings.musicEnabled ? 0.34 : 0, now, 0.06);
    this.sfxGain.gain.setTargetAtTime(this.settings.sfxEnabled ? 0.72 : 0, now, 0.04);
  }

  // =========================================================================
  // CATCHY FOOTBALL MENU MUSIC ENGINE
  // =========================================================================
  private triggerNoiseBurst(
    dest: AudioNode,
    time: number,
    duration: number,
    filterType: BiquadFilterType,
    freq: number,
    q: number,
    gainAmt: number
  ) {
    if (!this.ctx) return;
    const buf = this.getPinkNoiseBuffer(this.ctx);
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    // Start at random offset inside pink buffer for organic non-repetitive claps/shakers
    const offset = Math.random() * Math.max(0.1, buf.duration - duration - 0.05);

    const filter = this.ctx.createBiquadFilter();
    filter.type = filterType;
    filter.frequency.setValueAtTime(freq, time);
    filter.Q.setValueAtTime(q, time);

    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.001, time);
    g.gain.linearRampToValueAtTime(gainAmt, time + 0.008);
    g.gain.exponentialRampToValueAtTime(0.001, time + duration);

    src.connect(filter);
    filter.connect(g);
    g.connect(dest);
    src.start(time, offset, duration + 0.02);
    src.stop(time + duration + 0.03);
  }

  private triggerBrassHook(dest: AudioNode, time: number, freq: number, duration: number, level = 0.14) {
    if (!this.ctx) return;
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const filter = this.ctx.createBiquadFilter();
    const g = this.ctx.createGain();

    osc1.type = 'sawtooth';
    osc2.type = 'triangle';
    osc1.frequency.setValueAtTime(freq, time);
    osc2.frequency.setValueAtTime(freq * 1.005, time); // slight stadium chorus detune

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(650, time);
    filter.frequency.exponentialRampToValueAtTime(2800, time + 0.045);
    filter.frequency.exponentialRampToValueAtTime(1400, time + duration);
    filter.Q.setValueAtTime(1.8, time);

    g.gain.setValueAtTime(0.001, time);
    g.gain.linearRampToValueAtTime(level, time + 0.02);
    g.gain.setValueAtTime(level * 0.85, time + duration * 0.65);
    g.gain.exponentialRampToValueAtTime(0.001, time + duration);

    osc1.connect(filter);
    osc2.connect(filter);
    filter.connect(g);
    g.connect(dest);

    osc1.start(time);
    osc2.start(time);
    osc1.stop(time + duration + 0.02);
    osc2.stop(time + duration + 0.02);
  }

  private triggerStadiumChantChord(dest: AudioNode, time: number, freqs: number[], duration: number, level = 0.055) {
    if (!this.ctx) return;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(480, time);
    filter.frequency.linearRampToValueAtTime(860, time + duration * 0.45);
    filter.frequency.linearRampToValueAtTime(520, time + duration);
    filter.Q.setValueAtTime(1.4, time);

    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.001, time);
    g.gain.linearRampToValueAtTime(level, time + 0.08);
    g.gain.setValueAtTime(level * 0.8, time + duration * 0.7);
    g.gain.exponentialRampToValueAtTime(0.001, time + duration);

    filter.connect(g);
    g.connect(dest);

    freqs.forEach((f) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(f, time);
      osc.connect(filter);
      osc.start(time);
      osc.stop(time + duration + 0.02);
    });
  }

  private startMusicLoop() {
    this.stopMusicLoop();
    if (!this.settings.musicEnabled || this.inMatch) return;
    const track = SOUNDTRACK_TRACKS[this.settings.trackIndex % SOUNDTRACK_TRACKS.length];
    const stepMs = (60 / track.bpm / 2) * 1000; // 8th-note steps

    this.seqTimer = window.setInterval(() => {
      if (this.inMatch || !this.settings.musicEnabled || !this.ctx || this.ctx.state !== 'running' || !this.musicGain) {
        return;
      }
      const now = this.ctx.currentTime;
      const cfg = SOUNDTRACK_TRACKS[this.settings.trackIndex % SOUNDTRACK_TRACKS.length];
      const idx = this.step % 32;
      const barIdx = Math.floor(idx / 8); // 0..3
      const beatInBar = idx % 8;

      // 1. Stadium Surdo / Kick Drum
      const isKick =
        cfg.style === 'samba'
          ? beatInBar === 0 || beatInBar === 3 || beatInBar === 4 || beatInBar === 6
          : beatInBar % 2 === 0;
      if (isKick) {
        const osc = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        osc.type = 'sine';
        const punch = beatInBar === 0 ? 132 : 112;
        osc.frequency.setValueAtTime(punch, now);
        osc.frequency.exponentialRampToValueAtTime(40, now + 0.15);
        g.gain.setValueAtTime(beatInBar === 0 ? 0.52 : 0.4, now);
        g.gain.exponentialRampToValueAtTime(0.001, now + 0.17);
        osc.connect(g);
        g.connect(this.musicGain);
        osc.start(now);
        osc.stop(now + 0.18);
      }

      // 2. Stadium Crowd Claps on backbeats (beats 2 & 4 -> steps 2 and 6) + syncopated samba fill
      if (beatInBar === 2 || beatInBar === 6 || (cfg.style === 'anthem' && idx === 31)) {
        this.triggerNoiseBurst(this.musicGain, now, 0.11, 'bandpass', 1450, 1.1, 0.22);
        this.triggerNoiseBurst(this.musicGain, now + 0.018, 0.09, 'highpass', 2200, 0.8, 0.12);
      }

      // 3. Crisp Tamborim / Shaker 8th-note groove
      this.triggerNoiseBurst(
        this.musicGain,
        now,
        0.045,
        'highpass',
        beatInBar % 2 === 1 ? 5600 : 7200,
        1.0,
        beatInBar % 2 === 1 ? 0.08 : 0.04
      );

      // 4. Agogô / Football Cowbell groove in Samba & Anthem styles
      if ((cfg.style === 'samba' || cfg.style === 'anthem') && (beatInBar === 1 || beatInBar === 3 || beatInBar === 6)) {
        const bellOsc = this.ctx.createOscillator();
        const bellGain = this.ctx.createGain();
        bellOsc.type = 'triangle';
        const bellHz = beatInBar === 3 ? 1174.66 : 880;
        bellOsc.frequency.setValueAtTime(bellHz, now);
        bellGain.gain.setValueAtTime(0.06, now);
        bellGain.gain.exponentialRampToValueAtTime(0.001, now + 0.085);
        bellOsc.connect(bellGain);
        bellGain.connect(this.musicGain);
        bellOsc.start(now);
        bellOsc.stop(now + 0.09);
      }

      // 5. Punchy Bassline
      const bassSemi = cfg.bass[idx];
      if (bassSemi >= 0) {
        const bassHz = cfg.rootHz * 0.5 * Math.pow(2, bassSemi / 12);
        const osc = this.ctx.createOscillator();
        const filter = this.ctx.createBiquadFilter();
        const g = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(bassHz, now);
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(620, now);
        filter.frequency.exponentialRampToValueAtTime(240, now + 0.18);
        g.gain.setValueAtTime(0.22, now);
        g.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
        osc.connect(filter);
        filter.connect(g);
        g.connect(this.musicGain);
        osc.start(now);
        osc.stop(now + 0.21);
      }

      // 6. Stadium Choir Pad ("Ôôô!") on start of every bar
      if (beatInBar === 0) {
        const chordSemis = cfg.chords[barIdx % cfg.chords.length];
        const chordFreqs = chordSemis.map((s) => cfg.rootHz * 2 * Math.pow(2, s / 12));
        this.triggerStadiumChantChord(this.musicGain, now, chordFreqs, (stepMs * 7.2) / 1000, 0.055);
      }

      // 7. Catchy Stadium Brass / Fanfare Hook Melody
      const melSemi = cfg.melody[idx];
      if (melSemi >= 0) {
        // Compute sustained duration across trailing rests (-1)
        let holdSteps = 1;
        for (let k = 1; k <= 3; k++) {
          if (cfg.melody[(idx + k) % 32] === -1) holdSteps++;
          else break;
        }
        const durSec = Math.min(0.65, (holdSteps * stepMs) / 1000 * 0.9);
        const melHz = cfg.rootHz * 2 * Math.pow(2, melSemi / 12);
        this.triggerBrassHook(this.musicGain, now, melHz, durSec, 0.15);
      }

      this.step = (this.step + 1) % 32;
    }, stepMs);
  }

  private stopMusicLoop() {
    if (this.seqTimer !== null) {
      window.clearInterval(this.seqTimer);
      this.seqTimer = null;
    }
  }

  // =========================================================================
  // IN-MATCH STADIUM CROWD ("TORCIDA") ATMOSPHERE ENGINE
  // =========================================================================
  private startCrowdAmbience() {
    this.stopCrowdAmbience();
    if (!this.ctx || !this.sfxGain || !this.settings.sfxEnabled || !this.inMatch || this.matchPaused) return;

    const ctx = this.ctx;
    const now = ctx.currentTime;
    const pinkBuf = this.getPinkNoiseBuffer(ctx);

    // Master crowd bed gain
    const bedGain = ctx.createGain();
    bedGain.gain.setValueAtTime(0.001, now);
    bedGain.gain.linearRampToValueAtTime(0.14 + this.crowdExcitement * 0.12, now + 0.8);
    bedGain.connect(this.sfxGain);
    this.crowdBedGain = bedGain;

    // Layer 1: Deep stadium bowl roar (~195 Hz)
    const srcLow = ctx.createBufferSource();
    srcLow.buffer = pinkBuf;
    srcLow.loop = true;
    const filterLow = ctx.createBiquadFilter();
    filterLow.type = 'bandpass';
    filterLow.frequency.setValueAtTime(195, now);
    filterLow.Q.setValueAtTime(0.65, now);
    const gainLow = ctx.createGain();
    gainLow.gain.setValueAtTime(0.85, now);
    srcLow.connect(filterLow);
    filterLow.connect(gainLow);
    gainLow.connect(bedGain);
    srcLow.start(now);

    // Layer 2: Mid fan chatter / chanting murmur (~560 Hz modulated by slow LFO)
    const srcMid = ctx.createBufferSource();
    srcMid.buffer = pinkBuf;
    srcMid.loop = true;
    const filterMid = ctx.createBiquadFilter();
    filterMid.type = 'bandpass';
    filterMid.frequency.setValueAtTime(520 + this.crowdExcitement * 300, now);
    filterMid.Q.setValueAtTime(0.85, now);
    this.crowdFilterMid = filterMid;

    const lfo = ctx.createOscillator();
    lfo.type = 'sine';
    lfo.frequency.setValueAtTime(0.24, now);
    const lfoGain = ctx.createGain();
    lfoGain.gain.setValueAtTime(140, now);
    lfo.connect(lfoGain);
    lfoGain.connect(filterMid.frequency);
    lfo.start(now);

    const gainMid = ctx.createGain();
    gainMid.gain.setValueAtTime(0.95, now);
    srcMid.connect(filterMid);
    filterMid.connect(gainMid);
    gainMid.connect(bedGain);
    srcMid.start(now, 1.3);

    this.crowdSources = [srcLow, srcMid, lfo];

    // Layer 3: Rhythmic Torcida Drums, Claps & Terrace Chants
    this.crowdBeat = 0;
    this.crowdTimer = window.setInterval(() => {
      if (!this.ctx || this.ctx.state !== 'running' || !this.sfxGain || !this.inMatch || this.matchPaused || !this.settings.sfxEnabled) {
        return;
      }
      const t = this.ctx.currentTime;
      const step = this.crowdBeat % 16;

      // Classic Brazilian/World stadium drum cadence ("TUM... TUM... TUM-TUM-TUM!")
      if (step === 0 || step === 4 || step === 8 || step === 10 || step === 12) {
        const drumOsc = this.ctx.createOscillator();
        const drumGain = this.ctx.createGain();
        drumOsc.type = 'sine';
        drumOsc.frequency.setValueAtTime(step === 0 ? 105 : 92, t);
        drumOsc.frequency.exponentialRampToValueAtTime(42, t + 0.16);
        const drumVol = (0.14 + this.crowdExcitement * 0.12) * (step === 0 || step === 10 ? 1.15 : 0.9);
        drumGain.gain.setValueAtTime(drumVol, t);
        drumGain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
        drumOsc.connect(drumGain);
        drumGain.connect(this.sfxGain);
        drumOsc.start(t);
        drumOsc.stop(t + 0.19);
      }

      // Collective Torcida Claps ("PALMAS!")
      if (step === 2 || step === 6 || step === 11 || step === 14) {
        const clapVol = 0.08 + this.crowdExcitement * 0.08;
        this.triggerNoiseBurst(this.sfxGain, t, 0.14, 'bandpass', 1350, 0.9, clapVol);
      }

      // Stadium Crowd "Ôôô-Olé!" Singing Wave every 16 beats
      if (step === 0 && Math.random() < 0.72) {
        const chantBase = 196; // G3 warm terrace unison
        const chantNotes = this.crowdExcitement > 0.6 ? [chantBase, chantBase * 1.25, chantBase * 1.5] : [chantBase, chantBase * 1.5];
        this.triggerStadiumChantChord(this.sfxGain, t, chantNotes, 1.45, 0.065 + this.crowdExcitement * 0.05);
      }

      this.crowdBeat = (this.crowdBeat + 1) % 32;
    }, 280);
  }

  private stopCrowdAmbience() {
    if (this.crowdTimer !== null) {
      window.clearInterval(this.crowdTimer);
      this.crowdTimer = null;
    }
    for (const node of this.crowdSources) {
      try {
        if ('stop' in node && typeof (node as AudioBufferSourceNode).stop === 'function') {
          (node as AudioBufferSourceNode).stop();
        }
        node.disconnect();
      } catch {
        // Ignore already stopped audio nodes
      }
    }
    this.crowdSources = [];
    if (this.crowdBedGain) {
      try {
        this.crowdBedGain.disconnect();
      } catch {
        // Ignore
      }
      this.crowdBedGain = null;
    }
    this.crowdFilterMid = null;
  }

  // =========================================================================
  // MATCH SFX & DYNAMIC CROWD REACTIONS
  // =========================================================================
  public playKick(power = 0.7) {
    if (!this.settings.sfxEnabled) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(140 + power * 50, now);
    osc.frequency.exponentialRampToValueAtTime(38, now + 0.11);
    g.gain.setValueAtTime(0.45 * Math.min(1, 0.5 + power * 0.6), now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
    osc.connect(g);
    g.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.13);
  }

  public playWhistle(long = false) {
    if (!this.settings.sfxEnabled) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;
    const now = ctx.currentTime;
    const dur = long ? 0.52 : 0.22;
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const g = ctx.createGain();
    osc1.type = 'sine';
    osc2.type = 'triangle';
    osc1.frequency.setValueAtTime(2860, now);
    osc2.frequency.setValueAtTime(2940, now);
    g.gain.setValueAtTime(0.001, now);
    g.gain.linearRampToValueAtTime(0.22, now + 0.02);
    g.gain.setValueAtTime(0.2, now + dur - 0.04);
    g.gain.exponentialRampToValueAtTime(0.001, now + dur);
    osc1.connect(g);
    osc2.connect(g);
    g.connect(this.sfxGain);
    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + dur + 0.02);
    osc2.stop(now + dur + 0.02);
  }

  public playPostClang() {
    if (!this.settings.sfxEnabled) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(620, now);
    osc.frequency.exponentialRampToValueAtTime(410, now + 0.35);
    g.gain.setValueAtTime(0.32, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.38);
    osc.connect(g);
    g.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.4);
  }

  /** Collective "OOOOH!" stadium gasp & applause on shots, saves, or hitting the post */
  public playCrowdChance() {
    if (!this.settings.sfxEnabled) return;
    const perfNow = performance.now();
    if (perfNow - this.lastChanceCrowdTime < 1800) return;
    this.lastChanceCrowdTime = perfNow;

    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;
    const now = ctx.currentTime;
    const pinkBuf = this.getPinkNoiseBuffer(ctx);
    const src = ctx.createBufferSource();
    src.buffer = pinkBuf;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(520, now);
    filter.frequency.exponentialRampToValueAtTime(1050, now + 0.25);
    filter.frequency.exponentialRampToValueAtTime(480, now + 1.05);
    filter.Q.setValueAtTime(1.1, now);

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.01, now);
    g.gain.linearRampToValueAtTime(0.34, now + 0.16);
    g.gain.exponentialRampToValueAtTime(0.005, now + 1.15);

    src.connect(filter);
    filter.connect(g);
    g.connect(this.sfxGain);
    src.start(now, Math.random() * 1.5, 1.2);
    src.stop(now + 1.22);
  }

  /** Massive stadium goal celebration roar + cheering wave + celebratory horn */
  public playCrowdRoar() {
    if (!this.settings.sfxEnabled) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;
    const now = ctx.currentTime;
    const pinkBuf = this.getPinkNoiseBuffer(ctx);

    // 1. Wide Stadium Crowd Eruption
    const noise = ctx.createBufferSource();
    noise.buffer = pinkBuf;
    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(720, now);
    filter.frequency.linearRampToValueAtTime(1180, now + 0.45);
    filter.frequency.linearRampToValueAtTime(640, now + 2.4);
    filter.Q.setValueAtTime(0.7, now);

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.01, now);
    g.gain.linearRampToValueAtTime(0.62, now + 0.18);
    g.gain.setValueAtTime(0.55, now + 1.1);
    g.gain.exponentialRampToValueAtTime(0.005, now + 2.5);

    noise.connect(filter);
    filter.connect(g);
    g.connect(this.sfxGain);
    noise.start(now, 0.2, 2.55);
    noise.stop(now + 2.6);

    // 2. Celebratory Stadium Air-Horn / Fanfare Chord
    this.triggerBrassHook(this.sfxGain, now + 0.08, 392.0, 0.45, 0.12);
    this.triggerBrassHook(this.sfxGain, now + 0.08, 493.88, 0.45, 0.1);
    this.triggerBrassHook(this.sfxGain, now + 0.6, 523.25, 0.75, 0.13);
  }

  public playPackReveal() {
    if (!this.settings.sfxEnabled) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;
    const now = ctx.currentTime;
    const notes = [440, 554.37, 659.25, 880];
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = 'triangle';
      const t = now + i * 0.08;
      osc.frequency.setValueAtTime(freq, t);
      g.gain.setValueAtTime(0.18, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
      osc.connect(g);
      g.connect(this.sfxGain!);
      osc.start(t);
      osc.stop(t + 0.36);
    });
  }

  public speakCommentary(event: CommentaryEvent, lang: Language, extraContext?: string) {
    const lines = COMMENTARY_LINES[lang][event];
    const baseLine = lines[Math.floor(Math.random() * lines.length)];
    const fullLine = extraContext ? `${baseLine} ${extraContext}` : baseLine;

    const isHighPriority =
      event === 'goal_home' ||
      event === 'goal_away' ||
      event === 'kickoff' ||
      event === 'halftime' ||
      event === 'fulltime';

    const now = performance.now();
    if (!isHighPriority && now - this.lastSpeechTime < 4500) {
      return;
    }
    this.lastSpeechTime = now;

    if (this.onCaption) {
      this.onCaption(fullLine);
    }

    if (!this.settings.commentaryEnabled || typeof window === 'undefined' || !('speechSynthesis' in window)) {
      return;
    }

    try {
      const synth = window.speechSynthesis;
      if (isHighPriority) {
        synth.cancel();
      } else if (synth.speaking) {
        return;
      }

      const utter = new SpeechSynthesisUtterance(fullLine);
      const targetLang = lang === 'pt-BR' ? 'pt-BR' : lang === 'es' ? 'es-ES' : 'en-GB';
      utter.lang = targetLang;
      utter.volume = Math.min(1, this.settings.volume + 0.15);
      utter.rate = event === 'goal_home' || event === 'goal_away' ? 1.14 : 1.05;
      utter.pitch = event === 'goal_home' ? 1.18 : 1.0;

      const voices = synth.getVoices();
      const matched =
        voices.find((v) => v.lang.toLowerCase() === targetLang.toLowerCase()) ||
        voices.find((v) => v.lang.toLowerCase().startsWith(targetLang.slice(0, 2).toLowerCase()));
      if (matched) utter.voice = matched;

      synth.speak(utter);
    } catch {
      // Ignore TTS sandbox restrictions safely
    }
  }
}

export const soundEngine = new SoundEngine();
