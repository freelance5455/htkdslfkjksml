import { SystemSettings, DEFAULT_SETTINGS } from '../types/system';

type AudioListener = (unlocked: boolean) => void;
export type MusicMode = 'home' | 'profile';

class RetroSoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private compressor: DynamicsCompressorNode | null = null;
  private sfxGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private speechGain: GainNode | null = null;
  private sfxDelay: DelayNode | null = null;
  private musicDelayL: DelayNode | null = null;
  private musicDelayR: DelayNode | null = null;
  private musicBusFilter: BiquadFilterNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private brownNoiseBuffer: AudioBuffer | null = null;
  private saturationCurve: Float32Array<ArrayBuffer> | null = null;

  private settings: SystemSettings = { ...DEFAULT_SETTINGS };
  private musicPlaying = false;
  private musicMode: MusicMode = 'home';
  private musicTimer: number | null = null;
  private needsImmediateBar = false;
  private pendingTriggerBar: (() => void) | null = null;
  private activeMusicNodes = new Set<AudioScheduledSourceNode>();
  private chordStep = 0;
  private listeners = new Set<AudioListener>();
  private lastScrollTime = 0;
  private speechDucking = false;

  public ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;

      this.ctx = new AudioCtx({ latencyHint: 'interactive' });

      this.compressor = this.ctx.createDynamicsCompressor();
      this.compressor.threshold.value = -14;
      this.compressor.knee.value = 18;
      this.compressor.ratio.value = 4;
      this.compressor.attack.value = 0.004;
      this.compressor.release.value = 0.2;

      this.masterGain = this.ctx.createGain();
      this.sfxGain = this.ctx.createGain();
      this.musicGain = this.ctx.createGain();
      this.speechGain = this.ctx.createGain();

      // Lightweight damped echo bus for SFX (zero FFT Convolver overhead)
      this.sfxDelay = this.ctx.createDelay(0.5);
      this.sfxDelay.delayTime.value = 0.085;
      const sfxEchoFilter = this.ctx.createBiquadFilter();
      sfxEchoFilter.type = 'lowpass';
      sfxEchoFilter.frequency.value = 1350;
      const sfxEchoGain = this.ctx.createGain();
      sfxEchoGain.gain.value = 0.16;

      this.sfxGain.connect(this.masterGain);
      this.sfxGain.connect(this.sfxDelay);
      this.sfxDelay.connect(sfxEchoFilter);
      sfxEchoFilter.connect(sfxEchoGain);
      sfxEchoGain.connect(this.masterGain);

      // Lightweight warm stereo room delay bus for music
      this.musicDelayL = this.ctx.createDelay(0.6);
      this.musicDelayL.delayTime.value = 0.24;
      this.musicDelayR = this.ctx.createDelay(0.6);
      this.musicDelayR.delayTime.value = 0.36;

      const musicFeedback = this.ctx.createGain();
      musicFeedback.gain.value = 0.24;
      const musicWetFilter = this.ctx.createBiquadFilter();
      musicWetFilter.type = 'lowpass';
      musicWetFilter.frequency.value = 950;
      const musicWetGain = this.ctx.createGain();
      musicWetGain.gain.value = 0.26;

      // Single reusable lowpass filter bus for all music bars (prevents node accumulation)
      this.musicBusFilter = this.ctx.createBiquadFilter();
      this.musicBusFilter.type = 'lowpass';
      this.musicBusFilter.frequency.value = 1120;
      this.musicBusFilter.Q.value = 0.55;
      this.musicBusFilter.connect(this.musicGain);

      this.musicGain.connect(this.masterGain);
      this.musicGain.connect(this.musicDelayL);
      this.musicDelayL.connect(this.musicDelayR);
      this.musicDelayR.connect(musicFeedback);
      musicFeedback.connect(this.musicDelayL);
      this.musicDelayL.connect(musicWetFilter);
      this.musicDelayR.connect(musicWetFilter);
      musicWetFilter.connect(musicWetGain);
      musicWetGain.connect(this.masterGain);

      // Direct clean speech bus
      this.speechGain.connect(this.masterGain);

      this.masterGain.connect(this.compressor);
      this.compressor.connect(this.ctx.destination);

      this.applyVolumes();
      this.createNoiseBuffers(this.ctx);
      this.saturationCurve = this.buildSaturationCurve(2.0);

      this.ctx.onstatechange = () => {
        if (
          this.ctx?.state === 'running' &&
          this.musicPlaying &&
          this.settings.musicEnabled &&
          this.needsImmediateBar &&
          this.pendingTriggerBar
        ) {
          this.needsImmediateBar = false;
          this.pendingTriggerBar();
        }
        this.notifyListeners();
      };
    }
    return this.ctx;
  }

  public getSpeechDestination(): { ctx: AudioContext; destination: GainNode } | null {
    const ctx = this.ensureContext();
    if (!ctx || !this.speechGain) return null;
    if (ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }
    return { ctx, destination: this.speechGain };
  }

  public setSpeechDucking(active: boolean) {
    if (this.speechDucking === active) return;
    this.speechDucking = active;
    this.applyVolumes();
  }

  private buildSaturationCurve(amount: number): Float32Array<ArrayBuffer> {
    const samples = 512;
    const buffer = new ArrayBuffer(samples * 4);
    const curve = new Float32Array(buffer);
    for (let i = 0; i < samples; i++) {
      const x = (i * 2) / samples - 1;
      curve[i] = ((1 + amount) * x) / (1 + amount * Math.abs(x));
    }
    return curve;
  }

  private createNoiseBuffers(ctx: AudioContext) {
    const sampleRate = ctx.sampleRate;
    const length = Math.floor(sampleRate * 1.5);

    const white = ctx.createBuffer(1, length, sampleRate);
    const whiteData = white.getChannelData(0);
    for (let i = 0; i < length; i++) {
      whiteData[i] = Math.random() * 2 - 1;
    }
    this.noiseBuffer = white;

    const brown = ctx.createBuffer(1, length, sampleRate);
    const brownData = brown.getChannelData(0);
    let lastOut = 0;
    for (let i = 0; i < length; i++) {
      const w = Math.random() * 2 - 1;
      lastOut = (lastOut + 0.035 * w) / 1.035;
      brownData[i] = Math.max(-1, Math.min(1, lastOut * 4.2));
    }
    this.brownNoiseBuffer = brown;
  }

  public async unlock(): Promise<boolean> {
    const ctx = this.ensureContext();
    if (!ctx) return false;
    if (ctx.state === 'suspended') {
      try {
        await ctx.resume();
      } catch {
        // Autoplay restriction until user gesture
      }
    }
    if (
      ctx.state === 'running' &&
      this.musicPlaying &&
      this.settings.musicEnabled &&
      this.needsImmediateBar &&
      this.pendingTriggerBar
    ) {
      this.needsImmediateBar = false;
      this.pendingTriggerBar();
    }
    this.notifyListeners();
    return ctx.state === 'running';
  }

  public isUnlocked(): boolean {
    if (!this.ctx) return false;
    return this.ctx.state === 'running';
  }

  public subscribe(listener: AudioListener): () => void {
    this.listeners.add(listener);
    listener(this.isUnlocked());
    return () => this.listeners.delete(listener);
  }

  private notifyListeners() {
    const unlocked = this.isUnlocked();
    this.listeners.forEach((cb) => cb(unlocked));
  }

  public updateSettings(next: SystemSettings) {
    const prevMusicEnabled = this.settings.musicEnabled;
    this.settings = { ...next };
    this.applyVolumes();

    if (prevMusicEnabled && !next.musicEnabled) {
      this.stopMusic();
    } else if (!prevMusicEnabled && next.musicEnabled && this.musicPlaying) {
      this.startMusic(this.musicMode);
    }
  }

  private applyVolumes() {
    if (!this.ctx || !this.masterGain || !this.sfxGain || !this.musicGain || !this.speechGain) {
      return;
    }
    const now = this.ctx.currentTime;
    this.masterGain.gain.setTargetAtTime(this.settings.masterVolume, now, 0.03);
    this.sfxGain.gain.setTargetAtTime(
      this.settings.sfxEnabled ? this.settings.sfxVolume : 0,
      now,
      0.03
    );
    const duckFactor = this.speechDucking ? 0.34 : 1;
    this.musicGain.gain.setTargetAtTime(
      this.settings.musicEnabled ? this.settings.musicVolume * 0.56 * duckFactor : 0,
      now,
      0.08
    );
    this.speechGain.gain.setTargetAtTime(
      this.settings.screenReaderEnabled ? this.settings.screenReaderVolume : 0,
      now,
      0.03
    );
  }

  private canPlaySfx(isStartup = false): boolean {
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return false;
    if (ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }
    if (isStartup && !this.settings.startupAudioEnabled) return false;
    if (!isStartup && !this.settings.sfxEnabled) return false;
    return true;
  }

  private createPanner(ctx: AudioContext, pan: number): StereoPannerNode | GainNode {
    if (typeof ctx.createStereoPanner === 'function') {
      const panner = ctx.createStereoPanner();
      panner.pan.value = Math.max(-1, Math.min(1, pan));
      return panner;
    }
    return ctx.createGain();
  }

  // =========================================================================
  // REALISTIC CINEMATIC STARTUP FOLEY (METEOR FROM LEFT, IMPACT, IRON, SPARKS)
  // =========================================================================

  public playMeteorDescent(durationSec = 1.75) {
    if (!this.canPlaySfx(true)) return;
    const ctx = this.ctx!;
    const out = this.sfxGain!;
    const now = ctx.currentTime;

    const panner = this.createPanner(ctx, -0.85);
    if ('pan' in panner) {
      panner.pan.setValueAtTime(-0.85, now);
      panner.pan.exponentialRampToValueAtTime(-0.02, now + durationSec * 0.96);
    }
    panner.connect(out);

    if (this.brownNoiseBuffer) {
      const wind = ctx.createBufferSource();
      wind.buffer = this.brownNoiseBuffer;
      wind.loop = true;

      const lowSweep = ctx.createBiquadFilter();
      lowSweep.type = 'lowpass';
      lowSweep.frequency.setValueAtTime(180, now);
      lowSweep.frequency.exponentialRampToValueAtTime(1800, now + durationSec * 0.94);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.exponentialRampToValueAtTime(0.55, now + durationSec * 0.65);
      gain.gain.exponentialRampToValueAtTime(0.9, now + durationSec * 0.96);
      gain.gain.exponentialRampToValueAtTime(0.001, now + durationSec + 0.04);

      wind.connect(lowSweep);
      lowSweep.connect(gain);
      gain.connect(panner);
      wind.onended = () => {
        wind.disconnect();
        lowSweep.disconnect();
        gain.disconnect();
      };
      wind.start(now);
      wind.stop(now + durationSec + 0.06);
    }

    const sub = ctx.createOscillator();
    sub.type = 'triangle';
    sub.frequency.setValueAtTime(92, now);
    sub.frequency.exponentialRampToValueAtTime(42, now + durationSec);

    const subGain = ctx.createGain();
    subGain.gain.setValueAtTime(0.001, now);
    subGain.gain.linearRampToValueAtTime(0.32, now + durationSec * 0.88);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + durationSec + 0.03);

    sub.connect(subGain);
    subGain.connect(panner);
    sub.onended = () => {
      sub.disconnect();
      subGain.disconnect();
      panner.disconnect();
    };
    sub.start(now);
    sub.stop(now + durationSec + 0.05);
  }

  public playMeteorImpact() {
    if (!this.canPlaySfx(true)) return;
    const ctx = this.ctx!;
    const out = this.sfxGain!;
    const now = ctx.currentTime;

    const subOsc = ctx.createOscillator();
    subOsc.type = 'sine';
    subOsc.frequency.setValueAtTime(108, now);
    subOsc.frequency.exponentialRampToValueAtTime(24, now + 0.55);

    const shaper = ctx.createWaveShaper();
    if (this.saturationCurve) shaper.curve = this.saturationCurve;

    const subGain = ctx.createGain();
    subGain.gain.setValueAtTime(0.95, now);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + 1.15);

    subOsc.connect(shaper);
    shaper.connect(subGain);
    subGain.connect(out);
    subOsc.onended = () => {
      subOsc.disconnect();
      shaper.disconnect();
      subGain.disconnect();
    };
    subOsc.start(now);
    subOsc.stop(now + 1.2);

    if (this.brownNoiseBuffer) {
      const blast = ctx.createBufferSource();
      blast.buffer = this.brownNoiseBuffer;

      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.setValueAtTime(3600, now);
      lp.frequency.exponentialRampToValueAtTime(150, now + 1.0);

      const blastGain = ctx.createGain();
      blastGain.gain.setValueAtTime(0.95, now);
      blastGain.gain.exponentialRampToValueAtTime(0.001, now + 1.15);

      blast.connect(lp);
      lp.connect(blastGain);
      blastGain.connect(out);
      blast.onended = () => {
        blast.disconnect();
        lp.disconnect();
        blastGain.disconnect();
      };
      blast.start(now);
      blast.stop(now + 1.2);
    }

    this.playIronClang(0.9, 0, 0.01);
    this.playIronClang(0.55, -0.45, 0.1);
    this.playIronClang(0.48, 0.45, 0.18);

    [0.04, 0.11, 0.2, 0.32, 0.48].forEach((offset, i) => {
      const pan = (i % 2 === 0 ? -1 : 1) * (0.25 + i * 0.12);
      this.playSparkBurst(pan, offset, 0.72 - i * 0.08);
    });
  }

  public playIronClang(intensity = 0.7, pan = 0, delaySec = 0) {
    if (!this.canPlaySfx(true)) return;
    const ctx = this.ctx!;
    const out = this.sfxGain!;
    const t = ctx.currentTime + delaySec;

    const panner = this.createPanner(ctx, pan);
    panner.connect(out);

    const baseFreq = 195 + Math.random() * 80;
    const carrier = ctx.createOscillator();
    carrier.type = 'sine';
    carrier.frequency.setValueAtTime(baseFreq, t);

    const mod = ctx.createOscillator();
    mod.type = 'sine';
    mod.frequency.setValueAtTime(baseFreq * 1.4142, t);

    const modGain = ctx.createGain();
    modGain.gain.setValueAtTime(320 * intensity, t);
    modGain.gain.exponentialRampToValueAtTime(10, t + 0.36);

    mod.connect(modGain);
    modGain.connect(carrier.frequency);

    const env = ctx.createGain();
    env.gain.setValueAtTime(0.001, t);
    env.gain.linearRampToValueAtTime(0.24 * intensity, t + 0.003);
    env.gain.exponentialRampToValueAtTime(0.0008, t + 0.56);

    carrier.connect(env);
    env.connect(panner);
    carrier.onended = () => {
      carrier.disconnect();
      mod.disconnect();
      modGain.disconnect();
      env.disconnect();
      panner.disconnect();
    };
    carrier.start(t);
    mod.start(t);
    carrier.stop(t + 0.6);
    mod.stop(t + 0.6);

    if (this.noiseBuffer) {
      const hit = ctx.createBufferSource();
      hit.buffer = this.noiseBuffer;

      const bp = ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.setValueAtTime(2600 + Math.random() * 800, t);
      bp.Q.setValueAtTime(3.5, t);

      const hg = ctx.createGain();
      hg.gain.setValueAtTime(0.28 * intensity, t);
      hg.gain.exponentialRampToValueAtTime(0.001, t + 0.03);

      hit.connect(bp);
      bp.connect(hg);
      hg.connect(panner);
      hit.onended = () => {
        hit.disconnect();
        bp.disconnect();
        hg.disconnect();
      };
      hit.start(t, Math.random() * 0.6, 0.04);
    }
  }

  public playSparkBurst(pan = 0, delaySec = 0, intensity = 0.6) {
    if (!this.canPlaySfx(true)) return;
    const ctx = this.ctx!;
    const out = this.sfxGain!;
    const t = ctx.currentTime + delaySec;

    const panner = this.createPanner(ctx, pan);
    panner.connect(out);

    if (this.noiseBuffer) {
      const src = ctx.createBufferSource();
      src.buffer = this.noiseBuffer;

      const hp = ctx.createBiquadFilter();
      hp.type = 'bandpass';
      hp.frequency.setValueAtTime(5200 + Math.random() * 3400, t);
      hp.Q.setValueAtTime(3.2, t);

      const g = ctx.createGain();
      g.gain.setValueAtTime(0.001, t);
      g.gain.linearRampToValueAtTime(0.26 * intensity, t + 0.002);
      g.gain.exponentialRampToValueAtTime(0.0008, t + 0.048);

      src.connect(hp);
      hp.connect(g);
      g.connect(panner);
      src.onended = () => {
        src.disconnect();
        hp.disconnect();
        g.disconnect();
        panner.disconnect();
      };
      src.start(t, Math.random() * 0.6, 0.07);
    }
  }

  public playGoldReformation(durationSec = 2.15) {
    if (!this.canPlaySfx(true)) return;
    const ctx = this.ctx!;
    const out = this.sfxGain!;
    const now = ctx.currentTime;

    const drone = ctx.createOscillator();
    drone.type = 'sine';
    drone.frequency.setValueAtTime(55, now);
    drone.frequency.exponentialRampToValueAtTime(110, now + durationSec * 0.9);

    const droneG = ctx.createGain();
    droneG.gain.setValueAtTime(0.001, now);
    droneG.gain.linearRampToValueAtTime(0.24, now + durationSec * 0.8);
    droneG.gain.exponentialRampToValueAtTime(0.001, now + durationSec);

    drone.connect(droneG);
    droneG.connect(out);
    drone.onended = () => {
      drone.disconnect();
      droneG.disconnect();
    };
    drone.start(now);
    drone.stop(now + durationSec + 0.05);

    [0.24, 0.56, 0.88, 1.18, 1.46, 1.72].forEach((step, idx) => {
      const pan = (idx % 2 === 0 ? -1 : 1) * Math.max(0.06, 0.55 - idx * 0.08);
      this.playIronClang(0.28 + idx * 0.05, pan, step);
      if (idx % 2 === 1) {
        this.playSparkBurst(-pan * 0.5, step + 0.03, 0.48);
      }
    });

    const lockTime = now + durationSec * 0.91;
    const latch = ctx.createOscillator();
    latch.type = 'sine';
    latch.frequency.setValueAtTime(145, lockTime);
    latch.frequency.exponentialRampToValueAtTime(48, lockTime + 0.14);

    const latchG = ctx.createGain();
    latchG.gain.setValueAtTime(0.4, lockTime);
    latchG.gain.exponentialRampToValueAtTime(0.001, lockTime + 0.18);
    latch.connect(latchG);
    latchG.connect(out);
    latch.onended = () => {
      latch.disconnect();
      latchG.disconnect();
    };
    latch.start(lockTime);
    latch.stop(lockTime + 0.2);

    [130.81, 196.0].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      osc.type = i === 0 ? 'triangle' : 'sine';
      osc.frequency.setValueAtTime(freq, lockTime);

      const g = ctx.createGain();
      g.gain.setValueAtTime(0.001, lockTime);
      g.gain.linearRampToValueAtTime(0.15, lockTime + 0.015);
      g.gain.exponentialRampToValueAtTime(0.0008, lockTime + 0.95);

      osc.connect(g);
      g.connect(out);
      osc.onended = () => {
        osc.disconnect();
        g.disconnect();
      };
      osc.start(lockTime);
      osc.stop(lockTime + 1.0);
    });
  }

  public playControllerZoom() {
    if (!this.canPlaySfx(true)) return;
    const ctx = this.ctx!;
    const out = this.sfxGain!;
    const now = ctx.currentTime;

    if (this.brownNoiseBuffer) {
      const air = ctx.createBufferSource();
      air.buffer = this.brownNoiseBuffer;

      const bp = ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.Q.setValueAtTime(2.0, now);
      bp.frequency.setValueAtTime(260, now);
      bp.frequency.exponentialRampToValueAtTime(1700, now + 0.48);
      bp.frequency.exponentialRampToValueAtTime(340, now + 1.0);

      const panner = this.createPanner(ctx, -0.65);
      if ('pan' in panner) {
        panner.pan.setValueAtTime(-0.65, now);
        panner.pan.linearRampToValueAtTime(0.65, now + 0.52);
        panner.pan.linearRampToValueAtTime(0, now + 1.0);
      }

      const ag = ctx.createGain();
      ag.gain.setValueAtTime(0.001, now);
      ag.gain.linearRampToValueAtTime(0.4, now + 0.42);
      ag.gain.exponentialRampToValueAtTime(0.001, now + 1.05);

      air.connect(bp);
      bp.connect(ag);
      ag.connect(panner);
      panner.connect(out);
      air.onended = () => {
        air.disconnect();
        bp.disconnect();
        ag.disconnect();
        panner.disconnect();
      };
      air.start(now);
      air.stop(now + 1.1);
    }

    [130.81, 261.63].forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq * 0.94, now);
      osc.frequency.exponentialRampToValueAtTime(freq, now + 0.6);

      const g = ctx.createGain();
      g.gain.setValueAtTime(0.001, now);
      g.gain.linearRampToValueAtTime(0.11 - idx * 0.02, now + 0.3);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.95);

      osc.connect(g);
      g.connect(out);
      osc.onended = () => {
        osc.disconnect();
        g.disconnect();
      };
      osc.start(now);
      osc.stop(now + 1.0);
    });
  }

  // =========================================================================
  // SPACE STARFIELD CLASH SOUND (POST-BOOT INTO PROFILE SELECTION)
  // =========================================================================

  /**
   * Shimmering star bursts & celestial metallic clashes when entering the dark
   * starfield Profile Selection screen right after the boot intro.
   */
  public playStarfieldClash() {
    if (!this.canPlaySfx(false)) return;
    const ctx = this.ctx!;
    const out = this.sfxGain!;
    const now = ctx.currentTime;

    // 1. Deep cosmic space swell
    const swell = ctx.createOscillator();
    swell.type = 'sine';
    swell.frequency.setValueAtTime(65.41, now);
    swell.frequency.exponentialRampToValueAtTime(130.81, now + 0.65);

    const swellG = ctx.createGain();
    swellG.gain.setValueAtTime(0.001, now);
    swellG.gain.linearRampToValueAtTime(0.24, now + 0.14);
    swellG.gain.exponentialRampToValueAtTime(0.0008, now + 1.15);

    swell.connect(swellG);
    swellG.connect(out);
    swell.onended = () => {
      swell.disconnect();
      swellG.disconnect();
    };
    swell.start(now);
    swell.stop(now + 1.2);

    // 2. Clashing celestial star crystals across the stereo field
    const starHits = [
      { delay: 0.0, f1: 1174.66, f2: 1760.0, pan: -0.78, gain: 0.12 },
      { delay: 0.07, f1: 1567.98, f2: 2349.32, pan: 0.72, gain: 0.11 },
      { delay: 0.14, f1: 987.77, f2: 1479.98, pan: -0.38, gain: 0.12 },
      { delay: 0.21, f1: 2093.0, f2: 3135.96, pan: 0.44, gain: 0.1 },
      { delay: 0.29, f1: 1318.51, f2: 1975.53, pan: -0.15, gain: 0.11 },
      { delay: 0.37, f1: 1760.0, f2: 2637.02, pan: 0.18, gain: 0.09 },
    ];

    starHits.forEach((hit) => {
      const t = now + hit.delay;
      const panner = this.createPanner(ctx, hit.pan);
      panner.connect(out);

      // Inharmonic metallic bell pair simulating colliding stars/shards
      const oscA = ctx.createOscillator();
      oscA.type = 'sine';
      oscA.frequency.setValueAtTime(hit.f1, t);

      const oscB = ctx.createOscillator();
      oscB.type = 'triangle';
      oscB.frequency.setValueAtTime(hit.f2 * 1.07, t);

      const g = ctx.createGain();
      g.gain.setValueAtTime(0.001, t);
      g.gain.linearRampToValueAtTime(hit.gain, t + 0.004);
      g.gain.exponentialRampToValueAtTime(0.0006, t + 0.58);

      oscA.connect(g);
      oscB.connect(g);
      g.connect(panner);
      oscA.onended = () => {
        oscA.disconnect();
        oscB.disconnect();
        g.disconnect();
        panner.disconnect();
      };
      oscA.start(t);
      oscB.start(t);
      oscA.stop(t + 0.62);
      oscB.stop(t + 0.62);
    });

    // 3. Stardust shimmer burst
    if (this.noiseBuffer) {
      const dust = ctx.createBufferSource();
      dust.buffer = this.noiseBuffer;

      const bp = ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.setValueAtTime(4600, now);
      bp.frequency.exponentialRampToValueAtTime(2200, now + 0.55);
      bp.Q.setValueAtTime(2.6, now);

      const dg = ctx.createGain();
      dg.gain.setValueAtTime(0.001, now);
      dg.gain.linearRampToValueAtTime(0.14, now + 0.04);
      dg.gain.exponentialRampToValueAtTime(0.0008, now + 0.65);

      dust.connect(bp);
      bp.connect(dg);
      dg.connect(out);
      dust.onended = () => {
        dust.disconnect();
        bp.disconnect();
        dg.disconnect();
      };
      dust.start(now, 0, 0.7);
    }
  }

  // =========================================================================
  // JOYFUL 8-BIT RETRO UI SOUND EFFECTS + FANCY DASHBOARD UNLOCK CHIME
  // =========================================================================

  private play8BitNote(
    freq: number,
    startTime: number,
    durationSec: number,
    gainPeak: number,
    wave: OscillatorType = 'square',
    pan = 0
  ) {
    if (!this.ctx || !this.sfxGain) return;
    const ctx = this.ctx;
    const out = this.sfxGain;

    const osc = ctx.createOscillator();
    osc.type = wave;
    osc.frequency.setValueAtTime(freq, startTime);

    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(4200, startTime);

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.001, startTime);
    g.gain.linearRampToValueAtTime(gainPeak, startTime + 0.004);
    g.gain.exponentialRampToValueAtTime(0.0008, startTime + durationSec);

    const panner = this.createPanner(ctx, pan);
    osc.connect(lp);
    lp.connect(g);
    g.connect(panner);
    panner.connect(out);

    osc.onended = () => {
      osc.disconnect();
      lp.disconnect();
      g.disconnect();
      panner.disconnect();
    };
    osc.start(startTime);
    osc.stop(startTime + durationSec + 0.015);
  }

  /** 1. Tile Highlight: cheerful 8-bit retro pulse blip (C5 -> E5) */
  public playHighlight() {
    if (!this.canPlaySfx(false)) return;
    const now = this.ctx!.currentTime;
    this.play8BitNote(523.25, now, 0.036, 0.11, 'square', 0);
    this.play8BitNote(659.25, now + 0.024, 0.045, 0.1, 'square', 0);
  }

  /** 2. Scroll / Swipe Left: left-panned joyful 8-bit downward step (G5 -> D5) */
  public playScrollLeft() {
    if (!this.canPlaySfx(false)) return;
    const now = this.ctx!.currentTime;
    this.play8BitNote(783.99, now, 0.036, 0.12, 'square', -0.65);
    this.play8BitNote(587.33, now + 0.032, 0.055, 0.11, 'square', -0.65);
  }

  /** 3. Scroll / Swipe Right: right-panned joyful 8-bit upward step (D5 -> G5) */
  public playScrollRight() {
    if (!this.canPlaySfx(false)) return;
    const now = this.ctx!.currentTime;
    this.play8BitNote(587.33, now, 0.036, 0.12, 'square', 0.65);
    this.play8BitNote(783.99, now + 0.032, 0.055, 0.11, 'square', 0.65);
  }

  /** 4. List / Vertical Scroll: snappy 8-bit retro tick */
  public playScroll() {
    if (!this.canPlaySfx(false)) return;
    const nowMs = performance.now();
    if (nowMs - this.lastScrollTime < 60) return;
    this.lastScrollTime = nowMs;

    const now = this.ctx!.currentTime;
    this.play8BitNote(880, now, 0.028, 0.08, 'triangle', 0);
  }

  /** 5. Select / Activate: joyful classic 8-bit ascending fanfare (C5 -> E5 -> G5 -> C6) */
  public playSelect() {
    if (!this.canPlaySfx(false)) return;
    const now = this.ctx!.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((freq, i) => {
      this.play8BitNote(
        freq,
        now + i * 0.042,
        i === notes.length - 1 ? 0.14 : 0.052,
        0.13 - i * 0.01,
        'square',
        0
      );
    });
  }

  /** 6. Back / Cancel: distinct descending 8-bit retro return cadence (A4 -> F4 -> C4) */
  public playBack() {
    if (!this.canPlaySfx(false)) return;
    const now = this.ctx!.currentTime;
    const notes = [440.0, 349.23, 261.63];
    notes.forEach((freq, i) => {
      this.play8BitNote(
        freq,
        now + i * 0.048,
        i === notes.length - 1 ? 0.13 : 0.055,
        0.15 - i * 0.015,
        'triangle',
        0
      );
    });
  }

  /** 7. Home Screen Unlock Chime: warm, sparkling phone-unlock sound effect */
  public playHomeUnlock() {
    if (!this.canPlaySfx(false)) return;
    const ctx = this.ctx!;
    const out = this.sfxGain!;
    const now = ctx.currentTime;

    const pop = ctx.createOscillator();
    pop.type = 'sine';
    pop.frequency.setValueAtTime(320, now);
    pop.frequency.exponentialRampToValueAtTime(140, now + 0.05);
    const popG = ctx.createGain();
    popG.gain.setValueAtTime(0.18, now);
    popG.gain.exponentialRampToValueAtTime(0.001, now + 0.06);
    pop.connect(popG);
    popG.connect(out);
    pop.onended = () => {
      pop.disconnect();
      popG.disconnect();
    };
    pop.start(now);
    pop.stop(now + 0.07);

    const chimeNotes = [
      { freq: 523.25, delay: 0.02, pan: -0.25 },
      { freq: 783.99, delay: 0.085, pan: 0.25 },
      { freq: 1046.5, delay: 0.15, pan: -0.1 },
      { freq: 1318.51, delay: 0.215, pan: 0.15 },
    ];

    chimeNotes.forEach((n, idx) => {
      const t = now + n.delay;
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(n.freq, t);

      const g = ctx.createGain();
      g.gain.setValueAtTime(0.001, t);
      g.gain.linearRampToValueAtTime(0.14 - idx * 0.012, t + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0008, t + 0.65);

      const panner = this.createPanner(ctx, n.pan);
      osc.connect(g);
      g.connect(panner);
      panner.connect(out);
      osc.onended = () => {
        osc.disconnect();
        g.disconnect();
        panner.disconnect();
      };
      osc.start(t);
      osc.stop(t + 0.68);
    });
  }

  // =========================================================================
  // DUAL BACKGROUND MUSIC MODES:
  // 1) 'profile': Dark Cosmic Space Ambience (Profile Selection)
  // 2) 'home': Peaceful Relaxed C-Major Felt Piano (Dashboard)
  // =========================================================================

  private playPianoNote(
    freq: number,
    startTime: number,
    durationSec: number,
    velocity: number,
    pan: number,
    barFilter: BiquadFilterNode
  ) {
    if (!this.ctx) return;
    const c = this.ctx;
    const panner = this.createPanner(c, pan);
    panner.connect(barFilter);

    const osc1 = c.createOscillator();
    osc1.type = 'triangle';
    osc1.frequency.setValueAtTime(freq, startTime);
    osc1.detune.setValueAtTime(-2.2, startTime);

    const osc2 = c.createOscillator();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(freq, startTime);
    osc2.detune.setValueAtTime(2.2, startTime);

    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, startTime);
    g.gain.linearRampToValueAtTime(velocity, startTime + 0.016);
    g.gain.exponentialRampToValueAtTime(velocity * 0.28, startTime + durationSec * 0.35);
    g.gain.exponentialRampToValueAtTime(0.0001, startTime + durationSec);

    osc1.connect(g);
    osc2.connect(g);
    g.connect(panner);

    this.activeMusicNodes.add(osc1);
    this.activeMusicNodes.add(osc2);
    osc1.onended = () => {
      this.activeMusicNodes.delete(osc1);
      osc1.disconnect();
    };
    osc2.onended = () => {
      this.activeMusicNodes.delete(osc2);
      osc2.disconnect();
      g.disconnect();
      panner.disconnect();
    };

    osc1.start(startTime);
    osc2.start(startTime);
    osc1.stop(startTime + durationSec + 0.04);
    osc2.stop(startTime + durationSec + 0.04);
  }

  private playSpacePadNote(
    freq: number,
    startTime: number,
    durationSec: number,
    velocity: number,
    pan: number,
    barFilter: BiquadFilterNode
  ) {
    if (!this.ctx) return;
    const c = this.ctx;
    const panner = this.createPanner(c, pan);
    panner.connect(barFilter);

    const osc = c.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, startTime);

    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, startTime);
    g.gain.linearRampToValueAtTime(velocity, startTime + durationSec * 0.32);
    g.gain.exponentialRampToValueAtTime(0.0001, startTime + durationSec);

    osc.connect(g);
    g.connect(panner);
    this.activeMusicNodes.add(osc);
    osc.onended = () => {
      this.activeMusicNodes.delete(osc);
      osc.disconnect();
      g.disconnect();
      panner.disconnect();
    };

    osc.start(startTime);
    osc.stop(startTime + durationSec + 0.05);
  }

  public startMusic(mode: MusicMode = this.musicMode) {
    const ctx = this.ensureContext();
    if (!ctx || !this.musicGain) return;
    if (ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }

    const modeChanged = this.musicMode !== mode;
    this.musicMode = mode;

    if (modeChanged) {
      this.chordStep = 0;
      if (this.musicTimer !== null) {
        this.stopMusic();
      }
    }

    this.musicPlaying = true;
    if (!this.settings.musicEnabled) return;
    if (this.musicTimer !== null) {
      if (ctx.state === 'running' && this.needsImmediateBar && this.pendingTriggerBar) {
        this.needsImmediateBar = false;
        this.pendingTriggerBar();
      }
      return;
    }

    if (mode === 'profile') {
      this.startProfileSpaceLoop();
    } else {
      this.startHomePianoLoop();
    }
  }

  private startProfileSpaceLoop() {
    // Deep, calm starry cosmos ambience: Cmaj9(#11) -> Em7 -> Fmaj9 -> G6sus4
    const spaceBars = [
      {
        pad: [
          { freq: 65.41, dur: 5.8, vel: 0.14, pan: -0.25 },
          { freq: 130.81, dur: 5.8, vel: 0.11, pan: 0.25 },
          { freq: 196.0, dur: 5.5, vel: 0.09, pan: -0.1 },
          { freq: 246.94, dur: 5.2, vel: 0.08, pan: 0.18 },
        ],
        twinkles: [
          { freq: 523.25, offset: 0.8, dur: 2.2, vel: 0.055, pan: -0.55 },
          { freq: 739.99, offset: 2.4, dur: 2.4, vel: 0.045, pan: 0.52 },
          { freq: 659.25, offset: 3.9, dur: 2.0, vel: 0.05, pan: -0.2 },
        ],
      },
      {
        pad: [
          { freq: 82.41, dur: 5.8, vel: 0.14, pan: -0.25 },
          { freq: 164.81, dur: 5.8, vel: 0.1, pan: 0.25 },
          { freq: 246.94, dur: 5.5, vel: 0.09, pan: 0.1 },
          { freq: 293.66, dur: 5.2, vel: 0.08, pan: -0.18 },
        ],
        twinkles: [
          { freq: 587.33, offset: 1.0, dur: 2.2, vel: 0.05, pan: 0.48 },
          { freq: 783.99, offset: 2.8, dur: 2.3, vel: 0.048, pan: -0.5 },
        ],
      },
      {
        pad: [
          { freq: 87.31, dur: 5.8, vel: 0.14, pan: -0.2 },
          { freq: 130.81, dur: 5.8, vel: 0.11, pan: 0.2 },
          { freq: 220.0, dur: 5.5, vel: 0.09, pan: -0.15 },
          { freq: 329.63, dur: 5.2, vel: 0.08, pan: 0.22 },
        ],
        twinkles: [
          { freq: 659.25, offset: 0.9, dur: 2.3, vel: 0.05, pan: -0.45 },
          { freq: 880.0, offset: 2.7, dur: 2.4, vel: 0.045, pan: 0.45 },
        ],
      },
    ];

    const triggerBar = () => {
      if (!this.musicPlaying || !this.settings.musicEnabled || !this.ctx || !this.musicBusFilter) {
        return;
      }
      if (this.ctx.state !== 'running') {
        this.needsImmediateBar = true;
        return;
      }

      this.needsImmediateBar = false;
      const c = this.ctx;
      const barFilter = this.musicBusFilter;
      barFilter.frequency.setValueAtTime(1050, c.currentTime);
      barFilter.Q.setValueAtTime(0.5, c.currentTime);

      const bar = spaceBars[this.chordStep % spaceBars.length];
      this.chordStep++;
      const baseTime = c.currentTime + 0.05;

      bar.pad.forEach((n) => {
        this.playSpacePadNote(n.freq, baseTime, n.dur, n.vel, n.pan, barFilter);
      });
      bar.twinkles.forEach((t) => {
        this.playPianoNote(t.freq, baseTime + t.offset, t.dur, t.vel, t.pan, barFilter);
      });
    };

    this.pendingTriggerBar = triggerBar;
    triggerBar();
    this.musicTimer = window.setInterval(triggerBar, 5400);
  }

  private startHomePianoLoop() {
    // Peaceful, relaxed C Major felt-piano chord progression: Cmaj9 -> G6/B -> Am9 -> Fmaj9
    const progression = [
      {
        notes: [
          { freq: 130.81, offset: 0.0, dur: 4.7, vel: 0.16, pan: -0.25 },
          { freq: 196.0, offset: 0.36, dur: 4.3, vel: 0.12, pan: -0.1 },
          { freq: 246.94, offset: 0.75, dur: 3.9, vel: 0.11, pan: 0.05 },
          { freq: 293.66, offset: 1.45, dur: 3.4, vel: 0.1, pan: 0.16 },
          { freq: 329.63, offset: 2.35, dur: 2.9, vel: 0.12, pan: 0.24 },
          { freq: 392.0, offset: 3.5, dur: 2.5, vel: 0.09, pan: 0.3 },
        ],
      },
      {
        notes: [
          { freq: 123.47, offset: 0.0, dur: 4.7, vel: 0.15, pan: -0.28 },
          { freq: 196.0, offset: 0.38, dur: 4.3, vel: 0.11, pan: -0.1 },
          { freq: 293.66, offset: 0.82, dur: 3.8, vel: 0.11, pan: 0.1 },
          { freq: 329.63, offset: 1.55, dur: 3.3, vel: 0.1, pan: 0.2 },
          { freq: 392.0, offset: 2.55, dur: 2.8, vel: 0.11, pan: 0.28 },
          { freq: 293.66, offset: 3.7, dur: 2.3, vel: 0.08, pan: 0.12 },
        ],
      },
      {
        notes: [
          { freq: 110.0, offset: 0.0, dur: 4.8, vel: 0.16, pan: -0.3 },
          { freq: 164.81, offset: 0.36, dur: 4.4, vel: 0.12, pan: -0.15 },
          { freq: 246.94, offset: 0.78, dur: 3.9, vel: 0.1, pan: 0.05 },
          { freq: 261.63, offset: 1.5, dur: 3.5, vel: 0.11, pan: 0.15 },
          { freq: 329.63, offset: 2.48, dur: 3.0, vel: 0.11, pan: 0.24 },
          { freq: 392.0, offset: 3.6, dur: 2.4, vel: 0.08, pan: 0.32 },
        ],
      },
      {
        notes: [
          { freq: 87.31, offset: 0.0, dur: 4.9, vel: 0.15, pan: -0.32 },
          { freq: 130.81, offset: 0.36, dur: 4.5, vel: 0.13, pan: -0.2 },
          { freq: 196.0, offset: 0.78, dur: 4.0, vel: 0.1, pan: 0.0 },
          { freq: 220.0, offset: 1.48, dur: 3.5, vel: 0.11, pan: 0.12 },
          { freq: 261.63, offset: 2.42, dur: 3.1, vel: 0.11, pan: 0.2 },
          { freq: 329.63, offset: 3.55, dur: 2.6, vel: 0.09, pan: 0.28 },
        ],
      },
    ];

    const triggerBar = () => {
      if (!this.musicPlaying || !this.settings.musicEnabled || !this.ctx || !this.musicBusFilter) {
        return;
      }
      if (this.ctx.state !== 'running') {
        this.needsImmediateBar = true;
        return;
      }

      this.needsImmediateBar = false;
      const c = this.ctx;
      const barFilter = this.musicBusFilter;
      barFilter.frequency.setValueAtTime(1150, c.currentTime);
      barFilter.Q.setValueAtTime(0.6, c.currentTime);

      const bar = progression[this.chordStep % progression.length];
      this.chordStep++;
      const baseTime = c.currentTime + 0.05;

      bar.notes.forEach((n) => {
        const humanOffset = n.offset + (Math.random() - 0.5) * 0.02;
        this.playPianoNote(
          n.freq,
          baseTime + Math.max(0, humanOffset),
          n.dur,
          n.vel,
          n.pan,
          barFilter
        );
      });
    };

    this.pendingTriggerBar = triggerBar;
    triggerBar();
    this.musicTimer = window.setInterval(triggerBar, 5200);
  }

  public stopMusic() {
    this.musicPlaying = false;
    this.needsImmediateBar = false;
    this.pendingTriggerBar = null;
    if (this.musicTimer !== null) {
      window.clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
    this.activeMusicNodes.forEach((node) => {
      try {
        node.stop();
        node.disconnect();
      } catch {
        // Ignore already stopped nodes
      }
    });
    this.activeMusicNodes.clear();
  }
}

export const soundEngine = new RetroSoundEngine();
