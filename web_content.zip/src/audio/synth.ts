import { SynthConfig, TrackFx, DrumSoundType, midiToFrequency } from '../types/daw';

// Cache procedural impulse responses to prevent re-generation overhead
const impulseCache = new Map<number, AudioBuffer>();

export function createImpulseResponse(ctx: BaseAudioContext, decaySec = 2.0): AudioBuffer {
  const sampleRate = ctx.sampleRate;
  const length = Math.floor(sampleRate * Math.min(Math.max(decaySec, 0.2), 6.0));
  const cacheKey = Math.round(decaySec * 10);
  
  if (impulseCache.has(cacheKey) && impulseCache.get(cacheKey)!.sampleRate === sampleRate) {
    return impulseCache.get(cacheKey)!;
  }

  const impulse = ctx.createBuffer(2, length, sampleRate);
  const left = impulse.getChannelData(0);
  const right = impulse.getChannelData(1);

  for (let i = 0; i < length; i++) {
    const t = i / sampleRate;
    // Exponential decay with smooth room diffusion
    const envelope = Math.exp(-3.5 * t / decaySec);
    left[i] = (Math.random() * 2 - 1) * envelope;
    right[i] = (Math.random() * 2 - 1) * envelope;
  }

  impulseCache.set(cacheKey, impulse);
  return impulse;
}

export function createDistortionCurve(amount = 0): Float32Array<ArrayBuffer> {
  const n = 256;
  const buffer = new ArrayBuffer(n * Float32Array.BYTES_PER_ELEMENT);
  const curve = new Float32Array(buffer);
  const k = typeof amount === 'number' && amount > 0 ? amount * 12 : 0;
  const deg = Math.PI / 180;
  
  if (k === 0) {
    for (let i = 0; i < n; i++) {
      const x = (i * 2) / n - 1;
      curve[i] = x;
    }
    return curve;
  }

  for (let i = 0; i < n; i++) {
    const x = (i * 2) / n - 1;
    curve[i] = ((3 + k) * x * 20 * deg) / (Math.PI + k * Math.abs(x));
  }
  return curve;
}

export interface ActiveVoice {
  stop: (time?: number) => void;
}

/**
 * Triggers a polyphonic synth note with the given SynthConfig and velocity.
 */
export function playSynthNote(
  ctx: BaseAudioContext,
  destination: AudioNode,
  midiPitch: number,
  config: SynthConfig,
  startTime: number,
  duration?: number,
  velocity = 0.8
): ActiveVoice {
  const freq = midiToFrequency(midiPitch);
  const now = Math.max(startTime, ctx.currentTime);

  // Oscillators
  const osc1 = ctx.createOscillator();
  osc1.type = config.osc1Type;
  osc1.frequency.setValueAtTime(freq, now);

  const osc2 = ctx.createOscillator();
  osc2.type = config.osc2Type;
  osc2.frequency.setValueAtTime(freq, now);
  osc2.detune.setValueAtTime(config.detune, now);

  // Oscillator Mix
  const osc1Gain = ctx.createGain();
  const osc2Gain = ctx.createGain();
  osc1Gain.gain.setValueAtTime(1 - config.osc2Mix * 0.4, now);
  osc2Gain.gain.setValueAtTime(config.osc2Mix, now);

  osc1.connect(osc1Gain);
  osc2.connect(osc2Gain);

  // Filter
  const filter = ctx.createBiquadFilter();
  filter.type = config.filterType || 'lowpass';
  filter.frequency.setValueAtTime(config.filterCutoff, now);
  filter.Q.setValueAtTime(config.filterRes, now);

  // Filter envelope - short punch
  const filterEnvMod = Math.min(config.filterCutoff * 1.5, 14000);
  filter.frequency.exponentialRampToValueAtTime(Math.max(filterEnvMod, 100), now + 0.05);
  filter.frequency.exponentialRampToValueAtTime(Math.max(config.filterCutoff, 60), now + 0.3);

  osc1Gain.connect(filter);
  osc2Gain.connect(filter);

  // Volume Envelope (ADSR)
  const ampGain = ctx.createGain();
  ampGain.gain.setValueAtTime(0.0001, now);

  const attackTime = Math.max(config.attack, 0.005);
  const decayTime = Math.max(config.decay, 0.05);
  const peakVolume = Math.max(velocity, 0.05);
  const sustainLevel = Math.max(config.sustain * peakVolume, 0.0001);

  ampGain.gain.exponentialRampToValueAtTime(peakVolume, now + attackTime);
  ampGain.gain.exponentialRampToValueAtTime(sustainLevel, now + attackTime + decayTime);

  filter.connect(ampGain);
  ampGain.connect(destination);

  osc1.start(now);
  osc2.start(now);

  const releaseTime = Math.max(config.release, 0.05);

  const stop = (stopTime = ctx.currentTime) => {
    const st = Math.max(stopTime, ctx.currentTime);
    ampGain.gain.cancelScheduledValues(st);
    ampGain.gain.setValueAtTime(ampGain.gain.value, st);
    ampGain.gain.exponentialRampToValueAtTime(0.0001, st + releaseTime);

    try {
      osc1.stop(st + releaseTime + 0.05);
      osc2.stop(st + releaseTime + 0.05);
    } catch {
      // already stopped
    }
  };

  if (duration !== undefined && duration > 0) {
    const noteEndTime = now + duration;
    stop(noteEndTime);
  }

  return { stop };
}

/**
 * Procedural drum synthesis engine: 100% reliable, zero external network assets required.
 */
export function playDrumSound(
  ctx: BaseAudioContext,
  destination: AudioNode,
  drum: DrumSoundType,
  startTime: number,
  velocity = 0.8
) {
  const now = Math.max(startTime, ctx.currentTime);
  const vel = Math.max(0.1, Math.min(velocity, 1.2));

  switch (drum) {
    case 'kick': {
      // Punchy 808 style kick with initial transient click and pitch drop
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(160, now);
      osc.frequency.exponentialRampToValueAtTime(48, now + 0.08);
      osc.frequency.exponentialRampToValueAtTime(32, now + 0.35);

      gain.gain.setValueAtTime(1.0 * vel, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

      // Add click attack
      const clickOsc = ctx.createOscillator();
      const clickGain = ctx.createGain();
      clickOsc.type = 'triangle';
      clickOsc.frequency.setValueAtTime(350, now);
      clickOsc.frequency.exponentialRampToValueAtTime(40, now + 0.02);
      clickGain.gain.setValueAtTime(0.6 * vel, now);
      clickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.025);

      clickOsc.connect(clickGain);
      clickGain.connect(destination);
      clickOsc.start(now);
      clickOsc.stop(now + 0.03);

      osc.connect(gain);
      gain.connect(destination);
      osc.start(now);
      osc.stop(now + 0.45);
      break;
    }

    case 'snare': {
      // Dual tone: body oscillator + shaped white noise
      const osc = ctx.createOscillator();
      const oscGain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(220, now);
      osc.frequency.exponentialRampToValueAtTime(140, now + 0.08);
      oscGain.gain.setValueAtTime(0.7 * vel, now);
      oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
      osc.connect(oscGain);
      oscGain.connect(destination);
      osc.start(now);
      osc.stop(now + 0.18);

      // Noise layer
      const bufferSize = ctx.sampleRate * 0.25;
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }

      const noise = ctx.createBufferSource();
      noise.buffer = noiseBuffer;
      const filter = ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.setValueAtTime(1000, now);

      const noiseGain = ctx.createGain();
      noiseGain.gain.setValueAtTime(0.9 * vel, now);
      noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);

      noise.connect(filter);
      filter.connect(noiseGain);
      noiseGain.connect(destination);
      noise.start(now);
      noise.stop(now + 0.25);
      break;
    }

    case 'clap': {
      // 3 micro noise bursts
      const burstCount = 3;
      for (let i = 0; i < burstCount; i++) {
        const burstTime = now + i * 0.012;
        const dur = i === burstCount - 1 ? 0.2 : 0.015;
        const bufferSize = Math.floor(ctx.sampleRate * dur);
        const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const data = noiseBuffer.getChannelData(0);
        for (let j = 0; j < bufferSize; j++) {
          data[j] = Math.random() * 2 - 1;
        }

        const source = ctx.createBufferSource();
        source.buffer = noiseBuffer;
        const filter = ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(1100, burstTime);
        filter.Q.setValueAtTime(1.8, burstTime);

        const gain = ctx.createGain();
        gain.gain.setValueAtTime(0.85 * vel, burstTime);
        gain.gain.exponentialRampToValueAtTime(0.001, burstTime + dur);

        source.connect(filter);
        filter.connect(gain);
        gain.connect(destination);
        source.start(burstTime);
        source.stop(burstTime + dur + 0.02);
      }
      break;
    }

    case 'hihat_closed': {
      // Crisp metallic closed hat
      const dur = 0.06;
      const bufferSize = Math.floor(ctx.sampleRate * dur);
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      const source = ctx.createBufferSource();
      source.buffer = buffer;

      const hpFilter = ctx.createBiquadFilter();
      hpFilter.type = 'highpass';
      hpFilter.frequency.setValueAtTime(7000, now);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.7 * vel, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + dur);

      source.connect(hpFilter);
      hpFilter.connect(gain);
      gain.connect(destination);
      source.start(now);
      source.stop(now + dur + 0.01);
      break;
    }

    case 'hihat_open': {
      // Sizzling open hat
      const dur = 0.42;
      const bufferSize = Math.floor(ctx.sampleRate * dur);
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      const source = ctx.createBufferSource();
      source.buffer = buffer;

      const hpFilter = ctx.createBiquadFilter();
      hpFilter.type = 'highpass';
      hpFilter.frequency.setValueAtTime(5500, now);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.75 * vel, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + dur);

      source.connect(hpFilter);
      hpFilter.connect(gain);
      gain.connect(destination);
      source.start(now);
      source.stop(now + dur + 0.02);
      break;
    }

    case 'sub808': {
      // Long resonant sub bass hit
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(65, now);
      osc.frequency.exponentialRampToValueAtTime(42, now + 0.1);
      
      gain.gain.setValueAtTime(1.1 * vel, now);
      gain.gain.setValueAtTime(0.9 * vel, now + 0.2);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.9);

      osc.connect(gain);
      gain.connect(destination);
      osc.start(now);
      osc.stop(now + 0.95);
      break;
    }

    case 'perc': {
      // Resonant rimshot/wood percussion
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(820, now);
      osc.frequency.exponentialRampToValueAtTime(450, now + 0.05);

      gain.gain.setValueAtTime(0.8 * vel, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.07);

      osc.connect(gain);
      gain.connect(destination);
      osc.start(now);
      osc.stop(now + 0.09);
      break;
    }

    case 'cowbell': {
      // Dual square oscillator 808 cowbell
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();
      const filter = ctx.createBiquadFilter();

      osc1.type = 'square';
      osc1.frequency.setValueAtTime(800, now);

      osc2.type = 'square';
      osc2.frequency.setValueAtTime(540, now);

      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(750, now);
      filter.Q.setValueAtTime(2.5, now);

      gain.gain.setValueAtTime(0.7 * vel, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

      osc1.connect(filter);
      osc2.connect(filter);
      filter.connect(gain);
      gain.connect(destination);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 0.4);
      osc2.stop(now + 0.4);
      break;
    }
  }
}

/**
 * Creates and connects the FX rack nodes for a track channel.
 */
export function buildTrackFxRack(ctx: BaseAudioContext, fx: TrackFx, masterBus: AudioNode) {
  const inputNode = ctx.createGain();

  // 1. 3-Band Parametric EQ
  const lowEq = ctx.createBiquadFilter();
  lowEq.type = 'lowshelf';
  lowEq.frequency.setValueAtTime(250, ctx.currentTime);
  lowEq.gain.setValueAtTime(fx.eqLow, ctx.currentTime);

  const midEq = ctx.createBiquadFilter();
  midEq.type = 'peaking';
  midEq.frequency.setValueAtTime(1500, ctx.currentTime);
  midEq.Q.setValueAtTime(1.0, ctx.currentTime);
  midEq.gain.setValueAtTime(fx.eqMid, ctx.currentTime);

  const highEq = ctx.createBiquadFilter();
  highEq.type = 'highshelf';
  highEq.frequency.setValueAtTime(5500, ctx.currentTime);
  highEq.gain.setValueAtTime(fx.eqHigh, ctx.currentTime);

  inputNode.connect(lowEq);
  lowEq.connect(midEq);
  midEq.connect(highEq);

  // 2. Distortion / Overdrive
  const distNode = ctx.createWaveShaper();
  distNode.curve = createDistortionCurve(fx.distortionDrive);
  distNode.oversample = '2x';

  const distWetGain = ctx.createGain();
  distWetGain.gain.setValueAtTime(fx.distortionMix, ctx.currentTime);
  const distDryGain = ctx.createGain();
  distDryGain.gain.setValueAtTime(1 - fx.distortionMix * 0.5, ctx.currentTime);

  const distOutput = ctx.createGain();
  highEq.connect(distNode);
  distNode.connect(distWetGain);
  distWetGain.connect(distOutput);
  highEq.connect(distDryGain);
  distDryGain.connect(distOutput);

  // 3. Stereo Delay
  const delayNode = ctx.createDelay(1.5);
  delayNode.delayTime.setValueAtTime(Math.max(fx.delayTime, 0.05), ctx.currentTime);

  const delayFeedback = ctx.createGain();
  delayFeedback.gain.setValueAtTime(Math.min(fx.delayFeedback, 0.85), ctx.currentTime);

  const delayDamp = ctx.createBiquadFilter();
  delayDamp.type = 'lowpass';
  delayDamp.frequency.setValueAtTime(4000, ctx.currentTime);

  const delayWetGain = ctx.createGain();
  delayWetGain.gain.setValueAtTime(fx.delayMix, ctx.currentTime);

  const delayOutput = ctx.createGain();

  distOutput.connect(delayOutput); // dry path
  distOutput.connect(delayNode);
  delayNode.connect(delayDamp);
  delayDamp.connect(delayFeedback);
  delayFeedback.connect(delayNode);
  delayDamp.connect(delayWetGain);
  delayWetGain.connect(delayOutput);

  // 4. Reverb
  const reverbConvolver = ctx.createConvolver();
  reverbConvolver.buffer = createImpulseResponse(ctx, fx.reverbDecay);

  const reverbWetGain = ctx.createGain();
  reverbWetGain.gain.setValueAtTime(fx.reverbMix, ctx.currentTime);

  const reverbOutput = ctx.createGain();

  delayOutput.connect(reverbOutput); // dry path
  delayOutput.connect(reverbConvolver);
  reverbConvolver.connect(reverbWetGain);
  reverbWetGain.connect(reverbOutput);

  // Output to Master Bus
  reverbOutput.connect(masterBus);

  return {
    inputNode,
    lowEq,
    midEq,
    highEq,
    distNode,
    distWetGain,
    distDryGain,
    delayNode,
    delayFeedback,
    delayWetGain,
    reverbConvolver,
    reverbWetGain,
  };
}
