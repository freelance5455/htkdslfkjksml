/**
 * DAVIENGINE Audio Subsystem
 * Pure Web Audio API Synthesizer & Spatial Audio Architecture
 * Fully compatible with Android 8+ browsers and desktop browsers without external asset dependencies.
 */

class AudioManager {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private isMuted: boolean = false;
  private masterVolume: number = 0.8;
  private musicVolume: number = 0.5;
  private sfxVolume: number = 0.8;
  private activeAmbientNode: OscillatorNode | null = null;

  private initContext() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.ctx = new AudioContextClass();
        this.masterGain = this.ctx.createGain();
        this.musicGain = this.ctx.createGain();
        this.sfxGain = this.ctx.createGain();

        this.masterGain.gain.setValueAtTime(this.masterVolume, this.ctx.currentTime);
        this.musicGain.gain.setValueAtTime(this.musicVolume, this.ctx.currentTime);
        this.sfxGain.gain.setValueAtTime(this.sfxVolume, this.ctx.currentTime);

        this.musicGain.connect(this.masterGain);
        this.sfxGain.connect(this.masterGain);
        this.masterGain.connect(this.ctx.destination);
      }
    }

    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setMasterVolume(v: number) {
    this.masterVolume = Math.max(0, Math.min(1, v));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(this.isMuted ? 0 : this.masterVolume, this.ctx.currentTime, 0.05);
    }
  }

  public getMasterVolume(): number {
    return this.masterVolume;
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(this.isMuted ? 0 : this.masterVolume, this.ctx.currentTime, 0.05);
    }
    return this.isMuted;
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  /**
   * Synthesizes dynamic game audio effects
   */
  public playSound(
    type: 'synth_laser' | 'synth_jump' | 'synth_engine' | 'synth_drone' | 'synth_bell' | 'click',
    options?: { pitch?: number; volume?: number; pan?: number }
  ) {
    try {
      this.initContext();
      if (!this.ctx || !this.sfxGain) return;

      const now = this.ctx.currentTime;
      const pitchMultiplier = options?.pitch || 1.0;
      const gainMult = options?.volume ?? 1.0;

      // Panner for spatial audio
      const panner = this.ctx.createStereoPanner ? this.ctx.createStereoPanner() : null;
      if (panner && options?.pan !== undefined) {
        panner.pan.setValueAtTime(Math.max(-1, Math.min(1, options.pan)), now);
      }

      const voiceGain = this.ctx.createGain();
      voiceGain.gain.setValueAtTime(gainMult, now);

      if (panner) {
        voiceGain.connect(panner);
        panner.connect(this.sfxGain);
      } else {
        voiceGain.connect(this.sfxGain);
      }

      if (type === 'click') {
        const osc = this.ctx.createOscillator();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800 * pitchMultiplier, now);
        osc.frequency.exponentialRampToValueAtTime(300, now + 0.04);
        voiceGain.gain.setValueAtTime(0.3 * gainMult, now);
        voiceGain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);
        osc.connect(voiceGain);
        osc.start(now);
        osc.stop(now + 0.04);
      } else if (type === 'synth_jump') {
        const osc = this.ctx.createOscillator();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(160 * pitchMultiplier, now);
        osc.frequency.exponentialRampToValueAtTime(540 * pitchMultiplier, now + 0.22);
        voiceGain.gain.setValueAtTime(0.5 * gainMult, now);
        voiceGain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
        osc.connect(voiceGain);
        osc.start(now);
        osc.stop(now + 0.25);
      } else if (type === 'synth_laser') {
        const osc = this.ctx.createOscillator();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(980 * pitchMultiplier, now);
        osc.frequency.exponentialRampToValueAtTime(60, now + 0.18);
        voiceGain.gain.setValueAtTime(0.4 * gainMult, now);
        voiceGain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
        osc.connect(voiceGain);
        osc.start(now);
        osc.stop(now + 0.2);
      } else if (type === 'synth_bell') {
        const osc1 = this.ctx.createOscillator();
        const osc2 = this.ctx.createOscillator();
        osc1.type = 'sine';
        osc2.type = 'sine';
        osc1.frequency.setValueAtTime(587 * pitchMultiplier, now);
        osc2.frequency.setValueAtTime(1174 * pitchMultiplier, now);
        voiceGain.gain.setValueAtTime(0.4 * gainMult, now);
        voiceGain.gain.exponentialRampToValueAtTime(0.001, now + 0.7);
        osc1.connect(voiceGain);
        osc2.connect(voiceGain);
        osc1.start(now);
        osc2.start(now);
        osc1.stop(now + 0.7);
        osc2.stop(now + 0.7);
      } else if (type === 'synth_engine') {
        const osc = this.ctx.createOscillator();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(55 * pitchMultiplier, now);
        osc.frequency.linearRampToValueAtTime(90 * pitchMultiplier, now + 0.3);
        voiceGain.gain.setValueAtTime(0.2 * gainMult, now);
        voiceGain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
        osc.connect(voiceGain);
        osc.start(now);
        osc.stop(now + 0.35);
      } else if (type === 'synth_drone') {
        const osc = this.ctx.createOscillator();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(110 * pitchMultiplier, now);
        voiceGain.gain.setValueAtTime(0.15 * gainMult, now);
        voiceGain.gain.exponentialRampToValueAtTime(0.001, now + 0.9);
        osc.connect(voiceGain);
        osc.start(now);
        osc.stop(now + 0.9);
      }
    } catch {
      // Audio autoplay policy handled smoothly
    }
  }
}

export const audioSystem = new AudioManager();
