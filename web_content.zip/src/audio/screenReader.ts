import { ScreenReaderVoiceId } from '../types/system';
import { soundEngine } from './soundEngine';

export interface ScreenReaderConfig {
  enabled: boolean;
  volume: number;
  masterVolume: number;
  voiceId: ScreenReaderVoiceId;
  rate: number;
  hintsEnabled: boolean;
}

const SYSTEM_VOICE_ID: ScreenReaderVoiceId = 'maya-us';

/**
 * Consistent System Screen Reader:
 * - Locked to one calm, soft-voiced US English African American female accessibility voice
 *   across Boot, Profile Selection, Home Screen, Settings, and every game/app.
 * - Bounded in-memory AudioBuffer cache + automatic rate-limit cooldown fallback
 *   so speech stays responsive with zero audio ducking leaks.
 */
class ConsoleScreenReader {
  private enabled = true;
  private volume = 0.9;
  private masterVolume = 0.85;
  private readonly voiceId: ScreenReaderVoiceId = SYSTEM_VOICE_ID;
  private rate = 1.0;
  private hintsEnabled = true;

  private audioCache = new Map<string, AudioBuffer>();
  private inFlightFetches = new Map<string, Promise<AudioBuffer | null>>();
  private readonly maxCache = 120;

  private activeSource: AudioBufferSourceNode | null = null;
  private debounceTimer: number | null = null;
  private duckingGuardTimer: number | null = null;
  private speakSeq = 0;
  private apiCooldownUntil = 0;

  public updateSettings(config: ScreenReaderConfig) {
    const turnedOff = this.enabled && !config.enabled;

    this.enabled = config.enabled;
    this.volume = Math.max(0, Math.min(1, config.volume));
    this.masterVolume = Math.max(0, Math.min(1, config.masterVolume));
    this.rate = Math.max(0.75, Math.min(1.35, config.rate || 1.0));
    this.hintsEnabled = config.hintsEnabled;

    if (this.enabled && typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.getVoices();
      } catch {
        // Ignore browser speech voice query errors
      }
    }

    if (this.activeSource) {
      try {
        this.activeSource.playbackRate.value = this.rate;
      } catch {
        // Ignore if source already finished
      }
    }

    if (turnedOff) {
      this.stop();
    }
  }

  public isEnabled(): boolean {
    return this.enabled;
  }

  public getVoiceId(): ScreenReaderVoiceId {
    return this.voiceId;
  }

  private clearDuckingGuard() {
    if (this.duckingGuardTimer !== null) {
      window.clearTimeout(this.duckingGuardTimer);
      this.duckingGuardTimer = null;
    }
  }

  private armDuckingGuard(durationMs: number, seq: number) {
    this.clearDuckingGuard();
    this.duckingGuardTimer = window.setTimeout(() => {
      if (seq === this.speakSeq) {
        soundEngine.setSpeechDucking(false);
      }
    }, Math.max(3500, durationMs));
  }

  public stop() {
    this.speakSeq++;
    this.clearDuckingGuard();

    if (this.debounceTimer !== null) {
      window.clearTimeout(this.debounceTimer);
      this.debounceTimer = null;
    }
    if (this.activeSource) {
      try {
        this.activeSource.onended = null;
        this.activeSource.stop();
        this.activeSource.disconnect();
      } catch {
        // Ignore already stopped source
      }
      this.activeSource = null;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {
        // Ignore speech synthesis cancellation errors
      }
    }
    soundEngine.setSpeechDucking(false);
  }

  private prepareText(rawText: string, overrideHints?: boolean): string {
    const trimmed = rawText.trim();
    if (!trimmed) return '';
    const allowHints = overrideHints ?? this.hintsEnabled;
    if (allowHints) return trimmed;

    const stripped = trimmed
      .replace(
        /\s*(Double-tap|Tap again|Swipe or tap|Tap Back|Press Enter|Select Visit|Select Go to|Tap to apply)[^.]*\.?/gi,
        ''
      )
      .replace(/\s{2,}/g, ' ')
      .trim();
    return stripped || trimmed;
  }

  private makeCacheKey(text: string): string {
    return `${this.voiceId}::${text}`;
  }

  public prefetch(_texts: string[], _targetVoiceId: ScreenReaderVoiceId = this.voiceId) {
    // Spoken clips cache automatically on first play without spending quota speculatively.
  }

  public speak(
    text: string,
    options?: { immediate?: boolean; bypassHints?: boolean; voiceId?: ScreenReaderVoiceId }
  ) {
    if (!this.enabled) return;
    const cleanText = this.prepareText(text, options?.bypassHints ? true : undefined);
    if (!cleanText) return;

    this.stop();
    const seq = this.speakSeq;
    const cacheKey = this.makeCacheKey(cleanText);

    const cached = this.getCachedBuffer(cacheKey);
    if (cached) {
      this.playBuffer(cached, seq);
      return;
    }

    const delayMs = options?.immediate === false ? 35 : 0;
    if (delayMs === 0) {
      void this.executeSpeak(cleanText, seq);
    } else {
      this.debounceTimer = window.setTimeout(() => {
        if (seq !== this.speakSeq || !this.enabled) return;
        void this.executeSpeak(cleanText, seq);
      }, delayMs);
    }
  }

  private getCachedBuffer(key: string): AudioBuffer | undefined {
    const hit = this.audioCache.get(key);
    if (!hit) return undefined;
    this.audioCache.delete(key);
    this.audioCache.set(key, hit);
    return hit;
  }

  private setCachedBuffer(key: string, buffer: AudioBuffer) {
    if (this.audioCache.size >= this.maxCache) {
      const oldestKey = this.audioCache.keys().next().value;
      if (oldestKey !== undefined) this.audioCache.delete(oldestKey);
    }
    this.audioCache.set(key, buffer);
  }

  private async fetchAndDecodeBuffer(text: string): Promise<AudioBuffer | null> {
    const cacheKey = this.makeCacheKey(text);
    const cached = this.getCachedBuffer(cacheKey);
    if (cached) return cached;

    if (Date.now() < this.apiCooldownUntil) {
      return null;
    }

    const existing = this.inFlightFetches.get(cacheKey);
    if (existing) return existing;

    const task = (async (): Promise<AudioBuffer | null> => {
      const controller = new AbortController();
      const timeoutId = window.setTimeout(() => controller.abort(), 5000);

      try {
        const response = await fetch('/api/tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text, voiceId: this.voiceId }),
          signal: controller.signal,
        });

        if (response.status === 429 || response.status === 503) {
          this.apiCooldownUntil = Date.now() + 5 * 60 * 1000;
          return null;
        }

        if (!response.ok) return null;

        const data = (await response.json()) as {
          audioBase64?: string;
          fallback?: boolean;
          rateLimited?: boolean;
        };

        if (data.rateLimited) {
          this.apiCooldownUntil = Date.now() + 5 * 60 * 1000;
          return null;
        }

        if (!data.audioBase64 || data.fallback) return null;

        const speechOut = soundEngine.getSpeechDestination();
        if (!speechOut) return null;

        const binary = atob(data.audioBase64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
          bytes[i] = binary.charCodeAt(i);
        }

        const audioBuffer = await speechOut.ctx.decodeAudioData(bytes.buffer.slice(0));
        this.setCachedBuffer(cacheKey, audioBuffer);
        return audioBuffer;
      } catch {
        return null;
      } finally {
        window.clearTimeout(timeoutId);
        this.inFlightFetches.delete(cacheKey);
      }
    })();

    this.inFlightFetches.set(cacheKey, task);
    return task;
  }

  private async executeSpeak(text: string, seq: number) {
    const audioBuffer = await this.fetchAndDecodeBuffer(text);

    if (seq !== this.speakSeq || !this.enabled) {
      return;
    }

    if (audioBuffer) {
      this.playBuffer(audioBuffer, seq);
    } else {
      this.speakWithBrowserVoice(text, seq);
    }
  }

  private playBuffer(buffer: AudioBuffer, seq: number) {
    if (seq !== this.speakSeq || !this.enabled) return;
    const speechOut = soundEngine.getSpeechDestination();
    if (!speechOut) return;

    const { ctx, destination } = speechOut;
    if (ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }

    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.playbackRate.value = this.rate;
    source.connect(destination);

    this.activeSource = source;
    soundEngine.setSpeechDucking(true);
    this.armDuckingGuard(((buffer.duration / this.rate) + 1) * 1000, seq);

    source.onended = () => {
      source.disconnect();
      if (this.activeSource === source) {
        this.activeSource = null;
        this.clearDuckingGuard();
        soundEngine.setSpeechDucking(false);
      }
    };

    try {
      source.start(0);
    } catch {
      source.disconnect();
      if (this.activeSource === source) {
        this.activeSource = null;
      }
      this.clearDuckingGuard();
      soundEngine.setSpeechDucking(false);
    }
  }

  private speakWithBrowserVoice(text: string, seq: number) {
    if (seq !== this.speakSeq || !this.enabled) return;
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    try {
      const synth = window.speechSynthesis;
      synth.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'en-US';
      utterance.rate = Math.max(0.75, Math.min(1.3, this.rate * 0.94));
      utterance.pitch = 0.93; // Soft, warm, calm US female vocal register
      utterance.volume = Math.max(0, Math.min(1, this.volume * this.masterVolume));

      const voices = synth.getVoices();
      const isMaleVoice = (name: string) =>
        /(male|david|mark|daniel|guy|ryan|aaron|alex|fred|george|davis|andrew|brian)/i.test(name);

      const preferred =
        voices.find(
          (v) =>
            /en[-_]us/i.test(v.lang) &&
            !isMaleVoice(v.name) &&
            /(ava|aria|jenny|michelle|samantha|victoria|joanna|kendra|kimberly|salli|ivy|zira|natural|google us english)/i.test(
              v.name
            )
        ) ??
        voices.find((v) => /en[-_]us/i.test(v.lang) && !isMaleVoice(v.name)) ??
        voices.find((v) => /en[-_]us/i.test(v.lang)) ??
        voices.find((v) => v.lang.startsWith('en') && !isMaleVoice(v.name)) ??
        voices.find((v) => v.lang.startsWith('en'));

      if (preferred) {
        utterance.voice = preferred;
      }

      soundEngine.setSpeechDucking(true);
      this.armDuckingGuard((text.length * 90) / this.rate + 1500, seq);

      utterance.onend = () => {
        if (seq === this.speakSeq) {
          this.clearDuckingGuard();
          soundEngine.setSpeechDucking(false);
        }
      };
      utterance.onerror = () => {
        if (seq === this.speakSeq) {
          this.clearDuckingGuard();
          soundEngine.setSpeechDucking(false);
        }
      };

      synth.speak(utterance);
    } catch {
      this.clearDuckingGuard();
      soundEngine.setSpeechDucking(false);
    }
  }
}

export const screenReader = new ConsoleScreenReader();
