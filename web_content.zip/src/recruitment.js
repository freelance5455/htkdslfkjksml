// Recherche de recrutement : uniquement les damistes déjà présents dans les effectifs officiels.
export function searchRecruitmentCandidates(state, { query = '', minLevel = 0, shortlistedOnly = false } = {}) {
  const ownClubId = state?.userClubId;
  const ownClub = (state?.divisions || []).flatMap(d => d.clubs || []).find(c => c.id === ownClubId);
  if (!ownClub) return [];
  const q = String(query).trim().toLocaleLowerCase('fr');
  const shortlist = new Set(state.recruitment?.shortlist || []);
  const galaxyNames = new Map((state.world?.galaxies || []).map(g => [g.id, g.name]));
  const candidates = [];
  for (const division of state.divisions || []) {
    for (const club of division.clubs || []) {
      if (club.id === ownClubId) continue;
      for (const player of club.damistes || []) {
        const level = Number(player.level) || 0;
        const galaxy = galaxyNames.get(player.originGalaxyId) || player.origin || 'Origine inconnue';
        const row = { id: player.id, name: player.name, clubId: club.id, clubName: club.name, divisionName: division.name, level, potential: Number(player.potential) || level, age: player.age ?? null, galaxy, shortlisted: shortlist.has(player.id) };
        const haystack = `${row.name} ${row.clubName} ${row.divisionName} ${row.galaxy}`.toLocaleLowerCase('fr');
        if (level < Math.max(0, Number(minLevel) || 0) || (q && !haystack.includes(q)) || (shortlistedOnly && !row.shortlisted)) continue;
        candidates.push(row);
      }
    }
  }
  return candidates.sort((a, b) => b.level - a.level || a.name.localeCompare(b.name, 'fr'));
}

export function addRecruitmentShortlistTarget(state, playerId) {
  const valid = (state?.divisions || []).flatMap(d => d.clubs || []).some(c => c.id !== state.userClubId && (c.damistes || []).some(p => p.id === playerId));
  if (!valid) throw new Error('Ce damiste ne fait pas partie des effectifs adverses disponibles.');
  state.recruitment ??= { shortlist: [] };
  state.recruitment.shortlist ??= [];
  if (!state.recruitment.shortlist.includes(playerId)) state.recruitment.shortlist.push(playerId);
  return state.recruitment.shortlist.length;
}

export function removeRecruitmentShortlistTarget(state, playerId) {
  if (!state?.recruitment) return 0;
  state.recruitment.shortlist = (state.recruitment.shortlist || []).filter(id => id !== playerId);
  return state.recruitment.shortlist.length;
}
