import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { AdminLayout } from './layouts/AdminLayout';
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { AdminLogin } from './pages/admin/AdminLogin';

/**
 * Dedicated Admin App Module
 * Strictly handles:
 *  - "/admin/login" -> Admin Login Portal
 *  - "/admin"       -> Protected Super Admin Dashboard
 * 
 * Preserves 100% of admin functionalities (User management, payment gateways,
 * subscription ledger, export source code, and security).
 */
export const AdminApp: React.FC = () => {
  return (
    <Routes>
      {/* Admin Login Route */}
      <Route path="login" element={<AdminLogin />} />

      {/* Admin Panel Protected Dashboard */}
      <Route element={<AdminLayout />}>
        <Route index element={<AdminDashboard />} />
      </Route>
    </Routes>
  );
};
