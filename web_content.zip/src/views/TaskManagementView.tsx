import React, { useState } from 'react';
import { 
  CheckSquare, 
  Search, 
  Plus, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Eye, 
  EyeOff, 
  User,
  Filter,
  Edit2,
  Trash2
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Task, TaskStatus, ProjectPriority } from '../types';

interface TaskManagementViewProps {
  onOpenNewTaskModal: (projectId?: string) => void;
  onEditTask: (task: Task) => void;
}

export const TaskManagementView: React.FC<TaskManagementViewProps> = ({
  onOpenNewTaskModal,
  onEditTask
}) => {
  const { 
    tasks, 
    projects, 
    users, 
    currentUser, 
    updateTaskStatus, 
    deleteTask,
    setSelectedProjectId,
    setActiveView 
  } = useApp();

  const [statusFilter, setStatusFilter] = useState<'All' | TaskStatus>('All');
  const [selectedProjectId, setLocalSelectedProjectId] = useState<string>('All');
  const [selectedAssigneeId, setSelectedAssigneeId] = useState<string>(
    currentUser.role === 'Employee' ? currentUser.id : 'All'
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [taskToDelete, setTaskToDelete] = useState<Task | null>(null);

  const filteredTasks = tasks.filter(t => {
    const matchesStatus = statusFilter === 'All' || t.status === statusFilter;
    const matchesProject = selectedProjectId === 'All' || t.projectId === selectedProjectId;
    const matchesAssignee = selectedAssigneeId === 'All' || t.assignedToEmployeeId === selectedAssigneeId;
    const matchesSearch = 
      t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.projectReference.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.assignedToName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.remarks.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesProject && matchesAssignee && matchesSearch;
  });

  const overdueCount = tasks.filter(t => t.status === 'Overdue').length;

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Engineering Task Manager</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Site commissioning assignments, sensor wiring loops, pressure checks, and statutory milestones.
          </p>
        </div>

        <button
          onClick={() => onOpenNewTaskModal()}
          className="px-4 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg cursor-pointer shadow-xs transition-colors flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Assign New Task</span>
        </button>
      </div>

      {/* Filter and Status Controls */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          {/* Status Tabs */}
          <div className="overflow-x-auto no-scrollbar pb-1 sm:pb-0 -mx-1 px-1">
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg w-max sm:w-auto">
              {(['All', 'To Do', 'In Progress', 'Completed', 'Overdue'] as const).map(tab => {
                const count = tab === 'All' 
                  ? tasks.length 
                  : tasks.filter(t => t.status === tab).length;
                const isActive = statusFilter === tab;

                return (
                  <button
                    key={tab}
                    type="button"
                    onClick={() => setStatusFilter(tab)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
                      isActive 
                        ? 'bg-white text-slate-900 shadow-xs font-semibold' 
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <span>{tab}</span>
                    <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full ${
                      tab === 'Overdue' && count > 0 
                        ? 'bg-red-100 text-red-700 font-bold' 
                        : 'bg-slate-200/70 text-slate-600'
                    }`}>
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Project & Assignee Dropdowns */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full sm:w-auto">
            <select
              value={selectedProjectId}
              onChange={(e) => setLocalSelectedProjectId(e.target.value)}
              className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 cursor-pointer w-full sm:max-w-[180px] truncate"
            >
              <option value="All">All Projects</option>
              {projects.map(p => (
                <option key={p.id} value={p.id}>{p.reference} - {p.name.substring(0, 24)}...</option>
              ))}
            </select>

            <select
              value={selectedAssigneeId}
              onChange={(e) => setSelectedAssigneeId(e.target.value)}
              className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 cursor-pointer w-full sm:w-auto"
            >
              <option value="All">All Assignees</option>
              {users.filter(u => u.role === 'Employee' || u.role === 'Admin').map(u => (
                <option key={u.id} value={u.id}>{u.name}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search tasks by title, remarks, assignee..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:border-red-500"
          />
        </div>
      </div>

      {/* Tasks Table & Mobile Cards */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Mobile Task Cards List */}
        <div className="md:hidden divide-y divide-slate-100">
          {filteredTasks.length === 0 ? (
            <div className="py-10 text-center text-slate-500 text-xs">
              No tasks match the active filters.
            </div>
          ) : (
            filteredTasks.map(task => (
              <div key={task.id} className="p-4 space-y-3 hover:bg-slate-50/70 transition-colors">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-semibold text-slate-900 text-xs leading-snug">{task.title}</p>
                    <button
                      onClick={() => {
                        setSelectedProjectId(task.projectId);
                        setActiveView('project-detail');
                      }}
                      className="font-mono text-red-600 text-[11px] font-semibold hover:underline block mt-0.5"
                    >
                      {task.projectReference}
                    </button>
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded font-semibold shrink-0 ${
                    task.priority === 'Critical'
                      ? 'bg-red-100 text-red-800 font-bold'
                      : task.priority === 'High'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-slate-100 text-slate-700'
                  }`}>
                    {task.priority}
                  </span>
                </div>

                {task.remarks && (
                  <p className="text-[11px] text-slate-500 italic bg-slate-50 p-2 rounded border border-slate-100">
                    Note: {task.remarks}
                  </p>
                )}

                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span>Assigned: <strong className="text-slate-800">{task.assignedToName}</strong></span>
                  <span className="font-mono">Due: {task.deadline}</span>
                </div>

                <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-100">
                  <div className="flex items-center gap-2">
                    <select
                      value={task.status}
                      onChange={(e) => updateTaskStatus(task.id, e.target.value as TaskStatus)}
                      className={`text-[11px] px-2 py-1 rounded font-semibold border cursor-pointer ${
                        task.status === 'Completed'
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          : task.status === 'Overdue'
                          ? 'bg-red-50 text-red-800 border-red-200'
                          : task.status === 'In Progress'
                          ? 'bg-blue-50 text-blue-800 border-blue-200'
                          : 'bg-slate-100 text-slate-700 border-slate-200'
                      }`}
                    >
                      <option value="To Do">To Do</option>
                      <option value="In Progress">In Progress</option>
                      <option value="Completed">Completed</option>
                      <option value="Overdue">Overdue</option>
                    </select>

                    {task.visibleToClient ? (
                      <span className="text-[10px] text-emerald-700 flex items-center gap-1 font-medium bg-emerald-50 px-1.5 py-0.5 rounded">
                        <Eye className="w-3 h-3 text-emerald-600" />
                        <span>Client</span>
                      </span>
                    ) : (
                      <span className="text-[10px] text-slate-400 flex items-center gap-1 bg-slate-100 px-1.5 py-0.5 rounded">
                        <EyeOff className="w-3 h-3" />
                        <span>Internal</span>
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => onEditTask(task)}
                      className="px-2 py-1 text-xs text-blue-600 hover:bg-blue-50 rounded font-medium"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => setTaskToDelete(task)}
                      className="px-2 py-1 text-xs text-red-600 hover:bg-red-50 rounded font-medium"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Desktop Tasks Table */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Task Details</th>
                <th className="py-3 px-4">Project</th>
                <th className="py-3 px-4">Assigned To</th>
                <th className="py-3 px-4">Priority</th>
                <th className="py-3 px-4">Deadline</th>
                <th className="py-3 px-4">Status & Quick Toggle</th>
                <th className="py-3 px-4">Client Visibility</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTasks.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-10 text-center text-slate-500 text-xs">
                    No tasks match the active filters.
                  </td>
                </tr>
              ) : (
                filteredTasks.map(task => {
                  return (
                    <tr key={task.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 px-4 max-w-sm">
                        <p className="font-semibold text-slate-900 leading-snug">{task.title}</p>
                        {task.remarks && (
                          <p className="text-[11px] text-slate-500 mt-0.5 italic truncate">
                            Note: {task.remarks}
                          </p>
                        )}
                      </td>
                      <td className="py-3.5 px-4">
                        <button
                          onClick={() => {
                            setSelectedProjectId(task.projectId);
                            setActiveView('project-detail');
                          }}
                          className="font-mono text-red-600 hover:underline font-semibold cursor-pointer"
                        >
                          {task.projectReference}
                        </button>
                      </td>
                      <td className="py-3.5 px-4 text-slate-700 font-medium">
                        {task.assignedToName}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`font-semibold ${
                          task.priority === 'Critical'
                            ? 'text-red-700'
                            : task.priority === 'High'
                            ? 'text-amber-700'
                            : 'text-slate-600'
                        }`}>
                          {task.priority}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 font-mono tabular-nums text-slate-700">
                        {task.deadline}
                      </td>
                      <td className="py-3.5 px-4">
                        {/* Quick Status Dropdown */}
                        <select
                          value={task.status}
                          onChange={(e) => updateTaskStatus(task.id, e.target.value as TaskStatus)}
                          className={`text-xs px-2 py-1 rounded font-semibold border cursor-pointer ${
                            task.status === 'Completed'
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                              : task.status === 'Overdue'
                              ? 'bg-red-50 text-red-800 border-red-200'
                              : task.status === 'In Progress'
                              ? 'bg-blue-50 text-blue-800 border-blue-200'
                              : 'bg-slate-100 text-slate-700 border-slate-200'
                          }`}
                        >
                          <option value="To Do">To Do</option>
                          <option value="In Progress">In Progress</option>
                          <option value="Completed">Completed</option>
                          <option value="Overdue">Overdue</option>
                        </select>
                      </td>
                      <td className="py-3.5 px-4">
                        {task.visibleToClient ? (
                          <span className="text-slate-600 text-[11px] flex items-center gap-1 font-medium">
                            <Eye className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Client Visible</span>
                          </span>
                        ) : (
                          <span className="text-slate-400 text-[11px] flex items-center gap-1">
                            <EyeOff className="w-3.5 h-3.5" />
                            <span>Internal</span>
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => onEditTask(task)}
                            className="px-2 py-1 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded font-medium cursor-pointer"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => setTaskToDelete(task)}
                            className="px-2 py-1 text-red-600 hover:text-red-800 hover:bg-red-50 rounded font-medium cursor-pointer"
                          >
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {taskToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-md p-6">
            <h3 className="text-base font-bold text-slate-900">Delete Task</h3>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Are you sure you want to delete task <strong className="text-slate-900">"{taskToDelete.title}"</strong>?
            </p>

            <div className="mt-6 flex items-center justify-end gap-3">
              <button
                onClick={() => setTaskToDelete(null)}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  deleteTask(taskToDelete.id);
                  setTaskToDelete(null);
                }}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-xs transition-colors"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
