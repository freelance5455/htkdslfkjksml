import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { RequestStatus, PatientRequest, ServiceType } from '../types';
import { translations } from '../data/translations';
import { 
  LayoutDashboard, 
  Users, 
  Building2, 
  Stethoscope, 
  FileCheck, 
  Plane, 
  Languages, 
  Receipt, 
  BarChart3, 
  Search, 
  Filter, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Eye, 
  Edit3, 
  X, 
  Plus, 
  ShieldCheck, 
  Lock, 
  LogOut, 
  RefreshCw,
  TrendingUp,
  Download,
  DollarSign,
  Activity,
  Crown,
  Sparkles
} from 'lucide-react';

type AdminTab = 
  | 'overview' 
  | 'requests' 
  | 'hospitals' 
  | 'doctors' 
  | 'compliance' 
  | 'logistics' 
  | 'translators' 
  | 'invoices' 
  | 'reports';

export const AdminDashboardView: React.FC = () => {
  const { 
    language, 
    setCurrentView, 
    requests, 
    updateRequestStatus, 
    medicalCenters, 
    doctors, 
    translators, 
    invoices,
    resetDemoData,
    showToast,
    isAdminLoggedIn,
    demoAdminLogout
  } = useApp();

  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterService, setFilterService] = useState<string>('all');
  const [selectedRequestForDetail, setSelectedRequestForDetail] = useState<PatientRequest | null>(null);
  const [statusChangeValue, setStatusChangeValue] = useState<RequestStatus>('new');
  const [coordinatorNoteInput, setCoordinatorNoteInput] = useState('');
  const [assignedDoctorInput, setAssignedDoctorInput] = useState('');
  const [assignedHospitalInput, setAssignedHospitalInput] = useState('');

  const t = translations[language];
  const isAr = language === 'ar';

  // Stats Calculations
  const totalRequests = requests.length;
  const newRequests = requests.filter(r => r.status === 'new').length;
  const underReviewRequests = requests.filter(r => r.status === 'under_review' || r.status === 'coordinating').length;
  const completedRequests = requests.filter(r => r.status === 'completed' || r.status === 'confirmed').length;
  const totalRevenueUsd = invoices.reduce((acc, curr) => curr.status === 'paid' ? acc + curr.amountUsd : acc, 0);

  // Filtered Requests
  const filteredRequests = requests.filter(req => {
    const matchesSearch = 
      req.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      req.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      req.country.toLowerCase().includes(searchQuery.toLowerCase()) ||
      req.specialtyOrNeed.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = filterStatus === 'all' || req.status === filterStatus;
    const matchesService = filterService === 'all' || req.serviceType === filterService;

    return matchesSearch && matchesStatus && matchesService;
  });

  const handleOpenDetailModal = (req: PatientRequest) => {
    setSelectedRequestForDetail(req);
    setStatusChangeValue(req.status);
    setCoordinatorNoteInput(req.coordinatorNotes || '');
    setAssignedDoctorInput(req.assignedDoctor || '');
    setAssignedHospitalInput(req.assignedHospital || '');
  };

  const handleSaveStatusUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRequestForDetail) return;

    updateRequestStatus(
      selectedRequestForDetail.id, 
      statusChangeValue, 
      coordinatorNoteInput.trim() || undefined
    );

    // Update in-place for active modal
    setSelectedRequestForDetail({
      ...selectedRequestForDetail,
      status: statusChangeValue,
      coordinatorNotes: coordinatorNoteInput,
      assignedDoctor: assignedDoctorInput || selectedRequestForDetail.assignedDoctor,
      assignedHospital: assignedHospitalInput || selectedRequestForDetail.assignedHospital,
    });

    showToast(isAr ? `تم تحديث الطلب ${selectedRequestForDetail.id} بنجاح` : `Updated request ${selectedRequestForDetail.id}`);
  };

  const tabs: { id: AdminTab; labelAr: string; labelEn: string; icon: React.ReactNode; count?: number }[] = [
    { id: 'overview', labelAr: 'لوحة الإحصائيات العامة', labelEn: 'Overview & KPIs', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'requests', labelAr: 'إدارة الطلبات والمرضى', labelEn: 'Patient Requests', icon: <Users className="w-4 h-4" />, count: requests.length },
    { id: 'hospitals', labelAr: 'المستشفيات والمراكز', labelEn: 'Hospitals & Hubs', icon: <Building2 className="w-4 h-4" />, count: medicalCenters.length },
    { id: 'doctors', labelAr: 'الأطباء والاستشاريون', labelEn: 'Consultant Roster', icon: <Stethoscope className="w-4 h-4" />, count: doctors.length },
    { id: 'compliance', labelAr: 'مراجعة التراخيص والاعتمادات', labelEn: 'Accreditation Audit', icon: <FileCheck className="w-4 h-4" /> },
    { id: 'logistics', labelAr: 'حجوزات السفر والاستقبال', labelEn: 'Travel & Reception', icon: <Plane className="w-4 h-4" /> },
    { id: 'translators', labelAr: 'المترجمون والمرافقون', labelEn: 'Interpreters & Escorts', icon: <Languages className="w-4 h-4" />, count: translators.length },
    { id: 'invoices', labelAr: 'الفواتير والمالية التجريبية', labelEn: 'Demo Invoices & Fees', icon: <Receipt className="w-4 h-4" />, count: invoices.length },
    { id: 'reports', labelAr: 'تقارير الأداء ومؤشرات النمو', labelEn: 'Performance Analytics', icon: <BarChart3 className="w-4 h-4" /> },
  ];

  const getStatusBadge = (status: RequestStatus) => {
    switch (status) {
      case 'new':
        return <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold px-2.5 py-0.5 rounded-full text-xs">{isAr ? 'جديد' : 'New'}</span>;
      case 'under_review':
        return <span className="bg-yellow-500/20 text-yellow-300 border border-yellow-500/40 font-bold px-2.5 py-0.5 rounded-full text-xs">{isAr ? 'قيد المراجعة' : 'Under Review'}</span>;
      case 'coordinating':
        return <span className="bg-zinc-800 text-amber-200 border border-[#D4AF37]/50 font-bold px-2.5 py-0.5 rounded-full text-xs">{isAr ? 'جاري التنسيق' : 'Coordinating'}</span>;
      case 'confirmed':
        return <span className="bg-[#D4AF37]/30 text-amber-100 border border-[#D4AF37] font-bold px-2.5 py-0.5 rounded-full text-xs">{isAr ? 'تم التأكيد' : 'Confirmed'}</span>;
      case 'completed':
        return <span className="bg-amber-400 text-black font-extrabold px-2.5 py-0.5 rounded-full text-xs">{isAr ? 'مكتمل' : 'Completed'}</span>;
      case 'cancelled':
        return <span className="bg-zinc-900 text-zinc-500 border border-zinc-700 font-bold px-2.5 py-0.5 rounded-full text-xs">{isAr ? 'ملغى' : 'Cancelled'}</span>;
    }
  };

  return (
    <div className="bg-black min-h-screen text-zinc-100 pb-16">
      
      {/* Top Header of Admin Dashboard in Black & Gold */}
      <div className="bg-zinc-950 text-white border-b border-[#D4AF37]/30 py-4 px-4 sm:px-8 shadow-xl">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img 
              src="/assets/aistudio/logo_transparent.png" 
              alt="Logo" 
              className="h-12 w-auto object-contain drop-shadow-[0_2px_10px_rgba(212,175,55,0.4)]"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-black bg-gradient-to-r from-white via-zinc-100 to-amber-200 bg-clip-text text-transparent">
                  {t.adminDashboardTitle}
                </h1>
                <span className="text-[10px] bg-[#D4AF37]/20 text-amber-300 border border-[#D4AF37]/40 px-2 py-0.5 rounded-full font-mono font-bold">
                  GOLD EDITION
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                {t.adminDashboardSubtitle}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 bg-black px-3 py-1.5 rounded-xl border border-zinc-800 text-xs">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
              <span className="text-amber-200">{isAr ? 'المشرف: د. طه كامل (تنسيق طبي)' : 'Supervisor: Dr. Taha Kamel'}</span>
            </div>

            <button
              onClick={() => setCurrentView('home')}
              className="bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-extrabold px-3.5 py-1.5 rounded-xl text-xs transition-all shadow-md flex items-center gap-1.5"
            >
              <span>{isAr ? 'عرض الموقع كـ مريض' : 'Switch to Patient View'}</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        
        {/* Navigation Tabs Bar in Black & Gold */}
        <div className="bg-zinc-950 p-2 rounded-2xl border border-[#D4AF37]/30 shadow-md mb-6 overflow-x-auto">
          <div className="flex gap-1.5 min-w-max">
            {tabs.map(tab => {
              const active = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
                    active
                      ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-black font-black shadow-md'
                      : 'text-zinc-400 hover:bg-zinc-900 hover:text-amber-300'
                  }`}
                >
                  {tab.icon}
                  <span>{isAr ? tab.labelAr : tab.labelEn}</span>
                  {tab.count !== undefined && (
                    <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-mono ${
                      active ? 'bg-black text-amber-300 font-bold' : 'bg-zinc-900 text-zinc-400 border border-zinc-800'
                    }`}>
                      {tab.count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* TAB 1: OVERVIEW & KPIS */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            
            {/* KPI Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              
              <div className="bg-zinc-950 p-6 rounded-3xl border border-[#D4AF37]/30 shadow-xl space-y-2">
                <div className="flex items-center justify-between text-xs text-zinc-400">
                  <span>{isAr ? 'إجمالي الطلبات التجريبية' : 'Total Demo Requests'}</span>
                  <Users className="w-4 h-4 text-amber-400" />
                </div>
                <div className="text-3xl font-black text-white font-mono">
                  {totalRequests}
                </div>
                <div className="flex items-center gap-1 text-[11px] text-amber-400 font-semibold">
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>{isAr ? '+3 طلبات مسجلة اليوم' : '+3 submitted today'}</span>
                </div>
              </div>

              <div className="bg-zinc-950 p-6 rounded-3xl border border-[#D4AF37]/30 shadow-xl space-y-2">
                <div className="flex items-center justify-between text-xs text-zinc-400">
                  <span>{isAr ? 'طلبات جديدة (انتظار)' : 'New Inquiries'}</span>
                  <Clock className="w-4 h-4 text-amber-300" />
                </div>
                <div className="text-3xl font-black text-amber-400 font-mono">
                  {newRequests}
                </div>
                <div className="text-[11px] text-zinc-500">
                  {isAr ? 'تتطلب دراسة وتوجيه للمستشفى' : 'Awaiting clinical triage'}
                </div>
              </div>

              <div className="bg-zinc-950 p-6 rounded-3xl border border-[#D4AF37]/30 shadow-xl space-y-2">
                <div className="flex items-center justify-between text-xs text-zinc-400">
                  <span>{isAr ? 'قيد التنسيق والمراجعة' : 'Under Coordination'}</span>
                  <Activity className="w-4 h-4 text-yellow-400" />
                </div>
                <div className="text-3xl font-black text-yellow-400 font-mono">
                  {underReviewRequests}
                </div>
                <div className="text-[11px] text-zinc-500">
                  {isAr ? 'جاري تجهيز المواعيد والتأشيرات' : 'Appointments & visas pending'}
                </div>
              </div>

              <div className="bg-zinc-950 p-6 rounded-3xl border border-[#D4AF37]/30 shadow-xl space-y-2">
                <div className="flex items-center justify-between text-xs text-zinc-400">
                  <span>{isAr ? 'الإيرادات التجريبية المحصلة' : 'Demo Collected Revenue'}</span>
                  <DollarSign className="w-4 h-4 text-[#D4AF37]" />
                </div>
                <div className="text-3xl font-black text-amber-300 font-mono">
                  ${totalRevenueUsd.toLocaleString()}
                </div>
                <div className="text-[11px] text-zinc-500">
                  {isAr ? 'مستندة لفواتير الخدمات التجريبية' : 'Based on demo package invoices'}
                </div>
              </div>

            </div>

            {/* Quick Actions & Recent Incoming Stream */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Recent Requests Stream */}
              <div className="lg:col-span-8 bg-zinc-950 p-6 rounded-3xl border border-[#D4AF37]/30 shadow-xl space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-zinc-900">
                  <div>
                    <h3 className="font-bold text-white text-base">
                      {isAr ? 'أحدث الطلبات الواردة للمنصة' : 'Recent Patient Coordination Requests'}
                    </h3>
                    <p className="text-xs text-zinc-400">
                      {isAr ? 'يمكنك النقر على أي طلب لتحديث حالته وتجربة السيناريو' : 'Click on any request to view details and update workflow status'}
                    </p>
                  </div>
                  <button
                    onClick={() => setActiveTab('requests')}
                    className="text-xs font-bold text-amber-400 hover:underline"
                  >
                    {isAr ? 'عرض الكل ←' : 'View all →'}
                  </button>
                </div>

                <div className="space-y-3">
                  {requests.slice(0, 5).map(req => (
                    <div
                      key={req.id}
                      onClick={() => handleOpenDetailModal(req)}
                      className="p-3.5 rounded-2xl border border-zinc-900 bg-black/80 hover:border-[#D4AF37]/60 hover:bg-black transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-zinc-900 text-amber-300 font-bold flex items-center justify-center text-xs font-mono group-hover:bg-[#D4AF37] group-hover:text-black transition-colors border border-zinc-800">
                          {req.id.split('-')[2]}
                        </div>
                        <div>
                          <div className="font-bold text-xs sm:text-sm text-zinc-100 group-hover:text-amber-300">
                            {req.patientName}
                          </div>
                          <div className="text-xs text-zinc-400 flex items-center gap-2 mt-0.5">
                            <span>{req.country}</span>
                            <span>•</span>
                            <span className="text-amber-300 font-medium truncate max-w-xs">{req.specialtyOrNeed}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 self-end sm:self-center">
                        <span className="text-[11px] text-zinc-500 font-mono hidden md:inline">
                          {req.createdAt.split(' ')[0]}
                        </span>
                        {getStatusBadge(req.status)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* System Compliance & Facilities Summary */}
              <div className="lg:col-span-4 space-y-6">
                <div className="bg-black text-white p-6 rounded-3xl border border-[#D4AF37]/40 shadow-2xl space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-sm text-amber-200">
                      {isAr ? 'جاهزية شبكة الشركاء' : 'Partner Network Readiness'}
                    </h3>
                    <Crown className="w-5 h-5 text-[#D4AF37]" />
                  </div>

                  <div className="space-y-3 text-xs">
                    <div className="flex justify-between pb-2 border-b border-zinc-900">
                      <span className="text-zinc-400">{isAr ? 'المستشفيات المعتمدة:' : 'Hospitals:'}</span>
                      <span className="font-bold font-mono text-amber-300">{medicalCenters.length} صروح كبرى</span>
                    </div>
                    <div className="flex justify-between pb-2 border-b border-zinc-900">
                      <span className="text-zinc-400">{isAr ? 'الاستشاريون المسجلون:' : 'Active Consultants:'}</span>
                      <span className="font-bold font-mono text-amber-300">{doctors.length} أساتذة</span>
                    </div>
                    <div className="flex justify-between pb-2 border-b border-zinc-900">
                      <span className="text-zinc-400">{isAr ? 'مترجمون جاهزون:' : 'Interpreters Ready:'}</span>
                      <span className="font-bold font-mono text-amber-300">{translators.filter(t => t.status === 'available').length} متاح فوراً</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-400">{isAr ? 'حالة التراخيص والامتثال:' : 'Compliance Status:'}</span>
                      <span className="font-bold text-amber-400">100% موثقة</span>
                    </div>
                  </div>

                  <button
                    onClick={() => setActiveTab('compliance')}
                    className="w-full py-2.5 bg-zinc-900 hover:bg-zinc-800 text-amber-200 border border-[#D4AF37]/30 rounded-xl text-xs font-bold transition-colors"
                  >
                    {isAr ? 'فحص ملفات الامتثال والتراخيص' : 'View Compliance Files'}
                  </button>
                </div>

                {/* Quick Add Demo Request Button for Investor Demo */}
                <div className="bg-zinc-950 border border-[#D4AF37]/30 p-5 rounded-3xl text-zinc-300 space-y-2">
                  <h4 className="font-bold text-xs text-amber-300 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>{isAr ? 'تجربة دورة العمل كـ مستثمر:' : 'Investor Interactive Walkthrough:'}</span>
                  </h4>
                  <p className="text-[11px] leading-relaxed text-zinc-400">
                    {isAr
                      ? 'يمكنك الانتقال لنموذج الطلب وإرسال حالة باسمك، ثم العودة هنا لمشاهدتها تظهر بالثواني مع إمكانية اعتمادها.'
                      : 'You can switch to the front request form, enter a sample case, and watch it show up here instantaneously.'}
                  </p>
                  <button
                    onClick={() => setCurrentView('request-form')}
                    className="text-xs font-bold text-black bg-gradient-to-r from-amber-400 to-amber-500 px-3 py-1.5 rounded-lg transition-all shadow-sm"
                  >
                    {isAr ? 'فتح نموذج الطلب الآن ←' : 'Open Request Form →'}
                  </button>
                </div>
              </div>

            </div>

          </div>
        )}

        {/* TAB 2: REQUESTS MANAGEMENT TABLE */}
        {activeTab === 'requests' && (
          <div className="bg-zinc-950 rounded-3xl border border-[#D4AF37]/30 p-6 shadow-xl space-y-6">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-black bg-gradient-to-r from-white to-amber-200 bg-clip-text text-transparent">
                  {isAr ? 'جدول طلبات التنسيق والمرضى' : 'Patient Requests Roster'}
                </h2>
                <p className="text-xs text-zinc-400 mt-0.5">
                  {isAr ? 'تحكم كامل في مراجعة وتعديل حالات الطلبات والمستشفيات المسندة' : 'Full control over status updating, clinical triage, and hospital assignment'}
                </p>
              </div>

              <button
                onClick={() => setCurrentView('request-form')}
                className="bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black text-xs font-black px-4 py-2.5 rounded-xl transition-all flex items-center gap-1.5 self-start sm:self-auto shadow-md"
              >
                <Plus className="w-4 h-4 text-black" />
                <span>{isAr ? 'إضافة طلب جديد' : 'New Request'}</span>
              </button>
            </div>

            {/* Search & Filter Toolbar in Black & Gold */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="relative">
                <Search className="w-4 h-4 text-amber-400 absolute right-3 rtl:right-3 rtl:left-auto ltr:left-3 ltr:right-auto top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={isAr ? 'بحث بالاسم، الكود، الدولة...' : 'Search by name, ID, country...'}
                  className="w-full text-xs px-9 py-2.5 rounded-xl bg-black border border-zinc-800 text-white focus:outline-hidden focus:border-[#D4AF37]"
                />
              </div>

              <div>
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl bg-black border border-zinc-800 text-white focus:outline-hidden focus:border-[#D4AF37]"
                >
                  <option value="all">{isAr ? 'جميع الحالات' : 'All Statuses'}</option>
                  <option value="new">{isAr ? 'جديد (New)' : 'New'}</option>
                  <option value="under_review">{isAr ? 'قيد المراجعة (Under Review)' : 'Under Review'}</option>
                  <option value="coordinating">{isAr ? 'جاري التنسيق (Coordinating)' : 'Coordinating'}</option>
                  <option value="confirmed">{isAr ? 'تم التأكيد (Confirmed)' : 'Confirmed'}</option>
                  <option value="completed">{isAr ? 'مكتمل (Completed)' : 'Completed'}</option>
                </select>
              </div>

              <div>
                <select
                  value={filterService}
                  onChange={(e) => setFilterService(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl bg-black border border-zinc-800 text-white focus:outline-hidden focus:border-[#D4AF37]"
                >
                  <option value="all">{isAr ? 'جميع قطاعات الخدمة' : 'All Service Pillars'}</option>
                  <option value="medical_sector">{isAr ? 'القطاع الطبي الشامل' : 'Medical Sector'}</option>
                  <option value="addiction_rehab">{isAr ? 'علاج الإدمان والتأهيل' : 'Addiction Rehab'}</option>
                  <option value="medical_tourism">{isAr ? 'السياحة العلاجية' : 'Medical Tourism'}</option>
                  <option value="foreign_reception">{isAr ? 'استقبال المرضى الأجانب' : 'Foreign Reception'}</option>
                  <option value="international_services">{isAr ? 'الخدمات الدولية' : 'International Services'}</option>
                </select>
              </div>
            </div>

            {/* Interactive Data Table in Black & Gold */}
            <div className="overflow-x-auto rounded-2xl border border-zinc-800">
              <table className="w-full text-start text-xs">
                <thead className="bg-black border-b border-zinc-800 text-amber-300 font-bold uppercase text-[10px] tracking-wider">
                  <tr>
                    <th className="p-3.5 text-start">{isAr ? 'رقم الطلب' : 'Request ID'}</th>
                    <th className="p-3.5 text-start">{isAr ? 'اسم المريض' : 'Patient Name'}</th>
                    <th className="p-3.5 text-start">{isAr ? 'الدولة' : 'Country'}</th>
                    <th className="p-3.5 text-start">{isAr ? 'الخدمة / التخصص' : 'Service / Specialty'}</th>
                    <th className="p-3.5 text-start">{isAr ? 'الجهة المسندة' : 'Assigned Provider'}</th>
                    <th className="p-3.5 text-start">{isAr ? 'الحالة' : 'Status'}</th>
                    <th className="p-3.5 text-center">{isAr ? 'إجراءات' : 'Actions'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-900">
                  {filteredRequests.length > 0 ? (
                    filteredRequests.map(req => (
                      <tr key={req.id} className="hover:bg-zinc-900/60 transition-colors">
                        <td className="p-3.5 font-mono font-bold text-amber-400">
                          {req.id}
                        </td>
                        <td className="p-3.5 font-bold text-white">
                          {req.patientName}
                          <div className="text-[11px] font-normal text-zinc-500 font-mono">
                            {req.phone}
                          </div>
                        </td>
                        <td className="p-3.5 text-zinc-300">
                          {req.country}
                        </td>
                        <td className="p-3.5 text-zinc-300 max-w-xs truncate">
                          {req.specialtyOrNeed}
                        </td>
                        <td className="p-3.5 text-zinc-400 text-[11px]">
                          {req.assignedHospital || (isAr ? 'بانتظار التسكين' : 'Pending Allocation')}
                        </td>
                        <td className="p-3.5">
                          {getStatusBadge(req.status)}
                        </td>
                        <td className="p-3.5 text-center">
                          <button
                            onClick={() => handleOpenDetailModal(req)}
                            className="px-3 py-1 bg-black hover:bg-amber-400 hover:text-black border border-zinc-800 hover:border-amber-400 rounded-lg text-xs font-semibold text-amber-300 transition-all inline-flex items-center gap-1"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>{isAr ? 'تعديل/عرض' : 'Edit'}</span>
                          </button>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={7} className="p-8 text-center text-zinc-500 text-xs">
                        {isAr ? 'لا توجد نتائج مطابقة لمعايير البحث' : 'No matching records found'}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

          </div>
        )}

        {/* TAB 3: HOSPITALS & CENTERS */}
        {activeTab === 'hospitals' && (
          <div className="bg-zinc-950 rounded-3xl border border-[#D4AF37]/30 p-6 shadow-xl space-y-6">
            <div>
              <h2 className="text-xl font-black text-white">
                {isAr ? 'إدارة المستشفيات والمراكز المعتمدة' : 'Accredited Hospitals & Centers Management'}
              </h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                {isAr ? 'قاعدة بيانات المنشآت الطبية الموثقة وتراخيصها وسعتها السريرية' : 'Directory of verified healthcare partners, bed capacity, and accreditation'}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {medicalCenters.map(center => (
                <div key={center.id} className="p-5 rounded-2xl border border-zinc-800 bg-black space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-bold text-white text-sm">
                        {isAr ? center.nameAr : center.nameEn}
                      </h3>
                      <div className="text-xs text-zinc-400">{center.city} • {center.categoryAr}</div>
                    </div>
                    <span className="text-[10px] bg-[#D4AF37]/20 text-amber-300 border border-[#D4AF37]/40 font-bold px-2 py-0.5 rounded-full">
                      {isAr ? 'معتمد رسمياً' : 'Verified'}
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-1 text-[10px]">
                    {center.accreditation.map((acc, idx) => (
                      <span key={idx} className="bg-zinc-900 border border-zinc-800 text-amber-200 px-2 py-0.5 rounded">
                        {acc}
                      </span>
                    ))}
                  </div>

                  <div className="text-xs text-zinc-400">
                    <strong className="text-zinc-200">{isAr ? 'السعة السريرية:' : 'Beds:'}</strong> {center.bedCapacity} سرير • <strong className="text-zinc-200">{isAr ? 'التقييم:' : 'Rating:'}</strong> ★ {center.rating}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: DOCTORS */}
        {activeTab === 'doctors' && (
          <div className="bg-zinc-950 rounded-3xl border border-[#D4AF37]/30 p-6 shadow-xl space-y-6">
            <div>
              <h2 className="text-xl font-black text-white">
                {isAr ? 'قائمة الأطباء والاستشاريين المعتمدين' : 'Certified Consultants Directory'}
              </h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                {isAr ? 'الكوادر الطبية المرجعية المسؤولة عن مناظرة وإجراء العمليات للمرضى' : 'Lead medical professors overseeing international referrals'}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {doctors.map(doc => (
                <div key={doc.id} className="p-4 rounded-2xl border border-zinc-800 bg-black space-y-3">
                  <img src={doc.avatarUrl} alt={doc.nameAr} className="w-16 h-16 rounded-xl object-cover mx-auto border border-[#D4AF37]/40" />
                  <div className="text-center">
                    <h4 className="font-bold text-xs text-white">{isAr ? doc.nameAr : doc.nameEn}</h4>
                    <p className="text-[11px] text-amber-400 font-medium">{isAr ? doc.specialtyAr : doc.specialtyEn}</p>
                    <p className="text-[10px] text-zinc-500 mt-0.5">{doc.experienceYears} عام خبرة</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: COMPLIANCE & ACCREDITATION AUDIT */}
        {activeTab === 'compliance' && (
          <div className="bg-zinc-950 rounded-3xl border border-[#D4AF37]/30 p-6 sm:p-8 shadow-xl space-y-6">
            <div>
              <h2 className="text-xl font-black text-white">
                {isAr ? 'مراجعة وتدقيق التراخيص والوثائق الرسمية' : 'Compliance, Licensing & Accreditation Audit'}
              </h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                {isAr ? 'تدقيق مستمر لضمان عدم إدراج أي جهة طبية كشريك دون استيفاء التراخيص الرسمية المعمول بها بمصر' : 'Rigorous verification to ensure zero unaccredited providers on the platform'}
              </p>
            </div>

            <div className="space-y-4">
              {[
                { nameAr: 'الهيئة العامة للاعتماد والرقابة الصحية (GAHAR)', statusAr: 'ساري وموثق', date: '2026-12-31', badge: 'GOLD' },
                { nameAr: 'اعتماد اللجنة الدولية المشتركة لجودة المستشفيات (JCI)', statusAr: 'معتمد دولياً', date: '2027-04-15', badge: 'INTERNATIONAL' },
                { nameAr: 'تراخيص وزارة الصحة والسكان المصرية للمنشآت الطبية الخاصة', statusAr: 'مرخص رسمي', date: '2027-01-01', badge: 'OFFICIAL' },
                { nameAr: 'بروتوكولات سرية البيانات وحماية خصوصية المرضى', statusAr: 'ممتثل للمعايير', date: '2026-11-01', badge: 'COMPLIANT' },
              ].map((comp, idx) => (
                <div key={idx} className="p-4 rounded-2xl bg-black border border-zinc-800 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-3">
                    <ShieldCheck className="w-5 h-5 text-[#D4AF37] shrink-0" />
                    <div>
                      <div className="font-bold text-white">{comp.nameAr}</div>
                      <div className="text-[11px] text-zinc-500">صلاحية الترخيص حتى: {comp.date}</div>
                    </div>
                  </div>
                  <span className="bg-[#D4AF37]/20 text-amber-300 border border-[#D4AF37]/40 font-bold px-2.5 py-1 rounded-full text-[11px]">
                    {comp.statusAr}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 6: LOGISTICS & TRAVEL */}
        {activeTab === 'logistics' && (
          <div className="bg-zinc-950 rounded-3xl border border-[#D4AF37]/30 p-6 shadow-xl space-y-6">
            <div>
              <h2 className="text-xl font-black text-white">
                {isAr ? 'إدارة حجوزات السفر والاستقبال والسيارات' : 'Travel, Chauffeur & Hotel Coordination Desk'}
              </h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                {isAr ? 'تتبع رحلات وصول المرضى من مطار القاهرة وجداول السيارات والفنادق' : 'Tracking patient arrival flights, hotel stays, and hospital shuttles'}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-5 rounded-2xl bg-black border border-zinc-800 space-y-2">
                <div className="text-xs text-zinc-400 font-bold">{isAr ? 'استقبالات المطار المجدولة هذا الأسبوع:' : 'Airport VIP Pickups:'}</div>
                <div className="text-2xl font-black text-amber-400 font-mono">8 رحلات</div>
                <div className="text-[11px] text-zinc-400">مطار القاهرة صالة 3 VIP</div>
              </div>

              <div className="p-5 rounded-2xl bg-black border border-zinc-800 space-y-2">
                <div className="text-xs text-zinc-400 font-bold">{isAr ? 'حجوزات الفنادق والشقق النشطة:' : 'Active Hotel Bookings:'}</div>
                <div className="text-2xl font-black text-amber-400 font-mono">14 جناح فندقي</div>
                <div className="text-[11px] text-zinc-400">فنادق 5 نجوم بالتجمع والمعادي</div>
              </div>

              <div className="p-5 rounded-2xl bg-black border border-zinc-800 space-y-2">
                <div className="text-xs text-zinc-400 font-bold">{isAr ? 'سيارات الإسعاف والتنقل الطبي:' : 'Medical Shuttles On Standby:'}</div>
                <div className="text-2xl font-black text-amber-400 font-mono">5 سيارات مجهزة</div>
                <div className="text-[11px] text-zinc-400">جاهزية 24 ساعة</div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 7: TRANSLATORS */}
        {activeTab === 'translators' && (
          <div className="bg-zinc-950 rounded-3xl border border-[#D4AF37]/30 p-6 shadow-xl space-y-6">
            <div>
              <h2 className="text-xl font-black text-white">
                {isAr ? 'إدارة المترجمين والمرافقين اللغويين' : 'Interpreters & Escorts Fleet'}
              </h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                {isAr ? 'تسكين المترجمين مع الوفود الأجنبية وتتبع جاهزيتهم' : 'Assigning medical interpreters to incoming international patients'}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {translators.map(tr => (
                <div key={tr.id} className="p-4 rounded-2xl bg-black border border-zinc-800 flex items-center justify-between text-xs">
                  <div>
                    <h4 className="font-bold text-white text-sm">{tr.name}</h4>
                    <div className="text-zinc-400 mt-0.5">{tr.specialty}</div>
                    <div className="text-[11px] text-amber-400 mt-1">{tr.languages.join(' • ')}</div>
                  </div>
                  <span className={`px-2.5 py-1 rounded-full font-bold text-[11px] ${
                    tr.status === 'available' ? 'bg-[#D4AF37]/20 text-amber-300 border border-[#D4AF37]/40' : 'bg-zinc-900 text-zinc-500 border border-zinc-800'
                  }`}>
                    {tr.status === 'available' ? (isAr ? 'متاح' : 'Available') : (isAr ? 'في مهمة' : 'Assigned')}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 8: INVOICES & DEMO FINANCIALS */}
        {activeTab === 'invoices' && (
          <div className="bg-zinc-950 rounded-3xl border border-[#D4AF37]/30 p-6 shadow-xl space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-black text-white">
                  {isAr ? 'إدارة الفواتير والمدفوعات (عرض تجريبي توضيحي)' : 'Demo Invoices & Financial Tracking'}
                </h2>
                <p className="text-xs text-zinc-400 mt-0.5">
                  {isAr ? 'محاكاة لحسابات باقات التنسيق الطبي، المستشفيات، والفنادق' : 'Simulated medical packages, hospital disbursements, and receipts'}
                </p>
              </div>
              <div className="text-sm font-bold text-amber-300 bg-black px-3.5 py-1.5 rounded-xl border border-[#D4AF37]/40">
                {isAr ? `إجمالي الفواتير: $${totalRevenueUsd.toLocaleString()}` : `Total: $${totalRevenueUsd.toLocaleString()}`}
              </div>
            </div>

            <div className="overflow-x-auto rounded-2xl border border-zinc-800">
              <table className="w-full text-start text-xs">
                <thead className="bg-black border-b border-zinc-800 text-amber-300 font-bold uppercase text-[10px]">
                  <tr>
                    <th className="p-3 text-start">{isAr ? 'رقم الفاتورة' : 'Invoice ID'}</th>
                    <th className="p-3 text-start">{isAr ? 'اسم المريض' : 'Patient'}</th>
                    <th className="p-3 text-start">{isAr ? 'بيان الخدمة' : 'Service Summary'}</th>
                    <th className="p-3 text-start">{isAr ? 'المبلغ ($)' : 'Amount'}</th>
                    <th className="p-3 text-start">{isAr ? 'الحالة' : 'Status'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-900">
                  {invoices.map(inv => (
                    <tr key={inv.id}>
                      <td className="p-3 font-mono font-bold text-amber-400">{inv.id}</td>
                      <td className="p-3 font-bold text-white">{inv.patientName}</td>
                      <td className="p-3 text-zinc-300 max-w-sm truncate">{inv.serviceSummary}</td>
                      <td className="p-3 font-mono font-bold text-white">${inv.amountUsd.toLocaleString()}</td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          inv.status === 'paid' ? 'bg-[#D4AF37]/20 text-amber-300 border border-[#D4AF37]/40' : 'bg-zinc-900 text-zinc-400 border border-zinc-800'
                        }`}>
                          {inv.status === 'paid' ? (isAr ? 'مدفوع' : 'Paid') : (isAr ? 'قيد السداد' : 'Pending')}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 9: REPORTS & GROWTH METRICS */}
        {activeTab === 'reports' && (
          <div className="bg-zinc-950 rounded-3xl border border-[#D4AF37]/30 p-6 sm:p-8 shadow-xl space-y-6">
            <div>
              <h2 className="text-xl font-black text-white">
                {isAr ? 'تقارير الأداء ومؤشرات النمو السياحي الطبي' : 'Performance Analytics & Medical Tourism Metrics'}
              </h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                {isAr ? 'مؤشرات استرشادية للعرض أمام المستثمرين عن التدفقات السياحية الطبية بمصر' : 'Demo business intelligence charts for partner presentations'}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="p-6 bg-black rounded-2xl border border-zinc-800 space-y-4">
                <h3 className="font-bold text-xs uppercase text-amber-400 tracking-wider">
                  {isAr ? 'توزيع الطلبات حسب القطاع الخدمي' : 'Demand Distribution by Pillar'}
                </h3>
                <div className="space-y-3 text-xs">
                  <div>
                    <div className="flex justify-between text-xs mb-1 text-zinc-300">
                      <span>القطاع الطبي والجراحة المتخصصة</span>
                      <span className="font-bold text-amber-300">48%</span>
                    </div>
                    <div className="w-full h-2 bg-zinc-900 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-amber-400 to-[#D4AF37] w-[48%]"></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1 text-zinc-300">
                      <span>السياحة العلاجية والاستشفاء البيئي</span>
                      <span className="font-bold text-amber-300">24%</span>
                    </div>
                    <div className="w-full h-2 bg-zinc-900 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-amber-400 to-[#D4AF37] w-[24%]"></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1 text-zinc-300">
                      <span>علاج الإدمان والتأهيل السلوكي</span>
                      <span className="font-bold text-amber-300">16%</span>
                    </div>
                    <div className="w-full h-2 bg-zinc-900 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-amber-400 to-[#D4AF37] w-[16%]"></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1 text-zinc-300">
                      <span>باقات الاستقبال واللوجستيات VIP</span>
                      <span className="font-bold text-amber-300">12%</span>
                    </div>
                    <div className="w-full h-2 bg-zinc-900 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-amber-400 to-[#D4AF37] w-[12%]"></div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-6 bg-black rounded-2xl border border-zinc-800 space-y-4">
                <h3 className="font-bold text-xs uppercase text-amber-400 tracking-wider">
                  {isAr ? 'أعلى الدول من حيث عدد المرضى الوافدين' : 'Top Origin Countries for Referrals'}
                </h3>
                <div className="space-y-3 text-xs">
                  <div className="flex items-center justify-between p-2.5 bg-zinc-900 rounded-xl border border-zinc-800">
                    <span className="font-bold text-white">1. المملكة العربية السعودية</span>
                    <span className="font-mono text-amber-400 font-bold">34% من الإجمالي</span>
                  </div>
                  <div className="flex items-center justify-between p-2.5 bg-zinc-900 rounded-xl border border-zinc-800">
                    <span className="font-bold text-white">2. دولة قطر والكويت</span>
                    <span className="font-mono text-amber-400 font-bold">28% من الإجمالي</span>
                  </div>
                  <div className="flex items-center justify-between p-2.5 bg-zinc-900 rounded-xl border border-zinc-800">
                    <span className="font-bold text-white">3. شرق إفريقيا (كينيا والسودان)</span>
                    <span className="font-mono text-amber-400 font-bold">20% من الإجمالي</span>
                  </div>
                  <div className="flex items-center justify-between p-2.5 bg-zinc-900 rounded-xl border border-zinc-800">
                    <span className="font-bold text-white">4. أوروبا الشرقية (روسيا)</span>
                    <span className="font-mono text-amber-400 font-bold">18% من الإجمالي</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* DETAIL & EDIT MODAL FOR PATIENT REQUEST IN BLACK & GOLD */}
      {selectedRequestForDetail && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-zinc-950 rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-[#D4AF37]/50 max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-150 text-white">
            
            <div className="flex items-center justify-between pb-4 border-b border-zinc-900 mb-6">
              <div className="flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-[#D4AF37]" />
                <div>
                  <h3 className="font-bold text-white text-lg">
                    {isAr ? 'تعديل وتوجيه الطلب:' : 'Manage Patient Request:'}{' '}
                    <span className="font-mono text-amber-400">{selectedRequestForDetail.id}</span>
                  </h3>
                  <p className="text-xs text-zinc-400">
                    {selectedRequestForDetail.patientName} ({selectedRequestForDetail.country})
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setSelectedRequestForDetail(null)}
                className="text-zinc-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveStatusUpdate} className="space-y-5">
              
              {/* Status Selector */}
              <div>
                <label className="block text-xs font-bold text-amber-200 mb-2">
                  {isAr ? 'تغيير حالة الطلب في النظام:' : 'Update Request Status:'}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {(['new', 'under_review', 'coordinating', 'confirmed', 'completed', 'cancelled'] as RequestStatus[]).map(st => (
                    <button
                      key={st}
                      type="button"
                      onClick={() => setStatusChangeValue(st)}
                      className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all text-center ${
                        statusChangeValue === st
                          ? 'bg-[#D4AF37] text-black border-[#D4AF37] font-black shadow-md'
                          : 'bg-black border-zinc-800 text-zinc-300 hover:bg-zinc-900'
                      }`}
                    >
                      {st === 'new' && (isAr ? 'جديد' : 'New')}
                      {st === 'under_review' && (isAr ? 'قيد المراجعة' : 'Under Review')}
                      {st === 'coordinating' && (isAr ? 'جاري التنسيق' : 'Coordinating')}
                      {st === 'confirmed' && (isAr ? 'تم التأكيد' : 'Confirmed')}
                      {st === 'completed' && (isAr ? 'مكتمل' : 'Completed')}
                      {st === 'cancelled' && (isAr ? 'ملغى' : 'Cancelled')}
                    </button>
                  ))}
                </div>
              </div>

              {/* Assign Hospital & Doctor */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-amber-200 mb-1.5">
                    {isAr ? 'المستشفى أو المركز المسند:' : 'Assigned Hospital / Hub:'}
                  </label>
                  <input
                    type="text"
                    value={assignedHospitalInput}
                    onChange={(e) => setAssignedHospitalInput(e.target.value)}
                    placeholder={isAr ? 'مثال: مجمع النيل الطبي المتقدم' : 'e.g. Nile Medical Complex'}
                    className="w-full text-xs px-3 py-2.5 rounded-xl bg-black border border-zinc-800 text-white focus:outline-hidden focus:border-[#D4AF37]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-amber-200 mb-1.5">
                    {isAr ? 'الطبيب الاستشاري المسؤول:' : 'Assigned Lead Consultant:'}
                  </label>
                  <input
                    type="text"
                    value={assignedDoctorInput}
                    onChange={(e) => setAssignedDoctorInput(e.target.value)}
                    placeholder={isAr ? 'مثال: أ.د. حازم المنصوري' : 'e.g. Prof. Hazem El-Mansoury'}
                    className="w-full text-xs px-3 py-2.5 rounded-xl bg-black border border-zinc-800 text-white focus:outline-hidden focus:border-[#D4AF37]"
                  />
                </div>
              </div>

              {/* Coordinator Notes */}
              <div>
                <label className="block text-xs font-bold text-amber-200 mb-1.5">
                  {isAr ? 'ملاحظات وتوجيهات المنسق الطبي (تظهر للمريض في بوابة المتابعة):' : 'Coordinator Notes (Visible in Patient Portal):'}
                </label>
                <textarea
                  rows={3}
                  value={coordinatorNoteInput}
                  onChange={(e) => setCoordinatorNoteInput(e.target.value)}
                  placeholder={isAr ? 'اكتب تفاصيل التنسيق وموعد الوصول المقترح والتوصيات...' : 'Add coordination instructions, appointment schedule, or follow-up notes...'}
                  className="w-full text-xs px-3 py-2.5 rounded-xl bg-black border border-zinc-800 text-white focus:outline-hidden focus:border-[#D4AF37]"
                ></textarea>
              </div>

              {/* Quick Case Info Box */}
              <div className="p-3 bg-black rounded-xl border border-zinc-800 text-xs text-zinc-300 space-y-1">
                <div><strong className="text-amber-300">{isAr ? 'الاحتياج المسجل:' : 'Need:'}</strong> {selectedRequestForDetail.specialtyOrNeed}</div>
                <div><strong className="text-amber-300">{isAr ? 'الوصف:' : 'Details:'}</strong> {selectedRequestForDetail.description}</div>
                <div><strong className="text-amber-300">{isAr ? 'الاتصال:' : 'Contact:'}</strong> {selectedRequestForDetail.preferredContact} ({selectedRequestForDetail.phone})</div>
              </div>

              {/* Modal Buttons */}
              <div className="flex gap-3 pt-3 border-t border-zinc-900">
                <button
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black font-black py-3 rounded-xl text-xs transition-all shadow-md shadow-amber-500/20"
                >
                  {isAr ? 'حفظ التحديث وتطبيقه فوراً' : 'Save & Sync Immediately'}
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedRequestForDetail(null)}
                  className="px-4 py-3 border border-zinc-800 text-zinc-300 font-semibold rounded-xl text-xs hover:bg-zinc-900 transition-colors"
                >
                  {t.close}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
};
