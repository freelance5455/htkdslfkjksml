import React, { useState } from 'react';
import { 
  FolderKanban, 
  Search, 
  Plus, 
  Calendar, 
  Users, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  ExternalLink,
  Flame,
  Trash2,
  Edit2
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Project, ProjectPriority, ProjectCategory, ProjectStatus } from '../types';

interface ProjectManagementViewProps {
  onOpenNewProjectModal: () => void;
  onEditProject?: (project: Project) => void;
}

export const ProjectManagementView: React.FC<ProjectManagementViewProps> = ({ 
  onOpenNewProjectModal,
  onEditProject 
}) => {
  const { 
    projects, 
    clients, 
    users, 
    setSelectedProjectId, 
    setActiveView, 
    deleteProject 
  } = useApp();

  const [activeTab, setActiveTab] = useState<'All' | ProjectStatus>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [projectToDelete, setProjectToDelete] = useState<Project | null>(null);

  const categories: ProjectCategory[] = [
    'Fire Alarm System',
    'Hydrant & Sprinkler',
    'CO2 & Clean Agent Gas',
    'Extinguisher & AMC',
    'TNFRS NOC Compliance'
  ];

  const filteredProjects = projects.filter(p => {
    const matchesTab = activeTab === 'All' || p.status === activeTab;
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
    const matchesSearch = 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.reference.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.clientCompanyName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.siteLocation.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTab && matchesCategory && matchesSearch;
  });

  const handleOpenProject = (id: string) => {
    setSelectedProjectId(id);
    setActiveView('project-detail');
  };

  const handleConfirmDelete = () => {
    if (projectToDelete) {
      deleteProject(projectToDelete.id);
      setProjectToDelete(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Project Management & Work Orders</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Fire protection installation contracts, retrofits, and statutory TNFRS compliance monitoring.
          </p>
        </div>

        <button
          onClick={onOpenNewProjectModal}
          className="px-4 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg cursor-pointer shadow-xs transition-colors flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Create Project</span>
        </button>
      </div>

      {/* Tabs & Filters Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-4">
        {/* Status Tabs (Segmented Button Controls) */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="overflow-x-auto no-scrollbar pb-1 sm:pb-0 -mx-1 px-1">
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg w-max sm:w-auto">
              {(['All', 'In Progress', 'Pending', 'Completed', 'Overdue'] as const).map(tab => {
                const count = tab === 'All' 
                  ? projects.length 
                  : projects.filter(p => p.status === tab).length;
                const isActive = activeTab === tab;

                return (
                  <button
                    key={tab}
                    type="button"
                    onClick={() => setActiveTab(tab)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
                      isActive 
                        ? 'bg-white text-slate-900 shadow-xs font-semibold' 
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <span>{tab}</span>
                    <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full ${
                      tab === 'Overdue' && count > 0 
                        ? 'bg-red-100 text-red-700 font-bold' 
                        : 'bg-slate-200/70 text-slate-600'
                    }`}>
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto w-full sm:w-auto">
            <span className="text-xs text-slate-400 shrink-0">Category:</span>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 cursor-pointer w-full sm:w-auto"
            >
              <option value="All">All Categories</option>
              {categories.map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Search Input */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search by project reference (e.g. PHX-2026-081), project title, client, or site location..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:border-red-500"
          />
        </div>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredProjects.length === 0 ? (
          <div className="col-span-full bg-white rounded-xl border border-slate-200 p-12 text-center text-slate-500 text-xs">
            No projects found matching the selected filters.
          </div>
        ) : (
          filteredProjects.map((project) => {
            const assignedEngineers = users.filter(u => project.assignedEmployeeIds.includes(u.id));

            return (
              <div
                key={project.id}
                className="bg-white rounded-xl border border-slate-200 shadow-xs hover:border-slate-300 transition-all flex flex-col justify-between overflow-hidden"
              >
                <div className="p-5 space-y-3.5">
                  {/* Top metadata line with typographic separators (anti-slop) */}
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <div className="flex items-center gap-1.5 font-mono">
                      <span className="font-bold text-red-600">{project.reference}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-medium text-slate-600">{project.category}</span>
                    </div>

                    <span className={`font-semibold ${
                      project.status === 'Completed'
                        ? 'text-emerald-700'
                        : project.status === 'In Progress'
                        ? 'text-blue-700'
                        : project.status === 'Overdue'
                        ? 'text-red-700'
                        : 'text-amber-700'
                    }`}>
                      {project.status}
                    </span>
                  </div>

                  {/* Title & Client */}
                  <div>
                    <h3 
                      onClick={() => handleOpenProject(project.id)}
                      className="text-sm font-bold text-slate-900 hover:text-red-600 cursor-pointer transition-colors line-clamp-1"
                    >
                      {project.name}
                    </h3>
                    <p className="text-xs font-medium text-slate-700 mt-0.5">
                      {project.clientCompanyName}
                    </p>
                    <p className="text-[11px] text-slate-400 mt-0.5 truncate">
                      {project.siteLocation}
                    </p>
                  </div>

                  {/* Description */}
                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                    {project.description}
                  </p>

                  {/* Progress bar */}
                  <div className="space-y-1 pt-1">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-500">Completion</span>
                      <span className="font-mono font-semibold text-slate-800 tabular-nums">
                        {project.progressPercentage}%
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all ${
                          project.status === 'Completed'
                            ? 'bg-emerald-600'
                            : project.status === 'Overdue'
                            ? 'bg-red-600'
                            : 'bg-blue-600'
                        }`}
                        style={{ width: `${project.progressPercentage}%` }}
                      />
                    </div>
                  </div>

                  {/* Dates & Assigned Team */}
                  <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-500 flex items-center justify-between">
                    <div>
                      <span>Due: </span>
                      <span className="font-mono text-slate-800 font-medium">{project.expectedCompletionDate}</span>
                    </div>
                    <div>
                      <span>Team: </span>
                      <span className="text-slate-700 font-medium">
                        {assignedEngineers.map(e => e.name.split(' ')[0]).join(', ') || 'Unassigned'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Footer text-based actions */}
                <div className="px-5 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs">
                  <div className="font-mono font-semibold text-slate-800">
                    ₹{project.contractValueINR ? (project.contractValueINR / 100000).toFixed(1) + ' Lakhs' : 'TBD'}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleOpenProject(project.id)}
                      className="px-2.5 py-1 text-slate-700 hover:text-slate-900 font-semibold hover:bg-slate-200/60 rounded cursor-pointer transition-colors"
                    >
                      View
                    </button>
                    <button
                      type="button"
                      onClick={() => onEditProject ? onEditProject(project) : handleOpenProject(project.id)}
                      className="px-2.5 py-1 text-blue-600 hover:text-blue-800 font-semibold hover:bg-blue-50 rounded cursor-pointer transition-colors"
                    >
                      Edit
                    </button>
                    <button
                      type="button"
                      onClick={() => setProjectToDelete(project)}
                      className="px-2.5 py-1 text-red-600 hover:text-red-800 font-semibold hover:bg-red-50 rounded cursor-pointer transition-colors"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {projectToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-md p-6">
            <h3 className="text-base font-bold text-slate-900">Delete Project</h3>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Are you sure you want to permanently delete project <strong className="text-slate-900">{projectToDelete.reference}: {projectToDelete.name}</strong>?
            </p>
            <p className="text-xs text-red-600 mt-1">
              All linked tasks, conversations, and document references will be removed.
            </p>

            <div className="mt-6 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setProjectToDelete(null)}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-xs transition-colors"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
