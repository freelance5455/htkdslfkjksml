import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { translations } from '../data/translations';
import { 
  Globe2, 
  Calculator, 
  Send, 
  ArrowLeft, 
  ArrowRight, 
  Crown
} from 'lucide-react';

export const InternationalSectorView: React.FC = () => {
  const { language, setCurrentView, openRequestModalForService } = useApp();
  const t = translations[language];
  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  // Interactive Cost Estimator State (Demo purposes)
  const [procedureType, setProcedureType] = useState('cardiac');
  const [stayDuration, setStayDuration] = useState('7');
  const [includeHotel, setIncludeHotel] = useState(true);
  const [includeTranslator, setIncludeTranslator] = useState(true);

  const calculateEstimate = () => {
    let base = 3500;
    if (procedureType === 'cardiac') base = 7500;
    if (procedureType === 'ortho') base = 4800;
    if (procedureType === 'eye') base = 1800;
    if (procedureType === 'rehab') base = 5500;
    if (procedureType === 'wellness') base = 2800;

    const days = parseInt(stayDuration, 10) || 7;
    const hotelCost = includeHotel ? days * 120 : 0;
    const translatorCost = includeTranslator ? days * 60 : 0;
    const total = base + hotelCost + translatorCost;

    return {
      medical: base,
      hotel: hotelCost,
      escort: translatorCost,
      total: total
    };
  };

  const est = calculateEstimate();

  const partnerRegions = [
    {
      regionAr: 'منطقة الخليج العربي',
      regionEn: 'Gulf Cooperation Council (GCC)',
      countries: isAr ? ['السعودية', 'الإمارات', 'الكويت', 'قطر', 'سلطنة عمان', 'البحرين'] : ['Saudi Arabia', 'UAE', 'Kuwait', 'Qatar', 'Oman', 'Bahrain'],
      descAr: 'مكتب تنسيق مباشر وتسهيل الدخول دون تأشيرة لمعظم مواطني دول مجلس التعاون.',
      descEn: 'Dedicated liaison desk and streamlined travel access for GCC citizens.'
    },
    {
      regionAr: 'شمال وشرق إفريقيا',
      regionEn: 'North & East Africa',
      countries: isAr ? ['السودان', 'ليبيا', 'كينيا', 'تنزانيا', 'إثيوبيا', 'أوغندا'] : ['Sudan', 'Libya', 'Kenya', 'Tanzania', 'Ethiopia', 'Uganda'],
      descAr: 'تسهيل إصدار التأشيرة العلاجية المصرية العاجلة وترجمة التقارير وتوفير مرافقين متحدثين بالسواحلية.',
      descEn: 'Expedited Egyptian medical visas and Swahili-speaking clinical concierges.'
    },
    {
      regionAr: 'أوروبا الشرقية وآسيا الوسطى',
      regionEn: 'Eastern Europe & Central Asia',
      countries: isAr ? ['روسيا الاتحادية', 'كازاخستان', 'أوزبكستان', 'أذربيجان'] : ['Russia', 'Kazakhstan', 'Uzbekistan', 'Azerbaijan'],
      descAr: 'حزم سياحة علاجية واستشفائية بيئية بالبحر الأحمر وأسوان مع مترجمين متخصصين باللغة الروسية.',
      descEn: 'Red Sea & Aswan wellness itineraries accompanied by certified Russian interpreters.'
    }
  ];

  return (
    <div className="py-12 bg-black min-h-screen text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Breadcrumb */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => setCurrentView('home')}
            className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-zinc-400 hover:text-amber-300 transition-colors"
          >
            <ArrowIcon className="w-4 h-4 text-[#D4AF37]" />
            <span>{t.backToHome}</span>
          </button>
          <span className="text-xs bg-zinc-900 border border-[#D4AF37]/40 text-amber-300 font-bold px-3 py-1 rounded-full">
            {isAr ? 'البوابة والخدمات الدولية' : 'International Healthcare Coordination Desk'}
          </span>
        </div>

        {/* Hero Header in Black & Gold */}
        <div className="relative overflow-hidden bg-gradient-to-r from-zinc-950 via-black to-zinc-950 rounded-3xl p-8 sm:p-12 text-white shadow-2xl border border-[#D4AF37]/40">
          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center gap-2 bg-[#D4AF37]/15 text-amber-300 border border-[#D4AF37]/40 px-3 py-1 rounded-full text-xs font-semibold">
              <Globe2 className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>{isAr ? 'شبكة عابرة للحدود تخدم المرضى من 18+ دولة' : 'Cross-Border Network Serving 18+ Nations'}</span>
            </div>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-black bg-gradient-to-r from-white via-zinc-100 to-amber-200 bg-clip-text text-transparent tracking-tight">
              {isAr ? 'الخدمات الدولية وتنسيق الرحلة العلاجية' : 'Global Patient Operations & Medical Visa Desk'}
            </h1>
            <p className="text-zinc-300 text-sm sm:text-base leading-relaxed">
              {isAr
                ? 'استقبال طلبات المرضى من مختلف الدول وتيسير إصدار التأشيرات العلاجية، الاستشارات المرئية عن بُعد قبل السفر، والتنظيم المالي الشفاف لرحلة العلاج في جمهورية مصر العربية.'
                : 'Facilitating cross-border medical referrals, pre-travel telehealth diagnostics, medical visa processing, and transparent healthcare cost forecasting in Egypt.'}
            </p>
            <div className="pt-2 flex flex-wrap gap-3">
              <button
                onClick={() => openRequestModalForService('international_services')}
                className="bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black font-extrabold px-6 py-3.5 rounded-xl text-xs sm:text-sm transition-all shadow-xl shadow-amber-500/20 flex items-center gap-2"
              >
                <Send className="w-4 h-4 text-black" />
                <span>{isAr ? 'طلب التنسيق الدولي المباشر' : 'Initiate International Referral'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Regions Served in Black & Gold */}
        <div className="space-y-6">
          <div>
            <h2 className="text-2xl font-black bg-gradient-to-r from-white to-amber-200 bg-clip-text text-transparent">
              {isAr ? 'الأقاليم والدول المشمولة بالخدمة' : 'Global Liaison Desks & Regional Coverage'}
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              {isAr ? 'خدمات مخصصة تراعي التسهيلات القنصلية واحتياجات الترجمة لكل إقليم' : 'Tailored consular facilitation, visa guidance, and language support per region'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {partnerRegions.map((reg, idx) => (
              <div key={idx} className="bg-zinc-950 rounded-3xl p-6 border border-[#D4AF37]/30 hover:border-[#D4AF37] shadow-xl hover:shadow-[0_0_20px_rgba(212,175,55,0.15)] transition-all space-y-4">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-xl bg-black border border-[#D4AF37]/40 text-amber-300 flex items-center justify-center font-bold">
                    <Globe2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-base">
                      {isAr ? reg.regionAr : reg.regionEn}
                    </h3>
                  </div>
                </div>

                <p className="text-xs text-zinc-400 leading-relaxed">
                  {isAr ? reg.descAr : reg.descEn}
                </p>

                <div>
                  <div className="text-[11px] font-bold text-amber-400 uppercase tracking-wider mb-2">
                    {isAr ? 'أبرز الدول المستفيدة:' : 'Covered Nations:'}
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {reg.countries.map((c, cIdx) => (
                      <span key={cIdx} className="bg-black border border-zinc-800 text-zinc-300 text-xs px-2.5 py-1 rounded-lg">
                        {c}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Interactive Cost Estimator (Demo Tool for Investors in Black & Gold) */}
        <div className="bg-zinc-950 rounded-3xl p-6 sm:p-10 border border-[#D4AF37]/40 shadow-2xl">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl bg-black border border-[#D4AF37]/50 flex items-center justify-center text-amber-400 shadow-md">
              <Calculator className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-2xl font-black bg-gradient-to-r from-white via-zinc-100 to-amber-200 bg-clip-text text-transparent">
                {isAr ? 'حاسبة التكاليف الاسترشادية التقديرية (عرض توضيحي)' : 'Transparent Cost Estimator (Investor Demo Tool)'}
              </h2>
              <p className="text-xs text-zinc-400">
                {isAr ? 'أداة تفاعلية لحساب التكلفة التقديرية الشاملة للجراحة والإقامة والنقل للمرضى الوافدين' : 'Interactive demonstration showing estimated bundle pricing for clinical care, hotel, and escort'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Input Controls */}
            <div className="lg:col-span-7 space-y-5 bg-black p-6 rounded-2xl border border-zinc-800">
              <div>
                <label className="block text-xs font-bold text-amber-200 mb-2">
                  {isAr ? 'نوع التدخل الطبي أو الاستشفائي:' : 'Procedure or Treatment Type:'}
                </label>
                <select
                  value={procedureType}
                  onChange={(e) => setProcedureType(e.target.value)}
                  className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-white focus:outline-hidden focus:border-[#D4AF37]"
                >
                  <option value="cardiac">{isAr ? 'جراحة وقسطرة القلب التداخلية (~7,500$)' : 'Cardiac Stenting & Surgery (~$7,500)'}</option>
                  <option value="ortho">{isAr ? 'جراحة المفاصل والعمود الفقري بالمناظير (~4,800$)' : 'Joint Replacement & Spine (~$4,800)'}</option>
                  <option value="eye">{isAr ? 'جراحات العيون والفيمتو ليزك (~1,800$)' : 'Ophthalmology & Femto-Lasik (~$1,800)'}</option>
                  <option value="rehab">{isAr ? 'برنامج تأهيل نفسي وسحب سموم متكامل (~5,500$)' : 'Addiction Detox & Behavioral Rehab (~$5,500)'}</option>
                  <option value="wellness">{isAr ? 'برنامج استشفائي بيئي بسيوة أو أسوان (~2,800$)' : 'Natural Climatotherapy & Salt Baths (~$2,800)'}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-amber-200 mb-2">
                  {isAr ? 'مدة الإقامة المقدرة بمصر (أيام):' : 'Estimated Stay Duration (Days):'}
                </label>
                <div className="flex gap-2">
                  {['5', '7', '10', '14', '21'].map(d => (
                    <button
                      key={d}
                      type="button"
                      onClick={() => setStayDuration(d)}
                      className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-all ${
                        stayDuration === d
                          ? 'bg-[#D4AF37] text-black border-[#D4AF37]'
                          : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-800'
                      }`}
                    >
                      {d} {isAr ? 'أيام' : 'days'}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-3 pt-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={includeHotel}
                    onChange={(e) => setIncludeHotel(e.target.checked)}
                    className="w-4 h-4 text-amber-500 rounded border-zinc-700 bg-black"
                  />
                  <span className="text-xs text-zinc-300 font-medium">
                    {isAr ? 'شمل حجز فندقي 5 نجوم قريب من المستشفى للمريض والمرافق' : 'Include 5-star hotel near medical complex for patient & escort'}
                  </span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={includeTranslator}
                    onChange={(e) => setIncludeTranslator(e.target.checked)}
                    className="w-4 h-4 text-amber-500 rounded border-zinc-700 bg-black"
                  />
                  <span className="text-xs text-zinc-300 font-medium">
                    {isAr ? 'شمل مترجم طبي معتمد ومرافق طوال فترة الفحوصات' : 'Include certified medical interpreter & clinical escort'}
                  </span>
                </label>
              </div>

              <div className="text-[11px] text-zinc-500 italic">
                {isAr
                  ? '* الأسعار المذكورة هي تقديرات استرشادية للعرض فقط، ويتم تحديد التكلفة النهائية بعد الاطلاع على الفحوصات الطبية.'
                  : '* Prices are indicative estimates for demonstration. Formal quotation is issued following board clinical review.'}
              </div>
            </div>

            {/* Breakdown Display in Gold & Black */}
            <div className="lg:col-span-5 bg-black rounded-2xl p-6 text-white space-y-5 border border-[#D4AF37]/50 shadow-2xl">
              <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
                <span className="text-xs text-zinc-400 uppercase tracking-wider">{isAr ? 'ملخص الحزمة التقديرية' : 'Estimated Bundle'}</span>
                <span className="text-[10px] bg-[#D4AF37]/20 text-amber-300 border border-[#D4AF37]/40 px-2 py-0.5 rounded-full font-mono">
                  DEMO ESTIMATE
                </span>
              </div>

              <div className="space-y-2.5 text-xs text-zinc-300">
                <div className="flex justify-between">
                  <span>{isAr ? 'الإجراء الطبي / الاستشفائي:' : 'Clinical Intervention:'}</span>
                  <span className="font-mono text-white font-bold">${est.medical.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>{isAr ? `الإقامة الفندقية (${stayDuration} أيام):` : `Hotel Stay (${stayDuration}d):`}</span>
                  <span className="font-mono text-white font-bold">${est.hotel.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>{isAr ? 'المترجم والمرافق اللوجستي:' : 'Interpreter & Escort:'}</span>
                  <span className="font-mono text-white font-bold">${est.escort.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-amber-400">
                  <span>{isAr ? 'استقبال وتوديع المطار VIP:' : 'VIP Airport Care:'}</span>
                  <span className="font-bold">{isAr ? 'مجاني ضمن الباقة' : 'Complimentary'}</span>
                </div>
              </div>

              <div className="pt-4 border-t border-zinc-800">
                <div className="text-xs text-zinc-400 mb-1">{isAr ? 'إجمالي التكلفة التقديرية:' : 'Total Estimated Cost:'}</div>
                <div className="text-3xl font-black text-amber-400 font-mono">
                  ${est.total.toLocaleString()} <span className="text-xs text-zinc-400 font-normal">USD</span>
                </div>
                <div className="text-[11px] text-zinc-500 mt-1">
                  {isAr ? 'توفير يصل إلى 60% مقارنة بتكاليف العلاج في أوروبا وأمريكا' : 'Save up to 60% compared to Western Europe or US equivalents'}
                </div>
              </div>

              <button
                onClick={() => openRequestModalForService('international_services')}
                className="w-full py-3.5 bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black font-extrabold rounded-xl text-xs transition-all flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20"
              >
                <Send className="w-4 h-4 text-black" />
                <span>{isAr ? 'طلب تثبيت هذا العرض التقديري' : 'Lock In This Estimate Inquiry'}</span>
              </button>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};
