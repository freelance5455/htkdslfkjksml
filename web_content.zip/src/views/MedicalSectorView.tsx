import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { translations } from '../data/translations';
import { 
  HeartPulse, 
  Building2, 
  Award, 
  Star, 
  MapPin, 
  UserCheck, 
  Stethoscope, 
  ShieldCheck, 
  Send, 
  ArrowLeft, 
  ArrowRight, 
  Filter,
  Crown
} from 'lucide-react';

export const MedicalSectorView: React.FC = () => {
  const { 
    language, 
    setCurrentView, 
    openRequestModalForService, 
    medicalCenters, 
    doctors 
  } = useApp();

  const [selectedSpecialty, setSelectedSpecialty] = useState<string>('all');
  const t = translations[language];
  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  const specialties = [
    { id: 'all', nameAr: 'جميع التخصصات المرجعية', nameEn: 'All Specialties' },
    { id: 'heart', nameAr: 'جراحة القلب والقسطرة', nameEn: 'Cardiology & Stents' },
    { id: 'ortho', nameAr: 'العظام والعمود الفقري', nameEn: 'Orthopedics & Spine' },
    { id: 'cancer', nameAr: 'علاج وبحوث الأورام', nameEn: 'Oncology & Radiation' },
    { id: 'eye', nameAr: 'العيون وجراحات الليزك', nameEn: 'Ophthalmology & Cornea' },
    { id: 'transplant', nameAr: 'زراعة الأعضاء الدقيقة', nameEn: 'Organ Transplants' },
  ];

  return (
    <div className="py-12 bg-black min-h-screen text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Header Breadcrumb */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <button
            onClick={() => setCurrentView('home')}
            className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-zinc-400 hover:text-amber-300 transition-colors"
          >
            <ArrowIcon className="w-4 h-4 text-[#D4AF37]" />
            <span>{t.backToHome}</span>
          </button>
          <span className="text-xs bg-zinc-900 border border-[#D4AF37]/40 text-amber-300 font-bold px-3 py-1 rounded-full">
            {isAr ? 'القطاع الطبي الشامل المرجعي' : 'Comprehensive Medical Hub'}
          </span>
        </div>

        {/* Hero Banner for Medical Sector in Black & Gold */}
        <div className="relative overflow-hidden bg-gradient-to-r from-zinc-950 via-black to-zinc-950 rounded-3xl p-8 sm:p-12 text-white shadow-2xl border border-[#D4AF37]/40">
          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center gap-2 bg-[#D4AF37]/15 text-amber-300 border border-[#D4AF37]/40 px-3 py-1 rounded-full text-xs font-semibold">
              <Crown className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>{isAr ? 'مستشفيات معتمدة دولياً ومحلياً (JCI & GAHAR)' : 'JCI & GAHAR Gold Accredited'}</span>
            </div>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-black bg-gradient-to-r from-white via-zinc-100 to-amber-200 bg-clip-text text-transparent tracking-tight">
              {isAr ? 'القطاع الطبي الشامل والمستشفيات المعتمدة' : 'Comprehensive Medical Sector & Accredited Centers'}
            </h1>
            <p className="text-zinc-300 text-sm sm:text-base leading-relaxed">
              {isAr
                ? 'تنسيق مباشر مع أكبر المراكز الطبية الجامعية والتخصصية في مصر، بإشراف نخبة من كبار أساتذة الجراحة وزراعة الأعضاء والقسطرة التداخلية، مع إشراف طبي ولجان مراجعة سريرية متكاملة.'
                : 'Direct linkage to premier university and tertiary private hospitals across Egypt, led by renowned surgical professors and multi-disciplinary boards.'}
            </p>
            <div className="pt-2 flex flex-wrap gap-3">
              <button
                onClick={() => openRequestModalForService('medical_sector')}
                className="bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black font-extrabold px-6 py-3.5 rounded-xl text-xs sm:text-sm transition-all shadow-xl shadow-amber-500/20 flex items-center gap-2"
              >
                <Send className="w-4 h-4 text-black" />
                <span>{isAr ? 'طلب التنسيق مع جهة طبية مناسبة' : 'Request Medical Coordination'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Filter Bar in Black & Gold */}
        <div className="bg-zinc-950 p-4 rounded-2xl border border-zinc-800 shadow-md flex items-center gap-3 overflow-x-auto">
          <Filter className="w-4 h-4 text-amber-400 shrink-0" />
          <span className="text-xs font-bold text-amber-300 shrink-0">
            {isAr ? 'تصفية التخصص:' : 'Filter Specialty:'}
          </span>
          <div className="flex gap-2">
            {specialties.map(spec => (
              <button
                key={spec.id}
                onClick={() => setSelectedSpecialty(spec.id)}
                className={`text-xs px-3 py-1.5 rounded-xl whitespace-nowrap transition-all font-medium ${
                  selectedSpecialty === spec.id
                    ? 'bg-[#D4AF37] text-black font-bold shadow-md'
                    : 'bg-black hover:bg-zinc-900 text-zinc-300 border border-zinc-800'
                }`}
              >
                {isAr ? spec.nameAr : spec.nameEn}
              </button>
            ))}
          </div>
        </div>

        {/* Accredited Medical Centers Showcase */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-black bg-gradient-to-r from-white to-amber-200 bg-clip-text text-transparent">
                {isAr ? 'المستشفيات والمجمعات الطبية الشريكة' : 'Partner Hospitals & Medical Complexes'}
              </h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                {isAr ? 'جميع المستشفيات تخضع لمعايير الجودة والاعتماد الوطني والدولي' : 'All centers subject to official national and global accreditation'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {medicalCenters.map(center => (
              <div 
                key={center.id}
                className="bg-zinc-950 rounded-3xl border border-[#D4AF37]/30 hover:border-[#D4AF37] overflow-hidden shadow-xl hover:shadow-[0_0_25px_rgba(212,175,55,0.2)] transition-all duration-300 flex flex-col justify-between group"
              >
                <div>
                  <div className="relative h-56 overflow-hidden">
                    <img 
                      src={center.imageUrl} 
                      alt={isAr ? center.nameAr : center.nameEn}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent"></div>
                    
                    <div className="absolute top-3 right-3 rtl:right-3 rtl:left-auto ltr:left-3 ltr:right-auto flex gap-1.5 flex-wrap">
                      {center.accreditation.map((acc, aIdx) => (
                        <span key={aIdx} className="bg-black/90 backdrop-blur-md text-[#D4AF37] border border-[#D4AF37]/50 text-[10px] font-bold px-2.5 py-0.5 rounded-full shadow-md">
                          {acc}
                        </span>
                      ))}
                    </div>

                    <div className="absolute bottom-3 right-3 rtl:right-3 rtl:left-auto ltr:left-3 ltr:right-auto text-white">
                      <div className="flex items-center gap-1 text-xs text-amber-300 mb-0.5">
                        <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
                        <span>{center.city}</span>
                      </div>
                      <h3 className="text-lg font-bold text-white">
                        {isAr ? center.nameAr : center.nameEn}
                      </h3>
                    </div>
                  </div>

                  <div className="p-6 space-y-4">
                    <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
                      {isAr ? center.descriptionAr : center.descriptionEn}
                    </p>

                    <div>
                      <div className="text-xs font-bold text-amber-200 mb-2">
                        {isAr ? 'أبرز التخصصات المرجعية:' : 'Core Key Specialties:'}
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {center.specialties.map((sp, sIdx) => (
                          <span key={sIdx} className="text-[11px] bg-black text-amber-200 border border-zinc-800 px-2.5 py-1 rounded-lg">
                            {sp}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-xs text-zinc-400 pt-2 border-t border-zinc-900">
                      <span>{isAr ? `الطاقة الاستيعابية: ${center.bedCapacity} سرير` : `Capacity: ${center.bedCapacity} beds`}</span>
                      <div className="flex items-center gap-1 text-amber-400 font-bold">
                        <Star className="w-3.5 h-3.5 fill-current" />
                        <span>{center.rating} / 5.0</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-6 pt-0">
                  <button
                    onClick={() => openRequestModalForService('medical_sector')}
                    className="w-full py-3 bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 shadow-md shadow-amber-500/20"
                  >
                    <Send className="w-3.5 h-3.5 text-black" />
                    <span>{isAr ? 'طلب التنسيق مع هذا المجمع' : 'Coordinate with this Hospital'}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Leading Professors & Consultants */}
        <div className="space-y-6 pt-6">
          <div>
            <h2 className="text-2xl font-black bg-gradient-to-r from-white to-amber-200 bg-clip-text text-transparent">
              {isAr ? 'نخبة كبار الاستشاريين وأساتذة الجراحة' : 'Leading Surgical Professors & Consultants'}
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              {isAr ? 'كوادر ذات شهرة إقليمية ودولية في التدخلات الجراحية المعقدة' : 'Senior academic surgeons with proven international records'}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {doctors.map(doc => (
              <div 
                key={doc.id}
                className="bg-zinc-950 rounded-2xl border border-zinc-800 hover:border-[#D4AF37] p-5 shadow-md hover:shadow-[0_0_15px_rgba(212,175,55,0.2)] transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="relative mb-4">
                    <img 
                      src={doc.avatarUrl} 
                      alt={isAr ? doc.nameAr : doc.nameEn}
                      className="w-20 h-20 rounded-2xl object-cover mx-auto border-2 border-[#D4AF37]/50"
                    />
                    <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-black text-amber-300 text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-[#D4AF37]/50">
                      {isAr ? `${doc.experienceYears} عام خبرة` : `${doc.experienceYears} yrs exp`}
                    </div>
                  </div>

                  <div className="text-center space-y-1 mb-3">
                    <h3 className="font-bold text-white text-sm">
                      {isAr ? doc.nameAr : doc.nameEn}
                    </h3>
                    <div className="text-xs text-amber-400 font-medium">
                      {isAr ? doc.specialtyAr : doc.specialtyEn}
                    </div>
                    <div className="text-[11px] text-zinc-500">
                      {isAr ? doc.hospitalAr : doc.hospitalEn}
                    </div>
                  </div>

                  <div className="space-y-1 pt-2 border-t border-zinc-900 text-[11px] text-zinc-400">
                    <div className="flex justify-between">
                      <span className="text-zinc-500">{isAr ? 'اللغات:' : 'Languages:'}</span>
                      <span>{doc.languages.join(' • ')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-500">{isAr ? 'التقييم:' : 'Rating:'}</span>
                      <span className="text-amber-400 font-bold">★ {doc.rating}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-zinc-900">
                  <button
                    onClick={() => openRequestModalForService('medical_sector')}
                    className="w-full py-2 bg-black hover:bg-zinc-900 text-amber-300 border border-[#D4AF37]/40 rounded-lg text-xs font-bold transition-colors"
                  >
                    {isAr ? 'طلب استشارة أو موعد' : 'Book Consultation'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
