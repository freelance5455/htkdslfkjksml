import React from 'react';
import { useApp } from '../context/AppContext';
import { translations } from '../data/translations';
import { 
  Building2, 
  Lock, 
  ShieldCheck, 
  HeartHandshake, 
  CheckCircle2, 
  Send, 
  ArrowLeft, 
  ArrowRight, 
  MapPin, 
  Crown
} from 'lucide-react';

export const RehabSectorView: React.FC = () => {
  const { language, setCurrentView, openRequestModalForService, rehabCenters } = useApp();
  const t = translations[language];
  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  return (
    <div className="py-12 bg-black min-h-screen text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Breadcrumb */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => setCurrentView('home')}
            className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-zinc-400 hover:text-amber-300 transition-colors"
          >
            <ArrowIcon className="w-4 h-4 text-[#D4AF37]" />
            <span>{t.backToHome}</span>
          </button>
          <span className="text-xs bg-zinc-900 border border-[#D4AF37]/40 text-amber-300 font-bold px-3 py-1 rounded-full">
            {isAr ? 'علاج الإدمان والتأهيل السلوكي والنفسي' : 'Addiction Recovery & Psychological Rehab'}
          </span>
        </div>

        {/* Hero Banner in Black & Gold */}
        <div className="relative overflow-hidden bg-gradient-to-r from-zinc-950 via-black to-zinc-950 rounded-3xl p-8 sm:p-12 text-white shadow-2xl border border-[#D4AF37]/40">
          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center gap-2 bg-[#D4AF37]/15 text-amber-300 border border-[#D4AF37]/40 px-3 py-1 rounded-full text-xs font-semibold">
              <Lock className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>{isAr ? 'خصوصية وسرية عائلية مطلقة 100%' : '100% Strict Confidentiality Protocol'}</span>
            </div>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-black bg-gradient-to-r from-white via-zinc-100 to-amber-200 bg-clip-text text-transparent tracking-tight">
              {isAr ? 'برامج التعافي والتأهيل النفسي والسلوكي' : 'Addiction Medicine & Behavioral Recovery Retreats'}
            </h1>
            <p className="text-zinc-300 text-sm sm:text-base leading-relaxed">
              {isAr
                ? 'نوفر مسارات علاجية وتأهيلية في منتجعات استشفائية هادئة ومعزولة ومرخصة رسمياً، تعتمد على بروتوكولات علمية حديثة لسحب السموم بدون ألم، مع برامج العلاج السلوكي والدعم الأسري المستمر.'
                : 'Providing evidence-based addiction treatment and holistic psychological healing in secluded, high-amenity campuses with complete privacy.'}
            </p>
            <div className="pt-2 flex flex-wrap gap-3">
              <button
                onClick={() => openRequestModalForService('addiction_rehab')}
                className="bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black font-extrabold px-6 py-3.5 rounded-xl text-xs sm:text-sm transition-all shadow-xl shadow-amber-500/20 flex items-center gap-2"
              >
                <Lock className="w-4 h-4 text-black" />
                <span>{isAr ? 'طلب استشارة سرية خاصة' : 'Request Confidential Consultation'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* 4 Pillars of Rehab */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-zinc-950 p-6 rounded-2xl border border-zinc-800 space-y-2">
            <div className="w-10 h-10 rounded-xl bg-black border border-[#D4AF37]/40 text-amber-300 flex items-center justify-center font-bold">
              01
            </div>
            <h3 className="font-bold text-white text-sm">
              {isAr ? 'سحب السموم بدون ألم (Detox)' : 'Pain-Free Detox'}
            </h3>
            <p className="text-xs text-zinc-400 leading-relaxed">
              {isAr ? 'إشراف طبي دائم على مدار الساعة للسيطرة الكاملة على الأعراض الانسحابية بأمان تام.' : '24/7 medical supervision to safely and comfortably manage withdrawal symptoms.'}
            </p>
          </div>

          <div className="bg-zinc-950 p-6 rounded-2xl border border-zinc-800 space-y-2">
            <div className="w-10 h-10 rounded-xl bg-black border border-[#D4AF37]/40 text-amber-300 flex items-center justify-center font-bold">
              02
            </div>
            <h3 className="font-bold text-white text-sm">
              {isAr ? 'العلاج السلوكي المعرفي (CBT)' : 'Cognitive Behavioral Therapy'}
            </h3>
            <p className="text-xs text-zinc-400 leading-relaxed">
              {isAr ? 'جلسات فردية وجماعية مع كبار الاستشاريين لتعديل السلوك وبناء أنماط حياة صحية جديدة.' : 'Individual and group psychotherapy focused on cognitive reframing and habit rebuilding.'}
            </p>
          </div>

          <div className="bg-zinc-950 p-6 rounded-2xl border border-zinc-800 space-y-2">
            <div className="w-10 h-10 rounded-xl bg-black border border-[#D4AF37]/40 text-amber-300 flex items-center justify-center font-bold">
              03
            </div>
            <h3 className="font-bold text-white text-sm">
              {isAr ? 'إشراك ودعم الأسرة' : 'Family Guidance & Healing'}
            </h3>
            <p className="text-xs text-zinc-400 leading-relaxed">
              {isAr ? 'جلسات إرشاد وتوجيه أسري مكثف لإعادة بناء جسور الثقة والتواصل السليم.' : 'Family counseling sessions to restore trust, communication, and emotional resilience.'}
            </p>
          </div>

          <div className="bg-zinc-950 p-6 rounded-2xl border border-zinc-800 space-y-2">
            <div className="w-10 h-10 rounded-xl bg-black border border-[#D4AF37]/40 text-amber-300 flex items-center justify-center font-bold">
              04
            </div>
            <h3 className="font-bold text-white text-sm">
              {isAr ? 'رعاية ممتدة بعد الخروج' : 'Extended 1-Year Aftercare'}
            </h3>
            <p className="text-xs text-zinc-400 leading-relaxed">
              {isAr ? 'متابعة دورية مستمرة لعام كامل لتمكين المتعافي ومنع أي انتكاسة محتملة.' : 'Structured follow-up program and alumni group support to ensure long-term sobriety.'}
            </p>
          </div>
        </div>

        {/* Centers Directory */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-black bg-gradient-to-r from-white to-amber-200 bg-clip-text text-transparent">
                {isAr ? 'مراكز التأهيل المعتمدة التي تم التحقق من بياناتها' : 'Verified Partner Rehabilitation Campuses'}
              </h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                {isAr ? 'تم التحقق من تراخيص وزارة الصحة ومعايير السلامة والأمن' : 'Formally verified against regulatory licensing and privacy standards'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {rehabCenters.map(center => (
              <div 
                key={center.id}
                className="bg-zinc-950 rounded-3xl border border-[#D4AF37]/30 hover:border-[#D4AF37] p-7 shadow-xl hover:shadow-[0_0_20px_rgba(212,175,55,0.2)] transition-all flex flex-col justify-between"
              >
                <div className="space-y-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2 text-xs text-amber-400 font-bold mb-1">
                        <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
                        <span>{isAr ? 'ترخيص رسمي معتمد' : 'Verified & Licensed'}</span>
                      </div>
                      <h3 className="text-xl font-bold text-white">
                        {isAr ? center.nameAr : center.nameEn}
                      </h3>
                      <div className="flex items-center gap-1.5 text-xs text-zinc-400 mt-1">
                        <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
                        <span>{center.location}</span>
                      </div>
                    </div>
                    <span className="text-xs bg-[#D4AF37]/20 text-amber-300 border border-[#D4AF37]/40 font-bold px-3 py-1 rounded-full whitespace-nowrap">
                      {isAr ? center.confidentialityLevel : 'Strictly Confidential'}
                    </span>
                  </div>

                  <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
                    {isAr ? center.descriptionAr : center.descriptionEn}
                  </p>

                  <div>
                    <div className="text-xs font-bold text-amber-200 mb-2">
                      {isAr ? 'البرامج العلاجية المعتمدة:' : 'Accredited Programs:'}
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {center.programs.map((prog, pIdx) => (
                        <div key={pIdx} className="flex items-center gap-2 text-xs text-zinc-300 bg-black p-2.5 rounded-lg border border-zinc-900">
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
                          <span>{prog}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <div className="text-xs font-bold text-amber-200 mb-2">
                      {isAr ? 'المرافق والتجهيزات الفندقية:' : 'Resort Amenities:'}
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {center.amenities.map((am, aIdx) => (
                        <span key={aIdx} className="text-[11px] bg-black border border-zinc-800 text-zinc-400 px-2.5 py-1 rounded-md">
                          {am}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-zinc-900">
                  <button
                    onClick={() => openRequestModalForService('addiction_rehab')}
                    className="w-full py-3 bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20"
                  >
                    <Send className="w-4 h-4 text-black" />
                    <span>{isAr ? 'طلب التواصل السري مع إدارة هذا المركز' : 'Request Confidential Placement'}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
