import React, { useState } from 'react';
import {
  Settings as SettingsIcon,
  Save,
  Download,
  Upload,
  Printer,
  Smartphone,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Package,
  Copy,
  ExternalLink,
} from 'lucide-react';
import { SettingItem } from '../db/indexedDB';
import { sound } from '../utils/sound';
import { PWAInstallButton } from '../components/PWAInstallButton';

interface SettingsViewProps {
  settings: Record<string, string | number>;
  groups: string[];
  onSaveSettings: (settings: Record<string, string | number>, groups: string[]) => Promise<void>;
  onExportBackup: () => Promise<void>;
  onImportBackup: (file: File) => Promise<void>;
  onTestPrint: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  groups,
  onSaveSettings,
  onExportBackup,
  onImportBackup,
  onTestPrint,
}) => {
  const [companyName, setCompanyName] = useState(String(settings.companyName || ''));
  const [companyPhone, setCompanyPhone] = useState(String(settings.companyPhone || ''));
  const [companyAddress, setCompanyAddress] = useState(String(settings.companyAddress || ''));
  const [taxNo, setTaxNo] = useState(String(settings.taxNo || ''));
  const [receiptFooter, setReceiptFooter] = useState(String(settings.receiptFooter || ''));
  const [monthlyDiscountRate, setMonthlyDiscountRate] = useState(Number(settings.monthlyDiscountRate) || 5);
  const [dailyTarget, setDailyTarget] = useState(Number(settings.dailyTarget) || 15000);
  const [monthlyTarget, setMonthlyTarget] = useState(Number(settings.monthlyTarget) || 350000);
  const [vanSafetyThreshold, setVanSafetyThreshold] = useState(Number(settings.vanSafetyThreshold) || 15);

  const [customGroups, setCustomGroups] = useState<string[]>(groups);
  const [showBluetoothHelp, setShowBluetoothHelp] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [copyToast, setCopyToast] = useState<string | null>(null);

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    sound.playSuccess();
    setCopyToast(`تم نسخ ${label} بنجاح!`);
    setTimeout(() => setCopyToast(null), 3000);
  };

  const handleGroupChange = (index: number, val: string) => {
    const updated = [...customGroups];
    updated[index] = val;
    setCustomGroups(updated);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await onSaveSettings(
        {
          companyName: companyName.trim(),
          companyPhone: companyPhone.trim(),
          companyAddress: companyAddress.trim(),
          taxNo: taxNo.trim(),
          receiptFooter: receiptFooter.trim(),
          monthlyDiscountRate,
          dailyTarget,
          monthlyTarget,
          vanSafetyThreshold,
        },
        customGroups
      );
      sound.playSuccess();
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch {
      sound.playError();
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (confirm('تنبيه: استعادة النسخة الاحتياطية ستقوم باستبدال كافة البيانات الحالية. هل تود المتابعة؟')) {
        await onImportBackup(file);
      }
    }
  };

  return (
    <div className="space-y-4 pb-28 pt-2 text-right">
      {/* Title Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-lg flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
            <SettingsIcon className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-white">إعدادات النظام والشركة</h1>
            <p className="text-xs text-slate-400">تخصيص بيانات الفاتورة والنسخ الاحتياطي</p>
          </div>
        </div>

        {/* PWA Install Button */}
        <PWAInstallButton />
      </div>

      {/* App Download & ZIP Links Card */}
      <div className="bg-gradient-to-l from-amber-950/40 via-slate-900 to-slate-900 border border-amber-500/30 rounded-3xl p-4 shadow-lg space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="text-xs font-bold text-white">روابط تحميل وتشغيل التطبيق وملف الـ ZIP</h2>
              <p className="text-[11px] text-slate-400">
                تشغيل وتثبيت التطبيق على الهاتف بدون إنترنت، أو تحميل الحزمة البرمجية الكاملة
              </p>
            </div>
          </div>
          {copyToast && (
            <span className="text-[11px] font-bold text-emerald-300 bg-emerald-500/20 border border-emerald-500/35 px-2.5 py-1 rounded-full animate-fade-in">
              {copyToast}
            </span>
          )}
        </div>

        <div className="space-y-2.5 text-xs">
          {/* Direct ZIP Archive Download */}
          <div className="bg-emerald-950/30 border border-emerald-500/40 p-3 rounded-2xl flex items-center justify-between gap-2">
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5 text-emerald-300 font-bold text-xs mb-0.5">
                <Package className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>تحميل المشروع بالكامل (ملف ZIP مضغوط):</span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded border border-emerald-500/30">
                  372 KB
                </span>
              </div>
              <span className="font-mono text-[11px] text-slate-300 select-all break-all block truncate">
                https://ais-dev-oxwvwsbk3bzhrnlrwlrm6e-591247979635.europe-west3.run.app/salespro-applet.zip
              </span>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <a
                href="/salespro-applet.zip"
                download="salespro-applet.zip"
                className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black rounded-xl text-xs flex items-center gap-1.5 active:scale-95 transition shadow-sm"
              >
                <Download className="w-3.5 h-3.5" />
                <span>تحميل ZIP</span>
              </a>
              <button
                type="button"
                onClick={() =>
                  handleCopy(
                    'https://ais-dev-oxwvwsbk3bzhrnlrwlrm6e-591247979635.europe-west3.run.app/salespro-applet.zip',
                    'رابط ملف الـ ZIP'
                  )
                }
                className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 font-bold rounded-xl text-xs active:scale-95 transition"
                title="نسخ الرابط"
              >
                نسخ الرابط
              </button>
            </div>
          </div>

          {/* Shared App URL */}
          <div className="bg-slate-850 p-2.5 rounded-2xl border border-slate-750 flex items-center justify-between gap-2">
            <div className="min-w-0 flex-1">
              <span className="text-[10px] text-amber-400 font-bold block">
                رابط التشغيل والمشاركة المباشر (الموصى به للمندوبين):
              </span>
              <span className="font-mono text-[11px] text-white select-all break-all block truncate">
                https://ais-pre-oxwvwsbk3bzhrnlrwlrm6e-591247979635.europe-west3.run.app
              </span>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <a
                href="https://ais-pre-oxwvwsbk3bzhrnlrwlrm6e-591247979635.europe-west3.run.app"
                target="_blank"
                rel="noreferrer"
                className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl border border-slate-700 transition"
                title="فتح الرابط"
              >
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
              <button
                type="button"
                onClick={() =>
                  handleCopy(
                    'https://ais-pre-oxwvwsbk3bzhrnlrwlrm6e-591247979635.europe-west3.run.app',
                    'رابط التطبيق المباشر'
                  )
                }
                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl text-xs active:scale-95 transition"
              >
                نسخ الرابط
              </button>
            </div>
          </div>

          {/* Dev App URL */}
          <div className="bg-slate-850 p-2.5 rounded-2xl border border-slate-750 flex items-center justify-between gap-2">
            <div className="min-w-0 flex-1">
              <span className="text-[10px] text-sky-400 font-bold block">
                رابط بيئة التطوير المباشر (Development URL):
              </span>
              <span className="font-mono text-[11px] text-white select-all break-all block truncate">
                https://ais-dev-oxwvwsbk3bzhrnlrwlrm6e-591247979635.europe-west3.run.app
              </span>
            </div>
            <button
              type="button"
              onClick={() =>
                handleCopy(
                  'https://ais-dev-oxwvwsbk3bzhrnlrwlrm6e-591247979635.europe-west3.run.app',
                  'رابط بيئة التطوير'
                )
              }
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold rounded-xl text-xs active:scale-95 transition"
            >
              نسخ
            </button>
          </div>
        </div>

        <div className="text-[11px] text-slate-300 bg-slate-900/80 p-2.5 rounded-2xl border border-slate-800 leading-relaxed">
          💡 <strong className="text-white">طريقة التثبيت على الهاتف كـ تطبيق (WebAPK / PWA):</strong> افتح رابط التطبيق في متصفح Chrome أو Safari على هاتفك، ثم اضغط على القائمة (⋮ أو زر المشاركة) واختر <strong>"إضافة إلى الشاشة الرئيسية" (Add to Home screen)</strong> أو <strong>"تثبيت التطبيق"</strong>. سيقوم نظام أندرويد تلقائياً بإنشاء حزمة تطبيق أصلية كاملة تعمل دون إنترنت وبأيقونة مخصصة على شاشتك.
        </div>
      </div>

      {/* Main Settings Form */}
      <form onSubmit={handleSubmit} className="space-y-3.5">
        {/* Company Info Box */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-lg space-y-3">
          <h2 className="text-xs font-bold text-amber-400">بيانات الشركة وإيصال الفاتورة (80mm)</h2>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">اسم الشركة / المؤسسة</label>
            <input
              type="text"
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">رقم هاتف الشركة</label>
              <input
                type="text"
                value={companyPhone}
                onChange={(e) => setCompanyPhone(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-amber-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">الرقم الضريبي</label>
              <input
                type="text"
                value={taxNo}
                onChange={(e) => setTaxNo(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">عنوان الشركة والمخزن</label>
            <input
              type="text"
              value={companyAddress}
              onChange={(e) => setCompanyAddress(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">تذييل الإيصال المطبوع (Footer)</label>
            <input
              type="text"
              value={receiptFooter}
              onChange={(e) => setReceiptFooter(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
            />
          </div>
        </div>

        {/* Commercial Targets & Discount */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-lg space-y-3">
          <h2 className="text-xs font-bold text-emerald-400">السياسة المالية والأهداف</h2>

          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">الخصم الشهري %</label>
              <input
                type="number"
                min="0"
                max="100"
                value={monthlyDiscountRate}
                onChange={(e) => setMonthlyDiscountRate(Number(e.target.value) || 0)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-emerald-500 font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">الهدف اليومي (ج.م)</label>
              <input
                type="number"
                value={dailyTarget}
                onChange={(e) => setDailyTarget(Number(e.target.value) || 0)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-emerald-500 font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">الهدف الشهري (ج.م)</label>
              <input
                type="number"
                value={monthlyTarget}
                onChange={(e) => setMonthlyTarget(Number(e.target.value) || 0)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-emerald-500 font-bold"
              />
            </div>
          </div>
        </div>

        {/* Safety Stock Threshold Setting */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-lg space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-bold text-amber-400 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-400" />
              حد أمان رصيد السيارة وتنبيه النواقص
            </h2>
            <span className="text-[10px] bg-amber-500/15 text-amber-300 border border-amber-500/30 px-2.5 py-0.5 rounded-full font-bold">
              تنبيه مرئي في شاشة الجرد
            </span>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">
              حد أمان رصيد السيارة الافتراضي (بالقطع) *
            </label>
            <div className="relative">
              <input
                type="number"
                min="1"
                value={vanSafetyThreshold}
                onChange={(e) => setVanSafetyThreshold(Math.max(1, Number(e.target.value) || 1))}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-amber-500 font-bold"
                required
              />
              <span className="absolute left-3 top-2 text-xs text-slate-400 font-bold">قطعة</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1.5 leading-relaxed">
              عندما ينخفض رصيد أي صنف في سيارة التوزيع إلى أو أقل من هذا الحد، يظهر فوراً مؤشر تنبيه مرئي أحمر نابض ووميض تحذيري في شاشة جرد السيارة، مع زر فلترة سريع لتحديد النواقص وتحميلها من المخزن.
            </p>
          </div>
        </div>

        {/* 10 Customizable Product Groups */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-lg space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-bold text-sky-400">مجموعات الأصناف العشر (10 مجموعات)</h2>
            <span className="text-[10px] text-slate-400">تظهر في الفاتورة والمخزون</span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {customGroups.map((group, idx) => (
              <div key={idx} className="flex items-center gap-1.5">
                <span className="text-[10px] font-mono text-slate-500 w-4">{idx + 1}.</span>
                <input
                  type="text"
                  value={group}
                  onChange={(e) => handleGroupChange(idx, e.target.value)}
                  className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-sky-500"
                />
              </div>
            ))}
          </div>
        </div>

        {saveSuccess && (
          <div className="p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-2xl flex items-center gap-2 text-xs text-emerald-300">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>تم حفظ كافة الإعدادات والمجموعات بنجاح!</span>
          </div>
        )}

        <button
          type="submit"
          className="w-full py-3.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded-2xl text-xs flex items-center justify-center gap-2 active:scale-98 transition shadow-lg shadow-amber-950"
        >
          <Save className="w-4 h-4" />
          <span>حفظ جميع الإعدادات</span>
        </button>
      </form>

      {/* Printer Section */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-lg space-y-3">
        <h2 className="text-xs font-bold text-white flex items-center gap-2">
          <Printer className="w-4 h-4 text-amber-400" />
          مركز الطباعة وطابعات البلوتوث والـ USB
        </h2>
        <p className="text-xs text-slate-400 leading-relaxed">
          يدعم التطبيق الطباعة الحرارية المباشرة (80mm) لجميع طابعات البلوتوث المحمولة وUSB وشبكة Wi-Fi المعرفة على هاتف المندوب.
        </p>

        <div className="flex gap-2">
          <button
            onClick={onTestPrint}
            className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-750 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border border-slate-700 active:scale-95 transition"
          >
            <Printer className="w-4 h-4 text-emerald-400" />
            <span>اختبار طباعة إيصال تجريبي</span>
          </button>
          <button
            onClick={() => setShowBluetoothHelp(true)}
            className="py-2.5 px-3 bg-slate-800 hover:bg-slate-750 text-amber-400 rounded-xl text-xs font-bold flex items-center justify-center gap-1 border border-slate-700 active:scale-95 transition"
          >
            <HelpCircle className="w-4 h-4" />
            <span>تعليمات Bluetooth</span>
          </button>
        </div>
      </div>

      {/* Backup & Restore */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-lg space-y-3">
        <h2 className="text-xs font-bold text-white flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-sky-400" />
          النسخ الاحتياطي والاستعادة الشاملة
        </h2>
        <p className="text-xs text-slate-400 leading-relaxed">
          احفظ نسخة احتياطية مشفرة بملف JSON واحد يضم كل العملاء، خطوط السير، المخزون، الفواتير، والخزنة.
        </p>

        <div className="flex gap-2">
          <button
            onClick={onExportBackup}
            className="flex-1 py-2.5 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 active:scale-95 transition shadow-md shadow-sky-950"
          >
            <Download className="w-4 h-4" />
            <span>تصدير نسخة احتياطية (JSON)</span>
          </button>

          <label className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 active:scale-95 transition cursor-pointer">
            <Upload className="w-4 h-4 text-amber-400" />
            <span>استعادة من ملف</span>
            <input type="file" accept=".json" onChange={handleFileChange} className="hidden" />
          </label>
        </div>
      </div>

      {/* Bluetooth Guide Modal */}
      {showBluetoothHelp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 p-5 shadow-2xl text-right space-y-3">
            <h3 className="font-bold text-white text-sm flex items-center gap-2 pb-2 border-b border-slate-800">
              <Printer className="w-4 h-4 text-amber-400" />
              كيفية ربط طابعة البلوتوث المحمولة
            </h3>

            <div className="text-xs text-slate-300 space-y-2 leading-relaxed">
              <p>1. شغّل الطابعة الحرارية وفعّل البلوتوث بهاتفك.</p>
              <p>2. توجه إلى إعدادات الهاتف واقرن الطابعة (الرمز الافتراضي عادة 0000 أو 1234).</p>
              <p>3. في هواتف أندرويد، ثبّت خدمة طباعة البلوتوث المجانية الموصى بها لطابعتك (مثل RawBT أو Bluetooth Print).</p>
              <p>4. عند الضغط على "اعتماد وطباعة"، ستفتح نافذة الطباعة القياسية؛ اختر طابعتك وستطبع الفاتورة بدقة 80mm فوراً!</p>
            </div>

            <button
              onClick={() => setShowBluetoothHelp(false)}
              className="w-full py-2.5 bg-amber-500 text-slate-950 font-bold rounded-xl text-xs mt-2"
            >
              تم الفهم
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
