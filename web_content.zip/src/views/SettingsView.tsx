import React, { useState } from 'react';
import { Settings, ExternalLink, Save, CheckCircle2, ShieldCheck, Database } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const SettingsView: React.FC = () => {
  const { settings, updateSettings } = useApp();
  const [zohoUrl, setZohoUrl] = useState(settings.zohoUrl);
  const [isSaved, setIsSaved] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({ zohoUrl });
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header matching admin/settings.php */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">Phoenix PM Settings</h1>
        <p className="text-xs text-slate-500 mt-0.5">
          Configure the Zoho CRM / Books connection used by Phoenix Project Manager.
        </p>
      </div>

      {isSaved && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Settings saved successfully.</span>
        </div>
      )}

      {/* Settings Form */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-6">
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-900 text-sm mb-1">
              Zoho CRM / Books URL
            </label>
            <input
              type="url"
              required
              value={zohoUrl}
              onChange={(e) => setZohoUrl(e.target.value)}
              placeholder="https://www.zoho.com/crm/"
              className="w-full max-w-lg px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono text-xs focus:outline-hidden focus:border-red-500"
            />
            <p className="text-slate-500 text-[11px] mt-1.5">
              Enter your Zoho CRM URL. This will be used to open Zoho from Phoenix Project Manager client rows, project overviews, and import sessions.
            </p>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold cursor-pointer shadow-xs transition-colors flex items-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Settings</span>
            </button>
          </div>
        </form>

        <hr className="border-slate-100" />

        {/* Direct Zoho CRM launch section matching admin/settings.php */}
        <div className="space-y-2">
          <h2 className="text-sm font-bold text-slate-900">Zoho CRM Direct Access</h2>
          <p className="text-xs text-slate-500">
            Phoenix Project Manager can open your Zoho CRM from the project management system.
          </p>
          <a
            href={zohoUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-xs transition-colors"
          >
            <span>Open Zoho CRM</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>

      {/* System Status Table matching admin/dashboard.php */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100">
          <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Database className="w-4 h-4 text-red-600" />
            <span>WordPress Plugin Module Invariants & Database Schema</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">Tables verified against database/install.php</p>
        </div>

        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
            <tr>
              <th className="py-2.5 px-4 w-60">WordPress Table / Module</th>
              <th className="py-2.5 px-4">Database Structure</th>
              <th className="py-2.5 px-4">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            <tr>
              <td className="py-2.5 px-4 font-mono font-medium">wp_ppm_clients</td>
              <td className="py-2.5 px-4 text-slate-600">company, contact_person, email, username, password, zoho_contact_id</td>
              <td className="py-2.5 px-4 text-emerald-700 font-semibold">Active & Synced</td>
            </tr>
            <tr>
              <td className="py-2.5 px-4 font-mono font-medium">wp_ppm_projects</td>
              <td className="py-2.5 px-4 text-slate-600">client_id, project_name, location, status, start_date, end_date</td>
              <td className="py-2.5 px-4 text-emerald-700 font-semibold">Active & Synced</td>
            </tr>
            <tr>
              <td className="py-2.5 px-4 font-mono font-medium">wp_ppm_employees</td>
              <td className="py-2.5 px-4 text-slate-600">employee_code, employee_name, photo, aadhaar, pan, blood_group</td>
              <td className="py-2.5 px-4 text-emerald-700 font-semibold">Active & Synced</td>
            </tr>
            <tr>
              <td className="py-2.5 px-4 font-mono font-medium">wp_ppm_project_employees</td>
              <td className="py-2.5 px-4 text-slate-600">project_id, employee_id mapping</td>
              <td className="py-2.5 px-4 text-emerald-700 font-semibold">Active & Synced</td>
            </tr>
            <tr>
              <td className="py-2.5 px-4 font-mono font-medium">wp_ppm_tasks</td>
              <td className="py-2.5 px-4 text-slate-600">project_id, task_name, assigned_to, priority, status, due_date</td>
              <td className="py-2.5 px-4 text-emerald-700 font-semibold">Active & Synced</td>
            </tr>
            <tr>
              <td className="py-2.5 px-4 font-mono font-medium">wp_ppm_documents</td>
              <td className="py-2.5 px-4 text-slate-600">project_id, uploaded_by, document_name, document_type, file_path</td>
              <td className="py-2.5 px-4 text-emerald-700 font-semibold">Active & Synced</td>
            </tr>
            <tr>
              <td className="py-2.5 px-4 font-mono font-medium">wp_ppm_conversations</td>
              <td className="py-2.5 px-4 text-slate-600">sender_type, sender_id, message, audio_url, audio_duration, is_read</td>
              <td className="py-2.5 px-4 text-emerald-700 font-semibold">Active & Synced</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};
