import React from 'react';
import {
  LockKeyhole,
  Unlock,
  Printer,
  CheckCircle2,
  AlertTriangle,
  Calendar,
  Wallet,
  TrendingUp,
  Users,
} from 'lucide-react';
import { Invoice, ReturnRecord, Visit, TreasuryMove } from '../db/indexedDB';
import { formatMoney, getTodayDateString, getArabicDayName } from '../utils/calc';
import { sound } from '../utils/sound';

interface DayCloseViewProps {
  isClosed: boolean;
  invoices: Invoice[];
  returns: ReturnRecord[];
  visits: Visit[];
  treasuryMoves: TreasuryMove[];
  onCloseBusinessDay: () => Promise<void>;
  onReopenBusinessDay: () => Promise<void>;
  onPrintDailySummary: () => void;
}

export const DayCloseView: React.FC<DayCloseViewProps> = ({
  isClosed,
  invoices,
  returns,
  visits,
  treasuryMoves,
  onCloseBusinessDay,
  onReopenBusinessDay,
  onPrintDailySummary,
}) => {
  const todayStr = getTodayDateString();
  const dayName = getArabicDayName(todayStr);

  const todayInvoices = invoices.filter((i) => i.date?.slice(0, 10) === todayStr);
  const todayReturns = returns.filter((r) => r.date?.slice(0, 10) === todayStr);
  const todayVisits = visits.filter((v) => v.date === todayStr);
  const todayMoves = treasuryMoves.filter((m) => m.date?.slice(0, 10) === todayStr);

  const totalSales = todayInvoices.reduce((a, i) => a + Number(i.grandTotal || 0), 0);
  const totalReturnAmount = todayReturns.reduce((a, r) => a + Number(r.amount || 0), 0);
  const totalIncome = todayMoves.filter((m) => m.type === 'إيراد').reduce((a, m) => a + m.amount, 0);
  const totalExpense = todayMoves.filter((m) => m.type === 'مصروف').reduce((a, m) => a + m.amount, 0);
  const cashBalance = totalIncome - totalExpense;

  const handleCloseDay = async () => {
    if (!confirm('هل أنت متأكد من رغبتك في إغلاق اليوم البيعي؟ سيتم قفل إنشاء فواتير جديدة.')) {
      return;
    }
    await onCloseBusinessDay();
    sound.playSuccess();
  };

  const handleReopen = async () => {
    if (!confirm('إعادة فتح اليوم تسمح بتعديل وإضافة عمليات جديدة. هل تريد المتابعة؟')) {
      return;
    }
    await onReopenBusinessDay();
    sound.playSuccess();
  };

  return (
    <div className="space-y-3.5 pb-24 pt-2">
      {/* Status Card */}
      <div
        className={`border rounded-3xl p-5 shadow-xl text-center space-y-3 ${
          isClosed
            ? 'bg-gradient-to-br from-emerald-950/60 to-slate-900 border-emerald-500/40 text-emerald-300'
            : 'bg-gradient-to-br from-amber-950/60 to-slate-900 border-amber-500/40 text-amber-300'
        }`}
      >
        <div
          className={`w-14 h-14 mx-auto rounded-3xl flex items-center justify-center text-xl shadow-lg ${
            isClosed
              ? 'bg-emerald-500 text-slate-950 shadow-emerald-500/20'
              : 'bg-amber-500 text-slate-950 shadow-amber-500/20'
          }`}
        >
          {isClosed ? <LockKeyhole className="w-7 h-7" /> : <Unlock className="w-7 h-7" />}
        </div>

        <div>
          <h2 className="text-lg font-black text-white">
            {isClosed ? 'اليوم البيعي مُغلق ومعتمد بنجاح' : 'اليوم البيعي مفتوح حالياً'}
          </h2>
          <p className="text-xs text-slate-300 mt-1 font-mono">
            {dayName} • {todayStr}
          </p>
        </div>

        <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
          {isClosed
            ? 'تم إقفال حركات المبيعات والخزنة لهذا اليوم. يمكنك طباعة ملخص اليوم الشامل أو إعادة فتح اليوم إذا لزم الأمر.'
            : 'تأكد من مطابقة الخزنة ورصيد حمولة السيارة وجرد المرتجعات قبل اعتماد الإغلاق النهائي.'}
        </p>
      </div>

      {/* Daily Audit Numbers */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 text-center">
          <span className="text-[10px] text-slate-400 block font-bold">إجمالي مبيعات اليوم</span>
          <span className="text-base font-black font-mono text-emerald-400 block mt-0.5">
            {formatMoney(totalSales)}
          </span>
          <span className="text-[10px] text-slate-400">ج.م</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 text-center">
          <span className="text-[10px] text-slate-400 block font-bold">إجمالي المرتجعات</span>
          <span className="text-base font-black font-mono text-rose-400 block mt-0.5">
            {formatMoney(totalReturnAmount)}
          </span>
          <span className="text-[10px] text-slate-400">ج.م</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 text-center">
          <span className="text-[10px] text-slate-400 block font-bold">صافي رصيد الخزنة</span>
          <span className="text-base font-black font-mono text-amber-400 block mt-0.5">
            {formatMoney(cashBalance)}
          </span>
          <span className="text-[10px] text-slate-400">ج.م</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 text-center">
          <span className="text-[10px] text-slate-400 block font-bold">الزيارات المنجزة</span>
          <span className="text-base font-black font-mono text-white block mt-0.5">
            {todayVisits.length}
          </span>
          <span className="text-[10px] text-slate-400">عميل</span>
        </div>
      </div>

      {/* Pre-close Checklist */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 space-y-3 shadow-lg">
        <h3 className="text-xs font-bold text-white flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          قائمة التحقق قبل الإغلاق النهائي
        </h3>

        <ul className="text-xs text-slate-300 space-y-2">
          <li className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            <span>مراجعة جميع الفواتير المعتمدة وإجمالي التحصيل الكاش.</span>
          </li>
          <li className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            <span>مطابقة النقدية الفعلية في خزنة السيارة مع رصيد النظام ({formatMoney(cashBalance)} ج.م).</span>
          </li>
          <li className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            <span>تسجيل المرتجعات التالفة أو السليمة للسيارة والمخزن.</span>
          </li>
          <li className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            <span>التأكد من تسجيل حالات زيارات خط السير اليومية.</span>
          </li>
        </ul>
      </div>

      {/* Action Buttons */}
      <div className="space-y-2 pt-2">
        {!isClosed ? (
          <button
            onClick={handleCloseDay}
            className="w-full py-3.5 bg-rose-600 hover:bg-rose-500 text-white font-black rounded-2xl text-xs flex items-center justify-center gap-2 shadow-xl shadow-rose-950 active:scale-98 transition"
          >
            <LockKeyhole className="w-4 h-4" />
            <span>اعتماد إغلاق اليوم البيعي</span>
          </button>
        ) : (
          <button
            onClick={handleReopen}
            className="w-full py-3.5 bg-slate-800 hover:bg-slate-700 text-amber-400 font-bold rounded-2xl text-xs flex items-center justify-center gap-2 border border-slate-700 active:scale-98 transition"
          >
            <Unlock className="w-4 h-4" />
            <span>إعادة فتح اليوم البيعي للتعديل</span>
          </button>
        )}

        <button
          onClick={onPrintDailySummary}
          className="w-full py-3.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded-2xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-950 active:scale-98 transition"
        >
          <Printer className="w-4 h-4" />
          <span>طباعة تقرير إجمالي اليوم الشامل</span>
        </button>
      </div>
    </div>
  );
};
