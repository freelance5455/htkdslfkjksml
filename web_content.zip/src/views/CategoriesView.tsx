import React, { useState } from 'react';
import {
  Dumbbell,
  Sparkles,
  Utensils,
  Droplets,
  Scissors,
  UserCheck,
  Moon,
  Plus,
  Check,
  Timer,
  Clock,
  Flame,
  Award,
  ChevronRight
} from 'lucide-react';
import { Activity, ActivityCategory, AppState, DayRecord } from '../types';
import { calculateDailyNutrition, calculateDailyProgress, calculateSleepDuration } from '../utils/tracker';
import { playChimeSound } from '../utils/notifications';

interface CategoriesViewProps {
  state: AppState;
  activeDateStr: string;
  initialCategory?: ActivityCategory;
  onToggleTask: (activityId: string) => void;
  onAddWater: (amountMl: number) => void;
  onOpenTimer: (exerciseName: string, restSecs: number) => void;
  onEditActivity: (activity: Activity) => void;
  onOpenAddModal: () => void;
  onUpdateSleep: (bedtime: string, wakeTime: string) => void;
}

export const CategoriesView: React.FC<CategoriesViewProps> = ({
  state,
  activeDateStr,
  initialCategory = 'workout',
  onToggleTask,
  onAddWater,
  onOpenTimer,
  onEditActivity,
  onOpenAddModal,
  onUpdateSleep,
}) => {
  const [activeCategory, setActiveCategory] = useState<ActivityCategory>(initialCategory);
  const [bedtimeInput, setBedtimeInput] = useState('23:00');
  const [wakeTimeInput, setWakeTimeInput] = useState('07:00');

  const dayRecord: DayRecord | undefined = state.history[activeDateStr];
  const nutrition = calculateDailyNutrition(state.activities, dayRecord, activeDateStr);

  const categories = [
    { id: 'workout' as ActivityCategory, label: 'Gym & Workout', icon: Dumbbell, desc: 'Sets, Reps & Rest' },
    { id: 'skincare' as ActivityCategory, label: 'Skincare', icon: Sparkles, desc: 'AM & PM Routines' },
    { id: 'nutrition' as ActivityCategory, label: 'Diet & Food', icon: Utensils, desc: 'Calories & Protein' },
    { id: 'water' as ActivityCategory, label: 'Water Tracker', icon: Droplets, desc: 'Hydration Goal' },
    { id: 'grooming' as ActivityCategory, label: 'Hair & Grooming', icon: Scissors, desc: 'Daily & Weekly' },
    { id: 'posture' as ActivityCategory, label: 'Posture & Core', icon: UserCheck, desc: 'Alignment & Stretches' },
    { id: 'sleep' as ActivityCategory, label: 'Sleep & Rest', icon: Moon, desc: 'Restorative Sleep' },
  ];

  // Activities under active category
  const categoryActivities = state.activities.filter((a) => a.category === activeCategory);
  categoryActivities.sort((a, b) => a.scheduledTime.localeCompare(b.scheduledTime));

  const completedCount = categoryActivities.filter((a) => dayRecord?.tasks?.[a.id]?.completed).length;
  const categoryPercentage = categoryActivities.length > 0 ? Math.round((completedCount / categoryActivities.length) * 100) : 0;

  const handleTaskClick = (actId: string) => {
    playChimeSound('complete');
    onToggleTask(actId);
  };

  const handleSaveSleep = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSleep(bedtimeInput, wakeTimeInput);
    playChimeSound('complete');
  };

  const waterConsumed = dayRecord?.waterConsumedMl || 0;
  const waterGoal = state.profile.waterGoalMl || 3000;
  const sleepDurationMins = calculateSleepDuration(
    dayRecord?.sleepBedtime || bedtimeInput,
    dayRecord?.sleepWakeTime || wakeTimeInput
  );
  const sleepHours = (sleepDurationMins / 60).toFixed(1);

  return (
    <div className="space-y-6 pb-24">
      {/* Category Horizontal Selector */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        {categories.map((cat) => {
          const Icon = cat.icon;
          const isActive = activeCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`flex items-center gap-2 py-2.5 px-3.5 rounded-2xl text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
                isActive
                  ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-sm'
                  : 'bg-white dark:bg-[#13151B] text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:border-slate-300'
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Category Overview Card */}
      <div className="rounded-3xl bg-white dark:bg-[#13151B] border border-slate-100 dark:border-slate-800 p-5 shadow-sm">
        <div className="flex items-center justify-between gap-4">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-purple-600 dark:text-purple-400">
              Pillar Focus
            </span>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white mt-0.5">
              {categories.find((c) => c.id === activeCategory)?.label}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {completedCount} of {categoryActivities.length} activities completed today ({categoryPercentage}%)
            </p>
          </div>

          <button
            onClick={onOpenAddModal}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold shadow-sm transition-all shrink-0 active:scale-95"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Item</span>
          </button>
        </div>

        {/* Progress bar */}
        <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2 mt-4 overflow-hidden">
          <div
            className="bg-purple-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${categoryPercentage}%` }}
          />
        </div>
      </div>

      {/* SPECIFIC CATEGORY WIDGETS */}
      {/* 1. Diet & Nutrition Widget */}
      {activeCategory === 'nutrition' && (
        <div className="rounded-3xl bg-white dark:bg-[#13151B] border border-slate-100 dark:border-slate-800 p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Daily Macro Tracking
            </h3>
            <span className="text-xs text-slate-500 tabular-nums">
              Target: {state.profile.calorieGoal} kcal / {state.profile.proteinGoalG}g P
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 mb-4">
            <div className="p-3.5 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30">
              <span className="text-[11px] font-semibold text-emerald-700 dark:text-emerald-300 block">CALORIES CONSUMED</span>
              <div className="text-xl font-extrabold text-slate-900 dark:text-white mt-1 tabular-nums">
                {nutrition.calories} <span className="text-xs font-normal text-slate-400">kcal</span>
              </div>
              <div className="w-full bg-emerald-200/50 dark:bg-emerald-900/40 rounded-full h-1.5 mt-2 overflow-hidden">
                <div
                  className="bg-emerald-600 h-1.5 rounded-full"
                  style={{ width: `${Math.min(100, (nutrition.calories / (state.profile.calorieGoal || 2200)) * 100)}%` }}
                />
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-purple-50/50 dark:bg-purple-950/20 border border-purple-100 dark:border-purple-900/30">
              <span className="text-[11px] font-semibold text-purple-700 dark:text-purple-300 block">PROTEIN TARGET</span>
              <div className="text-xl font-extrabold text-slate-900 dark:text-white mt-1 tabular-nums">
                {nutrition.protein} <span className="text-xs font-normal text-slate-400">g</span>
              </div>
              <div className="w-full bg-purple-200/50 dark:bg-purple-900/40 rounded-full h-1.5 mt-2 overflow-hidden">
                <div
                  className="bg-purple-600 h-1.5 rounded-full"
                  style={{ width: `${Math.min(100, (nutrition.protein / (state.profile.proteinGoalG || 140)) * 100)}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. Water Tracker Widget */}
      {activeCategory === 'water' && (
        <div className="rounded-3xl bg-white dark:bg-[#13151B] border border-slate-100 dark:border-slate-800 p-6 shadow-sm text-center">
          <div className="w-14 h-14 rounded-3xl bg-cyan-50 dark:bg-cyan-950/40 text-cyan-600 dark:text-cyan-400 flex items-center justify-center mx-auto mb-3">
            <Droplets className="w-7 h-7" />
          </div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">
            Daily Water Hydration Goal
          </h3>
          <p className="text-xs text-slate-500 mb-6 max-w-sm mx-auto">
            Proper water intake purifies circulation, maintains skin hydration, and eliminates facial water retention puffiness.
          </p>

          <div className="relative w-40 h-40 mx-auto flex items-center justify-center mb-6">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="42" className="text-slate-100 dark:text-slate-800" strokeWidth="8" stroke="currentColor" fill="transparent" />
              <circle
                cx="50" cy="50" r="42"
                className="text-cyan-500 transition-all duration-300"
                strokeWidth="8"
                strokeDasharray={263.9}
                strokeDashoffset={263.9 - (263.9 * Math.min(100, (waterConsumed / waterGoal) * 100)) / 100}
                strokeLinecap="round"
                stroke="currentColor"
                fill="transparent"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-2xl font-extrabold text-slate-900 dark:text-white tabular-nums">
                {waterConsumed}
              </span>
              <span className="text-[11px] text-slate-400">/ {waterGoal} ml</span>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-2 max-w-sm mx-auto">
            {[150, 250, 500, 1000].map((amt) => (
              <button
                key={amt}
                onClick={() => onAddWater(amt)}
                className="py-2.5 px-2 rounded-2xl bg-cyan-50 dark:bg-cyan-950/40 text-cyan-700 dark:text-cyan-300 hover:bg-cyan-100 dark:hover:bg-cyan-900/60 font-semibold text-xs border border-cyan-100 dark:border-cyan-800/40 active:scale-95 transition-transform"
              >
                +{amt}ml
              </button>
            ))}
          </div>
        </div>
      )}

      {/* 3. Sleep Tracker Widget */}
      {activeCategory === 'sleep' && (
        <div className="rounded-3xl bg-white dark:bg-[#13151B] border border-slate-100 dark:border-slate-800 p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <Moon className="w-4 h-4 text-purple-600" />
              <span>Sleep Schedule & Restoration</span>
            </h3>
            <span className="text-xs font-semibold text-purple-600 dark:text-purple-400 tabular-nums">
              {sleepHours} Hours Rest
            </span>
          </div>

          <form onSubmit={handleSaveSleep} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                Target Bedtime
              </label>
              <input
                type="time"
                value={bedtimeInput}
                onChange={(e) => setBedtimeInput(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                Wake-up Time
              </label>
              <input
                type="time"
                value={wakeTimeInput}
                onChange={(e) => setWakeTimeInput(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
              />
            </div>
            <div className="flex items-end">
              <button
                type="submit"
                className="w-full py-2.5 px-4 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold shadow-sm transition-all"
              >
                Save Schedule
              </button>
            </div>
          </form>
        </div>
      )}

      {/* 4. Activities Checklist for Selected Category */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white">
          Active Routines
        </h3>

        {categoryActivities.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 p-8 text-center">
            <p className="text-xs text-slate-400 mb-3">No routines created in this category yet.</p>
            <button
              onClick={onOpenAddModal}
              className="px-3.5 py-1.5 rounded-xl bg-purple-600 text-white text-xs font-semibold"
            >
              Add First Activity
            </button>
          </div>
        ) : (
          <div className="space-y-2.5">
            {categoryActivities.map((act) => {
              const isCompleted = Boolean(dayRecord?.tasks?.[act.id]?.completed);

              return (
                <div
                  key={act.id}
                  onClick={() => handleTaskClick(act.id)}
                  className={`group rounded-2xl p-4 border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                    isCompleted
                      ? 'bg-slate-50/70 dark:bg-slate-900/40 border-slate-200/60 dark:border-slate-800/60 opacity-90'
                      : 'bg-white dark:bg-[#13151B] border-slate-200 dark:border-slate-800 hover:border-purple-300'
                  }`}
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleTaskClick(act.id);
                      }}
                      className={`w-7 h-7 rounded-xl flex items-center justify-center transition-all shrink-0 ${
                        isCompleted
                          ? 'bg-purple-600 text-white shadow-sm shadow-purple-600/30'
                          : 'border-2 border-slate-300 dark:border-slate-600 hover:border-purple-500 bg-white dark:bg-slate-900'
                      }`}
                      aria-label={isCompleted ? `Mark ${act.name} incomplete` : `Mark ${act.name} complete`}
                    >
                      {isCompleted && <Check className="w-4 h-4 stroke-[3]" />}
                    </button>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 mb-0.5">
                        <span className="flex items-center gap-1 tabular-nums font-medium">
                          <Clock className="w-3 h-3" />
                          {act.scheduledTime}
                        </span>
                        {act.routineType && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="capitalize">{act.routineType} Routine</span>
                          </>
                        )}
                        {act.workoutCategory && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>{act.workoutCategory}</span>
                          </>
                        )}
                      </div>

                      <h4
                        className={`text-sm font-semibold truncate ${
                          isCompleted
                            ? 'line-through text-slate-400 dark:text-slate-500'
                            : 'text-slate-900 dark:text-white'
                        }`}
                      >
                        {act.name}
                      </h4>

                      <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2 mt-0.5">
                        {act.sets && act.reps && (
                          <span className="tabular-nums font-medium">
                            {act.sets} sets × {act.reps} reps
                          </span>
                        )}
                        {act.sets && act.durationSeconds && (
                          <span className="tabular-nums font-medium">
                            {act.sets} × {act.durationSeconds}s
                          </span>
                        )}
                        {act.calories !== undefined && (
                          <span className="tabular-nums text-emerald-600 dark:text-emerald-400 font-medium">
                            {act.calories} kcal · {act.protein}g P
                          </span>
                        )}
                        {act.description && (
                          <span className="truncate text-slate-400">
                            {act.description}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                    {act.category === 'workout' && (
                      <button
                        onClick={() => onOpenTimer(act.name, act.restSeconds || 60)}
                        title="Open rest timer"
                        className="p-2 rounded-xl text-slate-400 hover:text-purple-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                        aria-label={`Open rest timer for ${act.name}`}
                      >
                        <Timer className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      onClick={() => onEditActivity(act)}
                      title="Edit activity"
                      className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      aria-label={`Edit ${act.name}`}
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
