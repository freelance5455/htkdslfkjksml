import React, { useState } from 'react';
import {
  TrendingUp,
  CreditCard,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Wallet,
  Truck,
  Users,
  Calendar,
  LockKeyhole,
  Boxes,
  FileText,
  Printer,
  PieChart as PieChartIcon,
  BarChart3,
  XCircle,
  Clock,
} from 'lucide-react';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
} from 'recharts';
import { Invoice, Visit, Customer, TreasuryMove } from '../db/indexedDB';
import {
  formatMoney,
  getTodayDateString,
  getArabicDayName,
  calcVisitStatusDistribution,
} from '../utils/calc';
import { ActiveTab } from '../components/BottomNav';

interface DashboardViewProps {
  invoices: Invoice[];
  visits: Visit[];
  customers: Customer[];
  treasuryMoves: TreasuryMove[];
  dailyTarget: number;
  selectedDay: string;
  onNavigate: (tab: ActiveTab) => void;
  onOpenCustomer: (customer: Customer) => void;
  onPrintInvoice?: (invoice: Invoice) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  invoices,
  visits,
  customers,
  treasuryMoves,
  dailyTarget,
  selectedDay,
  onNavigate,
  onOpenCustomer,
  onPrintInvoice,
}) => {
  const [visitScope, setVisitScope] = useState<'today' | 'all'>('today');

  const todayStr = getTodayDateString();
  const todayInvoices = invoices.filter((i) => i.date?.slice(0, 10) === todayStr);
  const todaySales = todayInvoices.reduce((acc, i) => acc + Number(i.grandTotal || 0), 0);
  const todayCollected = todayInvoices.reduce((acc, i) => acc + Number(i.paidAmount || 0), 0);
  
  const todayVisits = visits.filter((v) => v.date === todayStr);
  const completedVisits = todayVisits.filter((v) => v.status === 'تمت الزيارة' || v.status.includes('تمت')).length;
  const dayCustomers = customers.filter((c) => c.dayOfWeek === selectedDay);
  const totalDayCustomers = dayCustomers.length || 50;

  const totalDebt = customers.reduce((acc, c) => acc + Number(c.balance || 0), 0);

  const totalIncome = treasuryMoves.filter((m) => m.type === 'إيراد').reduce((a, m) => a + m.amount, 0);
  const totalExpense = treasuryMoves.filter((m) => m.type === 'مصروف').reduce((a, m) => a + m.amount, 0);
  const cashInTreasury = totalIncome - totalExpense;

  const targetPercent = dailyTarget > 0 ? Math.min(100, Math.round((todaySales / dailyTarget) * 100)) : 0;
  const visitPercent = totalDayCustomers > 0 ? Math.min(100, Math.round((completedVisits / totalDayCustomers) * 100)) : 0;

  // Visit Status Distribution calculation for Recharts Pie Chart
  const activeVisits = visitScope === 'today' ? todayVisits : visits;
  const statusStats = calcVisitStatusDistribution(activeVisits);

  const pieData = [
    { name: 'تمت', value: statusStats.completed, color: '#10b981', label: 'تمت الزيارة' },
    { name: 'ملغاة', value: statusStats.cancelled, color: '#f43f5e', label: 'ملغاة / مغلق' },
    { name: 'مؤجلة', value: statusStats.postponed, color: '#f59e0b', label: 'زيارات مؤجلة' },
  ];

  const hasVisitsData = statusStats.total > 0;

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0];
      const percent = statusStats.total > 0 ? Math.round((Number(data.value) / statusStats.total) * 100) : 0;
      return (
        <div className="bg-slate-900 border border-slate-700 p-2.5 rounded-xl shadow-xl text-right text-xs">
          <p className="font-bold text-white flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: data.payload.color }} />
            <span>{data.name} ({data.payload.label})</span>
          </p>
          <p className="text-slate-300 font-mono mt-1">
            العدد: <b className="text-white font-bold">{data.value}</b> زيارة
          </p>
          <p className="text-amber-400 font-bold font-mono">
            النسبة: {percent}%
          </p>
        </div>
      );
    }
    return null;
  };

  // 7-day sales calculation for Recharts Bar Chart
  const last7DaysData = React.useMemo(() => {
    const list: Array<{
      date: string;
      dayName: string;
      shortDay: string;
      sales: number;
      collected: number;
      invoiceCount: number;
      isToday: boolean;
    }> = [];

    const today = new Date();
    for (let i = 6; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(today.getDate() - i);
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      const dateStr = `${year}-${month}-${day}`;
      const dayName = getArabicDayName(dateStr);

      const dayInvoices = invoices.filter((inv) => inv.date?.slice(0, 10) === dateStr);
      const sales = dayInvoices.reduce((acc, inv) => acc + Number(inv.grandTotal || 0), 0);
      const collected = dayInvoices.reduce((acc, inv) => acc + Number(inv.paidAmount || 0), 0);

      list.push({
        date: dateStr,
        dayName,
        shortDay: dayName.replace('ال', ''),
        sales,
        collected,
        invoiceCount: dayInvoices.length,
        isToday: dateStr === todayStr,
      });
    }

    return list;
  }, [invoices, todayStr]);

  const total7DaysSales = last7DaysData.reduce((acc, d) => acc + d.sales, 0);
  const averageDailySales = Math.round(total7DaysSales / 7);

  const SalesTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-900 border border-slate-700 p-3 rounded-2xl shadow-2xl text-right text-xs space-y-1 min-w-[170px]">
          <p className="font-bold text-white flex items-center justify-between gap-2 border-b border-slate-800 pb-1">
            <span>{data.dayName}</span>
            <span className="font-mono text-slate-400 text-[10px]">{data.date}</span>
          </p>
          <div className="flex items-center justify-between gap-3 text-emerald-400 font-mono pt-0.5">
            <span className="text-slate-300 font-sans">المبيعات:</span>
            <b className="font-black text-sm">{formatMoney(data.sales)} ج.م</b>
          </div>
          <div className="flex items-center justify-between gap-3 text-sky-400 font-mono text-[11px]">
            <span className="text-slate-400 font-sans">المحصل:</span>
            <span>{formatMoney(data.collected)} ج.م</span>
          </div>
          <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-800 flex justify-between font-mono">
            <span className="font-sans">الفواتير:</span>
            <span className="font-bold text-white">{data.invoiceCount} فاتورة</span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-4 pb-24 pt-2 text-right">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-l from-slate-900 via-slate-850 to-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-amber-400 bg-amber-500/15 border border-amber-500/30 px-2.5 py-0.5 rounded-full">
                خط سير: {selectedDay}
              </span>
              <span className="text-xs text-slate-400 font-mono">{todayStr}</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white mt-1.5">
              مرحباً بك في يومك البيعي 🚚
            </h1>
            <p className="text-xs text-slate-300 mt-1">
              سيارة التوزيع: <strong className="text-white">VAN-9902</strong> • إجمالي العملاء اليوم: {totalDayCustomers}
            </p>
          </div>

          <button
            onClick={() => onNavigate('visits')}
            className="flex items-center gap-1.5 px-3.5 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-2xl font-black text-xs shadow-lg shadow-amber-500/20 active:scale-95 transition"
          >
            <span>ابدأ الزيارات</span>
            <ArrowRight className="w-4 h-4 rotate-180" />
          </button>
        </div>

        {/* Target Progress Bar */}
        <div className="mt-4 pt-3 border-t border-slate-800/80">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="text-slate-300 font-bold flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
              الهدف البيعي اليومي ({dailyTarget > 0 ? formatMoney(dailyTarget) : 'غير محدد'} ج.م)
            </span>
            <span className="font-mono font-bold text-amber-400">{targetPercent}%</span>
          </div>
          <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden p-0.5 border border-slate-700/50">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-emerald-400 rounded-full transition-all duration-500"
              style={{ width: `${targetPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* KPI Tiles */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        {/* Sales */}
        <div className="bg-gradient-to-br from-emerald-950/40 to-slate-900 border border-emerald-500/30 rounded-2xl p-3.5 shadow-lg">
          <div className="flex items-center justify-between text-emerald-400 mb-1">
            <span className="text-[11px] font-bold">مبيعات اليوم</span>
            <TrendingUp className="w-4 h-4" />
          </div>
          <div className="text-lg font-black font-mono text-white mt-1">
            {formatMoney(todaySales)}
            <small className="text-[10px] text-emerald-400 mr-1">ج.م</small>
          </div>
          <span className="text-[10px] text-slate-400 mt-0.5 block">
            {todayInvoices.length} فاتورة مسجلة
          </span>
        </div>

        {/* Collected */}
        <div className="bg-gradient-to-br from-sky-950/40 to-slate-900 border border-sky-500/30 rounded-2xl p-3.5 shadow-lg">
          <div className="flex items-center justify-between text-sky-400 mb-1">
            <span className="text-[11px] font-bold">المحصل اليوم</span>
            <CreditCard className="w-4 h-4" />
          </div>
          <div className="text-lg font-black font-mono text-white mt-1">
            {formatMoney(todayCollected)}
            <small className="text-[10px] text-sky-400 mr-1">ج.م</small>
          </div>
          <span className="text-[10px] text-slate-400 mt-0.5 block">
            كاش داخل اليوم
          </span>
        </div>

        {/* Visits */}
        <div className="bg-gradient-to-br from-amber-950/40 to-slate-900 border border-amber-500/30 rounded-2xl p-3.5 shadow-lg">
          <div className="flex items-center justify-between text-amber-400 mb-1">
            <span className="text-[11px] font-bold">زيارات مكتملة</span>
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <div className="text-lg font-black font-mono text-white mt-1">
            {completedVisits}
            <small className="text-[10px] text-slate-400 mr-1">/ {totalDayCustomers}</small>
          </div>
          <span className="text-[10px] text-amber-400 mt-0.5 block">
            {visitPercent}% إنجاز خط السير
          </span>
        </div>

        {/* Outstanding Debt - Clickable to Debt & Collections View */}
        <div
          onClick={() => onNavigate('debt')}
          className="bg-gradient-to-br from-rose-950/40 to-slate-900 border border-rose-500/30 hover:border-rose-400 rounded-2xl p-3.5 shadow-lg cursor-pointer transition active:scale-95 group"
          title="اضغط للانتقال إلى شاشة الآجل والتحصيل وسداد مديونيات العملاء"
        >
          <div className="flex items-center justify-between text-rose-400 mb-1">
            <span className="text-[11px] font-bold group-hover:text-rose-300">إجمالي المديونية</span>
            <AlertTriangle className="w-4 h-4" />
          </div>
          <div className="text-lg font-black font-mono text-white mt-1">
            {formatMoney(totalDebt)}
            <small className="text-[10px] text-rose-400 mr-1">ج.م</small>
          </div>
          <span className="text-[10px] text-rose-300/80 mt-0.5 flex items-center justify-between">
            <span>مديونيات كل العملاء</span>
            <span className="text-[9px] font-bold text-amber-400 underline">تحصيل الآن ←</span>
          </span>
        </div>
      </div>

      {/* Recharts Bar Chart: Last 7 Days Sales (إجمالي المبيعات المحققة خلال آخر 7 أيام) */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <BarChart3 className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
                مبيعات آخر 7 أيام
                <span className="text-[10px] font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                  {formatMoney(total7DaysSales)} ج.م إجمالي
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">
                متابعة حركة المبيعات اليومية وحجم الفواتير المحققة خلال الأسبوع
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-[11px] bg-slate-800 text-slate-300 border border-slate-700 px-2.5 py-1 rounded-xl font-mono">
              متوسط: <b className="text-emerald-400 font-bold">{formatMoney(averageDailySales)}</b> ج.م/يوم
            </span>
          </div>
        </div>

        {/* BarChart Container */}
        <div className="h-56 w-full -mr-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={last7DaysData}
              margin={{ top: 15, right: 10, left: -20, bottom: 5 }}
            >
              <defs>
                <linearGradient id="salesBarGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#10b981" stopOpacity={0.95} />
                  <stop offset="100%" stopColor="#059669" stopOpacity={0.35} />
                </linearGradient>
                <linearGradient id="todayBarGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#f59e0b" stopOpacity={1} />
                  <stop offset="100%" stopColor="#d97706" stopOpacity={0.45} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.3} vertical={false} />
              <XAxis
                dataKey="shortDay"
                stroke="#94a3b8"
                tick={{ fill: '#cbd5e1', fontSize: 11, fontWeight: 600 }}
                tickLine={false}
                axisLine={{ stroke: '#334155' }}
              />
              <YAxis
                stroke="#64748b"
                tick={{ fill: '#64748b', fontSize: 10, fontFamily: 'monospace' }}
                tickLine={false}
                axisLine={false}
                tickFormatter={(val) => (val >= 1000 ? `${(val / 1000).toFixed(0)}k` : val)}
              />
              <Tooltip content={<SalesTooltip />} cursor={{ fill: '#334155', opacity: 0.2, rx: 8 }} />
              <Bar dataKey="sales" radius={[8, 8, 2, 2]} maxBarSize={36}>
                {last7DaysData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={entry.isToday ? 'url(#todayBarGrad)' : 'url(#salesBarGrad)'}
                    stroke={entry.isToday ? '#f59e0b' : '#10b981'}
                    strokeWidth={entry.isToday ? 1.5 : 0}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Legend / Day markers */}
        <div className="flex items-center justify-between flex-wrap gap-2 pt-2 border-t border-slate-800 text-[11px] text-slate-400">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block shadow-sm shadow-emerald-500/50" />
              <span>مبيعات الأيام السابقة</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block shadow-sm shadow-amber-500/50 animate-pulse" />
              <span className="font-bold text-amber-300">اليوم ({last7DaysData.find(d => d.isToday)?.shortDay})</span>
            </span>
          </div>

          <button
            onClick={() => onNavigate('reports')}
            className="text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1 active:scale-95 transition"
          >
            <span>عرض تفاصيل التقارير اليومية</span>
            <ArrowRight className="w-3.5 h-3.5 rotate-180" />
          </button>
        </div>
      </div>

      {/* Recharts Pie Chart: Visit Status Distribution (تمت، ملغاة، مؤجلة) */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
              <PieChartIcon className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
                توزيع حالات زيارات العملاء
                <span className="text-[10px] font-bold bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full border border-slate-700">
                  {statusStats.total} زيارة مسجلة
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">
                نسبة الزيارات (تمت الزيارة، ملغاة/مغلق، مؤجلة) بمكتبة Recharts
              </p>
            </div>
          </div>

          {/* Toggle between Today and All */}
          <div className="bg-slate-850 p-1 rounded-xl border border-slate-750 flex items-center gap-1 text-xs">
            <button
              onClick={() => setVisitScope('today')}
              className={`px-2.5 py-1 rounded-lg font-bold transition active:scale-95 ${
                visitScope === 'today'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              زيارات اليوم
            </button>
            <button
              onClick={() => setVisitScope('all')}
              className={`px-2.5 py-1 rounded-lg font-bold transition active:scale-95 ${
                visitScope === 'all'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              كل السجل
            </button>
          </div>
        </div>

        {/* Chart Surface */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center pt-1">
          <div className="md:col-span-7 h-52 relative flex items-center justify-center">
            {hasVisitsData ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Tooltip content={<CustomTooltip />} />
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={4}
                    dataKey="value"
                    animationDuration={800}
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} stroke="#0f172a" strokeWidth={2} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            ) : (
              /* Informative Empty State with preview ring */
              <div className="flex flex-col items-center justify-center text-center p-4 space-y-2 border border-dashed border-slate-700/80 rounded-2xl w-full h-full bg-slate-850/40">
                <Users className="w-8 h-8 text-slate-500 animate-pulse" />
                <p className="text-xs font-bold text-slate-300">لم تُسجل أي زيارات لخط سير اليوم بعد</p>
                <p className="text-[11px] text-slate-400">
                  سجل حالات الزيارات (تمت، ملغاة، مؤجلة) لتظهر فوراً في الرسم البياني
                </p>
                <button
                  onClick={() => onNavigate('visits')}
                  className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-[11px] rounded-xl active:scale-95 transition"
                >
                  فتح خط السير الآن
                </button>
              </div>
            )}

            {/* Center label inside Donut */}
            {hasVisitsData && (
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
                <span className="text-[10px] text-slate-400 font-bold">إجمالي الزيارات</span>
                <span className="text-xl font-black font-mono text-white leading-none mt-0.5">
                  {statusStats.total}
                </span>
                <span className="text-[10px] text-emerald-400 font-mono font-bold mt-0.5">
                  {Math.round((statusStats.completed / Math.max(1, statusStats.total)) * 100)}% تمت
                </span>
              </div>
            )}
          </div>

          {/* Slices Legend & Quick Stats */}
          <div className="md:col-span-5 space-y-2">
            {/* Completed */}
            <div className="p-2.5 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-emerald-500 shrink-0" />
                <div>
                  <span className="text-xs font-bold text-white block">تمت الزيارة</span>
                  <span className="text-[10px] text-emerald-400">ناجحة وتمت المقابلة</span>
                </div>
              </div>
              <div className="text-left font-mono">
                <span className="text-sm font-black text-emerald-400 block">{statusStats.completed}</span>
                <span className="text-[10px] text-slate-400">
                  {statusStats.total > 0 ? Math.round((statusStats.completed / statusStats.total) * 100) : 0}%
                </span>
              </div>
            </div>

            {/* Cancelled */}
            <div className="p-2.5 rounded-2xl bg-rose-950/30 border border-rose-500/30 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-rose-500 shrink-0" />
                <div>
                  <span className="text-xs font-bold text-white block">ملغاة / مغلق</span>
                  <span className="text-[10px] text-rose-400">المحل مغلق أو تعذرت</span>
                </div>
              </div>
              <div className="text-left font-mono">
                <span className="text-sm font-black text-rose-400 block">{statusStats.cancelled}</span>
                <span className="text-[10px] text-slate-400">
                  {statusStats.total > 0 ? Math.round((statusStats.cancelled / statusStats.total) * 100) : 0}%
                </span>
              </div>
            </div>

            {/* Postponed */}
            <div className="p-2.5 rounded-2xl bg-amber-950/30 border border-amber-500/30 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-amber-500 shrink-0" />
                <div>
                  <span className="text-xs font-bold text-white block">زيارة مؤجلة</span>
                  <span className="text-[10px] text-amber-400">مطلوب إعادة الزيارة</span>
                </div>
              </div>
              <div className="text-left font-mono">
                <span className="text-sm font-black text-amber-400 block">{statusStats.postponed}</span>
                <span className="text-[10px] text-slate-400">
                  {statusStats.total > 0 ? Math.round((statusStats.postponed / statusStats.total) * 100) : 0}%
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Cash Box Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
            <Wallet className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-400 block font-bold">رصيد الخزنة الفعلي للسيارة</span>
            <span className="text-xl font-black text-white font-mono">
              {formatMoney(cashInTreasury)} <small className="text-xs text-amber-400">ج.م</small>
            </span>
          </div>
        </div>

        <button
          onClick={() => onNavigate('treasury')}
          className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold active:scale-95 transition"
        >
          حركة الخزنة
        </button>
      </div>

      {/* Quick Launchpad Buttons */}
      <div>
        <h2 className="text-xs font-bold text-slate-400 px-1 mb-2">الإجراءات والعمليات السريعة</h2>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-7 gap-2">
          <button
            onClick={() => onNavigate('visits')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-slate-850 hover:bg-slate-800 border border-slate-750 text-slate-200 active:scale-95 transition"
          >
            <Users className="w-5 h-5 text-amber-400 mb-1.5" />
            <span className="text-[11px] font-bold">خط السير</span>
          </button>

          <button
            onClick={() => onNavigate('invoice')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-slate-850 hover:bg-slate-800 border border-slate-750 text-slate-200 active:scale-95 transition"
          >
            <TrendingUp className="w-5 h-5 text-emerald-400 mb-1.5" />
            <span className="text-[11px] font-bold">فاتورة بيع</span>
          </button>

          <button
            onClick={() => onNavigate('debt')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-slate-850 hover:bg-slate-800 border border-rose-500/40 text-slate-200 active:scale-95 transition shadow-sm shadow-rose-950"
          >
            <CreditCard className="w-5 h-5 text-rose-400 mb-1.5" />
            <span className="text-[11px] font-bold text-rose-300">الآجل والتحصيل</span>
          </button>

          <button
            onClick={() => onNavigate('inventory')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-slate-850 hover:bg-slate-800 border border-slate-750 text-slate-200 active:scale-95 transition"
          >
            <Truck className="w-5 h-5 text-sky-400 mb-1.5" />
            <span className="text-[11px] font-bold">حمولة السيارة</span>
          </button>

          <button
            onClick={() => onNavigate('treasury')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-slate-850 hover:bg-slate-800 border border-slate-750 text-slate-200 active:scale-95 transition"
          >
            <Wallet className="w-5 h-5 text-amber-400 mb-1.5" />
            <span className="text-[11px] font-bold">الخزنة</span>
          </button>

          <button
            onClick={() => onNavigate('day-close')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-slate-850 hover:bg-slate-800 border border-slate-750 text-slate-200 active:scale-95 transition"
          >
            <LockKeyhole className="w-5 h-5 text-rose-400 mb-1.5" />
            <span className="text-[11px] font-bold">إغلاق اليوم</span>
          </button>

          <button
            onClick={() => onNavigate('reports')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-slate-850 hover:bg-slate-800 border border-slate-750 text-slate-200 active:scale-95 transition"
          >
            <FileText className="w-5 h-5 text-indigo-400 mb-1.5" />
            <span className="text-[11px] font-bold">التقارير</span>
          </button>
        </div>
      </div>

      {/* Today's Invoices List with Print Actions */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Printer className="w-4 h-4 text-amber-400" />
            <h2 className="text-xs font-bold text-slate-300">آخر فواتير صدرت اليوم (قابلة للطباعة)</h2>
          </div>
          <span className="text-[11px] text-amber-400 font-mono font-bold">{todayInvoices.length} فاتورة</span>
        </div>

        {todayInvoices.length > 0 ? (
          <div className="space-y-2">
            {todayInvoices.slice(0, 5).map((inv) => (
              <div
                key={inv.id}
                className="p-3 bg-slate-850 rounded-2xl border border-slate-750 flex items-center justify-between text-xs"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white">{inv.customerName}</span>
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded-md font-bold ${
                        inv.payType === 'كاش'
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : 'bg-amber-500/20 text-amber-400'
                      }`}
                    >
                      {inv.payType}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono block mt-0.5">
                    {inv.invoiceNo} • {new Date(inv.date).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                <div className="flex items-center gap-2.5">
                  <div className="text-left font-mono">
                    <span className="font-black text-amber-400 block text-sm">
                      {formatMoney(inv.grandTotal)} ج.م
                    </span>
                    {inv.remainingAmount > 0 && (
                      <span className="text-[10px] text-rose-400 block">
                        آجل: {formatMoney(inv.remainingAmount)}
                      </span>
                    )}
                  </div>

                  {/* Print Invoice Button */}
                  {onPrintInvoice && (
                    <button
                      onClick={() => onPrintInvoice(inv)}
                      className="p-2 bg-slate-800 hover:bg-slate-750 text-amber-400 border border-slate-700 hover:border-amber-500/50 rounded-xl active:scale-95 transition flex items-center gap-1 shadow-sm"
                      title="طباعة إيصال الفاتورة الحراري (80mm)"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span className="text-[10px] font-bold hidden sm:inline">طباعة</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-6 text-center text-xs text-slate-500 bg-slate-850/50 rounded-2xl">
            لم يتم إصدار فواتير بيع اليوم حتى الآن. اضغط على الزيارات أو فاتورة للبدء.
          </div>
        )}
      </div>
    </div>
  );
};
