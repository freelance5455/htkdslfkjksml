import React, { useState } from 'react';
import {
  Truck,
  Warehouse,
  Plus,
  Printer,
  AlertTriangle,
  Search,
  Package,
  Save,
  CheckCircle2,
  ShieldAlert,
  ArrowDownToLine,
  Filter,
  TrendingUp,
  Barcode,
  Layers,
  ShoppingCart,
  Tag,
} from 'lucide-react';
import { Product } from '../db/indexedDB';
import {
  formatMoney,
  getEffectiveThreshold,
  isStockBelowSafetyThreshold,
  getStockSafetyPercentage,
  getSafetyStockDeficit,
} from '../utils/calc';
import { sound } from '../utils/sound';

export interface InventoryViewProps {
  products: Product[];
  vanInventory: Map<string, number>;
  mainInventory: Map<string, number>;
  groups: string[];
  vanSafetyThreshold?: number;
  viewMode?: 'inventory' | 'products';
  onOpenLoadModal: () => void;
  onOpenProductModal: (product?: Product) => void;
  onUpdateMainStock: (productId: string, qty: number) => Promise<void>;
  onPrintStock: (type: 'van' | 'main') => void;
  onAddToCart?: (product: Product) => void;
}

export const InventoryView: React.FC<InventoryViewProps> = ({
  products,
  vanInventory,
  mainInventory,
  groups,
  vanSafetyThreshold = 15,
  viewMode = 'inventory',
  onOpenLoadModal,
  onOpenProductModal,
  onUpdateMainStock,
  onPrintStock,
  onAddToCart,
}) => {
  const [activeTab, setActiveTab] = useState<'van' | 'main'>('van');
  const [selectedGroup, setSelectedGroup] = useState('الكل');
  const [search, setSearch] = useState('');
  const [onlyLowStockFilter, setOnlyLowStockFilter] = useState(false);
  const [editableStock, setEditableStock] = useState<Record<string, number>>({});
  const [saveSuccess, setSaveSuccess] = useState<string | null>(null);

  const isProductCatalogMode = viewMode === 'products';

  // Calculate low stock products in van based on vanSafetyThreshold setting & product minQty
  const lowStockProducts = products.filter((p) => {
    const vanQty = vanInventory.get(p.id) || 0;
    return isStockBelowSafetyThreshold(vanQty, p.minQty, vanSafetyThreshold);
  });

  const q = search.trim().toLowerCase();
  const filteredProducts = products.filter((p) => {
    // If filtering by low safety stock
    if (onlyLowStockFilter) {
      const vanQty = vanInventory.get(p.id) || 0;
      if (!isStockBelowSafetyThreshold(vanQty, p.minQty, vanSafetyThreshold)) {
        return false;
      }
    }

    const matchGroup = selectedGroup === 'الكل' || p.group === selectedGroup;
    if (!matchGroup) return false;
    if (!q) return true;
    return (
      p.name.toLowerCase().includes(q) ||
      p.code.toLowerCase().includes(q) ||
      p.barcode?.toLowerCase().includes(q)
    );
  });

  const handleStockChange = (productId: string, value: string) => {
    const num = Math.max(0, parseFloat(value) || 0);
    setEditableStock((prev) => ({ ...prev, [productId]: num }));
  };

  const handleSaveStock = async (productId: string) => {
    const newQty = editableStock[productId];
    if (newQty === undefined) return;
    try {
      await onUpdateMainStock(productId, newQty);
      sound.playSuccess();
      setSaveSuccess(productId);
      setTimeout(() => setSaveSuccess(null), 2000);
    } catch {
      sound.playError();
    }
  };

  return (
    <div className="space-y-3.5 pb-24 pt-2 text-right">
      {/* Page Title & Context Header */}
      {isProductCatalogMode ? (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-lg space-y-2">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30 shadow-md shadow-amber-500/10">
                <Package className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-sm font-black text-white flex items-center gap-2">
                  دليل المنتجات وقائمة الأسعار
                  <span className="text-[11px] font-mono text-amber-400 font-bold bg-amber-400/10 px-2 py-0.5 rounded-full border border-amber-400/20">
                    {products.length} صنف
                  </span>
                </h1>
                <p className="text-xs text-slate-400">
                  مراقبة أسعار البيع والتكلفة، ورصد نواقص حمولة السيارة فورياً
                </p>
              </div>
            </div>

            {/* Active Safety Stock Limit Indicator */}
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold bg-slate-800 text-amber-300 border border-amber-500/30 px-3 py-1 rounded-xl flex items-center gap-1.5 shadow-sm">
                <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                <span>حد أمان السيارة المعتمد بالإعدادات: <strong className="font-mono text-white text-xs">{vanSafetyThreshold}</strong> قطعة</span>
              </span>
            </div>
          </div>
        </div>
      ) : (
        /* Switch between Van & Main Warehouse tabs when in Inventory mode */
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-1.5 shadow-lg flex gap-1.5">
          <button
            onClick={() => {
              setActiveTab('van');
              setOnlyLowStockFilter(false);
            }}
            className={`flex-1 py-3 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 transition active:scale-95 ${
              activeTab === 'van'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Truck className="w-4 h-4" />
            <span>حمولة ورصيد السيارة (VAN)</span>
            {lowStockProducts.length > 0 && (
              <span className="w-5 h-5 rounded-full bg-rose-600 text-white text-[10px] font-black flex items-center justify-center animate-pulse">
                {lowStockProducts.length}
              </span>
            )}
          </button>

          <button
            onClick={() => {
              setActiveTab('main');
              setOnlyLowStockFilter(false);
            }}
            className={`flex-1 py-3 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 transition active:scale-95 ${
              activeTab === 'main'
                ? 'bg-sky-500 text-slate-950 shadow-md shadow-sky-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Warehouse className="w-4 h-4" />
            <span>المخزن الرئيسي (المركزي)</span>
          </button>
        </div>
      )}

      {/* Prominent High-Visibility Red Safety Stock Warning Banner */}
      {lowStockProducts.length > 0 && (
        <div className="p-4 bg-gradient-to-r from-rose-950 via-slate-900 to-rose-950/80 border-2 border-rose-500 rounded-3xl shadow-2xl shadow-rose-950/50 space-y-3 relative overflow-hidden ring-1 ring-rose-500/40">
          {/* Subtle animated red background pulse effect */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="flex items-start justify-between gap-3 relative z-10">
            <div className="flex items-start gap-3">
              <div className="w-11 h-11 rounded-2xl bg-rose-600 text-white flex items-center justify-center shadow-lg shadow-rose-600/50 shrink-0 mt-0.5 animate-bounce">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-sm font-black text-rose-300 flex items-center gap-1.5">
                    <span>🚨 تنبيه أمان المخزون في السيارة</span>
                  </h3>
                  <span className="text-[11px] font-black bg-rose-500 text-white px-2.5 py-0.5 rounded-full shadow-sm animate-pulse">
                    يوجد {lowStockProducts.length} أصناف تحت حد الأمان ({vanSafetyThreshold} قطعة)
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  تم تسليط الضوء <strong className="text-rose-400 font-extrabold underline decoration-rose-500">باللون الأحمر</strong> على الأصناف التي يقل رصيدها في السيارة عن حد الأمان المحدد في الإعدادات ({vanSafetyThreshold} قطعة). يرجى تعويض الحمولة من المخزن لتجنب نفاد البضاعة أثناء خط السير اليومي.
                </p>
              </div>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex items-center gap-2 pt-2 border-t border-rose-500/30 relative z-10">
            <button
              onClick={() => setOnlyLowStockFilter(!onlyLowStockFilter)}
              className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition active:scale-95 shadow-md ${
                onlyLowStockFilter
                  ? 'bg-rose-600 text-white ring-2 ring-white/50 shadow-rose-600/50'
                  : 'bg-rose-500/20 text-rose-200 border border-rose-500/60 hover:bg-rose-500/30'
              }`}
            >
              <Filter className="w-4 h-4 text-rose-400" />
              <span>
                {onlyLowStockFilter
                  ? 'إلغاء التصفية • عرض كل الأصناف'
                  : `تصفية الأصناف المحددة بالأحمر فقط (${lowStockProducts.length})`}
              </span>
            </button>

            <button
              onClick={onOpenLoadModal}
              className="py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-xl text-xs flex items-center justify-center gap-1.5 active:scale-95 transition shadow-lg shadow-emerald-950 shrink-0"
            >
              <ArrowDownToLine className="w-4 h-4" />
              <span>تحميل فوري للسيارة</span>
            </button>
          </div>
        </div>
      )}

      {/* Top Action Toolbar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 shadow-lg space-y-2.5">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="بحث في المنتجات بالاسم أو الكود أو الباركود..."
              className="w-full h-11 pr-10 pl-8 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-400 focus:outline-none focus:border-amber-500 font-medium"
            />
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3.5" />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute left-3 top-3.5 text-xs text-slate-400 hover:text-white"
                title="مسح البحث"
              >
                ✕
              </button>
            )}
          </div>

          <button
            onClick={onOpenLoadModal}
            className="px-3.5 h-11 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 active:scale-95 transition shadow-md shadow-emerald-950 shrink-0"
          >
            <Truck className="w-4 h-4" />
            <span>تحميل سيارة</span>
          </button>

          <button
            onClick={() => onOpenProductModal()}
            className="px-3 h-11 bg-slate-800 hover:bg-slate-700 text-amber-400 border border-slate-700 font-bold rounded-xl text-xs flex items-center gap-1.5 active:scale-95 transition shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">صنف جديد</span>
          </button>

          <button
            onClick={() => onPrintStock(activeTab)}
            className="px-3 h-11 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold rounded-xl text-xs flex items-center justify-center active:scale-95 transition shrink-0"
            title="طباعة الدليل والجرد"
          >
            <Printer className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Quick Groups Filter Bar (شريط التبويبات العلوي للفلترة السريعة بمجموعات الأصناف) */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 shadow-lg space-y-2">
        <div className="flex items-center justify-between text-xs px-1">
          <span className="font-bold text-slate-200 flex items-center gap-1.5">
            <Layers className="w-4 h-4 text-amber-400" />
            <span>الفلترة السريعة بمجموعات الأصناف (Groups):</span>
          </span>
          <div className="flex items-center gap-2">
            {selectedGroup !== 'الكل' && (
              <button
                onClick={() => setSelectedGroup('الكل')}
                className="text-[11px] text-amber-400 hover:underline"
              >
                إلغاء الفلترة
              </button>
            )}
            <span className="text-[11px] font-mono text-slate-400 font-bold bg-slate-850 px-2 py-0.5 rounded-lg border border-slate-750">
              {filteredProducts.length} صنف متطابق
            </span>
          </div>
        </div>

        {/* Horizontal Scrollable Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
          {/* Dedicated Low Stock Alert Filter Chip if any items are low */}
          {lowStockProducts.length > 0 && (
            <button
              onClick={() => {
                setOnlyLowStockFilter(!onlyLowStockFilter);
                setSelectedGroup('الكل');
              }}
              className={`text-xs px-3.5 py-2 rounded-xl font-black whitespace-nowrap transition active:scale-95 flex items-center gap-1.5 shrink-0 border ${
                onlyLowStockFilter
                  ? 'bg-rose-600 text-white border-rose-400 shadow-lg shadow-rose-600/40 ring-2 ring-rose-300'
                  : 'bg-rose-500/20 border-rose-500 text-rose-300 hover:bg-rose-500/30'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
              <span>تحت حد الأمان ({lowStockProducts.length})</span>
            </button>
          )}

          {/* 'All' Tab */}
          <button
            onClick={() => {
              setSelectedGroup('الكل');
              setOnlyLowStockFilter(false);
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition active:scale-95 flex items-center gap-1.5 shrink-0 border ${
              selectedGroup === 'الكل' && !onlyLowStockFilter
                ? 'bg-amber-500 text-slate-950 border-amber-400 font-black shadow-md shadow-amber-500/25'
                : 'bg-slate-850 hover:bg-slate-800 text-slate-300 border-slate-750'
            }`}
          >
            <span>جميع المجموعات</span>
            <span
              className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                selectedGroup === 'الكل' && !onlyLowStockFilter
                  ? 'bg-slate-950/20 text-slate-950 font-black'
                  : 'bg-slate-750 text-slate-400'
              }`}
            >
              {products.length}
            </span>
          </button>

          {/* Dynamic Groups defined in Settings */}
          {groups.map((groupName) => {
            const groupProducts = products.filter((p) => p.group === groupName);
            const inStockCount = groupProducts.filter((p) => (vanInventory.get(p.id) || 0) > 0).length;
            const isSelected = selectedGroup === groupName && !onlyLowStockFilter;

            return (
              <button
                key={groupName}
                onClick={() => {
                  setSelectedGroup(groupName);
                  setOnlyLowStockFilter(false);
                }}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition active:scale-95 flex items-center gap-1.5 shrink-0 border ${
                  isSelected
                    ? 'bg-amber-500 text-slate-950 border-amber-400 font-black shadow-md shadow-amber-500/25'
                    : 'bg-slate-850 hover:bg-slate-800 text-slate-300 border-slate-750'
                }`}
              >
                <span>{groupName}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                    isSelected
                      ? 'bg-slate-950/20 text-slate-950 font-black'
                      : inStockCount > 0
                      ? 'bg-emerald-500/20 text-emerald-300'
                      : 'bg-slate-750 text-slate-400'
                  }`}
                  title={`${inStockCount} صنف متاح في السيارة`}
                >
                  {groupProducts.length}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Inventory / Product Catalog Items List */}
      <div className="space-y-3">
        {filteredProducts.length > 0 ? (
          filteredProducts.map((p) => {
            const vanQty = vanInventory.get(p.id) || 0;
            const mainQty = mainInventory.get(p.id) || 0;
            const threshold = getEffectiveThreshold(p.minQty, vanSafetyThreshold);
            const isLow = isStockBelowSafetyThreshold(vanQty, p.minQty, vanSafetyThreshold);
            const deficit = getSafetyStockDeficit(vanQty, p.minQty, vanSafetyThreshold);
            const safetyPercent = getStockSafetyPercentage(vanQty, p.minQty, vanSafetyThreshold);
            const currentEditQty = editableStock[p.id] !== undefined ? editableStock[p.id] : mainQty;
            const profitMargin = p.price > 0 ? Math.round(((p.price - p.cost) / p.price) * 100) : 0;

            return (
              <div
                key={p.id}
                className={`rounded-3xl p-4 shadow-lg space-y-3 transition-all relative overflow-hidden ${
                  isLow
                    ? 'bg-gradient-to-br from-rose-950/60 via-slate-900 to-rose-950/30 border-2 border-rose-500 shadow-[0_0_26px_rgba(244,63,94,0.28)] ring-1 ring-rose-500/50'
                    : 'bg-slate-900 border border-slate-800 hover:border-slate-700'
                }`}
              >
                {/* Visual solid red edge bar for low stock items */}
                {isLow && (
                  <div className="absolute top-0 right-0 bottom-0 w-1.5 bg-rose-500" />
                )}

                {/* Top Alert Ribbon for Low Stock Items */}
                {isLow && (
                  <div className="bg-rose-600 text-white px-3 py-1.5 rounded-2xl flex items-center justify-between text-xs font-black shadow-md shadow-rose-950/40 animate-pulse">
                    <div className="flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 shrink-0 text-white" />
                      <span>
                        تنبيه: رصيد السيارة ({vanQty}) يقل عن حد الأمان ({threshold} قطعة)
                      </span>
                    </div>
                    <span className="text-[10px] bg-rose-950 text-rose-200 px-2.5 py-0.5 rounded-full font-mono border border-rose-400/40 font-black">
                      {vanQty === 0 ? 'نافد تماماً (0)' : `عجز: ${deficit} قطعة`}
                    </span>
                  </div>
                )}

                {/* Product Header */}
                <div className="flex items-start justify-between gap-2">
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-[10px] font-mono bg-slate-800 text-amber-400 px-1.5 py-0.5 rounded-md border border-slate-700">
                        {p.code}
                      </span>
                      <span className="text-[10px] bg-amber-500/15 text-amber-300 px-2.5 py-0.5 rounded-full border border-amber-500/30 font-bold flex items-center gap-1">
                        <Tag className="w-2.5 h-2.5 text-amber-400" />
                        <span>{p.group}</span>
                      </span>
                      {p.barcode && (
                        <span className="text-[10px] font-mono bg-slate-800/80 text-slate-400 px-2 py-0.5 rounded-full flex items-center gap-1">
                          <Barcode className="w-3 h-3 text-slate-500" />
                          <span>{p.barcode}</span>
                        </span>
                      )}

                      {/* Low Stock Warning Badge */}
                      {isLow ? (
                        <span className="text-[10px] font-black bg-rose-500/20 text-rose-300 border border-rose-500 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3 text-rose-400" />
                          <span>تحت حد الأمان ({threshold} قطعة)</span>
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>رصيد آمن</span>
                        </span>
                      )}
                    </div>

                    <h3 className="text-base font-black text-white">{p.name}</h3>

                    {/* Financial details */}
                    <div className="flex items-center gap-2.5 text-xs text-slate-300 flex-wrap">
                      <span>
                        سعر البيع: <strong className="text-amber-400 font-mono font-bold">{formatMoney(p.price)}</strong> ج.م
                      </span>
                      <span>•</span>
                      <span>
                        التكلفة: <strong className="text-slate-400 font-mono">{formatMoney(p.cost)}</strong> ج.م
                      </span>
                      <span>•</span>
                      <span className="text-emerald-400 font-bold flex items-center gap-0.5">
                        <TrendingUp className="w-3 h-3" />
                        <span>هامش ربح {profitMargin}%</span>
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {onAddToCart && (
                      <button
                        onClick={() => {
                          if (vanQty > 0) {
                            sound.playBarcodeBeep();
                            onAddToCart(p);
                          } else {
                            sound.playError();
                          }
                        }}
                        disabled={vanQty <= 0}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 active:scale-95 transition shadow-sm ${
                          vanQty > 0
                            ? 'bg-amber-500 hover:bg-amber-600 text-slate-950 shadow-amber-500/20'
                            : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                        }`}
                        title={vanQty > 0 ? 'إضافة صنف إلى سلة البيع فوراً' : 'غير متوفر بالسيارة للبيع'}
                      >
                        <ShoppingCart className="w-3.5 h-3.5" />
                        <span>إضافة للبيع</span>
                      </button>
                    )}

                    <button
                      onClick={() => onOpenProductModal(p)}
                      className="text-xs text-slate-300 hover:text-white px-2.5 py-1.5 bg-slate-800 hover:bg-slate-750 rounded-xl border border-slate-700 active:scale-95 font-bold shadow-sm"
                    >
                      تعديل
                    </button>
                  </div>
                </div>

                {/* Safety Stock Gauge Meter */}
                <div className="pt-2 border-t border-slate-800/80 space-y-1.5">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-400 flex items-center gap-1.5">
                      <ShieldAlert className={`w-3.5 h-3.5 ${isLow ? 'text-rose-400' : 'text-emerald-400'}`} />
                      <span>مستوى أمان حمولة السيارة:</span>
                    </span>
                    <span
                      className={`font-mono font-bold ${
                        isLow ? 'text-rose-400 font-black' : 'text-emerald-400'
                      }`}
                    >
                      {vanQty} من حد الأمان ({threshold} قطعة)
                      {isLow && ` • عجز ${deficit} ق`}
                    </span>
                  </div>

                  {/* Visual Progress Bar */}
                  <div
                    className={`w-full h-2 rounded-full overflow-hidden p-0.5 border ${
                      isLow ? 'bg-slate-900 border-rose-500/50' : 'bg-slate-800 border-slate-700/60'
                    }`}
                  >
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        isLow
                          ? 'bg-gradient-to-r from-rose-600 to-rose-400 animate-pulse'
                          : 'bg-gradient-to-r from-amber-500 to-emerald-400'
                      }`}
                      style={{
                        width: `${Math.min(100, Math.max(8, (vanQty / Math.max(1, threshold * 1.5)) * 100))}%`,
                      }}
                    />
                  </div>
                </div>

                {/* Stock Balances Row */}
                <div className="grid grid-cols-2 gap-2.5 pt-1 border-t border-slate-800 text-xs">
                  {/* Van Stock Box - Prominently Red if Low */}
                  <div
                    className={`p-3 rounded-2xl border flex items-center justify-between transition-all ${
                      isLow
                        ? 'bg-rose-950/80 border-2 border-rose-500 text-rose-200 shadow-md shadow-rose-950/40 ring-1 ring-rose-500/30'
                        : 'bg-slate-850 border-slate-750 text-slate-300'
                    }`}
                  >
                    <div>
                      <span className="text-[10px] text-slate-400 block font-bold">
                        رصيد السيارة (VAN)
                      </span>
                      <div className="flex items-baseline gap-1 mt-0.5">
                        <span
                          className={`text-xl font-black font-mono ${
                            isLow ? 'text-rose-400' : 'text-white'
                          }`}
                        >
                          {vanQty}
                        </span>
                        <span className="text-[10px] text-slate-400">قطعة</span>
                      </div>
                      {isLow && (
                        <span className="text-[10px] text-rose-300 font-black block mt-0.5 animate-pulse">
                          ⚠️ أقل من حد الأمان ({threshold})
                        </span>
                      )}
                    </div>

                    {/* Replenish Button for low items */}
                    {isLow && (
                      <button
                        onClick={onOpenLoadModal}
                        className="py-1.5 px-3 bg-rose-600 hover:bg-rose-500 text-white font-black text-xs rounded-xl flex items-center gap-1 active:scale-95 shadow-lg shadow-rose-950"
                        title="تحميل فوري من المخزن الرئيسي"
                      >
                        <Truck className="w-3.5 h-3.5" />
                        <span>تحميل</span>
                      </button>
                    )}
                  </div>

                  {/* Main Warehouse Box */}
                  <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750 text-slate-300 flex items-center justify-between">
                    <div className="flex-1">
                      <span className="text-[10px] text-slate-400 block font-bold">
                        المخزن الرئيسي (المركزي)
                      </span>
                      {activeTab === 'main' && !isProductCatalogMode ? (
                        <div className="flex items-center gap-1.5 mt-1">
                          <input
                            type="number"
                            min="0"
                            value={currentEditQty}
                            onChange={(e) => handleStockChange(p.id, e.target.value)}
                            className="w-16 bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs font-mono font-bold text-white focus:outline-none focus:border-sky-500"
                          />
                          <button
                            onClick={() => handleSaveStock(p.id)}
                            className="p-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-lg active:scale-95"
                            title="حفظ رصيد المخزن"
                          >
                            {saveSuccess === p.id ? (
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
                            ) : (
                              <Save className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-baseline gap-1 mt-0.5">
                          <span className="text-xl font-black font-mono text-sky-400 block">
                            {mainQty}
                          </span>
                          <span className="text-[10px] text-slate-400">قطعة</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="p-8 text-center text-xs text-slate-400 bg-slate-900 border border-slate-800 rounded-3xl space-y-2">
            <Package className="w-8 h-8 text-slate-600 mx-auto" />
            <p className="font-bold">
              {onlyLowStockFilter
                ? 'ممتاز! لا توجد أي أصناف يقل رصيدها عن حد الأمان حالياً.'
                : 'لا توجد أصناف مطابقة لبحثك في هذا القسم.'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
