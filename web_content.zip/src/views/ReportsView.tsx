import React, { useState } from 'react';
import {
  Calendar,
  Printer,
  TrendingUp,
  CreditCard,
  Undo2,
  Users,
  Clock,
  BarChart3,
  FileSpreadsheet,
} from 'lucide-react';
import {
  Invoice,
  PaymentRecord,
  ReturnRecord,
  Visit,
  Customer,
  Product,
  InvoiceItem,
  TreasuryMove,
} from '../db/indexedDB';
import { formatMoney, getTodayDateString, getArabicDayName } from '../utils/calc';

interface ReportsViewProps {
  invoices: Invoice[];
  invoiceItems: InvoiceItem[];
  payments: PaymentRecord[];
  returns: ReturnRecord[];
  visits: Visit[];
  customers: Customer[];
  products: Product[];
  treasuryMoves: TreasuryMove[];
  onPrintReport: (type: string, date: string) => void;
  onPrintInvoice?: (invoice: Invoice) => void;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  invoices,
  invoiceItems,
  payments,
  returns,
  visits,
  customers,
  products,
  treasuryMoves,
  onPrintReport,
  onPrintInvoice,
}) => {
  const [reportDate, setReportDate] = useState<string>(getTodayDateString());
  const [activeReportTab, setActiveReportTab] = useState<
    'daily' | 'sales' | 'collections' | 'returns' | 'visits' | 'debt' | 'profit'
  >('daily');

  // Filter for selected date
  const dateInvoices = invoices.filter((i) => i.date?.slice(0, 10) === reportDate);
  const datePayments = payments.filter((p) => p.date?.slice(0, 10) === reportDate);
  const dateReturns = returns.filter((r) => r.date?.slice(0, 10) === reportDate);
  const dateVisits = visits.filter((v) => v.date === reportDate);
  const dateMoves = treasuryMoves.filter((m) => m.date?.slice(0, 10) === reportDate);

  const totalSales = dateInvoices.reduce((a, i) => a + Number(i.grandTotal || 0), 0);
  const totalCollections = datePayments.reduce((a, p) => a + Number(p.amount || 0), 0);
  const totalReturns = dateReturns.reduce((a, r) => a + Number(r.amount || 0), 0);
  const completedVisits = dateVisits.filter((v) => v.status === 'تمت الزيارة').length;

  // Debt & Aging calculation
  const customerDebtList = customers
    .filter((c) => Number(c.balance || 0) > 0)
    .sort((a, b) => Number(b.balance || 0) - Number(a.balance || 0));

  // Profit calculation for the date
  const prodMap = new Map(products.map((p) => [p.id, p]));
  const dateInvIds = new Set(dateInvoices.map((i) => i.id));
  const relevantItems = invoiceItems.filter((i) => dateInvIds.has(i.invoiceId));

  let costOfGoods = 0;
  for (const item of relevantItems) {
    const prod = prodMap.get(item.productId);
    costOfGoods += (prod?.cost || 0) * (item.qty || 0);
  }
  const estimatedProfit = Math.max(0, totalSales - costOfGoods - totalReturns);

  return (
    <div className="space-y-3.5 pb-24 pt-2">
      {/* Date Filter Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-amber-400" />
            <h2 className="text-sm font-bold text-white">التقارير اليومية والشاملة</h2>
          </div>

          <button
            onClick={() => onPrintReport(activeReportTab, reportDate)}
            className="px-3.5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-xl font-bold text-xs flex items-center gap-1.5 active:scale-95 transition shadow-md shadow-amber-500/20"
          >
            <Printer className="w-4 h-4" />
            <span>طباعة التقرير الحالي</span>
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="block text-[11px] text-slate-400 mb-1">اختر تاريخ التقرير</label>
            <input
              type="date"
              value={reportDate}
              onChange={(e) => setReportDate(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="bg-slate-850 p-2 rounded-xl border border-slate-750 flex flex-col justify-center">
            <span className="text-[10px] text-slate-400">اليوم المختار</span>
            <span className="text-xs font-bold text-amber-400 font-mono">
              {getArabicDayName(reportDate)} — {reportDate}
            </span>
          </div>
        </div>
      </div>

      {/* Quick KPIs for selected date */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-2.5 text-center">
          <span className="text-[10px] text-slate-400 block font-bold">مبيعات التاريخ</span>
          <span className="text-sm font-black font-mono text-emerald-400 block mt-0.5">
            {formatMoney(totalSales)} ج.م
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-2.5 text-center">
          <span className="text-[10px] text-slate-400 block font-bold">تحصيلات التاريخ</span>
          <span className="text-sm font-black font-mono text-sky-400 block mt-0.5">
            {formatMoney(totalCollections)} ج.م
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-2.5 text-center">
          <span className="text-[10px] text-slate-400 block font-bold">مرتجعات التاريخ</span>
          <span className="text-sm font-black font-mono text-rose-400 block mt-0.5">
            {formatMoney(totalReturns)} ج.م
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-2.5 text-center">
          <span className="text-[10px] text-slate-400 block font-bold">الربح التقديري</span>
          <span className="text-sm font-black font-mono text-amber-400 block mt-0.5">
            {formatMoney(estimatedProfit)} ج.م
          </span>
        </div>
      </div>

      {/* Report Sub-Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
        {[
          { id: 'daily', label: '📋 إجمالي اليوم' },
          { id: 'sales', label: '🧾 المبيعات' },
          { id: 'collections', label: '💳 التحصيلات' },
          { id: 'returns', label: '↩️ المرتجعات' },
          { id: 'visits', label: '📅 الزيارات' },
          { id: 'debt', label: '🕐 الآجل والمديونيات' },
          { id: 'profit', label: '📊 حساب الأرباح' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveReportTab(tab.id as any)}
            className={`text-xs px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition active:scale-95 ${
              activeReportTab === tab.id
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-slate-900 border border-slate-800 text-slate-300 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Report Content Container */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-lg space-y-3">
        {activeReportTab === 'daily' && (
          <div className="space-y-3 text-xs">
            <h3 className="font-bold text-white text-sm">ملخص شامل لحركة يوم {reportDate}</h3>
            <div className="grid grid-cols-2 gap-2 text-slate-300">
              <div className="p-3 bg-slate-850 rounded-2xl border border-slate-750">
                <span className="text-slate-400 block">إجمالي عدد الفواتير:</span>
                <span className="text-base font-bold text-white font-mono">{dateInvoices.length}</span>
              </div>
              <div className="p-3 bg-slate-850 rounded-2xl border border-slate-750">
                <span className="text-slate-400 block">إجمالي الزيارات:</span>
                <span className="text-base font-bold text-white font-mono">
                  {completedVisits} / {dateVisits.length}
                </span>
              </div>
            </div>

            <div className="p-3.5 bg-slate-850 rounded-2xl border border-slate-750 space-y-2">
              <span className="font-bold text-amber-400 block">حركة نقدية الخزنة لهذا اليوم</span>
              <div className="flex justify-between">
                <span>إيرادات مقبوضة:</span>
                <b className="text-emerald-400 font-mono">
                  +{formatMoney(dateMoves.filter((m) => m.type === 'إيراد').reduce((a, m) => a + m.amount, 0))} ج.م
                </b>
              </div>
              <div className="flex justify-between">
                <span>مصروفات نثريات:</span>
                <b className="text-rose-400 font-mono">
                  -{formatMoney(dateMoves.filter((m) => m.type === 'مصروف').reduce((a, m) => a + m.amount, 0))} ج.م
                </b>
              </div>
            </div>
          </div>
        )}

        {activeReportTab === 'sales' && (
          <div className="space-y-2">
            <h3 className="font-bold text-white text-xs">فواتير مبيعات يوم {reportDate}</h3>
            {dateInvoices.length > 0 ? (
              <div className="space-y-2">
                {dateInvoices.map((inv) => (
                  <div
                    key={inv.id}
                    className="p-3 bg-slate-850 rounded-2xl border border-slate-750 flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-bold text-white block">{inv.customerName}</span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {inv.invoiceNo} • {inv.payType}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-amber-400 text-sm">
                        {formatMoney(inv.grandTotal)} ج.م
                      </span>
                      {onPrintInvoice && (
                        <button
                          onClick={() => onPrintInvoice(inv)}
                          className="p-1.5 bg-slate-800 hover:bg-slate-750 text-amber-400 border border-slate-700 rounded-lg active:scale-95 transition"
                          title="طباعة إيصال الفاتورة"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-6 text-center text-xs text-slate-500">لا توجد مبيعات في هذا التاريخ</div>
            )}
          </div>
        )}

        {activeReportTab === 'collections' && (
          <div className="space-y-2">
            <h3 className="font-bold text-white text-xs">تحصيلات يوم {reportDate}</h3>
            {datePayments.length > 0 ? (
              <div className="space-y-2">
                {datePayments.map((p) => (
                  <div
                    key={p.id}
                    className="p-3 bg-slate-850 rounded-2xl border border-slate-750 flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-bold text-white block">{p.customerName}</span>
                      <span className="text-[10px] text-slate-400">{p.notes}</span>
                    </div>
                    <span className="font-mono font-bold text-sky-400 text-sm">
                      +{formatMoney(p.amount)} ج.م
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-6 text-center text-xs text-slate-500">لا توجد تحصيلات مسجلة في هذا التاريخ</div>
            )}
          </div>
        )}

        {activeReportTab === 'returns' && (
          <div className="space-y-2">
            <h3 className="font-bold text-white text-xs">مرتجعات يوم {reportDate}</h3>
            {dateReturns.length > 0 ? (
              <div className="space-y-2">
                {dateReturns.map((r) => (
                  <div
                    key={r.id}
                    className="p-3 bg-slate-850 rounded-2xl border border-slate-750 flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-bold text-white block">{r.returnNo}</span>
                      <span className="text-[10px] text-slate-400">{r.type} • {r.destination}</span>
                    </div>
                    <span className="font-mono font-bold text-rose-400 text-sm">
                      {formatMoney(r.amount)} ج.م
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-6 text-center text-xs text-slate-500">لا توجد مرتجعات في هذا التاريخ</div>
            )}
          </div>
        )}

        {activeReportTab === 'visits' && (
          <div className="space-y-2">
            <h3 className="font-bold text-white text-xs">زيارات خط سير يوم {reportDate}</h3>
            {dateVisits.length > 0 ? (
              <div className="space-y-2">
                {dateVisits.map((v) => (
                  <div
                    key={v.id}
                    className="p-3 bg-slate-850 rounded-2xl border border-slate-750 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white">{v.customerName}</span>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                            v.status.includes('تمت')
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : v.status.includes('مؤجل')
                              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                              : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          {v.status}
                        </span>
                      </div>
                      {v.notes && (
                        <span className="text-[10px] text-slate-400 block mt-0.5">
                          {v.notes}
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {v.timestamp ? new Date(v.timestamp).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }) : '-'}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-6 text-center text-xs text-slate-500">لا توجد زيارات مسجلة في هذا التاريخ</div>
            )}
          </div>
        )}

        {activeReportTab === 'debt' && (
          <div className="space-y-2">
            <h3 className="font-bold text-white text-xs">كشف المديونيات والأرصدة المستحقة</h3>
            {customerDebtList.length > 0 ? (
              <div className="space-y-2">
                {customerDebtList.map((c) => (
                  <div
                    key={c.id}
                    className="p-3 bg-slate-850 rounded-2xl border border-slate-750 flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-bold text-white block">{c.name}</span>
                      <span className="text-[10px] text-slate-400">{c.dayOfWeek} • {c.phone}</span>
                    </div>
                    <span className="font-mono font-bold text-rose-400 text-sm">
                      {formatMoney(c.balance)} ج.م
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-6 text-center text-xs text-emerald-400">
                رائع! لا توجد أي مديونيات متأخرة على العملاء.
              </div>
            )}
          </div>
        )}

        {activeReportTab === 'profit' && (
          <div className="space-y-3 text-xs">
            <h3 className="font-bold text-white text-sm">تحليل الأرباح وهوامش التكلفة لـ {reportDate}</h3>
            <div className="space-y-2">
              <div className="p-3 bg-slate-850 rounded-2xl border border-slate-750 flex justify-between">
                <span>صافي قيمة المبيعات:</span>
                <b className="font-mono text-emerald-400">{formatMoney(totalSales)} ج.م</b>
              </div>
              <div className="p-3 bg-slate-850 rounded-2xl border border-slate-750 flex justify-between">
                <span>تكلفة البضاعة المباعة (Cost):</span>
                <b className="font-mono text-rose-400">-{formatMoney(costOfGoods)} ج.م</b>
              </div>
              <div className="p-3 bg-slate-850 rounded-2xl border border-slate-750 flex justify-between">
                <span>خصم المرتجعات:</span>
                <b className="font-mono text-rose-400">-{formatMoney(totalReturns)} ج.م</b>
              </div>
              <div className="p-4 bg-amber-500/10 rounded-2xl border border-amber-500/20 flex justify-between text-sm">
                <span className="font-bold text-amber-300">الربح الإجمالي التقديري:</span>
                <b className="font-mono font-black text-amber-400 text-base">
                  {formatMoney(estimatedProfit)} ج.م
                </b>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
