import React, { useState } from 'react';
import { 
  BarChart3, 
  Download, 
  Printer, 
  Filter, 
  CheckCircle2, 
  AlertCircle, 
  Users, 
  Calendar,
  Briefcase
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ProjectStatus, ProjectPriority } from '../types';

export const ReportsView: React.FC = () => {
  const { projects, clients, users, tasks } = useApp();

  const [selectedClientId, setSelectedClientId] = useState<string>('All');
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');
  const [selectedPriority, setSelectedPriority] = useState<string>('All');

  // Filtered dataset
  const filteredProjects = projects.filter(p => {
    const matchesClient = selectedClientId === 'All' || p.clientId === selectedClientId;
    const matchesEmployee = selectedEmployeeId === 'All' || p.assignedEmployeeIds.includes(selectedEmployeeId);
    const matchesStatus = selectedStatus === 'All' || p.status === selectedStatus;
    const matchesPriority = selectedPriority === 'All' || p.priority === selectedPriority;
    return matchesClient && matchesEmployee && matchesStatus && matchesPriority;
  });

  const totalContractValue = filteredProjects.reduce((acc, p) => acc + (p.contractValueINR || 0), 0);
  const averageCompletion = filteredProjects.length > 0 
    ? Math.round(filteredProjects.reduce((acc, p) => acc + p.progressPercentage, 0) / filteredProjects.length)
    : 0;

  const handleExportCSV = () => {
    const headers = 'Reference,Project Name,Client,Category,Priority,Status,Progress %,Target Date,Contract Value (INR),Site Location\n';
    const rows = filteredProjects.map(p => 
      `"${p.reference}","${p.name}","${p.clientCompanyName}","${p.category}","${p.priority}","${p.status}","${p.progressPercentage}%","${p.expectedCompletionDate}","₹${p.contractValueINR}","${p.siteLocation}"`
    ).join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Phoenix_Fire_Safety_Report_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    window.print();
  };

  const employees = users.filter(u => u.role === 'Employee');

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Executive Reports & Business Overview</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Operational timelines, completion audits, and employee workload distributions for Phoenix Fire Safety.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handlePrint}
            className="px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer transition-colors flex items-center gap-1.5"
          >
            <Printer className="w-3.5 h-3.5 text-slate-600" />
            <span>Print View</span>
          </button>

          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg cursor-pointer shadow-xs transition-colors flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">Filtered Projects</span>
          <p className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
            {filteredProjects.length}
          </p>
          <span className="text-[11px] text-slate-400">Out of {projects.length} total</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">Combined Order Value</span>
          <p className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
            ₹{(totalContractValue / 100000).toFixed(2)} L
          </p>
          <span className="text-[11px] text-slate-400">Total contracted</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">Average Completion</span>
          <p className="text-2xl font-bold font-mono text-emerald-800 mt-1 tabular-nums">
            {averageCompletion}%
          </p>
          <span className="text-[11px] text-emerald-600">Across filtered scope</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">Delayed Scope</span>
          <p className="text-2xl font-bold font-mono text-red-800 mt-1 tabular-nums">
            {filteredProjects.filter(p => p.status === 'Overdue').length}
          </p>
          <span className="text-[11px] text-red-600">Past target date</span>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 mb-3">
          <Filter className="w-4 h-4 text-slate-500" />
          <span>Report Criteria Filters</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div>
            <label className="block text-slate-500 mb-1">Client Account</label>
            <select
              value={selectedClientId}
              onChange={(e) => setSelectedClientId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 cursor-pointer"
            >
              <option value="All">All Clients</option>
              {clients.map(c => (
                <option key={c.id} value={c.id}>{c.companyName}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-slate-500 mb-1">Project Engineer</label>
            <select
              value={selectedEmployeeId}
              onChange={(e) => setSelectedEmployeeId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 cursor-pointer"
            >
              <option value="All">All Engineers</option>
              {employees.map(e => (
                <option key={e.id} value={e.id}>{e.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-slate-500 mb-1">Project Status</label>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 cursor-pointer"
            >
              <option value="All">All Statuses</option>
              <option value="In Progress">In Progress</option>
              <option value="Pending">Pending</option>
              <option value="Completed">Completed</option>
              <option value="Overdue">Overdue</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-500 mb-1">Priority Level</label>
            <select
              value={selectedPriority}
              onChange={(e) => setSelectedPriority(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 cursor-pointer"
            >
              <option value="All">All Priorities</option>
              <option value="Critical">Critical</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>
        </div>
      </div>

      {/* Employee Workload Summary Matrix */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5">
        <h3 className="text-sm font-bold text-slate-900 mb-3">Field Engineering Workload Allocation</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {employees.map(emp => {
            const empProjects = projects.filter(p => p.assignedEmployeeIds.includes(emp.id));
            const empTasks = tasks.filter(t => t.assignedToEmployeeId === emp.id && t.status !== 'Completed');
            const empOverdue = tasks.filter(t => t.assignedToEmployeeId === emp.id && t.status === 'Overdue');

            return (
              <div key={emp.id} className="p-4 bg-slate-50 border border-slate-200 rounded-lg text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-slate-900">{emp.name}</h4>
                    <p className="text-[11px] text-slate-500">{emp.designation.split('(')[0]}</p>
                  </div>
                  <span className="font-mono text-xs font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded">
                    {empProjects.length} sites
                  </span>
                </div>

                <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-[11px]">
                  <span className="text-slate-600">Pending Tasks: <strong className="font-mono text-slate-900">{empTasks.length}</strong></span>
                  <span className="text-red-700 font-semibold">{empOverdue.length} overdue</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Filtered Projects Report Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">Project Master Audit Sheet ({filteredProjects.length})</h3>
          <span className="text-xs font-mono text-slate-400">Generated: {new Date().toLocaleDateString('en-IN')}</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Ref</th>
                <th className="py-3 px-4">Project Name & Site</th>
                <th className="py-3 px-4">Client Company</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Priority</th>
                <th className="py-3 px-4">Target Date</th>
                <th className="py-3 px-4">Progress</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Value (INR)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredProjects.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-500">
                    No records match the current filter selection.
                  </td>
                </tr>
              ) : (
                filteredProjects.map(p => (
                  <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-red-600">{p.reference}</td>
                    <td className="py-3 px-4 max-w-xs">
                      <p className="font-semibold text-slate-900 truncate">{p.name}</p>
                      <p className="text-[11px] text-slate-400 truncate">{p.siteLocation}</p>
                    </td>
                    <td className="py-3 px-4 text-slate-700">{p.clientCompanyName}</td>
                    <td className="py-3 px-4 text-slate-600">{p.category}</td>
                    <td className="py-3 px-4 font-medium text-slate-700">{p.priority}</td>
                    <td className="py-3 px-4 font-mono tabular-nums text-slate-700">{p.expectedCompletionDate}</td>
                    <td className="py-3 px-4 font-mono font-semibold tabular-nums text-slate-800">{p.progressPercentage}%</td>
                    <td className="py-3 px-4">
                      <span className={`font-semibold ${
                        p.status === 'Completed' ? 'text-emerald-700' : p.status === 'Overdue' ? 'text-red-700' : 'text-blue-700'
                      }`}>
                        {p.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                      ₹{p.contractValueINR.toLocaleString('en-IN')}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
