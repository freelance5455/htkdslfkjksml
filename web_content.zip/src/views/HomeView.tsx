import React, { useState } from 'react';
import {
  Check,
  Flame,
  Droplets,
  Utensils,
  Moon,
  Timer,
  Edit2,
  Clock,
  Dumbbell,
  Sparkles,
  ChevronRight,
  Filter
} from 'lucide-react';
import { Activity, ActivityCategory, AppState, DayRecord } from '../types';
import {
  calculateDailyNutrition,
  calculateDailyProgress,
  getKoreanMotivationalQuote,
  getScheduledActivitiesForDate
} from '../utils/tracker';
import { playChimeSound } from '../utils/notifications';

interface HomeViewProps {
  state: AppState;
  activeDateStr: string;
  dayNumber: number;
  streak: number;
  onToggleTask: (activityId: string) => void;
  onAddWater: (amountMl: number) => void;
  onOpenTimer: (exerciseName: string, restSecs: number) => void;
  onEditActivity: (activity: Activity) => void;
  onOpenAddModal: () => void;
  onSelectCategoryTab: (cat: ActivityCategory) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  state,
  activeDateStr,
  dayNumber,
  streak,
  onToggleTask,
  onAddWater,
  onOpenTimer,
  onEditActivity,
  onOpenAddModal,
  onSelectCategoryTab,
}) => {
  const [filterMode, setFilterMode] = useState<'all' | 'pending' | 'completed'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const dayRecord: DayRecord | undefined = state.history[activeDateStr];
  const scheduledActivities = getScheduledActivitiesForDate(state.activities, activeDateStr);
  const progress = calculateDailyProgress(state.activities, dayRecord, activeDateStr);
  const nutrition = calculateDailyNutrition(state.activities, dayRecord, activeDateStr);
  const quote = getKoreanMotivationalQuote(dayNumber);

  const waterConsumed = dayRecord?.waterConsumedMl || 0;
  const waterGoal = state.profile.waterGoalMl || 3000;
  const waterPercent = Math.min(100, Math.round((waterConsumed / waterGoal) * 100));

  // Filter tasks
  const filteredActivities = scheduledActivities.filter((act) => {
    const isCompleted = Boolean(dayRecord?.tasks?.[act.id]?.completed);
    if (filterMode === 'pending' && isCompleted) return false;
    if (filterMode === 'completed' && !isCompleted) return false;
    if (selectedCategory !== 'all' && act.category !== selectedCategory) return false;
    return true;
  });

  // Sort activities by scheduled time
  filteredActivities.sort((a, b) => a.scheduledTime.localeCompare(b.scheduledTime));

  const handleCheckboxClick = (e: React.MouseEvent, actId: string) => {
    e.stopPropagation();
    playChimeSound('complete');
    onToggleTask(actId);
  };

  const getCategoryColor = (cat: ActivityCategory) => {
    switch (cat) {
      case 'workout':
        return 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 border-blue-100 dark:border-blue-900/30';
      case 'skincare':
        return 'text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/40 border-purple-100 dark:border-purple-900/30';
      case 'nutrition':
        return 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 border-emerald-100 dark:border-emerald-900/30';
      case 'water':
        return 'text-cyan-600 dark:text-cyan-400 bg-cyan-50 dark:bg-cyan-950/40 border-cyan-100 dark:border-cyan-900/30';
      case 'grooming':
        return 'text-pink-600 dark:text-pink-400 bg-pink-50 dark:bg-pink-950/40 border-pink-100 dark:border-pink-900/30';
      case 'posture':
        return 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40 border-indigo-100 dark:border-indigo-900/30';
      case 'sleep':
        return 'text-violet-600 dark:text-violet-400 bg-violet-50 dark:bg-violet-950/40 border-violet-100 dark:border-violet-900/30';
    }
  };

  return (
    <div className="space-y-6 pb-24">
      {/* 1. Daily Progress & Hero Card */}
      <div className="rounded-3xl bg-white dark:bg-[#13151B] border border-slate-100 dark:border-slate-800/80 p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row items-center gap-6 justify-between">
          {/* Circular Progress Ring */}
          <div className="flex items-center gap-5 w-full sm:w-auto">
            <div className="relative w-24 h-24 shrink-0 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r="42"
                  className="text-slate-100 dark:text-slate-800"
                  strokeWidth="8"
                  stroke="currentColor"
                  fill="transparent"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="42"
                  className="text-purple-600 dark:text-purple-400 transition-all duration-500 ease-out"
                  strokeWidth="8"
                  strokeDasharray={263.9}
                  strokeDashoffset={263.9 - (263.9 * progress.percentage) / 100}
                  strokeLinecap="round"
                  stroke="currentColor"
                  fill="transparent"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-2xl font-extrabold tracking-tight tabular-nums text-slate-900 dark:text-white">
                  {progress.percentage}%
                </span>
                <span className="text-[10px] uppercase font-semibold text-slate-400">
                  Glow
                </span>
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-1.5 text-xs text-purple-600 dark:text-purple-400 font-semibold tracking-wide uppercase">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Daily Execution</span>
              </div>
              <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
                <span className="tabular-nums">{progress.completed}</span> / <span className="tabular-nums">{progress.total}</span> Tasks Done
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {progress.remaining > 0
                  ? `${progress.remaining} activities remaining today`
                  : "All daily targets crushed! You're on track."}
              </p>
            </div>
          </div>

          {/* Quick Metrics Bar */}
          <div className="w-full sm:w-auto grid grid-cols-2 gap-3 pt-3 sm:pt-0 border-t sm:border-t-0 border-slate-100 dark:border-slate-800">
            <div className="rounded-2xl bg-slate-50 dark:bg-slate-900/60 p-3 border border-slate-100 dark:border-slate-800">
              <span className="text-[10px] text-slate-400 block font-medium">STREAK</span>
              <div className="flex items-center gap-1 mt-0.5">
                <Flame className="w-4 h-4 fill-amber-500 text-amber-500" />
                <span className="text-base font-bold tabular-nums text-slate-900 dark:text-white">
                  {streak} Days
                </span>
              </div>
            </div>
            <div className="rounded-2xl bg-slate-50 dark:bg-slate-900/60 p-3 border border-slate-100 dark:border-slate-800">
              <span className="text-[10px] text-slate-400 block font-medium">CALORIES / PROTEIN</span>
              <div className="text-xs font-bold tabular-nums text-slate-900 dark:text-white mt-0.5">
                {nutrition.calories} kcal · {nutrition.protein}g P
              </div>
            </div>
          </div>
        </div>

        {/* Motivational Korean Wisdom Banner */}
        <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-800/80 flex items-start gap-3">
          <div className="w-8 h-8 rounded-xl bg-purple-50 dark:bg-purple-950/50 flex items-center justify-center text-purple-600 dark:text-purple-300 shrink-0">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <div className="text-[11px] font-semibold text-purple-700 dark:text-purple-300">
              {quote.principle}
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 italic mt-0.5">
              "{quote.quote}"
            </p>
          </div>
        </div>
      </div>

      {/* 2. Quick Hydration & Nutrition Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Water Intake Card */}
        <div className="rounded-2xl bg-white dark:bg-[#13151B] border border-slate-100 dark:border-slate-800 p-4 shadow-sm flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-50 dark:bg-cyan-950/40 text-cyan-600 dark:text-cyan-400 flex items-center justify-center shrink-0">
              <Droplets className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] font-medium text-slate-400 block">WATER INTAKE</span>
              <div className="text-sm font-bold text-slate-900 dark:text-white tabular-nums">
                {waterConsumed} / {waterGoal} ml
              </div>
              <span className="text-[10px] text-cyan-600 dark:text-cyan-400 font-medium">
                {waterPercent}% of daily goal
              </span>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => onAddWater(250)}
              className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-cyan-50 dark:bg-cyan-950/40 text-cyan-700 dark:text-cyan-300 hover:bg-cyan-100 dark:hover:bg-cyan-900/60 active:scale-95 transition-all"
            >
              +250ml
            </button>
            <button
              onClick={() => onAddWater(500)}
              className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-cyan-600 text-white hover:bg-cyan-700 active:scale-95 transition-all shadow-sm shadow-cyan-600/20"
            >
              +500ml
            </button>
          </div>
        </div>

        {/* Categories Shortcut */}
        <div className="rounded-2xl bg-white dark:bg-[#13151B] border border-slate-100 dark:border-slate-800 p-4 shadow-sm flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-50 dark:bg-purple-950/40 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
              <Dumbbell className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] font-medium text-slate-400 block">7 LIFE PILLARS</span>
              <div className="text-sm font-bold text-slate-900 dark:text-white">
                Gym, Skincare, Nutrition
              </div>
              <span className="text-[10px] text-slate-500">
                Custom routines & timers
              </span>
            </div>
          </div>
          <button
            onClick={() => onSelectCategoryTab('workout')}
            className="p-2 rounded-xl text-slate-400 hover:text-purple-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="View category routines"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* 3. Task Management Toolbar */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Today's Schedule
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Tick items to update your daily completion score in real-time
            </p>
          </div>

          {/* Filter Tabs */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-900 rounded-xl self-start sm:self-auto">
            {(['all', 'pending', 'completed'] as const).map((mode) => (
              <button
                key={mode}
                onClick={() => setFilterMode(mode)}
                className={`px-3 py-1 text-xs font-semibold rounded-lg capitalize transition-all ${
                  filterMode === mode
                    ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-300'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>
        </div>

        {/* Category Filter Pills (unboxed text style buttons) */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1.5 rounded-xl font-medium shrink-0 transition-all ${
              selectedCategory === 'all'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:border-slate-300'
            }`}
          >
            All Pillars
          </button>
          {[
            { id: 'workout', label: 'Workout' },
            { id: 'skincare', label: 'Skincare' },
            { id: 'nutrition', label: 'Diet' },
            { id: 'grooming', label: 'Grooming' },
            { id: 'posture', label: 'Posture' },
            { id: 'sleep', label: 'Sleep' },
          ].map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.id)}
              className={`px-3 py-1.5 rounded-xl font-medium shrink-0 transition-all ${
                selectedCategory === c.id
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:border-slate-300'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>

        {/* 4. Habit Activities List */}
        {filteredActivities.length === 0 ? (
          <div className="rounded-3xl bg-white dark:bg-[#13151B] border border-slate-100 dark:border-slate-800 p-8 text-center">
            <Sparkles className="w-8 h-8 text-purple-400 mx-auto mb-2 opacity-60" />
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">
              No activities match this filter
            </h4>
            <p className="text-xs text-slate-400 mt-1 mb-4">
              Try switching filters or add a new custom habit routine.
            </p>
            <button
              onClick={onOpenAddModal}
              className="px-4 py-2 bg-purple-600 text-white text-xs font-semibold rounded-xl hover:bg-purple-700 shadow-sm"
            >
              Add New Habit
            </button>
          </div>
        ) : (
          <div className="space-y-2.5">
            {filteredActivities.map((act) => {
              const taskRecord = dayRecord?.tasks?.[act.id];
              const isCompleted = Boolean(taskRecord?.completed);

              return (
                <div
                  key={act.id}
                  onClick={(e) => handleCheckboxClick(e, act.id)}
                  className={`group relative rounded-2xl p-4 transition-all border cursor-pointer flex items-center justify-between gap-3 ${
                    isCompleted
                      ? 'bg-slate-50/80 dark:bg-slate-900/40 border-slate-200/80 dark:border-slate-800/80'
                      : 'bg-white dark:bg-[#13151B] border-slate-200 dark:border-slate-800 hover:border-purple-300 dark:hover:border-purple-700/60 shadow-sm'
                  }`}
                >
                  {/* Left: Checkbox & Info */}
                  <div className="flex items-center gap-3.5 min-w-0">
                    {/* Interactive Checkbox */}
                    <button
                      type="button"
                      onClick={(e) => handleCheckboxClick(e, act.id)}
                      className={`w-7 h-7 rounded-xl flex items-center justify-center transition-all shrink-0 ${
                        isCompleted
                          ? 'bg-purple-600 text-white shadow-sm shadow-purple-600/30'
                          : 'border-2 border-slate-300 dark:border-slate-600 hover:border-purple-500 bg-white dark:bg-slate-900'
                      }`}
                      aria-label={isCompleted ? `Mark ${act.name} incomplete` : `Mark ${act.name} completed`}
                    >
                      {isCompleted && <Check className="w-4 h-4 stroke-[3]" />}
                    </button>

                    <div className="min-w-0">
                      {/* Quiet unboxed metadata */}
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 mb-0.5">
                        <span className="capitalize font-medium text-slate-600 dark:text-slate-300">
                          {act.category}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="flex items-center gap-1 tabular-nums">
                          <Clock className="w-3 h-3" />
                          {act.scheduledTime}
                        </span>
                        {act.workoutCategory && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>{act.workoutCategory}</span>
                          </>
                        )}
                        {act.routineType && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="capitalize">{act.routineType}</span>
                          </>
                        )}
                      </div>

                      {/* Title */}
                      <h4
                        className={`text-sm font-semibold truncate transition-colors ${
                          isCompleted
                            ? 'line-through text-slate-400 dark:text-slate-500'
                            : 'text-slate-900 dark:text-white'
                        }`}
                      >
                        {act.name}
                      </h4>

                      {/* Specific metadata descriptors */}
                      <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2 mt-0.5 truncate">
                        {act.sets && act.reps && (
                          <span className="tabular-nums font-medium">
                            {act.sets} sets × {act.reps} reps
                          </span>
                        )}
                        {act.sets && act.durationSeconds && (
                          <span className="tabular-nums font-medium">
                            {act.sets} × {act.durationSeconds}s hold
                          </span>
                        )}
                        {act.calories !== undefined && (
                          <span className="tabular-nums font-medium text-emerald-600 dark:text-emerald-400">
                            {act.calories} kcal · {act.protein}g protein
                          </span>
                        )}
                        {act.quantity && (
                          <span className="truncate">({act.quantity})</span>
                        )}
                        {act.postureDurationMinutes && (
                          <span className="tabular-nums">
                            {act.postureDurationMinutes} mins
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Right Actions */}
                  <div
                    className="flex items-center gap-1 shrink-0"
                    onClick={(e) => e.stopPropagation()}
                  >
                    {/* Workout Rest Timer Trigger */}
                    {act.category === 'workout' && (
                      <button
                        onClick={() => onOpenTimer(act.name, act.restSeconds || 60)}
                        title="Start Rest Timer"
                        className="p-2 rounded-xl text-slate-400 hover:text-purple-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                        aria-label={`Start timer for ${act.name}`}
                      >
                        <Timer className="w-4 h-4" />
                      </button>
                    )}

                    {/* Edit button */}
                    <button
                      onClick={() => onEditActivity(act)}
                      title="Edit activity"
                      className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      aria-label={`Edit ${act.name}`}
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
