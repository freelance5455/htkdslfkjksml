import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { translations } from '../data/translations';
import { 
  Activity, 
  Search, 
  Calendar, 
  Clock, 
  User, 
  Building2, 
  Stethoscope, 
  FileText, 
  CheckCircle2, 
  ArrowLeft, 
  ArrowRight, 
  Phone, 
  Mail, 
  MessageSquare, 
  Plane, 
  Hotel,
  ShieldCheck,
  Send,
  AlertCircle,
  Crown
} from 'lucide-react';

export const PatientTrackingView: React.FC = () => {
  const { 
    language, 
    setCurrentView, 
    trackingCode, 
    setTrackingCode, 
    currentTrackedRequest, 
    lookupTracking, 
    requests,
    showToast 
  } = useApp();

  const [inputCode, setInputCode] = useState(trackingCode || 'ALM-REQ-7924');
  const t = translations[language];
  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputCode.trim()) return;
    const ok = lookupTracking(inputCode.trim());
    if (!ok) {
      showToast(isAr ? `لم يتم العثور على الطلب (${inputCode})` : `Request (${inputCode}) not found`);
    }
  };

  const req = currentTrackedRequest;

  // Timeline Steps
  const getTimeline = () => {
    if (!req) return [];
    const status = req.status;

    return [
      {
        titleAr: 'استلام الطلب والفرز المبدئي',
        titleEn: 'Inquiry & Triage',
        descAr: 'تم استلام البيانات وفرز الاحتياج الطبي عبر مكتب التنسيق.',
        descEn: 'Case logged and triaged by clinical desk.',
        completed: true,
        current: status === 'new',
        date: req.createdAt
      },
      {
        titleAr: 'الدراسة السريرية ومطابقة الطبيب',
        titleEn: 'Clinical Board Matching',
        descAr: req.assignedHospital ? `تم التوجيه إلى: ${req.assignedHospital}` : 'جاري العرض على اللجنة الاستشارية وترشيح المستشفى الأنسب.',
        descEn: req.assignedHospital ? `Matched to: ${req.assignedHospital}` : 'Under advisory board evaluation.',
        completed: status !== 'new',
        current: status === 'under_review',
        date: 'مكتمل'
      },
      {
        titleAr: 'تأكيد الخطة والمواعيد واللوجستيات',
        titleEn: 'Coordination & Schedule',
        descAr: req.coordinatorNotes || 'إعداد جدول المواعيد وتنسيق التأشيرة والاستقبال الفندقي.',
        descEn: req.coordinatorNotes || 'Arranging appointments, medical visa and hotel.',
        completed: status === 'coordinating' || status === 'confirmed' || status === 'completed',
        current: status === 'coordinating',
        date: 'قيد التنفيذ'
      },
      {
        titleAr: 'الاستقبال والرعاية في المستشفى',
        titleEn: 'Arrival & Inpatient Care',
        descAr: 'استقبال من المطار والمرافقة السريرية أثناء الفحوصات والتدخلات.',
        descEn: 'Airport welcome and on-site clinical navigation.',
        completed: status === 'confirmed' || status === 'completed',
        current: status === 'confirmed',
        date: 'مجدول'
      },
      {
        titleAr: 'المتابعة بعد الشفاء والعودة للوطن',
        titleEn: 'Post-Care & Telehealth',
        descAr: 'تسليم التقرير الطبي المترجم واستمرار المتابعة عن بُعد مع الاستشاري.',
        descEn: 'Discharge summary issued with scheduled telehealth checkups.',
        completed: status === 'completed',
        current: false,
        date: status === 'completed' ? 'تم الانتهاء' : 'المرحلة القادمة'
      }
    ];
  };

  const timeline = getTimeline();

  return (
    <div className="py-12 bg-black min-h-screen text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        
        {/* Header Breadcrumb */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <button
            onClick={() => setCurrentView('home')}
            className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-zinc-400 hover:text-amber-300 transition-colors"
          >
            <ArrowIcon className="w-4 h-4 text-[#D4AF37]" />
            <span>{t.backToHome}</span>
          </button>
          <div className="flex items-center gap-2">
            <span className="text-xs bg-zinc-900 border border-[#D4AF37]/40 text-amber-300 font-bold px-3 py-1 rounded-full">
              {isAr ? 'بوابة متابعة المريض والملف الصحي' : 'Patient Portal & Live Tracking'}
            </span>
            <button
              onClick={() => setCurrentView('admin')}
              className="text-xs bg-gradient-to-r from-amber-400 to-amber-500 text-black font-extrabold px-3 py-1 rounded-full transition-colors shadow-sm"
            >
              {isAr ? 'عرض لوحة الإدارة' : 'Admin View'}
            </button>
          </div>
        </div>

        {/* Search / Switch Tracked Request */}
        <div className="bg-zinc-950 p-6 rounded-3xl border border-[#D4AF37]/40 shadow-xl">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-xl sm:text-2xl font-black bg-gradient-to-r from-white via-zinc-100 to-amber-200 bg-clip-text text-transparent">
                {isAr ? 'متابعة ملف الحالة والجدول الزمني' : 'Patient File & Coordination Timeline'}
              </h1>
              <p className="text-xs text-zinc-400 mt-0.5">
                {isAr ? 'أدخل رقم المتابعة أو اختر أحد الملفات التجريبية المسجلة في النظام' : 'Enter a tracking code or select a pre-populated patient file'}
              </p>
            </div>

            <form onSubmit={handleSearch} className="flex items-center gap-2 max-w-md w-full">
              <input
                type="text"
                value={inputCode}
                onChange={(e) => setInputCode(e.target.value)}
                placeholder="ALM-REQ-7924"
                className="w-full text-xs sm:text-sm font-mono px-3.5 py-2.5 rounded-xl bg-black border border-zinc-800 text-white focus:outline-hidden focus:border-[#D4AF37]"
              />
              <button
                type="submit"
                className="bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black text-xs font-black px-4.5 py-2.5 rounded-xl whitespace-nowrap transition-all shadow-md"
              >
                {isAr ? 'بحث ومتابعة' : 'Lookup'}
              </button>
            </form>
          </div>

          {/* Quick clickable chips for requests in demo database */}
          <div className="flex items-center gap-2 mt-4 pt-4 border-t border-zinc-900 flex-wrap text-xs">
            <span className="text-zinc-500">{isAr ? 'ملفات جاهزة للمعاينة:' : 'Sample patient records:'}</span>
            {requests.slice(0, 5).map(r => (
              <button
                key={r.id}
                onClick={() => {
                  setInputCode(r.id);
                  setTrackingCode(r.id);
                }}
                className={`font-mono px-2.5 py-1 rounded-lg text-xs transition-all ${
                  req?.id === r.id 
                    ? 'bg-[#D4AF37] text-black font-extrabold shadow-sm' 
                    : 'bg-black hover:bg-zinc-900 text-amber-300 border border-zinc-800'
                }`}
              >
                {r.id} ({r.patientName.split(' ')[0]})
              </button>
            ))}
          </div>
        </div>

        {req ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left Column: Patient Snapshot & Assigned Providers */}
            <div className="lg:col-span-5 space-y-6">
              
              {/* Patient Profile Card in Black & Gold */}
              <div className="bg-zinc-950 rounded-3xl p-6 border border-[#D4AF37]/40 shadow-xl space-y-4">
                <div className="flex items-center justify-between pb-4 border-b border-zinc-900">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-black border border-[#D4AF37]/50 text-amber-300 font-black flex items-center justify-center text-lg shadow-md">
                      {req.patientName.charAt(0)}
                    </div>
                    <div>
                      <h3 className="font-bold text-white text-base">{req.patientName}</h3>
                      <div className="text-xs text-zinc-400">{req.country} • {req.preferredLanguage}</div>
                    </div>
                  </div>
                  <span className="font-mono text-xs font-bold bg-[#D4AF37]/20 text-amber-300 border border-[#D4AF37]/40 px-2.5 py-1 rounded-full">
                    {req.id}
                  </span>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <span className="text-zinc-500 block mb-0.5">{isAr ? 'الخدمة والتخصص المطلوب:' : 'Requested Specialty:'}</span>
                    <span className="font-bold text-amber-200">{req.specialtyOrNeed}</span>
                  </div>

                  <div>
                    <span className="text-zinc-500 block mb-0.5">{isAr ? 'وصف الحالة المسجل:' : 'Case Description:'}</span>
                    <p className="text-zinc-300 bg-black p-3 rounded-xl border border-zinc-900 leading-relaxed">
                      {req.description}
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-zinc-900">
                    <div>
                      <span className="text-zinc-500 block mb-0.5">{isAr ? 'وسيلة الاتصال:' : 'Contact Method:'}</span>
                      <span className="font-semibold text-zinc-300 capitalize">{req.preferredContact} ({req.phone})</span>
                    </div>
                    <div>
                      <span className="text-zinc-500 block mb-0.5">{isAr ? 'التكلفة التقديرية:' : 'Estimated Cost:'}</span>
                      <span className="font-bold text-amber-400">{req.estimatedCost || 'قيد الاحتساب'}</span>
                    </div>
                  </div>
                </div>

                {/* Logistics Badges */}
                <div className="pt-3 border-t border-zinc-900 flex flex-wrap gap-2 text-[11px]">
                  <span className={`px-2.5 py-1 rounded-lg font-medium flex items-center gap-1 ${
                    req.airportPickup ? 'bg-amber-500/15 text-amber-300 border border-[#D4AF37]/40' : 'bg-black text-zinc-500 border border-zinc-800'
                  }`}>
                    <Plane className="w-3 h-3 text-[#D4AF37]" />
                    <span>{isAr ? 'استقبال مطار VIP' : 'VIP Airport'}</span>
                  </span>

                  <span className={`px-2.5 py-1 rounded-lg font-medium flex items-center gap-1 ${
                    req.hotelBooked ? 'bg-amber-500/15 text-amber-300 border border-[#D4AF37]/40' : 'bg-black text-zinc-500 border border-zinc-800'
                  }`}>
                    <Hotel className="w-3 h-3 text-[#D4AF37]" />
                    <span>{isAr ? 'إقامة فندقية مؤكدة' : 'Hotel Booked'}</span>
                  </span>

                  <span className="px-2.5 py-1 rounded-lg font-medium bg-black text-amber-300 border border-[#D4AF37]/30 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-[#D4AF37]" />
                    <span>{isAr ? 'ملف سرّي معتمد' : 'Encrypted File'}</span>
                  </span>
                </div>
              </div>

              {/* Assigned Clinical Team Card in Black & Gold */}
              <div className="bg-zinc-950 rounded-3xl p-6 border border-[#D4AF37]/40 shadow-xl space-y-4">
                <h4 className="font-bold text-white text-sm flex items-center gap-2">
                  <Stethoscope className="w-4 h-4 text-[#D4AF37]" />
                  <span>{isAr ? 'الجهة الطبية والاستشاري المسؤول' : 'Assigned Clinical Team'}</span>
                </h4>

                <div className="space-y-3 text-xs">
                  <div className="p-3 bg-black rounded-xl border border-zinc-900">
                    <div className="font-bold text-amber-200 text-sm">
                      {req.assignedHospital || (isAr ? 'مجمع النيل الطبي المتقدم (تجريبي)' : 'Nile Advanced Medical Center (Demo)')}
                    </div>
                    <div className="text-zinc-500 text-[11px] mt-0.5">
                      {isAr ? 'مستشفى مرجعي معتمد GAHAR و JCI' : 'Certified GAHAR / JCI Partner Hospital'}
                    </div>
                  </div>

                  <div className="p-3 bg-black rounded-xl border border-zinc-900">
                    <div className="font-bold text-amber-200 text-sm">
                      {req.assignedDoctor || (isAr ? 'أ.د. حازم المنصوري - رئيس الفريق الطبي' : 'Prof. Dr. Hazem El-Mansoury')}
                    </div>
                    <div className="text-zinc-500 text-[11px] mt-0.5">
                      {isAr ? 'استشاري التخصص المعين لمتابعة ومناظرة الحالة' : 'Lead specialist overseeing patient protocol'}
                    </div>
                  </div>

                  {req.translatorAssigned && (
                    <div className="p-2.5 bg-black border border-[#D4AF37]/30 rounded-xl text-amber-200">
                      <strong>{isAr ? 'المترجم والمرافق الميداني:' : 'Assigned Escort & Interpreter:'}</strong>{' '}
                      {req.translatorAssigned}
                    </div>
                  )}
                </div>
              </div>

            </div>

            {/* Right Column: Interactive Timeline & Next Milestones */}
            <div className="lg:col-span-7 space-y-6">
              <div className="bg-zinc-950 rounded-3xl p-6 sm:p-8 border border-[#D4AF37]/40 shadow-xl space-y-6">
                
                <div className="flex items-center justify-between pb-4 border-b border-zinc-900">
                  <div>
                    <h3 className="font-bold text-white text-lg">
                      {isAr ? 'مراحل التنسيق ومتابعة الحالة' : 'Coordination Milestones'}
                    </h3>
                    <p className="text-xs text-zinc-400 mt-0.5">
                      {isAr ? 'مراحل تقدم رحلة العلاج المحدثة من قبل منسق الحالة' : 'Live progress updates maintained by the medical desk'}
                    </p>
                  </div>
                  <span className="text-xs font-black px-3 py-1 rounded-full bg-[#D4AF37]/20 text-amber-300 border border-[#D4AF37]/40 uppercase font-mono">
                    {req.status}
                  </span>
                </div>

                {/* Coordinator Note Box */}
                {req.coordinatorNotes && (
                  <div className="p-4 bg-black border border-[#D4AF37]/40 rounded-2xl flex items-start gap-3 shadow-inner">
                    <MessageSquare className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                    <div>
                      <div className="font-bold text-xs text-amber-300 mb-0.5">
                        {isAr ? 'آخر تحديث وتوجيهات من المنسق الطبي:' : 'Latest Clinical Coordinator Note:'}
                      </div>
                      <p className="text-xs text-zinc-300 leading-relaxed">
                        {req.coordinatorNotes}
                      </p>
                    </div>
                  </div>
                )}

                {/* Timeline Component */}
                <div className="space-y-6 pt-2">
                  {timeline.map((item, idx) => (
                    <div key={idx} className="flex items-start gap-4 relative group">
                      
                      {/* Vertical line connecting nodes */}
                      {idx < timeline.length - 1 && (
                        <div 
                          className={`absolute top-7 right-[18px] rtl:right-[18px] ltr:left-[18px] w-0.5 h-[calc(100%-8px)] ${
                            item.completed ? 'bg-[#D4AF37]' : 'bg-zinc-800'
                          }`}
                        />
                      )}

                      {/* Node Icon */}
                      <div className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 z-10 transition-transform ${
                        item.completed 
                          ? 'bg-[#D4AF37] text-black font-black shadow-[0_0_12px_rgba(212,175,55,0.4)]' 
                          : item.current 
                          ? 'bg-amber-400 text-black ring-4 ring-amber-500/20 animate-pulse font-bold'
                          : 'bg-black text-zinc-600 border border-zinc-800'
                      }`}>
                        {item.completed ? (
                          <CheckCircle2 className="w-5 h-5 text-black" />
                        ) : (
                          <span className="text-xs font-bold">{idx + 1}</span>
                        )}
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0 bg-black p-4 rounded-2xl border border-zinc-900 group-hover:border-[#D4AF37]/50 transition-colors">
                        <div className="flex flex-wrap items-center justify-between gap-1 mb-1">
                          <h4 className="font-bold text-sm text-white">
                            {isAr ? item.titleAr : item.titleEn}
                          </h4>
                          <span className="text-[11px] font-mono text-zinc-500">
                            {item.date}
                          </span>
                        </div>
                        <p className="text-xs text-zinc-400 leading-relaxed">
                          {isAr ? item.descAr : item.descEn}
                        </p>
                      </div>

                    </div>
                  ))}
                </div>

                {/* Demo Action to change status directly from here if testing */}
                <div className="pt-6 border-t border-zinc-900 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <span className="text-zinc-500">
                    {isAr ? 'هل تريد تعديل حالة هذا الطلب وتجربة النتيجة؟' : 'Want to test updating this request live?'}
                  </span>
                  <button
                    onClick={() => {
                      setCurrentView('admin');
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="font-bold text-amber-400 hover:text-amber-300 hover:underline"
                  >
                    {isAr ? 'فتح الطلب في لوحة الإدارة ←' : 'Open in Admin Dashboard →'}
                  </button>
                </div>

              </div>
            </div>

          </div>
        ) : (
          <div className="bg-zinc-950 rounded-3xl p-12 text-center border border-[#D4AF37]/30 space-y-4">
            <AlertCircle className="w-12 h-12 text-amber-400 mx-auto" />
            <h3 className="text-lg font-bold text-white">
              {isAr ? 'لم يتم العثور على هذا الرمز' : 'Request not found'}
            </h3>
            <p className="text-xs text-zinc-400 max-w-sm mx-auto">
              {isAr ? 'تأكد من كتابة الرمز بشكل صحيح أو استخدم الرمز الافتراضي ALM-REQ-7924' : 'Please check the code or try default ALM-REQ-7924'}
            </p>
            <button
              onClick={() => {
                setTrackingCode('ALM-REQ-7924');
                setInputCode('ALM-REQ-7924');
              }}
              className="px-4 py-2 bg-gradient-to-r from-amber-400 to-amber-500 text-black rounded-xl text-xs font-bold shadow-md"
            >
              {isAr ? 'تحميل الطلب التجريبي الافتراضي' : 'Load Default Demo'}
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
