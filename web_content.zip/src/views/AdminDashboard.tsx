import React, { useState } from 'react';
import { 
  Briefcase, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Users, 
  CheckSquare, 
  MessageSquare, 
  ArrowUpRight, 
  Plus, 
  FileSpreadsheet, 
  BarChart3,
  Flame,
  Search,
  Filter
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Project, ProjectStatus } from '../types';

interface AdminDashboardProps {
  onOpenNewProjectModal: () => void;
  onOpenNewClientModal: () => void;
  onOpenNewTaskModal: () => void;
  onOpenZohoModal: () => void;
  onEditProject?: (project: Project) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onOpenNewProjectModal,
  onOpenNewClientModal,
  onOpenNewTaskModal,
  onOpenZohoModal,
  onEditProject
}) => {
  const { 
    projects, 
    clients, 
    tasks, 
    messages, 
    employees,
    settings,
    setSelectedProjectId, 
    setActiveView, 
    deleteProject 
  } = useApp();

  const [projectSearch, setProjectSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | ProjectStatus>('All');
  const [projectToDelete, setProjectToDelete] = useState<Project | null>(null);

  // Unread client messages matching WordPress admin/dashboard.php
  const unreadClientMessages = messages.filter(m => m.senderType === 'client' && !m.isRead);

  // Computed metrics
  const totalProjects = projects.length;
  const inProgressProjects = projects.filter(p => p.status === 'In Progress').length;
  const pendingProjects = projects.filter(p => p.status === 'Pending').length;
  const completedProjects = projects.filter(p => p.status === 'Completed').length;
  const overdueProjects = projects.filter(p => p.status === 'Overdue').length;

  const totalEmployees = employees.length;
  const pendingTasksCount = tasks.filter(t => t.status === 'Pending' || t.status === 'To Do').length;
  const completedTasksCount = tasks.filter(t => t.status === 'Completed').length;

  const activeClientsCount = clients.length;
  const outstandingTasksCount = tasks.filter(t => t.status !== 'Completed').length;
  const overdueTasksCount = tasks.filter(t => t.status === 'Overdue').length;

  // Filtered projects for the overview table
  const filteredProjects = projects.filter(p => {
    const matchesSearch = 
      p.name.toLowerCase().includes(projectSearch.toLowerCase()) ||
      p.reference.toLowerCase().includes(projectSearch.toLowerCase()) ||
      p.clientCompanyName.toLowerCase().includes(projectSearch.toLowerCase());
    const matchesStatus = statusFilter === 'All' || p.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleOpenProject = (id: string) => {
    setSelectedProjectId(id);
    setActiveView('project-detail');
  };

  const confirmDeleteProject = () => {
    if (projectToDelete) {
      deleteProject(projectToDelete.id);
      setProjectToDelete(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Welcome */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-red-600 font-semibold text-xs tracking-wider uppercase mb-1">
            <Flame className="w-4 h-4 fill-red-600" />
            <span>Phoenix Fire Safety Equipments Pvt. Ltd. · Chennai</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Executive Project & Operations Console
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Centralized monitoring for fire protection projects, client communications, task allocation, and compliance.
          </p>
        </div>

        {/* Quick Action Buttons with clear text labels - responsive 2-column on mobile, inline on desktop */}
        <div className="grid grid-cols-2 sm:flex sm:flex-wrap items-center gap-2 w-full md:w-auto">
          <button
            onClick={onOpenNewProjectModal}
            className="px-3.5 py-2.5 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg cursor-pointer shadow-xs transition-colors flex items-center justify-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Project</span>
          </button>
          <button
            onClick={onOpenNewClientModal}
            className="px-3 py-2.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer transition-colors text-center"
          >
            Add Client
          </button>
          <button
            onClick={onOpenNewTaskModal}
            className="px-3 py-2.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer transition-colors text-center"
          >
            Assign Task
          </button>
          <button
            onClick={() => setActiveView('employees')}
            className="px-3 py-2.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer transition-colors text-center"
          >
            Employees
          </button>
          <button
            onClick={onOpenZohoModal}
            className="col-span-2 sm:col-span-1 px-3 py-2.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer transition-colors flex items-center justify-center gap-1.5"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-slate-600" />
            <span>Zoho Import</span>
          </button>
        </div>
      </div>

      {/* =========================================================
          NOTIFICATIONS (matching WordPress admin/dashboard.php)
          ========================================================= */}
      {unreadClientMessages.length > 0 && (
        <div className="bg-white border border-slate-200 border-l-4 border-l-red-600 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-red-600" />
                <span>New Client Messages</span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                You have <strong className="text-red-600 font-mono">{unreadClientMessages.length}</strong> unread client message{unreadClientMessages.length === 1 ? '' : 's'}.
              </p>
            </div>
            <button
              onClick={() => {
                if (unreadClientMessages[0]) {
                  handleOpenProject(unreadClientMessages[0].projectId);
                }
              }}
              className="text-xs font-semibold text-red-600 hover:text-red-700 cursor-pointer"
            >
              Open Latest Conversation →
            </button>
          </div>

          <div className="mt-3 space-y-2 max-h-48 overflow-y-auto">
            {unreadClientMessages.map((msg) => {
              const proj = projects.find(p => p.id === msg.projectId);

              return (
                <div
                  key={msg.id}
                  onClick={() => handleOpenProject(msg.projectId)}
                  className="p-3 bg-slate-50 hover:bg-slate-100/80 border border-slate-200 rounded-lg flex items-center justify-between gap-4 cursor-pointer transition-colors"
                >
                  <div className="min-w-0">
                    <p className="font-semibold text-xs text-slate-900">
                      {msg.senderName}
                    </p>
                    <p className="text-[11px] text-slate-600 mt-0.5 truncate">
                      Project: <strong className="text-slate-800">{proj ? proj.name : 'Fire Safety Project'}</strong>
                    </p>
                    <p className="text-xs text-slate-500 mt-0.5 truncate">
                      {msg.type === 'voice' ? '🎤 [Voice message attached]' : msg.content}
                    </p>
                    <span className="text-[10px] text-slate-400 font-mono mt-1 block">
                      {msg.timestamp}
                    </span>
                  </div>

                  <span className="px-3 py-1 bg-red-600 text-white rounded-md text-xs font-semibold shrink-0">
                    View Message
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* =========================================================
          DASHBOARD STATISTICS (matching WordPress admin/dashboard.php)
          ========================================================= */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-3.5">
        <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 border-l-4 border-l-blue-600 shadow-xs">
          <span className="text-[11px] sm:text-xs text-slate-500 font-bold block uppercase tracking-wider">Projects</span>
          <p className="text-xl sm:text-2xl font-bold text-slate-900 font-mono tabular-nums mt-1">{totalProjects}</p>
          <span className="text-[10px] text-slate-400">Total contracts</span>
        </div>

        <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 border-l-4 border-l-emerald-600 shadow-xs">
          <span className="text-[11px] sm:text-xs text-slate-500 font-bold block uppercase tracking-wider">Clients</span>
          <p className="text-xl sm:text-2xl font-bold text-slate-900 font-mono tabular-nums mt-1">{activeClientsCount}</p>
          <span className="text-[10px] text-slate-400">Corporate accounts</span>
        </div>

        <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 border-l-4 border-l-amber-500 shadow-xs">
          <span className="text-[11px] sm:text-xs text-slate-500 font-bold block uppercase tracking-wider">Employees</span>
          <p className="text-xl sm:text-2xl font-bold text-slate-900 font-mono tabular-nums mt-1">{totalEmployees}</p>
          <span className="text-[10px] text-slate-400">Field & CAD staff</span>
        </div>

        <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 border-l-4 border-l-red-600 shadow-xs">
          <span className="text-[11px] sm:text-xs text-slate-500 font-bold block uppercase tracking-wider">Pending Tasks</span>
          <p className="text-xl sm:text-2xl font-bold text-red-900 font-mono tabular-nums mt-1">{pendingTasksCount}</p>
          <span className="text-[10px] text-red-600 font-medium">To be completed</span>
        </div>

        <div className="col-span-2 sm:col-span-1 bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 border-l-4 border-l-emerald-600 shadow-xs">
          <span className="text-[11px] sm:text-xs text-slate-500 font-bold block uppercase tracking-wider">Completed Tasks</span>
          <p className="text-xl sm:text-2xl font-bold text-emerald-900 font-mono tabular-nums mt-1">{completedTasksCount}</p>
          <span className="text-[10px] text-emerald-600 font-medium">Finished work</span>
        </div>
      </div>

      {/* Secondary Operational Breakdown Strip (balanced 7-item responsive grid) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-2.5 sm:gap-3">
        <div className="bg-white p-3 sm:p-3.5 rounded-lg border border-slate-200 shadow-xs">
          <span className="text-[11px] text-blue-700 font-medium">In Progress</span>
          <p className="text-lg sm:text-xl font-bold text-blue-900 font-mono tabular-nums mt-0.5">{inProgressProjects}</p>
          <span className="text-[10px] text-blue-600">Active sites</span>
        </div>

        <div className="bg-white p-3 sm:p-3.5 rounded-lg border border-slate-200 shadow-xs">
          <span className="text-[11px] text-amber-700 font-medium">Pending Start</span>
          <p className="text-lg sm:text-xl font-bold text-amber-900 font-mono tabular-nums mt-0.5">{pendingProjects}</p>
          <span className="text-[10px] text-amber-600">Design/Material</span>
        </div>

        <div className="bg-white p-3 sm:p-3.5 rounded-lg border border-slate-200 shadow-xs">
          <span className="text-[11px] text-emerald-700 font-medium">Completed</span>
          <p className="text-lg sm:text-xl font-bold text-emerald-900 font-mono tabular-nums mt-0.5">{completedProjects}</p>
          <span className="text-[10px] text-emerald-600">Commissioned</span>
        </div>

        <div className="bg-white p-3 sm:p-3.5 rounded-lg border border-red-200 bg-red-50/30 shadow-xs">
          <span className="text-[11px] text-red-700 font-medium">Overdue</span>
          <p className="text-lg sm:text-xl font-bold text-red-900 font-mono tabular-nums mt-0.5">{overdueProjects}</p>
          <span className="text-[10px] text-red-600">Requires follow-up</span>
        </div>

        <div className="bg-white p-3 sm:p-3.5 rounded-lg border border-slate-200 shadow-xs">
          <span className="text-[11px] text-slate-500 font-medium">Active Clients</span>
          <p className="text-lg sm:text-xl font-bold text-slate-900 font-mono tabular-nums mt-0.5">{activeClientsCount}</p>
          <span className="text-[10px] text-slate-400">Corporate accounts</span>
        </div>

        <div className="bg-white p-3 sm:p-3.5 rounded-lg border border-slate-200 shadow-xs">
          <span className="text-[11px] text-slate-500 font-medium">Open Tasks</span>
          <p className="text-lg sm:text-xl font-bold text-slate-900 font-mono tabular-nums mt-0.5">{outstandingTasksCount}</p>
          <span className="text-[10px] text-red-600 font-medium">{overdueTasksCount} overdue</span>
        </div>

        <div className="col-span-2 sm:col-span-1 md:col-span-2 lg:col-span-1 bg-white p-3 sm:p-3.5 rounded-lg border border-slate-200 shadow-xs">
          <span className="text-[11px] text-slate-500 font-medium">Messages</span>
          <p className="text-lg sm:text-xl font-bold text-slate-900 font-mono tabular-nums mt-0.5">{messages.length}</p>
          <span className="text-[10px] text-slate-400">Voice & text</span>
        </div>
      </div>

      {/* Main Content Split: Projects Table + Quick Activity Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 Cols wide on desktop): Master Projects Table */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden flex flex-col">
          <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-slate-900">Project Directory & Status</h2>
              <p className="text-xs text-slate-500 mt-0.5">Filter by status or search reference numbers and clients</p>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full sm:w-auto">
              <div className="relative flex-1 sm:w-48">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                <input
                  type="text"
                  placeholder="Search project or client..."
                  value={projectSearch}
                  onChange={(e) => setProjectSearch(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:border-red-500"
                />
              </div>

              {/* Status Tabs */}
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 cursor-pointer"
              >
                <option value="All">All Statuses</option>
                <option value="In Progress">In Progress</option>
                <option value="Pending">Pending</option>
                <option value="Completed">Completed</option>
                <option value="Overdue">Overdue</option>
              </select>
            </div>
          </div>

          {/* Mobile Project Cards List */}
          <div className="md:hidden divide-y divide-slate-100">
            {filteredProjects.length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs">
                No projects matched your search criteria.
              </div>
            ) : (
              filteredProjects.map((p) => (
                <div key={p.id} className="p-4 space-y-2.5 hover:bg-slate-50/60 transition-colors">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-mono font-bold text-red-600">{p.reference}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                      p.status === 'Completed'
                        ? 'bg-emerald-100 text-emerald-800'
                        : p.status === 'In Progress'
                        ? 'bg-blue-100 text-blue-800'
                        : p.status === 'Overdue'
                        ? 'bg-red-100 text-red-800 font-bold'
                        : 'bg-amber-100 text-amber-800'
                    }`}>
                      {p.status}
                    </span>
                  </div>

                  <div>
                    <h4 className="font-semibold text-slate-900 text-xs">{p.name}</h4>
                    <p className="text-[11px] text-slate-500 mt-0.5">{p.clientCompanyName} · {p.category}</p>
                  </div>

                  <div className="flex items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-2 flex-1">
                      <div className="flex-1 bg-slate-100 h-1.5 rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full ${
                            p.status === 'Completed' ? 'bg-emerald-600' : p.status === 'Overdue' ? 'bg-red-600' : 'bg-blue-600'
                          }`}
                          style={{ width: `${p.progressPercentage}%` }}
                        />
                      </div>
                      <span className="font-mono text-[11px] font-semibold text-slate-700">{p.progressPercentage}%</span>
                    </div>
                    <span className="text-[11px] font-mono text-slate-500 shrink-0">Due: {p.expectedCompletionDate}</span>
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-1 border-t border-slate-100/60">
                    <button
                      onClick={() => handleOpenProject(p.id)}
                      className="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-white rounded text-xs font-semibold cursor-pointer"
                    >
                      View
                    </button>
                    <button
                      onClick={() => onEditProject ? onEditProject(p) : handleOpenProject(p.id)}
                      className="px-2.5 py-1 text-blue-600 hover:bg-blue-50 rounded text-xs font-medium cursor-pointer"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => setProjectToDelete(p)}
                      className="px-2.5 py-1 text-red-600 hover:bg-red-50 rounded text-xs font-medium cursor-pointer"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Desktop Table */}
          <div className="hidden md:block overflow-x-auto flex-1">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Ref & Project Name</th>
                  <th className="py-3 px-4">Client Company</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Target Date</th>
                  <th className="py-3 px-4">Progress</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredProjects.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-500">
                      No projects matched your search criteria.
                    </td>
                  </tr>
                ) : (
                  filteredProjects.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                          <span className="font-mono text-red-600 text-[11px]">{p.reference}</span>
                        </div>
                        <p className="text-slate-600 truncate max-w-xs">{p.name}</p>
                      </td>
                      <td className="py-3 px-4 text-slate-700 font-medium">
                        {p.clientCompanyName}
                      </td>
                      <td className="py-3 px-4 text-slate-600">
                        {p.category}
                      </td>
                      <td className="py-3 px-4 font-mono tabular-nums text-slate-700">
                        {p.expectedCompletionDate}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-slate-100 h-1.5 rounded-full overflow-hidden">
                            <div 
                              className={`h-full rounded-full ${
                                p.status === 'Completed' ? 'bg-emerald-600' : p.status === 'Overdue' ? 'bg-red-600' : 'bg-blue-600'
                              }`}
                              style={{ width: `${p.progressPercentage}%` }}
                            />
                          </div>
                          <span className="font-mono tabular-nums text-[11px] font-semibold text-slate-700">
                            {p.progressPercentage}%
                          </span>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`font-medium ${
                          p.status === 'Completed'
                            ? 'text-emerald-700'
                            : p.status === 'In Progress'
                            ? 'text-blue-700'
                            : p.status === 'Overdue'
                            ? 'text-red-700 font-semibold'
                            : 'text-amber-700'
                        }`}>
                          {p.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleOpenProject(p.id)}
                            className="px-2 py-1 text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded font-medium cursor-pointer"
                          >
                            View
                          </button>
                          <button
                            onClick={() => onEditProject ? onEditProject(p) : handleOpenProject(p.id)}
                            className="px-2 py-1 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded font-medium cursor-pointer"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => setProjectToDelete(p)}
                            className="px-2 py-1 text-red-600 hover:text-red-800 hover:bg-red-50 rounded font-medium cursor-pointer"
                          >
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Column: Communications & Urgent Tasks */}
        <div className="space-y-6">
          {/* Urgent / Overdue Tasks Widget */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-600" />
                <span>Urgent & Overdue Tasks</span>
              </h3>
              <button
                onClick={() => setActiveView('tasks')}
                className="text-xs text-red-600 hover:text-red-700 font-medium cursor-pointer"
              >
                View all tasks
              </button>
            </div>

            <div className="space-y-2.5">
              {tasks.filter(t => t.status === 'Overdue' || t.priority === 'Critical').slice(0, 4).map(task => (
                <div key={task.id} className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs">
                  <div className="flex items-start justify-between gap-2">
                    <p className="font-semibold text-slate-900">{task.title}</p>
                    <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded font-semibold shrink-0 ${
                      task.status === 'Overdue' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-800'
                    }`}>
                      {task.status}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-slate-500 mt-1.5 text-[11px]">
                    <span>Assigned to: <strong className="text-slate-700">{task.assignedToName}</strong></span>
                    <span className="font-mono text-slate-600">Due: {task.deadline}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Communications Widget */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-slate-600" />
                <span>Recent Communications</span>
              </h3>
              <span className="text-xs text-slate-400">Two-Way Hub</span>
            </div>

            <div className="space-y-3">
              {messages.slice(-3).reverse().map(msg => (
                <div 
                  key={msg.id} 
                  onClick={() => handleOpenProject(msg.projectId)}
                  className="p-3 bg-slate-50 hover:bg-slate-100/80 border border-slate-200 rounded-lg cursor-pointer transition-colors"
                >
                  <div className="flex items-center justify-between text-[11px] mb-1">
                    <span className="font-semibold text-slate-900 truncate max-w-[170px]">{msg.senderName}</span>
                    <span className="text-slate-400 font-mono">{msg.timestamp.split(' ')[1]}</span>
                  </div>
                  <p className="text-xs text-slate-600 line-clamp-2">
                    {msg.type === 'voice' ? (
                      <span className="text-red-600 font-medium">🎤 [Voice Note Attached - Click to play]</span>
                    ) : (
                      msg.content
                    )}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* =========================================================
          SYSTEM STATUS (matching WordPress admin/dashboard.php)
          ========================================================= */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900">Phoenix PM System Status</h2>
            <p className="text-xs text-slate-500 mt-0.5">WordPress core module verification and database table connectivity</p>
          </div>
          <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200">
            All Systems Operational
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-4 w-72">Module</th>
                <th className="py-2.5 px-4">Database Table</th>
                <th className="py-2.5 px-4">Description</th>
                <th className="py-2.5 px-4 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              <tr>
                <td className="py-2.5 px-4 font-semibold text-slate-900">Clients</td>
                <td className="py-2.5 px-4 font-mono text-slate-500">wp_ppm_clients</td>
                <td className="py-2.5 px-4 text-slate-600">Company profiles, contacts, GSTINs, and login access</td>
                <td className="py-2.5 px-4 text-right text-emerald-700 font-semibold">✓ Complete</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-semibold text-slate-900">Projects</td>
                <td className="py-2.5 px-4 font-mono text-slate-500">wp_ppm_projects</td>
                <td className="py-2.5 px-4 text-slate-600">Work orders, categories, location, and dates</td>
                <td className="py-2.5 px-4 text-right text-emerald-700 font-semibold">✓ Complete</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-semibold text-slate-900">Employees</td>
                <td className="py-2.5 px-4 font-mono text-slate-500">wp_ppm_employees</td>
                <td className="py-2.5 px-4 text-slate-600">PFS codes, departments, photos, blood groups, and tasks</td>
                <td className="py-2.5 px-4 text-right text-emerald-700 font-semibold">✓ Complete</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-semibold text-slate-900">Project Employees</td>
                <td className="py-2.5 px-4 font-mono text-slate-500">wp_ppm_project_employees</td>
                <td className="py-2.5 px-4 text-slate-600">Multi-engineer site assignment mapping</td>
                <td className="py-2.5 px-4 text-right text-emerald-700 font-semibold">✓ Complete</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-semibold text-slate-900">Tasks</td>
                <td className="py-2.5 px-4 font-mono text-slate-500">wp_ppm_tasks</td>
                <td className="py-2.5 px-4 text-slate-600">Work assignments, priorities, deadlines, and completion</td>
                <td className="py-2.5 px-4 text-right text-emerald-700 font-semibold">✓ Complete</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-semibold text-slate-900">Documents</td>
                <td className="py-2.5 px-4 font-mono text-slate-500">wp_ppm_documents</td>
                <td className="py-2.5 px-4 text-slate-600">Drawings, quotations, Form B NOC, certificates, and photos</td>
                <td className="py-2.5 px-4 text-right text-emerald-700 font-semibold">✓ Complete</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-semibold text-slate-900">Conversations & Voice</td>
                <td className="py-2.5 px-4 font-mono text-slate-500">wp_ppm_conversations</td>
                <td className="py-2.5 px-4 text-slate-600">Text messaging, WebM voice recording, and read receipts</td>
                <td className="py-2.5 px-4 text-right text-emerald-700 font-semibold">✓ Complete</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-semibold text-slate-900">Timeline</td>
                <td className="py-2.5 px-4 font-mono text-slate-500">templates/project-timeline.php</td>
                <td className="py-2.5 px-4 text-slate-600">Sequential project start, task due date flow, and completion</td>
                <td className="py-2.5 px-4 text-right text-emerald-700 font-semibold">✓ Complete</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-semibold text-slate-900">Client Portal</td>
                <td className="py-2.5 px-4 font-mono text-slate-500">templates/client-portal/*</td>
                <td className="py-2.5 px-4 text-slate-600">Shortcodes [ppm_client_login], dashboard, project view, documents</td>
                <td className="py-2.5 px-4 text-right text-emerald-700 font-semibold">✓ Complete</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-semibold text-slate-900">Zoho Integration & Credentials</td>
                <td className="py-2.5 px-4 font-mono text-slate-500">includes/client-import.php</td>
                <td className="py-2.5 px-4 text-slate-600">Zoho Books import, duplicate detection, and credentials CSV generator</td>
                <td className="py-2.5 px-4 text-right text-emerald-700 font-semibold">✓ Complete</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {projectToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-md p-6">
            <h3 className="text-base font-bold text-slate-900">Confirm Project Deletion</h3>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Are you sure you want to permanently delete project <strong className="text-slate-900">{projectToDelete.reference}: {projectToDelete.name}</strong>?
            </p>
            <p className="text-xs text-red-600 mt-1">
              This will remove all associated tasks, conversations, and document links.
            </p>

            <div className="mt-6 flex items-center justify-end gap-3">
              <button
                onClick={() => setProjectToDelete(null)}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={confirmDeleteProject}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-xs transition-colors"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
