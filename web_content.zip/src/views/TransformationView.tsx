import React, { useState } from 'react';
import {
  Sparkles,
  TrendingDown,
  Upload,
  Calendar,
  Camera,
  Layers,
  Scale,
  Award,
  Plus,
  ChevronRight,
  Maximize2
} from 'lucide-react';
import { AppState, PhotoRecord, WeightRecord } from '../types';
import {
  calculateCategoryConsistency,
  calculateDailyProgress,
  formatDate,
  parseDate
} from '../utils/tracker';
import { playChimeSound } from '../utils/notifications';

interface TransformationViewProps {
  state: AppState;
  dayNumber: number;
  onSelectDate: (dateStr: string) => void;
  onAddWeight: (record: WeightRecord) => void;
  onAddPhoto: (photo: PhotoRecord) => void;
}

export const TransformationView: React.FC<TransformationViewProps> = ({
  state,
  dayNumber,
  onSelectDate,
  onAddWeight,
  onAddPhoto,
}) => {
  const [activeTab, setActiveTab] = useState<'matrix' | 'weight' | 'photos'>('matrix');
  const [sliderPosition, setSliderPosition] = useState<number>(50);

  // New weight modal state
  const [showWeightModal, setShowWeightModal] = useState(false);
  const [inputWeight, setInputWeight] = useState(String(state.profile.currentWeightKg || 75.8));
  const [inputBodyFat, setInputBodyFat] = useState('15.5');
  const [weightNotes, setWeightNotes] = useState('');

  // New photo modal state
  const [showPhotoModal, setShowPhotoModal] = useState(false);
  const [photoAngle, setPhotoAngle] = useState<'face' | 'jawline' | 'front_physique' | 'side_profile'>('jawline');
  const [photoType, setPhotoType] = useState<'before' | 'progress' | 'after'>('progress');
  const [photoNotes, setPhotoNotes] = useState('');
  const [photoBase64, setPhotoBase64] = useState<string>('');

  const todayStr = formatDate(new Date());

  // Consistency metrics over past 30 days
  const workoutConsistency = calculateCategoryConsistency('workout', state.history, state.activities, 30, todayStr);
  const skincareConsistency = calculateCategoryConsistency('skincare', state.history, state.activities, 30, todayStr);
  const nutritionConsistency = calculateCategoryConsistency('nutrition', state.history, state.activities, 30, todayStr);
  const postureConsistency = calculateCategoryConsistency('posture', state.history, state.activities, 30, todayStr);

  // Generate 90 days array relative to start date
  const startDate = parseDate(state.profile.startDate);
  const ninetyDays = Array.from({ length: 90 }, (_, i) => {
    const d = new Date(startDate);
    d.setDate(d.getDate() + i);
    const dStr = formatDate(d);
    const dayRec = state.history[dStr];
    const prog = calculateDailyProgress(state.activities, dayRec, dStr);
    const isToday = i + 1 === dayNumber;
    const isPast = i + 1 < dayNumber;
    const isFuture = i + 1 > dayNumber;
    return {
      day: i + 1,
      dateStr: dStr,
      progress: prog,
      isToday,
      isPast,
      isFuture,
      isComplete: prog.total > 0 && prog.percentage >= 80,
    };
  });

  // Handle Photo File Upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setPhotoBase64(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSavePhoto = (e: React.FormEvent) => {
    e.preventDefault();
    if (!photoBase64) return;

    const newPhoto: PhotoRecord = {
      id: `photo_${Date.now()}`,
      date: `Day ${dayNumber}`,
      dayNumber,
      type: photoType,
      angle: photoAngle,
      imageUrl: photoBase64,
      weightKg: state.profile.currentWeightKg,
      notes: photoNotes.trim() || undefined,
    };

    onAddPhoto(newPhoto);
    setShowPhotoModal(false);
    setPhotoBase64('');
    setPhotoNotes('');
    playChimeSound('complete');
  };

  const handleSaveWeight = (e: React.FormEvent) => {
    e.preventDefault();
    const weightNum = parseFloat(inputWeight);
    if (isNaN(weightNum)) return;

    const newRec: WeightRecord = {
      id: `weight_${Date.now()}`,
      date: todayStr,
      weightKg: weightNum,
      bodyFatPercentage: inputBodyFat ? parseFloat(inputBodyFat) : undefined,
      notes: weightNotes.trim() || undefined,
    };

    onAddWeight(newRec);
    setShowWeightModal(false);
    setWeightNotes('');
    playChimeSound('complete');
  };

  // Weight Chart coordinates
  const sortedWeights = [...state.weightHistory].sort((a, b) => a.date.localeCompare(b.date));
  const minW = Math.min(...sortedWeights.map((w) => w.weightKg), state.profile.targetWeightKg) - 1;
  const maxW = Math.max(...sortedWeights.map((w) => w.weightKg), state.profile.startWeightKg) + 1;
  const chartWidth = 500;
  const chartHeight = 180;

  const points = sortedWeights.map((w, idx) => {
    const x = (idx / Math.max(1, sortedWeights.length - 1)) * (chartWidth - 40) + 20;
    const y = chartHeight - 20 - ((w.weightKg - minW) / (maxW - minW)) * (chartHeight - 40);
    return { x, y, ...w };
  });

  const pathD = points.reduce((acc, pt, idx) => {
    return idx === 0 ? `M ${pt.x} ${pt.y}` : `${acc} L ${pt.x} ${pt.y}`;
  }, '');

  // Photos before and after
  const beforePhoto = state.photos.find((p) => p.type === 'before') || state.photos[0];
  const currentPhoto = state.photos.filter((p) => p.id !== beforePhoto?.id).slice(-1)[0] || state.photos[1] || beforePhoto;

  return (
    <div className="space-y-6 pb-24">
      {/* Transformation Header & Sub-Navigation */}
      <div className="rounded-3xl bg-white dark:bg-[#13151B] border border-slate-100 dark:border-slate-800 p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-semibold text-purple-600 dark:text-purple-400 tracking-wide uppercase">
              <Sparkles className="w-3.5 h-3.5" />
              <span>90-Day Transformation</span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white mt-0.5">
              Day {dayNumber} of 90 Progress Journal
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Track physical aesthetics, jawline definition, habits, and bodyweight evolution.
            </p>
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-900 rounded-xl self-start sm:self-auto">
            <button
              onClick={() => setActiveTab('matrix')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                activeTab === 'matrix'
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-500'
              }`}
            >
              90-Day Grid
            </button>
            <button
              onClick={() => setActiveTab('weight')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                activeTab === 'weight'
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-500'
              }`}
            >
              Weight Tracker
            </button>
            <button
              onClick={() => setActiveTab('photos')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                activeTab === 'photos'
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-500'
              }`}
            >
              Photo Journal
            </button>
          </div>
        </div>

        {/* 4 Pillar Consistency Scores */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-5 pt-4 border-t border-slate-100 dark:border-slate-800">
          <div className="p-3 rounded-2xl bg-blue-50/50 dark:bg-blue-950/20 border border-blue-100 dark:border-blue-900/30">
            <span className="text-[10px] font-semibold text-blue-700 dark:text-blue-300 block">WORKOUT</span>
            <div className="text-lg font-bold text-slate-900 dark:text-white tabular-nums mt-0.5">
              {workoutConsistency}%
            </div>
            <span className="text-[10px] text-slate-400">Consistency</span>
          </div>

          <div className="p-3 rounded-2xl bg-purple-50/50 dark:bg-purple-950/20 border border-purple-100 dark:border-purple-900/30">
            <span className="text-[10px] font-semibold text-purple-700 dark:text-purple-300 block">SKINCARE</span>
            <div className="text-lg font-bold text-slate-900 dark:text-white tabular-nums mt-0.5">
              {skincareConsistency}%
            </div>
            <span className="text-[10px] text-slate-400">Consistency</span>
          </div>

          <div className="p-3 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30">
            <span className="text-[10px] font-semibold text-emerald-700 dark:text-emerald-300 block">DIET & MACROS</span>
            <div className="text-lg font-bold text-slate-900 dark:text-white tabular-nums mt-0.5">
              {nutritionConsistency}%
            </div>
            <span className="text-[10px] text-slate-400">Consistency</span>
          </div>

          <div className="p-3 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/30">
            <span className="text-[10px] font-semibold text-indigo-700 dark:text-indigo-300 block">POSTURE</span>
            <div className="text-lg font-bold text-slate-900 dark:text-white tabular-nums mt-0.5">
              {postureConsistency}%
            </div>
            <span className="text-[10px] text-slate-400">Consistency</span>
          </div>
        </div>
      </div>

      {/* TAB 1: 90-DAY MATRIX */}
      {activeTab === 'matrix' && (
        <div className="rounded-3xl bg-white dark:bg-[#13151B] border border-slate-100 dark:border-slate-800 p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                90-Day Execution Grid
              </h3>
              <p className="text-xs text-slate-500">
                Click any day cell to review or retroactively log routines
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs text-slate-500">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-600" /> Done
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full ring-2 ring-purple-500 ring-offset-1" /> Today
              </span>
            </div>
          </div>

          {/* 90-Day Visual Grid */}
          <div className="grid grid-cols-6 sm:grid-cols-10 md:grid-cols-15 gap-1.5 pt-2">
            {ninetyDays.map((item) => (
              <button
                key={item.day}
                onClick={() => onSelectDate(item.dateStr)}
                title={`Day ${item.day}: ${item.progress.percentage}% completed (${item.dateStr})`}
                className={`aspect-square rounded-xl text-[11px] font-bold flex flex-col items-center justify-center transition-all ${
                  item.isToday
                    ? 'ring-2 ring-purple-600 ring-offset-2 dark:ring-offset-slate-900 bg-purple-600 text-white shadow-sm'
                    : item.isComplete
                    ? 'bg-purple-100 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 hover:bg-purple-200'
                    : item.isPast
                    ? 'bg-slate-100 dark:bg-slate-800 text-slate-500 hover:bg-slate-200'
                    : 'bg-slate-50/50 dark:bg-slate-900/30 text-slate-400 dark:text-slate-600 border border-slate-100 dark:border-slate-800/50'
                }`}
              >
                <span>{item.day}</span>
              </button>
            ))}
          </div>

          {/* Milestone Strip */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2">
            <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Transformation Milestones
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
              <div className="p-3 rounded-2xl bg-purple-50/60 dark:bg-purple-950/30 border border-purple-100 dark:border-purple-800/40">
                <div className="font-semibold text-purple-700 dark:text-purple-300">Day 1 - 21: Neural Habits</div>
                <p className="text-slate-500 text-[11px] mt-0.5">Water balance, morning SPF, posture neuromuscular activation.</p>
              </div>
              <div className="p-3 rounded-2xl bg-purple-50/60 dark:bg-purple-950/30 border border-purple-100 dark:border-purple-800/40">
                <div className="font-semibold text-purple-700 dark:text-purple-300">Day 22 - 60: Visual Shift</div>
                <p className="text-slate-500 text-[11px] mt-0.5">Jawline de-bloating, skin barrier radiance, body fat drop.</p>
              </div>
              <div className="p-3 rounded-2xl bg-purple-50/60 dark:bg-purple-950/30 border border-purple-100 dark:border-purple-800/40">
                <div className="font-semibold text-purple-700 dark:text-purple-300">Day 61 - 90: Aesthetic Peak</div>
                <p className="text-slate-500 text-[11px] mt-0.5">Peak symmetry, chisel definition, sustainable lifestyle master.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: WEIGHT TRACKER */}
      {activeTab === 'weight' && (
        <div className="rounded-3xl bg-white dark:bg-[#13151B] border border-slate-100 dark:border-slate-800 p-5 shadow-sm space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Bodyweight & Physique Composition
              </h3>
              <p className="text-xs text-slate-500">
                Steady progress tracking toward your {state.profile.targetWeightKg} kg goal
              </p>
            </div>
            <button
              onClick={() => setShowWeightModal(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold shadow-sm active:scale-95 transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Log Weight</span>
            </button>
          </div>

          {/* Metric Summary Cards */}
          <div className="grid grid-cols-3 gap-3">
            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800">
              <span className="text-[11px] font-semibold text-slate-400 block">START</span>
              <div className="text-lg font-bold text-slate-900 dark:text-white tabular-nums mt-0.5">
                {state.profile.startWeightKg} kg
              </div>
            </div>
            <div className="p-3.5 rounded-2xl bg-purple-50 dark:bg-purple-950/40 border border-purple-100 dark:border-purple-900/30">
              <span className="text-[11px] font-semibold text-purple-600 dark:text-purple-400 block">CURRENT</span>
              <div className="text-lg font-bold text-purple-700 dark:text-purple-300 tabular-nums mt-0.5">
                {state.profile.currentWeightKg} kg
              </div>
            </div>
            <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-900/30">
              <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 block">GOAL</span>
              <div className="text-lg font-bold text-emerald-700 dark:text-emerald-300 tabular-nums mt-0.5">
                {state.profile.targetWeightKg} kg
              </div>
            </div>
          </div>

          {/* SVG Weight Curve Chart */}
          <div className="p-4 rounded-2xl bg-slate-50/70 dark:bg-slate-900/40 border border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span>Weight Trend (Past 14 Days)</span>
              <span className="text-emerald-600 font-semibold flex items-center gap-1">
                <TrendingDown className="w-3.5 h-3.5" />
                -{(state.profile.startWeightKg - state.profile.currentWeightKg).toFixed(1)} kg total
              </span>
            </div>
            <div className="w-full overflow-x-auto">
              <svg className="w-full h-44" viewBox={`0 0 ${chartWidth} ${chartHeight}`}>
                {/* Horizontal guide lines */}
                <line x1="20" y1="30" x2={chartWidth - 20} y2="30" stroke="currentColor" className="text-slate-200 dark:text-slate-800" strokeDasharray="3 3" />
                <line x1="20" y1="80" x2={chartWidth - 20} y2="80" stroke="currentColor" className="text-slate-200 dark:text-slate-800" strokeDasharray="3 3" />
                <line x1="20" y1="130" x2={chartWidth - 20} y2="130" stroke="currentColor" className="text-slate-200 dark:text-slate-800" strokeDasharray="3 3" />

                {/* Trend line */}
                <path d={pathD} fill="none" stroke="#8B5CF6" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />

                {/* Data points */}
                {points.map((pt) => (
                  <g key={pt.id}>
                    <circle cx={pt.x} cy={pt.y} r="4" fill="#8B5CF6" className="cursor-pointer hover:r-6 transition-all" />
                    <text x={pt.x} y={pt.y - 8} textAnchor="middle" fontSize="10" fill="currentColor" className="text-slate-500 font-mono">
                      {pt.weightKg}
                    </text>
                  </g>
                ))}
              </svg>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: BEFORE & AFTER PHOTO JOURNAL */}
      {activeTab === 'photos' && (
        <div className="space-y-6">
          {/* Side-by-Side Interactive Comparison Slider */}
          {beforePhoto && currentPhoto && (
            <div className="rounded-3xl bg-white dark:bg-[#13151B] border border-slate-100 dark:border-slate-800 p-5 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    Transformation Split Slider
                  </h3>
                  <p className="text-xs text-slate-500">
                    Drag the slider to compare baseline with your current glow-up
                  </p>
                </div>
                <button
                  onClick={() => setShowPhotoModal(true)}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold shadow-sm active:scale-95"
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>Upload Photo</span>
                </button>
              </div>

              {/* Slider Viewport */}
              <div className="relative w-full max-w-md mx-auto aspect-square rounded-2xl overflow-hidden select-none border border-slate-200 dark:border-slate-800">
                {/* Current Photo (Underneath) */}
                <img
                  src={currentPhoto.imageUrl}
                  alt="Current progress"
                  referrerPolicy="no-referrer"
                  className="absolute inset-0 w-full h-full object-cover"
                />

                {/* Before Photo (Clipped) */}
                <div
                  className="absolute inset-0 overflow-hidden"
                  style={{ width: `${sliderPosition}%` }}
                >
                  <img
                    src={beforePhoto.imageUrl}
                    alt="Before baseline"
                    referrerPolicy="no-referrer"
                    className="absolute inset-0 w-full h-full object-cover max-w-none"
                    style={{ width: '100%', height: '100%' }}
                  />
                  <span className="absolute top-3 left-3 bg-slate-950/70 text-white text-[10px] font-bold px-2 py-1 rounded-lg backdrop-blur-sm">
                    DAY 1 BEFORE
                  </span>
                </div>

                <span className="absolute top-3 right-3 bg-purple-950/70 text-white text-[10px] font-bold px-2 py-1 rounded-lg backdrop-blur-sm">
                  DAY {dayNumber} NOW
                </span>

                {/* Slider divider line */}
                <div
                  className="absolute top-0 bottom-0 w-0.5 bg-white shadow-xl pointer-events-none"
                  style={{ left: `${sliderPosition}%` }}
                >
                  <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-white text-purple-600 flex items-center justify-center shadow-lg border border-purple-200 text-xs font-bold">
                    ⟷
                  </div>
                </div>

                {/* Range Input Overlay */}
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={sliderPosition}
                  onChange={(e) => setSliderPosition(Number(e.target.value))}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize"
                  aria-label="Before and after split slider"
                />
              </div>
            </div>
          )}

          {/* Photo Gallery Grid */}
          <div className="rounded-3xl bg-white dark:bg-[#13151B] border border-slate-100 dark:border-slate-800 p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Progress Gallery
              </h3>
              <span className="text-xs text-slate-500 tabular-nums">
                {state.photos.length} captures recorded
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {state.photos.map((photo) => (
                <div
                  key={photo.id}
                  className="group rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 flex flex-col"
                >
                  <div className="relative aspect-square overflow-hidden bg-slate-100 dark:bg-slate-800">
                    <img
                      src={photo.imageUrl}
                      alt={photo.notes || 'Progress capture'}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <span className="absolute bottom-2 left-2 px-2 py-0.5 rounded-lg bg-black/60 backdrop-blur-sm text-white text-[10px] font-semibold capitalize">
                      {photo.angle}
                    </span>
                  </div>
                  <div className="p-3">
                    <div className="flex items-center justify-between text-xs font-bold text-slate-900 dark:text-white">
                      <span>{photo.date}</span>
                      {photo.weightKg && (
                        <span className="text-purple-600 dark:text-purple-400 font-mono text-[11px]">
                          {photo.weightKg} kg
                        </span>
                      )}
                    </div>
                    {photo.notes && (
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                        {photo.notes}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* WEIGHT MODAL */}
      {showWeightModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-3xl bg-white dark:bg-[#13151B] border border-slate-200 dark:border-slate-800 p-6 shadow-2xl">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-4">
              Log Today's Weight & Body Fat
            </h3>
            <form onSubmit={handleSaveWeight} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Weight (kg)
                </label>
                <input
                  type="number"
                  step="0.1"
                  required
                  value={inputWeight}
                  onChange={(e) => setInputWeight(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Body Fat % (Optional)
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={inputBodyFat}
                  onChange={(e) => setInputBodyFat(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Notes
                </label>
                <input
                  type="text"
                  placeholder="e.g. Morning fasted weigh-in"
                  value={weightNotes}
                  onChange={(e) => setWeightNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs"
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowWeightModal(false)}
                  className="py-2 px-3 text-xs font-medium text-slate-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="py-2 px-4 rounded-xl bg-purple-600 text-white text-xs font-semibold hover:bg-purple-700"
                >
                  Save Measurement
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PHOTO MODAL */}
      {showPhotoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-3xl bg-white dark:bg-[#13151B] border border-slate-200 dark:border-slate-800 p-6 shadow-2xl">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-4">
              Add Transformation Photo
            </h3>
            <form onSubmit={handleSavePhoto} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Upload Image
                </label>
                <input
                  type="file"
                  accept="image/*"
                  required
                  onChange={handleFileUpload}
                  className="w-full text-xs text-slate-500 file:mr-3 file:py-2 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100"
                />
              </div>
              {photoBase64 && (
                <div className="w-24 h-24 mx-auto rounded-xl overflow-hidden border">
                  <img src={photoBase64} alt="Preview" className="w-full h-full object-cover" />
                </div>
              )}
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Angle Focus
                </label>
                <select
                  value={photoAngle}
                  onChange={(e) => setPhotoAngle(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs"
                >
                  <option value="jawline">Jawline & Facial Structure</option>
                  <option value="face">Skin & Facial Complexion</option>
                  <option value="front_physique">Front Torso & Shoulders</option>
                  <option value="side_profile">Side Profile & Posture</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Observations / Notes
                </label>
                <input
                  type="text"
                  placeholder="e.g. Jawline sharpness improving, skin clearer"
                  value={photoNotes}
                  onChange={(e) => setPhotoNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs"
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowPhotoModal(false)}
                  className="py-2 px-3 text-xs font-medium text-slate-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!photoBase64}
                  className="py-2 px-4 rounded-xl bg-purple-600 text-white text-xs font-semibold hover:bg-purple-700 disabled:opacity-50"
                >
                  Save to Journal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
