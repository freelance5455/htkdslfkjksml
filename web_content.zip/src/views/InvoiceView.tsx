import React, { useState } from 'react';
import {
  Search,
  Camera,
  ShoppingCart,
  Plus,
  Minus,
  Trash2,
  Printer,
  CreditCard,
  Banknote,
  AlertCircle,
  Check,
  Tag,
  UserCheck,
} from 'lucide-react';
import { Customer, Product } from '../db/indexedDB';
import { CartItem, calcInvoice, formatMoney } from '../utils/calc';
import { sound } from '../utils/sound';

interface InvoiceViewProps {
  customers: Customer[];
  selectedCustomer: Customer | null;
  onSelectCustomer: (customer: Customer | null) => void;
  products: Product[];
  vanInventory: Map<string, number>;
  groups: string[];
  cart: CartItem[];
  monthlyDiscountRate: number;
  onAddToCart: (product: Product) => void;
  onUpdateQty: (index: number, newQty: number) => void;
  onUpdateDiscount: (index: number, discount: number) => void;
  onRemoveFromCart: (index: number) => void;
  onClearCart: () => void;
  onOpenScanner: () => void;
  onCommitInvoice: (payType: string, paidAmount: number) => Promise<void>;
  isDayClosed: boolean;
}

export const InvoiceView: React.FC<InvoiceViewProps> = ({
  customers,
  selectedCustomer,
  onSelectCustomer,
  products,
  vanInventory,
  groups,
  cart,
  monthlyDiscountRate,
  onAddToCart,
  onUpdateQty,
  onUpdateDiscount,
  onRemoveFromCart,
  onClearCart,
  onOpenScanner,
  onCommitInvoice,
  isDayClosed,
}) => {
  const [selectedGroup, setSelectedGroup] = useState('الكل');
  const [search, setSearch] = useState('');
  const [payType, setPayType] = useState<'كاش' | 'آجل' | 'جزئي'>('كاش');
  const [customPaidAmount, setCustomPaidAmount] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Invoice calculations
  const totals = calcInvoice(cart, monthlyDiscountRate);

  // Paid amount calculation
  const calculatedPaid =
    customPaidAmount !== ''
      ? Number(customPaidAmount) || 0
      : payType === 'كاش'
      ? totals.grandTotal
      : payType === 'آجل'
      ? 0
      : Math.round(totals.grandTotal / 2);

  const remainingCredit = Math.max(0, Math.round((totals.grandTotal - calculatedPaid) * 100) / 100);

  // Filter products by group & search
  const q = search.trim().toLowerCase();
  const filteredProducts = products.filter((p) => {
    const matchGroup = selectedGroup === 'الكل' || p.group === selectedGroup;
    if (!matchGroup) return false;
    if (!q) return true;
    return (
      p.name.toLowerCase().includes(q) ||
      p.code.toLowerCase().includes(q) ||
      p.barcode.toLowerCase().includes(q)
    );
  });

  const handleCommit = async () => {
    setError(null);
    if (isDayClosed) {
      setError('اليوم البيعي مغلق حالياً! يرجى إعادة فتح اليوم من شاشة الإغلاق أولاً.');
      sound.playError();
      return;
    }
    if (!selectedCustomer) {
      setError('يرجى اختيار العميل أولاً قبل اعتماد الفاتورة');
      sound.playError();
      return;
    }
    if (cart.length === 0) {
      setError('سلة المبيعات فارغة! يرجى إضافة أصناف أولاً.');
      sound.playError();
      return;
    }

    // Check van stock
    for (const item of cart) {
      const stock = vanInventory.get(item.productId) || 0;
      if (item.qty > stock) {
        setError(`الكمية المطلوبة من (${item.name}) هي ${item.qty}، بينما رصيد السيارة هو ${stock} فقط`);
        sound.playError();
        return;
      }
    }

    if (calculatedPaid < 0 || calculatedPaid > totals.grandTotal) {
      setError('المبلغ المحصل غير صحيح');
      sound.playError();
      return;
    }

    try {
      setIsSubmitting(true);
      await onCommitInvoice(payType, calculatedPaid);
      sound.playSuccess();
      setCustomPaidAmount('');
    } catch (err: any) {
      setError(err?.message || 'تعذر اعتماد الفاتورة');
      sound.playError();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-3 pb-32 pt-2">
      {/* Customer Selector Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-3.5 shadow-lg space-y-2">
        <div className="flex items-center justify-between text-xs">
          <span className="font-bold text-slate-300 flex items-center gap-1.5">
            <UserCheck className="w-4 h-4 text-amber-400" />
            العميل المستلم للفاتورة *
          </span>
          {selectedCustomer && (
            <span className="font-mono text-[11px] text-rose-400 font-bold">
              مديونية سابقة: {formatMoney(selectedCustomer.balance)} ج.م
            </span>
          )}
        </div>

        <select
          value={selectedCustomer?.id || ''}
          onChange={(e) => {
            const found = customers.find((c) => c.id === e.target.value) || null;
            onSelectCustomer(found);
          }}
          className="w-full bg-slate-800 border border-slate-700 rounded-2xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500 font-bold"
        >
          <option value="">-- اضغط لاختيار العميل من خط السير --</option>
          {customers.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name} ({c.dayOfWeek}) — مديونية: {formatMoney(c.balance)} ج.م
            </option>
          ))}
        </select>
      </div>

      {/* Barcode Search & Scan Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-2.5 shadow-lg flex gap-2">
        <div className="relative flex-1">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث عن صنف بالاسم، الباركود أو الكود..."
            className="w-full h-11 pr-10 pl-3 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-400 focus:outline-none focus:border-amber-500 font-medium"
          />
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3.5" />
          {search && (
            <button
              onClick={() => setSearch('')}
              className="absolute left-3 top-3.5 text-xs text-slate-400 hover:text-white"
            >
              مسح
            </button>
          )}
        </div>

        <button
          onClick={onOpenScanner}
          className="px-3.5 h-11 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 active:scale-95 transition shadow-md shadow-amber-500/20 shrink-0"
        >
          <Camera className="w-4 h-4" />
          <span>مسح باركود</span>
        </button>
      </div>

      {/* Top Tab Bar for Product Groups */}
      <div className="bg-slate-900 border border-slate-800/90 rounded-2xl p-2 shadow-lg space-y-1.5">
        <div className="flex items-center justify-between px-1 text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5 font-bold text-slate-300">
            <Tag className="w-3.5 h-3.5 text-amber-400" />
            <span>مجموعات المنتجات المحددة</span>
          </div>
          <span className="font-mono text-[10px] text-slate-400">
            {filteredProducts.length} صنف متطابق
          </span>
        </div>

        {/* Tab navigation pills */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1 px-0.5">
          {/* 'All' Tab */}
          <button
            onClick={() => setSelectedGroup('الكل')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition active:scale-95 shrink-0 border ${
              selectedGroup === 'الكل'
                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md shadow-amber-500/25 font-black'
                : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 border-slate-700/60'
            }`}
          >
            <span>جميع الأصناف</span>
            <span
              className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                selectedGroup === 'الكل'
                  ? 'bg-slate-950/20 text-slate-950 font-black'
                  : 'bg-slate-700 text-slate-300'
              }`}
            >
              {products.length}
            </span>
          </button>

          {/* User Defined Groups Tabs */}
          {groups.map((groupName) => {
            const groupProducts = products.filter((p) => p.group === groupName);
            const inStockCount = groupProducts.filter((p) => (vanInventory.get(p.id) || 0) > 0).length;
            const isSelected = selectedGroup === groupName;

            return (
              <button
                key={groupName}
                onClick={() => setSelectedGroup(groupName)}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition active:scale-95 shrink-0 border ${
                  isSelected
                    ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md shadow-amber-500/25 font-black'
                    : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 border-slate-700/60'
                }`}
              >
                <span>{groupName}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                    isSelected
                      ? 'bg-slate-950/20 text-slate-950 font-black'
                      : inStockCount > 0
                      ? 'bg-emerald-500/20 text-emerald-300'
                      : 'bg-slate-700 text-slate-400'
                  }`}
                  title={`${inStockCount} صنف متاح في السيارة`}
                >
                  {groupProducts.length}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Product Catalog Grid */}
      {filteredProducts.length === 0 ? (
        <div className="p-8 text-center bg-slate-900 border border-slate-800 rounded-3xl text-slate-400 space-y-2">
          <p className="text-sm font-bold text-slate-300">لا توجد أصناف تطابق هذا البحث أو المجموعة</p>
          <p className="text-xs text-slate-500">
            جرّب اختيار مجموعة أخرى أو مسح نص البحث الحالي
          </p>
          {(selectedGroup !== 'الكل' || search) && (
            <button
              onClick={() => {
                setSelectedGroup('الكل');
                setSearch('');
              }}
              className="mt-2 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-amber-400 text-xs font-bold rounded-xl active:scale-95 transition"
            >
              عرض كافة الأصناف
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {filteredProducts.map((p) => {
            const stock = vanInventory.get(p.id) || 0;
            const cartItem = cart.find((i) => i.productId === p.id);
            const inCartQty = cartItem?.qty || 0;
            const hasStock = stock > inCartQty;

            return (
              <div
                key={p.id}
                className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-3 flex items-center justify-between gap-2 shadow-md transition"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.2 rounded font-mono">
                      {p.code}
                    </span>
                    {p.group && (
                      <span className="text-[10px] bg-amber-500/10 text-amber-400 border border-amber-500/20 px-1.5 py-0.2 rounded">
                        {p.group}
                      </span>
                    )}
                    <span className="text-xs font-bold text-white truncate block">{p.name}</span>
                  </div>

                  <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
                    <span className="text-amber-400 font-mono font-bold">{formatMoney(p.price)} ج.م</span>
                    <span>•</span>
                    <span
                      className={`text-[11px] font-mono px-1.5 py-0.2 rounded ${
                        stock > 0 ? 'bg-emerald-500/15 text-emerald-400' : 'bg-rose-500/15 text-rose-400'
                      }`}
                    >
                      رصيد السيارة: {stock}
                    </span>
                    {inCartQty > 0 && (
                      <span className="text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded">
                        في السلة: {inCartQty}
                      </span>
                    )}
                  </div>
                </div>

                <button
                  onClick={() => {
                    if (hasStock) {
                      sound.playBarcodeBeep();
                      onAddToCart(p);
                    } else {
                      sound.playError();
                    }
                  }}
                  disabled={!hasStock}
                  className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1 active:scale-95 transition shrink-0 ${
                    hasStock
                      ? 'bg-amber-500 hover:bg-amber-600 text-slate-950 shadow-md shadow-amber-500/20'
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>إضافة</span>
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* Cart Summary Section */}
      <div className="bg-slate-900 border-2 border-slate-800 rounded-3xl p-4 shadow-2xl space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingCart className="w-5 h-5 text-amber-400" />
            <h2 className="text-sm font-bold text-white">سلة الفاتورة ({cart.length} صنف)</h2>
          </div>
          {cart.length > 0 && (
            <button
              onClick={onClearCart}
              className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>تفريغ السلة</span>
            </button>
          )}
        </div>

        {/* Cart Items List */}
        {cart.length > 0 ? (
          <div className="space-y-2 max-h-56 overflow-y-auto no-scrollbar pr-1">
            {totals.lines.map((item, idx) => (
              <div
                key={item.productId}
                className="bg-slate-850 p-2.5 rounded-2xl border border-slate-750 flex items-center justify-between gap-2 text-xs"
              >
                <div className="flex-1 min-w-0">
                  <span className="font-bold text-white block truncate">{item.name}</span>
                  <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                    <span className="font-mono">{formatMoney(item.price)} ج.م</span>
                    {item.itemDiscount > 0 && (
                      <span className="text-rose-400 font-mono">خصم: -{formatMoney(item.itemDiscount)}</span>
                    )}
                  </div>
                </div>

                {/* Quantity Stepper */}
                <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-750 shrink-0">
                  <button
                    onClick={() => onUpdateQty(idx, item.qty - 1)}
                    className="w-6 h-6 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center active:scale-95"
                  >
                    <Minus className="w-3 h-3" />
                  </button>
                  <span className="w-7 text-center font-bold font-mono text-white text-xs">{item.qty}</span>
                  <button
                    onClick={() => onUpdateQty(idx, item.qty + 1)}
                    className="w-6 h-6 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center active:scale-95"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                </div>

                {/* Line total & remove */}
                <div className="flex items-center gap-2 text-left font-mono shrink-0">
                  <span className="font-bold text-amber-400">{formatMoney(item.lineTotal)}</span>
                  <button
                    onClick={() => onRemoveFromCart(idx)}
                    className="text-slate-500 hover:text-rose-400 p-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-4 text-center text-xs text-slate-500 bg-slate-850/40 rounded-2xl">
            السلة فارغة. اختر أصنافاً من الأعلى أو امسح الباركود بالكاميرا.
          </div>
        )}

        {/* Totals Breakdown */}
        <div className="pt-3 border-t border-slate-800 space-y-1.5 text-xs">
          <div className="flex items-center justify-between text-slate-300">
            <span>الإجمالي قبل الخصم:</span>
            <span className="font-mono font-bold">{formatMoney(totals.subtotal)} ج.م</span>
          </div>

          {totals.monthlyDiscountValue > 0 && (
            <div className="flex items-center justify-between text-amber-400">
              <span>الخصم الشهري ({totals.monthlyDiscountRate}%):</span>
              <span className="font-mono font-bold">-{formatMoney(totals.monthlyDiscountValue)} ج.م</span>
            </div>
          )}

          <div className="flex items-center justify-between text-base font-black text-emerald-400 pt-2 border-t border-slate-800">
            <span>الصافي النهائي المطلوب:</span>
            <span className="font-mono">{formatMoney(totals.grandTotal)} ج.م</span>
          </div>
        </div>

        {/* Payment Type Selection */}
        <div className="pt-2 border-t border-slate-800 space-y-2">
          <label className="block text-xs font-bold text-slate-300">نوع التحصيل والسداد:</label>
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => {
                setPayType('كاش');
                setCustomPaidAmount('');
              }}
              className={`py-2 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition active:scale-95 ${
                payType === 'كاش'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-900/30'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <Banknote className="w-3.5 h-3.5" />
              <span>كاش كامل</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setPayType('آجل');
                setCustomPaidAmount('0');
              }}
              className={`py-2 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition active:scale-95 ${
                payType === 'آجل'
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-900/30'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span>آجل كامل</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setPayType('جزئي');
                setCustomPaidAmount(String(Math.round(totals.grandTotal / 2)));
              }}
              className={`py-2 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition active:scale-95 ${
                payType === 'جزئي'
                  ? 'bg-amber-500 text-slate-950 font-black shadow-md shadow-amber-900/30'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <span>تحصيل جزئي</span>
            </button>
          </div>

          {/* Paid input */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <div>
              <span className="text-[10px] text-slate-400 block mb-1">المبلغ المدفوع كاش الآن (ج.م)</span>
              <input
                type="number"
                step="0.01"
                min="0"
                max={totals.grandTotal}
                value={customPaidAmount !== '' ? customPaidAmount : calculatedPaid}
                onChange={(e) => setCustomPaidAmount(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono font-bold focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <span className="text-[10px] text-slate-400 block mb-1">المتبقي يُسجل آجل</span>
              <div className="w-full bg-slate-850 border border-slate-750 rounded-xl px-3 py-2 text-xs font-mono font-bold text-rose-400">
                {formatMoney(remainingCredit)} ج.م
              </div>
            </div>
          </div>
        </div>

        {error && (
          <div className="p-3 bg-rose-500/15 border border-rose-500/30 rounded-xl flex items-center gap-2 text-xs text-rose-300">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Submit & Print Button */}
        <button
          onClick={handleCommit}
          disabled={isSubmitting || cart.length === 0}
          className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 disabled:opacity-50 text-white font-black rounded-2xl text-sm flex items-center justify-center gap-2 shadow-xl shadow-emerald-950 active:scale-98 transition"
        >
          <Printer className="w-5 h-5" />
          <span>
            {isSubmitting
              ? 'جاري الاعتماد والطباعة…'
              : 'اعتماد الفاتورة وطباعة الإيصال الحراري 80mm'}
          </span>
        </button>
      </div>
    </div>
  );
};
