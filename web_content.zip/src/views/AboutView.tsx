import React from 'react';
import { useApp } from '../context/AppContext';
import { translations } from '../data/translations';
import { 
  Building2, 
  ShieldCheck, 
  Award, 
  Smartphone, 
  Sparkles, 
  ArrowLeft, 
  ArrowRight,
  Crown
} from 'lucide-react';

export const AboutView: React.FC = () => {
  const { language, setCurrentView, openRequestModalForService } = useApp();
  const t = translations[language];
  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  return (
    <div className="py-12 bg-black min-h-screen text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Breadcrumb */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => setCurrentView('home')}
            className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-zinc-400 hover:text-amber-300 transition-colors"
          >
            <ArrowIcon className="w-4 h-4 text-[#D4AF37]" />
            <span>{t.backToHome}</span>
          </button>
          <span className="text-xs bg-zinc-900 border border-[#D4AF37]/40 text-amber-300 font-bold px-3 py-1 rounded-full">
            {isAr ? 'عن مشروع المواساة' : 'About Al-Mowasat Platform'}
          </span>
        </div>

        {/* Hero in Black & Gold */}
        <div className="relative overflow-hidden bg-gradient-to-r from-zinc-950 via-black to-zinc-950 rounded-3xl p-8 sm:p-12 text-white shadow-2xl border border-[#D4AF37]/40">
          <div className="max-w-3xl space-y-4">
            <span className="text-xs bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40 px-3.5 py-1.5 rounded-full font-bold inline-flex items-center gap-1.5">
              <Crown className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>{isAr ? 'الرؤية والرسالة الاستثمارية' : 'Platform Vision & Investment Overview'}</span>
            </span>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-black bg-gradient-to-r from-white via-zinc-100 to-amber-200 bg-clip-text text-transparent tracking-tight">
              {t.slogan}
            </h1>
            <p className="text-zinc-300 text-sm sm:text-base leading-relaxed">
              {isAr
                ? 'مشروع منصة المواساة هو منظومة رقمية ولوجستية وطنية متكاملة تهدف إلى وضع مصر في صدارة خريطة السياحة العلاجية العالمية، من خلال تمكين المرضى الوافدين من الوصول المباشر لأفضل الكوادر الطبية والمراكز المعتمدة مع رعاية شخصية كاملة.'
                : 'Al-Mowasat is an integrated digital health logistics platform designed to position Egypt at the forefront of global medical and wellness tourism by offering international patients frictionless concierge access to premier surgical professors and accredited facilities.'}
            </p>
          </div>
        </div>

        {/* 3 Core Strengths in Black & Gold */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-zinc-950 p-7 rounded-3xl border border-[#D4AF37]/30 shadow-xl space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-black border border-[#D4AF37]/40 text-amber-400 flex items-center justify-center">
              <Award className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white">
              {isAr ? 'الريادة الطبية المصرية' : 'Egyptian Clinical Eminence'}
            </h3>
            <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
              {isAr
                ? 'تاريخ عريق يمتد لعقود في كليات الطب العريقة وزراعة الأعضاء وجراحة القلب الدقيقة التي يشار إليها بالبنان إقليمياً وعالمياً.'
                : 'Decades of clinical prestige in complex organ transplantation, interventional cardiology, and academic surgical schools.'}
            </p>
          </div>

          <div className="bg-zinc-950 p-7 rounded-3xl border border-[#D4AF37]/30 shadow-xl space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-black border border-[#D4AF37]/40 text-amber-400 flex items-center justify-center">
              <Sparkles className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white">
              {isAr ? 'التنوع البيئي الاستشفائي الفريد' : 'Unmatched Healing Geography'}
            </h3>
            <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
              {isAr
                ? 'سيوة، أسوان، سفاجا، ووادي النطرون تشكل مقومات استشفائية ومناخية طبيعية نادرة على كوكب الأرض تجذب الباحثين عن التعافي من شتى البقاع.'
                : 'Siwa salt lakes, Aswan zero-humidity winter sunshine, and Safaga curative sands form a natural ecosystem unique in the Mediterranean.'}
            </p>
          </div>

          <div className="bg-zinc-950 p-7 rounded-3xl border border-[#D4AF37]/30 shadow-xl space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-black border border-[#D4AF37]/40 text-amber-400 flex items-center justify-center">
              <Smartphone className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white">
              {isAr ? 'بنية برمجية مهيأة لتطبيقات أندرويد' : 'Mobile-First & Scalable'}
            </h3>
            <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
              {isAr
                ? 'تم بناء هذا النموذج الأولي بهندسة برمجية منفصلة قابلة للتكامل المباشر مع قواعد بيانات سحابية والتحول إلى تطبيق Android أصيل مستقبلاً.'
                : 'Constructed with a decoupled architecture ready for cloud DB integration and seamless packaging into a standalone Android application.'}
            </p>
          </div>
        </div>

        {/* Bottom CTA in Black & Gold */}
        <div className="bg-zinc-950 rounded-3xl p-8 border border-[#D4AF37]/40 shadow-2xl text-center space-y-4 max-w-2xl mx-auto">
          <img 
            src="/assets/aistudio/logo_transparent.png" 
            alt="Al Mowasat" 
            className="w-24 h-auto mx-auto object-contain drop-shadow-[0_4px_12px_rgba(212,175,55,0.4)]"
          />
          <h3 className="text-xl font-bold bg-gradient-to-r from-white via-zinc-100 to-amber-200 bg-clip-text text-transparent">
            {isAr ? 'هل أنت مستثمر أو جهة طبية ترغب في الشراكة؟' : 'Healthcare Partner or Investor?'}
          </h3>
          <p className="text-xs sm:text-sm text-zinc-400">
            {isAr
              ? 'يسعدنا استعراض إمكانات النموذج الأولي ومناقشة آفاق التوسع المشترك.'
              : 'Explore the full prototype capabilities and discuss strategic partnership avenues.'}
          </p>
          <div className="flex flex-wrap justify-center gap-3 pt-2">
            <button
              onClick={() => setCurrentView('admin')}
              className="px-5 py-3 bg-black hover:bg-zinc-900 text-amber-300 border border-[#D4AF37]/50 font-bold text-xs rounded-xl transition-colors"
            >
              {isAr ? 'استعراض لوحة الإدارة التجريبية' : 'Open Admin Dashboard'}
            </button>
            <button
              onClick={() => openRequestModalForService('medical_sector')}
              className="px-5 py-3 bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black font-extrabold text-xs rounded-xl transition-all shadow-md shadow-amber-500/20"
            >
              {isAr ? 'تجربة تقديم طلب' : 'Test Request Submission'}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
