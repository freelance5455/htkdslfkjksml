import React from 'react';
import { Undo2, Plus, Calendar, Package, ArrowUpRight } from 'lucide-react';
import { ReturnRecord, Product, Customer } from '../db/indexedDB';
import { formatMoney } from '../utils/calc';

interface ReturnsViewProps {
  returns: ReturnRecord[];
  products: Product[];
  customers: Customer[];
  onOpenReturnModal: () => void;
}

export const ReturnsView: React.FC<ReturnsViewProps> = ({
  returns,
  products,
  customers,
  onOpenReturnModal,
}) => {
  const prodMap = new Map(products.map((p) => [p.id, p]));
  const custMap = new Map(customers.map((c) => [c.id, c]));

  const totalReturnAmount = returns.reduce((a, r) => a + Number(r.amount || 0), 0);
  const totalReturnQty = returns.reduce((a, r) => a + Number(r.qty || 0), 0);

  return (
    <div className="space-y-3.5 pb-24 pt-2">
      {/* KPI Tiles */}
      <div className="grid grid-cols-3 gap-2">
        <div className="bg-slate-900 border border-rose-500/30 rounded-2xl p-3 text-center">
          <span className="text-[10px] text-slate-400 block font-bold">قيمة المرتجعات</span>
          <span className="text-base font-black font-mono text-rose-400 block mt-0.5">
            {formatMoney(totalReturnAmount)}
          </span>
          <span className="text-[10px] text-slate-400">ج.م</span>
        </div>

        <div className="bg-slate-900 border border-sky-500/30 rounded-2xl p-3 text-center">
          <span className="text-[10px] text-slate-400 block font-bold">إجمالي القطع</span>
          <span className="text-base font-black font-mono text-sky-400 block mt-0.5">
            {totalReturnQty}
          </span>
          <span className="text-[10px] text-slate-400">قطعة</span>
        </div>

        <div className="bg-slate-900 border border-slate-700/60 rounded-2xl p-3 text-center">
          <span className="text-[10px] text-slate-400 block font-bold">عدد العمليات</span>
          <span className="text-base font-black font-mono text-white block mt-0.5">
            {returns.length}
          </span>
          <span className="text-[10px] text-slate-400">إرجاع</span>
        </div>
      </div>

      {/* Header and New return button */}
      <div className="flex items-center justify-between px-1">
        <h2 className="text-xs font-bold text-slate-300">سجل المرتجعات المتطور</h2>
        <button
          onClick={onOpenReturnModal}
          className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs flex items-center gap-1 active:scale-95 transition"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>+ تسجيل مرتجع</span>
        </button>
      </div>

      {/* Returns List */}
      <div className="space-y-2">
        {returns.length > 0 ? (
          returns
            .slice()
            .reverse()
            .map((r) => {
              const prod = prodMap.get(r.productId);
              const cust = custMap.get(r.customerId);

              return (
                <div
                  key={r.id}
                  className="bg-slate-900 border border-slate-800 rounded-3xl p-3.5 shadow-lg space-y-2 text-xs"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono bg-rose-500/20 text-rose-300 px-1.5 py-0.5 rounded-md border border-rose-500/30">
                          {r.returnNo}
                        </span>
                        <span className="font-bold text-white text-xs">
                          {cust?.name || r.customerName || r.customerId}
                        </span>
                      </div>
                      <span className="text-slate-300 font-bold block mt-1">
                        {prod?.name || r.productId}
                      </span>
                    </div>

                    <div className="text-left font-mono">
                      <span className="font-black text-rose-400 block text-sm">
                        {formatMoney(r.amount)} ج.م
                      </span>
                      <span className="text-[10px] text-slate-400 block">
                        الكمية: {r.qty} قطعة
                      </span>
                    </div>
                  </div>

                  {/* Badges row */}
                  <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-[11px] text-slate-400">
                    <div className="flex items-center gap-2">
                      <span className="bg-slate-800 px-2 py-0.5 rounded-md text-amber-300">
                        الحالة: {r.type}
                      </span>
                      <span className="bg-slate-800 px-2 py-0.5 rounded-md text-sky-300">
                        الوجهة: {r.destination}
                      </span>
                      <span className="bg-slate-800 px-2 py-0.5 rounded-md text-emerald-300">
                        التسوية: {r.refundType}
                      </span>
                    </div>

                    <span className="text-[10px] font-mono text-slate-500">
                      {new Date(r.date).toLocaleDateString('ar-EG')}
                    </span>
                  </div>

                  {r.reason && (
                    <p className="text-[11px] text-slate-400 bg-slate-850 p-2 rounded-xl">
                      السبب: {r.reason}
                    </p>
                  )}
                </div>
              );
            })
        ) : (
          <div className="p-8 text-center text-xs text-slate-500 bg-slate-900 border border-slate-800 rounded-3xl">
            لا توجد مرتجعات مسجلة حتى الآن.
          </div>
        )}
      </div>
    </div>
  );
};
