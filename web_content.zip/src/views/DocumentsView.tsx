import React, { useState } from 'react';
import { 
  FileText, 
  Search, 
  Upload, 
  Download, 
  Eye, 
  Trash2, 
  Lock, 
  Globe, 
  Filter,
  CheckCircle2,
  FileCheck
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { DocumentPreviewModal } from '../components/DocumentPreviewModal';
import { ProjectDocument, DocumentCategory } from '../types';

export const DocumentsView: React.FC = () => {
  const { 
    documents, 
    projects, 
    currentUser, 
    uploadDocument, 
    deleteDocument,
    setSelectedProjectId,
    setActiveView 
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedAccessLevel, setSelectedAccessLevel] = useState<string>('All');
  const [previewDocument, setPreviewDocument] = useState<ProjectDocument | null>(null);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);

  // Form state
  const [projectId, setProjectId] = useState(projects[0]?.id || '');
  const [title, setTitle] = useState('');
  const [filename, setDocFilename] = useState('');
  const [category, setDocCategory] = useState<DocumentCategory>('CAD Drawing');
  const [accessLevel, setAccessLevel] = useState<'Client Shared' | 'Internal Only'>('Client Shared');
  const [previewText, setDocPreviewText] = useState('');

  const categories: DocumentCategory[] = [
    'CAD Drawing',
    'Form B NOC',
    'Inspection Report',
    'Quotation',
    'Work Order',
    'Completion Certificate',
    'Service Report',
    'Site Photo'
  ];

  // Filtering
  const filteredDocuments = documents.filter(doc => {
    // If client, only Client Shared
    if (currentUser.role === 'Client' && doc.accessLevel !== 'Client Shared') return false;

    const matchesCategory = selectedCategory === 'All' || doc.category === selectedCategory;
    const matchesAccess = selectedAccessLevel === 'All' || doc.accessLevel === selectedAccessLevel;
    const matchesSearch = 
      doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.filename.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.projectReference.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.uploadedBy.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesAccess && matchesSearch;
  });

  const handleUploadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const proj = projects.find(p => p.id === projectId);
    if (!proj || !title || !filename) return;

    const ext = filename.split('.').pop()?.toLowerCase();
    let fileType: 'pdf' | 'dwg' | 'image' | 'doc' = 'pdf';
    if (ext === 'dwg' || ext === 'dxf') fileType = 'dwg';
    else if (['jpg', 'jpeg', 'png'].includes(ext || '')) fileType = 'image';
    else if (['doc', 'docx'].includes(ext || '')) fileType = 'doc';

    uploadDocument({
      projectId,
      projectReference: proj.reference,
      title,
      filename,
      fileType,
      fileSize: '2.1 MB',
      category,
      accessLevel,
      previewText: previewText || `Technical fire document on file for ${proj.reference}`
    });

    setIsUploadModalOpen(false);
    setTitle('');
    setDocFilename('');
    setDocPreviewText('');
  };

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Project Document Repository</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Central repository for CAD drawings, Tamil Nadu Fire Service Form B NOCs, quotations, and certificates.
          </p>
        </div>

        {currentUser.role !== 'Client' && (
          <button
            onClick={() => setIsUploadModalOpen(true)}
            className="px-4 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg cursor-pointer shadow-xs transition-colors flex items-center gap-1.5 self-start sm:self-auto"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Upload Document</span>
          </button>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          {/* Category Chips / Tabs */}
          <div className="overflow-x-auto no-scrollbar pb-1 sm:pb-0 -mx-1 px-1">
            <div className="flex items-center gap-1.5 w-max">
              <button
                onClick={() => setSelectedCategory('All')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors shrink-0 cursor-pointer ${
                  selectedCategory === 'All' 
                    ? 'bg-slate-900 text-white font-semibold' 
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                All Categories ({documents.length})
              </button>
              {categories.map(c => {
                const count = documents.filter(d => d.category === c).length;
                return (
                  <button
                    key={c}
                    onClick={() => setSelectedCategory(c)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors shrink-0 cursor-pointer flex items-center gap-1.5 ${
                      selectedCategory === c 
                        ? 'bg-red-600 text-white font-semibold' 
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    <span>{c}</span>
                    <span className="text-[10px] font-mono opacity-80">({count})</span>
                  </button>
                );
              })}
            </div>
          </div>

          {currentUser.role !== 'Client' && (
            <select
              value={selectedAccessLevel}
              onChange={(e) => setSelectedAccessLevel(e.target.value)}
              className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 cursor-pointer self-start sm:self-auto w-full sm:w-auto"
            >
              <option value="All">All Access Levels</option>
              <option value="Client Shared">Client Shared Only</option>
              <option value="Internal Only">Internal Only</option>
            </select>
          )}
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search documents by title, filename, reference, or uploader..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:border-red-500"
          />
        </div>
      </div>

      {/* Documents Table & Mobile Cards */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Mobile Documents Card List */}
        <div className="md:hidden divide-y divide-slate-100">
          {filteredDocuments.length === 0 ? (
            <div className="py-10 text-center text-slate-500 text-xs">
              No documents found matching the filter criteria.
            </div>
          ) : (
            filteredDocuments.map(doc => (
              <div key={doc.id} className="p-4 space-y-2.5 hover:bg-slate-50/70 transition-colors">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <h4 className="font-semibold text-slate-900 text-xs leading-snug">{doc.title}</h4>
                    <p className="font-mono text-[11px] text-slate-500 truncate mt-0.5">{doc.filename}</p>
                  </div>
                  <span className="font-mono text-[10px] uppercase font-bold text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded shrink-0">
                    {doc.fileType}
                  </span>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-500">
                  <button
                    onClick={() => {
                      setSelectedProjectId(doc.projectId);
                      setActiveView('project-detail');
                    }}
                    className="font-mono text-red-600 font-semibold hover:underline"
                  >
                    {doc.projectReference}
                  </button>
                  <span>{doc.category} · {doc.fileSize}</span>
                </div>

                <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-100 text-xs">
                  <div>
                    {doc.accessLevel === 'Client Shared' ? (
                      <span className="text-emerald-700 font-medium text-[10px] flex items-center gap-1 bg-emerald-50 px-1.5 py-0.5 rounded">
                        <Globe className="w-3 h-3 text-emerald-600" />
                        <span>Client Shared</span>
                      </span>
                    ) : (
                      <span className="text-slate-500 font-medium text-[10px] flex items-center gap-1 bg-slate-100 px-1.5 py-0.5 rounded">
                        <Lock className="w-3 h-3" />
                        <span>Internal</span>
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setPreviewDocument(doc)}
                      className="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-white rounded text-xs font-semibold cursor-pointer"
                    >
                      View
                    </button>
                    {currentUser.role !== 'Client' && (
                      <button
                        onClick={() => deleteDocument(doc.id)}
                        className="px-2 py-1 text-red-600 hover:bg-red-50 rounded cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Desktop Table */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Document Title & Filename</th>
                <th className="py-3 px-4">Project Ref</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">File Type & Size</th>
                <th className="py-3 px-4">Uploaded By</th>
                <th className="py-3 px-4">Upload Date</th>
                <th className="py-3 px-4">Access</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredDocuments.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-10 text-center text-slate-500">
                    No documents found matching the filter criteria.
                  </td>
                </tr>
              ) : (
                filteredDocuments.map(doc => (
                  <tr key={doc.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3.5 px-4 max-w-xs">
                      <p className="font-semibold text-slate-900 leading-snug">{doc.title}</p>
                      <p className="text-[11px] text-slate-500 font-mono mt-0.5">{doc.filename}</p>
                    </td>
                    <td className="py-3.5 px-4 font-mono font-semibold text-red-600">
                      <button
                        onClick={() => {
                          setSelectedProjectId(doc.projectId);
                          setActiveView('project-detail');
                        }}
                        className="hover:underline cursor-pointer"
                      >
                        {doc.projectReference}
                      </button>
                    </td>
                    <td className="py-3.5 px-4 text-slate-700">
                      {doc.category}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-slate-600">
                      <span className="uppercase font-semibold text-slate-800">{doc.fileType}</span> · {doc.fileSize}
                    </td>
                    <td className="py-3.5 px-4 text-slate-700">
                      {doc.uploadedBy}
                    </td>
                    <td className="py-3.5 px-4 font-mono tabular-nums text-slate-600">
                      {doc.uploadDate}
                    </td>
                    <td className="py-3.5 px-4">
                      {doc.accessLevel === 'Client Shared' ? (
                        <span className="text-emerald-700 font-medium text-[11px] flex items-center gap-1">
                          <Globe className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Client Shared</span>
                        </span>
                      ) : (
                        <span className="text-slate-500 font-medium text-[11px] flex items-center gap-1">
                          <Lock className="w-3.5 h-3.5" />
                          <span>Internal Only</span>
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setPreviewDocument(doc)}
                          className="px-2.5 py-1 text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded font-semibold cursor-pointer"
                        >
                          View
                        </button>
                        {currentUser.role !== 'Client' && (
                          <button
                            onClick={() => deleteDocument(doc.id)}
                            className="px-2 py-1 text-red-600 hover:text-red-800 hover:bg-red-50 rounded cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Document Preview Modal */}
      <DocumentPreviewModal
        document={previewDocument}
        onClose={() => setPreviewDocument(null)}
      />

      {/* Upload Document Modal */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-md p-6">
            <h3 className="text-base font-bold text-slate-900">Upload Project Document</h3>
            <p className="text-xs text-slate-500 mt-0.5">Attach drawings, quotations, or compliance certificates</p>

            <form onSubmit={handleUploadSubmit} className="mt-4 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Target Project *</label>
                <select
                  value={projectId}
                  onChange={(e) => setProjectId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer"
                >
                  {projects.map(p => (
                    <option key={p.id} value={p.id}>{p.reference} - {p.name.substring(0, 24)}...</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Document Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. As-Built Fire Alarm Schematic Rev 4"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Filename *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Apollo_DWG_Rev4.dwg or Cert.pdf"
                  value={filename}
                  onChange={(e) => setDocFilename(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setDocCategory(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer"
                  >
                    {categories.map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Access Level</label>
                  <select
                    value={accessLevel}
                    onChange={(e) => setAccessLevel(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer"
                  >
                    <option value="Client Shared">Client Shared</option>
                    <option value="Internal Only">Internal Only</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Summary / Technical Notes</label>
                <textarea
                  rows={2}
                  placeholder="Summary for document preview..."
                  value={previewText}
                  onChange={(e) => setDocPreviewText(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsUploadModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:text-slate-900 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold cursor-pointer shadow-xs"
                >
                  Upload File
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
