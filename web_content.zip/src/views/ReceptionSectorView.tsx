import React from 'react';
import { useApp } from '../context/AppContext';
import { translations } from '../data/translations';
import { 
  Plane, 
  Car, 
  Hotel, 
  Languages, 
  UserCheck, 
  ShieldCheck, 
  Send, 
  ArrowLeft, 
  ArrowRight, 
  Check,
  Crown
} from 'lucide-react';

export const ReceptionSectorView: React.FC = () => {
  const { language, setCurrentView, openRequestModalForService, translators } = useApp();
  const t = translations[language];
  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  const receptionServices = [
    {
      icon: <Plane className="w-6 h-6 text-[#D4AF37]" />,
      titleAr: 'استقبال المطار وإنهاء الإجراءات VIP',
      titleEn: 'VIP Airport Meet & Greet',
      descAr: 'استقبال من بوابة الطائرة، تخليص إجراءات الجوازات والجمارك دون انتظار، واستلام الأمتعة بأعلى درجات الراحة.',
      descEn: 'Tarmac or gate reception, expedited immigration clearance, baggage handling, and access to VIP airport lounges.'
    },
    {
      icon: <Car className="w-6 h-6 text-[#D4AF37]" />,
      titleAr: 'أسطول تنقلات خاصة وإسعاف طبي',
      titleEn: 'Equipped Medical & Luxury Fleet',
      descAr: 'سيارات مرسيدس وفان عائلية فاخرة وسيارات إسعاف مجهزة بالعناية المركزة للحالات الحرجة التي تستدعي نقلاً طبياً عاجلاً.',
      descEn: 'Luxury family vans, executive sedans, and ICU-equipped mobile ambulances for critical patient transfers.'
    },
    {
      icon: <Hotel className="w-6 h-6 text-[#D4AF37]" />,
      titleAr: 'حجوزات فندقية وشقق قريبة للمرافقين',
      titleEn: 'Partner Hotels & Serviced Residences',
      descAr: 'ترتيب إقامة راقية في فنادق 5 نجوم أو شقق فندقية مجهزة بالقرب من المستشفى لتسهيل إقامة العائلة والمرافقين.',
      descEn: 'Negotiated corporate rates at 5-star hotels and serviced residences adjacent to major medical complexes.'
    },
    {
      icon: <Languages className="w-6 h-6 text-[#D4AF37]" />,
      titleAr: 'مترجمون طبيون معتمدون',
      titleEn: 'Certified Medical Interpreters',
      descAr: 'ترجمة طبية فورية دقيقة بلغات متعددة (الإنجليزية، الفرنسية، الروسية، السواحلية، الأوردية) أثناء الكشف والجراحة.',
      descEn: 'Experienced clinical interpreters ensuring seamless doctor-patient dialogue during assessments and surgical rounds.'
    },
    {
      icon: <UserCheck className="w-6 h-6 text-[#D4AF37]" />,
      titleAr: 'مرافق شخصي مخصص (Patient Concierge)',
      titleEn: 'Dedicated Patient Care Navigator',
      descAr: 'منسق شخصي يلازم المريض والمرافق على مدار الساعة لتسهيل الإجراءات الطبية والمالية واللوجستية والترفيهية.',
      descEn: 'A dedicated patient advocate assisting with hospital paperwork, logistics, dining, and daily needs 24/7.'
    },
    {
      icon: <ShieldCheck className="w-6 h-6 text-[#D4AF37]" />,
      titleAr: 'التنسيق بين الفندق والمستشفى ذهاباً وإياباً',
      titleEn: 'Scheduled Clinic Shuttle & Escort',
      descAr: 'جدول مواعيد دقيق لنقل المريض من مقر إقامته إلى المستشفى للفحوصات وجلسات العلاج وإعادته بأمان.',
      descEn: 'Punctual private chauffeur routing synchronized with outpatient appointments and diagnostic scans.'
    }
  ];

  return (
    <div className="py-12 bg-black min-h-screen text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Breadcrumb */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => setCurrentView('home')}
            className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-zinc-400 hover:text-amber-300 transition-colors"
          >
            <ArrowIcon className="w-4 h-4 text-[#D4AF37]" />
            <span>{t.backToHome}</span>
          </button>
          <span className="text-xs bg-zinc-900 border border-[#D4AF37]/40 text-amber-300 font-bold px-3 py-1 rounded-full">
            {isAr ? 'بروتوكول استقبال المرضى الدوليين' : 'International Patient Reception Protocol'}
          </span>
        </div>

        {/* Hero Banner in Black & Gold */}
        <div className="relative overflow-hidden bg-gradient-to-r from-zinc-950 via-black to-zinc-950 rounded-3xl p-8 sm:p-12 text-white shadow-2xl border border-[#D4AF37]/40">
          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center gap-2 bg-[#D4AF37]/15 text-amber-300 border border-[#D4AF37]/40 px-3 py-1 rounded-full text-xs font-semibold">
              <Plane className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>{isAr ? 'رعاية متكاملة تبدأ من لحظة هبوط الطائرة' : 'Full Concierge from Tarmac to Recovery'}</span>
            </div>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-black bg-gradient-to-r from-white via-zinc-100 to-amber-200 bg-clip-text text-transparent tracking-tight">
              {isAr ? 'استقبال المرضى الأجانب والخدمات اللوجستية الفاخرة' : 'Foreign Patient Reception & Executive Hospitality'}
            </h1>
            <p className="text-zinc-300 text-sm sm:text-base leading-relaxed">
              {isAr
                ? 'ندير كل تفاصيل رحلتك في مصر: من استقبال المطار VIP، وتوفير السيارات المجهزة، وترتيب إقامة المرافقين، إلى توفير المترجمين والمرافق الشخصي طوال مدة إقامتك.'
                : 'Managing every travel and logistics detail in Egypt: VIP airport fast-track, medical and luxury transport, 5-star hotel bookings, certified interpreters, and dedicated personal escorts.'}
            </p>
            <div className="pt-2 flex flex-wrap gap-3">
              <button
                onClick={() => openRequestModalForService('foreign_reception')}
                className="bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black font-extrabold px-6 py-3.5 rounded-xl text-xs sm:text-sm transition-all shadow-xl shadow-amber-500/20 flex items-center gap-2"
              >
                <Send className="w-4 h-4 text-black" />
                <span>{isAr ? 'طلب باقة استقبال ولوجستيات' : 'Book Full Reception Package'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* 6 Reception Modules Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {receptionServices.map((srv, idx) => (
            <div 
              key={idx}
              className="bg-zinc-950 rounded-3xl p-7 border border-zinc-800 hover:border-[#D4AF37] shadow-xl hover:shadow-[0_0_20px_rgba(212,175,55,0.2)] transition-all flex flex-col justify-between group"
            >
              <div>
                <div className="w-14 h-14 rounded-2xl bg-black border border-[#D4AF37]/40 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform shadow-md">
                  {srv.icon}
                </div>
                <h3 className="text-lg font-bold text-white mb-2 group-hover:text-amber-300 transition-colors">
                  {isAr ? srv.titleAr : srv.titleEn}
                </h3>
                <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
                  {isAr ? srv.descAr : srv.descEn}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-zinc-900 flex items-center text-xs text-amber-400 font-semibold gap-1.5">
                <Check className="w-4 h-4 text-[#D4AF37]" />
                <span>{isAr ? 'مشمول في باقات التنسيق الطبي' : 'Included in Care Packages'}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Translators & Escorts Showcase */}
        <div className="bg-zinc-950 rounded-3xl p-8 border border-[#D4AF37]/30 shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-2xl font-black text-white">
                {isAr ? 'فريق المترجمين والمرافقين اللغويين المعتمدين' : 'Certified Medical Interpreters & Concierges'}
              </h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                {isAr ? 'مترجمون حاصلون على تدريب في المصطلحات الطبية للعمل داخل غرف العمليات والعيادات' : 'Medically certified interpreters bridging cultural and language gaps seamlessly'}
              </p>
            </div>
            <span className="text-xs bg-black text-amber-300 px-3 py-1.5 rounded-xl font-mono border border-zinc-800 self-start sm:self-auto">
              {isAr ? '6+ لغات عالمية متاحة' : '6+ Languages Available'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {translators.map(tr => (
              <div key={tr.id} className="bg-black rounded-2xl p-5 border border-zinc-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-full bg-zinc-900 border border-[#D4AF37]/30 text-amber-300 font-bold flex items-center justify-center text-xs">
                    {tr.name.split(' ')[0][0]}
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    tr.status === 'available' ? 'bg-[#D4AF37]/20 text-amber-300 border border-[#D4AF37]/40' : 'bg-zinc-900 text-zinc-500 border border-zinc-800'
                  }`}>
                    {tr.status === 'available' ? (isAr ? 'متاح الآن' : 'Available') : (isAr ? 'في مهمة حالية' : 'On Duty')}
                  </span>
                </div>

                <div>
                  <h4 className="font-bold text-white text-sm">{tr.name}</h4>
                  <p className="text-[11px] text-zinc-500 mt-0.5">{tr.specialty}</p>
                </div>

                <div className="pt-2 border-t border-zinc-900 text-xs">
                  <div className="text-[11px] text-zinc-500 mb-1">{isAr ? 'اللغات المتقنة:' : 'Languages:'}</div>
                  <div className="flex flex-wrap gap-1">
                    {tr.languages.map((l, lIdx) => (
                      <span key={lIdx} className="bg-zinc-900 border border-zinc-800 px-2 py-0.5 rounded text-[10px] text-amber-200">
                        {l}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
