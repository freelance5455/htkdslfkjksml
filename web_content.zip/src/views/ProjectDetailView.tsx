import React, { useState } from 'react';
import { 
  ArrowLeft, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Send, 
  Mic, 
  FileText, 
  Upload, 
  Plus, 
  Download, 
  Eye, 
  ShieldCheck, 
  User, 
  Calendar,
  MessageSquare,
  History,
  Sliders,
  Check,
  Building2,
  MapPin,
  Trash2,
  ExternalLink
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { VoiceMessagePlayer } from '../components/VoiceMessagePlayer';
import { VoiceRecorderModal } from '../components/VoiceRecorderModal';
import { DocumentPreviewModal } from '../components/DocumentPreviewModal';
import { TaskModal } from '../components/TaskModal';
import { ProjectDocument, DocumentCategory, Task, ProjectMilestone } from '../types';

export const ProjectDetailView: React.FC = () => {
  const { 
    selectedProjectId, 
    setSelectedProjectId, 
    setActiveView, 
    projects, 
    clients, 
    users, 
    currentUser, 
    tasks, 
    messages, 
    documents, 
    progressUpdates, 
    activities, 
    updateProjectProgress, 
    toggleMilestone, 
    sendMessage, 
    submitProgressUpdate, 
    uploadDocument,
    deleteDocument,
    updateTaskStatus,
    employees,
    settings,
    markMessagesAsRead
  } = useApp();

  const [activeTab, setActiveTab] = useState<'overview' | 'timeline' | 'tasks' | 'updates' | 'conversation' | 'documents' | 'audit'>('overview');
  
  // Modals
  const [isVoiceRecorderOpen, setIsVoiceRecorderOpen] = useState(false);
  const [previewDocument, setPreviewDocument] = useState<ProjectDocument | null>(null);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [taskToEdit, setTaskToEdit] = useState<Task | null>(null);
  const [isProgressReportModalOpen, setIsProgressReportModalOpen] = useState(false);
  const [isUploadDocModalOpen, setIsUploadDocModalOpen] = useState(false);

  // Conversation text message input
  const [textMessage, setTextMessage] = useState('');

  // Progress Report form state
  const [reportPercentage, setReportPercentage] = useState(75);
  const [reportNotes, setReportNotes] = useState('');
  const [reportAttachment, setReportAttachment] = useState('');
  const [reportClientVisible, setReportClientVisible] = useState(true);

  // Manual Progress slider modal state
  const [manualProgressValue, setManualProgressValue] = useState(75);
  const [showManualSlider, setShowManualSlider] = useState(false);

  // Document Upload form state
  const [docTitle, setDocTitle] = useState('');
  const [docCategory, setDocCategory] = useState<DocumentCategory>('CAD Drawing');
  const [docAccessLevel, setDocAccessLevel] = useState<'Client Shared' | 'Internal Only'>('Client Shared');
  const [docFilename, setDocFilename] = useState('');
  const [docPreviewText, setDocPreviewText] = useState('');

  const project = projects.find(p => p.id === selectedProjectId);

  if (!project) {
    return (
      <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
        <p className="text-slate-600 text-sm">Project record not found or has been removed.</p>
        <button
          onClick={() => setActiveView(currentUser.role === 'Admin' ? 'projects' : (currentUser.role === 'Client' ? 'client-portal' : 'employee-portal'))}
          className="mt-4 px-4 py-2 bg-red-600 text-white rounded-lg text-xs font-semibold cursor-pointer"
        >
          Return to Projects
        </button>
      </div>
    );
  }

  const client = clients.find(c => c.id === project.clientId);
  const assignedTeam = users.filter(u => project.assignedEmployeeIds.includes(u.id));
  
  // Filter items for this project
  const projectTasks = tasks.filter(t => t.projectId === project.id);
  // For client portal: only show tasks marked visibleToClient!
  const visibleTasks = currentUser.role === 'Client' 
    ? projectTasks.filter(t => t.visibleToClient)
    : projectTasks;

  const projectMessages = messages.filter(m => m.projectId === project.id);
  
  // Documents: Clients only see 'Client Shared'
  const projectDocs = documents.filter(d => 
    d.projectId === project.id && 
    (currentUser.role !== 'Client' || d.accessLevel === 'Client Shared')
  );

  // Assigned employees from ppm_employees / ppm_project_employees
  const assignedEmployeesList = employees.filter(e => project.assignedEmployeeIds.includes(e.id));

  // Unread client messages count matching WordPress admin/view-project.php
  const unreadClientMessages = projectMessages.filter(m => m.senderType === 'client' && !m.isRead).length;

  // Sorted tasks for Project Timeline tab matching templates/project-timeline.php
  const timelineTasks = [...visibleTasks].sort((a, b) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime());

  const projectActivities = activities.filter(a => a.projectId === project.id);
  const projectUpdates = progressUpdates.filter(u => u.projectId === project.id && (currentUser.role !== 'Client' || u.clientVisible));

  const handleSendTextMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!textMessage.trim()) return;
    sendMessage(project.id, textMessage.trim(), 'text');
    setTextMessage('');
  };

  const handleSendVoiceMessage = (audioUrl: string, durationSeconds: number, summaryText?: string) => {
    sendMessage(
      project.id,
      summaryText || `Voice note (${durationSeconds}s)`,
      'voice',
      audioUrl,
      durationSeconds
    );
  };

  const handleSubmitProgressForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reportNotes) return;
    submitProgressUpdate({
      projectId: project.id,
      percentageReported: Number(reportPercentage),
      notes: reportNotes,
      attachmentName: reportAttachment || undefined,
      clientVisible: reportClientVisible
    });
    setIsProgressReportModalOpen(false);
    setReportNotes('');
    setReportAttachment('');
  };

  const handleUploadDocumentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!docTitle || !docFilename) return;

    const ext = docFilename.split('.').pop()?.toLowerCase();
    let fileType: 'pdf' | 'dwg' | 'image' | 'doc' = 'pdf';
    if (ext === 'dwg' || ext === 'dxf') fileType = 'dwg';
    else if (['jpg', 'jpeg', 'png'].includes(ext || '')) fileType = 'image';
    else if (['doc', 'docx'].includes(ext || '')) fileType = 'doc';

    uploadDocument({
      projectId: project.id,
      projectReference: project.reference,
      title: docTitle,
      filename: docFilename,
      fileType,
      fileSize: '1.8 MB',
      category: docCategory,
      accessLevel: docAccessLevel,
      previewText: docPreviewText || `Document filed under ${docCategory} for ${project.reference}`
    });

    setIsUploadDocModalOpen(false);
    setDocTitle('');
    setDocFilename('');
    setDocPreviewText('');
  };

  const handleSaveManualProgress = () => {
    updateProjectProgress(project.id, manualProgressValue, true);
    setShowManualSlider(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Breadcrumb & Back Navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => {
            setSelectedProjectId(null);
            if (currentUser.role === 'Client') setActiveView('client-portal');
            else if (currentUser.role === 'Employee') setActiveView('employee-portal');
            else setActiveView('projects');
          }}
          className="text-xs font-semibold text-slate-600 hover:text-slate-900 flex items-center gap-1.5 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>
            Back to {currentUser.role === 'Client' ? 'My Projects' : (currentUser.role === 'Employee' ? 'My Workspace' : 'All Projects')}
          </span>
        </button>

        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="text-slate-400">Project Reference:</span>
          <span className="font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded border border-red-200">
            {project.reference}
          </span>
        </div>
      </div>

      {/* Main Project Overview Card */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6">
        <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-6 pb-6 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
              <span>{project.category}</span>
              <span>·</span>
              <span className="font-semibold text-slate-800">{project.clientCompanyName}</span>
              <span>·</span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                <span>{project.siteLocation}</span>
              </span>
            </div>

            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              {project.name}
            </h1>

            <p className="text-xs text-slate-600 mt-2 max-w-3xl leading-relaxed">
              {project.description}
            </p>
          </div>

          {/* Status & Priority Badge Block */}
          <div className="flex flex-wrap items-center sm:items-end lg:flex-col gap-2 shrink-0">
            <span className={`text-xs px-2.5 py-1 rounded-md font-semibold border ${
              project.status === 'Completed'
                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                : project.status === 'In Progress'
                ? 'bg-blue-50 text-blue-800 border-blue-200'
                : project.status === 'Overdue'
                ? 'bg-red-50 text-red-800 border-red-200 font-bold'
                : 'bg-amber-50 text-amber-800 border-amber-200'
            }`}>
              Status: {project.status}
            </span>

            <span className={`text-xs px-2 py-0.5 rounded font-medium ${
              project.priority === 'Critical'
                ? 'bg-red-100 text-red-800'
                : project.priority === 'High'
                ? 'bg-amber-100 text-amber-800'
                : 'bg-slate-100 text-slate-700'
            }`}>
              Priority: {project.priority}
            </span>

            <div className="text-left sm:text-right text-xs font-mono text-slate-500 mt-1 w-full sm:w-auto">
              Target: <strong className="text-slate-800">{project.expectedCompletionDate}</strong>
            </div>
          </div>
        </div>

        {/* Visual Progress Tracker & Adjustment Controls */}
        <div className="py-5 border-b border-slate-100">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-900">Project Completion Tracker</span>
              <span className="text-[11px] text-slate-400">
                ({project.isManualProgress ? 'Manual Calibration' : 'Milestones & Tasks'})
              </span>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-lg font-bold font-mono text-slate-900 tabular-nums">
                {project.progressPercentage}%
              </span>

              {currentUser.role === 'Admin' && (
                <button
                  onClick={() => {
                    setManualProgressValue(project.progressPercentage);
                    setShowManualSlider(!showManualSlider);
                  }}
                  className="px-2 py-1 text-[11px] text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded font-medium flex items-center gap-1 cursor-pointer"
                >
                  <Sliders className="w-3 h-3" />
                  <span>Adjust Progress</span>
                </button>
              )}
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-300 ${
                project.status === 'Completed'
                  ? 'bg-emerald-600'
                  : project.status === 'Overdue'
                  ? 'bg-red-600'
                  : 'bg-blue-600'
              }`}
              style={{ width: `${project.progressPercentage}%` }}
            />
          </div>

          {/* Manual Progress Slider Popover (For Admin override) */}
          {showManualSlider && (
            <div className="mt-3 p-3 bg-slate-50 border border-slate-200 rounded-lg flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-3 flex-1">
                <span className="text-slate-600 font-medium">Override Value:</span>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={manualProgressValue}
                  onChange={(e) => setManualProgressValue(Number(e.target.value))}
                  className="flex-1 accent-red-600 cursor-pointer"
                />
                <span className="font-mono font-bold text-slate-900 tabular-nums w-12 text-right">
                  {manualProgressValue}%
                </span>
              </div>
              <div className="flex items-center justify-end gap-2">
                <button
                  onClick={() => setShowManualSlider(false)}
                  className="px-2.5 py-1 text-slate-500 hover:text-slate-700"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveManualProgress}
                  className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded font-semibold cursor-pointer"
                >
                  Apply Override
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Quick Project Details Metadata Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 pt-4 text-xs">
          <div>
            <span className="text-slate-400 font-medium block">Contract Value</span>
            <p className="font-mono font-bold text-slate-800">
              ₹{project.contractValueINR.toLocaleString('en-IN')}
            </p>
          </div>
          <div>
            <span className="text-slate-400 font-medium block">Commencement</span>
            <p className="font-mono text-slate-800">{project.startDate}</p>
          </div>
          <div>
            <span className="text-slate-400 font-medium block">Assigned Engineers</span>
            <p className="text-slate-800 font-medium truncate">
              {assignedTeam.map(t => t.name).join(', ') || 'Unassigned'}
            </p>
          </div>
          <div>
            <span className="text-slate-400 font-medium block">Client Officer</span>
            <p className="text-slate-800 font-medium truncate">
              {client?.contactPerson}
            </p>
          </div>
        </div>
      </div>

      {/* Mobile Tab Selector (Instant 1-tap navigation on phones) */}
      <div className="sm:hidden bg-white rounded-t-xl border border-b-0 border-slate-200 p-3 pb-2">
        <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
          Select Project Section
        </label>
        <select
          value={activeTab}
          onChange={(e) => {
            const tab = e.target.value as any;
            setActiveTab(tab);
            if (tab === 'conversation') markMessagesAsRead(project.id);
          }}
          className="w-full text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-900 cursor-pointer focus:outline-hidden focus:border-red-500"
        >
          <option value="overview">📋 Overview & Specifications</option>
          <option value="conversation">
            💬 Conversation {unreadClientMessages > 0 ? `(${unreadClientMessages} unread)` : `(${projectMessages.length})`}
          </option>
          <option value="tasks">✅ Work Order Tasks ({visibleTasks.length})</option>
          <option value="documents">📁 Documents & Drawings ({projectDocs.length})</option>
          <option value="timeline">📅 Project Timeline</option>
          <option value="updates">📊 Progress Reports ({projectUpdates.length})</option>
          {currentUser.role !== 'Client' && (
            <option value="audit">🕒 Audit Trail ({projectActivities.length})</option>
          )}
        </select>
      </div>

      {/* Desktop / Tablet Tabs Navigation */}
      <div className="hidden sm:flex border-b border-slate-200 bg-white rounded-t-xl px-2 sm:px-4 pt-2 overflow-x-auto no-scrollbar gap-1">
        <button
          onClick={() => setActiveTab('overview')}
          className={`py-3 px-3 sm:px-4 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            activeTab === 'overview'
              ? 'border-red-600 text-red-600'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          Overview & Milestones
        </button>

        <button
          onClick={() => {
            setActiveTab('conversation');
            markMessagesAsRead(project.id);
          }}
          className={`py-3 px-3 sm:px-4 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'conversation'
              ? 'border-red-600 text-red-600'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <MessageSquare className="w-3.5 h-3.5 shrink-0" />
          <span>Conversation</span>
          {unreadClientMessages > 0 && (
            <span className="bg-red-600 text-white rounded-full px-1.5 py-0.2 text-[10px] font-bold font-mono shrink-0">
              {unreadClientMessages}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('tasks')}
          className={`py-3 px-3 sm:px-4 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            activeTab === 'tasks'
              ? 'border-red-600 text-red-600'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          Tasks ({visibleTasks.length})
        </button>

        <button
          onClick={() => setActiveTab('documents')}
          className={`py-3 px-3 sm:px-4 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'documents'
              ? 'border-red-600 text-red-600'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <FileText className="w-3.5 h-3.5 shrink-0" />
          <span>Documents ({projectDocs.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('timeline')}
          className={`py-3 px-3 sm:px-4 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'timeline'
              ? 'border-red-600 text-red-600'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <Calendar className="w-3.5 h-3.5 shrink-0" />
          <span>Timeline</span>
        </button>

        <button
          onClick={() => setActiveTab('updates')}
          className={`py-3 px-3 sm:px-4 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            activeTab === 'updates'
              ? 'border-red-600 text-red-600'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          Progress Reports ({projectUpdates.length})
        </button>

        {currentUser.role !== 'Client' && (
          <button
            onClick={() => setActiveTab('audit')}
            className={`py-3 px-3 sm:px-4 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'audit'
                ? 'border-red-600 text-red-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <History className="w-3.5 h-3.5 shrink-0" />
            <span>Audit Trail ({projectActivities.length})</span>
          </button>
        )}
      </div>

      {/* Tab Panels */}
      <div className="bg-white rounded-b-xl border border-t-0 border-slate-200 shadow-xs p-6">
        {/* Tab 1: Overview & Milestones */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* WordPress Overview Details Table matching admin/view-project.php */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <h3 className="text-sm font-bold text-slate-900">Project Overview Specifications</h3>
                <a
                  href={settings.zohoUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-xs transition-colors"
                >
                  <span>Open Zoho CRM</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="space-y-2">
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500 font-medium">Client Company:</span>
                    <span className="font-semibold text-slate-900">{project.clientCompanyName}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500 font-medium">Project Name:</span>
                    <span className="font-semibold text-slate-900">{project.name}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500 font-medium">Site Location:</span>
                    <span className="text-slate-800">{project.siteLocation}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500 font-medium">Status:</span>
                    <span className="font-semibold text-red-600">{project.status}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500 font-medium">Start Date:</span>
                    <span className="font-mono text-slate-800">{project.startDate}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500 font-medium">End Date:</span>
                    <span className="font-mono text-slate-800">{project.expectedCompletionDate}</span>
                  </div>
                  <div className="py-1 border-b border-slate-200/60">
                    <span className="text-slate-500 font-medium block mb-1">Assigned Employees (ppm_project_employees):</span>
                    {assignedEmployeesList.length > 0 ? (
                      <div className="space-y-1">
                        {assignedEmployeesList.map(emp => (
                          <div key={emp.id} className="font-mono text-slate-800 font-medium flex items-center gap-1.5">
                            <span className="text-red-600">{emp.employeeCode}</span>
                            <span>-</span>
                            <span>{emp.employeeName} ({emp.designation.split(' ')[0]})</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <em className="text-slate-400">No employees assigned.</em>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-bold text-slate-900">Project Stage Milestones</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Check off key completion steps to automatically recalculate project progress.
              </p>
            </div>

            <div className="space-y-3">
              {project.milestones.map((m, idx) => (
                <div
                  key={m.id}
                  className={`p-4 rounded-lg border transition-colors flex items-start gap-3.5 ${
                    m.completed ? 'bg-emerald-50/40 border-emerald-200' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <button
                    type="button"
                    disabled={currentUser.role === 'Client'}
                    onClick={() => toggleMilestone(project.id, m.id)}
                    className={`mt-0.5 w-5 h-5 rounded flex items-center justify-center transition-all cursor-pointer ${
                      m.completed 
                        ? 'bg-emerald-600 text-white' 
                        : 'border border-slate-300 bg-white hover:border-slate-400'
                    }`}
                  >
                    {m.completed && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                  </button>

                  <div className="flex-1 text-xs">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                      <h4 className={`font-semibold ${m.completed ? 'text-emerald-950 line-through' : 'text-slate-900'}`}>
                        {idx + 1}. {m.title}
                      </h4>
                      <span className="font-mono text-slate-500 text-[11px]">
                        Target: {m.dueDate} {m.completedDate && `(Finished: ${m.completedDate})`}
                      </span>
                    </div>
                    <p className="text-slate-600 mt-1">{m.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 2: Tasks */}
        {activeTab === 'tasks' && (
          <div className="space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Assigned Tasks ({visibleTasks.length})</h3>
                <p className="text-xs text-slate-500">Installation work orders and testing tasks for this project</p>
              </div>

              {currentUser.role !== 'Client' && (
                <button
                  onClick={() => {
                    setTaskToEdit(null);
                    setIsTaskModalOpen(true);
                  }}
                  className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Task</span>
                </button>
              )}
            </div>

            <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg overflow-hidden">
              {visibleTasks.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500">
                  No tasks assigned to this project yet.
                </div>
              ) : (
                visibleTasks.map(task => (
                  <div key={task.id} className="p-4 hover:bg-slate-50 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-900">{task.title}</span>
                        <span className={`text-[10px] px-1.5 py-0.2 rounded font-semibold ${
                          task.priority === 'Critical' ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-700'
                        }`}>
                          {task.priority}
                        </span>
                      </div>
                      <p className="text-slate-500 mt-1">
                        Assigned to: <strong className="text-slate-700">{task.assignedToName}</strong> · Due: <span className="font-mono text-slate-800">{task.deadline}</span>
                      </p>
                      {task.remarks && (
                        <p className="text-slate-600 mt-1 italic">Remarks: {task.remarks}</p>
                      )}
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <select
                        disabled={currentUser.role === 'Client'}
                        value={task.status}
                        onChange={(e) => updateTaskStatus(task.id, e.target.value as any)}
                        className={`text-xs px-2.5 py-1 rounded font-semibold border cursor-pointer ${
                          task.status === 'Completed'
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                            : task.status === 'Overdue'
                            ? 'bg-red-50 text-red-800 border-red-200'
                            : 'bg-blue-50 text-blue-800 border-blue-200'
                        }`}
                      >
                        <option value="To Do">To Do</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Completed">Completed</option>
                        <option value="Overdue">Overdue</option>
                      </select>

                      {currentUser.role !== 'Client' && (
                        <button
                          onClick={() => {
                            setTaskToEdit(task);
                            setIsTaskModalOpen(true);
                          }}
                          className="px-2 py-1 text-slate-600 hover:text-slate-900 font-medium"
                        >
                          Edit
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Tab 3: Progress Reports */}
        {activeTab === 'updates' && (
          <div className="space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Site Progress Reports</h3>
                <p className="text-xs text-slate-500">Chronological field updates submitted by project engineers</p>
              </div>

              {currentUser.role !== 'Client' && (
                <button
                  onClick={() => setIsProgressReportModalOpen(true)}
                  className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Submit Progress Report</span>
                </button>
              )}
            </div>

            <div className="space-y-3">
              {projectUpdates.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500">
                  No progress reports logged yet.
                </div>
              ) : (
                projectUpdates.map(upd => (
                  <div key={upd.id} className="p-4 bg-slate-50 border border-slate-200 rounded-lg text-xs space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900">{upd.submittedByName}</span>
                        <span className="text-[10px] bg-slate-200 px-1.5 py-0.2 rounded text-slate-700 font-medium">
                          {upd.userRole}
                        </span>
                      </div>
                      <span className="font-mono text-slate-400 text-[11px]">{upd.timestamp}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-slate-500">Reported Progress:</span>
                      <span className="font-mono font-bold text-emerald-700">{upd.percentageReported}%</span>
                    </div>

                    <p className="text-slate-700 leading-relaxed">{upd.notes}</p>

                    {upd.attachmentName && (
                      <div className="pt-2 text-[11px] text-red-600 flex items-center gap-1 font-mono">
                        <FileText className="w-3.5 h-3.5" />
                        <span>Attached: {upd.attachmentName}</span>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Tab 4: Two-Way Conversation & Voice Messaging */}
        {activeTab === 'conversation' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Project Communication Channel</h3>
                <p className="text-xs text-slate-500">
                  Direct exchange between {project.clientCompanyName} and the Phoenix Fire Safety team
                </p>
              </div>

              <button
                type="button"
                onClick={() => setIsVoiceRecorderOpen(true)}
                className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
              >
                <Mic className="w-3.5 h-3.5" />
                <span>Record Voice Note</span>
              </button>
            </div>

            {/* Conversation Feed */}
            <div className="space-y-4 max-h-[500px] overflow-y-auto p-4 bg-slate-50 rounded-xl border border-slate-200">
              {projectMessages.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-400">
                  No messages yet. Send a note or record a voice message below.
                </div>
              ) : (
                projectMessages.map(msg => {
                  const isCurrentUser = msg.senderId === currentUser.id;
                  const isClient = msg.senderRole === 'Client';

                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${isCurrentUser ? 'items-end' : 'items-start'}`}
                    >
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mb-1">
                        <span className="font-semibold text-slate-700">{msg.senderName}</span>
                        <span>·</span>
                        <span className="font-mono">{msg.timestamp}</span>
                        <span>·</span>
                        <span className="text-[10px] text-slate-400">{msg.status}</span>
                      </div>

                      {msg.type === 'voice' ? (
                        <VoiceMessagePlayer
                          audioUrl={msg.audioUrl}
                          durationSeconds={msg.audioDurationSeconds || 6}
                          senderName={msg.senderName}
                        />
                      ) : (
                        <div
                          className={`p-3 rounded-lg text-xs max-w-lg leading-relaxed shadow-xs ${
                            isCurrentUser
                              ? 'bg-red-600 text-white rounded-br-none'
                              : 'bg-white text-slate-900 border border-slate-200 rounded-bl-none'
                          }`}
                        >
                          {msg.content}
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>

            {/* Text Message Input Bar */}
            <form onSubmit={handleSendTextMessage} className="flex items-center gap-2 pt-2">
              <input
                type="text"
                placeholder="Type a message or engineering update..."
                value={textMessage}
                onChange={(e) => setTextMessage(e.target.value)}
                className="flex-1 px-4 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:border-red-500"
              />

              <button
                type="button"
                onClick={() => setIsVoiceRecorderOpen(true)}
                className="p-2.5 text-slate-600 hover:text-red-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                title="Record audio message"
              >
                <Mic className="w-4 h-4" />
              </button>

              <button
                type="submit"
                disabled={!textMessage.trim()}
                className="px-3 sm:px-4 py-2.5 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors shrink-0"
                aria-label="Send message"
              >
                <Send className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Send</span>
              </button>
            </form>
          </div>
        )}

        {/* Tab 5: Documents & Attachments */}
        {activeTab === 'documents' && (
          <div className="space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Project Documents & Drawings</h3>
                <p className="text-xs text-slate-500">CAD drawings, TNFRS Form B compliance, and test logs</p>
              </div>

              {currentUser.role !== 'Client' && (
                <button
                  onClick={() => setIsUploadDocModalOpen(true)}
                  className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Upload Document</span>
                </button>
              )}
            </div>

            <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg overflow-hidden">
              {projectDocs.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500">
                  No documents shared for this project.
                </div>
              ) : (
                projectDocs.map(doc => (
                  <div key={doc.id} className="p-4 hover:bg-slate-50 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded bg-red-100 text-red-700 font-bold text-[10px] uppercase flex items-center justify-center shrink-0 mt-0.5">
                        {doc.fileType}
                      </div>
                      <div>
                        <p className="font-semibold text-slate-900">{doc.title}</p>
                        <p className="text-slate-500 text-[11px] mt-0.5">
                          {doc.filename} · {doc.fileSize} · Uploaded by <strong className="text-slate-700">{doc.uploadedBy}</strong> ({doc.uploadDate})
                        </p>
                        <span className="text-[10px] text-slate-400 font-mono">
                          Category: {doc.category} · Access: {doc.accessLevel}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => setPreviewDocument(doc)}
                        className="px-2.5 py-1 text-slate-700 hover:text-slate-900 hover:bg-slate-200/70 rounded font-semibold flex items-center gap-1 cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Preview</span>
                      </button>

                      {currentUser.role !== 'Client' && (
                        <button
                          onClick={() => deleteDocument(doc.id)}
                          className="px-2 py-1 text-red-600 hover:text-red-800 hover:bg-red-50 rounded cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Tab 5: Project Timeline matching templates/project-timeline.php */}
        {activeTab === 'timeline' && (
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Project Timeline</h3>
              <p className="text-xs text-slate-500">
                Track the progress and important milestones of this project.
              </p>
            </div>

            {/* PROJECT START */}
            <div className="bg-white border border-slate-200 rounded-lg p-4 border-l-4 border-l-blue-600 shadow-xs">
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                PROJECT START
              </div>
              <h4 className="text-sm font-bold text-slate-900">{project.name}</h4>
              <p className="text-xs text-slate-600 mt-1 font-mono">Date: {project.startDate}</p>
            </div>

            {/* TASKS SORTED BY DUE DATE */}
            {timelineTasks.length === 0 ? (
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-8 text-center text-xs text-slate-500">
                <h4 className="text-sm font-semibold text-slate-800">No Timeline Events Yet</h4>
                <p className="mt-1">Project tasks will appear here as timeline events.</p>
              </div>
            ) : (
              timelineTasks.map((task) => {
                const isCompleted = task.status === 'Completed';
                const borderColor = isCompleted ? 'border-l-emerald-600' : 'border-l-amber-500';

                return (
                  <div
                    key={task.id}
                    className={`bg-white border border-slate-200 rounded-lg p-4 shadow-xs border-l-4 ${borderColor}`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                      <div>
                        <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">
                          TASK
                        </div>
                        <h4 className="text-sm font-semibold text-slate-900">{task.title}</h4>

                        <div className="mt-2 text-xs text-slate-600 flex flex-wrap items-center gap-4">
                          <span>
                            Due:{' '}
                            <strong className="font-mono text-slate-800">
                              {new Date(task.deadline).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
                            </strong>
                          </span>
                          <span>
                            Priority:{' '}
                            <strong className={task.priority === 'High' || task.priority === 'Critical' ? 'text-red-600' : 'text-slate-800'}>
                              {task.priority} Priority
                            </strong>
                          </span>
                          <span>
                            Assigned to: <strong className="text-slate-800">{task.assignedToName}</strong>
                          </span>
                        </div>
                      </div>

                      <span
                        className={`inline-block px-3 py-1 rounded-full text-xs font-semibold self-start ${
                          isCompleted ? 'bg-emerald-50 text-emerald-800' : 'bg-amber-50 text-amber-800'
                        }`}
                      >
                        {isCompleted ? '✓ Completed' : '⏱ Pending'}
                      </span>
                    </div>
                  </div>
                );
              })
            )}

            {/* PROJECT END */}
            <div className="bg-white border border-slate-200 rounded-lg p-4 border-l-4 border-l-slate-600 shadow-xs">
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                PROJECT END
              </div>
              <h4 className="text-sm font-bold text-slate-900">Project Completion</h4>
              <p className="text-xs text-slate-600 mt-1 font-mono">Date: {project.expectedCompletionDate}</p>
            </div>
          </div>
        )}

        {/* Tab 6: Audit Trail & Activity Log */}
        {activeTab === 'audit' && (
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Project Audit Trail & Change History</h3>
              <p className="text-xs text-slate-500">
                Immutable chronological log of all task updates, progress changes, document uploads, and milestone checks.
              </p>
            </div>

            <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg overflow-hidden text-xs">
              {projectActivities.length === 0 ? (
                <div className="p-8 text-center text-slate-500">No activity logged yet.</div>
              ) : (
                projectActivities.map(act => (
                  <div key={act.id} className="p-3.5 flex items-start justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-900">{act.action}</span>
                        <span className="text-[10px] text-slate-400 font-mono">by {act.performedBy} ({act.role})</span>
                      </div>
                      <p className="text-slate-600 mt-1">{act.details}</p>
                    </div>
                    <span className="text-[11px] font-mono text-slate-400 shrink-0">{act.timestamp}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>

      {/* Voice Recorder Modal */}
      <VoiceRecorderModal
        isOpen={isVoiceRecorderOpen}
        onClose={() => setIsVoiceRecorderOpen(false)}
        onSendVoiceMessage={handleSendVoiceMessage}
        projectName={project.name}
      />

      {/* Document Preview Modal */}
      <DocumentPreviewModal
        document={previewDocument}
        onClose={() => setPreviewDocument(null)}
      />

      {/* Task Creation / Edit Modal */}
      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => {
          setIsTaskModalOpen(false);
          setTaskToEdit(null);
        }}
        taskToEdit={taskToEdit}
        defaultProjectId={project.id}
      />

      {/* Submit Progress Report Modal */}
      {isProgressReportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-md p-6">
            <h3 className="text-base font-bold text-slate-900">Submit Site Progress Report</h3>
            <p className="text-xs text-slate-500 mt-0.5">Post field completion notes and supporting documentation</p>

            <form onSubmit={handleSubmitProgressForm} className="mt-4 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Estimated Completion Percentage ({reportPercentage}%)
                </label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={reportPercentage}
                  onChange={(e) => setReportPercentage(Number(e.target.value))}
                  className="w-full accent-red-600 cursor-pointer"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Site Notes & Milestones *</label>
                <textarea
                  required
                  rows={3}
                  placeholder="Detail work performed today, measurements, resistance logs..."
                  value={reportNotes}
                  onChange={(e) => setReportNotes(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Supporting Document / File Name</label>
                <input
                  type="text"
                  placeholder="e.g. Apollo_ICU_Loop3_Readings.pdf"
                  value={reportAttachment}
                  onChange={(e) => setReportAttachment(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                />
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between">
                <div>
                  <p className="font-semibold text-slate-900">Client Portal Visibility</p>
                  <p className="text-[11px] text-slate-500">Publish report to client view</p>
                </div>
                <input
                  type="checkbox"
                  checked={reportClientVisible}
                  onChange={(e) => setReportClientVisible(e.target.checked)}
                  className="w-4 h-4 text-red-600 rounded cursor-pointer"
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsProgressReportModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:text-slate-900 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold cursor-pointer shadow-xs"
                >
                  Post Report
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Upload Document Modal */}
      {isUploadDocModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-md p-6">
            <h3 className="text-base font-bold text-slate-900">Upload Project Document</h3>
            <p className="text-xs text-slate-500 mt-0.5">Attach drawings, quotations, or compliance certificates</p>

            <form onSubmit={handleUploadDocumentSubmit} className="mt-4 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Document Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. As-Built Fire Alarm Schematic Rev 3"
                  value={docTitle}
                  onChange={(e) => setDocTitle(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Filename *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Apollo_DWG_Rev3.dwg or Report.pdf"
                  value={docFilename}
                  onChange={(e) => setDocFilename(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Category</label>
                  <select
                    value={docCategory}
                    onChange={(e) => setDocCategory(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                  >
                    <option value="CAD Drawing">CAD Drawing</option>
                    <option value="Form B NOC">Form B NOC</option>
                    <option value="Inspection Report">Inspection Report</option>
                    <option value="Quotation">Quotation</option>
                    <option value="Work Order">Work Order</option>
                    <option value="Completion Certificate">Completion Certificate</option>
                    <option value="Service Report">Service Report</option>
                    <option value="Site Photo">Site Photo</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Access Level</label>
                  <select
                    value={docAccessLevel}
                    onChange={(e) => setDocAccessLevel(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                  >
                    <option value="Client Shared">Client Shared</option>
                    <option value="Internal Only">Internal Only</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Summary / Technical Notes</label>
                <textarea
                  rows={2}
                  placeholder="Short summary for the document preview..."
                  value={docPreviewText}
                  onChange={(e) => setDocPreviewText(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsUploadDocModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:text-slate-900 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold cursor-pointer shadow-xs"
                >
                  Upload
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
