import React, { useState } from 'react';
import { 
  FileSpreadsheet, 
  Upload, 
  Key, 
  Download, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle,
  FileText,
  ArrowLeft
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ZOHO_SAMPLE_RECORDS } from '../data/mockData';

export const ClientImportView: React.FC = () => {
  const { clients, importZohoClients, regenerateAllClientCredentials, setActiveView } = useApp();

  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [importStatus, setImportStatus] = useState<'idle' | 'ready' | 'importing' | 'completed'>('idle');
  const [processed, setProcessed] = useState(0);
  const [created, setCreated] = useState(0);
  const [updated, setUpdated] = useState(0);
  const [skipped, setSkipped] = useState(0);

  // Credential regeneration state
  const [showConfirmRegenModal, setShowConfirmRegenModal] = useState(false);
  const [isRegenerating, setIsRegenerating] = useState(false);
  const [regenStatus, setRegenStatus] = useState<string | null>(null);
  const [generatedCredentials, setGeneratedCredentials] = useState<any[] | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setCsvFile(file);
      setImportStatus('ready');
      setProcessed(0);
      setCreated(0);
      setUpdated(0);
      setSkipped(0);
    }
  };

  const startBatchImport = () => {
    setImportStatus('importing');
    let currentProcessed = 0;
    const total = ZOHO_SAMPLE_RECORDS.length;

    const interval = setInterval(() => {
      currentProcessed += 1;
      setProcessed(currentProcessed);

      if (currentProcessed >= total) {
        clearInterval(interval);
        const res = importZohoClients(ZOHO_SAMPLE_RECORDS, true);
        setCreated(res.added);
        setUpdated(res.updated);
        setSkipped(0);
        setImportStatus('completed');
      }
    }, 250);
  };

  const handleDownloadCredentialsCsv = () => {
    const list = clients.map(c => ({
      clientId: c.id,
      company: c.companyName,
      contactPerson: c.contactPerson,
      email: c.email,
      username: c.username || c.email.split('@')[0],
      temporaryPassword: c.password || 'TemporaryPass@123'
    }));

    exportCsvFile(list, 'phoenix-client-credentials.csv');
  };

  const executeRegeneration = () => {
    setShowConfirmRegenModal(false);
    setIsRegenerating(true);
    setRegenStatus(`Preparing credential generation for ${clients.length} clients...`);

    setTimeout(() => {
      const creds = regenerateAllClientCredentials();
      setGeneratedCredentials(creds);
      setIsRegenerating(false);
      setRegenStatus(`Completed. ${creds.length} client passwords replaced with new secure temporary tokens.`);
    }, 800);
  };

  const exportCsvFile = (records: any[], filename: string) => {
    const headers = 'Client ID,Company,Contact Person,Email,Username,Temporary Password\n';
    const rows = records.map(r => 
      `"${r.clientId}","${r.company}","${r.contactPerson}","${r.email}","${r.username}","${r.temporaryPassword}"`
    ).join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Top navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => setActiveView('clients')}
          className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1.5 cursor-pointer font-medium py-1 px-2 -ml-2 rounded-lg hover:bg-slate-200/60"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Client Directory</span>
        </button>
      </div>

      {/* Header matching includes/client-import.php */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">Phoenix Client Import & Password Generator</h1>
        <p className="text-xs text-slate-500 mt-1 leading-relaxed">
          Import Zoho Books customers from CSV. The importer matches existing clients by Zoho Contact ID first, then email, and creates usernames plus random temporary passwords for new clients.
        </p>
      </div>

      {/* Confirmation Modal for Credential Reset */}
      {showConfirmRegenModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-5 space-y-4 border border-slate-200">
            <div className="flex items-center gap-2.5 text-amber-600">
              <AlertCircle className="w-5 h-5 shrink-0" />
              <h3 className="font-bold text-slate-900 text-sm">Regenerate Client Credentials?</h3>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              This will reset the login password for all <strong>{clients.length}</strong> clients in Phoenix Project Manager and generate a downloadable credentials CSV with new secure temporary tokens.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowConfirmRegenModal(false)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={executeRegeneration}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg cursor-pointer"
              >
                Confirm & Regenerate
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CSV Upload & Batch Processor Section */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-5">
        <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <Upload className="w-4 h-4 text-red-600" />
          <span>Zoho Books CSV File Import</span>
        </h2>

        <div className="space-y-3">
          <input
            type="file"
            accept=".csv,text/csv"
            onChange={handleFileChange}
            className="text-xs file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-slate-900 file:text-white hover:file:bg-slate-800 cursor-pointer"
          />
          <p className="text-slate-500 text-[11px]">
            Export your Zoho Books Contacts/Customers as CSV. Excel files (.xlsx) are not accepted directly; save the export as CSV first.
          </p>
        </div>

        {/* Batch Status Area matching WordPress progress bar */}
        {importStatus !== 'idle' && (
          <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-3">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-800">
              <span>Status: <strong className="text-red-600 font-bold">{importStatus.toUpperCase()}</strong></span>
              <span className="font-mono text-slate-500">
                Processed: <strong className="text-slate-900">{processed}</strong> · Created: <strong className="text-emerald-700">{created}</strong> · Updated: <strong className="text-blue-700">{updated}</strong> · Skipped: <strong className="text-slate-600">{skipped}</strong>
              </span>
            </div>

            {/* Progress Bar matching ppm-import-bar */}
            <div className="w-full bg-slate-200 h-5 rounded overflow-hidden">
              <div 
                className="h-full bg-blue-600 transition-all duration-300"
                style={{ width: `${importStatus === 'completed' ? 100 : Math.round((processed / ZOHO_SAMPLE_RECORDS.length) * 100)}%` }}
              />
            </div>

            <div className="flex items-center gap-3 pt-1">
              <button
                type="button"
                disabled={importStatus === 'importing' || importStatus === 'completed'}
                onClick={startBatchImport}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-xs"
              >
                {importStatus === 'importing' ? 'Importing...' : 'Start Import'}
              </button>

              {importStatus === 'completed' && (
                <button
                  type="button"
                  onClick={handleDownloadCredentialsCsv}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-xs flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Import Credentials CSV</span>
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Generate New Credentials Section matching includes/client-import.php */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4">
        <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <Key className="w-4 h-4 text-slate-800" />
          <span>Generate New Credentials for All Existing Clients</span>
        </h2>
        <p className="text-xs text-slate-600 leading-relaxed">
          This keeps every existing client record and username, but replaces each client password with a new random temporary password. A CSV will be generated for you to download.
        </p>

        <div>
          <button
            type="button"
            disabled={isRegenerating}
            onClick={() => setShowConfirmRegenModal(true)}
            className="px-4 py-2.5 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-xs transition-colors flex items-center gap-2"
          >
            {isRegenerating && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
            <span>Generate New Credentials CSV</span>
          </button>
        </div>

        {regenStatus && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-900 space-y-2">
            <p className="font-semibold">{regenStatus}</p>
            {generatedCredentials && (
              <div>
                <button
                  type="button"
                  onClick={() => exportCsvFile(generatedCredentials, 'phoenix-client-new-credentials.csv')}
                  className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded font-medium flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download New Client Credentials CSV</span>
                </button>
                <p className="text-[11px] text-emerald-700 mt-1 italic">
                  Store this file securely and delete it after distributing the credentials to client representatives.
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
