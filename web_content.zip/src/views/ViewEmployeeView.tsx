import React from 'react';
import { 
  ArrowLeft, 
  Users, 
  Briefcase, 
  CheckSquare, 
  Phone, 
  Mail, 
  ShieldCheck, 
  MapPin, 
  Calendar,
  AlertCircle
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ViewEmployeeView: React.FC = () => {
  const { 
    selectedEmployeeId, 
    setSelectedEmployeeId, 
    setActiveView, 
    employees, 
    projects, 
    tasks, 
    setSelectedProjectId 
  } = useApp();

  const employee = employees.find(e => e.id === selectedEmployeeId);

  if (!employee) {
    return (
      <div className="bg-white rounded-xl border border-slate-200 p-12 text-center text-xs text-slate-500">
        <p>No employee selected.</p>
        <button
          onClick={() => setActiveView('employees')}
          className="mt-3 px-4 py-2 bg-red-600 text-white rounded-lg font-semibold cursor-pointer"
        >
          Return to Employees
        </button>
      </div>
    );
  }

  // Assigned projects from ppm_project_employees
  const assignedProjects = projects.filter(p => p.assignedEmployeeIds.includes(employee.id));
  // Assigned tasks from ppm_tasks
  const assignedTasks = tasks.filter(t => t.assignedToEmployeeId === employee.id);

  const handleOpenProject = (projectId: string) => {
    setSelectedProjectId(projectId);
    setActiveView('project-detail');
  };

  return (
    <div className="space-y-6">
      {/* Back button & Title */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => {
            setSelectedEmployeeId(null);
            setActiveView('employees');
          }}
          className="text-xs font-semibold text-slate-600 hover:text-slate-900 flex items-center gap-1.5 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Employees</span>
        </button>

        <span className="font-mono text-xs font-bold text-red-600 bg-red-50 px-2.5 py-1 rounded border border-red-200">
          {employee.employeeCode}
        </span>
      </div>

      {/* Main Employee Details Header matching admin/view-employee.php */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
          <div className="flex items-center gap-4">
            {employee.photo ? (
              <img
                src={employee.photo}
                alt={employee.employeeName}
                className="w-16 h-16 rounded-full object-cover border-2 border-red-500 shadow-xs"
              />
            ) : (
              <div className="w-16 h-16 rounded-full bg-slate-200 text-slate-700 font-bold text-xl flex items-center justify-center">
                {employee.employeeName.charAt(0)}
              </div>
            )}
            <div>
              <h1 className="text-xl font-bold text-slate-900">{employee.employeeName}</h1>
              <p className="text-xs text-slate-500 mt-0.5">{employee.designation} · {employee.department}</p>
            </div>
          </div>

          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
            employee.status === 'Active' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-slate-100 text-slate-600'
          }`}>
            {employee.status}
          </span>
        </div>

        {/* Info Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-5 text-xs">
          <div>
            <span className="text-slate-400 font-medium block">Employee Code</span>
            <p className="font-mono font-bold text-slate-800">{employee.employeeCode}</p>
          </div>
          <div>
            <span className="text-slate-400 font-medium block">Department</span>
            <p className="font-semibold text-slate-800">{employee.department}</p>
          </div>
          <div>
            <span className="text-slate-400 font-medium block">Designation</span>
            <p className="font-semibold text-slate-800">{employee.designation}</p>
          </div>
          <div>
            <span className="text-slate-400 font-medium block">Phone</span>
            <p className="font-mono text-slate-800">{employee.phone}</p>
          </div>
          <div>
            <span className="text-slate-400 font-medium block">Alternate Phone</span>
            <p className="font-mono text-slate-800">{employee.alternatePhone || 'N/A'}</p>
          </div>
          <div>
            <span className="text-slate-400 font-medium block">Email Address</span>
            <p className="font-mono text-slate-800">{employee.email}</p>
          </div>
          <div>
            <span className="text-slate-400 font-medium block">Blood Group</span>
            <p className="font-semibold text-red-600">{employee.bloodGroup || 'N/A'}</p>
          </div>
          <div>
            <span className="text-slate-400 font-medium block">Joining Date</span>
            <p className="font-mono text-slate-800">{employee.joiningDate}</p>
          </div>
          <div>
            <span className="text-slate-400 font-medium block">Statutory ID (Aadhaar / PAN)</span>
            <p className="font-mono text-slate-700">{employee.aadhaarNumber || 'N/A'} · {employee.panNumber || 'N/A'}</p>
          </div>
          <div className="sm:col-span-2">
            <span className="text-slate-400 font-medium block">Residential Address</span>
            <p className="text-slate-700">{employee.address || 'N/A'}</p>
          </div>
          <div>
            <span className="text-slate-400 font-medium block">Emergency Contact</span>
            <p className="text-slate-800">{employee.emergencyContactName} ({employee.emergencyContactPhone || 'N/A'})</p>
          </div>
        </div>
      </div>

      {/* Assigned Projects Table matching admin/view-employee.php */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Briefcase className="w-4 h-4 text-slate-700" />
            <span>Assigned Projects ({assignedProjects.length})</span>
          </h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4 w-20">ID</th>
                <th className="py-3 px-4">Project Name</th>
                <th className="py-3 px-4">Client</th>
                <th className="py-3 px-4">Location</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {assignedProjects.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    No projects assigned to this employee.
                  </td>
                </tr>
              ) : (
                assignedProjects.map(proj => (
                  <tr key={proj.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-mono text-slate-500">{proj.reference}</td>
                    <td className="py-3 px-4 font-semibold text-slate-900">{proj.name}</td>
                    <td className="py-3 px-4 text-slate-700">{proj.clientCompanyName}</td>
                    <td className="py-3 px-4 text-slate-600">{proj.siteLocation}</td>
                    <td className="py-3 px-4">
                      <span className={`font-semibold ${
                        proj.status === 'Completed' ? 'text-emerald-700' : proj.status === 'Overdue' ? 'text-red-700' : 'text-blue-700'
                      }`}>
                        {proj.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => handleOpenProject(proj.id)}
                        className="px-2.5 py-1 text-red-600 hover:text-red-800 font-semibold hover:bg-red-50 rounded cursor-pointer"
                      >
                        Open Project
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Assigned Tasks Table matching admin/view-employee.php */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <CheckSquare className="w-4 h-4 text-red-600" />
            <span>Assigned Tasks ({assignedTasks.length})</span>
          </h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4 w-20">ID</th>
                <th className="py-3 px-4">Task Name</th>
                <th className="py-3 px-4">Project</th>
                <th className="py-3 px-4">Priority</th>
                <th className="py-3 px-4">Due Date</th>
                <th className="py-3 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {assignedTasks.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    No tasks assigned.
                  </td>
                </tr>
              ) : (
                assignedTasks.map(task => {
                  const proj = projects.find(p => p.id === task.projectId);

                  return (
                    <tr key={task.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4 font-mono text-slate-500">{task.id}</td>
                      <td className="py-3 px-4 font-semibold text-slate-900">{task.title}</td>
                      <td className="py-3 px-4 text-slate-700">
                        <button
                          onClick={() => handleOpenProject(task.projectId)}
                          className="hover:underline text-red-600 font-medium"
                        >
                          {proj ? proj.name : task.projectReference}
                        </button>
                      </td>
                      <td className="py-3 px-4 font-medium text-slate-700">{task.priority}</td>
                      <td className="py-3 px-4 font-mono text-slate-600">{task.deadline}</td>
                      <td className="py-3 px-4">
                        <span className={`font-semibold ${
                          task.status === 'Completed' ? 'text-emerald-700' : task.status === 'Overdue' ? 'text-red-700' : 'text-blue-700'
                        }`}>
                          {task.status}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
