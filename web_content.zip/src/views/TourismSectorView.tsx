import React from 'react';
import { useApp } from '../context/AppContext';
import { translations } from '../data/translations';
import { 
  Palmtree, 
  Sun, 
  ShieldAlert, 
  Send, 
  ArrowLeft, 
  ArrowRight, 
  Calendar, 
  Sparkles, 
  MapPin, 
  CheckCircle2,
  Crown
} from 'lucide-react';

export const TourismSectorView: React.FC = () => {
  const { language, setCurrentView, openRequestModalForService, healingDestinations } = useApp();
  const t = translations[language];
  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  return (
    <div className="py-12 bg-black min-h-screen text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Breadcrumb */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => setCurrentView('home')}
            className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-zinc-400 hover:text-amber-300 transition-colors"
          >
            <ArrowIcon className="w-4 h-4 text-[#D4AF37]" />
            <span>{t.backToHome}</span>
          </button>
          <span className="text-xs bg-zinc-900 border border-[#D4AF37]/40 text-amber-300 font-bold px-3 py-1 rounded-full">
            {isAr ? 'السياحة العلاجية والاستشفاء البيئي الطبيعي' : 'Medical & Wellness Tourism'}
          </span>
        </div>

        {/* Hero Header in Black & Gold */}
        <div className="relative overflow-hidden bg-gradient-to-r from-zinc-950 via-black to-zinc-950 rounded-3xl p-8 sm:p-12 text-white shadow-2xl border border-[#D4AF37]/40">
          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center gap-2 bg-[#D4AF37]/15 text-amber-300 border border-[#D4AF37]/40 px-3 py-1 rounded-full text-xs font-semibold">
              <Sun className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>{isAr ? 'كنوز مصر البيئية الاستشفائية' : 'Egypt Natural Healing Sanctuaries'}</span>
            </div>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-black bg-gradient-to-r from-white via-zinc-100 to-amber-200 bg-clip-text text-transparent tracking-tight">
              {isAr ? 'السياحة العلاجية والاستشفاء البيئي المكمل' : 'Therapeutic Climate & Mineral Wellness Destinations'}
            </h1>
            <p className="text-zinc-300 text-sm sm:text-base leading-relaxed">
              {isAr
                ? 'استمتع بالفوائد العلاجية الطبيعية للرمال الساخنة في سيوة، والمناخ الجاف الخالي من الرطوبة بأسوان، والمياه والرمال الغنية بالمعادن في سفاجا، تحت إشراف وتوجيه أطباء مختصين.'
                : 'Experience natural therapeutic mineral hot springs, Siwa high-salinity salt flotation, and Aswan dry climatotherapy supervised by experienced medical consultants.'}
            </p>
            <div className="pt-2 flex flex-wrap gap-3">
              <button
                onClick={() => openRequestModalForService('medical_tourism')}
                className="bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black font-extrabold px-6 py-3.5 rounded-xl text-xs sm:text-sm transition-all shadow-xl shadow-amber-500/20 flex items-center gap-2"
              >
                <Send className="w-4 h-4 text-black" />
                <span>{isAr ? 'طلب تنسيق برنامج استشفائي' : 'Request Wellness Coordination'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Mandatory Regulatory Warning Banner */}
        <div className="bg-zinc-950/90 border border-[#D4AF37]/40 rounded-2xl p-5 text-amber-200 flex items-start gap-4 shadow-xl">
          <ShieldAlert className="w-6 h-6 text-[#D4AF37] shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="font-bold text-sm text-amber-300">
              {isAr ? 'ضابط تنظيمي وطبي صارم (معايير الشفافية الطبية):' : 'Strict Medical Disclosure & Transparency:'}
            </h4>
            <p className="text-xs text-zinc-300 leading-relaxed">
              {isAr
                ? 'تؤكد منصة المواساة بشكل حاسم أن جميع الأنشطة الاستشفائية البيئية (حمامات الرمال، بحيرات الملح، العيون الكبريتية، الاستشفاء المناخي) هي برامج مكملة ومعززة لجودة الحياة وليست بأي حال بديلاً عن الرعاية الطبية، أو الجراحة، أو الأدوية الموصوفة من الأطباء المرخصين. يتم فحص كل مريض مسبقاً للتأكد من عدم وجود موانع صحية.'
                : 'Al-Mowasat explicitly emphasizes that environmental therapies (sand baths, salt lakes, sulfur springs) are complementary holistic programs and NEVER a substitute for clinical diagnostics, surgery, or prescription medications.'}
            </p>
          </div>
        </div>

        {/* Destinations Cards in Black & Gold */}
        <div className="space-y-8">
          <div>
            <h2 className="text-2xl font-black bg-gradient-to-r from-white to-amber-200 bg-clip-text text-transparent">
              {isAr ? 'الوجهات الاستشفائية المعتمدة وبرامجها' : 'Featured Curative Regions in Egypt'}
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              {isAr ? 'وجهات مختارة بعناية توفر بيئة علاجية طبيعية مع خدمات إقامة ونقل راقية' : 'Carefully selected destinations combining unique geography with luxury hospitality'}
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {healingDestinations.map(dest => (
              <div 
                key={dest.id}
                className="bg-zinc-950 rounded-3xl border border-[#D4AF37]/30 hover:border-[#D4AF37] overflow-hidden shadow-xl hover:shadow-[0_0_20px_rgba(212,175,55,0.2)] transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="relative h-56 overflow-hidden">
                    <img 
                      src={dest.imageUrl} 
                      alt={isAr ? dest.nameAr : dest.nameEn}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent"></div>
                    <div className="absolute bottom-3 right-3 rtl:right-3 rtl:left-auto ltr:left-3 ltr:right-auto text-white">
                      <div className="flex items-center gap-1 text-xs text-amber-300 font-semibold mb-0.5">
                        <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
                        <span>{dest.governorate}</span>
                      </div>
                      <h3 className="text-base sm:text-lg font-bold text-white">
                        {isAr ? dest.nameAr : dest.nameEn}
                      </h3>
                    </div>
                  </div>

                  <div className="p-6 space-y-4">
                    <div>
                      <div className="text-xs font-bold text-amber-200 mb-1">
                        {isAr ? 'الخصائص والمناخ العلاجي:' : 'Therapeutic Climate Profile:'}
                      </div>
                      <p className="text-xs text-zinc-400 leading-relaxed">
                        {isAr ? dest.climateBenefitAr : dest.climateBenefitEn}
                      </p>
                    </div>

                    <div>
                      <div className="text-xs font-bold text-amber-200 mb-2">
                        {isAr ? 'أبرز البرامج المتاحة:' : 'Curated Healing Modalities:'}
                      </div>
                      <ul className="space-y-1.5">
                        {(isAr ? dest.featuredTreatmentsAr : dest.featuredTreatmentsEn).map((tItem, tIdx) => (
                          <li key={tIdx} className="flex items-start gap-2 text-xs text-zinc-300">
                            <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37] shrink-0 mt-0.5" />
                            <span>{tItem}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="flex items-center gap-1.5 text-xs text-zinc-400 pt-3 border-t border-zinc-900">
                      <Calendar className="w-3.5 h-3.5 text-[#D4AF37]" />
                      <span>{isAr ? `الموسم المثالي: ${dest.seasonAr}` : `Best Season: ${dest.seasonEn}`}</span>
                    </div>

                    <div className="p-2.5 bg-black rounded-xl text-[11px] text-zinc-400 border border-zinc-900 italic">
                      {isAr ? dest.disclaimerAr : dest.disclaimerEn}
                    </div>
                  </div>
                </div>

                <div className="p-6 pt-0">
                  <button
                    onClick={() => openRequestModalForService('medical_tourism')}
                    className="w-full py-3 bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 shadow-md shadow-amber-500/20"
                  >
                    <Send className="w-3.5 h-3.5 text-black" />
                    <span>{isAr ? 'تنسيق برنامج في هذه الوجهة' : 'Book Package in this Region'}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
