import React, { useState } from 'react';
import { Wallet, ArrowDownRight, ArrowUpLeft, Plus, Calendar, DollarSign, X } from 'lucide-react';
import { TreasuryMove } from '../db/indexedDB';
import { formatMoney } from '../utils/calc';
import { sound } from '../utils/sound';

interface TreasuryViewProps {
  treasuryMoves: TreasuryMove[];
  onAddExpense: (amount: number, notes: string) => Promise<void>;
}

export const TreasuryView: React.FC<TreasuryViewProps> = ({
  treasuryMoves,
  onAddExpense,
}) => {
  const [showExpenseModal, setShowExpenseModal] = useState(false);
  const [expenseAmount, setExpenseAmount] = useState('');
  const [expenseNotes, setExpenseNotes] = useState('');
  const [loading, setLoading] = useState(false);

  const totalIncome = treasuryMoves.filter((m) => m.type === 'إيراد').reduce((a, m) => a + m.amount, 0);
  const totalExpense = treasuryMoves.filter((m) => m.type === 'مصروف').reduce((a, m) => a + m.amount, 0);
  const netBalance = totalIncome - totalExpense;

  const handleExpenseSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const num = Number(expenseAmount);
    if (!Number.isFinite(num) || num <= 0) {
      sound.playError();
      return;
    }

    try {
      setLoading(true);
      await onAddExpense(num, expenseNotes.trim() || 'مصروف نثريات');
      sound.playSuccess();
      setShowExpenseModal(false);
      setExpenseAmount('');
      setExpenseNotes('');
    } catch {
      sound.playError();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-3.5 pb-24 pt-2">
      {/* Treasury Net Card */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-850 to-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl text-center space-y-2">
        <span className="text-xs font-bold text-slate-400">صافي رصيد الخزنة الفعلي</span>
        <div className="text-3xl font-black font-mono text-white">
          {formatMoney(netBalance)} <small className="text-xs text-amber-400">ج.م</small>
        </div>
        <p className="text-[11px] text-slate-400">
          المبلغ النقدي الفعلي المتواجد في خزنة السيارة بناءً على تحصيلات اليوم ومصروفاته
        </p>
      </div>

      {/* KPI Tiles */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className="bg-slate-900 border border-emerald-500/30 rounded-2xl p-3.5 flex items-center justify-between">
          <div>
            <span className="text-[11px] text-slate-400 block font-bold">إجمالي المقبوضات (إيراد)</span>
            <span className="text-lg font-black font-mono text-emerald-400 block mt-1">
              +{formatMoney(totalIncome)} ج.م
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
            <ArrowDownRight className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-900 border border-rose-500/30 rounded-2xl p-3.5 flex items-center justify-between">
          <div>
            <span className="text-[11px] text-slate-400 block font-bold">إجمالي المصروفات (صرف)</span>
            <span className="text-lg font-black font-mono text-rose-400 block mt-1">
              -{formatMoney(totalExpense)} ج.م
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center">
            <ArrowUpLeft className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Toolbar */}
      <div className="flex items-center justify-between px-1">
        <h2 className="text-xs font-bold text-slate-300">سجل حركات الخزنة اليومية</h2>
        <button
          onClick={() => setShowExpenseModal(true)}
          className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs flex items-center gap-1 active:scale-95 transition"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>+ تسجيل مصروف</span>
        </button>
      </div>

      {/* Movements list */}
      <div className="space-y-2">
        {treasuryMoves.length > 0 ? (
          treasuryMoves
            .slice()
            .reverse()
            .map((m) => {
              const isIncome = m.type === 'إيراد';
              return (
                <div
                  key={m.id}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-3 flex items-center justify-between text-xs shadow-md"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold ${
                        isIncome ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                      }`}
                    >
                      {isIncome ? <ArrowDownRight className="w-4 h-4" /> : <ArrowUpLeft className="w-4 h-4" />}
                    </div>
                    <div>
                      <span className="font-bold text-white block">{m.notes || (isIncome ? 'إيراد نقدي' : 'مصروف')}</span>
                      <span className="text-[10px] text-slate-400 font-mono block mt-0.5">
                        {new Date(m.date).toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' })}
                      </span>
                    </div>
                  </div>

                  <span
                    className={`font-black font-mono text-sm ${
                      isIncome ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {isIncome ? '+' : '-'}{formatMoney(m.amount)} ج.م
                  </span>
                </div>
              );
            })
        ) : (
          <div className="p-8 text-center text-xs text-slate-500 bg-slate-900 border border-slate-800 rounded-3xl">
            لا توجد حركات مسجلة في الخزنة حتى الآن.
          </div>
        )}
      </div>

      {/* Add Expense Modal */}
      {showExpenseModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-0 sm:p-4">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl p-4 text-right space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-bold text-white text-sm">تسجيل مصروف جديد من الخزنة</h3>
              <button
                onClick={() => setShowExpenseModal(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleExpenseSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">المبلغ المصروف (ج.م) *</label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={expenseAmount}
                  onChange={(e) => setExpenseAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full font-mono bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-rose-500 font-bold"
                  required
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">بيان المصروف *</label>
                <input
                  type="text"
                  value={expenseNotes}
                  onChange={(e) => setExpenseNotes(e.target.value)}
                  placeholder="مثال: بنزين سيارة، كارتة طريق، ضيافة..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                  required
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 py-3 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs active:scale-95 transition"
                >
                  {loading ? 'جاري الحفظ…' : 'اعتماد وصرف من الخزنة'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowExpenseModal(false)}
                  className="px-4 py-3 bg-slate-800 text-slate-300 rounded-xl text-xs"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
