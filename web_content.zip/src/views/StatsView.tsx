import React from 'react';
import {
  BarChart3,
  TrendingUp,
  Award,
  AlertTriangle,
  Flame,
  CheckCircle,
  Dumbbell,
  Sparkles
} from 'lucide-react';
import { AppState, Activity } from '../types';
import { calculateDailyProgress, formatDate, parseDate } from '../utils/tracker';

interface StatsViewProps {
  state: AppState;
  dayNumber: number;
  streak: number;
}

export const StatsView: React.FC<StatsViewProps> = ({
  state,
  dayNumber,
  streak,
}) => {
  const today = new Date();
  const todayStr = formatDate(today);

  // Calculate 7-day average completion
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(today);
    d.setDate(today.getDate() - (6 - i));
    const dStr = formatDate(d);
    const rec = state.history[dStr];
    const prog = calculateDailyProgress(state.activities, rec, dStr);
    const dayName = d.toLocaleDateString('en-US', { weekday: 'narrow' });
    return { dateStr: dStr, dayName, percentage: prog.percentage };
  });

  const weeklyAverage = Math.round(
    last7Days.reduce((acc, curr) => acc + curr.percentage, 0) / 7
  );

  // Calculate 30-day average
  let total30Score = 0;
  let count30 = 0;
  for (let i = 0; i < 30; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    const dStr = formatDate(d);
    const rec = state.history[dStr];
    if (rec) {
      const prog = calculateDailyProgress(state.activities, rec, dStr);
      total30Score += prog.percentage;
      count30++;
    }
  }
  const monthlyAverage = count30 > 0 ? Math.round(total30Score / count30) : weeklyAverage;

  // Habit consistency calculation (find most consistent and frequently missed)
  const habitStats = state.activities.map((act) => {
    let scheduledCount = 0;
    let completedCount = 0;

    for (let i = 0; i < 14; i++) {
      const d = new Date(today);
      d.setDate(today.getDate() - i);
      const dStr = formatDate(d);
      const rec = state.history[dStr];
      if (rec && rec.tasks) {
        scheduledCount++;
        if (rec.tasks[act.id]?.completed) {
          completedCount++;
        }
      }
    }

    const rate = scheduledCount > 0 ? Math.round((completedCount / scheduledCount) * 100) : 0;
    return { ...act, rate, completedCount, scheduledCount };
  });

  // Sort for top 4 most consistent & top 3 most missed
  const sortedByRate = [...habitStats].sort((a, b) => b.rate - a.rate);
  const mostConsistent = sortedByRate.slice(0, 4);
  const mostMissed = [...sortedByRate].filter((a) => a.rate < 85).reverse().slice(0, 3);

  // Workout frequency
  const workoutActivities = state.activities.filter((a) => a.category === 'workout');
  const upperBodyWorkouts = workoutActivities.filter((a) => a.workoutCategory === 'Upper Body').length;
  const lowerBodyWorkouts = workoutActivities.filter((a) => a.workoutCategory === 'Lower Body').length;
  const coreWorkouts = workoutActivities.filter((a) => a.workoutCategory === 'Core').length;

  return (
    <div className="space-y-6 pb-24">
      {/* Overview Card */}
      <div className="rounded-3xl bg-white dark:bg-[#13151B] border border-slate-100 dark:border-slate-800 p-5 shadow-sm">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-purple-600 dark:text-purple-400 tracking-wide uppercase mb-1">
          <BarChart3 className="w-3.5 h-3.5" />
          <span>Performance Analytics</span>
        </div>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">
          Habit Consistency & Insights
        </h2>
        <p className="text-xs text-slate-500 mt-0.5">
          Data-driven metrics to optimize your 90-day physical and aesthetic routine.
        </p>

        {/* 4 Key Metric Tiles */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-5 pt-4 border-t border-slate-100 dark:border-slate-800">
          <div className="p-3.5 rounded-2xl bg-purple-50/60 dark:bg-purple-950/20 border border-purple-100 dark:border-purple-900/30">
            <span className="text-[10px] font-semibold text-purple-700 dark:text-purple-300 block">7-DAY AVERAGE</span>
            <div className="text-xl font-bold text-slate-900 dark:text-white tabular-nums mt-0.5">
              {weeklyAverage}%
            </div>
            <span className="text-[10px] text-slate-400">Completion rate</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-blue-50/60 dark:bg-blue-950/20 border border-blue-100 dark:border-blue-900/30">
            <span className="text-[10px] font-semibold text-blue-700 dark:text-blue-300 block">MONTHLY EXECUTION</span>
            <div className="text-xl font-bold text-slate-900 dark:text-white tabular-nums mt-0.5">
              {monthlyAverage}%
            </div>
            <span className="text-[10px] text-slate-400">Sustained rate</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-amber-50/60 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/30">
            <span className="text-[10px] font-semibold text-amber-700 dark:text-amber-300 block">CURRENT STREAK</span>
            <div className="text-xl font-bold text-slate-900 dark:text-white tabular-nums mt-0.5 flex items-center gap-1">
              <Flame className="w-4 h-4 fill-amber-500 text-amber-500" />
              <span>{streak} Days</span>
            </div>
            <span className="text-[10px] text-slate-400">Zero missed days</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30">
            <span className="text-[10px] font-semibold text-emerald-700 dark:text-emerald-300 block">WEIGHT LOSS</span>
            <div className="text-xl font-bold text-emerald-700 dark:text-emerald-300 tabular-nums mt-0.5">
              -{(state.profile.startWeightKg - state.profile.currentWeightKg).toFixed(1)} kg
            </div>
            <span className="text-[10px] text-slate-400">From baseline</span>
          </div>
        </div>
      </div>

      {/* Weekly Progress Bar Chart */}
      <div className="rounded-3xl bg-white dark:bg-[#13151B] border border-slate-100 dark:border-slate-800 p-5 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              7-Day Completion Trajectory
            </h3>
            <p className="text-xs text-slate-500">
              Daily percentage of routine completed across the past week
            </p>
          </div>
          <span className="text-xs font-bold text-purple-600 dark:text-purple-400 tabular-nums">
            {weeklyAverage}% Avg
          </span>
        </div>

        {/* Bar Visualizer */}
        <div className="grid grid-cols-7 gap-2 items-end h-36 pt-4 px-2">
          {last7Days.map((d) => (
            <div key={d.dateStr} className="flex flex-col items-center gap-2 h-full justify-end">
              <span className="text-[10px] font-mono tabular-nums text-slate-400">
                {d.percentage}%
              </span>
              <div className="w-full max-w-[32px] bg-slate-100 dark:bg-slate-800 rounded-xl h-full relative overflow-hidden flex items-end">
                <div
                  className="w-full bg-purple-600 rounded-xl transition-all duration-500"
                  style={{ height: `${Math.max(8, d.percentage)}%` }}
                />
              </div>
              <span className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                {d.dayName}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Most Consistent & Missed Habits */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Most Consistent */}
        <div className="rounded-3xl bg-white dark:bg-[#13151B] border border-slate-100 dark:border-slate-800 p-5 shadow-sm space-y-3">
          <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase">
            <Award className="w-4 h-4" />
            <span>Most Consistent Habits</span>
          </div>

          <div className="space-y-2">
            {mostConsistent.map((act) => (
              <div
                key={act.id}
                className="p-3 rounded-2xl bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30 flex items-center justify-between"
              >
                <div>
                  <h4 className="text-xs font-semibold text-slate-900 dark:text-white truncate max-w-[170px]">
                    {act.name}
                  </h4>
                  <span className="text-[10px] text-slate-400 capitalize">{act.category}</span>
                </div>
                <div className="text-right">
                  <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                    {act.rate}%
                  </span>
                  <span className="text-[9px] text-slate-400 block">success</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Frequently Missed */}
        <div className="rounded-3xl bg-white dark:bg-[#13151B] border border-slate-100 dark:border-slate-800 p-5 shadow-sm space-y-3">
          <div className="flex items-center gap-1.5 text-xs font-bold text-amber-600 dark:text-amber-400 uppercase">
            <AlertTriangle className="w-4 h-4" />
            <span>Attention Needed</span>
          </div>

          <div className="space-y-2">
            {mostMissed.length === 0 ? (
              <div className="p-4 text-center text-xs text-slate-400">
                Outstanding discipline! No habits below 85% completion.
              </div>
            ) : (
              mostMissed.map((act) => (
                <div
                  key={act.id}
                  className="p-3 rounded-2xl bg-amber-50/40 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/30 flex items-center justify-between"
                >
                  <div>
                    <h4 className="text-xs font-semibold text-slate-900 dark:text-white truncate max-w-[170px]">
                      {act.name}
                    </h4>
                    <span className="text-[10px] text-slate-400 capitalize">{act.category} · {act.scheduledTime}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-bold text-amber-600 dark:text-amber-400 tabular-nums">
                      {act.rate}%
                    </span>
                    <span className="text-[9px] text-slate-400 block">completed</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Workout Frequency Breakdown */}
      <div className="rounded-3xl bg-white dark:bg-[#13151B] border border-slate-100 dark:border-slate-800 p-5 shadow-sm space-y-3">
        <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 dark:text-white uppercase">
          <Dumbbell className="w-4 h-4 text-purple-600" />
          <span>Workout Split Frequency</span>
        </div>
        <p className="text-xs text-slate-500">
          Distribution of planned training stimulus for optimal muscular symmetry and posture balance.
        </p>

        <div className="grid grid-cols-3 gap-3 pt-2">
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800 text-center">
            <span className="text-[10px] text-slate-400 block font-semibold">UPPER BODY</span>
            <span className="text-lg font-bold text-slate-900 dark:text-white tabular-nums">{upperBodyWorkouts}</span>
            <span className="text-[10px] text-slate-400 block">exercises/day</span>
          </div>
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800 text-center">
            <span className="text-[10px] text-slate-400 block font-semibold">LOWER BODY</span>
            <span className="text-lg font-bold text-slate-900 dark:text-white tabular-nums">{lowerBodyWorkouts}</span>
            <span className="text-[10px] text-slate-400 block">exercises/day</span>
          </div>
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800 text-center">
            <span className="text-[10px] text-slate-400 block font-semibold">CORE & POSTURE</span>
            <span className="text-lg font-bold text-slate-900 dark:text-white tabular-nums">{coreWorkouts}</span>
            <span className="text-[10px] text-slate-400 block">exercises/day</span>
          </div>
        </div>
      </div>
    </div>
  );
};
