import React, { useState } from 'react';
import {
  CreditCard,
  Banknote,
  Search,
  Phone,
  MapPin,
  Calendar,
  Printer,
  AlertTriangle,
  ArrowUpDown,
  History,
  FileText,
  UserCheck,
  CheckCircle2,
  TrendingDown,
  ChevronLeft,
  Sparkles,
} from 'lucide-react';
import { Customer, Invoice, PaymentRecord } from '../db/indexedDB';
import { formatMoney, getTodayDateString } from '../utils/calc';
import { sound } from '../utils/sound';

interface DebtViewProps {
  customers: Customer[];
  invoices: Invoice[];
  payments: PaymentRecord[];
  selectedDay: string;
  onSelectDay: (day: string) => void;
  onPayment: (customer: Customer) => void;
  onQuickInvoice?: (customer: Customer) => void;
  onPrintExistingPayment?: (payment: PaymentRecord, customer: Customer) => void;
  onPrintDebtReport: (dayFilter: string) => void;
}

const DAYS_OF_WEEK = ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس'];

export const DebtView: React.FC<DebtViewProps> = ({
  customers,
  invoices,
  payments,
  selectedDay,
  onSelectDay,
  onPayment,
  onQuickInvoice,
  onPrintExistingPayment,
  onPrintDebtReport,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'debtors' | 'collections'>('debtors');
  const [currentDayFilter, setCurrentDayFilter] = useState<string>(selectedDay || 'السبت');
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState<'debt-desc' | 'debt-asc' | 'name'>('debt-desc');
  const [minDebtFilter, setMinDebtFilter] = useState<number>(0);

  const todayStr = getTodayDateString();

  // All indebted customers
  const allDebtors = customers.filter((c) => Number(c.balance || 0) > 0);
  const totalAllDebt = allDebtors.reduce((acc, c) => acc + Number(c.balance || 0), 0);

  // Today's route debtors
  const dayDebtors = allDebtors.filter(
    (c) => currentDayFilter === 'الكل' || c.dayOfWeek === currentDayFilter
  );
  const totalDayDebt = dayDebtors.reduce((acc, c) => acc + Number(c.balance || 0), 0);

  // Today's collections
  const todayPayments = payments.filter((p) => p.date?.slice(0, 10) === todayStr);
  const totalTodayCollected = todayPayments.reduce((acc, p) => acc + Number(p.amount || 0), 0);

  // Filter & sort debtors
  const q = search.trim().toLowerCase();
  const filteredDebtors = dayDebtors
    .filter((c) => {
      if (minDebtFilter > 0 && Number(c.balance || 0) < minDebtFilter) return false;
      if (!q) return true;
      return (
        c.name.toLowerCase().includes(q) ||
        c.id.toLowerCase().includes(q) ||
        (c.phone && c.phone.includes(q)) ||
        (c.address && c.address.toLowerCase().includes(q))
      );
    })
    .sort((a, b) => {
      if (sortBy === 'debt-desc') return Number(b.balance || 0) - Number(a.balance || 0);
      if (sortBy === 'debt-asc') return Number(a.balance || 0) - Number(b.balance || 0);
      return a.name.localeCompare(b.name, 'ar');
    });

  return (
    <div className="space-y-3.5 pb-28 pt-2">
      {/* Top Identity Banner */}
      <div className="bg-gradient-to-l from-rose-950/60 via-slate-900 to-slate-900 border border-rose-500/30 rounded-3xl p-4 sm:p-5 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-44 h-44 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-rose-400 bg-rose-500/15 border border-rose-500/30 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                <CreditCard className="w-3.5 h-3.5" />
                شاشة الآجل والتحصيل الميداني
              </span>
              <span className="text-xs text-slate-400 font-mono">{todayStr}</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white mt-1.5 flex items-center gap-2">
              <span>الآجل والمديونيات والتحصيل</span>
              <span className="text-sm font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded-lg font-mono">
                {allDebtors.length} عميل مدين
              </span>
            </h1>
            <p className="text-xs text-slate-300 mt-1">
              متابعة حسابات العملاء الآجلة، واختيار اليوم لخط السير، والتسديد الفوري من عند العميل
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => onPrintDebtReport(currentDayFilter)}
              className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-2xl font-bold text-xs flex items-center gap-1.5 active:scale-95 transition shadow-md"
            >
              <Printer className="w-4 h-4 text-amber-400" />
              <span>طباعة كشف المديونيات</span>
            </button>
          </div>
        </div>

        {/* 4 Main KPIs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-4 pt-3 border-t border-slate-800/80">
          <div className="bg-slate-900/90 border border-rose-500/30 rounded-2xl p-2.5 text-right">
            <span className="text-[10px] text-slate-400 block font-bold">إجمالي المديونية العامة</span>
            <div className="text-base sm:text-lg font-black font-mono text-rose-400 mt-0.5">
              {formatMoney(totalAllDebt)}
              <small className="text-[10px] text-slate-400 mr-1">ج.م</small>
            </div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">
              {allDebtors.length} عميل مدين بكل الخطوط
            </span>
          </div>

          <div className="bg-slate-900/90 border border-amber-500/30 rounded-2xl p-2.5 text-right">
            <span className="text-[10px] text-slate-400 block font-bold">مديونية اليوم المختار ({currentDayFilter})</span>
            <div className="text-base sm:text-lg font-black font-mono text-amber-400 mt-0.5">
              {formatMoney(totalDayDebt)}
              <small className="text-[10px] text-slate-400 mr-1">ج.م</small>
            </div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">
              {dayDebtors.length} عميل في هذا اليوم
            </span>
          </div>

          <div className="bg-slate-900/90 border border-emerald-500/30 rounded-2xl p-2.5 text-right">
            <span className="text-[10px] text-slate-400 block font-bold">المحصل نقداً اليوم</span>
            <div className="text-base sm:text-lg font-black font-mono text-emerald-400 mt-0.5">
              {formatMoney(totalTodayCollected)}
              <small className="text-[10px] text-emerald-400 mr-1">ج.م</small>
            </div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">
              {todayPayments.length} سند قبض مسجل
            </span>
          </div>

          <div className="bg-slate-900/90 border border-sky-500/30 rounded-2xl p-2.5 text-right">
            <span className="text-[10px] text-slate-400 block font-bold">نسبة التحصيل لليوم</span>
            <div className="text-base sm:text-lg font-black font-mono text-sky-400 mt-0.5">
              {totalDayDebt + totalTodayCollected > 0
                ? Math.round((totalTodayCollected / (totalDayDebt + totalTodayCollected)) * 100)
                : 0}
              %
            </div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">إنجاز المستهدف اليومي</span>
          </div>
        </div>
      </div>

      {/* Main Switcher: Debtors List vs Today's Collections Log */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-1.5 flex gap-1 shadow-md">
        <button
          onClick={() => setActiveSubTab('debtors')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition active:scale-95 ${
            activeSubTab === 'debtors'
              ? 'bg-amber-500 text-slate-950 font-black shadow-md shadow-amber-500/20'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <CreditCard className="w-4 h-4" />
          <span>كشف مديونيات العملاء والتحصيل الميداني</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-950/20 font-mono">
            {filteredDebtors.length}
          </span>
        </button>

        <button
          onClick={() => setActiveSubTab('collections')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition active:scale-95 ${
            activeSubTab === 'collections'
              ? 'bg-emerald-600 text-white font-black shadow-md shadow-emerald-900/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <History className="w-4 h-4" />
          <span>سجل تحصيلات وسندات اليوم</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-950/20 font-mono">
            {todayPayments.length}
          </span>
        </button>
      </div>

      {activeSubTab === 'debtors' && (
        <div className="space-y-3">
          {/* Day Selector (إمكانية اختيار اليوم) */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 shadow-md space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-300 flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-amber-400" />
                اختر يوم خط السير لفلترة المديونيات المستحقة:
              </span>
              <span className="text-[11px] font-mono text-amber-400 font-bold">
                اليوم المختار: {currentDayFilter}
              </span>
            </div>

            {/* Day Chips with Subtotals */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
              <button
                onClick={() => {
                  setCurrentDayFilter('الكل');
                  onSelectDay('الكل');
                }}
                className={`px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition active:scale-95 flex items-center gap-1.5 shrink-0 border ${
                  currentDayFilter === 'الكل'
                    ? 'bg-amber-500 text-slate-950 border-amber-400 font-black shadow-md shadow-amber-500/20'
                    : 'bg-slate-850 hover:bg-slate-800 text-slate-300 border-slate-750'
                }`}
              >
                <span>كافة الأيام</span>
                <span className="text-[10px] font-mono opacity-80">({allDebtors.length})</span>
              </button>

              {DAYS_OF_WEEK.map((day) => {
                const count = allDebtors.filter((c) => c.dayOfWeek === day).length;
                const isSelected = currentDayFilter === day;
                return (
                  <button
                    key={day}
                    onClick={() => {
                      setCurrentDayFilter(day);
                      onSelectDay(day);
                    }}
                    className={`px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition active:scale-95 flex items-center gap-1.5 shrink-0 border ${
                      isSelected
                        ? 'bg-amber-500 text-slate-950 border-amber-400 font-black shadow-md shadow-amber-500/20'
                        : 'bg-slate-850 hover:bg-slate-800 text-slate-300 border-slate-750'
                    }`}
                  >
                    <span>{day}</span>
                    <span
                      className={`text-[10px] font-mono px-1 py-0.2 rounded-full ${
                        isSelected
                          ? 'bg-slate-950/20 text-slate-950 font-black'
                          : count > 0
                          ? 'bg-rose-500/20 text-rose-300'
                          : 'bg-slate-750 text-slate-400'
                      }`}
                    >
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Search, Filter & Sort Bar */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-2.5 shadow-md flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="بحث باسم العميل، الهاتف، العنوان، أو الكود..."
                className="w-full h-10 pr-9 pl-3 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-400 focus:outline-none focus:border-amber-500 font-medium"
              />
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
            </div>

            <div className="flex items-center gap-2">
              <select
                value={sortBy}
                onChange={(e: any) => setSortBy(e.target.value)}
                className="h-10 bg-slate-800 border border-slate-700 rounded-xl px-2.5 text-xs text-white focus:outline-none font-bold"
              >
                <option value="debt-desc">ترتيب: الأعلى مديونية</option>
                <option value="debt-asc">ترتيب: الأقل مديونية</option>
                <option value="name">ترتيب: أبجدي بالاسم</option>
              </select>

              <select
                value={minDebtFilter}
                onChange={(e) => setMinDebtFilter(Number(e.target.value))}
                className="h-10 bg-slate-800 border border-slate-700 rounded-xl px-2.5 text-xs text-white focus:outline-none font-bold"
              >
                <option value="0">كل المبالغ</option>
                <option value="500">&gt; 500 ج.م</option>
                <option value="1000">&gt; 1,000 ج.م (حرجة)</option>
                <option value="3000">&gt; 3,000 ج.م (عالية جداً)</option>
              </select>
            </div>
          </div>

          {/* Debtor Customers List */}
          {filteredDebtors.length === 0 ? (
            <div className="p-10 text-center bg-slate-900 border border-slate-800 rounded-3xl text-slate-400 space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto mb-2">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h3 className="text-sm font-bold text-white">لا توجد مديونيات مطابقة في هذا اليوم</h3>
              <p className="text-xs text-slate-500">
                جميع عملاء هذا الفلتر مسددون بالكامل أو لا توجد نتائج للبحث الحالي.
              </p>
              {currentDayFilter !== 'الكل' && (
                <button
                  onClick={() => setCurrentDayFilter('الكل')}
                  className="mt-2 px-3.5 py-2 bg-slate-800 hover:bg-slate-750 text-amber-400 text-xs font-bold rounded-xl active:scale-95 transition"
                >
                  عرض مديونيات كافة الأيام
                </button>
              )}
            </div>
          ) : (
            <div className="space-y-2.5">
              {filteredDebtors.map((customer) => {
                const balance = Number(customer.balance || 0);
                const unpaidInvoices = invoices.filter(
                  (i) => i.customerId === customer.id && i.remainingAmount > 0
                );

                return (
                  <div
                    key={customer.id}
                    className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-3.5 shadow-lg transition space-y-3"
                  >
                    {/* Top Row: Customer Info & Debt Badge */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded font-mono font-bold">
                            {customer.id}
                          </span>
                          <span className="text-xs font-black text-white">{customer.name}</span>
                          <span className="text-[10px] bg-amber-500/15 text-amber-300 border border-amber-500/30 px-2 py-0.2 rounded-full font-bold">
                            يوم: {customer.dayOfWeek}
                          </span>
                        </div>

                        {customer.address && (
                          <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-1 truncate">
                            <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                            <span>{customer.address}</span>
                          </div>
                        )}

                        <div className="flex items-center gap-3 text-[10px] text-slate-400 mt-1 font-mono">
                          {customer.lastVisit && (
                            <span>آخر زيارة: {customer.lastVisit}</span>
                          )}
                          {unpaidInvoices.length > 0 && (
                            <span className="text-rose-400 font-bold">
                              {unpaidInvoices.length} فاتورة آجل معلقة
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Debt Amount Display */}
                      <div className="text-left shrink-0 bg-rose-950/40 border border-rose-500/30 px-3 py-1.5 rounded-xl">
                        <span className="text-[9px] text-rose-300 block font-bold">إجمالي المديونية</span>
                        <div className="text-base sm:text-lg font-black font-mono text-rose-400 leading-tight">
                          {formatMoney(balance)}
                          <small className="text-[10px] text-rose-300 mr-1">ج.م</small>
                        </div>
                      </div>
                    </div>

                    {/* Bottom Action Row: Direct Repayment & Quick Contact */}
                    <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-800/80">
                      <div className="flex items-center gap-1.5">
                        {customer.phone && (
                          <a
                            href={`tel:${customer.phone}`}
                            className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center active:scale-95 transition"
                            title="اتصال هاتفي بالعميل"
                          >
                            <Phone className="w-3.5 h-3.5 text-emerald-400" />
                          </a>
                        )}

                        {onQuickInvoice && (
                          <button
                            onClick={() => onQuickInvoice(customer)}
                            className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-bold active:scale-95 transition"
                          >
                            فاتورة جديدة
                          </button>
                        )}
                      </div>

                      {/* Primary Direct Payment / Collection Action */}
                      <button
                        onClick={() => {
                          sound.playBarcodeBeep();
                          onPayment(customer);
                        }}
                        className="flex-1 max-w-[200px] py-2 px-3 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white font-black rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-950 active:scale-95 transition"
                      >
                        <Banknote className="w-4 h-4" />
                        <span>تسديد من عند العميل</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Subtab: Today's Collections Log */}
      {activeSubTab === 'collections' && (
        <div className="space-y-3">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-white block">سجل المقبوضات والتحصيلات لليوم</span>
              <span className="text-[11px] text-slate-400">
                إجمالي المحصل: <strong className="text-emerald-400 font-mono">{formatMoney(totalTodayCollected)} ج.م</strong>
              </span>
            </div>
            <span className="text-xs font-mono font-bold text-slate-400 bg-slate-800 px-2 py-1 rounded-xl">
              {todayPayments.length} سند قبض
            </span>
          </div>

          {todayPayments.length === 0 ? (
            <div className="p-10 text-center bg-slate-900 border border-slate-800 rounded-3xl text-slate-400 space-y-2">
              <History className="w-10 h-10 text-slate-600 mx-auto" />
              <p className="text-sm font-bold text-slate-300">لم يتم تسجيل أي تحصيلات نقدية اليوم بعد</p>
              <p className="text-xs text-slate-500">
                عند تحصيل مديونية من أي عميل، ستظهر السندات هنا فورياً مع إمكانية طباعة سند القبض.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {todayPayments.map((payment, idx) => {
                const customer = customers.find((c) => c.id === payment.customerId);
                return (
                  <div
                    key={payment.id || idx}
                    className="bg-slate-900 border border-slate-800 rounded-2xl p-3 flex items-center justify-between gap-2 shadow-md"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-mono bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded">
                          {payment.id}
                        </span>
                        <span className="text-xs font-bold text-white truncate block">
                          {payment.customerName}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-1">
                        <span className="font-mono">
                          {payment.date
                            ? new Date(payment.date).toLocaleTimeString('ar-EG', {
                                hour: '2-digit',
                                minute: '2-digit',
                              })
                            : '-'}
                        </span>
                        <span>•</span>
                        <span className="truncate">{payment.notes || 'سداد نقدي'}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <div className="text-left font-mono">
                        <span className="text-sm font-black text-emerald-400 block">
                          +{formatMoney(payment.amount)} ج.م
                        </span>
                      </div>

                      {customer && onPrintExistingPayment && (
                        <button
                          onClick={() => onPrintExistingPayment(payment, customer)}
                          className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl active:scale-95 transition"
                          title="طباعة سند القبض الحراري"
                        >
                          <Printer className="w-4 h-4 text-amber-400" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
