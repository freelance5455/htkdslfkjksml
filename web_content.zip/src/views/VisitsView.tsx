import React, { useState } from 'react';
import {
  Search,
  Crosshair,
  UserPlus,
  Phone,
  MapPin,
  ShoppingCart,
  CreditCard,
  Undo2,
  Navigation,
  CheckCircle2,
  XCircle,
  Calendar,
  X,
  Compass,
} from 'lucide-react';
import { Customer } from '../db/indexedDB';
import { ROUTE_DAYS, formatMoney, calculateDistanceMeters } from '../utils/calc';
import { sound } from '../utils/sound';

interface VisitsViewProps {
  customers: Customer[];
  selectedDay: string;
  onSelectDay: (day: string) => void;
  onOpenCustomer: (customer: Customer) => void;
  onQuickInvoice: (customer: Customer) => void;
  onPayment: (customer: Customer) => void;
  onReturn: (customer: Customer) => void;
  onNewCustomer: () => void;
  onSaveGPS: (customer: Customer) => void;
  onNavigateGPS: (customer: Customer) => void;
}

export const VisitsView: React.FC<VisitsViewProps> = ({
  customers,
  selectedDay,
  onSelectDay,
  onOpenCustomer,
  onQuickInvoice,
  onPayment,
  onReturn,
  onNewCustomer,
  onSaveGPS,
  onNavigateGPS,
}) => {
  const [search, setSearch] = useState('');
  const [isNearbyFilterActive, setIsNearbyFilterActive] = useState(false);
  const [nearbyCustomers, setNearbyCustomers] = useState<Array<Customer & { distance: number }>>([]);
  const [isLocating, setIsLocating] = useState(false);
  const [proximityMessage, setProximityMessage] = useState<string | null>(null);

  // Filter customers for current day
  const dayCustomers = customers.filter((c) => c.dayOfWeek === selectedDay);

  // Apply search query
  const q = search.trim().toLowerCase();
  const searchFiltered = dayCustomers.filter((c) => {
    if (!q) return true;
    const matchName = c.name.toLowerCase().includes(q);
    const matchPhone = c.phone.toLowerCase().includes(q);
    const matchCode = c.id.toLowerCase().includes(q);
    const matchAddress = c.address.toLowerCase().includes(q);
    return matchName || matchPhone || matchCode || matchAddress;
  });

  // Apply 75m nearby filter if active
  const displayedCustomers = isNearbyFilterActive
    ? nearbyCustomers
    : searchFiltered;

  const handleNearbyRadar = () => {
    if (isNearbyFilterActive) {
      setIsNearbyFilterActive(false);
      setProximityMessage(null);
      return;
    }

    if (!navigator.geolocation) {
      sound.playError();
      alert('خاصية تحديد الموقع غير مدعومة في هذا الجهاز');
      return;
    }

    setIsLocating(true);
    setProximityMessage('جاري تشغيل رادار الـ 75 متراً عبر GPS...');

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setIsLocating(false);
        const myLat = pos.coords.latitude;
        const myLng = pos.coords.longitude;

        const withDistance = dayCustomers
          .filter((c) => c.lat != null && c.lng != null)
          .map((c) => ({
            ...c,
            distance: calculateDistanceMeters(myLat, myLng, c.lat!, c.lng!),
          }))
          .filter((c) => c.distance <= 75)
          .sort((a, b) => a.distance - b.distance);

        setNearbyCustomers(withDistance);
        setIsNearbyFilterActive(true);
        sound.playSuccess();

        if (withDistance.length > 0) {
          setProximityMessage(`تم العثور على ${withDistance.length} عميل في نطاق 75 متراً حولك!`);
        } else {
          setProximityMessage('لا يوجد أي عميل مسجل الموقع على بُعد 75 متراً من موقعك الحالي.');
        }
      },
      () => {
        setIsLocating(false);
        sound.playError();
        setProximityMessage('تعذر التقاط موقعك. يرجى السماح بصلاحيات الموقع وتشغيل الـ GPS.');
      },
      { enableHighAccuracy: true, timeout: 12000 }
    );
  };

  return (
    <div className="space-y-3.5 pb-24 pt-2">
      {/* Route Days Selector */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-2 shadow-lg">
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
          {ROUTE_DAYS.map((d) => {
            const count = customers.filter((c) => c.dayOfWeek === d).length;
            const isSelected = selectedDay === d;
            return (
              <button
                key={d}
                onClick={() => {
                  onSelectDay(d);
                  setIsNearbyFilterActive(false);
                  setProximityMessage(null);
                }}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition active:scale-95 ${
                  isSelected
                    ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                    : 'bg-slate-850 hover:bg-slate-800 text-slate-300'
                }`}
              >
                <span>{d}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                    isSelected ? 'bg-slate-950 text-amber-400' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Search and Action Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 shadow-lg space-y-2.5">
        <div className="flex gap-2">
          {/* Search box */}
          <div className="relative flex-1">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="ابحث بالاسم، الهاتف، العنوان أو الكود..."
              className="w-full h-11 pr-10 pl-9 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-400 focus:outline-none focus:border-amber-500"
            />
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3.5" />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="w-6 h-6 rounded-lg bg-slate-700 text-slate-300 flex items-center justify-center absolute left-2.5 top-2.5 text-xs"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* New Customer Button */}
          <button
            onClick={onNewCustomer}
            className="px-3.5 h-11 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 active:scale-95 transition shadow-md shadow-amber-500/20 shrink-0"
          >
            <UserPlus className="w-4 h-4" />
            <span className="hidden sm:inline">عميل جديد</span>
          </button>
        </div>

        {/* Proximity 75m radar button */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleNearbyRadar}
            disabled={isLocating}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 border transition active:scale-98 ${
              isNearbyFilterActive
                ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                : 'bg-slate-850 hover:bg-slate-800 text-amber-400 border-amber-500/30'
            }`}
          >
            <Compass className={`w-4 h-4 ${isLocating ? 'animate-spin' : ''}`} />
            <span>
              {isLocating
                ? 'جاري فحص الموقع...'
                : isNearbyFilterActive
                ? 'إلغاء تصفية الرادار القريب (75م)'
                : '📡 رادار القريبين (75 متراً حول موقعي)'}
            </span>
          </button>
        </div>

        {proximityMessage && (
          <div className="p-2.5 bg-slate-800/80 rounded-xl border border-slate-700 text-xs text-amber-300 flex items-center justify-between">
            <span>{proximityMessage}</span>
            {isNearbyFilterActive && (
              <button
                onClick={() => {
                  setIsNearbyFilterActive(false);
                  setProximityMessage(null);
                }}
                className="text-[11px] font-bold text-slate-400 hover:text-white"
              >
                عرض كل عملاء اليوم
              </button>
            )}
          </div>
        )}
      </div>

      {/* Customer Count Badge */}
      <div className="flex items-center justify-between px-1 text-xs text-slate-400">
        <span>
          عرض <strong className="text-white">{displayedCustomers.length}</strong> عميل في خط سير يوم{' '}
          <strong className="text-amber-400">{selectedDay}</strong>
        </span>
        {isNearbyFilterActive && (
          <span className="bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full text-[10px] font-bold">
            نطاق 75م فقط
          </span>
        )}
      </div>

      {/* Customer Cards Grid */}
      <div className="space-y-2.5">
        {displayedCustomers.length > 0 ? (
          displayedCustomers.map((customer) => {
            const hasDebt = Number(customer.balance) > 0;
            const hasGPS = customer.lat != null && customer.lng != null;
            const dist = 'distance' in customer ? (customer as any).distance : null;

            return (
              <div
                key={customer.id}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-3.5 shadow-lg space-y-3 transition hover:border-slate-700"
              >
                {/* Header Row */}
                <div className="flex items-start justify-between">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono bg-slate-800 text-amber-400 px-1.5 py-0.5 rounded-md border border-slate-700">
                        {customer.id}
                      </span>
                      <h3
                        onClick={() => onOpenCustomer(customer)}
                        className="text-sm font-bold text-white hover:text-amber-400 cursor-pointer"
                      >
                        {customer.name}
                      </h3>
                    </div>

                    <div className="flex items-center gap-1.5 text-xs text-slate-400">
                      <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                      <span className="truncate max-w-[200px]">{customer.address || 'بدون عنوان مسجل'}</span>
                    </div>

                    {customer.phone && (
                      <div className="flex items-center gap-1.5 text-xs text-slate-400">
                        <Phone className="w-3 h-3 text-sky-400 shrink-0" />
                        <a href={`tel:${customer.phone}`} className="font-mono hover:underline">
                          {customer.phone}
                        </a>
                      </div>
                    )}
                  </div>

                  {/* Debt Badge */}
                  <div className="text-left font-mono">
                    <span
                      className={`text-xs font-black px-2.5 py-1 rounded-xl block ${
                        hasDebt
                          ? 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                          : 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                      }`}
                    >
                      {formatMoney(customer.balance)} ج.م
                    </span>
                    {dist != null && (
                      <span className="text-[10px] text-amber-400 font-bold block mt-1">
                        على بُعد {dist} متر
                      </span>
                    )}
                  </div>
                </div>

                {/* Status bar */}
                <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-800 text-slate-400">
                  <div className="flex items-center gap-1">
                    <Crosshair className={`w-3.5 h-3.5 ${hasGPS ? 'text-emerald-400' : 'text-slate-500'}`} />
                    <span>{hasGPS ? 'GPS محفوظ' : 'بدون موقع'}</span>
                  </div>
                  {customer.lastVisit ? (
                    <span className="text-emerald-400">آخر زيارة: {customer.lastVisit}</span>
                  ) : (
                    <span className="text-slate-500">لم يُزار مؤخراً</span>
                  )}
                </div>

                {/* Quick Action Grid */}
                <div className="grid grid-cols-4 sm:grid-cols-6 gap-1.5">
                  <button
                    onClick={() => onQuickInvoice(customer)}
                    className="py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center justify-center gap-1 active:scale-95 transition"
                  >
                    <ShoppingCart className="w-3.5 h-3.5" />
                    <span>فاتورة</span>
                  </button>

                  <button
                    onClick={() => onPayment(customer)}
                    className="py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-[11px] flex items-center justify-center gap-1 active:scale-95 transition"
                  >
                    <CreditCard className="w-3.5 h-3.5" />
                    <span>تحصيل</span>
                  </button>

                  <button
                    onClick={() => onReturn(customer)}
                    className="py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-[11px] flex items-center justify-center gap-1 active:scale-95 transition"
                  >
                    <Undo2 className="w-3.5 h-3.5" />
                    <span>مرتجع</span>
                  </button>

                  <button
                    onClick={() => onSaveGPS(customer)}
                    className="py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 border border-slate-700 font-bold text-[11px] flex items-center justify-center gap-1 active:scale-95 transition"
                  >
                    <Crosshair className="w-3.5 h-3.5" />
                    <span>حفظ موقعي</span>
                  </button>

                  <button
                    onClick={() => onNavigateGPS(customer)}
                    className="py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-sky-400 border border-slate-700 font-bold text-[11px] flex items-center justify-center gap-1 active:scale-95 transition"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    <span>توجيه</span>
                  </button>

                  <button
                    onClick={() => onOpenCustomer(customer)}
                    className="py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-[11px] flex items-center justify-center gap-1 active:scale-95 transition"
                  >
                    <span>البطاقة</span>
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <div className="p-8 text-center text-xs text-slate-500 bg-slate-900 border border-slate-800 rounded-3xl">
            لا توجد نتائج مطابقة لبحثك في خط سير يوم {selectedDay}.
          </div>
        )}
      </div>
    </div>
  );
};
