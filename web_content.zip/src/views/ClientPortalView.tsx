import React, { useState } from 'react';
import { 
  Building2, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight, 
  FileText, 
  MessageSquare, 
  Mic, 
  Flame, 
  Calendar,
  ShieldCheck,
  Eye
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Project, ProjectStatus } from '../types';

export const ClientPortalView: React.FC = () => {
  const { 
    currentUser, 
    clients, 
    projects, 
    setSelectedProjectId, 
    setActiveView,
    messages,
    documents
  } = useApp();

  const [activeCategoryFilter, setActiveCategoryFilter] = useState<'All' | ProjectStatus>('All');

  // Strict role isolation: Client only sees their own company's projects!
  const userClient = clients.find(c => c.id === currentUser.clientId) || clients[0];
  const companyProjects = projects.filter(p => p.clientId === userClient.id);

  const inProgressProjects = companyProjects.filter(p => p.status === 'In Progress');
  const pendingProjects = companyProjects.filter(p => p.status === 'Pending');
  const completedProjects = companyProjects.filter(p => p.status === 'Completed');
  const overdueProjects = companyProjects.filter(p => p.status === 'Overdue');

  const filteredProjects = activeCategoryFilter === 'All'
    ? companyProjects
    : companyProjects.filter(p => p.status === activeCategoryFilter);

  const handleOpenProject = (id: string) => {
    setSelectedProjectId(id);
    setActiveView('project-detail');
  };

  return (
    <div className="space-y-6">
      {/* Client Welcome Banner */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-red-600 uppercase tracking-wider mb-1">
            <Building2 className="w-4 h-4 text-red-600" />
            <span>Client Transparency Portal</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Welcome, {currentUser.name}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Registered Facility: <strong className="text-slate-800">{userClient.companyName}</strong> ({userClient.city})
          </p>
        </div>

        <div className="flex items-center gap-3 bg-slate-50 border border-slate-200 p-3 rounded-lg text-xs shrink-0">
          <ShieldCheck className="w-6 h-6 text-emerald-600 shrink-0" />
          <div>
            <p className="font-semibold text-slate-900">Dedicated Service Desk</p>
            <p className="text-[11px] text-slate-500">
              Chennai Office:{' '}
              <a href="tel:+919840122841" className="text-red-600 font-semibold hover:underline">
                +91 98401 22841
              </a>
            </p>
          </div>
        </div>
      </div>

      {/* Categorized Project Summary Badges */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <button
          onClick={() => setActiveCategoryFilter('In Progress')}
          className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
            activeCategoryFilter === 'In Progress'
              ? 'bg-blue-50/70 border-blue-400 shadow-xs'
              : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <span className="text-xs font-semibold text-blue-700">In Progress</span>
          <p className="text-2xl font-bold font-mono text-blue-900 mt-1 tabular-nums">
            {inProgressProjects.length}
          </p>
          <span className="text-[11px] text-slate-500">Active site work</span>
        </button>

        <button
          onClick={() => setActiveCategoryFilter('Pending')}
          className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
            activeCategoryFilter === 'Pending'
              ? 'bg-amber-50/70 border-amber-400 shadow-xs'
              : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <span className="text-xs font-semibold text-amber-700">Pending Start</span>
          <p className="text-2xl font-bold font-mono text-amber-900 mt-1 tabular-nums">
            {pendingProjects.length}
          </p>
          <span className="text-[11px] text-slate-500">Drawings & procurement</span>
        </button>

        <button
          onClick={() => setActiveCategoryFilter('Completed')}
          className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
            activeCategoryFilter === 'Completed'
              ? 'bg-emerald-50/70 border-emerald-400 shadow-xs'
              : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <span className="text-xs font-semibold text-emerald-700">Completed</span>
          <p className="text-2xl font-bold font-mono text-emerald-900 mt-1 tabular-nums">
            {completedProjects.length}
          </p>
          <span className="text-[11px] text-slate-500">Commissioned & certified</span>
        </button>

        <button
          onClick={() => setActiveCategoryFilter('Overdue')}
          className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
            activeCategoryFilter === 'Overdue'
              ? 'bg-red-50/70 border-red-400 shadow-xs'
              : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <span className="text-xs font-semibold text-red-700">Delayed / Overdue</span>
          <p className="text-2xl font-bold font-mono text-red-900 mt-1 tabular-nums">
            {overdueProjects.length}
          </p>
          <span className="text-[11px] text-slate-500">Needs attention</span>
        </button>
      </div>

      {/* Projects List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900">
            {activeCategoryFilter === 'All' ? 'All Company Projects' : `${activeCategoryFilter} Projects`} ({filteredProjects.length})
          </h2>
          {activeCategoryFilter !== 'All' && (
            <button
              onClick={() => setActiveCategoryFilter('All')}
              className="text-xs text-red-600 hover:underline font-medium cursor-pointer"
            >
              Show all ({companyProjects.length})
            </button>
          )}
        </div>

        {filteredProjects.length === 0 ? (
          <div className="bg-white rounded-xl border border-slate-200 p-10 text-center text-xs text-slate-500">
            No projects in this category for {userClient.companyName}.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {filteredProjects.map(project => {
              const projectMsgCount = messages.filter(m => m.projectId === project.id).length;
              const sharedDocsCount = documents.filter(d => d.projectId === project.id && d.accessLevel === 'Client Shared').length;

              return (
                <div
                  key={project.id}
                  className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 hover:border-slate-300 transition-all flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs text-slate-500">
                      <span className="font-mono font-bold text-red-600">{project.reference}</span>
                      <span className={`font-semibold ${
                        project.status === 'Completed'
                          ? 'text-emerald-700'
                          : project.status === 'In Progress'
                          ? 'text-blue-700'
                          : project.status === 'Overdue'
                          ? 'text-red-700 font-bold'
                          : 'text-amber-700'
                      }`}>
                        {project.status}
                      </span>
                    </div>

                    <div>
                      <h3 className="text-sm font-bold text-slate-900">{project.name}</h3>
                      <p className="text-xs text-slate-500 mt-0.5">{project.category}</p>
                    </div>

                    <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                      {project.description}
                    </p>

                    {/* Progress Bar */}
                    <div className="space-y-1 pt-1">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-slate-500">Execution Progress</span>
                        <span className="font-mono font-semibold text-slate-800">{project.progressPercentage}%</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            project.status === 'Completed' ? 'bg-emerald-600' : (project.status === 'Overdue' ? 'bg-red-600' : 'bg-blue-600')
                          }`}
                          style={{ width: `${project.progressPercentage}%` }}
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-100">
                      <span>Target Delivery: <strong className="text-slate-700 font-mono">{project.expectedCompletionDate}</strong></span>
                      <div className="flex items-center gap-3">
                        <span className="flex items-center gap-1">
                          <MessageSquare className="w-3.5 h-3.5 text-slate-400" />
                          <span>{projectMsgCount}</span>
                        </span>
                        <span className="flex items-center gap-1">
                          <FileText className="w-3.5 h-3.5 text-slate-400" />
                          <span>{sharedDocsCount}</span>
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                    <span className="text-xs text-slate-500 hidden sm:inline">Click to view drawings & messages</span>
                    <button
                      onClick={() => handleOpenProject(project.id)}
                      className="w-full sm:w-auto px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                    >
                      <span>Open Project Hub</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
