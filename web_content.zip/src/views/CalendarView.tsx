import React, { useState } from 'react';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  XCircle,
  Clock,
  Sparkles
} from 'lucide-react';
import { AppState, DayRecord } from '../types';
import {
  calculateDailyProgress,
  calculateDayNumber,
  formatDate,
  getScheduledActivitiesForDate,
  parseDate
} from '../utils/tracker';
import { playChimeSound } from '../utils/notifications';

interface CalendarViewProps {
  state: AppState;
  activeDateStr: string;
  onSelectDate: (dateStr: string) => void;
  onToggleTask: (activityId: string, dateStr: string) => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({
  state,
  activeDateStr,
  onSelectDate,
  onToggleTask,
}) => {
  // Calendar month state
  const activeDate = parseDate(activeDateStr);
  const [currentMonthDate, setCurrentMonthDate] = useState<Date>(
    new Date(activeDate.getFullYear(), activeDate.getMonth(), 1)
  );

  const prevMonth = () => {
    setCurrentMonthDate(new Date(currentMonthDate.getFullYear(), currentMonthDate.getMonth() - 1, 1));
  };

  const nextMonth = () => {
    setCurrentMonthDate(new Date(currentMonthDate.getFullYear(), currentMonthDate.getMonth() + 1, 1));
  };

  const year = currentMonthDate.getFullYear();
  const month = currentMonthDate.getMonth();
  const monthName = currentMonthDate.toLocaleString('default', { month: 'long' });

  // First day of month (0 is Sunday)
  const firstDayIndex = new Date(year, month, 1).getDay();
  // Total days in month
  const totalDays = new Date(year, month + 1, 0).getDate();

  // Selected date stats
  const selectedDayRecord: DayRecord | undefined = state.history[activeDateStr];
  const scheduledForSelected = getScheduledActivitiesForDate(state.activities, activeDateStr);
  const selectedProgress = calculateDailyProgress(state.activities, selectedDayRecord, activeDateStr);
  const selectedDayNumber = calculateDayNumber(state.profile.startDate, activeDateStr);

  const completedActivities = scheduledForSelected.filter(
    (act) => selectedDayRecord?.tasks?.[act.id]?.completed
  );
  const missedActivities = scheduledForSelected.filter(
    (act) => !selectedDayRecord?.tasks?.[act.id]?.completed
  );

  const handleRetroactiveToggle = (actId: string) => {
    playChimeSound('complete');
    onToggleTask(actId, activeDateStr);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Month Header & Calendar Card */}
      <div className="rounded-3xl bg-white dark:bg-[#13151B] border border-slate-100 dark:border-slate-800 p-5 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-purple-600 dark:text-purple-400">
              Execution History
            </span>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white mt-0.5">
              {monthName} {year}
            </h2>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={prevMonth}
              className="w-8 h-8 rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              aria-label="Previous month"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={nextMonth}
              className="w-8 h-8 rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              aria-label="Next month"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Days of week header */}
        <div className="grid grid-cols-7 gap-1 text-center text-xs font-semibold text-slate-400 mb-2">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
            <div key={d} className="py-1">
              {d}
            </div>
          ))}
        </div>

        {/* Calendar Day Grid */}
        <div className="grid grid-cols-7 gap-1">
          {/* Empty cells before month start */}
          {Array.from({ length: firstDayIndex }).map((_, i) => (
            <div key={`empty_${i}`} className="aspect-square" />
          ))}

          {/* Days of the month */}
          {Array.from({ length: totalDays }).map((_, i) => {
            const dayNum = i + 1;
            const cellDate = new Date(year, month, dayNum);
            const dateStr = formatDate(cellDate);
            const isSelected = dateStr === activeDateStr;
            const record = state.history[dateStr];
            const prog = calculateDailyProgress(state.activities, record, dateStr);

            const hasData = Boolean(record && record.tasks);
            const isFullyCompleted = prog.total > 0 && prog.percentage >= 80;
            const isPartial = prog.total > 0 && prog.percentage > 0 && prog.percentage < 80;

            return (
              <button
                key={dateStr}
                onClick={() => onSelectDate(dateStr)}
                className={`relative aspect-square rounded-2xl flex flex-col items-center justify-center text-xs font-semibold transition-all ${
                  isSelected
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30 ring-2 ring-purple-600 ring-offset-2 dark:ring-offset-slate-900'
                    : hasData
                    ? 'bg-slate-50 dark:bg-slate-900/60 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-900 dark:text-white'
                    : 'text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-900/40'
                }`}
              >
                <span>{dayNum}</span>
                {/* Status indicator dot */}
                {hasData && (
                  <span
                    className={`w-1.5 h-1.5 rounded-full mt-1 ${
                      isSelected
                        ? 'bg-white'
                        : isFullyCompleted
                        ? 'bg-emerald-500'
                        : isPartial
                        ? 'bg-amber-500'
                        : 'bg-slate-300 dark:bg-slate-600'
                    }`}
                  />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Day Inspection & Retroactive Log */}
      <div className="rounded-3xl bg-white dark:bg-[#13151B] border border-slate-100 dark:border-slate-800 p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {new Date(activeDateStr + 'T00:00:00').toLocaleDateString('en-US', {
                  weekday: 'long',
                  month: 'short',
                  day: 'numeric',
                  year: 'numeric',
                })}
              </h3>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-purple-50 dark:bg-purple-950/50 text-purple-700 dark:text-purple-300">
                Day {selectedDayNumber}/90
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              {selectedProgress.completed} of {selectedProgress.total} activities completed ({selectedProgress.percentage}%)
            </p>
          </div>

          <div className="text-right">
            <span className="text-2xl font-extrabold text-slate-900 dark:text-white tabular-nums">
              {selectedProgress.percentage}%
            </span>
            <span className="text-[10px] text-slate-400 block">Daily Score</span>
          </div>
        </div>

        {/* Missed Activities Section (Prompt Requirement) */}
        {missedActivities.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-600 dark:text-amber-400">
              <XCircle className="w-4 h-4" />
              <span>Missed / Pending Activities ({missedActivities.length})</span>
            </div>
            <div className="space-y-1.5">
              {missedActivities.map((act) => (
                <div
                  key={act.id}
                  onClick={() => handleRetroactiveToggle(act.id)}
                  className="rounded-2xl p-3 border border-amber-200/50 dark:border-amber-900/30 bg-amber-50/30 dark:bg-amber-950/10 flex items-center justify-between gap-3 cursor-pointer hover:border-amber-400 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      className="w-6 h-6 rounded-lg border-2 border-amber-400 bg-white dark:bg-slate-900 flex items-center justify-center"
                      aria-label={`Mark ${act.name} completed`}
                    />
                    <div>
                      <h4 className="text-xs font-semibold text-slate-900 dark:text-white">{act.name}</h4>
                      <span className="text-[11px] text-slate-400 capitalize">{act.category} · {act.scheduledTime}</span>
                    </div>
                  </div>
                  <span className="text-[10px] font-semibold text-amber-600 dark:text-amber-400">
                    Tap to Mark Done
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Completed Activities Section */}
        <div className="space-y-2 pt-2">
          <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400">
            <CheckCircle2 className="w-4 h-4" />
            <span>Completed Activities ({completedActivities.length})</span>
          </div>
          {completedActivities.length === 0 ? (
            <p className="text-xs text-slate-400 italic">No activities completed on this date.</p>
          ) : (
            <div className="space-y-1.5">
              {completedActivities.map((act) => (
                <div
                  key={act.id}
                  onClick={() => handleRetroactiveToggle(act.id)}
                  className="rounded-2xl p-3 border border-slate-100 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-900/40 flex items-center justify-between gap-3 cursor-pointer hover:border-slate-300 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
                      <CheckCircle2 className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-semibold text-slate-800 dark:text-slate-200 line-through opacity-85">{act.name}</h4>
                      <span className="text-[11px] text-slate-400 capitalize">{act.category} · {act.scheduledTime}</span>
                    </div>
                  </div>
                  <span className="text-[10px] text-slate-400">Done</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
