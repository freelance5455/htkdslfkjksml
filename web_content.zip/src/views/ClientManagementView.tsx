import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Plus, 
  Building2, 
  Mail, 
  Phone, 
  MapPin, 
  FileSpreadsheet, 
  ExternalLink, 
  Trash2, 
  Edit3, 
  FolderKanban,
  AlertCircle,
  Key
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Client } from '../types';

interface ClientManagementViewProps {
  onOpenZohoModal: () => void;
}

export const ClientManagementView: React.FC<ClientManagementViewProps> = ({ onOpenZohoModal }) => {
  const { 
    clients, 
    projects, 
    addClient, 
    updateClient, 
    deleteClient, 
    setSelectedProjectId, 
    setActiveView 
  } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClientForProfile, setSelectedClientForProfile] = useState<Client | null>(clients[0] || null);
  const [mobileTab, setMobileTab] = useState<'list' | 'profile'>('list');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [clientToDelete, setClientToDelete] = useState<Client | null>(null);
  const [deleteErrorMessage, setDeleteErrorMessage] = useState<string | null>(null);

  // Form state
  const [formData, setFormData] = useState({
    companyName: '',
    contactPerson: '',
    email: '',
    phone: '',
    address: '',
    city: 'Chennai, Tamil Nadu',
    gstin: '',
    industry: 'Commercial Facilities',
    notes: ''
  });

  const filteredClients = clients.filter(c => 
    c.companyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.contactPerson.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.city.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleOpenAddModal = () => {
    setFormData({
      companyName: '',
      contactPerson: '',
      email: '',
      phone: '',
      address: '',
      city: 'Chennai, Tamil Nadu',
      gstin: '',
      industry: 'Commercial Facilities',
      notes: ''
    });
    setIsAddModalOpen(true);
  };

  const handleOpenEditModal = (client: Client) => {
    setEditingClient(client);
    setFormData({
      companyName: client.companyName,
      contactPerson: client.contactPerson,
      email: client.email,
      phone: client.phone,
      address: client.address,
      city: client.city,
      gstin: client.gstin,
      industry: client.industry,
      notes: client.notes || ''
    });
  };

  const handleSaveClient = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.companyName || !formData.contactPerson || !formData.email) return;

    if (editingClient) {
      updateClient(editingClient.id, formData);
      setEditingClient(null);
    } else {
      const created = addClient(formData);
      setSelectedClientForProfile(created);
      setIsAddModalOpen(false);
    }
  };

  const handleConfirmDelete = () => {
    if (!clientToDelete) return;
    const res = deleteClient(clientToDelete.id);
    if (!res.success) {
      setDeleteErrorMessage(res.message);
    } else {
      setClientToDelete(null);
      setDeleteErrorMessage(null);
      if (selectedClientForProfile?.id === clientToDelete.id) {
        setSelectedClientForProfile(clients.find(c => c.id !== clientToDelete.id) || null);
      }
    }
  };

  // Associated projects for selected client
  const associatedProjects = selectedClientForProfile 
    ? projects.filter(p => p.clientId === selectedClientForProfile.id)
    : [];

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Client Directory & Profiles</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage corporate client accounts, billing information, GSTINs, and linked fire safety projects.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:flex sm:flex-wrap items-center gap-2 w-full sm:w-auto">
          <button
            onClick={() => setActiveView('client-import')}
            className="px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer transition-colors flex items-center justify-center gap-1.5"
            title="Batch import from CSV & regenerate client passwords (WordPress plugin feature)"
          >
            <Key className="w-3.5 h-3.5 text-slate-600" />
            <span className="hidden sm:inline">Batch Import & Passwords</span>
            <span className="sm:hidden">Batch CSV</span>
          </button>
          <button
            onClick={onOpenZohoModal}
            className="px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer transition-colors flex items-center justify-center gap-1.5"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-slate-600" />
            <span>Zoho Sync</span>
          </button>
          <button
            onClick={handleOpenAddModal}
            className="col-span-2 sm:col-span-1 px-3.5 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg cursor-pointer shadow-xs transition-colors flex items-center justify-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Client</span>
          </button>
        </div>
      </div>

      {/* Mobile Master-Detail Segmented Tab Switcher */}
      <div className="lg:hidden flex items-center p-1 bg-slate-200/80 rounded-xl text-xs font-semibold">
        <button
          type="button"
          onClick={() => setMobileTab('list')}
          className={`flex-1 py-2 text-center rounded-lg transition-all cursor-pointer ${
            mobileTab === 'list' 
              ? 'bg-white text-slate-900 shadow-xs' 
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <span>Client Directory ({filteredClients.length})</span>
        </button>
        <button
          type="button"
          onClick={() => setMobileTab('profile')}
          className={`flex-1 py-2 text-center rounded-lg transition-all cursor-pointer ${
            mobileTab === 'profile' 
              ? 'bg-white text-slate-900 shadow-xs' 
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <span>Company Profile</span>
        </button>
      </div>

      {/* Main 2-Column Split: Client List + Selected Profile & Associated Projects */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (5 Cols): Client List & Search */}
        <div className={`lg:col-span-5 bg-white rounded-xl border border-slate-200 shadow-xs flex flex-col overflow-hidden ${
          mobileTab === 'profile' ? 'hidden lg:flex' : 'flex'
        }`}>
          <div className="p-4 border-b border-slate-100">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search clients by name, contact, city..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:border-red-500"
              />
            </div>
            <div className="flex items-center justify-between mt-2.5 text-xs text-slate-400">
              <span>{filteredClients.length} clients registered</span>
              <span className="text-[11px]">Click row to inspect profile</span>
            </div>
          </div>

          <div className="divide-y divide-slate-100 overflow-y-auto max-h-[640px]">
            {filteredClients.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500">
                No clients match your search query.
              </div>
            ) : (
              filteredClients.map((client) => {
                const clientProjects = projects.filter(p => p.clientId === client.id);
                const isSelected = selectedClientForProfile?.id === client.id;

                return (
                  <div
                    key={client.id}
                    onClick={() => {
                      setSelectedClientForProfile(client);
                      setMobileTab('profile');
                    }}
                    className={`p-4 transition-colors cursor-pointer text-left ${
                      isSelected ? 'bg-red-50/50 border-l-3 border-l-red-600' : 'hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="font-semibold text-xs text-slate-900 leading-tight">
                        {client.companyName}
                      </h3>
                      <span className="text-[11px] font-mono text-slate-500 shrink-0">
                        {clientProjects.length} {clientProjects.length === 1 ? 'project' : 'projects'}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 mt-1 flex items-center gap-1.5">
                      <span>{client.contactPerson}</span>
                      <span>·</span>
                      <span className="text-slate-400">{client.city}</span>
                    </p>

                    <div className="mt-2 flex items-center justify-between text-[11px]">
                      <span className="font-mono text-slate-500">GST: {client.gstin || 'N/A'}</span>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenEditModal(client);
                          }}
                          className="px-1.5 py-0.5 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded"
                        >
                          Edit
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setClientToDelete(client);
                            setDeleteErrorMessage(null);
                          }}
                          className="px-1.5 py-0.5 text-red-600 hover:text-red-800 hover:bg-red-50 rounded"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column (7 Cols): Comprehensive Profile & Linked Projects */}
        <div className={`lg:col-span-7 space-y-6 ${
          mobileTab === 'list' ? 'hidden lg:block' : 'block'
        }`}>
          {/* Mobile Back Button to return to list */}
          <div className="lg:hidden pb-1">
            <button
              type="button"
              onClick={() => setMobileTab('list')}
              className="text-xs font-semibold text-red-600 hover:text-red-700 flex items-center gap-1.5 py-1 px-2 bg-red-50 rounded-lg cursor-pointer"
            >
              <span>← Back to Client Directory</span>
            </button>
          </div>
          {selectedClientForProfile ? (
            <>
              {/* Profile Card */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-5 border-b border-slate-100">
                  <div>
                    <span className="text-[11px] font-semibold text-red-600 uppercase tracking-wider">
                      {selectedClientForProfile.industry}
                    </span>
                    <h2 className="text-lg font-bold text-slate-900 mt-0.5">
                      {selectedClientForProfile.companyName}
                    </h2>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Account created: {selectedClientForProfile.createdAt}
                      {selectedClientForProfile.zohoContactId && (
                        <span> · Zoho ID: <strong className="font-mono text-slate-700">{selectedClientForProfile.zohoContactId}</strong></span>
                      )}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleOpenEditModal(selectedClientForProfile)}
                      className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer transition-colors"
                    >
                      Edit Profile
                    </button>
                  </div>
                </div>

                {/* Contact & Statutory Info Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-5 text-xs">
                  <div className="space-y-1">
                    <span className="text-slate-400 font-medium">Primary Contact Person</span>
                    <p className="font-semibold text-slate-800">{selectedClientForProfile.contactPerson}</p>
                  </div>

                  <div className="space-y-1">
                    <span className="text-slate-400 font-medium">Email Address</span>
                    <p className="font-mono text-slate-800">{selectedClientForProfile.email}</p>
                  </div>

                  <div className="space-y-1">
                    <span className="text-slate-400 font-medium">Phone Number</span>
                    <p className="font-mono text-slate-800">{selectedClientForProfile.phone}</p>
                  </div>

                  <div className="space-y-1">
                    <span className="text-slate-400 font-medium">GSTIN (Tamil Nadu)</span>
                    <p className="font-mono font-semibold text-slate-800">{selectedClientForProfile.gstin || 'Not Provided'}</p>
                  </div>

                  <div className="sm:col-span-2 space-y-1 pt-1">
                    <span className="text-slate-400 font-medium">Site & Billing Address</span>
                    <p className="text-slate-700">{selectedClientForProfile.address}, {selectedClientForProfile.city}</p>
                  </div>

                  {selectedClientForProfile.notes && (
                    <div className="sm:col-span-2 bg-slate-50 p-3 rounded-lg border border-slate-200 mt-2">
                      <span className="text-slate-500 font-medium block mb-0.5">Account Engineering Notes:</span>
                      <p className="text-slate-700 text-xs italic">{selectedClientForProfile.notes}</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Associated Projects Section */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
                <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                      <FolderKanban className="w-4 h-4 text-red-600" />
                      <span>Associated Projects ({associatedProjects.length})</span>
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      All fire protection installations and AMC contracts for this account
                    </p>
                  </div>
                </div>

                <div className="divide-y divide-slate-100">
                  {associatedProjects.length === 0 ? (
                    <div className="p-6 text-center text-xs text-slate-500">
                      No projects currently linked to this client.
                    </div>
                  ) : (
                    associatedProjects.map((p) => (
                      <div key={p.id} className="p-4 hover:bg-slate-50 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-semibold text-red-600">{p.reference}</span>
                            <span className="text-slate-300">·</span>
                            <span className="font-semibold text-slate-900">{p.name}</span>
                          </div>
                          <p className="text-slate-500 mt-1">
                            {p.category} · Target: <span className="font-mono">{p.expectedCompletionDate}</span>
                          </p>
                        </div>

                        <div className="flex items-center gap-3 shrink-0">
                          <div className="text-right">
                            <span className={`font-semibold ${
                              p.status === 'Completed' ? 'text-emerald-700' : p.status === 'Overdue' ? 'text-red-700' : 'text-blue-700'
                            }`}>
                              {p.status}
                            </span>
                            <p className="font-mono text-slate-500 text-[11px]">{p.progressPercentage}% complete</p>
                          </div>

                          <button
                            onClick={() => {
                              setSelectedProjectId(p.id);
                              setActiveView('project-detail');
                            }}
                            className="px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg cursor-pointer"
                          >
                            Open Project
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </>
          ) : (
            <div className="bg-white rounded-xl border border-slate-200 p-12 text-center text-slate-500 text-xs">
              Select a client from the list to view its complete profile and project history.
            </div>
          )}
        </div>
      </div>

      {/* Add / Edit Client Modal */}
      {(isAddModalOpen || editingClient) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900">
                {editingClient ? 'Edit Client Information' : 'Add New Client Record'}
              </h3>
              <button
                onClick={() => {
                  setIsAddModalOpen(false);
                  setEditingClient(null);
                }}
                className="text-slate-400 hover:text-slate-600 p-1 text-sm font-semibold rounded cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveClient} className="p-6 overflow-y-auto space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Company / Facility Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Apollo Hospitals Enterprise Ltd."
                  value={formData.companyName}
                  onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:border-red-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Contact Person *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. R. Sundararajan"
                    value={formData.contactPerson}
                    onChange={(e) => setFormData({ ...formData, contactPerson: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Industry Sector</label>
                  <input
                    type="text"
                    placeholder="e.g. Healthcare, Automotive, IT"
                    value={formData.industry}
                    onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:border-red-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    placeholder="contact@company.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:border-red-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Phone Number</label>
                  <input
                    type="tel"
                    placeholder="+91 98401 ..."
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:border-red-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">GSTIN Number (Tamil Nadu)</label>
                <input
                  type="text"
                  placeholder="33AAAAA0000A1Z5"
                  value={formData.gstin}
                  onChange={(e) => setFormData({ ...formData, gstin: e.target.value.toUpperCase() })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:border-red-500 font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Street Address</label>
                <input
                  type="text"
                  placeholder="Building No, Street, Industrial Estate"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:border-red-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">City & State</label>
                <input
                  type="text"
                  placeholder="Chennai, Tamil Nadu"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:border-red-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Engineering / Account Remarks</label>
                <textarea
                  rows={2}
                  placeholder="Specific safety requirements, access hours, or key instructions..."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:border-red-500"
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddModalOpen(false);
                    setEditingClient(null);
                  }}
                  className="px-4 py-2 text-slate-600 hover:text-slate-900 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold cursor-pointer shadow-xs transition-colors"
                >
                  {editingClient ? 'Save Changes' : 'Create Client'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal with Validation */}
      {clientToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-md p-6">
            <h3 className="text-base font-bold text-slate-900">Delete Client Record</h3>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Are you sure you want to remove <strong className="text-slate-900">{clientToDelete.companyName}</strong> from Phoenix records?
            </p>

            {deleteErrorMessage && (
              <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-800 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                <span>{deleteErrorMessage}</span>
              </div>
            )}

            <div className="mt-6 flex items-center justify-end gap-3">
              <button
                onClick={() => {
                  setClientToDelete(null);
                  setDeleteErrorMessage(null);
                }}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDelete}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-xs transition-colors"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
