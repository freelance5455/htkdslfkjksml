import React, { useState } from 'react';
import { 
  Users, 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Eye, 
  Phone, 
  Mail, 
  Building, 
  ShieldCheck, 
  UserCheck, 
  AlertCircle 
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Employee } from '../types';

export const EmployeesView: React.FC = () => {
  const { 
    employees, 
    tasks, 
    projects, 
    addEmployee, 
    updateEmployee, 
    deleteEmployee, 
    setSelectedEmployeeId, 
    setActiveView 
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [employeeToDelete, setEmployeeToDelete] = useState<Employee | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  // Form State matching WordPress ppm_add_employee()
  const [formData, setFormData] = useState({
    employeeName: '',
    photo: '',
    aadhaarNumber: '',
    panNumber: '',
    phone: '',
    alternatePhone: '',
    email: '',
    designation: 'Project Engineer',
    department: 'Fire Protection Engineering',
    joiningDate: '2026-01-01',
    bloodGroup: 'O+',
    dateOfBirth: '1990-01-01',
    address: 'Chennai, Tamil Nadu',
    emergencyContactName: '',
    emergencyContactPhone: '',
    status: 'Active' as 'Active' | 'Inactive'
  });

  const filteredEmployees = employees.filter(emp => 
    emp.employeeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    emp.employeeCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
    emp.phone.includes(searchQuery) ||
    emp.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
    emp.designation.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleOpenAddModal = () => {
    setEditingEmployee(null);
    setFormData({
      employeeName: '',
      photo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
      aadhaarNumber: '',
      panNumber: '',
      phone: '+91 ',
      alternatePhone: '',
      email: '',
      designation: 'Project Engineer',
      department: 'Fire Protection Engineering',
      joiningDate: '2026-01-01',
      bloodGroup: 'O+',
      dateOfBirth: '1990-01-01',
      address: 'Chennai, Tamil Nadu',
      emergencyContactName: '',
      emergencyContactPhone: '',
      status: 'Active'
    });
    setIsAddModalOpen(true);
  };

  const handleOpenEditModal = (emp: Employee) => {
    setEditingEmployee(emp);
    setFormData({
      employeeName: emp.employeeName,
      photo: emp.photo || '',
      aadhaarNumber: emp.aadhaarNumber || '',
      panNumber: emp.panNumber || '',
      phone: emp.phone,
      alternatePhone: emp.alternatePhone || '',
      email: emp.email,
      designation: emp.designation,
      department: emp.department,
      joiningDate: emp.joiningDate,
      bloodGroup: emp.bloodGroup || 'O+',
      dateOfBirth: emp.dateOfBirth || '',
      address: emp.address || '',
      emergencyContactName: emp.emergencyContactName || '',
      emergencyContactPhone: emp.emergencyContactPhone || '',
      status: emp.status
    });
    setIsAddModalOpen(true);
  };

  const handleSaveEmployee = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.employeeName || !formData.phone) return;

    if (editingEmployee) {
      updateEmployee(editingEmployee.id, formData);
    } else {
      addEmployee(formData);
    }
    setIsAddModalOpen(false);
    setEditingEmployee(null);
  };

  const handleConfirmDelete = () => {
    if (!employeeToDelete) return;
    const res = deleteEmployee(employeeToDelete.id);
    if (!res.success) {
      setDeleteError(res.message);
    } else {
      setEmployeeToDelete(null);
      setDeleteError(null);
    }
  };

  const handleViewEmployee = (empId: string) => {
    setSelectedEmployeeId(empId);
    setActiveView('view-employee');
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">
            <Users className="w-4 h-4 text-slate-600" />
            <span>WordPress Plugin Module: ppm_employees</span>
          </div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Employees Directory</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage field engineers, CAD technicians, commissioning supervisors, statutory details & task loads.
          </p>
        </div>

        <button
          onClick={handleOpenAddModal}
          className="px-4 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg cursor-pointer shadow-xs transition-colors flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Employee</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex items-center justify-between gap-4">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search by code (e.g. PFS-0001), name, phone, department, or designation..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:border-red-500"
          />
        </div>
        <span className="text-xs font-mono text-slate-500 shrink-0">
          {filteredEmployees.length} employees listed
        </span>
      </div>

      {/* Employees Table and Mobile Cards matching admin/employees.php */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Mobile Employee Cards List */}
        <div className="md:hidden divide-y divide-slate-100">
          {filteredEmployees.length === 0 ? (
            <div className="py-8 text-center text-slate-500 text-xs">
              No employees found matching your query.
            </div>
          ) : (
            filteredEmployees.map((employee) => {
              const empTasks = tasks.filter(t => t.assignedToEmployeeId === employee.id);

              return (
                <div key={employee.id} className="p-4 space-y-3 hover:bg-slate-50/70 transition-colors">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      {employee.photo ? (
                        <img
                          src={employee.photo}
                          alt={employee.employeeName}
                          className="w-10 h-10 rounded-full object-cover border border-slate-200 shrink-0"
                        />
                      ) : (
                        <div className="w-10 h-10 rounded-full bg-slate-200 text-slate-700 font-bold flex items-center justify-center text-xs shrink-0">
                          {employee.employeeName.charAt(0)}
                        </div>
                      )}
                      <div>
                        <button
                          onClick={() => handleViewEmployee(employee.id)}
                          className="font-bold text-slate-900 text-xs hover:text-red-600 text-left cursor-pointer"
                        >
                          {employee.employeeName}
                        </button>
                        <p className="font-mono text-red-600 font-semibold text-[11px]">{employee.employeeCode}</p>
                      </div>
                    </div>

                    <span className={`text-[10px] px-2 py-0.5 rounded font-semibold shrink-0 ${
                      employee.status === 'Active' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-500'
                    }`}>
                      {employee.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs text-slate-600 pt-1">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Designation</span>
                      <span className="font-medium text-slate-800">{employee.designation}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block">Department</span>
                      <span className="text-slate-700">{employee.department}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block">Phone</span>
                      <span className="font-mono text-slate-700">{employee.phone}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block">Tasks Assigned</span>
                      <button
                        onClick={() => handleViewEmployee(employee.id)}
                        className="inline-block px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 font-bold font-mono text-[11px] hover:bg-blue-100 cursor-pointer"
                      >
                        {empTasks.length} active
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                    <button
                      onClick={() => handleViewEmployee(employee.id)}
                      className="px-2.5 py-1 text-xs text-slate-700 hover:bg-slate-100 rounded font-medium cursor-pointer"
                    >
                      Profile
                    </button>
                    <button
                      onClick={() => handleOpenEditModal(employee)}
                      className="px-2.5 py-1 text-xs text-blue-600 hover:bg-blue-50 rounded font-medium cursor-pointer"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => {
                        setEmployeeToDelete(employee);
                        setDeleteError(null);
                      }}
                      className="px-2.5 py-1 text-xs text-red-600 hover:bg-red-50 rounded font-medium cursor-pointer"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Desktop Table */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4 w-12">ID</th>
                <th className="py-3 px-4 w-14">Photo</th>
                <th className="py-3 px-4">Employee Code</th>
                <th className="py-3 px-4">Name</th>
                <th className="py-3 px-4">Phone</th>
                <th className="py-3 px-4">Department</th>
                <th className="py-3 px-4">Designation</th>
                <th className="py-3 px-4 text-center">Tasks</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredEmployees.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-8 text-center text-slate-500">
                    No employees found.
                  </td>
                </tr>
              ) : (
                filteredEmployees.map((employee, idx) => {
                  const empTasks = tasks.filter(t => t.assignedToEmployeeId === employee.id);

                  return (
                    <tr key={employee.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4 font-mono text-slate-500">
                        {idx + 1}
                      </td>
                      <td className="py-3 px-4">
                        {employee.photo ? (
                          <img
                            src={employee.photo}
                            alt={employee.employeeName}
                            className="w-9 h-9 rounded-full object-cover border border-slate-200"
                          />
                        ) : (
                          <div className="w-9 h-9 rounded-full bg-slate-200 text-slate-600 font-bold flex items-center justify-center text-xs">
                            {employee.employeeName.charAt(0)}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4 font-mono font-bold text-red-600">
                        {employee.employeeCode}
                      </td>
                      <td className="py-3 px-4">
                        <button
                          onClick={() => handleViewEmployee(employee.id)}
                          className="font-semibold text-slate-900 hover:text-red-600 text-left cursor-pointer"
                        >
                          {employee.employeeName}
                        </button>
                        <p className="text-[11px] text-slate-400 font-mono">{employee.email}</p>
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-700">
                        {employee.phone}
                      </td>
                      <td className="py-3 px-4 text-slate-600">
                        {employee.department}
                      </td>
                      <td className="py-3 px-4 text-slate-800 font-medium">
                        {employee.designation}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <button
                          onClick={() => handleViewEmployee(employee.id)}
                          className="inline-block px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 font-bold font-mono text-xs hover:bg-blue-100 cursor-pointer"
                        >
                          {empTasks.length}
                        </button>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`font-semibold ${
                          employee.status === 'Active' ? 'text-emerald-700' : 'text-slate-400'
                        }`}>
                          {employee.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleViewEmployee(employee.id)}
                            className="px-2 py-1 text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded font-medium cursor-pointer"
                          >
                            View
                          </button>
                          <button
                            onClick={() => handleOpenEditModal(employee)}
                            className="px-2 py-1 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded font-medium cursor-pointer"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => {
                              setEmployeeToDelete(employee);
                              setDeleteError(null);
                            }}
                            className="px-2 py-1 text-red-600 hover:text-red-800 hover:bg-red-50 rounded font-medium cursor-pointer"
                          >
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Employee Modal matching admin/add-employee.php */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  {editingEmployee ? `Edit Employee (${editingEmployee.employeeCode})` : 'Add New Employee'}
                </h3>
                <p className="text-xs text-slate-500">
                  {editingEmployee ? 'Update employee details and credentials' : 'Creates an employee record with auto-generated PFS code'}
                </p>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 text-sm font-semibold rounded cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveEmployee} className="p-6 overflow-y-auto space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Employee Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="Full Name"
                    value={formData.employeeName}
                    onChange={(e) => setFormData({ ...formData, employeeName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Photo URL</label>
                  <input
                    type="text"
                    placeholder="https://... or photo url"
                    value={formData.photo}
                    onChange={(e) => setFormData({ ...formData, photo: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono text-[11px]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Phone *</label>
                  <input
                    type="tel"
                    required
                    placeholder="+91 94443..."
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Alternate Phone</label>
                  <input
                    type="tel"
                    placeholder="+91 98840..."
                    value={formData.alternatePhone}
                    onChange={(e) => setFormData({ ...formData, alternatePhone: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Email</label>
                  <input
                    type="email"
                    placeholder="employee@phoenixfiresafety.in"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Department</label>
                  <input
                    type="text"
                    placeholder="e.g. Fire Protection Engineering, Testing"
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Designation</label>
                  <input
                    type="text"
                    placeholder="e.g. Senior Project Engineer, Supervisor"
                    value={formData.designation}
                    onChange={(e) => setFormData({ ...formData, designation: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Aadhaar Number</label>
                  <input
                    type="text"
                    placeholder="XXXX-XXXX-XXXX"
                    value={formData.aadhaarNumber}
                    onChange={(e) => setFormData({ ...formData, aadhaarNumber: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">PAN Number</label>
                  <input
                    type="text"
                    placeholder="ABCDE1234F"
                    value={formData.panNumber}
                    onChange={(e) => setFormData({ ...formData, panNumber: e.target.value.toUpperCase() })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono uppercase"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Blood Group</label>
                  <select
                    value={formData.bloodGroup}
                    onChange={(e) => setFormData({ ...formData, bloodGroup: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                  >
                    <option value="">Select</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Joining Date</label>
                  <input
                    type="date"
                    value={formData.joiningDate}
                    onChange={(e) => setFormData({ ...formData, joiningDate: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Status</label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                  >
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Residential Address</label>
                <textarea
                  rows={2}
                  placeholder="Street, Area, Pin Code, Chennai..."
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Emergency Contact Name</label>
                  <input
                    type="text"
                    placeholder="Name (Relationship)"
                    value={formData.emergencyContactName}
                    onChange={(e) => setFormData({ ...formData, emergencyContactName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Emergency Contact Phone</label>
                  <input
                    type="tel"
                    placeholder="+91 ..."
                    value={formData.emergencyContactPhone}
                    onChange={(e) => setFormData({ ...formData, emergencyContactPhone: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:text-slate-900 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold cursor-pointer shadow-xs transition-colors"
                >
                  {editingEmployee ? 'Update Employee' : 'Save Employee'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {employeeToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-md p-6">
            <h3 className="text-base font-bold text-slate-900">Delete Employee Record</h3>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Are you sure you want to remove <strong className="text-slate-900">{employeeToDelete.employeeCode} - {employeeToDelete.employeeName}</strong>?
            </p>

            {deleteError && (
              <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-800 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                <span>{deleteError}</span>
              </div>
            )}

            <div className="mt-6 flex items-center justify-end gap-3">
              <button
                onClick={() => {
                  setEmployeeToDelete(null);
                  setDeleteError(null);
                }}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDelete}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-xs transition-colors"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
