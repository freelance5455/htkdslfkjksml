import React from 'react';
import { 
  Briefcase, 
  CheckSquare, 
  Clock, 
  AlertCircle, 
  ArrowRight, 
  MessageSquare, 
  Mic, 
  FileText, 
  Plus, 
  CheckCircle2,
  Calendar
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { TaskStatus } from '../types';

export const EmployeePortalView: React.FC = () => {
  const { 
    currentUser, 
    projects, 
    tasks, 
    updateTaskStatus, 
    setSelectedProjectId, 
    setActiveView 
  } = useApp();

  // Employee only sees projects they are assigned to
  const myProjects = projects.filter(p => p.assignedEmployeeIds.includes(currentUser.id));
  const myTasks = tasks.filter(t => t.assignedToEmployeeId === currentUser.id);

  const pendingTasks = myTasks.filter(t => t.status === 'To Do');
  const inProgressTasks = myTasks.filter(t => t.status === 'In Progress');
  const completedTasks = myTasks.filter(t => t.status === 'Completed');
  const overdueTasks = myTasks.filter(t => t.status === 'Overdue');

  const handleOpenProject = (id: string) => {
    setSelectedProjectId(id);
    setActiveView('project-detail');
  };

  return (
    <div className="space-y-6">
      {/* Employee Greeting Banner */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[11px] font-semibold text-blue-700 uppercase tracking-wider">
            Engineer Field Workspace
          </span>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-0.5">
            Hello, {currentUser.name}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            {currentUser.designation} · Phoenix Fire Safety Equipments
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveView('tasks')}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-xs transition-colors"
          >
            All Work Orders
          </button>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">Assigned Projects</span>
          <p className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">{myProjects.length}</p>
          <span className="text-[11px] text-slate-400">Active site sites</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs text-blue-700 font-medium">In Progress Tasks</span>
          <p className="text-2xl font-bold font-mono text-blue-900 mt-1 tabular-nums">{inProgressTasks.length}</p>
          <span className="text-[11px] text-slate-400">{pendingTasks.length} queued</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-red-200 bg-red-50/30 shadow-xs">
          <span className="text-xs text-red-700 font-medium">Overdue Attention</span>
          <p className="text-2xl font-bold font-mono text-red-900 mt-1 tabular-nums">{overdueTasks.length}</p>
          <span className="text-[11px] text-red-600 font-medium">Requires immediate report</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-emerald-200 bg-emerald-50/20 shadow-xs">
          <span className="text-xs text-emerald-700 font-medium">Tasks Completed</span>
          <p className="text-2xl font-bold font-mono text-emerald-900 mt-1 tabular-nums">{completedTasks.length}</p>
          <span className="text-[11px] text-emerald-600">Successfully inspected</span>
        </div>
      </div>

      {/* Main Split: Urgent Tasks + My Assigned Projects */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (6 Cols): My Assigned Tasks */}
        <div className="lg:col-span-6 bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden flex flex-col">
          <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <CheckSquare className="w-4 h-4 text-red-600" />
                <span>My Active Tasks ({myTasks.filter(t => t.status !== 'Completed').length})</span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">Quickly update status as installation progresses</p>
            </div>
          </div>

          <div className="divide-y divide-slate-100 overflow-y-auto max-h-[550px]">
            {myTasks.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500">
                You have no assigned tasks at this time.
              </div>
            ) : (
              myTasks.map(task => (
                <div key={task.id} className="p-4 hover:bg-slate-50 transition-colors space-y-2 text-xs">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="font-semibold text-slate-900">{task.title}</p>
                      <button
                        onClick={() => handleOpenProject(task.projectId)}
                        className="text-red-600 hover:underline font-mono text-[11px] mt-0.5"
                      >
                        {task.projectReference}
                      </button>
                    </div>

                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                      task.status === 'Overdue' 
                        ? 'bg-red-100 text-red-700 font-bold' 
                        : task.status === 'In Progress' 
                        ? 'bg-blue-100 text-blue-700' 
                        : 'bg-slate-100 text-slate-700'
                    }`}>
                      {task.status}
                    </span>
                  </div>

                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    {task.description}
                  </p>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[11px]">
                    <span className="text-slate-500 font-mono">
                      Deadline: <strong className="text-slate-700">{task.deadline}</strong>
                    </span>

                    {/* Quick update button */}
                    <div className="flex items-center gap-2">
                      <select
                        value={task.status}
                        onChange={(e) => updateTaskStatus(task.id, e.target.value as TaskStatus)}
                        className="text-[11px] bg-slate-50 border border-slate-200 rounded px-2 py-1 font-semibold cursor-pointer"
                      >
                        <option value="To Do">To Do</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Completed">Completed</option>
                      </select>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right Column (6 Cols): My Assigned Projects */}
        <div className="lg:col-span-6 bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden flex flex-col">
          <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-slate-700" />
                <span>My Assigned Projects ({myProjects.length})</span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">Projects where you are primary engineer</p>
            </div>
          </div>

          <div className="divide-y divide-slate-100 overflow-y-auto max-h-[550px]">
            {myProjects.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500">
                You are not currently assigned to any active project.
              </div>
            ) : (
              myProjects.map(p => (
                <div key={p.id} className="p-4 hover:bg-slate-50 transition-colors space-y-2.5 text-xs">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-red-600">{p.reference}</span>
                        <span className="text-slate-300">·</span>
                        <span className="font-semibold text-slate-900">{p.name}</span>
                      </div>
                      <p className="text-slate-500 text-[11px] mt-0.5">{p.clientCompanyName}</p>
                    </div>

                    <span className={`text-[11px] font-semibold ${
                      p.status === 'Completed' ? 'text-emerald-700' : p.status === 'Overdue' ? 'text-red-700' : 'text-blue-700'
                    }`}>
                      {p.status}
                    </span>
                  </div>

                  {/* Progress bar */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-500">Progress</span>
                      <span className="font-mono font-bold text-slate-800">{p.progressPercentage}%</span>
                    </div>
                    <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full ${
                          p.status === 'Completed' ? 'bg-emerald-600' : p.status === 'Overdue' ? 'bg-red-600' : 'bg-blue-600'
                        }`} 
                        style={{ width: `${p.progressPercentage}%` }} 
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[11px]">
                    <span className="text-slate-500">Location: {p.siteLocation.split(',')[0]}</span>
                    <button
                      onClick={() => handleOpenProject(p.id)}
                      className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                    >
                      <span>Open Workspace</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
