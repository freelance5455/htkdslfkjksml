import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type { CartItem, MenuItem, PlacedOrder, Shop, ZoneId } from "./types";
import { SHOPS, zoneFee } from "./data/shops";

type Modal =
  | null
  | "menu"
  | "prompt"
  | "cart"
  | "checkout"
  | "auth"
  | "success"
  | "search"
  | "splash";

interface Store {
  zone: ZoneId;
  setZone: (z: ZoneId) => void;
  category: string;
  setCategory: (c: string) => void;
  query: string;
  setQuery: (q: string) => void;
  cart: CartItem[];
  addItem: (shop: Shop, item: MenuItem, qty?: number) => void;
  addCustom: (shop: Shop, name: string, note: string, price: number) => void;
  setQty: (key: string, qty: number) => void;
  clearCart: () => void;
  count: number;
  subtotal: number;
  delivery: number;
  total: number;
  shop: Shop | null;
  openShop: (s: Shop) => void;
  modal: Modal;
  setModal: (m: Modal) => void;
  close: () => void;
  user: { name: string; phone: string } | null;
  setUser: (u: { name: string; phone: string } | null) => void;
  order: PlacedOrder | null;
  placeOrder: (o: Omit<PlacedOrder, "id" | "createdAt" | "items" | "subtotal" | "delivery" | "total">) => PlacedOrder;
  toast: string | null;
  showToast: (m: string) => void;
  scrolled: boolean;
}

const Ctx = createContext<Store | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [zone, setZone] = useState<ZoneId>("gate2");
  const [category, setCategory] = useState("all");
  const [query, setQuery] = useState("");
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const raw = localStorage.getItem("tb-cart");
      return raw ? (JSON.parse(raw) as CartItem[]) : [];
    } catch {
      return [];
    }
  });
  const [shop, setShop] = useState<Shop | null>(null);
  const [modal, setModal] = useState<Modal>(null);
  const [user, setUser] = useState<{ name: string; phone: string } | null>(null);
  const [order, setOrder] = useState<PlacedOrder | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = modal ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [modal]);

  useEffect(() => {
    try {
      const raw = localStorage.getItem("tb-user");
      if (raw) setUser(JSON.parse(raw));
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("tb-cart", JSON.stringify(cart));
  }, [cart]);

  const showToast = useCallback((m: string) => {
    setToast(m);
    window.setTimeout(() => setToast(null), 2400);
  }, []);

  const addItem = useCallback(
    (s: Shop, item: MenuItem, qty = 1) => {
      setCart((prev) => {
        const key = `${s.id}:${item.id}`;
        const found = prev.find((p) => p.key === key);
        if (found) {
          return prev.map((p) => (p.key === key ? { ...p, qty: p.qty + qty } : p));
        }
        return [
          ...prev,
          {
            key,
            shopId: s.id,
            shopName: s.name,
            itemId: item.id,
            name: item.name,
            description: item.description,
            price: item.price,
            qty,
            image: item.image,
          },
        ];
      });
      showToast(`Added ${item.name}`);
    },
    [showToast]
  );

  const addCustom = useCallback(
    (s: Shop, name: string, note: string, price: number) => {
      const id = `custom-${Date.now()}`;
      setCart((prev) => [
        ...prev,
        {
          key: `${s.id}:${id}`,
          shopId: s.id,
          shopName: s.name,
          itemId: id,
          name,
          description: note,
          price,
          qty: 1,
          image: s.image,
          note,
        },
      ]);
      showToast(`Added from ${s.name}`);
    },
    [showToast]
  );

  const setQty = useCallback((key: string, qty: number) => {
    setCart((prev) => (qty <= 0 ? prev.filter((p) => p.key !== key) : prev.map((p) => (p.key === key ? { ...p, qty } : p))));
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  const count = useMemo(() => cart.reduce((a, c) => a + c.qty, 0), [cart]);
  const subtotal = useMemo(() => cart.reduce((a, c) => a + c.price * c.qty, 0), [cart]);
  const delivery = useMemo(() => {
    if (!cart.length) return 0;
    const fees = cart.map((c) => {
      const s = SHOPS.find((x) => x.id === c.shopId);
      return s?.deliveryFee ?? zoneFee(s?.zone ?? zone);
    });
    const raw = Math.max(...fees);
    return subtotal >= 150 ? 0 : raw;
  }, [cart, zone, subtotal]);
  const total = subtotal + delivery;

  const openShop = useCallback((s: Shop) => {
    setShop(s);
    setZone(s.zone);
    setModal(s.hasMenu ? "menu" : "prompt");
  }, []);

  const close = useCallback(() => setModal(null), []);

  const persistUser = useCallback((u: { name: string; phone: string } | null) => {
    setUser(u);
    if (u) localStorage.setItem("tb-user", JSON.stringify(u));
    else localStorage.removeItem("tb-user");
  }, []);

  const placeOrder = useCallback(
    (o: Omit<PlacedOrder, "id" | "createdAt" | "items" | "subtotal" | "delivery" | "total">) => {
      const placed: PlacedOrder = {
        ...o,
        id: `TB${Math.floor(100000 + Math.random() * 900000)}`,
        createdAt: Date.now(),
        items: cart,
        subtotal,
        delivery,
        total,
      };
      setOrder(placed);
      setCart([]);
      setModal("success");
      return placed;
    },
    [cart, subtotal, delivery, total]
  );

  const value: Store = {
    zone,
    setZone,
    category,
    setCategory,
    query,
    setQuery,
    cart,
    addItem,
    addCustom,
    setQty,
    clearCart,
    count,
    subtotal,
    delivery,
    total,
    shop,
    openShop,
    modal,
    setModal,
    close,
    user,
    setUser: persistUser,
    order,
    placeOrder,
    toast,
    showToast,
    scrolled,
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useStore");
  return ctx;
}
