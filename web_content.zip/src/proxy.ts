import { NextResponse, type NextRequest } from "next/server";

// Booking is open to visitors without an account; account pages stay protected.
const PROTECTED_PREFIXES = ["/appointments", "/notifications", "/profile", "/admin"];
const SESSION_COOKIE = "shifacare_session";

/**
 * Lightweight route guard. Pages require a session cookie; API routes enforce
 * roles themselves (see src/lib/http.ts), so the cookie is verified server-side on every call.
 */
export function proxy(req: NextRequest) {
  const { pathname, search } = req.nextUrl;
  const needsAuth = PROTECTED_PREFIXES.some((p) => pathname === p || pathname.startsWith(`${p}/`));
  if (!needsAuth) return NextResponse.next();

  if (!req.cookies.get(SESSION_COOKIE)?.value) {
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    url.search = `?next=${encodeURIComponent(pathname + search)}`;
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|api/).*)"],
};
