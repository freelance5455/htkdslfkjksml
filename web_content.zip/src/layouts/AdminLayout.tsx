import React from 'react';
import { Outlet, Navigate, useLocation, Link, useNavigate } from 'react-router-dom';
import { 
  ShieldCheck, 
  Lock, 
  LogOut, 
  Globe, 
  ExternalLink, 
  AlertCircle,
  FolderArchive,
  Store as StoreIcon
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useApp } from '../context/AppContext';
import { ExportProjectModal } from '../components/modals/ExportProjectModal';

export const AdminLayout: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { currentUser, role, userProfile, logout, loading } = useAuth();
  const { language, setLanguage, isExportModalOpen, setIsExportModalOpen } = useApp();

  const isBn = language === 'bn';

  // Check if current user is an authorized platform Super Admin
  const isSuperAdmin = 
    role === 'SUPER_ADMIN' || 
    (currentUser?.email && ['mdsujatali20@gmail.com', 'alimdsujat4@gmail.com', 'admin@shanju.com'].includes(currentUser.email.toLowerCase()));

  // 1. Loading State
  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-300">
        <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mb-4 animate-pulse">
          <ShieldCheck className="w-7 h-7" />
        </div>
        <div className="w-6 h-6 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin mb-3"></div>
        <p className="text-xs font-semibold tracking-wider uppercase text-slate-400">
          {isBn ? 'অ্যাডমিন সিকিউরিটি যাচাই করা হচ্ছে...' : 'Verifying Administrator Credentials...'}
        </p>
      </div>
    );
  }

  // 2. Unauthenticated -> Redirect to /admin/login
  if (!currentUser) {
    return <Navigate to="/admin/login" replace state={{ from: location }} />;
  }

  // 3. Authenticated but unauthorized (non-admin user)
  if (!isSuperAdmin) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center shadow-2xl">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center mb-5">
            <Lock className="w-8 h-8" />
          </div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold uppercase mb-3">
            <AlertCircle className="w-3.5 h-3.5" />
            <span>{isBn ? 'অনুমতি নেই' : 'Restricted Area'}</span>
          </div>
          <h2 className="text-xl font-bold text-white mb-2">
            {isBn ? 'সুপার অ্যাডমিন অ্যাক্সেস সীমাবদ্ধ' : 'Super Admin Access Restricted'}
          </h2>
          <p className="text-xs text-slate-400 mb-6 leading-relaxed">
            {isBn
              ? `আপনি বর্তমানে "${currentUser.email}" হিসেবে সাইন ইন করেছেন, যা প্ল্যাটফর্মের সুপার অ্যাডমিন তালিকায় অন্তর্ভুক্ত নয়। অনুগ্রহ করে অ্যাডমিন একাউন্ট দিয়ে লগইন করুন।`
              : `You are signed in as "${currentUser.email}", which does not possess Super Admin permissions. Please log in with an administrator account.`}
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link
              to="/"
              className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
            >
              {isBn ? 'সাধারণ হোমে ফিরুন' : 'Back to Public Home'}
            </Link>
            <button
              onClick={async () => {
                await logout();
                navigate('/admin/login');
              }}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md shadow-emerald-600/30 transition-all"
            >
              {isBn ? 'অ্যাডমিন একাউন্টে সাইন ইন' : 'Switch to Admin Account'}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 4. Authenticated Super Admin -> Dedicated Admin Layout
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Dedicated Admin Header */}
      <header className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Admin Brand Branding */}
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md shadow-emerald-500/20">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-base font-extrabold tracking-tight text-white">
                    Shanju Admin OS
                  </span>
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    Super Admin
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 hidden sm:block">
                  {isBn ? 'প্ল্যাটফর্মের কেন্দ্রীয় কন্ট্রোল সেন্টার' : 'Platform Central Control Hub'}
                </span>
              </div>
            </div>

            {/* Admin Right Bar Controls */}
            <div className="flex items-center gap-2 sm:gap-3">
              {/* Link to Public Website */}
              <Link
                to="/"
                target="_blank"
                rel="noreferrer"
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white border border-slate-700 text-xs font-semibold transition-all"
                title={isBn ? 'নতুন ট্যাবে সাধারণ ওয়েবসাইট খুলুন' : 'Open Public Site in New Tab'}
              >
                <StoreIcon className="w-3.5 h-3.5 text-emerald-400" />
                <span>{isBn ? 'পাবলিক সাইট দেখুন' : 'Public Site'}</span>
                <ExternalLink className="w-3 h-3 text-slate-400" />
              </Link>

              {/* Export Source Code ZIP */}
              <button
                onClick={() => setIsExportModalOpen(true)}
                className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 hover:border-emerald-500/60 text-xs font-semibold transition-all"
                title={isBn ? 'সোর্স কোড ZIP ডাউনলোড' : 'Export Full Project ZIP'}
              >
                <FolderArchive className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden md:inline">{isBn ? 'ZIP ডাউনলোড' : 'Export ZIP'}</span>
                <span className="md:hidden">ZIP</span>
              </button>

              {/* Language Switcher */}
              <button
                onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
                className="flex items-center gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 transition-colors"
                title="Toggle Language"
              >
                <Globe className="w-3.5 h-3.5 text-emerald-400" />
                <span>{language === 'en' ? 'বাংলা' : 'EN'}</span>
              </button>

              {/* Admin Profile & Logout */}
              <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
                <div className="hidden lg:block text-right">
                  <p className="text-xs font-bold text-white truncate max-w-[130px]">
                    {userProfile?.displayName || 'Admin'}
                  </p>
                  <p className="text-[10px] text-emerald-400 truncate max-w-[130px]">
                    {currentUser.email}
                  </p>
                </div>

                <button
                  onClick={async () => {
                    await logout();
                    navigate('/admin/login');
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-semibold transition-colors"
                  title={isBn ? 'লগআউট' : 'Sign Out'}
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{isBn ? 'লগআউট' : 'Logout'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Admin Body Content */}
      <main className="flex-1">
        <Outlet />
      </main>

      {/* Export Modal */}
      <ExportProjectModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        language={language}
      />
    </div>
  );
};
