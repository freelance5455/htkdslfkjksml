import React from 'react';
import { Outlet, useNavigate } from 'react-router-dom';
import { PublicNavbar } from '../components/navigation/PublicNavbar';
import { CreateStoreWizardModal } from '../components/modals/CreateStoreWizardModal';
import { AuthModal } from '../components/modals/AuthModal';
import { useApp } from '../context/AppContext';

export const PublicLayout: React.FC = () => {
  const navigate = useNavigate();
  const {
    language,
    isCreateStoreWizardOpen,
    setIsCreateStoreWizardOpen,
    isAuthModalOpen,
    setIsAuthModalOpen,
    authModalMode,
    handleWizardStoreCreated
  } = useApp();

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100">
      {/* Isolated Public Navbar - Zero Admin Components */}
      <PublicNavbar />

      {/* Main Public View Content */}
      <main className="flex-1">
        <Outlet />
      </main>

      {/* Public Store Creation Wizard Modal */}
      <CreateStoreWizardModal
        isOpen={isCreateStoreWizardOpen}
        onClose={() => setIsCreateStoreWizardOpen(false)}
        language={language}
        onStoreCreated={handleWizardStoreCreated}
        onViewStorefront={() => {
          setIsCreateStoreWizardOpen(false);
          navigate('/storefront');
        }}
      />

      {/* Firebase Auth Modal (for merchants / customers) */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        language={language}
        initialMode={authModalMode}
        onSuccess={() => {
          navigate('/dashboard');
        }}
      />
    </div>
  );
};
