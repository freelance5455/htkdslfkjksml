// Règles de plateau extraites de l'ancienne version V116 (9 arènes spéciales).
// Les arènes visuelles et les 60 emplacements d'arènes de clubs ne modifient pas les règles.
export const ARENA_RULES = Object.freeze({
  terrestrial: Object.freeze({ id:'terrestrial', name:'Terrestre', clock:'standard' }),
  neon: Object.freeze({ id:'neon', name:'Néon', clock:'neon' }),
  crystalline: Object.freeze({ id:'crystalline', name:'Cristalline', clock:'standard', crystals:[[4,3],[4,7],[5,2],[5,6]] }),
  gravitational: Object.freeze({ id:'gravitational', name:'Gravitationnelle', clock:'standard', kingMoveLimit:3 }),
  volcanic: Object.freeze({ id:'volcanic', name:'Volcanique', clock:'standard', lava:[[4,1],[4,5],[5,4],[5,8]] }),
  oceanic: Object.freeze({ id:'oceanic', name:'Océanique', clock:'standard', menCaptureForwardOnly:true }),
  temporal: Object.freeze({ id:'temporal', name:'Temporelle', clock:'temporal', maxTurnsPerSide:40 }),
  dimensional: Object.freeze({ id:'dimensional', name:'Dimensionnelle', clock:'standard', earlyPromotion:true }),
  galacticSupreme: Object.freeze({ id:'galacticSupreme', name:'Galactique Suprême', clock:'galacticSupreme', lava:[[4,5],[5,4]], crystals:[[4,1],[5,8]] })
});
export const ARENA_OPTIONS = Object.values(ARENA_RULES).map(({id,name})=>({id,name}));
export function getArenaRules(arena='terrestrial') {
  const rules=ARENA_RULES[arena];
  if(!rules) throw new Error(`Arène inconnue : ${arena}`);
  return rules;
}
export function isArenaSquare(list,r,c){return !!list?.some(([rr,cc])=>rr===r&&cc===c);}
