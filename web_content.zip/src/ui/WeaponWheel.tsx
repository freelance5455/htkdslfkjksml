import { useState } from 'react';
import { engine } from '../game/engine';
import { WEAPONS, WEAPON_ORDER } from '../game/items';
import { useHud } from './useHud';

/** Radial weapon selector shown from the circular button in the top-right. */
export default function WeaponWheel() {
  const hud = useHud();
  const [hover, setHover] = useState<string | null>(null);
  if (!hud.wheelOpen) return null;

  const owned = (id: string) => id === 'fists' || engine.ownsWeapon(id);
  const radius = 116;
  const center = 140;

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center bg-black/35 backdrop-blur-[2px]"
      onClick={() => (engine.wheelOpen = false)}
    >
      <div
        className="relative"
        style={{ width: center * 2, height: center * 2 }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* ring */}
        <div
          className="absolute rounded-full border border-amber-400/25"
          style={{ inset: center - radius - 26, boxShadow: 'inset 0 0 60px rgba(0,0,0,0.55)' }}
        />
        {WEAPON_ORDER.map((id, i) => {
          const w = WEAPONS[id];
          const a = (i / WEAPON_ORDER.length) * Math.PI * 2 - Math.PI / 2;
          const x = center + Math.cos(a) * radius;
          const y = center + Math.sin(a) * radius;
          const isOwned = owned(id);
          const isCurrent = hud.weapon === id;
          return (
            <button
              key={id}
              onMouseEnter={() => setHover(id)}
              onMouseLeave={() => setHover(null)}
              onClick={() => engine.selectWeapon(id)}
              className={`absolute w-16 h-16 -translate-x-1/2 -translate-y-1/2 rounded-full flex flex-col items-center justify-center transition ${
                isCurrent
                  ? 'bg-amber-500 text-black border-2 border-amber-200 shadow-[0_0_22px_rgba(245,185,66,0.7)] scale-110'
                  : isOwned
                  ? 'bg-zinc-800/95 border border-white/25 text-white hover:scale-105'
                  : 'bg-zinc-900/80 border border-white/10 text-white/30'
              }`}
              style={{ left: x, top: y }}
            >
              <span className="text-xl leading-none">{w.icon}</span>
              <span className="text-[7px] font-bold tracking-tight mt-0.5">
                {w.short}
              </span>
              {!isOwned && (
                <span className="absolute -bottom-1 text-[7px] bg-black/80 px-1 rounded text-amber-400">
                  LOCKED
                </span>
              )}
            </button>
          );
        })}
        {/* centre info */}
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-52 text-center pointer-events-none">
          <div className="text-[11px] font-bold text-amber-300 uppercase tracking-wider">
            {WEAPONS[hover ?? hud.weapon].name}
          </div>
          <div className="text-[10px] text-white/60 mt-1 leading-snug">
            {WEAPONS[hover ?? hud.weapon].desc}
          </div>
        </div>
      </div>
      <div className="absolute bottom-10 text-[11px] text-white/60 tracking-widest">
        TAP A WEAPON · 1-6 QUICK SELECT
      </div>
    </div>
  );
}
