import { useEffect, useRef } from "react";
import type { QualityLevel } from "@/game/types";

type Props = {
  quality: QualityLevel;
  reduceMotion: boolean;
  ambience: string;
  act: number;
  falling?: boolean;
  warm?: boolean;
};

export function Starfield({ quality, reduceMotion, ambience, act, falling, warm }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const count = quality === "high" ? 220 : quality === "medium" ? 120 : 48;
    let w = 0;
    let h = 0;
    let raf = 0;
    let last = performance.now();
    const dpr = Math.min(2, window.devicePixelRatio || 1);

    type Star = { x: number; y: number; z: number; r: number; tw: number; vx: number; vy: number };
    let stars: Star[] = [];

    const resize = () => {
      w = canvas.clientWidth;
      h = canvas.clientHeight;
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const seed = () => {
      stars = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        z: Math.random(),
        r: Math.random() * 1.4 + 0.2,
        tw: Math.random() * Math.PI * 2,
        vx: (Math.random() - 0.5) * 0.02,
        vy: falling ? 0.15 + Math.random() * 0.35 : (Math.random() - 0.5) * 0.01,
      }));
    };

    resize();
    seed();
    const onResize = () => {
      resize();
      seed();
    };
    window.addEventListener("resize", onResize);

    const nebula = () => {
      const g = ctx.createRadialGradient(w * 0.5, h * 0.35, 20, w * 0.5, h * 0.4, Math.max(w, h) * 0.7);
      if (warm) {
        g.addColorStop(0, "rgba(120, 72, 48, 0.16)");
        g.addColorStop(0.45, "rgba(40, 24, 28, 0.1)");
        g.addColorStop(1, "rgba(0,0,0,0)");
      } else if (ambience === "fall") {
        g.addColorStop(0, "rgba(50, 24, 40, 0.2)");
        g.addColorStop(1, "rgba(0,0,0,0)");
      } else {
        g.addColorStop(0, "rgba(28, 40, 72, 0.22)");
        g.addColorStop(0.5, "rgba(20, 16, 40, 0.12)");
        g.addColorStop(1, "rgba(0,0,0,0)");
      }
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);
    };

    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      ctx.fillStyle = "#07060c";
      ctx.fillRect(0, 0, w, h);
      nebula();

      for (const s of stars) {
        if (!reduceMotion) {
          s.tw += dt * (0.6 + s.z);
          s.x += s.vx * (quality === "eco" ? 0 : 1);
          s.y += s.vy;
          if (s.x < 0) s.x += w;
          if (s.x > w) s.x -= w;
          if (s.y > h) s.y = 0;
          if (s.y < 0) s.y = h;
        }
        const a = 0.25 + s.z * 0.7 + (reduceMotion ? 0 : Math.sin(s.tw) * 0.2);
        ctx.beginPath();
        ctx.fillStyle = `rgba(243,239,230,${Math.max(0.08, Math.min(1, a))})`;
        ctx.arc(s.x, s.y, s.r * (0.6 + s.z), 0, Math.PI * 2);
        ctx.fill();
      }

      if (act <= 1 && ambience === "threshold") {
        const cx = w * 0.5;
        const cy = h * 0.28;
        const grd = ctx.createRadialGradient(cx, cy, 0, cx, cy, 48);
        grd.addColorStop(0, "rgba(243,239,230,0.9)");
        grd.addColorStop(0.25, "rgba(197,205,216,0.35)");
        grd.addColorStop(1, "rgba(7,6,12,0)");
        ctx.fillStyle = grd;
        ctx.beginPath();
        ctx.arc(cx, cy, 48, 0, Math.PI * 2);
        ctx.fill();
      }

      raf = requestAnimationFrame(loop);
    };

    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
    };
  }, [quality, reduceMotion, ambience, act, falling, warm]);

  return <canvas ref={ref} className="pointer-events-none absolute inset-0 h-full w-full" aria-hidden />;
}
