import React from 'react';
import { CarTelemetry, CameraMode } from '../types';
import { GameEngine } from '../game/GameEngine';
import { Minimap } from './Minimap';
import { Speedometer } from './Speedometer';
import { RadioWidget } from './RadioWidget';
import { BottomControlDock } from './BottomControlDock';
import { TouchControls } from './TouchControls';
import { Pause, Sparkles } from 'lucide-react';

interface HUDProps {
  engine: GameEngine | null;
  telemetry: CarTelemetry;
  cameraMode: CameraMode;
  onCameraChange: (mode: CameraMode) => void;
  onPause: () => void;
  onOpenGallery: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  engine,
  telemetry,
  cameraMode,
  onCameraChange,
  onPause,
  onOpenGallery,
}) => {
  return (
    <div className="fixed inset-0 pointer-events-none select-none z-20 flex flex-col justify-between p-4 font-mono">
      {/* Top Bar Perimeter Cluster */}
      <div className="flex justify-between items-start pointer-events-none">
        {/* Top-Left: Minimal Title & City Status */}
        <div className="pointer-events-auto flex flex-col gap-1">
          <div className="flex items-center gap-2 bg-slate-900/85 border border-pink-500/60 px-3 py-1.5 rounded-xl shadow-[0_0_15px_rgba(255,0,127,0.25)]">
            <span className="text-sm font-black text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-yellow-300 tracking-wider">
              VICE CITY
            </span>
            <span className="text-[10px] text-cyan-300 font-bold border-l border-slate-700 pl-2">
              FREE ROAM
            </span>
          </div>

          {/* Stunt notice if top speed or airtime record */}
          {telemetry.topSpeed > 180 && (
            <div className="text-[10px] font-bold text-yellow-300 bg-black/60 px-2 py-0.5 rounded border border-yellow-500/40 w-fit">
              TOP RECORD: {telemetry.topSpeed} KM/H
            </div>
          )}
        </div>

        {/* Top-Right: Radio Station & Pause Button */}
        <div className="flex items-center gap-2 pointer-events-auto">
          <RadioWidget />

          <button
            onClick={onPause}
            className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-700 hover:border-pink-500 text-slate-300 hover:text-white transition-colors cursor-pointer shadow-lg"
            title="Pause Game (Esc)"
          >
            <Pause className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Center 85% playfield completely unobstructed! */}
      <div className="flex-1 pointer-events-none" />

      {/* Bottom Perimeter: Minimap on Left, Speedometer on Right */}
      <div className="flex justify-between items-end mb-16 sm:mb-12 pointer-events-none">
        {/* Bottom Left: GTA Minimap */}
        <div className="pointer-events-auto">
          <Minimap
            playerX={telemetry.carPosition.x}
            playerZ={telemetry.carPosition.z}
            playerYaw={telemetry.carRotationY}
          />
        </div>

        {/* Bottom Right: Speedometer & Telemetry */}
        <div className="pointer-events-auto">
          <Speedometer telemetry={telemetry} />
        </div>
      </div>

      {/* Bottom Center: Collapsible Control Dock */}
      <BottomControlDock
        engine={engine}
        onOpenGallery={onOpenGallery}
        headlightsOn={telemetry.headlightsOn}
        underglowOn={telemetry.underglowOn}
        cameraMode={cameraMode}
        onCameraChange={onCameraChange}
      />

      {/* On-Screen Mobile Pedals & Steer */}
      <TouchControls engine={engine} />
    </div>
  );
};
