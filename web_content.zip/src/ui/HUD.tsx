import { BookOpen, Compass, Layers, Map, Settings, Orbit, Star } from "lucide-react";
import { MISSIONS, ACT_TITLES } from "@/data/missions";
import { relevantItems, fillNames } from "@/game/engine";
import { useGame } from "@/game/store";
import { cn } from "@/lib/utils";

const NAV = [
  { id: "journal" as const, icon: BookOpen, label: "Journal" },
  { id: "inventory" as const, icon: Layers, label: "Traces" },
  { id: "map" as const, icon: Map, label: "Carte" },
  { id: "constellation" as const, icon: Star, label: "Ciel" },
  { id: "combine" as const, icon: Orbit, label: "Résonance" },
];

export function HUD() {
  const overlay = useGame((s) => s.overlay);
  const setOverlay = useGame((s) => s.setOverlay);
  const act = useGame((s) => s.act);
  const flags = useGame((s) => s.flags);
  const locationId = useGame((s) => s.locationId);
  const inventory = useGame((s) => s.inventory);
  const hudVisible = useGame((s) => s.settings.hudVisible);
  const names = useGame((s) => s.names);
  const listen = useGame((s) => s.listenToStar);
  const phase = useGame((s) => s.phase);

  if (phase === "ending" || phase === "credits" || !hudVisible) return null;

  const mission = [...MISSIONS].reverse().find((m) => !flags[m.completeFlag] && (!m.unlockFlag || flags[m.unlockFlag]));
  const title = ACT_TITLES[act];
  const relevant = relevantItems(locationId, inventory);

  return (
    <>
      <div className="pointer-events-none absolute inset-x-0 top-0 z-20 p-4 pt-[max(1rem,env(safe-area-inset-top))]">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-[0.62rem] uppercase tracking-[0.28em] text-fog">Acte {act} — {title?.title}</p>
            <p className="mt-1 max-w-[16rem] font-display text-sm text-lumen/90">
              {mission ? fillNames(mission.title, names) : "Explorer."}
            </p>
          </div>
          <button
            type="button"
            onClick={() => setOverlay("settings")}
            className="pointer-events-auto flex size-11 items-center justify-center rounded-full border border-lumen/15 bg-void/40 text-silver"
            aria-label="Réglages"
          >
            <Settings className="size-4" />
          </button>
        </div>
        {relevant.length > 0 && (
          <p className="pointer-events-none mt-3 text-[0.7rem] tracking-wide text-silver/70">
            Une étrange résonance est détectée.
          </p>
        )}
      </div>

      <div className="absolute inset-x-0 bottom-0 z-20 px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
        <div className="mx-auto flex max-w-md items-end gap-2">
          <button
            type="button"
            onClick={listen}
            className="flex h-14 flex-1 flex-col items-center justify-center rounded-lg border border-lumen/15 bg-void/55 text-[0.62rem] uppercase tracking-[0.14em] text-silver backdrop-blur-md"
          >
            <Compass className="mb-0.5 size-4" />
            Écouter
          </button>
          <nav className="flex h-14 flex-[3] items-center justify-around rounded-lg border border-lumen/15 bg-void/70 px-1 backdrop-blur-md">
            {NAV.map((n) => {
              const Icon = n.icon;
              const active = overlay === n.id;
              return (
                <button
                  key={n.id}
                  type="button"
                  aria-label={n.label}
                  onClick={() => setOverlay(active ? "none" : n.id)}
                  className={cn(
                    "flex size-11 items-center justify-center rounded-md text-fog transition-colors",
                    active && "bg-lumen/10 text-lumen",
                  )}
                >
                  <Icon className="size-4" />
                </button>
              );
            })}
          </nav>
        </div>
      </div>
    </>
  );
}
