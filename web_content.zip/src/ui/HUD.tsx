import type { HudState } from '../game/Game';
import { RARITY_COLORS } from '../game/data/weapons';
import { cn } from '../utils/cn';

export function HUD({ h, touch, showFps, onRangeReset, onRangeEnd, onArmory }: { h: HudState; touch: boolean; showFps: boolean; onRangeReset: () => void; onRangeEnd: () => void; onArmory: () => void }) {
  const w = h.weapon;
  const lowAmmo = w && w.mag <= Math.ceil(w.magSize * 0.25);
  return (
    <div className="absolute inset-0 pointer-events-none z-10 font-[var(--font-display)]" style={{ paddingLeft: 'env(safe-area-inset-left)', paddingRight: 'env(safe-area-inset-right)' }}>
      {/* top center */}
      <div className="absolute top-2 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1">
        {h.mode === 'tdm' ? (
          <div className="flex items-center gap-2">
            <div className="bg-sky-500/80 px-3 py-1 text-lg font-black min-w-14 text-center clip-corner-sm">{h.teamScore[0]}</div>
            <div className="bg-black/60 px-3 py-1 text-sm font-bold tabular-nums">{h.timeText}<div className="text-[8px] text-white/50 text-center">TO {h.scoreLimit}</div></div>
            <div className="bg-red-600/80 px-3 py-1 text-lg font-black min-w-14 text-center clip-corner-sm">{h.teamScore[1]}</div>
          </div>
        ) : (
          <div className="flex items-center gap-2 bg-black/55 px-3 py-1 clip-corner-sm">
            <span className="text-sm font-bold tabular-nums">{h.timeText}</span>
            {h.mode !== 'range' && <span className="text-[11px] tracking-widest text-white/70">{h.mode === 'br' ? 'ALIVE' : 'HOSTILES'} <b className="text-red-400 text-sm">{h.enemiesLeft + (h.mode === 'br' && h.alive ? 1 : 0)}</b></span>}
            {h.mode === 'combat' && <span className="text-[11px] tracking-widest text-white/70">WAVE <b className="text-amber-op text-sm">{h.wave}/{h.maxWave}</b></span>}
          </div>
        )}
        <div className="flex items-center gap-2 text-sm font-black tracking-widest">
          <span className="tabular-nums" style={{ textShadow: '0 1px 4px #000' }}>{h.score.toLocaleString()}</span>
          {h.multiplier > 1 && <span className="text-amber-op text-xs anim-pop" key={h.multiplier}>x{h.multiplier.toFixed(2)}</span>}
        </div>
        {h.zone && <div className={cn('text-[11px] font-bold tracking-widest px-2 py-0.5', h.zone.outside ? 'bg-sky-600 text-white anim-blink' : 'bg-black/50 text-sky-300')}>{h.zone.outside ? 'OUTSIDE ZONE — TAKING DAMAGE' : h.zone.text}</div>}
        <div className="text-[10px] tracking-widest text-white/60 hidden sm:block" style={{ textShadow: '0 1px 3px #000' }}>{h.objective}</div>
      </div>
      {/* killfeed */}
      <div className={cn('absolute right-2 flex flex-col items-end gap-0.5', touch ? 'top-14' : 'top-2')}>
        {showFps && <div className="text-[10px] text-green-400 font-mono mb-1">{h.fps} FPS</div>}
        {h.killfeed.map(k => (
          <div key={k.id} className="anim-feed bg-black/55 px-2 py-0.5 text-[11px] font-bold flex gap-1.5 items-center">
            <span className={k.kTeam === 0 ? 'text-sky-300' : k.kTeam < 0 ? 'text-white/60' : 'text-red-300'}>{k.killer}</span>
            <span className="text-white/50 text-[9px]">{k.weapon ? `[${k.weapon.split(' ')[0]}]` : '☠'}{k.head ? ' ⌖' : ''}</span>
            <span className={k.vTeam === 0 ? 'text-sky-300' : 'text-red-300'}>{k.victim}</span>
          </div>
        ))}
      </div>
      {/* banner */}
      {h.banner && (
        <div key={h.banner.id} className="absolute top-[24%] inset-x-0 text-center anim-banner">
          <div className="text-2xl sm:text-5xl font-black tracking-[0.25em] text-white" style={{ textShadow: '0 0 30px rgba(245,165,36,0.6), 0 2px 6px #000' }}>{h.banner.text}</div>
          {h.banner.sub && <div className="text-[11px] sm:text-sm tracking-[0.3em] text-amber-op mt-1" style={{ textShadow: '0 1px 4px #000' }}>{h.banner.sub}</div>}
        </div>
      )}
      {h.streakText && <div key={h.streakText} className="absolute top-[38%] inset-x-0 text-center text-xl sm:text-3xl font-black tracking-[0.3em] text-amber-op anim-pop" style={{ textShadow: '0 2px 8px #000' }}>{h.streakText}</div>}
      {/* prompt */}
      {h.prompt && <div className="absolute top-[60%] inset-x-0 flex justify-center"><div className="bg-black/70 border border-amber-op/50 px-3 py-1.5 text-xs sm:text-sm font-bold tracking-widest anim-pop">{h.prompt}</div></div>}
      {h.useLabel && <div className="absolute top-[56%] inset-x-0 text-center text-xs font-bold tracking-[0.3em] text-white/80">{h.useLabel}</div>}
      {h.reload > 0 && <div className="absolute top-[57%] left-1/2 -translate-x-1/2 w-28"><div className="text-[9px] text-center tracking-[0.3em] text-white/70 mb-0.5">RELOADING</div><div className="h-1 bg-white/20"><div className="h-full bg-amber-op" style={{ width: `${h.reload * 100}%` }} /></div></div>}
      {!h.alive && h.respawnIn > 0 && <div className="absolute top-[45%] inset-x-0 text-center"><div className="text-3xl font-black tracking-[0.3em] text-red-400">ELIMINATED</div><div className="text-sm tracking-widest text-white/80 mt-1">Respawning in {h.respawnIn.toFixed(1)}s</div></div>}
      {/* health / armor */}
      <div className={cn('absolute left-3 w-52 sm:w-64', touch ? 'top-[136px]' : 'bottom-3')}>
        {h.mode === 'br' && (
          <div className="flex items-center gap-1 mb-1">
            <div className="flex-1 h-2 bg-black/50 flex gap-0.5">{[0, 1, 2].map(i => <div key={i} className="flex-1 bg-white/10"><div className="h-full bg-sky-400" style={{ width: `${Math.max(0, Math.min(1, (h.armor - i * 50) / 50)) * 100}%` }} /></div>)}</div>
            <span className="text-[10px] font-bold text-sky-300 w-7 text-right">{h.armor}</span>
          </div>
        )}
        <div className="flex items-center gap-1">
          <div className="flex-1 h-3 bg-black/50 relative overflow-hidden clip-corner-sm">
            <div className={cn('absolute inset-y-0 left-0 transition-all duration-150', h.health < 35 ? 'bg-red-500' : 'bg-white/90')} style={{ width: `${(h.health / h.maxHealth) * 100}%` }} />
          </div>
          <span className="text-sm font-black w-8 text-right tabular-nums">{h.health}</span>
        </div>
        {h.mode === 'br' && <div className="flex gap-3 mt-1 text-[11px] font-bold tracking-widest text-white/80"><span>✚ {h.medkits}/3 <span className="text-white/40">{touch ? '' : '[H]'}</span></span><span className="text-sky-300">▣ {h.plates}/3 <span className="text-white/40">{touch ? '' : '[V]'}</span></span></div>}
      </div>
      {/* weapon / ammo */}
      <div className={cn('absolute text-right', touch ? 'top-[136px] right-3' : 'bottom-3 right-4')}>
        {w ? <>
          <div className="text-[10px] tracking-[0.3em] font-bold" style={{ color: RARITY_COLORS[w.rarity] }}>{w.name} <span className="text-white/40">· {w.mode}</span></div>
          <div className="flex items-baseline justify-end gap-1 leading-none">
            <span className={cn('font-black tabular-nums', touch ? 'text-3xl' : 'text-5xl', lowAmmo ? 'text-red-400' : 'text-white')} style={{ textShadow: '0 2px 6px #000' }}>{w.mag}</span>
            <span className="text-lg text-white/50 font-bold tabular-nums">/ {w.reserve}</span>
          </div>
          {w.mag === 0 && w.reserve === 0 && <div className="text-[10px] text-red-400 font-bold tracking-widest">NO AMMO</div>}
        </> : <div className="text-xs text-white/50">NO WEAPON</div>}
        <div className="flex gap-1 justify-end mt-1">
          {h.slots.map((s, i) => <div key={i} className={cn('px-2 py-0.5 text-[9px] font-bold tracking-wider border-b-2', i === h.active ? 'bg-white/20' : 'bg-black/40 text-white/50')} style={{ borderColor: s ? RARITY_COLORS[s.rarity] : '#444' }}>{i + 1} {s ? s.name.split(' ')[1] ?? s.name : '—'}</div>)}
        </div>
      </div>
      {/* practice range panel */}
      {h.range && (
        <div className={cn('absolute left-3 pointer-events-auto z-30 bg-black/60 p-2 w-44 text-[11px] tracking-widest', touch ? 'top-[180px]' : 'top-[186px]')}>
          <div className="grid grid-cols-2 gap-y-0.5"><span className="text-white/50">HITS</span><b className="text-right">{h.range.hits}</b><span className="text-white/50">MISSES</span><b className="text-right">{h.range.misses}</b><span className="text-white/50">ACCURACY</span><b className="text-right text-amber-op">{h.range.acc}%</b><span className="text-white/50">TARGETS</span><b className="text-right">{h.range.targets}</b><span className="text-white/50">TIME</span><b className="text-right">{Math.floor(h.range.time / 60)}:{String(h.range.time % 60).padStart(2, '0')}</b></div>
          <div className="flex flex-col gap-1 mt-2">
            <button onClick={onArmory} className="bg-amber-op text-black font-bold py-1">ARMORY {touch ? '' : '[B]'}</button>
            <button onClick={onRangeReset} className="bg-white/15 font-bold py-1">RESTART STATS</button>
            <button onClick={onRangeEnd} className="bg-white/15 font-bold py-1">END SESSION</button>
          </div>
        </div>
      )}
    </div>
  );
}
