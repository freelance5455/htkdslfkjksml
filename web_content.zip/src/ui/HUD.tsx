import { useEffect, useState } from 'react';
import { engine } from '../game/engine';
import { useHud, fmtTime, fmtMoney } from './useHud';
import Minimap from './Minimap';

const WEATHER_ICON: Record<string, string> = {
  Clear: '☀️',
  Cloudy: '⛅',
  Overcast: '☁️',
  Rain: '🌧️',
  Storm: '⛈️',
  Fog: '🌫️',
};

export default function HUD({ onOpenMap }: { onOpenMap: () => void }) {
  const hud = useHud();
  const [, setTick] = useState(0);
  const [hints, setHints] = useState(1);

  useEffect(() => {
    const id = setInterval(() => setTick((v) => v + 1), 120);
    const fade = setTimeout(() => setHints(0), 26000);
    return () => {
      clearInterval(id);
      clearTimeout(fade);
    };
  }, []);

  const hpPct = Math.max(0, Math.min(100, (hud.hp / hud.maxHp) * 100));
  const low = hud.hp < 30;

  return (
    <div className="pointer-events-none fixed inset-0 z-30 select-none font-sans">
      {/* damage vignette */}
      {hud.damageFlash > 0.02 && (
        <div
          className="absolute inset-0 transition-opacity duration-150"
          style={{
            background:
              'radial-gradient(ellipse at center, rgba(180,0,0,0) 45%, rgba(160,10,10,0.55) 100%)',
            opacity: Math.min(1, hud.damageFlash),
          }}
        />
      )}
      {low && (
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(ellipse at center, rgba(120,0,0,0) 55%, rgba(120,0,0,0.35) 100%)',
            animation: 'pulse 1.4s ease-in-out infinite',
          }}
        />
      )}

      {/* ---------- top-left: minimap + location ---------- */}
      <div className="absolute top-3 left-3 flex flex-col gap-2">
        <Minimap />
        <div className="bg-black/55 backdrop-blur-sm rounded-md px-2.5 py-1.5 border border-white/10">
          <div className="text-[11px] font-semibold tracking-wide text-amber-300 uppercase">
            {hud.location}
          </div>
          <div className="text-[11px] text-white/75 flex items-center gap-2">
            <span>{fmtTime(hud.clock)}</span>
            <span>
              {WEATHER_ICON[hud.weather] ?? '☀️'} {hud.weather}
            </span>
            <span className="text-white/50">{hud.temp}°C</span>
          </div>
        </div>
      </div>

      {/* ---------- top-right: money, wanted, weapon wheel button ---------- */}
      <div className="absolute top-3 right-3 flex flex-col items-end gap-2">
        <div className="flex items-center gap-2">
          <div className="bg-black/55 backdrop-blur-sm rounded-md px-3 py-1.5 border border-white/10 text-emerald-300 font-bold text-sm tracking-wide">
            {fmtMoney(hud.money)}
          </div>
          {hud.wanted > 0 && (
            <div className="bg-black/55 backdrop-blur-sm rounded-md px-3 py-1.5 border border-red-500/40">
              <div className="text-amber-400 text-sm tracking-widest">
                {'★'.repeat(hud.wanted)}
                <span className="text-white/25">{'★'.repeat(5 - hud.wanted)}</span>
              </div>
            </div>
          )}
        </div>

        <button
          onClick={() => {
            engine.wheelOpen = !engine.wheelOpen;
          }}
          className="pointer-events-auto relative w-16 h-16 rounded-full bg-gradient-to-b from-zinc-700/90 to-zinc-900/90 border-2 border-amber-400/70 shadow-[0_0_22px_rgba(245,185,66,0.35)] flex items-center justify-center active:scale-95 transition"
        >
          <span className="text-2xl">{hud.weaponIcon}</span>
          <span className="absolute -bottom-5 text-[9px] font-semibold tracking-widest text-amber-300/90">
            WEAPONS
          </span>
        </button>
      </div>

      {/* ---------- bottom-left: health ---------- */}
      <div className="absolute bottom-4 left-3 flex flex-col gap-2">
        <div className="bg-black/55 backdrop-blur-sm rounded-md border border-white/10 px-3 py-2 w-56">
          <div className="flex items-center justify-between text-[10px] tracking-widest text-white/60 mb-1">
            <span>HEALTH</span>
            <span className={low ? 'text-red-400 font-bold' : 'text-white/80'}>
              {hud.hp} / {hud.maxHp}
            </span>
          </div>
          <div className="h-2.5 w-full rounded-full bg-black/60 overflow-hidden border border-white/10">
            <div
              className="h-full rounded-full transition-all duration-200"
              style={{
                width: `${hpPct}%`,
                background: low
                  ? 'linear-gradient(90deg,#b32020,#ff4d4d)'
                  : 'linear-gradient(90deg,#2f9d55,#6ee7a0)',
              }}
            />
          </div>
          {hud.inVehicle && (
            <div className="mt-1.5 flex items-center justify-between text-[10px] text-white/70">
              <span className="truncate max-w-[150px]">{hud.vehicleName}</span>
              <span className="font-bold text-amber-300">{Math.round(hud.speed)} km/h</span>
            </div>
          )}
        </div>

        {/* notifications */}
        <div className="flex flex-col gap-1">
          {hud.notifications.map((n) => (
            <div
              key={n.id}
              className={`bg-black/60 backdrop-blur-sm rounded border-l-2 px-3 py-1 text-[11px] font-medium ${
                n.kind === 'good'
                  ? 'border-emerald-400 text-emerald-200'
                  : n.kind === 'bad'
                  ? 'border-red-500 text-red-200'
                  : 'border-amber-400 text-amber-100'
              }`}
            >
              {n.text}
            </div>
          ))}
        </div>
      </div>

      {/* ---------- bottom-right: weapon + ammo ---------- */}
      <div className="absolute bottom-4 right-3 bg-black/55 backdrop-blur-sm rounded-md border border-white/10 px-3 py-2 text-right">
        <div className="text-[10px] tracking-widest text-white/55">EQUIPPED</div>
        <div className="text-sm font-bold text-amber-300 uppercase">{hud.weaponName}</div>
        {hud.weapon !== 'fists' && (
          <div className="text-[12px] text-white/80 font-mono">
            {hud.ammo} <span className="text-white/40">/ {hud.reserve}</span>
          </div>
        )}
        <div className="text-[9px] text-white/40 mt-0.5">
          {hud.inVehicle ? 'SPACE handbrake' : 'Q weapons · E interact · F punch'}
        </div>
      </div>

      {/* ---------- quick action column (right edge) ---------- */}
      <div className="absolute right-3 top-1/2 -translate-y-1/2 flex flex-col gap-2 pointer-events-none">
        <button
          onClick={() => engine.togglePhone()}
          className="pointer-events-auto w-12 h-12 rounded-xl bg-black/55 backdrop-blur-sm border border-white/15 flex flex-col items-center justify-center active:scale-95 transition"
          title="Phone (P)"
        >
          <span className="text-lg leading-none">📱</span>
          <span className="text-[7px] font-bold text-white/60 mt-0.5">PHONE</span>
        </button>
        <button
          onClick={() => (engine.inventoryOpen = !engine.inventoryOpen)}
          className="pointer-events-auto w-12 h-12 rounded-xl bg-black/55 backdrop-blur-sm border border-white/15 flex flex-col items-center justify-center active:scale-95 transition"
          title="Inventory (TAB)"
        >
          <span className="text-lg leading-none">🎒</span>
          <span className="text-[7px] font-bold text-white/60 mt-0.5">BAG</span>
        </button>
      </div>

      {/* ---------- objective (top center) ---------- */}
      <div className="absolute top-3 left-1/2 -translate-x-1/2 bg-black/50 backdrop-blur-sm rounded-md border border-white/10 px-4 py-1.5 text-center max-w-[46vw]">
        <div className="text-[10px] tracking-widest text-amber-400/80">OBJECTIVE</div>
        <div className="text-[12px] font-semibold text-white truncate">{hud.objective}</div>
      </div>

      {/* ---------- crosshair ---------- */}
      {hud.weapon !== 'fists' && !hud.inVehicle && (
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="w-3 h-3 rounded-full border border-white/70 bg-black/20" />
        </div>
      )}

      {/* ---------- interaction prompt ---------- */}
      {hud.prompt && (
        <div className="absolute left-1/2 top-[58%] -translate-x-1/2 bg-black/70 border border-amber-400/50 rounded px-3 py-1.5 text-[12px] font-semibold text-amber-200">
          {hud.prompt}
        </div>
      )}

      {/* first-run tutorial */}
      {hints > 0 && (
        <div
          className="absolute left-1/2 bottom-16 -translate-x-1/2 bg-black/70 backdrop-blur-md border border-amber-400/30 rounded-lg px-5 py-3 text-center transition-opacity duration-1000"
          style={{ opacity: hints }}
        >
          <div className="text-[10px] tracking-[0.3em] text-amber-400/90 mb-1.5">GETTING STARTED</div>
          <div className="text-[11px] text-white/80 leading-relaxed">
            {hud.interior
              ? 'Walk to the front door of your villa and press E (or the 🚪 button) to step outside.'
              : hud.inVehicle
              ? 'W/S accelerate & reverse · A/D steer · SPACE handbrake · E to get out'
              : 'WASD move · SHIFT run · SPACE jump · E enter cars & buildings · F punch · Q weapons'}
          </div>
        </div>
      )}

      {/* fps */}
      <div className="absolute top-1/2 left-3 -translate-y-1/2 text-[9px] text-white/35 font-mono">
        {hud.fps} FPS
      </div>

      {/* map shortcut */}
      <button
        onClick={onOpenMap}
        className="pointer-events-auto absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/55 backdrop-blur-sm border border-white/10 rounded-md px-3 py-1.5 text-[11px] font-semibold tracking-wider text-white/80 hover:text-white"
      >
        🗺️ MAP (M)
      </button>
    </div>
  );
}
