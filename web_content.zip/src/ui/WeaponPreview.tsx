import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { buildWeaponModel } from '../game/models';
import { getWeapon, type AttachConfig } from '../game/data/weapons';

/** Rotating 3D preview of a weapon configuration (one WebGL context, reused across changes) */
export function WeaponPreview({ weapon, attachments, skin, className }: { weapon: string; attachments: AttachConfig; skin: string; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const ctx = useRef<{ r: THREE.WebGLRenderer; s: THREE.Scene; c: THREE.PerspectiveCamera; holder: THREE.Group; raf: number } | null>(null);

  useEffect(() => {
    const el = ref.current!; let r: THREE.WebGLRenderer;
    try { r = new THREE.WebGLRenderer({ antialias: true, alpha: true }); } catch { return; }
    r.setPixelRatio(Math.min(2, window.devicePixelRatio || 1)); r.outputColorSpace = THREE.SRGBColorSpace; r.toneMapping = THREE.ACESFilmicToneMapping;
    r.domElement.style.cssText = 'width:100%;height:100%;display:block'; el.appendChild(r.domElement);
    const s = new THREE.Scene(); const c = new THREE.PerspectiveCamera(30, 1, 0.01, 20); c.position.set(0, 0.15, 2.3); c.lookAt(0, 0, 0);
    s.add(new THREE.HemisphereLight(0xffffff, 0x303030, 1.4));
    const k = new THREE.DirectionalLight(0xffe0b0, 2.4); k.position.set(2, 3, 2); s.add(k);
    const rim = new THREE.DirectionalLight(0x80b0ff, 1.6); rim.position.set(-2, 1, -2); s.add(rim);
    const holder = new THREE.Group(); s.add(holder);
    const state = { r, s, c, holder, raf: 0 }; ctx.current = state;
    let t = 0; let last = performance.now();
    const loop = (now: number) => {
      state.raf = requestAnimationFrame(loop); const dt = Math.min(0.05, (now - last) / 1000); last = now; t += dt;
      const w = el.clientWidth, h = el.clientHeight;
      if (r.domElement.width !== Math.floor(w * r.getPixelRatio())) { r.setSize(w, h, false); c.aspect = w / Math.max(1, h); c.updateProjectionMatrix(); }
      holder.rotation.y = Math.PI / 2 + Math.sin(t * 0.6) * 0.6; holder.rotation.x = Math.sin(t * 0.4) * 0.08;
      r.render(s, c);
    };
    state.raf = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(state.raf); r.dispose(); r.forceContextLoss(); r.domElement.remove(); ctx.current = null; };
  }, []);

  useEffect(() => {
    const st = ctx.current; if (!st) return;
    st.holder.clear();
    const m = buildWeaponModel(getWeapon(weapon), attachments, skin);
    const box = new THREE.Box3().setFromObject(m.group); const size = box.getSize(new THREE.Vector3()); const center = box.getCenter(new THREE.Vector3());
    m.group.position.sub(center); const sc = 1.25 / Math.max(0.3, size.z); const g = new THREE.Group(); g.add(m.group); g.scale.setScalar(sc);
    st.holder.add(g);
  }, [weapon, JSON.stringify(attachments), skin]); // eslint-disable-line react-hooks/exhaustive-deps

  return <div ref={ref} className={className} />;
}
