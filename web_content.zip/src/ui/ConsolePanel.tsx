import React, { useState } from 'react';
import { Terminal, Trash2, Filter, Send, CheckCircle2, AlertTriangle, AlertCircle, Info } from 'lucide-react';
import { ConsoleLog } from '../types';
import { audioSystem } from '../audio/audioManager';

interface ConsolePanelProps {
  logs: ConsoleLog[];
  onClearLogs: () => void;
  onExecuteCommand: (cmd: string) => void;
}

export const ConsolePanel: React.FC<ConsolePanelProps> = ({
  logs,
  onClearLogs,
  onExecuteCommand,
}) => {
  const [filter, setFilter] = useState<'all' | 'info' | 'warn' | 'error'>('all');
  const [inputCommand, setInputCommand] = useState('');

  const filtered = logs.filter((log) => {
    if (filter === 'all') return true;
    if (filter === 'info') return log.level === 'info' || log.level === 'success';
    if (filter === 'warn') return log.level === 'warn';
    if (filter === 'error') return log.level === 'error';
    return true;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputCommand.trim()) return;
    onExecuteCommand(inputCommand.trim());
    setInputCommand('');
    audioSystem.playSound('click', { pitch: 1.5, volume: 0.2 });
  };

  return (
    <div className="flex flex-col h-full bg-[#0d1117] text-slate-300 text-xs select-none">
      {/* Console Subheader */}
      <div className="h-8 bg-[#161b22] border-b border-[#21262d] flex items-center justify-between px-3 shrink-0">
        <div className="flex items-center space-x-2">
          <Terminal className="w-3.5 h-3.5 text-cyan-400" />
          <span className="font-semibold text-[11px] text-slate-200">Terminal & Engine Output</span>
        </div>

        <div className="flex items-center space-x-2">
          {/* Filters */}
          <div className="flex items-center space-x-1 bg-[#0d1117] p-0.5 rounded border border-[#30363d] text-[10px]">
            <button
              onClick={() => setFilter('all')}
              className={`px-1.5 py-0.5 rounded ${filter === 'all' ? 'bg-cyan-950 text-cyan-300 font-bold' : 'text-slate-400'}`}
            >
              All ({logs.length})
            </button>
            <button
              onClick={() => setFilter('info')}
              className={`px-1.5 py-0.5 rounded ${filter === 'info' ? 'bg-cyan-950 text-cyan-300 font-bold' : 'text-slate-400'}`}
            >
              Info
            </button>
            <button
              onClick={() => setFilter('warn')}
              className={`px-1.5 py-0.5 rounded ${filter === 'warn' ? 'bg-amber-950 text-amber-300 font-bold' : 'text-slate-400'}`}
            >
              Warn
            </button>
            <button
              onClick={() => setFilter('error')}
              className={`px-1.5 py-0.5 rounded ${filter === 'error' ? 'bg-rose-950 text-rose-300 font-bold' : 'text-slate-400'}`}
            >
              Error
            </button>
          </div>

          <button
            onClick={onClearLogs}
            className="p-1 text-slate-400 hover:text-white rounded hover:bg-[#21262d]"
            title="Clear Console"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Logs Scroll List */}
      <div className="flex-1 overflow-y-auto p-2 font-mono text-[11px] space-y-1 divide-y divide-[#1e2530]/40">
        {filtered.length === 0 ? (
          <div className="text-slate-600 p-2">No messages logged.</div>
        ) : (
          filtered.map((log) => (
            <div key={log.id} className="pt-1 flex items-start space-x-2 leading-relaxed">
              <span className="text-slate-600 text-[9px] shrink-0 mt-0.5">[{log.timestamp}]</span>
              {log.level === 'error' && <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />}
              {log.level === 'warn' && <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />}
              {log.level === 'success' && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />}
              {log.level === 'info' && <Info className="w-3.5 h-3.5 text-sky-400 shrink-0 mt-0.5" />}
              <span
                className={`break-all ${
                  log.level === 'error'
                    ? 'text-rose-300'
                    : log.level === 'warn'
                    ? 'text-amber-300'
                    : log.level === 'success'
                    ? 'text-emerald-300'
                    : 'text-slate-300'
                }`}
              >
                {log.message}
              </span>
            </div>
          ))
        )}
      </div>

      {/* Interactive Command Prompt */}
      <form onSubmit={handleSubmit} className="h-8 bg-[#161b22] border-t border-[#21262d] flex items-center px-2">
        <span className="text-cyan-400 font-mono text-[11px] mr-2">&gt;</span>
        <input
          type="text"
          value={inputCommand}
          onChange={(e) => setInputCommand(e.target.value)}
          placeholder="Enter command (e.g. 'spawn cube', 'clear', 'help', 'play')..."
          className="flex-1 bg-transparent text-slate-200 text-[11px] font-mono focus:outline-none placeholder-slate-600"
        />
        <button type="submit" className="text-slate-400 hover:text-cyan-400 p-1">
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
};
