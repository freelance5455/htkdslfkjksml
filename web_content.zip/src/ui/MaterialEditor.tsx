import React, { useState, useEffect, useRef } from 'react';
import * as THREE from 'three';
import { Palette, Check, Sparkles, RefreshCw } from 'lucide-react';
import { MaterialData } from '../types';
import { MATERIAL_PRESETS } from '../materials/presets';
import { audioSystem } from '../audio/audioManager';

interface MaterialEditorProps {
  currentMaterial: MaterialData;
  onApplyMaterial: (mat: MaterialData) => void;
}

export const MaterialEditor: React.FC<MaterialEditorProps> = ({
  currentMaterial,
  onApplyMaterial,
}) => {
  const [mat, setMat] = useState<MaterialData>({ ...currentMaterial });
  const previewCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Sync when currentMaterial prop updates
  useEffect(() => {
    setMat({ ...currentMaterial });
  }, [currentMaterial]);

  // Mini Three.js preview sphere
  useEffect(() => {
    if (!previewCanvasRef.current) return;
    const canvas = previewCanvasRef.current;
    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    renderer.setSize(180, 180);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 100);
    camera.position.set(0, 0, 3.2);

    const light1 = new THREE.DirectionalLight(0xffffff, 2.0);
    light1.position.set(2, 3, 2);
    const light2 = new THREE.DirectionalLight(0x38bdf8, 1.0);
    light2.position.set(-2, -1, 1);
    const ambient = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(light1, light2, ambient);

    const sphereGeo = new THREE.SphereGeometry(1.0, 32, 32);

    // Procedural texture on preview sphere if enabled
    let previewMap: THREE.CanvasTexture | null = null;
    if (mat.textureType && mat.textureType !== 'none') {
      const canvasTex = document.createElement('canvas');
      canvasTex.width = 128;
      canvasTex.height = 128;
      const ctx = canvasTex.getContext('2d');
      if (ctx) {
        if (mat.textureType === 'grid') {
          ctx.fillStyle = '#0f172a';
          ctx.fillRect(0, 0, 128, 128);
          ctx.strokeStyle = '#06b6d4';
          ctx.lineWidth = 2;
          for (let i = 0; i <= 128; i += 16) {
            ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, 128); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(128, i); ctx.stroke();
          }
        } else if (mat.textureType === 'rock') {
          ctx.fillStyle = '#52525b';
          ctx.fillRect(0, 0, 128, 128);
          for (let i = 0; i < 600; i++) {
            ctx.fillStyle = `rgb(${Math.floor(70 + Math.random() * 90)},${Math.floor(70 + Math.random() * 90)},${Math.floor(70 + Math.random() * 90)})`;
            ctx.fillRect(Math.random() * 128, Math.random() * 128, 2, 2);
          }
        } else if (mat.textureType === 'wood') {
          ctx.fillStyle = '#78350f';
          ctx.fillRect(0, 0, 128, 128);
          for (let y = 0; y < 128; y += 4) {
            ctx.fillStyle = '#92400e';
            ctx.fillRect(0, y, 128, 2);
          }
        } else if (mat.textureType === 'metal') {
          ctx.fillStyle = '#94a3b8';
          ctx.fillRect(0, 0, 128, 128);
          for (let x = 0; x < 128; x += 2) {
            ctx.fillStyle = '#cbd5e1';
            ctx.fillRect(x, 0, 1, 128);
          }
        } else if (mat.textureType === 'sand') {
          ctx.fillStyle = '#d97706';
          ctx.fillRect(0, 0, 128, 128);
          for (let y = 0; y < 128; y += 6) {
            ctx.fillStyle = '#b45309';
            ctx.fillRect(0, y, 128, 2);
          }
        }
        previewMap = new THREE.CanvasTexture(canvasTex);
        previewMap.wrapS = THREE.RepeatWrapping;
        previewMap.wrapT = THREE.RepeatWrapping;
        previewMap.repeat.set(2, 2);
      }
    }

    const sphereMat = new THREE.MeshStandardMaterial({
      color: mat.baseColor,
      metalness: mat.metallic,
      roughness: mat.roughness,
      emissive: new THREE.Color(mat.emissive || '#000000'),
      emissiveIntensity: mat.emissiveIntensity || 0,
      wireframe: !!mat.wireframe,
      transparent: (mat.opacity ?? 1) < 1,
      opacity: mat.opacity ?? 1,
      map: previewMap,
    });
    const sphere = new THREE.Mesh(sphereGeo, sphereMat);
    scene.add(sphere);

    let frameId: number;
    const animate = () => {
      frameId = requestAnimationFrame(animate);
      sphere.rotation.y += 0.01;
      sphere.rotation.x += 0.005;
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(frameId);
      renderer.dispose();
    };
  }, [mat]);

  const handleApplyPreset = (preset: MaterialData) => {
    setMat(preset);
    onApplyMaterial(preset);
    audioSystem.playSound('synth_bell', { pitch: 1.5, volume: 0.3 });
  };

  const handleUpdate = (updated: Partial<MaterialData>) => {
    const next = { ...mat, ...updated };
    setMat(next);
    onApplyMaterial(next);
  };

  return (
    <div className="flex flex-col h-full bg-[#11161f] text-slate-300 text-xs p-3 space-y-4 overflow-y-auto select-none">
      <div className="flex items-center justify-between border-b border-[#21262d] pb-2">
        <div className="flex items-center space-x-2">
          <Palette className="w-4 h-4 text-cyan-400" />
          <span className="font-bold text-slate-100 text-xs tracking-wide">PBR MATERIAL LAB</span>
        </div>
        <span className="text-[10px] text-cyan-400 bg-cyan-950/80 px-1.5 py-0.5 rounded border border-cyan-800 font-mono">
          Interactive Preview
        </span>
      </div>

      {/* Real-Time Rotating Preview Sphere */}
      <div className="flex flex-col items-center bg-[#0d1117] p-3 rounded-lg border border-[#21262d]">
        <canvas ref={previewCanvasRef} className="w-[180px] h-[180px] rounded" />
        <div className="text-[11px] font-semibold text-slate-200 mt-2">{mat.name}</div>
        <div className="text-[9px] text-slate-500 font-mono">Real-time PBR Shader Preview</div>
      </div>

      {/* Parameter Sliders */}
      <div className="bg-[#161b22] p-3 rounded border border-[#21262d] space-y-3">
        <div className="text-[11px] font-semibold text-slate-200">Material Channels</div>

        {/* Color */}
        <div className="flex items-center justify-between">
          <span className="text-[10px] text-slate-400">Base Albedo</span>
          <div className="flex items-center space-x-2">
            <span className="font-mono text-[10px] text-slate-300">{mat.baseColor}</span>
            <input
              type="color"
              value={mat.baseColor}
              onChange={(e) => handleUpdate({ baseColor: e.target.value })}
              className="w-6 h-6 rounded border border-[#30363d] bg-transparent cursor-pointer"
            />
          </div>
        </div>

        {/* Metallic */}
        <div className="space-y-1">
          <div className="flex justify-between text-[10px]">
            <span className="text-slate-400">Metallic</span>
            <span className="font-mono text-cyan-400">{mat.metallic.toFixed(2)}</span>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={mat.metallic}
            onChange={(e) => handleUpdate({ metallic: parseFloat(e.target.value) })}
            className="w-full accent-cyan-500 cursor-pointer"
          />
        </div>

        {/* Roughness */}
        <div className="space-y-1">
          <div className="flex justify-between text-[10px]">
            <span className="text-slate-400">Roughness</span>
            <span className="font-mono text-cyan-400">{mat.roughness.toFixed(2)}</span>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={mat.roughness}
            onChange={(e) => handleUpdate({ roughness: parseFloat(e.target.value) })}
            className="w-full accent-cyan-500 cursor-pointer"
          />
        </div>

        {/* Emission */}
        <div className="space-y-1">
          <div className="flex justify-between text-[10px]">
            <span className="text-slate-400">Emissive Bloom</span>
            <span className="font-mono text-amber-400">{mat.emissiveIntensity.toFixed(1)}</span>
          </div>
          <div className="flex items-center space-x-2">
            <input
              type="color"
              value={mat.emissive || '#000000'}
              onChange={(e) => handleUpdate({ emissive: e.target.value })}
              className="w-6 h-6 rounded border border-[#30363d] bg-transparent cursor-pointer"
            />
            <input
              type="range"
              min="0"
              max="3"
              step="0.1"
              value={mat.emissiveIntensity}
              onChange={(e) => handleUpdate({ emissiveIntensity: parseFloat(e.target.value) })}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>
        </div>

        {/* Procedural Texture Map */}
        <div className="space-y-1">
          <div className="flex justify-between text-[10px]">
            <span className="text-slate-400">Procedural Surface Map</span>
            <span className="font-mono text-cyan-400 uppercase">{mat.textureType || 'NONE'}</span>
          </div>
          <select
            value={mat.textureType || 'none'}
            onChange={(e) => handleUpdate({ textureType: e.target.value as any })}
            className="w-full bg-[#0d1117] border border-[#30363d] rounded px-2 py-1 text-[11px] text-slate-200 focus:outline-none focus:border-cyan-500"
          >
            <option value="none">None (Smooth PBR)</option>
            <option value="grid">Grid (Cyber UV Guide)</option>
            <option value="rock">Rock (Stochastic Granular)</option>
            <option value="wood">Wood (Linear Grain)</option>
            <option value="metal">Brushed Metal (Directional)</option>
            <option value="sand">Sand (Dune Ripples)</option>
          </select>
        </div>

        {/* Opacity */}
        <div className="space-y-1">
          <div className="flex justify-between text-[10px]">
            <span className="text-slate-400">Opacity / Alpha</span>
            <span className="font-mono text-cyan-400">{((mat.opacity ?? 1) * 100).toFixed(0)}%</span>
          </div>
          <input
            type="range"
            min="0.05"
            max="1"
            step="0.05"
            value={mat.opacity ?? 1}
            onChange={(e) => handleUpdate({ opacity: parseFloat(e.target.value) })}
            className="w-full accent-cyan-500 cursor-pointer"
          />
        </div>

        {/* Wireframe Toggle */}
        <div className="flex items-center justify-between pt-1">
          <span className="text-[10px] text-slate-400">Wireframe Mesh</span>
          <button
            onClick={() => handleUpdate({ wireframe: !mat.wireframe })}
            className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
              mat.wireframe
                ? 'bg-cyan-600 text-white font-bold'
                : 'bg-[#21262d] text-slate-400 hover:text-white'
            }`}
          >
            {mat.wireframe ? 'ACTIVE' : 'DISABLED'}
          </button>
        </div>
      </div>

      {/* Preset Library */}
      <div className="space-y-2">
        <div className="text-[11px] font-semibold text-slate-200">DAVIENGINE PBR Presets</div>
        <div className="grid grid-cols-2 gap-2">
          {MATERIAL_PRESETS.map((preset) => (
            <button
              key={preset.id}
              onClick={() => handleApplyPreset(preset)}
              className="flex items-center space-x-2 bg-[#161b22] hover:bg-[#1f2633] border border-[#21262d] hover:border-cyan-600 p-2 rounded text-left transition-colors"
            >
              <div
                className="w-4 h-4 rounded-full border border-white/20 shrink-0 shadow-sm"
                style={{ backgroundColor: preset.baseColor }}
              />
              <span className="truncate text-[10px] font-medium text-slate-200">{preset.name}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
