import React, { useState } from 'react';
import {
  X,
  FolderPlus,
  Layers,
  Download,
  Upload,
  Copy,
  Check,
  Sparkles,
  HelpCircle,
  Cpu,
  Globe,
  ShieldCheck,
  Boxes,
} from 'lucide-react';
import { ProjectData, SceneData } from '../types';
import { audioSystem } from '../audio/audioManager';

interface ModalsProps {
  activeModal: 'project' | 'shortcuts' | 'about' | 'build' | null;
  onClose: () => void;
  project: ProjectData;
  onUpdateProjectName: (name: string) => void;
  onSelectScene: (sceneId: string) => void;
  onCreateScene: (name: string) => void;
  onDuplicateProject: () => void;
  onExportProject: () => void;
  onImportProject: () => void;
}

export const Modals: React.FC<ModalsProps> = ({
  activeModal,
  onClose,
  project,
  onUpdateProjectName,
  onSelectScene,
  onCreateScene,
  onDuplicateProject,
  onExportProject,
  onImportProject,
}) => {
  if (!activeModal) return null;

  const [newSceneName, setNewSceneName] = useState('');
  const [projNameInput, setProjNameInput] = useState(project.name);

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4 select-none">
      <div className="bg-[#161b22] border border-[#30363d] rounded-xl shadow-2xl w-full max-w-xl overflow-hidden flex flex-col max-h-[90vh] text-slate-200 text-xs">
        {/* Modal Header */}
        <div className="h-11 bg-[#0d1117] border-b border-[#21262d] flex items-center justify-between px-4">
          <div className="flex items-center space-x-2 font-bold text-slate-100">
            {activeModal === 'project' && <FolderPlus className="w-4 h-4 text-cyan-400" />}
            {activeModal === 'shortcuts' && <HelpCircle className="w-4 h-4 text-amber-400" />}
            {activeModal === 'about' && <Sparkles className="w-4 h-4 text-cyan-400" />}
            {activeModal === 'build' && <Boxes className="w-4 h-4 text-emerald-400" />}
            <span className="uppercase tracking-wider">
              {activeModal === 'project' && 'Project & Scene Manager'}
              {activeModal === 'shortcuts' && 'Keyboard & Touch Controls'}
              {activeModal === 'about' && 'About DAVIENGINE'}
              {activeModal === 'build' && 'Build & Export Pipeline'}
            </span>
          </div>
          <button
            onClick={() => {
              onClose();
              audioSystem.playSound('click');
            }}
            className="p-1 text-slate-400 hover:text-white rounded hover:bg-[#21262d]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 overflow-y-auto flex-1 space-y-4">
          {/* PROJECT MANAGER MODAL */}
          {activeModal === 'project' && (
            <div className="space-y-4">
              <div className="bg-[#0d1117] p-3 rounded-lg border border-[#21262d] space-y-2">
                <label className="text-[11px] font-semibold text-slate-300">Project Name</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={projNameInput}
                    onChange={(e) => setProjNameInput(e.target.value)}
                    className="flex-1 bg-[#161b22] border border-[#30363d] rounded px-2.5 py-1 text-xs text-white focus:outline-none focus:border-cyan-500"
                  />
                  <button
                    onClick={() => {
                      onUpdateProjectName(projNameInput);
                      audioSystem.playSound('synth_bell', { pitch: 1.2 });
                    }}
                    className="bg-cyan-600 hover:bg-cyan-500 text-white font-medium px-3 py-1 rounded"
                  >
                    Rename
                  </button>
                </div>
              </div>

              {/* Scenes in Project */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-[11px] font-semibold text-slate-300">
                  <span>Scenes in Project ({project.scenes.length})</span>
                </div>
                <div className="space-y-1.5 max-h-48 overflow-y-auto">
                  {project.scenes.map((s) => (
                    <div
                      key={s.id}
                      onClick={() => {
                        onSelectScene(s.id);
                        onClose();
                      }}
                      className={`flex items-center justify-between p-2 rounded cursor-pointer border transition-colors ${
                        project.currentSceneId === s.id
                          ? 'bg-cyan-950/80 border-cyan-500 text-cyan-200'
                          : 'bg-[#0d1117] border-[#21262d] hover:bg-[#1f2633] text-slate-300'
                      }`}
                    >
                      <div className="flex items-center space-x-2">
                        <Layers className="w-3.5 h-3.5 text-cyan-400" />
                        <span className="font-semibold">{s.name}</span>
                        <span className="text-[9px] text-slate-500 font-mono">({s.objects.length} objects)</span>
                      </div>
                      {project.currentSceneId === s.id && (
                        <span className="text-[10px] text-cyan-400 font-mono flex items-center gap-1">
                          <Check className="w-3 h-3" /> Active
                        </span>
                      )}
                    </div>
                  ))}
                </div>

                {/* Create Scene Input */}
                <div className="flex gap-2 pt-2">
                  <input
                    type="text"
                    placeholder="New scene title..."
                    value={newSceneName}
                    onChange={(e) => setNewSceneName(e.target.value)}
                    className="flex-1 bg-[#0d1117] border border-[#30363d] rounded px-2.5 py-1 text-xs text-white placeholder-slate-500 focus:outline-none"
                  />
                  <button
                    onClick={() => {
                      if (newSceneName.trim()) {
                        onCreateScene(newSceneName.trim());
                        setNewSceneName('');
                        audioSystem.playSound('synth_jump', { pitch: 1.4 });
                      }
                    }}
                    className="bg-[#21262d] hover:bg-[#30363d] text-slate-200 border border-[#30363d] px-3 py-1 rounded"
                  >
                    + Create Scene
                  </button>
                </div>
              </div>

              {/* Project Serialization Actions */}
              <div className="grid grid-cols-3 gap-2 pt-2 border-t border-[#21262d]">
                <button
                  onClick={onDuplicateProject}
                  className="bg-[#0d1117] hover:bg-[#1f2633] border border-[#30363d] p-2 rounded text-center text-[10px] flex items-center justify-center gap-1.5"
                >
                  <Copy className="w-3 h-3 text-cyan-400" /> Duplicate
                </button>
                <button
                  onClick={onExportProject}
                  className="bg-[#0d1117] hover:bg-[#1f2633] border border-[#30363d] p-2 rounded text-center text-[10px] flex items-center justify-center gap-1.5"
                >
                  <Download className="w-3 h-3 text-emerald-400" /> Export JSON
                </button>
                <button
                  onClick={onImportProject}
                  className="bg-[#0d1117] hover:bg-[#1f2633] border border-[#30363d] p-2 rounded text-center text-[10px] flex items-center justify-center gap-1.5"
                >
                  <Upload className="w-3 h-3 text-violet-400" /> Import JSON
                </button>
              </div>
            </div>
          )}

          {/* SHORTCUTS MODAL */}
          {activeModal === 'shortcuts' && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div className="bg-[#0d1117] p-2.5 rounded border border-[#21262d] space-y-1.5">
                  <div className="font-bold text-cyan-400">Viewport Navigation</div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Orbit Camera</span>
                    <span className="font-mono text-slate-200">Right Click Drag / 1 Finger</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Pan Camera</span>
                    <span className="font-mono text-slate-200">Middle Click / Shift + Drag</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Zoom</span>
                    <span className="font-mono text-slate-200">Mouse Wheel / 2 Finger Pinch</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Focus Object</span>
                    <span className="font-mono text-cyan-300">F key</span>
                  </div>
                </div>

                <div className="bg-[#0d1117] p-2.5 rounded border border-[#21262d] space-y-1.5">
                  <div className="font-bold text-cyan-400">Gizmo & Tools</div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Translate (Move)</span>
                    <span className="font-mono text-amber-300">W key</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Rotate</span>
                    <span className="font-mono text-amber-300">E key</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Scale</span>
                    <span className="font-mono text-amber-300">R key</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Save Scene</span>
                    <span className="font-mono text-cyan-300">Ctrl + S</span>
                  </div>
                </div>
              </div>

              <div className="bg-[#0d1117] p-2.5 rounded border border-[#21262d] space-y-1 text-[11px]">
                <div className="font-bold text-emerald-400">Game Simulation Mode</div>
                <p className="text-slate-400 leading-relaxed">
                  Press <strong>PLAY</strong> to enter runtime simulation. Control the robot character with <strong>W, A, S, D</strong> or <strong>Arrow Keys</strong>, press <strong>Space</strong> to jump. On mobile/Android 8, an on-screen analog joystick and jump button will appear automatically!
                </p>
              </div>
            </div>
          )}

          {/* ABOUT MODAL */}
          {activeModal === 'about' && (
            <div className="space-y-3">
              <div className="flex items-center space-x-3 bg-[#0d1117] p-3 rounded-lg border border-[#21262d]">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-cyan-600 to-amber-500 flex items-center justify-center font-black text-white text-lg shadow-md">
                  D
                </div>
                <div>
                  <div className="text-sm font-extrabold text-white">DAVIENGINE 0.1.0</div>
                  <div className="text-[11px] text-cyan-400">"Create Worlds. Build Anything."</div>
                </div>
              </div>

              <div className="space-y-2 text-[11px] text-slate-300 leading-relaxed">
                <p>
                  <strong>DAVIENGINE</strong> is an original 3D engine and game development studio created for game developers, worldbuilders, and 3D artists.
                </p>
                <div className="bg-[#0d1117] p-2.5 rounded border border-emerald-900/60 flex items-start space-x-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-emerald-300">Free & Unlocked Software:</span>
                    <p className="text-slate-400 text-[10px] mt-0.5">
                      DAVIENGINE is designed to remain completely free for its creators. No paywalls, no editor advertisements, and no forced recurring subscriptions.
                    </p>
                  </div>
                </div>

                <div className="bg-[#0d1117] p-2.5 rounded border border-[#21262d] space-y-1">
                  <div className="font-bold text-slate-200">Device Compatibility:</div>
                  <p className="text-slate-400 text-[10px]">
                    Includes custom WebGL 1.0 & 2.0 fallback pipelines, high-precision touch joystick support, and low-draw-call rendering, fully tested and optimized for modern PCs, tablets, and mobile phones including Android 8+ devices.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* BUILD & EXPORT MODAL */}
          {activeModal === 'build' && (
            <div className="space-y-3 text-[11px]">
              <div className="bg-[#0d1117] p-3 rounded border border-[#21262d] space-y-2">
                <div className="font-bold text-emerald-400 text-xs">HTML5 Standalone Web Player</div>
                <p className="text-slate-400">
                  Packages the complete scene data, WebGL renderer, procedural assets, and player controller into a self-contained web bundle ready for itch.io, GitHub Pages, or self-hosting.
                </p>
                <button
                  onClick={() => {
                    onExportProject();
                    audioSystem.playSound('synth_bell', { pitch: 1.3 });
                  }}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-medium py-1 px-3 rounded"
                >
                  Download Web Project Bundle
                </button>
              </div>

              <div className="bg-[#0d1117] p-3 rounded border border-[#21262d] space-y-2">
                <div className="font-bold text-cyan-400 text-xs">Android 8+ APK Container Setup</div>
                <p className="text-slate-400">
                  Configured with Capacitor / WebView wrapper target flags: minSdkVersion 26 (Android 8.0 Oreo), hardware-accelerated WebGL canvas, and responsive viewport sizing.
                </p>
                <div className="p-2 bg-[#161b22] rounded font-mono text-[10px] text-cyan-300 border border-[#30363d]">
                  &lt;uses-feature android:glEsVersion="0x00020000" android:required="true" /&gt;
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
