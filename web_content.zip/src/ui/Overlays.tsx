import { useMemo, useState } from "react";
import { FRAGMENTS, categoryLabel, familyLabel, getItemDef } from "@/data/fragments";
import { JOURNAL_SECTIONS } from "@/data/journal";
import { MAP_NODES } from "@/data/locations";
import { MISSIONS } from "@/data/missions";
import { STARS, STAR_EDGES } from "@/data/constellation";
import { journalVisible, relevantItems, fillNames } from "@/game/engine";
import { useGame } from "@/game/store";
import { setAudioVolumes } from "@/game/audio";
import { exportSave, importSave } from "@/game/save";
import { cn } from "@/lib/utils";
import { OverlayFrame, StarButton } from "./chrome";
import type { ItemCategory, QualityLevel } from "@/game/types";

export function InventoryOverlay() {
  const inventory = useGame((s) => s.inventory);
  const locationId = useGame((s) => s.locationId);
  const inspect = useGame((s) => s.inspect);
  const close = useGame((s) => s.closeModal);
  const [cat, setCat] = useState<ItemCategory | "all">("all");
  const relevant = relevantItems(locationId, inventory);
  const cats: (ItemCategory | "all")[] = ["all", "fragments", "artifacts", "keys", "symbols", "memories", "tools", "documents"];
  const items = inventory
    .map((id) => getItemDef(id))
    .filter((x): x is NonNullable<typeof x> => Boolean(x))
    .filter((x) => cat === "all" || x.category === cat);

  return (
    <OverlayFrame title="Traces" onClose={close}>
      <div className="mb-3 flex gap-1 overflow-x-auto pb-1">
        {cats.map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => setCat(c)}
            className={cn(
              "shrink-0 rounded-full px-3 py-1 text-[0.65rem] uppercase tracking-wider",
              cat === c ? "bg-lumen/15 text-lumen" : "text-fog",
            )}
          >
            {c === "all" ? "Tout" : categoryLabel(c)}
          </button>
        ))}
      </div>
      {items.length === 0 ? (
        <p className="py-8 text-center font-display italic text-fog">Rien n'a encore été recueilli.</p>
      ) : (
        <ul className="space-y-2">
          {items.map((item) => (
            <li key={item.id}>
              <button
                type="button"
                onClick={() => inspect(item.id)}
                className="flex w-full items-start gap-3 rounded-md border border-lumen/10 bg-lumen/5 p-3 text-left"
              >
                <span className="mt-0.5 w-8 text-center font-display text-lg text-silver">{item.symbol ?? "·"}</span>
                <span className="min-w-0 flex-1">
                  <span className="block text-sm text-lumen">{item.name}</span>
                  <span className="block text-xs text-fog">{item.description}</span>
                  {relevant.includes(item.id) && (
                    <span className="mt-1 block text-[0.65rem] tracking-wide text-silver/80">
                      Ce symbole vous semble familier.
                    </span>
                  )}
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </OverlayFrame>
  );
}

export function InspectOverlay() {
  const id = useGame((s) => s.inspectId);
  const inspect = useGame((s) => s.inspect);
  const [angle, setAngle] = useState(0);
  const item = id ? getItemDef(id) : undefined;
  if (!item) return null;
  const secret = "inspectSecret" in item ? item.inspectSecret : undefined;
  const showSecret = secret && angle >= secret.angleMin && angle <= secret.angleMax;
  const frag = FRAGMENTS.find((f) => f.id === item.id);

  return (
    <OverlayFrame title={item.name} onClose={() => inspect(null)}>
      <div
        className="relative mx-auto mb-4 flex h-40 w-40 items-center justify-center"
        onPointerDown={(e) => {
          const startX = e.clientX;
          const startA = angle;
          const move = (ev: PointerEvent) => setAngle((startA + (ev.clientX - startX) * 0.8 + 360) % 360);
          const up = () => {
            window.removeEventListener("pointermove", move);
            window.removeEventListener("pointerup", up);
          };
          window.addEventListener("pointermove", move);
          window.addEventListener("pointerup", up);
        }}
      >
        <div
          className="flex size-28 items-center justify-center rounded-full border border-lumen/20 bg-lumen/5 font-display text-4xl text-lumen shadow-[0_0_40px_rgba(243,239,230,0.12)]"
          style={{ transform: `rotateY(${angle}deg)` }}
        >
          {item.symbol ?? "·"}
        </div>
      </div>
      <p className="text-center text-[0.65rem] uppercase tracking-[0.18em] text-fog">Faites glisser pour tourner</p>
      <p className="mt-3 font-display text-base leading-relaxed text-mist">{item.description}</p>
      {frag && (
        <p className="mt-2 text-xs text-fog">
          {familyLabel(frag.family)} · {frag.origin} · {frag.functionApparent}
        </p>
      )}
      {showSecret && secret && (
        <p className="mt-4 border-t border-lumen/10 pt-3 font-display text-sm italic text-silver">{secret.text}</p>
      )}
    </OverlayFrame>
  );
}

export function JournalOverlay() {
  const close = useGame((s) => s.closeModal);
  const state = useGame.getState();
  const flags = useGame((s) => s.flags);
  const names = useGame((s) => s.names);
  const entries = journalVisible({ ...state, flags });
  const [section, setSection] = useState<(typeof JOURNAL_SECTIONS)[number]["id"]>("quete");
  const shown = entries.filter((e) => e.section === section);
  const missions = MISSIONS.filter((m) => !m.unlockFlag || flags[m.unlockFlag]);

  return (
    <OverlayFrame title="Journal" onClose={close} wide>
      <div className="mb-3 flex gap-1 overflow-x-auto">
        {JOURNAL_SECTIONS.map((s) => (
          <button
            key={s.id}
            type="button"
            onClick={() => setSection(s.id)}
            className={cn(
              "shrink-0 rounded-full px-3 py-1 text-[0.65rem] uppercase tracking-wider",
              section === s.id ? "bg-lumen/15 text-lumen" : "text-fog",
            )}
          >
            {s.label}
          </button>
        ))}
      </div>
      {section === "quete" && (
        <ul className="mb-4 space-y-2">
          {missions.map((m) => (
            <li key={m.id} className="border-b border-lumen/8 py-2">
              <p className={cn("text-sm", flags[m.completeFlag] ? "text-fog line-through" : "text-lumen")}>
                {fillNames(m.title, names)}
              </p>
              <p className="text-xs text-fog">{fillNames(m.description, names)}</p>
            </li>
          ))}
        </ul>
      )}
      {shown.length === 0 ? (
        <p className="py-6 text-center font-display italic text-fog">Rien n'est encore inscrit.</p>
      ) : (
        shown.map((e) => (
          <article key={e.id} className="mb-4">
            <h3 className="text-[0.7rem] uppercase tracking-[0.18em] text-fog">{fillNames(e.title, names)}</h3>
            <p className="mt-1 font-display text-base leading-relaxed text-lumen/90">{fillNames(e.text, names)}</p>
          </article>
        ))
      )}
    </OverlayFrame>
  );
}

export function MapOverlay() {
  const close = useGame((s) => s.closeModal);
  const discovered = useGame((s) => s.discovered);
  const locationId = useGame((s) => s.locationId);
  const flags = useGame((s) => s.flags);
  const travel = useGame((s) => s.travel);

  return (
    <OverlayFrame title="Carte céleste" onClose={close} wide>
      <div className="relative mx-auto aspect-[4/5] w-full overflow-hidden rounded-lg border border-lumen/10 bg-void">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_20%,rgba(40,50,80,0.35),transparent_55%)]" />
        {MAP_NODES.map((n) => {
          const known = discovered.includes(n.id) || flags[`visited_${n.id}`];
          const here = n.id === locationId;
          return (
            <button
              key={n.id}
              type="button"
              disabled={!known}
              onClick={() => known && travel(n.id)}
              style={{ left: `${n.x}%`, top: `${n.y}%` }}
              className="absolute -translate-x-1/2 -translate-y-1/2"
            >
              <span
                className={cn(
                  "block size-2 rounded-full",
                  here ? "bg-lumen shadow-[0_0_12px_white]" : known ? "bg-silver/70" : "bg-fog/20",
                )}
              />
              {known && (
                <span className="absolute left-3 top-[-2px] whitespace-nowrap text-[0.6rem] uppercase tracking-wider text-mist">
                  {n.name}
                </span>
              )}
            </button>
          );
        })}
      </div>
      <p className="mt-3 text-center text-xs text-fog">Les lieux non découverts restent sous la brume.</p>
    </OverlayFrame>
  );
}

export function ConstellationOverlay() {
  const close = useGame((s) => s.closeModal);
  const flags = useGame((s) => s.flags);
  const intensity = useGame((s) => s.starIntensity);

  return (
    <OverlayFrame title="Constellation" onClose={close} wide>
      <div className="relative mx-auto aspect-square w-full">
        <svg viewBox="0 0 100 100" className="h-full w-full">
          {STAR_EDGES.map(([a, b]) => {
            const sa = STARS.find((s) => s.id === a)!;
            const sb = STARS.find((s) => s.id === b)!;
            const on = flags[sa.unlockFlag] && flags[sb.unlockFlag];
            return (
              <line
                key={`${a}-${b}`}
                x1={sa.x}
                y1={sa.y}
                x2={sb.x}
                y2={sb.y}
                stroke="rgba(213,216,224,0.35)"
                strokeWidth={on ? 0.4 : 0}
              />
            );
          })}
          {STARS.map((s) => {
            const on = flags[s.unlockFlag];
            const i = intensity[s.id] ?? 1;
            return (
              <g key={s.id}>
                <circle cx={s.x} cy={s.y} r={on ? 1.6 : 0.7} fill={on ? `rgba(243,239,230,${0.4 + i * 0.6})` : "rgba(139,147,167,0.25)"} />
                {on && (
                  <text x={s.x + 3} y={s.y + 1.2} fontSize="3.2" fill="rgba(213,216,224,0.8)">
                    {s.name}
                  </text>
                )}
              </g>
            );
          })}
        </svg>
      </div>
    </OverlayFrame>
  );
}

export function CombineOverlay() {
  const close = useGame((s) => s.closeModal);
  const inventory = useGame((s) => s.inventory);
  const slots = useGame((s) => s.combineSlots);
  const toggle = useGame((s) => s.toggleCombine);
  const tryCombine = useGame((s) => s.tryCombine);
  const items = inventory.map((id) => getItemDef(id)).filter(Boolean);

  return (
    <OverlayFrame title="Table de résonance" onClose={close}>
      <div className="mx-auto mb-4 flex size-36 items-center justify-center rounded-full border border-dashed border-lumen/25 bg-lumen/5">
        <div className="flex gap-2">
          {slots.length === 0 && <span className="text-xs text-fog">Placez deux traces</span>}
          {slots.map((id) => (
            <span key={id} className="font-display text-lg text-lumen">
              {getItemDef(id)?.symbol}
            </span>
          ))}
        </div>
      </div>
      <StarButton variant="solid" className="mb-4 w-full" disabled={slots.length < 2} onClick={tryCombine}>
        Faire résonner
      </StarButton>
      <ul className="grid grid-cols-3 gap-2">
        {items.map((item) =>
          item ? (
            <li key={item.id}>
              <button
                type="button"
                onClick={() => toggle(item.id)}
                className={cn(
                  "flex h-20 w-full flex-col items-center justify-center rounded-md border text-xs",
                  slots.includes(item.id) ? "border-lumen/50 bg-lumen/10" : "border-lumen/10 bg-lumen/5",
                )}
              >
                <span className="font-display text-lg">{item.symbol}</span>
                <span className="px-1 text-center text-[0.6rem] text-fog">{item.name}</span>
              </button>
            </li>
          ) : null,
        )}
      </ul>
    </OverlayFrame>
  );
}

export function SettingsOverlay() {
  const close = useGame((s) => s.closeModal);
  const settings = useGame((s) => s.settings);
  const setSettings = useGame((s) => s.setSettings);
  const setQuality = useGame((s) => s.setQuality);
  const backToTitle = useGame((s) => s.backToTitle);
  const wipe = useGame((s) => s.wipe);
  const applyImported = useGame((s) => s.applyImported);
  const state = useGame.getState();

  const onVol = (key: "master" | "music" | "sfx", v: number) => {
    setSettings({ [key]: v });
    setAudioVolumes({ [key]: v });
  };

  const install = async () => {
    const deferred = (window as unknown as { deferredPrompt?: { prompt: () => Promise<void> } }).deferredPrompt;
    if (deferred) await deferred.prompt();
    else alert("Sur Android, ouvrez le menu du navigateur puis « Ajouter à l'écran d'accueil ».");
  };

  return (
    <OverlayFrame title="Réglages" onClose={close}>
      <p className="mb-2 text-[0.65rem] uppercase tracking-[0.18em] text-fog">Qualité</p>
      <div className="mb-4 grid grid-cols-3 gap-2">
        {(["high", "medium", "eco"] as QualityLevel[]).map((q) => (
          <StarButton key={q} variant={settings.quality === q ? "solid" : "ghost"} onClick={() => setQuality(q, true)}>
            {q === "high" ? "Élevé" : q === "medium" ? "Moyen" : "Économie"}
          </StarButton>
        ))}
      </div>
      {(["master", "music", "sfx"] as const).map((k) => (
        <label key={k} className="mb-3 block text-xs text-fog">
          {k === "master" ? "Volume" : k === "music" ? "Musique" : "Effets"}
          <input
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={settings[k]}
            onChange={(e) => onVol(k, Number(e.target.value))}
            className="mt-1 w-full accent-silver"
          />
        </label>
      ))}
      <label className="mb-3 block text-xs text-fog">
        Taille du texte
        <input
          type="range"
          min={0.9}
          max={1.25}
          step={0.05}
          value={settings.textScale}
          onChange={(e) => setSettings({ textScale: Number(e.target.value) })}
          className="mt-1 w-full accent-silver"
        />
      </label>
      <div className="mb-4 space-y-2 text-sm">
        <Toggle label="Réduire les animations" on={settings.reduceMotion} onChange={(v) => setSettings({ reduceMotion: v })} />
        <Toggle label="Vibrations" on={settings.vibrate} onChange={(v) => setSettings({ vibrate: v })} />
        <Toggle label="Contraste élevé" on={settings.contrast} onChange={(v) => setSettings({ contrast: v })} />
        <Toggle label="Afficher l'interface" on={settings.hudVisible} onChange={(v) => setSettings({ hudVisible: v })} />
      </div>
      <StarButton className="mb-2 w-full" onClick={install}>
        Installer l'application
      </StarButton>
      <StarButton
        className="mb-2 w-full"
        onClick={() => {
          const blob = new Blob([exportSave(state)], { type: "application/json" });
          const a = document.createElement("a");
          a.href = URL.createObjectURL(blob);
          a.download = "lost-star-save.json";
          a.click();
        }}
      >
        Exporter la sauvegarde
      </StarButton>
      <label className="mb-2 block">
        <span className="sr-only">Importer</span>
        <input
          type="file"
          accept="application/json"
          className="w-full text-xs text-fog"
          onChange={async (e) => {
            const file = e.target.files?.[0];
            if (!file) return;
            const next = importSave(await file.text());
            if (next) applyImported(next);
          }}
        />
      </label>
      <StarButton className="mb-2 w-full" onClick={backToTitle}>
        Écran-titre
      </StarButton>
      <StarButton variant="quiet" className="w-full text-destructive" onClick={wipe}>
        Effacer la progression
      </StarButton>
    </OverlayFrame>
  );
}

function Toggle({ label, on, onChange }: { label: string; on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button type="button" className="flex w-full items-center justify-between" onClick={() => onChange(!on)}>
      <span className="text-mist">{label}</span>
      <span className={cn("h-5 w-9 rounded-full border border-lumen/20 p-0.5", on && "bg-lumen/20")}>
        <span className={cn("block size-4 rounded-full bg-silver transition-transform", on && "translate-x-4")} />
      </span>
    </button>
  );
}

export function HintsOverlay() {
  const text = useGame((s) => s.hintText);
  const close = useGame((s) => s.closeModal);
  return (
    <OverlayFrame title="Écouter l'étoile" onClose={close}>
      <p className="font-display text-lg italic leading-relaxed text-lumen">{text}</p>
      <p className="mt-4 text-xs text-fog">L'étoile s'est un peu atténuée. Rien de plus.</p>
    </OverlayFrame>
  );
}

export function ResonanceOverlay() {
  const id = useGame((s) => s.dialogueId);
  const setResonance = useGame((s) => s.setResonance);
  const close = useGame((s) => s.closeModal);
  const [val, setVal] = useState("");
  const def = useMemo(() => {
    const all = [
      { id: "r_souvenir", prompt: "Quel souvenir refuses-tu d'oublier ?", placeholder: "Un lieu, une voix, une heure…" },
      { id: "r_personne", prompt: "Quelle personne aimerais-tu retrouver ?", placeholder: "Un nom, ou seulement une présence" },
      { id: "r_distance", prompt: "Quelle distance aimerais-tu pouvoir effacer ?", placeholder: "Kilomètres, années, silences…" },
      { id: "r_dire", prompt: "Qu'est-ce que tu voudrais pouvoir dire avant qu'il ne soit trop tard ?", placeholder: "Une phrase, même incomplète" },
    ];
    return all.find((r) => r.id === id);
  }, [id]);
  if (!def) return null;
  return (
    <OverlayFrame title="Résonance inconnue" onClose={close}>
      <p className="font-display text-lg text-lumen">{def.prompt}</p>
      <textarea
        value={val}
        onChange={(e) => setVal(e.target.value)}
        placeholder={def.placeholder}
        className="mt-4 h-28 w-full rounded-md border border-lumen/15 bg-void/50 p-3 text-sm text-lumen outline-none"
      />
      <StarButton variant="solid" className="mt-3 w-full" disabled={!val.trim()} onClick={() => setResonance(def.id, val.trim())}>
        Inscrire
      </StarButton>
    </OverlayFrame>
  );
}
