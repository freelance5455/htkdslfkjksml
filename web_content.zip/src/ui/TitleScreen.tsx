import { useEffect, useState } from "react";
import { loadSave } from "@/game/save";
import { useGame } from "@/game/store";
import { unlockAudio, startMusic } from "@/game/audio";
import { StarButton } from "./chrome";

export function TitleScreen() {
  const newGame = useGame((s) => s.newGame);
  const continueGame = useGame((s) => s.continueGame);
  const openAdmin = useGame((s) => s.openAdmin);
  const [hasSave, setHasSave] = useState(false);
  const [taps, setTaps] = useState(0);

  useEffect(() => {
    const s = loadSave();
    setHasSave(Boolean(s?.flags.game_started));
  }, []);

  const begin = (fn: () => void) => {
    unlockAudio();
    startMusic(1);
    fn();
  };

  return (
    <div className="absolute inset-0 z-20 flex flex-col items-center justify-end px-6 pb-16 text-center">
      <button
        type="button"
        aria-label="Étoile"
        className="absolute left-1/2 top-[18%] size-16 -translate-x-1/2"
        onClick={() => {
          const n = taps + 1;
          setTaps(n);
          if (n >= 7) openAdmin();
        }}
      />
      <p
        className="text-[0.68rem] uppercase tracking-[0.42em] text-fog"
        style={{ animation: "fade-rise 0.8s ease both" }}
      >
        Une transmission perdue
      </p>
      <h1
        className="mt-4 font-display text-5xl leading-none tracking-[0.12em] text-lumen sm:text-6xl"
        style={{ animation: "fade-rise 1s ease 0.12s both" }}
      >
        THE LOST STAR
      </h1>
      <p
        className="mt-3 font-display text-lg italic text-silver"
        style={{ animation: "fade-rise 1s ease 0.24s both" }}
      >
        La Quête de Lohen
      </p>
      <div className="mt-10 flex w-full max-w-xs flex-col gap-3" style={{ animation: "fade-rise 1s ease 0.4s both" }}>
        {hasSave && (
          <StarButton variant="solid" onClick={() => begin(continueGame)}>
            Reprendre la transmission
          </StarButton>
        )}
        <StarButton variant={hasSave ? "ghost" : "solid"} onClick={() => begin(newGame)}>
          Suivre la lumière
        </StarButton>
      </div>
      <p className="mt-8 text-[0.62rem] uppercase tracking-[0.22em] text-fog/70">Touchez pour commencer</p>
    </div>
  );
}

export function ReconnectScreen() {
  const [step, setStep] = useState(0);
  useEffect(() => {
    const t = window.setTimeout(() => setStep(1), 900);
    return () => window.clearTimeout(t);
  }, []);
  return (
    <div className="absolute inset-0 z-20 flex flex-col items-center justify-center px-8 text-center">
      <span className="mb-8 size-1.5 rounded-full bg-lumen shadow-[0_0_18px_rgba(243,239,230,0.9)]" />
      <p className="font-display text-xl text-lumen">
        {step === 0 ? "Reconnexion à la transmission…" : "Dernière synchronisation retrouvée."}
      </p>
    </div>
  );
}

export function BootScreen() {
  return (
    <div className="flex min-h-dvh items-center justify-center bg-void text-lumen">
      <div className="text-center">
        <div className="mx-auto mb-6 size-2 rounded-full bg-lumen/80 shadow-[0_0_16px_rgba(243,239,230,0.8)]" />
        <p className="text-[0.7rem] uppercase tracking-[0.3em] text-fog">Transmission</p>
      </div>
    </div>
  );
}
