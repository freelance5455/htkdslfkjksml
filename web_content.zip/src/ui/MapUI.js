export class MapUI {
  constructor(containerEl) {
    this.container = containerEl;
    this.isVisible = false;
    this.rooms = [
      { id: 'streets', name: 'Raccoon City Streets (شوارع المدينة)', status: 'EXPLORED', color: '#3a75c4', x: 100, y: 300 },
      { id: 'rpd_hall', name: 'RPD Main Hall (البهو الرئيسي)', status: 'EXPLORED', color: '#2a9d8f', x: 250, y: 300 },
      { id: 'rpd_west', name: 'West Wing Safe Room (الغرفة الآمنة)', status: 'SAVED', color: '#e9c46a', x: 250, y: 180 },
      { id: 'sewers', name: 'Underground Sewers (المجاري)', status: 'UNEXPLORED', color: '#e76f51', x: 400, y: 300 },
      { id: 'nest', name: 'NEST Secret Lab (المختبر السري)', status: 'LOCKED', color: '#f4a261', x: 550, y: 300 }
    ];
  }

  toggle() {
    this.isVisible = !this.isVisible;
    this.render();
  }

  render() {
    let el = document.getElementById('map-modal');
    if (!this.isVisible) {
      if (el) el.remove();
      return;
    }

    if (!el) {
      el = document.createElement('div');
      el.id = 'map-modal';
      el.className = 'interactive';
      el.style.cssText = `
        position: absolute;
        top: 10%;
        left: 10%;
        width: 80%;
        height: 80%;
        background: rgba(10, 15, 25, 0.95);
        border: 2px solid #5577aa;
        box-shadow: 0 0 30px rgba(0, 100, 255, 0.4);
        border-radius: 8px;
        padding: 20px;
        color: #fff;
        display: flex;
        flex-direction: column;
        z-index: 100;
      `;
      this.container.appendChild(el);
    }

    el.innerHTML = `
      <div style="display:flex; justify-between; align-items:center; border-bottom:1px solid #445577; padding-bottom:10px; margin-bottom:20px;">
        <h2 style="margin:0; color:#88ccff; font-size: 22px;">🗺️ خريطة Raccoon City & RPD Police Station</h2>
        <button id="close-map-btn" style="background:#881111; color:#fff; border:none; padding:8px 16px; font-weight:bold; cursor:pointer; border-radius:4px;">إغلاق (M)</button>
      </div>

      <div style="flex:1; position:relative; background:#080c14; border:1px solid #223355; border-radius:6px; overflow:hidden;">
        <!-- Simulated Map Blueprint -->
        <svg width="100%" height="100%" style="position:absolute; top:0; left:0;">
          <line x1="100" y1="300" x2="250" y2="300" stroke="#5588cc" stroke-width="3" stroke-dasharray="4"/>
          <line x1="250" y1="300" x2="250" y2="180" stroke="#5588cc" stroke-width="3"/>
          <line x1="250" y1="300" x2="400" y2="300" stroke="#5588cc" stroke-width="3"/>
          <line x1="400" y1="300" x2="550" y2="300" stroke="#5588cc" stroke-width="3" stroke-dasharray="4"/>
        </svg>

        ${this.rooms.map(r => `
          <div style="
            position:absolute;
            left:${r.x}px;
            top:${r.y - 40}px;
            width:120px;
            height:70px;
            background:${r.color};
            border:2px solid #fff;
            border-radius:6px;
            display:flex;
            flex-direction:column;
            justify-content:center;
            align-items:center;
            font-size:12px;
            font-weight:bold;
            text-align:center;
            padding:4px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.6);
          ">
            <span>${r.name}</span>
            <span style="font-size:10px; opacity:0.8; margin-top:4px;">[${r.status}]</span>
          </div>
        `).join('')}

        <!-- Player Location Indicator -->
        <div style="
          position:absolute;
          left:250px;
          top:290px;
          width:20px;
          height:20px;
          background:#ff3300;
          border-radius:50%;
          border:2px solid #fff;
          box-shadow: 0 0 12px #ff3300;
          animation: pulse 1s infinite alternate;
        "></div>
      </div>
    `;

    document.getElementById('close-map-btn')?.addEventListener('click', () => this.toggle());
  }
}
