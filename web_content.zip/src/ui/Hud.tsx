import { useRef, useState, type ReactNode, type PointerEvent as RPE } from "react";
import { engine } from "../game/engine";
import { LAYERS, LOCATIONS, RARITY_INFO, TREASURE_MAP, xpForLevel, locById } from "../game/data";
import { S, bagCount, curShovel, derived, hud, ui, useStore } from "../game/store";
import { CoinIcon, RarityTag, TIcon, fmt, openScreen } from "./common";

const Svg = ({ children, size = 26 }: { children: ReactNode; size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    {children}
  </svg>
);
export const Icons = {
  bag: <Svg><path d="M6 8h12l1.5 12.5H4.5L6 8z" /><path d="M9 8V6.5a3 3 0 016 0V8" /><path d="M9 13h6" /></Svg>,
  pause: <Svg><rect x="6" y="5" width="4" height="14" rx="1" fill="currentColor" /><rect x="14" y="5" width="4" height="14" rx="1" fill="currentColor" /></Svg>,
  detector: <Svg><path d="M5 20L14 8" /><ellipse cx="17" cy="6" rx="4.5" ry="2.6" transform="rotate(30 17 6)" /><path d="M3 21h6" /></Svg>,
  shovel: <Svg><path d="M18 3l3 3-3 2-2-2 2-3z" /><path d="M17 7L9 15" /><path d="M9 15l-4 1 -2 5 5-2 1-4z" fill="currentColor" fillOpacity=".35" /></Svg>,
  book: <Svg><path d="M5 4h11a3 3 0 013 3v13H8a3 3 0 01-3-3V4z" /><path d="M5 17a3 3 0 013-3h11" /></Svg>,
  shop: <Svg><path d="M4 9l1.5-5h13L20 9" /><path d="M4 9c0 1.7 1.3 2.5 2.7 2.5S9.3 10.7 9.3 9c0 1.7 1.2 2.5 2.7 2.5s2.7-.8 2.7-2.5c0 1.7 1.3 2.5 2.7 2.5S20 10.7 20 9" /><path d="M5.5 12v8h13v-8" /></Svg>,
  up: <Svg size={30}><path d="M6 14l6-6 6 6" /><path d="M6 19l6-6 6 6" /></Svg>,
  hand: <Svg size={28}><path d="M8 13V6a1.5 1.5 0 013 0v5" /><path d="M11 11V4.5a1.5 1.5 0 013 0V11" /><path d="M14 11V6a1.5 1.5 0 013 0v7" /><path d="M8 13c-1.5-1.5-3-1-3 .5 0 2 3 6 4 6.5h6c2-1 3-3 3-6" /></Svg>,
  goals: <Svg><circle cx="12" cy="12" r="8" /><circle cx="12" cy="12" r="4" /><circle cx="12" cy="12" r="0.8" fill="currentColor" /></Svg>,
  map: <Svg><path d="M3 6l6-2 6 2 6-2v14l-6 2-6-2-6 2V6z" /><path d="M9 4v14M15 6v14" /></Svg>,
};

// ---------------- Virtual joystick ----------------
function Joystick({ scale, side }: { scale: number; side: "left" | "right" }) {
  const base = useRef<HTMLDivElement>(null);
  const [k, setK] = useState({ x: 0, y: 0, on: false });
  const pid = useRef<number | null>(null);
  const size = 150 * scale;
  const upd = (e: RPE) => {
    const el = base.current!;
    const r = el.getBoundingClientRect();
    const R = r.width * 0.36;
    let dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2);
    const len = Math.hypot(dx, dy);
    if (len > R) { dx *= R / len; dy *= R / len; }
    setK({ x: dx, y: dy, on: true });
    engine.input.mx = dx / R;
    engine.input.mz = -dy / R;
  };
  const end = () => {
    pid.current = null;
    setK({ x: 0, y: 0, on: false });
    engine.input.mx = 0;
    engine.input.mz = 0;
  };
  return (
    <div
      ref={base}
      className="pointer-events-auto absolute touch-none"
      style={{ [side]: `max(14px, env(safe-area-inset-${side}))`, bottom: "max(16px, env(safe-area-inset-bottom))", width: size, height: size } as React.CSSProperties}
      onPointerDown={(e) => { (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); pid.current = e.pointerId; upd(e); }}
      onPointerMove={(e) => { if (pid.current === e.pointerId) upd(e); }}
      onPointerUp={end}
      onPointerCancel={end}
      onLostPointerCapture={end}
    >
      <div className="absolute inset-0 rounded-full" style={{ background: "radial-gradient(circle, rgba(20,14,10,.55), rgba(20,14,10,.28) 70%)", border: "2px solid rgba(255,230,180,.28)", boxShadow: "0 6px 20px rgba(0,0,0,.4)" }} />
      <div className="absolute inset-[22%] rounded-full" style={{ border: "1.5px dashed rgba(255,230,180,.2)" }} />
      <div
        className="absolute rounded-full"
        style={{
          width: size * 0.42, height: size * 0.42, left: "50%", top: "50%",
          transform: `translate(calc(-50% + ${k.x}px), calc(-50% + ${k.y}px))`,
          background: "radial-gradient(circle at 35% 30%, #fff1c2, #ffb23e 70%)",
          boxShadow: "0 4px 10px rgba(0,0,0,.5), inset 0 -4px 0 rgba(150,80,10,.45)",
          opacity: k.on ? 1 : 0.85,
        }}
      />
    </div>
  );
}

function HoldButton({ className, style, onDown, onUp, children, label }: { className?: string; style?: React.CSSProperties; onDown: () => void; onUp?: () => void; children: ReactNode; label?: string }) {
  const [down, setDown] = useState(false);
  const up = () => {
    if (down) { setDown(false); onUp?.(); }
  };
  return (
    <button
      aria-label={label}
      className={`round pointer-events-auto absolute touch-none ${down ? "down" : ""} ${className || ""}`}
      style={style}
      onPointerDown={(e) => { e.preventDefault(); (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); setDown(true); onDown(); }}
      onPointerUp={up}
      onPointerCancel={up}
      onLostPointerCapture={up}
      onContextMenu={(e) => e.preventDefault()}
    >
      {children}
    </button>
  );
}

function SideBtn({ icon, label, onClick, active, badge }: { icon: ReactNode; label: string; onClick: () => void; active?: boolean; badge?: string }) {
  const s = S.settings.ctrlScale;
  return (
    <button
      aria-label={label}
      onClick={onClick}
      className={`round pointer-events-auto relative ${active ? "!border-[#7dffb0] !bg-[radial-gradient(circle_at_35%_30%,#b9ffd0,#1d7a46_65%)]" : ""}`}
      style={{ width: 52 * s, height: 52 * s }}
    >
      {icon}
      {badge && <span className="head absolute -bottom-1 rounded-full bg-black/70 px-1.5 text-[10px]">{badge}</span>}
    </button>
  );
}

export function Hud() {
  useStore();
  const s = S.settings;
  const scale = s.ctrlScale;
  const side: "left" | "right" = s.swap ? "right" : "left";
  const other: "left" | "right" = s.swap ? "left" : "right";
  const need = xpForLevel(S.level);
  const bag = bagCount();
  const cap = derived().bag;
  const loc = locById(S.location);
  const layer = LAYERS[hud.layer];
  const sh = curShovel();
  const layerColor = loc.layerColors[hud.layer];
  const inter = ui.interact;
  const bigDig = 98 * scale;

  return (
    <div className="pointer-events-none fixed inset-0 z-10" style={{ opacity: Math.max(0.45, s.ctrlOpacity) }}>
      {/* top bar */}
      <div className="safe-t safe-l safe-r absolute left-0 right-0 top-0 flex items-start justify-between gap-2">
        <div className="flex flex-col gap-1.5">
          <div className="flex items-center gap-2">
            <div className="pill flex items-center gap-2 px-3 py-1.5">
              <CoinIcon size={22} />
              <span key={S.coins} className="head bump text-xl leading-none" style={{ color: "var(--gold)" }}>{fmt(S.coins)}</span>
            </div>
            <div className="pill flex flex-col px-3 py-1" style={{ minWidth: 86 }}>
              <div className="head flex justify-between text-sm leading-tight"><span>Lv {S.level}</span><span className="text-[11px]" style={{ color: "var(--mut)" }}>{S.xp}/{need}</span></div>
              <div className="bar mt-0.5"><i style={{ width: `${(S.xp / need) * 100}%` }} /></div>
            </div>
          </div>
          {/* depth panel */}
          <div className="pill pointer-events-none flex w-fit items-center gap-2 px-3 py-1.5">
            <div className="flex flex-col">
              <span className="text-[10px] font-extrabold uppercase leading-none tracking-wider" style={{ color: "var(--mut)" }}>Depth</span>
              <span className="head text-lg leading-tight">{hud.depth.toFixed(1)} m</span>
            </div>
            <div className="flex flex-col gap-[2px]">
              <span className="text-xs font-extrabold leading-none" style={{ color: layerColor, filter: "brightness(1.5)" }}>{layer.name}</span>
              <div className="flex gap-[2px]">
                {LAYERS.map((_, i) => (
                  <span key={i} className="h-[6px] w-[14px] rounded-sm" style={{ background: loc.layerColors[i], opacity: i === hud.layer ? 1 : 0.35, outline: i === hud.layer ? "1.5px solid #fff" : "none" }} />
                ))}
              </div>
            </div>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1.5">
          <div className="flex items-center gap-2">
            <div className="pill flex items-center gap-2 px-3 py-1.5" style={bag >= cap ? { borderColor: "#ff7a7a", boxShadow: "0 0 14px #ff5a5a88" } : undefined}>
              <span style={{ color: bag >= cap ? "#ff8f8f" : "var(--gold)" }}>{Icons.bag}</span>
              <span className="head text-lg leading-none">{bag}/{cap}</span>
            </div>
            <button className="round pointer-events-auto" style={{ width: 46 * scale, height: 46 * scale }} onClick={() => openScreen("pause")} aria-label="Pause">{Icons.pause}</button>
          </div>
          <div className="pill flex items-center gap-1.5 px-2.5 py-1 text-xs">
            <span style={{ color: s.quality === "low" ? "#ffb" : "var(--gold)" }}>{Icons.shovel}</span>
            <span className="head text-sm">{ui.detector ? "Metal Detector" : sh.name}</span>
          </div>
          {s.showFps && <div className="pill px-2 py-0.5 text-xs">{hud.fps} FPS</div>}
        </div>
      </div>

      {/* side shortcut buttons */}
      <div className={`sidebtns ${other === "right" ? "on-right" : "on-left"}`}>
        <SideBtn icon={Icons.bag} label="Inventory" onClick={() => openScreen("inventory")} badge={String(bag)} />
        <SideBtn icon={Icons.detector} label="Metal detector" active={ui.detector} onClick={() => engine.toggleDetector()} />
        <SideBtn icon={Icons.shop} label="Equipment shop" onClick={() => { ui.shopTab = "shovels"; openScreen("shop"); }} />
        <SideBtn icon={Icons.goals} label="Goals" onClick={() => openScreen("goals")} />
      </div>

      {/* detector meter */}
      {ui.detector && <DetectorMeter />}

      {/* interact hint */}
      {inter && (
        <div className="pill head absolute left-1/2 -translate-x-1/2 px-4 py-1.5 text-center text-base pop" style={{ bottom: `calc(${130 * scale}px + max(14px, env(safe-area-inset-bottom)) + ${ui.detector ? 70 : 0}px)` }}>
          {inter === "collect" ? <>Tap <b style={{ color: "var(--gold)" }}>COLLECT</b> · {ui.interactName}</> : <>Merchant nearby · tap <b style={{ color: "var(--gold)" }}>TRADE</b></>}
        </div>
      )}
      {hud.digMsg && !ui.detector && (
        <div className="pill head absolute left-1/2 -translate-x-1/2 px-4 py-1 text-sm" style={{ bottom: `calc(${210 * scale}px + max(14px, env(safe-area-inset-bottom)))`, color: "#ff9a8a", borderColor: "#ff7a6a66" }}>{hud.digMsg}</div>
      )}

      {/* controls */}
      <Joystick scale={scale} side={side} />
      <div className="absolute bottom-0" style={{ [other]: 0, width: 300 * scale, height: 260 * scale } as React.CSSProperties}>
        <HoldButton
          label="Dig"
          className="!border-[#ffd166] !text-[#fff]"
          style={{
            [other]: `calc(max(14px, env(safe-area-inset-${other})) + 4px)`, bottom: "max(16px, env(safe-area-inset-bottom))", width: bigDig, height: bigDig,
            background: hud.canDig ? "radial-gradient(circle at 35% 28%, #fff3b0, #ffa930 60%, #c66a12)" : "radial-gradient(circle at 35% 28%, #ffb0a0, #c94a3a 60%, #7a1d14)",
            color: "#3a1c05", boxShadow: "0 8px 0 rgba(120,60,10,.6), 0 12px 24px rgba(0,0,0,.5)",
          } as React.CSSProperties}
          onDown={() => { if (ui.detector) engine.toggleDetector(); engine.input.dig = true; }}
          onUp={() => { engine.input.dig = false; }}
        >
          <span className="flex flex-col items-center leading-none">
            <span style={{ transform: "scale(1.35)" }}>{Icons.shovel}</span>
            <span className="head mt-2 text-xl" style={{ textShadow: "0 1px 0 #fff8" }}>DIG</span>
          </span>
        </HoldButton>
        <HoldButton
          label="Jump"
          style={{ [other]: `calc(max(14px, env(safe-area-inset-${other})) + ${bigDig + 18}px)`, bottom: "max(22px, env(safe-area-inset-bottom))", width: 64 * scale, height: 64 * scale } as React.CSSProperties}
          onDown={() => { engine.input.jump = true; }}
        >
          {Icons.up}
        </HoldButton>
        <HoldButton
          label="Interact"
          className={inter ? "shine !border-[#7dffb0]" : "!opacity-55"}
          style={{
            [other]: `calc(max(14px, env(safe-area-inset-${other})) + ${bigDig * 0.2}px)`, bottom: `calc(max(16px, env(safe-area-inset-bottom)) + ${bigDig + 14}px)`, width: 72 * scale, height: 72 * scale,
            overflow: "hidden", background: inter ? "radial-gradient(circle at 35% 30%, #c9ffd9, #1f9a58 65%)" : undefined,
          } as React.CSSProperties}
          onDown={() => { engine.input.interact = true; }}
        >
          <span className="flex flex-col items-center leading-none">
            {Icons.hand}
            <span className="head mt-0.5 text-[11px]">{inter === "sell" ? "TRADE" : inter === "collect" ? "COLLECT" : "USE"}</span>
          </span>
        </HoldButton>
      </div>
    </div>
  );
}

function DetectorMeter() {
  const sig = hud.signal;
  const tier = hud.signalTier;
  const n = 14;
  const lit = Math.round(sig * n);
  const col = tier >= 3 ? "#ffd23f" : tier === 2 ? "#cfe3ff" : "#ff9d5c";
  const label = sig < 0.03 ? "Sweeping… no signal" : sig < 0.35 ? "Faint signal" : sig < 0.7 ? "Strong signal!" : "VERY STRONG — dig here!";
  return (
    <div className="panel pop absolute left-1/2 -translate-x-1/2 rounded-2xl px-4 py-2" style={{ bottom: "calc(max(14px, env(safe-area-inset-bottom)) + 8px)", width: "min(42vw, 340px)", ["--glow" as string]: col, animation: sig > 0.6 ? "pulseGlow .6s infinite" : undefined }}>
      <div className="mb-1 flex items-center justify-between">
        <span className="head text-sm" style={{ color: "var(--mut)" }}>METAL DETECTOR</span>
        <span className="head text-sm" style={{ color: sig > 0.03 ? col : "var(--mut)" }}>{tier >= 3 ? "GOLD-CLASS" : tier === 2 ? "SILVER-CLASS" : tier === 1 ? "BASE METAL" : ""}</span>
      </div>
      <div className="flex items-end gap-[3px]">
        {Array.from({ length: n }).map((_, i) => (
          <span key={i} className="flex-1 rounded-sm" style={{ height: 8 + i * 1.6, background: i < lit ? col : "rgba(255,255,255,.12)", boxShadow: i < lit ? `0 0 8px ${col}` : "none", transition: "background .1s" }} />
        ))}
      </div>
      <div className="head mt-1 text-center text-sm">{label}</div>
    </div>
  );
}

// ---------------- Overlays: toasts, discoveries, level-up, flash, loading ----------------
export function Overlays() {
  useStore();
  const d = ui.discovery;
  const def = d ? TREASURE_MAP[d.id] : null;
  const info = def ? RARITY_INFO[def.rarity] : null;
  const loc = locById(S.location);
  const showFlash = ui.flash && Date.now() - ui.flash < 900;
  return (
    <>
      {showFlash && <div key={ui.flash} className="pointer-events-none fixed inset-0 z-30" style={{ background: `radial-gradient(circle at 50% 40%, ${ui.flashColor}aa, transparent 70%)`, animation: "flash .9s ease-out both" }} />}
      {/* toasts */}
      <div className="pointer-events-none fixed left-1/2 z-30 flex -translate-x-1/2 flex-col items-center gap-1.5" style={{ top: "calc(max(8px, env(safe-area-inset-top)) + 118px)" }}>
        {ui.toasts.map((t) => (
          <div key={t.id} className="pill slide flex items-center gap-2 px-3.5 py-1.5" style={{ borderColor: (t.color || "#fff") + "66" }}>
            {t.rarity && <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ background: t.color, boxShadow: `0 0 8px ${t.color}` }} />}
            <div className="leading-tight">
              <div className="head text-[15px]" style={{ color: t.color || "var(--txt)" }}>{t.title}</div>
              {t.sub && <div className="text-[11px]" style={{ color: "var(--mut)" }}>{t.sub}</div>}
            </div>
          </div>
        ))}
      </div>
      {/* discovery */}
      {d && def && info && (
        <div className="pointer-events-none fixed left-1/2 z-30 -translate-x-1/2" style={{ top: "calc(max(8px, env(safe-area-inset-top)) + 150px)", width: "min(92vw, 400px)" }}>
          <div key={d.key} className="pop relative overflow-hidden rounded-3xl p-3" style={{ background: "linear-gradient(180deg, rgba(34,24,16,.94), rgba(18,12,8,.94))", border: `2px solid ${info.color}`, boxShadow: `0 0 ${def.rarity === "legendary" ? 70 : def.rarity === "rare" ? 44 : 20}px ${info.color}88, 0 12px 30px rgba(0,0,0,.5)` }}>
            {(def.rarity === "rare" || def.rarity === "legendary") && (
              <div className="absolute left-[-30%] top-[-120%] h-[340%] w-[60%] opacity-40" style={{ background: `repeating-conic-gradient(from 0deg, ${info.color}88 0 10deg, transparent 10deg 24deg)`, animation: "spin 8s linear infinite", borderRadius: "50%" }} />
            )}
            <div className="relative flex items-center gap-3">
              <div className="floaty grid h-[84px] w-[84px] flex-none place-items-center rounded-2xl" style={{ background: `radial-gradient(circle, ${info.color}44, transparent 70%)` }}>
                <TIcon id={def.id} size={84} />
              </div>
              <div className="min-w-0 flex-1">
                <div className="head flex items-center gap-2 text-xs uppercase tracking-widest" style={{ color: info.color }}>
                  {def.rarity === "legendary" ? "★ Legendary Discovery ★" : def.rarity === "rare" ? "Rare Discovery!" : "You found something!"}
                  {d.isNew && <span className="rounded bg-[#ff4d6d] px-1.5 py-[1px] text-[10px] text-white">NEW</span>}
                </div>
                <div className="head truncate text-2xl leading-tight">{def.name}</div>
                <div className="flex items-center gap-2 text-sm"><RarityTag r={def.rarity} small /><span><CoinIcon size={14} /> {fmt(def.value)}</span></div>
                <div className="mt-0.5 text-[11px]" style={{ color: "var(--mut)" }}>Walk up &amp; tap COLLECT to pick it up</div>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* level up */}
      {ui.levelUp && (
        <div className="pointer-events-none fixed left-1/2 z-30 -translate-x-1/2 text-center" style={{ top: "26%" }}>
          <div className="pop panel rounded-3xl px-8 py-4" style={{ borderColor: "var(--gold)", boxShadow: "0 0 50px #ffd16688" }}>
            <div className="head text-sm tracking-widest" style={{ color: "var(--mut)" }}>LEVEL UP</div>
            <div className="head title-gradient text-6xl leading-none">{ui.levelUp.level}</div>
            <div className="head mt-1 text-lg"><CoinIcon /> +{fmt(ui.levelUp.reward)} reward</div>
          </div>
        </div>
      )}
      {/* loading */}
      {ui.loading && (
        <div className="fixed inset-0 z-[60] grid place-items-center fade" style={{ background: `linear-gradient(180deg, ${loc.grad[0]}, ${loc.grad[1]})` }}>
          <div className="text-center">
            <div className="mx-auto mb-4 h-14 w-14 rounded-full border-4 border-white/30 border-t-white" style={{ animation: "spin .9s linear infinite" }} />
            <div className="head text-3xl" style={{ textShadow: "0 3px 0 rgba(0,0,0,.3)" }}>Travelling…</div>
          </div>
        </div>
      )}
    </>
  );
}

export { LOCATIONS };
