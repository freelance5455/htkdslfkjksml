import { useRef, useState } from "react";
import type { GameState } from "../game/engine";
import type { Action } from "../game/engine";
import { itemIcon, itemName } from "./icon";

interface Props {
  state: GameState;
  hudScale: number;
  showDebug: boolean;
  isTouch: boolean;
  onSlot: (i: number) => void;
  onTouchKey: (action: Action, down: boolean) => void;
  onLook: (dx: number, dy: number) => void;
}

export default function Hud({
  state,
  hudScale,
  showDebug,
  isTouch,
  onSlot,
  onTouchKey,
  onLook,
}: Props) {
  const [held, setHeld] = useState<string | null>(null);
  const lookRef = useRef<{ x: number; y: number } | null>(null);
  const stickRef = useRef<HTMLDivElement | null>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });

  const hearts = Math.round(state.health / 10);
  const shields = Math.round(state.armour / 10);

  const stickMove = (clientX: number, clientY: number) => {
    const el = stickRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const dx = clientX - (r.left + r.width / 2);
    const dy = clientY - (r.top + r.height / 2);
    const max = r.width / 2;
    const len = Math.min(Math.hypot(dx, dy), max);
    const ang = Math.atan2(dy, dx);
    setKnob({ x: Math.cos(ang) * len, y: Math.sin(ang) * len });
    const dead = 12;
    onTouchKey("forward", dy < -dead);
    onTouchKey("backward", dy > dead);
    onTouchKey("left", dx < -dead);
    onTouchKey("right", dx > dead);
  };

  const stickEnd = () => {
    setKnob({ x: 0, y: 0 });
    (["forward", "backward", "left", "right"] as Action[]).forEach((a) => onTouchKey(a, false));
  };

  return (
    <div className="pointer-events-none absolute inset-0 select-none">
      {/* ---------- touch look layer ---------- */}
      {isTouch && (
        <div
          className="pointer-events-auto absolute inset-0"
          onPointerDown={(e) => {
            if (e.pointerType !== "touch") return;
            lookRef.current = { x: e.clientX, y: e.clientY };
          }}
          onPointerMove={(e) => {
            if (e.pointerType !== "touch" || !lookRef.current) return;
            onLook(e.clientX - lookRef.current.x, e.clientY - lookRef.current.y);
            lookRef.current = { x: e.clientX, y: e.clientY };
          }}
          onPointerUp={() => {
            lookRef.current = null;
          }}
        />
      )}

      {/* ---------- debug ---------- */}
      {showDebug && (
        <div className="absolute left-3 top-3 bg-black/55 px-3 py-2 text-[10px] leading-[1.9] text-[#e6e0d7]">
          <div className="text-[#7ec850]">VOXELCRAFT · DEBUG (F3)</div>
          <div className="tabular-nums">
            XYZ {state.x} / {state.y} / {state.z}
          </div>
          <div className="tabular-nums">FPS {state.fps}</div>
          <div className="tabular-nums">
            HEALTH {state.health} · ARMOUR {state.armour}
          </div>
          <div className="tabular-nums">
            HELD {itemName(state.hotbar[state.slot] || "").toUpperCase()}
          </div>
          <div className="tabular-nums">
            VEHICLE {state.vehicle ? state.vehicle.toUpperCase() : "ON FOOT"}
          </div>
        </div>
      )}

      {/* ---------- coins / ammo ---------- */}
      <div className="absolute right-3 top-3 flex flex-col items-end gap-2">
        <div className="mc-slot--dark mc-slot flex items-center gap-2 px-3 py-2">
          <img src={itemIcon("coin")} alt="" className="pixelated h-5 w-5" />
          <span className="tabular-nums text-sm text-[#e8c24a] mc-shadow-sm">
            {state.coins.toLocaleString()}
          </span>
        </div>
        <div className="flex gap-2">
          <div className="mc-slot--dark mc-slot px-3 py-2 text-[10px] tabular-nums text-[#e6e0d7]">
            AMMO <span className="text-[#ffffa0]">{state.ammo}</span>
          </div>
          <div className="mc-slot--dark mc-slot px-3 py-2 text-[10px] tabular-nums text-[#e6e0d7]">
            ROCKETS <span className="text-[#ffffa0]">{state.rockets}</span>
          </div>
        </div>
      </div>

      {/* ---------- crosshair ---------- */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
        <div className="crosshair absolute -translate-x-1/2 -translate-y-1/2" style={{ width: 3, height: 17 }} />
        <div className="crosshair absolute -translate-x-1/2 -translate-y-1/2" style={{ width: 17, height: 3 }} />
      </div>

      {/* ---------- speedometer ---------- */}
      {state.vehicle && (
        <div className="absolute bottom-[300px] right-4 text-right sm:bottom-32 sm:right-8">
          <div className="font-title text-3xl tabular-nums text-white mc-shadow sm:text-5xl">
            {Math.round(state.speed)}
          </div>
          <div className="text-[9px] tracking-[0.32em] text-[#b7ada0]">KM/H</div>
          <div className="mt-2 text-[10px] tracking-[0.22em] text-[#7ec850]">
            {state.vehicle.toUpperCase()} · ALT {state.altitude}M
          </div>
        </div>
      )}

      {/* ---------- messages ---------- */}
      <div className="absolute bottom-[248px] left-3 max-w-[46vw] space-y-1 sm:bottom-32 sm:left-6">
        {state.messages.map((m) => (
          <div key={m.id} className="bg-black/45 px-2 py-1 text-[10px] text-[#ffffa0] mc-shadow-sm">
            {m.text}
          </div>
        ))}
      </div>

      {/* ---------- hotbar cluster ---------- */}
      <div
        className="absolute bottom-3 left-1/2 -translate-x-1/2 sm:bottom-5"
        style={{ transform: `translateX(-50%) scale(${hudScale})`, transformOrigin: "bottom center" }}
      >
        <div className="mb-2 flex items-end justify-between gap-4 px-1">
          <div className="flex gap-[2px]">
            {Array.from({ length: 10 }).map((_, i) => (
              <img
                key={i}
                src={itemIcon("armour")}
                alt=""
                className="pixelated h-4 w-4"
                style={{ opacity: i < shields ? 1 : 0.18 }}
              />
            ))}
          </div>
          <div className="flex gap-[2px]">
            {Array.from({ length: 10 }).map((_, i) => (
              <img
                key={i}
                src={itemIcon("heart")}
                alt=""
                className="pixelated h-4 w-4"
                style={{ opacity: i < hearts ? 1 : 0.18 }}
              />
            ))}
          </div>
        </div>

        <div className="flex gap-[3px] border-2 border-black bg-black/45 p-[3px]">
          {state.hotbar.map((item, i) => (
            <button
              key={i}
              className={`mc-slot pointer-events-auto relative flex h-[40px] w-[40px] items-center justify-center sm:h-[52px] sm:w-[52px] ${
                state.slot === i ? "mc-slot--active" : "mc-slot--dark"
              }`}
              onClick={() => onSlot(i)}
              title={item ? itemName(item) : "Empty slot"}
            >
              <span className="absolute left-[3px] top-[1px] text-[8px] text-[#b7ada0]">{i + 1}</span>
              {item && (
                <img src={itemIcon(item)} alt="" className="pixelated h-7 w-7 sm:h-9 sm:w-9" />
              )}
            </button>
          ))}
        </div>
        <div className="mt-1 text-center text-[9px] tracking-[0.28em] text-[#b7ada0]">
          {itemName(state.hotbar[state.slot] || "—").toUpperCase()}
        </div>
      </div>

      {/* ---------- touch controls ---------- */}
      {isTouch && (
        <>
          <div
            ref={stickRef}
            className="pointer-events-auto absolute bottom-24 left-5 h-32 w-32 border-2 border-white/25 bg-black/30"
            onPointerDown={(e) => {
              e.currentTarget.setPointerCapture(e.pointerId);
              stickMove(e.clientX, e.clientY);
            }}
            onPointerMove={(e) => {
              if (e.buttons || e.pointerType === "touch") stickMove(e.clientX, e.clientY);
            }}
            onPointerUp={stickEnd}
            onPointerCancel={stickEnd}
          >
            <div
              className="absolute left-1/2 top-1/2 h-12 w-12 border-2 border-white/40 bg-white/25"
              style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
            />
          </div>

          <div className="pointer-events-auto absolute bottom-24 right-5 grid grid-cols-2 gap-2">
            {(
              [
                ["jump", "JUMP"],
                ["attack", "FIRE"],
                ["use", "PLACE"],
                ["interact", "DRIVE"],
                ["fly", "FLY"],
                ["store", "SHOP"],
              ] as [Action, string][]
            ).map(([action, label]) => (
              <button
                key={action}
                className={`mc-btn h-14 w-14 text-[9px] ${held === action ? "mc-btn--grass" : ""}`}
                onPointerDown={() => {
                  setHeld(action);
                  onTouchKey(action, true);
                }}
                onPointerUp={() => {
                  setHeld(null);
                  onTouchKey(action, false);
                }}
                onPointerLeave={() => {
                  setHeld(null);
                  onTouchKey(action, false);
                }}
              >
                {label}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
