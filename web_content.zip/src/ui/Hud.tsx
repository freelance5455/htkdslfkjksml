import type { HudState } from '../game/Game';

export interface BannerState { id: number; text: string; sub?: string; kind?: string }
export interface PopupState { id: number; text: string; kind: string }

function Pips({ n, color, right }: { n: number; color: string; right?: boolean }) {
  return (
    <div className={`flex gap-1 mt-1 ${right ? 'justify-end' : 'justify-start'}`}>
      {[0, 1].map((i) => (
        <div
          key={i}
          style={{
            width: 12, height: 12, transform: 'rotate(45deg)',
            background: i < n ? color : 'transparent',
            border: `2px solid ${i < n ? color : '#555a63'}`,
            boxShadow: i < n ? `0 0 8px ${color}` : 'none',
          }}
        />
      ))}
    </div>
  );
}

function Side({ hud, idx }: { hud: HudState; idx: 0 | 1 }) {
  const hp = hud.hp[idx];
  const stam = hud.stam[idx];
  const spec = hud.spec[idx];
  const mine = hud.player === idx;
  const ada = idx === 1;
  const color = ada ? '#ff3a48' : '#6ea0ff';
  return (
    <div className="flex-1 min-w-0">
      <div className={`flex items-end gap-2 mb-0.5 ${ada ? 'flex-row-reverse text-right' : ''}`}>
        <span className="font-display text-white" style={{ fontSize: 'clamp(12px,3vh,20px)', textShadow: '0 2px 0 #000' }}>
          {ada ? 'ADA WONG' : 'LEON S. KENNEDY'}
        </span>
        <span
          className="font-display px-1.5"
          style={{ fontSize: 'clamp(8px,1.8vh,12px)', background: mine ? color : '#2a2d33', color: mine ? '#000' : '#aab' }}
        >
          {mine ? 'YOU' : 'CPU'}
        </span>
      </div>
      <div className={`hp-wrap ${ada ? 'hp-ada' : 'hp-leon'} ${hp < 25 ? 'hp-low' : ''}`}>
        <div className="hp-trail" style={{ width: `${hp}%` }} />
        <div className="hp-fill" style={{ width: `${hp}%` }} />
      </div>
      <div className="mt-1" style={{ width: '82%', marginLeft: ada ? 'auto' : 0 }}>
        <div className="mini-bar" style={{ direction: ada ? 'rtl' : 'ltr' }}>
          <div className={`stam ${stam < 25 ? 'low' : ''}`} style={{ width: `${stam}%`, marginLeft: ada ? 'auto' : 0 }} />
        </div>
        <div className="mini-bar mt-0.5" style={{ width: '75%', marginLeft: ada ? 'auto' : 0, direction: ada ? 'rtl' : 'ltr' }}>
          <div className={`spec ${spec >= 100 ? 'full' : ''}`} style={{ width: `${spec}%` }} />
        </div>
      </div>
      <Pips n={hud.wins[idx]} color={color} right={ada} />
    </div>
  );
}

export function Hud({
  hud, banner, popups, onPause, onRestart, onFs,
}: {
  hud: HudState; banner: BannerState | null; popups: PopupState[];
  onPause: () => void; onRestart: () => void; onFs: () => void;
}) {
  const comboLeft = hud.combo.who === 0;
  return (
    <div className="fixed inset-0 z-10 pointer-events-none" style={{ padding: 'max(8px, env(safe-area-inset-top)) max(12px, env(safe-area-inset-right)) 0 max(12px, env(safe-area-inset-left))' }}>
      <div className="flex items-start gap-3" style={{ maxWidth: 1100, margin: '0 auto' }}>
        <Side hud={hud} idx={0} />
        <div className="flex flex-col items-center" style={{ width: 'clamp(70px,12vw,120px)' }}>
          <div className={`timer ${hud.time <= 10 ? 'low' : ''}`}>{hud.mode === 'menu' ? '--' : hud.time}</div>
          <div className="font-display text-[10px] tracking-widest text-neutral-400">ROUND {hud.round}</div>
          <div className="flex gap-1.5 mt-1 pointer-events-auto">
            <button className="hud-icon" onClick={onPause} aria-label="Pause">❚❚</button>
            <button className="hud-icon" onClick={onRestart} aria-label="Restart">⟳</button>
            <button className="hud-icon" onClick={onFs} aria-label="Fullscreen"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 6V1h5M10 1h5v5M15 10v5h-5M6 15H1v-5"/></svg></button>
          </div>
        </div>
        <Side hud={hud} idx={1} />
      </div>

      {hud.combo.n >= 2 && (
        <div
          className="absolute"
          style={{ top: '26%', [comboLeft ? 'left' : 'right']: 'max(16px, 3vw)', textAlign: comboLeft ? 'left' : 'right' }}
        >
          <div key={hud.combo.n} className="combo" style={{ fontSize: 'clamp(32px,10vh,72px)', lineHeight: 1 }}>
            {hud.combo.n}
            <span style={{ fontSize: '0.4em', marginLeft: 6 }}>HITS</span>
          </div>
          <div className="font-display text-neutral-300" style={{ fontSize: 'clamp(10px,2.2vh,15px)', letterSpacing: '0.2em' }}>COMBO</div>
        </div>
      )}

      {hud.counter && hud.mode === 'fight' && (
        <div className="absolute left-1/2 -translate-x-1/2 font-display text-orange-400" style={{ top: '19%', fontSize: 'clamp(11px,2.6vh,18px)', letterSpacing: '0.25em', textShadow: '0 0 10px #f60' }}>
          COUNTER READY
        </div>
      )}

      <div className="absolute left-1/2 -translate-x-1/2 flex flex-col items-center gap-1" style={{ top: '30%' }}>
        {popups.map((p) => (
          <div key={p.id} className={`popup ${p.kind}`}>{p.text}</div>
        ))}
      </div>

      {banner && (
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div key={banner.id} className={`banner ${banner.kind ?? ''}`}>
            <div style={{ fontSize: 'clamp(40px,16vh,130px)', lineHeight: 1 }}>{banner.text}</div>
            {banner.sub && <div style={{ fontSize: 'clamp(12px,3.2vh,22px)', letterSpacing: '0.3em', marginTop: 6, color: '#cfd4da' }}>{banner.sub}</div>}
          </div>
        </div>
      )}
    </div>
  );
}
