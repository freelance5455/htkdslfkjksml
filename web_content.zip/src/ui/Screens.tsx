import { useState, type ReactNode } from "react";
import { engine } from "../game/engine";
import {
  ACHIEVEMENTS, LOCATIONS, RARITIES, RARITY_INFO, SHOVELS, TREASURES, TREASURE_MAP, UPGRADES, locById, upgradeCost, xpForLevel, type LocId, type Rarity,
} from "../game/data";
import {
  S, bagCount, bagValue, buyShovel, buyUpgrade, canUnlock, claimTier, derived, discoveredCount, emit, equipShovel, markDirty,
  resetAll, saveNow, sellItems, setScreen, tierComplete, toast, ui, unlockLocation, useStore,
} from "../game/store";
import { audio } from "../game/audio";
import { CoinIcon, Confirm, Inspect, RarityTag, Sheet, TIcon, closeSheet, fmt, openScreen } from "./common";
import { Icons } from "./Hud";

const LOC_NAMES: Record<string, string> = Object.fromEntries(LOCATIONS.map((l) => [l.id, l.name]));

function Stat({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="card px-3 py-1.5 text-center">
      <div className="text-[10px] font-extrabold uppercase tracking-wider" style={{ color: "var(--mut)" }}>{label}</div>
      <div className="head text-lg leading-tight">{value}</div>
    </div>
  );
}
function Tabs<T extends string>({ tabs, value, onChange }: { tabs: [T, string][]; value: T; onChange: (t: T) => void }) {
  return (
    <div className="mb-3 flex gap-2">
      {tabs.map(([k, n]) => (
        <button key={k} onClick={() => { audio.ui(); onChange(k); }} className={`btn sm flex-1 ${value === k ? "" : "ghost"}`}>{n}</button>
      ))}
    </div>
  );
}

// ---------------- Main menu ----------------
function MainMenu() {
  useStore();
  const [help, setHelp] = useState(false);
  const loc = locById(S.location);
  const play = () => {
    audio.init();
    audio.ui();
    S.played = true;
    markDirty();
    setScreen("none");
    toast(`Welcome to ${loc.name}`, "Dig anywhere outside the merchant area", loc.accent);
  };
  return (
    <div className="menu fixed inset-0 z-40 fade" style={{ padding: "max(14px, env(safe-area-inset-top)) max(16px, env(safe-area-inset-right)) max(14px, env(safe-area-inset-bottom)) max(16px, env(safe-area-inset-left))" }}>
      <div className="menu-title-box text-center">
        <div className="head title-gradient menu-title pop leading-[0.9]">DEEP DIG</div>
        <div className="head menu-sub mt-2 uppercase" style={{ color: "#ffe9bd", textShadow: "0 2px 6px #000a" }}>Treasure Digging Simulator</div>
      </div>
      <div className="menu-buttons flex w-full max-w-sm flex-col items-stretch gap-2.5">
        <div className="pill head mx-auto flex items-center gap-3 px-4 py-1 text-sm">
          <span>Lv {S.level}</span><span><CoinIcon size={15} /> {fmt(S.coins)}</span><span>{discoveredCount()}/{TREASURES.length} found</span>
        </div>
        <button className="btn shine relative overflow-hidden py-3 text-3xl" onClick={() => (S.played ? play() : setHelp(true))}>{S.played ? "CONTINUE" : "PLAY"}</button>
        <div className="flex gap-2.5">
          <button className="btn blue flex-1" onClick={() => openScreen("locations")}>Locations</button>
          <button className="btn blue flex-1" onClick={() => openScreen("book")}>Collection</button>
        </div>
        <div className="flex gap-2.5">
          <button className="btn ghost flex-1" onClick={() => setHelp(true)}>How to play</button>
          <button className="btn ghost flex-1" onClick={() => openScreen("settings")}>Settings</button>
        </div>
        <div className="text-center text-xs" style={{ color: "var(--mut)" }}>{loc.name} · Progress saves automatically</div>
      </div>
      {help && <Help onClose={() => { setHelp(false); if (!S.played) play(); }} />}
    </div>
  );
}

export function Help({ onClose }: { onClose: () => void }) {
  const tips: [string, string][] = [
    ["Move & look", "Left stick walks (push far to run). Drag anywhere on the right side to turn the camera."],
    ["DIG", "Face the glowing ring and hold DIG. Each scoop removes real sand — keep digging to make a deep hole through 7 layers."],
    ["Find treasure", "Sparkles mean something is just under the sand. When it's exposed, tap COLLECT."],
    ["Detector", "Equip the metal detector to find buried metal. Faster beeps and a taller meter mean you're close."],
    ["Sell & upgrade", "Walk to the merchant stall and tap TRADE to sell. Spend coins on shovels, upgrades and new locations."],
  ];
  return (
    <div className="fixed inset-0 z-50 grid place-items-center fade" style={{ background: "rgba(0,0,0,.7)" }}>
      <div className="panel pop scroll w-[min(94vw,760px)] rounded-3xl p-4" style={{ maxHeight: "94vh" }}>
        <h3 className="head m-0 mb-2 text-center text-3xl" style={{ color: "var(--gold)" }}>How to play</h3>
        <div className="grid gap-2 sm:grid-cols-2">
          {tips.map(([t, d], i) => (
            <div key={t} className="card flex gap-3 p-2.5">
              <div className="head grid h-8 w-8 flex-none place-items-center rounded-full bg-[#ffb23e] text-[#3a2108]">{i + 1}</div>
              <div><div className="head text-lg leading-tight">{t}</div><div className="text-sm" style={{ color: "var(--mut)" }}>{d}</div></div>
            </div>
          ))}
        </div>
        <button className="btn green mt-3 w-full py-2 text-xl" onClick={onClose}>Let's dig!</button>
      </div>
    </div>
  );
}

// ---------------- Pause ----------------
function Pause() {
  const [help, setHelp] = useState(false);
  const [saved, setSaved] = useState(false);
  const Row = ({ icon, label, onClick, cls = "" }: { icon: ReactNode; label: string; onClick: () => void; cls?: string }) => (
    <button className={`btn flex items-center justify-center gap-2 ${cls}`} onClick={() => { audio.ui(); onClick(); }}>{icon}<span>{label}</span></button>
  );
  return (
    <Sheet title="Paused" onClose={() => { audio.back(); setScreen("none"); }}>
      <div className="grid grid-cols-2 gap-3">
        <Row icon={Icons.bag} label="Inventory" cls="blue" onClick={() => openScreen("inventory", true)} />
        <Row icon={Icons.book} label="Collection" cls="blue" onClick={() => openScreen("book", true)} />
        <Row icon={Icons.shop} label="Shop" onClick={() => { ui.shopTab = "shovels"; openScreen("shop", true); }} />
        <Row icon={Icons.map} label="Locations" onClick={() => openScreen("locations", true)} />
        <Row icon={Icons.goals} label="Goals" cls="green" onClick={() => openScreen("goals", true)} />
        <Row icon={<span>⚙</span>} label="Settings" cls="ghost" onClick={() => openScreen("settings", true)} />
        <Row icon={<span>?</span>} label="How to play" cls="ghost" onClick={() => setHelp(true)} />
        <Row icon={<span>💾</span>} label={saved ? "Saved ✓" : "Save game"} cls="ghost" onClick={() => { const ok = saveNow(); setSaved(ok); toast(ok ? "Game saved" : "Save failed (storage full?)", undefined, ok ? "#7dffb0" : "#ff8f8f"); }} />
      </div>
      <button className="btn red mt-3 w-full" onClick={() => { saveNow(); setScreen("menu"); }}>Save &amp; Main menu</button>
      <button className="btn mt-3 w-full py-3 text-xl" onClick={() => { audio.back(); setScreen("none"); }}>Resume</button>
      {help && <Help onClose={() => setHelp(false)} />}
    </Sheet>
  );
}

// ---------------- Inventory ----------------
function timeAgo(t: number) {
  const s = Math.floor((Date.now() - t) / 1000);
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}
function Inventory() {
  useStore();
  const [tab, setTab] = useState<"bag" | "history">("bag");
  const [insp, setInsp] = useState<string | null>(null);
  const cap = derived().bag;
  const items = Object.entries(S.inventory)
    .map(([id, q]) => ({ def: TREASURE_MAP[id], q }))
    .sort((a, b) => RARITIES.indexOf(b.def.rarity) - RARITIES.indexOf(a.def.rarity) || b.def.value - a.def.value);
  return (
    <Sheet title="Inventory" onClose={closeSheet} wide>
      <div className="mb-3 grid grid-cols-3 gap-2">
        <Stat label="Bag" value={<span style={{ color: bagCount() >= cap ? "#ff8f8f" : undefined }}>{bagCount()} / {cap}</span>} />
        <Stat label="Bag value" value={<><CoinIcon size={15} /> {fmt(bagValue())}</>} />
        <Stat label="Coins" value={<><CoinIcon size={15} /> {fmt(S.coins)}</>} />
      </div>
      <Tabs tabs={[["bag", "Treasure bag"], ["history", "Collection history"]]} value={tab} onChange={setTab} />
      {tab === "bag" && (
        <>
          {items.length === 0 ? (
            <div className="card grid place-items-center p-8 text-center" style={{ color: "var(--mut)" }}>
              <div className="head mb-1 text-xl" style={{ color: "var(--txt)" }}>Your bag is empty</div>
              Dig up some treasure! Look for sparkles in the sand.
            </div>
          ) : (
            <div className="grid gap-2.5" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(112px, 1fr))" }}>
              {items.map(({ def, q }) => {
                const c = RARITY_INFO[def.rarity].color;
                return (
                  <button key={def.id} onClick={() => { audio.ui(); setInsp(def.id); }} className="card relative flex flex-col items-center p-2 text-center active:scale-95" style={{ borderColor: c + "88", background: `linear-gradient(180deg, ${c}22, rgba(40,28,18,.9))` }}>
                    <span className="head absolute right-1.5 top-1 rounded-full bg-black/60 px-1.5 text-sm">×{q}</span>
                    <TIcon id={def.id} size={66} />
                    <div className="head w-full truncate text-sm leading-tight">{def.name}</div>
                    <div className="text-xs" style={{ color: c }}><CoinIcon size={11} /> {fmt(def.value)}</div>
                  </button>
                );
              })}
            </div>
          )}
          <div className="mt-3 flex items-center gap-3">
            <div className="flex-1 text-xs" style={{ color: "var(--mut)" }}>Tap an item to inspect it in 3D. Sell at the merchant stall.</div>
            <button className="btn" onClick={() => { ui.shopTab = "sell"; openScreen("shop"); }}>Sell items</button>
          </div>
        </>
      )}
      {tab === "history" && (
        <div className="flex flex-col gap-1.5">
          {S.history.length === 0 && <div className="card p-6 text-center" style={{ color: "var(--mut)" }}>No finds yet.</div>}
          {S.history.map((h, i) => {
            const d = TREASURE_MAP[h.id];
            if (!d) return null;
            return (
              <button key={i} className="card flex items-center gap-3 p-1.5 text-left" onClick={() => setInsp(d.id)}>
                <TIcon id={d.id} size={42} />
                <div className="min-w-0 flex-1"><div className="head truncate text-base leading-tight">{d.name}</div><div className="text-xs" style={{ color: "var(--mut)" }}>{LOC_NAMES[h.loc]} · {timeAgo(h.t)}</div></div>
                <RarityTag r={d.rarity} small />
              </button>
            );
          })}
        </div>
      )}
      {insp && <Inspect id={insp} onClose={() => setInsp(null)} />}
    </Sheet>
  );
}

// ---------------- Collection book ----------------
function Book() {
  useStore();
  const [insp, setInsp] = useState<string | null>(null);
  const total = TREASURES.length, got = discoveredCount();
  return (
    <Sheet title="Collection Book" onClose={closeSheet} wide right={<div className="head mr-1 text-lg">{got}/{total}</div>}>
      <div className="card mb-3 p-3">
        <div className="mb-1 flex justify-between"><span className="head">Overall completion</span><span className="head" style={{ color: "var(--gold)" }}>{Math.round((got / total) * 100)}%</span></div>
        <div className="bar" style={{ height: 12 }}><i style={{ width: `${(got / total) * 100}%` }} /></div>
      </div>
      {RARITIES.map((r: Rarity) => {
        const list = TREASURES.filter((t) => t.rarity === r);
        const tc = tierComplete(r);
        const claimed = S.claimedTiers.includes("tier_" + r);
        const info = RARITY_INFO[r];
        return (
          <div key={r} className="mb-4">
            <div className="mb-1.5 flex items-center gap-2">
              <span className="head text-xl" style={{ color: info.color }}>{info.name}</span>
              <span className="text-sm" style={{ color: "var(--mut)" }}>{tc.have}/{tc.total}</span>
              <div className="flex-1" />
              {claimed ? <span className="head text-sm" style={{ color: "#7dffb0" }}>✓ Set bonus claimed</span> : (
                <button className="btn green sm" disabled={tc.have < tc.total} onClick={() => claimTier(r)}>{tc.have < tc.total ? `Set bonus ${fmt(info.bonus)}` : `Claim ${fmt(info.bonus)} coins`}</button>
              )}
            </div>
            <div className="grid gap-2" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(98px, 1fr))" }}>
              {list.map((d) => {
                const f = S.discovered[d.id];
                return (
                  <button key={d.id} onClick={() => (f ? setInsp(d.id) : toast("Undiscovered", "Found in: " + (d.locs.includes("all") ? "anywhere" : d.locs.map((l) => LOC_NAMES[l]).join(", ")), "#c9b79b"))} className="card flex flex-col items-center p-1.5 text-center active:scale-95" style={{ borderColor: f ? info.color + "77" : undefined, opacity: f ? 1 : 0.8 }}>
                    <TIcon id={d.id} size={58} dim={!f} />
                    <div className="head w-full truncate text-[13px] leading-tight">{f ? d.name : "???"}</div>
                    <div className="text-[11px]" style={{ color: "var(--mut)" }}>{f ? `Found ×${f.count}` : "Not found"}</div>
                  </button>
                );
              })}
            </div>
          </div>
        );
      })}
      {insp && <Inspect id={insp} onClose={() => setInsp(null)} />}
    </Sheet>
  );
}

// ---------------- Shop ----------------
function Shop() {
  useStore();
  const tab = ui.shopTab;
  const setTab = (t: "sell" | "shovels" | "upgrades") => { ui.shopTab = t; emit(); };
  const [sel, setSel] = useState<Set<string>>(new Set());
  const [gain, setGain] = useState<{ v: number; k: number } | null>(null);
  const [conf, setConf] = useState<null | { title: string; body: ReactNode; cost?: number; run: () => void; yes?: string }>(null);
  const items = Object.entries(S.inventory)
    .map(([id, q]) => ({ def: TREASURE_MAP[id], q }))
    .sort((a, b) => b.def.value * b.q - a.def.value * a.q);
  const selTotal = items.filter((i) => sel.has(i.def.id)).reduce((a, i) => a + i.def.value * i.q, 0);
  const near = ui.nearMerchant;
  const doSell = (ids: string[] | "all") => {
    const t = sellItems(ids);
    if (t > 0) setGain({ v: t, k: Date.now() });
    setSel(new Set());
  };
  const sellAll = () => {
    const rare = items.some((i) => i.def.rarity === "rare" || i.def.rarity === "legendary");
    if (rare) setConf({ title: "Sell everything?", body: "Your bag contains Rare or Legendary treasures. Sell them all?", cost: bagValue(), run: () => doSell("all"), yes: "Sell all" });
    else doSell("all");
  };
  return (
    <Sheet title="Merchant & Shop" onClose={closeSheet} wide right={<div className="pill head mr-1 flex items-center gap-1.5 px-3 py-1 text-lg"><CoinIcon size={18} /><span key={S.coins} className="bump">{fmt(S.coins)}</span></div>}>
      <Tabs tabs={[["sell", "Sell"], ["shovels", "Shovels"], ["upgrades", "Upgrades"]]} value={tab} onChange={setTab} />
      {tab === "sell" && (
        <div className="relative">
          {gain && <div key={gain.k} className="head pointer-events-none absolute left-1/2 top-0 z-10 -translate-x-1/2 text-4xl" style={{ color: "var(--gold)", animation: "coinPop 1.4s ease-out both", textShadow: "0 3px 0 #7a3b0a" }}>+{fmt(gain.v)}</div>}
          {!near ? (
            <div className="card p-6 text-center">
              <div className="head mb-1 text-2xl">The merchant isn't here</div>
              <div style={{ color: "var(--mut)" }}>Walk to the Treasure Buyer stall in {locById(S.location).name} and tap <b style={{ color: "var(--gold)" }}>TRADE</b> to sell your finds. You can still buy shovels and upgrades from anywhere.</div>
            </div>
          ) : items.length === 0 ? (
            <div className="card p-6 text-center"><div className="head mb-1 text-2xl">"Nothing to sell yet!"</div><div style={{ color: "var(--mut)" }}>Come back when you've dug up some treasure.</div></div>
          ) : (
            <>
              <div className="mb-2 text-sm" style={{ color: "var(--mut)" }}>"Welcome, hunter! Tap items to select them, or sell your whole bag."</div>
              <div className="flex flex-col gap-1.5">
                {items.map(({ def, q }) => {
                  const on = sel.has(def.id);
                  const c = RARITY_INFO[def.rarity].color;
                  return (
                    <div key={def.id} className="card flex items-center gap-2 p-1.5" style={{ borderColor: on ? "var(--gold)" : c + "44", background: on ? "rgba(255,200,80,.14)" : undefined }}>
                      <button className="flex min-w-0 flex-1 items-center gap-2 text-left" onClick={() => { audio.ui(); const n = new Set(sel); on ? n.delete(def.id) : n.add(def.id); setSel(n); }}>
                        <span className={`grid h-6 w-6 flex-none place-items-center rounded-md border-2 ${on ? "border-[#ffd166] bg-[#ffd166] text-black" : "border-white/30"}`}>{on ? "✓" : ""}</span>
                        <TIcon id={def.id} size={46} />
                        <div className="min-w-0"><div className="head truncate text-base leading-tight">{def.name} <span style={{ color: "var(--mut)" }}>×{q}</span></div><div className="text-xs" style={{ color: c }}>{RARITY_INFO[def.rarity].name} · <CoinIcon size={11} /> {fmt(def.value)} each</div></div>
                      </button>
                      <div className="head w-16 text-right text-lg" style={{ color: "var(--gold)" }}>{fmt(def.value * q)}</div>
                      <button className="btn sm" onClick={() => { const t = sellItems([def.id], 1); if (t) setGain({ v: t, k: Date.now() }); }}>Sell 1</button>
                    </div>
                  );
                })}
              </div>
              <div className="sticky bottom-0 mt-3 flex gap-2 rounded-2xl p-2" style={{ background: "rgba(20,14,9,.92)" }}>
                <button className="btn green flex-1" disabled={sel.size === 0} onClick={() => doSell([...sel])}>Sell selected · {fmt(selTotal)}</button>
                <button className="btn flex-1" onClick={sellAll}>Sell all · {fmt(bagValue())}</button>
              </div>
            </>
          )}
        </div>
      )}
      {tab === "shovels" && (
        <div className="grid gap-3 sm:grid-cols-2">
          {SHOVELS.map((sh) => {
            const owned = S.ownedShovels.includes(sh.id);
            const eq = S.shovel === sh.id;
            const lockedLvl = S.level < sh.level;
            const icon = engine.getShovelIcon(sh.id);
            return (
              <div key={sh.id} className="card flex gap-3 p-3" style={{ borderColor: eq ? "#7dffb0" : undefined, boxShadow: eq ? "0 0 20px #4cd06a44" : undefined }}>
                <div className="grid h-[96px] w-[84px] flex-none place-items-center rounded-xl" style={{ background: "radial-gradient(circle, rgba(255,220,150,.18), transparent 70%)" }}>
                  {icon && <img src={icon} alt={sh.name} width={96} height={96} draggable={false} style={{ width: 96, height: 96, objectFit: "contain" }} />}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="head text-lg leading-tight">{sh.name}</div>
                  <div className="mb-1.5 text-xs" style={{ color: "var(--mut)" }}>{sh.desc}</div>
                  {([["Power", sh.power / 3.1], ["Speed", sh.speed / 1.55], ["Width", sh.radius / 1.28]] as [string, number][]).map(([n, v]) => (
                    <div key={n} className="mb-[3px] flex items-center gap-2 text-[11px]"><span className="w-10" style={{ color: "var(--mut)" }}>{n}</span><div className="bar flex-1" style={{ height: 6 }}><i style={{ width: `${v * 100}%` }} /></div></div>
                  ))}
                  <div className="mt-2 flex items-center gap-2">
                    {eq ? <span className="head text-sm" style={{ color: "#7dffb0" }}>✓ Equipped</span>
                      : owned ? <button className="btn green sm" onClick={() => equipShovel(sh.id)}>Equip</button>
                      : lockedLvl ? <span className="head text-sm" style={{ color: "#ff9a8a" }}>Requires level {sh.level}</span>
                      : <button className="btn sm" disabled={S.coins < sh.price} onClick={() => setConf({ title: `Buy ${sh.name}?`, body: sh.desc, cost: sh.price, run: () => buyShovel(sh.id), yes: "Buy" })}><CoinIcon size={13} /> {fmt(sh.price)}</button>}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
      {tab === "upgrades" && (
        <div className="grid gap-3 sm:grid-cols-2">
          {UPGRADES.map((u) => {
            const lvl = S.upgrades[u.id] || 0;
            const max = lvl >= u.max;
            const cost = upgradeCost(u, lvl);
            return (
              <div key={u.id} className="card p-3">
                <div className="flex items-center justify-between"><div className="head text-lg">{u.name}</div><div className="head text-sm" style={{ color: "var(--gold)" }}>Lv {lvl}/{u.max}</div></div>
                <div className="mb-2 text-xs" style={{ color: "var(--mut)" }}>{u.desc}</div>
                <div className="mb-2 flex gap-[3px]">{Array.from({ length: u.max }).map((_, i) => <span key={i} className="h-2 flex-1 rounded-sm" style={{ background: i < lvl ? "linear-gradient(90deg,#ffd166,#ff9f43)" : "rgba(255,255,255,.12)" }} />)}</div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 text-sm"><span style={{ color: "var(--mut)" }}>{u.effect(lvl)}</span>{!max && <> → <b style={{ color: "#7dffb0" }}>{u.effect(lvl + 1)}</b></>}</div>
                  <button className="btn sm" disabled={max || S.coins < cost} onClick={() => buyUpgrade(u.id)}>{max ? "MAX" : <><CoinIcon size={13} /> {fmt(cost)}</>}</button>
                </div>
              </div>
            );
          })}
        </div>
      )}
      {conf && <Confirm title={conf.title} body={conf.body} cost={conf.cost} yes={conf.yes} onNo={() => setConf(null)} onYes={() => { conf.run(); setConf(null); }} />}
    </Sheet>
  );
}

// ---------------- Locations ----------------
function Locations() {
  useStore();
  const [conf, setConf] = useState<LocId | null>(null);
  return (
    <Sheet title="Excavation Sites" onClose={closeSheet} wide>
      <div className="grid gap-3 md:grid-cols-2">
        {LOCATIONS.map((l) => {
          const unlocked = S.unlocked.includes(l.id);
          const here = S.location === l.id;
          const lvlOk = S.level >= l.level;
          const tot = l.rarityW.reduce((a, b) => a + b, 0);
          return (
            <div key={l.id} className="relative overflow-hidden rounded-2xl p-3" style={{ background: `linear-gradient(135deg, ${l.grad[0]}cc, ${l.grad[1]}dd)`, border: here ? "2px solid #fff" : "1px solid rgba(255,255,255,.25)", boxShadow: here ? `0 0 26px ${l.accent}88` : undefined, color: "#fff", textShadow: "0 1px 3px rgba(0,0,0,.5)" }}>
              <div className="flex items-start justify-between">
                <div><div className="head text-2xl leading-tight">{l.name}</div><div className="text-sm font-bold opacity-90">{l.tagline}</div></div>
                {here && <span className="head rounded-full bg-white px-2 text-xs text-black" style={{ textShadow: "none" }}>YOU ARE HERE</span>}
              </div>
              <p className="my-2 text-sm leading-snug opacity-95">{l.desc}</p>
              <div className="mb-2 flex gap-[3px]">{l.layerColors.map((c, i) => <span key={i} className="h-3 flex-1 rounded-sm" style={{ background: c, border: "1px solid rgba(0,0,0,.3)" }} />)}</div>
              <div className="mb-2 flex items-center gap-2 text-[11px] font-bold">
                {(["common", "uncommon", "rare", "legendary"] as Rarity[]).map((r, i) => (
                  <div key={r} className="flex-1"><div className="h-1.5 rounded-full" style={{ background: RARITY_INFO[r].color, width: `${Math.max(8, (l.rarityW[i] / tot) * 100)}%`, boxShadow: "0 0 4px #000a" }} /><div className="opacity-90">{RARITY_INFO[r].name.slice(0, 3)} {Math.round((l.rarityW[i] / tot) * 100)}%</div></div>
                ))}
              </div>
              <div className="flex items-center gap-2">
                {unlocked ? (
                  <button className="btn green" disabled={here} onClick={() => engine.travel(l.id)}>{here ? "Current site" : "Travel here"}</button>
                ) : (
                  <button className="btn" disabled={!canUnlock(l.id)} onClick={() => setConf(l.id)}>Unlock · <CoinIcon size={13} /> {fmt(l.cost)}</button>
                )}
                {!unlocked && <span className="head text-sm" style={{ color: lvlOk ? "#c9ffd9" : "#ffd0c8" }}>{lvlOk ? "Level OK" : `Requires level ${l.level}`}</span>}
              </div>
            </div>
          );
        })}
      </div>
      {conf && (
        <Confirm title={`Unlock ${locById(conf).name}?`} body={locById(conf).desc} cost={locById(conf).cost} yes="Unlock" onNo={() => setConf(null)} onYes={() => { unlockLocation(conf); setConf(null); }} />
      )}
    </Sheet>
  );
}

// ---------------- Settings ----------------
function Slider({ label, value, min = 0, max = 1, step = 0.05, onChange, fmtv }: { label: string; value: number; min?: number; max?: number; step?: number; onChange: (v: number) => void; fmtv?: (v: number) => string }) {
  return (
    <label className="block">
      <div className="mb-1 flex justify-between text-sm"><span className="head">{label}</span><span style={{ color: "var(--mut)" }}>{fmtv ? fmtv(value) : Math.round(value * 100) + "%"}</span></div>
      <input type="range" className="w-full" min={min} max={max} step={step} value={value} onChange={(e) => onChange(parseFloat(e.target.value))} />
    </label>
  );
}
function Toggle({ label, on, onChange, desc }: { label: string; on: boolean; onChange: (v: boolean) => void; desc?: string }) {
  return (
    <button className="flex w-full items-center justify-between gap-3 text-left" onClick={() => { audio.ui(); onChange(!on); }}>
      <div><div className="head text-base">{label}</div>{desc && <div className="text-xs" style={{ color: "var(--mut)" }}>{desc}</div>}</div>
      <span className={`toggle ${on ? "on" : ""}`} />
    </button>
  );
}
function Settings() {
  useStore();
  const st = S.settings;
  const [confirmReset, setConfirmReset] = useState(false);
  const set = <K extends keyof typeof st>(k: K, v: (typeof st)[K], apply?: boolean) => {
    st[k] = v;
    if (apply) engine.applyQuality();
    else audio.setVolumes({ master: st.master, sfx: st.sfx, ambient: st.ambient });
    markDirty();
    emit();
  };
  return (
    <Sheet title="Settings" onClose={closeSheet}>
      <div className="flex flex-col gap-4">
        <div className="card flex flex-col gap-3 p-3">
          <div className="head text-lg" style={{ color: "var(--gold)" }}>Audio</div>
          <Slider label="Master volume" value={st.master} onChange={(v) => set("master", v)} />
          <Slider label="Sound effects" value={st.sfx} onChange={(v) => { set("sfx", v); audio.dig("dry"); }} />
          <Slider label="Ambience" value={st.ambient} onChange={(v) => set("ambient", v)} />
        </div>
        <div className="card flex flex-col gap-3 p-3">
          <div className="head text-lg" style={{ color: "var(--gold)" }}>Controls</div>
          <Slider label="Camera sensitivity" value={st.sens} min={0.3} max={2.5} step={0.1} fmtv={(v) => v.toFixed(1) + "×"} onChange={(v) => set("sens", v)} />
          <Slider label="Button & joystick size" value={st.ctrlScale} min={0.7} max={1.5} step={0.05} fmtv={(v) => Math.round(v * 100) + "%"} onChange={(v) => set("ctrlScale", v)} />
          <Slider label="Control opacity" value={st.ctrlOpacity} min={0.45} max={1} step={0.05} onChange={(v) => set("ctrlOpacity", v)} />
          <Toggle label="Swap sides" desc="Joystick on the right, action buttons on the left" on={st.swap} onChange={(v) => set("swap", v)} />
          <Toggle label="Invert camera Y" on={st.invertY} onChange={(v) => set("invertY", v)} />
          <Toggle label="Vibration" desc="Haptic feedback on dig & discoveries" on={st.haptics} onChange={(v) => set("haptics", v)} />
        </div>
        <div className="card flex flex-col gap-3 p-3">
          <div className="head text-lg" style={{ color: "var(--gold)" }}>Graphics</div>
          <div className="grid grid-cols-4 gap-2">
            {(["auto", "low", "med", "high"] as const).map((q) => (
              <button key={q} className={`btn sm ${st.quality === q ? "" : "ghost"}`} onClick={() => set("quality", q, true)}>{q === "med" ? "Medium" : q[0].toUpperCase() + q.slice(1)}</button>
            ))}
          </div>
          <div className="text-xs" style={{ color: "var(--mut)" }}>Auto adapts resolution to keep a smooth frame rate on your device.</div>
          <Toggle label="Shadows" on={st.shadows} onChange={(v) => set("shadows", v, true)} />
          <Toggle label="Show FPS" on={st.showFps} onChange={(v) => set("showFps", v)} />
        </div>
        <div className="card flex flex-col gap-2 p-3">
          <div className="head text-lg" style={{ color: "var(--gold)" }}>Save data</div>
          <button className="btn green" onClick={() => { const ok = saveNow(); toast(ok ? "Game saved" : "Save failed", undefined, ok ? "#7dffb0" : "#ff8f8f"); }}>Save now</button>
          <button className="btn red" onClick={() => setConfirmReset(true)}>Reset all progress…</button>
          <div className="text-xs" style={{ color: "var(--mut)" }}>Progress saves automatically. A backup copy is kept if you reset.</div>
        </div>
      </div>
      {confirmReset && <Confirm title="Reset everything?" body="This will delete your coins, upgrades, collection and excavations. A backup is stored in your browser." yes="Reset" onNo={() => setConfirmReset(false)} onYes={() => resetAll()} />}
    </Sheet>
  );
}

// ---------------- Goals ----------------
function Goals() {
  useStore();
  const need = xpForLevel(S.level);
  const labels: Record<string, (n: number) => string> = {
    digs: (n) => `Dig ${n} scoops`, items: (n) => `Collect ${n} treasures`, depth: (n) => `Reach ${n} m deep`,
    earn: (n) => `Earn ${n} coins selling`, rare: (n) => `Find ${n} Uncommon+ treasure${n > 1 ? "s" : ""}`,
  };
  return (
    <Sheet title="Goals & Achievements" onClose={closeSheet} wide>
      <div className="card mb-3 flex items-center gap-4 p-3">
        <div className="head title-gradient text-5xl">{S.level}</div>
        <div className="flex-1"><div className="head">Player level</div><div className="bar mt-1" style={{ height: 10 }}><i style={{ width: `${(S.xp / need) * 100}%` }} /></div><div className="mt-0.5 text-xs" style={{ color: "var(--mut)" }}>{S.xp} / {need} XP · finding new treasure earns double XP</div></div>
      </div>
      <div className="head mb-1.5 text-xl" style={{ color: "var(--gold)" }}>Daily goals</div>
      <div className="mb-4 grid gap-2 sm:grid-cols-3">
        {S.daily.goals.map((g, i) => (
          <div key={i} className="card p-2.5" style={{ borderColor: g.done ? "#7dffb0" : undefined }}>
            <div className="head text-base leading-tight">{labels[g.type](g.target)}</div>
            <div className="bar my-1.5"><i style={{ width: `${Math.min(100, (g.progress / g.target) * 100)}%` }} /></div>
            <div className="flex justify-between text-xs"><span style={{ color: "var(--mut)" }}>{g.type === "depth" ? g.progress.toFixed(1) : Math.floor(g.progress)} / {g.target}</span><span style={{ color: g.done ? "#7dffb0" : "var(--gold)" }}>{g.done ? "✓ Done" : <><CoinIcon size={11} /> {g.reward}</>}</span></div>
          </div>
        ))}
      </div>
      <div className="head mb-1.5 text-xl" style={{ color: "var(--gold)" }}>Lifetime stats</div>
      <div className="mb-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
        <Stat label="Scoops dug" value={fmt(S.stats.digs)} />
        <Stat label="Earth moved" value={`${S.stats.sandDug.toFixed(1)} m³`} />
        <Stat label="Max depth" value={`${S.stats.maxDepth.toFixed(1)} m`} />
        <Stat label="Treasures" value={fmt(S.stats.items)} />
        <Stat label="Coins earned" value={fmt(S.stats.coinsEarned)} />
        <Stat label="Rare finds" value={S.stats.rare} />
        <Stat label="Legendary" value={S.stats.legendary} />
        <Stat label="Collection" value={`${discoveredCount()}/${TREASURES.length}`} />
      </div>
      <div className="head mb-1.5 text-xl" style={{ color: "var(--gold)" }}>Achievements <span className="text-sm" style={{ color: "var(--mut)" }}>{S.achievements.length}/{ACHIEVEMENTS.length}</span></div>
      <div className="grid gap-2 sm:grid-cols-2">
        {ACHIEVEMENTS.map((a) => {
          const done = S.achievements.includes(a.id);
          return (
            <div key={a.id} className="card flex items-center gap-3 p-2" style={{ opacity: done ? 1 : 0.7, borderColor: done ? "var(--gold)" : undefined }}>
              <div className="grid h-10 w-10 flex-none place-items-center rounded-full text-xl" style={{ background: done ? "linear-gradient(180deg,#ffe08a,#ffb23e)" : "rgba(255,255,255,.08)", color: "#3a2108" }}>{done ? "★" : "☆"}</div>
              <div className="min-w-0 flex-1"><div className="head text-base leading-tight">{a.name}</div><div className="text-xs" style={{ color: "var(--mut)" }}>{a.desc}</div></div>
              <div className="head text-sm" style={{ color: "var(--gold)" }}><CoinIcon size={12} /> {fmt(a.reward)}</div>
            </div>
          );
        })}
      </div>
    </Sheet>
  );
}

export function Screens() {
  useStore();
  switch (ui.screen) {
    case "menu": return <MainMenu />;
    case "pause": return <Pause />;
    case "inventory": return <Inventory />;
    case "book": return <Book />;
    case "shop": return <Shop />;
    case "locations": return <Locations />;
    case "settings": return <Settings />;
    case "goals": return <Goals />;
    default: return null;
  }
}
