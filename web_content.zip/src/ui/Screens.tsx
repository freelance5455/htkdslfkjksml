import { useState } from 'react';
import { Screen, Panel, MenuButton, Choice, Toggle, useStore, LockBadge } from './common';
import { MODES, MAP_NAMES, MAP_DESC, DIFFICULTIES, OPERATORS, levelFromXp, LEVEL_CAP, type ModeId, type MapId, type Difficulty } from '../game/data/content';
import { WEAPONS, SKINS, ATTACHMENTS, getWeapon } from '../game/data/weapons';
import { store, missionProgress } from '../game/save';
import { audio } from '../game/audio';
import { cn } from '../utils/cn';

export interface DeployOptions { mode: ModeId; map: MapId; difficulty: Difficulty; brZone: boolean }

// ------------------------------------------------------------ MODE SELECT
export function ModeSelect({ initial, onBack, onDeploy, onLoadout }: { initial: ModeId; onBack: () => void; onDeploy: (o: DeployOptions) => void; onLoadout: () => void }) {
  const s = useStore();
  const [mode, setMode] = useState<ModeId>(initial);
  const md = MODES.find(m => m.id === mode)!;
  const [map, setMap] = useState<MapId>(md.maps[0]);
  const diff = s.settings.gameplay.difficulty;
  const zone = s.settings.gameplay.brZone;
  const pick = (m: ModeId) => { setMode(m); const d = MODES.find(x => x.id === m)!; if (!d.maps.includes(map)) setMap(d.maps[0]); };
  const lo = s.profile.loadouts[s.profile.activeLoadout];
  return (
    <Screen title="SELECT OPERATION" subtitle="ALL MODES RUN LOCALLY ON THIS DEVICE" onBack={onBack}>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3 mb-3">
        {MODES.map(m => (
          <button key={m.id} onClick={() => { audio.ui('select'); pick(m.id); }} className={cn('text-left p-3 sm:p-4 clip-corner border transition-all', m.id === mode ? 'bg-amber-op/15 border-amber-op' : 'bg-black/50 border-white/10 hover:border-white/40')}>
            <div className="text-[9px] tracking-[0.3em] text-green-400/90">{m.status}</div>
            <div className="text-sm sm:text-lg font-black tracking-[0.15em] mt-1">{m.name}</div>
            <div className="text-[10px] sm:text-xs text-white/55 mt-1 leading-snug hidden sm:block">{m.desc}</div>
          </button>
        ))}
      </div>
      <div className="grid md:grid-cols-[1fr_320px] gap-3">
        <Panel title="MISSION PARAMETERS" className="p-3 sm:p-4 pt-1">
          <p className="text-xs text-white/60 mb-2 sm:hidden">{md.desc}</p>
          <Choice label="Map" value={map} options={md.maps.map(m => ({ v: m, l: MAP_NAMES[m] }))} onChange={setMap} note={MAP_DESC[map]} />
          {mode !== 'range' && <Choice label="Difficulty" value={diff} options={DIFFICULTIES.map(d => ({ v: d.id, l: d.name }))} onChange={v => store.setSettings(x => { x.gameplay.difficulty = v; return x; })} />}
          {mode === 'br' && <Toggle label="Shrinking zone" value={zone} onChange={v => store.setSettings(x => { x.gameplay.brZone = v; return x; })} note="Disable for a free-roam elimination match" />}
          <div className="text-[10px] text-white/40 mt-2 leading-relaxed">
            {mode === 'br' && 'Opponent count scales with your graphics preset (9–21 AI operators). Online 100-player matches are not available — no server infrastructure is deployed.'}
            {mode === 'tdm' && 'Squads of 4–6 per side depending on graphics preset. Allies and enemies are AI-controlled.'}
            {mode === 'combat' && 'Five waves, increasing hostile counts. Ammo drops from eliminated enemies; resupply between waves.'}
            {mode === 'range' && 'Unlimited ammunition. Use the in-range Armory to swap to any unlocked weapon and attachment set.'}
          </div>
        </Panel>
        <Panel title="LOADOUT" className="p-3 sm:p-4 pt-1">
          <div className="text-sm font-bold tracking-widest">{lo.name}</div>
          <div className="text-xs text-white/60 mt-1">{mode === 'br' ? 'BR: you drop with a P-01 Sidekick and loot the rest.' : `${getWeapon(lo.primary.weapon).name} · ${getWeapon(lo.secondary.weapon).name}`}</div>
          <div className="flex gap-2 mt-3">
            <MenuButton small onClick={onLoadout}>Edit loadout</MenuButton>
          </div>
          <button onClick={() => { audio.ui('select'); onDeploy({ mode, map, difficulty: diff, brZone: zone }); }} className="mt-4 w-full anim-glow clip-corner bg-amber-op hover:bg-amber-300 text-black py-3 font-black tracking-[0.3em] text-base">▶ DEPLOY</button>
        </Panel>
      </div>
    </Screen>
  );
}

// ------------------------------------------------------------ MULTIPLAYER
export function Multiplayer({ onBack, onTdm }: { onBack: () => void; onTdm: (map: MapId) => void }) {
  const s = useStore(); const [name, setName] = useState(s.profile.name);
  return (
    <Screen title="MULTIPLAYER" subtitle="NETWORK STATUS: OFFLINE — NO GAME SERVER DEPLOYED" onBack={onBack}>
      <div className="grid md:grid-cols-2 gap-3">
        <Panel title="LOCAL TEAM DEATHMATCH (VS AI)" className="p-4 pt-1">
          <p className="text-xs text-white/65 leading-relaxed">Two squads with respawns and a score limit, fully playable offline. Your teammates and opponents are AI soldiers — this is <b>not</b> online play.</p>
          <div className="flex flex-wrap gap-2 mt-3">
            <MenuButton primary onClick={() => onTdm('iron')}>TDM · Iron District</MenuButton>
            <MenuButton onClick={() => onTdm('dust')}>TDM · Dust Frontier</MenuButton>
          </div>
        </Panel>
        <Panel title="ONLINE MATCHMAKING" className="p-4 pt-1">
          <div className="flex items-center gap-2 text-xs"><span className="w-2 h-2 rounded-full bg-red-500 anim-blink" /> <span className="text-red-300 tracking-widest">UNAVAILABLE</span></div>
          <p className="text-xs text-white/65 leading-relaxed mt-2">Real online play needs an authoritative game server (validating movement, ammunition, damage and eliminations), a lobby/matchmaking service and hosting. None of these are deployed for this build, so online play is disabled rather than faked with bots.</p>
          <MenuButton disabled className="mt-3" status="Requires server">Find Online Match</MenuButton>
        </Panel>
        <Panel title="OPERATOR CALLSIGN" className="p-4 pt-1">
          <div className="flex gap-2 items-center">
            <input type="text" maxLength={16} value={name} onChange={e => setName(e.target.value.toUpperCase().replace(/[^A-Z0-9_ -]/g, ''))} className="flex-1 bg-black/60 border border-white/20 px-3 py-2 text-sm tracking-widest outline-none focus:border-amber-op" />
            <MenuButton small onClick={() => store.setProfile(p => { p.name = name.trim() || 'OPERATOR'; return p; })}>Save</MenuButton>
          </div>
          <p className="text-[10px] text-white/40 mt-2">Shown in kill feeds and the local high-score table.</p>
        </Panel>
        <Panel title="ARCHITECTURE NOTES" className="p-4 pt-1 text-[11px] text-white/55 leading-relaxed">
          Gameplay events in this build already flow through single entry points (fire → trace → damage → kill), which is where an authoritative server would validate them. Progress shown here is <b>local only</b> and kept separate from any future server-verified progression.
        </Panel>
      </div>
    </Screen>
  );
}

// ------------------------------------------------------------ OPERATORS
export function Operators({ onBack }: { onBack: () => void }) {
  const s = useStore(); const lvl = s.level;
  return (
    <Screen title="OPERATORS" subtitle="SELECTED OPERATOR APPEARS IN THE MENU AND ON YOUR FIRST-PERSON ARMS" onBack={onBack}>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-2 sm:gap-3 max-w-3xl">
        {OPERATORS.map(o => {
          const locked = lvl < o.unlock; const sel = s.profile.operator === o.id;
          return (
            <button key={o.id} disabled={locked} onClick={() => { audio.ui('select'); store.setProfile(p => { p.operator = o.id; return p; }); }}
              className={cn('text-left p-3 clip-corner border transition-all relative', sel ? 'border-amber-op bg-amber-op/10' : 'border-white/10 bg-black/60 hover:border-white/40', locked && 'opacity-50')}>
              <div className="flex gap-1 mb-2">{[o.uniform, o.vest, o.helmet, o.accent].map((c, i) => <span key={i} className="w-5 h-5" style={{ background: '#' + c.toString(16).padStart(6, '0') }} />)}</div>
              <div className="text-base sm:text-lg font-black tracking-[0.2em]">{o.name}</div>
              <div className="text-[10px] tracking-[0.25em] text-amber-op">{o.role.toUpperCase()}</div>
              <div className="text-[11px] text-white/55 mt-1 leading-snug hidden sm:block">{o.bio}</div>
              <div className="absolute top-2 right-2">{locked ? <LockBadge level={o.unlock} /> : sel ? <span className="text-[9px] font-bold bg-amber-op text-black px-1.5 py-0.5">EQUIPPED</span> : null}</div>
            </button>
          );
        })}
      </div>
    </Screen>
  );
}

// ------------------------------------------------------------ MISSIONS
export function Missions({ onBack }: { onBack: () => void }) {
  const s = useStore(); const ms = missionProgress(s.profile);
  const claim = (id: string, xp: number) => { audio.pickup(); store.setProfile(p => { if (!p.claimed.includes(id)) { p.claimed.push(id); p.xp += xp; } return p; }); };
  return (
    <Screen title="MISSIONS" subtitle={`${ms.filter(m => m.claimed).length} / ${ms.length} COMPLETED`} onBack={onBack}>
      <div className="grid md:grid-cols-2 gap-2 max-w-5xl">
        {ms.map(m => (
          <Panel key={m.id} className="p-3 flex items-center gap-3">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2"><span className="font-black tracking-[0.15em] text-sm">{m.name.toUpperCase()}</span><span className="text-[10px] text-amber-op font-bold">+{m.xp} XP</span></div>
              <div className="text-[11px] text-white/55">{m.desc}</div>
              <div className="mt-1.5 h-1.5 bg-white/10"><div className={cn('h-full', m.done ? 'bg-green-400' : 'bg-amber-op')} style={{ width: `${(m.value / m.target) * 100}%` }} /></div>
              <div className="text-[9px] text-white/40 mt-0.5 tabular-nums">{Math.round(m.value)} / {m.target}</div>
            </div>
            {m.claimed ? <span className="text-[10px] font-bold text-green-400 tracking-widest">CLAIMED ✓</span>
              : <MenuButton small primary={m.done} disabled={!m.done} onClick={() => claim(m.id, m.xp)}>Claim</MenuButton>}
          </Panel>
        ))}
      </div>
    </Screen>
  );
}

// ------------------------------------------------------------ PROGRESSION & HIGH SCORES
export function Progression({ onBack }: { onBack: () => void }) {
  const s = useStore(); const p = s.profile; const st = p.stats; const lv = levelFromXp(p.xp);
  const [tab, setTab] = useState<ModeId>('combat');
  const acc = st.shots ? Math.round((st.hits / st.shots) * 100) : 0;
  const kd = st.deaths ? (st.kills / st.deaths).toFixed(2) : st.kills.toFixed(2);
  const stats: [string, string | number][] = [['Matches', st.matches], ['Wins', st.wins], ['Eliminations', st.kills], ['Deaths', st.deaths], ['K/D', kd], ['Headshots', st.headshots], ['Accuracy', acc + '%'], ['Longest Hit', st.longestShot + 'm'], ['BR Wins', st.brWins], ['TDM Wins', st.tdmWins], ['Crates Opened', st.cratesOpened], ['Play Time', Math.round(st.playTime / 60) + ' min']];
  const unlocks: { lvl: number; items: string[] }[] = [];
  for (let l = 2; l <= LEVEL_CAP; l++) {
    const items = [...WEAPONS.filter(w => w.unlock === l).map(w => '🔫 ' + w.name), ...ATTACHMENTS.filter(a => a.unlock === l).map(a => '⚙ ' + a.name), ...SKINS.filter(k => k.unlock === l).map(k => '🎨 ' + k.name + ' skin'), ...OPERATORS.filter(o => o.unlock === l).map(o => '👤 ' + o.name)];
    if (items.length) unlocks.push({ lvl: l, items });
  }
  const scores = p.highscores.filter(h => h.mode === tab).sort((a, b) => b.score - a.score).slice(0, 10);
  return (
    <Screen title="PROGRESSION" subtitle="LOCAL PROFILE · STORED ON THIS DEVICE" onBack={onBack}>
      <div className="grid lg:grid-cols-[1fr_1fr] gap-3">
        <div className="space-y-3">
          <Panel className="p-4 flex items-center gap-4">
            <div className="w-16 h-16 clip-corner bg-amber-op text-black flex flex-col items-center justify-center font-black leading-none"><span className="text-[9px]">LEVEL</span><span className="text-3xl">{lv.level}</span></div>
            <div className="flex-1">
              <div className="text-xs tracking-widest text-white/60">TOTAL XP {p.xp.toLocaleString()}</div>
              <div className="h-2 bg-white/10 mt-1"><div className="h-full bg-amber-op" style={{ width: `${(lv.into / lv.need) * 100}%` }} /></div>
              <div className="text-[10px] text-white/40 mt-1">{lv.level >= LEVEL_CAP ? 'MAX LEVEL' : `${lv.need - lv.into} XP to level ${lv.level + 1}`}</div>
            </div>
          </Panel>
          <Panel title="SERVICE RECORD" className="p-4 pt-1 grid grid-cols-3 sm:grid-cols-4 gap-2">
            {stats.map(([k, v]) => <div key={k} className="bg-white/5 p-2"><div className="text-[9px] tracking-widest text-white/50 uppercase">{k}</div><div className="text-lg font-black tabular-nums">{v}</div></div>)}
          </Panel>
          <Panel title="LOCAL HIGH SCORES" className="p-4 pt-1">
            <div className="flex gap-1 mb-2 flex-wrap">{MODES.map(m => <button key={m.id} onClick={() => setTab(m.id)} className={cn('px-2 py-1 text-[10px] font-bold tracking-widest', tab === m.id ? 'bg-amber-op text-black' : 'bg-white/10')}>{m.short}</button>)}</div>
            {scores.length === 0 ? <div className="text-xs text-white/40 py-4 text-center">No scores yet — play a match!</div> : (
              <table className="w-full text-xs"><tbody>
                {scores.map((h, i) => <tr key={h.date + '' + i} className={cn('border-b border-white/5', i === 0 && 'text-amber-op')}>
                  <td className="py-1 w-6 font-black">{i + 1}</td><td className="font-black tabular-nums">{h.score.toLocaleString()}</td><td className="text-white/60">{h.result}</td><td className="text-white/50">{h.kills}K</td><td className="text-white/40 text-right">{MAP_NAMES[h.map as MapId] ?? h.map} · {new Date(h.date).toLocaleDateString()}</td>
                </tr>)}
              </tbody></table>
            )}
          </Panel>
        </div>
        <Panel title="UNLOCK TRACK" className="p-4 pt-1">
          <div className="space-y-1.5 max-h-[60vh] scroll-y pr-2">
            {unlocks.map(u => (
              <div key={u.lvl} className={cn('flex gap-3 p-2 border-l-2', lv.level >= u.lvl ? 'border-green-400 bg-green-400/5' : 'border-white/15 bg-white/[0.03]')}>
                <div className="w-12 shrink-0 font-black text-sm">LV {u.lvl}</div>
                <div className="text-[11px] text-white/70 flex flex-wrap gap-x-3">{u.items.map(i => <span key={i}>{i}</span>)}</div>
                {lv.level >= u.lvl && <span className="ml-auto text-green-400 text-xs">✓</span>}
              </div>
            ))}
          </div>
          <div className="text-[10px] text-white/35 mt-2">No real-money purchases or random loot boxes — everything unlocks through play.</div>
        </Panel>
      </div>
    </Screen>
  );
}

// ------------------------------------------------------------ CREDITS
export function Credits({ onBack }: { onBack: () => void }) {
  const rows: [string, string][] = [
    ['Game Design & Direction', 'Operation Shadow Team'], ['Gameplay & AI Programming', 'Operation Shadow Team'], ['3D Art', 'Procedurally generated in-engine'],
    ['Audio', '100% procedurally synthesised at runtime with the Web Audio API'], ['Rendering', 'three.js (MIT License)'], ['UI Framework', 'React + Tailwind CSS (MIT)'],
    ['Maps', 'Iron District · Dust Frontier · Shadow Range — original layouts'], ['Weapons', '20 original weapon designs and names'],
  ];
  return (
    <Screen title="CREDITS" subtitle="ORIGINAL GAME — NO THIRD-PARTY GAME ASSETS" onBack={onBack}>
      <Panel className="p-5 max-w-2xl space-y-3">
        {rows.map(([a, b]) => <div key={a}><div className="text-[10px] tracking-[0.3em] text-amber-op">{a.toUpperCase()}</div><div className="text-sm text-white/85">{b}</div></div>)}
        <p className="text-[11px] text-white/45 pt-2 border-t border-white/10">OPERATION SHADOW is an original work. It is not affiliated with or endorsed by any other game franchise. All characters, maps, weapon names and sounds were created for this project.</p>
      </Panel>
    </Screen>
  );
}
