import { useEffect, useReducer, useRef, useState, type ReactNode } from 'react';
import { ERA_FACS, ERAS, FACS, type Era } from '../game/data';
import { MAP_LIST, mapsFor } from '../game/maps';
import type { Cfg } from '../game/world';
import { HostLobby, GuestLobby } from '../game/lobby';
import { primeCamera, type Link } from '../game/net';
import { S, saveS, sfx, unlockAudio } from '../game/audio';
import { QRView, Scanner } from './QR';

export interface StartParams { cfg: Cfg; role: 'solo' | 'host' | 'client'; links?: Map<number, Link>; link?: Link }
const rgb = (a: number[]) => `rgb(${a.map(v => Math.round(v * 255)).join(',')})`;

/* ---------- era art ---------- */
const ART: Record<Era, ReactNode> = {
  anc: (<svg viewBox="0 0 290 150" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="a1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#f6c27a" /><stop offset="1" stopColor="#fbe3b0" /></linearGradient></defs><rect width="290" height="150" fill="url(#a1)" /><circle cx="220" cy="38" r="20" fill="#fff4c4" /><path d="M0 120 Q70 95 150 118 T290 110 V150 H0Z" fill="#d9b06a" /><polygon points="40,118 95,45 150,118" fill="#c99a52" /><polygon points="95,45 150,118 110,118" fill="#a97d3c" /><polygon points="150,118 205,70 260,118" fill="#d2a45a" /><rect x="120" y="120" width="6" height="14" fill="#5a3a1a" /><circle cx="60" cy="132" r="5" fill="#3a2a1a" /><rect x="58" y="120" width="2" height="14" fill="#5a3a1a" /></svg>),
  ww2: (<svg viewBox="0 0 290 150" preserveAspectRatio="xMidYMid slice"><rect width="290" height="150" fill="#8798ad" /><rect y="105" width="290" height="45" fill="#4c5e36" /><circle cx="60" cy="40" r="10" fill="#c9d3dd" opacity=".6" /><rect x="70" y="86" width="90" height="20" rx="4" fill="#59603f" /><rect x="90" y="72" width="44" height="16" rx="4" fill="#6a714c" /><rect x="130" y="76" width="56" height="5" fill="#3a3f2a" /><rect x="64" y="104" width="102" height="9" rx="4" fill="#222" /><g fill="#444"><polygon points="200,40 250,34 214,46" /><rect x="190" y="38" width="30" height="5" /></g><path d="M0 100 q70 -20 140 0 t150 0 V105 H0Z" fill="#3d4d2b" /></svg>),
  mod: (<svg viewBox="0 0 290 150" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="m1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#2a4a7a" /><stop offset="1" stopColor="#9ac0e8" /></linearGradient></defs><rect width="290" height="150" fill="url(#m1)" /><rect y="112" width="290" height="38" fill="#6a665c" /><polygon points="60,40 150,26 100,48" fill="#cfd6df" /><polygon points="100,48 150,26 150,52" fill="#8f99a6" /><rect x="140" y="88" width="110" height="20" rx="5" fill="#6d7466" /><rect x="170" y="74" width="50" height="16" rx="5" fill="#7a8272" /><rect x="214" y="80" width="60" height="4" fill="#2a2d28" /><rect x="136" y="106" width="118" height="9" rx="4" fill="#222" /><circle cx="40" cy="95" r="6" fill="#ff7a2a" opacity=".8" /></svg>),
};

/* ---------- shared bits ---------- */
export function FacGrid({ era, value, onPick }: { era: Era; value: string; onPick: (f: string) => void }) {
  return (
    <div className="fgrid">
      {ERA_FACS(era).map(f => (
        <div key={f.id} className={'fc' + (value === f.id ? ' on' : '')} onClick={() => { sfx('click'); onPick(f.id); }}>
          <span className="em">{f.ic}</span><h4>{f.n}</h4>
          <div><span className="sw" style={{ background: rgb(f.a) }} /><span className="sw" style={{ background: rgb(f.b) }} /></div>
          <p>{f.ds}</p><p className="g">＋ {f.g}</p><p className="w">－ {f.w}</p>
        </div>
      ))}
    </div>
  );
}
export function MapPicker({ era, players, value, onPick }: { era: Era; players: number; value: string; onPick: (id: string) => void }) {
  const list = mapsFor(era, players);
  return (
    <div>{list.map(m => (
      <div key={m.id} className={'mapchip' + (value === m.id ? ' on' : '')} onClick={() => { sfx('click'); onPick(m.id); }}>
        <i>{m.pl} لاعبين</i><b>🗺 {m.n}</b><p>{m.ds}</p>
      </div>
    ))}</div>
  );
}
const DIFF = ['سهل', 'متوسط', 'صعب'];
function DiffRow({ v, set }: { v: number; set: (n: number) => void }) {
  return <div className="diff">{DIFF.map((d, i) => <button key={i} className={'tab' + (v === i ? ' on' : '')} onClick={() => set(i)}>{d}</button>)}</div>;
}
const randId = () => (Math.random() * 1e9) | 0;

/* ---------- main ---------- */
export function MainScreen({ mode, setMode, pickEra, go }: { mode: string; setMode: (m: string) => void; pickEra: (e: Era) => void; go: (s: string) => void }) {
  return (
    <div className="scr"><div className="wrap">
      <h1 className="logo">⚔ سيّد الحروب <small>عبر العصور • حرب ثلاثية الأبعاد</small></h1>
      <div className="tabs">
        <button className={'tab' + (mode === 'ai' ? ' on' : '')} onClick={() => setMode('ai')}>🤖 ضد الكمبيوتر</button>
        <button className={'tab' + (mode === 'host' ? ' on' : '')} onClick={() => setMode('host')}>📡 استضافة غرفة (2–4 لاعبين)</button>
        <button className={'tab' + (mode === 'join' ? ' on' : '')} onClick={() => { setMode('join'); }}>📷 انضمام بمسح QR</button>
      </div>
      {mode === 'join' ? (
        <div className="box" style={{ maxWidth: 520, margin: '16px auto' }}>
          <h3>الانضمام إلى غرفة صديقك</h3>
          <p>اطلب من المضيف فتح غرفة واختيار الحقبة والخريطة، ثم امسح رمز QR الظاهر على شاشة هاتفه بكاميرا هاتفك. لا حاجة للإنترنت — يكفي الاتصال بنفس شبكة الواي فاي أو الهوت سبوت.</p>
          <div className="row"><button className="btn" onClick={() => { unlockAudio(); go('join'); }}>📷 فتح الماسح</button></div>
        </div>
      ) : (
        <>
          <p className="sub">{mode === 'host' ? 'اختر الحقبة الزمنية للغرفة (سيلتزم بها جميع اللاعبين)' : 'اختر ساحة المعركة'}</p>
          <div className="cards">
            {(['anc', 'ww2', 'mod'] as Era[]).map(e => (
              <div key={e} className="card" onClick={() => { unlockAudio(); sfx('click'); pickEra(e); }}>
                <div className="art">{ART[e]}</div><h3>{ERAS[e].n}</h3>
                <p>{ERA_FACS(e).map(f => f.n).join(' • ')}</p>
              </div>
            ))}
          </div>
        </>
      )}
      <div className="row">
        <button className="btn sm gray" onClick={() => go('set')}>⚙ الإعدادات</button>
        <button className="btn sm gray" onClick={() => go('how')}>📖 طريقة اللعب</button>
        <button className="btn sm" onClick={() => go('dev')}>👨‍💻 مطوّر اللعبة</button>
      </div>
      <div className="devline">تطوير: <b>بلال محمد</b> و <b>عبدالله محمد</b></div>
    </div></div>
  );
}

/* ---------- vs computer ---------- */
export function FacScreen({ era, onStart, onBack }: { era: Era; onStart: (p: StartParams) => void; onBack: () => void }) {
  const [fac, setFac] = useState(ERA_FACS(era)[0].id); const [foes, setFoes] = useState(1); const [diff, setDiff] = useState(1);
  const [map, setMap] = useState(mapsFor(era, 2)[0].id);
  useEffect(() => { const l = mapsFor(era, foes + 1); if (!l.find(m => m.id === map)) setMap(l[0].id); }, [foes, era, map]);
  const go = () => {
    const others = ERA_FACS(era).filter(f => f.id !== fac); const players = [{ fac, name: 'أنت', ai: -1 }];
    const pool = [...others].sort(() => Math.random() - 0.5);
    for (let i = 0; i < foes; i++) players.push({ fac: pool[i % pool.length].id, name: 'كمبيوتر ' + (i + 1), ai: diff });
    onStart({ cfg: { era, map, players, seed: randId(), local: 0 }, role: 'solo' });
  };
  return (
    <div className="scr"><div className="wrap">
      <h2 className="logo" style={{ fontSize: 24 }}>{ERAS[era].n} — اختر جيشك</h2>
      <FacGrid era={era} value={fac} onPick={setFac} />
      <div className="box"><h3>عدد الأعداء</h3>
        <div className="diff">{[1, 2, 3].map(n => <button key={n} className={'tab' + (foes === n ? ' on' : '')} onClick={() => setFoes(n)}>{n === 1 ? 'عدو واحد' : n + ' أعداء'}</button>)}</div>
        <h3>الخريطة</h3><MapPicker era={era} players={foes + 1} value={map} onPick={setMap} />
        <h3>مستوى الصعوبة</h3><DiffRow v={diff} set={setDiff} />
      </div>
      <div className="row"><button className="btn" onClick={go}>⚔ ابدأ المعركة</button><button className="btn gray" onClick={onBack}>رجوع</button></div>
    </div></div>
  );
}

/* ---------- host ---------- */
export function HostScreen({ era, onStart, onBack }: { era: Era; onStart: (p: StartParams) => void; onBack: () => void }) {
  const [, force] = useReducer((x: number) => x + 1, 0);
  const lobby = useRef<HostLobby | null>(null); if (!lobby.current) lobby.current = new HostLobby(era);
  const L = lobby.current; const handed = useRef(false);
  const [scan, setScan] = useState(-1); const [err, setErr] = useState(''); const [camOk, setCamOk] = useState<boolean | null>(null);
  useEffect(() => { L.onChange = force; return () => { L.onChange = () => { }; if (!handed.current) L.destroy(); }; }, [L]);
  const open = async (i: number) => { unlockAudio(); if (camOk === null) setCamOk(await primeCamera()); L.open(i); };
  const start = () => {
    const r = L.build(); if (typeof r === 'string') { setErr(r); return; }
    handed.current = true; const { cfg, assign } = r;
    assign.forEach((l, pi) => l.send({ t: 'start', cfg: { ...cfg, local: pi } }));
    onStart({ cfg, role: 'host', links: assign });
  };
  return (
    <div className="scr"><div className="wrap">
      <h2 className="logo" style={{ fontSize: 24 }}>📡 إنشاء غرفة (بدون إنترنت)</h2>
      <div className="box"><p>١) اتصل مع أصدقائك بنفس شبكة الواي فاي أو هوت سبوت. ٢) اضغط «إنشاء رمز» للاعب، فيمسحه صديقك من «انضمام بمسح QR». ٣) امسح أنت رمز الرد الذي يظهر على هاتفه. لا نسخ ولا لصق نهائياً.</p></div>
      <div className="box">
        <h3>الحقبة الزمنية</h3>
        <div className="diff">{(['anc', 'ww2', 'mod'] as Era[]).map(e => <button key={e} className={'tab' + (L.era === e ? ' on' : '')} onClick={() => L.setEra(e)}>{ERAS[e].n}</button>)}</div>
        <h3>عدد اللاعبين في الغرفة</h3>
        <div className="diff">{[2, 3, 4].map(n => <button key={n} className={'tab' + (L.n === n ? ' on' : '')} onClick={() => L.setN(n)}>{n} لاعبين</button>)}</div>
        <h3>الخريطة</h3><MapPicker era={L.era} players={L.n} value={L.mapId} onPick={id => L.setMap(id)} />
        <h3>ملء المقاعد الفارغة بالكمبيوتر</h3>
        <div className="diff"><button className={'tab' + (L.fill ? ' on' : '')} onClick={() => { L.fill = !L.fill; L.changed(); }}>{L.fill ? 'مفعّل ✔' : 'متوقف'}</button></div>
        {L.fill && <DiffRow v={L.diff} set={n => { L.diff = n; L.changed(); }} />}
      </div>
      <div className="box"><h3>جيشك (المضيف)</h3><FacGrid era={L.era} value={L.hostFac} onPick={f => L.setHostFac(f)} /></div>
      <div className="box"><h3>مقاعد اللاعبين</h3>
        {camOk === false && <p className="bad">لم يتم السماح بالكاميرا — لن تتمكن من مسح رمز الرد. فعّل إذن الكاميرا من إعدادات المتصفح.</p>}
        {Array.from({ length: L.n - 1 }, (_, k) => k + 1).map(i => {
          const s = L.slots[i];
          return (
            <div className="slot" key={i}>
              <h4>👤 اللاعب {i + 1} {s.status === 'on' && <span className="ok"> — متصل ✔ ({FACS[s.fac]?.n})</span>}</h4>
              {s.status === 'idle' && <button className="btn sm" onClick={() => open(i)}>🔳 إنشاء رمز QR لهذا اللاعب</button>}
              {s.status === 'making' && <p className="sub">جارٍ إنشاء الرمز…</p>}
              {s.status === 'offer' && (<>
                <QRView text={s.code} size={Math.min(320, window.innerWidth - 80)} />
                <p className="sub">1) اطلب من صديقك مسح هذا الرمز من «انضمام بمسح QR».<br />2) ثم اضغط الزر وامسح رمز الرد على هاتفه.</p>
                <div className="row" style={{ margin: 0 }}><button className="btn sm green" onClick={() => setScan(i)}>📷 مسح رمز رد اللاعب</button><button className="btn sm gray" onClick={() => { L.closeSlot(i); L.changed(); }}>إلغاء</button></div>
              </>)}
              {s.status === 'wait' && <p className="sub">⏳ جارٍ الاتصال… (تأكد أن الهاتفين على نفس الشبكة)</p>}
              {s.status === 'err' && (<><p className="bad">فشل الاتصال. تأكد من نفس الشبكة وأعد المحاولة.</p><button className="btn sm" onClick={() => open(i)}>↻ إعادة المحاولة</button></>)}
              {s.status === 'on' && <button className="btn sm gray" onClick={() => { L.closeSlot(i); L.changed(); }}>طرد</button>}
            </div>
          );
        })}
      </div>
      {err && <p className="bad">{err}</p>}
      <div className="row"><button className="btn" onClick={start}>⚔ ابدأ اللعبة ({1 + L.connected()} متصل)</button><button className="btn gray" onClick={onBack}>رجوع</button></div>
      {scan >= 0 && <Scanner title={`امسح رد اللاعب ${scan + 1}`} onCancel={() => setScan(-1)} onResult={c => { const i = scan; setScan(-1); L.scanAnswer(i, c); }} />}
    </div></div>
  );
}

/* ---------- join ---------- */
export function JoinScreen({ onStart, onBack }: { onStart: (p: StartParams) => void; onBack: () => void }) {
  const [, force] = useReducer((x: number) => x + 1, 0);
  const lobby = useRef<GuestLobby | null>(null); if (!lobby.current) lobby.current = new GuestLobby();
  const G = lobby.current; const [scan, setScan] = useState(false);
  useEffect(() => {
    G.onChange = force; G.onStart = (cfg, link) => onStart({ cfg, role: 'client', link });
    return () => { G.onChange = () => { }; G.destroy(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [G]);
  const info = G.info;
  return (
    <div className="scr"><div className="wrap" style={{ maxWidth: 640 }}>
      <h2 className="logo" style={{ fontSize: 24 }}>📷 الانضمام لغرفة</h2>
      {(G.status === 'idle' || G.status === 'err' || G.status === 'closed') && (
        <div className="box">
          <p>{G.status === 'err' ? '❌ تعذّر قراءة الرمز أو الاتصال. ' : G.status === 'closed' ? '⚠ انقطع الاتصال بالمضيف. ' : ''}اضغط الزر ووجّه الكاميرا نحو رمز QR الظاهر على شاشة المضيف.</p>
          <div className="row"><button className="btn green" onClick={() => { unlockAudio(); setScan(true); }}>📷 مسح رمز المضيف</button></div>
        </div>
      )}
      {G.status === 'making' && <div className="box"><p>جارٍ إنشاء رمز الرد…</p></div>}
      {G.status === 'answer' && (
        <div className="box" style={{ textAlign: 'center' }}>
          <h3>رمز الرد</h3>
          <QRView text={G.code} size={Math.min(320, window.innerWidth - 80)} />
          <p className="sub">اطلب من المضيف الضغط على «مسح رمز رد اللاعب» وتوجيه كاميرته إلى هذه الشاشة.</p>
        </div>
      )}
      {G.status === 'on' && (
        <div className="box">
          <h3 className="ok">✅ متصل بالغرفة</h3>
          {info ? (<>
            <p>🕰 الحقبة: <b>{ERAS[info.era].n}</b> (حدّدها المضيف)</p>
            <p>🗺 الخريطة: <b>{MAP_LIST.find(m => m.id === info.map)?.n}</b> • عدد اللاعبين: <b>{info.n}</b></p>
            <div>{info.slots.map((s, i) => <span key={i} className="pill">{i === info.you ? '⭐ أنت' : s.name} — {FACS[s.fac]?.ic} {FACS[s.fac]?.n}{s.k === 'ai' ? ' (كمبيوتر)' : ''}</span>)}</div>
            <h3 style={{ marginTop: 10 }}>اختر جيشك (من نفس الحقبة فقط)</h3>
            <FacGrid era={info.era} value={G.fac} onPick={f => G.pick(f)} />
            <p className="sub">⏳ بانتظار أن يبدأ المضيف المعركة…</p>
          </>) : <p>بانتظار بيانات الغرفة…</p>}
        </div>
      )}
      <div className="row"><button className="btn gray" onClick={onBack}>رجوع</button></div>
      {scan && <Scanner title="امسح رمز المضيف" onCancel={() => setScan(false)} onResult={c => { setScan(false); G.join(c); }} />}
    </div></div>
  );
}

/* ---------- simple screens ---------- */
export function SettingsScreen({ onBack }: { onBack: () => void }) {
  const [, force] = useReducer((x: number) => x + 1, 0);
  const tg = (k: 'sound' | 'vib' | 'shake' | 'hq') => <button className={'tg' + (S[k] ? ' on' : '')} onClick={() => { S[k] = !S[k]; saveS(); force(); }} />;
  return (
    <div className="scr"><div className="wrap" style={{ maxWidth: 520 }}>
      <h2 className="logo" style={{ fontSize: 24 }}>⚙ الإعدادات</h2>
      <div className="box">
        <div className="set"><span>🔊 المؤثرات الصوتية</span>{tg('sound')}</div>
        <div className="set"><span>📳 الاهتزاز</span>{tg('vib')}</div>
        <div className="set"><span>🎥 اهتزاز الكاميرا (انفجارات)</span>{tg('shake')}</div>
        <div className="set"><span>✨ جودة عالية (ظلال ومؤثرات أكثر)</span>{tg('hq')}</div>
        <p className="sub">يُطبَّق تغيير الجودة عند بدء معركة جديدة.</p>
      </div>
      <div className="row"><button className="btn" onClick={onBack}>رجوع</button></div>
    </div></div>
  );
}
export function DevScreen({ onBack }: { onBack: () => void }) {
  return (
    <div className="scr"><div className="wrap" style={{ maxWidth: 520 }}>
      <h2 className="logo" style={{ fontSize: 24 }}>👨‍💻 مطوّر اللعبة</h2>
      <div className="box" style={{ textAlign: 'center' }}><p>تم تطوير اللعبة بواسطة</p><div className="dev">بلال محمد</div><div className="dev">عبدالله محمد</div><p>لعبة استراتيجية ثلاثية الأبعاد تعمل بدون إنترنت</p></div>
      <div className="row"><button className="btn" onClick={onBack}>رجوع</button></div>
    </div></div>
  );
}
export function HowScreen({ onBack }: { onBack: () => void }) {
  return (
    <div className="scr"><div className="wrap" style={{ maxWidth: 640 }}>
      <h2 className="logo" style={{ fontSize: 24 }}>📖 طريقة اللعب</h2>
      <div className="box"><p>
        • <b>اضغط</b> على وحدتك لتحديدها (ضغطتان سريعتان تحدّد كل الوحدات المشابهة)، ثم اضغط على الأرض للتحرك أو على العدو للهجوم.<br />
        • <b>اسحب بإصبع</b> لتحريك الكاميرا، و<b>بإصبعين</b> للتقريب والتدوير. على الكمبيوتر: عجلة الماوس للتقريب، WASD للتحريك، Q/E للتدوير، كليك أيسر للتحديد/سحب مربع، وأيمن للأوامر.<br />
        • زر ⬚ للتحديد بالمربع، 🪖 لتحديد كل الجيش، ⚔ للهجوم والتحرك، ⏹ للإيقاف.<br />
        • العمال يجمعون الذهب تلقائياً من المناجم. اضغط 🏗 للبناء ثم اضغط مكان البناء (قرب مبانيك).<br />
        • اضغط على مبنى لإنتاج الوحدات. تحتاج ثكنات ومصانع ومطارات (في الحرب العالمية والحديثة).<br />
        • لكل جيش قدرتان خاصتان في الأعلى (غارات، تعزيزات، علاج...). اضغط القدرة ثم اختر الهدف.<br />
        • دمّر مقر العدو لتفوز. الطائرات تحتاج مضادات جوية: الرشاشات والصواريخ وأبراج الدفاع.<br />
        • <b>اللعب الجماعي:</b> المضيف يفتح غرفة (2–4 لاعبين)، يختار الحقبة والخريطة، ثم يمسح اللاعبون رمز QR بكاميرا الهاتف. الجميع يختار جيشه من نفس الحقبة.
      </p></div>
      <div className="row"><button className="btn" onClick={onBack}>رجوع</button></div>
    </div></div>
  );
}
export function EndScreen({ win, text, stats, onMenu }: { win: boolean; text: string; stats: string[]; onMenu: () => void }) {
  return (
    <div className="scr"><div className="wrap" style={{ maxWidth: 440 }}>
      <div className="big">{win ? '🏆' : '💀'}</div>
      <h2 className="logo" style={{ fontSize: 30 }}>{win ? 'النصر!' : 'انتهت المعركة'}</h2>
      <div className="box"><p style={{ fontSize: 15, color: '#fff' }}>{text}</p>{stats.map((s, i) => <p key={i}>{s}</p>)}</div>
      <div className="row"><button className="btn" onClick={onMenu}>القائمة الرئيسية</button></div>
    </div></div>
  );
}
