import type { FighterId } from '../game/character';
import type { Difficulty } from '../game/ai';
import type { Settings } from '../game/Game';

export type Screen = 'main' | 'select' | 'difficulty' | 'settings' | 'game';

export const DIFFS: { id: Difficulty; name: string; desc: string }[] = [
  { id: 'easy', name: 'Easy', desc: 'Slow reactions, rarely blocks. Great for learning the moves.' },
  { id: 'normal', name: 'Normal', desc: 'Balanced opponent that blocks, dodges and chains combos.' },
  { id: 'hard', name: 'Hard', desc: 'Ruthless. Fast reactions, punishes whiffs, uses specials.' },
];

const CHARS: Record<FighterId, {
  name: string; role: string; blurb: string; power: number; speed: number; reach: number; stamina: number; special: string; color: string;
}> = {
  leon: {
    name: 'LEON S. KENNEDY', role: 'RPD ROOKIE / SPECIAL AGENT', color: '#6ea0ff',
    blurb: 'Hard-hitting close-quarters brawler with powerful overhand strikes and punishing roundhouse kicks.',
    power: 90, speed: 62, reach: 70, stamina: 70, special: 'Rushing Roundhouse',
  },
  ada: {
    name: 'ADA WONG', role: 'MASTER SPY', color: '#ff3a48',
    blurb: 'Fast and elegant martial artist. Longer kicks, a farther dodge and quick stamina recovery.',
    power: 66, speed: 92, reach: 82, stamina: 85, special: 'Aerial Axe Flip',
  },
};

function Stat({ label, v, c }: { label: string; v: number; c: string }) {
  return (
    <div className="flex items-center gap-2" style={{ fontSize: 'clamp(9px,1.9vh,12px)' }}>
      <span className="w-14 text-neutral-400 tracking-widest">{label}</span>
      <div className="stat-bar flex-1"><div style={{ width: `${v}%`, background: `linear-gradient(90deg, #222, ${c})` }} /></div>
    </div>
  );
}

function Portrait({ id }: { id: FighterId }) {
  const leon = id === 'leon';
  return (
    <svg viewBox="0 0 100 120" style={{ height: 'clamp(70px,22vh,150px)' }}>
      <defs>
        <linearGradient id={`g-${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={leon ? '#1c2230' : '#2a0c10'} />
          <stop offset="1" stopColor="#07080a" />
        </linearGradient>
      </defs>
      <rect width="100" height="120" fill={`url(#g-${id})`} />
      {/* shoulders / outfit */}
      <path d="M5 120 Q8 82 34 76 L66 76 Q92 82 95 120Z" fill={leon ? '#14161a' : '#b3121d'} />
      {!leon && <path d="M42 76 L50 100 L58 76Z" fill="#111" />}
      {leon && <path d="M30 78 L44 120 M70 78 L56 120" stroke="#3a3a34" strokeWidth="5" />}
      {/* neck + head */}
      <rect x="43" y="62" width="14" height="18" fill={leon ? '#d8a98a' : '#e6bfa2'} />
      <ellipse cx="50" cy="45" rx="19" ry="23" fill={leon ? '#d8a98a' : '#e6bfa2'} />
      {/* hair */}
      {leon ? (
        <path d="M30 44 Q28 18 50 17 Q74 18 70 44 Q66 30 56 29 Q48 36 38 30 Q32 34 30 44Z" fill="#9a7745" />
      ) : (
        <path d="M28 62 Q22 20 50 17 Q78 20 72 62 L66 62 Q68 36 62 30 Q50 38 36 30 Q32 38 34 62Z" fill="#0a0a0d" />
      )}
      <circle cx="42" cy="46" r="1.8" fill="#111" />
      <circle cx="58" cy="46" r="1.8" fill="#111" />
      <rect x="45" y="58" width="10" height="2.4" rx="1" fill={leon ? '#a0705c' : '#a8101e'} />
    </svg>
  );
}

export function MainMenu({ onPlay, onGo, sel, diff }: {
  onPlay: () => void; onGo: (s: Screen) => void; sel: FighterId; diff: Difficulty;
}) {
  const opp = sel === 'leon' ? 'ADA WONG' : 'LEON S. KENNEDY';
  return (
    <div className="fixed inset-0 z-30 flex items-center fade-in" style={{ background: 'linear-gradient(90deg, rgba(2,3,5,0.92) 0%, rgba(2,3,5,0.55) 45%, transparent 75%)', padding: '0 max(24px, 5vw)' }}>
      <div style={{ width: 'min(480px, 52vw)' }}>
        <div className="text-[10px] tracking-[0.5em] text-red-400 mb-1" style={{ fontSize: 'clamp(8px,1.8vh,12px)' }}>SURVIVAL FIGHTING · RACCOON CITY</div>
        <div className="title-main text-white" style={{ fontSize: 'clamp(30px,10.5vh,86px)' }}>Leon S. Kennedy</div>
        <div className="title-vs" style={{ fontSize: 'clamp(18px,6vh,48px)', margin: '0.1em 0' }}>— VS —</div>
        <div className="title-main" style={{ fontSize: 'clamp(30px,10.5vh,86px)', color: '#ff5a66' }}>Ada Wong</div>
        <div className="flex flex-col gap-1.5 mt-[3vh]" style={{ width: 'min(340px,100%)' }}>
          <button className="menu-btn primary" onClick={onPlay}>
            Play<small>{sel === 'leon' ? 'Leon' : 'Ada'} vs {opp} · {diff.toUpperCase()}</small>
          </button>
          <button className="menu-btn" onClick={() => onGo('select')}>Character Select</button>
          <button className="menu-btn" onClick={() => onGo('difficulty')}>Difficulty</button>
          <button className="menu-btn" onClick={() => onGo('settings')}>Settings</button>
        </div>
      </div>
    </div>
  );
}

function Back({ onBack }: { onBack: () => void }) {
  return (
    <button className="menu-btn" style={{ width: 'auto', display: 'inline-block', fontSize: 'clamp(13px,2.8vh,18px)' }} onClick={onBack}>
      ◀ Back
    </button>
  );
}

export function CharSelect({ sel, onSel, onBack, onPlay }: {
  sel: FighterId; onSel: (id: FighterId) => void; onBack: () => void; onPlay: () => void;
}) {
  return (
    <div className="fixed inset-0 z-30 flex flex-col fade-in" style={{ background: 'linear-gradient(180deg, rgba(2,3,5,0.8), rgba(2,3,5,0.15) 40%, rgba(2,3,5,0.85))', padding: 'max(10px,2vh) max(18px,3vw)' }}>
      <div className="flex items-center justify-between">
        <Back onBack={onBack} />
        <div className="font-display text-white tracking-[0.3em]" style={{ fontSize: 'clamp(16px,4vh,30px)' }}>SELECT YOUR FIGHTER</div>
        <button className="menu-btn primary" style={{ width: 'auto', fontSize: 'clamp(13px,2.8vh,18px)' }} onClick={onPlay}>Fight ▶</button>
      </div>
      <div className="flex-1" />
      <div className="flex gap-4 justify-between items-end" style={{ maxWidth: 980, margin: '0 auto', width: '100%' }}>
        {(['leon', 'ada'] as FighterId[]).map((id) => {
          const c = CHARS[id];
          const on = sel === id;
          return (
            <div key={id} className={`card flex-1 p-3 ${on ? `sel-${id}` : ''}`} style={{ opacity: on ? 1 : 0.7 }} onClick={() => onSel(id)}>
              <div className="flex gap-3 items-center">
                <Portrait id={id} />
                <div className="flex-1 min-w-0">
                  <div className="font-display text-white" style={{ fontSize: 'clamp(14px,3.6vh,26px)', color: on ? c.color : '#fff' }}>{c.name}</div>
                  <div className="text-neutral-400 tracking-widest" style={{ fontSize: 'clamp(8px,1.6vh,11px)' }}>{c.role}</div>
                  <div className="text-neutral-300 my-1 leading-tight" style={{ fontSize: 'clamp(9px,1.9vh,13px)' }}>{c.blurb}</div>
                  <Stat label="POWER" v={c.power} c={c.color} />
                  <Stat label="SPEED" v={c.speed} c={c.color} />
                  <Stat label="REACH" v={c.reach} c={c.color} />
                  <Stat label="STAMINA" v={c.stamina} c={c.color} />
                  <div className="mt-1 text-amber-300 tracking-wider" style={{ fontSize: 'clamp(9px,1.8vh,12px)' }}>★ SPECIAL: {c.special}</div>
                </div>
              </div>
              {on && <div className="text-center font-display tracking-[0.3em] mt-1" style={{ color: c.color, fontSize: 'clamp(10px,2vh,14px)' }}>SELECTED</div>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function DiffScreen({ diff, onSel, onBack }: { diff: Difficulty; onSel: (d: Difficulty) => void; onBack: () => void }) {
  return (
    <div className="fixed inset-0 z-30 flex flex-col fade-in" style={{ background: 'rgba(2,3,5,0.8)', padding: 'max(10px,2vh) max(18px,3vw)' }}>
      <div className="flex items-center justify-between">
        <Back onBack={onBack} />
        <div className="font-display text-white tracking-[0.3em]" style={{ fontSize: 'clamp(16px,4vh,30px)' }}>DIFFICULTY</div>
        <div style={{ width: 90 }} />
      </div>
      <div className="flex-1 flex items-center justify-center">
        <div className="flex gap-4 w-full" style={{ maxWidth: 900 }}>
          {DIFFS.map((d) => (
            <button key={d.id} className={`card flex-1 p-4 text-left ${diff === d.id ? 'sel-ada' : ''}`} onClick={() => onSel(d.id)}>
              <div className="font-display text-white" style={{ fontSize: 'clamp(18px,5vh,36px)', color: diff === d.id ? '#ff5a66' : '#fff' }}>{d.name.toUpperCase()}</div>
              <div className="flex gap-1 my-2">
                {[0, 1, 2].map((i) => (
                  <div key={i} style={{ width: 22, height: 6, background: i <= DIFFS.findIndex((x) => x.id === d.id) ? '#ff3a48' : '#2a2d33' }} />
                ))}
              </div>
              <div className="text-neutral-300" style={{ fontSize: 'clamp(10px,2.1vh,14px)' }}>{d.desc}</div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between py-1.5 border-b border-neutral-800">
      <span className="font-display tracking-widest text-neutral-200" style={{ fontSize: 'clamp(12px,2.8vh,18px)' }}>{label}</span>
      {children}
    </div>
  );
}

function Toggle({ value, opts, onChange }: { value: string; opts: [string, string][]; onChange: (v: string) => void }) {
  return (
    <div className="toggle">
      {opts.map(([v, l]) => (
        <button key={v} className={value === v ? 'on' : ''} onClick={() => onChange(v)}>{l}</button>
      ))}
    </div>
  );
}

export function SettingsScreen({ s, onChange, onBack, onFs }: { s: Settings; onChange: (s: Settings) => void; onBack: () => void; onFs: () => void }) {
  const onOff: [string, string][] = [['1', 'ON'], ['0', 'OFF']];
  return (
    <div className="fixed inset-0 z-30 flex flex-col fade-in" style={{ background: 'rgba(2,3,5,0.82)', padding: 'max(10px,2vh) max(18px,3vw)' }}>
      <div className="flex items-center justify-between">
        <Back onBack={onBack} />
        <div className="font-display text-white tracking-[0.3em]" style={{ fontSize: 'clamp(16px,4vh,30px)' }}>SETTINGS</div>
        <div style={{ width: 90 }} />
      </div>
      <div className="flex-1 flex items-center justify-center overflow-auto">
        <div className="panel p-4 w-full" style={{ maxWidth: 640 }}>
          <Row label="GRAPHICS QUALITY">
            <Toggle value={String(s.quality)} opts={[['0', 'LOW'], ['1', 'MEDIUM'], ['2', 'HIGH']]} onChange={(v) => onChange({ ...s, quality: Number(v) as 0 | 1 | 2 })} />
          </Row>
          <Row label="SOUND">
            <Toggle value={s.sound ? '1' : '0'} opts={onOff} onChange={(v) => onChange({ ...s, sound: v === '1' })} />
          </Row>
          <Row label="CAMERA SHAKE">
            <Toggle value={s.shake ? '1' : '0'} opts={onOff} onChange={(v) => onChange({ ...s, shake: v === '1' })} />
          </Row>
          <Row label="VIBRATION">
            <Toggle value={s.vibrate ? '1' : '0'} opts={onOff} onChange={(v) => onChange({ ...s, vibrate: v === '1' })} />
          </Row>
          <Row label="FULLSCREEN">
            <button className="toggle" onClick={onFs}><span className="px-3 py-1 font-display tracking-widest text-sm" style={{ background: '#c4121f' }}>TOGGLE</span></button>
          </Row>
          <div className="mt-3 text-neutral-400 leading-snug" style={{ fontSize: 'clamp(9px,1.8vh,12px)' }}>
            <b className="text-neutral-200">Keyboard:</b> WASD / Arrows move · J punch · K heavy · L kick · Shift block · Space dodge · E special.
            <br />
            <b className="text-neutral-200">Tips:</b> Block right before a hit lands for a PERFECT BLOCK. Dodge through an attack to unlock a COUNTER (+50% damage). Land hits to fill the special meter.
          </div>
        </div>
      </div>
    </div>
  );
}

export function PauseMenu({ onResume, onRestart, onQuit }: { onResume: () => void; onRestart: () => void; onQuit: () => void }) {
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center" style={{ background: 'rgba(2,3,5,0.72)' }}>
      <div className="panel p-5 fade-in" style={{ width: 'min(340px,86vw)' }}>
        <div className="font-display text-white text-center tracking-[0.3em] mb-3" style={{ fontSize: 'clamp(18px,4.4vh,30px)' }}>PAUSED</div>
        <div className="flex flex-col gap-2">
          <button className="menu-btn primary" onClick={onResume}>Resume</button>
          <button className="menu-btn" onClick={onRestart}>Restart Match</button>
          <button className="menu-btn" onClick={onQuit}>Main Menu</button>
        </div>
      </div>
    </div>
  );
}

export function ResultScreen({ won, wins, onRematch, onQuit }: { won: boolean; wins: [number, number]; onRematch: () => void; onQuit: () => void }) {
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center" style={{ background: 'rgba(2,3,5,0.6)' }}>
      <div className="panel p-5 fade-in text-center" style={{ width: 'min(420px,90vw)' }}>
        <div className="font-display" style={{ fontSize: 'clamp(30px,10vh,64px)', color: won ? '#ffcf5a' : '#ff3a48', textShadow: '0 3px 0 #000' }}>
          {won ? 'VICTORY' : 'DEFEAT'}
        </div>
        <div className="font-display text-neutral-300 tracking-[0.3em] mb-3">{wins[0]} — {wins[1]}</div>
        <div className="flex gap-2">
          <button className="menu-btn primary text-center" onClick={onRematch}>Rematch</button>
          <button className="menu-btn text-center" onClick={onQuit}>Menu</button>
        </div>
      </div>
    </div>
  );
}
