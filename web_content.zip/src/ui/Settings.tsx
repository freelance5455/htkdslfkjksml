import { useEffect, useState } from "react";
import {
  ACTION_LIST,
  DEFAULT_KEYMAP,
  DEFAULT_SETTINGS,
  prettyKey,
  type Action,
  type GameSettings,
} from "../game/engine";

interface Props {
  keymap: Record<Action, string>;
  settings: GameSettings;
  onChangeKey: (action: Action, code: string) => void;
  onChangeSettings: (s: GameSettings) => void;
  onClose: () => void;
}

export default function Settings({
  keymap,
  settings,
  onChangeKey,
  onChangeSettings,
  onClose,
}: Props) {
  const [listening, setListening] = useState<Action | null>(null);

  useEffect(() => {
    if (!listening) return;
    const onKey = (e: KeyboardEvent) => {
      e.preventDefault();
      e.stopPropagation();
      if (e.code !== "Escape") onChangeKey(listening, e.code);
      setListening(null);
    };
    const onMouse = (e: MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      onChangeKey(listening, `Mouse${e.button}`);
      setListening(null);
    };
    window.addEventListener("keydown", onKey, true);
    window.addEventListener("mousedown", onMouse, true);
    return () => {
      window.removeEventListener("keydown", onKey, true);
      window.removeEventListener("mousedown", onMouse, true);
    };
  }, [listening, onChangeKey]);

  const set = (patch: Partial<GameSettings>) =>
    onChangeSettings({ ...settings, ...patch });

  const groups = Array.from(new Set(ACTION_LIST.map((a) => a.group)));

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-[#0e0b08]/82 p-3 sm:p-6">
      <div
        data-rebinding={listening ? "true" : undefined}
        className="mc-panel snap-in flex h-full max-h-[880px] w-full max-w-[1000px] flex-col"
      >
        <div className="flex shrink-0 items-center justify-between border-b-4 border-black bg-[#1c140c]/70 px-5 py-4">
          <div>
            <div className="text-[9px] tracking-[0.32em] text-[#b7ada0]">
              CONTROLS · EVERY BUTTON IS REBINDABLE
            </div>
            <h2 className="font-title mt-2 text-lg text-white mc-shadow sm:text-2xl">SETTINGS</h2>
          </div>
          <button className="mc-btn" onClick={onClose}>
            ✕ CLOSE
          </button>
        </div>

        <div className="mc-scroll min-h-0 flex-1 overflow-y-auto p-4 sm:p-6">
          {/* ---- sliders ---- */}
          <div className="grid gap-4 sm:grid-cols-2">
            <Slider
              label="MOUSE SENSITIVITY"
              value={settings.sensitivity}
              min={0.2}
              max={3}
              step={0.05}
              display={`${settings.sensitivity.toFixed(2)}×`}
              onChange={(v) => set({ sensitivity: v })}
            />
            <Slider
              label="FIELD OF VIEW"
              value={settings.fov}
              min={55}
              max={110}
              step={1}
              display={`${settings.fov}°`}
              onChange={(v) => set({ fov: v })}
            />
            <Slider
              label="RENDER SCALE"
              value={settings.renderScale}
              min={0.5}
              max={1.5}
              step={0.05}
              display={`${Math.round(settings.renderScale * 100)}%`}
              onChange={(v) => set({ renderScale: v })}
            />
            <Slider
              label="HUD SCALE"
              value={settings.hudScale}
              min={0.7}
              max={1.5}
              step={0.05}
              display={`${Math.round(settings.hudScale * 100)}%`}
              onChange={(v) => set({ hudScale: v })}
            />
            <Toggle
              label="INVERT VERTICAL LOOK"
              value={settings.invertY}
              onChange={(v) => set({ invertY: v })}
            />
            <Toggle
              label="SHOW DEBUG OVERLAY (F3)"
              value={settings.showDebug}
              onChange={(v) => set({ showDebug: v })}
            />
          </div>

          {/* ---- keybinds ---- */}
          <div className="mt-8">
            <div className="flex items-baseline gap-3">
              <h3 className="font-title text-sm text-white mc-shadow">KEY BINDINGS</h3>
              <span className="text-[9px] tracking-[0.22em] text-[#b7ada0]">
                CLICK A KEY, THEN PRESS ANY KEY OR MOUSE BUTTON
              </span>
            </div>

            {groups.map((group) => (
              <div key={group} className="mt-5">
                <div className="mb-2 text-[9px] tracking-[0.32em] text-[#7ec850]">
                  {group.toUpperCase()}
                </div>
                <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                  {ACTION_LIST.filter((a) => a.group === group).map((a) => (
                    <div
                      key={a.id}
                      className="mc-panel--stone mc-panel flex items-center justify-between gap-3 px-3 py-2"
                    >
                      <span className="text-[10px] leading-tight text-[#e6e0d7]">{a.label}</span>
                      <button
                        className={`mc-btn min-w-[92px] px-2 py-1 text-[10px] ${
                          listening === a.id ? "mc-btn--grass blink" : ""
                        }`}
                        onClick={() => setListening(a.id)}
                      >
                        {listening === a.id ? "PRESS KEY" : prettyKey(keymap[a.id])}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 flex flex-wrap gap-3">
            <button
              className="mc-btn"
              onClick={() => onChangeKey("__reset__" as Action, "")}
            >
              RESET KEYS
            </button>
            <button
              className="mc-btn"
              onClick={() => onChangeSettings({ ...DEFAULT_SETTINGS })}
            >
              RESET OPTIONS
            </button>
            <span className="self-center text-[9px] tracking-[0.18em] text-[#b7ada0]">
              DEFAULTS: {prettyKey(DEFAULT_KEYMAP.forward)} /{" "}
              {prettyKey(DEFAULT_KEYMAP.jump)} / {prettyKey(DEFAULT_KEYMAP.store)} STORE /{" "}
              {prettyKey(DEFAULT_KEYMAP.interact)} DRIVE
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

function Slider(props: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  display: string;
  onChange: (v: number) => void;
}) {
  return (
    <label className="mc-panel--stone mc-panel block px-3 py-3">
      <div className="mb-2 flex items-baseline justify-between">
        <span className="text-[9px] tracking-[0.24em] text-[#b7ada0]">{props.label}</span>
        <span className="text-[11px] tabular-nums text-[#e8c24a]">{props.display}</span>
      </div>
      <input
        type="range"
        className="w-full"
        min={props.min}
        max={props.max}
        step={props.step}
        value={props.value}
        onChange={(e) => props.onChange(Number(e.target.value))}
      />
    </label>
  );
}

function Toggle(props: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      className="mc-panel--stone mc-panel flex items-center justify-between px-3 py-3"
      onClick={() => props.onChange(!props.value)}
    >
      <span className="text-[9px] tracking-[0.24em] text-[#b7ada0]">{props.label}</span>
      <span
        className={`mc-btn pointer-events-none px-3 py-1 text-[10px] ${
          props.value ? "mc-btn--grass" : ""
        }`}
      >
        {props.value ? "ON" : "OFF"}
      </span>
    </button>
  );
}
