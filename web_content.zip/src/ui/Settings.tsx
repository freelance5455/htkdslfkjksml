import { useEffect, useState } from 'react';
import { Screen, Panel, Slider, Toggle, Choice, MenuButton, useStore } from './common';
import { store, PRESETS, recommendPreset, ACTION_LABELS, DEFAULT_BINDINGS, type Action, type Settings as S, type Preset } from '../game/save';
import { audio } from '../game/audio';
import { WEAPONS } from '../game/data/weapons';
import { DIFFICULTIES } from '../game/data/content';
import { cn } from '../utils/cn';

export type SettingsTab = 'graphics' | 'audio' | 'controls' | 'gameplay';
const keyLabel = (c: string) => c.replace('Key', '').replace('Digit', '').replace('Left', ' L').replace('Right', ' R');

export function SettingsScreen({ tab: initial, onBack }: { tab: SettingsTab; onBack: () => void }) {
  const s = useStore(); const st = s.settings;
  const [tab, setTab] = useState<SettingsTab>(initial);
  const [rebinding, setRebinding] = useState<Action | null>(null);
  const [rec] = useState(() => recommendPreset());
  const set = (fn: (x: S) => void) => store.setSettings(x => { fn(x); return x; });
  const setG = (fn: (g: S['graphics']) => void) => set(x => { fn(x.graphics); x.graphics.preset = 'custom'; });

  useEffect(() => {
    if (!rebinding) return;
    const h = (e: KeyboardEvent) => {
      e.preventDefault(); e.stopPropagation();
      if (e.code !== 'Escape') set(x => {
        // swap if key already used, so no action is left unbound by a duplicate
        const other = (Object.keys(x.controls.bindings) as Action[]).find(a => x.controls.bindings[a] === e.code && a !== rebinding);
        if (other) x.controls.bindings[other] = x.controls.bindings[rebinding];
        x.controls.bindings[rebinding] = e.code;
      });
      setRebinding(null);
    };
    window.addEventListener('keydown', h, true); return () => window.removeEventListener('keydown', h, true);
  }, [rebinding]); // eslint-disable-line react-hooks/exhaustive-deps

  const applyPreset = (p: Exclude<Preset, 'custom'>) => set(x => { x.graphics = { ...x.graphics, ...PRESETS[p], preset: p }; });
  const tabs: { id: SettingsTab; l: string }[] = [{ id: 'graphics', l: 'GRAPHICS' }, { id: 'audio', l: 'AUDIO' }, { id: 'controls', l: 'CONTROLS' }, { id: 'gameplay', l: 'GAMEPLAY' }];
  const g = st.graphics, a = st.audio, c = st.controls;
  return (
    <Screen title="SETTINGS" subtitle="SAVED AUTOMATICALLY TO THIS DEVICE" onBack={onBack}
      right={<div className="flex gap-1">{tabs.map(t => <button key={t.id} onClick={() => { audio.ui('select'); setTab(t.id); }} className={cn('px-2 sm:px-3 py-1.5 text-[10px] sm:text-xs font-bold tracking-widest clip-corner-sm', tab === t.id ? 'bg-amber-op text-black' : 'bg-white/10')}>{t.l}</button>)}</div>}>
      {tab === 'graphics' && (
        <div className="grid lg:grid-cols-2 gap-3">
          <Panel title="QUALITY PRESET" className="p-4 pt-1">
            <div className="flex gap-1 flex-wrap mb-2">
              {(['low', 'medium', 'high', 'ultra'] as const).map(p => <button key={p} onClick={() => { audio.ui('select'); applyPreset(p); }} className={cn('px-3 py-2 text-xs font-black tracking-widest clip-corner-sm', g.preset === p ? 'bg-amber-op text-black' : 'bg-white/10 hover:bg-white/20')}>{p.toUpperCase()}{rec.preset === p ? ' ★' : ''}</button>)}
              {g.preset === 'custom' && <span className="px-3 py-2 text-xs font-black tracking-widest bg-white/20">CUSTOM</span>}
            </div>
            <div className="text-[10px] text-white/45">★ Recommended for this device: <b className="text-amber-op">{rec.preset.toUpperCase()}</b> — {rec.reason}</div>
            <div className="text-[10px] text-white/35 mt-1">Frame rate depends on your hardware and browser; no specific FPS is guaranteed. Enable “Show FPS” to measure it.</div>
          </Panel>
          <Panel title="DISPLAY" className="p-4 pt-1">
            <Slider label="Field of view" value={g.fov} min={60} max={110} step={1} onChange={v => set(x => { x.graphics.fov = v; })} format={v => v + '°'} />
            <Slider label="Render scale" value={g.renderScale} min={0.5} max={1.5} step={0.05} onChange={v => setG(x => { x.renderScale = v; })} format={v => Math.round(v * 100) + '%'} />
            <Toggle label="Dynamic resolution" value={g.dynamicRes} onChange={v => setG(x => { x.dynamicRes = v; })} note="Lowers render scale when FPS drops" />
            <Choice label="Frame-rate limit" value={g.fpsLimit} options={[{ v: 0, l: 'DISPLAY SYNC' }, { v: 30, l: '30' }, { v: 60, l: '60' }, { v: 120, l: '120' }]} onChange={v => set(x => { x.graphics.fpsLimit = v; })} note="V-Sync is always on in browsers (requestAnimationFrame); the limit caps below the display rate." />
            <Toggle label="Show FPS counter" value={g.showFps} onChange={v => set(x => { x.graphics.showFps = v; })} />
          </Panel>
          <Panel title="RENDERING" className="p-4 pt-1">
            <Choice label="Shadows" value={g.shadows} options={[{ v: 0, l: 'OFF' }, { v: 1, l: 'LOW' }, { v: 2, l: 'HIGH' }, { v: 3, l: 'ULTRA' }]} onChange={v => setG(x => { x.shadows = v; })} note="1024 / 2048 / 4096 shadow maps" />
            <Choice label="Textures" value={g.textures} options={[{ v: 0, l: 'LOW' }, { v: 1, l: 'MEDIUM' }, { v: 2, l: 'HIGH' }]} onChange={v => setG(x => { x.textures = v; })} note="64 / 128 / 256px procedural, anisotropic filtering" />
            <Choice label="Effects" value={g.effects} options={[{ v: 0, l: 'LOW' }, { v: 1, l: 'MEDIUM' }, { v: 2, l: 'HIGH' }]} onChange={v => setG(x => { x.effects = v; })} note="Particle budget, tracers, decals" />
            <Slider label="View distance" value={g.viewDistance} min={100} max={400} step={10} onChange={v => setG(x => { x.viewDistance = v; })} format={v => v + 'm'} />
            <Toggle label="Anti-aliasing" value={g.antialias} onChange={v => setG(x => { x.antialias = v; })} note="MSAA — applies when the next match/menu starts" />
            <Toggle label="Motion blur" value={g.motionBlur} onChange={v => set(x => { x.graphics.motionBlur = v; })} note="Post-process; applies next match" />
          </Panel>
        </div>
      )}
      {tab === 'audio' && (
        <Panel title="VOLUME" className="p-4 pt-1 max-w-2xl">
          <Slider label="Master" value={a.master} min={0} max={1} onChange={v => set(x => { x.audio.master = v; })} format={v => Math.round(v * 100) + '%'} />
          <Slider label="Music" value={a.music} min={0} max={1} onChange={v => set(x => { x.audio.music = v; })} format={v => Math.round(v * 100) + '%'} />
          <Slider label="Sound effects" value={a.sfx} min={0} max={1} onChange={v => set(x => { x.audio.sfx = v; })} format={v => Math.round(v * 100) + '%'} />
          <Slider label="Dialogue" value={a.dialogue} min={0} max={1} onChange={v => set(x => { x.audio.dialogue = v; })} format={v => Math.round(v * 100) + '%'} />
          <div className="flex flex-wrap gap-2 mt-3">
            <MenuButton small onClick={() => audio.shot(WEAPONS[Math.floor(Math.random() * WEAPONS.length)].sound, false)}>Test SFX</MenuButton>
            <MenuButton small onClick={() => audio.stinger(true)}>Test music</MenuButton>
            <MenuButton small onClick={() => audio.announce('Radio check. Operation Shadow.')}>Test dialogue</MenuButton>
          </div>
          <p className="text-[10px] text-white/40 mt-3">All audio is synthesised in real time. Enemy gunfire and footsteps are spatialised in 3D.</p>
        </Panel>
      )}
      {tab === 'controls' && (
        <div className="grid lg:grid-cols-2 gap-3">
          <Panel title="AIM" className="p-4 pt-1">
            <Slider label="Mouse sensitivity" value={c.sensitivity} min={0.1} max={4} onChange={v => set(x => { x.controls.sensitivity = v; })} />
            <Slider label="ADS multiplier" value={c.adsSensitivity} min={0.2} max={1.5} onChange={v => set(x => { x.controls.adsSensitivity = v; })} />
            <Toggle label="Invert Y axis" value={c.invertY} onChange={v => set(x => { x.controls.invertY = v; })} />
            <Toggle label="Toggle ADS" value={c.toggleAds} onChange={v => set(x => { x.controls.toggleAds = v; })} note="Off = hold to aim" />
          </Panel>
          <Panel title="TOUCH CONTROLS" className="p-4 pt-1">
            <Choice label="Touch HUD" value={c.touchMode} options={[{ v: 'auto', l: 'AUTO' }, { v: 'on', l: 'ON' }, { v: 'off', l: 'OFF' }]} onChange={v => set(x => { x.controls.touchMode = v; })} note="Auto = shown only on touch devices" />
            <Slider label="Look sensitivity" value={c.touchSensitivity} min={0.2} max={3} onChange={v => set(x => { x.controls.touchSensitivity = v; })} />
            <Toggle label="Left-handed layout" value={c.leftHanded} onChange={v => set(x => { x.controls.leftHanded = v; })} />
            <Slider label="Button size" value={c.buttonScale} min={0.6} max={1.6} onChange={v => set(x => { x.controls.buttonScale = v; })} format={v => Math.round(v * 100) + '%'} />
            <Slider label="Button opacity" value={c.buttonOpacity} min={0.2} max={1} onChange={v => set(x => { x.controls.buttonOpacity = v; })} format={v => Math.round(v * 100) + '%'} />
            <Slider label="Fire button X" value={c.fireOffsetX} min={-150} max={150} step={1} onChange={v => set(x => { x.controls.fireOffsetX = v; })} format={v => v + 'px'} />
            <Slider label="Fire button Y" value={c.fireOffsetY} min={-150} max={150} step={1} onChange={v => set(x => { x.controls.fireOffsetY = v; })} format={v => v + 'px'} />
          </Panel>
          <Panel title="KEYBOARD BINDINGS" className="p-4 pt-1 lg:col-span-2">
            <div className="grid sm:grid-cols-2 gap-x-6">
              {(Object.keys(ACTION_LABELS) as Action[]).map(act => (
                <div key={act} className="flex items-center justify-between py-1 border-b border-white/5">
                  <span className="text-xs tracking-widest text-white/75">{ACTION_LABELS[act].toUpperCase()}</span>
                  <button onClick={() => { audio.ui('select'); setRebinding(act); }} className={cn('min-w-20 px-2 py-1 text-[11px] font-bold tracking-widest', rebinding === act ? 'bg-amber-op text-black anim-blink' : 'bg-white/10 hover:bg-white/20')}>{rebinding === act ? 'PRESS KEY' : keyLabel(c.bindings[act])}</button>
                </div>
              ))}
              <div className="flex items-center justify-between py-1 border-b border-white/5"><span className="text-xs tracking-widest text-white/50">FIRE / AIM</span><span className="text-[11px] text-white/50">LMB / RMB</span></div>
              <div className="flex items-center justify-between py-1 border-b border-white/5"><span className="text-xs tracking-widest text-white/50">PAUSE</span><span className="text-[11px] text-white/50">ESC</span></div>
            </div>
            <div className="mt-3"><MenuButton small onClick={() => set(x => { x.controls.bindings = { ...DEFAULT_BINDINGS }; })}>Reset bindings</MenuButton></div>
          </Panel>
        </div>
      )}
      {tab === 'gameplay' && (
        <Panel title="GAMEPLAY" className="p-4 pt-1 max-w-2xl">
          <Choice label="AI difficulty" value={st.gameplay.difficulty} options={DIFFICULTIES.map(d => ({ v: d.id, l: d.name }))} onChange={v => set(x => { x.gameplay.difficulty = v; })} note="Affects AI reaction time, accuracy, vision and health" />
          <Toggle label="Damage numbers" value={st.gameplay.damageNumbers} onChange={v => set(x => { x.gameplay.damageNumbers = v; })} />
          <Slider label="Screen shake" value={st.gameplay.screenShake} min={0} max={1.5} onChange={v => set(x => { x.gameplay.screenShake = v; })} format={v => Math.round(v * 100) + '%'} />
          <Toggle label="BR shrinking zone" value={st.gameplay.brZone} onChange={v => set(x => { x.gameplay.brZone = v; })} />
          <div className="flex flex-wrap gap-2 mt-4 pt-3 border-t border-white/10">
            <MenuButton small onClick={() => { if (confirm('Reset all settings to defaults?')) store.resetSettings(); }}>Reset settings</MenuButton>
            <MenuButton small onClick={() => { if (confirm('Erase ALL local progress, loadouts and high scores?')) store.resetProfile(); }}>Reset profile</MenuButton>
          </div>
        </Panel>
      )}
    </Screen>
  );
}
