import { useEffect, useRef, useState, type ReactNode } from "react";
import { engine } from "../game/engine";
import { RARITY_INFO, TREASURE_MAP, type Rarity } from "../game/data";
import { S, setScreen, ui, useStore, type Screen } from "../game/store";
import { audio } from "../game/audio";

export const fmt = (n: number) => Math.floor(n).toLocaleString();

let returnTo: Screen = "none";
export function openScreen(s: Screen, _pause = false) {
  void _pause;
  returnTo = ui.screen === "menu" ? "menu" : ui.screen === "pause" ? "pause" : "none";
  audio.open();
  setScreen(s);
}
export function closeSheet() {
  audio.back();
  const r = returnTo;
  returnTo = "none";
  setScreen(r);
}

export function CoinIcon({ size = 18 }: { size?: number }) {
  return (
    <span
      className="inline-block rounded-full align-middle"
      style={{
        width: size, height: size,
        background: "radial-gradient(circle at 35% 30%, #fff2a8, #ffc933 55%, #c78a0f)",
        boxShadow: "inset 0 -2px 0 rgba(120,70,0,.5), 0 1px 3px rgba(0,0,0,.5)",
      }}
    />
  );
}

export function TIcon({ id, size = 56, dim = false }: { id: string; size?: number; dim?: boolean }) {
  useStore();
  const src = engine.getIcon(id);
  if (!src) return <div style={{ width: size, height: size }} className="rounded-xl bg-white/5" />;
  return (
    <img
      src={src} width={size} height={size} draggable={false} alt=""
      style={{ width: size, height: size, filter: dim ? "brightness(0) opacity(.45)" : "drop-shadow(0 4px 4px rgba(0,0,0,.45))", objectFit: "contain" }}
    />
  );
}

export function RarityTag({ r, small }: { r: Rarity; small?: boolean }) {
  const info = RARITY_INFO[r];
  return (
    <span
      className="head rounded-full px-2 uppercase"
      style={{ color: info.color, border: `1px solid ${info.color}66`, background: `${info.color}1f`, fontSize: small ? 10 : 12, lineHeight: small ? "16px" : "20px" }}
    >
      {info.name}
    </span>
  );
}

export function Sheet({ title, onClose, children, wide, right }: { title: string; onClose: () => void; children: ReactNode; wide?: boolean; right?: ReactNode }) {
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center fade" style={{ background: "rgba(8,5,3,.62)", padding: "max(8px, env(safe-area-inset-top)) max(8px, env(safe-area-inset-right)) max(8px, env(safe-area-inset-bottom)) max(8px, env(safe-area-inset-left))" }}>
      <div className={`panel sheet flex w-full flex-col overflow-hidden rounded-3xl ${wide ? "max-w-5xl" : "max-w-2xl"}`} style={{ maxHeight: "100%", height: wide ? "100%" : "auto" }}>
        <div className="flex items-center gap-3 border-b px-4 py-2.5" style={{ borderColor: "var(--line)" }}>
          <h2 className="head m-0 flex-1 text-2xl" style={{ color: "var(--gold)" }}>{title}</h2>
          {right}
          <button className="round h-10 w-10 text-lg" onClick={onClose} aria-label="Close">✕</button>
        </div>
        <div className="scroll flex-1 p-3 sm:p-4">{children}</div>
      </div>
    </div>
  );
}

export function Confirm({ title, body, cost, onYes, onNo, yes = "Confirm" }: { title: string; body: ReactNode; cost?: number; onYes: () => void; onNo: () => void; yes?: string }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center fade" style={{ background: "rgba(0,0,0,.6)" }}>
      <div className="panel pop scroll w-[min(92vw,380px)] rounded-3xl p-5 text-center" style={{ maxHeight: "94vh" }}>
        <h3 className="head m-0 mb-2 text-2xl" style={{ color: "var(--gold)" }}>{title}</h3>
        <div className="mb-3 text-sm" style={{ color: "var(--mut)" }}>{body}</div>
        {cost !== undefined && (
          <div className="head mb-4 text-2xl">
            <CoinIcon size={22} /> {fmt(cost)}
          </div>
        )}
        <div className="flex gap-3">
          <button className="btn ghost flex-1" onClick={onNo}>Cancel</button>
          <button className="btn green flex-1" onClick={onYes}>{yes}</button>
        </div>
      </div>
    </div>
  );
}

/** 3D turntable of a treasure rendered through the main renderer */
export function Inspect({ id, onClose }: { id: string; onClose: () => void }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const [owned] = useState(() => S.inventory[id] || 0);
  const def = TREASURE_MAP[id];
  const drag = useRef<{ x: number; y: number; id: number } | null>(null);
  const yaw = useRef(0.4);
  const pitch = useRef(0.5);
  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    const loop = (t: number) => {
      const dt = (t - last) / 1000;
      last = t;
      if (!drag.current) yaw.current += dt * 0.9;
      if (ref.current) engine.renderTo(ref.current, id, yaw.current, pitch.current);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [id]);
  const info = RARITY_INFO[def.rarity];
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center fade" style={{ background: "rgba(0,0,0,.7)" }} onClick={onClose}>
      <div className="panel pop scroll relative w-[min(94vw,420px)] rounded-3xl p-4 text-center" onClick={(e) => e.stopPropagation()} style={{ boxShadow: `0 0 60px ${info.color}55`, maxHeight: "96vh" }}>
        <div className="absolute inset-0 -z-10 opacity-60" style={{ background: `radial-gradient(circle at 50% 30%, ${info.color}55, transparent 65%)` }} />
        <canvas
          ref={ref} width={256} height={256}
          className="mx-auto block touch-none"
          style={{ width: "min(62vw, 38vh, 260px)", height: "min(62vw, 38vh, 260px)", cursor: "grab" }}
          onPointerDown={(e) => { (e.target as HTMLElement).setPointerCapture(e.pointerId); drag.current = { x: e.clientX, y: e.clientY, id: e.pointerId }; }}
          onPointerMove={(e) => {
            const d = drag.current;
            if (!d) return;
            yaw.current += (e.clientX - d.x) * 0.012;
            pitch.current = Math.max(0.05, Math.min(1.3, pitch.current + (e.clientY - d.y) * 0.008));
            d.x = e.clientX; d.y = e.clientY;
          }}
          onPointerUp={() => (drag.current = null)}
          onPointerCancel={() => (drag.current = null)}
        />
        <div className="mb-1"><RarityTag r={def.rarity} /></div>
        <h3 className="head m-0 text-2xl">{def.name}</h3>
        <p className="mx-auto my-2 max-w-xs text-sm" style={{ color: "var(--mut)" }}>{def.desc}</p>
        <div className="mb-3 flex justify-center gap-4 text-sm">
          <span><CoinIcon size={16} /> <b>{fmt(def.value)}</b> value</span>
          <span>Owned: <b>{owned}</b></span>
          <span>{def.metal ? "Metallic" : "Mineral"}</span>
        </div>
        <button className="btn" onClick={onClose}>Close</button>
      </div>
    </div>
  );
}
