import { useSyncExternalStore, type ReactNode } from 'react';
import { store } from '../game/save';
import { audio } from '../game/audio';
import { cn } from '../utils/cn';

export function useStore() {
  useSyncExternalStore(store.subscribe.bind(store), () => store.version, () => store.version);
  return store;
}

export function Logo({ size = 1, animated = false }: { size?: number; animated?: boolean }) {
  return (
    <div className={cn('flex items-center gap-3 select-none', animated && 'animate-[logoReveal_1.6s_ease_both]')} style={{ transform: `scale(${size})`, transformOrigin: 'left center' }}>
      <svg width="54" height="54" viewBox="0 0 64 64" aria-hidden>
        <defs><linearGradient id="lg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#ffd27a" /><stop offset="1" stopColor="#d9820f" /></linearGradient></defs>
        <path d="M32 3 L58 13 V32 C58 47 46 57 32 61 C18 57 6 47 6 32 V13 Z" fill="#0d1114" stroke="url(#lg)" strokeWidth="3" />
        <path d="M14 30 C20 21 44 21 50 30 C44 39 20 39 14 30 Z" fill="none" stroke="url(#lg)" strokeWidth="2.5" />
        <circle cx="32" cy="30" r="6" fill="url(#lg)" />
        <path d="M32 14 V22 M32 38 V46 M18 30 H10 M54 30 H46" stroke="#f5a524" strokeWidth="2" />
        <path d="M20 50 L32 44 L44 50" fill="none" stroke="#f5a524" strokeWidth="2.5" />
      </svg>
      <div className="leading-none">
        <div className="text-[11px] tracking-[0.55em] text-amber-op/80 font-semibold">OPERATION</div>
        <div className="text-[34px] font-black tracking-[0.14em] text-white" style={{ textShadow: '0 0 24px rgba(245,165,36,0.25)' }}>SHADOW</div>
      </div>
    </div>
  );
}

export function MenuButton({ children, onClick, disabled, hint, primary, small, className, status }: { children: ReactNode; onClick?: () => void; disabled?: boolean; hint?: string; primary?: boolean; small?: boolean; className?: string; status?: string }) {
  return (
    <button
      disabled={disabled}
      onMouseEnter={() => !disabled && audio.ui('hover')}
      onClick={() => { if (disabled) return; audio.ui('select'); onClick?.(); }}
      title={hint}
      className={cn(
        'group relative overflow-hidden text-left clip-corner-sm transition-all duration-150 font-bold tracking-[0.18em] uppercase',
        small ? 'px-3 py-1.5 text-[11px]' : 'px-4 py-2 text-[13px]',
        primary ? 'bg-amber-op text-black hover:bg-amber-300' : 'bg-white/[0.06] text-white/90 hover:bg-white/[0.14] hover:text-white hover:pl-5',
        disabled && 'opacity-40 cursor-not-allowed hover:pl-4 hover:bg-white/[0.06]', className,
      )}
    >
      {!primary && <span className="absolute left-0 top-0 h-full w-[3px] bg-amber-op scale-y-0 group-hover:scale-y-100 transition-transform" />}
      <span className="relative flex items-center justify-between gap-3">
        <span>{children}</span>
        {status && <span className="text-[9px] tracking-widest font-semibold text-white/45 normal-case">{status}</span>}
      </span>
      {primary && <span className="absolute inset-y-0 w-1/3 bg-white/30 skew-x-12 animate-[sweep_2.4s_ease-in-out_infinite]" />}
    </button>
  );
}

export function Screen({ title, subtitle, onBack, children, right, wide }: { title: string; subtitle?: string; onBack: () => void; children: ReactNode; right?: ReactNode; wide?: boolean }) {
  return (
    <div className="absolute inset-0 flex flex-col anim-fade" style={{ paddingLeft: 'env(safe-area-inset-left)', paddingRight: 'env(safe-area-inset-right)' }}>
      <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/75 to-black/40 pointer-events-none" />
      <header className="relative flex items-center gap-4 px-4 sm:px-8 pt-3 sm:pt-5 pb-2 shrink-0">
        <button onClick={() => { audio.ui('back'); onBack(); }} className="clip-corner-sm bg-white/10 hover:bg-amber-op hover:text-black px-3 py-1.5 text-xs font-bold tracking-widest transition-colors">◀ BACK <span className="opacity-50 hidden sm:inline">[ESC]</span></button>
        <div>
          <h1 className="text-xl sm:text-3xl font-black tracking-[0.2em] text-white leading-none">{title}</h1>
          {subtitle && <p className="text-[10px] sm:text-xs tracking-[0.25em] text-amber-op/80 mt-1">{subtitle}</p>}
        </div>
        <div className="ml-auto">{right}</div>
      </header>
      <div className={cn('relative flex-1 min-h-0 px-4 sm:px-8 pb-4 scroll-y', wide ? '' : 'max-w-6xl')}>{children}</div>
    </div>
  );
}

export function Panel({ children, className, title }: { children: ReactNode; className?: string; title?: string }) {
  return (
    <div className={cn('relative bg-[#0c1014]/85 border border-white/10 clip-corner backdrop-blur-sm', className)}>
      {title && <div className="px-4 pt-3 pb-1 text-[10px] font-bold tracking-[0.3em] text-amber-op/90">{title}</div>}
      {children}
    </div>
  );
}

export function Slider({ label, value, min, max, step = 0.01, onChange, format }: { label: string; value: number; min: number; max: number; step?: number; onChange: (v: number) => void; format?: (v: number) => string }) {
  return (
    <label className="flex items-center gap-3 py-1.5">
      <span className="w-40 shrink-0 text-xs tracking-widest text-white/75 uppercase">{label}</span>
      <input type="range" min={min} max={max} step={step} value={value} onChange={e => onChange(parseFloat(e.target.value))} />
      <span className="w-14 text-right text-xs font-bold text-amber-op tabular-nums">{format ? format(value) : value.toFixed(2)}</span>
    </label>
  );
}

export function Toggle({ label, value, onChange, note }: { label: string; value: boolean; onChange: (v: boolean) => void; note?: string }) {
  return (
    <div className="flex items-center gap-3 py-1.5">
      <span className="w-40 shrink-0 text-xs tracking-widest text-white/75 uppercase">{label}</span>
      <button onClick={() => { audio.ui('select'); onChange(!value); }} className={cn('relative w-12 h-6 clip-corner-sm transition-colors', value ? 'bg-amber-op' : 'bg-white/15')}>
        <span className={cn('absolute top-1 w-4 h-4 bg-black transition-all', value ? 'left-7' : 'left-1')} />
      </button>
      {note && <span className="text-[10px] text-white/40">{note}</span>}
    </div>
  );
}

export function Choice<T extends string | number>({ label, value, options, onChange, note }: { label: string; value: T; options: { v: T; l: string }[]; onChange: (v: T) => void; note?: string }) {
  return (
    <div className="flex items-center gap-3 py-1.5 flex-wrap">
      <span className="w-40 shrink-0 text-xs tracking-widest text-white/75 uppercase">{label}</span>
      <div className="flex gap-1 flex-wrap">
        {options.map(o => (
          <button key={String(o.v)} onClick={() => { audio.ui('select'); onChange(o.v); }} className={cn('px-2.5 py-1 text-[11px] font-bold tracking-widest clip-corner-sm transition-colors', o.v === value ? 'bg-amber-op text-black' : 'bg-white/10 hover:bg-white/20')}>{o.l}</button>
        ))}
      </div>
      {note && <span className="text-[10px] text-white/40 w-full sm:w-auto">{note}</span>}
    </div>
  );
}

export function StatBar({ label, value, base }: { label: string; value: number; base?: number }) {
  const diff = base !== undefined ? value - base : 0;
  return (
    <div className="flex items-center gap-2 text-[10px] tracking-widest">
      <span className="w-20 text-white/60 uppercase">{label}</span>
      <div className="relative flex-1 h-1.5 bg-white/10">
        <div className="absolute inset-y-0 left-0 bg-white/80" style={{ width: `${Math.min(value, base ?? value)}%` }} />
        {diff > 0.5 && <div className="absolute inset-y-0 bg-green-400" style={{ left: `${base}%`, width: `${diff}%` }} />}
        {diff < -0.5 && <div className="absolute inset-y-0 bg-red-500" style={{ left: `${value}%`, width: `${-diff}%` }} />}
      </div>
      <span className={cn('w-8 text-right tabular-nums', diff > 0.5 ? 'text-green-400' : diff < -0.5 ? 'text-red-400' : 'text-white/70')}>{Math.round(value)}</span>
    </div>
  );
}

export function LockBadge({ level }: { level: number }) {
  return <span className="inline-flex items-center gap-1 text-[9px] font-bold tracking-widest bg-black/60 text-white/70 px-1.5 py-0.5">🔒 LV {level}</span>;
}
