import { useEffect, useRef, useState } from 'react';
import { engine } from '../game/engine';
import { useHud, fmtMoney } from './useHud';
import { WEAPONS, WEAPON_ORDER, MISSIONS } from '../game/items';

type AppId =
  | 'home'
  | 'shop'
  | 'maps'
  | 'bank'
  | 'weather'
  | 'messages'
  | 'music'
  | 'gallery'
  | 'settings'
  | 'missions'
  | 'contacts';

const APPS: { id: AppId; label: string; icon: string; color: string }[] = [
  { id: 'shop', label: 'Phone Shop', icon: '🛒', color: 'from-emerald-500 to-emerald-700' },
  { id: 'maps', label: 'Maps', icon: '🗺️', color: 'from-sky-500 to-sky-700' },
  { id: 'bank', label: 'Bank', icon: '🏦', color: 'from-amber-500 to-amber-700' },
  { id: 'messages', label: 'Messages', icon: '💬', color: 'from-indigo-500 to-indigo-700' },
  { id: 'weather', label: 'Weather', icon: '⛅', color: 'from-cyan-400 to-blue-600' },
  { id: 'music', label: 'Music', icon: '🎵', color: 'from-rose-500 to-rose-700' },
  { id: 'gallery', label: 'Gallery', icon: '🖼️', color: 'from-fuchsia-500 to-purple-700' },
  { id: 'missions', label: 'Jobs', icon: '📋', color: 'from-orange-500 to-orange-700' },
  { id: 'settings', label: 'Settings', icon: '⚙️', color: 'from-zinc-500 to-zinc-700' },
];

const MESSAGES = [
  { who: 'CHOP', text: 'Woof woof! 🐕 (He misses you)', time: '09:12' },
  { who: 'Mara', text: 'The M8 is ready. Drive safe.', time: '09:40' },
  { who: 'TORQUE Garage', text: 'Bring it in whenever, we open late.', time: '11:02' },
  { who: 'Unknown', text: 'Nice car. Where did you get it?', time: '11:55' },
];

export default function Phone() {
  const hud = useHud();
  const [app, setApp] = useState<AppId>('home');
  const mapRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (hud.phoneOpen && hud.phoneApp) setApp(hud.phoneApp as AppId);
  }, [hud.phoneOpen, hud.phoneApp]);

  useEffect(() => {
    if (app === 'maps' && mapRef.current) {
      engine.attachCanvases(null, mapRef.current);
      engine.drawBigMap();
    }
  }, [app]);

  if (!hud.phoneOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 backdrop-blur-sm p-4">
      <div
        className="relative w-[340px] max-w-[92vw] rounded-[38px] bg-gradient-to-b from-[#2a2d33] to-[#121417] p-[10px] shadow-[0_30px_80px_rgba(0,0,0,0.75)] border border-white/10"
        style={{ animation: 'phoneIn 0.32s cubic-bezier(0.2,0.9,0.3,1.2)' }}
      >
        {/* bezel + screen */}
        <div className="relative rounded-[30px] bg-[#08090c] overflow-hidden h-[620px] max-h-[76vh] flex flex-col">
          {/* status bar */}
          <div className="flex items-center justify-between px-5 pt-3 pb-1 text-[10px] text-white/80 bg-black">
            <span className="font-semibold tracking-wide">SOLSTICE</span>
            <span className="flex items-center gap-1">
              <span>📶</span>
              <span>🔋</span>
              <span>{Math.floor(hud.clock).toString().padStart(2, '0')}:00</span>
            </span>
          </div>

          {/* app content */}
          <div className="flex-1 overflow-y-auto bg-gradient-to-b from-[#0f1218] to-[#151922]">
            {app === 'home' && (
              <div className="p-4">
                <div className="text-white/80 text-sm font-semibold mb-3">Good day, Player</div>
                <div className="grid grid-cols-3 gap-4">
                  {APPS.map((a) => (
                    <button
                      key={a.id}
                      onClick={() => {
                        setApp(a.id);
                        engine.openPhoneApp(a.id);
                      }}
                      className="flex flex-col items-center gap-1.5 active:scale-95 transition"
                    >
                      <div
                        className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${a.color} flex items-center justify-center text-3xl shadow-lg border border-white/15`}
                      >
                        {a.icon}
                      </div>
                      <span className="text-[10px] text-white/70 text-center leading-tight">
                        {a.label}
                      </span>
                    </button>
                  ))}
                </div>
                <div className="mt-6 bg-white/5 rounded-xl p-3 border border-white/10">
                  <div className="text-[10px] text-white/45 tracking-widest">WALLET</div>
                  <div className="text-emerald-300 font-bold text-xl">{fmtMoney(hud.money)}</div>
                  <div className="text-[10px] text-white/40 mt-1">
                    Prepaid credit: {fmtMoney(hud.phoneBalance)}
                  </div>
                </div>
              </div>
            )}

            {app === 'shop' && <ShopApp />}
            {app === 'maps' && (
              <div className="p-3">
                <div className="text-[11px] tracking-widest text-white/50 mb-2">SOLSTICE CITY</div>
                <div className="rounded-xl overflow-hidden border border-white/15 aspect-square bg-[#171b20]">
                  <canvas ref={mapRef} width={620} height={620} className="w-full h-full" />
                </div>
                <div className="mt-3 text-[11px] text-white/60 leading-relaxed">
                  You are in <span className="text-amber-300">{hud.location}</span>. Yellow markers
                  show active job objectives.
                </div>
              </div>
            )}
            {app === 'bank' && (
              <div className="p-4 space-y-3">
                <div className="bg-gradient-to-br from-amber-500/30 to-amber-800/20 border border-amber-400/30 rounded-xl p-4">
                  <div className="text-[10px] text-white/50 tracking-widest">AVAILABLE BALANCE</div>
                  <div className="text-3xl font-bold text-amber-200">{fmtMoney(hud.money)}</div>
                </div>
                {[
                  ['Payday', '+', 1200],
                  ['Garage fees', '-', 350],
                  ['Fuel', '-', 80],
                  ['Job payment', '+', 2500],
                ].map(([l, s, v]) => (
                  <div
                    key={l as string}
                    className="flex items-center justify-between bg-white/5 rounded-lg px-3 py-2 border border-white/10"
                  >
                    <span className="text-[12px] text-white/75">{l as string}</span>
                    <span
                      className={`text-[12px] font-semibold ${
                        (s as string) === '+' ? 'text-emerald-300' : 'text-red-300'
                      }`}
                    >
                      {s as string}
                      {fmtMoney(v as number)}
                    </span>
                  </div>
                ))}
              </div>
            )}
            {app === 'weather' && (
              <div className="p-4">
                <div className="bg-gradient-to-br from-sky-600/40 to-blue-900/30 border border-white/10 rounded-xl p-5 text-center">
                  <div className="text-5xl">☀️</div>
                  <div className="text-2xl font-bold text-white mt-1">{hud.weather}</div>
                  <div className="text-white/60 text-sm">
                    {hud.temp}°C · {hud.location}
                  </div>
                </div>
                <div className="mt-3 space-y-2">
                  {[
                    ['Now', hud.weather, hud.temp],
                    ['+1h', 'Cloudy', hud.temp - 1],
                    ['+2h', 'Rain', hud.temp - 3],
                    ['+3h', 'Rain', hud.temp - 4],
                    ['+4h', 'Cloudy', hud.temp - 2],
                  ].map(([t, w, temp]) => (
                    <div
                      key={t as string}
                      className="flex items-center justify-between bg-white/5 rounded-lg px-3 py-2 border border-white/10 text-[12px]"
                    >
                      <span className="text-white/60 w-10">{t as string}</span>
                      <span className="text-white/85 flex-1">{w as string}</span>
                      <span className="text-white/70">{temp as number}°</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {app === 'messages' && (
              <div className="p-3 space-y-2">
                {MESSAGES.map((m) => (
                  <div key={m.who + m.time} className="bg-white/5 rounded-xl p-3 border border-white/10">
                    <div className="flex justify-between items-center">
                      <span className="text-[12px] font-semibold text-amber-300">{m.who}</span>
                      <span className="text-[10px] text-white/35">{m.time}</span>
                    </div>
                    <div className="text-[12px] text-white/75 mt-1">{m.text}</div>
                  </div>
                ))}
              </div>
            )}
            {app === 'music' && (
              <div className="p-4">
                <div className="bg-gradient-to-br from-rose-600/40 to-purple-900/30 border border-white/10 rounded-xl p-4">
                  <div className="h-32 rounded-lg bg-gradient-to-br from-fuchsia-400/60 to-indigo-600/60 flex items-center justify-center text-5xl">
                    🎧
                  </div>
                  <div className="mt-3 text-white font-semibold">Midnight in Solstice</div>
                  <div className="text-[11px] text-white/50">The Coastline Radio</div>
                  <div className="mt-3 h-1 bg-white/15 rounded-full">
                    <div className="h-full w-2/5 bg-white/80 rounded-full" />
                  </div>
                  <div className="flex items-center justify-center gap-6 mt-3 text-white/80 text-lg">
                    <span>⏮</span>
                    <span className="text-3xl">⏸</span>
                    <span>⏭</span>
                  </div>
                </div>
              </div>
            )}
            {app === 'gallery' && (
              <div className="p-3 grid grid-cols-3 gap-2">
                {Array.from({ length: 12 }).map((_, i) => (
                  <div
                    key={i}
                    className="aspect-square rounded-lg"
                    style={{
                      background: `linear-gradient(${(i * 47) % 360}deg, hsl(${(i * 53) % 360} 55% 45%), hsl(${
                        (i * 91) % 360
                      } 60% 25%))`,
                    }}
                  />
                ))}
              </div>
            )}
            {app === 'missions' && (
              <div className="p-3 space-y-2">
                {hud.missions.map((m) => (
                  <div key={m.id} className="bg-white/5 rounded-xl p-3 border border-white/10">
                    <div className="flex justify-between items-start gap-2">
                      <span className="text-[13px] font-semibold text-white">{m.title}</span>
                      <span className="text-[11px] text-emerald-300 shrink-0">+{fmtMoney(m.reward)}</span>
                    </div>
                    <p className="text-[11px] text-white/55 mt-1">{m.brief}</p>
                    <button
                      disabled={m.state === 'done'}
                      onClick={() => engine.startMission(m.id)}
                      className={`mt-2 text-[10px] font-bold tracking-wider rounded px-3 py-1.5 ${
                        m.state === 'done'
                          ? 'bg-white/10 text-white/35'
                          : 'bg-amber-500 text-black active:scale-95'
                      }`}
                    >
                      {m.state === 'done' ? 'COMPLETED' : m.state === 'active' ? 'RESTART' : 'START JOB'}
                    </button>
                  </div>
                ))}
              </div>
            )}
            {app === 'settings' && <SettingsApp />}
          </div>

          {/* home bar / dock */}
          <div className="bg-black/90 border-t border-white/10 px-4 py-2 flex items-center justify-between">
            <button
              onClick={() => {
                setApp('home');
                engine.openPhoneApp('home');
              }}
              className="text-[11px] text-white/60 px-3 py-1.5 rounded-lg bg-white/5"
            >
              ⌂ Home
            </button>
            <button
              onClick={() => engine.closePhone()}
              className="text-[11px] text-white/60 px-3 py-1.5 rounded-lg bg-white/5"
            >
              ✕ Close
            </button>
          </div>
        </div>
        {/* side buttons */}
        <div className="absolute -right-[3px] top-32 w-[3px] h-12 bg-white/20 rounded" />
        <div className="absolute -left-[3px] top-28 w-[3px] h-8 bg-white/20 rounded" />
      </div>
    </div>
  );
}

function ShopApp() {
  const hud = useHud();
  const products = [
    { id: 'ammo', label: 'Pistol Rounds x40', price: 120, icon: '🔩' },
    { id: 'medkit', label: 'Field Medkit', price: 300, icon: '🩹' },
    { id: 'grenade', label: 'Frag Grenade', price: 450, icon: '💣' },
    { id: 'smoke', label: 'Smoke Grenade', price: 300, icon: '🌫️' },
    { id: 'sniper', label: 'Vector VX-9 Sniper', price: 4800, icon: '🎯' },
    { id: 'rpg', label: 'Skyfire RPG', price: 9000, icon: '🚀' },
    { id: 'eagle', label: 'Desert Vulture .50', price: 2200, icon: '🔫' },
    { id: 'wrench', label: 'Torque Wrench', price: 250, icon: '🔧' },
  ];
  return (
    <div className="p-3">
      <div className="bg-emerald-600/20 border border-emerald-400/30 rounded-xl p-3 mb-3">
        <div className="text-[11px] font-bold text-emerald-300 tracking-widest">CITY PHONE STORE</div>
        <div className="text-[10px] text-white/55">Balance {fmtMoney(hud.money)}</div>
      </div>
      <div className="space-y-2">
        {products.map((p) => {
          const owned = p.id === 'eagle' ? engine.ownsWeapon('eagle') : hud.inventory.some((i) => i.id === p.id);
          return (
            <div
              key={p.id}
              className="flex items-center gap-3 bg-white/5 rounded-xl p-3 border border-white/10"
            >
              <span className="text-2xl">{p.icon}</span>
              <div className="flex-1 min-w-0">
                <div className="text-[12px] font-semibold text-white truncate">{p.label}</div>
                <div className="text-[11px] text-amber-300">{fmtMoney(p.price)}</div>
              </div>
              <button
                onClick={() => {
                  if (p.id === 'eagle') {
                    if (engine.ownsWeapon('eagle')) return;
                    if (engine.money < p.price) {
                      engine.notify('Not enough money', 'bad');
                      return;
                    }
                    engine.money -= p.price;
                    engine.giveWeapon('eagle');
                    engine.notify(`Bought ${WEAPONS.eagle.name}`, 'good');
                  } else {
                    engine.buyItem(p.id, p.price);
                  }
                }}
                className={`text-[10px] font-bold tracking-wider rounded px-3 py-1.5 ${
                  owned ? 'bg-white/10 text-white/40' : 'bg-emerald-500 text-black active:scale-95'
                }`}
              >
                {owned ? 'OWNED' : 'BUY'}
              </button>
            </div>
          );
        })}
      </div>
      <div className="mt-3 text-[10px] text-white/35 text-center">
        Weapons appear in your inventory and the weapon wheel.
      </div>
    </div>
  );
}

function SettingsApp() {
  const [, force] = useState(0);
  const [vol, setVol] = useState(engine.masterVolume);
  const [quality, setQuality] = useState(engine.quality);
  useEffect(() => {
    const id = setInterval(() => force((v) => v + 1), 300);
    return () => clearInterval(id);
  }, []);
  return (
    <div className="p-4 space-y-3">
      <div className="bg-white/5 rounded-xl p-3 border border-white/10">
        <div className="text-[11px] text-white/60 mb-2">MASTER VOLUME</div>
        <input
          type="range"
          min={0}
          max={100}
          value={Math.round(vol * 100)}
          onChange={(e) => {
            const v = e.target.valueAsNumber / 100;
            setVol(v);
            engine.masterVolume = v;
            engine.setVolume(v);
          }}
          className="w-full accent-amber-500"
        />
      </div>
      <div className="bg-white/5 rounded-xl p-3 border border-white/10">
        <div className="text-[11px] text-white/60 mb-2">GRAPHICS</div>
        <div className="flex gap-2">
          {(['low', 'medium', 'high'] as const).map((q) => (
            <button
              key={q}
              onClick={() => {
                setQuality(q);
                engine.setQuality(q);
              }}
              className={`flex-1 text-[10px] font-bold rounded py-2 ${
                quality === q ? 'bg-amber-500 text-black' : 'bg-white/10 text-white/60'
              }`}
            >
              {q.toUpperCase()}
            </button>
          ))}
        </div>
      </div>
      <div className="bg-white/5 rounded-xl p-3 border border-white/10 text-[11px] text-white/60">
        <div className="text-white/80 font-semibold mb-1">Inventory</div>
        <div className="grid grid-cols-2 gap-1">
          {WEAPON_ORDER.map((w) => (
            <div key={w} className="flex items-center gap-2">
              <span>{WEAPONS[w].icon}</span>
              <span className="truncate">{WEAPONS[w].short}</span>
            </div>
          ))}
        </div>
        <div className="mt-2 text-white/40">Total jobs: {MISSIONS.length}</div>
      </div>
    </div>
  );
}
