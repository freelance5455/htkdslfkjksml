import { useEffect, useRef, useState } from 'react';
import { Game, type GameOptions, type HudState } from '../game/Game';
import { HUD } from './HUD';
import { TouchControls } from './TouchControls';
import { RangeArmory } from './Loadout';
import { SettingsScreen } from './Settings';
import { MenuButton, Panel, useStore } from './common';
import { applyMatchResult, isTouchDevice, store, type MatchResult, type MatchRewards } from '../game/save';
import { MODES, MAP_NAMES, levelFromXp, type MapId } from '../game/data/content';
import { audio } from '../game/audio';
import { cn } from '../utils/cn';

export function GameView({ opts, onExit, onRestart }: { opts: GameOptions; onExit: () => void; onRestart: () => void }) {
  const s = useStore();
  const wrap = useRef<HTMLDivElement>(null); const hudCanvas = useRef<HTMLCanvasElement>(null); const gameRef = useRef<Game | null>(null);
  const [hud, setHud] = useState<HudState | null>(null);
  const [paused, setPaused] = useState(false);
  const [armory, setArmory] = useState(false);
  const [result, setResult] = useState<{ r: MatchResult; rw: MatchRewards } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [portrait, setPortrait] = useState(false);
  const [started, setStarted] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const touch = s.settings.controls.touchMode === 'on' || (s.settings.controls.touchMode === 'auto' && isTouchDevice());

  useEffect(() => {
    let g: Game | null = null;
    try {
      g = new Game(wrap.current!, hudCanvas.current!, opts, {
        onEnd: r => { const rw = applyMatchResult(r); setResult({ r, rw }); setPaused(false); setArmory(false); },
        onPause: p => setPaused(p),
      });
      gameRef.current = g;
      if (!(store.settings.controls.touchMode === 'on' || (store.settings.controls.touchMode === 'auto' && isTouchDevice()))) g.setPaused(true);
    } catch (e) { console.error(e); setError(String((e as Error)?.message ?? e)); return; }
    const iv = setInterval(() => { if (gameRef.current) setHud(gameRef.current.getHud()); }, 100);
    return () => { clearInterval(iv); g?.dispose(); gameRef.current = null; };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // fullscreen + landscape lock on touch devices
  useEffect(() => {
    if (!touch) return;
    const el = document.documentElement;
    el.requestFullscreen?.().then(() => (screen.orientation as unknown as { lock?: (o: string) => Promise<void> })?.lock?.('landscape').catch(() => {})).catch(() => {});
    const chk = () => setPortrait(window.innerHeight > window.innerWidth);
    chk(); window.addEventListener('resize', chk);
    return () => { window.removeEventListener('resize', chk); if (document.fullscreenElement) document.exitFullscreen?.().catch(() => {}); };
  }, [touch]);

  // keyboard: armory (B), pause fallback (Esc w/o pointer lock), instant restart (R) on results
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      const g = gameRef.current;
      if (result) { if (e.code === 'KeyR') onRestart(); if (e.code === 'Escape') onExit(); return; }
      if (!g) return;
      if (e.code === 'KeyB' && opts.mode === 'range') {
        if (armory) { setArmory(false); g.setPaused(false); } else { setArmory(true); g.setPaused(true); }
      }
      if (showSettings) { if (e.code === 'Escape') setShowSettings(false); return; }
      // Pausing via keys; resuming always requires a click (browsers block pointer-lock requests from Esc)
      if ((e.code === 'Escape' || e.code === 'KeyP') && !armory && (started || touch) && !g.paused) g.setPaused(true);
    };
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
  }, [result, armory, opts.mode, started, touch, onRestart, onExit, showSettings]);

  const resume = () => { setArmory(false); gameRef.current?.setPaused(false); setStarted(true); };
  const clickToPlay = () => { audio.unlock(); if (!touch && started) gameRef.current?.requestLock(); };

  if (error) return (
    <div className="absolute inset-0 flex items-center justify-center bg-black p-6">
      <Panel className="p-5 max-w-md text-center"><div className="text-red-400 font-black tracking-widest mb-2">FAILED TO START MATCH</div><div className="text-xs text-white/60 mb-4">{error}</div><MenuButton primary onClick={onExit}>Return to menu</MenuButton></Panel>
    </div>
  );

  const modeName = MODES.find(m => m.id === opts.mode)?.name ?? '';
  return (
    <div className="absolute inset-0 bg-black overflow-hidden" style={{ touchAction: 'none' }}>
      <div ref={wrap} className="absolute inset-0" onClick={clickToPlay} />
      <canvas ref={hudCanvas} className="absolute inset-0 pointer-events-none z-[5]" />
      {hud && !result && <HUD h={hud} touch={touch} showFps={s.settings.graphics.showFps}
        onArmory={() => { setArmory(true); gameRef.current?.setPaused(true); }}
        onRangeReset={() => gameRef.current?.resetRangeStats()} onRangeEnd={() => gameRef.current?.endRangeSession()} />}
      {touch && !paused && !result && hud && <TouchControls mode={opts.mode} onPause={() => gameRef.current?.setPaused(true)} onArmory={opts.mode === 'range' ? () => { setArmory(true); gameRef.current?.setPaused(true); } : undefined} />}
      {!touch && !started && !result && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/40 cursor-pointer" onClick={resume}>
          <div className="text-center anim-pop">
            <div className="text-3xl sm:text-4xl font-black tracking-[0.3em]">CLICK TO ENGAGE</div>
            <div className="text-xs tracking-[0.3em] text-white/60 mt-2">WASD MOVE · MOUSE AIM · LMB FIRE · RMB ADS · R RELOAD · SHIFT SPRINT · C CROUCH/SLIDE · E USE · ESC PAUSE</div>
          </div>
        </div>
      )}
      {armory && !result && <RangeArmory onClose={resume} onEquip={(slot, id, att, skin) => { gameRef.current?.setWeaponFromArmory(slot, id, att, skin); audio.pickup(); }} />}
      {paused && started && !armory && !result && !showSettings && (
        <div className="absolute inset-0 z-40 bg-black/70 backdrop-blur-sm flex items-center justify-center anim-fade">
          <Panel className="p-5 w-80 max-w-[92vw]">
            <div className="text-[10px] tracking-[0.3em] text-amber-op">{modeName} · {MAP_NAMES[opts.map]}</div>
            <div className="text-3xl font-black tracking-[0.25em] mb-4">PAUSED</div>
            <div className="flex flex-col gap-1.5">
              <MenuButton primary onClick={resume}>Resume</MenuButton>
              <MenuButton onClick={onRestart}>Restart match</MenuButton>
              <MenuButton onClick={() => setShowSettings(true)}>Settings</MenuButton>
              <MenuButton onClick={onExit}>Quit to main menu</MenuButton>
            </div>
            <div className="text-[10px] text-white/40 mt-3">Local simulation is fully paused. Quitting forfeits match rewards.</div>
          </Panel>
        </div>
      )}
      {showSettings && !result && <div className="absolute inset-0 z-[45] bg-black/85"><SettingsScreen tab="graphics" onBack={() => setShowSettings(false)} /></div>}
      {result && <Results r={result.r} rw={result.rw} onRestart={onRestart} onExit={onExit} />}
      {portrait && touch && !result && <div className="absolute inset-0 z-50 bg-black/90 flex flex-col items-center justify-center text-center p-6"><div className="text-5xl mb-3">⟳</div><div className="font-black tracking-[0.3em]">ROTATE TO LANDSCAPE</div><div className="text-xs text-white/50 mt-2">Operation Shadow is played in landscape orientation.</div></div>}
    </div>
  );
}

function Results({ r, rw, onRestart, onExit }: { r: MatchResult; rw: MatchRewards; onRestart: () => void; onExit: () => void }) {
  const p = store.profile; const lv = levelFromXp(p.xp);
  const scores = p.highscores.filter(h => h.mode === r.mode).sort((a, b) => b.score - a.score).slice(0, 5);
  const stats: [string, string | number][] = [['Eliminations', r.kills], ['Deaths', r.deaths], ['Headshots', r.headshots], ['Accuracy', rw.accuracy + '%'], ['Time', `${Math.floor(r.time / 60)}:${String(r.time % 60).padStart(2, '0')}`]];
  if (r.placement) stats.push(['Placement', '#' + r.placement]);
  if (r.teamScore) stats.push(['Team Score', `${r.teamScore[0]} – ${r.teamScore[1]}`]);
  if (r.mode === 'range') stats.push(['Targets', r.rangeTargets]);
  return (
    <div className="absolute inset-0 z-50 bg-black/80 backdrop-blur flex items-center justify-center p-3 anim-fade scroll-y">
      <div className="w-full max-w-3xl">
        <div className={cn('text-center text-3xl sm:text-6xl font-black tracking-[0.25em] anim-pop', r.victory ? 'text-amber-op' : 'text-red-400')} style={{ textShadow: '0 0 40px currentColor' }}>{r.victory ? 'VICTORY' : 'DEFEAT'}</div>
        <div className="text-center text-xs sm:text-sm tracking-[0.35em] text-white/70 mt-1">{r.resultText} · {MAP_NAMES[r.map as MapId] ?? r.map}</div>
        <div className="grid sm:grid-cols-[1fr_260px] gap-3 mt-4">
          <Panel className="p-4">
            <div className="flex items-end gap-3">
              <div><div className="text-[10px] tracking-[0.3em] text-white/50">SCORE</div><div className="text-4xl font-black tabular-nums">{r.score.toLocaleString()}</div></div>
              {rw.newHigh && <div className="mb-1 bg-amber-op text-black text-[10px] font-black tracking-widest px-2 py-1 anim-glow">NEW HIGH SCORE</div>}
              {!rw.newHigh && rw.rank >= 0 && <div className="mb-1 text-[10px] text-amber-op font-bold tracking-widest">#{rw.rank + 1} ON LOCAL BOARD</div>}
            </div>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 mt-3">{stats.map(([k, v]) => <div key={k} className="bg-white/5 p-2"><div className="text-[9px] tracking-widest text-white/50 uppercase">{k}</div><div className="text-lg font-black">{v}</div></div>)}</div>
            <div className="mt-3">
              <div className="flex justify-between text-[10px] tracking-widest"><span className="text-white/60">+{rw.xpEarned} XP</span><span className="text-amber-op font-bold">LEVEL {lv.level}{rw.levelAfter > rw.levelBefore ? ' ▲ LEVEL UP!' : ''}</span></div>
              <div className="h-2 bg-white/10 mt-1"><div className="h-full bg-amber-op transition-all duration-1000" style={{ width: `${(lv.into / lv.need) * 100}%` }} /></div>
            </div>
          </Panel>
          <Panel title="LOCAL TOP 5" className="p-3 pt-1">
            {scores.map((h, i) => <div key={i} className={cn('flex justify-between text-xs py-0.5 border-b border-white/5', h.date === p.highscores.find(x => x.score === r.score && x.mode === r.mode)?.date && 'text-amber-op')}><span className="font-black w-5">{i + 1}</span><span className="flex-1 font-bold tabular-nums">{h.score.toLocaleString()}</span><span className="text-white/45">{h.kills}K</span></div>)}
          </Panel>
        </div>
        <div className="flex gap-2 justify-center mt-4">
          <button onClick={() => { audio.ui('select'); onRestart(); }} className="anim-glow clip-corner bg-amber-op hover:bg-amber-300 text-black px-6 py-3 font-black tracking-[0.25em]">↻ PLAY AGAIN <span className="opacity-60 text-xs">[R]</span></button>
          <button onClick={() => { audio.ui('back'); onExit(); }} className="clip-corner bg-white/10 hover:bg-white/20 px-6 py-3 font-black tracking-[0.25em]">MAIN MENU</button>
        </div>
      </div>
    </div>
  );
}
