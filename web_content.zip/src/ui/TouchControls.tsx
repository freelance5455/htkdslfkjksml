import { useEffect, useRef, type ReactNode } from 'react';
import { touchState, type TouchAction } from '../game/input';
import { useStore } from './common';
import type { ModeId } from '../game/data/content';

interface BtnProps { action: TouchAction; label: ReactNode; size: number; style: React.CSSProperties; toggle?: boolean; look?: boolean; opacity: number; accent?: boolean; onPress?: () => void }

function TouchBtn({ action, label, size, style, toggle, look, opacity, accent, onPress }: BtnProps) {
  const ref = useRef<HTMLDivElement>(null);
  const last = useRef<{ x: number; y: number } | null>(null);
  const down = (e: React.PointerEvent) => {
    e.preventDefault(); e.stopPropagation();
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    if (onPress) { onPress(); return; }
    if (toggle) { if (touchState.held.has(action)) touchState.held.delete(action); else touchState.held.add(action); }
    else touchState.held.add(action);
    touchState.pressed.add(action);
    last.current = { x: e.clientX, y: e.clientY };
    ref.current?.classList.add('scale-90', 'brightness-150');
  };
  const move = (e: React.PointerEvent) => {
    if (!look || !last.current) return;
    touchState.lookDX += e.clientX - last.current.x; touchState.lookDY += e.clientY - last.current.y;
    last.current = { x: e.clientX, y: e.clientY };
  };
  const up = (e: React.PointerEvent) => {
    e.preventDefault();
    if (!toggle) touchState.held.delete(action);
    last.current = null; ref.current?.classList.remove('scale-90', 'brightness-150');
  };
  const active = toggle && touchState.held.has(action);
  return (
    <div ref={ref} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up}
      className={`absolute rounded-full flex items-center justify-center font-black tracking-wider select-none transition-transform duration-75 border-2 ${accent ? 'bg-red-600/70 border-red-300/70 text-white' : active ? 'bg-amber-op/80 border-amber-200 text-black' : 'bg-black/45 border-white/40 text-white'}`}
      style={{ width: size, height: size, fontSize: Math.max(9, size * 0.2), opacity, touchAction: 'none', ...style }}>
      {label}
    </div>
  );
}

export function TouchControls({ mode, onPause, onArmory }: { mode: ModeId; onPause: () => void; onArmory?: () => void }) {
  const s = useStore(); const c = s.settings.controls;
  const k = c.buttonScale; const op = c.buttonOpacity; const lh = c.leftHanded;
  const joyBase = useRef<HTMLDivElement>(null); const joyKnob = useRef<HTMLDivElement>(null);
  const joy = useRef<{ id: number; ox: number; oy: number } | null>(null);
  const looks = useRef(new Map<number, { x: number; y: number }>());

  useEffect(() => () => touchState.reset(), []);
  useEffect(() => { touchState.active = true; return () => { touchState.active = false; }; }, []);

  const R = 60 * k;
  const onDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    const w = window.innerWidth; const isMoveSide = lh ? e.clientX > w * 0.6 : e.clientX < w * 0.4;
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    if (isMoveSide && !joy.current) {
      joy.current = { id: e.pointerId, ox: e.clientX, oy: e.clientY };
      if (joyBase.current) { joyBase.current.style.left = e.clientX - R + 'px'; joyBase.current.style.top = e.clientY - R + 'px'; joyBase.current.style.opacity = '1'; }
    } else looks.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
  };
  const onMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (joy.current && e.pointerId === joy.current.id) {
      let dx = e.clientX - joy.current.ox, dy = e.clientY - joy.current.oy; const d = Math.hypot(dx, dy);
      if (d > R) { dx = (dx / d) * R; dy = (dy / d) * R; }
      touchState.moveX = dx / R; touchState.moveY = dy / R;
      if (joyKnob.current) joyKnob.current.style.transform = `translate(${dx}px, ${dy}px)`;
      return;
    }
    const l = looks.current.get(e.pointerId);
    if (l) { touchState.lookDX += e.clientX - l.x; touchState.lookDY += e.clientY - l.y; l.x = e.clientX; l.y = e.clientY; }
  };
  const onUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (joy.current && e.pointerId === joy.current.id) {
      joy.current = null; touchState.moveX = 0; touchState.moveY = 0;
      if (joyKnob.current) joyKnob.current.style.transform = 'translate(0,0)';
      if (joyBase.current) joyBase.current.style.opacity = '0.35';
    }
    looks.current.delete(e.pointerId);
  };

  // right-cluster positions (mirrored when left-handed)
  const side = (px: number) => (lh ? { left: px } : { right: px });
  const B = 64 * k, S = 50 * k, F = 92 * k;
  const fx = 40 * k + c.fireOffsetX * (lh ? -1 : 1) * -1, fy = 60 * k - c.fireOffsetY;
  return (
    <div className="absolute inset-0 z-20" style={{ touchAction: 'none' }} onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp}>
      {/* joystick */}
      <div ref={joyBase} className="absolute rounded-full border-2 border-white/30 bg-black/25 pointer-events-none" style={{ width: R * 2, height: R * 2, left: lh ? undefined : 70 * k, right: lh ? 70 * k : undefined, bottom: 50 * k, opacity: 0.35 }}>
        <div ref={joyKnob} className="absolute rounded-full bg-white/60" style={{ width: R * 0.8, height: R * 0.8, left: R - R * 0.4, top: R - R * 0.4 }} />
      </div>
      <div className="absolute text-[9px] tracking-widest text-white/35 pointer-events-none" style={{ bottom: 18, ...(lh ? { right: 80 } : { left: 80 }) }}>MOVE · PUSH UP FULLY TO SPRINT</div>
      {/* action cluster */}
      <TouchBtn action="fire" label="FIRE" size={F} opacity={op} accent look style={{ bottom: fy, ...side(fx) }} />
      <TouchBtn action="ads" label="AIM" size={B} opacity={op} toggle style={{ bottom: fy + F + 14 * k, ...side(fx + 10 * k) }} />
      <TouchBtn action="jump" label="JUMP" size={B} opacity={op} style={{ bottom: fy - 10 * k, ...side(fx + F + 16 * k) }} />
      <TouchBtn action="crouch" label="CROUCH" size={S} opacity={op} style={{ bottom: 14 * k, ...side(fx + F + 10 * k + B) }} />
      <TouchBtn action="reload" label="RELOAD" size={S} opacity={op} style={{ bottom: fy + F * 0.6, ...side(fx + F + 22 * k) }} />
      <TouchBtn action="sprint" label="SPRINT" size={S} opacity={op} toggle style={{ bottom: fy + F + B * 0.5, ...side(fx + F + 30 * k) }} />
      <TouchBtn action="swap" label="⇄" size={S} opacity={op} style={{ bottom: fy + F + 26 * k + B, ...side(fx + 20 * k) }} />
      <TouchBtn action="interact" label="USE" size={S} opacity={op} style={{ bottom: fy + F + B + 30 * k, ...side(fx + F + 30 * k) }} />
      {mode === 'br' && <>
        <TouchBtn action="heal" label="✚" size={S * 0.9} opacity={op} style={{ top: 120 * k, ...side(14) }} />
        <TouchBtn action="plate" label="▣" size={S * 0.9} opacity={op} style={{ top: 120 * k + S + 8, ...side(14) }} />
      </>}
      {onArmory && <TouchBtn action="inspect" label="ARMS" size={S * 0.9} opacity={op} onPress={onArmory} style={{ top: 120 * k, ...side(14) }} />}
      <TouchBtn action="pause" label="❚❚" size={44} opacity={op} onPress={onPause} style={{ top: 10, left: '50%', marginLeft: -22 }} />
    </div>
  );
}
