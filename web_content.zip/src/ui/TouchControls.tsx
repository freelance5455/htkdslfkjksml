import React, { useState, useRef } from 'react';
import { ChevronUp, ArrowUp, Zap } from 'lucide-react';
import { audioSystem } from '../audio/audioManager';

interface TouchControlsProps {
  onMoveChange: (move: { forward: number; right: number }) => void;
  onJump: () => void;
  onAction: () => void;
}

export const TouchControls: React.FC<TouchControlsProps> = ({
  onMoveChange,
  onJump,
  onAction,
}) => {
  const [knobPos, setKnobPos] = useState({ x: 0, y: 0 });
  const stickBaseRef = useRef<HTMLDivElement | null>(null);
  const touchIdRef = useRef<number | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    e.preventDefault();
    if (!stickBaseRef.current) return;
    const touch = e.changedTouches[0];
    touchIdRef.current = touch.identifier;
    updateStick(touch.clientX, touch.clientY);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    e.preventDefault();
    if (!stickBaseRef.current || touchIdRef.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === touchIdRef.current) {
        updateStick(touch.clientX, touch.clientY);
        break;
      }
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    e.preventDefault();
    setKnobPos({ x: 0, y: 0 });
    touchIdRef.current = null;
    onMoveChange({ forward: 0, right: 0 });
  };

  const updateStick = (clientX: number, clientY: number) => {
    if (!stickBaseRef.current) return;
    const rect = stickBaseRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const dx = clientX - centerX;
    const dy = clientY - centerY;
    const distance = Math.hypot(dx, dy);
    const maxRadius = rect.width / 2 - 10;

    let nx = dx;
    let ny = dy;

    if (distance > maxRadius) {
      nx = (dx / distance) * maxRadius;
      ny = (dy / distance) * maxRadius;
    }

    setKnobPos({ x: nx, y: ny });

    // Normalized move input (-1 to 1)
    const normRight = nx / maxRadius;
    const normForward = -ny / maxRadius; // Up is forward
    onMoveChange({ forward: normForward, right: normRight });
  };

  return (
    <div className="absolute inset-0 pointer-events-none z-30 flex items-end justify-between p-6 select-none">
      {/* Left Virtual Joystick */}
      <div
        ref={stickBaseRef}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onTouchCancel={handleTouchEnd}
        className="w-28 h-28 rounded-full bg-slate-900/60 backdrop-blur-sm border-2 border-cyan-500/40 pointer-events-auto flex items-center justify-center relative touch-none shadow-lg"
      >
        <div
          style={{ transform: `translate(${knobPos.x}px, ${knobPos.y}px)` }}
          className="w-12 h-12 rounded-full bg-gradient-to-tr from-cyan-600 to-sky-400 border border-white/50 shadow-md shadow-cyan-900/60 pointer-events-none transition-transform duration-75"
        />
      </div>

      {/* Right Action Buttons */}
      <div className="flex items-center space-x-3 pointer-events-auto">
        {/* Action / Laser button */}
        <button
          onClick={() => {
            onAction();
            audioSystem.playSound('synth_laser', { pitch: 1.3, volume: 0.5 });
          }}
          className="w-14 h-14 rounded-full bg-amber-600/80 hover:bg-amber-500 active:scale-95 text-white flex items-center justify-center border-2 border-amber-400/50 shadow-lg shadow-amber-950 font-bold text-xs"
        >
          <Zap className="w-6 h-6 fill-current" />
        </button>

        {/* Jump button */}
        <button
          onClick={() => {
            onJump();
            audioSystem.playSound('synth_jump', { pitch: 1.1, volume: 0.6 });
          }}
          className="w-16 h-16 rounded-full bg-cyan-600/80 hover:bg-cyan-500 active:scale-95 text-white flex items-center justify-center border-2 border-cyan-400/50 shadow-lg shadow-cyan-950 font-bold text-sm"
        >
          <ArrowUp className="w-7 h-7 stroke-[2.5]" />
        </button>
      </div>
    </div>
  );
};
