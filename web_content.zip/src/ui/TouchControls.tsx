import React from 'react';
import { GameEngine } from '../game/GameEngine';
import { ArrowLeft, ArrowRight, ArrowUp, ArrowDown, Flame, Disc } from 'lucide-react';
import { soundEngine } from '../audio/SoundSystem';

interface TouchControlsProps {
  engine: GameEngine | null;
}

export const TouchControls: React.FC<TouchControlsProps> = ({ engine }) => {
  if (!engine) return null;

  const setControl = (key: keyof typeof engine.controls, value: boolean) => {
    soundEngine.init();
    soundEngine.resume();
    engine.controls[key] = value;
    if (key === 'horn') {
      soundEngine.setHorn(value);
    }
  };

  return (
    <div className="fixed inset-0 pointer-events-none select-none z-20 flex justify-between items-end p-4 pb-20 md:hidden">
      {/* Steering controls (Left side) */}
      <div className="flex gap-3 pointer-events-auto">
        <button
          onTouchStart={() => setControl('left', true)}
          onTouchEnd={() => setControl('left', false)}
          onMouseDown={() => setControl('left', true)}
          onMouseUp={() => setControl('left', false)}
          className="w-16 h-16 rounded-2xl bg-slate-900/80 border-2 border-cyan-400/80 active:bg-cyan-500 active:text-black text-cyan-300 flex items-center justify-center shadow-lg active:scale-95 transition-all"
        >
          <ArrowLeft className="w-8 h-8" />
        </button>
        <button
          onTouchStart={() => setControl('right', true)}
          onTouchEnd={() => setControl('right', false)}
          onMouseDown={() => setControl('right', true)}
          onMouseUp={() => setControl('right', false)}
          className="w-16 h-16 rounded-2xl bg-slate-900/80 border-2 border-cyan-400/80 active:bg-cyan-500 active:text-black text-cyan-300 flex items-center justify-center shadow-lg active:scale-95 transition-all"
        >
          <ArrowRight className="w-8 h-8" />
        </button>
      </div>

      {/* Action Pedals (Right side) */}
      <div className="flex flex-col gap-2 items-end pointer-events-auto">
        <div className="flex gap-2">
          {/* Nitro */}
          <button
            onTouchStart={() => setControl('nitro', true)}
            onTouchEnd={() => setControl('nitro', false)}
            onMouseDown={() => setControl('nitro', true)}
            onMouseUp={() => setControl('nitro', false)}
            className="w-14 h-14 rounded-2xl bg-blue-900/80 border-2 border-blue-400/80 active:bg-cyan-400 active:text-black text-blue-300 flex flex-col items-center justify-center shadow-lg text-[10px] font-black active:scale-95"
          >
            <Flame className="w-5 h-5 text-yellow-300" />
            <span>NOS</span>
          </button>

          {/* Handbrake */}
          <button
            onTouchStart={() => setControl('handbrake', true)}
            onTouchEnd={() => setControl('handbrake', false)}
            onMouseDown={() => setControl('handbrake', true)}
            onMouseUp={() => setControl('handbrake', false)}
            className="w-14 h-14 rounded-2xl bg-pink-900/80 border-2 border-pink-400/80 active:bg-pink-500 active:text-black text-pink-300 flex flex-col items-center justify-center shadow-lg text-[10px] font-black active:scale-95"
          >
            <Disc className="w-5 h-5 text-pink-300" />
            <span>DRIFT</span>
          </button>
        </div>

        <div className="flex gap-3">
          {/* Brake / Reverse */}
          <button
            onTouchStart={() => setControl('backward', true)}
            onTouchEnd={() => setControl('backward', false)}
            onMouseDown={() => setControl('backward', true)}
            onMouseUp={() => setControl('backward', false)}
            className="w-16 h-20 rounded-2xl bg-red-950/80 border-2 border-red-500/80 active:bg-red-500 active:text-black text-red-300 flex flex-col items-center justify-center shadow-lg active:scale-95"
          >
            <ArrowDown className="w-7 h-7" />
            <span className="text-[10px] font-black">BRAKE</span>
          </button>

          {/* Gas / Accelerate */}
          <button
            onTouchStart={() => setControl('forward', true)}
            onTouchEnd={() => setControl('forward', false)}
            onMouseDown={() => setControl('forward', true)}
            onMouseUp={() => setControl('forward', false)}
            className="w-16 h-20 rounded-2xl bg-emerald-950/80 border-2 border-emerald-400/80 active:bg-emerald-500 active:text-black text-emerald-300 flex flex-col items-center justify-center shadow-lg active:scale-95"
          >
            <ArrowUp className="w-7 h-7" />
            <span className="text-[10px] font-black">GAS</span>
          </button>
        </div>
      </div>
    </div>
  );
};
