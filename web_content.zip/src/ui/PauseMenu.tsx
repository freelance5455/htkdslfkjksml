import { useState } from 'react';
import { engine } from '../game/engine';
import { useHud } from './useHud';

export default function PauseMenu() {
  const hud = useHud();
  const [tab, setTab] = useState<'main' | 'settings' | 'jobs' | 'controls'>('main');
  const [vol, setVol] = useState(engine.masterVolume);
  const [sens, setSens] = useState(engine.sensitivity * 1000);
  const [quality, setQuality] = useState(engine.quality);
  const [invert, setInvert] = useState(engine.invertY);

  if (!hud.paused) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-[#0d1016]/95 border border-white/12 rounded-2xl overflow-hidden shadow-2xl">
        <div className="px-6 py-4 border-b border-white/10 bg-gradient-to-r from-amber-500/15 to-transparent">
          <h2 className="text-white font-bold tracking-[0.3em] text-lg">SOLSTICE CITY</h2>
          <p className="text-[11px] text-white/45">Paused · {hud.location}</p>
        </div>

        {tab === 'main' && (
          <div className="p-5 grid grid-cols-2 sm:grid-cols-3 gap-3">
            {[
              ['RESUME', '▶', () => {
                engine.paused = false;
                setTimeout(() => engine.requestLock(), 60);
              }],
              ['MAP', '🗺️', () => {
                engine.paused = false;
                engine.mapOpen = true;
              }],
              ['JOBS', '📋', () => setTab('jobs')],
              ['SETTINGS', '⚙️', () => setTab('settings')],
              ['CONTROLS', '🎮', () => setTab('controls')],
              ['SAVE GAME', '💾', () => engine.save()],
              ['LOAD GAME', '📂', () => engine.load()],
              ['PHONE', '📱', () => {
                engine.paused = false;
                engine.togglePhone();
              }],
              ['NEW GAME', '🗑️', () => {
                if (confirm('Reset the game? Your progress will be lost.')) engine.resetGame();
              }],
            ].map(([label, icon, fn]) => (
              <button
                key={label as string}
                onClick={fn as () => void}
                className="bg-white/5 hover:bg-amber-500/90 hover:text-black text-white border border-white/10 rounded-xl py-4 flex flex-col items-center gap-1.5 transition text-[12px] font-bold tracking-wider"
              >
                <span className="text-2xl">{icon as string}</span>
                {label as string}
              </button>
            ))}
          </div>
        )}

        {tab === 'settings' && (
          <div className="p-5 space-y-4">
            <Row label="MASTER VOLUME">
              <input
                type="range"
                min={0}
                max={100}
                value={Math.round(vol * 100)}
                onChange={(e) => {
                  const v = e.target.valueAsNumber / 100;
                  setVol(v);
                  engine.setVolume(v);
                }}
                className="w-full accent-amber-500"
              />
            </Row>
            <Row label="LOOK SENSITIVITY">
              <input
                type="range"
                min={5}
                max={80}
                value={sens}
                onChange={(e) => {
                  const v = e.target.valueAsNumber;
                  setSens(v);
                  engine.sensitivity = v / 1000;
                }}
                className="w-full accent-amber-500"
              />
            </Row>
            <Row label="GRAPHICS QUALITY">
              <div className="flex gap-2">
                {(['low', 'medium', 'high'] as const).map((q) => (
                  <button
                    key={q}
                    onClick={() => {
                      setQuality(q);
                      engine.setQuality(q);
                    }}
                    className={`px-3 py-1.5 rounded text-[11px] font-bold ${
                      quality === q ? 'bg-amber-500 text-black' : 'bg-white/10 text-white/60'
                    }`}
                  >
                    {q.toUpperCase()}
                  </button>
                ))}
              </div>
            </Row>
            <Row label="INVERT LOOK Y">
              <button
                onClick={() => {
                  setInvert(!invert);
                  engine.invertY = !invert;
                }}
                className={`px-3 py-1.5 rounded text-[11px] font-bold ${
                  invert ? 'bg-amber-500 text-black' : 'bg-white/10 text-white/60'
                }`}
              >
                {invert ? 'ON' : 'OFF'}
              </button>
            </Row>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setTab('main')}
                className="flex-1 py-2.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-bold tracking-wider"
              >
                BACK
              </button>
            </div>
          </div>
        )}

        {tab === 'jobs' && (
          <div className="p-5 space-y-3">
            {hud.missions.map((m) => (
              <div key={m.id} className="bg-white/5 border border-white/10 rounded-xl p-4">
                <div className="flex justify-between items-start gap-3">
                  <span className="text-white font-semibold">{m.title}</span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      m.state === 'done'
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : m.state === 'active'
                        ? 'bg-amber-500/20 text-amber-300'
                        : 'bg-white/10 text-white/40'
                    }`}
                  >
                    {m.state.toUpperCase()}
                  </span>
                </div>
                <p className="text-white/55 text-[12px] mt-1">{m.brief}</p>
                <button
                  disabled={m.state === 'done'}
                  onClick={() => engine.startMission(m.id)}
                  className={`mt-3 text-[10px] font-bold tracking-wider rounded px-3 py-1.5 ${
                    m.state === 'done'
                      ? 'bg-white/10 text-white/35'
                      : 'bg-amber-500 text-black active:scale-95'
                  }`}
                >
                  {m.state === 'done' ? 'COMPLETED' : 'START JOB'} · ${m.reward}
                </button>
              </div>
            ))}
            <button
              onClick={() => setTab('main')}
              className="w-full py-2.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-bold tracking-wider"
            >
              BACK
            </button>
          </div>
        )}

        {tab === 'controls' && (
          <div className="p-5 grid grid-cols-1 sm:grid-cols-2 gap-4 text-[12px] text-white/75">
            <div>
              <div className="text-amber-400 font-bold tracking-wider mb-2">ON FOOT</div>
              {[
                ['W A S D', 'Move'],
                ['SHIFT', 'Sprint'],
                ['SPACE', 'Jump'],
                ['MOUSE', 'Look around'],
                ['LEFT CLICK', 'Attack / Fire'],
                ['F', 'Punch'],
                ['C', 'Sit / Stand'],
                ['E', 'Enter vehicle / building'],
                ['Q', 'Weapon wheel'],
                ['1 - 6', 'Quick select weapon'],
                ['R', 'Reload'],
                ['TAB', 'Inventory'],
                ['P', 'Phone'],
                ['M', 'Map'],
                ['ESC', 'Pause'],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between border-b border-white/5 py-1">
                  <span className="font-mono text-white/85">{k}</span>
                  <span className="text-white/50">{v}</span>
                </div>
              ))}
            </div>
            <div>
              <div className="text-amber-400 font-bold tracking-wider mb-2">IN A VEHICLE</div>
              {[
                ['W / S', 'Accelerate / Reverse'],
                ['A / D', 'Steer'],
                ['SPACE', 'Handbrake'],
                ['H', 'Horn'],
                ['E', 'Exit vehicle'],
                ['MOUSE', 'Camera'],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between border-b border-white/5 py-1">
                  <span className="font-mono text-white/85">{k}</span>
                  <span className="text-white/50">{v}</span>
                </div>
              ))}
              <div className="mt-4 text-amber-400 font-bold tracking-wider mb-2">MOBILE</div>
              <p className="text-white/55 leading-relaxed">
                Left thumb: analog stick. Drag anywhere on the screen to look. Right buttons: run,
                jump, punch, fire, enter/exit, sit, aim. Top bar: weapons, phone, map, bag.
              </p>
            </div>
            <button
              onClick={() => setTab('main')}
              className="sm:col-span-2 py-2.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-bold tracking-wider"
            >
              BACK
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="text-[11px] tracking-widest text-white/50 mb-1.5">{label}</div>
      {children}
    </div>
  );
}
