import { useEffect } from "react";
import { useGame } from "@/game/store";
import { writeSave } from "@/game/save";
import { resumeAudio, setAudioVolumes, unlockAudio } from "@/game/audio";
import { Starfield } from "./Starfield";
import { TitleScreen, ReconnectScreen } from "./TitleScreen";
import { SceneView } from "./SceneView";
import { HUD } from "./HUD";
import {
  CombineOverlay,
  ConstellationOverlay,
  HintsOverlay,
  InspectOverlay,
  InventoryOverlay,
  JournalOverlay,
  MapOverlay,
  ResonanceOverlay,
  SettingsOverlay,
} from "./Overlays";
import { DialogueOverlay } from "./Dialogue";
import { CinematicOverlay } from "./Cinematic";
import { EndingSequence, CreditsScreen } from "./Ending";
import { AdminOverlay } from "./Admin";
import { PuzzleHost } from "@/puzzles/PuzzleHost";
import { getLocation } from "@/data/locations";

export function GameRoot() {
  const hydrate = useGame((s) => s.hydrate);
  const hydrated = useGame((s) => s.hydrated);
  const phase = useGame((s) => s.phase);
  const overlay = useGame((s) => s.overlay);
  const act = useGame((s) => s.act);
  const locationId = useGame((s) => s.locationId);
  const settings = useGame((s) => s.settings);
  const toast = useGame((s) => s.toast);
  const setQuality = useGame((s) => s.setQuality);
  const loc = getLocation(locationId);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    const onHide = () => {
      if (document.visibilityState === "hidden") writeSave(useGame.getState());
      else resumeAudio();
    };
    document.addEventListener("visibilitychange", onHide);
    window.addEventListener("pagehide", onHide);
    return () => {
      document.removeEventListener("visibilitychange", onHide);
      window.removeEventListener("pagehide", onHide);
    };
  }, []);

  useEffect(() => {
    setAudioVolumes({ master: settings.master, music: settings.music, sfx: settings.sfx });
  }, [settings.master, settings.music, settings.sfx]);

  useEffect(() => {
    const onFirst = () => unlockAudio();
    window.addEventListener("pointerdown", onFirst, { once: true });
    return () => window.removeEventListener("pointerdown", onFirst);
  }, []);

  useEffect(() => {
    if (settings.qualityLocked) return;
    let frames = 0;
    let start = performance.now();
    let raf = 0;
    const loop = (t: number) => {
      frames += 1;
      if (t - start > 1800) {
        const fps = (frames / (t - start)) * 1000;
        if (fps < 28) setQuality("eco");
        else if (fps < 45) setQuality("medium");
        return;
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [setQuality, settings.qualityLocked]);

  useEffect(() => {
    const onPrompt = (e: Event) => {
      e.preventDefault();
      (window as unknown as { deferredPrompt: Event }).deferredPrompt = e;
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    if ("serviceWorker" in navigator) {
      void navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  if (!hydrated) {
    return (
      <div className="relative min-h-dvh bg-void">
        <Starfield quality="medium" reduceMotion ambience="threshold" act={1} />
      </div>
    );
  }

  const warm = act >= 9;
  const falling = act === 7 || loc?.weather === "starfall";
  const scale = settings.textScale;

  return (
    <div
      className="relative h-dvh min-h-dvh overflow-hidden bg-void text-lumen"
      style={{ fontSize: `${scale * 100}%` }}
    >
      <Starfield
        quality={settings.quality}
        reduceMotion={settings.reduceMotion}
        ambience={loc?.ambience ?? "threshold"}
        act={act}
        falling={falling}
        warm={warm}
      />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_40%,rgba(7,6,12,0.72)_100%)]" />
      {settings.contrast && <div className="pointer-events-none absolute inset-0 bg-void/20" />}

      {phase === "title" && <TitleScreen />}
      {phase === "reconnect" && <ReconnectScreen />}
      {(phase === "playing" || phase === "intro") && (
        <>
          <SceneView />
          <HUD />
        </>
      )}
      {phase === "ending" && <EndingSequence />}
      {phase === "credits" && <CreditsScreen />}

      {overlay === "inventory" && <InventoryOverlay />}
      {overlay === "inspect" && <InspectOverlay />}
      {overlay === "journal" && <JournalOverlay />}
      {overlay === "map" && <MapOverlay />}
      {overlay === "constellation" && <ConstellationOverlay />}
      {overlay === "combine" && <CombineOverlay />}
      {overlay === "settings" && <SettingsOverlay />}
      {overlay === "hints" && <HintsOverlay />}
      {overlay === "resonance" && <ResonanceOverlay />}
      {overlay === "puzzle" && <PuzzleHost />}
      {(overlay === "dialogue" || overlay === "choice") && <DialogueOverlay />}
      {overlay === "cinematic" && <CinematicOverlay />}
      {overlay === "admin" && <AdminOverlay />}

      {toast && (
        <div className="pointer-events-none absolute inset-x-0 top-[22%] z-50 flex justify-center px-6">
          <p className="rounded-full border border-lumen/15 bg-void/70 px-4 py-2 font-display text-sm text-lumen backdrop-blur-md">
            {toast.text}
          </p>
        </div>
      )}
    </div>
  );
}
