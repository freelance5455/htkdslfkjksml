import React, { useEffect, useRef, useState } from 'react';
import { Activity, Cpu, Layers, HardDrive, Zap } from 'lucide-react';
import { ViewportStats } from '../renderer/viewportEngine';

interface ProfilerPanelProps {
  stats: ViewportStats;
}

export const ProfilerPanel: React.FC<ProfilerPanelProps> = ({ stats }) => {
  const [fpsHistory, setFpsHistory] = useState<number[]>(new Array(40).fill(60));
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    setFpsHistory((prev) => {
      const next = [...prev.slice(1), stats.fps];
      return next;
    });
  }, [stats.fps]);

  useEffect(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw background grid lines
    ctx.strokeStyle = '#21262d';
    ctx.lineWidth = 1;
    for (let y = 0; y < canvas.height; y += 15) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    // Draw FPS sparkline
    ctx.beginPath();
    ctx.strokeStyle = stats.fps >= 50 ? '#10b981' : stats.fps >= 30 ? '#f59e0b' : '#ef4444';
    ctx.lineWidth = 2;

    const stepX = canvas.width / (fpsHistory.length - 1);
    fpsHistory.forEach((fps, i) => {
      const y = canvas.height - (Math.min(120, fps) / 120) * canvas.height;
      if (i === 0) ctx.moveTo(0, y);
      else ctx.lineTo(i * stepX, y);
    });
    ctx.stroke();
  }, [fpsHistory, stats.fps]);

  return (
    <div className="flex flex-col md:flex-row h-full bg-[#0d1117] text-slate-300 text-xs p-3 gap-3 overflow-y-auto select-none">
      {/* Real-time FPS graph */}
      <div className="bg-[#161b22] p-3 rounded-lg border border-[#21262d] flex flex-col justify-between flex-1 min-w-[220px]">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-1.5">
            <Activity className="w-4 h-4 text-emerald-400" />
            <span className="font-bold text-slate-100 text-xs">FRAME METRICS</span>
          </div>
          <span className="font-mono text-sm font-black text-emerald-400">
            {stats.fps} FPS
          </span>
        </div>

        <canvas ref={canvasRef} width={260} height={60} className="w-full h-[60px] rounded bg-[#0d1117] border border-[#30363d]" />

        <div className="flex justify-between items-center text-[10px] text-slate-400 mt-2 font-mono">
          <span>Frame Time: <strong className="text-cyan-300">{stats.frameTime} ms</strong></span>
          <span>Target: <strong className="text-slate-200">16.6 ms (60Hz)</strong></span>
        </div>
      </div>

      {/* Numerical Metrics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 flex-1">
        <div className="bg-[#161b22] p-2.5 rounded border border-[#21262d] flex flex-col justify-between">
          <div className="text-[10px] text-slate-400 flex items-center gap-1">
            <Layers className="w-3 h-3 text-cyan-400" /> Triangles
          </div>
          <div className="text-lg font-mono font-bold text-cyan-300 mt-1">
            {stats.triangles.toLocaleString()}
          </div>
          <div className="text-[9px] text-slate-500 font-mono">Rasterized Geo</div>
        </div>

        <div className="bg-[#161b22] p-2.5 rounded border border-[#21262d] flex flex-col justify-between">
          <div className="text-[10px] text-slate-400 flex items-center gap-1">
            <Zap className="w-3 h-3 text-amber-400" /> Draw Calls
          </div>
          <div className="text-lg font-mono font-bold text-amber-300 mt-1">
            {stats.drawCalls}
          </div>
          <div className="text-[9px] text-slate-500 font-mono">GPU Submissions</div>
        </div>

        <div className="bg-[#161b22] p-2.5 rounded border border-[#21262d] flex flex-col justify-between">
          <div className="text-[10px] text-slate-400 flex items-center gap-1">
            <Cpu className="w-3 h-3 text-violet-400" /> Scene Entities
          </div>
          <div className="text-lg font-mono font-bold text-violet-300 mt-1">
            {stats.objectsCount}
          </div>
          <div className="text-[9px] text-slate-500 font-mono">Transform Nodes</div>
        </div>

        <div className="bg-[#161b22] p-2.5 rounded border border-[#21262d] flex flex-col justify-between">
          <div className="text-[10px] text-slate-400 flex items-center gap-1">
            <HardDrive className="w-3 h-3 text-sky-400" /> GPU Context
          </div>
          <div className="text-xs font-mono font-bold text-sky-300 mt-1 truncate">
            {stats.webglVersion}
          </div>
          <div className="text-[9px] text-slate-500 font-mono">Android 8+ Compatible</div>
        </div>
      </div>
    </div>
  );
};
