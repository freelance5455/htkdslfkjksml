import { useMemo, useState } from "react";
import { CATEGORIES, ITEMS, type Category, type ItemDef } from "../game/items";
import { itemIcon } from "./icon";
import { spriteURL } from "../game/sprites";

interface Props {
  coins: number;
  owned: string[];
  onBuy: (item: ItemDef) => void;
  onClose: () => void;
}

export default function Store({ coins, owned, onBuy, onClose }: Props) {
  const [cat, setCat] = useState<Category>("vehicles");
  const [tip, setTip] = useState<{ x: number; y: number; item: ItemDef } | null>(null);
  const [bannerOk, setBannerOk] = useState(true);

  const list = useMemo(() => ITEMS.filter((i) => i.category === cat), [cat]);
  const current = CATEGORIES.find((c) => c.id === cat)!;

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-[#0e0b08]/82 p-3 sm:p-6">
      <div className="mc-panel snap-in flex h-full max-h-[880px] w-full max-w-[1120px] flex-col">
        {/* ---- header banner ---- */}
        <div className="relative h-28 shrink-0 overflow-hidden border-b-4 border-black sm:h-36">
          {bannerOk ? (
            <img
              src="images/highway.jpg"
              alt=""
              className="h-full w-full object-cover object-[50%_62%]"
              onError={() => setBannerOk(false)}
            />
          ) : (
            <div className="h-full w-full bg-[linear-gradient(180deg,#2a3550_0%,#5b4a2c_100%)]" />
          )}
          <div className="absolute inset-0 bg-[linear-gradient(90deg,#1a120bef_0%,#1a120b99_46%,#1a120b22_100%)]" />
          <div className="absolute inset-0 flex items-center justify-between px-5 sm:px-8">
            <div>
              <div className="text-[9px] tracking-[0.32em] text-[#b7ada0] sm:text-[10px]">
                IN-GAME SHOP · BLOCK &amp; BLADE
              </div>
              <h2 className="font-title mt-2 text-xl leading-none text-white mc-shadow sm:text-3xl">
                STORE
              </h2>
            </div>
            <div className="flex items-center gap-3">
              <div className="mc-slot--dark mc-slot flex items-center gap-2 px-3 py-2">
                <img src={spriteURL("coin")} alt="" className="pixelated h-5 w-5" />
                <span className="text-sm text-[#e8c24a] mc-shadow-sm tabular-nums sm:text-base">
                  {coins.toLocaleString()}
                </span>
              </div>
              <button className="mc-btn" onClick={onClose} aria-label="Close store">
                ✕ CLOSE
              </button>
            </div>
          </div>
        </div>

        <div className="flex min-h-0 flex-1 flex-col sm:flex-row">
          {/* ---- category rail ---- */}
          <div className="flex shrink-0 gap-2 overflow-x-auto border-b-2 border-black/60 p-3 sm:w-56 sm:flex-col sm:overflow-visible sm:border-b-0 sm:border-r-2 sm:p-4">
            {CATEGORIES.map((c) => {
              const active = c.id === cat;
              return (
                <button
                  key={c.id}
                  onClick={() => setCat(c.id)}
                  className={`mc-btn shrink-0 justify-start whitespace-nowrap sm:w-full ${
                    active ? "mc-btn--grass" : ""
                  }`}
                >
                  {c.label.toUpperCase()}
                </button>
              );
            })}
            <div className="mt-auto hidden text-[9px] leading-relaxed tracking-[0.18em] text-[#b7ada0] sm:block">
              {current.sub.toUpperCase()}
            </div>
          </div>

          {/* ---- item grid ---- */}
          <div
            className="mc-scroll min-h-0 flex-1 overflow-y-auto p-3 sm:p-5"
            onMouseLeave={() => setTip(null)}
          >
            <div className="mb-4 flex items-baseline gap-3">
              <h3 className="font-title text-sm text-white mc-shadow sm:text-base">
                {current.label.toUpperCase()}
              </h3>
              <span className="text-[9px] tracking-[0.22em] text-[#b7ada0]">
                {list.length} ITEMS AVAILABLE
              </span>
            </div>

            <div className="grid grid-cols-1 gap-3 lg:grid-cols-2 xl:grid-cols-3">
              {list.map((item) => {
                const isOwned = owned.includes(item.id);
                const affordable = coins >= item.price;
                return (
                  <div
                    key={item.id}
                    className="mc-panel--stone mc-panel flex flex-col p-3"
                    onMouseMove={(e) => setTip({ x: e.clientX, y: e.clientY, item })}
                    onMouseLeave={() => setTip(null)}
                  >
                    <div className="flex gap-3">
                      <div className="mc-slot flex h-16 w-16 shrink-0 items-center justify-center">
                        <img
                          src={itemIcon(item.id)}
                          alt=""
                          className="pixelated h-12 w-12"
                          draggable={false}
                        />
                      </div>
                      <div className="min-w-0">
                        <div className="text-[13px] leading-tight text-white mc-shadow-sm">
                          {item.name}
                        </div>
                        <div className="mt-1 text-[9px] leading-[1.7] text-[#b7ada0]">
                          {item.tagline}
                        </div>
                        <div className="mt-1 text-[9px] leading-[1.7] text-[#7ec850]">
                          {item.stat}
                        </div>
                      </div>
                    </div>
                    <div className="mt-3 flex items-center justify-between gap-2 border-t-2 border-black/50 pt-3">
                      <span className="flex items-center gap-2">
                        <img src={spriteURL("coin")} alt="" className="pixelated h-4 w-4" />
                        <span className="text-sm tabular-nums text-[#e8c24a] mc-shadow-sm">
                          {item.price.toLocaleString()}
                        </span>
                      </span>
                      {isOwned && item.action !== "give" ? (
                        <button className="mc-btn" onClick={() => onBuy(item)}>
                          {item.action === "spawn"
                            ? "SPAWN"
                            : item.action === "build"
                              ? "BUILD"
                              : "EQUIP"}
                        </button>
                      ) : (
                        <button
                          className="mc-btn mc-btn--grass"
                          disabled={!affordable}
                          onClick={() => onBuy(item)}
                        >
                          {affordable ? "BUY" : "NEED COINS"}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* ---- minecraft hover tooltip ---- */}
      {tip && (
        <div
          className="mc-tooltip pointer-events-none fixed z-50 max-w-[260px]"
          style={{
            left: Math.min(tip.x + 18, window.innerWidth - 280),
            top: Math.min(tip.y + 18, window.innerHeight - 140),
          }}
        >
          <div className="text-[11px] text-white mc-shadow-sm">{tip.item.name}</div>
          <div className="mt-1 text-[9px] leading-[1.8] text-[#b7ada0]">{tip.item.control}</div>
          <div className="mt-1 text-[9px] leading-[1.8] text-[#e8c24a]">
            {tip.item.action === "build"
              ? "Places real blocks in the world"
              : tip.item.action === "spawn"
                ? "Drivable vehicle"
                : tip.item.action === "equip"
                  ? "Equips to your hotbar"
                  : "Added to inventory"}
          </div>
        </div>
      )}
    </div>
  );
}
