import React, { useState } from 'react';
import { Mountain, Trees, Waves, RefreshCw, Layers, Check } from 'lucide-react';
import { audioSystem } from '../audio/audioManager';

interface TerrainEditorProps {
  onRegenerateTerrain: (heightScale: number, roughness: number) => void;
  onUpdateWaterHeight: (height: number) => void;
  onAddFoliage: (type: 'trees' | 'rocks') => void;
}

export const TerrainEditor: React.FC<TerrainEditorProps> = ({
  onRegenerateTerrain,
  onUpdateWaterHeight,
  onAddFoliage,
}) => {
  const [heightScale, setHeightScale] = useState(4.0);
  const [roughness, setRoughness] = useState(0.85);
  const [waterLevel, setWaterLevel] = useState(-0.6);
  const [activeBrush, setActiveBrush] = useState<'grass' | 'sand' | 'stone' | 'dirt'>('grass');

  return (
    <div className="flex flex-col h-full bg-[#11161f] text-slate-300 text-xs p-3 space-y-4 overflow-y-auto select-none">
      <div className="flex items-center justify-between border-b border-[#21262d] pb-2">
        <div className="flex items-center space-x-2">
          <Mountain className="w-4 h-4 text-emerald-400" />
          <span className="font-bold text-slate-100 text-xs tracking-wide">TERRAIN GENERATOR</span>
        </div>
        <span className="text-[10px] text-cyan-400 bg-cyan-950/80 px-1.5 py-0.5 rounded border border-cyan-800 font-mono">
          Chunk 4x4
        </span>
      </div>

      {/* Procedural Height Parameters */}
      <div className="space-y-3 bg-[#161b22] p-2.5 rounded border border-[#21262d]">
        <div className="text-[11px] font-semibold text-slate-200">Elevation & Relief</div>
        <div>
          <div className="flex justify-between text-[10px] text-slate-400 mb-1">
            <span>Peak Elevation</span>
            <span className="font-mono text-cyan-300">{heightScale.toFixed(1)}m</span>
          </div>
          <input
            type="range"
            min="1.0"
            max="12.0"
            step="0.5"
            value={heightScale}
            onChange={(e) => setHeightScale(parseFloat(e.target.value))}
            className="w-full accent-cyan-500 cursor-pointer"
          />
        </div>

        <div>
          <div className="flex justify-between text-[10px] text-slate-400 mb-1">
            <span>Surface Roughness</span>
            <span className="font-mono text-cyan-300">{roughness.toFixed(2)}</span>
          </div>
          <input
            type="range"
            min="0.1"
            max="2.0"
            step="0.05"
            value={roughness}
            onChange={(e) => setRoughness(parseFloat(e.target.value))}
            className="w-full accent-cyan-500 cursor-pointer"
          />
        </div>

        <button
          onClick={() => {
            onRegenerateTerrain(heightScale, roughness);
            audioSystem.playSound('synth_drone', { pitch: 1.2 });
          }}
          className="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-medium py-1.5 px-3 rounded flex items-center justify-center space-x-1.5 transition-colors shadow-sm"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Sculpt / Re-Mesh Terrain</span>
        </button>
      </div>

      {/* Surface Biome Painting */}
      <div className="space-y-2 bg-[#161b22] p-2.5 rounded border border-[#21262d]">
        <div className="text-[11px] font-semibold text-slate-200">Biome Material Brush</div>
        <div className="grid grid-cols-2 gap-1.5">
          {[
            { id: 'grass', label: 'Meadow Grass', color: '#2e7d32' },
            { id: 'sand', label: 'Coastal Sand', color: '#d97706' },
            { id: 'stone', label: 'Granite Ridge', color: '#52525b' },
            { id: 'dirt', label: 'Forest Humus', color: '#78350f' },
          ].map((brush) => (
            <button
              key={brush.id}
              onClick={() => {
                setActiveBrush(brush.id as any);
                audioSystem.playSound('click');
              }}
              className={`flex items-center space-x-2 p-1.5 rounded border text-left text-[10px] transition-colors ${
                activeBrush === brush.id
                  ? 'bg-cyan-950/80 border-cyan-500 text-cyan-300'
                  : 'bg-[#0d1117] border-[#30363d] text-slate-400 hover:text-white'
              }`}
            >
              <div className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: brush.color }} />
              <span className="truncate">{brush.label}</span>
              {activeBrush === brush.id && <Check className="w-3 h-3 text-cyan-400 ml-auto" />}
            </button>
          ))}
        </div>
      </div>

      {/* Vegetation & Foliage Scatter */}
      <div className="space-y-2 bg-[#161b22] p-2.5 rounded border border-[#21262d]">
        <div className="text-[11px] font-semibold text-slate-200 flex items-center space-x-1.5">
          <Trees className="w-3.5 h-3.5 text-emerald-400" />
          <span>Foliage & Scatter</span>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => {
              onAddFoliage('trees');
              audioSystem.playSound('synth_jump', { pitch: 1.6, volume: 0.3 });
            }}
            className="bg-[#0d1117] hover:bg-[#1f2633] text-emerald-300 border border-emerald-900/60 p-2 rounded text-center text-[10px] transition-colors"
          >
            + Scatter Trees
          </button>
          <button
            onClick={() => {
              onAddFoliage('rocks');
              audioSystem.playSound('synth_bell', { pitch: 1.4, volume: 0.3 });
            }}
            className="bg-[#0d1117] hover:bg-[#1f2633] text-amber-300 border border-amber-900/60 p-2 rounded text-center text-[10px] transition-colors"
          >
            + Scatter Boulders
          </button>
        </div>
      </div>

      {/* Water Basin Elevation */}
      <div className="space-y-2 bg-[#161b22] p-2.5 rounded border border-[#21262d]">
        <div className="flex items-center justify-between text-[11px] font-semibold text-slate-200">
          <span className="flex items-center space-x-1.5">
            <Waves className="w-3.5 h-3.5 text-sky-400" />
            <span>Water Level</span>
          </span>
          <span className="font-mono text-sky-400 text-[10px]">{waterLevel.toFixed(2)}m</span>
        </div>
        <input
          type="range"
          min="-3.0"
          max="2.0"
          step="0.1"
          value={waterLevel}
          onChange={(e) => {
            const val = parseFloat(e.target.value);
            setWaterLevel(val);
            onUpdateWaterHeight(val);
          }}
          className="w-full accent-sky-500 cursor-pointer"
        />
      </div>
    </div>
  );
};
