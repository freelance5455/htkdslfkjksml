/**
 * WHITE ROOM OS — Interactive UI Controller (Phases 1 + 2 + 3 + 4 + 5 Integrated Diagnostics, Mastery & Retention)
 * Connects Reactive Store & Engines (Daily OS & Adaptive Scheduler, Persistent Timer, Skill Engine,
 * Learning Engine, Diagnostics & Mastery Engine, Internal Time-Block Calendar, Weekly Planner, Backup/Restore) to DOM.
 */

import { createWhiteRoomSystem } from '../core/bootstrap.js';
import {
  DAYS_OF_WEEK,
  RESOURCE_TYPES,
  SESSION_TYPES,
  EVIDENCE_TYPES,
  TEST_KINDS,
  TIME_BLOCK_TYPES,
  ERROR_TAXONOMY_CATEGORIES,
  RETEST_VERIFICATION_MODES,
} from '../core/schema.js';

export function formatSecondsHHMMSS(totalSeconds) {
  const sec = Math.max(0, Math.floor(totalSeconds || 0));
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  if (h > 0) {
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export async function mountWhiteRoomApp(rootElement) {
  const system = await createWhiteRoomSystem({ initialDate: '2026-10-14' });
  const { store, engines, db } = system;

  const formDraftCache = {};
  const tabHistoryStack = [];

  function captureFormDrafts() {
    if (!rootElement) return;
    rootElement.querySelectorAll('input[type="text"], textarea').forEach((el) => {
      if (el.id && el.id !== 'analytics-export-textarea' && el.id !== 'backup-json-textarea') {
        formDraftCache[el.id] = el.value;
      }
    });
  }

  function restoreFormDrafts() {
    if (!rootElement) return;
    rootElement.querySelectorAll('input[type="text"], textarea').forEach((el) => {
      if (
        el.id &&
        formDraftCache[el.id] !== undefined &&
        formDraftCache[el.id] !== '' &&
        !el.readOnly &&
        el.value === ''
      ) {
        el.value = formDraftCache[el.id];
      }
    });
  }

  function handleAndroidBackNavigation() {
    captureFormDrafts();
    // 1. If any collapsible details panel is open on mobile, close it first without losing data
    const openDetails = rootElement
      ? Array.from(rootElement.querySelectorAll('details[open]'))
      : [];
    if (openDetails.length > 0) {
      openDetails[openDetails.length - 1].removeAttribute('open');
      showToast('تم طي اللوحة المفتوحة مع الاحتفاظ بالبيانات المدخلة');
      return true;
    }
    // 2. If tab history has previous tabs, pop and navigate back while preserving drafts
    while (tabHistoryStack.length > 0) {
      const prevTab = tabHistoryStack.pop();
      if (prevTab && prevTab !== store.getState().activeTab) {
        store.setState({ activeTab: prevTab });
        showToast(`العودة إلى التبويب السابق (${prevTab}) مع حفظ المسودات`);
        return true;
      }
    }
    // 3. If not on daily-os, return to daily-os root tab
    if (store.getState().activeTab !== 'daily-os') {
      store.setState({ activeTab: 'daily-os' });
      showToast('العودة إلى الشاشة الرئيسية (Today OS) مع حفظ المسودات');
      return true;
    }
    return false;
  }

  if (typeof window !== 'undefined') {
    window.__WHITE_ROOM_OS__ = system;
    window.__WHITE_ROOM_HANDLE_BACK__ = handleAndroidBackNavigation;
    window.__WHITE_ROOM_FORM_DRAFTS__ = formDraftCache;
    window.addEventListener('whiteroom:hardware-back', () => {
      handleAndroidBackNavigation();
    });
    window.addEventListener('popstate', () => {
      handleAndroidBackNavigation();
    });
  }

  let toastTimeout = null;
  function showToast(msg) {
    const toastEl = document.getElementById('wr-toast');
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.classList.remove('hidden');
    if (toastTimeout) clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => toastEl.classList.add('hidden'), 3800);
  }

  function getCategoryBadgeClass(cat) {
    if (cat === 'Primary' || cat === 'Remediation' || cat === 'Tests') return 'badge-primary';
    if (cat === 'Secondary' || cat === 'Practice') return 'badge-secondary';
    if (cat === 'Maintenance' || cat === 'Reviews') return 'badge-maintenance';
    return 'badge-recovery';
  }

  // =========================================================================
  // PHASE 4: UPGRADED TODAY SCREEN (ADAPTIVE SCHEDULER & DAILY EXECUTION)
  // =========================================================================
  function renderTodayExecutionTab(state, skillMap) {
    const {
      currentDate,
      currentEnergy,
      skills,
      learningObjectives,
      dailyExecutionView,
      dailyPlan,
      errors,
      flashcards,
    } = state;

    const view = dailyExecutionView || dailyPlan || {};
    const budget = view.budget || engines.timeEngine.calculateDayBudget(state.scheduleConfig, currentDate, currentEnergy);
    const orderedTasks = view.tasks || [];
    const deferredTasks = view.deferredTasks || [];
    const excludedBlocked = view.excludedBlockedTasks || [];
    const overloadCheck = view.overloadCheck || { isOverloaded: false, warnings: [] };
    const nextTask = view.nextRecommendedTask;
    const execHistory = view.executionHistory || state.executionHistory || [];

    const objMap = {};
    for (const o of learningObjectives) objMap[o.id] = o;

    const openCriticalErrors = errors.filter((e) => e.status !== 'resolved');
    const dueCards = flashcards.filter(
      (c) => !c.nextReviewDate || String(c.nextReviewDate) <= String(currentDate)
    );

    return `
      <section class="wr-card" id="tab-panel-daily-os">
        <div class="wr-card-header">
          <div>
            <div class="wr-card-title">⚡ TODAY EXECUTION & ADAPTIVE SCHEDULER — محرك التنفيذ والجدولة التكيفية (Phase 4–5)</div>
            <div style="font-size:12px;color:var(--text-muted);">
              يجيب بالبيانات والوزن الحسابي عن: ماذا أفعل اليوم؟ لماذا اختيرت هذه المهمة؟ متى أنفذها؟ وماذا يتغير غداً بناءً على نتائج اليوم؟
            </div>
          </div>
          <span class="wr-badge ${budget.isCollegeDay ? 'badge-college' : 'badge-focus'}" id="daily-day-type-badge">
            ${budget.dayName} • ${budget.isCollegeDay ? `يوم كلية (${budget.collegeWindow})` : 'يوم تركيز حر'}
          </span>
        </div>

        <!-- Date, Energy & Regenerate Controls -->
        <div class="wr-form-grid" style="margin-bottom:14px;">
          <div class="wr-field">
            <label for="input-daily-date">تاريخ اليوم التشغيلي</label>
            <input type="date" id="input-daily-date" class="wr-input" value="${currentDate}" />
          </div>
          <div class="wr-field">
            <label for="input-daily-energy">مستوى الطاقة الحالي (${currentEnergy}/10)</label>
            <input type="range" id="input-daily-energy" class="wr-input" min="1" max="10" value="${currentEnergy}" />
          </div>
          <div class="wr-field" style="display:flex;align-items:flex-end;">
            <button class="wr-btn wr-btn-secondary" id="btn-regenerate-day" style="width:100%;">
              🔄 إعادة حساب وجدولة خطة اليوم التكيفية
            </button>
          </div>
        </div>

        <!-- Main Objective & Next Recommended Action Banner -->
        <div class="wr-form-grid" style="margin-bottom:14px;">
          <div style="background:linear-gradient(90deg, rgba(20,184,166,0.15), rgba(56,189,248,0.08));border:1px solid var(--border-color);padding:12px;border-radius:10px;">
            <div style="font-size:11px;color:var(--accent-cyan);font-weight:700;">🎯 الهدف الرئيسي لليوم (MAIN OBJECTIVE FOR TODAY)</div>
            <div style="font-size:14px;font-weight:800;margin-top:3px;" id="today-main-objective">
              ${view.mainObjective || orderedTasks[0]?.title || 'استكمال خطة التطوير اليومية'}
            </div>
            <div style="font-size:11px;color:var(--text-secondary);margin-top:4px;">
              الإجراء الموصى به الآن (Next Action): <strong id="today-next-recommended" style="color:#6ee7b7;">${nextTask ? `${nextTask.title} (${nextTask.scheduledWindow || nextTask.plannedDurationMin + ' د'})` : 'تم إتمام جميع مهام اليوم المجدولة!'}</strong>
            </div>
          </div>

          <div style="background:var(--bg-secondary);border:1px solid var(--border-subtle);padding:12px;border-radius:10px;" id="today-urgent-strip">
            <div style="font-size:11px;color:#fcd34d;font-weight:700;">🔔 المعالجات الحرجة والمراجعات المستحقة</div>
            <div style="font-size:12px;margin-top:4px;">
              🚨 أخطاء مفتوحة للمعالجة: <strong>${openCriticalErrors.length}</strong> |
              🗂️ مراجعات متباعدة مستحقة: <strong>${dueCards.length}</strong>
            </div>
            <div style="font-size:11px;color:${overloadCheck.isOverloaded ? '#fda4af' : '#6ee7b7'};margin-top:4px;" id="today-overload-status">
              ${overloadCheck.isOverloaded
                ? `⚠️ ${overloadCheck.warnings[0]}`
                : `🛡️ حماية الحمل والاستشفاء: ضمن السقف الآمن (${overloadCheck.utilizationPct || 0}% من الميزانية المتاحة) • النوم محمي (${budget.sleepHours} س)`}
            </div>
          </div>
        </div>

        <!-- Time Budget, Planned Workload, Buffer & Remaining Time -->
        <div style="background:var(--bg-secondary);padding:12px;border-radius:10px;border:1px solid var(--border-subtle);margin-bottom:16px;" id="today-workload-strip">
          <div style="font-size:12px;font-weight:700;color:var(--accent-cyan);margin-bottom:8px;">
            ميزانية الوقت والحمل اليومي — السقف المجدول الآمن: <span id="budget-schedulable-min">${budget.schedulableWorkMin ?? 180}</span> د | وقت احتياطي محفوظ (Buffer): <span id="budget-buffer-min">${budget.bufferMin ?? 30}</span> د
          </div>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(125px,1fr));gap:8px;font-size:12px;">
            <div>🏛️ الكلية: <strong>${budget.collegeHours} س</strong></div>
            <div>😴 النوم: <strong>${budget.sleepHours} س</strong></div>
            <div>✅ الصافي الحر: <strong id="budget-net-free">${budget.netFreeHours} س</strong></div>
            <div>📋 الحمل المخطط: <strong id="today-planned-workload">${view.plannedWorkloadMin ?? 0} د</strong></div>
            <div>⏱ المنجز اليوم: <strong id="today-completed-min">${view.completedMinutesToday ?? 0} د</strong></div>
            <div style="color:var(--accent-emerald);">⏳ المتاح المتبقي: <strong id="today-remaining-avail">${view.remainingAvailableMin ?? 0} د</strong></div>
          </div>
        </div>

        <!-- Ordered Explainable Task List -->
        <div style="font-size:14px;font-weight:700;margin-bottom:10px;">
          📋 قائمة المهام المرتبة حسب الأولوية والتفسير السببي (Ordered Daily Execution Queue: ${orderedTasks.length})
        </div>
        <div class="wr-task-list" id="daily-tasks-list">
          ${orderedTasks.map((t) => {
            const sk = skillMap[t.skillId];
            const obj = t.objectiveId ? objMap[t.objectiveId] : null;
            return `
              <div class="wr-task-item ${t.status === 'completed' ? 'completed' : ''}" data-task-id="${t.id}" id="task-card-${t.id}">
                <div style="flex:1;min-width:240px;">
                  <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:4px;">
                    <span class="wr-badge ${getCategoryBadgeClass(t.category)}">${t.category}</span>
                    <span class="wr-badge badge-focus" title="Priority Score">Score: ${t.priorityScore ?? 75}/100 (P${t.priority})</span>
                    <span style="font-size:11px;color:var(--text-muted);font-family:monospace;">
                      ${t.scheduledWindow ? `🕒 ${t.scheduledWindow} • ` : ''}${t.plannedDurationMin} د
                    </span>
                    <span class="wr-badge" id="task-status-badge-${t.id}" style="background:rgba(255,255,255,0.08);color:var(--text-primary);">
                      ${t.status.toUpperCase()} ${t.partialCompletionPct && t.status === 'partially_completed' ? `(${t.partialCompletionPct}%)` : ''}
                    </span>
                    <span class="wr-badge badge-recovery" style="font-size:10px;">Prereq: ${t.prerequisiteStatus || 'SATISFIED'}</span>
                  </div>

                  <div style="font-weight:700;font-size:14px;margin-bottom:4px;">${t.title}</div>

                  <div style="font-size:11px;color:var(--accent-cyan);margin-bottom:3px;">
                    ${sk ? `🏛️ المهارة: ${sk.nameAr}` : ''} ${obj ? `• 🎯 الهدف التعلمي: ${obj.title}` : ''}
                  </div>

                  <!-- Explainability Block (Why important, Why selected over alternatives, Consequence if skipped) -->
                  <div style="background:var(--bg-primary);padding:6px 8px;border-radius:6px;font-size:11px;color:var(--text-secondary);margin-top:4px;">
                    <div>💡 <strong>لماذا مهمة:</strong> ${t.selectionExplanation || t.notes || ''}</div>
                    <div>⚖️ <strong>لماذا اختيرت على البدائل:</strong> ${t.whySelectedOverAlternatives || ''}</div>
                    <div style="color:#fcd34d;">⚠️ <strong>أثر التخطي أو الفشل:</strong> ${t.consequenceIfSkipped || ''}</div>
                    ${t.diagnosis ? `<div style="color:#fda4af;margin-top:2px;">🩺 <strong>تشخيص التكييف:</strong> ${t.diagnosis.summaryText}</div>` : ''}
                  </div>
                </div>

                <!-- Complete Lifecycle Execution Controls -->
                <div class="wr-task-actions" style="flex-direction:column;min-width:140px;">
                  <button class="wr-btn wr-btn-primary" data-action="start-task-timer" data-task-id="${t.id}" style="width:100%;font-size:12px;">
                    ▶ بدء المهمة والمؤقت
                  </button>
                  ${t.status !== 'completed' ? `
                    <button class="wr-btn wr-btn-secondary" data-action="exec-complete-task" data-task-id="${t.id}" style="width:100%;font-size:11px;border-color:var(--accent-emerald);color:#6ee7b7;">
                      ✅ إتمام كامل (Complete)
                    </button>
                    <button class="wr-btn wr-btn-amber" data-action="exec-partial-task" data-task-id="${t.id}" style="width:100%;font-size:11px;">
                      🌗 إتمام جزئي 50%
                    </button>
                    <button class="wr-btn wr-btn-danger" data-action="exec-skip-task" data-task-id="${t.id}" style="width:100%;font-size:11px;">
                      ⏭️ تخطي وإعادة جدولة للغد
                    </button>
                  ` : ''}
                </div>
              </div>
            `;
          }).join('')}
        </div>

        <!-- Add Custom Task Form -->
        <div style="margin-top:16px;padding-top:14px;border-top:1px solid var(--border-subtle);">
          <div style="font-size:14px;font-weight:700;margin-bottom:10px;">➕ إضافة مهمة تدريبية مخصصة لليوم</div>
          <form id="form-add-custom-task" class="wr-form-grid">
            <div class="wr-field">
              <label>عنوان المهمة</label>
              <input type="text" id="custom-task-title" class="wr-input" placeholder="مثال: حل 10 تكتيكات شطرنج أو معمل Linux" required />
            </div>
            <div class="wr-field">
              <label>الفئة (Slot)</label>
              <select id="custom-task-category" class="wr-select">
                <option value="Primary">Primary (أساسية - عمل عميق)</option>
                <option value="Secondary" selected>Secondary (ثانوية - تدريب)</option>
                <option value="Practice">Practice (تطبيق عملي)</option>
                <option value="Reviews">Reviews (مراجعات متباعدة)</option>
                <option value="Maintenance">Maintenance (صيانة)</option>
                <option value="Recovery">Recovery (استشفاء ولياقة)</option>
              </select>
            </div>
            <div class="wr-field">
              <label>المهارة المرتبطة</label>
              <select id="custom-task-skill" class="wr-select">
                ${skills.map((s) => `<option value="${s.id}">${s.nameAr} (${s.name})</option>`).join('')}
              </select>
            </div>
            <div class="wr-field">
              <label>المدة المخططة (دقيقة)</label>
              <input type="number" id="custom-task-duration" class="wr-input" value="45" min="5" max="300" required />
            </div>
            <div class="wr-field" style="display:flex;align-items:flex-end;">
              <button type="submit" class="wr-btn wr-btn-primary" id="btn-add-custom-task" style="width:100%;">إضافة المهمة لليوم</button>
            </div>
          </form>
        </div>

        <!-- Explainability: Deferred Tasks, Prerequisite-Blocked Exclusions & Today's Execution History -->
        <div class="wr-form-grid" style="margin-top:18px;padding-top:14px;border-top:1px solid var(--border-subtle);" id="today-explainability-panel">
          <div class="wr-cap-card">
            <div style="font-size:13px;font-weight:700;color:#fcd34d;margin-bottom:6px;">
              ⏳ المهام المؤجلة لحماية الوقت والـ Buffer (Deferred Tasks: ${deferredTasks.length})
            </div>
            <div id="deferred-tasks-list">
              ${deferredTasks.length === 0 ? `<div style="font-size:11px;color:var(--text-muted);">جميع المهام المؤهلة استوعبتها ميزانية اليوم.</div>` : deferredTasks.slice(0, 5).map((dt) => `
                <div style="font-size:11px;background:var(--bg-primary);padding:6px 8px;border-radius:6px;margin-bottom:4px;">
                  <strong>${dt.title}</strong> (${dt.plannedDurationMin} د • Score ${dt.priorityScore})
                  <div style="color:var(--text-muted);">${dt.deferralReason} [${dt.limitingConstraint}]</div>
                </div>
              `).join('')}
            </div>
          </div>

          <div class="wr-cap-card">
            <div style="font-size:13px;font-weight:700;color:#fda4af;margin-bottom:6px;">
              🔒 مهام مستبعدة لعدم استيفاء المتطلبات (Prerequisite-Blocked Exclusions: ${excludedBlocked.length})
            </div>
            <div id="excluded-blocked-tasks-list">
              ${excludedBlocked.length === 0 ? `<div style="font-size:11px;color:var(--text-muted);">لا توجد مهام مقفلة.</div>` : excludedBlocked.slice(0, 5).map((ex) => `
                <div style="font-size:11px;background:var(--bg-primary);padding:6px 8px;border-radius:6px;margin-bottom:4px;">
                  <strong>${ex.title}</strong>
                  <div style="color:#fda4af;">السبب: ${ex.reason}</div>
                </div>
              `).join('')}
            </div>
          </div>
        </div>

        <!-- Execution History & Adaptive Tomorrow Diagnosis -->
        ${execHistory.length > 0 ? `
          <div style="margin-top:12px;" id="today-execution-history-box">
            <div style="font-size:13px;font-weight:700;color:var(--accent-cyan);margin-bottom:6px;">
              📜 سجل التنفيذ والتشخيص التكيفي لليوم (${execHistory.length})
            </div>
            ${execHistory.slice(0, 4).map((eh) => `
              <div style="font-size:11px;background:var(--bg-secondary);padding:6px 10px;border-radius:6px;margin-bottom:4px;border:1px solid var(--border-subtle);">
                <span class="wr-badge badge-focus">${eh.eventType}</span>
                <strong>${eh.taskTitle}</strong> — ${eh.outcome || eh.skipReason || ''}
                ${eh.diagnosis ? `<div style="color:#fcd34d;margin-top:2px;">🔄 تعديل الغد: ${eh.diagnosis.summaryText}</div>` : ''}
              </div>
            `).join('')}
          </div>
        ` : ''}
      </section>
    `;
  }

  // =========================================================================
  // PHASE 5: INTEGRATED DIAGNOSTICS, ERROR CORRECTION, MASTERY & RETENTION TAB
  // =========================================================================
  function renderDiagnosticsAndMasteryTab(state, skillMap) {
    const {
      skills,
      subskills,
      errors,
      remediations,
      reviews,
      diagnosticAssessments,
      masteryHistory,
      weaknessScan,
      selectedSkillId,
      selectedSkillBundle,
      progressSummary,
    } = state;

    const taxonomy = engines.diagnosticsEngine.getErrorTaxonomy();
    const scan = weaknessScan || {
      weakSkills: [],
      weakSubskills: [],
      unresolvedErrors: [],
      overdueMaintenanceSkills: [],
      dueFlashcardsCount: 0,
    };

    const bundle = selectedSkillBundle;
    const selSkill = bundle?.skill || skills[0];
    const gate = bundle?.skillGate;
    const openErrors = errors.filter((e) => e.status !== 'resolved');
    const allTasks = bundle?.correctiveTasks || [];
    const dims = progressSummary?.dimensions || {
      activity: 0,
      learning: 0,
      competence: 0,
      mastery: 0,
      retention: 0,
    };
    const evAudit = progressSummary?.evidencePartitionAudit || {
      totalEvidenceRecords: 0,
      learningEvidenceCount: 0,
      competenceEvidenceCount: 0,
      retentionEvidenceCount: 0,
      zeroDoubleCountingVerified: true,
    };

    return `
      <section class="wr-card" id="tab-panel-diagnostics">
        <div class="wr-card-header">
          <div>
            <div class="wr-card-title">🩺 PHASE 5: INTEGRATED DIAGNOSTICS, ERROR CORRECTION, MASTERY & RETENTION</div>
            <div style="font-size:12px;color:var(--text-muted);">
              Assessment → Diagnosis → Error → Remediation → Corrective Practice → Retest → Verification → Mastery Evaluation → Maintenance → Retention Check
            </div>
          </div>
          <span class="wr-badge ${openErrors.length > 0 ? 'badge-primary' : 'badge-recovery'}" id="diag-open-errors-badge">
            Open Errors: ${openErrors.length} • Weak Skills: ${scan.weakSkills.length} • Overdue Maint: ${scan.overdueMaintenanceSkills.length}
          </span>
        </div>

        <!-- 1. WEAK SKILLS, SUBSKILLS & OVERDUE RETENTION ISSUES (UI Requirement 1 & 9) -->
        <div class="wr-form-grid" style="margin-bottom:16px;" id="diag-weakness-overview">
          <div class="wr-cap-card" style="border-color:rgba(244,63,94,0.4);">
            <div style="font-size:13px;font-weight:700;color:#fda4af;margin-bottom:6px;">
              ⚠️ المهارات والمهارات الفرعية الضعيفة (Weak Skills & Subskills: ${scan.weakSkills.length} / ${scan.weakSubskills.length})
            </div>
            <div id="diag-weak-skills-list" class="wr-task-list">
              ${scan.weakSkills.length === 0 ? `<div style="font-size:11px;color:#6ee7b7;">لا توجد مهارات تعاني من أخطاء مفتوحة أو تراجع احتفاظ حالياً.</div>` : scan.weakSkills.map((ws) => `
                <div style="background:var(--bg-primary);padding:8px;border-radius:6px;font-size:12px;border:1px solid var(--border-subtle);">
                  <div style="display:flex;justify-content:space-between;align-items:center;">
                    <strong>${ws.name}</strong>
                    <button class="wr-btn wr-btn-secondary" data-select-skill-id="${ws.skillId}" style="padding:2px 8px;font-size:11px;">فحص المهارة</button>
                  </div>
                  <div style="font-size:11px;color:#fda4af;margin-top:3px;">الأسباب: ${ws.primaryReasons.join(' | ')}</div>
                  <div style="font-size:10px;color:var(--text-muted);">Competence: ${ws.competence}% • Mastery: ${ws.mastery}% • Retention: ${ws.retention}% • Historical Mastery: ${ws.historicalMasteryAchieved ? 'YES' : 'NO'}</div>
                </div>
              `).join('')}
            </div>
            ${scan.weakSubskills.length > 0 ? `
              <div style="margin-top:8px;font-size:11px;" id="diag-weak-subskills-list">
                <strong>مهارات فرعية ضعيفة:</strong>
                ${scan.weakSubskills.map((sub) => `<span class="wr-badge badge-primary" style="margin-right:4px;">${sub.name} (Errors: ${sub.openErrorsCount})</span>`).join('')}
              </div>
            ` : ''}
          </div>

          <div class="wr-cap-card" style="border-color:rgba(251,191,36,0.4);">
            <div style="font-size:13px;font-weight:700;color:#fcd34d;margin-bottom:6px;">
              ⏰ المراجعات المتأخرة، سجل التقييمات التشخيصية، و5D Progress Audit
            </div>
            <div id="diag-overdue-reviews-list" style="font-size:12px;margin-bottom:8px;">
              <div>📌 مهارات مستحقة لمراجعة الصيانة (Overdue Maintenance): <strong>${scan.overdueMaintenanceSkills.length}</strong></div>
              <div>🗂️ بطاقات استرجاع مستحقة (Due Flashcards): <strong>${scan.dueFlashcardsCount}</strong></div>
              <div>🔬 تقييمات تشخيصية مسجلة (Diagnostic Assessments): <strong id="diag-assessments-count">${diagnosticAssessments.length}</strong></div>
            </div>
            <div style="background:var(--bg-primary);padding:8px;border-radius:6px;font-size:11px;" id="diag-5d-progress-audit">
              <div style="font-weight:700;color:var(--accent-cyan);margin-bottom:4px;">📊 التقدم الخماسي المستقل (5D System Progress — No Double Counting: ${evAudit.zeroDoubleCountingVerified ? 'VERIFIED ✅' : 'CHECK'})</div>
              <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:4px;text-align:center;">
                <div><div>Activity</div><strong>${dims.activity}%</strong></div>
                <div><div>Learning</div><strong>${dims.learning}%</strong></div>
                <div><div>Comp.</div><strong>${dims.competence}%</strong></div>
                <div><div>Mastery</div><strong>${dims.mastery}%</strong></div>
                <div><div>Retent.</div><strong>${dims.retention}%</strong></div>
              </div>
              <div style="font-size:10px;color:var(--text-muted);margin-top:4px;">
                توزيع الأدلة الموثقة (${evAudit.totalEvidenceRecords}): Learning=${evAudit.learningEvidenceCount} | Competence=${evAudit.competenceEvidenceCount} | Retention=${evAudit.retentionEvidenceCount}
              </div>
            </div>
          </div>
        </div>

        <!-- 2. RUN DIAGNOSTIC ASSESSMENT & EXECUTE VERIFIED RETEST FORMS -->
        <div class="wr-form-grid" style="margin-bottom:16px;">
          <form id="form-run-diagnostic" class="wr-cap-card" style="background:var(--bg-secondary);">
            <div style="font-weight:700;font-size:13px;color:var(--accent-cyan);margin-bottom:8px;">
              🔬 1. إجراء تقييم تشخيصي مبني على الأدلة (Run Diagnostic Assessment)
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px;">
              <div class="wr-field">
                <label>المهارة (Skill)</label>
                <select id="diag-skill-id" class="wr-select">
                  ${skills.map((s) => `<option value="${s.id}" ${s.id === selectedSkillId ? 'selected' : ''}>${s.nameAr || s.name}</option>`).join('')}
                </select>
              </div>
              <div class="wr-field">
                <label>المهارة الفرعية (Subskill)</label>
                <select id="diag-subskill-id" class="wr-select">
                  <option value="">-- عام للمهارة --</option>
                  ${subskills.map((sub) => `<option value="${sub.id}">${sub.name}</option>`).join('')}
                </select>
              </div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:8px;">
              <div class="wr-field">
                <label>الدرجة المرصودة %</label>
                <input type="number" id="diag-score-input" class="wr-input" value="58" min="0" max="100" required />
              </div>
              <div class="wr-field">
                <label>الدقة المرصودة %</label>
                <input type="number" id="diag-accuracy-input" class="wr-input" value="55" min="0" max="100" required />
              </div>
              <div class="wr-field">
                <label>تصنيف الخطأ (Taxonomy)</label>
                <select id="diag-category-input" class="wr-select">
                  ${ERROR_TAXONOMY_CATEGORIES.map((cat) => `<option value="${cat}">${taxonomy[cat]?.labelAr || cat}</option>`).join('')}
                </select>
              </div>
            </div>
            <div class="wr-field" style="margin-bottom:8px;">
              <label>الوقائع المرصودة (Observed Facts — بدون افتراضات غير مدعومة)</label>
              <input type="text" id="diag-observed-notes" class="wr-input" value="إخفاق في تطبيق شرط التوقف في المسألة الثانية مع انخفاض الدقة" required />
            </div>
            <button type="submit" class="wr-btn wr-btn-primary" id="btn-submit-diagnostic" style="width:100%;">
              🩺 تنفيذ التشخيص وتوليد فرضيات السبب الجذري
            </button>
          </form>

          <form id="form-verified-retest" class="wr-cap-card" style="background:var(--bg-secondary);">
            <div style="font-weight:700;font-size:13px;color:#6ee7b7;margin-bottom:8px;">
              🎯 2. تنفيذ إعادة اختبار محققة (Verified Retest — يمنع التكرار الحرفي)
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px;">
              <div class="wr-field">
                <label>الخطأ المرتبط (Linked Error)</label>
                <select id="retest-error-id" class="wr-select">
                  ${openErrors.length === 0 ? `<option value="">-- لا توجد أخطاء مفتوحة --</option>` : openErrors.map((e) => `<option value="${e.id}">${e.description.slice(0, 42)} (${e.status})</option>`).join('')}
                </select>
              </div>
              <div class="wr-field">
                <label>نمط التحقق (Verification Mode)</label>
                <select id="retest-verification-mode" class="wr-select">
                  ${RETEST_VERIFICATION_MODES.map((vm) => `<option value="${vm}">${vm}</option>`).join('')}
                </select>
              </div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px;">
              <div class="wr-field">
                <label>درجة إعادة الاختبار %</label>
                <input type="number" id="retest-score-input" class="wr-input" value="92" min="0" max="100" required />
              </div>
              <div class="wr-field">
                <label>دقة الأداء %</label>
                <input type="number" id="retest-accuracy-input" class="wr-input" value="90" min="0" max="100" required />
              </div>
            </div>
            <div class="wr-field" style="margin-bottom:8px;">
              <label>دليل التحقق التطبيقي (Verification Evidence)</label>
              <input type="text" id="retest-evidence-input" class="wr-input" value="حل مسألتين جديدتين في سياق مختلف بشكل مستقل بدون أخطاء" required />
            </div>
            <button type="submit" class="wr-btn wr-btn-primary" id="btn-submit-verified-retest" style="width:100%;background:var(--accent-emerald);">
              ✅ تسجيل إعادة الاختبار والتحقق من إغلاق الخطأ
            </button>
          </form>
        </div>

        <!-- 3. INSPECT ERRORS, OBSERVED FACTS, ROOT-CAUSE HYPOTHESES, UNCERTAINTY & REMEDIATION TASKS -->
        <div class="wr-card" style="background:var(--bg-secondary);margin-bottom:16px;" id="diag-errors-inspector-section">
          <div style="font-size:14px;font-weight:700;color:#fda4af;margin-bottom:10px;">
            🔍 فاحص الأخطاء، الوقائع المرصودة، فرضيات السبب الجذري، والمهام التصحيحية (Errors & Root-Cause Hypotheses: ${errors.length})
          </div>
          <div class="wr-task-list" id="diag-errors-inspector-list">
            ${errors.length === 0 ? `<div style="font-size:12px;color:var(--text-muted);">لا توجد أخطاء مسجلة بعد. قم بإجراء تقييم تشخيصي أعلاه لرصد الفجوات.</div>` : errors.map((err) => {
              const rem = remediations.find((r) => r.id === err.remediationId || r.errorId === err.id);
              const taxMeta = taxonomy[err.category] || { labelAr: err.category };
              const hyps = Array.isArray(err.hypotheses) ? err.hypotheses : [];
              const facts = Array.isArray(err.observedFacts) && err.observedFacts.length > 0 ? err.observedFacts : [err.evidence || err.description];
              return `
                <div class="wr-cap-card" data-error-card-id="${err.id}" id="error-inspector-card-${err.id}" style="background:var(--bg-primary);border-color:${err.status === 'resolved' ? 'rgba(16,185,129,0.4)' : 'rgba(244,63,94,0.45)'};">
                  <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;margin-bottom:6px;">
                    <div>
                      <span class="wr-badge ${err.status === 'resolved' ? 'badge-recovery' : 'badge-primary'}">${err.status.toUpperCase()}</span>
                      <span class="wr-badge badge-focus">${taxMeta.labelAr || err.category}</span>
                      <span class="wr-badge badge-maintenance">State: ${err.classificationState || 'hypothesized'}</span>
                      <strong style="margin-right:6px;">${err.description}</strong>
                    </div>
                    <span style="font-size:11px;color:var(--text-muted);">المهارة: ${skillMap[err.skillId]?.nameAr || err.skillId} • المحاولات الفاشلة: ${err.failureCount || 1}</span>
                  </div>

                  <!-- Observed Facts vs Inferred Hypotheses -->
                  <div style="font-size:11px;background:var(--bg-secondary);padding:8px;border-radius:6px;margin-bottom:8px;">
                    <div style="color:var(--accent-cyan);font-weight:700;">📌 الوقائع المرصودة فعلياً (Observed Facts):</div>
                    <ul style="margin:4px 0 6px 18px;color:var(--text-secondary);">
                      ${facts.map((f) => `<li>${f}</li>`).join('')}
                    </ul>
                    <div style="color:#fcd34d;font-weight:700;">💡 الفرضيات التفسيرية وعدم اليقين (Root-Cause Hypotheses & Uncertainty):</div>
                    ${hyps.length === 0 ? `<div style="color:var(--text-muted);">${err.cause || 'قيد الفحص التشخيصي'}</div>` : hyps.map((h) => `
                      <div style="margin-top:4px;padding:6px;background:var(--bg-primary);border-radius:4px;">
                        <div><strong>الفرضية (${h.category}):</strong> ${h.explanation} <span class="wr-badge badge-focus">Confidence: ${h.confidenceLevel || 'moderate'}</span></div>
                        <div style="color:var(--text-muted);"><strong>الأدلة الداعمة:</strong> ${(h.supportingEvidence || []).join(' | ')}</div>
                        <div style="color:#fda4af;"><strong>ملاحظة عدم اليقين:</strong> ${h.uncertaintyNote || ''}</div>
                        <div style="color:#6ee7b7;"><strong>طريقة التحقق الموصى بها:</strong> ${h.verificationMethod || ''}</div>
                      </div>
                    `).join('')}
                  </div>

                  <!-- Remediation & Corrective Practice Controls -->
                  ${err.status !== 'resolved' ? `
                    <div style="margin-top:6px;">
                      ${!rem ? `
                        <button class="wr-btn wr-btn-amber" data-action="generate-targeted-remediation" data-error-id="${err.id}" id="btn-gen-rem-${err.id}" style="font-size:12px;">
                          🛠️ توليد خطة علاجية ومهام تصحيحية مخصصة (${taxMeta.labelAr || err.category})
                        </button>
                      ` : `
                        <div style="background:rgba(20,184,166,0.08);border:1px solid var(--border-color);padding:8px;border-radius:6px;font-size:12px;">
                          <div><strong>الخطة العلاجية (${rem.status}):</strong> ${rem.title} — <em>Retest Allowed: ${rem.retestAllowed ? 'YES ✅' : 'NO (أكمل المهام التصحيحية أولاً)'}</em></div>
                          <div style="font-size:11px;color:var(--text-muted);margin-top:2px;">الاستراتيجية: ${rem.strategy}</div>
                        </div>
                      `}
                    </div>
                  ` : `
                    <div style="font-size:11px;color:#6ee7b7;">
                      ✅ تم إغلاق الخطأ بعد التحقق عبر المحاولة (${err.resolvedByAttemptId}) بنمط تحقق (${err.verificationMode || 'equivalent_questions'}).
                    </div>
                  `}
                </div>
              `;
            }).join('')}
          </div>

          <!-- Active Corrective Tasks for Selected Skill -->
          ${allTasks.length > 0 ? `
            <div style="margin-top:12px;" id="diag-corrective-tasks-box">
              <div style="font-size:13px;font-weight:700;color:var(--accent-cyan);margin-bottom:6px;">
                🏋️ المهام التصحيحية المرتبطة بالمهارة المحددة (${selSkill?.nameAr || ''}: ${allTasks.length})
              </div>
              ${allTasks.map((ct) => `
                <div style="display:flex;justify-content:space-between;align-items:center;background:var(--bg-primary);padding:8px 10px;border-radius:6px;margin-bottom:6px;font-size:12px;">
                  <div>
                    <span>${ct.status === 'completed' ? '✅' : '⏳'} <strong>${ct.title}</strong> (${ct.plannedDurationMin} د)</span>
                    <div style="font-size:11px;color:var(--text-muted);">Error ID: ${ct.errorId} • Remediation ID: ${ct.remediationId}</div>
                  </div>
                  <div style="display:flex;gap:6px;">
                    ${ct.status !== 'completed' ? `
                      <button class="wr-btn wr-btn-secondary" data-action="start-task-timer" data-task-id="${ct.id}" style="font-size:11px;padding:4px 8px;">▶ بدء بالمؤقت</button>
                      <button class="wr-btn wr-btn-primary" data-action="complete-corrective-task" data-task-id="${ct.id}" id="btn-complete-corr-${ct.id}" style="font-size:11px;padding:4px 8px;">✅ إتمام وتوثيق دليل العلاج</button>
                    ` : `<span class="wr-badge badge-recovery">مكتملة وموثقة</span>`}
                  </div>
                </div>
              `).join('')}
            </div>
          ` : ''}
        </div>

        <!-- 4. MASTERY GATE TRACEABILITY & HISTORICAL MASTERY VS RETENTION HISTORY (UI Requirement 7 & 8) -->
        <div class="wr-form-grid">
          <div class="wr-cap-card" id="diag-mastery-gate-traceability">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
              <div style="font-weight:700;font-size:13px;color:var(--accent-cyan);">
                🏛️ تفسير قرار بوابة الإتقان (Mastery Gate Traceability: ${selSkill?.nameAr || ''})
              </div>
              <span class="wr-badge ${gate?.passed ? 'badge-recovery' : 'badge-primary'}" id="diag-gate-verdict-badge">
                ${gate?.passed ? 'PASSED ✅' : 'BLOCKED ❌'}
              </span>
            </div>
            <div style="font-size:12px;background:var(--bg-primary);padding:8px;border-radius:6px;margin-bottom:8px;" id="diag-gate-explanation-text">
              ${gate?.decisionExplanation || ''}
            </div>
            <table class="wr-table" style="font-size:11px;">
              <thead>
                <tr>
                  <th>المعيار (Criterion)</th>
                  <th>المطلوب</th>
                  <th>الفعلي</th>
                  <th>الحالة</th>
                </tr>
              </thead>
              <tbody>
                ${(gate?.criteriaBreakdown || []).map((row) => `
                  <tr>
                    <td>${row.label}</td>
                    <td>${row.required}</td>
                    <td>${row.actual}</td>
                    <td>${row.passed ? '✅ محقق' : '❌ غير محقق'}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>

          <div class="wr-cap-card" id="diag-retention-and-history-panel">
            <div style="font-weight:700;font-size:13px;color:#d8b4fe;margin-bottom:6px;">
              🛡️ سجل الإتقان التاريخي وفحوصات الاحتفاظ (Historical Mastery vs. Current Retention)
            </div>
            <div style="font-size:12px;background:var(--bg-primary);padding:8px;border-radius:6px;margin-bottom:8px;" id="diag-retention-status-strip">
              <div>🏆 الإتقان التاريخي للمهارة المحددة (Historical Mastery Achieved): <strong id="diag-hist-mastery-flag">${selSkill?.historicalMasteryAchieved ? 'نعم — محفوظ تاريخياً ✅' : 'لم يصل للإتقان بعد'}</strong></div>
              <div>🔄 حالة الاحتفاظ الحالية (Current Retention Status): <strong id="diag-curr-retention-status" style="color:var(--accent-cyan);">${selSkill?.currentRetentionStatus || 'UNMASTERED'}</strong></div>
            </div>

            <form id="form-diag-retention-check" style="margin-bottom:10px;">
              <div style="display:grid;grid-template-columns:1fr 2fr;gap:8px;margin-bottom:6px;">
                <div class="wr-field">
                  <label>درجة فحص الاحتفاظ %</label>
                  <input type="number" id="diag-ret-score" class="wr-input" value="90" min="0" max="100" required />
                </div>
                <div class="wr-field">
                  <label>دليل الأداء الفعلي (مطلوب للإثبات)</label>
                  <input type="text" id="diag-ret-evidence" class="wr-input" value="حل مسألة استبقاء من الذاكرة بدون مراجعة" required />
                </div>
              </div>
              <button type="submit" class="wr-btn wr-btn-secondary" id="btn-submit-diag-retention" style="width:100%;">
                🧪 تسجيل فحص احتفاظ للمهارة المحددة (${selSkill?.nameAr || ''})
              </button>
            </form>

            <div style="font-size:11px;font-weight:700;margin-bottom:4px;">📜 سجل انتقالات الإتقان والصيانة (Mastery & Retention History: ${masteryHistory.length} / Reviews: ${reviews.length})</div>
            <div id="diag-mastery-history-list" style="max-height:170px;overflow-y:auto;">
              ${masteryHistory.length === 0 ? `<div style="font-size:11px;color:var(--text-muted);">لا توجد انتقالات إتقان مسجلة بعد.</div>` : masteryHistory.slice(0, 6).map((mh) => `
                <div style="font-size:11px;background:var(--bg-primary);padding:6px;border-radius:4px;margin-bottom:4px;">
                  <span class="wr-badge badge-focus">${mh.eventType}</span>
                  <strong>${skillMap[mh.skillId]?.nameAr || mh.entityId}</strong> (${mh.previousState} → ${mh.newState})
                  <div style="color:var(--text-muted);">Historical Preserved: ${mh.historicalMasteryPreserved ? 'YES' : 'NO'} • Retention: ${mh.currentRetentionStatus}</div>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      </section>
    `;
  }



  // =========================================================================
  // PHASE 7: ADAPTIVE STRATEGY, PRIORITY OPTIMIZATION & NEXT-BEST-ACTION TAB
  // =========================================================================
  function renderStrategyAndPriorityTab(state, skillMap) {
    const {
      currentDate,
      currentEnergy,
      strategyBundle,
    } = state;

    if (!strategyBundle) {
      return `<section class="wr-card" id="tab-panel-strategy"><div>جارٍ تحميل محرك القرار الاستراتيجي...</div></section>`;
    }

    const {
      isEmptyDatabase,
      rankedRecommendations = [],
      blockedCandidates = [],
      suppressedDismissedRecommendations = [],
      bottleneckAnalysis = { circularDependencies: [], bottlenecks: [], blockedSkills: [], blockedGoals: [] },
      dailyStrategicPlan = {},
      weeklyStrategicProposal = {},
      effectivenessAnalytics = null,
      outcomeDefinitionsByType = {},
      strategicDecisionsHistory = [],
      outcomeEvaluationsHistory = [],
    } = strategyBundle;
    const effOverall = effectivenessAnalytics?.overall || { separateMetrics: {}, verifiedOutcomesCount: 0 };
    const effByType = effectivenessAnalytics?.byRecommendationType || {};
    const effGov = effectivenessAnalytics?.typeRankingGovernance || {};

    const wCheck = dailyStrategicPlan.workloadAndRecoveryCheck || {};
    const infoGuide = dailyStrategicPlan.insufficientEvidenceGuidance || {};

    return `
      <section class="wr-card" id="tab-panel-strategy">
        <div class="wr-card-header">
          <div>
            <div class="wr-card-title">🧭 PHASE 7: ADAPTIVE STRATEGY, PRIORITY OPTIMIZATION & NEXT-BEST-ACTION ENGINE</div>
            <div style="font-size:12px;color:var(--text-muted);">
              ماذا أفعل بعد ذلك؟ لماذا هو الأعلى قيمة؟ أي اختناق يعالجه؟ ما الأدلة الداعمة؟ كم يتطلب من الوقت والجهد؟ وكيف أتحقق من نجاحه؟
            </div>
          </div>
          <span class="wr-badge ${isEmptyDatabase ? "badge-maintenance" : bottleneckAnalysis.hasCircularDependencies ? "badge-primary" : "badge-focus"}" id="strategy-status-badge">
            ${isEmptyDatabase
              ? "⚠️ Empty Database State"
              : bottleneckAnalysis.hasCircularDependencies
              ? `⚠️ Circular Dependencies: ${bottleneckAnalysis.circularDependencies.length}`
              : `✅ Cycle-Free Graph • ${rankedRecommendations.length} Ranked Actions`}
          </span>
        </div>

        <!-- Insufficient Evidence / Information-Gathering Banner -->
        ${infoGuide.hasInsufficientEvidence ? `
          <div style="background:rgba(245,158,11,0.12);border:1px solid rgba(245,158,11,0.45);padding:10px 12px;border-radius:8px;margin-bottom:14px;font-size:12px;" id="strategy-insufficient-evidence-banner">
            <strong style="color:#fcd34d;">🔎 تنبيه كفاية الأدلة وقيمة جمع المعلومات (Information-Gathering Guidance):</strong>
            <span> ${infoGuide.explanation}</span>
            ${infoGuide.recommendedInformationGatheringAction ? `
              <div style="margin-top:4px;color:var(--accent-cyan);">
                الإجراء الاستقصائي الموصى به أولاً: <strong>${infoGuide.recommendedInformationGatheringAction.title}</strong>
              </div>
            ` : ""}
          </div>
        ` : ""}

        <!-- 1. DAILY STRATEGIC PLAN PROPOSAL (Section 5) -->
        <div class="wr-card" style="background:var(--bg-secondary);margin-bottom:16px;" id="strategy-daily-proposal-section">
          <div class="wr-card-header">
            <div>
              <div class="wr-card-title">⚡ المقترح الاستراتيجي لليوم (Daily Strategic Proposal: ${currentDate} • طاقة ${currentEnergy}/10)</div>
              <div style="font-size:11px;color:var(--text-muted);">
                أولوية استراتيجية رئيسية واحدة + عدد محدود من الإجراءات الداعمة + فحوصات الاحتفاظ والعلاج + ترك وقت حر غير مخصص (${wCheck.unallocatedFreeMinutes ?? 0} د) وحفظ ${wCheck.preservedSafetyBufferMinutes ?? 30} د Buffer بدون مضاعفة حمل الغد
              </div>
            </div>
            <span class="wr-badge ${wCheck.isOverloaded ? "badge-primary" : "badge-recovery"}" id="strategy-daily-workload-badge">
              المخصص: ${wCheck.allocatedStrategicMinutes ?? 0} د / السقف: ${wCheck.schedulableCeilingMinutes ?? 180} د (غير مخصص: ${wCheck.unallocatedFreeMinutes ?? 0} د)
            </span>
          </div>

          <div class="wr-form-grid" style="margin-bottom:12px;">
            <div class="wr-cap-card" style="background:var(--bg-primary);border-color:var(--accent-cyan);" id="strategy-primary-priority-box">
              <div style="font-size:11px;font-weight:700;color:var(--accent-cyan);">🎯 1. الأولوية الاستراتيجية الرئيسية لليوم (Primary Strategic Priority)</div>
              ${dailyStrategicPlan.primaryStrategicPriority ? `
                <div style="font-weight:800;font-size:14px;margin-top:4px;">${dailyStrategicPlan.primaryStrategicPriority.title}</div>
                <div style="font-size:11px;color:var(--text-secondary);margin-top:3px;">
                  Score: <strong>${dailyStrategicPlan.primaryStrategicPriority.score}/100</strong> • الجهد المقدر: <strong>${dailyStrategicPlan.primaryStrategicPriority.estimatedEffort.durationMinutes} د</strong> • العملية: <code>${dailyStrategicPlan.primaryStrategicPriority.executableOperation}</code>
                </div>
                <div style="font-size:11px;color:#6ee7b7;margin-top:3px;">
                  <strong>لماذا يتصدر:</strong> ${dailyStrategicPlan.primaryStrategicPriority.rankingExplanation}
                </div>
              ` : `<div style="font-size:12px;color:var(--text-muted);margin-top:4px;">لا توجد أولوية مؤهلة حالياً (Empty State).</div>`}
            </div>

            <div class="wr-cap-card" style="background:var(--bg-primary);" id="strategy-supporting-and-retention-box">
              <div style="font-size:11px;font-weight:700;color:var(--accent-blue);">🛠️ 2. الإجراءات الداعمة، العلاجية، وفحوصات الاحتفاظ المستحقة</div>
              <div style="font-size:11px;margin-top:4px;">
                <div>• إجراءات داعمة (${(dailyStrategicPlan.supportingActions || []).length}): <strong>${(dailyStrategicPlan.supportingActions || []).map((a) => a.title).join(" | ") || "لا يوجد"}</strong></div>
                <div style="margin-top:3px;">• أعمال تصحيحية حرجة (${(dailyStrategicPlan.importantCorrectiveWork || []).length}): <strong>${(dailyStrategicPlan.importantCorrectiveWork || []).map((a) => a.title).join(" | ") || "لا يوجد"}</strong></div>
                <div style="margin-top:3px;">• احتفاظ وصيانة مستحقة (${(dailyStrategicPlan.dueRetentionOrMaintenance || []).length}): <strong>${(dailyStrategicPlan.dueRetentionOrMaintenance || []).map((a) => a.title).join(" | ") || "لا يوجد"}</strong></div>
              </div>
            </div>
          </div>

          ${(dailyStrategicPlan.deferredActions || []).length > 0 ? `
            <div style="font-size:11px;background:var(--bg-primary);padding:8px 10px;border-radius:6px;" id="strategy-deferred-actions-box">
              <strong style="color:#fcd34d;">⏳ إجراءات مؤجلة صراحةً مع سبب التأجيل (${dailyStrategicPlan.deferredActions.length}):</strong>
              ${dailyStrategicPlan.deferredActions.slice(0, 4).map((da) => `
                <div style="margin-top:3px;color:var(--text-secondary);">
                  • <strong>${da.title}</strong> (${da.estimatedMinutes} د) — <em>${da.deferralReason}</em> [<code>${da.constraintCode}</code>]
                </div>
              `).join("")}
            </div>
          ` : ""}
        </div>

        <!-- 2. RANKED NEXT-BEST ACTIONS QUEUE WITH FULL EXPLAINABILITY & FEEDBACK CONTROLS (Sections 2, 3, 7, 8) -->
        <div class="wr-card" style="background:var(--bg-secondary);margin-bottom:16px;" id="strategy-ranked-nba-section">
          <div style="font-size:14px;font-weight:700;color:var(--accent-cyan);margin-bottom:10px;">
            🏆 قائمة أفضل الإجراءات التالية المرتبة بالأدلة (Ranked Next-Best Actions: <span id="strategy-ranked-count">${rankedRecommendations.length}</span>)
          </div>

          <div class="wr-task-list" id="strategy-ranked-nba-list">
            ${rankedRecommendations.length === 0 ? `
              <div style="font-size:12px;color:var(--text-muted);padding:12px;background:var(--bg-primary);border-radius:8px;">
                لا توجد توصيات نشطة حالياً (قاعدة البيانات فارغة أو تم استبعاد جميع التوصيات الحالية لحين ظهور أدلة جديدة).
              </div>
            ` : rankedRecommendations.map((rec) => `
              <div class="wr-cap-card" data-recommendation-key="${rec.recommendationKey}" id="nba-card-${rec.recommendationKey}" style="background:var(--bg-primary);border-color:${rec.rank === 1 ? "var(--accent-cyan)" : "var(--border-subtle)"};">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;margin-bottom:6px;">
                  <div>
                    <span class="wr-badge badge-focus">#${rec.rank} • Score: ${rec.score}/100</span>
                    <span class="wr-badge badge-secondary">${rec.actionType}</span>
                    <span class="wr-badge badge-recovery">Prereq: ${rec.dependenciesAndPrerequisites.status}</span>
                    ${rec.latestDecisionStatus ? `<span class="wr-badge badge-maintenance">Decision: ${rec.latestDecisionStatus}</span>` : ""}
                    ${rec.reconsideredDueToNewEvidence ? `<span class="wr-badge badge-primary">🔔 أُعيد عرضها لظهور دليل جديد</span>` : ""}
                  </div>
                  <span style="font-size:11px;font-family:monospace;color:var(--text-muted);">
                    ⏱ ${rec.estimatedEffort.durationMinutes} د • ⚡ طاقة ${rec.estimatedEffort.energyDemand}/10 • ${rec.deadlineUrgency.urgencyLabel}
                  </span>
                </div>

                <div style="font-weight:800;font-size:14px;margin-bottom:6px;">${rec.title}</div>

                <div style="font-size:11px;background:var(--bg-secondary);padding:8px;border-radius:6px;margin-bottom:8px;color:var(--text-secondary);">
                  <div>📌 <strong>الأدلة المسجلة الداعمة (Supporting Evidence):</strong> ${rec.supportingEvidence.map((e) => e.summary).join(" | ")}</div>
                  <div style="margin-top:3px;">🧭 <strong>المبرر الاستراتيجي (Rationale):</strong> ${rec.strategicRationale}</div>
                  <div style="margin-top:3px;color:#6ee7b7;">📈 <strong>العائد المتوقع (Expected Benefit):</strong> ${rec.expectedBenefit.summary}</div>
                  <div style="margin-top:3px;color:#fcd34d;">⚖️ <strong>تكلفة الفرصة البديلة (Opportunity Cost):</strong> ${rec.opportunityCost}</div>
                  <div style="margin-top:3px;">📊 <strong>تفصيل الدرجة والترتيب (10-Factor Score Breakdown):</strong> ${rec.rankingExplanation}</div>
                  <div style="margin-top:3px;color:#fda4af;">🔬 <strong>كفاية الأدلة وعدم اليقين (${rec.evidenceSufficiencyAndUncertainty.status}):</strong> ${rec.evidenceSufficiencyAndUncertainty.uncertaintyNote}</div>
                  <div style="margin-top:3px;color:var(--accent-cyan);">✅ <strong>طريقة التحقق من النتيجة (Verification Method):</strong> ${rec.verificationMethod}</div>
                  ${rec.outcomeRuleDefinition ? `<div style="margin-top:3px;color:#cbd5e1;">📏 <strong>قاعدة النتيجة الموثقة (Outcome Rule • نافذة ${rec.outcomeRuleDefinition.defaultObservationWindowDays} يوم):</strong> المتوقع: ${rec.outcomeRuleDefinition.expectedResult} | القيود: ${rec.outcomeRuleDefinition.knownLimitations}</div>` : ""}
                  ${rec.calibrationFeedback ? `<div style="margin-top:3px;color:${rec.calibrationFeedback.isCalibrated ? "#fcd34d" : "#94a3b8"};">⚖️ <strong>معايرة الأدلة التاريخية (Calibration Delta: ${rec.calibrationFeedback.calibrationDelta >= 0 ? "+" : ""}${rec.calibrationFeedback.calibrationDelta}):</strong> ${rec.calibrationFeedback.explanation}</div>` : ""}
                </div>

                <!-- Functional Accept, Modify, Defer, Reject, Dismiss & Jump Controls -->
                <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;">
                  <button type="button" class="wr-btn wr-btn-primary" data-action="strategy-accept" data-rec-key="${rec.recommendationKey}" id="btn-accept-${rec.recommendationKey}" style="font-size:11px;padding:5px 10px;">
                    ✅ اعتماد وجدولة (Accept)
                  </button>
                  <button type="button" class="wr-btn wr-btn-secondary" data-action="strategy-modify" data-rec-key="${rec.recommendationKey}" id="btn-modify-${rec.recommendationKey}" style="font-size:11px;padding:5px 10px;">
                    ✏️ تعديل (20 د) واعتماد (Modify)
                  </button>
                  <button type="button" class="wr-btn wr-btn-amber" data-action="strategy-defer" data-rec-key="${rec.recommendationKey}" id="btn-defer-${rec.recommendationKey}" style="font-size:11px;padding:5px 10px;">
                    ⏳ تأجيل (Defer)
                  </button>
                  <button type="button" class="wr-btn wr-btn-danger" data-action="strategy-reject" data-rec-key="${rec.recommendationKey}" id="btn-reject-${rec.recommendationKey}" style="font-size:11px;padding:5px 10px;">
                    ✖ رفض (Reject)
                  </button>
                  <button type="button" class="wr-btn wr-btn-secondary" data-action="strategy-dismiss" data-rec-key="${rec.recommendationKey}" id="btn-dismiss-${rec.recommendationKey}" style="font-size:11px;padding:5px 10px;">
                    🔕 استبعاد مؤقت (Dismiss)
                  </button>
                  ${rec.target?.skillId ? `
                    <button type="button" class="wr-btn wr-btn-secondary" data-jump-skill-id="${rec.target.skillId}" data-jump-tab="diagnostics" style="font-size:11px;padding:5px 10px;">
                      🩺 فتح التشخيص والمهارة
                    </button>
                  ` : ""}
                </div>
              </div>
            `).join("")}
          </div>
        </div>

        <!-- 3. BOTTLENECK ANALYSIS & WEEKLY STRATEGIC REVIEW (Sections 4 & 6) -->
        <div class="wr-form-grid" style="margin-bottom:16px;">
          <div class="wr-cap-card" style="background:var(--bg-secondary);" id="strategy-bottlenecks-section">
            <div style="font-size:13px;font-weight:700;color:#fda4af;margin-bottom:8px;">
              🚧 تحليل اختناقات المتطلبات السابقة وفحص الاعتماد الدائري (Bottlenecks: ${bottleneckAnalysis.bottlenecks.length})
            </div>
            ${bottleneckAnalysis.circularDependencies.length > 0 ? `
              <div style="background:rgba(244,63,94,0.15);border:1px solid rgba(244,63,94,0.5);padding:6px 8px;border-radius:6px;font-size:11px;color:#fda4af;margin-bottom:8px;" id="strategy-cycle-warning">
                ⚠️ تم رصد (${bottleneckAnalysis.circularDependencies.length}) اعتماد دائري: ${bottleneckAnalysis.circularDependencies.map((c) => c.description).join(" | ")}
              </div>
            ` : `<div style="font-size:11px;color:#6ee7b7;margin-bottom:6px;">✅ شبكة المتطلبات السابقة سليمة وخالية من أي حلقات دائرية (0 Circular Dependencies).</div>`}

            <div class="wr-task-list" id="strategy-bottlenecks-list">
              ${bottleneckAnalysis.bottlenecks.slice(0, 4).map((b) => `
                <div style="background:var(--bg-primary);padding:8px;border-radius:6px;font-size:11px;">
                  <div style="display:flex;justify-content:space-between;">
                    <strong>${b.skillName} (${b.status})</strong>
                    <span class="wr-badge badge-primary">Impact: ${b.bottleneckImpactScore}</span>
                  </div>
                  <div style="color:var(--text-secondary);margin-top:3px;">
                    يفتح (${b.transitiveBlockedSkillIds.length}) مهارة تالية: ${b.transitiveBlockedSkillNames.join("، ") || "لا يوجد"} • يؤثر على (${b.affectedGoalIds.length}) أهداف
                  </div>
                  ${b.taskCompletionWithoutMasteryNote ? `<div style="color:#fcd34d;margin-top:2px;">⚠️ ${b.taskCompletionWithoutMasteryNote}</div>` : ""}
                  <div style="color:var(--text-muted);margin-top:2px;">عدم اليقين: ${b.uncertaintyNote}</div>
                </div>
              `).join("")}
            </div>
          </div>

          <div class="wr-cap-card" style="background:var(--bg-secondary);" id="strategy-weekly-proposal-section">
            <div style="font-size:13px;font-weight:700;color:var(--accent-blue);margin-bottom:8px;">
              📅 المراجعة والمقترح الاستراتيجي الأسبوعي (Weekly Strategic Review: ${weeklyStrategicProposal.weekStartDate} → ${weeklyStrategicProposal.weekEndDate})
            </div>
            <div style="font-size:11px;background:var(--bg-primary);padding:8px;border-radius:6px;">
              <div>🔥 <strong>أهم اختناق هيكلي:</strong> ${weeklyStrategicProposal.mostImportantBottleneck ? `${weeklyStrategicProposal.mostImportantBottleneck.skillName} (يفتح ${weeklyStrategicProposal.mostImportantBottleneck.transitiveBlockedSkillIds.length} مهارات)` : "لا يوجد اختناق"}</div>
              <div style="margin-top:4px;color:#6ee7b7;">🏆 <strong>أقوى دليل تقدم:</strong> ${weeklyStrategicProposal.strongestEvidenceOfProgress?.summary || ""}</div>
              <div style="margin-top:4px;color:#fda4af;">⚠️ <strong>أخطر نقطة ضعف غير محلولة:</strong> ${weeklyStrategicProposal.mostConsequentialUnresolvedWeakness?.description || "لا توجد أخطاء مفتوحة"}</div>
              <div style="margin-top:4px;color:#fcd34d;">⚖️ <strong>المفاضلات بين الأهداف المتنافسة (Competing Goals Trade-Offs):</strong> ${(weeklyStrategicProposal.competingGoalsTradeOffs || []).map((t) => t.tradeOffExplanation).join(" | ") || "لا يوجد تعارض أهداف"}</div>
              ${(weeklyStrategicProposal.neglectedOrOveremphasizedSkills?.overemphasizedWithoutAssessmentSkills || []).length > 0 ? `
                <div style="margin-top:4px;color:#fcd34d;">
                  📊 <strong>مهارات ذات نشاط مرتفع بدون تقييم:</strong> ${weeklyStrategicProposal.neglectedOrOveremphasizedSkills.overemphasizedWithoutAssessmentSkills.map((s) => s.skillName).join("، ")}
                </div>
              ` : ""}
            </div>
          </div>
        </div>

        <!-- 4. PHASE 9: RECOMMENDATION EFFECTIVENESS ANALYTICS, DENOMINATORS & SAMPLE-SIZE GOVERNANCE (Sections 7, 8, 9, 10) -->
        <div class="wr-card" style="background:var(--bg-secondary);margin-bottom:16px;" id="strategy-effectiveness-analytics-section">
          <div class="wr-card-header">
            <div>
              <div class="wr-card-title">📊 PHASE 9: معايرة النتائج وفاعلية التوصيات بالأدلة (Outcome Calibration & Effectiveness Analytics)</div>
              <div style="font-size:11px;color:var(--text-muted);">
                6 مقاييس مستقلة بدون دمج مضلل • إظهار البسط والمقام وحجم العينة (n) • ضوابط السببية وعدم ادعاء السببية المطلقة • حماية العينات الصغيرة من الترتيب الزائف
              </div>
            </div>
            <span class="wr-badge ${effOverall.isSampleSizeSufficient ? "badge-recovery" : "badge-maintenance"}" id="strategy-sample-size-badge">
              Verified Sample: n=${effOverall.verifiedOutcomesCount || 0} (Min Required: ${effOverall.minSampleSizeRequired || 3})
            </span>
          </div>

          <div style="background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.35);padding:8px 10px;border-radius:6px;font-size:11px;color:#fcd34d;margin-bottom:12px;" id="strategy-sample-size-governance-box">
            ⚖️ <strong>حوكمة حجم العينة والسببية (Sample-Size & Causality Governance):</strong> ${effGov.governanceNote || ""} ${effOverall.sampleSizeWarning ? " • " + effOverall.sampleSizeWarning : ""}
          </div>

          <div class="wr-cap-grid" id="strategy-effectiveness-6d-grid" style="margin-bottom:14px;">
            ${Object.values(effOverall.separateMetrics || {}).map((m) => `
              <div class="wr-cap-card" data-eff-metric="${m.key}" id="eff-metric-${m.key}" style="background:var(--bg-primary);">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;">
                  <strong style="font-size:12px;color:var(--accent-cyan);">${m.labelAr}</strong>
                  <span class="wr-badge ${m.value === null ? "badge-maintenance" : "badge-focus"}" id="eff-val-${m.key}">${m.statusLabel}</span>
                </div>
                <div style="font-size:10px;color:var(--text-muted);font-family:monospace;">
                  المقام وحجم العينة: n=${m.sampleSize ?? 0} (${m.denominatorDescription || ""})
                </div>
                ${m.note ? `<div style="font-size:10px;color:#fcd34d;margin-top:3px;">${m.note}</div>` : ""}
              </div>
            `).join("")}
          </div>

          <div style="font-size:12px;font-weight:700;color:var(--accent-blue);margin-bottom:6px;">
            📋 ملخص الفاعلية والتغطية حسب نوع التوصية (Effectiveness Summary by Recommendation Type)
          </div>
          <div style="overflow-x:auto;">
            <table class="wr-table" id="strategy-effectiveness-by-type-table" style="font-size:11px;">
              <thead>
                <tr>
                  <th>نوع التوصية (Action Type)</th>
                  <th>الصادرة (Issued)</th>
                  <th>المقبولة (Accepted)</th>
                  <th>المرفوضة (Rejected)</th>
                  <th>المحققة (Verified n)</th>
                  <th>ناجحة (Success)</th>
                  <th>غير ناجحة (Unsuccessful)</th>
                  <th>غير حاسمة / معلقة</th>
                  <th>معدل النجاح المحقق</th>
                  <th>حالة العينة (Sample Status)</th>
                </tr>
              </thead>
              <tbody>
                ${Object.values(effByType).map((row) => `
                  <tr data-eff-type-row="${row.actionType}">
                    <td><strong>${row.actionType}</strong><div style="font-size:10px;color:var(--text-muted);">${row.titleAr}</div></td>
                    <td>${row.issuedCount}</td>
                    <td>${row.acceptedCount}</td>
                    <td>${row.rejectedCount}</td>
                    <td><strong>${row.verifiedOutcomesCount}</strong></td>
                    <td style="color:#6ee7b7;">${row.verifiedSuccessCount}</td>
                    <td style="color:#fda4af;">${row.verifiedFailureCount}</td>
                    <td>${row.inconclusiveCount} / ${row.pendingOrAwaitingCount}</td>
                    <td>${row.separateMetrics.verifiedOutcomeRate.statusLabel}</td>
                    <td>
                      <span class="wr-badge ${row.isSampleSizeSufficient ? "badge-recovery" : "badge-maintenance"}">
                        ${row.isSampleSizeSufficient ? "Sufficient (n≥3)" : `Small Sample (n=${row.verifiedOutcomesCount})`}
                      </span>
                    </td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
          </div>
        </div>

        <!-- 5. RECOMMENDATION FEEDBACK HISTORY, OUTCOME CALIBRATION & PRESERVED EVALUATIONS (Sections 6, 10, 11) -->
        <div class="wr-card" style="background:var(--bg-secondary);" id="strategy-decisions-history-section">
          <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:10px;">
            <div>
              <div style="font-size:14px;font-weight:700;color:var(--accent-cyan);">
                📜 سجل قرارات التوصيات والتحقق من النتائج الفعلية (Decisions History: <span id="strategy-decisions-count">${strategicDecisionsHistory.length}</span> • Suppressed Dismissed: <span id="strategy-suppressed-count">${suppressedDismissedRecommendations.length}</span>)
              </div>
              <div style="font-size:11px;color:var(--text-muted);">
                يتتبع القرارات (Accepted / Modified / Deferred / Rejected / Dismissed) ويتحقق مما إذا كانت الاختبارات أو العروض العملية اللاحقة قد أثبتت تحقق النتيجة المتوقعة
              </div>
            </div>
            <button type="button" class="wr-btn wr-btn-primary" id="btn-evaluate-strategy-outcomes">
              🔄 فحص وتقييم نتائج التوصيات المعتمدة
            </button>
          </div>

          <div id="strategy-decisions-list" class="wr-task-list">
            ${strategicDecisionsHistory.length === 0 ? `<div style="font-size:11px;color:var(--text-muted);">لم يتم تسجيل قرارات توصيات بعد.</div>` : strategicDecisionsHistory.slice(0, 8).map((dec) => `
              <div class="wr-cap-card" data-decision-id="${dec.id}" style="background:var(--bg-primary);font-size:11px;">
                <div style="display:flex;justify-content:space-between;align-items:center;">
                  <div>
                    <span class="wr-badge ${dec.status === "ACCEPTED" || dec.status === "MODIFIED" ? "badge-recovery" : dec.status === "DEFERRED" ? "badge-maintenance" : "badge-secondary"}">${dec.status}</span>
                    <strong>${dec.title}</strong>
                  </div>
                  <span class="wr-badge badge-focus" id="dec-outcome-${dec.id}">${dec.outcomeStatus}</span>
                </div>
                <div style="margin-top:3px;color:var(--text-secondary);">
                  الإجراء المنفذ: <code>${dec.actionPerformed}</code> • السبب/الملاحظة: ${dec.userReason}
                </div>
                <div style="margin-top:4px;font-size:11px;color:var(--accent-cyan);">
                  📌 <strong>حالة النتيجة المعيارية (Phase 9 Outcome State):</strong> <span class="wr-badge badge-focus" id="dec-outcome-state-${dec.id}">${dec.outcomeState || "PENDING"}</span>
                  • سجل التقييمات المحفوظة: <strong id="dec-eval-versions-${dec.id}">${(dec.outcomeEvaluationHistoryIds || []).length}</strong>
                </div>
                ${dec.outcomeEvaluation ? `
                  <div style="margin-top:4px;background:var(--bg-secondary);padding:6px 8px;border-radius:6px;color:${dec.outcomeEvaluation.expectedOutcomeOccurred ? "#6ee7b7" : "#fcd34d"};">
                    <div>🔬 <strong>التقييم (#v${dec.outcomeEvaluation.evaluationVersion || 1}):</strong> ${dec.outcomeEvaluation.summary} ${dec.shouldReconsider ? "(يُوصى بإعادة النظر Reconsider 🔄)" : ""}</div>
                    ${dec.outcomeEvaluation.baselineAndWindow ? `
                      <div style="color:var(--text-secondary);margin-top:2px;">
                        📏 <strong>خط الأساس والمقارنة (${dec.outcomeEvaluation.baselineAndWindow.baselineStatus}):</strong>
                        Baseline: ${dec.outcomeEvaluation.baselineAndWindow.baselineScore !== null ? dec.outcomeEvaluation.baselineAndWindow.baselineScore + "%" : "N/A"} →
                        Follow-up: ${dec.outcomeEvaluation.baselineAndWindow.followUpScore !== null ? dec.outcomeEvaluation.baselineAndWindow.followUpScore + "%" : "N/A"} |
                        Delta: <strong>${dec.outcomeEvaluation.baselineAndWindow.prePostDelta !== null ? (dec.outcomeEvaluation.baselineAndWindow.prePostDelta >= 0 ? "+" : "") + dec.outcomeEvaluation.baselineAndWindow.prePostDelta + " pts" : "غير قابل للقياس الكمي"}</strong>
                        (${dec.outcomeEvaluation.baselineAndWindow.comparabilityStatus})
                      </div>
                    ` : ""}
                    ${dec.outcomeEvaluation.expectedVsObserved ? `
                      <div style="color:#cbd5e1;margin-top:2px;">
                        🎯 <strong>المتوقع:</strong> ${dec.outcomeEvaluation.expectedVsObserved.expected} | <strong>المرصود:</strong> ${dec.outcomeEvaluation.expectedVsObserved.observed}
                      </div>
                    ` : ""}
                    <div style="color:#a7f3d0;margin-top:2px;">
                      🛡️ <strong>ضابط السببية (Attribution Control):</strong> <code>${dec.outcomeEvaluation.attributionStatement || ""}</code>
                    </div>
                    ${dec.outcomeEvaluation.inconclusiveReason ? `
                      <div style="color:#fda4af;margin-top:2px;">
                        ❓ <strong>سبب عدم الحسم (Why Inconclusive):</strong> ${dec.outcomeEvaluation.inconclusiveReason}
                      </div>
                    ` : ""}
                    ${dec.outcomeEvaluation.isReevaluation ? `
                      <div style="color:#38bdf8;margin-top:2px;">
                        ♻️ <strong>سجل إعادة التقييم (Preserved Earlier Eval: ${dec.outcomeEvaluation.previousEvaluationId}):</strong> ${dec.outcomeEvaluation.reevaluationReason}
                      </div>
                    ` : ""}
                  </div>
                ` : ""}
                <div style="margin-top:6px;display:flex;gap:6px;flex-wrap:wrap;">
                  <button type="button" class="wr-btn wr-btn-secondary" data-action="strategy-reevaluate-decision" data-decision-id="${dec.id}" style="font-size:10px;padding:3px 8px;">
                    🔄 إعادة تقييم هذه التوصية وحفظ سجل تاريخي
                  </button>
                  ${dec.skillId ? `
                    <button type="button" class="wr-btn wr-btn-secondary" data-jump-skill-id="${dec.skillId}" data-jump-tab="capabilities" style="font-size:10px;padding:3px 8px;">
                      🏛️ فتح المهارة والاختبارات
                    </button>
                  ` : ""}
                </div>
              </div>
            `).join("")}
          </div>
        </div>
      </section>
    `;
  }

  // =========================================================================
  // PHASE 6: REPORTING, ANALYTICS, PERFORMANCE TRENDS & REVIEW ENGINE TAB
  // =========================================================================
  function renderWorkloadSvgChart(dailyBreakdown = []) {
    if (!dailyBreakdown || dailyBreakdown.length === 0) {
      return `<div style="padding:18px;text-align:center;color:var(--text-muted);font-size:12px;background:var(--bg-primary);border-radius:8px;" id="svg-workload-empty">لا توجد سجلات مهام مجدولة في هذا النطاق لعرض مخطط الحمل المخطط مقابل الفعلي (Empty State — 0 Observations).</div>`;
    }
    const maxVal = Math.max(120, ...dailyBreakdown.map((d) => Math.max(d.plannedMinutes || 0, d.actualMinutes || 0, d.safeCeilingMin || 0)));
    const barGroupWidth = 76;
    const svgWidth = Math.max(360, dailyBreakdown.length * barGroupWidth + 40);
    const svgHeight = 175;
    const chartBottom = 135;
    const usableHeight = 105;

    const barsSvg = dailyBreakdown.map((d, idx) => {
      const xBase = 25 + idx * barGroupWidth;
      const pH = Math.round(((d.plannedMinutes || 0) / maxVal) * usableHeight);
      const aH = Math.round(((d.actualMinutes || 0) / maxVal) * usableHeight);
      const cY = chartBottom - Math.round(((d.safeCeilingMin || 120) / maxVal) * usableHeight);
      return `
        <g>
          <rect x="${xBase}" y="${chartBottom - pH}" width="22" height="${pH}" fill="#38bdf8" rx="3" />
          <rect x="${xBase + 25}" y="${chartBottom - aH}" width="22" height="${aH}" fill="${d.isOverloaded ? "#f43f5e" : "#14b8a6"}" rx="3" />
          <line x1="${xBase - 3}" y1="${cY}" x2="${xBase + 50}" y2="${cY}" stroke="#f59e0b" stroke-width="1.5" stroke-dasharray="3,2" />
          <text x="${xBase + 23}" y="152" fill="#cbd5e1" font-size="10" text-anchor="middle">${d.date.slice(5)}</text>
          <text x="${xBase + 23}" y="165" fill="#94a3b8" font-size="9" text-anchor="middle">${d.actualMinutes}/${d.plannedMinutes}د</text>
        </g>
      `;
    }).join("");

    return `
      <div style="overflow-x:auto;background:var(--bg-primary);padding:10px;border-radius:8px;">
        <svg id="svg-workload-chart" width="${svgWidth}" height="${svgHeight}" viewBox="0 0 ${svgWidth} ${svgHeight}" role="img" aria-label="Planned vs Actual Workload Chart">
          <line x1="15" y1="${chartBottom}" x2="${svgWidth - 15}" y2="${chartBottom}" stroke="#334155" stroke-width="1" />
          ${barsSvg}
        </svg>
        <div style="font-size:11px;color:var(--text-muted);margin-top:4px;">
          📏 <strong>ماذا يقيس هذا المخطط:</strong> يقارن الدقائق المخططة (أزرق) بالدقائق المنفذة فعلياً (تركواز/أحمر عند التجاوز) مقابل السقف الصحي الآمن لليوم (خط متقطع برتقالي) من واقع المهام المحفوظة.
        </div>
      </div>
    `;
  }

  function renderSkillTrendSvgChart(skillTrend) {
    if (!skillTrend || !skillTrend.observations || skillTrend.observations.length < 2) {
      const obsCount = skillTrend?.observationCount || 0;
      return `
        <div style="padding:18px;text-align:center;color:#fcd34d;font-size:12px;background:var(--bg-primary);border-radius:8px;" id="svg-skill-trend-insufficient">
          ⚠️ <strong>Insufficient data (بيانات غير كافية لرسم منحنى اتجاه):</strong> المهارة "${skillTrend?.name || ""}" تحتوي على (${obsCount}) قياس تقييمي فقط. يتطلب المنحنى قياسين فعليين على الأقل (اختبار أو مراجعة احتفاظ) لعدم اختلاق اتجاه وهمي.
        </div>
      `;
    }
    const pts = skillTrend.observations;
    const svgWidth = 420;
    const svgHeight = 165;
    const padX = 36;
    const topY = 20;
    const bottomY = 130;
    const usableH = bottomY - topY;
    const usableW = svgWidth - padX * 2;

    const coords = pts.map((pt, i) => {
      const x = padX + Math.round((i / (pts.length - 1)) * usableW);
      const y = bottomY - Math.round((Math.max(0, Math.min(100, pt.value)) / 100) * usableH);
      return { x, y, val: pt.value, date: String(pt.dateOrIso || "").slice(0, 10) };
    });

    const polylinePoints = coords.map((c) => `${c.x},${c.y}`).join(" ");
    const targetScore = skillTrend.configuredTarget?.minTestScore || 85;
    const targetY = bottomY - Math.round((targetScore / 100) * usableH);

    return `
      <div style="overflow-x:auto;background:var(--bg-primary);padding:10px;border-radius:8px;">
        <svg id="svg-skill-trend-chart" width="${svgWidth}" height="${svgHeight}" viewBox="0 0 ${svgWidth} ${svgHeight}" role="img" aria-label="Skill Performance Trend Chart">
          <line x1="${padX}" y1="${bottomY}" x2="${svgWidth - padX}" y2="${bottomY}" stroke="#334155" stroke-width="1" />
          <line x1="${padX}" y1="${targetY}" x2="${svgWidth - padX}" y2="${targetY}" stroke="#10b981" stroke-width="1.2" stroke-dasharray="4,3" />
          <polyline fill="none" stroke="#14b8a6" stroke-width="2.5" points="${polylinePoints}" />
          ${coords.map((c) => `
            <circle cx="${c.x}" cy="${c.y}" r="4" fill="#38bdf8" />
            <text x="${c.x}" y="${c.y - 8}" fill="#f8fafc" font-size="10" text-anchor="middle">${c.val}%</text>
            <text x="${c.x}" y="${bottomY + 16}" fill="#94a3b8" font-size="9" text-anchor="middle">${c.date.slice(5)}</text>
          `).join("")}
        </svg>
        <div style="font-size:11px;color:var(--text-muted);margin-top:4px;">
          📏 <strong>ماذا يقيس هذا المخطط:</strong> يعرض سلسلة درجات التقييم الفعلي المحفوظة (${pts.length} قياسات) للمهارة "${skillTrend.name}" مقارنة بدرجة الإتقان المستهدفة (${targetScore}% — خط أخضر متقطع).
        </div>
      </div>
    `;
  }

  function renderAnalyticsAndReviewsTab(state, skillMap) {
    const {
      currentDate,
      goals,
      capabilities,
      skills,
      selectedSkillId,
      analyticsFilters,
      activeReviewPeriodType,
      analyticsReport,
      periodicReviews,
    } = state;

    const report = analyticsReport;
    if (!report) {
      return `<section class="wr-card" id="tab-panel-analytics"><div>جارٍ تحميل بيانات التحليلات...</div></section>`;
    }

    const dims = report.nineDimensions || {};
    const trends = report.developmentTrends || { skills: [], subskills: [], goals: [], capabilities: [] };
    const sched = report.schedulingAnalysis || { counts: {}, rates: {}, dailyBreakdown: [], recommendations: [], recurringMissCauses: [] };
    const errBottle = report.errorAndBottleneckAnalysis || {
      skillsWithRepeatedErrors: [],
      recurringErrorCategories: [],
      unresolvedErrors: [],
      remediationOutcomes: [],
      prerequisiteBlockedSkills: [],
      activityWithoutAssessmentSkills: [],
      deterioratedSkills: [],
      downstreamBottlenecks: [],
      observedFacts: [],
      inferredHypotheses: [],
    };
    const goalTarget = report.goalAndTargetAnalysis || { goals: [] };
    const selectedSkillTrend =
      trends.skills.find((s) => s.id === (analyticsFilters?.skillId || selectedSkillId)) ||
      trends.skills[0] ||
      null;

    const activeDraft =
      report.reviewDrafts?.[activeReviewPeriodType || "daily"] ||
      report.reviewDrafts?.daily;

    return `
      <section class="wr-card" id="tab-panel-analytics">
        <div class="wr-card-header">
          <div>
            <div class="wr-card-title">📊 PHASE 6: REPORTING, ANALYTICS, PERFORMANCE TRENDS & REVIEW ENGINE</div>
            <div style="font-size:12px;color:var(--text-muted);">
              تحليلات مبنية حصرياً على الأدلة المسجلة • 9 مقاييس مستقلة بدون ازدواجية عدّ • كشف الاختناقات • المراجعات اليومية والأسبوعية والشهرية • تصدير JSON / CSV / Markdown
            </div>
          </div>
          <span class="wr-badge ${report.isEmptyDatabase ? "badge-maintenance" : "badge-focus"}" id="analytics-data-status-badge">
            ${report.isEmptyDatabase ? "⚠️ Empty State (قاعدة بيانات فارغة)" : `✅ Live Persisted Analytics • Zero Double-Counting: ${report.evidencePartitionAudit?.zeroDoubleCountingVerified ? "VERIFIED" : "CHECK"}`}
          </span>
        </div>

        <!-- 1. FILTERS FOR DATE RANGE, GOAL, CAPABILITY & SKILL (Section 6) -->
        <form id="form-analytics-filters" class="wr-card" style="background:var(--bg-secondary);margin-bottom:16px;">
          <div style="font-size:13px;font-weight:700;color:var(--accent-cyan);margin-bottom:8px;">
            🔎 فلاتر النطاق الزمني والأهداف والقدرات والمهارات (Analytics Filters)
          </div>
          <div class="wr-form-grid">
            <div class="wr-field">
              <label>من تاريخ (Start Date)</label>
              <input type="date" id="filter-start-date" class="wr-input" value="${analyticsFilters?.startDate || ""}" />
            </div>
            <div class="wr-field">
              <label>إلى تاريخ (End Date)</label>
              <input type="date" id="filter-end-date" class="wr-input" value="${analyticsFilters?.endDate || ""}" />
            </div>
            <div class="wr-field">
              <label>الهدف (Goal)</label>
              <select id="filter-goal-id" class="wr-select">
                <option value="">-- جميع الأهداف --</option>
                ${goals.map((g) => `<option value="${g.id}" ${analyticsFilters?.goalId === g.id ? "selected" : ""}>${g.title}</option>`).join("")}
              </select>
            </div>
            <div class="wr-field">
              <label>المجال / القدرة (Capability)</label>
              <select id="filter-capability-id" class="wr-select">
                <option value="">-- جميع القدرات --</option>
                ${capabilities.map((c) => `<option value="${c.id}" ${analyticsFilters?.capabilityId === c.id ? "selected" : ""}>${c.order}. ${c.nameAr}</option>`).join("")}
              </select>
            </div>
            <div class="wr-field">
              <label>المهارة (Skill)</label>
              <select id="filter-skill-id" class="wr-select">
                <option value="">-- جميع المهارات --</option>
                ${skills.map((s) => `<option value="${s.id}" ${analyticsFilters?.skillId === s.id ? "selected" : ""}>${s.nameAr || s.name}</option>`).join("")}
              </select>
            </div>
            <div class="wr-field" style="display:flex;align-items:flex-end;gap:6px;">
              <button type="submit" class="wr-btn wr-btn-primary" id="btn-apply-analytics-filters" style="flex:1;">تطبيق الفلتر</button>
              <button type="button" class="wr-btn wr-btn-secondary" id="btn-reset-analytics-filters">إعادة ضبط</button>
            </div>
          </div>
        </form>

        <!-- 2. 9 SEPARATE PERFORMANCE DIMENSIONS WITH DEFINITIONS, DENOMINATORS & EXCLUSIONS (Section 4B) -->
        <div class="wr-card" style="background:var(--bg-secondary);margin-bottom:16px;" id="analytics-9d-section">
          <div style="font-size:14px;font-weight:700;color:var(--accent-cyan);margin-bottom:10px;">
            📐 المقاييس التسعة المستقلة للأداء والتطور (9 Separate Performance Dimensions — Zero Double-Counting)
          </div>
          <div class="wr-cap-grid" id="analytics-9d-grid">
            ${Object.values(dims).map((d) => `
              <div class="wr-cap-card" data-dimension-key="${d.key}" id="dim-card-${d.key}" style="background:var(--bg-primary);">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;">
                  <strong style="font-size:13px;color:var(--accent-cyan);">${d.labelAr}</strong>
                  <span class="wr-badge ${d.value === null ? "badge-maintenance" : "badge-focus"}" id="dim-val-${d.key}">
                    ${d.statusLabel}
                  </span>
                </div>
                <div style="font-size:11px;color:var(--text-secondary);margin-bottom:4px;">
                  <strong>التعريف:</strong> ${d.definition}
                </div>
                <div style="font-size:10px;color:var(--text-muted);font-family:monospace;">
                  البسط / المقام: ${d.numerator} / ${d.denominator} (${d.denominatorDescription})
                </div>
                <div style="font-size:10px;color:#fcd34d;margin-top:3px;">
                  <strong>الاستثناءات والقيود:</strong> ${d.exclusions}
                </div>
              </div>
            `).join("")}
          </div>
        </div>

        <!-- 3. SVG VISUALIZATIONS: PLANNED VS ACTUAL WORKLOAD & SKILL OBSERVATIONS TREND (Section 6) -->
        <div class="wr-form-grid" style="margin-bottom:16px;" id="analytics-charts-section">
          <div class="wr-cap-card" style="background:var(--bg-secondary);">
            <div style="font-size:13px;font-weight:700;color:var(--accent-blue);margin-bottom:8px;">
              📊 1. مخطط الحمل المخطط مقابل المنفذ فعلياً والسقف الآمن (Planned vs. Actual Workload)
            </div>
            ${renderWorkloadSvgChart(sched.dailyBreakdown)}
            <div style="font-size:11px;margin-top:8px;display:flex;justify-content:space-between;flex-wrap:wrap;gap:6px;">
              <span>المخطط: <strong>${sched.plannedMinutes} د</strong></span>
              <span>الفعلي: <strong>${sched.actualMinutes} د</strong></span>
              <span>انحراف التقدير: <strong>${sched.estimationErrorPct !== null ? sched.estimationErrorPct + "%" : "Insufficient data"}</strong></span>
              <span>أيام الحمل الزائد: <strong>${sched.overloadDaysCount}</strong></span>
            </div>
          </div>

          <div class="wr-cap-card" style="background:var(--bg-secondary);">
            <div style="font-size:13px;font-weight:700;color:var(--accent-cyan);margin-bottom:8px;">
              📈 2. منحنى تطور التقييمات الفعلية للمهارة المحددة (${selectedSkillTrend?.name || "لا توجد مهارة"})
            </div>
            ${renderSkillTrendSvgChart(selectedSkillTrend)}
            ${selectedSkillTrend ? `
              <div style="font-size:11px;margin-top:8px;color:var(--text-secondary);">
                <div>🎯 الهدف الطموح المحفوظ: <strong>Lv ${selectedSkillTrend.configuredTarget.targetLevel} (Min Score ${selectedSkillTrend.configuredTarget.minTestScore}%)</strong> | الحالة المقاسة: <strong>${selectedSkillTrend.currentMeasuredState.status}</strong></div>
                <div>📌 خط الأساس (Baseline): <strong>${selectedSkillTrend.baseline ? selectedSkillTrend.baseline.value + "%" : "لا يوجد خط أساس بعد"}</strong> | التغير منذ خط الأساس: <strong>${selectedSkillTrend.changeSinceBaseline !== null ? (selectedSkillTrend.changeSinceBaseline >= 0 ? "+" : "") + selectedSkillTrend.changeSinceBaseline + "%" : "Insufficient data"}</strong></div>
                <div>🧭 الاتجاه الحديث: <strong>${selectedSkillTrend.recentTrend}</strong> | الاتجاه التاريخي: <strong>${selectedSkillTrend.historicalTrend}</strong> (${selectedSkillTrend.observationCount} قياسات)</div>
              </div>
            ` : ""}
          </div>
        </div>

        <!-- 4. SKILL & GOAL COMPARISONS + ERROR & BOTTLENECK ANALYSIS WITH ACTION LINKS (Sections 4A, 4D, 4E) -->
        <div class="wr-form-grid" style="margin-bottom:16px;" id="analytics-goals-bottlenecks-section">
          <div class="wr-cap-card" style="background:var(--bg-secondary);">
            <div style="font-size:13px;font-weight:700;color:#6ee7b7;margin-bottom:8px;">
              🎯 تقدم الأهداف طويلة المدى مقابل المعايير الطموحة (Goal & Target Analysis: ${goalTarget.goals.length})
            </div>
            <div id="analytics-goals-list" class="wr-task-list">
              ${goalTarget.goals.length === 0 ? `<div style="font-size:11px;color:var(--text-muted);">لا توجد أهداف مسجلة.</div>` : goalTarget.goals.map((g) => `
                <div style="background:var(--bg-primary);padding:8px 10px;border-radius:6px;font-size:12px;">
                  <div style="display:flex;justify-content:space-between;">
                    <strong>${g.title}</strong>
                    <span class="wr-badge badge-focus">Mastered Skills: ${g.milestones.masteredSkills}/${g.milestones.totalSkills} (${g.measuredSkillMasteryPct}%)</span>
                  </div>
                  <div style="font-size:11px;color:var(--text-muted);margin-top:3px;">
                    الموعد المستهدف: ${g.configuredTargetDate || "غير محدد"} • التقدم التراكمي: ${g.configuredProgressPct}%
                  </div>
                  <div style="font-size:11px;color:#fcd34d;margin-top:2px;">
                    🔮 التنبؤ بالإنجاز: <strong>${g.completionForecast.label}</strong>
                  </div>
                  ${g.evidenceGaps.length > 0 ? `<div style="font-size:10px;color:#fda4af;margin-top:2px;">فجوات أدلة/اختبارات في (${g.evidenceGaps.length}) مهارة مرتبطة.</div>` : ""}
                </div>
              `).join("")}
            </div>
          </div>

          <div class="wr-cap-card" style="background:var(--bg-secondary);">
            <div style="font-size:13px;font-weight:700;color:#fda4af;margin-bottom:8px;">
              🚧 تحليل الاختناقات، الأخطاء المتكررة، وفاعلية العلاج (Bottlenecks & Error Analysis)
            </div>
            <div id="analytics-bottlenecks-list" style="font-size:11px;">
              <div style="margin-bottom:6px;">
                <strong style="color:var(--accent-cyan);">الاختناقات المؤثرة على المهارات والأهداف التالية (${errBottle.downstreamBottlenecks.length}):</strong>
                ${errBottle.downstreamBottlenecks.length === 0 ? `<div style="color:#6ee7b7;">لا توجد اختناقات حرجة.</div>` : errBottle.downstreamBottlenecks.map((b) => `
                  <div style="background:var(--bg-primary);padding:6px 8px;border-radius:6px;margin-top:4px;display:flex;justify-content:space-between;align-items:center;">
                    <div>
                      <strong>${b.bottleneckSkillName}</strong> (${b.status}) — يوقف ${b.blockedDownstreamSkillIds.length} مهارة تالية • أخطاء مفتوحة: ${b.openErrorsCount}
                    </div>
                    <button class="wr-btn wr-btn-secondary" data-jump-skill-id="${b.bottleneckSkillId}" data-jump-tab="diagnostics" style="padding:2px 8px;font-size:10px;">فحص التشخيص</button>
                  </div>
                `).join("")}
              </div>

              ${errBottle.activityWithoutAssessmentSkills.length > 0 ? `
                <div style="margin-bottom:6px;">
                  <strong style="color:#fcd34d;">⚠️ مهارات ذات نشاط ولكن بدون أي دليل تقييم (${errBottle.activityWithoutAssessmentSkills.length}):</strong>
                  ${errBottle.activityWithoutAssessmentSkills.map((aw) => `
                    <div style="background:var(--bg-primary);padding:5px 8px;border-radius:6px;margin-top:3px;display:flex;justify-content:space-between;align-items:center;">
                      <span>${aw.skillName}: ${aw.totalPracticeAndStudyMinutes} د دراسة (0 اختبارات)</span>
                      <button class="wr-btn wr-btn-secondary" data-jump-skill-id="${aw.skillId}" data-jump-tab="capabilities" style="padding:2px 8px;font-size:10px;">إجراء اختبار</button>
                    </div>
                  `).join("")}
                </div>
              ` : ""}

              ${errBottle.inferredHypotheses.length > 0 ? `
                <div style="background:var(--bg-primary);padding:6px 8px;border-radius:6px;margin-top:6px;">
                  <div style="color:#fcd34d;font-weight:700;">💡 فرضيات تفسيرية وملاحظة عدم اليقين (Observed Facts vs. Hypotheses):</div>
                  ${errBottle.inferredHypotheses.map((ih) => `
                    <div style="margin-top:3px;">
                      <div><strong>الفرضية:</strong> ${ih.hypothesis}</div>
                      <div style="color:var(--text-muted);">الأدلة: ${ih.supportingEvidence.join(" | ")}</div>
                      <div style="color:#fda4af;">عدم اليقين: ${ih.uncertaintyNote}</div>
                    </div>
                  `).join("")}
                </div>
              ` : ""}
            </div>
          </div>
        </div>

        <!-- 5. DAILY, WEEKLY, AND MONTHLY REVIEWS WORKSPACE & PERSISTED HISTORY (Section 5) -->
        <div class="wr-card" style="background:var(--bg-secondary);margin-bottom:16px;" id="analytics-periodic-reviews-section">
          <div class="wr-card-header">
            <div>
              <div class="wr-card-title">📝 المراجعات الدورية الموثقة (Daily, Weekly & Monthly Reviews)</div>
              <div style="font-size:11px;color:var(--text-muted);">
                توليد مسودة المراجعة من السجلات الفعلية + كتابة وحفظ ملاحظاتك وقراراتك وخطواتك القادمة مع حفظ الأرشيف التاريخي دون مسح
              </div>
            </div>
            <div style="display:flex;gap:6px;">
              ${["daily", "weekly", "monthly"].map((pt) => `
                <button type="button" class="wr-btn ${activeReviewPeriodType === pt ? "wr-btn-primary" : "wr-btn-secondary"}" data-review-period="${pt}" id="btn-period-${pt}" style="padding:5px 10px;font-size:12px;">
                  ${pt === "daily" ? "يومية (Daily)" : pt === "weekly" ? "أسبوعية (Weekly)" : "شهرية (Monthly)"}
                </button>
              `).join("")}
            </div>
          </div>

          ${activeDraft ? `
            <div style="background:var(--bg-primary);padding:12px;border-radius:8px;margin-bottom:12px;font-size:12px;" id="live-review-draft-box">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
                <strong style="color:var(--accent-cyan);">ملخص الفترة الفعلي (${activeDraft.periodType.toUpperCase()}: ${activeDraft.startDate} → ${activeDraft.endDate})</strong>
                <span class="wr-badge ${activeDraft.snapshot.isEmptyPeriod ? "badge-maintenance" : "badge-recovery"}">
                  ${activeDraft.snapshot.isEmptyPeriod ? "فترة فارغة (0 سجلات)" : `${activeDraft.snapshot.dayCount} يوم`}
                </span>
              </div>
              <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:8px;margin-bottom:8px;">
                <div>📋 المخطط مقابل المنجز: <strong>${activeDraft.snapshot.plannedVsCompleted.actualMinutes} / ${activeDraft.snapshot.plannedVsCompleted.plannedMinutes} د</strong> (${activeDraft.snapshot.plannedVsCompleted.completedTasksCount}/${activeDraft.snapshot.plannedVsCompleted.scheduledTasksCount} مهام)</div>
                <div>🧾 الأدلة المسجلة: <strong>${activeDraft.snapshot.meaningfulEvidenceRecorded.length} دليل</strong></div>
                <div>⏭️ مهام متخطاة/جزئية: <strong>${activeDraft.snapshot.missedOrPartialTasks.length}</strong></div>
                <div>🚨 أخطاء/عوائق مفتوحة: <strong>${activeDraft.snapshot.errorsAndBlockers.length}</strong></div>
              </div>
              ${activeDraft.snapshot.missingDataWarnings.length > 0 ? `
                <div style="color:#fcd34d;font-size:11px;margin-bottom:6px;">
                  ⚠️ تنبيهات نقص البيانات: ${activeDraft.snapshot.missingDataWarnings.join(" | ")}
                </div>
              ` : ""}
              <div style="font-size:11px;color:#6ee7b7;">
                <strong>الأولويات الموصى بها للفترة القادمة:</strong> ${activeDraft.snapshot.recommendedNextPriorities.join(" • ") || "الاستمرار في الخطة الحالية"}
              </div>
            </div>
          ` : ""}

          <form id="form-save-periodic-review" class="wr-form-grid" style="margin-bottom:14px;">
            <div class="wr-field">
              <label>ملاحظاتك وتأملاتك الشخصية (User Notes)</label>
              <input type="text" id="review-user-notes" class="wr-input" placeholder="اكتب ملاحظاتك الحقيقية حول أداء الفترة..." required />
            </div>
            <div class="wr-field">
              <label>القرارات المتخذة (Decisions)</label>
              <input type="text" id="review-decisions" class="wr-input" placeholder="مثال: تثبيت جلسة الصباح للمفاهيم الصعبة" required />
            </div>
            <div class="wr-field">
              <label>الإجراءات القادمة (Next Actions)</label>
              <input type="text" id="review-next-actions" class="wr-input" placeholder="مثال: إغلاق خطأ المؤشرين وإجراء فحص الاحتفاظ" required />
            </div>
            <div class="wr-field" style="display:flex;align-items:flex-end;">
              <button type="submit" class="wr-btn wr-btn-primary" id="btn-save-periodic-review" style="width:100%;">
                💾 حفظ المراجعة الدورية في السجل التاريخي
              </button>
            </div>
          </form>

          <div style="font-size:12px;font-weight:700;margin-bottom:6px;">
            📚 أرشيف المراجعات الدورية المحفوظة (Saved Historical Reviews: <span id="saved-reviews-count">${periodicReviews.length}</span>)
          </div>
          <div id="saved-periodic-reviews-list" class="wr-task-list">
            ${periodicReviews.length === 0 ? `<div style="font-size:11px;color:var(--text-muted);">لم يتم حفظ مراجعات دورية بعد.</div>` : periodicReviews.slice(0, 6).map((pr) => `
              <div class="wr-cap-card" data-periodic-review-id="${pr.id}" style="background:var(--bg-primary);font-size:12px;">
                <div style="display:flex;justify-content:space-between;">
                  <strong>[${pr.periodType.toUpperCase()} #v${pr.revisionNumber || 1}] ${pr.startDate} → ${pr.endDate}</strong>
                  <span style="font-size:10px;color:var(--text-muted);">${pr.createdAt.slice(0, 19)}</span>
                </div>
                <div style="margin-top:4px;color:var(--text-secondary);">📝 <strong>الملاحظات:</strong> ${pr.userNotes}</div>
                <div style="color:var(--accent-cyan);font-size:11px;">⚖️ <strong>القرارات:</strong> ${(pr.decisions || []).join(" | ")} • 🚀 <strong>الخطوات القادمة:</strong> ${(pr.nextActions || []).join(" | ")}</div>
              </div>
            `).join("")}
          </div>
        </div>

        <!-- 6. PRACTICAL REPORT EXPORTS: JSON, CSV, MARKDOWN (Section 7) -->
        <div class="wr-card" style="background:var(--bg-secondary);" id="analytics-exports-section">
          <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:10px;">
            <div>
              <div style="font-size:14px;font-weight:700;color:var(--accent-cyan);">📤 تصدير التقارير التحليلية الموثقة (JSON / CSV / Markdown Report Exports)</div>
              <div style="font-size:11px;color:var(--text-muted);">يتضمن فترة التقرير، تاريخ التوليد، تعريفات المقاييس التسعة، والقيود المنهجية مع تهريب CSV قياسي (RFC-4180)</div>
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
              <button type="button" class="wr-btn wr-btn-primary" id="btn-export-report-json">تصدير JSON</button>
              <button type="button" class="wr-btn wr-btn-secondary" id="btn-export-report-csv">تصدير CSV</button>
              <button type="button" class="wr-btn wr-btn-amber" id="btn-export-report-md">تصدير Markdown</button>
            </div>
          </div>
          <textarea id="analytics-export-textarea" class="wr-textarea" rows="6" readonly style="font-family:monospace;font-size:11px;direction:ltr;text-align:left;" placeholder="اضغط على أحد أزرار التصدير أعلاه (JSON / CSV / Markdown) لتوليد التقرير الموثق وعرضه هنا..."></textarea>
        </div>
      </section>
    `;
  }

  // =========================================================================
  // PHASE 3: LEARNING ENGINE DASHBOARD & OBJECTIVE DETAIL VIEW
  // =========================================================================
  function renderLearningEngineTab(state, skillMap) {
    const {
      skills,
      subskills,
      learningObjectives,
      recallAttempts,
      flashcards,
      learningPaths,
      learningRecommendations,
      selectedObjectiveId,
      selectedObjectiveBundle,
      currentDate,
    } = state;

    const obBundle = selectedObjectiveBundle;
    const selObj = obBundle?.objective;
    const weakObjectives = learningObjectives.filter(
      (o) => o.status === 'WEAK' || o.status === 'REMEDIATION'
    );
    const dueFlashcards = flashcards.filter(
      (c) => !c.nextReviewDate || String(c.nextReviewDate) <= String(currentDate)
    );
    const mismatches = [
      ...recallAttempts.filter((r) => r.metacognitiveMismatch),
      ...(state.testAttempts || []).filter((t) => t.metacognitiveMismatch),
    ];

    return `
      <section class="wr-card" id="tab-panel-learning">
        <div class="wr-card-header">
          <div>
            <div class="wr-card-title">🧠 LEARNING ENGINE — محرك التعلم العميق والاسترجاع النشط (Phase 3)</div>
            <div style="font-size:12px;color:var(--text-muted);">
              Resource → Objective → Learning Session → Active Recall / Feynman / Flashcards → Practice → Evidence → Test → Mastery → Retention
            </div>
          </div>
          <span class="wr-badge badge-focus" id="learning-objectives-count-badge">
            Objectives: ${learningObjectives.length} • Due Cards: ${dueFlashcards.length}
          </span>
        </div>

        <div class="wr-form-grid" style="margin-bottom:16px;">
          <div class="wr-cap-card" style="border-color:var(--accent-cyan);">
            <div style="font-size:13px;font-weight:700;color:var(--accent-cyan);margin-bottom:6px;">
              🧭 ماذا أتعلم الآن؟ (Recommended Next Actions)
            </div>
            <div id="learning-recommendations-list" class="wr-task-list">
              ${learningRecommendations.slice(0, 4).map((rec) => `
                <div style="background:var(--bg-primary);padding:8px 10px;border-radius:8px;border:1px solid var(--border-subtle);font-size:12px;">
                  <div style="display:flex;justify-content:space-between;align-items:center;">
                    <span class="wr-badge ${rec.priority === 1 ? 'badge-primary' : rec.priority === 2 ? 'badge-maintenance' : 'badge-focus'}">${rec.type}</span>
                    ${rec.objectiveId ? `<button class="wr-btn wr-btn-secondary" data-select-objective-id="${rec.objectiveId}" style="padding:2px 8px;font-size:11px;">فتح الهدف</button>` : ''}
                  </div>
                  <div style="font-weight:700;margin-top:4px;">${rec.title}</div>
                  <div style="font-size:11px;color:var(--text-muted);">${rec.reason}</div>
                </div>
              `).join('')}
            </div>
          </div>

          <div class="wr-cap-card">
            <div style="font-size:13px;font-weight:700;color:var(--accent-blue);margin-bottom:6px;">
              🛣️ مسارات التعلم النشطة (Learning Paths & Weak Areas)
            </div>
            ${learningPaths.map((lp) => {
              const pathObjs = learningObjectives.filter((o) => (lp.objectiveIds || []).includes(o.id));
              const mast = pathObjs.filter((o) => o.status === 'MASTERED' || o.status === 'MAINTENANCE').length;
              const pct = pathObjs.length > 0 ? Math.round((mast / pathObjs.length) * 100) : 0;
              return `
                <div style="background:var(--bg-primary);padding:8px 10px;border-radius:8px;margin-bottom:8px;font-size:12px;">
                  <div style="display:flex;justify-content:space-between;">
                    <strong>${lp.title}</strong>
                    <span style="color:var(--accent-cyan);font-family:monospace;">${mast}/${pathObjs.length} (${pct}%)</span>
                  </div>
                  <div class="wr-progress-bar-wrap"><div class="wr-progress-bar-fill" style="width:${pct}%;"></div></div>
                  <div style="font-size:11px;color:var(--text-muted);">المهارة: ${skillMap[lp.skillId]?.nameAr || lp.skillId}</div>
                </div>
              `;
            }).join('')}
            <div style="font-size:11px;margin-top:6px;color:${weakObjectives.length > 0 || mismatches.length > 0 ? '#fda4af' : '#6ee7b7'};">
              ⚠️ أهداف ضعيفة/قيد العلاج: <strong>${weakObjectives.length}</strong> | فجوات وهم الكفاءة: <strong id="learning-mismatch-count">${mismatches.length}</strong>
            </div>
          </div>
        </div>

        <div style="font-size:15px;font-weight:700;margin-bottom:10px;">
          🎯 الأهداف التعلمية (Learning Objectives — اضغط على أي هدف لفتح ساحة التعلم الكاملة)
        </div>
        <div class="wr-cap-grid" id="learning-objectives-grid" style="margin-bottom:16px;">
          ${learningObjectives.map((obj) => {
            const isSel = obj.id === selectedObjectiveId;
            return `
              <div class="wr-cap-card wr-skill-card-selectable ${isSel ? 'selected' : ''}" data-select-objective-id="${obj.id}" id="objective-card-${obj.id}">
                <div style="display:flex;justify-content:space-between;align-items:center;gap:6px;">
                  <strong style="font-size:13px;color:var(--accent-cyan);">${obj.title}</strong>
                  <span class="wr-badge state-${obj.status}" id="objective-status-badge-${obj.id}">${obj.status}</span>
                </div>
                <div style="font-size:11px;color:var(--text-muted);margin:4px 0;">
                  المهارة: ${skillMap[obj.skillId]?.nameAr || obj.skillId} • الصعوبة: ${obj.difficulty}/10 • ${obj.estimatedEffortMin} د
                </div>
                <div style="font-size:11px;color:#a7f3d0;background:rgba(16,185,129,0.08);padding:5px 8px;border-radius:6px;margin-top:4px;">
                  <strong>المخرج التطبيقي (DO Outcome):</strong> ${obj.targetOutcome}
                </div>
              </div>
            `;
          }).join('')}
        </div>

        <div class="wr-form-grid" style="margin-bottom:18px;">
          <details style="background:var(--bg-secondary);border:1px solid var(--border-subtle);border-radius:10px;padding:12px;" id="details-create-objective">
            <summary style="cursor:pointer;font-weight:700;font-size:13px;color:var(--accent-cyan);">➕ إنشاء هدف تعلمي جديد (Create Learning Objective)</summary>
            <form id="form-create-objective" style="margin-top:10px;">
              <div class="wr-field" style="margin-bottom:8px;">
                <label>عنوان الهدف التعلمي (Title)</label>
                <input type="text" id="new-obj-title" class="wr-input" required />
              </div>
              <div class="wr-field" style="margin-bottom:8px;">
                <label>ماذا يجب أن يستطيع المتعلم فعله عملياً؟ (Target DO Outcome)</label>
                <input type="text" id="new-obj-outcome" class="wr-input" required />
              </div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px;">
                <div class="wr-field">
                  <label>المهارة المرتبطة (Skill)</label>
                  <select id="new-obj-skill" class="wr-select">
                    ${skills.map((s) => `<option value="${s.id}">${s.nameAr} (${s.name})</option>`).join('')}
                  </select>
                </div>
                <div class="wr-field">
                  <label>المهارة الفرعية (Subskill)</label>
                  <select id="new-obj-subskill" class="wr-select">
                    <option value="">-- عام للمهارة --</option>
                    ${subskills.map((sub) => `<option value="${sub.id}">${sub.name}</option>`).join('')}
                  </select>
                </div>
              </div>
              <div class="wr-field" style="margin-bottom:8px;">
                <label>المتطلب السابق (Prerequisite Objective)</label>
                <select id="new-obj-prereq" class="wr-select">
                  <option value="">-- بدون متطلب سابق --</option>
                  ${learningObjectives.map((o) => `<option value="${o.id}">${o.title} (${o.status})</option>`).join('')}
                </select>
              </div>
              <button type="submit" class="wr-btn wr-btn-primary" id="btn-create-objective" style="width:100%;">حفظ الهدف التعلمي</button>
            </form>
          </details>

          <details style="background:var(--bg-secondary);border:1px solid var(--border-subtle);border-radius:10px;padding:12px;" id="details-create-resource">
            <summary style="cursor:pointer;font-weight:700;font-size:13px;color:var(--accent-blue);">📚 ربط مصدر تعلمي جديد (Add & Link Resource)</summary>
            <form id="form-create-resource" style="margin-top:10px;">
              <div class="wr-field" style="margin-bottom:8px;">
                <label>عنوان المصدر (Resource Title)</label>
                <input type="text" id="new-res-title" class="wr-input" required />
              </div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px;">
                <div class="wr-field">
                  <label>النوع (Type)</label>
                  <select id="new-res-type" class="wr-select">
                    ${RESOURCE_TYPES.map((rt) => `<option value="${rt}">${rt}</option>`).join('')}
                  </select>
                </div>
                <div class="wr-field">
                  <label>الهدف المرتبط (Objective)</label>
                  <select id="new-res-objective" class="wr-select">
                    ${learningObjectives.map((o) => `<option value="${o.id}" ${o.id === selectedObjectiveId ? 'selected' : ''}>${o.title}</option>`).join('')}
                  </select>
                </div>
              </div>
              <div class="wr-field" style="margin-bottom:8px;">
                <label>الرابط أو المرجع (URL / Path / Reference)</label>
                <input type="text" id="new-res-ref" class="wr-input" value="local://course/mit-6006-lec16" required />
              </div>
              <button type="submit" class="wr-btn wr-btn-primary" id="btn-create-resource" style="width:100%;">إضافة وربط المصدر بالهدف</button>
            </form>
          </details>
        </div>

        ${selObj ? `
          <div class="wr-card" id="objective-detail-panel" style="background:#0f172a;border-color:var(--accent-cyan);">
            <div class="wr-card-header">
              <div>
                <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                  <span class="wr-card-title" id="detail-objective-title">🔬 تفاصيل الهدف التعلمي: ${selObj.title}</span>
                  <span class="wr-badge state-${selObj.status}" id="detail-objective-status">${selObj.status}</span>
                </div>
                <div style="font-size:12px;color:#a7f3d0;margin-top:4px;">
                  <strong>🎯 ماذا ستكون قادراً على فعله (Target Outcome):</strong> ${selObj.targetOutcome}
                </div>
              </div>
            </div>

            <div class="wr-form-grid" style="margin-bottom:16px;">
              <div class="wr-cap-card">
                <div style="font-weight:700;font-size:13px;color:var(--accent-blue);margin-bottom:8px;">
                  📖 1. المصادر المرتبطة وتسجيل جلسة تعلم
                </div>
                <form id="form-record-learning-session">
                  <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px;">
                    <div class="wr-field">
                      <label>نوع الجلسة</label>
                      <select id="lsess-type" class="wr-select">
                        ${SESSION_TYPES.map((st) => `<option value="${st}">${st}</option>`).join('')}
                      </select>
                    </div>
                    <div class="wr-field">
                      <label>المصدر</label>
                      <select id="lsess-resource" class="wr-select">
                        <option value="">-- بدون مصدر --</option>
                        ${obBundle.resources.map((r) => `<option value="${r.id}">${r.title}</option>`).join('')}
                      </select>
                    </div>
                  </div>
                  <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px;">
                    <div class="wr-field">
                      <label>المدة الفعلية (د)</label>
                      <input type="number" id="lsess-duration" class="wr-input" value="40" required />
                    </div>
                    <div class="wr-field">
                      <label>الثقة %</label>
                      <input type="number" id="lsess-confidence" class="wr-input" value="80" required />
                    </div>
                  </div>
                  <div class="wr-field" style="margin-bottom:8px;">
                    <label>ملاحظات الجلسة</label>
                    <input type="text" id="lsess-notes" class="wr-input" />
                  </div>
                  <button type="submit" class="wr-btn wr-btn-primary" id="btn-record-learning-session" style="width:100%;">
                    ⏱ تسجيل جلسة التعلم
                  </button>
                </form>
              </div>

              <div class="wr-cap-card">
                <div style="font-weight:700;font-size:13px;color:var(--accent-cyan);margin-bottom:8px;">
                  ⚡ 2. الاسترجاع النشط (Active Recall)
                </div>
                <form id="form-record-recall">
                  <div class="wr-field" style="margin-bottom:6px;">
                    <label>سؤال الاسترجاع</label>
                    <input type="text" id="recall-question" class="wr-input" value="متى وكيف نحرك المؤشر الأيسر في خوارزمية النافذة المنزلقة؟" required />
                  </div>
                  <div class="wr-field" style="margin-bottom:6px;">
                    <label>الإجابة المتوقعة</label>
                    <input type="text" id="recall-expected" class="wr-input" value="نحرك المؤشر الأيسر لتقليص النافذة عندما ينكسر شرط صلاحية النافذة مع تحديث الحالة في زمن خطي" required />
                  </div>
                  <div class="wr-field" style="margin-bottom:6px;">
                    <label>إجابتك من الذاكرة</label>
                    <input type="text" id="recall-user-answer" class="wr-input" required />
                  </div>
                  <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px;">
                    <div class="wr-field">
                      <label>ثقتك %</label>
                      <input type="number" id="recall-confidence" class="wr-input" value="85" required />
                    </div>
                    <div class="wr-field">
                      <label>درجة الصحة %</label>
                      <input type="number" id="recall-correctness" class="wr-input" value="90" />
                    </div>
                  </div>
                  <button type="submit" class="wr-btn wr-btn-primary" id="btn-record-recall" style="width:100%;">
                    🧠 تقييم وحفظ الاسترجاع النشط
                  </button>
                </form>
              </div>
            </div>

            <div class="wr-form-grid" style="margin-bottom:16px;">
              <div class="wr-cap-card">
                <div style="font-weight:700;font-size:13px;color:#fcd34d;margin-bottom:8px;">
                  🗣️ 3. تقنية فاينمان (Feynman Mode)
                </div>
                <form id="form-record-feynman">
                  <div class="wr-field" style="margin-bottom:6px;">
                    <label>اشرح المفهوم بلغتك الخاصة</label>
                    <textarea id="feynman-explanation" class="wr-textarea" rows="2" required></textarea>
                  </div>
                  <div class="wr-field" style="margin-bottom:6px;">
                    <label>الفجوات المكتشفة</label>
                    <input type="text" id="feynman-gaps" class="wr-input" />
                  </div>
                  <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px;">
                    <div class="wr-field">
                      <label>الوضوح %</label>
                      <input type="number" id="feynman-clarity" class="wr-input" value="90" required />
                    </div>
                    <div class="wr-field">
                      <label>الثقة %</label>
                      <input type="number" id="feynman-confidence" class="wr-input" value="85" required />
                    </div>
                  </div>
                  <button type="submit" class="wr-btn wr-btn-amber" id="btn-record-feynman" style="width:100%;">
                    📝 حفظ شرح فاينمان
                  </button>
                </form>
              </div>

              <div class="wr-cap-card">
                <div style="font-weight:700;font-size:13px;color:#6ee7b7;margin-bottom:8px;">
                  🛠️ 4. التطبيق العملي وتوثيق الأدلة (Practice Tasks)
                </div>
                <form id="form-create-practice-task" style="margin-bottom:10px;">
                  <div class="wr-field" style="margin-bottom:6px;">
                    <label>عنوان مهمة التطبيق</label>
                    <input type="text" id="prac-task-title" class="wr-input" required />
                  </div>
                  <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px;">
                    <div class="wr-field">
                      <label>نوع الدليل</label>
                      <select id="prac-evidence-type" class="wr-select">
                        ${EVIDENCE_TYPES.map((et) => `<option value="${et}">${et}</option>`).join('')}
                      </select>
                    </div>
                    <div class="wr-field">
                      <label>الوقت (د)</label>
                      <input type="number" id="prac-time-min" class="wr-input" value="45" required />
                    </div>
                  </div>
                  <button type="submit" class="wr-btn wr-btn-secondary" id="btn-create-practice-task" style="width:100%;">
                    ➕ توليد مهمة تطبيق عملي
                  </button>
                </form>
                <div id="objective-practice-tasks-list" class="wr-task-list">
                  ${obBundle.practiceTasks.map((pt) => `
                    <div style="display:flex;justify-content:space-between;align-items:center;background:var(--bg-primary);padding:6px 8px;border-radius:6px;font-size:12px;">
                      <span>${pt.status === 'completed' ? '✅' : '⏳'} ${pt.title}</span>
                      ${pt.status !== 'completed' ? `
                        <button class="wr-btn wr-btn-primary" data-action="complete-practice-task" data-task-id="${pt.id}" style="padding:3px 8px;font-size:11px;">
                          إتمام وتوثيق الدليل
                        </button>
                      ` : ''}
                    </div>
                  `).join('')}
                </div>
              </div>
            </div>

            <div class="wr-form-grid">
              <div class="wr-cap-card">
                <div style="font-weight:700;font-size:13px;color:var(--accent-cyan);margin-bottom:8px;">
                  🎯 5. اختبارات التعلم وإعادة الاختبار
                </div>
                <form id="form-record-learning-test">
                  <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px;">
                    <div class="wr-field">
                      <label>نوع الاختبار</label>
                      <select id="ltest-kind" class="wr-select">
                        ${TEST_KINDS.map((tk) => `<option value="${tk}" ${tk === 'mastery' ? 'selected' : ''}>${tk}</option>`).join('')}
                      </select>
                    </div>
                    <div class="wr-field">
                      <label>ربط بخطأ (Retest)</label>
                      <select id="ltest-linked-error" class="wr-select">
                        <option value="">-- اختبار جديد --</option>
                        ${obBundle.errors.filter((e) => e.status !== 'resolved').map((e) => `
                          <option value="${e.id}">Retest: ${e.description.slice(0, 35)} (${e.status})</option>
                        `).join('')}
                      </select>
                    </div>
                  </div>
                  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:8px;">
                    <div class="wr-field">
                      <label>الدرجة %</label>
                      <input type="number" id="ltest-score" class="wr-input" value="92" required />
                    </div>
                    <div class="wr-field">
                      <label>الدقة %</label>
                      <input type="number" id="ltest-accuracy" class="wr-input" value="90" required />
                    </div>
                    <div class="wr-field">
                      <label>الثقة %</label>
                      <input type="number" id="ltest-confidence" class="wr-input" value="88" required />
                    </div>
                  </div>
                  <button type="submit" class="wr-btn wr-btn-primary" id="btn-submit-learning-test" style="width:100%;">
                    🧪 تنفيذ اختبار الهدف التعلمي
                  </button>
                </form>

                <div style="margin-top:10px;" id="objective-errors-list">
                  ${obBundle.errors.filter((e) => e.status !== 'resolved').map((err) => {
                    const rem = obBundle.remediations.find((r) => r.errorId === err.id);
                    return `
                      <div style="background:var(--bg-primary);border:1px solid rgba(244,63,94,0.45);padding:8px;border-radius:6px;margin-top:6px;font-size:11px;">
                        <div style="color:#fda4af;font-weight:700;">❌ [${err.status.toUpperCase()}] ${err.description}</div>
                        ${!rem ? `
                          <button class="wr-btn wr-btn-amber" data-action="create-remediation" data-error-id="${err.id}" style="margin-top:6px;width:100%;font-size:11px;">
                            🛠 إنشاء خطة علاجية ومهمة تصحيحية
                          </button>
                        ` : `<div style="margin-top:4px;color:var(--accent-cyan);">خطة علاجية (${rem.status})</div>`}
                      </div>
                    `;
                  }).join('')}
                </div>
              </div>

              <div class="wr-cap-card">
                <div style="font-weight:700;font-size:13px;color:#d8b4fe;margin-bottom:8px;">
                  🔄 6. مراجعة الاحتفاظ طويل المدى والملاحظات
                </div>
                <form id="form-record-retention-review" style="margin-bottom:10px;">
                  <div style="display:grid;grid-template-columns:1fr 2fr;gap:8px;margin-bottom:8px;">
                    <div class="wr-field">
                      <label>درجة الاحتفاظ %</label>
                      <input type="number" id="ret-review-score" class="wr-input" value="94" required />
                    </div>
                    <div class="wr-field">
                      <label>دليل الاحتفاظ</label>
                      <input type="text" id="ret-review-evidence" class="wr-input" value="إعادة حل مسألة من الذاكرة بدون أخطاء" required />
                    </div>
                  </div>
                  <button type="submit" class="wr-btn wr-btn-secondary" id="btn-record-retention-review" style="width:100%;">
                    🛡️ تسجيل مراجعة الاحتفاظ
                  </button>
                </form>

                <form id="form-add-learning-note">
                  <div style="display:flex;gap:6px;">
                    <input type="text" id="learning-note-content" class="wr-input" placeholder="أضف ملاحظة..." required />
                    <button type="submit" class="wr-btn wr-btn-secondary" id="btn-add-learning-note">حفظ</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        ` : ''}

        <div class="wr-card" style="background:var(--bg-secondary);margin-top:16px;" id="flashcards-deck-section">
          <div class="wr-card-header">
            <div class="wr-card-title">🗂️ بطاقات الاسترجاع المتباعد (Flashcards: ${flashcards.length})</div>
          </div>
          <div class="wr-cap-grid" id="flashcards-list-grid" style="margin-bottom:14px;">
            ${flashcards.map((fc) => `
              <div class="wr-cap-card" data-flashcard-id="${fc.id}" id="flashcard-item-${fc.id}" style="background:var(--bg-primary);">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
                  <span class="wr-badge badge-focus" id="fc-state-${fc.id}">${fc.retentionState}</span>
                  <span style="font-size:11px;color:var(--text-muted);font-family:monospace;">Due: ${fc.nextReviewDate}</span>
                </div>
                <div style="font-weight:700;font-size:13px;color:var(--accent-cyan);margin-bottom:4px;">س: ${fc.front}</div>
                <div style="font-size:12px;color:var(--text-secondary);margin-bottom:8px;">ج: ${fc.back}</div>
                <div style="display:flex;gap:6px;">
                  <button class="wr-btn wr-btn-primary" data-action="review-flashcard-pass" data-flashcard-id="${fc.id}" style="flex:1;padding:5px;font-size:11px;">
                    ✅ تذكرت بدقة (95%)
                  </button>
                  <button class="wr-btn wr-btn-danger" data-action="review-flashcard-fail" data-flashcard-id="${fc.id}" style="flex:1;padding:5px;font-size:11px;">
                    ❌ تعثرت (45%)
                  </button>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      </section>
    `;
  }

  // =========================================================================
  // PHASE 2 + PHASE 5: SKILL ENGINE TAB
  // =========================================================================
  function renderSkillEngineTab(state) {
    const {
      skills,
      capabilities,
      selectedSkillId,
      selectedSkillBundle,
    } = state;

    const bundle = selectedSkillBundle;
    const selSkill = bundle?.skill;
    const gate = bundle?.skillGate;
    const prog = selSkill?.progress || {
      activityProgress: 0,
      learningProgress: 0,
      competence: 0,
      mastery: 0,
      retention: 0,
    };

    return `
      <section class="wr-card" id="tab-panel-capabilities">
        <div class="wr-card-header">
          <div class="wr-card-title">🏛️ SKILL ENGINE — محرك المهارات وبوابات الإتقان والصيانة (Phase 2–5)</div>
        </div>

        <div class="wr-cap-grid" id="skills-list-grid" style="margin-bottom:18px;">
          ${skills.map((s) => {
            const p = s.progress || {};
            const isSel = s.id === selectedSkillId;
            return `
              <div class="wr-cap-card wr-skill-card-selectable ${isSel ? 'selected' : ''}" data-select-skill-id="${s.id}" id="skill-card-${s.id}">
                <div style="display:flex;justify-content:space-between;align-items:center;gap:6px;">
                  <strong style="font-size:14px;color:var(--accent-cyan);">${s.nameAr || s.name}</strong>
                  <span class="wr-badge state-${s.status}" id="skill-status-badge-${s.id}">${s.status}</span>
                </div>
                <div style="font-size:11px;color:var(--text-muted);margin:3px 0;">
                  ${s.name} • Lv ${s.currentLevel} → ${s.targetLevel}
                  ${s.historicalMasteryAchieved ? ' • 🏆 متقنة تاريخياً' : ''}
                </div>
                <div style="font-size:11px;color:var(--text-muted);display:grid;grid-template-columns:repeat(5,1fr);gap:4px;text-align:center;background:var(--bg-primary);padding:6px;border-radius:6px;">
                  <div><div>Activity</div><strong>${p.activityProgress ?? 0}%</strong></div>
                  <div><div>Learning</div><strong>${p.learningProgress ?? 0}%</strong></div>
                  <div><div>Comp.</div><strong>${p.competence ?? 0}%</strong></div>
                  <div><div>Mastery</div><strong>${p.mastery ?? 0}%</strong></div>
                  <div><div>Retent.</div><strong>${p.retention ?? 0}%</strong></div>
                </div>
              </div>
            `;
          }).join('')}
        </div>

        ${selSkill ? `
          <div class="wr-card" id="skill-detail-panel" style="background:#0f172a;border-color:var(--accent-cyan);">
            <div class="wr-card-header">
              <div>
                <span class="wr-card-title" id="detail-skill-title">🔍 تفاصيل المهارة: ${selSkill.nameAr || selSkill.name}</span>
                <span class="wr-badge state-${selSkill.status}" id="detail-skill-status">${selSkill.status}</span>
                <span class="wr-badge badge-focus" id="detail-skill-retention-status">Retention: ${selSkill.currentRetentionStatus || 'UNMASTERED'}</span>
              </div>
            </div>

            <div class="wr-5d-grid" id="detail-5d-progress">
              <div class="wr-5d-box"><span>1. Activity</span> <strong id="prog-val-activity">${prog.activityProgress}%</strong></div>
              <div class="wr-5d-box"><span>2. Learning</span> <strong id="prog-val-learning">${prog.learningProgress}%</strong></div>
              <div class="wr-5d-box"><span>3. Competence</span> <strong id="prog-val-competence">${prog.competence}%</strong></div>
              <div class="wr-5d-box"><span>4. Mastery</span> <strong id="prog-val-mastery">${prog.mastery}%</strong></div>
              <div class="wr-5d-box"><span>5. Retention</span> <strong id="prog-val-retention">${prog.retention}%</strong></div>
            </div>

            <div style="margin-top:10px;padding:8px;background:var(--bg-primary);border-radius:6px;font-size:11px;" id="skill-gate-explanation-box">
              <strong>تفسير بوابة الإتقان (Mastery Gate Decision):</strong> ${gate?.decisionExplanation || ''}
            </div>

            <div class="wr-task-list" id="skill-subskills-list" style="margin-top:12px;">
              ${bundle.subskills.map((sub) => `
                <div class="wr-task-item" data-subskill-id="${sub.id}" id="subskill-item-${sub.id}">
                  <div>
                    <strong>${sub.name}</strong>
                    <span class="wr-badge state-${sub.masteryState}" id="subskill-state-${sub.id}">${sub.masteryState}</span>
                  </div>
                </div>
              `).join('')}
            </div>

            <div class="wr-form-grid" style="margin-top:14px;">
              <form id="form-record-training" class="wr-cap-card">
                <div style="font-weight:700;font-size:13px;margin-bottom:6px;">🏋️ تسجيل تدريب ودليل</div>
                <select id="train-subskill-id" class="wr-select" style="margin-bottom:6px;">
                  <option value="">-- عام --</option>
                  ${bundle.subskills.map((s) => `<option value="${s.id}">${s.name}</option>`).join('')}
                </select>
                <input type="number" id="train-duration-min" class="wr-input" value="45" style="margin-bottom:6px;" required />
                <input type="text" id="train-evidence-title" class="wr-input" placeholder="عنوان الدليل" style="margin-bottom:6px;" required />
                <button type="submit" class="wr-btn wr-btn-primary" id="btn-record-training" style="width:100%;">حفظ التدريب</button>
              </form>

              <form id="form-record-test-attempt" class="wr-cap-card">
                <div style="font-weight:700;font-size:13px;margin-bottom:6px;">🧪 تسجيل اختبار</div>
                <select id="test-subskill-id" class="wr-select" style="margin-bottom:6px;">
                  <option value="">-- عام --</option>
                  ${bundle.subskills.map((s) => `<option value="${s.id}">${s.name}</option>`).join('')}
                </select>
                <input type="number" id="test-score-input" class="wr-input" value="90" style="margin-bottom:6px;" required />
                <input type="number" id="test-accuracy-input" class="wr-input" value="88" style="margin-bottom:6px;" required />
                <select id="test-linked-error-id" class="wr-select" style="margin-bottom:6px;">
                  <option value="">-- اختبار قياسي --</option>
                  ${bundle.errors.filter((e) => e.status !== 'resolved').map((e) => `<option value="${e.id}">${e.description.slice(0, 30)}</option>`).join('')}
                </select>
                <input type="text" id="test-evidence-input" class="wr-input" style="margin-bottom:6px;" />
                <button type="submit" class="wr-btn wr-btn-primary" id="btn-submit-test-attempt" style="width:100%;">تسجيل الاختبار</button>
              </form>
            </div>

            <div style="margin-top:14px;" id="skill-errors-remediation-section">
              <div class="wr-task-list" id="skill-remediations-list">
                ${bundle.remediations.map((rem) => {
                  const remTasks = bundle.correctiveTasks.filter((t) => t.remediationId === rem.id);
                  return `
                    <div class="wr-cap-card" data-remediation-id="${rem.id}">
                      <strong>Remediation: ${rem.title} (${rem.status})</strong>
                      ${remTasks.map((ct) => `
                        <div style="display:flex;justify-content:space-between;margin-top:6px;">
                          <span>${ct.status === 'completed' ? '✅' : '⏳'} ${ct.title}</span>
                          ${ct.status !== 'completed' ? `<button class="wr-btn wr-btn-primary" data-action="complete-corrective-task" data-task-id="${ct.id}">إتمام المهمة التصحيحية</button>` : ''}
                        </div>
                      `).join('')}
                    </div>
                  `;
                }).join('')}
              </div>
            </div>

            <form id="form-record-maintenance" class="wr-cap-card" style="margin-top:12px;">
              <input type="number" id="maint-score-input" class="wr-input" value="94" style="margin-bottom:6px;" required />
              <input type="text" id="maint-evidence-input" class="wr-input" value="مراجعة صيانة ناجحة" style="margin-bottom:6px;" required />
              <button type="submit" class="wr-btn wr-btn-secondary" id="btn-record-maintenance" style="width:100%;">تسجيل جلسة الصيانة</button>
            </form>
          </div>
        ` : ''}

        <div class="wr-cap-grid" id="capabilities-13-grid" style="margin-top:14px;">
          ${capabilities.map((c) => `<div class="wr-cap-card" data-capability-id="${c.id}"><strong>${c.order}. ${c.nameAr}</strong></div>`).join('')}
        </div>
      </section>
    `;
  }

  // =========================================================================
  // PHASE 4: INTERNAL TIME-BLOCK CALENDAR, WEEKLY PLANNER & SCHEDULE CONFIG
  // =========================================================================
  function renderScheduleAndCalendarTab(state) {
    const {
      currentDate,
      scheduleConfig,
      dailyExecutionView,
      weeklyPlan,
    } = state;

    const timeBlocks = dailyExecutionView?.timeBlocks || state.timeBlocks || [];
    const unscheduledTasks = dailyExecutionView?.unscheduledTasks || [];
    const conflictCheck = dailyExecutionView?.conflictCheck || { hasConflicts: false, conflicts: [] };
    const activeDayTasks = dailyExecutionView?.tasks || [];

    return `
      <section class="wr-card" id="tab-panel-schedule">
        <div class="wr-card-header">
          <div>
            <div class="wr-card-title">🗓️ INTERNAL CALENDAR, TIME BLOCKS & WEEKLY PLANNER (Phase 4)</div>
            <div style="font-size:12px;color:var(--text-muted);">
              الكتل الزمنية الداخلية (ثابتة ومتحركة)، كشف التعارضات، التخطيط الأسبوعي الموزع، وإعدادات الكلية والـ Buffers
            </div>
          </div>
          <span class="wr-badge ${conflictCheck.hasConflicts ? 'badge-primary' : 'badge-recovery'}" id="time-blocks-conflict-badge">
            ${conflictCheck.hasConflicts ? `⚠️ تعارضات: ${conflictCheck.conflicts.length}` : '✅ 0 تعارض زمني (Conflict-Free)'}
          </span>
        </div>

        <div class="wr-card" style="background:var(--bg-secondary);margin-bottom:16px;" id="day-time-blocks-section">
          <div style="font-size:14px;font-weight:700;color:var(--accent-cyan);margin-bottom:10px;">
            ⏰ الكتل الزمنية ليوم ${currentDate} (Internal Day Time-Block Schedule: ${timeBlocks.length})
          </div>

          <div class="wr-task-list" id="time-blocks-list" style="margin-bottom:14px;">
            ${timeBlocks.map((b) => `
              <div class="wr-task-item" data-block-id="${b.id}" style="padding:8px 12px;border-color:${b.isFixed ? 'rgba(168,85,247,0.4)' : 'var(--border-color)'};">
                <div>
                  <span style="font-family:monospace;font-weight:800;color:var(--accent-cyan);margin-left:8px;">
                    ${b.startTime}–${b.endTime}
                  </span>
                  <strong>${b.title}</strong>
                </div>
                <div style="display:flex;gap:6px;align-items:center;">
                  <span class="wr-badge ${b.isFixed ? 'badge-college' : 'badge-focus'}">
                    ${b.isFixed ? '🔒 Fixed Block' : '🔄 Movable Block'} (${b.blockType})
                  </span>
                </div>
              </div>
            `).join('')}
          </div>

          <div style="font-size:12px;margin-bottom:12px;" id="unscheduled-tasks-list">
            <strong>مهام غير مربوطة بكتلة زمنية (Unscheduled Tasks: ${unscheduledTasks.length}):</strong>
            ${unscheduledTasks.length === 0 ? `<span style="color:#6ee7b7;"> جميع المهام النشطة مسندة لفترات زمنية محددة.</span>` : unscheduledTasks.map((ut) => `<span class="wr-badge badge-maintenance" style="margin-right:4px;">${ut.title}</span>`).join('')}
          </div>

          <div class="wr-form-grid">
            <form id="form-create-time-block" class="wr-cap-card" style="background:var(--bg-primary);">
              <div style="font-size:12px;font-weight:700;margin-bottom:6px;">➕ إضافة / تعديل كتلة زمنية (Time Block)</div>
              <div class="wr-field" style="margin-bottom:6px;">
                <label>عنوان الكتلة الزمنية</label>
                <input type="text" id="blk-title-input" class="wr-input" placeholder="مثال: محاضرة إضافية أو نافذة مذاكرة" required />
              </div>
              <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin-bottom:6px;">
                <div class="wr-field">
                  <label>من (HH:MM)</label>
                  <input type="time" id="blk-start-input" class="wr-input" value="16:30" required />
                </div>
                <div class="wr-field">
                  <label>إلى (HH:MM)</label>
                  <input type="time" id="blk-end-input" class="wr-input" value="17:30" required />
                </div>
                <div class="wr-field">
                  <label>النوع</label>
                  <select id="blk-type-input" class="wr-select">
                    ${TIME_BLOCK_TYPES.map((bt) => `<option value="${bt}">${bt}</option>`).join('')}
                  </select>
                </div>
              </div>
              <label style="display:flex;align-items:center;gap:6px;font-size:12px;margin-bottom:8px;">
                <input type="checkbox" id="blk-is-fixed-input" checked />
                <span>التزام ثابت غير قابل للتحريك (Fixed Commitment)</span>
              </label>
              <button type="submit" class="wr-btn wr-btn-primary" id="btn-create-time-block" style="width:100%;">حفظ الكتلة الزمنية وفحص التعارض</button>
            </form>

            <form id="form-assign-task-block" class="wr-cap-card" style="background:var(--bg-primary);">
              <div style="font-size:12px;font-weight:700;margin-bottom:6px;">🔗 إسناد مهمة إلى كتلة زمنية (Assign Task to Block)</div>
              <div class="wr-field" style="margin-bottom:6px;">
                <label>المهمة</label>
                <select id="assign-task-select" class="wr-select">
                  ${activeDayTasks.map((t) => `<option value="${t.id}">${t.title}</option>`).join('')}
                </select>
              </div>
              <div class="wr-field" style="margin-bottom:8px;">
                <label>الكتلة الزمنية المتاحة (Movable Block)</label>
                <select id="assign-block-select" class="wr-select">
                  ${timeBlocks.filter((b) => !b.isFixed).map((b) => `<option value="${b.id}">${b.startTime}–${b.endTime}: ${b.title}</option>`).join('')}
                </select>
              </div>
              <button type="submit" class="wr-btn wr-btn-secondary" id="btn-assign-task-block" style="width:100%;">إسناد المهمة للكتلة الزمنية</button>
            </form>
          </div>
        </div>

        <div class="wr-card" style="background:var(--bg-secondary);margin-bottom:16px;" id="weekly-plan-section">
          <div class="wr-card-header">
            <div>
              <div class="wr-card-title">📅 الخطة الأسبوعية الموزعة (Weekly Plan Distribution: ${weeklyPlan?.weekStartDate || currentDate} → ${weeklyPlan?.weekEndDate || ''})</div>
              <div style="font-size:11px;color:var(--text-muted);">
                توزع الأهداف والمسارات والصيانة والاستشفاء عبر 7 أيام دون نسخ نفس اليوم المزدحم 7 مرات (تم التوليد #${weeklyPlan?.regeneratedCount || 1})
              </div>
            </div>
            <button class="wr-btn wr-btn-secondary" id="btn-regenerate-weekly-plan">
              🔄 إعادة توليد الأسبوع (مع حفظ المنجز)
            </button>
          </div>

          <div class="wr-cap-grid" id="weekly-plan-grid">
            ${(weeklyPlan?.days || []).map((d) => `
              <div class="wr-cap-card" data-week-day="${d.date}" style="background:var(--bg-primary);border-color:${d.isCollegeDay ? 'rgba(168,85,247,0.4)' : 'var(--border-subtle)'};">
                <div style="display:flex;justify-content:space-between;align-items:center;">
                  <strong>${d.dayName} (${d.date})</strong>
                  <span class="wr-badge ${d.isCollegeDay ? 'badge-college' : 'badge-focus'}">${d.isCollegeDay ? 'كلية' : 'تركيز حر'}</span>
                </div>
                <div style="font-size:12px;color:var(--accent-cyan);margin-top:4px;font-weight:700;">${d.dayTheme}</div>
                <div style="font-size:11px;color:var(--text-secondary);margin-top:4px;">
                  الحمل المخطط: <strong>${d.plannedWorkloadMin} د</strong> / المتاح: ${d.availableNetMin} د (Buffer: ${d.bufferMin} د)
                </div>
                <div style="font-size:10px;color:var(--text-muted);margin-top:3px;">
                  ${d.includesMaintenance ? '🔄 صيانة ومراجعة • ' : ''}${d.includesRecovery ? '🥊 استشفاء بدني • ' : ''}مهام مكتملة: ${d.completedTasksCount}
                </div>
              </div>
            `).join('')}
          </div>
        </div>

        <form id="form-schedule-config">
          <div style="font-size:14px;font-weight:700;margin-bottom:10px;">⚙️ إعدادات الالتزامات الثابتة، النوم، ونسبة الاحتياطي (Configurable Schedule & Buffers)</div>
          <div style="margin-bottom:14px;">
            <label style="display:block;font-size:13px;font-weight:700;margin-bottom:8px;">أيام حضور الكلية (College Days):</label>
            <div style="display:flex;flex-wrap:wrap;gap:8px;">
              ${DAYS_OF_WEEK.map((day) => {
                const checked = scheduleConfig.collegeDays.includes(day);
                return `
                  <label style="display:inline-flex;align-items:center;gap:6px;background:var(--bg-secondary);padding:8px 12px;border-radius:8px;border:1px solid ${checked ? 'var(--accent-cyan)' : 'var(--border-subtle)'};cursor:pointer;font-size:13px;">
                    <input type="checkbox" name="collegeDay" value="${day}" ${checked ? 'checked' : ''} />
                    <span>${day}</span>
                  </label>
                `;
              }).join('')}
            </div>
          </div>

          <div class="wr-form-grid">
            <div class="wr-field">
              <label>وقت بداية الكلية (HH:MM)</label>
              <input type="time" id="sched-college-start" class="wr-input" value="${scheduleConfig.collegeStart}" required />
            </div>
            <div class="wr-field">
              <label>وقت نهاية الكلية (HH:MM)</label>
              <input type="time" id="sched-college-end" class="wr-input" value="${scheduleConfig.collegeEnd}" required />
            </div>
            <div class="wr-field">
              <label>ساعات النوم اليومية (Sleep Hours)</label>
              <input type="number" step="0.5" id="sched-sleep-hours" class="wr-input" value="${scheduleConfig.sleepHours}" min="4" max="12" required />
            </div>
            <div class="wr-field">
              <label>ساعات الوجبات والصلاة (Meals & Prayer)</label>
              <input type="number" step="0.5" id="sched-meals-hours" class="wr-input" value="${scheduleConfig.mealsAndPrayerHours}" min="0.5" max="6" required />
            </div>
            <div class="wr-field">
              <label>التزامات شخصية أخرى (Other Hours)</label>
              <input type="number" step="0.5" id="sched-other-hours" class="wr-input" value="${scheduleConfig.otherCommitmentsHours}" min="0" max="8" required />
            </div>
            <div class="wr-field">
              <label>سعة العمل العميق في الأيام الحرة (ساعات)</label>
              <input type="number" step="0.5" id="sched-deep-work-hours" class="wr-input" value="${scheduleConfig.deepWorkCapacityHours}" min="1" max="10" required />
            </div>
          </div>

          <div style="margin-top:16px;">
            <button type="submit" class="wr-btn wr-btn-primary" id="btn-save-schedule">💾 حفظ إعدادات الجدول وإعادة حساب خطة اليوم والأسبوع</button>
          </div>
        </form>
      </section>
    `;
  }

  function renderApp() {
    const state = store.getState();
    const {
      currentDate,
      currentEnergy,
      activeTab,
      skills,
      scheduleConfig,
      dailyPlan,
      timerState,
      progressSummary,
      enginesRegistry,
    } = state;

    const liveTimer = engines.timerEngine.computeLiveMetrics(timerState, Date.now());
    const budget = dailyPlan?.budget || engines.timeEngine.calculateDayBudget(scheduleConfig, currentDate, currentEnergy);

    const skillMap = {};
    for (const s of skills) skillMap[s.id] = s;

    const isTimerActive = liveTimer.status === 'running' || liveTimer.status === 'paused';

    rootElement.innerHTML = `
      <header class="wr-header">
        <div class="wr-header-top">
          <div class="wr-brand">
            <div class="wr-logo">WR</div>
            <div>
              <div class="wr-title">WHITE ROOM OS <span style="font-size:11px;font-weight:400;color:#94a3b8;">v9.0</span></div>
              <div class="wr-subtitle">PERSONAL DEVELOPMENT OS • PHASE 9 OUTCOME CALIBRATION & RECOMMENDATION EFFECTIVENESS</div>
            </div>
          </div>
          <div class="wr-status-pill" id="wr-storage-status">
            ${db.hasBrowserIndexedDB() ? '🟢 IndexedDB v9 Active (v7+ Compatible)' : '🟢 Local Store v9 Active'} • 13 Domains
          </div>
        </div>

        <div class="wr-mini-timer ${isTimerActive ? '' : 'hidden'}" id="wr-mini-timer-bar">
          <div>
            <span class="wr-badge ${liveTimer.status === 'running' ? 'badge-focus' : 'badge-maintenance'}">
              ${liveTimer.status === 'running' ? '⏱ جارٍ التنفيذ' : '⏸ متوقف مؤقتاً'}
            </span>
            <strong style="margin-right:6px;font-size:13px;" id="wr-mini-timer-title">${liveTimer.taskTitle || ''}</strong>
          </div>
          <div style="display:flex;align-items:center;gap:10px;">
            <span class="wr-mini-timer-clock" id="wr-mini-timer-clock">${formatSecondsHHMMSS(liveTimer.elapsedActiveSec)}</span>
            <button class="wr-btn wr-btn-secondary" data-action="go-timer-tab" style="padding:5px 10px;font-size:12px;">فتح المؤقت</button>
          </div>
        </div>
      </header>

      <main class="wr-container">
        <section class="wr-kpi-grid">
          <div class="wr-kpi-card">
            <div class="wr-kpi-label">إنجاز مهام النظام</div>
            <div class="wr-kpi-value" id="kpi-completion-rate">${progressSummary?.taskCompletionRate ?? 0}%</div>
            <div class="wr-kpi-sub">${progressSummary?.completedTasks ?? 0} / ${progressSummary?.totalTasks ?? 0} مهمة مكتملة</div>
          </div>
          <div class="wr-kpi-card">
            <div class="wr-kpi-label">المهارات المتقنة (Mastered)</div>
            <div class="wr-kpi-value" id="kpi-mastered-skills">${progressSummary?.masteredSkillsCount ?? 0} / ${progressSummary?.totalSkillsCount ?? skills.length}</div>
            <div class="wr-kpi-sub">جلسات مسجلة: <span id="kpi-sessions-count">${progressSummary?.totalSessionsLogged ?? 0}</span></div>
          </div>
          <div class="wr-kpi-card">
            <div class="wr-kpi-label">الوقت الحر المتاح اليوم</div>
            <div class="wr-kpi-value" id="kpi-free-hours">${budget.netFreeHours} س</div>
            <div class="wr-kpi-sub">${budget.isCollegeDay ? 'يوم كلية (06:00–18:00)' : 'يوم تركيز كامل'}</div>
          </div>
          <div class="wr-kpi-card">
            <div class="wr-kpi-label">الأخطاء المفتوحة للمعالجة</div>
            <div class="wr-kpi-value" id="kpi-open-errors" style="color:${(progressSummary?.openErrorsCount || 0) > 0 ? '#fda4af' : '#6ee7b7'}">${progressSummary?.openErrorsCount ?? 0}</div>
            <div class="wr-kpi-sub">${progressSummary?.bottleneckSkillId ? 'Bottleneck: ' + (skillMap[progressSummary.bottleneckSkillId]?.nameAr || progressSummary.bottleneckSkillId) : 'لا يوجد اختناق حرج'}</div>
          </div>
        </section>

        ${activeTab === 'daily-os' ? renderTodayExecutionTab(state, skillMap) : ''}
        ${activeTab === 'diagnostics' ? renderDiagnosticsAndMasteryTab(state, skillMap) : ''}
        ${activeTab === 'strategy' ? renderStrategyAndPriorityTab(state, skillMap) : ''}
        ${activeTab === 'analytics' ? renderAnalyticsAndReviewsTab(state, skillMap) : ''}

        ${activeTab === 'timer' ? `
          <section class="wr-card" id="tab-panel-timer">
            <div class="wr-card-header">
              <div>
                <div class="wr-card-title">⏱ PERSISTENT TIMER & PERFORMANCE LOG</div>
              </div>
              <span class="wr-badge ${liveTimer.status === 'running' ? 'badge-focus' : 'badge-secondary'}" id="timer-status-badge">
                الحالة: ${liveTimer.status.toUpperCase()}
              </span>
            </div>

            <div class="wr-timer-hud">
              <div style="font-size:14px;color:var(--text-secondary);font-weight:700;" id="timer-active-task-title">
                ${liveTimer.taskTitle || 'لم يتم اختيار مهمة بعد'}
              </div>
              <div class="wr-timer-digits" id="timer-main-display">
                ${formatSecondsHHMMSS(liveTimer.elapsedActiveSec)}
              </div>
              <div style="font-size:12px;color:var(--text-muted);font-family:monospace;">
                المخطط: ${formatSecondsHHMMSS(liveTimer.plannedDurationSec)} | المتبقي: <span id="timer-remaining-display">${formatSecondsHHMMSS(liveTimer.remainingSec)}</span> | وقت التوقف المؤقت: <span id="timer-pause-display">${formatSecondsHHMMSS(liveTimer.elapsedPauseSec)}</span>
              </div>
              <div class="wr-progress-bar-wrap">
                <div class="wr-progress-bar-fill" id="timer-progress-bar" style="width:${liveTimer.progressPct}%;"></div>
              </div>

              <div style="display:flex;justify-content:center;gap:8px;flex-wrap:wrap;margin-top:14px;">
                ${liveTimer.status === 'idle' || liveTimer.status === 'finished' || liveTimer.status === 'cancelled' ? `
                  <button class="wr-btn wr-btn-primary" id="btn-timer-start-default">▶ بدء جلسة على المهمة الأولى</button>
                ` : ''}
                ${liveTimer.status === 'running' ? `
                  <button class="wr-btn wr-btn-amber" id="btn-timer-pause">⏸ إيقاف مؤقت (Pause)</button>
                ` : ''}
                ${liveTimer.status === 'paused' ? `
                  <button class="wr-btn wr-btn-primary" id="btn-timer-resume">▶ استئناف (Resume)</button>
                ` : ''}
                ${liveTimer.status === 'running' || liveTimer.status === 'paused' ? `
                  <button class="wr-btn wr-btn-primary" id="btn-timer-finish" style="background:var(--accent-emerald);">✅ إنهاء الجلسة (Finish)</button>
                  <button class="wr-btn wr-btn-danger" id="btn-timer-cancel">✖ إلغاء (Cancel)</button>
                ` : ''}
                <button class="wr-btn wr-btn-secondary" id="btn-timer-reset">🔄 تصفير (Reset)</button>
              </div>
            </div>

            <div class="wr-card" style="background:var(--bg-secondary);margin-bottom:16px;">
              <form id="form-performance-log">
                <div class="wr-form-grid">
                  <div class="wr-field">
                    <label>المهمة</label>
                    <select id="perf-task-id" class="wr-select" required>
                      ${(state.dailyExecutionView?.tasks || dailyPlan?.tasks || []).map((t) => `
                        <option value="${t.id}" ${t.id === liveTimer.taskId ? 'selected' : ''}>${t.title}</option>
                      `).join('')}
                    </select>
                  </div>
                  <div class="wr-field">
                    <label>المدة الفعلية (دقائق)</label>
                    <input type="number" id="perf-actual-min" class="wr-input" value="45" required />
                  </div>
                  <div class="wr-field">
                    <label>نسبة الإنجاز Completion %</label>
                    <input type="number" id="perf-completion-pct" class="wr-input" value="100" required />
                  </div>
                  <div class="wr-field">
                    <label>الطاقة Energy (1-10)</label>
                    <input type="number" id="perf-energy" class="wr-input" value="8" required />
                  </div>
                  <div class="wr-field">
                    <label>الصعوبة Difficulty (1-10)</label>
                    <input type="number" id="perf-difficulty" class="wr-input" value="6" required />
                  </div>
                  <div class="wr-field">
                    <label>الثقة Confidence (1-10)</label>
                    <input type="number" id="perf-confidence" class="wr-input" value="8" required />
                  </div>
                </div>
                <div class="wr-form-grid" style="margin-top:10px;">
                  <div class="wr-field">
                    <label>ماذا تعلمت؟</label>
                    <textarea id="perf-what-learned" class="wr-textarea" rows="2"></textarea>
                  </div>
                  <div class="wr-field">
                    <label>الأخطاء المرصودة</label>
                    <textarea id="perf-mistakes" class="wr-textarea" rows="2"></textarea>
                  </div>
                </div>
                <div class="wr-field" style="margin-top:10px;">
                  <input type="text" id="perf-notes" class="wr-input" placeholder="ملاحظات..." />
                </div>
                <div style="margin-top:12px;">
                  <button type="submit" class="wr-btn wr-btn-primary" id="btn-submit-performance-log">💾 حفظ سجل الأداء</button>
                </div>
              </form>
            </div>
          </section>
        ` : ''}

        ${activeTab === 'learning' ? renderLearningEngineTab(state, skillMap) : ''}
        ${activeTab === 'capabilities' ? renderSkillEngineTab(state, skillMap) : ''}
        ${activeTab === 'schedule' ? renderScheduleAndCalendarTab(state) : ''}

        ${activeTab === 'system' ? `
          <section class="wr-card" id="tab-panel-system">
            <div class="wr-card-header">
              <div>
                <div class="wr-card-title">🛡️ BACKUP / RESTORE & 23 MASTER ENGINES MATRIX</div>
                <div style="font-size:12px;color:var(--text-muted);">النسخ الاحتياطي المحلي (v9 Schema • 35 Stores) مع فحص Checksum + مصفوفة حالة المحركات الـ 23</div>
              </div>
            </div>

            <div class="wr-form-grid" style="margin-bottom:18px;">
              <div class="wr-cap-card">
                <div style="font-weight:700;font-size:14px;margin-bottom:6px;">⬇️ تصدير نسخة احتياطية كاملة (Export Backup)</div>
                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                  <button class="wr-btn wr-btn-primary" id="btn-export-backup">توليد وعرض النسخة الاحتياطية</button>
                  <button class="wr-btn wr-btn-secondary" id="btn-download-backup">تحميل ملف .JSON</button>
                </div>
              </div>

              <div class="wr-cap-card">
                <div style="font-weight:700;font-size:14px;margin-bottom:6px;">⬆️ استعادة نسخة احتياطية (Restore Backup / File Picker)</div>
                <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:8px;">
                  <button class="wr-btn wr-btn-amber" id="btn-restore-backup">استعادة من حقل JSON أدناه</button>
                  <label for="input-backup-file-picker" class="wr-btn wr-btn-secondary" style="cursor:pointer;margin:0;">📂 اختيار ملف .JSON من الهاتف</label>
                  <input type="file" id="input-backup-file-picker" accept=".json,application/json" style="font-size:11px;max-width:210px;" />
                </div>
              </div>
            </div>

            <div class="wr-field" style="margin-bottom:18px;">
              <textarea id="backup-json-textarea" class="wr-textarea" rows="5" style="font-family:monospace;font-size:11px;direction:ltr;text-align:left;"></textarea>
            </div>

            <div style="overflow-x:auto;">
              <table class="wr-table">
                <thead>
                  <tr>
                    <th>الكود</th>
                    <th>المحرك</th>
                    <th>المرحلة</th>
                    <th>الحالة</th>
                    <th>التفاصيل</th>
                  </tr>
                </thead>
                <tbody>
                  ${enginesRegistry.map((eng) => `
                    <tr>
                      <td style="font-family:monospace;font-weight:700;">${eng.code}</td>
                      <td style="font-weight:700;">${eng.name}</td>
                      <td>Phase ${eng.phase}</td>
                      <td><span class="wr-badge badge-recovery">${eng.status}</span></td>
                      <td>${eng.notes}</td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          </section>
        ` : ''}
      </main>

      <div id="wr-toast" class="wr-toast hidden"></div>

      <nav class="wr-bottom-nav">
        <button class="wr-nav-btn ${activeTab === 'daily-os' ? 'active' : ''}" data-nav-tab="daily-os" id="nav-tab-daily-os">
          <span>⚡</span>
          <span>Today OS</span>
        </button>
        <button class="wr-nav-btn ${activeTab === 'diagnostics' ? 'active' : ''}" data-nav-tab="diagnostics" id="nav-tab-diagnostics">
          <span>🩺</span>
          <span>التشخيص والإتقان</span>
        </button>
        <button class="wr-nav-btn ${activeTab === 'strategy' ? 'active' : ''}" data-nav-tab="strategy" id="nav-tab-strategy">
          <span>🧭</span>
          <span>الاستراتيجية</span>
        </button>
        <button class="wr-nav-btn ${activeTab === 'analytics' ? 'active' : ''}" data-nav-tab="analytics" id="nav-tab-analytics">
          <span>📊</span>
          <span>التقارير والتحليلات</span>
        </button>
        <button class="wr-nav-btn ${activeTab === 'timer' ? 'active' : ''}" data-nav-tab="timer" id="nav-tab-timer">
          <span>⏱</span>
          <span>المؤقت</span>
        </button>
        <button class="wr-nav-btn ${activeTab === 'learning' ? 'active' : ''}" data-nav-tab="learning" id="nav-tab-learning">
          <span>🧠</span>
          <span>محرك التعلم</span>
        </button>
        <button class="wr-nav-btn ${activeTab === 'capabilities' ? 'active' : ''}" data-nav-tab="capabilities" id="nav-tab-capabilities">
          <span>🏛️</span>
          <span>المهارات</span>
        </button>
        <button class="wr-nav-btn ${activeTab === 'schedule' ? 'active' : ''}" data-nav-tab="schedule" id="nav-tab-schedule">
          <span>🗓️</span>
          <span>الجدولة والأسبوع</span>
        </button>
        <button class="wr-nav-btn ${activeTab === 'system' ? 'active' : ''}" data-nav-tab="system" id="nav-tab-system">
          <span>🛡️</span>
          <span>النظام</span>
        </button>
      </nav>
    `;

    attachEventHandlers();
  }

  function attachEventHandlers() {
    restoreFormDrafts();

    rootElement.querySelectorAll('input[type="text"], textarea').forEach((el) => {
      if (el.id && !el.readOnly) {
        el.addEventListener('input', () => {
          formDraftCache[el.id] = el.value;
        });
      }
    });

    rootElement.querySelectorAll('[data-nav-tab]').forEach((btn) => {
      btn.addEventListener('click', () => {
        captureFormDrafts();
        const currentTab = store.getState().activeTab;
        const tab = btn.getAttribute('data-nav-tab');
        if (tab && tab !== currentTab) {
          tabHistoryStack.push(currentTab);
          if (typeof window !== 'undefined' && window.history?.pushState) {
            window.history.pushState({ activeTab: tab }, '');
          }
          store.setState({ activeTab: tab });
        }
      });
    });

    const goTimerBtn = rootElement.querySelector('[data-action="go-timer-tab"]');
    if (goTimerBtn) {
      goTimerBtn.addEventListener('click', () => store.setState({ activeTab: 'timer' }));
    }



    // Phase 7 Strategic Recommendation Decisions (Accept, Modify, Defer, Reject, Dismiss & Outcome Evaluation)
    rootElement.querySelectorAll("[data-action=\"strategy-accept\"]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          const recKey = btn.getAttribute("data-rec-key");
          const res = await engines.strategyEngine.recordRecommendationDecision({
            recommendationKey: recKey,
            status: "ACCEPTED",
            referenceDate: store.getState().currentDate,
          });
          await store.getState().refreshAll();
          showToast(`✅ تم اعتماد التوصية وجدولة المهمة: ${res.createdOrLinkedTask?.title || recKey}`);
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    });

    rootElement.querySelectorAll("[data-action=\"strategy-modify\"]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          const recKey = btn.getAttribute("data-rec-key");
          await engines.strategyEngine.recordRecommendationDecision({
            recommendationKey: recKey,
            status: "MODIFIED",
            modifiedDurationMin: 20,
            userReason: "تعديل مدة الجلسة الاستراتيجية إلى 20 دقيقة واعتمادها",
            referenceDate: store.getState().currentDate,
          });
          await store.getState().refreshAll();
          showToast("✏️ تم تعديل المقترح الاستراتيجي واعتماده بنجاح");
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    });

    rootElement.querySelectorAll("[data-action=\"strategy-defer\"]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          const recKey = btn.getAttribute("data-rec-key");
          await engines.strategyEngine.recordRecommendationDecision({
            recommendationKey: recKey,
            status: "DEFERRED",
            userReason: "تأجيل لمراجعة لاحقة",
            referenceDate: store.getState().currentDate,
          });
          await store.getState().refreshAll();
          showToast("⏳ تم تسجيل تأجيل التوصية الاستراتيجية");
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    });

    rootElement.querySelectorAll("[data-action=\"strategy-reject\"]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          const recKey = btn.getAttribute("data-rec-key");
          await engines.strategyEngine.recordRecommendationDecision({
            recommendationKey: recKey,
            status: "REJECTED",
            userReason: "تفضيل مسار بديل حالياً",
            referenceDate: store.getState().currentDate,
          });
          await store.getState().refreshAll();
          showToast("✖ تم تسجيل رفض التوصية مع احترام تفضيلك");
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    });

    rootElement.querySelectorAll("[data-action=\"strategy-dismiss\"]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          const recKey = btn.getAttribute("data-rec-key");
          await engines.strategyEngine.recordRecommendationDecision({
            recommendationKey: recKey,
            status: "DISMISSED",
            userReason: "استبعاد حتى ظهور أدلة جديدة",
            referenceDate: store.getState().currentDate,
          });
          await store.getState().refreshAll();
          showToast("🔕 تم استبعاد التوصية ولن تتكرر إلا عند ظهور أدلة جديدة");
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    });

    const btnEvalOutcomes = document.getElementById("btn-evaluate-strategy-outcomes");
    if (btnEvalOutcomes) {
      btnEvalOutcomes.addEventListener("click", async () => {
        await engines.strategyEngine.evaluateRecommendationOutcomes({
          referenceDate: store.getState().currentDate,
        });
        await store.getState().refreshAll();
        showToast("🔄 تم فحص وتحديث نتائج التوصيات المعتمدة بناءً على الاختبارات والأدلة اللاحقة");
      });
    }

    rootElement.querySelectorAll('[data-action="strategy-reevaluate-decision"]').forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          const decId = btn.getAttribute("data-decision-id");
          const res = await engines.strategyEngine.reevaluateDecisionOutcome(decId, {
            referenceDate: store.getState().currentDate,
            forceReevaluate: true,
            reevaluationReason: "إعادة تقييم يدوية من واجهة المعايرة مع حفظ التقييم السابق",
          });
          await store.getState().refreshAll();
          showToast(`♻️ تمت إعادة التقييم وحفظ الإصدار #${res.evaluationHistory.length} مع الاحتفاظ بالسجل السابق`);
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    });

    // Phase 6 Analytics Filters, Jump Links, Periodic Reviews & Exports
    const formAnalyticsFilters = document.getElementById("form-analytics-filters");
    if (formAnalyticsFilters) {
      formAnalyticsFilters.addEventListener("submit", async (e) => {
        e.preventDefault();
        const startDate = document.getElementById("filter-start-date").value;
        const endDate = document.getElementById("filter-end-date").value;
        const goalId = document.getElementById("filter-goal-id").value;
        const capabilityId = document.getElementById("filter-capability-id").value;
        const skillId = document.getElementById("filter-skill-id").value;
        await store.getState().setAnalyticsFilters({ startDate, endDate, goalId, capabilityId, skillId });
        showToast("تم تطبيق فلاتر التحليلات بنجاح");
      });
    }

    const btnResetFilters = document.getElementById("btn-reset-analytics-filters");
    if (btnResetFilters) {
      btnResetFilters.addEventListener("click", async () => {
        await store.getState().setAnalyticsFilters({ startDate: "", endDate: "", goalId: "", capabilityId: "", skillId: "" });
        showToast("تمت إعادة ضبط فلاتر التحليلات");
      });
    }

    rootElement.querySelectorAll("[data-jump-skill-id]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const skillId = btn.getAttribute("data-jump-skill-id");
        const targetTab = btn.getAttribute("data-jump-tab") || "diagnostics";
        store.setState({ selectedSkillId: skillId, activeTab: targetTab });
        await store.getState().refreshAll();
      });
    });

    rootElement.querySelectorAll("[data-review-period]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const pt = btn.getAttribute("data-review-period");
        await store.getState().setActiveReviewPeriodType(pt);
      });
    });

    const formSavePeriodicReview = document.getElementById("form-save-periodic-review");
    if (formSavePeriodicReview) {
      formSavePeriodicReview.addEventListener("submit", async (e) => {
        e.preventDefault();
        const userNotes = document.getElementById("review-user-notes").value.trim();
        const decisions = document.getElementById("review-decisions").value.trim();
        const nextActions = document.getElementById("review-next-actions").value.trim();
        const periodType = store.getState().activeReviewPeriodType || "daily";
        await engines.analyticsEngine.savePeriodicReview({
          periodType,
          referenceDate: store.getState().currentDate,
          userNotes,
          decisions,
          nextActions,
        });
        await store.getState().refreshAll();
        showToast(`تم حفظ المراجعة الدورية (${periodType}) في الأرشيف التاريخي`);
      });
    }

    const getActiveFilterOpts = () => {
      const st = store.getState();
      return {
        referenceDate: st.currentDate,
        startDate: st.analyticsFilters?.startDate || null,
        endDate: st.analyticsFilters?.endDate || null,
        goalId: st.analyticsFilters?.goalId || null,
        capabilityId: st.analyticsFilters?.capabilityId || null,
        skillId: st.analyticsFilters?.skillId || null,
      };
    };

    const btnExpJson = document.getElementById("btn-export-report-json");
    if (btnExpJson) {
      btnExpJson.addEventListener("click", async () => {
        const out = await engines.analyticsEngine.exportReportJSON(getActiveFilterOpts());
        const area = document.getElementById("analytics-export-textarea");
        if (area) area.value = out;
        showToast("تم توليد تقرير JSON الموثق");
      });
    }

    const btnExpCsv = document.getElementById("btn-export-report-csv");
    if (btnExpCsv) {
      btnExpCsv.addEventListener("click", async () => {
        const out = await engines.analyticsEngine.exportReportCSV(getActiveFilterOpts());
        const area = document.getElementById("analytics-export-textarea");
        if (area) area.value = out;
        showToast("تم توليد تقرير CSV الموثق (RFC-4180)");
      });
    }

    const btnExpMd = document.getElementById("btn-export-report-md");
    if (btnExpMd) {
      btnExpMd.addEventListener("click", async () => {
        const out = await engines.analyticsEngine.exportReportMarkdown(getActiveFilterOpts());
        const area = document.getElementById("analytics-export-textarea");
        if (area) area.value = out;
        showToast("تم توليد تقرير Markdown الموثق");
      });
    }

    // Phase 5 Diagnostic Assessment Form
    const formRunDiag = document.getElementById('form-run-diagnostic');
    if (formRunDiag) {
      formRunDiag.addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
          const skillId = document.getElementById('diag-skill-id').value;
          const subskillId = document.getElementById('diag-subskill-id').value || null;
          const score = Number(document.getElementById('diag-score-input').value);
          const accuracy = Number(document.getElementById('diag-accuracy-input').value);
          const reportedCategory = document.getElementById('diag-category-input').value;
          const observedNotes = document.getElementById('diag-observed-notes').value.trim();

          const res = await engines.diagnosticsEngine.runDiagnosticAssessment({
            skillId,
            subskillId,
            score,
            accuracy,
            reportedCategory,
            observedNotes,
            date: store.getState().currentDate,
          });
          store.setState({ selectedSkillId: skillId });
          await store.getState().refreshAll();
          showToast(
            `تم حفظ التشخيص وتوليد ${res.hypotheses.length} فرضية سبب جذري (${res.diagnostic.primaryCategory})`
          );
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    }

    // Phase 5 Generate Targeted Remediation
    rootElement.querySelectorAll('[data-action="generate-targeted-remediation"]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          const errorId = btn.getAttribute('data-error-id');
          const res = await engines.diagnosticsEngine.generateTargetedRemediation(errorId, {
            date: store.getState().currentDate,
          });
          await store.getState().refreshAll();
          showToast(
            `تم توليد الخطة العلاجية و(${res.correctiveTasks.length}) مهام تصحيحية مخصصة`
          );
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    });

    // Phase 5 Verified Retest Form
    const formVerifiedRetest = document.getElementById('form-verified-retest');
    if (formVerifiedRetest) {
      formVerifiedRetest.addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
          const linkedErrorId = document.getElementById('retest-error-id').value;
          const verificationMode = document.getElementById('retest-verification-mode').value;
          const score = Number(document.getElementById('retest-score-input').value);
          const accuracy = Number(document.getElementById('retest-accuracy-input').value);
          const evidence = document.getElementById('retest-evidence-input').value.trim();

          const res = await engines.diagnosticsEngine.executeVerifiedRetest({
            linkedErrorId,
            verificationMode,
            score,
            accuracy,
            evidence,
          });
          await store.getState().refreshAll();
          showToast(
            res.passed
              ? `✅ اجتزت إعادة الاختبار المحققة (${verificationMode}) وتم إغلاق الخطأ!`
              : '⚠️ لم تجتز إعادة الاختبار؛ تم حفظ المحاولة وتصعيد الخطة العلاجية'
          );
        } catch (err) {
          showToast(`منع إعادة الاختبار: ${err.message}`);
        }
      });
    }

    // Phase 5 Retention Check Form in Diagnostics Tab
    const formDiagRet = document.getElementById('form-diag-retention-check');
    if (formDiagRet) {
      formDiagRet.addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
          const skillId = store.getState().selectedSkillId;
          const score = Number(document.getElementById('diag-ret-score').value);
          const retentionEvidence = document.getElementById('diag-ret-evidence').value.trim();

          const res = await engines.skillEngine.recordMaintenanceSession({
            skillId,
            reviewDate: store.getState().currentDate,
            score,
            retentionEvidence,
          });
          await store.getState().refreshAll();
          showToast(
            res.passed
              ? `✅ فحص احتفاظ ناجح (${score}%) — المراجعة القادمة: ${res.nextReviewDate}`
              : `⚠️ تراجع في الاحتفاظ (${score}%) — الإتقان التاريخي محفوظ وتم فتح مسار إعادة تعلم (Relearning)`
          );
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    }

    // Phase 4 Task Lifecycle Actions on Today Screen
    rootElement.querySelectorAll('[data-action="start-task-timer"]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          const taskId = btn.getAttribute('data-task-id');
          const started = await engines.schedulerEngine.startTaskExecution(taskId, Date.now());
          await store.getState().refreshAll();
          store.setState({ activeTab: 'timer' });
          showToast(`بدأ تنفيذ المهمة والمؤقت: ${started.title}`);
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    });

    rootElement.querySelectorAll('[data-action="exec-complete-task"]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          const taskId = btn.getAttribute('data-task-id');
          const res = await engines.schedulerEngine.completeTaskExecution(taskId, {
            outcome: 'تم إتمام المهمة بنجاح من شاشة التنفيذ اليومي',
            energy: store.getState().currentEnergy,
          });
          await store.getState().refreshAll();
          showToast(`✅ اكتملت المهمة: ${res.task.title}`);
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    });

    rootElement.querySelectorAll('[data-action="exec-partial-task"]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          const taskId = btn.getAttribute('data-task-id');
          const res = await engines.schedulerEngine.partiallyCompleteTaskExecution(taskId, {
            completionPct: 50,
            energy: store.getState().currentEnergy,
          });
          await store.getState().refreshAll();
          showToast(`🌗 تم تسجيل إنجاز 50% وجدولة المتبقي ليوم الغد (${res.continuationTask.date})`);
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    });

    rootElement.querySelectorAll('[data-action="exec-skip-task"]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          const taskId = btn.getAttribute('data-task-id');
          await engines.schedulerEngine.skipTaskExecution(taskId, {
            skipReason: 'ضيق الوقت أو الحاجة لتقسيم المهمة',
            energy: store.getState().currentEnergy,
          });
          await store.getState().refreshAll();
          showToast('⏭️ تم تخطي المهمة وتشخيص السبب وإعادة جدولتها بتكييف ذكي ليوم الغد');
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    });

    // Phase 4 Time-Block Creation & Task Assignment
    const formTimeBlock = document.getElementById('form-create-time-block');
    if (formTimeBlock) {
      formTimeBlock.addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
          const title = document.getElementById('blk-title-input').value.trim();
          const startTime = document.getElementById('blk-start-input').value;
          const endTime = document.getElementById('blk-end-input').value;
          const blockType = document.getElementById('blk-type-input').value;
          const isFixed = document.getElementById('blk-is-fixed-input').checked;

          const res = await engines.schedulerEngine.createOrUpdateTimeBlock({
            date: store.getState().currentDate,
            title,
            startTime,
            endTime,
            blockType,
            isFixed,
          });
          await store.getState().refreshAll();
          showToast(
            res.conflictCheck.hasConflicts
              ? `تم الحفظ مع رصد ${res.conflictCheck.conflicts.length} تعارض زمني`
              : 'تم حفظ الكتلة الزمنية بدون أي تعارض'
          );
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    }

    const formAssignBlock = document.getElementById('form-assign-task-block');
    if (formAssignBlock) {
      formAssignBlock.addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
          const taskId = document.getElementById('assign-task-select').value;
          const blockId = document.getElementById('assign-block-select').value;
          if (!taskId || !blockId) return;
          await engines.schedulerEngine.assignTaskToTimeBlock(taskId, blockId);
          await store.getState().refreshAll();
          showToast('تم إسناد المهمة للكتلة الزمنية بنجاح');
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    }

    const btnRegenWeek = document.getElementById('btn-regenerate-weekly-plan');
    if (btnRegenWeek) {
      btnRegenWeek.addEventListener('click', async () => {
        await engines.schedulerEngine.generateWeeklyPlan(store.getState().currentDate, {
          preserveCompleted: true,
        });
        await store.getState().refreshAll();
        showToast('تم إعادة توليد الخطة الأسبوعية الموزعة مع الحفاظ على السجلات المنجزة');
      });
    }

    rootElement.querySelectorAll('[data-select-objective-id]').forEach((el) => {
      el.addEventListener('click', async () => {
        const objId = el.getAttribute('data-select-objective-id');
        await store.getState().selectObjective(objId);
      });
    });

    const formCreateObj = document.getElementById('form-create-objective');
    if (formCreateObj) {
      formCreateObj.addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
          const title = document.getElementById('new-obj-title').value.trim();
          const targetOutcome = document.getElementById('new-obj-outcome').value.trim();
          const skillId = document.getElementById('new-obj-skill').value;
          const subskillId = document.getElementById('new-obj-subskill').value || null;
          const prereq = document.getElementById('new-obj-prereq').value;

          const created = await engines.learningEngine.createLearningObjective({
            title,
            targetOutcome,
            skillId,
            subskillId,
            prerequisites: prereq ? [prereq] : [],
          });
          store.setState({ selectedObjectiveId: created.id });
          await store.getState().refreshAll();
          showToast(`تم إنشاء الهدف التعلمي: ${created.title}`);
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    }

    const formCreateRes = document.getElementById('form-create-resource');
    if (formCreateRes) {
      formCreateRes.addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
          const title = document.getElementById('new-res-title').value.trim();
          const type = document.getElementById('new-res-type').value;
          const objectiveId = document.getElementById('new-res-objective').value;
          const reference = document.getElementById('new-res-ref').value.trim();
          const obj = store.getState().learningObjectives.find((o) => o.id === objectiveId);

          await engines.learningEngine.createResource({
            title,
            type,
            reference,
            skillId: obj?.skillId || store.getState().selectedSkillId,
            subskillId: obj?.subskillId || null,
            learningObjectives: [objectiveId],
          });
          await store.getState().refreshAll();
          showToast('تمت إضافة المصدر وربطه بالهدف التعلمي');
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    }

    const formLearnSess = document.getElementById('form-record-learning-session');
    if (formLearnSess) {
      formLearnSess.addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
          const objectiveId = store.getState().selectedObjectiveId;
          const sessionType = document.getElementById('lsess-type').value;
          const resourceId = document.getElementById('lsess-resource').value || null;
          const actualDurationMin = Number(document.getElementById('lsess-duration').value || 40);
          const confidence = Number(document.getElementById('lsess-confidence').value || 80);
          const notes = document.getElementById('lsess-notes').value.trim();

          const res = await engines.learningEngine.recordLearningSession({
            objectiveId,
            resourceId,
            sessionType,
            plannedDurationMin: actualDurationMin,
            actualDurationMin,
            confidence,
            notes,
          });
          await store.getState().refreshAll();
          showToast(`تم تسجيل الجلسة (${sessionType}) — حالة الهدف: ${res.objective.status}`);
        } catch (err) {
          showToast(`منع بواسطة القفل: ${err.message}`);
        }
      });
    }

    const formRecall = document.getElementById('form-record-recall');
    if (formRecall) {
      formRecall.addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
          const objectiveId = store.getState().selectedObjectiveId;
          const question = document.getElementById('recall-question').value.trim();
          const expectedAnswer = document.getElementById('recall-expected').value.trim();
          const userAnswer = document.getElementById('recall-user-answer').value.trim();
          const confidence = Number(document.getElementById('recall-confidence').value || 80);
          const rawCorr = document.getElementById('recall-correctness').value;
          const correctness = rawCorr !== '' ? Number(rawCorr) : undefined;

          const res = await engines.learningEngine.recordRecallAttempt({
            objectiveId,
            question,
            expectedAnswer,
            userAnswer,
            confidence,
            correctness,
          });
          await store.getState().refreshAll();
          showToast(`تم تقييم الاسترجاع (${res.recallAttempt.correctness}%)`);
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    }

    const formFeynman = document.getElementById('form-record-feynman');
    if (formFeynman) {
      formFeynman.addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
          const objectiveId = store.getState().selectedObjectiveId;
          const explanation = document.getElementById('feynman-explanation').value.trim();
          const gapsRaw = document.getElementById('feynman-gaps').value.trim();
          const identifiedGaps = gapsRaw
            ? gapsRaw.split(/[،,]/).map((s) => s.trim()).filter(Boolean)
            : [];
          const clarityScore = Number(document.getElementById('feynman-clarity').value || 90);
          const confidence = Number(document.getElementById('feynman-confidence').value || 85);

          await engines.learningEngine.recordFeynmanExplanation({
            objectiveId,
            explanation,
            identifiedGaps,
            clarityScore,
            confidence,
          });
          await store.getState().refreshAll();
          showToast('تم حفظ شرح فاينمان');
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    }

    const formCreatePrac = document.getElementById('form-create-practice-task');
    if (formCreatePrac) {
      formCreatePrac.addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
          const objectiveId = store.getState().selectedObjectiveId;
          const title = document.getElementById('prac-task-title').value.trim();
          const evidenceRequirement = document.getElementById('prac-evidence-type').value;
          const timeEstimateMin = Number(document.getElementById('prac-time-min').value || 45);

          await engines.learningEngine.createPracticeTask({
            objectiveId,
            title,
            evidenceRequirement,
            timeEstimateMin,
            date: store.getState().currentDate,
          });
          await store.getState().refreshAll();
          showToast('تم إنشاء مهمة التطبيق العملي');
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    }

    rootElement.querySelectorAll('[data-action="complete-practice-task"]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          const taskId = btn.getAttribute('data-task-id');
          await engines.learningEngine.completePracticeTask(taskId);
          await store.getState().refreshAll();
          showToast('تم إتمام التطبيق وتوثيق الدليل');
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    });

    const formLearnTest = document.getElementById('form-record-learning-test');
    if (formLearnTest) {
      formLearnTest.addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
          const objectiveId = store.getState().selectedObjectiveId;
          const testType = document.getElementById('ltest-kind').value;
          const linkedErrorId = document.getElementById('ltest-linked-error').value || null;
          const score = Number(document.getElementById('ltest-score').value);
          const accuracy = Number(document.getElementById('ltest-accuracy').value);
          const confidence = Number(document.getElementById('ltest-confidence').value);

          await engines.learningEngine.recordLearningTestAttempt({
            objectiveId,
            testType,
            linkedErrorId,
            isRetest: Boolean(linkedErrorId),
            score,
            accuracy,
            confidence,
          });
          await store.getState().refreshAll();
          showToast('تم تنفيذ اختبار الهدف التعلمي');
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    }

    const formRetReview = document.getElementById('form-record-retention-review');
    if (formRetReview) {
      formRetReview.addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
          const objectiveId = store.getState().selectedObjectiveId;
          const score = Number(document.getElementById('ret-review-score').value);
          const evidence = document.getElementById('ret-review-evidence').value.trim();

          await engines.learningEngine.recordRetentionReview({
            objectiveId,
            reviewDate: store.getState().currentDate,
            score,
            evidence,
          });
          await store.getState().refreshAll();
          showToast('تم تسجيل مراجعة الاحتفاظ');
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    }

    const formAddNote = document.getElementById('form-add-learning-note');
    if (formAddNote) {
      formAddNote.addEventListener('submit', async (e) => {
        e.preventDefault();
        const content = document.getElementById('learning-note-content').value.trim();
        if (!content) return;
        const objectiveId = store.getState().selectedObjectiveId;
        await engines.learningEngine.addNote({
          targetType: 'objective',
          targetId: objectiveId,
          skillId: store.getState().selectedSkillId,
          content,
        });
        await store.getState().refreshAll();
        showToast('تم حفظ الملاحظة');
      });
    }

    rootElement.querySelectorAll('[data-action="review-flashcard-pass"]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const fcId = btn.getAttribute('data-flashcard-id');
        await engines.learningEngine.reviewFlashcard({
          flashcardId: fcId,
          recallScore: 95,
          confidence: 90,
          reviewDate: store.getState().currentDate,
        });
        await store.getState().refreshAll();
        showToast('تم جدولة البطاقة للمراجعة القادمة');
      });
    });

    rootElement.querySelectorAll('[data-action="review-flashcard-fail"]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const fcId = btn.getAttribute('data-flashcard-id');
        await engines.learningEngine.reviewFlashcard({
          flashcardId: fcId,
          recallScore: 45,
          confidence: 70,
          reviewDate: store.getState().currentDate,
        });
        await store.getState().refreshAll();
        showToast('تم إعادة ضبط فاصل البطاقة للمراجعة غداً');
      });
    });

    rootElement.querySelectorAll('[data-select-skill-id]').forEach((card) => {
      card.addEventListener('click', async () => {
        const skillId = card.getAttribute('data-select-skill-id');
        await store.getState().selectSkill(skillId);
      });
    });

    const formRecordTraining = document.getElementById('form-record-training');
    if (formRecordTraining) {
      formRecordTraining.addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
          const skillId = store.getState().selectedSkillId;
          const subskillId = document.getElementById('train-subskill-id').value || null;
          const durationMinutes = Number(document.getElementById('train-duration-min').value || 45);
          const evidenceTitle = document.getElementById('train-evidence-title').value.trim();

          await engines.skillEngine.recordTrainingSession({
            skillId,
            subskillId,
            durationMinutes,
            evidenceTitle,
            evidenceContent: evidenceTitle,
            qualityScore: 90,
          });
          await store.getState().refreshAll();
          showToast('تم تسجيل جلسة التدريب');
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    }

    const formTestAttempt = document.getElementById('form-record-test-attempt');
    if (formTestAttempt) {
      formTestAttempt.addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
          const skillId = store.getState().selectedSkillId;
          const subskillId = document.getElementById('test-subskill-id').value || null;
          const score = Number(document.getElementById('test-score-input').value);
          const accuracy = Number(document.getElementById('test-accuracy-input').value);
          const linkedErrorId = document.getElementById('test-linked-error-id').value || null;
          const evidence = document.getElementById('test-evidence-input').value.trim();

          await engines.skillEngine.recordTestAttempt({
            skillId,
            subskillId,
            score,
            accuracy,
            linkedErrorId,
            isRetest: Boolean(linkedErrorId),
            evidence: evidence || `Test attempt (${score}% / ${accuracy}%)`,
          });
          await store.getState().refreshAll();
          showToast('تم تسجيل نتيجة الاختبار');
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    }

    rootElement.querySelectorAll('[data-action="create-remediation"]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          const errorId = btn.getAttribute('data-error-id');
          await engines.skillEngine.createRemediationPlan({ errorId });
          await store.getState().refreshAll();
          showToast('تم إنشاء الخطة العلاجية');
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    });

    rootElement.querySelectorAll('[data-action="complete-corrective-task"]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          const taskId = btn.getAttribute('data-task-id');
          await engines.skillEngine.completeCorrectiveTask(taskId);
          await store.getState().refreshAll();
          showToast('تم إتمام المهمة التصحيحية وتوثيق الدليل');
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    });

    const formMaint = document.getElementById('form-record-maintenance');
    if (formMaint) {
      formMaint.addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
          const skillId = store.getState().selectedSkillId;
          const score = Number(document.getElementById('maint-score-input').value);
          const retentionEvidence = document.getElementById('maint-evidence-input').value.trim();
          await engines.skillEngine.recordMaintenanceSession({
            skillId,
            reviewDate: store.getState().currentDate,
            score,
            retentionEvidence,
          });
          await store.getState().refreshAll();
          showToast('تم تسجيل جلسة الصيانة');
        } catch (err) {
          showToast(`خطأ: ${err.message}`);
        }
      });
    }

    const dateInput = document.getElementById('input-daily-date');
    const energyInput = document.getElementById('input-daily-energy');
    if (dateInput) {
      dateInput.addEventListener('change', async (e) => {
        await store.getState().setDateAndEnergy(e.target.value, store.getState().currentEnergy);
        showToast('تم تحديث تاريخ اليوم وحساب ميزانية الوقت');
      });
    }
    if (energyInput) {
      energyInput.addEventListener('change', async (e) => {
        await store.getState().setDateAndEnergy(store.getState().currentDate, Number(e.target.value));
        showToast(`تم تحديث الطاقة إلى ${e.target.value}/10`);
      });
    }

    const regenBtn = document.getElementById('btn-regenerate-day');
    if (regenBtn) {
      regenBtn.addEventListener('click', async () => {
        await store.getState().regenerateDayMissions();
        showToast('تم إعادة توليد وجدولة خطة اليوم التكيفية بنجاح');
      });
    }

    const addCustomForm = document.getElementById('form-add-custom-task');
    if (addCustomForm) {
      addCustomForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const title = document.getElementById('custom-task-title').value.trim();
        const category = document.getElementById('custom-task-category').value;
        const skillId = document.getElementById('custom-task-skill').value;
        const plannedDurationMin = Number(document.getElementById('custom-task-duration').value);
        if (!title) return;
        await engines.dailyOsEngine.createCustomTask({
          title,
          date: store.getState().currentDate,
          category,
          skillId,
          plannedDurationMin,
          priority: category === 'Primary' ? 1 : 2,
        });
        await store.getState().refreshAll();
        showToast('تمت إضافة المهمة المخصصة بنجاح');
      });
    }

    const btnPause = document.getElementById('btn-timer-pause');
    if (btnPause) {
      btnPause.addEventListener('click', async () => {
        await engines.timerEngine.pause(Date.now());
        await store.getState().refreshAll();
      });
    }

    const btnResume = document.getElementById('btn-timer-resume');
    if (btnResume) {
      btnResume.addEventListener('click', async () => {
        await engines.timerEngine.resume(Date.now());
        await store.getState().refreshAll();
      });
    }

    const btnFinish = document.getElementById('btn-timer-finish');
    if (btnFinish) {
      btnFinish.addEventListener('click', async () => {
        await engines.timerEngine.finish(Date.now());
        await store.getState().refreshAll();
      });
    }

    const btnCancel = document.getElementById('btn-timer-cancel');
    if (btnCancel) {
      btnCancel.addEventListener('click', async () => {
        await engines.timerEngine.cancel(Date.now());
        await store.getState().refreshAll();
      });
    }

    const btnReset = document.getElementById('btn-timer-reset');
    if (btnReset) {
      btnReset.addEventListener('click', async () => {
        await engines.timerEngine.reset();
        await store.getState().refreshAll();
      });
    }

    const perfForm = document.getElementById('form-performance-log');
    if (perfForm) {
      perfForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const taskId = document.getElementById('perf-task-id').value;
        const actualMin = Number(document.getElementById('perf-actual-min').value);
        const completionPct = Number(document.getElementById('perf-completion-pct').value);
        const energy = Number(document.getElementById('perf-energy').value);
        const difficulty = Number(document.getElementById('perf-difficulty').value);
        const confidence = Number(document.getElementById('perf-confidence').value);
        const whatLearned = document.getElementById('perf-what-learned').value;
        const mistakes = document.getElementById('perf-mistakes').value;
        const notes = document.getElementById('perf-notes').value;

        await engines.performanceEngine.recordPerformanceLog({
          taskId,
          date: store.getState().currentDate,
          actualDurationSec: actualMin * 60,
          completionPct,
          energy,
          difficulty,
          confidence,
          whatLearned,
          mistakes,
          notes,
        });
        await engines.timerEngine.reset();
        await store.getState().refreshAll();
        showToast('تم حفظ سجل الأداء');
      });
    }

    const schedForm = document.getElementById('form-schedule-config');
    if (schedForm) {
      schedForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const checkedDays = Array.from(
          schedForm.querySelectorAll('input[name="collegeDay"]:checked')
        ).map((el) => el.value);
        const collegeStart = document.getElementById('sched-college-start').value;
        const collegeEnd = document.getElementById('sched-college-end').value;
        const sleepHours = Number(document.getElementById('sched-sleep-hours').value);
        const mealsAndPrayerHours = Number(document.getElementById('sched-meals-hours').value);
        const otherCommitmentsHours = Number(document.getElementById('sched-other-hours').value);
        const deepWorkCapacityHours = Number(document.getElementById('sched-deep-work-hours').value);

        await engines.timeEngine.updateScheduleConfig({
          collegeDays: checkedDays,
          collegeStart,
          collegeEnd,
          sleepHours,
          mealsAndPrayerHours,
          otherCommitmentsHours,
          deepWorkCapacityHours,
        });
        await store.getState().refreshAll();
        showToast('تم حفظ جدول الكلية وإعادة حساب ميزانية الوقت');
      });
    }

    const btnExport = document.getElementById('btn-export-backup');
    if (btnExport) {
      btnExport.addEventListener('click', async () => {
        const bundle = await engines.backupEngine.exportBackup();
        const area = document.getElementById('backup-json-textarea');
        if (area) area.value = JSON.stringify(bundle, null, 2);
        showToast(`تم توليد النسخة الاحتياطية (Checksum: ${bundle.checksum})`);
      });
    }

    const btnDownloadBackup = document.getElementById('btn-download-backup');
    if (btnDownloadBackup) {
      btnDownloadBackup.addEventListener('click', async () => {
        const bundle = await engines.backupEngine.exportBackup();
        const jsonStr = JSON.stringify(bundle, null, 2);
        const area = document.getElementById('backup-json-textarea');
        if (area) area.value = jsonStr;
        if (typeof Blob !== 'undefined' && typeof URL !== 'undefined' && URL.createObjectURL) {
          const blob = new Blob([jsonStr], { type: 'application/json' });
          const dlUrl = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = dlUrl;
          a.download = `white_room_os_backup_v${bundle.schemaVersion}_${store.getState().currentDate}.json`;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          setTimeout(() => URL.revokeObjectURL(dlUrl), 1500);
        }
        showToast(`تم تحميل ملف النسخة الاحتياطية (.JSON • Checksum: ${bundle.checksum})`);
      });
    }

    const btnRestore = document.getElementById('btn-restore-backup');
    if (btnRestore) {
      btnRestore.addEventListener('click', async () => {
        const area = document.getElementById('backup-json-textarea');
        if (!area || !area.value.trim()) return;
        try {
          const parsed = JSON.parse(area.value);
          const res = await engines.backupEngine.restoreBackup(parsed);
          await store.getState().refreshAll();
          showToast(`تمت استعادة ${res.restoredCount} سجل بنجاح`);
        } catch (err) {
          showToast(`خطأ في الاستعادة: ${err.message}`);
        }
      });
    }

    const filePicker = document.getElementById('input-backup-file-picker');
    if (filePicker) {
      filePicker.addEventListener('change', async (e) => {
        const file = e.target.files && e.target.files[0];
        if (!file) return;
        try {
          const text = await file.text();
          const area = document.getElementById('backup-json-textarea');
          if (area) area.value = text;
          const parsed = JSON.parse(text);
          const res = await engines.backupEngine.restoreBackup(parsed);
          await store.getState().refreshAll();
          showToast(`📂 تم استيراد واستعادة الملف (${file.name}: ${res.restoredCount} سجل) بنجاح`);
        } catch (err) {
          showToast(`خطأ في ملف النسخة الاحتياطية: ${err.message}`);
        }
      });
    }
  }

  store.subscribe(() => {
    renderApp();
  });

  setInterval(() => {
    const { timerState } = store.getState();
    if (!timerState || (timerState.status !== 'running' && timerState.status !== 'paused')) return;
    const live = engines.timerEngine.computeLiveMetrics(timerState, Date.now());
    const mainDisp = document.getElementById('timer-main-display');
    const remDisp = document.getElementById('timer-remaining-display');
    const pauseDisp = document.getElementById('timer-pause-display');
    const progBar = document.getElementById('timer-progress-bar');
    const miniClock = document.getElementById('wr-mini-timer-clock');

    if (mainDisp) mainDisp.textContent = formatSecondsHHMMSS(live.elapsedActiveSec);
    if (remDisp) remDisp.textContent = formatSecondsHHMMSS(live.remainingSec);
    if (pauseDisp) pauseDisp.textContent = formatSecondsHHMMSS(live.elapsedPauseSec);
    if (progBar) progBar.style.width = `${live.progressPct}%`;
    if (miniClock) miniClock.textContent = formatSecondsHHMMSS(live.elapsedActiveSec);
  }, 500);

  renderApp();
  return system;
}
