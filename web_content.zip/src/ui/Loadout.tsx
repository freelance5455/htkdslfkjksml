import { useState } from 'react';
import { Screen, Panel, MenuButton, StatBar, useStore, LockBadge } from './common';
import { WeaponPreview } from './WeaponPreview';
import {
  WEAPONS, CATEGORY_NAMES, SLOTS, SLOT_NAMES, SKINS, attachmentsFor, computeStats, statBars, getWeapon, sanitizeAttachments,
  type AttachConfig, type Category, type WeaponDef,
} from '../game/data/weapons';
import { store, type LoadoutSlot } from '../game/save';
import { audio } from '../game/audio';
import { cn } from '../utils/cn';

const CATS: Category[] = ['AR', 'SMG', 'SR', 'SG', 'LMG', 'MR', 'PISTOL'];
export const isSecondaryOk = (w: WeaponDef) => w.category === 'PISTOL' || w.category === 'SG';
export const isPrimaryOk = (w: WeaponDef) => w.category !== 'PISTOL';

export function StatsCompare({ weapon, attachments }: { weapon: string; attachments: AttachConfig }) {
  const def = getWeapon(weapon);
  const base = statBars(computeStats(def, {})); const fin = statBars(computeStats(def, attachments)); const fs = computeStats(def, attachments);
  return (
    <div className="space-y-1">
      {(Object.keys(base) as (keyof typeof base)[]).map(k => <StatBar key={k} label={k} value={fin[k]} base={base[k]} />)}
      <div className="grid grid-cols-4 gap-1 pt-2 text-[10px] text-white/60">
        <div>DMG <b className="text-white">{Math.round(fs.damage)}{fs.pellets > 1 ? `×${fs.pellets}` : ''}</b></div>
        <div>RPM <b className="text-white">{fs.rpm}</b></div>
        <div>MAG <b className="text-white">{fs.mag}</b></div>
        <div>RELOAD <b className="text-white">{fs.reload.toFixed(1)}s</b></div>
        <div>RANGE <b className="text-white">{Math.round(fs.range)}m</b></div>
        <div>ADS <b className="text-white">{Math.round(fs.adsTime * 1000)}ms</b></div>
        <div>ZOOM <b className="text-white">{fs.zoom.toFixed(1)}x</b></div>
        <div>MODE <b className="text-white">{fs.mode.toUpperCase()}</b></div>
      </div>
      {fs.suppressed && <div className="text-[10px] text-sky-300 tracking-widest">● SUPPRESSED — hidden from enemy minimap & reduced hearing range</div>}
    </div>
  );
}

export function AttachmentEditor({ weapon, attachments, skin, onChange, showSkins = true }: { weapon: string; attachments: AttachConfig; skin: string; onChange: (a: AttachConfig, skin: string) => void; showSkins?: boolean }) {
  const lvl = store.level; const def = getWeapon(weapon);
  return (
    <div className="space-y-2">
      {SLOTS.map(slot => {
        const opts = attachmentsFor(def, slot); if (!opts.length) return null;
        return (
          <div key={slot}>
            <div className="text-[9px] tracking-[0.3em] text-white/45 mb-1">{SLOT_NAMES[slot].toUpperCase()}</div>
            <div className="flex flex-wrap gap-1">
              <button onClick={() => { audio.ui('select'); const a = { ...attachments }; delete a[slot]; onChange(a, skin); }} className={cn('px-2 py-1 text-[10px] font-bold tracking-wider', !attachments[slot] ? 'bg-amber-op text-black' : 'bg-white/10 hover:bg-white/20')}>NONE</button>
              {opts.map(o => {
                const locked = lvl < o.unlock;
                return <button key={o.id} disabled={locked} title={o.desc} onClick={() => { audio.ui('select'); onChange(sanitizeAttachments(def, { ...attachments, [slot]: o.id }), skin); }}
                  className={cn('px-2 py-1 text-[10px] font-bold tracking-wider', attachments[slot] === o.id ? 'bg-amber-op text-black' : 'bg-white/10 hover:bg-white/20', locked && 'opacity-40 cursor-not-allowed')}>
                  {o.name.toUpperCase()}{locked ? ` 🔒${o.unlock}` : ''}
                </button>;
              })}
            </div>
          </div>
        );
      })}
      {showSkins && (
        <div>
          <div className="text-[9px] tracking-[0.3em] text-white/45 mb-1">SKIN (COSMETIC)</div>
          <div className="flex flex-wrap gap-1">
            {SKINS.map(k => {
              const locked = lvl < k.unlock;
              return <button key={k.id} disabled={locked} onClick={() => { audio.ui('select'); onChange(attachments, k.id); }} title={k.name + (locked ? ` (level ${k.unlock})` : '')}
                className={cn('w-8 h-8 border-2 relative', skin === k.id ? 'border-amber-op' : 'border-white/15', locked && 'opacity-35')}
                style={{ background: k.color === null ? 'linear-gradient(135deg,#2b2f33,#5a6b4a)' : '#' + k.color.toString(16).padStart(6, '0') }}>
                {locked && <span className="absolute inset-0 flex items-center justify-center text-[9px]">🔒</span>}
              </button>;
            })}
          </div>
        </div>
      )}
    </div>
  );
}

function WeaponList({ filter, selected, onPick }: { filter: (w: WeaponDef) => boolean; selected: string; onPick: (id: string) => void }) {
  const lvl = store.level;
  return (
    <div className="space-y-2">
      {CATS.map(c => {
        const list = WEAPONS.filter(w => w.category === c && filter(w)); if (!list.length) return null;
        return (
          <div key={c}>
            <div className="text-[9px] tracking-[0.3em] text-amber-op/80 mb-1">{CATEGORY_NAMES[c].toUpperCase()}</div>
            <div className="grid grid-cols-2 gap-1">
              {list.map(w => {
                const locked = lvl < w.unlock;
                return <button key={w.id} disabled={locked} onClick={() => { audio.ui('select'); onPick(w.id); }}
                  className={cn('text-left px-2 py-1.5 text-[11px] font-bold tracking-wider flex items-center justify-between gap-1', selected === w.id ? 'bg-amber-op text-black' : 'bg-white/[0.07] hover:bg-white/15', locked && 'opacity-45 cursor-not-allowed')}>
                  <span className="truncate">{w.name}</span>{locked && <LockBadge level={w.unlock} />}
                </button>;
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ------------------------------------------------------------ LOADOUT SCREEN
export function LoadoutScreen({ onBack, initialSlot = 'primary' }: { onBack: () => void; initialSlot?: 'primary' | 'secondary' }) {
  const s = useStore(); const p = s.profile;
  const [idx, setIdx] = useState(p.activeLoadout);
  const [slot, setSlot] = useState<'primary' | 'secondary'>(initialSlot);
  const lo = p.loadouts[idx]; const cur = lo[slot];
  const update = (fn: (ls: LoadoutSlot) => LoadoutSlot) => store.setProfile(pp => { pp.loadouts[idx][slot] = fn(pp.loadouts[idx][slot]); return pp; });
  return (
    <Screen title="LOADOUT" subtitle="CHANGES SAVE AUTOMATICALLY" onBack={onBack} wide
      right={<div className="flex gap-1">{p.loadouts.map((l, i) => <button key={i} onClick={() => { audio.ui('select'); setIdx(i); }} className={cn('px-2 sm:px-3 py-1.5 text-[10px] sm:text-xs font-bold tracking-widest clip-corner-sm', i === idx ? 'bg-amber-op text-black' : 'bg-white/10')}>{l.name}{p.activeLoadout === i ? ' ★' : ''}</button>)}</div>}>
      <div className="grid lg:grid-cols-[300px_1fr_340px] gap-3">
        <Panel className="p-3">
          <div className="flex items-center gap-2 mb-2">
            <input type="text" maxLength={12} value={lo.name} onChange={e => { const v = e.target.value.toUpperCase(); store.setProfile(pp => { pp.loadouts[idx].name = v || 'LOADOUT'; return pp; }); }} className="flex-1 min-w-0 bg-black/60 border border-white/15 px-2 py-1 text-xs tracking-widest outline-none focus:border-amber-op" />
            {p.activeLoadout === idx ? <span className="text-[10px] font-bold text-amber-op tracking-widest">ACTIVE ★</span> : <MenuButton small primary onClick={() => store.setProfile(pp => { pp.activeLoadout = idx; return pp; })}>Set active</MenuButton>}
          </div>
          {(['primary', 'secondary'] as const).map(sl => (
            <button key={sl} onClick={() => { audio.ui('select'); setSlot(sl); }} className={cn('w-full text-left p-2 mb-1 border', slot === sl ? 'border-amber-op bg-amber-op/10' : 'border-white/10 bg-white/5')}>
              <div className="text-[9px] tracking-[0.3em] text-white/50">{sl.toUpperCase()}</div>
              <div className="font-black tracking-widest text-sm">{getWeapon(lo[sl].weapon).name}</div>
              <div className="text-[10px] text-white/45">{Object.keys(lo[sl].attachments).length} attachments</div>
            </button>
          ))}
          <div className="mt-2 max-h-[40vh] lg:max-h-[55vh] scroll-y pr-1">
            <WeaponList filter={slot === 'primary' ? isPrimaryOk : isSecondaryOk} selected={cur.weapon} onPick={id => update(() => ({ weapon: id, attachments: {}, skin: cur.skin }))} />
          </div>
        </Panel>
        <Panel className="p-3 flex flex-col">
          <div className="text-[10px] tracking-[0.3em] text-amber-op">{getWeapon(cur.weapon).category} · {CATEGORY_NAMES[getWeapon(cur.weapon).category].toUpperCase()}</div>
          <div className="text-xl sm:text-2xl font-black tracking-[0.15em]">{getWeapon(cur.weapon).name}</div>
          <div className="text-xs text-white/55">{getWeapon(cur.weapon).desc}</div>
          <WeaponPreview weapon={cur.weapon} attachments={cur.attachments} skin={cur.skin} className="h-40 sm:h-56 w-full" />
          <AttachmentEditor weapon={cur.weapon} attachments={cur.attachments} skin={cur.skin} onChange={(a, sk) => update(x => ({ ...x, attachments: a, skin: sk }))} />
        </Panel>
        <Panel title="STATISTICS · BASE → CUSTOMISED" className="p-3 pt-1">
          <StatsCompare weapon={cur.weapon} attachments={cur.attachments} />
        </Panel>
      </div>
    </Screen>
  );
}

// ------------------------------------------------------------ ARMORY
export function Armory({ onBack, onCustomize, onTest }: { onBack: () => void; onCustomize: (slot: 'primary' | 'secondary') => void; onTest: (id: string) => void }) {
  const s = useStore(); const lvl = s.level;
  const [cat, setCat] = useState<Category | 'ALL'>('ALL');
  const [sel, setSel] = useState('ar01');
  const def = getWeapon(sel); const locked = lvl < def.unlock;
  const equip = (slot: 'primary' | 'secondary') => { audio.pickup(); store.setProfile(p => { p.loadouts[p.activeLoadout][slot] = { weapon: sel, attachments: {}, skin: 'default' }; return p; }); };
  const list = WEAPONS.filter(w => cat === 'ALL' || w.category === cat);
  return (
    <Screen title="WEAPON ARMORY" subtitle={`${WEAPONS.length} WEAPONS · ${WEAPONS.filter(w => w.unlock <= lvl).length} UNLOCKED`} onBack={onBack} wide>
      <div className="flex gap-1 flex-wrap mb-2">
        {(['ALL', ...CATS] as const).map(c => <button key={c} onClick={() => { audio.ui('select'); setCat(c); }} className={cn('px-2.5 py-1 text-[10px] font-bold tracking-widest clip-corner-sm', cat === c ? 'bg-amber-op text-black' : 'bg-white/10')}>{c === 'ALL' ? 'ALL' : CATEGORY_NAMES[c].toUpperCase()}</button>)}
      </div>
      <div className="grid lg:grid-cols-[1fr_420px] gap-3">
        <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-1.5 content-start">
          {list.map(w => {
            const lk = lvl < w.unlock; const bars = statBars(computeStats(w));
            return (
              <button key={w.id} onClick={() => { audio.ui('select'); setSel(w.id); }} className={cn('text-left p-2 clip-corner-sm border transition-all', sel === w.id ? 'border-amber-op bg-amber-op/10' : 'border-white/10 bg-black/60 hover:border-white/35', lk && 'opacity-60')}>
                <div className="flex justify-between items-start"><span className="text-[9px] tracking-[0.25em] text-amber-op/80">{w.category}</span>{lk && <LockBadge level={w.unlock} />}</div>
                <div className="text-xs sm:text-sm font-black tracking-wider">{w.name}</div>
                <div className="mt-1 space-y-0.5">{(['Damage', 'Fire Rate', 'Range'] as const).map(k => <div key={k} className="h-1 bg-white/10"><div className="h-full bg-white/70" style={{ width: `${bars[k]}%` }} /></div>)}</div>
              </button>
            );
          })}
        </div>
        <Panel className="p-3">
          <div className="text-[10px] tracking-[0.3em] text-amber-op">{CATEGORY_NAMES[def.category].toUpperCase()} · {def.mode.toUpperCase()}</div>
          <div className="text-2xl font-black tracking-[0.15em]">{def.name}</div>
          <div className="text-xs text-white/55">{def.desc}</div>
          <WeaponPreview weapon={sel} attachments={{}} skin="default" className="h-40 sm:h-48 w-full" />
          <StatsCompare weapon={sel} attachments={{}} />
          {locked ? <div className="mt-3 text-xs text-white/60">Unlocks at <b className="text-amber-op">level {def.unlock}</b>. Earn XP by playing matches and completing missions.</div> : (
            <div className="flex flex-wrap gap-1.5 mt-3">
              {isPrimaryOk(def) && <MenuButton small primary onClick={() => equip('primary')}>Equip primary</MenuButton>}
              {isSecondaryOk(def) && <MenuButton small primary onClick={() => equip('secondary')}>Equip secondary</MenuButton>}
              <MenuButton small onClick={() => { equip(isPrimaryOk(def) ? 'primary' : 'secondary'); onCustomize(isPrimaryOk(def) ? 'primary' : 'secondary'); }}>Customize</MenuButton>
              <MenuButton small onClick={() => onTest(sel)}>Test in range</MenuButton>
            </div>
          )}
        </Panel>
      </div>
    </Screen>
  );
}

// ------------------------------------------------------------ IN-RANGE ARMORY (overlay during practice)
export function RangeArmory({ onEquip, onClose }: { onEquip: (slot: number, id: string, att: AttachConfig, skin: string) => void; onClose: () => void }) {
  useStore();
  const [sel, setSel] = useState('ar01'); const [att, setAtt] = useState<AttachConfig>({}); const [skin, setSkin] = useState('default');
  return (
    <div className="absolute inset-0 z-40 bg-black/80 backdrop-blur-sm flex items-center justify-center p-2 sm:p-6 anim-fade">
      <Panel className="w-full max-w-5xl max-h-full flex flex-col p-3">
        <div className="flex items-center mb-2"><div className="text-lg font-black tracking-[0.2em]">RANGE ARMORY</div><span className="ml-3 text-[10px] text-white/40">All unlocked weapons · unlimited ammo</span><button onClick={onClose} className="ml-auto px-3 py-1 bg-white/10 hover:bg-amber-op hover:text-black text-xs font-bold tracking-widest">CLOSE [B]</button></div>
        <div className="grid md:grid-cols-[1fr_1fr] gap-3 min-h-0 flex-1 scroll-y">
          <div className="scroll-y max-h-[70vh] pr-1"><WeaponList filter={() => true} selected={sel} onPick={id => { setSel(id); setAtt({}); }} /></div>
          <div className="space-y-2">
            <div className="text-xl font-black tracking-widest">{getWeapon(sel).name}</div>
            <AttachmentEditor weapon={sel} attachments={att} skin={skin} onChange={(a, k) => { setAtt(a); setSkin(k); }} />
            <StatsCompare weapon={sel} attachments={att} />
            <div className="flex gap-2 pt-1">
              <MenuButton primary small onClick={() => onEquip(0, sel, att, skin)}>Equip slot 1</MenuButton>
              <MenuButton primary small onClick={() => onEquip(1, sel, att, skin)}>Equip slot 2</MenuButton>
            </div>
          </div>
        </div>
      </Panel>
    </div>
  );
}
