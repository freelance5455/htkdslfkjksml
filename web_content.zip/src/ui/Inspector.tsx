import React, { useState } from 'react';
import {
  Sliders,
  Box,
  Eye,
  Lock,
  Flame,
  Volume2,
  Cpu,
  FileCode,
  Zap,
  Sparkles,
  Layers,
  Activity,
  Play,
} from 'lucide-react';
import { EngineObject, Vector3D } from '../types';
import { audioSystem } from '../audio/audioManager';

interface InspectorProps {
  selectedObject: EngineObject | null;
  onUpdateTransform: (transform: EngineObject['transform']) => void;
  onUpdateMaterial: (material: EngineObject['material']) => void;
  onUpdateLighting: (lighting: NonNullable<EngineObject['lighting']>) => void;
  onUpdatePhysics: (physics: NonNullable<EngineObject['physics']>) => void;
  onUpdateAI: (ai: NonNullable<EngineObject['ai']>) => void;
  onUpdateAudio: (audio: NonNullable<EngineObject['audio']>) => void;
  onUpdateName: (name: string) => void;
}

export const Inspector: React.FC<InspectorProps> = ({
  selectedObject,
  onUpdateTransform,
  onUpdateMaterial,
  onUpdateLighting,
  onUpdatePhysics,
  onUpdateAI,
  onUpdateAudio,
  onUpdateName,
}) => {
  if (!selectedObject) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-slate-500 text-xs p-6 text-center select-none">
        <Sliders className="w-8 h-8 mb-2 text-slate-600 stroke-[1.5]" />
        <div className="font-semibold text-slate-400">No Object Selected</div>
        <p className="text-[11px] mt-1 text-slate-500 max-w-[200px]">
          Click on any object in the 3D Viewport or Scene Graph to inspect and edit its properties.
        </p>
      </div>
    );
  }

  const { transform, material, lighting, physics, ai, audio } = selectedObject;

  const handleVecChange = (
    field: 'position' | 'rotation' | 'scale',
    axis: 'x' | 'y' | 'z',
    val: number
  ) => {
    const updated = {
      ...transform,
      [field]: {
        ...transform[field],
        [axis]: isNaN(val) ? 0 : val,
      },
    };
    onUpdateTransform(updated);
  };

  return (
    <div className="flex flex-col h-full bg-[#11161f] text-slate-300 text-xs overflow-y-auto divide-y divide-[#21262d] select-none">
      {/* Object Header */}
      <div className="p-3 bg-[#161b22] flex items-center justify-between">
        <div className="flex items-center space-x-2 flex-1 min-w-0 pr-2">
          <Box className="w-4 h-4 text-cyan-400 shrink-0" />
          <input
            type="text"
            value={selectedObject.name}
            onChange={(e) => onUpdateName(e.target.value)}
            className="bg-[#0d1117] border border-[#30363d] rounded px-2 py-0.5 text-xs text-white font-semibold focus:outline-none focus:border-cyan-500 w-full"
          />
        </div>
        <span className="px-1.5 py-0.5 text-[9px] bg-cyan-950 text-cyan-400 rounded border border-cyan-800 font-mono">
          {selectedObject.type}
        </span>
      </div>

      {/* TRANSFORM SECTION */}
      <div className="p-3 space-y-2.5">
        <div className="flex items-center justify-between font-bold text-[11px] text-slate-200 uppercase tracking-wider">
          <span className="flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-cyan-400" /> Transform
          </span>
        </div>

        {/* Position */}
        <div className="space-y-1">
          <div className="text-[10px] text-slate-400 font-medium">Position</div>
          <div className="grid grid-cols-3 gap-1 font-mono text-[11px]">
            <div className="flex items-center bg-[#0d1117] border border-[#30363d] rounded px-1.5 py-1">
              <span className="text-rose-500 font-bold mr-1 text-[10px]">X</span>
              <input
                type="number"
                step="0.5"
                value={transform.position.x}
                onChange={(e) => handleVecChange('position', 'x', parseFloat(e.target.value))}
                className="w-full bg-transparent text-slate-200 focus:outline-none"
              />
            </div>
            <div className="flex items-center bg-[#0d1117] border border-[#30363d] rounded px-1.5 py-1">
              <span className="text-emerald-500 font-bold mr-1 text-[10px]">Y</span>
              <input
                type="number"
                step="0.5"
                value={transform.position.y}
                onChange={(e) => handleVecChange('position', 'y', parseFloat(e.target.value))}
                className="w-full bg-transparent text-slate-200 focus:outline-none"
              />
            </div>
            <div className="flex items-center bg-[#0d1117] border border-[#30363d] rounded px-1.5 py-1">
              <span className="text-sky-500 font-bold mr-1 text-[10px]">Z</span>
              <input
                type="number"
                step="0.5"
                value={transform.position.z}
                onChange={(e) => handleVecChange('position', 'z', parseFloat(e.target.value))}
                className="w-full bg-transparent text-slate-200 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Rotation */}
        <div className="space-y-1">
          <div className="text-[10px] text-slate-400 font-medium">Rotation (Deg)</div>
          <div className="grid grid-cols-3 gap-1 font-mono text-[11px]">
            <div className="flex items-center bg-[#0d1117] border border-[#30363d] rounded px-1.5 py-1">
              <span className="text-rose-500 font-bold mr-1 text-[10px]">X</span>
              <input
                type="number"
                step="5"
                value={transform.rotation.x}
                onChange={(e) => handleVecChange('rotation', 'x', parseFloat(e.target.value))}
                className="w-full bg-transparent text-slate-200 focus:outline-none"
              />
            </div>
            <div className="flex items-center bg-[#0d1117] border border-[#30363d] rounded px-1.5 py-1">
              <span className="text-emerald-500 font-bold mr-1 text-[10px]">Y</span>
              <input
                type="number"
                step="5"
                value={transform.rotation.y}
                onChange={(e) => handleVecChange('rotation', 'y', parseFloat(e.target.value))}
                className="w-full bg-transparent text-slate-200 focus:outline-none"
              />
            </div>
            <div className="flex items-center bg-[#0d1117] border border-[#30363d] rounded px-1.5 py-1">
              <span className="text-sky-500 font-bold mr-1 text-[10px]">Z</span>
              <input
                type="number"
                step="5"
                value={transform.rotation.z}
                onChange={(e) => handleVecChange('rotation', 'z', parseFloat(e.target.value))}
                className="w-full bg-transparent text-slate-200 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Scale */}
        <div className="space-y-1">
          <div className="text-[10px] text-slate-400 font-medium">Scale</div>
          <div className="grid grid-cols-3 gap-1 font-mono text-[11px]">
            <div className="flex items-center bg-[#0d1117] border border-[#30363d] rounded px-1.5 py-1">
              <span className="text-rose-500 font-bold mr-1 text-[10px]">X</span>
              <input
                type="number"
                step="0.1"
                value={transform.scale.x}
                onChange={(e) => handleVecChange('scale', 'x', parseFloat(e.target.value))}
                className="w-full bg-transparent text-slate-200 focus:outline-none"
              />
            </div>
            <div className="flex items-center bg-[#0d1117] border border-[#30363d] rounded px-1.5 py-1">
              <span className="text-emerald-500 font-bold mr-1 text-[10px]">Y</span>
              <input
                type="number"
                step="0.1"
                value={transform.scale.y}
                onChange={(e) => handleVecChange('scale', 'y', parseFloat(e.target.value))}
                className="w-full bg-transparent text-slate-200 focus:outline-none"
              />
            </div>
            <div className="flex items-center bg-[#0d1117] border border-[#30363d] rounded px-1.5 py-1">
              <span className="text-sky-500 font-bold mr-1 text-[10px]">Z</span>
              <input
                type="number"
                step="0.1"
                value={transform.scale.z}
                onChange={(e) => handleVecChange('scale', 'z', parseFloat(e.target.value))}
                className="w-full bg-transparent text-slate-200 focus:outline-none"
              />
            </div>
          </div>
        </div>
      </div>

      {/* MATERIAL & PBR RENDERER */}
      <div className="p-3 space-y-3">
        <div className="flex items-center justify-between font-bold text-[11px] text-slate-200 uppercase tracking-wider">
          <span className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" /> PBR Material
          </span>
          <span className="text-[10px] text-slate-400 font-normal font-sans truncate max-w-[100px]">
            {material.name}
          </span>
        </div>

        {/* Base Color Picker */}
        <div className="flex items-center justify-between">
          <span className="text-[11px] text-slate-300">Albedo Color</span>
          <div className="flex items-center space-x-2">
            <span className="font-mono text-[10px] text-slate-400">{material.baseColor}</span>
            <input
              type="color"
              value={material.baseColor}
              onChange={(e) => onUpdateMaterial({ ...material, baseColor: e.target.value })}
              className="w-7 h-7 rounded border border-[#30363d] bg-transparent cursor-pointer p-0"
            />
          </div>
        </div>

        {/* Metallic Slider */}
        <div className="space-y-1">
          <div className="flex justify-between text-[10px]">
            <span className="text-slate-400">Metallic</span>
            <span className="font-mono text-cyan-400">{material.metallic.toFixed(2)}</span>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={material.metallic}
            onChange={(e) => onUpdateMaterial({ ...material, metallic: parseFloat(e.target.value) })}
            className="w-full accent-cyan-500 cursor-pointer"
          />
        </div>

        {/* Roughness Slider */}
        <div className="space-y-1">
          <div className="flex justify-between text-[10px]">
            <span className="text-slate-400">Roughness</span>
            <span className="font-mono text-cyan-400">{material.roughness.toFixed(2)}</span>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={material.roughness}
            onChange={(e) => onUpdateMaterial({ ...material, roughness: parseFloat(e.target.value) })}
            className="w-full accent-cyan-500 cursor-pointer"
          />
        </div>

        {/* Emissive Color & Intensity */}
        <div className="space-y-1">
          <div className="flex justify-between text-[10px]">
            <span className="text-slate-400">Emissive Glow</span>
            <span className="font-mono text-amber-400">{material.emissiveIntensity.toFixed(1)}</span>
          </div>
          <div className="flex items-center space-x-2">
            <input
              type="color"
              value={material.emissive || '#000000'}
              onChange={(e) => onUpdateMaterial({ ...material, emissive: e.target.value })}
              className="w-6 h-6 rounded border border-[#30363d] bg-transparent cursor-pointer p-0"
            />
            <input
              type="range"
              min="0"
              max="3"
              step="0.1"
              value={material.emissiveIntensity}
              onChange={(e) => onUpdateMaterial({ ...material, emissiveIntensity: parseFloat(e.target.value) })}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>
        </div>

        {/* Opacity */}
        <div className="space-y-1">
          <div className="flex justify-between text-[10px]">
            <span className="text-slate-400">Opacity</span>
            <span className="font-mono text-cyan-400">{material.opacity.toFixed(2)}</span>
          </div>
          <input
            type="range"
            min="0.1"
            max="1"
            step="0.05"
            value={material.opacity}
            onChange={(e) => onUpdateMaterial({ ...material, opacity: parseFloat(e.target.value) })}
            className="w-full accent-cyan-500 cursor-pointer"
          />
        </div>

        {/* Wireframe toggle */}
        <label className="flex items-center space-x-2 text-[11px] text-slate-300 cursor-pointer">
          <input
            type="checkbox"
            checked={material.wireframe}
            onChange={(e) => onUpdateMaterial({ ...material, wireframe: e.target.checked })}
            className="rounded accent-cyan-500"
          />
          <span>Render Wireframe</span>
        </label>
      </div>

      {/* PHYSICS COMPONENT */}
      <div className="p-3 space-y-2.5">
        <div className="flex items-center justify-between font-bold text-[11px] text-slate-200 uppercase tracking-wider">
          <span className="flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-emerald-400" /> Physics & Collider
          </span>
          <input
            type="checkbox"
            checked={physics?.enabled ?? true}
            onChange={(e) =>
              onUpdatePhysics({
                enabled: e.target.checked,
                type: physics?.type || 'dynamic',
                mass: physics?.mass ?? 10,
                friction: physics?.friction ?? 0.6,
                bounciness: physics?.bounciness ?? 0.2,
                useGravity: physics?.useGravity ?? true,
                colliderType: physics?.colliderType || 'box',
              })
            }
            className="rounded accent-emerald-500"
          />
        </div>

        <div className="grid grid-cols-2 gap-2 text-[10px]">
          <div>
            <span className="text-slate-400">Body Type</span>
            <select
              value={physics?.type || 'dynamic'}
              onChange={(e) => onUpdatePhysics({ ...physics!, type: e.target.value as any })}
              className="w-full bg-[#0d1117] border border-[#30363d] rounded p-1 text-slate-200 focus:outline-none"
            >
              <option value="dynamic">Dynamic</option>
              <option value="static">Static</option>
              <option value="kinematic">Kinematic</option>
            </select>
          </div>
          <div>
            <span className="text-slate-400">Collider</span>
            <select
              value={physics?.colliderType || 'box'}
              onChange={(e) => onUpdatePhysics({ ...physics!, colliderType: e.target.value as any })}
              className="w-full bg-[#0d1117] border border-[#30363d] rounded p-1 text-slate-200 focus:outline-none"
            >
              <option value="box">Box</option>
              <option value="sphere">Sphere</option>
              <option value="capsule">Capsule</option>
              <option value="mesh">Convex Mesh</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 text-[10px]">
          <div>
            <span className="text-slate-400">Mass (kg)</span>
            <input
              type="number"
              value={physics?.mass ?? 10}
              onChange={(e) => onUpdatePhysics({ ...physics!, mass: parseFloat(e.target.value) })}
              className="w-full bg-[#0d1117] border border-[#30363d] rounded p-1 text-slate-200"
            />
          </div>
          <div>
            <span className="text-slate-400">Bounciness</span>
            <input
              type="number"
              step="0.05"
              min="0"
              max="1"
              value={physics?.bounciness ?? 0.2}
              onChange={(e) => onUpdatePhysics({ ...physics!, bounciness: parseFloat(e.target.value) })}
              className="w-full bg-[#0d1117] border border-[#30363d] rounded p-1 text-slate-200"
            />
          </div>
        </div>
      </div>

      {/* LIGHTING COMPONENT (if light) */}
      {lighting && (
        <div className="p-3 space-y-2.5">
          <div className="flex items-center justify-between font-bold text-[11px] text-slate-200 uppercase tracking-wider">
            <span className="flex items-center gap-1.5">
              <Flame className="w-3.5 h-3.5 text-amber-400" /> Light Emission
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-slate-400">Light Tint</span>
            <input
              type="color"
              value={lighting.color}
              onChange={(e) => onUpdateLighting({ ...lighting, color: e.target.value })}
              className="w-6 h-6 rounded border border-[#30363d] bg-transparent cursor-pointer"
            />
          </div>
          <div className="space-y-1">
            <div className="flex justify-between text-[10px]">
              <span className="text-slate-400">Intensity</span>
              <span className="font-mono text-amber-400">{lighting.intensity.toFixed(1)}</span>
            </div>
            <input
              type="range"
              min="0.1"
              max="10"
              step="0.2"
              value={lighting.intensity}
              onChange={(e) => onUpdateLighting({ ...lighting, intensity: parseFloat(e.target.value) })}
              className="w-full accent-amber-500"
            />
          </div>
          <label className="flex items-center space-x-2 text-[10px] text-slate-300">
            <input
              type="checkbox"
              checked={lighting.castShadow}
              onChange={(e) => onUpdateLighting({ ...lighting, castShadow: e.target.checked })}
              className="rounded accent-amber-500"
            />
            <span>Cast Real-Time Shadow</span>
          </label>
        </div>
      )}

      {/* AUDIO COMPONENT */}
      {audio && (
        <div className="p-3 space-y-2.5">
          <div className="flex items-center justify-between font-bold text-[11px] text-slate-200 uppercase tracking-wider">
            <span className="flex items-center gap-1.5">
              <Volume2 className="w-3.5 h-3.5 text-cyan-400" /> Audio Source
            </span>
            <button
              onClick={() => audioSystem.playSound(audio.soundType, { pitch: audio.pitch, volume: audio.volume })}
              className="bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-800 px-2 py-0.5 rounded text-[10px] flex items-center gap-1"
            >
              <Play className="w-3 h-3 fill-current" /> Test
            </button>
          </div>
          <div className="text-[10px] text-slate-400">
            Clip: <span className="text-slate-200 font-semibold">{audio.clipName}</span>
          </div>
          <div className="space-y-1">
            <div className="flex justify-between text-[10px]">
              <span className="text-slate-400">Spatial Volume</span>
              <span className="font-mono text-cyan-400">{(audio.volume * 100).toFixed(0)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={audio.volume}
              onChange={(e) => onUpdateAudio({ ...audio, volume: parseFloat(e.target.value) })}
              className="w-full accent-cyan-500"
            />
          </div>
        </div>
      )}

      {/* AI COMPONENT */}
      {ai && (
        <div className="p-3 space-y-2.5">
          <div className="flex items-center justify-between font-bold text-[11px] text-slate-200 uppercase tracking-wider">
            <span className="flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-violet-400" /> AI Behavior
            </span>
            <span className="text-[9px] bg-violet-950 text-violet-300 border border-violet-800 px-1.5 py-0.2 rounded font-mono">
              {ai.state}
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2 text-[10px]">
            <div>
              <span className="text-slate-400">AI Pattern</span>
              <select
                value={ai.type}
                onChange={(e) => onUpdateAI({ ...ai, type: e.target.value as any })}
                className="w-full bg-[#0d1117] border border-[#30363d] rounded p-1 text-slate-200"
              >
                <option value="patrol">Patrol Waypoints</option>
                <option value="chase">Chase Player</option>
                <option value="wander">Wander Radius</option>
                <option value="idle">Idle / Stationary</option>
              </select>
            </div>
            <div>
              <span className="text-slate-400">Nav Speed (m/s)</span>
              <input
                type="number"
                step="0.5"
                value={ai.speed}
                onChange={(e) => onUpdateAI({ ...ai, speed: parseFloat(e.target.value) })}
                className="w-full bg-[#0d1117] border border-[#30363d] rounded p-1 text-slate-200"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
