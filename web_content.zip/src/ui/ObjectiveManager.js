export class ObjectiveManager {
  constructor() {
    this.objectives = [
      { id: 'reach_rpd', text: 'الوصول إلى مركز شرطة Raccoon City (RPD)', completed: false },
      { id: 'find_medallions', text: 'العثور على الميداليات الثلاث لفتح ممر Goddess Statue', completed: false },
      { id: 'escape_mrx', text: 'الهروب من المستهدف السري Mr. X والوصول للمجاري', completed: false },
      { id: 'nest_reactor', text: 'تفعيل المفاعل الرئيسي للمختبر السري NEST والهروب', completed: false }
    ];
    this.currentObjectiveIndex = 0;
  }

  getCurrentObjective() {
    return this.objectives[this.currentObjectiveIndex] || { text: 'جميع الأهداف مكتملة! تم النجاح والهروب.' };
  }

  completeObjective(id) {
    const obj = this.objectives.find(o => o.id === id);
    if (obj) {
      obj.completed = true;
      if (this.currentObjectiveIndex < this.objectives.length - 1) {
        this.currentObjectiveIndex++;
      }
    }
  }
}
