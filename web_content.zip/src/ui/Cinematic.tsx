import { fillNames } from "@/game/engine";
import { useGame } from "@/game/store";
import { StarButton } from "./chrome";

const FALSE_STEPS = [
  "Une silhouette, trop loin pour être certaine.",
  "Une voix. Presque la sienne.",
  "Une porte. Un lieu que tu reconnais sans l'avoir vu.",
  "C'est lui.",
  "La silhouette s'efface. Il reste un objet. Rien d'autre.",
  "Tu es arrivé trop tard.",
];

export function CinematicOverlay() {
  const id = useGame((s) => s.cinematicId);
  const step = useGame((s) => s.introStep);
  const advance = useGame((s) => s.advanceCinematic);
  const names = useGame((s) => s.names);
  if (id !== "false_reveal") return null;
  const text = FALSE_STEPS[Math.min(step, FALSE_STEPS.length - 1)] ?? "";

  return (
    <div className="absolute inset-0 z-40 flex flex-col items-center justify-center bg-void/80 px-8 text-center">
      {step === 0 && <div className="mb-10 h-40 w-20 bg-gradient-to-b from-lumen/20 to-transparent blur-sm" />}
      {step === 3 && <p className="mb-6 font-display text-3xl text-lumen">C'est lui.</p>}
      <p className="max-w-sm font-display text-xl leading-relaxed text-lumen">{fillNames(text, names)}</p>
      <StarButton variant="solid" className="mt-10" onClick={advance}>
        {step >= 5 ? "Continue." : "…"}
      </StarButton>
    </div>
  );
}
