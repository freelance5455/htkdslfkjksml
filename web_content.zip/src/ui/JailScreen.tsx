import { engine } from '../game/engine';
import { useHud, fmtCountdown } from './useHud';

/** Countdown overlay while serving the 3 hour sentence. */
export default function JailScreen() {
  const hud = useHud();
  if (!hud.jailed) return null;

  const progress = 1 - hud.jailRemaining / hud.jailTotal;

  return (
    <div className="fixed inset-0 z-35 pointer-events-none">
      {/* prison bars */}
      <div className="absolute inset-0 flex justify-around opacity-[0.13]">
        {Array.from({ length: 14 }).map((_, i) => (
          <div key={i} className="w-2 h-full bg-black" />
        ))}
      </div>
      <div className="absolute inset-x-0 top-0 h-16 bg-black/70" />
      <div className="absolute inset-x-0 bottom-0 h-16 bg-black/70" />

      <div className="absolute top-6 left-1/2 -translate-x-1/2 w-[min(92vw,440px)] bg-black/80 backdrop-blur-md border border-red-500/40 rounded-xl px-5 py-4 text-center">
        <div className="text-[11px] tracking-[0.35em] text-red-400 font-bold">SERVED AT SOLSTICE POLICE HQ</div>
        <div className="text-4xl font-mono font-bold text-white mt-1 tracking-wider">
          {fmtCountdown(hud.jailRemaining)}
        </div>
        <div className="text-[11px] text-white/55 mt-1">
          Sentence: 3 hours · {Math.round(progress * 100)}% complete
        </div>
        <div className="h-1.5 w-full bg-white/10 rounded-full mt-3 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-red-500 to-amber-400 transition-all duration-1000"
            style={{ width: `${Math.min(100, progress * 100)}%` }}
          />
        </div>
        <div className="text-[10px] text-white/40 mt-2">
          The timer keeps running if you close the game — progress is saved automatically.
        </div>
        <button
          onClick={() => engine.buyEarlyRelease()}
          className="pointer-events-auto mt-3 text-[10px] font-bold tracking-wider bg-white/10 hover:bg-white/20 text-white/80 rounded px-3 py-1.5"
        >
          REQUEST EARLY RELEASE — $25,000
        </button>
      </div>
    </div>
  );
}
