import React, { useState } from 'react';
import { Volume2, VolumeX, Play, Sliders, Music, Radio } from 'lucide-react';
import { audioSystem } from '../audio/audioManager';

export const AudioManagerPanel: React.FC = () => {
  const [masterVol, setMasterVol] = useState(0.8);
  const [isMuted, setIsMuted] = useState(false);
  const [spatialPan, setSpatialPan] = useState(0);
  const [pitchShift, setPitchShift] = useState(1.0);

  const handleMuteToggle = () => {
    const muted = audioSystem.toggleMute();
    setIsMuted(muted);
  };

  const handleMasterChange = (v: number) => {
    setMasterVol(v);
    audioSystem.setMasterVolume(v);
  };

  const playSynthesized = (type: 'synth_laser' | 'synth_jump' | 'synth_engine' | 'synth_drone' | 'synth_bell') => {
    audioSystem.playSound(type, { pitch: pitchShift, pan: spatialPan });
  };

  return (
    <div className="flex flex-col md:flex-row h-full bg-[#0d1117] text-slate-300 text-xs p-3 gap-3 overflow-y-auto select-none">
      {/* Master Volumes */}
      <div className="bg-[#161b22] p-3 rounded-lg border border-[#21262d] flex flex-col justify-between flex-1 min-w-[220px]">
        <div className="flex items-center justify-between border-b border-[#21262d] pb-1.5">
          <div className="flex items-center space-x-1.5 font-bold text-slate-200">
            <Volume2 className="w-4 h-4 text-cyan-400" />
            <span>MASTER BUS</span>
          </div>
          <button
            onClick={handleMuteToggle}
            className={`p-1 rounded ${isMuted ? 'bg-rose-950 text-rose-400' : 'bg-[#0d1117] text-slate-400 hover:text-white'}`}
            title="Toggle Mute"
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
          </button>
        </div>

        <div className="space-y-2 mt-2">
          <div>
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>Master Gain</span>
              <span className="font-mono text-cyan-300">{(masterVol * 100).toFixed(0)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={masterVol}
              onChange={(e) => handleMasterChange(parseFloat(e.target.value))}
              className="w-full accent-cyan-500"
            />
          </div>

          <div>
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>3D Spatial Pan (L - R)</span>
              <span className="font-mono text-cyan-300">{spatialPan.toFixed(1)}</span>
            </div>
            <input
              type="range"
              min="-1"
              max="1"
              step="0.1"
              value={spatialPan}
              onChange={(e) => setSpatialPan(parseFloat(e.target.value))}
              className="w-full accent-cyan-500"
            />
          </div>

          <div>
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>Pitch Modulator</span>
              <span className="font-mono text-cyan-300">{pitchShift.toFixed(2)}x</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="2.0"
              step="0.1"
              value={pitchShift}
              onChange={(e) => setPitchShift(parseFloat(e.target.value))}
              className="w-full accent-cyan-500"
            />
          </div>
        </div>
      </div>

      {/* Sound Synthesizer Launchpad */}
      <div className="bg-[#161b22] p-3 rounded-lg border border-[#21262d] flex-1 flex flex-col justify-between">
        <div className="flex items-center justify-between border-b border-[#21262d] pb-1.5 mb-2">
          <div className="flex items-center space-x-1.5 font-bold text-slate-200">
            <Radio className="w-4 h-4 text-emerald-400" />
            <span>SYNTH SOUNDBOARD (Web Audio API)</span>
          </div>
          <span className="text-[9px] text-emerald-400 bg-emerald-950/80 px-1.5 py-0.5 rounded font-mono">
            Zero-Asset Latency
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          <button
            onClick={() => playSynthesized('synth_laser')}
            className="bg-[#0d1117] hover:bg-cyan-950/60 border border-[#30363d] hover:border-cyan-500 p-2 rounded text-left transition-all group"
          >
            <div className="font-semibold text-slate-200 group-hover:text-cyan-300 flex items-center justify-between">
              <span>Laser Blast</span>
              <Play className="w-3 h-3 text-cyan-400 fill-current opacity-70 group-hover:opacity-100" />
            </div>
            <div className="text-[9px] text-slate-500 font-mono mt-0.5">Sawtooth 980Hz</div>
          </button>

          <button
            onClick={() => playSynthesized('synth_jump')}
            className="bg-[#0d1117] hover:bg-cyan-950/60 border border-[#30363d] hover:border-cyan-500 p-2 rounded text-left transition-all group"
          >
            <div className="font-semibold text-slate-200 group-hover:text-cyan-300 flex items-center justify-between">
              <span>Anti-Grav Jump</span>
              <Play className="w-3 h-3 text-cyan-400 fill-current opacity-70 group-hover:opacity-100" />
            </div>
            <div className="text-[9px] text-slate-500 font-mono mt-0.5">Triangle Sweep</div>
          </button>

          <button
            onClick={() => playSynthesized('synth_bell')}
            className="bg-[#0d1117] hover:bg-cyan-950/60 border border-[#30363d] hover:border-cyan-500 p-2 rounded text-left transition-all group"
          >
            <div className="font-semibold text-slate-200 group-hover:text-cyan-300 flex items-center justify-between">
              <span>Chime / Reward</span>
              <Play className="w-3 h-3 text-cyan-400 fill-current opacity-70 group-hover:opacity-100" />
            </div>
            <div className="text-[9px] text-slate-500 font-mono mt-0.5">Dual Sine 1174Hz</div>
          </button>

          <button
            onClick={() => playSynthesized('synth_engine')}
            className="bg-[#0d1117] hover:bg-cyan-950/60 border border-[#30363d] hover:border-cyan-500 p-2 rounded text-left transition-all group"
          >
            <div className="font-semibold text-slate-200 group-hover:text-cyan-300 flex items-center justify-between">
              <span>Rover Throttle</span>
              <Play className="w-3 h-3 text-cyan-400 fill-current opacity-70 group-hover:opacity-100" />
            </div>
            <div className="text-[9px] text-slate-500 font-mono mt-0.5">Saw 55-90Hz</div>
          </button>

          <button
            onClick={() => playSynthesized('synth_drone')}
            className="bg-[#0d1117] hover:bg-cyan-950/60 border border-[#30363d] hover:border-cyan-500 p-2 rounded text-left transition-all group"
          >
            <div className="font-semibold text-slate-200 group-hover:text-cyan-300 flex items-center justify-between">
              <span>Ambient Drone</span>
              <Play className="w-3 h-3 text-cyan-400 fill-current opacity-70 group-hover:opacity-100" />
            </div>
            <div className="text-[9px] text-slate-500 font-mono mt-0.5">Sub Sine 110Hz</div>
          </button>
        </div>
      </div>
    </div>
  );
};
