import type { AudioManager } from '../engine/audio'
import type { I18n } from '../engine/i18n'
import type { Input } from '../engine/input'
import type { Quality, SaveData, SaveStore } from '../engine/save'
import type { Game } from '../game/game'
import { formatClock, formatDistance, type RunState } from '../game/rules'
import { TouchControls } from './touch'

export type ScreenName = 'boot' | 'title' | 'hud' | 'pause' | 'settings' | 'results'

export type UiCallbacks = {
  play(): void
  restart(): void
  resume(): void
  quit(): void
  pause(): void
  settings(patch: Partial<SaveData>): void
}

const CONTOURS = `
<svg class="contours" viewBox="0 0 320 36" preserveAspectRatio="none" aria-hidden="true">
  <path d="M0 26 C40 6 70 34 120 18 S210 2 260 16 S300 24 320 12"/>
  <path d="M0 31 C45 13 78 38 126 24 S214 9 262 22 S302 30 320 19"/>
  <path d="M0 35 C48 20 84 41 132 30 S218 16 264 28 S304 35 320 26"/>
</svg>`


export class Ui {
  screen: ScreenName = 'boot'
  readonly touch: TouchControls

  private readonly root: HTMLElement
  private readonly screens = new Map<ScreenName, HTMLElement>()
  private settingsReturn: ScreenName = 'title'
  private hintStage = -1
  private readonly cache = new Map<string, string>()
  private readonly el: Record<string, HTMLElement> = {}

  constructor(
    private readonly i18n: I18n,
    private readonly save: SaveStore,
    private readonly audio: AudioManager,
    private readonly input: Input,
    private readonly cb: UiCallbacks,
  ) {
    const t = (key: string, vars?: Record<string, string | number>) => i18n.t(key, vars)
    this.root = document.getElementById('ui')!
    this.root.innerHTML = `
    <section class="screen boot" data-screen="boot">
      <div class="boot-card">
        <img class="boot-icon" src="./favicon.svg" width="72" height="72" alt="" />
        <h1 class="wordmark">${t('title.name')}</h1>
        ${CONTOURS}
        <p class="boot-status" data-boot-status>${t('boot.loading')}</p>
        <div class="bar" role="progressbar" aria-valuemin="0" aria-valuemax="100"><i data-boot-bar></i></div>
        <button class="btn btn-primary" data-boot-retry hidden>${t('boot.retry')}</button>
      </div>
    </section>

    <section class="screen title" data-screen="title" hidden>
      <div class="panel title-panel">
        <span class="kicker">${t('title.kicker')}</span>
        <h1 class="wordmark">${t('title.name')}</h1>
        ${CONTOURS}
        <p class="subtitle">${t('title.sub')}</p>
        <p class="lede">${t('title.lede')}</p>
        <div class="actions">
          <button class="btn btn-primary btn-xl" data-act="play">${t('title.play')}</button>
          <button class="btn btn-ghost" data-act="settings">${t('title.settings')}</button>
        </div>
        <p class="best" data-best></p>
        <p class="legend legend-touch">${t('title.touch')}</p>
        <p class="legend legend-keys">${t('title.keys')}</p>
      </div>
    </section>

    <section class="hud" data-screen="hud" hidden>
      <div class="hud-panel hud-tl">
        <div class="stat"><span class="stat-label"><i class="l-long">${t('hud.speed')}</i><i class="l-short">${t('hud.speedShort')}</i></span><span class="stat-value"><b data-hud="speed">0</b><small>${t('hud.speedUnit')}</small></span></div>
        <div class="stat"><span class="stat-label"><i class="l-long">${t('hud.alt')}</i><i class="l-short">${t('hud.altShort')}</i></span><span class="stat-value"><b data-hud="alt">0</b><small>${t('hud.meters')}</small></span></div>
        <div class="stat stat-agl"><span class="stat-label"><i class="l-long">${t('hud.agl')}</i><i class="l-short">${t('hud.aglShort')}</i></span><span class="stat-value"><b data-hud="agl">0</b><small>${t('hud.meters')}</small></span></div>
      </div>
      <div class="hud-compass" aria-hidden="true"><b data-hud="cardinal">N</b><span data-hud="heading">000°</span></div>
      <div class="hud-right">
        <div class="hud-panel hud-score">
          <div class="stat"><span class="stat-label"><i class="l-long">${t('hud.score')}</i><i class="l-short">${t('hud.scoreShort')}</i></span><span class="stat-value"><b data-hud="score">0</b><em data-hud="mult" hidden>×2</em></span></div>
          <div class="stat"><span class="stat-label"><i class="l-long">${t('hud.rings')}</i><i class="l-short">${t('hud.ringsShort')}</i></span><span class="stat-value"><b data-hud="rings">0</b></span></div>
        </div>
        <button class="btn-pause" data-act="pause" aria-label="${t('hud.pause')}"><i></i><i></i></button>
      </div>
      <div class="warn" data-hud="warn" hidden></div>
      <div class="ringmark" data-hud="ringmark" hidden>
        <span class="ringmark-arrow"></span><i class="ringmark-diamond"></i><b data-hud="ringdist"></b>
      </div>
      <div class="pipper" data-hud="pipper" hidden><i></i></div>
      <div class="popups" data-hud="popups" aria-live="polite"></div>
      <p class="hint" data-hud="hint" hidden></p>
    </section>

    <section class="screen pause" data-screen="pause" hidden>
      <div class="panel menu-panel">
        <h2>${t('pause.title')}</h2>
        <div class="stack">
          <button class="btn btn-primary" data-act="resume">${t('pause.resume')}</button>
          <button class="btn btn-ghost" data-act="restart">${t('pause.restart')}</button>
          <button class="btn btn-ghost" data-act="settings">${t('pause.settings')}</button>
          <button class="btn btn-ghost" data-act="quit">${t('pause.quit')}</button>
        </div>
      </div>
    </section>

    <section class="screen settings" data-screen="settings" hidden>
      <div class="panel settings-panel">
        <h2>${t('settings.title')}</h2>
        <div class="settings-grid">
          <label class="row"><span>${t('settings.music')}</span><input type="range" min="0" max="1" step="0.05" data-set="musicVolume" /></label>
          <label class="row"><span>${t('settings.sfx')}</span><input type="range" min="0" max="1" step="0.05" data-set="sfxVolume" /></label>
          <label class="row"><span>${t('settings.sensitivity')}</span><input type="range" min="0.5" max="2" step="0.1" data-set="sensitivity" /></label>
          <div class="row"><span>${t('settings.pitch')}<small>${t('settings.pitchHelp')}</small></span>
            <div class="seg" role="group" data-seg="invertY">
              <button type="button" data-value="false">${t('settings.pitchClassic')}</button>
              <button type="button" data-value="true">${t('settings.pitchInverted')}</button>
            </div></div>
          <div class="row"><span>${t('settings.quality')}</span>
            <div class="seg" role="group" data-seg="quality">
              <button type="button" data-value="low">${t('settings.low')}</button>
              <button type="button" data-value="medium">${t('settings.medium')}</button>
              <button type="button" data-value="high">${t('settings.high')}</button>
            </div></div>
          <label class="row"><span>${t('settings.assist')}<small>${t('settings.assistHelp')}</small></span><input type="checkbox" data-set="assist" /></label>
          <label class="row"><span>${t('settings.motion')}<small>${t('settings.motionHelp')}</small></span><input type="checkbox" data-set="reducedMotion" /></label>
          <label class="row"><span>${t('settings.mute')}</span><input type="checkbox" data-set="muted" /></label>
        </div>
        <button class="btn btn-primary" data-act="back">${t('settings.back')}</button>
      </div>
    </section>

    <section class="screen results" data-screen="results" hidden>
      <div class="panel results-panel">
        <span class="kicker" data-res="badge"></span>
        <h2 data-res="title"></h2>
        <p class="lede" data-res="tip"></p>
        <dl class="results-grid">
          <div><dt>${t('results.score')}</dt><dd data-res="score">0</dd></div>
          <div><dt>${t('results.rings')}</dt><dd data-res="rings">0</dd></div>
          <div><dt>${t('results.distance')}</dt><dd data-res="distance">0</dd></div>
          <div><dt>${t('results.time')}</dt><dd data-res="time">0:00</dd></div>
          <div><dt>${t('results.altitude')}</dt><dd data-res="alt">0</dd></div>
        </dl>
        <p class="best" data-res="best"></p>
        <div class="actions">
          <button class="btn btn-primary btn-xl" data-act="restart">${t('results.retry')}</button>
          <button class="btn btn-ghost" data-act="quit">${t('results.menu')}</button>
        </div>
      </div>
    </section>
    <div class="flash" data-flash></div>`

    for (const node of this.root.querySelectorAll<HTMLElement>('[data-screen]')) {
      this.screens.set(node.dataset.screen as ScreenName, node)
    }
    for (const node of this.root.querySelectorAll<HTMLElement>('[data-hud]')) this.el[node.dataset.hud!] = node
    for (const node of this.root.querySelectorAll<HTMLElement>('[data-res]')) this.el[`res.${node.dataset.res}`] = node
    this.el.flash = this.root.querySelector<HTMLElement>('[data-flash]')!

    this.touch = new TouchControls(this.root, input, { throttle: t('hud.throttle') })

    this.root.addEventListener('contextmenu', e => e.preventDefault())
    this.root.addEventListener('click', e => {
      const target = (e.target as HTMLElement).closest<HTMLElement>('[data-act]')
      if (!target) return
      this.audio.unlock()
      this.audio.play('click')
      this.act(target.dataset.act!)
    })
    this.bindSettings()
    this.refreshSettings()
  }

  private act(name: string): void {
    switch (name) {
      case 'play': this.cb.play(); break
      case 'restart': this.cb.restart(); break
      case 'resume': this.cb.resume(); break
      case 'pause': this.cb.pause(); break
      case 'quit': this.cb.quit(); break
      case 'settings':
        this.settingsReturn = this.screen === 'pause' ? 'pause' : 'title'
        this.show('settings')
        break
      case 'back': this.show(this.settingsReturn); break
    }
  }

  show(name: ScreenName): void {
    this.screen = name
    for (const [key, node] of this.screens) node.hidden = key !== name
    this.touch.setVisible(name === 'hud')
    this.root.dataset.screen = name
    if (name === 'title') this.refreshBest()
    if (name !== 'hud') {
      this.setHint('')
      this.hintStage = -1
    }
    if (name === 'hud') this.root.classList.remove('is-crashed')
    // Focus the primary action for keyboard and gamepad users.
    const primary = this.screens.get(name)?.querySelector<HTMLElement>('.btn-primary')
    if (primary && name !== 'boot') primary.focus({ preventScroll: true })
  }

  // ─── boot ───────────────────────────────────────────────────────────────
  setBootProgress(progress: number): void {
    const pct = Math.round(Math.min(1, Math.max(0, progress)) * 100)
    this.root.querySelector<HTMLElement>('[data-boot-bar]')!.style.width = `${pct}%`
    this.root.querySelector('.bar')!.setAttribute('aria-valuenow', String(pct))
  }

  bootError(retry: () => void): void {
    this.root.querySelector<HTMLElement>('[data-boot-status]')!.textContent = this.i18n.t('boot.error')
    const button = this.root.querySelector<HTMLButtonElement>('[data-boot-retry]')!
    button.hidden = false
    button.onclick = () => {
      button.hidden = true
      this.root.querySelector<HTMLElement>('[data-boot-status]')!.textContent = this.i18n.t('boot.loading')
      retry()
    }
  }

  // ─── settings ───────────────────────────────────────────────────────────
  private bindSettings(): void {
    const panel = this.screens.get('settings')!
    panel.addEventListener('input', e => {
      const node = e.target as HTMLInputElement
      const key = node.dataset.set as keyof SaveData | undefined
      if (!key) return
      const value = node.type === 'checkbox' ? node.checked : Number(node.value)
      this.cb.settings({ [key]: value } as Partial<SaveData>)
    })
    panel.addEventListener('click', e => {
      const button = (e.target as HTMLElement).closest<HTMLButtonElement>('.seg button')
      if (!button) return
      const group = button.parentElement!.dataset.seg as 'invertY' | 'quality'
      const raw = button.dataset.value!
      const patch = group === 'invertY' ? { invertY: raw === 'true' } : { quality: raw as Quality }
      this.cb.settings(patch)
      this.refreshSettings()
    })
  }

  refreshSettings(): void {
    const d = this.save.data
    for (const node of this.root.querySelectorAll<HTMLInputElement>('[data-set]')) {
      const key = node.dataset.set as keyof SaveData
      if (node.type === 'checkbox') node.checked = Boolean(d[key])
      else node.value = String(d[key])
    }
    for (const group of this.root.querySelectorAll<HTMLElement>('[data-seg]')) {
      const current = String(group.dataset.seg === 'invertY' ? d.invertY : d.quality)
      for (const b of group.querySelectorAll<HTMLButtonElement>('button')) b.setAttribute('aria-pressed', String(b.dataset.value === current))
    }
  }

  private refreshBest(): void {
    const best = this.save.data.best
    const node = this.root.querySelector<HTMLElement>('[data-best]')!
    node.textContent = best.score > 0
      ? this.i18n.t('title.best', { score: best.score.toLocaleString('es-AR'), rings: best.rings })
      : this.i18n.t('title.noBest')
  }

  // ─── HUD ────────────────────────────────────────────────────────────────
  private text(key: string, value: string): void {
    if (this.cache.get(key) === value) return
    this.cache.set(key, value)
    this.el[key].textContent = value
  }

  private toggle(key: string, visible: boolean): void {
    const node = this.el[key]
    if (node.hidden === !visible) return
    node.hidden = !visible
  }

  /** Update the HUD from the live game state; call once per frame while on the HUD. */
  updateHud(game: Game): void {
    const h = game.hud
    const run = game.run
    this.touch.sync()
    this.text('speed', String(Math.round(h.speedKmh)))
    this.text('alt', String(Math.round(h.altitude)))
    this.text('agl', String(Math.max(0, Math.round(h.agl))))
    this.text('cardinal', h.compass)
    this.text('heading', `${String(Math.round(h.heading) % 360).padStart(3, '0')}°`)
    this.text('score', run.score.toLocaleString('es-AR'))
    this.text('rings', String(run.rings))
    this.text('mult', `×${run.multiplier}`)
    this.toggle('mult', run.multiplier > 1)
    this.el.agl.parentElement!.parentElement!.classList.toggle('is-low', h.agl < 60)

    const warn = game.mode === 'playing' ? h.warning : null
    if (warn) this.text('warn', this.i18n.t(`warn.${warn}`))
    this.toggle('warn', warn !== null)
    this.el.warn.dataset.kind = warn ?? ''

    const showRing = game.mode === 'playing' && h.ring.visible
    this.toggle('ringmark', showRing)
    if (showRing) {
      const node = this.el.ringmark
      node.style.transform = `translate3d(${h.ring.x}px, ${h.ring.y}px, 0)`
      node.classList.toggle('is-edge', !h.ring.onScreen)
      node.style.setProperty('--angle', `${h.ring.angle}rad`)
      this.text('ringdist', h.ringDistance >= 1000 ? `${(h.ringDistance / 1000).toFixed(1)} km` : `${Math.round(h.ringDistance / 10) * 10} m`)
    }
    const showPipper = game.mode === 'playing' && h.pipper.visible && h.pipper.onScreen
    this.toggle('pipper', showPipper)
    if (showPipper) this.el.pipper.style.transform = `translate3d(${h.pipper.x}px, ${h.pipper.y}px, 0)`

    if (game.mode === 'playing') this.tutorial(run)
  }

  /** First-flight guidance, one line at a time. */
  private tutorial(run: RunState): void {
    if (this.save.data.tutorialDone) return
    const keys = this.input.method !== 'touch'
    const s = run.seconds
    const stage = s < 5.5 ? 0 : s < 11 ? 1 : s < 17 ? 2 : 3
    if (stage === this.hintStage) return
    this.hintStage = stage
    if (stage === 0) this.setHint(this.i18n.t(keys ? 'hint.stickKeys' : 'hint.stick'))
    else if (stage === 1) this.setHint(this.i18n.t(keys ? 'hint.throttleKeys' : 'hint.throttle'))
    else if (stage === 2) this.setHint(this.i18n.t('hint.rings'))
    else {
      this.setHint('')
      this.save.update({ tutorialDone: true })
    }
  }

  private setHint(text: string): void {
    const node = this.el.hint
    if (!node) return
    node.textContent = text
    node.hidden = text === ''
  }

  popup(text: string, kind: 'points' | 'perfect' | 'miss' = 'points'): void {
    const box = this.el.popups
    const node = document.createElement('div')
    node.className = `popup popup-${kind}`
    node.textContent = text
    box.append(node)
    window.setTimeout(() => node.remove(), 1500)
    while (box.children.length > 4) box.firstElementChild?.remove()
  }

  ring(info: { points: number; perfect: boolean; multiplier: number }): void {
    const t = this.i18n.t.bind(this.i18n)
    const parts = [t('popup.points', { points: info.points })]
    if (info.multiplier > 1) parts.push(t('popup.multiplier', { n: info.multiplier }))
    this.popup(parts.join('  '), info.perfect ? 'perfect' : 'points')
    if (info.perfect) window.setTimeout(() => this.popup(t('popup.perfect'), 'perfect'), 120)
  }

  missed(): void {
    this.popup(this.i18n.t('popup.miss'), 'miss')
  }

  /** Red flash and control lock the instant the aircraft hits the ground. */
  crashed(): void {
    this.root.classList.add('is-crashed')
    this.touch.release()
    this.touch.setVisible(false)
    const flash = this.el.flash
    flash.classList.remove('is-on')
    void flash.offsetWidth
    flash.classList.add('is-on')
  }

  showResults(run: RunState, newBest: boolean): void {
    const t = this.i18n.t.bind(this.i18n)
    const water = run.cause === 'water'
    this.el['res.title'].textContent = t(water ? 'results.crashWater' : 'results.crashTerrain')
    this.el['res.tip'].textContent = t(water ? 'results.tipWater' : 'results.tipTerrain')
    this.el['res.score'].textContent = run.score.toLocaleString('es-AR')
    this.el['res.rings'].textContent = String(run.rings)
    this.el['res.distance'].textContent = formatDistance(run.distance)
    this.el['res.time'].textContent = formatClock(run.seconds)
    this.el['res.alt'].textContent = `${Math.round(run.maxAltitude)} m`
    this.el['res.badge'].textContent = newBest ? t('results.newBest') : ''
    this.el['res.badge'].hidden = !newBest
    this.el['res.best'].textContent = run.unranked ? t('results.unranked') : t('results.best', { score: this.save.data.best.score.toLocaleString('es-AR') })
    this.show('results')
  }

  /** Mark the UI root with the active input method so CSS can show the right legend. */
  frame(): void {
    const method = this.input.method
    if (this.root.dataset.input !== method) this.root.dataset.input = method
  }
}
