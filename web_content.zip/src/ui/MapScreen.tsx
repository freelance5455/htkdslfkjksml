import { useEffect, useRef } from 'react';
import { engine } from '../game/engine';
import { useHud } from './useHud';
import { LANDMARKS } from '../game/items';

export default function MapScreen() {
  const hud = useHud();
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!hud.mapOpen) return;
    engine.attachCanvases(null, ref.current);
    const id = setInterval(() => engine.drawBigMap(), 400);
    engine.drawBigMap();
    return () => {
      clearInterval(id);
      engine.attachCanvases(null, null);
    };
  }, [hud.mapOpen]);

  if (!hud.mapOpen) return null;

  return (
    <div className="fixed inset-0 z-40 bg-[#0a0d11]/95 flex flex-col">
      <div className="flex items-center justify-between px-5 py-3 border-b border-white/10">
        <div>
          <h2 className="text-white font-bold tracking-[0.25em] text-sm">SOLSTICE CITY</h2>
          <p className="text-[11px] text-white/45">
            {hud.location} · {Math.round(hud.speed)} km/h · press M to close
          </p>
        </div>
        <button
          onClick={() => (engine.mapOpen = false)}
          className="text-white/70 hover:text-white bg-white/5 rounded px-3 py-1.5 text-xs"
        >
          CLOSE
        </button>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row gap-4 p-4 overflow-hidden">
        <div className="flex-1 relative rounded-xl overflow-hidden border border-white/10 bg-[#12161b] min-h-[300px]">
          <canvas ref={ref} width={900} height={900} className="w-full h-full object-contain" />
        </div>

        <div className="w-full lg:w-72 overflow-y-auto space-y-3">
          <div className="bg-white/5 border border-white/10 rounded-xl p-3">
            <div className="text-[10px] tracking-widest text-amber-400/80 mb-2">LANDMARKS</div>
            <div className="space-y-1.5">
              {LANDMARKS.map((l) => (
                <div key={l.id} className="flex items-center gap-2 text-[12px] text-white/80">
                  <span
                    className="w-3 h-3 rounded-sm"
                    style={{ background: '#' + l.color.toString(16).padStart(6, '0') }}
                  />
                  <span className="flex-1">{l.name}</span>
                  <span className="text-[10px] text-white/35">
                    {Math.round(Math.hypot(l.x - 0, l.z - 0))}m
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-xl p-3">
            <div className="text-[10px] tracking-widest text-amber-400/80 mb-2">JOBS</div>
            <div className="space-y-2">
              {hud.missions.map((m) => (
                <div key={m.id} className="text-[12px]">
                  <div className="text-white/85 font-semibold flex justify-between">
                    <span>{m.title}</span>
                    <span
                      className={
                        m.state === 'done'
                          ? 'text-emerald-300'
                          : m.state === 'active'
                          ? 'text-amber-300'
                          : 'text-white/40'
                      }
                    >
                      {m.state.toUpperCase()}
                    </span>
                  </div>
                  <div className="text-white/45 text-[11px] leading-snug">{m.brief}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-xl p-3 text-[11px] text-white/55 leading-relaxed">
            <div className="text-white/85 font-semibold mb-1">Legend</div>
            🟡 Objective · 🟣 Interior · 🔵 Police · 🟢 Shop
          </div>
        </div>
      </div>
    </div>
  );
}
