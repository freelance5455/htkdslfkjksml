import { getLocation } from "@/data/locations";
import { hotspotVisible, isNight, fillNames } from "@/game/engine";
import { useGame } from "@/game/store";
import { cn } from "@/lib/utils";

function Silhouette({ ambience, past }: { ambience: string; past: boolean }) {
  const dusk = past ? "opacity-80" : "opacity-100";
  if (ambience === "village") {
    return (
      <svg viewBox="0 0 100 60" className={cn("absolute inset-x-0 bottom-0 w-full text-night", dusk)} preserveAspectRatio="none">
        <path fill="currentColor" d="M0 60 V38 H8 V28 H14 V38 H22 V32 H28 V22 H32 V32 H40 V36 H52 V30 H60 V38 H70 V26 H78 V38 H88 V34 H100 V60 Z" />
        <rect x="11" y="31" width="2" height="3" className="fill-lumen/30" />
        <rect x="25" y="34" width="2" height="3" className="fill-lumen/20" />
        <rect x="73" y="30" width="2" height="3" className="fill-lumen/25" />
      </svg>
    );
  }
  if (ambience === "forest") {
    return (
      <svg viewBox="0 0 100 60" className="absolute inset-x-0 bottom-0 w-full text-night" preserveAspectRatio="none">
        <path fill="currentColor" d="M0 60 L8 18 L16 60 L24 10 L34 60 L42 22 L50 60 L60 8 L70 60 L80 16 L90 60 L100 20 V60 Z" />
      </svg>
    );
  }
  if (ambience === "observatory") {
    return (
      <svg viewBox="0 0 100 60" className="absolute inset-x-0 bottom-[8%] w-full text-night" preserveAspectRatio="xMidYEnd meet">
        <path fill="currentColor" d="M30 58 V36 A20 16 0 0 1 70 36 V58 Z" />
        <rect x="48" y="18" width="4" height="16" fill="currentColor" />
      </svg>
    );
  }
  if (ambience === "city") {
    return (
      <svg viewBox="0 0 100 60" className="absolute inset-x-0 bottom-0 w-full text-night" preserveAspectRatio="none">
        <path fill="currentColor" d="M0 60 V40 H10 V22 H22 V40 H30 V18 H42 V40 H50 V28 H62 V14 H74 V36 H84 V24 H96 V60 Z" />
        <g className="fill-lumen/15">
          <rect x="13" y="28" width="2" height="2" />
          <rect x="34" y="24" width="2" height="2" />
          <rect x="66" y="22" width="2" height="2" />
          <rect x="88" y="30" width="2" height="2" />
        </g>
      </svg>
    );
  }
  if (ambience === "sanctuary") {
    return (
      <div className="absolute inset-x-[12%] bottom-[12%] top-[22%] border border-lumen/10 bg-ink/40">
        <div className="absolute bottom-[18%] left-[18%] h-16 w-10 border border-lumen/20 bg-night/80" />
        <div className="absolute right-[16%] top-[18%] h-14 w-14 rounded-full border border-lumen/15" />
      </div>
    );
  }
  if (ambience === "gates") {
    return (
      <svg viewBox="0 0 100 50" className="absolute inset-x-0 bottom-[16%] w-full text-lumen/20">
        {[8, 20, 32, 44, 56, 68, 80].map((x) => (
          <path key={x} fill="none" stroke="currentColor" strokeWidth="0.6" d={`M${x} 46 V18 A6 8 0 0 1 ${x + 12} 18 V46`} />
        ))}
      </svg>
    );
  }
  if (ambience === "last") {
    return (
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="h-40 w-40 rounded-full bg-lumen/5 blur-2xl" />
      </div>
    );
  }
  if (ambience === "threshold") {
    return (
      <svg viewBox="0 0 100 30" className="absolute inset-x-0 bottom-0 w-full text-night" preserveAspectRatio="none">
        <path fill="currentColor" d="M0 30 L18 18 L34 24 L50 14 L68 22 L86 12 L100 20 V30 Z" />
      </svg>
    );
  }
  return (
    <div className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-void to-transparent" />
  );
}

export function SceneView() {
  const locationId = useGame((s) => s.locationId);
  const flags = useGame((s) => s.flags);
  const visits = useGame((s) => s.visits);
  const timeLayer = useGame((s) => s.timeLayer);
  const act = useGame((s) => s.act);
  const names = useGame((s) => s.names);
  const interact = useGame((s) => s.interact);
  const travel = useGame((s) => s.travel);
  const loc = getLocation(locationId);
  if (!loc) return null;

  const night = isNight(act >= 7);
  const echoIndex = Math.min(loc.echoes.length - 1, Math.max(0, (visits[locationId] ?? 1) - 1));
  const blurb = fillNames(loc.echoes[echoIndex] ?? loc.blurb, names);
  const past = timeLayer === "past";

  return (
    <div className="absolute inset-0">
      <Silhouette ambience={loc.ambience} past={past} />
      {past && <div className="pointer-events-none absolute inset-0 bg-ember/5 mix-blend-screen" />}
      {loc.weather === "fog" && (
        <div className="pointer-events-none absolute inset-0 animate-[mist-drift_12s_ease-in-out_infinite_alternate] bg-[radial-gradient(ellipse_at_center,rgba(168,176,194,0.14),transparent_70%)]" />
      )}

      <div className="absolute inset-x-0 top-[18%] px-6 text-center">
        <p className="text-[0.65rem] uppercase tracking-[0.32em] text-fog/80">{loc.region}</p>
        <h1 className="mt-2 font-display text-3xl text-lumen sm:text-4xl">{loc.name}</h1>
        <p className="mx-auto mt-3 max-w-sm font-display text-base italic text-mist/80">{blurb}</p>
        {past && (
          <p className="mt-2 text-[0.65rem] uppercase tracking-[0.22em] text-warm/80">Couche temporelle : passé</p>
        )}
      </div>

      {loc.hotspots.map((hs) => {
        if (!hotspotVisible(hs, useGame.getState(), timeLayer, night)) return null;
        return (
          <button
            key={hs.id}
            type="button"
            onClick={() => interact(hs.id)}
            style={{ left: `${hs.x}%`, top: `${hs.y}%` }}
            className="group absolute z-10 flex -translate-x-1/2 -translate-y-1/2 flex-col items-center"
          >
            <span className="relative flex size-11 items-center justify-center">
              <span className="absolute size-11 rounded-full bg-lumen/5 group-hover:bg-lumen/10" />
              <span className="absolute size-2.5 rounded-full bg-lumen shadow-[0_0_16px_rgba(243,239,230,0.7)] animate-[pulse-star_2.8s_ease-in-out_infinite]" />
            </span>
            <span className="mt-1 max-w-[9rem] text-center text-[0.7rem] tracking-wide text-silver/90 opacity-90">
              {fillNames(hs.label, names)}
            </span>
          </button>
        );
      })}

      {loc.exits.map((ex) => {
        if (ex.hideFlag && flags[ex.hideFlag]) return null;
        if (ex.requireFlag && !flags[ex.requireFlag]) return null;
        return (
          <button
            key={ex.to}
            type="button"
            onClick={() => travel(ex.to)}
            style={{ left: `${ex.x}%`, top: `${ex.y}%` }}
            className="absolute z-10 -translate-x-1/2 -translate-y-1/2 rounded-md border border-lumen/15 bg-void/40 px-3 py-2 text-[0.7rem] uppercase tracking-[0.16em] text-fog backdrop-blur-sm hover:border-lumen/35 hover:text-lumen"
          >
            {ex.label}
          </button>
        );
      })}
    </div>
  );
}
