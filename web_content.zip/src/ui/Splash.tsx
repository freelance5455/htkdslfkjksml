import { useEffect, useState } from 'react';
import { Logo } from './common';
import { preloadTextures } from '../game/textures';
import { buildWeaponModel } from '../game/models';
import { WEAPONS } from '../game/data/weapons';
import { store } from '../game/save';
import { audio } from '../game/audio';

const LINES = [
  '// CLASSIFIED — EYES ONLY',
  'THEATRE: IRON DISTRICT / DUST FRONTIER',
  'HOSTILE FORCES HAVE SEIZED THE CORRIDOR.',
  'YOUR UNIT OPERATES WHERE OTHERS CANNOT.',
  'NO FLAGS. NO NAMES. ONLY THE SHADOW.',
];

function webglOk() { try { const c = document.createElement('canvas'); return !!(c.getContext('webgl2') || c.getContext('webgl')); } catch { return false; } }

export function Splash({ onDone }: { onDone: () => void }) {
  const [phase, setPhase] = useState<'logo' | 'load' | 'ready' | 'error'>('logo');
  const [progress, setProgress] = useState(0);
  const [task, setTask] = useState('');
  const [line, setLine] = useState(0);
  const [chars, setChars] = useState(0);

  useEffect(() => { const t = setTimeout(() => setPhase('load'), 1700); return () => clearTimeout(t); }, []);

  // real loading work: verifies WebGL, generates textures, builds & caches weapon models
  useEffect(() => {
    if (phase !== 'load') return;
    let cancelled = false;
    (async () => {
      try {
        setTask('Checking WebGL support'); await new Promise(r => setTimeout(r, 120));
        if (!webglOk()) { setPhase('error'); return; }
        setProgress(0.08);
        setTask('Generating terrain & material textures');
        await preloadTextures(store.settings.graphics.textures, p => !cancelled && setProgress(0.08 + p * 0.42));
        setTask('Assembling weapon armory');
        for (let i = 0; i < WEAPONS.length; i++) {
          buildWeaponModel(WEAPONS[i]); if (cancelled) return;
          setProgress(0.5 + ((i + 1) / WEAPONS.length) * 0.45);
          await new Promise(r => setTimeout(r, 30));
        }
        setTask('Loading profile'); setProgress(1);
        await new Promise(r => setTimeout(r, 250));
        if (!cancelled) setPhase('ready');
      } catch (e) { console.error(e); if (!cancelled) setPhase('error'); }
    })();
    return () => { cancelled = true; };
  }, [phase]);

  // briefing typewriter
  useEffect(() => {
    if (phase === 'logo' || phase === 'error') return;
    if (line >= LINES.length) return;
    const t = setTimeout(() => {
      if (chars < LINES[line].length) setChars(c => c + 1); else { setLine(l => l + 1); setChars(0); }
    }, chars >= LINES[line]?.length ? 380 : 22);
    return () => clearTimeout(t);
  }, [phase, line, chars]);

  useEffect(() => {
    if (phase !== 'ready') return;
    const go = () => { audio.unlock(); audio.ui('select'); audio.startMusic('menu'); onDone(); };
    const k = (e: KeyboardEvent) => { e.preventDefault(); go(); };
    window.addEventListener('keydown', k); window.addEventListener('pointerdown', go);
    return () => { window.removeEventListener('keydown', k); window.removeEventListener('pointerdown', go); };
  }, [phase, onDone]);

  return (
    <div className="absolute inset-0 bg-black overflow-hidden scanlines vignette">
      <div className="absolute inset-0 opacity-40" style={{ background: 'radial-gradient(ellipse at 60% 40%, #3a2a10 0%, #0a0806 55%, #000 100%)' }} />
      {phase !== 'logo' && <>
        <div className="absolute top-0 inset-x-0 bg-black z-10 animate-[letterbox_1.2s_ease_both]" style={{ height: '11%' }} />
        <div className="absolute bottom-0 inset-x-0 bg-black z-10 animate-[letterbox_1.2s_ease_both]" style={{ height: '11%' }} />
      </>}
      <div className="absolute inset-0 flex flex-col items-center justify-center gap-8 px-6">
        <div className={phase === 'logo' ? '' : 'transition-all duration-700 -translate-y-6'}>
          <div className="scale-[1.4] sm:scale-[2]"><Logo animated /></div>
        </div>
        {phase === 'logo' && <div className="text-[10px] tracking-[0.6em] text-white/40 anim-fade" style={{ animationDelay: '0.8s' }}>AN ORIGINAL TACTICAL SHOOTER</div>}
        {phase !== 'logo' && phase !== 'error' && (
          <div className="w-full max-w-xl anim-fade">
            <div className="font-mono text-[11px] sm:text-sm text-amber-op/90 min-h-[7.5rem] space-y-1">
              {LINES.slice(0, line).map((l, i) => <div key={i}>{l}</div>)}
              {line < LINES.length && <div>{LINES[line].slice(0, chars)}<span className="anim-blink">▌</span></div>}
            </div>
            {phase === 'load' && (
              <div className="mt-4">
                <div className="flex justify-between text-[10px] tracking-[0.3em] text-white/50 mb-1"><span>{task.toUpperCase()}</span><span>{Math.round(progress * 100)}%</span></div>
                <div className="h-[3px] bg-white/10"><div className="h-full bg-amber-op transition-all duration-150" style={{ width: `${progress * 100}%` }} /></div>
              </div>
            )}
            {phase === 'ready' && <div className="mt-6 text-center text-sm tracking-[0.5em] text-white anim-blink">PRESS ANY KEY OR TAP TO DEPLOY</div>}
          </div>
        )}
        {phase === 'error' && (
          <div className="max-w-md text-center text-sm text-red-300 bg-red-950/50 border border-red-500/40 p-4">
            WebGL is unavailable on this device/browser. OPERATION SHADOW requires hardware-accelerated WebGL. Enable hardware acceleration or try a recent version of Chrome, Edge, Firefox or Safari.
          </div>
        )}
      </div>
      <div className="absolute bottom-[12%] right-6 text-[9px] tracking-[0.3em] text-white/25 z-20">BUILD 1.0 · WEBGL</div>
    </div>
  );
}
