import { useState } from 'react';
import { engine } from '../game/engine';
import { useHud } from './useHud';
import type { ItemCategory } from '../game/items';

const CATS: { id: ItemCategory | 'all'; label: string; icon: string }[] = [
  { id: 'all', label: 'ALL', icon: '🎒' },
  { id: 'weapon', label: 'WEAPONS', icon: '🔫' },
  { id: 'ammo', label: 'AMMO', icon: '🔩' },
  { id: 'food', label: 'FOOD', icon: '🍔' },
  { id: 'tool', label: 'TOOLS', icon: '🔧' },
  { id: 'misc', label: 'OTHER', icon: '📦' },
];

export default function Inventory() {
  const hud = useHud();
  const [cat, setCat] = useState<ItemCategory | 'all'>('all');
  if (!hud.inventoryOpen) return null;

  const items = hud.inventory.filter((i) => cat === 'all' || i.category === cat);

  return (
    <div
      className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={() => (engine.inventoryOpen = false)}
    >
      <div
        className="w-full max-w-3xl max-h-[82vh] bg-[#0e1116]/95 border border-white/12 rounded-xl overflow-hidden shadow-2xl flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 py-3 border-b border-white/10 bg-gradient-to-r from-amber-500/10 to-transparent">
          <div>
            <h2 className="text-white font-bold tracking-widest text-sm">INVENTORY</h2>
            <p className="text-[11px] text-white/45">
              {hud.inventory.length} unique stacks · {fmt(hud.money)} carried
            </p>
          </div>
          <button
            onClick={() => (engine.inventoryOpen = false)}
            className="text-white/60 hover:text-white text-lg px-2"
          >
            ✕
          </button>
        </div>

        <div className="flex gap-1.5 px-4 py-3 overflow-x-auto border-b border-white/10">
          {CATS.map((c) => (
            <button
              key={c.id}
              onClick={() => setCat(c.id)}
              className={`px-3 py-1.5 rounded-md text-[11px] font-semibold tracking-wider whitespace-nowrap transition ${
                cat === c.id
                  ? 'bg-amber-500 text-black'
                  : 'bg-white/5 text-white/65 hover:bg-white/10'
              }`}
            >
              {c.icon} {c.label}
            </button>
          ))}
        </div>

        <div className="p-4 overflow-y-auto grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {items.length === 0 && (
            <div className="col-span-full text-center text-white/40 text-sm py-10">
              Nothing in this category yet.
            </div>
          )}
          {items.map((it) => (
            <div
              key={it.id}
              className="bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg p-3 flex flex-col gap-1 transition group"
            >
              <div className="flex items-start justify-between">
                <span className="text-2xl">{it.icon}</span>
                {it.qty > 1 && (
                  <span className="text-[11px] font-bold text-amber-300">x{it.qty}</span>
                )}
              </div>
              <div className="text-[12px] font-semibold text-white leading-tight">{it.name}</div>
              <div className="text-[10px] text-white/45 leading-snug flex-1">{it.desc}</div>
              <button
                onClick={() => engine.useItem(it.id)}
                className="mt-1 text-[10px] font-bold tracking-wider bg-amber-500/90 hover:bg-amber-400 text-black rounded py-1.5"
              >
                {it.category === 'weapon' ? 'EQUIP' : 'USE'}
              </button>
            </div>
          ))}
        </div>

        <div className="px-5 py-3 border-t border-white/10 text-[11px] text-white/45">
          Weapons are equipped from the weapon wheel (Q / top-right button). Press R to reload.
        </div>
      </div>
    </div>
  );
}

function fmt(v: number) {
  return '$' + Math.floor(v).toLocaleString('en-US');
}
