import type { Input } from '../engine/input'

/**
 * On-screen flight controls for touch (and mouse):
 *  - Left half of the screen: a floating joystick. The base appears under the thumb, the knob follows
 *    it, and the offset becomes pitch (vertical) and roll (horizontal).
 *  - Right edge: a vertical throttle slider (bottom = idle, top = full power).
 *
 * Both use Pointer Events with pointer capture, so several fingers work independently and a drag
 * that leaves its element keeps controlling.
 */
const STICK_RADIUS = 62

export class TouchControls {
  readonly root: HTMLElement
  private readonly zone: HTMLElement
  private readonly base: HTMLElement
  private readonly knob: HTMLElement
  private readonly slider: HTMLElement
  private readonly track: HTMLElement
  private readonly fill: HTMLElement
  private readonly thumb: HTMLElement
  private readonly valueLabel: HTMLElement
  private stickPointer = -1
  private throttlePointer = -1
  private originX = 0
  private originY = 0
  private lastPercent = -1

  constructor(parent: HTMLElement, private readonly input: Input, labels: { throttle: string }) {
    this.root = document.createElement('div')
    this.root.className = 'touch'
    this.root.innerHTML = `
      <div class="stick-zone" data-stick-zone></div>
      <div class="stick" data-stick aria-hidden="true">
        <div class="stick-base"><i class="stick-ring"></i><i class="stick-knob"></i></div>
      </div>
      <div class="throttle" data-throttle role="slider" aria-label="${labels.throttle}" aria-valuemin="0" aria-valuemax="100">
        <span class="throttle-label">${labels.throttle}</span>
        <div class="throttle-track" data-track>
          <i class="throttle-fill"></i>
          <i class="throttle-tick" style="bottom:25%"></i><i class="throttle-tick" style="bottom:50%"></i><i class="throttle-tick" style="bottom:75%"></i>
          <b class="throttle-thumb"></b>
        </div>
        <span class="throttle-value">50%</span>
      </div>`
    parent.append(this.root)
    this.zone = this.root.querySelector('[data-stick-zone]')!
    this.base = this.root.querySelector('[data-stick]')!
    this.knob = this.root.querySelector('.stick-knob')!
    this.slider = this.root.querySelector('[data-throttle]')!
    this.track = this.root.querySelector('[data-track]')!
    this.fill = this.root.querySelector('.throttle-fill')!
    this.thumb = this.root.querySelector('.throttle-thumb')!
    this.valueLabel = this.root.querySelector('.throttle-value')!

    // ─── joystick ───
    this.zone.addEventListener('pointerdown', e => {
      if (this.stickPointer !== -1) return
      e.preventDefault()
      this.stickPointer = e.pointerId
      this.zone.setPointerCapture(e.pointerId)
      const rect = this.zone.getBoundingClientRect()
      // Keep the whole base inside the zone even when touched near an edge.
      const m = STICK_RADIUS + 14
      this.originX = Math.min(rect.right - m, Math.max(rect.left + m, e.clientX))
      this.originY = Math.min(rect.bottom - m, Math.max(rect.top + m, e.clientY))
      this.base.classList.add('is-active')
      this.base.style.setProperty('--x', `${this.originX}px`)
      this.base.style.setProperty('--y', `${this.originY}px`)
      this.moveStick(e.clientX, e.clientY)
    })
    this.zone.addEventListener('pointermove', e => {
      if (e.pointerId === this.stickPointer) this.moveStick(e.clientX, e.clientY)
    })
    const endStick = (e: PointerEvent) => {
      if (e.pointerId !== this.stickPointer) return
      this.releaseStick()
    }
    this.zone.addEventListener('pointerup', endStick)
    this.zone.addEventListener('pointercancel', endStick)
    this.zone.addEventListener('lostpointercapture', endStick)

    // ─── throttle ───
    this.slider.addEventListener('pointerdown', e => {
      if (this.throttlePointer !== -1) return
      e.preventDefault()
      this.throttlePointer = e.pointerId
      this.slider.setPointerCapture(e.pointerId)
      this.slider.classList.add('is-active')
      this.moveThrottle(e.clientY)
    })
    this.slider.addEventListener('pointermove', e => {
      if (e.pointerId === this.throttlePointer) this.moveThrottle(e.clientY)
    })
    const endThrottle = (e: PointerEvent) => {
      if (e.pointerId !== this.throttlePointer) return
      this.throttlePointer = -1
      this.slider.classList.remove('is-active')
    }
    this.slider.addEventListener('pointerup', endThrottle)
    this.slider.addEventListener('pointercancel', endThrottle)
    this.slider.addEventListener('lostpointercapture', endThrottle)
    this.slider.addEventListener('keydown', e => {
      const step = e.key === 'ArrowUp' || e.key === 'ArrowRight' ? 0.05 : e.key === 'ArrowDown' || e.key === 'ArrowLeft' ? -0.05 : 0
      if (step) {
        e.preventDefault()
        this.input.setThrottle(this.input.throttle + step)
      }
    })
    this.slider.tabIndex = -1
    this.sync()
  }

  private moveStick(clientX: number, clientY: number): void {
    let dx = clientX - this.originX
    let dy = clientY - this.originY
    const len = Math.hypot(dx, dy)
    if (len > STICK_RADIUS) {
      dx = (dx / len) * STICK_RADIUS
      dy = (dy / len) * STICK_RADIUS
    }
    this.knob.style.transform = `translate3d(${dx}px, ${dy}px, 0)`
    let nx = dx / STICK_RADIUS
    let ny = -dy / STICK_RADIUS
    // Small dead zone so a resting thumb does not drift the aircraft.
    const mag = Math.hypot(nx, ny)
    const dead = 0.07
    if (mag < dead) {
      nx = 0
      ny = 0
    } else {
      const scale = (mag - dead) / (1 - dead) / mag
      nx *= scale
      ny *= scale
    }
    this.input.setTouchStick(nx, ny)
  }

  private releaseStick(): void {
    this.stickPointer = -1
    this.base.classList.remove('is-active')
    this.knob.style.transform = ''
    this.input.releaseTouchStick()
  }

  private moveThrottle(clientY: number): void {
    const rect = this.track.getBoundingClientRect()
    const v = 1 - (clientY - rect.top) / rect.height
    this.input.setThrottle(Math.min(1, Math.max(0, v)))
    this.sync()
  }

  /** Reflect `input.throttle` (which keys and gamepad also change) in the slider. */
  sync(): void {
    const percent = Math.round(this.input.throttle * 100)
    if (percent === this.lastPercent) return
    this.lastPercent = percent
    const p = `${this.input.throttle * 100}%`
    this.fill.style.height = p
    this.thumb.style.bottom = p
    this.valueLabel.textContent = `${percent}%`
    this.slider.setAttribute('aria-valuenow', String(percent))
  }

  /** Cancel any active drag (pause, crash, screen change). */
  release(): void {
    if (this.stickPointer !== -1) this.releaseStick()
    this.throttlePointer = -1
    this.slider.classList.remove('is-active')
  }

  setVisible(visible: boolean): void {
    this.root.classList.toggle('is-visible', visible)
    if (!visible) this.release()
  }
}
