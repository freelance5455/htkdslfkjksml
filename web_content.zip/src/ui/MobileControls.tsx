import { useCallback, useRef, useState } from 'react';
import { engine } from '../game/engine';

/** Touch controls: analog stick, action pad, camera drag zone. */
export default function MobileControls() {
  const [look, setLook] = useState(false);

  return (
    <div className="fixed inset-0 z-20 select-none touch-none">
      {/* camera look zone (behind the buttons) */}
      <div
        className="absolute inset-0"
        style={{ touchAction: 'none' }}
        onPointerDown={(e) => {
          (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
          setLook(true);
          (e.currentTarget as HTMLElement).dataset.lx = String(e.clientX);
          (e.currentTarget as HTMLElement).dataset.ly = String(e.clientY);
        }}
        onPointerMove={(e) => {
          if (!look) return;
          const el = e.currentTarget as HTMLElement;
          const lx = Number(el.dataset.lx ?? e.clientX);
          const ly = Number(el.dataset.ly ?? e.clientY);
          engine.look(e.clientX - lx, e.clientY - ly);
          el.dataset.lx = String(e.clientX);
          el.dataset.ly = String(e.clientY);
        }}
        onPointerUp={() => setLook(false)}
        onPointerCancel={() => setLook(false)}
      />

      <Joystick />

      {/* right action cluster */}
      <div className="absolute bottom-4 right-3 flex flex-col items-end gap-2 pointer-events-none z-10">
        <div className="flex gap-2 pointer-events-auto">
          <ActionButton
            label="PHONE"
            icon="📱"
            onDown={() => engine.setButton('phone', true)}
            onUp={() => engine.setButton('phone', false)}
            className="!w-12 !h-12 !text-base !bg-sky-500/80"
          />
          <ActionButton
            label="GEAR"
            icon="🎒"
            onDown={() => engine.setButton('inventory', true)}
            onUp={() => engine.setButton('inventory', false)}
            className="!w-12 !h-12 !text-base !bg-violet-500/80"
          />
          <ActionButton
            label="MAP"
            icon="🗺️"
            onDown={() => engine.setButton('map', true)}
            onUp={() => engine.setButton('map', false)}
            className="!w-12 !h-12 !text-base !bg-emerald-500/80"
          />
        </div>

        <div className="pointer-events-auto flex items-end gap-2">
          <div className="flex flex-col gap-2">
            <ActionButton
              label="SIT"
              icon="🪑"
              onDown={() => engine.setButton('sit', true)}
              onUp={() => engine.setButton('sit', false)}
              className="!w-12 !h-12 !text-base !bg-zinc-600/80"
            />
            <ActionButton
              label="AIM"
              icon="🎯"
              onDown={() => engine.setButton('aim', true)}
              onUp={() => engine.setButton('aim', false)}
              className="!w-12 !h-12 !text-base !bg-zinc-600/80"
            />
          </div>

          <ActionButton
            label="RUN"
            icon="🏃"
            onDown={() => engine.setButton('run', true)}
            onUp={() => engine.setButton('run', false)}
            className="!w-14 !h-14 !text-lg !bg-amber-500/85"
          />

          <div className="flex flex-col gap-2">
            <ActionButton
              label="JUMP"
              icon="⤴️"
              onDown={() => engine.setButton('jump', true)}
              onUp={() => engine.setButton('jump', false)}
              className="!w-14 !h-14 !text-xl !bg-sky-600/85"
            />
            <ActionButton
              label="E"
              icon="🚪"
              onDown={() => engine.setButton('enter', true)}
              onUp={() => engine.setButton('enter', false)}
              className="!w-14 !h-12 !text-lg !bg-emerald-600/85"
            />
          </div>

          <ActionButton
            label="FIRE"
            icon="🔥"
            onDown={() => engine.setButton('fire', true)}
            onUp={() => engine.setButton('fire', false)}
            className="!w-16 !h-16 !text-2xl !bg-red-600/85"
          />
        </div>
      </div>

    </div>
  );
}

function ActionButton({
  label,
  icon,
  onDown,
  onUp,
  className = '',
}: {
  label: string;
  icon: string;
  onDown: () => void;
  onUp: () => void;
  className?: string;
}) {
  return (
    <button
      onPointerDown={(e) => {
        e.preventDefault();
        e.stopPropagation();
        onDown();
      }}
      onPointerUp={(e) => {
        e.preventDefault();
        e.stopPropagation();
        onUp();
      }}
      onPointerLeave={() => onUp()}
      className={`relative w-14 h-14 rounded-full bg-white/10 border border-white/25 backdrop-blur-md flex flex-col items-center justify-center text-2xl active:scale-90 transition ${className}`}
    >
      <span className="leading-none">{icon}</span>
      <span className="text-[7px] font-bold tracking-wider text-white/80 mt-0.5">{label}</span>
    </button>
  );
}

function Joystick() {
  const baseRef = useRef<HTMLDivElement>(null);
  const knobRef = useRef<HTMLDivElement>(null);
  const active = useRef(false);
  const origin = useRef({ x: 0, y: 0 });

  const move = useCallback((cx: number, cy: number) => {
    const dx = cx - origin.current.x;
    const dy = cy - origin.current.y;
    const max = 52;
    const len = Math.hypot(dx, dy);
    const k = len > max ? max / len : 1;
    const kx = dx * k;
    const ky = dy * k;
    if (knobRef.current) knobRef.current.style.transform = `translate(${kx}px, ${ky}px)`;
    engine.touch.mx = Math.max(-1, Math.min(1, kx / max));
    engine.touch.my = Math.max(-1, Math.min(1, -ky / max));
  }, []);

  return (
    <div
      ref={baseRef}
      className="absolute left-4 bottom-4 w-32 h-32 rounded-full bg-black/35 border border-white/20 backdrop-blur-sm flex items-center justify-center pointer-events-auto"
      style={{ touchAction: 'none' }}
      onPointerDown={(e) => {
        e.preventDefault();
        e.stopPropagation();
        active.current = true;
        const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
        origin.current = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
        (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
        move(e.clientX, e.clientY);
      }}
      onPointerMove={(e) => {
        if (!active.current) return;
        move(e.clientX, e.clientY);
      }}
      onPointerUp={() => {
        active.current = false;
        engine.touch.mx = 0;
        engine.touch.my = 0;
        if (knobRef.current) knobRef.current.style.transform = 'translate(0,0)';
      }}
      onPointerCancel={() => {
        active.current = false;
        engine.touch.mx = 0;
        engine.touch.my = 0;
        if (knobRef.current) knobRef.current.style.transform = 'translate(0,0)';
      }}
    >
      <div
        ref={knobRef}
        className="w-14 h-14 rounded-full bg-white/25 border border-white/40 shadow-lg"
        style={{ transition: 'none' }}
      />
    </div>
  );
}
