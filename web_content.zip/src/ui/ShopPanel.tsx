import { useState } from 'react';
import { engine } from '../game/engine';
import { useHud, fmtMoney } from './useHud';

/** In-store purchase panel used inside the Phone Store and TORQUE Garage. */
export default function ShopPanel() {
  const hud = useHud();
  const shop = engine.shopTarget;
  const [tab, setTab] = useState<'goods' | 'mods'>('goods');
  if (!hud.shopOpen || !shop) return null;

  const isMod = shop.kind === 'mod';

  return (
    <div
      className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={() => (engine.shopOpen = false)}
    >
      <div
        className="w-full max-w-lg bg-[#0d1015]/95 border border-white/12 rounded-xl overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-5 py-3 border-b border-white/10 bg-gradient-to-r from-amber-500/12 to-transparent flex items-center justify-between">
          <div>
            <h3 className="text-white font-bold tracking-widest text-sm uppercase">
              {isMod ? 'TORQUE GARAGE' : 'CITY PHONE STORE'}
            </h3>
            <p className="text-[11px] text-white/45">Balance {fmtMoney(hud.money)}</p>
          </div>
          <button onClick={() => (engine.shopOpen = false)} className="text-white/60 hover:text-white">
            ✕
          </button>
        </div>

        {isMod && (
          <div className="flex gap-2 px-4 pt-3">
            {(
              [
                ['goods', 'SERVICES'],
                ['mods', 'CUSTOMISE'],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                onClick={() => setTab(id)}
                className={`px-3 py-1.5 rounded-md text-[11px] font-bold tracking-wider ${
                  tab === id ? 'bg-amber-500 text-black' : 'bg-white/5 text-white/60'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        )}

        <div className="p-4 space-y-2 max-h-[60vh] overflow-y-auto">
          {(tab === 'mods' ? modItems : shop.shopItems ?? []).map((item) => (
            <div
              key={item.id}
              className="flex items-center gap-3 bg-white/5 rounded-lg p-3 border border-white/10"
            >
              <span className="text-xl">{(item as any).icon ?? '🛠️'}</span>
              <div className="flex-1">
                <div className="text-[12px] font-semibold text-white">{item.label}</div>
                <div className="text-[11px] text-amber-300">{fmtMoney(item.price)}</div>
              </div>
              <button
                onClick={() => {
                  if (isMod && item.kind !== 'goods') engine.applyMod(item.kind);
                  else engine.buyItem(item.id, item.price);
                }}
                className="text-[10px] font-bold tracking-wider rounded px-3 py-1.5 bg-amber-500 text-black active:scale-95"
              >
                BUY
              </button>
            </div>
          ))}
          {isMod && tab === 'mods' && (
            <div className="text-[11px] text-white/45 bg-white/5 rounded-lg p-3 border border-white/10">
              Custom paint applies to the car you are sitting in. Engine tunes raise top speed and
              acceleration. Sport tyres improve grip.
            </div>
          )}
        </div>

        <div className="px-5 py-3 border-t border-white/10 text-[11px] text-white/45">
          Press E again or close this panel to leave the counter.
        </div>
      </div>
    </div>
  );
}

const modItems = [
  { id: 'paint', label: 'Custom Paint Job', price: 400, kind: 'paint', icon: '🎨' },
  { id: 'engine', label: 'Engine Tune (+25% power)', price: 1200, kind: 'engine', icon: '🔧' },
  { id: 'tires', label: 'Sport Tyres (+grip)', price: 600, kind: 'tires', icon: '🛞' },
  { id: 'plate', label: 'Custom Plate', price: 250, kind: 'plate', icon: '🔖' },
];
