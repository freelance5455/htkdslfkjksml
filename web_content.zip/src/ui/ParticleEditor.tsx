import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, Play, Pause, RefreshCw, Flame } from 'lucide-react';
import { PARTICLE_PRESETS, ParticleEmitterConfig } from '../particles/particleSystem';
import { audioSystem } from '../audio/audioManager';

export const ParticleEditor: React.FC = () => {
  const [activeConfig, setActiveConfig] = useState<ParticleEmitterConfig>(PARTICLE_PRESETS[0]);
  const [isPlaying, setIsPlaying] = useState(true);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    interface Particle {
      x: number;
      y: number;
      vx: number;
      vy: number;
      life: number;
      maxLife: number;
      size: number;
      color: string;
    }

    let particles: Particle[] = [];
    let animationId: number;
    let lastEmit = performance.now();

    const animate = (time: number) => {
      animationId = requestAnimationFrame(animate);

      // Clear with dark alpha trail
      ctx.fillStyle = 'rgba(13, 17, 23, 0.25)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      if (isPlaying) {
        // Emit new particles
        const emitInterval = 1000 / activeConfig.rate;
        if (time - lastEmit >= emitInterval) {
          lastEmit = time;
          const angle = (Math.random() - 0.5) * activeConfig.spread * Math.PI - Math.PI / 2;
          const speed = activeConfig.speed * (0.8 + Math.random() * 0.4) * 35;
          particles.push({
            x: canvas.width / 2,
            y: canvas.height * 0.7,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed,
            life: 0,
            maxLife: activeConfig.lifetime,
            size: activeConfig.size * 22,
            color: activeConfig.colorStart,
          });
        }
      }

      // Update & Draw particles
      const dt = 0.016;
      particles.forEach((p, idx) => {
        p.life += dt;
        if (p.life >= p.maxLife) {
          particles.splice(idx, 1);
          return;
        }

        p.vy += activeConfig.gravity * 30 * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;

        const progress = p.life / p.maxLife;
        const currentSize = p.size * (1 - progress);

        ctx.fillStyle = progress > 0.5 ? activeConfig.colorEnd : activeConfig.colorStart;
        ctx.beginPath();
        ctx.arc(p.x, p.y, Math.max(1, currentSize), 0, Math.PI * 2);
        ctx.fill();
      });
    };

    animationId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationId);
  }, [activeConfig, isPlaying]);

  return (
    <div className="flex flex-col h-full bg-[#11161f] text-slate-300 text-xs p-3 space-y-4 overflow-y-auto select-none">
      <div className="flex items-center justify-between border-b border-[#21262d] pb-2">
        <div className="flex items-center space-x-2">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span className="font-bold text-slate-100 text-xs tracking-wide">PARTICLE LAB</span>
        </div>
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          className="p-1 rounded bg-[#161b22] border border-[#30363d] text-slate-300 hover:text-white"
        >
          {isPlaying ? <Pause className="w-3.5 h-3.5 text-amber-400" /> : <Play className="w-3.5 h-3.5 text-emerald-400" />}
        </button>
      </div>

      {/* Particle Canvas Viewport */}
      <div className="flex flex-col items-center bg-[#0d1117] p-2 rounded border border-[#21262d]">
        <canvas ref={canvasRef} width={240} height={160} className="rounded w-full max-w-[240px] h-[160px]" />
        <div className="text-[10px] text-slate-400 mt-1 font-mono">{activeConfig.name} Simulator</div>
      </div>

      {/* Particle Tuning Parameters */}
      <div className="bg-[#161b22] p-3 rounded border border-[#21262d] space-y-3">
        <div className="text-[11px] font-semibold text-slate-200">Emitter Dynamics</div>

        <div className="space-y-1">
          <div className="flex justify-between text-[10px]">
            <span className="text-slate-400">Emission Rate</span>
            <span className="font-mono text-cyan-400">{activeConfig.rate} /s</span>
          </div>
          <input
            type="range"
            min="10"
            max="200"
            step="5"
            value={activeConfig.rate}
            onChange={(e) => setActiveConfig({ ...activeConfig, rate: parseInt(e.target.value) })}
            className="w-full accent-cyan-500 cursor-pointer"
          />
        </div>

        <div className="space-y-1">
          <div className="flex justify-between text-[10px]">
            <span className="text-slate-400">Initial Velocity</span>
            <span className="font-mono text-cyan-400">{activeConfig.speed.toFixed(1)} m/s</span>
          </div>
          <input
            type="range"
            min="0.5"
            max="10.0"
            step="0.5"
            value={activeConfig.speed}
            onChange={(e) => setActiveConfig({ ...activeConfig, speed: parseFloat(e.target.value) })}
            className="w-full accent-cyan-500 cursor-pointer"
          />
        </div>

        <div className="space-y-1">
          <div className="flex justify-between text-[10px]">
            <span className="text-slate-400">Lifetime</span>
            <span className="font-mono text-cyan-400">{activeConfig.lifetime.toFixed(1)}s</span>
          </div>
          <input
            type="range"
            min="0.5"
            max="5.0"
            step="0.2"
            value={activeConfig.lifetime}
            onChange={(e) => setActiveConfig({ ...activeConfig, lifetime: parseFloat(e.target.value) })}
            className="w-full accent-cyan-500 cursor-pointer"
          />
        </div>

        <div className="space-y-1">
          <div className="flex justify-between text-[10px]">
            <span className="text-slate-400">Gravity Scale</span>
            <span className="font-mono text-cyan-400">{activeConfig.gravity.toFixed(1)}</span>
          </div>
          <input
            type="range"
            min="-5.0"
            max="5.0"
            step="0.5"
            value={activeConfig.gravity}
            onChange={(e) => setActiveConfig({ ...activeConfig, gravity: parseFloat(e.target.value) })}
            className="w-full accent-cyan-500 cursor-pointer"
          />
        </div>

        {/* Colors */}
        <div className="flex items-center justify-between text-[10px]">
          <span className="text-slate-400">Color Ramp</span>
          <div className="flex items-center space-x-2">
            <input
              type="color"
              value={activeConfig.colorStart}
              onChange={(e) => setActiveConfig({ ...activeConfig, colorStart: e.target.value })}
              className="w-5 h-5 rounded border border-[#30363d] bg-transparent cursor-pointer"
            />
            <span>→</span>
            <input
              type="color"
              value={activeConfig.colorEnd}
              onChange={(e) => setActiveConfig({ ...activeConfig, colorEnd: e.target.value })}
              className="w-5 h-5 rounded border border-[#30363d] bg-transparent cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Presets */}
      <div className="space-y-2">
        <div className="text-[11px] font-semibold text-slate-200">Emitter Presets</div>
        <div className="grid grid-cols-2 gap-1.5">
          {PARTICLE_PRESETS.map((p) => (
            <button
              key={p.id}
              onClick={() => {
                setActiveConfig(p);
                audioSystem.playSound('synth_laser', { pitch: 1.6, volume: 0.2 });
              }}
              className={`p-2 rounded border text-left text-[10px] transition-colors ${
                activeConfig.id === p.id
                  ? 'bg-cyan-950/80 border-cyan-500 text-cyan-300 font-semibold'
                  : 'bg-[#161b22] border-[#21262d] text-slate-300 hover:text-white'
              }`}
            >
              {p.name}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
