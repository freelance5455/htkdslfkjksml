/* ==========================================================================
   ui/screens/money.js — بدهی، استقلال مالی، شبیه‌ساز ثروت، سناریوی آینده
   ========================================================================== */

import { State } from '../../store.js';
import { reg } from '../actions.js';
import { register, section, card, M, FA, toast, kv, bar, emptyBox, disclaimer, render, modal, closeModal } from '../shell.js';
import { debtPlan, freedomCalc, simulateScenarios, projectWealth, doNothingVsPlan, financeMetrics } from '../../engines/financial-engine.js';
import { lineChart, barChart, ring, hBars, CHART_COLORS } from '../../charts.js';
import { fmtCompact, pct, toFaDigits, esc, clamp, round } from '../../utils.js';

/* ----------------------------------------------------------------- بدهی */
function debtView() {
  const state = State.get();
  const m = financeMetrics(state);
  const extra = state.__debtExtra || 0;
  const plan = debtPlan(state, extra);
  if (!plan.hasDebt) {
    return card('<div class="card__title">🕊️ بدهی فعالی نداری</div><p class="tiny">اگر بدهی داری، از «ثروت من → بدهی‌ها» آن را اضافه کن تا مقایسه روش‌های بازپرداخت انجام شود.</p>' +
      '<button class="btn btn--primary" data-act="fin.addDebt">افزودن بدهی</button>', '');
  }
  const rec = plan[plan.recommended];
  let html = '';
  html += section('مقایسه روش‌های بازپرداخت', card(
    kv('مجموع بدهی', fmtCompact(m.debtTotal, state.profile)) +
    kv('قسط ماهانه فعلی', fmtCompact(m.monthlyDebtPayment, state.profile)) +
    kv('نسبت قسط به درآمد', pct(m.debtToIncome)) +
    '<div class="field mt"><label>پرداخت اضافی ماهانه: ' + fmtCompact(extra, state.profile) + '</label>' +
    '<input class="range" type="range" min="0" max="' + Math.max(1, Math.round(m.income * 0.4)) + '" step="' + Math.max(1, Math.round(m.income * 0.01)) + '" value="' + extra + '" data-change="debt.extra"></div>' +
    '<div class="scrollx"><table class="tbl"><tr><th>روش</th><th class="n">مدت</th><th class="n">سود پرداختی</th></tr>' +
    '<tr><td>بهمن (بالاترین نرخ بهره)</td><td class="n">' + FA(plan.avalanche.months) + ' ماه</td><td class="n">' + fmtCompact(plan.avalanche.totalInterest, state.profile) + '</td></tr>' +
    '<tr><td>گلوله برفی (کوچک‌ترین مبلغ)</td><td class="n">' + FA(plan.snowball.months) + ' ماه</td><td class="n">' + fmtCompact(plan.snowball.totalInterest, state.profile) + '</td></tr></table></div>' +
    '<div class="alert alert--ok mt"><i>🏆</i><div class="tiny"><b>پیشنهاد برای تو:</b> ' + esc(plan.why) + '</div></div>' +
    '<p class="tiny mt">اختلاف سود دو روش: ' + fmtCompact(plan.savingByMethod, state.profile) + '</p>', ''));
  html += section('ترتیب پرداخت پیشنهادی', hBars(rec.orderNames.map((n, i) => ({ label: (i + 1) + '. ' + n, value: rec.orderNames.length - i, text: i === 0 ? 'اولویت اول' : 'بعدی', color: i === 0 ? CHART_COLORS.red : CHART_COLORS.gold })), {}));
  html += section('روند کاهش بدهی', card(lineChart({
    series: rec.timeline.filter((t, i) => i % Math.max(1, Math.ceil(rec.timeline.length / 12)) === 0).map((t) => ({ label: 'م' + t.month, value: t.remaining })), color: CHART_COLORS.red,
  }), ''));
  html += disclaimer('محاسبات بر اساس نرخ بهره و اقساط ثبت‌شده توسط تو است؛ شرایط واقعی قرارداد می‌تواند متفاوت باشد.');
  return html;
}

/* -------------------------------------------------------- استقلال مالی */
function freedomView() {
  const state = State.get();
  const m = financeMetrics(state);
  const a = state.__fiAssumptions || { swr: 3.5, return: 35, inflation: 30 };
  const fc = freedomCalc(state, { swr: a.swr, return: a.return, inflation: a.inflation });
  let html = '';
  html += section('وضعیت استقلال مالی', card(
    '<div class="row" style="gap:14px">' + ring(fc.progress * 100, { size: 100, color: fc.progress > 0.6 ? CHART_COLORS.green : CHART_COLORS.gold, label: 'پیشرفت' }) +
    '<div style="flex:1">' +
    kv('هزینه سالانه', fmtCompact(fc.annualExpense, state.profile)) +
    kv('سرمایه موردنیاز', fmtCompact(fc.requiredCapital, state.profile)) +
    kv('سرمایه فعلی', fmtCompact(fc.currentCapital, state.profile)) +
    kv('فاصله', fmtCompact(fc.gap, state.profile)) +
    '</div></div>', 'card--gold'));
  html += section('نتایج', card(
    kv('درآمد غیرفعال فعلی (تخمینی)', fmtCompact(fc.passiveIncome, state.profile) + ' در ماه') +
    kv('درآمد غیرفعال هدف', fmtCompact(fc.passiveIncomeTarget, state.profile) + ' در ماه') +
    kv('پس‌انداز ماهانه', fmtCompact(fc.monthlySaving, state.profile)) +
    kv('زمان تخمینی تا استقلال', '<b>' + FA(fc.years) + ' سال</b>') +
    kv('نرخ برداشت ایمن', FA(a.swr) + '٪'), ''));
  html += section('فرضیات (قابل تغییر)', card(
    '<div class="field"><label>نرخ برداشت ایمن سالانه: ' + FA(a.swr) + '٪</label><input class="range" type="range" min="2.5" max="8" step="0.5" value="' + a.swr + '" data-change="fi.swr"></div>' +
    '<div class="field"><label>بازده سالانه فرضی: ' + FA(a.return) + '٪</label><input class="range" type="range" min="0" max="120" step="5" value="' + a.return + '" data-change="fi.return"></div>' +
    '<div class="field"><label>تورم فرضی: ' + FA(a.inflation) + '٪</label><input class="range" type="range" min="0" max="100" step="5" value="' + a.inflation + '" data-change="fi.inflation"></div>' +
    '<p class="hint">با کاهش هزینه ثابت یا افزایش نرخ پس‌انداز، زمان رسیدن به استقلال به‌طور محسوس کم می‌شود.</p>', ''));
  html += section('سه اهرم اصلی', card(
    '<ol><li>کاهش هزینه ثابت: هر کاهش، ماهانه تکرار می‌شود.</li>' +
    '<li>افزایش نرخ پس‌انداز: از ' + pct(m.savingsRate) + ' به ۳۰٪ با کاهش زمان هم‌خوان است.</li>' +
    '<li>تبدیل پس‌انداز به دارایی درآمدزا: پول راکد، هدف را دورتر می‌کند.</li></ol>', ''));
  html += disclaimer('این محاسبات مدل‌سازی داخلی است، نه تضمین. بازده واقعی می‌تواند کمتر یا بیشتر باشد.');
  return html;
}

/* ------------------------------------------------------------ شبیه‌ساز */
function simulatorView() {
  const state = State.get();
  const m = financeMetrics(state);
  const p = state.__sim || {};
  const input = {
    startCapital: p.startCapital != null ? p.startCapital : m.investable,
    income: p.income != null ? p.income : m.income,
    savingsRatePct: p.savingsRatePct != null ? p.savingsRatePct : Math.max(0, round(m.savingsRate * 100, 0)),
    incomeGrowthPct: p.incomeGrowthPct != null ? p.incomeGrowthPct : 15,
    returnPct: p.returnPct != null ? p.returnPct : 35,
    inflationPct: p.inflationPct != null ? p.inflationPct : 30,
    years: p.years || 20,
  };
  const sim = simulateScenarios(state, input);
  let html = '';
  html += section('ورودی‌های شبیه‌ساز', card(
    slider('سرمایه اولیه', fmtCompact(input.startCapital, state.profile), 0, Math.max(1e9, m.income * 12), Math.max(1, Math.round(m.income * 0.5)), input.startCapital, 'sim.capital') +
    slider('درآمد ماهانه', fmtCompact(input.income, state.profile), 0, Math.max(1e8, m.income * 3), Math.max(1, Math.round(m.income * 0.05)), input.income, 'sim.income') +
    slider('نرخ پس‌انداز (٪)', FA(input.savingsRatePct) + '٪', 0, 80, 1, input.savingsRatePct, 'sim.rate') +
    slider('رشد سالانه درآمد (٪)', FA(input.incomeGrowthPct) + '٪', 0, 120, 5, input.incomeGrowthPct, 'sim.growth') +
    slider('بازده سالانه سرمایه‌گذاری (٪)', FA(input.returnPct) + '٪', 0, 200, 5, input.returnPct, 'sim.return') +
    slider('تورم سالانه (٪)', FA(input.inflationPct) + '٪', 0, 150, 5, input.inflationPct, 'sim.inflation') +
    slider('مدت (سال)', FA(input.years) + ' سال', 1, 40, 1, input.years, 'sim.years'), ''));

  html += section('مقایسه سه سناریو', card(lineChart({
    series: sim.scenarios.map((s) => ({ label: s.fa, value: s.finalReal })),
    color: CHART_COLORS.gold, height: 150, labels: true,
  }), ''));
  html += section('جزئیات سناریوها', sim.scenarios.map((s) => card(
    '<div class="row row--between"><div class="card__title">' + esc(s.fa) + '</div><span class="chip">' + esc(s.note) + '</span></div>' +
    kv('ارزش واقعی پایان دوره (پس از تورم)', fmtCompact(s.finalReal, state.profile)) +
    kv('ارزش اسمی', fmtCompact(s.final.capital, state.profile)) +
    '<div class="mt">' + bar(Math.min(100, (s.finalReal / Math.max(1, sim.scenarios[2].finalReal)) * 100), 'bar--gold') + '</div>' +
    '<div class="btn-row mt"><button class="btn btn--sm" data-act="sim.apply" data-k="' + s.key + '">استفاده از این سناریو</button></div>', 'card--flat')).join(''));
  html += section('پیش‌بینی سال به سال (سناریوی متعادل)', card(
    '<div class="scrollx"><table class="tbl"><tr><th>سال</th><th class="n">سرمایه (اسمی)</th><th class="n">ارزش واقعی</th></tr>' +
    sim.scenarios[1].series.filter((r, i) => i % Math.max(1, Math.ceil(sim.scenarios[1].series.length / 10)) === 0)
      .map((r) => '<tr><td>' + FA(r.year) + '</td><td class="n">' + fmtCompact(r.capital, state.profile) + '</td><td class="n">' + fmtCompact(r.real, state.profile) + '</td></tr>').join('') +
    '</table></div>', ''));
  html += disclaimer('این محاسبات پیش‌بینی قطعی آینده نیستند. بازده واقعی متغیر است و می‌تواند منفی هم باشد.');
  return html;
}
function slider(label, text, min, max, step, value, changeKey) {
  return '<div class="field"><label>' + label + ': <b class="num">' + text + '</b></label>' +
    '<input class="range" type="range" min="' + min + '" max="' + max + '" step="' + step + '" value="' + value + '" data-change="' + changeKey + '"></div>';
}

/* ------------------------------------------------ «اگر هیچ چیز را تغییر ندهم» */
function futureView() {
  const state = State.get();
  const cmp = doNothingVsPlan(state, [1, 3, 5, 10, 20]);
  let html = '';
  html += '<div class="alert alert--warn mb"><i>🔮</i><div class="tiny">این صفحه دو سناریوی مدل‌سازی‌شده را مقایسه می‌کند: «اگر هیچ چیز را تغییر ندهم» و «با اجرای برنامه». اینها پیش‌بینی قطعی نیستند؛ ابزار تصمیم‌گیری‌اند.</div></div>';
  html += section('مقایسه دو سناریو', card(
    '<div class="scrollx"><table class="tbl"><tr><th>بازه</th><th class="n">بدون تغییر</th><th class="n">با اجرای برنامه</th><th class="n">اختلاف</th></tr>' +
    cmp.rows.map((r) => '<tr><td>' + FA(r.year) + ' سال</td><td class="n">' + fmtCompact(r.noChange, state.profile) + '</td><td class="n">' + fmtCompact(r.withPlan, state.profile) + '</td><td class="n pos">+' + fmtCompact(r.diff, state.profile) + '</td></tr>').join('') +
    '</table></div>', ''));
  html += section('نمودار مقایسه', card(lineChart({
    series: cmp.rows.map((r) => ({ label: r.year + 'y', value: r.withPlan })), color: CHART_COLORS.green, height: 150,
  }), ''));
  html += section('چرا این تفاوت رخ می‌دهد', card(
    '<ol><li><b>نرخ پس‌انداز:</b> برنامه پس‌انداز را حدود ۲۰ درصد‌واحد بالا می‌برد.</li>' +
    '<li><b>رشد درآمد:</b> با مهارت و فروش، درآمد سالانه رشد بیشتری می‌گیرد.</li>' +
    '<li><b>ترکیب (Compound):</b> زمان، اختلاف را چند برابر می‌کند.</li>' +
    '<li><b>کنترل هزینه:</b> جلوگیری از رشد هزینه همراه درآمد.</li></ol>' +
    '<p class="tiny">تورم فرضی محاسبه: ' + FA(cmp.inflation) + '٪ — همه اعداد به ارزش واقعی (پس از تورم) گزارش شده‌اند.</p>', ''));
  html += '<div class="btn-row"><button class="btn btn--primary" data-act="ui.nav" data-id="path">شروع برنامه</button>' +
    '<button class="btn" data-act="ui.nav" data-id="simulator">شبیه‌ساز پیشرفته</button></div>';
  html += disclaimer('تصمیم نهایی و مسئولیت آن با تو است؛ برنامه هیچ نتیجه‌ای را تضمین نمی‌کند.');
  return html;
}

/* --------------------------------------------------------------- اکشن‌ها */
reg('debt', {
  extra(el) {
    const v = +el.value || 0;
    State.update((s) => { s.__debtExtra = v; }, { silent: true });
    const label = el.parentElement.querySelector('label');
    if (label) label.innerHTML = 'پرداخت اضافی ماهانه: <b class="num">' + fmtCompact(v, State.get().profile) + '</b>';
    clearTimeout(window.__debtT);
    window.__debtT = setTimeout(() => render(), 220);
  },
});

reg('fi', {
  swr(el) { setFI('swr', +el.value); },
  return(el) { setFI('return', +el.value); },
  inflation(el) { setFI('inflation', +el.value); },
});
function setFI(key, val) {
  State.update((s) => { s.__fiAssumptions = { ...(s.__fiAssumptions || { swr: 3.5, return: 35, inflation: 30 }), [key]: val }; }, { silent: true });
  clearTimeout(window.__fiT);
  window.__fiT = setTimeout(() => render(), 220);
}

reg('sim', {
  capital(el) { setSim('startCapital', +el.value); },
  income(el) { setSim('income', +el.value); },
  rate(el) { setSim('savingsRatePct', +el.value); },
  growth(el) { setSim('incomeGrowthPct', +el.value); },
  return(el) { setSim('returnPct', +el.value); },
  inflation(el) { setSim('inflationPct', +el.value); },
  years(el) { setSim('years', +el.value); },
  apply(el, ds) {
    const map = { conservative: { returnPct: 20, incomeGrowthPct: 5 }, balanced: { returnPct: 35, incomeGrowthPct: 15 }, aggressive: { returnPct: 55, incomeGrowthPct: 30 } };
    State.update((s) => { s.__sim = { ...(s.__sim || {}), ...map[ds.k] }; });
    toast('فرض‌های سناریو اعمال شد'); render();
  },
});
function setSim(key, val) {
  State.update((s) => { s.__sim = { ...(s.__sim || {}), [key]: val }; }, { silent: true });
  clearTimeout(window.__simT);
  window.__simT = setTimeout(() => render(), 220);
}

register('debt', { title: 'بدهی', eyebrow: 'روش‌های بازپرداخت', render: debtView, tab: false });
register('freedom', { title: 'استقلال مالی', eyebrow: 'ماشین‌حساب آزادی', render: freedomView, tab: false });
register('simulator', { title: 'شبیه‌ساز ثروت', eyebrow: 'سه سناریو', render: simulatorView, tab: false });
register('future', { title: 'اگر هیچ چیز را تغییر ندهم چه می‌شود؟', eyebrow: 'مقایسه دو آینده', render: futureView, tab: false });
