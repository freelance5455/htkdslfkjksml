/* ==========================================================================
   ui/screens/path.js — مسیر من: کشف مسیر، نقشه راه، مأموریت‌ها، برنامه معکوس
   ========================================================================== */

import { State } from '../../store.js';
import { reg } from '../actions.js';
import { register, section, card, M, FA, toast, modal, closeModal, kv, bar, emptyBox, disclaimer, go, confirmModal, render, chips } from '../shell.js';
import { discoverPaths, chooseBest, buildRoadmap, buildMissions, reversePlan, goalRealism, roadmapProgress, currentMonthPlan, UNLOCK_LEVELS, unlockLevel, PATHS } from '../../engines/roadmap-engine.js';
import { goalProbabilityFor, skillTree } from '../../engines/ai-engine.js';
import { ring } from '../../charts.js';
import { fmtCompact, pct, toFaDigits, esc, todayKey, faDate, daysBetween, clamp } from '../../utils.js';
import { addXP, logXP, XP_RULES } from '../../achievements.js';

function view(sub) {
  const state = State.get();
  const rp = roadmapProgress(state);

  let html = '';
  if (sub === 'compare') return compareView();
  if (sub === 'reverse') return reverseView();

  // Header progress
  html += '<div class="hero"><div class="row" style="gap:12px">' +
    ring(rp.percent, { size: 92, color: '#e8b44a', label: 'نقشه راه' }) +
    '<div style="flex:1"><div class="card__title">' + (state.plan.roadmap ? esc(state.plan.roadmap.pathTitle) : 'مسیر انتخاب نشده') + '</div>' +
    '<p class="tiny">ماه ' + FA(rp.currentMonth) + ' از ۱۲ • ' + FA(rp.monthsDone) + ' ماه تکمیل‌شده' +
    (state.plan.roadmap ? ' • شروع: ' + esc(faDate(state.plan.roadmap.createdAt)) : '') + '</p>' +
    '<div class="btn-row mt"><button class="btn btn--sm btn--primary" data-act="path.discover">کشف/تغییر مسیر</button>' +
    '<button class="btn btn--sm" data-act="path.recalc">بازتنظیم تطبیقی</button></div></div></div></div>';

  // Missions
  const missions = buildMissions(state);
  html += section('مأموریت‌های ثروت (Mission)', missions.map((ms) => card(
    '<div class="row row--between"><div class="card__title">' + (ms.unlocked ? '🔓' : '🔒') + ' مأموریت ' + FA(ms.level) + ': ' + esc(ms.title) + '</div>' +
    '<span class="chip ' + (ms.progress >= 1 ? 'chip--green' : '') + '">' + FA(Math.round(ms.progress * 100)) + '٪</span></div>' +
    bar(ms.progress * 100, ms.progress >= 1 ? '' : 'bar--gold') +
    '<p class="tiny mt">' + esc(ms.why) + (ms.target && ms.unit === 'money' ? ' — هدف: ' + fmtCompact(ms.target, state.profile) + ' • فعلی: ' + fmtCompact(ms.current, state.profile) : '') + '</p>',
    'card--flat')).join(''));

  // Timeline roadmap
  if (!state.plan.roadmap) {
    html += section('نقشه راه', emptyBox('🗺️', 'هنوز نقشه راهی ساخته نشده. ابتدا مسیر خود را کشف و انتخاب کن.'));
  } else {
    const rm = state.plan.roadmap;
    html += section('نقشه راه ۱۲ ماهه', '<div class="timeline">' + rm.months.map((mm) => {
      const cls = mm.done ? 'done' : (mm.n === rp.currentMonth ? 'active' : '');
      return '<div class="tl-item ' + cls + '"><h4>ماه ' + FA(mm.n) + ' — ' + esc(mm.title) + '</h4>' +
        '<p class="tiny">' + esc(mm.focus) + '</p>' +
        '<div class="chips">' + mm.tasks.map((t) => '<span class="chip">' + esc(t) + '</span>').join('') + '</div>' +
        '<div class="btn-row mt"><button class="btn btn--sm ' + (mm.done ? 'btn--green' : '') + '" data-act="path.monthDone" data-n="' + mm.n + '">' + (mm.done ? '✅ تکمیل شد' : 'علامت‌گذاری تکمیل') + '</button></div>' +
        '</div>';
    }).join('') + '</div>');
  }

  // Goal + reverse plan
  html += section('هدف و برنامه‌ریزی معکوس', state.goals.length ? state.goals.map((g) => {
    const rev = reversePlan(state, g);
    const prob = goalProbabilityFor(state, g);
    const real = goalRealism(state, g);
    const left = g.deadline ? daysBetween(todayKey(), g.deadline) : null;
    return card(
      '<div class="row row--between"><div class="card__title">🎯 ' + esc(g.title) + '</div>' +
      '<span class="chip ' + (real.verdict === 'reachable' ? 'chip--green' : real.verdict === 'stretch' ? 'chip--gold' : 'chip--red') + '">' +
      (real.verdict === 'reachable' ? 'قابل حصول' : real.verdict === 'stretch' ? 'چالشی' : 'دور از دسترس') + '</span></div>' +
      '<p class="tiny">هدف: ' + fmtCompact(g.targetAmount || 0, state.profile) + (g.deadline ? ' • مهلت: ' + esc(faDate(g.deadline)) + (left != null ? ' (' + (left >= 0 ? FA(left) + ' روز مانده' : FA(Math.abs(left)) + ' روز گذشته') + ')' : '') : '') + '</p>' +
      '<div class="row mt" style="gap:12px">' + ring(prob, { size: 84, color: prob >= 60 ? '#22c55e' : prob >= 35 ? '#e8b44a' : '#ef4444', label: 'احتمال' }) +
      '<div style="flex:1">' +
      kv('هدف ماهانه پس‌انداز', fmtCompact(rev.neededMonthlySaving, state.profile)) +
      kv('درآمد موردنیاز', fmtCompact(rev.neededIncome, state.profile)) +
      kv('فاصله تا هدف', fmtCompact(rev.gap, state.profile)) +
      '</div></div>' +
      '<div class="alert ' + (real.verdict === 'unreachable' ? 'alert--danger' : 'alert--warn') + ' mt"><i>⚠️</i><div class="tiny">' + esc(real.message) + '</div></div>' +
      (real.alternative ? '<div class="alert alert--ok mt"><i>🛠</i><div class="tiny"><b>مسیر جایگزین:</b> ' + esc(real.alternative.text || ('بازه زمانی پیشنهادی: ' + FA(real.alternative.months || 0) + ' ماه')) + '</div></div>' : '') +
      '<div class="btn-row mt"><button class="btn btn--sm" data-act="path.reverse" data-id="' + g.id + '">زنجیره معکوس کامل</button>' +
      '<button class="btn btn--sm" data-act="goal.edit" data-id="' + g.id + '">ویرایش هدف</button>' +
      '<button class="btn btn--sm btn--danger" data-act="goal.del" data-id="' + g.id + '">حذف</button></div>', 'card--flat');
  }).join('') : emptyBox('🎯', 'هدفی ثبت نشده است. یک هدف اضافه کن تا برنامه معکوس ساخته شود.'),
    { action: '<button class="btn btn--sm" data-act="goal.add">+ هدف</button>' });

  // Skill tree preview
  html += section('درخت مهارت (Skill Tree)', skillTree(state).slice(0, 3).map((s) => card(
    '<div class="card__title">' + esc(s.title) + ' — ROI ' + FA(s.roi) + '/100</div>' +
    '<div class="skill__lvl">' + s.steps.map((st) => '<i class="' + (st.lvl <= s.level ? 'on' : '') + '"></i>').join('') + '</div>' +
    '<p class="tiny mt">سطح فعلی: ' + FA(s.level) + ' از ۶ — تقاضای بازار: ' + FA(s.demand) + '/100</p>', 'card--flat')).join(''),
    { action: '<button class="btn btn--sm" data-act="ui.nav" data-id="skills">درخت کامل</button>' });

  html += disclaimer('مسیرها و درصدها بر اساس داده‌های پروفایل تو محاسبه شده‌اند و می‌توانند با تغییر شرایط به‌روزرسانی شوند.');
  return html;
}

function compareView() {
  const state = State.get();
  const paths = discoverPaths(state);
  const choice = chooseBest(state, paths);
  let html = '';
  html += '<div class="alert alert--ok mb"><i>🏆</i><div class="tiny">' + esc(choice.text) + '</div></div>';
  html += section('مقایسه مسیرها', '<div class="scrollx"><table class="tbl"><tr><th>مسیر</th><th class="n">تناسب</th><th class="n">ریسک</th><th class="n">سرمایه</th><th class="n">زمان درآمد</th><th class="n">پتانسیل</th></tr>' +
    choice.comparison.map((p) => '<tr><td>' + esc(p.fa) + '</td><td class="n">' + FA(p.fit) + '٪</td><td class="n">' + FA(p.risk) + '</td><td class="n">' + fmtCompact(p.capitalNeeded, state.profile) + '</td><td class="n">' + FA(p.timeToIncome) + ' ماه</td><td class="n">' + esc(p.potential) + '</td></tr>').join('') + '</table></div>');
  html += section('جزئیات مسیرها', paths.slice(0, 6).map((p) => card(
    '<div class="row row--between"><div class="card__title">' + p.icon + ' ' + esc(p.fa) + '</div><span class="chip chip--gold">تناسب ' + FA(p.fitPercent) + '٪</span></div>' +
    '<div class="task__meta"><span class="chip">ریسک: ' + esc(p.riskLevel) + '</span><span class="chip">سرمایه: ' + esc(p.capitalLabel) + '</span>' +
    '<span class="chip">درآمد در ' + FA(p.timeToIncomeMonths) + ' ماه</span><span class="chip chip--green">پتانسیل: ' + esc(p.potentialLabel) + '</span></div>' +
    '<p class="tiny mt">' + esc(p.why) + '</p>' +
    '<p class="tiny">' + p.reasons.map((r) => '• ' + esc(r)).join('<br>') + '</p>' +
    '<div class="alert alert--ok mt"><i>🚀</i><div class="tiny"><b>۵ قدم اول:</b><ol>' + p.firstSteps.map((s) => '<li>' + esc(s) + '</li>').join('') + '</ol></div></div>' +
    '<div class="btn-row mt"><button class="btn btn--sm btn--primary" data-act="path.choose" data-id="' + p.id + '">انتخاب این مسیر</button></div>', 'card--flat')).join(''));
  html += disclaimer('امتیاز مسیرها بر اساس مهارت، سرمایه، زمان، سن، ریسک‌پذیری و وضعیت بدهی تو محاسبه شده است.');
  return html;
}

function reverseView() {
  const state = State.get();
  const g = state.goals.find((x) => x.id === (state.__selGoal || '')) || state.goals[0];
  if (!g) return emptyBox('🎯', 'هدفی ثبت نشده است.');
  const rev = reversePlan(state, g);
  return section('زنجیره برنامه‌ریزی معکوس: ' + esc(g.title),
    card('<div class="timeline">' + rev.chain.map((c, i) => '<div class="tl-item ' + (i === 0 ? 'active' : '') + '"><h4>' + esc(c.level) + '</h4>' +
      '<p class="tiny">' + (c.value != null ? fmtCompact(c.value, state.profile) + ' — ' : '') + esc(c.text) + '</p></div>').join('') +
      '<div class="tl-item active"><h4>🔥 کار امروز</h4><p class="tiny">' + esc(rev.todayTask.title) + '</p>' +
      '<button class="btn btn--sm btn--primary mt" data-act="task.addFromReverse" data-title="' + esc(rev.todayTask.title) + '">افزودن به امروز</button></div>' +
      '</div>', ''));
}

/* --------------------------------------------------------------- اکشن‌ها */
reg('path', {
  discover() { go('path', { sub: 'compare' }); location.hash = '#/path/compare'; render(); },
  compare() { location.hash = '#/path/compare'; render(); },
  choose(el, ds) {
    State.update((s) => {
      const p = PATHS.find((x) => x.id === ds.id) || discoverPaths(s)[0];
      const built = buildRoadmap(s, p);
      s.plan.pathId = p.id;
      s.plan.roadmap = built.roadmap;
      s.gamification.xp += XP_RULES.pathChosen;
      s.gamification.history.push({ id: 'xp' + Date.now(), kind: 'pathChosen', label: 'انتخاب مسیر: ' + p.fa, xp: XP_RULES.pathChosen, at: todayKey() });
      s.meta.lastRecalc = todayKey();
    });
    toast('مسیر انتخاب و نقشه راه ۱۲ ماهه ساخته شد 🎯');
    location.hash = '#/path'; render();
  },
  monthDone(el, ds) {
    State.update((s) => {
      const rm = s.plan.roadmap;
      if (!rm) return;
      const mm = rm.months.find((x) => String(x.n) === String(ds.n));
      if (!mm) return;
      mm.done = !mm.done;
      if (mm.done) { s.gamification.xp += 50; toast('ماه ' + ds.n + ' تکمیل شد — +۵۰ XP'); }
    });
    render();
  },
  recalc() {
    let msg = '';
    State.update((s) => {
      const { recalibrate } = requireRecalc();
      const r = recalibrate(s);
      msg = r.notes.join(' ');
      if (r.adjust === 'reduce' && s.plan.roadmap) {
        s.plan.roadmap.months.forEach((mm) => { if (!mm.done && mm.tasks.length > 3) mm.tasks = mm.tasks.slice(0, 3); });
      }
      s.meta.lastRecalc = todayKey();
    });
    toast('بازتنظیم انجام شد: ' + msg);
    render();
  },
  reverse(el, ds) {
    State.update((s) => { s.__selGoal = ds.id; }, { persist: true, silent: true });
    go('path', { sub: 'reverse' });
    location.hash = '#/path/reverse'; render();
  },
});

reg('goal', {
  add() {
    modal({
      title: 'هدف جدید',
      body: '<form data-form="goal.save">' +
        '<div class="field"><label>عنوان هدف</label><input class="input" name="title" placeholder="مثلاً استقلال مالی"></div>' +
        '<div class="field"><label>نوع هدف</label><select class="select" name="type">' +
        ['freedom:استقلال مالی', 'wealth:ثروت مشخص', 'income:افزایش درآمد', 'business:ساخت کسب‌وکار', 'debt:خروج از بدهی', 'custom:سفارشی']
          .map((o) => { const p = o.split(':'); return '<option value="' + p[0] + '">' + p[1] + '</option>'; }).join('') + '</select></div>' +
        '<div class="field"><label>مبلغ هدف</label><input class="input num" name="target" inputmode="decimal" placeholder="مثلاً 1 میلیارد"></div>' +
        '<div class="field"><label>واحد پول</label><select class="select" name="unit">' +
        ['IRT:تومان', 'USD:دلار', 'EUR:یورو', 'IRR:ریال', 'OTHER:سایر'].map((o) => { const p = o.split(':'); return '<option value="' + p[0] + '">' + p[1] + '</option>'; }).join('') + '</select>' +
        '<p class="hint">اگر «میلیاردر شدن» را هدف گرفته‌ای، واحد پول مهم است: ۱ میلیارد تومان با ۱ میلیارد دلار تفاوت بزرگی دارد.</p></div>' +
        '<div class="field"><label>درآمد ماهانه هدف (اختیاری)</label><input class="input num" name="monthly" inputmode="decimal"></div>' +
        '<div class="field"><label>تاریخ هدف (میلادی YYYY-MM-DD)</label><input class="input" type="date" name="deadline"></div>' +
        '<button class="btn btn--primary btn--block" type="submit">ذخیره هدف</button></form>',
    });
  },
  edit(el, ds) {
    const g = State.get().goals.find((x) => x.id === ds.id);
    if (!g) return;
    modal({
      title: 'ویرایش هدف',
      body: '<form data-form="goal.save" data-id="' + g.id + '">' +
        '<div class="field"><label>عنوان</label><input class="input" name="title" value="' + esc(g.title) + '"></div>' +
        '<div class="field"><label>مبلغ هدف</label><input class="input num" name="target" value="' + (g.targetAmount || 0) + '"></div>' +
        '<div class="field"><label>درآمد ماهانه هدف</label><input class="input num" name="monthly" value="' + (g.monthlyIncomeTarget || 0) + '"></div>' +
        '<div class="field"><label>مهلت</label><input class="input" type="date" name="deadline" value="' + (g.deadline || '') + '"></div>' +
        '<button class="btn btn--primary btn--block" type="submit">ذخیره</button></form>',
    });
  },
  del(el, ds) {
    confirmModal('حذف هدف', 'این هدف و برنامه معکوس آن حذف می‌شود. مطمئنی؟', 'goal.delConfirm', { id: ds.id });
  },
  delConfirm(el, ds) {
    State.update((s) => { s.goals = s.goals.filter((g) => g.id !== ds.id); });
    closeModal(); toast('هدف حذف شد'); render();
  },
});

reg('form', {
  'goal.save'(fd, el) {
    const id = el && el.dataset ? el.dataset.id : null;
    State.update((s) => {
      const target = parseAmount(fd.target);
      const monthly = parseAmount(fd.monthly);
      const custom = { monthlyIncomeTarget: monthly };
      if (id) {
        const g = s.goals.find((x) => x.id === id);
        if (g) { g.title = fd.title || g.title; g.targetAmount = target; g.deadline = fd.deadline || g.deadline; g.custom = custom; }
      } else {
        s.goals.push({
          id: 'g' + Date.now(), title: fd.title || 'هدف مالی', type: fd.type || 'custom', unit: fd.unit || s.profile.currency,
          targetAmount: target, monthlyIncomeTarget: monthly, deadline: fd.deadline || null, createdAt: todayKey(), done: false, custom,
        });
      }
    });
    closeModal(); toast('هدف ذخیره شد و برنامه معکوس به‌روزرسانی شد'); render();
  },
  'task.addFromReverse'(fd) {
    State.update((s) => {
      const day = ensureDay(s, todayKey());
      day.tasks.push({ id: 't' + Date.now(), title: fd.title, cat: 'مهم‌ترین اقدام', minutes: 45, impact: 92, done: false });
    });
    toast('به کارهای امروز اضافه شد');
    location.hash = '#/today'; render();
  },
});

function parseAmount(v) {
  const s = String(v == null ? '' : v).replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
  const m = /میلیارد/.test(s) ? 1e9 : /میلیون/.test(s) ? 1e6 : /هزار/.test(s) ? 1e3 : 1;
  const n = parseFloat(s.replace(/[^\d.\-]/g, ''));
  return isNaN(n) ? 0 : n * m;
}
function requireRecalc() { return { recalibrate: recalibrateRef }; }
let recalibrateRef = null;
export function bindRecalibrate(fn) { recalibrateRef = fn; }
function requireEnsure() { return { ensureDay: ensureDayRef }; }
let ensureDayRef = null;
export function bindEnsureDay(fn) { ensureDayRef = fn; }

register('path', { title: 'مسیر من', eyebrow: 'نقشه راه ثروت', render: view, tab: true });
