/* ==========================================================================
   ui/screens/intelligence.js — هوش مالی: تحلیل‌ها، پیشنهادها، تصمیم‌یار، ریسک
   ========================================================================== */

import { State } from '../../store.js';
import { reg } from '../actions.js';
import { register, section, card, M, FA, toast, modal, closeModal, kv, bar, emptyBox, disclaimer, render, alertBox, listRow } from '../shell.js';
import { financeMetrics } from '../../engines/financial-engine.js';
import { computeScore } from '../../engines/scoring-engine.js';
import { priorities, recommendations, riskWarnings, decide, skillROI, oneBigMove, presetsForDecisions } from '../../engines/ai-engine.js';
import { discoverPaths, chooseBest } from '../../engines/roadmap-engine.js';
import { hBars, barChart, CHART_COLORS } from '../../charts.js';
import { fmtCompact, pct, toFaDigits, esc, round } from '../../utils.js';
import { ensureDay } from '../../engines/planner.js';
import { todayKey } from '../../utils.js';

let tab = 'money';

const TABS = [
  { k: 'money', fa: 'تحلیل مالی' },
  { k: 'income', fa: 'درآمد' },
  { k: 'expense', fa: 'هزینه' },
  { k: 'skill', fa: 'مهارت' },
  { k: 'path', fa: 'مسیر' },
  { k: 'rec', fa: 'پیشنهادها' },
  { k: 'decide', fa: 'تصمیم‌یار' },
  { k: 'risk', fa: 'ریسک' },
];

function view() {
  const state = State.get();
  const m = financeMetrics(state);
  const score = computeScore(state);
  let html = '';

  html += '<div class="tabs">' + TABS.map((t) => '<button class="tab ' + (t.k === tab ? 'is-active' : '') + '" data-act="intel.tab" data-k="' + t.k + '">' + t.fa + '</button>').join('') + '</div>';

  if (tab === 'money') {
    html += section('تحلیل مالی', card(
      kv('درآمد ماهانه', fmtCompact(m.income, state.profile)) +
      kv('هزینه ماهانه', fmtCompact(m.expense, state.profile)) +
      kv('پس‌انداز ماهانه', '<span class="' + (m.savings >= 0 ? 'pos' : 'neg') + '">' + fmtCompact(m.savings, state.profile) + '</span>') +
      kv('نرخ پس‌انداز', pct(m.savingsRate)) +
      kv('خالص ثروت', fmtCompact(m.netWorth, state.profile)) +
      kv('نسبت بدهی به درآمد', pct(m.debtToIncome)) +
      kv('پوشش نقدینگی', FA(m.runwayMonths) + ' ماه هزینه') +
      kv('تعداد منابع درآمد', FA(m.incomeStreams)) +
      kv('امتیاز مالی', FA(score.total) + '/1000 (' + esc(score.grade) + ')'), ''));
    html += section('مؤلفه‌های امتیاز مالی (ضعیف‌ترین‌ها)', hBars(score.components.slice(0, 8).map((c) => ({ label: c.label, value: c.value, text: FA(c.value) + '/100', color: c.value < 35 ? CHART_COLORS.red : c.value < 60 ? CHART_COLORS.gold : CHART_COLORS.green })), {}));
    html += section('اولویت‌های فعلی (Rule Engine)', priorities(state).priorities.map((p, i) => card(
      '<div class="card__title">' + FA(i + 1) + '. ' + esc(p.title) + '</div>' +
      '<p class="tiny">' + esc(p.why) + '</p>' +
      '<div class="chips mt">' + p.actions.map((a) => '<span class="chip">' + esc(a) + '</span>').join('') + '</div>', 'card--flat')).join(''));
  }

  if (tab === 'income') {
    const incomes = state.finance.incomes || [];
    html += section('منابع درآمد', incomes.length ? incomes.map((i) => listRow({
      icon: i.kind === 'salary' ? '💼' : i.kind === 'side' ? '🧩' : i.kind === 'business' ? '🏢' : '📈',
      title: i.label || 'درآمد', sub: (i.type === 'fixed' ? 'ثابت' : 'متغیر') + ' — ' + kindFa(i.kind),
      amount: fmtCompact(i.amount, state.profile), right: '<button class="iconbtn" data-act="fin.delIncome" data-id="' + i.id + '">🗑</button>',
    })).join('') : emptyBox('💼', 'منبع درآمدی ثبت نشده است.'), { action: '<button class="btn btn--sm btn--primary" data-act="fin.addIncome">+ درآمد</button>' });

    html += section('شتاب‌دهنده درآمد (Income Accelerator)', card(
      '<div class="row row--between"><div><div class="card__title">سطح فعلی: ' + fmtCompact(m.income, state.profile) + '</div>' +
      '<p class="tiny">هدف پیشنهادی ۱۲ ماهه: ' + fmtCompact(Math.round(m.income * 1.6), state.profile) + '</p></div>' +
      '<span class="chip chip--gold">' + pct(Math.min(1.6, 1.6)) + '</span></div>' +
      '<div class="mt">' + bar((m.income / Math.max(1, m.income * 1.6)) * 100, 'bar--gold') + '</div>' +
      '<ol class="mt">' + incomeAccelerator(state, m).map((x) => '<li>' + esc(x) + '</li>').join('') + '</ol>', ''));
    html += section('روند ۶ ماه', card(barChart({
      series: [{ name: 'درآمد', labels: monthLabels(state), values: monthSeriesIncome(state) }], colors: [CHART_COLORS.gold], legend: false,
    }), ''));
  }

  if (tab === 'expense') {
    const cats = m.expenseByCat;
    html += section('هزینه به تفکیک دسته', cats.length ? hBars(cats.map((c) => ({ label: c.category, value: c.amount, text: fmtCompact(c.amount, state.profile), color: c.amount > m.expense * 0.3 ? CHART_COLORS.red : CHART_COLORS.blue })), {}) : emptyBox('🧾', 'هزینه‌ای ثبت نشده است.'));
    html += section('تحلیل نشتی‌ها', card(
      kv('هزینه ضروری', fmtCompact(m.essential, state.profile)) +
      kv('هزینه اختیاری', fmtCompact(m.discretionary, state.profile)) +
      kv('سهم اختیاری از کل', pct(m.expense > 0 ? m.discretionary / m.expense : 0)) +
      '<div class="alert alert--warn mt"><i>✂️</i><div class="tiny">با کاهش ۳۰٪ هزینه اختیاری، ماهانه ' + fmtCompact(m.discretionary * 0.3, state.profile) + ' و سالانه ' + fmtCompact(m.discretionary * 0.3 * 12, state.profile) + ' آزاد می‌شود.</div></div>', ''));
    html += section('هزینه‌های ثبت‌شده', (state.finance.expenses || []).length ? (state.finance.expenses).map((e) => listRow({
      icon: '🧾', title: e.label || e.category, sub: e.category, amount: fmtCompact(e.amount, state.profile),
      right: '<button class="iconbtn" data-act="fin.delExpense" data-id="' + e.id + '">🗑</button>',
    })).join('') : emptyBox('🧾', 'هزینه ماهانه‌ای ثبت نشده.'), { action: '<button class="btn btn--sm btn--primary" data-act="fin.addExpense">+ هزینه</button>' });
  }

  if (tab === 'skill') {
    const roi = skillROI(state);
    html += section('بازده مهارت‌ها (ROI)', roi.map((r) => card(
      '<div class="row row--between"><div class="card__title">' + esc(r.title) + '</div><span class="chip chip--gold">ROI ' + FA(r.roi) + '</span></div>' +
      bar(r.roi, r.roi >= 70 ? '' : 'bar--gold') +
      '<div class="task__meta mt"><span class="chip">تقاضا ' + FA(r.demand) + '/100</span><span class="chip">کمیابی ' + FA(r.rarity) + '</span><span class="chip">سطح ' + FA(r.level) + '/6</span></div>' +
      '<p class="tiny mt">' + esc(r.reason) + '</p>' +
      '<div class="btn-row mt"><button class="btn btn--sm btn--primary" data-act="skill.practice" data-t="' + esc(r.title) + '">۶۰ دقیقه تمرین امروز</button>' +
      '<button class="btn btn--sm" data-act="skill.add" data-t="' + esc(r.title) + '">افزودن به درخت مهارت</button></div>', 'card--flat')).join(''));
  }

  if (tab === 'path') {
    const paths = discoverPaths(state);
    const ch = chooseBest(state, paths);
    html += section('بهترین نقطه شروع', card('<p>' + esc(ch.text) + '</p>' +
      '<div class="btn-row mt"><button class="btn btn--sm btn--primary" data-act="ui.nav" data-id="path">نقشه راه</button>' +
      '<button class="btn btn--sm" data-act="path.compare">مقایسه کامل</button></div>', 'card--gold'));
    html += section('امتیاز مسیرها', hBars(paths.slice(0, 6).map((p) => ({ label: p.fa, value: p.score, text: FA(p.score) + '٪', color: CHART_COLORS.gold })), {}));
  }

  if (tab === 'rec') {
    const recs = recommendations(state);
    html += section('پیشنهادهای هوشمند (مرتب‌شده بر اساس اثر)', recs.map((r) => card(
      '<div class="row row--between"><div class="card__title">⭐ ' + esc(r.title) + '</div><span class="chip chip--gold">امتیاز ' + FA(r.score) + '</span></div>' +
      '<p class="tiny">' + esc(r.why) + '</p>' +
      '<div class="grid grid-3 mt" style="gap:6px">' +
      miniKpi('اثر', FA(r.impact)) + miniKpi('دشواری', FA(r.difficulty)) + miniKpi('ریسک', FA(r.risk)) +
      miniKpi('هزینه', r.cost === 0 ? 'صفر' : fmtCompact(r.cost, state.profile)) + miniKpi('زمان', esc(r.time)) + miniKpi('احتمال موفقیت', FA(r.probability) + '٪') +
      '</div>' +
      '<div class="chips mt">' + r.actions.map((a) => '<span class="chip">' + esc(a) + '</span>').join('') + '</div>' +
      '<div class="btn-row mt"><button class="btn btn--sm btn--primary" data-act="rec.toTask" data-id="' + r.id + '">افزودن به امروز</button></div>', 'card--flat')).join(''));
  }

  if (tab === 'decide') {
    html += section('اگر جای من بودی چه کار می‌کردی؟', card(
      '<form data-form="intel.decide">' +
      '<div class="field"><label>پول نقد موجود</label><input class="input num" name="cash" inputmode="decimal" placeholder="مثلاً 100 میلیون"></div>' +
      '<div class="field"><label>درآمد ماهانه هدف</label><input class="input num" name="incomeGoal" inputmode="decimal" placeholder="مثلاً 150 میلیون"></div>' +
      '<div class="field"><label>افق زمانی (ماه)</label><input class="input num" name="horizon" inputmode="numeric" value="12"></div>' +
      '<button class="btn btn--primary btn--block" type="submit">تحلیل کن</button></form>' +
      '<p class="hint mt">برای شروع می‌توانی از سناریوهای آماده استفاده کنی:</p>' +
      '<div class="chips">' + presetsForDecisions().map((p) => '<button class="chipbtn" data-act="intel.preset" data-id="' + p.id + '">' + esc(p.title) + '</button>').join('') + '</div>', ''));
  }

  if (tab === 'risk') {
    const w = riskWarnings(state);
    html += section('هشدارهای ریسک', w.map((x) => alertBox(x.level === 'high' ? 'danger' : x.level === 'medium' ? 'warn' : x.level === 'low' ? 'info' : 'ok', x.level === 'high' ? '🚨' : x.level === 'medium' ? '⚠️' : 'ℹ️', '', x.text)).join(''));
    html += section('قوانین ریسک برنامه', card(
      '<ol><li>ریسک غیرقابل بازگشت نپذیر.</li><li>بدترین حالت را قبل از اقدام بنویس.</li>' +
      '<li>حجم ریسک متناسب با صندوق اضطراری باشد.</li><li>نقطه خروج را قبل از ورود تعیین کن.</li>' +
      '<li>۲۰٪ حاشیه زمانی و مالی برای پیش‌بینی‌نشدنی بگذار.</li></ol>', ''));
    html += disclaimer('برنامه توصیه قطعی خرید یا فروش دارایی نمی‌دهد. تصمیم نهایی با تو است.');
  }

  return html;
}

function miniKpi(l, v) { return '<div class="kpi"><span class="kpi__label">' + l + '</span><span class="kpi__value num" style="font-size:13px">' + v + '</span></div>'; }
function kindFa(k) { return { salary: 'درآمد اصلی', side: 'درآمد دوم', business: 'کسب‌وکار', investment: 'سرمایه‌گذاری', other: 'سایر' }[k] || 'سایر'; }
function monthLabels(state) {
  const { monthSeries } = reqFin();
  return monthSeries(state, 6).map((s) => s.month.slice(5));
}
function monthSeriesIncome(state) {
  const { monthSeries } = reqFin();
  return monthSeries(state, 6).map((s) => s.income);
}
function reqFin() { return { monthSeries: monthSeriesRef }; }
let monthSeriesRef = null;
export function bindMonthSeries(fn) { monthSeriesRef = fn; }

function incomeAccelerator(state, m) {
  const c = state.profile;
  const out = [];
  out.push('افزایش تخصص: یک مهارت پرتقاضا را ۹۰ روز تمرین و سه نمونه‌کار بساز.');
  out.push('خدمات جانبی: یک خدمت مشخص با قیمت مشخص به مهارت فعلی اضافه کن.');
  out.push('پروژه آزاد (فریلنسری): ۲۰ مشتری احتمالی + ۵ تماس روزانه.');
  out.push('آموزش: آموزش تخصص خود به دیگران (کارگاه، دوره، محتوا).');
  out.push('کسب‌وکار خدماتی: تبدیل خدمت به قرارداد ماهانه تکرارشونده.');
  if ((c.skills || []).indexOf('فروش') === -1) out.push('مهارت فروش را اضافه کن؛ بیشترین ضریب افزایش درآمد را دارد.');
  if (m.incomeStreams < 2) out.push('درآمد دوم بساز؛ تک‌منبعی بودن رشد را متوقف می‌کند.');
  return out;
}

reg('intel', {
  tab(el, ds) { tab = ds.k; render(); },
  preset(el, ds) {
    const p = presetsForDecisions().find((x) => x.id === ds.id);
    if (!p) return;
    const st = State.get();
    const answer = decide(st, { cash: p.cash != null ? p.cash * 1e6 : 0, incomeGoal: p.incomeGoal ? p.incomeGoal * 1e6 : 0, horizon: 12 });
    modal({ title: p.title, body: answer.text, footer: '<button class="btn btn--ghost" data-act="ui.closeModal">بستن</button><button class="btn btn--primary" data-act="rec.bigToTask">افزودن کار غالب امروز</button>' });
  },
});

reg('form', {
  'intel.decide'(fd) {
    const st = State.get();
    const answer = decide(st, { cash: parseAmount(fd.cash), incomeGoal: parseAmount(fd.incomeGoal), horizon: +fd.horizon || 12 });
    modal({
      title: 'پاسخ تصمیم‌یار', body: answer.text,
      footer: '<button class="btn btn--ghost" data-act="ui.closeModal">بستن</button><button class="btn btn--primary" data-act="rec.bigToTask">افزودن کار غالب امروز</button>',
    });
  },
});

reg('rec', {
  toTask(el, ds) {
    const r = recommendations(State.get()).find((x) => x.id === ds.id);
    if (!r) return;
    State.update((s) => {
      const day = ensureDay(s, todayKey());
      day.tasks.push({ id: 't' + Date.now(), title: r.title + ' — ' + (r.actions[0] || ''), cat: 'اقدام درآمدی', minutes: 40, impact: r.impact, done: false });
    });
    toast('به کارهای امروز اضافه شد ✅'); render();
  },
  bigToTask() {
    const bm = oneBigMove(State.get());
    State.update((s) => {
      const day = ensureDay(s, todayKey());
      if (!day.tasks.some((t) => t.title === bm.title)) day.tasks.push({ id: 't' + Date.now(), title: bm.title, cat: bm.cat, minutes: bm.minutes, impact: bm.impact, done: false });
    });
    closeModal(); toast('کار غالب امروز اضافه شد'); location.hash = '#/today'; render();
  },
});

reg('skill', {
  practice(el, ds) {
    State.update((s) => {
      const day = ensureDay(s, todayKey());
      day.tasks.push({ id: 't' + Date.now(), title: '۶۰ دقیقه تمرین هدفمند مهارت «' + ds.t + '»', cat: 'مهارت', minutes: 60, impact: 85, done: false });
    });
    toast('به کارهای امروز اضافه شد ✅'); render();
  },
  add(el, ds) {
    State.update((s) => {
      if (!s.skills.some((x) => x.title === ds.t)) s.skills.push({ id: 's' + Date.now(), title: ds.t, level: 1, note: 'تازه اضافه شد' });
    });
    toast('مهارت به درخت مهارت اضافه شد'); render();
  },
});

function parseAmount(v) {
  const s = String(v == null ? '' : v);
  const mult = /میلیارد/.test(s) ? 1e9 : /میلیون/.test(s) ? 1e6 : /هزار/.test(s) ? 1e3 : 1;
  const n = parseFloat(s.replace(/[^\d.\-]/g, ''));
  return isNaN(n) ? 0 : n * mult;
}

register('intelligence', { title: 'هوش مالی', eyebrow: 'تحلیل و تصمیم‌یار آفلاین', render: view, tab: false });
