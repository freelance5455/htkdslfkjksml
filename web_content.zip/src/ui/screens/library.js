/* ==========================================================================
   ui/screens/library.js — کتابخانه: ۱۰۰ کتاب، اصول، تمرین، اقدام + حکمت روزانه
   ========================================================================== */

import { State } from '../../store.js';
import { reg } from '../actions.js';
import { register, section, card, FA, toast, emptyBox, disclaimer, render, modal, closeModal, chips, kv } from '../shell.js';
import { categories, searchBooks, bookDetail } from '../../engines/books-engine.js';
import { BOOK_CATS } from '../../knowledge/books.js';
import { wisdomToday, wisdomList } from '../../engines/ai-engine.js';
import { toFaDigits, esc, todayKey, uid } from '../../utils.js';
import { checkAchievements, addXP, XP_RULES } from '../../achievements.js';

let cat = '';
let query = '';
let openBook = null;

function view() {
  const state = State.get();
  let html = '';

  if (openBook) return bookView(state);

  // Daily wisdom
  const w = wisdomToday(state);
  html += section('حکمت روز (Daily Wisdom)', card(
    '<p style="font-size:14.5px">«' + esc(w.text) + '»</p>' +
    '<div class="alert alert--ok mt"><i>✅</i><div class="tiny"><b>اقدام امروز:</b> ' + esc(w.action) + '</div></div>' +
    '<div class="btn-row mt"><button class="btn btn--sm btn--primary" data-act="lib.wisdomTask" data-t="' + esc(w.action) + '">افزودن به امروز</button>' +
    '<button class="btn btn--sm" data-act="lib.wisdomAll">آرشیو حکمت‌ها</button></div>', 'card--gold'));

  // Search
  html += section('جست‌وجو در کتابخانه', card(
    '<input class="input" id="libSearch" placeholder="نام کتاب، نویسنده یا موضوع…" value="' + esc(query) + '" data-change="lib.search">' +
    '<div class="chips mt"><button class="chipbtn ' + (cat === '' ? 'is-active' : '') + '" data-act="lib.cat" data-c="">همه</button>' +
    categories().map((c) => '<button class="chipbtn ' + (cat === c.key ? 'is-active' : '') + '" data-act="lib.cat" data-c="' + c.key + '">' + c.icon + ' ' + esc(c.fa) + ' (' + FA(c.count) + ')</button>').join('') + '</div>', ''));

  const books = searchBooks(query, cat);
  html += section('کتاب‌ها (' + FA(books.length) + ')', books.length ? '<div class="stack">' + books.map((b) => {
    const read = (state.learning.books || []).some((x) => x.id === b.id);
    return card(
      '<div class="row row--between"><div class="card__title">' + (BOOK_CATS[b.cat] ? BOOK_CATS[b.cat].icon : '📘') + ' ' + esc(b.fa) + '</div>' +
      (read ? '<span class="chip chip--green">خوانده شد</span>' : '<span class="chip">' + esc(BOOK_CATS[b.cat] ? BOOK_CATS[b.cat].fa : '') + '</span>') + '</div>' +
      '<p class="tiny">' + esc(b.author) + ' — ' + esc(b.en) + '</p>' +
      '<p class="muted">' + esc(b.idea) + '</p>' +
      '<div class="btn-row mt"><button class="btn btn--sm btn--primary" data-act="lib.open" data-id="' + b.id + '">خلاصه، اصول و تمرین‌ها</button>' +
      '<button class="btn btn--sm ' + (read ? 'btn--ghost' : '') + '" data-act="lib.read" data-id="' + b.id + '">' + (read ? 'حذف از خوانده‌شده‌ها' : 'خواندم ✓') + '</button></div>', 'card--flat');
  }).join('') + '</div>' : emptyBox('🔍', 'کتابی با این جست‌وجو پیدا نشد.'));

  html += section('مفاهیم کلیدی پایگاه دانش', card(
    '<p class="tiny">برنامه بر پایه ' + FA(100) + ' کتاب و ' + FA(80) + '+ مفهوم کلیدی ساخته شده است. هر مفهوم شامل اصل، نحوه اجرا و اقدام مشخص است.</p>' +
    '<div class="btn-row mt"><button class="btn btn--sm" data-act="lib.concepts">فهرست مفاهیم</button></div>', ''));
  html += disclaimer('محتوای کتاب‌ها به‌صورت مفهومی و بازنویسی‌شده است و هیچ متنی از کتاب‌ها کپی نشده.');
  return html;
}

function bookView(state) {
  const detail = bookDetail(openBook);
  const b = detail.book;
  return section(esc(b.fa),
    card(
      '<div class="card__title">' + esc(b.fa) + '</div>' +
      '<p class="tiny">' + esc(b.author) + ' • ' + esc(b.en) + ' • دسته: ' + esc(BOOK_CATS[b.cat] ? BOOK_CATS[b.cat].fa : '') + '</p>' +
      '<div class="alert alert--ok mt"><i>💡</i><div class="tiny">' + esc(detail.lesson) + '</div></div>' +
      '<div class="btn-row mt"><button class="btn btn--sm" data-act="lib.back">بازگشت به کتابخانه</button>' +
      '<button class="btn btn--sm btn--primary" data-act="lib.read" data-id="' + b.id + '">خواندم ✓</button></div>', 'card--gold') +
    section('خلاصه مفهومی', card('<p>' + esc(detail.summary) + '</p>', '')) +
    section('۱۰ اصل کلیدی', card('<ol>' + detail.principles.map((p) => '<li>' + esc(p) + '</li>').join('') + '</ol>', '')) +
    section('۱۰ تمرین عملی', card('<ol>' + detail.exercises.map((p) => '<li>' + esc(p) + '</li>').join('') + '</ol>', '')) +
    section('۱۰ اقدام قابل اجرا', card('<ol>' + detail.actions.map((p) => '<li>' + esc(p) + '</li>').join('') + '</ol>', '') +
      '<button class="btn btn--primary btn--block mt" data-act="lib.toTask" data-id="' + b.id + '">افزودن سه اقدام اول به امروز</button>') +
    section('پنج سؤال برای فهم عمیق‌تر', card('<ol>' + detail.questions.map((p) => '<li>' + esc(p) + '</li>').join('') + '</ol>', '')) +
    section('مفاهیم مرتبط', detail.concepts.length ? card(detail.concepts.map((c) =>
      '<div class="kv"><span><b>' + esc(c.title) + '</b><br><span class="tiny">' + esc(c.body) + '</span></span><span class="chip">' + esc(c.type) + '</span></div>').join(''), '') : emptyBox('📘', 'مفهوم مرتبطی ثبت نشده.')) +
    (detail.related.length ? section('کتاب‌های مرتبط', card(detail.related.map((r) => '<div class="kv"><span>' + esc(r.fa) + '</span><button class="btn btn--sm" data-act="lib.open" data-id="' + r.id + '">نمایش</button></div>').join(''), '')) : '')
  );
}

reg('lib', {
  cat(el, ds) { cat = ds.c; render(); },
  search(el) {
    query = el.value || '';
    clearTimeout(window.__libT);
    window.__libT = setTimeout(() => render(), 260);
  },
  open(el, ds) {
    openBook = { id: ds.id };
    const b = searchBooks('').find((x) => x.id === ds.id);
    openBook = b;
    render();
    try { window.scrollTo(0, 0); } catch (e) { void e; }
  },
  back() { openBook = null; render(); },
  read(el, ds) {
    let added = false;
    State.update((s) => {
      s.learning.books = s.learning.books || [];
      const i = s.learning.books.findIndex((x) => x.id === ds.id);
      if (i > -1) s.learning.books.splice(i, 1);
      else {
        const b = searchBooks('').find((x) => x.id === ds.id);
        s.learning.books.push({ id: ds.id, title: b ? b.fa : ds.id, readAt: todayKey() });
        s.learning.lessonsDone = (s.learning.lessonsDone || 0) + 1;
        s.gamification.xp += XP_RULES.learning;
        added = true;
        checkAchievements(s, 0);
      }
    });
    toast(added ? 'به لیست خوانده‌شده‌ها اضافه شد (+۵ XP)' : 'از لیست حذف شد');
    render();
  },
  toTask(el, ds) {
    const b = searchBooks('').find((x) => x.id === ds.id);
    if (!b) return;
    const d = bookDetail(b);
    State.update((s) => {
      const { ensureDay } = lazyEnsure();
      const day = ensureDay(s, todayKey());
      d.actions.slice(0, 3).forEach((a) => day.tasks.push({ id: 't' + Date.now() + Math.random().toString(36).slice(2, 5), title: a, cat: 'یادگیری', minutes: 25, impact: 65, done: false }));
    });
    toast('سه اقدام کتاب به کارهای امروز اضافه شد');
    location.hash = '#/today'; render();
  },
  wisdomTask(el, ds) {
    State.update((s) => {
      const { ensureDay } = lazyEnsure();
      const day = ensureDay(s, todayKey());
      day.tasks.push({ id: 't' + Date.now(), title: ds.t, cat: 'یادگیری', minutes: 15, impact: 60, done: false });
    });
    toast('به کارهای امروز اضافه شد'); location.hash = '#/today'; render();
  },
  wisdomAll() {
    const list = wisdomList();
    modal({ title: 'آرشیو حکمت‌های مالی', body: '<div class="stack">' + list.map((w) => '<div class="list-row"><div class="list-row__main"><div class="list-row__title">' + esc(w.text) + '</div><div class="list-row__sub">اقدام: ' + esc(w.action) + '</div></div></div>').join('') + '</div>' });
  },
  concepts() {
    modal({
      title: 'مفاهیم کلیدی پایگاه دانش',
      body: '<div class="stack">' + conceptList().map((c) =>
        '<div class="list-row"><div class="list-row__main"><div class="list-row__title">' + esc(c.title) + '</div>' +
        '<div class="list-row__sub">' + esc(c.type) + ' — ' + esc(c.body) + '</div>' +
        '<div class="list-row__sub">اجرا: ' + esc(c.apply) + '</div></div></div>').join('') + '</div>',
    });
  },
});

function conceptList() { return CONCEPTS; }

register('library', { title: 'کتابخانه', eyebrow: '۱۰۰ کتاب ثروت — خلاصه مفهومی', render: view, tab: false });
