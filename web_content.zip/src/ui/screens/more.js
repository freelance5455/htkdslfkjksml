/* ==========================================================================
   ui/screens/more.js — فهرست کامل امکانات
   ========================================================================== */

import { State } from '../../store.js';
import { reg } from '../actions.js';
import { register, section, card, FA, toast, kv, render } from '../shell.js';
import { financeMetrics } from '../../engines/financial-engine.js';
import { computeScore } from '../../engines/scoring-engine.js';
import { bookCount, conceptCount } from '../../engines/ai-engine.js';
import { toFaDigits, esc, todayKey } from '../../utils.js';

const ITEMS = [
  { id: 'dashboard', icon: '📊', fa: 'داشبورد مالی', sub: 'نمای کلی و نمودارها' },
  { id: 'plan', icon: '🗓️', fa: 'برنامه‌ریزی', sub: 'هفته، ماه، سال، تقویم' },
  { id: 'calendar', icon: '📅', fa: 'تقویم هوشمند', sub: 'برنامه روزانه و زمان‌بندی' },
  { id: 'intelligence', icon: '🧠', fa: 'هوش مالی', sub: 'تحلیل، پیشنهاد، تصمیم‌یار' },
  { id: 'coach', icon: '🤖', fa: 'مربی آفلاین', sub: 'پرسش و پاسخ شخصی‌سازی‌شده' },
  { id: 'reports', icon: '🧾', fa: 'گزارش‌ها', sub: 'مرور هفتگی و ماهانه' },
  { id: 'simulator', icon: '🔮', fa: 'شبیه‌ساز ثروت', sub: 'سه سناریوی محافظه‌کارانه تا تهاجمی' },
  { id: 'freedom', icon: '🕊️', fa: 'استقلال مالی', sub: 'سرمایه موردنیاز و زمان' },
  { id: 'debt', icon: '📉', fa: 'بدهی', sub: 'بهمن یا گلوله برفی؟' },
  { id: 'future', icon: '⏳', fa: 'اگر تغییر ندهم؟', sub: 'مقایسه دو آینده' },
  { id: 'skills', icon: '🎯', fa: 'درخت مهارت', sub: 'بازده هر مهارت' },
  { id: 'business', icon: '🚀', fa: 'موتور کسب‌وکار', sub: 'ایده، MVP، برنامه ۳۰ روزه' },
  { id: 'library', icon: '📚', fa: 'کتابخانه', sub: '۱۰۰ کتاب، اصول و تمرین' },
  { id: 'achievements', icon: '🏆', fa: 'دستاوردها و XP', sub: 'انگیزه و پیشرفت' },
  { id: 'backup', icon: '💾', fa: 'پشتیبان‌گیری', sub: 'خروجی و بازیابی JSON' },
  { id: 'settings', icon: '⚙️', fa: 'تنظیمات', sub: 'حالت تیره/روشن، اعلان، زبان' },
  { id: 'profile', icon: '👤', fa: 'پروفایل', sub: 'ویرایش اطلاعات مالی' },
  { id: 'about', icon: 'ℹ️', fa: 'درباره و حریم خصوصی', sub: 'آفلاین بودن و امنیت داده' },
];

function view() {
  const state = State.get();
  const m = financeMetrics(state);
  const sc = computeScore(state);
  let html = '';
  html += section('خلاصه وضعیت', card(
    kv('امتیاز مالی', FA(sc.total) + '/1000 (' + esc(sc.grade) + ')') +
    kv('خالص ثروت', fmt(state, m.netWorth)) +
    kv('نرخ پس‌انداز', toFaDigits(Math.round(m.savingsRate * 100)) + '٪') +
    kv('XP', toFaDigits(state.gamification.xp || 0)), 'card--gold'));
  html += section('همه امکانات', '<div class="grid grid-2">' + ITEMS.map((i) =>
    '<button class="card tile" data-act="ui.nav" data-id="' + i.id + '"><div style="font-size:22px">' + i.icon + '</div>' +
    '<div style="font-weight:800;margin-top:4px;font-size:13.5px">' + esc(i.fa) + '</div>' +
    '<div class="tiny">' + esc(i.sub) + '</div></button>').join('') + '</div>');
  html += section('موتور هوش مالی آفلاین', card(
    kv('کتاب‌های پایگاه دانش', toFaDigits(bookCount())) +
    kv('مفاهیم و قوانین', toFaDigits(conceptCount())) +
    kv('مسیرهای ثروت', toFaDigits(10)) +
    kv('آخرین بازتنظیم مسیر', esc(state.meta.lastRecalc ? state.meta.lastRecalc : '—')), ''));
  html += '<p class="tiny center">مسیر میلیاردری — نسخه ۱٫۰ • کاملاً آفلاین • داده‌ها فقط روی دستگاه تو</p>';
  return html;
}
function fmt(state, n) { return fmtCompact(n, state.profile); }

register('more', { title: 'بیشتر', eyebrow: 'همه امکانات', render: view, tab: true });
