/* ==========================================================================
   ui/screens/skills.js — درخت مهارت، Career Engine، مسیر رشد تا درآمد
   ========================================================================== */

import { State } from '../../store.js';
import { reg } from '../actions.js';
import { register, section, card, FA, toast, emptyBox, disclaimer, render, kv, bar, modal, closeModal } from '../shell.js';
import { skillTree, skillROI } from '../../engines/ai-engine.js';
import { skillScore } from '../../engines/scoring-engine.js';
import { hBars, ring, CHART_COLORS } from '../../charts.js';
import { toFaDigits, esc, todayKey, uid, clamp } from '../../utils.js';
import { ensureDay } from '../../engines/planner.js';

function view() {
  const state = State.get();
  const sc = skillScore(state);
  const tree = skillTree(state);
  const roi = skillROI(state);
  let html = '';

  html += '<div class="hero"><div class="row" style="gap:14px">' +
    ring(sc, { size: 92, color: sc >= 70 ? CHART_COLORS.green : CHART_COLORS.gold, label: 'امتیاز مهارت' }) +
    '<div style="flex:1"><div class="card__title">مسیر: مهارت ← تخصص ← درآمد ← کسب‌وکار</div>' +
    '<p class="tiny">تخصص‌های ثبت‌شده: ' + ((state.profile.skills || []).map(esc).join('، ') || 'ثبت نشده') + '</p>' +
    '<p class="tiny">هر مهارت ۶ سطح دارد؛ سطح ۳ یعنی «قابل فروش».</p></div></div></div>';

  html += section('بیشترین بازده (ROI)', hBars(roi.slice(0, 8).map((r) => ({ label: r.title, value: r.roi, text: FA(r.roi) + '/100', color: r.roi >= 70 ? CHART_COLORS.green : CHART_COLORS.gold })), {}));

  html += section('درخت مهارت', tree.length ? tree.map((s) => card(
    '<div class="row row--between"><div class="card__title">' + esc(s.title) + '</div><span class="chip chip--gold">ROI ' + FA(s.roi) + '</span></div>' +
    '<div class="skill__lvl">' + s.steps.map((st) => '<i class="' + (st.lvl <= s.level ? 'on' : '') + '"></i>').join('') + '</div>' +
    '<div class="mt">' + s.steps.map((st) => '<div class="kv"><span>' + (st.lvl <= s.level ? '✅' : '⬜') + ' سطح ' + FA(st.lvl) + ': ' + esc(st.fa) + '</span><b class="tiny">' + esc(st.need) + '</b></div>').join('') + '</div>' +
    '<div class="btn-row mt"><button class="btn btn--sm btn--primary" data-act="skill.up" data-t="' + esc(s.title) + '">یک سطح بالاتر</button>' +
    '<button class="btn btn--sm" data-act="skill.practice" data-t="' + esc(s.title) + '">تمرین امروز</button>' +
    '<button class="iconbtn" data-act="skill.del" data-t="' + esc(s.title) + '">🗑</button></div>', 'card--flat')).join('')
    : emptyBox('🎯', 'مهارتی ثبت نشده است. از پروفایل یا فهرست ROI اضافه کن.'));

  html += section('مهارت‌های پرتقاضا (Career Engine)', card(
    '<p class="tiny">بر اساس سن، تخصص، زمان آزاد و وضعیت بازار، این مهارت‌ها بیشترین بازده را برای تو دارند:</p>' +
    '<ol>' + roi.slice(0, 5).map((r) => '<li><b>' + esc(r.title) + '</b> — تقاضا ' + FA(r.demand) + '/100 • ' + esc(r.reason) + '</li>').join('') + '</ol>' +
    '<div class="btn-row mt"><button class="btn btn--sm btn--primary" data-act="skill.addTop">افزودن بهترین مهارت</button>' +
    '<button class="btn btn--sm" data-act="ui.nav" data-id="business">ایده کسب‌وکار مرتبط</button></div>', ''));

  html += section('زنجیره ارزش مهارت', card(
    '<div class="timeline">' +
    ['مهارت', 'سطح ۱: آشنایی', 'سطح ۲: اجرای ساده', 'سطح ۳: قابل فروش', 'تخصص', 'درآمد بالا', 'کسب‌وکار']
      .map((x, i) => '<div class="tl-item ' + (i <= Math.min(6, Math.ceil(sc / 17)) ? 'active' : '') + '"><h4>' + esc(x) + '</h4></div>').join('') +
    '</div>', ''));
  html += disclaimer('سطح مهارت‌ها را خودت به‌روزرسانی کن؛ برنامه بر اساس آن، مسیر درآمد را بازمحاسبه می‌کند.');
  return html;
}

reg('skill', {
  up(el, ds) {
    State.update((s) => {
      const t = (s.skills || []).find((x) => x.title === ds.t);
      if (!t) { s.skills = s.skills || []; s.skills.push({ id: uid('s'), title: ds.t, level: 1, note: '' }); }
      else if ((t.level || 1) < 6) t.level = (t.level || 1) + 1;
      s.gamification.xp += 20;
    });
    toast('سطح مهارت افزایش یافت (+۲۰ XP)'); render();
  },
  practice(el, ds) {
    State.update((s) => {
      const day = ensureDay(s, todayKey());
      day.tasks.push({ id: 't' + Date.now(), title: '۶۰ دقیقه تمرین هدفمند مهارت «' + ds.t + '»', cat: 'مهارت', minutes: 60, impact: 85, done: false });
    });
    toast('به کارهای امروز اضافه شد'); location.hash = '#/today'; render();
  },
  add(el, ds) {
    State.update((s) => {
      s.skills = s.skills || [];
      if (!s.skills.some((x) => x.title === ds.t)) s.skills.push({ id: uid('s'), title: ds.t, level: 1, note: '' });
    });
    toast('مهارت اضافه شد'); render();
  },
  addTop() {
    const best = skillROI(State.get())[0];
    State.update((s) => {
      s.skills = s.skills || [];
      if (!s.skills.some((x) => x.title === best.title)) s.skills.push({ id: uid('s'), title: best.title, level: 1, note: 'پیشنهاد هوشمند برنامه' });
      s.profile.skills = s.profile.skills || [];
      if (s.profile.skills.indexOf(best.title) === -1) s.profile.skills.push(best.title);
    });
    toast('مهارت «' + best.title + '» اضافه شد'); render();
  },
  del(el, ds) {
    State.update((s) => { s.skills = (s.skills || []).filter((x) => x.title !== ds.t); });
    toast('مهارت حذف شد'); render();
  },
});

register('skills', { title: 'درخت مهارت', eyebrow: 'Career & Skill Engine', render: view, tab: false });
