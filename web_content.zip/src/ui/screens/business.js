/* ==========================================================================
   ui/screens/business.js — موتور کسب‌وکار: ایده، بازار، مدل درآمد، MVP، برنامه ۳۰ روزه
   ========================================================================== */

import { State } from '../../store.js';
import { reg } from '../actions.js';
import { register, section, card, M, FA, toast, kv, bar, emptyBox, disclaimer, render } from '../shell.js';
import { businessIdeas } from '../../engines/ai-engine.js';
import { skillROI } from '../../engines/ai-engine.js';
import { financeMetrics } from '../../engines/financial-engine.js';
import { ensureDay } from '../../engines/planner.js';
import { hBars, CHART_COLORS } from '../../charts.js';
import { fmtCompact, pct, toFaDigits, esc, todayKey, clamp } from '../../utils.js';
import { checkAchievements } from '../../achievements.js';

let selected = 0;

function view() {
  const state = State.get();
  const m = financeMetrics(state);
  const ideas = businessIdeas(state);
  const best = ideas[selected] || ideas[0];
  let html = '';

  html += section('ایده‌های متناسب با شرایط تو', hBars(ideas.slice(0, 6).map((i, ix) => ({ label: i.title, value: i.score, text: FA(i.score) + '٪', color: ix === selected ? CHART_COLORS.green : CHART_COLORS.gold })), {}));

  html += section('انتخاب ایده', '<div class="chips">' + ideas.map((i, ix) =>
    '<button class="chipbtn ' + (ix === selected ? 'is-active' : '') + '" data-act="biz.pick" data-i="' + ix + '">' + esc(i.title) + '</button>').join('') + '</div>');

  if (best) {
    html += section('طرح کامل ایده', card(
      '<div class="card__title">🚀 ' + esc(best.title) + '</div>' +
      '<p class="card__sub">' + esc(best.why) + '</p>' +
      kv('بازار هدف', esc(best.market)) +
      kv('مشتری هدف (Persona)', esc(best.persona)) +
      kv('مدل درآمدی', esc(best.model)) +
      kv('هزینه شروع تخمینی', fmtCompact(best.cost, state.profile)) +
      kv('امتیاز تناسب', FA(best.score) + '٪') +
      '<h5 class="mt">ریسک‌ها</h5><ul>' + best.risks.map((r) => '<li>' + esc(r) + '</li>').join('') + '</ul>' +
      '<h5>MVP (حداقل محصول قابل عرضه)</h5><p>' + esc(best.mvp) + '</p>' +
      '<h5>برنامه ۳۰ روزه</h5><ol>' + best.plan30.map((p, i) => '<li><b>هفته ' + FA(i + 1) + ':</b> ' + esc(p) + '</li>').join('') + '</ol>' +
      '<h5>برنامه جذب اولین مشتری</h5><p>' + esc(best.firstCustomer) + '</p>' +
      '<div class="btn-row mt"><button class="btn btn--primary" data-act="biz.start">ساخت برنامه ۳۰ روزه در نقشه راه</button>' +
      '<button class="btn" data-act="biz.firstTasks">افزودن کارهای امروز</button></div>', 'card--gold'));

    html += section('بررسی آمادگی مالی', card(
      kv('نقدینگی موجود', fmtCompact(m.liquid, state.profile)) +
      kv('هزینه ثابت ماهانه', fmtCompact(m.expense, state.profile)) +
      kv('پوشش نقدینگی', FA(m.runwayMonths) + ' ماه') +
      '<div class="alert ' + (m.runwayMonths >= 3 ? 'alert--ok' : 'alert--danger') + ' mt"><i>' + (m.runwayMonths >= 3 ? '✅' : '⚠️') + '</i><div class="tiny">' +
      (m.runwayMonths >= 3
        ? 'پوشش نقدینگی کافی است؛ می‌توانی با ریسک کنترل‌شده شروع کنی. سرمایه در گردش دو ماه هزینه را نقد نگه دار.'
        : 'پوشش نقدینگی کمتر از سه ماه است. قبل از شروع، یک منبع درآمد جانبی بساز یا هزینه ثابت را کاهش بده.') + '</div></div>' +
      '<p class="hint">هرگز برای شروع کسب‌وکار قرض با بهره بالا نگیر؛ اول با کوچک‌ترین نسخه فروش را آزمایش کن.</p>', ''));
  } else {
    html += emptyBox('🚀', 'برای پیشنهاد ایده، ابتدا تخصص‌های خود را در پروفایل ثبت کن.');
  }

  html += section('مهارت‌های پشتیبان این ایده', card(
    '<ol>' + skillROI(state).slice(0, 4).map((s) => '<li><b>' + esc(s.title) + '</b> — ROI ' + FA(s.roi) + '/100</li>').join('') + '</ol>', ''));
  html += disclaimer('ایده‌ها فرضیه‌اند، نه تضمین. با کوچک‌ترین آزمون واقعی و کمترین هزینه شروع کن.');
  return html;
}

reg('biz', {
  pick(el, ds) { selected = +ds.i || 0; render(); },
  start(el) {
    const ideas = businessIdeas(State.get());
    const best = ideas[selected] || ideas[0];
    State.update((s) => {
      s.plan.businessStarted = true;
      s.plan.bizPlan = { title: best.title, model: best.model, cost: best.cost, at: todayKey(), plan30: best.plan30 };
      s.gamification.xp += 40;
      checkAchievements(s, 0);
    });
    toast('کسب‌وکار به مسیر اضافه شد (+۴۰ XP)');
    render();
  },
  firstTasks(el) {
    const ideas = businessIdeas(State.get());
    const best = ideas[selected] || ideas[0];
    State.update((s) => {
      const day = ensureDay(s, todayKey());
      const tasks = [
        { title: 'مصاحبه با ۳ مشتری بالقوه درباره «' + best.title + '»', cat: 'اقدام درآمدی', minutes: 60 },
        { title: 'تعریف عرضه و سه سطح قیمت', cat: 'اقدام درآمدی', minutes: 40 },
        { title: '۵ پیام شخصی‌سازی‌شده به مشتری احتمالی', cat: 'فروش', minutes: 30 },
      ];
      tasks.forEach((t) => day.tasks.push({ id: 't' + Date.now() + Math.random().toString(36).slice(2, 5), ...t, impact: 85, done: false }));
    });
    toast('کارهای شروع کسب‌وکار اضافه شد');
    location.hash = '#/today'; render();
  },
});

register('business', { title: 'موتور کسب‌وکار', eyebrow: 'ایده، بازار، MVP و برنامه ۳۰ روزه', render: view, tab: false });
