/* ==========================================================================
   ui/screens/today.js — صفحه «امروز»: مهم‌ترین اقدام، ماموریت روزانه، زنجیره
   ========================================================================== */

import { State } from '../../store.js';
import { reg } from '../actions.js';
import { register, section, card, M, FA, toast, modal, closeModal, formModal, listRow, bar, emptyBox, alertBox, taskRow, kv, chips, disclaimer, go, render } from '../shell.js';
import { ensureDay, adaptiveReschedule, timeBlocks, streakGuard, weekPercentDone, generateWeek } from '../../engines/planner.js';
import { roadmapProgress, currentMonthPlan, unlockLevel, UNLOCK_LEVELS } from '../../engines/roadmap-engine.js';
import { buildAlerts } from '../../notifications.js';
import { wisdomToday, oneBigMove } from '../../engines/ai-engine.js';
import { todayKey, addDays, faDate, toFaDigits, weekdayIndex, esc, clamp, vibrate, daysBetween } from '../../utils.js';
import { addXP, logXP, levelInfo } from '../../achievements.js';
import { checkAchievements } from '../../achievements.js';

function streakBars(state) {
  const hist = state.streak.history || [];
  const out = [];
  for (let i = 6; i >= 0; i--) {
    const key = addDays(todayKey(), -i);
    out.push('<i class="' + (hist.indexOf(key) > -1 ? 'on' : '') + '" title="' + faDate(key, { withYear: false }) + '"></i>');
  }
  return '<div class="streak">' + out.join('') + '</div>';
}

function view() {
  const state = State.get();
  const tk = todayKey();
  const day = ensureDay(state, tk);
  const rp = roadmapProgress(state);
  const monthPlan = currentMonthPlan(state);
  const lv = levelInfo(state.gamification.xp);
  const alerts = buildAlerts(state).slice(0, 2);
  const doneCount = day.tasks.filter((t) => t.done).length;
  const bigMove = day.bigMove || oneBigMove(state);
  const bigTask = day.tasks.find((t) => t.cat === 'مهم‌ترین اقدام');
  const bigDone = bigTask ? bigTask.done : false;
  const wis = wisdomToday(state);
  const unlocked = unlockLevel(state);
  const mission = state.profile.mission || '';

  let html = '';

  // Hero
  html += '<div class="hero">' +
    '<p class="hero__hi">' + (state.profile.name ? 'سلام ' + esc(state.profile.name) + ' 👋' : 'سلام 👋') + ' — ' + esc(faDate(tk, { withWeekday: true })) + '</p>' +
    '<div class="hero__path">مسیر شما: ' + esc(state.plan.roadmap ? state.plan.roadmap.pathTitle : 'هنوز انتخاب نشده') +
    ' • پیشرفت: ' + FA(rp.percent) + '٪ • سطح ' + FA(lv.level) + ' (' + esc(lv.fa) + ')</div>' +
    (mission ? '<p class="tiny" style="color:var(--text-2)">🎯 ' + esc(mission) + '</p>' : '<p class="tiny"><button class="btn btn--sm" data-act="profile.openMission">مأموریت شخصی‌ات را بنویس</button></p>') +
    '<div class="row row--between mt"><div>' + kpiMini('ماموریت امروز', FA(doneCount) + ' / ' + FA(day.tasks.length)) + '</div>' +
    '<div>' + kpiMini('روزهای فعال', FA((state.streak.history || []).length)) + '</div>' +
    '<div>' + kpiMini('زنجیره', FA(state.streak.current || 0) + ' روز') + '</div></div>' +
    '</div>';

  // Alerts
  if (alerts.length) html += '<div class="stack mb">' + alerts.map((a) => alertBox(a.level, a.icon, a.title, a.body, a.action ? a.action.screen : null)).join('') + '</div>';

  // ONE BIG MOVE
  html += section('مهم‌ترین اقدام امروز (ONE BIG MOVE)',
    card(
      '<div class="card__title">🔥 ' + esc(bigMove.title) + '</div>' +
      '<p class="card__sub">' + esc(bigMove.reason || 'این کار بیشترین اثر را بر سرعت رسیدن به هدف تو دارد.') + '</p>' +
      '<div class="task__meta"><span class="chip chip--gold">' + esc(bigMove.cat || 'اقدام کلیدی') + '</span><span class="chip">' + FA(bigMove.minutes || 45) + ' دقیقه</span>' +
      '<span class="chip chip--green">اثر ' + FA(bigMove.impact || 90) + '/100</span></div>' +
      '<div class="btn-row mt"><button class="btn ' + (bigDone ? 'btn--green' : 'btn--primary') + '" data-act="task.toggle" data-day="' + tk + '" data-id="' + (bigTask ? bigTask.id : '') + '">' + (bigDone ? '✅ انجام شد' : 'انجام شد') + '</button>' +
      '<button class="btn btn--ghost" data-act="task.replaceBig">جایگزین کن</button>' +
      '<button class="btn btn--ghost" data-act="plan.openTime">زمان‌بندی</button></div>',
      'card--gold'), { action: '<span class="chip">' + FA(doneCount) + '/' + FA(day.tasks.length) + '</span>' });

  // Daily mission
  html += section('ماموریت روزانه', day.tasks.length
    ? day.tasks.map((t) => taskRow(t, tk)).join('')
    : emptyBox('🎯', 'کاری برای امروز ساخته نشده. با دکمه زیر بساز.'),
    { action: '<button class="btn btn--sm" data-act="task.add">+ کار</button>' });

  if (day.tasks.length > 5) html += '<div class="alert alert--warn mb"><i>🎯</i><div class="tiny">برای حفظ تمرکز، کارهای روز را محدود کن. بیش از ۵ کار در روز احتمال انجام هیچ‌کدام را بالا می‌برد.</div></div>';

  // Schedule
  const blocks = timeBlocks(state, tk);
  if (blocks.length) {
    html += section('برنامه زمانی پیشنهادی', card(blocks.map((b) =>
      '<div class="kv"><span class="muted num">' + b.time + '</span><span style="flex:1">' + (b.done ? '✅ ' : '') + esc(b.title) + '</span><b class="tiny">' + FA(b.minutes) + 'د</b></div>').join(''),
      ''), { action: '<button class="btn btn--sm" data-act="plan.openTime">تقویم</button>' });
  }

  // Wisdom
  html += section('حکمت روز', card(
    '<p style="font-size:14px">«' + esc(wis.text) + '»</p>' +
    '<div class="alert alert--ok mt"><i>✅</i><div class="tiny"><b>اقدام امروز:</b> ' + esc(wis.action) + '</div></div>', 'card--flat'));

  // Streak + week progress
  html += section('زنجیره موفقیت', card(
    '<div class="row row--between"><div><div class="card__title">🔥 ' + FA(state.streak.current || 0) + ' روز پیوسته</div>' +
    '<p class="tiny">بهترین رکورد: ' + FA(state.streak.best || 0) + ' روز — هدف بعدی: ' + FA(nextStreakTarget(state.streak.current || 0)) + ' روز</p></div>' + streakBars(state) + '</div>' +
    '<div class="mt">' + bar(weekPercentDone(state).percent) + '<p class="tiny mt">پیشرفت هفته: ' + FA(weekPercentDone(state).percent) + '٪ (' + FA(weekPercentDone(state).done) + ' از ' + FA(weekPercentDone(state).total) + ')</p></div>', ''));

  // Month focus
  if (monthPlan) {
    html += section('تمرکز این ماه', card(
      '<div class="card__title">📌 ماه ' + FA(monthPlan.n) + ': ' + esc(monthPlan.title) + '</div>' +
      '<p class="card__sub">' + esc(monthPlan.focus) + '</p>' +
      '<div class="chips mt">' + monthPlan.tasks.map((t) => '<span class="chip">' + esc(t) + '</span>').join('') + '</div>', ''),
      { action: '<button class="btn btn--sm" data-act="ui.nav" data-id="path">نقشه راه</button>' });
  }

  // Level unlock
  html += section('سطح باز شده', card(
    UNLOCK_LEVELS.map((l) => '<div class="kv"><span>' + (l.level <= unlocked ? '🔓' : '🔒') + ' سطح ' + FA(l.level) + ': ' + esc(l.fa) + '</span><b class="tiny">' + esc(l.need) + '</b></div>').join(''), ''),
    { action: '<button class="btn btn--sm" data-act="ui.nav" data-id="achievements">دستاوردها</button>' });

  html += disclaimer('برنامه هیچ وعده قطعی نمی‌دهد؛ مسیرها و اعداد، مدل‌سازی داخلی برای تصمیم‌گیری بهتر تو هستند.');
  return html;
}

function kpiMini(label, value) {
  return '<div class="kpi"><span class="kpi__label">' + label + '</span><span class="kpi__value num" style="font-size:15px">' + value + '</span></div>';
}
function nextStreakTarget(cur) { return cur < 7 ? 7 : cur < 30 ? 30 : cur < 90 ? 90 : 365; }

/* --------------------------------------------------------------- اکشن‌ها */
reg('task', {
  toggle(el, ds) {
    const key = ds.day || todayKey();
    const id = ds.id;
    if (!id) { toast('این کار در دسترس نیست', 'red'); return; }
    let done = false;
    State.update((s) => {
      const day = (s.plan.days || {})[key];
      if (!day) return;
      const t = day.tasks.find((x) => x.id === id);
      if (!t) return;
      t.done = !t.done;
      done = t.done;
      if (t.done) {
        s.gamification.tasksDone = (s.gamification.tasksDone || 0) + 1;
        s.gamification.xp += 10;
        s.gamification.history.push({ id: 'xp' + Date.now(), kind: 'task', label: t.title, xp: 10, at: todayKey() });
        streakGuard(s);
        checkAchievements(s, 0);
        vibrate(14);
      } else {
        s.gamification.tasksDone = Math.max(0, (s.gamification.tasksDone || 0) - 1);
        s.gamification.xp = Math.max(0, s.gamification.xp - 10);
      }
    });
    toast(done ? '✅ انجام شد — +۱۰ XP و زنجیره ثبت شد' : 'کار به حالت انجام‌نشده برگشت', done ? '' : 'red');
    checkScore();
    render();
  },
  remove(el, ds) {
    State.update((s) => {
      const day = (s.plan.days || {})[ds.day];
      if (day) day.tasks = day.tasks.filter((t) => t.id !== ds.id);
    });
    toast('کار حذف شد');
    render();
  },
  add() {
    formModal('افزودن کار به امروز',
      field('عنوان کار', 'text', 'title', '', 'مثلاً: تماس با ۳ مشتری') +
      fieldSelect('دسته', 'cat', ['مهم‌ترین اقدام', 'یادگیری', 'اقدام مالی', 'اقدام درآمدی', 'عادت', 'مرور و برنامه‌ریزی', 'فروش', 'مهارت', 'بدهی', 'پس‌انداز'], 'اقدام درآمدی') +
      fieldNum('مدت (دقیقه)', 'minutes', 30) +
      fieldNum('اثر (۰-۱۰۰)', 'impact', 70),
      { form: 'task.add', submit: 'افزودن' });
  },
  replaceBig() {
    State.update((s) => {
      const day = (s.plan.days || {})[todayKey()];
      if (!day) return;
      const alt = oneBigMove(s);
      day.bigMove = alt;
      const t = day.tasks.find((x) => x.cat === 'مهم‌ترین اقدام');
      if (t) { t.title = alt.title; t.impact = alt.impact; t.done = false; }
    });
    toast('اقدام غالب جایگزین شد');
    render();
  },
});

reg('plan', {
  reschedule() {
    let msg = '';
    State.update((s) => { const r = adaptiveReschedule(s); msg = r.message; });
    toast(msg);
    render();
  },
  openTime() { go('calendar'); },
  generateWeek() {
    let n = 0;
    State.update((s) => { n = generateWeek(s).created.length; });
    toast(n ? FA(n) + ' روز برنامه‌ریزی شد' : 'برنامه هفته از قبل ساخته شده بود');
    render();
  },
});

reg('profile', {
  openMission() {
    modal({
      title: 'مأموریت شخصی',
      body: '<form data-form="profile.mission">' +
        '<div class="field"><label>چرا می‌خواهی ثروتمند شوی؟</label>' +
        '<textarea class="textarea" name="mission" placeholder="مثلاً: آزادی زمانی، امنیت خانواده، کمک به دیگران">' + esc(State.get().profile.mission || '') + '</textarea>' +
        '<p class="hint">این متن در داشبورد نمایش داده می‌شود تا انگیزه‌ات حفظ شود.</p></div>' +
        '<div class="field"><label>دلایل (با کاما جدا کن)</label><input class="input" name="reasons" value="' + esc((State.get().profile.reasons || []).join('، ')) + '"></div>' +
        '<button class="btn btn--primary btn--block" type="submit">ذخیره</button></form>',
    });
  },
});

reg('form', {
  'task.add'(fd) {
    State.update((s) => {
      const day = (s.plan.days || {})[todayKey()] || ensureDay(s, todayKey());
      day.tasks.push({
        id: 't' + Date.now(), title: fd.title || 'کار جدید', cat: fd.cat || 'اقدام درآمدی',
        minutes: +fd.minutes || 30, impact: +fd.impact || 70, done: false, priority: 9,
      });
    });
    closeModal(); toast('کار اضافه شد'); render();
  },
  'profile.mission'(fd) {
    State.update((s) => {
      s.profile.mission = (fd.mission || '').trim();
      s.profile.reasons = String(fd.reasons || '').split(/[،,]/).map((x) => x.trim()).filter(Boolean);
    });
    closeModal(); toast('مأموریت ذخیره شد'); render();
  },
});

function checkScore() {
  State.update((s) => { s.meta.lastScoreCheck = todayKey(); }, { silent: true });
}

/* ------------------------------------------------------- فیلدساز مشترک */
export function field(label, type, name, value, placeholder) {
  return '<div class="field"><label>' + label + '</label><input class="input" type="' + (type || 'text') + '" name="' + name + '" value="' + esc(value == null ? '' : value) + '" placeholder="' + esc(placeholder || '') + '"></div>';
}
export function fieldNum(label, name, value, placeholder) {
  return '<div class="field"><label>' + label + '</label><input class="input num" type="text" inputmode="decimal" name="' + name + '" value="' + esc(value == null ? '' : value) + '" placeholder="' + esc(placeholder || 'مثلاً 2.5 میلیون') + '"></div>';
}
export function fieldSelect(label, name, options, value) {
  return '<div class="field"><label>' + label + '</label><select class="select" name="' + name + '">' +
    options.map((o) => { const v = typeof o === 'string' ? o : o.v; const l = typeof o === 'string' ? o : o.l; return '<option value="' + esc(v) + '"' + (String(v) === String(value) ? ' selected' : '') + '>' + esc(l) + '</option>'; }).join('') +
    '</select></div>';
}
export function fieldArea(label, name, value) {
  return '<div class="field"><label>' + label + '</label><textarea class="textarea" name="' + name + '">' + esc(value || '') + '</textarea></div>';
}

register('today', { title: 'امروز', eyebrow: 'ماموریت روزانه', render: view, tab: true });
