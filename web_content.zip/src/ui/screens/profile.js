/* ==========================================================================
   ui/screens/profile.js — پروفایل، ویزارد، تنظیمات، پشتیبان، دستاوردها، درباره
   ========================================================================== */

import { State, applyDemo, defaultState } from '../../store.js';
import { reg } from '../actions.js';
import { register, section, card, M, FA, toast, modal, closeModal, kv, bar, emptyBox, disclaimer, render, confirmModal, chips } from '../shell.js';
import { exportBackup, importBackup, wipeAll, clearDemoData } from '../../lib/backup.js';
import { Security } from '../../security.js';
import { storageUsage } from '../../storage.js';
import { levelInfo, achievementsOf, LEVELS, totalAchievementProgress, xpHistory, XP_RULES } from '../../achievements.js';
import { discoverPaths, chooseBest, buildRoadmap } from '../../engines/roadmap-engine.js';
import { ensureDay } from '../../engines/planner.js';
import { CURRENCIES, toFaDigits, esc, todayKey, uid, fmtCompact } from '../../utils.js';
import { setLang, LANGS } from '../../i18n.js';
import { logEvent } from '../../database.js';
import { requestNotifPermission, notifPermission } from '../../notifications.js';

/* ------------------------------------------------------------------ WIZARD */
let step = 0;
const STEPS = ['خوش‌آمد و حریم خصوصی', 'اطلاعات شخصی', 'شغل و تخصص', 'درآمد و هزینه', 'دارایی و بدهی', 'هدف مالی', 'آماده‌سازی'];
let draft = null;

function ensureDraft() {
  if (!draft) draft = JSON.parse(JSON.stringify(State.get()));
  return draft;
}

function wizRender() {
  const d = ensureDraft();
  let html = '<div class="wizard__steps">' + STEPS.map((s, i) => '<i class="' + (i <= step ? 'on' : '') + '"></i>').join('') + '</div>';
  html += '<h3 class="wizard__step-title">' + esc(STEPS[step]) + '</h3>';
  html += '<p class="wizard__step-sub">مرحله ' + FA(step + 1) + ' از ' + FA(STEPS.length) + '</p>';

  if (step === 0) {
    html += card(
      '<div class="card__title">🪙 مسیر میلیاردری</div>' +
      '<p>«فقط مسیر را نبین؛ هر روز یک قدم بردار.»</p>' +
      '<p class="muted">این برنامه یک مربی مالی شخصی آفلاین است: وضعیت تو را تحلیل می‌کند، مسیر مناسب را انتخاب می‌کند، نقشه راه می‌سازد، هر روز کار مشخص می‌دهد و بر اساس نتایج، برنامه را اصلاح می‌کند.</p>' +
      '<div class="alert alert--ok mt"><i>🔒</i><div class="tiny"><b>حریم خصوصی:</b> اطلاعات مالی شما فقط روی همین دستگاه ذخیره می‌شود. هیچ اتصال به سرور، API یا اینترنت برای عملکرد اصلی وجود ندارد.</div></div>' +
      '<div class="alert alert--info mt"><i>⚠️</i><div class="tiny">برنامه وعده ثروت سریع نمی‌دهد. همه اعداد، مدل‌سازی داخلی هستند و نتیجه تضمین‌شده محسوب نمی‌شوند.</div></div>' +
      '<div class="btn-row mt"><button class="btn btn--primary" data-act="wiz.next">شروع واقعی</button>' +
      '<button class="btn btn--ghost" data-act="wiz.demo">مشاهده نسخه نمایشی</button></div>', 'card--gold');
  }

  if (step === 1) {
    html += card(
      '<div class="field"><label>نام (اختیاری)</label><input class="input" name="name" form="wizf" value="' + esc(d.profile.name) + '"></div>' +
      '<div class="field"><label>سن</label><input class="input num" name="age" form="wizf" inputmode="numeric" value="' + (d.profile.age || '') + '"></div>' +
      '<div class="field"><label>جنسیت (اختیاری)</label><select class="select" name="gender" form="wizf">' + opt(['', 'زن', 'مرد', 'سایر'], d.profile.gender) + '</select></div>' +
      '<div class="field"><label>کشور</label><input class="input" name="country" form="wizf" value="' + esc(d.profile.country) + '"></div>' +
      '<div class="field"><label>شهر (اختیاری)</label><input class="input" name="city" form="wizf" value="' + esc(d.profile.city) + '"></div>' +
      '<div class="field"><label>وضعیت تأهل (اختیاری)</label><select class="select" name="marital" form="wizf">' + opt(['', 'مجرد', 'متأهل', 'جداشده'], d.profile.marital) + '</select></div>' +
      '<div class="field"><label>تعداد افراد تحت تکفل</label><input class="input num" name="dependents" form="wizf" inputmode="numeric" value="' + (d.profile.dependents || 0) + '"></div>' +
      '<div class="field"><label>واحد پول اصلی تو</label><select class="select" name="currency" form="wizf">' +
      Object.keys(CURRENCIES).map((k) => '<option value="' + k + '"' + (d.profile.currency === k ? ' selected' : '') + '>' + CURRENCIES[k].fa + '</option>').join('') + '</select>' +
      '<input class="input mt" name="currencyLabel" form="wizf" placeholder="اگر «واحد سفارشی» انتخاب کردی، نامش را بنویس" value="' + esc(d.profile.currencyLabel || '') + '"></div>' +
      '<button class="btn btn--primary btn--block" form="wizf" type="submit" data-step="1">ذخیره و ادامه</button>', '');
  }

  if (step === 2) {
    const jobs = ['کارمند', 'کارگر', 'تکنسین', 'مهندس', 'مدیر', 'صاحب کسب‌وکار', 'فریلنسر', 'فروشنده', 'سرمایه‌گذار', 'دانشجو', 'بیکار', 'سایر'];
    const skills = ['برق صنعتی', 'مکانیک', 'تعمیرات', 'برنامه‌نویسی', 'هوش مصنوعی', 'فروش', 'بازاریابی', 'مدیریت', 'مالی', 'سرمایه‌گذاری', 'تولید', 'کشاورزی', 'معدن', 'ساختمان', 'تجارت', 'آموزش', 'پزشکی', 'مهندسی', 'طراحی', 'محتوا', 'خدمات', 'سایر'];
    html += card('<div class="field"><label>وضعیت شغلی</label><div class="pick">' + jobs.map((j) =>
      '<button class="pick__opt ' + (d.profile.job === j ? 'is-on' : '') + '" data-act="wiz.set" data-k="job" data-v="' + j + '">' + j + '</button>').join('') + '</div></div>' +
      '<div class="field"><label>تخصص‌ها (چند مورد)</label><div class="pick">' + skills.map((s) =>
        '<button class="pick__opt ' + ((d.profile.skills || []).indexOf(s) > -1 ? 'is-on' : '') + '" data-act="wiz.toggleSkill" data-v="' + s + '">' + s + '</button>').join('') + '</div></div>' +
      '<div class="field"><label>سال تجربه</label><input class="input num" name="experienceYears" form="wizf" inputmode="numeric" value="' + (d.profile.experienceYears || 0) + '"></div>' +
      '<div class="field"><label>ساعت آزاد در روز (واقعی، نه ایده‌آل)</label><input class="input num" name="freeHours" form="wizf" inputmode="decimal" value="' + (d.profile.freeHours || 2) + '"></div>' +
      '<div class="field"><label>ریسک‌پذیری: ' + FA(d.profile.riskTolerance || 50) + '/100</label><input class="range" name="riskTolerance" form="wizf" type="range" min="0" max="100" step="5" value="' + (d.profile.riskTolerance || 50) + '"></div>' +
      '<button class="btn btn--primary btn--block" form="wizf" type="submit" data-step="2">ذخیره و ادامه</button>', '');
  }

  if (step === 3) {
    html += card('<p class="tiny">مبالغ را با «میلیون» یا «هزار» بنویس؛ برنامه خودش تبدیل می‌کند.</p>' +
      '<div class="field"><label>درآمد ماهانه کل</label><input class="input num" name="incomeMonthly" form="wizf" inputmode="decimal" placeholder="مثلاً 50 میلیون"></div>' +
      '<div class="field"><label>سهم درآمد ثابت (اختیاری)</label><input class="input num" name="incomeFixed" form="wizf" inputmode="decimal"></div>' +
      '<div class="field"><label>هزینه ماهانه کل</label><input class="input num" name="expenseMonthly" form="wizf" inputmode="decimal" placeholder="مثلاً 30 میلیون"></div>' +
      '<div class="field"><label>بزرگ‌ترین دسته هزینه (مسکن/غذا/…)</label><input class="input" name="expenseMain" form="wizf" placeholder="مثلاً مسکن"></div>' +
      '<div class="field"><label>مبلغ بزرگ‌ترین دسته هزینه</label><input class="input num" name="expenseMainAmount" form="wizf" inputmode="decimal"></div>' +
      '<button class="btn btn--primary btn--block" form="wizf" type="submit" data-step="3">ذخیره و ادامه</button>', '');
  }

  if (step === 4) {
    html += card('<p class="tiny">خالص ثروت = دارایی − بدهی. همین عدد، معیار واقعی پیشرفت تو است.</p>' +
      '<div class="field"><label>پول نقد</label><input class="input num" name="cash" form="wizf" inputmode="decimal"></div>' +
      '<div class="field"><label>سپرده/سرمایه‌گذاری</label><input class="input num" name="deposit" form="wizf" inputmode="decimal"></div>' +
      '<div class="field"><label>طلا و ارز</label><input class="input num" name="gold" form="wizf" inputmode="decimal"></div>' +
      '<div class="field"><label>ملک و خودرو و تجهیزات</label><input class="input num" name="physical" form="wizf" inputmode="decimal"></div>' +
      '<div class="field"><label>مجموع بدهی</label><input class="input num" name="debtTotal" form="wizf" inputmode="decimal"></div>' +
      '<div class="field"><label>نرخ بهره میانگین بدهی (٪)</label><input class="input num" name="debtRate" form="wizf" inputmode="decimal" value="20"></div>' +
      '<div class="field"><label>قسط ماهانه بدهی</label><input class="input num" name="debtMonthly" form="wizf" inputmode="decimal"></div>' +
      '<button class="btn btn--primary btn--block" form="wizf" type="submit" data-step="4">ذخیره و ادامه</button>', '');
  }

  if (step === 5) {
    const goals = ['استقلال مالی', 'ثروت ۱ میلیارد', 'ثروت ۱۰ میلیارد', 'میلیونر شدن', 'میلیاردر شدن', 'ساخت کسب‌وکار', 'بازنشستگی زودهنگام', 'افزایش درآمد', 'خروج از بدهی'];
    html += card('<div class="field"><label>هدف اصلی تو چیست؟</label><div class="pick pick--wide">' + goals.map((g) =>
      '<button class="pick__opt ' + (d.__goalTitle === g ? 'is-on' : '') + '" data-act="wiz.goal" data-v="' + g + '">' + g + '</button>').join('') + '</div></div>' +
      '<div class="field"><label>مبلغ هدف (عدد)</label><input class="input num" name="goalAmount" form="wizf" inputmode="decimal" placeholder="مثلاً 1 میلیارد"></div>' +
      '<div class="field"><label>درآمد ماهانه هدف</label><input class="input num" name="goalMonthly" form="wizf" inputmode="decimal"></div>' +
      '<div class="field"><label>مهلت (سال)</label><input class="input num" name="goalYears" form="wizf" inputmode="numeric" value="5"></div>' +
      '<div class="alert alert--warn"><i>❓</i><div class="tiny">اگر «میلیاردر شدن» را انتخاب کردی: منظورت ۱ میلیارد از چه واحد پولی است؟ (تومان / دلار / یورو / سایر) — واحد را در مرحله اول تعیین کردی و برنامه بر همان اساس محاسبه می‌کند.</div></div>' +
      '<div class="field"><label>چرا می‌خواهی ثروتمند شوی؟ (مأموریت شخصی)</label><textarea class="textarea" name="mission" form="wizf" placeholder="آزادی زمانی، خانواده، امنیت، کمک به دیگران…">' + esc(d.profile.mission || '') + '</textarea></div>' +
      '<button class="btn btn--primary btn--block" form="wizf" type="submit" data-step="5">ذخیره و ادامه</button>', '');
  }

  if (step === 6) {
    html += card('<p>همه چیز آماده است. برنامه الان پروفایل تو را تحلیل می‌کند، مسیرهای مناسب را امتیازدهی می‌کند و نقشه راه ۱۲ ماهه با کارهای روزانه می‌سازد.</p>' +
      '<div class="alert alert--ok"><i>🚀</i><div class="tiny">همه محاسبات روی همین دستگاه و بدون اینترنت انجام می‌شود.</div></div>' +
      '<button class="btn btn--primary btn--block mt" data-act="wiz.finish">تحلیل و ساخت نقشه راه من</button>', '');
  }

  if (step > 0) html += '<div class="btn-row mt"><button class="btn btn--ghost" data-act="wiz.prev">مرحله قبل</button></div>';
  html += '<form id="wizf" data-form="wiz.save" data-step="' + step + '"></form>';
  return html;
}

function opt(list, val) {
  return list.map((l) => '<option value="' + esc(l) + '"' + (String(l) === String(val) ? ' selected' : '') + '>' + esc(l || '—') + '</option>').join('');
}

reg('wiz', {
  next() { step = Math.min(STEPS.length - 1, step + 1); render(); },
  prev() { step = Math.max(0, step - 1); render(); },
  set(el, ds) { const d = ensureDraft(); d.profile[ds.k] = ds.v; render(); },
  toggleSkill(el, ds) {
    const d = ensureDraft();
    d.profile.skills = d.profile.skills || [];
    const i = d.profile.skills.indexOf(ds.v);
    if (i > -1) d.profile.skills.splice(i, 1); else d.profile.skills.push(ds.v);
    render();
  },
  goal(el, ds) { const d = ensureDraft(); d.__goalTitle = ds.v; render(); },
  demo() {
    applyDemo();
    step = 0; draft = null;
    toast('نسخه نمایشی بارگذاری شد — همه امکانات فعال است');
    location.hash = '#/today'; render();
  },
  finish() {
    finishOnboarding();
  },
});

reg('form', {
  'wiz.save'(fd, el) {
    const d = ensureDraft();
    const stepNo = +(el.dataset.step || 0);
    if (stepNo === 1) {
      d.profile.name = fd.name || ''; d.profile.age = parseInt(fd.age, 10) || 30;
      d.profile.gender = fd.gender || ''; d.profile.country = fd.country || 'ایران';
      d.profile.city = fd.city || ''; d.profile.marital = fd.marital || '';
      d.profile.dependents = parseInt(fd.dependents, 10) || 0;
      d.profile.currency = fd.currency || 'IRT';
      d.profile.currencyLabel = fd.currencyLabel || '';
    }
    if (stepNo === 2) {
      d.profile.experienceYears = parseInt(fd.experienceYears, 10) || 0;
      d.profile.freeHours = parseFloat(fd.freeHours) || 1;
      d.profile.riskTolerance = parseInt(fd.riskTolerance, 10) || 50;
    }
    if (stepNo === 3) {
      const inc = num(fd.incomeMonthly), fixed = num(fd.incomeFixed) || inc;
      d.finance.incomes = [];
      if (inc > 0) d.finance.incomes.push({ id: uid('i'), label: 'درآمد اصلی', amount: inc, type: fixed >= inc ? 'fixed' : 'mixed', kind: 'salary' });
      if (fixed > 0 && fixed < inc) d.finance.incomes.push({ id: uid('i'), label: 'درآمد متغیر', amount: inc - fixed, type: 'variable', kind: 'side' });
      const exp = num(fd.expenseMonthly);
      d.finance.expenses = [];
      if (exp > 0) {
        d.finance.expenses.push({ id: uid('e'), label: fd.expenseMain || 'هزینه اصلی', category: fd.expenseMain || 'سایر', amount: num(fd.expenseMainAmount) || exp });
        if ((num(fd.expenseMainAmount) || exp) < exp) d.finance.expenses.push({ id: uid('e'), label: 'سایر هزینه‌ها', category: 'سایر', amount: exp - (num(fd.expenseMainAmount) || 0) });
      }
    }
    if (stepNo === 4) {
      d.finance.assets = [];
      const cash = num(fd.cash), dep = num(fd.deposit), gold = num(fd.gold), phys = num(fd.physical);
      if (cash > 0) d.finance.assets.push({ id: uid('a'), label: 'پول نقد', category: 'نقد', amount: cash, liquid: true });
      if (dep > 0) d.finance.assets.push({ id: uid('a'), label: 'سپرده/سرمایه‌گذاری', category: 'سپرده', amount: dep, liquid: false });
      if (gold > 0) d.finance.assets.push({ id: uid('a'), label: 'طلا و ارز', category: 'طلا', amount: gold, liquid: false });
      if (phys > 0) d.finance.assets.push({ id: uid('a'), label: 'دارایی فیزیکی', category: 'ملک', amount: phys, liquid: false });
      d.finance.debts = [];
      const debt = num(fd.debtTotal);
      if (debt > 0) d.finance.debts.push({
        id: uid('d'), label: 'بدهی', kind: 'loan', amount: debt,
        rate: parseFloat(fd.debtRate) || 0, monthlyPayment: num(fd.debtMonthly), term: 12,
      });
    }
    if (stepNo === 5) {
      d.__goalAmount = num(fd.goalAmount);
      d.__goalMonthly = num(fd.goalMonthly);
      d.__goalYears = parseInt(fd.goalYears, 10) || 5;
      d.profile.mission = fd.mission || '';
      d.profile.reasons = String(fd.mission || '').split(/[،,.\n]/).map((x) => x.trim()).filter((x) => x.length > 2).slice(0, 4);
    }
    step = Math.min(STEPS.length - 1, stepNo + 1);
    render();
  },
});

function num(v) {
  const s = String(v == null ? '' : v);
  const mult = /میلیارد/.test(s) ? 1e9 : /میلیون/.test(s) ? 1e6 : /هزار/.test(s) ? 1e3 : 1;
  const n = parseFloat(s.replace(/[^\d.\-]/g, ''));
  return isNaN(n) ? 0 : n * mult;
}

function finishOnboarding() {
  const d = ensureDraft();
  State.replace(d);
  State.update((s) => {
    s.onboardingDone = true;
    s.demoMode = false;
    s.id = uid('user');
    s.createdAt = todayKey();
    if (!s.goals.length) {
      const title = d.__goalTitle || 'استقلال مالی';
      s.goals.push({
        id: uid('g'), title, type: title.indexOf('استقلال') > -1 ? 'freedom' : 'custom',
        unit: s.profile.currency, targetAmount: d.__goalAmount || 0, monthlyIncomeTarget: d.__goalMonthly || 0,
        deadline: addYears(todayKey(), d.__goalYears || 5), createdAt: todayKey(), done: false,
        custom: { monthlyIncomeTarget: d.__goalMonthly || 0 },
      });
    }
    const paths = discoverPaths(s);
    const best = paths[0];
    s.plan.pathId = best.id;
    s.plan.roadmap = buildRoadmap(s, best).roadmap;
    ensureDay(s, todayKey());
    s.meta.lastRecalc = todayKey();
    s.gamification.xp += 30;
  });
  draft = null; step = 0;
  const st = State.get();
  const ch = chooseBest(st);
  toast('پروفایل ساخته شد 🎯');
  modal({
    title: 'تحلیل اولیه آماده شد',
    body: '<p>' + esc(ch.text) + '</p>' +
      '<div class="alert alert--ok mt"><i>🔥</i><div class="tiny"><b>مهم‌ترین اقدام امروز:</b> ' + esc((st.plan.days[todayKey()] || { bigMove: { title: '' } }).bigMove ? st.plan.days[todayKey()].bigMove.title : '') + '</div></div>' +
      '<button class="btn btn--primary btn--block mt" data-act="wiz.goToday">شروع امروز</button>',
  });
}
function addYears(key, n) {
  const d = new Date(key);
  d.setFullYear(d.getFullYear() + n);
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
reg('wiz', {
  goToday() { closeModal(); location.hash = '#/today'; render(); },
});

register('wizard', { title: 'شروع', eyebrow: 'پروفایل مالی تو', render: wizRender, tab: false });

/* ------------------------------------------------------------------ PROFILE */
function profileRender() {
  const state = State.get();
  const p = state.profile;
  const paths = discoverPaths(state);
  let html = '';
  html += section('اطلاعات شخصی', card(
    kv('نام', esc(p.name || '—')) + kv('سن', FA(p.age)) + kv('کشور/شهر', esc(p.country + (p.city ? ' / ' + p.city : ''))) +
    kv('وضعیت تأهل', esc(p.marital || '—')) + kv('افراد تحت تکفل', FA(p.dependents)) +
    kv('واحد پول', esc(p.currency === 'OTHER' ? (p.currencyLabel || 'سفارشی') : (CURRENCIES[p.currency] || {}).fa || 'تومان')) +
    '<div class="btn-row mt"><button class="btn btn--sm btn--primary" data-act="profile.editPersonal">ویرایش</button></div>', ''));

  html += section('شغل، تخصص و زمان', card(
    kv('شغل', esc(p.job || '—')) + kv('تخصص‌ها', esc((p.skills || []).join('، ') || '—')) +
    kv('تجربه', FA(p.experienceYears) + ' سال') + kv('زمان آزاد روزانه', FA(p.freeHours) + ' ساعت') +
    kv('ریسک‌پذیری', FA(p.riskTolerance) + '/100') +
    '<div class="btn-row mt"><button class="btn btn--sm btn--primary" data-act="profile.editJob">ویرایش</button>' +
    '<button class="btn btn--sm" data-act="ui.nav" data-id="skills">درخت مهارت</button></div>', ''));

  html += section('مالی (خلاصه)', card(
    kv('درآمد ماهانه', fmtCompact((state.finance.incomes || []).reduce((a, b) => a + (+b.amount || 0), 0), p)) +
    kv('هزینه ماهانه', fmtCompact((state.finance.expenses || []).reduce((a, b) => a + (+b.amount || 0), 0), p)) +
    kv('دارایی', fmtCompact((state.finance.assets || []).reduce((a, b) => a + (+b.amount || 0), 0), p)) +
    kv('بدهی', fmtCompact((state.finance.debts || []).reduce((a, b) => a + (+b.amount || 0), 0), p)) +
    '<div class="btn-row mt"><button class="btn btn--sm btn--primary" data-act="ui.nav" data-id="wealth">مدیریت ثروت</button>' +
    '<button class="btn btn--sm" data-act="ui.nav" data-id="wizard">تکمیل مجدد ویزارد</button></div>', ''));

  html += section('هدف و مأموریت', card(
    kv('هدف فعال', esc((state.goals[0] || {}).title || '—')) +
    kv('مبلغ هدف', fmtCompact((state.goals[0] || {}).targetAmount || 0, p)) +
    kv('مأموریت شخصی', esc(p.mission || '—')) +
    '<div class="btn-row mt"><button class="btn btn--sm btn--primary" data-act="goal.add">هدف جدید</button>' +
    '<button class="btn btn--sm" data-act="profile.openMission">مأموریت</button></div>', ''));

  html += section('مسیر پیشنهادی فعلی', card(
    '<div class="card__title">' + paths[0].icon + ' ' + esc(paths[0].fa) + '</div>' +
    '<p class="tiny">' + esc(paths[0].why) + '</p>' +
    '<p class="tiny">تناسب: ' + FA(paths[0].fitPercent) + '٪ — ریسک: ' + esc(paths[0].riskLevel) + ' — سرمایه لازم: ' + fmtCompact(paths[0].capitalNeeded, p) + '</p>' +
    '<div class="btn-row mt"><button class="btn btn--sm btn--primary" data-act="path.compare">مقایسه مسیرها</button>' +
    '<button class="btn btn--sm" data-act="profile.recalc">بازمحاسبه مسیر</button></div>', ''));

  html += disclaimer('هر تغییری در پروفایل، امتیاز مالی، مسیر پیشنهادی و نقشه راه را دوباره محاسبه می‌کند.');
  return html;
}

reg('profile', {
  editPersonal() {
    const p = State.get().profile;
    modal({
      title: 'ویرایش اطلاعات شخصی',
      body: '<form data-form="profile.personal">' +
        '<div class="field"><label>نام</label><input class="input" name="name" value="' + esc(p.name) + '"></div>' +
        '<div class="field"><label>سن</label><input class="input num" name="age" value="' + p.age + '"></div>' +
        '<div class="field"><label>کشور</label><input class="input" name="country" value="' + esc(p.country) + '"></div>' +
        '<div class="field"><label>شهر</label><input class="input" name="city" value="' + esc(p.city) + '"></div>' +
        '<div class="field"><label>وضعیت تأهل</label><select class="select" name="marital">' + opt(['', 'مجرد', 'متأهل', 'جداشده'], p.marital) + '</select></div>' +
        '<div class="field"><label>افراد تحت تکفل</label><input class="input num" name="dependents" value="' + p.dependents + '"></div>' +
        '<div class="field"><label>واحد پول</label><select class="select" name="currency">' + Object.keys(CURRENCIES).map((k) => '<option value="' + k + '"' + (p.currency === k ? ' selected' : '') + '>' + CURRENCIES[k].fa + '</option>').join('') + '</select></div>' +
        '<div class="field"><label>نام واحد سفارشی</label><input class="input" name="currencyLabel" value="' + esc(p.currencyLabel || '') + '"></div>' +
        '<button class="btn btn--primary btn--block" type="submit">ذخیره</button></form>',
    });
  },
  editJob() {
    const p = State.get().profile;
    const jobs = ['کارمند', 'کارگر', 'تکنسین', 'مهندس', 'مدیر', 'صاحب کسب‌وکار', 'فریلنسر', 'فروشنده', 'سرمایه‌گذار', 'دانشجو', 'بیکار', 'سایر'];
    const skills = ['برق صنعتی', 'مکانیک', 'تعمیرات', 'برنامه‌نویسی', 'هوش مصنوعی', 'فروش', 'بازاریابی', 'مدیریت', 'مالی', 'سرمایه‌گذاری', 'تولید', 'کشاورزی', 'معدن', 'ساختمان', 'تجارت', 'آموزش', 'پزشکی', 'مهندسی', 'طراحی', 'محتوا', 'خدمات', 'سایر'];
    modal({
      title: 'شغل، تخصص و زمان',
      body: '<form data-form="profile.job">' +
        '<div class="field"><label>شغل</label><select class="select" name="job">' + jobs.map((j) => '<option' + (p.job === j ? ' selected' : '') + '>' + j + '</option>').join('') + '</select></div>' +
        '<div class="field"><label>تخصص‌ها</label><div class="pick">' + skills.map((s) =>
          '<button type="button" class="pick__opt ' + ((p.skills || []).indexOf(s) > -1 ? 'is-on' : '') + '" data-act="profile.toggleSkill" data-v="' + s + '">' + s + '</button>').join('') + '</div></div>' +
        '<div class="field"><label>سال تجربه</label><input class="input num" name="experienceYears" value="' + p.experienceYears + '"></div>' +
        '<div class="field"><label>ساعت آزاد روزانه</label><input class="input num" name="freeHours" value="' + p.freeHours + '"></div>' +
        '<div class="field"><label>ریسک‌پذیری (۰-۱۰۰)</label><input class="input num" name="riskTolerance" value="' + p.riskTolerance + '"></div>' +
        '<button class="btn btn--primary btn--block" type="submit">ذخیره و بازمحاسبه مسیر</button></form>',
    });
  },
  toggleSkill(el) {
    el.classList.toggle('is-on');
  },
  openMission() {
    const p = State.get().profile;
    modal({
      title: 'مأموریت شخصی',
      body: '<form data-form="profile.mission">' +
        '<div class="field"><label>چرا می‌خواهی ثروتمند شوی؟</label>' +
        '<textarea class="textarea" name="mission" placeholder="آزادی زمانی، خانواده، امنیت، کمک به دیگران…">' + esc(p.mission || '') + '</textarea></div>' +
        '<div class="field"><label>دلایل (با کاما جدا کن)</label><input class="input" name="reasons" value="' + esc((p.reasons || []).join('، ')) + '"></div>' +
        '<button class="btn btn--primary btn--block" type="submit">ذخیره</button></form>',
    });
  },
  recalc() {
    State.update((s) => {
      const paths = discoverPaths(s);
      s.plan.pathId = paths[0].id;
      s.plan.roadmap = buildRoadmap(s, paths[0]).roadmap;
      s.meta.lastRecalc = todayKey();
    });
    toast('مسیر و نقشه راه بازمحاسبه شد'); render();
  },
});

reg('form', {
  'profile.personal'(fd) {
    State.update((s) => {
      s.profile.name = fd.name || ''; s.profile.age = parseInt(fd.age, 10) || s.profile.age;
      s.profile.country = fd.country || ''; s.profile.city = fd.city || '';
      s.profile.marital = fd.marital || ''; s.profile.dependents = parseInt(fd.dependents, 10) || 0;
      s.profile.currency = fd.currency || s.profile.currency; s.profile.currencyLabel = fd.currencyLabel || '';
      s.meta.lastRecalc = todayKey();
    });
    closeModal(); toast('اطلاعات ذخیره و مسیر بازمحاسبه شد'); render();
  },
  'profile.job'(fd) {
    State.update((s) => {
      s.profile.job = fd.job || s.profile.job;
      const sel = Array.prototype.slice.call(document.querySelectorAll('.pick__opt.is-on')).map((x) => x.dataset.v);
      if (sel.length) s.profile.skills = sel;
      s.profile.experienceYears = parseInt(fd.experienceYears, 10) || 0;
      s.profile.freeHours = parseFloat(fd.freeHours) || 1;
      s.profile.riskTolerance = parseInt(fd.riskTolerance, 10) || 50;
      const paths = discoverPaths(s);
      s.plan.pathId = paths[0].id;
      s.plan.roadmap = buildRoadmap(s, paths[0]).roadmap;
      s.meta.lastRecalc = todayKey();
    });
    closeModal(); toast('ذخیره شد و مسیر بازمحاسبه شد'); render();
  },
});

register('profile', { title: 'پروفایل', eyebrow: 'اطلاعات و شخصی‌سازی', render: profileRender, tab: false });

/* ----------------------------------------------------------------- SETTINGS */
function settingsRender() {
  const state = State.get();
  const s = state.settings;
  let html = '';
  html += section('نمایش', card(
    '<div class="list-row"><div class="list-row__main"><div class="list-row__title">حالت تیره</div><div class="list-row__sub">طراحی تیره سرمه‌ای و طلایی</div></div>' +
    '<button class="switch ' + (s.theme === 'dark' ? 'on' : '') + '" data-act="settings.theme"><i></i></button></div>' +
    '<div class="list-row"><div class="list-row__main"><div class="list-row__title">اعداد فارسی</div><div class="list-row__sub">نمایش اعداد با ارقام فارسی</div></div>' +
    '<button class="switch ' + (s.persianDigits ? 'on' : '') + '" data-act="settings.digits"><i></i></button></div>' +
    '<div class="field mt"><label>زبان (Language)</label><select class="select" data-change="settings.lang">' +
    Object.keys(LANGS).map((k) => '<option value="' + k + '"' + (s.language === k ? ' selected' : '') + '>' + LANGS[k].name + '</option>').join('') + '</select>' +
    '<p class="hint">ساختار چندزبانه آماده است؛ ترجمه کامل در نسخه بعدی فعال می‌شود.</p></div>', ''));

  html += section('اعلان‌های محلی', card(
    '<div class="list-row"><div class="list-row__main"><div class="list-row__title">اعلان روی دستگاه</div>' +
    '<div class="list-row__sub">وضعیت مجوز: ' + esc(notifPermission()) + '</div></div>' +
    '<button class="switch ' + (s.notifications ? 'on' : '') + '" data-act="settings.notif"><i></i></button></div>' +
    '<p class="hint">اعلان‌ها کاملاً محلی هستند؛ هیچ سرویس بیرونی درگیر نیست.</p>', ''));

  html += section('امنیت', card(
    '<div class="list-row"><div class="list-row__main"><div class="list-row__title">قفل برنامه با PIN</div>' +
    '<div class="list-row__sub">' + (Security.hasPin() ? 'PIN فعال است' : 'PIN تنظیم نشده') + '</div></div>' +
    '<button class="switch ' + (s.lockEnabled && Security.hasPin() ? 'on' : '') + '" data-act="settings.lock"><i></i></button></div>' +
    '<div class="btn-row mt"><button class="btn btn--sm" data-act="settings.setPin">' + (Security.hasPin() ? 'تغییر PIN' : 'تنظیم PIN') + '</button>' +
    '<button class="btn btn--sm" data-act="settings.clearPin">حذف PIN</button>' +
    '<button class="btn btn--sm" data-act="settings.encrypt">' + (Security.info().encryptExports ? 'رمز خروجی: روشن' : 'رمز خروجی: خاموش') + '</button></div>' +
    '<p class="hint">خروجی پشتیبان می‌تواند با عبارت رمز رمزگذاری شود (بدون اینترنت).</p>', ''));

  html += section('داده‌ها', card(
    kv('حجم داده ذخیره‌شده', toFaDigits(Math.round(storageUsage() / 1024)) + ' کیلوبایت') +
    kv('حالت نمایشی', state.demoMode ? 'فعال' : 'غیرفعال') +
    '<div class="btn-row mt"><button class="btn btn--sm" data-act="ui.nav" data-id="backup">پشتیبان‌گیری</button>' +
    '<button class="btn btn--sm btn--danger" data-act="settings.clearDemo">پاک کردن اطلاعات نمونه</button>' +
    '<button class="btn btn--sm btn--danger" data-act="settings.wipe">پاک کردن همه اطلاعات</button></div>' +
    '<p class="hint">«پاک کردن اطلاعات نمونه» برنامه را برای استفاده شخصی خالی می‌کند؛ «پاک کردن همه» تمام داده‌ها را حذف می‌کند.</p>', ''));

  html += section('درباره', card(
    kv('نسخه', '۱٫۰٫۰') + kv('حالت', '۱۰۰٪ آفلاین') + kv('موتور تصمیم', 'Rule Engine + پایگاه دانش داخلی') +
    '<div class="btn-row mt"><button class="btn btn--sm" data-act="ui.nav" data-id="about">جزئیات حریم خصوصی</button></div>', ''));
  return html;
}

reg('settings', {
  theme() {
    State.update((s) => { s.settings.theme = s.settings.theme === 'dark' ? 'light' : 'dark'; });
    render();
  },
  digits() { State.update((s) => { s.settings.persianDigits = !s.settings.persianDigits; }); toast('حالت نمایش اعداد تغییر کرد'); render(); },
  lang(el) {
    const v = el.value;
    State.update((s) => { s.settings.language = v; });
    setLang(v);
    document.documentElement.setAttribute('dir', LANGS[v] ? LANGS[v].dir : 'rtl');
    toast('زبان تغییر کرد (نسخه کامل چندزبانه در نسخه بعد)'); render();
  },
  async notif() {
    if (!State.get().settings.notifications) {
      const p = await requestNotifPermission();
      State.update((s) => { s.settings.notifications = p === 'granted'; });
      toast(p === 'granted' ? 'اعلان محلی فعال شد' : 'مجوز اعلان داده نشد', p === 'granted' ? '' : 'red');
    } else {
      State.update((s) => { s.settings.notifications = false; });
      toast('اعلان غیرفعال شد');
    }
    render();
  },
  lock() {
    const s = State.get().settings;
    if (!Security.hasPin()) { ActionsSetPin(); return; }
    State.update((st) => { st.settings.lockEnabled = !st.settings.lockEnabled; });
    toast(State.get().settings.lockEnabled ? 'قفل برنامه فعال شد' : 'قفل برنامه خاموش شد'); render();
  },
  setPin() { ActionsSetPin(); },
  clearPin() { Security.clearPin(); State.update((s) => { s.settings.lockEnabled = false; }); toast('PIN حذف شد'); render(); },
  encrypt() {
    Security.setEncryptExports(!Security.info().encryptExports);
    toast(Security.info().encryptExports ? 'خروجی پشتیبان رمزگذاری می‌شود' : 'خروجی پشتیبان بدون رمز ذخیره می‌شود'); render();
  },
  clearDemo() { confirmModal('پاک کردن اطلاعات نمونه', 'همه داده‌های نمایشی حذف و برنامه برای استفاده شخصی خالی می‌شود. ادامه می‌دهی؟', 'settings.clearDemoConfirm', {}); },
  clearDemoConfirm() {
    clearDemoData().then(() => { closeModal(); toast('اطلاعات نمونه پاک شد — ویزارد شروع می‌شود'); location.hash = '#/wizard'; render(); });
  },
  wipe() { confirmModal('پاک کردن همه اطلاعات', 'این عمل قابل بازگشت نیست. بهتر است اول از اطلاعات خود پشتیبان بگیری.', 'settings.wipeConfirm', {}); },
  wipeConfirm() {
    wipeAll().then(() => { closeModal(); toast('همه اطلاعات پاک شد'); location.hash = '#/wizard'; render(); });
  },
});

function ActionsSetPin() {
  modal({
    title: 'تنظیم PIN',
    body: '<form data-form="settings.pin">' +
      '<div class="field"><label>PIN (۴ تا ۸ رقم)</label><input class="input num" name="pin" inputmode="numeric" type="password"></div>' +
      '<div class="field"><label>سؤال بازیابی</label><input class="input" name="question" value="نام اولین مدرسه‌ات؟"></div>' +
      '<div class="field"><label>پاسخ بازیابی</label><input class="input" name="answer"></div>' +
      '<button class="btn btn--primary btn--block" type="submit">ذخیره PIN</button></form>',
  });
}
reg('form', {
  'settings.pin'(fd) {
    const pin = String(fd.pin || '').trim();
    if (pin.length < 4) { toast('PIN باید حداقل ۴ رقم باشد', 'red'); return; }
    Security.setPin(pin);
    Security.setRecovery(fd.question, fd.answer);
    State.update((s) => { s.settings.lockEnabled = true; });
    closeModal(); toast('PIN تنظیم و قفل فعال شد'); render();
  },
});
register('settings', { title: 'تنظیمات', eyebrow: 'نمایش، امنیت، داده', render: settingsRender, tab: false });

/* ------------------------------------------------------------------ BACKUP */
function backupRender() {
  const state = State.get();
  let html = '';
  html += section('خروجی گرفتن (Export)', card(
    '<p class="tiny">فایل JSON شامل همه اطلاعات تو ساخته می‌شود: پروفایل، تراکنش‌ها، دارایی، بدهی، اهداف، نقشه راه، کارها، عادت‌ها و پیشرفت.</p>' +
    '<div class="field"><label>عبارت رمز (اختیاری)</label><input class="input" id="bkPass" placeholder="برای رمزگذاری فایل، عبارتی بنویس"></div>' +
    '<button class="btn btn--primary btn--block" data-act="backup.export">دانلود فایل پشتیبان</button>' +
    '<p class="hint">نام فایل نمونه: پشتیبان اطلاعات من ۰۷-۱۰-۲۰۲۶.json</p>', ''));
  html += section('بازیابی (Import)', card(
    '<input class="input" type="file" id="bkFile" accept=".json,application/json">' +
    '<div class="field mt"><label>عبارت رمز (اگر فایل رمزگذاری شده)</label><input class="input" id="bkPassIn"></div>' +
    '<button class="btn btn--primary btn--block" data-act="backup.import">بازیابی از فایل</button>' +
    '<p class="hint">بازیابی، اطلاعات فعلی را با اطلاعات فایل جایگزین می‌کند.</p>', ''));
  html += section('وضعیت داده‌ها', card(
    kv('تعداد تراکنش‌ها', FA((state.finance.transactions || []).length)) +
    kv('تعداد کارهای برنامه', FA(Object.keys(state.plan.days || {}).length) + ' روز') +
    kv('تعداد دستاوردها', FA((state.gamification.achievements || []).length)) +
    kv('حجم ذخیره‌سازی', toFaDigits(Math.round(storageUsage() / 1024)) + ' کیلوبایت'), ''));
  html += section('منطقه خطر', card(
    '<div class="btn-row"><button class="btn btn--sm btn--danger" data-act="settings.clearDemo">پاک کردن اطلاعات نمونه</button>' +
    '<button class="btn btn--sm btn--danger" data-act="settings.wipe">پاک کردن همه اطلاعات</button></div>', ''));
  html += disclaimer('پشتیبان‌گیری و بازیابی کاملاً روی دستگاه انجام می‌شود؛ هیچ فایلی آپلود نمی‌شود.');
  return html;
}

reg('backup', {
  export() {
    const pass = (document.getElementById('bkPass') || {}).value || '';
    const enc = Security.info().encryptExports;
    exportBackup(pass || (enc ? 'bp' : '')).then(() => toast('فایل پشتیبان ساخته شد 💾')).catch((e) => toast('خطا: ' + e.message, 'red'));
  },
  import() {
    const input = document.getElementById('bkFile');
    const passEl = document.getElementById('bkPassIn');
    if (!input || !input.files || !input.files[0]) { toast('ابتدا فایل پشتیبان را انتخاب کن', 'red'); return; }
    importBackup(input.files[0], (passEl && passEl.value) || '').then(() => {
      toast('اطلاعات با موفقیت بازیابی شد ✅');
      location.hash = '#/dashboard'; render();
    }).catch((e) => toast('خطا: ' + e.message, 'red'));
  },
});
register('backup', { title: 'پشتیبان‌گیری', eyebrow: 'خروجی و بازیابی JSON', render: backupRender, tab: false });

/* ------------------------------------------------------------- ACHIEVEMENTS */
function achievementsRender() {
  const state = State.get();
  const lv = levelInfo(state.gamification.xp);
  const list = achievementsOf(state);
  const prog = totalAchievementProgress(state);
  let html = '';
  html += '<div class="hero"><div class="row" style="gap:14px">' +
    '<div style="font-size:38px">' + lv.icon + '</div>' +
    '<div style="flex:1"><div class="card__title">سطح ' + FA(lv.level) + ': ' + esc(lv.fa) + '</div>' +
    '<p class="tiny">' + FA(state.gamification.xp || 0) + ' XP' + (lv.next ? ' — تا سطح بعد: ' + FA(lv.toNext) + ' XP (' + lv.next.fa + ')' : ' — بالاترین سطح!') + '</p>' +
    bar(lv.progress * 100, 'bar--gold') + '</div></div></div>';
  html += section('سطح‌ها', card(LEVELS.map((l, i) =>
    '<div class="kv"><span>' + l.icon + ' ' + esc(l.fa) + ' (' + esc(l.en) + ')</span><b class="' + (state.gamification.xp >= l.min ? 'pos' : '') + '">' + FA(l.min) + ' XP</b></div>').join(''), ''));
  html += section('دستاوردها (' + FA(prog.have) + ' از ' + FA(prog.total) + ')', card(
    '<div class="grid grid-2">' + list.map((a) =>
      '<div class="card ' + (a.unlocked ? 'card--gold' : 'locked') + '" style="padding:11px"><div style="font-size:20px">' + a.icon + '</div>' +
      '<div style="font-weight:800;font-size:13px;margin-top:3px">' + esc(a.fa) + '</div>' +
      '<div class="tiny">' + esc(a.desc) + '</div>' +
      (a.unlocked ? '<div class="tiny gold mt">' + esc(a.at || '') + '</div>' : '<div class="tiny mt">🔒 باز نشده</div>') + '</div>').join('') + '</div>', ''));
  const hist = xpHistory(state);
  if (hist.length) html += section('آخرین امتیازها', card(hist.map((h) =>
    '<div class="kv"><span>' + esc(h.label || h.kind) + '</span><b class="pos">+' + FA(h.xp) + ' XP</b></div>').join(''), ''));
  html += section('قوانین امتیازدهی', card(
    kv('انجام کار', '+' + FA(XP_RULES.task) + ' XP') + kv('عادت', '+' + FA(XP_RULES.habit)) +
    kv('یادگیری/مطالعه', '+' + FA(XP_RULES.learning)) + kv('ثبت هزینه', '+' + FA(XP_RULES.expenseLog)) +
    kv('رسیدن به هدف', '+' + FA(XP_RULES.goalReached)) + kv('دستاورد', '+' + FA(XP_RULES.achievement)), ''));
  return html;
}
register('achievements', { title: 'دستاوردها', eyebrow: 'XP و Gamification', render: achievementsRender, tab: false });

/* -------------------------------------------------------------------- ABOUT */
function aboutRender() {
  let html = '';
  html += section('هویت برنامه', card(
    '<div class="card__title">🪙 مسیر میلیاردری — Billionaire Path</div>' +
    '<p>«فقط مسیر را نبین؛ هر روز یک قدم بردار.»</p>' +
    '<p class="muted">«ثروت یک اتفاق نیست؛ یک سیستم است.»</p>' +
    '<p class="muted">«ما فقط به تو نمی‌گوییم چه کار کنی؛ هر روز می‌گوییم امروز چه کاری انجام بدهی.»</p>', 'card--gold'));
  html += section('حریم خصوصی و آفلاین بودن', card(
    '<ul><li>اطلاعات مالی شما <b>فقط روی همین دستگاه</b> ذخیره می‌شود (localStorage + IndexedDB).</li>' +
    '<li>هیچ اتصالی به سرور، Firebase، OpenAI، Gemini یا هر API بیرونی وجود ندارد.</li>' +
    '<li>موتور تصمیم‌گیری و پایگاه دانش به‌صورت کامل داخل برنامه است.</li>' +
    '<li>می‌توانی هر زمان همه اطلاعات را پاک کنی یا خروجی رمزگذاری‌شده بگیری.</li>' +
    '<li>برنامه هیچ وعده قطعی ثروت نمی‌دهد و توصیه خرید/فروش دارایی نمی‌دهد.</li></ul>', ''));
  html += section('موتور هوش مالی آفلاین', card(
    '<ul><li>Rule Engine چندلایه برای تعیین اولویت</li><li>Decision Tree برای تصمیم‌یار</li>' +
    '<li>Scoring Engine برای امتیاز ۰ تا ۱۰۰۰</li><li>Recommendation Engine با اثر/دشواری/ریسک/احتمال</li>' +
    '<li>Financial Projection Engine و Goal Planning</li><li>Habit Engine و Progress Engine</li>' +
    '<li>Risk، Career، Business و Investment Education Engine</li><li>Adaptive Roadmap Engine برای اصلاح پویا</li></ul>', ''));
  html += section('سلب مسئولیت', card(
    '<p class="tiny">همه اعداد این برنامه خروجی مدل‌سازی داخلی‌اند، نه پیش‌بینی قطعی آینده. تصمیم نهایی و مسئولیت آن با کاربر است.</p>', 'alert--info'));
  return html;
}
register('about', { title: 'درباره', eyebrow: 'حریم خصوصی و معماری', render: aboutRender, tab: false });
