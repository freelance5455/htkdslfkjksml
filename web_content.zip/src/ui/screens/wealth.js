/* ==========================================================================
   ui/screens/wealth.js — ثروت من: دارایی، بدهی، درآمد، هزینه، تراکنش، نمودار
   ========================================================================== */

import { State } from '../../store.js';
import { reg } from '../actions.js';
import { register, section, card, M, FA, toast, modal, closeModal, kv, bar, emptyBox, disclaimer, render, listRow, go } from '../shell.js';
import { financeMetrics, monthSeries } from '../../engines/financial-engine.js';
import { seriesFromSnapshots, ensureSnapshot } from '../../engines/planner.js';
import { lineChart, barChart, donut, hBars, CHART_COLORS } from '../../charts.js';
import { fmtCompact, pct, toFaDigits, esc, uid, todayKey, dateKey, faDate } from '../../utils.js';
import { addXP, logXP, XP_RULES } from '../../achievements.js';
import { checkAchievements } from '../../achievements.js';

let tab = 'overview';
const TABS = [
  { k: 'overview', fa: 'نمای کلی' },
  { k: 'assets', fa: 'دارایی‌ها' },
  { k: 'debts', fa: 'بدهی‌ها' },
  { k: 'income', fa: 'درآمد' },
  { k: 'expense', fa: 'هزینه' },
  { k: 'tx', fa: 'تراکنش‌ها' },
];

function view() {
  const state = State.get();
  ensureSnapshot(state);
  const m = financeMetrics(state);
  let html = '';

  html += '<div class="tabs">' + TABS.map((t) => '<button class="tab ' + (t.k === tab ? 'is-active' : '') + '" data-act="wealth.tab" data-k="' + t.k + '">' + t.fa + '</button>').join('') + '</div>';

  if (tab === 'overview') {
    html += section('خالص ثروت (Net Worth)', card(
      '<div class="row row--between"><div><span class="kpi__label">دارایی − بدهی</span>' +
      '<div class="kpi__value num" style="font-size:26px;color:var(--accent-text)">' + fmtCompact(m.netWorth, state.profile) + '</div>' +
      '<p class="tiny">دارایی: ' + fmtCompact(m.assetsTotal, state.profile) + ' • بدهی: ' + fmtCompact(m.debtTotal, state.profile) + '</p></div>' +
      donut({ segments: assetSegments(state, m), size: 104, thickness: 16, center: '<b class="num">' + FA(m.assetsTotal > 0 ? Math.round((m.investable / m.assetsTotal) * 100) : 0) + '٪</b><span class="tiny">درآمدزا</span>' }) +
      '</div>', 'card--gold'));
    html += section('روند خالص ثروت', card(lineChart({
      series: (seriesFromSnapshots(state).length ? seriesFromSnapshots(state) : [{ label: 'اکنون', value: m.netWorth }]).map((s) => ({ label: s.label, value: s.netWorth })), color: CHART_COLORS.green,
    }), ''));
    html += section('ترکیب دارایی', hBars(m.assetsTotal ? (state.finance.assets || []).map((a) => ({ label: a.label || a.category, value: a.amount, text: fmtCompact(a.amount, state.profile), color: CHART_COLORS.gold })) : [], {}));
    html += section('جریان نقدی ۶ ماه', card(barChart({
      series: [
        { name: 'درآمد', labels: monthSeries(state, 6).map((s) => s.month.slice(5)), values: monthSeries(state, 6).map((s) => s.income) },
        { name: 'هزینه', labels: monthSeries(state, 6).map((s) => s.month.slice(5)), values: monthSeries(state, 6).map((s) => s.expense) },
      ], colors: [CHART_COLORS.gold, CHART_COLORS.red],
    }), ''));
    html += section('شاخص‌های کلیدی', card(
      kv('نرخ پس‌انداز', pct(m.savingsRate)) +
      kv('نسبت قسط به درآمد', pct(m.debtToIncome)) +
      kv('پوشش نقدینگی', FA(m.runwayMonths) + ' ماه') +
      kv('سرمایه درآمدزا', fmtCompact(m.investable, state.profile)) +
      kv('سالانه برابرِ خالص ثروت', FA(m.netWorthYears) + ' سال هزینه'), ''));
    html += '<div class="btn-row"><button class="btn btn--primary" data-act="wealth.addTx">+ ثبت تراکنش</button>' +
      '<button class="btn" data-act="ui.nav" data-id="debt">بدهی‌ها</button>' +
      '<button class="btn" data-act="ui.nav" data-id="simulator">شبیه‌ساز</button></div>';
  }

  if (tab === 'assets') {
    const assets = state.finance.assets || [];
    html += section('دارایی‌ها', assets.length ? assets.map((a) => listRow({
      icon: assetIcon(a.category), title: a.label || a.category, sub: a.category + (a.liquid ? ' • نقدشونده' : ''),
      amount: fmtCompact(a.amount, state.profile),
      right: '<button class="iconbtn" data-act="fin.delAsset" data-id="' + a.id + '">🗑</button>',
    })).join('') : emptyBox('💎', 'دارایی‌ای ثبت نشده است.'), { action: '<button class="btn btn--sm btn--primary" data-act="fin.addAsset">+ دارایی</button>' });
    html += card(kv('مجموع دارایی', fmtCompact(m.assetsTotal, state.profile)) + kv('نقدشونده', fmtCompact(m.liquid, state.profile)) + kv('سرمایه‌گذاری‌شونده', fmtCompact(m.investable, state.profile)), '');
  }

  if (tab === 'debts') {
    const debts = state.finance.debts || [];
    html += section('بدهی‌ها', debts.length ? debts.map((d) => listRow({
      icon: '📉', title: d.label || 'بدهی', sub: 'نرخ بهره ' + FA(d.rate || 0) + '٪ • قسط ' + fmtCompact(d.monthlyPayment || 0, state.profile),
      amount: fmtCompact(d.amount, state.profile),
      right: '<button class="iconbtn" data-act="debt.pay" data-id="' + d.id + '" aria-label="پرداخت">💰</button>',
    })).join('') : emptyBox('🕊️', 'بدهی فعال نداری — عالی است.'), { action: '<button class="btn btn--sm btn--primary" data-act="fin.addDebt">+ بدهی</button>' });
    html += card(kv('مجموع بدهی', fmtCompact(m.debtTotal, state.profile)) + kv('قسط ماهانه', fmtCompact(m.monthlyDebtPayment, state.profile)) + kv('نسبت به درآمد', pct(m.debtToIncome)), '');
    html += '<div class="btn-row mt"><button class="btn btn--primary" data-act="ui.nav" data-id="debt">مقایسه روش‌های بازپرداخت</button></div>';
  }

  if (tab === 'income') {
    const incomes = state.finance.incomes || [];
    html += section('درآمدهای ماهانه', incomes.length ? incomes.map((i) => listRow({
      icon: i.kind === 'salary' ? '💼' : i.kind === 'side' ? '🧩' : i.kind === 'business' ? '🏢' : '📈',
      title: i.label || 'درآمد', sub: (i.type === 'fixed' ? 'ثابت' : 'متغیر'), amount: fmtCompact(i.amount, state.profile),
      right: '<button class="iconbtn" data-act="fin.delIncome" data-id="' + i.id + '">🗑</button>',
    })).join('') : emptyBox('💼', 'درآمدی ثبت نشده است.'), { action: '<button class="btn btn--sm btn--primary" data-act="fin.addIncome">+ درآمد</button>' });
    html += card(kv('درآمد ثابت', fmtCompact(m.fixedIncome, state.profile)) + kv('درآمد متغیر', fmtCompact(m.variableIncome, state.profile)) + kv('مجموع', fmtCompact(m.income, state.profile)), '');
  }

  if (tab === 'expense') {
    const exp = state.finance.expenses || [];
    html += section('هزینه‌های ماهانه', exp.length ? exp.map((e) => listRow({
      icon: '🧾', title: e.label || e.category, sub: e.category, amount: fmtCompact(e.amount, state.profile),
      right: '<button class="iconbtn" data-act="fin.delExpense" data-id="' + e.id + '">🗑</button>',
    })).join('') : emptyBox('🧾', 'هزینه‌ای ثبت نشده است.'), { action: '<button class="btn btn--sm btn--primary" data-act="fin.addExpense">+ هزینه</button>' });
    html += section('سهم دسته‌ها', hBars(m.expenseByCat.map((c) => ({ label: c.category, value: c.amount, text: fmtCompact(c.amount, state.profile), color: CHART_COLORS.blue })), {}));
  }

  if (tab === 'tx') {
    const tx = (state.finance.transactions || []).slice().reverse().slice(0, 60);
    html += section('تراکنش‌های اخیر', tx.length ? tx.map((t) => listRow({
      icon: t.type === 'income' ? '⬆️' : '⬇️', title: t.label || (t.type === 'income' ? 'درآمد' : 'هزینه'),
      sub: esc(t.date ? dateFa(t.date) : '') + ' • ' + (t.category || ''),
      amount: fmtCompact(t.amount, state.profile), amountClass: t.type === 'income' ? 'pos' : 'neg',
      right: '<button class="iconbtn" data-act="fin.delTx" data-id="' + t.id + '">🗑</button>',
    })).join('') : emptyBox('📒', 'تراکنشی ثبت نشده است.'), { action: '<button class="btn btn--sm btn--primary" data-act="wealth.addTx">+ تراکنش</button>' });
  }

  html += disclaimer('همه داده‌ها روی دستگاه تو ذخیره می‌شوند و هیچ‌گاه ارسال نمی‌شوند.');
  return html;
}

function assetSegments(state, m) {
  const colors = [CHART_COLORS.gold, CHART_COLORS.green, CHART_COLORS.blue, CHART_COLORS.purple, '#f97316'];
  return (state.finance.assets || []).slice(0, 5).map((a, i) => ({ label: a.category, value: a.amount, color: colors[i % colors.length] }));
}
function assetIcon(cat) {
  const map = { 'نقد': '💵', 'سپرده': '🏦', 'سهام': '📈', 'طلا': '🥇', 'ارز': '💱', 'ملک': '🏠', 'خودرو': '🚗', 'کسب‌وکار': '🏢', 'تجهیزات': '🧰' };
  return map[cat] || '💎';
}
function dateFa(d) {
  const { faDate } = reqUtil();
  return faDate(d, { withYear: false });
}
function reqUtil() { return { faDate: faDateRef }; }
let faDateRef = null;
export function bindFaDate(fn) { faDateRef = fn; }

/* --------------------------------------------------------------- اکشن‌ها */
reg('wealth', {
  tab(el, ds) { tab = ds.k; render(); },
  addTx() {
    modal({
      title: 'ثبت تراکنش',
      body: '<form data-form="fin.tx">' +
        '<div class="field"><label>نوع</label><select class="select" name="type"><option value="expense">هزینه</option><option value="income">درآمد</option></select></div>' +
        '<div class="field"><label>مبلغ</label><input class="input num" name="amount" inputmode="decimal" placeholder="مثلاً 250 هزار"></div>' +
        '<div class="field"><label>دسته</label><select class="select" name="category">' +
        ['غذا', 'مسکن', 'حمل‌ونقل', 'آموزش', 'درمان', 'تفریح', 'خانواده', 'اقساط', 'درآمد', 'سایر'].map((c) => '<option>' + c + '</option>').join('') + '</select></div>' +
        '<div class="field"><label>توضیح</label><input class="input" name="label" placeholder="مثلاً خرید هفتگی"></div>' +
        '<div class="field"><label>تاریخ (میلادی)</label><input class="input" type="date" name="date" value="' + todayKey() + '"></div>' +
        '<button class="btn btn--primary btn--block" type="submit">ثبت</button></form>',
    });
  },
});

reg('fin', {
  addIncome() {
    modal({
      title: 'درآمد ماهانه',
      body: '<form data-form="fin.income">' +
        '<div class="field"><label>عنوان</label><input class="input" name="label" placeholder="مثلاً حقوق"></div>' +
        '<div class="field"><label>مبلغ ماهانه</label><input class="input num" name="amount" inputmode="decimal"></div>' +
        '<div class="field"><label>نوع</label><select class="select" name="type"><option value="fixed">ثابت</option><option value="variable">متغیر</option></select></div>' +
        '<div class="field"><label>منبع</label><select class="select" name="kind"><option value="salary">درآمد اصلی</option><option value="side">درآمد دوم</option><option value="business">کسب‌وکار</option><option value="investment">سرمایه‌گذاری</option></select></div>' +
        '<button class="btn btn--primary btn--block" type="submit">ذخیره</button></form>',
    });
  },
  addExpense() {
    modal({
      title: 'هزینه ماهانه',
      body: '<form data-form="fin.expense">' +
        '<div class="field"><label>عنوان</label><input class="input" name="label" placeholder="مثلاً اجاره"></div>' +
        '<div class="field"><label>مبلغ ماهانه</label><input class="input num" name="amount" inputmode="decimal"></div>' +
        '<div class="field"><label>دسته</label><select class="select" name="category">' +
        ['مسکن', 'غذا', 'حمل‌ونقل', 'آموزش', 'درمان', 'تفریح', 'خانواده', 'اقساط', 'سایر'].map((c) => '<option>' + c + '</option>').join('') + '</select></div>' +
        '<button class="btn btn--primary btn--block" type="submit">ذخیره</button></form>',
    });
  },
  addAsset() {
    modal({
      title: 'دارایی',
      body: '<form data-form="fin.asset">' +
        '<div class="field"><label>عنوان</label><input class="input" name="label" placeholder="مثلاً سپرده بانکی"></div>' +
        '<div class="field"><label>ارزش فعلی</label><input class="input num" name="amount" inputmode="decimal"></div>' +
        '<div class="field"><label>دسته</label><select class="select" name="category">' +
        ['نقد', 'سپرده', 'سهام', 'طلا', 'ارز', 'ملک', 'خودرو', 'کسب‌وکار', 'تجهیزات', 'سایر'].map((c) => '<option>' + c + '</option>').join('') + '</select></div>' +
        '<label class="check"><input type="checkbox" name="liquid" value="1"><span>نقدشونده است (قابل تبدیل سریع به پول نقد)</span></label>' +
        '<button class="btn btn--primary btn--block" type="submit">ذخیره</button></form>',
    });
  },
  addDebt() {
    modal({
      title: 'بدهی',
      body: '<form data-form="fin.debt">' +
        '<div class="field"><label>عنوان</label><input class="input" name="label" placeholder="مثلاً وام بانکی"></div>' +
        '<div class="field"><label>مانده بدهی</label><input class="input num" name="amount" inputmode="decimal"></div>' +
        '<div class="field"><label>نرخ بهره سالانه (٪)</label><input class="input num" name="rate" inputmode="decimal" value="20"></div>' +
        '<div class="field"><label>قسط ماهانه</label><input class="input num" name="monthly" inputmode="decimal"></div>' +
        '<div class="field"><label>مدت (ماه)</label><input class="input num" name="term" inputmode="numeric" value="12"></div>' +
        '<div class="field"><label>نوع</label><select class="select" name="kind"><option value="loan">وام</option><option value="personal">شخصی</option><option value="business">کسب‌وکار</option><option value="card">کارت اعتباری</option><option value="other">سایر</option></select></div>' +
        '<button class="btn btn--primary btn--block" type="submit">ذخیره</button></form>',
    });
  },
  delIncome(el, ds) { delItem('incomes', ds.id, 'درآمد حذف شد'); },
  delExpense(el, ds) { delItem('expenses', ds.id, 'هزینه حذف شد'); },
  delAsset(el, ds) { delItem('assets', ds.id, 'دارایی حذف شد'); },
  delDebt(el, ds) { delItem('debts', ds.id, 'بدهی حذف شد'); },
  delTx(el, ds) { delItem('transactions', ds.id, 'تراکنش حذف شد'); },
});

reg('debt', {
  pay(el, ds) {
    const d = State.get().finance.debts.find((x) => x.id === ds.id);
    if (!d) return;
    modal({
      title: 'پرداخت بدهی: ' + (d.label || 'بدهی'),
      body: '<form data-form="debt.pay" data-id="' + d.id + '">' +
        '<p class="tiny">مانده فعلی: <b>' + fmtCompact(d.amount, State.get().profile) + '</b></p>' +
        '<div class="field"><label>مبلغ پرداخت</label><input class="input num" name="amount" inputmode="decimal" placeholder="' + fmtCompact(d.monthlyPayment || d.amount, State.get().profile) + '"></div>' +
        '<button class="btn btn--primary btn--block" type="submit">ثبت پرداخت</button></form>',
    });
  },
});

reg('form', {
  'fin.tx'(fd) {
    State.update((s) => {
      s.finance.transactions.push({
        id: uid('tx'), date: fd.date || todayKey(), type: fd.type, category: fd.category,
        label: fd.label, amount: parseAmount(fd.amount), kind: fd.type === 'income' ? 'other' : '',
      });
      s.gamification.xp += XP_RULES.expenseLog;
      s.gamification.history.push({ id: 'xp' + Date.now(), kind: 'expenseLog', label: 'ثبت تراکنش', xp: XP_RULES.expenseLog, at: todayKey() });
      checkAchievements(s, 0);
    });
    closeModal(); toast('تراکنش ثبت شد (+۳ XP)'); render();
  },
  'fin.income'(fd) {
    State.update((s) => {
      s.finance.incomes.push({ id: uid('i'), label: fd.label, amount: parseAmount(fd.amount), type: fd.type, kind: fd.kind });
    });
    closeModal(); toast('درآمد ثبت شد'); render();
  },
  'fin.expense'(fd) {
    State.update((s) => {
      s.finance.expenses.push({ id: uid('e'), label: fd.label, amount: parseAmount(fd.amount), category: fd.category });
    });
    closeModal(); toast('هزینه ثبت شد'); render();
  },
  'fin.asset'(fd) {
    State.update((s) => {
      s.finance.assets.push({ id: uid('a'), label: fd.label, amount: parseAmount(fd.amount), category: fd.category, liquid: !!fd.liquid });
      checkAchievements(s, 0);
    });
    closeModal(); toast('دارایی ثبت شد'); render();
  },
  'fin.debt'(fd) {
    State.update((s) => {
      s.finance.debts.push({
        id: uid('d'), label: fd.label, amount: parseAmount(fd.amount), rate: parseFloat(fd.rate) || 0,
        monthlyPayment: parseAmount(fd.monthly), term: parseInt(fd.term, 10) || 12, kind: fd.kind,
      });
    });
    closeModal(); toast('بدهی ثبت شد'); render();
  },
  'debt.pay'(fd, el) {
    State.update((s) => {
      const d = s.finance.debts.find((x) => x.id === el.dataset.id);
      if (!d) return;
      const pay = parseAmount(fd.amount);
      d.amount = Math.max(0, (d.amount || 0) - pay);
      s.finance.transactions.push({ id: uid('tx'), date: todayKey(), type: 'expense', category: 'اقساط', label: 'پرداخت بدهی: ' + (d.label || ''), amount: pay, kind: '' });
      if (d.amount === 0) s.gamification.xp += 40;
      checkAchievements(s, 0);
    });
    closeModal(); toast('پرداخت ثبت شد'); render();
  },
});

function delItem(coll, id, msg) {
  State.update((s) => { s.finance[coll] = (s.finance[coll] || []).filter((x) => x.id !== id); });
  toast(msg); render();
}
function parseAmount(v) {
  const s = String(v == null ? '' : v);
  const mult = /میلیارد/.test(s) ? 1e9 : /میلیون/.test(s) ? 1e6 : /هزار/.test(s) ? 1e3 : 1;
  const n = parseFloat(s.replace(/[^\d.\-]/g, ''));
  return isNaN(n) ? 0 : n * mult;
}

register('wealth', { title: 'ثروت من', eyebrow: 'مدیریت دارایی و بدهی', render: view, tab: true });