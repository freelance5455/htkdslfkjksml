/* ==========================================================================
   ui/screens/plan.js — برنامه‌ریزی: هفته، ماه، سال، تقویم، اهداف، کارها، عادت‌ها
   ========================================================================== */

import { State } from '../../store.js';
import { reg } from '../actions.js';
import { register, section, card, M, FA, toast, modal, closeModal, kv, bar, emptyBox, disclaimer, render, listRow, taskRow } from '../shell.js';
import { weekTasks, calendarFor, timeBlocks, ensureDay, generateWeek, adaptiveReschedule, weekPercentDone } from '../../engines/planner.js';
import { addDays } from '../../utils.js';
import { toggleHabitToday, suggestHabits, habitImpact, addHabit, habitTotals, weeklyCompletion, streakOf } from '../../engines/habit-engine.js';
import { reversePlan } from '../../engines/roadmap-engine.js';
import { ring, hBars, CHART_COLORS } from '../../charts.js';
import { toJalali, toGregorian, dateKey, J_MONTHS, toFaDigits, faDate, todayKey, startOfWeek, weekdayIndex, esc, uid, addMonthsKey, fmtCompact } from '../../utils.js';
import { checkAchievements, addXP, XP_RULES } from '../../achievements.js';

let tab = 'week';
const TABS = [
  { k: 'week', fa: 'هفته' },
  { k: 'month', fa: 'ماه' },
  { k: 'year', fa: 'سال' },
  { k: 'calendar', fa: 'تقویم' },
  { k: 'goals', fa: 'اهداف' },
  { k: 'tasks', fa: 'کارها' },
  { k: 'habits', fa: 'عادت‌ها' },
];

let selDay = todayKey();

function view() {
  const state = State.get();
  let html = '<div class="tabs">' + TABS.map((t) => '<button class="tab ' + (t.k === tab ? 'is-active' : '') + '" data-act="plan.tab" data-k="' + t.k + '">' + t.fa + '</button>').join('') + '</div>';

  if (tab === 'week') {
    const wt = weekTasks(state);
    const wp = weekPercentDone(state);
    html += section('برنامه هفته جاری', card(
      '<div class="row row--between"><div class="card__title">📅 ' + esc(faDate(wt.weekStart, { withWeekday: true })) + '</div>' +
      '<span class="chip chip--gold">' + FA(wp.percent) + '٪ انجام شده</span></div>' + bar(wp.percent), ''));
    html += wt.days.map((d) => card(
      '<div class="row row--between"><b>' + esc(d.fa) + '</b><span class="chip ' + (d.rest ? 'chip--green' : '') + '">' + (d.rest ? 'استراحت' : FA(d.tasks.length) + ' کار') + '</span></div>' +
      (d.tasks.length ? '<div class="mt">' + d.tasks.map((t) => '<div class="kv"><span>' + (t.done ? '✅' : '⬜') + ' ' + esc(t.title) + '</span><b class="tiny">' + FA(t.minutes || 30) + 'د</b></div>').join('') + '</div>'
        : '<p class="tiny mt">بدون برنامه — با دکمه زیر برای این روز برنامه بساز.</p>') +
      '<div class="btn-row mt"><button class="btn btn--sm" data-act="plan.ensureDay" data-day="' + d.key + '">برنامه این روز</button>' +
      '<button class="btn btn--sm" data-act="plan.dayDetail" data-day="' + d.key + '">جزئیات</button></div>', 'card--flat')).join('');
    html += '<div class="btn-row"><button class="btn btn--primary" data-act="plan.genWeek">ساخت برنامه هفته</button>' +
      '<button class="btn" data-act="plan.reschedule">بازآرایی تطبیقی</button></div>';
  }

  if (tab === 'month') {
    const j = toJalali(new Date());
    const days = [];
    const state2 = state;
    let total = 0, done = 0;
    for (let d = 1; d <= 31; d++) {
      const key = dayKeyFromJalali(j.jy, j.jm, d);
      if (!key) continue;
      const day = (state2.plan.days || {})[key];
      if (!day) continue;
      total += day.tasks.length; done += day.tasks.filter((t) => t.done).length;
      days.push({ key, day, d });
    }
    const percent = total ? Math.round((done / total) * 100) : 0;
    html += section('عملکرد ماه ' + J_MONTHS[j.jm - 1], card(
      '<div class="row" style="gap:14px">' + ring(percent, { size: 96, color: percent >= 70 ? CHART_COLORS.green : CHART_COLORS.gold, label: 'انجام' }) +
      '<div style="flex:1">' + kv('کارهای ماه', FA(done) + ' از ' + FA(total)) +
      kv('روزهای فعال', FA(new Set((state.streak.history || []).filter((k) => k.slice(0, 7) === todayKey().slice(0, 7))).size)) +
      '</div></div>', ''));
    html += section('روزهای ثبت‌شده', hBars(days.slice(-14).map((x) => ({ label: FA(x.d), value: x.day.tasks.filter((t) => t.done).length, text: FA(x.day.tasks.filter((t) => t.done).length) + '/' + FA(x.day.tasks.length), color: CHART_COLORS.gold })), {}));
    html += section('عادت‌های ماه', card(kv('نرخ انجام عادت‌ها', Math.round(weeklyCompletion(state) * 100) + '٪') + kv('بهترین زنجیره', FA(habitTotals(state).bestStreak) + ' روز'), ''));
  }

  if (tab === 'year') {
    const j = toJalali(new Date());
    const rm = state.plan.roadmap;
    html += section('نقشه راه سال', rm ? card('<div class="timeline">' + rm.phases.map((p) => {
      const months = rm.months.filter((mm) => mm.n >= p.from && mm.n <= p.to);
      const doneCount = months.filter((mm) => mm.done).length;
      return '<div class="tl-item ' + (doneCount === months.length ? 'done' : '') + '"><h4>' + esc(p.title) + ' (ماه ' + FA(p.from) + ' تا ' + FA(p.to) + ')</h4>' +
        bar(months.length ? (doneCount / months.length) * 100 : 0, 'bar--gold') +
        '<p class="tiny mt">' + months.map((mm) => esc(mm.title)).join(' • ') + '</p></div>';
    }).join('') + '</div>', '') : emptyBox('🗺️', 'نقشه راهی وجود ندارد. از صفحه «مسیر» مسیر خود را انتخاب کن.'));
    html += section('اهداف سالانه', state.goals.length ? state.goals.map((g) => {
      const rev = reversePlan(state, g);
      return listRow({ icon: '🎯', title: g.title, sub: 'هدف ماهانه: ' + fmtCompact(rev.neededMonthlySaving, state.profile), amount: fmtCompact(g.targetAmount || 0, state.profile) });
    }).join('') : emptyBox('🎯', 'هدفی ثبت نشده است.'), { action: '<button class="btn btn--sm btn--primary" data-act="goal.add">+ هدف</button>' });
  }

  if (tab === 'calendar') html += calendarHtml(state);

  if (tab === 'goals') {
    html += section('اهداف', state.goals.length ? state.goals.map((g) => {
      const rev = reversePlan(state, g);
      return card(
        '<div class="row row--between"><div class="card__title">' + (g.done ? '✅' : '🎯') + ' ' + esc(g.title) + '</div>' +
        '<span class="chip">' + fmtCompact(g.targetAmount || 0, state.profile) + '</span></div>' +
        kv('هدف ماهانه پس‌انداز', fmtCompact(rev.neededMonthlySaving, state.profile)) +
        kv('درآمد موردنیاز', fmtCompact(rev.neededIncome, state.profile)) +
        (g.deadline ? kv('مهلت', esc(faDate(g.deadline))) : '') +
        '<div class="btn-row mt"><button class="btn btn--sm" data-act="path.reverse" data-id="' + g.id + '">زنجیره معکوس</button>' +
        '<button class="btn btn--sm" data-act="goal.edit" data-id="' + g.id + '">ویرایش</button>' +
        '<button class="btn btn--sm" data-act="goal.toggleDone" data-id="' + g.id + '">' + (g.done ? 'فعال کردن' : 'تکمیل شد') + '</button></div>', 'card--flat');
    }).join('') : emptyBox('🎯', 'هدفی ثبت نشده است.'), { action: '<button class="btn btn--sm btn--primary" data-act="goal.add">+ هدف</button>' });
  }

  if (tab === 'tasks') {
    const keys = Object.keys(state.plan.days || {}).sort().reverse().slice(0, 10);
    html += section('کارهای ۱۰ روز اخیر', keys.length ? keys.map((k) => {
      const day = state.plan.days[k];
      const done = day.tasks.filter((t) => t.done).length;
      return card('<div class="row row--between"><b>' + esc(faDate(k, { withWeekday: true })) + '</b><span class="chip">' + FA(done) + '/' + FA(day.tasks.length) + '</span></div>' +
        '<div class="mt">' + day.tasks.map((t) => taskRow(t, k)).join('') + '</div>', 'card--flat');
    }).join('') : emptyBox('📋', 'کاری ثبت نشده است.'), { action: '<button class="btn btn--sm btn--primary" data-act="task.add">+ کار</button>' });
  }

  if (tab === 'habits') {
    const h = state.habits || [];
    html += section('عادت‌های من', h.length ? h.map((x) => {
      const impact = habitImpact(state, x);
      return card(
        '<div class="row row--between"><div class="card__title">' + (x.icon || '✅') + ' ' + esc(x.title) + '</div>' +
        '<span class="chip ' + (impact >= 70 ? 'chip--green' : '') + '">اثر مالی ' + FA(impact) + '/100</span></div>' +
        '<div class="task__meta"><span class="chip">زنجیره ' + FA(streakOf(x)) + ' روز</span><span class="chip">' + FA(x.targetPerWeek || 5) + ' بار در هفته</span><span class="chip">' + esc(x.cat) + '</span></div>' +
        '<div class="btn-row mt"><button class="btn btn--sm ' + ((x.history || []).indexOf(todayKey()) > -1 ? 'btn--green' : 'btn--primary') + '" data-act="habit.toggle" data-id="' + x.id + '">' + ((x.history || []).indexOf(todayKey()) > -1 ? '✅ امروز انجام شد' : 'امروز انجام دادم') + '</button>' +
        '<button class="iconbtn" data-act="habit.del" data-id="' + x.id + '">🗑</button></div>', 'card--flat');
    }).join('') : emptyBox('🔁', 'عادتی ثبت نشده است.'), { action: '<button class="btn btn--sm btn--primary" data-act="habit.add">+ عادت</button>' });
    const sug = suggestHabits(state).filter((s) => !s.exists).slice(0, 5);
    html += section('عادت‌های پیشنهادی با بیشترین اثر مالی', sug.map((s) => listRow({
      icon: s.icon, title: s.title, sub: s.cat + ' • اثر مالی ' + FA(s.impact) + '/100 • ' + FA(s.minutes) + ' دقیقه',
      right: '<button class="btn btn--sm" data-act="habit.addPreset" data-t="' + esc(s.title) + '" data-c="' + esc(s.cat) + '" data-m="' + s.minutes + '" data-w="' + s.targetPerWeek + '">افزودن</button>',
    })).join(''));
  }

  html += disclaimer('برنامه بر اساس زمان آزاد واقعی تو تنظیم می‌شود؛ در پروفایل می‌توانی آن را تغییر دهی.');
  return html;
}

/* --------------------------------------------------------------- تقویم */
function calendarHtml(state) {
  const j = toJalali(new Date(selDay));
  let y = j.jy, m = j.jm;
  if (state.__cal) { y = state.__cal.jy; m = state.__cal.jm; }
  const cells = calendarFor(state, y, m, selDay);
  const day = (state.plan.days || {})[selDay];
  const blocks = timeBlocks(state, selDay);
  return section(J_MONTHS[m - 1] + ' ' + toFaDigits(y),
    card('<div class="cal__head"><button class="iconbtn" data-act="cal.prev">‹</button><b>' + J_MONTHS[m - 1] + ' ' + toFaDigits(y) + '</b><button class="iconbtn" data-act="cal.next">›</button></div>' +
      '<div class="cal"><div class="cal__grid">' + ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'].map((d) => '<div class="cal__dow">' + d + '</div>').join('') +
      cells.map((c) => c.empty ? '<div class="cal__day empty"></div>' :
        '<button class="cal__day ' + (c.isToday ? 'is-today' : '') + ' ' + (c.key === selDay ? 'sel' : '') + ' ' + (c.holiday ? 'holiday' : '') + '" data-act="cal.pick" data-key="' + c.key + '">' +
        '<span>' + toFaDigits(c.jd) + '</span>' + (c.dot ? '<span class="dot ' + c.dot + '"></span>' : '') + '</button>').join('') +
      '</div></div>' +
      '<p class="hint">نقطه قرمز: کارهای انجام‌نشده • طلایی: انجام نیمه‌کاره • بدون نقطه: بدون برنامه</p>', '') +
    section('برنامه روز انتخاب‌شده', card(
      '<div class="row row--between"><b>' + esc(faDate(selDay, { withWeekday: true })) + '</b>' +
      ((state.plan.restDays || []).indexOf(weekdayIndex(selDay)) > -1 ? '<span class="chip chip--green">روز استراحت</span>' : '<span class="chip">' + FA(day ? day.tasks.length : 0) + ' کار</span>') + '</div>' +
      (blocks.length ? blocks.map((b) => '<div class="kv"><span class="muted num">' + b.time + '</span><span style="flex:1">' + (b.done ? '✅ ' : '') + esc(b.title) + '</span><b class="tiny">' + FA(b.minutes) + 'د</b></div>').join('')
        : '<p class="tiny">برنامه‌ای برای این روز ساخته نشده.</p>') +
      '<div class="btn-row mt"><button class="btn btn--sm btn--primary" data-act="plan.ensureDay" data-day="' + selDay + '">ساخت برنامه این روز</button>' +
      '<button class="btn btn--sm" data-act="cal.toggleRest">تغییر روز استراحت</button></div>', '')));
}

function dayKeyFromJalali(jy, jm, jd) {
  const { toGregorian, dateKey } = utilRef();
  if (jd > 31) return null;
  const d = toGregorian(jy, jm, jd);
  if (d.getMonth() + 1 !== (function () { const t = toJalali(d); return t.jm; })()) return null;
  return dateKey(d);
}
function utilRef() { return { toGregorian: gRef, dateKey: kRef }; }
let gRef = null, kRef = null;
export function bindDateUtils(g, k) { gRef = g; kRef = k; }

/* --------------------------------------------------------------- اکشن‌ها */
reg('plan', {
  tab(el, ds) { tab = ds.k; render(); },
  genWeek() { let n = 0; State.update((s) => { n = generateWeek(s).created.length; }); toast(n ? FA(n) + ' روز برنامه‌ریزی شد' : 'هفته از قبل برنامه‌ریزی شده بود'); render(); },
  reschedule() { let msg = ''; State.update((s) => { msg = adaptiveReschedule(s).message; }); toast(msg); render(); },
  ensureDay(el, ds) { State.update((s) => { ensureDay(s, ds.day); }); toast('برنامه روز ساخته شد'); render(); },
  dayDetail(el, ds) {
    const s = State.get();
    const day = (s.plan.days || {})[ds.day];
    modal({
      title: faDate(ds.day, { withWeekday: true }),
      body: (day && day.tasks.length ? day.tasks.map((t) => taskRow(t, ds.day)).join('') : '<p class="muted">بدون برنامه</p>') +
        '<button class="btn btn--primary btn--block mt" data-act="plan.ensureDay" data-day="' + ds.day + '" data-act-close="1">ساخت برنامه</button>',
    });
  },
});

reg('cal', {
  prev() { shiftMonth(-1); },
  next() { shiftMonth(1); },
  pick(el, ds) { selDay = ds.key; tab = 'calendar'; render(); },
  toggleRest() {
    State.update((s) => {
      const w = weekdayIndex(selDay);
      const list = s.plan.restDays || [];
      const i = list.indexOf(w);
      if (i > -1) list.splice(i, 1); else list.push(w);
      s.plan.restDays = list;
    });
    toast('روزهای استراحت به‌روزرسانی شد'); render();
  },
});
function shiftMonth(delta) {
  State.update((s) => {
    const base = s.__cal || { jy: toJalali(new Date(selDay)).jy, jm: toJalali(new Date(selDay)).jm };
    let jm = base.jm + delta, jy = base.jy;
    if (jm < 1) { jm = 12; jy--; }
    if (jm > 12) { jm = 1; jy++; }
    s.__cal = { jy, jm };
  }, { silent: true });
  render();
}

reg('habit', {
  toggle(el, ds) {
    let done = false;
    State.update((s) => {
      const r = toggleHabitToday(s, ds.id);
      done = r && r.done;
      if (done) {
        s.gamification.xp += XP_RULES.habit;
        s.gamification.history.push({ id: 'xp' + Date.now(), kind: 'habit', label: 'عادت', xp: XP_RULES.habit, at: todayKey() });
        checkAchievements(s, 0);
      }
    });
    toast(done ? 'عادت ثبت شد (+۵ XP)' : 'ثبت عادت حذف شد', done ? '' : 'red');
    render();
  },
  add() {
    const sug = suggestHabits(State.get()).slice(0, 6);
    modal({
      title: 'عادت جدید',
      body: '<form data-form="habit.save">' +
        '<div class="field"><label>عنوان</label><input class="input" name="title" placeholder="مثلاً مطالعه ۲۰ صفحه"></div>' +
        '<div class="field"><label>دسته</label><select class="select" name="cat">' +
        ['مالی', 'درآمد', 'مهارت', 'کسب‌وکار', 'شبکه', 'برند', 'یادگیری', 'انرژی'].map((c) => '<option>' + c + '</option>').join('') + '</select></div>' +
        '<div class="field"><label>مدت روزانه (دقیقه)</label><input class="input num" name="minutes" value="20"></div>' +
        '<div class="field"><label>تعداد در هفته</label><input class="input num" name="targetPerWeek" value="5"></div>' +
        '<button class="btn btn--primary btn--block" type="submit">افزودن</button></form>' +
        '<p class="hint mt">پیشنهاد سریع:</p><div class="chips">' + sug.map((s) => '<button class="chipbtn" data-act="habit.addPreset" data-t="' + esc(s.title) + '" data-c="' + esc(s.cat) + '" data-m="' + s.minutes + '" data-w="' + s.targetPerWeek + '">' + esc(s.title) + '</button>').join('') + '</div>',
    });
  },
  addPreset(el, ds) {
    State.update((s) => { addHabit(s, { title: ds.t, cat: ds.c, minutes: +ds.m, targetPerWeek: +ds.w }); });
    toast('عادت اضافه شد'); render();
  },
  del(el, ds) {
    State.update((s) => { s.habits = (s.habits || []).filter((h) => h.id !== ds.id); });
    toast('عادت حذف شد'); render();
  },
});

reg('goal', {
  toggleDone(el, ds) {
    State.update((s) => {
      const g = s.goals.find((x) => x.id === ds.id);
      if (!g) return;
      g.done = !g.done;
      if (g.done) { s.gamification.xp += XP_RULES.goalReached; checkAchievements(s, 0); }
    });
    toast('وضعیت هدف تغییر کرد'); render();
  },
});

register('plan', { title: 'برنامه‌ریزی', eyebrow: 'هفته، ماه، سال و تقویم', render: view, tab: false });
register('calendar', { title: 'تقویم هوشمند', eyebrow: 'برنامه روزانه', render: () => { tab = 'calendar'; return calendarHtml(State.get()); }, tab: false });
