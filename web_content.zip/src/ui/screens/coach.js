/* ==========================================================================
   ui/screens/coach.js — مربی آفلاین: پرسش و پاسخ شخصی‌سازی‌شده
   ========================================================================== */

import { State } from '../../store.js';
import { reg } from '../actions.js';
import { register, section, card, FA, toast, emptyBox, disclaimer, render, closeModal } from '../shell.js';
import { ask } from '../../engines/ai-engine.js';
import { CHAT_SUGGESTIONS } from '../../knowledge/concepts.js';
import { uid, todayKey, esc, faDate } from '../../utils.js';
import { logEvent } from '../../database.js';
import { ensureDay } from '../../engines/planner.js';

let pending = null;

function view() {
  const state = State.get();
  const msgs = state.chat || [];

  let html = '';
  html += '<div class="alert alert--info mb"><i>🤖</i><div class="tiny">این مربی <b>کاملاً آفلاین</b> است: بر پایه پروفایل تو، قوانین تصمیم‌گیری و پایگاه دانش داخلی (۱۰۰ کتاب) پاسخ می‌دهد. بدون اینترنت.</div></div>';

  html += '<div class="chat">';
  if (!msgs.length) {
    html += emptyBox('💬', 'سؤالت را بپرس. مثلاً «چطور درآمد ماهانه‌ام را دو برابر کنم؟»');
  } else {
    msgs.slice(-40).forEach((m) => {
      html += '<div class="msg ' + (m.role === 'user' ? 'msg--user' : 'msg--ai') + '">' +
        (m.role === 'ai' ? m.text : esc(m.text).replace(/\n/g, '<br>')) +
        (m.actions && m.actions.length ? '<div class="msg__actions">' + m.actions.map((a, i) =>
          '<button class="btn btn--sm" data-act="coach.addTask" data-i="' + i + '" data-id="' + m.id + '">' + esc(a.label) + '</button>').join('') + '</div>' : '') +
        '</div>';
    });
  }
  html += '</div>';

  html += section('پرسش‌های آماده', '<div class="chips">' + CHAT_SUGGESTIONS.map((s) =>
    '<button class="chipbtn" data-act="coach.quick" data-q="' + esc(s) + '">' + esc(s) + '</button>').join('') + '</div>');

  html += '<div class="chatbar mt"><input id="coachInput" class="input" placeholder="سؤال مالی‌ات را بنویس…" value="' + esc(pending || '') + '">' +
    '<button class="btn btn--primary" data-act="coach.send">ارسال</button></div>';
  html += '<div class="btn-row mt"><button class="btn btn--sm btn--ghost" data-act="coach.clear">پاک کردن گفت‌وگو</button>' +
    '<button class="btn btn--sm" data-act="coach.weekly">پیام مربی این هفته</button></div>';
  html += disclaimer('پاسخ‌ها حاصل قوانین داخلی برنامه هستند و توصیه سرمایه‌گذاری قطعی نیستند.');
  return html;
}

reg('coach', {
  send() {
    const input = document.getElementById('coachInput');
    const q = (input && input.value ? input.value : pending || '').trim();
    if (!q) { toast('سؤالی بنویس تا تحلیل کنم'); return; }
    sendQuestion(q);
  },
  quick(el, ds) { sendQuestion(ds.q); },
  clear() {
    State.update((s) => { s.chat = []; });
    toast('گفت‌وگو پاک شد'); render();
  },
  weekly() { sendQuestion('این هفته چطور عمل کردم و چه کاری انجام بدهم؟'); },
  addTask(el, ds) {
    const m = (State.get().chat || []).find((x) => x.id === ds.id);
    if (!m || !m.actions || !m.actions[+ds.i]) return;
    const t = m.actions[+ds.i].task;
    State.update((s) => {
      const day = ensureDay(s, todayKey());
      day.tasks.push({ id: 't' + Date.now(), title: t.title, cat: t.cat || 'اقدام درآمدی', minutes: t.minutes || 30, impact: t.impact || 75, done: false });
    });
    toast('به کارهای امروز اضافه شد ✅');
    render();
  },
});

function sendQuestion(q) {
  const state = State.get();
  const answer = ask(state, q);
  State.update((s) => {
    s.chat.push({ id: uid('c'), role: 'user', text: q, ts: Date.now(), at: todayKey() });
    s.chat.push({ id: uid('c'), role: 'ai', text: answer.text, ts: Date.now(), at: todayKey(), actions: answer.actions || [], sources: answer.sources || [] });
    if (s.chat.length > 120) s.chat = s.chat.slice(-120);
    s.decisions.push({ id: uid('d'), q, at: todayKey(), sources: answer.sources || [] });
    if (s.decisions.length > 60) s.decisions = s.decisions.slice(-60);
  });
  pending = null;
  logEvent('chat', q);
  render();
  setTimeout(() => {
    const host = document.getElementById('screen');
    if (host) host.scrollTop = host.scrollHeight;
    try { window.scrollTo(0, document.body.scrollHeight); } catch (e) { void e; }
  }, 60);
}

register('coach', { title: 'مربی مالی', eyebrow: 'هوش مالی آفلاین', render: view, tab: true });
