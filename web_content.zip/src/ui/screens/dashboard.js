/* ==========================================================================
   ui/screens/dashboard.js — داشبورد مالی اصلی
   ========================================================================== */

import { State } from '../../store.js';
import { reg } from '../actions.js';
import { register, section, card, M, FA, toast, listRow, bar, kv, go, scoreRing, disclaimer, alertBox } from '../shell.js';
import { financeMetrics, monthSeries } from '../../engines/financial-engine.js';
import { computeScore } from '../../engines/scoring-engine.js';
import { roadmapProgress, buildMissions, reversePlan } from '../../engines/roadmap-engine.js';
import { seriesFromSnapshots, ensureSnapshot, activeDaysCount, daysLeftInMonth } from '../../engines/planner.js';
import { lineChart, barChart, ring } from '../../charts.js';
import { oneBigMove, limiterList, goalProbabilityFor, coachMessage } from '../../engines/ai-engine.js';
import { fmtCompact, pct, toFaDigits, esc, round, todayKey } from '../../utils.js';

function view() {
  const state = State.get();
  ensureSnapshot(state);
  const m = financeMetrics(state);
  const score = computeScore(state);
  const rp = roadmapProgress(state);
  const missions = buildMissions(state);
  const limiters = limiterList(state);
  const series = monthSeries(state, 6);
  const snaps = seriesFromSnapshots(state);
  const rpPlan = reversePlan(state, state.goals[0]);
  const bm = oneBigMove(state);

  let html = '';

  // Hero + score
  html += '<div class="hero"><div class="row" style="gap:14px">' +
    '<div style="flex:1">' +
    kpiSmall('سلام 👋', state.profile.name ? state.profile.name : 'کاربر عزیز') +
    '<p class="hero__path mt">مسیر شما: ' + esc(state.plan.roadmap ? state.plan.roadmap.pathTitle : 'انتخاب نشده') + ' • پیشرفت ' + FA(rp.percent) + '٪</p>' +
    kpiRow([
      ['خالص ثروت', fmtCompact(m.netWorth, state.profile)],
      ['درآمد ماهانه', fmtCompact(m.income, state.profile)],
      ['نرخ پس‌انداز', pct(m.savingsRate)],
      ['روزهای فعال', FA(activeDaysCount(state))],
    ]) +
    '</div>' + scoreRing(score.total) + '</div></div>';

  html += '<div class="alert alert--warn mb"><i>🔥</i><div><b>مهم‌ترین اقدام امروز</b><div class="tiny">' + esc(bm.title) + '</div></div>' +
    '<button class="btn btn--sm" data-act="ui.nav" data-id="today">برو</button></div>';

  // Limiters
  html += section('سه عامل محدودکننده سرعت ثروت‌سازی تو', limiters.map((l, i) => card(
    '<div class="card__title">' + FA(i + 1) + '. ' + esc(l.label) + '</div>' +
    '<p class="tiny">' + esc(l.why) + '</p>' +
    '<div class="alert alert--ok mt"><i>🛠</i><div class="tiny"><b>راه‌حل:</b> ' + esc(l.fix) + '</div></div>', 'card--flat')).join(''));

  // Financial KPIs
  html += section('وضعیت مالی', card(
    '<div class="grid grid-2">' +
    '<div class="kpi"><span class="kpi__label">دارایی‌ها</span><span class="kpi__value num">' + fmtCompact(m.assetsTotal, state.profile) + '</span></div>' +
    '<div class="kpi"><span class="kpi__label">بدهی‌ها</span><span class="kpi__value num neg">' + fmtCompact(m.debtTotal, state.profile) + '</span></div>' +
    '<div class="kpi"><span class="kpi__label">پس‌انداز ماهانه</span><span class="kpi__value num ' + (m.savings >= 0 ? 'pos' : 'neg') + '">' + fmtCompact(m.savings, state.profile) + '</span></div>' +
    '<div class="kpi"><span class="kpi__label">نقدینگی (ماه هزینه)</span><span class="kpi__value num">' + FA(m.runwayMonths) + ' ماه</span></div>' +
    '</div>' +
    '<div class="mt">' + bar(m.savingsRate * 100, m.savingsRate >= 0.2 ? '' : m.savingsRate >= 0.1 ? 'bar--gold' : 'bar--red') +
    '<p class="tiny mt">نرخ پس‌انداز هدف: ۲۰٪ — فعلی: ' + pct(m.savingsRate) + ' • نسبت قسط به درآمد: ' + pct(m.debtToIncome) + '</p></div>', ''));

  // Charts
  html += section('درآمد و هزینه ۶ ماه گذشته', card(barChart({
    series: [
      { name: 'درآمد', labels: series.map((s) => s.month.slice(5)), values: series.map((s) => s.income) },
      { name: 'هزینه', labels: series.map((s) => s.month.slice(5)), values: series.map((s) => s.expense) },
    ], colors: ['#e8b44a', '#ef4444'],
  }), ''), { action: '<button class="btn btn--sm" data-act="ui.nav" data-id="reports">گزارش‌ها</button>' });

  html += section('روند خالص ثروت', card(lineChart({
    series: (snaps.length ? snaps : [{ label: 'اکنون', value: m.netWorth }]).map((s) => ({ label: s.label, value: s.netWorth })),
    color: '#22c55e', height: 150,
  }), ''), { action: '<button class="btn btn--sm" data-act="ui.nav" data-id="wealth">ثروت من</button>' });

  html += section('روند امتیاز مالی', card(lineChart({
    series: (snaps.length ? snaps : [{ label: 'اکنون', value: score.total }]).map((s) => ({ label: s.label, value: s.score })),
    color: '#e8b44a', height: 130, fill: false,
  }), ''));

  // Missions
  html += section('مأموریت‌های مسیر', missions.map((ms) => card(
    '<div class="row row--between"><div class="card__title">' + (ms.unlocked ? '🔓' : '🔒') + ' ' + esc(ms.title) + '</div><span class="chip ' + (ms.progress >= 1 ? 'chip--green' : '') + '">' + FA(Math.round(ms.progress * 100)) + '٪</span></div>' +
    bar(ms.progress * 100, ms.progress >= 1 ? '' : 'bar--gold') +
    '<p class="tiny mt">' + esc(ms.why) + '</p>', 'card--flat')).join(''),
    { action: '<button class="btn btn--sm" data-act="ui.nav" data-id="path">مسیر من</button>' });

  // Reverse plan summary
  html += section('برنامه‌ریزی معکوس از هدف', card(
    rpPlan.chain.slice(0, 6).map((c) => kv(c.level, c.value != null ? fmtCompact(c.value, state.profile) : esc(c.text))).join('') +
    '<div class="alert alert--ok mt"><i>🎯</i><div class="tiny"><b>امروز:</b> ' + esc(rpPlan.todayTask.title) + '</div></div>', ''),
    { action: '<button class="btn btn--sm" data-act="ui.nav" data-id="path">جزئیات</button>' });

  if (state.goals[0]) {
    const prob = goalProbabilityFor(state, state.goals[0]);
    html += section('احتمال تحقق هدف', card(
      '<div class="row" style="gap:14px">' + ring(prob, { size: 96, color: prob >= 60 ? '#22c55e' : prob >= 35 ? '#e8b44a' : '#ef4444', label: 'احتمال' }) +
      '<div style="flex:1"><div class="card__title">' + esc(state.goals[0].title) + '</div>' +
      '<p class="tiny">هدف: ' + fmtCompact(state.goals[0].targetAmount || 0, state.profile) + '</p>' +
      '<p class="tiny">این عدد خروجی مدل داخلی برنامه است و پیش‌بینی علمی قطعی نیست.</p></div></div>', ''));
  }

  html += '<div class="alert alert--info mb"><i>🧠</i><div class="tiny">' + esc(coachMessage(state, 'week')) + '</div></div>';
  html += '<div class="btn-row"><button class="btn btn--primary" data-act="ui.nav" data-id="coach">پرسش از مربی</button>' +
    '<button class="btn" data-act="ui.nav" data-id="intelligence">هوش مالی</button>' +
    '<button class="btn" data-act="ui.nav" data-id="future">اگر تغییر ندهم؟</button></div>';
  html += disclaimer('همه اعداد این صفحه از داده‌های خودت محاسبه شده‌اند؛ هیچ داده‌ای از دستگاه خارج نمی‌شود.');
  return html;
}

function kpiSmall(l, v) { return '<div><span class="kpi__label">' + esc(l) + '</span><div class="kpi__value" style="font-size:18px">' + esc(v) + '</div></div>'; }
function kpiRow(items) {
  return '<div class="grid grid-2 mt" style="gap:8px">' + items.map((i) =>
    '<div class="kpi"><span class="kpi__label">' + i[0] + '</span><span class="kpi__value num" style="font-size:14px">' + i[1] + '</span></div>').join('') + '</div>';
}

reg('dash', {
  refresh() { State.update((s) => { ensureSnapshot(s); }); toast('داشبورد به‌روزرسانی شد'); go('dashboard'); },
});

register('dashboard', { title: 'داشبورد', eyebrow: 'نمای کلی', render: view, tab: true });
