/* ==========================================================================
   ui/screens/reports.js — گزارش هفتگی، گزارش ماهانه، مرور ماهانه (بازتنظیم مسیر)
   ========================================================================== */

import { State } from '../../store.js';
import { reg } from '../actions.js';
import { register, section, card, M, FA, toast, kv, bar, emptyBox, disclaimer, render, modal, closeModal } from '../shell.js';
import { weeklyReview, monthlyReview } from '../../engines/planner.js';
import { monthActuals } from '../../engines/financial-engine.js';
import { computeScore } from '../../engines/scoring-engine.js';
import { recalibrate } from '../../engines/roadmap-engine.js';
import { lineChart, barChart, ring, CHART_COLORS } from '../../charts.js';
import { fmtCompact, pct, toFaDigits, esc, currentMonthKey, addMonthsKey, faDate, todayKey, uid, clamp } from '../../utils.js';
import { logEvent } from '../../database.js';

let tab = 'monthly';

function view() {
  const state = State.get();
  let html = '<div class="tabs">' +
    '<button class="tab ' + (tab === 'weekly' ? 'is-active' : '') + '" data-act="reports.tab" data-k="weekly">هفتگی</button>' +
    '<button class="tab ' + (tab === 'monthly' ? 'is-active' : '') + '" data-act="reports.tab" data-k="monthly">ماهانه</button>' +
    '<button class="tab ' + (tab === 'review' ? 'is-active' : '') + '" data-act="reports.tab" data-k="review">مرور ماه و بازتنظیم</button>' +
    '</div>';

  if (tab === 'weekly') {
    const wr = weeklyReview(state);
    html += section('گزارش هفته', card(
      '<div class="row" style="gap:14px">' + ring(wr.rate * 100, { size: 96, color: wr.rate >= 0.7 ? CHART_COLORS.green : CHART_COLORS.gold, label: 'انجام کارها' }) +
      '<div style="flex:1">' + kv('کارهای انجام‌شده', FA(wr.done) + ' از ' + FA(wr.total)) +
      kv('درآمد ایجادشده (خارج از درآمد اصلی)', fmtCompact(wr.incomeCreated, state.profile)) +
      '</div></div>', ''));
    html += section('جلسه مربی‌گری هفتگی', card(
      wr.coach.map((c) => '<div class="kv"><span class="muted">' + esc(c.q) + '</span><span style="flex:1;text-align:left">' + esc(c.a) + '</span></div>').join('') +
      '<div class="btn-row mt"><button class="btn btn--primary btn--sm" data-act="plan.genWeek">ساخت برنامه هفته بعد</button>' +
      '<button class="btn btn--sm" data-act="plan.reschedule">بازآرایی تطبیقی</button></div>', 'card--gold'));
    html += section('توزیع کارهای هفته', hBarsSafe(wr.cats));
  }

  if (tab === 'monthly') {
    const mk = currentMonthKey();
    const rep = monthlyReview(state, mk);
    html += section('گزارش ماهانه: ' + esc(faDate(todayKey())), card(
      '<div class="grid grid-2">' +
      '<div class="kpi"><span class="kpi__label">درآمد</span><span class="kpi__value num">' + fmtCompact(rep.act.current.income, state.profile) + '</span><span class="tiny ' + (rep.act.delta.income >= 0 ? 'pos' : 'neg') + '">' + sign(rep.act.delta.income) + '٪</span></div>' +
      '<div class="kpi"><span class="kpi__label">هزینه</span><span class="kpi__value num">' + fmtCompact(rep.act.current.expense, state.profile) + '</span><span class="tiny ' + (rep.act.delta.expense <= 0 ? 'pos' : 'neg') + '">' + sign(rep.act.delta.expense) + '٪</span></div>' +
      '<div class="kpi"><span class="kpi__label">پس‌انداز</span><span class="kpi__value num">' + fmtCompact(rep.act.savings, state.profile) + '</span><span class="tiny ' + (rep.act.delta.savings >= 0 ? 'pos' : 'neg') + '">' + sign(rep.act.delta.savings) + '٪</span></div>' +
      '<div class="kpi"><span class="kpi__label">نرخ پس‌انداز</span><span class="kpi__value num">' + pct(rep.act.savingsRate) + '</span></div>' +
      '</div>', ''));
    html += section('امتیاز و عملکرد', card(
      kv('امتیاز مالی فعلی', FA(rep.score) + '/1000') +
      kv('تغییر امتیاز نسبت به ماه قبل', '<span class="' + (rep.scoreDelta >= 0 ? 'pos' : 'neg') + '">' + (rep.scoreDelta >= 0 ? '+' : '') + FA(rep.scoreDelta) + '</span>') +
      kv('نرخ انجام کارها', FA(rep.taskRate) + '٪') +
      '<div class="mt">' + bar(rep.taskRate, rep.taskRate >= 70 ? '' : 'bar--gold') + '</div>', ''));
    html += section('تحلیل مربی', card(
      '<div class="alert alert--ok"><i>🏆</i><div class="tiny"><b>بهترین عملکرد:</b> ' + esc(rep.best) + '</div></div>' +
      '<div class="alert alert--danger mt"><i>⚠️</i><div class="tiny"><b>بزرگ‌ترین اشتباه:</b> ' + esc(rep.mistake) + '</div></div>' +
      '<div class="alert alert--info mt"><i>💡</i><div class="tiny"><b>فرصت ماه آینده:</b> ' + esc(rep.opportunity) + '</div></div>' +
      '<h5 class="mt">سه اقدام اصلی ماه آینده</h5><ol>' + rep.actions.map((a) => '<li>' + esc(a) + '</li>').join('') + '</ol>' +
      '<div class="btn-row mt"><button class="btn btn--sm btn--primary" data-act="reports.saveMonth">ثبت این مرور در پرونده</button>' +
      '<button class="btn btn--sm" data-act="reports.toTasks">تبدیل اقدام‌ها به کار امروز</button></div>', 'card--gold'));
    html += section('مقایسه ۶ ماه', card(barChart({
      series: [
        { name: 'پس‌انداز', labels: monthLabels(state), values: monthSeries(state, 6).map((s) => Math.max(0, s.saving)) },
        { name: 'هزینه', labels: monthLabels(state), values: monthSeries(state, 6).map((s) => s.expense) },
      ], colors: [CHART_COLORS.green, CHART_COLORS.red],
    }), ''));
  }

  if (tab === 'review') {
    const mk = currentMonthKey();
    html += section('مرور ماهانه و بازتنظیم مسیر', card(
      '<form data-form="reports.review">' +
      '<div class="field"><label>چه مقدار درآمد داشتی؟</label><input class="input num" name="income" inputmode="decimal" placeholder="مثلاً 60 میلیون"></div>' +
      '<div class="field"><label>چه مقدار پس‌انداز کردی؟</label><input class="input num" name="saving" inputmode="decimal"></div>' +
      '<div class="field"><label>چه کارهایی انجام دادی؟</label><textarea class="textarea" name="done" placeholder="مثلاً ۲۰ تماس فروش، ۹۰ ساعت یادگیری"></textarea></div>' +
      '<div class="field"><label>چه چیزهایی انجام نشد؟</label><textarea class="textarea" name="missed"></textarea></div>' +
      '<div class="field"><label>چه مهارتی یاد گرفتی؟</label><input class="input" name="skill"></div>' +
      '<div class="field"><label>آیا شرایط زندگی تغییر کرده؟ (تأهل، فرزند، شغل، شهر، سلامت)</label><textarea class="textarea" name="life"></textarea></div>' +
      '<button class="btn btn--primary btn--block" type="submit">ثبت مرور و بازمحاسبه نقشه راه</button></form>', ''));
    const prev = (state.plan.monthlyReviews || []).slice(-2);
    if (prev.length) {
      html += section('مرورهای ثبت‌شده', prev.map((r) => card(
        '<div class="card__title">' + esc(r.month) + '</div>' +
        kv('درآمد ثبت‌شده', fmtCompact(r.answers.incomeNum || 0, state.profile)) +
        kv('پس‌انداز ثبت‌شده', fmtCompact(r.answers.savingNum || 0, state.profile)) +
        (r.answers.done ? '<p class="tiny">انجام‌شده: ' + esc(r.answers.done) + '</p>' : '') +
        (r.answers.missed ? '<p class="tiny">انجام‌نشده: ' + esc(r.answers.missed) + '</p>' : '') +
        (r.notes ? '<div class="alert alert--ok mt"><i>🧠</i><div class="tiny">' + esc(r.notes) + '</div></div>' : ''), 'card--flat')).join(''));
    }
  }

  html += disclaimer('گزارش‌ها بر اساس داده‌های ثبت‌شده خودت ساخته می‌شوند؛ دقت آن‌ها به دقت ثبت تو بستگی دارد.');
  return html;
}

function sign(x) { return (x >= 0 ? '+' : '') + toFaDigits(Math.round((x || 0) * 100)); }
function monthLabels(state) {
  const { monthSeries: ms } = lazyFin();
  return ms(state, 6).map((s) => s.month.slice(5));
}
function hBarsSafe(cats) {
  const keys = Object.keys(cats || {});
  if (!keys.length) return emptyBox('📊', 'داده‌ای برای نمایش نیست.');
  const max = Math.max(...keys.map((k) => cats[k]), 1);
  return keys.map((k) => '<div class="hbar"><div class="hbar__label">' + esc(k) + '</div><div class="hbar__track"><i style="width:' + Math.round((cats[k] / max) * 100) + '%;background:' + CHART_COLORS.gold + '"></i></div><div class="hbar__value num">' + toFaDigits(cats[k]) + '</div></div>').join('');
}
function lazyFin() { return { monthSeries: msRef }; }
let msRef = null;
export function bindMs(fn) { msRef = fn; }

reg('reports', {
  tab(el, ds) { tab = ds.k; render(); },
  saveMonth() {
    const rep = monthlyReview(State.get(), currentMonthKey());
    State.update((s) => {
      s.plan.monthlyReviews = s.plan.monthlyReviews || [];
      s.plan.monthlyReviews.push({
        id: uid('rev'), month: currentMonthKey(), at: todayKey(),
        score: rep.score, taskRate: rep.taskRate,
        best: rep.best, mistake: rep.mistake, opportunity: rep.opportunity, actions: rep.actions,
      });
      if (s.plan.monthlyReviews.length > 24) s.plan.monthlyReviews = s.plan.monthlyReviews.slice(-24);
    });
    logEvent('review', 'ثبت گزارش ماهانه');
    toast('مرور ماهانه در پرونده ذخیره شد'); render();
  },
  toTasks() {
    const rep = monthlyReview(State.get(), currentMonthKey());
    State.update((s) => {
      const { ensureDay } = lazyEnsure();
      const day = ensureDay(s, todayKey());
      rep.actions.forEach((a) => day.tasks.push({ id: 't' + Date.now() + Math.random().toString(36).slice(2, 5), title: a, cat: 'مرور و برنامه‌ریزی', minutes: 30, impact: 75, done: false }));
    });
    toast('اقدام‌های ماه آینده به کارهای امروز اضافه شد');
    location.hash = '#/today'; render();
  },
});

reg('form', {
  'reports.review'(fd) {
    const notes = [];
    State.update((s) => {
      const incomeNum = parseAmount(fd.income);
      const savingNum = parseAmount(fd.saving);
      s.plan.monthlyReviews = s.plan.monthlyReviews || [];
      s.plan.monthlyReviews.push({
        id: uid('rev'), month: currentMonthKey(), at: todayKey(),
        answers: { ...fd, incomeNum, savingNum },
        notes: '',
      });
      if (incomeNum > 0) {
        const main = s.finance.incomes[0];
        if (main) main.amount = incomeNum;
        else s.finance.incomes.push({ id: uid('i'), label: 'درآمد ماهانه', amount: incomeNum, type: 'fixed', kind: 'salary' });
        notes.push('درآمد ماهانه بر اساس گزارش تو به ' + fmtCompact(incomeNum, s.profile) + ' به‌روزرسانی شد.');
      }
      if (savingNum > 0) notes.push('پس‌انداز این ماه: ' + fmtCompact(savingNum, s.profile) + ' — هدف ماه بعد را ۱۰٪ بالاتر بگذار.');
      if (fd.skill) {
        const title = String(fd.skill).trim();
        if (!s.skills.some((x) => x.title === title)) s.skills.push({ id: 's' + Date.now(), title, level: 1, note: 'یادگرفته‌شده در مرور ماه' });
        notes.push('مهارت «' + title + '» به درخت مهارت اضافه شد.');
      }
      if (fd.life) notes.push('تغییر شرایط زندگی ثبت شد؛ مسیر با شرایط جدید بازمحاسبه می‌شود.');
      const r = recalibrate(s);
      notes.push(r.notes.join(' '));
      s.meta.lastRecalc = todayKey();
      s.plan.monthlyReviews[s.plan.monthlyReviews.length - 1].notes = notes.join(' ');
    });
    logEvent('review', 'مرور ماهانه و بازتنظیم مسیر');
    closeModal();
    toast('مرور ثبت و نقشه راه بازمحاسبه شد');
    modal({
      title: 'نتیجه بازتنظیم مسیر',
      body: '<ul>' + notes.map((n) => '<li>' + esc(n) + '</li>').join('') + '</ul>' +
        '<button class="btn btn--primary btn--block mt" data-act="ui.closeModal">متوجه شدم</button>',
    });
    render();
  },
});

function parseAmount(v) {
  const s = String(v == null ? '' : v);
  const mult = /میلیارد/.test(s) ? 1e9 : /میلیون/.test(s) ? 1e6 : /هزار/.test(s) ? 1e3 : 1;
  const n = parseFloat(s.replace(/[^\d.\-]/g, ''));
  return isNaN(n) ? 0 : n * mult;
}
register('reports', { title: 'گزارش‌ها', eyebrow: 'مرور هفتگی و ماهانه', render: view, tab: false });
