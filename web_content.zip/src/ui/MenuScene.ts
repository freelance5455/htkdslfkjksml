import * as THREE from 'three';
import { buildSoldier, buildWeaponModel, type SoldierRefs } from '../game/models';
import { getTexture } from '../game/textures';
import { store } from '../game/save';
import { getOperator } from '../game/data/content';
import { getWeapon } from '../game/data/weapons';

/** Cinematic 3D main-menu backdrop: animated operator, fire light, searchlight, dust */
export class MenuScene {
  renderer: THREE.WebGLRenderer; scene = new THREE.Scene(); camera = new THREE.PerspectiveCamera(38, 1, 0.1, 300);
  private raf = 0; private t = 0; private last = performance.now(); private disposed = false;
  private op: SoldierRefs | null = null; private opKey = ''; private fireLight: THREE.PointLight; private search: THREE.Mesh;
  private dust: THREE.Points; private embers: THREE.Points; private mx = 0; private my = 0; private unsub: () => void;
  private el: HTMLElement; private intro = 0; focus = 0;

  constructor(el: HTMLElement) {
    this.el = el;
    const g = store.settings.graphics;
    this.renderer = new THREE.WebGLRenderer({ antialias: g.antialias, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2) * Math.min(1, g.renderScale));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace; this.renderer.toneMapping = THREE.ACESFilmicToneMapping; this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = g.shadows > 0; this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    el.appendChild(this.renderer.domElement);
    this.renderer.domElement.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;';
    const s = this.scene; s.background = new THREE.Color(0x0b0f14); s.fog = new THREE.FogExp2(0x101820, 0.028);
    const tq = g.textures;
    // ground
    const gm = new THREE.MeshStandardMaterial({ map: getTexture('concrete', tq).clone(), roughness: 0.95 });
    gm.map!.repeat.set(10, 10); gm.map!.needsUpdate = true;
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(120, 120), gm); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; s.add(ground);
    // ruined walls & props
    const wallM = new THREE.MeshStandardMaterial({ map: getTexture('brick', tq), roughness: 0.9 });
    const conc = new THREE.MeshStandardMaterial({ color: 0x5a5d60, roughness: 0.9 });
    const add = (geo: THREE.BufferGeometry, m: THREE.Material, x: number, y: number, z: number, ry = 0) => { const me = new THREE.Mesh(geo, m); me.position.set(x, y, z); me.rotation.y = ry; me.castShadow = me.receiveShadow = true; s.add(me); return me; };
    add(new THREE.BoxGeometry(7, 4.5, 0.5), wallM, -2.5, 2.25, -5.5);
    add(new THREE.BoxGeometry(3, 2.2, 0.5), wallM, 3.2, 1.1, -5.8, 0.15);
    add(new THREE.BoxGeometry(0.5, 3.5, 4), wallM, -5.8, 1.75, -3.5);
    add(new THREE.BoxGeometry(1.2, 1.2, 1.2), new THREE.MeshStandardMaterial({ map: getTexture('crate', tq) }), 2.4, 0.6, -1.6, 0.4);
    add(new THREE.BoxGeometry(0.9, 0.9, 0.9), new THREE.MeshStandardMaterial({ map: getTexture('crate', tq) }), 2.6, 1.65, -1.7, 0.1);
    add(new THREE.BoxGeometry(3, 1, 0.9), new THREE.MeshStandardMaterial({ map: getTexture('sandbag', tq) }), -2.6, 0.5, -1.2, -0.2);
    add(new THREE.BoxGeometry(6.5, 2.7, 2.6), new THREE.MeshStandardMaterial({ map: getTexture('container', tq), color: 0x4a6a3a }), 6.5, 1.35, -4, -0.5);
    for (let i = 0; i < 26; i++) { const h = 8 + Math.random() * 30; add(new THREE.BoxGeometry(5 + Math.random() * 6, h, 5 + Math.random() * 6), conc, -60 + i * 5 + Math.random() * 3, h / 2, -26 - Math.random() * 20); }
    // fire barrel
    const barrel = add(new THREE.CylinderGeometry(0.32, 0.3, 0.9, 14), new THREE.MeshStandardMaterial({ color: 0x5a2a18, roughness: 0.6, metalness: 0.5 }), -1.6, 0.45, -2.2);
    void barrel;
    this.fireLight = new THREE.PointLight(0xff7a2a, 18, 12, 1.6); this.fireLight.position.set(-1.6, 1.4, -2.2); this.fireLight.castShadow = g.shadows > 1; s.add(this.fireLight);
    // lights
    s.add(new THREE.HemisphereLight(0x6080a8, 0x1a1410, 0.6));
    const key = new THREE.DirectionalLight(0xbcd0ff, 1.6); key.position.set(4, 8, 6); key.castShadow = g.shadows > 0; key.shadow.mapSize.set(1024, 1024);
    const sc = key.shadow.camera; sc.left = -8; sc.right = 8; sc.top = 8; sc.bottom = -8; s.add(key);
    const rim = new THREE.SpotLight(0xffb060, 30, 30, 0.5, 0.6); rim.position.set(-4, 5, -6); rim.target.position.set(1.2, 1, 0); s.add(rim); s.add(rim.target);
    // searchlight beam
    const cone = new THREE.ConeGeometry(4, 40, 24, 1, true); cone.translate(0, -20, 0);
    this.search = new THREE.Mesh(cone, new THREE.MeshBasicMaterial({ color: 0xbfd8ff, transparent: true, opacity: 0.06, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
    this.search.position.set(-18, 26, -30); s.add(this.search);
    // dust & embers
    const mkPts = (n: number, color: number, size: number, spread: [number, number, number], center: [number, number, number]) => {
      const p = new Float32Array(n * 3); for (let i = 0; i < n; i++) { p[i * 3] = center[0] + (Math.random() - 0.5) * spread[0]; p[i * 3 + 1] = center[1] + Math.random() * spread[1]; p[i * 3 + 2] = center[2] + (Math.random() - 0.5) * spread[2]; }
      const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(p, 3));
      const pts = new THREE.Points(geo, new THREE.PointsMaterial({ color, size, transparent: true, opacity: 0.7, blending: THREE.AdditiveBlending, depthWrite: false })); s.add(pts); return pts;
    };
    this.dust = mkPts(g.effects === 0 ? 150 : 500, 0xc8b89a, 0.03, [16, 6, 10], [0, 0, -1]);
    this.embers = mkPts(60, 0xff8a30, 0.06, [0.6, 3, 0.6], [-1.6, 0.9, -2.2]);
    this.camera.position.set(0.6, 1.55, 5.2);
    this.refreshOperator();
    this.unsub = store.subscribe(() => this.refreshOperator());
    window.addEventListener('resize', this.resize); window.addEventListener('pointermove', this.pm);
    this.resize();
    this.raf = requestAnimationFrame(this.loop);
  }

  private refreshOperator() {
    const p = store.profile; const lo = p.loadouts[p.activeLoadout];
    const k = `${p.operator}|${lo.primary.weapon}|${JSON.stringify(lo.primary.attachments)}|${lo.primary.skin}`;
    if (k === this.opKey) return; this.opKey = k;
    if (this.op) this.scene.remove(this.op.root);
    const o = getOperator(p.operator);
    const r = buildSoldier(o, true);
    r.gun.visible = false;
    const wm = buildWeaponModel(getWeapon(lo.primary.weapon), lo.primary.attachments, lo.primary.skin);
    wm.group.position.set(0.1, 0.3, -0.3); wm.group.rotation.set(-0.15, 0.55, 0.9); wm.group.scale.setScalar(1.15);
    r.chest.add(wm.group);
    r.armR.rotation.set(-0.7, 0, -0.25); r.armL.rotation.set(-1.0, 0, 0.7);
    r.root.position.set(1.2, 0, 0); r.root.rotation.y = -0.45;
    r.root.traverse(m => { m.castShadow = true; });
    this.scene.add(r.root); this.op = r;
  }

  private pm = (e: PointerEvent) => { this.mx = (e.clientX / window.innerWidth - 0.5) * 2; this.my = (e.clientY / window.innerHeight - 0.5) * 2; };
  private resize = () => {
    const w = this.el.clientWidth || window.innerWidth, h = this.el.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false); this.camera.aspect = w / h; this.camera.fov = w / h < 1.3 ? 50 : 38; this.camera.updateProjectionMatrix();
  };
  private loop = (now: number) => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(0.05, (now - this.last) / 1000); this.last = now; this.t += dt; this.intro = Math.min(1, this.intro + dt * 0.35);
    const t = this.t;
    // cinematic intro dolly + idle drift + parallax
    const e = 1 - Math.pow(1 - this.intro, 3);
    const tx = 0.4 + Math.sin(t * 0.13) * 0.25 + this.mx * 0.25 - this.focus * 0.6;
    const ty = 1.45 + Math.sin(t * 0.21) * 0.06 - this.my * 0.1;
    const tz = 5.2 - this.focus * 0.8;
    this.camera.position.set(THREE.MathUtils.lerp(-3, tx, e), THREE.MathUtils.lerp(4, ty, e), THREE.MathUtils.lerp(12, tz, e));
    this.camera.lookAt(0.3 - this.focus * 0.2, 1.2, -1);
    // operator idle animation
    if (this.op) {
      const o = this.op; const br = Math.sin(t * 1.6);
      o.chest.scale.set(1 + br * 0.008, 1 + br * 0.012, 1 + br * 0.01);
      o.head.rotation.y = Math.sin(t * 0.37) * 0.35 + Math.sin(t * 1.3) * 0.03; o.head.rotation.x = Math.sin(t * 0.5) * 0.05;
      o.body.rotation.z = Math.sin(t * 0.45) * 0.015; o.body.position.y = br * 0.004;
      o.armL.rotation.x = -1.0 + br * 0.03; o.armR.rotation.x = -0.7 + br * 0.02;
      o.legL.rotation.x = Math.sin(t * 0.45) * 0.03; o.legR.rotation.x = -Math.sin(t * 0.45) * 0.03;
    }
    // fire flicker
    this.fireLight.intensity = 14 + Math.sin(t * 17) * 3 + Math.sin(t * 31) * 2 + Math.random() * 2;
    this.search.rotation.z = Math.sin(t * 0.3) * 0.5; this.search.rotation.x = Math.cos(t * 0.23) * 0.2;
    const dp = this.dust.geometry.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < dp.count; i++) { let x = dp.getX(i) + dt * 0.25; if (x > 8) x = -8; dp.setX(i, x); dp.setY(i, dp.getY(i) + Math.sin(t + i) * dt * 0.05); }
    dp.needsUpdate = true;
    const ep = this.embers.geometry.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < ep.count; i++) { let y = ep.getY(i) + dt * (0.6 + (i % 5) * 0.2); if (y > 4) { y = 0.9; ep.setX(i, -1.6 + (Math.random() - 0.5) * 0.4); ep.setZ(i, -2.2 + (Math.random() - 0.5) * 0.4); } ep.setY(i, y); ep.setX(i, ep.getX(i) + Math.sin(t * 3 + i) * dt * 0.1); }
    ep.needsUpdate = true;
    this.renderer.render(this.scene, this.camera);
  };
  dispose() {
    this.disposed = true; cancelAnimationFrame(this.raf); this.unsub();
    window.removeEventListener('resize', this.resize); window.removeEventListener('pointermove', this.pm);
    this.scene.traverse(o => { const m = o as THREE.Mesh; if (m.isMesh || (o as THREE.Points).isPoints) { if (!m.geometry.userData.cached) m.geometry.dispose(); } });
    this.renderer.dispose(); this.renderer.forceContextLoss(); this.renderer.domElement.remove();
  }
}
