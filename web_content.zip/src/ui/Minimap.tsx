import { useEffect, useRef } from 'react';
import { engine } from '../game/engine';

/** Circular GTA-style mini-map, drawn directly by the engine for performance. */
export default function Minimap({ size = 168 }: { size?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    engine.attachCanvases(ref.current, null);
    return () => engine.attachCanvases(null, null);
  }, []);

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <canvas
        ref={ref}
        width={size * 2}
        height={size * 2}
        className="w-full h-full rounded-full shadow-[0_8px_30px_rgba(0,0,0,0.6)]"
        style={{ border: '2px solid rgba(255,255,255,0.22)' }}
      />
      <div className="absolute -top-1 left-1/2 -translate-x-1/2 text-[10px] font-bold tracking-widest text-white/70 drop-shadow">
        N
      </div>
      <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 text-[10px] font-bold tracking-widest text-white/70 drop-shadow">
        S
      </div>
    </div>
  );
}
