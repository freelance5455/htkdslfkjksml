import React, { useState } from 'react';
import { Network, Play, Plus, RefreshCw, CheckCircle2 } from 'lucide-react';
import {
  INITIAL_VISUAL_SCRIPT_NODES,
  INITIAL_VISUAL_SCRIPT_CONNECTIONS,
} from '../scripting/scriptEngine';
import { VisualScriptNode, VisualScriptConnection } from '../types';
import { audioSystem } from '../audio/audioManager';

export const VisualScriptEditor: React.FC = () => {
  const [nodes, setNodes] = useState<VisualScriptNode[]>(INITIAL_VISUAL_SCRIPT_NODES);
  const [connections] = useState<VisualScriptConnection[]>(INITIAL_VISUAL_SCRIPT_CONNECTIONS);
  const [draggingNodeId, setDraggingNodeId] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [activeExecutingStep, setActiveExecutingStep] = useState<number | null>(null);

  const handlePointerDown = (e: React.PointerEvent, id: string) => {
    setDraggingNodeId(id);
    const node = nodes.find((n) => n.id === id);
    if (node) {
      setDragOffset({ x: e.clientX - node.x, y: e.clientY - node.y });
    }
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!draggingNodeId) return;
    setNodes((prev) =>
      prev.map((n) => {
        if (n.id === draggingNodeId) {
          return {
            ...n,
            x: Math.max(10, e.clientX - dragOffset.x),
            y: Math.max(10, e.clientY - dragOffset.y),
          };
        }
        return n;
      })
    );
  };

  const handlePointerUp = () => {
    setDraggingNodeId(null);
  };

  const executeFlowSimulation = async () => {
    audioSystem.playSound('synth_bell', { pitch: 1.0 });
    for (let i = 0; i < nodes.length; i++) {
      setActiveExecutingStep(i);
      audioSystem.playSound('synth_jump', { pitch: 1.0 + i * 0.2, volume: 0.3 });
      await new Promise((r) => setTimeout(r, 600));
    }
    audioSystem.playSound('synth_bell', { pitch: 1.8, volume: 0.5 });
    setActiveExecutingStep(null);
  };

  return (
    <div
      className="flex flex-col h-full bg-[#0d1117] text-slate-300 text-xs overflow-hidden select-none relative"
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
    >
      {/* Top Toolbar */}
      <div className="h-10 bg-[#161b22] border-b border-[#21262d] flex items-center justify-between px-3 shrink-0 z-20">
        <div className="flex items-center space-x-2">
          <Network className="w-4 h-4 text-cyan-400" />
          <span className="font-bold text-slate-100 text-xs tracking-wide">
            VISUAL LOGIC GRAPHER
          </span>
          <span className="text-[10px] bg-cyan-950 text-cyan-300 px-1.5 py-0.5 rounded border border-cyan-800 font-mono">
            Trigger_Outpost.graph
          </span>
        </div>

        <button
          onClick={executeFlowSimulation}
          className="bg-emerald-600 hover:bg-emerald-500 text-white px-2.5 py-1 rounded flex items-center space-x-1 font-semibold text-[11px] shadow-sm transition-colors"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>Execute Logic Flow</span>
        </button>
      </div>

      {/* Interactive Infinite Canvas with Nodes */}
      <div className="flex-1 relative overflow-auto bg-[#0b0f19] bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px]">
        {/* SVG Curved Connections */}
        <svg className="absolute inset-0 w-[1400px] h-[700px] pointer-events-none z-0">
          {connections.map((conn) => {
            const fromNode = nodes.find((n) => n.id === conn.fromNodeId);
            const toNode = nodes.find((n) => n.id === conn.toNodeId);
            if (!fromNode || !toNode) return null;

            const startX = fromNode.x + 190;
            const startY = fromNode.y + 45;
            const endX = toNode.x;
            const endY = toNode.y + 45;
            const cpx1 = startX + 60;
            const cpx2 = endX - 60;

            return (
              <path
                key={conn.id}
                d={`M ${startX} ${startY} C ${cpx1} ${startY}, ${cpx2} ${endY}, ${endX} ${endY}`}
                fill="none"
                stroke="#06b6d4"
                strokeWidth="2.5"
                strokeDasharray="4 2"
                className="opacity-80"
              />
            );
          })}
        </svg>

        {/* Nodes */}
        {nodes.map((node, index) => {
          const isExecuting = activeExecutingStep === index;
          return (
            <div
              key={node.id}
              style={{ left: `${node.x}px`, top: `${node.y}px` }}
              onPointerDown={(e) => handlePointerDown(e, node.id)}
              className={`absolute w-48 rounded-lg shadow-xl border cursor-move transition-shadow z-10 ${
                isExecuting
                  ? 'bg-[#1c2a38] border-cyan-400 ring-2 ring-cyan-500 shadow-cyan-900/60'
                  : 'bg-[#161b22] border-[#30363d] hover:border-slate-400'
              }`}
            >
              {/* Header */}
              <div
                className={`px-2.5 py-1.5 rounded-t-lg font-bold text-[11px] flex items-center justify-between ${
                  node.type === 'event'
                    ? 'bg-amber-950/80 text-amber-300 border-b border-amber-800/60'
                    : node.type === 'condition'
                    ? 'bg-violet-950/80 text-violet-300 border-b border-violet-800/60'
                    : 'bg-cyan-950/80 text-cyan-300 border-b border-cyan-800/60'
                }`}
              >
                <span>{node.title}</span>
                {isExecuting && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 animate-spin" />}
              </div>

              {/* Body */}
              <div className="p-2 space-y-1 text-[10px]">
                {Object.entries(node.params).map(([k, v]) => (
                  <div key={k} className="flex justify-between text-slate-400">
                    <span className="font-mono">{k}:</span>
                    <span className="font-semibold text-slate-200">{String(v)}</span>
                  </div>
                ))}
              </div>

              {/* Connection Ports */}
              <div className="flex justify-between px-2 py-1 bg-[#0d1117] rounded-b-lg text-[9px] font-mono text-slate-500 border-t border-[#21262d]">
                <span>{node.inputs.join(', ') || 'Trigger'}</span>
                <span>{node.outputs.join(', ') || 'Exit'}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
