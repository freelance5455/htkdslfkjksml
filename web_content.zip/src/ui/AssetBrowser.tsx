import React, { useState } from 'react';
import {
  Folder,
  Box,
  Image,
  Palette,
  Layers,
  Music,
  PlayCircle,
  FileCode,
  Package,
  Plus,
  Search,
  Sparkles,
} from 'lucide-react';
import { ObjectType } from '../types';
import { audioSystem } from '../audio/audioManager';

interface AssetBrowserProps {
  onSpawnAsset: (type: ObjectType, name: string) => void;
}

export const AssetBrowser: React.FC<AssetBrowserProps> = ({ onSpawnAsset }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const categories = [
    { id: 'all', label: 'All Assets', icon: <Folder className="w-3.5 h-3.5" /> },
    { id: 'models', label: 'Models', icon: <Box className="w-3.5 h-3.5" /> },
    { id: 'materials', label: 'Materials', icon: <Palette className="w-3.5 h-3.5" /> },
    { id: 'textures', label: 'Textures', icon: <Image className="w-3.5 h-3.5" /> },
    { id: 'scenes', label: 'Scenes', icon: <Layers className="w-3.5 h-3.5" /> },
    { id: 'audio', label: 'Audio', icon: <Music className="w-3.5 h-3.5" /> },
    { id: 'animations', label: 'Animations', icon: <PlayCircle className="w-3.5 h-3.5" /> },
    { id: 'prefabs', label: 'Prefabs', icon: <Package className="w-3.5 h-3.5" /> },
    { id: 'scripts', label: 'Scripts', icon: <FileCode className="w-3.5 h-3.5" /> },
  ];

  const assetsByCategory: Record<string, { name: string; type: ObjectType; desc: string }[]> = {
    models: [
      { name: 'Sci-Fi Crate', type: 'cube', desc: 'Standard storage container' },
      { name: 'Plasma Orb', type: 'sphere', desc: 'Energy containment cell' },
      { name: 'Sentinel Drone', type: 'npc', desc: 'Floating security sentinel' },
      { name: 'Rover Vehicle', type: 'vehicle', desc: 'Exploration rover' },
      { name: 'Cabin Base', type: 'building', desc: 'Modular architectural structure' },
      { name: 'Pine Foliage', type: 'cone', desc: 'Low-poly botanical pine' },
    ],
    materials: [
      { name: 'Davi Electric Cyan', type: 'cube', desc: 'Engine signature emissive alloy' },
      { name: 'Burnished Gold', type: 'sphere', desc: 'High reflectivity metallic gold' },
      { name: 'Deep Obsidian', type: 'cube', desc: 'Volcanic glass smooth stone' },
      { name: 'Cyber Emerald', type: 'capsule', desc: 'Synthesized glowing crystal' },
    ],
    textures: [
      { name: 'Grid_Checker_Normal', type: 'plane', desc: 'Procedural UV alignment pattern' },
      { name: 'Stone_Roughness_PBR', type: 'plane', desc: 'Cobblestone roughness surface' },
      { name: 'Carbon_Fiber_Map', type: 'plane', desc: 'High-tech composite fiber weave' },
    ],
    scenes: [
      { name: 'Archipelago Valley 01', type: 'terrain', desc: 'Full procedural demo island' },
      { name: 'Empty Grid Workspace', type: 'plane', desc: 'Minimal clean prototyping stage' },
    ],
    audio: [
      { name: 'Laser Blaster Synth', type: 'audio_source', desc: 'Pulse SFX 980Hz' },
      { name: 'Anti-Grav Jump', type: 'audio_source', desc: 'Exponential ramp 160Hz-540Hz' },
      { name: 'Sub-Bass Engine Rumble', type: 'audio_source', desc: 'Sawtooth 55Hz drone' },
      { name: 'Ancient Temple Bell', type: 'audio_source', desc: 'Harmonic sine bell pair' },
    ],
    animations: [
      { name: 'Player_Idle_Breathe', type: 'capsule', desc: 'Idle standing procedural cycle' },
      { name: 'Player_Run_Sprint', type: 'capsule', desc: 'Locomotion cycle at 9 m/s' },
      { name: 'Drone_Hover_Spin', type: 'npc', desc: 'Sentinel ring rotation loop' },
    ],
    prefabs: [
      { name: 'Explorer Camp Rig', type: 'building', desc: 'Cabin + lantern + perimeter' },
      { name: 'Watchtower Light Station', type: 'light_spot', desc: 'Spotlight with beacon stand' },
    ],
    scripts: [
      { name: 'CharacterController.ts', type: 'capsule', desc: 'WASD & Touch locomotion handler' },
      { name: 'RotatingBeacon.ts', type: 'cylinder', desc: 'Procedural rotation behavior' },
      { name: 'PatrolAI.ts', type: 'npc', desc: 'Waypoint navigation agent' },
    ],
  };

  let allItems: { name: string; type: ObjectType; desc: string; cat: string }[] = [];
  Object.entries(assetsByCategory).forEach(([cat, list]) => {
    list.forEach((item) => allItems.push({ ...item, cat }));
  });

  const filteredItems = allItems.filter((item) => {
    const matchesCat = activeCategory === 'all' || item.cat === activeCategory;
    const matchesSearch =
      searchQuery === '' ||
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.desc.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="flex flex-col h-full bg-[#11161f] text-slate-300 text-xs select-none">
      {/* Search Bar */}
      <div className="p-2 border-b border-[#21262d] bg-[#0d1117]">
        <div className="relative">
          <Search className="w-3 h-3 text-slate-500 absolute left-2 top-2" />
          <input
            type="text"
            placeholder="Search assets, prefabs, materials..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#161b22] border border-[#30363d] rounded pl-7 pr-2 py-1 text-[11px] text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex overflow-x-auto p-1.5 gap-1 border-b border-[#21262d] scrollbar-none bg-[#0d1117]">
        {categories.map((c) => (
          <button
            key={c.id}
            onClick={() => {
              setActiveCategory(c.id);
              audioSystem.playSound('click', { pitch: 1.3, volume: 0.2 });
            }}
            className={`flex items-center space-x-1 px-2 py-1 rounded text-[10px] whitespace-nowrap transition-colors ${
              activeCategory === c.id
                ? 'bg-cyan-950/90 text-cyan-300 border border-cyan-700/60 font-medium'
                : 'bg-[#161b22] text-slate-400 hover:text-white border border-[#21262d]'
            }`}
          >
            {c.icon}
            <span>{c.label}</span>
          </button>
        ))}
      </div>

      {/* Assets Grid */}
      <div className="flex-1 overflow-y-auto p-2 grid grid-cols-2 gap-2 content-start">
        {filteredItems.length === 0 ? (
          <div className="col-span-2 py-8 text-center text-slate-500 text-[11px]">
            No assets found matching "{searchQuery}"
          </div>
        ) : (
          filteredItems.map((item, idx) => (
            <div
              key={idx}
              onClick={() => {
                onSpawnAsset(item.type, item.name);
                audioSystem.playSound('synth_jump', { pitch: 1.4, volume: 0.3 });
              }}
              className="group bg-[#161b22] hover:bg-[#1f2633] border border-[#21262d] hover:border-cyan-600/60 rounded p-2 flex flex-col justify-between cursor-pointer transition-all shadow-sm hover:shadow-cyan-950/20"
            >
              <div className="flex items-start justify-between">
                <span className="font-semibold text-slate-200 text-[11px] group-hover:text-cyan-300 truncate">
                  {item.name}
                </span>
                <Plus className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-400 shrink-0 ml-1" />
              </div>
              <p className="text-[10px] text-slate-400 mt-1 line-clamp-2 leading-tight">
                {item.desc}
              </p>
              <div className="mt-2 pt-1 border-t border-[#262c36] flex items-center justify-between text-[9px] text-slate-500 font-mono">
                <span>{item.type}</span>
                <span className="text-cyan-400 opacity-0 group-hover:opacity-100 transition-opacity">
                  + Spawn
                </span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
