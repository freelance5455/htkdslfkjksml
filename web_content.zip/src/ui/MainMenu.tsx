import { useEffect, useState } from 'react';
import { Logo, MenuButton, useStore } from './common';
import { levelFromXp, getOperator } from '../game/data/content';
import { getWeapon } from '../game/data/weapons';
import { isTouchDevice } from '../game/save';

export type MenuTarget = 'play' | 'br' | 'multiplayer' | 'range' | 'loadout' | 'armory' | 'operators' | 'missions' | 'progression' | 'settings' | 'audio' | 'graphics' | 'controls' | 'credits' | 'quick';

const TIPS = [
  'Sprint then press crouch to slide into cover.',
  'Headshots deal bonus damage — the multiplier varies per weapon.',
  'Enemies hear unsuppressed gunfire from far away. Suppressors keep you off the minimap.',
  'Chain eliminations to raise your score multiplier up to x3.',
  'In Battle Royale, press V to apply armor plates and H to use medkits.',
  'Attachments change real weapon stats — compare them in the Loadout screen.',
  'Missions award bonus XP. Claim them from the Missions screen.',
];

export function MainMenu({ go }: { go: (t: MenuTarget) => void }) {
  const s = useStore(); const p = s.profile;
  const lv = levelFromXp(p.xp); const op = getOperator(p.operator); const lo = p.loadouts[p.activeLoadout];
  const [tip, setTip] = useState(0);
  useEffect(() => { const t = setInterval(() => setTip(x => (x + 1) % TIPS.length), 6000); return () => clearInterval(t); }, []);
  const best = p.highscores.length ? Math.max(...p.highscores.map(h => h.score)) : 0;
  const touch = isTouchDevice();
  const items: { t: MenuTarget; label: string; status?: string; primary?: boolean }[] = [
    { t: 'play', label: 'Play', status: 'Offline Combat', primary: true },
    { t: 'br', label: 'Battle Royale', status: 'vs AI' },
    { t: 'multiplayer', label: 'Multiplayer', status: 'TDM vs AI · Online N/A' },
    { t: 'range', label: 'Practice Range' },
    { t: 'loadout', label: 'Loadout' },
    { t: 'armory', label: 'Weapon Armory', status: '20 weapons' },
    { t: 'operators', label: 'Operators' },
    { t: 'missions', label: 'Missions' },
    { t: 'progression', label: 'Progression', status: `LV ${lv.level}` },
    { t: 'settings', label: 'Settings' },
    { t: 'audio', label: 'Audio Settings' },
    { t: 'graphics', label: 'Graphics Settings' },
    { t: 'controls', label: 'Controls' },
    { t: 'credits', label: 'Credits' },
  ];
  return (
    <div className="absolute inset-0 flex" style={{ paddingLeft: 'env(safe-area-inset-left)', paddingRight: 'env(safe-area-inset-right)' }}>
      <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/45 to-transparent pointer-events-none" />
      <div className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-black/80 to-transparent pointer-events-none" />
      {/* left column */}
      <div className="relative flex flex-col w-full max-w-[420px] px-4 sm:px-8 py-3 sm:py-6 min-h-0 anim-right">
        <div className="shrink-0 mb-2 sm:mb-5 origin-left scale-75 sm:scale-100"><Logo /></div>
        <nav className="flex-1 min-h-0 scroll-y pr-2 grid grid-cols-1 [@media(max-height:560px)]:grid-cols-2 gap-1 content-start">
          {items.map((it, i) => (
            <div key={it.t} className="anim-up" style={{ animationDelay: `${0.04 * i}s` }}>
              <MenuButton primary={it.primary} small={false} status={it.status} onClick={() => go(it.t)} className="w-full">{it.label}</MenuButton>
            </div>
          ))}
          <div className="anim-up" style={{ animationDelay: '0.6s' }}>
            <MenuButton disabled status="Desktop/Android app only" hint="Browsers do not allow a page to close itself. Close the tab to exit." className="w-full">Exit</MenuButton>
          </div>
        </nav>
      </div>
      {/* top-right: profile */}
      <div className="absolute top-3 right-3 sm:top-5 sm:right-6 flex items-center gap-3 anim-fade">
        <div className="text-right">
          <div className="text-sm sm:text-base font-black tracking-[0.2em]">{p.name}</div>
          <div className="text-[10px] tracking-[0.3em] text-amber-op">{op.name} · {op.role.toUpperCase()}</div>
          <div className="mt-1 w-40 sm:w-52 h-1.5 bg-white/10"><div className="h-full bg-amber-op" style={{ width: `${(lv.into / lv.need) * 100}%` }} /></div>
          <div className="text-[9px] tracking-widest text-white/50 mt-0.5">{lv.into} / {lv.need} XP</div>
        </div>
        <div className="w-12 h-12 sm:w-14 sm:h-14 clip-corner-sm bg-amber-op text-black flex flex-col items-center justify-center font-black leading-none">
          <span className="text-[8px] tracking-widest">LEVEL</span><span className="text-xl sm:text-2xl">{lv.level}</span>
        </div>
      </div>
      {/* bottom-right: quick deploy */}
      <div className="absolute bottom-3 right-3 sm:bottom-6 sm:right-6 flex flex-col items-end gap-2 max-w-[60%] anim-up" style={{ animationDelay: '0.3s' }}>
        <div className="hidden sm:block text-right text-[10px] tracking-[0.25em] text-white/50">LOADOUT · <span className="text-white/80">{lo.name}</span> — {getWeapon(lo.primary.weapon).name} / {getWeapon(lo.secondary.weapon).name}</div>
        {best > 0 && <div className="text-[10px] tracking-[0.25em] text-white/50">BEST SCORE <span className="text-amber-op font-bold">{best.toLocaleString()}</span></div>}
        <button onClick={() => go('quick')} className="anim-glow clip-corner bg-amber-op hover:bg-amber-300 text-black px-6 sm:px-10 py-3 sm:py-4 font-black tracking-[0.3em] text-sm sm:text-lg transition-colors">
          ▶ QUICK DEPLOY
        </button>
        <div className="text-[10px] text-white/45 tracking-wider text-right max-w-xs">{touch ? 'Touch controls enabled · ' : 'Mouse + keyboard · '}TIP: {TIPS[tip]}</div>
      </div>
    </div>
  );
}
