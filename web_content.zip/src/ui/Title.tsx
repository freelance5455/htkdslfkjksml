import { useState } from "react";

const SPLASHES = [
  "Vehicles actually drive!",
  "Now with 100% more bazooka!",
  "Builds real mansions, block by block!",
  "Every button is rebindable!",
  "Try the highway preset at dusk!",
  "Trucks, buses, planes and guns!",
  "100% procedurally drawn pixels!",
];

interface Props {
  onPlay: () => void;
  onStore: () => void;
  onSettings: () => void;
  onHelp: () => void;
}

export default function Title({ onPlay, onStore, onSettings, onHelp }: Props) {
  const [bgOk, setBgOk] = useState(true);
  const [splash] = useState(() => SPLASHES[Math.floor(Math.random() * SPLASHES.length)]);

  return (
    <div className="absolute inset-0 overflow-hidden bg-[#22201c]">
      {bgOk ? (
        <img
          src="images/panorama.jpg"
          alt=""
          className="kenburns absolute inset-0 h-full w-full object-cover"
          onError={() => setBgOk(false)}
        />
      ) : (
        <div className="absolute inset-0 bg-[linear-gradient(180deg,#8ab8ff_0%,#c8a86a_62%,#5d9c3f_62.5%,#3c6b28_100%)]" />
      )}
      <div className="absolute inset-0 bg-[radial-gradient(120%_90%_at_50%_10%,#0e0b0b22_0%,#0e0b0bd9_78%)]" />
      <div className="absolute inset-x-0 bottom-0 h-40 bg-[linear-gradient(180deg,#0e0b0b00,#0e0b0be6)]" />

      <div className="relative flex h-full flex-col items-center justify-center px-5">
        <div className="text-[9px] tracking-[0.42em] text-[#b7ada0] sm:text-[10px]">
          SANDBOX · VEHICLES · WEAPONS · BUILDINGS
        </div>

        <div className="relative mt-4">
          <h1
            className="font-title text-[clamp(30px,8.4vw,88px)] leading-none text-[#e8e2d6]"
            style={{
              textShadow:
                "4px 4px 0 #2b2118, 8px 8px 0 #16110c, -2px -2px 0 #2b211866, 0 18px 40px #00000099",
              letterSpacing: "0.02em",
            }}
          >
            VOXELCRAFT
          </h1>
          <div className="splash absolute right-0 top-[calc(100%-6px)] whitespace-nowrap origin-center text-[10px] text-[#ffff4d] mc-shadow sm:text-[13px]">
            {splash}
          </div>
        </div>

        <div className="mt-12 flex w-full max-w-[330px] flex-col gap-3">
          <button className="mc-btn mc-btn--grass w-full py-4 text-base" onClick={onPlay}>
            ▶ PLAY WORLD
          </button>
          <button className="mc-btn w-full py-3" onClick={onStore}>
            STORE · VEHICLES &amp; GUNS
          </button>
          <div className="flex gap-3">
            <button className="mc-btn w-full py-3" onClick={onSettings}>
              SETTINGS
            </button>
            <button className="mc-btn w-full py-3" onClick={onHelp}>
              HOW TO PLAY
            </button>
          </div>
        </div>

        <div className="mt-10 max-w-[560px] text-center text-[9px] leading-[2.2] tracking-[0.18em] text-[#b7ada0]">
          A MINECRAFT REPLICA — DRIVE CARS, BUSES, TRUCKS AND PLANES · FIRE RIFLES AND
          BAZOOKAS THAT CRATER THE TERRAIN · BUILD MANSIONS, BUNGALOWS AND HIGHWAYS
        </div>

        <div className="absolute bottom-4 left-4 text-[9px] tracking-[0.22em] text-[#8c8378]">
          VOXELCRAFT 1.0 · THREE.JS VOXEL ENGINE
        </div>
        <div className="absolute bottom-4 right-4 text-[9px] tracking-[0.22em] text-[#8c8378]">
          NOT AFFILIATED WITH MOJANG
        </div>
      </div>
    </div>
  );
}
