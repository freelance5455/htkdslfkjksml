import React, { useState } from 'react';
import {
  Play,
  Square,
  Save,
  FolderOpen,
  Plus,
  Download,
  Upload,
  Activity,
  Maximize2,
  HelpCircle,
  FileCode,
  Layers,
  Sparkles,
  Volume2,
  Cpu,
  Smartphone,
} from 'lucide-react';
import { ProjectData, SceneData } from '../types';
import { audioSystem } from '../audio/audioManager';

interface TopMenuBarProps {
  project: ProjectData;
  activeScene: SceneData;
  isGameMode: boolean;
  onToggleGameMode: () => void;
  onSaveScene: () => void;
  onOpenProjectModal: () => void;
  onSelectScene: (sceneId: string) => void;
  onCreateNewScene: () => void;
  onExportProject: () => void;
  onImportProject: () => void;
  onOpenModal: (type: 'shortcuts' | 'about' | 'build') => void;
  bottomPanelTab: string;
  setBottomPanelTab: (tab: any) => void;
  showBottomPanel: boolean;
  setShowBottomPanel: (v: boolean) => void;
  isMobileLayout: boolean;
  setIsMobileLayout: (v: boolean) => void;
}

export const TopMenuBar: React.FC<TopMenuBarProps> = ({
  project,
  activeScene,
  isGameMode,
  onToggleGameMode,
  onSaveScene,
  onOpenProjectModal,
  onSelectScene,
  onCreateNewScene,
  onExportProject,
  onImportProject,
  onOpenModal,
  bottomPanelTab,
  setBottomPanelTab,
  showBottomPanel,
  setShowBottomPanel,
  isMobileLayout,
  setIsMobileLayout,
}) => {
  const [activeMenu, setActiveMenu] = useState<string | null>(null);

  const toggleMenu = (menuName: string) => {
    setActiveMenu(activeMenu === menuName ? null : menuName);
    audioSystem.playSound('click', { pitch: 1.4, volume: 0.2 });
  };

  const closeMenu = () => setActiveMenu(null);

  return (
    <header className="h-11 bg-[#0d1117] border-b border-[#21262d] flex items-center justify-between px-2 sm:px-4 select-none relative z-40 text-xs text-[#c9d1d9]">
      {/* Brand & Project Name */}
      <div className="flex items-center space-x-3">
        <div className="flex items-center space-x-2">
          <div className="w-6 h-6 rounded bg-gradient-to-tr from-cyan-600 via-sky-500 to-amber-500 flex items-center justify-center font-black text-white text-xs shadow-md shadow-cyan-900/40">
            D
          </div>
          <div className="flex flex-col">
            <div className="flex items-center space-x-1.5">
              <span className="font-extrabold tracking-wider text-white text-xs">DAVIENGINE</span>
              <span className="px-1 py-0.2 text-[9px] bg-cyan-950/80 text-cyan-400 border border-cyan-800/60 rounded font-mono">
                0.1.0
              </span>
            </div>
          </div>
        </div>

        <div className="h-4 w-px bg-[#30363d] hidden sm:block" />

        {/* Project & Scene Selector */}
        <div className="hidden md:flex items-center space-x-2 text-[11px] text-[#8b949e]">
          <span>Project:</span>
          <span className="font-semibold text-slate-200 bg-[#161b22] px-2 py-0.5 rounded border border-[#30363d]">
            {project.name}
          </span>
          <span>Scene:</span>
          <select
            value={activeScene.id}
            onChange={(e) => onSelectScene(e.target.value)}
            className="bg-[#161b22] text-cyan-300 px-2 py-0.5 rounded border border-[#30363d] text-[11px] focus:outline-none focus:border-cyan-500 cursor-pointer"
          >
            {project.scenes.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </div>

        {/* Desktop Menus */}
        <nav className="hidden lg:flex items-center space-x-1 ml-2">
          {/* FILE MENU */}
          <div className="relative">
            <button
              onClick={() => toggleMenu('file')}
              className={`px-2 py-1 rounded hover:bg-[#21262d] ${activeMenu === 'file' ? 'bg-[#21262d] text-white' : ''}`}
            >
              FILE
            </button>
            {activeMenu === 'file' && (
              <div
                className="absolute top-full left-0 mt-1 w-48 bg-[#161b22] border border-[#30363d] rounded shadow-xl py-1 z-50 text-[11px]"
                onMouseLeave={closeMenu}
              >
                <button
                  onClick={() => {
                    onCreateNewScene();
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-950/60 hover:text-cyan-400 flex items-center justify-between"
                >
                  <span className="flex items-center gap-2">
                    <Plus className="w-3.5 h-3.5 text-cyan-400" /> New Scene
                  </span>
                </button>
                <button
                  onClick={() => {
                    onSaveScene();
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-950/60 hover:text-cyan-400 flex items-center justify-between"
                >
                  <span className="flex items-center gap-2">
                    <Save className="w-3.5 h-3.5 text-amber-400" /> Save Scene
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">Ctrl+S</span>
                </button>
                <div className="h-px bg-[#30363d] my-1" />
                <button
                  onClick={() => {
                    onOpenProjectModal();
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-950/60 hover:text-cyan-400 flex items-center gap-2"
                >
                  <FolderOpen className="w-3.5 h-3.5 text-sky-400" /> Project Manager
                </button>
                <button
                  onClick={() => {
                    onExportProject();
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-950/60 hover:text-cyan-400 flex items-center gap-2"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-400" /> Export Project (JSON)
                </button>
                <button
                  onClick={() => {
                    onImportProject();
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-950/60 hover:text-cyan-400 flex items-center gap-2"
                >
                  <Upload className="w-3.5 h-3.5 text-violet-400" /> Import Project (JSON)
                </button>
              </div>
            )}
          </div>

          {/* EDIT MENU */}
          <div className="relative">
            <button
              onClick={() => toggleMenu('edit')}
              className={`px-2 py-1 rounded hover:bg-[#21262d] ${activeMenu === 'edit' ? 'bg-[#21262d] text-white' : ''}`}
            >
              EDIT
            </button>
            {activeMenu === 'edit' && (
              <div
                className="absolute top-full left-0 mt-1 w-44 bg-[#161b22] border border-[#30363d] rounded shadow-xl py-1 z-50 text-[11px]"
                onMouseLeave={closeMenu}
              >
                <button
                  onClick={() => {
                    onSaveScene();
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#21262d]"
                >
                  Save State
                </button>
                <button
                  onClick={() => {
                    audioSystem.playSound('click');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#21262d] flex justify-between"
                >
                  <span>Focus Selected</span>
                  <span className="text-[10px] text-slate-500 font-mono">F</span>
                </button>
              </div>
            )}
          </div>

          {/* VIEW MENU */}
          <div className="relative">
            <button
              onClick={() => toggleMenu('view')}
              className={`px-2 py-1 rounded hover:bg-[#21262d] ${activeMenu === 'view' ? 'bg-[#21262d] text-white' : ''}`}
            >
              VIEW
            </button>
            {activeMenu === 'view' && (
              <div
                className="absolute top-full left-0 mt-1 w-44 bg-[#161b22] border border-[#30363d] rounded shadow-xl py-1 z-50 text-[11px]"
                onMouseLeave={closeMenu}
              >
                <button
                  onClick={() => {
                    setShowBottomPanel(!showBottomPanel);
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#21262d]"
                >
                  {showBottomPanel ? 'Hide Bottom Panels' : 'Show Bottom Panels'}
                </button>
                <button
                  onClick={() => {
                    setBottomPanelTab('profiler');
                    setShowBottomPanel(true);
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#21262d]"
                >
                  Toggle Profiler
                </button>
              </div>
            )}
          </div>

          {/* PROJECT MENU */}
          <div className="relative">
            <button
              onClick={() => toggleMenu('project')}
              className={`px-2 py-1 rounded hover:bg-[#21262d] ${activeMenu === 'project' ? 'bg-[#21262d] text-white' : ''}`}
            >
              PROJECT
            </button>
            {activeMenu === 'project' && (
              <div
                className="absolute top-full left-0 mt-1 w-48 bg-[#161b22] border border-[#30363d] rounded shadow-xl py-1 z-50 text-[11px]"
                onMouseLeave={closeMenu}
              >
                <button
                  onClick={() => {
                    onOpenProjectModal();
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#21262d]"
                >
                  Manage Projects & Scenes
                </button>
                <button
                  onClick={() => {
                    onExportProject();
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#21262d]"
                >
                  Save to Local Disk (JSON)
                </button>
              </div>
            )}
          </div>

          {/* BUILD MENU */}
          <div className="relative">
            <button
              onClick={() => toggleMenu('build')}
              className={`px-2 py-1 rounded hover:bg-[#21262d] ${activeMenu === 'build' ? 'bg-[#21262d] text-white' : ''}`}
            >
              BUILD
            </button>
            {activeMenu === 'build' && (
              <div
                className="absolute top-full left-0 mt-1 w-52 bg-[#161b22] border border-[#30363d] rounded shadow-xl py-1 z-50 text-[11px]"
                onMouseLeave={closeMenu}
              >
                <button
                  onClick={() => {
                    onOpenModal('build');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#21262d]"
                >
                  Export Standalone Web Player
                </button>
                <button
                  onClick={() => {
                    onOpenModal('build');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#21262d]"
                >
                  Android 8+ APK Configuration
                </button>
              </div>
            )}
          </div>

          {/* HELP MENU */}
          <div className="relative">
            <button
              onClick={() => toggleMenu('help')}
              className={`px-2 py-1 rounded hover:bg-[#21262d] ${activeMenu === 'help' ? 'bg-[#21262d] text-white' : ''}`}
            >
              HELP
            </button>
            {activeMenu === 'help' && (
              <div
                className="absolute top-full left-0 mt-1 w-44 bg-[#161b22] border border-[#30363d] rounded shadow-xl py-1 z-50 text-[11px]"
                onMouseLeave={closeMenu}
              >
                <button
                  onClick={() => {
                    onOpenModal('shortcuts');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#21262d] flex items-center gap-2"
                >
                  <HelpCircle className="w-3.5 h-3.5 text-cyan-400" /> Controls & Shortcuts
                </button>
                <button
                  onClick={() => {
                    onOpenModal('about');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#21262d] flex items-center gap-2"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" /> About DAVIENGINE
                </button>
              </div>
            )}
          </div>
        </nav>
      </div>

      {/* Center PLAY / STOP Controls */}
      <div className="flex items-center space-x-2">
        <button
          onClick={() => {
            audioSystem.playSound(isGameMode ? 'synth_bell' : 'synth_jump', { pitch: isGameMode ? 0.8 : 1.2 });
            onToggleGameMode();
          }}
          className={`px-4 py-1 rounded font-bold tracking-wider text-[11px] flex items-center space-x-1.5 transition-all shadow-md ${
            isGameMode
              ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-950 animate-pulse'
              : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-950'
          }`}
          title={isGameMode ? 'Stop Game Simulation (Return to Editor)' : 'Play Game Mode (WASD / Touch Controls)'}
        >
          {isGameMode ? (
            <>
              <Square className="w-3.5 h-3.5 fill-current" />
              <span>STOP</span>
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>PLAY</span>
            </>
          )}
        </button>

        <button
          onClick={onSaveScene}
          className="bg-[#21262d] hover:bg-[#30363d] text-slate-200 px-2.5 py-1 rounded flex items-center space-x-1 border border-[#30363d] transition-colors"
          title="Save Scene (Ctrl+S)"
        >
          <Save className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden sm:inline text-[11px]">Save</span>
        </button>
      </div>

      {/* Right Tools & View Toggles */}
      <div className="flex items-center space-x-1 sm:space-x-2">
        {/* Mobile View Toggle */}
        <button
          onClick={() => setIsMobileLayout(!isMobileLayout)}
          className={`p-1.5 rounded border transition-colors ${
            isMobileLayout
              ? 'bg-cyan-950/80 border-cyan-500 text-cyan-400'
              : 'bg-[#161b22] border-[#30363d] text-slate-400 hover:text-white'
          }`}
          title="Toggle Mobile/Responsive Layout"
        >
          <Smartphone className="w-3.5 h-3.5" />
        </button>

        {/* Profiler Quick Button */}
        <button
          onClick={() => {
            setBottomPanelTab('profiler');
            setShowBottomPanel(true);
          }}
          className={`p-1.5 rounded border transition-colors ${
            showBottomPanel && bottomPanelTab === 'profiler'
              ? 'bg-cyan-950/80 border-cyan-500 text-cyan-400'
              : 'bg-[#161b22] border-[#30363d] text-slate-400 hover:text-white'
          }`}
          title="Performance Profiler"
        >
          <Activity className="w-3.5 h-3.5" />
        </button>

        {/* Console Quick Button */}
        <button
          onClick={() => {
            setBottomPanelTab('console');
            setShowBottomPanel(true);
          }}
          className={`p-1.5 rounded border transition-colors ${
            showBottomPanel && bottomPanelTab === 'console'
              ? 'bg-cyan-950/80 border-cyan-500 text-cyan-400'
              : 'bg-[#161b22] border-[#30363d] text-slate-400 hover:text-white'
          }`}
          title="System Console"
        >
          <FileCode className="w-3.5 h-3.5" />
        </button>
      </div>
    </header>
  );
};
