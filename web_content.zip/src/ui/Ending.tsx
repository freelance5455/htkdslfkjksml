import { useEffect, useState } from "react";
import { useGame } from "@/game/store";
import { loadAdmin } from "@/game/save";
import { CREDITS_DEFAULT } from "@/data/credits";
import { StarButton } from "./chrome";
import type { TransmissionPart } from "@/data/final-transmission";

export function EndingSequence() {
  const step = useGame((s) => s.endingStep);
  const advance = useGame((s) => s.advanceEnding);
  const finish = useGame((s) => s.finishEnding);
  const names = useGame((s) => s.names);
  const [parts, setParts] = useState<TransmissionPart[] | null>(null);
  const [letterIndex, setLetterIndex] = useState(0);

  useEffect(() => {
    let alive = true;
    void import("@/data/final-transmission").then((mod) => {
      if (alive) setParts(mod.buildFinalTransmission(names.player, names.searched));
    });
    return () => {
      alive = false;
    };
  }, [names.player, names.searched]);

  if (step < 6) {
    const lines = [
      "Silence.",
      "Une étoile flotte au centre.",
      "Transmission retrouvée.",
      "Destinataire identifié.",
      names.player.toUpperCase(),
      "Expéditeur identifié.",
    ];
    return (
      <button type="button" className="absolute inset-0 z-40 flex items-center justify-center px-8" onClick={advance}>
        <p className="font-display text-2xl tracking-wide text-lumen">{lines[step]}</p>
      </button>
    );
  }

  if (step === 6) {
    return (
      <button type="button" className="absolute inset-0 z-40 flex items-center justify-center px-8" onClick={advance}>
        <p className="font-display text-3xl tracking-[0.2em] text-lumen">{names.searched.toUpperCase()}</p>
      </button>
    );
  }

  if (!parts) {
    return <div className="absolute inset-0 z-40 bg-void" />;
  }

  const part = parts[letterIndex];
  if (!part) {
    return (
      <div className="absolute inset-0 z-40 flex flex-col items-center justify-center px-8">
        <StarButton variant="solid" onClick={finish}>
          …
        </StarButton>
      </div>
    );
  }

  return (
    <div className="absolute inset-0 z-40 overflow-y-auto bg-void px-6 py-16">
      <div className="mx-auto max-w-md">
        <p className="mb-6 whitespace-pre-wrap font-display text-lg leading-relaxed text-lumen/95">{part.body}</p>
        <StarButton
          variant="ghost"
          className="w-full"
          onClick={() => {
            if (letterIndex >= parts.length - 1) finish();
            else setLetterIndex((i) => i + 1);
          }}
        >
          Toucher pour continuer
        </StarButton>
      </div>
    </div>
  );
}

export function CreditsScreen() {
  const [gone, setGone] = useState(0);
  const admin = loadAdmin();
  const line1 = admin.creditsLine1 ?? CREDITS_DEFAULT.line1;
  const line2 = admin.creditsLine2 ?? CREDITS_DEFAULT.line2;
  const back = useGame((s) => s.backToTitle);

  useEffect(() => {
    const t = window.setInterval(() => setGone((g) => g + 1), 700);
    return () => window.clearInterval(t);
  }, []);

  return (
    <div className="absolute inset-0 z-40 flex flex-col items-center justify-center bg-void px-8 text-center">
      <div className="mb-10 flex gap-3">
        {Array.from({ length: 7 }).map((_, i) => (
          <span
            key={i}
            className="size-1.5 rounded-full bg-lumen"
            style={{ opacity: gone > i + 4 ? 0 : 1, transition: "opacity 1.2s" }}
          />
        ))}
      </div>
      {gone > 8 && (
        <>
          <p className="font-display text-sm tracking-[0.2em] text-fog">Fin de la transmission.</p>
          <p className="mt-10 font-display text-xl text-lumen">{line1}</p>
          <p className="mt-3 font-display text-base italic text-silver">{line2}</p>
          <button type="button" onClick={back} className="mt-16 text-[0.65rem] uppercase tracking-[0.24em] text-fog">
            Revenir
          </button>
        </>
      )}
    </div>
  );
}
