import React from 'react';
const glyphs:Record<string,string>={plus:'＋',play:'▶',pause:'Ⅱ',back:'‹',gear:'⚙',shield:'◈',spark:'✦',text:'T',audio:'♫',media:'▣',effects:'✳',keyframe:'◇',layers:'▤',undo:'↶',redo:'↷',export:'⇧',magic:'✧'};
export function Icon({name}:{name:string}){return <span aria-hidden="true" className="icon">{glyphs[name]??'•'}</span>}
