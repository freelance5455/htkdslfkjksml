import React from 'react';
import {
  Move,
  RotateCw,
  Maximize,
  Grid,
  Magnet,
  Camera,
  Eye,
  Crosshair,
  Box,
  Layers,
  Sparkles,
} from 'lucide-react';
import { ViewportMode, TransformGizmoMode } from '../types';
import { audioSystem } from '../audio/audioManager';

interface ViewportToolbarProps {
  gizmoMode: TransformGizmoMode;
  onSetGizmoMode: (mode: TransformGizmoMode) => void;
  viewportMode: ViewportMode;
  onSetViewportMode: (mode: ViewportMode) => void;
  showGrid: boolean;
  onToggleGrid: () => void;
  snapEnabled: boolean;
  onToggleSnap: () => void;
  onCameraView: (preset: 'perspective' | 'top' | 'front' | 'side' | 'reset') => void;
  onFocusSelected: () => void;
  selectedObjectId: string | null;
}

export const ViewportToolbar: React.FC<ViewportToolbarProps> = ({
  gizmoMode,
  onSetGizmoMode,
  viewportMode,
  onSetViewportMode,
  showGrid,
  onToggleGrid,
  snapEnabled,
  onToggleSnap,
  onCameraView,
  onFocusSelected,
  selectedObjectId,
}) => {
  return (
    <div className="h-9 bg-[#161b22]/90 backdrop-blur border-b border-[#21262d] flex items-center justify-between px-3 text-xs text-[#c9d1d9] select-none z-10">
      {/* Transform Gizmo Modes */}
      <div className="flex items-center space-x-1">
        <button
          onClick={() => {
            onSetGizmoMode('translate');
            audioSystem.playSound('click', { pitch: 1.2 });
          }}
          className={`px-2 py-1 rounded flex items-center space-x-1 border transition-all ${
            gizmoMode === 'translate'
              ? 'bg-cyan-950/80 border-cyan-500 text-cyan-300 shadow-sm shadow-cyan-900/40 font-semibold'
              : 'bg-[#0d1117] border-[#30363d] text-slate-400 hover:text-white'
          }`}
          title="Move Gizmo (Shortcut: W)"
        >
          <Move className="w-3.5 h-3.5" />
          <span className="hidden sm:inline text-[10px]">Move (W)</span>
        </button>

        <button
          onClick={() => {
            onSetGizmoMode('rotate');
            audioSystem.playSound('click', { pitch: 1.3 });
          }}
          className={`px-2 py-1 rounded flex items-center space-x-1 border transition-all ${
            gizmoMode === 'rotate'
              ? 'bg-cyan-950/80 border-cyan-500 text-cyan-300 shadow-sm shadow-cyan-900/40 font-semibold'
              : 'bg-[#0d1117] border-[#30363d] text-slate-400 hover:text-white'
          }`}
          title="Rotate Gizmo (Shortcut: E)"
        >
          <RotateCw className="w-3.5 h-3.5" />
          <span className="hidden sm:inline text-[10px]">Rotate (E)</span>
        </button>

        <button
          onClick={() => {
            onSetGizmoMode('scale');
            audioSystem.playSound('click', { pitch: 1.4 });
          }}
          className={`px-2 py-1 rounded flex items-center space-x-1 border transition-all ${
            gizmoMode === 'scale'
              ? 'bg-cyan-950/80 border-cyan-500 text-cyan-300 shadow-sm shadow-cyan-900/40 font-semibold'
              : 'bg-[#0d1117] border-[#30363d] text-slate-400 hover:text-white'
          }`}
          title="Scale Gizmo (Shortcut: R)"
        >
          <Maximize className="w-3.5 h-3.5" />
          <span className="hidden sm:inline text-[10px]">Scale (R)</span>
        </button>
      </div>

      {/* Center Shading Modes */}
      <div className="flex items-center space-x-1 bg-[#0d1117] p-0.5 rounded border border-[#30363d]">
        <button
          onClick={() => onSetViewportMode('wireframe')}
          className={`px-2 py-0.5 rounded text-[10px] transition-colors ${
            viewportMode === 'wireframe' ? 'bg-cyan-600 text-white font-medium' : 'text-slate-400 hover:text-white'
          }`}
        >
          Wireframe
        </button>
        <button
          onClick={() => onSetViewportMode('solid')}
          className={`px-2 py-0.5 rounded text-[10px] transition-colors ${
            viewportMode === 'solid' ? 'bg-cyan-600 text-white font-medium' : 'text-slate-400 hover:text-white'
          }`}
        >
          Solid
        </button>
        <button
          onClick={() => onSetViewportMode('material')}
          className={`px-2 py-0.5 rounded text-[10px] transition-colors ${
            viewportMode === 'material' ? 'bg-cyan-600 text-white font-medium' : 'text-slate-400 hover:text-white'
          }`}
        >
          Material
        </button>
      </div>

      {/* Right Helpers & Camera Views */}
      <div className="flex items-center space-x-1">
        {/* Snapping */}
        <button
          onClick={onToggleSnap}
          className={`p-1 rounded border ${
            snapEnabled
              ? 'bg-amber-950/80 border-amber-500 text-amber-300'
              : 'bg-[#0d1117] border-[#30363d] text-slate-400 hover:text-white'
          }`}
          title="Toggle Grid Snapping"
        >
          <Magnet className="w-3.5 h-3.5" />
        </button>

        {/* Grid */}
        <button
          onClick={onToggleGrid}
          className={`p-1 rounded border ${
            showGrid
              ? 'bg-cyan-950/80 border-cyan-500 text-cyan-300'
              : 'bg-[#0d1117] border-[#30363d] text-slate-400 hover:text-white'
          }`}
          title="Toggle Ground Grid"
        >
          <Grid className="w-3.5 h-3.5" />
        </button>

        {/* Focus selected object */}
        <button
          onClick={onFocusSelected}
          disabled={!selectedObjectId}
          className={`p-1 rounded border transition-colors ${
            selectedObjectId
              ? 'bg-[#0d1117] border-[#30363d] text-cyan-400 hover:bg-[#21262d]'
              : 'bg-[#0d1117] border-[#21262d] text-slate-600 cursor-not-allowed'
          }`}
          title="Focus Selected Object (Shortcut: F)"
        >
          <Crosshair className="w-3.5 h-3.5" />
        </button>

        {/* Camera presets */}
        <div className="hidden md:flex items-center space-x-0.5 pl-1 border-l border-[#30363d]">
          <button
            onClick={() => onCameraView('perspective')}
            className="px-1.5 py-0.5 rounded text-[10px] bg-[#0d1117] text-slate-300 hover:text-white border border-[#30363d]"
            title="Perspective View"
          >
            Persp
          </button>
          <button
            onClick={() => onCameraView('top')}
            className="px-1.5 py-0.5 rounded text-[10px] bg-[#0d1117] text-slate-300 hover:text-white border border-[#30363d]"
            title="Top-Down View"
          >
            Top
          </button>
          <button
            onClick={() => onCameraView('front')}
            className="px-1.5 py-0.5 rounded text-[10px] bg-[#0d1117] text-slate-300 hover:text-white border border-[#30363d]"
            title="Front View"
          >
            Front
          </button>
          <button
            onClick={() => onCameraView('reset')}
            className="px-1.5 py-0.5 rounded text-[10px] bg-[#0d1117] text-slate-300 hover:text-white border border-[#30363d]"
            title="Reset Camera"
          >
            Reset
          </button>
        </div>
      </div>
    </div>
  );
};
