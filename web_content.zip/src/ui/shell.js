/* ==========================================================================
   ui/shell.js — پوسته اپ: روتر، هدر، ناوبری پایین، مودال، توست، اجزای مشترک
   ========================================================================== */

import { State } from '../store.js';
import { fmtCompact, toFaDigits, esc, pct, faDate, todayKey, clamp } from '../utils.js';
import { ensureDay, ensureSnapshot } from '../engines/planner.js';
import { levelInfo } from '../achievements.js';
import { ring } from '../charts.js';

export const SCREENS = {};
export const NAV = [
  { id: 'today', icon: '☀️', label: 'امروز' },
  { id: 'path', icon: '🧭', label: 'مسیر' },
  { id: 'coach', icon: '🤖', label: 'مربی', center: true },
  { id: 'wealth', icon: '💎', label: 'ثروت' },
  { id: 'more', icon: '☰', label: 'بیشتر' },
];

export const params = {};

export function register(id, def) { SCREENS[id] = def; }

export function go(id, p) {
  Object.keys(params).forEach((k) => delete params[k]);
  if (p) Object.assign(params, p);
  if (('#/' + id) !== location.hash) location.hash = '#/' + id;
  else render();
  try { window.scrollTo({ top: 0, behavior: 'smooth' }); } catch (e) { window.scrollTo(0, 0); }
}

export function currentRoute() {
  const h = (location.hash || '#/today').replace('#/', '');
  const [id, sub] = h.split('/');
  return { id: id || 'today', sub: sub || '' };
}

/* ------------------------------------------------------------------ helpers */
export function M(n) { return fmtCompact(n, State.get().profile); }
export function FA(n) { return toFaDigits(n); }

export function section(title, body, opts = {}) {
  return '<section class="section">' +
    (title ? '<div class="section__head"><h3>' + title + '</h3>' + (opts.action || '') + '</div>' : '') +
    body + '</section>';
}

export function card(inner, cls) { return '<div class="card ' + (cls || '') + '">' + inner + '</div>'; }

export function kpi(label, value, cls) {
  return '<div class="kpi ' + (cls || '') + '"><span class="kpi__label">' + label + '</span><span class="kpi__value num">' + value + '</span></div>';
}

export function kv(k, v) { return '<div class="kv"><span class="muted">' + k + '</span><b>' + v + '</b></div>'; }

export function listRow(opts) {
  return '<div class="list-row">' +
    (opts.icon ? '<div style="font-size:19px">' + opts.icon + '</div>' : '') +
    '<div class="list-row__main"><div class="list-row__title">' + esc(opts.title) + '</div>' +
    (opts.sub ? '<div class="list-row__sub">' + esc(opts.sub) + '</div>' : '') + '</div>' +
    (opts.amount != null ? '<div class="list-row__amount num ' + (opts.amountClass || '') + '">' + opts.amount + '</div>' : '') +
    (opts.right || '') + '</div>';
}

export function bar(percent, cls) {
  const p = clamp(percent, 0, 100);
  return '<div class="bar ' + (cls || '') + '"><i style="width:' + p + '%"></i></div>';
}

export function chips(list, activeIndex) {
  return '<div class="chips">' + list.map((c, i) => '<span class="chip ' + (i === activeIndex ? 'chip--gold' : '') + '">' + esc(c) + '</span>').join('') + '</div>';
}

export function emptyBox(icon, text) {
  return '<div class="empty"><i>' + icon + '</i><p class="tiny">' + esc(text) + '</p></div>';
}

/* -------------------------------------------------------------------- toast */
let toastTimer = null;
export function toast(msg, type) {
  const root = document.getElementById('toast-root');
  const el = document.createElement('div');
  el.className = 'toast ' + (type ? 'toast--' + type : '');
  el.textContent = msg;
  root.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateY(8px)'; el.style.transition = 'all .3s'; }, 2600);
  setTimeout(() => el.remove(), 3000);
}

/* ------------------------------------------------------------------- modal */
export function modal(opts) {
  const root = document.getElementById('modal-root');
  root.hidden = false;
  root.innerHTML =
    '<div class="modal__backdrop" data-act="ui.closeModal"></div>' +
    '<div class="modal__box ' + (opts.center ? 'modal--center-box' : '') + '">' +
    '<div class="modal__head"><h3>' + esc(opts.title || '') + '</h3>' +
    '<button class="iconbtn" data-act="ui.closeModal" aria-label="بستن">✕</button></div>' +
    '<div class="modal__body">' + (opts.body || '') + '</div>' +
    (opts.footer ? '<div class="btn-row mt">' + opts.footer + '</div>' : '') +
    '</div>';
}

export function closeModal() {
  const root = document.getElementById('modal-root');
  root.hidden = true; root.innerHTML = '';
}

export function formModal(title, fields, opts = {}) {
  const body = '<form data-form="' + opts.form + '">' + fields + '<button class="btn btn--primary btn--block mt" type="submit">' + (opts.submit || 'ذخیره') + '</button></form>';
  modal({ title, body });
  setTimeout(() => {
    const el = root().querySelector('input,select,textarea');
    if (el) el.focus();
  }, 120);
}
function root() { return document.getElementById('modal-root'); }

export function confirmModal(title, text, act, data) {
  modal({
    title,
    body: '<p class="muted">' + esc(text) + '</p>',
    footer: '<button class="btn btn--ghost" data-act="ui.closeModal">انصراف</button>' +
      '<button class="btn btn--danger" data-act="' + act + '" ' + Object.keys(data || {}).map((k) => 'data-' + k + '="' + esc(data[k]) + '"').join(' ') + '>تأیید و انجام</button>',
  });
}

/* ------------------------------------------------------------------ render */
export function render() {
  const state = State.get();
  if (!state) return;
  const route = currentRoute();
  const def = SCREENS[route.id] || SCREENS.today;
  const lv = levelInfo(state.gamification.xp);

  const top = document.getElementById('topbar');
  top.hidden = false;
  const showBack = def.tab === false;
  top.innerHTML =
    (showBack ? '<button class="iconbtn" data-act="ui.back" aria-label="بازگشت">‹</button>' : '') +
    '<div class="topbar__titles">' +
    '<p class="topbar__eyebrow">' + esc(def.eyebrow || 'مسیر میلیاردری') + '</p>' +
    '<h2 class="topbar__title">' + esc(def.title || '') + '</h2></div>' +
    '<button class="topbar__xp" data-act="ui.goAchievements" aria-label="امتیاز و سطح"><b>' + FA(lv.level) + '</b><span>' + esc(lv.fa) + '</span></button>' +
    '<button class="iconbtn" data-act="ui.toggleTheme" aria-label="تغییر حالت روشن/تیره">' + (state.settings.theme === 'dark' ? '☀️' : '🌙') + '</button>' +
    '<button class="iconbtn" data-act="ui.goSettings" aria-label="تنظیمات">⚙️</button>';

  const host = document.getElementById('screen');
  let html = '';
  try { html = def.render(route.sub, params); }
  catch (e) {
    html = card('<h3>خطا در نمایش این صفحه</h3><p class="muted">' + esc(String(e && e.message ? e.message : e)) + '</p><button class="btn btn--primary" data-act="ui.home">بازگشت به امروز</button>');
    if (typeof console !== 'undefined') console.error(e);
  }
  host.innerHTML = html;

  const nav = document.getElementById('bottomnav');
  nav.hidden = def.tab === false;
  if (def.tab !== false) {
    nav.innerHTML = NAV.map((n) => {
      const active = route.id === n.id || (n.id === 'today' && ['dashboard'].indexOf(route.id) > -1);
      return '<button class="navbtn ' + (active ? 'is-active' : '') + ' ' + (n.center ? 'navbtn--center' : '') + '" data-act="ui.nav" data-id="' + n.id + '">' +
        '<i>' + n.icon + '</i><span>' + n.label + '</span></button>';
    }).join('');
  }
  document.documentElement.setAttribute('data-theme', state.settings.theme === 'light' ? 'light' : 'dark');
}

/* ----------------------------------------------------- اجزای خاص و پرکاربرد */
export function scoreRing(score) {
  return ring((score / 1000) * 100, { size: 108, color: score >= 700 ? '#22c55e' : score >= 400 ? '#e8b44a' : '#ef4444', label: 'امتیاز مالی' });
}

export function taskRow(t, key) {
  const icons = {
    'مهم‌ترین اقدام': '🔥', 'یادگیری': '📚', 'اقدام مالی': '💰', 'اقدام درآمدی': '💼', 'عادت': '🧠',
    'مرور و برنامه‌ریزی': '📊', 'بدهی': '📉', 'پس‌انداز': '🪣', 'فروش': '🤝', 'مهارت': '🎯', 'سایر': '•',
  };
  return '<div class="task ' + (t.done ? 'done' : '') + ' ' + (t.cat === 'مهم‌ترین اقدام' ? 'task__big' : '') + '">' +
    '<button class="task__check" data-act="task.toggle" data-day="' + key + '" data-id="' + t.id + '" aria-label="انجام شد">' + (t.done ? '✓' : '') + '</button>' +
    '<div class="task__body"><div class="task__title">' + (icons[t.cat] || '•') + ' ' + esc(t.title) + '</div>' +
    '<div class="task__meta"><span class="chip">' + esc(t.cat) + '</span>' +
    '<span class="chip">' + FA(t.minutes || 30) + ' دقیقه</span>' +
    (t.rescheduled ? '<span class="chip chip--blue">بازآرایی‌شده</span>' : '') +
    (t.impact ? '<span class="chip chip--gold">اثر ' + FA(t.impact) + '</span>' : '') + '</div></div>' +
    '<button class="iconbtn" data-act="task.remove" data-day="' + key + '" data-id="' + t.id + '" aria-label="حذف">🗑</button>' +
    '</div>';
}

export function alertBox(level, icon, title, text, action) {
  return '<div class="alert alert--' + level + '"><i>' + icon + '</i><div style="flex:1"><b>' + esc(title) + '</b>' +
    '<div class="tiny">' + esc(text) + '</div></div>' +
    (action ? '<button class="btn btn--sm" data-act="ui.nav" data-id="' + action + '">رفتن</button>' : '') + '</div>';
}

export function disclaimer(text) {
  return '<div class="alert alert--info mt"><i>ℹ️</i><div class="tiny">' + esc(text) + '</div></div>';
}

export function dateBadge() { return faDate(todayKey(), { withWeekday: true }); }

export function pctText(x, d) { return pct(x, d); }
