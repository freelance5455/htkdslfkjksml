import { useEffect, useRef, useState, type CSSProperties } from 'react';
import { Game, type EndInfo, type HudState } from '../game/game';
import type { StartParams } from './Screens';
import { S, saveS, sfx } from '../game/audio';

function Hud({ g, h, onPause }: { g: Game; h: HudState; onPause: () => void }) {
  const [bm, setBm] = useState(false); const [dismiss, setDismiss] = useState(false); const mini = useRef<HTMLCanvasElement>(null);
  useEffect(() => { g.setMini(mini.current); }, [g]);
  const s = h.sel;
  return (
    <div id="hud">
      <div id="top">
        <div className="chip">💰 <b>{h.res}</b></div>
        <div className="chip">👥 <b>{h.pop}/{h.cap}</b></div>
        {h.buffT > 0 && <div className="chip">🔥 <b>{Math.ceil(h.buffT)}</b></div>}
        <div id="pows">
          {h.pows.map((p, i) => {
            const rdy = p.cd <= 0;
            return (
              <button key={i} className={'pw' + (rdy ? ' rdy' : '') + (h.powSel === i ? ' sel' : '')} title={p.ds} onClick={() => g.usePower(i)}>
                <i>{p.ic}</i>{p.n}<br /><span style={{ color: rdy ? '#7dff9a' : '#ffb0a0' }}>{rdy ? 'جاهز ✔' : Math.ceil(p.cd) + ' ث'}</span>
              </button>
            );
          })}
        </div>
        <button className="ib" onClick={() => { sfx('click'); onPause(); }}>⏸</button>
      </div>
      <button className="btn sm" id="bBuild" onClick={() => { sfx('click'); setBm(!bm); }}>🏗 بناء</button>
      {bm && (
        <div id="bmenu">
          {h.build.map(b => (
            <button key={b.t} className={'pb' + (b.ok ? '' : ' no')} onClick={() => { if (b.ok) { g.startPlace(b.t); setBm(false); } else g.toast('الذهب غير كافٍ', true); }}>
              <i>{b.ic}</i>{b.n}<small>💰 {b.cost}</small>
            </button>
          ))}
        </div>
      )}
      <div id="toast">{h.toasts.map(t => <div key={t.id} className={t.bad ? 'bad' : ''}>{t.s}</div>)}</div>
      {h.hint && <div id="hint"><span>{h.hint}</span><button className="btn sm red" onClick={() => { g.cancelModes(); g.am = false; g.box = false; }}>إلغاء</button></div>}
      <div id="side">
        <button className={'ib' + (h.box ? ' on' : '')} title="تحديد بمربع" onClick={() => g.toggleBox()}>⬚</button>
        <button className="ib" title="كل الجيش" onClick={() => g.selectAll()}>🪖</button>
        <button className={'ib' + (h.am ? ' on' : '')} title="هجوم وتحرك" onClick={() => g.toggleAm()}>⚔</button>
        <button className="ib" title="إيقاف" onClick={() => g.stopSel()}>⏹</button>
        <button className="ib" title="العودة للقاعدة" onClick={() => g.goBase()}>🏠</button>
      </div>
      <canvas id="mini" width={140} height={140} ref={mini} />
      <div id="panel">
        {!s && (<><div className="inf"><b>لا يوجد تحديد</b><p style={{ margin: '4px 0', color: '#aab6ca' }}>اضغط على وحدة أو مبنى. اسحب لتحريك الكاميرا.</p></div>
          <div className="pbs"><button className="pb cmd" onClick={() => g.selectAll()}><i>🪖</i>كل الجيش</button><button className="pb cmd" onClick={() => g.goBase()}><i>🏠</i>القاعدة</button></div></>)}
        {s && s.kind === 'units' && (<>
          <div className="inf"><b>{s.name} ×{s.count}</b><div className="hb"><div style={{ width: (s.hp / s.mhp) * 100 + '%' }} /></div><div>{Math.round(s.hp)}/{Math.round(s.mhp)}</div><div style={{ fontSize: 12 }}>{s.list}</div></div>
          <div className="pbs">
            <button className="pb cmd" onClick={() => g.stopSel()}><i>⏹</i>إيقاف</button>
            <button className={'pb cmd' + (h.am ? ' on' : '')} onClick={() => g.toggleAm()}><i>⚔</i>هجوم وتحرك</button>
            {s.hasWk && <button className="pb cmd" onClick={() => setBm(true)}><i>🏗</i>بناء</button>}
          </div>
        </>)}
        {s && s.kind === 'bld' && (<>
          <div className="inf"><b>{s.name}</b><div className="hb"><div style={{ width: (s.hp / s.mhp) * 100 + '%' }} /></div><div>{Math.round(s.hp)}/{Math.round(s.mhp)}</div>{s.cons < 1 && <div>🔨 قيد البناء {Math.round(s.cons * 100)}%</div>}</div>
          <div className="pbs">
            {s.opts.map(o => <button key={o.u} className={'pb' + (o.ok ? '' : ' no')} onClick={() => g.train(o.u)}><i>{o.ic}</i>{o.n}<small>💰 {o.cost}</small></button>)}
            {s.q.length > 0 && <div className="q">{s.q.map((x, i) => <span key={i} className={i === 0 ? 'cur' : ''} style={{ '--p': Math.round(x.p * 100) + '%' } as CSSProperties} title="اضغط للإلغاء" onClick={() => g.cancelQ(i)}>{x.ic}</span>)}</div>}
          </div>
        </>)}
      </div>
      {h.lost && !dismiss && (
        <div className="modal" style={{ background: 'rgba(0,0,0,.7)' }}>
          <div className="big">💀</div><h2 className="logo">تم تدمير مقرك</h2>
          <div className="row"><button className="btn" onClick={() => setDismiss(true)}>👁 متابعة المشاهدة</button></div>
        </div>
      )}
    </div>
  );
}

export function GameScreen({ params, onEnd, onQuit }: { params: StartParams; onEnd: (e: EndInfo) => void; onQuit: () => void }) {
  const gl = useRef<HTMLCanvasElement>(null), ov = useRef<HTMLCanvasElement>(null), touch = useRef<HTMLDivElement>(null);
  const gref = useRef<Game | null>(null); const [h, setH] = useState<HudState | null>(null); const [pause, setPause] = useState(false); const [, force] = useState(0);
  const endRef = useRef(onEnd); endRef.current = onEnd;
  useEffect(() => {
    const g = new Game({ cfg: params.cfg, role: params.role, gl: gl.current!, ov: ov.current!, touch: touch.current!, links: params.links, link: params.link, onEnd: e => endRef.current(e) });
    gref.current = g; setH(g.hud()); const iv = setInterval(() => setH(g.hud()), 140);
    return () => { clearInterval(iv); g.destroy(); gref.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const g = gref.current;
  const setP = (b: boolean) => { setPause(b); if (gref.current) gref.current.paused = b; };
  return (
    <>
      <canvas ref={gl} className="fullc" />
      <canvas ref={ov} id="ov" className="fullc" />
      <div ref={touch} id="touch" />
      {g && h && <Hud g={g} h={h} onPause={() => setP(true)} />}
      {pause && (
        <div className="scr" style={{ zIndex: 40 }}><div className="wrap" style={{ maxWidth: 420 }}>
          <h2 className="logo" style={{ fontSize: 26 }}>⏸ إيقاف مؤقت</h2>
          {params.role !== 'solo' && <p className="sub">اللعبة الجماعية تستمر في الخلفية.</p>}
          <div className="row" style={{ flexDirection: 'column', alignItems: 'stretch' }}>
            <button className="btn" onClick={() => setP(false)}>▶ متابعة</button>
            <button className="btn gray" onClick={() => { S.sound = !S.sound; saveS(); force(x => x + 1); }}>{S.sound ? '🔊 الصوت: يعمل' : '🔇 الصوت: متوقف'}</button>
            <button className="btn red" onClick={onQuit}>🚪 خروج للقائمة</button>
          </div>
        </div></div>
      )}
    </>
  );
}
