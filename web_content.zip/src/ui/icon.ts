import { BLOCKS } from "../game/world";
import { spriteURL } from "../game/sprites";
import { tileIcon } from "../game/textures";

/** Resolves a hotbar / store item id to its pixel-art icon. */
export function itemIcon(id: string): string {
  if (id.startsWith("block:")) {
    const n = Number(id.split(":")[1]);
    return tileIcon(BLOCKS[n]?.side ?? 3);
  }
  return spriteURL(id);
}

export function itemName(id: string): string {
  if (id.startsWith("block:")) {
    const n = Number(id.split(":")[1]);
    return BLOCKS[n]?.name ?? "Block";
  }
  return (
    {
      sword: "Diamond Sword",
      rifle: "Assault Rifle",
      bazooka: "Bazooka",
      armour: "Iron Armour",
    }[id] ?? id
  );
}
