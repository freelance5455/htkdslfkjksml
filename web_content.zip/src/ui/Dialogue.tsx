import { useMemo } from "react";
import { getDialogue } from "@/data/dialogues";
import { getLocation } from "@/data/locations";
import { fillNames } from "@/game/engine";
import { useGame } from "@/game/store";
import { getItemDef } from "@/data/fragments";
import { Panel, StarButton } from "./chrome";

export function DialogueOverlay() {
  const dialogueId = useGame((s) => s.dialogueId);
  const close = useGame((s) => s.closeModal);
  const names = useGame((s) => s.names);
  const locationId = useGame((s) => s.locationId);
  const flags = useGame((s) => s.flags);
  const addItem = useGame((s) => s.addItem);
  const setFlag = useGame((s) => s.setFlag);
  const choose = useGame((s) => s.choose);
  const pending = useGame((s) => s.pendingChoice);
  const overlay = useGame((s) => s.overlay);

  const content = useMemo(() => {
    if (!dialogueId) return null;
    if (dialogueId.startsWith("ex:")) {
      const hsId = dialogueId.slice(3);
      const loc = getLocation(locationId);
      const hs = loc?.hotspots.find((h) => h.id === hsId);
      if (!hs) return null;
      if (hs.action.type === "examine") {
        return {
          speaker: names.player,
          lines: [hs.action.text, hs.action.lohen].filter(Boolean) as string[],
        };
      }
      if (hs.action.type === "pickup") {
        const item = getItemDef(hs.action.itemId);
        return {
          speaker: "",
          lines: [hs.action.text, item ? item.name : "", hs.action.lohen].filter(Boolean) as string[],
        };
      }
      if (hs.action.type === "use") {
        return { speaker: "", lines: [hs.action.successText] };
      }
    }
    if (dialogueId.startsWith("choice:")) {
      const opt = pending?.options.find((o) => dialogueId.endsWith(o.id));
      return { speaker: "", lines: [opt?.text ?? "Le chemin se fend."] };
    }
    const d = getDialogue(dialogueId);
    if (!d) return null;
    return { speaker: d.npc, lines: d.lines.map((l) => l.text), def: d };
  }, [dialogueId, locationId, names.player, pending]);

  if (overlay === "choice" && pending) {
    return (
      <div className="absolute inset-x-0 bottom-0 z-30 p-4 pb-[max(1rem,env(safe-area-inset-bottom))]">
        <Panel className="mx-auto max-w-md p-4">
          <p className="font-display text-lg text-lumen">{fillNames(pending.prompt, names)}</p>
          <div className="mt-4 flex flex-col gap-2">
            {pending.options.map((o) => (
              <StarButton key={o.id} onClick={() => choose(o.id)}>
                {fillNames(o.label, names)}
              </StarButton>
            ))}
          </div>
        </Panel>
      </div>
    );
  }

  if (!content) return null;
  const d = "def" in content ? content.def : undefined;

  return (
    <div className="absolute inset-x-0 bottom-0 z-30 p-4 pb-[max(1rem,env(safe-area-inset-bottom))]">
      <Panel className="mx-auto max-w-md p-4">
        {content.speaker ? (
          <p className="mb-2 text-[0.65rem] uppercase tracking-[0.22em] text-fog">{fillNames(content.speaker, names)}</p>
        ) : null}
        {content.lines.map((line, i) => (
          <p key={i} className="mb-2 font-display text-[1.15rem] leading-relaxed text-lumen">
            {fillNames(line, names)}
          </p>
        ))}
        {d?.choices && !flags[d.choices[0]?.flag ?? ""] ? (
          <div className="mt-3 flex flex-col gap-2">
            {d.choices.map((c) => (
              <StarButton
                key={c.id}
                onClick={() => {
                  setFlag(c.flag);
                  close();
                }}
              >
                {c.label}
              </StarButton>
            ))}
          </div>
        ) : (
          <StarButton
            variant="solid"
            className="mt-3 w-full"
            onClick={() => {
              if (d?.setFlag) setFlag(d.setFlag);
              if (d?.giveItem) addItem(d.giveItem);
              close();
            }}
          >
            Continuer
          </StarButton>
        )}
      </Panel>
    </div>
  );
}
