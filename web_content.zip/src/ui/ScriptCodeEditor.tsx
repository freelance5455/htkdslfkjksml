import React, { useState } from 'react';
import { FileCode, Play, Save, Plus, Check } from 'lucide-react';
import { SAMPLE_SCRIPTS } from '../scripting/scriptEngine';
import { audioSystem } from '../audio/audioManager';

interface ScriptCodeEditorProps {
  onRunScript: (scriptName: string, code: string) => void;
}

export const ScriptCodeEditor: React.FC<ScriptCodeEditorProps> = ({ onRunScript }) => {
  const [selectedScript, setSelectedScript] = useState<string>('CharacterController.ts');
  const [scripts, setScripts] = useState<Record<string, string>>({ ...SAMPLE_SCRIPTS });
  const [hasSaved, setHasSaved] = useState(false);

  const currentCode = scripts[selectedScript] || '';

  const handleCodeChange = (newCode: string) => {
    setScripts((prev) => ({ ...prev, [selectedScript]: newCode }));
    setHasSaved(false);
  };

  const handleSave = () => {
    setHasSaved(true);
    audioSystem.playSound('synth_bell', { pitch: 1.4, volume: 0.3 });
    setTimeout(() => setHasSaved(false), 2000);
  };

  const handleRun = () => {
    onRunScript(selectedScript, currentCode);
    audioSystem.playSound('synth_laser', { pitch: 1.2, volume: 0.4 });
  };

  const handleCreateScript = () => {
    const name = `Script_${Object.keys(scripts).length + 1}.ts`;
    const defaultTemplate = `// DAVIENGINE Script: ${name}\nexport class CustomBehavior {\n  public onStart() {\n    console.log("Initialized ${name}");\n  }\n  public onUpdate(delta: number) {\n    // Frame update logic\n  }\n}\n`;
    setScripts((prev) => ({ ...prev, [name]: defaultTemplate }));
    setSelectedScript(name);
    audioSystem.playSound('click');
  };

  return (
    <div className="flex flex-col h-full bg-[#0d1117] text-slate-300 text-xs select-none">
      {/* Top Bar */}
      <div className="h-8 bg-[#161b22] border-b border-[#21262d] flex items-center justify-between px-3 shrink-0">
        {/* Script Tabs */}
        <div className="flex items-center space-x-1 overflow-x-auto scrollbar-none">
          {Object.keys(scripts).map((name) => (
            <button
              key={name}
              onClick={() => setSelectedScript(name)}
              className={`flex items-center space-x-1 px-2.5 py-1 rounded-t text-[11px] font-mono transition-colors border-t border-x ${
                selectedScript === name
                  ? 'bg-[#0d1117] border-[#30363d] text-cyan-300 font-bold'
                  : 'bg-[#161b22] border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileCode className="w-3 h-3 text-cyan-400" />
              <span>{name}</span>
            </button>
          ))}
          <button
            onClick={handleCreateScript}
            className="p-1 text-slate-400 hover:text-white rounded hover:bg-[#21262d]"
            title="Create New Script"
          >
            <Plus className="w-3 h-3" />
          </button>
        </div>

        {/* Actions */}
        <div className="flex items-center space-x-2">
          <button
            onClick={handleSave}
            className="flex items-center space-x-1 px-2 py-0.5 rounded bg-[#21262d] hover:bg-[#30363d] text-slate-200 text-[11px]"
          >
            {hasSaved ? <Check className="w-3 h-3 text-emerald-400" /> : <Save className="w-3 h-3 text-amber-400" />}
            <span>{hasSaved ? 'Saved' : 'Save'}</span>
          </button>

          <button
            onClick={handleRun}
            className="flex items-center space-x-1 px-2.5 py-0.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-[11px] shadow-sm transition-colors"
          >
            <Play className="w-3 h-3 fill-current" />
            <span>Compile & Test</span>
          </button>
        </div>
      </div>

      {/* Code Editor Body with Line Numbers */}
      <div className="flex-1 flex overflow-hidden">
        {/* Line Numbers */}
        <div className="w-10 bg-[#0d1117] border-r border-[#21262d] py-2 text-right pr-2 text-slate-600 font-mono text-[11px] select-none">
          {currentCode.split('\n').map((_, i) => (
            <div key={i}>{i + 1}</div>
          ))}
        </div>

        {/* Text Area */}
        <textarea
          value={currentCode}
          onChange={(e) => handleCodeChange(e.target.value)}
          spellCheck={false}
          className="flex-1 bg-[#090d14] text-slate-200 font-mono text-[11px] p-2 leading-relaxed focus:outline-none resize-none"
        />
      </div>
    </div>
  );
};
