import React, { useState } from 'react';
import { Grid, Eye, Cpu, RefreshCw, Zap } from 'lucide-react';
import { terrainStreamingSystem } from '../terrain/terrainManager';
import { audioSystem } from '../audio/audioManager';

export const WorldStreamingPanel: React.FC = () => {
  const [cells, setCells] = useState(terrainStreamingSystem.getCells());
  const [streamingRadius, setStreamingRadius] = useState(45);
  const [targetPos, setTargetPos] = useState({ x: 0, z: 0 });

  const handleUpdateStreaming = (x: number, z: number) => {
    setTargetPos({ x, z });
    terrainStreamingSystem.updateStreaming({ x, y: 0, z }, streamingRadius);
    setCells([...terrainStreamingSystem.getCells()]);
    audioSystem.playSound('click', { pitch: 1.2, volume: 0.2 });
  };

  const loadedCount = cells.filter((c) => c.status === 'loaded').length;
  const loadingCount = cells.filter((c) => c.status === 'loading').length;
  const unloadedCount = cells.filter((c) => c.status === 'unloaded').length;

  return (
    <div className="flex flex-col h-full bg-[#11161f] text-slate-300 text-xs p-3 space-y-3 overflow-y-auto select-none">
      <div className="flex items-center justify-between border-b border-[#21262d] pb-2">
        <div className="flex items-center space-x-2">
          <Grid className="w-4 h-4 text-cyan-400" />
          <span className="font-bold text-slate-100 text-xs tracking-wide">WORLD STREAMING</span>
        </div>
        <span className="text-[10px] text-emerald-400 bg-emerald-950/80 px-1.5 py-0.5 rounded border border-emerald-800 font-mono">
          Level of Detail 0
        </span>
      </div>

      <p className="text-[11px] text-slate-400 leading-relaxed">
        DAVIENGINE partitions open-world spaces into streaming cells (A1–D4), dynamically paging assets
        based on camera / player proximity to maximize framerate on both desktop and mobile devices.
      </p>

      {/* Grid Matrix Visualizer (A1 to D4) */}
      <div className="bg-[#0d1117] p-3 rounded border border-[#21262d] flex flex-col items-center">
        <div className="text-[10px] font-mono text-cyan-400 mb-2">STREAMING CELL SECTOR MAP</div>
        <div className="grid grid-cols-4 gap-1.5 w-full max-w-[280px]">
          {cells.map((cell) => {
            let statusBg = 'bg-[#161b22] border-[#30363d] text-slate-500';
            if (cell.status === 'loaded') {
              statusBg = 'bg-cyan-950/90 border-cyan-500 text-cyan-200 shadow-sm shadow-cyan-900/30 font-bold';
            } else if (cell.status === 'loading') {
              statusBg = 'bg-amber-950/80 border-amber-500 text-amber-300 animate-pulse';
            }

            return (
              <button
                key={cell.id}
                onClick={() => handleUpdateStreaming(cell.x, cell.z)}
                className={`h-12 rounded border flex flex-col items-center justify-center p-1 text-[10px] transition-all hover:scale-105 ${statusBg}`}
                title={`Sector ${cell.id}: (${cell.x}m, ${cell.z}m) - ${cell.status}`}
              >
                <span className="font-mono text-xs">{cell.id}</span>
                <span className="text-[8px] opacity-75">{cell.status}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Stats Breakdown */}
      <div className="grid grid-cols-3 gap-2 text-center text-[10px]">
        <div className="bg-[#161b22] p-2 rounded border border-[#21262d]">
          <div className="text-cyan-400 font-bold text-sm">{loadedCount}</div>
          <div className="text-slate-400">Loaded</div>
        </div>
        <div className="bg-[#161b22] p-2 rounded border border-[#21262d]">
          <div className="text-amber-400 font-bold text-sm">{loadingCount}</div>
          <div className="text-slate-400">Paging</div>
        </div>
        <div className="bg-[#161b22] p-2 rounded border border-[#21262d]">
          <div className="text-slate-500 font-bold text-sm">{unloadedCount}</div>
          <div className="text-slate-400">Culled</div>
        </div>
      </div>

      {/* Streaming Radius Config */}
      <div className="bg-[#161b22] p-2.5 rounded border border-[#21262d] space-y-2">
        <div className="flex justify-between text-[10px]">
          <span className="text-slate-300 font-semibold">Streaming Radius</span>
          <span className="font-mono text-cyan-400">{streamingRadius}m</span>
        </div>
        <input
          type="range"
          min="20"
          max="80"
          step="5"
          value={streamingRadius}
          onChange={(e) => {
            const rad = parseInt(e.target.value);
            setStreamingRadius(rad);
            terrainStreamingSystem.updateStreaming({ x: targetPos.x, y: 0, z: targetPos.z }, rad);
            setCells([...terrainStreamingSystem.getCells()]);
          }}
          className="w-full accent-cyan-500 cursor-pointer"
        />
      </div>
    </div>
  );
};
