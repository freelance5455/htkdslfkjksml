export type SparrowDeedId =
  | 'croissant_heist'
  | 'coffee_bowling'
  | 'sleepy_sugar'
  | 'pigeon_scatter'
  | 'picnic_raid'
  | 'busker_coins'
  | 'canal_prank'
  | 'painter_muse'
  | 'apple_avalanche'
  | 'music_box'
  | 'belfry_bell'
  | 'sky_sanctuary';

export interface SparrowDeedDef {
  id: SparrowDeedId;
  label: string;
}

export const SPARROW_DEEDS: readonly SparrowDeedDef[] = [
  {
    id: 'croissant_heist',
    label: 'Snatch a warm croissant from the boulangerie',
  },
  {
    id: 'coffee_bowling',
    label: 'Bowl a giant to-go coffee cup off a bistro table',
  },
  {
    id: 'sleepy_sugar',
    label: "Drop a sugar cube into the drowsy commuter's mug",
  },
  {
    id: 'pigeon_scatter',
    label: 'Swoop or chirp to scatter the fountain pigeon flock',
  },
  {
    id: 'picnic_raid',
    label: 'Peck open the wicker picnic basket in the gazebo',
  },
  {
    id: 'busker_coins',
    label: "Toss 3 shiny coins into the busker's guitar case",
  },
  {
    id: 'canal_prank',
    label: 'Ring a vintage bicycle bell or topple a gelato cone',
  },
  {
    id: 'painter_muse',
    label: 'Bring glasses & 2 blossoms to the balcony painter',
  },
  {
    id: 'apple_avalanche',
    label: "Topple the fruit vendor's stacked apple pyramid",
  },
  {
    id: 'music_box',
    label: 'Wind the bookshop music box with the brass key',
  },
  {
    id: 'belfry_bell',
    label: 'Peck the great bronze bell atop the clocktower',
  },
  {
    id: 'sky_sanctuary',
    label: 'Weave 4 treasures into the Clocktower Sky Nest',
  },
];

interface CachedDeedRow {
  li: HTMLLIElement;
  check: HTMLSpanElement;
}

/**
 * Compact French-postcard Mischief & Deeds HUD.
 * Hidden during the indoor tutorial so onboarding shows only key prompts.
 * Built with safe DOM APIs (createElement, textContent; no innerHTML).
 * Toggled with the `J` key or an accessible `<button>` (`Tab` stays free for focus navigation).
 */
export class SparrowJournalHUD {
  private readonly root: HTMLDivElement;
  private readonly pillBtn: HTMLButtonElement;
  private readonly seedCountEl: HTMLSpanElement;
  private readonly deedCountEl: HTMLSpanElement;
  private readonly keyCapEl: HTMLElement;
  private readonly campaignBtn: HTMLButtonElement;
  private readonly dayLabelEl: HTMLSpanElement;
  private readonly heartsEl: HTMLSpanElement;
  private readonly rescueLabelEl: HTMLSpanElement;
  private readonly campaignKeyCapEl: HTMLElement;
  private readonly timeBtn: HTMLButtonElement;
  private readonly timeIconEl: HTMLSpanElement;
  private readonly timeLabelEl: HTMLSpanElement;
  private readonly timeKeyCapEl: HTMLElement;
  private readonly rainBtn: HTMLButtonElement;
  private readonly rainIconEl: HTMLSpanElement;
  private readonly rainLabelEl: HTMLSpanElement;
  private readonly rainKeyCapEl: HTMLElement;
  private readonly threatBannerEl: HTMLDivElement;
  private readonly cardEl: HTMLDivElement;
  private readonly toastHost: HTMLDivElement;

  private readonly rowElements = new Map<SparrowDeedId, CachedDeedRow>();
  private readonly completed = new Set<SparrowDeedId>();
  private expanded = false;
  private visible = false;
  private mobileMode = false;
  public onToggleMute?: () => boolean;
  public onCycleTimeOfDay?: () => void;
  public onCycleWeather?: () => void;
  public onAdvanceCampaignDay?: () => void;

  constructor(parent: HTMLElement) {
    this.root = document.createElement('div');
    this.root.className = 'journal-hud';
    this.root.setAttribute('aria-hidden', 'false');

    const topBar = document.createElement('div');
    topBar.className = 'journal-top-bar';

    // Top-left compact interactive button pill (hidden until indoor tutorial completes)
    this.pillBtn = document.createElement('button');
    this.pillBtn.type = 'button';
    this.pillBtn.className = 'journal-pill is-hidden';
    this.pillBtn.setAttribute('aria-expanded', 'false');
    this.pillBtn.setAttribute('aria-label', 'Toggle Deeds List (Key J)');

    const seedWrap = document.createElement('span');
    seedWrap.className = 'journal-stat';
    const seedDot = document.createElement('span');
    seedDot.className = 'journal-seed-dot';
    seedDot.setAttribute('aria-hidden', 'true');
    this.seedCountEl = document.createElement('span');
    this.seedCountEl.textContent = '0';
    seedWrap.appendChild(seedDot);
    seedWrap.appendChild(this.seedCountEl);

    const divider = document.createElement('span');
    divider.className = 'journal-sep';
    divider.setAttribute('aria-hidden', 'true');
    divider.textContent = '·';

    this.deedCountEl = document.createElement('span');
    this.deedCountEl.className = 'journal-stat';
    this.deedCountEl.textContent = `0 / ${SPARROW_DEEDS.length}`;

    this.keyCapEl = document.createElement('kbd');
    this.keyCapEl.className = 'journal-tab-key';
    this.keyCapEl.textContent = 'J';

    this.pillBtn.appendChild(seedWrap);
    this.pillBtn.appendChild(divider);
    this.pillBtn.appendChild(this.deedCountEl);
    this.pillBtn.appendChild(this.keyCapEl);

    let lastPillTouchToggleMs = 0;
    this.pillBtn.addEventListener(
      'touchend',
      (e) => {
        e.preventDefault();
        e.stopPropagation();
        lastPillTouchToggleMs = performance.now();
        this.setExpanded(!this.expanded);
      },
      { passive: false }
    );
    this.pillBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (performance.now() - lastPillTouchToggleMs < 450) return;
      this.setExpanded(!this.expanded);
    });

    // 7-Day Survival & Bird Rescue Campaign Button (`Key N`)
    this.campaignBtn = document.createElement('button');
    this.campaignBtn.type = 'button';
    this.campaignBtn.className = 'journal-pill journal-campaign-btn';
    this.campaignBtn.setAttribute('aria-label', '7-Day Survival & Rescue Status — Advance Day (Key N)');

    this.dayLabelEl = document.createElement('span');
    this.dayLabelEl.className = 'journal-stat journal-tabular journal-day-badge';
    this.dayLabelEl.textContent = 'Day 1/7';

    const campSep1 = document.createElement('span');
    campSep1.className = 'journal-sep';
    campSep1.setAttribute('aria-hidden', 'true');
    campSep1.textContent = '·';

    this.heartsEl = document.createElement('span');
    this.heartsEl.className = 'journal-hearts';
    this.heartsEl.textContent = '♥♥♥';

    const campSep2 = document.createElement('span');
    campSep2.className = 'journal-sep';
    campSep2.setAttribute('aria-hidden', 'true');
    campSep2.textContent = '·';

    this.rescueLabelEl = document.createElement('span');
    this.rescueLabelEl.className = 'journal-stat journal-tabular journal-rescue-stat';
    this.rescueLabelEl.textContent = '🐦 0/2';

    this.campaignKeyCapEl = document.createElement('kbd');
    this.campaignKeyCapEl.className = 'journal-tab-key';
    this.campaignKeyCapEl.textContent = 'N';

    this.campaignBtn.appendChild(this.dayLabelEl);
    this.campaignBtn.appendChild(campSep1);
    this.campaignBtn.appendChild(this.heartsEl);
    this.campaignBtn.appendChild(campSep2);
    this.campaignBtn.appendChild(this.rescueLabelEl);
    this.campaignBtn.appendChild(this.campaignKeyCapEl);

    let lastCampaignTouchMs = 0;
    this.campaignBtn.addEventListener(
      'touchend',
      (e) => {
        e.preventDefault();
        e.stopPropagation();
        lastCampaignTouchMs = performance.now();
        this.onAdvanceCampaignDay?.();
      },
      { passive: false }
    );
    this.campaignBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (performance.now() - lastCampaignTouchMs < 450) return;
      this.onAdvanceCampaignDay?.();
    });

    // Day/Night Cycle Interactive Button (`Key T`)
    this.timeBtn = document.createElement('button');
    this.timeBtn.type = 'button';
    this.timeBtn.className = 'journal-pill journal-atmo-btn';
    this.timeBtn.setAttribute('aria-label', 'Cycle Time of Day (Key T)');

    this.timeIconEl = document.createElement('span');
    this.timeIconEl.className = 'journal-atmo-icon';
    this.timeIconEl.setAttribute('aria-hidden', 'true');
    this.timeIconEl.textContent = '☀';

    this.timeLabelEl = document.createElement('span');
    this.timeLabelEl.className = 'journal-stat journal-tabular';
    this.timeLabelEl.textContent = 'Morning · 09:10';

    this.timeKeyCapEl = document.createElement('kbd');
    this.timeKeyCapEl.className = 'journal-tab-key';
    this.timeKeyCapEl.textContent = 'T';

    this.timeBtn.appendChild(this.timeIconEl);
    this.timeBtn.appendChild(this.timeLabelEl);
    this.timeBtn.appendChild(this.timeKeyCapEl);

    let lastTimeTouchMs = 0;
    this.timeBtn.addEventListener(
      'touchend',
      (e) => {
        e.preventDefault();
        e.stopPropagation();
        lastTimeTouchMs = performance.now();
        this.onCycleTimeOfDay?.();
      },
      { passive: false }
    );
    this.timeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (performance.now() - lastTimeTouchMs < 450) return;
      this.onCycleTimeOfDay?.();
    });

    // Rain Weather Interactive Button (`Key R`)
    this.rainBtn = document.createElement('button');
    this.rainBtn.type = 'button';
    this.rainBtn.className = 'journal-pill journal-atmo-btn';
    this.rainBtn.setAttribute('aria-label', 'Toggle Rain Weather (Key R)');

    this.rainIconEl = document.createElement('span');
    this.rainIconEl.className = 'journal-atmo-icon';
    this.rainIconEl.setAttribute('aria-hidden', 'true');
    this.rainIconEl.textContent = '☂';

    this.rainLabelEl = document.createElement('span');
    this.rainLabelEl.className = 'journal-stat';
    this.rainLabelEl.textContent = 'Clear';

    this.rainKeyCapEl = document.createElement('kbd');
    this.rainKeyCapEl.className = 'journal-tab-key';
    this.rainKeyCapEl.textContent = 'R';

    this.rainBtn.appendChild(this.rainIconEl);
    this.rainBtn.appendChild(this.rainLabelEl);
    this.rainBtn.appendChild(this.rainKeyCapEl);

    let lastRainTouchMs = 0;
    this.rainBtn.addEventListener(
      'touchend',
      (e) => {
        e.preventDefault();
        e.stopPropagation();
        lastRainTouchMs = performance.now();
        this.onCycleWeather?.();
      },
      { passive: false }
    );
    this.rainBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (performance.now() - lastRainTouchMs < 450) return;
      this.onCycleWeather?.();
    });

    topBar.appendChild(this.pillBtn);
    topBar.appendChild(this.campaignBtn);
    topBar.appendChild(this.timeBtn);
    topBar.appendChild(this.rainBtn);

    // Contextual Predator & Trap Warning Banner
    this.threatBannerEl = document.createElement('div');
    this.threatBannerEl.className = 'journal-threat-banner is-hidden';
    this.threatBannerEl.setAttribute('aria-live', 'assertive');

    // Expandable Postcard Checklist (one row per deed)
    this.cardEl = document.createElement('div');
    this.cardEl.className = 'journal-card';
    this.cardEl.setAttribute('aria-hidden', 'true');
    this.cardEl.addEventListener('touchstart', (e) => e.stopPropagation(), { passive: true });
    this.cardEl.addEventListener('click', (e) => e.stopPropagation());

    const list = document.createElement('ul');
    list.className = 'journal-list';

    for (const deed of SPARROW_DEEDS) {
      const li = document.createElement('li');
      li.className = 'journal-item';

      const check = document.createElement('span');
      check.className = 'journal-check';
      check.setAttribute('aria-hidden', 'true');
      check.textContent = '';

      const text = document.createElement('span');
      text.className = 'journal-label';
      text.textContent = deed.label;

      li.appendChild(check);
      li.appendChild(text);
      list.appendChild(li);
      this.rowElements.set(deed.id, { li, check });
    }

    this.cardEl.appendChild(list);
    this.root.appendChild(topBar);
    this.root.appendChild(this.threatBannerEl);
    this.root.appendChild(this.cardEl);
    parent.appendChild(this.root);

    // Celebratory completion toast container (top-right, screen-reader polite live region)
    this.toastHost = document.createElement('div');
    this.toastHost.className = 'journal-toast-host';
    this.toastHost.setAttribute('role', 'status');
    this.toastHost.setAttribute('aria-live', 'polite');
    parent.appendChild(this.toastHost);

    window.addEventListener('pointerdown', (e) => {
      if (!this.expanded) return;
      if (e.target instanceof Element && e.target.closest('.journal-hud')) return;
      this.setExpanded(false);
    });

    window.addEventListener('keydown', (e) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      if (e.code === 'KeyJ' && this.visible) {
        e.preventDefault();
        this.setExpanded(!this.expanded);
      } else if (e.code === 'KeyN') {
        e.preventDefault();
        this.onAdvanceCampaignDay?.();
      } else if (e.code === 'KeyT') {
        e.preventDefault();
        this.onCycleTimeOfDay?.();
      } else if (e.code === 'KeyR') {
        e.preventDefault();
        this.onCycleWeather?.();
      } else if (e.code === 'KeyM') {
        e.preventDefault();
        this.onToggleMute?.();
      }
    });
  }

  public setMobileMode(isMobile: boolean): void {
    this.mobileMode = isMobile;
    this.root.classList.toggle('is-mobile', isMobile);
    this.keyCapEl.style.display = isMobile ? 'none' : '';
    this.campaignKeyCapEl.style.display = isMobile ? 'none' : '';
    this.timeKeyCapEl.style.display = isMobile ? 'none' : '';
    this.rainKeyCapEl.style.display = isMobile ? 'none' : '';
    this.pillBtn.setAttribute(
      'aria-label',
      isMobile ? 'Toggle Deeds List' : 'Toggle Deeds List (Key J)'
    );
    this.campaignBtn.setAttribute(
      'aria-label',
      isMobile ? '7-Day Campaign — Next Day' : '7-Day Campaign — Next Day (Key N)'
    );
    this.timeBtn.setAttribute(
      'aria-label',
      isMobile ? 'Cycle Time of Day' : 'Cycle Time of Day (Key T)'
    );
    this.rainBtn.setAttribute(
      'aria-label',
      isMobile ? 'Toggle Rain Weather' : 'Toggle Rain Weather (Key R)'
    );
  }

  public isMobileMode(): boolean {
    return this.mobileMode;
  }

  public setCampaignStatus(
    day: number,
    maxDays: number,
    hearts: number,
    maxHearts: number,
    rescuedToday: number,
    targetToday: number,
    campaignWon: boolean
  ): void {
    const nextDayStr = campaignWon ? `7/7 Victory♛` : `Day ${day}/${maxDays}`;
    if (this.dayLabelEl.textContent !== nextDayStr) {
      this.dayLabelEl.textContent = nextDayStr;
    }

    const filled = Math.max(0, Math.min(maxHearts, hearts));
    const heartStr = '♥'.repeat(filled) + '♡'.repeat(Math.max(0, maxHearts - filled));
    if (this.heartsEl.textContent !== heartStr) {
      this.heartsEl.textContent = heartStr;
    }

    const rescueStr = `🐦 ${rescuedToday}/${targetToday}`;
    if (this.rescueLabelEl.textContent !== rescueStr) {
      this.rescueLabelEl.textContent = rescueStr;
    }

    this.campaignBtn.classList.toggle('is-victory', campaignWon);
  }

  public setThreatAlert(
    threatType: 'none' | 'cat' | 'eagle' | 'trap' | 'trapper',
    message: string
  ): void {
    if (threatType === 'none' || !message) {
      this.threatBannerEl.classList.add('is-hidden');
      return;
    }
    this.threatBannerEl.classList.remove('is-hidden');
    this.threatBannerEl.classList.toggle('is-rescue-hint', threatType === 'trap');
    if (this.threatBannerEl.textContent !== message) {
      this.threatBannerEl.textContent = message;
    }
  }

  public setAtmosphereDisplay(
    phaseLabel: string,
    clockStr: string,
    iconChar: string,
    weatherLabel: string,
    isRaining: boolean
  ): void {
    const nextTimeText = this.mobileMode ? phaseLabel : `${phaseLabel} · ${clockStr}`;
    if (this.timeLabelEl.textContent !== nextTimeText) {
      this.timeLabelEl.textContent = nextTimeText;
    }
    if (this.timeIconEl.textContent !== iconChar) {
      this.timeIconEl.textContent = iconChar;
    }
    if (this.rainLabelEl.textContent !== weatherLabel) {
      this.rainLabelEl.textContent = weatherLabel;
    }
    this.rainBtn.classList.toggle('is-active-weather', isRaining);
  }

  public setVisible(visible: boolean): void {
    if (this.visible === visible) return;
    this.visible = visible;
    this.pillBtn.classList.toggle('is-hidden', !visible);
    if (!visible && this.expanded) {
      this.setExpanded(false);
    }
  }

  public setExpanded(expanded: boolean): void {
    this.expanded = expanded;
    this.root.classList.toggle('is-expanded', expanded);
    this.pillBtn.setAttribute('aria-expanded', expanded ? 'true' : 'false');
    this.cardEl.setAttribute('aria-hidden', expanded ? 'false' : 'true');
  }

  public setSeedsCount(count: number): void {
    this.seedCountEl.textContent = String(count);
  }

  public getCompletedCount(): number {
    return this.completed.size;
  }

  public getTotalCount(): number {
    return SPARROW_DEEDS.length;
  }

  public isDeedCompleted(id: SparrowDeedId): boolean {
    return this.completed.has(id);
  }

  public completeDeed(id: SparrowDeedId): boolean {
    if (this.completed.has(id)) return false;
    this.completed.add(id);

    const row = this.rowElements.get(id);
    if (row) {
      row.li.classList.add('is-done');
      row.check.textContent = '✓';
    }

    this.deedCountEl.textContent = `${this.completed.size} / ${SPARROW_DEEDS.length}`;

    const def = SPARROW_DEEDS.find((d) => d.id === id);
    if (def && this.visible) {
      this.spawnStampToast(def);
    }
    return true;
  }

  public spawnCoronationToast(): void {
    this.spawnCampaignToast('♛', 'Crown of the Neighborhood!', 'royal');
  }

  public spawnCampaignToast(
    stampIcon: string,
    message: string,
    tone: 'rescue' | 'danger' | 'day' | 'royal' = 'day'
  ): void {
    const toast = document.createElement('div');
    toast.className = `journal-toast is-${tone}`;

    const stamp = document.createElement('span');
    stamp.className = 'journal-toast-stamp';
    stamp.setAttribute('aria-hidden', 'true');
    stamp.textContent = stampIcon;

    const title = document.createElement('span');
    title.className = 'journal-toast-label';
    title.textContent = message;

    toast.appendChild(stamp);
    toast.appendChild(title);
    this.toastHost.appendChild(toast);

    window.setTimeout(() => {
      toast.classList.add('is-leaving');
      window.setTimeout(() => {
        toast.remove();
      }, 420);
    }, 3600);
  }

  private spawnStampToast(def: SparrowDeedDef): void {
    const toast = document.createElement('div');
    toast.className = 'journal-toast';

    const stamp = document.createElement('span');
    stamp.className = 'journal-toast-stamp';
    stamp.setAttribute('aria-hidden', 'true');
    stamp.textContent = '✓';

    const title = document.createElement('span');
    title.className = 'journal-toast-label';
    title.textContent = def.label;

    toast.appendChild(stamp);
    toast.appendChild(title);
    this.toastHost.appendChild(toast);

    window.setTimeout(() => {
      toast.classList.add('is-leaving');
      window.setTimeout(() => {
        toast.remove();
      }, 420);
    }, 3100);
  }
}
