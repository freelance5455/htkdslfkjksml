import { useEffect, useRef } from 'react';
import { input, press, type Btn } from '../game/input';

function Joystick() {
  const zoneRef = useRef<HTMLDivElement>(null);
  const baseRef = useRef<HTMLDivElement>(null);
  const knobRef = useRef<HTMLDivElement>(null);
  const st = useRef({ id: -1, cx: 0, cy: 0, size: 120 });

  const sizeNow = () => Math.max(96, Math.min(150, window.innerHeight * 0.3));

  const place = (x: number, y: number) => {
    const b = baseRef.current;
    if (!b) return;
    const s = st.current.size;
    b.style.width = b.style.height = `${s}px`;
    b.style.left = `${x}px`;
    b.style.top = `${y}px`;
    st.current.cx = x;
    st.current.cy = y;
  };
  const home = () => {
    const z = zoneRef.current;
    if (!z) return;
    st.current.size = sizeNow();
    const r = z.getBoundingClientRect();
    const s = st.current.size;
    place(Math.min(r.width * 0.5, s * 0.5 + 34), r.height - s * 0.5 - 22);
    if (knobRef.current) knobRef.current.style.transform = 'translate(0,0)';
  };

  useEffect(() => {
    home();
    window.addEventListener('resize', home);
    return () => window.removeEventListener('resize', home);
  }, []);

  const update = (e: React.PointerEvent) => {
    const z = zoneRef.current!;
    const r = z.getBoundingClientRect();
    const s = st.current;
    const R = s.size * 0.5;
    let dx = e.clientX - r.left - s.cx;
    let dy = e.clientY - r.top - s.cy;
    const d = Math.hypot(dx, dy);
    if (d > R) { dx = (dx / d) * R; dy = (dy / d) * R; }
    // floating origin: drag base along if finger goes far
    if (d > R * 1.6) {
      const k = (d - R * 1.6) / d;
      place(s.cx + (e.clientX - r.left - s.cx) * k, s.cy + (e.clientY - r.top - s.cy) * k);
    }
    let jx = dx / R, jy = dy / R;
    const m = Math.hypot(jx, jy);
    if (m < 0.1) { jx = jy = 0; }
    input.jx = jx; input.jy = jy;
    if (knobRef.current) knobRef.current.style.transform = `translate(${dx * 0.9}px, ${dy * 0.9}px)`;
    baseRef.current?.classList.toggle('run', m > 0.88);
  };

  const down = (e: React.PointerEvent) => {
    if (st.current.id >= 0) return;
    e.preventDefault();
    st.current.id = e.pointerId;
    zoneRef.current!.setPointerCapture(e.pointerId);
    const r = zoneRef.current!.getBoundingClientRect();
    st.current.size = sizeNow();
    place(e.clientX - r.left, e.clientY - r.top);
    update(e);
  };
  const move = (e: React.PointerEvent) => {
    if (e.pointerId !== st.current.id) return;
    e.preventDefault();
    update(e);
  };
  const up = (e: React.PointerEvent) => {
    if (e.pointerId !== st.current.id) return;
    st.current.id = -1;
    input.jx = input.jy = 0;
    baseRef.current?.classList.remove('run');
    home();
  };

  return (
    <div
      ref={zoneRef}
      className="joy-zone"
      onPointerDown={down}
      onPointerMove={move}
      onPointerUp={up}
      onPointerCancel={up}
      onLostPointerCapture={up}
      onContextMenu={(e) => e.preventDefault()}
    >
      <div ref={baseRef} className="joy-base">
        <div ref={knobRef} className="joy-knob" />
      </div>
    </div>
  );
}

interface BtnDef {
  id: Btn | 'block';
  label: string;
  sub: string;
  x: number; y: number; d: number;
  bg: string;
}

// positions are in a 340 x 240 design box
const BTNS: BtnDef[] = [
  { id: 'punch', label: 'PUNCH', sub: 'LIGHT', x: 238, y: 182, d: 82, bg: 'radial-gradient(circle at 35% 30%, #ff6a5a, #b3121d 70%, #5a0a10)' },
  { id: 'kick', label: 'KICK', sub: 'LEG', x: 305, y: 118, d: 74, bg: 'radial-gradient(circle at 35% 30%, #6fb0ff, #1f56c4 70%, #0f2a66)' },
  { id: 'heavy', label: 'HEAVY', sub: 'POWER', x: 205, y: 92, d: 68, bg: 'radial-gradient(circle at 35% 30%, #ffa05a, #c4561a 70%, #5e2208)' },
  { id: 'block', label: 'BLOCK', sub: 'HOLD', x: 116, y: 196, d: 66, bg: 'radial-gradient(circle at 35% 30%, #c9d2dc, #5f6b79 70%, #2a313a)' },
  { id: 'dodge', label: 'DODGE', sub: 'EVADE', x: 100, y: 102, d: 60, bg: 'radial-gradient(circle at 35% 30%, #7af0b0, #1c9b60 70%, #0b4a2e)' },
  { id: 'special', label: 'SPECIAL', sub: 'METER', x: 296, y: 34, d: 62, bg: 'radial-gradient(circle at 35% 30%, #ffe27a, #d19412 70%, #6b4706)' },
];

function ActionButton({ def, dim, ready }: { def: BtnDef; dim: boolean; ready: boolean }) {
  const isBlock = def.id === 'block';
  const release = (e: React.PointerEvent) => {
    (e.currentTarget as HTMLElement).dataset.down = '0';
    if (isBlock) input.block = false;
  };
  return (
    <div
      className={`act-btn ${dim && def.id !== 'block' ? 'dim' : ''} ${ready && def.id === 'special' ? 'ready' : ''}`}
      data-down="0"
      style={{
        left: `${(def.x / 340) * 100}%`,
        top: `${(def.y / 240) * 100}%`,
        width: `${(def.d / 340) * 100}%`,
        aspectRatio: '1',
        background: def.bg,
      }}
      onPointerDown={(e) => {
        e.preventDefault();
        e.stopPropagation();
        (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
        (e.currentTarget as HTMLElement).dataset.down = '1';
        if (isBlock) input.block = true;
        else press(def.id as Btn);
      }}
      onPointerUp={release}
      onPointerCancel={release}
      onLostPointerCapture={release}
      onContextMenu={(e) => e.preventDefault()}
    >
      <span className="lbl">{def.label}</span>
      <span className="sub">{def.sub}</span>
    </div>
  );
}

export function Controls({ stamina, special }: { stamina: number; special: number }) {
  return (
    <div className="touch-layer">
      <Joystick />
      <div className="act-area">
        {BTNS.map((b) => (
          <ActionButton
            key={b.id}
            def={b}
            dim={b.id === 'special' ? special < 100 : b.id === 'dodge' ? stamina < 18 : false}
            ready={special >= 100}
          />
        ))}
      </div>
    </div>
  );
}
