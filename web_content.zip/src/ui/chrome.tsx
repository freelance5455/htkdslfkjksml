import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Panel({
  className,
  children,
  dim,
}: {
  className?: string;
  children: ReactNode;
  dim?: boolean;
}) {
  return (
    <div
      className={cn(
        "panel rounded-xl text-lumen shadow-[0_20px_60px_rgba(0,0,0,0.45)]",
        dim && "bg-void/80",
        className,
      )}
    >
      {children}
    </div>
  );
}

export function StarButton({
  className,
  children,
  variant = "ghost",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "ghost" | "solid" | "quiet" }) {
  return (
    <button
      type="button"
      className={cn(
        "min-h-11 rounded-md px-4 font-sans text-sm tracking-wide transition-[opacity,transform,background-color,border-color] duration-150 ease-out active:scale-[0.96] disabled:opacity-40",
        variant === "solid" && "bg-lumen text-void hover:opacity-90",
        variant === "ghost" &&
          "border border-lumen/15 bg-lumen/5 text-lumen hover:border-lumen/30 hover:bg-lumen/10",
        variant === "quiet" && "text-fog hover:text-lumen",
        className,
      )}
      {...props}
    >
      {children}
    </button>
  );
}

export function OverlayFrame({
  title,
  onClose,
  children,
  wide,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
  wide?: boolean;
}) {
  return (
    <div className="absolute inset-0 z-30 flex items-end justify-center p-3 sm:items-center sm:p-6">
      <button
        type="button"
        aria-label="Fermer"
        className="absolute inset-0 bg-void/55"
        onClick={onClose}
      />
      <Panel className={cn("relative z-10 flex max-h-[86dvh] w-full flex-col p-4", wide ? "max-w-lg" : "max-w-md")}>
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 className="font-display text-xl tracking-wide text-lumen">{title}</h2>
          <StarButton variant="quiet" className="px-2 text-xs uppercase tracking-[0.18em]" onClick={onClose}>
            Fermer
          </StarButton>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto">{children}</div>
      </Panel>
    </div>
  );
}

export function TypeLine({ text, className }: { text: string; className?: string }) {
  return (
    <p className={cn("whitespace-pre-wrap font-display text-[1.15rem] leading-relaxed text-lumen/90", className)}>
      {text}
    </p>
  );
}
