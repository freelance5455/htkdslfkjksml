import React, { useState } from 'react';
import {
  Search,
  Plus,
  Eye,
  EyeOff,
  Lock,
  Unlock,
  Trash2,
  Copy,
  Folder,
  Box,
  Circle,
  Sun,
  Camera,
  Volume2,
  User,
  Car,
  Home,
  Waves,
  Mountain,
  Crosshair,
} from 'lucide-react';
import { EngineObject, ObjectType } from '../types';
import { audioSystem } from '../audio/audioManager';

interface SceneGraphProps {
  objects: EngineObject[];
  selectedObjectId: string | null;
  onSelectObject: (id: string | null) => void;
  onFocusObject?: (id: string) => void;
  onAddObject: (type: ObjectType) => void;
  onDeleteObject: (id: string) => void;
  onDuplicateObject: (id: string) => void;
  onToggleVisibility: (id: string) => void;
  onToggleLock: (id: string) => void;
}

export const SceneGraph: React.FC<SceneGraphProps> = ({
  objects,
  selectedObjectId,
  onSelectObject,
  onFocusObject,
  onAddObject,
  onDeleteObject,
  onDuplicateObject,
  onToggleVisibility,
  onToggleLock,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddMenu, setShowAddMenu] = useState(false);
  const [filterType, setFilterType] = useState<'all' | 'mesh' | 'light' | 'game' | 'other'>('all');

  const filteredObjects = objects.filter((o) => {
    const matchesSearch = o.name.toLowerCase().includes(searchQuery.toLowerCase());
    if (!matchesSearch) return false;

    if (filterType === 'all') return true;
    if (filterType === 'mesh') return ['cube', 'sphere', 'capsule', 'cylinder', 'plane', 'cone', 'terrain', 'water', 'building'].includes(o.type);
    if (filterType === 'light') return o.type.startsWith('light');
    if (filterType === 'game') return ['npc', 'vehicle', 'audio_source'].includes(o.type);
    if (filterType === 'other') return ['camera', 'empty'].includes(o.type);
    return true;
  });

  const getObjectIcon = (type: ObjectType) => {
    switch (type) {
      case 'cube':
      case 'plane':
      case 'cylinder':
      case 'cone':
      case 'capsule':
        return <Box className="w-3.5 h-3.5 text-cyan-400" />;
      case 'sphere':
        return <Circle className="w-3.5 h-3.5 text-cyan-400" />;
      case 'light_directional':
      case 'light_point':
      case 'light_spot':
        return <Sun className="w-3.5 h-3.5 text-amber-400" />;
      case 'camera':
        return <Camera className="w-3.5 h-3.5 text-sky-400" />;
      case 'audio_source':
        return <Volume2 className="w-3.5 h-3.5 text-emerald-400" />;
      case 'npc':
      case 'capsule':
        return <User className="w-3.5 h-3.5 text-violet-400" />;
      case 'vehicle':
        return <Car className="w-3.5 h-3.5 text-orange-400" />;
      case 'building':
        return <Home className="w-3.5 h-3.5 text-amber-500" />;
      case 'terrain':
        return <Mountain className="w-3.5 h-3.5 text-emerald-500" />;
      case 'water':
        return <Waves className="w-3.5 h-3.5 text-sky-500" />;
      default:
        return <Folder className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  const primitives: { label: string; type: ObjectType }[] = [
    { label: 'Cube', type: 'cube' },
    { label: 'Sphere', type: 'sphere' },
    { label: 'Capsule', type: 'capsule' },
    { label: 'Cylinder', type: 'cylinder' },
    { label: 'Plane', type: 'plane' },
    { label: 'Cone', type: 'cone' },
    { label: 'Empty Object', type: 'empty' },
    { label: 'Directional Light', type: 'light_directional' },
    { label: 'Point Light', type: 'light_point' },
    { label: 'Spot Light', type: 'light_spot' },
    { label: 'Camera Rig', type: 'camera' },
    { label: 'Audio Source', type: 'audio_source' },
  ];

  return (
    <div className="flex flex-col h-full bg-[#11161f] text-slate-300 text-xs select-none">
      {/* Search & Add Bar */}
      <div className="p-2 border-b border-[#21262d] flex items-center space-x-1.5 relative">
        <div className="relative flex-1">
          <Search className="w-3 h-3 text-slate-500 absolute left-2 top-2" />
          <input
            type="text"
            placeholder="Search hierarchy..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#0d1117] border border-[#30363d] rounded pl-7 pr-2 py-1 text-[11px] text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        {/* Add Object Button */}
        <div className="relative">
          <button
            onClick={() => setShowAddMenu(!showAddMenu)}
            className="bg-cyan-600 hover:bg-cyan-500 text-white p-1 rounded transition-colors shadow-sm"
            title="Create Object"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>

          {showAddMenu && (
            <div className="absolute right-0 top-full mt-1 w-48 bg-[#161b22] border border-[#30363d] rounded shadow-2xl py-1 z-50 text-[11px]">
              <div className="px-2 py-1 text-[10px] font-bold tracking-wider text-cyan-400 uppercase">
                Add Primitive
              </div>
              {primitives.map((p) => (
                <button
                  key={p.type}
                  onClick={() => {
                    onAddObject(p.type);
                    setShowAddMenu(false);
                    audioSystem.playSound('synth_laser', { pitch: 1.5, volume: 0.3 });
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-950/70 hover:text-cyan-300 flex items-center space-x-2 transition-colors"
                >
                  {getObjectIcon(p.type)}
                  <span>{p.label}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Filter Chips */}
      <div className="flex items-center space-x-1 px-2 py-1 bg-[#0d1117] border-b border-[#21262d] overflow-x-auto text-[10px]">
        {(
          [
            { id: 'all', label: 'All' },
            { id: 'mesh', label: 'Meshes' },
            { id: 'light', label: 'Lights' },
            { id: 'game', label: 'Actors' },
            { id: 'other', label: 'Other' },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            onClick={() => setFilterType(tab.id)}
            className={`px-1.5 py-0.5 rounded transition-colors whitespace-nowrap ${
              filterType === tab.id
                ? 'bg-cyan-900/60 text-cyan-300 font-medium border border-cyan-700/50'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Objects Tree List */}
      <div className="flex-1 overflow-y-auto p-1 divide-y divide-[#1e2530]/60">
        <div className="px-2 py-1 text-[10px] font-semibold text-slate-400 flex justify-between items-center">
          <span>SCENE HIERARCHY</span>
          <span className="font-mono text-[9px] bg-[#1a2333] text-cyan-400 px-1.5 py-0.2 rounded">
            {filteredObjects.length} / {objects.length}
          </span>
        </div>

        {filteredObjects.length === 0 ? (
          <div className="p-4 text-center text-slate-500 text-[11px]">No objects matched query</div>
        ) : (
          filteredObjects.map((obj) => {
            const isSelected = selectedObjectId === obj.id;
            return (
              <div
                key={obj.id}
                onClick={() => onSelectObject(obj.id)}
                onDoubleClick={() => {
                  onSelectObject(obj.id);
                  onFocusObject?.(obj.id);
                }}
                className={`group flex items-center justify-between px-2 py-1.5 rounded cursor-pointer transition-colors ${
                  isSelected
                    ? 'bg-cyan-950/80 border border-cyan-700/60 text-cyan-200'
                    : 'hover:bg-[#161b22] text-slate-300'
                }`}
              >
                <div className="flex items-center space-x-2 flex-1 min-w-0 pr-1">
                  {getObjectIcon(obj.type)}
                  <span className="truncate text-[11px] font-medium" title={obj.name}>
                    {obj.name}
                  </span>
                </div>

                {/* Actions: Focus, Visibility, Lock, Duplicate, Delete */}
                <div className="flex items-center space-x-1 opacity-60 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectObject(obj.id);
                      onFocusObject?.(obj.id);
                    }}
                    className="p-1 hover:text-cyan-300"
                    title="Focus Camera on Object"
                  >
                    <Crosshair className="w-3 h-3 text-slate-400 hover:text-cyan-300" />
                  </button>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleVisibility(obj.id);
                    }}
                    className="p-1 hover:text-white"
                    title={obj.visible ? 'Hide Object' : 'Show Object'}
                  >
                    {obj.visible ? <Eye className="w-3 h-3 text-cyan-400" /> : <EyeOff className="w-3 h-3 text-slate-500" />}
                  </button>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleLock(obj.id);
                    }}
                    className="p-1 hover:text-white"
                    title={obj.locked ? 'Unlock Object' : 'Lock Object'}
                  >
                    {obj.locked ? <Lock className="w-3 h-3 text-amber-400" /> : <Unlock className="w-3 h-3 text-slate-500" />}
                  </button>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDuplicateObject(obj.id);
                    }}
                    className="p-1 hover:text-cyan-300"
                    title="Duplicate Object"
                  >
                    <Copy className="w-3 h-3" />
                  </button>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteObject(obj.id);
                    }}
                    className="p-1 hover:text-rose-400"
                    title="Delete Object"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
