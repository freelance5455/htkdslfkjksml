import { useSyncExternalStore } from 'react';
import { engine, HudState } from '../game/engine';

export function useHud(): HudState {
  return useSyncExternalStore(
    (cb) => engine.subscribe(() => cb()),
    () => engine.getHud()
  );
}

export const fmtTime = (hours: number) => {
  const h = Math.floor(hours) % 24;
  const m = Math.floor((hours % 1) * 60);
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
};

export const fmtMoney = (v: number) => '$' + Math.floor(v).toLocaleString('en-US');

export const fmtCountdown = (ms: number) => {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${sec
    .toString()
    .padStart(2, '0')}`;
};
