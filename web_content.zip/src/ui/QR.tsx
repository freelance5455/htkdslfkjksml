import { useEffect, useRef, useState } from 'react';
import qrcode from 'qrcode-generator';
import jsQR from 'jsqr';

export function QRView({ text, size = 300 }: { text: string; size?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current; if (!c || !text) return;
    const qr = qrcode(0, 'L'); qr.addData(text); qr.make();
    const n = qr.getModuleCount(); const quiet = 3; const dpr = Math.min(window.devicePixelRatio || 1, 3);
    const cell = Math.max(2, Math.floor((size * dpr) / (n + quiet * 2)));
    const px = cell * (n + quiet * 2); c.width = px; c.height = px; c.style.width = c.style.height = px / dpr + 'px';
    const x = c.getContext('2d')!; x.fillStyle = '#fff'; x.fillRect(0, 0, px, px); x.fillStyle = '#000';
    for (let r = 0; r < n; r++) for (let k = 0; k < n; k++) if (qr.isDark(r, k)) x.fillRect((k + quiet) * cell, (r + quiet) * cell, cell, cell);
  }, [text, size]);
  return <div className="qrbox"><canvas ref={ref} /></div>;
}

export function Scanner({ title, onResult, onCancel }: { title: string; onResult: (s: string) => void; onCancel: () => void }) {
  const vref = useRef<HTMLVideoElement>(null); const [err, setErr] = useState('');
  useEffect(() => {
    let stop = false; let stream: MediaStream | null = null; const c = document.createElement('canvas'); const x = c.getContext('2d', { willReadFrequently: true })!;
    if (!navigator.mediaDevices?.getUserMedia) { setErr('الكاميرا غير متاحة في هذا المتصفح/الاتصال. افتح اللعبة من المتصفح مباشرة (HTTPS أو ملف محلي).'); return; }
    let last = 0;
    const tick = () => {
      if (stop) return; requestAnimationFrame(tick); const v = vref.current; if (!v || v.readyState < 2) return;
      const now = performance.now(); if (now - last < 100) return; last = now;
      const w = v.videoWidth, h = v.videoHeight; if (!w) return; const sc = Math.min(1, 720 / w); c.width = Math.round(w * sc); c.height = Math.round(h * sc);
      x.drawImage(v, 0, 0, c.width, c.height); const img = x.getImageData(0, 0, c.width, c.height);
      const r = jsQR(img.data, c.width, c.height, { inversionAttempts: 'dontInvert' });
      if (r && r.data && r.data.startsWith('1|')) { stop = true; onResult(r.data); }
    };
    navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 } }, audio: false }).then(s => {
      if (stop) { s.getTracks().forEach(t => t.stop()); return; }
      stream = s; const v = vref.current!; v.srcObject = s; v.setAttribute('playsinline', 'true'); v.muted = true; v.play().catch(() => { }); tick();
    }).catch(() => setErr('لم يتم السماح بالوصول للكاميرا. فعّل إذن الكاميرا ثم أعد المحاولة.'));
    return () => { stop = true; stream?.getTracks().forEach(t => t.stop()); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return (
    <div className="modal">
      <h3 style={{ color: '#f3c552', margin: 0 }}>📷 {title}</h3>
      {err ? <p className="bad" style={{ maxWidth: 420, textAlign: 'center' }}>{err}</p> : <div className="scanframe"><video ref={vref} /></div>}
      <p className="sub" style={{ margin: 0 }}>وجّه الكاميرا نحو رمز QR على شاشة الهاتف الآخر</p>
      <button className="btn gray" onClick={onCancel}>إلغاء</button>
    </div>
  );
}
