import { useState } from "react";
import { CREDITS_DEFAULT } from "@/data/credits";
import { PUZZLES } from "@/data/puzzles";
import { useGame } from "@/game/store";
import { loadAdmin, writeAdmin } from "@/game/save";
import { OverlayFrame, StarButton } from "./chrome";

export function AdminOverlay() {
  const close = useGame((s) => s.closeAdmin);
  const names = useGame((s) => s.names);
  const setNames = useGame((s) => s.setNames);
  const admin = loadAdmin();
  const [player, setPlayer] = useState(names.player);
  const [searched, setSearched] = useState(names.searched);
  const [c1, setC1] = useState(admin.creditsLine1 ?? CREDITS_DEFAULT.line1);
  const [c2, setC2] = useState(admin.creditsLine2 ?? CREDITS_DEFAULT.line2);
  const [answers, setAnswers] = useState<Record<string, string>>(
    Object.fromEntries((admin.puzzleAnswers ?? {})[""] ? [] : PUZZLES.filter((p) => p.acceptedAnswers).map((p) => [p.id, (admin.puzzleAnswers?.[p.id] ?? p.acceptedAnswers ?? []).join(" | ")])),
  );

  return (
    <OverlayFrame title="Atelier" onClose={close} wide>
      <p className="mb-4 text-xs text-fog">Espace caché. Les changements s'appliquent à cette machine.</p>
      <label className="mb-3 block text-xs text-fog">
        Nom du voyageur
        <input value={player} onChange={(e) => setPlayer(e.target.value)} className="mt-1 w-full rounded-md border border-lumen/15 bg-void p-2 text-sm text-lumen" />
      </label>
      <label className="mb-3 block text-xs text-fog">
        Nom recherché
        <input value={searched} onChange={(e) => setSearched(e.target.value)} className="mt-1 w-full rounded-md border border-lumen/15 bg-void p-2 text-sm text-lumen" />
      </label>
      <label className="mb-3 block text-xs text-fog">
        Ligne de générique 1
        <input value={c1} onChange={(e) => setC1(e.target.value)} className="mt-1 w-full rounded-md border border-lumen/15 bg-void p-2 text-sm text-lumen" />
      </label>
      <label className="mb-3 block text-xs text-fog">
        Ligne de générique 2
        <input value={c2} onChange={(e) => setC2(e.target.value)} className="mt-1 w-full rounded-md border border-lumen/15 bg-void p-2 text-sm text-lumen" />
      </label>
      {PUZZLES.filter((p) => p.acceptedAnswers).map((p) => (
        <label key={p.id} className="mb-3 block text-xs text-fog">
          Réponses — {p.title}
          <input
            value={answers[p.id] ?? p.acceptedAnswers?.join(" | ")}
            onChange={(e) => setAnswers({ ...answers, [p.id]: e.target.value })}
            className="mt-1 w-full rounded-md border border-lumen/15 bg-void p-2 text-sm text-lumen"
          />
        </label>
      ))}
      <StarButton
        variant="solid"
        className="w-full"
        onClick={() => {
          setNames({ player: player.trim() || "Lohen", searched: searched.trim() || "Esteban" });
          const puzzleAnswers: Record<string, string[]> = {};
          for (const [k, v] of Object.entries(answers)) {
            puzzleAnswers[k] = v.split("|").map((s) => s.trim().toLowerCase()).filter(Boolean);
          }
          writeAdmin({
            names: { player: player.trim() || "Lohen", searched: searched.trim() || "Esteban" },
            creditsLine1: c1,
            creditsLine2: c2,
            puzzleAnswers,
          });
          close();
        }}
      >
        Enregistrer
      </StarButton>
    </OverlayFrame>
  );
}
