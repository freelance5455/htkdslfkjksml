/* ==========================================================================
   actions.js — رجیستری مرکزی اکشن‌ها (همه دکمه‌ها واقعی کار می‌کنند)
   ========================================================================== */

export const Actions = {};

export function reg(prefix, map) {
  Object.keys(map).forEach((k) => { Actions[prefix + '.' + k] = map[k]; });
}

export function dispatch(name, el) {
  const fn = Actions[name];
  if (!fn) {
    if (typeof console !== 'undefined') console.warn('اکشن تعریف نشده:', name);
    return false;
  }
  try { fn(el, el ? el.dataset : {}); return true; }
  catch (e) {
    if (typeof console !== 'undefined') console.error(e);
    import('./shell.js').then((m) => m.toast('خطا در اجرای عملیات: ' + (e && e.message ? e.message : e), 'red'));
    return false;
  }
}

/** find action name from element or closest parent */
export function actionOf(el) {
  let node = el;
  while (node && node !== document) {
    if (node.dataset && node.dataset.act) return node.dataset.act;
    node = node.parentElement;
  }
  return null;
}
