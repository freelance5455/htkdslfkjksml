/**
 * GODEX Central Event Bus
 * Strongly typed, immutable event stream for synchronization across all GODEX subsystems:
 * Chat, Task Tree, Context, Agent Matrix, Diff, Safe Edit, Test Suite, Telemetry, Verification, Preview.
 */

export type GodexEventType =
  | 'OPERATION_CREATED'
  | 'OPERATION_STARTED'
  | 'CONTEXT_BUILD_STARTED'
  | 'CONTEXT_BUILD_COMPLETED'
  | 'TASK_CREATED'
  | 'TASK_STARTED'
  | 'TASK_COMPLETED'
  | 'TASK_FAILED'
  | 'AGENT_ASSIGNED'
  | 'AGENT_STARTED'
  | 'AGENT_WAITING'
  | 'AGENT_COMPLETED'
  | 'AGENT_FAILED'
  | 'FILE_INSPECTED'
  | 'PLAN_CREATED'
  | 'EDIT_PROPOSED'
  | 'APPROVAL_REQUIRED'
  | 'EDIT_APPROVED'
  | 'EDIT_REJECTED'
  | 'EDIT_APPLIED'
  | 'EDIT_FAILED'
  | 'DIFF_CREATED'
  | 'VALIDATION_STARTED'
  | 'VALIDATION_COMPLETED'
  | 'TEST_STARTED'
  | 'TEST_COMPLETED'
  | 'EXECUTION_STARTED'
  | 'EXECUTION_COMPLETED'
  | 'VERIFICATION_STARTED'
  | 'VERIFICATION_COMPLETED'
  | 'MEMORY_RECORDED'
  | 'OPERATION_COMPLETED'
  | 'OPERATION_FAILED'
  | 'OPERATION_CANCELLED';

export interface GodexEvent {
  eventId: string;
  timestamp: number;
  type: GodexEventType;
  operationId: string;
  taskId?: string;
  agentId?: string;
  filePath?: string;
  subsystem?: string;
  severity?: 'info' | 'warn' | 'error' | 'success';
  message?: string;
  payload?: any;
  evidence?: any;
}

export type GodexEventListener = (event: Readonly<GodexEvent>) => void;

export class GodexEventBus {
  private static instance: GodexEventBus | null = null;
  private listeners: Set<GodexEventListener> = new Set();
  private eventHistory: GodexEvent[] = [];
  private maxHistory = 1000;

  private constructor() {}

  public static getInstance(): GodexEventBus {
    if (!GodexEventBus.instance) {
      GodexEventBus.instance = new GodexEventBus();
    }
    return GodexEventBus.instance;
  }

  /**
   * Subscribe to all GODEX events
   */
  public subscribe(listener: GodexEventListener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  /**
   * Emit an immutable event to all subscribers and append to event history
   */
  public emit(event: Omit<GodexEvent, 'eventId' | 'timestamp'> & { eventId?: string; timestamp?: number }): GodexEvent {
    const fullEvent: GodexEvent = Object.freeze({
      eventId: event.eventId || `evt-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      timestamp: event.timestamp || Date.now(),
      type: event.type,
      operationId: event.operationId,
      taskId: event.taskId,
      agentId: event.agentId,
      filePath: event.filePath,
      subsystem: event.subsystem,
      severity: event.severity || 'info',
      message: event.message,
      payload: event.payload ? JSON.parse(JSON.stringify(event.payload)) : undefined,
      evidence: event.evidence ? JSON.parse(JSON.stringify(event.evidence)) : undefined
    });

    this.eventHistory.push(fullEvent);
    if (this.eventHistory.length > this.maxHistory) {
      this.eventHistory.shift();
    }

    for (const listener of this.listeners) {
      try {
        listener(fullEvent);
      } catch (err) {
        console.error('[GodexEventBus] Listener error:', err);
      }
    }

    return fullEvent;
  }

  /**
   * Retrieve immutable event history
   */
  public getHistory(operationId?: string): readonly GodexEvent[] {
    if (operationId) {
      return this.eventHistory.filter(e => e.operationId === operationId);
    }
    return [...this.eventHistory];
  }

  /**
   * Clear event history (used for clean resets)
   */
  public clear(): void {
    this.eventHistory = [];
  }
}
