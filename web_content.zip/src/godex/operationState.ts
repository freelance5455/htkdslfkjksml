/**
 * GODEX Authoritative Operation State Model
 * Centralized, immutable single-source-of-truth state machine representing
 * the complete engineering lifecycle from user intent to evidence-grounded verification.
 */

import { ContextPack } from '../intelligence/contextTypes';

export type OperationStatus =
  | 'IDLE'
  | 'RECEIVING'
  | 'PLANNING'
  | 'INSPECTING'
  | 'GENERATING'
  | 'WAITING_APPROVAL'
  | 'EDITING'
  | 'VALIDATING'
  | 'TESTING'
  | 'VERIFYING'
  | 'COMPLETED'
  | 'FAILED'
  | 'CANCELLED';

export type TaskItemStatus =
  | 'QUEUED'
  | 'READY'
  | 'RUNNING'
  | 'WAITING'
  | 'BLOCKED'
  | 'COMPLETED'
  | 'FAILED'
  | 'CANCELLED';

export type AgentRoleName =
  | 'ARCHITECT'
  | 'RESEARCHER'
  | 'CODER'
  | 'DEBUGGER'
  | 'TESTER'
  | 'UI_UX'
  | 'SECURITY'
  | 'REVIEWER'
  | 'VERIFIER';

export type AgentItemStatus =
  | 'IDLE'
  | 'QUEUED'
  | 'WORKING'
  | 'WAITING'
  | 'BLOCKED'
  | 'COMPLETED'
  | 'FAILED';

export interface OperationTaskItem {
  id: string;
  title: string;
  description?: string;
  status: TaskItemStatus;
  dependencies: string[];
  agentId?: string;
  agentRole: AgentRoleName;
  files: string[];
  createdAt: number;
  startedAt?: number;
  completedAt?: number;
  error?: string;
  progressPercent: number;
}

export interface OperationAgentItem {
  id: string;
  name: string;
  role: AgentRoleName;
  title: string;
  description: string;
  capabilities: string[];
  status: AgentItemStatus;
  currentTaskId?: string;
  color: string;
  model: string;
  iconName?: string;
}

export interface ContextFileItem {
  path: string;
  reason: string;
  relevance: number; // 0 - 100
  tokens: number;
  epistemic: 'KNOWN' | 'LIKELY' | 'UNKNOWN';
  architecturalLayer?: string;
}

export interface ContextSymbolItem {
  name: string;
  file: string;
  kind: string;
  line: number;
}

export interface OperationContextState {
  contextPack?: ContextPack;
  files: ContextFileItem[];
  symbols: ContextSymbolItem[];
  tokenBudget: number;
  tokenUsage: number;
  architecturalLayer?: string;
  memoryReferences: string[];
  gitReferences: string[];
  epistemicSummary: {
    known: string[];
    likely: string[];
    unknown: string[];
  };
}

export interface DiffLineItem {
  type: 'added' | 'removed' | 'unchanged';
  oldLineNumber?: number;
  newLineNumber?: number;
  content: string;
}

export interface OperationFileDiff {
  filePath: string;
  before: string;
  after: string;
  additions: number;
  deletions: number;
  status: 'PROPOSED' | 'APPLIED' | 'REJECTED' | 'FAILED';
  approval: 'REQUIRED' | 'AUTO_APPROVED' | 'USER_APPROVED' | 'REJECTED';
  validation: 'PASSED' | 'FAILED' | 'PENDING';
  unifiedDiff: string;
  lines: DiffLineItem[];
}

export interface OperationDiffState {
  fileDiffs: OperationFileDiff[];
  totalAdditions: number;
  totalDeletions: number;
  hasChanges: boolean;
}

export interface OperationEditState {
  targetFile: string;
  operation: 'create' | 'modify' | 'delete' | 'patch';
  risk: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  fingerprint: string;
  isStale: boolean;
  approval: 'REQUIRED' | 'AUTO_APPROVED' | 'USER_APPROVED' | 'REJECTED';
  checkpointId?: string;
  rollbackAvailable: boolean;
  validationStatus: 'PENDING' | 'PASSED' | 'FAILED';
  blockedReason?: string;
  patchSummary?: string;
}

export interface OperationTestItem {
  id: string;
  name: string;
  category: 'syntax' | 'transpile' | 'dom_assertion' | 'runtime' | 'sandbox';
  status: 'QUEUED' | 'RUNNING' | 'PASS' | 'FAIL' | 'BLOCKED' | 'NOT_VERIFIED';
  durationMs?: number;
  details?: string;
  error?: string;
}

export interface OperationTestState {
  testItems: OperationTestItem[];
  totalCount: number;
  passedCount: number;
  failedCount: number;
  overallStatus: 'QUEUED' | 'RUNNING' | 'PASS' | 'FAIL' | 'NOT_VERIFIED';
}

export interface OperationExecutionState {
  command?: string;
  stdout?: string;
  stderr?: string;
  exitCode?: number;
  status: 'IDLE' | 'RUNNING' | 'SUCCESS' | 'FAILED';
  durationMs?: number;
}

export type VerificationPillarStatus = 'PASS' | 'FAIL' | 'BLOCKED' | 'NOT_VERIFIED';

export interface UIQualityVerificationInfo {
  score: number;
  rating: string;
  personality: string;
  category: string;
  passedInvariants: string[];
  truthfulEvidence: string[];
  violationsCount: number;
}

export interface OperationVerificationState {
  typecheck: VerificationPillarStatus;
  test: VerificationPillarStatus;
  build: VerificationPillarStatus;
  execution: VerificationPillarStatus;
  regression: VerificationPillarStatus;
  security: VerificationPillarStatus;
  overall: VerificationPillarStatus;
  score: number; // 0 - 100
  evidenceSummary: string;
  verifiedAt?: number;
  uiQuality?: UIQualityVerificationInfo;
}

export interface OperationTelemetryItem {
  id: string;
  timestamp: number;
  subsystem: 'ORCHESTRATOR' | 'CONTEXT' | 'CODING' | 'VALIDATION' | 'TEST' | 'VERIFICATION' | 'EXECUTION' | 'MEMORY' | 'SAFETY';
  event: string;
  operationId: string;
  taskId?: string;
  agentId?: string;
  severity: 'info' | 'warn' | 'error' | 'success';
  message: string;
  details?: string;
}

export interface GeneratedArtifact {
  id: string;
  operationId: string;
  name: string;
  description: string;
  files: Record<string, string>;
  entryFile: string;
  html?: string;
  css?: string;
  javascript?: string;
  reactCode?: string;
  createdAt: number;
  designAudit?: {
    score: number;
    rating: string;
    personality: string;
    category: string;
    passedInvariants: string[];
  };
}

export interface OperationState {
  operationId: string;
  userRequest: string;
  status: OperationStatus;
  createdAt: number;
  updatedAt: number;

  currentTaskId?: string;
  currentAgentId?: string;

  tasks: OperationTaskItem[];
  agents: OperationAgentItem[];

  context?: OperationContextState;
  diff?: OperationDiffState;
  edit?: OperationEditState;
  tests?: OperationTestState;
  execution?: OperationExecutionState;
  verification?: OperationVerificationState;
  artifact?: GeneratedArtifact;

  telemetry: OperationTelemetryItem[];
  errors: string[];
}

export function createInitialAgents(): OperationAgentItem[] {
  return [
    {
      id: 'agent-architect',
      name: 'Architect Agent',
      role: 'ARCHITECT',
      title: 'System & Architecture Planner',
      description: 'Analyzes holistic workspace structure, designs dependency graphs, and structures implementation steps.',
      capabilities: ['AST Topology Analysis', 'Dependency Tree Mapping', 'Step Decomposition'],
      status: 'IDLE',
      color: 'border-amber-500/40 text-amber-300 bg-amber-950/30',
      model: 'gemini-3.7-flash',
      iconName: 'Layers'
    },
    {
      id: 'agent-researcher',
      name: 'Researcher Agent',
      role: 'RESEARCHER',
      title: 'Symbol & Context Investigator',
      description: 'Inspects symbols, imports, types, and project context packs to locate exact mutation targets.',
      capabilities: ['Symbol Extraction', 'Epistemic Classification', 'Context Token Optimization'],
      status: 'IDLE',
      color: 'border-purple-500/40 text-purple-300 bg-purple-950/30',
      model: 'gemini-3.7-flash',
      iconName: 'Search'
    },
    {
      id: 'agent-coder',
      name: 'Coder Agent',
      role: 'CODER',
      title: 'Deterministic Code Synthesis',
      description: 'Generates type-safe code modifications, components, and surgical AST patches.',
      capabilities: ['TypeScript / React Synthesis', 'Surgical File Mutations', 'Safe Patch Generation'],
      status: 'IDLE',
      color: 'border-cyan-500/40 text-cyan-300 bg-cyan-950/30',
      model: 'gemini-3.7-flash',
      iconName: 'Code'
    },
    {
      id: 'agent-debugger',
      name: 'Debugger Agent',
      role: 'DEBUGGER',
      title: 'Self-Healing & Error Interception',
      description: 'Detects compilation, import, or runtime errors and synthesizes automatic repair patches.',
      capabilities: ['Error Boundary Interception', 'Root Cause Diagnosis', 'Self-Healing Repair Plans'],
      status: 'IDLE',
      color: 'border-rose-500/40 text-rose-300 bg-rose-950/30',
      model: 'gemini-3.7-flash',
      iconName: 'ShieldAlert'
    },
    {
      id: 'agent-tester',
      name: 'Tester Agent',
      role: 'TESTER',
      title: 'Test & Discovery Validation',
      description: 'Executes test suite assertions, transpiler verifications, and DOM element checks.',
      capabilities: ['AST Validation', 'DOM Assertion Verification', 'Transpile Integrity Check'],
      status: 'IDLE',
      color: 'border-amber-500/40 text-amber-300 bg-amber-950/30',
      model: 'gemini-3.7-flash',
      iconName: 'TestTube'
    },
    {
      id: 'agent-ui-ux',
      name: 'UI/UX Visual QA Agent',
      role: 'UI_UX',
      title: 'Visual QA & Viewport Inspector',
      description: 'Conducts multi-viewport audits (Mobile 390px, Tablet 768px, Desktop 1280px), checking typography, layout overflow, contrast, and touch targets.',
      capabilities: ['Multi-Viewport Layout Inspection', 'WCAG AA Color Contrast Audit', 'Touch Target Compliance', 'Asset Health Verification'],
      status: 'IDLE',
      color: 'border-pink-500/40 text-pink-300 bg-pink-950/30',
      model: 'gemini-3.7-flash',
      iconName: 'Eye'
    },
    {
      id: 'agent-security',
      name: 'Security Reviewer Agent',
      role: 'SECURITY',
      title: 'Security & Secret Auditor',
      description: 'Performs static taint analysis to block secret leaks, unsafe eval, unescaped HTML, and iframe sandbox escapes.',
      capabilities: ['Secret Leak Protection', 'AST Taint Analysis', 'Iframe Sandbox Boundary Enforcement'],
      status: 'IDLE',
      color: 'border-red-500/40 text-red-300 bg-red-950/30',
      model: 'gemini-3.7-flash',
      iconName: 'Lock'
    },
    {
      id: 'agent-reviewer',
      name: 'Reviewer Agent',
      role: 'REVIEWER',
      title: 'Independent Diff & Security Review',
      description: 'Audits proposed diffs for security vulnerabilities, stale fingerprints, and unintended deletions.',
      capabilities: ['Secret Redaction Check', 'Stale Fingerprint Validation', 'Resource Conflict Auditing'],
      status: 'IDLE',
      color: 'border-blue-500/40 text-blue-300 bg-blue-950/30',
      model: 'gemini-3.7-flash',
      iconName: 'GitPullRequest'
    },
    {
      id: 'agent-verifier',
      name: 'Verifier Agent',
      role: 'VERIFIER',
      title: 'Evidence-Grounded Verifier',
      description: 'Aggregates 6-pillar verification evidence and certifies task completion with zero false claims.',
      capabilities: ['6-Pillar Evidence Aggregation', 'Truth-Grounded Scoring', 'Final Certification'],
      status: 'IDLE',
      color: 'border-emerald-400/40 text-emerald-300 bg-emerald-950/30',
      model: 'gemini-3.7-flash',
      iconName: 'ShieldCheck'
    }
  ];
}

export function createInitialOperationState(): OperationState {
  return {
    operationId: 'op-init',
    userRequest: '',
    status: 'IDLE',
    createdAt: Date.now(),
    updatedAt: Date.now(),
    tasks: [],
    agents: createInitialAgents(),
    telemetry: [],
    errors: []
  };
}
