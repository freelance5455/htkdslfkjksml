/**
 * GODEX Operation Manager
 * Authoritative single source of truth for operations, task trees, context,
 * diffs, safe edits, test runs, verifications, and generated artifacts.
 */

import {
  OperationState,
  OperationStatus,
  OperationTaskItem,
  OperationAgentItem,
  OperationContextState,
  OperationDiffState,
  OperationEditState,
  OperationTestState,
  OperationVerificationState,
  OperationTelemetryItem,
  GeneratedArtifact,
  createInitialOperationState,
  createInitialAgents
} from './operationState';
import { GodexEventBus, GodexEvent } from './godexEventBus';

export type OperationListener = (operation: Readonly<OperationState>) => void;

export class OperationManager {
  private static instance: OperationManager | null = null;
  private operations: Map<string, OperationState> = new Map();
  private activeOperationId: string | null = null;
  private listeners: Set<OperationListener> = new Set();
  private eventBus = GodexEventBus.getInstance();

  private constructor() {
    this.eventBus.subscribe((evt: GodexEvent) => {
      this.handleEvent(evt);
    });
  }

  public static getInstance(): OperationManager {
    if (!OperationManager.instance) {
      OperationManager.instance = new OperationManager();
    }
    return OperationManager.instance;
  }

  public subscribe(listener: OperationListener): () => void {
    this.listeners.add(listener);
    const active = this.getActiveOperation();
    if (active) {
      listener(active);
    }
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify(): void {
    const active = this.getActiveOperation();
    if (active) {
      for (const listener of this.listeners) {
        try {
          listener({ ...active });
        } catch (err) {
          console.error('[OperationManager] Listener error:', err);
        }
      }
    }
  }

  private handleEvent(event: GodexEvent): void {
    if (!event.operationId) return;
    const op = this.operations.get(event.operationId);
    if (!op) return;

    const telemetryItem: OperationTelemetryItem = {
      id: event.eventId,
      timestamp: event.timestamp,
      subsystem: (event.subsystem as any) || 'ORCHESTRATOR',
      event: event.type,
      operationId: event.operationId,
      taskId: event.taskId,
      agentId: event.agentId,
      severity: event.severity || 'info',
      message: event.message || `${event.type} recorded.`,
      details: event.payload ? JSON.stringify(event.payload).slice(0, 120) : undefined
    };

    op.telemetry = [telemetryItem, ...op.telemetry].slice(0, 200);
    op.updatedAt = Date.now();
    this.notify();
  }

  /**
   * Creates and registers a new authoritative operation.
   */
  public createOperation(userRequest: string, customId?: string): OperationState {
    const operationId = customId || `op-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const newOperation: OperationState = {
      operationId,
      userRequest,
      status: 'RECEIVING',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      tasks: [],
      agents: createInitialAgents(),
      telemetry: [],
      errors: []
    };

    this.operations.set(operationId, newOperation);
    this.activeOperationId = operationId;

    this.eventBus.emit({
      type: 'OPERATION_CREATED',
      operationId,
      subsystem: 'ORCHESTRATOR',
      severity: 'info',
      message: `Operation ${operationId} created for: "${userRequest}"`,
      payload: { userRequest }
    });

    this.notify();
    return newOperation;
  }

  public getOperation(operationId: string): OperationState | undefined {
    return this.operations.get(operationId);
  }

  public getActiveOperationId(): string | null {
    return this.activeOperationId;
  }

  public setActiveOperationId(operationId: string): boolean {
    if (this.operations.has(operationId)) {
      this.activeOperationId = operationId;
      this.notify();
      return true;
    }
    return false;
  }

  public getActiveOperation(): OperationState | null {
    if (this.activeOperationId && this.operations.has(this.activeOperationId)) {
      return this.operations.get(this.activeOperationId)!;
    }
    if (this.operations.size > 0) {
      const latest = Array.from(this.operations.values())[this.operations.size - 1];
      this.activeOperationId = latest.operationId;
      return latest;
    }
    return null;
  }

  public updateOperation(operationId: string, partial: Partial<OperationState>): OperationState | null {
    const op = this.operations.get(operationId);
    if (!op) return null;

    Object.assign(op, partial, { updatedAt: Date.now() });
    this.notify();
    return op;
  }

  public updateStatus(operationId: string, status: OperationStatus): void {
    const op = this.operations.get(operationId);
    if (!op) return;

    op.status = status;
    op.updatedAt = Date.now();

    if (status === 'COMPLETED') {
      this.eventBus.emit({
        type: 'OPERATION_COMPLETED',
        operationId,
        subsystem: 'ORCHESTRATOR',
        severity: 'success',
        message: `Operation ${operationId} completed successfully.`
      });
    } else if (status === 'FAILED') {
      this.eventBus.emit({
        type: 'OPERATION_FAILED',
        operationId,
        subsystem: 'ORCHESTRATOR',
        severity: 'error',
        message: `Operation ${operationId} failed.`
      });
    }

    this.notify();
  }

  public addTask(operationId: string, task: OperationTaskItem): void {
    const op = this.operations.get(operationId);
    if (!op) return;

    op.tasks = [...op.tasks.filter(t => t.id !== task.id), task];
    op.updatedAt = Date.now();

    this.eventBus.emit({
      type: 'TASK_CREATED',
      operationId,
      taskId: task.id,
      subsystem: 'ORCHESTRATOR',
      message: `Task ${task.title} added [${task.agentRole}]`
    });

    this.notify();
  }

  public updateTask(operationId: string, taskId: string, updates: Partial<OperationTaskItem>): void {
    const op = this.operations.get(operationId);
    if (!op) return;

    op.tasks = op.tasks.map(t => {
      if (t.id === taskId) {
        return {
          ...t,
          ...updates,
          completedAt: updates.status === 'COMPLETED' || updates.status === 'FAILED' ? Date.now() : t.completedAt
        };
      }
      return t;
    });

    op.currentTaskId = taskId;
    op.updatedAt = Date.now();
    this.notify();
  }

  public assignAgent(operationId: string, role: OperationAgentItem['role'], status: OperationAgentItem['status'], currentTaskId?: string): void {
    const op = this.operations.get(operationId);
    if (!op) return;

    op.agents = op.agents.map(a => {
      if (a.role === role) {
        return {
          ...a,
          status,
          currentTaskId: status === 'WORKING' || status === 'QUEUED' ? currentTaskId : undefined
        };
      }
      return a;
    });

    if (status === 'WORKING') {
      const active = op.agents.find(a => a.role === role);
      op.currentAgentId = active?.id;
    }

    op.updatedAt = Date.now();
    this.notify();
  }

  public updateContext(operationId: string, context: OperationContextState): void {
    const op = this.operations.get(operationId);
    if (!op) return;

    op.context = context;
    op.updatedAt = Date.now();
    this.notify();
  }

  public updateDiff(operationId: string, diff: OperationDiffState): void {
    const op = this.operations.get(operationId);
    if (!op) return;

    op.diff = diff;
    op.updatedAt = Date.now();
    this.notify();
  }

  public updateSafeEdit(operationId: string, edit: OperationEditState): void {
    const op = this.operations.get(operationId);
    if (!op) return;

    op.edit = edit;
    op.updatedAt = Date.now();
    this.notify();
  }

  public updateTests(operationId: string, tests: OperationTestState): void {
    const op = this.operations.get(operationId);
    if (!op) return;

    op.tests = tests;
    op.updatedAt = Date.now();
    this.notify();
  }

  public updateVerification(operationId: string, verification: OperationVerificationState): void {
    const op = this.operations.get(operationId);
    if (!op) return;

    op.verification = verification;
    op.updatedAt = Date.now();
    this.notify();
  }

  public updateArtifact(operationId: string, artifact: GeneratedArtifact): void {
    const op = this.operations.get(operationId);
    if (!op) return;

    // Set canonical artifact and alias for compatibility
    op.artifact = { ...artifact, operationId };
    (op as any).generatedArtifact = { ...artifact, operationId };
    op.updatedAt = Date.now();
    this.notify();
  }

  public appendTelemetry(operationId: string, item: OperationTelemetryItem): void {
    const op = this.operations.get(operationId);
    if (!op) return;

    op.telemetry = [item, ...op.telemetry].slice(0, 200);
    op.updatedAt = Date.now();
    this.notify();
  }

  public getOperationHistory(): OperationState[] {
    return Array.from(this.operations.values()).sort((a, b) => b.createdAt - a.createdAt);
  }

  public clear(): void {
    this.operations.clear();
    this.activeOperationId = null;
  }
}
