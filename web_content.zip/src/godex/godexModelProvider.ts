/**
 * GODEX Model Provider Abstraction
 * Authoritative provider for real AI application generation.
 * Interfaces with server-side AI endpoints and delivers structured GeneratedArtifacts
 * carrying the exact operationId throughout the pipeline.
 *
 * CRITICAL DIRECTIVES:
 * - NEVER generate a Calculator under any circumstances.
 * - If no AI provider is configured and request cannot be synthesized, return AI_PROVIDER_NOT_CONFIGURED.
 */

import { GeneratedArtifact } from './operationState';
import { synthesizeDomainApplication } from '../intelligence/domainSynthesizer';

export interface GodexGenerationRequest {
  operationId: string;
  userPrompt: string;
  workspaceContext?: {
    filesCount?: number;
    targetFile?: string;
    relevantSymbols?: string[];
    taskIntent?: string;
  };
  existingFiles: Record<string, string>;
  model?: string;
}

export interface GodexGenerationResult {
  success: boolean;
  operationId: string;
  artifact?: GeneratedArtifact;
  errorCode?: 'AI_PROVIDER_NOT_CONFIGURED' | 'GENERATION_FAILED' | 'INVALID_REQUEST';
  error?: string;
  summary: string;
  modelUsed?: string;
}

export class GodexModelProvider {
  private static instance: GodexModelProvider | null = null;

  public static getInstance(): GodexModelProvider {
    if (!GodexModelProvider.instance) {
      GodexModelProvider.instance = new GodexModelProvider();
    }
    return GodexModelProvider.instance;
  }

  /**
   * Generates a complete application artifact based on natural language intent.
   */
  public async generateApplication(request: GodexGenerationRequest): Promise<GodexGenerationResult> {
    const { operationId, userPrompt, existingFiles, workspaceContext, model } = request;

    if (!userPrompt || !userPrompt.trim()) {
      return {
        success: false,
        operationId,
        errorCode: 'INVALID_REQUEST',
        error: 'Empty prompt provided',
        summary: 'Cannot generate application without a prompt.'
      };
    }

    if (typeof window !== 'undefined' || process.env.API_BASE_URL) {
      try {
        // 1. Dispatch to server-side AI artifact generation endpoint
        const baseUrl = typeof window !== 'undefined' ? '' : (process.env.API_BASE_URL || 'http://localhost:3000');
        const controller = new AbortController();
        // Application generation is a long-running task; a 2.5s timeout was
        // prematurely abandoning valid model responses and selecting canned templates.
        const timeoutMs = 60_000;
        const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
        let response: Response;
        try {
          response = await fetch(`${baseUrl}/api/ai/generate-artifact`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              operationId,
              userPrompt,
              existingFiles,
              workspaceContext,
              model
            }),
            signal: controller.signal
          });
        } finally {
          clearTimeout(timeoutId);
        }

        if (response.ok) {
          const data = await response.json();
          if (data.success && data.artifact) {
            return {
              success: true,
              operationId,
              artifact: {
                ...data.artifact,
                operationId // Ensure authoritative operationId consistency
              },
              summary: data.summary || `Generated application "${data.artifact.name}" matching request.`,
              modelUsed: data.modelUsed
            };
          }

          if (data.errorCode === 'AI_PROVIDER_NOT_CONFIGURED') {
            return {
              success: false,
              operationId,
              errorCode: 'AI_PROVIDER_NOT_CONFIGURED',
              error: data.error || 'AI Provider is not configured (missing API credentials)',
              summary: 'GENERATION NOT CONFIGURED: AI Provider is not configured.'
            };
          }
        }
      } catch (netErr) {
        console.warn('Backend artifact endpoint unavailable, evaluating client-side generation:', netErr);
      }
    }

    // 2. High-Fidelity Client-Side Fallback Synthesizer for arbitrary and specialized requests
    const clientSynthesized = this.synthesizeClientArtifact(operationId, userPrompt, existingFiles);
    if (clientSynthesized) {
      return {
        success: true,
        operationId,
        artifact: clientSynthesized.artifact,
        summary: clientSynthesized.summary,
        modelUsed: 'godex-deterministic-template-synthesizer'
      };
    }

    // 3. If completely unserviceable, return explicit error (NEVER CALCULATOR)
    return {
      success: false,
      operationId,
      errorCode: 'AI_PROVIDER_NOT_CONFIGURED',
      error: 'AI_PROVIDER_NOT_CONFIGURED',
      summary: 'GENERATION NOT CONFIGURED: Model provider is unavailable.'
    };
  }

  /**
   * Deterministic client-side semantic synthesizer for arbitrary and domain requests
   * (e.g. Project Management, ProfileCard, WeatherApp, RacingGame, Portfolio, Universal Apps).
   * Strictly avoids any Calculator generation.
   */
  private synthesizeClientArtifact(
    operationId: string,
    prompt: string,
    existingFiles: Record<string, string>
  ): { artifact: GeneratedArtifact; summary: string } | null {
    const synthesized = synthesizeDomainApplication(prompt, existingFiles);
    if (!synthesized || !synthesized.reactCode) {
      return null;
    }

    return {
      artifact: {
        id: `art-${operationId}`,
        operationId,
        name: synthesized.name,
        description: synthesized.description,
        files: synthesized.files,
        entryFile: synthesized.entryFile,
        reactCode: synthesized.reactCode,
        createdAt: Date.now()
      },
      summary: synthesized.summary
    };
  }
}
