import { getLunarDate } from './lunar-calendar.js';
import { scheduleCompetitionCalendar } from './competition-calendar.js';
import { LEGACY_GALAXIES } from './legacy-catalog.js';

export const LUNAR_CUP_ID = 'coupe-lunaire';
export const LUNAR_CUP_NAME = 'Coupe Lunaire — AGD';

/** Règlement : 16 meilleures sélections galactiques, 4 groupes de 4, puis quarts / demi / finale.
 *  Cycle sexennal : saison % 6 === 1 (séparée des autres AGD par une saison vide). */
export const LUNAR_GALAXIES = Object.freeze(
  [...LEGACY_GALAXIES].sort((a, b) => (b.level || 0) - (a.level || 0)).slice(0, 16).map(g => g.name)
);

export const LUNAR_ROUND_DAYS = Object.freeze([
  // Phase de groupes (3 journées) puis knockout
  330, 337, 344, // groupes
  349, 353, 356  // quarts, demi, finale
]);

const GROUP_NAMES = Object.freeze(['Groupe A', 'Groupe B', 'Groupe C', 'Groupe D']);
const KO_LABELS = Object.freeze(['Quarts de finale', 'Demi-finales', 'Finale']);

function hash(text) {
  let h = 2166136261;
  for (const ch of String(text)) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
function seededOrder(ids, seed) {
  return [...ids].sort((a, b) => hash(`${seed}|${a}`) - hash(`${seed}|${b}`) || String(a).localeCompare(String(b)));
}

function makeFixture(state, round, home, away, index, label) {
  return {
    id: `S${state.season}:${LUNAR_CUP_ID}:R${round}:${index}:${home}:${away}`,
    season: state.season,
    divisionId: null,
    competitionId: LUNAR_CUP_ID,
    competitionName: LUNAR_CUP_NAME,
    round,
    roundLabel: label,
    home,
    away,
    venueType: 'galactic-neutral',
    homeAdvantage: false,
    status: 'scheduled',
    score: null,
    playedAt: null,
    arenaId: 'terrestrial',
    scheduleAuthority: 'AGD'
  };
}

function isLunarCupSeason(season) {
  return Number(season) % 6 === 1;
}

export function createLunarCupSeason(state) {
  const cup = state.competitions.find(c => c.id === LUNAR_CUP_ID);
  if (!cup) throw new Error('Coupe Lunaire absente du registre');

  if (!isLunarCupSeason(state.season)) {
    if (cup.season !== state.season) {
      cup.season = state.season;
      cup.status = 'pending';
      cup.phase = 'waiting-cycle';
      cup.groups = [];
      cup.rounds = [];
      cup.fixtures = [];
      cup.championId = null;
    }
    cup.history ??= [];
    cup.format = { frequency: 6, participants: 16, groups: 4, source: 'reglement-officiel-sexennal' };
    return [];
  }

  if (cup.season === state.season && cup.status !== 'pending' && cup.groups?.length === 4) {
    return cup.fixtures.map(id => state.calendar.fixtures.find(f => f.id === id)).filter(Boolean);
  }

  const galaxies = seededOrder([...LUNAR_GALAXIES], `LUNAR|${state.season}`);
  const groups = GROUP_NAMES.map((name, i) => {
    const teams = galaxies.slice(i * 4, i * 4 + 4);
    const group = {
      name,
      teams: [...teams],
      table: teams.map(galaxyId => ({
        galaxyId, played: 0, won: 0, drawn: 0, lost: 0, goalsFor: 0, goalsAgainst: 0, points: 0
      })),
      matchdays: []
    };
    // 3 journées de poule
    const [a, b, c, d] = teams;
    const pairings = [[[a, b], [c, d]], [[a, c], [d, b]], [[a, d], [b, c]]];
    group.matchdays = pairings.map((pairs, day) =>
      pairs.map(([home, away], pi) => makeFixture(state, day + 1, home, away, i * 2 + pi + 1, `${name} — journée ${day + 1}`))
    );
    return group;
  });

  const allGroupFixtures = groups.flatMap(g => g.matchdays.flat());
  cup.season = state.season;
  cup.status = 'in-progress';
  cup.phase = 'groups';
  cup.format = {
    type: 'four-groups-and-knockout',
    frequency: 6,
    participants: 16,
    groups: 4,
    galaxiesPerGroup: 4,
    groupMatches: 24,
    qualifiedPerGroup: 2,
    quarterfinals: 4,
    semifinals: 2,
    final: 1,
    totalMatches: 31,
    source: 'reglement-officiel-16-groupes'
  };
  cup.galaxies = [...LUNAR_GALAXIES];
  cup.groups = groups;
  cup.rounds = [{
    number: 1,
    label: 'Phase de groupes',
    participants: [...galaxies],
    fixtureIds: allGroupFixtures.map(f => f.id),
    completed: false,
    advancedGalaxyIds: []
  }];
  cup.fixtures = allGroupFixtures.map(f => f.id);
  cup.championId = null;
  cup.history ??= [];
  state.calendar.fixtures.push(...allGroupFixtures);
  scheduleCompetitionCalendar(state);
  return allGroupFixtures;
}

function sortGroupTable(group) {
  return [...group.table].sort((a, b) =>
    b.points - a.points ||
    (b.goalsFor - b.goalsAgainst) - (a.goalsFor - a.goalsAgainst) ||
    b.goalsFor - a.goalsFor ||
    String(a.galaxyId).localeCompare(String(b.galaxyId))
  );
}

function updateGroupTables(cup, state) {
  for (const group of cup.groups || []) {
    for (const row of group.table) {
      Object.assign(row, { played: 0, won: 0, drawn: 0, lost: 0, goalsFor: 0, goalsAgainst: 0, points: 0 });
    }
    const map = new Map(group.table.map(r => [r.galaxyId, r]));
    for (const f of group.matchdays.flat()) {
      const live = state.calendar.fixtures.find(x => x.id === f.id);
      if (!live || live.status !== 'played' || !Array.isArray(live.score)) continue;
      const [hs, as] = live.score;
      const h = map.get(live.home), a = map.get(live.away);
      if (!h || !a) continue;
      h.played++; a.played++;
      h.goalsFor += hs; h.goalsAgainst += as;
      a.goalsFor += as; a.goalsAgainst += hs;
      if (hs > as) { h.won++; h.points += 3; a.lost++; }
      else if (hs < as) { a.won++; a.points += 3; h.lost++; }
      else { h.drawn++; a.drawn++; h.points++; a.points++; }
    }
  }
}

function startKnockout(state, cup) {
  updateGroupTables(cup, state);
  const qualified = cup.groups.flatMap(g => sortGroupTable(g).slice(0, 2).map(r => r.galaxyId));
  if (qualified.length !== 8) throw new Error('La phase de groupes doit produire 8 qualifiés (2 par groupe)');
  cup.phase = 'knockout';
  // Croisement A1-B2, B1-A2, C1-D2, D1-C2
  const tables = cup.groups.map(g => sortGroupTable(g));
  const pairs = [
    [tables[0][0].galaxyId, tables[1][1].galaxyId],
    [tables[1][0].galaxyId, tables[0][1].galaxyId],
    [tables[2][0].galaxyId, tables[3][1].galaxyId],
    [tables[3][0].galaxyId, tables[2][1].galaxyId]
  ];
  return pushKnockoutRound(state, cup, 2, KO_LABELS[0], pairs, qualified);
}

function pushKnockoutRound(state, cup, roundNumber, label, pairs, participants) {
  const fixtures = pairs.map(([home, away], i) => makeFixture(state, roundNumber, home, away, i + 1, label));
  const row = {
    number: roundNumber,
    label,
    participants: [...participants],
    fixtureIds: fixtures.map(f => f.id),
    completed: false,
    advancedGalaxyIds: []
  };
  cup.rounds.push(row);
  cup.fixtures.push(...row.fixtureIds);
  state.calendar.fixtures.push(...fixtures);
  scheduleCompetitionCalendar(state);
  return fixtures;
}

export function resolveLunarCupDraw(fixture) {
  return hash(`${fixture.id}|lunar-tie-break`) % 2 ? fixture.home : fixture.away;
}

export function recordLunarCupResult(state, fixtureId, homeScore, awayScore, { winnerId = null, matchDetails = {} } = {}) {
  const fixture = state.calendar.fixtures.find(f => f.id === fixtureId && f.competitionId === LUNAR_CUP_ID);
  if (!fixture) throw new Error('Rencontre de Coupe Lunaire introuvable');
  if (fixture.status === 'played' || state.calendar.processedFixtureIds.includes(fixtureId)) {
    return { accepted: false, nextFixtures: [] };
  }
  if (fixture.scheduledDay && Number(state.calendar.currentDay || 1) < Number(fixture.scheduledDay)) {
    throw new Error(`Cette rencontre est programmée au jour ${fixture.scheduledDay} du calendrier général`);
  }
  if (![homeScore, awayScore].every(n => Number.isInteger(n) && n >= 0)) throw new Error('Score de Coupe Lunaire invalide');

  const cup = state.competitions.find(c => c.id === LUNAR_CUP_ID);
  const round = cup.rounds.find(r => r.fixtureIds.includes(fixtureId));
  if (!round) throw new Error('Tour de Coupe Lunaire introuvable');

  if (homeScore === awayScore) winnerId = resolveLunarCupDraw(fixture);
  else winnerId = homeScore > awayScore ? fixture.home : fixture.away;
  if (![fixture.home, fixture.away].includes(winnerId)) throw new Error('Vainqueur absent de la rencontre');

  fixture.score = [homeScore, awayScore];
  fixture.winnerId = winnerId;
  fixture.status = 'played';
  fixture.playedAt = { season: state.season, ...getLunarDate(state.calendar?.currentDay || state.day || 1) };
  fixture.matchDetails = { ...matchDetails, winnerId, tieBreak: homeScore === awayScore ? 'deterministic-draw-decision' : null };
  state.calendar.processedFixtureIds ??= [];
  state.calendar.processedFixtureIds.push(fixtureId);

  if (!round.fixtureIds.every(id => state.calendar.fixtures.find(f => f.id === id)?.status === 'played')) {
    return { accepted: true, nextFixtures: [] };
  }
  round.completed = true;

  // Fin de phase de groupes → knockout
  if (round.number === 1 && cup.phase === 'groups') {
    const next = startKnockout(state, cup);
    return { accepted: true, nextFixtures: next };
  }

  round.advancedGalaxyIds = round.fixtureIds.map(id => state.calendar.fixtures.find(f => f.id === id)?.winnerId).filter(Boolean);

  // Finale (round 4)
  if (round.number === 4 || round.advancedGalaxyIds.length === 1) {
    cup.status = 'completed';
    cup.phase = 'completed';
    cup.championId = round.advancedGalaxyIds[0] || null;
    cup.completedAtSeason = state.season;
    cup.history ??= [];
    cup.history.unshift({ season: state.season, championId: cup.championId, fixtureIds: [...cup.fixtures] });
    cup.history = cup.history.slice(0, 30);
    scheduleCompetitionCalendar(state);
    return { accepted: true, nextFixtures: [], championId: cup.championId };
  }

  // Tours KO suivants
  const nextRound = round.number + 1;
  const label = KO_LABELS[nextRound - 2] || `Tour ${nextRound}`;
  const ordered = seededOrder(round.advancedGalaxyIds, `LUNAR|${state.season}|KO|${nextRound}`);
  const pairs = [];
  for (let i = 0; i < ordered.length; i += 2) pairs.push([ordered[i], ordered[i + 1]]);
  const next = pushKnockoutRound(state, cup, nextRound, label, pairs, round.advancedGalaxyIds);
  return { accepted: true, nextFixtures: next };
}

export function getLunarCupStatus(state) {
  const cup = state.competitions.find(c => c.id === LUNAR_CUP_ID);
  if (!cup) return null;
  const r = cup.rounds?.find(x => !x.completed) || cup.rounds?.at(-1);
  return {
    name: LUNAR_CUP_NAME,
    status: cup.status,
    phase: cup.phase,
    participantCount: cup.format?.participants || 16,
    groupCount: cup.format?.groups || 4,
    round: r?.number || 0,
    roundLabel: r?.label || (cup.phase === 'waiting-cycle' ? 'En attente du cycle sexennal' : 'À venir'),
    pendingFixtures: r?.fixtureIds?.filter(id => state.calendar.fixtures.find(f => f.id === id)?.status !== 'played').length || 0,
    championId: cup.championId || null,
    edition: cup.season,
    totalMatches: cup.format?.totalMatches || 31,
    history: cup.history || []
  };
}

export function validateLunarCup(state) {
  const cup = state.competitions.find(c => c.id === LUNAR_CUP_ID);
  if (!cup) throw new Error('Coupe Lunaire manquante');
  if (cup.status === 'in-progress' || cup.status === 'completed') {
    if (cup.phase === 'groups' || cup.phase === 'knockout' || cup.phase === 'completed') {
      if (cup.format?.participants !== 16) throw new Error('Coupe Lunaire : 16 galaxies attendues');
      if (cup.groups && cup.groups.length !== 4) throw new Error('Coupe Lunaire : 4 groupes attendus');
    }
    if (new Set(cup.fixtures || []).size !== (cup.fixtures || []).length) throw new Error('Rencontre dupliquée dans la Coupe Lunaire');
  }
  return true;
}

/** Rencontre de la galaxie du joueur encore à jouer, s'il en a choisi une. */
export function getLunarUserFixture(state) {
  const galaxy = state.userGalaxyId;
  if (!galaxy) return null;
  return (state.calendar?.fixtures || []).find(f =>
    f.competitionId === LUNAR_CUP_ID &&
    f.status === 'scheduled' &&
    (f.home === galaxy || f.away === galaxy)
  ) || null;
}
