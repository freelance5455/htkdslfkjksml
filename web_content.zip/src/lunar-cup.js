import { getLunarDate } from './lunar-calendar.js';
import { scheduleCompetitionCalendar } from './competition-calendar.js';

export const LUNAR_CUP_ID = 'coupe-lunaire';
export const LUNAR_CUP_NAME = 'Coupe Lunaire — AGD';
// Participants et formule repris du moteur V116 : huit représentants, trois tours.
export const LUNAR_GALAXIES = Object.freeze([
  'Astra Nova','Orion','Andromède','Nébula','Vega','Solarys','Éclipse','Lyris'
]);
// Scheduler V116 V92 : mois 12, ouverture au jour lunaire 6, puis un tour tous les sept jours.
export const LUNAR_ROUND_DAYS = Object.freeze([342,349,356]);
const LABELS = Object.freeze(['Quarts de finale','Demi-finales','Finale']);
function hash(text){let h=2166136261;for(const ch of String(text)){h^=ch.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;}
function makeFixture(state,round,home,away,index){
  return {id:`S${state.season}:${LUNAR_CUP_ID}:R${round}:${index}:${home}:${away}`,season:state.season,divisionId:null,competitionId:LUNAR_CUP_ID,competitionName:LUNAR_CUP_NAME,round,roundLabel:LABELS[round-1],home,away,venueType:'galactic-neutral',homeAdvantage:false,status:'scheduled',score:null,playedAt:null,arenaId:'terrestrial',scheduleAuthority:'AGD'};
}
function pushRound(state,cup,round,participants,pairs){
  const fixtures=pairs.map(([home,away],i)=>makeFixture(state,round,home,away,i+1));
  const row={number:round,label:LABELS[round-1],participants:[...participants],fixtureIds:fixtures.map(f=>f.id),completed:false,advancedGalaxyIds:[]};
  cup.rounds.push(row);cup.fixtures.push(...row.fixtureIds);state.calendar.fixtures.push(...fixtures);scheduleCompetitionCalendar(state);return fixtures;
}
export function createLunarCupSeason(state){
  const cup=state.competitions.find(c=>c.id===LUNAR_CUP_ID);if(!cup)throw new Error('Coupe Lunaire absente du registre');
  if(cup.season===state.season&&cup.status!=='pending'&&cup.rounds?.length)return cup.rounds.flatMap(r=>r.fixtureIds.map(id=>state.calendar.fixtures.find(f=>f.id===id)).filter(Boolean));
  cup.season=state.season;cup.status='in-progress';cup.phase='knockout';cup.championId=null;
  cup.format={type:'galaxy-single-elimination',participants:8,quarterfinals:4,semifinals:2,final:1,totalMatches:7,smallFinal:false,frequency:'annual',month:12,source:'V116-static-audit'};
  cup.galaxies=[...LUNAR_GALAXIES];cup.rounds=[];cup.fixtures=[];cup.history??=[];
  const pairs=[];for(let i=0;i<LUNAR_GALAXIES.length;i+=2)pairs.push([LUNAR_GALAXIES[i],LUNAR_GALAXIES[i+1]]);
  return pushRound(state,cup,1,LUNAR_GALAXIES,pairs);
}
export function resolveLunarCupDraw(fixture){return hash(`${fixture.id}|V116-lunar-tie-break`)%2?fixture.home:fixture.away;}
export function recordLunarCupResult(state,fixtureId,homeScore,awayScore,{winnerId=null,matchDetails={}}={}){
  const fixture=state.calendar.fixtures.find(f=>f.id===fixtureId&&f.competitionId===LUNAR_CUP_ID);if(!fixture)throw new Error('Rencontre de Coupe Lunaire introuvable');
  if(fixture.status==='played'||state.calendar.processedFixtureIds.includes(fixtureId))return{accepted:false,nextFixtures:[]};
  if(fixture.scheduledDay&&Number(state.calendar.currentDay||1)<Number(fixture.scheduledDay))throw new Error(`Cette rencontre est programmée au jour ${fixture.scheduledDay} du calendrier général`);
  if(![homeScore,awayScore].every(n=>Number.isInteger(n)&&n>=0))throw new Error('Score de Coupe Lunaire invalide');
  const cup=state.competitions.find(c=>c.id===LUNAR_CUP_ID),round=cup.rounds.find(r=>r.fixtureIds.includes(fixtureId));if(!round)throw new Error('Tour de Coupe Lunaire introuvable');
  if(homeScore===awayScore)winnerId=resolveLunarCupDraw(fixture);else winnerId=homeScore>awayScore?fixture.home:fixture.away;
  if(![fixture.home,fixture.away].includes(winnerId))throw new Error('Vainqueur absent de la rencontre');
  fixture.score=[homeScore,awayScore];fixture.winnerId=winnerId;fixture.status='played';fixture.playedAt={ season: state.season, ...getLunarDate(state.calendar?.currentDay || state.day || 1) };fixture.matchDetails={...matchDetails,winnerId,tieBreak:homeScore===awayScore?'V116-deterministic-draw-decision':null};
  state.calendar.processedFixtureIds??=[];state.calendar.processedFixtureIds.push(fixtureId);
  if(!round.fixtureIds.every(id=>state.calendar.fixtures.find(f=>f.id===id)?.status==='played'))return{accepted:true,nextFixtures:[]};
  round.completed=true;round.advancedGalaxyIds=round.fixtureIds.map(id=>state.calendar.fixtures.find(f=>f.id===id).winnerId);
  if(round.number===3){
    cup.status='completed';cup.phase='completed';cup.championId=round.advancedGalaxyIds[0]||null;cup.completedAtSeason=state.season;
    cup.history??=[];cup.history.unshift({season:state.season,championId:cup.championId,fixtureIds:[...cup.fixtures]});cup.history=cup.history.slice(0,30);scheduleCompetitionCalendar(state);
    return{accepted:true,nextFixtures:[],championId:cup.championId};
  }
  const winners=round.advancedGalaxyIds,pairs=round.number===1?[[winners[0],winners[1]],[winners[2],winners[3]]]:[[winners[0],winners[1]]];
  const next=pushRound(state,cup,round.number+1,winners,pairs);return{accepted:true,nextFixtures:next,championId:null};
}
export function getLunarCupStatus(state){
  const cup=state.competitions.find(c=>c.id===LUNAR_CUP_ID);if(!cup)return null;const round=cup.rounds?.find(r=>!r.completed)||cup.rounds?.at(-1)||null;
  return{name:LUNAR_CUP_NAME,status:cup.status,phase:cup.phase||'pending',participantCount:cup.format?.participants||0,round:round?.number||0,roundLabel:round?.label||'À venir',pendingFixtures:round?.fixtureIds.filter(id=>state.calendar.fixtures.find(f=>f.id===id)?.status!=='played').length||0,championId:cup.championId||null,totalMatches:cup.format?.totalMatches||0,history:cup.history||[]};
}
export function getLunarUserFixture(state,userGalaxyId=state.userGalaxyId){
  if(!userGalaxyId)return null;const cup=state.competitions.find(c=>c.id===LUNAR_CUP_ID),round=cup?.rounds?.find(r=>!r.completed);
  if(!round||cup.status!=='in-progress'||!round.participants.includes(userGalaxyId))return null;
  const fixture=round.fixtureIds.map(id=>state.calendar.fixtures.find(f=>f.id===id)).find(f=>f&&f.status==='scheduled'&&(f.home===userGalaxyId||f.away===userGalaxyId))||null;return fixture&&Number(state.calendar.currentDay||1)>=Number(fixture.scheduledDay||Number.MAX_SAFE_INTEGER)?fixture:null;
}
export function validateLunarCup(state){
  const cup=state.competitions.find(c=>c.id===LUNAR_CUP_ID);if(!cup)throw new Error('Coupe Lunaire manquante');
  if(cup.status==='in-progress'||cup.status==='completed'){
    if(cup.galaxies?.length!==8||cup.format?.participants!==8||cup.format?.totalMatches!==7)throw new Error('Format historique de Coupe Lunaire invalide');
    if(new Set(cup.fixtures).size!==cup.fixtures.length)throw new Error('Rencontre dupliquée en Coupe Lunaire');
    for(const id of cup.fixtures)if(!state.calendar.fixtures.some(f=>f.id===id&&f.competitionId===LUNAR_CUP_ID))throw new Error(`Rencontre lunaire absente du calendrier central : ${id}`);
    if(cup.rounds.length>3||cup.rounds.some((r,i)=>r.number!==i+1)||cup.rounds.some((r,i)=>r.fixtureIds.length!==[4,2,1][i]))throw new Error('Progression des tours de Coupe Lunaire invalide');
    if(cup.status==='completed'&&!cup.championId)throw new Error('Champion AGD manquant');
  }return true;
}
