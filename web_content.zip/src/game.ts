// Core Water Sort rules. Tubes are stored bottom-to-top, with four units of capacity.
export const CAPACITY = 4;
export const TOTAL_LEVELS = 120;

export type Difficulty = "Easy" | "Medium" | "Hard";
export type SkinId = "classic" | "crystal" | "bamboo" | "neon" | "frost" | "sunset";
export type TubeState = number[][];

export interface Move {
  from: number;
  to: number;
  amount: number;
  color: number;
}

export interface LevelDefinition {
  id: number;
  difficulty: Difficulty;
  colorCount: number;
  tubes: TubeState;
  par: number;
  /** A genuine path back to the solved state, retained from generation. */
  solution: Move[];
}

export interface LevelResult {
  level: number;
  moves: number;
  seconds: number;
  stars: number;
  score: number;
}

// Player-chosen palette: 🟥🟧🟨🟩🟦🟪🟫⬛⬜
// Ordered so early levels get the most distinct colors first.
export const LIQUID_COLORS = [
  { name: "Red", base: "#e8322f", light: "#ff8a80", dark: "#8e1010", glow: "#ff5a52" },
  { name: "Blue", base: "#2f6bff", light: "#8fb3ff", dark: "#12318f", glow: "#5a8cff" },
  { name: "Yellow", base: "#ffd21f", light: "#fff3a0", dark: "#b38600", glow: "#ffe45c" },
  { name: "Green", base: "#2fbf4a", light: "#93f0a0", dark: "#0f6b24", glow: "#55dd6d" },
  { name: "Orange", base: "#ff8a1f", light: "#ffc888", dark: "#a8460a", glow: "#ffa552" },
  { name: "Purple", base: "#8e3fe0", light: "#cfa3ff", dark: "#4a1491", glow: "#a964f0" },
  { name: "Brown", base: "#8b5428", light: "#d4a273", dark: "#4a2a10", glow: "#a86d3c" },
  { name: "White", base: "#eef3f6", light: "#ffffff", dark: "#9aa9b3", glow: "#ffffff" },
  { name: "Black", base: "#2a2e35", light: "#7d8794", dark: "#0b0d10", glow: "#4a525e" },
];

export const TUBE_SKINS: Array<{
  id: SkinId;
  name: string;
  note: string;
  completed: number;
  stars: number;
}> = [
  { id: "classic", name: "Classic Glass", note: "Thick, clear hand-blown glass", completed: 0, stars: 0 },
  { id: "crystal", name: "Crystal Glass", note: "Prismatic facets and bright rims", completed: 6, stars: 12 },
  { id: "bamboo", name: "Bamboo", note: "Warm natural nodes and grain", completed: 18, stars: 36 },
  { id: "frost", name: "Frost Glass", note: "Icy chill with snowflake glints", completed: 28, stars: 56 },
  { id: "neon", name: "Neon", note: "Bioluminescent deep-sea glow", completed: 40, stars: 80 },
  { id: "sunset", name: "Sunset Amber", note: "Golden-hour warmth in glass", completed: 55, stars: 110 },
];

export function getDifficulty(level: number): Difficulty {
  if (level <= 40) return "Easy";
  if (level <= 80) return "Medium";
  return "Hard";
}

export function getLevelColorCount(level: number): number {
  // Easy 3→6, Medium 6→8, Hard 8→9 (all nine colors). Hard levels get
  // extra difficulty from deeper scrambling rather than more colors.
  // Every level has at least 8 glasses (6 colors + 2 empty).
  if (level <= 40) return 6;
  if (level <= 80) return Math.min(8, 6 + Math.floor((level - 41) / 14));
  return Math.min(9, 8 + Math.floor((level - 81) / 10));
}

function mulberry32(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function topGroup(tube: number[]): { color: number; count: number } {
  if (!tube.length) return { color: -1, count: 0 };
  const color = tube[tube.length - 1];
  let count = 1;
  for (let i = tube.length - 2; i >= 0 && tube[i] === color; i -= 1) count += 1;
  return { color, count };
}

export function isTubeComplete(tube: number[]): boolean {
  return tube.length === CAPACITY && tube.every((unit) => unit === tube[0]);
}

export function isSolved(tubes: TubeState): boolean {
  return tubes.every((tube) => tube.length === 0 || isTubeComplete(tube));
}

export function getPourAmount(tubes: TubeState, from: number, to: number): number {
  if (from === to) return 0;
  const source = tubes[from];
  const target = tubes[to];
  if (!source || !target || source.length === 0 || target.length >= CAPACITY) return 0;
  const { color, count } = topGroup(source);
  if (target.length > 0 && target[target.length - 1] !== color) return 0;
  return Math.min(count, CAPACITY - target.length);
}

export function getValidMoves(tubes: TubeState): Move[] {
  const moves: Move[] = [];
  for (let from = 0; from < tubes.length; from += 1) {
    if (!tubes[from].length) continue;
    const { color } = topGroup(tubes[from]);
    for (let to = 0; to < tubes.length; to += 1) {
      const amount = getPourAmount(tubes, from, to);
      if (amount > 0) moves.push({ from, to, amount, color });
    }
  }
  return moves;
}

export function applyMove(tubes: TubeState, move: Move): TubeState {
  const next = tubes.map((tube) => [...tube]);
  const amount = Math.min(move.amount, getPourAmount(tubes, move.from, move.to));
  if (amount > 0) next[move.to].push(...next[move.from].splice(-amount));
  return next;
}

function countBlocks(tubes: TubeState): number {
  return tubes.reduce((total, tube) => {
    let blocks = 0;
    tube.forEach((color, index) => {
      if (index === 0 || tube[index - 1] !== color) blocks += 1;
    });
    return total + blocks;
  }, 0);
}

function mixedTubeCount(tubes: TubeState): number {
  return tubes.filter((tube) => new Set(tube).size > 1).length;
}

/**
 * Scrambling runs backwards from a solved board. Every reverse operation is
 * constrained so its exact inverse is a legal pour. Therefore every generated
 * board has a known solution rather than relying on random shuffling luck.
 */
function scramble(level: number, colorCount: number, attempt: number) {
  const random = mulberry32(level * 7919 + colorCount * 131 + attempt * 104729);
  const tubes: TubeState = Array.from({ length: colorCount + 2 }, (_, index) =>
    index < colorCount ? Array(CAPACITY).fill(index) : [],
  );
  const history: Array<{ from: number; to: number; amount: number; color: number }> = [];
  // Early Easy levels scramble lightly so 8 glasses still feel friendly.
  const steps = level <= 40
    ? 20 + Math.floor(level * 2.2)
    : 44 + colorCount * 13 + (level > 80 ? 40 + Math.floor((level - 80) / 2) : 12);
  let last: { from: number; to: number } | null = null;

  for (let step = 0; step < steps; step += 1) {
    const candidates: Array<{ from: number; to: number; amount: number; weight: number }> = [];
    for (let from = 0; from < tubes.length; from += 1) {
      const source = tubes[from];
      if (!source.length) continue;
      const { color, count } = topGroup(source);
      for (let to = 0; to < tubes.length; to += 1) {
        const target = tubes[to];
        if (from === to || target.length >= CAPACITY) continue;
        if (target.length && target[target.length - 1] === color) continue;
        if (last && from === last.to && to === last.from) continue;
        const max = Math.min(count, CAPACITY - target.length);
        for (let amount = 1; amount <= max; amount += 1) {
          // After removing this group, the source must be empty or still expose
          // the same color; otherwise the inverse pour would be illegal.
          if (!(amount < count || amount === source.length)) continue;
          // Moving a whole uniform tube into an empty one changes nothing useful.
          if (amount === source.length && count === source.length && target.length === 0) continue;
          const createsBoundary = target.length > 0 && target[target.length - 1] !== color;
          candidates.push({ from, to, amount, weight: createsBoundary ? 5 : 1 });
        }
      }
    }
    if (!candidates.length) break;
    const totalWeight = candidates.reduce((sum, item) => sum + item.weight, 0);
    let roll = random() * totalWeight;
    let choice = candidates[candidates.length - 1];
    for (const candidate of candidates) {
      roll -= candidate.weight;
      if (roll <= 0) {
        choice = candidate;
        break;
      }
    }
    const color = tubes[choice.from][tubes[choice.from].length - 1];
    const moved = tubes[choice.from].splice(-choice.amount);
    tubes[choice.to].push(...moved);
    history.push({ from: choice.from, to: choice.to, amount: choice.amount, color });
    last = choice;
  }

  const solution: Move[] = [];
  for (let i = history.length - 1; i >= 0; i -= 1) {
    const item = history[i];
    solution.push({ from: item.to, to: item.from, amount: item.amount, color: item.color });
  }
  return { tubes, solution };
}

const levelCache = new Map<number, LevelDefinition>();

export function getLevel(level: number): LevelDefinition {
  const id = Math.max(1, Math.min(TOTAL_LEVELS, Math.floor(level)));
  const cached = levelCache.get(id);
  if (cached) return cached;
  const colorCount = getLevelColorCount(id);
  if (id === -1) {
    const tutorial: LevelDefinition = {
      id: 1,
      difficulty: "Easy",
      colorCount: 3,
      tubes: [[0, 0, 1, 1], [1, 1, 2, 2], [2, 2, 0, 0], [], []],
      par: 4,
      solution: [
        { from: 0, to: 3, amount: 2, color: 1 },
        { from: 2, to: 0, amount: 2, color: 0 },
        { from: 1, to: 2, amount: 2, color: 2 },
        { from: 3, to: 1, amount: 2, color: 1 },
      ],
    };
    levelCache.set(id, tutorial);
    return tutorial;
  }
  let best: ReturnType<typeof scramble> | null = null;
  let bestQuality = -Infinity;

  for (let attempt = 0; attempt < 7; attempt += 1) {
    const candidate = scramble(id, colorCount, attempt);
    const mixed = mixedTubeCount(candidate.tubes);
    const blocks = countBlocks(candidate.tubes);
    const solvedTubes = candidate.tubes.filter(isTubeComplete).length;
    const quality = mixed * 18 + blocks * 2 - solvedTubes * 9;
    if (quality > bestQuality) {
      best = candidate;
      bestQuality = quality;
    }
    if (mixed >= colorCount && solvedTubes <= 1 && blocks >= colorCount + 3) break;
  }

  const chosen = best!;
  const blocks = countBlocks(chosen.tubes);
  const difficultyBonus = id > 80 ? 3 : id > 40 ? 1 : 0;
  const definition: LevelDefinition = {
    id,
    difficulty: getDifficulty(id),
    colorCount,
    tubes: chosen.tubes.map((tube) => [...tube]),
    par: Math.max(6, Math.ceil(blocks * 0.9 + colorCount * 1.4 + difficultyBonus)),
    solution: chosen.solution,
  };
  levelCache.set(id, definition);
  return definition;
}

function canonicalKey(tubes: TubeState): string {
  return tubes
    .map((tube) => tube.join(","))
    .sort()
    .join("|");
}

function moveScore(tubes: TubeState, move: Move): number {
  const source = tubes[move.from];
  const target = tubes[move.to];
  const remaining = source.length - move.amount;
  let score = 0;
  if (target.length) score += 36;
  if (target.length + move.amount === CAPACITY) score += 32;
  if (remaining === 0) score += 14;
  if (remaining > 0 && source[remaining - 1] === move.color) score += 8;
  if (!target.length) score -= 8;
  if (new Set(source).size === 1) score -= 14;
  if (isTubeComplete(source) && !target.length) score -= 100;
  return score;
}

/** A bounded, real solver. If a hard tree exceeds the budget, it returns the
 * highest-ranked legal move instead of freezing the game or inventing a move. */
export function findHint(tubes: TubeState): { move: Move | null; fullySolved: boolean } {
  let nodes = 0;
  const budget = 24000;
  const maxDepth = 76;
  const seen = new Map<string, number>();

  function search(state: TubeState, depth: number, previous: Move | null): Move[] | null {
    if (isSolved(state)) return [];
    if (depth >= maxDepth || nodes >= budget) return null;
    nodes += 1;
    const key = canonicalKey(state);
    const oldDepth = seen.get(key);
    if (oldDepth !== undefined && oldDepth <= depth) return null;
    seen.set(key, depth);

    const moves = getValidMoves(state)
      .filter((move) => {
        const source = state[move.from];
        const target = state[move.to];
        if (!target.length && new Set(source).size === 1 && move.amount === source.length) return false;
        if (previous && move.from === previous.to && move.to === previous.from && target.length === 0) return false;
        return true;
      })
      .sort((a, b) => moveScore(state, b) - moveScore(state, a));

    for (const move of moves) {
      if (nodes >= budget) break;
      const tail = search(applyMove(state, move), depth + 1, move);
      if (tail) return [move, ...tail];
    }
    return null;
  }

  const path = search(tubes.map((tube) => [...tube]), 0, null);
  if (path?.length) return { move: path[0], fullySolved: true };
  const legal = getValidMoves(tubes);
  const useful = legal.filter((move) => {
    const source = tubes[move.from];
    return !(tubes[move.to].length === 0 && new Set(source).size === 1 && move.amount === source.length);
  });
  const choices = useful.length ? useful : legal;
  const fallback = choices.sort((a, b) => moveScore(tubes, b) - moveScore(tubes, a))[0] ?? null;
  return { move: fallback, fullySolved: false };
}

export function calculateResult(
  level: number,
  moves: number,
  seconds: number,
  hints: number,
  undos: number,
  extraTubes: number,
): LevelResult {
  const definition = getLevel(level);
  const stars = moves <= definition.par ? 3 : moves <= Math.ceil(definition.par * 1.5) ? 2 : 1;
  const efficiency = Math.max(0, moves - definition.par) * 35;
  const score = Math.max(
    100,
    Math.round(1000 + level * 20 + stars * 250 - efficiency - seconds * 2 - hints * 120 - undos * 60 - extraTubes * 250),
  );
  return { level, moves, seconds, stars, score };
}

export function previewScore(level: number, moves: number, seconds: number, hints: number, undos: number, extraTubes: number) {
  return calculateResult(level, moves, seconds, hints, undos, extraTubes).score;
}

export function skinIsUnlocked(skin: SkinId, completed: number, stars: number): boolean {
  const item = TUBE_SKINS.find((entry) => entry.id === skin)!;
  return completed >= item.completed || stars >= item.stars;
}

export function formatTime(totalSeconds: number): string {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = Math.floor(totalSeconds % 60);
  return `${minutes}:${seconds.toString().padStart(2, "0")}`;
}
