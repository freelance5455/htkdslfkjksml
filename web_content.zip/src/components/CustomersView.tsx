import React, { useMemo, useState } from 'react';
import type { Customer, StoreData } from '../types';
import { fmtDateTime, fmtMoney, uid } from '../utils';
import { Icon } from './Icon';
import { ConfirmModal, Modal } from './SharedUI';

interface CustomersViewProps {
  data: StoreData;
  t: Record<string, string>;
  onSaveCustomer: (cust: Customer, isEdit: boolean) => void;
  onDeleteCustomer: (id: string) => void;
  onCollectDue: (custId: string, amount: number) => void;
  notify: (msg: string, type?: 'success' | 'error') => void;
}

export const CustomersView: React.FC<CustomersViewProps> = ({
  data,
  t,
  onSaveCustomer,
  onDeleteCustomer,
  onCollectDue,
  notify,
}) => {
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Customer | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Customer | null>(null);
  const [form, setForm] = useState({ name: '', phone: '', address: '', dueBalance: 0 });
  const [dueModalCust, setDueModalCust] = useState<Customer | null>(null);
  const [duePay, setDuePay] = useState('');
  const [historyCust, setHistoryCust] = useState<Customer | null>(null);

  const openAdd = () => {
    setEditing(null);
    setForm({ name: '', phone: '', address: '', dueBalance: 0 });
    setModalOpen(true);
  };

  const openEdit = (c: Customer) => {
    setEditing(c);
    setForm({ name: c.name, phone: c.phone || '', address: c.address || '', dueBalance: c.dueBalance || 0 });
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) {
      notify(t.fillRequiredFields, 'error');
      return;
    }
    onSaveCustomer(
      {
        id: editing ? editing.id : uid(),
        name: form.name.trim(),
        phone: form.phone.trim(),
        address: form.address.trim(),
        dueBalance: Number(form.dueBalance || 0),
        totalSpent: editing ? editing.totalSpent : 0,
        isDefault: editing?.isDefault || false,
      },
      !!editing
    );
    setModalOpen(false);
  };

  const handleCollectSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Number(duePay || 0);
    if (amt <= 0 || !dueModalCust) {
      notify(t.fillRequiredFields, 'error');
      return;
    }
    onCollectDue(dueModalCust.id, amt);
    setDueModalCust(null);
    setDuePay('');
  };

  const filteredCustomers = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return data.customers;
    return data.customers.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        (c.phone || '').toLowerCase().includes(q) ||
        (c.address || '').toLowerCase().includes(q)
    );
  }, [data.customers, search]);

  const summary = useMemo(() => {
    const totalDue = data.customers.reduce((s, c) => s + Number(c.dueBalance || 0), 0);
    const totalSpent = data.customers.reduce((s, c) => s + Number(c.totalSpent || 0), 0);
    return { totalDue, totalSpent };
  }, [data.customers]);

  const custSales = useMemo(
    () => (historyCust ? data.sales.filter((s) => s.customerId === historyCust.id) : []),
    [historyCust, data.sales]
  );

  const inputClass =
    'w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition';

  return (
    <div className="space-y-4">
      {/* Customer KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 tabular-nums">
        <div className="surface-card px-4 py-3.5">
          <p className="text-xs font-medium text-slate-500">{t.nav_customers}</p>
          <p className="text-xl font-extrabold text-slate-900 mt-0.5">{data.customers.length}</p>
        </div>
        <div className="surface-card px-4 py-3.5">
          <p className="text-xs font-medium text-slate-500">{t.totalSpent}</p>
          <p className="text-xl font-extrabold text-blue-600 mt-0.5">{fmtMoney(summary.totalSpent)}</p>
        </div>
        <div className="surface-card px-4 py-3.5">
          <p className="text-xs font-medium text-slate-500">{t.outstandingDue}</p>
          <p className={`text-xl font-extrabold mt-0.5 ${summary.totalDue > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
            {fmtMoney(summary.totalDue)}
          </p>
        </div>
      </div>

      {/* Search & Add Customer Bar */}
      <div className="surface-card p-4 flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Icon name="search" className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t.search}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition"
          />
        </div>
        <button type="button" onClick={openAdd} className="btn-primary px-4 py-2.5 text-sm">
          <Icon name="plus" className="w-4 h-4" />
          <span>{t.addCustomer}</span>
        </button>
      </div>

      <div className="surface-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left tabular-nums">
            <thead className="bg-slate-50 text-xs font-semibold text-slate-600 border-b border-slate-200">
              <tr>
                <th className="px-4 py-3 whitespace-nowrap">{t.customerName}</th>
                <th className="px-4 py-3 whitespace-nowrap">{t.phone}</th>
                <th className="px-4 py-3 whitespace-nowrap">{t.address}</th>
                <th className="px-4 py-3 text-right whitespace-nowrap">{t.totalSpent}</th>
                <th className="px-4 py-3 text-right whitespace-nowrap">{t.dueBalance}</th>
                <th className="px-4 py-3 text-right whitespace-nowrap">{t.actions}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-10 text-slate-400">
                    {t.noData}
                  </td>
                </tr>
              ) : (
                filteredCustomers.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-4 py-3 font-bold text-slate-800 whitespace-nowrap">{c.name}</td>
                    <td className="px-4 py-3 text-slate-600 font-mono text-xs whitespace-nowrap">{c.phone || '-'}</td>
                    <td className="px-4 py-3 text-slate-500 min-w-[140px]">{c.address || '-'}</td>
                    <td className="px-4 py-3 text-right font-semibold whitespace-nowrap">{fmtMoney(c.totalSpent)}</td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <span className={`font-bold ${c.dueBalance > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>{fmtMoney(c.dueBalance)}</span>
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1.5">
                        {c.dueBalance > 0 && (
                          <button
                            type="button"
                            onClick={() => {
                              setDueModalCust(c);
                              setDuePay(String(c.dueBalance));
                            }}
                            className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 text-xs font-bold hover:bg-emerald-100 whitespace-nowrap"
                          >
                            {t.collectDue}
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => setHistoryCust(c)}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 text-xs font-semibold hover:bg-slate-200 whitespace-nowrap"
                        >
                          {t.purchaseHistory}
                        </button>
                        {c.id !== 'walk-in' && (
                          <>
                            <button
                              type="button"
                              onClick={() => openEdit(c)}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50"
                            >
                              <Icon name="edit" className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                if (c.id === 'walk-in') {
                                  notify(t.walkInProtected, 'error');
                                  return;
                                }
                                setDeleteTarget(c);
                              }}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50"
                            >
                              <Icon name="trash" className="w-4 h-4" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? t.editCustomer : t.addCustomer}>
        <form noValidate onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.customerName} *</label>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={inputClass} />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.phone}</label>
            <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className={inputClass} />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.address}</label>
            <input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className={inputClass} />
          </div>
          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button type="button" onClick={() => setModalOpen(false)} className="px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold hover:bg-slate-50">
              {t.cancel}
            </button>
            <button type="submit" className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold">
              {t.save}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmModal
        open={!!deleteTarget}
        title={t.confirmDeleteTitle}
        message={`${t.confirmDelete} (${deleteTarget?.name || ''})`}
        confirmLabel={t.delete}
        cancelLabel={t.cancel}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={() => {
          if (deleteTarget) onDeleteCustomer(deleteTarget.id);
          setDeleteTarget(null);
        }}
      />

      <Modal open={!!dueModalCust} onClose={() => setDueModalCust(null)} title={`${t.collectDue} — ${dueModalCust?.name || ''}`}>
        <form noValidate onSubmit={handleCollectSubmit} className="space-y-4">
          <p className="text-sm text-slate-600 tabular-nums">
            {t.dueBalance}: <span className="font-bold text-rose-600">{fmtMoney(dueModalCust?.dueBalance)}</span>
          </p>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.paidAmount}</label>
            <input
              type="number"
              step="0.01"
              min="0.01"
              max={dueModalCust?.dueBalance}
              value={duePay}
              onChange={(e) => setDuePay(e.target.value)}
              className={`${inputClass} font-bold tabular-nums`}
            />
          </div>
          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button type="button" onClick={() => setDueModalCust(null)} className="px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold hover:bg-slate-50">
              {t.cancel}
            </button>
            <button type="submit" className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold">
              {t.confirm}
            </button>
          </div>
        </form>
      </Modal>

      <Modal open={!!historyCust} onClose={() => setHistoryCust(null)} title={`${t.purchaseHistory} — ${historyCust?.name || ''}`} maxWidth="max-w-2xl">
        {custSales.length === 0 ? (
          <p className="text-sm text-slate-400 text-center py-8">{t.noTransactionsYet}</p>
        ) : (
          <div className="divide-y divide-slate-100 tabular-nums">
            {custSales.map((s) => (
              <div key={s.id} className="py-3 flex justify-between text-sm">
                <div>
                  <p className="font-bold text-slate-800 font-mono">{s.invoiceNo}</p>
                  <p className="text-xs text-slate-500">
                    {fmtDateTime(s.date)} · {s.items.length} {t.items}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-bold">{fmtMoney(s.grandTotal)}</p>
                  {s.dueAmount > 0 && (
                    <p className="text-xs text-rose-600">
                      {t.due}: {fmtMoney(s.dueAmount)}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </Modal>
    </div>
  );
};
