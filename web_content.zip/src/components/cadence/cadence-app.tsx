import { useEffect } from "react";
import { ChordStage } from "@/components/cadence/chord-stage";
import { BeatsEditor, ChordPalette, StudioControls } from "@/components/cadence/studio-controls";
import { Transport } from "@/components/cadence/transport";
import { TooltipProvider } from "@/components/ui/tooltip";
import { getAudioEngine } from "@/lib/audio-engine";
import {
  borrowedPalette,
  diatonicPalette,
  keyLabel,
  resolveProgression,
  scaleName,
} from "@/lib/harmony";
import { PRESETS } from "@/lib/harmony";
import { usePlayerStore } from "@/store/player-store";

export function CadenceApp() {
  const hydrate = usePlayerStore((s) => s.hydrate);
  const keyPc = usePlayerStore((s) => s.keyPc);
  const scale = usePlayerStore((s) => s.scale);
  const slots = usePlayerStore((s) => s.slots);
  const sevenths = usePlayerStore((s) => s.sevenths);
  const instrument = usePlayerStore((s) => s.instrument);
  const pattern = usePlayerStore((s) => s.pattern);
  const bpm = usePlayerStore((s) => s.bpm);
  const loop = usePlayerStore((s) => s.loop);
  const volume = usePlayerStore((s) => s.volume);
  const metronome = usePlayerStore((s) => s.metronome);
  const playing = usePlayerStore((s) => s.playing);
  const selectedIndex = usePlayerStore((s) => s.selectedIndex);
  const activeIndex = usePlayerStore((s) => s.activeIndex);

  const setKey = usePlayerStore((s) => s.setKey);
  const setScale = usePlayerStore((s) => s.setScale);
  const setSevenths = usePlayerStore((s) => s.setSevenths);
  const applyPreset = usePlayerStore((s) => s.applyPreset);
  const addChord = usePlayerStore((s) => s.addChord);
  const setSlotNumeral = usePlayerStore((s) => s.setSlotNumeral);
  const setSlotBeats = usePlayerStore((s) => s.setSlotBeats);
  const setDefaultBeats = usePlayerStore((s) => s.setDefaultBeats);
  const setPattern = usePlayerStore((s) => s.setPattern);
  const setInstrument = usePlayerStore((s) => s.setInstrument);
  const setBpm = usePlayerStore((s) => s.setBpm);
  const setVolume = usePlayerStore((s) => s.setVolume);
  const setLoop = usePlayerStore((s) => s.setLoop);
  const setMetronome = usePlayerStore((s) => s.setMetronome);
  const setPlaying = usePlayerStore((s) => s.setPlaying);
  const advanceTo = usePlayerStore((s) => s.advanceTo);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    const engine = getAudioEngine();
    engine.setGetter(() => {
      const s = usePlayerStore.getState();
      return {
        chords: resolveProgression(s.slots, s.keyPc, s.scale, s.sevenths, s.instrument),
        bpm: s.bpm,
        pattern: s.pattern,
        instrument: s.instrument,
        loop: s.loop,
        volume: s.volume,
        metronome: s.metronome,
      };
    });
    engine.setCallbacks({
      onChord: (index) => advanceTo(index),
      onStop: () => setPlaying(false),
    });
  }, [advanceTo, setPlaying]);

  useEffect(() => {
    getAudioEngine().setVolume(volume);
  }, [volume]);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const el = e.target as HTMLElement | null;
      if (el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.isContentEditable)) return;
      if (e.code === "Space") {
        e.preventDefault();
        const engine = getAudioEngine();
        const s = usePlayerStore.getState();
        if (s.playing) {
          engine.stop();
          s.setPlaying(false);
          return;
        }
        void engine.resume().then(() => {
          const next = usePlayerStore.getState();
          next.setPlaying(true);
          engine.start(next.activeIndex);
        });
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const chords = resolveProgression(slots, keyPc, scale, sevenths, instrument);
  const diatonic = diatonicPalette(keyPc, scale, sevenths);
  const borrowed = borrowedPalette(keyPc, scale, sevenths);
  const selected = slots[selectedIndex] ?? slots[0];
  const presetHint =
    PRESETS.find(
      (p) => p.scale === scale && p.numerals.join() === slots.map((s) => s.numeral).join(),
    )?.hint ?? null;

  async function togglePlay() {
    const engine = getAudioEngine();
    const s = usePlayerStore.getState();
    if (s.playing) {
      engine.stop();
      s.setPlaying(false);
      return;
    }
    await engine.resume();
    s.setPlaying(true);
    engine.start(s.activeIndex);
  }

  function stop() {
    getAudioEngine().stop();
    const s = usePlayerStore.getState();
    s.setPlaying(false);
    s.setActiveIndex(0);
  }

  return (
    <TooltipProvider delayDuration={250}>
      <div className="min-h-dvh overflow-x-hidden bg-background text-foreground">
        <header className="mx-auto flex w-full max-w-6xl flex-col gap-3 px-4 pt-6 pb-4 sm:pt-8">
          <div className="flex items-end justify-between gap-3">
            <div>
              <p className="text-xs font-medium tracking-[0.18em] text-muted-foreground uppercase">Studio</p>
              <h1 className="font-serif text-4xl leading-none italic sm:text-5xl">Cadence</h1>
            </div>
            <div className="text-right">
              <p className="font-serif text-lg italic sm:text-2xl">
                {keyLabel(keyPc)} {scaleName(scale)}
              </p>
              <p className="text-xs text-muted-foreground tabular-nums">
                {bpm} BPM · {playing ? `bar ${activeIndex + 1}` : "ready"}
              </p>
            </div>
          </div>
          <p className="max-w-md text-sm text-muted-foreground text-pretty">
            Hear the changes. Loop a progression, swap voicings, and write the next song.
          </p>
        </header>

        <main className="mx-auto grid w-full min-w-0 max-w-6xl gap-4 px-4 pb-44 lg:grid-cols-[minmax(0,280px)_minmax(0,1fr)] lg:gap-6">
          <aside className="order-2 rounded-xl bg-surface p-3 shadow-[var(--shadow-border)] sm:p-4 lg:order-1">
            <StudioControls
              keyPc={keyPc}
              scale={scale}
              sevenths={sevenths}
              presetHint={presetHint}
              onKey={setKey}
              onScale={setScale}
              onSevenths={setSevenths}
              onPreset={applyPreset}
            />
          </aside>

          <div className="order-1 space-y-4 lg:order-2">
            <ChordStage chords={chords} bpm={bpm} pattern={pattern} instrument={instrument} />
            <ChordPalette
              diatonic={diatonic}
              borrowed={borrowed}
              onAdd={addChord}
              onReplace={(numeral) => setSlotNumeral(selectedIndex, numeral)}
            />
            <BeatsEditor
              beats={selected?.beats ?? 4}
              onChange={(beats) => setSlotBeats(selectedIndex, beats)}
              onApplyAll={setDefaultBeats}
            />
          </div>
        </main>

        <Transport
          playing={playing}
          loop={loop}
          bpm={bpm}
          volume={volume}
          metronome={metronome}
          pattern={pattern}
          instrument={instrument}
          onTogglePlay={() => void togglePlay()}
          onStop={stop}
          onLoop={setLoop}
          onBpm={setBpm}
          onVolume={setVolume}
          onMetronome={setMetronome}
          onPattern={setPattern}
          onInstrument={setInstrument}
        />
      </div>
    </TooltipProvider>
  );
}
