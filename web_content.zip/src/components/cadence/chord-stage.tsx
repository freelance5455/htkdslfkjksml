import { useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Copy, GripVertical, Trash2 } from "lucide-react";
import { PianoStrip } from "@/components/cadence/piano-strip";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { ResolvedChord } from "@/lib/harmony";
import { getAudioEngine } from "@/lib/audio-engine";
import type { PatternId } from "@/lib/patterns";
import type { InstrumentId } from "@/lib/harmony";
import { usePlayerStore } from "@/store/player-store";

export function ChordStage({
  chords,
  bpm,
  pattern,
  instrument,
}: {
  chords: ResolvedChord[];
  bpm: number;
  pattern: PatternId;
  instrument: InstrumentId;
}) {
  const playing = usePlayerStore((s) => s.playing);
  const activeIndex = usePlayerStore((s) => s.activeIndex);
  const selectedIndex = usePlayerStore((s) => s.selectedIndex);
  const playGen = usePlayerStore((s) => s.playGen);
  const selectIndex = usePlayerStore((s) => s.selectIndex);
  const moveSlot = usePlayerStore((s) => s.moveSlot);
  const removeSlot = usePlayerStore((s) => s.removeSlot);
  const duplicateSlot = usePlayerStore((s) => s.duplicateSlot);
  const scroller = useRef<HTMLDivElement>(null);
  const [dragFrom, setDragFrom] = useState<number | null>(null);

  useEffect(() => {
    const el = scroller.current?.querySelector<HTMLElement>(`[data-chord="${activeIndex}"]`);
    el?.scrollIntoView({ behavior: "smooth", inline: "center", block: "nearest" });
  }, [activeIndex]);

  const current = chords[playing ? activeIndex : selectedIndex] ?? chords[0];

  function onChordClick(index: number) {
    selectIndex(index);
    if (!playing) {
      const chord = chords[index];
      if (chord) {
        void getAudioEngine().resume().then(() => {
          getAudioEngine().preview(chord, pattern, bpm, instrument);
        });
      }
    }
  }

  return (
    <section className="min-w-0 rounded-xl bg-surface p-3 shadow-[var(--shadow-border)] sm:p-4">
      <div className="mb-3 flex items-end justify-between gap-3">
        <div>
          <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">Progression</p>
          <p className="font-serif text-2xl leading-tight italic text-foreground sm:text-3xl">
            {current ? current.symbol : "—"}
          </p>
        </div>
        <p className="text-xs text-muted-foreground tabular-nums">
          {chords.length} bar{chords.length === 1 ? "" : "s"}
        </p>
      </div>

      <div
        ref={scroller}
        className="staff-lines -mx-1 flex max-w-full snap-x snap-mandatory gap-2 overflow-x-auto px-1 py-2 pb-3 [scrollbar-width:thin]"
      >
        {chords.map((chord, index) => {
          const active = index === activeIndex && playing;
          const selected = index === selectedIndex;
          const duration = (chord.beats * 60) / bpm;
          return (
            <button
              key={chord.id}
              type="button"
              data-chord={index}
              draggable
              onDragStart={() => setDragFrom(index)}
              onDragOver={(e) => e.preventDefault()}
              onDrop={() => {
                if (dragFrom != null) moveSlot(dragFrom, index);
                setDragFrom(null);
              }}
              onClick={() => onChordClick(index)}
              className={cn(
                "relative w-28 shrink-0 snap-start overflow-hidden rounded-md bg-surface-2 p-3 text-left transition-[box-shadow,background-color,transform] duration-150 ease-out sm:w-32",
                "shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
                selected && "ring-1 ring-foreground/25",
                active && "bg-secondary ring-1 ring-primary",
              )}
            >
              {active && (
                <span
                  key={playGen}
                  className="animate-playhead pointer-events-none absolute inset-0 origin-left bg-primary/20"
                  style={{ animationDuration: `${duration}s` }}
                />
              )}
              <span className="relative flex items-start justify-between">
                <span className="font-serif text-2xl leading-none italic sm:text-3xl">{chord.numeral}</span>
                <GripVertical className="size-3.5 text-subtle opacity-50" />
              </span>
              <span className="relative mt-2 block text-sm text-muted-foreground">{chord.symbol}</span>
              <span className="relative mt-3 flex gap-1">
                {Array.from({ length: chord.beats }).map((_, b) => (
                  <span key={b} className={cn("h-1 w-3 rounded-full", active ? "bg-primary" : "bg-foreground/20")} />
                ))}
              </span>
            </button>
          );
        })}
      </div>

      <PianoStrip activePcs={current?.midi ?? []} className="mt-1 overflow-hidden rounded-md" />

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => moveSlot(selectedIndex, Math.max(0, selectedIndex - 1))}
          disabled={selectedIndex <= 0}
          aria-label="Move chord earlier"
        >
          <ChevronLeft />
        </Button>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => moveSlot(selectedIndex, Math.min(chords.length - 1, selectedIndex + 1))}
          disabled={selectedIndex >= chords.length - 1}
          aria-label="Move chord later"
        >
          <ChevronRight />
        </Button>
        <Button type="button" variant="ghost" size="sm" onClick={() => duplicateSlot(selectedIndex)}>
          <Copy />
          Duplicate
        </Button>
        <Button type="button" variant="ghost" size="sm" onClick={() => removeSlot(selectedIndex)}>
          <Trash2 />
          Remove
        </Button>
      </div>
    </section>
  );
}
