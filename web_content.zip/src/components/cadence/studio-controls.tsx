import type { ReactNode } from "react";
import { Plus } from "lucide-react";
import { CHROMATIC_KEYS, PRESETS, SCALES, type PaletteChord, type ScaleId } from "@/lib/harmony";
import { cn } from "@/lib/utils";

function Chip({
  active,
  onClick,
  children,
  title,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
  title?: string;
}) {
  return (
    <button
      type="button"
      title={title}
      onClick={onClick}
      className={cn(
        "h-10 min-w-10 rounded-full px-3 text-sm font-medium transition-[background-color,color] duration-150",
        active ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground",
      )}
    >
      {children}
    </button>
  );
}

export function StudioControls({
  keyPc,
  scale,
  sevenths,
  presetHint,
  onKey,
  onScale,
  onSevenths,
  onPreset,
}: {
  keyPc: number;
  scale: ScaleId;
  sevenths: boolean;
  presetHint: string | null;
  onKey: (pc: number) => void;
  onScale: (scale: ScaleId) => void;
  onSevenths: (value: boolean) => void;
  onPreset: (id: string) => void;
}) {
  return (
    <div className="space-y-6">
      <section>
        <p className="mb-2 text-xs font-medium tracking-wide text-muted-foreground uppercase">Key</p>
        <div className="flex flex-wrap gap-1.5">
          {CHROMATIC_KEYS.map((k) => (
            <Chip key={k.id} active={k.pc === keyPc} onClick={() => onKey(k.pc)}>
              {k.label}
            </Chip>
          ))}
        </div>
      </section>

      <section>
        <p className="mb-2 text-xs font-medium tracking-wide text-muted-foreground uppercase">Scale</p>
        <div className="flex flex-wrap gap-1.5">
          {SCALES.map((s) => (
            <Chip key={s.id} active={s.id === scale} onClick={() => onScale(s.id)}>
              {s.name}
            </Chip>
          ))}
          <Chip active={sevenths} onClick={() => onSevenths(!sevenths)}>
            7ths
          </Chip>
        </div>
      </section>

      <section>
        <div className="mb-2 flex items-baseline justify-between">
          <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">Presets</p>
          {presetHint ? <p className="text-xs text-subtle">{presetHint}</p> : null}
        </div>
        <div className="flex flex-wrap gap-1.5">
          {PRESETS.map((p) => (
            <Chip key={p.id} active={false} title={p.hint} onClick={() => onPreset(p.id)}>
              {p.name}
            </Chip>
          ))}
        </div>
      </section>
    </div>
  );
}

export function ChordPalette({
  diatonic,
  borrowed,
  onAdd,
  onReplace,
}: {
  diatonic: PaletteChord[];
  borrowed: PaletteChord[];
  onAdd: (numeral: string) => void;
  onReplace: (numeral: string) => void;
}) {
  return (
    <section className="rounded-xl bg-surface p-3 shadow-[var(--shadow-border)] sm:p-4">
      <div className="mb-3 flex items-baseline justify-between gap-2">
        <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">Add or replace</p>
        <p className="text-xs text-subtle">Tap a chord to swap the selected bar</p>
      </div>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-7">
        {diatonic.map((c) => (
          <PaletteButton key={c.numeral} chord={c} onAdd={onAdd} onReplace={onReplace} />
        ))}
      </div>
      <p className="mt-4 mb-2 text-xs font-medium tracking-wide text-muted-foreground uppercase">Borrowed</p>
      <div className="flex flex-wrap gap-2">
        {borrowed.map((c) => (
          <PaletteButton key={c.numeral} chord={c} onAdd={onAdd} onReplace={onReplace} compact />
        ))}
      </div>
    </section>
  );
}

function PaletteButton({
  chord,
  onAdd,
  onReplace,
  compact,
}: {
  chord: PaletteChord;
  onAdd: (numeral: string) => void;
  onReplace: (numeral: string) => void;
  compact?: boolean;
}) {
  return (
    <div className={cn("relative min-w-0 rounded-md bg-surface-2 shadow-[var(--shadow-border)]", compact && "min-w-20")}>
      <button
        type="button"
        onClick={() => onReplace(chord.numeral)}
        className={cn("w-full px-3 py-2 pr-10 text-left hover:bg-secondary", compact ? "min-h-11" : "min-h-16")}
      >
        <span className="block font-serif text-lg leading-none italic">{chord.numeral}</span>
        <span className="mt-1 block text-xs text-muted-foreground">{chord.symbol}</span>
      </button>
      <button
        type="button"
        onClick={() => onAdd(chord.numeral)}
        className="absolute top-1 right-1 flex size-8 items-center justify-center rounded-sm text-muted-foreground hover:bg-secondary hover:text-foreground"
        aria-label={`Add ${chord.symbol}`}
      >
        <Plus className="size-4" />
      </button>
    </div>
  );
}

export function BeatsEditor({
  beats,
  onChange,
  onApplyAll,
}: {
  beats: number;
  onChange: (beats: number) => void;
  onApplyAll: (beats: number) => void;
}) {
  return (
    <section className="rounded-xl bg-surface p-3 shadow-[var(--shadow-border)] sm:p-4">
      <p className="mb-2 text-xs font-medium tracking-wide text-muted-foreground uppercase">Beats for selected chord</p>
      <div className="flex flex-wrap gap-1.5">
        {[1, 2, 3, 4, 8].map((n) => (
          <Chip key={n} active={beats === n} onClick={() => onChange(n)}>
            {n}
          </Chip>
        ))}
        <button
          type="button"
          onClick={() => onApplyAll(beats)}
          className="h-10 rounded-full px-3 text-xs font-medium text-muted-foreground hover:text-foreground"
        >
          Apply to all
        </button>
      </div>
    </section>
  );
}
