import { Pause, Play, Repeat, Square, Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { cn } from "@/lib/utils";
import { PATTERNS, type PatternId } from "@/lib/patterns";
import type { InstrumentId } from "@/lib/harmony";

export function Transport({
  playing,
  loop,
  bpm,
  volume,
  metronome,
  pattern,
  instrument,
  onTogglePlay,
  onStop,
  onLoop,
  onBpm,
  onVolume,
  onMetronome,
  onPattern,
  onInstrument,
}: {
  playing: boolean;
  loop: boolean;
  bpm: number;
  volume: number;
  metronome: boolean;
  pattern: PatternId;
  instrument: InstrumentId;
  onTogglePlay: () => void;
  onStop: () => void;
  onLoop: (value: boolean) => void;
  onBpm: (value: number) => void;
  onVolume: (value: number) => void;
  onMetronome: (value: boolean) => void;
  onPattern: (value: PatternId) => void;
  onInstrument: (value: InstrumentId) => void;
}) {
  return (
    <footer className="fixed inset-x-0 bottom-0 z-20 overflow-x-hidden border-t border-border bg-background/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm">
      <div className="mx-auto flex w-full min-w-0 max-w-6xl flex-col gap-3 px-4 py-3">
        <div className="flex items-center gap-2 overflow-x-auto [scrollbar-width:none]">
          {PATTERNS.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => onPattern(p.id)}
              className={cn(
                "h-9 shrink-0 rounded-full px-3 text-xs font-medium transition-[background-color,color] duration-150",
                pattern === p.id
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-muted-foreground hover:text-foreground",
              )}
            >
              {p.name}
            </button>
          ))}
        </div>

        <div className="flex min-w-0 flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center">
          <div className="flex items-center gap-2">
            <Button
              type="button"
              size="lg"
              onClick={onTogglePlay}
              className="min-w-24"
              aria-label={playing ? "Pause" : "Play"}
            >
              {playing ? <Pause className="size-5" /> : <Play className="size-5 ml-0.5" />}
              {playing ? "Pause" : "Play"}
            </Button>
            <Button type="button" variant="secondary" size="icon" onClick={onStop} aria-label="Stop">
              <Square className="size-4 fill-current" />
            </Button>
            <Button
              type="button"
              variant={loop ? "default" : "secondary"}
              size="icon"
              onClick={() => onLoop(!loop)}
              aria-label={loop ? "Disable loop" : "Enable loop"}
            >
              <Repeat />
            </Button>
          </div>

          <div className="flex min-w-0 flex-1 items-center gap-3">
            <span className="w-14 shrink-0 text-xs font-medium text-muted-foreground tabular-nums">{bpm} BPM</span>
            <Slider value={[bpm]} min={60} max={180} step={1} onValueChange={(v) => onBpm(v[0] ?? bpm)} />
          </div>

          <div className="hidden min-w-0 items-center gap-2 sm:flex sm:w-36">
            <Volume2 className="size-4 shrink-0 text-muted-foreground" />
            <Slider
              value={[Math.round(volume * 100)]}
              min={0}
              max={100}
              step={1}
              onValueChange={(v) => onVolume((v[0] ?? 72) / 100)}
            />
          </div>

          <div className="flex flex-wrap items-center gap-1 sm:ml-auto">
            <button
              type="button"
              onClick={() => onInstrument("keys")}
              className={cn(
                "h-9 rounded-full px-3 text-xs font-medium",
                instrument === "keys" ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground",
              )}
            >
              Keys
            </button>
            <button
              type="button"
              onClick={() => onInstrument("nylon")}
              className={cn(
                "h-9 rounded-full px-3 text-xs font-medium",
                instrument === "nylon" ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground",
              )}
            >
              Nylon
            </button>
            <button
              type="button"
              onClick={() => onMetronome(!metronome)}
              className={cn(
                "h-9 rounded-full px-3 text-xs font-medium",
                metronome ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground",
              )}
            >
              Click
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
