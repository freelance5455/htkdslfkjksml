import { cn } from "@/lib/utils";

const WHITE = [0, 2, 4, 5, 7, 9, 11];
const START = 48; // C3
const END = 72; // C5

function isWhite(pc: number) {
  return WHITE.includes(pc);
}

export function PianoStrip({
  activePcs,
  className,
}: {
  activePcs: number[];
  className?: string;
}) {
  const whites: number[] = [];
  const blacks: { midi: number; left: number }[] = [];
  for (let m = START; m <= END; m++) {
    const pc = m % 12;
    if (isWhite(pc)) whites.push(m);
  }
  const whiteWidth = 100 / whites.length;
  let wIndex = 0;
  for (let m = START; m <= END; m++) {
    const pc = m % 12;
    if (isWhite(pc)) {
      wIndex += 1;
      continue;
    }
    blacks.push({ midi: m, left: (wIndex - 0.32) * whiteWidth });
  }

  const active = new Set(activePcs.map((n) => ((n % 12) + 12) % 12));

  return (
    <div className={cn("relative h-14 w-full", className)} aria-hidden="true">
      <div className="absolute inset-0 flex">
        {whites.map((midi) => {
          const on = active.has(midi % 12);
          return (
            <div
              key={midi}
              className={cn(
                "h-full flex-1 border-r border-background last:border-r-0",
                on ? "bg-primary" : "bg-foreground/90",
              )}
            />
          );
        })}
      </div>
      {blacks.map(({ midi, left }) => {
        const on = active.has(midi % 12);
        return (
          <div
            key={midi}
            className={cn(
              "absolute top-0 h-[58%] w-[4.2%] rounded-b-sm",
              on ? "bg-primary-foreground/80" : "bg-background",
            )}
            style={{ left: `${left}%` }}
          />
        );
      })}
    </div>
  );
}
