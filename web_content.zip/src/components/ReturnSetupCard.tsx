import React, { useEffect, useState } from 'react';
import { Check, CalendarCheck, CalendarPlus, RotateCcw } from 'lucide-react';
import type { UserProfile } from '../types';
import {
  DATE_KEY_REGEX,
  MAX_NOTE_LENGTH,
  formatArabicDateFull,
} from '../utils/attendance';

interface ReturnSetupCardProps {
  profile: UserProfile;
  todayKey: string;
  saving: boolean;
  onSaveReturnStart: (dateKey: string) => Promise<void>;
  onClearReturnStart: () => Promise<void>;
  onRecordAnnualLeaveRange: (
    startDateKey: string,
    daysCount: number,
    note: string
  ) => Promise<void>;
}

export const ReturnSetupCard: React.FC<ReturnSetupCardProps> = ({
  profile,
  todayKey,
  saving,
  onSaveReturnStart,
  onClearReturnStart,
  onRecordAnnualLeaveRange,
}) => {
  const [dateInput, setDateInput] = useState<string>(profile.returnStartDate || todayKey);
  const [isEditingDate, setIsEditingDate] = useState<boolean>(!profile.returnStartDate);

  const [leaveDate, setLeaveDate] = useState<string>(todayKey);
  const [leaveDaysCount, setLeaveDaysCount] = useState<string>('1');
  const [leaveNote, setLeaveNote] = useState<string>('');
  const [leaveSavedNotice, setLeaveSavedNotice] = useState<string | null>(null);

  useEffect(() => {
    setDateInput(profile.returnStartDate || todayKey);
    if (!profile.returnStartDate) {
      setIsEditingDate(true);
    }
  }, [profile.returnStartDate, todayKey]);

  const handleRegisterFirstDay = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!DATE_KEY_REGEX.test(dateInput)) return;
    await onSaveReturnStart(dateInput);
    setIsEditingDate(false);
  };

  const handleRecordLeave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!DATE_KEY_REGEX.test(leaveDate)) return;
    const count = Math.max(1, Math.min(60, Math.floor(Number(leaveDaysCount) || 1)));
    await onRecordAnnualLeaveRange(leaveDate, count, leaveNote);
    setLeaveDaysCount('1');
    setLeaveNote('');
    setLeaveSavedNotice(
      `تم تسجيل ${count} ${count === 1 ? 'يوم' : 'أيام'} (إجازة اعتيادي).`
    );
    window.setTimeout(() => setLeaveSavedNotice(null), 3500);
  };

  const hasReturnDate = Boolean(profile.returnStartDate);

  return (
    <section id="setup" className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-6">
      {/* Primary Action: First Day Return Registration */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div className="space-y-1">
          <h2 className="text-base sm:text-lg font-bold text-slate-900">
            تسجيل الحضور — أول يوم عودة للعمل
          </h2>
          <p className="text-sm text-slate-600">
            التسجيل يتم في أول يوم فقط، وتُحتسب جميع الأيام التالية كأيام حضور باستثناء الإجازات الاعتيادي المسجلة.
          </p>
        </div>

        {hasReturnDate && !isEditingDate ? (
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <div className="px-3.5 py-2 bg-emerald-50 border border-emerald-200 rounded-lg text-sm text-emerald-900 flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-700 shrink-0" aria-hidden="true" />
              <span>
                مسجل منذ:{' '}
                <strong className="font-semibold">
                  {formatArabicDateFull(profile.returnStartDate)}
                </strong>
              </span>
            </div>
            <button
              type="button"
              onClick={() => setIsEditingDate(true)}
              disabled={saving}
              className="px-4 py-2.5 min-h-[42px] text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              تعديل التاريخ
            </button>
            <button
              type="button"
              onClick={() => {
                void onClearReturnStart();
                setIsEditingDate(true);
              }}
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-3.5 py-2.5 min-h-[42px] text-xs font-medium text-slate-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
              <span>إعادة تعيين</span>
            </button>
          </div>
        ) : (
          <form
            onSubmit={handleRegisterFirstDay}
            className="flex flex-wrap items-center gap-2.5 shrink-0"
          >
            <label htmlFor="return-start-date" className="sr-only">
              تاريخ أول يوم عودة للعمل
            </label>
            <input
              id="return-start-date"
              type="date"
              value={dateInput}
              max={todayKey}
              onChange={(e) => setDateInput(e.target.value)}
              required
              className="px-3.5 py-2.5 min-h-[44px] text-sm font-mono-num text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
            />
            <button
              type="submit"
              disabled={saving || !DATE_KEY_REGEX.test(dateInput)}
              className="inline-flex items-center gap-2 px-5 py-2.5 min-h-[44px] text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              <CalendarCheck className="w-4 h-4" aria-hidden="true" />
              <span>{saving ? 'جاري الحفظ...' : 'تسجيل أول يوم عودة'}</span>
            </button>
            {hasReturnDate && (
              <button
                type="button"
                onClick={() => {
                  setDateInput(profile.returnStartDate);
                  setIsEditingDate(false);
                }}
                className="px-3.5 py-2.5 min-h-[44px] text-xs font-medium text-slate-600 hover:text-slate-900 rounded-lg"
              >
                إلغاء
              </button>
            )}
          </form>
        )}
      </div>

      {/* Hairline divider + Annual Leave Entry */}
      <div className="border-t border-slate-200 pt-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <h3 className="text-sm sm:text-base font-bold text-slate-900">
              تسجيل أيام الإجازة الاعتيادي
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              سجّل يوم الإجازة أو عدد أيامها ليتم خصمها من الحضور وإضافتها في العداد تلقائياً.
            </p>
          </div>
          {leaveSavedNotice && (
            <span className="text-xs font-medium text-emerald-700">{leaveSavedNotice}</span>
          )}
        </div>

        <form onSubmit={handleRecordLeave} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-3 items-end">
          {/* Start Date */}
          <div className="lg:col-span-3">
            <label htmlFor="leave-date" className="block text-xs font-medium text-slate-600 mb-1.5">
              تاريخ الإجازة
            </label>
            <input
              id="leave-date"
              type="date"
              value={leaveDate}
              onChange={(e) => setLeaveDate(e.target.value)}
              required
              className="w-full px-3 py-2 min-h-[42px] text-sm font-mono-num text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
            />
          </div>

          {/* Number of Days */}
          <div className="lg:col-span-2">
            <label htmlFor="leave-count" className="block text-xs font-medium text-slate-600 mb-1.5">
              عدد الأيام
            </label>
            <input
              id="leave-count"
              type="number"
              min={1}
              max={60}
              value={leaveDaysCount}
              onChange={(e) => setLeaveDaysCount(e.target.value)}
              required
              className="w-full px-3 py-2 min-h-[42px] text-sm font-mono-num text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
            />
          </div>

          {/* Note */}
          <div className="lg:col-span-4">
            <label htmlFor="leave-note" className="block text-xs font-medium text-slate-600 mb-1.5">
              ملاحظة (اختياري)
            </label>
            <input
              id="leave-note"
              type="text"
              maxLength={MAX_NOTE_LENGTH}
              value={leaveNote}
              onChange={(e) => setLeaveNote(e.target.value)}
              placeholder="ملاحظة حول الإجازة"
              className="w-full px-3 py-2 min-h-[42px] text-xs text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
            />
          </div>

          {/* Submit */}
          <div className="lg:col-span-3">
            <button
              type="submit"
              disabled={saving || !DATE_KEY_REGEX.test(leaveDate)}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2 min-h-[42px] text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap"
            >
              <CalendarPlus className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>{saving ? 'جاري الحفظ...' : 'تسجيل إجازة اعتيادي'}</span>
            </button>
          </div>
        </form>
      </div>
    </section>
  );
};
