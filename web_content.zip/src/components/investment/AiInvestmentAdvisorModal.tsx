import React, { useState } from 'react';
import { Bot, Sparkles, X, TrendingUp, ShieldCheck, ArrowRight, Zap } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { MetalType } from '../../types';

interface AiInvestmentAdvisorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenBuyModal: (metal: MetalType) => void;
  onOpenSipModal: () => void;
}

export const AiInvestmentAdvisorModal: React.FC<AiInvestmentAdvisorModalProps> = ({
  isOpen,
  onClose,
  onOpenBuyModal,
  onOpenSipModal,
}) => {
  const { goldPricePerGram, silverPricePerGram } = useApp();
  const [budget, setBudget] = useState<number>(1000);
  const [aiAdvice, setAiAdvice] = useState<string>(
    `Based on current bullish bullion trends (Gold ₹${goldPricePerGram}/g, Silver ₹${silverPricePerGram}/g), allocating 70% to 24K Gold and 30% to Digital Silver provides optimal capital protection with +14.8% projected annual growth.`
  );
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleAskAi = () => {
    setIsAnalyzing(true);
    setTimeout(() => {
      setIsAnalyzing(false);
      const goldAmt = Math.round(budget * 0.7);
      const silverAmt = budget - goldAmt;
      setAiAdvice(
        `AI Portfolio Recommendation for ₹${budget.toLocaleString()} monthly savings: \n• Allocate ₹${goldAmt} into 24K Digital Gold (~${(goldAmt / goldPricePerGram).toFixed(4)}g)\n• Allocate ₹${silverAmt} into Digital Silver (~${(silverAmt / silverPricePerGram).toFixed(4)}g)\n✨ Tip: Set up a Weekly SIP to automatically average out market volatility!`
      );
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-slate-900 border border-indigo-500/40 rounded-3xl p-5 sm:p-6 shadow-2xl relative space-y-4 text-white">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white bg-slate-800/80 cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/40 flex items-center justify-center font-bold text-xl shadow-lg">
            <Bot className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-black tracking-tight">AI Investment Advisor</h2>
              <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                GEMINI AI
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Smart bullion analysis & budget allocation assistant
            </p>
          </div>
        </div>

        {/* AI Insight Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-950/80 via-slate-950 to-purple-950/80 border border-indigo-500/30 space-y-2 text-xs">
          <div className="flex items-center gap-1.5 text-indigo-300 font-bold">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>AI Market Insight & Recommendation</span>
          </div>
          <p className="text-slate-300 leading-relaxed whitespace-pre-line font-medium">
            {isAnalyzing ? 'Analyzing live bullion indexes & global inflation metrics...' : aiAdvice}
          </p>
        </div>

        {/* Budget Helper */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3 text-xs">
          <label className="block font-bold text-slate-300">Enter Your Monthly Investment Budget (INR)</label>
          <div className="relative">
            <span className="absolute left-3.5 top-3 text-slate-400 font-bold">₹</span>
            <input
              type="number"
              step="100"
              value={budget}
              onChange={(e) => setBudget(Number(e.target.value))}
              className="w-full pl-8 pr-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-black text-sm focus:border-indigo-500 focus:outline-none"
            />
          </div>

          <button
            type="button"
            onClick={handleAskAi}
            disabled={isAnalyzing}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-black text-xs shadow-md shadow-indigo-600/20 cursor-pointer transition-all flex items-center justify-center gap-2"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Generate AI Portfolio Plan</span>
          </button>
        </div>

        {/* Quick Action buttons */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenBuyModal('gold');
            }}
            className="py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs cursor-pointer shadow-md flex items-center justify-center gap-1"
          >
            <span>Buy Gold Now</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenSipModal();
            }}
            className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 font-bold text-xs cursor-pointer flex items-center justify-center gap-1"
          >
            <span>Start SIP Plan</span>
            <TrendingUp className="w-3.5 h-3.5" />
          </button>
        </div>

        <p className="text-[10px] text-slate-500 text-center leading-tight">
          🤖 AI Advisor assists with smart asset allocation. Past performance does not guarantee future returns.
        </p>
      </div>
    </div>
  );
};
