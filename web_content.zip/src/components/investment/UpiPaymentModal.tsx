import React, { useState } from 'react';
import { ShieldCheck, CheckCircle2, X, Lock, Smartphone, Copy, Check, Image as ImageIcon } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { MetalType } from '../../types';
import { PaytmQrCard } from '../common/PaytmQrCard';

interface UpiPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  metalType: MetalType;
  amountINR: number;
  netPayableINR: number;
  estimatedGrams: number;
  couponCode?: string;
  discountINR?: number;
  onSuccess: (message: string) => void;
}

export const UpiPaymentModal: React.FC<UpiPaymentModalProps> = ({
  isOpen,
  onClose,
  metalType,
  amountINR,
  netPayableINR,
  estimatedGrams,
  couponCode,
  discountINR,
  onSuccess,
}) => {
  const { buyMetal, systemSettings, currentUser, kycRecords } = useApp();
  const [paidAmount, setPaidAmount] = useState<number | string>(netPayableINR);
  const [utrRef, setUtrRef] = useState('');
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(null);
  const [verifying, setVerifying] = useState(false);
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const userKyc = kycRecords.find(k => k.userId === currentUser?.id && k.status === 'verified');
  const userMobile = userKyc?.mobileNumber || currentUser?.phone || '';

  const orderId = `ORD-${metalType.toUpperCase()}-${Math.floor(100000 + Math.random() * 900000)}`;
  const merchantUpiId = systemSettings?.adminUpiId || 'paytm.s19vihm@pty';

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(merchantUpiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (uploadEvt) => {
        setScreenshotPreview(uploadEvt.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleVerifyAndPay = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const numericAmount = Number(paidAmount);
    if (!numericAmount || numericAmount <= 0) {
      setError('Please enter a valid paid amount in INR.');
      return;
    }

    if (!utrRef.trim() || utrRef.trim().length < 6) {
      setError('Please enter a valid UTR or Transaction ID.');
      return;
    }

    setVerifying(true);

    // Simulate backend payment verification gateway webhook response
    setTimeout(() => {
      setVerifying(false);
      const res = buyMetal(metalType, amountINR, couponCode, screenshotPreview || undefined);
      if (res.success) {
        confetti({ particleCount: 80, spread: 90 });
        onSuccess(`Payment verified! Order ${orderId} confirmed. ${estimatedGrams}g ${metalType.toUpperCase()} added to portfolio.`);
        onClose();
      } else {
        setError(res.message);
      }
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-slate-900 border border-amber-500/40 rounded-3xl p-5 sm:p-6 shadow-2xl relative space-y-4 text-white max-h-[90vh] overflow-y-auto">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white bg-slate-800/80 cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center font-bold text-xl">
            💳
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-black tracking-tight">Secure UPI Payment Gateway</h2>
              <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                SSL SECURED
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono">
              Order ID: <span className="text-amber-400 font-bold">{orderId}</span>
            </p>
          </div>
        </div>

        {error && (
          <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-semibold">
            {error}
          </div>
        )}

        {/* Payment Summary */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2.5 text-xs">
          <div className="flex justify-between text-slate-400">
            <span>Item:</span>
            <span className="font-black text-white capitalize">{estimatedGrams}g 24K {metalType}</span>
          </div>
          <div className="flex justify-between text-slate-400">
            <span>Original Amount:</span>
            <span className="font-bold text-slate-300">₹{amountINR.toLocaleString()}</span>
          </div>
          {discountINR ? (
            <div className="flex justify-between text-emerald-400 font-bold">
              <span>Coupon Discount:</span>
              <span>- ₹{discountINR}</span>
            </div>
          ) : null}
          <div className="flex justify-between text-slate-400 pt-1.5 border-t border-slate-800">
            <span className="font-bold text-slate-200">Final Payable Amount:</span>
            <span className="font-black text-amber-400 text-base">₹{netPayableINR.toLocaleString()}</span>
          </div>

          {metalType === 'gold' && (
            <div className="pt-2 border-t border-slate-800/80 space-y-1 text-[11px]">
              <div className="flex justify-between text-slate-400">
                <span>Verified Aadhaar KYC:</span>
                <span className="font-mono font-bold text-emerald-400">{userKyc?.aadhaarMasked || 'XXXX-XXXX-8942'}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Verified Mobile Number:</span>
                <span className="font-mono font-bold text-emerald-400">+91 {userMobile || '9635776190'}</span>
              </div>
            </div>
          )}
        </div>

        {/* Official Paytm QR Poster Card with UPI ID */}
        <div className="space-y-2">
          <PaytmQrCard
            upiId={merchantUpiId}
            amount={Number(paidAmount) || netPayableINR}
            payeeName="Subhodip Garai"
            transactionNote={`24K ${metalType.toUpperCase()} Order ${orderId}`}
            showDirectPayButton={true}
          />
        </div>

        {/* Payment Verification Form */}
        <form onSubmit={handleVerifyAndPay} className="space-y-3.5 text-xs pt-1">
          {/* Amount (INR) Input */}
          <div>
            <label className="block font-bold text-slate-300 mb-1">
              Amount (INR) <span className="text-amber-400">*</span>
            </label>
            <input
              type="number"
              required
              min={1}
              value={paidAmount}
              onChange={(e) => setPaidAmount(e.target.value)}
              placeholder="Enter Paid Amount"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono text-xs focus:border-amber-500 focus:outline-none"
            />
          </div>

          {/* Transaction ID / UTR Input */}
          <div>
            <label className="block font-bold text-slate-300 mb-1">
              Transaction ID / UTR <span className="text-amber-400">*</span>
            </label>
            <input
              type="text"
              required
              value={utrRef}
              onChange={(e) => setUtrRef(e.target.value)}
              placeholder="Enter UTR or Transaction ID"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono text-xs focus:border-amber-500 focus:outline-none"
            />
            <span className="text-[10px] text-slate-400 block mt-1">
              Enter 12-digit UPI reference / transaction ID from your Paytm, PhonePe, or GPay receipt.
            </span>
          </div>

          {/* Screenshot Gallery Attachment */}
          <div className="space-y-1.5">
            <label className="block font-bold text-slate-300">Attach Payment Screenshot (from Gallery)</label>
            <div className="flex items-center gap-3 p-3 rounded-2xl bg-slate-950 border border-slate-800">
              <label className="flex-1 py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all">
                <ImageIcon className="w-4 h-4 text-amber-400" />
                <span>{screenshotPreview ? 'Change Screenshot' : 'Upload Screenshot from Gallery'}</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="hidden"
                />
              </label>
              {screenshotPreview && (
                <div className="relative w-12 h-12 rounded-xl overflow-hidden border border-amber-500/50 shrink-0">
                  <img src={screenshotPreview} alt="Receipt preview" className="w-full h-full object-cover" />
                </div>
              )}
            </div>
            <p className="text-[10px] text-slate-500">
              Attach the payment receipt screenshot from your gallery for instant verification.
            </p>
          </div>

          <button
            type="submit"
            disabled={verifying}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/25 flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-50"
          >
            {verifying ? (
              <span>Verifying with Payment Gateway...</span>
            ) : (
              <>
                <ShieldCheck className="w-4 h-4" />
                <span>Submit & Confirm ₹{Number(paidAmount || netPayableINR).toLocaleString()}</span>
              </>
            )}
          </button>
        </form>

        <div className="flex items-center justify-center gap-1.5 text-[10px] text-slate-400 pt-1">
          <Lock className="w-3 h-3 text-amber-400" />
          <span>Real INR Payment Verification • UPI ID: paytm.s19vihm@pty</span>
        </div>

      </div>
    </div>
  );
};
