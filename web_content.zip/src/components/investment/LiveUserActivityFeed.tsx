import React, { useState, useEffect } from 'react';
import { Activity, Radio, Users, Award, ArrowUpRight, CheckCircle2, Clock } from 'lucide-react';

interface ActivityItem {
  id: string;
  userName: string;
  activityType: 'Gold Buy' | 'Gold Sell' | 'Silver Buy' | 'Silver Sell' | 'New User Registered' | 'Withdrawal Requested' | 'Withdrawal Completed';
  detail: string;
  amount?: string;
  status: 'Completed' | 'Processing' | 'Pending';
  timestamp: string;
  category: 'user' | 'gold' | 'silver' | 'withdrawal';
}

const INITIAL_ACTIVITIES: ActivityItem[] = [
  { id: 'act-1', userName: 'Rahul S.', activityType: 'Gold Buy', detail: 'Bought 0.3185g Gold', amount: '₹2,000', status: 'Completed', timestamp: '1 sec ago', category: 'gold' },
  { id: 'act-2', userName: 'Puja D.', activityType: 'Withdrawal Requested', detail: 'UPI Payout requested', amount: '₹850', status: 'Processing', timestamp: '3 sec ago', category: 'withdrawal' },
  { id: 'act-3', userName: 'Amit K.', activityType: 'New User Registered', detail: 'Joined Task Earn Pro & Verified KYC', status: 'Completed', timestamp: '5 sec ago', category: 'user' },
  { id: 'act-4', userName: 'Sneha R.', activityType: 'Silver Buy', detail: 'Bought 63.12g Silver', amount: '₹5,000', status: 'Completed', timestamp: '8 sec ago', category: 'silver' },
  { id: 'act-5', userName: 'Vikram M.', activityType: 'Gold Sell', detail: 'Sold 0.159g Gold', amount: '₹1,000', status: 'Completed', timestamp: '12 sec ago', category: 'gold' },
];

const DEMO_NAMES = ['Rahul S.', 'Puja D.', 'Amit K.', 'Sneha R.', 'Vikram M.', 'Ananya G.', 'Karan P.', 'Rohan T.', 'Pooja N.', 'Arjun N.', 'Megha S.', 'Siddharth V.'];

export const LiveUserActivityFeed: React.FC = () => {
  const [activities, setActivities] = useState<ActivityItem[]>(INITIAL_ACTIVITIES);
  const [filter, setFilter] = useState<'all' | 'user' | 'gold' | 'silver' | 'withdrawal'>('all');

  // 1-Second live simulation update
  useEffect(() => {
    const timer = setInterval(() => {
      const name = DEMO_NAMES[Math.floor(Math.random() * DEMO_NAMES.length)];
      const types: { type: ActivityItem['activityType']; cat: ActivityItem['category']; details: string[]; amt: string }[] = [
        { type: 'Gold Buy', cat: 'gold', details: ['Bought 0.159g Gold', 'Bought 0.796g Gold', 'Bought 1.59g Gold'], amt: '₹1,000' },
        { type: 'Silver Buy', cat: 'silver', details: ['Bought 12.62g Silver', 'Bought 63.12g Silver', 'Bought 126.26g Silver'], amt: '₹1,000' },
        { type: 'Gold Sell', cat: 'gold', details: ['Sold 0.318g Gold'], amt: '₹2,000' },
        { type: 'Silver Sell', cat: 'silver', details: ['Sold 25.25g Silver'], amt: '₹2,000' },
        { type: 'New User Registered', cat: 'user', details: ['Joined Task Earn Pro & Verified KYC'], amt: '' },
        { type: 'Withdrawal Completed', cat: 'withdrawal', details: ['UPI Payout completed successfully'], amt: '₹1,500' },
      ];

      const chosen = types[Math.floor(Math.random() * types.length)];
      const detail = chosen.details[Math.floor(Math.random() * chosen.details.length)];

      const newItem: ActivityItem = {
        id: `act-${Date.now()}`,
        userName: name,
        activityType: chosen.type,
        detail,
        amount: chosen.amt,
        status: 'Completed',
        timestamp: 'Just now',
        category: chosen.cat,
      };

      setActivities(prev => [newItem, ...prev.slice(0, 19)]);
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const filteredActivities = activities.filter(a => {
    if (filter === 'all') return true;
    return a.category === filter;
  });

  return (
    <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-slate-800 shadow-xl space-y-4">
      
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center animate-pulse">
            <Radio className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-black text-white">Live User Activity Feed</h3>
            <p className="text-[10px] text-amber-400 font-bold uppercase tracking-wider">
              Real-time Live Feed
            </p>
          </div>
        </div>
        <span className="px-2.5 py-1 rounded-xl bg-slate-800 text-slate-300 text-[10px] font-bold">
          50,000+ Active Investors
        </span>
      </div>

      {/* Filters */}
      <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-1">
        {[
          { id: 'all', label: 'All' },
          { id: 'user', label: 'New Users' },
          { id: 'gold', label: 'Gold' },
          { id: 'silver', label: 'Silver' },
          { id: 'withdrawal', label: 'Withdrawals' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setFilter(tab.id as any)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              filter === tab.id
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Activity List */}
      <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
        {filteredActivities.map((act) => (
          <div
            key={act.id}
            className="p-3 rounded-2xl bg-slate-950 border border-slate-800/80 flex items-center justify-between gap-3 text-xs animate-in slide-in-from-top-2 duration-200"
          >
            <div className="flex items-center gap-3">
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                act.category === 'gold' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
                act.category === 'silver' ? 'bg-slate-300/20 text-slate-200 border border-slate-400/30' :
                act.category === 'user' ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30' :
                'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
              }`}>
                {act.category === 'gold' ? '🏆' : act.category === 'silver' ? '🥈' : act.category === 'user' ? '👤' : '💸'}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white">{act.userName}</span>
                  <span className="px-2 py-0.5 rounded text-[9px] font-black uppercase bg-slate-900 text-slate-300 border border-slate-800">
                    {act.activityType}
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 block mt-0.5">{act.detail}</span>
              </div>
            </div>

            <div className="text-right shrink-0">
              {act.amount && <span className="font-black text-amber-400 block font-mono">{act.amount}</span>}
              <span className="text-[10px] text-slate-500 flex items-center gap-1 justify-end">
                <Clock className="w-3 h-3" />
                <span>{act.timestamp}</span>
              </span>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
