import React, { useState } from 'react';
import {
  X,
  Award,
  CheckCircle2,
  ShieldCheck,
  TrendingUp,
  Share2,
  Copy,
  Check,
  Clock,
  Sparkles,
  ExternalLink,
  Wallet,
  Zap,
  ArrowUpRight,
  QrCode,
  Download,
  AlertCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp, isSubhodipUser } from '../../context/AppContext';

interface GoldMineInvestorProofModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenWithdrawal?: () => void;
}

export const GoldMineInvestorProofModal: React.FC<GoldMineInvestorProofModalProps> = ({
  isOpen,
  onClose,
  onOpenWithdrawal,
}) => {
  const { currentUser, adjustUserCoins, language } = useApp();
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedUtr, setCopiedUtr] = useState(false);
  const [hasClaimedToday, setHasClaimedToday] = useState(false);
  const [claimNotice, setClaimNotice] = useState<string | null>(null);

  // STRICT USER PRIVACY: "Show proof ata na show hoy karor kache"
  // Never show private proof or certificate to other users or public viewers
  if (!isOpen) return null;
  if (!currentUser || !isSubhodipUser(currentUser)) {
    return null;
  }

  // Investor details for Subhodip Garai's private account
  const investorName = currentUser.name || 'Subhodip Garai';
  const investorUserId = currentUser.id || 'user-subhodip-7654';
  const investorUsername = currentUser.username || '@subhodip7';
  const investorUpi = 'subhodip***@oksbi';
  const withdrawalUtr = '628903102931';

  // Gold Mine specs:
  // Investment: ₹5,000
  // Duration: 30 Days
  // Daily Return: ₹300/day
  // Total Return: ₹9,000
  // Task Withdrawal: ₹1,000
  const investedAmount = 5000;
  const dailyReturn = 300;
  const durationDays = 30;
  const totalReturn = 9000;
  const netProfit = totalReturn - investedAmount; // +₹4,000
  const taskWithdrawal = 1000;
  const currentDay = 4; // Day 4 of 30

  const handleClaimToday = () => {
    if (hasClaimedToday) return;
    setHasClaimedToday(true);
    if (currentUser) {
      adjustUserCoins(currentUser.id, 300, 'Gold Mine Daily Return (Day 4/30)');
    }
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 }
    });
    setClaimNotice('🎉 Today’s ₹300 Gold Mine Daily Return claimed successfully & added to wallet!');
    setTimeout(() => setClaimNotice(null), 5000);
  };

  const shareText = `🏆 *Task Earn Pro - 100% Real Gold Investment Proof!*
👤 Investor: ${investorName} (ID: ${investorUserId})
💎 Plan: ₹${investedAmount.toLocaleString()} Gold Mine (30 Days)
📈 Daily Return: ₹${dailyReturn}/Day (30 দিনে মোট ₹${totalReturn.toLocaleString()} লাভ!)
💸 Task Withdrawal: ₹${taskWithdrawal.toLocaleString()} সফলভাবে পেয়েছি!
🏦 Bank UTR: ${withdrawalUtr} (State Bank of India)
✅ এটি 100% রিয়েল এবং বিশ্বস্ত অ্যাপ। তোমরাও ইনভেস্ট করে প্রতিদিন ইনকাম করো:
👉 ${window.location.origin}`;

  const handleShareWhatsApp = () => {
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`;
    const a = document.createElement('a');
    a.href = url;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    a.click();
  };

  const handleCopyProof = () => {
    navigator.clipboard.writeText(shareText);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleCopyUtr = () => {
    navigator.clipboard.writeText(withdrawalUtr);
    setCopiedUtr(true);
    setTimeout(() => setCopiedUtr(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div 
        className="w-full max-w-lg my-auto rounded-3xl bg-slate-900 border-2 border-amber-500/50 shadow-2xl overflow-hidden relative text-white"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Gold ambient background accents */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-yellow-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Top Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-amber-950 via-slate-900 to-amber-950 border-b border-amber-500/30 flex items-center justify-between relative z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center text-xl shadow-md shadow-amber-500/10">
              🏆
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-amber-400 block">
                Official Proof & Certificate
              </span>
              <h2 className="text-base sm:text-lg font-black text-white tracking-tight flex items-center gap-1.5">
                <span>Gold Mine ₹5,000 Investment</span>
                <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  100% REAL
                </span>
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800/80 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors cursor-pointer border border-slate-700"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 space-y-4 max-h-[80vh] overflow-y-auto relative z-10 text-xs">
          
          {/* Claim Toast Notice */}
          {claimNotice && (
            <div className="p-3 rounded-2xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-200 text-xs font-bold flex items-center gap-2 animate-in zoom-in-95">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{claimNotice}</span>
            </div>
          )}

          {/* Bengali Trust Banner for Friends */}
          <div className="p-3.5 sm:p-4 rounded-2xl bg-gradient-to-r from-amber-500/20 via-yellow-500/15 to-emerald-500/20 border border-amber-500/40 space-y-1.5">
            <div className="flex items-center gap-2 text-amber-300 font-black text-xs sm:text-sm">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>বন্ধুদের দেখানোর গ্যারান্টি প্রুফ (100% Real App)</span>
            </div>
            <p className="text-[11px] text-slate-200 leading-relaxed">
              &quot;আমার বন্ধুরা যাতে বিশ্বাস করে এটি কোনো ফেক অ্যাপ নয় — এখানে <strong className="text-amber-300 font-bold">সুভদীপ গড়াই (Subhodip Garai)</strong> ₹৫,০০০ টাকার 30-Day Gold Mine কিনেছেন, প্রতিদিন <strong className="text-emerald-300 font-bold">₹৩০০ টাকা</strong> নিশ্চিত রিটার্ন পাচ্ছেন এবং <strong className="text-amber-300 font-bold">₹১,০০০ টাকা টাস্ক উইথড্রয়াল</strong> সফলভাবে ব্যাংক অ্যাকাউন্টে পেয়েছেন।&quot;
            </p>
          </div>

          {/* Investor ID Card Preview */}
          <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-yellow-950/40 border-2 border-amber-500/60 shadow-xl space-y-3 relative overflow-hidden">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-300 p-0.5 shadow-md">
                  <div className="w-full h-full rounded-2xl bg-slate-900 flex items-center justify-center font-black text-amber-300 text-lg">
                    SG
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-black text-white">{investorName}</h3>
                    <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      VIP 5 GOLD
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono mt-0.5">
                    <span>User ID: <strong className="text-slate-200">{investorUserId}</strong></span>
                    <span>•</span>
                    <span className="text-amber-400 font-bold">{investorUsername}</span>
                  </div>
                </div>
              </div>

              <span className="px-2.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>KYC Verified</span>
              </span>
            </div>

            {/* 4 Gold Mine Financial Metric Badges */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-800">
              <div className="p-2.5 rounded-xl bg-slate-950/90 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-400 block font-medium">Invested Amount</span>
                <span className="text-sm font-black text-amber-400 font-mono">₹{investedAmount.toLocaleString()}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950/90 border border-emerald-800/40 text-center">
                <span className="text-[10px] text-slate-400 block font-medium">Daily Return</span>
                <span className="text-sm font-black text-emerald-400 font-mono">+₹{dailyReturn}/day</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950/90 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-400 block font-medium">Total 30-Day Return</span>
                <span className="text-sm font-black text-white font-mono">₹{totalReturn.toLocaleString()}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950/90 border border-yellow-800/40 text-center">
                <span className="text-[10px] text-slate-400 block font-medium">Net Profit (ROI)</span>
                <span className="text-sm font-black text-amber-300 font-mono">+₹{netProfit.toLocaleString()} (80%)</span>
              </div>
            </div>

            {/* 30-Day Progress Bar */}
            <div className="space-y-1.5 pt-1">
              <div className="flex justify-between text-[11px] font-semibold text-slate-300">
                <span>Gold Mining Maturity Status</span>
                <span className="text-amber-300 font-mono font-bold">Day {currentDay} of {durationDays} Days</span>
              </div>
              <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 rounded-full"
                  style={{ width: `${(currentDay / durationDays) * 100}%` }}
                />
              </div>
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>Total Claimed So Far: <strong className="text-emerald-400 font-mono">₹{(currentDay * dailyReturn).toLocaleString()}</strong></span>
                <span>Remaining: <strong className="text-slate-300 font-mono">₹{(totalReturn - (currentDay * dailyReturn)).toLocaleString()}</strong></span>
              </div>
            </div>
          </div>

          {/* Claim Today's Daily Return (+₹300) Action */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/50 via-slate-900 to-emerald-950/50 border border-emerald-500/40 flex items-center justify-between gap-3 flex-wrap">
            <div className="space-y-0.5">
              <div className="flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-yellow-400" />
                <span className="font-black text-white text-xs sm:text-sm">Daily Return Credit (+₹{dailyReturn})</span>
              </div>
              <p className="text-[10px] text-slate-300">
                Gold Mine yield auto-generates ₹300 every 24 hours.
              </p>
            </div>

            <button
              type="button"
              onClick={handleClaimToday}
              disabled={hasClaimedToday}
              className={`px-4 py-2.5 rounded-xl font-black text-xs shadow-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                hasClaimedToday
                  ? 'bg-slate-800 text-slate-400 cursor-not-allowed border border-slate-700'
                  : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-emerald-600/25 active:scale-95'
              }`}
            >
              {hasClaimedToday ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Claimed for Today</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5 text-yellow-300 animate-spin" />
                  <span>Claim Today’s ₹{dailyReturn}</span>
                </>
              )}
            </button>
          </div>

          {/* Task Withdrawal Proof Card (₹1,000) */}
          <div className="p-4 sm:p-5 rounded-3xl bg-slate-950 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center text-sm font-bold">
                  💸
                </div>
                <div>
                  <h4 className="font-black text-white text-xs sm:text-sm">
                    Verified Task Withdrawal Proof (₹1,000)
                  </h4>
                  <span className="text-[10px] text-slate-400">
                    VIP Fast Payout Approved & Credited
                  </span>
                </div>
              </div>

              <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>SUCCESS</span>
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 space-y-2 font-mono text-[11px]">
              <div className="flex justify-between text-slate-400">
                <span>Withdrawal Amount:</span>
                <span className="text-emerald-400 font-bold font-sans">₹{taskWithdrawal.toLocaleString()}.00 INR</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Payment Mode:</span>
                <span className="text-white">UPI Instant Transfer</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Recipient Account:</span>
                <span className="text-amber-300">{investorUpi}</span>
              </div>
              <div className="flex justify-between items-center text-slate-400 pt-1 border-t border-slate-800">
                <span>Bank UTR Reference:</span>
                <button
                  type="button"
                  onClick={handleCopyUtr}
                  className="flex items-center gap-1 text-sky-400 hover:text-sky-300 font-bold cursor-pointer"
                  title="Copy UTR Reference"
                >
                  <span>{withdrawalUtr}</span>
                  {copiedUtr ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                </button>
              </div>
            </div>

            <p className="text-[10px] text-slate-400 leading-relaxed italic">
              * Official State Bank of India UPI confirmation ref UTR: {withdrawalUtr}. Funds credited directly to {investorName}’s linked account.
            </p>
          </div>

          {/* Real App Verification Badges */}
          <div className="grid grid-cols-2 gap-2 text-[10px]">
            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <div>
                <span className="text-white font-bold block">100% Real App</span>
                <span className="text-slate-400">Pure 24K Bullion Vault</span>
              </div>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-400 shrink-0" />
              <div>
                <span className="text-white font-bold block">Government CIN Verified</span>
                <span className="text-slate-400">U74999DL2026PTC108921</span>
              </div>
            </div>
          </div>

          {/* Social Proof Actions: WhatsApp Share & Copy Proof */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
            <button
              type="button"
              onClick={handleShareWhatsApp}
              className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95"
            >
              <Share2 className="w-4 h-4" />
              <span>Share Proof to Friends on WhatsApp</span>
            </button>

            <button
              type="button"
              onClick={handleCopyProof}
              className="w-full py-3 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-black text-xs flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95"
            >
              {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-amber-400" />}
              <span>{copiedLink ? 'Proof Details Copied!' : 'Copy Real Proof Text'}</span>
            </button>
          </div>

          {/* Quick links */}
          {onOpenWithdrawal && (
            <div className="text-center pt-1">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenWithdrawal();
                }}
                className="text-[11px] font-bold text-amber-400 hover:underline cursor-pointer"
              >
                Go to Wallet & Withdraw ₹1,000 Task Earnings →
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
