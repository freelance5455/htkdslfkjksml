import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  ShieldCheck, 
  X, 
  Check, 
  ArrowRight, 
  Zap, 
  Award,
  CheckCircle2,
  Phone,
  CreditCard,
  Lock,
  User,
  AlertCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { MetalType } from '../../types';
import { UpiPaymentModal } from './UpiPaymentModal';

interface BuySellModalProps {
  isOpen: boolean;
  onClose: () => void;
  metalType: MetalType;
  initialMode?: 'buy' | 'sell';
}

export const BuySellModal: React.FC<BuySellModalProps> = ({
  isOpen,
  onClose,
  metalType,
  initialMode = 'buy',
}) => {
  const { 
    currentUser, 
    goldPricePerGram, 
    silverPricePerGram, 
    buyMetal, 
    sellMetal, 
    investmentOrders,
    systemSettings,
    kycRecords,
    submitKyc,
  } = useApp();

  const [mode, setMode] = useState<'buy' | 'sell'>(initialMode);
  const [amountINR, setAmountINR] = useState<number>(metalType === 'gold' ? 300 : 100);
  const [couponCode, setCouponCode] = useState<string>('');
  const [couponApplied, setCouponApplied] = useState<boolean>(false);
  const [couponDiscount, setCouponDiscount] = useState<number>(0);
  const [couponError, setCouponError] = useState<string>('');
  const [sellGrams, setSellGrams] = useState<number>(1);
  const [loading, setLoading] = useState<boolean>(false);
  const [successMsg, setSuccessMsg] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [isUpiModalOpen, setIsUpiModalOpen] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      setMode(initialMode);
      setAmountINR(metalType === 'gold' ? 300 : 100);
      setCouponApplied(false);
      setCouponDiscount(0);
      setCouponError('');
      setErrorMsg('');
      setSuccessMsg('');
    }
  }, [isOpen, metalType, initialMode]);

  // Aadhaar KYC & Mobile states for Gold purchase
  const userKyc = kycRecords.find(r => r.userId === currentUser?.id && r.status === 'verified');
  const userMobile = userKyc?.mobileNumber || currentUser?.phone || '';
  const hasAadhaar = Boolean(userKyc && userKyc.aadhaarMasked);
  const hasMobile = Boolean(userMobile && userMobile.trim().length >= 10);
  const isGoldKycCompleted = Boolean(hasAadhaar && hasMobile);

  const [kycFullName, setKycFullName] = useState(currentUser?.name || '');
  const [kycAadhaar, setKycAadhaar] = useState('');
  const [kycMobile, setKycMobile] = useState(currentUser?.phone || '');
  const [kycSubmitting, setKycSubmitting] = useState(false);
  const [kycInlineError, setKycInlineError] = useState('');
  const [kycInlineSuccess, setKycInlineSuccess] = useState('');

  if (!isOpen) return null;

  const currentPrice = metalType === 'gold' ? goldPricePerGram : silverPricePerGram;
  const metalName = metalType === 'gold' ? 'Digital Gold (24K 99.9%)' : 'Digital Silver (99.9%)';

  // Calculate user holding
  const userOrders = investmentOrders.filter(o => o.userId === currentUser?.id && o.metalType === metalType && o.status === 'completed');
  const totalBought = userOrders.filter(o => o.orderType === 'buy').reduce((s, o) => s + o.grams, 0);
  const totalSold = userOrders.filter(o => o.orderType === 'sell').reduce((s, o) => s + o.grams, 0);
  const netHolding = Number((totalBought - totalSold).toFixed(4));

  const quickAmounts = metalType === 'gold' 
    ? [300, 500, 1000, 2000, 5000, 10000]
    : [100, 200, 500, 1000, 2000, 5000, 10000];

  const handleQuickVerifyKyc = (e: React.FormEvent) => {
    e.preventDefault();
    setKycInlineError('');
    setKycInlineSuccess('');
    const cleanAadhaar = kycAadhaar.replace(/\D/g, '');
    const cleanMobile = kycMobile.replace(/\D/g, '');

    if (!kycFullName.trim()) {
      setKycInlineError('Please enter full legal name (আপনার সম্পূর্ণ নাম লিখুন)');
      return;
    }
    if (cleanAadhaar.length !== 12) {
      setKycInlineError('Aadhaar number must be exactly 12 digits (১২ সংখ্যার আধার নম্বর দিন)');
      return;
    }
    if (cleanMobile.length !== 10) {
      setKycInlineError('Mobile number must be exactly 10 digits (১০ সংখ্যার সঠিক মোবাইল নম্বর দিন)');
      return;
    }

    setKycSubmitting(true);
    setTimeout(() => {
      const res = submitKyc(
        kycFullName.trim(),
        '2001-05-14',
        cleanAadhaar,
        'UPI / Bank Linked Account',
        cleanMobile
      );
      setKycSubmitting(false);
      if (res.success) {
        confetti({ particleCount: 70, spread: 80 });
        setKycInlineSuccess('Aadhaar KYC Completed & Mobile Number Added! You can now buy Gold.');
      } else {
        setKycInlineError(res.message);
      }
    }, 600);
  };

  const handleApplyCoupon = () => {
    // Disabled for gold
    if (metalType === 'gold') {
      setCouponError('Coupons are not applicable for Gold purchases.');
      return;
    }
    setCouponError('');
    if (!couponCode.trim()) return;
    if (couponCode.toUpperCase() === 'TODAY60') {
      if (amountINR < 100) {
        setCouponError('Minimum investment ₹100 required.');
        return;
      }
      setCouponApplied(true);
      setCouponDiscount(60);
      confetti({ particleCount: 30, spread: 40 });
    } else {
      setCouponError('Invalid or expired coupon code.');
      setCouponApplied(false);
      setCouponDiscount(0);
    }
  };

  const netPayableINR = Math.max(0, amountINR - (metalType !== 'gold' && couponApplied ? couponDiscount : 0));
  const estimatedGrams = Number((netPayableINR / currentPrice).toFixed(4));

  const handleExecute = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (mode === 'buy') {
      const minRequired = metalType === 'gold' ? 300 : 100;
      if (amountINR < minRequired) {
        setErrorMsg(
          metalType === 'gold'
            ? 'Minimum Gold investment amount is ₹300 (ন্যূনতম গোল্ড ক্রয় ₹৩০০ থেকে শুরু, ₹১০০ গ্রহণযোগ্য নয়)।'
            : 'Minimum investment amount is ₹100 (ন্যূনতম বিনিয়োগ ₹১০০ থেকে শুরু)।'
        );
        return;
      }
      if (metalType === 'gold' && !isGoldKycCompleted) {
        setErrorMsg('গোল্ড কেনার জন্য আধার কার্ড KYC ও মোবাইল নম্বর ভেরিফিকেশন সম্পূর্ণ করুন (Aadhaar Card KYC & Mobile Number required to buy Gold)।');
        return;
      }
      setIsUpiModalOpen(true);
    } else {
      setLoading(true);
      setTimeout(() => {
        setLoading(false);
        const res = sellMetal(metalType, sellGrams);
        if (res.success) {
          setSuccessMsg(res.message);
          confetti({ particleCount: 70, spread: 80 });
          setTimeout(() => onClose(), 2200);
        } else {
          setErrorMsg(res.message);
        }
      }, 600);
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
        <div className="w-full max-w-md bg-slate-900 border border-amber-500/35 rounded-3xl p-5 sm:p-6 shadow-2xl relative space-y-4 text-white">
          
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white bg-slate-800/80 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>

          {/* Header */}
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-xl shadow-lg ${
              metalType === 'gold' 
                ? 'bg-gradient-to-tr from-amber-500 to-yellow-300 text-slate-950 shadow-amber-500/20' 
                : 'bg-gradient-to-tr from-slate-300 to-slate-100 text-slate-950 shadow-slate-300/20'
            }`}>
              {metalType === 'gold' ? '🏆' : '🥈'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black tracking-tight">{metalName}</h2>
                <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  LIVE RATE
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono">
                ₹{currentPrice.toLocaleString()} / gram (99.9% Purity)
              </p>
            </div>
          </div>

          {/* Tomorrow's Price Growth Forecast Widget */}
          <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-[11px] flex items-center justify-between">
            <span className="font-bold flex items-center gap-1.5">
              <span>📈</span>
              <span>Tomorrow's Forecast:</span>
            </span>
            <span className="font-black text-emerald-400">
              Expected +0.6% to +1.2% Tomorrow 🚀
            </span>
          </div>

          {/* Mode Switcher */}
          <div className="grid grid-cols-2 gap-2 p-1 bg-slate-950 rounded-2xl border border-slate-800">
            <button
              type="button"
              onClick={() => setMode('buy')}
              className={`py-2.5 rounded-xl font-black text-xs transition-all cursor-pointer ${
                mode === 'buy'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Buy {metalType.toUpperCase()}
            </button>
            <button
              type="button"
              onClick={() => setMode('sell')}
              className={`py-2.5 rounded-xl font-black text-xs transition-all cursor-pointer ${
                mode === 'sell'
                  ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-md shadow-purple-600/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Sell {metalType.toUpperCase()}
            </button>
          </div>

          {errorMsg && (
            <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-semibold">
              {errorMsg}
            </div>
          )}

          {successMsg && (
            <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          <form onSubmit={handleExecute} className="space-y-4 text-xs">
            
            {mode === 'buy' ? (
              <>
                {/* Amount Selection */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="font-bold text-slate-300">Investment Amount (INR)</label>
                    <span className="text-[10px] text-amber-400 font-bold">
                      {metalType === 'gold' ? 'Minimum Gold Buy ₹300' : 'Minimum Investment ₹100'}
                    </span>
                  </div>
                  
                  <div className="relative">
                    <span className="absolute left-3.5 top-3 text-slate-400 font-bold text-sm">₹</span>
                    <input
                      type="number"
                      min={metalType === 'gold' ? 300 : 100}
                      value={amountINR}
                      onChange={(e) => {
                        setAmountINR(Number(e.target.value));
                        setCouponApplied(false);
                      }}
                      className="w-full pl-8 pr-4 py-3 rounded-2xl bg-slate-950 border border-slate-700 text-white font-black text-base focus:border-amber-500 focus:outline-none"
                      required
                    />
                  </div>

                  {/* Quick Amounts */}
                  <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-1">
                    {quickAmounts.map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => {
                          setAmountINR(amt);
                          setCouponApplied(false);
                        }}
                        className={`px-3 py-1.5 rounded-xl text-[11px] font-black transition-all cursor-pointer whitespace-nowrap ${
                          amountINR === amt
                            ? 'bg-amber-500 text-slate-950'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                        }`}
                      >
                        ₹{amt.toLocaleString()}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Aadhaar KYC & Mobile Number Requirement Section for Gold Buy */}
                {metalType === 'gold' ? (
                  <div className="space-y-2">
                    {isGoldKycCompleted ? (
                      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/70 via-slate-900 to-slate-950 border border-emerald-500/40 text-emerald-300 space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                              <CheckCircle2 className="w-4 h-4" />
                            </div>
                            <div>
                              <span className="font-black text-xs text-white block">Aadhaar KYC & Mobile Verified</span>
                              <span className="text-[10px] text-emerald-400 font-semibold">আধার কার্ড KYC ও মোবাইল নম্বর ভেরিফাইড সম্পন্ন</span>
                            </div>
                          </div>
                          <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                            VERIFIED
                          </span>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-[11px] pt-1.5 border-t border-emerald-500/20">
                          <div className="bg-slate-950/70 p-2 rounded-xl border border-emerald-500/20">
                            <span className="text-slate-400 block text-[9px] font-bold">Aadhaar Card:</span>
                            <span className="font-mono font-black text-white">{userKyc?.aadhaarMasked}</span>
                          </div>
                          <div className="bg-slate-950/70 p-2 rounded-xl border border-emerald-500/20">
                            <span className="text-slate-400 block text-[9px] font-bold">Linked Mobile:</span>
                            <span className="font-mono font-black text-white">+91 {userMobile}</span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="p-4 rounded-2xl bg-gradient-to-b from-amber-950/60 via-slate-950 to-slate-950 border border-amber-500/40 space-y-3">
                        <div className="flex items-start gap-2.5">
                          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center shrink-0 mt-0.5">
                            <ShieldCheck className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <h4 className="text-xs font-black text-white">Aadhaar Card KYC & Mobile Required</h4>
                              <span className="px-1.5 py-0.5 rounded text-[8px] font-black uppercase bg-rose-500/20 text-rose-300 border border-rose-500/30">MANDATORY</span>
                            </div>
                            <p className="text-[10px] text-amber-300/90 leading-tight mt-0.5">
                              গোল্ড কিনতে ১২-ডিজিট আধার কার্ড KYC সম্পূর্ণ করুন এবং ১০-সংখ্যার মোবাইল নম্বর যোগ করুন।
                            </p>
                          </div>
                        </div>

                        {kycInlineError && (
                          <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-[10px] font-bold">
                            {kycInlineError}
                          </div>
                        )}

                        {kycInlineSuccess && (
                          <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold">
                            {kycInlineSuccess}
                          </div>
                        )}

                        <div className="space-y-2 text-xs">
                          <div>
                            <label className="text-[10px] font-bold text-slate-300 block mb-1">Full Legal Name (আপনার পূর্ণ নাম)</label>
                            <div className="relative">
                              <User className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                              <input
                                type="text"
                                value={kycFullName}
                                onChange={(e) => setKycFullName(e.target.value)}
                                placeholder="Subhodip Garai"
                                className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-amber-500"
                              />
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="text-[10px] font-bold text-slate-300 block mb-1">Aadhaar (১২ ডিজিট আধার)</label>
                              <div className="relative">
                                <CreditCard className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                                <input
                                  type="text"
                                  maxLength={12}
                                  value={kycAadhaar}
                                  onChange={(e) => setKycAadhaar(e.target.value)}
                                  placeholder="245089421209"
                                  className="w-full pl-8 pr-2 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-mono tracking-wider focus:outline-none focus:border-amber-500"
                                />
                              </div>
                            </div>
                            <div>
                              <label className="text-[10px] font-bold text-slate-300 block mb-1">Mobile (১০ ডিজিট মোবাইল)</label>
                              <div className="relative">
                                <Phone className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                                <input
                                  type="tel"
                                  maxLength={10}
                                  value={kycMobile}
                                  onChange={(e) => setKycMobile(e.target.value)}
                                  placeholder="9635776190"
                                  className="w-full pl-8 pr-2 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-mono tracking-wider focus:outline-none focus:border-amber-500"
                                />
                              </div>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={handleQuickVerifyKyc}
                            disabled={kycSubmitting}
                            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs shadow-md shadow-amber-500/20 cursor-pointer transition-all flex items-center justify-center gap-1.5"
                          >
                            <ShieldCheck className="w-3.5 h-3.5" />
                            <span>{kycSubmitting ? 'ভেরিফাই হচ্ছে...' : 'Complete Aadhaar KYC & Add Mobile (আধার ভেরিফাই করুন)'}</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                ) : null}

                {/* Order Summary */}
                <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2 text-xs">
                  <div className="flex justify-between text-slate-400">
                    <span>Estimated Quantity:</span>
                    <span className="font-black text-white">{estimatedGrams} grams</span>
                  </div>
                  {metalType !== 'gold' && couponApplied && (
                    <div className="flex justify-between text-emerald-400 font-bold">
                      <span>Coupon Discount:</span>
                      <span>- ₹{couponDiscount}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-slate-400 pt-1 border-t border-slate-800">
                    <span>Final Payable Amount:</span>
                    <span className="font-black text-amber-400 text-sm">₹{netPayableINR.toLocaleString()}</span>
                  </div>
                </div>
              </>
            ) : (
              <>
                {/* Sell Flow */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="font-bold text-slate-300">Sell Quantity (Grams)</label>
                    <span className="text-[10px] text-emerald-400 font-bold">Available: {netHolding}g</span>
                  </div>

                  <div className="relative">
                    <input
                      type="number"
                      step="0.0001"
                      min={0.0001}
                      max={netHolding}
                      value={sellGrams}
                      onChange={(e) => setSellGrams(Number(e.target.value))}
                      className="w-full px-4 py-3 rounded-2xl bg-slate-950 border border-slate-700 text-white font-black text-base focus:border-purple-500 focus:outline-none"
                      required
                    />
                    <span className="absolute right-4 top-3.5 text-slate-400 font-bold">grams</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1.5 text-xs">
                    <div className="flex justify-between text-slate-400">
                      <span>Estimated Payout (INR):</span>
                      <span className="font-black text-emerald-400 text-sm">₹{(sellGrams * currentPrice).toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </>
            )}

            {/* Secure Execution Button */}
            <button
              type="submit"
              disabled={loading || (mode === 'buy' && metalType === 'gold' && !isGoldKycCompleted)}
              className={`w-full py-3.5 rounded-2xl font-black text-xs shadow-lg flex items-center justify-center gap-2 transition-all cursor-pointer ${
                mode === 'buy' && metalType === 'gold' && !isGoldKycCompleted
                  ? 'bg-slate-800 text-amber-400/80 border border-amber-500/30 cursor-not-allowed opacity-80'
                  : mode === 'buy'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 shadow-amber-500/25'
                  : 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white shadow-purple-600/25'
              }`}
            >
              {loading ? (
                <span>Processing Secure Transaction...</span>
              ) : mode === 'buy' && metalType === 'gold' && !isGoldKycCompleted ? (
                <>
                  <AlertCircle className="w-4 h-4 text-amber-400" />
                  <span>Complete Aadhaar KYC & Add Mobile to Buy Gold</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>{mode === 'buy' ? `Pay ₹${netPayableINR.toLocaleString()} & Buy ${metalType.toUpperCase()}` : `Confirm Sell Order`}</span>
                </>
              )}
            </button>
          </form>

          <p className="text-[10px] text-slate-500 text-center leading-tight">
            🔒 Real INR UPI Payment Gateway • Zero Task Coins Deduction • Server-side Verification.
          </p>
        </div>
      </div>

      <UpiPaymentModal
        isOpen={isUpiModalOpen}
        onClose={() => setIsUpiModalOpen(false)}
        metalType={metalType}
        amountINR={amountINR}
        netPayableINR={netPayableINR}
        estimatedGrams={estimatedGrams}
        couponCode={couponApplied ? couponCode : undefined}
        discountINR={couponApplied ? couponDiscount : undefined}
        onSuccess={(msg) => {
          setSuccessMsg(msg);
          setTimeout(() => onClose(), 2000);
        }}
      />
    </>
  );
};
