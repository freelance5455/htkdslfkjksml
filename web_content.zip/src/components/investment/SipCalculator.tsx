import React, { useState, useId } from 'react';
import { 
  Calculator, 
  TrendingUp, 
  Calendar, 
  Coins, 
  ArrowRight, 
  Sparkles, 
  ShieldCheck, 
  HelpCircle, 
  Info, 
  Percent, 
  Clock, 
  CheckCircle2,
  RefreshCw,
  X
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { GoldBullionVisual } from '../common/GoldBullionVisual';
import { SilverBullionVisual } from '../common/SilverBullionVisual';
import { useApp } from '../../context/AppContext';
import { MetalType, SipFrequency } from '../../types';

interface SipCalculatorProps {
  onStartSip?: (metal: MetalType, amount: number, frequency: SipFrequency) => void;
  onClose?: () => void;
  isModal?: boolean;
}

export const SipCalculator: React.FC<SipCalculatorProps> = ({
  onStartSip,
  onClose,
  isModal = false,
}) => {
  const { goldPricePerGram, silverPricePerGram } = useApp();
  const formId = useId();

  // Inputs
  const [metal, setMetal] = useState<MetalType>('gold');
  const [installmentAmount, setInstallmentAmount] = useState<number>(1000);
  const [frequency, setFrequency] = useState<SipFrequency>('monthly');
  const [durationYears, setDurationYears] = useState<number>(3); // 1 to 15 years
  const [expectedAnnualReturn, setExpectedAnnualReturn] = useState<number>(13.5); // 13.5% default historical CAGR for Gold
  const [targetWealthGoal, setTargetWealthGoal] = useState<number>(100000);
  const [activeTab, setActiveTab] = useState<'sip_returns' | 'target_goal'>('sip_returns');

  // Market reference prices
  const currentPricePerGram = metal === 'gold' ? goldPricePerGram : silverPricePerGram;

  // Preset return benchmarks
  const handleMetalChange = (newMetal: MetalType) => {
    setMetal(newMetal);
    if (newMetal === 'gold') {
      setExpectedAnnualReturn(13.5); // Historical 10y CAGR for 24K Gold in India is ~12-14%
    } else {
      setExpectedAnnualReturn(15.0); // Silver has higher volatility / industrial demand growth
    }
  };

  // Convert frequency to number of installments per year
  const getPeriodsPerYear = (freq: SipFrequency) => {
    switch (freq) {
      case 'daily': return 365;
      case 'weekly': return 52;
      case 'monthly': return 12;
      default: return 12;
    }
  };

  const periodsPerYear = getPeriodsPerYear(frequency);
  const totalInstallments = periodsPerYear * durationYears;
  const periodicRate = (expectedAnnualReturn / 100) / periodsPerYear;

  // Total Invested Capital
  const totalInvested = installmentAmount * totalInstallments;

  // Compound Maturity Future Value for SIP (Annuity due or ordinary annuity formula):
  // FV = P * [ ((1 + r)^n - 1) / r ] * (1 + r)
  const futureValue = periodicRate > 0 
    ? Math.round(installmentAmount * ((Math.pow(1 + periodicRate, totalInstallments) - 1) / periodicRate) * (1 + periodicRate))
    : totalInvested;

  const estimatedProfit = Math.max(0, futureValue - totalInvested);
  const profitPercentage = totalInvested > 0 ? ((estimatedProfit / totalInvested) * 100).toFixed(1) : '0';

  // Grams accumulated estimate (assuming dynamic average price appreciation over tenure)
  // Approximate average purchase price over tenure: currentPrice * (1 + (expectedAnnualReturn/100)/2 * durationYears/2)
  const projectedAvgPrice = currentPricePerGram * (1 + (expectedAnnualReturn / 100) * 0.4);
  const estimatedAccumulatedGrams = Number((futureValue / projectedAvgPrice).toFixed(3));

  // Reverse Goal calculation: How much SIP required to reach targetWealthGoal?
  const requiredSipMonthly = periodicRate > 0
    ? Math.round(targetWealthGoal / (((Math.pow(1 + periodicRate, totalInstallments) - 1) / periodicRate) * (1 + periodicRate)))
    : Math.round(targetWealthGoal / totalInstallments);

  const handleApplySip = () => {
    confetti({ particleCount: 60, spread: 70 });
    if (onStartSip) {
      onStartSip(metal, installmentAmount, frequency);
    }
  };

  const content = (
    <div className="space-y-5 text-slate-100">
      {/* Header bar */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 via-amber-600 to-yellow-400 text-slate-950 flex items-center justify-center font-black shadow-lg shadow-amber-500/20">
            <Calculator className="w-5 h-5 text-slate-950" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-black text-white tracking-tight">
                Gold & Silver SIP Calculator
              </h2>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[9px] font-black uppercase">
                Compound Wealth
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Calculate future returns, profit & accumulated grams with live market compounding
            </p>
          </div>
        </div>

        {isModal && onClose && (
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Mode Tabs */}
      <div className="flex p-1 rounded-2xl bg-slate-950 border border-slate-800 text-xs font-bold">
        <button
          type="button"
          onClick={() => setActiveTab('sip_returns')}
          className={`flex-1 py-2 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            activeTab === 'sip_returns'
              ? 'bg-amber-500 text-slate-950 shadow-md font-black'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5" />
          <span>Calculate SIP Returns</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('target_goal')}
          className={`flex-1 py-2 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            activeTab === 'target_goal'
              ? 'bg-amber-500 text-slate-950 shadow-md font-black'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Goal-Based Planner</span>
        </button>
      </div>

      {/* Asset Selection (Gold vs Silver) */}
      <div className="grid grid-cols-2 gap-3">
        <button
          type="button"
          onClick={() => handleMetalChange('gold')}
          className={`p-3 rounded-2xl border transition-all cursor-pointer text-left relative overflow-hidden flex items-center justify-between ${
            metal === 'gold'
              ? 'bg-gradient-to-r from-amber-950/80 via-slate-900 to-amber-900/40 border-amber-500/80 shadow-lg shadow-amber-500/10'
              : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl overflow-hidden shrink-0 border border-amber-500/40">
              <GoldBullionVisual size="sm" />
            </div>
            <div>
              <span className="text-xs font-black text-amber-300 block">24K Digital Gold</span>
              <span className="text-[10px] text-slate-400">₹{goldPricePerGram.toLocaleString()}/g • 13.5% CAGR</span>
            </div>
          </div>
          {metal === 'gold' && <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 ml-1" />}
        </button>

        <button
          type="button"
          onClick={() => handleMetalChange('silver')}
          className={`p-3 rounded-2xl border transition-all cursor-pointer text-left relative overflow-hidden flex items-center justify-between ${
            metal === 'silver'
              ? 'bg-gradient-to-r from-slate-900 via-cyan-950/50 to-slate-900 border-cyan-400/80 shadow-lg shadow-cyan-500/10'
              : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl overflow-hidden shrink-0 border border-slate-400/40">
              <SilverBullionVisual size="sm" />
            </div>
            <div>
              <span className="text-xs font-black text-slate-200 block">999 Pure Silver</span>
              <span className="text-[10px] text-slate-400">₹{silverPricePerGram.toLocaleString()}/g • 15.0% CAGR</span>
            </div>
          </div>
          {metal === 'silver' && <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 ml-1" />}
        </button>
      </div>

      {activeTab === 'sip_returns' ? (
        <>
          {/* Controls Container */}
          <div className="p-4 sm:p-5 rounded-3xl bg-slate-950/90 border border-slate-800/80 space-y-4">
            {/* Frequency Selection */}
            <div>
              <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block mb-1.5">
                SIP Frequency
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['daily', 'weekly', 'monthly'] as SipFrequency[]).map((freq) => (
                  <button
                    key={freq}
                    type="button"
                    onClick={() => setFrequency(freq)}
                    className={`py-2 px-3 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer border ${
                      frequency === freq
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/60 font-black'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                    }`}
                  >
                    {freq}
                  </button>
                ))}
              </div>
            </div>

            {/* Installment Amount Slider & Input */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label htmlFor={`${formId}-amount`} className="text-[11px] font-bold text-slate-300">
                  {frequency.toUpperCase()} Installment Amount
                </label>
                <div className="flex items-center gap-1 bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1">
                  <span className="text-amber-400 font-bold text-xs">₹</span>
                  <input
                    id={`${formId}-amount`}
                    type="number"
                    min={50}
                    max={100000}
                    step={50}
                    value={installmentAmount}
                    onChange={(e) => setInstallmentAmount(Math.max(50, Number(e.target.value)))}
                    className="w-20 bg-transparent text-right font-black text-white text-xs focus:outline-none font-mono"
                  />
                </div>
              </div>
              <input
                type="range"
                min={50}
                max={frequency === 'daily' ? 2000 : frequency === 'weekly' ? 10000 : 25000}
                step={frequency === 'daily' ? 20 : frequency === 'weekly' ? 100 : 250}
                value={installmentAmount}
                onChange={(e) => setInstallmentAmount(Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
              <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-0.5">
                {[100, 500, 1000, 2500, 5000].map((quickAmt) => (
                  <button
                    key={quickAmt}
                    type="button"
                    onClick={() => setInstallmentAmount(quickAmt)}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-bold cursor-pointer transition-colors ${
                      installmentAmount === quickAmt
                        ? 'bg-amber-500 text-slate-950 font-black'
                        : 'bg-slate-900 text-slate-300 border border-slate-800 hover:bg-slate-800'
                    }`}
                  >
                    ₹{quickAmt.toLocaleString()}
                  </button>
                ))}
              </div>
            </div>

            {/* Duration Slider (Years) */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-bold text-slate-300">
                  Investment Duration (Time Horizon)
                </label>
                <span className="text-xs font-black text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded-lg border border-amber-500/30">
                  {durationYears} {durationYears === 1 ? 'Year' : 'Years'} ({totalInstallments} installments)
                </span>
              </div>
              <input
                type="range"
                min={1}
                max={15}
                step={1}
                value={durationYears}
                onChange={(e) => setDurationYears(Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>1 Year</span>
                <span>3 Years</span>
                <span>5 Years</span>
                <span>10 Years</span>
                <span>15 Years</span>
              </div>
            </div>

            {/* Expected Annual Rate of Return */}
            <div className="space-y-2 pt-2 border-t border-slate-800">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <label htmlFor={`${formId}-return`} className="text-[11px] font-bold text-slate-300">
                    Expected Annual Return (CAGR)
                  </label>
                  <span className="text-[9px] text-slate-400">(Historical benchmark)</span>
                </div>
                <div className="flex items-center gap-1 bg-slate-900 border border-slate-700 rounded-xl px-2 py-1">
                  <input
                    id={`${formId}-return`}
                    type="number"
                    min={5}
                    max={30}
                    step={0.5}
                    value={expectedAnnualReturn}
                    onChange={(e) => setExpectedAnnualReturn(Number(e.target.value))}
                    className="w-12 bg-transparent text-right font-black text-emerald-400 text-xs focus:outline-none font-mono"
                  />
                  <span className="text-emerald-400 font-bold text-xs">%</span>
                </div>
              </div>
              <input
                type="range"
                min={8}
                max={25}
                step={0.5}
                value={expectedAnnualReturn}
                onChange={(e) => setExpectedAnnualReturn(Number(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>
          </div>

          {/* Projection Results Showcase Card */}
          <div className="p-5 rounded-3xl bg-gradient-to-br from-amber-950/70 via-slate-900 to-indigo-950/70 border border-amber-500/50 shadow-2xl relative overflow-hidden space-y-4">
            <div className="absolute top-0 right-0 w-36 h-36 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black uppercase text-amber-400 tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Projected Maturity Value</span>
              </span>
              <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                +{profitPercentage}% Profit
              </span>
            </div>

            <div>
              <div className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-baseline gap-1.5">
                <span className="text-amber-400 font-serif">₹</span>
                <span>{futureValue.toLocaleString()}</span>
              </div>
              <p className="text-[10px] text-slate-400 mt-0.5">
                Estimated maturity payout at the end of {durationYears} years ({totalInstallments} installments of ₹{installmentAmount.toLocaleString()})
              </p>
            </div>

            {/* Split Breakdown */}
            <div className="grid grid-cols-3 gap-2 p-3 rounded-2xl bg-slate-950/80 border border-slate-800 text-center">
              <div>
                <span className="text-[9px] uppercase tracking-wider text-slate-400 block mb-0.5">Total Invested</span>
                <span className="text-xs sm:text-sm font-black text-white">₹{totalInvested.toLocaleString()}</span>
              </div>
              <div className="border-x border-slate-800">
                <span className="text-[9px] uppercase tracking-wider text-emerald-400 block mb-0.5">Wealth Gain</span>
                <span className="text-xs sm:text-sm font-black text-emerald-400">+₹{estimatedProfit.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-[9px] uppercase tracking-wider text-amber-300 block mb-0.5">Accumulated {metal.toUpperCase()}</span>
                <span className="text-xs sm:text-sm font-black text-amber-300">~{estimatedAccumulatedGrams} g</span>
              </div>
            </div>

            {/* Progress visual bar */}
            <div className="space-y-1">
              <div className="h-2.5 w-full bg-slate-800 rounded-full overflow-hidden flex">
                <div 
                  className="bg-slate-400 h-full transition-all duration-500"
                  style={{ width: `${Math.min(100, Math.round((totalInvested / futureValue) * 100))}%` }}
                  title="Invested Amount"
                />
                <div 
                  className="bg-gradient-to-r from-emerald-500 to-amber-400 h-full transition-all duration-500"
                  style={{ width: `${Math.max(0, 100 - Math.min(100, Math.round((totalInvested / futureValue) * 100)))}%` }}
                  title="Gains / Growth"
                />
              </div>
              <div className="flex justify-between text-[9px] text-slate-400">
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-slate-400 inline-block" />
                  <span>Invested: {Math.round((totalInvested / futureValue) * 100)}%</span>
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block" />
                  <span>Wealth Growth: {100 - Math.round((totalInvested / futureValue) * 100)}%</span>
                </span>
              </div>
            </div>

            {/* Action CTA */}
            {onStartSip && (
              <button
                type="button"
                onClick={handleApplySip}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs sm:text-sm shadow-xl shadow-amber-500/25 cursor-pointer active:scale-98 transition-all flex items-center justify-center gap-2"
              >
                <span>Start {metal.toUpperCase()} SIP with ₹{installmentAmount.toLocaleString()}/{frequency}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </>
      ) : (
        /* Target Goal Mode */
        <div className="p-5 rounded-3xl bg-slate-950/90 border border-slate-800 space-y-4">
          <div className="space-y-1.5">
            <label htmlFor={`${formId}-goal`} className="text-xs font-bold text-slate-200 block">
              What is your target wealth goal? (INR)
            </label>
            <div className="flex items-center gap-2 bg-slate-900 border border-slate-700 rounded-2xl px-3 py-2">
              <span className="text-amber-400 font-black text-base">₹</span>
              <input
                id={`${formId}-goal`}
                type="number"
                min={10000}
                step={5000}
                value={targetWealthGoal}
                onChange={(e) => setTargetWealthGoal(Math.max(5000, Number(e.target.value)))}
                className="w-full bg-transparent font-black text-lg text-white focus:outline-none font-mono"
              />
            </div>
            <div className="flex gap-1.5 overflow-x-auto no-scrollbar pt-1">
              {[50000, 100000, 250000, 500000, 1000000].map((g) => (
                <button
                  key={g}
                  type="button"
                  onClick={() => setTargetWealthGoal(g)}
                  className={`px-3 py-1 rounded-xl text-[10px] font-bold cursor-pointer ${
                    targetWealthGoal === g
                      ? 'bg-amber-500 text-slate-950 font-black'
                      : 'bg-slate-900 text-slate-300 border border-slate-800'
                  }`}
                >
                  ₹{g >= 100000 ? `${g / 100000} Lakh` : `${g / 1000}k`}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-300">Target Timeframe</label>
              <span className="text-xs font-black text-amber-300">{durationYears} Years</span>
            </div>
            <input
              type="range"
              min={1}
              max={15}
              step={1}
              value={durationYears}
              onChange={(e) => setDurationYears(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          {/* Goal Required SIP Result */}
          <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/40 text-center space-y-2">
            <span className="text-[10px] font-black uppercase text-amber-400 tracking-wider block">
              Required Monthly SIP
            </span>
            <div className="text-3xl font-black text-white">
              <span className="text-amber-400">₹</span>
              {requiredSipMonthly.toLocaleString()}
              <span className="text-xs text-slate-400 font-normal"> / month</span>
            </div>
            <p className="text-[11px] text-slate-300">
              Investing ₹{requiredSipMonthly.toLocaleString()}/mo for {durationYears} years @ {expectedAnnualReturn}% expected return will achieve your <strong>₹{targetWealthGoal.toLocaleString()}</strong> goal!
            </p>
          </div>

          {onStartSip && (
            <button
              type="button"
              onClick={() => {
                setInstallmentAmount(requiredSipMonthly);
                setFrequency('monthly');
                handleApplySip();
              }}
              className="w-full py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs sm:text-sm cursor-pointer shadow-lg shadow-amber-500/20"
            >
              Start This Target Goal SIP (₹{requiredSipMonthly.toLocaleString()}/mo)
            </button>
          )}
        </div>
      )}

      {/* SIP Educational / Benefits Callout */}
      <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800 text-[11px] text-slate-400 space-y-1.5">
        <div className="flex items-center gap-1.5 font-bold text-slate-200">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Why Rupee-Cost Averaging with Gold SIP?</span>
        </div>
        <p className="leading-relaxed">
          SIP automatically buys more grams when prices drop and fewer when prices rise, smoothing volatility. Stored 100% securely in insured BRINKS/SEBI-compliant vaults. Redeem into physical bullion or cash out directly to UPI anytime.
        </p>
      </div>
    </div>
  );

  if (isModal) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
        <div className="w-full max-w-lg bg-slate-900 border border-amber-500/40 rounded-3xl p-5 sm:p-6 shadow-2xl relative max-h-[92vh] overflow-y-auto">
          {content}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 rounded-3xl bg-slate-900/95 border border-slate-800/80 shadow-xl">
      {content}
    </div>
  );
};
