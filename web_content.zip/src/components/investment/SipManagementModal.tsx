import React, { useState } from 'react';
import { TrendingUp, Plus, Trash2, X, CheckCircle2, ShieldCheck, Calendar, Clock, Calculator } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { MetalType, SipFrequency } from '../../types';
import { UpiPaymentModal } from './UpiPaymentModal';
import { SipCalculator } from './SipCalculator';

interface SipManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SipManagementModal: React.FC<SipManagementModalProps> = ({ isOpen, onClose }) => {
  const { sipPlans, createSipPlan, toggleSipPlan, deleteSipPlan, currentUser, goldPricePerGram, silverPricePerGram } = useApp();

  const [metalType, setMetalType] = useState<MetalType>('gold');
  const [amountINR, setAmountINR] = useState<number>(500);
  const [frequency, setFrequency] = useState<SipFrequency>('weekly');
  const [message, setMessage] = useState<{ text: string; isError: boolean } | null>(null);
  const [isUpiModalOpen, setIsUpiModalOpen] = useState(false);
  const [isCalcOpen, setIsCalcOpen] = useState(false);

  if (!isOpen) return null;

  const currentPrice = metalType === 'gold' ? goldPricePerGram : silverPricePerGram;
  const estimatedGrams = Number((amountINR / currentPrice).toFixed(4));

  const userSips = sipPlans.filter(s => s.userId === currentUser?.id);

  const handleCreateSip = (e: React.FormEvent) => {
    e.preventDefault();
    if (amountINR < 50) {
      setMessage({ text: 'Minimum SIP installment amount is ₹50.', isError: true });
      return;
    }
    // Open UPI Payment verification modal first
    setIsUpiModalOpen(true);
  };

  const handlePaymentSuccess = (successMsg: string) => {
    const res = createSipPlan(metalType, amountINR, frequency);
    if (res.success) {
      setMessage({ text: `Payment Verified! ${res.message}`, isError: false });
      confetti({ particleCount: 70, spread: 80 });
      setTimeout(() => setMessage(null), 4000);
    } else {
      setMessage({ text: res.message, isError: true });
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
        <div className="w-full max-w-md bg-slate-900 border border-amber-500/40 rounded-3xl p-5 sm:p-6 shadow-2xl relative space-y-5 text-slate-100 max-h-[90vh] overflow-y-auto">
          
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
                <TrendingUp className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-black text-white">Gold & Silver SIP</h2>
                <p className="text-[10px] text-slate-400">Systematic Investment Plan — Automate your savings</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setIsCalcOpen(true)}
                className="px-2.5 py-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-bold flex items-center gap-1 hover:bg-amber-500/30 cursor-pointer"
                title="Calculate SIP returns"
              >
                <Calculator className="w-3.5 h-3.5" />
                <span className="hidden xs:inline">Calculate</span>
              </button>
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-xl bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {message && (
            <div className={`p-3 rounded-xl text-xs font-bold border flex items-center gap-2 ${
              message.isError 
                ? 'bg-rose-500/20 text-rose-300 border-rose-500/30' 
                : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
            }`}>
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{message.text}</span>
            </div>
          )}

          {/* Create SIP Form */}
          <form onSubmit={handleCreateSip} className="space-y-4 p-4 rounded-2xl bg-slate-950/80 border border-slate-800 text-xs">
            <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block">
              Set Up New SIP
            </span>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setMetalType('gold')}
                className={`py-2 rounded-xl font-bold flex items-center justify-center gap-1.5 cursor-pointer border ${
                  metalType === 'gold'
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                    : 'bg-slate-900 text-slate-400 border-slate-800'
                }`}
              >
                <span>🏆 Gold SIP</span>
              </button>
              <button
                type="button"
                onClick={() => setMetalType('silver')}
                className={`py-2 rounded-xl font-bold flex items-center justify-center gap-1.5 cursor-pointer border ${
                  metalType === 'silver'
                    ? 'bg-slate-200/20 text-slate-200 border-slate-400/50'
                    : 'bg-slate-900 text-slate-400 border-slate-800'
                }`}
              >
                <span>🥈 Silver SIP</span>
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] text-slate-400 mb-1">Frequency</label>
                <select
                  value={frequency}
                  onChange={(e) => setFrequency(e.target.value as SipFrequency)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="daily">Daily SIP</option>
                  <option value="weekly">Weekly SIP</option>
                  <option value="monthly">Monthly SIP</option>
                </select>
              </div>
              <div>
                <label className="block text-[10px] text-slate-400 mb-1">Installment (INR)</label>
                <input
                  type="number"
                  min={50}
                  value={amountINR}
                  onChange={(e) => setAmountINR(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 font-mono text-white focus:outline-none focus:border-amber-500"
                  required
                />
              </div>
            </div>

            {/* Quick Amounts */}
            <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-1">
              {[100, 500, 1000, 5000].map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => setAmountINR(amt)}
                  className={`px-3 py-1 rounded-lg text-[10px] font-black cursor-pointer ${
                    amountINR === amt ? 'bg-amber-500 text-slate-950' : 'bg-slate-900 text-slate-300 border border-slate-800'
                  }`}
                >
                  ₹{amt}
                </button>
              ))}
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black shadow-lg shadow-amber-500/20 cursor-pointer transition-all flex items-center justify-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Start {metalType.toUpperCase()} SIP (₹{amountINR}/{frequency}) & Pay UPI</span>
            </button>
          </form>

          {/* Active SIP List */}
          <div className="space-y-3">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
              My Active SIP Plans ({userSips.length})
            </span>

            <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
              {userSips.length === 0 ? (
                <div className="p-4 rounded-2xl bg-slate-950/40 border border-slate-800 text-center text-xs text-slate-500">
                  No active SIP plans. Start your first automated SIP above!
                </div>
              ) : (
                userSips.map((sip) => (
                  <div
                    key={sip.id}
                    className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-base">
                          {sip.metalType === 'gold' ? '🏆' : '🥈'}
                        </span>
                        <div>
                          <div className="font-black text-white capitalize">
                            {sip.frequency} {sip.metalType} SIP — ₹{sip.amountINR}
                          </div>
                          <span className="text-[10px] text-slate-400">
                            {sip.installmentsCompleted} installments • {sip.accumulatedGrams}g accumulated
                          </span>
                        </div>
                      </div>

                      <span className={`px-2 py-0.5 rounded-md text-[9px] font-black uppercase ${
                        sip.status === 'active'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      }`}>
                        {sip.status}
                      </span>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-[10px] text-slate-400">
                      <span>Total Invested: <strong className="text-white">₹{sip.totalInvestedINR}</strong></span>
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => toggleSipPlan(sip.id)}
                          className="px-2.5 py-1 rounded-lg font-bold bg-slate-900 text-slate-300 border border-slate-800 cursor-pointer hover:text-white"
                        >
                          {sip.status === 'active' ? 'Pause' : 'Resume'}
                        </button>
                        <button
                          type="button"
                          onClick={() => deleteSipPlan(sip.id)}
                          className="p-1.5 rounded-lg bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>
      </div>

      {/* UPI Payment Modal for SIP Installment */}
      <UpiPaymentModal
        isOpen={isUpiModalOpen}
        onClose={() => setIsUpiModalOpen(false)}
        metalType={metalType}
        amountINR={amountINR}
        netPayableINR={amountINR}
        estimatedGrams={estimatedGrams}
        onSuccess={handlePaymentSuccess}
      />

      {/* SIP Calculator Modal */}
      {isCalcOpen && (
        <SipCalculator
          isModal={true}
          onClose={() => setIsCalcOpen(false)}
          onStartSip={(metal, amt, freq) => {
            setMetalType(metal);
            setAmountINR(amt);
            setFrequency(freq);
            setIsCalcOpen(false);
          }}
        />
      )}
    </>
  );
};

