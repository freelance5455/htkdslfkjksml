import React, { useState } from 'react';
import { ShieldCheck, User, Calendar, CreditCard, CheckCircle2, X, AlertCircle, Phone } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';

interface KycVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const KycVerificationModal: React.FC<KycVerificationModalProps> = ({ isOpen, onClose }) => {
  const { currentUser, kycRecords, submitKyc } = useApp();

  const userKyc = kycRecords.find(r => r.userId === currentUser?.id);

  const [fullName, setFullName] = useState(currentUser?.name || '');
  const [dob, setDob] = useState('2001-05-14');
  const [aadhaar, setAadhaar] = useState('');
  const [mobileNumber, setMobileNumber] = useState(userKyc?.mobileNumber || currentUser?.phone || '');
  const [bankDetails, setBankDetails] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const cleanAadhaar = aadhaar.replace(/\D/g, '');
    const cleanMobile = mobileNumber.replace(/\D/g, '');

    if (!fullName.trim() || !cleanAadhaar || !cleanMobile || !bankDetails.trim()) {
      setErrorMsg('Please fill in all required identity verification fields (সবগুলো তথ্য পূরণ করুন)।');
      return;
    }

    if (cleanAadhaar.length !== 12) {
      setErrorMsg('Aadhaar number must be exactly 12 digits (১২ সংখ্যার আধার নম্বর দিন)।');
      return;
    }

    if (cleanMobile.length !== 10) {
      setErrorMsg('Mobile number must be exactly 10 digits (১০ সংখ্যার সঠিক মোবাইল নম্বর দিন)।');
      return;
    }

    const res = submitKyc(fullName, dob, cleanAadhaar, bankDetails, cleanMobile);
    if (res.success) {
      setSuccessMsg(res.message);
      confetti({ particleCount: 60, spread: 70 });
      setTimeout(() => {
        onClose();
      }, 2000);
    } else {
      setErrorMsg(res.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-slate-900 border border-indigo-500/30 rounded-3xl p-5 sm:p-6 shadow-2xl relative space-y-4 text-white max-h-[90vh] overflow-y-auto">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white bg-slate-800/80 cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center">
            <ShieldCheck className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h2 className="text-base font-black tracking-tight">Aadhaar Card KYC & Mobile Verification</h2>
            <p className="text-xs text-slate-400">
              Mandatory for 24K Gold Investment & Secure Payouts
            </p>
          </div>
        </div>

        {/* Bengali Info Banner */}
        <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs">
          <span className="font-bold block">🇮🇳 গোল্ড কেনার জন্য আধার KYC ও মোবাইল নম্বর বাধ্যতামূলক</span>
          <span className="text-[11px] text-slate-300 block mt-0.5">
            ১২ সংখ্যার আধার কার্ড এবং সক্রিয় ১০ সংখ্যার মোবাইল নম্বর দিয়ে ভেরিফিকেশন সম্পূর্ণ করুন।
          </span>
        </div>

        {userKyc?.status === 'verified' && (
          <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 space-y-1.5">
            <div className="flex items-center justify-between font-bold text-xs">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>KYC & Mobile Verified (ভেরিফাইড)</span>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase bg-emerald-500/20 text-emerald-300">
                ACTIVE
              </span>
            </div>
            <div className="text-[11px] text-slate-300 space-y-0.5 pt-1 border-t border-emerald-500/20">
              <p>Verified Name: <strong className="text-white">{userKyc.fullName}</strong></p>
              <p>Aadhaar Masked: <strong className="font-mono text-white">{userKyc.aadhaarMasked}</strong></p>
              <p>Mobile: <strong className="font-mono text-white">+91 {userKyc.mobileNumber || currentUser?.phone || '9635776190'}</strong></p>
            </div>
          </div>
        )}

        {errorMsg && (
          <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-semibold">
            {errorMsg}
          </div>
        )}

        {successMsg && (
          <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
            {successMsg}
          </div>
        )}

        {userKyc?.status !== 'verified' && (
          <form onSubmit={handleSubmit} className="space-y-3 text-xs">
            <div>
              <label className="block font-bold text-slate-300 mb-1">Full Legal Name (ID অনুযায়ী সম্পূর্ণ নাম)</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Subhodip Garai"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-300 mb-1">Mobile Number (১০ ডিজিটের মোবাইল নম্বর)</label>
              <div className="relative">
                <span className="absolute left-3.5 top-3 text-xs text-slate-400 font-mono">+91</span>
                <input
                  type="tel"
                  required
                  maxLength={10}
                  value={mobileNumber}
                  onChange={(e) => setMobileNumber(e.target.value)}
                  placeholder="9635776190"
                  className="w-full pl-12 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-indigo-500 font-mono tracking-widest"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-300 mb-1">Aadhaar Number (১২ ডিজিট আধার নম্বর)</label>
              <div className="relative">
                <CreditCard className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  required
                  maxLength={12}
                  value={aadhaar}
                  onChange={(e) => setAadhaar(e.target.value)}
                  placeholder="2450 8942 1209"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-indigo-500 font-mono tracking-widest"
                />
              </div>
              <span className="text-[10px] text-slate-500 mt-0.5 block">
                🔒 Your Aadhaar is securely encrypted and masked. We only store verification status.
              </span>
            </div>

            <div>
              <label className="block font-bold text-slate-300 mb-1">Date of Birth</label>
              <div className="relative">
                <Calendar className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="date"
                  required
                  value={dob}
                  onChange={(e) => setDob(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-indigo-500 font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-300 mb-1">Bank Account or UPI Details for Payout</label>
              <input
                type="text"
                required
                value={bankDetails}
                onChange={(e) => setBankDetails(e.target.value)}
                placeholder="HDFC Bank A/C 1234567890 / mobile@upi"
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-indigo-500 font-mono"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-95 text-white font-black text-xs shadow-lg shadow-indigo-600/30 cursor-pointer transition-all mt-2"
            >
              Verify Aadhaar & Save Mobile Instantly
            </button>
          </form>
        )}

      </div>
    </div>
  );
};
