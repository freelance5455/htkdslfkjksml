import React, { useState } from 'react';
import { Bell, Plus, Trash2, X, ShieldAlert, CheckCircle2, TrendingUp, TrendingDown } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { MetalType } from '../../types';

interface PriceAlertsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PriceAlertsModal: React.FC<PriceAlertsModalProps> = ({ isOpen, onClose }) => {
  const { 
    priceAlerts, 
    addPriceAlert, 
    deletePriceAlert, 
    togglePriceAlert, 
    goldPricePerGram, 
    silverPricePerGram,
    currentUser 
  } = useApp();

  const [metalType, setMetalType] = useState<MetalType>('gold');
  const [targetPrice, setTargetPrice] = useState<string>(String(Math.round(goldPricePerGram * 1.02)));
  const [condition, setCondition] = useState<'above' | 'below'>('above');
  const [message, setMessage] = useState<{ text: string; isError: boolean } | null>(null);

  if (!isOpen) return null;

  const currentMetalPrice = metalType === 'gold' ? goldPricePerGram : silverPricePerGram;

  const handleCreateAlert = (e: React.FormEvent) => {
    e.preventDefault();
    const priceNum = parseFloat(targetPrice);
    if (isNaN(priceNum) || priceNum <= 0) {
      setMessage({ text: 'Please enter a valid target price threshold.', isError: true });
      return;
    }

    const res = addPriceAlert(metalType, priceNum, condition);
    if (res.success) {
      setMessage({ text: res.message, isError: false });
      setTimeout(() => {
        setMessage(null);
      }, 3000);
    } else {
      setMessage({ text: res.message, isError: true });
    }
  };

  const userAlerts = priceAlerts.filter(a => a.userId === currentUser?.id);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md p-6 rounded-3xl bg-slate-900 border border-amber-500/30 shadow-2xl space-y-5 text-slate-100 relative">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <Bell className="w-5 h-5 animate-bounce" />
            </div>
            <div>
              <h2 className="text-base font-black text-white">Custom Price Alerts</h2>
              <p className="text-[10px] text-slate-400">Get notified instantly when Gold or Silver hits your target</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {message && (
          <div className={`p-3 rounded-xl text-xs font-bold border flex items-center gap-2 ${
            message.isError 
              ? 'bg-rose-500/20 text-rose-300 border-rose-500/30' 
              : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
          }`}>
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{message.text}</span>
          </div>
        )}

        {/* Create Alert Form */}
        <form onSubmit={handleCreateAlert} className="space-y-4 p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
          <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block">
            Create New Alert
          </span>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => {
                setMetalType('gold');
                setTargetPrice(String(Math.round(goldPricePerGram * 1.02)));
              }}
              className={`py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer border ${
                metalType === 'gold'
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                  : 'bg-slate-900 text-slate-400 border-slate-800'
              }`}
            >
              <span>🏆 Gold (₹{goldPricePerGram}/g)</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setMetalType('silver');
                setTargetPrice(String(Math.round(silverPricePerGram * 1.05)));
              }}
              className={`py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer border ${
                metalType === 'silver'
                  ? 'bg-slate-200/20 text-slate-200 border-slate-400/50'
                  : 'bg-slate-900 text-slate-400 border-slate-800'
              }`}
            >
              <span>🥈 Silver (₹{silverPricePerGram}/g)</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">Trigger Condition</label>
              <select
                value={condition}
                onChange={(e) => setCondition(e.target.value as 'above' | 'below')}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:border-amber-500"
              >
                <option value="above">Rises Above (≥)</option>
                <option value="below">Drops Below (≤)</option>
              </select>
            </div>
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">Target Price (₹/g)</label>
              <input
                type="number"
                step="0.1"
                value={targetPrice}
                onChange={(e) => setTargetPrice(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-white focus:outline-none focus:border-amber-500"
                placeholder="Enter price"
                required
              />
            </div>
          </div>

          <div className="flex items-center gap-1.5 pt-1">
            <span className="text-[10px] text-slate-400">Quick presets:</span>
            <button
              type="button"
              onClick={() => setTargetPrice(String(Math.round(currentMetalPrice * 1.02)))}
              className="px-2 py-0.5 rounded bg-slate-900 text-[10px] text-amber-400 border border-slate-800 hover:bg-slate-800 cursor-pointer"
            >
              +2%
            </button>
            <button
              type="button"
              onClick={() => setTargetPrice(String(Math.round(currentMetalPrice * 1.05)))}
              className="px-2 py-0.5 rounded bg-slate-900 text-[10px] text-amber-400 border border-slate-800 hover:bg-slate-800 cursor-pointer"
            >
              +5%
            </button>
            <button
              type="button"
              onClick={() => setTargetPrice(String(Math.round(currentMetalPrice * 0.98)))}
              className="px-2 py-0.5 rounded bg-slate-900 text-[10px] text-amber-400 border border-slate-800 hover:bg-slate-800 cursor-pointer"
            >
              -2%
            </button>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/20 cursor-pointer transition-all flex items-center justify-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Set Price Alert</span>
          </button>
        </form>

        {/* Existing Alerts List */}
        <div className="space-y-3">
          <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
            Active Price Alerts ({userAlerts.length})
          </span>

          <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
            {userAlerts.length === 0 ? (
              <div className="p-4 rounded-2xl bg-slate-950/40 border border-slate-800 text-center text-xs text-slate-500">
                No active price alerts set. Create one above!
              </div>
            ) : (
              userAlerts.map((alert) => (
                <div
                  key={alert.id}
                  className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-base">
                      {alert.metalType === 'gold' ? '🏆' : '🥈'}
                    </span>
                    <div>
                      <div className="font-bold text-white">
                        {alert.metalType.toUpperCase()} {alert.condition === 'above' ? '≥' : '≤'} ₹{alert.targetPrice}
                      </div>
                      <span className="text-[10px] text-slate-400">
                        {alert.isActive ? '🟢 Monitoring active' : '⚪ Paused'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => togglePriceAlert(alert.id)}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-bold cursor-pointer ${
                        alert.isActive
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : 'bg-slate-800 text-slate-400 border border-slate-700'
                      }`}
                    >
                      {alert.isActive ? 'Active' : 'Off'}
                    </button>
                    <button
                      type="button"
                      onClick={() => deletePriceAlert(alert.id)}
                      className="p-1.5 rounded-lg bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>
    </div>
  );
};
