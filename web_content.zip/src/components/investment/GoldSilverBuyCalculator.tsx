import React, { useState, useEffect } from 'react';
import { 
  Coins, 
  TrendingUp, 
  ShieldCheck, 
  ArrowRight, 
  Check, 
  X, 
  AlertCircle, 
  CheckCircle2, 
  Calculator, 
  Lock, 
  Sparkles,
  Info,
  Building2,
  FileText
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { MetalType } from '../../types';

interface GoldSilverBuyCalculatorProps {
  onOpenOrderModal: (metal: MetalType, mode: 'buy' | 'sell') => void;
  onOpenKyc: () => void;
}

export const GoldSilverBuyCalculator: React.FC<GoldSilverBuyCalculatorProps> = ({ 
  onOpenOrderModal,
  onOpenKyc
}) => {
  const { 
    currentUser, 
    goldPricePerGram, 
    silverPricePerGram, 
    buyMetal, 
    advancedKyc,
    metalProviderConfig
  } = useApp();

  const [metal, setMetal] = useState<MetalType>('gold');
  const [inputMode, setInputMode] = useState<'amount' | 'grams'>('amount');
  const [amountInput, setAmountInput] = useState<string>('1000');
  const [gramsInput, setGramsInput] = useState<string>('0.1365');
  const [livePrices, setLivePrices] = useState({
    gold: goldPricePerGram || 7325.80,
    silver: silverPricePerGram || 89.75,
    goldChange: 1.65,
    silverChange: 2.18,
    lastSync: 'Live MCX'
  });

  const [showConfirmation, setShowConfirmation] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState<string | null>(null);
  const [orderError, setOrderError] = useState<string | null>(null);

  // Fetch legitimate live prices from backend API
  useEffect(() => {
    const fetchLive = async () => {
      try {
        const res = await fetch('/api/metal/prices');
        const json = await res.json();
        if (json.success && json.data) {
          setLivePrices({
            gold: json.data.gold.pricePerGram,
            silver: json.data.silver.pricePerGram,
            goldChange: json.data.gold.change24h || 1.65,
            silverChange: json.data.silver.change24h || 2.18,
            lastSync: new Date(json.data.gold.lastUpdated).toLocaleTimeString()
          });
        }
      } catch {}
    };
    fetchLive();
    const interval = setInterval(fetchLive, 30000);
    return () => clearInterval(interval);
  }, []);

  const activeRate = metal === 'gold' ? livePrices.gold : livePrices.silver;
  const minAmount = metal === 'gold' ? 300 : 200;

  // Handle amount change -> recalculate grams
  const handleAmountChange = (val: string) => {
    setAmountInput(val);
    const num = parseFloat(val);
    if (!isNaN(num) && num > 0) {
      setGramsInput((num / activeRate).toFixed(4));
    } else {
      setGramsInput('0.0000');
    }
  };

  // Handle grams change -> recalculate amount
  const handleGramsChange = (val: string) => {
    setGramsInput(val);
    const num = parseFloat(val);
    if (!isNaN(num) && num > 0) {
      setAmountInput(Math.round(num * activeRate).toString());
    } else {
      setAmountInput('0');
    }
  };

  // Switch metal
  const handleSwitchMetal = (m: MetalType) => {
    setMetal(m);
    const rate = m === 'gold' ? livePrices.gold : livePrices.silver;
    const num = parseFloat(amountInput) || (m === 'gold' ? 1000 : 500);
    setAmountInput(num.toString());
    setGramsInput((num / rate).toFixed(4));
  };

  const parsedAmount = parseFloat(amountInput) || 0;
  const parsedGrams = parseFloat(gramsInput) || 0;
  const gstAmount = Number((parsedAmount * 0.03).toFixed(2));
  const bullionValue = Number((parsedAmount - gstAmount).toFixed(2));

  const handleProceedToConfirmation = () => {
    setOrderError(null);
    if (parsedAmount < minAmount) {
      setOrderError(`Minimum purchase amount for ${metal === 'gold' ? 'Gold' : 'Silver'} is ₹${minAmount}.`);
      return;
    }
    setShowConfirmation(true);
  };

  const handleExecuteOrder = () => {
    setOrderError(null);
    const res = buyMetal(metal, parsedAmount);
    if (res.success) {
      confetti({ particleCount: 50, spread: 60 });
      setOrderSuccess(`Order confirmed! ${parsedGrams}g of 24K ${metal.toUpperCase()} credited to your insured BRINKS vault.`);
      setTimeout(() => {
        setShowConfirmation(false);
        setOrderSuccess(null);
      }, 2000);
    } else {
      setOrderError(res.message);
    }
  };

  return (
    <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-amber-500/40 shadow-2xl shadow-amber-950/20 space-y-5 relative overflow-hidden">
      {/* Glow */}
      <div className="absolute top-0 right-0 w-44 h-44 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-2 relative z-10">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Calculator className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-black text-white">
              Instant Bullion Purchase Calculator & Order Engine
            </h3>
            <p className="text-[11px] text-slate-400">
              Live National Spot Rate • 100% Physical Insured Vault Storage
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-slate-950 border border-slate-800">
          <button
            onClick={() => handleSwitchMetal('gold')}
            className={`px-3 py-1 rounded-xl font-black text-xs transition-all cursor-pointer ${
              metal === 'gold'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            🏆 24K Gold
          </button>
          <button
            onClick={() => handleSwitchMetal('silver')}
            className={`px-3 py-1 rounded-xl font-black text-xs transition-all cursor-pointer ${
              metal === 'silver'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            🥈 999 Silver
          </button>
        </div>
      </div>

      {/* Live Market Price Banner */}
      <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between flex-wrap gap-3 relative z-10 text-xs">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
          <span className="text-slate-300">
            Current {metal === 'gold' ? 'Digital Gold (24K 99.9%)' : 'Digital Silver (99.9%)'} Rate:
          </span>
          <span className="font-mono font-black text-white text-sm">
            ₹{activeRate.toFixed(2)}/g
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
            +{metal === 'gold' ? livePrices.goldChange : livePrices.silverChange}% Today
          </span>
          <span className="text-[10px] text-slate-500 font-mono">Sync: {livePrices.lastSync}</span>
        </div>
      </div>

      {/* Interactive Calculator Inputs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 relative z-10 text-xs">
        {/* Amount in INR */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-[11px] font-bold text-slate-300">Investment Amount (INR)</label>
            <span className="text-[10px] text-amber-400 font-bold font-mono">Min ₹{minAmount}</span>
          </div>
          <div className="relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm">₹</span>
            <input
              type="number"
              value={amountInput}
              onChange={(e) => handleAmountChange(e.target.value)}
              min={minAmount}
              step={100}
              className="w-full pl-8 pr-4 py-2.5 rounded-xl bg-slate-900 border border-slate-750 text-white font-mono font-black text-base focus:outline-none focus:border-amber-500"
            />
          </div>
          <div className="flex items-center gap-1.5 pt-1 flex-wrap">
            {[minAmount, 1000, 2000, 5000].map((preset) => (
              <button
                key={preset}
                onClick={() => handleAmountChange(preset.toString())}
                className="px-2 py-0.5 rounded-lg bg-slate-850 hover:bg-slate-800 text-[10px] text-slate-300 font-mono transition-colors"
              >
                +₹{preset}
              </button>
            ))}
          </div>
        </div>

        {/* Accumulated Grams */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-[11px] font-bold text-slate-300">Accumulated Weight</label>
            <span className="text-[10px] text-slate-400">Purity: 99.9% Hallmark</span>
          </div>
          <div className="relative">
            <input
              type="number"
              value={gramsInput}
              onChange={(e) => handleGramsChange(e.target.value)}
              step={0.0001}
              className="w-full pl-4 pr-12 py-2.5 rounded-xl bg-slate-900 border border-slate-750 text-white font-mono font-black text-base focus:outline-none focus:border-amber-500"
            />
            <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-xs">grams</span>
          </div>
          <p className="text-[10px] text-slate-400 pt-1 leading-snug">
            Calculated at real-time spot price with zero storage fees.
          </p>
        </div>
      </div>

      {orderError && (
        <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{orderError}</span>
        </div>
      )}

      {/* Buttons: Buy and Sell Options */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 relative z-10">
        <button
          onClick={handleProceedToConfirmation}
          className="py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs sm:text-sm shadow-lg shadow-amber-500/20 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
        >
          <span>Buy {metal === 'gold' ? 'Digital Gold' : 'Digital Silver'} (₹{parsedAmount.toLocaleString()})</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        <button
          onClick={() => onOpenOrderModal(metal, 'sell')}
          className="py-3 rounded-2xl bg-slate-800 hover:bg-slate-750 text-amber-300 border border-amber-500/30 font-bold text-xs sm:text-sm active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
        >
          <span>Sell / Instant Liquidation to UPI</span>
        </button>
      </div>

      {/* Transparent Fees, Taxes & Risk Disclosures */}
      <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-850 text-[11px] text-slate-400 space-y-1 relative z-10">
        <div className="flex items-center gap-2 font-bold text-slate-300">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Transparent Fees & Terms (RBI & MCA Compliant):</span>
        </div>
        <p>
          • <strong>GST:</strong> Standard 3.0% Government Mandated Goods & Services Tax applied.
        </p>
        <p>
          • <strong>Vault Storage & Insurance:</strong> ₹0 (Free 100% insured BRINKS physical vaulted storage).
        </p>
        <p>
          • <strong>Market Risk:</strong> Precious metals prices fluctuate with international spot markets. Digital gold can be sold back anytime or redeemed for 24K physical coins.
        </p>
      </div>

      {/* Order Confirmation Modal Screen */}
      {showConfirmation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="max-w-md w-full bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-amber-500/50 rounded-3xl p-5 sm:p-6 space-y-4">
            
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Coins className="w-5 h-5 text-amber-400" />
                <h3 className="font-black text-white text-base">Order Confirmation & Invoice</h3>
              </div>
              <button 
                onClick={() => setShowConfirmation(false)}
                className="p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2.5 text-xs">
              <div className="flex justify-between text-slate-400">
                <span>Commodity:</span>
                <span className="font-black text-white">24K 99.9% Pure {metal.toUpperCase()}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Live Spot Rate:</span>
                <span className="font-mono text-slate-200">₹{activeRate.toFixed(2)}/g</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Allocated Weight:</span>
                <span className="font-mono font-black text-amber-400 text-sm">{parsedGrams} grams</span>
              </div>
              <div className="flex justify-between text-slate-400 pt-2 border-t border-slate-850">
                <span>Bullion Base Value:</span>
                <span className="font-mono text-slate-300">₹{bullionValue.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Mandatory GST (3.0%):</span>
                <span className="font-mono text-slate-300">₹{gstAmount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Insured Vault & Brinks Fee:</span>
                <span className="font-mono text-emerald-400 font-bold">₹0.00 (Free)</span>
              </div>
              <div className="flex justify-between text-white font-bold text-sm pt-2 border-t border-slate-800">
                <span>Total Net Payable:</span>
                <span className="font-mono font-black text-amber-300">₹{parsedAmount.toLocaleString()}</span>
              </div>
            </div>

            {orderSuccess ? (
              <div className="p-3 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                <span>{orderSuccess}</span>
              </div>
            ) : (
              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowConfirmation(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold hover:bg-slate-750 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleExecuteOrder}
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 text-slate-950 font-black shadow-lg shadow-amber-500/20 active:scale-95 transition-all"
                >
                  Confirm & Buy Now
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
