import React, { useRef, useState } from 'react';
import { Check, Download, RotateCcw, Save, Upload, Wifi, WifiOff } from 'lucide-react';
import { formatSimClock } from '../data/kennelConstants';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { GameState } from '../types/kennel';
import { PWAInstallButton } from './PWAInstallButton';

interface SaveViewProps {
  state: GameState;
  onManualSave: () => void;
  onImportState: (parsed: GameState) => void;
  onResetKennel: () => void;
}

export const SaveView: React.FC<SaveViewProps> = ({
  state,
  onManualSave,
  onImportState,
  onResetKennel,
}) => {
  const isOnline = useOnlineStatus();
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);

  const handleExport = () => {
    setErrorMessage(null);
    const payload = JSON.stringify(state, null, 2);
    const blob = new Blob([payload], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `dingo-ledger-day${state.dayCount}-${formatSimClock(state.simClockSec).replace(/:/g, '-')}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setStatusMessage('Save file exported to your device.');
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setErrorMessage(null);
    setStatusMessage(null);
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as GameState;
      if (!parsed || !Array.isArray(parsed.dogs) || typeof parsed.simClockSec !== 'number' || !parsed.bowls) {
        setErrorMessage('This file does not appear to be a valid Dingo Ledger save.');
        return;
      }
      onImportState(parsed);
      setStatusMessage(`Loaded kennel save (${parsed.dogs.length} dogs, Day ${parsed.dayCount ?? 1}).`);
    } catch {
      setErrorMessage('Could not read the selected JSON save file.');
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <div className="max-w-3xl space-y-6">
      <section className="pb-4 border-b border-[#DFDBD0]">
        <h1 className="font-display text-2xl sm:text-3xl font-semibold text-[#1C1B18]">
          Offline Save &amp; Export
        </h1>
        <p className="mt-1 text-sm text-[#5C584F]">
          Dingo Ledger runs completely locally on your device. Progress auto-saves to browser storage and can be exported as a portable JSON ledger anytime.
        </p>
      </section>

      {statusMessage && (
        <div className="rounded-xl bg-[#1F4E3D]/10 border border-[#1F4E3D]/25 px-4 py-3 text-sm text-[#1F4E3D] flex items-center gap-2">
          <Check className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{statusMessage}</span>
        </div>
      )}

      {errorMessage && (
        <div className="rounded-xl bg-[#991B1B]/10 border border-[#991B1B]/25 px-4 py-3 text-sm text-[#991B1B]">
          {errorMessage}
        </div>
      )}

      {/* Save & Export Actions */}
      <section className="rounded-2xl bg-white border border-[#DFDBD0] p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#5C584F] font-mono-tabular">
          <span>Active Dogs: {state.dogs.length}</span>
          <span>Day {state.dayCount} · {formatSimClock(state.simClockSec)}</span>
          <span>Last Saved: {new Date(state.lastSavedAtMs).toLocaleTimeString()}</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <button
            type="button"
            onClick={() => {
              onManualSave();
              setStatusMessage('Saved current kennel state locally.');
            }}
            className="inline-flex items-center justify-center gap-2 min-h-[48px] px-4 py-2.5 text-sm font-semibold rounded-xl bg-[#1F4E3D] text-white hover:bg-[#173B2E] transition-colors cursor-pointer"
          >
            <Save className="w-4 h-4" aria-hidden="true" />
            <span>Save Locally</span>
          </button>

          <button
            type="button"
            onClick={handleExport}
            className="inline-flex items-center justify-center gap-2 min-h-[48px] px-4 py-2.5 text-sm font-semibold rounded-xl border border-[#D8D3C6] bg-[#F7F5F0] text-[#1C1B18] hover:bg-[#EFECE4] transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" aria-hidden="true" />
            <span>Export Save (.json)</span>
          </button>

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center justify-center gap-2 min-h-[48px] px-4 py-2.5 text-sm font-semibold rounded-xl border border-[#D8D3C6] bg-[#F7F5F0] text-[#1C1B18] hover:bg-[#EFECE4] transition-colors cursor-pointer"
          >
            <Upload className="w-4 h-4" aria-hidden="true" />
            <span>Import Save (.json)</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="application/json,.json"
            onChange={handleFileChange}
            className="hidden"
          />
        </div>
      </section>

      {/* Mobile Standalone / Offline Status */}
      <section className="rounded-2xl bg-white border border-[#DFDBD0] p-5 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            {isOnline ? (
              <Wifi className="w-4 h-4 text-[#1F4E3D]" aria-hidden="true" />
            ) : (
              <WifiOff className="w-4 h-4 text-[#9A5B13]" aria-hidden="true" />
            )}
            <span className="text-sm font-semibold text-[#1C1B18]">
              {isOnline ? 'Online · Assets cached for offline play' : 'Offline Mode · Running standalone locally'}
            </span>
          </div>
          <PWAInstallButton />
        </div>
        <p className="text-xs text-[#5C584F]">
          On mobile, install Dingo Ledger to your home screen to launch full-screen without an internet connection.
        </p>
      </section>

      {/* Reset Kennel */}
      <section className="rounded-2xl bg-white border border-[#DFDBD0] p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-[#1C1B18]">Start Fresh Kennel</h2>
            <p className="text-xs text-[#5C584F] mt-0.5">
              Clears current dogs, genetics, and logs back to a new Day 1 starter kennel.
            </p>
          </div>
          {!confirmReset ? (
            <button
              type="button"
              onClick={() => setConfirmReset(true)}
              className="inline-flex items-center justify-center gap-2 min-h-[44px] px-4 py-2 text-xs font-semibold rounded-xl border border-[#D8D3C6] text-[#991B1B] hover:bg-[#991B1B]/5 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" aria-hidden="true" />
              <span>Reset Kennel</span>
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  onResetKennel();
                  setConfirmReset(false);
                  setStatusMessage('Kennel reset to Day 1.');
                }}
                className="min-h-[44px] px-4 py-2 text-xs font-semibold rounded-xl bg-[#991B1B] text-white hover:bg-[#7F1D1D] cursor-pointer"
              >
                Confirm Reset
              </button>
              <button
                type="button"
                onClick={() => setConfirmReset(false)}
                className="min-h-[44px] px-3 py-2 text-xs font-medium rounded-xl border border-[#D8D3C6] text-[#1C1B18] hover:bg-[#EFECE4] cursor-pointer"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};
