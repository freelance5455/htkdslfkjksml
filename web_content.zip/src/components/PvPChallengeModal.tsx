import React, { useState } from 'react';
import { Territory, CivilizationId } from '../types/kingdom';
import { useKingdom } from '../context/KingdomContext';
import { CIVILIZATIONS, PVP_PRESET_MESSAGES, PVP_PREPARATION_OPTIONS } from '../game/gameConfig';
import { Swords, Clock, Coins, MessageSquare, ShieldAlert, X, Crown, MapPin } from 'lucide-react';

interface PvPChallengeModalProps {
  target: Territory;
  onClose: () => void;
  onSuccess?: () => void;
}

export const PvPChallengeModal: React.FC<PvPChallengeModalProps> = ({ target, onClose, onSuccess }) => {
  const { kingdom, sendPvPChallenge, playSound } = useKingdom();

  const [selectedHours, setSelectedHours] = useState<number>(24);
  const [goldStake, setGoldStake] = useState<number>(250);
  const [selectedMessage, setSelectedMessage] = useState<string>(PVP_PRESET_MESSAGES[0]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!kingdom) return null;

  const targetCiv = target.ownerCivilization
    ? CIVILIZATIONS[target.ownerCivilization as CivilizationId]
    : null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      const result = await sendPvPChallenge({
        defenderId: target.ownerUserId || target.id,
        defenderKingdomName: target.name,
        defenderCastleName: target.castleName || 'Fortaleza Real',
        defenderCivilization: (target.ownerCivilization as CivilizationId) || 'castellanos',
        defenderGlory: target.gloryReward || 100,
        preparationHours: selectedHours,
        goldStake,
        message: selectedMessage,
        distance: target.distance || 20,
      });

      if (!result.success) {
        setError(result.error || 'Error al enviar el desafío');
      } else {
        playSound('horn');
        if (onSuccess) onSuccess();
        onClose();
      }
    } catch (err: any) {
      setError(err?.message || 'Error inesperado al registrar el desafío');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-stone-900 border border-amber-900/60 rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl flex flex-col text-stone-200">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-800 flex items-center justify-between sticky top-0 bg-stone-900/95 backdrop-blur z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-950/80 border border-red-700/60 flex items-center justify-center text-red-400">
              <Swords className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-amber-200 flex items-center gap-2">
                Desafío Diplomático Feudal
                <span className="text-[10px] bg-red-900/80 text-red-300 px-2 py-0.5 rounded-full border border-red-700 font-mono">
                  Punto 38 PvP
                </span>
              </h2>
              <p className="text-xs text-stone-400">Pactar contienda oficial a través del Parlamento</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-stone-800 rounded-lg text-stone-400 hover:text-stone-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-5">
          {/* Target Castle Card */}
          <div className="bg-stone-950 border border-stone-800 rounded-xl p-4 relative overflow-hidden">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <Crown className="w-4 h-4 text-amber-400" />
                  <span className="text-base font-bold text-stone-100">{target.name}</span>
                  <span className="text-xs text-amber-500 font-mono">({targetCiv?.name || 'Reino Rival'})</span>
                </div>
                <div className="text-xs text-stone-400 mt-1 flex items-center gap-3">
                  <span>Castillo: <strong className="text-stone-300">{target.castleName || 'Torreón'}</strong></span>
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-stone-500" />
                    {target.distance || 25} leguas (~{Math.round((target.distance || 25) / 10)}h)
                  </span>
                </div>
              </div>
              <span className="px-2.5 py-1 bg-amber-950/80 border border-amber-700/60 text-amber-300 text-xs font-semibold rounded-lg">
                👑 Jugador Real
              </span>
            </div>

            {/* General Intelligence */}
            <div className="mt-3 pt-3 border-t border-stone-900 grid grid-cols-2 gap-2 text-xs">
              <div className="bg-stone-900/70 p-2 rounded-lg border border-stone-800/80">
                <span className="text-stone-500 block text-[11px]">Población aproximada</span>
                <span className="font-semibold text-stone-200">~{target.population || 250} habitantes</span>
              </div>
              <div className="bg-stone-900/70 p-2 rounded-lg border border-stone-800/80">
                <span className="text-stone-500 block text-[11px]">Guarnición estimada</span>
                <span className="font-semibold text-stone-300 italic">Desconocida (espionaje)</span>
              </div>
            </div>
          </div>

          {/* Law Feudal Note */}
          <div className="bg-stone-950/60 border border-amber-950 rounded-xl p-3.5 flex gap-3 text-xs text-amber-300/90 leading-relaxed">
            <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
            <p>
              <strong>Artículo 38 de la Ley Feudal:</strong> No existen ataques sorpresa entre reinos soberanos.
              El rival recibirá este desafío en su Parlamento y podrá negociar, aceptar o rechazar.
              El plazo acordado permitirá alistar tropas, forjar armas y preparar la formación táctica.
            </p>
          </div>

          {/* Preparation Time selector */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-amber-300 flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-400" />
              Tiempo de Preparación y Fecha de Batalla (Punto 39)
            </label>
            <div className="space-y-1.5">
              {PVP_PREPARATION_OPTIONS.map((opt) => {
                const isSelected = selectedHours === opt.hours;
                return (
                  <button
                    key={opt.hours}
                    type="button"
                    onClick={() => {
                      setSelectedHours(opt.hours);
                      playSound('click');
                    }}
                    className={`w-full text-left px-3 py-2.5 rounded-xl border text-xs flex items-center justify-between transition cursor-pointer ${
                      isSelected
                        ? 'bg-amber-950/60 border-amber-500 text-amber-200 shadow-sm'
                        : 'bg-stone-950/70 border-stone-800 text-stone-300 hover:border-stone-700'
                    }`}
                  >
                    <span>{opt.label}</span>
                    {isSelected && (
                      <span className="text-[11px] font-bold text-amber-400 font-mono">Pactado</span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Gold Stake */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-amber-300 flex items-center gap-2">
                <Coins className="w-4 h-4 text-yellow-400" />
                Apuesta en Litigio (Monedas de Oro)
              </label>
              <span className="text-xs text-stone-400 font-mono">
                Oro en arcas: <strong className="text-yellow-400">{kingdom.resources.gold}</strong>
              </span>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {[0, 100, 250, 500].map((amount) => {
                const isSelected = goldStake === amount;
                const canAfford = kingdom.resources.gold >= amount;
                return (
                  <button
                    key={amount}
                    type="button"
                    disabled={!canAfford}
                    onClick={() => {
                      setGoldStake(amount);
                      playSound('click');
                    }}
                    className={`py-2 px-1 rounded-xl text-xs font-bold border transition text-center ${
                      isSelected
                        ? 'bg-yellow-950/70 border-yellow-500 text-yellow-300'
                        : canAfford
                        ? 'bg-stone-950 border-stone-800 text-stone-300 hover:border-stone-700'
                        : 'opacity-40 border-stone-900 bg-stone-950 text-stone-600 cursor-not-allowed'
                    }`}
                  >
                    {amount === 0 ? 'Sin oro' : `${amount} 🪙`}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Preset Messages selector (Punto 60) */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-amber-300 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-amber-400" />
              Mensaje Diplomático Oficial (Punto 60 - Frases Predefinidas)
            </label>
            <div className="space-y-1.5">
              {PVP_PRESET_MESSAGES.map((msg) => {
                const isSelected = selectedMessage === msg;
                return (
                  <button
                    key={msg}
                    type="button"
                    onClick={() => {
                      setSelectedMessage(msg);
                      playSound('click');
                    }}
                    className={`w-full text-left px-3 py-2 rounded-xl border text-xs flex items-center justify-between transition ${
                      isSelected
                        ? 'bg-red-950/50 border-red-500 text-red-200'
                        : 'bg-stone-950 border-stone-800 text-stone-300 hover:border-stone-700'
                    }`}
                  >
                    <span>{msg}</span>
                    {isSelected && <span className="w-2 h-2 rounded-full bg-red-500"></span>}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Error Message */}
          {error && (
            <div className="bg-red-950/80 border border-red-800 text-red-200 p-3 rounded-xl text-xs">
              {error}
            </div>
          )}

          {/* Action buttons */}
          <div className="pt-2 flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="flex-1 py-3 px-4 rounded-xl border border-stone-700 text-stone-300 hover:bg-stone-800 text-xs font-bold transition"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 py-3 px-4 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-stone-950 font-bold text-xs shadow-lg shadow-amber-950/50 flex items-center justify-center gap-2 transition"
            >
              <Swords className="w-4 h-4" />
              {isSubmitting ? 'Despachando...' : 'Enviar Desafío al Parlamento'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
