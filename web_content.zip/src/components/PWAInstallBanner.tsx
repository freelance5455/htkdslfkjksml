import React, { useState } from 'react';
import { Check, Copy, Download, FileArchive, Loader2, Smartphone, WifiOff, X } from 'lucide-react';
import { LangMode } from '../data/types';
import { useOnlineStatus, usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC<{ lang: LangMode }> = ({ lang }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [downloadingType, setDownloadingType] = useState<'source' | 'web' | null>(null);
  const [zipError, setZipError] = useState<string | null>(null);

  const currentUrl = typeof window !== 'undefined' ? window.location.origin : '';
  const isInIframe = typeof window !== 'undefined' && window.self !== window.top;

  const handleClick = () => {
    setZipError(null);
    setShowGuide(true);
  };

  const handleCopyUrl = () => {
    navigator.clipboard?.writeText(currentUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const handleDownloadZip = async (type: 'source' | 'web') => {
    try {
      setZipError(null);
      setDownloadingType(type);
      const response = await fetch(`/api/download-zip?type=${type}`);
      if (!response.ok) {
        const errData = (await response.json().catch(() => ({}))) as { error?: string };
        throw new Error(errData.error || `Download failed (${response.status})`);
      }
      const blob = await response.blob();
      const blobUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download =
        type === 'web' ? 'farid-plumber-pro-web-bundle.zip' : 'farid-plumber-pro-source.zip';
      document.body.appendChild(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(blobUrl), 5000);
    } catch (err: unknown) {
      setZipError(err instanceof Error ? err.message : 'Unable to download ZIP file');
    } finally {
      setDownloadingType(null);
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={handleClick}
        className="h-12 px-5 rounded-xl bg-white border border-blue-300 hover:border-blue-600 text-blue-800 hover:bg-blue-50 text-sm font-semibold transition-colors whitespace-nowrap shrink-0 flex items-center gap-2"
      >
        <Download className="w-4 h-4" />
        <span>
          {isInstalled
            ? lang === 'hi'
              ? 'ऐप ZIP डाउनलोड करें'
              : 'Download App ZIP'
            : lang === 'hi'
              ? 'ऐप डाउनलोड / ZIP इंस्टॉल'
              : 'Download App / ZIP'}
        </span>
      </button>

      {showGuide && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Download and Install Farid Plumber Pro"
          onClick={() => setShowGuide(false)}
        >
          <div
            className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl border border-slate-200 p-5 sm:p-6 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-200 text-blue-700 flex items-center justify-center shrink-0">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">
                    {lang === 'hi' ? 'ऐप ZIP डाउनलोड और इंस्टॉल' : 'Download App ZIP & Install'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {lang === 'hi'
                      ? 'ऑफलाइन फाइल ZIP डाउनलोड करें या Chrome में इंस्टॉल करें'
                      : 'Download complete ZIP package or install in Chrome'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                aria-label="Close install guide"
                className="w-9 h-9 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-100 flex items-center justify-center shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-sm text-slate-700">
              {isInstallable && !isInstalled && (
                <button
                  type="button"
                  onClick={install}
                  className="w-full h-11 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors"
                >
                  <Smartphone className="w-4 h-4" />
                  <span>
                    {lang === 'hi' ? 'सीधे होम स्क्रीन पर इंस्टॉल करें' : 'Install App on Home Screen Now'}
                  </span>
                </button>
              )}
              {/* ZIP Download Section */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
                <div className="flex items-center gap-2 font-bold text-slate-900 text-xs sm:text-sm">
                  <FileArchive className="w-4 h-4 text-blue-700 shrink-0" />
                  <span>
                    {lang === 'hi'
                      ? 'ZIP फाइल सीधे फोन/कंप्यूटर में डाउनलोड करें:'
                      : 'Download App Package (.ZIP):'}
                  </span>
                </div>

                <div className="grid grid-cols-1 gap-2">
                  <button
                    type="button"
                    onClick={() => handleDownloadZip('source')}
                    disabled={downloadingType !== null}
                    className="w-full h-11 px-4 rounded-xl bg-blue-700 hover:bg-blue-800 disabled:opacity-60 text-white text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-colors"
                  >
                    {downloadingType === 'source' ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <FileArchive className="w-4 h-4" />
                    )}
                    <span>
                      {downloadingType === 'source'
                        ? lang === 'hi'
                          ? 'ZIP तैयार हो रहा है...'
                          : 'Preparing Source ZIP...'
                        : lang === 'hi'
                          ? 'Complete App Source ZIP डाउनलोड करें'
                          : 'Download Complete App Source (.ZIP)'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleDownloadZip('web')}
                    disabled={downloadingType !== null}
                    className="w-full h-10 px-4 rounded-xl bg-white border border-slate-300 hover:border-blue-500 hover:bg-blue-50 disabled:opacity-60 text-slate-800 text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
                  >
                    {downloadingType === 'web' ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Download className="w-4 h-4 text-blue-700" />
                    )}
                    <span>
                      {downloadingType === 'web'
                        ? lang === 'hi'
                          ? 'Web ZIP तैयार हो रहा है...'
                          : 'Preparing Web ZIP...'
                        : lang === 'hi'
                          ? 'Ready Web Build ZIP (Netlify/Hosting)'
                          : 'Download Ready Web Build (.ZIP)'}
                    </span>
                  </button>
                </div>

                {zipError && (
                  <p className="text-xs text-rose-700 bg-rose-50 border border-rose-200 rounded-lg px-2.5 py-1.5">
                    {zipError}
                  </p>
                )}
              </div>

              {isInIframe && currentUrl && (
                <a
                  href={currentUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full h-11 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors"
                >
                  <Download className="w-4 h-4" />
                  <span>
                    {lang === 'hi' ? 'सीधे Chrome टैब में ऐप खोलें' : 'Open App Directly in Chrome Tab'}
                  </span>
                </a>
              )}

              {!isInstalled &&
                (isIOS ? (
                  <div className="p-3.5 rounded-xl bg-blue-50 border border-blue-200 space-y-1.5 text-xs sm:text-sm">
                    <div className="font-bold text-blue-950">iPhone / iPad (Safari):</div>
                    <p>1. Open this app directly in <strong>Safari</strong> (outside preview frame).</p>
                    <p>2. Tap the <strong>Share</strong> icon in Safari toolbar.</p>
                    <p>3. Scroll down and tap <strong>Add to Home Screen</strong>.</p>
                    {lang !== 'en' && (
                      <p className="text-blue-900 pt-1">
                        हिंदी: Safari में खोलें → <strong>Share</strong> बटन दबाएं → <strong>Add to Home Screen</strong> चुनें।
                      </p>
                    )}
                  </div>
                ) : (
                  <div className="p-3.5 rounded-xl bg-blue-50 border border-blue-200 space-y-1.5 text-xs sm:text-sm">
                    <div className="font-bold text-blue-950">Android (Chrome) & Desktop (Chrome / Edge):</div>
                    <p>1. Open the app in a full <strong>Chrome</strong> tab (do not use WhatsApp in-app browser).</p>
                    <p>2. Tap Chrome menu <strong>⋮</strong> → <strong>Install app</strong> / <strong>Add to Home screen</strong>.</p>
                    {lang !== 'en' && (
                      <p className="text-blue-900 pt-1">
                        हिंदी: सीधे Chrome में खोलें → ऊपर दाएं <strong>⋮</strong> मेनू दबाएं → <strong>Install app / Add to Home screen</strong> चुनें।
                      </p>
                    )}
                  </div>
                ))}

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-2">
                <span className="text-xs font-mono-num text-slate-600 truncate">
                  {currentUrl}
                </span>
                <button
                  type="button"
                  onClick={handleCopyUrl}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-semibold flex items-center gap-1.5 shrink-0"
                >
                  {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedUrl ? 'Copied' : 'Copy Link'}</span>
                </button>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowGuide(false)}
              className="w-full h-11 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold"
            >
              {lang === 'hi' ? 'बंद करें' : 'Close'}
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export const OfflineIndicator: React.FC<{ lang: LangMode }> = ({ lang }) => {
  const isOnline = useOnlineStatus();
  if (isOnline) return null;

  return (
    <div className="fixed bottom-20 md:bottom-4 left-4 z-50 flex items-center gap-2 rounded-xl bg-amber-600 px-3.5 py-2 text-xs font-semibold text-white shadow-lg">
      <WifiOff className="w-4 h-4 shrink-0" />
      <span>
        {lang === 'hi'
          ? 'ऑफलाइन मोड — सेव किया डेटा उपलब्ध है'
          : 'Offline Mode — Cached lessons & routine available'}
      </span>
    </div>
  );
};
