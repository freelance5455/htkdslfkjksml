import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Smartphone, Download, CheckCircle2, X, Share2, PlusSquare, Sparkles } from 'lucide-react';

interface PWAInstallBannerProps {
  lang: 'bn' | 'en';
}

export const PWAInstallBanner: React.FC<PWAInstallBannerProps> = ({ lang }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [isDismissed, setIsDismissed] = useState(false);
  const [showIOSModal, setShowIOSModal] = useState(false);

  // If already installed or dismissed this session, don't show the full banner
  if (isInstalled || isDismissed) {
    return null;
  }

  // Not installable in this browser context and not iOS
  if (!isInstallable && !isIOS) {
    return null;
  }

  const handleInstallClick = async () => {
    if (isInstallable) {
      await install();
    } else if (isIOS) {
      setShowIOSModal(true);
    }
  };

  return (
    <>
      <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 text-white px-4 py-3 shadow-md relative border-b border-indigo-500/30">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="flex items-start sm:items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/15 backdrop-blur-md flex items-center justify-center shrink-0 border border-white/20 shadow-xs">
              <Smartphone className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/90 text-white font-black text-[10px] uppercase tracking-wider">
                  Android 8 — 16 Ready
                </span>
                <span className="font-extrabold text-sm text-white">
                  {lang === 'bn'
                    ? 'স্মার্টফোনে অ্যাপ ইনস্টল করুন'
                    : 'Install Mobile App on Phone'}
                </span>
              </div>
              <p className="text-xs text-blue-100 mt-0.5">
                {lang === 'bn'
                  ? 'প্লে-স্টোর অ্যাপের মতো অফলাইন ও অনলাইনে ফুলস্ক্রিনে দ্রুত চালান। কোনো ইন্টারনেট সংযোগ ছাড়াও নির্বিঘ্নে চলবে।'
                  : 'Install directly on your home screen. Operates 100% offline and online with full-screen experience.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto shrink-0 pl-13 sm:pl-0">
            <button
              onClick={handleInstallClick}
              className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 active:scale-95 text-slate-900 font-black text-xs flex items-center gap-1.5 shadow-md transition-all cursor-pointer"
            >
              <Download className="w-4 h-4 text-slate-900" />
              <span>{lang === 'bn' ? 'ফোনে ইনস্টল করুন' : 'Install on Phone'}</span>
            </button>

            <button
              onClick={() => setIsDismissed(true)}
              className="p-2 rounded-xl hover:bg-white/15 text-blue-200 hover:text-white transition-colors cursor-pointer"
              title={lang === 'bn' ? 'এখন নয়' : 'Not now'}
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* iOS Safari Guide Modal */}
      {showIOSModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-sm rounded-3xl bg-white p-6 shadow-2xl border border-slate-200">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-3">
              <Smartphone className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-black text-slate-900">
              {lang === 'bn' ? 'আইফোন / আইপ্যাডে ইনস্টল করুন' : 'Install on iPhone / iPad'}
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              {lang === 'bn'
                ? 'সাফারি ব্রাউজারে নিচের নির্দেশিকা অনুসরণ করুন:'
                : 'Follow these quick steps in Safari browser:'}
            </p>

            <div className="mt-4 space-y-2.5 text-xs text-slate-700 bg-slate-50 p-4 rounded-2xl border border-slate-100">
              <div className="flex items-center gap-2">
                <Share2 className="w-4 h-4 text-blue-600 shrink-0" />
                <span>
                  {lang === 'bn'
                    ? '১. নিচের শেয়ার (Share) বাটনে চাপুন।'
                    : '1. Tap the Share button in Safari.'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <PlusSquare className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>
                  {lang === 'bn'
                    ? '২. একটু নিচে নেমে "Add to Home Screen" চাপুন।'
                    : '2. Scroll down and tap "Add to Home Screen".'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>
                  {lang === 'bn'
                    ? '৩. "Add" চাপলেই হোমস্ক্রিনে অ্যাপ যোগ হবে।'
                    : '3. Tap "Add" to install on home screen.'}
                </span>
              </div>
            </div>

            <button
              onClick={() => setShowIOSModal(false)}
              className="mt-5 w-full py-2.5 rounded-xl bg-slate-900 text-white font-bold text-xs hover:bg-slate-800 transition cursor-pointer"
            >
              {lang === 'bn' ? 'বুঝেছি / বন্ধ করুন' : 'Got it / Close'}
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export const PWAInstallButton: React.FC<{ lang: 'bn' | 'en' }> = ({ lang }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSModal, setShowIOSModal] = useState(false);

  if (isInstalled) {
    return (
      <div className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold">
        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
        <span>{lang === 'bn' ? 'অ্যাপ সক্রিয়' : 'App Active'}</span>
      </div>
    );
  }

  if (!isInstallable && !isIOS) {
    return null;
  }

  return (
    <>
      <button
        onClick={async () => {
          if (isInstallable) {
            await install();
          } else if (isIOS) {
            setShowIOSModal(true);
          }
        }}
        className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs transition cursor-pointer"
        title={lang === 'bn' ? 'অ্যান্ড্রয়েড ফোনে অ্যাপ হিসেবে ডাউনলোড করুন' : 'Install on device'}
      >
        <Download className="w-3.5 h-3.5" />
        <span>{lang === 'bn' ? 'অ্যাপ ইনস্টল' : 'Install App'}</span>
      </button>

      {showIOSModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-sm rounded-3xl bg-white p-6 shadow-2xl border border-slate-200 text-slate-800">
            <h3 className="text-lg font-black text-slate-900">
              {lang === 'bn' ? 'হোমস্ক্রিনে যোগ করুন' : 'Add to Home Screen'}
            </h3>
            <p className="text-xs text-slate-500 mt-2">
              {lang === 'bn'
                ? 'সাফারি ব্রাউজারে শেয়ার আইকনে (Share) চাপ দিয়ে "Add to Home Screen" সিলেক্ট করুন।'
                : 'Tap Share in Safari and select "Add to Home Screen".'}
            </p>
            <button
              onClick={() => setShowIOSModal(false)}
              className="mt-4 w-full py-2 rounded-xl bg-slate-900 text-white font-bold text-xs cursor-pointer"
            >
              {lang === 'bn' ? 'ঠিক আছে' : 'OK'}
            </button>
          </div>
        </div>
      )}
    </>
  );
};
