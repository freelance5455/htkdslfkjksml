import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, Smartphone, X, CheckCircle2 } from 'lucide-react';
import { feedback } from '../utils/haptics';

export const PWAInstallBanner: React.FC<{ soundEnabled?: boolean; hapticsEnabled?: boolean }> = ({
  soundEnabled = true,
  hapticsEnabled = true,
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  // If already installed or dismissed, don't show
  if (isInstalled || dismissed) {
    return null;
  }

  const handleInstall = async () => {
    feedback.vibrateSoft(hapticsEnabled);
    feedback.playTap(soundEnabled);
    const success = await install();
    if (success) {
      feedback.vibrateSuccess(hapticsEnabled);
      feedback.playSuccess(soundEnabled);
    }
  };

  return (
    <>
      <div className="bg-gradient-to-r from-red-700 via-rose-600 to-amber-600 text-white p-3 px-4 shadow-md flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center shrink-0">
            <Smartphone className="w-4 h-4 text-white" />
          </div>
          <div>
            <div className="font-semibold text-sm leading-tight">Install on Android</div>
            <div className="text-white/80 text-[11px]">Add Stock Manager to home screen for fast offline access</div>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {isInstallable && (
            <button
              onClick={handleInstall}
              className="bg-white text-red-700 hover:bg-red-50 font-semibold px-3 py-1.5 rounded-lg shadow-sm flex items-center gap-1.5 transition active:scale-95"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Install</span>
            </button>
          )}

          {isIOS && (
            <button
              onClick={() => setShowIOSGuide(true)}
              className="bg-white/20 hover:bg-white/30 text-white font-medium px-2.5 py-1.5 rounded-lg transition"
            >
              How to Install
            </button>
          )}

          <button
            onClick={() => setDismissed(true)}
            className="p-1 rounded-full text-white/70 hover:text-white hover:bg-white/10 transition"
            aria-label="Dismiss banner"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {showIOSGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 p-5 shadow-2xl text-slate-800 dark:text-slate-100">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-bold flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-red-600" />
                Add to Home Screen
              </h3>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <ol className="space-y-3 text-xs text-slate-600 dark:text-slate-300">
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-400 font-bold flex items-center justify-center shrink-0">1</span>
                <span>Open browser menu or tap the <strong>Share</strong> button.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-400 font-bold flex items-center justify-center shrink-0">2</span>
                <span>Scroll down and tap <strong>Add to Home screen</strong>.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-400 font-bold flex items-center justify-center shrink-0">3</span>
                <span>Tap <strong>Add</strong> to launch it like a native Android/mobile app!</span>
              </li>
            </ol>

            <button
              onClick={() => setShowIOSGuide(false)}
              className="mt-5 w-full py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-medium text-xs transition"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </>
  );
};
