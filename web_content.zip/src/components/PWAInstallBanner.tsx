import { useState } from 'react';
import { Download, Smartphone, X, Share } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { useI18n } from '../contexts/LanguageContext';

const DISMISS_KEY = 'tmn_pwa_banner_dismissed_until';
const DISMISS_TTL_MS = 7 * 24 * 60 * 60 * 1000;

export function PWAInstallBanner() {
  const { canPromptInstall, isInstalled, isIOS, promptInstall } = usePWAInstall();
  const { t } = useI18n();
  const [dismissed, setDismissed] = useState<boolean>(() => {
    try {
      const until = Number(localStorage.getItem(DISMISS_KEY) || 0);
      return Number.isFinite(until) && until > Date.now();
    } catch {
      return false;
    }
  });
  const [showGuide, setShowGuide] = useState(false);

  if (isInstalled || dismissed) return null;

  const handleInstallClick = async () => {
    if (canPromptInstall) {
      const accepted = await promptInstall();
      if (accepted) {
        setDismissed(true);
      }
      return;
    }
    setShowGuide((prev) => !prev);
  };

  const handleDismiss = () => {
    setDismissed(true);
    try {
      localStorage.setItem(DISMISS_KEY, String(Date.now() + DISMISS_TTL_MS));
    } catch {
      // Ignore
    }
  };

  return (
    <div
      data-testid="pwa-install-banner"
      className="relative z-50 border-b border-sky-500/25 bg-gradient-to-l from-[#0a1d3a] via-[#0e2a52] to-[#0a1d3a] text-white"
    >
      <div className="mx-auto flex max-w-5xl items-center justify-between gap-2.5 px-3 py-2 sm:px-4">
        <div className="flex min-w-0 items-center gap-2.5">
          <img
            src="/pwa-192x192.png"
            alt="TMN"
            className="h-8 w-8 shrink-0 rounded-lg border border-sky-400/40 object-cover shadow-sm"
          />
          <div className="min-w-0">
            <div className="truncate text-xs font-extrabold tracking-tight text-white sm:text-sm">
              {t.pwaBannerTitle}
            </div>
            <div className="hidden truncate text-[11px] font-medium text-sky-200/85 sm:block">
              {t.pwaBannerSub}
            </div>
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-1.5">
          <button
            type="button"
            data-testid="pwa-install-btn"
            onClick={() => void handleInstallClick()}
            className="inline-flex items-center gap-1.5 rounded-xl bg-sky-500 px-3 py-1.5 text-xs font-extrabold text-slate-950 shadow-sm hover:bg-sky-400"
          >
            <Download className="h-3.5 w-3.5" />
            <span>{t.pwaInstallBtn}</span>
          </button>
          <button
            type="button"
            onClick={handleDismiss}
            aria-label={t.close}
            className="flex h-7 w-7 items-center justify-center rounded-lg border border-white/15 bg-white/5 text-sky-200 hover:bg-white/15 hover:text-white"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {showGuide && (
        <div className="border-t border-sky-400/20 bg-[#07152b] px-4 py-3 text-xs text-sky-100">
          <div className="mx-auto flex max-w-5xl items-start justify-between gap-3">
            <div className="space-y-1">
              <div className="flex items-center gap-1.5 font-extrabold text-sky-300">
                {isIOS ? <Share className="h-3.5 w-3.5" /> : <Smartphone className="h-3.5 w-3.5" />}
                <span>{isIOS ? t.pwaIosTitle : t.pwaBannerTitle}</span>
              </div>
              {isIOS ? (
                <>
                  <p className="leading-relaxed text-sky-100/90">{t.pwaIosStep1}</p>
                  <p className="leading-relaxed text-sky-100/90">{t.pwaIosStep2}</p>
                </>
              ) : (
                <p className="leading-relaxed text-sky-100/90">{t.pwaDesktopStep}</p>
              )}
            </div>
            <button
              type="button"
              onClick={() => setShowGuide(false)}
              className="shrink-0 rounded-lg border border-white/15 px-2.5 py-1 text-[11px] font-bold text-sky-200 hover:bg-white/10"
            >
              {t.close}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
