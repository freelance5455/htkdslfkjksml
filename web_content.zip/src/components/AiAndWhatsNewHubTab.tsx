import { useEffect, useRef, useState } from 'react';
import { motion, type TargetAndTransition } from 'motion/react';
import {
  Send,
  Paperclip,
  X,
  WifiOff,
  Trash2,
  FileText,
  Image as ImageIcon,
  Film,
  Music,
  Loader2,
  Sparkles,
  Newspaper,
  HelpCircle,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Calendar,
} from 'lucide-react';
import type { ChatMessage, WhatsNewItem } from '../types';
import { celebrateCorrectAnswer } from '../lib/confetti';
import { useResolvedFileUrl } from '../hooks/useResolvedFileUrl';
import { InteractiveCard, TactileButton } from './InteractiveButton';

function NewsCardImage({ src, alt }: { src: string; alt: string }) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const node = containerRef.current;
    if (!node) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          setInView(true);
          observer.disconnect();
        }
      },
      { rootMargin: '160px' }
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  const { resolvedUrl, loading } = useResolvedFileUrl(inView ? src : '', 'image');

  return (
    <div
      ref={containerRef}
      className="h-40 w-full bg-slate-100 dark:bg-slate-800 overflow-hidden"
    >
      {!inView || loading ? (
        <div className="w-full h-full bg-slate-200/80 dark:bg-slate-800 animate-pulse" />
      ) : resolvedUrl ? (
        <img
          src={resolvedUrl}
          alt={alt}
          loading="lazy"
          decoding="async"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover"
        />
      ) : null}
    </div>
  );
}

interface AiAndWhatsNewHubTabProps {
  isOnline: boolean;
  messages: ChatMessage[];
  onUpdateMessages: (messages: ChatMessage[]) => void;
  items: WhatsNewItem[];
  loadingItems: boolean;
  solvedQuizIds: string[];
  onQuizSolved: (quizId: string) => void;
  understoodAiIds: string[];
  onMarkAiUnderstood: (messageId: string) => void;
  onAskAiQuestion: (messageId: string) => void;
}

type HubSectionFilter = 'all' | 'ai' | 'news' | 'quizzes';

const QUICK_PROMPTS = [
  { id: 'explain', label: 'اشرح لي هذا الملف بأسلوب مبسط' },
  { id: 'summarize', label: 'لخص أهم النقاط الأساسية في الدرس' },
  { id: 'quiz3', label: 'أنشئ لي 3 أسئلة تدريبية مع الحل' },
] as const;

export function AiAndWhatsNewHubTab({
  isOnline,
  messages,
  onUpdateMessages,
  items,
  loadingItems,
  solvedQuizIds,
  onQuizSolved,
  understoodAiIds,
  onMarkAiUnderstood,
  onAskAiQuestion,
}: AiAndWhatsNewHubTabProps) {
  const [sectionFilter, setSectionFilter] = useState<HubSectionFilter>('all');

  // AI state
  const [prompt, setPrompt] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [activeContextFile, setActiveContextFile] = useState<File | null>(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [lastRequest, setLastRequest] = useState<{
    text: string;
    file: File | null;
    priorMessages: ChatMessage[];
  } | null>(null);

  // Typing animation state for newly arrived model reply
  const [typingMessageId, setTypingMessageId] = useState<string | null>(null);
  const [typedLength, setTypedLength] = useState(0);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const promptInputRef = useRef<HTMLTextAreaElement | null>(null);
  const chatScrollRef = useRef<HTMLDivElement | null>(null);

  // Quiz state & progressive viewport pagination
  const [quizAnswers, setQuizAnswers] = useState<Record<string, number>>({});
  const [visibleNewsCount, setVisibleNewsCount] = useState(4);
  const [visibleQuizzesCount, setVisibleQuizzesCount] = useState(4);
  const newsSentinelRef = useRef<HTMLDivElement | null>(null);
  const quizzesSentinelRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const node = newsSentinelRef.current;
    if (!node) return;
    const obs = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          setVisibleNewsCount((c) => c + 4);
        }
      },
      { rootMargin: '160px' }
    );
    obs.observe(node);
    return () => obs.disconnect();
  }, [items.length, sectionFilter, visibleNewsCount]);

  useEffect(() => {
    const node = quizzesSentinelRef.current;
    if (!node) return;
    const obs = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          setVisibleQuizzesCount((c) => c + 4);
        }
      },
      { rootMargin: '160px' }
    );
    obs.observe(node);
    return () => obs.disconnect();
  }, [items.length, sectionFilter, visibleQuizzesCount]);

  useEffect(() => {
    if (!typingMessageId) return;
    const targetMsg = messages.find((m) => m.id === typingMessageId);
    if (!targetMsg) {
      setTypingMessageId(null);
      return;
    }
    const fullLength = targetMsg.text.length;
    if (typedLength >= fullLength) {
      setTypingMessageId(null);
      return;
    }

    const timer = window.setInterval(() => {
      setTypedLength((prev) => {
        const step = fullLength > 600 ? 4 : 2;
        const next = prev + step;
        if (next >= fullLength) {
          window.clearInterval(timer);
          setTypingMessageId(null);
          return fullLength;
        }
        return next;
      });
    }, 16);

    return () => window.clearInterval(timer);
  }, [typingMessageId, typedLength, messages]);

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [messages.length, typedLength, aiLoading]);

  if (!isOnline) {
    return (
      <section className="bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 sm:p-8 text-center max-w-2xl mx-auto shadow-xs">
        <div className="w-12 h-12 mx-auto mb-3 rounded-2xl bg-orange-50 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400 flex items-center justify-center">
          <WifiOff className="w-6 h-6" />
        </div>
        <h1 className="font-display text-lg sm:text-xl font-bold text-slate-900 dark:text-white mb-1.5">
          المعلم الذكي و ما الجديد يحتاجان إلى اتصال
        </h1>
        <p className="text-slate-700 dark:text-slate-200 text-xs sm:text-sm font-medium leading-relaxed">
          افتح الإنترنت لاستخدام الذكاء الاصطناعي أو ما الجديد
        </p>
      </section>
    );
  }

  const newsItems = items.filter((i) => i.category === 'news');
  const quizItems = items.filter((i) => i.category === 'quiz');

  const getAiAttachmentIcon = (type: string) => {
    if (type.startsWith('image/')) return ImageIcon;
    if (type.startsWith('video/')) return Film;
    if (type.startsWith('audio/')) return Music;
    return FileText;
  };

  const handleSelectQuickPrompt = async (
    quickId: (typeof QUICK_PROMPTS)[number]['id'],
    quickLabel: string
  ) => {
    if (aiLoading) return;
    const fileToSend = selectedFile ?? activeContextFile;
    const typedText = prompt.trim();
    let finalPrompt = quickLabel;

    if (fileToSend) {
      if (quickId === 'quiz3') {
        finalPrompt = `اعمل 3 أسئلة على الملف ده (${fileToSend.name}) مع الحل والشرح بالعربي المصري البسيط`;
      } else if (quickId === 'explain') {
        finalPrompt = `اشرح لي الملف ده (${fileToSend.name}) بأسلوب مبسط وواضح بالعربي المصري البسيط`;
      } else if (quickId === 'summarize') {
        finalPrompt = `لخص أهم النقاط الأساسية في الملف ده (${fileToSend.name}) بالعربي المصري البسيط`;
      }
    } else if (typedText) {
      finalPrompt = `${quickLabel}: ${typedText}`;
    } else if (quickId === 'quiz3') {
      finalPrompt = 'أنشئ لي 3 أسئلة تدريبية مع الحل والشرح بالعربي المصري البسيط';
    }

    await executeAiRequest(finalPrompt, fileToSend, messages, true);
  };

  const executeAiRequest = async (
    textToSend: string,
    fileToSend: File | null,
    historySource: ChatMessage[],
    appendUserMessage: boolean
  ) => {
    if (aiLoading) return;
    setAiError(null);

    if (fileToSend) {
      setActiveContextFile(fileToSend);
    }

    let workingMessages = historySource;
    if (appendUserMessage) {
      const userMsg: ChatMessage = {
        id: `msg-${Date.now()}`,
        role: 'user',
        text: textToSend || `اشرح لي محتوى الملف: ${fileToSend?.name || ''}`,
        attachmentName: fileToSend?.name,
        attachmentType: fileToSend?.type,
        timestamp: Date.now(),
      };
      workingMessages = [...historySource, userMsg];
      onUpdateMessages(workingMessages);
      setPrompt('');
      setSelectedFile(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }

    setLastRequest({
      text: textToSend || `اشرح لي محتوى الملف: ${fileToSend?.name || ''}`,
      file: fileToSend,
      priorMessages: workingMessages,
    });
    setAiLoading(true);

    try {
      const formData = new FormData();
      formData.append('prompt', textToSend || `اشرح لي محتوى الملف: ${fileToSend?.name || ''}`);
      formData.append(
        'history',
        JSON.stringify(
          historySource.slice(-8).map((m) => ({
            role: m.role,
            text: m.text,
          }))
        )
      );
      if (fileToSend) {
        formData.append('file', fileToSend);
      }

      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        body: formData,
      });

      const data = (await res.json().catch(() => ({}))) as {
        text?: string;
        error?: string;
        code?: string;
        status?: number;
        details?: string;
      };

      if (!res.ok || !data.text) {
        console.error('[المعلم الذكي] خطأ من الخادم:', {
          status: res.status || data.status,
          code: data.code,
          details: data.details || data.error,
        });

        if (
          data.code === 'MISSING_API_KEY' ||
          data.code === 'API_KEY_INVALID_OR_DENIED'
        ) {
          setAiError(
            data.error ||
              'المعلم محتاج مفتاح API في إعدادات المشروع (Settings > Secrets).'
          );
          return;
        }
        setAiError('حصل مشكلة في الاتصال، دوس حاول تاني');
        return;
      }

      const aiMsgId = `msg-${Date.now() + 1}`;
      const aiMsg: ChatMessage = {
        id: aiMsgId,
        role: 'model',
        text: data.text,
        timestamp: Date.now(),
      };
      onUpdateMessages([...workingMessages, aiMsg]);
      onAskAiQuestion(aiMsgId);
      setTypingMessageId(aiMsgId);
      setTypedLength(0);
      setLastRequest(null);
    } catch (err) {
      console.error('[المعلم الذكي] تعذر الاتصال بالخادم:', err);
      setAiError('حصل مشكلة في الاتصال، دوس حاول تاني');
    } finally {
      setAiLoading(false);
    }
  };

  const handleSendAi = async () => {
    const textToSend = prompt.trim();
    if (!textToSend && !selectedFile) return;
    await executeAiRequest(textToSend, selectedFile ?? activeContextFile, messages, true);
  };

  const handleRetryAi = async () => {
    if (!lastRequest || aiLoading) return;
    await executeAiRequest(
      lastRequest.text,
      lastRequest.file,
      lastRequest.priorMessages,
      false
    );
  };

  const formatDate = (ms: number, customDate?: string) => {
    if (customDate) return customDate;
    return new Intl.DateTimeFormat('ar-EG', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    }).format(new Date(ms));
  };

  const handleSelectOption = (item: WhatsNewItem, optionIndex: number) => {
    if (quizAnswers[item.id] !== undefined) return;
    setQuizAnswers((prev) => ({ ...prev, [item.id]: optionIndex }));
    if (optionIndex === item.quizCorrectIndex) {
      celebrateCorrectAnswer();
      onQuizSolved(item.id);
    }
  };

  const SelectedAiFileIcon = selectedFile ? getAiAttachmentIcon(selectedFile.type) : FileText;

  return (
    <div className="space-y-6">
      {/* Hub Filter Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl border border-slate-200/80 dark:border-slate-800 p-4 sm:p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-3.5 shadow-xs">
        <div>
          <h1 className="font-display text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
            المعلم الذكي و ما الجديد
          </h1>
          <p className="text-slate-600 dark:text-slate-400 text-xs sm:text-sm mt-0.5">
            تعلّم مع المعلم الذكي وتابع الأخبار والأسئلة التفاعلية.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {[
            { id: 'all', label: 'الكل' },
            { id: 'ai', label: 'المعلم الذكي' },
            { id: 'news', label: `ما الجديد (${newsItems.length})` },
            { id: 'quizzes', label: `اختبر نفسك (${quizItems.length})` },
          ].map((tab) => (
            <TactileButton
              key={tab.id}
              type="button"
              onClick={() => setSectionFilter(tab.id as HubSectionFilter)}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap min-h-[38px] ${
                sectionFilter === tab.id
                  ? 'bg-violet-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {tab.label}
            </TactileButton>
          ))}
        </div>
      </div>

      {/* Section A: AI Tutor */}
      {(sectionFilter === 'all' || sectionFilter === 'ai') && (
        <section className="space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl border border-slate-200/80 dark:border-slate-800 p-4 sm:p-6 shadow-xs flex flex-col gap-4">
            <div className="flex flex-wrap items-center justify-between gap-3 pb-3.5 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-violet-100 dark:bg-violet-950 shrink-0 flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-violet-700 dark:text-violet-400" />
                </div>
                <div>
                  <h2 className="font-display text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white">
                    المعلم الذكي
                  </h2>
                  <p className="text-slate-600 dark:text-slate-400 text-xs sm:text-sm">
                    اسأل أي سؤال أو ارفع أي ملف وسأشرحه لك فوراً.
                  </p>
                </div>
              </div>

              {messages.length > 0 && (
                <TactileButton
                  type="button"
                  onClick={() => {
                    onUpdateMessages([]);
                    setActiveContextFile(null);
                    setAiError(null);
                    setLastRequest(null);
                  }}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-rose-50 dark:hover:bg-rose-950 text-slate-700 dark:text-slate-200 hover:text-rose-600 dark:hover:text-rose-400 text-xs sm:text-sm font-bold min-h-[38px]"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>محادثة جديدة</span>
                </TactileButton>
              )}
            </div>

            <div
              ref={chatScrollRef}
              className="space-y-3.5 max-h-[360px] overflow-y-auto pl-1"
            >
              {messages.length === 0 ? (
                <div className="py-3 text-center">
                  <p className="text-slate-600 dark:text-slate-300 font-medium text-xs sm:text-sm">
                    اختر سؤالاً جاهزاً بالأسفل أو اكتب سؤالك وأرفق أي ملف للشرح:
                  </p>
                </div>
              ) : (
                messages.map((msg) => {
                  const isUnderstood = understoodAiIds.includes(msg.id);
                  const isTypingThis = msg.id === typingMessageId;
                  const visibleText = isTypingThis
                    ? msg.text.slice(0, typedLength)
                    : msg.text;
                  return (
                    <motion.div
                      key={msg.id}
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex ${msg.role === 'user' ? 'justify-start' : 'justify-end'}`}
                    >
                      <div
                        className={`max-w-[88%] rounded-2xl px-4 py-3 text-xs sm:text-sm leading-relaxed whitespace-pre-line space-y-2.5 ${
                          msg.role === 'user'
                            ? 'bg-violet-600 text-white rounded-tr-md'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-tl-md'
                        }`}
                      >
                        {msg.attachmentName && (
                          <div
                            className={`text-xs font-bold pb-2 border-b ${
                              msg.role === 'user'
                                ? 'border-white/20 text-violet-100'
                                : 'border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400'
                            } flex items-center gap-1.5`}
                          >
                            <Paperclip className="w-3.5 h-3.5" />
                            <span>{msg.attachmentName}</span>
                          </div>
                        )}
                        <p>
                          {visibleText}
                          {isTypingThis && (
                            <span className="inline-block w-1.5 h-3.5 mr-1 align-middle bg-violet-600 dark:bg-violet-400 animate-pulse rounded-xs" />
                          )}
                        </p>
                        {msg.role === 'model' && !isTypingThis && (
                          <div className="pt-1.5 border-t border-slate-200/70 dark:border-slate-700/70 flex justify-end">
                            <TactileButton
                              type="button"
                              disabled={isUnderstood}
                              onClick={() => onMarkAiUnderstood(msg.id)}
                              className={`inline-flex items-center gap-1 px-3 py-1 rounded-xl text-[11px] font-bold min-h-[32px] ${
                                isUnderstood
                                  ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 shadow-none'
                                  : 'bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-100 hover:bg-emerald-500 hover:text-white'
                              }`}
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>{isUnderstood ? 'تم فهم الشرح' : 'فهمت الشرح'}</span>
                            </TactileButton>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  );
                })
              )}

              {aiLoading && (
                <div className="flex justify-end">
                  <div className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-2xl rounded-tl-md px-4 py-3 flex items-center gap-2 text-xs sm:text-sm font-bold">
                    <Loader2 className="w-4 h-4 animate-spin text-violet-600 dark:text-violet-400" />
                    <span>المعلم بيكتب...</span>
                  </div>
                </div>
              )}
            </div>

            {aiError && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-200 text-xs sm:text-sm font-bold flex flex-wrap items-center justify-between gap-2.5">
                <span>{aiError}</span>
                {lastRequest && (
                  <TactileButton
                    type="button"
                    disabled={aiLoading}
                    onClick={handleRetryAi}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold min-h-[36px]"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>حاول تاني</span>
                  </TactileButton>
                )}
              </div>
            )}

            {/* Active lesson file context badge if previously attached */}
            {!selectedFile && activeContextFile && (
              <div className="flex items-center justify-between gap-2 px-3 py-1.5 rounded-xl bg-violet-50/80 dark:bg-violet-950/40 border border-violet-200/70 dark:border-violet-800/70 text-violet-900 dark:text-violet-200 text-xs">
                <div className="flex items-center gap-1.5 min-w-0">
                  <Paperclip className="w-3.5 h-3.5 text-violet-600 dark:text-violet-400 shrink-0" />
                  <span className="truncate font-bold">
                    ملف الشرح النشط: {activeContextFile.name}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveContextFile(null)}
                  aria-label="إلغاء ربط الملف النشط"
                  className="p-1 rounded-lg hover:bg-violet-200/60 dark:hover:bg-violet-900/60 cursor-pointer shrink-0"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* 3 Quick Prompt Buttons: 1 per row on mobile, 3 side-by-side on desktop */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
              {QUICK_PROMPTS.map((q) => (
                <TactileButton
                  key={q.id}
                  type="button"
                  disabled={aiLoading}
                  onClick={() => handleSelectQuickPrompt(q.id, q.label)}
                  className="w-full px-3 py-2.5 rounded-xl bg-violet-50 dark:bg-violet-950/60 hover:bg-violet-100 dark:hover:bg-violet-900 text-violet-800 dark:text-violet-200 text-xs sm:text-sm font-bold min-h-[42px] whitespace-normal text-center leading-snug disabled:opacity-60"
                >
                  {q.label}
                </TactileButton>
              ))}
            </div>

            {selectedFile && (
              <div className="flex items-center justify-between gap-3 px-3.5 py-2 rounded-xl bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 text-blue-900 dark:text-blue-100 text-xs sm:text-sm">
                <div className="flex items-center gap-2 min-w-0">
                  <SelectedAiFileIcon className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
                  <span className="font-bold truncate">{selectedFile.name}</span>
                  <span className="text-[11px] text-blue-700 dark:text-blue-300 shrink-0 tabular-nums">
                    ({(selectedFile.size / (1024 * 1024)).toFixed(2)} MB)
                  </span>
                </div>
                <motion.button
                  type="button"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    setSelectedFile(null);
                    setActiveContextFile(null);
                    if (fileInputRef.current) fileInputRef.current.value = '';
                  }}
                  aria-label="إزالة الملف المرفق"
                  className="min-w-[34px] min-h-[34px] rounded-lg flex items-center justify-center hover:bg-blue-100 dark:hover:bg-blue-900 cursor-pointer active:shadow-none"
                >
                  <X className="w-4 h-4" />
                </motion.button>
              </div>
            )}

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendAi();
              }}
              className="flex items-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="*/*"
                onChange={(e) => {
                  const picked = e.target.files?.[0] || null;
                  setSelectedFile(picked);
                  if (picked) setActiveContextFile(picked);
                }}
                className="hidden"
              />

              <TactileButton
                type="button"
                onClick={() => fileInputRef.current?.click()}
                title="إرفاق ملف"
                aria-label="إرفاق ملف"
                className="min-w-[44px] min-h-[44px] rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center shrink-0"
              >
                <Paperclip className="w-4 h-4" />
              </TactileButton>

              <textarea
                ref={promptInputRef}
                rows={1}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendAi();
                  }
                }}
                placeholder="اكتب سؤالك هنا أو أرفق ملفاً للشرح..."
                className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:border-violet-500 outline-none resize-none min-h-[44px] max-h-28 text-sm"
              />

              <TactileButton
                type="submit"
                flashSuccess
                disabled={aiLoading || (!prompt.trim() && !selectedFile)}
                aria-label="إرسال"
                className="min-w-[48px] min-h-[44px] px-4 rounded-xl bg-violet-600 hover:bg-violet-700 disabled:opacity-50 text-white font-bold flex items-center justify-center gap-1.5 shrink-0 text-sm"
              >
                <Send className="w-4 h-4" />
                <span className="hidden sm:inline">إرسال</span>
              </TactileButton>
            </form>
          </div>
        </section>
      )}

      {/* Section B: News ("ما الجديد") */}
      {(sectionFilter === 'all' || sectionFilter === 'news') && (
        <section className="space-y-3.5">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white">
              ما الجديد
            </h2>
            <span className="text-xs sm:text-sm font-bold text-slate-500 dark:text-slate-400 tabular-nums">
              {newsItems.length} خبر
            </span>
          </div>

          {loadingItems ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[1, 2].map((n) => (
                <div
                  key={n}
                  className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 h-32 animate-pulse"
                />
              ))}
            </div>
          ) : newsItems.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 text-center text-slate-500 dark:text-slate-400 text-sm font-medium">
              لسه مفيش أخبار جديدة، تابعنا
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {newsItems.slice(0, visibleNewsCount).map((item) => (
                  <InteractiveCard
                    key={item.id}
                    className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-xs flex flex-col"
                  >
                    {item.fileUrl && (
                      <NewsCardImage src={item.fileUrl} alt={item.title} />
                    )}
                    <div className="p-4 sm:p-5 space-y-2.5 flex-1">
                      <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                        <Newspaper className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                        <span className="font-bold text-blue-600 dark:text-blue-400">خبر</span>
                        <span aria-hidden="true">·</span>
                        <Calendar className="w-3.5 h-3.5" />
                        <span className="tabular-nums">
                          {formatDate(item.createdAtMs, item.newsDate)}
                        </span>
                      </div>

                      <h3 className="font-display text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                        {item.title}
                      </h3>

                      <p className="text-slate-700 dark:text-slate-300 text-xs sm:text-sm leading-relaxed whitespace-pre-line">
                        {item.description}
                      </p>
                    </div>
                  </InteractiveCard>
                ))}
              </div>
              {newsItems.length > visibleNewsCount && (
                <div ref={newsSentinelRef} className="h-8 flex items-center justify-center">
                  <span className="text-xs font-bold text-slate-400">جاري تحميل المزيد...</span>
                </div>
              )}
            </>
          )}
        </section>
      )}

      {/* Section C: Interactive Quizzes ("اختبر نفسك") */}
      {(sectionFilter === 'all' || sectionFilter === 'quizzes') && quizItems.length > 0 && (
        <section className="space-y-3.5">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white">
              اختبر نفسك — أسئلة تفاعلية
            </h2>
            <span className="text-xs sm:text-sm font-bold text-slate-500 dark:text-slate-400 tabular-nums">
              {quizItems.length} سؤال
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {quizItems.slice(0, visibleQuizzesCount).map((item) => {
              const selectedOption = quizAnswers[item.id];
              const hasAnswered = selectedOption !== undefined;
              const alreadySolvedBefore = solvedQuizIds.includes(item.id);

              return (
                <InteractiveCard
                  key={item.id}
                  className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-4 sm:p-5 space-y-3.5 shadow-xs"
                >
                  <div className="flex items-center justify-between gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                    <div className="flex items-center gap-1.5">
                      <HelpCircle className="w-3.5 h-3.5 text-orange-500" />
                      <span className="font-bold text-orange-600 dark:text-orange-400">
                        سؤال تفاعلي
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{item.title}</span>
                    </div>
                    {alreadySolvedBefore && (
                      <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                        تمت الإجابة بنجاح
                      </span>
                    )}
                  </div>

                  <p className="font-display text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                    {item.quizQuestion}
                  </p>

                  <div className="grid grid-cols-1 gap-2">
                    {item.quizOptions.map((opt, idx) => {
                      const isSelected = selectedOption === idx;
                      const isCorrect = idx === item.quizCorrectIndex;

                      let btnStyle =
                        'bg-slate-50 dark:bg-slate-800 hover:bg-violet-50 dark:hover:bg-violet-950/60 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100';
                      let animateVariant: TargetAndTransition | undefined = undefined;

                      if (hasAnswered) {
                        if (isCorrect && isSelected) {
                          btnStyle =
                            'bg-emerald-500 border-emerald-600 text-white shadow-emerald-500/25';
                          animateVariant = {
                            scale: [1, 1.04, 0.98, 1.02, 1],
                            rotate: [0, -1.5, 1.5, -1, 1, 0],
                          };
                        } else if (isCorrect) {
                          btnStyle =
                            'bg-emerald-50 dark:bg-emerald-950/70 border-emerald-400 text-emerald-900 dark:text-emerald-200';
                        } else if (isSelected && !isCorrect) {
                          btnStyle =
                            'bg-rose-500 border-rose-600 text-white shadow-rose-500/25';
                          animateVariant = {
                            x: [0, -10, 10, -8, 8, -4, 4, 0],
                          };
                        } else {
                          btnStyle =
                            'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-800 text-slate-400 dark:text-slate-500';
                        }
                      }

                      return (
                        <motion.button
                          key={idx}
                          type="button"
                          disabled={hasAnswered}
                          whileHover={!hasAnswered ? { scale: 1.05 } : undefined}
                          whileTap={!hasAnswered ? { scale: 0.95 } : undefined}
                          animate={animateVariant}
                          transition={{ duration: 0.42 }}
                          onClick={() => handleSelectOption(item, idx)}
                          className={`btn-shine shadow-sm active:shadow-none w-full text-right px-3.5 py-2.5 rounded-xl border font-bold text-xs sm:text-sm flex items-center justify-between gap-2.5 min-h-[42px] cursor-pointer transition-colors ${btnStyle}`}
                        >
                          <span>{opt}</span>
                          {hasAnswered && isCorrect && (
                            <CheckCircle2 className="w-4 h-4 shrink-0" />
                          )}
                          {hasAnswered && isSelected && !isCorrect && (
                            <XCircle className="w-4 h-4 shrink-0" />
                          )}
                        </motion.button>
                      );
                    })}
                  </div>

                  {hasAnswered && (
                    <div className="flex items-center justify-between pt-1">
                      <span
                        className={`text-xs sm:text-sm font-bold ${
                          selectedOption === item.quizCorrectIndex
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : 'text-rose-600 dark:text-rose-400'
                        }`}
                      >
                        {selectedOption === item.quizCorrectIndex
                          ? 'إجابة صحيحة! زادت نسبة تقدمك.'
                          : 'إجابة غير صحيحة، حاول مرة أخرى.'}
                      </span>
                      <motion.button
                        type="button"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() =>
                          setQuizAnswers((prev) => {
                            const copy = { ...prev };
                            delete copy[item.id];
                            return copy;
                          })
                        }
                        className="inline-flex items-center gap-1 text-xs font-bold text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white cursor-pointer active:shadow-none"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>إعادة</span>
                      </motion.button>
                    </div>
                  )}
                </InteractiveCard>
              );
            })}
          </div>
          {quizItems.length > visibleQuizzesCount && (
            <div ref={quizzesSentinelRef} className="h-8 flex items-center justify-center">
              <span className="text-xs font-bold text-slate-400">جاري تحميل المزيد...</span>
            </div>
          )}
        </section>
      )}
    </div>
  );
}
