import React, { useState } from 'react';
import { Search, Mic, Camera, Bell, ShoppingCart, X, Sparkles } from 'lucide-react';
import { ScreenType } from '../types/ecommerce';

interface TopSearchBarProps {
  onSearch: (query: string) => void;
  searchQuery: string;
  onNavigate: (screen: ScreenType) => void;
  cartCount: number;
}

export const TopSearchBar: React.FC<TopSearchBarProps> = ({
  onSearch,
  searchQuery,
  onNavigate,
  cartCount
}) => {
  const [isVoiceOpen, setIsVoiceOpen] = useState(false);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [voiceTranscript, setVoiceTranscript] = useState('Listening for "Running shoes" or "Smartwatch"...');
  const [isListening, setIsListening] = useState(false);

  const startVoiceSim = () => {
    setIsVoiceOpen(true);
    setIsListening(true);
    setVoiceTranscript('Listening... Speak now');
    setTimeout(() => {
      setVoiceTranscript('Recognized: "Running sneakers"');
      setTimeout(() => {
        onSearch('sneakers');
        setIsVoiceOpen(false);
        setIsListening(false);
        onNavigate('categories');
      }, 1200);
    }, 1500);
  };

  const handleSampleImageSearch = (keyword: string) => {
    onSearch(keyword);
    setIsCameraOpen(false);
    onNavigate('categories');
  };

  return (
    <>
      <header className="sticky top-0 z-30 bg-[#FF6600] text-white px-3 py-2.5 shadow-sm transition-colors">
        <div className="flex items-center gap-2 max-w-full">
          {/* Logo / Brand Wordmark */}
          <button 
            onClick={() => onNavigate('home')}
            className="flex items-center gap-1 font-black text-lg tracking-tight text-white hover:opacity-95 transition-opacity shrink-0"
          >
            <span className="bg-white text-[#FF6600] px-1.5 py-0.5 rounded text-xs font-black tracking-wider shadow-xs">SE</span>
            <span className="tracking-tighter">WORA</span>
            <span className="text-[10px] bg-slate-900/40 px-1 py-0.5 rounded font-black tracking-widest text-yellow-300 ml-0.5 uppercase">MART</span>
          </button>

          {/* Search Input Bar */}
          <div className="relative flex-1 min-w-0">
            <div className="flex items-center bg-white rounded-lg h-9 px-2.5 shadow-inner">
              <Search className="w-4 h-4 text-slate-400 shrink-0" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearch(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    onNavigate('categories');
                  }
                }}
                placeholder="Search deals, brands & items..."
                className="w-full bg-transparent px-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none"
              />
              {searchQuery && (
                <button
                  onClick={() => onSearch('')}
                  className="p-1 text-slate-400 hover:text-slate-600 mr-1"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
              {/* Voice search button */}
              <button
                onClick={startVoiceSim}
                title="Voice Search"
                className="p-1 text-slate-500 hover:text-[#FF6600] transition-colors"
              >
                <Mic className="w-4 h-4" />
              </button>
              {/* Image visual search button */}
              <button
                onClick={() => setIsCameraOpen(true)}
                title="Photo / Visual Search"
                className="p-1 text-slate-500 hover:text-[#FF6600] transition-colors"
              >
                <Camera className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Header Action Icons */}
          <div className="flex items-center gap-1 shrink-0">
            <button 
              onClick={() => alert('Notifications: 3 new flash deals available!')}
              className="p-2 text-white/90 hover:text-white relative rounded-full hover:bg-black/10 transition-colors"
              aria-label="Notifications"
            >
              <Bell className="w-5 h-5" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-yellow-300 rounded-full"></span>
            </button>
            <button
              onClick={() => onNavigate('cart')}
              className="p-2 text-white/90 hover:text-white relative rounded-full hover:bg-black/10 transition-colors"
              aria-label="Cart"
            >
              <ShoppingCart className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-[#0F172A] text-white text-[10px] font-bold h-4 min-w-[16px] px-1 rounded-full flex items-center justify-center border border-white">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Voice Search Modal */}
      {isVoiceOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 max-w-xs w-full text-center shadow-2xl relative">
            <button
              onClick={() => setIsVoiceOpen(false)}
              className="absolute top-3 right-3 text-slate-400 hover:text-slate-600 p-1"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="w-16 h-16 rounded-full bg-orange-100 text-[#FF6600] flex items-center justify-center mx-auto mb-4 animate-pulse">
              <Mic className="w-8 h-8" />
            </div>
            <h3 className="font-bold text-slate-900 text-base mb-1">Sewora Voice Search</h3>
            <p className="text-xs text-slate-500 mb-4">{voiceTranscript}</p>
            <div className="flex justify-center gap-1.5 h-6 items-center">
              <span className={`w-1 bg-[#FF6600] rounded-full transition-all duration-300 ${isListening ? 'h-6' : 'h-2'}`}></span>
              <span className={`w-1 bg-[#FF6600] rounded-full transition-all duration-300 ${isListening ? 'h-8' : 'h-3'}`}></span>
              <span className={`w-1 bg-[#FF6600] rounded-full transition-all duration-300 ${isListening ? 'h-4' : 'h-1.5'}`}></span>
              <span className={`w-1 bg-[#FF6600] rounded-full transition-all duration-300 ${isListening ? 'h-7' : 'h-2'}`}></span>
            </div>
          </div>
        </div>
      )}

      {/* Visual Image Search Modal */}
      {isCameraOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-5 max-w-sm w-full shadow-2xl relative">
            <button
              onClick={() => setIsCameraOpen(false)}
              className="absolute top-3 right-3 text-slate-400 hover:text-slate-600 p-1"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 mb-3">
              <div className="p-2 bg-orange-50 text-[#FF6600] rounded-lg">
                <Camera className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-sm">Visual Search & Lens</h3>
                <p className="text-[11px] text-slate-500">Snap a photo or select an item to match</p>
              </div>
            </div>

            <div className="border-2 border-dashed border-slate-200 rounded-xl p-4 text-center mb-4 bg-slate-50 hover:bg-slate-100/50 transition-colors cursor-pointer">
              <Sparkles className="w-8 h-8 text-[#FF6600] mx-auto mb-2 opacity-80" />
              <p className="text-xs font-medium text-slate-700">Drag & drop product photo or tap camera</p>
              <p className="text-[10px] text-slate-400 mt-0.5">Supports JPG, PNG up to 10MB</p>
            </div>

            <div className="text-xs font-semibold text-slate-700 mb-2">Or try finding matching items:</div>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => handleSampleImageSearch('sneakers')}
                className="flex items-center gap-2 p-2 rounded-lg border border-slate-200 hover:border-[#FF6600] text-left text-xs bg-white hover:bg-orange-50/50 transition-all"
              >
                <span className="text-base">👟</span>
                <div>
                  <div className="font-medium text-slate-800">Running Shoes</div>
                  <div className="text-[10px] text-slate-400">Match fashion</div>
                </div>
              </button>
              <button
                onClick={() => handleSampleImageSearch('smartwatch')}
                className="flex items-center gap-2 p-2 rounded-lg border border-slate-200 hover:border-[#FF6600] text-left text-xs bg-white hover:bg-orange-50/50 transition-all"
              >
                <span className="text-base">⌚</span>
                <div>
                  <div className="font-medium text-slate-800">Smartwatch</div>
                  <div className="text-[10px] text-slate-400">Match gadgets</div>
                </div>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
