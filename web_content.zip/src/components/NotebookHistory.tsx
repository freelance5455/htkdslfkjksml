import React, { useState } from 'react';
import { SavedHistoryItem, ActiveTab } from '../types';
import {
  BookOpen,
  Camera,
  FileText,
  BookMarked,
  SpellCheck,
  Search,
  Trash2,
  Copy,
  CheckCircle2,
  Calendar,
  ExternalLink
} from 'lucide-react';

interface NotebookHistoryProps {
  history: SavedHistoryItem[];
  onClearHistory: () => void;
  onDeleteItem: (id: string) => void;
  setActiveTab: (tab: ActiveTab) => void;
  onSendToGrammar: (text: string) => void;
}

export const NotebookHistory: React.FC<NotebookHistoryProps> = ({
  history,
  onClearHistory,
  onDeleteItem,
  setActiveTab,
  onSendToGrammar,
}) => {
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filtered = history.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(search.toLowerCase()) ||
      item.gradeWhenCreated.toLowerCase().includes(search.toLowerCase());
    const matchesFilter = filterType === 'all' || item.type === filterType;
    return matchesSearch && matchesFilter;
  });

  const getIcon = (type: string) => {
    switch (type) {
      case 'snap-solve':
        return <Camera className="w-4 h-4 text-blue-600" />;
      case 'paragraph':
        return <FileText className="w-4 h-4 text-violet-600" />;
      case 'essay':
        return <BookMarked className="w-4 h-4 text-emerald-600" />;
      case 'grammar':
        return <SpellCheck className="w-4 h-4 text-amber-600" />;
      default:
        return <BookOpen className="w-4 h-4 text-slate-600" />;
    }
  };

  const copyItem = (item: SavedHistoryItem) => {
    let textToCopy = '';
    if (item.type === 'snap-solve') {
      textToCopy = `Direct Answer: ${item.data.directAnswer}\n\nExplanation:\n${item.data.gradeTailoredExplanation}`;
    } else if (item.type === 'paragraph') {
      textToCopy = item.data.paragraph;
    } else if (item.type === 'essay') {
      textToCopy = `${item.data.title}\n\n${item.data.essay}`;
    } else if (item.type === 'grammar') {
      textToCopy = item.data.correctedText;
    }
    navigator.clipboard.writeText(textToCopy);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-bold uppercase tracking-wider mb-2">
            <BookOpen className="w-3.5 h-3.5" />
            Study Notebook
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Saved Homework & Writing
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Review past solutions, generated paragraphs, full essays, and grammar revisions anytime.
          </p>
        </div>

        {history.length > 0 && (
          <button
            onClick={() => {
              if (confirm('Are you sure you want to clear your study notebook?')) {
                onClearHistory();
              }
            }}
            className="text-xs font-bold text-rose-600 hover:text-rose-700 flex items-center gap-1.5 px-3 py-2 rounded-xl border border-rose-200 hover:bg-rose-50 transition self-start sm:self-auto cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" /> Clear All History
          </button>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search saved problems, essays, or topics..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-xs sm:text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-600/30"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          {[
            { id: 'all', label: 'All Items' },
            { id: 'snap-solve', label: 'Snaps' },
            { id: 'paragraph', label: 'Paragraphs' },
            { id: 'essay', label: 'Essays' },
            { id: 'grammar', label: 'Grammar' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterType(tab.id)}
              className={`px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                filterType === tab.id
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* History Items Grid */}
      {filtered.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-2">
          <BookOpen className="w-10 h-10 text-slate-300 mx-auto" />
          <p className="text-sm font-bold text-slate-700">No items match your search</p>
          <p className="text-xs text-slate-400">
            Work you complete in Snap & Solve, Paragraphs, Essays, and Grammar is automatically saved here.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs hover:shadow-md transition flex flex-col justify-between space-y-4"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 text-[11px] font-bold">
                    {getIcon(item.type)}
                    <span className="capitalize">{item.type}</span>
                  </div>
                  <span className="text-[11px] text-slate-400 flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {new Date(item.timestamp).toLocaleDateString()}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-900 line-clamp-1">
                  {item.title}
                </h3>
                <span className="text-[10px] font-semibold text-blue-600 block mb-2">
                  Level: {item.gradeWhenCreated}
                </span>

                {/* Content preview */}
                <div className="p-3 bg-slate-50 rounded-xl text-xs text-slate-600 line-clamp-3 leading-relaxed font-serif">
                  {item.type === 'snap-solve' && (
                    <span>Answer: {item.data.directAnswer}</span>
                  )}
                  {item.type === 'paragraph' && (
                    <span>{item.data.paragraph}</span>
                  )}
                  {item.type === 'essay' && (
                    <span>{item.data.thesisStatement || item.data.essay}</span>
                  )}
                  {item.type === 'grammar' && (
                    <span>Score {item.data.overallScore}/100: {item.data.correctedText}</span>
                  )}
                </div>
              </div>

              {/* Card Footer Actions */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                <button
                  onClick={() => copyItem(item)}
                  className="text-xs font-semibold text-slate-600 hover:text-slate-900 flex items-center gap-1 cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  {copiedId === item.id ? 'Copied!' : 'Copy'}
                </button>

                <div className="flex items-center gap-2">
                  {(item.type === 'paragraph' || item.type === 'essay') && (
                    <button
                      onClick={() => {
                        const content = item.type === 'paragraph' ? item.data.paragraph : item.data.essay;
                        onSendToGrammar(content);
                        setActiveTab('grammar');
                      }}
                      className="text-xs font-bold text-amber-700 hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <SpellCheck className="w-3.5 h-3.5" /> Check
                    </button>
                  )}
                  <button
                    onClick={() => onDeleteItem(item.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 transition"
                    title="Delete item"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
