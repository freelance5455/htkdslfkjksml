import React, { useEffect, useState, useRef } from 'react';
import { X, ExternalLink, ShieldCheck, Play, ArrowRight } from 'lucide-react';

interface InterstitialAdModalProps {
  isOpen: boolean;
  adSlotId?: string; // '3882999054' or '1065264026'
  publisherId?: string; // 'ca-app-pub-9247061906860945'
  onClose: () => void;
  onAdCompleted: () => void;
  title?: string;
}

export const InterstitialAdModal: React.FC<InterstitialAdModalProps> = ({
  isOpen,
  adSlotId = '3882999054',
  publisherId = 'ca-app-pub-9247061906860945',
  onClose,
  onAdCompleted,
  title = 'Your download is preparing...',
}) => {
  const [countdown, setCountdown] = useState(4);
  const [canSkip, setCanSkip] = useState(false);
  const pushedRef = useRef(false);

  useEffect(() => {
    if (!isOpen) {
      setCountdown(4);
      setCanSkip(false);
      pushedRef.current = false;
      return;
    }

    // Try triggering AdSense push
    if (!pushedRef.current) {
      try {
        if (typeof window !== 'undefined') {
          // @ts-expect-error - adsbygoogle is provided by Google
          (window.adsbygoogle = window.adsbygoogle || []).push({});
          pushedRef.current = true;
        }
      } catch {
        // Ignored
      }
    }

    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setCanSkip(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen]);

  if (!isOpen) return null;

  const handleFinish = () => {
    onClose();
    onAdCompleted();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in">
      <div className="bg-slate-900 border-2 border-cyan-500/60 rounded-3xl w-full max-w-lg shadow-2xl shadow-cyan-950/70 overflow-hidden flex flex-col text-slate-100">
        
        {/* Ad Header */}
        <div className="px-5 py-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
            <span className="text-xs font-bold uppercase tracking-wider text-cyan-300">
              Advertisement
            </span>
          </div>

          <div>
            {canSkip ? (
              <button
                onClick={handleFinish}
                className="px-3.5 py-1 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
              >
                <span>Continue to Download</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <span className="text-xs font-semibold text-slate-400 bg-slate-800 px-3 py-1 rounded-lg">
                Ad closes in <strong className="text-white font-bold">{countdown}s</strong>
              </span>
            )}
          </div>
        </div>

        {/* Ad Content Container */}
        <div className="p-5 sm:p-6 text-center space-y-4">
          <p className="text-xs sm:text-sm font-semibold text-slate-300">
            {title}
          </p>

          {/* Real Google AdSense Unit Container */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl min-h-[250px] p-3 flex flex-col items-center justify-center relative overflow-hidden">
            <ins
              className="adsbygoogle block w-full"
              style={{ display: 'block', minHeight: '250px' }}
              data-ad-client={publisherId}
              data-ad-slot={adSlotId}
              data-ad-format="rectangle"
              data-full-width-responsive="true"
            />

            {/* Visual fallback / preview placeholder */}
            <div className="absolute inset-0 -z-10 flex flex-col items-center justify-center p-6 text-center space-y-2 opacity-50 pointer-events-none">
              <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <Play className="w-5 h-5 fill-cyan-400" />
              </div>
              <p className="text-xs font-bold text-slate-200">Google AdMob / AdSense Unit</p>
              <p className="text-[11px] font-mono text-cyan-300">Slot ID: {adSlotId}</p>
              <p className="text-[10px] text-slate-400">Publisher: {publisherId}</p>
            </div>
          </div>

          <p className="text-[11px] text-slate-400">
            Ads support <strong className="text-cyan-400">SL TIK TOK Video</strong> by Saleem Zakhme to keep downloads 100% free.
          </p>
        </div>

        {/* Ad Footer Action */}
        <div className="p-4 bg-slate-950/70 border-t border-slate-800 flex items-center justify-between gap-3">
          <span className="text-[11px] text-slate-500">
            Ad Unit: {adSlotId}
          </span>
          <button
            onClick={handleFinish}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs sm:text-sm font-bold flex items-center gap-1.5 shadow-lg shadow-cyan-500/20 transition cursor-pointer"
          >
            <span>Skip & Download File</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
