import React, { useState } from 'react';
import { Package, Plus, Search, Layers, X, Check } from 'lucide-react';
import { StockItem } from '../types/tally';
import { formatCurrency, formatINR } from '../utils/tallyEngine';
import { triggerHaptic, soundManager } from '../utils/haptics';

interface StockSummaryViewProps {
  stockItems: StockItem[];
  onAddStockItem: (item: StockItem) => void;
}

export const StockSummaryView: React.FC<StockSummaryViewProps> = ({
  stockItems,
  onAddStockItem,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);

  // New item form state
  const [name, setName] = useState<string>('');
  const [category, setCategory] = useState<string>('Hardware');
  const [unit, setUnit] = useState<string>('Pcs');
  const [hsnCode, setHsnCode] = useState<string>('8471');
  const [gstRate, setGstRate] = useState<number>(18);
  const [openingQty, setOpeningQty] = useState<number>(10);
  const [openingRate, setOpeningRate] = useState<number>(1500);
  const [standardSellingRate, setStandardSellingRate] = useState<number>(2200);

  const filteredItems = stockItems.filter(
    (item) =>
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.hsnCode.includes(searchQuery)
  );

  const totalValuation = filteredItems.reduce(
    (sum, item) => sum + item.currentQty * item.openingRate,
    0
  );

  const handleCreateItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    triggerHaptic('success');
    soundManager.playAcceptChime();

    const newItem: StockItem = {
      id: 'item_' + Date.now(),
      name: name.trim(),
      category: category.trim() || 'General',
      unit: unit.trim() || 'Nos',
      hsnCode: hsnCode.trim() || '8471',
      gstRate: Number(gstRate) || 18,
      openingQty: Number(openingQty) || 0,
      openingRate: Number(openingRate) || 0,
      standardSellingRate: Number(standardSellingRate) || 0,
      currentQty: Number(openingQty) || 0,
    };

    onAddStockItem(newItem);
    setIsAddModalOpen(false);
    setName('');
  };

  return (
    <div className="flex-1 flex flex-col pb-8 text-slate-800 dark:text-slate-100">
      {/* Header bar */}
      <div className="bg-emerald-900 text-white px-4 py-3 flex items-center justify-between shadow-xs">
        <div>
          <div className="text-[10px] uppercase font-bold text-emerald-300 tracking-wider">
            Inventory & Warehouse
          </div>
          <h2 className="text-base font-bold">Stock Summary</h2>
        </div>
        <button
          onClick={() => {
            triggerHaptic('light');
            setIsAddModalOpen(true);
          }}
          className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 text-white px-2.5 py-1.5 rounded-lg text-xs font-semibold shadow-xs touch-press"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Item</span>
        </button>
      </div>

      {/* Summary Banner */}
      <div className="p-3 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 space-y-2">
        <div className="flex items-center justify-between text-xs font-mono">
          <span className="text-slate-500">Items Count: {filteredItems.length}</span>
          <span className="font-bold text-slate-900 dark:text-white">
            Total Valuation: <strong className="text-emerald-600 dark:text-emerald-400">{formatCurrency(totalValuation)}</strong>
          </span>
        </div>

        {/* Search input */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search stock item, category, HSN..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs focus:ring-2 focus:ring-emerald-500"
          />
        </div>
      </div>

      {/* Stock Cards List */}
      <div className="p-3 space-y-2.5">
        {filteredItems.map((item) => {
          const itemValuation = item.currentQty * item.openingRate;
          return (
            <div
              key={item.id}
              className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 p-3 shadow-xs space-y-2"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="text-xs font-bold text-slate-900 dark:text-white line-clamp-1">
                    {item.name}
                  </h3>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-2 mt-0.5 font-mono">
                    <span>{item.category}</span>
                    <span>·</span>
                    <span>HSN: {item.hsnCode}</span>
                    <span>·</span>
                    <span>GST: {item.gstRate}%</span>
                  </div>
                </div>

                <span className="text-xs font-mono font-bold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 px-2 py-0.5 rounded-lg shrink-0">
                  {item.currentQty} {item.unit}
                </span>
              </div>

              <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 grid grid-cols-3 gap-1 text-center font-mono text-[11px]">
                <div className="bg-slate-50 dark:bg-slate-800/50 p-1.5 rounded-lg">
                  <div className="text-[10px] text-slate-400 font-sans">Cost Rate</div>
                  <div className="font-semibold">{formatINR(item.openingRate, false)}</div>
                </div>

                <div className="bg-slate-50 dark:bg-slate-800/50 p-1.5 rounded-lg">
                  <div className="text-[10px] text-slate-400 font-sans">Selling Rate</div>
                  <div className="font-semibold text-emerald-600">{formatINR(item.standardSellingRate, false)}</div>
                </div>

                <div className="bg-slate-50 dark:bg-slate-800/50 p-1.5 rounded-lg">
                  <div className="text-[10px] text-slate-400 font-sans">Total Value</div>
                  <div className="font-bold text-slate-900 dark:text-white tabular-nums">
                    {formatINR(itemValuation, false)}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Stock Item Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95">
            <div className="bg-emerald-900 text-white px-4 py-3 flex items-center justify-between">
              <span className="text-xs font-bold">New Stock Item Creation</span>
              <button onClick={() => setIsAddModalOpen(false)}>
                <X className="w-4 h-4 text-emerald-200" />
              </button>
            </div>

            <form onSubmit={handleCreateItem} className="p-4 space-y-3 text-xs">
              <div>
                <label className="block text-[11px] font-medium text-slate-500 mb-1">
                  Item Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Laser Barcode Scanner"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-medium text-slate-500 mb-1">
                    Category
                  </label>
                  <input
                    type="text"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-500 mb-1">
                    Unit (e.g. Pcs, Box, Nos)
                  </label>
                  <input
                    type="text"
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 font-mono">
                <div>
                  <label className="block text-[11px] font-sans font-medium text-slate-500 mb-1">
                    HSN Code
                  </label>
                  <input
                    type="text"
                    value={hsnCode}
                    onChange={(e) => setHsnCode(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-sans font-medium text-slate-500 mb-1">
                    GST Rate (%)
                  </label>
                  <select
                    value={gstRate}
                    onChange={(e) => setGstRate(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                  >
                    <option value={0}>0%</option>
                    <option value={5}>5%</option>
                    <option value={12}>12%</option>
                    <option value={18}>18%</option>
                    <option value={28}>28%</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 font-mono">
                <div>
                  <label className="block text-[10px] font-sans font-medium text-slate-500 mb-1">
                    Opening Qty
                  </label>
                  <input
                    type="number"
                    value={openingQty}
                    onChange={(e) => setOpeningQty(Number(e.target.value))}
                    className="w-full px-2 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-center"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-sans font-medium text-slate-500 mb-1">
                    Cost Rate (₹)
                  </label>
                  <input
                    type="number"
                    value={openingRate}
                    onChange={(e) => setOpeningRate(Number(e.target.value))}
                    className="w-full px-2 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-center"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-sans font-medium text-slate-500 mb-1">
                    Selling (₹)
                  </label>
                  <input
                    type="number"
                    value={standardSellingRate}
                    onChange={(e) => setStandardSellingRate(Number(e.target.value))}
                    className="w-full px-2 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-center font-bold text-emerald-600"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl bg-emerald-600 text-white font-bold shadow-xs hover:bg-emerald-500"
                >
                  Save Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
