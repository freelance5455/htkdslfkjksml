import React from 'react';
import {
  X,
  TrendingUp,
  Fuel,
  Users,
  Compass,
  Globe2,
  Award,
  DollarSign,
  Plane as PlaneIcon,
  Flame,
  ArrowRightLeft,
  Star
} from 'lucide-react';
import {
  GameState,
  CITY_MAP,
  calculateAirlineRating,
  RouteStat,
  INITIAL_CITIES
} from '../game/flightLogic';
import { signInWithGoogle, signOutUser } from '../game/firebase';
import { sound } from '../game/sound';

interface AnalyticsDrawerProps {
  gameState: GameState;
  onClose: () => void;
  onGoogleSignInSuccess?: (user: { uid: string; email: string | null; displayName: string | null; photoURL: string | null }) => void;
  onGoogleSignOutSuccess?: () => void;
}

export const AnalyticsDrawer: React.FC<AnalyticsDrawerProps> = ({
  gameState,
  onClose,
  onGoogleSignInSuccess,
  onGoogleSignOutSuccess
}) => {
  const rating = calculateAirlineRating(gameState);

  const totalFlightsCompleted = gameState.planes.reduce(
    (acc, p) => acc + p.totalFlightsCompleted,
    0
  );

  const grossRevenue = gameState.totalEarned + (gameState.totalFuelCost || 0);
  const fuelExpense = gameState.totalFuelCost || 0;
  const netProfit = gameState.totalEarned;
  const operatingMargin = grossRevenue > 0 ? (netProfit / grossRevenue) * 100 : 100;

  // Earth circumference is ~40,075 km
  const earthCircuits = ((gameState.totalDistanceFlownKm || 0) / 40075).toFixed(1);

  // Sorted Route Leaderboard by net profit or flights
  const routeEntries = Object.entries(gameState.routeStats || {}).sort(
    (a, b) => b[1].netProfit - a[1].netProfit
  );

  const handleSignIn = async () => {
    try {
      sound.playClick();
      const user = await signInWithGoogle();
      if (user && onGoogleSignInSuccess) {
        onGoogleSignInSuccess({
          uid: user.uid,
          email: user.email,
          displayName: user.displayName,
          photoURL: user.photoURL
        });
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleSignOut = async () => {
    try {
      sound.playClick();
      await signOutUser();
      if (onGoogleSignOutSuccess) {
        onGoogleSignOutSuccess();
      }
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div
      className="fixed inset-y-0 right-0 z-40 w-full max-w-lg bg-[#0a0b10] border-l border-[#27272a] shadow-2xl flex flex-col text-white animate-in slide-in-from-right duration-200"
      data-testid="analytics-drawer"
    >
      {/* Drawer Header */}
      <div className="p-5 border-b border-[#27272a]">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-white text-black flex items-center justify-center font-bold text-sm shadow">
              <TrendingUp size={20} />
            </div>
            <div>
              <h2 className="font-mono text-base font-bold tracking-tight">OPERATIONS & ANALYTICS</h2>
              <p className="text-xs text-[#a1a1aa] font-mono mt-0.5">
                {gameState.airlineName || 'Global Airways'} · Flight Telemetry
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close Analytics Panel"
            className="p-1.5 text-[#a1a1aa] hover:text-white hover:bg-[#18181b] rounded-lg transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Airline Prestige Rating Banner */}
        <div className="mt-4 p-3.5 rounded-xl bg-[#12131c] border border-[#27272a] flex items-center justify-between">
          <div>
            <div className="flex items-center gap-1.5 text-amber-400">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  size={14}
                  className={i < Math.floor(rating.stars) ? 'fill-amber-400 text-amber-400' : 'text-[#3f3f46]'}
                />
              ))}
              <span className="text-xs font-mono font-bold text-white ml-1">
                {rating.stars.toFixed(1)} / 5.0
              </span>
            </div>
            <div className="text-xs font-mono font-semibold text-[#e4e4e7] mt-1">
              {rating.title}
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] font-mono uppercase tracking-wider text-[#71717a] block">
              CONTINENTAL COVERAGE
            </span>
            <span className="text-xs font-mono font-bold text-white">
              {rating.continentsCount} / 7 Continents
            </span>
          </div>
        </div>
      </div>

      {/* Scrollable Analytics Body */}
      <div className="flex-1 overflow-y-auto p-5 pb-24 space-y-5">
        {/* Financial KPI Grid */}
        <div>
          <div className="flex items-center justify-between mb-2.5">
            <h3 className="font-mono text-xs font-bold text-[#a1a1aa] tracking-wider uppercase flex items-center gap-1.5">
              <DollarSign size={13} className="text-emerald-400" />
              FINANCIAL METRICS
            </h3>
            <span className="text-[11px] font-mono text-[#71717a]">
              Margin: {operatingMargin.toFixed(1)}%
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2.5 font-mono">
            <div className="p-3 bg-[#11121a] border border-[#27272a] rounded-xl">
              <span className="text-[10px] text-[#71717a] block uppercase font-medium">Gross Fares</span>
              <span className="text-base font-bold text-white tabular-nums">
                ${grossRevenue.toLocaleString()}
              </span>
              <span className="text-[10px] text-[#a1a1aa] block mt-0.5">Ticket revenue</span>
            </div>

            <div className="p-3 bg-[#11121a] border border-[#27272a] rounded-xl">
              <span className="text-[10px] text-[#71717a] block uppercase font-medium flex items-center gap-1">
                <Fuel size={11} className="text-amber-400" /> Jet Fuel Burn
              </span>
              <span className="text-base font-bold text-amber-300 tabular-nums">
                -${fuelExpense.toLocaleString()}
              </span>
              <span className="text-[10px] text-[#a1a1aa] block mt-0.5">Operational expense</span>
            </div>

            <div className="p-3 bg-[#11121a] border border-[#27272a] rounded-xl">
              <span className="text-[10px] text-[#71717a] block uppercase font-medium">Net Profit</span>
              <span className="text-base font-bold text-emerald-400 tabular-nums">
                ${netProfit.toLocaleString()}
              </span>
              <span className="text-[10px] text-[#a1a1aa] block mt-0.5">Post-fuel earnings</span>
            </div>

            <div className="p-3 bg-[#11121a] border border-[#27272a] rounded-xl">
              <span className="text-[10px] text-[#71717a] block uppercase font-medium">Treasury Cash</span>
              <span className="text-base font-bold text-white tabular-nums">
                ${gameState.cash.toLocaleString()}
              </span>
              <span className="text-[10px] text-[#a1a1aa] block mt-0.5">Liquid balance</span>
            </div>
          </div>
        </div>

        {/* Operational Volume KPI Grid */}
        <div>
          <h3 className="font-mono text-xs font-bold text-[#a1a1aa] tracking-wider uppercase mb-2.5 flex items-center gap-1.5">
            <Compass size={13} className="text-sky-400" />
            FLIGHT OPERATIONS
          </h3>

          <div className="grid grid-cols-2 gap-2.5 font-mono">
            <div className="p-3 bg-[#11121a] border border-[#27272a] rounded-xl">
              <span className="text-[10px] text-[#71717a] block uppercase font-medium flex items-center gap-1">
                <Users size={11} className="text-sky-400" /> Passengers
              </span>
              <span className="text-base font-bold text-white tabular-nums">
                {(gameState.totalPassengersCarried || 0).toLocaleString()}
              </span>
              <span className="text-[10px] text-[#a1a1aa] block mt-0.5">Seats occupied</span>
            </div>

            <div className="p-3 bg-[#11121a] border border-[#27272a] rounded-xl">
              <span className="text-[10px] text-[#71717a] block uppercase font-medium flex items-center gap-1">
                <Globe2 size={11} className="text-sky-400" /> Distance Flown
              </span>
              <span className="text-base font-bold text-white tabular-nums">
                {(gameState.totalDistanceFlownKm || 0).toLocaleString()} km
              </span>
              <span className="text-[10px] text-[#a1a1aa] block mt-0.5">
                ≈ {earthCircuits}x Earth orbits
              </span>
            </div>

            <div className="p-3 bg-[#11121a] border border-[#27272a] rounded-xl">
              <span className="text-[10px] text-[#71717a] block uppercase font-medium">Flights Dispatched</span>
              <span className="text-base font-bold text-white tabular-nums">
                {totalFlightsCompleted.toLocaleString()}
              </span>
              <span className="text-[10px] text-[#a1a1aa] block mt-0.5">Legs completed</span>
            </div>

            <div className="p-3 bg-[#11121a] border border-[#27272a] rounded-xl">
              <span className="text-[10px] text-[#71717a] block uppercase font-medium">Fleet Size</span>
              <span className="text-base font-bold text-white tabular-nums">
                {gameState.planes.length} Aircraft
              </span>
              <span className="text-[10px] text-[#a1a1aa] block mt-0.5">Active airframes</span>
            </div>
          </div>
        </div>

        {/* Global Jet Fuel Market & Environmental Factor */}
        <div className="p-4 rounded-xl bg-[#12131c] border border-[#27272a] space-y-2 font-mono">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white flex items-center gap-1.5">
              <Fuel size={14} className="text-amber-400" /> GLOBAL JET FUEL INDEX
            </span>
            <span className="text-xs font-bold text-amber-300">
              {(gameState.fuelMarketIndex || 1.0).toFixed(2)}x Market
            </span>
          </div>
          <p className="text-[11px] text-[#a1a1aa] leading-relaxed">
            Real-world long-haul transoceanic routes burn more aviation kerosene per flight. Upgrading aircraft capacity and airport terminals offsets fuel burn with higher yields.
          </p>
        </div>

        {/* Route Performance Leaderboard */}
        <div>
          <div className="flex items-center justify-between mb-2.5">
            <h3 className="font-mono text-xs font-bold text-[#a1a1aa] tracking-wider uppercase flex items-center gap-1.5">
              <ArrowRightLeft size={13} className="text-white" />
              ROUTE PERFORMANCE LEADERBOARD
            </h3>
            <span className="text-[11px] font-mono text-[#71717a]">
              {routeEntries.length} Tracked Corridors
            </span>
          </div>

          {routeEntries.length === 0 ? (
            <div className="p-4 rounded-xl bg-[#101117] border border-[#27272a] text-center text-xs text-[#71717a] font-mono">
              Flight corridors will record profitability data here as your fleet completes flights.
            </div>
          ) : (
            <div className="space-y-2">
              {routeEntries.slice(0, 8).map(([key, stat]) => {
                const [fromId, toId] = key.split('-');
                const fromCity = CITY_MAP.get(fromId);
                const toCity = CITY_MAP.get(toId);

                return (
                  <div
                    key={key}
                    className="p-3 bg-[#111219] border border-[#27272a] rounded-xl flex items-center justify-between text-xs font-mono"
                  >
                    <div>
                      <div className="flex items-center gap-1.5 font-bold text-white">
                        <span>{fromCity?.code || fromId}</span>
                        <span className="text-[#71717a]">⇄</span>
                        <span>{toCity?.code || toId}</span>
                        <span className="text-[11px] font-normal text-[#71717a] ml-1">
                          ({stat.distanceKm} km)
                        </span>
                      </div>
                      <div className="text-[10px] text-[#a1a1aa] mt-0.5">
                        {stat.flights} flights · {stat.passengers} passengers
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-emerald-400 font-bold tabular-nums">
                        +${stat.netProfit.toLocaleString()}
                      </div>
                      <div className="text-[10px] text-amber-300 tabular-nums">
                        -${stat.fuelCost.toLocaleString()} fuel
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Pilot Account & Cloud Sync Status */}
        <div className="p-4 rounded-xl bg-[#0f1017] border border-[#27272a] space-y-3 font-mono">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white flex items-center gap-1.5">
              <Award size={14} className="text-white" /> PILOT PROFILE & CLOUD SYNC
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950/70 border border-emerald-800/60 text-emerald-300">
              FIREBASE SECURED
            </span>
          </div>

          {gameState.userId ? (
            <div className="flex items-center justify-between pt-1">
              <div className="flex items-center gap-2.5">
                {gameState.userAvatar ? (
                  <img
                    src={gameState.userAvatar}
                    alt={gameState.userEmail || 'User'}
                    className="w-8 h-8 rounded-full border border-white/20"
                  />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-white text-black font-bold flex items-center justify-center text-xs">
                    {(gameState.userEmail || 'U')[0].toUpperCase()}
                  </div>
                )}
                <div>
                  <div className="text-xs font-bold text-white">
                    {gameState.userEmail || 'Google Pilot'}
                  </div>
                  <div className="text-[10px] text-emerald-400">Cloud Sync Enabled</div>
                </div>
              </div>

              <button
                onClick={handleSignOut}
                className="px-3 py-1.5 bg-[#181924] hover:bg-[#232435] text-xs text-[#a1a1aa] hover:text-white rounded-lg border border-[#27272a] transition-colors cursor-pointer"
              >
                Sign Out
              </button>
            </div>
          ) : (
            <div className="space-y-2 pt-1">
              <p className="text-[11px] text-[#a1a1aa] leading-relaxed">
                Sign in with Google to backup your airline progress, fleet upgrades, and unlocked liveries to Cloud Firestore.
              </p>
              <button
                onClick={handleSignIn}
                className="w-full py-2 px-3 bg-white hover:bg-[#e4e4e7] text-black font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Sign in with Google</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
