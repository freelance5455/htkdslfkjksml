import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type ChangeEvent,
  type ClipboardEvent,
  type DragEvent,
  type FormEvent,
} from 'react';
import { CheckCircle2, FileText, Image as ImageIcon, Loader2, RotateCw, Upload, X } from 'lucide-react';
import type { Worker } from '../types/attendance';
import { parseBulkWorkersText } from '../utils/attendanceLogic';
import {
  MAX_IMPORT_FILE_BYTES,
  formatExtractionError,
  formatFileSize,
  isImageImportMimeType,
  resolveImportMimeType,
} from '../utils/workerExtraction';

interface BulkImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (workers: Worker[], mode: 'append' | 'replace') => void;
}

const SAMPLE_PLACEHOLDER = `WRK-201, Arjun Mandi, Welder
WRK-202, Gopal Hansda, Fitter
WRK-203, Mohan Soren, Mason`;

interface SelectedFileMeta {
  name: string;
  size: number;
  mimeType: string;
  previewUrl?: string;
}

function readFileAsBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = typeof reader.result === 'string' ? reader.result : '';
      const commaIdx = result.indexOf(',');
      resolve(commaIdx !== -1 ? result.slice(commaIdx + 1) : result);
    };
    reader.onerror = () => reject(new Error('Could not read the selected file.'));
    reader.readAsDataURL(file);
  });
}

export function BulkImportModal({ isOpen, onClose, onImport }: BulkImportModalProps) {
  const [rawText, setRawText] = useState('');
  const [mode, setMode] = useState<'append' | 'replace'>('append');
  const [submitError, setSubmitError] = useState('');
  const [fileError, setFileError] = useState('');
  const [fileNotice, setFileNotice] = useState('');
  const [isExtracting, setIsExtracting] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<SelectedFileMeta | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const lastFileRef = useRef<File | null>(null);

  const clearPreviewUrl = (meta: SelectedFileMeta | null) => {
    if (meta?.previewUrl) {
      URL.revokeObjectURL(meta.previewUrl);
    }
  };

  useEffect(() => {
    if (isOpen) {
      setRawText('');
      setMode('append');
      setSubmitError('');
      setFileError('');
      setFileNotice('');
      setIsExtracting(false);
      setIsDragging(false);
      lastFileRef.current = null;
      setSelectedFile((prev) => {
        clearPreviewUrl(prev);
        return null;
      });
    } else {
      abortControllerRef.current?.abort();
    }
  }, [isOpen]);

  useEffect(() => {
    return () => {
      abortControllerRef.current?.abort();
    };
  }, []);

  const parsed = useMemo(() => parseBulkWorkersText(rawText), [rawText]);

  if (!isOpen) {
    return null;
  }

  const processImportFile = async (file: File) => {
    setFileError('');
    setFileNotice('');
    setSubmitError('');

    const resolvedMime = resolveImportMimeType(file.name, file.type);
    if (!resolvedMime) {
      setFileError(
        'Unsupported file format. Please choose a PDF, JPG, PNG screenshot, WebP, or CSV/TXT file.',
      );
      return;
    }

    if (file.size === 0) {
      setFileError('The selected file is empty.');
      return;
    }

    if (file.size > MAX_IMPORT_FILE_BYTES) {
      setFileError('File is too large. Please select a file under 15 MB.');
      return;
    }

    abortControllerRef.current?.abort();
    const controller = new AbortController();
    abortControllerRef.current = controller;
    lastFileRef.current = file;

    const previewUrl = isImageImportMimeType(resolvedMime) ? URL.createObjectURL(file) : undefined;
    const displayName = file.name?.trim() || 'pasted-screenshot.png';

    setSelectedFile((prev) => {
      clearPreviewUrl(prev);
      return {
        name: displayName,
        size: file.size,
        mimeType: resolvedMime,
        previewUrl,
      };
    });
    setIsExtracting(true);

    try {
      const dataBase64 = await readFileAsBase64(file);
      const response = await fetch('/api/workers/extract-from-file', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          fileName: displayName,
          mimeType: resolvedMime,
          dataBase64,
        }),
      });

      const payload = (await response.json().catch(() => ({}))) as {
        rawText?: string;
        workers?: Worker[];
        sourceType?: string;
        error?: string;
      };

      if (!response.ok) {
        const formatted = formatExtractionError(payload.error || 'Could not extract workers from this file.');
        throw new Error(formatted.message);
      }

      const extractedText = (payload.rawText ?? '').trim();
      if (!extractedText) {
        throw new Error('No workers could be extracted from this file.');
      }

      setRawText(extractedText);
      const count = Array.isArray(payload.workers) && payload.workers.length > 0
        ? payload.workers.length
        : parseBulkWorkersText(extractedText).workers.length;

      setFileNotice(
        count > 0
          ? `Extracted ${count} ${count === 1 ? 'worker' : 'workers'} from ${displayName}. Review or edit below before importing.`
          : `Loaded ${displayName}. Review the lines below before importing.`,
      );
    } catch (error) {
      if (error instanceof DOMException && error.name === 'AbortError') {
        return;
      }
      setFileError(formatExtractionError(error).message);
    } finally {
      if (abortControllerRef.current === controller) {
        setIsExtracting(false);
      }
    }
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (file) {
      void processImportFile(file);
    }
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      void processImportFile(file);
    }
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isDragging) {
      setIsDragging(true);
    }
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleModalPaste = (e: ClipboardEvent<HTMLDivElement>) => {
    const items = e.clipboardData?.items;
    if (!items) return;

    for (let i = 0; i < items.length; i += 1) {
      const item = items[i];
      if (item.kind === 'file' && item.type.startsWith('image/')) {
        const pastedFile = item.getAsFile();
        if (pastedFile) {
          e.preventDefault();
          const ext = item.type.split('/')[1]?.replace(/[^a-z0-9]/gi, '') || 'png';
          const namedFile =
            pastedFile.name && pastedFile.name !== 'image.png'
              ? pastedFile
              : new File([pastedFile], `screenshot-${Date.now()}.${ext}`, {
                  type: item.type || 'image/png',
                });
          void processImportFile(namedFile);
          return;
        }
      }
    }
  };

  const handleClearFile = () => {
    abortControllerRef.current?.abort();
    lastFileRef.current = null;
    setIsExtracting(false);
    setFileError('');
    setFileNotice('');
    setSelectedFile((prev) => {
      clearPreviewUrl(prev);
      return null;
    });
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (isExtracting) {
      return;
    }
    if (parsed.workers.length === 0) {
      setSubmitError('Upload a PDF/image/screenshot or paste at least one valid line in "ID, Name, Role" format.');
      return;
    }
    onImport(parsed.workers, mode);
    onClose();
  };

  const isPdfSelected = selectedFile?.mimeType === 'application/pdf';

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-900/50 backdrop-blur-xs p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="bulk-import-modal-title"
      onPaste={handleModalPaste}
    >
      <div className="w-full sm:max-w-lg bg-white rounded-t-3xl sm:rounded-2xl shadow-xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 shrink-0">
          <h2 id="bulk-import-modal-title" className="text-lg font-semibold text-slate-900">
            Bulk Import Workers
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close bulk import modal"
            className="min-w-[44px] min-h-[44px] -mr-2 flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto">
          <div>
            <span className="block text-sm font-medium text-slate-700 mb-1.5">
              Import from File (PDF, JPG, Screenshot)
            </span>
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,.jpg,.jpeg,.png,.webp,.heic,.heif,.csv,.txt,application/pdf,image/*"
              onChange={handleFileChange}
              className="sr-only"
              aria-label="Choose PDF, JPG, or screenshot file to extract workers"
            />
            <div
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              className={`rounded-xl border-2 border-dashed p-3.5 transition-colors ${
                isDragging
                  ? 'border-blue-500 bg-blue-50/70'
                  : 'border-slate-300 bg-slate-50/70 hover:border-slate-400'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-slate-800">
                    Upload PDF, JPG, or Screenshot
                  </p>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Drop a file here, browse, or press Ctrl+V to paste a screenshot
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isExtracting}
                  className="min-h-[44px] px-3.5 py-2 inline-flex items-center justify-center gap-2 text-sm font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-xl transition-colors shrink-0 disabled:opacity-60"
                >
                  {isExtracting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Extracting...</span>
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4" />
                      <span>Choose File</span>
                    </>
                  )}
                </button>
              </div>

              {selectedFile && (
                <div className="mt-3 pt-2.5 border-t border-slate-200/80 flex items-center justify-between gap-2.5">
                  <div className="flex items-center gap-2.5 min-w-0">
                    {selectedFile.previewUrl ? (
                      <img
                        src={selectedFile.previewUrl}
                        alt={selectedFile.name}
                        className="w-9 h-9 rounded-lg object-cover border border-slate-200 shrink-0"
                      />
                    ) : (
                      <div className="w-9 h-9 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-600 shrink-0">
                        {isPdfSelected ? (
                          <FileText className="w-4 h-4 text-rose-600" />
                        ) : isImageImportMimeType(selectedFile.mimeType) ? (
                          <ImageIcon className="w-4 h-4 text-blue-600" />
                        ) : (
                          <FileText className="w-4 h-4 text-slate-600" />
                        )}
                      </div>
                    )}
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-slate-800 truncate">
                        {selectedFile.name}
                      </p>
                      <p className="text-[11px] text-slate-500 tabular-nums">
                        {formatFileSize(selectedFile.size)}
                        {isExtracting ? ' · Reading workers...' : ''}
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleClearFile}
                    aria-label="Remove selected file"
                    className="min-w-[36px] min-h-[36px] flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/70 transition-colors shrink-0"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>

            {fileNotice && (
              <p
                role="status"
                className="mt-2 flex items-start gap-2 text-xs font-medium text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-xl px-3 py-2"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>{fileNotice}</span>
              </p>
            )}

            {fileError && (
              <div
                role="alert"
                className="mt-2 flex items-center justify-between gap-2.5 text-xs font-medium text-rose-700 bg-rose-50 border border-rose-200 rounded-xl px-3 py-2"
              >
                <span>{fileError}</span>
                {lastFileRef.current && !isExtracting && (
                  <button
                    type="button"
                    onClick={() => {
                      if (lastFileRef.current) {
                        void processImportFile(lastFileRef.current);
                      }
                    }}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white text-rose-700 border border-rose-200 hover:bg-rose-100 font-semibold shrink-0 transition-colors"
                  >
                    <RotateCw className="w-3.5 h-3.5" />
                    <span>Retry</span>
                  </button>
                )}
              </div>
            )}
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label htmlFor="bulk-workers-textarea" className="block text-sm font-medium text-slate-700">
                Paste or Review Workers (ID, Name, Role)
              </label>
              <button
                type="button"
                onClick={() => {
                  setRawText(SAMPLE_PLACEHOLDER);
                  setSubmitError('');
                  setFileError('');
                  setFileNotice('');
                }}
                className="text-xs font-medium text-blue-600 hover:text-blue-700 hover:underline shrink-0 whitespace-nowrap"
              >
                Insert Example
              </button>
            </div>
            <textarea
              id="bulk-workers-textarea"
              rows={5}
              value={rawText}
              onChange={(e) => {
                setRawText(e.target.value);
                if (submitError) setSubmitError('');
              }}
              placeholder={SAMPLE_PLACEHOLDER}
              autoFocus
              className="w-full px-3.5 py-2.5 text-sm font-mono text-slate-900 bg-slate-50/70 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600 focus:bg-white"
            />
            <p className="mt-1.5 text-xs text-slate-500">
              One worker per line: <span className="font-mono text-slate-700">Worker ID, Full Name, Role</span>
            </p>
          </div>

          <fieldset>
            <legend className="text-sm font-medium text-slate-700 mb-2">Import Mode</legend>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <label
                className={`flex items-start gap-2.5 p-3 rounded-xl border cursor-pointer transition-colors ${
                  mode === 'append'
                    ? 'border-blue-600 bg-blue-50/60'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <input
                  type="radio"
                  name="import-mode"
                  value="append"
                  checked={mode === 'append'}
                  onChange={() => setMode('append')}
                  className="mt-0.5 accent-blue-600"
                />
                <div>
                  <span className="block text-sm font-semibold text-slate-900">Append to roster</span>
                  <span className="block text-xs text-slate-500">Adds new workers and updates matching IDs</span>
                </div>
              </label>

              <label
                className={`flex items-start gap-2.5 p-3 rounded-xl border cursor-pointer transition-colors ${
                  mode === 'replace'
                    ? 'border-blue-600 bg-blue-50/60'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <input
                  type="radio"
                  name="import-mode"
                  value="replace"
                  checked={mode === 'replace'}
                  onChange={() => setMode('replace')}
                  className="mt-0.5 accent-blue-600"
                />
                <div>
                  <span className="block text-sm font-semibold text-slate-900">Replace roster</span>
                  <span className="block text-xs text-slate-500">Replaces current list with imported workers</span>
                </div>
              </label>
            </div>
          </fieldset>

          {rawText.trim() && (
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs space-y-1.5">
              <div className="flex items-center justify-between font-medium">
                <span className="text-emerald-700 tabular-nums">
                  {parsed.workers.length} valid {parsed.workers.length === 1 ? 'worker' : 'workers'} ready
                </span>
                {parsed.errors.length > 0 && (
                  <span className="text-rose-600 tabular-nums">
                    {parsed.errors.length} {parsed.errors.length === 1 ? 'issue' : 'issues'}
                  </span>
                )}
              </div>
              {parsed.errors.length > 0 && (
                <ul className="space-y-1 text-rose-600 max-h-24 overflow-y-auto pt-1 border-t border-slate-200">
                  {parsed.errors.map((err) => (
                    <li key={`${err.lineNumber}-${err.raw}`}>
                      Line {err.lineNumber}: {err.reason}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}

          {submitError && (
            <p role="alert" className="text-sm font-medium text-rose-600 bg-rose-50 border border-rose-200 rounded-xl px-3.5 py-2">
              {submitError}
            </p>
          )}

          <div className="flex items-center justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[44px] px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isExtracting}
              className="min-h-[44px] px-5 py-2 text-sm font-semibold text-white bg-[#2563EB] hover:bg-[#1D4ED8] rounded-xl shadow-xs transition-colors disabled:opacity-60"
            >
              {isExtracting
                ? 'Extracting...'
                : `Import ${parsed.workers.length > 0 ? `(${parsed.workers.length})` : 'Workers'}`}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
