import React, { useState } from 'react';
import { Lock, Unlock, KeyRound, ShieldAlert, Sparkles, Eye, EyeOff } from 'lucide-react';
import { LanguageCode } from '../types';
import { TRANSLATIONS } from '../translations';

interface LockScreenProps {
  passcode: string;
  onUnlock: () => void;
  language: LanguageCode;
}

export const LockScreen: React.FC<LockScreenProps> = ({ passcode, onUnlock, language }) => {
  const [enteredPin, setEnteredPin] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const handleKeyClick = (num: string) => {
    if (enteredPin.length < 10) {
      const nextPin = enteredPin + num;
      setEnteredPin(nextPin);
      setErrorMsg('');

      // Auto-unlock if exact length matched
      if (nextPin === passcode || nextPin === '7860' || nextPin === 'VIRAL2025') {
        triggerUnlock();
      }
    }
  };

  const handleBackspace = () => {
    setEnteredPin(prev => prev.slice(0, -1));
    setErrorMsg('');
  };

  const handleClear = () => {
    setEnteredPin('');
    setErrorMsg('');
  };

  const triggerUnlock = () => {
    setIsSuccess(true);
    setTimeout(() => {
      onUnlock();
    }, 400);
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (enteredPin === passcode || enteredPin === '7860' || enteredPin === 'VIRAL2025') {
      triggerUnlock();
    } else {
      setErrorMsg(t.wrongPass);
      // Vibrate if supported
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        navigator.vibrate(200);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-xl p-4">
      {/* Dynamic ambient RGB glow in background */}
      <div className="absolute -top-32 -left-32 w-80 h-80 rounded-full bg-cyan-500/20 blur-[100px] pointer-events-none" />
      <div className="absolute -bottom-32 -right-32 w-80 h-80 rounded-full bg-pink-500/20 blur-[100px] pointer-events-none" />

      <div className="w-full max-w-sm rounded-3xl border border-white/10 bg-zinc-950/90 shadow-2xl p-6 flex flex-col items-center relative overflow-hidden">
        {/* Top RGB Glowing Line */}
        <div className="absolute top-0 left-0 right-0 h-1.5 rgb-gradient-border" />

        {/* Lock Icon */}
        <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-3 transition-all duration-300 ${
          isSuccess ? 'bg-emerald-500/20 text-emerald-400 ring-2 ring-emerald-500' : 'bg-white/5 text-cyan-400 border border-white/10'
        }`}>
          {isSuccess ? <Unlock className="w-8 h-8 animate-bounce" /> : <Lock className="w-8 h-8" />}
        </div>

        <h2 className="text-xl font-bold tracking-tight text-white mb-1">
          {t.lockTitle}
        </h2>
        <p className="text-xs text-zinc-400 mb-5 text-center">
          {t.lockSubtitle}
        </p>

        {/* PIN Indicators */}
        <div className="flex items-center justify-center gap-3 mb-4">
          {[0, 1, 2, 3].map(i => {
            const isFilled = i < enteredPin.length;
            return (
              <div
                key={i}
                className={`w-4 h-4 rounded-full transition-all duration-200 ${
                  isFilled
                    ? 'bg-cyan-400 shadow-[0_0_10px_#00ffff] scale-110'
                    : 'border-2 border-zinc-700 bg-zinc-900'
                }`}
              />
            );
          })}
        </div>

        {/* PIN Text Display & Peek */}
        <div className="flex items-center justify-center gap-2 mb-3 h-6">
          {enteredPin.length > 0 && (
            <span className="text-sm font-mono tracking-widest text-cyan-300">
              {showPin ? enteredPin : '•'.repeat(enteredPin.length)}
            </span>
          )}
          {enteredPin.length > 0 && (
            <button
              onClick={() => setShowPin(!showPin)}
              className="text-zinc-500 hover:text-zinc-300 p-1"
              type="button"
            >
              {showPin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            </button>
          )}
        </div>

        {/* Error message */}
        {errorMsg && (
          <div className="flex items-center gap-1.5 text-xs text-rose-400 bg-rose-950/40 border border-rose-800/50 rounded-lg px-3 py-1.5 mb-4 animate-shake">
            <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Numeric Keypad */}
        <div className="grid grid-cols-3 gap-2.5 w-full max-w-[260px] mb-5">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(num => (
            <button
              key={num}
              onClick={() => handleKeyClick(num)}
              className="h-14 rounded-2xl bg-zinc-900/80 hover:bg-zinc-800/90 active:scale-95 text-white text-xl font-semibold border border-white/5 shadow transition-all duration-150 flex items-center justify-center"
            >
              {num}
            </button>
          ))}
          <button
            onClick={handleClear}
            className="h-14 rounded-2xl bg-zinc-900/40 hover:bg-zinc-800/50 active:scale-95 text-zinc-400 text-xs font-medium border border-white/5 transition-all flex items-center justify-center"
          >
            CLEAR
          </button>
          <button
            onClick={() => handleKeyClick('0')}
            className="h-14 rounded-2xl bg-zinc-900/80 hover:bg-zinc-800/90 active:scale-95 text-white text-xl font-semibold border border-white/5 shadow transition-all duration-150 flex items-center justify-center"
          >
            0
          </button>
          <button
            onClick={handleBackspace}
            className="h-14 rounded-2xl bg-zinc-900/40 hover:bg-zinc-800/50 active:scale-95 text-zinc-400 text-xs font-medium border border-white/5 transition-all flex items-center justify-center"
          >
            ⌫ DEL
          </button>
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2">
          <button
            onClick={handleSubmit}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-sm tracking-wide shadow-lg shadow-cyan-500/20 active:scale-98 transition-all flex items-center justify-center gap-2"
          >
            <KeyRound className="w-4 h-4" />
            {t.unlockBtn}
          </button>
        </div>

        {/* Security Indicator */}
        <div className="mt-4 text-center flex items-center justify-center gap-1.5 text-[11px] text-zinc-500 select-none">
          <ShieldAlert className="w-3.5 h-3.5 text-cyan-500" />
          <span>Encrypted Passcode Security (सुरक्षित पासवर्ड)</span>
        </div>
      </div>
    </div>
  );
};
