import React, { useEffect } from 'react';
import { X, Download } from 'lucide-react';

interface Props {
  photo: {
    url: string;
    caption: string;
    title: string;
    tag?: string;
  } | null;
  onClose: () => void;
}

export const PhotoLightbox: React.FC<Props> = ({ photo, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!photo) return null;

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = photo.url;
    link.download = `foto_${Date.now()}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div
      className="fixed inset-0 z-60 bg-black/90 backdrop-blur-md flex flex-col justify-between p-4 sm:p-6"
      onClick={onClose}
    >
      {/* Top Header Bar */}
      <div
        className="flex items-center justify-between text-white shrink-0 z-10"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3">
          {photo.tag && (
            <span className="text-xs font-semibold bg-white/20 px-2 py-0.5 rounded backdrop-blur-xs">
              {photo.tag}
            </span>
          )}
          <span className="text-xs text-neutral-300 font-mono">
            {photo.title}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleDownload}
            title="Scarica Immagine"
            className="p-2 text-neutral-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
          >
            <Download className="w-5 h-5" />
          </button>
          <button
            onClick={onClose}
            title="Chiudi"
            className="p-2 text-neutral-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Image Center */}
      <div
        className="flex-1 flex items-center justify-center p-2 sm:p-6 min-h-0"
        onClick={(e) => e.stopPropagation()}
      >
        <img
          src={photo.url}
          alt={photo.caption || 'Immagine ingrandita'}
          referrerPolicy="no-referrer"
          className="max-h-full max-w-full object-contain rounded-lg shadow-2xl"
        />
      </div>

      {/* Bottom Caption Bar */}
      <div
        className="bg-black/60 backdrop-blur-md border border-white/10 p-4 rounded-xl text-white max-w-2xl mx-auto w-full shrink-0 z-10 text-center"
        onClick={(e) => e.stopPropagation()}
      >
        <p className="text-sm font-medium text-white">
          {photo.caption || 'Nessuna didascalia associata a questa immagine'}
        </p>
      </div>
    </div>
  );
};
