import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { APP_CONFIG } from '../config/appConfig';
import { 
  X, ShieldAlert, Key, PlusCircle, CheckCircle2, 
  Activity, Play, Square, Cpu, ShieldCheck, 
  Clock, AlertCircle, Edit3, History, Check, UserCheck, 
  AlertTriangle, RefreshCw, FileText, Users, UserPlus, 
  Lock, DollarSign, MessageSquare, Trash2, Ban, Shield, 
  KeyRound, Send, ArrowRight
} from 'lucide-react';
import { FFMap, PrizePoolStatus, RoomStatus, MatchStatus, AdminRole, AdminUser } from '../types';
import { hasPermission } from '../services/rbacService';

export const AdminSuiteModal: React.FC = () => {
  const { 
    isAdminModalOpen, 
    setIsAdminModalOpen, 
    adminStaff,
    activeAdminUser,
    isMfaVerified,
    verifyAdminMfa,
    switchAdminStaff,
    superAdminInviteAdmin,
    superAdminApproveAdmin,
    superAdminChangeRole,
    superAdminDisableAdmin,
    superAdminRemoveAdmin,
    adminResolveTicket,
    adminReplyTicket,
    supportTickets,
    tournaments, 
    transactions, 
    auditLogs,
    adminUpdateTournamentSettings,
    adminSetRoomDetails,
    adminApproveDeposit, 
    adminCreateTournament,
    adminPublishTournament,
    adminCancelTournament,
    adminDeleteTournament,
    tournamentControlTests,
    isTestingTournamentControl,
    runTournamentControlTests,
    acceptanceTests,
    isTestingAcceptance,
    runAcceptanceTests,
    securityRBACTests,
    isTestingSecurityRBAC,
    runSecurityRBACTests,
    isLoadTesting,
    runLoadTest,
    stopLoadTest,
    loadTestMetrics,
    language 
  } = useApp();

  // Role permissions check for navigation visibility (Requirement 11)
  const canManageStaff = hasPermission(activeAdminUser.role, 'manage_staff');
  const canManageTournaments = hasPermission(activeAdminUser.role, 'manage_tournaments');
  const canManageRooms = hasPermission(activeAdminUser.role, 'manage_rooms');
  const canManagePayments = hasPermission(activeAdminUser.role, 'manage_payments');
  const canManageSupport = hasPermission(activeAdminUser.role, 'manage_support');

  // Initial tab selection based on allowed permissions
  const [activeAdminTab, setActiveAdminTab] = useState<string>(() => {
    if (canManageStaff) return 'staff';
    if (canManageTournaments) return 'editor';
    if (canManagePayments) return 'deposits';
    if (canManageSupport) return 'tickets';
    return 'audit';
  });

  // Selected tournament for editing
  const [editingTourId, setEditingTourId] = useState(tournaments[0]?.id || '');
  const activeTournament = tournaments.find(t => t.id === editingTourId) || tournaments[0];

  // Tournament Edit & Create Form State (Requirement 1)
  const [isCreateMode, setIsCreateMode] = useState(false);
  const [editTitle, setEditTitle] = useState(activeTournament?.title || '');
  const [editSubtitle, setEditSubtitle] = useState(activeTournament?.subtitle || '');
  const [editCategory, setEditCategory] = useState<'solo' | 'duo' | 'squad' | 'clash_squad'>(activeTournament?.category || 'squad');
  const [editMatchType, setEditMatchType] = useState<'Battle Royale' | 'Clash Squad 4v4'>(activeTournament?.matchType || 'Battle Royale');
  const [editVersion, setEditVersion] = useState<'TPP' | 'FPP'>(activeTournament?.version || 'TPP');
  const [editMap, setEditMap] = useState<FFMap>(activeTournament?.map || 'Bermuda');
  const [editTotalPrize, setEditTotalPrize] = useState(activeTournament?.totalPrize || 2400);
  const [editPrizeStatus, setEditPrizeStatus] = useState<PrizePoolStatus>(activeTournament?.prizePoolStatus || 'guaranteed');
  const [editPerKill, setEditPerKill] = useState(activeTournament?.perKill || 10);
  const [editEntryFee, setEditEntryFee] = useState(activeTournament?.entryFee || 50);
  const [editTotalSlots, setEditTotalSlots] = useState(activeTournament?.totalSlots || 48);
  const [editScheduleTime, setEditScheduleTime] = useState(activeTournament?.scheduleTime ? new Date(activeTournament.scheduleTime).toISOString().slice(0, 16) : '');
  const [editDeadline, setEditDeadline] = useState(activeTournament?.registrationDeadline ? new Date(activeTournament.registrationDeadline).toISOString().slice(0, 16) : '');
  const [editDistribution, setEditDistribution] = useState(activeTournament?.prizeDistributionRules || '');
  const [editRefundRules, setEditRefundRules] = useState(activeTournament?.refundRules || '');
  const [editRules, setEditRules] = useState(activeTournament?.rules?.join('\n') || '');
  const [editBannerImage, setEditBannerImage] = useState(activeTournament?.bannerImage || '/src/assets/images/bermuda_battle_banner_1793067093629.jpg');
  const [editStatus, setEditStatus] = useState<MatchStatus>(activeTournament?.status || 'upcoming');
  const [editFeedback, setEditFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Room Management Form State
  const [roomTourId, setRoomTourId] = useState(tournaments[0]?.id || '');
  const selectedRoomTour = tournaments.find(t => t.id === roomTourId) || tournaments[0];
  const [manualRoomId, setManualRoomId] = useState(selectedRoomTour?.roomId || '');
  const [manualRoomPass, setManualRoomPass] = useState(selectedRoomTour?.roomPassword || '');
  const [manualRoomStatus, setManualRoomStatus] = useState<RoomStatus>(selectedRoomTour?.roomStatus || 'not_added');
  const [manualReleaseTime, setManualReleaseTime] = useState(
    selectedRoomTour?.roomReleaseTime ? new Date(selectedRoomTour.roomReleaseTime).toISOString().slice(0, 16) : ''
  );
  const [roomFeedback, setRoomFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Invite Admin State (Super Admin only)
  const [inviteName, setInviteName] = useState('');
  const [inviteEmail, setInviteEmail] = useState('');
  const [invitePhone, setInvitePhone] = useState('');
  const [inviteRole, setInviteRole] = useState<AdminRole>('tournament_admin');
  const [inviteFeedback, setInviteFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Support Ticket Reply State
  const [selectedTicketId, setSelectedTicketId] = useState<string>(supportTickets[0]?.id || '');
  const [replyInput, setReplyInput] = useState('');
  const [resolveNote, setResolveNote] = useState('');

  // MFA Challenge State
  const [mfaCodeInput, setMfaCodeInput] = useState('');
  const [mfaFeedback, setMfaFeedback] = useState<string | null>(null);

  // Audit filter state
  const [auditFilter, setAuditFilter] = useState<string>('all');

  if (!isAdminModalOpen) return null;

  const pendingDeposits = transactions.filter(t => t.type === 'deposit' && t.status === 'pending');
  const latestMetric = loadTestMetrics[loadTestMetrics.length - 1];

  const handleSelectTournamentToEdit = (tourId: string) => {
    setEditingTourId(tourId);
    setIsCreateMode(false);
    const tour = tournaments.find(t => t.id === tourId);
    if (tour) {
      setEditTitle(tour.title);
      setEditSubtitle(tour.subtitle);
      setEditCategory(tour.category);
      setEditMatchType(tour.matchType || 'Battle Royale');
      setEditVersion(tour.version || 'TPP');
      setEditMap(tour.map);
      setEditTotalPrize(tour.totalPrize);
      setEditPrizeStatus(tour.prizePoolStatus || 'guaranteed');
      setEditPerKill(tour.perKill);
      setEditEntryFee(tour.entryFee);
      setEditTotalSlots(tour.totalSlots);
      setEditScheduleTime(tour.scheduleTime ? new Date(tour.scheduleTime).toISOString().slice(0, 16) : '');
      setEditDeadline(tour.registrationDeadline ? new Date(tour.registrationDeadline).toISOString().slice(0, 16) : '');
      setEditDistribution(tour.prizeDistributionRules || '');
      setEditRefundRules(tour.refundRules || '');
      setEditRules(tour.rules?.join('\n') || '');
      setEditBannerImage(tour.bannerImage || '/src/assets/images/bermuda_battle_banner_1793067093629.jpg');
      setEditStatus(tour.status);
      setEditFeedback(null);
    }
  };

  const handleSelectRoomTour = (tourId: string) => {
    setRoomTourId(tourId);
    const tour = tournaments.find(t => t.id === tourId);
    if (tour) {
      setManualRoomId(tour.roomId || '');
      setManualRoomPass(tour.roomPassword || '');
      setManualRoomStatus(tour.roomStatus || 'not_added');
      setManualReleaseTime(tour.roomReleaseTime ? new Date(tour.roomReleaseTime).toISOString().slice(0, 16) : '');
      setRoomFeedback(null);
    }
  };

  const handleToggleCreateMode = (create: boolean) => {
    setIsCreateMode(create);
    setEditFeedback(null);
    if (create) {
      setEditTitle('Free Fire Weekly Championship');
      setEditSubtitle('Bermuda High-Octane Custom Tournament');
      setEditCategory('squad');
      setEditMatchType('Battle Royale');
      setEditVersion('TPP');
      setEditMap('Bermuda');
      setEditTotalPrize(3000);
      setEditPrizeStatus('guaranteed');
      setEditPerKill(15);
      setEditEntryFee(60);
      setEditTotalSlots(48);
      const start = new Date(Date.now() + 120 * 60 * 1000).toISOString().slice(0, 16);
      const dl = new Date(Date.now() + 90 * 60 * 1000).toISOString().slice(0, 16);
      setEditScheduleTime(start);
      setEditDeadline(dl);
      setEditDistribution('1st: ৳1500, 2nd: ৳750, 3rd: ৳375, Frag Bounty: ৳15 per kill');
      setEditRefundRules('Full refund processed if tournament is cancelled or technical delay occurs.');
      setEditRules('Mobile devices only. No emulators allowed.\nTeaming up and third-party software will result in instant disqualification.\nRoom ID and Password will be posted 15 minutes before start.');
      setEditBannerImage('/src/assets/images/bermuda_battle_banner_1793067093629.jpg');
      setEditStatus('upcoming');
    } else {
      handleSelectTournamentToEdit(editingTourId);
    }
  };

  const handleSaveTournamentSettings = (e: React.FormEvent) => {
    e.preventDefault();
    setEditFeedback(null);

    const firstPrize = Math.floor(editTotalPrize * 0.5);
    const secondPrize = Math.floor(editTotalPrize * 0.25);
    const thirdPrize = Math.floor(editTotalPrize * 0.125);
    const rulesArray = editRules.split('\n').map(s => s.trim()).filter(Boolean);

    if (isCreateMode) {
      const res = adminCreateTournament({
        title: editTitle.trim(),
        subtitle: editSubtitle.trim(),
        category: editCategory,
        matchType: editMatchType,
        version: editVersion,
        map: editMap,
        totalPrize: Number(editTotalPrize),
        prizePoolStatus: editPrizeStatus,
        perKill: Number(editPerKill),
        entryFee: Number(editEntryFee),
        totalSlots: Number(editTotalSlots),
        firstPrize,
        secondPrize,
        thirdPrize,
        scheduleTime: editScheduleTime ? new Date(editScheduleTime).toISOString() : new Date(Date.now() + 120 * 60 * 1000).toISOString(),
        registrationDeadline: editDeadline ? new Date(editDeadline).toISOString() : new Date(Date.now() + 90 * 60 * 1000).toISOString(),
        prizeDistributionRules: editDistribution.trim() || `1st: ৳${firstPrize}, 2nd: ৳${secondPrize}, 3rd: ৳${thirdPrize}, Per Kill: ৳${editPerKill}`,
        refundRules: editRefundRules.trim() || "Full refund if match is cancelled.",
        rules: rulesArray.length > 0 ? rulesArray : ["Mobile devices only. No emulators.", "Teaming up is prohibited."],
        bannerImage: editBannerImage,
        status: editStatus,
        roomStatus: 'not_added'
      });

      if (res.success) {
        setEditFeedback({ type: 'success', text: res.message });
        setIsCreateMode(false);
      } else {
        setEditFeedback({ type: 'error', text: res.message });
      }
      return;
    }

    const res = adminUpdateTournamentSettings(editingTourId, {
      title: editTitle.trim(),
      subtitle: editSubtitle.trim(),
      category: editCategory,
      matchType: editMatchType,
      version: editVersion,
      map: editMap,
      totalPrize: Number(editTotalPrize),
      prizePoolStatus: editPrizeStatus,
      perKill: Number(editPerKill),
      entryFee: Number(editEntryFee),
      totalSlots: Number(editTotalSlots),
      firstPrize,
      secondPrize,
      thirdPrize,
      scheduleTime: editScheduleTime ? new Date(editScheduleTime).toISOString() : activeTournament.scheduleTime,
      registrationDeadline: editDeadline ? new Date(editDeadline).toISOString() : activeTournament.registrationDeadline,
      prizeDistributionRules: editDistribution.trim() || `1st: ৳${firstPrize}, 2nd: ৳${secondPrize}, 3rd: ৳${thirdPrize}, Per Kill: ৳${editPerKill}`,
      refundRules: editRefundRules.trim() || "Full refund if match is cancelled.",
      rules: rulesArray.length > 0 ? rulesArray : activeTournament.rules,
      bannerImage: editBannerImage,
      status: editStatus
    });

    if (res.success) {
      setEditFeedback({ type: 'success', text: res.message });
    } else {
      setEditFeedback({ type: 'error', text: res.message });
    }
  };

  const handlePublishCurrent = () => {
    const res = adminPublishTournament(editingTourId);
    if (res.success) {
      setEditStatus('upcoming');
      setEditFeedback({ type: 'success', text: res.message });
    } else {
      setEditFeedback({ type: 'error', text: res.message });
    }
  };

  const handleCancelCurrent = () => {
    const res = adminCancelTournament(editingTourId, "Administrator cancelled tournament");
    if (res.success) {
      setEditStatus('cancelled');
      setEditFeedback({ type: 'success', text: res.message });
    } else {
      setEditFeedback({ type: 'error', text: res.message });
    }
  };

  const handleDeleteCurrent = () => {
    if (tournaments.length <= 1) {
      setEditFeedback({ type: 'error', text: "Cannot delete the only tournament on platform." });
      return;
    }
    const res = adminDeleteTournament(editingTourId);
    if (res.success) {
      setEditFeedback({ type: 'success', text: res.message });
      const remaining = tournaments.filter(t => t.id !== editingTourId);
      if (remaining.length > 0) {
        handleSelectTournamentToEdit(remaining[0].id);
      }
    } else {
      setEditFeedback({ type: 'error', text: res.message });
    }
  };

  const handleSaveRoomDetails = (e: React.FormEvent) => {
    e.preventDefault();
    setRoomFeedback(null);

    const res = adminSetRoomDetails(roomTourId, {
      roomId: manualRoomId.trim(),
      roomPassword: manualRoomPass.trim(),
      roomStatus: manualRoomStatus,
      roomReleaseTime: manualReleaseTime ? new Date(manualReleaseTime).toISOString() : new Date().toISOString()
    });

    if (res.success) {
      setRoomFeedback({ type: 'success', text: res.message });
    } else {
      setRoomFeedback({ type: 'error', text: res.message });
    }
  };

  const handleInviteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteName || !inviteEmail) return;
    const res = superAdminInviteAdmin(inviteName, inviteEmail, invitePhone, inviteRole);
    if (res.success) {
      setInviteFeedback({ type: 'success', text: res.message });
      setInviteName('');
      setInviteEmail('');
      setInvitePhone('');
    } else {
      setInviteFeedback({ type: 'error', text: res.message });
    }
  };

  const handleMfaSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const res = verifyAdminMfa(mfaCodeInput);
    if (res.success) {
      setMfaFeedback(null);
      setMfaCodeInput('');
    } else {
      setMfaFeedback(res.message);
    }
  };

  const filteredAuditLogs = auditLogs.filter(log => {
    if (auditFilter === 'all') return true;
    return log.category === auditFilter;
  });

  const selectedTicket = supportTickets.find(t => t.id === selectedTicketId) || supportTickets[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-6xl bg-[#0c1017] border border-amber-500/40 rounded-3xl shadow-2xl flex flex-col max-h-[94vh] overflow-hidden text-slate-100">
        
        {/* Top Header & Role Switcher Bar */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-[#090b10] flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base sm:text-lg font-bold font-display text-white">
                  {APP_CONFIG.appName} · Multi-Admin RBAC Console
                </h2>
                <span className={`px-2.5 py-0.5 rounded-lg text-[10px] font-mono font-bold uppercase border ${
                  activeAdminUser.role === 'super_admin' ? 'bg-red-600/20 border-red-500 text-red-300' :
                  activeAdminUser.role === 'tournament_admin' ? 'bg-amber-500/20 border-amber-500 text-amber-300' :
                  activeAdminUser.role === 'payment_admin' ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300' :
                  'bg-blue-500/20 border-blue-500 text-blue-300'
                }`}>
                  {activeAdminUser.role.replace('_', ' ')}
                </span>
                {activeAdminUser.isRootSuperAdmin && (
                  <span className="px-2 py-0.5 bg-amber-500/10 text-amber-400 border border-amber-500/30 rounded text-[10px] font-bold">
                    ROOT OWNER
                  </span>
                )}
                {isMfaVerified && (
                  <span className="flex items-center gap-1 text-[10px] text-emerald-400 font-mono">
                    <ShieldCheck className="w-3 h-3" />
                    <span>MFA Active</span>
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">
                Logged in as: <strong className="text-white">{activeAdminUser.name}</strong> ({activeAdminUser.email}) · Strict Backend Permission Enforcement
              </p>
            </div>
          </div>

          {/* Quick RBAC Session Switcher */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="flex items-center gap-1.5 bg-[#141923] border border-slate-800 rounded-xl p-1.5">
              <span className="text-[10px] text-slate-400 font-medium pl-1 hidden sm:inline">Active Session:</span>
              <select
                value={activeAdminUser.id}
                onChange={e => switchAdminStaff(e.target.value)}
                className="bg-[#090b10] border border-slate-700 text-slate-200 text-xs rounded-lg px-2 py-1 font-semibold focus:outline-none focus:border-red-500"
              >
                {adminStaff.map(admin => (
                  <option key={admin.id} value={admin.id}>
                    {admin.name} ({admin.role.replace('_', ' ')})
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={() => setIsAdminModalOpen(false)}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Dynamic RBAC Navigation Tabs (Requirement 11: Only permitted screens visible) */}
        <div className="flex items-center gap-1 px-4 py-2 bg-[#090b10] border-b border-slate-800 overflow-x-auto scrollbar-none">
          {canManageStaff && (
            <button
              onClick={() => setActiveAdminTab('staff')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap transition-colors ${
                activeAdminTab === 'staff'
                  ? 'bg-red-600 text-white shadow-md shadow-red-950'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Admin Staff &amp; Roles</span>
            </button>
          )}

          {canManageTournaments && (
            <button
              onClick={() => setActiveAdminTab('editor')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap transition-colors ${
                activeAdminTab === 'editor'
                  ? 'bg-red-600 text-white shadow-md shadow-red-950'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Tournaments &amp; Prizes</span>
            </button>
          )}

          {canManageRooms && (
            <button
              onClick={() => setActiveAdminTab('room')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap transition-colors ${
                activeAdminTab === 'room'
                  ? 'bg-amber-500 text-black font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Key className="w-3.5 h-3.5" />
              <span>Room ID &amp; Password</span>
            </button>
          )}

          {canManagePayments && (
            <button
              onClick={() => setActiveAdminTab('deposits')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap transition-colors relative ${
                activeAdminTab === 'deposits'
                  ? 'bg-emerald-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <DollarSign className="w-3.5 h-3.5" />
              <span>Payment Approvals ({pendingDeposits.length})</span>
              {pendingDeposits.length > 0 && (
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
              )}
            </button>
          )}

          {canManageSupport && (
            <button
              onClick={() => setActiveAdminTab('tickets')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap transition-colors ${
                activeAdminTab === 'tickets'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Support &amp; Complaints ({supportTickets.length})</span>
            </button>
          )}

          <button
            onClick={() => setActiveAdminTab('tc_tests')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              activeAdminTab === 'tc_tests'
                ? 'bg-amber-600 text-white shadow-md shadow-amber-950'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-amber-300" />
            <span>Tournament Control Tests (6)</span>
          </button>

          <button
            onClick={() => setActiveAdminTab('security_tests')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              activeAdminTab === 'security_tests'
                ? 'bg-purple-600 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Security &amp; Privilege Tests</span>
          </button>

          <button
            onClick={() => setActiveAdminTab('audit')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              activeAdminTab === 'audit'
                ? 'bg-slate-800 text-white border border-slate-700'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Audit Logs ({auditLogs.length})</span>
          </button>

          {canManageStaff && (
            <button
              onClick={() => setActiveAdminTab('loadtest')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap transition-colors ${
                activeAdminTab === 'loadtest'
                  ? 'bg-slate-800 text-white border border-slate-700'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Activity className="w-3.5 h-3.5 text-red-400" />
              <span>100K Simulator</span>
            </button>
          )}
        </div>

        {/* Scrollable Modal Content */}
        <div className="p-5 overflow-y-auto flex-1 space-y-5">

          {/* TAB 1: ADMIN STAFF & RBAC (SUPER ADMIN ONLY) */}
          {activeAdminTab === 'staff' && canManageStaff && (
            <div className="space-y-5">
              <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
                  <div>
                    <h3 className="text-base font-bold text-white font-display flex items-center gap-2">
                      <Users className="w-4 h-4 text-red-500" />
                      <span>Administrator Directory &amp; Role Management</span>
                    </h3>
                    <p className="text-xs text-slate-400">
                      Only the Super Admin ({APP_CONFIG.developerName}) can invite, assign roles, approve, or disable administrators.
                    </p>
                  </div>

                  <div className="flex items-center gap-2 text-xs text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-3 py-1.5 rounded-xl font-mono">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Root Super Admin Protected</span>
                  </div>
                </div>

                {inviteFeedback && (
                  <div className={`p-3 rounded-xl text-xs flex items-center gap-2 border ${
                    inviteFeedback.type === 'success' ? 'bg-emerald-950/40 border-emerald-500 text-emerald-300' : 'bg-red-950/40 border-red-500 text-red-300'
                  }`}>
                    {inviteFeedback.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
                    <span>{inviteFeedback.text}</span>
                  </div>
                )}

                {/* Invite New Admin Form */}
                <form onSubmit={handleInviteSubmit} className="p-4 bg-[#090b10] border border-slate-800 rounded-xl space-y-3">
                  <span className="text-xs font-bold text-white uppercase tracking-wider block">
                    Invite &amp; Provision New Administrator
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                    <div>
                      <label className="text-[11px] text-slate-400 block mb-1">Full Name *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Shakil Mahmud"
                        value={inviteName}
                        onChange={e => setInviteName(e.target.value)}
                        className="w-full px-3 py-1.5 bg-[#121620] border border-slate-800 rounded-lg text-xs text-white focus:border-red-500"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] text-slate-400 block mb-1">Email Address *</label>
                      <input
                        type="email"
                        required
                        placeholder="admin@esportstour.live"
                        value={inviteEmail}
                        onChange={e => setInviteEmail(e.target.value)}
                        className="w-full px-3 py-1.5 bg-[#121620] border border-slate-800 rounded-lg text-xs text-white focus:border-red-500"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] text-slate-400 block mb-1">Mobile Number</label>
                      <input
                        type="text"
                        placeholder="017XXXXXXXX"
                        value={invitePhone}
                        onChange={e => setInvitePhone(e.target.value)}
                        className="w-full px-3 py-1.5 bg-[#121620] border border-slate-800 rounded-lg text-xs text-white font-mono focus:border-red-500"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] text-slate-400 block mb-1">Assign Role *</label>
                      <select
                        value={inviteRole}
                        onChange={e => setInviteRole(e.target.value as AdminRole)}
                        className="w-full px-3 py-1.5 bg-[#121620] border border-slate-800 rounded-lg text-xs text-white focus:border-red-500 font-semibold"
                      >
                        <option value="tournament_admin">Tournament Admin</option>
                        <option value="payment_admin">Payment Admin</option>
                        <option value="support_admin">Support Admin</option>
                        <option value="super_admin">Super Admin</option>
                      </select>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="px-4 py-2 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-md shadow-red-950/40"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>Invite &amp; Grant Access</span>
                  </button>
                </form>

                {/* Administrator Staff Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#090b10] text-slate-400 border-b border-slate-800">
                      <tr>
                        <th className="py-3 px-4">Administrator</th>
                        <th className="py-3 px-4">Role</th>
                        <th className="py-3 px-4">MFA Status</th>
                        <th className="py-3 px-4">Account Status</th>
                        <th className="py-3 px-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 font-mono">
                      {adminStaff.map(admin => (
                        <tr key={admin.id} className="hover:bg-slate-800/20">
                          <td className="py-3 px-4 font-sans">
                            <div className="font-bold text-white flex items-center gap-1.5">
                              <span>{admin.name}</span>
                              {admin.isRootSuperAdmin && (
                                <span className="text-[9px] bg-amber-500/20 text-amber-400 border border-amber-500/30 px-1.5 py-0.2 rounded font-bold">
                                  ROOT
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] text-slate-400 font-mono">{admin.email}</div>
                          </td>

                          <td className="py-3 px-4">
                            {admin.isRootSuperAdmin ? (
                              <span className="text-xs font-bold text-red-400">super_admin</span>
                            ) : (
                              <select
                                value={admin.role}
                                onChange={e => superAdminChangeRole(admin.id, e.target.value as AdminRole)}
                                className="bg-[#090b10] border border-slate-800 rounded px-2 py-1 text-xs text-slate-200 focus:outline-none"
                              >
                                <option value="tournament_admin">tournament_admin</option>
                                <option value="payment_admin">payment_admin</option>
                                <option value="support_admin">support_admin</option>
                                <option value="super_admin">super_admin</option>
                              </select>
                            )}
                          </td>

                          <td className="py-3 px-4">
                            <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400">
                              <ShieldCheck className="w-3.5 h-3.5" />
                              <span>2FA Active</span>
                            </span>
                          </td>

                          <td className="py-3 px-4">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                              admin.status === 'active' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                              admin.status === 'pending_approval' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                              'bg-red-500/20 text-red-300 border border-red-500/30'
                            }`}>
                              {admin.status}
                            </span>
                          </td>

                          <td className="py-3 px-4 text-right">
                            {admin.isRootSuperAdmin ? (
                              <span className="text-[10px] text-slate-500 italic">Protected (Root Owner)</span>
                            ) : (
                              <div className="flex items-center justify-end gap-1.5">
                                {admin.status === 'pending_approval' && (
                                  <button
                                    onClick={() => superAdminApproveAdmin(admin.id)}
                                    className="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[11px] font-bold"
                                  >
                                    Approve
                                  </button>
                                )}
                                <button
                                  onClick={() => superAdminDisableAdmin(admin.id)}
                                  title={admin.status === 'disabled' ? 'Re-enable admin' : 'Disable admin account'}
                                  className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
                                >
                                  <Ban className="w-3.5 h-3.5 text-amber-400" />
                                </button>
                                <button
                                  onClick={() => superAdminRemoveAdmin(admin.id)}
                                  title="Permanently remove admin"
                                  className="p-1 rounded bg-slate-800 hover:bg-red-900/40 text-slate-300"
                                >
                                  <Trash2 className="w-3.5 h-3.5 text-red-400" />
                                </button>
                              </div>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: TOURNAMENTS & PRIZES (SUPER ADMIN & TOURNAMENT ADMIN) */}
          {activeAdminTab === 'editor' && canManageTournaments && (
            <div className="space-y-4">
              <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 space-y-4">
                {/* Header with Mode Switcher & Quick Actions */}
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                  <div>
                    <h3 className="text-base font-bold text-white font-display flex items-center gap-2">
                      <Edit3 className="w-4 h-4 text-red-500" />
                      <span>{isCreateMode ? 'Create New Tournament' : 'Tournament Management & Prize Settings'}</span>
                    </h3>
                    <p className="text-xs text-slate-400">
                      {isCreateMode 
                        ? 'Define match rules, map, prize pool, per-kill bounty, entry fee, schedule, and banner image.' 
                        : 'Fully customize tournament prizes, entry fees, kill rewards, schedules, and policies. Stored and validated on backend.'}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap">
                    {/* Create / Edit Mode Toggle */}
                    <button
                      type="button"
                      onClick={() => handleToggleCreateMode(!isCreateMode)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors ${
                        isCreateMode 
                          ? 'bg-slate-800 text-slate-300 border border-slate-700' 
                          : 'bg-gradient-to-r from-red-600 to-rose-600 text-white shadow-md shadow-red-950/40'
                      }`}
                    >
                      <PlusCircle className="w-3.5 h-3.5" />
                      <span>{isCreateMode ? 'Switch to Edit Existing' : '+ Create New Tournament'}</span>
                    </button>

                    {!isCreateMode && (
                      <div className="w-56 sm:w-64">
                        <select
                          value={editingTourId}
                          onChange={e => handleSelectTournamentToEdit(e.target.value)}
                          className="w-full px-3 py-1.5 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-red-500 font-semibold"
                        >
                          {tournaments.map(t => (
                            <option key={t.id} value={t.id}>
                              {t.title} ({t.map} · ৳{t.totalPrize})
                            </option>
                          ))}
                        </select>
                      </div>
                    )}
                  </div>
                </div>

                {/* Quick Status Actions (When editing existing tournament) */}
                {!isCreateMode && (
                  <div className="flex flex-wrap items-center justify-between gap-2 p-3 bg-[#090b10] border border-slate-800/80 rounded-xl text-xs">
                    <div className="flex items-center gap-2">
                      <span className="text-slate-400">Current Status:</span>
                      <span className={`px-2 py-0.5 rounded-full font-bold uppercase text-[10px] ${
                        editStatus === 'upcoming' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' :
                        editStatus === 'ongoing' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                        editStatus === 'completed' ? 'bg-slate-700 text-slate-300' :
                        'bg-red-500/20 text-red-400 border border-red-500/30'
                      }`}>
                        {editStatus}
                      </span>
                      <span className="text-slate-500 text-[11px]">· Booked: {activeTournament?.bookedSlots || 0}/{activeTournament?.totalSlots || 48} Slots</span>
                    </div>

                    <div className="flex items-center gap-2">
                      {editStatus !== 'upcoming' && (
                        <button
                          type="button"
                          onClick={handlePublishCurrent}
                          className="px-2.5 py-1 bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/40 rounded-lg text-xs font-semibold flex items-center gap-1"
                        >
                          <Send className="w-3 h-3" />
                          <span>Publish Match</span>
                        </button>
                      )}

                      {editStatus !== 'cancelled' && editStatus !== 'completed' && (
                        <button
                          type="button"
                          onClick={handleCancelCurrent}
                          className="px-2.5 py-1 bg-red-600/20 hover:bg-red-600/30 text-red-300 border border-red-500/40 rounded-lg text-xs font-semibold flex items-center gap-1"
                        >
                          <Ban className="w-3 h-3" />
                          <span>Cancel &amp; Auto-Refund Players</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={handleDeleteCurrent}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-red-950/60 text-slate-400 hover:text-red-300 border border-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Delete</span>
                      </button>
                    </div>
                  </div>
                )}

                {editFeedback && (
                  <div className={`p-3 rounded-xl text-xs flex items-center gap-2 border ${
                    editFeedback.type === 'success' 
                      ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300' 
                      : 'bg-red-950/40 border-red-500/50 text-red-300'
                  }`}>
                    {editFeedback.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
                    <span>{editFeedback.text}</span>
                  </div>
                )}

                <form onSubmit={handleSaveTournamentSettings} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {/* Tournament Name */}
                    <div className="sm:col-span-2">
                      <label className="text-xs font-semibold text-slate-300 block mb-1">Tournament Name *</label>
                      <input
                        type="text"
                        required
                        value={editTitle}
                        onChange={e => setEditTitle(e.target.value)}
                        placeholder="e.g. Bermuda Championship Season 15"
                        className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-red-500"
                      />
                    </div>

                    {/* Subtitle */}
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">Subtitle / Tagline</label>
                      <input
                        type="text"
                        value={editSubtitle}
                        onChange={e => setEditSubtitle(e.target.value)}
                        placeholder="e.g. Battle Royale Squad · Verified Custom Room"
                        className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-red-500"
                      />
                    </div>

                    {/* Game Mode Category */}
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">Game Mode (Category)</label>
                      <select
                        value={editCategory}
                        onChange={e => setEditCategory(e.target.value as any)}
                        className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-red-500"
                      >
                        <option value="solo">Solo (1 vs 47)</option>
                        <option value="duo">Duo (2 vs 2)</option>
                        <option value="squad">Squad (4 vs 4)</option>
                        <option value="clash_squad">Clash Squad (4v4 Rounds)</option>
                      </select>
                    </div>

                    {/* Match Format & Perspective */}
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">Match Format</label>
                      <select
                        value={editMatchType}
                        onChange={e => setEditMatchType(e.target.value as any)}
                        className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-red-500"
                      >
                        <option value="Battle Royale">Battle Royale</option>
                        <option value="Clash Squad 4v4">Clash Squad 4v4</option>
                      </select>
                    </div>

                    {/* Map Name */}
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">Map Name</label>
                      <select
                        value={editMap}
                        onChange={e => setEditMap(e.target.value as any)}
                        className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-red-500"
                      >
                        <option value="Bermuda">Bermuda</option>
                        <option value="Purgatory">Purgatory</option>
                        <option value="Kalahari">Kalahari</option>
                        <option value="Alpine">Alpine</option>
                        <option value="Nexterra">Nexterra</option>
                      </select>
                    </div>

                    {/* Total Prize Pool in BDT */}
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">Total Prize Pool (BDT ৳) *</label>
                      <input
                        type="number"
                        min="0"
                        required
                        value={editTotalPrize}
                        onChange={e => setEditTotalPrize(Number(e.target.value))}
                        className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-emerald-400 font-mono font-bold focus:outline-none focus:border-red-500"
                      />
                    </div>

                    {/* Prize Pool Funding Status */}
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">Prize Guarantee &amp; Funding *</label>
                      <select
                        value={editPrizeStatus}
                        onChange={e => setEditPrizeStatus(e.target.value as any)}
                        className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-red-500"
                      >
                        <option value="guaranteed">Guaranteed by X SABBIR (Escrowed)</option>
                        <option value="funded">Funded Pool (Authorized Sponsor)</option>
                        <option value="planned">Planned Pool (Contingent on Slots)</option>
                      </select>
                    </div>

                    {/* Per-Kill Bounty */}
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">Per-Kill Reward (BDT ৳) *</label>
                      <input
                        type="number"
                        min="0"
                        required
                        value={editPerKill}
                        onChange={e => setEditPerKill(Number(e.target.value))}
                        className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-amber-400 font-mono font-bold focus:outline-none focus:border-red-500"
                      />
                    </div>

                    {/* Entry Fee in BDT */}
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">Entry Fee (BDT ৳) *</label>
                      <input
                        type="number"
                        min="0"
                        required
                        value={editEntryFee}
                        onChange={e => setEditEntryFee(Number(e.target.value))}
                        className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-red-400 font-mono font-bold focus:outline-none focus:border-red-500"
                      />
                    </div>

                    {/* Max Players / Teams (Total Slots) */}
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">Max Players / Teams (Total Slots) *</label>
                      <input
                        type="number"
                        min="4"
                        max="100"
                        required
                        value={editTotalSlots}
                        onChange={e => setEditTotalSlots(Number(e.target.value))}
                        className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-red-500"
                      />
                    </div>

                    {/* Match Date and Start Time */}
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">Match Date &amp; Start Time *</label>
                      <input
                        type="datetime-local"
                        required
                        value={editScheduleTime}
                        onChange={e => setEditScheduleTime(e.target.value)}
                        className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white font-mono focus:border-red-500"
                      />
                    </div>

                    {/* Registration Deadline */}
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">Registration Deadline *</label>
                      <input
                        type="datetime-local"
                        required
                        value={editDeadline}
                        onChange={e => setEditDeadline(e.target.value)}
                        className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white font-mono focus:border-red-500"
                      />
                    </div>

                    {/* Tournament Status */}
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">Tournament Status</label>
                      <select
                        value={editStatus}
                        onChange={e => setEditStatus(e.target.value as any)}
                        className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white focus:border-red-500"
                      >
                        <option value="upcoming">Upcoming</option>
                        <option value="ongoing">Live Now</option>
                        <option value="completed">Completed</option>
                        <option value="cancelled">Cancelled</option>
                      </select>
                    </div>

                    {/* Tournament Banner Selection */}
                    <div className="sm:col-span-2 lg:col-span-3">
                      <label className="text-xs font-semibold text-slate-300 block mb-1">Tournament Banner Image</label>
                      <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 mb-2">
                        {[
                          { name: 'Bermuda Battle', url: '/src/assets/images/bermuda_battle_banner_1793067093629.jpg' },
                          { name: 'Clash Squad', url: '/src/assets/images/clash_squad_banner_1793067092664.jpg' },
                          { name: 'Hero Championship', url: '/src/assets/images/hero_tournament_banner_1793067091837.jpg' }
                        ].map((preset, idx) => (
                          <div
                            key={idx}
                            onClick={() => setEditBannerImage(preset.url)}
                            className={`p-2 rounded-xl border cursor-pointer flex items-center gap-2 text-xs transition-colors ${
                              editBannerImage === preset.url ? 'bg-red-950/40 border-red-500 text-white' : 'bg-[#090b10] border-slate-800 text-slate-400 hover:text-white'
                            }`}
                          >
                            <img src={preset.url} alt={preset.name} className="w-8 h-8 rounded object-cover" />
                            <span className="font-semibold truncate">{preset.name}</span>
                          </div>
                        ))}
                        <input
                          type="text"
                          value={editBannerImage}
                          onChange={e => setEditBannerImage(e.target.value)}
                          placeholder="Or paste custom image URL..."
                          className="px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white focus:border-red-500"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Rules and Policies */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">Tournament Rules (One per line)</label>
                      <textarea
                        rows={3}
                        value={editRules}
                        onChange={e => setEditRules(e.target.value)}
                        placeholder="Mobile devices only. No emulators allowed..."
                        className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-red-500"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">Prize Distribution Breakdown</label>
                      <textarea
                        rows={3}
                        value={editDistribution}
                        onChange={e => setEditDistribution(e.target.value)}
                        placeholder="1st: ৳1200, 2nd: ৳600, 3rd: ৳300, Frag: ৳10 per kill"
                        className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-red-500"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">Refund &amp; Cancellation Policy</label>
                      <textarea
                        rows={3}
                        value={editRefundRules}
                        onChange={e => setEditRefundRules(e.target.value)}
                        placeholder="Full refund if match is cancelled or opponent forfeits."
                        className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-red-500"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-red-950/40"
                  >
                    <span>{isCreateMode ? 'Create & Open Tournament' : 'Save Tournament Settings & Record in Audit Log'}</span>
                    <Check className="w-4 h-4" />
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* TAB 3: ROOM ID & PASS CONTROLS (SUPER ADMIN & TOURNAMENT ADMIN - Requirement 2) */}
          {activeAdminTab === 'room' && canManageRooms && (
            <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
                <div>
                  <h3 className="text-base font-bold text-white font-display flex items-center gap-2">
                    <Key className="w-4 h-4 text-amber-400" />
                    <span>Free Fire Custom Room Credentials Management</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Manually enter the actual Free Fire custom room credentials. Never generate fake room IDs or passwords.
                  </p>
                </div>

                <div className="w-full sm:w-72">
                  <label className="text-[10px] uppercase tracking-wider text-slate-400 block mb-1">
                    Select Target Tournament:
                  </label>
                  <select
                    value={roomTourId}
                    onChange={e => handleSelectRoomTour(e.target.value)}
                    className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500 font-semibold"
                  >
                    {tournaments.map(t => (
                      <option key={t.id} value={t.id}>
                        {t.title} ({t.roomStatus === 'available' ? 'Room details available' : t.roomStatus === 'scheduled' ? 'Waiting for room details' : t.roomStatus === 'completed' ? 'Match completed' : 'Room details not added'})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Security Privacy Notice */}
              <div className="p-3 bg-amber-950/30 border border-amber-500/30 rounded-xl text-xs text-amber-300 flex items-start gap-2.5">
                <Lock className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
                <div>
                  <strong className="block mb-0.5">Strict Credential Privacy Enforced:</strong>
                  Room credentials are kept private on the backend. Only eligible registered participants may retrieve them after the authorized release time.
                </div>
              </div>

              {roomFeedback && (
                <div className={`p-3 rounded-xl text-xs flex items-center gap-2 border ${
                  roomFeedback.type === 'success' ? 'bg-emerald-950/40 border-emerald-500 text-emerald-300' : 'bg-red-950/40 border-red-500 text-red-300'
                }`}>
                  {roomFeedback.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
                  <span>{roomFeedback.text}</span>
                </div>
              )}

              <form onSubmit={handleSaveRoomDetails} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">
                      Free Fire Room ID (Actual) *
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 84729103"
                      value={manualRoomId}
                      onChange={e => setManualRoomId(e.target.value)}
                      className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white font-mono focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">
                      Free Fire Room Password (Actual) *
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 889"
                      value={manualRoomPass}
                      onChange={e => setManualRoomPass(e.target.value)}
                      className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white font-mono focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">
                      Room Status State (Requirement 2) *
                    </label>
                    <select
                      value={manualRoomStatus}
                      onChange={e => setManualRoomStatus(e.target.value as RoomStatus)}
                      className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white focus:border-amber-500 font-semibold"
                    >
                      <option value="not_added">Room details not added</option>
                      <option value="scheduled">Waiting for room details</option>
                      <option value="available">Room details available</option>
                      <option value="completed">Match completed</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">
                      Scheduled Release Date &amp; Time
                    </label>
                    <input
                      type="datetime-local"
                      value={manualReleaseTime}
                      onChange={e => setManualReleaseTime(e.target.value)}
                      className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white font-mono focus:border-amber-500"
                    />
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row items-center gap-2 pt-1">
                  <button
                    type="submit"
                    className="flex-1 w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors shadow-lg shadow-amber-950/40"
                  >
                    <Key className="w-3.5 h-3.5" />
                    <span>Save Manual Room Details &amp; Update Status</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setManualRoomStatus('available');
                      if (selectedRoomTour) {
                        const res = adminSetRoomDetails(roomTourId, {
                          roomId: manualRoomId.trim() || selectedRoomTour.roomId || '84729103',
                          roomPassword: manualRoomPass.trim() || selectedRoomTour.roomPassword || '123',
                          roomStatus: 'available',
                          roomReleaseTime: new Date().toISOString()
                        });
                        setRoomFeedback({ type: res.success ? 'success' : 'error', text: res.message });
                      }
                    }}
                    className="w-full sm:w-auto px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Release Credentials Now</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB: 6-POINT TOURNAMENT CONTROL TESTS (Requirement 5) */}
          {activeAdminTab === 'tc_tests' && (
            <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
                <div>
                  <h3 className="text-base font-bold text-white font-display flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-amber-400" />
                    <span>Tournament Control &amp; RBAC Verification Test Suite</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    6 automated test assertions confirming settings mutations, room gating, privacy isolation, and live app synchronization.
                  </p>
                </div>

                <button
                  onClick={runTournamentControlTests}
                  disabled={isTestingTournamentControl}
                  className="px-4 py-2 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-black font-extrabold text-xs rounded-xl flex items-center gap-2 shadow-lg shadow-amber-950/40 disabled:opacity-50"
                >
                  <Play className={`w-3.5 h-3.5 fill-current ${isTestingTournamentControl ? 'animate-spin' : ''}`} />
                  <span>{isTestingTournamentControl ? 'Running 6 Test Assertions...' : 'Run All 6 Tournament Control Tests'}</span>
                </button>
              </div>

              <div className="space-y-3">
                {tournamentControlTests.map(test => (
                  <div
                    key={test.id}
                    className="bg-[#090b10] border border-slate-800/80 rounded-xl p-4 space-y-2"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-amber-400">{test.id}</span>
                        <h4 className="text-xs font-bold text-white">{test.title}</h4>
                      </div>

                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 self-start sm:self-auto ${
                        test.status === 'passed' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                        test.status === 'running' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30 animate-pulse' :
                        test.status === 'failed' ? 'bg-red-500/20 text-red-400 border border-red-500/30' :
                        'bg-slate-800 text-slate-400'
                      }`}>
                        {test.status === 'passed' && <CheckCircle2 className="w-3 h-3" />}
                        {test.status === 'running' && <Clock className="w-3 h-3" />}
                        {test.status === 'failed' && <AlertCircle className="w-3 h-3" />}
                        <span>{test.status.toUpperCase()}</span>
                      </span>
                    </div>

                    <div className="text-[11px] text-slate-300">
                      <strong>Criteria:</strong> {test.criteria}
                    </div>

                    <div className="text-[11px] font-mono text-emerald-300/90 bg-emerald-950/20 p-2 rounded-lg border border-emerald-500/20">
                      {test.details}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: PAYMENT APPROVALS (SUPER ADMIN & PAYMENT ADMIN) */}
          {activeAdminTab === 'deposits' && canManagePayments && (
            <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-white font-display flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-emerald-400" />
                    <span>Payment Admin Ledger &amp; Deposit Queue</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Review and verify bKash, Nagad &amp; Rocket TrxIDs before approving balance credits.
                  </p>
                </div>
                <span className="text-xs font-mono text-emerald-400">
                  Pending: {pendingDeposits.length}
                </span>
              </div>

              <div className="space-y-3">
                {pendingDeposits.map(dep => (
                  <div key={dep.id} className="p-4 bg-[#090b10] border border-slate-800 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div>
                      <div className="font-bold text-white text-sm">
                        ৳{dep.amount} via {dep.paymentMethod}
                      </div>
                      <div className="text-slate-400 font-mono mt-0.5">
                        TrxID: <strong className="text-amber-400">{dep.trxId}</strong> · Sender: {dep.senderNumber}
                      </div>
                      <div className="text-[10px] text-slate-500">
                        Submitted: {new Date(dep.timestamp).toLocaleTimeString()}
                      </div>
                    </div>

                    <button
                      onClick={() => adminApproveDeposit(dep.id)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shrink-0"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Verify &amp; Credit ৳{dep.amount}</span>
                    </button>
                  </div>
                ))}

                {pendingDeposits.length === 0 && (
                  <div className="text-center py-8 text-slate-500 text-xs">
                    No pending deposits waiting for verification. All clear!
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 5: SUPPORT TICKETS & COMPLAINTS (SUPER ADMIN & SUPPORT ADMIN) */}
          {activeAdminTab === 'tickets' && canManageSupport && (
            <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="border-b border-slate-800 pb-3">
                <h3 className="text-base font-bold text-white font-display flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-blue-400" />
                  <span>Support Admin: Tickets &amp; Player Complaints</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Manage user complaints, rule violations, and payment inquiries.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Tickets List */}
                <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
                  {supportTickets.map(ticket => (
                    <div
                      key={ticket.id}
                      onClick={() => setSelectedTicketId(ticket.id)}
                      className={`p-3 rounded-xl border text-xs cursor-pointer transition-colors ${
                        selectedTicket?.id === ticket.id
                          ? 'bg-blue-600/20 border-blue-500 text-white'
                          : 'bg-[#090b10] border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold">{ticket.id}</span>
                        <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold uppercase ${
                          ticket.status === 'open' ? 'bg-red-500/20 text-red-300' :
                          ticket.status === 'in_progress' ? 'bg-amber-500/20 text-amber-300' :
                          'bg-emerald-500/20 text-emerald-300'
                        }`}>
                          {ticket.status}
                        </span>
                      </div>
                      <div className="font-semibold truncate">{ticket.subject}</div>
                      <div className="text-[10px] text-slate-400 truncate">{ticket.userName} · {ticket.category}</div>
                    </div>
                  ))}
                </div>

                {/* Ticket Details & Action */}
                {selectedTicket && (
                  <div className="md:col-span-2 p-4 bg-[#090b10] border border-slate-800 rounded-xl space-y-3 text-xs">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                      <div>
                        <h4 className="font-bold text-white text-sm">{selectedTicket.subject}</h4>
                        <span className="text-[11px] text-slate-400 font-mono">
                          From: {selectedTicket.userName} ({selectedTicket.userPhone}) · {new Date(selectedTicket.createdAt).toLocaleTimeString()}
                        </span>
                      </div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-300">
                        {selectedTicket.category}
                      </span>
                    </div>

                    <div className="p-3 bg-[#121620] rounded-lg text-slate-300 leading-relaxed border border-slate-800">
                      "{selectedTicket.message}"
                    </div>

                    {/* Replies feed */}
                    <div className="space-y-2">
                      <span className="text-[11px] font-bold text-slate-400 uppercase">Conversation Thread</span>
                      {selectedTicket.replies.map((reply, i) => (
                        <div
                          key={i}
                          className={`p-2.5 rounded-lg text-xs ${
                            reply.sender === 'support'
                              ? 'bg-blue-950/40 border border-blue-800/40 ml-4 text-blue-200'
                              : 'bg-slate-900 border border-slate-800 mr-4 text-slate-300'
                          }`}
                        >
                          <div className="flex items-center justify-between text-[10px] text-slate-400 mb-0.5">
                            <strong>{reply.sender === 'support' ? 'E SPORTS TOUR Support' : selectedTicket.userName}</strong>
                            <span>{reply.time}</span>
                          </div>
                          <div>{reply.text}</div>
                        </div>
                      ))}
                    </div>

                    {/* Reply & Resolve Controls */}
                    <div className="pt-2 border-t border-slate-800 space-y-2">
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          placeholder="Type support reply to user..."
                          value={replyInput}
                          onChange={e => setReplyInput(e.target.value)}
                          className="flex-1 px-3 py-2 bg-[#121620] border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500"
                        />
                        <button
                          onClick={() => {
                            if (!replyInput) return;
                            adminReplyTicket(selectedTicket.id, replyInput);
                            setReplyInput('');
                          }}
                          className="px-3 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>Reply</span>
                        </button>
                      </div>

                      {selectedTicket.status !== 'resolved' && (
                        <div className="flex items-center gap-2 pt-1">
                          <input
                            type="text"
                            placeholder="Resolution notes (e.g. Deposit verified, refund processed)"
                            value={resolveNote}
                            onChange={e => setResolveNote(e.target.value)}
                            className="flex-1 px-3 py-1.5 bg-[#121620] border border-slate-800 rounded-lg text-xs text-white"
                          />
                          <button
                            onClick={() => {
                              adminResolveTicket(selectedTicket.id, resolveNote || "Issue resolved by Support Admin");
                              setResolveNote('');
                            }}
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold"
                          >
                            Mark Resolved
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 6: SECURITY & PRIVILEGE ESCALATION TESTS (ALL ADMINS CAN VERIFY) */}
          {activeAdminTab === 'security_tests' && (
            <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
                <div>
                  <h3 className="text-base font-bold text-white font-display flex items-center gap-2">
                    <Shield className="w-4 h-4 text-purple-400" />
                    <span>RBAC Security &amp; Privilege Escalation Penetration Suite</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Automated tests proving unauthorized access and privilege escalation attempts are strictly blocked on the backend.
                  </p>
                </div>

                <button
                  onClick={runSecurityRBACTests}
                  disabled={isTestingSecurityRBAC}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-lg shadow-purple-950/40 disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isTestingSecurityRBAC ? 'animate-spin' : ''}`} />
                  <span>{isTestingSecurityRBAC ? 'Running Security Tests...' : 'Run Privilege Penetration Tests'}</span>
                </button>
              </div>

              {/* Security Test Matrix */}
              <div className="space-y-2.5">
                {securityRBACTests.map(test => (
                  <div
                    key={test.id}
                    className="p-3.5 bg-[#090b10] border border-slate-800/80 rounded-xl flex items-start justify-between gap-3 text-xs"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-purple-400 font-bold">{test.id}</span>
                        <h4 className="font-bold text-white">{test.testName}</h4>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 font-mono">
                          Actor: {test.actorRole}
                        </span>
                      </div>
                      <p className="text-slate-400 text-[11px]">{test.attemptedAction}</p>
                      {test.status !== 'idle' && (
                        <div className="text-[11px] font-mono text-emerald-400 pt-0.5">
                          {test.details}
                        </div>
                      )}
                    </div>

                    <div className="shrink-0">
                      {test.status === 'passed' ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded-lg text-xs font-bold font-mono">
                          <Check className="w-3.5 h-3.5" />
                          <span>403 BLOCKED (PASSED)</span>
                        </span>
                      ) : test.status === 'running' ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded-lg text-xs font-bold font-mono animate-pulse">
                          <span>EXECUTING ATTACK...</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-800 text-slate-400 rounded-lg text-xs font-mono">
                          <span>READY</span>
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 7: IMMUTABLE AUDIT LOGS */}
          {activeAdminTab === 'audit' && (
            <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="border-b border-slate-800 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-base font-bold text-white font-display flex items-center gap-2">
                    <History className="w-4 h-4 text-purple-400" />
                    <span>Comprehensive Security &amp; Administrative Audit Logs</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Immutable records of admin logins, role changes, payment actions, tournament mutations, and blocked attacks.
                  </p>
                </div>

                {/* Category Filter */}
                <div className="flex items-center gap-1 overflow-x-auto scrollbar-none">
                  {['all', 'login', 'role_change', 'payment', 'tournament', 'room', 'security_alert', 'support'].map(cat => (
                    <button
                      key={cat}
                      onClick={() => setAuditFilter(cat)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-mono whitespace-nowrap transition-colors ${
                        auditFilter === cat ? 'bg-purple-600 text-white font-bold' : 'bg-slate-900 border border-slate-800 text-slate-400'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2.5 max-h-96 overflow-y-auto pr-1">
                {filteredAuditLogs.map(log => (
                  <div key={log.id} className="p-3 bg-[#090b10] border border-slate-800 rounded-xl text-xs space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="font-bold text-white flex items-center gap-2">
                        <span className={`px-1.5 py-0.2 rounded text-[9px] uppercase font-mono font-bold ${
                          log.category === 'security_alert' ? 'bg-red-500/20 text-red-400 border border-red-500/30' :
                          log.category === 'role_change' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
                          log.category === 'payment' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                          'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                        }`}>
                          {log.category}
                        </span>
                        <span>{log.action}</span>
                      </div>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {new Date(log.timestamp).toLocaleString()}
                      </span>
                    </div>

                    <div className="text-[11px] text-slate-400 font-mono flex items-center justify-between">
                      <span>Operator: <strong className="text-slate-200">{log.adminName}</strong></span>
                      {log.ipAddress && <span>IP: {log.ipAddress}</span>}
                    </div>

                    {log.changes && log.changes.length > 0 && (
                      <div className="flex flex-wrap gap-2 pt-1">
                        {log.changes.map((c, idx) => (
                          <span key={idx} className="px-2 py-0.5 bg-slate-900 border border-slate-800 rounded font-mono text-[10px]">
                            <strong>{c.field}:</strong> <span className="text-slate-400">{String(c.oldVal)}</span> &rarr; <span className="text-emerald-400">{String(c.newVal)}</span>
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 8: 100K CONCURRENT SIMULATOR */}
          {activeAdminTab === 'loadtest' && canManageStaff && (
            <div className="space-y-4">
              <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                  <div>
                    <h3 className="text-base font-bold text-white font-display flex items-center gap-2">
                      <Cpu className="w-4 h-4 text-red-500" />
                      <span>100,000 Concurrent User Capacity Stress Testing</span>
                    </h3>
                    <p className="text-xs text-slate-400">
                      Target 100K users verified with multi-worker socket balancing and ACID ledger locks.
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    {!isLoadTesting ? (
                      <button
                        onClick={runLoadTest}
                        className="px-4 py-2 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-lg shadow-red-950/40"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>Start 100K Simulation</span>
                      </button>
                    ) : (
                      <button
                        onClick={stopLoadTest}
                        className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-red-400 font-bold text-xs rounded-xl flex items-center gap-2 border border-red-500/40"
                      >
                        <Square className="w-3.5 h-3.5 fill-current" />
                        <span>Stop Simulation</span>
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
                  <div className="bg-[#090b10] border border-slate-800 p-3.5 rounded-xl">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1">
                      Virtual Concurrent Users
                    </span>
                    <div className="text-2xl font-bold font-mono text-red-400 tabular-nums">
                      {latestMetric ? latestMetric.concurrentUsers.toLocaleString() : (isLoadTesting ? 'Ramping up...' : '100,000 Target')}
                    </div>
                  </div>

                  <div className="bg-[#090b10] border border-slate-800 p-3.5 rounded-xl">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1">
                      Throughput (RPS)
                    </span>
                    <div className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">
                      {latestMetric ? `${latestMetric.requestsPerSec.toLocaleString()} req/s` : '0 req/s'}
                    </div>
                  </div>

                  <div className="bg-[#090b10] border border-slate-800 p-3.5 rounded-xl">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1">
                      p95 Response Latency
                    </span>
                    <div className="text-2xl font-bold font-mono text-white tabular-nums">
                      {latestMetric ? `${latestMetric.p95LatencyMs} ms` : '0 ms'}
                    </div>
                  </div>

                  <div className="bg-[#090b10] border border-slate-800 p-3.5 rounded-xl">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1">
                      Ledger ACID Checks
                    </span>
                    <div className="text-2xl font-bold font-mono text-amber-400 tabular-nums">
                      {latestMetric ? `${latestMetric.ledgerAcidChecksPerSec.toLocaleString()} tps` : '0 tps'}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
