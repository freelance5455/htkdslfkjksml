import React, { useState, useEffect } from 'react';
import { useParentControl } from '../context/ParentControlContext';
import { 
  ShieldAlert, Lock, AlertTriangle, PhoneCall, Battery, Wifi, 
  MapPin, Volume2, ShieldCheck, ArrowRight, Smartphone, Clock, Sparkles,
  QrCode, CheckCircle2
} from 'lucide-react';
import { sirenPlayer } from '../lib/audioAlert';
import { QrScannerModal } from './QrScannerModal';

interface ChildCompanionViewProps {
  onSwitchToParent: () => void;
}

export const ChildCompanionView: React.FC<ChildCompanionViewProps> = ({ onSwitchToParent }) => {
  const { 
    activeDevice, 
    devices,
    activeDeviceId,
    setActiveDeviceId,
    reportChildTelemetry, 
    sendChildSOS, 
    stopEmergencySiren,
    sirenPlaying,
    pairDeviceFromQr,
    language 
  } = useParentControl();

  const [currentTime, setCurrentTime] = useState(new Date());
  const [realBattery, setRealBattery] = useState<number>(activeDevice?.batteryLevel || 84);
  const [isCharging, setIsCharging] = useState(false);
  const [locationStatus, setLocationStatus] = useState<string>('جارِ تحديد الموقع...');
  const [blockedAppAlert, setBlockedAppAlert] = useState<string | null>(null);
  const [activeScreenApp, setActiveScreenApp] = useState<any | null>(null);
  const [sosSent, setSosSent] = useState(false);
  const [isQrScannerOpen, setIsQrScannerOpen] = useState(false);
  const [pairSuccessBanner, setPairSuccessBanner] = useState<string | null>(null);

  const isAr = language === 'ar';
  const isLocked = activeDevice?.settings?.screenLocked;
  const isSirenOn = Boolean(activeDevice?.sirenActive || sirenPlaying);

  // Auto-detect pairing parameters from URL (e.g. when opening from a camera QR scan)
  useEffect(() => {
    if (typeof window !== 'undefined' && window.location.search) {
      const params = new URLSearchParams(window.location.search);
      const pairCode = params.get('pairCode') || params.get('code');
      if (pairCode) {
        const res = pairDeviceFromQr(window.location.search);
        if (res.success) {
          setPairSuccessBanner(res.message);
          setTimeout(() => setPairSuccessBanner(null), 6000);
        }
      }
    }
  }, [pairDeviceFromQr]);

  // Live Clock
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Real Battery API Integration
  useEffect(() => {
    let batteryInstance: any;
    if ('getBattery' in navigator) {
      (navigator as any).getBattery().then((battery: any) => {
        batteryInstance = battery;
        const updateBattery = () => {
          const level = Math.round(battery.level * 100);
          setRealBattery(level);
          setIsCharging(battery.charging);
          reportChildTelemetry(activeDevice.id, {
            batteryLevel: level,
            isCharging: battery.charging
          });
        };
        updateBattery();
        battery.addEventListener('levelchange', updateBattery);
        battery.addEventListener('chargingchange', updateBattery);
      }).catch(console.error);
    }
  }, [activeDevice.id, reportChildTelemetry]);

  // Real Geolocation API Integration
  useEffect(() => {
    if ('geolocation' in navigator) {
      const watchId = navigator.geolocation.watchPosition(
        (pos) => {
          const { latitude, longitude, accuracy } = pos.coords;
          setLocationStatus(`${latitude.toFixed(4)}, ${longitude.toFixed(4)} (دقة ${Math.round(accuracy)}م)`);
          reportChildTelemetry(activeDevice.id, {
            latitude,
            longitude,
            address: `إحداثيات حية (${latitude.toFixed(4)}, ${longitude.toFixed(4)})`
          });
        },
        (err) => {
          console.warn('Geolocation warning:', err.message);
          setLocationStatus('الموقع غير مفعل');
        },
        { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
      );

      return () => navigator.geolocation.clearWatch(watchId);
    }
  }, [activeDevice.id, reportChildTelemetry]);

  const handleLaunchApp = (app: any) => {
    if (isLocked) return;
    if (app.isBlocked) {
      setBlockedAppAlert(app.nameAr || app.name);
      setTimeout(() => setBlockedAppAlert(null), 3000);
    } else {
      setActiveScreenApp(app);
    }
  };

  const handleTriggerSOS = () => {
    sendChildSOS(activeDevice.id);
    setSosSent(true);
    setTimeout(() => setSosSent(false), 5000);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans select-none relative overflow-hidden">
      {/* Top Mobile Status Bar */}
      <div className="w-full bg-black/40 backdrop-blur-md px-4 py-2 flex items-center justify-between text-xs text-slate-300 z-30">
        <span className="font-semibold font-mono tracking-wider">
          {currentTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true })}
        </span>

        {/* Device Switcher for testing */}
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-indigo-400 bg-indigo-950/80 px-2 py-0.5 rounded-full border border-indigo-800">
            {isAr ? 'وضع هاتف الطفل الحقيقي' : 'Child Device Mode'}
          </span>
          <select
            value={activeDeviceId}
            onChange={(e) => setActiveDeviceId(e.target.value)}
            className="bg-slate-800 text-[11px] text-slate-200 rounded px-1.5 py-0.5 border border-slate-700"
          >
            {devices.map(d => (
              <option key={d.id} value={d.id}>{d.childNameAr} ({d.deviceName})</option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2 font-mono">
          <Wifi className="w-3.5 h-3.5 text-slate-300" />
          <div className="flex items-center gap-1">
            <Battery className={`w-3.5 h-3.5 ${realBattery < 20 ? 'text-rose-400' : 'text-emerald-400'}`} />
            <span>{realBattery}%</span>
            {isCharging && <span className="text-[10px] text-amber-400">⚡</span>}
          </div>
        </div>
      </div>

      {/* FLASHING SIREN OVERLAY (when siren is playing) */}
      {isSirenOn && (
        <div className="absolute inset-0 z-50 bg-rose-600/90 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center animate-pulse">
          <div className="w-24 h-24 rounded-full bg-white text-rose-600 flex items-center justify-center mb-4 shadow-2xl animate-bounce">
            <Volume2 className="w-12 h-12" />
          </div>
          <h2 className="text-2xl font-black text-white mb-2">
            🚨 {isAr ? 'صفارة إنذار من ولي الأمر!' : 'Emergency Siren Triggered!'}
          </h2>
          <p className="text-sm text-rose-100 mb-6 max-w-xs">
            {isAr ? 'يقوم ولي الأمر بإصدار صوت رنين مرتفع للعثور على هذا الهاتف.' : 'Parent is ringing this phone at maximum volume.'}
          </p>
          <button
            onClick={stopEmergencySiren}
            className="px-6 py-3 bg-white text-rose-700 font-bold text-sm rounded-2xl shadow-xl hover:bg-rose-50 active:scale-95 transition-all"
          >
            {isAr ? 'إيقاف صوت الصفارة' : 'Silence Siren'}
          </button>
        </div>
      )}

      {/* FULL LOCK SCREEN (when parent locks the device) */}
      {isLocked ? (
        <div className="flex-1 flex flex-col items-center justify-between p-6 bg-gradient-to-b from-rose-950 via-slate-950 to-black text-center z-20 animate-in fade-in duration-300">
          <div className="pt-8">
            <div className="mx-auto w-20 h-20 rounded-3xl bg-rose-600/20 border border-rose-500/40 flex items-center justify-center mb-4 shadow-xl">
              <Lock className="w-10 h-10 text-rose-500 animate-pulse" />
            </div>
            <span className="px-3 py-1 rounded-full bg-rose-500/20 text-rose-400 text-xs font-bold border border-rose-500/30">
              {isAr ? 'الجهاز مقفل مؤقتاً' : 'Device Locked by Parent'}
            </span>
            <h1 className="text-3xl font-extrabold text-white mt-4 mb-2">
              {isAr ? 'وقت الراحة والمذاكرة' : 'Downtime Active'}
            </h1>
            <p className="text-sm text-rose-200/80 max-w-sm mx-auto leading-relaxed mt-2 bg-rose-950/40 p-4 rounded-2xl border border-rose-900/50">
              {activeDevice?.settings?.lockMessage || (isAr ? 'تم قفل هذا الهاتف بواسطة ولي الأمر. يرجى التوقف عن استخدام الجهاز الآن والتركيز على واجباتك أو النوم.' : 'This phone is locked by your parent.')}
            </p>
          </div>

          {/* Emergency Call Options */}
          <div className="w-full max-w-xs space-y-3 pb-6">
            <div className="text-xs text-slate-400 mb-1">
              {isAr ? 'يمكنك فقط الاتصال بولي الأمر في حالة الطوارئ:' : 'Emergency calls allowed only:'}
            </div>
            <a
              href="tel:01000000000"
              className="w-full py-3.5 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-95"
            >
              <PhoneCall className="w-4 h-4" />
              <span>{isAr ? 'اتصال بـ بابا / ماما' : 'Call Dad / Mom'}</span>
            </a>

            <button
              onClick={handleTriggerSOS}
              className={`w-full py-3 px-4 rounded-2xl border font-bold text-xs flex items-center justify-center gap-2 transition-all ${
                sosSent 
                  ? 'bg-rose-600 text-white border-rose-400' 
                  : 'bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border-rose-800/60'
              }`}
            >
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              <span>{sosSent ? (isAr ? 'تم إرسال نداء الاستغاثة لولي الأمر!' : 'SOS Alert Sent!') : (isAr ? 'إرسال نداء استغاثة فوري (SOS)' : 'Send Emergency SOS')}</span>
            </button>
          </div>
        </div>
      ) : activeScreenApp ? (
        /* Running Allowed App Screen */
        <div className="flex-1 flex flex-col bg-slate-950 z-20">
          <div className="p-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <img src={activeScreenApp.icon} alt="" className="w-7 h-7 rounded-lg" />
              <span className="font-bold text-sm text-white">{activeScreenApp.nameAr || activeScreenApp.name}</span>
            </div>
            <button
              onClick={() => setActiveScreenApp(null)}
              className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-xl font-medium"
            >
              {isAr ? 'الخروج للشاشة الرئيسية' : 'Exit to Home'}
            </button>
          </div>

          <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
            <img src={activeScreenApp.icon} alt="" className="w-20 h-20 rounded-2xl mb-4 shadow-xl shadow-indigo-500/10" />
            <h3 className="text-xl font-bold text-white mb-1">{activeScreenApp.nameAr || activeScreenApp.name}</h3>
            <p className="text-xs text-slate-400 mb-4 font-mono">{activeScreenApp.packageName}</p>
            <span className="px-3 py-1 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 text-xs font-semibold">
              {isAr ? 'تطبيق مسموح به من ولي الأمر' : 'Allowed by Parent'}
            </span>
          </div>
        </div>
      ) : (
        /* Normal Child Home Screen */
        <div className="flex-1 flex flex-col justify-between p-6 z-20 overflow-y-auto">
          {/* Child Profile & Header */}
          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center gap-3">
              <img 
                src={activeDevice?.avatarUrl} 
                alt={activeDevice?.childName} 
                className="w-12 h-12 rounded-2xl border-2 border-indigo-500/50 shadow-md object-cover" 
              />
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-1.5">
                  <span>{isAr ? `مرحباً، ${activeDevice?.childNameAr}` : `Hello, ${activeDevice?.childName}`}</span>
                  <span className="text-xs">👋</span>
                </h2>
                <p className="text-xs text-slate-400 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-indigo-400" />
                  <span className="truncate max-w-[180px]">{locationStatus}</span>
                </p>
              </div>
            </div>

            <div className="text-end font-mono">
              <div className="text-2xl font-black text-white">
                {currentTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false })}
              </div>
              <div className="text-[10px] text-slate-400">
                {currentTime.toLocaleDateString(isAr ? 'ar-EG' : 'en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
              </div>
            </div>
          </div>

          {/* Auto-pair Success Alert Banner */}
          {pairSuccessBanner && (
            <div className="my-3 p-3 bg-emerald-950/80 border border-emerald-700 text-white rounded-2xl flex items-center gap-2.5 animate-in slide-in-from-top-2 shadow-lg">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              <span className="text-xs font-bold">{pairSuccessBanner}</span>
            </div>
          )}

          {/* Pair via QR Button Banner */}
          <div className="my-3 p-3 bg-gradient-to-r from-indigo-900/60 to-purple-900/60 border border-indigo-700/60 rounded-2xl flex items-center justify-between gap-3 shadow-lg">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-indigo-500/20 text-indigo-300 flex items-center justify-center">
                <QrCode className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-white">
                  {isAr ? 'إقران الهاتف بولي الأمر عبر QR' : 'Pair Device via Parent QR'}
                </p>
                <p className="text-[11px] text-indigo-200">
                  {isAr ? `رمز الإقران: ${activeDevice?.pairingCode || 'PG-8421'}` : `Pairing Code: ${activeDevice?.pairingCode}`}
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsQrScannerOpen(true)}
              className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5 active:scale-95 transition-all shrink-0"
            >
              <QrCode className="w-3.5 h-3.5" />
              <span>{isAr ? 'مسح الباركود' : 'Scan QR'}</span>
            </button>
          </div>

          {/* Blocked App Toast Alert */}
          {blockedAppAlert && (
            <div className="my-3 p-3 rounded-2xl bg-rose-900/90 border border-rose-700 text-white text-xs flex items-center gap-2 animate-in fade-in slide-in-from-top-2 shadow-lg">
              <ShieldAlert className="w-5 h-5 text-rose-300 shrink-0" />
              <div>
                <div className="font-bold">{isAr ? 'هذا التطبيق محظور!' : 'Application Blocked!'}</div>
                <div className="text-[11px] text-rose-200">
                  {isAr ? `قام ولي الأمر بحظر (${blockedAppAlert}) لحمايتك.` : `Parent has blocked this application.`}
                </div>
              </div>
            </div>
          )}

          {/* Child Apps Grid */}
          <div className="my-6">
            <div className="flex items-center justify-between mb-3 text-xs text-slate-400">
              <span className="font-bold text-slate-300">{isAr ? 'التطبيقات المثبتة' : 'Installed Apps'}</span>
              <span>{activeDevice?.installedApps.length} {isAr ? 'تطبيقات' : 'apps'}</span>
            </div>

            <div className="grid grid-cols-4 gap-4">
              {activeDevice?.installedApps.map((app) => (
                <button
                  key={app.id}
                  onClick={() => handleLaunchApp(app)}
                  className="flex flex-col items-center gap-1.5 p-2 rounded-2xl hover:bg-white/5 active:scale-90 transition-all relative group"
                >
                  <div className="relative">
                    <img 
                      src={app.icon} 
                      alt={app.name} 
                      className="w-13 h-13 rounded-2xl shadow-md group-hover:shadow-indigo-500/20 transition-shadow object-cover" 
                    />
                    {app.isBlocked && (
                      <div className="absolute inset-0 bg-rose-950/80 rounded-2xl flex items-center justify-center border border-rose-500/80">
                        <Lock className="w-5 h-5 text-rose-400" />
                      </div>
                    )}
                  </div>
                  <span className="text-[11px] font-medium text-slate-200 truncate w-14 text-center">
                    {app.nameAr || app.name}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Bottom Actions: SOS & Switch to Parent */}
          <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between gap-3">
            <button
              onClick={handleTriggerSOS}
              className={`flex-1 py-3 px-4 rounded-2xl font-bold text-xs flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all ${
                sosSent 
                  ? 'bg-emerald-600 text-white' 
                  : 'bg-rose-600 hover:bg-rose-700 text-white'
              }`}
            >
              <AlertTriangle className="w-4 h-4" />
              <span>{sosSent ? (isAr ? 'تم إرسال الاستغاثة بنجاح!' : 'SOS Sent to Parent!') : (isAr ? 'زر الاستغاثة (SOS)' : 'Emergency SOS')}</span>
            </button>

            <button
              onClick={onSwitchToParent}
              className="py-3 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs flex items-center gap-1.5 transition-colors"
              title={isAr ? 'العودة للوحة تحكم ولي الأمر (محمية برمز PIN)' : 'Back to Parent Dashboard'}
            >
              <ShieldCheck className="w-4 h-4 text-indigo-400" />
              <span>{isAr ? 'لوحة الأب' : 'Parent'}</span>
            </button>
          </div>
        </div>
      )}

      {/* Decorative subtle background grid */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1f293710_1px,transparent_1px),linear-gradient(to_bottom,#1f293710_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />

      {/* QR Scanner Modal */}
      <QrScannerModal
        isOpen={isQrScannerOpen}
        onClose={() => setIsQrScannerOpen(false)}
        defaultCode={activeDevice?.pairingCode}
        onPairSuccess={(dev) => {
          setPairSuccessBanner(isAr ? `تم إقران الهاتف بنجاح (${dev.childNameAr})!` : `Paired successfully with ${dev.childName}!`);
          setTimeout(() => setPairSuccessBanner(null), 5000);
        }}
      />
    </div>
  );
};
