import React, { useState } from 'react';
import {
  Download,
  Upload,
  Copy,
  Check,
  RefreshCw,
  Trash2,
  Database,
  FileJson,
  ShieldCheck,
  AlertTriangle,
  HardDrive,
  Sparkles,
} from 'lucide-react';
import type { AppDatabase } from '../types/pharmacy.ts';
import {
  exportDatabaseJson,
  importDatabaseJson,
  resetToSampleData,
  clearAllData,
} from '../services/storage.ts';
import { formatDateArabic } from '../utils/calculations.ts';

interface BackupTabProps {
  db: AppDatabase;
  onDatabaseReplaced: (newDb: AppDatabase) => void;
}

export const BackupTab: React.FC<BackupTabProps> = ({ db, onDatabaseReplaced }) => {
  const [copied, setCopied] = useState(false);
  const [importText, setImportText] = useState('');
  const [importStatus, setImportStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const jsonContent = exportDatabaseJson(db);

  // File download
  const handleDownloadFile = () => {
    const blob = new Blob([jsonContent], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const dateStr = new Date().toISOString().split('T')[0];
    a.href = url;
    a.download = `daftari-backup-${dateStr}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Clipboard copy
  const handleCopyClipboard = async () => {
    try {
      await navigator.clipboard.writeText(jsonContent);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      alert('يرجى تحديد النص ونسخه يدوياً');
    }
  };

  // Import JSON text or file
  const handleImportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!importText.trim()) return;

    const result = importDatabaseJson(importText.trim());
    if (result.success && result.data) {
      onDatabaseReplaced(result.data);
      setImportStatus({ type: 'success', message: 'تم استرجاع قاعدة البيانات بنجاح!' });
      setImportText('');
    } else {
      setImportStatus({ type: 'error', message: result.error || 'فشل استيراد البيانات' });
    }
  };

  // File upload input
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        setImportText(content);
        const result = importDatabaseJson(content);
        if (result.success && result.data) {
          onDatabaseReplaced(result.data);
          setImportStatus({ type: 'success', message: 'تم استرجاع الملف بنجاح!' });
        } else {
          setImportStatus({ type: 'error', message: result.error || 'ملف غير صالح' });
        }
      }
    };
    reader.readAsText(file);
  };

  const handleResetSample = () => {
    if (confirm('هل تريد استعادة بيانات العينة التجريبية للصيدليات والمذاخر العراقية؟ سيتم استبدال البيانات الحالية.')) {
      const sample = resetToSampleData();
      onDatabaseReplaced(sample);
      setImportStatus({ type: 'success', message: 'تم تحميل البيانات التجريبية بنجاح!' });
    }
  };

  const handleClearAll = () => {
    if (confirm('تحذير: هل أنت متأكد من تصفير ومسح جميع البيانات بالكامل؟ لا يمكن التراجع إلا إذا كان لديك نسخة احتياطية.')) {
      const empty = clearAllData();
      onDatabaseReplaced(empty);
      setImportStatus({ type: 'success', message: 'تم تصفير قاعدة البيانات.' });
    }
  };

  const dbSizeApprox = Math.round((jsonContent.length / 1024) * 10) / 10;

  return (
    <div className="space-y-4 pb-20 animate-fadeIn">
      {/* Header */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
        <h1 className="text-xl font-black text-slate-900 flex items-center gap-2">
          <Database className="h-6 w-6 text-teal-700" />
          النسخ الاحتياطي وحفظ البيانات
        </h1>
        <p className="text-xs text-slate-500 mt-0.5">
          تصدير واستيراد بياناتك بصيغة JSON لحمايتها من الضياع أو نقلها لهاتف آخر
        </p>
      </div>

      {/* Security & Local Storage Guarantee Banner */}
      <div className="rounded-2xl bg-teal-50 border border-teal-200 p-4 text-xs text-teal-900 flex items-start gap-3">
        <ShieldCheck className="h-5 w-5 text-teal-700 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <div className="font-bold text-teal-950">بياناتك محفوظة محلياً في جهازك 100% (Offline-First)</div>
          <p className="text-teal-800/90 leading-relaxed">
            يعمل التطبيق بدون أي خوادم خارجية ولا تُرسل أي أرقام أو أسعار عبر الإنترنت. لضمان أمان حساباتك، نوصي بتنزيل ملف نسخة احتياطية أسبوعياً وحفظه على جهازك أو إرساله لنفسك عبر الواتساب أو الإيميل.
          </p>
        </div>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center text-xs">
        <div className="rounded-xl bg-white p-3 border border-slate-200 shadow-xs">
          <span className="text-slate-400">عدد الأدوية المسجلة</span>
          <div className="text-base font-black text-slate-900 mt-0.5">
            {db.medicines.length || Object.keys(db.minStockOverrides).length}
          </div>
        </div>
        <div className="rounded-xl bg-white p-3 border border-slate-200 shadow-xs">
          <span className="text-slate-400">فواتير الشراء</span>
          <div className="text-base font-black text-slate-900 mt-0.5">{db.purchases.length}</div>
        </div>
        <div className="rounded-xl bg-white p-3 border border-slate-200 shadow-xs">
          <span className="text-slate-400">فواتير البيع</span>
          <div className="text-base font-black text-slate-900 mt-0.5">{db.sales.length}</div>
        </div>
        <div className="rounded-xl bg-white p-3 border border-slate-200 shadow-xs">
          <span className="text-slate-400">حجم البيانات التقديري</span>
          <div className="text-base font-black text-teal-700 mt-0.5">{dbSizeApprox} KB</div>
        </div>
      </div>

      {/* Status banner */}
      {importStatus && (
        <div
          className={`rounded-xl p-3 text-xs font-bold flex items-center justify-between ${
            importStatus.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-rose-50 text-rose-800 border border-rose-200'
          }`}
        >
          <span>{importStatus.message}</span>
          <button onClick={() => setImportStatus(null)} className="text-slate-400 hover:text-slate-600">
            ×
          </button>
        </div>
      )}

      {/* Export Section */}
      <div className="rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Download className="h-4 w-4 text-teal-700" />
            1. تصدير البيانات (تنزيل نسخة احتياطية)
          </h3>
          <span className="text-xs text-slate-400 font-mono">
            آخر تحديث: {db.updatedAt ? formatDateArabic(db.updatedAt.split('T')[0]) : 'اليوم'}
          </span>
        </div>

        <p className="text-xs text-slate-500">
          احفظ قاعدة البيانات كملف `.json` أو انسخ النص البرمجي لحفظه بأي مكان:
        </p>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={handleDownloadFile}
            className="flex items-center gap-1.5 rounded-xl bg-teal-700 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-teal-800 active:scale-95 transition"
          >
            <Download className="h-4 w-4" />
            تنزيل ملف النسخة الاحتياطية (.json)
          </button>

          <button
            onClick={handleCopyClipboard}
            className="flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 active:scale-95 transition"
          >
            {copied ? <Check className="h-4 w-4 text-emerald-600" /> : <Copy className="h-4 w-4 text-slate-500" />}
            {copied ? 'تم النسخ للحافظة!' : 'نسخ النص للحافظة'}
          </button>
        </div>
      </div>

      {/* Import Section */}
      <div className="rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs space-y-3">
        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <Upload className="h-4 w-4 text-indigo-700" />
          2. استرجاع البيانات (استيراد نسخة احتياطية)
        </h3>

        <p className="text-xs text-slate-500">
          اختر ملف النسخة الاحتياطية من جهازك أو الصق نص الـ JSON في الصندوق أدناه:
        </p>

        <div className="flex items-center gap-3">
          <label className="cursor-pointer inline-flex items-center gap-1.5 rounded-xl bg-indigo-50 border border-indigo-200 px-4 py-2 text-xs font-bold text-indigo-800 hover:bg-indigo-100 transition">
            <Upload className="h-4 w-4" />
            اختيار ملف من الجهاز
            <input type="file" accept=".json,application/json" onChange={handleFileUpload} className="hidden" />
          </label>
        </div>

        <form onSubmit={handleImportSubmit} className="space-y-2">
          <textarea
            value={importText}
            onChange={(e) => setImportText(e.target.value)}
            rows={4}
            placeholder="أو الصق نص JSON هنا مباشرة ثم اضغط استرجاع..."
            dir="ltr"
            className="w-full rounded-xl border border-slate-200 bg-slate-50 p-2.5 text-xs font-mono text-slate-800 focus:border-indigo-500 focus:bg-white focus:outline-hidden"
          />

          <button
            type="submit"
            disabled={!importText.trim()}
            className="rounded-xl bg-indigo-700 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-indigo-800 disabled:opacity-40 transition"
          >
            تأكيد واسترجاع البيانات
          </button>
        </form>
      </div>

      {/* Danger & Reset Tools */}
      <div className="rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs space-y-3">
        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <HardDrive className="h-4 w-4 text-slate-600" />
          إدارة وتجربة النظام
        </h3>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={handleResetSample}
            className="flex items-center gap-1.5 rounded-xl border border-teal-300 bg-teal-50 px-3.5 py-2 text-xs font-bold text-teal-800 hover:bg-teal-100 transition"
          >
            <RefreshCw className="h-4 w-4 text-teal-600" />
            إعادة تحميل البيانات التجريبية العراقية
          </button>

          <button
            onClick={handleClearAll}
            className="flex items-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-2 text-xs font-bold text-rose-700 hover:bg-rose-100 transition"
          >
            <Trash2 className="h-4 w-4 text-rose-600" />
            تصفير ومسح كل السجلات
          </button>
        </div>
      </div>
    </div>
  );
};
