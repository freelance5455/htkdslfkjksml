import React, { useState } from 'react';
import {
  Download,
  Upload,
  Copy,
  Check,
  RefreshCw,
  Trash2,
  Database,
  Cloud,
  AlertTriangle,
  HardDrive,
} from 'lucide-react';
import type { AppDatabase } from '../types/pharmacy.ts';
import {
  exportDatabaseJson,
  importDatabaseJson,
  resetToSampleData,
  clearAllData,
} from '../services/storage.ts';
import { formatDateArabic } from '../utils/calculations.ts';

interface BackupTabProps {
  db: AppDatabase;
  onDatabaseReplaced: (newDb: AppDatabase) => Promise<void> | void;
  onWipeAllCloudData?: () => Promise<void>;
}

export const BackupTab: React.FC<BackupTabProps> = ({
  db,
  onDatabaseReplaced,
  onWipeAllCloudData,
}) => {
  const [copied, setCopied] = useState(false);
  const [importText, setImportText] = useState('');
  const [importStatus, setImportStatus] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);
  const [confirmSample, setConfirmSample] = useState(false);
  const [isBusy, setIsBusy] = useState(false);

  const jsonContent = exportDatabaseJson(db);

  // File download
  const handleDownloadFile = () => {
    const blob = new Blob([jsonContent], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const dateStr = new Date().toISOString().split('T')[0];
    a.href = url;
    a.download = `meshmesh-backup-${dateStr}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Clipboard copy
  const handleCopyClipboard = async () => {
    try {
      await navigator.clipboard.writeText(jsonContent);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setImportStatus({ type: 'error', message: 'تعذر النسخ التلقائي، يرجى تنزيل الملف.' });
    }
  };

  // Import JSON text or file
  const handleImportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!importText.trim()) return;

    const result = importDatabaseJson(importText.trim());
    if (result.success && result.data) {
      setIsBusy(true);
      try {
        await onDatabaseReplaced(result.data);
        setImportStatus({
          type: 'success',
          message: 'تم استرجاع قاعدة البيانات ومزامنتها مع السحابة بنجاح!',
        });
        setImportText('');
      } finally {
        setIsBusy(false);
      }
    } else {
      setImportStatus({ type: 'error', message: result.error || 'فشل استيراد البيانات' });
    }
  };

  // File upload input
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      const content = event.target?.result as string;
      if (content) {
        setImportText(content);
        const result = importDatabaseJson(content);
        if (result.success && result.data) {
          setIsBusy(true);
          try {
            await onDatabaseReplaced(result.data);
            setImportStatus({
              type: 'success',
              message: 'تم استرجاع الملف ومزامنته مع السحابة بنجاح!',
            });
          } finally {
            setIsBusy(false);
          }
        } else {
          setImportStatus({ type: 'error', message: result.error || 'ملف غير صالح' });
        }
      }
    };
    reader.readAsText(file);
  };

  const handleResetSample = async () => {
    setIsBusy(true);
    try {
      const sample = resetToSampleData();
      await onDatabaseReplaced(sample);
      setConfirmSample(false);
      setImportStatus({
        type: 'success',
        message: 'تم تحميل البيانات التجريبية وتحديث السحابة بنجاح!',
      });
    } finally {
      setIsBusy(false);
    }
  };

  const handleClearAll = async () => {
    setIsBusy(true);
    try {
      if (onWipeAllCloudData) {
        await onWipeAllCloudData();
      } else {
        const empty = clearAllData();
        await onDatabaseReplaced(empty);
      }
      setConfirmClear(false);
      setImportStatus({
        type: 'success',
        message: 'تم مسح وتصفير جميع البيانات السحابية والمحلية على كل الأجهزة!',
      });
    } finally {
      setIsBusy(false);
    }
  };

  const dbSizeApprox = Math.round((jsonContent.length / 1024) * 10) / 10;

  return (
    <div className="space-y-4 pb-20 animate-fadeIn">
      {/* Header */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
        <h1 className="text-lg sm:text-xl font-black text-slate-900 flex items-center gap-2">
          <Database className="h-5 w-5 text-teal-700" />
          النسخ الاحتياطي والتحكم ببيانات السحابة
        </h1>
        <p className="text-xs text-slate-500 mt-0.5">
          تصدير واستيراد نسخة احتياطية JSON، أو مسح وتصفير البيانات السحابية من جميع الأجهزة
        </p>
      </div>

      {/* Cloud & Local Sync Banner */}
      <div className="rounded-2xl bg-teal-50 border border-teal-200 p-3.5 text-xs text-teal-900 flex items-start gap-2.5">
        <Cloud className="h-5 w-5 text-teal-700 shrink-0 mt-0.5" />
        <div className="space-y-0.5">
          <div className="font-black text-teal-950">
            حفظ مزدوج: سحابي مباشر + نسخة محلية على جهازك
          </div>
          <p className="text-teal-800/90 leading-relaxed">
            أي استيراد أو تصفير تقوم به هنا ينعكس مباشرة على قاعدة البيانات السحابية المشتركة وعلى جميع الهواتف المربوطة بالتطبيق.
          </p>
        </div>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
        <div className="rounded-xl bg-white p-3 border border-slate-200 shadow-xs">
          <span className="text-slate-500">الأدوية المسجلة</span>
          <div className="text-base font-black font-mono text-slate-900 mt-0.5">
            {db.medicines.length}
          </div>
        </div>
        <div className="rounded-xl bg-white p-3 border border-slate-200 shadow-xs">
          <span className="text-slate-500">فواتير الشراء</span>
          <div className="text-base font-black font-mono text-slate-900 mt-0.5">
            {db.purchases.length}
          </div>
        </div>
        <div className="rounded-xl bg-white p-3 border border-slate-200 shadow-xs">
          <span className="text-slate-500">فواتير البيع</span>
          <div className="text-base font-black font-mono text-slate-900 mt-0.5">
            {db.sales.length}
          </div>
        </div>
        <div className="rounded-xl bg-white p-3 border border-slate-200 shadow-xs">
          <span className="text-slate-500">حجم البيانات</span>
          <div className="text-base font-black font-mono text-teal-700 mt-0.5">
            {dbSizeApprox} KB
          </div>
        </div>
      </div>

      {/* Status banner */}
      {importStatus && (
        <div
          className={`rounded-xl p-3 text-xs font-bold flex items-center justify-between ${
            importStatus.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-rose-50 text-rose-800 border border-rose-200'
          }`}
        >
          <span>{importStatus.message}</span>
          <button
            onClick={() => setImportStatus(null)}
            className="text-slate-400 hover:text-slate-600"
          >
            ×
          </button>
        </div>
      )}

      {/* Danger & Cloud Wipe Tools */}
      <div className="rounded-2xl bg-white p-4 border-2 border-rose-200/80 shadow-xs space-y-3">
        <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
          <HardDrive className="h-4 w-4 text-rose-600" />
          تصفير ومسح البيانات السحابية (على جميع الأجهزة)
        </h3>
        <p className="text-xs text-slate-500">
          يمكنك مسح كافة الفواتير والمواد المسجلة في السحابة لتصفير التطبيق بالكامل على كل الهواتف والحاسبات:
        </p>

        <div className="flex flex-wrap gap-2">
          {!confirmClear ? (
            <button
              type="button"
              disabled={isBusy}
              onClick={() => {
                setConfirmClear(true);
                setConfirmSample(false);
              }}
              className="flex items-center gap-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 px-4 py-2.5 text-xs font-black text-white shadow-xs transition active:scale-95"
            >
              <Trash2 className="h-4 w-4" />
              <span>مسح وتصفير كل البيانات السحابية من جميع الأجهزة</span>
            </button>
          ) : (
            <div className="w-full rounded-xl bg-rose-50 border border-rose-300 p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-black text-rose-950">
                <AlertTriangle className="h-4 w-4 text-rose-600 shrink-0" />
                <span>هل أنت متأكد من مسح كافة البيانات السحابية والمحلية من كل الأجهزة؟</span>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={handleClearAll}
                  className="rounded-xl bg-rose-700 hover:bg-rose-800 text-white px-4 py-1.5 text-xs font-black transition"
                >
                  {isBusy ? 'جاري المسح...' : 'نعم، امسح الكل الآن'}
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmClear(false)}
                  className="rounded-xl bg-white border border-slate-300 px-3 py-1.5 text-xs font-bold text-slate-700"
                >
                  إلغاء
                </button>
              </div>
            </div>
          )}

          {!confirmSample ? (
            <button
              type="button"
              disabled={isBusy}
              onClick={() => {
                setConfirmSample(true);
                setConfirmClear(false);
              }}
              className="flex items-center gap-1.5 rounded-xl border border-teal-300 bg-teal-50 px-3.5 py-2.5 text-xs font-bold text-teal-900 hover:bg-teal-100 transition"
            >
              <RefreshCw className="h-4 w-4 text-teal-700" />
              <span>إعادة تحميل البيانات التجريبية للسحابة</span>
            </button>
          ) : (
            <div className="w-full rounded-xl bg-teal-50 border border-teal-300 p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <span className="text-xs font-black text-teal-950">
                هل تريد استبدال البيانات الحالية ببيانات العينة التجريبية؟
              </span>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={handleResetSample}
                  className="rounded-xl bg-teal-800 hover:bg-teal-900 text-white px-4 py-1.5 text-xs font-black transition"
                >
                  {isBusy ? 'جاري التحميل...' : 'تأكيد تحميل العينة'}
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmSample(false)}
                  className="rounded-xl bg-white border border-slate-300 px-3 py-1.5 text-xs font-bold text-slate-700"
                >
                  إلغاء
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Export Section */}
      <div className="rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Download className="h-4 w-4 text-teal-700" />
            تصدير البيانات (تنزيل نسخة احتياطية)
          </h3>
          <span className="text-xs text-slate-400 font-mono">
            {db.updatedAt ? formatDateArabic(db.updatedAt.split('T')[0]) : 'اليوم'}
          </span>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={handleDownloadFile}
            className="flex items-center gap-1.5 rounded-xl bg-teal-700 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-teal-800 active:scale-95 transition"
          >
            <Download className="h-4 w-4" />
            تنزيل ملف النسخة الاحتياطية (.json)
          </button>

          <button
            onClick={handleCopyClipboard}
            className="flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 active:scale-95 transition"
          >
            {copied ? (
              <Check className="h-4 w-4 text-emerald-600" />
            ) : (
              <Copy className="h-4 w-4 text-slate-500" />
            )}
            {copied ? 'تم النسخ للحافظة!' : 'نسخ النص للحافظة'}
          </button>
        </div>
      </div>

      {/* Import Section */}
      <div className="rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs space-y-3">
        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <Upload className="h-4 w-4 text-indigo-700" />
          استرجاع البيانات (استيراد نسخة احتياطية)
        </h3>

        <div className="flex items-center gap-3">
          <label className="cursor-pointer inline-flex items-center gap-1.5 rounded-xl bg-indigo-50 border border-indigo-200 px-4 py-2 text-xs font-bold text-indigo-800 hover:bg-indigo-100 transition">
            <Upload className="h-4 w-4" />
            اختيار ملف من الجهاز
            <input
              type="file"
              accept=".json,application/json"
              onChange={handleFileUpload}
              className="hidden"
            />
          </label>
        </div>

        <form onSubmit={handleImportSubmit} className="space-y-2">
          <textarea
            value={importText}
            onChange={(e) => setImportText(e.target.value)}
            rows={3}
            placeholder="أو الصق نص JSON هنا مباشرة ثم اضغط استرجاع..."
            dir="ltr"
            className="w-full rounded-xl border border-slate-200 bg-slate-50 p-2.5 text-xs font-mono text-slate-800 focus:border-indigo-500 focus:bg-white focus:outline-hidden"
          />

          <button
            type="submit"
            disabled={!importText.trim() || isBusy}
            className="rounded-xl bg-indigo-700 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-indigo-800 disabled:opacity-40 transition"
          >
            تأكيد واسترجاع البيانات للسحابة
          </button>
        </form>
      </div>
    </div>
  );
};
