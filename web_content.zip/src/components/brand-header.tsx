import { Shield } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export function BrandHeader() {
  return (
    <header className="mb-6 flex flex-col items-center text-center lg:items-start lg:text-left">
      <p className="mb-4 flex items-center gap-1.5 font-display text-xs font-semibold uppercase tracking-[0.22em] text-accent">
        eFootball 2025 / 2026
      </p>
      <div className="mb-3 flex items-center gap-3">
        <div className="flex size-12 items-center justify-center rounded-[var(--radius-lg)] bg-accent text-accent-fg shadow-[var(--shadow-lift)]">
          <Shield className="size-6" strokeWidth={2.2} aria-hidden />
        </div>
        <div className="text-left">
          <h1 className="font-display text-3xl font-semibold tracking-tight text-fg">
            Bruno Gaming
          </h1>
          <p className="font-display text-xs font-medium uppercase tracking-[0.18em] text-muted">
            Pro Account Appraisal
          </p>
        </div>
      </div>
      <Badge>
        <Shield className="size-3" aria-hidden />
        မြန်မာ့ eFootball စျေးကွက်ပေါက်စျေး
      </Badge>
    </header>
  );
}
