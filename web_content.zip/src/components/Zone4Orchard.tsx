import React, { useState } from 'react';
import { useGame } from '../context/GameContext.tsx';
import { SPECIES_MAP, BEE_SPECIES_DATA } from '../data/species.ts';
import { getBeeGachaRate } from '../utils/gameLogic.ts';
import { Shovel, Sparkles, Plus, Clock, Flower2 } from 'lucide-react';

export const Zone4Orchard: React.FC = () => {
  const {
    player,
    orchardSlots,
    beeHives,
    inventory,
    shovelModeActive,
    plantFruitTreeOrMushroom,
    harvestOrchardSlot,
    shovelOrchardSlot,
    graftTreeOrMushroom,
    harvestBeeHive,
    breedBeeGacha,
  } = useGame();

  const [activeTab, setActiveTab] = useState<'trees' | 'mushrooms' | 'bees'>('trees');
  const [selectSlotForPlant, setSelectSlotForPlant] = useState<number | null>(null);

  // Grafting bench state
  const [graftSlot1, setGraftSlot1] = useState<string>('');
  const [graftSlot2, setGraftSlot2] = useState<string>('');
  const [graftResultMsg, setGraftResultMsg] = useState<string | null>(null);

  // Bee Gacha state
  const [selectedBeeForGacha, setSelectedBeeForGacha] = useState<string>(BEE_SPECIES_DATA[0].id);
  const [selectedFlowerForGacha, setSelectedFlowerForGacha] = useState<string>('');
  const [gachaResultMsg, setGachaResultMsg] = useState<string | null>(null);

  const treeSlots = orchardSlots.filter((s) => s.type === 'fruit_tree');
  const mushroomSlots = orchardSlots.filter((s) => s.type === 'mushroom');

  const availableTreeSeeds = inventory.filter((i) => {
    const sp = SPECIES_MAP.get(i.id);
    return sp && sp.category === 'fruit_tree' && i.count > 0;
  });

  const availableMushroomSpores = inventory.filter((i) => {
    const sp = SPECIES_MAP.get(i.id);
    return sp && sp.category === 'mushroom' && i.count > 0;
  });

  const availableFlowers = inventory.filter((i) => {
    const sp = SPECIES_MAP.get(i.id.replace('prod_', ''));
    return sp && sp.category === 'crop_flower' && i.count > 0;
  });

  const now = Date.now();
  const currentPityRate = Math.round(getBeeGachaRate(player.beeGachaPityCount) * 100);

  const handleGraft = () => {
    if (!graftSlot1 || !graftSlot2) return;
    const res = graftTreeOrMushroom(graftSlot1, graftSlot2);
    if (res.success && res.resultSpeciesId) {
      const sp = SPECIES_MAP.get(res.resultSpeciesId);
      setGraftResultMsg(`Ghép thành công giống mới Bậc ${sp?.tier}: ${sp?.name}!`);
    } else {
      setGraftResultMsg('Ghép thất bại! Hãy chắc chắn bạn có đủ 2 giống trong kho.');
    }
  };

  const handleGachaRoll = () => {
    if (!selectedFlowerForGacha) return;
    const res = breedBeeGacha(selectedBeeForGacha, selectedFlowerForGacha);
    if (res.success && res.newBeeId) {
      const b = BEE_SPECIES_DATA.find((x) => x.id === res.newBeeId);
      setGachaResultMsg(`🎉 Chúc mừng! Bạn đã lai tạo thành công: ${b?.name} (Bậc ${b?.tier})!`);
    } else {
      setGachaResultMsg(`Chưa trúng ong mới! Tỷ lệ trúng tăng lên ở lượt kế tiếp (Bảo hiểm: ${res.pity}/5 lần)`);
    }
  };

  return (
    <div className="space-y-4">
      {/* Action Bar */}
      <div className="bg-stone-900/90 border border-stone-800 rounded-xl p-3 shadow-md space-y-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🍎</span>
            <div>
              <h2 className="text-base font-bold text-amber-300">Khu 4: Vườn Quả, Rừng Ong Nấm</h2>
              <p className="text-xs text-stone-400">
                Cây ăn quả lâu năm • Gỗ mục trồng nấm • 10 loài Ong mật & Gacha Lai Hoa Nông Trại
              </p>
            </div>
          </div>
        </div>

        {/* 3 Tabs */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1 border-t border-stone-800 text-xs">
          {[
            { id: 'trees', label: '🍎 Vườn Cây Ăn Quả', count: treeSlots.length },
            { id: 'mushrooms', label: '🍄 Khu Gỗ Trồng Nấm', count: mushroomSlots.length },
            { id: 'bees', label: '🐝 Tổ Ong & Đài Gacha Hoa', count: beeHives.length },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-1.5 rounded-lg border font-bold transition ${
                activeTab === tab.id
                  ? 'bg-amber-500/20 text-amber-300 border-amber-400 shadow-sm'
                  : 'bg-stone-800 text-stone-400 border-stone-700 hover:text-stone-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab 1: Fruit Trees */}
      {activeTab === 'trees' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {treeSlots.map((slot) => {
              const sp = slot.speciesId ? SPECIES_MAP.get(slot.speciesId) : null;
              const isRipe = slot.readyAt && now >= slot.readyAt;
              const remSec = slot.readyAt ? Math.max(0, Math.ceil((slot.readyAt - now) / 1000)) : 0;

              return (
                <div
                  key={slot.id}
                  onClick={() => {
                    if (shovelModeActive && slot.speciesId) {
                      shovelOrchardSlot(slot.id);
                      return;
                    }
                    if (!slot.speciesId) {
                      setSelectSlotForPlant(slot.id);
                      return;
                    }
                    if (isRipe) {
                      harvestOrchardSlot(slot.id);
                    }
                  }}
                  className={`relative h-36 rounded-2xl border-2 p-3 flex flex-col justify-between cursor-pointer select-none transition hover:shadow-lg ${
                    isRipe ? 'bg-amber-950/40 border-amber-400 ring-2 ring-amber-400/50' : 'bg-stone-900 border-stone-800'
                  }`}
                >
                  <div className="flex justify-between items-center text-[10px] text-stone-400 font-bold">
                    <span>Gốc Cây #{slot.id + 1}</span>
                    {sp && <span className="text-amber-400">Bậc {sp.tier}</span>}
                  </div>

                  <div className="flex flex-col items-center justify-center text-center">
                    {sp ? (
                      <>
                        <span className={`text-4xl mb-1 ${isRipe ? 'animate-bounce' : ''}`}>{sp.icon}</span>
                        <span className="text-xs font-bold text-stone-200">{sp.name}</span>
                      </>
                    ) : (
                      <div className="flex flex-col items-center text-stone-500">
                        <Plus className="w-6 h-6 mb-1 opacity-60" />
                        <span className="text-xs font-semibold">Trồng Cây Quả</span>
                      </div>
                    )}
                  </div>

                  <div className="text-center text-[10px] font-bold">
                    {isRipe ? (
                      <span className="bg-amber-400 text-stone-950 px-2 py-0.5 rounded-full font-black animate-pulse">
                        ✨ Thu Hoạch Quả!
                      </span>
                    ) : sp ? (
                      <div className="flex items-center justify-center gap-1 text-stone-400">
                        <Clock className="w-3 h-3 text-amber-400" />
                        <span>{remSec}s</span>
                      </div>
                    ) : (
                      <span className="text-stone-500">Nhấn để chọn giống</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Grafting Bench for Fruit Trees & Mushrooms */}
          <div className="bg-stone-900/90 border border-amber-600/40 rounded-2xl p-4 shadow-md space-y-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-400" />
              <h3 className="font-bold text-amber-300 text-sm sm:text-base">
                Bàn Ghép Giống Cây Quả & Cấy Phôi Nấm (5 Bậc)
              </h3>
            </div>
            <p className="text-xs text-stone-400">
              Ghép 2 hạt giống cây quả hoặc 2 phôi nấm để nâng cấp mở khóa giống mới bậc cao hơn!
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
              <div>
                <label className="block text-stone-400 mb-1 font-semibold">Giống Thứ Nhất:</label>
                <select
                  value={graftSlot1}
                  onChange={(e) => setGraftSlot1(e.target.value)}
                  className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-200"
                >
                  <option value="">-- Chọn giống 1 --</option>
                  {[...availableTreeSeeds, ...availableMushroomSpores].map((i) => (
                    <option key={i.id} value={i.id}>
                      {i.name} (Có: {i.count})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-stone-400 mb-1 font-semibold">Giống Thứ Hai:</label>
                <select
                  value={graftSlot2}
                  onChange={(e) => setGraftSlot2(e.target.value)}
                  className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-200"
                >
                  <option value="">-- Chọn giống 2 --</option>
                  {[...availableTreeSeeds, ...availableMushroomSpores].map((i) => (
                    <option key={i.id} value={i.id}>
                      {i.name} (Có: {i.count})
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-end">
                <button
                  type="button"
                  onClick={handleGraft}
                  className="w-full py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-black rounded-lg shadow transition"
                >
                  🧬 Ghép Giống Ngay
                </button>
              </div>
            </div>

            {graftResultMsg && (
              <div className="p-2 rounded-lg bg-amber-950/60 border border-amber-500/50 text-amber-200 text-xs font-semibold">
                {graftResultMsg}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 2: Mushrooms */}
      {activeTab === 'mushrooms' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {mushroomSlots.map((slot) => {
              const sp = slot.speciesId ? SPECIES_MAP.get(slot.speciesId) : null;
              const isRipe = slot.readyAt && now >= slot.readyAt;
              const remSec = slot.readyAt ? Math.max(0, Math.ceil((slot.readyAt - now) / 1000)) : 0;

              return (
                <div
                  key={slot.id}
                  onClick={() => {
                    if (shovelModeActive && slot.speciesId) {
                      shovelOrchardSlot(slot.id);
                      return;
                    }
                    if (!slot.speciesId) {
                      setSelectSlotForPlant(slot.id);
                      return;
                    }
                    if (isRipe) {
                      harvestOrchardSlot(slot.id);
                    }
                  }}
                  className={`relative h-36 rounded-2xl border-2 p-3 flex flex-col justify-between cursor-pointer select-none transition hover:shadow-lg ${
                    isRipe ? 'bg-amber-950/40 border-amber-400 ring-2 ring-amber-400/50' : 'bg-stone-900 border-stone-800'
                  }`}
                >
                  <div className="flex justify-between items-center text-[10px] text-stone-400 font-bold">
                    <span>Gốc Nấm #{slot.id + 1}</span>
                    {sp && <span className="text-amber-400">Bậc {sp.tier}</span>}
                  </div>

                  <div className="flex flex-col items-center justify-center text-center">
                    {sp ? (
                      <>
                        <span className={`text-4xl mb-1 ${isRipe ? 'animate-bounce' : ''}`}>{sp.icon}</span>
                        <span className="text-xs font-bold text-stone-200">{sp.name}</span>
                      </>
                    ) : (
                      <div className="flex flex-col items-center text-stone-500">
                        <Plus className="w-6 h-6 mb-1 opacity-60" />
                        <span className="text-xs font-semibold">Cấy Phôi Nấm</span>
                      </div>
                    )}
                  </div>

                  <div className="text-center text-[10px] font-bold">
                    {isRipe ? (
                      <span className="bg-amber-400 text-stone-950 px-2 py-0.5 rounded-full font-black animate-pulse">
                        ✨ Thu Hoạch Nấm!
                      </span>
                    ) : sp ? (
                      <div className="flex items-center justify-center gap-1 text-stone-400">
                        <Clock className="w-3 h-3 text-amber-400" />
                        <span>{remSec}s</span>
                      </div>
                    ) : (
                      <span className="text-stone-500">Nhấn để cấy phôi</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 3: Bees & Flower Gacha */}
      {activeTab === 'bees' && (
        <div className="space-y-4">
          {/* Active Bee Hives */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {beeHives.map((hive) => {
              const bee = BEE_SPECIES_DATA.find((b) => b.id === hive.beeSpeciesId) || BEE_SPECIES_DATA[0];
              const isRipe = now >= hive.readyAt;
              const remSec = Math.max(0, Math.ceil((hive.readyAt - now) / 1000));

              return (
                <div
                  key={hive.id}
                  className={`bg-stone-900 border-2 rounded-2xl p-3.5 shadow-md flex flex-col justify-between space-y-2 ${
                    isRipe ? 'border-amber-400 bg-amber-950/20 ring-2 ring-amber-400/40' : 'border-stone-800'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-3xl p-1 bg-stone-800 rounded-xl">{bee.icon}</span>
                      <div>
                        <h4 className="font-bold text-stone-100 text-sm">{bee.name}</h4>
                        <span className="text-[10px] text-amber-400 font-semibold">Bậc {bee.tier}</span>
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-stone-400 italic bg-stone-950/60 p-2 rounded-lg border border-stone-800">
                    Lợi ích: <strong className="text-emerald-300">{bee.perk}</strong>
                  </p>

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-xs text-stone-300">
                      Tạo: {bee.honeyIcon} <strong>{bee.honey}</strong>
                    </span>

                    {isRipe ? (
                      <button
                        type="button"
                        onClick={() => harvestBeeHive(hive.id)}
                        className="px-3 py-1 bg-amber-400 hover:bg-amber-300 text-stone-950 font-black text-xs rounded-lg animate-pulse"
                      >
                        Thu Mật!
                      </button>
                    ) : (
                      <div className="flex items-center gap-1 text-xs text-stone-400 bg-stone-800 px-2 py-1 rounded-lg">
                        <Clock className="w-3 h-3 text-amber-400" />
                        <span>{remSec}s</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Bee Flower Gacha Station (6-Roll Pity) */}
          <div className="bg-stone-900/90 border-2 border-pink-500/40 rounded-2xl p-4 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Flower2 className="w-5 h-5 text-pink-400 animate-spin-slow" />
                <h3 className="font-bold text-pink-300 text-sm sm:text-base">
                  Đài Gacha Lai Tạo Ong Với Hoa Nông Trại
                </h3>
              </div>

              {/* Pity Counter */}
              <div className="text-xs bg-stone-800 px-3 py-1 rounded-xl border border-pink-500/30 text-stone-200">
                <span>Bảo hiểm trúng 100%: </span>
                <strong className="text-pink-400 font-black">{player.beeGachaPityCount}/5</strong>
                <span className="text-stone-400 text-[10px] ml-1">
                  ({currentPityRate}% tỷ lệ lượt này)
                </span>
              </div>
            </div>

            <p className="text-xs text-stone-300">
              Kết hợp Ong hiện tại + Hoa màu thu hoạch từ Khu 1 để lai tạo 10 loài Ong thuộc 5 Bậc. Sau 5 lần trượt, lần thứ 6 cam kết trúng 100%!
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="block text-stone-400 mb-1 font-semibold">Chọn Ong Thụ Phấn:</label>
                <select
                  value={selectedBeeForGacha}
                  onChange={(e) => setSelectedBeeForGacha(e.target.value)}
                  className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-200"
                >
                  {BEE_SPECIES_DATA.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.icon} {b.name} (Bậc {b.tier})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-stone-400 mb-1 font-semibold">Chọn Hoa Nông Trại (Khu 1):</label>
                <select
                  value={selectedFlowerForGacha}
                  onChange={(e) => setSelectedFlowerForGacha(e.target.value)}
                  className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-200"
                >
                  <option value="">-- Chọn loài hoa --</option>
                  {availableFlowers.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.name} (Có: {f.count})
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-end">
                <button
                  type="button"
                  disabled={!selectedFlowerForGacha}
                  onClick={handleGachaRoll}
                  className={`w-full py-2.5 rounded-xl font-black text-xs transition shadow-md ${
                    selectedFlowerForGacha
                      ? 'bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-400 hover:to-rose-400 text-white'
                      : 'bg-stone-800 text-stone-500 cursor-not-allowed'
                  }`}
                >
                  🎲 Thụ Phấn Gacha ({currentPityRate}%)
                </button>
              </div>
            </div>

            {gachaResultMsg && (
              <div className="p-2.5 rounded-xl bg-pink-950/60 border border-pink-500/50 text-pink-200 text-xs font-semibold animate-pulse">
                {gachaResultMsg}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modal: Select Fruit Tree / Mushroom Seed */}
      {selectSlotForPlant !== null && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="bg-stone-900 border-2 border-stone-700 rounded-2xl max-w-sm w-full p-4 shadow-2xl space-y-3">
            <div className="flex items-center justify-between border-b border-stone-800 pb-2">
              <h3 className="font-bold text-amber-300 text-sm flex items-center gap-1.5">
                <span>🌱</span> Chọn Giống Cây Quả / Nấm
              </h3>
              <button
                type="button"
                onClick={() => setSelectSlotForPlant(null)}
                className="text-stone-400 hover:text-stone-100 font-bold px-2 py-0.5 rounded bg-stone-800"
              >
                ✕ Đóng
              </button>
            </div>

            <div className="space-y-2 text-xs max-h-64 overflow-y-auto">
              {[...availableTreeSeeds, ...availableMushroomSpores].length === 0 ? (
                <div className="text-center py-6 text-stone-400">
                  <p>Bạn không có hạt giống cây quả hoặc phôi nấm nào!</p>
                  <p className="mt-1 text-amber-400">Hãy ghép giống trên bàn ghép hoặc mua từ Cảng.</p>
                </div>
              ) : (
                [...availableTreeSeeds, ...availableMushroomSpores].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      plantFruitTreeOrMushroom(selectSlotForPlant, item.id);
                      setSelectSlotForPlant(null);
                    }}
                    className="w-full flex items-center justify-between p-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 border border-stone-700 text-left text-stone-200"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">{item.icon}</span>
                      <div>
                        <div className="font-bold">{item.name}</div>
                        <div className="text-[10px] text-stone-400">Có: {item.count}</div>
                      </div>
                    </div>
                    <span className="font-bold text-amber-400">Trồng</span>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
