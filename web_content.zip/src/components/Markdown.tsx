import { useEffect, useMemo, useRef } from 'react';
import { marked } from 'marked';
import DOMPurify from 'dompurify';
import renderMathInElement from 'katex/contrib/auto-render';
import { cn } from '../lib/utils';

marked.setOptions({ breaks: true, gfm: true });

/**
 * Renders tutor markdown. HTML is sanitised, then KaTeX typesets $...$ / $$...$$
 * inside the sanitised output.
 */
export function Markdown({ content, className }: { content: string; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);

  const html = useMemo(() => {
    const raw = marked.parse(content ?? '', { async: false }) as string;
    return DOMPurify.sanitize(raw, {
      ADD_TAGS: ['math', 'mrow', 'mi', 'mo', 'mn', 'msup', 'msub', 'mfrac', 'msqrt', 'annotation'],
      ADD_ATTR: ['target', 'rel'],
    });
  }, [content]);

  useEffect(() => {
    if (!ref.current) return;
    try {
      renderMathInElement(ref.current, {
        delimiters: [
          { left: '$$', right: '$$', display: true },
          { left: '\\[', right: '\\]', display: true },
          { left: '$', right: '$', display: false },
          { left: '\\(', right: '\\)', display: false },
        ],
        throwOnError: false,
        strict: false,
      });
    } catch {
      /* malformed math should never break the page */
    }
  }, [html]);

  return <div ref={ref} className={cn('prose-chat', className)} dangerouslySetInnerHTML={{ __html: html }} />;
}
