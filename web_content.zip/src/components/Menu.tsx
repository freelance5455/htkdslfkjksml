import { useEffect, useRef, useState } from 'react';
import type { Mode } from '../game/match';
import type { Difficulty } from '../game/bot';
import type { Settings, Stats } from '../game/settings';
import { Sim, JOINT_IDS, TURN_STEPS } from '../game/physics';
import { PRESETS, presetStates } from '../game/presets';
import { draw, newView, updateView } from '../game/render';
import { initAudio } from '../game/audio';
import { cn } from '../utils/cn';

interface Props {
  settings: Settings;
  stats: Stats;
  onSettings: (s: Settings) => void;
  onPlay: (mode: Mode, difficulty: Difficulty) => void;
  onResetStats: () => void;
}

type Page = 'main' | 'play' | 'howto' | 'settings';

export default function Menu({ settings, stats, onSettings, onPlay, onResetStats }: Props) {
  const [page, setPage] = useState<Page>('main');
  const [diff, setDiff] = useState<Difficulty>('normal');

  return (
    <div className="fixed inset-0 overflow-hidden bg-slate-950 text-white">
      <Backdrop />
      <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/30 to-black/80 landscape:bg-gradient-to-r landscape:from-black/85 landscape:via-black/40 landscape:to-black/20" />

      <div className="absolute inset-0 flex flex-col items-center justify-center gap-5 overflow-y-auto p-5 landscape:flex-row landscape:items-center landscape:justify-start landscape:gap-10 landscape:px-[8vw]">
        {/* title */}
        <div className="shrink-0 text-center landscape:text-left">
          <div className="text-[10px] font-bold tracking-[0.5em] text-white/50">TURN-BASED PHYSICS FIGHTING</div>
          <h1 className="mt-1 bg-gradient-to-b from-white via-red-200 to-red-600 bg-clip-text text-5xl font-black italic tracking-tight text-transparent drop-shadow-[0_4px_0_rgba(0,0,0,0.6)] sm:text-6xl landscape:text-5xl">
            TORIBASH
          </h1>
          <div className="-mt-1 inline-block -skew-x-12 bg-red-600 px-3 py-0.5 text-sm font-black tracking-[0.5em]">MOBILE</div>
          {page === 'main' && (
            <div className="mt-3 text-xs text-white/50">
              Record <b className="text-green-300">{stats.wins}W</b> · <b className="text-red-300">{stats.losses}L</b> · <b className="text-white/70">{stats.draws}D</b>
              {stats.best > 0 && <> · Best damage {stats.best}</>}
            </div>
          )}
        </div>

        {/* pages */}
        <div className="w-full max-w-xs shrink-0 space-y-2.5 landscape:max-h-full landscape:overflow-y-auto landscape:py-2">
          {page === 'main' && (
            <>
              <MenuBtn primary onClick={() => { initAudio(); setPage('play'); }}>
                ▶ Play
              </MenuBtn>
              <MenuBtn onClick={() => onPlay('practice', diff)}>🥋 Practice (dummy)</MenuBtn>
              <MenuBtn onClick={() => setPage('howto')}>❓ How to play</MenuBtn>
              <MenuBtn onClick={() => setPage('settings')}>⚙ Settings</MenuBtn>
              <FullscreenBtn />
              <p className="pt-1 text-center text-[10px] text-white/30 landscape:text-left">Fan-made tribute. Best played in landscape.</p>
            </>
          )}

          {page === 'play' && (
            <>
              <SectionTitle>Choose a match</SectionTitle>
              <div className="rounded-xl bg-white/5 p-2 ring-1 ring-white/10">
                <div className="mb-1.5 px-1 text-[11px] font-bold uppercase tracking-wider text-white/50">Bot difficulty</div>
                <div className="grid grid-cols-3 gap-1.5">
                  {(['easy', 'normal', 'hard'] as Difficulty[]).map((d) => (
                    <button
                      key={d}
                      onClick={() => setDiff(d)}
                      className={cn(
                        'h-10 rounded-lg text-sm font-bold capitalize',
                        diff === d ? 'bg-red-600 text-white' : 'bg-slate-800 text-white/70'
                      )}
                    >
                      {d}
                    </button>
                  ))}
                </div>
              </div>
              <MenuBtn primary onClick={() => onPlay('bot', diff)}>
                🤖 Versus Bot
              </MenuBtn>
              <MenuBtn onClick={() => onPlay('local', diff)}>👥 Two players (same phone)</MenuBtn>
              <MenuBtn onClick={() => onPlay('practice', diff)}>🥋 Practice</MenuBtn>
              <MenuBtn onClick={() => setPage('main')}>← Back</MenuBtn>
            </>
          )}

          {page === 'howto' && (
            <>
              <SectionTitle>How to play</SectionTitle>
              <div className="space-y-2 rounded-xl bg-white/5 p-3 text-[13px] leading-snug text-white/80 ring-1 ring-white/10">
                <p>
                  <b>1. Plan.</b> Tap a coloured joint on your fighter (the <span className="text-blue-300">blue</span> one on the left) and choose what it does.
                </p>
                <ul className="space-y-1 pl-1 text-xs">
                  <li><Dot c="#ef4444" /> <b>Contract</b> – bend / pull the joint</li>
                  <li><Dot c="#22c55e" /> <b>Extend</b> – straighten / push the joint</li>
                  <li><Dot c="#facc15" /> <b>Hold</b> – lock at its current angle</li>
                  <li><Dot c="#38bdf8" /> <b>Relax</b> – go limp like a ragdoll</li>
                </ul>
                <p>
                  <b>2. Ready.</b> Both fighters move at once for half a second of real physics. Then plan again.
                </p>
                <p>
                  <b>3. Hit.</b> Hard hits to the head, torso and groin score damage. Hands and feet are tough, so use them as weapons. Hit hard enough to <b>dismember</b>.
                </p>
                <p>
                  <b>Tips:</b> use quick moves (👊 🦵) as a starting point, switch on ✊ Grip for a wrist to grab, pinch to zoom and drag to pan. Momentum carries over between turns!
                </p>
              </div>
              <MenuBtn onClick={() => setPage('main')}>← Back</MenuBtn>
            </>
          )}

          {page === 'settings' && (
            <>
              <SectionTitle>Settings</SectionTitle>
              <div className="space-y-2 rounded-xl bg-white/5 p-3 ring-1 ring-white/10">
                <Choice
                  label="Turns per match"
                  value={settings.turns}
                  options={[6, 10, 12, 20]}
                  onChange={(v) => onSettings({ ...settings, turns: v })}
                />
                <Choice
                  label="Turn timer"
                  value={settings.turnTime}
                  options={[0, 15, 25, 40]}
                  fmt={(v) => (v === 0 ? '∞' : v + 's')}
                  onChange={(v) => onSettings({ ...settings, turnTime: v })}
                />
                <Toggle label="Dismemberment" value={settings.dismember} onChange={(v) => onSettings({ ...settings, dismember: v })} />
                <Toggle label="Impact slow-motion" value={settings.slowmo} onChange={(v) => onSettings({ ...settings, slowmo: v })} />
                <Toggle label="Sound" value={settings.sound} onChange={(v) => onSettings({ ...settings, sound: v })} />
                <Toggle label="Vibration" value={settings.vibrate} onChange={(v) => onSettings({ ...settings, vibrate: v })} />
              </div>
              <MenuBtn onClick={onResetStats}>Reset record</MenuBtn>
              <MenuBtn onClick={() => setPage('main')}>← Back</MenuBtn>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- widgets
function MenuBtn({ children, onClick, primary }: { children: React.ReactNode; onClick: () => void; primary?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'flex h-12 w-full items-center justify-center rounded-xl text-[15px] font-bold tracking-wide shadow-lg transition active:scale-[0.97]',
        primary
          ? 'bg-gradient-to-b from-red-500 to-red-700 text-white shadow-red-900/50 ring-1 ring-red-300/40'
          : 'bg-slate-900/80 text-white/90 ring-1 ring-white/15 backdrop-blur hover:bg-slate-800'
      )}
    >
      {children}
    </button>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return <div className="text-center text-xs font-bold uppercase tracking-[0.35em] text-white/60 landscape:text-left">{children}</div>;
}

function Dot({ c }: { c: string }) {
  return <span className="mr-1 inline-block h-3 w-3 rounded-full align-middle ring-1 ring-black" style={{ background: c }} />;
}

function Toggle({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!value)} className="flex h-10 w-full items-center justify-between rounded-lg px-1 text-sm font-semibold">
      <span>{label}</span>
      <span className={cn('relative h-6 w-11 rounded-full transition', value ? 'bg-green-500' : 'bg-slate-700')}>
        <span className={cn('absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all', value ? 'left-[22px]' : 'left-0.5')} />
      </span>
    </button>
  );
}

function Choice({ label, value, options, onChange, fmt }: { label: string; value: number; options: number[]; onChange: (v: number) => void; fmt?: (v: number) => string }) {
  return (
    <div>
      <div className="mb-1 px-1 text-sm font-semibold">{label}</div>
      <div className="grid grid-cols-4 gap-1.5">
        {options.map((o) => (
          <button
            key={o}
            onClick={() => onChange(o)}
            className={cn('h-9 rounded-lg text-sm font-bold', value === o ? 'bg-red-600' : 'bg-slate-800 text-white/70')}
          >
            {fmt ? fmt(o) : o}
          </button>
        ))}
      </div>
    </div>
  );
}

function FullscreenBtn() {
  return (
    <MenuBtn
      onClick={async () => {
        try {
          if (!document.fullscreenElement) {
            await document.documentElement.requestFullscreen();
            const o = screen.orientation as ScreenOrientation & { lock?: (o: string) => Promise<void> };
            await o.lock?.('landscape');
          } else {
            await document.exitFullscreen();
          }
        } catch {
          /* not supported */
        }
      }}
    >
      ⛶ Fullscreen / landscape
    </MenuBtn>
  );
}

// -------------------------------------------- live fighting demo backdrop
function Backdrop() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current!;
    const ctx = canvas.getContext('2d')!;
    const view = newView();
    let sim = new Sim({ dismember: false });
    let turn = 0;
    let steps = 0;
    let raf = 0;
    let last = performance.now();
    let acc = 0;

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      view.w = w;
      view.h = h;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener('resize', resize);

    const plan = () => {
      for (const f of sim.fighters) {
        const p = PRESETS[Math.floor(Math.random() * PRESETS.length)];
        const st = presetStates(p);
        for (const i of JOINT_IDS) f.state[i] = st[i];
      }
      sim.beginTurn();
      steps = TURN_STEPS;
      turn++;
    };
    plan();

    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      acc += dt * 0.8;
      let g = 0;
      while (acc >= 1 / 60 && g++ < 4) {
        acc -= 1 / 60;
        sim.step();
        sim.events.length = 0;
        steps--;
        if (steps <= 0) {
          if (turn >= 9) {
            sim = new Sim({ dismember: false });
            turn = 0;
          }
          plan();
        }
      }
      updateView(view, sim, dt);
      view.zoom = 1;
      draw(ctx, { sim, view, particles: [], popups: [], selected: null, selectedFighter: 0, markers: [0, 0], shake: 0, time: now / 1000, dismemberOn: false });
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
    };
  }, []);
  return <canvas ref={ref} className="absolute inset-0 h-full w-full" />;
}
