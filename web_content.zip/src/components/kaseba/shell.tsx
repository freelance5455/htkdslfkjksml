import { useState } from "react";
import { BookOpen, Grid2x2, Home, Mic, Package, Plus, Users } from "lucide-react";
import { useLedger } from "@/lib/accounting/store";
import type { View } from "@/lib/accounting/types";
import { cn } from "@/lib/cn";
import { AssistantView } from "./assistant";
import { BooksView } from "./books";
import { Dashboard } from "./dashboard";
import { GoodsView } from "./goods";
import { InvoiceView } from "./invoice";
import {
  AssetsView,
  ControlView,
  ExcelView,
  MoreMenu,
  OpsView,
  ProductionView,
  PurchaseView,
  SettingsView,
  TreasuryView,
} from "./more";
import { PartiesView } from "./parties";
import { PrintOverlay } from "./print-view";
import { Mark, Sheet } from "./ui";

const TITLES: Record<View, string> = {
  home: "خانه",
  goods: "کالاها",
  parties: "مشتری‌ها و فروشنده‌ها",
  invoice: "فاکتور فروش جدید",
  assistant: "دستیار کاسبا",
  ops: "عملیات روزانه",
  books: "دفاتر",
  excel: "اکسل",
  treasury: "خزانه‌داری",
  assets: "دارایی و استهلاک",
  production: "تولید",
  purchase: "خرید کالا",
  control: "کنترل روزانه",
  settings: "تنظیمات",
  more: "بیشتر",
};

function backOf(view: View): View | null {
  if (view === "home" || view === "goods" || view === "assistant" || view === "more") return null;
  if (view === "invoice") return "home";
  return "more";
}

export function AppShell() {
  const view = useLedger((s) => s.view);
  const setView = useLedger((s) => s.setView);
  const resetDraft = useLedger((s) => s.resetDraft);
  const [createOpen, setCreateOpen] = useState(false);
  const back = backOf(view);
  const tab = view === "home" ? "home" : view === "goods" ? "goods" : view === "assistant" ? "assistant" : view === "invoice" ? "" : "more";

  return (
    <div className="min-h-dvh bg-canvas text-ink">
      <div className="mx-auto grid min-h-dvh max-w-6xl md:grid-cols-[16rem_minmax(0,1fr)]">
        <aside className="no-print sticky top-0 hidden h-dvh flex-col bg-navy px-4 py-6 text-on-navy md:flex">
          <div className="flex items-center gap-3">
            <Mark />
            <div>
              <p className="text-lg font-extrabold">کاسبا</p>
              <p className="text-xs text-on-navy/70">دفتر فروش و سند دوبل</p>
            </div>
          </div>
          <div className="mt-4 h-px bg-gold/70" />
          <nav className="mt-4 grid gap-1">
            <SideLink icon={Home} label="خانه" on={view === "home"} onClick={() => setView("home")} />
            <SideLink icon={Package} label="کالاها" on={view === "goods"} onClick={() => setView("goods")} />
            <SideLink icon={Users} label="اشخاص" on={view === "parties"} onClick={() => setView("parties")} />
            <SideLink
              icon={Plus}
              label="فاکتور جدید"
              on={view === "invoice"}
              onClick={() => {
                resetDraft(null);
                setView("invoice");
              }}
            />
            <SideLink icon={Mic} label="دستیار" on={view === "assistant"} onClick={() => setView("assistant")} />
            <SideLink icon={BookOpen} label="دفاتر" on={view === "books"} onClick={() => setView("books")} />
            <SideLink icon={Grid2x2} label="بیشتر" on={view === "more"} onClick={() => setView("more")} />
          </nav>
        </aside>
        <div className="min-w-0">
          {view !== "home" && (
            <header className="no-print sticky top-0 z-20 flex items-center gap-2 bg-canvas/95 px-4 py-3 backdrop-blur md:px-6">
              {back && (
                <button type="button" onClick={() => setView(back)} className="grid size-10 place-items-center rounded-full bg-surface text-lg" aria-label="بازگشت">
                  ›
                </button>
              )}
              <h1 className="text-lg font-extrabold">{TITLES[view]}</h1>
            </header>
          )}
          <main className="px-4 pb-32 md:px-6 md:pb-8">
            {view === "home" && <Dashboard />}
            {view === "goods" && <GoodsView />}
            {view === "parties" && <PartiesView />}
            {view === "invoice" && <InvoiceView />}
            {view === "assistant" && <AssistantView />}
            {view === "ops" && <OpsView />}
            {view === "books" && <BooksView />}
            {view === "excel" && <ExcelView />}
            {view === "treasury" && <TreasuryView />}
            {view === "assets" && <AssetsView />}
            {view === "production" && <ProductionView />}
            {view === "purchase" && <PurchaseView />}
            {view === "control" && <ControlView />}
            {view === "settings" && <SettingsView />}
            {view === "more" && <MoreMenu />}
          </main>
        </div>
      </div>

      <nav className="no-print fixed inset-x-0 bottom-0 z-40 px-3 pb-3 md:hidden">
        <div className="relative mx-auto grid max-w-lg grid-cols-5 items-end rounded-3xl bg-navy px-1 pb-2 pt-3 text-on-navy shadow-lg">
          <DockBtn label="خانه" on={tab === "home"} onClick={() => setView("home")} icon={Home} />
          <DockBtn label="کالاها" on={tab === "goods"} onClick={() => setView("goods")} icon={Package} />
          <span />
          <DockBtn label="دستیار" on={tab === "assistant"} onClick={() => setView("assistant")} icon={Mic} />
          <DockBtn label="بیشتر" on={tab === "more"} onClick={() => setView("more")} icon={Grid2x2} />
          <button
            type="button"
            aria-label="ثبت جدید"
            onClick={() => setCreateOpen(true)}
            className="absolute left-1/2 top-0 grid size-14 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-primary text-on-primary shadow-md"
          >
            <Plus className="size-7" />
          </button>
        </div>
      </nav>

      <Sheet open={createOpen} title="ثبت تازه" onClose={() => setCreateOpen(false)}>
        <div className="grid gap-2">
          <BtnNav
            title="فاکتور فروش"
            onClick={() => {
              resetDraft(null);
              setView("invoice");
              setCreateOpen(false);
            }}
          />
          <BtnNav
            title="خرید کالا"
            onClick={() => {
              setView("purchase");
              setCreateOpen(false);
            }}
          />
          <BtnNav
            title="دریافت و خزانه‌داری"
            onClick={() => {
              setView("treasury");
              setCreateOpen(false);
            }}
          />
          <BtnNav
            title="تولید و بهای تمام‌شده"
            onClick={() => {
              setView("production");
              setCreateOpen(false);
            }}
          />
        </div>
      </Sheet>
      <PrintOverlay />
    </div>
  );
}

function SideLink({
  icon: Icon,
  label,
  on,
  onClick,
}: {
  icon: typeof Home;
  label: string;
  on: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn("flex h-11 items-center gap-2 rounded-xl px-3 text-sm font-semibold", on ? "bg-on-navy/15 text-on-navy" : "text-on-navy/70")}
    >
      <Icon className="size-4" />
      {label}
    </button>
  );
}

function DockBtn({
  icon: Icon,
  label,
  on,
  onClick,
}: {
  icon: typeof Home;
  label: string;
  on: boolean;
  onClick: () => void;
}) {
  return (
    <button type="button" onClick={onClick} className={cn("flex flex-col items-center gap-1 py-1 text-xs", on ? "text-on-navy" : "text-on-navy/60")}>
      <Icon className="size-5" />
      {label}
    </button>
  );
}

function BtnNav({ title, onClick }: { title: string; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="h-12 rounded-xl bg-canvas text-sm font-bold">
      {title}
    </button>
  );
}
