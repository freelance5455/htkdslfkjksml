import { useMemo, useState, useEffect } from "react";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { kardexValue, kpisOf, salesSeries, trialOf } from "@/lib/accounting/engine";
import { toman } from "@/lib/accounting/format";
import { formatJalali, formatJalaliShort } from "@/lib/accounting/jalali";
import { useLedger } from "@/lib/accounting/store";
import { SOURCE_LABEL } from "@/lib/accounting/chart";
import { Card, Mark } from "./ui";

export function Dashboard() {
  const products = useLedger((s) => s.products);
  const entries = useLedger((s) => s.entries);
  const invoices = useLedger((s) => s.invoices);
  const settings = useLedger((s) => s.settings);
  const setView = useLedger((s) => s.setView);
  const drafts = invoices.filter((i) => i.status === "draft").length;
  const kpi = useMemo(() => kpisOf(entries, products, drafts), [entries, products, drafts]);
  const series = useMemo(
    () => salesSeries(entries).map((d) => ({ label: formatJalaliShort(d.date), sales: d.sales })),
    [entries],
  );
  const recent = [...entries].reverse().slice(0, 5);
  const lows = products.filter((p) => p.qty <= p.minQty);
  const trial = useMemo(() => trialOf(entries), [entries]);
  const stockBook = trial.rows.find((r) => r.code === "1300");
  const stockGap = Math.abs((stockBook?.debit ?? 0) - kardexValue(products));

  return (
    <div className="space-y-4">
      <header className="flex items-center justify-between pt-2">
        <div className="flex items-center gap-3">
          <Mark />
          <div>
            <p className="text-lg font-extrabold leading-tight">کاسبا</p>
            <p className="text-xs text-muted">{settings.shopName}</p>
          </div>
        </div>
        <p className="text-left text-xs font-semibold text-muted">{formatJalali("2026-11-06")}</p>
      </header>

      <div className="grid grid-cols-2 gap-3">
        <Kpi label="فروش آبان" value={kpi.sales} hint="پس از تخفیف، پیش از مالیات" />
        <Kpi label="خرید آبان" value={kpi.purchases} hint="ورود به موجودی" />
        <Kpi label="سود ناخالص" value={kpi.profit} hint="فروش منهای بهای تمام‌شده" />
        <Kpi label="اسناد ثبت‌شده" value={kpi.docs} hint="دفتر روزنامه" plain />
      </div>

      {(lows.length > 0 || kpi.negative > 0 || !kpi.balanced) && (
        <Card className="border-warn/30 bg-warn-soft">
          <p className="text-sm font-bold text-warn">نیاز به پیگیری</p>
          <ul className="mt-2 space-y-1 text-sm text-ink">
            {lows.slice(0, 3).map((p) => (
              <li key={p.id}>
                {p.name}: موجودی {p.qty.toLocaleString("fa-IR")}، حداقل {p.minQty.toLocaleString("fa-IR")}
              </li>
            ))}
            {kpi.negative > 0 && <li>موجودی منفی در {kpi.negative.toLocaleString("fa-IR")} کالا</li>}
            {!kpi.balanced && <li>تراز آزمایشی نامتوازن است.</li>}
          </ul>
          <button type="button" className="mt-3 text-sm font-bold text-warn" onClick={() => setView("control")}>
            کنترل روزانه
          </button>
        </Card>
      )}

      <Card>
        <div className="mb-2 flex items-baseline justify-between">
          <h2 className="font-extrabold">روند فروش ۱۴ روز</h2>
          <span className="text-xs text-muted">تومان</span>
        </div>
        <SalesChart data={series} />
      </Card>

      <div className="grid grid-cols-3 gap-2">
        <Mini label="صندوق" value={toman(kpi.cash)} onClick={() => setView("treasury")} />
        <Mini label="بانک" value={toman(kpi.bank)} onClick={() => setView("treasury")} />
        <Mini label={kpi.balanced ? "تراز متوازن" : "تراز ناقص"} value={stockGap < 1000 ? "کاردکس سالم" : "مغایرت کالا"} onClick={() => setView("books")} />
      </div>

      <Card className="p-0">
        <div className="flex items-center justify-between px-4 pt-4">
          <h2 className="font-extrabold">آخرین عملیات</h2>
          <button type="button" className="text-sm font-semibold text-primary" onClick={() => setView("ops")}>
            همه
          </button>
        </div>
        <ul>
          {recent.map((e) => (
            <li key={e.id} className="flex items-center justify-between gap-3 border-t border-line px-4 py-3 first:border-t-0">
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold">{e.desc}</p>
                <p className="text-xs text-muted">
                  {SOURCE_LABEL[e.source]} · {formatJalali(e.date)}
                </p>
              </div>
              <span className="shrink-0 text-sm font-bold">{toman(e.lines.reduce((s, l) => s + l.debit, 0))}</span>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}

function Kpi({ label, value, hint, plain }: { label: string; value: number; hint: string; plain?: boolean }) {
  return (
    <Card>
      <p className="text-xs font-medium text-muted">{label}</p>
      <p className="mt-2 text-xl font-extrabold tracking-tight">{plain ? value.toLocaleString("fa-IR") : toman(value)}</p>
      <p className="mt-1 text-xs text-muted">{hint}</p>
    </Card>
  );
}

function Mini({ label, value, onClick }: { label: string; value: string; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="rounded-2xl border border-line bg-surface px-2 py-3 text-center shadow-sm">
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-1 truncate text-xs font-extrabold">{value}</p>
    </button>
  );
}

function SalesChart({ data }: { data: { label: string; sales: number }[] }) {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  if (!ready) return <div className="h-40 rounded-xl bg-canvas" />;
  return (
    <div className="h-40">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 8, right: 0, left: 0, bottom: 0 }}>
          <XAxis dataKey="label" tick={{ fontSize: 10, fill: "var(--color-muted)" }} axisLine={false} tickLine={false} interval={2} />
          <Tooltip
            formatter={(v) => [`${toman(Number(v))} تومان`, "فروش"]}
            labelFormatter={(l) => String(l)}
            contentStyle={{ borderRadius: 12, borderColor: "var(--color-line)", fontFamily: "inherit" }}
          />
          <Area type="monotone" dataKey="sales" stroke="var(--color-primary)" fill="var(--color-primary-soft)" strokeWidth={2} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
