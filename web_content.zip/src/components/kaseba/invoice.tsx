import { useMemo, useState } from "react";
import { toast } from "sonner";
import { payLabel, priceDraft } from "@/lib/accounting/engine";
import { toman } from "@/lib/accounting/format";
import { TODAY, addDays, formatJalali, isToday } from "@/lib/accounting/jalali";
import { useLedger } from "@/lib/accounting/store";
import type { PayMethod, Settlement } from "@/lib/accounting/types";
import { cn } from "@/lib/cn";
import { ProductGlyph } from "./icons";
import { Btn, Field, inputClass, Sheet } from "./ui";

const METHODS: { id: PayMethod; label: string }[] = [
  { id: "cash", label: "نقدی" },
  { id: "card", label: "کارت" },
  { id: "cheque", label: "چک" },
  { id: "other", label: "سایر" },
];

const SETTLEMENTS: { id: Settlement; label: string }[] = [
  { id: "full", label: "تسویه کامل" },
  { id: "multi", label: "چند روش" },
  { id: "credit", label: "نسیه / قسطی" },
];

export function InvoiceView() {
  const draft = useLedger((s) => s.draft);
  const products = useLedger((s) => s.products);
  const parties = useLedger((s) => s.parties);
  const settings = useLedger((s) => s.settings);
  const patchDraft = useLedger((s) => s.patchDraft);
  const addLine = useLedger((s) => s.addLine);
  const setLineQty = useLedger((s) => s.setLineQty);
  const postDraft = useLedger((s) => s.postDraft);
  const setView = useLedger((s) => s.setView);
  const [picker, setPicker] = useState<"party" | "goods" | null>(null);
  const [terms, setTerms] = useState(false);
  const [query, setQuery] = useState("");
  const priced = useMemo(() => priceDraft(draft, products, settings), [draft, products, settings]);
  const party = parties.find((p) => p.id === draft.partyId);

  const found = products.filter((p) => !query.trim() || p.name.includes(query.trim())).slice(0, 8);

  return (
    <div className="space-y-3 pb-36">
      <div className="grid grid-cols-2 gap-2 rounded-2xl bg-canvas p-1">
        {(
          [
            ["proforma", "پیش‌فاکتور"],
            ["sale", "فاکتور"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => patchDraft({ kind: id })}
            className={cn("h-11 rounded-xl text-sm font-bold", draft.kind === id ? "bg-surface text-ink shadow-sm" : "text-muted")}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-2">
        <button type="button" onClick={() => setPicker("party")} className="rounded-2xl border border-line bg-surface px-3 py-3 text-right">
          <span className="block text-xs text-muted">مشتری</span>
          <span className="mt-1 block truncate font-bold">{party?.name ?? "انتخاب"}</span>
        </button>
        <div className="rounded-2xl border border-line bg-surface px-3 py-3">
          <span className="block text-xs text-muted">تاریخ</span>
          <span className="mt-1 flex items-center justify-between font-bold">
            <button type="button" aria-label="روز قبل" onClick={() => patchDraft({ date: addDays(draft.date, -1) })}>
              ‹
            </button>
            <span className="text-xs">{isToday(draft.date) ? `امروز · ${formatJalali(TODAY)}` : formatJalali(draft.date)}</span>
            <button type="button" aria-label="روز بعد" onClick={() => patchDraft({ date: addDays(draft.date, 1) })}>
              ›
            </button>
          </span>
        </div>
      </div>

      <div className="flex gap-2">
        <Btn variant="ghost" className="shrink-0" onClick={() => setPicker("goods")}>
          انتخاب
        </Btn>
        <Btn variant="soft" className="shrink-0" onClick={() => setView("assistant")}>
          صدا
        </Btn>
        <input className={inputClass} placeholder="جستجو یا گفتن نام کالا…" value={query} onChange={(e) => setQuery(e.target.value)} />
      </div>
      {query.trim() && (
        <ul className="overflow-hidden rounded-2xl border border-line bg-surface">
          {found.map((p) => (
            <li key={p.id}>
              <button
                type="button"
                className="flex w-full items-center gap-2 px-3 py-2 text-right text-sm"
                onClick={() => {
                  addLine(p.id);
                  setQuery("");
                }}
              >
                <ProductGlyph icon={p.icon} className="size-4 text-primary" />
                <span className="flex-1">{p.name}</span>
                <span className="text-muted">{toman(p.price)}</span>
              </button>
            </li>
          ))}
          {found.length === 0 && <li className="px-3 py-3 text-sm text-muted">کالایی پیدا نشد.</li>}
        </ul>
      )}

      <div className="overflow-hidden rounded-2xl border border-line bg-surface">
        <div className="grid grid-cols-[2rem_1fr_auto_auto] gap-2 border-b border-line px-3 py-2 text-xs text-muted">
          <span>ردیف</span>
          <span>شرح</span>
          <span>تعداد</span>
          <span>مبلغ</span>
        </div>
        {priced.lines.length === 0 && <p className="px-3 py-8 text-center text-sm text-muted">کالایی در فاکتور نیست.</p>}
        {priced.lines.map((line, i) => (
          <div key={line.productId} className="grid grid-cols-[2rem_1fr_auto] items-center gap-2 border-b border-line px-3 py-3 last:border-b-0">
            <span className="text-sm text-muted">{(i + 1).toLocaleString("fa-IR")}</span>
            <div className="min-w-0">
              <p className="truncate font-semibold">{line.name}</p>
              <p className="text-xs text-muted">فی {toman(line.price)}</p>
            </div>
            <div className="text-left">
              <div className="flex items-center justify-end gap-1">
                <button type="button" className="grid size-8 place-items-center rounded-full bg-canvas" onClick={() => setLineQty(line.productId, line.qty - 1)} aria-label="کم کردن">
                  −
                </button>
                <span className="w-6 text-center font-bold">{line.qty.toLocaleString("fa-IR")}</span>
                <button type="button" className="grid size-8 place-items-center rounded-full bg-canvas" onClick={() => setLineQty(line.productId, line.qty + 1)} aria-label="زیاد کردن">
                  +
                </button>
              </div>
              <p className="mt-1 text-sm font-bold">{toman(line.amount)}</p>
            </div>
          </div>
        ))}
      </div>

      <footer className="fixed inset-x-0 bottom-28 z-30 border-t border-line bg-surface/95 px-4 py-3 backdrop-blur md:sticky md:bottom-0 md:rounded-2xl md:border">
        <div className="mx-auto flex max-w-3xl items-center gap-3">
          <div className="min-w-0 flex-1">
            <p className="text-lg font-extrabold">{toman(priced.total)} تومان</p>
            <button type="button" className="text-xs font-semibold text-primary" onClick={() => setTerms(true)}>
              {payLabel(draft)}
              {priced.discount ? "" : " · بدون تخفیف"}
              {draft.taxEnabled ? ` · مالیات ${settings.taxRate.toLocaleString("fa-IR")}٪` : " · بدون مالیات"}
            </button>
          </div>
          <Btn
            variant="good"
            onClick={() => {
              const res = postDraft();
              if (res.ok) {
                toast.success(res.message);
                setView("home");
              } else toast.error(res.message);
            }}
          >
            بستن
          </Btn>
        </div>
      </footer>

      <Sheet open={picker === "party"} title="انتخاب مشتری" onClose={() => setPicker(null)}>
        <button
          type="button"
          className="mb-2 w-full rounded-xl bg-canvas px-3 py-3 text-right text-sm"
          onClick={() => {
            patchDraft({ partyId: null });
            setPicker(null);
          }}
        >
          مشتری متفرقه
        </button>
        <ul className="space-y-1">
          {parties.map((p) => (
            <li key={p.id}>
              <button
                type="button"
                className="w-full rounded-xl px-3 py-3 text-right text-sm font-semibold hover:bg-canvas"
                onClick={() => {
                  patchDraft({ partyId: p.id });
                  setPicker(null);
                }}
              >
                {p.name}
              </button>
            </li>
          ))}
        </ul>
      </Sheet>

      <Sheet open={picker === "goods"} title="انتخاب کالا" onClose={() => setPicker(null)}>
        <ul className="space-y-1">
          {products.map((p) => (
            <li key={p.id}>
              <button
                type="button"
                className="flex w-full items-center gap-2 rounded-xl px-2 py-2 text-right"
                onClick={() => addLine(p.id)}
              >
                <span className="grid size-9 place-items-center rounded-lg bg-primary-soft text-primary">
                  <ProductGlyph icon={p.icon} className="size-4" />
                </span>
                <span className="flex-1 text-sm font-semibold">{p.name}</span>
                <span className="text-xs text-muted">{p.qty.toLocaleString("fa-IR")} · {toman(p.price)}</span>
              </button>
            </li>
          ))}
        </ul>
      </Sheet>

      <Sheet open={terms} title="شرایط پرداخت، تخفیف و هزینه‌ها" onClose={() => setTerms(false)}>
        <div className="space-y-3">
          <p className="text-xs text-muted">تسویه</p>
          <div className="grid grid-cols-3 gap-2">
            {SETTLEMENTS.map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => patchDraft({ settlement: s.id, splitCash: s.id === "multi" ? Math.round(priced.total / 2) : draft.splitCash })}
                className={cn("h-11 rounded-xl text-xs font-bold", draft.settlement === s.id ? "bg-navy text-on-navy" : "bg-canvas text-ink")}
              >
                {s.label}
              </button>
            ))}
          </div>
          {draft.settlement !== "credit" && (
            <>
              <p className="text-xs text-muted">روش</p>
              <div className="grid grid-cols-4 gap-2">
                {METHODS.map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => patchDraft({ method: m.id })}
                    className={cn("h-11 rounded-xl text-xs font-bold", draft.method === m.id ? "bg-primary text-on-primary" : "bg-canvas")}
                  >
                    {m.label}
                  </button>
                ))}
              </div>
            </>
          )}
          {draft.settlement === "multi" && (
            <Field label="بخش نقد از جمع">
              <input
                className={inputClass}
                inputMode="numeric"
                value={draft.splitCash ? String(draft.splitCash) : ""}
                onChange={(e) => patchDraft({ splitCash: Number(e.target.value.replace(/[^\d]/g, "")) || 0 })}
              />
            </Field>
          )}
          <div className="grid grid-cols-2 gap-2">
            <button type="button" className={cn("h-11 rounded-xl text-sm font-bold", draft.discountMode === "amount" ? "bg-primary text-on-primary" : "bg-canvas")} onClick={() => patchDraft({ discountMode: "amount" })}>
              تخفیف تومان
            </button>
            <button type="button" className={cn("h-11 rounded-xl text-sm font-bold", draft.discountMode === "percent" ? "bg-primary text-on-primary" : "bg-canvas")} onClick={() => patchDraft({ discountMode: "percent" })}>
              تخفیف درصد
            </button>
          </div>
          <input
            className={inputClass}
            inputMode="numeric"
            placeholder={draft.discountMode === "percent" ? "درصد" : "مبلغ تخفیف"}
            value={draft.discountValue ? String(draft.discountValue) : ""}
            onChange={(e) => patchDraft({ discountValue: Number(e.target.value.replace(/[^\d]/g, "")) || 0 })}
          />
          <label className="flex items-center justify-between rounded-xl bg-canvas px-3 py-3 text-sm">
            <span>مالیات {settings.taxRate.toLocaleString("fa-IR")}٪</span>
            <input type="checkbox" checked={draft.taxEnabled} onChange={(e) => patchDraft({ taxEnabled: e.target.checked })} />
          </label>
          <p className="text-xs font-bold text-muted">هزینه‌های جانبی</p>
          <div className="grid grid-cols-3 gap-2">
            <Field label="حمل">
              <input className={inputClass} inputMode="numeric" value={draft.shipping || ""} onChange={(e) => patchDraft({ shipping: Number(e.target.value.replace(/[^\d]/g, "")) || 0 })} />
            </Field>
            <Field label="بسته‌بندی">
              <input className={inputClass} inputMode="numeric" value={draft.packing || ""} onChange={(e) => patchDraft({ packing: Number(e.target.value.replace(/[^\d]/g, "")) || 0 })} />
            </Field>
            <Field label="سایر">
              <input className={inputClass} inputMode="numeric" value={draft.otherCost || ""} onChange={(e) => patchDraft({ otherCost: Number(e.target.value.replace(/[^\d]/g, "")) || 0 })} />
            </Field>
          </div>
          <p className="text-sm font-bold">قابل پرداخت {toman(priced.total)} تومان</p>
          <Btn className="w-full" onClick={() => setTerms(false)}>
            تأیید
          </Btn>
        </div>
      </Sheet>
    </div>
  );
}
