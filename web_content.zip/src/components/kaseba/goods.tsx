import { useMemo, useState } from "react";
import { toast } from "sonner";
import { GROUPS } from "@/lib/accounting/chart";
import { toman } from "@/lib/accounting/format";
import { formatJalali } from "@/lib/accounting/jalali";
import { useLedger } from "@/lib/accounting/store";
import type { Product } from "@/lib/accounting/types";
import { ProductGlyph } from "./icons";
import { Btn, Chips, Field, inputClass, Sheet } from "./ui";

type Filter = "all" | "low" | "stock" | "recent";

export function GoodsView() {
  const products = useLedger((s) => s.products);
  const moves = useLedger((s) => s.moves);
  const addProduct = useLedger((s) => s.addProduct);
  const updateProduct = useLedger((s) => s.updateProduct);
  const adjustStock = useLedger((s) => s.adjustStock);
  const addLine = useLedger((s) => s.addLine);
  const resetDraft = useLedger((s) => s.resetDraft);
  const setView = useLedger((s) => s.setView);
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<Filter>("all");
  const [open, setOpen] = useState<Product | null>(null);
  const [creating, setCreating] = useState(false);

  const lastDate = useMemo(() => {
    const map = new Map<string, string>();
    for (const m of moves) {
      const prev = map.get(m.productId);
      if (!prev || m.date > prev) map.set(m.productId, m.date);
    }
    return map;
  }, [moves]);

  const rows = useMemo(() => {
    const query = q.trim();
    let list = products.filter((p) => !query || p.name.includes(query) || p.barcode.includes(query));
    if (filter === "low") list = list.filter((p) => p.qty <= p.minQty);
    if (filter === "stock") list = list.filter((p) => p.qty > 0);
    if (filter === "recent") list = [...list].sort((a, b) => (lastDate.get(b.id) ?? "").localeCompare(lastDate.get(a.id) ?? ""));
    return list;
  }, [products, q, filter, lastDate]);

  const counts = {
    all: products.length,
    low: products.filter((p) => p.qty <= p.minQty).length,
    stock: products.filter((p) => p.qty > 0).length,
  };

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <input className={inputClass} placeholder="جستجوی نام یا بارکد…" value={q} onChange={(e) => setQ(e.target.value)} />
        <Btn className="shrink-0 px-3" onClick={() => setCreating(true)}>
          کالای جدید
        </Btn>
      </div>
      <Chips
        value={filter}
        onChange={(id) => setFilter(id as Filter)}
        options={[
          { id: "all", label: `همه ${counts.all.toLocaleString("fa-IR")}` },
          { id: "low", label: `کم‌موجود ${counts.low.toLocaleString("fa-IR")}` },
          { id: "stock", label: `موجود ${counts.stock.toLocaleString("fa-IR")}` },
          { id: "recent", label: "اخیر" },
        ]}
      />
      {rows.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-line bg-surface px-4 py-10 text-center text-sm text-muted">
          هنوز کالایی با این مشخصات نیست.
        </p>
      ) : (
        <ul className="space-y-2">
          {rows.map((p) => (
            <li key={p.id}>
              <button type="button" onClick={() => setOpen(p)} className="flex w-full items-center gap-3 rounded-2xl border border-line bg-surface px-3 py-3 text-right shadow-sm">
                <span className="grid size-12 shrink-0 place-items-center rounded-xl bg-primary-soft text-primary">
                  <ProductGlyph icon={p.icon} className="size-6" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-semibold">{p.name}</span>
                  <span className="mt-0.5 block text-xs text-muted">
                    {toman(p.price)} تومان · {p.qty.toLocaleString("fa-IR")} {p.unit}
                    {p.qty <= p.minQty ? " · کم‌موجود" : ""}
                  </span>
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}

      <Sheet open={!!open} title={open?.name ?? ""} onClose={() => setOpen(null)}>
        {open && (
          <ProductSheet
            product={products.find((p) => p.id === open.id) ?? open}
            moves={moves}
            onSave={(patch) => {
              updateProduct(open.id, patch);
              toast.success("کالا به‌روز شد.");
            }}
            onAdjust={(qty) => {
              const res = adjustStock(open.id, qty);
              if (res.ok) toast.success(res.message);
              else toast.error(res.message);
            }}
            onSell={() => {
              resetDraft(null);
              addLine(open.id);
              setOpen(null);
              setView("invoice");
            }}
          />
        )}
      </Sheet>

      <Sheet open={creating} title="کالای جدید" onClose={() => setCreating(false)}>
        <NewProduct
          onCreate={(input) => {
            const res = addProduct(input);
            if (res.ok) {
              toast.success(res.message);
              setCreating(false);
            } else toast.error(res.message);
          }}
        />
      </Sheet>
    </div>
  );
}

function ProductSheet({
  product,
  moves,
  onSave,
  onAdjust,
  onSell,
}: {
  product: Product;
  moves: { productId: string; date: string; qty: number; kind: string }[];
  onSave: (patch: Partial<Product>) => void;
  onAdjust: (qty: number) => void;
  onSell: () => void;
}) {
  const [price, setPrice] = useState(String(product.price));
  const [minQty, setMinQty] = useState(String(product.minQty));
  const [counted, setCounted] = useState(String(product.qty));
  const kardex = moves.filter((m) => m.productId === product.id).slice(-6).reverse();
  return (
    <div className="space-y-3">
      <p className="text-sm text-muted">
        گروه {product.group} · بارکد {product.barcode} · بهای میانگین {toman(product.cost)} تومان
      </p>
      <div className="grid grid-cols-2 gap-2">
        <Field label="قیمت فروش">
          <input className={inputClass} inputMode="numeric" value={price} onChange={(e) => setPrice(e.target.value.replace(/[^\d]/g, ""))} />
        </Field>
        <Field label="حداقل موجودی">
          <input className={inputClass} inputMode="numeric" value={minQty} onChange={(e) => setMinQty(e.target.value.replace(/[^\d]/g, ""))} />
        </Field>
      </div>
      <Btn
        variant="soft"
        className="w-full"
        onClick={() => onSave({ price: Number(price) || product.price, minQty: Number(minQty) || 0 })}
      >
        ذخیره قیمت و حداقل
      </Btn>
      <Field label="موجودی شمارش‌شده">
        <input className={inputClass} inputMode="numeric" value={counted} onChange={(e) => setCounted(e.target.value.replace(/[^\d]/g, ""))} />
      </Field>
      <Btn variant="ghost" className="w-full" onClick={() => onAdjust(Number(counted) || 0)}>
        ثبت اصلاح موجودی
      </Btn>
      <Btn className="w-full" onClick={onSell}>
        فروش این کالا
      </Btn>
      <div>
        <p className="mb-2 text-xs font-bold text-muted">کاردکس اخیر</p>
        <ul className="space-y-1 text-sm">
          {kardex.map((m, i) => (
            <li key={m.date + i} className="flex justify-between rounded-xl bg-canvas px-3 py-2">
              <span>{formatJalali(m.date)}</span>
              <span className={m.qty < 0 ? "text-bad" : "text-good"}>
                {m.qty > 0 ? "+" : ""}
                {m.qty.toLocaleString("fa-IR")}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function NewProduct({
  onCreate,
}: {
  onCreate: (input: { name: string; group: string; unit: string; price: number; cost: number; qty: number; minQty: number; barcode: string }) => void;
}) {
  const [name, setName] = useState("");
  const [group, setGroup] = useState(GROUPS[0]);
  const [price, setPrice] = useState("");
  const [cost, setCost] = useState("");
  const [qty, setQty] = useState("");
  const [barcode, setBarcode] = useState("");
  return (
    <form
      className="space-y-3"
      onSubmit={(e) => {
        e.preventDefault();
        onCreate({
          name,
          group,
          unit: "عدد",
          price: Number(price) || 0,
          cost: Number(cost) || 0,
          qty: Number(qty) || 0,
          minQty: 5,
          barcode,
        });
      }}
    >
      <Field label="نام کالا">
        <input className={inputClass} value={name} onChange={(e) => setName(e.target.value)} />
      </Field>
      <Field label="گروه">
        <select className={inputClass} value={group} onChange={(e) => setGroup(e.target.value)}>
          {GROUPS.map((g) => (
            <option key={g}>{g}</option>
          ))}
        </select>
      </Field>
      <div className="grid grid-cols-2 gap-2">
        <Field label="قیمت فروش">
          <input className={inputClass} inputMode="numeric" value={price} onChange={(e) => setPrice(e.target.value.replace(/[^\d]/g, ""))} />
        </Field>
        <Field label="بهای خرید">
          <input className={inputClass} inputMode="numeric" value={cost} onChange={(e) => setCost(e.target.value.replace(/[^\d]/g, ""))} />
        </Field>
      </div>
      <Field label="موجودی اولیه">
        <input className={inputClass} inputMode="numeric" value={qty} onChange={(e) => setQty(e.target.value.replace(/[^\d]/g, ""))} />
      </Field>
      <Field label="بارکد">
        <input className={inputClass} value={barcode} onChange={(e) => setBarcode(e.target.value)} />
      </Field>
      <Btn type="submit" className="w-full">
        ثبت کالا
      </Btn>
    </form>
  );
}
