import { useMemo, useState } from "react";
import {
  BookOpen,
  Boxes,
  FileSpreadsheet,
  Landmark,
  ListChecks,
  Settings,
  ShoppingBag,
  Users,
  Warehouse,
  ClipboardList,
} from "lucide-react";
import { toast } from "sonner";
import { accountBalance, kardexValue, kpisOf, moveQty, partyRows, trialOf } from "@/lib/accounting/engine";
import { toman } from "@/lib/accounting/format";
import { TODAY, formatJalali } from "@/lib/accounting/jalali";
import { RECIPES } from "@/lib/accounting/recipes";
import { productsCsv, rowsFromFile, useLedger } from "@/lib/accounting/store";
import { SOURCE_LABEL } from "@/lib/accounting/chart";
import type { View } from "@/lib/accounting/types";
import { Btn, Card, Field, inputClass } from "./ui";

const LINKS: { view: View; title: string; hint: string; icon: typeof Users }[] = [
  { view: "parties", title: "مشتری‌ها و فروشنده‌ها", hint: "بدهکار، بستانکار، تراز اشخاص", icon: Users },
  { view: "ops", title: "عملیات روزانه", hint: "همه سندهایی که به دفتر نشسته‌اند", icon: ClipboardList },
  { view: "books", title: "دفاتر", hint: "روزنامه، کل، تراز آزمایشی", icon: BookOpen },
  { view: "purchase", title: "خرید کالا", hint: "ورود موجودی و بهای میانگین", icon: ShoppingBag },
  { view: "excel", title: "اکسل", hint: "خروج و ورود کالا با فایل", icon: FileSpreadsheet },
  { view: "treasury", title: "خزانه‌داری", hint: "صندوق، بانک، دریافت و هزینه", icon: Landmark },
  { view: "assets", title: "دارایی و استهلاک", hint: "ثبت استهلاک ماه", icon: Warehouse },
  { view: "production", title: "تولید", hint: "مصرف مواد و ساخت پک", icon: Boxes },
  { view: "control", title: "کنترل روزانه", hint: "موجودی منفی، کاردکس، تراز", icon: ListChecks },
  { view: "settings", title: "تنظیمات فروشگاه", hint: "نام، مالیات، بازنشانی", icon: Settings },
];

export function MoreMenu() {
  const setView = useLedger((s) => s.setView);
  return (
    <div className="grid gap-2">
      {LINKS.map((item) => {
        const Icon = item.icon;
        return (
          <button
            key={item.view}
            type="button"
            onClick={() => setView(item.view)}
            className="flex items-center gap-3 rounded-2xl border border-line bg-surface px-3 py-3 text-right shadow-sm"
          >
            <span className="grid size-11 place-items-center rounded-xl bg-primary-soft text-primary">
              <Icon className="size-5" />
            </span>
            <span>
              <span className="block font-bold">{item.title}</span>
              <span className="block text-xs text-muted">{item.hint}</span>
            </span>
          </button>
        );
      })}
    </div>
  );
}

export function OpsView() {
  const entries = useLedger((s) => s.entries);
  const [src, setSrc] = useState("all");
  const list = [...entries]
    .filter((e) => src === "all" || e.source === src)
    .sort((a, b) => b.date.localeCompare(a.date));
  return (
    <div className="space-y-3">
      <div className="flex gap-2 overflow-x-auto">
        {["all", "sale", "purchase", "receipt", "payment", "expense", "production", "opening"].map((id) => (
          <button
            key={id}
            type="button"
            onClick={() => setSrc(id)}
            className={`h-9 shrink-0 rounded-full px-3 text-xs font-bold ${src === id ? "bg-navy text-on-navy" : "bg-surface text-muted"}`}
          >
            {id === "all" ? "همه" : SOURCE_LABEL[id]}
          </button>
        ))}
      </div>
      <ul className="space-y-2">
        {list.map((e) => (
          <li key={e.id} className="rounded-2xl border border-line bg-surface px-3 py-3">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="font-bold">{e.desc}</p>
                <p className="text-xs text-muted">
                  {SOURCE_LABEL[e.source]} · {formatJalali(e.date)} · تأییدشده
                </p>
              </div>
              <p className="text-sm font-extrabold">{toman(e.lines.reduce((s, l) => s + l.debit, 0))}</p>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function ExcelView() {
  const products = useLedger((s) => s.products);
  const parties = useLedger((s) => s.parties);
  const importRows = useLedger((s) => s.importRows);
  const loadTraining = useLedger((s) => s.loadTraining);
  const [preview, setPreview] = useState<string[][] | null>(null);
  const [fileName, setFileName] = useState("");
  const names = preview ? preview.slice(1, 6).map((row) => row[0]).filter(Boolean) : [];
  return (
    <div className="space-y-3">
      <Card>
        <h2 className="font-extrabold">خروج به اکسل</h2>
        <p className="mt-1 text-sm text-muted">کالا و طرف‌حساب در فایل CSV که اکسل باز می‌کند. همان ستون‌ها را برای ورود دوباره بگذارید.</p>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <Btn variant="ghost" onClick={() => download("kaseba-goods.csv", productsCsv(products))}>
            فایل کالا
          </Btn>
          <Btn variant="soft" onClick={() => download("kaseba-parties.csv", partiesCsv(parties))}>
            فایل اشخاص
          </Btn>
        </div>
      </Card>
      <Card>
        <h2 className="font-extrabold">ورود از اکسل</h2>
        <p className="mt-1 text-sm leading-6 text-muted">
          فایل xlsx یا csv. ستون‌ها: نام، بارکد، گروه، واحد، موجودی، قیمت، بهای تمام‌شده، حداقل. کالای هم‌نام دوباره ساخته نمی‌شود و موجودی تازه با سند سرمایه می‌نشیند.
        </p>
        <label className="mt-3 flex h-12 cursor-pointer items-center justify-center rounded-xl bg-primary text-sm font-bold text-on-primary">
          انتخاب فایل اکسل
          <input
            type="file"
            accept=".csv,.txt,.xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            className="sr-only"
            onChange={async (e) => {
              const file = e.target.files?.[0];
              e.target.value = "";
              if (!file) return;
              try {
                const rows = await rowsFromFile(file);
                if (rows.length < 2) {
                  toast.error("فایل خالی است یا سطر عنوان ندارد.");
                  return;
                }
                setPreview(rows);
                setFileName(file.name);
              } catch {
                toast.error("خواندن فایل ممکن نشد. csv یا xlsx بدهید.");
              }
            }}
          />
        </label>
        {preview && (
          <div className="mt-3 rounded-xl bg-canvas p-3 text-sm">
            <p className="font-bold">{fileName}</p>
            <p className="mt-1 text-muted">{(preview.length - 1).toLocaleString("fa-IR")} ردیف داده</p>
            <ul className="mt-2 space-y-1">
              {names.map((name) => (
                <li key={name}>{name}</li>
              ))}
            </ul>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <Btn
                onClick={() => {
                  const res = importRows(preview);
                  if (res.ok) {
                    toast.success(res.message);
                    setPreview(null);
                  } else toast.error(res.message);
                }}
              >
                تأیید ورود
              </Btn>
              <Btn variant="ghost" onClick={() => setPreview(null)}>
                انصراف
              </Btn>
            </div>
          </div>
        )}
        <button
          type="button"
          className="mt-3 w-full text-center text-sm font-semibold text-primary"
          onClick={() => {
            const res = loadTraining();
            if (res.ok) toast.success(res.message);
            else toast.error(res.message);
          }}
        >
          دریافت فایل نمونه آموزشی
        </button>
      </Card>
    </div>
  );
}

function partiesCsv(parties: { name: string; phone: string }[]) {
  return "\uFEFF" + ["نام,موبایل", ...parties.map((p) => `${p.name},${p.phone}`)].join("\n");
}

function download(name: string, text: string) {
  const blob = new Blob([text], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
  toast.success("فایل آماده دانلود است.");
}

export function PurchaseView() {
  const products = useLedger((s) => s.products);
  const parties = useLedger((s) => s.parties);
  const taxRate = useLedger((s) => s.settings.taxRate);
  const postPurchase = useLedger((s) => s.postPurchase);
  const [productId, setProductId] = useState(products[0]?.id ?? "");
  const [partyId, setPartyId] = useState("");
  const [qty, setQty] = useState("1");
  const [cost, setCost] = useState("");
  const [pay, setPay] = useState<"cash" | "bank" | "credit">("cash");
  const [taxed, setTaxed] = useState(true);
  const [lines, setLines] = useState<{ productId: string; qty: number; cost: number }[]>([]);
  const net = lines.reduce((s, l) => s + l.qty * l.cost, 0);
  const tax = taxed ? Math.round((net * taxRate) / 100) : 0;
  return (
    <div className="space-y-3">
      <Card>
        <form
          className="space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            const product = products.find((p) => p.id === productId);
            const q = Number(qty) || 0;
            const c = Number(cost) || 0;
            if (!product || q <= 0 || c <= 0) {
              toast.error("کالا، تعداد و بهای واحد را کامل کنید.");
              return;
            }
            setLines((prev) => {
              const hit = prev.find((l) => l.productId === product.id && l.cost === c);
              if (hit) return prev.map((l) => (l === hit ? { ...l, qty: l.qty + q } : l));
              return [...prev, { productId: product.id, qty: q, cost: c }];
            });
            setQty("1");
            setCost("");
          }}
        >
          <Field label="کالا">
            <select className={inputClass} value={productId} onChange={(e) => setProductId(e.target.value)}>
              {products.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} — موجودی {p.qty.toLocaleString("fa-IR")}
                </option>
              ))}
            </select>
          </Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="تعداد">
              <input className={inputClass} inputMode="numeric" value={qty} onChange={(e) => setQty(e.target.value.replace(/[^\d]/g, ""))} />
            </Field>
            <Field label="بهای واحد">
              <input className={inputClass} inputMode="numeric" placeholder="ریال" value={cost} onChange={(e) => setCost(e.target.value.replace(/[^\d]/g, ""))} />
            </Field>
          </div>
          <Btn type="submit" variant="soft" className="w-full">
            افزودن به فاکتور خرید
          </Btn>
        </form>
      </Card>
      <Card className="space-y-3">
        {lines.length === 0 && <p className="text-sm text-muted">هنوز ردیفی نیست.</p>}
        {lines.map((line, index) => {
          const product = products.find((p) => p.id === line.productId);
          return (
            <div key={`${line.productId}-${index}`} className="flex items-center justify-between gap-2 text-sm">
              <div>
                <p className="font-bold">{product?.name}</p>
                <p className="text-muted">
                  {line.qty.toLocaleString("fa-IR")} × {toman(line.cost)}
                </p>
              </div>
              <button type="button" className="text-bad" onClick={() => setLines((prev) => prev.filter((_, i) => i !== index))}>
                حذف
              </button>
            </div>
          );
        })}
        <Field label="فروشنده">
          <select className={inputClass} value={partyId} onChange={(e) => setPartyId(e.target.value)}>
            <option value="">بدون شخص</option>
            {parties.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </Field>
        <div className="grid grid-cols-3 gap-2">
          {(
            [
              ["cash", "صندوق"],
              ["bank", "بانک"],
              ["credit", "نسیه"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setPay(id)}
              className={`h-10 rounded-xl text-sm font-bold ${pay === id ? "bg-navy text-on-navy" : "bg-canvas text-muted"}`}
            >
              {label}
            </button>
          ))}
        </div>
        <label className="flex items-center justify-between text-sm">
          <span>مالیات خرید محاسبه شود</span>
          <input type="checkbox" checked={taxed} onChange={(e) => setTaxed(e.target.checked)} />
        </label>
        <div className="space-y-1 text-sm">
          <div className="flex justify-between">
            <span className="text-muted">جمع کالا</span>
            <span>{toman(net)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted">مالیات</span>
            <span>{toman(tax)}</span>
          </div>
          <div className="flex justify-between font-extrabold">
            <span>قابل پرداخت</span>
            <span>{toman(net + tax)}</span>
          </div>
        </div>
        <Btn
          className="w-full"
          disabled={!lines.length}
          onClick={() => {
            const res = postPurchase({ date: TODAY, partyId: partyId || null, lines, taxed, pay });
            if (res.ok) {
              toast.success(res.message);
              setLines([]);
            } else toast.error(res.message);
          }}
        >
          ثبت خرید و صدور سند
        </Btn>
      </Card>
    </div>
  );
}

export function TreasuryView() {
  const entries = useLedger((s) => s.entries);
  const parties = useLedger((s) => s.parties);
  const postReceipt = useLedger((s) => s.postReceipt);
  const postPayment = useLedger((s) => s.postPayment);
  const postExpense = useLedger((s) => s.postExpense);
  const postTransfer = useLedger((s) => s.postTransfer);
  const rows = useMemo(() => partyRows(entries, parties), [entries, parties]);
  const cash = accountBalance(entries, "1100").natural;
  const bank = accountBalance(entries, "1110").natural;
  const [partyId, setPartyId] = useState(parties[0]?.id ?? "");
  const [amount, setAmount] = useState("");
  const [desc, setDesc] = useState("");
  const [viaBank, setViaBank] = useState(false);
  const n = Number(amount) || 0;
  const party = rows.find((p) => p.id === partyId);
  const recent = [...entries]
    .filter((e) => e.source === "receipt" || e.source === "payment" || e.source === "expense" || e.source === "transfer")
    .slice(-4)
    .reverse();
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <Card>
          <p className="text-xs text-muted">صندوق</p>
          <p className="mt-1 text-lg font-extrabold">{toman(cash)}</p>
        </Card>
        <Card>
          <p className="text-xs text-muted">بانک</p>
          <p className="mt-1 text-lg font-extrabold">{toman(bank)}</p>
        </Card>
      </div>
      <Card className="space-y-3">
        <h2 className="font-extrabold">دریافت و پرداخت</h2>
        <select className={inputClass} value={partyId} onChange={(e) => setPartyId(e.target.value)}>
          {rows.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name} — {p.label}
            </option>
          ))}
        </select>
        {party && (
          <p className="text-sm text-muted">
            مانده {party.name}: {toman(Math.abs(party.net))} · {party.label}
          </p>
        )}
        <input className={inputClass} inputMode="numeric" placeholder="مبلغ ریال" value={amount} onChange={(e) => setAmount(e.target.value.replace(/[^\d]/g, ""))} />
        <div className="grid grid-cols-2 gap-2">
          <button type="button" onClick={() => setViaBank(false)} className={`h-10 rounded-xl text-sm font-bold ${viaBank ? "bg-canvas text-muted" : "bg-navy text-on-navy"}`}>
            صندوق
          </button>
          <button type="button" onClick={() => setViaBank(true)} className={`h-10 rounded-xl text-sm font-bold ${viaBank ? "bg-navy text-on-navy" : "bg-canvas text-muted"}`}>
            بانک
          </button>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Btn
            onClick={() => {
              toastMsg(postReceipt({ date: TODAY, partyId, amount: n, toBank: viaBank }));
              setAmount("");
            }}
          >
            دریافت
          </Btn>
          <Btn
            variant="ghost"
            onClick={() => {
              toastMsg(postPayment({ date: TODAY, partyId, amount: n, fromBank: viaBank }));
              setAmount("");
            }}
          >
            پرداخت
          </Btn>
        </div>
        <p className="text-xs leading-6 text-muted">دریافت، حساب دریافتنی را کم می‌کند. پرداخت، حساب پرداختنی را تسویه می‌کند.</p>
      </Card>
      <Card className="space-y-2">
        <h2 className="font-extrabold">هزینه و انتقال</h2>
        <input className={inputClass} placeholder="شرح هزینه" value={desc} onChange={(e) => setDesc(e.target.value)} />
        <Btn variant="soft" className="w-full" onClick={() => toastMsg(postExpense({ date: TODAY, amount: n, desc, fromBank: viaBank }))}>
          ثبت هزینه از {viaBank ? "بانک" : "صندوق"}
        </Btn>
        <div className="grid grid-cols-2 gap-2">
          <Btn variant="navy" onClick={() => toastMsg(postTransfer({ date: TODAY, amount: n, toBank: true }))}>
            صندوق به بانک
          </Btn>
          <Btn variant="ghost" onClick={() => toastMsg(postTransfer({ date: TODAY, amount: n, toBank: false }))}>
            بانک به صندوق
          </Btn>
        </div>
      </Card>
      {recent.length > 0 && (
        <Card>
          <h2 className="font-extrabold">آخرین اسناد خزانه</h2>
          <ul className="mt-2 space-y-2 text-sm">
            {recent.map((e) => (
              <li key={e.id} className="flex justify-between gap-2">
                <span>{e.desc}</span>
                <span className="font-bold">{toman(e.lines.reduce((s, l) => s + l.debit, 0))}</span>
              </li>
            ))}
          </ul>
        </Card>
      )}
    </div>
  );
}

export function AssetsView() {
  const assets = useLedger((s) => s.assets);
  const postDepreciation = useLedger((s) => s.postDepreciation);
  return (
    <ul className="space-y-2">
      {assets.map((a) => {
        const monthly = Math.round(a.cost / a.months);
        const remain = a.cost - a.accumulated;
        return (
          <li key={a.id}>
            <Card>
              <p className="font-extrabold">{a.name}</p>
              <p className="mt-1 text-sm text-muted">
                بها {toman(a.cost)} · انباشته {toman(a.accumulated)} · مانده {toman(remain)}
              </p>
              <p className="text-xs text-muted">استهلاک ماهانه {toman(monthly)} · تحصیل {formatJalali(a.acquired)}</p>
              <Btn className="mt-3 w-full" variant="ghost" onClick={() => toastMsg(postDepreciation(a.id))}>
                ثبت استهلاک این ماه
              </Btn>
            </Card>
          </li>
        );
      })}
    </ul>
  );
}

export function ProductionView() {
  const products = useLedger((s) => s.products);
  const postProduction = useLedger((s) => s.postProduction);
  const [qty, setQty] = useState<Record<string, string>>({});
  return (
    <div className="space-y-3">
      <Card>
        <p className="font-extrabold">بهای تمام‌شده تولید</p>
        <p className="mt-1 text-sm leading-6 text-muted">
          مواد از انبار کم می‌شود و محصول ساخته‌شده با میانگین بهای مواد وارد موجودی می‌شود. سند، ارزش موجودی را جابه‌جا می‌کند و تراز را به هم نمی‌زند. بهای فروش جدا از بهای ساخت است.
        </p>
      </Card>
      {RECIPES.map((recipe) => {
        const count = Number(qty[recipe.id] || "1") || 0;
        const parts = recipe.inputs.map((inp) => {
          const have = products.find((p) => p.name === inp.name);
          const need = inp.qty * count;
          return { inp, have, need, cost: (have?.cost ?? 0) * need };
        });
        const material = parts.reduce((s, p) => s + p.cost, 0);
        const unit = count > 0 ? Math.round(material / count) : 0;
        const short = parts.some((p) => !p.have || p.have.qty < p.need);
        return (
          <Card key={recipe.id}>
            <div className="flex items-start justify-between gap-2">
              <p className="font-extrabold">{recipe.name}</p>
              <p className="text-sm font-bold">{toman(recipe.price)}</p>
            </div>
            <ul className="mt-2 space-y-1 text-sm text-muted">
              {parts.map((part) => (
                <li key={part.inp.name}>
                  {part.inp.name} × {part.need.toLocaleString("fa-IR")} — موجودی {part.have ? part.have.qty.toLocaleString("fa-IR") : "ندارد"} — {toman(part.cost)}
                </li>
              ))}
            </ul>
            <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
              <p>
                بهای واحد ساخت
                <span className="mt-1 block font-extrabold">{toman(unit)}</span>
              </p>
              <p>
                حاشیه نسبت به فروش
                <span className="mt-1 block font-extrabold">{toman(recipe.price - unit)}</span>
              </p>
            </div>
            <div className="mt-3 flex gap-2">
              <input
                className={inputClass}
                inputMode="numeric"
                value={qty[recipe.id] ?? "1"}
                onChange={(e) => setQty((prev) => ({ ...prev, [recipe.id]: e.target.value.replace(/[^\d]/g, "") }))}
              />
              <Btn className="shrink-0" disabled={short || count <= 0} onClick={() => toastMsg(postProduction(recipe.id, count))}>
                تولید
              </Btn>
            </div>
          </Card>
        );
      })}
    </div>
  );
}

export function ControlView() {
  const products = useLedger((s) => s.products);
  const moves = useLedger((s) => s.moves);
  const entries = useLedger((s) => s.entries);
  const invoices = useLedger((s) => s.invoices);
  const trial = useMemo(() => trialOf(entries), [entries]);
  const kpi = useMemo(() => kpisOf(entries, products, invoices.filter((i) => i.status === "draft").length), [entries, products, invoices]);
  const mismatches = products.filter((p) => moveQty(moves, p.id) !== p.qty);
  const book = trial.rows.find((r) => r.code === "1300")?.debit ?? 0;
  const kardex = kardexValue(products);
  const gap = Math.abs(book - kardex);
  return (
    <div className="space-y-3">
      <Card>
        <p className="font-extrabold">{trial.ok ? "تراز سند دوبل متوازن است" : "تراز نامتوازن است"}</p>
        <p className="mt-1 text-sm text-muted">
          پیش‌نویس {kpi.drafts.toLocaleString("fa-IR")} · کالای زیر حداقل {kpi.low.toLocaleString("fa-IR")} · موجودی منفی {kpi.negative.toLocaleString("fa-IR")}
        </p>
      </Card>
      <Card>
        <p className="font-extrabold">{gap < 1000 ? "کاردکس با حساب موجودی هم‌خوان است" : "مغایرت ارزش موجودی"}</p>
        <p className="mt-1 text-sm text-muted">
          دفتر {toman(book)} · کاردکس {toman(kardex)}
          {gap >= 1000 ? ` · اختلاف ${toman(gap)}` : gap > 0 ? ` · اختلاف گرد کردن ${toman(gap)}` : ""}
        </p>
        {mismatches.length > 0 && (
          <ul className="mt-2 text-sm text-bad">
            {mismatches.map((p) => (
              <li key={p.id}>
                {p.name}: کارت {moveQty(moves, p.id).toLocaleString("fa-IR")} / کارتکس کالا {p.qty.toLocaleString("fa-IR")}
              </li>
            ))}
          </ul>
        )}
      </Card>
      <Card>
        <p className="font-extrabold">کالاهای کم‌موجود</p>
        <ul className="mt-2 space-y-1 text-sm">
          {products.filter((p) => p.qty <= p.minQty).length === 0 && <li className="text-muted">موردی نیست.</li>}
          {products
            .filter((p) => p.qty <= p.minQty)
            .map((p) => (
              <li key={p.id}>
                {p.name} — {p.qty.toLocaleString("fa-IR")} از حداقل {p.minQty.toLocaleString("fa-IR")}
              </li>
            ))}
        </ul>
      </Card>
    </div>
  );
}

export function SettingsView() {
  const settings = useLedger((s) => s.settings);
  const updateSettings = useLedger((s) => s.updateSettings);
  const resetDemo = useLedger((s) => s.resetDemo);
  return (
    <div className="space-y-3">
      <Card className="space-y-3">
        <Field label="نام فروشگاه">
          <input className={inputClass} value={settings.shopName} onChange={(e) => updateSettings({ shopName: e.target.value })} />
        </Field>
        <Field label="تلفن">
          <input className={inputClass} value={settings.phone} onChange={(e) => updateSettings({ phone: e.target.value })} />
        </Field>
        <Field label="نشانی">
          <input className={inputClass} value={settings.address} onChange={(e) => updateSettings({ address: e.target.value })} />
        </Field>
        <Field label="کد اقتصادی">
          <input className={inputClass} value={settings.economicCode} onChange={(e) => updateSettings({ economicCode: e.target.value })} />
        </Field>
        <Field label="نرخ مالیات درصد">
          <input
            className={inputClass}
            inputMode="numeric"
            value={String(settings.taxRate)}
            onChange={(e) => updateSettings({ taxRate: Number(e.target.value.replace(/[^\d]/g, "")) || 0 })}
          />
        </Field>
      </Card>
      <Card>
        <p className="text-sm leading-7 text-muted">
          فقط عملیات تأییدشده به دفتر روزنامه می‌رود. پیش‌فاکتور سند نمی‌سازد. فروش، هم‌زمان دریافتنی یا صندوق، فروش، مالیات، بهای تمام‌شده و خروج موجودی را ثبت می‌کند.
        </p>
        <Btn
          variant="danger"
          className="mt-3 w-full"
          onClick={() => {
            resetDemo();
            toast.success("داده نمونه از نو بارگذاری شد.");
          }}
        >
          بازنشانی داده نمونه
        </Btn>
      </Card>
    </div>
  );
}

function toastMsg(res: { ok: boolean; message: string }) {
  if (res.ok) toast.success(res.message);
  else toast.error(res.message);
}
