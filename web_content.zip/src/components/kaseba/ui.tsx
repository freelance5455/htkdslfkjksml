import { cn } from "@/lib/cn";
import type { ButtonHTMLAttributes, ReactNode } from "react";

export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return <section className={cn("rounded-2xl border border-line bg-surface p-4 shadow-sm", className)}>{children}</section>;
}

export function Btn({
  variant = "primary",
  className,
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "navy" | "good" | "soft" | "danger" }) {
  const look = {
    primary: "bg-primary text-on-primary",
    ghost: "border border-line bg-surface text-ink",
    navy: "bg-navy text-on-navy",
    good: "bg-good text-on-primary",
    soft: "bg-primary-soft text-primary",
    danger: "bg-bad-soft text-bad",
  }[variant];
  return (
    <button
      type={type}
      className={cn(
        "inline-flex h-11 items-center justify-center gap-2 rounded-xl px-4 text-sm font-semibold transition active:scale-[0.98] disabled:opacity-50",
        look,
        className,
      )}
      {...props}
    />
  );
}

export function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-medium text-muted">{label}</span>
      {children}
    </label>
  );
}

export const inputClass =
  "h-11 w-full rounded-xl border border-line bg-canvas px-3 text-sm text-ink outline-none focus:border-primary";

export function Chips({
  value,
  onChange,
  options,
}: {
  value: string;
  onChange: (id: string) => void;
  options: { id: string; label: string }[];
}) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-1">
      {options.map((o) => {
        const on = value === o.id;
        return (
          <button
            key={o.id}
            type="button"
            onClick={() => onChange(o.id)}
            className={cn(
              "h-9 shrink-0 rounded-full px-3 text-xs font-semibold",
              on ? "border border-line bg-surface text-ink shadow-sm" : "text-muted",
            )}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

export function Sheet({
  open,
  title,
  onClose,
  children,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center md:items-center">
      <button type="button" className="absolute inset-0 bg-navy/45" aria-label="بستن" onClick={onClose} />
      <div
        role="dialog"
        aria-modal="true"
        className="relative max-h-[85dvh] w-full max-w-lg overflow-y-auto rounded-t-3xl bg-surface p-4 pb-8 shadow-xl md:rounded-3xl"
      >
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 className="text-base font-extrabold">{title}</h2>
          <button type="button" onClick={onClose} className="grid size-10 place-items-center rounded-full bg-canvas text-sm text-muted">
            بستن
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Mark({ className }: { className?: string }) {
  return (
    <span className={cn("grid size-10 place-items-center rounded-xl bg-navy text-base font-extrabold text-white ring-1 ring-gold", className)}>
      ک
    </span>
  );
}

export function Money({ value, className }: { value: number; className?: string }) {
  return <span className={cn("font-bold tabular-nums", className)}>{value.toLocaleString("fa-IR")}</span>;
}
