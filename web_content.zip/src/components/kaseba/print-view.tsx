import { useState } from "react";
import { toman } from "@/lib/accounting/format";
import { formatJalali } from "@/lib/accounting/jalali";
import { useLedger } from "@/lib/accounting/store";
import type { Invoice, Settings } from "@/lib/accounting/types";
import { cn } from "@/lib/cn";
import { Btn } from "./ui";

export type TemplateId = "formal" | "tax" | "letter" | "clean";

const TEMPLATES: { id: TemplateId; title: string; hint: string }[] = [
  { id: "formal", title: "رسمی جدول‌دار", hint: "جدول کامل با اطلاعات خریدار حقوقی" },
  { id: "tax", title: "رسمی مالیاتی", hint: "کد اقتصادی و ردیف مالیات ارزش افزوده" },
  { id: "letter", title: "سربرگ‌دار امروزی", hint: "سربرگ رنگی با جمع برجسته" },
  { id: "clean", title: "سربرگ و پاک", hint: "حداقل خط، مناسب اشتراک تصویری" },
];

export function InvoicePaper({
  invoice,
  settings,
  template,
}: {
  invoice: Invoice;
  settings: Settings;
  template: TemplateId;
}) {
  const band =
    template === "letter" ? "bg-primary text-on-primary" : template === "clean" ? "border-b-2 border-gold bg-surface text-ink" : "bg-navy text-on-navy";
  const boxed = template === "formal" || template === "tax";
  return (
    <article className="bg-surface px-4 py-5 text-ink">
      <header className={cn("rounded-xl px-4 py-3", band)}>
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-lg font-extrabold">{settings.shopName}</p>
            <p className={cn("text-xs", template === "clean" ? "text-muted" : "text-on-navy/75")}>فاکتور {invoice.kind === "proforma" ? "پیش‌نویس" : "فروش"}</p>
          </div>
          <div className="text-left">
            <p className="text-sm font-bold">شماره {invoice.number.toLocaleString("fa-IR")}</p>
            <p className={cn("text-xs", template === "clean" ? "text-muted" : "text-on-navy/75")}>{formatJalali(invoice.date)}</p>
          </div>
        </div>
      </header>
      <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
        <p>
          <span className="text-muted">خریدار: </span>
          {invoice.partyName}
        </p>
        <p>
          <span className="text-muted">تسویه: </span>
          {invoice.payLabel}
        </p>
        {template === "tax" && (
          <>
            <p>
              <span className="text-muted">کد اقتصادی فروشنده: </span>
              {settings.economicCode}
            </p>
            <p>
              <span className="text-muted">تلفن: </span>
              <span dir="ltr">{settings.phone}</span>
            </p>
          </>
        )}
      </div>
      <table className={cn("mt-3 w-full border-collapse text-xs", boxed && "border border-line")}>
        <thead>
          <tr className={cn(boxed ? "bg-canvas" : "border-b border-line")}>
            <th className="px-2 py-2 text-right font-semibold">ردیف</th>
            <th className="px-2 py-2 text-right font-semibold">شرح</th>
            <th className="px-2 py-2 text-center font-semibold">تعداد</th>
            <th className="px-2 py-2 text-left font-semibold">مبلغ</th>
          </tr>
        </thead>
        <tbody>
          {invoice.lines.map((line, i) => (
            <tr key={line.name + i} className={boxed ? "border-t border-line" : "border-b border-line"}>
              <td className="px-2 py-2">{(i + 1).toLocaleString("fa-IR")}</td>
              <td className="px-2 py-2">
                {line.name}
                <span className="mt-0.5 block text-muted">فی {toman(line.price)}</span>
              </td>
              <td className="px-2 py-2 text-center">{line.qty.toLocaleString("fa-IR")}</td>
              <td className="px-2 py-2 text-left font-semibold">{toman(line.amount)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <dl className="mt-3 space-y-1 text-xs">
        <div className="flex justify-between">
          <dt className="text-muted">جمع کالا</dt>
          <dd>{toman(invoice.gross)}</dd>
        </div>
        {invoice.discount > 0 && (
          <div className="flex justify-between">
            <dt className="text-muted">تخفیف</dt>
            <dd>{toman(invoice.discount)}</dd>
          </div>
        )}
        <div className="flex justify-between">
          <dt className="text-muted">مالیات</dt>
          <dd>{toman(invoice.tax)}</dd>
        </div>
        {invoice.extras > 0 && (
          <div className="flex justify-between">
            <dt className="text-muted">هزینه جانبی</dt>
            <dd>{toman(invoice.extras)}</dd>
          </div>
        )}
        <div className="flex justify-between border-t border-line pt-2 text-sm font-extrabold">
          <dt>قابل پرداخت</dt>
          <dd>{toman(invoice.total)} تومان</dd>
        </div>
      </dl>
      {template === "tax" && <p className="mt-3 text-xs text-muted">مالیات بر ارزش افزوده طبق نرخ قانونی در جمع بالا محاسبه شده است.</p>}
      <footer className="mt-6 flex items-end justify-between text-xs text-muted">
        <p>
          {settings.address}
          <br />
          {settings.phone}
        </p>
        <p className="text-left">
          امضا و مهر فروشنده
          <span className="mt-6 block w-24 border-b border-line" />
        </p>
      </footer>
    </article>
  );
}

export function PrintOverlay() {
  const invoiceId = useLedger((s) => s.focusInvoiceId);
  const invoice = useLedger((s) => s.invoices.find((i) => i.id === invoiceId) ?? null);
  const settings = useLedger((s) => s.settings);
  const setFocus = useLedger((s) => s.setFocus);
  const [template, setTemplate] = useState<TemplateId>("formal");
  if (!invoice) return null;
  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-navy/55">
      <div className="no-print mx-auto flex max-w-lg items-center justify-between px-4 py-3 text-on-navy">
        <button type="button" className="grid size-10 place-items-center rounded-full bg-on-navy/15" onClick={() => setFocus(null)}>
          ×
        </button>
        <div className="text-center">
          <p className="font-extrabold">فاکتور {invoice.number.toLocaleString("fa-IR")}</p>
          <p className="text-xs text-on-navy/75">
            {invoice.partyName} · {toman(invoice.total)} تومان
          </p>
        </div>
        <span className="w-10" />
      </div>
      <div id="print-root" className="mx-auto max-w-lg overflow-hidden bg-surface shadow-xl">
        <InvoicePaper invoice={invoice} settings={settings} template={template} />
      </div>
      <div className="no-print mx-auto max-w-lg space-y-3 px-4 py-4">
        <div className="grid grid-cols-4 gap-2">
          {TEMPLATES.map((tpl) => (
            <button
              key={tpl.id}
              type="button"
              onClick={() => setTemplate(tpl.id)}
              className={cn(
                "rounded-2xl border px-1 py-2 text-center text-xs font-semibold",
                template === tpl.id ? "border-primary bg-primary text-on-primary" : "border-line bg-surface text-ink",
              )}
            >
              {tpl.title}
            </button>
          ))}
        </div>
        <p className="text-center text-xs text-on-navy/80">{TEMPLATES.find((t) => t.id === template)?.hint}</p>
        <Btn className="w-full" onClick={() => window.print()}>
          چاپ
        </Btn>
        <div className="grid grid-cols-2 gap-2">
          <Btn
            variant="ghost"
            onClick={() => shareInvoice(invoice, "image")}
          >
            اشتراک عکس
          </Btn>
          <Btn variant="ghost" onClick={() => shareInvoice(invoice, "pdf")}>
            اشتراک PDF
          </Btn>
        </div>
      </div>
    </div>
  );
}

async function shareInvoice(invoice: Invoice, mode: "image" | "pdf") {
  const text = `${invoice.kind === "proforma" ? "پیش‌فاکتور" : "فاکتور"} ${invoice.number} — ${invoice.partyName}\n${invoice.lines
    .map((l) => `${l.name} × ${l.qty} = ${toman(l.amount)}`)
    .join("\n")}\nقابل پرداخت: ${toman(invoice.total)} تومان`;
  const nav = navigator as Navigator & { share?: (data: ShareData) => Promise<void> };
  if (nav.share) {
    try {
      await nav.share({ title: `فاکتور ${invoice.number}`, text });
      return;
    } catch {
      /* dismissed */
    }
  }
  try {
    await navigator.clipboard.writeText(text);
    const { toast } = await import("sonner");
    toast.success(mode === "pdf" ? "متن فاکتور کپی شد. چاپ را برای PDF انتخاب کنید." : "متن فاکتور برای اشتراک کپی شد.");
  } catch {
    window.print();
  }
}
