import { useMemo, useState } from "react";
import { toast } from "sonner";
import { partyRows, partySummary } from "@/lib/accounting/engine";
import { maskPhone, toman } from "@/lib/accounting/format";
import { useLedger } from "@/lib/accounting/store";
import { cn } from "@/lib/cn";
import { Btn, Chips, Field, inputClass, Sheet } from "./ui";

type Filter = "all" | "debtor" | "creditor";

export function PartiesView() {
  const parties = useLedger((s) => s.parties);
  const entries = useLedger((s) => s.entries);
  const addParty = useLedger((s) => s.addParty);
  const resetDraft = useLedger((s) => s.resetDraft);
  const setView = useLedger((s) => s.setView);
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<Filter>("all");
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");

  const rows = useMemo(() => partyRows(entries, parties), [entries, parties]);
  const summary = useMemo(() => partySummary(rows), [rows]);
  const shown = rows.filter((r) => {
    if (q && !r.name.includes(q.trim()) && !r.phone.includes(q.trim())) return false;
    if (filter === "debtor") return r.net > 0;
    if (filter === "creditor") return r.net < 0;
    return true;
  });
  const debtorCount = rows.filter((r) => r.net > 0).length;
  const creditorCount = rows.filter((r) => r.net < 0).length;

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-3 gap-2">
        <Sum label="تراز" value={summary.balance} tone="bad" />
        <Sum label="بستانکاران" value={summary.creditors} tone="navy" />
        <Sum label="بدهکاران" value={summary.debtors} tone="warn" />
      </div>
      <div className="flex gap-2">
        <input className={inputClass} placeholder="نام یا شماره…" value={q} onChange={(e) => setQ(e.target.value)} />
        <Btn className="shrink-0 px-3" onClick={() => setCreating(true)}>
          شخص جدید
        </Btn>
      </div>
      <Chips
        value={filter}
        onChange={(id) => setFilter(id as Filter)}
        options={[
          { id: "all", label: `همه ${rows.length.toLocaleString("fa-IR")}` },
          { id: "creditor", label: `بستانکار ${creditorCount.toLocaleString("fa-IR")}` },
          { id: "debtor", label: `بدهکار ${debtorCount.toLocaleString("fa-IR")}` },
        ]}
      />
      <ul className="space-y-2">
        {shown.map((r) => (
          <li key={r.id} className="flex items-center gap-3 rounded-2xl border border-line bg-surface px-3 py-3 shadow-sm">
            <span className="grid size-11 shrink-0 place-items-center rounded-full bg-primary-soft text-sm font-extrabold text-primary">
              {r.name.trim().slice(0, 1)}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate font-semibold">{r.name}</p>
              <p className="text-xs text-muted" dir="ltr">
                {maskPhone(r.phone)}
              </p>
            </div>
            <div className="text-left">
              <p className={cn("text-sm font-extrabold", r.net > 0 ? "text-warn" : r.net < 0 ? "text-primary" : "text-good")}>
                {r.net === 0 ? "تسویه" : toman(Math.abs(r.net))}
              </p>
              {r.net !== 0 && <p className="text-xs text-muted">{r.label}</p>}
            </div>
          </li>
        ))}
      </ul>
      <Sheet open={creating} title="شخص جدید" onClose={() => setCreating(false)}>
        <form
          className="space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            const res = addParty({ name, phone });
            if (!res.ok) {
              toast.error(res.message);
              return;
            }
            toast.success(res.message);
            setName("");
            setPhone("");
            setCreating(false);
          }}
        >
          <Field label="نام">
            <input className={inputClass} value={name} onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="موبایل">
            <input className={inputClass} dir="ltr" value={phone} onChange={(e) => setPhone(e.target.value)} />
          </Field>
          <Btn type="submit" className="w-full">
            ثبت
          </Btn>
        </form>
      </Sheet>
      <Btn
        variant="soft"
        className="w-full"
        onClick={() => {
          resetDraft(null);
          setView("invoice");
        }}
      >
        فاکتور برای مشتری
      </Btn>
    </div>
  );
}

function Sum({ label, value, tone }: { label: string; value: number; tone: "bad" | "navy" | "warn" }) {
  const color = tone === "bad" ? "text-bad" : tone === "warn" ? "text-warn" : "text-primary";
  return (
    <div className="rounded-2xl border border-line bg-surface px-2 py-3 text-center shadow-sm">
      <p className="text-xs text-muted">{label}</p>
      <p className={cn("mt-1 text-sm font-extrabold", color)}>{toman(value)}</p>
    </div>
  );
}
