import { useMemo, useState } from "react";
import { toast } from "sonner";
import { CHART, SOURCE_LABEL, accountName } from "@/lib/accounting/chart";
import { ledgerOf, trialOf } from "@/lib/accounting/engine";
import { toman } from "@/lib/accounting/format";
import { TODAY, formatJalali } from "@/lib/accounting/jalali";
import { useLedger } from "@/lib/accounting/store";
import { cn } from "@/lib/cn";
import { Btn, Chips, Field, inputClass, Sheet } from "./ui";

type Tab = "journal" | "ledger" | "trial";

export function BooksView() {
  const entries = useLedger((s) => s.entries);
  const postManual = useLedger((s) => s.postManual);
  const [tab, setTab] = useState<Tab>("journal");
  const [code, setCode] = useState("1100");
  const [manual, setManual] = useState(false);
  const trial = useMemo(() => trialOf(entries), [entries]);
  const ledger = useMemo(() => ledgerOf(entries, code), [entries, code]);
  const journal = useMemo(() => [...entries].sort((a, b) => b.date.localeCompare(a.date) || b.number.localeCompare(a.number)), [entries]);

  return (
    <div className="space-y-3">
      <Chips
        value={tab}
        onChange={(id) => setTab(id as Tab)}
        options={[
          { id: "journal", label: "دفتر روزنامه" },
          { id: "ledger", label: "دفتر کل" },
          { id: "trial", label: "تراز آزمایشی" },
        ]}
      />
      <div className={cn("rounded-2xl px-3 py-2 text-sm font-semibold", trial.ok ? "bg-good-soft text-good" : "bg-bad-soft text-bad")}>
        {trial.ok ? "جمع بدهکار و بستانکار برابر است." : "تراز نامتوازن است."} {toman(trial.debit)} تومان
      </div>
      <Btn variant="ghost" onClick={() => setManual(true)}>
        سند دستی
      </Btn>

      {tab === "journal" && (
        <ul className="space-y-2">
          {journal.map((e) => (
            <li key={e.id} className="rounded-2xl border border-line bg-surface p-3 shadow-sm">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-bold">{e.desc}</p>
                  <p className="text-xs text-muted">
                    سند {Number(e.number).toLocaleString("fa-IR")} · {SOURCE_LABEL[e.source]} · {formatJalali(e.date)}
                  </p>
                </div>
              </div>
              <ul className="mt-2 space-y-1 text-xs">
                {e.lines.map((l, i) => (
                  <li key={i} className="grid grid-cols-[1fr_auto_auto] gap-2">
                    <span>{accountName(l.accountCode)}</span>
                    <span className="w-20 text-left">{l.debit ? toman(l.debit) : "—"}</span>
                    <span className="w-20 text-left">{l.credit ? toman(l.credit) : "—"}</span>
                  </li>
                ))}
              </ul>
            </li>
          ))}
        </ul>
      )}

      {tab === "ledger" && (
        <div className="space-y-2">
          <select className={inputClass} value={code} onChange={(e) => setCode(e.target.value)}>
            {CHART.map((a) => (
              <option key={a.code} value={a.code}>
                {a.code} — {a.name}
              </option>
            ))}
          </select>
          <ul className="space-y-1">
            {ledger.length === 0 && <li className="text-sm text-muted">گردشی برای این حساب نیست.</li>}
            {ledger.map((l) => (
              <li key={l.id} className="rounded-xl border border-line bg-surface px-3 py-2 text-sm">
                <div className="flex justify-between gap-2">
                  <span className="font-semibold">{l.desc}</span>
                  <span className="text-xs text-muted">{formatJalali(l.date)}</span>
                </div>
                <p className="mt-1 text-xs text-muted">
                  بدهکار {toman(l.debit)} · بستانکار {toman(l.credit)} · مانده {toman(l.balance)}
                </p>
              </li>
            ))}
          </ul>
        </div>
      )}

      {tab === "trial" && (
        <div className="overflow-hidden rounded-2xl border border-line bg-surface">
          <div className="grid grid-cols-[1fr_auto_auto] gap-2 border-b border-line px-3 py-2 text-xs text-muted">
            <span>حساب</span>
            <span>بدهکار</span>
            <span>بستانکار</span>
          </div>
          {trial.rows.map((r) => (
            <div key={r.code} className="grid grid-cols-[1fr_auto_auto] gap-2 border-b border-line px-3 py-2 text-sm last:border-b-0">
              <span>
                <span className="text-muted">{r.code} </span>
                {r.name}
              </span>
              <span className="font-semibold">{r.debit ? toman(r.debit) : "—"}</span>
              <span className="font-semibold">{r.credit ? toman(r.credit) : "—"}</span>
            </div>
          ))}
          <div className="grid grid-cols-[1fr_auto_auto] gap-2 bg-canvas px-3 py-2 text-sm font-extrabold">
            <span>جمع</span>
            <span>{toman(trial.debit)}</span>
            <span>{toman(trial.credit)}</span>
          </div>
        </div>
      )}

      <ManualSheet
        open={manual}
        onClose={() => setManual(false)}
        onPost={(input) => {
          const res = postManual(input);
          if (res.ok) {
            toast.success(res.message);
            setManual(false);
          } else toast.error(res.message);
        }}
      />
    </div>
  );
}

function ManualSheet({
  open,
  onClose,
  onPost,
}: {
  open: boolean;
  onClose: () => void;
  onPost: (input: { date: string; desc: string; lines: { accountCode: string; debit: number; credit: number }[] }) => void;
}) {
  const [desc, setDesc] = useState("");
  const [rows, setRows] = useState([
    { accountCode: "5200", debit: "", credit: "" },
    { accountCode: "1100", debit: "", credit: "" },
  ]);
  const debit = rows.reduce((s, r) => s + (Number(r.debit) || 0), 0);
  const credit = rows.reduce((s, r) => s + (Number(r.credit) || 0), 0);
  return (
    <Sheet open={open} title="سند دستی" onClose={onClose}>
      <div className="space-y-2">
        <Field label="شرح">
          <input className={inputClass} value={desc} onChange={(e) => setDesc(e.target.value)} />
        </Field>
        {rows.map((r, i) => (
          <div key={i} className="grid grid-cols-3 gap-2">
            <select
              className={inputClass}
              value={r.accountCode}
              onChange={(e) => setRows(rows.map((x, idx) => (idx === i ? { ...x, accountCode: e.target.value } : x)))}
            >
              {CHART.map((a) => (
                <option key={a.code} value={a.code}>
                  {a.name}
                </option>
              ))}
            </select>
            <input
              className={inputClass}
              inputMode="numeric"
              placeholder="بدهکار"
              value={r.debit}
              onChange={(e) => setRows(rows.map((x, idx) => (idx === i ? { ...x, debit: e.target.value.replace(/[^\d]/g, "") } : x)))}
            />
            <input
              className={inputClass}
              inputMode="numeric"
              placeholder="بستانکار"
              value={r.credit}
              onChange={(e) => setRows(rows.map((x, idx) => (idx === i ? { ...x, credit: e.target.value.replace(/[^\d]/g, "") } : x)))}
            />
          </div>
        ))}
        <button
          type="button"
          className="text-sm font-bold text-primary"
          onClick={() => setRows([...rows, { accountCode: "1100", debit: "", credit: "" }])}
        >
          ردیف تازه
        </button>
        <p className={cn("text-sm font-bold", debit === credit ? "text-good" : "text-bad")}>
          بدهکار {toman(debit)} · بستانکار {toman(credit)}
        </p>
        <Btn
          className="w-full"
          onClick={() =>
            onPost({
              date: TODAY,
              desc,
              lines: rows.map((r) => ({ accountCode: r.accountCode, debit: Number(r.debit) || 0, credit: Number(r.credit) || 0 })),
            })
          }
        >
          ثبت سند
        </Btn>
      </div>
    </Sheet>
  );
}
