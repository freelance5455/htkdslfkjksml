import {
  Battery,
  Brush,
  Candy,
  Cuboid,
  Droplets,
  Fish,
  Flame,
  FlaskConical,
  Layers,
  Leaf,
  Lightbulb,
  Milk,
  Notebook,
  Package,
  PenLine,
  Sparkles,
  SprayCan,
  Utensils,
  Wheat,
  type LucideIcon,
} from "lucide-react";

const ICONS: Record<string, LucideIcon> = {
  droplets: Droplets,
  leaf: Leaf,
  wheat: Wheat,
  flask: FlaskConical,
  flame: Flame,
  spray: SprayCan,
  layers: Layers,
  candy: Candy,
  pen: PenLine,
  brush: Brush,
  bulb: Lightbulb,
  milk: Milk,
  pasta: Utensils,
  fish: Fish,
  cube: Cuboid,
  spark: Sparkles,
  battery: Battery,
  notebook: Notebook,
  package: Package,
};

export function ProductGlyph({ icon, className }: { icon: string; className?: string }) {
  const Icon = ICONS[icon] ?? Package;
  return <Icon className={className} strokeWidth={1.75} />;
}
