import { useState } from "react";
import { Mic } from "lucide-react";
import { toast } from "sonner";
import { toman } from "@/lib/accounting/format";
import { useLedger } from "@/lib/accounting/store";
import { parseCommand } from "@/lib/accounting/voice";
import { Btn } from "./ui";

type Rec = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start: () => void;
  stop: () => void;
  onresult: ((ev: { resultIndex: number; results: ArrayLike<{ 0: { transcript: string }; isFinal: boolean }> }) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
};

function getRecognizer() {
  const w = window as Window & { SpeechRecognition?: new () => Rec; webkitSpeechRecognition?: new () => Rec };
  const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
  if (!Ctor) return null;
  const rec = new Ctor();
  rec.lang = "fa-IR";
  rec.continuous = true;
  rec.interimResults = true;
  return rec;
}

const SAMPLE = "فروش مسواک دو تا لامپ یه دونه به رضا اکبری";

export function AssistantView() {
  const products = useLedger((s) => s.products);
  const parties = useLedger((s) => s.parties);
  const applyVoiceLines = useLedger((s) => s.applyVoiceLines);
  const [text, setText] = useState("");
  const [listening, setListening] = useState(false);
  const [note, setNote] = useState("");
  const [rec, setRec] = useState<Rec | null>(null);

  const finish = (raw: string) => {
    const spoken = raw.trim();
    if (!spoken) {
      toast.error("چیزی شنیده نشد. عبارت را بنویسید یا نمونه را بزنید.");
      return;
    }
    const parsed = parseCommand(
      spoken,
      products.map((p) => ({ id: p.id, name: p.name })),
      parties.map((p) => ({ id: p.id, name: p.name })),
    );
    if (parsed.intent === "stock") {
      if (!parsed.items.length) {
        setNote("کالا را در جمله بیاورید. مثلاً: از خودکار آبی چند تا دارم");
        return;
      }
      const lines = parsed.items.map((it) => {
        const p = products.find((x) => x.id === it.product.id);
        return p ? `${p.name}: ${p.qty.toLocaleString("fa-IR")} ${p.unit}، فی ${toman(p.price)}` : it.product.name;
      });
      setNote(lines.join("\n"));
      return;
    }
    if (!parsed.items.length) {
      setNote("کالا را نشناختم. نام را نزدیک موجودی انبار بگویید.");
      return;
    }
    applyVoiceLines(
      parsed.party?.id ?? null,
      parsed.items.map((it) => ({ productId: it.product.id, qty: it.qty })),
    );
    toast.success(parsed.party ? `فاکتور برای ${parsed.party.name} آماده شد.` : "ردیف‌ها روی فاکتور نشست. مشتری را انتخاب کنید.");
  };

  const toggle = () => {
    if (listening && rec) {
      rec.stop();
      setListening(false);
      return;
    }
    const next = getRecognizer();
    if (!next) {
      setNote("میکروفون در این مرورگر نیست. عبارت را بنویسید یا نمونه را بزنید.");
      return;
    }
    next.onresult = (ev) => {
      let said = "";
      for (let i = 0; i < ev.results.length; i++) said += ev.results[i][0].transcript + " ";
      setText(said.trim());
    };
    next.onerror = () => {
      setListening(false);
      setNote("دسترسی میکروفون ممکن نشد. می‌توانید تایپ کنید.");
    };
    next.onend = () => setListening(false);
    try {
      next.start();
      setRec(next);
      setListening(true);
    } catch {
      setNote("میکروفون شروع نشد.");
    }
  };

  return (
    <div className="space-y-4">
      <p className="text-sm leading-7 text-muted">
        سلام. درباره موجودی بپرسید یا فروش را دیکته کنید. قبل از ثبت، فاکتور را نشان می‌دهم تا خودتان ببندید. مثلاً «فروش … به …» یا «از خودکار آبی چند تا دارم».
      </p>
      <button
        type="button"
        onClick={() => {
          setText(SAMPLE);
          setNote("");
        }}
        className="rounded-full bg-primary-soft px-3 py-2 text-xs font-bold text-primary"
      >
        {SAMPLE}
      </button>
      <div className="rounded-3xl border border-line bg-surface px-4 py-8 text-center shadow-sm">
        <button
          type="button"
          onClick={toggle}
          className={`mx-auto grid size-20 place-items-center rounded-full bg-primary text-on-primary ${listening ? "mic-live" : ""}`}
          aria-label={listening ? "توقف شنیدن" : "شروع شنیدن"}
        >
          <Mic className="size-8" />
        </button>
        <p className="mt-4 font-extrabold">{listening ? "بگویید، گوش می‌دهم…" : "برای گفتن، دکمه را بزنید"}</p>
        <textarea
          className="mt-4 min-h-24 w-full rounded-2xl border border-line bg-canvas p-3 text-sm outline-none focus:border-primary"
          placeholder="یا همین‌جا بنویسید"
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        {note && <p className="mt-3 whitespace-pre-wrap text-sm font-semibold text-ink">{note}</p>}
      </div>
      <div className="grid grid-cols-[5rem_1fr] gap-2">
        <Btn
          variant="ghost"
          onClick={() => {
            rec?.stop();
            setListening(false);
            setText("");
            setNote("");
          }}
        >
          لغو
        </Btn>
        <Btn
          onClick={() => {
            rec?.stop();
            setListening(false);
            finish(text);
          }}
        >
          تمام شد
        </Btn>
      </div>
    </div>
  );
}
