import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { RotateCcw, Trophy, CheckCircle2, Clock, Sparkles } from 'lucide-react';
import { GameStats } from '../types/game';

interface VictoryModalProps {
  stats: GameStats;
  onReplay: () => void;
  onBackToMenu: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  stats,
  onReplay,
  onBackToMenu,
}) => {
  useEffect(() => {
    // Launch celebratory colorful confetti bursts
    const count = 200;
    const defaults = {
      origin: { y: 0.65 },
    };

    function fire(particleRatio: number, opts: confetti.Options) {
      confetti({
        ...defaults,
        ...opts,
        particleCount: Math.floor(count * particleRatio),
      });
    }

    fire(0.25, {
      spread: 26,
      startVelocity: 55,
      colors: ['#38bdf8', '#fbbf24', '#34d399'],
    });
    fire(0.2, {
      spread: 60,
      colors: ['#f43f5e', '#a855f7', '#fbbf24'],
    });
    fire(0.35, {
      spread: 100,
      decay: 0.91,
      scalar: 0.8,
    });
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 10);
    return `${mins}m ${secs}.${ms}s`;
  };

  return (
    <div className="absolute inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border-2 border-emerald-500/80 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl shadow-emerald-950/60 text-center flex flex-col items-center space-y-5 animate-in fade-in zoom-in-95 duration-200">
        {/* Glow badge */}
        <div className="w-20 h-20 rounded-2xl bg-linear-to-tr from-emerald-500 to-teal-400 flex items-center justify-center shadow-xl shadow-emerald-500/40 border-2 border-white">
          <CheckCircle2 className="w-12 h-12 text-slate-950 stroke-[2.5]" />
        </div>

        <div>
          <h2 className="text-4xl sm:text-5xl font-black text-white tracking-tight drop-shadow-md">
            ESCAPED!
          </h2>
          <p className="text-emerald-300 font-semibold text-sm sm:text-base mt-1">
            You navigated the maze and reached the portal safely!
          </p>
        </div>

        {/* Stats Grid */}
        <div className="w-full grid grid-cols-2 gap-3 bg-slate-950/60 rounded-2xl p-4 border border-slate-800">
          <div className="flex flex-col items-center p-2 rounded-xl bg-slate-900/60">
            <Clock className="w-4 h-4 text-amber-400 mb-1" />
            <span className="text-[11px] uppercase font-bold text-slate-400">ESCAPE TIME</span>
            <span className="font-mono-num font-bold text-white text-base">
              {formatTime(stats.timeElapsed)}
            </span>
          </div>

          <div className="flex flex-col items-center p-2 rounded-xl bg-slate-900/60">
            <Trophy className="w-4 h-4 text-yellow-400 mb-1" />
            <span className="text-[11px] uppercase font-bold text-slate-400">SURVIVAL SCORE</span>
            <span className="font-mono-num font-bold text-amber-400 text-base">
              {stats.score.toLocaleString()}
            </span>
          </div>

          <div className="flex flex-col items-center p-2 rounded-xl bg-slate-900/60">
            <span className="text-sm mb-1">💎</span>
            <span className="text-[11px] uppercase font-bold text-slate-400">CRYSTALS</span>
            <span className="font-mono-num font-bold text-cyan-300 text-sm">
              {stats.crystalsCollected}/{stats.totalCrystals} (Unlocked!)
            </span>
          </div>

          <div className="flex flex-col items-center p-2 rounded-xl bg-slate-900/60">
            <span className="text-sm mb-1">🪜</span>
            <span className="text-[11px] uppercase font-bold text-slate-400">LADDERS USED</span>
            <span className="font-mono-num font-bold text-slate-200 text-sm">
              {stats.laddersUsed}
            </span>
          </div>
        </div>

        {/* Replay & Menu buttons */}
        <div className="w-full flex flex-col space-y-2.5">
          <button
            onClick={onReplay}
            className="w-full py-3.5 px-6 rounded-2xl bg-linear-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 active:scale-95 text-slate-950 font-black text-lg shadow-xl shadow-emerald-500/40 border-2 border-white flex items-center justify-center space-x-2 transition cursor-pointer"
          >
            <RotateCcw className="w-5 h-5 stroke-[2.5]" />
            <span>REPLAY</span>
          </button>

          <button
            onClick={onBackToMenu}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-bold text-sm transition"
          >
            Main Menu
          </button>
        </div>

        <div className="flex items-center space-x-1.5 text-xs text-emerald-400/80 font-medium">
          <Sparkles className="w-3.5 h-3.5" />
          <span>New procedural maze generated on each replay!</span>
        </div>
      </div>
    </div>
  );
};
