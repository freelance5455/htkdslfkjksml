import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Mission, Language } from '../types/game';
import { soundEngine } from '../audio/soundSystem';

interface VictoryModalProps {
  mission: Mission;
  isGrandFinale: boolean;
  coins: number;
  stars: number;
  language: Language;
  onNextLevel: () => void;
  onReplayLevel: () => void;
  onReturnTitle: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  mission,
  isGrandFinale,
  coins,
  stars,
  language,
  onNextLevel,
  onReplayLevel,
  onReturnTitle,
}) => {
  useEffect(() => {
    soundEngine.playVictory();

    // Shoot confetti burst
    confetti({
      particleCount: isGrandFinale ? 140 : 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#f59e0b', '#0284c7', '#ec4899', '#10b981', '#f43f5e'],
    });

    if (isGrandFinale) {
      setTimeout(() => {
        confetti({
          particleCount: 100,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
        });
        confetti({
          particleCount: 100,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
        });
      }, 350);
    }
  }, [isGrandFinale]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 pointer-events-auto animate-fade-in">
      <div className="w-full max-w-lg bg-gradient-to-b from-amber-950 via-slate-900 to-slate-950 border-2 border-amber-400 rounded-3xl p-6 shadow-2xl text-white text-center relative overflow-hidden">
        {/* Decorative Top Sunburst Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-72 h-32 bg-amber-400/20 blur-3xl pointer-events-none rounded-full" />

        {/* Big Trophy / Star Icon */}
        <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 border-4 border-white flex items-center justify-center text-4xl shadow-xl mb-4">
          {isGrandFinale ? '🏆' : '⭐'}
        </div>

        {/* Title */}
        <h2 className="text-2xl md:text-3xl font-black text-amber-300">
          {isGrandFinale
            ? (language === 'hinglish' ? '🎉 Maha Vijeta! Family United!' : '🎉 Grand Victory! Family United!')
            : (language === 'hinglish' ? 'Mission Kamyab! (Level Clear)' : 'Mission Complete!')}
        </h2>

        <p className="text-xs md:text-sm text-slate-200 mt-2 font-medium max-w-md mx-auto">
          {mission.cutsceneSummary[language]}
        </p>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3 my-5 p-3 rounded-2xl bg-black/40 border border-amber-500/30">
          <div className="flex flex-col items-center">
            <span className="text-xs text-slate-400 font-bold uppercase">Total Coins</span>
            <span className="text-lg font-black text-amber-300 flex items-center gap-1">
              <span>🪙</span> {coins}
            </span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-xs text-slate-400 font-bold uppercase">Stars Discovered</span>
            <span className="text-lg font-black text-yellow-300 flex items-center gap-1">
              <span>⭐</span> {stars} / 4
            </span>
          </div>
        </div>

        {/* Final Family Celebration Note */}
        {isGrandFinale && (
          <div className="mb-5 p-3 rounded-2xl bg-amber-500/15 border border-amber-400/40 text-xs text-amber-100 font-semibold leading-relaxed">
            {language === 'hinglish'
              ? 'Mr. Ripin, Mrs. Anjeeta, Arav aur Akshhara sabhi Ayush ke clever dimag aur pyar se khush hain! Poora parivar ek saath jashn mana raha hai!'
              : 'Mr. Ripin, Mrs. Anjeeta, Arav and Akshhara are overjoyed! Ayush has brought harmony, smiles and laughter to the entire family!'}
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex flex-col gap-2.5">
          {!isGrandFinale ? (
            <button
              onClick={onNextLevel}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-500 hover:from-amber-400 hover:to-orange-400 active:scale-95 text-slate-950 font-black shadow-xl transition-transform text-sm md:text-base border border-amber-200 flex items-center justify-center gap-2"
            >
              <span>{language === 'hinglish' ? 'Agla Mission Shuru Karein ➔' : 'Next Mission ➔'}</span>
            </button>
          ) : (
            <button
              onClick={onReturnTitle}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:from-amber-400 active:scale-95 text-slate-950 font-black shadow-xl transition-transform text-sm md:text-base border border-amber-200"
            >
              <span>{language === 'hinglish' ? '👑 Main Menu & Replay' : '👑 Main Menu & Replay'}</span>
            </button>
          )}

          <div className="flex items-center gap-2">
            <button
              onClick={onReplayLevel}
              className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-xs font-bold text-amber-200 border border-slate-700 transition-transform"
            >
              {language === 'hinglish' ? '🔄 Replay Level' : '🔄 Replay Level'}
            </button>
            <button
              onClick={onReturnTitle}
              className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-xs font-bold text-amber-200 border border-slate-700 transition-transform"
            >
              {language === 'hinglish' ? '🏠 Main Menu' : '🏠 Main Menu'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
