import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Star, ArrowRight, RotateCcw, Home } from 'lucide-react';
import { LevelConfig } from '../types/game';
import { soundSystem } from '../game/soundSystem';

interface VictoryModalProps {
  level: LevelConfig;
  score: number;
  coinsEarned: number;
  onNextLevel: () => void;
  onReplay: () => void;
  onHome: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  level,
  score,
  coinsEarned,
  onNextLevel,
  onReplay,
  onHome
}) => {
  useEffect(() => {
    soundSystem.playVictory();

    // Trigger celebratory confetti burst
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {
      // Ignore if canvas blocked
    }
  }, []);

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-4 bg-slate-950/85">
      <div className="bg-slate-900 border-2 border-emerald-500/70 rounded-3xl p-5 md:p-6 max-w-md w-full shadow-2xl flex flex-col items-center text-center animate-in zoom-in-95 duration-200">
        {/* Victory Trophy Badge */}
        <div className="w-16 h-16 rounded-full bg-emerald-500 border-4 border-yellow-300 flex items-center justify-center text-3xl shadow-lg -mt-12 mb-2">
          🏆
        </div>

        <h2 className="text-2xl md:text-3xl font-black text-emerald-400 mb-1">
          تم إكمال المرحلة بنجاح!
        </h2>
        <div className="text-sm font-bold text-slate-300 mb-3">{level.title}</div>

        {/* 3 Stars */}
        <div className="flex items-center gap-2 mb-4">
          <Star className="w-9 h-9 fill-amber-400 text-yellow-300 drop-shadow" />
          <Star className="w-11 h-11 fill-amber-400 text-yellow-300 drop-shadow -mt-2" />
          <Star className="w-9 h-9 fill-amber-400 text-yellow-300 drop-shadow" />
        </div>

        {/* Level Stats */}
        <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-3.5 w-full mb-4 space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-slate-400 font-bold">النقاط المحققة:</span>
            <span className="text-cyan-400 font-extrabold tabular-nums">{score.toLocaleString('ar-EG')}</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-slate-400 font-bold">العملات المكتسبة:</span>
            <span className="text-amber-400 font-extrabold tabular-nums">+{coinsEarned.toLocaleString('ar-EG')} 🪙</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-slate-400 font-bold">مكافأة الفوز:</span>
            <span className="text-emerald-400 font-extrabold">+5 💎 جواهر</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2.5 w-full">
          <button
            onClick={onNextLevel}
            className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-lg shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>المرحلة التالية</span>
            <ArrowRight className="w-5 h-5 stroke-[2.5]" />
          </button>

          <div className="grid grid-cols-2 gap-2 w-full">
            <button
              onClick={onReplay}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold text-sm active:scale-95 transition-all flex items-center justify-center gap-1.5"
            >
              <RotateCcw className="w-4 h-4 text-amber-400" />
              <span>إعادة المرحلة</span>
            </button>

            <button
              onClick={onHome}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold text-sm active:scale-95 transition-all flex items-center justify-center gap-1.5"
            >
              <Home className="w-4 h-4 text-slate-300" />
              <span>القائمة</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
