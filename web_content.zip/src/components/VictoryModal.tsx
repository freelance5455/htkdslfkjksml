import React from 'react';
import { GameMode, LevelConfig } from '../types/game';
import { Star, RotateCcw, ArrowRight, Home, Coins, Flame } from 'lucide-react';
import { soundEngine } from '../utils/audio';

interface VictoryModalProps {
  level: LevelConfig;
  mode: GameMode;
  starsEarned: number;
  score: number;
  movesTaken: number;
  movesRemaining: number;
  coinsEarned: number;
  highestCombo: number;
  onNextLevel: () => void;
  onRetry: () => void;
  onHome: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  level,
  mode,
  starsEarned,
  score,
  movesTaken,
  movesRemaining,
  coinsEarned,
  highestCombo,
  onNextLevel,
  onRetry,
  onHome
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md select-none animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm sm:max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col items-center text-center">
        {/* Glow Accent */}
        <div className="absolute -top-12 w-32 h-32 bg-cyan-500/20 rounded-full blur-2xl pointer-events-none" />

        {/* Victory Header */}
        <div className="text-xs font-bold tracking-widest uppercase text-cyan-400 mb-1">
          {mode === 'classic' ? 'Level Cleared!' : 'Stage Completed!'}
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-4">
          SPECTACULAR!
        </h2>

        {/* Animated Star Rating */}
        <div className="flex items-center justify-center gap-2 mb-6">
          {[1, 2, 3].map((starNum) => {
            const isEarned = starNum <= starsEarned;
            return (
              <div
                key={starNum}
                className={`transition-all duration-500 transform ${
                  isEarned
                    ? 'scale-110 drop-shadow-[0_0_12px_rgba(250,204,21,0.8)]'
                    : 'scale-90 opacity-25'
                }`}
                style={{ transitionDelay: `${starNum * 120}ms` }}
              >
                <Star
                  className={`w-10 h-10 sm:w-12 sm:h-12 ${
                    isEarned
                      ? 'fill-amber-400 text-yellow-300'
                      : 'fill-slate-700 text-slate-600'
                  }`}
                />
              </div>
            );
          })}
        </div>

        {/* Score & Rewards Cards */}
        <div className="w-full grid grid-cols-2 gap-3 mb-6">
          {/* Score */}
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-2xl p-3 flex flex-col items-center">
            <span className="text-[11px] text-slate-400 font-semibold uppercase">Total Score</span>
            <span className="text-lg sm:text-xl font-mono tabular-nums font-black text-white">
              {score.toLocaleString()}
            </span>
          </div>

          {/* Coins Earned */}
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-2xl p-3 flex flex-col items-center">
            <span className="text-[11px] text-slate-400 font-semibold uppercase">Coins Won</span>
            <div className="flex items-center gap-1.5 text-lg sm:text-xl font-mono tabular-nums font-black text-amber-400">
              <Coins className="w-5 h-5 text-amber-400" />
              <span>+{coinsEarned}</span>
            </div>
          </div>
        </div>

        {/* Detailed Stats Row */}
        <div className="w-full flex items-center justify-around py-2.5 px-4 bg-slate-950/50 rounded-xl border border-slate-800/50 mb-6 text-xs text-slate-300">
          <div>
            Moves: <span className="font-mono font-bold text-white">{movesTaken}</span> / {level.maxMoves}
          </div>
          <div className="w-px h-3 bg-slate-800" />
          <div className="flex items-center gap-1">
            <Flame className="w-3.5 h-3.5 text-orange-400" />
            Max Combo: <span className="font-mono font-bold text-white">{highestCombo}x</span>
          </div>
        </div>

        {/* Actions */}
        <div className="w-full flex items-center gap-3">
          <button
            onClick={() => {
              soundEngine.playNodeSelect(0);
              onHome();
            }}
            title="Main Menu"
            className="w-12 h-12 flex items-center justify-center rounded-2xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors"
          >
            <Home className="w-5 h-5" />
          </button>

          <button
            onClick={() => {
              soundEngine.playNodeSelect(1);
              onRetry();
            }}
            title="Replay Level"
            className="w-12 h-12 flex items-center justify-center rounded-2xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors"
          >
            <RotateCcw className="w-5 h-5" />
          </button>

          <button
            onClick={() => {
              soundEngine.playNodeSelect(2);
              onNextLevel();
            }}
            className="flex-1 h-12 flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-sm tracking-wide shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all hover:scale-102 active:scale-98"
          >
            <span>NEXT STAGE</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
