/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Trophy, RotateCcw, Home, Skull, Flame, Sparkles } from 'lucide-react';

interface VictoryModalProps {
  score: number;
  kills: number;
  onRestart: () => void;
  onQuitToTitle: () => void;
  onPlayEndless: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  score,
  kills,
  onRestart,
  onQuitToTitle,
  onPlayEndless,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4 select-none">
      <div className="bg-[#0b0f17] border-2 border-emerald-500/60 rounded-3xl max-w-md w-full p-6 sm:p-8 text-slate-100 shadow-[0_0_50px_rgba(16,185,129,0.3)] text-center relative overflow-hidden">
        {/* Glow ambient background */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Trophy icon */}
        <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-tr from-emerald-950 to-emerald-800 border-2 border-emerald-400 flex items-center justify-center shadow-lg shadow-emerald-900/50">
          <Trophy className="w-10 h-10 text-emerald-300 animate-bounce" />
        </div>

        <div className="text-xs font-mono text-emerald-400 font-bold uppercase tracking-widest mb-1">
          EVACUATION SUCCESSFUL
        </div>
        <h2 className="text-3xl font-black tracking-tight text-white uppercase drop-shadow">
          MISSION ACCOMPLISHED!
        </h2>

        {/* Creator Badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 mt-2 mb-6 rounded-full bg-slate-900 border border-amber-500/40 text-xs font-bold text-amber-300">
          <Sparkles className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
          <span>MADE BY REHANX</span>
        </div>

        <p className="text-xs sm:text-sm text-slate-300 mb-6 max-w-sm mx-auto font-sans">
          You secured the quarantined biochemical research vial and survived the infected horde to reach the extraction chopper!
        </p>

        {/* Mission Stats Breakdown */}
        <div className="grid grid-cols-2 gap-3 mb-6 font-mono text-left">
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3">
            <div className="text-[10px] text-slate-400 uppercase tracking-widest flex items-center gap-1">
              <Skull className="w-3 h-3 text-red-400" />
              <span>INFECTED KILLED</span>
            </div>
            <div className="text-2xl font-black text-white tabular-nums mt-0.5">{kills}</div>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3">
            <div className="text-[10px] text-slate-400 uppercase tracking-widest flex items-center gap-1">
              <Trophy className="w-3 h-3 text-yellow-400" />
              <span>SURVIVAL SCORE</span>
            </div>
            <div className="text-2xl font-black text-emerald-400 tabular-nums mt-0.5">{score}</div>
          </div>
        </div>

        {/* CTAs */}
        <div className="space-y-2.5">
          <button
            onClick={onPlayEndless}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white font-bold tracking-wider uppercase transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-amber-900/40"
          >
            <Flame className="w-4 h-4 text-yellow-200 fill-yellow-200" />
            <span>PLAY ENDLESS HORDE SURVIVAL</span>
          </button>

          <button
            onClick={onRestart}
            className="w-full py-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 font-semibold tracking-wide transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4 text-emerald-400" />
            <span>REPLAY CAMPAIGN</span>
          </button>

          <button
            onClick={onQuitToTitle}
            className="w-full py-3 rounded-xl bg-slate-950 hover:bg-slate-900 border border-slate-800 text-slate-400 hover:text-white font-semibold tracking-wide transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <Home className="w-4 h-4" />
            <span>MAIN MENU</span>
          </button>
        </div>
      </div>
    </div>
  );
};
