import React from 'react';
import {
  Building2,
  Calendar,
  Search,
  Mic,
  ChevronRight,
  FileSpreadsheet,
  Receipt,
  ShoppingCart,
  TrendingUp,
  Scale,
  ArrowRightLeft,
  BookOpen,
  PieChart,
  Package,
  Layers,
  Sparkles,
  Download,
  RotateCcw,
} from 'lucide-react';
import { Company, Ledger, StockItem, Voucher, VoucherType, ActiveScreen } from '../types/tally';
import { formatCurrency, computeProfitAndLoss, computeBalanceSheet } from '../utils/tallyEngine';
import { triggerHaptic, soundManager } from '../utils/haptics';

interface GatewayOfTallyProps {
  company: Company;
  ledgers: Ledger[];
  stockItems: StockItem[];
  vouchers: Voucher[];
  onOpenScreen: (screen: ActiveScreen) => void;
  onOpenNewVoucher: (type?: VoucherType) => void;
  onOpenCompanyModal: () => void;
  onOpenGoToModal: () => void;
  onOpenVoiceModal: () => void;
  onExportData: () => void;
  onResetData: () => void;
}

export const GatewayOfTally: React.FC<GatewayOfTallyProps> = ({
  company,
  ledgers,
  stockItems,
  vouchers,
  onOpenScreen,
  onOpenNewVoucher,
  onOpenCompanyModal,
  onOpenGoToModal,
  onOpenVoiceModal,
  onExportData,
  onResetData,
}) => {
  // Financial metrics
  const pnl = computeProfitAndLoss(ledgers, stockItems);
  const bs = computeBalanceSheet(ledgers, stockItems);

  const cashBankTotal = bs.currentAssets.bankAccounts + bs.currentAssets.cashInHand;
  const receivablesTotal = bs.currentAssets.sundryDebtors;
  const payablesTotal = bs.currentLiabilities.sundryCreditors;
  const netProfit = pnl.netProfit;

  const handleAction = (cb: () => void) => {
    triggerHaptic('light');
    soundManager.playKeyClick();
    cb();
  };

  return (
    <div className="flex-1 flex flex-col pb-6 text-slate-800 dark:text-slate-100">
      {/* 1. Gateway Header Bar */}
      <div className="bg-emerald-900 text-white px-4 pt-3 pb-3 shadow-md">
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold tracking-wider uppercase text-emerald-300">
              Gateway of Tally
            </span>
            <span className="text-emerald-400">·</span>
            <span className="text-[11px] text-emerald-200">Release 4.1 Mobile</span>
          </div>
          <button
            onClick={() => handleAction(onOpenCompanyModal)}
            className="flex items-center gap-1 text-[11px] bg-emerald-800/80 hover:bg-emerald-700/80 text-emerald-100 px-2 py-0.5 rounded border border-emerald-700 transition-colors"
          >
            <Building2 className="w-3 h-3" />
            <span>F3: Company</span>
          </button>
        </div>

        {/* Company Title & GSTIN */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-base font-bold tracking-tight text-white line-clamp-1">
              {company.name}
            </h1>
            <p className="text-[11px] text-emerald-200 flex items-center gap-1.5 mt-0.5">
              <span>GSTIN: {company.gstin}</span>
              <span>·</span>
              <span>{company.city}, {company.state}</span>
            </p>
          </div>
        </div>

        {/* Period bar */}
        <div className="mt-2.5 pt-2 border-t border-emerald-800/60 flex items-center justify-between text-[11px] text-emerald-100">
          <div className="flex items-center gap-1">
            <Calendar className="w-3 h-3 text-emerald-300" />
            <span>FY: 01-Apr-26 to 31-Mar-27</span>
          </div>
          <div className="font-mono text-[11px] text-emerald-300">
            Total Vouchers: {vouchers.length}
          </div>
        </div>
      </div>

      {/* 2. Quick Go To Search & Voice Bar */}
      <div className="px-3 py-2 bg-emerald-800/20 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center gap-2">
        <button
          onClick={() => handleAction(onOpenGoToModal)}
          className="flex-1 flex items-center justify-between px-3 py-2 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 text-xs text-slate-500 dark:text-slate-400 shadow-sm hover:border-emerald-500 transition-all text-left"
        >
          <div className="flex items-center gap-2">
            <Search className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span>Go To (Alt+G): Search vouchers, ledgers, reports...</span>
          </div>
          <span className="text-[10px] bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded text-slate-500 font-mono">
            Alt+G
          </span>
        </button>

        <button
          onClick={() => handleAction(onOpenVoiceModal)}
          className="p-2 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white rounded-xl shadow-sm transition-all"
          title="Quick Voice Voucher Entry"
          aria-label="Voice Voucher"
        >
          <Mic className="w-4 h-4" />
        </button>
      </div>

      {/* 3. Tally Function Keys Quick Strip (F4 to F9) */}
      <div className="px-3 pt-3 pb-1">
        <div className="flex items-center justify-between text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1.5">
          <span>Speed Keys (Touch or Keypad)</span>
          <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-mono">Double-Entry</span>
        </div>
        <div className="grid grid-cols-6 gap-1.5 text-center">
          <button
            onClick={() => handleAction(() => onOpenNewVoucher('contra'))}
            className="p-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-amber-500 text-slate-700 dark:text-slate-200 shadow-xs touch-press"
          >
            <div className="text-[10px] font-mono font-bold text-amber-600 dark:text-amber-400">F4</div>
            <div className="text-[10px] truncate">Contra</div>
          </button>
          <button
            onClick={() => handleAction(() => onOpenNewVoucher('payment'))}
            className="p-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-rose-500 text-slate-700 dark:text-slate-200 shadow-xs touch-press"
          >
            <div className="text-[10px] font-mono font-bold text-rose-600 dark:text-rose-400">F5</div>
            <div className="text-[10px] truncate">Payment</div>
          </button>
          <button
            onClick={() => handleAction(() => onOpenNewVoucher('receipt'))}
            className="p-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-emerald-500 text-slate-700 dark:text-slate-200 shadow-xs touch-press"
          >
            <div className="text-[10px] font-mono font-bold text-emerald-600 dark:text-emerald-400">F6</div>
            <div className="text-[10px] truncate">Receipt</div>
          </button>
          <button
            onClick={() => handleAction(() => onOpenNewVoucher('journal'))}
            className="p-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-purple-500 text-slate-700 dark:text-slate-200 shadow-xs touch-press"
          >
            <div className="text-[10px] font-mono font-bold text-purple-600 dark:text-purple-400">F7</div>
            <div className="text-[10px] truncate">Journal</div>
          </button>
          <button
            onClick={() => handleAction(() => onOpenNewVoucher('sales'))}
            className="p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 shadow-xs touch-press"
          >
            <div className="text-[10px] font-mono font-bold text-emerald-700 dark:text-emerald-400">F8</div>
            <div className="text-[10px] font-semibold truncate">Sales</div>
          </button>
          <button
            onClick={() => handleAction(() => onOpenNewVoucher('purchase'))}
            className="p-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/40 border border-blue-300 dark:border-blue-800 text-blue-800 dark:text-blue-200 shadow-xs touch-press"
          >
            <div className="text-[10px] font-mono font-bold text-blue-700 dark:text-blue-400">F9</div>
            <div className="text-[10px] font-semibold truncate">Purch</div>
          </button>
        </div>
      </div>

      {/* 4. Real-Time Financial Metric Cards */}
      <div className="px-3 pt-2 pb-1">
        <div className="grid grid-cols-2 gap-2">
          {/* Cash + Bank */}
          <div
            onClick={() => handleAction(() => onOpenScreen('ledgers'))}
            className="p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs cursor-pointer hover:border-emerald-500 transition-colors"
          >
            <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
              <span>Cash & Bank</span>
              <span className="text-[10px] text-emerald-600 font-mono">Liquid</span>
            </div>
            <div className="text-base font-bold tracking-tight text-slate-900 dark:text-white tabular-nums mt-0.5">
              {formatCurrency(cashBankTotal)}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">HDFC, SBI & Cash</div>
          </div>

          {/* Net Profit */}
          <div
            onClick={() => handleAction(() => onOpenScreen('profitloss'))}
            className="p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs cursor-pointer hover:border-emerald-500 transition-colors"
          >
            <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
              <span>Net Profit (P&L)</span>
              <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
            </div>
            <div className="text-base font-bold tracking-tight text-emerald-600 dark:text-emerald-400 tabular-nums mt-0.5">
              {formatCurrency(netProfit)}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">Current Period</div>
          </div>

          {/* Receivables (Debtors) */}
          <div
            onClick={() => handleAction(() => onOpenScreen('ledgers'))}
            className="p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs cursor-pointer hover:border-blue-500 transition-colors"
          >
            <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
              <span>Receivables</span>
              <span className="text-[10px] text-blue-600 font-mono">Debtors</span>
            </div>
            <div className="text-base font-bold tracking-tight text-blue-600 dark:text-blue-400 tabular-nums mt-0.5">
              {formatCurrency(receivablesTotal)}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">From Customers</div>
          </div>

          {/* Payables (Creditors) */}
          <div
            onClick={() => handleAction(() => onOpenScreen('ledgers'))}
            className="p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs cursor-pointer hover:border-rose-500 transition-colors"
          >
            <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
              <span>Payables</span>
              <span className="text-[10px] text-rose-600 font-mono">Creditors</span>
            </div>
            <div className="text-base font-bold tracking-tight text-rose-600 dark:text-rose-400 tabular-nums mt-0.5">
              {formatCurrency(payablesTotal)}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">To Suppliers</div>
          </div>
        </div>
      </div>

      {/* 5. Authentic Gateway of Tally Menu */}
      <div className="px-3 pt-3 space-y-3">
        {/* SECTION: MASTERS */}
        <div className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-xs">
          <div className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 text-[11px] font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider flex items-center justify-between">
            <span>Masters</span>
            <span className="text-[10px] font-normal text-slate-400 lowercase">accounts & inventory</span>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-700/60">
            <button
              onClick={() => handleAction(() => onOpenScreen('ledgers'))}
              className="w-full px-3 py-2.5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors text-left"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center">
                  <Layers className="w-3.5 h-3.5" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    <span className="underline decoration-emerald-500 font-bold">L</span>edgers & Parties
                  </div>
                  <div className="text-[10px] text-slate-400">
                    {ledgers.length} Accounts (Debtors, Creditors, Bank, GST)
                  </div>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </button>

            <button
              onClick={() => handleAction(() => onOpenScreen('stocksummary'))}
              className="w-full px-3 py-2.5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors text-left"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 flex items-center justify-center">
                  <Package className="w-3.5 h-3.5" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    <span className="underline decoration-emerald-500 font-bold">S</span>tock Items (Inventory)
                  </div>
                  <div className="text-[10px] text-slate-400">
                    {stockItems.length} Products · Valuation {formatCurrency(bs.currentAssets.closingStock)}
                  </div>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </button>
          </div>
        </div>

        {/* SECTION: TRANSACTIONS (VOUCHERS) */}
        <div className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-xs">
          <div className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 text-[11px] font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider flex items-center justify-between">
            <span>Transactions</span>
            <span className="text-[10px] font-normal text-slate-400">Accounting Vouchers</span>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-700/60">
            {/* Sales */}
            <button
              onClick={() => handleAction(() => onOpenNewVoucher('sales'))}
              className="w-full px-3 py-2.5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors text-left"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-bold text-xs">
                  F8
                </div>
                <div>
                  <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    Sales Invoice (GST)
                  </div>
                  <div className="text-[10px] text-slate-400">Tax Invoice, B2B & B2C billings</div>
                </div>
              </div>
              <span className="text-[10px] font-mono text-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded">
                + New
              </span>
            </button>

            {/* Purchase */}
            <button
              onClick={() => handleAction(() => onOpenNewVoucher('purchase'))}
              className="w-full px-3 py-2.5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors text-left"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 flex items-center justify-center font-bold text-xs">
                  F9
                </div>
                <div>
                  <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    Purchase Bill
                  </div>
                  <div className="text-[10px] text-slate-400">Vendor inward bills & ITC claim</div>
                </div>
              </div>
              <span className="text-[10px] font-mono text-blue-600 bg-blue-50 dark:bg-blue-950/60 px-2 py-0.5 rounded">
                + New
              </span>
            </button>

            {/* Payment & Receipt */}
            <div className="grid grid-cols-2 divide-x divide-slate-100 dark:divide-slate-700/60">
              <button
                onClick={() => handleAction(() => onOpenNewVoucher('payment'))}
                className="px-3 py-2 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors text-left"
              >
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-bold font-mono text-rose-600 bg-rose-50 dark:bg-rose-950/40 px-1 rounded">
                    F5
                  </span>
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">Payment</span>
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">Bank / Cash paid</div>
              </button>

              <button
                onClick={() => handleAction(() => onOpenNewVoucher('receipt'))}
                className="px-3 py-2 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors text-left"
              >
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-bold font-mono text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 px-1 rounded">
                    F6
                  </span>
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">Receipt</span>
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">Customer payments</div>
              </button>
            </div>

            {/* Contra & Journal */}
            <div className="grid grid-cols-2 divide-x divide-slate-100 dark:divide-slate-700/60">
              <button
                onClick={() => handleAction(() => onOpenNewVoucher('contra'))}
                className="px-3 py-2 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors text-left"
              >
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-bold font-mono text-amber-600 bg-amber-50 dark:bg-amber-950/40 px-1 rounded">
                    F4
                  </span>
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">Contra</span>
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">Cash / Bank transfer</div>
              </button>

              <button
                onClick={() => handleAction(() => onOpenNewVoucher('journal'))}
                className="px-3 py-2 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors text-left"
              >
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-bold font-mono text-purple-600 bg-purple-50 dark:bg-purple-950/40 px-1 rounded">
                    F7
                  </span>
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">Journal</span>
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">Adjustments & Depr</div>
              </button>
            </div>
          </div>
        </div>

        {/* SECTION: FINANCIAL REPORTS */}
        <div className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-xs">
          <div className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 text-[11px] font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider flex items-center justify-between">
            <span>Financial Reports</span>
            <span className="text-[10px] font-normal text-emerald-600 dark:text-emerald-400">Real-Time</span>
          </div>

          <div className="grid grid-cols-2 divide-x divide-y divide-slate-100 dark:divide-slate-700/60">
            {/* Balance Sheet */}
            <button
              onClick={() => handleAction(() => onOpenScreen('balancesheet'))}
              className="p-3 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors text-left"
            >
              <div className="flex items-center gap-1.5">
                <Scale className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                  <span className="underline decoration-emerald-500 font-bold">B</span>alance Sheet
                </span>
              </div>
              <div className="text-[11px] font-bold tabular-nums text-slate-700 dark:text-slate-300 mt-1">
                {formatCurrency(bs.totalLiabilities)}
              </div>
              <div className="text-[10px] text-emerald-600">Balanced</div>
            </button>

            {/* Profit & Loss */}
            <button
              onClick={() => handleAction(() => onOpenScreen('profitloss'))}
              className="p-3 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors text-left"
            >
              <div className="flex items-center gap-1.5">
                <PieChart className="w-3.5 h-3.5 text-blue-600" />
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                  <span className="underline decoration-emerald-500 font-bold">P</span>rofit & Loss
                </span>
              </div>
              <div className="text-[11px] font-bold tabular-nums text-emerald-600 mt-1">
                {formatCurrency(pnl.netProfit)}
              </div>
              <div className="text-[10px] text-slate-400">Gross: {formatCurrency(pnl.grossProfit)}</div>
            </button>

            {/* Day Book */}
            <button
              onClick={() => handleAction(() => onOpenScreen('daybook'))}
              className="p-3 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors text-left"
            >
              <div className="flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-amber-600" />
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                  <span className="underline decoration-emerald-500 font-bold">D</span>ay Book
                </span>
              </div>
              <div className="text-[11px] font-bold tabular-nums text-slate-700 dark:text-slate-300 mt-1">
                {vouchers.length} Vouchers
              </div>
              <div className="text-[10px] text-slate-400">Daily Journal feed</div>
            </button>

            {/* Trial Balance */}
            <button
              onClick={() => handleAction(() => onOpenScreen('trialbalance'))}
              className="p-3 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors text-left"
            >
              <div className="flex items-center gap-1.5">
                <FileSpreadsheet className="w-3.5 h-3.5 text-purple-600" />
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                  <span className="underline decoration-emerald-500 font-bold">T</span>rial Balance
                </span>
              </div>
              <div className="text-[11px] font-bold tabular-nums text-slate-700 dark:text-slate-300 mt-1">
                Matched (Dr=Cr)
              </div>
              <div className="text-[10px] text-purple-600">Double-entry audit</div>
            </button>

            {/* Stock Summary */}
            <button
              onClick={() => handleAction(() => onOpenScreen('stocksummary'))}
              className="p-3 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors text-left"
            >
              <div className="flex items-center gap-1.5">
                <Package className="w-3.5 h-3.5 text-teal-600" />
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                  Stock Summary
                </span>
              </div>
              <div className="text-[11px] font-bold tabular-nums text-slate-700 dark:text-slate-300 mt-1">
                {formatCurrency(bs.currentAssets.closingStock)}
              </div>
              <div className="text-[10px] text-slate-400">Inventory Items</div>
            </button>

            {/* GST Reports (GSTR-1 & 3B) */}
            <button
              onClick={() => handleAction(() => onOpenScreen('gst_reports'))}
              className="p-3 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors text-left"
            >
              <div className="flex items-center gap-1.5">
                <Receipt className="w-3.5 h-3.5 text-indigo-600" />
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                  <span className="underline decoration-emerald-500 font-bold">G</span>ST Summary
                </span>
              </div>
              <div className="text-[11px] font-bold tabular-nums text-indigo-600 mt-1">
                GSTR-1 & 3B
              </div>
              <div className="text-[10px] text-slate-400">Tax liability & ITC</div>
            </button>
          </div>
        </div>

        {/* SECTION: UTILITIES & DATA */}
        <div className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 p-2.5 shadow-xs">
          <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 mb-2 uppercase tracking-wider">
            Utilities & Data
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => handleAction(onExportData)}
              className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-slate-100 dark:bg-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-200 transition-colors touch-press"
            >
              <Download className="w-3.5 h-3.5 text-emerald-600" />
              <span>Backup Data</span>
            </button>
            <button
              onClick={() => handleAction(onResetData)}
              className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-slate-100 dark:bg-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-200 transition-colors touch-press"
            >
              <RotateCcw className="w-3.5 h-3.5 text-rose-500" />
              <span>Reset Demo</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
