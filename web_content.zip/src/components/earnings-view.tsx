import { StatusPill } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { fmtMoney, type CommissionRow } from "@/lib/rooms-model";

export function EarningsView({
  rows,
  signedIn,
  loading,
}: {
  rows: CommissionRow[];
  signedIn: boolean;
  loading: boolean;
}) {
  const pending = rows.filter((c) => c.status !== "paid").reduce((s, c) => s + c.amount, 0);
  const paid = rows.filter((c) => c.status === "paid").reduce((s, c) => s + c.amount, 0);
  const currencies = new Set(rows.map((c) => c.currency).filter(Boolean));
  const currency = currencies.size === 1 ? [...currencies][0] : "";

  return (
    <div>
      {!signedIn ? (
        <p className="mb-4 rounded-sm bg-paper-alt px-3 py-2.5 text-[13px] text-ink-soft">
          Sign in to see your referral links and earnings.
        </p>
      ) : null}
      <div className="mb-5.5 grid grid-cols-2 gap-3.5">
        <div className="rounded-md border border-line bg-card p-4">
          <div className="font-serif text-[26px] font-semibold tabular-nums">
            {loading ? "—" : fmtMoney(pending, currency)}
          </div>
          <div className="mt-0.5 text-xs text-ink-soft">Pending commission</div>
        </div>
        <div className="rounded-md border border-line bg-card p-4">
          <div className="font-serif text-[26px] font-semibold tabular-nums">
            {loading ? "—" : fmtMoney(paid, currency)}
          </div>
          <div className="mt-0.5 text-xs text-ink-soft">Paid out</div>
        </div>
      </div>
      <section className="rounded-lg border border-line bg-card p-5.5">
        <h2 className="font-serif mb-4 text-[19px] font-semibold">Your commissions</h2>
        {loading ? <Skeleton className="h-24" /> : null}
        {!loading && signedIn && rows.length === 0 ? (
          <p className="py-8 text-center text-sm text-ink-soft">
            No referrals yet. Share a room's link from the Browse tab to start earning.
          </p>
        ) : null}
        {!loading && rows.length > 0 ? (
          <table className="w-full border-collapse text-[13.5px]">
            <thead>
              <tr>
                <th className="border-b border-line px-1.5 py-2 text-left text-xs font-medium text-ink-soft">Room</th>
                <th className="border-b border-line px-1.5 py-2 text-left text-xs font-medium text-ink-soft">Amount</th>
                <th className="border-b border-line px-1.5 py-2 text-left text-xs font-medium text-ink-soft">Status</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((c) => (
                <tr key={c.id}>
                  <td className="border-b border-line px-1.5 py-2.5">{c.roomTitle || c.roomId}</td>
                  <td className="border-b border-line px-1.5 py-2.5 tabular-nums">{fmtMoney(c.amount, c.currency)}</td>
                  <td className="border-b border-line px-1.5 py-2.5">
                    <StatusPill tone={c.status === "paid" ? "paid" : "pending"}>{c.status}</StatusPill>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : null}
      </section>
    </div>
  );
}
