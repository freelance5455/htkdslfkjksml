import React, { useEffect, useRef, useState } from 'react';
import { Alarm } from '../types/alarm';
import { getMediaPlaybackUrl } from '../utils/mediaStore';
import {
  requestWakeLock,
  releaseWakeLock,
  sendAlarmNotification,
} from '../utils/alarmEngine';
import { MusicVisualizer } from './MusicVisualizer';
import { Volume2, VolumeX, Bell, Clock, Square, Sparkles, Music, Video } from 'lucide-react';

interface RingingModalProps {
  alarm: Alarm | null;
  onStop: () => void;
  onSnooze: (minutes: number) => void;
}

export const RingingModal: React.FC<RingingModalProps> = ({ alarm, onStop, onSnooze }) => {
  if (!alarm) return null;

  const [mediaUrl, setMediaUrl] = useState<string | null>(null);
  const [currentVolume, setCurrentVolume] = useState<number>(0);
  const [isMuted, setIsMuted] = useState(false);
  const [selectedSnoozeMins, setSelectedSnoozeMins] = useState<number>(alarm.snoozeDuration || 5);
  const [timeRingingStr, setTimeRingingStr] = useState<string>('00:00');

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const volumeIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const ringingTimerRef = useRef<NodeJS.Timeout | null>(null);

  const isVideo = alarm.mediaType === 'video';

  // Fetch resolved URL for media
  useEffect(() => {
    let active = true;
    getMediaPlaybackUrl(alarm.mediaUri).then((res) => {
      if (active) setMediaUrl(res.url);
    });

    // Request Screen Wake Lock & Notification (NO VIBRATION)
    requestWakeLock();
    sendAlarmNotification(
      `WAKE UP! ${alarm.alarmLabel}`,
      `Playing ${alarm.mediaName}. Tap to dismiss or snooze.`
    );

    // Track elapsed ringing time
    const startTime = Date.now();
    ringingTimerRef.current = setInterval(() => {
      const elapsedSec = Math.floor((Date.now() - startTime) / 1000);
      const mins = Math.floor(elapsedSec / 60);
      const secs = elapsedSec % 60;
      setTimeRingingStr(
        `${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`
      );
    }, 1000);

    return () => {
      active = false;
      releaseWakeLock();
      if (ringingTimerRef.current) clearInterval(ringingTimerRef.current);
    };
  }, [alarm]);

  // Gradual Volume Ramping logic
  useEffect(() => {
    const targetVol = alarm.volume / 100;

    if (alarm.gradualVolumeEnabled) {
      setCurrentVolume(0.05); // Start low at 5%
      const step = (targetVol - 0.05) / 30; // Ramp over 30 seconds

      volumeIntervalRef.current = setInterval(() => {
        setCurrentVolume((prev) => {
          if (prev >= targetVol) {
            if (volumeIntervalRef.current) clearInterval(volumeIntervalRef.current);
            return targetVol;
          }
          return Math.min(targetVol, prev + step);
        });
      }, 1000);
    } else {
      setCurrentVolume(targetVol);
    }

    return () => {
      if (volumeIntervalRef.current) clearInterval(volumeIntervalRef.current);
    };
  }, [alarm]);

  // Sync volume with media element
  useEffect(() => {
    const mediaElem = isVideo ? videoRef.current : audioRef.current;
    if (mediaElem) {
      mediaElem.volume = isMuted ? 0 : currentVolume;
    }
  }, [currentVolume, isMuted, isVideo, mediaUrl]);

  const handleStopAlarm = () => {
    releaseWakeLock();
    onStop();
  };

  const handleSnoozeAlarm = () => {
    releaseWakeLock();
    onSnooze(selectedSnoozeMins);
  };

  return (
    <div className="fixed inset-0 z-100 bg-slate-950 flex flex-col justify-between overflow-hidden text-white font-sans select-none animate-in fade-in duration-300">
      {/* Hidden Audio/Video Media Element - Plays Sound ONLY without showing video */}
      {mediaUrl && (
        <div className="hidden">
          {isVideo ? (
            <video
              ref={videoRef}
              src={mediaUrl}
              autoPlay
              loop
              playsInline
              aria-hidden="true"
            />
          ) : (
            <audio
              ref={audioRef}
              src={mediaUrl}
              autoPlay
              loop
              aria-hidden="true"
            />
          )}
        </div>
      )}

      {/* Decorative Glowing Backdrop */}
      <div className="absolute inset-0 z-0 bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/40 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl animate-pulse" />
      </div>

      {/* Top Status Header */}
      <div className="relative z-10 p-5 sm:p-6 flex items-center justify-between bg-slate-900/80 backdrop-blur-md border-b border-white/10">
        <div className="flex items-center gap-3">
          <img
            src="/assets/aistudio/file_00000000ef4c8211bafeca7fec614b22_95cdb1d5.png"
            alt="WakeUp Logo"
            className="w-10 h-10 rounded-xl shadow-md border border-white/20 object-cover shrink-0 animate-pulse"
          />
          <div>
            <div className="text-[10px] font-extrabold uppercase tracking-widest text-amber-400">
              ALARM RINGING · SOUND ONLY
            </div>
            <div className="text-sm font-bold text-white truncate max-w-[200px]">
              {alarm.alarmLabel || 'WakeUp Alarm'}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="px-3 py-1 rounded-full bg-white/10 border border-white/20 text-xs font-mono font-semibold text-slate-300">
            {timeRingingStr}
          </div>
          <button
            onClick={() => setIsMuted(!isMuted)}
            className="p-2.5 rounded-full bg-white/10 border border-white/20 hover:bg-white/20 transition-colors cursor-pointer"
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <VolumeX className="w-5 h-5 text-red-400" /> : <Volume2 className="w-5 h-5 text-white" />}
          </button>
        </div>
      </div>

      {/* Middle Center Alarm Ringing Display */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-6 text-center max-w-xl mx-auto w-full py-6">
        {/* App Logo & Media Info Badge */}
        <div className="mb-4 flex flex-col items-center">
          <div className="relative mb-3">
            <img
              src="/assets/aistudio/file_00000000ef4c8211bafeca7fec614b22_95cdb1d5.png"
              alt="WakeUp App Logo"
              className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl border-2 border-amber-400/50 shadow-2xl shadow-amber-500/20 object-cover"
            />
            <div className="absolute -bottom-2 -right-2 px-2.5 py-0.5 rounded-full bg-slate-900 border border-amber-400 text-[10px] font-bold text-amber-300 flex items-center gap-1 shadow-md">
              {isVideo ? <Video className="w-3 h-3" /> : <Music className="w-3 h-3" />}
              <span>{isVideo ? 'Video Sound' : 'Music'}</span>
            </div>
          </div>

          <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight text-white mt-2">
            {alarm.mediaName}
          </h2>
          <p className="text-xs font-semibold text-amber-400 uppercase tracking-widest mt-0.5">
            Playing Media Sound
          </p>
        </div>

        {/* Animated Music Frequency Visualizer */}
        <MusicVisualizer isPlaying={true} audioRef={audioRef} />

        {/* Large Alarm Clock Ringing Digits */}
        <div className="mt-2">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest block mb-1">
            Alarm Scheduled Time
          </span>
          <div className="text-5xl sm:text-6xl font-extrabold font-mono tracking-tight text-white">
            {alarm.hour < 10 ? `0${alarm.hour}` : alarm.hour}:
            {alarm.minute < 10 ? `0${alarm.minute}` : alarm.minute}
          </div>
        </div>
      </div>

      {/* Bottom Action Bar (Snooze & Stop) */}
      <div className="relative z-10 p-6 sm:p-8 bg-slate-900/90 backdrop-blur-xl border-t border-white/10 space-y-4 max-w-xl mx-auto w-full">
        {/* Snooze Duration Selector */}
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-amber-400" />
            <span>Snooze Duration</span>
          </span>
          <div className="flex items-center gap-1.5">
            {[5, 10, 15].map((mins) => (
              <button
                key={mins}
                onClick={() => setSelectedSnoozeMins(mins)}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  selectedSnoozeMins === mins
                    ? 'bg-amber-400 text-slate-950 font-extrabold shadow-md'
                    : 'bg-white/10 text-slate-300 hover:bg-white/20'
                }`}
              >
                {mins}m
              </button>
            ))}
          </div>
        </div>

        {/* Big Touch Buttons */}
        <div className="grid grid-cols-2 gap-4">
          {/* Snooze Button */}
          <button
            onClick={handleSnoozeAlarm}
            className="w-full py-4 px-6 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 active:scale-98 transition-transform cursor-pointer"
          >
            <Clock className="w-5 h-5 stroke-[2.5]" />
            <span>Snooze ({selectedSnoozeMins}m)</span>
          </button>

          {/* Stop Button */}
          <button
            onClick={handleStopAlarm}
            className="w-full py-4 px-6 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-red-600/30 active:scale-98 transition-transform cursor-pointer"
          >
            <Square className="w-5 h-5 fill-white" />
            <span>Stop Alarm</span>
          </button>
        </div>
      </div>
    </div>
  );
};
