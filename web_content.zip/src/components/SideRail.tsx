import {
  Compass,
  Droplet,
  Footprints,
  Landmark,
  Map,
  Moon,
  Sparkles,
  Swords,
  Trophy,
} from "lucide-react";
import type { HudSnapshot, ScoreEntry } from "@/game/types";
import { SHRINES, CAMP, OASIS } from "@/game/world";
import { ScoreTable } from "./HighScores";

function missionMap(hud: HudSnapshot) {
  const sx = (x: number) => 18 + (x / 2400) * 244;
  const sy = (y: number) => 14 + (y / 1700) * 112;
  const campX = sx(CAMP.x);
  const campY = sy(CAMP.y);
  return (
    <div className="relative overflow-hidden rounded-xl border border-ink/10 bg-[#e3d2b3]">
      <svg viewBox="0 0 280 140" className="block h-auto w-full" aria-label="خريطة مصغّرة للواحة">
        <defs>
          <linearGradient id="map-sand" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#e9dcc1" />
            <stop offset="100%" stopColor="#d6c2a0" />
          </linearGradient>
          <linearGradient id="map-water" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#5d9c8f" />
            <stop offset="100%" stopColor="#2e6c69" />
          </linearGradient>
        </defs>
        <rect width="280" height="140" fill="url(#map-sand)" />
        <path d="M-10 40C50 20 70 55 130 36S220 50 290 26" stroke="#f6eedb" strokeWidth="8" fill="none" opacity="0.55" />
        <path d="M-10 88C50 68 90 104 150 86S230 96 290 76" stroke="#bca884" strokeWidth="1.2" fill="none" opacity="0.5" strokeDasharray="2 4" />
        <path d="M-10 122C60 108 100 132 160 118S240 126 290 108" stroke="#f6eedb" strokeWidth="7" fill="none" opacity="0.4" />
        {/* trails */}
        {SHRINES.map((s) => (
          <path
            key={s.name}
            d={`M${campX} ${campY} Q${(campX + sx(s.x)) / 2 - 10} ${(campY + sy(s.y)) / 2}, ${sx(s.x)} ${sy(s.y)}`}
            fill="none"
            stroke="#9c865f"
            strokeWidth="0.9"
            strokeDasharray="3 4"
            opacity="0.7"
          />
        ))}
        {/* oasis */}
        <ellipse cx={sx(OASIS.x)} cy={sy(OASIS.y)} rx="23" ry="13" fill="url(#map-water)" />
        <ellipse cx={sx(OASIS.x)} cy={sy(OASIS.y)} rx="23" ry="13" fill="none" stroke="#efe6cf" strokeWidth="1.4" opacity="0.8" />
        <ellipse cx="206" cy="111" rx="13" ry="7" fill="url(#map-water)" opacity="0.85" />
        {/* ruins dots */}
        {[
          [176, 44],
          [186, 57],
          [164, 56],
          [204, 78],
          [216, 66],
        ].map(([x, y], i) => (
          <rect key={i} x={x} y={y} width="4" height="5" rx="1" fill="#9d8a68" opacity="0.8" />
        ))}
        {/* arch */}
        <path d="M205 91v-8a5 5 0 0 1 10 0v8" stroke="#8f7b58" strokeWidth="2.2" fill="none" />
        {/* camp */}
        <circle cx={campX} cy={campY} r="9" fill="#e0b272" opacity="0.3" />
        <circle cx={campX} cy={campY} r="4" fill="#b76a44" stroke="#f6ead2" strokeWidth="1.2" />
        <path d={`M${campX} ${campY - 4}c3 3 3 6 0 8c-3-2-3-5 0-8Z`} fill="#f2ce85" />
        {/* shrines */}
        {SHRINES.map((s, i) => {
          const lit = hud.shrines[i];
          return (
            <g key={s.name}>
              {lit && <circle cx={sx(s.x)} cy={sy(s.y)} r="10" fill="#e3b974" opacity="0.26" />}
              <circle
                cx={sx(s.x)}
                cy={sy(s.y)}
                r="5.6"
                fill={lit ? "#f3d59a" : "#f7f0e1"}
                stroke={lit ? "#a9793d" : "#9b8b6c"}
                strokeWidth="1.2"
              />
              <text
                x={sx(s.x)}
                y={sy(s.y) + 2.3}
                textAnchor="middle"
                fontSize="6"
                fontWeight="700"
                fill="#4d4636"
              >
                {i + 1}
              </text>
            </g>
          );
        })}
        {/* compass */}
        <g transform="translate(255 20)">
          <circle r="8" fill="none" stroke="#8d7a58" strokeWidth="0.6" opacity="0.5" />
          <path d="M0 -5L1.8 1.5L0 0.6L-1.8 1.5Z" fill="#8d7a58" />
        </g>
        <text x="12" y="132" fontSize="5.5" fill="#7c6a4e" fontFamily="IBM Plex Sans Arabic" opacity="0.8">
          واحة سِراب · ٢٤٠٠ × ١٧٠٠ خطوة
        </text>
      </svg>
      <div className="absolute bottom-1.5 left-1.5 flex items-center gap-1 rounded-md bg-[#f8f1e2]/80 px-1 py-0.5 text-[7px] text-ink-muted backdrop-blur-sm">
        <Moon className="h-2 w-2 text-[#7e8ba3]" />
        دورة {hud.cycles}
      </div>
    </div>
  );
}

export function SideRail({
  hud,
  scores,
  entryId,
}: {
  hud: HudSnapshot;
  scores: ScoreEntry[];
  entryId: string | null;
}) {
  const lit = hud.shrines.filter(Boolean).length;

  return (
    <aside className="flex w-full flex-col gap-3 lg:w-[316px] lg:shrink-0">
      <section className="card relative overflow-hidden rounded-2xl p-4">
        <div className="pointer-events-none absolute -left-10 -top-12 h-32 w-32 rounded-full border border-ink/5" />
        <div className="pointer-events-none absolute -left-4 -top-6 h-20 w-20 rounded-full border border-ink/5" />
        <div className="relative flex items-start justify-between gap-2">
          <div>
            <p className="mb-1 flex items-center gap-1.5 text-[8px] font-semibold uppercase tracking-[0.22em] text-gold-deep">
              <Compass className="h-2.5 w-2.5" />
              مهمة الواحة
            </p>
            <h2 className="font-display text-[22px] leading-tight text-ink">أيقظ الأضرحة الثلاثة</h2>
          </div>
          <span className="nums flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-[#b98b4a]/35 bg-[#e3b974]/20 text-[13px] font-bold text-[#7c5825]">
            {lit}/3
          </span>
        </div>
        <p className="relative mt-1 text-[10px] leading-relaxed text-ink-muted">
          اقترب من المسلّة واضغط <kbd className="rounded border border-ink/20 bg-white/60 px-1 font-sans text-[9px]">E</kbd> لإشعالها.
          إشعال الثلاثة يفتح دورة جديدة، يشفي جراحك، ويمنحك مكافأة كبيرة.
        </p>

        <div className="relative mt-3 h-1.5 w-full overflow-hidden rounded-full bg-ink/10">
          <div
            className="h-full rounded-full bg-gradient-to-l from-[#7aa99a] via-[#e3b974] to-[#d3a55f] transition-[width] duration-500"
            style={{ width: `${(lit / 3) * 100}%` }}
          />
        </div>

        <ul className="relative mt-2.5 space-y-1">
          {SHRINES.map((s, i) => {
            const done = hud.shrines[i];
            return (
              <li
                key={s.name}
                className={`flex items-center gap-2 rounded-lg border px-2 py-1.5 transition-colors ${
                  done ? "border-[#b98b4a]/30 bg-[#e3b974]/15" : "border-transparent bg-ink/[0.025]"
                }`}
              >
                <span
                  className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md border ${
                    done
                      ? "border-[#b98b4a]/50 bg-[#e3b974] text-[#543913]"
                      : "border-ink/10 bg-white/45 text-ink-faint"
                  }`}
                >
                  {done ? <Sparkles className="h-2.5 w-2.5" /> : <Landmark className="h-2.5 w-2.5" />}
                </span>
                <span className={`flex-1 text-[10px] font-medium ${done ? "text-[#76501f]" : "text-ink-soft"}`}>
                  {s.name}
                </span>
                <span className={`text-[8px] ${done ? "text-[#8b6228]" : "text-ink-faint"}`}>
                  {done ? "مُضاف" : "خامد"}
                </span>
              </li>
            );
          })}
        </ul>

        <div className="relative mt-2.5 flex items-center justify-between rounded-lg border border-[#7a9e8c]/25 bg-[#7a9e8c]/10 px-2 py-1.5">
          <span className="text-[9px] text-ink-muted">مكافأة إتمام الدورة</span>
          <span className="nums text-[11px] font-bold text-[#4a735f]">+1000 نقطة</span>
        </div>

        <div className="relative mt-3">{missionMap(hud)}</div>
      </section>

      <section className="card rounded-2xl p-4">
        <div className="mb-2 flex items-center justify-between">
          <h2 className="flex items-center gap-1.5 text-[12px] font-semibold text-ink">
            <Trophy className="h-3.5 w-3.5 text-[#a4753d]" />
            لوحة الشرف
          </h2>
          <span className="flex items-center gap-1 text-[8px] text-ink-faint">
            <Map className="h-2.5 w-2.5" />
            محفوظة محليًا
          </span>
        </div>
        <ScoreTable scores={scores} highlightId={entryId} limit={5} />
        <p className="mt-2 border-t border-ink/8 pt-2 text-center text-[8px] text-ink-faint">
          أفضل ثمانية مسارات · تُحفظ على جهازك فقط
        </p>
      </section>

      <section className="card rounded-2xl p-4">
        <h2 className="mb-2 flex items-center gap-1.5 text-[12px] font-semibold text-ink">
          <Swords className="h-3.5 w-3.5 text-[#a4753d]" />
          دليل البقاء
        </h2>
        <div className="grid grid-cols-2 gap-1.5">
          {[
            { icon: <Sparkles className="h-3 w-3" />, label: "ذرة نور", value: "حتى +١٥٠" },
            { icon: <Swords className="h-3 w-3" />, label: "الظل المقهور", value: "+٥٥ إلى +١٩٠" },
            { icon: <Droplet className="h-3 w-3" />, label: "قربة ماء", value: "+٣٨ ماء" },
            { icon: <Landmark className="h-3 w-3" />, label: "ضريح مُوقَد", value: "+٢٥٠ وقلب" },
          ].map((tip) => (
            <div key={tip.label} className="rounded-lg border border-ink/8 bg-white/35 px-1.5 py-1.5">
              <span className="mb-0.5 flex h-4 w-4 items-center justify-center rounded bg-[#142e28]/8 text-[#8c6c40]">
                {tip.icon}
              </span>
              <p className="text-[8.5px] font-medium text-ink-soft">{tip.label}</p>
              <p className="nums text-[8px] text-[#9a7c4d]">{tip.value}</p>
            </div>
          ))}
        </div>
        <div className="mt-2 flex gap-1.5 rounded-lg border border-[#c66b46]/20 bg-[#c66b46]/8 px-2 py-1.5">
          <span className="mt-0.5 text-[#b15d3c]"><Swords className="h-3 w-3" /></span>
          <p className="text-[9px] leading-relaxed text-ink-muted">
            اضرب سلسلة سريعة لرفع المضاعف حتى ×٦. عند الغسق تتضاعف نقاط الظلال أيضًا.
          </p>
        </div>
        <div className="mt-2 flex items-center gap-3 text-[8px] text-ink-faint">
          <span className="flex items-center gap-1"><Footprints className="h-2.5 w-2.5" /> Shift اندفاع</span>
          <span className="flex items-center gap-1"><Moon className="h-2.5 w-2.5" /> الغسق يزيد الخطر والغنيمة</span>
        </div>
      </section>
    </aside>
  );
}
