import { useEffect, useRef, useState } from "react";
import { localBrain } from "../lib/assistant";
import { useReveal } from "../lib/hooks";
import { IconMic, IconSend, IconVolume, IconWifiOff, IconArrowRight, IconX, IconSpark } from "./Icons";

interface Msg {
  role: "user" | "ai";
  text: string;
  forgePrompt?: string;
}

interface Props {
  onForge: (prompt: string) => void;
  toast: (msg: string, kind?: "ok" | "warn") => void;
}

const QUICK = [
  "build me a space shooter called Starforge",
  "which model is fastest on low RAM?",
  "how does offline mode work?",
  "make a snake game that never ends",
];

type SpeechRecEvent = {
  resultIndex: number;
  results: ArrayLike<ArrayLike<{ transcript: string }> & { isFinal: boolean }>;
};
interface RecInstance {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onresult: ((e: SpeechRecEvent) => void) | null;
  onend: (() => void) | null;
  onerror: (() => void) | null;
}
interface SRCtor {
  new (): RecInstance;
}

export default function Voice({ onForge, toast }: Props) {
  const [msgs, setMsgs] = useState<Msg[]>([
    {
      role: "ai",
      text: "Yuno Nano online — 100% on-device. Talk to me or type. Say \"build me a ...\" and I will route it straight to the forge.",
    },
  ]);
  const [listening, setListening] = useState(false);
  const [interim, setInterim] = useState("");
  const [input, setInput] = useState("");
  const [voiceOut, setVoiceOut] = useState(true);
  const [unsupported, setUnsupported] = useState(false);
  const recRef = useRef<RecInstance | null>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const headRef = useReveal<HTMLDivElement>();
  const bodyRef = useReveal<HTMLDivElement>();

  useEffect(() => {
    const el = listRef.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [msgs, interim]);

  const speak = (text: string) => {
    if (!voiceOut || !("speechSynthesis" in window)) return;
    try {
      const u = new SpeechSynthesisUtterance(text.replace(/["']/g, ""));
      u.rate = 1.04;
      u.pitch = 0.95;
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(u);
    } catch {
      /* voice replies unavailable — silent is fine */
    }
  };

  const respond = (userText: string) => {
    setMsgs((m) => [...m, { role: "user", text: userText }]);
    setTimeout(() => {
      const reply = localBrain(userText);
      setMsgs((m) => [...m, { role: "ai", text: reply.text, forgePrompt: reply.forgePrompt }]);
      speak(reply.text);
    }, 420 + Math.random() * 500);
  };

  const toggleMic = () => {
    if (listening) {
      recRef.current?.stop();
      setListening(false);
      return;
    }
    const w = window as unknown as Record<string, unknown>;
    const Ctor = (w.SpeechRecognition || w.webkitSpeechRecognition) as SRCtor | undefined;
    if (!Ctor) {
      setUnsupported(true);
      toast("Speech recognition not supported here — type instead, everything else works", "warn");
      return;
    }
    const rec = new Ctor();
    rec.lang = "en-US";
    rec.continuous = false;
    rec.interimResults = true;
    rec.onresult = (e) => {
      let fin = "";
      let inter = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const r = e.results[i];
        if (r.isFinal) fin += r[0].transcript;
        else inter += r[0].transcript;
      }
      setInterim(inter);
      if (fin) {
        setInterim("");
        respond(fin.trim());
      }
    };
    rec.onend = () => {
      setListening(false);
      setInterim("");
    };
    rec.onerror = () => {
      setListening(false);
      setInterim("");
    };
    recRef.current = rec;
    rec.start();
    setListening(true);
  };

  return (
    <section id="voice" className="relative py-24 border-t border-line/60">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_55%_45%_at_80%_10%,rgba(47,230,200,0.06),transparent)] pointer-events-none" />
      <div className="mx-auto max-w-7xl px-5 relative">
        <div ref={headRef} className="reveal mb-10">
          <p className="font-mono text-[11px] tracking-[0.3em] text-ember mb-3">// 04 — TALK TO YUNO</p>
          <h2 className="font-display font-bold text-[clamp(1.6rem,3.4vw,2.5rem)] text-snow leading-tight">
            Speak. It hears you —<br />
            <span className="text-fog text-[0.62em] font-medium">no signal bars required.</span>
          </h2>
        </div>

        <div ref={bodyRef} className="reveal grid lg:grid-cols-[0.9fr_1.4fr] gap-4">
          {/* left explainer */}
          <div className="border border-line bg-panel clip-hud p-6 flex flex-col gap-5">
            <div className="flex items-center gap-3">
              <span className="w-11 h-11 border border-teal/50 bg-teal/8 text-teal clip-tag flex items-center justify-center">
                <IconMic size={20} />
              </span>
              <div>
                <p className="font-display font-bold text-snow text-[15px]">YUNO NANO</p>
                <p className="font-mono text-[9.5px] tracking-[0.18em] text-fog mt-1">ON-DEVICE ASSISTANT</p>
              </div>
              <span className="ml-auto flex items-center gap-1.5 font-mono text-[9px] tracking-[0.18em] text-teal">
                <span className="w-1.5 h-1.5 rounded-full bg-teal pulse-dot" /> ACTIVE
              </span>
            </div>

            <p className="text-[13px] text-fog leading-relaxed">
              Whisper listens, the local brain thinks, Piper speaks. The whole conversation happens inside
              your machine — pull the ethernet cable mid-sentence and nothing changes.
            </p>

            <div className="space-y-2.5">
              {[
                ["WHISPER 39M", "speech → text · 0.5 GB RAM · int8"],
                ["YUNO NANO BRAIN", "intent routing · forge commands · model advice"],
                ["PIPER TTS", "text → voice · 0.4 GB RAM · neural"],
              ].map(([k, v]) => (
                <div key={k} className="flex items-center gap-3 border border-line bg-ink2 px-3.5 py-2.5 clip-tag">
                  <IconSpark size={13} className="text-ember shrink-0" />
                  <div className="font-mono">
                    <p className="text-[10.5px] text-mist tracking-[0.14em]">{k}</p>
                    <p className="text-[9px] text-fog tracking-[0.1em] mt-0.5">{v}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-auto border border-teal/30 bg-teal/5 p-4 flex gap-3 clip-tag">
              <IconWifiOff size={18} className="text-teal shrink-0 mt-0.5" />
              <p className="font-mono text-[10.5px] leading-relaxed text-teal/90 tracking-[0.08em]">
                AIRPLANE-MODE TESTED. Your voice is processed in local memory and discarded — never recorded, never sent.
              </p>
            </div>
          </div>

          {/* chat */}
          <div className="border border-line bg-panel clip-hud flex flex-col overflow-hidden">
            <div className="flex items-center gap-2 px-4 h-10 border-b border-line">
              <svg width="9" height="9" viewBox="0 0 10 10"><circle cx="5" cy="5" r="4" fill="#ff5d73" /></svg>
              <svg width="9" height="9" viewBox="0 0 10 10"><circle cx="5" cy="5" r="4" fill="#ffb454" /></svg>
              <svg width="9" height="9" viewBox="0 0 10 10"><circle cx="5" cy="5" r="4" fill="#2fe6c8" /></svg>
              <span className="ml-2 font-mono text-[10px] tracking-[0.18em] text-fog">yuno://talk — local session</span>
              <button
                onClick={() => { setVoiceOut((v) => !v); toast(voiceOut ? "Voice replies muted" : "Voice replies on — Yuno will speak", "ok"); }}
                className={`ml-auto flex items-center gap-1.5 font-mono text-[9px] tracking-[0.16em] border px-2 py-1 clip-tag transition-all ${
                  voiceOut ? "border-teal/50 text-teal" : "border-line2 text-fog"
                }`}
              >
                <IconVolume size={11} /> {voiceOut ? "VOICE ON" : "VOICE OFF"}
              </button>
            </div>

            <div ref={listRef} className="flex-1 min-h-[340px] max-h-[430px] overflow-y-auto terminal-log p-5 space-y-4 bg-ink2/50">
              {msgs.map((m, i) => (
                <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[85%] ${m.role === "user" ? "text-right" : ""}`}>
                    <div
                      className={`inline-block text-left px-4 py-3 text-[13px] leading-relaxed clip-hud-sm border ${
                        m.role === "user"
                          ? "bg-ember/12 border-ember/40 text-snow"
                          : "bg-panel2 border-line text-mist"
                      }`}
                    >
                      {m.text}
                    </div>
                    {m.role === "ai" && m.forgePrompt && (
                      <div className="mt-2">
                        <button
                          onClick={() => onForge(m.forgePrompt!)}
                          className="btn-primary clip-tag px-4 py-2.5 font-mono text-[10px] font-bold tracking-[0.14em] inline-flex items-center gap-2"
                        >
                          SEND "{m.forgePrompt.slice(0, 34)}{m.forgePrompt.length > 34 ? "…" : ""}" TO FORGE <IconArrowRight size={12} />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {(listening || interim) && (
                <div className="flex justify-end">
                  <div className="px-4 py-3 border border-teal/40 bg-teal/6 text-teal font-mono text-[12px] clip-hud-sm italic">
                    {interim || "listening…"}
                  </div>
                </div>
              )}
            </div>

            <div className="border-t border-line p-4">
              {unsupported && (
                <p className="mb-3 flex items-center gap-2 font-mono text-[10px] text-coral">
                  <IconX size={11} /> MIC UNAVAILABLE IN THIS BROWSER — TYPE BELOW, THE LOCAL BRAIN STILL ANSWERS
                </p>
              )}
              <div className="flex flex-wrap gap-2 mb-3.5">
                {QUICK.map((qk) => (
                  <button key={qk} onClick={() => respond(qk)} className="clip-tag border border-line2 text-fog text-[10.5px] px-2.5 py-1.5 hover:border-teal/60 hover:text-teal transition-all">
                    {qk}
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={toggleMic}
                  className={`relative shrink-0 w-12 h-12 clip-tag flex items-center justify-center transition-all ${
                    listening ? "bg-coral text-ink" : "bg-panel2 border border-line2 text-teal hover:border-teal"
                  }`}
                  aria-label={listening ? "Stop listening" : "Start talking"}
                >
                  {listening && <span className="absolute inset-0 border-2 border-coral mic-ring" />}
                  {listening && <span className="absolute inset-0 border-2 border-coral mic-ring" style={{ animationDelay: "0.55s" }} />}
                  <IconMic size={20} />
                </button>

                {listening && (
                  <div className="flex items-end gap-[3px] h-8">
                    {[0, 1, 2, 3, 4, 5, 6].map((i) => (
                      <span key={i} className="wavebar w-[3px] bg-teal h-full" style={{ animationDelay: i * 0.11 + "s" }} />
                    ))}
                  </div>
                )}

                <form
                  className="flex-1 flex items-center border border-line2 bg-ink2 focus-within:border-teal/60 transition-colors clip-tag"
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (!input.trim()) return;
                    respond(input.trim());
                    setInput("");
                  }}
                >
                  <input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder={listening ? "Speak now…" : "Type to Yuno Nano…"}
                    className="flex-1 bg-transparent outline-none px-4 h-12 text-[13px] font-mono text-snow placeholder:text-fog/50 min-w-0"
                  />
                  <button type="submit" className="w-12 h-12 flex items-center justify-center text-ember hover:bg-ember/10 transition-colors" aria-label="Send">
                    <IconSend size={17} />
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
