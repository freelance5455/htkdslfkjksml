import type { Build } from "../lib/models";
import { useReveal } from "../lib/hooks";
import { IconDownload, IconPlay, IconTrash, IconGamepad, IconClock } from "./Icons";
import { GENRE_META } from "../lib/models";

interface Props {
  builds: Build[];
  onPlay: (b: Build) => void;
  onDelete: (id: string) => void;
  onDownload: (b: Build) => void;
}

const GENRE_ICON_TINT: Record<string, string> = {
  "SPACE SHOOTER": "#ffb454",
  "METEOR DODGE": "#ffb454",
  "NEON SNAKE": "#2fe6c8",
  "BLOCK BREAKER": "#ff5d73",
  "PIXEL RUNNER": "#2fe6c8",
  "TURBO RACER": "#ff5d73",
};

function ago(ts: number): string {
  const m = Math.max(1, Math.round((Date.now() - ts) / 60000));
  if (m < 60) return m + "m ago";
  const h = Math.round(m / 60);
  if (h < 24) return h + "h ago";
  return Math.round(h / 24) + "d ago";
}

export default function Arcade({ builds, onPlay, onDelete, onDownload }: Props) {
  const headRef = useReveal<HTMLDivElement>();
  const gridRef = useReveal<HTMLDivElement>();

  return (
    <section id="arcade" className="relative py-24 border-t border-line/60">
      <div className="mx-auto max-w-7xl px-5">
        <div ref={headRef} className="reveal flex flex-wrap items-end justify-between gap-6 mb-10">
          <div>
            <p className="font-mono text-[11px] tracking-[0.3em] text-teal mb-3">// 03 — YOUR ARCADE</p>
            <h2 className="font-display font-bold text-[clamp(1.6rem,3.4vw,2.5rem)] text-snow leading-tight">
              Everything you forged,<br />
              <span className="text-fog text-[0.62em] font-medium">stored in your browser. Reboot-proof, cloud-free.</span>
            </h2>
          </div>
          <p className="font-mono text-[11px] tracking-[0.16em] text-fog border border-line bg-panel px-3.5 py-2.5 clip-tag">
            <span className="text-ember">{builds.length}</span> BUILD{builds.length === 1 ? "" : "S"} ON DISK
          </p>
        </div>

        {builds.length === 0 ? (
          <div className="border border-dashed border-line2 clip-hud p-16 text-center">
            <IconGamepad size={38} className="mx-auto text-fog mb-4" />
            <p className="text-mist">The arcade is dark. Forge your first game above and it lands here.</p>
          </div>
        ) : (
          <div ref={gridRef} className="reveal grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {builds.map((b) => (
              <article key={b.id} className="card-hover group border border-line bg-panel clip-hud overflow-hidden flex flex-col">
                <button onClick={() => onPlay(b)} className="relative block text-left cursor-pointer" aria-label={"Play " + b.title}>
                  {b.thumb ? (
                    <img src={b.thumb} alt={b.title} className="w-full aspect-[3/2] object-cover transition-transform duration-700 group-hover:scale-[1.06]" />
                  ) : (
                    <div
                      className="w-full aspect-[3/2] flex items-center justify-center relative overflow-hidden"
                      style={{ background: "linear-gradient(140deg, " + b.config.colors.bg + ", #131824)" }}
                    >
                      <div
                        className="absolute inset-0 opacity-40"
                        style={{ background: "radial-gradient(ellipse at 30% 30%, " + b.config.colors.player + "22, transparent 60%), radial-gradient(ellipse at 75% 70%, " + b.config.colors.enemy + "22, transparent 60%)" }}
                      />
                      <IconGamepad size={44} className="relative transition-transform duration-500 group-hover:scale-125 group-hover:-rotate-6" style={{ color: GENRE_ICON_TINT[b.genre] ?? "#ffb454" }} />
                      <div className="absolute bottom-3 left-3 flex gap-1.5">
                        {[b.config.colors.player, b.config.colors.enemy, b.config.colors.accent].map((c) => (
                          <span key={c} className="w-4 h-4 border border-ink/60" style={{ background: c }} />
                        ))}
                      </div>
                    </div>
                  )}
                  <span className="absolute inset-0 bg-ink/0 group-hover:bg-ink/40 transition-colors flex items-center justify-center">
                    <span className="opacity-0 group-hover:opacity-100 scale-75 group-hover:scale-100 transition-all duration-300 w-14 h-14 clip-tag bg-ember text-ink flex items-center justify-center">
                      <IconPlay size={22} />
                    </span>
                  </span>
                  {b.seed && (
                    <span className="absolute top-2.5 left-2.5 font-mono text-[8.5px] tracking-[0.2em] bg-ink/85 text-teal border border-teal/40 px-2 py-0.5">SAMPLE BUILD</span>
                  )}
                </button>

                <div className="p-4 flex flex-col gap-3 flex-1">
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="font-display font-bold text-[14.5px] text-snow truncate">{b.title}</h3>
                      <span className="font-mono text-[9px] tracking-[0.14em] text-fog flex items-center gap-1 shrink-0">
                        <IconClock size={10} /> {ago(b.date)}
                      </span>
                    </div>
                    <p className="font-mono text-[9.5px] tracking-[0.16em] text-fog mt-1.5">
                      <span className="text-teal">{b.genre}</span> · {b.modelName}
                    </p>
                  </div>
                  <p className="text-[11.5px] text-fog/90 leading-relaxed line-clamp-2 italic">"{b.config.prompt}"</p>
                  <div className="mt-auto flex gap-2 pt-1">
                    <button onClick={() => onPlay(b)} className="clip-tag h-8 px-3 bg-ember text-ink font-mono text-[9.5px] font-bold tracking-[0.14em] hover:brightness-110 transition-all inline-flex items-center gap-1.5">
                      <IconPlay size={10} /> PLAY
                    </button>
                    <button onClick={() => onDownload(b)} className="clip-tag h-8 px-3 border border-line2 text-fog font-mono text-[9.5px] tracking-[0.14em] hover:border-ember hover:text-ember transition-all inline-flex items-center gap-1.5">
                      <IconDownload size={10} /> .HTML
                    </button>
                    {!b.seed && (
                      <button onClick={() => onDelete(b.id)} className="clip-tag h-8 px-2.5 border border-line2 text-fog hover:border-coral hover:text-coral transition-all ml-auto" aria-label="Delete build">
                        <IconTrash size={11} />
                      </button>
                    )}
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}

        <p className="mt-8 font-mono text-[10.5px] tracking-[0.14em] text-fog/70">
          GENRES CURRENTLY FORGEABLE: {Object.values(GENRE_META).map((g) => g.label).join(" · ")}
        </p>
      </div>
    </section>
  );
}
