import { useCallback, useEffect, useRef, useState } from "react";
import type { Car, DriverRecord, RunResult } from "../data/game";
import { formatDistance, formatNumber } from "../data/game";
import { GameCanvas, type GameHandle } from "../game/GameCanvas";
import type { HudSnapshot, Phase } from "../game/world";
import { LEVEL_STEP, START_SHIELD } from "../game/world";
import { sound } from "../game/audio";
import {
  ArrowRight,
  Bolt,
  ChevronLeft,
  ChevronRight,
  Close,
  Expand,
  Flag,
  Pause,
  Play,
  Restart,
  Shield,
  Shrink,
  Steering,
  Trophy,
  VolumeOff,
  VolumeOn,
} from "./Icons";

export type SubmitInfo = { rank: number; total: number };

type Props = {
  car: Car;
  records: DriverRecord[];
  personalBest: number;
  soundOn: boolean;
  onToggleSound: () => void;
  onSubmitRun: (result: RunResult) => SubmitInfo;
  onOpenGarage: () => void;
  onOpenCircuit: () => void;
};

const DEFAULT_HUD: HudSnapshot = {
  score: 0,
  distance: 0,
  speed: 118,
  topSpeed: 118,
  shield: START_SHIELD,
  nitro: 60,
  nitroActive: false,
  level: 1,
  nearMisses: 0,
  sparks: 0,
  nextMilestone: LEVEL_STEP,
  crashed: false,
};

const pad = (value: number) => String(value).padStart(2, "0");

const OBJECTIVES = [
  { label: "Reach the city limits", target: 1000, detail: "1,000 m" },
  { label: "Clear the coastal stretch", target: 2500, detail: "2,500 m" },
  { label: "Etch your name on the wall", target: 5000, detail: "5,000 m" },
];

export function GameStage({
  car,
  records,
  personalBest,
  soundOn,
  onToggleSound,
  onSubmitRun,
  onOpenGarage,
  onOpenCircuit,
}: Props) {
  const [phase, setPhase] = useState<Phase>("idle");
  const [runToken, setRunToken] = useState(0);
  const [hud, setHud] = useState<HudSnapshot>(DEFAULT_HUD);
  const [countdown, setCountdown] = useState(3);
  const [fullscreen, setFullscreen] = useState(false);
  const [milestone, setMilestone] = useState<{ id: number; level: number } | null>(null);
  const [summary, setSummary] = useState<(RunResult & SubmitInfo & { best: boolean }) | null>(null);
  const canvasRef = useRef<GameHandle | null>(null);
  const bestBeforeRef = useRef(personalBest);
  const milestoneTimer = useRef<number | null>(null);

  const topRecord = records[0];
  const running = phase === "playing" || phase === "paused" || phase === "countdown";

  const beginRun = useCallback(() => {
    bestBeforeRef.current = personalBest;
    setSummary(null);
    setMilestone(null);
    setHud(DEFAULT_HUD);
    setCountdown(3);
    setPhase("countdown");
    setRunToken((token) => token + 1);
    canvasRef.current?.restart();
    sound.setMuted(!soundOn);
    sound.start();
  }, [personalBest, soundOn]);

  useEffect(() => {
    const handler = () => beginRun();
    window.addEventListener("vanta:start", handler);
    return () => window.removeEventListener("vanta:start", handler);
  }, [beginRun]);

  useEffect(() => {
    if (phase !== "countdown") return;
    const delay = countdown === 0 ? 420 : 620;
    const timer = window.setTimeout(() => {
      if (countdown > 0) setCountdown((value) => value - 1);
      else setPhase("playing");
    }, delay);
    return () => window.clearTimeout(timer);
  }, [phase, countdown]);

  useEffect(() => {
    if (!fullscreen) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [fullscreen]);

  useEffect(
    () => () => {
      if (milestoneTimer.current) window.clearTimeout(milestoneTimer.current);
    },
    [],
  );

  const handlePhaseRequest = useCallback(
    (next: Phase | "restart") => {
      if (next === "restart") {
        beginRun();
        return;
      }
      if (next === "playing") {
        if (phase === "paused") setPhase("playing");
        else if (phase === "idle" || phase === "over") beginRun();
        return;
      }
      if (next === "paused" && phase === "playing") setPhase("paused");
    },
    [beginRun, phase],
  );

  const handleRunEnd = useCallback(
    (result: RunResult) => {
      setPhase("over");
      const info = onSubmitRun(result);
      setSummary({ ...result, ...info, best: result.distance > bestBeforeRef.current });
    },
    [onSubmitRun],
  );

  const handleMilestone = useCallback((level: number) => {
    setMilestone({ id: Date.now(), level });
    if (milestoneTimer.current) window.clearTimeout(milestoneTimer.current);
    milestoneTimer.current = window.setTimeout(() => setMilestone(null), 2300);
  }, []);

  const requestStart = () => {
    if (phase === "playing") setPhase("paused");
    else if (phase === "paused") setPhase("playing");
    else beginRun();
  };

  const progress = Math.min(1, (hud.distance % LEVEL_STEP) / LEVEL_STEP);

  const shell = fullscreen
    ? "fixed inset-0 z-[80] flex flex-col bg-ink-950 p-3 sm:p-5"
    : "relative";

  const frame = fullscreen
    ? "relative min-h-0 flex-1 overflow-hidden rounded-2xl border border-white/12 bg-ink-900"
    : "relative aspect-[4/5] overflow-hidden rounded-[22px] border border-white/12 bg-ink-900 sm:aspect-[16/10] xl:aspect-[16/9]";

  return (
    <div className={shell}>
      {fullscreen && (
        <div className="pointer-events-none absolute inset-0 -z-10 bg-[radial-gradient(70%_60%_at_50%_0%,rgba(201,250,60,0.08),transparent_70%)]" />
      )}

      {/* Module toolbar */}
      <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-volt/25 bg-volt/10 text-volt">
            <Steering className="h-4 w-4" />
          </span>
          <div>
            <p className="font-mono text-[9px] uppercase tracking-[0.22em] text-moss-500">Playable // 01</p>
            <h3 className="text-[15px] font-semibold tracking-tight text-bone sm:text-base">The Midnight Run</h3>
          </div>
          <span className="ml-1 hidden items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-2.5 py-1 font-mono text-[9px] uppercase tracking-[0.16em] text-moss-300 sm:inline-flex">
            <span className={`h-1.5 w-1.5 rounded-full ${running ? "animate-pulse-dot bg-volt" : "bg-moss-500/60"}`} />
            {phase === "playing" ? "Running" : phase === "paused" ? "Paused" : phase === "over" ? "Logged" : "Ready"}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onToggleSound}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-moss-300 transition hover:border-white/20 hover:text-bone"
            aria-label={soundOn ? "Mute game audio" : "Unmute game audio"}
            aria-pressed={soundOn}
            title={soundOn ? "Mute audio" : "Enable audio"}
          >
            {soundOn ? <VolumeOn /> : <VolumeOff />}
          </button>
          <button
            type="button"
            onClick={() => setFullscreen((value) => !value)}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-moss-300 transition hover:border-white/20 hover:text-bone"
            aria-label={fullscreen ? "Exit fullscreen game" : "Play in fullscreen"}
            title={fullscreen ? "Exit fullscreen" : "Fullscreen"}
          >
            {fullscreen ? <Shrink /> : <Expand />}
          </button>
          <button
            type="button"
            onClick={requestStart}
            className="group inline-flex h-9 items-center gap-2 rounded-lg bg-volt px-3.5 text-[11px] font-semibold uppercase tracking-[0.12em] text-ink-950 transition hover:bg-volt-bright sm:h-9"
          >
            {phase === "playing" ? <Pause className="h-3.5 w-3.5" /> : phase === "paused" ? <Play className="h-3 w-3" /> : <Play className="h-3 w-3" />}
            {phase === "playing" ? "Pause" : phase === "paused" ? "Resume" : phase === "over" ? "Run again" : "Start run"}
          </button>
        </div>
      </div>

      <div
        className={
          fullscreen
            ? "flex min-h-0 flex-1 flex-col gap-3"
            : "grid gap-4 lg:grid-cols-[minmax(0,1fr)_318px] xl:grid-cols-[minmax(0,1fr)_338px]"
        }
      >
        <div className="flex min-h-0 flex-col">
          <div className={frame}>
            <GameCanvas
              ref={canvasRef}
              car={car}
              phase={phase}
              runToken={runToken}
              soundOn={soundOn}
              onHud={setHud}
              onPhaseRequest={handlePhaseRequest}
              onRunEnd={handleRunEnd}
              onMilestone={handleMilestone}
            />
            <div className="pointer-events-none absolute inset-0 rounded-[inherit] ring-1 ring-inset ring-white/8" />

            {/* Live HUD */}
            {phase !== "idle" && (
              <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between gap-2 p-2.5 sm:p-4">
                <div className="glass rounded-xl border border-white/12 px-3 py-2 sm:rounded-2xl sm:px-3.5 sm:py-2.5">
                  <div className="flex items-baseline gap-1.5">
                    <span className="font-mono text-[26px] font-semibold leading-none tabular-nums tracking-tight text-bone sm:text-[30px]">
                      {hud.speed}
                    </span>
                    <span className="font-mono text-[8px] uppercase tracking-[0.16em] text-moss-400">km/h</span>
                  </div>
                  <div className="mt-2 flex items-center gap-1.5">
                    <span className="font-mono text-[7px] font-semibold uppercase tracking-[0.14em] text-volt">N2O</span>
                    <span className="h-1 w-16 overflow-hidden rounded-full bg-white/12 sm:w-24">
                      <span
                        className={`block h-full rounded-full transition-[width] duration-150 ${
                          hud.nitroActive ? "bg-volt-bright" : hud.nitro > 99 ? "animate-pulse-dot bg-volt" : "bg-volt"
                        }`}
                        style={{ width: `${hud.nitro}%` }}
                      />
                    </span>
                  </div>
                </div>

                <div className="flex flex-col items-end gap-1.5">
                  <span className="glass inline-flex items-center gap-1.5 rounded-full border border-white/12 px-2.5 py-1 font-mono text-[8px] uppercase tracking-[0.16em] text-moss-300 sm:text-[9px]">
                    <span className="h-1 w-1 animate-pulse-dot rounded-full bg-volt" />
                    Sector {pad(hud.level)}
                  </span>
                  <div className="glass flex items-center gap-2.5 rounded-xl border border-white/12 px-2.5 py-1.5">
                    <span className="flex items-center gap-1" aria-label={`${hud.shield} of ${START_SHIELD} shields`}>
                      {Array.from({ length: START_SHIELD }).map((_, index) => (
                        <span
                          key={index}
                          className={`h-2.5 w-2.5 rotate-45 rounded-[2px] border ${
                            index < hud.shield ? "border-volt/60 bg-volt" : "border-white/25 bg-white/5"
                          }`}
                        />
                      ))}
                    </span>
                    <span className="h-3 w-px bg-white/15" />
                    <span className="font-mono text-[9px] uppercase tracking-[0.1em] text-moss-300 tabular-nums">
                      {formatNumber(hud.distance)} m
                    </span>
                  </div>
                </div>
              </div>
            )}

            {milestone && (
              <div className="pointer-events-none absolute left-1/2 top-[76px] z-10 -translate-x-1/2 sm:top-24">
                <div className="animate-reveal-up flex items-center gap-2 rounded-full border border-volt/40 bg-ink-950/85 px-4 py-2 shadow-[0_8px_30px_rgba(0,0,0,0.5)] backdrop-blur-md">
                  <span className="h-1.5 w-1.5 animate-pulse-dot rounded-full bg-volt" />
                  <span className="font-mono text-[10px] font-semibold uppercase tracking-[0.18em] text-volt">
                    Sector {pad(milestone.level)} unlocked
                  </span>
                </div>
              </div>
            )}

            {/* Idle overlay */}
            {phase === "idle" && (
              <div className="absolute inset-0 z-20 flex items-center justify-center overflow-y-auto p-4 sm:p-6">
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950/95 via-ink-950/55 to-ink-950/25" />
                <div className="relative w-full max-w-md text-center">
                  <div className="animate-reveal-up">
                    <span className="inline-flex items-center gap-2 rounded-full border border-volt/30 bg-volt/8 px-3 py-1.5 font-mono text-[9px] uppercase tracking-[0.2em] text-volt">
                      <span className="h-1.5 w-1.5 animate-pulse-dot rounded-full bg-volt" />
                      Endless highway runner
                    </span>
                    <h4 className="mt-4 text-balance text-3xl font-semibold leading-[0.98] tracking-[-0.03em] text-bone sm:text-[40px]">
                      The night is
                      <br />
                      <span className="font-serif italic font-normal text-volt">waiting for you.</span>
                    </h4>
                    <p className="mx-auto mt-3 max-w-xs text-balance text-[13px] leading-relaxed text-moss-300">
                      Thread the traffic, chain near misses and push to 200 km/h. Every metre is score — every mistake costs a shield.
                    </p>
                    <button
                      type="button"
                      onClick={beginRun}
                      className="group mt-5 inline-flex items-center justify-center gap-2.5 rounded-full bg-volt px-6 py-3 text-[12px] font-semibold uppercase tracking-[0.14em] text-ink-950 transition hover:bg-volt-bright hover:shadow-[0_0_40px_-8px_rgba(201,250,60,0.65)]"
                    >
                      Start the engine
                      <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
                    </button>
                    <div className="mt-4 flex flex-wrap items-center justify-center gap-x-3 gap-y-1.5 font-mono text-[9px] uppercase tracking-[0.12em] text-moss-500">
                      <span className="flex items-center gap-1">
                        <span className="keycap !min-w-0 !px-1 !py-0.5 !text-[9px]">←</span>
                        <span className="keycap !min-w-0 !px-1 !py-0.5 !text-[9px]">→</span>
                        steer
                      </span>
                      <span className="h-1 w-1 rounded-full bg-moss-500/50" />
                      <span className="flex items-center gap-1">
                        <span className="keycap !min-w-0 !px-1 !py-0.5 !text-[9px]">⇧</span>
                        nitro
                      </span>
                      <span className="h-1 w-1 rounded-full bg-moss-500/50" />
                      <span>Best {formatNumber(personalBest)} m</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {phase === "countdown" && (
              <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-ink-950/45">
                <p className="kicker mb-3 text-volt">Eyes up · hold your line</p>
                <div
                  key={countdown}
                  className="animate-countdown font-mono text-[86px] font-semibold leading-none tracking-tighter text-volt drop-shadow-[0_0_36px_rgba(201,250,60,0.45)] sm:text-[112px]"
                >
                  {countdown > 0 ? countdown : "GO"}
                </div>
                <p className="mt-4 font-mono text-[10px] uppercase tracking-[0.22em] text-moss-300">{car.name}</p>
              </div>
            )}

            {phase === "paused" && (
              <div className="absolute inset-0 z-20 flex items-center justify-center p-4">
                <div className="absolute inset-0 bg-ink-950/70 backdrop-blur-[3px]" />
                <div className="animate-reveal-up relative w-full max-w-sm rounded-2xl border border-white/12 bg-ink-850/95 p-6">
                  <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-volt/25 bg-volt/10 text-volt">
                    <Pause />
                  </span>
                  <h4 className="mt-4 text-2xl font-semibold tracking-tight text-bone">Run paused.</h4>
                  <p className="mt-1.5 text-[13px] leading-relaxed text-moss-300">
                    The highway is holding its breath. Take your time — the clock starts again when you do.
                  </p>
                  <div className="mt-5 flex flex-col gap-2">
                    <button
                      type="button"
                      onClick={() => setPhase("playing")}
                      className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-volt px-4 py-3 text-[12px] font-semibold uppercase tracking-[0.12em] text-ink-950 transition hover:bg-volt-bright"
                    >
                      <Play className="h-3.5 w-3.5" /> Resume run
                    </button>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={beginRun}
                        className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-white/12 bg-white/5 px-3 py-2.5 text-[11px] font-medium text-bone transition hover:bg-white/8"
                      >
                        <Restart className="h-3.5 w-3.5" /> Restart
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setPhase("idle");
                          setFullscreen(false);
                          onOpenGarage();
                        }}
                        className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-white/12 bg-white/5 px-3 py-2.5 text-[11px] font-medium text-bone transition hover:bg-white/8"
                      >
                        <Steering className="h-3.5 w-3.5" /> Garage
                      </button>
                    </div>
                  </div>
                  <p className="mt-4 font-mono text-[9px] uppercase tracking-[0.16em] text-moss-500">Press P to resume · R to restart</p>
                </div>
              </div>
            )}

            {phase === "over" && summary && (
              <div className="absolute inset-0 z-20 flex items-start justify-center overflow-y-auto p-3 sm:items-center sm:p-5">
                <div className="absolute inset-0 bg-ink-950/82 backdrop-blur-[3px]" />
                <div className="animate-reveal-up relative my-auto w-full max-w-md rounded-2xl border border-white/12 bg-ink-850/95 p-4 shadow-2xl sm:p-6">
                  <div className="flex items-center justify-between">
                    <span
                      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 font-mono text-[9px] font-semibold uppercase tracking-[0.16em] ${
                        summary.best ? "bg-volt text-ink-950" : "border border-white/12 bg-white/5 text-moss-300"
                      }`}
                    >
                      {summary.best ? <Trophy className="h-3 w-3" /> : <Flag className="h-3 w-3" />}
                      {summary.best ? "New personal best" : "Run logged"}
                    </span>
                    <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-moss-500">{car.name}</span>
                  </div>
                  <h4 className="mt-3 text-[26px] font-semibold leading-none tracking-[-0.03em] text-bone sm:text-[32px]">
                    {summary.best ? (
                      <>
                        You own the <span className="font-serif italic font-normal text-volt">night.</span>
                      </>
                    ) : (
                      <>
                        One more <span className="font-serif italic font-normal text-volt">run.</span>
                      </>
                    )}
                  </h4>
                  <p className="mt-1.5 text-[12px] leading-relaxed text-moss-300">
                    P{summary.rank} of {summary.total} on the local wall · {formatNumber(summary.nearMisses)} near misses ·{" "}
                    {summary.sparks} charges collected.
                  </p>

                  <div className="mt-4 grid grid-cols-3 gap-px overflow-hidden rounded-xl border border-white/10 bg-white/8">
                    {[
                      { label: "Distance", value: formatNumber(summary.distance), unit: "m", accent: true },
                      { label: "Run score", value: formatNumber(summary.score), unit: "pts" },
                      { label: "Top speed", value: String(summary.topSpeed), unit: "km/h" },
                    ].map((stat) => (
                      <div key={stat.label} className="bg-ink-900/95 px-2.5 py-3">
                        <p className="font-mono text-[7px] uppercase tracking-[0.14em] text-moss-500">{stat.label}</p>
                        <p className="mt-1 flex items-baseline gap-1">
                          <span
                            className={`font-mono text-base font-semibold tabular-nums sm:text-lg ${
                              stat.accent ? "text-volt" : "text-bone"
                            }`}
                          >
                            {stat.value}
                          </span>
                          <span className="font-mono text-[8px] text-moss-500">{stat.unit}</span>
                        </p>
                      </div>
                    ))}
                  </div>

                  <div className="mt-2 grid grid-cols-3 gap-2 rounded-xl border border-white/10 bg-white/4 px-3 py-2">
                    {[
                      ["Sector", pad(summary.level)],
                      ["Shields left", `${Math.max(0, hud.shield)} / ${START_SHIELD}`],
                      ["Car", car.trim],
                    ].map(([label, value]) => (
                      <div key={label}>
                        <p className="font-mono text-[7px] uppercase tracking-[0.12em] text-moss-500">{label}</p>
                        <p className="mt-0.5 font-mono text-[11px] font-medium text-moss-300">{value}</p>
                      </div>
                    ))}
                  </div>

                  <div className="mt-4 flex flex-col gap-2 sm:flex-row">
                    <button
                      type="button"
                      onClick={beginRun}
                      className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-volt px-4 py-3 text-[12px] font-semibold uppercase tracking-[0.12em] text-ink-950 transition hover:bg-volt-bright"
                    >
                      <Restart className="h-4 w-4" /> Run it back
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setPhase("idle");
                        setFullscreen(false);
                        onOpenCircuit();
                      }}
                      className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl border border-white/12 bg-white/5 px-4 py-3 text-[12px] font-medium text-bone transition hover:bg-white/8"
                    >
                      See the circuit <ArrowRight className="h-4 w-4" />
                    </button>
                  </div>
                  <p className="mt-3 text-center font-mono text-[9px] uppercase tracking-[0.14em] text-moss-500">
                    Press R to restart instantly
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Controls under the frame */}
          <div className="mt-3 flex items-center justify-between gap-3">
            <div className="flex w-full items-center justify-between gap-3 lg:hidden">
              <div className="flex gap-2">
                <HoldButton onHold={(value) => canvasRef.current?.setControl("left", value)} label="Steer left">
                  <ChevronLeft className="h-5 w-5" />
                </HoldButton>
                <HoldButton onHold={(value) => canvasRef.current?.setControl("right", value)} label="Steer right">
                  <ChevronRight className="h-5 w-5" />
                </HoldButton>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handlePhaseRequest("restart")}
                  className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/12 bg-white/5 text-moss-300 transition active:bg-white/10"
                  aria-label="Restart run"
                >
                  <Restart className="h-4 w-4" />
                </button>
                <HoldButton
                  onHold={(value) => canvasRef.current?.setControl("nitro", value)}
                  label="Hold for nitro"
                  variant="nitro"
                >
                  <Bolt className="h-4 w-4" /> Nitro
                </HoldButton>
              </div>
            </div>

            <div className="hidden w-full items-center justify-between gap-4 lg:flex">
              <div className="flex flex-wrap items-center gap-x-4 gap-y-2 font-mono text-[9px] uppercase tracking-[0.12em] text-moss-500">
                <span className="flex items-center gap-1.5">
                  <span className="keycap">←</span>
                  <span className="keycap">→</span> Steer
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="keycap">↑</span>
                  <span className="keycap">↓</span> Throttle
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="keycap !px-2">shift</span> Nitro
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="keycap">P</span> Pause
                </span>
              </div>
              <span className="flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.12em] text-moss-500">
                <span className="h-1 w-1 animate-pulse-dot rounded-full bg-volt" /> Drag on the road to steer
              </span>
            </div>
          </div>
        </div>

        {!fullscreen && (
          <aside className="flex flex-col gap-3">
            <div className="rounded-2xl border border-white/10 bg-ink-900/80 p-4">
              <div className="flex items-center justify-between">
                <p className="kicker !tracking-[0.18em]">Live telemetry</p>
                <span className="font-mono text-[8px] uppercase tracking-[0.14em] text-moss-500">
                  {running ? "● recording" : "○ standby"}
                </span>
              </div>

              <div className="mt-3 flex items-end justify-between gap-2">
                <div>
                  <p className="font-mono text-[8px] uppercase tracking-[0.16em] text-moss-500">Run score</p>
                  <p className="mt-0.5 font-mono text-[32px] font-semibold leading-none tabular-nums tracking-tight text-bone">
                    {formatNumber(hud.score)}
                  </p>
                </div>
                <span className="rounded-full border border-volt/25 bg-volt/8 px-2 py-1 font-mono text-[8px] font-medium uppercase tracking-[0.12em] text-volt">
                  Lvl {pad(hud.level)}
                </span>
              </div>

              <div className="mt-4 grid grid-cols-3 gap-px overflow-hidden rounded-xl border border-white/10 bg-white/8">
                {[
                  { label: "Distance", value: formatNumber(hud.distance), unit: "m" },
                  { label: "Top speed", value: String(Math.round(hud.topSpeed ?? hud.speed)), unit: "km/h" },
                  { label: "Near miss", value: String(hud.nearMisses), unit: "" },
                ].map((stat) => (
                  <div key={stat.label} className="bg-ink-900 px-2.5 py-2.5">
                    <p className="font-mono text-[7px] uppercase tracking-[0.1em] text-moss-500">{stat.label}</p>
                    <p className="mt-1 font-mono text-[13px] font-semibold tabular-nums text-bone">
                      {stat.value}
                      {stat.unit && <span className="ml-1 text-[8px] font-normal text-moss-500">{stat.unit}</span>}
                    </p>
                  </div>
                ))}
              </div>

              <div className="mt-4 space-y-3">
                <div>
                  <div className="mb-1.5 flex items-center justify-between">
                    <span className="flex items-center gap-1.5 font-mono text-[8px] uppercase tracking-[0.14em] text-moss-400">
                      <Shield className="h-3 w-3" /> Integrity
                    </span>
                    <span className="font-mono text-[9px] tabular-nums text-bone">
                      {hud.shield}/{START_SHIELD}
                    </span>
                  </div>
                  <div className="flex gap-1">
                    {Array.from({ length: START_SHIELD }).map((_, index) => (
                      <span
                        key={index}
                        className={`h-1.5 flex-1 rounded-full transition-colors ${
                          index < hud.shield ? "bg-volt" : "bg-white/10"
                        }`}
                      />
                    ))}
                  </div>
                </div>
                <div>
                  <div className="mb-1.5 flex items-center justify-between">
                    <span className="flex items-center gap-1.5 font-mono text-[8px] uppercase tracking-[0.14em] text-moss-400">
                      <Bolt className="h-3 w-3" /> Nitro charge
                    </span>
                    <span className={`font-mono text-[9px] tabular-nums ${hud.nitroActive ? "text-volt" : "text-bone"}`}>
                      {hud.nitroActive ? "BOOSTING" : `${hud.nitro}%`}
                    </span>
                  </div>
                  <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
                    <div
                      className={`h-full rounded-full transition-[width] duration-150 ${hud.nitroActive ? "bg-volt-bright" : "bg-volt"}`}
                      style={{ width: `${hud.nitro}%` }}
                    />
                  </div>
                </div>
                <div>
                  <div className="mb-1.5 flex items-center justify-between font-mono text-[8px] uppercase tracking-[0.14em] text-moss-400">
                    <span>Sector {pad(hud.level)} progress</span>
                    <span className="tabular-nums text-moss-300">
                      {formatNumber(hud.distance % LEVEL_STEP)} / {formatNumber(LEVEL_STEP)} m
                    </span>
                  </div>
                  <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
                    <div className="h-full rounded-full bg-moss-300/60 transition-[width]" style={{ width: `${progress * 100}%` }} />
                  </div>
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-white/10 bg-ink-900/60 p-4">
              <div className="flex items-center justify-between">
                <p className="kicker !tracking-[0.18em]">Run objectives</p>
                <span className="font-mono text-[8px] uppercase tracking-[0.14em] text-moss-500">
                  {OBJECTIVES.filter((item) => hud.distance >= item.target).length}/{OBJECTIVES.length}
                </span>
              </div>
              <ul className="mt-2.5 space-y-1">
                {OBJECTIVES.map((item) => {
                  const done = hud.distance >= item.target;
                  return (
                    <li key={item.target} className="flex items-center gap-2.5 border-b border-white/5 py-2 last:border-0">
                      <span
                        className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border ${
                          done ? "border-volt bg-volt text-ink-950" : "border-white/15 bg-white/4 text-moss-500"
                        }`}
                      >
                        {done ? (
                          <svg viewBox="0 0 24 24" fill="none" className="h-3 w-3">
                            <path d="m5 12 5 5L19 7" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
                          </svg>
                        ) : (
                          <span className="h-1 w-1 rounded-full bg-current" />
                        )}
                      </span>
                      <span className={`flex-1 text-[11.5px] ${done ? "text-moss-400 line-through decoration-moss-500/40" : "text-moss-300"}`}>
                        {item.label}
                      </span>
                      <span className="font-mono text-[8px] uppercase tracking-[0.1em] text-moss-500">{item.detail}</span>
                    </li>
                  );
                })}
              </ul>
            </div>

            <div className="rounded-2xl border border-white/10 bg-gradient-to-br from-white/6 to-transparent p-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-mono text-[8px] uppercase tracking-[0.16em] text-moss-500">Personal best</p>
                  <p className="mt-1 font-mono text-xl font-semibold tabular-nums text-bone">
                    {personalBest > 0 ? `${formatNumber(personalBest)} m` : "Not set yet"}
                  </p>
                </div>
                <span className="flex h-8 w-8 items-center justify-center rounded-lg border border-volt/25 bg-volt/10 text-volt">
                  <Trophy className="h-4 w-4" />
                </span>
              </div>
              <div className="mt-3 flex items-center gap-2 border-t border-white/8 pt-2.5">
                <span className="font-mono text-[8px] uppercase tracking-[0.12em] text-moss-500">Wall record</span>
                <span className="ml-auto font-mono text-[10px] text-moss-300">
                  {topRecord ? `${formatDistance(topRecord.distance)} · ${topRecord.driver}` : "—"}
                </span>
              </div>
            </div>
          </aside>
        )}
      </div>

      {fullscreen && (
        <button
          type="button"
          onClick={() => setFullscreen(false)}
          className="absolute right-3 top-3 z-30 flex h-9 w-9 items-center justify-center rounded-lg border border-white/15 bg-ink-950/80 text-moss-300 backdrop-blur transition hover:text-bone sm:right-5 sm:top-5"
          aria-label="Close fullscreen"
        >
          <Close />
        </button>
      )}
    </div>
  );
}

function HoldButton({
  onHold,
  children,
  label,
  variant = "default",
}: {
  onHold: (value: boolean) => void;
  children: React.ReactNode;
  label: string;
  variant?: "default" | "nitro";
}) {
  const stop = (event: React.PointerEvent<HTMLButtonElement>) => {
    onHold(false);
    if (event.currentTarget.hasPointerCapture(event.pointerId)) {
      event.currentTarget.releasePointerCapture(event.pointerId);
    }
  };

  return (
    <button
      type="button"
      aria-label={label}
      onPointerDown={(event) => {
        event.preventDefault();
        event.currentTarget.setPointerCapture(event.pointerId);
        onHold(true);
      }}
      onPointerUp={stop}
      onPointerCancel={stop}
      onContextMenu={(event) => event.preventDefault()}
      style={{ touchAction: "none" }}
      className={`flex h-11 touch-none items-center justify-center gap-1.5 rounded-xl text-[11px] font-semibold uppercase tracking-[0.1em] transition active:scale-[0.98] ${
        variant === "nitro"
          ? "border border-volt/40 bg-volt/15 px-4 text-volt"
          : "w-14 border border-white/12 bg-white/5 text-bone"
      }`}
    >
      {children}
    </button>
  );
}
