import { useEffect, useRef, useState } from "react";
import { Footprints, Keyboard, Swords } from "lucide-react";
import { GameEngine } from "@/game/engine";
import { emptyHud, type BannerEvent, type GamePhase, type HudSnapshot, type RunResult, type ScoreEntry } from "@/game/types";
import { GameHud } from "./GameHud";
import { GameOverOverlay, PauseOverlay, StartOverlay } from "./Overlays";
import { TouchControls } from "./TouchControls";

interface GameStageProps {
  phase: GamePhase;
  result: RunResult | null;
  scores: ScoreEntry[];
  savedRank: number | null;
  entryId: string | null;
  playerName: string;
  muted: boolean;
  engineRef: React.RefObject<GameEngine | null>;
  onHud: (hud: HudSnapshot) => void;
  onGameOver: (result: RunResult) => void;
  onStart: () => void;
  onPause: () => void;
  onResume: () => void;
  onRestart: () => void;
  onHome: () => void;
  onMute: () => void;
  onNameChange: (name: string) => void;
}

export function GameStage(props: GameStageProps) {
  const {
    phase,
    result,
    scores,
    savedRank,
    entryId,
    playerName,
    muted,
    engineRef,
    onStart,
    onPause,
    onResume,
    onRestart,
    onHome,
    onMute,
    onNameChange,
  } = props;

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const callbacks = useRef(props);
  callbacks.current = props;
  const [banner, setBanner] = useState<BannerEvent | null>(null);
  const [hud, setHud] = useState<HudSnapshot>(emptyHud);
  const bannerTimer = useRef<number | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const engine = new GameEngine(canvas, {
      onHud: (next) => {
        setHud(next);
        callbacks.current.onHud(next);
      },
      onGameOver: (next) => callbacks.current.onGameOver(next),
      muted: callbacks.current.muted,
    });
    engineRef.current = engine;
    return () => {
      engine.destroy();
      engineRef.current = null;
    };
    // Engine is intentionally created once; callbacks are read from a live ref.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    engineRef.current?.setMuted(muted);
  }, [muted, engineRef]);

  const bannerId = hud.banner?.id ?? null;
  useEffect(() => {
    if (!bannerId) return;
    setBanner(hud.banner);
    if (bannerTimer.current) window.clearTimeout(bannerTimer.current);
    bannerTimer.current = window.setTimeout(() => setBanner(null), 3800);
    return () => {
      if (bannerTimer.current) window.clearTimeout(bannerTimer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bannerId]);

  useEffect(() => {
    if (phase !== "playing") setBanner(null);
  }, [phase]);

  return (
    <div className="stage-frame relative h-full w-full rounded-[24px] p-[5px] sm:rounded-[30px] sm:p-[7px]">
      <div className="stage-inner relative h-full w-full overflow-hidden rounded-[19px] bg-[#173129] sm:rounded-[24px]">
        <canvas
          ref={canvasRef}
          className="game-canvas absolute inset-0 h-full w-full"
          aria-label="ميدان لعب سراب — واحة صحراوية"
          role="img"
        />
        <div className="pointer-events-none absolute inset-0 z-10 bg-[radial-gradient(ellipse_at_center,transparent_42%,rgba(6,20,17,0.38)_100%)]" />
        <div className="pointer-events-none absolute inset-0 z-10 opacity-[0.06] [background-image:repeating-linear-gradient(0deg,rgba(255,255,255,0.5)_0px,rgba(255,255,255,0.5)_1px,transparent_1px,transparent_3px)]" />

        {phase === "playing" && (
          <GameHud hud={hud} onPause={onPause} banner={banner} onInteract={() => engineRef.current?.interact()} />
        )}

        {phase === "playing" && (
          <div className="desktop-hint pointer-events-none absolute bottom-3 left-3 z-20 items-center gap-2 rounded-full border border-[#f0d9a8]/15 bg-[#102620]/60 px-2.5 py-1.5 text-[9px] text-[#e8dcc4]/75 backdrop-blur-md">
            <Keyboard className="h-3 w-3 text-[#e3b974]" />
            <span><kbd className="font-sans text-[#f5dba4]">WASD</kbd> حركة</span>
            <span className="h-2.5 w-px bg-[#e8dcc4]/20" />
            <span className="flex items-center gap-1"><Swords className="h-2.5 w-2.5" /> مسافة هجوم</span>
            <span className="h-2.5 w-px bg-[#e8dcc4]/20" />
            <span className="flex items-center gap-1"><Footprints className="h-2.5 w-2.5" /> Shift اندفاع</span>
            <span className="h-2.5 w-px bg-[#e8dcc4]/20" />
            <span><kbd className="font-sans text-[#f5dba4]">E</kbd> تفاعل</span>
          </div>
        )}

        {phase === "playing" && <TouchControls engineRef={engineRef} phase={phase} hud={hud} />}

        {phase === "start" && (
          <StartOverlay
            onStart={onStart}
            bestScore={scores[0]?.score ?? 0}
            scores={scores}
            playerName={playerName}
            onNameChange={onNameChange}
            muted={muted}
            onMute={onMute}
          />
        )}

        {phase === "paused" && (
          <PauseOverlay onResume={onResume} onRestart={onRestart} onHome={onHome} muted={muted} onMute={onMute} />
        )}

        {phase === "over" && result && (
          <GameOverOverlay
            result={result}
            scores={scores}
            savedRank={savedRank}
            playerName={playerName}
            entryId={entryId}
            onNameChange={onNameChange}
            onRestart={onRestart}
            onHome={onHome}
          />
        )}

        {phase === "playing" && hud.hp <= 1 && hud.hp > 0 && (
          <div className="pointer-events-none absolute inset-0 z-[15] animate-pulse rounded-[19px] ring-2 ring-inset ring-[#c4513d]/40 sm:rounded-[24px]" />
        )}
      </div>
    </div>
  );
}
