import { statusMeta } from "@/lib/reportStats";
import { cn } from "@/lib/utils";

const styles = {
  reported: "bg-[#FBF0DA] text-[#8A5A0B] border-[#EFDCB4]",
  in_progress: "bg-[#E6F1F5] text-[#1E5E75] border-[#C7E0E9]",
  resolved: "bg-[#E4F2E9] text-[#14603C] border-[#C4E3D1]",
};

export default function StatusPill({ status, className }) {
  const meta = statusMeta(status);
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium",
        styles[status] || styles.reported,
        className
      )}
    >
      <span
        className="h-1.5 w-1.5 rounded-full"
        style={{ backgroundColor: meta.color }}
      />
      {meta.label}
    </span>
  );
}