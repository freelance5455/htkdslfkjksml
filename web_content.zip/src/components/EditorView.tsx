import React, { useState, useEffect, useRef } from 'react';
import {
  Play, Pause, RotateCcw, Volume2, VolumeX, Download, Wand2,
  Sliders, Type, Sparkles, LayoutTemplate, Layers, Check, RefreshCw
} from 'lucide-react';
import { AspectRatioType, FilterType, VideoProject } from '../types/project';
import { formatTime, estimateFileSizeMB } from '../utils/videoMath';
import { exportVideoSegment, renderProjectFrameToCanvas } from '../utils/videoExporter';
import { VIDEO_TEMPLATES } from '../data/templates';

interface EditorViewProps {
  project: VideoProject;
  onUpdateProject: (updated: Partial<VideoProject>) => void;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  onOpenAICommand: () => void;
  onNavigateToSplitter: () => void;
  lang: 'ar' | 'en';
}

export const EditorView: React.FC<EditorViewProps> = ({
  project,
  onUpdateProject,
  videoRef,
  canvasRef,
  onOpenAICommand,
  onNavigateToSplitter,
  lang
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [activeTab, setActiveTab] = useState<'aspect' | 'filters' | 'text' | 'audio' | 'templates'>('aspect');

  // Text overlay edit states
  const [titleInput, setTitleInput] = useState(project.textOverlays[0]?.text || '');
  const [watermarkInput, setWatermarkInput] = useState(project.watermarkText || '');
  const [subtitleInput, setSubtitleInput] = useState('');

  // Export Modal state
  const [showExportModal, setShowExportModal] = useState(false);
  const [exportRes, setExportRes] = useState<'480p' | '720p' | '1080p'>('720p');
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [exportedUrl, setExportedUrl] = useState<string | null>(null);

  // Play / Pause toggle
  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;

    if (video.paused) {
      video.play().catch(() => {});
      setIsPlaying(true);
    } else {
      video.pause();
      setIsPlaying(false);
    }
  };

  // Keep canvas rendering synchronized with video frames
  useEffect(() => {
    let animId: number;
    const loop = () => {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      if (video && canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          renderProjectFrameToCanvas(ctx, video, project, canvas.width, canvas.height);
          setCurrentTime(video.currentTime);
        }
      }
      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [project]);

  // Handle Seek
  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    const video = videoRef.current;
    if (video) {
      video.currentTime = time;
      setCurrentTime(time);
    }
  };

  // Update text overlays in project
  const handleUpdateTitle = (val: string) => {
    setTitleInput(val);
    const existing = [...project.textOverlays];
    if (existing.length > 0) {
      existing[0] = { ...existing[0], text: val };
    } else {
      existing.push({
        id: 'title_1',
        text: val,
        position: 'top',
        fontSize: 32,
        color: '#ffffff',
        bgColor: 'rgba(124, 58, 237, 0.85)',
        hasBackground: true
      });
    }
    onUpdateProject({ textOverlays: existing });
  };

  const handleUpdateWatermark = (val: string) => {
    setWatermarkInput(val);
    onUpdateProject({ watermarkText: val });
  };

  const handleAddSubtitle = (val: string) => {
    setSubtitleInput(val);
    const existing = [...project.textOverlays];
    const subIdx = existing.findIndex((t) => t.isSubtitle);
    if (subIdx >= 0) {
      existing[subIdx] = { ...existing[subIdx], text: val };
    } else if (val) {
      existing.push({
        id: 'sub_1',
        text: val,
        position: 'bottom',
        fontSize: 24,
        color: '#facc15',
        bgColor: 'rgba(0, 0, 0, 0.8)',
        hasBackground: true,
        isSubtitle: true
      });
    }
    onUpdateProject({ textOverlays: existing });
  };

  // Apply template
  const handleSelectTemplate = (tId: string) => {
    const template = VIDEO_TEMPLATES.find((t) => t.id === tId);
    if (!template) return;

    setTitleInput(template.defaultTitle);
    onUpdateProject({
      templateId: template.id,
      aspectRatio: template.aspectRatio,
      blurBackground: template.blurBackground,
      filter: template.filter,
      textOverlays: [
        {
          id: 'tpl_title',
          text: template.defaultTitle,
          position: template.aspectRatio === '9:16' ? 'top' : 'bottom',
          fontSize: 30,
          color: '#ffffff',
          bgColor: template.accentColor + 'cc',
          hasBackground: true
        }
      ]
    });
  };

  // Perform full video export
  const handleExport = async () => {
    const video = videoRef.current;
    if (!video) return;

    setIsExporting(true);
    setExportProgress(0);
    setExportedUrl(null);

    try {
      const blob = await exportVideoSegment(
        video,
        project,
        0,
        project.duration || 60,
        exportRes,
        (pct) => setExportProgress(pct)
      );

      const url = URL.createObjectURL(blob);
      setExportedUrl(url);
    } catch (err: any) {
      alert('خطأ أثناء التصدير: ' + err?.message);
    } finally {
      setIsExporting(false);
    }
  };

  const totalDur = project.duration || 60;
  const estimatedSize = estimateFileSizeMB(totalDur, exportRes, 'high');

  return (
    <div className="max-w-6xl mx-auto p-4 sm:p-6 space-y-6 pb-28">
      {/* Top Bar with AI Prompt shortcut & Splitter Jump */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#111224] p-3.5 rounded-2xl border border-purple-900/40">
        <div className="flex items-center gap-2">
          <span className="font-bold text-sm text-white">{project.name}</span>
          <span className="text-xs px-2 py-0.5 rounded-full bg-purple-950 text-purple-300 border border-purple-800/40 font-mono">
            {formatTime(totalDur)}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenAICommand}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-900/40 hover:bg-purple-900/70 border border-purple-700/40 text-purple-200 text-xs font-semibold transition cursor-pointer"
          >
            <Wand2 className="w-3.5 h-3.5 text-purple-400" />
            <span>{lang === 'ar' ? 'تعديل بالأمر الذكي' : 'AI Edit Prompt'}</span>
          </button>

          <button
            onClick={onNavigateToSplitter}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-950/40 hover:bg-indigo-900/60 border border-indigo-700/40 text-indigo-200 text-xs font-semibold transition cursor-pointer"
          >
            <span>{lang === 'ar' ? 'تقسيم الفيديو ✂️' : 'Split Video ✂️'}</span>
          </button>

          <button
            onClick={() => setShowExportModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold shadow-md shadow-emerald-950 transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{lang === 'ar' ? 'تصدير الفيديو' : 'Export Video'}</span>
          </button>
        </div>
      </div>

      {/* Main Studio: Video Preview Canvas + Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column (Canvas Player & Timeline) */}
        <div className="lg:col-span-7 flex flex-col items-center">
          <div className="relative w-full max-w-[420px] aspect-[9/16] max-h-[580px] bg-black rounded-2xl overflow-hidden border border-purple-900/50 shadow-2xl flex items-center justify-center">
            {/* Real Canvas Rendering Output */}
            <canvas
              ref={canvasRef}
              width={720}
              height={1280}
              className="w-full h-full object-contain"
            />

            {/* Play/Pause Overlay Icon on Hover */}
            <button
              onClick={togglePlay}
              className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/40 transition opacity-0 hover:opacity-100 group cursor-pointer"
              aria-label={isPlaying ? 'Pause' : 'Play'}
            >
              <div className="p-4 rounded-full bg-purple-600/90 text-white shadow-xl scale-95 group-hover:scale-105 transition">
                {isPlaying ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8 ml-0.5" />}
              </div>
            </button>
          </div>

          {/* Timeline & Player Bar */}
          <div className="w-full max-w-[420px] mt-4 bg-[#111224] border border-purple-900/40 p-3.5 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-xs font-mono text-purple-300">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(totalDur)}</span>
            </div>

            <input
              type="range"
              min="0"
              max={totalDur}
              step="0.1"
              value={currentTime}
              onChange={handleSeek}
              className="w-full accent-purple-500 cursor-pointer h-2 bg-black/40 rounded-lg"
            />

            <div className="flex items-center justify-between pt-1">
              <button
                onClick={() => {
                  const v = videoRef.current;
                  if (v) v.currentTime = 0;
                }}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
                title={lang === 'ar' ? 'البدء من الأول' : 'Rewind to start'}
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              <button
                onClick={togglePlay}
                className="py-1.5 px-4 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-1.5 shadow transition cursor-pointer"
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                <span>{isPlaying ? (lang === 'ar' ? 'إيقاف مؤقت' : 'Pause') : (lang === 'ar' ? 'تشغيل' : 'Play')}</span>
              </button>

              <button
                onClick={() => onUpdateProject({ isMuted: !project.isMuted })}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
              >
                {project.isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
              </button>
            </div>
          </div>
        </div>

        {/* Right Column (Editing Control Panels) */}
        <div className="lg:col-span-5 bg-[#111224] border border-purple-900/40 rounded-2xl p-5 space-y-5">
          {/* Sub-tabs header */}
          <div className="flex items-center gap-1 bg-[#090a14] p-1 rounded-xl border border-purple-950 overflow-x-auto">
            {[
              { id: 'aspect', labelAr: 'الأبعاد', labelEn: 'Aspect' },
              { id: 'filters', labelAr: 'الألوان', labelEn: 'Colors' },
              { id: 'text', labelAr: 'النصوص', labelEn: 'Texts' },
              { id: 'audio', labelAr: 'الصوت والسرعة', labelEn: 'Audio' },
              { id: 'templates', labelAr: 'القوالب', labelEn: 'Templates' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-1.5 px-3 rounded-lg text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-purple-600 text-white shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {lang === 'ar' ? tab.labelAr : tab.labelEn}
              </button>
            ))}
          </div>

          {/* TAB 1: Aspect Ratio & Smart Blur */}
          {activeTab === 'aspect' && (
            <div className="space-y-4 animate-fadeIn">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                {lang === 'ar' ? 'نسبة العرض إلى الارتفاع' : 'Aspect Ratio'}
              </h3>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: '9:16', name: 'عمودي 9:16', desc: 'TikTok, Shorts, Reels' },
                  { id: '16:9', name: 'أفقي 16:9', desc: 'YouTube Standard' },
                  { id: '1:1', name: 'مربع 1:1', desc: 'Instagram Feed' },
                  { id: '4:5', name: 'بورتريه 4:5', desc: 'Social Portrait' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => onUpdateProject({ aspectRatio: item.id as AspectRatioType })}
                    className={`p-3 rounded-xl border text-start transition cursor-pointer ${
                      project.aspectRatio === item.id
                        ? 'bg-purple-950/60 border-purple-500 shadow-md text-white'
                        : 'bg-black/30 border-purple-950 text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="font-bold text-xs">{item.name}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">{item.desc}</div>
                  </button>
                ))}
              </div>

              {/* Blurred Background Toggle */}
              <div className="p-3.5 rounded-xl bg-[#090a14] border border-purple-900/40 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-white block">
                    {lang === 'ar' ? 'خلفية ضبابية ذكية (Mirror Blur)' : 'Smart Blurred Mirror Background'}
                  </span>
                  <span className="text-[10px] text-slate-400">
                    {lang === 'ar' ? 'تجنب الحواف السوداء في الفيديو العمودي' : 'Fills black letterbox borders'}
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={project.blurBackground}
                  onChange={(e) => onUpdateProject({ blurBackground: e.target.checked })}
                  className="w-4 h-4 accent-purple-500 rounded cursor-pointer"
                />
              </div>
            </div>
          )}

          {/* TAB 2: Filters & Sliders */}
          {activeTab === 'filters' && (
            <div className="space-y-4 animate-fadeIn">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                {lang === 'ar' ? 'قوالب الألوان والمؤثرات' : 'Color Presets'}
              </h3>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'normal', name: 'طبيعي' },
                  { id: 'cinematic', name: 'سينمائي' },
                  { id: 'vibrant', name: 'حيوي ومشرق' },
                  { id: 'gold', name: 'ذهبي فاخر' },
                  { id: 'bw', name: 'أبيض وأسود' },
                  { id: 'vintage', name: 'كلاسيكي' },
                ].map((f) => (
                  <button
                    key={f.id}
                    onClick={() => onUpdateProject({ filter: f.id as FilterType })}
                    className={`py-2 rounded-xl text-xs font-bold border transition cursor-pointer ${
                      project.filter === f.id
                        ? 'bg-purple-600 border-purple-400 text-white'
                        : 'bg-black/30 border-purple-950 text-slate-400 hover:text-white'
                    }`}
                  >
                    {f.name}
                  </button>
                ))}
              </div>

              {/* Sliders */}
              <div className="space-y-3 pt-2">
                <div>
                  <div className="flex justify-between text-xs text-slate-300 mb-1">
                    <span>{lang === 'ar' ? 'السطوع (Brightness)' : 'Brightness'}</span>
                    <span className="font-mono">{project.brightness}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="1.5"
                    step="0.05"
                    value={project.brightness}
                    onChange={(e) => onUpdateProject({ brightness: parseFloat(e.target.value) })}
                    className="w-full accent-purple-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs text-slate-300 mb-1">
                    <span>{lang === 'ar' ? 'التباين (Contrast)' : 'Contrast'}</span>
                    <span className="font-mono">{project.contrast}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="1.5"
                    step="0.05"
                    value={project.contrast}
                    onChange={(e) => onUpdateProject({ contrast: parseFloat(e.target.value) })}
                    className="w-full accent-purple-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs text-slate-300 mb-1">
                    <span>{lang === 'ar' ? 'تشبع الألوان (Saturation)' : 'Saturation'}</span>
                    <span className="font-mono">{project.saturation}x</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="2"
                    step="0.1"
                    value={project.saturation}
                    onChange={(e) => onUpdateProject({ saturation: parseFloat(e.target.value) })}
                    className="w-full accent-purple-500 cursor-pointer"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Text & Watermarks */}
          {activeTab === 'text' && (
            <div className="space-y-4 animate-fadeIn">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                {lang === 'ar' ? 'العناوين والعلامة المائية' : 'Titles & Watermarks'}
              </h3>

              {/* Main Title Input */}
              <div className="space-y-1.5">
                <label className="text-xs text-slate-300 font-medium">
                  {lang === 'ar' ? 'عنوان الفيديو الرئيسي:' : 'Main Video Title:'}
                </label>
                <input
                  type="text"
                  value={titleInput}
                  onChange={(e) => handleUpdateTitle(e.target.value)}
                  placeholder={lang === 'ar' ? 'مثال: شاهد للنهاية 🔥' : 'Watch till the end 🔥'}
                  className="w-full px-3 py-2 bg-[#0a0b16] border border-purple-800/50 rounded-xl text-white text-xs focus:outline-none focus:border-purple-400"
                />
              </div>

              {/* Subtitles Input */}
              <div className="space-y-1.5">
                <label className="text-xs text-slate-300 font-medium">
                  {lang === 'ar' ? 'نص الترجمة / توضيح بالأسفل:' : 'Bottom Subtitle / Caption:'}
                </label>
                <input
                  type="text"
                  value={subtitleInput}
                  onChange={(e) => handleAddSubtitle(e.target.value)}
                  placeholder={lang === 'ar' ? 'أضف تعليقاً أو ترجمة سريعة...' : 'Add quick caption or subtitle...'}
                  className="w-full px-3 py-2 bg-[#0a0b16] border border-purple-800/50 rounded-xl text-white text-xs focus:outline-none focus:border-purple-400"
                />
              </div>

              {/* Watermark / Channel name */}
              <div className="space-y-1.5">
                <label className="text-xs text-slate-300 font-medium">
                  {lang === 'ar' ? 'شعار القناة / العلامة المائية:' : 'Watermark / Brand Name:'}
                </label>
                <input
                  type="text"
                  value={watermarkInput}
                  onChange={(e) => handleUpdateWatermark(e.target.value)}
                  placeholder="Designo"
                  className="w-full px-3 py-2 bg-[#0a0b16] border border-purple-800/50 rounded-xl text-white text-xs focus:outline-none focus:border-purple-400"
                />
              </div>
            </div>
          )}

          {/* TAB 4: Audio & Playback Speed */}
          {activeTab === 'audio' && (
            <div className="space-y-4 animate-fadeIn">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                {lang === 'ar' ? 'التحكم في الصوت وسرعة الفيديو' : 'Audio & Speed'}
              </h3>

              {/* Speed Controller */}
              <div className="space-y-1.5">
                <span className="text-xs text-slate-300">{lang === 'ar' ? 'سرعة تشغيل الفيديو:' : 'Playback Speed:'}</span>
                <div className="grid grid-cols-6 gap-1">
                  {[0.5, 0.75, 1, 1.25, 1.5, 2].map((spd) => (
                    <button
                      key={spd}
                      onClick={() => onUpdateProject({ speed: spd })}
                      className={`py-1.5 rounded-lg text-xs font-bold border transition cursor-pointer ${
                        project.speed === spd
                          ? 'bg-purple-600 border-purple-400 text-white'
                          : 'bg-black/30 border-purple-950 text-slate-400 hover:text-white'
                      }`}
                    >
                      {spd}x
                    </button>
                  ))}
                </div>
              </div>

              {/* Volume Slider */}
              <div className="space-y-1.5 pt-2">
                <div className="flex justify-between text-xs text-slate-300">
                  <span>{lang === 'ar' ? 'مستوى الصوت:' : 'Volume:'}</span>
                  <span className="font-mono">{Math.round(project.volume * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={project.volume}
                  onChange={(e) => onUpdateProject({ volume: parseFloat(e.target.value) })}
                  className="w-full accent-purple-500 cursor-pointer"
                />
              </div>
            </div>
          )}

          {/* TAB 5: Quick Templates */}
          {activeTab === 'templates' && (
            <div className="space-y-3 animate-fadeIn max-h-[320px] overflow-y-auto pr-1">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                {lang === 'ar' ? 'اختر قالباً جاهزاً لتطبيقه فوراً' : 'Select Instant Template'}
              </h3>
              <div className="space-y-2">
                {VIDEO_TEMPLATES.slice(0, 8).map((tpl) => (
                  <div
                    key={tpl.id}
                    onClick={() => handleSelectTemplate(tpl.id)}
                    className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition ${
                      project.templateId === tpl.id
                        ? 'bg-purple-950/70 border-purple-400 shadow'
                        : 'bg-[#0a0b16] border-purple-900/30 hover:border-purple-700/50'
                    }`}
                  >
                    <div>
                      <div className="font-bold text-xs text-white">{lang === 'ar' ? tpl.nameAr : tpl.nameEn}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{tpl.badgeText} • {tpl.aspectRatio}</div>
                    </div>
                    {project.templateId === tpl.id && (
                      <Check className="w-4 h-4 text-emerald-400" />
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Export Modal */}
      {showExportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="w-full max-w-md bg-[#111224] border border-purple-800/40 rounded-2xl p-5 shadow-2xl space-y-4">
            <h3 className="font-bold text-lg text-white flex items-center gap-2">
              <Download className="w-5 h-5 text-emerald-400" />
              <span>{lang === 'ar' ? 'تصدير الفيديو الكامل' : 'Export Full Video'}</span>
            </h3>

            <div className="space-y-3">
              <label className="text-xs text-slate-300 font-medium block">
                {lang === 'ar' ? 'اختر دقة التصدير:' : 'Select resolution:'}
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['480p', '720p', '1080p'] as const).map((r) => (
                  <button
                    key={r}
                    onClick={() => setExportRes(r)}
                    className={`py-2 rounded-xl text-xs font-bold border transition cursor-pointer ${
                      exportRes === r
                        ? 'bg-purple-600 border-purple-400 text-white'
                        : 'bg-black/30 border-purple-950 text-slate-400 hover:text-white'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>

              <div className="p-3 rounded-xl bg-purple-950/30 border border-purple-900/30 text-xs text-slate-300 flex justify-between">
                <span>{lang === 'ar' ? 'الحجم التقديري:' : 'Estimated size:'}</span>
                <span className="font-bold text-emerald-400 font-mono">~{estimatedSize} MB</span>
              </div>
            </div>

            {/* Progress if exporting */}
            {isExporting && (
              <div className="space-y-2 pt-2">
                <div className="flex justify-between text-xs text-purple-200">
                  <span className="flex items-center gap-1.5">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>{lang === 'ar' ? 'جاري تصدير الفيديو...' : 'Exporting...'}</span>
                  </span>
                  <span className="font-mono">{exportProgress}%</span>
                </div>
                <div className="h-2.5 w-full bg-black/50 rounded-full overflow-hidden p-0.5">
                  <div
                    className="h-full bg-gradient-to-r from-purple-500 to-emerald-400 rounded-full transition-all"
                    style={{ width: `${exportProgress}%` }}
                  />
                </div>
              </div>
            )}

            {/* Download link when done */}
            {exportedUrl && !isExporting && (
              <a
                href={exportedUrl}
                download={`Designo_${project.name}.webm`}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>{lang === 'ar' ? 'تنزيل الفيديو على جهازك' : 'Download Video'}</span>
              </a>
            )}

            {/* Modal actions */}
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowExportModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium cursor-pointer"
              >
                {lang === 'ar' ? 'إغلاق' : 'Close'}
              </button>

              {!exportedUrl && (
                <button
                  onClick={handleExport}
                  disabled={isExporting}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold disabled:opacity-50 cursor-pointer"
                >
                  {lang === 'ar' ? 'بدء التصدير' : 'Start Export'}
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
