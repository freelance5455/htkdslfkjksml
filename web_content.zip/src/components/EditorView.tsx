import { useMemo, useRef, useState } from "react";
import Prism from "prismjs";
import "prismjs/components/prism-typescript";
import "prismjs/components/prism-jsx";
import "prismjs/components/prism-tsx";
import "prismjs/components/prism-json";
import "prismjs/components/prism-markdown";
import { useStore } from "../lib/store";
import { langOf, pathOf, statLine } from "../lib/fs";
import { download } from "../lib/workspace";
import { Button, Icon, IconButton, Sheet } from "./ui";

const LANGUAGES: Record<string, string> = {
  ts: "typescript",
  js: "javascript",
  tsx: "tsx",
  jsx: "jsx",
  json: "json",
  css: "css",
  html: "markup",
  md: "markdown",
};

export default function EditorView({ onBrowse }: { onBrowse: () => void }) {
  const { s, set, execute, showToast, openFile } = useStore();
  const node = s.openFileId ? s.fs.nodes[s.openFileId] : null;
  const draft = node ? (s.editorDrafts[node.id] ?? node.content ?? "") : "";
  const [menu, setMenu] = useState(false);
  const [finding, setFinding] = useState(false);
  const [query, setQuery] = useState("");
  const [saving, setSaving] = useState(false);
  const [scroll, setScroll] = useState({ x: 0, y: 0 });
  const textarea = useRef<HTMLTextAreaElement>(null);
  const dirty = !!node && draft !== (node.content ?? "");
  const lines = draft.split("\n").length;
  const lang = LANGUAGES[langOf(node?.name ?? "")] ?? "text";
  const highlighted = useMemo(
    () =>
      Prism.languages[lang]
        ? Prism.highlight(draft, Prism.languages[lang], lang)
        : (Prism.util.encode(draft) as string),
    [draft, lang],
  );
  const matches = query
    ? draft.toLowerCase().split(query.toLowerCase()).length - 1
    : 0;
  const update = (value: string) => {
    if (node)
      set((state) => ({
        editorDrafts: { ...state.editorDrafts, [node.id]: value },
      }));
  };
  const insert = (value: string) => {
    const el = textarea.current;
    if (!el) return;
    const start = el.selectionStart;
    update(draft.slice(0, start) + value + draft.slice(el.selectionEnd));
    requestAnimationFrame(() => {
      el.focus();
      el.setSelectionRange(start + value.length, start + value.length);
    });
  };
  const save = async () => {
    if (!node || !dirty || saving) return;
    setSaving(true);
    const value = draft;
    const result = await execute({
      kind: "edit",
      label: "Save file",
      path: pathOf(s.fs, node.id),
      content: value,
    });
    if (result.status === "done") {
      set((state) => {
        const drafts = { ...state.editorDrafts };
        if (drafts[node.id] === value) delete drafts[node.id];
        return { editorDrafts: drafts };
      });
      showToast(
        s.workspaceMode === "device"
          ? "Saved to your device folder."
          : "Saved in this browser workspace.",
      );
    } else showToast(result.note);
    setSaving(false);
  };
  if (!node || node.type !== "file")
    return (
      <div className="flex min-h-0 flex-1 flex-col items-center justify-center gap-4 px-6 text-center">
        <Icon name="code" className="h-10 w-10 text-line2" />
        <h1 className="text-xl font-medium tracking-tight">
          A little room to code.
        </h1>
        <p className="max-w-[320px] text-xs leading-relaxed text-muted">
          Open a file to edit, or let the agent propose your next change.
          Unsaved drafts stay here when you switch tabs.
        </p>
        <Button variant="secondary" icon="folder" onClick={onBrowse}>
          Browse files
        </Button>
        <div className="mt-3 space-y-2">
          {Object.values(s.fs.nodes)
            .filter((n) => n.type === "file" && !n.binary)
            .slice(0, 3)
            .map((n) => (
              <button
                key={n.id}
                onClick={() => openFile(n.id)}
                className="flex w-full items-center gap-2 text-[11px] text-muted hover:text-accent"
              >
                <Icon name="file" className="h-3 w-3" />
                {pathOf(s.fs, n.id)}
                <Icon name="arrowUpRight" className="h-3 w-3" />
              </button>
            ))}
        </div>
      </div>
    );

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex h-14 shrink-0 items-center gap-2 border-b border-line px-3 sm:px-6">
        <Icon name="code" className="h-4 w-4 text-accent" />
        <div className="min-w-0 flex-1">
          <span className="block truncate font-mono text-[11px]">
            {pathOf(s.fs, node.id)}
            {dirty && (
              <span className="ml-2 inline-block h-1.5 w-1.5 rounded-full bg-warn" />
            )}
          </span>
          <span className="mt-0.5 block text-[9px] uppercase tracking-wider text-muted">
            {langOf(node.name)}
          </span>
        </div>
        <IconButton
          name="search"
          label="Find in file"
          onClick={() => setFinding(!finding)}
        />
        <Button
          size="sm"
          variant={dirty ? "primary" : "ghost"}
          icon="save"
          disabled={!dirty || saving || !s.permissions.edit}
          onClick={save}
        >
          {saving ? "Saving..." : "Save"}
        </Button>
        <IconButton
          name="dots"
          label="File options"
          onClick={() => setMenu(true)}
        />
      </div>
      {finding && (
        <div className="flex shrink-0 items-center gap-2 border-b border-line px-4 py-2">
          <input
            aria-label="Find in file"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Find..."
            className="h-9 min-w-0 flex-1 rounded-lg border border-line bg-surface2 px-3 text-xs outline-none focus:border-accent"
          />
          <span className="text-[10px] text-muted">{matches} matches</span>
          <button
            onClick={() => {
              const el = textarea.current;
              if (!el || !query) return;
              let index = draft
                .toLowerCase()
                .indexOf(query.toLowerCase(), el.selectionEnd);
              if (index < 0)
                index = draft.toLowerCase().indexOf(query.toLowerCase());
              if (index >= 0) {
                el.focus();
                el.setSelectionRange(index, index + query.length);
                el.scrollTop = Math.max(
                  0,
                  (draft.slice(0, index).split("\n").length - 4) * 22,
                );
              }
            }}
            className="px-2 text-xs text-accent"
          >
            Next
          </button>
          <IconButton
            name="close"
            label="Close find"
            onClick={() => setFinding(false)}
          />
        </div>
      )}
      {!s.permissions.edit && (
        <p className="border-b border-line bg-warnsoft px-4 py-2 text-[11px] text-warn">
          Edit permission is off. This file is read-only.
        </p>
      )}
      <div className="syntax-editor relative flex min-h-0 flex-1 overflow-hidden font-mono">
        <div
          aria-hidden="true"
          className="code-editor w-12 shrink-0 select-none overflow-hidden border-r border-line bg-surface text-right text-muted/50"
        >
          <div
            className="py-4"
            style={{ transform: `translateY(${-scroll.y}px)` }}
          >
            {Array.from({ length: lines }, (_, i) => (
              <div className="pr-3" key={i}>
                {i + 1}
              </div>
            ))}
          </div>
        </div>
        <div className="relative min-w-0 flex-1 overflow-hidden">
          <pre
            aria-hidden="true"
            className="code-editor pointer-events-none absolute left-0 top-0 m-0 min-h-full min-w-full whitespace-pre p-4"
            style={{ transform: `translate(${-scroll.x}px, ${-scroll.y}px)` }}
          >
            <code dangerouslySetInnerHTML={{ __html: highlighted + "\n" }} />
          </pre>
          <textarea
            aria-label={`Edit ${node.name}`}
            ref={textarea}
            readOnly={!s.permissions.edit}
            value={draft}
            spellCheck={false}
            autoCorrect="off"
            autoCapitalize="off"
            wrap="off"
            onChange={(e) => update(e.target.value)}
            onScroll={(e) =>
              setScroll({
                x: e.currentTarget.scrollLeft,
                y: e.currentTarget.scrollTop,
              })
            }
            onKeyDown={(e) => {
              if (e.key === "Tab") {
                e.preventDefault();
                insert("  ");
              }
              if ((e.ctrlKey || e.metaKey) && e.key === "s") {
                e.preventDefault();
                void save();
              }
              if ((e.ctrlKey || e.metaKey) && e.key === "f") {
                e.preventDefault();
                setFinding(true);
              }
            }}
            className="code-editor relative block h-full w-full resize-none overflow-auto whitespace-pre bg-transparent p-4 text-transparent caret-fg outline-none"
          />
        </div>
      </div>
      <div className="flex shrink-0 items-center gap-1 border-t border-line bg-surface px-3 py-1.5 md:hidden">
        {["Tab", "{ }", "[ ]", "( )", "=>", ";", '"'].map((key) => (
          <button
            key={key}
            onPointerDown={(e) => e.preventDefault()}
            onClick={() => insert(key === "Tab" ? "  " : key)}
            disabled={!s.permissions.edit}
            className="h-8 flex-1 rounded-md bg-surface2 font-mono text-[11px] text-muted hover:text-fg disabled:opacity-30"
          >
            {key}
          </button>
        ))}
      </div>
      <div className="flex shrink-0 items-center justify-between border-t border-line px-4 py-2 font-mono text-[9px] text-muted">
        <span>{statLine(s.fs, node.id)}</span>
        <span>
          {dirty
            ? "Unsaved draft"
            : s.workspaceMode === "device"
              ? "Saved to device"
              : "Saved locally"}{" "}
          / UTF-8
        </span>
      </div>
      <Sheet
        open={menu}
        onClose={() => setMenu(false)}
        title={node.name}
        subtitle="File options"
      >
        <div className="px-3 pb-4">
          {[
            {
              label: "Copy contents",
              icon: "copy",
              run: async () => {
                try {
                  await navigator.clipboard.writeText(draft);
                  showToast("File contents copied.");
                } catch {
                  showToast("Clipboard unavailable.");
                }
              },
            },
            {
              label: "Download this file",
              icon: "download",
              run: () => download(draft, node.name),
            },
            { label: "Browse workspace files", icon: "folder", run: onBrowse },
            {
              label: "Close file (draft is kept)",
              icon: "close",
              run: () => set({ openFileId: null }),
            },
          ].map((action) => (
            <button
              key={action.label}
              onClick={() => {
                void action.run();
                setMenu(false);
              }}
              className="flex w-full items-center gap-3 rounded-lg px-3 py-3 text-left text-sm hover:bg-surface2"
            >
              <Icon name={action.icon} className="h-4 w-4 text-muted" />
              {action.label}
            </button>
          ))}
        </div>
      </Sheet>
    </div>
  );
}
