import React, { useState, useRef } from 'react';
import Editor, { Monaco, loader } from '@monaco-editor/react';
import { emmetHTML, emmetCSS, emmetJSX, expandAbbreviation } from 'emmet-monaco-es';
import { FileItem } from '../types';
import { THEMES } from '../constants';
import { isImageFile } from '../utils/files';
import { 
  Play, 
  Sparkles, 
  ExternalLink,
  Check,
  Code2,
  Trash2
} from 'lucide-react';

// Configure Monaco Editor 0.45.0 from jsdelivr CDN
loader.config({
  paths: {
    vs: 'https://cdn.jsdelivr.net/npm/monaco-editor@0.45.0/min/vs',
  },
});

interface EditorViewProps {
  files: FileItem[];
  activeFileId: string | null;
  siteTheme?: string;
  onSelectFile: (id: string) => void;
  onUpdateFileContent: (id: string, content: string) => void;
  onRunPreview: () => void;
  onCreateFile: (name: string, isFolder: boolean, parentId?: string | null, content?: string) => void;
  onDeleteFile?: (id: string) => void;
}

export const EditorView: React.FC<EditorViewProps> = ({
  files,
  activeFileId,
  siteTheme = 'vscode-dark',
  onSelectFile,
  onUpdateFileContent,
  onRunPreview,
  onCreateFile,
  onDeleteFile,
}) => {
  const activeFile = files.find((f) => f.id === activeFileId) || files[0] || null;
  const editorRef = useRef<any>(null);
  const [createPrompt, setCreatePrompt] = useState<{ isOpen: boolean; fileName: string } | null>(null);
  const [formattedFeedback, setFormattedFeedback] = useState(false);

  const themeConfig = THEMES[siteTheme] || THEMES['vscode-dark'];
  const monacoTheme = themeConfig.isDark ? 'vs-dark' : 'vs';

  const isImg = isImageFile(activeFile);

  const handleEditorDidMount = (editor: any, monaco: Monaco) => {
    editorRef.current = editor;

    // Emmet setup for HTML, CSS, JSX
    try {
      emmetHTML(monaco, ['html']);
      emmetCSS(monaco, ['css']);
      emmetJSX(monaco, ['javascript', 'typescript', 'javascriptreact', 'typescriptreact']);
    } catch (err) {
      console.warn('Emmet setup:', err);
    }

    // Register the editor action for emmet expansion
    editor.addAction({
      id: 'editor.emmet.action.expandAbbreviation',
      label: 'Emmet: Expand Abbreviation',
      run: (ed: any) => {
        const model = ed.getModel();
        const position = ed.getPosition();
        if (!model || !position) return;

        const line = model.getLineContent(position.lineNumber).substring(0, position.column - 1);
        const match = line.match(/([a-zA-Z0-9_#\.\*\+>:\$\{\}\[\]\!-]+)$/);
        if (match) {
          const abbr = match[1];
          const lang = model.getLanguageId();
          try {
            const expanded = expandAbbreviation(abbr, {
              type: lang === 'css' ? 'stylesheet' : 'markup',
              syntax: lang,
            });
            if (expanded) {
              const startCol = position.column - abbr.length;
              ed.executeEdits('emmet', [
                {
                  range: new monaco.Range(position.lineNumber, startCol, position.lineNumber, position.column),
                  text: expanded,
                  forceMoveMarkers: true,
                },
              ]);
              return;
            }
          } catch (e) {}
        }
        ed.trigger('keyboard', 'type', { text: '\n' });
      },
    });

    // Trigger Emmet abbreviation expansion on Enter
    editor.addCommand(monaco.KeyCode.Enter, () =>
      editor.trigger('emmet', 'editor.emmet.action.expandAbbreviation', {})
    );

    // Define custom themes if needed
    monaco.editor.defineTheme('pure-black-monaco', {
      base: 'vs-dark',
      inherit: true,
      rules: [],
      colors: {
        'editor.background': '#000000',
      },
    });

    // Snippet completions for '!' and '+'
    monaco.languages.registerCompletionItemProvider('html', {
      triggerCharacters: ['.', '#', '!', '+', '>'],
      provideCompletionItems: (model: any, position: any) => {
        const lineContent = model.getLineContent(position.lineNumber).substring(0, position.column - 1);
        const match = lineContent.match(/([a-zA-Z0-9_\-\.#\+!]+)$/);
        if (!match) return { suggestions: [] };

        const word = match[1];
        const startCol = position.column - word.length;
        const range = {
          startLineNumber: position.lineNumber,
          endLineNumber: position.lineNumber,
          startColumn: startCol,
          endColumn: position.column,
        };

        const suggestions: any[] = [];

        if (word === '!' || word.endsWith('!')) {
          suggestions.push({
            label: '!',
            kind: monaco.languages.CompletionItemKind.Snippet,
            detail: 'HTML5 Boilerplate',
            insertText: [
              '<!DOCTYPE html>',
              '<html lang="en">',
              '<head>',
              '  <meta charset="UTF-8">',
              '  <meta name="viewport" content="width=device-width, initial-scale=1.0">',
              '  <title>Document</title>',
              '  <link rel="stylesheet" href="styles.css">',
              '</head>',
              '<body>',
              '  $0',
              '</body>',
              '</html>',
            ].join('\n'),
            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
            range,
          });
        }

        if (word.includes('+')) {
          const parts = word.split('+').filter(Boolean);
          if (parts.length >= 2) {
            const expanded = parts.map((tag: string) => `<${tag}>$0</${tag}>`).join('\n');
            suggestions.push({
              label: word,
              kind: monaco.languages.CompletionItemKind.Snippet,
              detail: `Emmet Sibling: ${word}`,
              insertText: expanded,
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              range,
            });
          }
        }

        return { suggestions };
      },
    });
  };

  const handleFormatCode = () => {
    if (editorRef.current) {
      editorRef.current.getAction('editor.action.formatDocument')?.run();
      setFormattedFeedback(true);
      setTimeout(() => setFormattedFeedback(false), 1500);
    }
  };

  const handleAutoCreateFile = () => {
    if (!createPrompt) return;
    const fileName = createPrompt.fileName;
    setCreatePrompt(null);

    let defaultContent = '';
    const lower = fileName.toLowerCase();
    if (lower.endsWith('.css')) {
      defaultContent = `/* ${fileName} */\nbody {\n  margin: 0;\n  padding: 0;\n}`;
    } else if (lower.endsWith('.js') || lower.endsWith('.ts')) {
      defaultContent = `// ${fileName}\nconsole.log("${fileName} initialized.");`;
    } else if (lower.endsWith('.html')) {
      defaultContent = `<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <title>${fileName}</title>\n</head>\n<body>\n  <h1>${fileName}</h1>\n</body>\n</html>`;
    }

    onCreateFile(fileName, false, null, defaultContent);
  };

  if (!activeFile) {
    return (
      <div className="h-full w-full flex flex-col items-center justify-center theme-bg-main theme-text-muted p-8 text-center">
        <Code2 className="w-12 h-12 text-[#359efe] mb-3 opacity-60" />
        <h3 className="text-base font-bold theme-text-main mb-1">No Active File Selected</h3>
        <p className="text-xs max-w-xs leading-relaxed">
          Open or create a file from the Explorer sidebar on the left to start editing code.
        </p>
      </div>
    );
  }

  return (
    <div className="h-full w-full flex flex-col overflow-hidden theme-bg-main relative">
      {/* Editor Action Breadcrumb Bar */}
      <div className="h-9 px-3 flex items-center justify-between border-b theme-border bg-[#181920] shrink-0 text-xs">
        <div className="flex items-center space-x-2 truncate">
          <span className="font-mono text-[11px] theme-text-muted">workspace /</span>
          <span className="font-mono text-xs font-semibold text-slate-200 truncate">
            {activeFile.name}
          </span>
          {onDeleteFile && (
            <button
              onClick={() => {
                if (window.confirm(`Are you sure you want to delete "${activeFile.name}"?`)) {
                  onDeleteFile(activeFile.id);
                }
              }}
              className="p-1 text-slate-500 hover:text-red-400 rounded transition-colors cursor-pointer"
              title={`Delete ${activeFile.name}`}
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        <div className="flex items-center space-x-2">
          {/* Format Code */}
          <button
            onClick={handleFormatCode}
            className="flex items-center space-x-1 px-2.5 py-1 rounded text-[11px] font-medium theme-bg-surface hover:theme-bg-surface-hover theme-text-main transition-colors cursor-pointer"
            title="Format Code (Prettier / Beautify)"
          >
            {formattedFeedback ? (
              <Check className="w-3 h-3 text-emerald-400" />
            ) : (
              <Sparkles className="w-3 h-3 text-amber-400" />
            )}
            <span>{formattedFeedback ? 'Formatted' : 'Format'}</span>
          </button>

          {/* Run Code / Live Preview */}
          <button
            onClick={onRunPreview}
            className="flex items-center space-x-1.5 px-3 py-1 rounded bg-[#359efe] hover:bg-[#2563eb] text-white text-[11px] font-bold cursor-pointer transition-transform active:scale-95 shadow-xs"
            title="Run Code & View Live Preview (Go Live)"
          >
            <Play className="w-3 h-3 fill-current" />
            <span>Go Live</span>
          </button>
        </div>
      </div>

      {/* Editor Main Content or Image Preview */}
      <div className="flex-grow w-full h-[calc(100%-2.25rem)] relative overflow-hidden">
        {isImg ? (
          <div className="h-full w-full flex flex-col items-center justify-center p-6 theme-bg-surface overflow-auto">
            <div className="max-w-md p-4 rounded-xl border theme-border theme-bg-main shadow-xl text-center">
              <div className="max-h-80 max-w-full overflow-hidden rounded-lg flex items-center justify-center bg-black/40 p-2 mb-3">
                <img
                  src={activeFile.content}
                  alt={activeFile.name}
                  className="max-h-72 object-contain rounded"
                />
              </div>
              <div className="font-mono text-xs font-bold text-slate-200">{activeFile.name}</div>
              <div className="text-[10px] theme-text-muted mt-1">Image Asset</div>
            </div>
          </div>
        ) : (
          <Editor
            height="100%"
            width="100%"
            language={activeFile.language || 'plaintext'}
            value={activeFile.content}
            theme={monacoTheme}
            onChange={(val) => onUpdateFileContent(activeFile.id, val || '')}
            onMount={handleEditorDidMount}
            options={{
              fontSize: 13,
              fontFamily: 'Consolas, "Fira Code", Monaco, monospace',
              tabSize: 2,
              wordWrap: 'on',
              minimap: { enabled: false },
              scrollBeyondLastLine: false,
              automaticLayout: true,
              smoothScrolling: true,
              cursorBlinking: 'smooth',
              cursorSmoothCaretAnimation: 'on',
              renderLineHighlight: 'all',
              bracketPairColorization: { enabled: true },
              formatOnPaste: true,
              suggestOnTriggerCharacters: true,
              tabCompletion: 'on',
              acceptSuggestionOnEnter: 'on',
              wordBasedSuggestions: 'off',
            }}
          />
        )}
      </div>

      {/* Auto Create File Dialog */}
      {createPrompt?.isOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#1f1f2e] border border-[#383a4d] rounded-xl shadow-2xl w-full max-w-sm p-5 text-slate-200">
            <h4 className="text-sm font-bold text-white mb-2 flex items-center space-x-2">
              <ExternalLink className="w-4 h-4 text-[#359efe]" />
              <span>VS Code File Link Navigation</span>
            </h4>
            <p className="text-xs text-slate-300 mb-4 leading-relaxed">
              File <span className="font-mono text-cyan-300 font-bold">"{createPrompt.fileName}"</span> was not found in your workspace. Would you like to auto-create and open this file in the editor now?
            </p>
            <div className="flex items-center justify-end space-x-2">
              <button
                onClick={() => setCreatePrompt(null)}
                className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleAutoCreateFile}
                className="px-4 py-1.5 rounded-lg text-xs font-bold bg-[#359efe] hover:bg-[#2563eb] text-white transition-colors cursor-pointer"
              >
                Create File
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
