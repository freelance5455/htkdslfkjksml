import { useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { tokenizeLine, tokenClass, LANG_LABEL, type LangId } from "@/lib/language";
import type { StudioApi, StudioFile } from "@/hooks/useStudio";
import { cn } from "@/lib/utils";
import { ChevronUp, Search, X } from "lucide-react";

interface Props {
  studio: StudioApi;
  activeFile: StudioFile | null;
  onOpenFiles: () => void;
}

const QUICK_KEYS = ["<", ">", "/", "{", "}", "(", ")", "[", "]", '"', "'", "=", ";", ":", "&", "|", "$", "#", "!", "*", "+", "-", "_"];

export function EditorView({ studio, activeFile, onOpenFiles }: Props) {
  const { settings, updateContent } = studio;
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const highlightRef = useRef<HTMLPreElement>(null);
  const gutterRef = useRef<HTMLDivElement>(null);
  const [cursor, setCursor] = useState({ line: 1, col: 1 });
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [replaceWith, setReplaceWith] = useState("");
  const [showQuickKeys, setShowQuickKeys] = useState(true);

  const content = activeFile?.content ?? "";
  const lang: LangId = (activeFile?.language as LangId) ?? "text";
  const lines = useMemo(() => content.split("\n"), [content]);

  useEffect(() => {
    const ta = textareaRef.current;
    if (!ta || !activeFile) return;
    const saved = sessionStorage.getItem(`cursor-${activeFile.id}`);
    if (saved) {
      const pos = Number(saved);
      if (!Number.isNaN(pos) && pos <= ta.value.length) {
        ta.selectionStart = ta.selectionEnd = pos;
      }
    }
  }, [activeFile?.id]);

  const syncScroll = () => {
    const ta = textareaRef.current;
    if (!ta) return;
    if (highlightRef.current) {
      highlightRef.current.scrollTop = ta.scrollTop;
      highlightRef.current.scrollLeft = ta.scrollLeft;
    }
    if (gutterRef.current) gutterRef.current.scrollTop = ta.scrollTop;
  };

  const updateCursor = () => {
    const ta = textareaRef.current;
    if (!ta) return;
    const pos = ta.selectionStart;
    const before = ta.value.slice(0, pos);
    const line = before.split("\n").length;
    const col = pos - before.lastIndexOf("\n");
    setCursor({ line, col });
    if (activeFile) sessionStorage.setItem(`cursor-${activeFile.id}`, String(pos));
  };

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (!activeFile) return;
    updateContent(activeFile.id, e.target.value);
    requestAnimationFrame(updateCursor);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    const ta = e.currentTarget;
    const { selectionStart, selectionEnd, value } = ta;

    if (e.key === "Tab") {
      e.preventDefault();
      const indent = " ".repeat(settings.tabSize);
      const next = value.slice(0, selectionStart) + indent + value.slice(selectionEnd);
      if (activeFile) updateContent(activeFile.id, next);
      requestAnimationFrame(() => {
        ta.selectionStart = ta.selectionEnd = selectionStart + indent.length;
      });
      return;
    }

    const pairs: Record<string, string> = { "(": ")", "[": "]", "{": "}", '"': '"', "'": "'", "`": "`" };
    if (pairs[e.key]) {
      e.preventDefault();
      const close = pairs[e.key];
      const next = value.slice(0, selectionStart) + e.key + close + value.slice(selectionEnd);
      if (activeFile) updateContent(activeFile.id, next);
      requestAnimationFrame(() => {
        ta.selectionStart = ta.selectionEnd = selectionStart + 1;
      });
      return;
    }

    if (e.key === "Enter") {
      const lineStart = value.lastIndexOf("\n", selectionStart - 1) + 1;
      const currentLine = value.slice(lineStart, selectionStart);
      const indentMatch = /^(\s*)/.exec(currentLine);
      const indent = indentMatch ? indentMatch[1] : "";
      const extra = /[{[(]\s*$/.test(currentLine) ? " ".repeat(settings.tabSize) : "";
      if (indent || extra) {
        e.preventDefault();
        const insert = "\n" + indent + extra;
        const next = value.slice(0, selectionStart) + insert + value.slice(selectionEnd);
        if (activeFile) updateContent(activeFile.id, next);
        requestAnimationFrame(() => {
          ta.selectionStart = ta.selectionEnd = selectionStart + insert.length;
        });
      }
    }
  };

  const insertText = (text: string) => {
    const ta = textareaRef.current;
    if (!ta || !activeFile) return;
    const { selectionStart, selectionEnd, value } = ta;
    const next = value.slice(0, selectionStart) + text + value.slice(selectionEnd);
    updateContent(activeFile.id, next);
    requestAnimationFrame(() => {
      ta.focus();
      ta.selectionStart = ta.selectionEnd = selectionStart + text.length;
      updateCursor();
    });
  };

  const runSearch = () => {
    if (!query || !activeFile) return;
    const idx = content.indexOf(query);
    if (idx === -1) return;
    const ta = textareaRef.current;
    if (!ta) return;
    ta.focus();
    ta.selectionStart = idx;
    ta.selectionEnd = idx + query.length;
    updateCursor();
  };

  const runReplaceAll = () => {
    if (!query || !activeFile) return;
    const next = content.split(query).join(replaceWith);
    updateContent(activeFile.id, next);
  };

  if (!activeFile) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center gap-4 p-8 text-center">
        <div className="rounded-2xl bg-sky-100 p-6 dark:bg-sky-950">
          <ChevronUp className="h-10 w-10 text-sky-600 dark:text-sky-400" />
        </div>
        <h2 className="text-xl font-bold">لا يوجد ملف مفتوح</h2>
        <p className="max-w-xs text-sm text-muted-foreground">
          أنشئ ملفًا جديدًا أو افتح أحد ملفات المشروع للبدء في التحرير.
        </p>
        <Button onClick={onOpenFiles} className="bg-sky-600 hover:bg-sky-700">
          إدارة الملفات
        </Button>
      </div>
    );
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex items-center gap-2 border-b border-slate-200 bg-white px-3 py-2 dark:border-slate-800 dark:bg-slate-900">
        <span className="rounded-md bg-sky-100 px-2 py-0.5 text-xs font-semibold text-sky-700 dark:bg-sky-950 dark:text-sky-300">
          {LANG_LABEL[lang]}
        </span>
        <span className="truncate text-sm font-medium">{activeFile.name}</span>
        {activeFile.dirty && (
          <span className="h-2 w-2 shrink-0 rounded-full bg-amber-500" title="غير محفوظ" />
        )}
        <div className="ms-auto flex items-center gap-1">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => setSearchOpen((v) => !v)}
            className="h-8 w-8 p-0"
          >
            <Search className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => setShowQuickKeys((v) => !v)}
            className="h-8 px-2 text-xs"
          >
            {showQuickKeys ? "إخفاء الرموز" : "رموز"}
          </Button>
        </div>
      </div>

      {searchOpen && (
        <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 bg-slate-50 px-3 py-2 dark:border-slate-800 dark:bg-slate-900">
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="بحث..."
            className="h-8 flex-1 text-sm"
          />
          <Input
            value={replaceWith}
            onChange={(e) => setReplaceWith(e.target.value)}
            placeholder="استبدال بـ..."
            className="h-8 flex-1 text-sm"
          />
          <Button size="sm" onClick={runSearch} className="h-8 bg-sky-600 hover:bg-sky-700">
            بحث
          </Button>
          <Button size="sm" variant="outline" onClick={runReplaceAll} className="h-8">
            استبدال الكل
          </Button>
          <Button size="sm" variant="ghost" onClick={() => setSearchOpen(false)} className="h-8 w-8 p-0">
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}

      <div className="relative flex min-h-0 flex-1 overflow-hidden bg-slate-950">
        {settings.showLineNumbers && (
          <div
            ref={gutterRef}
            className="shrink-0 select-none overflow-hidden border-e border-slate-800 bg-slate-900 py-3 text-end font-mono text-slate-600"
            style={{ fontSize: settings.fontSize, lineHeight: settings.lineHeight }}
          >
            {lines.map((_, i) => (
              <div key={i} className="px-3">
                {i + 1}
              </div>
            ))}
          </div>
        )}

        <div className="relative min-w-0 flex-1">
          <pre
            ref={highlightRef}
            aria-hidden
            className={cn(
              "pointer-events-none absolute inset-0 overflow-auto whitespace-pre px-3 py-3 font-mono text-slate-200",
              settings.wordWrap && "whitespace-pre-wrap break-words"
            )}
            style={{ fontSize: settings.fontSize, lineHeight: settings.lineHeight }}
          >
            {lines.map((line, i) => (
              <div key={i}>
                {tokenizeLine(line, lang).map((t, j) => (
                  <span key={j} className={tokenClass(t.cls)}>
                    {t.text}
                  </span>
                ))}
                {"\n"}
              </div>
            ))}
          </pre>
          <textarea
            ref={textareaRef}
            value={content}
            onChange={handleChange}
            onKeyDown={handleKeyDown}
            onScroll={syncScroll}
            onClick={updateCursor}
            onKeyUp={updateCursor}
            spellCheck={false}
            autoCapitalize="off"
            autoCorrect="off"
            className={cn(
              "absolute inset-0 resize-none overflow-auto whitespace-pre bg-transparent px-3 py-3 font-mono text-transparent caret-sky-400 outline-none",
              settings.wordWrap && "whitespace-pre-wrap break-words"
            )}
            style={{ fontSize: settings.fontSize, lineHeight: settings.lineHeight }}
          />
        </div>
      </div>

      {showQuickKeys && (
        <div className="flex gap-1 overflow-x-auto border-t border-slate-800 bg-slate-900 px-2 py-2">
          {QUICK_KEYS.map((k) => (
            <button
              key={k}
              onClick={() => insertText(k)}
              className="h-9 min-w-9 shrink-0 rounded-md bg-slate-800 px-2 font-mono text-sm text-slate-200 active:bg-sky-600"
            >
              {k}
            </button>
          ))}
          <button
            onClick={() => insertText("\n")}
            className="h-9 shrink-0 rounded-md bg-slate-800 px-3 text-xs text-slate-200 active:bg-sky-600"
          >
            سطر
          </button>
        </div>
      )}
    </div>
  );
}