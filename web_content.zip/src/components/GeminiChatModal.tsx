import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Send,
  Sparkles,
  Globe,
  Mic,
  MicOff,
  Bot,
  User,
  Copy,
  Check,
  ExternalLink,
  BookOpen
} from 'lucide-react';
import { sound } from '../services/sound';

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  sources?: { title?: string; uri?: string }[];
  timestamp: string;
}

interface GeminiChatModalProps {
  onClose: () => void;
  targetExam?: string;
}

export const GeminiChatModal: React.FC<GeminiChatModalProps> = ({
  onClose,
  targetExam = 'Bangladesh Civil Service (BCS)',
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      content: `Hello, Aspirant! I am **Professor Cadre**, your dedicated Lexicographical Mentor for **${targetExam}** and competitive examinations.\n\nAsk me about tricky lookalikes, precise prepositions, authentic collocations, or request tailor-made examination drills!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputPrompt, setInputPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [useSearchGrounding, setUseSearchGrounding] = useState(true);
  const [isListening, setIsListening] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputPrompt).trim();
    if (!text || isLoading) return;

    const userMsg: ChatMessage = {
      id: 'usr_' + Date.now(),
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputPrompt('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...messages, userMsg].map(m => ({
            role: m.role,
            content: m.content
          })),
          useSearchGrounding,
          examTarget: targetExam
        }),
      });

      if (!response.ok) {
        throw new Error(`Server error: ${response.statusText}`);
      }

      const data = await response.json();
      const assistantMsg: ChatMessage = {
        id: 'ast_' + Date.now(),
        role: 'model',
        content: data.text || 'No response formulated.',
        sources: data.sources,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, assistantMsg]);
      sound.correct();
    } catch (err: unknown) {
      console.error('Chat error:', err);
      const errMsg: ChatMessage = {
        id: 'err_' + Date.now(),
        role: 'model',
        content: `Error: Unable to connect to Gemini API. Please make sure the dev server is running and check your connection.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errMsg]);
      sound.wrong();
    } finally {
      setIsLoading(false);
    }
  };

  // Web Speech API Voice Transcription
  const toggleSpeechRecognition = () => {
    if (typeof window === 'undefined') return;
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Speech recognition is not supported in this browser.');
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'en-US';
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onerror = () => setIsListening(false);

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputPrompt(prev => (prev ? `${prev} ${transcript}` : transcript));
      };

      recognition.start();
    } catch (e) {
      console.warn('Speech recognition error:', e);
      setIsListening(false);
    }
  };

  const handleCopyMessage = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const quickPrompts = [
    'Compare Callous vs Careless in BCS essays',
    'Quiz me on 3 high-yield vocabulary words',
    'Search recent editorial sentences using Abate',
    'Explain the root etymology of Abrogate'
  ];

  return (
    <div className="fixed inset-0 z-50 bg-[#f8faf7] dark:bg-[#090d16] flex flex-col overflow-hidden animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="bg-white/95 dark:bg-[#111827]/95 backdrop-blur-md border-b-2 border-slate-200 dark:border-slate-800 p-3.5 safe-top shrink-0 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-indigo-600 to-purple-600 text-white flex items-center justify-center font-black shadow-sm">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-sm text-slate-900 dark:text-white">
                Professor Cadre AI
              </span>
              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300">
                Gemini 3.8
              </span>
            </div>
            <p className="text-[10px] text-slate-400">
              Exam Mentor & Lexicographer &bull; {targetExam.split('(')[0]}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Google Search Grounding Toggle */}
          <button
            onClick={() => setUseSearchGrounding(!useSearchGrounding)}
            className={`px-2.5 py-1 rounded-xl text-xs font-bold flex items-center gap-1 transition-all ${
              useSearchGrounding
                ? 'bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 border border-blue-300 dark:border-blue-800'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
            }`}
            title="Toggle Google Search Grounding for current editorial sentences"
          >
            <Globe className="w-3.5 h-3.5" />
            <span className="text-[10px] hidden sm:inline">Google Search Grounding</span>
          </button>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-800 dark:hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Messages Thread Container */}
      <div className="flex-1 smooth-scroll p-4 space-y-4 max-w-2xl mx-auto w-full">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';

          return (
            <div
              key={msg.id}
              className={`flex items-start gap-2.5 ${isUser ? 'flex-row-reverse' : ''}`}
            >
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 font-bold text-xs ${
                  isUser
                    ? 'bg-emerald-600 text-white'
                    : 'bg-gradient-to-tr from-indigo-600 to-purple-600 text-white'
                }`}
              >
                {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div
                className={`max-w-[85%] rounded-3xl p-4 text-xs sm:text-sm leading-relaxed shadow-sm space-y-2 ${
                  isUser
                    ? 'bg-emerald-600 text-white rounded-tr-sm'
                    : 'bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 rounded-tl-sm'
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.content}</div>

                {/* Grounding Web Sources */}
                {msg.sources && msg.sources.length > 0 && (
                  <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1">
                    <span className="text-[10px] uppercase font-bold text-slate-400 flex items-center gap-1">
                      <Globe className="w-3 h-3 text-blue-500" /> Grounded Search Sources:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {msg.sources.map((src, sIdx) => (
                        <a
                          key={sIdx}
                          href={src.uri}
                          target="_blank"
                          rel="noreferrer"
                          className="text-[10px] bg-slate-50 dark:bg-slate-800 text-blue-600 dark:text-blue-400 hover:underline px-2 py-0.5 rounded-lg flex items-center gap-1 border border-slate-200 dark:border-slate-700"
                        >
                          <ExternalLink className="w-2.5 h-2.5" />
                          <span className="truncate max-w-[160px]">{src.title || 'Source'}</span>
                        </a>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                  <span>{msg.timestamp}</span>
                  {!isUser && (
                    <button
                      onClick={() => handleCopyMessage(msg.id, msg.content)}
                      className="hover:text-emerald-500 flex items-center gap-1 transition-colors"
                      title="Copy message"
                    >
                      {copiedId === msg.id ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-center gap-2 text-slate-400 text-xs italic p-2">
            <Sparkles className="w-4 h-4 animate-spin text-indigo-500" />
            <span>Professor Cadre is consulting lexicographical benchmarks...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Prompt Chips */}
      <div className="p-2 border-t border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-[#111827]/50 max-w-2xl mx-auto w-full">
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {quickPrompts.map((qText, i) => (
            <button
              key={i}
              onClick={() => handleSendMessage(qText)}
              className="text-[11px] px-3 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-emerald-950 text-slate-700 dark:text-slate-300 font-medium shrink-0 border border-slate-200 dark:border-slate-700 active:scale-95 transition-all"
            >
              {qText}
            </button>
          ))}
        </div>
      </div>

      {/* Input Bar */}
      <div className="p-3 bg-white dark:bg-[#111827] border-t border-slate-200 dark:border-slate-800 safe-bottom shrink-0 max-w-2xl mx-auto w-full">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center gap-2"
        >
          <button
            type="button"
            onClick={toggleSpeechRecognition}
            className={`p-3 rounded-2xl transition-all ${
              isListening
                ? 'bg-rose-600 text-white animate-pulse'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-emerald-500'
            }`}
            title={isListening ? 'Listening...' : 'Transcribe voice question'}
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          <input
            type="text"
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            placeholder="Ask Professor Cadre (e.g. usage of Callous in essays)..."
            className="flex-1 p-3 rounded-2xl bg-slate-100 dark:bg-slate-800 border-0 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm text-slate-900 dark:text-white"
          />

          <button
            type="submit"
            disabled={!inputPrompt.trim() || isLoading}
            className="p-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-2xl shadow-sm active:scale-95 transition-all"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>
      </div>

    </div>
  );
};
