import React, { useState } from 'react';
import {
  BarChart3,
  CheckCircle2,
  Clock,
  AlertTriangle,
  BookOpen,
  ArrowRight,
  TrendingUp,
  Brain,
  Sparkles,
  Award,
  Filter,
  X,
  Play,
  RotateCcw,
  Zap,
  Target
} from 'lucide-react';
import { WordData, UserProfile, UserProgressData, SrsRating } from '../types';
import { SrsEngine } from '../services/srs';
import { sound } from '../services/sound';

interface AnalyticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  words: WordData[];
  profile: UserProfile;
  progress: UserProgressData;
  onOpenWordDetail: (word: WordData) => void;
  onSetStatus: (word: string, status: 'mastered' | 'revise' | 'learn') => void;
  onOpenSrsDrill: () => void;
}

export type ReviewFilter = 'all' | 'critical' | 'due' | 'mistakes' | 'revise';

export const AnalyticsModal: React.FC<AnalyticsModalProps> = ({
  isOpen,
  onClose,
  words,
  profile,
  progress,
  onOpenWordDetail,
  onSetStatus,
  onOpenSrsDrill,
}) => {
  const [activeFilter, setActiveFilter] = useState<ReviewFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen) return null;

  const totalWords = words.length;
  const masteredCount = progress.mastered.length;
  const reviseCount = progress.revise.length;
  const learnCount = progress.learn.length;
  const remainingCount = Math.max(0, totalWords - masteredCount);
  const unseenCount = Math.max(0, totalWords - (masteredCount + reviseCount + learnCount));

  const masteredPercent = Math.min(100, Math.round((masteredCount / totalWords) * 100));
  const remainingPercent = Math.round((remainingCount / totalWords) * 100);

  // Spaced Repetition stats
  const srsSchedule = SrsEngine.getSrsSchedule(
    words,
    progress.srsRecords || {},
    progress.mastered,
    progress.revise,
    progress.learn
  );

  // Words that need review more
  interface ReviewItem {
    wordObj: WordData;
    reason: string;
    priority: number; // 1 = highest, 3 = lower
    category: 'critical' | 'due' | 'mistakes' | 'revise';
    retentionScore?: number;
    mistakeCount?: number;
  }

  const reviewMap = new Map<string, ReviewItem>();

  // 1. Critical decay (<50% retention)
  const allSrsItems = [...srsSchedule.dueWords, ...srsSchedule.upcomingWords];
  allSrsItems.forEach(item => {
    if (item.srs.retentionScore < 50) {
      reviewMap.set(item.word.toLowerCase(), {
        wordObj: item,
        reason: `Critical Memory Decay (${item.srs.retentionScore}% retention)`,
        priority: 1,
        category: 'critical',
        retentionScore: item.srs.retentionScore,
      });
    }
  });

  // 2. Overdue words
  srsSchedule.dueWords.forEach(item => {
    const key = item.word.toLowerCase();
    const existing = reviewMap.get(key);
    if (!existing) {
      reviewMap.set(key, {
        wordObj: item,
        reason: `Spaced Repetition Overdue (Stage ${item.srs.stage})`,
        priority: 1,
        category: 'due',
        retentionScore: item.srs.retentionScore,
      });
    }
  });

  // 3. Mistakes Vault words
  progress.mistakesVault.forEach(m => {
    const key = m.word.toLowerCase();
    const existing = reviewMap.get(key);
    const wordObj = words.find(w => w.word.toLowerCase() === key);
    if (wordObj) {
      if (existing) {
        existing.reason += ` • Missed in Diagnostic Quiz (${m.category})`;
        existing.priority = 1;
        existing.category = 'mistakes';
      } else {
        reviewMap.set(key, {
          wordObj,
          reason: `Missed in Diagnostic Quiz (${m.category})`,
          priority: 2,
          category: 'mistakes',
        });
      }
    }
  });

  // 4. Group B (Revise) words
  progress.revise.forEach(w => {
    const key = w.toLowerCase();
    if (!reviewMap.has(key)) {
      const wordObj = words.find(item => item.word.toLowerCase() === key);
      if (wordObj) {
        reviewMap.set(key, {
          wordObj,
          reason: 'Categorized in Group B (Revise)',
          priority: 3,
          category: 'revise',
        });
      }
    }
  });

  // 5. Default words in learning with low fluency
  if (reviewMap.size === 0) {
    progress.learn.slice(0, 5).forEach(w => {
      const wordObj = words.find(item => item.word.toLowerCase() === w.toLowerCase());
      if (wordObj) {
        reviewMap.set(w.toLowerCase(), {
          wordObj,
          reason: 'Recently added to Group C (Learn)',
          priority: 3,
          category: 'revise',
        });
      }
    });
  }

  const allReviewItems = Array.from(reviewMap.values()).sort((a, b) => a.priority - b.priority);

  const filteredReviewItems = allReviewItems.filter(item => {
    if (activeFilter !== 'all' && item.category !== activeFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        item.wordObj.word.toLowerCase().includes(q) ||
        item.wordObj.bengali.toLowerCase().includes(q)
      );
    }
    return true;
  });

  // Parts of Speech Breakdown
  const posStats = ['noun', 'verb', 'adjective', 'adverb'].map(pos => {
    const totalPosWords = words.filter(w => w.pos.toLowerCase() === pos);
    const masteredPosWords = totalPosWords.filter(w =>
      progress.mastered.some(m => m.toLowerCase() === w.word.toLowerCase())
    );
    const pct = totalPosWords.length > 0
      ? Math.round((masteredPosWords.length / totalPosWords.length) * 100)
      : 0;
    return {
      pos: pos.charAt(0).toUpperCase() + pos.slice(1),
      total: totalPosWords.length,
      mastered: masteredPosWords.length,
      pct,
    };
  });

  // BCS Exam Vocabulary Score Projection (Out of 20 marks in BCS Prelims English Language)
  const projectedBcsMarks = (masteredPercent * 0.18 + (srsSchedule.stats.averageRetention * 0.02)).toFixed(1);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden text-slate-800 dark:text-slate-100"
        role="dialog"
        aria-modal="true"
        aria-labelledby="analytics-modal-title"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/80 dark:bg-slate-800/40">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-md shadow-indigo-600/30">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <h2 id="analytics-modal-title" className="text-base sm:text-lg font-black tracking-tight text-slate-900 dark:text-white flex items-center gap-1.5">
                Lexicon Mastery & Review Analytics
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                Cognitive progress analysis for {profile.targetExam}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800 transition-all"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 smooth-scroll">
          
          {/* Top 3 KPI Grid: Mastered, Remaining, Review More */}
          <div className="grid grid-cols-3 gap-2 sm:gap-3">
            
            {/* 1. Total Mastered Words */}
            <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 rounded-2xl p-3 sm:p-3.5 text-center flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-emerald-800 dark:text-emerald-300 block">
                  Mastered Words
                </span>
                <div className="text-2xl sm:text-3xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
                  {masteredCount}
                </div>
              </div>
              <div className="mt-1">
                <span className="text-[10px] font-bold text-emerald-700/80 dark:text-emerald-300/80 bg-emerald-100/70 dark:bg-emerald-900/60 px-1.5 py-0.5 rounded-md">
                  {masteredPercent}% of syllabus
                </span>
              </div>
            </div>

            {/* 2. Remaining Words */}
            <div className="bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/60 rounded-2xl p-3 sm:p-3.5 text-center flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-blue-800 dark:text-blue-300 block">
                  Remaining Words
                </span>
                <div className="text-2xl sm:text-3xl font-black text-blue-600 dark:text-blue-400 mt-1">
                  {remainingCount}
                </div>
              </div>
              <div className="mt-1">
                <span className="text-[10px] font-bold text-blue-700/80 dark:text-blue-300/80 bg-blue-100/70 dark:bg-blue-900/60 px-1.5 py-0.5 rounded-md">
                  {remainingPercent}% left to go
                </span>
              </div>
            </div>

            {/* 3. Words to Review More */}
            <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 rounded-2xl p-3 sm:p-3.5 text-center flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-amber-800 dark:text-amber-300 block">
                  Review Queue
                </span>
                <div className="text-2xl sm:text-3xl font-black text-amber-600 dark:text-amber-400 mt-1">
                  {allReviewItems.length}
                </div>
              </div>
              <div className="mt-1">
                <span className="text-[10px] font-bold text-amber-700/80 dark:text-amber-300/80 bg-amber-100/70 dark:bg-amber-900/60 px-1.5 py-0.5 rounded-md">
                  Needs Attention
                </span>
              </div>
            </div>

          </div>

          {/* Detailed Progress Bar & Lexicon Pipeline */}
          <div className="bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
              <span className="flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-emerald-500" />
                Lexicon Learning Pipeline ({totalWords} High-Yield Words)
              </span>
              <span className="text-emerald-600 dark:text-emerald-400 font-mono">
                {masteredCount}/{totalWords} Words
              </span>
            </div>

            {/* Multi-Segmented Progress Bar */}
            <div className="w-full h-3 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden flex">
              <div
                style={{ width: `${(masteredCount / totalWords) * 100}%` }}
                className="bg-emerald-500 h-full transition-all"
                title={`Mastered: ${masteredCount} words`}
              />
              <div
                style={{ width: `${(reviseCount / totalWords) * 100}%` }}
                className="bg-amber-500 h-full transition-all"
                title={`Revise (Group B): ${reviseCount} words`}
              />
              <div
                style={{ width: `${(learnCount / totalWords) * 100}%` }}
                className="bg-rose-500 h-full transition-all"
                title={`Learning (Group C): ${learnCount} words`}
              />
            </div>

            {/* Segment Legend */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-[11px] font-bold">
              <div className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" />
                <span>Mastered: {masteredCount}</span>
              </div>
              <div className="flex items-center gap-1.5 text-amber-600 dark:text-amber-400">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shrink-0" />
                <span>Revise (B): {reviseCount}</span>
              </div>
              <div className="flex items-center gap-1.5 text-rose-600 dark:text-rose-400">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shrink-0" />
                <span>Learning (C): {learnCount}</span>
              </div>
              <div className="flex items-center gap-1.5 text-slate-400 dark:text-slate-500">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-400 shrink-0" />
                <span>Unseen: {unseenCount}</span>
              </div>
            </div>
          </div>

          {/* Examination Projection & Ebbinghaus Retention Index */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            
            <div className="p-3.5 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/60">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[10px] font-black uppercase tracking-wider text-indigo-700 dark:text-indigo-300 flex items-center gap-1">
                  <Brain className="w-3.5 h-3.5" /> Ebbinghaus Retention Health
                </span>
                <span className="text-xs font-black text-indigo-600 dark:text-indigo-400">
                  {srsSchedule.stats.averageRetention}%
                </span>
              </div>
              <div className="text-[11px] text-slate-600 dark:text-slate-300 leading-snug font-bengali">
                {srsSchedule.stats.averageRetention >= 80
                  ? 'স্মৃতিরেখা দৃঢ় ও স্থায়ী। দীর্ঘমেয়াদী ধারণক্ষমতা অত্যন্ত শক্তিশালী।'
                  : 'কিছু শব্দ দ্রুত ভুলে যাওয়ার ঝুঁকিতে রয়েছে। দৈনিক ড্রিল সম্পন্ন করুন।'}
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-teal-50/70 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800/60">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[10px] font-black uppercase tracking-wider text-teal-800 dark:text-teal-300 flex items-center gap-1">
                  <Target className="w-3.5 h-3.5" /> BCS Prelims Projected Score
                </span>
                <span className="text-xs font-black text-teal-600 dark:text-teal-400">
                  {projectedBcsMarks} / 20.0
                </span>
              </div>
              <div className="text-[11px] text-slate-600 dark:text-slate-300 leading-snug font-bengali">
                ভোকাবুলারি অংশে প্রক্ষেপিত নম্বর। নির্ভুলতা বাড়াতে দুর্বল শব্দগুলো সংশোধন করুন।
              </div>
            </div>

          </div>

          {/* Parts of Speech Mastery Breakdown */}
          <div className="space-y-2">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              Parts of Speech Distribution
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {posStats.map((item, idx) => (
                <div
                  key={idx}
                  className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 rounded-xl p-2.5 text-center"
                >
                  <div className="text-[11px] font-extrabold text-slate-700 dark:text-slate-300">
                    {item.pos}
                  </div>
                  <div className="text-base font-black text-slate-900 dark:text-white my-0.5">
                    {item.mastered} / {item.total}
                  </div>
                  <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden mt-1">
                    <div
                      className="bg-emerald-500 h-full rounded-full"
                      style={{ width: `${item.pct}%` }}
                    />
                  </div>
                  <span className="text-[9px] font-bold text-slate-400 mt-1 block">
                    {item.pct}% Mastered
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Section: Which Words to Review More */}
          <div className="space-y-3 pt-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-500" />
                  Which Words to Review More ({allReviewItems.length} Words)
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Prioritized by forgetting curve decay and diagnostic test mistakes
                </p>
              </div>

              {allReviewItems.length > 0 && (
                <button
                  onClick={() => {
                    onClose();
                    onOpenSrsDrill();
                  }}
                  className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-extrabold text-xs shadow-md shadow-indigo-600/20 hover:from-indigo-500 hover:to-purple-500 active:scale-95 transition-all inline-flex items-center gap-1.5 self-start sm:self-auto"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Start Review Drill</span>
                </button>
              )}
            </div>

            {/* Filter pills & Search input */}
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                onClick={() => setActiveFilter('all')}
                className={`text-[10px] font-extrabold px-2.5 py-1 rounded-lg transition-all ${
                  activeFilter === 'all'
                    ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-sm'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                All ({allReviewItems.length})
              </button>
              <button
                onClick={() => setActiveFilter('critical')}
                className={`text-[10px] font-extrabold px-2.5 py-1 rounded-lg transition-all ${
                  activeFilter === 'critical'
                    ? 'bg-rose-600 text-white shadow-sm'
                    : 'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300'
                }`}
              >
                Critical Decay
              </button>
              <button
                onClick={() => setActiveFilter('due')}
                className={`text-[10px] font-extrabold px-2.5 py-1 rounded-lg transition-all ${
                  activeFilter === 'due'
                    ? 'bg-amber-600 text-white shadow-sm'
                    : 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300'
                }`}
              >
                Overdue
              </button>
              <button
                onClick={() => setActiveFilter('mistakes')}
                className={`text-[10px] font-extrabold px-2.5 py-1 rounded-lg transition-all ${
                  activeFilter === 'mistakes'
                    ? 'bg-purple-600 text-white shadow-sm'
                    : 'bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300'
                }`}
              >
                Mistakes Vault
              </button>
              <button
                onClick={() => setActiveFilter('revise')}
                className={`text-[10px] font-extrabold px-2.5 py-1 rounded-lg transition-all ${
                  activeFilter === 'revise'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300'
                }`}
              >
                Group B (Revise)
              </button>
            </div>

            {/* List of Words to Review More */}
            <div className="space-y-2 max-h-72 overflow-y-auto pr-1 smooth-scroll">
              {filteredReviewItems.length > 0 ? (
                filteredReviewItems.map((item, idx) => {
                  const w = item.wordObj;
                  return (
                    <div
                      key={idx}
                      className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 hover:border-indigo-400 dark:hover:border-indigo-500 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-2.5"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-black text-sm text-slate-900 dark:text-white">
                            {w.word}
                          </span>
                          <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 capitalize font-medium">
                            {w.pos}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {w.ipa}
                          </span>
                        </div>

                        <div className="text-xs text-slate-600 dark:text-slate-300 font-bengali">
                          {w.bengali}
                        </div>

                        {/* Priority / Diagnostic Reason Badge */}
                        <div className="flex items-center gap-1.5">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full inline-flex items-center gap-1 ${
                            item.category === 'critical'
                              ? 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 border border-rose-300 dark:border-rose-800'
                              : item.category === 'mistakes'
                              ? 'bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 border border-purple-300 dark:border-purple-800'
                              : item.category === 'due'
                              ? 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border border-amber-300 dark:border-amber-800'
                              : 'bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 border border-blue-300 dark:border-blue-800'
                          }`}>
                            {item.reason}
                          </span>
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-1.5 self-end sm:self-center shrink-0">
                        <button
                          onClick={() => {
                            onClose();
                            onOpenWordDetail(w);
                          }}
                          className="px-2.5 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-300 text-xs font-bold inline-flex items-center gap-1 transition-all"
                          title="Open 17-Section Master Dossier"
                        >
                          <BookOpen className="w-3 h-3" />
                          <span>Dossier</span>
                        </button>

                        <button
                          onClick={() => {
                            onSetStatus(w.word, 'mastered');
                            sound.correct();
                            sound.triggerFloatingXp(15);
                          }}
                          className="px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold inline-flex items-center gap-1 transition-all shadow-sm"
                          title="Mark as Group A (Mastered)"
                        >
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Mastered</span>
                        </button>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="p-6 text-center text-slate-400 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800">
                  <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-1" />
                  <div className="text-xs font-black text-slate-700 dark:text-slate-200">
                    No Words in this Category!
                  </div>
                  <p className="text-[11px] text-slate-500 font-bengali mt-0.5">
                    আপনার এই ফিল্টারে কোনো দুর্বল শব্দ নেই। চমৎকার অগ্রগতি!
                  </p>
                </div>
              )}
            </div>

          </div>

        </div>

        {/* Footer */}
        <div className="p-3.5 sm:p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/40 flex items-center justify-between">
          <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">
            Mastered: <strong className="text-emerald-600 dark:text-emerald-400">{masteredCount}</strong> | Remaining: <strong className="text-blue-600 dark:text-blue-400">{remainingCount}</strong>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-900 text-white dark:bg-white dark:text-slate-900 font-extrabold text-xs hover:opacity-90 active:scale-95 transition-all"
          >
            Close Analytics
          </button>
        </div>

      </div>
    </div>
  );
};
