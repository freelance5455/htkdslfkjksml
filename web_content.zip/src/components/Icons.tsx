import type { ReactNode } from "react";

const base = {
  width: 22,
  height: 22,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.8,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
};

function I({ children, size = 22, fill }: { children: ReactNode; size?: number; fill?: boolean }) {
  return (
    <svg {...base} width={size} height={size} fill={fill ? "currentColor" : "none"} aria-hidden="true">
      {children}
    </svg>
  );
}

export const HomeIcon = () => (
  <I>
    <path d="M3 11l9-8 9 8" />
    <path d="M5 10v10h14V10" />
    <path d="M10 20v-6h4v6" />
  </I>
);
export const SearchIcon = ({ size }: { size?: number }) => (
  <I size={size}>
    <circle cx="11" cy="11" r="7" />
    <path d="M21 21l-4.3-4.3" />
  </I>
);
export const GridIcon = () => (
  <I>
    <rect x="3" y="3" width="7" height="7" rx="1.5" />
    <rect x="14" y="3" width="7" height="7" rx="1.5" />
    <rect x="3" y="14" width="7" height="7" rx="1.5" />
    <rect x="14" y="14" width="7" height="7" rx="1.5" />
  </I>
);
export const HeartIcon = ({ filled, size }: { filled?: boolean; size?: number }) => (
  <I size={size} fill={filled}>
    <path d="M12 21s-7-4.4-9.3-9A5.3 5.3 0 0112 6.6 5.3 5.3 0 0121.3 12C19 16.6 12 21 12 21z" />
  </I>
);
export const InfoIcon = () => (
  <I>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 11v5M12 8h.01" />
  </I>
);
export const CopyIcon = () => (
  <I size={18}>
    <rect x="9" y="9" width="11" height="11" rx="2" />
    <path d="M5 15V6a2 2 0 012-2h9" />
  </I>
);
export const ShareIcon = () => (
  <I size={18}>
    <circle cx="18" cy="5" r="2.5" />
    <circle cx="6" cy="12" r="2.5" />
    <circle cx="18" cy="19" r="2.5" />
    <path d="M8.2 10.8l7.6-4.4M8.2 13.2l7.6 4.4" />
  </I>
);
export const BackIcon = () => (
  <I>
    <path d="M9 6l6 6-6 6" />
  </I>
);
export const CloseIcon = () => (
  <I size={18}>
    <path d="M6 6l12 12M18 6L6 18" />
  </I>
);
export const ChevronDown = ({ open }: { open?: boolean }) => (
  <svg {...base} width={18} height={18} style={{ transform: open ? "rotate(180deg)" : undefined, transition: "transform .2s" }}>
    <path d="M6 9l6 6 6-6" />
  </svg>
);
export const CheckIcon = () => (
  <I size={16}>
    <path d="M5 12l5 5 9-10" />
  </I>
);
export const MoonIcon = () => (
  <I size={20}>
    <path d="M21 13A9 9 0 1111 3a7 7 0 0010 10z" />
  </I>
);
export const SunIcon = () => (
  <I size={20}>
    <circle cx="12" cy="12" r="4" />
    <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
  </I>
);
