import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement> & { size?: number };

function base({ size = 22, ...rest }: P) {
  return {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.7,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    ...rest,
  };
}

export const IconLogo = ({ size = 34, ...r }: P) => (
  <svg {...base({ size, strokeWidth: 1.5, ...r })}>
    <path d="M5 3.5h9.5L19 8v6.2" />
    <path d="M5 3.5V18a2.5 2.5 0 0 0 2.5 2.5H12" />
    <path d="M7.8 7.2h6.4M7.8 10h6.4M7.8 12.8h4" />
    <circle cx="15.6" cy="16.2" r="4.4" strokeWidth={1.9} />
    <path d="m19 19.6 2.3 2.3" strokeWidth={2.2} />
  </svg>
);

export const IconChevronRight = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, ...r })}>
    <path d="m9 5 7 7-7 7" />
  </svg>
);

export const IconChevronLeft = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, ...r })}>
    <path d="m15 5-7 7 7 7" />
  </svg>
);

export const IconGear = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, ...r })}>
    <circle cx="12" cy="12" r="3.1" />
    <path d="M19.6 14.2a1.5 1.5 0 0 0 .3 1.65l.05.05a1.8 1.8 0 1 1-2.55 2.55l-.05-.05a1.5 1.5 0 0 0-1.65-.3 1.5 1.5 0 0 0-.9 1.37V20a1.8 1.8 0 1 1-3.6 0v-.1a1.5 1.5 0 0 0-.98-1.37 1.5 1.5 0 0 0-1.65.3l-.05.05A1.8 1.8 0 1 1 3.97 16.3l.05-.05a1.5 1.5 0 0 0 .3-1.65 1.5 1.5 0 0 0-1.37-.9H3a1.8 1.8 0 1 1 0-3.6h.1a1.5 1.5 0 0 0 1.37-.98 1.5 1.5 0 0 0-.3-1.65l-.05-.05A1.8 1.8 0 1 1 6.67 4.87l.05.05a1.5 1.5 0 0 0 1.65.3h.07a1.5 1.5 0 0 0 .9-1.37V3.8a1.8 1.8 0 1 1 3.6 0v.1a1.5 1.5 0 0 0 .9 1.37 1.5 1.5 0 0 0 1.65-.3l.05-.05a1.8 1.8 0 1 1 2.55 2.55l-.05.05a1.5 1.5 0 0 0-.3 1.65v.07a1.5 1.5 0 0 0 1.37.9h.15a1.8 1.8 0 1 1 0 3.6h-.1a1.5 1.5 0 0 0-1.37.9Z" />
  </svg>
);

export const IconBookmark = ({ size = 22, filled = false, ...r }: P & { filled?: boolean }) => (
  <svg {...base({ size, ...r })} fill={filled ? "currentColor" : "none"}>
    <path d="M6.5 3.8h11a1 1 0 0 1 1 1v15.4l-6.5-4-6.5 4V4.8a1 1 0 0 1 1-1Z" />
  </svg>
);

export const IconToc = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, ...r })}>
    <path d="M4 6h11M4 12h16M4 18h8" />
    <circle cx="19" cy="6" r="1.4" fill="currentColor" stroke="none" />
  </svg>
);

export const IconPlus = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, strokeWidth: 2, ...r })}>
    <path d="M12 5v14M5 12h14" />
  </svg>
);

export const IconTrash = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, ...r })}>
    <path d="M4.5 6.5h15M9.5 6.5V4.8a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v1.7" />
    <path d="M6.8 6.5 7.7 19a1.4 1.4 0 0 0 1.4 1.3h5.8A1.4 1.4 0 0 0 16.3 19l.9-12.5" />
    <path d="M10.4 10v6.4M13.6 10v6.4" />
  </svg>
);

export const IconClose = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, strokeWidth: 1.9, ...r })}>
    <path d="m6 6 12 12M18 6 6 18" />
  </svg>
);

export const IconCheck = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, strokeWidth: 2.1, ...r })}>
    <path d="m4.5 12.5 5 5 10-11" />
  </svg>
);

export const IconSun = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, ...r })}>
    <circle cx="12" cy="12" r="4" />
    <path d="M12 2.6v2.2M12 19.2v2.2M4.3 4.3l1.6 1.6M18.1 18.1l1.6 1.6M2.6 12h2.2M19.2 12h2.2M4.3 19.7l1.6-1.6M18.1 5.9l1.6-1.6" />
  </svg>
);

export const IconMoon = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, ...r })}>
    <path d="M20 14.4A8.4 8.4 0 0 1 9.2 3.9a8.5 8.5 0 1 0 10.8 10.5Z" />
  </svg>
);

export const IconLeaf = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, ...r })}>
    <path d="M4 20c0-8 5.2-13.4 16-13.6C20.4 16.6 15 21 4 20Z" />
    <path d="M9.6 15.4c2.2-2.6 4.8-4.3 7.6-5.3" />
  </svg>
);

export const IconGrid = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, ...r })}>
    <rect x="4" y="4" width="16" height="16" rx="2.2" />
    <path d="M12 4v16M4 12h16" />
  </svg>
);

export const IconRows = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, ...r })}>
    <rect x="4" y="3.6" width="16" height="16.8" rx="2.2" />
    <path d="M4 9.2h16M4 14.8h16" />
  </svg>
);

export const IconSwipe = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, ...r })}>
    <path d="M8.4 11.6V6.4a1.7 1.7 0 1 1 3.4 0v5" />
    <path d="M11.8 11.2v-1a1.6 1.6 0 0 1 3.2 0v1.2M15 11.4a1.6 1.6 0 0 1 3.2 0v3.1a5.6 5.6 0 0 1-5.6 5.6h-1.4a5 5 0 0 1-4-2l-3-4a1.7 1.7 0 0 1 2.5-2.2l1.7 1.9" />
    <path d="M3.2 8.4 1.6 10l1.6 1.6M20.8 8.4 22.4 10l-1.6 1.6" opacity=".55" />
  </svg>
);

export const IconBook = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, ...r })}>
    <path d="M4 4.6a1.6 1.6 0 0 1 1.6-1.6H11a2.4 2.4 0 0 1 2.4 2.4V20a2 2 0 0 0-2-2H5.6A1.6 1.6 0 0 1 4 16.4Z" />
    <path d="M20 4.6a1.6 1.6 0 0 0-1.6-1.6H15" />
    <path d="M20 4.6v11.8a1.6 1.6 0 0 1-1.6 1.6H13.4" />
  </svg>
);

export const IconContrast = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, ...r })}>
    <circle cx="12" cy="12" r="8.6" />
    <path d="M12 3.4a8.6 8.6 0 0 1 0 17.2Z" fill="currentColor" stroke="none" />
  </svg>
);

export const IconSearch = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, ...r })}>
    <circle cx="11" cy="11" r="6.4" />
    <path d="m16 16 4.4 4.4" />
  </svg>
);

export const IconReset = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, ...r })}>
    <path d="M4.2 10.4a8 8 0 1 1-.5 4.2" />
    <path d="M3.2 4.6v5.2h5.2" />
  </svg>
);

export const IconLayers = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, ...r })}>
    <path d="m12 3.4 8.4 4.3-8.4 4.3-8.4-4.3Z" />
    <path d="m4.4 12 7.6 3.9 7.6-3.9M4.4 16.2l7.6 3.9 7.6-3.9" opacity=".6" />
  </svg>
);

export const IconInfo = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, ...r })}>
    <circle cx="12" cy="12" r="8.6" />
    <path d="M12 11v5.2" />
    <circle cx="12" cy="7.9" r="1.05" fill="currentColor" stroke="none" />
  </svg>
);

export const IconDownload = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, ...r })}>
    <path d="M12 3.6v10.8M8 10.8l4 3.8 4-3.8" />
    <path d="M4.4 17.2v1.6a1.8 1.8 0 0 0 1.8 1.8h11.6a1.8 1.8 0 0 0 1.8-1.8v-1.6" />
  </svg>
);

export const IconScan = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, ...r })}>
    <path d="M4 8V5.6A1.6 1.6 0 0 1 5.6 4H8M16 4h2.4A1.6 1.6 0 0 1 20 5.6V8M20 16v2.4a1.6 1.6 0 0 1-1.6 1.6H16M8 20H5.6A1.6 1.6 0 0 1 4 18.4V16" />
    <path d="M3.5 12h17" strokeWidth={2} />
    <path d="M8 8.4h8M8 15.6h5" opacity=".55" />
  </svg>
);

export const IconFullscreen = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, ...r })}>
    <path d="M8.5 4H5.6A1.6 1.6 0 0 0 4 5.6v2.9M15.5 4h2.9A1.6 1.6 0 0 1 20 5.6v2.9M20 15.5v2.9a1.6 1.6 0 0 1-1.6 1.6h-2.9M8.5 20H5.6A1.6 1.6 0 0 1 4 18.4v-2.9" />
  </svg>
);

export const IconFullscreenExit = ({ size = 22, ...r }: P) => (
  <svg {...base({ size, ...r })}>
    <path d="M8.5 4v2.9A1.6 1.6 0 0 1 6.9 8.5H4M15.5 4v2.9a1.6 1.6 0 0 0 1.6 1.6H20M20 15.5h-2.9a1.6 1.6 0 0 0-1.6 1.6V20M4 15.5h2.9a1.6 1.6 0 0 1 1.6 1.6V20" />
  </svg>
);
