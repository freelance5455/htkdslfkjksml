import type { WeaponType } from '../game/weapons';

const SIL: Record<WeaponType, string> = {
  rifle: 'M2 11 h58 v-4 h6 v4 h30 v4 h-30 v2 h-12 l5 11 h-8 l-6 -11 h-6 l-2 7 h-7 l1 -7 h-18 l-9 7 h-4 l2 -9 z',
  smg: 'M10 10 h50 v-3 h5 v3 h20 v4 h-20 v2 h-8 l2 12 h-7 l-3 -12 h-6 l-2 8 h-7 l2 -8 h-10 l-8 5 h-4 l2 -7 z',
  sniper: 'M0 12 h40 v-6 h26 v6 h32 v3 h-32 v2 h-16 l-3 8 h-7 l2 -8 h-8 l-3 6 h-6 l1 -6 h-6 l-14 6 h-3 l3 -8 z M44 4 h20 v2 h-20 z',
  shotgun: 'M2 12 h40 v-2 h56 v4 h-30 v3 h-14 v-1 h-12 l-3 7 h-7 l2 -8 h-14 l-12 6 h-4 l3 -8 z',
  lmg: 'M2 10 h56 v-4 h8 v4 h30 v5 h-30 v3 h-10 v9 h-16 v-9 h-4 l-3 8 h-7 l2 -8 h-10 l-9 7 h-4 l2 -10 z',
  pistol: 'M30 8 h44 v8 h-30 v2 h-4 l-1 3 h-5 l-4 10 h-10 l5 -14 h-0 z',
  knife: 'M20 16 h22 v-4 h6 c18 0 34 -6 46 -10 c-8 12 -26 18 -46 18 h-6 v-4 h-22 z',
  grenade: 'M40 6 h10 v4 h4 l6 -4 l2 2 l-6 5 c6 3 8 8 8 12 c0 6 -6 10 -14 10 c-8 0 -14 -4 -14 -10 c0 -6 4 -10 8 -12 v-3 h-4 z',
};

export function GunSil({ type, className = '', color = 'currentColor' }: { type: WeaponType; className?: string; color?: string }) {
  return (
    <svg viewBox="0 0 100 32" className={className} fill={color}>
      <path d={SIL[type]} />
    </svg>
  );
}

export const Ico = {
  fire: (c = 'currentColor') => (
    <svg viewBox="0 0 48 48" className="w-full h-full" fill="none" stroke={c} strokeWidth="3">
      <circle cx="24" cy="24" r="14" /><circle cx="24" cy="24" r="3" fill={c} />
      <path d="M24 4v10M24 34v10M4 24h10M34 24h10" />
    </svg>
  ),
  scope: () => (
    <svg viewBox="0 0 48 48" className="w-full h-full" fill="none" stroke="currentColor" strokeWidth="3">
      <circle cx="24" cy="24" r="16" /><path d="M24 8v32M8 24h32" strokeWidth="2" />
    </svg>
  ),
  reload: () => (
    <svg viewBox="0 0 48 48" className="w-full h-full" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round">
      <path d="M38 24a14 14 0 1 1-4-10" /><path d="M36 6v9h-9" />
    </svg>
  ),
  jump: () => (
    <svg viewBox="0 0 48 48" className="w-full h-full" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 28l12-12 12 12" /><path d="M12 38l12-12 12 12" opacity=".5" />
    </svg>
  ),
  crouch: () => (
    <svg viewBox="0 0 48 48" className="w-full h-full" fill="currentColor">
      <circle cx="26" cy="10" r="5" /><path d="M20 17h10l3 12-6 2 4 11h-6l-4-10-6 1-3 9h-6l4-13 8-2z" />
    </svg>
  ),
  grenade: () => (
    <svg viewBox="0 0 48 48" className="w-full h-full" fill="currentColor">
      <path d="M20 6h8v5h3l5-4 2 2-5 5c5 3 7 8 7 13 0 8-7 14-16 14S8 35 8 27c0-7 5-12 12-14z" />
    </svg>
  ),
  cart: () => (
    <svg viewBox="0 0 48 48" className="w-full h-full" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinejoin="round">
      <path d="M4 8h7l5 22h22l4-15H14" /><circle cx="19" cy="38" r="3" fill="currentColor" /><circle cx="35" cy="38" r="3" fill="currentColor" />
    </svg>
  ),
  menu: () => (
    <svg viewBox="0 0 48 48" className="w-full h-full" fill="currentColor"><rect x="8" y="11" width="32" height="4" rx="2" /><rect x="8" y="22" width="32" height="4" rx="2" /><rect x="8" y="33" width="32" height="4" rx="2" /></svg>
  ),
  list: () => (
    <svg viewBox="0 0 48 48" className="w-full h-full" fill="currentColor"><rect x="16" y="10" width="26" height="4" rx="2" /><rect x="16" y="22" width="26" height="4" rx="2" /><rect x="16" y="34" width="26" height="4" rx="2" /><circle cx="9" cy="12" r="3" /><circle cx="9" cy="24" r="3" /><circle cx="9" cy="36" r="3" /></svg>
  ),
  heart: () => (<svg viewBox="0 0 24 24" className="w-full h-full" fill="currentColor"><path d="M12 21s-8-5-8-11a4.5 4.5 0 0 1 8-3 4.5 4.5 0 0 1 8 3c0 6-8 11-8 11z" /></svg>),
  shield: () => (<svg viewBox="0 0 24 24" className="w-full h-full" fill="currentColor"><path d="M12 2l8 3v6c0 5-3.5 9-8 11-4.5-2-8-6-8-11V5z" /></svg>),
  skull: () => (<svg viewBox="0 0 24 24" className="w-full h-full" fill="currentColor"><path d="M12 2C7 2 4 5.5 4 10c0 3 1.5 5 3 6v3h2v-2h2v2h2v-2h2v2h2v-3c1.5-1 3-3 3-6 0-4.5-3-8-8-8zM8.5 13a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm7 0a2 2 0 1 1 0-4 2 2 0 0 1 0 4z" /></svg>),
  lock: () => (<svg viewBox="0 0 24 24" className="w-full h-full" fill="currentColor"><path d="M6 10V8a6 6 0 1 1 12 0v2h1v12H5V10zm2 0h8V8a4 4 0 1 0-8 0z" /></svg>),
  coin: () => (<svg viewBox="0 0 24 24" className="w-full h-full"><circle cx="12" cy="12" r="10" fill="#f5c518" stroke="#a87800" strokeWidth="2" /><path d="M12 6v12M9 9h5a2 2 0 0 1 0 4h-4a2 2 0 0 0 0 4h5" stroke="#7a5600" strokeWidth="2" fill="none" /></svg>),
  rotate: () => (
    <svg viewBox="0 0 64 64" className="w-full h-full" fill="none" stroke="currentColor" strokeWidth="3">
      <rect x="20" y="6" width="24" height="44" rx="4" /><circle cx="32" cy="44" r="2" fill="currentColor" />
    </svg>
  ),
};
