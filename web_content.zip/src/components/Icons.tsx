import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement> & { size?: number };

const base = (p: P) => {
  const { size = 18, ...rest } = p;
  return {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.8,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    ...rest,
  };
};

export const IconLogo = ({ size = 28, ...rest }: P) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="none" {...rest}>
    <path d="M16 2 29 9.5v13L16 30 3 22.5v-13L16 2z" stroke="#FFB454" strokeWidth="2" />
    <path d="M11 10l5 6 5-6M16 16v8" stroke="#2FE6C8" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const IconCpu = (p: P) => (
  <svg {...base(p)}>
    <rect x="6" y="6" width="12" height="12" rx="1" />
    <rect x="10" y="10" width="4" height="4" />
    <path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3" />
  </svg>
);

export const IconDownload = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 3v11M7.5 10.5 12 15l4.5-4.5" />
    <path d="M4 17v3h16v-3" />
  </svg>
);

export const IconPlay = (p: P) => (
  <svg {...base(p)}>
    <path d="M7 4.5v15l12-7.5-12-7.5z" fill="currentColor" stroke="none" />
  </svg>
);

export const IconMic = (p: P) => (
  <svg {...base(p)}>
    <rect x="9" y="3" width="6" height="11" rx="3" />
    <path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3M8.5 21h7" />
  </svg>
);

export const IconImage = (p: P) => (
  <svg {...base(p)}>
    <rect x="3.5" y="4.5" width="17" height="15" rx="1.5" />
    <circle cx="9" cy="10" r="1.7" />
    <path d="M4.5 17.5 10 12l4 4 2.5-2.5 3 3" />
  </svg>
);

export const IconFileCode = (p: P) => (
  <svg {...base(p)}>
    <path d="M6 3h8l4 4v14H6V3z" />
    <path d="M14 3v4h4" />
    <path d="m10.5 11-2 2.5 2 2.5M13.5 11l2 2.5-2 2.5" />
  </svg>
);

export const IconArchive = (p: P) => (
  <svg {...base(p)}>
    <rect x="3.5" y="4" width="17" height="5" />
    <path d="M5.5 9v11h13V9M10 13h4" />
  </svg>
);

export const IconTrash = (p: P) => (
  <svg {...base(p)}>
    <path d="M4.5 6.5h15M9.5 6V4h5v2M6.5 6.5 7.5 20h9l1-13.5M10 10.5v6M14 10.5v6" />
  </svg>
);

export const IconX = (p: P) => (
  <svg {...base(p)}>
    <path d="m6 6 12 12M18 6 6 18" />
  </svg>
);

export const IconCheck = (p: P) => (
  <svg {...base(p)}>
    <path d="m4.5 12.5 5 5 10-11" />
  </svg>
);

export const IconArrowRight = (p: P) => (
  <svg {...base(p)}>
    <path d="M4 12h15M13.5 6 19.5 12l-6 6" />
  </svg>
);

export const IconGithub = (p: P) => (
  <svg width={p.size ?? 18} height={p.size ?? 18} viewBox="0 0 24 24" fill="currentColor" {...{ className: p.className }}>
    <path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.11.79-.25.79-.55 0-.27-.01-1.17-.02-2.12-3.2.7-3.88-1.36-3.88-1.36-.52-1.33-1.28-1.68-1.28-1.68-1.04-.71.08-.7.08-.7 1.15.08 1.76 1.19 1.76 1.19 1.03 1.75 2.69 1.25 3.34.95.1-.74.4-1.25.72-1.54-2.55-.29-5.24-1.28-5.24-5.68 0-1.26.45-2.28 1.19-3.09-.12-.29-.52-1.46.11-3.05 0 0 .97-.31 3.17 1.18a11.04 11.04 0 0 1 5.78 0c2.2-1.49 3.17-1.18 3.17-1.18.63 1.59.23 2.76.11 3.05.74.81 1.19 1.83 1.19 3.09 0 4.41-2.7 5.38-5.26 5.67.41.35.77 1.05.77 2.12 0 1.53-.01 2.76-.01 3.14 0 .3.2.67.8.55A11.51 11.51 0 0 0 23.5 12C23.5 5.65 18.35.5 12 .5z" />
  </svg>
);

export const IconHf = ({ size = 18, className }: P) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle cx="12" cy="12" r="9.2" stroke="currentColor" strokeWidth="1.7" />
    <circle cx="8.6" cy="10.2" r="1.35" fill="currentColor" />
    <circle cx="15.4" cy="10.2" r="1.35" fill="currentColor" />
    <path d="M8.2 14.6c2.3 2 5.3 2 7.6 0" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
  </svg>
);

export const IconFlame = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 3s1 2.4 1 4.2c0 1.5-1 2.3-1 2.3s-3.5-1.6-3.5-5C6 6.5 7.5 9 7.5 12a4.5 4.5 0 0 0 9 0c0-4-2.5-7.5-4.5-9z" />
    <path d="M12 21a3.2 3.2 0 0 1-3.2-3.2c0-2 3.2-4.3 3.2-4.3s3.2 2.3 3.2 4.3A3.2 3.2 0 0 1 12 21z" />
  </svg>
);

export const IconGamepad = (p: P) => (
  <svg {...base(p)}>
    <path d="M7 8h10a4.5 4.5 0 0 1 4.4 5.6l-.7 2.9a2.6 2.6 0 0 1-4.6 1L14.6 16H9.4l-1.5 1.5a2.6 2.6 0 0 1-4.6-1l-.7-2.9A4.5 4.5 0 0 1 7 8z" />
    <path d="M8 11v3M6.5 12.5h3M15.5 11.5h.01M17.8 13.5h.01" />
  </svg>
);

export const IconWifiOff = (p: P) => (
  <svg {...base(p)}>
    <path d="M2 8.5C5 6 8.4 4.8 12 4.8c1.5 0 2.9.2 4.3.6M22 8.5a17 17 0 0 0-3.2-2M5 12a12 12 0 0 1 4.2-2.4M19 12a12 12 0 0 0-1.6-1.2M8.5 15.4a7 7 0 0 1 3-1.5M15.5 15.4c-.3-.2-.7-.4-1-.6" />
    <circle cx="12" cy="18.6" r="1.1" fill="currentColor" stroke="none" />
    <path d="M3.5 3.5l17 17" />
  </svg>
);

export const IconWifi = (p: P) => (
  <svg {...base(p)}>
    <path d="M2 8.5C8 3.5 16 3.5 22 8.5M5 12c4.4-3.6 9.6-3.6 14 0M8.5 15.4a5.6 5.6 0 0 1 7 0" />
    <circle cx="12" cy="18.6" r="1.1" fill="currentColor" stroke="none" />
  </svg>
);

export const IconVolume = (p: P) => (
  <svg {...base(p)}>
    <path d="M4 9.5v5h3.5L12 19V5L7.5 9.5H4z" />
    <path d="M15.5 9a4.3 4.3 0 0 1 0 6M18 6.6a8 8 0 0 1 0 10.8" />
  </svg>
);

export const IconSend = (p: P) => (
  <svg {...base(p)}>
    <path d="M4 11.5 20 4l-4.5 16-4-6.5L4 11.5z" />
    <path d="m11.5 13.5 4-4" />
  </svg>
);

export const IconTerminal = (p: P) => (
  <svg {...base(p)}>
    <rect x="3" y="4.5" width="18" height="15" rx="1.5" />
    <path d="m7 9.5 3 2.7-3 2.7M12.5 15h4.5" />
  </svg>
);

export const IconSearch = (p: P) => (
  <svg {...base(p)}>
    <circle cx="10.5" cy="10.5" r="6" />
    <path d="m15.2 15.2 5 5" />
  </svg>
);

export const IconSpark = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M18.4 5.6l-2.8 2.8M8.4 15.6l-2.8 2.8" />
  </svg>
);

export const IconFolder = (p: P) => (
  <svg {...base(p)}>
    <path d="M3.5 6.5v12h17v-9.5H12l-2-2.5H3.5z" />
  </svg>
);

export const IconEye = (p: P) => (
  <svg {...base(p)}>
    <path d="M2.5 12S6 5.8 12 5.8 21.5 12 21.5 12 18 18.2 12 18.2 2.5 12 2.5 12z" />
    <circle cx="12" cy="12" r="2.8" />
  </svg>
);

export const IconBolt = (p: P) => (
  <svg {...base(p)}>
    <path d="M13 2.5 5 13.5h5.5L11 21.5l8-11h-5.5L13 2.5z" />
  </svg>
);

export const IconLayers = (p: P) => (
  <svg {...base(p)}>
    <path d="m12 3 9 5-9 5-9-5 9-5z" />
    <path d="m4.5 12.5 7.5 4.2 7.5-4.2M4.5 16.5 12 20.7l7.5-4.2" />
  </svg>
);

export const IconClock = (p: P) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 7v5.2l3.4 2" />
  </svg>
);

export const IconKey = ({ label, wide }: { label: string; wide?: boolean }) => (
  <span
    className={`inline-flex items-center justify-center h-7 ${wide ? "px-3.5" : "w-7"} border border-line2 bg-panel2 text-[10px] font-mono text-mist rounded-[4px] shadow-[0_2px_0_#0b0e13]`}
  >
    {label}
  </span>
);
