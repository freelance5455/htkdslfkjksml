import type { SVGProps } from "react";
import type { SpeciesKey } from "@/data";

type IconProps = SVGProps<SVGSVGElement> & { size?: number };

function base({ size = 18, ...props }: IconProps) {
  return {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.5,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true,
    ...props,
  };
}

export function MountainMark({ size = 34, ...props }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none" aria-hidden {...props}>
      <path d="M3.5 31.5 15 10.5l6.4 11.8 3.6-6 11.5 15.2" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
      <path d="M11 31.5 19.5 15l8.2 16.5" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" opacity=".55" />
      <path d="M20 7.5v-2M18 5.5h4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
      <circle cx="20" cy="27.5" r="2.4" stroke="currentColor" strokeWidth="1.2" />
      <path d="M3.5 35h33" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" opacity=".7" />
    </svg>
  );
}

export const ArrowRight = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M4 12h15M13 6l6 6-6 6" />
  </svg>
);
export const ArrowLeft = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M20 12H5M11 6l-6 6 6 6" />
  </svg>
);
export const PlayIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M8 5.5v13l11-6.5-11-6.5Z" fill="currentColor" stroke="none" />
  </svg>
);
export const PauseIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M9 5v14M15 5v14" strokeWidth="2" />
  </svg>
);
export const CloseIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="m6 6 12 12M18 6 6 18" />
  </svg>
);
export const MenuIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M3.5 7h17M3.5 12h17M3.5 17h11" />
  </svg>
);
export const CompassIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="m15.2 8.8-1.8 4.6-4.6 1.8 1.8-4.6 4.6-1.8Z" />
  </svg>
);
export const WindIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M3 8h11a3 3 0 1 0-3-3M3 12h15a3 3 0 1 1-3 3M3 16h7a2.5 2.5 0 1 1-2.5 2.5" />
  </svg>
);
export const SunIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="4" />
    <path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M18.7 5.3l-1.4 1.4M6.7 17.3l-1.4 1.4" />
  </svg>
);
export const ClockIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 7.5V12l3 2" />
  </svg>
);
export const ScopeIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="7.5" />
    <path d="M12 2v4M12 18v4M2 12h4M18 12h4" />
    <circle cx="12" cy="12" r="1" fill="currentColor" />
  </svg>
);
export const CrosshairIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="6.5" />
    <path d="M12 2.5v6M12 15.5v6M2.5 12h6M15.5 12h6" />
    <circle cx="12" cy="12" r="1.1" fill="currentColor" />
  </svg>
);
export const TargetIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="8.5" />
    <circle cx="12" cy="12" r="4.2" />
    <path d="M12 1.5v4M12 18.5v4M1.5 12h4M18.5 12h4" />
  </svg>
);
export const RifleIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M2 10.5h13.5l3.5-2.5 3 1v3l-5.5 1.2-2.5 4.3h-2l1.3-4.5H9l-2.4 4.5H4.3l1.4-5.5-3.7-1V10.5Z" />
    <path d="M14 8h4.5M9.8 10.5 8 6h3.4" />
  </svg>
);
export const BookIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v17H6.5A2.5 2.5 0 0 0 4 21.5v-17Z" />
    <path d="M4 19a2.5 2.5 0 0 1 2.5-2.5H20M8 6h8M8 10h6" />
  </svg>
);
export const AwardIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <circle cx="12" cy="9" r="5.5" />
    <path d="m8.5 13.5-1 8L12 19l4.5 2.5-1-8M9.8 9l1.6 1.6L14.6 7" />
  </svg>
);
export const ReloadIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M20 11a8 8 0 1 0-.8 5.2" />
    <path d="M20 4.5V11h-6.2" />
  </svg>
);
export const SoundIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M4 9.5h3l4-3.5v12l-4-3.5H4v-5Z" />
    <path d="M15 8.5a5 5 0 0 1 0 7M17.8 6a8.5 8.5 0 0 1 0 12" />
  </svg>
);
export const MutedIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M4 9.5h3l4-3.5v12l-4-3.5H4v-5Z" />
    <path d="m15.5 9.5 5 5M20.5 9.5l-5 5" />
  </svg>
);
export const FootprintIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M8.5 13.5c-2.5 0-4 2-4 4.2 0 1.7 1.2 3.3 3.2 3.3 1.1 0 1.5-.6 2.6-.6s1.5.6 2.6.6c2 0 3.2-1.6 3.2-3.3 0-2.2-1.5-4.2-4-4.2-1.3 0-1.8.4-1.8.4s-.5-.4-1.8-.4Z" />
    <circle cx="9" cy="8.5" r="1.2" />
    <circle cx="13" cy="7" r="1.2" />
    <circle cx="16" cy="8.8" r="1.1" />
    <circle cx="17.3" cy="12" r="1" />
  </svg>
);
export const CheckIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="m4.5 12.5 5 5L20 6.5" />
  </svg>
);
export const LockIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <rect x="5" y="10" width="14" height="11" rx="2" />
    <path d="M8.5 10V7.5a3.5 3.5 0 0 1 7 0V10" />
  </svg>
);
export const ChevronDown = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="m6 9.5 6 6 6-6" />
  </svg>
);
export const TrophyIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M7 4h10v5.5a5 5 0 0 1-10 0V4Z" />
    <path d="M7 6H3.5v2A4.5 4.5 0 0 0 8 12.5M17 6h3.5v2a4.5 4.5 0 0 1-4.5 4.5M12 14.5V19M8 22h8" />
  </svg>
);
export const LeafIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M5 19c-1-7 4-13 14-14 1 10-5 15-11 14M5 19c2.5-4 6-7.5 10.5-10" />
  </svg>
);
export const LocateIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="3" />
    <path d="M12 2v3M12 19v3M2 12h3M19 12h3" />
    <circle cx="12" cy="12" r="7.5" opacity=".55" />
  </svg>
);
export const InfoIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 11v5.5M12 7.5v.5" />
  </svg>
);
export const SmartphoneIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <rect x="6.5" y="2.5" width="11" height="19" rx="2.2" />
    <path d="M10 5.5h4M11 18.5h2" />
  </svg>
);
export const DownloadIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M12 3v11M7.5 9.5 12 14l4.5-4.5M4 17v2.5A1.5 1.5 0 0 0 5.5 21h13a1.5 1.5 0 0 0 1.5-1.5V17" />
  </svg>
);
export const CopyIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <rect x="9" y="9" width="11.5" height="11.5" rx="1.8" />
    <path d="M15 5.5V4.8A1.8 1.8 0 0 0 13.2 3H4.8A1.8 1.8 0 0 0 3 4.8v8.4A1.8 1.8 0 0 0 4.8 15h.7" />
  </svg>
);
export const AndroidIcon = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M5 11.5a7 7 0 0 1 14 0v5.2a1.3 1.3 0 0 1-1.3 1.3H6.3A1.3 1.3 0 0 1 5 16.7v-5.2Z" />
    <path d="m7.2 6.2-1.4-2M16.8 6.2l1.4-2M8.8 12.2v.1M15.2 12.2v.1" />
    <path d="M3 13v4M21 13v4M9.5 18v3M14.5 18v3" />
  </svg>
);

export function AnimalMark({ species, size = 34, ...props }: IconProps & { species: SpeciesKey }) {
  const common = {
    width: size,
    height: size,
    viewBox: "0 0 64 64",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.7,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true,
    ...props,
  };

  switch (species) {
    case "deer":
      return (
        <svg {...common}>
          <ellipse cx="30" cy="39" rx="15" ry="8.2" />
          <path d="M41 33.5c2.2-3.4 3-7 4-10.2 1-3 2.6-4.4 5-4.7 2.8-.3 4.6 1 5.7 3.1 1.3 2.4 1 4.9-.7 6.4-1.5 1.3-3.8 1.4-5.7.3" />
          <path d="M51 20.5c.6-2.3 2-4 4.3-4.8M52 22.6l4.7 1.6" />
          <path d="M49.5 15.5c-.7-2.4-.5-4.3.8-6.2M49 15c-2.2-.8-3.4-2.2-4-4.4M50 14.8c1-2.3 2.7-3.6 5.1-4" />
          <path d="M26 46.5 23.5 58M34 46.5 35 58M38 45.5l2.5 10M22 45.8 20 57" />
          <path d="M15.5 38.5c-2.5 1.5-2 4.5 1 4.5" />
        </svg>
      );
    case "elk":
      return (
        <svg {...common}>
          <ellipse cx="29" cy="39" rx="16.5" ry="9.2" />
          <path d="M41 33.5C43.5 29 44 24 46 20c1.5-3 4-4.5 6.7-3.5 2.5.9 3.6 3.2 2.7 5.6-.9 2.4-3.5 3.4-6 2.4" />
          <path d="M50 16.5c.4-2.8 1.7-4.8 4-6.1M51.5 18.8l5.2 1M52 12c-.9-2.4-2.5-3.8-5-4.5M53.5 11.8c2.6-.6 4.8-.2 6.5 1.4" />
          <path d="M47 16.5c-2.2-1.2-3.6-3-4.2-5.4" />
          <path d="M24 47.5 21 58M33 48l1 10M39 46.8 42 57M20.5 47 18 58" />
          <path d="M13 39c-2.4 1-2.5 4.4.9 4.8" />
        </svg>
      );
    case "boar":
      return (
        <svg {...common}>
          <path d="M13 38c0-7.5 6.5-12.5 16-12.5 8 0 13 3 18 6.5 2 1.4 5 1.5 7 3.4 1.8 1.7 1.6 4.5-.4 5.7-2.4 1.4-5 1-7.3.2l-1.2 2.7H26l-2 5.5h-3.5L22 42c-4.5-1.2-9-1.6-9-4Z" />
          <path d="M47 35.5c1.5-.3 2.6 0 3.4.9M44 29.5c2-2.5 3-5.3 3-8.4M46.5 26.2l3.9-2.4" />
          <circle cx="44" cy="31.8" r=".9" fill="currentColor" />
          <path d="M27 49.5 26 58M35 49v9M42 47l1 11M20 43.5 18 57" />
        </svg>
      );
    case "fox":
      return (
        <svg {...common}>
          <path d="M16 38c1-6.5 6.5-10.2 14-10.2 7 0 11.5 3.4 13.4 8.5l7.6-5.3c-1 7.2-3.7 11-8 12.1-2.2 3-5.8 4.4-11.4 4.4-7.8 0-13.4-2.8-15.6-9.5Z" />
          <path d="M44 33c3-1.8 4.8-4.7 5.2-8.5-2.5.4-4.4 1.6-5.8 3.4M50 37.5c3.7.6 6 2.6 7 6-3.7.8-6.4.2-8.2-1.8" />
          <path d="M25 47.5v10M33 47.5v10M39 46.5l1.5 11M20 45.5l-1.5 12" />
          <path d="M44.5 29.5c-.6-3.2.1-6 2-8.5 2.4 1.7 3.6 4.1 3.6 7.2" />
        </svg>
      );
    case "hare":
      return (
        <svg {...common}>
          <path d="M21 42c0-6 5.5-10.5 12.5-10.5 8 0 12.4 4 13.4 9.4 1.6.2 3 .9 4.2 2.2-1.7 2.2-4 3.1-6.8 2.8C42 50.2 37 52.5 31 52c-6-.5-10-3-10-10Z" />
          <path d="M29 33.5c-.3-5.2 1.1-9.8 4.2-13.8 2.8 1.2 4.2 3.6 4.2 7.2 0 2.1-.7 3.9-2.1 5.4M38.5 32c1.3-4.9 3.5-8 6.7-9.4 1.7 2.7 1.4 5.7-.8 9" />
          <path d="M27 50.5 24 58M39 51l2 7.5M45 36c1.7-1.6 3.8-2.4 6.3-2.4" />
          <circle cx="48.5" cy="39" r=".8" fill="currentColor" />
        </svg>
      );
    case "pheasant":
      return (
        <svg {...common}>
          <path d="M35 28c4.5 0 8 2.5 9 6.5 3.2 1.2 4.5 3.6 3.6 7-1.4 5.6-6 9.5-12.3 10.4-4.8.7-9.4-.7-13.7-4.2 3.5-1.5 6.2-4 8.2-7.5 2-3.4 3.8-7.4 5.2-12.2Z" />
          <path d="M47.5 34c1.5-3.2 1-6.3-1.5-9.2-2.2-2.5-5.6-3.2-8.7-2.3-2.7.8-4.5 3-5.3 5.5 2.8-1.7 5.5-2.3 8-1.7" />
          <path d="M37 21.5c2-2 4.6-2.7 7.5-2.2l.6-2.8M34.5 30c-1-2.7-2.8-5-5.4-6.9M39 43c-2.3 4.4-2.4 9.2-.2 14.2M42.5 44c-1.5 4.6-1 9.6 1.4 15M34 42c-1.4 4-3.4 7.4-6.2 10.2" />
          <circle cx="47.5" cy="24" r=".85" fill="currentColor" />
        </svg>
      );
  }
}

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <span className="text-brass-300">
        <MountainMark size={compact ? 30 : 36} />
      </span>
      <span className="flex flex-col leading-none">
        <span className="font-condensed text-[1.35rem] font-semibold uppercase tracking-[0.26em] text-sand-100">
          Ridgeline
        </span>
        <span className="mt-1 font-condensed text-[0.54rem] font-medium uppercase tracking-[0.4em] text-sand-400">
          Hunting Club · Est. 1987
        </span>
      </span>
    </div>
  );
}
