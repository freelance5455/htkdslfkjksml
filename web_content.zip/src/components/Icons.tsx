import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement>;
const s = { fill: "none", stroke: "currentColor", strokeWidth: 1.8, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };

export const IconSearch = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></svg>
);
export const IconPin = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><path d="M12 21s7-5.4 7-11a7 7 0 1 0-14 0c0 5.6 7 11 7 11Z" /><circle cx="12" cy="10" r="2.2" /></svg>
);
export const IconClock = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><circle cx="12" cy="12" r="8" /><path d="M12 8v4.5L15 14" /></svg>
);
export const IconTruck = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><path d="M3 7h11v10H3zM14 10h4l3 3v4h-7z" /><circle cx="7" cy="18" r="1.6" /><circle cx="18" cy="18" r="1.6" /></svg>
);
export const IconStar = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" fill="currentColor" {...p}><path d="m12 3.4 2.3 4.8 5.3.8-3.8 3.7.9 5.3L12 15.5 7.3 18l.9-5.3L4.4 9l5.3-.8L12 3.4Z" /></svg>
);
export const IconPlus = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><path d="M12 5v14M5 12h14" /></svg>
);
export const IconMinus = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><path d="M5 12h14" /></svg>
);
export const IconX = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><path d="m6 6 12 12M18 6 6 18" /></svg>
);
export const IconCart = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><path d="M4 5h2l1.5 11h11L21 8H7" /><circle cx="9.5" cy="19.5" r="1.3" /><circle cx="17.5" cy="19.5" r="1.3" /></svg>
);
export const IconPhone = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><path d="M7 3.8h3.2l1.2 3-2 1.2a12 12 0 0 0 6.6 6.6l1.2-2 3 1.2V17a2 2 0 0 1-2.2 2A16 16 0 0 1 5 6.2 2 2 0 0 1 7 3.8Z" /></svg>
);
export const IconWA = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" fill="currentColor" {...p}><path d="M12.04 3C7.3 3 3.45 6.8 3.45 11.5c0 1.5.4 2.95 1.16 4.23L3.4 21l5.42-1.17A8.96 8.96 0 0 0 12.04 20c4.74 0 8.59-3.8 8.59-8.5S16.78 3 12.04 3Zm4.98 12.04c-.2.57-1.18 1.05-1.63 1.12-.42.06-.95.09-1.54-.1-.35-.1-.81-.27-1.4-.52-2.46-1.06-4.06-3.54-4.18-3.7-.12-.17-1-1.33-1-2.54 0-1.2.63-1.8.86-2.05.22-.24.49-.3.65-.3h.47c.15 0 .35-.05.55.42.2.5.7 1.72.76 1.85.06.12.1.27.02.43-.08.17-.12.27-.24.42-.12.14-.25.32-.36.43-.12.12-.24.25-.1.48.14.24.62 1.02 1.33 1.65.92.82 1.69 1.07 1.93 1.19.24.12.38.1.52-.06.14-.17.6-.7.76-.94.16-.24.32-.2.54-.12.22.08 1.4.66 1.64.78.24.12.4.18.46.28.06.1.06.58-.14 1.15Z" /></svg>
);
export const IconUser = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><circle cx="12" cy="8" r="3.2" /><path d="M5.5 19.2c.9-3.2 3.4-5 6.5-5s5.6 1.8 6.5 5" /></svg>
);
export const IconChevron = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><path d="m9 6 6 6-6 6" /></svg>
);
export const IconHome = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><path d="m4 11 8-7 8 7v9a1 1 0 0 1-1 1h-5v-6H10v6H5a1 1 0 0 1-1-1z" /></svg>
);
export const IconBag = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><path d="M6 8h12l-.8 12H6.8L6 8Z" /><path d="M9 8V6.5A3 3 0 0 1 15 6.5V8" /></svg>
);
export const IconCheck = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><path d="m5 12 5 5 9-10" /></svg>
);
export const IconCopy = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><rect x="8" y="8" width="12" height="12" rx="2" /><path d="M4 16V6a2 2 0 0 1 2-2h10" /></svg>
);
export const IconMenu = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><path d="M4 7h16M4 12h16M4 17h16" /></svg>
);
export const IconArrow = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><path d="M5 12h14M13 6l6 6-6 6" /></svg>
);
export const IconBell = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><path d="M6 9a6 6 0 1 1 12 0c0 4 1.5 5.5 1.5 5.5H4.5S6 13 6 9Z" /><path d="M10 19a2 2 0 0 0 4 0" /></svg>
);
export const IconDownload = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><path d="M12 4v10M8 10l4 4 4-4M5 19h14" /></svg>
);
export const IconBank = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><path d="M4 10h16M6 10v8M10 10v8M14 10v8M18 10v8M3 18h18M12 4 3 9h18L12 4Z" /></svg>
);
export const IconCash = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><rect x="3" y="6" width="18" height="12" rx="2" /><circle cx="12" cy="12" r="2.4" /></svg>
);
export const IconSend = (p: P) => (
  <svg viewBox="0 0 24 24" width="1em" height="1em" {...s} {...p}><path d="m4 12 16-8-6 16-2.5-6.5L4 12Z" /></svg>
);
