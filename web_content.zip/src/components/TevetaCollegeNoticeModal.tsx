import React, { useState } from 'react';
import { Building2, CheckCircle2, GraduationCap, MapPin, Search, ShieldAlert, X } from 'lucide-react';
import { TRANSLATIONS } from '../lib/i18n';
import { TEVETA_COLLEGE_DIRECTORY } from '../lib/tevetaCatalog';
import type { LanguageCode } from '../types';

interface TevetaCollegeNoticeModalProps {
  open: boolean;
  onClose: () => void;
  language: LanguageCode;
  onSelectCollege?: (collegeName: string) => void;
}

export const TevetaCollegeNoticeModal: React.FC<TevetaCollegeNoticeModalProps> = ({
  open,
  onClose,
  language,
  onSelectCollege,
}) => {
  const t = TRANSLATIONS[language];
  const [regionFilter, setRegionFilter] = useState<'All' | 'Northern' | 'Central' | 'Southern'>('All');
  const [search, setSearch] = useState('');

  if (!open) return null;

  const filteredColleges = TEVETA_COLLEGE_DIRECTORY.filter((c) => {
    if (regionFilter !== 'All' && c.region !== regionFilter && c.region !== 'National') {
      return false;
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        c.name.toLowerCase().includes(q) ||
        c.district.toLowerCase().includes(q) ||
        c.category.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-400 flex items-center justify-center shrink-0">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-wide text-emerald-700 dark:text-emerald-400">
                {t.studentNotice.badgeLabel}
              </p>
              <h2 className="font-display font-bold text-lg text-slate-900 dark:text-white mt-0.5">
                {t.studentNotice.modalTitle}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {t.studentNotice.modalSubtitle}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close notice"
            className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {/* 3 Key Notice Cards */}
          <div className="grid sm:grid-cols-3 gap-3">
            <div className="p-4 rounded-xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900 space-y-1.5">
              <div className="flex items-center gap-2 text-blue-700 dark:text-blue-400 font-display font-semibold text-xs">
                <GraduationCap className="w-4 h-4 shrink-0" />
                <span>{t.studentNotice.point1Title}</span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {t.studentNotice.point1Body}
              </p>
            </div>

            <div className="p-4 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900 space-y-1.5">
              <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-400 font-display font-semibold text-xs">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{t.studentNotice.point2Title}</span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {t.studentNotice.point2Body}
              </p>
            </div>

            <div className="p-4 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 space-y-1.5">
              <div className="flex items-center gap-2 text-amber-700 dark:text-amber-400 font-display font-semibold text-xs">
                <ShieldAlert className="w-4 h-4 shrink-0" />
                <span>{t.studentNotice.point3Title}</span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {t.studentNotice.point3Body}
              </p>
            </div>
          </div>

          {/* Search & Regional Filter for All Colleges */}
          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="font-display font-bold text-sm text-slate-900 dark:text-white">
                Covered TEVETA Colleges Across Malawi ({filteredColleges.length})
              </h3>
              <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
                {(['All', 'Northern', 'Central', 'Southern'] as const).map((region) => (
                  <button
                    key={region}
                    type="button"
                    onClick={() => setRegionFilter(region)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                      regionFilter === region
                        ? 'bg-white dark:bg-slate-900 text-blue-700 dark:text-blue-400 shadow-sm'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {region}
                  </button>
                ))}
              </div>
            </div>

            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search college name, district, or type..."
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs"
              />
            </div>

            <div className="grid sm:grid-cols-2 gap-2.5">
              {filteredColleges.map((col) => (
                <div
                  key={col.name}
                  className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 flex items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <p className="font-display font-semibold text-xs text-slate-900 dark:text-white truncate">
                      {col.name}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3 h-3 shrink-0" />
                      <span className="truncate">
                        {col.district} · {col.region} · {col.category}
                      </span>
                    </p>
                  </div>
                  {onSelectCollege && col.category !== 'Other' && (
                    <button
                      type="button"
                      onClick={() => {
                        onSelectCollege(col.name);
                        onClose();
                      }}
                      className="shrink-0 px-2.5 py-1.5 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-[11px] font-semibold cursor-pointer"
                    >
                      Library
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex flex-wrap items-center justify-between gap-2">
          {onSelectCollege ? (
            <button
              type="button"
              onClick={() => {
                onSelectCollege('All');
                onClose();
              }}
              className="min-h-[40px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer"
            >
              Browse All-College TEVETA Library
            </button>
          ) : (
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Select your college during sign-up or in your profile anytime.
            </span>
          )}
          <button
            type="button"
            onClick={onClose}
            className="min-h-[40px] px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            {t.studentNotice.dismissBtn}
          </button>
        </div>
      </div>
    </div>
  );
};
