import { memo, useState, type ReactNode } from "react";
import { Icon } from "./ui";

function inline(text: string, key: string): ReactNode[] {
  return text
    .split(/(`[^`]+`|\*\*[^*]+\*\*)/g)
    .filter(Boolean)
    .map((part, index) =>
      part.startsWith("`") && part.endsWith("`") ? (
        <code
          key={`${key}-${index}`}
          className="rounded bg-accentsoft/70 px-1 py-0.5 font-mono text-[11px] text-accent"
        >
          {part.slice(1, -1)}
        </code>
      ) : part.startsWith("**") && part.endsWith("**") ? (
        <strong key={`${key}-${index}`} className="font-semibold text-fg">
          {part.slice(2, -2)}
        </strong>
      ) : (
        part
      ),
    );
}
function CodeBlock({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  const [first, ...rest] = text.split("\n");
  const lang = /^[a-z0-9+-]{1,16}$/i.test(first.trim()) ? first.trim() : "code";
  const code = (lang !== "code" ? rest.join("\n") : text).replace(/\n$/, "");
  return (
    <div className="my-3 overflow-hidden rounded-xl border border-line bg-bg">
      <div className="flex items-center justify-between border-b border-line px-3 py-2 text-[9px] text-muted">
        <span className="font-mono uppercase">{lang}</span>
        <button
          aria-label="Copy code"
          onClick={async () => {
            try {
              await navigator.clipboard.writeText(code);
              setCopied(true);
              setTimeout(() => setCopied(false), 1500);
            } catch {
              setCopied(false);
            }
          }}
          className="flex items-center gap-1 hover:text-accent"
        >
          <Icon name={copied ? "check" : "copy"} className="h-3 w-3" />
          {copied ? "Copied" : "Copy"}
        </button>
      </div>
      <pre className="max-h-[420px] overflow-auto p-3 font-mono text-[11px] leading-[1.8]">
        <code>{code}</code>
      </pre>
    </div>
  );
}
function MessageContent({ text }: { text: string }) {
  return (
    <>
      {text.split("```").map((block, bi) =>
        bi % 2 ? (
          <CodeBlock key={bi} text={block} />
        ) : (
          <div key={bi} className="space-y-1.5">
            {block
              .trim()
              .split("\n")
              .map((line, li) => {
                if (!line.trim()) return <div key={li} className="h-1" />;
                if (/^#{1,4}\s/.test(line))
                  return (
                    <h3
                      key={li}
                      className="pb-1 pt-3 text-[14px] font-semibold leading-relaxed"
                    >
                      {inline(line.replace(/^#{1,4}\s+/, ""), `${bi}-${li}`)}
                    </h3>
                  );
                if (/^[-*]\s|^\d+\.\s/.test(line)) {
                  const marker = line.match(/^\d+\./)?.[0];
                  return (
                    <div key={li} className="flex items-start gap-2 pl-1">
                      <span className="mt-[3px] w-3 shrink-0 text-[11px] text-accent">
                        {marker || (
                          <span className="mt-[7px] block h-1 w-1 rounded-full bg-accent" />
                        )}
                      </span>
                      <span className="min-w-0 flex-1">
                        {inline(
                          line.replace(/^([-*]|\d+\.)\s+/, ""),
                          `${bi}-${li}`,
                        )}
                      </span>
                    </div>
                  );
                }
                if (/^>\s/.test(line))
                  return (
                    <blockquote
                      key={li}
                      className="border-l-2 border-accent/35 pl-3 text-muted"
                    >
                      {inline(line.slice(2), `${bi}-${li}`)}
                    </blockquote>
                  );
                return <p key={li}>{inline(line, `${bi}-${li}`)}</p>;
              })}
          </div>
        ),
      )}
    </>
  );
}
export default memo(MessageContent);
