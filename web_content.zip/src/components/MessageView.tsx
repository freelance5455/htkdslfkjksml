import { useState } from 'react';
import { BookmarkPlus, Check, Copy, RotateCcw } from 'lucide-react';
import type { ChatMessage, MemoryCategory } from '../lib/jarvisTypes';
import { formatLanguageLabel } from '../lib/language';

interface MessageViewProps {
  messages: ChatMessage[];
  isStreaming: boolean;
  onFollowUpClick: (question: string) => void;
  onSaveToMemory: (content: string, category: MemoryCategory) => Promise<void>;
  onRetryMessage?: (failedAssistantMsgId: string) => void;
}

interface ContentBlock {
  type: 'text' | 'code';
  content: string;
  lang?: string;
}

function splitMarkdownBlocks(raw: string): ContentBlock[] {
  const blocks: ContentBlock[] = [];
  const regex = /```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = regex.exec(raw)) !== null) {
    if (match.index > lastIndex) {
      blocks.push({ type: 'text', content: raw.slice(lastIndex, match.index) });
    }
    blocks.push({
      type: 'code',
      lang: match[1] || 'code',
      content: match[2].replace(/\n$/, ''),
    });
    lastIndex = match.index + match[0].length;
  }

  if (lastIndex < raw.length) {
    blocks.push({ type: 'text', content: raw.slice(lastIndex) });
  }

  return blocks;
}

function renderInlineFormatting(text: string): React.ReactNode[] {
  const parts = text.split(/(`[^`]+`|\*\*[^*]+\*\*)/g);
  return parts.map((part, idx) => {
    if (part.startsWith('`') && part.endsWith('`') && part.length >= 2) {
      return (
        <code
          key={idx}
          className="rounded bg-slate-800/90 px-1.5 py-0.5 font-mono text-[0.86em] text-sky-200"
        >
          {part.slice(1, -1)}
        </code>
      );
    }
    if (part.startsWith('**') && part.endsWith('**') && part.length >= 4) {
      return (
        <strong key={idx} className="font-semibold text-slate-50">
          {part.slice(2, -2)}
        </strong>
      );
    }
    return <span key={idx}>{part}</span>;
  });
}

function CodeBlock({ lang, code }: { lang: string; code: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard unavailable
    }
  };

  return (
    <div className="my-3 overflow-hidden rounded-xl border border-white/10 bg-[#04060A]">
      <div className="flex items-center justify-between border-b border-white/10 px-3.5 py-2 text-xs text-slate-400">
        <span className="font-mono text-amber-300/90">{lang}</span>
        <button
          type="button"
          onClick={handleCopy}
          className="inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-xs text-slate-300 transition-colors hover:bg-white/5 hover:text-white whitespace-nowrap shrink-0"
          aria-label={`Copy ${lang} code`}
        >
          {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
          <span>{copied ? 'Copied' : 'Copy'}</span>
        </button>
      </div>
      <pre className="overflow-x-auto p-3.5 font-mono text-[13px] leading-relaxed text-slate-200">
        <code>{code}</code>
      </pre>
    </div>
  );
}

function TextProse({ text }: { text: string }) {
  const lines = text.split('\n');
  return (
    <div className="space-y-2 leading-relaxed">
      {lines.map((line, i) => {
        const trimmed = line.trim();
        if (!trimmed) return <div key={i} className="h-1" />;
        if (trimmed.startsWith('### ')) {
          return (
            <h4 key={i} className="pt-1 font-display text-base font-semibold text-slate-100">
              {renderInlineFormatting(trimmed.slice(4))}
            </h4>
          );
        }
        if (trimmed.startsWith('## ')) {
          return (
            <h3 key={i} className="pt-1 font-display text-lg font-semibold text-slate-50">
              {renderInlineFormatting(trimmed.slice(3))}
            </h3>
          );
        }
        if (/^[-*•]\s+/.test(trimmed)) {
          return (
            <div key={i} className="flex items-start gap-2.5 pl-1">
              <span aria-hidden="true" className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-amber-400/75" />
              <span>{renderInlineFormatting(trimmed.replace(/^[-*•]\s+/, ''))}</span>
            </div>
          );
        }
        if (/^\d+\.\s+/.test(trimmed)) {
          const numMatch = trimmed.match(/^(\d+\.)\s+(.*)$/);
          if (numMatch) {
            return (
              <div key={i} className="flex items-start gap-2.5 pl-1">
                <span className="shrink-0 pt-0.5 font-mono text-xs font-medium text-sky-400 tabular-nums">
                  {numMatch[1]}
                </span>
                <span>{renderInlineFormatting(numMatch[2])}</span>
              </div>
            );
          }
        }
        return <p key={i}>{renderInlineFormatting(line)}</p>;
      })}
    </div>
  );
}

export function MessageView({
  messages,
  isStreaming,
  onFollowUpClick,
  onSaveToMemory,
  onRetryMessage,
}: MessageViewProps) {
  const [savedIds, setSavedIds] = useState<Record<string, boolean>>({});

  const handleManualSave = async (msg: ChatMessage) => {
    const snippet = msg.content.replace(/```[\s\S]*?```/g, '').trim().slice(0, 240);
    if (!snippet) return;
    await onSaveToMemory(snippet, msg.role === 'user' ? 'fact' : 'decision');
    setSavedIds((prev) => ({ ...prev, [msg.id]: true }));
  };

  return (
    <div className="space-y-6" data-testid="conversation-stream">
      {messages.map((msg, idx) => {
        const isUser = msg.role === 'user';
        const isLast = idx === messages.length - 1;
        const timeStr = new Date(msg.timestamp).toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
        });

        return (
          <article
            key={msg.id}
            className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
            data-testid={`message-${msg.role}`}
          >
            <div className="mb-1.5 flex items-center gap-2 text-xs text-slate-400">
              <span className={`font-medium ${isUser ? 'text-sky-300' : 'text-amber-300'}`}>
                {isUser ? 'You' : 'JARVIS'}
              </span>
              {msg.language && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>{formatLanguageLabel(msg.language)}</span>
                </>
              )}
              {msg.attachmentName && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono text-slate-300">{msg.attachmentName}</span>
                </>
              )}
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums">{timeStr}</span>
            </div>

            <div
              className={`max-w-[92%] sm:max-w-[84%] rounded-2xl px-4 py-3 text-[15px] ${
                isUser
                  ? 'bg-sky-500/12 border border-sky-400/25 text-slate-100'
                  : msg.error
                    ? 'bg-rose-950/40 border border-rose-500/30 text-rose-200'
                    : 'bg-[#0B1018] border border-white/8 text-slate-200'
              }`}
            >
              {msg.content ? (
                <>
                  {splitMarkdownBlocks(msg.content).map((block, bIdx) =>
                    block.type === 'code' ? (
                      <CodeBlock key={bIdx} lang={block.lang || 'code'} code={block.content} />
                    ) : (
                      <TextProse key={bIdx} text={block.content} />
                    ),
                  )}
                  {isStreaming && isLast && (
                    <div
                      data-testid="typing-indicator"
                      className="mt-2 inline-flex items-center gap-1.5 text-xs text-sky-300/80"
                    >
                      <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-sky-400" />
                      <span>Typing…</span>
                    </div>
                  )}
                </>
              ) : isStreaming && isLast ? (
                <div
                  data-testid="thinking-indicator"
                  className="flex items-center gap-2 py-1 text-sm text-sky-300/90"
                >
                  <span className="inline-flex items-center gap-1" aria-hidden="true">
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-sky-400 [animation-delay:-0.2s]" />
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-sky-400 [animation-delay:-0.1s]" />
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-amber-300" />
                  </span>
                  <span>Thinking…</span>
                </div>
              ) : (
                <div className="py-1 text-sm text-slate-400">Generation stopped before any text arrived.</div>
              )}

              {!isUser && msg.savedMemories && msg.savedMemories.length > 0 && (
                <div className="mt-3 border-t border-amber-400/15 pt-2 text-xs text-amber-300/90">
                  Saved to memory: {msg.savedMemories.join(' · ')}
                </div>
              )}

              {!isUser && msg.error && !isStreaming && onRetryMessage && (
                <div className="mt-3 flex items-center justify-end border-t border-rose-500/20 pt-2">
                  <button
                    type="button"
                    onClick={() => onRetryMessage(msg.id)}
                    aria-label="Retry failed message"
                    className="inline-flex min-h-[34px] items-center gap-1.5 rounded-lg border border-rose-400/35 bg-rose-500/15 px-3 py-1 text-xs font-semibold text-rose-100 transition-colors hover:bg-rose-500/25 whitespace-nowrap"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    <span>Retry</span>
                  </button>
                </div>
              )}

              {!msg.error && msg.content && !(isStreaming && isLast) && (
                <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-white/6 pt-2">
                  <button
                    type="button"
                    onClick={() => handleManualSave(msg)}
                    disabled={savedIds[msg.id]}
                    className="inline-flex min-h-[32px] items-center gap-1.5 rounded-lg px-2 py-1 text-xs font-medium text-slate-400 transition-colors hover:bg-white/5 hover:text-amber-300 disabled:text-emerald-400 whitespace-nowrap shrink-0"
                  >
                    {savedIds[msg.id] ? (
                      <>
                        <Check className="h-3.5 w-3.5" />
                        <span>Saved to memory</span>
                      </>
                    ) : (
                      <>
                        <BookmarkPlus className="h-3.5 w-3.5" />
                        <span>Remember</span>
                      </>
                    )}
                  </button>

                  {!isUser && msg.modelId && (
                    <span className="font-mono text-[11px] text-slate-500">
                      {msg.modelId}
                    </span>
                  )}
                </div>
              )}
            </div>

            {!isUser && isLast && msg.followUps && msg.followUps.length > 0 && !isStreaming && (
              <div className="mt-2.5 flex flex-wrap gap-2">
                {msg.followUps.map((q) => (
                  <button
                    key={q}
                    type="button"
                    onClick={() => onFollowUpClick(q)}
                    className="min-h-[40px] rounded-xl border border-white/10 bg-[#0B1018] px-3.5 py-2 text-left text-xs font-medium text-slate-300 transition-colors hover:border-sky-400/40 hover:bg-sky-500/10 hover:text-sky-100"
                  >
                    {q}
                  </button>
                ))}
              </div>
            )}
          </article>
        );
      })}
    </div>
  );
}
