import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { mockTestData } from '../data/mockData';
import {
  X,
  Clock,
  Award,
  CheckCircle2,
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  Sparkles,
  HelpCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const MockTestModal: React.FC = () => {
  const { mockTestOpen, setMockTestOpen, showToast } = useApp();

  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [markedForReview, setMarkedForReview] = useState<Record<number, boolean>>({});
  const [timeLeft, setTimeLeft] = useState(mockTestData.durationMinutes * 60);
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Timer countdown
  useEffect(() => {
    if (!mockTestOpen || isSubmitted) return;
    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          handleSubmitTest();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [mockTestOpen, isSubmitted]);

  if (!mockTestOpen) return null;

  const currentQ = mockTestData.questions[currentIndex];
  const totalQuestions = mockTestData.questions.length;

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSelectOption = (optIndex: number) => {
    setSelectedAnswers((prev) => ({ ...prev, [currentQ.id]: optIndex }));
  };

  const handleClearOption = () => {
    setSelectedAnswers((prev) => {
      const next = { ...prev };
      delete next[currentQ.id];
      return next;
    });
  };

  const toggleMarkForReview = () => {
    setMarkedForReview((prev) => ({
      ...prev,
      [currentQ.id]: !prev[currentQ.id]
    }));
  };

  const handleSubmitTest = () => {
    setIsSubmitted(true);
    try {
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.6 }
      });
    } catch (e) {
      console.error(e);
    }
    showToast('Mock test submitted successfully! View your performance scorecard.', 'success');
  };

  const handleRetake = () => {
    setSelectedAnswers({});
    setMarkedForReview({});
    setTimeLeft(mockTestData.durationMinutes * 60);
    setCurrentIndex(0);
    setIsSubmitted(false);
  };

  // Score calculations
  let correctCount = 0;
  let wrongCount = 0;
  mockTestData.questions.forEach((q) => {
    const userAns = selectedAnswers[q.id];
    if (userAns !== undefined) {
      if (userAns === q.correctAnswer) {
        correctCount++;
      } else {
        wrongCount++;
      }
    }
  });

  const totalAttempted = Object.keys(selectedAnswers).length;
  const unattempted = totalQuestions - totalAttempted;
  const rawScore = correctCount * mockTestData.marksPerQuestion - wrongCount * mockTestData.negativeMark;
  const maxMarks = totalQuestions * mockTestData.marksPerQuestion;
  const percentage = Math.max(0, Math.round((rawScore / maxMarks) * 100));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-950/85 backdrop-blur-md transition-opacity"
        onClick={() => {
          if (isSubmitted || confirm('Are you sure you want to exit the mock test? Your progress will be lost.')) {
            setMockTestOpen(false);
          }
        }}
      />

      {/* Test Container */}
      <div className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh] z-10 animate-in fade-in zoom-in-95 duration-150">
        {/* Test Header */}
        <div className="bg-[#0B192C] text-white px-4 py-3 flex items-center justify-between border-b border-[#1E3E62] shrink-0">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/20 uppercase">
                {mockTestData.exam}
              </span>
              <h2 className="text-xs sm:text-sm font-black text-white truncate max-w-xs sm:max-w-md">
                {mockTestData.title}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {!isSubmitted && (
              <div className="flex items-center gap-1.5 bg-slate-800 text-amber-400 px-3 py-1 rounded-lg border border-slate-700 font-mono text-xs sm:text-sm font-bold">
                <Clock className="w-4 h-4 text-amber-400" />
                <span>{formatTimer(timeLeft)}</span>
              </div>
            )}

            <button
              onClick={() => {
                if (isSubmitted || confirm('Exit mock test?')) {
                  setMockTestOpen(false);
                }
              }}
              className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Test Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          {/* Scorecard State */}
          {isSubmitted ? (
            <div className="space-y-6">
              <div className="bg-gradient-to-br from-[#0B192C] to-[#1E3E62] text-white rounded-2xl p-6 sm:p-8 text-center space-y-3 shadow-lg">
                <Award className="w-16 h-16 text-amber-400 mx-auto" />
                <h2 className="text-2xl sm:text-3xl font-black">
                  Mock Test Performance Card
                </h2>
                <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto">
                  {rawScore >= 12
                    ? 'Outstanding! Your preparation for ADRE & Assam Police is in the top 5% bracket.'
                    : 'Good attempt. Focus on revising weak areas in Assam History and Quantitative Aptitude.'}
                </p>

                {/* Score Big Meter */}
                <div className="pt-2 flex items-center justify-center gap-6">
                  <div>
                    <span className="text-3xl sm:text-4xl font-black text-amber-400">
                      {rawScore}
                    </span>
                    <span className="text-xs text-slate-400 block font-semibold">
                      Out of {maxMarks} Marks
                    </span>
                  </div>
                  <div className="h-10 w-px bg-slate-700" />
                  <div>
                    <span className="text-3xl sm:text-4xl font-black text-emerald-400">
                      {percentage}%
                    </span>
                    <span className="text-xs text-slate-400 block font-semibold">
                      Score Accuracy
                    </span>
                  </div>
                </div>
              </div>

              {/* Statistics Breakdown */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-center">
                  <span className="text-xl font-black text-emerald-700">{correctCount}</span>
                  <span className="block text-[11px] font-bold text-emerald-800 uppercase mt-0.5">Correct (+{correctCount * 2})</span>
                </div>
                <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-center">
                  <span className="text-xl font-black text-red-600">{wrongCount}</span>
                  <span className="block text-[11px] font-bold text-red-800 uppercase mt-0.5">Wrong (-{wrongCount * 0.5})</span>
                </div>
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-center">
                  <span className="text-xl font-black text-slate-700">{unattempted}</span>
                  <span className="block text-[11px] font-bold text-slate-600 uppercase mt-0.5">Skipped</span>
                </div>
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-center">
                  <span className="text-xl font-black text-amber-700">{totalQuestions}</span>
                  <span className="block text-[11px] font-bold text-amber-800 uppercase mt-0.5">Total Questions</span>
                </div>
              </div>

              {/* Retake Button */}
              <div className="flex justify-end gap-2">
                <button
                  onClick={handleRetake}
                  className="bg-[#0B192C] text-amber-400 hover:bg-slate-800 font-bold text-xs px-4 py-2 rounded-xl flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Retake Test
                </button>
              </div>

              {/* Comprehensive Question Solutions Review */}
              <div className="space-y-4 pt-4 border-t border-slate-200">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Question-by-Question Solution Explanations
                </h3>

                <div className="space-y-3">
                  {mockTestData.questions.map((q, idx) => {
                    const userAns = selectedAnswers[q.id];
                    const isCorrect = userAns === q.correctAnswer;
                    const isSkipped = userAns === undefined;

                    return (
                      <div
                        key={q.id}
                        className={`p-4 rounded-xl border ${
                          isCorrect
                            ? 'bg-emerald-50/50 border-emerald-200'
                            : isSkipped
                            ? 'bg-slate-50 border-slate-200'
                            : 'bg-red-50/50 border-red-200'
                        } space-y-2`}
                      >
                        <div className="flex items-center justify-between text-xs font-bold">
                          <span className="text-slate-800">
                            Q{idx + 1}. ({q.topic})
                          </span>
                          {isCorrect ? (
                            <span className="text-emerald-700 font-bold flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5" /> +2 Marks
                            </span>
                          ) : isSkipped ? (
                            <span className="text-slate-500 font-semibold">Not Attempted (0 Marks)</span>
                          ) : (
                            <span className="text-red-600 font-bold flex items-center gap-1">
                              <AlertCircle className="w-3.5 h-3.5" /> -0.5 Marks
                            </span>
                          )}
                        </div>

                        <p className="text-xs sm:text-sm font-semibold text-slate-900">
                          {q.question}
                        </p>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-xs">
                          {q.options.map((opt, optIdx) => {
                            const isThisCorrect = optIdx === q.correctAnswer;
                            const isThisUser = optIdx === userAns;
                            return (
                              <div
                                key={optIdx}
                                className={`p-2 rounded-lg border ${
                                  isThisCorrect
                                    ? 'bg-emerald-100 border-emerald-300 font-bold text-emerald-900'
                                    : isThisUser
                                    ? 'bg-red-100 border-red-300 font-bold text-red-900'
                                    : 'bg-white border-slate-200 text-slate-700'
                                }`}
                              >
                                {String.fromCharCode(65 + optIdx)}. {opt}
                                {isThisCorrect && ' ✓ (Correct)'}
                                {isThisUser && !isThisCorrect && ' ✗ (Your Pick)'}
                              </div>
                            );
                          })}
                        </div>

                        <div className="bg-white/80 p-2.5 rounded-lg border border-slate-200 text-[11px] text-slate-700">
                          <strong>Detailed Explanation:</strong> {q.explanation}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : (
            /* Live Exam Questions Palette and Workspace */
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Question Workspace */}
              <div className="lg:col-span-8 space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200 text-xs text-slate-500">
                  <span className="font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded">
                    Question {currentIndex + 1} of {totalQuestions} • {currentQ.topic}
                  </span>
                  <span>Marks: +2.0 / -0.5</span>
                </div>

                <div className="bg-slate-50 p-4 sm:p-5 rounded-2xl border border-slate-200">
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 leading-snug">
                    {currentQ.question}
                  </h3>
                </div>

                {/* Options List */}
                <div className="space-y-2">
                  {currentQ.options.map((opt, optIdx) => {
                    const isSelected = selectedAnswers[currentQ.id] === optIdx;
                    return (
                      <button
                        key={optIdx}
                        type="button"
                        onClick={() => handleSelectOption(optIdx)}
                        className={`w-full text-left p-3.5 rounded-xl border flex items-center gap-3 transition-all ${
                          isSelected
                            ? 'bg-amber-50 border-amber-500 ring-2 ring-amber-400 font-bold text-slate-950'
                            : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-800'
                        }`}
                      >
                        <span className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                          isSelected ? 'bg-amber-400 text-slate-950' : 'bg-slate-100 text-slate-600'
                        }`}>
                          {String.fromCharCode(65 + optIdx)}
                        </span>
                        <span className="text-xs sm:text-sm">{opt}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Control Actions */}
                <div className="pt-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleClearOption}
                      className="text-xs font-bold text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 px-3 py-2 rounded-xl transition-colors"
                    >
                      Clear Selection
                    </button>
                    <button
                      onClick={toggleMarkForReview}
                      className={`text-xs font-bold px-3 py-2 rounded-xl border transition-colors ${
                        markedForReview[currentQ.id]
                          ? 'bg-purple-100 text-purple-900 border-purple-300'
                          : 'bg-white text-purple-700 border-purple-200 hover:bg-purple-50'
                      }`}
                    >
                      {markedForReview[currentQ.id] ? 'Marked for Review ★' : 'Mark for Review'}
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      disabled={currentIndex === 0}
                      onClick={() => setCurrentIndex((prev) => Math.max(0, prev - 1))}
                      className="px-3 py-2 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 disabled:opacity-40"
                    >
                      <ChevronLeft className="w-4 h-4 inline" /> Prev
                    </button>
                    <button
                      disabled={currentIndex === totalQuestions - 1}
                      onClick={() => setCurrentIndex((prev) => Math.min(totalQuestions - 1, prev + 1))}
                      className="px-4 py-2 rounded-xl text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 disabled:opacity-40"
                    >
                      Next <ChevronRight className="w-4 h-4 inline" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Question Palette Sidebar */}
              <div className="lg:col-span-4 bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-4">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-700 block">
                  Question Navigation Palette
                </span>

                <div className="grid grid-cols-5 gap-2">
                  {mockTestData.questions.map((q, idx) => {
                    const isAnswered = selectedAnswers[q.id] !== undefined;
                    const isMarked = markedForReview[q.id];
                    const isCurrent = currentIndex === idx;

                    let bgClass = 'bg-white text-slate-700 border-slate-300';
                    if (isMarked) bgClass = 'bg-purple-600 text-white border-purple-700';
                    else if (isAnswered) bgClass = 'bg-emerald-600 text-white border-emerald-700';

                    return (
                      <button
                        key={q.id}
                        onClick={() => setCurrentIndex(idx)}
                        className={`w-9 h-9 rounded-lg font-bold text-xs border flex items-center justify-center transition-all ${bgClass} ${
                          isCurrent ? 'ring-2 ring-amber-400 scale-105' : ''
                        }`}
                      >
                        {idx + 1}
                      </button>
                    );
                  })}
                </div>

                {/* Legend */}
                <div className="pt-3 border-t border-slate-200 space-y-1.5 text-[11px] text-slate-600">
                  <div className="flex items-center gap-2">
                    <span className="w-3.5 h-3.5 rounded bg-emerald-600 shrink-0" />
                    <span>Answered ({Object.keys(selectedAnswers).length})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3.5 h-3.5 rounded bg-purple-600 shrink-0" />
                    <span>Marked for Review ({Object.values(markedForReview).filter(Boolean).length})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3.5 h-3.5 rounded bg-white border border-slate-300 shrink-0" />
                    <span>Unanswered</span>
                  </div>
                </div>

                {/* Final Submit */}
                <div className="pt-3 border-t border-slate-200">
                  <button
                    onClick={() => {
                      if (confirm('Are you ready to submit your test for scoring?')) {
                        handleSubmitTest();
                      }
                    }}
                    className="w-full bg-[#0B192C] hover:bg-slate-800 text-amber-400 font-black text-xs sm:text-sm py-3 rounded-xl shadow-md transition-colors"
                  >
                    Submit Test & View Results
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
