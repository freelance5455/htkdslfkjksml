import React from 'react';
import { Phone, AlertCircle, X } from 'lucide-react';
import { EmergencyServiceInfo } from '../types';

interface CallConfirmDialogProps {
  service: EmergencyServiceInfo | null;
  onCancel: () => void;
  onConfirm: (service: EmergencyServiceInfo) => void;
}

export const CallConfirmDialog: React.FC<CallConfirmDialogProps> = ({
  service,
  onCancel,
  onConfirm,
}) => {
  if (!service) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 animate-in fade-in duration-150">
      <div className="bg-slate-800 border border-slate-700 w-full max-w-sm rounded-2xl p-6 shadow-2xl space-y-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-rose-500/20 text-rose-500 rounded-xl">
            <Phone className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Call {service.title}?</h3>
            <p className="text-xs text-rose-400 font-bold">Helpline: {service.number}</p>
          </div>
        </div>

        <div className="text-sm text-slate-300 bg-slate-900/60 p-3 rounded-xl border border-slate-700/50">
          <p className="text-xs text-slate-400 mb-1">Purpose:</p>
          <p className="font-medium text-slate-200">{service.description}</p>
        </div>

        <p className="text-xs text-slate-400 flex items-center gap-1.5">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
          This will trigger your device phone dialer with <span className="font-mono text-white">tel:{service.number}</span>.
        </p>

        <div className="flex items-center gap-3 pt-2">
          <button
            onClick={onCancel}
            className="flex-1 py-2.5 rounded-xl border border-slate-600 text-slate-300 hover:bg-slate-700 text-sm font-semibold transition cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={() => onConfirm(service)}
            className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-sm font-bold shadow-lg shadow-rose-900/30 transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <Phone className="w-4 h-4" />
            Call {service.number}
          </button>
        </div>
      </div>
    </div>
  );
};
