import React, { useState } from 'react';
import { useData } from '../context/DataContext.tsx';
import { GalleryItem } from '../types/index.ts';
import {
  ArrowLeft,
  Download,
  ExternalLink,
  Code2,
  PenTool,
  Box,
  MessageSquare,
  Layers,
  Image as ImageIcon,
  X,
  Maximize2,
  Sparkles
} from 'lucide-react';

interface ProjectsPageProps {
  initialCategory?: string;
  onBack: () => void;
}

export const ProjectsPage: React.FC<ProjectsPageProps> = ({
  initialCategory,
  onBack
}) => {
  const { data } = useData();
  const [activeViewMode, setActiveViewMode] = useState<'projects' | 'gallery'>('projects');
  const [selectedCat, setSelectedCat] = useState<string>(initialCategory || 'all');
  const [lightboxItem, setLightboxItem] = useState<{
    title: string;
    imageUrl: string;
    category?: string;
    caption?: string;
    externalUrl?: string;
    downloadUrl?: string;
    fileName?: string;
  } | null>(null);

  const categories = [
    { id: 'all', name: 'All Work', icon: Layers },
    { id: 'web', name: 'Website Development', icon: Code2 },
    { id: 'design', name: 'Graphic Design', icon: PenTool },
    { id: 'minecraft', name: 'Minecraft Development', icon: Box },
    { id: 'discord', name: 'Discord Solutions', icon: MessageSquare }
  ];

  // Filter published projects
  const allProjects = (data.projects || []).filter((p) => p.published !== false);
  const filteredProjects = selectedCat === 'all'
    ? allProjects
    : allProjects.filter((p) => p.category === selectedCat);

  // Filter published gallery items
  const allGallery = (data.gallery || []).filter((g) => g.published !== false);
  const filteredGallery = selectedCat === 'all'
    ? allGallery
    : allGallery.filter((g) => g.category === selectedCat);

  const getCategoryTitle = () => {
    switch (selectedCat) {
      case 'web':
        return 'Website Development';
      case 'design':
        return 'Graphic Design';
      case 'minecraft':
        return 'Minecraft Development';
      case 'discord':
        return 'Discord Solutions';
      default:
        return 'Projects & Gallery Showcase';
    }
  };

  return (
    <div className="max-w-[1120px] mx-auto px-4 sm:px-6 py-10 sm:py-14 animate-fadeIn">
      {/* Navigation Header */}
      <div className="flex items-center justify-between mb-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-sm font-semibold text-slate-400 hover:text-cyan-400 transition-colors cursor-pointer group"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          <span>Back to Home</span>
        </button>

        <span className="text-xs font-mono text-cyan-400/80 bg-cyan-950/40 px-3 py-1 rounded-full border border-cyan-500/20">
          Studio Works &amp; Visuals
        </span>
      </div>

      {/* Header */}
      <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-12">
        <span className="text-xs font-mono font-bold tracking-widest text-cyan-400 uppercase bg-cyan-950/60 px-3.5 py-1 rounded-full border border-cyan-500/30">
          CUBIX PORTFOLIO &amp; SHOWCASE
        </span>
        <h1 className="text-4xl sm:text-6xl font-black text-white tracking-tight mt-4 mb-3 font-['Plus_Jakarta_Sans']">
          {getCategoryTitle()}
          <span className="text-cyan-400">.</span>
        </h1>
        <p className="text-slate-300 text-base sm:text-lg">
          Selected work, visual assets, and engineered systems managed by Cubix Studio across web, design, Minecraft, and Discord.
        </p>

        {/* View Mode Switcher: Projects vs Gallery */}
        <div className="inline-flex p-1 rounded-2xl bg-white/[0.04] border border-white/10 mt-6 gap-1">
          <button
            onClick={() => setActiveViewMode('projects')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeViewMode === 'projects'
                ? 'bg-cyan-400 text-slate-950 shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Projects &amp; Files ({allProjects.length})</span>
          </button>
          <button
            onClick={() => setActiveViewMode('gallery')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeViewMode === 'gallery'
                ? 'bg-cyan-400 text-slate-950 shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>Visual Media Gallery ({allGallery.length})</span>
          </button>
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 mb-12">
        {categories.map((cat) => {
          const Icon = cat.icon;
          const isSelected = selectedCat === cat.id;
          const count = activeViewMode === 'projects'
            ? (cat.id === 'all' ? allProjects.length : allProjects.filter((p) => p.category === cat.id).length)
            : (cat.id === 'all' ? allGallery.length : allGallery.filter((g) => g.category === cat.id).length);

          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCat(cat.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                isSelected
                  ? 'bg-cyan-500 text-slate-950 shadow-[0_0_20px_rgba(0,210,255,0.35)]'
                  : 'bg-white/[0.03] hover:bg-white/[0.08] text-slate-300 border border-white/10'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{cat.name}</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                  isSelected ? 'bg-slate-950/25 text-slate-950 font-extrabold' : 'bg-white/10 text-slate-400'
                }`}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* 1. PROJECTS VIEW */}
      {activeViewMode === 'projects' && (
        filteredProjects.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-7">
            {filteredProjects.map((p) => {
              const hasDownload = Boolean(p.fileUrl || p.fileName || p.fileData);
              const downloadHref = p.fileUrl || (p.fileName ? `/api/download/${p.fileName}` : p.fileData);

              return (
                <article
                  key={p.id}
                  className="p-7 sm:p-8 rounded-3xl bg-gradient-to-b from-[#08172c] to-[#040c17] border border-cyan-500/20 hover:border-cyan-400/50 transition-all duration-200 shadow-[0_15px_35px_rgba(0,0,0,0.4)] flex flex-col justify-between group"
                >
                  <div>
                    {/* Category Pill and Date */}
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-[11px] font-mono font-bold tracking-wider px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 uppercase">
                        {p.category}
                      </span>
                      {p.date && (
                        <span className="text-xs font-mono text-slate-500">
                          {p.date}
                        </span>
                      )}
                    </div>

                    {/* Thumbnail if provided (with clickable preview lightbox) */}
                    {p.thumbnail && (
                      <div
                        onClick={() =>
                          setLightboxItem({
                            title: p.name,
                            imageUrl: p.thumbnail!,
                            category: p.category,
                            caption: p.description,
                            externalUrl: p.externalUrl,
                            downloadUrl: downloadHref,
                            fileName: p.fileName
                          })
                        }
                        className="relative mb-4 rounded-xl overflow-hidden border border-white/10 max-h-52 cursor-pointer group/thumb"
                      >
                        <img
                          src={p.thumbnail}
                          alt={p.name}
                          className="w-full h-full object-cover transition-transform duration-300 group-hover/thumb:scale-105"
                        />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/thumb:opacity-100 flex items-center justify-center transition-opacity text-cyan-300 text-xs font-semibold gap-1.5 backdrop-blur-[2px]">
                          <Maximize2 className="w-4 h-4" />
                          <span>Expand Preview</span>
                        </div>
                      </div>
                    )}

                    {/* Title */}
                    <h2 className="text-2xl font-black text-white mb-2.5 tracking-tight">
                      {p.name}
                    </h2>

                    {/* Description */}
                    <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-5">
                      {p.description}
                    </p>

                    {/* Technologies / Tags */}
                    {p.tags && p.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 mb-5">
                        {p.tags.map((tag, tIdx) => (
                          <span
                            key={tIdx}
                            className="text-[11px] font-mono px-2.5 py-0.5 rounded-md bg-white/[0.03] text-slate-300 border border-white/10"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Footer Action Links */}
                  <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
                    {hasDownload && downloadHref ? (
                      <a
                        href={downloadHref}
                        download={p.fileName || `${p.name}.zip`}
                        className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs sm:text-sm transition-all shadow-[0_0_15px_rgba(0,210,255,0.3)] cursor-pointer"
                      >
                        <Download className="w-4 h-4" />
                        <span>Download {p.fileName || 'Asset'}</span>
                      </a>
                    ) : (
                      <span className="text-xs font-mono text-slate-500">
                        Verified delivery
                      </span>
                    )}

                    {p.externalUrl && (
                      <a
                        href={p.externalUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1.5 text-xs font-bold text-cyan-400 hover:text-cyan-300 transition-colors"
                      >
                        <span>Live Preview</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
        ) : (
          <div className="p-12 text-center rounded-3xl bg-[#061021]/80 border border-cyan-500/20 max-w-lg mx-auto">
            <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center mx-auto mb-4 border border-cyan-500/20">
              <Layers className="w-7 h-7" />
            </div>
            <h2 className="text-xl font-bold text-white mb-2">No projects found.</h2>
            <p className="text-slate-400 text-sm leading-relaxed">
              Projects in this category will appear here as they are published from the Cubix Studio management dashboard.
            </p>
          </div>
        )
      )}

      {/* 2. VISUAL MEDIA GALLERY VIEW */}
      {activeViewMode === 'gallery' && (
        filteredGallery.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {filteredGallery.map((g) => (
              <div
                key={g.id}
                onClick={() =>
                  setLightboxItem({
                    title: g.title,
                    imageUrl: g.imageUrl,
                    category: g.category,
                    caption: g.caption,
                    externalUrl: g.externalUrl
                  })
                }
                className="group relative rounded-2xl bg-[#061224] border border-white/10 hover:border-cyan-400/50 overflow-hidden cursor-pointer shadow-lg transition-all duration-200 flex flex-col justify-between"
              >
                <div className="relative aspect-video bg-black/60 overflow-hidden">
                  <img
                    src={g.imageUrl}
                    alt={g.title}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#061224] via-transparent to-transparent opacity-80" />
                  <span className="absolute top-3 left-3 text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded-full bg-cyan-950/80 text-cyan-300 border border-cyan-500/30">
                    {g.category}
                  </span>
                  <div className="absolute bottom-3 right-3 p-1.5 rounded-lg bg-black/60 text-white/80 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Maximize2 className="w-3.5 h-3.5" />
                  </div>
                </div>

                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-base font-bold text-white group-hover:text-cyan-300 transition-colors">
                      {g.title}
                    </h3>
                    {g.caption && (
                      <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                        {g.caption}
                      </p>
                    )}
                  </div>
                  <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between text-[11px] text-slate-500 font-mono">
                    <span>{g.createdAt || 'Showcase'}</span>
                    <span className="text-cyan-400 group-hover:underline flex items-center gap-1">
                      View Asset &rarr;
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-12 text-center rounded-3xl bg-[#061021]/80 border border-cyan-500/20 max-w-lg mx-auto">
            <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center mx-auto mb-4 border border-cyan-500/20">
              <ImageIcon className="w-7 h-7" />
            </div>
            <h2 className="text-xl font-bold text-white mb-2">Gallery media coming soon.</h2>
            <p className="text-slate-400 text-sm leading-relaxed">
              Showcase screenshots and design graphics uploaded in the Admin Panel will be displayed in this gallery.
            </p>
          </div>
        )
      )}

      {/* FULL RESOLUTION LIGHTBOX MODAL */}
      {lightboxItem && (
        <div
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn"
          onClick={() => setLightboxItem(null)}
        >
          <div
            className="relative max-w-4xl w-full bg-[#071324] border border-cyan-500/30 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Lightbox Header */}
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between bg-black/40">
              <div className="flex items-center gap-3">
                <span className="text-[10px] font-mono uppercase tracking-wider px-2.5 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  {lightboxItem.category || 'Asset'}
                </span>
                <h3 className="text-lg font-bold text-white truncate max-w-md">
                  {lightboxItem.title}
                </h3>
              </div>
              <button
                onClick={() => setLightboxItem(null)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Lightbox Image Stage */}
            <div className="flex-1 bg-black/70 flex items-center justify-center p-4 overflow-auto min-h-[300px]">
              <img
                src={lightboxItem.imageUrl}
                alt={lightboxItem.title}
                className="max-h-[60vh] max-w-full object-contain rounded-lg shadow-2xl border border-white/5"
              />
            </div>

            {/* Lightbox Details & Actions */}
            <div className="p-4 sm:p-5 border-t border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-black/40">
              <p className="text-xs text-slate-300 max-w-xl">
                {lightboxItem.caption || 'Cubix Studio engineered production asset.'}
              </p>
              <div className="flex items-center gap-2 shrink-0">
                {lightboxItem.downloadUrl && (
                  <a
                    href={lightboxItem.downloadUrl}
                    download={lightboxItem.fileName || 'asset.zip'}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-400 text-slate-950 font-bold text-xs hover:bg-cyan-300 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </a>
                )}
                {lightboxItem.externalUrl && (
                  <a
                    href={lightboxItem.externalUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition-colors"
                  >
                    <span>Visit Live</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
