import { ClubLogo } from "@/components/game/ClubLogo";
import { Btn } from "@/components/game/ui";
import { TEAM_BY_ID } from "@/lib/game/data/teams";
import {
  AMBIENT,
  chanceOf,
  expectedGoals,
  pickMoments,
  startChance,
  type MatchMoment,
  type MomentOption,
} from "@/lib/game/engine/match";
import { ratingColor } from "@/lib/game/format";
import { Sound } from "@/lib/game/sound";
import { useGame } from "@/lib/game/store";
import type { MatchResult } from "@/lib/game/types";
import { clamp, irand } from "@/lib/game/rng";
import { useEffect, useRef, useState } from "react";

const REAL = 45;
const MATCH_MIN = 90;

type Log = { t: string; kind: string; min: number };

type Live = {
  hg: number;
  ag: number;
  goals: number;
  assists: number;
  shots: number;
  keyPasses: number;
  tackles: number;
  yellow: boolean;
  red: boolean;
  minutesPlayed: number;
  onPitch: boolean;
};

export function MatchPlay() {
  const { career, pendingMatch, finishPlayedMatch, setScreen } = useGame();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [ended, setEnded] = useState<MatchResult | null>(null);
  const [minute, setMinute] = useState(0);
  const [log, setLog] = useState<Log[]>([]);
  const [moment, setMoment] = useState<MatchMoment | null>(null);
  const [benchMsg, setBenchMsg] = useState<string | null>(null);
  const live = useRef<Live>({
    hg: 0,
    ag: 0,
    goals: 0,
    assists: 0,
    shots: 0,
    keyPasses: 0,
    tackles: 0,
    yellow: false,
    red: false,
    minutesPlayed: 0,
    onPitch: false,
  });
  const paused = useRef(false);
  const startRef = useRef(0);
  const momentsRef = useRef<MatchMoment[]>([]);
  const fired = useRef(new Set<number>());
  const doneRef = useRef(false);

  useEffect(() => {
    if (!career || !pendingMatch) return;
    Sound.whistle();
    const chance = startChance(career.manager.trust, career.role);
    const starts = Math.random() < chance && career.role !== "bench";
    const benchMin = irand(Math.random, 35, 78);
    live.current.onPitch = starts;
    momentsRef.current = pickMoments(irand(Math.random, 15, 20), career.week * 17 + career.player.overall);
    startRef.current = performance.now();
    paused.current = false;
    pushLog(starts ? "Mac basladi. Ilk 11'densin." : "Yedek kulubesindesin.", starts ? "goal" : "key", 0);

    const home = TEAM_BY_ID[pendingMatch.home];
    const away = TEAM_BY_ID[pendingMatch.away];
    const meHome = pendingMatch.home === career.clubId;
    const hp = home?.power ?? 70;
    const ap = away?.power ?? 70;
    const xgH = expectedGoals(hp, ap, true);
    const xgA = expectedGoals(ap, hp, false);

    const balls = Array.from({ length: 22 }, (_, i) => ({
      x: i < 11 ? 0.28 + Math.random() * 0.2 : 0.52 + Math.random() * 0.2,
      y: 0.12 + (i % 11) * 0.07,
      tx: 0.5,
      ty: 0.5,
    }));
    const ball = { x: 0.5, y: 0.5, tx: 0.5, ty: 0.5 };

    let raf = 0;
    let lastAmbient = 0;
    const loop = (now: number) => {
      const cnv = canvasRef.current;
      if (!cnv) {
        raf = requestAnimationFrame(loop);
        return;
      }
      const ctx = cnv.getContext("2d");
      if (!ctx) return;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const w = cnv.clientWidth;
      const h = cnv.clientHeight;
      if (cnv.width !== Math.floor(w * dpr)) {
        cnv.width = Math.floor(w * dpr);
        cnv.height = Math.floor(h * dpr);
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      drawPitch(ctx, w, h);

      if (!paused.current && !doneRef.current) {
        const elapsed = (now - startRef.current) / 1000;
        const m = Math.min(MATCH_MIN, (elapsed / REAL) * MATCH_MIN);
        setMinute(Math.floor(m));
        if (live.current.onPitch) live.current.minutesPlayed = Math.floor(m) - (starts ? 0 : benchMin);
        if (!starts && !live.current.onPitch && m >= benchMin) {
          live.current.onPitch = true;
          setBenchMsg("Hoca seni cagirdi!");
          Sound.success();
          pushLog("Oyuna girdin.", "goal", Math.floor(m));
          setTimeout(() => setBenchMsg(null), 1800);
        }
        if (now - lastAmbient > 3500 + Math.random() * 3000) {
          lastAmbient = now;
          pushLog(AMBIENT[Math.floor(Math.random() * AMBIENT.length)]!, "key", Math.floor(m));
        }
        if (Math.random() < 0.004) {
          if (Math.random() < xgH / 90) {
            live.current.hg += 1;
            Sound.goal();
            pushLog((home?.name || "Ev") + " gol!", meHome ? "goal" : "concede", Math.floor(m));
          } else if (Math.random() < xgA / 90) {
            live.current.ag += 1;
            pushLog((away?.name || "Dep") + " gol!", meHome ? "concede" : "goal", Math.floor(m));
          }
        }
        for (const mom of momentsRef.current) {
          if (live.current.onPitch && m >= mom.minute && !fired.current.has(mom.minute)) {
            fired.current.add(mom.minute);
            paused.current = true;
            setMoment(mom);
            break;
          }
        }
        ball.x += (ball.tx - ball.x) * 0.04;
        ball.y += (ball.ty - ball.y) * 0.04;
        if (Math.random() < 0.02) {
          ball.tx = 0.18 + Math.random() * 0.64;
          ball.ty = 0.12 + Math.random() * 0.76;
        }
        balls.forEach((p, i) => {
          if (Math.random() < 0.03) {
            p.tx = clamp(p.x + (Math.random() - 0.5) * 0.12, i < 11 ? 0.12 : 0.4, i < 11 ? 0.6 : 0.88);
            p.ty = clamp(p.y + (Math.random() - 0.5) * 0.1, 0.08, 0.92);
          }
          p.x += (p.tx - p.x) * 0.05;
          p.y += (p.ty - p.y) * 0.05;
          const col = i < 11 ? (meHome ? "#6ea0d4" : "#d46a62") : meHome ? "#d46a62" : "#6ea0d4";
          const me = live.current.onPitch && i === 9;
          ctx.beginPath();
          ctx.arc(p.x * w, p.y * h, me ? 8 : 5.5, 0, Math.PI * 2);
          ctx.fillStyle = me ? "#d6ead6" : col;
          ctx.fill();
          if (me) {
            ctx.fillStyle = "#0b0c0b";
            ctx.font = "700 9px Barlow Condensed, sans-serif";
            ctx.textAlign = "center";
            ctx.fillText("SEN", p.x * w, p.y * h - 12);
          }
        });
        const g = ctx.createRadialGradient(ball.x * w, ball.y * h, 0, ball.x * w, ball.y * h, 16);
        g.addColorStop(0, "rgba(255,255,255,0.9)");
        g.addColorStop(1, "rgba(255,255,255,0)");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(ball.x * w, ball.y * h, 16, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(ball.x * w, ball.y * h, 5, 0, Math.PI * 2);
        ctx.fillStyle = "#f4f1ea";
        ctx.fill();

        if (m >= MATCH_MIN) {
          finish();
          return;
        }
      } else {
        balls.forEach((p, i) => {
          const col = i < 11 ? "#6ea0d4" : "#d46a62";
          ctx.beginPath();
          ctx.arc(p.x * w, p.y * h, 5.5, 0, Math.PI * 2);
          ctx.fillStyle = col;
          ctx.fill();
        });
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function pushLog(t: string, kind: string, min: number) {
    setLog((l) => [{ t, kind, min }, ...l].slice(0, 24));
  }

  function choose(opt: MomentOption) {
    if (!career || !moment) return;
    const attr = career.player.attrs[opt.attr] ?? 55;
    const ok = Math.random() < chanceOf(attr, career.player.form, career.player.fatigue);
    const L = live.current;
    if (ok) {
      Sound.success();
      if (opt.onSuccess?.goals) {
        L.goals += opt.onSuccess.goals;
        L.shots += opt.onSuccess.shots || 1;
        if (pendingMatch?.home === career.clubId) L.hg += 1;
        else L.ag += 1;
        Sound.goal();
      }
      if (opt.onSuccess?.assists) L.assists += opt.onSuccess.assists;
      if (opt.onSuccess?.shots) L.shots += opt.onSuccess.shots;
      if (opt.onSuccess?.keyPasses) L.keyPasses += opt.onSuccess.keyPasses;
      if (opt.onSuccess?.tackles) L.tackles += opt.onSuccess.tackles;
      pushLog(opt.success, opt.tone === "goal" ? "goal" : "key", moment.minute);
    } else {
      Sound.fail();
      if (opt.onFail?.shots) L.shots += opt.onFail.shots;
      if (opt.onFail?.yellow) {
        L.yellow = true;
        Sound.card();
      }
      if (opt.onFail?.concede) {
        if (pendingMatch?.home === career.clubId) L.ag += 1;
        else L.hg += 1;
      }
      pushLog(opt.fail, opt.tone === "warn" ? "warn" : "miss", moment.minute);
    }
    setMoment(null);
    paused.current = false;
    startRef.current += 0;
  }

  function finish() {
    if (!career || !pendingMatch || doneRef.current) return;
    doneRef.current = true;
    const L = live.current;
    const mins = Math.max(0, L.onPitch ? Math.max(L.minutesPlayed, 8) : 0);
    let rating = 6.1 + L.goals * 0.7 + L.assists * 0.4 + (L.shots > 2 ? 0.15 : 0);
    if (!L.onPitch) rating = 5.5;
    rating = clamp(Math.round(rating * 10) / 10, 4.8, 9.8);
    const res: MatchResult = {
      week: career.week,
      home: pendingMatch.home,
      away: pendingMatch.away,
      hg: L.hg,
      ag: L.ag,
      rating,
      goals: L.goals,
      assists: L.assists,
      minutes: mins,
      motm: rating >= 8.4,
      yellow: L.yellow,
      red: L.red,
      shots: L.shots,
      keyPasses: L.keyPasses,
      tackles: L.tackles,
      role: career.role,
    };
    paused.current = true;
    setEnded(res);
    Sound.whistle();
  }

  if (!career || !pendingMatch) {
    return (
      <div className="p-6">
        <Btn onClick={() => setScreen("career")}>Geri</Btn>
      </div>
    );
  }

  const home = TEAM_BY_ID[pendingMatch.home]!;
  const away = TEAM_BY_ID[pendingMatch.away]!;
  const L = live.current;

  if (ended) {
    return (
      <div className="mx-auto flex min-h-dvh max-w-lg flex-col justify-center px-5 py-8">
        <div className="text-center text-[12px] uppercase tracking-[0.2em] text-muted">Mac sonu</div>
        <div className="mt-3 flex items-center justify-center gap-4">
          <ClubLogo team={home} size={48} />
          <div className="font-display text-6xl tabular-nums">
            {ended.hg}-{ended.ag}
          </div>
          <ClubLogo team={away} size={48} />
        </div>
        <div
          className="mt-4 text-center font-display text-4xl tabular-nums"
          style={{ color: ratingColor(ended.rating) }}
        >
          {ended.rating.toFixed(1)}
        </div>
        <div className="mt-6 grid grid-cols-3 gap-2 text-center">
          {[
            ["Gol", ended.goals],
            ["Asist", ended.assists],
            ["Sut", ended.shots],
            ["Kilit pas", ended.keyPasses],
            ["Mudahale", ended.tackles],
            ["Dakika", ended.minutes],
          ].map(([k, v]) => (
            <div key={String(k)} className="rounded-[16px] bg-bg-elev py-3 hairline">
              <div className="text-[11px] text-muted">{k}</div>
              <div className="font-display text-2xl tabular-nums">{v}</div>
            </div>
          ))}
        </div>
        <Btn tone="primary" className="mt-8 h-12" onClick={() => finishPlayedMatch(ended)}>
          Kariyere don
        </Btn>
      </div>
    );
  }

  return (
    <div className="flex min-h-dvh flex-col bg-bg">
      <div className="flex items-center justify-between px-3 py-2">
        <div className="flex items-center gap-2">
          <ClubLogo team={home} size={24} />
          <span className="font-display text-2xl tabular-nums">
            {L.hg}-{L.ag}
          </span>
          <ClubLogo team={away} size={24} />
        </div>
        <div className="font-display text-xl tabular-nums">{Math.min(90, minute)}'</div>
      </div>
      <div className="relative mx-3 overflow-hidden rounded-[18px]">
        <canvas ref={canvasRef} className="block h-[42vh] w-full touch-none" />
        {benchMsg && (
          <div className="absolute inset-x-4 top-4 rounded-[14px] bg-accent px-3 py-2 text-center text-accent-fg">
            {benchMsg}
          </div>
        )}
      </div>
      {moment && (
        <div className="mx-3 mt-3 rounded-[22px] bg-bg-elev p-4 hairline">
          <div className="text-[12px] uppercase tracking-[0.16em] text-muted">{moment.minute}. dakika</div>
          <div className="mt-1 font-display text-2xl">{moment.prompt}</div>
          <div className="mt-3 grid gap-2">
            {moment.options.map((o) => (
              <Btn key={o.id} className="justify-start" onClick={() => choose(o)}>
                {o.label}
              </Btn>
            ))}
          </div>
        </div>
      )}
      <div className="min-h-0 flex-1 overflow-y-auto px-3 py-3">
        {log.map((l, i) => (
          <div
            key={i}
            className={
              "border-l-2 py-1 pl-3 text-[13px] " +
              (l.kind === "goal"
                ? "border-ok text-ok"
                : l.kind === "concede"
                  ? "border-danger text-danger"
                  : l.kind === "miss"
                    ? "border-warn text-warn"
                    : l.kind === "warn"
                      ? "border-warn text-warn"
                      : "border-line text-muted")
            }
          >
            <span className="tabular-nums">{l.min}' </span>
            {l.t}
          </div>
        ))}
      </div>
    </div>
  );
}

function drawPitch(ctx: CanvasRenderingContext2D, w: number, h: number) {
  const g = ctx.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, "#1b4a32");
  g.addColorStop(1, "#123526");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
  for (let i = 0; i < 8; i++) {
    ctx.fillStyle = i % 2 ? "rgba(255,255,255,0.025)" : "rgba(0,0,0,0.04)";
    ctx.fillRect((w / 8) * i, 0, w / 8, h);
  }
  ctx.strokeStyle = "rgba(245,245,240,0.55)";
  ctx.lineWidth = 1.4;
  const pad = 10;
  ctx.strokeRect(pad, pad, w - pad * 2, h - pad * 2);
  ctx.beginPath();
  ctx.moveTo(w / 2, pad);
  ctx.lineTo(w / 2, h - pad);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(w / 2, h / 2, h * 0.14, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(w / 2, h / 2, 2.4, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(245,245,240,0.8)";
  ctx.fill();
  const bw = w * 0.5;
  const bh = h * 0.36;
  const boxH = h * 0.16;
  ctx.strokeRect(pad, (h - bh) / 2, bw * 0.22, bh);
  ctx.strokeRect(w - pad - bw * 0.22, (h - bh) / 2, bw * 0.22, bh);
  ctx.strokeRect(pad, (h - boxH) / 2, bw * 0.08, boxH);
  ctx.strokeRect(w - pad - bw * 0.08, (h - boxH) / 2, bw * 0.08, boxH);
  ctx.beginPath();
  ctx.arc(pad + bw * 0.16, h / 2, 2, 0, Math.PI * 2);
  ctx.arc(w - pad - bw * 0.16, h / 2, 2, 0, Math.PI * 2);
  ctx.fill();
}
