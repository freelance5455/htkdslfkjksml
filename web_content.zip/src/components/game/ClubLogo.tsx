import type { Team } from "@/lib/game/types";

const SHIELD = "M50 5 L95 20 L95 62 Q95 100 50 115 Q5 100 5 62 L5 20 Z";

export function ClubLogo({ team, size = 48, className }: { team: Team; size?: number; className?: string }) {
  const id = "c" + team.id.replace(/[^a-z0-9]/g, "");
  return (
    <svg
      viewBox="0 0 100 120"
      width={size}
      height={Math.round(size * 1.2)}
      className={className}
      aria-hidden
    >
      <defs>
        <clipPath id={id}>
          <path d={SHIELD} />
        </clipPath>
      </defs>
      <path d={SHIELD} fill={team.c1} stroke="rgba(255,255,255,0.28)" strokeWidth="2.4" />
      <g clipPath={"url(#" + id + ")"}>
        <rect x="5" y="5" width="90" height="110" fill={team.c1} />
        {team.pattern === "ss" && (
          <>
            <rect x="20" y="5" width="12" height="110" fill={team.c2} />
            <rect x="44" y="5" width="12" height="110" fill={team.c2} />
            <rect x="68" y="5" width="12" height="110" fill={team.c2} />
          </>
        )}
        {team.pattern === "sd" && (
          <>
            <path d="M5 20 L95 115 L80 115 L5 35 Z" fill={team.c2} />
            <path d="M20 5 L95 85 L95 70 L35 5 Z" fill={team.c2} />
          </>
        )}
        {team.pattern === "sh" && <rect x="5" y="55" width="90" height="60" fill={team.c2} />}
        {team.pattern === "sc" && (
          <>
            <rect x="44" y="5" width="12" height="110" fill={team.c2} />
            <rect x="5" y="52" width="90" height="12" fill={team.c2} />
          </>
        )}
        {(team.pattern === "c" || team.pattern === "cr") && (
          <circle cx="50" cy="52" r="22" fill={team.c2} />
        )}
      </g>
      <path d={SHIELD} fill="none" stroke="rgba(0,0,0,0.35)" strokeWidth="1.2" />
      {team.emblem === "star" && (
        <polygon points="50,28 54,40 67,40 56,48 60,60 50,52 40,60 44,48 33,40 46,40" fill={team.c2} />
      )}
      {team.emblem === "crown" && (
        <path d="M34 52 L34 40 L42 48 L50 34 L58 48 L66 40 L66 52 Z" fill={team.c2} />
      )}
      {team.emblem === "eagle" && (
        <path d="M50 34 C40 40 32 46 30 54 C40 50 44 52 50 60 C56 52 60 50 70 54 C68 46 60 40 50 34 Z" fill={team.c2} />
      )}
      {team.emblem === "lion" && (
        <path d="M42 38 C42 30 58 30 58 38 L60 50 C60 58 40 58 40 50 Z" fill={team.c2} />
      )}
    </svg>
  );
}
