import { useMemo, useState } from "react";
import { money } from "@/lib/game/format";
import { playerWage } from "@/lib/game/player";
import type { PlayerData, Position } from "@/lib/game/types";
import { useGame } from "@/lib/game/store";
import { Btn, Field, inputClass, Ovr, Panel, StatusIcons } from "./primitives";

const POS: Position[] = ["GK", "CB", "LB", "RB", "CDM", "CM", "CAM", "LW", "RW", "ST"];

export function TransferView() {
  const game = useGame((s) => s.game)!;
  const bump = useGame((s) => s.bump);
  const flash = useGame((s) => s.flash);
  const bidPlayer = useGame((s) => s.bidPlayer);
  const setBidPlayer = useGame((s) => s.setBidPlayer);
  useGame((s) => s.tick);
  const [q, setQ] = useState("");
  const [pos, setPos] = useState<string>("ALL");
  const [tab, setTab] = useState<"market" | "squad">("market");
  const market = useMemo(() => game.market.list(game.state), [game, game.state.uid, game.state.week]);

  const list = market.filter((p) => {
    if (pos !== "ALL" && p.pos !== pos) return false;
    if (q && !p.name.toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  });

  const target = bidPlayer ? game.state.players[bidPlayer] : undefined;
  const [amount, setAmount] = useState(0);
  const [wage, setWage] = useState(0);

  function openBid(p: PlayerData) {
    setBidPlayer(p.id);
    setAmount(Math.round(p.value * 1.05));
    setWage(Math.round(playerWage(p.ovr, p.age) * 1.05));
  }

  function confirmBid() {
    if (!target) return;
    const r = game.bid(target.id, amount, wage);
    flash(r.message);
    if (r.ok) setBidPlayer(null);
    bump();
  }

  return (
    <div className="flex h-full flex-col gap-3 p-3">
      <div className="flex flex-wrap items-center gap-2">
        <Btn variant={tab === "market" ? "primary" : "soft"} onClick={() => setTab("market")}>
          Pazar
        </Btn>
        <Btn variant={tab === "squad" ? "primary" : "soft"} onClick={() => setTab("squad")}>
          Satış
        </Btn>
        <span className="text-xs text-muted">
          {game.state.transferOpen ? "Pencere açık" : "Pencere kapalı"}
        </span>
        <input
          className={inputClass + " ml-auto w-40"}
          placeholder="İsim ara"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <select className={inputClass} value={pos} onChange={(e) => setPos(e.target.value)}>
          <option value="ALL">Mevki</option>
          {POS.map((p) => (
            <option key={p}>{p}</option>
          ))}
        </select>
      </div>

      {tab === "market" ? (
        <Panel className="min-h-0 flex-1 overflow-auto">
          <table className="w-full text-left text-sm">
            <thead className="sticky top-0 bg-surface text-[11px] uppercase tracking-wide text-muted">
              <tr>
                <th className="px-3 py-2">Oyuncu</th>
                <th>Kulüp</th>
                <th>Yaş</th>
                <th>Değer</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {list.slice(0, 80).map((p) => {
                const club = game.state.clubs[p.clubId];
                return (
                  <tr key={p.id} className="border-t border-border">
                    <td className="px-3 py-2">
                      <div className="flex items-center gap-2">
                        <Ovr n={p.ovr} />
                        <span>
                          {p.name}
                          <span className="ml-2 text-[11px] text-muted">{p.pos}</span>
                        </span>
                      </div>
                    </td>
                    <td className="text-muted">{club?.short}</td>
                    <td className="tabular">{p.age}</td>
                    <td className="tabular">{money(p.value)}</td>
                    <td className="pr-3">
                      <Btn
                        className="min-h-9 px-2 text-xs"
                        disabled={!game.state.transferOpen}
                        onClick={() => openBid(p)}
                      >
                        Teklif
                      </Btn>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Panel>
      ) : (
        <Panel className="min-h-0 flex-1 overflow-auto">
          <ul>
            {game.userPlayers().map((p) => (
              <li
                key={p.id}
                className="flex items-center gap-2 border-b border-border px-3 py-2"
              >
                <Ovr n={p.ovr} />
                <span className="w-8 text-[11px] text-muted">{p.pos}</span>
                <span className="flex-1 truncate text-sm">
                  {p.name}{" "}
                  <span className="text-xs text-muted">{money(p.value)}</span>
                </span>
                <StatusIcons p={p} />
                <Btn
                  variant="soft"
                  className="min-h-9 px-2 text-xs"
                  onClick={() => {
                    const r = game.sell(p.id);
                    flash(r.message);
                    bump();
                  }}
                >
                  Sat
                </Btn>
              </li>
            ))}
          </ul>
        </Panel>
      )}

      {target ? (
        <div className="fixed inset-0 z-30 flex items-end justify-center bg-bg/70 p-4 sm:items-center">
          <Panel className="w-full max-w-md p-5">
            <h3 className="text-base font-semibold">{target.name}</h3>
            <p className="mb-4 text-xs text-muted">
              {target.pos} · {target.age} · {money(target.value)}
            </p>
            <div className="grid gap-3">
              <Field label="Transfer bedeli">
                <input
                  type="number"
                  className={inputClass}
                  value={amount}
                  onChange={(e) => setAmount(Number(e.target.value))}
                />
              </Field>
              <Field label="Haftalık ücret">
                <input
                  type="number"
                  className={inputClass}
                  value={wage}
                  onChange={(e) => setWage(Number(e.target.value))}
                />
              </Field>
            </div>
            <div className="mt-4 flex gap-2">
              <Btn variant="ghost" className="flex-1" onClick={() => setBidPlayer(null)}>
                Vazgeç
              </Btn>
              <Btn className="flex-1" onClick={confirmBid}>
                Gönder
              </Btn>
            </div>
          </Panel>
        </div>
      ) : null}
    </div>
  );
}
