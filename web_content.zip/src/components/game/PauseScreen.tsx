import { Button } from "@/components/ui/button";
import { useGameStore } from "@/game/store";
import { Volume2, VolumeX } from "lucide-react";

type Props = {
  onResume: () => void;
  onQuit: () => void;
  onMute: () => void;
};

export function PauseScreen({ onResume, onQuit, onMute }: Props) {
  const muted = useGameStore((s) => s.muted);
  const sensitivity = useGameStore((s) => s.sensitivity);
  const aimAssist = useGameStore((s) => s.aimAssist);
  const score = useGameStore((s) => s.score);
  const wave = useGameStore((s) => s.wave);

  return (
    <div className="absolute inset-0 z-30 flex items-end justify-center bg-bg/70 sm:items-center">
      <div className="mb-[max(1.5rem,env(safe-area-inset-bottom))] w-full max-w-md rounded-xl border border-border bg-surface p-6 sm:mb-0">
        <p className="font-display text-xs uppercase tracking-[0.3em] text-muted">Paused</p>
        <h2 className="mt-1 font-display text-3xl text-fg">Hold fast</h2>
        <p className="mt-2 font-display text-sm tabular-nums text-subtle">
          Wave {wave} · {score.toLocaleString()}
        </p>

        <label className="mt-6 block text-sm text-muted">
          Look sensitivity
          <input
            type="range"
            min={0.4}
            max={2}
            step={0.05}
            value={sensitivity}
            onChange={(e) => useGameStore.setState({ sensitivity: Number(e.target.value) })}
            className="mt-2 w-full accent-accent"
          />
        </label>

        <label className="mt-4 flex items-center gap-3 text-sm text-fg">
          <input
            type="checkbox"
            checked={aimAssist}
            onChange={(e) => useGameStore.setState({ aimAssist: e.target.checked })}
            className="size-4 accent-accent"
          />
          Aim assist
        </label>

        <div className="mt-6 flex flex-col gap-3">
          <Button size="lg" className="w-full" onClick={onResume}>
            Resume
          </Button>
          <div className="flex gap-3">
            <Button variant="secondary" className="flex-1" onClick={onMute}>
              {muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
              {muted ? "Unmute" : "Mute"}
            </Button>
            <Button variant="secondary" className="flex-1" onClick={onQuit}>
              Town square
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
