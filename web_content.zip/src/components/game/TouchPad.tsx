import { useRef } from "react";
import { Map, Pause, Rocket, Scan } from "lucide-react";
import type { TouchState } from "@/game/types";
import { useGameStore } from "@/game/store";

type Props = {
  onChange: (t: Partial<TouchState>) => void
  onWarp: () => void
  onPause: () => void
  onCatalog: () => void
};

export function TouchPad({ onChange, onWarp, onPause, onCatalog }: Props) {
  const stickRef = useRef<HTMLDivElement>(null);
  const pid = useRef<number | null>(null);
  const scanning = useGameStore((s) => s.hud.scanning);
  const canScan = useGameStore((s) => s.hud.canScan);

  const readStick = (clientX: number, clientY: number) => {
    const el = stickRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const nx = (clientX - (r.left + r.width / 2)) / (r.width * 0.5);
    const ny = (clientY - (r.top + r.height / 2)) / (r.height * 0.5);
    const x = Math.max(-1, Math.min(1, nx));
    const y = Math.max(-1, Math.min(1, ny));
    onChange({ steer: -x, throttle: -y });
  };

  return (
    <div className="pointer-events-none absolute inset-0 z-10 sm:hidden">
      <div
        ref={stickRef}
        className="pointer-events-auto absolute bottom-[max(1.25rem,env(safe-area-inset-bottom))] left-[max(1rem,env(safe-area-inset-left))] size-32 rounded-full border border-border bg-surface/70"
        onPointerDown={(e) => {
          pid.current = e.pointerId;
          e.currentTarget.setPointerCapture(e.pointerId);
          readStick(e.clientX, e.clientY);
        }}
        onPointerMove={(e) => {
          if (pid.current !== e.pointerId) return;
          readStick(e.clientX, e.clientY);
        }}
        onPointerUp={(e) => {
          if (pid.current !== e.pointerId) return;
          pid.current = null;
          onChange({ steer: 0, throttle: 0 });
        }}
        onPointerCancel={() => {
          pid.current = null;
          onChange({ steer: 0, throttle: 0 });
        }}
      >
        <div className="absolute inset-10 rounded-full border border-border-strong" />
      </div>

      <div className="pointer-events-auto absolute right-[max(0.75rem,env(safe-area-inset-right))] bottom-[max(1.25rem,env(safe-area-inset-bottom))] grid grid-cols-2 gap-2">
        <button
          type="button"
          className="size-14 rounded-lg border border-border bg-surface/80 text-fg"
          onPointerDown={() => onChange({ pitch: 1 })}
          onPointerUp={() => onChange({ pitch: 0 })}
          onPointerCancel={() => onChange({ pitch: 0 })}
        >
          Up
        </button>
        <button
          type="button"
          className={`size-14 rounded-lg border border-border bg-surface/80 text-fg ${canScan ? "border-accent" : ""}`}
          onPointerDown={() => onChange({ scan: true })}
          onPointerUp={() => onChange({ scan: false })}
          onPointerCancel={() => onChange({ scan: false })}
          aria-label="Scan"
        >
          <Scan className={`mx-auto size-5 ${scanning ? "text-accent" : ""}`} />
        </button>
        <button
          type="button"
          className="size-14 rounded-lg border border-border bg-surface/80 text-fg"
          onPointerDown={() => onChange({ pitch: -1 })}
          onPointerUp={() => onChange({ pitch: 0 })}
          onPointerCancel={() => onChange({ pitch: 0 })}
        >
          Dn
        </button>
        <button
          type="button"
          className="size-14 rounded-lg border border-border bg-surface/80 text-fg"
          onPointerDown={() => onChange({ boost: true })}
          onPointerUp={() => onChange({ boost: false })}
          onPointerCancel={() => onChange({ boost: false })}
        >
          Boost
        </button>
        <button
          type="button"
          className="size-14 rounded-lg border border-border bg-surface/80 text-fg"
          onClick={onWarp}
          aria-label="Warp"
        >
          <Rocket className="mx-auto size-5" />
        </button>
        <button
          type="button"
          className="size-14 rounded-lg border border-border bg-surface/80 text-fg"
          onClick={onCatalog}
          aria-label="Catalog"
        >
          <Map className="mx-auto size-5" />
        </button>
      </div>

      <button
        type="button"
        className="pointer-events-auto absolute top-[max(0.75rem,env(safe-area-inset-top))] right-[max(0.75rem,env(safe-area-inset-right))] size-11 rounded-md border border-border bg-surface/80"
        onClick={onPause}
        aria-label="Pause"
      >
        <Pause className="mx-auto size-4" />
      </button>
    </div>
  );
}
