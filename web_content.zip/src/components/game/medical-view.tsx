import { money } from "@/lib/game/format";
import { useGame } from "@/lib/game/store";
import { Activity } from "lucide-react";
import { Btn, Meter, Ovr, Panel, StatusIcons } from "./primitives";

const COST = [0, 0, 2_000_000, 5_500_000, 13_000_000, 28_000_000];
const RED = [0, 0, 10, 18, 26, 35];

export function MedicalView() {
  const game = useGame((s) => s.game)!;
  const bump = useGame((s) => s.bump);
  const flash = useGame((s) => s.flash);
  useGame((s) => s.tick);
  const user = game.user();
  const squad = game.userPlayers();
  const injured = squad.filter((p) => p.inj);
  const banned = squad.filter((p) => p.ban > 0);
  const tired = squad.filter((p) => p.energy < 70 && !p.inj);

  return (
    <div className="mx-auto grid max-w-5xl gap-3 p-3 lg:grid-cols-[1fr_280px]">
      <div className="flex flex-col gap-3">
        <Panel className="p-4">
          <div className="mb-3 flex items-center gap-2">
            <Activity className="size-4 text-danger" />
            <h2 className="text-sm font-semibold">Sakat kadro</h2>
            <span className="text-xs text-muted">{injured.length} oyuncu</span>
          </div>
          {injured.length === 0 ? (
            <p className="text-sm text-muted">Revir boş. Kondisyonu düşük oyuncuları dinlendirin.</p>
          ) : (
            <ul className="divide-y divide-border">
              {injured.map((p) => (
                <li key={p.id} className="flex items-center gap-2 py-2">
                  <Ovr n={p.ovr} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm">
                      {p.name} <StatusIcons p={p} />
                    </p>
                    <p className="text-[11px] text-muted">
                      {p.inj?.label} · {p.inj?.weeksLeft} hafta kaldı
                    </p>
                    <Meter
                      value={
                        p.inj
                          ? ((p.inj.originalWeeks - p.inj.weeksLeft) / p.inj.originalWeeks) *
                            100
                          : 0
                      }
                      tone="danger"
                    />
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Panel>

        <Panel className="p-4">
          <h2 className="mb-3 text-sm font-semibold">Cezalılar ve kartlar</h2>
          {banned.length === 0 && squad.every((p) => p.yellows === 0) ? (
            <p className="text-sm text-muted">Aktif ceza yok. 4 sarı = 1 maç, kırmızı = 2 maç.</p>
          ) : (
            <ul className="divide-y divide-border">
              {squad
                .filter((p) => p.ban > 0 || p.yellows > 0)
                .map((p) => (
                  <li key={p.id} className="flex items-center justify-between py-2 text-sm">
                    <span>
                      {p.name}{" "}
                      <span className="text-xs text-muted">
                        {p.yellows} sarı
                      </span>
                    </span>
                    <span className="text-xs text-danger">
                      {p.ban > 0 ? `${p.ban} maç ceza` : ""}
                    </span>
                  </li>
                ))}
            </ul>
          )}
        </Panel>

        <Panel className="p-4">
          <h2 className="mb-3 text-sm font-semibold">Düşük kondisyon (sakatlık riski)</h2>
          <ul className="divide-y divide-border">
            {tired.slice(0, 8).map((p) => (
              <li key={p.id} className="flex items-center gap-3 py-2">
                <span className="w-28 truncate text-sm">{p.name}</span>
                <div className="flex-1">
                  <Meter value={p.energy} />
                </div>
                <span className="tabular text-xs text-muted">{Math.round(p.energy)}%</span>
              </li>
            ))}
            {tired.length === 0 ? (
              <li className="text-sm text-muted">Kondisyonlar yerinde.</li>
            ) : null}
          </ul>
        </Panel>
      </div>

      <Panel className="h-fit p-4">
        <h2 className="text-sm font-semibold">Sağlık ekibi</h2>
        <p className="mt-1 text-3xl font-semibold tabular">Sv {user.medical}</p>
        <p className="mt-2 text-xs text-muted">
          İyileşme süresi {RED[user.medical]}% daha kısa. Seviye 5’te %35.
        </p>
        {user.medical < 5 ? (
          <Btn
            className="mt-4 w-full"
            onClick={() => {
              const err = game.upgrade("medical");
              flash(err ?? `Sağlık ekibi seviye ${user.medical}`);
              bump();
            }}
          >
            Yükselt · {money(COST[user.medical + 1] ?? 0)}
          </Btn>
        ) : (
          <p className="mt-4 text-xs text-ok">Maksimum seviye</p>
        )}
      </Panel>
    </div>
  );
}
