import { COUNTRY_NAME, POS_TR } from "@/lib/game/constants";
import { ageFromDob, cardTier } from "@/lib/game/format";
import type { Player } from "@/lib/game/types";
import { cn } from "@/lib/utils";

export function PlayerCard({
  player,
  date,
  compact,
}: {
  player: Player;
  date: string;
  compact?: boolean;
}) {
  const tier = cardTier(player.overall);
  const age = ageFromDob(player.dob, date);
  return (
    <div
      className={cn(
        "relative overflow-hidden text-black shadow-[0_18px_40px_rgba(0,0,0,0.35)]",
        compact ? "rounded-[18px] p-3" : "rounded-[28px] p-4 sm:p-5",
        "card-" + tier,
      )}
    >
      <div className="pointer-events-none absolute -right-4 top-2 font-display text-[88px] leading-none text-black/10">
        {player.number}
      </div>
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="font-display text-[11px] uppercase tracking-[0.22em] text-black/55">{tier}</div>
          <div className={cn("font-display leading-none tracking-tight", compact ? "text-2xl" : "text-3xl sm:text-4xl")}>
            {player.displayName}
          </div>
          <div className="mt-1 text-[12px] font-medium text-black/65">
            {POS_TR[player.pos]} · {COUNTRY_NAME[player.nat] || player.nat} · {age} yas
          </div>
        </div>
        <div className="text-right">
          <div className={cn("font-display tabular-nums leading-none", compact ? "text-4xl" : "text-5xl")}>
            {player.overall}
          </div>
          <div className="text-[10px] font-semibold uppercase tracking-[0.18em] text-black/55">OVR</div>
        </div>
      </div>
      {!compact && (
        <div className="mt-4 flex gap-4 text-[12px] font-medium text-black/70">
          <span>POT {player.potential}</span>
          <span>{player.height} cm</span>
          <span>{player.foot === "left" ? "Sol ayak" : "Sag ayak"}</span>
        </div>
      )}
    </div>
  );
}
