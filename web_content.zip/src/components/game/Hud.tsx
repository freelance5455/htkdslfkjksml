import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { useGameStore } from "@/game/store";
import { Pause } from "lucide-react";
import { cn } from "@/lib/utils";

type Props = {
  onPause: () => void;
};

export function Hud({ onPause }: Props) {
  const health = useGameStore((s) => s.health);
  const maxHealth = useGameStore((s) => s.maxHealth);
  const ammo = useGameStore((s) => s.ammo);
  const reserve = useGameStore((s) => s.reserve);
  const reloading = useGameStore((s) => s.reloading);
  const score = useGameStore((s) => s.score);
  const wave = useGameStore((s) => s.wave);
  const banner = useGameStore((s) => s.banner);
  const hitmarkerAt = useGameStore((s) => s.hitmarkerAt);
  const hurtAt = useGameStore((s) => s.hurtAt);
  const [now, setNow] = useState(() => 0);

  useEffect(() => {
    if (!hitmarkerAt && !hurtAt) return;
    const t = window.setInterval(() => setNow(performance.now()), 80);
    return () => clearInterval(t);
  }, [hitmarkerAt, hurtAt]);

  const hitOn = now - hitmarkerAt < 140 && hitmarkerAt > 0;
  const hurtFade = hurtAt > 0 ? Math.max(0, 1 - (now - hurtAt) / 450) : 0;
  const low = health < 35;

  return (
    <div className="pointer-events-none absolute inset-0 z-10">
      <div
        className="absolute inset-0 bg-danger transition-opacity duration-150"
        style={{ opacity: Math.min(0.45, hurtFade * 0.4 + (low ? 0.12 : 0)) }}
      />

      <div className="absolute left-4 top-4 pt-[env(safe-area-inset-top)] sm:left-6 sm:top-6">
        <p className="font-display text-xs uppercase tracking-[0.28em] text-muted">Wave {wave}</p>
        <p className="mt-1 font-display text-xl tabular-nums text-fg">{score.toLocaleString()}</p>
      </div>

      <div className="absolute right-4 top-4 pt-[env(safe-area-inset-top)] sm:right-6">
        <Button
          variant="secondary"
          size="icon"
          className="pointer-events-auto"
          aria-label="Pause"
          onClick={onPause}
        >
          <Pause className="size-4" />
        </Button>
      </div>

      <div className="absolute left-1/2 top-5 w-40 -translate-x-1/2 pt-[env(safe-area-inset-top)] sm:w-56">
        <div className="h-2 overflow-hidden rounded-xs bg-health-track">
          <div
            className="h-full bg-health transition-[width] duration-150"
            style={{ width: `${Math.max(0, (health / maxHealth) * 100)}%` }}
          />
        </div>
      </div>

      {banner ? (
        <p className="absolute left-1/2 top-[18%] -translate-x-1/2 font-display text-2xl tracking-display text-balance text-fg">
          {banner}
        </p>
      ) : null}

      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
        <div className={cn("relative size-7", hitOn ? "opacity-100" : "opacity-80")}>
          <span className="absolute left-1/2 top-0 h-2 w-px -translate-x-1/2 bg-accent" />
          <span className="absolute bottom-0 left-1/2 h-2 w-px -translate-x-1/2 bg-accent" />
          <span className="absolute left-0 top-1/2 h-px w-2 -translate-y-1/2 bg-accent" />
          <span className="absolute right-0 top-1/2 h-px w-2 -translate-y-1/2 bg-accent" />
          {hitOn ? <span className="absolute inset-0 rotate-45 border border-accent" /> : null}
        </div>
      </div>

      <div className="absolute bottom-44 right-5 text-right sm:bottom-8 sm:right-8">
        <p className="font-display text-xs uppercase tracking-[0.22em] text-muted">
          {reloading ? "Reloading" : "Cylinder"}
        </p>
        <div className="mt-2 flex justify-end gap-1.5">
          {Array.from({ length: 6 }).map((_, i) => (
            <span
              key={i}
              className={cn(
                "size-2.5 rounded-full border border-border-strong",
                i < ammo ? "bg-accent" : "bg-transparent",
              )}
            />
          ))}
        </div>
        <p className="mt-1 font-display text-sm tabular-nums text-subtle">{reserve}</p>
      </div>
    </div>
  );
}
