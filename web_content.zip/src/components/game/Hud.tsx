import { Layers3, Map, Pause, Rocket } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useGameStore } from "@/game/store";
import { KIND_LABEL } from "@/game/catalog";
import type { BodyKind } from "@/game/types";

const DIMENSION_LABELS = [
  "Off",
  "Ripple Field",
  "4D Hypersphere",
  "Phase Slice",
  "Tesseract",
  "5D Quantum Manifold",
] as const;

export function Hud({
  onPause,
  onCatalog,
  onWarp,
  onDimension,
  onSlice,
}: {
  onPause: () => void
  onCatalog: () => void
  onWarp: () => void
  onDimension: (mode: number) => void
  onSlice: (w: number, v: number) => void
}) {
  const hud = useGameStore((s) => s.hud);
  const xpPct = hud.xpSpan <= 0 ? 100 : Math.max(0, Math.min(100, (hud.xpInto / hud.xpSpan) * 100));
  const missionPct = hud.missionGoal <= 0 ? 100 : Math.max(0, Math.min(100, (hud.missionProgress / hud.missionGoal) * 100));

  return (
    <div className="pointer-events-none absolute inset-0 z-10 p-3 pt-[max(0.75rem,env(safe-area-inset-top))] pr-[max(0.75rem,env(safe-area-inset-right))] pb-[max(0.75rem,env(safe-area-inset-bottom))] pl-[max(0.75rem,env(safe-area-inset-left))]">
      <div className="flex items-start justify-between gap-3">
        <div className="w-min max-w-[min(24rem,calc(100vw-7.5rem))] rounded-xl border border-border-strong bg-surface/90 px-3 py-2.5 shadow-2xl backdrop-blur-md">
          <p className="font-mono text-2xs tracking-[0.16em] text-muted uppercase">
            Mission · {hud.missionProgress}/{hud.missionGoal}
          </p>
          <p className="mt-1 text-sm font-medium text-fg">{hud.missionTitle}</p>
          <p className="mt-0.5 text-xs leading-snug text-muted">{hud.missionText}</p>
          <div className="mt-2 h-0.5 overflow-hidden rounded-full bg-surface-2">
            <div className="h-full bg-accent transition-[width] duration-200" style={{ width: `${missionPct}%` }} />
          </div>
        </div>

        <div className="pointer-events-auto flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={onCatalog} aria-label="Open Atlas menu">
            <Map className="size-4" />
            <span className="hidden sm:inline">Atlas Menu</span>
          </Button>
          <Button variant="outline" size="icon" onClick={onPause} aria-label="Pause">
            <Pause className="size-4" />
          </Button>
        </div>
      </div>

      <div className="pointer-events-none absolute top-3 left-1/2 w-40 -translate-x-1/2 sm:hidden">
        <div className="flex justify-between font-mono text-2xs text-muted">
          <span>{hud.rank}</span>
          <span className="tabular-nums">{Math.round(hud.hull * 100)}%</span>
        </div>
        <div className="mt-1 h-1 overflow-hidden rounded-full bg-surface">
          <div className="h-full bg-ok" style={{ width: `${hud.hull * 100}%` }} />
        </div>
      </div>

      <div className="pointer-events-none absolute top-3 left-1/2 hidden w-56 -translate-x-1/2 sm:block">
        <div className="flex justify-between font-mono text-2xs text-muted">
          <span>{hud.rank}</span>
          <span>{hud.xp} XP</span>
        </div>
        <div className="mt-1 h-1 overflow-hidden rounded-full bg-surface">
          <div className="h-full bg-accent" style={{ width: `${xpPct}%` }} />
        </div>
      </div>

      <div className="mt-3 hidden w-56 rounded-xl border border-border-strong bg-surface/90 p-2.5 shadow-xl backdrop-blur-md sm:block">
        <dl className="grid grid-cols-2 gap-x-3 gap-y-1.5 font-mono text-2xs">
          <div><dt className="text-subtle uppercase tracking-wider">Speed</dt><dd className="text-sm text-fg tabular-nums">{hud.speed.toFixed(0)}</dd></div>
          <div><dt className="text-subtle uppercase tracking-wider">FPS</dt><dd className="text-sm text-fg tabular-nums">{hud.fps.toFixed(0)}</dd></div>
          <div><dt className="text-subtle uppercase tracking-wider">Hull</dt><dd className="text-sm text-fg tabular-nums">{Math.round(hud.hull * 100)}%</dd></div>
          <div><dt className="text-subtle uppercase tracking-wider">Boost</dt><dd className="text-sm text-fg tabular-nums">{Math.round(hud.boost * 100)}%</dd></div>
          <div><dt className="text-subtle uppercase tracking-wider">Charted</dt><dd className="text-sm text-fg tabular-nums">{hud.discovered}/{hud.total}</dd></div>
          <div><dt className="text-subtle uppercase tracking-wider">Credits</dt><dd className="text-sm text-fg tabular-nums">{hud.credits}</dd></div>
        </dl>
        <div className="mt-2 h-1 overflow-hidden rounded-full bg-surface-2"><div className="h-full bg-ok" style={{ width: `${hud.hull * 100}%` }} /></div>
      </div>

      <div className="absolute top-24 right-3 hidden max-w-64 rounded-xl border border-border-strong bg-surface/90 p-2.5 shadow-xl backdrop-blur-md md:block">
        <p className="font-mono text-2xs tracking-[0.14em] text-muted uppercase">Nearest signal</p>
        <p className="mt-1 text-sm text-fg">{hud.nearestName}</p>
        <p className="font-mono text-2xs text-subtle">{KIND_LABEL[hud.nearestKind as BodyKind] ?? hud.nearestKind} · {hud.nearestDist.toFixed(0)} u</p>
        <p className="mt-2 font-mono text-2xs text-muted">{hud.canScan ? (hud.scanning ? "Scanning…" : "Hold E / Space to scan") : "Close in to scan"}</p>
      </div>

      <div className="pointer-events-auto absolute bottom-36 left-1/2 flex w-[min(36rem,calc(100vw-1.5rem))] -translate-x-1/2 items-center gap-2 rounded-xl border border-border-strong bg-surface/85 p-2 shadow-xl backdrop-blur-md sm:bottom-28">
        <Layers3 className="hidden size-4 shrink-0 text-accent sm:block" />
        <select
          value={hud.dimension}
          onChange={(e) => onDimension(Number(e.target.value))}
          className="min-w-0 flex-1 rounded-md border border-border bg-surface-2 px-2 py-2 text-xs text-fg outline-none"
          aria-label="Dimension visualization"
        >
          {DIMENSION_LABELS.map((label, i) => <option key={label} value={i}>{i === 0 ? "Dimension: Off" : `Dimension ${i} · ${label}`}</option>)}
        </select>
        <label className="hidden min-w-28 items-center gap-2 sm:flex">
          <span className="font-mono text-2xs text-subtle">W</span>
          <input type="range" min={-1} max={1} step={0.01} value={hud.wSlice} onChange={(e) => onSlice(Number(e.target.value), hud.vPhase)} className="w-full accent-[var(--color-accent)]" />
        </label>
        <label className="hidden min-w-28 items-center gap-2 sm:flex">
          <span className="font-mono text-2xs text-subtle">V</span>
          <input type="range" min={-1} max={1} step={0.01} value={hud.vPhase} onChange={(e) => onSlice(hud.wSlice, Number(e.target.value))} className="w-full accent-[var(--color-accent)]" />
        </label>
      </div>

      {hud.markers.map((m) => {
        if (m.offscreen) return null;
        return (
          <div key={m.id} className="absolute hidden -translate-x-1/2 -translate-y-1/2 md:block" style={{ left: m.x, top: m.y }}>
            <div className={`size-1.5 rounded-full ${m.discovered ? "bg-ok" : "bg-accent"}`} />
            {m.dist < 70 && <p className="mt-1 max-w-44 truncate whitespace-nowrap font-mono text-2xs text-muted">{m.name}</p>}
          </div>
        );
      })}

      {hud.toastOn && (
        <div className="absolute top-1/2 left-1/2 w-[min(20rem,80vw)] -translate-x-1/2 -translate-y-1/2 rounded-xl border border-border-strong bg-surface/95 px-4 py-3 text-center shadow-2xl backdrop-blur-md">
          <p className="text-sm font-medium text-fg">{hud.toastTitle}</p>
          <p className="mt-1 text-xs text-muted">{hud.toastText}</p>
        </div>
      )}

      {hud.phase === "complete" && (
        <div className="pointer-events-auto absolute inset-x-0 bottom-36 mx-auto w-[min(24rem,90vw)] rounded-xl border border-border-strong bg-surface/95 p-4 text-center shadow-2xl">
          <p className="text-sm font-medium">Atlas complete</p>
          <p className="mt-1 text-xs text-muted">All 119 atlas bodies are chartable. Keep flying and switch dimensions for the higher-order view.</p>
        </div>
      )}

      <div className="pointer-events-auto absolute right-3 bottom-20 hidden sm:block">
        <Button variant="outline" size="sm" onClick={onWarp} disabled={hud.targetId == null || hud.warping}>
          <Rocket className="size-3.5" />
          Warp {hud.targetName === "None" ? "" : hud.targetName}
        </Button>
      </div>
    </div>
  );
}
