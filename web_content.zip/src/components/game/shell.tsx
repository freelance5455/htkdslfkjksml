import type { ReactNode } from "react";
import {
  Activity,
  ArrowLeftRight,
  Building2,
  Play,
  Shield,
  Trophy,
  Users,
} from "lucide-react";
import { money, seasonDate, confTone, objectiveLabel, leagueName } from "@/lib/game/format";
import type { ScreenId } from "@/lib/game/types";
import { useGame } from "@/lib/game/store";
import { cn } from "@/lib/utils";
import { Crest, Meter } from "./primitives";

const NAV: { id: ScreenId; label: string; icon: typeof Users }[] = [
  { id: "squad", label: "Kadro", icon: Users },
  { id: "tactics", label: "Taktik", icon: Shield },
  { id: "transfer", label: "Transfer", icon: ArrowLeftRight },
  { id: "europe", label: "Avrupa", icon: Trophy },
  { id: "medical", label: "Revir", icon: Activity },
  { id: "club", label: "Kulüp", icon: Building2 },
  { id: "match", label: "Maç", icon: Play },
];

export function Shell({ children }: { children: ReactNode }) {
  const game = useGame((s) => s.game)!;
  const screen = useGame((s) => s.screen);
  const setScreen = useGame((s) => s.setScreen);
  useGame((s) => s.tick);
  const user = game.user();
  const table = game.leagueTable(user.league);
  const pos = table.findIndex((c) => c.id === user.id) + 1;
  const next = game.nextUserFixture();

  return (
    <div className="flex h-dvh flex-col bg-bg text-fg">
      <header className="flex items-center gap-3 border-b border-border bg-panel px-3 py-2 sm:px-4">
        <Crest club={user} size={40} />
        <div className="min-w-0 flex-1">
          <div className="flex items-baseline gap-2">
            <h1 className="truncate text-sm font-semibold sm:text-base">{user.name}</h1>
            <span className="hidden text-xs text-muted sm:inline">
              {leagueName(user.league)} · {pos}. sıra
            </span>
          </div>
          <div className="mt-0.5 flex items-center gap-3 text-[11px] text-muted">
            <span className="tabular">{seasonDate(game.state.season, game.state.week)}</span>
            <span className="tabular text-fg">{money(user.balance)}</span>
            <span className="hidden sm:inline">{objectiveLabel(game.state.objective)}</span>
          </div>
        </div>
        <div className="w-24 shrink-0 sm:w-32">
          <div className="mb-1 flex justify-between text-[10px] uppercase tracking-wide">
            <span className="text-muted">Yönetim</span>
            <span className={cn("tabular font-medium", confTone(game.state.board))}>
              {game.state.board}%
            </span>
          </div>
          <Meter value={game.state.board} />
        </div>
        {next && screen !== "match" ? (
          <button
            onClick={() => setScreen("match")}
            className="hidden min-h-11 rounded-sm bg-accent px-3 text-xs font-medium text-accent-fg sm:inline-flex sm:items-center"
          >
            Sıradaki maç
          </button>
        ) : null}
      </header>

      <main className="min-h-0 flex-1 overflow-auto">{children}</main>

      <nav className="grid grid-cols-7 border-t border-border bg-panel pb-[env(safe-area-inset-bottom)]">
        {NAV.map((n) => {
          const Icon = n.icon;
          const on = screen === n.id;
          return (
            <button
              key={n.id}
              onClick={() => setScreen(n.id)}
              className={cn(
                "flex min-h-12 flex-col items-center justify-center gap-0.5 text-[10px]",
                on ? "text-fg" : "text-muted",
              )}
            >
              <Icon className={cn("size-4", on ? "text-accent" : "")} strokeWidth={1.75} />
              {n.label}
            </button>
          );
        })}
      </nav>
    </div>
  );
}
