import { useRef, useState, type PointerEvent } from "react";
import { useMobileLayout } from "@/components/game/useMobileLayout";
import { cn } from "@/lib/utils";
import { RotateCcw } from "lucide-react";

type Props = {
  onMove: (x: number, y: number) => void;
  onFire: (held: boolean) => void;
  onReload: () => void;
};

export function TouchControls({ onMove, onFire, onReload }: Props) {
  const mobile = useMobileLayout();
  if (!mobile) return null;

  return (
    <div className="pointer-events-none absolute inset-0 z-20">
      <Stick onMove={onMove} />
      <button
        type="button"
        aria-label="Reload"
        className="pointer-events-auto absolute right-6 bottom-36 flex size-14 items-center justify-center rounded-full border border-border-strong bg-surface/80 text-fg"
        onPointerDown={(e) => {
          e.preventDefault();
          e.stopPropagation();
          onReload();
        }}
      >
        <RotateCcw className="size-5" />
      </button>
      <button
        type="button"
        aria-label="Fire"
        className="pointer-events-auto absolute bottom-20 right-5 flex size-20 items-center justify-center rounded-full border border-accent/40 bg-danger font-display text-sm tracking-wide text-fg"
        onPointerDown={(e) => {
          e.preventDefault();
          e.stopPropagation();
          onFire(true);
        }}
        onPointerUp={(e) => {
          e.preventDefault();
          onFire(false);
        }}
        onPointerCancel={() => onFire(false)}
        onPointerLeave={() => onFire(false)}
      >
        Fire
      </button>
    </div>
  );
}

function Stick({ onMove }: { onMove: (x: number, y: number) => void }) {
  const baseRef = useRef<HTMLDivElement>(null);
  const pid = useRef<number | null>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });

  const apply = (clientX: number, clientY: number) => {
    const el = baseRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const max = rect.width / 2 - 10;
    const mag = Math.hypot(dx, dy);
    if (mag > max) {
      dx = (dx / mag) * max;
      dy = (dy / mag) * max;
    }
    setKnob({ x: dx, y: dy });
    onMove(dx / max, -dy / max);
  };

  const reset = () => {
    pid.current = null;
    setKnob({ x: 0, y: 0 });
    onMove(0, 0);
  };

  const down = (e: PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    pid.current = e.pointerId;
    e.currentTarget.setPointerCapture(e.pointerId);
    apply(e.clientX, e.clientY);
  };

  const move = (e: PointerEvent<HTMLDivElement>) => {
    if (pid.current !== e.pointerId) return;
    apply(e.clientX, e.clientY);
  };

  return (
    <div
      ref={baseRef}
      className="pointer-events-auto absolute bottom-16 left-5 size-28 rounded-full border border-border-strong bg-surface/50"
      aria-label="Move"
      onPointerDown={down}
      onPointerMove={move}
      onPointerUp={reset}
      onPointerCancel={reset}
      style={{ marginBottom: "env(safe-area-inset-bottom)" }}
    >
      <div
        className={cn("absolute size-12 rounded-full bg-accent/90")}
        style={{
          left: "50%",
          top: "50%",
          transform: `translate(-50%, -50%) translate(${knob.x}px, ${knob.y}px)`,
        }}
      />
    </div>
  );
}
