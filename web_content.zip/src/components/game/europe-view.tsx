import { useState } from "react";
import { compLabel, leagueName } from "@/lib/game/format";
import type { Comp } from "@/lib/game/types";
import { groupTable } from "@/lib/game/uefa";
import { useGame } from "@/lib/game/store";
import { cn } from "@/lib/utils";
import { Crest, Panel } from "./primitives";

type Tab = "rank" | "table" | "fix" | Comp;

export function EuropeView() {
  const game = useGame((s) => s.game)!;
  useGame((s) => s.tick);
  const [tab, setTab] = useState<Tab>("rank");
  const user = game.user();
  const ranked = game.uefa.ranked(game.state.countries);

  return (
    <div className="flex h-full flex-col gap-3 p-3">
      <div className="flex flex-wrap gap-1.5">
        {(
          [
            ["rank", "Ülke puanı"],
            ["table", "Lig"],
            ["fix", "Fikstür"],
            ["UCL", "UCL"],
            ["UEL", "UEL"],
            ["UECL", "UECL"],
          ] as const
        ).map(([id, lab]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={cn(
              "rounded-sm px-3 py-2 text-xs font-medium",
              tab === id ? "bg-accent text-accent-fg" : "bg-elevated text-muted",
            )}
          >
            {lab}
          </button>
        ))}
      </div>

      {tab === "rank" ? (
        <Panel className="min-h-0 flex-1 overflow-auto">
          <table className="w-full text-left text-sm">
            <thead className="sticky top-0 bg-surface text-[11px] uppercase tracking-wide text-muted">
              <tr>
                <th className="px-3 py-2">#</th>
                <th>Ülke</th>
                <th>5 yıl</th>
                <th>Sezon</th>
                <th>Kontenjan</th>
              </tr>
            </thead>
            <tbody>
              {ranked.map((c, i) => {
                const q = game.uefa.quota(i + 1);
                const total = game.uefa.total(c);
                return (
                  <tr
                    key={c.code}
                    className={cn(
                      "border-t border-border",
                      c.code === user.country && "bg-elevated",
                    )}
                  >
                    <td className="tabular px-3 py-2">{i + 1}</td>
                    <td>{c.name}</td>
                    <td className="tabular">{total.toFixed(1)}</td>
                    <td className="tabular">
                      {c.seasonMatches
                        ? (c.seasonPts / c.seasonMatches).toFixed(2)
                        : "0.00"}
                    </td>
                    <td className="pr-3 text-xs text-muted">
                      {q.uclD}+{q.uclQ} UCL · {q.uel} UEL · {q.uecl} UECL
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          <p className="px-3 py-3 text-[11px] text-muted">
            1–4: 4 UCL direkt. 5–6: 3 UCL (2 direkt, 1 ön eleme). 7–10: 2 UCL ön
            elemeli, 1 UEL, 2 UECL. Grup 3.leri alt kupaya düşer.
          </p>
        </Panel>
      ) : null}

      {tab === "table" ? (
        <Panel className="min-h-0 flex-1 overflow-auto">
          <h2 className="px-3 py-2 text-sm font-semibold">{leagueName(user.league)}</h2>
          <Table clubs={game.leagueTable(user.league)} userId={user.id} />
        </Panel>
      ) : null}

      {tab === "fix" ? (
        <Panel className="min-h-0 flex-1 overflow-auto">
          <ul>
            {game.state.fixtures
              .filter((f) => f.homeId === user.id || f.awayId === user.id)
              .slice(0, 24)
              .map((f) => {
                const opp = game.state.clubs[f.homeId === user.id ? f.awayId : f.homeId];
                const home = f.homeId === user.id;
                return (
                  <li
                    key={f.id}
                    className="flex items-center gap-2 border-b border-border px-3 py-2 text-sm"
                  >
                    <span className="w-16 text-[11px] text-muted">{f.round}</span>
                    {opp ? <Crest club={opp} size={24} /> : null}
                    <span className="flex-1 truncate">
                      {home ? "vs" : "@"} {opp?.name}
                    </span>
                    <span className="text-[11px] text-muted">{compLabel(f.comp)}</span>
                    <span className="tabular text-xs">
                      {f.played ? `${f.homeGoals}–${f.awayGoals}` : `Hf ${f.week}`}
                    </span>
                  </li>
                );
              })}
          </ul>
        </Panel>
      ) : null}

      {tab === "UCL" || tab === "UEL" || tab === "UECL" ? (
        <div className="grid min-h-0 flex-1 grid-cols-1 gap-2 overflow-auto md:grid-cols-2">
          {game.state.groups
            .filter((g) => g.comp === tab)
            .map((g) => {
              const rows = groupTable(g, game.state.fixtures, game.state.clubs);
              return (
                <Panel key={g.comp + g.name} className="p-2">
                  <h3 className="px-2 py-1 text-xs font-semibold">
                    {compLabel(tab)} · Grup {g.name}
                  </h3>
                  <Table
                    clubs={rows.map((r) => ({
                      id: r.id,
                      name: r.name,
                      short: game.state.clubs[r.id]?.short ?? "",
                      colors: game.state.clubs[r.id]?.colors ?? ["#333", "#fff"],
                      pld: r.pld,
                      w: r.w,
                      d: r.d,
                      l: r.l,
                      gf: r.gf,
                      ga: r.ga,
                      pts: r.pts,
                    }))}
                    userId={user.id}
                    dropThird
                  />
                </Panel>
              );
            })}
        </div>
      ) : null}
    </div>
  );
}

function Table({
  clubs,
  userId,
  dropThird,
}: {
  clubs: Array<{
    id: string;
    name: string;
    short?: string;
    colors?: [string, string];
    pld: number;
    w: number;
    d: number;
    l: number;
    gf: number;
    ga: number;
    pts: number;
  }>;
  userId: string;
  dropThird?: boolean;
}) {
  return (
    <table className="w-full text-left text-xs">
      <thead className="text-[10px] uppercase tracking-wide text-muted">
        <tr>
          <th className="px-2 py-1">#</th>
          <th>Takım</th>
          <th>O</th>
          <th>Av</th>
          <th>P</th>
        </tr>
      </thead>
      <tbody>
        {clubs.map((c, i) => (
          <tr
            key={c.id}
            className={cn(
              "border-t border-border",
              c.id === userId && "bg-elevated",
              dropThird && i === 2 && "text-warn",
              dropThird && i >= 3 && "text-faint",
            )}
          >
            <td className="tabular px-2 py-1.5">{i + 1}</td>
            <td className="flex items-center gap-2 py-1.5">
              {c.colors && c.short ? (
                <Crest club={{ short: c.short, colors: c.colors }} size={18} />
              ) : null}
              <span className="truncate">{c.name}</span>
            </td>
            <td className="tabular">{c.pld}</td>
            <td className="tabular">{c.gf - c.ga}</td>
            <td className="tabular font-semibold">{c.pts}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
