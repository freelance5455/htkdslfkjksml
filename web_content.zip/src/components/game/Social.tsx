import { Btn, Input } from "@/components/game/ui";
import { SCENES } from "@/lib/game/constants";
import { TEAM_BY_ID } from "@/lib/game/data/teams";
import {
  applyFollowers,
  captionsFor,
  composePost,
  dmReply,
  estimateReach,
  reachLabel,
  slug,
} from "@/lib/game/engine/social";
import { fmtNum } from "@/lib/game/format";
import { Sound } from "@/lib/game/sound";
import { useGame } from "@/lib/game/store";
import type { GramPost, GramUser, SocialState } from "@/lib/game/types";
import {
  Bookmark,
  ChevronLeft,
  Heart,
  Home,
  MessageCircle,
  PlusSquare,
  Search,
  Send,
  Bell,
  User,
  BarChart3,
  Check,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";

type Tab = "home" | "search" | "compose" | "activity" | "profile" | "dm" | "thread";

const HUES = [150, 210, 12, 280, 32, 190];

function Avatar({ hue, size = 40, letter }: { hue: number; size?: number; letter: string }) {
  return (
    <div
      className="grid place-items-center rounded-full font-display text-white"
      style={{
        width: size,
        height: size,
        background: "linear-gradient(135deg, hsl(" + hue + " 45% 38%), hsl(" + ((hue + 40) % 360) + " 50% 22%))",
        fontSize: size * 0.38,
      }}
    >
      {letter.slice(0, 1).toUpperCase()}
    </div>
  );
}

function sceneBg(scene: string): string {
  const map: Record<string, string> = {
    goal: "linear-gradient(160deg,#14301f,#0b0c0b 70%)",
    train: "linear-gradient(160deg,#1c2418,#0b0c0b 70%)",
    matchday: "linear-gradient(160deg,#1a2030,#0b0c0b 70%)",
    team: "linear-gradient(160deg,#241818,#0b0c0b 70%)",
    life: "linear-gradient(160deg,#201c18,#0b0c0b 70%)",
    deal: "linear-gradient(160deg,#1c1c20,#0b0c0b 70%)",
    cup: "linear-gradient(160deg,#2a2414,#0b0c0b 70%)",
    sign: "linear-gradient(160deg,#182018,#0b0c0b 70%)",
    press: "linear-gradient(160deg,#1a1a22,#0b0c0b 70%)",
  };
  return map[scene] || map.life!;
}

export function Footballgram({ onBack }: { onBack: () => void }) {
  const { career, setCareer } = useGame();
  const [tab, setTab] = useState<Tab>("home");
  const [threadId, setThreadId] = useState<string | null>(null);
  const [storyI, setStoryI] = useState<number | null>(null);
  const [burst, setBurst] = useState<string | null>(null);
  const [analytics, setAnalytics] = useState<string | null>(null);
  if (!career) return null;
  const social = career.social;
  const users = useMemo(() => Object.fromEntries(social.users.map((u) => [u.id, u])), [social.users]);

  if (!social.setup) return <Setup onBack={onBack} />;

  function patch(next: SocialState) {
    setCareer({ ...career!, social: next });
  }

  function like(id: string) {
    Sound.pop();
    patch({
      ...social,
      posts: social.posts.map((p) =>
        p.id === id ? { ...p, liked: !p.liked, likes: p.likes + (p.liked ? -1 : 1) } : p,
      ),
    });
  }

  const me = users.me;

  return (
    <div className="mx-auto flex min-h-dvh max-w-lg flex-col bg-black text-white">
      {tab !== "thread" && storyI == null && (
        <header className="flex items-center justify-between px-4 py-3">
          <button type="button" onClick={onBack} className="text-[13px] text-white/60">
            Kariyer
          </button>
          <div className="gram-wordmark text-[28px] leading-none">Footballgram</div>
          <div className="flex gap-2">
            <button
              type="button"
              className="relative grid size-10 place-items-center"
              onClick={() => {
                Sound.tap();
                setTab("activity");
              }}
            >
              <Bell size={18} />
              {social.activity.some((a) => a.unread) && (
                <span className="absolute right-1.5 top-1.5 size-2 rounded-full bg-[#e14b6a]" />
              )}
            </button>
            <button
              type="button"
              className="relative grid size-10 place-items-center"
              onClick={() => {
                Sound.dm();
                setTab("dm");
              }}
            >
              <Send size={18} />
              {social.threads.some((t) => t.unread) && (
                <span className="absolute right-1.5 top-1.5 size-2 rounded-full bg-[#e14b6a]" />
              )}
            </button>
          </div>
        </header>
      )}

      <div className="min-h-0 flex-1 overflow-y-auto pb-16">
        {tab === "home" && (
          <>
            <div className="no-scrollbar flex gap-3 overflow-x-auto px-3 pb-3">
              {social.stories.map((st, i) => {
                const u = users[st.userId];
                return (
                  <button
                    key={st.id}
                    type="button"
                    className="w-16 shrink-0 text-center"
                    onClick={() => {
                      Sound.tap();
                      setStoryI(i);
                      if (!career.achievements.includes("story")) {
                        setCareer({ ...career, achievements: [...career.achievements, "story"] });
                      }
                    }}
                  >
                    <div className={"mx-auto grid size-16 place-items-center rounded-full p-[2px] " + (st.seen ? "bg-white/20" : "story-ring")}>
                      <div className="grid size-full place-items-center rounded-full bg-black">
                        <Avatar hue={u?.hue || 150} letter={u?.displayName || "?"} size={52} />
                      </div>
                    </div>
                    <div className="mt-1 truncate text-[11px] text-white/70">{st.userId === "me" ? "Hikayen" : u?.username}</div>
                  </button>
                );
              })}
            </div>
            {social.posts.map((p) => (
              <PostCard
                key={p.id}
                post={p}
                user={users[p.userId]}
                onLike={() => like(p.id)}
                onDouble={() => {
                  setBurst(p.id);
                  if (!p.liked) like(p.id);
                  setTimeout(() => setBurst(null), 500);
                }}
                burst={burst === p.id}
                onSave={() =>
                  patch({
                    ...social,
                    savedIds: social.savedIds.includes(p.id)
                      ? social.savedIds.filter((x) => x !== p.id)
                      : [...social.savedIds, p.id],
                    posts: social.posts.map((x) => (x.id === p.id ? { ...x, saved: !x.saved } : x)),
                  })
                }
                onComment={(text) => {
                  patch({
                    ...social,
                    posts: social.posts.map((x) =>
                      x.id === p.id ? { ...x, comments: [...x.comments, { userId: "me", text }] } : x,
                    ),
                  });
                }}
                onAnalytics={p.userId === "me" ? () => setAnalytics(p.id) : undefined}
              />
            ))}
          </>
        )}

        {tab === "search" && <SearchTab social={social} users={users} />}
        {tab === "compose" && (
          <Compose
            onShare={(scene, caption, tags, ments) => {
              Sound.follow();
              const next = composePost(career, scene, caption, tags, ments);
              const ach = career.achievements.includes("first_post")
                ? career.achievements
                : [...career.achievements, "first_post"];
              setCareer({ ...career, social: next, achievements: ach });
              setTab("home");
            }}
          />
        )}
        {tab === "activity" && (
          <div className="px-4 py-2">
            {social.activity.length === 0 && <p className="text-white/50">Sessizlik. Paylasim yap.</p>}
            {social.activity.map((a) => (
              <div key={a.id} className="flex items-center gap-3 border-b border-white/10 py-3">
                <Avatar hue={users[a.userId]?.hue || 0} letter={users[a.userId]?.username || "?"} />
                <div className="flex-1 text-[14px]">
                  <span className="font-medium">{users[a.userId]?.username}</span> {a.text}
                </div>
                {a.unread && <span className="size-2 rounded-full bg-[#e14b6a]" />}
              </div>
            ))}
          </div>
        )}
        {tab === "profile" && me && (
          <ProfileTab
            me={me}
            social={social}
            onEdit={(u, d, b) => {
              patch({
                ...social,
                username: u,
                displayName: d,
                bio: b,
                users: social.users.map((x) => (x.id === "me" ? { ...x, username: u, displayName: d, bio: b } : x)),
              });
            }}
          />
        )}
        {tab === "dm" && (
          <div>
            {social.threads.map((th) => {
              const u = users[th.userId] || {
                username: th.userId.replace("offer_", ""),
                displayName: th.userId,
                hue: 200,
              };
              return (
                <button
                  key={th.userId}
                  type="button"
                  className="flex w-full items-center gap-3 px-4 py-3 text-left"
                  onClick={() => {
                    Sound.tap();
                    setThreadId(th.userId);
                    setTab("thread");
                  }}
                >
                  <Avatar hue={u.hue || 200} letter={u.displayName} />
                  <div className="min-w-0 flex-1">
                    <div className="font-medium">{u.displayName}</div>
                    <div className="truncate text-[13px] text-white/50">{th.messages[th.messages.length - 1]?.text}</div>
                  </div>
                  {th.unread > 0 && (
                    <span className="grid size-5 place-items-center rounded-full bg-[#e14b6a] text-[11px]">{th.unread}</span>
                  )}
                </button>
              );
            })}
          </div>
        )}
        {tab === "thread" && threadId && (
          <Thread
            social={social}
            threadId={threadId}
            users={users}
            onBack={() => setTab("dm")}
            onSend={(text) => {
              const ach = career.achievements.includes("first_dm")
                ? career.achievements
                : [...career.achievements, "first_dm"];
              const threads = social.threads.map((th) =>
                th.userId === threadId
                  ? {
                      ...th,
                      unread: 0,
                      messages: [...th.messages, { id: Math.random().toString(36).slice(2), from: "me" as const, text, time: "Az once" }],
                    }
                  : th,
              );
              setCareer({ ...career, social: { ...social, threads }, achievements: ach });
              const u = users[threadId];
              const reply = dmReply(text, u?.role);
              const delay = 900 + Math.random() * 1400;
              setTimeout(() => {
                const cur = useGame.getState().career;
                if (!cur) return;
                Sound.dm();
                const ths = cur.social.threads.map((th) =>
                  th.userId === threadId
                    ? {
                        ...th,
                        messages: [
                          ...th.messages,
                          { id: Math.random().toString(36).slice(2), from: "them" as const, text: reply, time: "Az once" },
                        ],
                      }
                    : th,
                );
                setCareer({ ...cur, social: { ...cur.social, threads: ths } });
              }, delay);
            }}
          />
        )}
      </div>

      {tab !== "thread" && (
        <nav className="fixed inset-x-0 bottom-0 z-20 mx-auto flex max-w-lg justify-around border-t border-white/10 bg-black/95 py-2">
          {(
            [
              ["home", Home],
              ["search", Search],
              ["compose", PlusSquare],
              ["activity", Heart],
              ["profile", User],
            ] as const
          ).map(([id, Ic]) => (
            <button
              key={id}
              type="button"
              className="grid size-11 place-items-center"
              onClick={() => {
                Sound.tap();
                setTab(id);
              }}
            >
              <Ic size={22} className={tab === id ? "text-white" : "text-white/45"} />
            </button>
          ))}
        </nav>
      )}

      {storyI != null && (
        <StoryViewer
          stories={social.stories}
          index={storyI}
          users={users}
          onClose={() => setStoryI(null)}
          onIndex={setStoryI}
        />
      )}

      {analytics && (
        <div className="fixed inset-0 z-40 bg-black/80 p-5" onClick={() => setAnalytics(null)}>
          <div className="mx-auto mt-16 max-w-sm rounded-3xl bg-[#161616] p-5" onClick={(e) => e.stopPropagation()}>
            <div className="mb-3 flex items-center gap-2 font-medium">
              <BarChart3 size={16} /> Analitik
            </div>
            {["Gosterim", "Erisilen", "Begeni", "Yorum", "Profil ziyareti", "Yeni takipci"].map((k, i) => (
              <div key={k} className="flex justify-between py-1.5 text-[14px]">
                <span className="text-white/50">{k}</span>
                <span>{fmtNum(400 + i * 180)}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function PostCard({
  post,
  user,
  onLike,
  onDouble,
  burst,
  onSave,
  onComment,
  onAnalytics,
}: {
  post: GramPost;
  user?: GramUser;
  onLike: () => void;
  onDouble: () => void;
  burst: boolean;
  onSave: () => void;
  onComment: (t: string) => void;
  onAnalytics?: () => void;
}) {
  const [c, setC] = useState("");
  return (
    <article className="border-b border-white/10 pb-3">
      <div className="flex items-center gap-2 px-3 py-2">
        <Avatar hue={user?.hue || 0} letter={user?.displayName || "?"} size={32} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1 text-[14px] font-medium">
            {user?.username}
            {user?.verified && <Check size={12} className="text-sky-400" />}
          </div>
          {post.location && <div className="text-[11px] text-white/45">{post.location}</div>}
        </div>
      </div>
      <button
        type="button"
        className="relative block h-72 w-full"
        style={{ background: sceneBg(post.scene) }}
        onDoubleClick={onDouble}
      >
        <div className="absolute inset-0 grid place-items-center">
          <div className="text-center">
            <div className="font-display text-5xl uppercase tracking-wide text-white/90">{post.scene}</div>
            <div className="mt-2 text-[13px] text-white/55">cift dokun, begen</div>
          </div>
        </div>
        {burst && (
          <div className="heart-burst pointer-events-none absolute inset-0 grid place-items-center">
            <Heart size={72} fill="white" />
          </div>
        )}
      </button>
      <div className="flex items-center gap-1 px-2 pt-2">
        <button type="button" className="grid size-10 place-items-center" onClick={onLike}>
          <Heart size={22} fill={post.liked ? "#e14b6a" : "none"} className={post.liked ? "text-[#e14b6a]" : ""} />
        </button>
        <button type="button" className="grid size-10 place-items-center">
          <MessageCircle size={22} />
        </button>
        <button type="button" className="grid size-10 place-items-center">
          <Send size={20} />
        </button>
        <div className="flex-1" />
        {onAnalytics && (
          <button type="button" className="grid size-10 place-items-center" onClick={onAnalytics}>
            <BarChart3 size={18} />
          </button>
        )}
        <button type="button" className="grid size-10 place-items-center" onClick={onSave}>
          <Bookmark size={20} fill={post.saved ? "white" : "none"} />
        </button>
      </div>
      <div className="px-4 text-[14px] font-medium">{fmtNum(post.likes)} begeni</div>
      <div className="px-4 pt-1 text-[14px]">
        <span className="font-medium">{user?.username} </span>
        {post.caption}
        {post.hashtags.map((h) => (
          <span key={h} className="text-sky-400">
            {" #"}
            {h}
          </span>
        ))}
      </div>
      {post.comments.slice(0, 2).map((cmt, i) => (
        <div key={i} className="px-4 text-[13px] text-white/70">
          {cmt.text}
        </div>
      ))}
      <div className="px-4 pt-1 text-[11px] uppercase tracking-wide text-white/35">{post.time}</div>
      <form
        className="mt-1 flex gap-2 px-4"
        onSubmit={(e) => {
          e.preventDefault();
          if (!c.trim()) return;
          onComment(c.trim());
          setC("");
        }}
      >
        <input
          value={c}
          onChange={(e) => setC(e.target.value)}
          placeholder="Yorum ekle..."
          className="h-9 flex-1 bg-transparent text-[14px] outline-none placeholder:text-white/30"
        />
      </form>
    </article>
  );
}

function SearchTab({ social, users }: { social: SocialState; users: Record<string, GramUser | undefined> }) {
  const [q, setQ] = useState("");
  const tags = ["matchday", "goal", "ucl", "transfer", "training"];
  const grid = [...social.posts].sort((a, b) => b.likes - a.likes).slice(0, 9);
  return (
    <div className="px-3 py-2">
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Ara"
        className="h-10 w-full rounded-xl bg-white/10 px-3 text-[14px] outline-none"
      />
      <div className="mt-3 flex flex-wrap gap-2">
        {tags.map((t) => (
          <span key={t} className="rounded-full bg-white/10 px-3 py-1 text-[12px]">
            #{t}
          </span>
        ))}
      </div>
      <div className="mt-3 grid grid-cols-3 gap-1">
        {grid.map((p) => (
          <div key={p.id} className="aspect-square" style={{ background: sceneBg(p.scene) }} />
        ))}
      </div>
      <div className="mt-4 text-[12px] uppercase tracking-[0.14em] text-white/40">Onerilen</div>
      {social.users
        .filter((u) => u.id !== "me")
        .slice(0, 6)
        .map((u) => (
          <div key={u.id} className="flex items-center gap-3 py-2">
            <Avatar hue={u.hue} letter={u.displayName} />
            <div className="flex-1">
              <div className="text-[14px]">{u.username}</div>
              <div className="text-[12px] text-white/45">{fmtNum(u.followers)} takipci</div>
            </div>
            <span className="text-[12px] text-sky-400">Takip et</span>
          </div>
        ))}
      {q && Object.values(users).filter((u) => u && u.username.includes(q.toLowerCase())).length === 0 && (
        <p className="mt-2 text-white/40">Sonuc yok.</p>
      )}
    </div>
  );
}

function Compose({
  onShare,
}: {
  onShare: (scene: string, caption: string, tags: string[], ments: string[]) => void;
}) {
  const career = useGame((s) => s.career)!;
  const [scene, setScene] = useState("matchday");
  const [caption, setCaption] = useState("");
  const [tags, setTags] = useState<string[]>([]);
  const reach = estimateReach(career.social.followers, scene);
  const templates = captionsFor(scene, career.lastResult);
  const allTags = ["goal", "matchday", "training", "team", "career", "weekend"];
  return (
    <div className="px-4 py-3">
      <div className="mb-3 font-medium">Olustur</div>
      <div className="grid grid-cols-3 gap-2">
        {SCENES.map((s) => (
          <button
            key={s.id}
            type="button"
            onClick={() => setScene(s.id)}
            className={"rounded-xl py-3 text-[12px] " + (scene === s.id ? "bg-white text-black" : "bg-white/10")}
          >
            {s.tr}
          </button>
        ))}
      </div>
      <div className="mt-3 h-36 rounded-2xl" style={{ background: sceneBg(scene) }} />
      <div className="mt-3 flex flex-wrap gap-2">
        {templates.map((t) => (
          <button key={t} type="button" className="rounded-full bg-white/10 px-3 py-1 text-[12px]" onClick={() => setCaption(t)}>
            Sablon
          </button>
        ))}
      </div>
      <textarea
        value={caption}
        onChange={(e) => setCaption(e.target.value)}
        rows={3}
        className="mt-3 w-full rounded-xl bg-white/10 p-3 text-[14px] outline-none"
        placeholder="Caption"
      />
      <div className="mt-2 flex flex-wrap gap-2">
        {allTags.map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => setTags((x) => (x.includes(t) ? x.filter((i) => i !== t) : x.length < 5 ? [...x, t] : x))}
            className={"rounded-full px-3 py-1 text-[12px] " + (tags.includes(t) ? "bg-white text-black" : "bg-white/10")}
          >
            #{t}
          </button>
        ))}
      </div>
      <div className="mt-3 text-[13px] text-white/50">
        Tahmini erisim: {reachLabel(reach, career.social.followers)} · {TEAM_BY_ID[career.clubId]?.name}
      </div>
      <Btn tone="primary" className="mt-4 w-full" onClick={() => onShare(scene, caption || templates[0]!, tags, [])}>
        Paylas
      </Btn>
    </div>
  );
}

function ProfileTab({
  me,
  social,
  onEdit,
}: {
  me: GramUser;
  social: SocialState;
  onEdit: (u: string, d: string, b: string) => void;
}) {
  const [edit, setEdit] = useState(false);
  const [u, setU] = useState(me.username);
  const [d, setD] = useState(me.displayName);
  const [b, setB] = useState(me.bio);
  const mine = social.posts.filter((p) => p.userId === "me");
  return (
    <div className="px-4 py-3">
      <div className="flex items-center gap-4">
        <Avatar hue={social.hue} letter={me.displayName} size={96} />
        <div className="flex flex-1 justify-around text-center">
          <div>
            <div className="font-display text-2xl">{mine.length}</div>
            <div className="text-[11px] text-white/50">Gonderi</div>
          </div>
          <div>
            <div className="font-display text-2xl">{fmtNum(social.followers)}</div>
            <div className="text-[11px] text-white/50">Takipci</div>
          </div>
          <div>
            <div className="font-display text-2xl">{social.followingCount}</div>
            <div className="text-[11px] text-white/50">Takip</div>
          </div>
        </div>
      </div>
      <div className="mt-3 font-medium">
        {me.displayName} {social.verified && <Check size={14} className="inline text-sky-400" />}
      </div>
      <div className="text-[13px] text-white/55">@{me.username}</div>
      <p className="mt-1 text-[14px]">{me.bio}</p>
      <div className="mt-3 grid grid-cols-2 gap-2">
        <Btn onClick={() => setEdit(true)}>Profili duzenle</Btn>
        <Btn>Olustur</Btn>
      </div>
      <div className="mt-4 grid grid-cols-3 gap-1">
        {mine.map((p) => (
          <div key={p.id} className="aspect-square" style={{ background: sceneBg(p.scene) }} />
        ))}
      </div>
      {edit && (
        <div className="fixed inset-0 z-40 grid place-items-center bg-black/70 p-4">
          <div className="w-full max-w-sm rounded-3xl bg-[#161616] p-4">
            <Input value={u} onChange={(e) => setU(e.target.value)} />
            <div className="mt-2">
              <Input value={d} onChange={(e) => setD(e.target.value)} />
            </div>
            <div className="mt-2">
              <Input value={b} onChange={(e) => setB(e.target.value)} />
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <Btn onClick={() => setEdit(false)}>Vazgec</Btn>
              <Btn
                tone="primary"
                onClick={() => {
                  onEdit(slug(u), d, b.slice(0, 80));
                  setEdit(false);
                }}
              >
                Kaydet
              </Btn>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Thread({
  social,
  threadId,
  users,
  onBack,
  onSend,
}: {
  social: SocialState;
  threadId: string;
  users: Record<string, GramUser | undefined>;
  onBack: () => void;
  onSend: (t: string) => void;
}) {
  const [t, setT] = useState("");
  const th = social.threads.find((x) => x.userId === threadId);
  const u = users[threadId];
  const quick = ["Selam", "Antrenmanda gorusuruz", "Tesekkurler", "Mac gunu hazirim"];
  return (
    <div className="flex h-full min-h-[70vh] flex-col">
      <div className="flex items-center gap-2 px-2 py-2">
        <button type="button" className="grid size-10 place-items-center" onClick={onBack}>
          <ChevronLeft />
        </button>
        <Avatar hue={u?.hue || 200} letter={u?.displayName || "?"} size={32} />
        <div>
          <div className="text-[14px] font-medium">{u?.displayName || "Sohbet"}</div>
          <div className="text-[11px] text-white/45">Cevrimici</div>
        </div>
      </div>
      <div className="flex-1 space-y-2 overflow-y-auto px-3 py-2">
        {th?.messages.map((m) => (
          <div
            key={m.id}
            className={"max-w-[80%] rounded-2xl px-3 py-2 text-[14px] " + (m.from === "me" ? "ml-auto bg-[#1b4f9c]" : "bg-white/10")}
          >
            {m.text}
          </div>
        ))}
      </div>
      <div className="flex flex-wrap gap-1 px-3">
        {quick.map((q) => (
          <button key={q} type="button" className="rounded-full bg-white/10 px-3 py-1 text-[12px]" onClick={() => onSend(q)}>
            {q}
          </button>
        ))}
      </div>
      <form
        className="flex gap-2 p-3"
        onSubmit={(e) => {
          e.preventDefault();
          if (!t.trim()) return;
          onSend(t.trim());
          setT("");
        }}
      >
        <input
          value={t}
          onChange={(e) => setT(e.target.value)}
          className="h-11 flex-1 rounded-full bg-white/10 px-4 text-[14px] outline-none"
          placeholder="Mesaj"
        />
      </form>
    </div>
  );
}

function StoryViewer({
  stories,
  index,
  users,
  onClose,
  onIndex,
}: {
  stories: SocialState["stories"];
  index: number;
  users: Record<string, GramUser | undefined>;
  onClose: () => void;
  onIndex: (n: number) => void;
}) {
  const st = stories[index];
  useEffect(() => {
    const t = setTimeout(() => {
      if (index < stories.length - 1) onIndex(index + 1);
      else onClose();
    }, 5000);
    return () => clearTimeout(t);
  }, [index, onClose, onIndex, stories.length]);
  if (!st) return null;
  const u = users[st.userId];
  return (
    <div className="fixed inset-0 z-50 bg-black">
      <div className="flex gap-1 px-3 pt-3">
        {stories.map((_, i) => (
          <div key={i} className="h-0.5 flex-1 overflow-hidden rounded bg-white/25">
            <div
              className="h-full bg-white"
              style={{
                width: i < index ? "100%" : i === index ? "100%" : "0%",
                animation: i === index ? "storybar 5s linear" : undefined,
              }}
            />
          </div>
        ))}
      </div>
      <style>{`@keyframes storybar { from { width: 0% } to { width: 100% } }`}</style>
      <div className="flex items-center gap-2 px-4 py-3">
        <Avatar hue={u?.hue || 0} letter={u?.displayName || "?"} size={28} />
        <div className="flex-1 text-[13px]">{u?.username} · 5sn</div>
        <button type="button" onClick={onClose}>
          Kapat
        </button>
      </div>
      <div className="relative mx-4 mt-6 h-[70vh] overflow-hidden rounded-3xl" style={{ background: sceneBg(st.scene) }}>
        <button type="button" className="absolute inset-y-0 left-0 w-1/3" onClick={() => (index > 0 ? onIndex(index - 1) : onClose())} />
        <button
          type="button"
          className="absolute inset-y-0 right-0 w-2/3"
          onClick={() => (index < stories.length - 1 ? onIndex(index + 1) : onClose())}
        />
        <div className="flex h-full flex-col items-center justify-center p-6 text-center">
          <div className="font-display text-6xl uppercase">{st.scene}</div>
          <div className="mt-4 text-lg">{st.text}</div>
        </div>
      </div>
    </div>
  );
}

function Setup({ onBack }: { onBack: () => void }) {
  const { career, setCareer } = useGame();
  const [step, setStep] = useState(1);
  const [u, setU] = useState(career?.social.username || "player");
  const [d, setD] = useState(career?.player.displayName || "");
  const [b, setB] = useState("Saha ve hayat.");
  const [hue, setHue] = useState(150);
  if (!career) return null;
  return (
    <div className="mx-auto flex min-h-dvh max-w-lg flex-col bg-black px-5 py-6 text-white">
      <button type="button" className="text-[13px] text-white/50" onClick={onBack}>
        Geri
      </button>
      <div className="gram-wordmark mt-6 text-4xl">Footballgram</div>
      <p className="mt-1 text-white/50">Adim {step}/5</p>
      {step === 1 && (
        <label className="mt-8 block">
          <span className="text-[12px] uppercase tracking-[0.14em] text-white/40">Kullanici adi</span>
          <input value={u} onChange={(e) => setU(e.target.value.toLowerCase())} className="mt-2 h-12 w-full border-b border-white/20 bg-transparent text-lg outline-none" />
        </label>
      )}
      {step === 2 && (
        <label className="mt-8 block">
          <span className="text-[12px] uppercase tracking-[0.14em] text-white/40">Gorunen ad</span>
          <input value={d} onChange={(e) => setD(e.target.value)} className="mt-2 h-12 w-full border-b border-white/20 bg-transparent text-lg outline-none" />
        </label>
      )}
      {step === 3 && (
        <label className="mt-8 block">
          <span className="text-[12px] uppercase tracking-[0.14em] text-white/40">Biyografi</span>
          <input value={b} maxLength={80} onChange={(e) => setB(e.target.value)} className="mt-2 h-12 w-full border-b border-white/20 bg-transparent text-lg outline-none" />
        </label>
      )}
      {step === 4 && (
        <div className="mt-8">
          <div className="text-[12px] uppercase tracking-[0.14em] text-white/40">Avatar rengi</div>
          <div className="mt-4 flex gap-3">
            {HUES.map((h) => (
              <button
                key={h}
                type="button"
                onClick={() => setHue(h)}
                className={"rounded-full " + (hue === h ? "ring-2 ring-white" : "")}
              >
                <Avatar hue={h} letter={d} size={48} />
              </button>
            ))}
          </div>
        </div>
      )}
      {step === 5 && (
        <div className="mt-8 text-center">
          <Avatar hue={hue} letter={d} size={96} />
          <div className="mt-3 font-display text-3xl">{d}</div>
          <div className="text-white/50">@{slug(u)}</div>
          <p className="mt-2 text-white/60">{b}</p>
        </div>
      )}
      <Btn
        tone="primary"
        className="mt-auto"
        onClick={() => {
          Sound.click();
          if (step < 5) setStep(step + 1);
          else {
            const username = slug(u);
            setCareer({
              ...career,
              social: {
                ...career.social,
                setup: true,
                username,
                displayName: d,
                bio: b,
                hue,
                users: career.social.users.map((x) =>
                  x.id === "me" ? { ...x, username, displayName: d, bio: b, hue } : x,
                ),
              },
            });
          }
        }}
      >
        {step < 5 ? "Devam" : "Hesabi ac"}
      </Btn>
    </div>
  );
}

void applyFollowers;
