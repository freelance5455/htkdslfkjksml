import { Button } from "@/components/ui/button";
import { useMobileLayout } from "@/components/game/useMobileLayout";
import { useGameStore } from "@/game/store";
import { Volume2, VolumeX } from "lucide-react";

type Props = {
  ready: boolean;
  onStart: () => void;
  onMute: () => void;
};

export function TitleScreen({ ready, onStart, onMute }: Props) {
  const highScore = useGameStore((s) => s.highScore);
  const bestWave = useGameStore((s) => s.bestWave);
  const muted = useGameStore((s) => s.muted);
  const mobile = useMobileLayout();

  return (
    <div className="absolute inset-0 z-20 flex flex-col justify-end bg-gradient-to-t from-bg via-bg/80 to-bg/25">
      <div className="absolute right-4 top-4 z-30 pt-[env(safe-area-inset-top)]">
        <Button
          variant="ghost"
          size="icon"
          aria-label={muted ? "Unmute" : "Mute"}
          onClick={onMute}
        >
          {muted ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
        </Button>
      </div>

      <div className="mx-auto w-full max-w-lg px-6 pb-[max(4.5rem,env(safe-area-inset-bottom))]">
        <p className="font-display text-xs uppercase tracking-[0.38em] text-muted">Parish of 1879</p>
        <h1 className="mt-2 font-display text-4xl font-semibold tracking-display text-balance text-fg sm:text-6xl">
          Gallows Hollow
        </h1>
        <div className="mt-4 h-px w-16 bg-border-strong" />
        <p className="mt-4 max-w-md text-pretty text-sm leading-relaxed text-muted sm:text-base">
          The dead have climbed out of the churchyard. You are the last sheriff. Hold the
          square with a six-shooter until the cylinder — or you — run dry.
        </p>

        <div className="mt-6 flex flex-wrap gap-x-6 gap-y-1 font-display text-sm tabular-nums text-subtle">
          <span>Best {highScore.toLocaleString()}</span>
          <span>Wave {bestWave || "—"}</span>
        </div>

        <Button
          size="xl"
          className="mt-6 w-full sm:w-auto"
          disabled={!ready}
          onClick={onStart}
        >
          {ready ? "Enter Town" : "Loading…"}
        </Button>

        <p className="mt-4 text-pretty text-xs leading-relaxed text-subtle">
          {mobile
            ? "Left stick to walk. Drag the right side to look. Fire and reload with the buttons."
            : "WASD to walk. Drag or mouse to look. Click or Space to fire. R reloads. Shift sprints. Esc pauses."}
        </p>
      </div>
    </div>
  );
}
