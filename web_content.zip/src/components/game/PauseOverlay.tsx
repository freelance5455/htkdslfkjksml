import { Button } from "@/components/ui/button";
import { useGameStore } from "@/game/store";
import { Volume2, VolumeX } from "lucide-react";

export function PauseOverlay({ onResume, onReset }: { onResume: () => void; onReset: () => void }) {
  const muted = useGameStore((s) => s.hud.muted);
  const save = useGameStore((s) => s.save);

  return (
    <div className="absolute inset-0 z-30 grid place-items-center bg-bg/70 px-4">
      <div className="w-full max-w-sm rounded-xl border border-border bg-surface p-6">
        <p className="font-mono text-2xs tracking-[0.18em] text-muted uppercase">Paused</p>
        <h2 className="mt-1 text-xl font-medium">Survey hold</h2>
        <p className="mt-2 text-sm text-muted">
          {save.discovered.length}/119 charted · {save.xp} XP · rank saved locally
        </p>
        <div className="mt-5 flex flex-col gap-2">
          <Button onClick={onResume}>Resume</Button>
          <Button variant="outline" onClick={() => useGameStore.getState().toggleMute()}>
            {muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
            {muted ? "Unmute" : "Mute"}
          </Button>
          <Button variant="ghost" onClick={onReset}>
            Reset progress
          </Button>
        </div>
        <p className="mt-4 font-mono text-2xs leading-relaxed text-subtle">
          W throttle · A left · D right · R/F pitch · Shift boost · E scan · Q warp · V dimensions · C Atlas Menu
        </p>
      </div>
    </div>
  );
}
