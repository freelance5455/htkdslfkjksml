import { SPONSORS } from "@/lib/game/data";
import { money, objectiveLabel } from "@/lib/game/format";
import { useGame } from "@/lib/game/store";
import { Btn, Crest, Meter, Panel } from "./primitives";

const COST = [0, 0, 2_000_000, 5_500_000, 13_000_000, 28_000_000];

export function ClubView() {
  const game = useGame((s) => s.game)!;
  const bump = useGame((s) => s.bump);
  const flash = useGame((s) => s.flash);
  const newGame = useGame((s) => s.newGame);
  useGame((s) => s.tick);
  const user = game.user();
  const wages = game.userPlayers().reduce((s, p) => s + p.wage, 0);
  const sp = SPONSORS.find((s) => s.id === user.sponsorId);

  function up(kind: "academy" | "training" | "stadium") {
    const err = game.upgrade(kind);
    flash(err ?? "Tesis yükseltildi");
    bump();
  }

  return (
    <div className="mx-auto grid max-w-5xl gap-3 p-3 md:grid-cols-2">
      <Panel className="p-4">
        <div className="flex items-center gap-3">
          <Crest club={user} size={52} />
          <div>
            <h2 className="text-lg font-semibold">{user.name}</h2>
            <p className="text-xs text-muted">
              {user.stadium} · {user.cap.toLocaleString("tr-TR")} kapasite
            </p>
          </div>
        </div>
        <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
          <Stat k="Kasa" v={money(user.balance)} />
          <Stat k="Haftalık ücret" v={money(wages)} />
          <Stat k="İtibar" v={String(user.rep)} />
          <Stat k="Hedef" v={objectiveLabel(game.state.objective)} />
        </dl>
        <div className="mt-4">
          <div className="mb-1 flex justify-between text-xs">
            <span className="text-muted">Yönetim güveni</span>
            <span className="tabular">{game.state.board}%</span>
          </div>
          <Meter value={game.state.board} />
          <p className="mt-2 text-[11px] text-muted">
            %12’nin altına düşerseniz görevden alınabilirsiniz.
          </p>
        </div>
      </Panel>

      <Panel className="p-4">
        <h2 className="mb-3 text-sm font-semibold">Tesisler</h2>
        <Fac
          title="Gençlik akademisi"
          lvl={user.academy}
          onUp={() => up("academy")}
        />
        <Fac
          title="Antrenman sahası"
          lvl={user.training}
          onUp={() => up("training")}
        />
        <div className="mt-3 flex items-center justify-between border-t border-border pt-3">
          <div>
            <p className="text-sm">Stadyum</p>
            <p className="text-xs text-muted">
              {user.cap.toLocaleString("tr-TR")} · +4000 koltuk
            </p>
          </div>
          <Btn variant="soft" onClick={() => up("stadium")}>
            {money(Math.round(user.cap * 420))}
          </Btn>
        </div>
      </Panel>

      <Panel className="p-4">
        <h2 className="mb-3 text-sm font-semibold">Sponsorluk</h2>
        <p className="mb-3 text-xs text-muted">
          Aktif: {sp?.name} · haftalık {money(sp?.weekly ?? 0)}
        </p>
        <ul className="grid gap-2">
          {SPONSORS.filter((s) => s.id !== "none").map((s) => (
            <li key={s.id} className="flex items-center justify-between gap-2">
              <span className="text-sm">
                {s.name}
                <span className="ml-2 text-xs text-muted">{money(s.weekly)}/hf</span>
              </span>
              <Btn
                variant={user.sponsorId === s.id ? "primary" : "soft"}
                className="min-h-9 px-2 text-xs"
                onClick={() => {
                  const err = game.setSponsor(s.id);
                  flash(err ?? "Sponsor güncellendi");
                  bump();
                }}
              >
                {user.sponsorId === s.id ? "Aktif" : "Seç"}
              </Btn>
            </li>
          ))}
        </ul>
      </Panel>

      <Panel className="p-4">
        <h2 className="mb-3 text-sm font-semibold">Haberler</h2>
        <ul className="max-h-56 space-y-2 overflow-auto">
          {game.state.news.slice(0, 12).map((n) => (
            <li key={n.id} className="border-b border-border pb-2">
              <p className="text-sm font-medium">{n.title}</p>
              <p className="text-xs text-muted">{n.body}</p>
            </li>
          ))}
        </ul>
        <Btn variant="ghost" className="mt-4 w-full" onClick={newGame}>
          Yeni kariyer
        </Btn>
      </Panel>
    </div>
  );
}

function Stat({ k, v }: { k: string; v: string }) {
  return (
    <div>
      <dt className="text-[11px] uppercase tracking-wide text-muted">{k}</dt>
      <dd className="tabular font-medium">{v}</dd>
    </div>
  );
}

function Fac({
  title,
  lvl,
  onUp,
}: {
  title: string;
  lvl: number;
  onUp: () => void;
}) {
  return (
    <div className="mb-3 flex items-center justify-between">
      <div>
        <p className="text-sm">{title}</p>
        <p className="text-xs text-muted">Seviye {lvl}/5</p>
      </div>
      {lvl < 5 ? (
        <Btn variant="soft" className="min-h-9 text-xs" onClick={onUp}>
          {money(COST[lvl + 1] ?? 0)}
        </Btn>
      ) : (
        <span className="text-xs text-ok">Max</span>
      )}
    </div>
  );
}
