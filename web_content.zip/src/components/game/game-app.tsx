import { useEffect } from "react";
import { useGame } from "@/lib/game/store";
import { ClubView } from "./club-view";
import { EuropeView } from "./europe-view";
import { MatchView } from "./match-view";
import { MedicalView } from "./medical-view";
import { Shell } from "./shell";
import { SquadView } from "./squad-view";
import { StartScreen } from "./start-screen";
import { TacticsView } from "./tactics-view";
import { TransferView } from "./transfer-view";
import { Btn, Panel } from "./primitives";

export function GameApp() {
  const hydrate = useGame((s) => s.hydrate);
  const game = useGame((s) => s.game);
  const screen = useGame((s) => s.screen);
  const toast = useGame((s) => s.toast);
  const bump = useGame((s) => s.bump);
  useGame((s) => s.tick);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    const onHide = () => useGame.getState().game?.save();
    document.addEventListener("visibilitychange", onHide);
    window.addEventListener("pagehide", onHide);
    return () => {
      document.removeEventListener("visibilitychange", onHide);
      window.removeEventListener("pagehide", onHide);
    };
  }, [game]);

  if (!game) return <StartScreen />;

  const view =
    screen === "squad" ? (
      <SquadView />
    ) : screen === "tactics" ? (
      <TacticsView />
    ) : screen === "transfer" ? (
      <TransferView />
    ) : screen === "europe" ? (
      <EuropeView />
    ) : screen === "medical" ? (
      <MedicalView />
    ) : screen === "club" ? (
      <ClubView />
    ) : (
      <MatchView />
    );

  return (
    <>
      <Shell>{view}</Shell>
      {toast ? (
        <div className="pointer-events-none fixed bottom-16 left-1/2 z-40 -translate-x-1/2 rounded-sm bg-elevated px-4 py-2 text-sm shadow-panel">
          {toast}
        </div>
      ) : null}
      {game.state.sacked ? <SackedModal bump={bump} /> : null}
    </>
  );
}

function SackedModal({ bump }: { bump: () => void }) {
  const game = useGame((s) => s.game)!;
  const newGame = useGame((s) => s.newGame);
  const jobs = game.availableJobs();
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-bg/80 p-4">
      <Panel className="w-full max-w-md p-5">
        <h2 className="text-lg font-semibold">Görevden alındınız</h2>
        <p className="mt-2 text-sm text-muted">
          Yönetim kurulu güveni tükendi. Yeni bir kulüp seçebilir veya kariyeri sıfırlayabilirsiniz.
        </p>
        <ul className="mt-4 max-h-48 space-y-1 overflow-auto">
          {jobs.map((c) => (
            <li key={c.id}>
              <Btn
                variant="soft"
                className="w-full justify-between"
                onClick={() => {
                  game.takeJob(c.id);
                  bump();
                }}
              >
                <span>{c.name}</span>
                <span className="text-xs text-muted">{c.short}</span>
              </Btn>
            </li>
          ))}
        </ul>
        <Btn variant="ghost" className="mt-3 w-full" onClick={newGame}>
          Yeni kariyer
        </Btn>
      </Panel>
    </div>
  );
}
