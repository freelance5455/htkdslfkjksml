import { useEffect, useRef } from "react";
import { FORMATIONS } from "@/lib/game/data";
import { compLabel } from "@/lib/game/format";
import type { MatchEvent } from "@/lib/game/types";
import { useGame } from "@/lib/game/store";
import { cn } from "@/lib/utils";
import { Btn, Crest, Panel } from "./primitives";

export function MatchView() {
  const game = useGame((s) => s.game)!;
  const bump = useGame((s) => s.bump);
  const speed = useGame((s) => s.speed);
  const setSpeed = useGame((s) => s.setSpeed);
  const flash = useGame((s) => s.flash);
  useGame((s) => s.tick);
  const live = game.state.live;
  const next = game.nextUserFixture();

  if (live) {
    return (
      <Live
        speed={speed}
        setSpeed={setSpeed}
        bump={bump}
      />
    );
  }

  if (!next) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-3 p-6 text-center">
        <p className="text-sm text-muted">Bu hafta sizin için maç yok.</p>
        <Btn
          onClick={() => {
            game.simRestOfWeek();
            bump();
          }}
        >
          Haftayı simüle et
        </Btn>
      </div>
    );
  }

  const user = game.user();
  const home = game.state.clubs[next.homeId]!;
  const away = game.state.clubs[next.awayId]!;
  const userHome = next.homeId === user.id;

  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-4 p-4">
      <Panel className="p-5">
        <p className="text-center text-[11px] uppercase tracking-[0.18em] text-muted">
          {compLabel(next.comp)} · {next.round} · Hafta {next.week}
        </p>
        <div className="mt-4 flex items-center justify-between gap-3">
          <Side club={home} align="left" you={userHome} />
          <span className="text-2xl font-semibold text-muted">vs</span>
          <Side club={away} align="right" you={!userHome} />
        </div>
        <div className="mt-6 grid grid-cols-1 gap-2 sm:grid-cols-3">
          <Btn
            onClick={() => {
              const err = game.startMatch(next.id);
              if (err) flash(err);
              bump();
            }}
          >
            Maçı başlat
          </Btn>
          <Btn
            variant="soft"
            onClick={() => {
              const err = game.startMatch(next.id);
              if (err) {
                flash(err);
                return;
              }
              game.skipMatch();
              bump();
            }}
          >
            Anında sonuç
          </Btn>
          <Btn
            variant="ghost"
            onClick={() => {
              game.simRestOfWeek();
              bump();
            }}
          >
            Haftayı simüle et
          </Btn>
        </div>
      </Panel>
      <Panel className="p-4">
        <h2 className="mb-2 text-sm font-semibold">Son haberler</h2>
        <ul className="space-y-2">
          {game.state.news.slice(0, 5).map((n) => (
            <li key={n.id} className="text-sm">
              <span className="font-medium">{n.title}</span>
              <span className="text-muted"> — {n.body}</span>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}

function Side({
  club,
  align,
  you,
}: {
  club: { name: string; short: string; colors: [string, string]; rep: number };
  align: "left" | "right";
  you: boolean;
}) {
  return (
    <div className={cn("flex flex-1 items-center gap-2", align === "right" && "flex-row-reverse")}>
      <Crest club={club} size={48} />
      <div className={align === "right" ? "text-right" : ""}>
        <p className="text-sm font-semibold">{club.name}</p>
        <p className="text-[11px] text-muted">
          {you ? "Siz" : "Rakip"} · {club.rep}
        </p>
      </div>
    </div>
  );
}

function Live({
  speed,
  setSpeed,
  bump,
}: {
  speed: 1 | 2;
  setSpeed: (s: 1 | 2) => void;
  bump: () => void;
}) {
  const game = useGame((s) => s.game)!;
  const live = game.state.live!;
  const home = game.state.clubs[live.homeId]!;
  const away = game.state.clubs[live.awayId]!;
  const phase = live.phase;
  const running = phase === "first" || phase === "second";
  const feedRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!running) return;
    let raf = 0;
    let acc = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      const sp = useGame.getState().speed;
      acc += dt * sp;
      const step = 0.34;
      const g = useGame.getState().game;
      const l = g?.state.live;
      while (acc >= step && l && (l.phase === "first" || l.phase === "second")) {
        acc -= step;
        g.stepMinute();
        useGame.getState().bump();
      }
      if (g?.state.live && (g.state.live.phase === "first" || g.state.live.phase === "second")) {
        raf = requestAnimationFrame(loop);
      }
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [running, live.fixtureId]);

  useEffect(() => {
    feedRef.current?.scrollTo({ top: 0 });
  }, [live.events[0]?.text, live.minute]);

  const userIsHome = live.homeId === game.state.clubId;
  const xi = userIsHome ? live.homeXI : live.awayXI;
  const bench = userIsHome ? live.homeBench : live.awayBench;
  const formation = game.user().tactics.formation;
  const slots = FORMATIONS[formation]?.slots ?? FORMATIONS["4-3-3"]!.slots;

  return (
    <div className="grid h-full grid-cols-1 gap-3 p-3 lg:grid-cols-[minmax(0,1fr)_280px]">
      <div className="flex min-h-0 flex-col gap-3">
        <Panel className="p-4">
          <div className="flex items-center justify-between text-[11px] uppercase tracking-wider text-muted">
            <span>
              {compLabel(live.comp)} · {live.round}
            </span>
            <span className="tabular text-lg font-semibold text-fg">
              {live.phase === "ht" ? "Devre" : live.phase === "ft" ? "90+" : `${live.minute}'`}
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Crest club={home} size={40} />
              <span className="text-sm font-semibold">{home.short}</span>
            </div>
            <p className="tabular text-4xl font-semibold tracking-tight">
              {live.homeGoals}
              <span className="mx-1 text-muted">–</span>
              {live.awayGoals}
            </p>
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold">{away.short}</span>
              <Crest club={away} size={40} />
            </div>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <Btn variant={speed === 1 ? "primary" : "soft"} className="min-h-9 px-3 text-xs" onClick={() => setSpeed(1)}>
              1x
            </Btn>
            <Btn variant={speed === 2 ? "primary" : "soft"} className="min-h-9 px-3 text-xs" onClick={() => setSpeed(2)}>
              2x
            </Btn>
            {phase === "ht" ? (
              <Btn
                className="min-h-9 px-3 text-xs"
                onClick={() => {
                  game.continueSecondHalf();
                  bump();
                }}
              >
                İkinci yarı
              </Btn>
            ) : null}
            {phase === "ft" ? (
              <Btn
                className="min-h-9 px-3 text-xs"
                onClick={() => {
                  game.closeMatchAndAdvance();
                  bump();
                }}
              >
                Devam
              </Btn>
            ) : (
              <Btn
                variant="ghost"
                className="min-h-9 px-3 text-xs"
                onClick={() => {
                  game.skipMatch();
                  bump();
                }}
              >
                Anında bitir
              </Btn>
            )}
          </div>
        </Panel>

        <Panel className="min-h-0 flex-1 overflow-hidden">
          <div ref={feedRef} className="h-full max-h-[42vh] space-y-2 overflow-auto p-3 lg:max-h-none">
            {live.events.map((ev, i) => (
              <EventLine key={i} ev={ev} />
            ))}
          </div>
        </Panel>
      </div>

      <div className="flex flex-col gap-3">
        <Panel className="p-3">
          <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted">İstatistik</h3>
          <StatRow label="Şut" a={live.stats.home.shots} b={live.stats.away.shots} />
          <StatRow label="İsabet" a={live.stats.home.onTarget} b={live.stats.away.onTarget} />
          <StatRow label="xG" a={Number(live.stats.home.xg.toFixed(1))} b={Number(live.stats.away.xg.toFixed(1))} />
          <StatRow label="Topla oynama" a={live.stats.home.possession} b={live.stats.away.possession} />
          <StatRow label="Sarı / Kırmızı" a={live.stats.home.yellows} b={live.stats.away.yellows} />
        </Panel>
        {phase !== "ft" ? (
          <Panel className="max-h-64 overflow-auto p-3">
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted">
              Değişiklik ({live.subsUsed}/5)
            </h3>
            <p className="mb-2 text-[11px] text-muted">Sahadakine dokun, yedekten seç.</p>
            <SubPanel xi={xi} bench={bench} slots={slots} />
          </Panel>
        ) : (
          <Panel className="p-3">
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted">Goller</h3>
            <ul className="text-sm">
              {live.scorers.map((s, i) => (
                <li key={i} className="tabular text-muted">
                  {s.minute}' {s.name}
                </li>
              ))}
              {live.scorers.length === 0 ? <li className="text-muted">Golsüz.</li> : null}
            </ul>
          </Panel>
        )}
      </div>
    </div>
  );
}

function EventLine({ ev }: { ev: MatchEvent }) {
  const tone =
    ev.kind === "goal"
      ? "text-ok"
      : ev.kind === "red" || ev.kind === "injury"
        ? "text-danger"
        : ev.kind === "yellow"
          ? "text-warn"
          : "text-fg";
  return (
    <p className={cn("text-sm leading-snug", tone)}>
      {ev.text}
    </p>
  );
}

function StatRow({ label, a, b }: { label: string; a: number; b: number }) {
  const tot = a + b || 1;
  return (
    <div className="mb-2">
      <div className="mb-0.5 flex justify-between text-[11px] text-muted">
        <span className="tabular text-fg">{a}</span>
        <span>{label}</span>
        <span className="tabular text-fg">{b}</span>
      </div>
      <div className="flex h-1.5 overflow-hidden rounded-full bg-bg">
        <div className="bg-fg/80" style={{ width: `${(a / tot) * 100}%` }} />
        <div className="bg-muted/50" style={{ width: `${(b / tot) * 100}%` }} />
      </div>
    </div>
  );
}

function SubPanel({
  xi,
  bench,
  slots,
}: {
  xi: string[];
  bench: string[];
  slots: string[];
}) {
  const game = useGame((s) => s.game)!;
  const bump = useGame((s) => s.bump);
  const selectedId = useGame((s) => s.selectedId);
  const setSelected = useGame((s) => s.setSelected);
  const flash = useGame((s) => s.flash);

  function tap(id: string, from: "xi" | "bench") {
    if (!selectedId) {
      setSelected(id);
      return;
    }
    const selFromXi = xi.includes(selectedId);
    if (from === "bench" && selFromXi) {
      const err = game.sub(selectedId, id);
      if (err) flash(err);
      setSelected(null);
      bump();
      return;
    }
    if (from === "xi" && bench.includes(selectedId)) {
      const err = game.sub(id, selectedId);
      if (err) flash(err);
      setSelected(null);
      bump();
      return;
    }
    setSelected(id);
  }

  return (
    <div>
      <ul className="mb-2">
        {xi.map((id, i) => {
          const p = game.state.players[id];
          if (!p) return null;
          return (
            <li key={id}>
              <button
                onClick={() => tap(id, "xi")}
                className={cn(
                  "flex w-full items-center gap-2 rounded-xs px-1 py-1 text-left text-xs",
                  selectedId === id && "bg-elevated",
                )}
              >
                <span className="w-7 text-muted">{slots[i]}</span>
                <span className="flex-1 truncate">{p.name}</span>
                <span className="tabular text-muted">{Math.round(p.energy)}%</span>
              </button>
            </li>
          );
        })}
      </ul>
      <p className="mb-1 text-[10px] uppercase tracking-wide text-muted">Yedek</p>
      <ul>
        {bench.map((id) => {
          const p = game.state.players[id];
          if (!p) return null;
          return (
            <li key={id}>
              <button
                onClick={() => tap(id, "bench")}
                className={cn(
                  "flex w-full items-center gap-2 rounded-xs px-1 py-1 text-left text-xs",
                  selectedId === id && "bg-elevated",
                )}
              >
                <span className="w-7 text-muted">{p.pos}</span>
                <span className="flex-1 truncate">{p.name}</span>
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
