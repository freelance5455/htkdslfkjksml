import { ClubLogo } from "@/components/game/ClubLogo";
import { Btn } from "@/components/game/ui";
import { TEAM_BY_ID } from "@/lib/game/data/teams";
import { listSlots } from "@/lib/game/save";
import { Sound } from "@/lib/game/sound";
import { useGame } from "@/lib/game/store";
import type { SaveSlotMeta } from "@/lib/game/types";
import { Award, CircleHelp, FolderOpen, Play, Settings2, Volume2, VolumeX } from "lucide-react";
import { useEffect, useState } from "react";

export function Menu() {
  const { sound, toggleSound, setScreen, load } = useGame();
  const [slots, setSlots] = useState<SaveSlotMeta[]>([]);
  useEffect(() => {
    setSlots(listSlots());
  }, []);
  const latest = [...slots].reverse().find((s) => s.occupied) || slots.find((s) => s.occupied);
  const club = latest?.club ? TEAM_BY_ID[latest.club] : undefined;

  return (
    <div className="pitch-bg relative min-h-dvh">
      <div className="mx-auto flex min-h-dvh max-w-lg flex-col px-5 pb-8 pt-6">
        <div className="flex items-center justify-between">
          <div className="text-[11px] uppercase tracking-[0.22em] text-muted">v25 · TR</div>
          <button
            type="button"
            aria-label={sound ? "Sesi kapat" : "Sesi ac"}
            className="grid size-11 place-items-center rounded-full bg-bg-soft hairline"
            onClick={() => {
              Sound.tap();
              toggleSound();
            }}
          >
            {sound ? <Volume2 size={18} /> : <VolumeX size={18} />}
          </button>
        </div>

        <div className="flex flex-1 flex-col justify-center py-8">
          <p className="text-[12px] font-medium uppercase tracking-[0.28em] text-pitch">Oyuncu kariyer modu</p>
          <h1 className="mt-2 font-display text-[56px] leading-[0.88] tracking-tight sm:text-[72px]">
            FUTBOL
            <br />
            KARİYERİ
          </h1>
          <p className="mt-4 max-w-[34ch] text-[15px] leading-relaxed text-muted">
            Sıfırdan bir isim ol. Liglerde ilerle, stadyum ışıklarında oyna, transfer tekliflerini oku.
          </p>

          <div className="mt-8 flex flex-col gap-2.5">
            {latest?.occupied && (
              <Btn
                tone="primary"
                className="h-14 justify-between px-5"
                onClick={() => {
                  Sound.click();
                  load(latest.slot);
                }}
              >
                <span className="flex items-center gap-3">
                  {club && <ClubLogo team={club} size={28} />}
                  <span className="text-left">
                    <span className="block text-[11px] uppercase tracking-[0.16em] opacity-70">Kariyere devam et</span>
                    <span className="block font-display text-xl leading-none">{latest.name}</span>
                  </span>
                </span>
                <Play size={16} />
              </Btn>
            )}
            <Btn
              className="h-12 justify-start"
              onClick={() => {
                Sound.click();
                setScreen("create");
              }}
            >
              Yeni kariyer
            </Btn>
            <Btn
              className="h-12 justify-start gap-3"
              onClick={() => {
                Sound.click();
                setScreen("load");
              }}
            >
              <FolderOpen size={16} />
              Kariyer yükle
            </Btn>
            <div className="grid grid-cols-3 gap-2.5">
              <Btn
                className="h-12 px-2 text-[13px]"
                onClick={() => {
                  Sound.tap();
                  setScreen("achievements");
                }}
              >
                <Award size={15} /> Başarım
              </Btn>
              <Btn
                className="h-12 px-2 text-[13px]"
                onClick={() => {
                  Sound.tap();
                  setScreen("howto");
                }}
              >
                <CircleHelp size={15} /> Nasıl
              </Btn>
              <Btn
                className="h-12 px-2 text-[13px]"
                onClick={() => {
                  Sound.tap();
                  setScreen("settings");
                }}
              >
                <Settings2 size={15} /> Ayarlar
              </Btn>
            </div>
          </div>
        </div>

        <div className="text-center text-[12px] text-subtle">Kayitlar bu cihazda tutulur · 3 yuva</div>
      </div>
    </div>
  );
}
