import { Btn, Field, Input, Select } from "@/components/game/ui";
import {
  ALLOC_ATTRS,
  ARCHETYPES,
  ATTR_TR,
  COUNTRIES,
  PERSONALITIES,
  POSITIONS,
  attrCost,
} from "@/lib/game/constants";
import { blankAttrs, calcOverall } from "@/lib/game/engine/attrs";
import { Sound } from "@/lib/game/sound";
import { useGame } from "@/lib/game/store";
import { Minus, Plus } from "lucide-react";

export function Create() {
  const { draft, setDraft, createStep, setStep, setScreen } = useGame();
  const ovr = calcOverall(draft.pos, draft.attrs);
  const minDob = "1981-10-01";
  const maxDob = "2010-10-01";

  return (
    <div className="mx-auto min-h-dvh max-w-lg px-4 pb-28 pt-6">
      <button
        type="button"
        className="text-[13px] text-muted"
        onClick={() => {
          Sound.tap();
          if (createStep > 1) setStep(createStep - 1);
          else setScreen("menu");
        }}
      >
        Geri
      </button>
      <div className="mt-3 flex items-end justify-between">
        <h1 className="font-display text-4xl tracking-tight">Oyuncu olustur</h1>
        <span className="tabular-nums text-muted">Adim {createStep}/4</span>
      </div>
      <div className="mt-3 flex gap-1.5">
        {[1, 2, 3, 4].map((n) => (
          <div key={n} className={"h-1 flex-1 rounded-full " + (n <= createStep ? "bg-accent" : "bg-bg-hover")} />
        ))}
      </div>

      {createStep === 1 && (
        <div className="mt-6 grid gap-3 fade-up">
          <Field label="Ad">
            <Input value={draft.firstName} onChange={(e) => setDraft({ firstName: e.target.value })} />
          </Field>
          <Field label="Soyad">
            <Input value={draft.lastName} onChange={(e) => setDraft({ lastName: e.target.value })} />
          </Field>
          <Field label="Gorunen ad">
            <Input value={draft.displayName} onChange={(e) => setDraft({ displayName: e.target.value })} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Uyruk">
              <Select value={draft.nat} onChange={(e) => setDraft({ nat: e.target.value })}>
                {COUNTRIES.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Ikinci uyruk">
              <Select value={draft.nat2} onChange={(e) => setDraft({ nat2: e.target.value })}>
                <option value="">Yok</option>
                {COUNTRIES.filter((c) => c.id !== draft.nat).map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </Select>
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Dogum tarihi">
              <Input type="date" min={minDob} max={maxDob} value={draft.dob} onChange={(e) => setDraft({ dob: e.target.value })} />
            </Field>
            <Field label="Ayak">
              <Select value={draft.foot} onChange={(e) => setDraft({ foot: e.target.value as "right" | "left" })}>
                <option value="right">Sag</option>
                <option value="left">Sol</option>
              </Select>
            </Field>
          </div>
        </div>
      )}

      {createStep === 2 && (
        <div className="mt-6 fade-up">
          <p className="mb-2 text-[12px] uppercase tracking-[0.14em] text-muted">Mevki</p>
          <div className="grid grid-cols-3 gap-2">
            {POSITIONS.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => {
                  Sound.tap();
                  setDraft({ pos: p.id });
                }}
                className={
                  "rounded-[12px] px-2 py-3 text-left hairline " +
                  (draft.pos === p.id ? "bg-accent text-accent-fg" : "bg-bg-soft")
                }
              >
                <div className="font-display text-lg leading-none">{p.id}</div>
                <div className="mt-1 text-[11px] opacity-70">{p.tr}</div>
              </button>
            ))}
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <Field label="Ikinci mevki">
              <Select value={draft.pos2} onChange={(e) => setDraft({ pos2: e.target.value as typeof draft.pos2 })}>
                <option value="">Yok</option>
                {POSITIONS.filter((p) => p.id !== draft.pos).map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.id} · {p.tr}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Forma no">
              <Input
                type="number"
                min={1}
                max={99}
                value={draft.number}
                onChange={(e) => setDraft({ number: Math.max(1, Math.min(99, Number(e.target.value) || 1)) })}
              />
            </Field>
            <Field label="Boy (cm)">
              <Input
                type="number"
                min={160}
                max={210}
                value={draft.height}
                onChange={(e) => setDraft({ height: Math.max(160, Math.min(210, Number(e.target.value) || 160)) })}
              />
            </Field>
            <Field label="Kilo (kg)">
              <Input
                type="number"
                min={55}
                max={110}
                value={draft.weight}
                onChange={(e) => setDraft({ weight: Math.max(55, Math.min(110, Number(e.target.value) || 55)) })}
              />
            </Field>
          </div>
        </div>
      )}

      {createStep === 3 && (
        <div className="mt-6 fade-up">
          <p className="mb-2 text-[12px] uppercase tracking-[0.14em] text-muted">Oyun tarzi</p>
          <div className="grid gap-2">
            {ARCHETYPES.filter((a) => a.pos.includes(draft.pos)).map((a) => (
              <button
                key={a.id}
                type="button"
                onClick={() => {
                  Sound.tap();
                  setDraft({ archetype: a.id });
                }}
                className={
                  "rounded-[16px] px-4 py-3 text-left hairline " +
                  (draft.archetype === a.id ? "bg-accent text-accent-fg" : "bg-bg-soft")
                }
              >
                <div className="font-medium">{a.tr}</div>
                <div className="text-[12px] opacity-70">{a.pos.join(" · ")}</div>
              </button>
            ))}
          </div>
          <p className="mb-2 mt-5 text-[12px] uppercase tracking-[0.14em] text-muted">Kişilik</p>
          <div className="grid grid-cols-2 gap-2">
            {PERSONALITIES.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => {
                  Sound.tap();
                  setDraft({ personality: p.id });
                }}
                className={
                  "rounded-[12px] px-3 py-3 hairline " +
                  (draft.personality === p.id ? "bg-accent text-accent-fg" : "bg-bg-soft")
                }
              >
                {p.tr}
              </button>
            ))}
          </div>
        </div>
      )}

      {createStep === 4 && (
        <div className="mt-6 fade-up">
          <div className="mb-3 flex items-end justify-between">
            <div>
              <div className="text-[12px] uppercase tracking-[0.14em] text-muted">Puan dagit</div>
              <div className="font-display text-3xl tabular-nums">{draft.points} puan</div>
            </div>
            <div className="text-right">
              <div className="text-[12px] text-muted">GEN</div>
              <div className="font-display text-3xl tabular-nums">{ovr}</div>
            </div>
          </div>
          <p className="mb-3 text-[13px] text-muted">Her ozellik 55 baslar. 85 tavan. Yuksek degerler daha pahali.</p>
          <div className="grid gap-2">
            {ALLOC_ATTRS.map((key) => {
              const v = draft.attrs[key] ?? 55;
              const up = attrCost(v, v + 1);
              return (
                <div key={key} className="flex items-center gap-3 rounded-[16px] bg-bg-soft px-3 py-2 hairline">
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[14px]">{ATTR_TR[key] || key}</div>
                    <div className="h-1 overflow-hidden rounded-full bg-bg-hover">
                      <div className="h-full bg-pitch" style={{ width: ((v - 40) / 45) * 100 + "%" }} />
                    </div>
                  </div>
                  <div className="w-8 text-center font-display text-xl tabular-nums">{v}</div>
                  <button
                    type="button"
                    className="grid size-10 place-items-center rounded-[10px] bg-bg-elev"
                    onClick={() => {
                      if (v <= 55) return;
                      Sound.tap();
                      const refund = attrCost(v - 1, v);
                      setDraft({ attrs: { ...draft.attrs, [key]: v - 1 }, points: draft.points + refund });
                    }}
                  >
                    <Minus size={14} />
                  </button>
                  <button
                    type="button"
                    className="grid size-10 place-items-center rounded-[10px] bg-bg-elev"
                    onClick={() => {
                      if (v >= 85 || draft.points < up) return;
                      Sound.tap();
                      setDraft({ attrs: { ...draft.attrs, [key]: v + 1 }, points: draft.points - up });
                    }}
                  >
                    <Plus size={14} />
                  </button>
                </div>
              );
            })}
          </div>
          <button
            type="button"
            className="mt-3 text-[13px] text-muted underline"
            onClick={() => setDraft({ attrs: blankAttrs(55), points: 30 })}
          >
            Sifirla
          </button>
        </div>
      )}

      <div className="fixed inset-x-0 bottom-0 z-20 border-t border-line bg-bg/95 px-4 py-3 backdrop-blur">
        <div className="mx-auto max-w-lg">
          <Btn
            tone="primary"
            className="h-12 w-full"
            onClick={() => {
              Sound.click();
              if (createStep < 4) setStep(createStep + 1);
              else useGame.getState().setScreen("team");
            }}
          >
            {createStep < 4 ? "Devam" : "Kulup sec"}
          </Btn>
        </div>
      </div>
    </div>
  );
}
