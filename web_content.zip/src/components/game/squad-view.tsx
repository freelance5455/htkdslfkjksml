import { FORMATIONS } from "@/lib/game/data";
import { ovrTone } from "@/lib/game/format";
import { slotOf } from "@/lib/game/team";
import type { PlayerData } from "@/lib/game/types";
import { useGame } from "@/lib/game/store";
import { cn } from "@/lib/utils";
import { Crest, Meter, Ovr, Panel, StatusIcons } from "./primitives";

export function SquadView() {
  const game = useGame((s) => s.game)!;
  useGame((s) => s.tick);
  const selectedId = useGame((s) => s.selectedId);
  const setSelected = useGame((s) => s.setSelected);
  const bump = useGame((s) => s.bump);
  const user = game.user();
  const players = game.userPlayers();
  const form = FORMATIONS[user.tactics.formation] ?? FORMATIONS["4-3-3"]!;
  const byId = (id: string) => game.state.players[id];

  function tapPlayer(id: string) {
    if (!selectedId) {
      setSelected(id);
      return;
    }
    if (selectedId === id) {
      setSelected(null);
      return;
    }
    game.swap(selectedId, id);
    setSelected(null);
    bump();
  }

  function tapSlot(index: number) {
    if (selectedId) {
      game.setSlot(index, selectedId);
      setSelected(null);
      bump();
      return;
    }
    const id = user.xi[index];
    if (id) tapPlayer(id);
  }

  const xiSet = new Set(user.xi);
  const benchSet = new Set(user.bench);
  const rest = players.filter((p) => !xiSet.has(p.id) && !benchSet.has(p.id));

  return (
    <div className="grid h-full grid-cols-1 gap-3 p-3 lg:grid-cols-[minmax(0,1fr)_320px]">
      <Panel className="flex flex-col overflow-hidden p-3">
        <div className="mb-2 flex items-center justify-between">
          <h2 className="text-sm font-semibold">İlk 11 · {user.tactics.formation}</h2>
          <p className="text-xs text-muted">Oyuncu seç, yuvaya yerleştir</p>
        </div>
        <div className="pitch-grid relative flex min-h-[320px] flex-1 flex-col justify-between rounded-md p-3">
          {form.rows.map((row, ri) => (
            <div key={ri} className="flex justify-evenly">
              {row.map((si) => {
                const id = user.xi[si];
                const p = id ? byId(id) : undefined;
                const slot = form.slots[si]!;
                const mismatch = p && p.pos !== slot;
                return (
                  <button
                    key={si}
                    onClick={() => tapSlot(si)}
                    className={cn(
                      "flex w-[72px] flex-col items-center rounded-sm border bg-bg/80 px-1 py-1.5 backdrop-blur-sm",
                      selectedId && p?.id === selectedId
                        ? "border-accent"
                        : "border-border",
                    )}
                  >
                    <span className="text-[9px] uppercase tracking-wide text-muted">{slot}</span>
                    {p ? (
                      <>
                        <span className={cn("tabular text-sm font-semibold", ovrTone(p.ovr))}>
                          {mismatch ? Math.round(p.ovr * 0.8) : p.ovr}
                        </span>
                        <span className="w-full truncate text-[10px]">{p.name.split(" ").slice(-1)}</span>
                        <StatusIcons p={p} />
                      </>
                    ) : (
                      <span className="text-[10px] text-faint">Boş</span>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </div>
      </Panel>

      <div className="flex min-h-0 flex-col gap-3">
        <PlayerBlock
          title="Yedekler"
          list={user.bench.map((id) => byId(id)).filter((p): p is PlayerData => !!p)}
          selectedId={selectedId}
          onTap={tapPlayer}
        />
        <PlayerBlock title="Rezerv" list={rest} selectedId={selectedId} onTap={tapPlayer} />
      </div>
    </div>
  );
}

function PlayerBlock({
  title,
  list,
  selectedId,
  onTap,
}: {
  title: string;
  list: PlayerData[];
  selectedId: string | null;
  onTap: (id: string) => void;
}) {
  const game = useGame((s) => s.game)!;
  const user = game.user();
  return (
    <Panel className="min-h-0 flex-1 overflow-hidden">
      <div className="border-b border-border px-3 py-2 text-xs font-medium uppercase tracking-wide text-muted">
        {title}
      </div>
      <ul className="max-h-64 overflow-auto lg:max-h-none">
        {list.map((p) => {
          const locked = !!p.inj || p.ban > 0;
          return (
            <li key={p.id}>
              <button
                onClick={() => !locked && onTap(p.id)}
                disabled={locked}
                className={cn(
                  "flex w-full items-center gap-2 px-3 py-2 text-left hover:bg-elevated",
                  selectedId === p.id && "bg-elevated",
                  locked && "opacity-50",
                )}
              >
                <Ovr n={p.ovr} />
                <span className="w-8 text-[11px] text-muted">{p.pos}</span>
                <span className="min-w-0 flex-1 truncate text-sm">{p.name}</span>
                <StatusIcons p={p} />
                <div className="w-12">
                  <Meter value={p.energy} />
                </div>
              </button>
            </li>
          );
        })}
        {list.length === 0 ? (
          <li className="px-3 py-4 text-xs text-muted">Liste boş</li>
        ) : null}
      </ul>
      <div className="hidden">
        <Crest club={user} size={16} />
      </div>
    </Panel>
  );
}
