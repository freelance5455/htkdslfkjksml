import { Button } from "@/components/ui/button";
import { useGameStore } from "@/game/store";

type Props = {
  onAgain: () => void;
  onQuit: () => void;
};

export function GameOverScreen({ onAgain, onQuit }: Props) {
  const score = useGameStore((s) => s.score);
  const wave = useGameStore((s) => s.wave);
  const kills = useGameStore((s) => s.kills);
  const highScore = useGameStore((s) => s.highScore);
  const newRecord = useGameStore((s) => s.newRecord);

  return (
    <div className="absolute inset-0 z-30 flex items-end justify-center bg-bg/75 sm:items-center">
      <div className="mb-[max(1.5rem,env(safe-area-inset-bottom))] w-full max-w-md rounded-xl border border-border bg-surface p-6 sm:mb-0">
        <p className="font-display text-xs uppercase tracking-[0.3em] text-muted">Fallen</p>
        <h2 className="mt-1 font-display text-3xl text-fg">Gallows Hollow keeps you</h2>
        {newRecord ? (
          <p className="mt-2 text-sm text-accent">A new ledger mark.</p>
        ) : null}
        <dl className="mt-5 grid grid-cols-3 gap-3 font-display">
          <div>
            <dt className="text-xs uppercase tracking-wide text-subtle">Score</dt>
            <dd className="mt-1 text-xl tabular-nums text-fg">{score.toLocaleString()}</dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-wide text-subtle">Wave</dt>
            <dd className="mt-1 text-xl tabular-nums text-fg">{wave}</dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-wide text-subtle">Put down</dt>
            <dd className="mt-1 text-xl tabular-nums text-fg">{kills}</dd>
          </div>
        </dl>
        <p className="mt-3 text-sm tabular-nums text-subtle">Best {highScore.toLocaleString()}</p>
        <div className="mt-6 flex flex-col gap-3">
          <Button size="lg" className="w-full" onClick={onAgain}>
            Stand again
          </Button>
          <Button variant="secondary" className="w-full" onClick={onQuit}>
            Town square
          </Button>
        </div>
      </div>
    </div>
  );
}
