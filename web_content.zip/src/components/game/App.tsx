import { Career } from "@/components/game/Career";
import { Create } from "@/components/game/Create";
import { MatchPlay } from "@/components/game/MatchPlay";
import { Menu } from "@/components/game/Menu";
import { TeamSelect } from "@/components/game/TeamSelect";
import { Btn, Panel } from "@/components/game/ui";
import { ClubLogo } from "@/components/game/ClubLogo";
import { ACHIEVEMENTS } from "@/lib/game/constants";
import { TEAM_BY_ID } from "@/lib/game/data/teams";
import { listSlots } from "@/lib/game/save";
import { Sound, unlockSound } from "@/lib/game/sound";
import { useGame } from "@/lib/game/store";
import { clearSlot } from "@/lib/game/save";
import { useEffect } from "react";

export function GameApp() {
  const { hydrate, screen, toast, sound, toggleSound, setScreen, load } = useGame();

  useEffect(() => {
    hydrate();
    const on = () => unlockSound();
    window.addEventListener("pointerdown", on, { once: true });
    const vis = () => {
      if (document.visibilityState === "visible") unlockSound();
    };
    document.addEventListener("visibilitychange", vis);
    return () => {
      window.removeEventListener("pointerdown", on);
      document.removeEventListener("visibilitychange", vis);
    };
  }, [hydrate]);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      {screen === "menu" && <Menu />}
      {screen === "create" && <Create />}
      {screen === "team" && <TeamSelect />}
      {screen === "career" && <Career />}
      {screen === "match" && <MatchPlay />}
      {screen === "load" && <LoadScreen />}
      {screen === "achievements" && <AchievementsScreen />}
      {screen === "howto" && <HowTo />}
      {screen === "settings" && <SettingsScreen />}
      {toast && (
        <div className="pointer-events-none fixed inset-x-0 top-4 z-50 flex justify-center px-4">
          <div
            className={
              "rounded-full px-4 py-2 text-[14px] hairline " +
              (toast.kind === "bad" ? "bg-danger/20 text-danger" : "bg-bg-elev text-fg")
            }
          >
            {toast.text}
          </div>
        </div>
      )}
    </div>
  );

  function LoadScreen() {
    const slots = listSlots();
    return (
      <Meta title="Kariyer yukle">
        <div className="grid gap-3">
          {slots.map((s) => {
            const club = s.club ? TEAM_BY_ID[s.club] : undefined;
            return (
              <Panel key={s.slot} className="flex items-center gap-3">
                <div className="w-8 font-display text-2xl text-muted">{s.slot + 1}</div>
                {s.occupied ? (
                  <>
                    {club && <ClubLogo team={club} size={32} />}
                    <div className="flex-1">
                      <div className="font-medium">{s.name}</div>
                      <div className="text-[12px] text-muted">
                        {club?.name} · OVR {s.ovr} · {s.season} H{s.week}
                      </div>
                    </div>
                    <Btn
                      tone="primary"
                      onClick={() => {
                        Sound.click();
                        load(s.slot);
                      }}
                    >
                      Yukle
                    </Btn>
                    <Btn
                      tone="danger"
                      onClick={() => {
                        clearSlot(s.slot);
                        setScreen("menu");
                        setScreen("load");
                      }}
                    >
                      Sil
                    </Btn>
                  </>
                ) : (
                  <div className="text-muted">Bos yuva</div>
                )}
              </Panel>
            );
          })}
        </div>
      </Meta>
    );
  }

  function AchievementsScreen() {
    const career = useGame.getState().career;
    return (
      <Meta title="Basarimlar">
        <div className="grid gap-2">
          {ACHIEVEMENTS.map((a) => {
            const on = career?.achievements.includes(a.id);
            return (
              <Panel key={a.id} className="flex items-center justify-between">
                <div>
                  <div className="font-medium">{a.tr}</div>
                  <div className="text-[13px] text-muted">{a.desc}</div>
                </div>
                <div className={on ? "text-ok" : "text-subtle"}>{on ? "Acildi" : "Kilitli"}</div>
              </Panel>
            );
          })}
        </div>
      </Meta>
    );
  }

  function HowTo() {
    return (
      <Meta title="Nasil oynanir">
        <Panel className="grid gap-3 text-[15px] leading-relaxed text-muted">
          <p>Oyuncu olustur, 30 puani ozelliklere dagit, bir kulup sec.</p>
          <p>Her hafta antrenman yap. Mac gununde sahaya cik veya simule et.</p>
          <p>Mac icinde anlik kararlar reytingini, gol ve asistini belirler.</p>
          <p>Footballgram'da paylas, DM at, takipci kas. Yasaminda ev, araba ve iliski yonet.</p>
          <p>Guclu form, daha iyi teklifler demek. Menajer guveni ilk 11'e giden yoldur.</p>
        </Panel>
      </Meta>
    );
  }

  function SettingsScreen() {
    return (
      <Meta title="Ayarlar">
        <Panel className="grid gap-4">
          <div className="flex items-center justify-between">
            <div>
              <div>Dil</div>
              <div className="text-[13px] text-muted">Turkce</div>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <div>Ses efektleri</div>
              <div className="text-[13px] text-muted">{sound ? "Acik" : "Kapali"}</div>
            </div>
            <Btn
              onClick={() => {
                Sound.tap();
                toggleSound();
              }}
            >
              {sound ? "Kapat" : "Ac"}
            </Btn>
          </div>
          <p className="text-[13px] text-muted">Otomatik kayit her hafta ilerlemede calisir. 3 yuva, surum 25.</p>
        </Panel>
      </Meta>
    );
  }
}

function Meta({ title, children }: { title: string; children: React.ReactNode }) {
  const setScreen = useGame((s) => s.setScreen);
  const career = useGame((s) => s.career);
  return (
    <div className="mx-auto min-h-dvh max-w-lg px-4 py-6">
      <button
        type="button"
        className="text-[13px] text-muted"
        onClick={() => {
          Sound.tap();
          setScreen(career ? "career" : "menu");
        }}
      >
        Geri
      </button>
      <h1 className="mt-3 font-display text-4xl tracking-tight">{title}</h1>
      <div className="mt-5">{children}</div>
    </div>
  );
}
