import { FORMATIONS, MENT_LABEL, PRESS_LABEL, STYLE_LABEL } from "@/lib/game/data";
import { chemistry } from "@/lib/game/team";
import type { Mentality, PlayStyle, PressLine } from "@/lib/game/types";
import { useGame } from "@/lib/game/store";
import { Btn, Panel } from "./primitives";

export function TacticsView() {
  const game = useGame((s) => s.game)!;
  const bump = useGame((s) => s.bump);
  useGame((s) => s.tick);
  const t = game.user().tactics;
  const chem = Math.round(chemistry(game.user(), game.state.players) * 100);

  function set<K extends keyof typeof t>(key: K, value: (typeof t)[K]) {
    game.setTactics({ [key]: value });
    bump();
  }

  return (
    <div className="mx-auto grid max-w-4xl gap-3 p-3 md:grid-cols-2">
      <Panel className="p-4">
        <h2 className="mb-3 text-sm font-semibold">Diziliş</h2>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {Object.keys(FORMATIONS).map((f) => (
            <Btn
              key={f}
              variant={t.formation === f ? "primary" : "soft"}
              onClick={() => set("formation", f)}
            >
              {f}
            </Btn>
          ))}
        </div>
        <p className="mt-4 text-xs text-muted">
          Mevki uyumu {chem}%. Doğal mevki dışında reyting %20 düşer.
        </p>
      </Panel>

      <Panel className="p-4">
        <h2 className="mb-3 text-sm font-semibold">Oyun stili</h2>
        <Row
          options={STYLE_LABEL}
          value={t.style}
          onChange={(v) => set("style", v as PlayStyle)}
        />
        <h2 className="mb-3 mt-5 text-sm font-semibold">Pres çizgisi</h2>
        <Row
          options={PRESS_LABEL}
          value={t.press}
          onChange={(v) => set("press", v as PressLine)}
        />
        <h2 className="mb-3 mt-5 text-sm font-semibold">Mentolite</h2>
        <Row
          options={MENT_LABEL}
          value={t.mentality}
          onChange={(v) => set("mentality", v as Mentality)}
        />
      </Panel>

      <Panel className="p-4 md:col-span-2">
        <h2 className="mb-2 text-sm font-semibold">Eşleşme notu</h2>
        <ul className="grid gap-2 text-sm text-muted sm:grid-cols-3">
          <li>Kontra, yüksek prese karşı avantajlıdır.</li>
          <li>Kısa pas, düşük bloğu açmakta iyidir.</li>
          <li>Yüksek pres yorar; sakatlık riski artar.</li>
        </ul>
      </Panel>
    </div>
  );
}

function Row({
  options,
  value,
  onChange,
}: {
  options: Record<string, string>;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div className="grid grid-cols-3 gap-2">
      {Object.entries(options).map(([k, lab]) => (
        <Btn key={k} variant={value === k ? "primary" : "soft"} onClick={() => onChange(k)}>
          {lab}
        </Btn>
      ))}
    </div>
  );
}
