import { useEffect, useRef, useState } from "react";
import type { AtlasEngine } from "@/game/engine";
import { useGameStore } from "@/game/store";
import { unlockAudio, startDrone } from "@/game/audio";
import { Hud } from "./Hud";
import { StartScreen } from "./StartScreen";
import { CatalogPanel } from "./CatalogPanel";
import { TouchPad } from "./TouchPad";
import { PauseOverlay } from "./PauseOverlay";

export function GameRoot() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<AtlasEngine | null>(null);
  const pendingStart = useRef(false);
  const [ready, setReady] = useState(false);
  const [fail, setFail] = useState<string | null>(null);
  const phase = useGameStore((s) => s.hud.phase);
  const catalogOpen = useGameStore((s) => s.catalogOpen);

  useEffect(() => {
    useGameStore.getState().load();
    let disposed = false;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const onHide = () => {
      if (document.hidden) useGameStore.getState().persist();
    };
    document.addEventListener("visibilitychange", onHide);
    import("@/game/engine")
      .then(({ AtlasEngine }) => {
        if (disposed || !canvas) return;
        const engine = new AtlasEngine(canvas);
        engineRef.current = engine;
        setReady(true);
        if (pendingStart.current) engine.startExpedition();
      })
      .catch((err: unknown) => {
        setFail(err instanceof Error ? err.message : "WebGL failed to start");
      });
    return () => {
      disposed = true;
      document.removeEventListener("visibilitychange", onHide);
      engineRef.current?.dispose();
      engineRef.current = null;
      useGameStore.getState().persist();
    };
  }, []);

  const start = () => {
    unlockAudio();
    startDrone();
    if (engineRef.current) engineRef.current.startExpedition();
    else pendingStart.current = true;
  };

  const warpTo = (id: number) => {
    engineRef.current?.warpTo(id);
    engineRef.current?.setTarget(id);
    useGameStore.getState().setCatalogOpen(false);
  };

  return (
    <main className="fixed inset-0 overflow-hidden bg-bg text-fg">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 block h-full w-full touch-none"
        aria-label="Galaxy Atlas 3D view"
      />
      {fail && (
        <div className="absolute inset-0 z-30 grid place-items-center bg-bg p-6 text-center">
          <div className="max-w-md rounded-xl border border-border bg-surface p-6">
            <h1 className="text-lg font-medium">Atlas cannot start</h1>
            <p className="mt-2 text-sm text-muted">{fail}</p>
          </div>
        </div>
      )}
      {phase === "attract" && <StartScreen onStart={start} ready={ready} />}
      {phase !== "attract" && (
        <>
          <Hud
            onPause={() => engineRef.current?.togglePause()}
            onDimension={(mode) => engineRef.current?.setDimension(mode)}
            onSlice={(w, v) => engineRef.current?.setDimensionSlice(w, v)}
            onCatalog={() => useGameStore.getState().setCatalogOpen(!catalogOpen)}
            onWarp={() => {
              const id = useGameStore.getState().hud.targetId;
              if (id != null) warpTo(id);
            }}
          />
          <TouchPad
            onChange={(t) => engineRef.current?.setTouch(t)}
            onWarp={() => {
              const id = useGameStore.getState().hud.targetId ?? 0;
              warpTo(id);
            }}
            onPause={() => engineRef.current?.togglePause()}
            onCatalog={() => useGameStore.getState().setCatalogOpen(!catalogOpen)}
          />
        </>
      )}
      {catalogOpen && <CatalogPanel onWarp={warpTo} />}
      {phase === "pause" && (
        <PauseOverlay
          onResume={() => engineRef.current?.setPaused(false)}
          onReset={() => {
            useGameStore.getState().resetProgress();
            engineRef.current?.startExpedition();
          }}
        />
      )}
    </main>
  );
}
