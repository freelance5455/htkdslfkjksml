import { ClubLogo } from "@/components/game/ClubLogo";
import { Btn, Panel } from "@/components/game/ui";
import { LEAGUES, TEAM_BY_ID } from "@/lib/game/data/teams";
import { wageFor } from "@/lib/game/engine/create";
import { calcOverall } from "@/lib/game/engine/attrs";
import { fmtMoney } from "@/lib/game/format";
import { Sound } from "@/lib/game/sound";
import { suggestedSlot, useGame } from "@/lib/game/store";
import { Shuffle } from "lucide-react";
import { useState } from "react";

export function TeamSelect() {
  const { draft, offers, shuffleClubs, startFromClub, setScreen, setStep } = useGame();
  const [picked, setPicked] = useState<string | null>(null);
  const ovr = calcOverall(draft.pos, draft.attrs);

  return (
    <div className="mx-auto min-h-dvh max-w-lg px-4 pb-28 pt-6">
      <button
        type="button"
        className="text-[13px] text-muted"
        onClick={() => {
          Sound.tap();
          setStep(4);
          setScreen("create");
        }}
      >
        Geri
      </button>
      <h1 className="mt-3 font-display text-4xl tracking-tight">Ilk kulubun</h1>
      <p className="mt-2 text-[15px] text-muted">Uc teklif. Gucune gore haftalik maas belirlenir.</p>

      <div className="mt-5 grid gap-3">
        {offers.map((id) => {
          const t = TEAM_BY_ID[id];
          if (!t) return null;
          const league = LEAGUES.find((l) => l.id === t.leagueId);
          const wage = wageFor(ovr, t.power);
          const on = picked === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => {
                Sound.tap();
                setPicked(id);
              }}
              className={"rounded-[28px] p-4 text-left hairline " + (on ? "bg-accent text-accent-fg" : "bg-bg-elev")}
            >
              <div className="flex items-center gap-3">
                <ClubLogo team={t} size={44} />
                <div className="min-w-0 flex-1">
                  <div className="font-display text-2xl leading-none">{t.name}</div>
                  <div className={"mt-1 text-[12px] " + (on ? "opacity-70" : "text-muted")}>
                    {t.country} · {league?.name}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-display text-2xl tabular-nums">{t.power}</div>
                  <div className={"text-[10px] uppercase tracking-[0.14em] " + (on ? "opacity-70" : "text-muted")}>Guc</div>
                </div>
              </div>
              <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-black/20">
                <div className="h-full bg-pitch" style={{ width: t.power + "%" }} />
              </div>
              <div className={"mt-2 text-[13px] " + (on ? "opacity-80" : "text-muted")}>
                Teklif edilen maas {fmtMoney(wage)} / hafta
              </div>
            </button>
          );
        })}
      </div>

      <Btn
        className="mt-4 w-full"
        onClick={() => {
          Sound.pop();
          shuffleClubs();
          setPicked(null);
        }}
      >
        <Shuffle size={16} /> Karistir
      </Btn>

      <Panel className="mt-4 text-[13px] text-muted">
        {draft.displayName} · {draft.pos} · GEN {ovr}
      </Panel>

      <div className="fixed inset-x-0 bottom-0 z-20 border-t border-line bg-bg/95 px-4 py-3 backdrop-blur">
        <div className="mx-auto max-w-lg">
          <Btn
            tone="primary"
            className="h-12 w-full"
            disabled={!picked}
            onClick={() => {
              if (!picked) return;
              Sound.success();
              startFromClub(picked, suggestedSlot());
            }}
          >
            Kariyere basla
          </Btn>
        </div>
      </div>
    </div>
  );
}
