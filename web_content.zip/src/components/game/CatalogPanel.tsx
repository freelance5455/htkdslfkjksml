import { useMemo, useState } from "react";
import { CATALOG, KIND_LABEL } from "@/game/catalog";
import { useGameStore } from "@/game/store";
import { Button } from "@/components/ui/button";

export function CatalogPanel({ onWarp }: { onWarp: (id: number) => void }) {
  const discovered = useGameStore((s) => s.save.discovered);
  const targetId = useGameStore((s) => s.hud.targetId);
  const [filter, setFilter] = useState<"all" | "real" | "recipe" | "blackhole">("all");
  const [query, setQuery] = useState("");
  const selected = targetId != null ? CATALOG[targetId] : CATALOG[0];

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return CATALOG.filter((b) => {
      const group = b.kind === "blackhole" ? "blackhole" : b.recipeId != null ? "recipe" : "real";
      if (filter !== "all" && group !== filter) return false;
      return !q || b.name.toLowerCase().includes(q) || b.info.toLowerCase().includes(q);
    });
  }, [filter, query]);

  return (
    <div className="absolute inset-0 z-20 flex items-end justify-end bg-bg/55 p-3 backdrop-blur-[2px] sm:items-stretch sm:p-5" onClick={() => useGameStore.getState().setCatalogOpen(false)}>
      <div className="flex h-[min(82dvh,46rem)] w-full max-w-2xl flex-col overflow-hidden rounded-2xl border border-border-strong bg-surface/95 shadow-2xl backdrop-blur-xl sm:h-full" onClick={(e) => e.stopPropagation()}>
        <div className="border-b border-border p-4">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="font-mono text-2xs tracking-[0.18em] text-muted uppercase">Atlas menu · selectable objects</p>
              <h2 className="mt-1 text-base font-medium">{discovered.length}/{CATALOG.length} charted</h2>
            </div>
            <Button variant="ghost" size="sm" onClick={() => useGameStore.getState().setCatalogOpen(false)}>Close</Button>
          </div>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {(["all", "real", "recipe", "blackhole"] as const).map((k) => (
              <button key={k} type="button" onClick={() => setFilter(k)} className={`rounded-md border px-2 py-1.5 font-mono text-2xs uppercase tracking-wider ${filter === k ? "border-accent bg-accent/10 text-fg" : "border-border text-muted"}`}>
                {k === "all" ? `All · ${CATALOG.length}` : k === "real" ? "Real galaxies · 26" : k === "recipe" ? "Recipes · 88" : "Black holes · 5"}
              </button>
            ))}
          </div>
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search the atlas…" className="mt-3 w-full rounded-md border border-border bg-bg/60 px-3 py-2.5 text-xs text-fg outline-none placeholder:text-subtle focus:border-border-strong" />
        </div>

        <div className="grid min-h-0 flex-1 grid-cols-1 md:grid-cols-[minmax(0,1fr)_15rem]">
          <div className="min-h-0 overflow-y-auto p-2">
            {visible.map((b) => {
              const found = discovered.includes(String(b.id));
              const active = targetId === b.id;
              return (
                <button key={b.id} type="button" onClick={() => onWarp(b.id)} className={`mb-1 flex w-full items-center justify-between gap-3 rounded-lg border px-3 py-2.5 text-left ${active ? "border-accent/40 bg-accent/8" : "border-transparent hover:border-border hover:bg-surface-2/60"}`}>
                  <span className="min-w-0">
                    <span className="block truncate text-sm text-fg">{found ? b.name : "Uncharted signal"}</span>
                    <span className="block truncate font-mono text-2xs text-subtle">{found ? KIND_LABEL[b.kind] : b.recipeId != null ? "Procedural morphology" : "Unknown signal"} · warp</span>
                  </span>
                  <span className={`size-2 shrink-0 rounded-full ${found ? "bg-ok shadow-[0_0_12px_rgba(124,227,182,.55)]" : "bg-subtle"}`} />
                </button>
              );
            })}
            {visible.length === 0 && <p className="p-8 text-center text-xs text-muted">No atlas objects match that search.</p>}
          </div>

          <aside className="hidden min-h-0 overflow-y-auto border-l border-border bg-bg/25 p-4 md:block">
            <p className="font-mono text-2xs tracking-[0.15em] text-muted uppercase">Selected signal</p>
            <div className="mt-3 rounded-xl border border-border bg-surface-2/40 p-3">
              <div className="mb-3 aspect-square rounded-lg bg-[radial-gradient(circle_at_50%_50%,rgba(169,218,255,.22),transparent_48%),radial-gradient(circle,rgba(255,199,128,.12),transparent_70%)]" />
              <h3 className="text-sm font-medium text-fg">{selected.name}</h3>
              <p className="mt-1 font-mono text-2xs text-subtle">{KIND_LABEL[selected.kind] ?? selected.kind}</p>
              <p className="mt-3 text-xs leading-relaxed text-muted">{selected.info}</p>
              <Button className="mt-4 w-full" onClick={() => onWarp(selected.id)}>Warp to object</Button>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
