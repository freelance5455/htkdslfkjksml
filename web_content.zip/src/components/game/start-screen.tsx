import { useEffect, useMemo, useState } from "react";
import { CLUB_RAW, LEAGUES } from "@/lib/game/data";
import { hasSave } from "@/lib/game/save";
import { useGame } from "@/lib/game/store";
import { Btn, Crest, Field, inputClass, Panel } from "./primitives";

const FEATURED = [
  "Galatasaray",
  "Fenerbahçe",
  "Beşiktaş",
  "Real Madrid",
  "Manchester City",
  "Bayern Münih",
  "Barcelona",
  "Liverpool",
  "Paris Saint-Germain",
  "Inter",
];

export function StartScreen() {
  const startClub = useGame((s) => s.startClub);
  const createClub = useGame((s) => s.createClub);
  const continueSave = useGame((s) => s.continueSave);
  const [saved, setSaved] = useState(false);
  const [tab, setTab] = useState<"pick" | "create">("pick");
  const [q, setQ] = useState("");
  const [league, setLeague] = useState("TUR1");
  const [busy, setBusy] = useState(false);
  const [manager, setManager] = useState("Teknik Direktör");
  const [form, setForm] = useState({
    name: "Mavi Kartal",
    short: "MKA",
    stadium: "Yeni Şehir Stadyumu",
    primary: "#1f4e79",
    secondary: "#d9e2e8",
    budget: 12_000_000,
    manager: "Teknik Direktör",
  });

  const clubs = useMemo(() => {
    const rows: { league: string; leagueName: string; name: string; short: string; stadium: string; colors: [string, string]; rep: number }[] = [];
    for (const L of LEAGUES) {
      for (const r of CLUB_RAW[L.id] ?? []) {
        rows.push({
          league: L.id,
          leagueName: L.name,
          name: r[0],
          short: r[1],
          stadium: r[2],
          colors: [r[4], r[5]],
          rep: r[3],
        });
      }
    }
    return rows;
  }, []);

  const filtered = clubs.filter((c) => {
    if (league !== "ALL" && c.league !== league) return false;
    if (!q.trim()) return true;
    const s = q.toLowerCase();
    return c.name.toLowerCase().includes(s) || c.short.toLowerCase().includes(s);
  });

  const featured = clubs.filter((c) => FEATURED.includes(c.name));

  useEffect(() => {
    setSaved(hasSave());
  }, []);

  function goPick(name: string) {
    setBusy(true);
    window.setTimeout(() => startClub(name, manager || "Teknik Direktör"), 40);
  }

  function goCreate() {
    setBusy(true);
    window.setTimeout(
      () =>
        createClub({
          ...form,
          short: form.short.slice(0, 4).toUpperCase(),
          manager: form.manager || manager,
        }),
      40,
    );
  }

  return (
    <div className="relative flex min-h-dvh flex-col bg-bg">
      <header className="flex items-end justify-between gap-4 px-5 pb-3 pt-6 sm:px-8">
        <div>
          <p className="text-[11px] font-medium uppercase tracking-[0.22em] text-muted">
            Teknik Direktör Simülasyonu
          </p>
          <h1 className="mt-1 font-sans text-4xl font-semibold tracking-tight text-fg sm:text-5xl">
            Onbir
          </h1>
        </div>
        {saved ? (
          <Btn onClick={continueSave} className="shrink-0">
            Kayda devam
          </Btn>
        ) : null}
      </header>

      <div className="flex gap-1 px-5 sm:px-8">
        <Tab active={tab === "pick"} onClick={() => setTab("pick")}>
          Hazır takım
        </Tab>
        <Tab active={tab === "create"} onClick={() => setTab("create")}>
          Sıfırdan kulüp
        </Tab>
      </div>

      <div className="min-h-0 flex-1 overflow-auto px-5 py-4 sm:px-8">
        {tab === "pick" ? (
          <div className="flex flex-col gap-4">
            <Field label="Menajer adı">
              <input
                className={inputClass}
                value={manager}
                onChange={(e) => setManager(e.target.value)}
                maxLength={24}
              />
            </Field>
            <div>
              <p className="mb-2 text-xs uppercase tracking-wider text-muted">Öne çıkanlar</p>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
                {featured.map((c) => (
                  <button
                    key={c.name}
                    onClick={() => goPick(c.name)}
                    className="flex items-center gap-2 rounded-md border border-border bg-surface px-2.5 py-2 text-left hover:border-accent"
                  >
                    <Crest club={c} size={32} />
                    <span className="truncate text-sm font-medium">{c.name}</span>
                  </button>
                ))}
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <select
                className={inputClass}
                value={league}
                onChange={(e) => setLeague(e.target.value)}
              >
                <option value="ALL">Tüm ligler</option>
                {LEAGUES.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.name}
                  </option>
                ))}
              </select>
              <input
                className={cnGrow()}
                placeholder="Takım ara"
                value={q}
                onChange={(e) => setQ(e.target.value)}
              />
            </div>
            <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2 lg:grid-cols-3">
              {filtered.map((c) => (
                <button
                  key={c.league + c.name}
                  onClick={() => goPick(c.name)}
                  className="flex items-center gap-3 rounded-md border border-border bg-surface px-3 py-2.5 text-left hover:border-accent"
                >
                  <Crest club={c} />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-medium">{c.name}</span>
                    <span className="text-xs text-muted">
                      {c.leagueName} · {c.stadium}
                    </span>
                  </span>
                  <span className="tabular text-xs text-muted">{c.rep}</span>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <Panel className="mx-auto max-w-xl p-5">
            <h2 className="mb-4 text-lg font-semibold">Kulüp kur</h2>
            <p className="mb-5 text-sm text-muted">
              1. Lig’den başlarsınız. Bütçe, forma renkleri ve stadyum sizin.
            </p>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <Field label="Kulüp adı">
                <input
                  className={inputClass}
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                />
              </Field>
              <Field label="Kısaltma">
                <input
                  className={inputClass}
                  value={form.short}
                  maxLength={4}
                  onChange={(e) => setForm({ ...form, short: e.target.value.toUpperCase() })}
                />
              </Field>
              <Field label="Stadyum">
                <input
                  className={inputClass}
                  value={form.stadium}
                  onChange={(e) => setForm({ ...form, stadium: e.target.value })}
                />
              </Field>
              <Field label="Menajer">
                <input
                  className={inputClass}
                  value={form.manager}
                  onChange={(e) => setForm({ ...form, manager: e.target.value })}
                />
              </Field>
              <Field label="Ana renk">
                <input
                  type="color"
                  className="h-11 w-full rounded-sm border border-border bg-bg"
                  value={form.primary}
                  onChange={(e) => setForm({ ...form, primary: e.target.value })}
                />
              </Field>
              <Field label="İkinci renk">
                <input
                  type="color"
                  className="h-11 w-full rounded-sm border border-border bg-bg"
                  value={form.secondary}
                  onChange={(e) => setForm({ ...form, secondary: e.target.value })}
                />
              </Field>
            </div>
            <div className="mt-4">
              <p className="mb-2 text-xs text-muted">Başlangıç bütçesi</p>
              <div className="grid grid-cols-3 gap-2">
                {[
                  [8_000_000, "Düşük"],
                  [12_000_000, "Orta"],
                  [22_000_000, "Yüksek"],
                ].map(([v, lab]) => (
                  <button
                    key={String(v)}
                    onClick={() => setForm({ ...form, budget: v as number })}
                    className={`rounded-sm border px-2 py-3 text-sm ${
                      form.budget === v
                        ? "border-accent bg-accent/20 text-fg"
                        : "border-border bg-bg text-muted"
                    }`}
                  >
                    {lab}
                    <span className="mt-1 block text-xs">€{(v as number) / 1_000_000}M</span>
                  </button>
                ))}
              </div>
            </div>
            <div className="mt-5 flex items-center gap-3">
              <Crest
                club={{ short: form.short || "FC", colors: [form.primary, form.secondary] }}
                size={48}
              />
              <Btn onClick={goCreate} className="flex-1">
                1. Lig’den başla
              </Btn>
            </div>
          </Panel>
        )}
      </div>

      {busy ? (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-bg/80">
          <Panel className="px-8 py-6 text-center">
            <p className="text-sm font-medium">Ligler kuruluyor</p>
            <p className="mt-1 text-xs text-muted">Kadrolar ve fikstür hazırlanıyor…</p>
          </Panel>
        </div>
      ) : null}
    </div>
  );
}

function Tab({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-sm px-4 py-2 text-sm font-medium ${
        active ? "bg-surface text-fg" : "text-muted hover:text-fg"
      }`}
    >
      {children}
    </button>
  );
}

function cnGrow() {
  return inputClass + " flex-1 min-w-[160px]";
}
