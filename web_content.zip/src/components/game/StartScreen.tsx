import { Button } from "@/components/ui/button";
import { useGameStore } from "@/game/store";

export function StartScreen({ onStart, ready }: { onStart: () => void; ready: boolean }) {
  const save = useGameStore((s) => s.save);
  const returning = save.discovered.length > 0 || save.xp > 0;

  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center bg-bg/55 px-4">
      <div className="w-full max-w-lg rounded-xl border border-border bg-surface p-6 shadow-2xl sm:p-8">
        <p className="font-mono text-2xs tracking-[0.22em] text-muted uppercase">Ultra X · cosmic survey</p>
        <h1 className="mt-3 text-3xl font-medium tracking-tight text-fg sm:text-4xl">Galaxy Atlas</h1>
        <p className="mt-3 max-w-md text-sm leading-relaxed text-muted">
          Pilot a scout craft through 26 real galaxies, 88 procedural morphology recipes, and 5 black holes. Scan systems, collect stellar samples, and explore 4D/5D projections. Stay clear of event horizons.
        </p>
        <ul className="mt-5 grid gap-1 font-mono text-2xs text-subtle sm:text-xs">
          <li>W / S throttle · A / D yaw · R / F pitch · Shift boost</li>
          <li>Hold E or Space to scan · Q warp · C Atlas Menu · V dimensions · P pause</li>
        </ul>
        {returning && (
          <p className="mt-4 font-mono text-xs text-accent">
            Saved survey · {save.discovered.length}/119 charted · {save.xp} XP
          </p>
        )}
        <div className="mt-6 flex flex-wrap gap-3">
          <Button size="lg" onClick={onStart} disabled={!ready}>
            {ready ? (returning ? "Resume expedition" : "Start expedition") : "Aligning atlas…"}
          </Button>
        </div>
      </div>
    </div>
  );
}
