import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/utils";
import type { ClubState, PlayerData } from "@/lib/game/types";
import { AlertTriangle, Ban } from "lucide-react";

export function Btn({
  variant = "primary",
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "ghost" | "soft" | "danger" | "warn";
}) {
  const styles = {
    primary: "bg-accent text-accent-fg hover:brightness-110",
    ghost: "bg-transparent text-fg hover:bg-elevated",
    soft: "bg-elevated text-fg hover:bg-border/40 border border-border",
    danger: "bg-danger text-accent-fg hover:brightness-110",
    warn: "bg-warn text-bg hover:brightness-110",
  }[variant];
  return (
    <button
      className={cn(
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-sm px-3.5 text-sm font-medium transition-opacity duration-150 disabled:cursor-not-allowed disabled:opacity-40",
        styles,
        className,
      )}
      {...props}
    />
  );
}

export function Panel({
  className,
  children,
}: {
  className?: string;
  children: ReactNode;
}) {
  return (
    <section
      className={cn(
        "rounded-lg border border-border bg-surface shadow-panel",
        className,
      )}
    >
      {children}
    </section>
  );
}

export function Crest({
  club,
  size = 36,
}: {
  club: Pick<ClubState, "short" | "colors">;
  size?: number;
}) {
  return (
    <div
      className="flex shrink-0 items-center justify-center rounded-sm text-[10px] font-semibold tracking-wider"
      style={{
        width: size,
        height: size,
        background: club.colors[0],
        color: club.colors[1],
        boxShadow: `inset 0 0 0 2px ${club.colors[1]}`,
      }}
    >
      {club.short.slice(0, 3)}
    </div>
  );
}

export function Ovr({ n }: { n: number }) {
  const tone =
    n >= 86 ? "bg-ok text-accent-fg" : n >= 76 ? "bg-elevated text-fg" : "bg-bg text-muted";
  return (
    <span
      className={cn(
        "tabular inline-flex h-6 min-w-6 items-center justify-center rounded-xs px-1 text-[11px] font-semibold",
        tone,
      )}
    >
      {n}
    </span>
  );
}

export function StatusIcons({ p }: { p: PlayerData }) {
  return (
    <span className="inline-flex items-center gap-1">
      {p.inj ? (
        <AlertTriangle className="size-3.5 text-danger" aria-label="Sakat" />
      ) : null}
      {p.ban > 0 ? <Ban className="size-3.5 text-card-red" aria-label="Cezalı" /> : null}
      {p.yellows >= 2 ? (
        <span className="size-2.5 rounded-[2px] bg-card-yellow" title="Sarı kartlar" />
      ) : null}
    </span>
  );
}

export function Meter({
  value,
  tone = "accent",
}: {
  value: number;
  tone?: "accent" | "ok" | "warn" | "danger";
}) {
  const map = {
    accent: "bg-accent",
    ok: "bg-ok",
    warn: "bg-warn",
    danger: "bg-danger",
  };
  const t = value >= 70 ? "ok" : value >= 40 ? "warn" : "danger";
  const bar = tone === "accent" ? map[t] : map[tone];
  return (
    <div className="h-1.5 overflow-hidden rounded-full bg-bg">
      <div className={cn("h-full rounded-full", bar)} style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
    </div>
  );
}

export function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="flex flex-col gap-1.5 text-xs text-muted">
      {label}
      {children}
    </label>
  );
}

export const inputClass =
  "min-h-11 rounded-sm border border-border bg-bg px-3 text-sm text-fg outline-none focus:border-accent";
