import { useEffect, useRef, useState, type PointerEvent } from "react";
import { GameOverScreen } from "@/components/game/GameOverScreen";
import { Hud } from "@/components/game/Hud";
import { PauseScreen } from "@/components/game/PauseScreen";
import { TitleScreen } from "@/components/game/TitleScreen";
import { TouchControls } from "@/components/game/TouchControls";
import type { GameEngine } from "@/game/engine";
import { toggleMuted, useGameStore } from "@/game/store";

export function GameApp() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const lookId = useRef<number | null>(null);
  const lastLook = useRef({ x: 0, y: 0 });
  const moved = useRef(0);
  const [bootError, setBootError] = useState<string | null>(null);

  const phase = useGameStore((s) => s.phase);
  const ready = useGameStore((s) => s.ready);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let cancelled = false;
    let engine: GameEngine | null = null;

    import("@/game/engine")
      .then(({ GameEngine }) => {
        if (cancelled || !canvasRef.current) return;
        engine = new GameEngine(canvasRef.current);
        engineRef.current = engine;
      })
      .catch((err: unknown) => {
        const message = err instanceof Error ? err.message : "The town failed to load.";
        setBootError(message);
      });

    return () => {
      cancelled = true;
      engine?.dispose();
      engineRef.current = null;
    };
  }, []);

  const start = () => engineRef.current?.start();
  const pause = () => engineRef.current?.pause();
  const resume = () => engineRef.current?.resume();
  const quit = () => engineRef.current?.quitToTitle();
  const mute = () => {
    toggleMuted();
    engineRef.current?.setMuted(useGameStore.getState().muted);
  };

  const onLookDown = (e: PointerEvent<HTMLDivElement>) => {
    if (phase !== "playing") return;
    if (e.pointerType === "mouse" && e.button !== 0) return;
    lookId.current = e.pointerId;
    lastLook.current = { x: e.clientX, y: e.clientY };
    moved.current = 0;
    e.currentTarget.setPointerCapture(e.pointerId);
    engineRef.current?.tryPointerLock();
  };

  const onLookMove = (e: PointerEvent<HTMLDivElement>) => {
    if (lookId.current !== e.pointerId) return;
    if (document.pointerLockElement) return;
    const dx = (e.clientX - lastLook.current.x) * 1.65;
    const dy = (e.clientY - lastLook.current.y) * 1.65;
    lastLook.current = { x: e.clientX, y: e.clientY };
    moved.current += Math.hypot(dx, dy);
    engineRef.current?.addLook(dx, dy);
  };

  const onLookUp = (e: PointerEvent<HTMLDivElement>) => {
    if (lookId.current !== e.pointerId) return;
    lookId.current = null;
    if (document.pointerLockElement) return;
    if (moved.current < 14 && e.pointerType !== "touch") {
      engineRef.current?.setFireHeld(true);
      window.setTimeout(() => engineRef.current?.setFireHeld(false), 50);
    }
  };

  return (
    <main className="relative h-dvh w-full overflow-hidden bg-bg text-fg">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 size-full touch-none"
        onContextMenu={(e) => e.preventDefault()}
      />

      {phase === "playing" ? (
        <div
          className="absolute inset-0 z-[5] touch-none"
          onPointerDown={onLookDown}
          onPointerMove={onLookMove}
          onPointerUp={onLookUp}
          onPointerCancel={() => {
            lookId.current = null;
          }}
        />
      ) : null}

      {phase === "playing" || phase === "paused" ? <Hud onPause={pause} /> : null}
      {phase === "playing" ? (
        <TouchControls
          onMove={(x, y) => engineRef.current?.setTouchMove(x, y)}
          onFire={(held) => engineRef.current?.setFireHeld(held)}
          onReload={() => engineRef.current?.queueReload()}
        />
      ) : null}

      {phase === "title" ? (
        <TitleScreen ready={ready && !bootError} onStart={start} onMute={mute} />
      ) : null}
      {phase === "paused" ? (
        <PauseScreen onResume={resume} onQuit={quit} onMute={mute} />
      ) : null}
      {phase === "dead" ? <GameOverScreen onAgain={start} onQuit={quit} /> : null}

      {bootError ? (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-bg p-6 text-center">
          <p className="max-w-sm text-sm text-muted">{bootError}</p>
        </div>
      ) : null}
    </main>
  );
}
