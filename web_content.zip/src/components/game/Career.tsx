import { ClubLogo } from "@/components/game/ClubLogo";
import { PlayerCard } from "@/components/game/PlayerCard";
import { Footballgram } from "@/components/game/Social";
import { Btn, Modal, Panel, StatBar } from "@/components/game/ui";
import { ACHIEVEMENTS, ATTR_TR, ATTRIBUTE_GROUPS, CARS, HOMES, INTENSITY, POS_TR, TRAINING_FOCI } from "@/lib/game/constants";
import { LEAGUES, TEAM_BY_ID, teamsInLeague } from "@/lib/game/data/teams";
import { displayName } from "@/lib/game/data/squads";
import * as Life from "@/lib/game/engine/life";
import { currentFixture } from "@/lib/game/engine/week";
import { ageFromDob, attrColor, fmtFee, fmtMoney, ratingColor, trDate } from "@/lib/game/format";
import { Sound } from "@/lib/game/sound";
import { useGame } from "@/lib/game/store";
import type { CareerState, CareerView } from "@/lib/game/types";
import {
  Banknote,
  Briefcase,
  CalendarDays,
  ChevronRight,
  Dumbbell,
  Flag,
  Heart,
  History,
  Home,
  Landmark,
  Menu,
  Newspaper,
  Save,
  Settings2,
  Shirt,
  Trophy,
  User,
  Users,
  X,
} from "lucide-react";
import { useMemo, useState } from "react";

const NAV: { cat: string; items: { id: CareerView; label: string; icon: typeof User }[] }[] = [
  {
    cat: "Oyuncu",
    items: [
      { id: "panel", label: "Panel", icon: Home },
      { id: "profile", label: "Oyuncu profili", icon: User },
      { id: "attributes", label: "Ozellikler", icon: Shirt },
      { id: "stats", label: "Istatistikler", icon: Newspaper },
    ],
  },
  {
    cat: "Saha",
    items: [
      { id: "training", label: "Antrenman", icon: Dumbbell },
      { id: "matches", label: "Maclar", icon: Flag },
      { id: "calendar", label: "Takvim", icon: CalendarDays },
      { id: "club", label: "Kulup", icon: Landmark },
      { id: "manager", label: "Menajer", icon: Briefcase },
      { id: "teammates", label: "Takim arkadaslari", icon: Users },
    ],
  },
  {
    cat: "Kariyer",
    items: [
      { id: "transfers", label: "Transferler", icon: Newspaper },
      { id: "agent", label: "Menajer ajani", icon: Briefcase },
      { id: "contract", label: "Sozlesme", icon: Shirt },
      { id: "finance", label: "Finans", icon: Banknote },
      { id: "national", label: "Milli takim", icon: Flag },
      { id: "trophies", label: "Kupalar", icon: Trophy },
      { id: "history", label: "Kariyer gecmisi", icon: History },
    ],
  },
  {
    cat: "Yasam",
    items: [
      { id: "life", label: "Yasam", icon: Heart },
      { id: "social", label: "Sosyal medya", icon: Newspaper },
    ],
  },
];

export function Career() {
  const { career, view, drawer, setDrawer, setView, setScreen, save, savedFlash, quit, weekAdvance } = useGame();
  const [quitOpen, setQuitOpen] = useState(false);
  if (!career) return null;
  if (view === "social") return <Footballgram onBack={() => setView("panel")} />;

  const club = TEAM_BY_ID[career.clubId];
  const title = NAV.flatMap((n) => n.items).find((i) => i.id === view)?.label || "Panel";

  return (
    <div className="min-h-dvh bg-bg">
      <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-line bg-bg/95 px-3 py-2.5 backdrop-blur">
        <button
          type="button"
          aria-label="Menu"
          className="grid size-11 place-items-center rounded-[12px] bg-bg-soft"
          onClick={() => {
            Sound.tap();
            setDrawer(true);
          }}
        >
          <Menu size={18} />
        </button>
        <div className="min-w-0 flex-1">
          <div className="font-display text-xl leading-none">{title}</div>
          <div className="truncate text-[12px] text-muted">
            {club?.name} · Hafta {career.week} · {trDate(career.date)}
          </div>
        </div>
        {club && <ClubLogo team={club} size={28} />}
      </header>

      {drawer && (
        <div className="fixed inset-0 z-40 flex">
          <aside className="flex h-full w-[86%] max-w-sm flex-col bg-bg-elev slide-in">
            <div className="flex items-center justify-between px-4 py-4">
              <div className="font-display text-2xl">Futbol Kariyeri</div>
              <button type="button" className="grid size-10 place-items-center" onClick={() => setDrawer(false)}>
                <X size={18} />
              </button>
            </div>
            <div className="min-h-0 flex-1 overflow-y-auto px-2 pb-4">
              {NAV.map((g) => (
                <div key={g.cat} className="mb-3">
                  <div className="px-3 pb-1 text-[11px] uppercase tracking-[0.18em] text-subtle">{g.cat}</div>
                  {g.items.map((it) => (
                    <button
                      key={it.id}
                      type="button"
                      onClick={() => {
                        Sound.tap();
                        setView(it.id);
                      }}
                      className={
                        "flex w-full items-center gap-3 rounded-[12px] px-3 py-2.5 text-left " +
                        (view === it.id ? "bg-bg-hover" : "")
                      }
                    >
                      <it.icon size={16} className="text-muted" />
                      <span>{it.label}</span>
                    </button>
                  ))}
                </div>
              ))}
            </div>
            <div className="grid grid-cols-3 gap-2 border-t border-line p-3">
              <Btn
                className="px-2 text-[13px]"
                onClick={() => {
                  Sound.success();
                  save();
                }}
              >
                <Save size={14} /> {savedFlash ? "Kaydedildi" : "Kaydet"}
              </Btn>
              <Btn
                className="px-2 text-[13px]"
                onClick={() => {
                  Sound.tap();
                  setDrawer(false);
                  setScreen("settings");
                }}
              >
                <Settings2 size={14} /> Ayarlar
              </Btn>
              <Btn
                tone="danger"
                className="px-2 text-[13px]"
                onClick={() => {
                  Sound.tap();
                  setQuitOpen(true);
                }}
              >
                Cik
              </Btn>
            </div>
          </aside>
          <button type="button" className="flex-1 bg-black/50" aria-label="Kapat" onClick={() => setDrawer(false)} />
        </div>
      )}

      <div className="mx-auto max-w-lg px-4 py-4">
        {view === "panel" && <Dash career={career} onAdvance={weekAdvance} />}
        {view === "profile" && <Profile career={career} />}
        {view === "attributes" && <Attrs career={career} />}
        {view === "stats" && <Stats career={career} />}
        {view === "training" && <Training career={career} />}
        {view === "matches" && <Matches career={career} />}
        {view === "calendar" && <Calendar career={career} />}
        {view === "club" && <Club career={career} />}
        {view === "manager" && <ManagerV career={career} />}
        {view === "teammates" && <Teammates career={career} />}
        {view === "transfers" && <Transfers career={career} />}
        {view === "agent" && <AgentV career={career} />}
        {view === "contract" && <ContractV career={career} />}
        {view === "finance" && <FinanceV career={career} />}
        {view === "national" && <National career={career} />}
        {view === "trophies" && <Trophies career={career} />}
        {view === "history" && <HistoryV career={career} />}
        {view === "life" && <LifeV career={career} />}
      </div>

      <Modal open={quitOpen} title="Kariyerden cik" onClose={() => setQuitOpen(false)}>
        <p className="text-[15px] text-muted">Kayit guncellenecek ve ana menuye doneceksin.</p>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <Btn onClick={() => setQuitOpen(false)}>Vazgec</Btn>
          <Btn
            tone="danger"
            onClick={() => {
              Sound.click();
              quit();
            }}
          >
            Cik
          </Btn>
        </div>
      </Modal>
    </div>
  );
}

function Dash({ career, onAdvance }: { career: CareerState; onAdvance: (auto: boolean) => void }) {
  const club = TEAM_BY_ID[career.clubId]!;
  const league = LEAGUES.find((l) => l.id === career.leagueId);
  const fx = currentFixture(career);
  const table = [...career.table].sort((a, b) => b.pts - a.pts || b.gf - a.gf);
  const pos = table.findIndex((r) => r.teamId === career.clubId) + 1;
  const opp = fx ? TEAM_BY_ID[fx.home === career.clubId ? fx.away : fx.home] : null;
  const home = fx?.home === career.clubId;
  const roleLabel = career.role === "starter" ? "Ilk 11" : career.role === "rotation" ? "Rotasyon" : "Yedek";
  const news = career.news.slice(0, 5);
  const transfers = career.worldTransfers.slice(0, 3);

  return (
    <div className="grid gap-4 fade-up">
      <PlayerCard player={career.player} date={career.date} />
      {career.injury && (
        <div className="rounded-[16px] bg-danger/15 px-4 py-3 text-[14px] text-danger">
          Sakatlik: {career.injury.name} · {career.injury.weeksLeft} hafta
        </div>
      )}
      {club && (
        <Panel className="flex items-center gap-3">
          <ClubLogo team={club} size={42} />
          <div className="min-w-0 flex-1">
            <div className="font-display text-2xl leading-none">{club.name}</div>
            <div className="text-[13px] text-muted">
              {league?.name} · {pos}. sira
            </div>
          </div>
        </Panel>
      )}
      <div className="grid grid-cols-2 gap-2">
        <MiniStat label="Form" v={career.player.form} />
        <MiniStat label="Moral" v={career.player.morale} />
        <MiniStat label="Performans" v={career.seasonStats.avgRating * 10} sub={career.seasonStats.avgRating.toFixed(1)} />
        <MiniStat label="Yorgunluk" v={career.player.fatigue} />
      </div>
      <Panel>
        <div className="text-[12px] uppercase tracking-[0.16em] text-muted">Siradaki mac</div>
        {fx && opp ? (
          <>
            <div className="mt-2 flex items-center justify-between">
              <div className="font-display text-2xl">{home ? "Ic saha" : "Dis saha"}</div>
              <ClubLogo team={opp} size={36} />
            </div>
            <div className="text-[15px] text-muted">{opp.name}</div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <Btn
                tone="primary"
                onClick={() => {
                  Sound.whistle();
                  onAdvance(false);
                }}
              >
                Maci oyna
              </Btn>
              <Btn
                onClick={() => {
                  Sound.click();
                  onAdvance(true);
                }}
              >
                Haftayi ilerlet
              </Btn>
            </div>
          </>
        ) : (
          <div className="mt-2">
            <p className="text-muted">Bu hafta lig maci yok.</p>
            <Btn className="mt-3 w-full" onClick={() => onAdvance(true)}>
              Haftayi ilerlet
            </Btn>
          </div>
        )}
      </Panel>
      <Panel>
        <div className="text-[12px] uppercase tracking-[0.16em] text-muted">Menajer</div>
        <div className="mt-1 font-display text-2xl">
          {career.manager.first} {career.manager.last}
        </div>
        <div className="text-[13px] text-muted">{roleLabel} · {career.manager.style}</div>
        <div className="mt-3">
          <StatBar label="Guven" value={career.manager.trust} />
        </div>
      </Panel>
      <div className="grid grid-cols-2 gap-2">
        <Panel>
          <div className="text-[12px] text-muted">Bakiye</div>
          <div className="font-display text-2xl tabular-nums">{fmtMoney(career.finances.balance)}</div>
        </Panel>
        <Panel>
          <div className="text-[12px] text-muted">Takipci</div>
          <div className="font-display text-2xl tabular-nums">{career.social.followers.toLocaleString("tr-TR")}</div>
        </Panel>
      </div>
      <Panel>
        <div className="mb-2 text-[12px] uppercase tracking-[0.16em] text-muted">Dunya transferleri</div>
        <div className="grid gap-2">
          {transfers.map((t) => (
            <div key={t.id} className="flex items-center justify-between gap-2 text-[13px]">
              <span className="truncate">{t.name}</span>
              <span className="tabular-nums text-ok">{fmtFee(t.fee)}</span>
            </div>
          ))}
          {!transfers.length && <div className="text-muted">Henuz yok.</div>}
        </div>
      </Panel>
      <Panel>
        <div className="mb-2 text-[12px] uppercase tracking-[0.16em] text-muted">Haberler</div>
        <div className="grid gap-3">
          {news.map((n) => (
            <div key={n.id}>
              <div className="font-medium">{n.title}</div>
              <div className="text-[13px] text-muted">{n.body}</div>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}

function MiniStat({ label, v, sub }: { label: string; v: number; sub?: string }) {
  return (
    <div className="rounded-[18px] bg-bg-elev p-3 hairline">
      <div className="text-[12px] text-muted">{label}</div>
      <div className="font-display text-2xl tabular-nums">{sub ?? Math.round(v)}</div>
      <div className="mt-2 h-1 overflow-hidden rounded-full bg-bg-hover">
        <div className="h-full bg-pitch" style={{ width: Math.max(4, Math.min(100, v)) + "%" }} />
      </div>
    </div>
  );
}

function Profile({ career }: { career: CareerState }) {
  const p = career.player;
  return (
    <div className="grid gap-4">
      <PlayerCard player={p} date={career.date} />
      <Panel className="grid grid-cols-2 gap-3 text-[14px]">
        <Row k="Ad" v={p.firstName + " " + p.lastName} />
        <Row k="Mevki" v={POS_TR[p.pos]} />
        <Row k="Yas" v={String(ageFromDob(p.dob, career.date))} />
        <Row k="Uyruk" v={p.nat + (p.nat2 ? " / " + p.nat2 : "")} />
        <Row k="Boy / kilo" v={p.height + " cm · " + p.weight + " kg"} />
        <Row k="Ayak" v={p.foot === "left" ? "Sol" : "Sag"} />
        <Row k="Forma" v={"#" + p.number} />
        <Row k="Potansiyel" v={String(p.potential)} />
      </Panel>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div>
      <div className="text-[12px] text-muted">{k}</div>
      <div>{v}</div>
    </div>
  );
}

function Attrs({ career }: { career: CareerState }) {
  return (
    <div className="grid gap-4">
      {ATTRIBUTE_GROUPS.map((g) => (
        <Panel key={g.id}>
          <div className="mb-3 font-display text-xl">{g.tr}</div>
          <div className="grid gap-2">
            {g.keys.map((k) => {
              const v = career.player.attrs[k.key] ?? 55;
              return (
                <div key={k.key} className="flex items-center gap-3">
                  <div className="w-36 truncate text-[13px] text-muted">{ATTR_TR[k.key]}</div>
                  <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-bg-hover">
                    <div className="h-full" style={{ width: v + "%", background: attrColor(v) }} />
                  </div>
                  <div className="w-8 text-right font-display tabular-nums" style={{ color: attrColor(v) }}>
                    {v}
                  </div>
                </div>
              );
            })}
          </div>
        </Panel>
      ))}
    </div>
  );
}

function Stats({ career }: { career: CareerState }) {
  const s = career.seasonStats;
  const items = [
    ["Mac", s.apps],
    ["Gol", s.goals],
    ["Asist", s.assists],
    ["Ort. reyting", s.avgRating.toFixed(1)],
    ["Sari", s.yellowCards],
    ["Kirmizi", s.redCards],
    ["MOTM", s.motm],
    ["Dakika", s.minutes],
  ] as const;
  return (
    <div className="grid grid-cols-2 gap-2">
      {items.map(([k, v]) => (
        <Panel key={k}>
          <div className="text-[12px] text-muted">{k}</div>
          <div className="font-display text-3xl tabular-nums">{v}</div>
        </Panel>
      ))}
    </div>
  );
}

function Training({ career }: { career: CareerState }) {
  const { setTraining } = useGame();
  return (
    <div className="grid gap-4">
      <Panel>
        <div className="font-display text-xl">Odak</div>
        <div className="mt-3 grid gap-2">
          {TRAINING_FOCI.map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => {
                Sound.tap();
                setTraining(f.id, career.training.intensity);
              }}
              className={
                "rounded-[14px] px-3 py-3 text-left hairline " +
                (career.training.focus === f.id ? "bg-accent text-accent-fg" : "bg-bg-soft")
              }
            >
              <div className="font-medium">{f.tr}</div>
              <div className="text-[12px] opacity-70">{f.attrs.length ? f.attrs.map((a) => ATTR_TR[a]).join(", ") : "Yorgunluk duser"}</div>
            </button>
          ))}
        </div>
      </Panel>
      <Panel>
        <div className="font-display text-xl">Yogunluk</div>
        <div className="mt-3 grid grid-cols-3 gap-2">
          {(["low", "mid", "high"] as const).map((k) => (
            <Btn
              key={k}
              tone={career.training.intensity === k ? "primary" : "ghost"}
              onClick={() => setTraining(career.training.focus, k)}
            >
              {INTENSITY[k].tr}
            </Btn>
          ))}
        </div>
      </Panel>
    </div>
  );
}

function Matches({ career }: { career: CareerState }) {
  return (
    <div className="grid gap-2">
      {career.matchLog.length === 0 && <Panel>Henuz mac yok.</Panel>}
      {career.matchLog.map((m, i) => {
        const home = TEAM_BY_ID[m.home];
        const away = TEAM_BY_ID[m.away];
        return (
          <Panel key={i} className="flex items-center gap-3">
            {home && <ClubLogo team={home} size={28} />}
            <div className="flex-1 text-center">
              <div className="font-display text-2xl tabular-nums">
                {m.hg} - {m.ag}
              </div>
              <div className="text-[12px] text-muted">
                {m.minutes} dk · {m.goals}G {m.assists}A
              </div>
            </div>
            {away && <ClubLogo team={away} size={28} />}
            <div className="w-10 text-right font-display text-xl tabular-nums" style={{ color: ratingColor(m.rating) }}>
              {m.rating.toFixed(1)}
            </div>
          </Panel>
        );
      })}
    </div>
  );
}

function Calendar({ career }: { career: CareerState }) {
  const upcoming = career.fixtures.filter((f) => f.week >= career.week && (f.home === career.clubId || f.away === career.clubId)).slice(0, 8);
  return (
    <div className="grid gap-2">
      {upcoming.map((f) => {
        const opp = TEAM_BY_ID[f.home === career.clubId ? f.away : f.home];
        return (
          <Panel key={f.week + f.home} className="flex items-center gap-3">
            <div className="w-16 text-[12px] text-muted">Hafta {f.week}</div>
            {opp && <ClubLogo team={opp} size={28} />}
            <div className="flex-1">
              {f.home === career.clubId ? "vs" : "@"} {opp?.name}
            </div>
          </Panel>
        );
      })}
    </div>
  );
}

function Club({ career }: { career: CareerState }) {
  const club = TEAM_BY_ID[career.clubId];
  const table = [...career.table].sort((a, b) => b.pts - a.pts || b.gf - a.gf);
  return (
    <div className="grid gap-4">
      {club && (
        <Panel className="flex items-center gap-3">
          <ClubLogo team={club} size={56} />
          <div>
            <div className="font-display text-3xl">{club.name}</div>
            <div className="text-muted">{club.country}</div>
          </div>
        </Panel>
      )}
      <Panel>
        <div className="mb-2 font-display text-xl">Puan durumu</div>
        <div className="grid gap-1">
          {table.map((r, i) => {
            const t = TEAM_BY_ID[r.teamId];
            const me = r.teamId === career.clubId;
            return (
              <div key={r.teamId} className={"flex items-center gap-2 rounded-[10px] px-2 py-1.5 text-[13px] " + (me ? "bg-bg-hover" : "")}>
                <div className="w-5 tabular-nums text-muted">{i + 1}</div>
                {t && <ClubLogo team={t} size={18} />}
                <div className="min-w-0 flex-1 truncate">{t?.name}</div>
                <div className="w-8 text-right tabular-nums">{r.played}</div>
                <div className="w-8 text-right font-medium tabular-nums">{r.pts}</div>
              </div>
            );
          })}
        </div>
      </Panel>
    </div>
  );
}

function ManagerV({ career }: { career: CareerState }) {
  return (
    <Panel>
      <div className="font-display text-3xl">
        {career.manager.first} {career.manager.last}
      </div>
      <div className="text-muted">{career.manager.style}</div>
      <div className="mt-4">
        <StatBar label="Guven" value={career.manager.trust} />
      </div>
      <p className="mt-3 text-[14px] text-muted">
        Rolun: {career.role === "starter" ? "Ilk 11" : career.role === "rotation" ? "Rotasyon" : "Yedek"}
      </p>
    </Panel>
  );
}

function Teammates({ career }: { career: CareerState }) {
  return (
    <div className="grid gap-2">
      {career.teammates.map((p) => (
        <Panel key={p.id} className="flex items-center gap-3 py-3">
          <div className="w-10 font-display text-lg text-muted">{p.pos}</div>
          <div className="flex-1">
            <div>{displayName(p)}</div>
            <div className="text-[12px] text-muted">
              {p.nat} · {p.age} yas
            </div>
          </div>
          <div className="font-display text-2xl tabular-nums">{p.ovr}</div>
        </Panel>
      ))}
    </div>
  );
}

function Transfers({ career }: { career: CareerState }) {
  const { takeOffer } = useGame();
  const confirmed = career.worldTransfers.filter((t) => !t.rumor).slice(0, 30);
  const rumors = career.worldTransfers.filter((t) => t.rumor).slice(0, 20);
  return (
    <div className="grid gap-4">
      <Panel>
        <div className="mb-2 font-display text-xl">Sana ilgi</div>
        {career.transferInterest.length === 0 && <div className="text-muted">Suan izleyen kulup yok.</div>}
        {career.transferInterest.map((i) => {
          const t = TEAM_BY_ID[i.teamId];
          const lg = LEAGUES.find((l) => l.id === t?.leagueId);
          return (
            <div key={i.teamId + i.week} className="flex items-center gap-3 py-2">
              {t && <ClubLogo team={t} size={28} />}
              <div>
                <div>{t?.name}</div>
                <div className="text-[12px] text-muted">{lg?.name}</div>
              </div>
            </div>
          );
        })}
      </Panel>
      {career.offers.filter((o) => o.status === "open").map((o) => {
        const t = TEAM_BY_ID[o.teamId];
        return (
          <Panel key={o.id}>
            <div className="text-[12px] uppercase tracking-[0.14em] text-muted">{o.kind === "loan" ? "Kiralik" : "Transfer"}</div>
            <div className="mt-1 flex items-center gap-3">
              {t && <ClubLogo team={t} size={36} />}
              <div>
                <div className="font-display text-2xl">{t?.name}</div>
                <div className="text-[13px] text-muted">
                  {fmtFee(o.fee)} · {fmtMoney(o.wage)}/hafta
                </div>
              </div>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <Btn tone="primary" onClick={() => takeOffer(o.id, true)}>
                Kabul et
              </Btn>
              <Btn onClick={() => takeOffer(o.id, false)}>Reddet</Btn>
            </div>
          </Panel>
        );
      })}
      <Panel>
        <div className="mb-2 font-display text-xl">Onaylanan transferler</div>
        {confirmed.map((t) => (
          <div key={t.id} className="border-t border-line py-2 first:border-0">
            <div className="flex items-center justify-between gap-2">
              <span className="font-medium">{t.name}</span>
              <span className="tabular-nums text-ok">{fmtFee(t.fee)}</span>
            </div>
            <div className="text-[12px] text-muted">
              {TEAM_BY_ID[t.fromId]?.name} → {TEAM_BY_ID[t.toId]?.name} · {t.pos} {t.ovr}
              {t.record ? " · REKOR" : ""}
            </div>
          </div>
        ))}
      </Panel>
      <Panel>
        <div className="mb-2 font-display text-xl text-warn">Soylentiler</div>
        {rumors.map((t) => (
          <div key={t.id} className="py-1 text-[13px] text-muted">
            {t.name}: {TEAM_BY_ID[t.fromId]?.name} → {TEAM_BY_ID[t.toId]?.name}
          </div>
        ))}
      </Panel>
    </div>
  );
}

function AgentV({ career }: { career: CareerState }) {
  return (
    <Panel>
      <div className="font-display text-3xl">
        {career.agent.first} {career.agent.last}
      </div>
      <p className="mt-2 text-muted">Kesinti %{career.agent.cut}. Teklifler transferler sekmesinde.</p>
    </Panel>
  );
}

function ContractV({ career }: { career: CareerState }) {
  const c = career.contract;
  return (
    <Panel className="grid gap-3">
      <Row k="Sure" v={c.years + " yil"} />
      <Row k="Haftalik maas" v={fmtMoney(c.weeklyWage)} />
      <Row k="Mac primi" v={fmtMoney(c.appearanceBonus)} />
      <Row k="Gol primi" v={fmtMoney(c.goalBonus)} />
      <Row k="Asist primi" v={fmtMoney(c.assistBonus)} />
    </Panel>
  );
}

function FinanceV({ career }: { career: CareerState }) {
  return (
    <div className="grid gap-2">
      <Panel>
        <div className="text-muted">Bakiye</div>
        <div className="font-display text-4xl tabular-nums">{fmtMoney(career.finances.balance)}</div>
      </Panel>
      <Panel>
        <Row k="Haftalik maas" v={fmtMoney(career.finances.weeklyWage)} />
        <div className="mt-2">
          <Row k="Aylik gelir" v={fmtMoney(career.finances.monthlyIncome)} />
        </div>
        <div className="mt-2">
          <Row k="Aylik gider" v={fmtMoney(career.finances.monthlyExpenses)} />
        </div>
      </Panel>
    </div>
  );
}

function National({ career }: { career: CareerState }) {
  const called = career.player.overall >= 74 && career.player.form >= 58;
  return (
    <Panel>
      <div className="font-display text-2xl">{career.player.nat} milli takim</div>
      <p className="mt-2 text-muted">
        {called
          ? "Formun yeterli. Kamp kadrosuna aday gosterildin."
          : "Henuz kadroya cagrilmadi. Form ve reytingi yukselt."}
      </p>
    </Panel>
  );
}

function Trophies({ career }: { career: CareerState }) {
  return (
    <div className="grid gap-2">
      {career.trophies.length === 0 && <Panel>Dolap bos. Sabir.</Panel>}
      {career.trophies.map((t) => (
        <Panel key={t.id} className="flex items-center gap-3">
          <Trophy size={18} />
          <div>
            <div>{t.name}</div>
            <div className="text-[12px] text-muted">
              {t.season} · {t.team}
            </div>
          </div>
        </Panel>
      ))}
      <Panel>
        <div className="mb-2 font-display text-xl">Basarimlar</div>
        {ACHIEVEMENTS.map((a) => (
          <div key={a.id} className="flex items-center justify-between py-1.5 text-[14px]">
            <span>{a.tr}</span>
            <span className={career.achievements.includes(a.id) ? "text-ok" : "text-subtle"}>
              {career.achievements.includes(a.id) ? "Acildi" : "Kilitli"}
            </span>
          </div>
        ))}
      </Panel>
    </div>
  );
}

function HistoryV({ career }: { career: CareerState }) {
  return (
    <div className="grid gap-2">
      {career.careerHistory.map((h, i) => (
        <Panel key={i}>
          <div className="text-[12px] text-muted">
            {h.season} · Hafta {h.week}
          </div>
          <div>{h.text}</div>
        </Panel>
      ))}
    </div>
  );
}

function LifeV({ career }: { career: CareerState }) {
  const { setCareer, flash } = useGame();
  const apply = (r: CareerState | string) => {
    if (typeof r === "string") {
      Sound.fail();
      flash(r, "bad");
      return;
    }
    Sound.success();
    setCareer(r);
  };
  return (
    <div className="grid gap-4">
      <div className="grid grid-cols-2 gap-2">
        <MiniStat label="Mutluluk" v={career.player.happiness} />
        <MiniStat label="Enerji" v={career.player.energy} />
        <MiniStat label="Stres" v={career.player.stress} />
        <MiniStat label="Yas" v={ageFromDob(career.player.dob, career.date)} sub={String(ageFromDob(career.player.dob, career.date))} />
      </div>
      <Panel>
        <div className="font-display text-xl">Ev</div>
        <div className="mt-2 grid gap-2">
          {HOMES.map((h) => (
            <button
              key={h.id}
              type="button"
              disabled={career.life.home >= h.id}
              onClick={() => apply(Life.buyHome(career, h.id))}
              className="flex items-center justify-between rounded-[12px] bg-bg-soft px-3 py-2 text-left hairline disabled:opacity-50"
            >
              <span>{h.tr}</span>
              <span className="text-[13px] text-muted">{h.cost ? fmtMoney(h.cost) : "Baslangic"}</span>
            </button>
          ))}
        </div>
      </Panel>
      <Panel>
        <div className="font-display text-xl">Araba</div>
        <div className="mt-2 grid gap-2">
          {CARS.map((h) => (
            <button
              key={h.id}
              type="button"
              disabled={career.life.car >= h.id}
              onClick={() => apply(Life.buyCar(career, h.id))}
              className="flex items-center justify-between rounded-[12px] bg-bg-soft px-3 py-2 text-left hairline disabled:opacity-50"
            >
              <span>{h.tr}</span>
              <span className="text-[13px] text-muted">{h.cost ? fmtMoney(h.cost) : "-"}</span>
            </button>
          ))}
        </div>
      </Panel>
      <Panel>
        <div className="font-display text-xl">Iliski</div>
        <p className="mt-1 text-muted">
          {career.life.relationship === "single"
            ? "Yalniz"
            : career.life.partnerName + " · " + career.life.relationship + " · " + career.life.togetherWeeks + " hafta"}
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          {career.life.relationship === "single" && <Btn onClick={() => apply(Life.startDating(career))}>Birini tanis</Btn>}
          {career.life.relationship === "dating" && <Btn onClick={() => apply(Life.propose(career))}>Evlenme teklifi et</Btn>}
          {career.life.relationship === "engaged" && <Btn onClick={() => apply(Life.marry(career))}>Evlen</Btn>}
          {career.life.relationship === "married" && <Btn onClick={() => apply(Life.haveChild(career))}>Cocuk sahibi ol</Btn>}
          {career.life.relationship !== "single" && (
            <Btn tone="danger" onClick={() => apply(Life.breakUp(career))}>
              Ayril
            </Btn>
          )}
        </div>
      </Panel>
      <Panel>
        <div className="font-display text-xl">Aktivite</div>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <Btn onClick={() => apply(Life.rest(career))}>Dinlen</Btn>
          <Btn onClick={() => apply(Life.familyVisit(career))}>Aile ziyareti</Btn>
          <Btn onClick={() => apply(Life.friendsOut(career))}>Arkadaslar</Btn>
          <Btn onClick={() => apply(Life.gym(career))}>Spor salonu</Btn>
          <Btn onClick={() => apply(Life.party(career))}>Parti · £20B</Btn>
          <Btn onClick={() => apply(Life.vacation(career))}>Tatil · £50B</Btn>
          <Btn onClick={() => apply(Life.donate(career))}>Bagis · £10B</Btn>
          <Btn onClick={() => apply(Life.invest(career))}>Yatirim · £200B</Btn>
        </div>
      </Panel>
      <Panel>
        <div className="mb-2 font-display text-xl">Olaylar</div>
        {career.life.events.map((e, i) => (
          <div key={i} className="border-t border-line py-2 text-[14px] first:border-0">
            <span className="text-muted">H{e.week} · </span>
            {e.text}
          </div>
        ))}
      </Panel>
    </div>
  );
}

export function useLeagueName() {
  return useMemo(() => LEAGUES, []);
}

void ChevronRight;
void teamsInLeague;
