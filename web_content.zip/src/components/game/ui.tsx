import { cn } from "@/lib/utils";
import type { ButtonHTMLAttributes, ReactNode } from "react";

export function Btn({
  tone = "ghost",
  className,
  children,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { tone?: "primary" | "ghost" | "danger" | "soft" }) {
  return (
    <button
      type="button"
      className={cn(
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-[12px] px-4 text-[15px] font-medium transition-colors duration-150 ease-out active:scale-[0.98]",
        tone === "primary" && "bg-accent text-accent-fg hover:bg-fg",
        tone === "ghost" && "bg-bg-soft text-fg hover:bg-bg-hover hairline",
        tone === "soft" && "bg-pitch-dim text-fg hover:bg-bg-hover",
        tone === "danger" && "bg-danger/15 text-danger hover:bg-danger/25",
        className,
      )}
      {...rest}
    >
      {children}
    </button>
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[12px] font-medium uppercase tracking-[0.14em] text-muted">{label}</span>
      {children}
    </label>
  );
}

export function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={cn(
        "h-11 w-full rounded-[12px] border border-line bg-bg-elev px-3 text-[15px] text-fg outline-none placeholder:text-subtle focus:border-line-strong",
        props.className,
      )}
    />
  );
}

export function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className={cn(
        "h-11 w-full rounded-[12px] border border-line bg-bg-elev px-3 text-[15px] text-fg outline-none focus:border-line-strong",
        props.className,
      )}
    />
  );
}

export function StatBar({ label, value, max = 100, tone }: { label: string; value: number; max?: number; tone?: string }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div>
      <div className="mb-1 flex items-baseline justify-between text-[12px]">
        <span className="text-muted">{label}</span>
        <span className="tabular-nums text-fg">{Math.round(value)}</span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-bg-hover">
        <div className="h-full rounded-full" style={{ width: pct + "%", background: tone || "var(--color-pitch)" }} />
      </div>
    </div>
  );
}

export function Panel({ children, className }: { children: ReactNode; className?: string }) {
  return <section className={cn("rounded-[28px] bg-bg-elev p-4 hairline sm:p-5", className)}>{children}</section>;
}

export function Modal({
  open,
  title,
  children,
  onClose,
}: {
  open: boolean;
  title: string;
  children: ReactNode;
  onClose: () => void;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-3 sm:items-center" onClick={onClose}>
      <div
        className="w-full max-w-md rounded-[28px] bg-bg-elev p-5 hairline fade-up"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 font-display text-2xl">{title}</div>
        {children}
      </div>
    </div>
  );
}
