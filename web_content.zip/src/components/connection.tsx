"use client";

import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { isOnline, pendingCount, probeServer, syncAll } from "@/lib/match-repo";

/**
 * Connection / synchronisation engine.
 *
 * This module drives offline-first behaviour: it detects connectivity, probes
 * whether cloud sync is usable, and uploads pending matches automatically.
 *
 * It renders NOTHING. Sync state is kept internally (and via `useConnection()`
 * for diagnostics) but is deliberately never surfaced as status text in the
 * scorer UI — no LOCAL MODE, OFFLINE or "pending sync" badges anywhere.
 */

export type ConnMode = "ONLINE" | "OFFLINE" | "LOCAL" | "SYNCING" | "SYNCED";

type Ctx = {
  mode: ConnMode;
  online: boolean;
  pending: number;
  syncNow: () => Promise<void>;
};

const ConnCtx = createContext<Ctx>({
  mode: "LOCAL",
  online: true,
  pending: 0,
  syncNow: async () => {},
});

export function useConnection() {
  return useContext(ConnCtx);
}

export function ConnectionProvider({ children }: { children: ReactNode }) {
  const [online, setOnline] = useState(true);
  const [cloudOk, setCloudOk] = useState(false);
  const [pending, setPending] = useState(0);
  const [syncing, setSyncing] = useState(false);

  const refreshPending = useCallback(async () => {
    setPending(await pendingCount());
  }, []);

  const syncNow = useCallback(async () => {
    if (!isOnline()) return;
    const n = await pendingCount();
    if (n === 0) {
      setPending(0);
      return;
    }
    setSyncing(true);
    const { pending: left } = await syncAll();
    setPending(left);
    setSyncing(false);
  }, []);

  const probe = useCallback(async () => {
    const net = isOnline();
    setOnline(net);
    if (!net) {
      setCloudOk(false);
      return;
    }
    const health = await probeServer();
    const ok = health.status === "ONLINE";
    setCloudOk(ok);
    // Database problems are logged for operators only — never surfaced in the UI.
    if (!ok && health.status !== "OFFLINE_MODE") {
      console.warn(`[match-cricket] cloud sync unavailable (${health.status})`);
    }
    if (ok) await syncNow();
  }, [syncNow]);

  useEffect(() => {
    // Deferred so the first paint is never blocked by a state update.
    const boot = setTimeout(() => {
      void probe();
      void refreshPending();
    }, 0);
    const on = () => void probe();
    const off = () => {
      setOnline(false);
      setCloudOk(false);
    };
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    const t = setInterval(() => {
      void refreshPending();
      if (isOnline() && !cloudOk) void probe();
    }, 8000);
    return () => {
      clearTimeout(boot);
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
      clearInterval(t);
    };
  }, [probe, refreshPending, cloudOk]);

  const mode: ConnMode = syncing
    ? "SYNCING"
    : !online
      ? "OFFLINE"
      : !cloudOk
        ? "LOCAL"
        : pending > 0
          ? "ONLINE"
          : "SYNCED";

  return (
    <ConnCtx.Provider value={{ mode, online, pending, syncNow }}>{children}</ConnCtx.Provider>
  );
}
