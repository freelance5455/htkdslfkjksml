import React, { useState, useEffect } from 'react';
import { 
  X, 
  Save, 
  MapPin, 
  Locate, 
  AlertCircle, 
  FileText, 
  User, 
  Phone, 
  Gauge, 
  Check, 
  ShieldAlert,
  HelpCircle
} from 'lucide-react';
import { MeterRecord } from '../../types/meter';

interface MeterFormModalProps {
  isOpen: boolean;
  meterToEdit: MeterRecord | null;
  onClose: () => void;
  onSave: (record: MeterRecord) => void;
}

export const MeterFormModal: React.FC<MeterFormModalProps> = ({
  isOpen,
  meterToEdit,
  onClose,
  onSave
}) => {
  const [formData, setFormData] = useState<Partial<MeterRecord>>({
    gda: '',
    ref: '',
    ctr: '',
    index: 0,
    compt: '',
    saisie: false,
    nonSaisie: true,
    bloque: false,
    nouvIndex: null,
    hublotTaps: false,
    clientAbsent: false,
    necessiteVerification: false,
    sansPlombage: false,
    numFI: '',
    observation: '',
    latitude: null,
    longitude: null,
    address: '',
    clientName: '',
    phone: '',
  });

  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (meterToEdit) {
      setFormData({ ...meterToEdit });
    } else {
      setFormData({
        id: `rec-${Date.now()}`,
        gda: '',
        ref: '',
        ctr: '',
        index: 0,
        compt: '',
        saisie: false,
        nonSaisie: true,
        bloque: false,
        nouvIndex: null,
        hublotTaps: false,
        clientAbsent: false,
        necessiteVerification: false,
        sansPlombage: false,
        numFI: '',
        observation: '',
        latitude: null,
        longitude: null,
        address: '',
        clientName: '',
        phone: '',
      });
    }
    setErrorMsg(null);
  }, [meterToEdit, isOpen]);

  if (!isOpen) return null;

  const handleGetDeviceLocation = () => {
    if (!navigator.geolocation) {
      setErrorMsg('تحديد الموقع غير مدعوم في متصفحك');
      return;
    }

    setIsLocating(true);
    setErrorMsg(null);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setFormData(prev => ({
          ...prev,
          latitude: parseFloat(pos.coords.latitude.toFixed(6)),
          longitude: parseFloat(pos.coords.longitude.toFixed(6))
        }));
        setIsLocating(false);
      },
      (err) => {
        setIsLocating(false);
        setErrorMsg(`فشل جلب الموقع الجغرافي: ${err.message}`);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.gda?.trim() && !formData.ref?.trim() && !formData.compt?.trim()) {
      setErrorMsg('يرجى إدخال على الأقل رمز GDA أو مرجع الحريف REF أو رقم العداد COMPT');
      return;
    }

    const hasNewIndex = formData.nouvIndex !== null && !isNaN(formData.nouvIndex as number);
    const isSaisie = formData.saisie || hasNewIndex;

    const recordToSave: MeterRecord = {
      id: formData.id || `rec-${Date.now()}`,
      gda: formData.gda?.trim() || '',
      ref: formData.ref?.trim() || '',
      ctr: formData.ctr?.trim() || '',
      index: Number(formData.index) || 0,
      compt: formData.compt?.trim() || '',
      saisie: isSaisie,
      nonSaisie: !isSaisie,
      bloque: Boolean(formData.bloque),
      nouvIndex: hasNewIndex ? Number(formData.nouvIndex) : null,
      hublotTaps: Boolean(formData.hublotTaps),
      clientAbsent: Boolean(formData.clientAbsent),
      necessiteVerification: Boolean(formData.necessiteVerification),
      sansPlombage: Boolean(formData.sansPlombage),
      numFI: formData.numFI?.trim() || '',
      observation: formData.observation?.trim() || '',
      latitude: formData.latitude != null ? Number(formData.latitude) : null,
      longitude: formData.longitude != null ? Number(formData.longitude) : null,
      address: formData.address?.trim() || '',
      clientName: formData.clientName?.trim() || '',
      phone: formData.phone?.trim() || '',
      dateReleve: isSaisie 
        ? (formData.dateReleve || new Date().toISOString().substring(0, 16).replace('T', ' '))
        : null
    };

    onSave(recordToSave);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div 
        className="bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl w-full max-w-2xl text-slate-100 overflow-hidden my-6 transition-all"
        dir="rtl"
      >
        {/* Header */}
        <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-orange-500/10 text-orange-400 border border-orange-500/20">
              <Gauge className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100">
                {meterToEdit ? 'تعديل بيانات العداد' : 'إضافة عداد جديد إلى الجولة'}
              </h2>
              <p className="text-xs text-slate-400">
                أدخل بيانات العداد والمؤشر والموقع الجغرافي
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Error message */}
        {errorMsg && (
          <div className="mx-4 mt-4 p-3 bg-rose-950/60 border border-rose-800 text-rose-200 text-xs rounded-lg flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Main Meter Identifiers */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                رمز GDA / الجولة *
              </label>
              <input
                type="text"
                value={formData.gda || ''}
                onChange={e => setFormData({ ...formData, gda: e.target.value })}
                placeholder="مثال: G6272884"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                المرجع REF (رقم الحريف) *
              </label>
              <input
                type="text"
                value={formData.ref || ''}
                onChange={e => setFormData({ ...formData, ref: e.target.value })}
                placeholder="مثال: 921132540"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                رقم العقد CTR
              </label>
              <input
                type="text"
                value={formData.ctr || ''}
                onChange={e => setFormData({ ...formData, ctr: e.target.value })}
                placeholder="مثال: 00166341/2019"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                رقم العداد COMPT
              </label>
              <input
                type="text"
                value={formData.compt || ''}
                onChange={e => setFormData({ ...formData, compt: e.target.value })}
                placeholder="مثال: GM190400166341"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                المؤشر القديم (INDEX)
              </label>
              <input
                type="number"
                value={formData.index !== undefined ? formData.index : 0}
                onChange={e => setFormData({ ...formData, index: parseFloat(e.target.value) || 0 })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-emerald-400 mb-1">
                المؤشر الجديد (Nouv. Index)
              </label>
              <input
                type="number"
                value={formData.nouvIndex !== null && formData.nouvIndex !== undefined ? formData.nouvIndex : ''}
                onChange={e => {
                  const val = e.target.value === '' ? null : parseFloat(e.target.value);
                  setFormData({
                    ...formData,
                    nouvIndex: val,
                    saisie: val !== null,
                    nonSaisie: val === null
                  });
                }}
                placeholder="أدخل المؤشر المسجل..."
                className="w-full bg-emerald-950/40 border border-emerald-600/60 rounded-lg px-3 py-2 text-sm text-emerald-200 font-mono font-bold focus:outline-none focus:border-emerald-400"
              />
            </div>
          </div>

          {/* Status & Condition Checkboxes */}
          <div className="bg-slate-950/50 p-3.5 rounded-xl border border-slate-800">
            <h3 className="text-xs font-bold text-slate-300 mb-2.5 flex items-center gap-1.5">
              <span>حالة العداد والتدخل الميداني</span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              <label className="flex items-center gap-2 p-2 rounded-lg bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 cursor-pointer text-xs">
                <input
                  type="checkbox"
                  checked={formData.saisie || false}
                  onChange={e => setFormData({ ...formData, saisie: e.target.checked, nonSaisie: !e.target.checked })}
                  className="rounded text-emerald-600 focus:ring-0 focus:ring-offset-0 bg-slate-900 border-slate-600"
                />
                <span className="font-semibold text-emerald-400">تم الرفع (Saisie)</span>
              </label>

              <label className="flex items-center gap-2 p-2 rounded-lg bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 cursor-pointer text-xs">
                <input
                  type="checkbox"
                  checked={formData.bloque || false}
                  onChange={e => setFormData({ ...formData, bloque: e.target.checked })}
                  className="rounded text-rose-600 focus:ring-0 focus:ring-offset-0 bg-slate-900 border-slate-600"
                />
                <span className="font-semibold text-rose-400">معطل / متوقف (Bloqué)</span>
              </label>

              <label className="flex items-center gap-2 p-2 rounded-lg bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 cursor-pointer text-xs">
                <input
                  type="checkbox"
                  checked={formData.clientAbsent || false}
                  onChange={e => setFormData({ ...formData, clientAbsent: e.target.checked })}
                  className="rounded text-amber-500 focus:ring-0 focus:ring-offset-0 bg-slate-900 border-slate-600"
                />
                <span className="text-amber-300">حريف غائب (Absent)</span>
              </label>

              <label className="flex items-center gap-2 p-2 rounded-lg bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 cursor-pointer text-xs">
                <input
                  type="checkbox"
                  checked={formData.hublotTaps || false}
                  onChange={e => setFormData({ ...formData, hublotTaps: e.target.checked })}
                  className="rounded text-purple-600 focus:ring-0 focus:ring-offset-0 bg-slate-900 border-slate-600"
                />
                <span className="text-purple-300">خلل زجاج (Hublot+Taps)</span>
              </label>

              <label className="flex items-center gap-2 p-2 rounded-lg bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 cursor-pointer text-xs">
                <input
                  type="checkbox"
                  checked={formData.sansPlombage || false}
                  onChange={e => setFormData({ ...formData, sansPlombage: e.target.checked })}
                  className="rounded text-rose-500 focus:ring-0 focus:ring-offset-0 bg-slate-900 border-slate-600"
                />
                <span className="text-rose-300">بدون ترصيص (Sans plombage)</span>
              </label>

              <label className="flex items-center gap-2 p-2 rounded-lg bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 cursor-pointer text-xs">
                <input
                  type="checkbox"
                  checked={formData.necessiteVerification || false}
                  onChange={e => setFormData({ ...formData, necessiteVerification: e.target.checked })}
                  className="rounded text-orange-500 focus:ring-0 focus:ring-offset-0 bg-slate-900 border-slate-600"
                />
                <span className="text-orange-300">يحتاج تدقيق (Vérification)</span>
              </label>
            </div>
          </div>

          {/* Location & Navigation Section */}
          <div className="bg-slate-950/50 p-3.5 rounded-xl border border-slate-800">
            <div className="flex items-center justify-between mb-2.5">
              <h3 className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-orange-400" />
                <span>الموقع الجغرافي والتوجيه (GPS)</span>
              </h3>
              <button
                type="button"
                onClick={handleGetDeviceLocation}
                disabled={isLocating}
                className="flex items-center gap-1 bg-blue-600/30 hover:bg-blue-600 text-blue-300 hover:text-white border border-blue-500/40 px-2.5 py-1 rounded-lg text-xs font-medium transition-colors"
              >
                <Locate className={`w-3.5 h-3.5 ${isLocating ? 'animate-spin' : ''}`} />
                <span>{isLocating ? 'جارِ الجلب...' : 'جلب موقعي الحالي'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-2.5">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">
                  خط العرض (Latitude)
                </label>
                <input
                  type="number"
                  step="any"
                  value={formData.latitude !== null && formData.latitude !== undefined ? formData.latitude : ''}
                  onChange={e => setFormData({ ...formData, latitude: e.target.value ? parseFloat(e.target.value) : null })}
                  placeholder="مثال: 36.8188"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">
                  خط الطول (Longitude)
                </label>
                <input
                  type="number"
                  step="any"
                  value={formData.longitude !== null && formData.longitude !== undefined ? formData.longitude : ''}
                  onChange={e => setFormData({ ...formData, longitude: e.target.value ? parseFloat(e.target.value) : null })}
                  placeholder="مثال: 10.1658"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">
                العنوان أو الحي أو المعلم البارز
              </label>
              <input
                type="text"
                value={formData.address || ''}
                onChange={e => setFormData({ ...formData, address: e.target.value })}
                placeholder="مثال: نهج فلسطين، عمارة 12، بجانب المسجد"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-orange-500"
              />
            </div>
          </div>

          {/* Client Details & Intervention */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                اسم الحريف (اختياري)
              </label>
              <input
                type="text"
                value={formData.clientName || ''}
                onChange={e => setFormData({ ...formData, clientName: e.target.value })}
                placeholder="اسم صاحب العداد"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                رقم الهاتف
              </label>
              <input
                type="text"
                value={formData.phone || ''}
                onChange={e => setFormData({ ...formData, phone: e.target.value })}
                placeholder="+216 ..."
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                رقم بطاقة التدخل (N° FI)
              </label>
              <input
                type="text"
                value={formData.numFI || ''}
                onChange={e => setFormData({ ...formData, numFI: e.target.value })}
                placeholder="مثال: FI-2024-001"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
              />
            </div>
          </div>

          {/* Observation */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              ملاحظات الميدان (Observation)
            </label>
            <textarea
              rows={2}
              value={formData.observation || ''}
              onChange={e => setFormData({ ...formData, observation: e.target.value })}
              placeholder="مثال: RAS، أو ملاحظة حول حالة العداد والوصول إليه..."
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-orange-500 resize-none"
            />
          </div>

          {/* Modal Footer Actions */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-lg bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white text-xs font-bold shadow-lg transition-all flex items-center gap-1.5"
            >
              <Save className="w-4 h-4" />
              <span>حفظ البيانات</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
