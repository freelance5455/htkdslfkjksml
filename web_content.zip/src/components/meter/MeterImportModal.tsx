import React, { useState, useRef } from 'react';
import { 
  X, 
  Upload, 
  FileSpreadsheet, 
  FileText, 
  Check, 
  AlertCircle, 
  ArrowRight,
  Database
} from 'lucide-react';
import { MeterRecord } from '../../types/meter';
import { parseExcelToMeters, parseCSVToMeters } from '../../utils/meterExcel';

interface MeterImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (records: MeterRecord[], mode: 'replace' | 'append') => void;
}

export const MeterImportModal: React.FC<MeterImportModalProps> = ({
  isOpen,
  onClose,
  onImport
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [activeTab, setActiveTab] = useState<'file' | 'paste'>('file');
  const [pastedText, setPastedText] = useState<string>('');
  const [parsedPreview, setParsedPreview] = useState<MeterRecord[]>([]);
  const [fileName, setFileName] = useState<string | null>(null);
  const [importMode, setImportMode] = useState<'replace' | 'append'>('replace');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleFileUpload = async (file: File) => {
    setIsProcessing(true);
    setErrorMsg(null);
    setFileName(file.name);

    try {
      if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) {
        const buffer = await file.arrayBuffer();
        const records = await parseExcelToMeters(buffer);
        if (records.length === 0) {
          setErrorMsg('لم يتم العثور على أسطر صالحة في ملف الإكسيل. تأكد من وجود رؤوس الأعمدة: GDA, REF, COMPT...');
        } else {
          setParsedPreview(records);
        }
      } else {
        // Assume CSV or text
        const text = await file.text();
        const records = parseCSVToMeters(text);
        if (records.length === 0) {
          setErrorMsg('لم يتم التعرف على بنية ملف CSV. تأكد من الفواصل (;) أو (,) ورؤوس الأعمدة');
        } else {
          setParsedPreview(records);
        }
      }
    } catch (err: any) {
      setErrorMsg(`فشل قراءة الملف: ${err.message || 'خطأ غير معروف'}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileUpload(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFileUpload(file);
    }
  };

  const handleParsePastedText = () => {
    if (!pastedText.trim()) {
      setErrorMsg('الرجاء لصق نص الجدول أو CSV أولاً');
      return;
    }

    setIsProcessing(true);
    setErrorMsg(null);

    try {
      const records = parseCSVToMeters(pastedText);
      if (records.length === 0) {
        setErrorMsg('تعذر تحليل النص الملصق. تأكد من احتواء السطر الأول على عناوين الأعمدة مفصولة بـ (;)');
      } else {
        setParsedPreview(records);
      }
    } catch (err: any) {
      setErrorMsg(`خطأ في التحليل: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleConfirmImport = () => {
    if (parsedPreview.length === 0) return;
    onImport(parsedPreview, importMode);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm overflow-y-auto">
      <div 
        className="bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl w-full max-w-2xl text-slate-100 overflow-hidden my-6"
        dir="rtl"
      >
        {/* Header */}
        <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100">
                استيراد جدول إكسيل أو CSV للعدادات
              </h2>
              <p className="text-xs text-slate-400">
                رفع ملف .xlsx / .xls أو لصق نص البيانات مباشرة (GDA;REF;CTR;INDEX;COMPT...)
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950/40">
          <button
            onClick={() => setActiveTab('file')}
            className={`flex-1 py-2.5 text-xs font-bold flex items-center justify-center gap-2 border-b-2 transition-colors ${
              activeTab === 'file'
                ? 'border-emerald-500 text-emerald-400 bg-slate-800/40'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Upload className="w-4 h-4" />
            <span>رفع ملف إكسيل / CSV</span>
          </button>
          <button
            onClick={() => setActiveTab('paste')}
            className={`flex-1 py-2.5 text-xs font-bold flex items-center justify-center gap-2 border-b-2 transition-colors ${
              activeTab === 'paste'
                ? 'border-emerald-500 text-emerald-400 bg-slate-800/40'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>لصق نص الجدول مباشرة</span>
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          {errorMsg && (
            <div className="p-3 bg-rose-950/60 border border-rose-800 text-rose-200 text-xs rounded-lg flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMsg}</span>
            </div>
          )}

          {activeTab === 'file' ? (
            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-700 hover:border-emerald-500/70 bg-slate-950/40 hover:bg-slate-800/30 rounded-xl p-8 text-center cursor-pointer transition-all"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx,.xls,.csv,.txt"
                onChange={handleFileChange}
                className="hidden"
              />
              <FileSpreadsheet className="w-12 h-12 text-emerald-400 mx-auto mb-3 opacity-90" />
              <p className="text-sm font-bold text-slate-200 mb-1">
                اسحب ملف الإكسيل هنا أو انقر للاختيار من جهازك
              </p>
              <p className="text-xs text-slate-400">
                يدعم صيغ Microsoft Excel (.xlsx, .xls) وملفات CSV المفصولة بفاصلة منقوطة (;)
              </p>
              {fileName && (
                <div className="mt-3 inline-flex items-center gap-2 bg-emerald-950/60 text-emerald-300 border border-emerald-700 px-3 py-1 rounded-full text-xs font-mono">
                  <span>{fileName}</span>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-300">
                الصق أسطر الجدول هنا (مفصولة بـ ; مثل صيغة جدول الشركة):
              </label>
              <textarea
                rows={6}
                value={pastedText}
                onChange={e => setPastedText(e.target.value)}
                placeholder="GDA;REF;CTR;INDEX;COMPT,SAISIE;Non saisie;Saisie;Bloqué;...&#10;G6272884;921132540;00166341/2019;920;GM190400166341;;1;;;1;;;;;;"
                className="w-full bg-slate-950/80 border border-slate-700 rounded-lg p-3 text-xs font-mono text-slate-200 focus:outline-none focus:border-emerald-500"
              />
              <button
                type="button"
                onClick={handleParsePastedText}
                disabled={isProcessing}
                className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors"
              >
                تحليل النص الملصق
              </button>
            </div>
          )}

          {/* Preview of Parsed Rows */}
          {parsedPreview.length > 0 && (
            <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
                  <Check className="w-4 h-4" />
                  <span>تم استخراج {parsedPreview.length} سطر بنجاح</span>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-slate-400">طريقة الإضافة:</span>
                  <select
                    value={importMode}
                    onChange={(e: any) => setImportMode(e.target.value)}
                    className="bg-slate-800 border border-slate-700 text-slate-200 text-xs rounded px-2 py-1 focus:outline-none"
                  >
                    <option value="replace">استبدال الجدول بالكامل</option>
                    <option value="append">إضافة إلى البيانات الحالية</option>
                  </select>
                </div>
              </div>

              {/* Mini Table Preview */}
              <div className="max-h-40 overflow-y-auto border border-slate-800 rounded-lg">
                <table className="w-full text-right text-[11px]">
                  <thead className="bg-slate-800 text-slate-300 font-mono sticky top-0">
                    <tr>
                      <th className="p-1.5">#</th>
                      <th className="p-1.5">GDA</th>
                      <th className="p-1.5">REF</th>
                      <th className="p-1.5">CTR</th>
                      <th className="p-1.5">المؤشر</th>
                      <th className="p-1.5">رقم العداد</th>
                      <th className="p-1.5">الحالة</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 text-slate-300 font-mono">
                    {parsedPreview.slice(0, 10).map((r, i) => (
                      <tr key={i} className="hover:bg-slate-800/40">
                        <td className="p-1.5 text-slate-500">{i + 1}</td>
                        <td className="p-1.5 font-bold text-orange-300">{r.gda}</td>
                        <td className="p-1.5">{r.ref}</td>
                        <td className="p-1.5">{r.ctr}</td>
                        <td className="p-1.5 text-emerald-300">{r.index}</td>
                        <td className="p-1.5">{r.compt}</td>
                        <td className="p-1.5">
                          {r.saisie ? (
                            <span className="text-emerald-400">تم الرفع</span>
                          ) : r.bloque ? (
                            <span className="text-rose-400">معطل</span>
                          ) : (
                            <span className="text-slate-400">غير مسجل</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {parsedPreview.length > 10 && (
                <p className="text-[11px] text-slate-500 text-center">
                  + {parsedPreview.length - 10} أسطر أخرى سيتم استيرادها...
                </p>
              )}
            </div>
          )}

          {/* Footer */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors"
            >
              إلغاء
            </button>
            <button
              type="button"
              onClick={handleConfirmImport}
              disabled={parsedPreview.length === 0}
              className="px-5 py-2 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 text-white text-xs font-bold shadow-lg transition-all flex items-center gap-1.5"
            >
              <Database className="w-4 h-4" />
              <span>تأكيد استيراد ({parsedPreview.length}) عداد</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
