import React, { useState, useEffect } from 'react';
import { 
  X, 
  Check, 
  ChevronRight, 
  ChevronLeft, 
  Navigation, 
  AlertTriangle, 
  UserX, 
  MapPin, 
  Gauge, 
  RotateCcw,
  ExternalLink,
  ShieldAlert
} from 'lucide-react';
import { MeterRecord } from '../../types/meter';

interface QuickRecordModalProps {
  isOpen: boolean;
  meter: MeterRecord | null;
  metersList: MeterRecord[];
  onClose: () => void;
  onSaveAndNext: (updated: MeterRecord, nextMeterId?: string) => void;
}

export const QuickRecordModal: React.FC<QuickRecordModalProps> = ({
  isOpen,
  meter,
  metersList,
  onClose,
  onSaveAndNext
}) => {
  const [currentId, setCurrentId] = useState<string | null>(meter?.id || null);
  const [nouvIndexVal, setNouvIndexVal] = useState<string>('');
  const [bloque, setBloque] = useState<boolean>(false);
  const [clientAbsent, setClientAbsent] = useState<boolean>(false);
  const [hublotTaps, setHublotTaps] = useState<boolean>(false);
  const [sansPlombage, setSansPlombage] = useState<boolean>(false);
  const [necessiteVerification, setNecessiteVerification] = useState<boolean>(false);
  const [observation, setObservation] = useState<string>('');

  const currentMeter = metersList.find(m => m.id === currentId) || meter;
  const currentIndex = currentMeter ? metersList.findIndex(m => m.id === currentMeter.id) : -1;

  useEffect(() => {
    if (meter) {
      setCurrentId(meter.id);
    }
  }, [meter]);

  useEffect(() => {
    if (currentMeter) {
      setNouvIndexVal(currentMeter.nouvIndex !== null ? String(currentMeter.nouvIndex) : '');
      setBloque(currentMeter.bloque);
      setClientAbsent(currentMeter.clientAbsent);
      setHublotTaps(currentMeter.hublotTaps);
      setSansPlombage(currentMeter.sansPlombage);
      setNecessiteVerification(currentMeter.necessiteVerification);
      setObservation(currentMeter.observation || '');
    }
  }, [currentMeter?.id]);

  if (!isOpen || !currentMeter) return null;

  const handleSave = (goToNext: boolean) => {
    const parsedNum = nouvIndexVal.trim() === '' ? null : parseFloat(nouvIndexVal);
    const hasRecorded = parsedNum !== null && !isNaN(parsedNum);
    const isSaisie = hasRecorded || (!clientAbsent && !bloque && currentMeter.saisie);

    const updated: MeterRecord = {
      ...currentMeter,
      nouvIndex: parsedNum,
      saisie: isSaisie,
      nonSaisie: !isSaisie,
      bloque,
      clientAbsent,
      hublotTaps,
      sansPlombage,
      necessiteVerification,
      observation: observation.trim(),
      dateReleve: isSaisie 
        ? new Date().toISOString().substring(0, 16).replace('T', ' ')
        : currentMeter.dateReleve
    };

    let nextId: string | undefined = undefined;
    if (goToNext && currentIndex < metersList.length - 1) {
      nextId = metersList[currentIndex + 1].id;
      setCurrentId(nextId);
    }

    onSaveAndNext(updated, nextId);

    if (!goToNext || currentIndex === metersList.length - 1) {
      onClose();
    }
  };

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setCurrentId(metersList[currentIndex - 1].id);
    }
  };

  const handleNext = () => {
    if (currentIndex < metersList.length - 1) {
      setCurrentId(metersList[currentIndex + 1].id);
    }
  };

  // Quick Keypad append
  const handleKeypadPress = (digit: string) => {
    setNouvIndexVal(prev => prev + digit);
  };

  const handleKeypadClear = () => {
    setNouvIndexVal('');
  };

  const handleKeypadBackspace = () => {
    setNouvIndexVal(prev => prev.slice(0, -1));
  };

  // Google Maps Direction URL
  const gmapsUrl = currentMeter.latitude && currentMeter.longitude
    ? `https://www.google.com/maps/dir/?api=1&destination=${currentMeter.latitude},${currentMeter.longitude}`
    : null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div 
        className="bg-slate-900 border border-slate-700/90 rounded-2xl shadow-2xl w-full max-w-lg text-slate-100 overflow-hidden my-auto"
        dir="rtl"
      >
        {/* Header with Counter Stepper */}
        <div className="p-3.5 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-orange-500/20 text-orange-400 text-xs font-mono font-bold flex items-center justify-center border border-orange-500/30">
              {currentIndex + 1}
            </span>
            <div>
              <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <span>تسجيل المؤشر السريع</span>
                <span className="text-xs text-slate-400 font-mono">({currentIndex + 1} من {metersList.length})</span>
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={handlePrevious}
              disabled={currentIndex <= 0}
              className="p-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-slate-300"
              title="العداد السابق"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={handleNext}
              disabled={currentIndex >= metersList.length - 1}
              className="p-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-slate-300"
              title="العداد التالي"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button 
              onClick={onClose}
              className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 mr-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Meter Info Card */}
        <div className="p-4 bg-slate-950/50 border-b border-slate-800 space-y-2">
          <div className="flex items-start justify-between">
            <div>
              <div className="text-xs text-slate-400">رمز GDA:</div>
              <div className="font-mono font-bold text-xl text-orange-400 tracking-wider">
                {currentMeter.gda}
              </div>
            </div>

            <div className="text-left">
              <div className="text-xs text-slate-400">رقم العداد (COMPT):</div>
              <div className="font-mono font-bold text-sm text-slate-200">
                {currentMeter.compt || '—'}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
            <div>
              <span className="text-slate-400 block text-[11px]">المرجع (REF):</span>
              <span className="font-mono font-bold text-slate-200">{currentMeter.ref}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">رقم العقد (CTR):</span>
              <span className="font-mono text-slate-300">{currentMeter.ctr}</span>
            </div>
            {currentMeter.address && (
              <div className="col-span-2 pt-1 border-t border-slate-800/80">
                <span className="text-slate-400 block text-[11px]">العنوان / الموقع:</span>
                <span className="text-slate-200">{currentMeter.address}</span>
              </div>
            )}
          </div>

          {/* Quick GPS button */}
          {gmapsUrl && (
            <a
              href={gmapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-1.5 py-1.5 px-3 bg-blue-600/30 hover:bg-blue-600 border border-blue-500/40 text-blue-300 hover:text-white rounded-lg text-xs font-semibold transition-colors"
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>فتح في خرائط جوجل للتوجيه المباشر</span>
              <ExternalLink className="w-3 h-3 opacity-70" />
            </a>
          )}
        </div>

        {/* Index Input Box */}
        <div className="p-4 space-y-3">
          <div className="flex items-center justify-between bg-slate-950/70 p-3 rounded-xl border border-slate-800">
            <div>
              <div className="text-[11px] text-slate-400">المؤشر السابق:</div>
              <div className="font-mono font-bold text-lg text-slate-300">
                {currentMeter.index}
              </div>
            </div>

            <div className="text-left">
              <div className="text-[11px] text-emerald-400 font-bold">المؤشر الجديد:</div>
              <input
                type="text"
                value={nouvIndexVal}
                onChange={e => setNouvIndexVal(e.target.value)}
                placeholder="أدخل الرقم..."
                autoFocus
                className="w-36 text-center font-mono text-xl font-bold bg-slate-900 border-2 border-emerald-500/70 rounded-lg py-1 px-2 text-emerald-300 focus:outline-none focus:border-emerald-400"
              />
            </div>
          </div>

          {/* On-screen Keypad for fast tablet/mobile input */}
          <div className="grid grid-cols-3 gap-1.5">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(d => (
              <button
                key={d}
                type="button"
                onClick={() => handleKeypadPress(d)}
                className="py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-100 font-mono font-bold text-base border border-slate-700/60 shadow-sm active:scale-95 transition-all"
              >
                {d}
              </button>
            ))}
            <button
              type="button"
              onClick={handleKeypadClear}
              className="py-2.5 rounded-lg bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 font-bold text-xs border border-rose-800/50 active:scale-95"
            >
              مسح C
            </button>
            <button
              type="button"
              onClick={() => handleKeypadPress('0')}
              className="py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-100 font-mono font-bold text-base border border-slate-700/60 shadow-sm active:scale-95 transition-all"
            >
              0
            </button>
            <button
              type="button"
              onClick={handleKeypadBackspace}
              className="py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs border border-slate-700/60 active:scale-95"
            >
              ← حذف
            </button>
          </div>

          {/* Quick Status Buttons */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              onClick={() => {
                setBloque(!bloque);
                if (!bloque) setClientAbsent(false);
              }}
              className={`p-2 rounded-lg border text-xs font-bold flex items-center justify-center gap-1.5 transition-colors ${
                bloque
                  ? 'bg-rose-900/60 border-rose-500 text-rose-200'
                  : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
              <span>عداد معطل / متوقف</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setClientAbsent(!clientAbsent);
                if (!clientAbsent) setBloque(false);
              }}
              className={`p-2 rounded-lg border text-xs font-bold flex items-center justify-center gap-1.5 transition-colors ${
                clientAbsent
                  ? 'bg-amber-900/60 border-amber-500 text-amber-200'
                  : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <UserX className="w-3.5 h-3.5 text-amber-400" />
              <span>الحريف غائب</span>
            </button>

            <button
              type="button"
              onClick={() => setHublotTaps(!hublotTaps)}
              className={`p-1.5 rounded-lg border text-xs flex items-center justify-center gap-1.5 transition-colors ${
                hublotTaps
                  ? 'bg-purple-900/60 border-purple-500 text-purple-200 font-bold'
                  : 'bg-slate-800/40 border-slate-800 text-slate-400 hover:bg-slate-800'
              }`}
            >
              <span>كسر زجاج (Hublot)</span>
            </button>

            <button
              type="button"
              onClick={() => setSansPlombage(!sansPlombage)}
              className={`p-1.5 rounded-lg border text-xs flex items-center justify-center gap-1.5 transition-colors ${
                sansPlombage
                  ? 'bg-rose-900/60 border-rose-500 text-rose-200 font-bold'
                  : 'bg-slate-800/40 border-slate-800 text-slate-400 hover:bg-slate-800'
              }`}
            >
              <span>بدون ترصيص</span>
            </button>
          </div>

          {/* Quick Observation note */}
          <div>
            <input
              type="text"
              value={observation}
              onChange={e => setObservation(e.target.value)}
              placeholder="ملاحظة سريعة (مثال: RAS، باب مقفل، كلب...)"
              className="w-full bg-slate-950/60 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-orange-500"
            />
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex items-center gap-2 border-t border-slate-800">
            <button
              type="button"
              onClick={() => handleSave(false)}
              className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition-colors"
            >
              حفظ هذا العداد فقط
            </button>
            <button
              type="button"
              onClick={() => handleSave(true)}
              className="flex-[2] py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs shadow-lg flex items-center justify-center gap-1.5 transition-all"
            >
              <Check className="w-4 h-4" />
              <span>حفظ والانتقال للتالي (التلقائي) ←</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
