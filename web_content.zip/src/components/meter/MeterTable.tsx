import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
  Search, 
  Plus, 
  Upload, 
  Download, 
  MapPin, 
  Navigation, 
  Trash2, 
  Edit3, 
  CheckCircle2, 
  AlertTriangle, 
  UserX, 
  ShieldAlert, 
  Gauge, 
  Layers, 
  Map, 
  Table as TableIcon,
  RefreshCw,
  ExternalLink,
  ChevronDown,
  CheckSquare,
  Square,
  Play,
  Filter,
  Copy,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Columns,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Check,
  X,
  Sparkles,
  Locate,
  CornerDownLeft,
  Settings2
} from 'lucide-react';
import { MeterRecord, MeterFilterStatus, TourneeStats } from '../../types/meter';
import { calculateStats } from '../../utils/meterStorage';

export type SortField = 
  | 'gda' 
  | 'ref' 
  | 'ctr' 
  | 'index' 
  | 'nouvIndex' 
  | 'compt' 
  | 'saisie' 
  | 'address' 
  | 'observation';

export type SortOrder = 'asc' | 'desc' | 'none';

interface MeterTableProps {
  meters: MeterRecord[];
  onAddMeter: () => void;
  onQuickAddRow: (newRecord: MeterRecord) => void;
  onDuplicateMeter: (meter: MeterRecord) => void;
  onEditMeter: (meter: MeterRecord) => void;
  onUpdateMeterInline: (id: string, updates: Partial<MeterRecord>) => void;
  onDeleteMeter: (id: string) => void;
  onDeleteMultiple: (ids: string[]) => void;
  onOpenImport: () => void;
  onOpenExport: () => void;
  onQuickRecord: (meter: MeterRecord) => void;
  onSelectOnMap: (meterId: string) => void;
  onOpenLocationPicker: (meter: MeterRecord) => void;
  viewMode: 'table' | 'map' | 'split';
  onToggleViewMode: (mode: 'table' | 'map' | 'split') => void;
  onResetToDemo: () => void;
  onClearAll?: () => void;
  selectedMeterId: string | null;
}

export const MeterTable: React.FC<MeterTableProps> = ({
  meters,
  onAddMeter,
  onQuickAddRow,
  onDuplicateMeter,
  onEditMeter,
  onUpdateMeterInline,
  onDeleteMeter,
  onDeleteMultiple,
  onOpenImport,
  onOpenExport,
  onQuickRecord,
  onSelectOnMap,
  onOpenLocationPicker,
  viewMode,
  onToggleViewMode,
  onResetToDemo,
  onClearAll,
  selectedMeterId
}) => {
  const tableContainerRef = useRef<HTMLDivElement>(null);

  // Search, Filter & Sort states
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [filterStatus, setFilterStatus] = useState<MeterFilterStatus>('all');
  const [selectedGdaFilter, setSelectedGdaFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<SortField>('gda');
  const [sortOrder, setSortOrder] = useState<SortOrder>('none');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // Density mode
  const [isCompact, setIsCompact] = useState<boolean>(false);

  // Column visibility
  const [visibleColumns, setVisibleColumns] = useState<Record<string, boolean>>({
    index: true,
    gda: true,
    ref: true,
    ctr: true,
    prevIndex: true,
    nouvIndex: true,
    compt: true,
    status: true,
    location: true,
    observation: true,
    actions: true
  });
  const [isColumnDropdownOpen, setIsColumnDropdownOpen] = useState<boolean>(false);

  // Inline Cell Editing state
  // key: `${meterId}-${fieldName}`
  const [editingCell, setEditingCell] = useState<{ id: string; field: string } | null>(null);
  const [cellEditValue, setCellEditValue] = useState<string>('');

  // Active keyboard cell navigation
  const [focusedRowIndex, setFocusedRowIndex] = useState<number>(-1);

  // Feedback indicator
  const [saveFeedback, setSaveFeedback] = useState<string | null>(null);

  // Calculate tour statistics
  const stats = useMemo<TourneeStats>(() => calculateStats(meters), [meters]);

  // Unique GDAs for filter dropdown
  const uniqueGdaList = useMemo(() => {
    const set = new Set<string>();
    meters.forEach(m => {
      if (m.gda?.trim()) set.add(m.gda.trim());
    });
    return Array.from(set).sort();
  }, [meters]);

  // Filter & Search & Sort records
  const filteredMeters = useMemo(() => {
    let result = meters.filter(m => {
      // 1. Search term matching across all fields
      if (searchTerm.trim()) {
        const term = searchTerm.toLowerCase().trim();
        const matches =
          (m.gda && m.gda.toLowerCase().includes(term)) ||
          (m.ref && m.ref.toLowerCase().includes(term)) ||
          (m.ctr && m.ctr.toLowerCase().includes(term)) ||
          (m.compt && m.compt.toLowerCase().includes(term)) ||
          (m.numFI && m.numFI.toLowerCase().includes(term)) ||
          (m.address && m.address.toLowerCase().includes(term)) ||
          (m.clientName && m.clientName.toLowerCase().includes(term)) ||
          (m.observation && m.observation.toLowerCase().includes(term));

        if (!matches) return false;
      }

      // 2. GDA group filter
      if (selectedGdaFilter !== 'all' && m.gda !== selectedGdaFilter) {
        return false;
      }

      // 3. Status filter
      switch (filterStatus) {
        case 'saisie':
          return m.saisie;
        case 'nonSaisie':
          return !m.saisie;
        case 'bloque':
          return m.bloque;
        case 'clientAbsent':
          return m.clientAbsent;
        case 'hublotTaps':
          return m.hublotTaps;
        case 'sansPlombage':
          return m.sansPlombage;
        case 'necessiteVerification':
          return m.necessiteVerification;
        case 'withLocation':
          return m.latitude != null && m.longitude != null && !isNaN(m.latitude) && !isNaN(m.longitude);
        case 'withoutLocation':
          return m.latitude == null || m.longitude == null || isNaN(m.latitude) || isNaN(m.longitude);
        case 'all':
        default:
          return true;
      }
    });

    // 4. Sorting
    if (sortOrder !== 'none') {
      result = [...result].sort((a, b) => {
        let valA: any = a[sortField as keyof MeterRecord];
        let valB: any = b[sortField as keyof MeterRecord];

        if (sortField === 'address') {
          valA = a.address || '';
          valB = b.address || '';
        }

        if (typeof valA === 'string' && typeof valB === 'string') {
          return sortOrder === 'asc' 
            ? valA.localeCompare(valB, 'ar', { numeric: true }) 
            : valB.localeCompare(valA, 'ar', { numeric: true });
        }

        const numA = valA !== null && valA !== undefined ? Number(valA) : -Infinity;
        const numB = valB !== null && valB !== undefined ? Number(valB) : -Infinity;

        return sortOrder === 'asc' ? numA - numB : numB - numA;
      });
    }

    return result;
  }, [meters, searchTerm, selectedGdaFilter, filterStatus, sortField, sortOrder]);

  // Handle column header click for sorting
  const handleSort = (field: SortField) => {
    if (sortField === field) {
      if (sortOrder === 'asc') setSortOrder('desc');
      else if (sortOrder === 'desc') setSortOrder('none');
      else setSortOrder('asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  // Bulk selection handlers
  const handleSelectAll = () => {
    if (selectedIds.size === filteredMeters.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredMeters.map(m => m.id)));
    }
  };

  const handleToggleSelect = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setSelectedIds(next);
  };

  const handleDeleteSelected = () => {
    if (selectedIds.size === 0) return;
    if (window.confirm(`هل أنت متأكد من حذف ${selectedIds.size} عداد محدد؟`)) {
      onDeleteMultiple(Array.from(selectedIds));
      setSelectedIds(new Set());
      showSaveNotice(`تم حذف ${selectedIds.size} عداد`);
    }
  };

  // Start inline editing
  const handleStartEdit = (meter: MeterRecord, field: string) => {
    setEditingCell({ id: meter.id, field });
    const currentVal = (meter as any)[field];
    setCellEditValue(currentVal !== null && currentVal !== undefined ? String(currentVal) : '');
  };

  // Save inline edit
  const handleCommitEdit = () => {
    if (!editingCell) return;

    const { id, field } = editingCell;
    const targetMeter = meters.find(m => m.id === id);
    if (!targetMeter) {
      setEditingCell(null);
      return;
    }

    let updatedValue: any = cellEditValue.trim();

    // Number conversions
    if (field === 'index') {
      const parsed = parseFloat(updatedValue.replace(/[^0-9.-]/g, ''));
      updatedValue = isNaN(parsed) ? 0 : parsed;
    } else if (field === 'nouvIndex') {
      if (updatedValue === '') {
        updatedValue = null;
      } else {
        const parsed = parseFloat(updatedValue.replace(/[^0-9.-]/g, ''));
        updatedValue = isNaN(parsed) ? null : parsed;
      }
    }

    const updates: Partial<MeterRecord> = { [field]: updatedValue };

    // If new index entered and is not null, auto-mark Saisie
    if (field === 'nouvIndex' && updatedValue !== null) {
      updates.saisie = true;
      updates.nonSaisie = false;
      if (!targetMeter.dateReleve) {
        updates.dateReleve = new Date().toISOString().substring(0, 16).replace('T', ' ');
      }
    }

    onUpdateMeterInline(id, updates);
    setEditingCell(null);
    showSaveNotice('تم حفظ تعديل الخانة بنجاح');
  };

  const handleCancelEdit = () => {
    setEditingCell(null);
    setCellEditValue('');
  };

  // Quick feedback toast helper
  const showSaveNotice = (msg: string) => {
    setSaveFeedback(msg);
    setTimeout(() => setSaveFeedback(null), 3000);
  };

  // Quick Inline Add Row
  const handleQuickAddRow = () => {
    const newRecord: MeterRecord = {
      id: `rec-${Date.now()}`,
      gda: uniqueGdaList.length > 0 ? uniqueGdaList[0] : 'G0000000',
      ref: '',
      ctr: '',
      index: 0,
      compt: '',
      saisie: false,
      nonSaisie: true,
      bloque: false,
      nouvIndex: null,
      hublotTaps: false,
      clientAbsent: false,
      necessiteVerification: false,
      sansPlombage: false,
      numFI: '',
      observation: '',
      latitude: null,
      longitude: null,
      address: '',
      clientName: '',
      phone: '',
      dateReleve: null
    };

    onQuickAddRow(newRecord);
    setEditingCell({ id: newRecord.id, field: 'gda' });
    setCellEditValue(newRecord.gda);
    showSaveNotice('تمت إضافة سطر جديد إلى الجدول');
  };

  // 1-Click Current Location GPS capture
  const handleCaptureCurrentGps = (meter: MeterRecord) => {
    if (!navigator.geolocation) {
      alert('المتصفح لا يدعم تحديد الموقع الجغرافي');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = parseFloat(pos.coords.latitude.toFixed(6));
        const lng = parseFloat(pos.coords.longitude.toFixed(6));
        onUpdateMeterInline(meter.id, {
          latitude: lat,
          longitude: lng,
          address: meter.address || 'موقع ملتقط بالـ GPS'
        });
        showSaveNotice(`تم تثبيت موقع العداد ${meter.gda} بنجاح 📍`);
      },
      (err) => {
        alert(`تعذر التقاط الموقع: ${err.message}`);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  // Keyboard navigation for whole table
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (editingCell) {
      if (e.key === 'Enter') {
        e.preventDefault();
        handleCommitEdit();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        handleCancelEdit();
      }
      return;
    }

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setFocusedRowIndex(prev => Math.min(prev + 1, filteredMeters.length - 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setFocusedRowIndex(prev => Math.max(prev - 1, 0));
    }
  };

  // Horizontal scroll helper
  const scrollTable = (direction: 'left' | 'right') => {
    if (tableContainerRef.current) {
      const offset = direction === 'left' ? -250 : 250;
      tableContainerRef.current.scrollBy({ left: offset, behavior: 'smooth' });
    }
  };

  return (
    <div className="space-y-4 text-slate-100" dir="rtl" onKeyDown={handleKeyDown}>
      {/* Save feedback indicator */}
      {saveFeedback && (
        <div className="fixed bottom-6 right-6 z-50 bg-emerald-600 text-white px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 text-xs font-bold border border-emerald-400 animate-bounce">
          <Check className="w-4 h-4" />
          <span>{saveFeedback}</span>
        </div>
      )}

      {/* 1. Tournee Stats Dashboard Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Total */}
        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl shadow-sm">
          <div className="text-slate-400 text-[11px] font-medium mb-1 flex items-center justify-between">
            <span>إجمالي العدادات</span>
            <Gauge className="w-3.5 h-3.5 text-blue-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-100">{stats.total}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">عداد في الجولة الحالية</div>
        </div>

        {/* Saisis / Progress */}
        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl relative overflow-hidden shadow-sm">
          <div className="text-emerald-400 text-[11px] font-medium mb-1 flex items-center justify-between">
            <span>تم الرفع (Saisie)</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <div className="text-2xl font-bold font-mono text-emerald-400">{stats.saisis}</div>
            <span className="text-xs text-emerald-300 font-mono font-semibold">({stats.progressPercent}%)</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-2 overflow-hidden">
            <div 
              className="bg-emerald-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${stats.progressPercent}%` }}
            />
          </div>
        </div>

        {/* Non saisis */}
        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl shadow-sm">
          <div className="text-slate-300 text-[11px] font-medium mb-1 flex items-center justify-between">
            <span>غير مسجل (معلق)</span>
            <span className="w-2 h-2 rounded-full bg-slate-500" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-300">{stats.nonSaisis}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">بانتظار الزيارة والرفع</div>
        </div>

        {/* Bloqués */}
        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl shadow-sm">
          <div className="text-rose-400 text-[11px] font-medium mb-1 flex items-center justify-between">
            <span>معطل / متوقف</span>
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-rose-400">{stats.bloques}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">عدادات متوقفة / عاطلة</div>
        </div>

        {/* Absents */}
        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl shadow-sm">
          <div className="text-amber-400 text-[11px] font-medium mb-1 flex items-center justify-between">
            <span>حريف غائب</span>
            <UserX className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-amber-400">{stats.absents}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">أبواب مقفلة / تعذر الوصول</div>
        </div>

        {/* GPS Locations */}
        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl shadow-sm">
          <div className="text-blue-400 text-[11px] font-medium mb-1 flex items-center justify-between">
            <span>محددة جغرافياً</span>
            <MapPin className="w-3.5 h-3.5 text-blue-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-blue-300">{stats.withGps}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">جاهزة للتوجيه بالـ GPS</div>
        </div>
      </div>

      {/* 2. Primary Navigation & Controls Bar */}
      <div className="bg-slate-900/95 border border-slate-800 p-3 rounded-xl flex flex-wrap items-center justify-between gap-3 shadow-lg">
        {/* Search Box & GDA Group Selector */}
        <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-[280px]">
          {/* Global Search Input */}
          <div className="relative flex-1 min-w-[180px] max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="بحث برمز GDA، المرجع REF، العقد CTR، العداد..."
              className="w-full bg-slate-950/80 border border-slate-700/80 rounded-lg pr-9 pl-8 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-orange-500 transition-colors"
            />
            {searchTerm && (
              <button 
                onClick={() => setSearchTerm('')}
                className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* GDA Group Filter Dropdown */}
          {uniqueGdaList.length > 1 && (
            <div className="flex items-center gap-1 bg-slate-950/80 border border-slate-700/80 px-2 py-1 rounded-lg text-xs">
              <span className="text-slate-400 text-[11px]">جولة:</span>
              <select
                value={selectedGdaFilter}
                onChange={e => setSelectedGdaFilter(e.target.value)}
                className="bg-transparent text-orange-400 font-mono font-bold focus:outline-none text-xs cursor-pointer"
              >
                <option value="all" className="bg-slate-900 text-slate-100">جميع الجولات ({meters.length})</option>
                {uniqueGdaList.map(gda => (
                  <option key={gda} value={gda} className="bg-slate-900 text-slate-100">
                    {gda} ({meters.filter(m => m.gda === gda).length})
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* View Mode Switcher: Table / Split / Map */}
          <div className="flex bg-slate-950/90 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => onToggleViewMode('table')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-semibold transition-all ${
                viewMode === 'table'
                  ? 'bg-orange-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="عرض الجدول بالحجم الكامل"
            >
              <TableIcon className="w-3.5 h-3.5" />
              <span>جدول البيانات</span>
            </button>

            <button
              onClick={() => onToggleViewMode('split')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold transition-all ${
                viewMode === 'split'
                  ? 'bg-orange-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="عرض مزدوج: جدول وخريطة معاً جنباً إلى جنب"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span>شاشة مزدوجة</span>
            </button>

            <button
              onClick={() => onToggleViewMode('map')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-semibold transition-all ${
                viewMode === 'map'
                  ? 'bg-orange-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="عرض الخريطة وتوجيه GPS"
            >
              <Map className="w-3.5 h-3.5" />
              <span>الخريطة ({stats.withGps})</span>
            </button>
          </div>
        </div>

        {/* Action Buttons: Add, Import, Export */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Quick inline row add */}
          <button
            onClick={handleQuickAddRow}
            className="flex items-center gap-1.5 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-bold text-xs px-3 py-1.5 rounded-lg shadow-md transition-all active:scale-95"
            title="إضافة سطر جديد للجدول مباشرة وتعديل خاناته"
          >
            <Plus className="w-4 h-4" />
            <span>+ سطر جديد</span>
          </button>

          {/* Full meter creation modal */}
          <button
            onClick={onAddMeter}
            className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs px-2.5 py-1.5 rounded-lg transition-colors"
            title="إضافة عداد بنموذج مفصل"
          >
            <span>نموذج كامل</span>
          </button>

          {/* Import / Export */}
          <button
            onClick={onOpenImport}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 font-semibold text-xs px-3 py-1.5 rounded-lg transition-colors"
            title="استيراد من ملف إكسيل أو CSV أو لصق أسطر الجدول"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>استيراد</span>
          </button>

          <button
            onClick={onOpenExport}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs px-3 py-1.5 rounded-lg transition-colors"
            title="تصدير وتحميل كملف إكسيل (.xlsx) أو CSV"
          >
            <Download className="w-3.5 h-3.5 text-orange-400" />
            <span>تصدير</span>
          </button>

          {/* Customize Columns dropdown */}
          <div className="relative">
            <button
              onClick={() => setIsColumnDropdownOpen(!isColumnDropdownOpen)}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 flex items-center gap-1 text-xs"
              title="تخصيص وإظهار/إخفاء الأعمدة"
            >
              <Columns className="w-3.5 h-3.5 text-slate-400" />
              <ChevronDown className="w-3 h-3" />
            </button>

            {isColumnDropdownOpen && (
              <div className="absolute left-0 mt-2 w-48 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl p-2 z-30 space-y-1 text-xs">
                <div className="font-bold text-slate-300 px-2 py-1 border-b border-slate-800 flex justify-between items-center">
                  <span>إظهار الأعمدة</span>
                  <button 
                    onClick={() => setIsColumnDropdownOpen(false)}
                    className="text-slate-500 hover:text-white"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
                {[
                  { key: 'gda', label: 'رمز GDA' },
                  { key: 'ref', label: 'المرجع REF' },
                  { key: 'ctr', label: 'العقد CTR' },
                  { key: 'prevIndex', label: 'المؤشر السابق' },
                  { key: 'nouvIndex', label: 'المؤشر الجديد' },
                  { key: 'compt', label: 'رقم العداد COMPT' },
                  { key: 'status', label: 'الحالة والملاحظات' },
                  { key: 'location', label: 'الموقع والتوجيه GPS' },
                  { key: 'observation', label: 'الملاحظة و N° FI' }
                ].map(col => (
                  <label 
                    key={col.key} 
                    className="flex items-center gap-2 px-2 py-1 hover:bg-slate-800 rounded cursor-pointer text-slate-200"
                  >
                    <input
                      type="checkbox"
                      checked={visibleColumns[col.key] !== false}
                      onChange={(e) => {
                        setVisibleColumns(prev => ({ ...prev, [col.key]: e.target.checked }));
                      }}
                      className="rounded accent-orange-500"
                    />
                    <span>{col.label}</span>
                  </label>
                ))}
              </div>
            )}
          </div>

          {/* Reset button */}
          <button
            onClick={onResetToDemo}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 border border-slate-700"
            title="إعادة تحميل نموذج بيانات الشركة التجريبي"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 3. Status Filters Bar & Multi-Select Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
        {/* Status Chips */}
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-slate-400 text-[11px] ml-1 flex items-center gap-1">
            <Filter className="w-3 h-3" />
            تصفية:
          </span>

          {[
            { id: 'all', label: 'الكل', count: meters.length, color: 'text-slate-200' },
            { id: 'saisie', label: 'تم الرفع (Saisie)', count: stats.saisis, color: 'text-emerald-400' },
            { id: 'nonSaisie', label: 'غير مسجل', count: stats.nonSaisis, color: 'text-slate-300' },
            { id: 'bloque', label: 'معطل (Bloqué)', count: stats.bloques, color: 'text-rose-400' },
            { id: 'clientAbsent', label: 'حريف غائب', count: stats.absents, color: 'text-amber-400' },
            { id: 'hublotTaps', label: 'كسر زجاج', count: meters.filter(m => m.hublotTaps).length, color: 'text-purple-400' },
            { id: 'sansPlombage', label: 'بدون ترصيص', count: meters.filter(m => m.sansPlombage).length, color: 'text-rose-300' },
            { id: 'withLocation', label: 'مع موقع GPS', count: stats.withGps, color: 'text-blue-400' },
            { id: 'withoutLocation', label: 'بدون موقع', count: meters.length - stats.withGps, color: 'text-slate-400' },
          ].map(filter => (
            <button
              key={filter.id}
              onClick={() => setFilterStatus(filter.id as MeterFilterStatus)}
              className={`px-2.5 py-1 rounded-full text-xs font-medium transition-all ${
                filterStatus === filter.id
                  ? 'bg-orange-600 text-white shadow-md'
                  : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800'
              }`}
            >
              <span className={filter.color}>{filter.label}</span>
              <span className="mr-1 opacity-70 text-[10px]">({filter.count})</span>
            </button>
          ))}
        </div>

        {/* Selected rows batch actions & Horizontal Scroll controls */}
        <div className="flex items-center gap-2">
          {selectedIds.size > 0 && (
            <div className="flex items-center gap-2 bg-slate-900 border border-slate-700 px-2.5 py-1 rounded-lg">
              <span className="text-xs font-bold text-orange-400">
                {selectedIds.size} محدد
              </span>
              <button
                onClick={handleDeleteSelected}
                className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1 font-semibold"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>حذف المحدد</span>
              </button>
            </div>
          )}

          {/* Horizontal scroll helpers for wide tables */}
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg p-0.5">
            <button
              type="button"
              onClick={() => scrollTable('right')}
              className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800"
              title="تحريك الجدول لليمين"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <span className="text-[10px] text-slate-500 px-1">تمرير الجدول</span>
            <button
              type="button"
              onClick={() => scrollTable('left')}
              className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800"
              title="تحريك الجدول لليسار"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* 4. Main Interactive Data Table */}
      {(viewMode === 'table' || viewMode === 'split') && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl relative">
          {/* Scrollable Container with Sticky headers and pinned right columns */}
          <div 
            ref={tableContainerRef} 
            className="overflow-x-auto max-h-[680px] overflow-y-auto scrollbar-thin scrollbar-thumb-slate-700"
          >
            <table className="w-full text-right text-xs border-collapse">
              <thead className="bg-slate-950 text-slate-300 border-b border-slate-800 font-bold sticky top-0 z-20 shadow-sm">
                <tr>
                  {/* Select All Checkbox - Sticky Right */}
                  <th className="p-3 w-10 text-center sticky right-0 bg-slate-950 z-20 border-l border-slate-800/80">
                    <button
                      onClick={handleSelectAll}
                      className="text-slate-400 hover:text-white"
                      title="تحديد الكل"
                    >
                      {selectedIds.size > 0 && selectedIds.size === filteredMeters.length ? (
                        <CheckSquare className="w-4 h-4 text-orange-500" />
                      ) : (
                        <Square className="w-4 h-4" />
                      )}
                    </button>
                  </th>

                  {/* Row Number - Sticky */}
                  {visibleColumns.index && (
                    <th className="p-3 w-12 text-center sticky right-10 bg-slate-950 z-20 border-l border-slate-800/80">
                      #
                    </th>
                  )}

                  {/* GDA Column - Sortable & Sticky */}
                  {visibleColumns.gda && (
                    <th 
                      onClick={() => handleSort('gda')}
                      className="p-3 sticky right-22 bg-slate-950 z-20 border-l border-slate-800/80 cursor-pointer hover:text-orange-400 whitespace-nowrap"
                    >
                      <div className="flex items-center gap-1.5">
                        <span>رمز GDA</span>
                        {sortField === 'gda' && sortOrder === 'asc' && <ArrowUp className="w-3 h-3 text-orange-400" />}
                        {sortField === 'gda' && sortOrder === 'desc' && <ArrowDown className="w-3 h-3 text-orange-400" />}
                        {sortField !== 'gda' && <ArrowUpDown className="w-3 h-3 text-slate-600" />}
                      </div>
                    </th>
                  )}

                  {/* REF Column - Sortable */}
                  {visibleColumns.ref && (
                    <th 
                      onClick={() => handleSort('ref')}
                      className="p-3 cursor-pointer hover:text-orange-400 whitespace-nowrap"
                    >
                      <div className="flex items-center gap-1.5">
                        <span>المرجع (REF)</span>
                        {sortField === 'ref' && sortOrder === 'asc' && <ArrowUp className="w-3 h-3 text-orange-400" />}
                        {sortField === 'ref' && sortOrder === 'desc' && <ArrowDown className="w-3 h-3 text-orange-400" />}
                        {sortField !== 'ref' && <ArrowUpDown className="w-3 h-3 text-slate-600" />}
                      </div>
                    </th>
                  )}

                  {/* CTR Column */}
                  {visibleColumns.ctr && (
                    <th 
                      onClick={() => handleSort('ctr')}
                      className="p-3 cursor-pointer hover:text-orange-400 whitespace-nowrap"
                    >
                      <div className="flex items-center gap-1.5">
                        <span>رقم العقد (CTR)</span>
                        {sortField === 'ctr' && sortOrder === 'asc' && <ArrowUp className="w-3 h-3 text-orange-400" />}
                        {sortField === 'ctr' && sortOrder === 'desc' && <ArrowDown className="w-3 h-3 text-orange-400" />}
                      </div>
                    </th>
                  )}

                  {/* Previous Index */}
                  {visibleColumns.prevIndex && (
                    <th 
                      onClick={() => handleSort('index')}
                      className="p-3 cursor-pointer hover:text-orange-400 whitespace-nowrap"
                    >
                      <div className="flex items-center gap-1.5">
                        <span>المؤشر السابق</span>
                        {sortField === 'index' && sortOrder === 'asc' && <ArrowUp className="w-3 h-3 text-orange-400" />}
                        {sortField === 'index' && sortOrder === 'desc' && <ArrowDown className="w-3 h-3 text-orange-400" />}
                      </div>
                    </th>
                  )}

                  {/* New Index */}
                  {visibleColumns.nouvIndex && (
                    <th 
                      onClick={() => handleSort('nouvIndex')}
                      className="p-3 cursor-pointer hover:text-orange-400 whitespace-nowrap bg-emerald-950/20"
                    >
                      <div className="flex items-center gap-1.5 text-emerald-300">
                        <span>المؤشر الجديد (Nouv Index)</span>
                        {sortField === 'nouvIndex' && sortOrder === 'asc' && <ArrowUp className="w-3 h-3 text-emerald-400" />}
                        {sortField === 'nouvIndex' && sortOrder === 'desc' && <ArrowDown className="w-3 h-3 text-emerald-400" />}
                      </div>
                    </th>
                  )}

                  {/* COMPT (Meter Serial) */}
                  {visibleColumns.compt && (
                    <th 
                      onClick={() => handleSort('compt')}
                      className="p-3 cursor-pointer hover:text-orange-400 whitespace-nowrap"
                    >
                      <div className="flex items-center gap-1.5">
                        <span>رقم العداد (COMPT)</span>
                        {sortField === 'compt' && sortOrder === 'asc' && <ArrowUp className="w-3 h-3 text-orange-400" />}
                        {sortField === 'compt' && sortOrder === 'desc' && <ArrowDown className="w-3 h-3 text-orange-400" />}
                      </div>
                    </th>
                  )}

                  {/* Status Badges & Flags */}
                  {visibleColumns.status && (
                    <th className="p-3 whitespace-nowrap">
                      <span>حالة العداد (تعديل مباشر بالنقر)</span>
                    </th>
                  )}

                  {/* Location & GPS Navigation */}
                  {visibleColumns.location && (
                    <th className="p-3 whitespace-nowrap">
                      <span>الموقع والتوجيه عبر الخريطة GPS</span>
                    </th>
                  )}

                  {/* Observation & FI */}
                  {visibleColumns.observation && (
                    <th className="p-3 whitespace-nowrap">
                      <span>ملاحظات و N° FI</span>
                    </th>
                  )}

                  {/* Row Actions */}
                  {visibleColumns.actions && (
                    <th className="p-3 text-center whitespace-nowrap">
                      الإجراءات
                    </th>
                  )}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 text-slate-200">
                {filteredMeters.length === 0 ? (
                  <tr>
                    <td colSpan={12} className="p-10 text-center text-slate-400">
                      <div className="max-w-md mx-auto space-y-3">
                        <Gauge className="w-12 h-12 text-slate-600 mx-auto" />
                        <p className="text-sm font-bold text-slate-200">لا توجد عدادات مطابقة لمعايير البحث أو التصفية</p>
                        <p className="text-xs text-slate-400">يمكنك إضافة سطر جديد، أو استيراد جدول، أو إلغاء التصفية.</p>
                        <div className="flex justify-center gap-2 pt-2">
                          <button
                            onClick={handleQuickAddRow}
                            className="text-xs bg-orange-600 hover:bg-orange-500 text-white px-3 py-1.5 rounded-lg font-bold shadow"
                          >
                            + إضافة سطر الآن
                          </button>
                          <button
                            onClick={() => { setSearchTerm(''); setFilterStatus('all'); setSelectedGdaFilter('all'); }}
                            className="text-xs bg-slate-800 text-slate-300 hover:text-white px-3 py-1.5 rounded-lg"
                          >
                            إلغاء جميع عوامل التصفية
                          </button>
                        </div>
                      </div>
                    </td>
                  </tr>
                ) : (
                  filteredMeters.map((meter, index) => {
                    const isSelected = selectedIds.has(meter.id);
                    const isRowFocused = focusedRowIndex === index || selectedMeterId === meter.id;
                    const hasLocation = meter.latitude != null && meter.longitude != null && !isNaN(meter.latitude) && !isNaN(meter.longitude);
                    const googleMapsUrl = hasLocation
                      ? `https://www.google.com/maps/dir/?api=1&destination=${meter.latitude},${meter.longitude}`
                      : null;

                    // Compute consumption if both indices exist
                    const consumption = (meter.nouvIndex !== null && meter.index !== null)
                      ? meter.nouvIndex - meter.index
                      : null;

                    return (
                      <tr 
                        key={meter.id}
                        className={`hover:bg-slate-800/60 transition-colors group ${
                          isRowFocused ? 'bg-orange-950/40 ring-1 ring-orange-500/40' : index % 2 === 1 ? 'bg-slate-950/20' : ''
                        }`}
                        onClick={() => setFocusedRowIndex(index)}
                      >
                        {/* Checkbox - Sticky Right */}
                        <td className="p-2.5 text-center sticky right-0 bg-slate-900 group-hover:bg-slate-850 z-10 border-l border-slate-800/80">
                          <button
                            onClick={(e) => { e.stopPropagation(); handleToggleSelect(meter.id); }}
                            className="text-slate-400 hover:text-white"
                          >
                            {isSelected ? (
                              <CheckSquare className="w-4 h-4 text-orange-500" />
                            ) : (
                              <Square className="w-4 h-4" />
                            )}
                          </button>
                        </td>

                        {/* Row Index - Sticky */}
                        {visibleColumns.index && (
                          <td className="p-2.5 text-center font-mono text-slate-500 text-[11px] sticky right-10 bg-slate-900 group-hover:bg-slate-850 z-10 border-l border-slate-800/80">
                            {index + 1}
                          </td>
                        )}

                        {/* GDA Column - Sticky & Inline Editable */}
                        {visibleColumns.gda && (
                          <td 
                            className="p-2.5 font-mono font-bold text-orange-400 whitespace-nowrap sticky right-22 bg-slate-900 group-hover:bg-slate-850 z-10 border-l border-slate-800/80 cursor-pointer"
                            onDoubleClick={() => handleStartEdit(meter, 'gda')}
                            title="انقر مرتين لتعديل رمز GDA"
                          >
                            {editingCell?.id === meter.id && editingCell?.field === 'gda' ? (
                              <div className="flex items-center gap-1">
                                <input
                                  type="text"
                                  autoFocus
                                  value={cellEditValue}
                                  onChange={e => setCellEditValue(e.target.value)}
                                  onBlur={handleCommitEdit}
                                  className="w-24 bg-slate-950 border border-orange-500 rounded px-1.5 py-0.5 text-xs text-orange-300 font-mono focus:outline-none"
                                />
                                <button onMouseDown={handleCommitEdit} className="text-emerald-400 hover:text-emerald-300">
                                  <Check className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ) : (
                              <div className="flex items-center gap-1">
                                <span>{meter.gda || '—'}</span>
                                <Edit3 className="w-3 h-3 opacity-0 group-hover:opacity-40 text-slate-400" />
                              </div>
                            )}
                          </td>
                        )}

                        {/* REF Column - Inline Editable */}
                        {visibleColumns.ref && (
                          <td 
                            className="p-2.5 font-mono text-slate-200 whitespace-nowrap cursor-pointer hover:bg-slate-800/80"
                            onDoubleClick={() => handleStartEdit(meter, 'ref')}
                            title="انقر مرتين لتعديل رقم المرجع REF"
                          >
                            {editingCell?.id === meter.id && editingCell?.field === 'ref' ? (
                              <input
                                type="text"
                                autoFocus
                                value={cellEditValue}
                                onChange={e => setCellEditValue(e.target.value)}
                                onBlur={handleCommitEdit}
                                className="w-24 bg-slate-950 border border-orange-500 rounded px-1.5 py-0.5 text-xs text-white font-mono focus:outline-none"
                              />
                            ) : (
                              <div className="flex items-center gap-1">
                                <span>{meter.ref || '—'}</span>
                                <Edit3 className="w-3 h-3 opacity-0 group-hover:opacity-40 text-slate-400" />
                              </div>
                            )}
                          </td>
                        )}

                        {/* CTR Column - Inline Editable */}
                        {visibleColumns.ctr && (
                          <td 
                            className="p-2.5 font-mono text-slate-300 whitespace-nowrap cursor-pointer hover:bg-slate-800/80"
                            onDoubleClick={() => handleStartEdit(meter, 'ctr')}
                            title="انقر مرتين لتعديل رقم العقد CTR"
                          >
                            {editingCell?.id === meter.id && editingCell?.field === 'ctr' ? (
                              <input
                                type="text"
                                autoFocus
                                value={cellEditValue}
                                onChange={e => setCellEditValue(e.target.value)}
                                onBlur={handleCommitEdit}
                                className="w-28 bg-slate-950 border border-orange-500 rounded px-1.5 py-0.5 text-xs text-white font-mono focus:outline-none"
                              />
                            ) : (
                              <div className="flex items-center gap-1">
                                <span>{meter.ctr || '—'}</span>
                                <Edit3 className="w-3 h-3 opacity-0 group-hover:opacity-40 text-slate-400" />
                              </div>
                            )}
                          </td>
                        )}

                        {/* Previous Index - Inline Editable */}
                        {visibleColumns.prevIndex && (
                          <td 
                            className="p-2.5 font-mono text-slate-300 font-semibold whitespace-nowrap cursor-pointer hover:bg-slate-800/80"
                            onDoubleClick={() => handleStartEdit(meter, 'index')}
                            title="انقر مرتين لتعديل المؤشر السابق"
                          >
                            {editingCell?.id === meter.id && editingCell?.field === 'index' ? (
                              <input
                                type="number"
                                autoFocus
                                value={cellEditValue}
                                onChange={e => setCellEditValue(e.target.value)}
                                onBlur={handleCommitEdit}
                                className="w-20 bg-slate-950 border border-orange-500 rounded px-1.5 py-0.5 text-xs text-white font-mono focus:outline-none"
                              />
                            ) : (
                              <div className="flex items-center gap-1">
                                <span>{meter.index}</span>
                                <Edit3 className="w-3 h-3 opacity-0 group-hover:opacity-40 text-slate-400" />
                              </div>
                            )}
                          </td>
                        )}

                        {/* New Index - Inline Editable with Consumption Calculation */}
                        {visibleColumns.nouvIndex && (
                          <td 
                            className="p-2.5 font-mono whitespace-nowrap cursor-pointer hover:bg-slate-800/80 bg-emerald-950/10"
                            onDoubleClick={() => handleStartEdit(meter, 'nouvIndex')}
                            title="انقر مرتين لتعديل المؤشر الجديد"
                          >
                            {editingCell?.id === meter.id && editingCell?.field === 'nouvIndex' ? (
                              <div className="flex items-center gap-1">
                                <input
                                  type="number"
                                  autoFocus
                                  placeholder="جديد..."
                                  value={cellEditValue}
                                  onChange={e => setCellEditValue(e.target.value)}
                                  onBlur={handleCommitEdit}
                                  className="w-20 bg-slate-950 border border-emerald-500 rounded px-1.5 py-0.5 text-xs text-emerald-300 font-mono font-bold focus:outline-none"
                                />
                                <button onMouseDown={handleCommitEdit} className="text-emerald-400">
                                  <Check className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ) : meter.nouvIndex !== null ? (
                              <div className="flex items-center gap-1.5">
                                <span className="font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-700/60 px-2 py-0.5 rounded text-xs">
                                  {meter.nouvIndex}
                                </span>
                                {consumption !== null && (
                                  <span className={`text-[10px] font-mono px-1 rounded ${
                                    consumption >= 0 ? 'text-emerald-300 bg-emerald-950/40' : 'text-rose-400 bg-rose-950/40'
                                  }`}>
                                    (∆ {consumption})
                                  </span>
                                )}
                              </div>
                            ) : (
                              <button
                                onClick={() => handleStartEdit(meter, 'nouvIndex')}
                                className="text-[11px] text-slate-400 hover:text-emerald-400 font-medium px-2 py-0.5 rounded border border-dashed border-slate-700 hover:border-emerald-500"
                              >
                                + أدخل المؤشر
                              </button>
                            )}
                          </td>
                        )}

                        {/* COMPT (Meter Serial) - Inline Editable */}
                        {visibleColumns.compt && (
                          <td 
                            className="p-2.5 font-mono text-slate-300 text-[11px] whitespace-nowrap cursor-pointer hover:bg-slate-800/80"
                            onDoubleClick={() => handleStartEdit(meter, 'compt')}
                            title="انقر مرتين لتعديل رقم العداد"
                          >
                            {editingCell?.id === meter.id && editingCell?.field === 'compt' ? (
                              <input
                                type="text"
                                autoFocus
                                value={cellEditValue}
                                onChange={e => setCellEditValue(e.target.value)}
                                onBlur={handleCommitEdit}
                                className="w-28 bg-slate-950 border border-orange-500 rounded px-1.5 py-0.5 text-xs text-white font-mono focus:outline-none"
                              />
                            ) : (
                              <div className="flex items-center gap-1">
                                <span>{meter.compt || '—'}</span>
                                <Edit3 className="w-3 h-3 opacity-0 group-hover:opacity-40 text-slate-400" />
                              </div>
                            )}
                          </td>
                        )}

                        {/* Status Badges with 1-Click Toggle */}
                        {visibleColumns.status && (
                          <td className="p-2.5">
                            <div className="flex flex-wrap items-center gap-1">
                              {/* Saisie Toggle */}
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onUpdateMeterInline(meter.id, {
                                    saisie: !meter.saisie,
                                    nonSaisie: meter.saisie,
                                    dateReleve: !meter.saisie ? new Date().toISOString().substring(0, 16).replace('T', ' ') : null
                                  });
                                  showSaveNotice(meter.saisie ? 'تم إلغاء رفع العداد' : 'تم تأكيد رفع العداد');
                                }}
                                className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold transition-all ${
                                  meter.saisie
                                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
                                    : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                                }`}
                                title="انقر للتبديل بين تم الرفع وغير مسجل"
                              >
                                <CheckCircle2 className="w-3 h-3" />
                                <span>{meter.saisie ? 'تم الرفع' : 'غير مسجل'}</span>
                              </button>

                              {/* Bloqué Toggle */}
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onUpdateMeterInline(meter.id, { bloque: !meter.bloque });
                                  showSaveNotice(meter.bloque ? 'تم إلغاء حالة العطل' : 'تم وسم العداد كـ معطل');
                                }}
                                className={`inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] font-bold transition-all ${
                                  meter.bloque
                                    ? 'bg-rose-500/30 text-rose-300 border border-rose-500/50'
                                    : 'bg-slate-800/60 text-slate-500 hover:text-slate-300'
                                }`}
                                title="عداد متوقف / معطل (Bloqué)"
                              >
                                <AlertTriangle className="w-2.5 h-2.5" />
                                <span>معطل</span>
                              </button>

                              {/* Client Absent Toggle */}
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onUpdateMeterInline(meter.id, { clientAbsent: !meter.clientAbsent });
                                }}
                                className={`inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] transition-all ${
                                  meter.clientAbsent
                                    ? 'bg-amber-500/30 text-amber-300 border border-amber-500/50'
                                    : 'bg-slate-800/60 text-slate-500 hover:text-slate-300'
                                }`}
                                title="حريف غائب / باب مقفل"
                              >
                                <UserX className="w-2.5 h-2.5" />
                                <span>غائب</span>
                              </button>

                              {/* Hublot Taps (Broken glass) */}
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onUpdateMeterInline(meter.id, { hublotTaps: !meter.hublotTaps });
                                }}
                                className={`px-1.5 py-0.5 rounded text-[10px] transition-all ${
                                  meter.hublotTaps
                                    ? 'bg-purple-500/30 text-purple-300 border border-purple-500/50 font-bold'
                                    : 'bg-slate-800/60 text-slate-500 hover:text-slate-300'
                                }`}
                                title="كسر في زجاج العداد (Hublot)"
                              >
                                زجاج
                              </button>

                              {/* Sans plombage (Unsealed) */}
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onUpdateMeterInline(meter.id, { sansPlombage: !meter.sansPlombage });
                                }}
                                className={`px-1.5 py-0.5 rounded text-[10px] transition-all ${
                                  meter.sansPlombage
                                    ? 'bg-rose-600/30 text-rose-300 border border-rose-500/50 font-bold'
                                    : 'bg-slate-800/60 text-slate-500 hover:text-slate-300'
                                }`}
                                title="عداد بدون ترصيص (Sans plombage)"
                              >
                                ترصيص
                              </button>

                              {/* Verification Needed */}
                              {meter.necessiteVerification && (
                                <span className="bg-orange-500/20 text-orange-300 px-1.5 py-0.5 rounded text-[10px] font-bold">
                                  تدقيق
                                </span>
                              )}
                            </div>
                          </td>
                        )}

                        {/* Location & GPS Navigation Actions */}
                        {visibleColumns.location && (
                          <td className="p-2.5">
                            {hasLocation ? (
                              <div className="space-y-1">
                                {meter.address && (
                                  <div 
                                    className="text-[11px] text-slate-300 truncate max-w-[170px] cursor-pointer hover:text-orange-300" 
                                    title={meter.address}
                                    onDoubleClick={() => handleStartEdit(meter, 'address')}
                                  >
                                    {editingCell?.id === meter.id && editingCell?.field === 'address' ? (
                                      <input
                                        type="text"
                                        autoFocus
                                        value={cellEditValue}
                                        onChange={e => setCellEditValue(e.target.value)}
                                        onBlur={handleCommitEdit}
                                        className="w-full bg-slate-950 border border-orange-500 rounded px-1 py-0.5 text-xs text-white"
                                      />
                                    ) : (
                                      <span>📍 {meter.address}</span>
                                    )}
                                  </div>
                                )}
                                <div className="flex items-center gap-1.5">
                                  {/* Direct Google Maps Navigation Button */}
                                  <a
                                    href={googleMapsUrl!}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="inline-flex items-center gap-1 bg-blue-600/30 hover:bg-blue-600 text-blue-300 hover:text-white border border-blue-500/40 px-2 py-0.5 rounded text-[10px] font-bold transition-all shadow-sm"
                                    title="بدء التوجيه المباشر في خرائط جوجل GPS"
                                  >
                                    <Navigation className="w-3 h-3" />
                                    <span>توجيه GPS</span>
                                    <ExternalLink className="w-2.5 h-2.5 opacity-70" />
                                  </a>

                                  {/* Pan to meter on interactive map */}
                                  <button
                                    onClick={(e) => { e.stopPropagation(); onSelectOnMap(meter.id); }}
                                    className="text-[10px] text-slate-400 hover:text-slate-100 p-1 rounded hover:bg-slate-800"
                                    title="عرض وتكبير في الخريطة"
                                  >
                                    <Map className="w-3.5 h-3.5" />
                                  </button>

                                  {/* Edit Location coordinates modal */}
                                  <button
                                    onClick={(e) => { e.stopPropagation(); onOpenLocationPicker(meter); }}
                                    className="text-[10px] text-slate-400 hover:text-orange-400 p-1 rounded hover:bg-slate-800"
                                    title="تعديل الإحداثيات على الخريطة"
                                  >
                                    <Edit3 className="w-3 h-3" />
                                  </button>
                                </div>
                              </div>
                            ) : (
                              <div className="flex items-center gap-1.5">
                                <button
                                  onClick={(e) => { e.stopPropagation(); onOpenLocationPicker(meter); }}
                                  className="text-[11px] text-amber-400 hover:text-amber-300 flex items-center gap-1 px-2 py-0.5 rounded bg-amber-950/30 border border-amber-800/40 font-semibold transition-colors"
                                  title="فتح الخريطة وتحديد موقع العداد"
                                >
                                  <MapPin className="w-3 h-3" />
                                  <span>+ تحديد موقع</span>
                                </button>

                                <button
                                  onClick={(e) => { e.stopPropagation(); handleCaptureCurrentGps(meter); }}
                                  className="text-[10px] text-blue-400 hover:text-blue-300 p-1 rounded hover:bg-blue-950/40"
                                  title="التقاط موقعي الحالي للجهاز GPS وتثبيته لهذا العداد"
                                >
                                  <Locate className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            )}
                          </td>
                        )}

                        {/* Observation & FI - Inline Editable */}
                        {visibleColumns.observation && (
                          <td 
                            className="p-2.5 text-[11px] text-slate-300 max-w-[150px] truncate cursor-pointer hover:bg-slate-800/80"
                            onDoubleClick={() => handleStartEdit(meter, 'observation')}
                            title={meter.observation ? `ملاحظة: ${meter.observation}` : 'انقر مرتين لإضافة ملاحظة'}
                          >
                            {editingCell?.id === meter.id && editingCell?.field === 'observation' ? (
                              <input
                                type="text"
                                autoFocus
                                value={cellEditValue}
                                onChange={e => setCellEditValue(e.target.value)}
                                onBlur={handleCommitEdit}
                                placeholder="ملاحظة..."
                                className="w-full bg-slate-950 border border-orange-500 rounded px-1.5 py-0.5 text-xs text-white"
                              />
                            ) : (
                              <div className="flex items-center gap-1">
                                {meter.numFI && (
                                  <span className="font-mono text-[10px] bg-slate-800 text-slate-400 px-1 rounded">
                                    {meter.numFI}
                                  </span>
                                )}
                                <span>{meter.observation || '—'}</span>
                                <Edit3 className="w-2.5 h-2.5 opacity-0 group-hover:opacity-40 text-slate-400" />
                              </div>
                            )}
                          </td>
                        )}

                        {/* Action Buttons */}
                        {visibleColumns.actions && (
                          <td className="p-2.5 text-center whitespace-nowrap">
                            <div className="flex items-center justify-center gap-1">
                              {/* Quick Record Modal */}
                              <button
                                onClick={(e) => { e.stopPropagation(); onQuickRecord(meter); }}
                                className="p-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600 text-emerald-300 hover:text-white transition-colors"
                                title="تسجيل المؤشر السريع"
                              >
                                <Gauge className="w-3.5 h-3.5" />
                              </button>

                              {/* Duplicate Row */}
                              <button
                                onClick={(e) => { e.stopPropagation(); onDuplicateMeter(meter); showSaveNotice('تم نسخ وتكرار السطر'); }}
                                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                                title="تكرار ونسخ هذا السطر"
                              >
                                <Copy className="w-3.5 h-3.5" />
                              </button>

                              {/* Full Edit Modal */}
                              <button
                                onClick={(e) => { e.stopPropagation(); onEditMeter(meter); }}
                                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                                title="تعديل العداد بالكامل"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>

                              {/* Delete Row */}
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (window.confirm(`هل أنت متأكد من حذف العداد ${meter.gda}؟`)) {
                                    onDeleteMeter(meter.id);
                                    showSaveNotice('تم حذف العداد');
                                  }
                                }}
                                className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-900/60 text-slate-400 hover:text-rose-300 transition-colors"
                                title="حذف"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        )}
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* Quick Add Row & Table Footer Info Bar */}
          <div className="p-3 bg-slate-950 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
            <div className="flex items-center gap-3">
              <button
                onClick={handleQuickAddRow}
                className="flex items-center gap-1 text-orange-400 hover:text-orange-300 font-bold px-2 py-1 rounded hover:bg-orange-950/30 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ إضافة سطر في نهاية الجدول</span>
              </button>
              <span>•</span>
              <div>
                عرض <b className="text-slate-200">{filteredMeters.length}</b> من أصل <b className="text-slate-200">{meters.length}</b> عداد
              </div>
            </div>

            <div className="flex items-center gap-4 text-[11px]">
              <span className="hidden sm:inline">نصيحة: انقر مرتين على أي خانة لتعديلها مباشرة أو استخدم الأسهم ومفتاح Enter</span>
              <div className="flex items-center gap-3 font-mono">
                <span>مسجل: <b className="text-emerald-400">{stats.saisis}</b></span>
                <span>معلق: <b className="text-slate-200">{stats.nonSaisis}</b></span>
                <span>معطل: <b className="text-rose-400">{stats.bloques}</b></span>
                <span>غائب: <b className="text-amber-400">{stats.absents}</b></span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
