import React, { useState } from 'react';
import { 
  X, 
  FileSpreadsheet, 
  Download, 
  Printer, 
  FileText, 
  Check, 
  Filter
} from 'lucide-react';
import { MeterRecord } from '../../types/meter';
import { exportMetersToExcel, exportMetersToCSV } from '../../utils/meterExcel';

interface MeterExportModalProps {
  isOpen: boolean;
  meters: MeterRecord[];
  onClose: () => void;
}

export const MeterExportModal: React.FC<MeterExportModalProps> = ({
  isOpen,
  meters,
  onClose
}) => {
  const [exportScope, setExportScope] = useState<'all' | 'saisie' | 'nonSaisie' | 'anomalies'>('all');
  const [fileName, setFileName] = useState<string>(`Tournee_Gaz_${new Date().toISOString().substring(0, 10)}`);

  if (!isOpen) return null;

  const getFilteredMeters = () => {
    switch (exportScope) {
      case 'saisie':
        return meters.filter(m => m.saisie);
      case 'nonSaisie':
        return meters.filter(m => !m.saisie);
      case 'anomalies':
        return meters.filter(m => m.bloque || m.clientAbsent || m.hublotTaps || m.sansPlombage || m.necessiteVerification);
      case 'all':
      default:
        return meters;
    }
  };

  const recordsToExport = getFilteredMeters();

  const handleExportXLSX = () => {
    exportMetersToExcel(recordsToExport, `${fileName}.xlsx`);
  };

  const handleExportCSV = () => {
    exportMetersToCSV(recordsToExport, `${fileName}.csv`);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm overflow-y-auto">
      <div 
        className="bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl w-full max-w-lg text-slate-100 overflow-hidden my-6"
        dir="rtl"
      >
        {/* Header */}
        <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100">
                تصدير وتحميل جدول العدادات (Excel)
              </h2>
              <p className="text-xs text-slate-400">
                تنزيل الملف بصيغة Excel أو CSV متوافقة مع جداول الشركة
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4">
          {/* File Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              اسم الملف المصدّر:
            </label>
            <input
              type="text"
              value={fileName}
              onChange={e => setFileName(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Scope Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5 text-orange-400" />
              <span>البيانات المراد تصديرها:</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setExportScope('all')}
                className={`p-2.5 rounded-lg border text-xs text-right transition-colors ${
                  exportScope === 'all'
                    ? 'border-emerald-500 bg-emerald-950/40 text-emerald-200'
                    : 'border-slate-800 bg-slate-800/40 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <div className="font-bold">جميع العدادات</div>
                <div className="text-[10px] text-slate-400">{meters.length} سطر</div>
              </button>

              <button
                type="button"
                onClick={() => setExportScope('saisie')}
                className={`p-2.5 rounded-lg border text-xs text-right transition-colors ${
                  exportScope === 'saisie'
                    ? 'border-emerald-500 bg-emerald-950/40 text-emerald-200'
                    : 'border-slate-800 bg-slate-800/40 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <div className="font-bold">المسجلة فقط (Saisie)</div>
                <div className="text-[10px] text-slate-400">{meters.filter(m => m.saisie).length} سطر</div>
              </button>

              <button
                type="button"
                onClick={() => setExportScope('nonSaisie')}
                className={`p-2.5 rounded-lg border text-xs text-right transition-colors ${
                  exportScope === 'nonSaisie'
                    ? 'border-emerald-500 bg-emerald-950/40 text-emerald-200'
                    : 'border-slate-800 bg-slate-800/40 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <div className="font-bold">المعلقة غير المسجلة</div>
                <div className="text-[10px] text-slate-400">{meters.filter(m => !m.saisie).length} سطر</div>
              </button>

              <button
                type="button"
                onClick={() => setExportScope('anomalies')}
                className={`p-2.5 rounded-lg border text-xs text-right transition-colors ${
                  exportScope === 'anomalies'
                    ? 'border-emerald-500 bg-emerald-950/40 text-emerald-200'
                    : 'border-slate-800 bg-slate-800/40 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <div className="font-bold">المعطلة والغياب والعيوب</div>
                <div className="text-[10px] text-slate-400">
                  {meters.filter(m => m.bloque || m.clientAbsent || m.hublotTaps || m.sansPlombage || m.necessiteVerification).length} سطر
                </div>
              </button>
            </div>
          </div>

          {/* Export Options Buttons */}
          <div className="space-y-2.5 pt-2">
            <button
              onClick={handleExportXLSX}
              className="w-full flex items-center justify-between p-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs shadow-lg transition-all"
            >
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5" />
                <div className="text-right">
                  <div>تحميل كملف Microsoft Excel (.xlsx)</div>
                  <div className="text-[10px] font-normal opacity-85">يتضمن جميع الأعمدة وتنسيق احترافي جاهز للفتح والتعديل</div>
                </div>
              </div>
              <Download className="w-4 h-4" />
            </button>

            <button
              onClick={handleExportCSV}
              className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition-colors"
            >
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-amber-400" />
                <div className="text-right">
                  <div>تحميل كملف CSV مفصول بفاصلة منقوطة (;)</div>
                  <div className="text-[10px] font-normal text-slate-400">المطابق تماماً لصيغة جدول الشركة (STEG / Tournée)</div>
                </div>
              </div>
              <Download className="w-4 h-4" />
            </button>

            <button
              onClick={handlePrint}
              className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-300 font-bold text-xs border border-slate-700/60 transition-colors"
            >
              <div className="flex items-center gap-2">
                <Printer className="w-5 h-5 text-blue-400" />
                <div className="text-right">
                  <div>طباعة ورقة الجولة الميدانية (Bordereau)</div>
                  <div className="text-[10px] font-normal text-slate-400">طباعة A4 للمراقب الميداني</div>
                </div>
              </div>
              <Printer className="w-4 h-4 opacity-70" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
