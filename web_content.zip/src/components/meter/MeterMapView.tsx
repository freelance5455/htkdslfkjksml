import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { 
  Navigation, 
  MapPin, 
  Locate, 
  Layers, 
  CheckCircle2, 
  AlertTriangle, 
  UserX, 
  ShieldAlert, 
  ExternalLink,
  ChevronRight,
  Route,
  Info
} from 'lucide-react';
import { MeterRecord } from '../../types/meter';

interface MeterMapViewProps {
  meters: MeterRecord[];
  selectedMeterId: string | null;
  onSelectMeter: (id: string) => void;
  onUpdateMeterLocation: (id: string, lat: number, lng: number) => void;
  onEditMeter?: (meter: MeterRecord) => void;
}

export const MeterMapView: React.FC<MeterMapViewProps> = ({
  meters,
  selectedMeterId,
  onSelectMeter,
  onUpdateMeterLocation,
  onEditMeter
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markersRef = useRef<Record<string, L.Marker>>({});
  const routeLayerRef = useRef<L.Polyline | null>(null);
  const userMarkerRef = useRef<L.Marker | null>(null);

  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [assigningLocationForId, setAssigningLocationForId] = useState<string | null>(null);
  const [mapLayerType, setMapLayerType] = useState<'streets' | 'satellite'>('streets');
  const [tileLayerRef, setTileLayerRef] = useState<L.TileLayer | null>(null);

  // Filter meters that have valid coordinates
  const metersWithGps = meters.filter(
    m => m.latitude != null && m.longitude != null && !isNaN(m.latitude) && !isNaN(m.longitude)
  );

  const unpositionedMeters = meters.filter(
    m => m.latitude == null || m.longitude == null || isNaN(m.latitude) || isNaN(m.longitude)
  );

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapRef.current) {
      // Default center: Tunis / Northern Africa coordinates or first meter
      const defaultCenter: [number, number] = metersWithGps.length > 0 
        ? [metersWithGps[0].latitude!, metersWithGps[0].longitude!]
        : [36.8065, 10.1815];

      const map = L.map(mapContainerRef.current, {
        center: defaultCenter,
        zoom: 14,
        zoomControl: true,
      });

      const osmTile = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
        maxZoom: 19,
      }).addTo(map);

      setTileLayerRef(osmTile);
      mapRef.current = map;

      // Handle click on map for assigning location
      map.on('click', (e: L.LeafletMouseEvent) => {
        if (assigningLocationForId) {
          onUpdateMeterLocation(assigningLocationForId, e.latlng.lat, e.latlng.lng);
          setAssigningLocationForId(null);
        }
      });
    }

    return () => {
      // Cleanup on unmount
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, []);

  // Update Tile Layer when switching streets / satellite
  useEffect(() => {
    if (!mapRef.current || !tileLayerRef) return;
    mapRef.current.removeLayer(tileLayerRef);

    let newLayer: L.TileLayer;
    if (mapLayerType === 'satellite') {
      newLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: '&copy; Esri World Imagery',
        maxZoom: 18,
      });
    } else {
      newLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
        maxZoom: 19,
      });
    }

    newLayer.addTo(mapRef.current);
    setTileLayerRef(newLayer);
  }, [mapLayerType]);

  // Request current user GPS location
  const handleLocateUser = () => {
    if (!navigator.geolocation) {
      setLocationError('تحديد الموقع غير مدعوم في هذا المتصفح');
      return;
    }

    setIsLocating(true);
    setLocationError(null);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        setUserLocation({ lat: latitude, lng: longitude });
        setIsLocating(false);

        if (mapRef.current) {
          // Add or update user marker
          if (userMarkerRef.current) {
            userMarkerRef.current.setLatLng([latitude, longitude]);
          } else {
            const userIcon = L.divIcon({
              className: 'user-pulse-marker',
              html: `<div class="relative flex items-center justify-center">
                <span class="animate-ping absolute inline-flex h-6 w-6 rounded-full bg-blue-400 opacity-75"></span>
                <span class="relative inline-flex rounded-full h-4 w-4 bg-blue-600 border-2 border-white shadow-lg"></span>
              </div>`,
              iconSize: [24, 24],
              iconAnchor: [12, 12]
            });

            userMarkerRef.current = L.marker([latitude, longitude], { icon: userIcon, zIndexOffset: 1000 })
              .addTo(mapRef.current)
              .bindPopup('<b>موقعك الحالي (المراقب)</b>');
          }

          mapRef.current.flyTo([latitude, longitude], 15);
        }
      },
      (err) => {
        setIsLocating(false);
        setLocationError(`تعذر تحديد الموقع: ${err.message}`);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  // Helper to create marker icon based on meter status
  const getMarkerIcon = (meter: MeterRecord, isSelected: boolean) => {
    let bgColor = 'bg-slate-500';
    let borderColor = 'border-white';
    let label = meter.nouvIndex !== null ? `${meter.nouvIndex}` : meter.index ? `${meter.index}` : '—';

    if (meter.bloque) {
      bgColor = 'bg-rose-600';
    } else if (meter.clientAbsent) {
      bgColor = 'bg-amber-500';
    } else if (meter.hublotTaps || meter.sansPlombage || meter.necessiteVerification) {
      bgColor = 'bg-purple-600';
    } else if (meter.saisie) {
      bgColor = 'bg-emerald-600';
    }

    const ring = isSelected ? 'ring-4 ring-orange-400 scale-125 z-50' : 'hover:scale-110';

    return L.divIcon({
      className: 'custom-meter-marker',
      html: `
        <div class="relative transition-transform flex items-center justify-center ${ring}">
          <div class="${bgColor} ${borderColor} border-2 text-white font-bold text-xs rounded-full px-2 py-0.5 shadow-md flex items-center gap-1">
            <span>${meter.gda || 'G'}</span>
            <span class="text-[10px] opacity-90">(${label})</span>
          </div>
          <div class="w-2 h-2 ${bgColor} rotate-45 -mt-1 mx-auto"></div>
        </div>
      `,
      iconSize: [80, 32],
      iconAnchor: [40, 32]
    });
  };

  // Update meter markers whenever meters or selectedMeterId changes
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    // Clear old markers
    Object.values(markersRef.current).forEach(m => map.removeLayer(m));
    markersRef.current = {};

    const bounds = L.latLngBounds([]);

    metersWithGps.forEach(meter => {
      const isSelected = meter.id === selectedMeterId;
      const marker = L.marker([meter.latitude!, meter.longitude!], {
        icon: getMarkerIcon(meter, isSelected),
        draggable: assigningLocationForId === meter.id
      }).addTo(map);

      // On Drag end
      marker.on('dragend', (e) => {
        const newPos = (e.target as L.Marker).getLatLng();
        onUpdateMeterLocation(meter.id, newPos.lat, newPos.lng);
      });

      // Marker Popup Content
      const googleMapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${meter.latitude},${meter.longitude}`;
      
      const popupHtml = `
        <div class="p-2 text-slate-900 font-['Cairo',sans-serif] text-right" dir="rtl">
          <div class="flex items-center justify-between border-b pb-1 mb-2">
            <span class="font-bold text-sm text-slate-800">${meter.gda}</span>
            <span class="text-xs px-2 py-0.5 rounded ${
              meter.saisie ? 'bg-emerald-100 text-emerald-800 font-semibold' : 'bg-slate-100 text-slate-700'
            }">${meter.saisie ? 'تم التسجيل' : 'غير مسجل'}</span>
          </div>
          
          <div class="text-xs space-y-1 mb-2 text-slate-600">
            <div><b class="text-slate-700">المرجع (REF):</b> ${meter.ref || '—'}</div>
            <div><b class="text-slate-700">العداد:</b> ${meter.compt || '—'}</div>
            <div><b class="text-slate-700">المؤشر الحالي:</b> <span class="font-mono font-bold text-slate-900">${meter.nouvIndex !== null ? meter.nouvIndex : meter.index}</span></div>
            ${meter.address ? `<div><b class="text-slate-700">العنوان:</b> ${meter.address}</div>` : ''}
            ${meter.clientName ? `<div><b class="text-slate-700">الحريف:</b> ${meter.clientName}</div>` : ''}
            ${meter.observation ? `<div class="bg-amber-50 p-1 rounded text-amber-900"><b class="text-amber-800">ملاحظة:</b> ${meter.observation}</div>` : ''}
          </div>

          <div class="pt-2 flex flex-col gap-1.5 border-t">
            <a 
              href="${googleMapsUrl}" 
              target="_blank" 
              rel="noopener noreferrer" 
              class="w-full text-center bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs py-1.5 px-3 rounded shadow inline-flex items-center justify-center gap-1.5"
            >
              <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="3 11 22 2 13 21 11 13 3 11"></polygon></svg>
              بدء التوجيه المباشر (Google Maps)
            </a>
          </div>
        </div>
      `;

      marker.bindPopup(popupHtml);

      marker.on('click', () => {
        onSelectMeter(meter.id);
      });

      markersRef.current[meter.id] = marker;
      bounds.extend([meter.latitude!, meter.longitude!]);
    });

    // Draw route path between markers
    if (routeLayerRef.current) {
      map.removeLayer(routeLayerRef.current);
      routeLayerRef.current = null;
    }

    if (metersWithGps.length > 1) {
      const latlngs = metersWithGps.map(m => [m.latitude!, m.longitude!] as [number, number]);
      routeLayerRef.current = L.polyline(latlngs, {
        color: '#f97316',
        weight: 3,
        opacity: 0.7,
        dashArray: '6, 8',
      }).addTo(map);
    }

    // If selected meter exists, open popup and pan to it
    if (selectedMeterId && markersRef.current[selectedMeterId]) {
      const selectedMarker = markersRef.current[selectedMeterId];
      selectedMarker.openPopup();
      map.panTo(selectedMarker.getLatLng());
    } else if (metersWithGps.length > 0 && !selectedMeterId) {
      map.fitBounds(bounds, { padding: [50, 50], maxZoom: 16 });
    }
  }, [meters, selectedMeterId, assigningLocationForId]);

  // Calculate distance between two lat/lng points in meters
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371e3; // Earth radius in metres
    const φ1 = (lat1 * Math.PI) / 180;
    const φ2 = (lat2 * Math.PI) / 180;
    const Δφ = ((lat2 - lat1) * Math.PI) / 180;
    const Δλ = ((lon2 - lon1) * Math.PI) / 180;

    const a =
      Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
      Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return Math.round(R * c); // in meters
  };

  const selectedMeter = meters.find(m => m.id === selectedMeterId);

  return (
    <div className="relative w-full h-[600px] lg:h-[720px] rounded-xl overflow-hidden border border-slate-700/80 shadow-2xl flex flex-col md:flex-row bg-slate-900 text-slate-100">
      {/* Map Main Canvas */}
      <div className="relative flex-1 h-full">
        <div ref={mapContainerRef} className="w-full h-full z-0" />

        {/* Map Top Floating Controls */}
        <div className="absolute top-3 right-3 z-10 flex flex-wrap gap-2 items-center bg-slate-900/90 backdrop-blur-md p-1.5 rounded-lg border border-slate-700 shadow-lg text-xs">
          <button
            onClick={() => setMapLayerType(mapLayerType === 'streets' ? 'satellite' : 'streets')}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600 transition-colors"
            title="تبديل الخريطة / القمر الصناعي"
          >
            <Layers className="w-3.5 h-3.5 text-orange-400" />
            <span>{mapLayerType === 'streets' ? 'قمر صناعي' : 'خريطة شوارع'}</span>
          </button>

          <button
            onClick={handleLocateUser}
            disabled={isLocating}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded bg-blue-600 hover:bg-blue-500 text-white font-medium transition-colors shadow"
            title="تحديد موقعي المباشر"
          >
            <Locate className={`w-3.5 h-3.5 ${isLocating ? 'animate-spin' : ''}`} />
            <span>{isLocating ? 'جارِ التحديد...' : 'موقعي المباشر'}</span>
          </button>

          {metersWithGps.length > 0 && (
            <button
              onClick={() => {
                if (mapRef.current && metersWithGps.length > 0) {
                  const bounds = L.latLngBounds(metersWithGps.map(m => [m.latitude!, m.longitude!]));
                  mapRef.current.fitBounds(bounds, { padding: [40, 40] });
                }
              }}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600 transition-colors"
              title="رؤية جميع العدادات"
            >
              <Route className="w-3.5 h-3.5 text-emerald-400" />
              <span>عرض المسار الكامل ({metersWithGps.length})</span>
            </button>
          )}
        </div>

        {/* Location mode notification banner */}
        {assigningLocationForId && (
          <div className="absolute top-16 left-1/2 -translate-x-1/2 z-20 bg-amber-500 text-slate-950 font-bold px-4 py-2 rounded-full shadow-2xl flex items-center gap-2 text-xs border border-amber-300 animate-bounce">
            <MapPin className="w-4 h-4" />
            <span>انقر على الخريطة لتثبيت موقع العداد المحدد</span>
            <button 
              onClick={() => setAssigningLocationForId(null)} 
              className="ml-2 bg-slate-900 text-white px-2 py-0.5 rounded text-[11px] hover:bg-slate-800"
            >
              إلغاء
            </button>
          </div>
        )}

        {locationError && (
          <div className="absolute top-16 left-3 z-10 bg-rose-900/90 text-rose-100 text-xs px-3 py-1.5 rounded border border-rose-700 shadow flex items-center gap-2">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>{locationError}</span>
          </div>
        )}

        {/* Bottom Legend */}
        <div className="absolute bottom-3 right-3 z-10 bg-slate-900/90 backdrop-blur-md px-3 py-2 rounded-lg border border-slate-700 shadow-md text-[11px] flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
            <span className="text-slate-300">تم التسجيل</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-400"></span>
            <span className="text-slate-300">غير مسجل</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
            <span className="text-slate-300">معطل / متوقف</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
            <span className="text-slate-300">حريف غائب</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-purple-500"></span>
            <span className="text-slate-300">خلل / تحقق</span>
          </div>
        </div>
      </div>

      {/* Sidebar: Selected meter details & tour list */}
      <div className="w-full md:w-80 lg:w-96 bg-slate-900/95 border-t md:border-t-0 md:border-r border-slate-800 flex flex-col h-72 md:h-full z-10">
        {/* Header */}
        <div className="p-3 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2">
            <Navigation className="w-4 h-4 text-orange-400" />
            <h3 className="font-bold text-sm text-slate-100">مسار الجولة والتوجيه</h3>
          </div>
          <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-400">
            {metersWithGps.length} من {meters.length} محددة جغرافياً
          </span>
        </div>

        {/* Details for Selected Meter */}
        {selectedMeter ? (
          <div className="p-3.5 bg-slate-800/60 border-b border-slate-700/80">
            <div className="flex items-center justify-between mb-2">
              <div>
                <span className="font-bold text-base text-orange-400 font-mono">{selectedMeter.gda}</span>
                <p className="text-xs text-slate-400">{selectedMeter.compt || 'بدون رقم عداد'}</p>
              </div>
              <span className={`text-[11px] px-2 py-0.5 rounded font-medium ${
                selectedMeter.saisie ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-slate-700 text-slate-300'
              }`}>
                {selectedMeter.saisie ? '✓ تم الرفع' : '⏳ معلق'}
              </span>
            </div>

            <div className="text-xs space-y-1 text-slate-300 mb-3 bg-slate-900/70 p-2.5 rounded-lg border border-slate-800">
              <div className="flex justify-between">
                <span className="text-slate-400">المرجع (REF):</span>
                <span className="font-mono text-slate-200">{selectedMeter.ref}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">العقد (CTR):</span>
                <span className="font-mono text-slate-200">{selectedMeter.ctr}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">المؤشر السابق:</span>
                <span className="font-mono text-slate-200">{selectedMeter.index}</span>
              </div>
              {selectedMeter.nouvIndex !== null && (
                <div className="flex justify-between text-emerald-400 font-bold">
                  <span>المؤشر الجديد المسجل:</span>
                  <span className="font-mono text-sm">{selectedMeter.nouvIndex}</span>
                </div>
              )}
              {selectedMeter.address && (
                <div className="pt-1 text-slate-300">
                  <span className="text-slate-400 block text-[10px]">العنوان:</span>
                  <span>{selectedMeter.address}</span>
                </div>
              )}
              {userLocation && selectedMeter.latitude && selectedMeter.longitude && (
                <div className="pt-1 flex justify-between text-blue-400 font-semibold text-[11px]">
                  <span>المسافة عن موقعك:</span>
                  <span>
                    {calculateDistance(
                      userLocation.lat,
                      userLocation.lng,
                      selectedMeter.latitude,
                      selectedMeter.longitude
                    ) > 1000
                      ? `${(calculateDistance(userLocation.lat, userLocation.lng, selectedMeter.latitude, selectedMeter.longitude) / 1000).toFixed(1)} كم`
                      : `${calculateDistance(userLocation.lat, userLocation.lng, selectedMeter.latitude, selectedMeter.longitude)} متر`}
                  </span>
                </div>
              )}
            </div>

            {/* Action Buttons for selected meter */}
            <div className="flex flex-col gap-2">
              {selectedMeter.latitude && selectedMeter.longitude ? (
                <a
                  href={`https://www.google.com/maps/dir/?api=1&destination=${selectedMeter.latitude},${selectedMeter.longitude}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs py-2 rounded-lg shadow-lg transition-all"
                >
                  <Navigation className="w-4 h-4" />
                  <span>توجيه مباشر GPS (خرائط جوجل)</span>
                  <ExternalLink className="w-3 h-3 opacity-70" />
                </a>
              ) : (
                <button
                  onClick={() => setAssigningLocationForId(selectedMeter.id)}
                  className="w-full flex items-center justify-center gap-2 bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs py-2 rounded-lg shadow transition-colors"
                >
                  <MapPin className="w-4 h-4" />
                  <span>تحديد موقع هذا العداد على الخريطة</span>
                </button>
              )}

              {onEditMeter && (
                <button
                  onClick={() => onEditMeter(selectedMeter)}
                  className="w-full text-center text-xs text-slate-300 hover:text-white py-1.5 rounded bg-slate-700/60 hover:bg-slate-700 transition-colors"
                >
                  تعديل بيانات العداد / تسجيل المؤشر
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="p-4 text-center text-slate-400 text-xs border-b border-slate-800">
            <Info className="w-5 h-5 mx-auto mb-1 text-slate-500" />
            انقر على أي عداد على الخريطة أو في القائمة أدناه لعرض تفاصيله وبدء التوجيه إليه
          </div>
        )}

        {/* Meters Tournee List */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1.5">
          <div className="text-[11px] font-bold text-slate-400 px-2 py-1 flex justify-between items-center">
            <span>عدادات الجولة</span>
            <span>{meters.length}</span>
          </div>

          {meters.map((meter, index) => {
            const hasLocation = meter.latitude != null && meter.longitude != null;
            const isSelected = meter.id === selectedMeterId;

            return (
              <div
                key={meter.id}
                onClick={() => {
                  onSelectMeter(meter.id);
                  if (hasLocation && mapRef.current) {
                    mapRef.current.flyTo([meter.latitude!, meter.longitude!], 16);
                  }
                }}
                className={`p-2 rounded-lg border text-xs cursor-pointer transition-all flex items-center justify-between ${
                  isSelected
                    ? 'bg-orange-950/40 border-orange-500/80 text-orange-200'
                    : 'bg-slate-800/40 hover:bg-slate-800 border-slate-800 text-slate-300'
                }`}
              >
                <div className="flex items-center gap-2 min-w-0">
                  <span className="w-5 h-5 rounded-full bg-slate-700 text-[10px] font-mono flex items-center justify-center text-slate-300 shrink-0">
                    {index + 1}
                  </span>
                  <div className="truncate">
                    <div className="font-bold flex items-center gap-1.5 truncate">
                      <span className="font-mono">{meter.gda}</span>
                      {meter.saisie && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 inline" />}
                      {meter.bloque && <AlertTriangle className="w-3.5 h-3.5 text-rose-400 inline" />}
                      {meter.clientAbsent && <UserX className="w-3.5 h-3.5 text-amber-400 inline" />}
                    </div>
                    <div className="text-[10px] text-slate-400 truncate">
                      REF: {meter.ref} | {meter.address || 'بدون عنوان'}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  {hasLocation ? (
                    <span className="text-emerald-400" title="موقع GPS محدد">
                      <MapPin className="w-3.5 h-3.5" />
                    </span>
                  ) : (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectMeter(meter.id);
                        setAssigningLocationForId(meter.id);
                      }}
                      className="text-[10px] bg-slate-700 hover:bg-amber-600 text-slate-300 hover:text-white px-1.5 py-0.5 rounded transition-colors"
                      title="تحديد الموقع"
                    >
                      + موقع
                    </button>
                  )}
                  <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
