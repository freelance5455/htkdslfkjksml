import React, { useState, useEffect, useRef } from 'react';
import L from 'leaflet';
import { 
  X, 
  MapPin, 
  Navigation, 
  Locate, 
  Search, 
  Check, 
  AlertCircle, 
  ExternalLink,
  Layers,
  Crosshair
} from 'lucide-react';
import { MeterRecord } from '../../types/meter';

interface LocationPickerModalProps {
  isOpen: boolean;
  meter: MeterRecord | null;
  onClose: () => void;
  onSaveLocation: (meterId: string, lat: number, lng: number, address?: string) => void;
}

export const LocationPickerModal: React.FC<LocationPickerModalProps> = ({
  isOpen,
  meter,
  onClose,
  onSaveLocation
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);

  const [lat, setLat] = useState<number>(36.8065);
  const [lng, setLng] = useState<number>(10.1815);
  const [address, setAddress] = useState<string>('');
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [mapLayerType, setMapLayerType] = useState<'streets' | 'satellite'>('streets');
  const [coordInput, setCoordInput] = useState<string>('');
  const tileLayerRef = useRef<L.TileLayer | null>(null);

  // Initialize coordinates from meter or default
  useEffect(() => {
    if (!isOpen || !meter) return;

    const initialLat = meter.latitude != null && !isNaN(meter.latitude) ? meter.latitude : 36.8188;
    const initialLng = meter.longitude != null && !isNaN(meter.longitude) ? meter.longitude : 10.1658;
    
    setLat(initialLat);
    setLng(initialLng);
    setAddress(meter.address || '');
    setCoordInput(`${initialLat}, ${initialLng}`);
    setErrorMsg(null);
  }, [isOpen, meter]);

  // Leaflet map initialization
  useEffect(() => {
    if (!isOpen || !mapContainerRef.current) return;

    // Small delay to ensure modal DOM is painted
    const timer = setTimeout(() => {
      if (!mapContainerRef.current) return;

      if (!mapRef.current) {
        const map = L.map(mapContainerRef.current, {
          center: [lat, lng],
          zoom: 15,
          zoomControl: true,
        });

        const tile = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '&copy; OpenStreetMap contributors',
          maxZoom: 19,
        }).addTo(map);

        tileLayerRef.current = tile;
        mapRef.current = map;

        // Custom pin icon
        const pinIcon = L.divIcon({
          className: 'custom-picker-pin',
          html: `
            <div class="relative flex items-center justify-center -translate-x-1/2 -translate-y-full">
              <div class="bg-orange-600 border-2 border-white text-white p-2 rounded-full shadow-2xl animate-bounce">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                  <circle cx="12" cy="10" r="3"></circle>
                </svg>
              </div>
            </div>
          `,
          iconSize: [32, 32],
          iconAnchor: [16, 32]
        });

        const marker = L.marker([lat, lng], {
          icon: pinIcon,
          draggable: true
        }).addTo(map);

        marker.on('dragend', (e) => {
          const pos = (e.target as L.Marker).getLatLng();
          const newLat = parseFloat(pos.lat.toFixed(6));
          const newLng = parseFloat(pos.lng.toFixed(6));
          setLat(newLat);
          setLng(newLng);
          setCoordInput(`${newLat}, ${newLng}`);
        });

        markerRef.current = marker;

        // Click anywhere on map to move pin
        map.on('click', (e: L.LeafletMouseEvent) => {
          const newLat = parseFloat(e.latlng.lat.toFixed(6));
          const newLng = parseFloat(e.latlng.lng.toFixed(6));
          setLat(newLat);
          setLng(newLng);
          setCoordInput(`${newLat}, ${newLng}`);
          if (markerRef.current) {
            markerRef.current.setLatLng([newLat, newLng]);
          }
        });
      } else {
        mapRef.current.invalidateSize();
        mapRef.current.setView([lat, lng], 15);
        if (markerRef.current) {
          markerRef.current.setLatLng([lat, lng]);
        }
      }
    }, 150);

    return () => {
      clearTimeout(timer);
    };
  }, [isOpen]);

  // Clean up map when modal unmounts
  useEffect(() => {
    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
        markerRef.current = null;
      }
    };
  }, []);

  // Update tile layer streets / satellite
  useEffect(() => {
    if (!mapRef.current) return;
    if (tileLayerRef.current) {
      mapRef.current.removeLayer(tileLayerRef.current);
    }

    let newLayer: L.TileLayer;
    if (mapLayerType === 'satellite') {
      newLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: '&copy; Esri World Imagery',
        maxZoom: 18,
      });
    } else {
      newLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
        maxZoom: 19,
      });
    }

    newLayer.addTo(mapRef.current);
    tileLayerRef.current = newLayer;
  }, [mapLayerType]);

  // Handle GPS location from device
  const handleGetDeviceLocation = () => {
    if (!navigator.geolocation) {
      setErrorMsg('تحديد الموقع الجغرافي غير مدعوم في متصفحك أو جهازك.');
      return;
    }

    setIsLocating(true);
    setErrorMsg(null);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const newLat = parseFloat(pos.coords.latitude.toFixed(6));
        const newLng = parseFloat(pos.coords.longitude.toFixed(6));
        setLat(newLat);
        setLng(newLng);
        setCoordInput(`${newLat}, ${newLng}`);
        setIsLocating(false);

        if (mapRef.current) {
          mapRef.current.flyTo([newLat, newLng], 17);
        }
        if (markerRef.current) {
          markerRef.current.setLatLng([newLat, newLng]);
        }
      },
      (err) => {
        setIsLocating(false);
        setErrorMsg(`تعذر التقاط الموقع: ${err.message}`);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  // Handle pasting coordinates (e.g. "36.8188, 10.1658" or Google Maps link)
  const handleParseCoordinates = () => {
    if (!coordInput.trim()) return;

    // Check for "lat, lng" format
    const match = coordInput.match(/(-?\d+\.\d+)[,\s]+(-?\d+\.\d+)/);
    if (match) {
      const parsedLat = parseFloat(match[1]);
      const parsedLng = parseFloat(match[2]);
      if (!isNaN(parsedLat) && !isNaN(parsedLng)) {
        setLat(parsedLat);
        setLng(parsedLng);
        if (mapRef.current) {
          mapRef.current.flyTo([parsedLat, parsedLng], 16);
        }
        if (markerRef.current) {
          markerRef.current.setLatLng([parsedLat, parsedLng]);
        }
        setErrorMsg(null);
        return;
      }
    }

    setErrorMsg('صيغة الإحداثيات غير صحيحة. استخدم مثال: 36.8188, 10.1658');
  };

  const handleSave = () => {
    if (!meter) return;
    onSaveLocation(meter.id, lat, lng, address.trim() || undefined);
    onClose();
  };

  if (!isOpen || !meter) return null;

  const googleMapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div 
        className="bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl w-full max-w-3xl text-slate-100 overflow-hidden my-auto flex flex-col max-h-[92vh]"
        dir="rtl"
      >
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-orange-600/20 text-orange-400 border border-orange-500/30">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <span>تحديد الموقع الجغرافي والتوجيه للعداد</span>
                <span className="font-mono text-xs px-2 py-0.5 rounded bg-orange-500/20 text-orange-400 border border-orange-500/30">
                  {meter.gda}
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                مرجع الحريف: <span className="font-mono text-slate-300">{meter.ref}</span> | رقم العداد: <span className="font-mono text-slate-300">{meter.compt || '—'}</span>
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-3 overflow-y-auto flex-1">
          {errorMsg && (
            <div className="p-2.5 bg-rose-950/70 border border-rose-800 text-rose-200 text-xs rounded-lg flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Controls Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            {/* Address / Location Name */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                اسم المكان أو العنوان (نهج، حي، مدينة):
              </label>
              <input
                type="text"
                value={address}
                onChange={e => setAddress(e.target.value)}
                placeholder="مثال: نهج فلسطين، المنزه 1..."
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-orange-500"
              />
            </div>

            {/* Coordinates Input & Paste */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                الإحداثيات الجغرافية (خط العرض، خط الطول):
              </label>
              <div className="flex gap-1.5">
                <input
                  type="text"
                  value={coordInput}
                  onChange={e => setCoordInput(e.target.value)}
                  placeholder="36.8188, 10.1658"
                  className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs font-mono text-slate-100 placeholder-slate-500 focus:outline-none focus:border-orange-500"
                />
                <button
                  type="button"
                  onClick={handleParseCoordinates}
                  className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold whitespace-nowrap"
                >
                  تطبيق
                </button>
              </div>
            </div>
          </div>

          {/* Map Interactive Canvas */}
          <div className="relative w-full h-[320px] sm:h-[380px] rounded-xl overflow-hidden border border-slate-700 shadow-inner">
            <div ref={mapContainerRef} className="w-full h-full z-0" />

            {/* Floating Top Controls inside map */}
            <div className="absolute top-2.5 right-2.5 z-10 flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleGetDeviceLocation}
                disabled={isLocating}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg transition-all"
                title="التقاط موقعي الحالي GPS"
              >
                <Locate className={`w-4 h-4 ${isLocating ? 'animate-spin' : ''}`} />
                <span>{isLocating ? 'جاري الالتقاط...' : '📍 موقعي الحالي الآن'}</span>
              </button>

              <button
                type="button"
                onClick={() => setMapLayerType(mapLayerType === 'streets' ? 'satellite' : 'streets')}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-900/90 hover:bg-slate-800 text-slate-200 border border-slate-700 text-xs shadow backdrop-blur-sm"
              >
                <Layers className="w-3.5 h-3.5 text-orange-400" />
                <span>{mapLayerType === 'streets' ? 'قمر صناعي' : 'شوارع'}</span>
              </button>
            </div>

            {/* Instruction Badge */}
            <div className="absolute bottom-2.5 right-2.5 z-10 bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-700 shadow text-[11px] text-slate-300 flex items-center gap-1.5 pointer-events-none">
              <Crosshair className="w-3.5 h-3.5 text-orange-400" />
              <span>انقر في أي مكان على الخريطة أو اسحب العلامة لتحديد الموقع بدقة</span>
            </div>
          </div>

          {/* Current selected Lat / Lng Display & Navigation Preview */}
          <div className="bg-slate-950/70 border border-slate-800 p-3 rounded-xl flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-3">
              <div className="text-slate-400">
                خط العرض: <span className="font-mono font-bold text-emerald-400">{lat}</span>
              </div>
              <div className="text-slate-400">
                خط الطول: <span className="font-mono font-bold text-emerald-400">{lng}</span>
              </div>
            </div>

            <a
              href={googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 bg-blue-600/30 hover:bg-blue-600 text-blue-300 hover:text-white border border-blue-500/40 px-3 py-1 rounded-lg text-xs font-bold transition-all"
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>تجربة التوجه في Google Maps</span>
              <ExternalLink className="w-3 h-3 opacity-70" />
            </a>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors"
          >
            إلغاء
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-5 py-2 rounded-lg bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white text-xs font-bold shadow-lg transition-all flex items-center gap-1.5"
          >
            <Check className="w-4 h-4" />
            <span>حفظ الموقع للعداد</span>
          </button>
        </div>
      </div>
    </div>
  );
};
