import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { copy } from "@/lib/i18n";
import {
  emptyDraft,
  useLaksha,
  type ReminderMode,
  type WatchKind,
} from "@/lib/store";
import { cn, extractUrl } from "@/lib/utils";

const KINDS: WatchKind[] = ["site", "reminder", "target", "keyword", "custom"];
const MODES: ReminderMode[] = ["daily", "every5", "everyHour", "every6h"];

type Props = {
  open: boolean;
  note: string;
  onOpenChange: (open: boolean) => void;
};

export function AddWatchDialog({ open, note, onOpenChange }: Props) {
  const lang = useLaksha((s) => s.lang);
  const addWatch = useLaksha((s) => s.addWatch);
  const t = copy[lang];
  const [draft, setDraft] = useState(() => emptyDraft(note));
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) return;
    const next = emptyDraft(note);
    const url = extractUrl(note);
    if (url) {
      next.kind = "site";
      next.url = url;
    }
    setDraft(next);
    setError("");
  }, [open, note]);

  const kindLabel: Record<WatchKind, string> = {
    site: t.kindSite,
    reminder: t.kindReminder,
    target: t.kindTarget,
    keyword: t.kindKeyword,
    custom: t.kindCustom,
  };
  const modeLabel: Record<ReminderMode, string> = {
    daily: t.daily,
    every5: t.every5,
    everyHour: t.everyHour,
    every6h: t.every6h,
  };

  function save() {
    if (draft.kind === "site" && !draft.url.trim()) {
      setError(t.requiredUrl);
      return;
    }
    addWatch(draft);
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{t.refine}</DialogTitle>
          <DialogDescription>{t.composerHint}</DialogDescription>
        </DialogHeader>

        <div className="mt-3 flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="note">{t.note}</Label>
            <Textarea
              id="note"
              value={draft.note}
              onChange={(e) => setDraft((d) => ({ ...d, note: e.target.value }))}
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <Label htmlFor="title">{t.title}</Label>
            <Input
              id="title"
              value={draft.title}
              placeholder={t.title}
              onChange={(e) => setDraft((d) => ({ ...d, title: e.target.value }))}
            />
          </div>

          <div className="flex flex-col gap-2">
            <Label>{t.refine}</Label>
            <div className="flex flex-wrap gap-2">
              {KINDS.map((k) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => setDraft((d) => ({ ...d, kind: k }))}
                  className={cn(
                    "h-9 rounded-full border px-3 text-xs font-medium",
                    draft.kind === k
                      ? "border-primary bg-primary text-primary-fg"
                      : "border-border bg-surface-2 text-muted",
                  )}
                >
                  {kindLabel[k]}
                </button>
              ))}
            </div>
          </div>

          {draft.kind === "site" && (
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="url">{t.url}</Label>
              <Input
                id="url"
                value={draft.url}
                placeholder={t.urlHint}
                onChange={(e) => setDraft((d) => ({ ...d, url: e.target.value }))}
              />
            </div>
          )}

          {draft.kind === "keyword" && (
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="kw">{t.keyword}</Label>
              <Input
                id="kw"
                value={draft.keyword}
                onChange={(e) => setDraft((d) => ({ ...d, keyword: e.target.value }))}
              />
            </div>
          )}

          {draft.kind === "target" && (
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="tgt">{t.targetValue}</Label>
                <Input
                  id="tgt"
                  inputMode="decimal"
                  value={draft.targetValue}
                  onChange={(e) => setDraft((d) => ({ ...d, targetValue: e.target.value }))}
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="cur">{t.currentValue}</Label>
                <Input
                  id="cur"
                  inputMode="decimal"
                  value={draft.currentValue}
                  onChange={(e) => setDraft((d) => ({ ...d, currentValue: e.target.value }))}
                />
              </div>
              <div className="col-span-2 flex gap-2">
                <button
                  type="button"
                  className={cn(
                    "h-9 flex-1 rounded-full border text-xs font-medium",
                    draft.targetDirection === "below"
                      ? "border-primary bg-primary text-primary-fg"
                      : "border-border bg-surface-2 text-muted",
                  )}
                  onClick={() => setDraft((d) => ({ ...d, targetDirection: "below" }))}
                >
                  {t.below}
                </button>
                <button
                  type="button"
                  className={cn(
                    "h-9 flex-1 rounded-full border text-xs font-medium",
                    draft.targetDirection === "above"
                      ? "border-primary bg-primary text-primary-fg"
                      : "border-border bg-surface-2 text-muted",
                  )}
                  onClick={() => setDraft((d) => ({ ...d, targetDirection: "above" }))}
                >
                  {t.above}
                </button>
              </div>
            </div>
          )}

          {draft.kind === "reminder" && (
            <div className="flex flex-col gap-3">
              <div className="flex flex-wrap gap-2">
                {MODES.map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setDraft((d) => ({ ...d, reminderMode: m }))}
                    className={cn(
                      "h-9 rounded-full border px-3 text-xs font-medium",
                      draft.reminderMode === m
                        ? "border-primary bg-primary text-primary-fg"
                        : "border-border bg-surface-2 text-muted",
                    )}
                  >
                    {modeLabel[m]}
                  </button>
                ))}
              </div>
              {draft.reminderMode === "daily" && (
                <div className="flex flex-col gap-1.5">
                  <Label htmlFor="time">{t.atTime}</Label>
                  <Input
                    id="time"
                    type="time"
                    value={draft.reminderAt}
                    onChange={(e) => setDraft((d) => ({ ...d, reminderAt: e.target.value }))}
                  />
                </div>
              )}
            </div>
          )}

          <div className="flex flex-col gap-3 rounded-lg border border-border bg-surface-2 p-3">
            <Label>{t.channels}</Label>
            <div className="flex items-center justify-between">
              <span className="text-sm">{t.notif}</span>
              <Switch
                checked={draft.notification}
                onCheckedChange={(v) => setDraft((d) => ({ ...d, notification: v }))}
              />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">{t.smsChannel}</span>
              <Switch
                checked={draft.sms}
                onCheckedChange={(v) => setDraft((d) => ({ ...d, sms: v }))}
              />
            </div>
          </div>

          {error ? <p className="text-sm text-alert">{error}</p> : null}
        </div>

        <DialogFooter>
          <Button variant="secondary" onClick={() => onOpenChange(false)}>
            {t.cancel}
          </Button>
          <Button onClick={save}>{t.save}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
