import React, { useState, useRef } from "react";
import {
  X,
  Download,
  Upload,
  FileText,
  FileSpreadsheet,
  Presentation,
  Image,
  Volume2,
  Video,
  Archive,
  Code,
  Globe,
  Check,
  Sparkles,
  AlertCircle,
  FileCode,
  Layers,
  ChevronRight,
  Filter,
  CheckCircle2,
  RefreshCw,
  FolderKanban,
  Binary
} from "lucide-react";
import { Note, SectionItem, ThemeAccent } from "../types";
import {
  SUPPORTED_DOCUMENT_FORMATS,
  DocumentCategory,
  DocumentFormatInfo,
  exportToWordDocx,
  exportToPDF,
  exportToTXT,
  exportToRTF,
  exportToODT,
  exportToExcelXLSX,
  exportToCSV,
  exportToODS,
  exportToPowerPointPPTX,
  exportToHTML,
  exportToXML,
  exportToSVGCard,
  exportToZIPArchive,
  exportToBIN,
  parseUploadedDocument,
  ParsedImportResult
} from "../utils/documentHub";
import { THEME_ACCENTS } from "../utils/theme";

interface DocumentHubModalProps {
  isOpen: boolean;
  onClose: () => void;
  notes: Note[];
  sections: SectionItem[];
  themeAccent: ThemeAccent;
  onImportNotes: (newNotes: Array<Omit<Note, "id" | "createdAt" | "updatedAt">>) => void;
  activeNote?: Note | null;
  defaultNote?: Note | null;
}

export const DocumentHubModal: React.FC<DocumentHubModalProps> = ({
  isOpen,
  onClose,
  notes,
  sections,
  themeAccent,
  onImportNotes,
  activeNote = null,
  defaultNote = null,
}) => {
  const initialNote = activeNote || defaultNote || null;
  const [activeTab, setActiveTab] = useState<"export" | "import">("export");
  const [selectedCategory, setSelectedCategory] = useState<DocumentCategory | "all">("all");
  const [exportScope, setExportScope] = useState<"all" | "single" | "section">(initialNote ? "single" : "all");
  const [selectedNoteId, setSelectedNoteId] = useState<string>(initialNote ? initialNote.id : notes[0]?.id || "");
  const [selectedSectionName, setSelectedSectionName] = useState<string>(sections[0]?.name || "Genel");
  const [isExporting, setIsExporting] = useState<string | null>(null);
  
  // Import states
  const [isDragging, setIsDragging] = useState(false);
  const [isParsing, setIsParsing] = useState(false);
  const [parsedItems, setParsedItems] = useState<ParsedImportResult[]>([]);
  const [importTargetCategory, setImportTargetCategory] = useState<string>("Genel");
  const [importSuccessMsg, setImportSuccessMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const themeDef = THEME_ACCENTS[themeAccent] || THEME_ACCENTS.teal;

  if (!isOpen) return null;

  // Filter notes based on scope
  const getNotesToExport = (): Note[] => {
    if (exportScope === "single") {
      const found = notes.find((n) => n.id === selectedNoteId);
      return found ? [found] : notes.slice(0, 1);
    }
    if (exportScope === "section") {
      const filtered = notes.filter((n) => n.category === selectedSectionName);
      return filtered.length > 0 ? filtered : notes;
    }
    return notes;
  };

  const handleExecuteExport = async (format: DocumentFormatInfo) => {
    const targetNotes = getNotesToExport();
    if (targetNotes.length === 0) {
      alert("Dışa aktarılacak not bulunamadı.");
      return;
    }

    setIsExporting(format.id);
    try {
      const exportTitle =
        exportScope === "single"
          ? targetNotes[0].title || "Not_Belgesi"
          : exportScope === "section"
          ? `${selectedSectionName}_Notlari`
          : "NoteFlow_Tum_Notlar";

      switch (format.id) {
        case "docx":
          exportToWordDocx(targetNotes, exportTitle);
          break;
        case "pdf":
          exportToPDF(targetNotes, exportTitle);
          break;
        case "txt":
          exportToTXT(targetNotes, exportTitle);
          break;
        case "rtf":
          exportToRTF(targetNotes, exportTitle);
          break;
        case "odt":
          exportToODT(targetNotes, exportTitle);
          break;
        case "xlsx":
          exportToExcelXLSX(targetNotes, exportTitle);
          break;
        case "csv":
          exportToCSV(targetNotes, exportTitle);
          break;
        case "ods":
          exportToODS(targetNotes, exportTitle);
          break;
        case "pptx":
          exportToPowerPointPPTX(targetNotes, exportTitle);
          break;
        case "odp":
          exportToPowerPointPPTX(targetNotes, exportTitle);
          break;
        case "html":
          exportToHTML(targetNotes, exportTitle);
          break;
        case "xml":
          exportToXML(targetNotes, exportTitle);
          break;
        case "bin":
          exportToBIN(targetNotes, exportTitle);
          break;
        case "json":
          exportToHTML(targetNotes, exportTitle);
          break;
        case "zip":
          await exportToZIPArchive(targetNotes, exportTitle);
          break;
        case "svg":
        case "png":
          if (targetNotes.length > 0) exportToSVGCard(targetNotes[0]);
          break;
        default:
          exportToTXT(targetNotes, exportTitle);
          break;
      }
    } catch (err) {
      console.error("Export error:", err);
      alert("Dışa aktarım sırasında bir hata oluştu.");
    } finally {
      setTimeout(() => setIsExporting(null), 800);
    }
  };

  // Process files dropped or picked
  const handleFilesSelected = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setIsParsing(true);
    setImportSuccessMsg(null);

    const allParsed: ParsedImportResult[] = [];
    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const res = await parseUploadedDocument(file);
        allParsed.push(...res);
      }
      setParsedItems(allParsed);

      if (allParsed.length > 0) {
        const toImport = allParsed.map((p) => ({
          title: p.title || "İçe Aktarılan Not",
          content: p.content,
          htmlContent: p.htmlContent,
          category: importTargetCategory || p.category || "Genel",
          tags: p.tags || ["#aktarim"],
          pinned: false,
          favorite: false,
          tasks: p.tasks || [],
          attachments: p.attachment
            ? [
                {
                  id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
                  name: p.attachment.name,
                  mime: p.attachment.mime,
                  size: p.attachment.size,
                  data: p.attachment.data,
                },
              ]
            : [],
        }));

        onImportNotes(toImport);
        setImportSuccessMsg(
          `✓ ${toImport.length} adet dosya (.bin dahil) başarıyla Notlar bölümüne eklendi ve tüm içeriği açıldı!`
        );
      }
    } catch (err) {
      console.error("Import parse failed:", err);
      alert("Dosyalar ayrıştırılırken bir sorun oluştu.");
    } finally {
      setIsParsing(false);
    }
  };

  const handleSaveImportedNotes = () => {
    if (parsedItems.length === 0) return;

    const toImport = parsedItems.map((p) => ({
      title: p.title || "İçe Aktarılan Not",
      content: p.content,
      htmlContent: p.htmlContent,
      category: importTargetCategory || p.category || "Genel",
      tags: p.tags || ["#aktarim"],
      pinned: false,
      favorite: false,
      tasks: p.tasks || [],
      attachments: p.attachment ? [
        {
          id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          name: p.attachment.name,
          mime: p.attachment.mime,
          size: p.attachment.size,
          data: p.attachment.data,
        }
      ] : [],
    }));

    onImportNotes(toImport);
    setImportSuccessMsg(`✓ ${toImport.length} adet belge ve not başarıyla çalışma alanınıza eklendi!`);
    setParsedItems([]);
    setTimeout(() => {
      onClose();
    }, 1500);
  };

  const filteredFormats = SUPPORTED_DOCUMENT_FORMATS.filter((fmt) => {
    if (selectedCategory === "all") return fmt.canExport;
    return fmt.category === selectedCategory && fmt.canExport;
  });

  const categoriesList: Array<{ id: DocumentCategory | "all"; label: string; icon: any }> = [
    { id: "all", label: "Tüm Formatlar", icon: Layers },
    { id: "office", label: "Metin & Ofis", icon: FileText },
    { id: "table", label: "Tablo & Veri", icon: FileSpreadsheet },
    { id: "presentation", label: "Sunum", icon: Presentation },
    { id: "binary", label: "İkili & Sistem (.BIN)", icon: Binary },
    { id: "media", label: "Görsel & Grafik", icon: Image },
    { id: "archive", label: "Arşiv (ZIP)", icon: Archive },
    { id: "code_web", label: "Kod & Web", icon: Code },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl max-h-[90vh] bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/80">
          <div className="flex items-center gap-3">
            <div className={`w-11 h-11 rounded-2xl bg-gradient-to-tr ${themeDef.gradient} flex items-center justify-center text-white shadow-md font-bold text-xl`}>
              📁
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                  Evrensel Belge ve Dosya Merkezi
                </h2>
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${themeDef.badgeBg} ${themeDef.badgeText} border`}>
                  Tüm Formatlar Destekli
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Word, Excel, PDF, PowerPoint, Resim, Ses, ZIP ve Web belgelerinde sınırsız içe ve dışa aktarım
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Top Mode Segmented Switcher */}
            <div className="flex p-1 bg-slate-200/80 dark:bg-slate-800 rounded-2xl border border-slate-300/50 dark:border-slate-700 text-xs font-semibold">
              <button
                onClick={() => setActiveTab("export")}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all ${
                  activeTab === "export"
                    ? `${themeDef.buttonBg} shadow-xs font-bold`
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                }`}
              >
                <Download className="w-3.5 h-3.5" />
                <span>Dışa Aktar</span>
              </button>
              <button
                onClick={() => setActiveTab("import")}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all ${
                  activeTab === "import"
                    ? `${themeDef.buttonBg} shadow-xs font-bold`
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                }`}
              >
                <Upload className="w-3.5 h-3.5" />
                <span>İçeri Aktar</span>
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">

          {/* TAB 1: EXPORT CENTER */}
          {activeTab === "export" && (
            <div className="space-y-6">
              {/* Scope Bar */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-850/60 border border-slate-200/80 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    Aktarılacak Kapsam:
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setExportScope("all")}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                        exportScope === "all"
                          ? `${themeDef.bgLight} ${themeDef.bgLightDark} ${themeDef.border} ${themeDef.text} ${themeDef.textDark} font-bold`
                          : "border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400"
                      }`}
                    >
                      Tüm Notlarım ({notes.length})
                    </button>
                    <button
                      onClick={() => setExportScope("single")}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                        exportScope === "single"
                          ? `${themeDef.bgLight} ${themeDef.bgLightDark} ${themeDef.border} ${themeDef.text} ${themeDef.textDark} font-bold`
                          : "border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400"
                      }`}
                    >
                      Seçili Tek Not
                    </button>
                    <button
                      onClick={() => setExportScope("section")}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                        exportScope === "section"
                          ? `${themeDef.bgLight} ${themeDef.bgLightDark} ${themeDef.border} ${themeDef.text} ${themeDef.textDark} font-bold`
                          : "border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400"
                      }`}
                    >
                      Bölüme Göre
                    </button>
                  </div>
                </div>

                {/* Sub Dropdowns */}
                {exportScope === "single" && (
                  <select
                    value={selectedNoteId}
                    onChange={(e) => setSelectedNoteId(e.target.value)}
                    className="text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-1.5 max-w-xs"
                  >
                    {notes.map((n) => (
                      <option key={n.id} value={n.id}>
                        {n.title || "Başlıksız Not"}
                      </option>
                    ))}
                  </select>
                )}

                {exportScope === "section" && (
                  <select
                    value={selectedSectionName}
                    onChange={(e) => setSelectedSectionName(e.target.value)}
                    className="text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-1.5"
                  >
                    {sections.map((s) => (
                      <option key={s.id} value={s.name}>
                        {s.name} ({notes.filter((n) => n.category === s.name).length} not)
                      </option>
                    ))}
                  </select>
                )}

                {/* Quick ZIP Export Button */}
                <button
                  onClick={() => handleExecuteExport(SUPPORTED_DOCUMENT_FORMATS.find((f) => f.id === "zip")!)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r ${themeDef.gradient} shadow-md active:scale-95 transition-all`}
                >
                  <Archive className="w-4 h-4" />
                  <span>Tek Tıkla Tümünü ZIP İndir</span>
                </button>
              </div>

              {/* Category Filter Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                {categoriesList.map((cat) => {
                  const Icon = cat.icon;
                  const isSelected = selectedCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                        isSelected
                          ? `${themeDef.buttonBg} shadow-xs font-bold`
                          : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span>{cat.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Formats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
                {filteredFormats.map((fmt) => {
                  const isExportingThis = isExporting === fmt.id;
                  return (
                    <div
                      key={fmt.id}
                      className="p-4 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 hover:border-teal-500/50 hover:shadow-md transition-all flex flex-col justify-between group"
                    >
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase tracking-wider ${fmt.badgeColor}`}>
                            {fmt.extension}
                          </span>
                          <span className="text-[10px] text-slate-400 font-medium">
                            {fmt.categoryLabel}
                          </span>
                        </div>
                        <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1 group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors">
                          {fmt.name}
                        </h3>
                        <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed mb-3">
                          {fmt.description}
                        </p>
                      </div>

                      <button
                        onClick={() => handleExecuteExport(fmt)}
                        disabled={isExportingThis}
                        className={`w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-bold border transition-all ${
                          isExportingThis
                            ? "bg-teal-50 text-teal-700 border-teal-300 dark:bg-teal-950 dark:text-teal-300 animate-pulse"
                            : "bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-teal-600 hover:text-white hover:border-teal-600 dark:hover:bg-teal-600 dark:hover:text-white"
                        }`}
                      >
                        {isExportingThis ? (
                          <>
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                            <span>Hazırlanıyor...</span>
                          </>
                        ) : (
                          <>
                            <Download className="w-3.5 h-3.5" />
                            <span>{fmt.extension} Olarak İndir</span>
                          </>
                        )}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: UNIVERSAL IMPORT HUB */}
          {activeTab === "import" && (
            <div className="space-y-6">
              {/* Drag & Drop Zone */}
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDragging(true);
                }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setIsDragging(false);
                  handleFilesSelected(e.dataTransfer.files);
                }}
                onClick={() => fileInputRef.current?.click()}
                className={`p-8 rounded-3xl border-2 border-dashed text-center cursor-pointer transition-all ${
                  isDragging
                    ? "border-teal-500 bg-teal-50/50 dark:bg-teal-950/30 scale-[1.01]"
                    : "border-slate-300 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-850/50 hover:bg-slate-100/60 dark:hover:bg-slate-800/60"
                }`}
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={(e) => handleFilesSelected(e.target.files)}
                  multiple
                  accept="*"
                  className="hidden"
                />

                <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-teal-100 dark:bg-teal-950/80 text-teal-600 dark:text-teal-400 flex items-center justify-center text-3xl shadow-inner">
                  📥
                </div>
                <h3 className="text-base font-bold text-slate-800 dark:text-slate-100 mb-1">
                  Herhangi Bir Belgeyi Buraya Sürükleyip Bırakın (.BIN Dahil Tüm Formatlar)
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto mb-4">
                  İkili (.BIN), Word, Excel, PDF, TXT, RTF, Sunum, Resimler, Ses/Video veya ZIP dosyalarını doğrudan seçin; içerikleri anında notlarınıza eklenir.
                </p>

                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-md transition-colors">
                  <Upload className="w-4 h-4" />
                  <span>Bilgisayarınızdan Dosya Seçin</span>
                </div>

                <div className="mt-4 flex flex-wrap justify-center gap-1.5 max-w-xl mx-auto">
                  {[
                    ".docx", ".doc", ".pdf", ".txt", ".rtf", ".odt",
                    ".xlsx", ".csv", ".pptx", ".zip", ".jpg", ".png",
                    ".svg", ".mp3", ".mp4", ".html", ".json", ".xml"
                  ].map((ext) => (
                    <span key={ext} className="text-[10px] font-mono px-1.5 py-0.5 rounded-md bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                      {ext}
                    </span>
                  ))}
                </div>
              </div>

              {/* Parsing State */}
              {isParsing && (
                <div className="p-4 rounded-2xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 flex items-center justify-center gap-3 text-teal-700 dark:text-teal-300 text-sm font-semibold animate-pulse">
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Belgeleriniz taranıyor ve akıllı notlara dönüştürülüyor...</span>
                </div>
              )}

              {/* Success Message */}
              {importSuccessMsg && (
                <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-300 dark:border-emerald-800 flex items-center gap-3 text-emerald-800 dark:text-emerald-300 text-sm font-bold animate-in fade-in">
                  <CheckCircle2 className="w-5 h-5 flex-shrink-0 text-emerald-600" />
                  <span>{importSuccessMsg}</span>
                </div>
              )}

              {/* Parsed Items Preview Table */}
              {parsedItems.length > 0 && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                        İçe Aktarılacak Notlar ({parsedItems.length} Adet Hazır)
                      </h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Eklenmeden önce kontrol edebilir ve hedef bölümü seçebilirsiniz:
                      </p>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                          Hedef Bölüm:
                        </span>
                        <select
                          value={importTargetCategory}
                          onChange={(e) => setImportTargetCategory(e.target.value)}
                          className="text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-1.5"
                        >
                          {sections.map((s) => (
                            <option key={s.id} value={s.name}>
                              {s.name}
                            </option>
                          ))}
                        </select>
                      </div>

                      <button
                        onClick={handleSaveImportedNotes}
                        className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r ${themeDef.gradient} shadow-md active:scale-95 transition-all`}
                      >
                        <Check className="w-4 h-4" />
                        <span>Notlarıma Ekle ({parsedItems.length})</span>
                      </button>
                    </div>
                  </div>

                  <div className="max-h-60 overflow-y-auto rounded-2xl border border-slate-200 dark:border-slate-700 divide-y divide-slate-100 dark:divide-slate-800">
                    {parsedItems.map((item, idx) => (
                      <div key={idx} className="p-3 bg-white dark:bg-slate-800/60 flex items-center justify-between gap-4 text-xs">
                        <div className="flex items-center gap-3 min-w-0">
                          <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded-md bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300 uppercase">
                            .{item.rawFormat}
                          </span>
                          <div className="truncate">
                            <span className="font-bold text-slate-800 dark:text-slate-200">
                              {item.title}
                            </span>
                            <span className="text-slate-400 text-[11px] block truncate">
                              {item.content.slice(0, 80)}...
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 flex-shrink-0">
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-400">
                            {item.category}
                          </span>
                          <button
                            onClick={() => setParsedItems(parsedItems.filter((_, i) => i !== idx))}
                            className="text-slate-400 hover:text-red-500 p-1"
                            title="Listeden Çıkar"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 border-t border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/80 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              Mevcut Not Havuzunuz:
            </span>
            <span>{notes.length} Not</span>
            <span>•</span>
            <span>{sections.length} Bölüm</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            Kapat
          </button>
        </div>
      </div>
    </div>
  );
};
