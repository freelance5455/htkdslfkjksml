import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { MessExpense, MessCollection, MessExpenseCategory, Labour, LabourRoleType } from '../types';
import { 
  formatCurrency, 
  formatDateBengali, 
  getExpenseCategoryLabel, 
  getRoleTypeBadge, 
  getPaymentMethodLabel 
} from '../utils/formatters';
import { getMessFinancialSummary } from '../utils/calculations';
import { 
  UtensilsCrossed, 
  Plus, 
  Filter, 
  Calendar, 
  DollarSign, 
  Users, 
  ShoppingBag, 
  Flame, 
  ChefHat, 
  Zap, 
  Wrench, 
  Trash2, 
  Edit3, 
  ArrowUpRight, 
  CheckCircle, 
  AlertCircle,
  X,
  Search
} from 'lucide-react';

export const MessView: React.FC = () => {
  const { 
    labours, 
    messExpenses, 
    messCollections, 
    addMessExpense, 
    deleteMessExpense, 
    addMessCollection, 
    deleteMessCollection,
    updateLabour 
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'expenses' | 'collections' | 'members'>('expenses');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [collectionTypeFilter, setCollectionTypeFilter] = useState<'all' | 'meal_cost' | 'room_rent'>('all');
  const [memberRoleFilter, setMemberRoleFilter] = useState<string>('all');
  const [searchMember, setSearchMember] = useState('');

  // Modals
  const [showExpenseModal, setShowExpenseModal] = useState(false);
  const [showCollectionModal, setShowCollectionModal] = useState(false);
  const [editingLabourForStay, setEditingLabourForStay] = useState<Labour | null>(null);

  // New Expense State
  const [expenseForm, setExpenseForm] = useState<Omit<MessExpense, 'id'>>({
    date: new Date().toISOString().slice(0, 10),
    category: 'bazar',
    title: '',
    amount: 1000,
    paidBy: 'মেস ম্যানেজার তহবিল',
    note: ''
  });

  // New Collection State
  const [collectionForm, setCollectionForm] = useState<Omit<MessCollection, 'id'>>({
    labourId: labours.find(l => l.roleType !== 'site_only')?.id || labours[0]?.id || '',
    type: 'meal_cost',
    periodLabel: '১ম সপ্তাহ (মার্চ)',
    date: new Date().toISOString().slice(0, 10),
    amount: 750,
    paymentMethod: 'cash',
    note: ''
  });

  // Stay Edit Form
  const [stayDatesForm, setStayDatesForm] = useState<{
    startDate: string;
    endDate: string;
    roleType: LabourRoleType;
  }>({
    startDate: '',
    endDate: '',
    roleType: 'mess_and_site'
  });

  // Financial summary
  const summary = getMessFinancialSummary(messExpenses, messCollections);

  // Filtered Expenses
  const filteredExpenses = messExpenses.filter(e => {
    if (selectedCategory === 'all') return true;
    return e.category === selectedCategory;
  });

  // Filtered Collections
  const filteredCollections = messCollections.filter(c => {
    if (collectionTypeFilter === 'all') return true;
    return c.type === collectionTypeFilter;
  });

  // Filtered Labours (all who have mess interaction or all labours)
  const filteredMembers = labours.filter(l => {
    if (memberRoleFilter !== 'all' && l.roleType !== memberRoleFilter) return false;
    if (searchMember) {
      return l.name.toLowerCase().includes(searchMember.toLowerCase()) || l.phone.includes(searchMember);
    }
    return true;
  });

  const getCategoryIcon = (category: MessExpenseCategory) => {
    switch (category) {
      case 'bazar': return <ShoppingBag className="w-4 h-4 text-emerald-600" />;
      case 'gas': return <Flame className="w-4 h-4 text-orange-600" />;
      case 'cook_salary': return <ChefHat className="w-4 h-4 text-purple-600" />;
      case 'electricity': return <Zap className="w-4 h-4 text-amber-600" />;
      case 'water_repairs': return <Wrench className="w-4 h-4 text-cyan-600" />;
      default: return <UtensilsCrossed className="w-4 h-4 text-slate-500" />;
    }
  };

  return (
    <div className="space-y-6">
      
      {/* মেস ফাইন্যান্সিয়াল কিপিআই বার */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <span className="block text-xs font-medium text-slate-500">মোট মেস খরচ</span>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-slate-900">
            {formatCurrency(summary.totalMessExpense)}
          </div>
          <span className="block text-[11px] text-slate-400 mt-1">বাজার, গ্যাস, বিদ্যুৎ ও বাবুর্চির মোট ব্যয়</span>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <span className="block text-xs font-medium text-slate-500">খাবার খরচ সংগ্রহ (Meal Cost)</span>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-emerald-700">
            {formatCurrency(summary.totalMealCollection)}
          </div>
          <span className="block text-[11px] text-slate-400 mt-1">মেসের লেবারদের থেকে সাপ্তাহিক চাঁদা</span>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <span className="block text-xs font-medium text-slate-500">মেস উদ্বৃত্ত / ঘাটতি</span>
          <div className={`mt-2 text-2xl font-bold font-mono tabular-nums ${summary.messSurplus >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
            {summary.messSurplus >= 0 ? '+' : ''}{formatCurrency(summary.messSurplus)}
          </div>
          <span className="block text-[11px] text-slate-400 mt-1">
            {summary.messSurplus >= 0 ? 'খাবার তহবিলে উদ্বৃত্ত রয়েছে' : 'মেসে সাময়িক ঘাটতি দেখা দিয়েছে'}
          </span>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <span className="block text-xs font-medium text-slate-500">লেবারদের রুম ভাড়া সংগ্রহ</span>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-blue-700">
            {formatCurrency(summary.totalRoomRentCollection)}
          </div>
          <span className="block text-[11px] text-slate-400 mt-1">মেসের লেবারদের থেকে সংগৃহীত রুম ভাড়া</span>
        </div>

      </div>

      {/* সাব-ট্যাব ন্যাভিগেশন ও মূল অ্যাকশন বোতাম */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-2.5 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-1.5 overflow-x-auto">
          <button
            onClick={() => setActiveSubTab('expenses')}
            className={`px-3.5 py-2 text-xs sm:text-sm font-medium rounded-lg whitespace-nowrap transition-colors ${
              activeSubTab === 'expenses'
                ? 'bg-amber-600 text-white shadow-xs font-semibold'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            মেস খরচ এন্ট্রি (বাজার, গ্যাস, বাবুর্চি)
          </button>

          <button
            onClick={() => setActiveSubTab('collections')}
            className={`px-3.5 py-2 text-xs sm:text-sm font-medium rounded-lg whitespace-nowrap transition-colors ${
              activeSubTab === 'collections'
                ? 'bg-amber-600 text-white shadow-xs font-semibold'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            সাপ্তাহিক মিল ও রুম ভাড়া সংগ্রহ
          </button>

          <button
            onClick={() => setActiveSubTab('members')}
            className={`px-3.5 py-2 text-xs sm:text-sm font-medium rounded-lg whitespace-nowrap transition-colors ${
              activeSubTab === 'members'
                ? 'bg-amber-600 text-white shadow-xs font-semibold'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            লেবারদের এন্ট্রি-এক্সিট ও থাকার স্ট্যাটাস
          </button>
        </div>

        <div className="flex items-center gap-2">
          {activeSubTab === 'expenses' && (
            <button
              onClick={() => {
                setExpenseForm({
                  date: new Date().toISOString().slice(0, 10),
                  category: 'bazar',
                  title: '',
                  amount: 1500,
                  paidBy: 'মেস ম্যানেজার তহবিল',
                  note: ''
                });
                setShowExpenseModal(true);
              }}
              className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs sm:text-sm font-medium rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              <span>+ মেস খরচ যোগ</span>
            </button>
          )}

          {activeSubTab === 'collections' && (
            <button
              onClick={() => {
                const defaultLabour = labours.find(l => l.roleType !== 'site_only') || labours[0];
                setCollectionForm({
                  labourId: defaultLabour?.id || '',
                  type: 'meal_cost',
                  periodLabel: '১ম সপ্তাহ (মার্চ)',
                  date: new Date().toISOString().slice(0, 10),
                  amount: 750,
                  paymentMethod: 'cash',
                  note: ''
                });
                setShowCollectionModal(true);
              }}
              className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs sm:text-sm font-medium rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              <span>+ টাকা কালেকশন এন্ট্রি</span>
            </button>
          )}
        </div>
      </div>

      {/* ১. মেস খরচ এন্ট্রি ভিউ */}
      {activeSubTab === 'expenses' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          {/* ক্যাটাগরি ফিল্টার বার */}
          <div className="p-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-slate-50/50">
            <div className="flex items-center gap-1.5 overflow-x-auto text-xs">
              <span className="text-slate-500 font-medium mr-1">ক্যাটাগরি:</span>
              {[
                { id: 'all', label: 'সব খরচ' },
                { id: 'bazar', label: 'কাঁচাবাজার' },
                { id: 'gas', label: 'গ্যাস সিলিন্ডার' },
                { id: 'cook_salary', label: 'বাবুর্চির বেতন' },
                { id: 'electricity', label: 'বিদ্যুৎ বিল' },
                { id: 'water_repairs', label: 'জল/মেরামত' },
                { id: 'other', label: 'অন্যান্য' }
              ].map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                    selectedCategory === cat.id
                      ? 'bg-slate-900 text-white'
                      : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            <div className="text-xs text-slate-500 font-mono">
              মোট খরচ এন্ট্রি: {filteredExpenses.length} টি
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase text-[11px] font-semibold">
                <tr>
                  <th className="py-3 px-4">তারিখ</th>
                  <th className="py-3 px-4">ক্যাটাগরি</th>
                  <th className="py-3 px-4">খরচের বিবরণ</th>
                  <th className="py-3 px-3">প্রদানকারী তহবিল</th>
                  <th className="py-3 px-4 text-right">টাকার পরিমাণ (₹)</th>
                  <th className="py-3 px-4 text-center">মুছুন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredExpenses.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-400">
                      কোনো মেস খরচ পাওয়া যায়নি।
                    </td>
                  </tr>
                ) : (
                  filteredExpenses.map(expense => {
                    const catInfo = getExpenseCategoryLabel(expense.category);
                    return (
                      <tr key={expense.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3 px-4 whitespace-nowrap text-slate-600 font-mono text-xs">
                          {formatDateBengali(expense.date)}
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-medium ${catInfo.badgeColor}`}>
                            {getCategoryIcon(expense.category)}
                            {catInfo.label}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-semibold text-slate-900">{expense.title}</div>
                          {expense.note && (
                            <div className="text-[11px] text-slate-500 mt-0.5">{expense.note}</div>
                          )}
                        </td>
                        <td className="py-3 px-3 text-slate-600 whitespace-nowrap text-xs">
                          {expense.paidBy}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums font-bold text-slate-900 text-sm">
                          {formatCurrency(expense.amount)}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <button
                            onClick={() => deleteMessExpense(expense.id)}
                            className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors"
                            title="মুছে ফেলুন"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ২. সাপ্তাহিক খাবার ও মাসিক রুম ভাড়া সংগ্রহ ভিউ */}
      {activeSubTab === 'collections' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          {/* ফিল্টার বার */}
          <div className="p-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-slate-50/50">
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-500 font-medium">সংগ্রহের ধরন:</span>
              <button
                onClick={() => setCollectionTypeFilter('all')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                  collectionTypeFilter === 'all'
                    ? 'bg-slate-900 text-white'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                সব কালেকশন
              </button>
              <button
                onClick={() => setCollectionTypeFilter('meal_cost')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                  collectionTypeFilter === 'meal_cost'
                    ? 'bg-emerald-700 text-white'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                সাপ্তাহিক খাবার খরচ (Meal)
              </button>
              <button
                onClick={() => setCollectionTypeFilter('room_rent')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                  collectionTypeFilter === 'room_rent'
                    ? 'bg-blue-700 text-white'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                মাসিক রুম ভাড়া (Room Rent)
              </button>
            </div>

            <div className="text-xs text-slate-500">
              মোট সংগৃহীত: <strong className="font-mono text-slate-900">{formatCurrency(filteredCollections.reduce((sum, c) => sum + c.amount, 0))}</strong>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase text-[11px] font-semibold">
                <tr>
                  <th className="py-3 px-4">লেবারের নাম ও ফোন</th>
                  <th className="py-3 px-4">সংগ্রহের ধরন</th>
                  <th className="py-3 px-4">সপ্তাহ / সময়কাল</th>
                  <th className="py-3 px-3">তারিখ ও মাধ্যম</th>
                  <th className="py-3 px-4 text-right">আদায়ের পরিমাণ (₹)</th>
                  <th className="py-3 px-4 text-center">মুছুন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredCollections.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-400">
                      কোনো কালেকশন রেকর্ড পাওয়া যায়নি।
                    </td>
                  </tr>
                ) : (
                  filteredCollections.map(col => {
                    const labour = labours.find(l => l.id === col.labourId);
                    const isMeal = col.type === 'meal_cost';
                    return (
                      <tr key={col.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3 px-4">
                          <div className="font-semibold text-slate-900">{labour?.name || 'অজ্ঞাত লেবার'}</div>
                          <div className="text-[11px] text-slate-500 font-mono">{labour?.phone}</div>
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <span className={`inline-block px-2 py-0.5 rounded text-xs font-medium ${
                            isMeal ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-blue-50 text-blue-800 border border-blue-200'
                          }`}>
                            {isMeal ? 'সাপ্তাহিক খাবার খরচ' : 'মাসিক রুম ভাড়া'}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-medium text-slate-800">
                          {col.periodLabel}
                        </td>
                        <td className="py-3 px-3 text-slate-600 text-xs">
                          <div>{formatDateBengali(col.date)}</div>
                          <div className="text-[10px] text-slate-400 uppercase mt-0.5">{getPaymentMethodLabel(col.paymentMethod)}</div>
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums font-bold text-slate-900 text-sm">
                          {formatCurrency(col.amount)}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <button
                            onClick={() => deleteMessCollection(col.id)}
                            className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors"
                            title="মুছে ফেলুন"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ৩. লেবারদের এন্ট্রি ও এক্সিট এবং কাজের ধরন ও থাকার স্ট্যাটাস ট্র্যাকার */}
      {activeSubTab === 'members' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          {/* ফিল্টার বার */}
          <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/50">
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span className="text-slate-500 font-medium">কাজের ধরন ফিল্টার:</span>
              <button
                onClick={() => setMemberRoleFilter('all')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                  memberRoleFilter === 'all'
                    ? 'bg-slate-900 text-white'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                সব লেবার
              </button>
              <button
                onClick={() => setMemberRoleFilter('mess_and_site')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                  memberRoleFilter === 'mess_and_site'
                    ? 'bg-emerald-700 text-white'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                মেসে থাকে ও সাইটে কাজ করে
              </button>
              <button
                onClick={() => setMemberRoleFilter('mess_only')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                  memberRoleFilter === 'mess_only'
                    ? 'bg-amber-700 text-white'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                মেসে থাকে কিন্তু বাইরে কাজ করে
              </button>
              <button
                onClick={() => setMemberRoleFilter('site_only')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                  memberRoleFilter === 'site_only'
                    ? 'bg-blue-700 text-white'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                সাইটে কাজ করে কিন্তু মেসে থাকে না
              </button>
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="লেবারের নাম খুঁজুন..."
                value={searchMember}
                onChange={e => setSearchMember(e.target.value)}
                className="pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase text-[11px] font-semibold">
                <tr>
                  <th className="py-3 px-4">লেবারের নাম ও ফোন</th>
                  <th className="py-3 px-4">কাজের ধরন ও স্ট্যাটাস</th>
                  <th className="py-3 px-3">ট্রেড/দক্ষতা</th>
                  <th className="py-3 px-3">মেসে ওঠার তারিখ (Entry)</th>
                  <th className="py-3 px-3">মেস ছাড়ার তারিখ (Exit)</th>
                  <th className="py-3 px-3">মেসে থাকার স্ট্যাটাস</th>
                  <th className="py-3 px-4 text-center">তারিখ ও স্ট্যাটাস এডিট</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredMembers.map(labour => {
                  const roleBadge = getRoleTypeBadge(labour.roleType);
                  const isCurrentlyInMess = (labour.roleType !== 'site_only') && (!labour.messStayEndDate || new Date(labour.messStayEndDate) >= new Date());

                  return (
                    <tr key={labour.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900">{labour.name}</div>
                        <div className="text-[11px] text-slate-500 font-mono">{labour.phone}</div>
                      </td>

                      <td className="py-3 px-4">
                        <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-medium border ${roleBadge.badgeClass}`}>
                          {roleBadge.label}
                        </span>
                        <p className="text-[10px] text-slate-400 mt-0.5">{roleBadge.description}</p>
                      </td>

                      <td className="py-3 px-3 text-slate-700 font-medium">
                        {labour.trade}
                      </td>

                      <td className="py-3 px-3 text-slate-700 font-mono text-xs whitespace-nowrap">
                        {labour.roleType === 'site_only' ? (
                          <span className="text-slate-400">মেসে থাকে না</span>
                        ) : (
                          formatDateBengali(labour.messStayStartDate)
                        )}
                      </td>

                      <td className="py-3 px-3 text-slate-700 font-mono text-xs whitespace-nowrap">
                        {labour.roleType === 'site_only' ? (
                          <span className="text-slate-400">-</span>
                        ) : labour.messStayEndDate ? (
                          <span className="text-rose-600 font-semibold">{formatDateBengali(labour.messStayEndDate)}</span>
                        ) : (
                          <span className="text-emerald-700 font-medium">বর্তমানে রয়েছে (সক্রিয়)</span>
                        )}
                      </td>

                      <td className="py-3 px-3 whitespace-nowrap">
                        {labour.roleType === 'site_only' ? (
                          <span className="text-slate-400 text-xs">বাইরের বাসিন্দা</span>
                        ) : isCurrentlyInMess ? (
                          <span className="inline-flex items-center gap-1 text-xs text-emerald-700 font-semibold">
                            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                            মেসে সক্রিয়
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-xs text-slate-500">
                            <span className="w-2 h-2 rounded-full bg-slate-400"></span>
                            মেস ছেড়েছে
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-center">
                        <button
                          onClick={() => {
                            setEditingLabourForStay(labour);
                            setStayDatesForm({
                              startDate: labour.messStayStartDate || new Date().toISOString().slice(0, 10),
                              endDate: labour.messStayEndDate || '',
                              roleType: labour.roleType
                            });
                          }}
                          className="px-2.5 py-1 text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 rounded transition-colors flex items-center gap-1 mx-auto"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>এডিট</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* মডাল ১: মেস খরচ এন্ট্রি */}
      {showExpenseModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">নতুন মেস খরচ ভাউচার এন্ট্রি</h3>
              <button onClick={() => setShowExpenseModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                if (!expenseForm.title || !expenseForm.amount) return;
                addMessExpense({
                  ...expenseForm,
                  amount: Number(expenseForm.amount)
                });
                setShowExpenseModal(false);
              }}
              className="space-y-4 mt-4 text-xs sm:text-sm"
            >
              <div>
                <label className="block font-medium text-slate-700 mb-1">খরচের ক্যাটাগরি *</label>
                <select
                  value={expenseForm.category}
                  onChange={e => setExpenseForm({ ...expenseForm, category: e.target.value as any })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                >
                  <option value="bazar">কাঁচাবাজার ও খাদ্যসামগ্রী (চাল, ডাল, তেল, সবজি)</option>
                  <option value="gas">গ্যাস সিলিন্ডার রিফিল</option>
                  <option value="cook_salary">বাবুর্চির বেতন / পারিশ্রমিক</option>
                  <option value="electricity">বিদ্যুৎ বিল (Electric Bill)</option>
                  <option value="water_repairs">জল, প্লাম্বিং ও মেস মেরামত</option>
                  <option value="other">অন্যান্য জরুরি খরচ</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">খরচের বিবরণ / টাইটেল *</label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: সপ্তাহের রেশন ও মাছ-সবজির বাজার"
                  value={expenseForm.title}
                  onChange={e => setExpenseForm({ ...expenseForm, title: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">টাকার পরিমাণ (₹) *</label>
                  <input
                    type="number"
                    required
                    min="10"
                    step="10"
                    value={expenseForm.amount}
                    onChange={e => setExpenseForm({ ...expenseForm, amount: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono font-bold text-base"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">তারিখ</label>
                  <input
                    type="date"
                    value={expenseForm.date}
                    onChange={e => setExpenseForm({ ...expenseForm, date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">প্রদানকারী তহবিল</label>
                <select
                  value={expenseForm.paidBy}
                  onChange={e => setExpenseForm({ ...expenseForm, paidBy: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                >
                  <option value="মেস ম্যানেজার তহবিল">মেস ম্যানেজার তহবিল (লেবারদের চাঁদা থেকে)</option>
                  <option value="কন্ট্রাক্টর তহবিল">কন্ট্রাক্টর নিজস্ব তহবিল (অগ্রিম)</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">নোট / মেমো নং</label>
                <input
                  type="text"
                  placeholder="যেমন: ক্যাশ রসিদ নং ১২৩"
                  value={expenseForm.note}
                  onChange={e => setExpenseForm({ ...expenseForm, note: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowExpenseModal(false)}
                  className="px-4 py-2 border border-slate-200 rounded-lg text-slate-600"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-medium"
                >
                  খরচ জমা করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* মডাল ২: সাপ্তাহিক খাবার ও রুম ভাড়া কালেকশন এন্ট্রি */}
      {showCollectionModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">লেবার চাঁদা / ভাড়া সংগ্রহ এন্ট্রি</h3>
              <button onClick={() => setShowCollectionModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                if (!collectionForm.labourId || !collectionForm.amount) return;
                addMessCollection({
                  ...collectionForm,
                  amount: Number(collectionForm.amount)
                });
                setShowCollectionModal(false);
              }}
              className="space-y-4 mt-4 text-xs sm:text-sm"
            >
              <div>
                <label className="block font-medium text-slate-700 mb-1">সংগ্রহের ধরন *</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setCollectionForm({ ...collectionForm, type: 'meal_cost', amount: 750, periodLabel: '১ম সপ্তাহ (মার্চ)' })}
                    className={`py-2 px-3 rounded-lg text-xs font-semibold border ${
                      collectionForm.type === 'meal_cost'
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-800'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    সাপ্তাহিক খাবার খরচ (Meal)
                  </button>
                  <button
                    type="button"
                    onClick={() => setCollectionForm({ ...collectionForm, type: 'room_rent', amount: 1500, periodLabel: 'মার্চ ২০২৫' })}
                    className={`py-2 px-3 rounded-lg text-xs font-semibold border ${
                      collectionForm.type === 'room_rent'
                        ? 'bg-blue-50 border-blue-500 text-blue-800'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    মাসিক রুম ভাড়া (Rent)
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">লেবার নির্বাচন করুন *</label>
                <select
                  required
                  value={collectionForm.labourId}
                  onChange={e => setCollectionForm({ ...collectionForm, labourId: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                >
                  <option value="">-- লেবার বাছুন --</option>
                  {labours
                    .filter(l => l.roleType !== 'site_only') // শুধুমাত্র যারা মেসে থাকে
                    .map(l => (
                      <option key={l.id} value={l.id}>
                        {l.name} ({l.roleType === 'mess_only' ? 'বাইরে কাজ করা লেবার' : 'সাইটের লেবার'})
                      </option>
                    ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">সপ্তাহ / পিরিয়ড</label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: ১ম সপ্তাহ (মার্চ)"
                    value={collectionForm.periodLabel}
                    onChange={e => setCollectionForm({ ...collectionForm, periodLabel: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">টাকার পরিমাণ (₹) *</label>
                  <input
                    type="number"
                    required
                    min="50"
                    step="50"
                    value={collectionForm.amount}
                    onChange={e => setCollectionForm({ ...collectionForm, amount: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono font-bold text-base text-emerald-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">পেমেন্ট মাধ্যম</label>
                  <select
                    value={collectionForm.paymentMethod}
                    onChange={e => setCollectionForm({ ...collectionForm, paymentMethod: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  >
                    <option value="cash">নগদ (Cash)</option>
                    <option value="upi">UPI / অনলাইন</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">তারিখ</label>
                  <input
                    type="date"
                    value={collectionForm.date}
                    onChange={e => setCollectionForm({ ...collectionForm, date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  />
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowCollectionModal(false)}
                  className="px-4 py-2 border border-slate-200 rounded-lg text-slate-600"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-medium"
                >
                  সংগ্রহ নিশ্চিত করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* মডাল ৩: মেস এন্ট্রি ও এক্সিট তারিখ এবং কাজের ধরন আপডেট */}
      {editingLabourForStay && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">মেসে থাকার তারিখ ও কাজের ধরন এডিট</h3>
                <p className="text-xs text-slate-500">{editingLabourForStay.name}</p>
              </div>
              <button onClick={() => setEditingLabourForStay(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                updateLabour(editingLabourForStay.id, {
                  messStayStartDate: stayDatesForm.startDate,
                  messStayEndDate: stayDatesForm.endDate || null,
                  roleType: stayDatesForm.roleType
                });
                setEditingLabourForStay(null);
              }}
              className="space-y-4 mt-4 text-xs sm:text-sm"
            >
              <div>
                <label className="block font-medium text-slate-700 mb-1">কাজের ধরন ও থাকার স্ট্যাটাস *</label>
                <select
                  value={stayDatesForm.roleType}
                  onChange={e => setStayDatesForm({ ...stayDatesForm, roleType: e.target.value as any })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                >
                  <option value="mess_and_site">১. মেসে থাকে ও সাইটে কাজ করে</option>
                  <option value="mess_only">২. মেসে থাকে কিন্তু বাইরে নিজের কাজ খুঁজে খায়</option>
                  <option value="site_only">৩. সাইটে কাজ করে কিন্তু মেসে থাকে না</option>
                </select>
                <span className="block text-[11px] text-slate-500 mt-1">
                  বাইরে কাজ করা লেবারদের থেকে মেসের খাবার খরচ ও রুম ভাড়া নেওয়া হয় কিন্তু সাইট মজুরিতে ধরা হয় না।
                </span>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">মেসে ওঠার তারিখ (Stay Start Date) *</label>
                <input
                  type="date"
                  required
                  value={stayDatesForm.startDate}
                  onChange={e => setStayDatesForm({ ...stayDatesForm, startDate: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  মেস ছাড়ার তারিখ (Stay End Date - ঐচ্ছিক)
                </label>
                <input
                  type="date"
                  value={stayDatesForm.endDate}
                  onChange={e => setStayDatesForm({ ...stayDatesForm, endDate: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                />
                <span className="block text-[11px] text-slate-400 mt-1">
                  লেবার বর্তমানে মেসে থাকলে এই ঘরটি ফাঁকা রাখুন।
                </span>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingLabourForStay(null)}
                  className="px-4 py-2 border border-slate-200 rounded-lg text-slate-600"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-medium"
                >
                  আপডেট সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
