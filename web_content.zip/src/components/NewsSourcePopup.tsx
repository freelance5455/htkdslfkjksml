/**
 * HELENA - News & Information Source Pop-up
 * Automatically pops up when HELENA answers an informational query,
 * displaying the source news portal or reference website.
 * Styled in dark green theme (--cor-anel, --cor-brilho, --cor-borda).
 */

import React from 'react';
import { ExternalLink, Globe, X, Newspaper, CheckCircle2 } from 'lucide-react';

export interface NewsSourceInfo {
  url: string;
  title: string;
  query: string;
  snippet?: string;
}

interface NewsSourcePopupProps {
  source: NewsSourceInfo | null;
  isOpen: boolean;
  onClose: () => void;
}

export const NewsSourcePopup: React.FC<NewsSourcePopupProps> = ({
  source,
  isOpen,
  onClose,
}) => {
  if (!isOpen || !source) return null;

  const handleOpenExternal = () => {
    window.open(source.url, '_blank', 'noopener,noreferrer');
  };

  // Derive display domain
  let domain = 'google.com';
  try {
    const parsed = new URL(source.url);
    domain = parsed.hostname.replace('www.', '');
  } catch {}

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div 
        className="bg-[#030d06] border border-[#14502D] rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 text-[#CDEBD8]"
        style={{ borderColor: 'var(--cor-borda)' }}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#14502D]/60">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-[#0E7A3D]/20 border border-[#0E7A3D] rounded-xl text-[#2FD16F]">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white tracking-wide">
                Fonte & Referência Científica
              </h3>
              <p className="text-[11px] text-[#CDEBD8]/60 font-mono">
                Base de dados e literatura recomendada
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-[#CDEBD8]/70 hover:text-white rounded-lg hover:bg-[#14502D]/40 transition min-h-[40px] min-w-[40px] flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Details */}
        <div className="space-y-3">
          <div className="p-3.5 bg-black/60 border border-[#14502D]/80 rounded-xl space-y-1.5">
            <div className="flex items-center space-x-2 text-xs text-[#2FD16F] font-mono">
              <Globe className="w-3.5 h-3.5" />
              <span>{domain}</span>
            </div>
            <h4 className="text-sm font-semibold text-white leading-snug">
              {source.title}
            </h4>
            {source.snippet && (
              <p className="text-xs text-[#CDEBD8]/75 leading-relaxed">
                "{source.snippet}"
              </p>
            )}
          </div>

          <div className="flex items-center space-x-1.5 text-[11px] text-[#CDEBD8]/50">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#2FD16F]" />
            <span>Consenso acadêmico verificado pela HELENA</span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end space-x-2 pt-2">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl border border-[#14502D] hover:bg-[#14502D]/40 text-xs text-[#CDEBD8] transition min-h-[44px] cursor-pointer"
          >
            Fechar
          </button>
          <button
            onClick={handleOpenExternal}
            className="flex items-center space-x-1.5 px-5 py-2.5 rounded-xl bg-[#0E7A3D] hover:bg-[#17B35A] text-xs font-semibold text-white shadow-lg shadow-[#0E7A3D]/25 transition min-h-[44px] cursor-pointer"
          >
            <span>Acessar Artigo / Referência</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
