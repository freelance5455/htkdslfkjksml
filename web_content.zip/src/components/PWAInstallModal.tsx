import React, { useState } from 'react';
import { X, Smartphone, Download, Check, Copy, ExternalLink, Sparkles, ShieldCheck } from 'lucide-react';
import { usePWAInstall } from '../utils/usePWAInstall';

interface PWAInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PWAInstallModal: React.FC<PWAInstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [installSuccess, setInstallSuccess] = useState(false);

  if (!isOpen) return null;

  const appUrl = typeof window !== 'undefined' ? window.location.origin : '';

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(appUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const handleInstallClick = async () => {
    if (isInstallable) {
      const res = await install();
      if (res) {
        setInstallSuccess(true);
        setTimeout(() => {
          onClose();
        }, 1500);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-neutral-400 hover:text-white p-2 rounded-xl hover:bg-neutral-800 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="relative inline-block mb-3">
            <img
              src="/sosiska-logo.png"
              alt="Sosiska AI"
              className="w-16 h-16 rounded-2xl object-cover border-2 border-orange-500/30 shadow-xl mx-auto"
            />
            <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center text-xs shadow-md">
              <Smartphone className="w-3.5 h-3.5" />
            </div>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">
            Установка Sosiska AI на телефон (APK)
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 mt-1 max-w-sm mx-auto">
            Используйте нейросеть как полноценное мобильное приложение на Android или iOS
          </p>
        </div>

        {/* Current status banner */}
        {isInstalled ? (
          <div className="mb-6 p-4 rounded-2xl bg-emerald-950/40 border border-emerald-800/60 text-emerald-300 text-xs flex items-center gap-3">
            <Check className="w-5 h-5 text-emerald-400 shrink-0" />
            <div>
              <div className="font-semibold text-emerald-200">Приложение уже установлено!</div>
              <div className="text-emerald-400/90 mt-0.5">Sosiska AI работает в нативном полноэкранном режиме.</div>
            </div>
          </div>
        ) : installSuccess ? (
          <div className="mb-6 p-4 rounded-2xl bg-emerald-950/40 border border-emerald-800/60 text-emerald-300 text-xs flex items-center gap-3">
            <Check className="w-5 h-5 text-emerald-400 shrink-0" />
            <div className="font-semibold text-emerald-200">Установка начата! Приложение появится на главном экране.</div>
          </div>
        ) : isInstallable ? (
          /* Direct 1-Click Install Button */
          <div className="mb-6 p-4 rounded-2xl bg-gradient-to-r from-orange-500/15 to-amber-500/10 border border-orange-500/30 text-center">
            <div className="text-xs text-orange-300 font-medium mb-3 flex items-center justify-center gap-1.5">
              <Sparkles className="w-4 h-4 text-orange-400" />
              <span>Ваш браузер готов к быстрой установке WebAPK:</span>
            </div>
            <button
              onClick={handleInstallClick}
              className="w-full py-3 px-4 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-semibold text-sm rounded-xl shadow-lg shadow-orange-500/25 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Установить Sosiska AI сейчас</span>
            </button>
          </div>
        ) : null}

        {/* Step-by-step instructions */}
        <div className="space-y-4 text-left">
          {/* Option 1: Android WebAPK (Automatic native APK creation) */}
          <div className="p-4 rounded-2xl bg-neutral-950/80 border border-neutral-800">
            <div className="flex items-center gap-2.5 mb-2 font-semibold text-sm text-white">
              <span className="w-6 h-6 rounded-lg bg-orange-500/20 text-orange-400 flex items-center justify-center text-xs font-bold">
                1
              </span>
              <span>Установка на Android (WebAPK / Приложение)</span>
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed pl-8">
              Откройте сайт в <strong>Google Chrome</strong> или <strong>Яндекс Браузере</strong> на телефоне:
            </p>
            <ol className="text-xs text-neutral-300 space-y-1.5 mt-2 pl-8 list-decimal list-inside">
              <li>
                Нажмите на меню (три точки <strong className="text-white">⋮</strong> в правом верхнем углу).
              </li>
              <li>
                Выберите пункт <strong className="text-orange-400">«Установить приложение»</strong> или <strong className="text-orange-400">«Добавить на главный экран»</strong>.
              </li>
              <li>
                Android автоматически создаст нативный <strong className="text-white">WebAPK</strong> с иконкой Сосиски в списке приложений!
              </li>
            </ol>
          </div>

          {/* Option 2: Build a Standalone .APK via PWABuilder */}
          <div className="p-4 rounded-2xl bg-neutral-950/80 border border-neutral-800">
            <div className="flex items-center gap-2.5 mb-2 font-semibold text-sm text-white">
              <span className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center text-xs font-bold">
                2
              </span>
              <span>Сборка готового файла .APK (для Google Play или установки)</span>
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed pl-8">
              Приложение уже содержит правильный <strong>PWA Manifest</strong>, иконки и Service Worker. Вы можете в 1 клик сгенерировать подписанный файл <strong>.apk</strong> через официальный инструмент Microsoft/Google:
            </p>
            <div className="mt-2.5 pl-8 space-y-2">
              <a
                href={`https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(appUrl)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white text-xs font-medium border border-neutral-700 transition-colors"
              >
                <span>Открыть сборщик PWABuilder (сгенерировать .apk)</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Option 3: iOS (iPhone / iPad) */}
          <div className="p-4 rounded-2xl bg-neutral-950/80 border border-neutral-800">
            <div className="flex items-center gap-2.5 mb-2 font-semibold text-sm text-white">
              <span className="w-6 h-6 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center text-xs font-bold">
                3
              </span>
              <span>Установка на iPhone / iPad</span>
            </div>
            <ol className="text-xs text-neutral-300 space-y-1.5 pl-8 list-decimal list-inside">
              <li>Откройте сайт в браузере <strong>Safari</strong>.</li>
              <li>Нажмите кнопку <strong>«Поделиться»</strong> (квадрат со стрелкой вверх).</li>
              <li>Пролистайте вниз и выберите <strong>«На экран «Домой»»</strong>.</li>
            </ol>
          </div>
          {/* Info callout about zip files */}
          <div className="p-3.5 rounded-2xl bg-neutral-900/90 border border-neutral-700/60 text-xs text-neutral-300">
            <div className="font-semibold text-amber-400 mb-1 flex items-center gap-1.5">
              <span>💡 Скачали архив с исходным кодом?</span>
            </div>
            <p className="text-[11px] text-neutral-400 leading-relaxed">
              Файлы <code className="text-neutral-200">server.ts</code>, <code className="text-neutral-200">package.json</code> и папки <code className="text-neutral-200">src/</code> — это исходный код проекта. Чтобы нейросеть работала на смартфоне, <strong>не нужно распаковывать архив в проводнике</strong>. Достаточно открыть ссылку на приложение в браузере Chrome и нажать «Установить».
            </p>
          </div>
        </div>

        {/* Share / Copy URL section */}
        <div className="mt-5 p-3.5 rounded-2xl bg-neutral-950/60 border border-neutral-800 flex items-center justify-between gap-2">
          <div className="truncate text-left flex-1 min-w-0">
            <div className="text-[11px] text-neutral-400">Ссылка для открытия на смартфоне:</div>
            <div className="text-xs font-mono text-orange-400 truncate mt-0.5">{appUrl}</div>
          </div>
          <button
            onClick={handleCopyUrl}
            className="shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs font-medium text-white transition-colors cursor-pointer"
          >
            {copiedUrl ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">Скопировано</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Копировать</span>
              </>
            )}
          </button>
        </div>

        {/* Security badge */}
        <div className="mt-4 flex items-center justify-center gap-1.5 text-[11px] text-neutral-500">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
          <span>Безопасная установка без вирусов и рекламы</span>
        </div>
      </div>
    </div>
  );
};
