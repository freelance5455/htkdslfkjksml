import React from "react";
import {
  X,
  Smartphone,
  Download,
  CheckCircle2,
  Share,
  PlusSquare,
  Zap,
  WifiOff,
  ExternalLink,
  ShieldCheck,
  AlertCircle,
  HelpCircle,
} from "lucide-react";
import { InstallDiagnosticReason } from "../hooks/usePWAInstall";

interface PWAInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  isInstallable: boolean;
  onAutoInstall: () => void;
  isIOS: boolean;
  isAndroid: boolean;
  isInIframe: boolean;
  isSecure: boolean;
  diagnosticReason: InstallDiagnosticReason;
  onOpenDirectTab: () => void;
}

export const PWAInstallModal: React.FC<PWAInstallModalProps> = ({
  isOpen,
  onClose,
  isInstallable,
  onAutoInstall,
  isIOS,
  isAndroid,
  isInIframe,
  isSecure,
  diagnosticReason,
  onOpenDirectTab,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden border border-slate-200 max-h-[90vh] flex flex-col animate-in slide-in-from-bottom-6 sm:slide-in-from-bottom-2 duration-300">
        {/* Header with App Logo */}
        <div className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 p-5 text-white flex items-start justify-between relative overflow-hidden shrink-0">
          <div className="absolute -right-8 -top-8 w-28 h-28 rounded-full bg-emerald-500/20 blur-xl pointer-events-none" />

          <div className="flex items-center gap-3.5 relative z-10">
            <div className="w-12 h-12 rounded-2xl bg-white/10 border border-white/20 p-2 shrink-0 flex items-center justify-center shadow-inner">
              <img
                src="/icon.svg"
                alt="Ceiling Calculation"
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-extrabold uppercase tracking-wider bg-emerald-500 text-slate-950 px-2 py-0.5 rounded-full">
                  OFFICIAL PWA APP
                </span>
              </div>
              <h3 className="font-extrabold text-lg text-white mt-0.5 leading-tight">
                Install "Ceiling Calculation"
              </h3>
              <p className="text-xs text-indigo-200">
                Direct Android & Mobile Home Screen App
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white/80 hover:text-white transition-colors z-10"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-4">
          {/* Highlights row */}
          <div className="grid grid-cols-2 gap-2 text-[11px] font-semibold text-slate-700">
            <div className="bg-indigo-50/80 border border-indigo-100 p-2.5 rounded-xl flex items-center gap-2">
              <Zap className="w-4 h-4 text-indigo-600 shrink-0" />
              <span>Full-screen App Experience</span>
            </div>
            <div className="bg-emerald-50/80 border border-emerald-100 p-2.5 rounded-xl flex items-center gap-2">
              <WifiOff className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>100% Offline Calculator</span>
            </div>
          </div>

          {/* 1. Native Prompt Available (Direct 1-tap) */}
          {isInstallable && (
            <div className="bg-emerald-50 border-2 border-emerald-500/80 p-4 rounded-2xl space-y-3 text-center shadow-sm">
              <div className="flex items-center justify-center gap-1.5 text-emerald-950 font-bold text-xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Browser Installation Prompt is Ready!</span>
              </div>
              <button
                onClick={() => {
                  onAutoInstall();
                }}
                className="w-full bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-black py-3.5 px-4 rounded-xl flex items-center justify-center gap-2 text-sm shadow-md uppercase tracking-wide active:scale-95 transition-all"
              >
                <Download className="w-4 h-4 stroke-[2.5]" />
                <span>CLICK TO INSTALL NOW (अभी इंस्टॉल करें)</span>
              </button>
            </div>
          )}

          {/* 2. Iframe Context Notice (AI Studio / Embedded preview) */}
          {isInIframe && (
            <div className="bg-amber-50 border border-amber-300 p-4 rounded-2xl space-y-3 text-xs text-amber-950">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-extrabold text-amber-950 text-xs uppercase tracking-wide">
                    Android Installation Notice (Preview Window)
                  </h4>
                  <p className="mt-1 leading-relaxed text-amber-900">
                    Android Chrome security blocks direct app installation inside embedded preview frames. To install the app directly on your phone, open it in a direct Chrome tab:
                  </p>
                </div>
              </div>

              <button
                onClick={onOpenDirectTab}
                className="w-full bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-black py-3 px-4 rounded-xl flex items-center justify-center gap-2 text-xs uppercase tracking-wide shadow-md transition-all active:scale-95"
              >
                <ExternalLink className="w-4 h-4" />
                <span>🌐 Open in Chrome Tab (नये टैब में खोलें)</span>
              </button>
            </div>
          )}

          {/* 3. Step-by-Step Installation Instructions */}
          <div className="space-y-3">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
              <Smartphone className="w-4 h-4 text-indigo-600" />
              <span>
                {isIOS
                  ? "iPhone / iPad Safari Installation"
                  : "Android Google Chrome Installation (Step-by-Step)"}
              </span>
            </h4>

            {isIOS ? (
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3 text-xs text-slate-700">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center shrink-0 text-xs">
                    1
                  </div>
                  <div>
                    Safari browser ke neeche <strong>Share</strong> button{" "}
                    <Share className="w-3.5 h-3.5 inline mx-1 text-indigo-600" />{" "}
                    par tap karein.
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center shrink-0 text-xs">
                    2
                  </div>
                  <div>
                    Menu ko scroll karke <strong>Add to Home Screen</strong>{" "}
                    <PlusSquare className="w-3.5 h-3.5 inline mx-1 text-indigo-600" />{" "}
                    par tap karein.
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center shrink-0 text-xs">
                    3
                  </div>
                  <div>
                    Top right corner mein <strong>Add</strong> par click karein.
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3 text-xs text-slate-700">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center shrink-0 text-xs">
                    1
                  </div>
                  <div>
                    Google Chrome browser ke top right corner mein <strong>3-dots menu (⋮)</strong> par tap karein.
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center shrink-0 text-xs">
                    2
                  </div>
                  <div>
                    Menu mein se <strong>"Install app" (ऐप इंस्टॉल करें)</strong> ya <strong>"Add to Home screen" (होम स्क्रीन पर जोड़ें)</strong> option par tap karein.
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center shrink-0 text-xs">
                    3
                  </div>
                  <div>
                    Screen par aane wale popup mein <strong>"Install"</strong> par click karein. App aapke phone ki home screen par <strong>Ceiling Calculation</strong> ke icon ke saath install ho jayegi!
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Technical PWA Audit & Compliance Status */}
          <div className="bg-slate-100/80 rounded-2xl p-3.5 border border-slate-200 text-[11px] text-slate-600 space-y-2">
            <div className="flex items-center gap-1.5 font-bold text-slate-900">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>PWA Technical Readiness Audit</span>
            </div>
            <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-[10px] text-slate-600">
              <div className="flex items-center gap-1">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>Manifest: manifest.json</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>Display: standalone</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>Service Worker: sw.js</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>Icons: 192px & 512px PNG</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>Security: HTTPS</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>Offline Cache: Active</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center gap-2 shrink-0">
          {isInIframe && (
            <button
              onClick={onOpenDirectTab}
              className="flex-1 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-bold py-3 rounded-xl text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5 shadow-sm"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Open in New Tab</span>
            </button>
          )}
          <button
            onClick={onClose}
            className="flex-1 bg-slate-900 hover:bg-slate-800 text-white font-bold py-3 rounded-xl text-xs uppercase tracking-wider transition-colors text-center"
          >
            Close / Samajh Gaya
          </button>
        </div>
      </div>
    </div>
  );
};
