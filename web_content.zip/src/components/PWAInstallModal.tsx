import React, { useState } from 'react';
import {
  Download,
  X,
  Smartphone,
  CheckCircle2,
  Share2,
  PlusSquare,
  Sparkles,
  Monitor,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { useApp } from '../context/AppContext';

interface PWAInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PWAInstallModal: React.FC<PWAInstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const { language } = useApp();
  const [activeGuideTab, setActiveGuideTab] = useState<'android' | 'ios' | 'pc'>('android');

  if (!isOpen) return null;

  const isBn = language === 'bn';

  const handleInstallClick = async () => {
    const success = await install();
    if (success) {
      onClose();
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-6 shadow-2xl transition-all max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          aria-label="Close"
        >
          <X size={18} />
        </button>

        {/* Brand Header */}
        <div className="flex items-center gap-3.5 mb-5">
          <img
            src="/icon.svg"
            alt="Habivio App Icon"
            className="w-14 h-14 rounded-2xl shadow-md ring-2 ring-violet-500/30"
          />
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">
                {isBn ? 'হাবিভিও অ্যাপ ইনস্টল করুন' : 'Install Habivio App'}
              </h3>
              <Sparkles size={16} className="text-amber-500" />
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {isBn ? 'আপনার মোবাইলের হোম স্ক্রিনে সরাসরি সেভ করুন' : 'Your Day, Your Way — Add to Home Screen'}
            </p>
          </div>
        </div>

        {/* Direct Link Action Bar for Mobile Browsers */}
        <div className="mb-4 p-3 rounded-2xl bg-linear-to-r from-violet-500/10 via-indigo-500/10 to-sky-500/10 border border-violet-500/20 flex items-center justify-between gap-2">
          <div className="min-w-0 flex-1">
            <span className="text-xs font-bold text-slate-900 dark:text-white block">
              {isBn ? 'সরাসরি ব্রাউজারে খোলার লিঙ্ক' : 'Direct Link for Chrome/Safari'}
            </span>
            <span className="text-[10px] text-slate-500 dark:text-slate-400 block truncate">
              {isBn ? 'লিঙ্ক কপি করে Google Chrome-এ পেস্ট করুন' : 'Copy and paste directly in Chrome'}
            </span>
          </div>

          <button
            onClick={() => {
              try {
                navigator.clipboard.writeText(window.location.href);
                alert(isBn ? 'লিঙ্ক কপি হয়েছে! এবার আপনার ফোনের Chrome ব্রাউজারে পেস্ট করুন।' : 'Link copied! Now paste into Google Chrome on your phone.');
              } catch {
                // ignore
              }
            }}
            className="px-3 py-1.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-xs font-bold shrink-0 shadow-xs active:scale-95 transition-all"
          >
            {isBn ? 'লিঙ্ক কপি' : 'Copy'}
          </button>
        </div>

        {/* If native install prompt is directly ready */}
        {isInstallable && !isInstalled && (
          <div className="mb-5 p-4 rounded-2xl bg-linear-to-r from-violet-600 to-indigo-600 text-white shadow-lg shadow-violet-500/20">
            <h4 className="text-sm font-bold mb-1">
              {isBn ? 'এক ক্লিকে ইনস্টল করুন' : 'Instant One-Click Install'}
            </h4>
            <p className="text-xs text-white/90 mb-3">
              {isBn
                ? 'ব্রাউজার ছাড়াই আসল অ্যান্ড্রয়েড অ্যাপের মতো ব্যবহার করতে নিচের বাটনে চাপুন।'
                : 'Install Habivio as a standalone lightweight app with instant offline support.'}
            </p>
            <button
              onClick={handleInstallClick}
              className="w-full py-2.5 px-4 rounded-xl bg-white text-violet-700 font-bold text-xs flex items-center justify-center gap-2 shadow-sm hover:bg-slate-100 active:scale-95 transition-all"
            >
              <Download size={16} />
              <span>{isBn ? 'এখনই অ্যাপ ইনস্টল করুন' : 'Install Now'}</span>
            </button>
          </div>
        )}

        {isInstalled && (
          <div className="mb-4 p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
            <span>
              {isBn
                ? 'হাবিভিও ইতিমধ্যে আপনার ডিভাইসে ইনস্টল করা আছে!'
                : 'Habivio is already installed on this device!'}
            </span>
          </div>
        )}

        {/* Device Step-by-Step Guide Tabs */}
        <div>
          <div className="flex p-1 rounded-xl bg-slate-100 dark:bg-slate-800 mb-4 text-xs font-bold">
            <button
              onClick={() => setActiveGuideTab('android')}
              className={`flex-1 py-1.5 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                activeGuideTab === 'android'
                  ? 'bg-white dark:bg-slate-700 text-violet-600 dark:text-violet-300 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <Smartphone size={14} />
              <span>Android</span>
            </button>
            <button
              onClick={() => setActiveGuideTab('ios')}
              className={`flex-1 py-1.5 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                activeGuideTab === 'ios'
                  ? 'bg-white dark:bg-slate-700 text-violet-600 dark:text-violet-300 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <Share2 size={14} />
              <span>iPhone (iOS)</span>
            </button>
            <button
              onClick={() => setActiveGuideTab('pc')}
              className={`flex-1 py-1.5 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                activeGuideTab === 'pc'
                  ? 'bg-white dark:bg-slate-700 text-violet-600 dark:text-violet-300 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <Monitor size={14} />
              <span>PC / Laptop</span>
            </button>
          </div>

          {/* Android Steps */}
          {activeGuideTab === 'android' && (
            <div className="space-y-3 text-xs text-slate-700 dark:text-slate-300">
              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200/80 dark:border-slate-800 flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-violet-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                  1
                </span>
                <div>
                  <strong className="text-slate-900 dark:text-white block mb-0.5">
                    {isBn ? 'ব্রাউজার মেনু খুলুন' : 'Open Browser Menu'}
                  </strong>
                  <span>
                    {isBn
                      ? 'Chrome বা আপনার মোবাইল ব্রাউজারের উপরে ডানদিকের তিনটি ডটে (⋮) চাপুন।'
                      : 'Tap the three dots (⋮) in the top-right corner of Google Chrome.'}
                  </span>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200/80 dark:border-slate-800 flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-violet-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                  2
                </span>
                <div>
                  <strong className="text-slate-900 dark:text-white block mb-0.5">
                    {isBn ? '"Install app" বা "Add to Home screen" চাপুন' : 'Select "Install app"'}
                  </strong>
                  <span>
                    {isBn
                      ? 'মেনু থেকে "Install app" অথবা "Add to Home screen" (হোম স্ক্রিনে যুক্ত করুন) অপশনটিতে ট্যাপ করুন।'
                      : 'Choose "Install app" or "Add to Home screen" from the menu options.'}
                  </span>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200/80 dark:border-slate-800 flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-violet-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                  3
                </span>
                <div>
                  <strong className="text-slate-900 dark:text-white block mb-0.5">
                    {isBn ? 'ইনস্টল নিশ্চিত করুন' : 'Confirm Installation'}
                  </strong>
                  <span>
                    {isBn
                      ? 'পপআপে "Install" চাপুন। অ্যাপটি সরাসরি আপনার ফোনের অ্যাপ ড্রয়ার ও হোম স্ক্রিনে চলে আসবে।'
                      : 'Tap "Install" on the confirmation prompt. Habivio will now appear as an icon on your home screen.'}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* iOS Steps */}
          {activeGuideTab === 'ios' && (
            <div className="space-y-3 text-xs text-slate-700 dark:text-slate-300">
              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200/80 dark:border-slate-800 flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-violet-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                  1
                </span>
                <div>
                  <strong className="text-slate-900 dark:text-white block mb-0.5">
                    {isBn ? 'Safari ব্রাউজারে শেয়ার বাটন চাপুন' : 'Tap Safari Share'}
                  </strong>
                  <span>
                    {isBn
                      ? 'Safari ব্রাউজারের নিচে থাকা শেয়ার আইকনে (বক্স থেকে উপরের দিকে তীর) চাপুন।'
                      : 'Tap the Share icon at the bottom of the Safari screen.'}
                  </span>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200/80 dark:border-slate-800 flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-violet-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                  2
                </span>
                <div>
                  <strong className="text-slate-900 dark:text-white block mb-0.5">
                    {isBn ? '"Add to Home Screen" অপশন বেছে নিন' : 'Tap "Add to Home Screen"'}
                  </strong>
                  <span>
                    {isBn
                      ? 'তালিকাটি স্ক্রল করে "Add to Home Screen" (প্লাস চিহ্নযুক্ত আইকন) নির্বাচন করুন।'
                      : 'Scroll down and select "Add to Home Screen" from the action sheet.'}
                  </span>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200/80 dark:border-slate-800 flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-violet-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                  3
                </span>
                <div>
                  <strong className="text-slate-900 dark:text-white block mb-0.5">
                    {isBn ? 'উপরে "Add" চাপুন' : 'Tap "Add"'}
                  </strong>
                  <span>
                    {isBn
                      ? 'উপরে ডানদিকের "Add" বাটনে চাপলেই আপনার আইফোনের হোম স্ক্রিনে অ্যাপ যুক্ত হয়ে যাবে।'
                      : 'Tap "Add" in the top-right corner to finish.'}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* PC / Laptop Steps */}
          {activeGuideTab === 'pc' && (
            <div className="space-y-3 text-xs text-slate-700 dark:text-slate-300">
              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200/80 dark:border-slate-800 flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-violet-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                  1
                </span>
                <div>
                  <strong className="text-slate-900 dark:text-white block mb-0.5">
                    {isBn ? 'এড্রেসবারের ইনস্টল আইকন' : 'Address Bar Icon'}
                  </strong>
                  <span>
                    {isBn
                      ? 'Chrome বা Edge ব্রাউজারের এড্রেসবারে (URL যেখানে লেখা থাকে) ডানপাশে থাকা ছোট কম্পিউটার/ডাউনলোড আইকনে ক্লিক করুন।'
                      : 'Look for the Install icon in the right side of the Chrome/Edge address bar.'}
                  </span>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200/80 dark:border-slate-800 flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-violet-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                  2
                </span>
                <div>
                  <strong className="text-slate-900 dark:text-white block mb-0.5">
                    {isBn ? '"Install" বাটনে ক্লিক করুন' : 'Click Install'}
                  </strong>
                  <span>
                    {isBn
                      ? 'পপআপে "Install" বাটনে চাপলে এটি ডেস্কটপ অ্যাপ হিসেবে ওপেন হবে এবং শর্টকাট তৈরি হবে।'
                      : 'Click Install in the prompt to run Habivio in a dedicated window.'}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Troubleshooting Box */}
        <div className="mt-4 p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-800/60 text-[11px] text-amber-900 dark:text-amber-200 space-y-1">
          <div className="font-bold flex items-center gap-1.5 text-amber-800 dark:text-amber-300">
            <span>{isBn ? 'ইনস্টল অপশন দেখতে পাচ্ছেন না?' : "Don't see the install option?"}</span>
          </div>
          <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
            {isBn
              ? 'নিশ্চিত করুন লিঙ্কটি আসল Google Chrome ব্রাউজারে খোলা হয়েছে। Chrome-এর ৩টি ডটে (⋮) চাপার পর "Install app" না পেলে "Add to Home screen" (হোম স্ক্রিনে যোগ করুন) চাপুন।'
              : 'Make sure this is opened directly in Google Chrome, not inside a social app or iframe. If you don\'t see "Install", look for "Add to Home screen".'}
          </p>
        </div>

        <button
          onClick={onClose}
          className="mt-5 w-full py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
        >
          {isBn ? 'ঠিক আছে / বন্ধ করুন' : 'Got it / Close'}
        </button>
      </div>
    </div>
  );
};
