import { useEffect, useState } from "react";
import { askLabAssistant, labAiStatus } from "@/lib/lab/ai.functions";
import { readmeCommands } from "@/lib/lab/commands";
import { projectBrief } from "@/lib/lab/report";
import { useLab } from "@/lib/lab/store";

type Provider = "locale" | "grok" | "compatible";

export function AssistantPanel({ onClose }: { onClose: () => void }) {
  const chat = useLab((s) => s.chat);
  const pending = useLab((s) => s.pending);
  const [text, setText] = useState("");
  const [provider, setProvider] = useState<Provider>("locale");
  const [busy, setBusy] = useState(false);
  const [grok, setGrok] = useState<boolean | null>(null);
  const [baseUrl, setBaseUrl] = useState("https://api.openai.com/v1");
  const [model, setModel] = useState("gpt-4o-mini");
  const [key, setKey] = useState("");
  const [remember, setRemember] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const raw = localStorage.getItem("officina-endpoint");
    if (!raw) return;
    try {
      const saved = JSON.parse(raw) as { baseUrl?: string; model?: string; key?: string; remember?: boolean };
      if (saved.baseUrl) setBaseUrl(saved.baseUrl);
      if (saved.model) setModel(saved.model);
      if (saved.remember && saved.key) {
        setRemember(true);
        setKey(saved.key);
      }
    } catch {
      /* impostazioni ignorate */
    }
  }, []);

  useEffect(() => {
    void labAiStatus().then((status) => setGrok(status.grok)).catch(() => setGrok(false));
  }, []);

  function persistEndpoint(nextRemember: boolean, nextKey: string) {
    localStorage.setItem(
      "officina-endpoint",
      JSON.stringify({
        baseUrl,
        model,
        remember: nextRemember,
        key: nextRemember ? nextKey : "",
      }),
    );
  }

  async function send() {
    const message = text.trim();
    if (!message || busy) return;
    setText("");
    setError(null);
    if (provider === "locale") {
      useLab.getState().runCommand(message);
      return;
    }
    const state = useLab.getState();
    state.pushChat("user", message);
    setBusy(true);
    try {
      const result = await askLabAssistant({
        data: {
          message,
          brief: projectBrief({
            projectName: state.projectName,
            assemblies: state.assemblies,
            parts: state.parts,
            joints: state.joints,
            ideas: state.ideas,
            study: state.study,
            rpm: state.sim.rpm,
          }),
          provider: provider === "grok" ? "grok" : "compatible",
          userKey: provider === "compatible" ? key : "",
          baseUrl,
          model,
        },
      });
      if (!result.ok) {
        setError(result.error);
        useLab.getState().pushChat("system", result.error);
        return;
      }
      useLab.getState().pushChat("assistant", result.reply);
      const mutating = result.actions.filter((action) => action.op !== "note");
      if (mutating.length) useLab.getState().setPending(result.reply, result.actions);
      else if (result.actions.length) useLab.getState().applyActions(result.actions, "assistente");
    } catch {
      setError("Chiamata non riuscita.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="lab-sheet">
      <header className="lab-header">
        <strong>Assistente</strong>
        <button type="button" className="lab-btn" onClick={onClose}>
          Chiudi
        </button>
      </header>
      <div className="lab-scroll lab-chat">
        <p className="lab-note">
          Locale: comandi del banco, senza rete. Grok e l'endpoint compatibile sono chiamate vere, solo quando invii. Le modifiche arrivano come azioni e vanno confermate.
        </p>
        <div className="lab-grid">
          <button type="button" className="lab-btn" data-on={provider === "locale"} onClick={() => setProvider("locale")}>
            Locale
          </button>
          <button type="button" className="lab-btn" data-on={provider === "grok"} onClick={() => setProvider("grok")}>
            Grok
          </button>
          <button type="button" className="lab-btn" data-on={provider === "compatible"} onClick={() => setProvider("compatible")}>
            Endpoint
          </button>
        </div>
        {provider === "grok" ? (
          <p className="lab-note">
            {grok === null ? "Controllo disponibilità…" : grok ? "Grok risponde da qui. Ogni messaggio consuma quota." : "Grok non è configurato in questo ambiente. Usa i comandi locali."}
          </p>
        ) : null}
        {provider === "compatible" ? (
          <div className="grid gap-2">
            <input aria-label="Indirizzo API" value={baseUrl} onChange={(event) => setBaseUrl(event.target.value)} onBlur={() => persistEndpoint(remember, key)} />
            <input aria-label="Modello" value={model} onChange={(event) => setModel(event.target.value)} onBlur={() => persistEndpoint(remember, key)} />
            <input
              aria-label="Chiave API"
              type="password"
              autoComplete="off"
              placeholder="Chiave, non viene messa nel progetto"
              value={key}
              onChange={(event) => setKey(event.target.value)}
              onBlur={() => persistEndpoint(remember, key)}
            />
            <label className="flex min-h-11 items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={remember}
                onChange={(event) => {
                  setRemember(event.target.checked);
                  persistEndpoint(event.target.checked, key);
                }}
              />
              Ricorda la chiave su questo dispositivo
            </label>
            <p className="lab-note">La chiave sta in chiaro nel browser se la ricordi. Non finisce nel file esportato. Su un telefono condiviso non ricordarla.</p>
          </div>
        ) : null}
        <div className="flex flex-wrap gap-1">
          {readmeCommands().map((hint) => (
            <button key={hint} type="button" className="lab-btn" onClick={() => setText(hint)}>
              {hint}
            </button>
          ))}
        </div>
        {chat.map((message) => (
          <p key={message.id} className="lab-bubble" data-role={message.role}>
            {message.text}
          </p>
        ))}
        {error ? <p className="lab-note">{error}</p> : null}
        {pending ? (
          <article className="lab-bubble">
            <strong>Confermi queste modifiche?</strong>
            <ul className="mt-2 list-disc pl-4">
              {pending.actions.filter((action) => action.op !== "note").map((action, index) => (
                <li key={`${action.op}-${index}`}>{action.summary}</li>
              ))}
            </ul>
            <div className="mt-2 flex gap-2">
              <button type="button" className="lab-btn primary" onClick={() => useLab.getState().confirmPending()}>
                Applica
              </button>
              <button type="button" className="lab-btn" onClick={() => useLab.getState().cancelPending()}>
                Annulla
              </button>
            </div>
          </article>
        ) : null}
      </div>
      <form
        className="lab-transport"
        onSubmit={(event) => {
          event.preventDefault();
          void send();
        }}
      >
        <input
          aria-label="Messaggio"
          value={text}
          placeholder={provider === "locale" ? "Comando del banco" : "Messaggio all'assistente"}
          onChange={(event) => setText(event.target.value)}
        />
        <button type="submit" className="lab-btn primary" disabled={busy}>
          {busy ? "…" : "Invia"}
        </button>
      </form>
    </div>
  );
}
