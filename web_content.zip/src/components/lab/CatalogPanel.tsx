import {
  makeArm,
  makeDisc,
  makeFlywheel,
  makeGearPair,
  makeLever,
  makePanel,
  makePiston,
  makePrimitive,
  makePulley,
  makeRail,
  makeSeat,
  makeSpring,
  makeSteering,
  makeStirling,
  makeWheel,
} from "@/lib/lab/catalog";
import { useLab } from "@/lib/lab/store";
import type { LabAction } from "@/lib/lab/types";
import { Eye, EyeOff } from "lucide-react";

function place(foot: number): { x: number; z: number } {
  const s = useLab.getState();
  const i = s.assemblies.length + s.parts.filter((p) => !p.assemblyId).length;
  return { x: (i % 3) * foot, z: Math.floor(i / 3) * foot * 0.55 };
}

function add(action: LabAction) {
  useLab.getState().applyActions([action], "utente");
}

export function CatalogPanel() {
  const parts = useLab((s) => s.parts);
  const selected = useLab((s) => s.selectedIds);
  const groups: { title: string; items: { label: string; run: () => void }[] }[] = [
    {
      title: "Motore",
      items: [
        { label: "Stirling Gamma", run: () => { const p = place(230); add(makeStirling(p.x, p.z)); } },
        { label: "Pistone libero", run: () => { const p = place(80); add(makePiston(p.x, p.z)); } },
        { label: "Volano", run: () => { const p = place(110); add(makeFlywheel(p.x, p.z)); } },
      ],
    },
    {
      title: "Trasmissione",
      items: [
        { label: "Ingranaggi 18/36", run: () => { const p = place(140); add(makeGearPair(p.x, p.z)); } },
        { label: "Albero", run: () => { const p = place(90); add(makePrimitive("shaft", p.x, p.z)); } },
        { label: "Puleggia", run: () => { const p = place(80); add(makePulley(p.x, p.z)); } },
      ],
    },
    {
      title: "Leve ed elastici",
      items: [
        { label: "Leva", run: () => { const p = place(100); add(makeLever(p.x, p.z)); } },
        { label: "Molla", run: () => { const p = place(80); add(makeSpring(p.x, p.z)); } },
      ],
    },
    {
      title: "Macchina, pezzo per pezzo",
      items: [
        { label: "Longherone", run: () => { const p = place(200); add(makeRail(p.x, p.z)); } },
        { label: "Braccio", run: () => { const p = place(120); add(makeArm(p.x, p.z)); } },
        { label: "Ruota", run: () => { const p = place(100); add(makeWheel(p.x, p.z)); } },
        { label: "Disco freno", run: () => { const p = place(90); add(makeDisc(p.x, p.z)); } },
        { label: "Volante", run: () => { const p = place(90); add(makeSteering(p.x, p.z)); } },
        { label: "Pannello", run: () => { const p = place(160); add(makePanel(p.x, p.z)); } },
        { label: "Sedile", run: () => { const p = place(100); add(makeSeat(p.x, p.z)); } },
      ],
    },
    {
      title: "Primitive",
      items: [
        { label: "Scatola", run: () => { const p = place(70); add(makePrimitive("box", p.x, p.z)); } },
        { label: "Cilindro", run: () => { const p = place(70); add(makePrimitive("cylinder", p.x, p.z)); } },
        { label: "Sfera", run: () => { const p = place(60); add(makePrimitive("sphere", p.x, p.z)); } },
        { label: "Piastra", run: () => { const p = place(90); add(makePrimitive("plate", p.x, p.z)); } },
      ],
    },
  ];

  return (
    <div className="lab-scroll">
      <p className="lab-note">Il banco nasce vuoto. Ogni pezzo resta separato: niente macchina già fatta.</p>
      {groups.map((group) => (
        <section key={group.title}>
          <h2 className="lab-kicker">{group.title}</h2>
          <div className="lab-grid">
            {group.items.map((item) => (
              <button key={item.label} className="lab-btn" type="button" onClick={item.run}>
                {item.label}
              </button>
            ))}
          </div>
        </section>
      ))}
      <h2 className="lab-kicker">Sul banco</h2>
      {parts.length === 0 ? <p className="lab-note">Nessun componente.</p> : null}
      <div className="lab-list">
        {parts.map((part) => (
          <button
            key={part.id}
            type="button"
            className="item"
            data-on={selected.includes(part.id)}
            onClick={() => useLab.getState().selectOnly(part.id)}
          >
            <span className="min-w-0 flex-1 truncate">
              {part.name}
              {part.hypothesis ? " · ipotesi" : ""}
            </span>
            <span
              className="lab-icon"
              role="button"
              aria-label={part.visible ? "Nascondi" : "Mostra"}
              onClick={(event) => {
                event.stopPropagation();
                useLab.getState().updatePart(part.id, { visible: !part.visible }, part.visible ? "Componente nascosto." : "Componente mostrato.");
              }}
            >
              {part.visible ? <Eye size={16} /> : <EyeOff size={16} />}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
