import { useState } from "react";
import { useLab } from "@/lib/lab/store";
import type { IdeaStatus } from "@/lib/lab/types";

const STATUSES: IdeaStatus[] = ["ipotesi", "esperimento", "verificato"];

export function ArchivePanel() {
  const ideas = useLab((s) => s.ideas);
  const versions = useLab((s) => s.versions);
  const log = useLab((s) => s.log);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [tab, setTab] = useState<"idee" | "versioni" | "diario">("idee");

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="lab-tabs">
        <button type="button" data-on={tab === "idee"} onClick={() => setTab("idee")}>Idee</button>
        <button type="button" data-on={tab === "versioni"} onClick={() => setTab("versioni")}>Versioni</button>
        <button type="button" data-on={tab === "diario"} onClick={() => setTab("diario")}>Diario</button>
      </div>
      <div className="lab-scroll">
        {tab === "idee" ? (
          <>
            <p className="lab-note">Le ipotesi restano finché non le togli tu. Non diventano risultati da sole.</p>
            <input aria-label="Titolo idea" placeholder="Titolo" value={title} onChange={(event) => setTitle(event.target.value)} />
            <textarea className="mt-2" aria-label="Testo idea" placeholder="Cosa vuoi tenere" value={body} onChange={(event) => setBody(event.target.value)} />
            <button
              type="button"
              className="lab-btn primary mt-2"
              onClick={() => {
                if (!title.trim() && !body.trim()) return;
                useLab.getState().addIdea(title.trim() || "Ipotesi", body.trim(), "ipotesi");
                setTitle("");
                setBody("");
              }}
            >
              Archivia
            </button>
            {ideas.map((idea) => (
              <article key={idea.id} className="mt-3 border-t border-line pt-3">
                <h3 className="font-semibold">{idea.title}</h3>
                <p className="lab-note">{idea.body}</p>
                <div className="mt-2 flex flex-wrap gap-1">
                  {STATUSES.map((status) => (
                    <button
                      key={status}
                      type="button"
                      className="lab-btn"
                      data-on={idea.status === status}
                      onClick={() => useLab.getState().setIdeaStatus(idea.id, status)}
                    >
                      {status}
                    </button>
                  ))}
                  <button type="button" className="lab-btn danger" onClick={() => useLab.getState().removeIdea(idea.id)}>
                    Elimina
                  </button>
                </div>
              </article>
            ))}
          </>
        ) : null}
        {tab === "versioni" ? (
          <>
            <button
              type="button"
              className="lab-btn primary"
              onClick={() => useLab.getState().saveVersion(`Versione ${new Date().toLocaleString("it")}`)}
            >
              Salva versione
            </button>
            <p className="lab-note">Il salvataggio è sul telefono, in questo browser. Il ripristino tiene una copia del banco attuale.</p>
            {versions.map((version) => (
              <div key={version.id} className="lab-row">
                <span>
                  {version.name}
                  <br />
                  <small>{new Date(version.at).toLocaleString("it")}</small>
                </span>
                <button type="button" className="lab-btn" onClick={() => useLab.getState().restoreVersion(version.id)}>
                  Ripristina
                </button>
              </div>
            ))}
          </>
        ) : null}
        {tab === "diario" ? (
          <ol className="lab-list">
            {log.map((entry) => (
              <li key={entry.id} className="lab-row">
                <span>
                  {entry.summary}
                  <br />
                  <small>
                    {entry.source} · {new Date(entry.at).toLocaleString("it")}
                  </small>
                </span>
              </li>
            ))}
            {log.length === 0 ? <p className="lab-note">Ancora nessuna modifica.</p> : null}
          </ol>
        ) : null}
      </div>
    </div>
  );
}
