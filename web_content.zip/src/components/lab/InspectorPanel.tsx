import { useEffect, useState } from "react";
import { massKg, sectionMm2 } from "@/lib/lab/calc";
import { round } from "@/lib/lab/ids";
import { MATERIALS } from "@/lib/lab/materials";
import { useLab } from "@/lib/lab/store";
import { MODULES, sizeLabels, type Part } from "@/lib/lab/types";

function Num({
  label,
  value,
  onCommit,
}: {
  label: string;
  value: number;
  onCommit: (n: number) => void;
}) {
  const [text, setText] = useState(String(round(value, 2)));
  useEffect(() => setText(String(round(value, 2))), [value]);
  return (
    <label className="lab-field block">
      <span className="lab-note">{label}</span>
      <input
        inputMode="decimal"
        value={text}
        onChange={(event) => setText(event.target.value)}
        onBlur={() => {
          const n = Number(text.replace(",", "."));
          if (Number.isFinite(n)) onCommit(n);
        }}
      />
    </label>
  );
}

export function InspectorPanel() {
  const parts = useLab((s) => s.parts);
  const assemblies = useLab((s) => s.assemblies);
  const joints = useLab((s) => s.joints);
  const selectedIds = useLab((s) => s.selectedIds);
  const part = parts.find((p) => p.id === selectedIds[0]);
  const assembly = assemblies.find((a) => a.id === part?.assemblyId);

  if (!part) {
    return (
      <div className="lab-scroll">
        <h2 className="lab-kicker">Nessuna selezione</h2>
        <p className="lab-note">
          Tocca un pezzo sul banco. Con «Sposta» il gizmo muove il gruppo intero, così il motore non si smonta.
        </p>
        <p className="lab-note">{parts.length} componenti, {assemblies.length} gruppi, {joints.length} collegamenti registrati.</p>
      </div>
    );
  }

  const labels = sizeLabels(part.kind);
  const mass = massKg(part);
  const area = sectionMm2(part);
  const linked = joints.filter((j) => j.a === part.id || j.b === part.id);

  function patch(next: Partial<Part>, summary: string) {
    useLab.getState().updatePart(part!.id, next, summary);
  }

  return (
    <div className="lab-scroll">
      <h2 className="lab-kicker">Componente</h2>
      <input
        aria-label="Nome"
        value={part.name}
        onChange={(event) => patch({ name: event.target.value }, "Nome aggiornato.")}
      />
      <p className="lab-note">
        {part.kind} · {part.role}
        {part.hypothesis ? " · ipotesi" : " · nel progetto"}
      </p>
      <label className="lab-note block">
        Materiale
        <select
          value={part.materialId}
          onChange={(event) => patch({ materialId: event.target.value }, "Materiale cambiato.")}
        >
          {MATERIALS.map((m) => (
            <option key={m.id} value={m.id}>
              {m.name}
            </option>
          ))}
        </select>
      </label>
      <label className="lab-note block">
        Modulo della macchina
        <select
          value={part.module}
          onChange={(event) => patch({ module: event.target.value as Part["module"] }, "Modulo cambiato.")}
        >
          {MODULES.map((m) => (
            <option key={m.id} value={m.id}>
              {m.label}
            </option>
          ))}
        </select>
      </label>
      <div className="lab-row">
        <span>Massa stimata</span>
        <span>{mass === null ? "—" : `${round(mass, 3)} kg`}</span>
      </div>
      <div className="lab-row">
        <span>Sezione assunta</span>
        <span>{area === null ? "—" : `${round(area, 1)} mm²`}</span>
      </div>
      <p className="lab-note">Volume da primitiva, densità da manuale. Non è una pesata.</p>

      {assembly ? (
        <>
          <h2 className="lab-kicker">Gruppo {assembly.name}</h2>
          <div className="lab-grid">
            {(["x", "y", "z"] as const).map((axis) => (
              <Num
                key={axis}
                label={`Origine ${axis.toUpperCase()}`}
                value={assembly.position[axis]}
                onCommit={(n) =>
                  useLab.getState().updateAssembly(assembly.id, { ...assembly.position, [axis]: n }, assembly.rotation)
                }
              />
            ))}
          </div>
          {assembly.kind === "stirling-gamma" ? <StirlingTune id={assembly.id} parts={parts} /> : null}
          {assembly.kind === "ingranaggi" ? <GearTune id={assembly.id} parts={parts} /> : null}
        </>
      ) : (
        <>
          <h2 className="lab-kicker">Posizione mm</h2>
          <div className="lab-grid">
            {(["x", "y", "z"] as const).map((axis) => (
              <Num
                key={axis}
                label={axis.toUpperCase()}
                value={part.position[axis]}
                onCommit={(n) => patch({ position: { ...part.position, [axis]: n } }, "Posizione aggiornata.")}
              />
            ))}
          </div>
        </>
      )}

      <h2 className="lab-kicker">Dimensioni mm</h2>
      <div className="lab-grid">
        {labels.axes.map((axis) => (
          <Num
            key={axis}
            label={labels[axis]}
            value={part.size[axis]}
            onCommit={(n) => patch({ size: { ...part.size, [axis]: Math.max(0.4, n) } }, "Dimensione aggiornata.")}
          />
        ))}
      </div>

      {part.role === "spring" ? (
        <div className="lab-grid">
          <Num
            label="k N/mm"
            value={part.params.stiffness ?? 4}
            onCommit={(n) => patch({ params: { ...part.params, stiffness: n } }, "Rigidezza aggiornata.")}
          />
          <Num
            label="Schiacciamento mm"
            value={part.params.deflection ?? 0}
            onCommit={(n) => patch({ params: { ...part.params, deflection: n } }, "Deformazione aggiornata.")}
          />
        </div>
      ) : null}
      {part.role === "lever" ? (
        <div className="lab-grid">
          <Num label="Braccio l1" value={part.params.l1 ?? 1} onCommit={(n) => patch({ params: { ...part.params, l1: n } }, "Braccio aggiornato.")} />
          <Num label="Braccio l2" value={part.params.l2 ?? 1} onCommit={(n) => patch({ params: { ...part.params, l2: n } }, "Braccio aggiornato.")} />
        </div>
      ) : null}

      <label className="mt-2 flex min-h-11 items-center gap-2 text-sm">
        <input
          type="checkbox"
          checked={part.hypothesis}
          onChange={(event) => patch({ hypothesis: event.target.checked }, "Stato dell'ipotesi aggiornato.")}
        />
        Segna come ipotesi, non come pezzo verificato
      </label>
      <label className="flex min-h-11 items-center gap-2 text-sm">
        <input
          type="checkbox"
          checked={part.locked}
          onChange={(event) => patch({ locked: event.target.checked }, part.locked ? "Sbloccato." : "Bloccato.")}
        />
        Blocca gli spostamenti
      </label>
      <label className="lab-note block">
        Note
        <textarea
          value={part.notes}
          onChange={(event) => patch({ notes: event.target.value }, "Nota aggiornata.")}
        />
      </label>
      {linked.length ? (
        <>
          <h2 className="lab-kicker">Collegamenti</h2>
          {linked.map((j) => (
            <p key={j.id} className="lab-note">
              {j.name}: {j.type}, rapporto ω {round(j.ratio, 3)}, rendimento dichiarato {j.efficiency}. {j.notes}
            </p>
          ))}
        </>
      ) : null}
      <div className="mt-3 flex gap-2">
        <button type="button" className="lab-btn" onClick={() => useLab.getState().duplicateSelected()}>
          Duplica
        </button>
        <button type="button" className="lab-btn" onClick={() => useLab.getState().alignGround()}>
          A terra
        </button>
      </div>
    </div>
  );
}

function StirlingTune({ id, parts }: { id: string; parts: Part[] }) {
  const crank = parts.find((p) => p.assemblyId === id && p.role === "crank");
  const power = parts.find((p) => p.assemblyId === id && p.role === "power-piston");
  const disp = parts.find((p) => p.assemblyId === id && p.role === "displacer");
  if (!crank || !power || !disp) return null;
  return (
    <div className="lab-grid">
      <Num
        label="Corsa manovella 2r"
        value={(crank.params.crankRadius ?? 18) * 2}
        onCommit={(n) => useLab.getState().applyActions([{ op: "tuneStirling", id, stroke: n, summary: `Corsa ${n} mm.` }], "utente")}
      />
      <Num
        label="Alesaggio"
        value={power.params.bore ?? power.size.x}
        onCommit={(n) => useLab.getState().applyActions([{ op: "tuneStirling", id, bore: n, summary: `Alesaggio ${n} mm.` }], "utente")}
      />
      <Num
        label="Fase displacer °"
        value={((disp.params.phase ?? Math.PI / 2) * 180) / Math.PI}
        onCommit={(n) => useLab.getState().applyActions([{ op: "tuneStirling", id, phaseDeg: n, summary: `Fase ${n}°.` }], "utente")}
      />
    </div>
  );
}

function GearTune({ id, parts }: { id: string; parts: Part[] }) {
  const driver = parts.find((p) => p.assemblyId === id && p.role === "gear-driver");
  const driven = parts.find((p) => p.assemblyId === id && p.role === "gear-driven");
  if (!driver || !driven) return null;
  return (
    <div className="lab-grid">
      <Num
        label="Denti conduttore"
        value={driver.params.teeth ?? 18}
        onCommit={(n) =>
          useLab.getState().applyActions([{ op: "tuneGears", id, teethA: Math.round(n), summary: "Denti aggiornati." }], "utente")
        }
      />
      <Num
        label="Denti condotto"
        value={driven.params.teeth ?? 36}
        onCommit={(n) =>
          useLab.getState().applyActions([{ op: "tuneGears", id, teethB: Math.round(n), summary: "Denti aggiornati." }], "utente")
        }
      />
    </div>
  );
}
