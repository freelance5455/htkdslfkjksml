import { useEffect, useRef } from "react";
import type { SceneSnap } from "./scene";
import { useLab } from "@/lib/lab/store";

export function Viewport() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let dead = false;
    let dispose = () => {};
    void import("./scene").then(({ mountLabScene }) => {
      if (dead) return;
      const handle = mountLabScene(canvas, {
        getSnap: (): SceneSnap => {
          const s = useLab.getState();
          return {
            parts: s.parts,
            joints: s.joints,
            assemblies: s.assemblies,
            selectedIds: s.selectedIds,
            explode: s.explode,
            showGrid: s.showGrid,
            view: s.view,
            tool: s.tool,
            playing: s.sim.playing,
            rpm: s.sim.rpm,
            angle: s.sim.angle,
            seekId: s.seekId,
            study: s.study,
            measure: s.measure,
            multi: s.multi,
          };
        },
        onSelect: (id, additive) => {
          const api = useLab.getState();
          if (!id) {
            api.selectOnly(null);
            return;
          }
          if (additive) api.toggleSelect(id);
          else api.selectOnly(id);
        },
        onCommitAssembly: (id, position, rotation) => {
          useLab.getState().updateAssembly(id, position, rotation);
        },
        onCommitPart: (id, position, rotation) => {
          useLab.getState().updatePart(id, { position, rotation }, "Componente spostato.");
        },
        onMeasure: (p) => useLab.getState().addMeasurePoint(p),
        onAngle: (rad) => useLab.getState().publishAngle(rad),
      });
      dispose = () => handle.dispose();
    });
    return () => {
      dead = true;
      dispose();
    };
  }, []);

  return <canvas ref={canvasRef} aria-label="Banco tridimensionale" />;
}
