import * as THREE from "three";
import type { Part } from "@/lib/lab/types";
import { getMaterial } from "@/lib/lab/materials";

export function geoKey(part: Part): string {
  return `${part.kind}|${part.size.x}|${part.size.y}|${part.size.z}|${JSON.stringify(part.params)}`;
}

export function appearanceKey(part: Part, selected: boolean, tint: string | null): string {
  return `${part.materialId}|${part.color ?? ""}|${part.kind}|${selected ? 1 : 0}|${tint ?? ""}`;
}

function materialFor(part: Part, selected: boolean, tint: string | null): THREE.MeshStandardMaterial {
  const def = getMaterial(part.materialId);
  const color = tint ?? part.color ?? def.color;
  const mat = new THREE.MeshStandardMaterial({
    color,
    metalness: part.kind === "bore" ? 0.05 : def.metalness,
    roughness: part.kind === "bore" ? 0.08 : def.roughness,
    emissive: selected ? new THREE.Color("#d4a054") : new THREE.Color("#000000"),
    emissiveIntensity: selected ? 0.28 : 0,
  });
  if (part.kind === "bore") {
    mat.transparent = true;
    mat.opacity = 0.28;
    mat.depthWrite = false;
  }
  return mat;
}

function cyl(radius: number, length: number, axis: "x" | "y" | "z", segs = 24): THREE.BufferGeometry {
  const geo = new THREE.CylinderGeometry(Math.max(0.2, radius), Math.max(0.2, radius), Math.max(0.2, length), segs);
  if (axis === "z") geo.rotateX(Math.PI / 2);
  if (axis === "x") geo.rotateZ(Math.PI / 2);
  return geo;
}

function mesh(geo: THREE.BufferGeometry, mat: THREE.Material, cast = true): THREE.Mesh {
  const m = new THREE.Mesh(geo, mat);
  m.castShadow = cast;
  m.receiveShadow = true;
  return m;
}

function gearGeometry(teeth: number, moduleMm: number, thickness: number): THREE.BufferGeometry {
  const pitch = (moduleMm * Math.max(6, teeth)) / 2;
  const add = pitch + moduleMm;
  const ded = Math.max(moduleMm, pitch - 1.25 * moduleMm);
  const shape = new THREE.Shape();
  const steps = Math.max(6, teeth) * 2;
  for (let i = 0; i <= steps; i++) {
    const a = (i / steps) * Math.PI * 2;
    const r = i % 2 === 0 ? add : ded;
    const x = Math.cos(a) * r;
    const y = Math.sin(a) * r;
    if (i === 0) shape.moveTo(x, y);
    else shape.lineTo(x, y);
  }
  const hole = new THREE.Path();
  hole.absarc(0, 0, Math.max(1.2, pitch * 0.18), 0, Math.PI * 2, true);
  shape.holes.push(hole);
  const geo = new THREE.ExtrudeGeometry(shape, { depth: Math.max(0.8, thickness), bevelEnabled: false, curveSegments: 1 });
  geo.translate(0, 0, -thickness / 2);
  return geo;
}

function springGeometry(part: Part): THREE.BufferGeometry {
  const coils = Math.max(3, part.params.coils ?? 8);
  const radius = Math.max(2, part.size.x / 2);
  const wire = Math.max(0.4, part.size.z || 2);
  const rest = part.size.y;
  const deflection = part.params.deflection ?? 0;
  const length = Math.max(wire * coils, rest + deflection);
  const pts: THREE.Vector3[] = [];
  const n = Math.round(coils * 12);
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    const a = t * coils * Math.PI * 2;
    pts.push(new THREE.Vector3(Math.cos(a) * radius, (t - 0.5) * length, Math.sin(a) * radius));
  }
  const curve = new THREE.CatmullRomCurve3(pts);
  return new THREE.TubeGeometry(curve, n, wire / 2, 6, false);
}

export function buildPart(part: Part, selected: boolean, tint: string | null): THREE.Group {
  const group = new THREE.Group();
  group.name = part.id;
  const mat = materialFor(part, selected, tint);
  const d = part.size.x;
  const r = d / 2;
  const h = part.size.y;

  const add = (m: THREE.Mesh) => group.add(m);

  switch (part.kind) {
    case "box":
    case "plate":
    case "frame":
    case "lever":
      add(mesh(new THREE.BoxGeometry(part.size.x, part.size.y, part.size.z), mat));
      break;
    case "sphere":
      add(mesh(new THREE.SphereGeometry(Math.max(0.4, r), 24, 16), mat));
      break;
    case "cylinder":
    case "piston":
    case "rod":
      add(mesh(cyl(r, h, "y"), mat));
      if (part.kind === "piston") {
        const ring = new THREE.Mesh(new THREE.TorusGeometry(r * 0.92, Math.max(0.4, r * 0.08), 8, 18), mat);
        ring.rotation.x = Math.PI / 2;
        ring.position.y = h * 0.2;
        add(ring);
      }
      break;
    case "bore":
      add(mesh(cyl(r, h, "y", 28), mat, false));
      break;
    case "shaft":
    case "crank":
      add(mesh(cyl(r, h, "z"), mat));
      break;
    case "flywheel":
    case "pulley": {
      add(mesh(cyl(r, h, "z"), mat));
      const flangeGeo = cyl(r * 1.08, Math.max(1, h * 0.18), "z");
      const flange = mesh(flangeGeo, mat);
      flange.position.z = h * 0.38;
      const flange2 = mesh(flangeGeo.clone(), mat);
      flange2.position.z = -h * 0.38;
      add(flange);
      add(flange2);
      break;
    }
    case "wheel":
    case "disc":
      add(mesh(cyl(r, h, "x", part.kind === "wheel" ? 28 : 24), mat));
      if (part.kind === "wheel") {
        const hubMat = materialFor({ ...part, kind: "shaft", materialId: "s235", color: null }, selected, null);
        add(mesh(cyl(r * 0.28, h * 1.05, "x"), hubMat));
      }
      break;
    case "gear":
      add(mesh(gearGeometry(part.params.teeth ?? 18, part.params.module ?? 2, part.params.thickness ?? h), mat));
      break;
    case "spring":
      add(mesh(springGeometry(part), mat));
      break;
    case "torus":
      add(mesh(new THREE.TorusGeometry(Math.max(4, r), Math.max(0.6, part.size.y / 2), 12, 28), mat));
      break;
    case "seat": {
      const cushion = mesh(new THREE.BoxGeometry(part.size.x, 16, part.size.z), mat);
      cushion.position.y = -part.size.y / 2 + 8;
      const back = mesh(new THREE.BoxGeometry(part.size.x, Math.max(20, part.size.y - 16), 12), mat);
      back.position.y = 8;
      back.position.z = -part.size.z / 2 + 6;
      add(cushion);
      add(back);
      break;
    }
    default:
      add(mesh(new THREE.BoxGeometry(10, 10, 10), mat));
  }

  group.userData.pick = part.id;
  group.traverse((obj) => {
    obj.userData.pick = part.id;
  });
  return group;
}

export function disposeGroup(group: THREE.Object3D): void {
  group.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (mesh.geometry) mesh.geometry.dispose();
    const mat = mesh.material;
    if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
    else if (mat && "dispose" in mat) mat.dispose();
  });
}
