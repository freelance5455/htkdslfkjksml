import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { TransformControls } from "three/addons/controls/TransformControls.js";
import { sectionMm2, stressMPa, safetyFactor } from "@/lib/lab/calc";
import { mechanismFrame, type OverlaySeg, type Pose } from "@/lib/lab/kinematics";
import { getMaterial } from "@/lib/lab/materials";
import type { Assembly, Joint, Part, Study, ToolId, Vec3, ViewMode } from "@/lib/lab/types";
import { appearanceKey, buildPart, disposeGroup, geoKey } from "./geometry";

export type SceneSnap = {
  parts: Part[];
  joints: Joint[];
  assemblies: Assembly[];
  selectedIds: string[];
  explode: number;
  showGrid: boolean;
  view: ViewMode;
  tool: ToolId;
  playing: boolean;
  rpm: number;
  angle: number;
  seekId: number;
  study: Study;
  measure: { a: Vec3 | null; b: Vec3 | null };
  multi: boolean;
};

type Handlers = {
  getSnap: () => SceneSnap;
  onSelect: (id: string | null, additive: boolean) => void;
  onCommitAssembly: (id: string, position: Vec3, rotation: Vec3) => void;
  onCommitPart: (id: string, position: Vec3, rotation: Vec3) => void;
  onMeasure: (p: Vec3) => void;
  onAngle: (rad: number) => void;
};

const _up = new THREE.Vector3(0, 1, 0);
const _dir = new THREE.Vector3();
const _mid = new THREE.Vector3();
const _wp = new THREE.Vector3();

function stressTint(part: Part, forceN: number): string | null {
  const area = sectionMm2(part);
  if (!area) return null;
  const sigma = stressMPa(forceN, area);
  const mat = getMaterial(part.materialId);
  const n = sigma ? safetyFactor(mat.yieldMPa, sigma) : null;
  if (!n || !sigma) return null;
  if (n < 1) return "#c45c4a";
  if (n < 1.6) return "#d4a054";
  return "#7f8f78";
}

export function mountLabScene(canvas: HTMLCanvasElement, handlers: Handlers): { dispose: () => void } {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  const small = Math.min(window.innerWidth, window.innerHeight) < 800;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, small ? 1.5 : 2));
  renderer.setClearColor(0x101418, 1);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;

  const scene = new THREE.Scene();
  scene.fog = new THREE.Fog(0x101418, 500, 1800);

  const persp = new THREE.PerspectiveCamera(38, 1, 1, 4000);
  persp.position.set(220, 160, 260);
  const ortho = new THREE.OrthographicCamera(-200, 200, 140, -140, 0.1, 4000);
  ortho.position.copy(persp.position);

  const controls = new OrbitControls(persp, canvas);
  controls.target.set(40, 36, 0);
  controls.enableDamping = true;
  controls.dampingFactor = 0.08;
  controls.maxDistance = 1600;
  controls.minDistance = 30;
  controls.maxPolarAngle = Math.PI * 0.92;

  const transform = new TransformControls(persp, canvas);
  transform.setSize(1.15);
  scene.add(transform.getHelper());

  const hemi = new THREE.HemisphereLight(0xf4efe4, 0x1a2228, 1.15);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xfff6ea, 2.4);
  sun.position.set(120, 220, 80);
  sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  sun.shadow.camera.near = 20;
  sun.shadow.camera.far = 700;
  sun.shadow.camera.left = -220;
  sun.shadow.camera.right = 220;
  sun.shadow.camera.top = 220;
  sun.shadow.camera.bottom = -220;
  scene.add(sun);
  const fill = new THREE.DirectionalLight(0x9eb0be, 0.45);
  fill.position.set(-140, 60, -100);
  scene.add(fill);

  const ground = new THREE.Mesh(
    new THREE.CircleGeometry(900, 48),
    new THREE.MeshStandardMaterial({ color: "#141b20", roughness: 1, metalness: 0 }),
  );
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  ground.userData.ground = true;
  scene.add(ground);

  const grid = new THREE.GridHelper(400, 40, 0x8a6a32, 0x2a3840);
  grid.position.y = 0.15;
  scene.add(grid);
  const axes = new THREE.AxesHelper(60);
  axes.position.y = 0.2;
  scene.add(axes);

  const root = new THREE.Group();
  scene.add(root);
  const assemblyGroups = new Map<string, THREE.Group>();
  const partGroups = new Map<string, THREE.Group>();
  const partSig = new Map<string, string>();
  const overlayGroups = new Map<string, THREE.Group>();
  const segMeshes = new Map<string, THREE.Mesh>();
  const segMat = new THREE.MeshStandardMaterial({ color: "#c6a15a", metalness: 0.6, roughness: 0.35 });
  const pinGeo = new THREE.SphereGeometry(1, 12, 10);
  const rodGeo = new THREE.CylinderGeometry(1, 1, 1, 8);

  const flowGeo = new THREE.BufferGeometry();
  const flowCount = 80;
  const flowPos = new Float32Array(flowCount * 3);
  for (let i = 0; i < flowCount; i++) {
    flowPos[i * 3] = Math.random() * 360 - 40;
    flowPos[i * 3 + 1] = 20 + Math.random() * 120;
    flowPos[i * 3 + 2] = Math.random() * 160 - 80;
  }
  flowGeo.setAttribute("position", new THREE.BufferAttribute(flowPos, 3));
  const flow = new THREE.Points(
    flowGeo,
    new THREE.PointsMaterial({ color: "#d4a054", size: 2.2, transparent: true, opacity: 0.75, sizeAttenuation: true }),
  );
  flow.visible = false;
  flow.frustumCulled = false;
  scene.add(flow);

  const measureLine = new THREE.Line(
    new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]),
    new THREE.LineBasicMaterial({ color: "#d4a054" }),
  );
  measureLine.visible = false;
  scene.add(measureLine);
  const measureDots = [0, 1].map(() => {
    const m = new THREE.Mesh(
      new THREE.SphereGeometry(2.2, 12, 8),
      new THREE.MeshBasicMaterial({ color: "#d4a054" }),
    );
    m.visible = false;
    scene.add(m);
    return m;
  });

  const raycaster = new THREE.Raycaster();
  const pointer = new THREE.Vector2();
  const timer = new THREE.Timer();
  timer.connect(document);

  let angle = 0;
  let appliedSeek = -1;
  let wasPlaying = false;
  let publishAcc = 0;
  let dragging = false;
  let currentCamera: THREE.Camera = persp;
  let disposed = false;

  transform.addEventListener("dragging-changed", (event) => {
    const active = Boolean((event as { value?: boolean }).value);
    dragging = active;
    controls.enabled = !active;
    if (!active) commitDrag();
  });

  function commitDrag() {
    const obj = transform.object;
    if (!obj) return;
    const target = obj.userData.target as string | undefined;
    const id = obj.userData.id as string | undefined;
    if (!id) return;
    const snap = handlers.getSnap();
    const s = snap.snap;
    const roundTo = (v: number) => (s > 0 ? Math.round(v / s) * s : v);
    const position = { x: roundTo(obj.position.x), y: roundTo(obj.position.y), z: roundTo(obj.position.z) };
    const rotation = {
      x: (obj.rotation.x * 180) / Math.PI,
      y: (obj.rotation.y * 180) / Math.PI,
      z: (obj.rotation.z * 180) / Math.PI,
    };
    if (target === "assembly") handlers.onCommitAssembly(id, position, rotation);
    if (target === "part") handlers.onCommitPart(id, position, rotation);
  }

  function resize() {
    const parent = canvas.parentElement;
    if (!parent) return;
    const w = Math.max(1, parent.clientWidth);
    const h = Math.max(1, parent.clientHeight);
    renderer.setSize(w, h, false);
    persp.aspect = w / h;
    persp.updateProjectionMatrix();
    const frustum = 150;
    ortho.left = (-frustum * w) / h;
    ortho.right = (frustum * w) / h;
    ortho.top = frustum;
    ortho.bottom = -frustum;
    ortho.updateProjectionMatrix();
  }
  const observer = new ResizeObserver(resize);
  if (canvas.parentElement) observer.observe(canvas.parentElement);
  resize();

  function placeSeg(mesh: THREE.Mesh, seg: OverlaySeg) {
    if (seg.from.x === seg.to.x && seg.from.y === seg.to.y && seg.from.z === seg.to.z) {
      mesh.geometry = pinGeo;
      mesh.scale.setScalar(seg.radius);
      mesh.position.set(seg.from.x, seg.from.y, seg.from.z);
      mesh.quaternion.identity();
      return;
    }
    mesh.geometry = rodGeo;
    _dir.set(seg.to.x - seg.from.x, seg.to.y - seg.from.y, seg.to.z - seg.from.z);
    const len = Math.max(0.001, _dir.length());
    _mid.set((seg.from.x + seg.to.x) / 2, (seg.from.y + seg.to.y) / 2, (seg.from.z + seg.to.z) / 2);
    mesh.position.copy(_mid);
    mesh.scale.set(seg.radius, len, seg.radius);
    _dir.multiplyScalar(1 / len);
    mesh.quaternion.setFromUnitVectors(_up, _dir);
  }

  function ensureObjects(snap: SceneSnap) {
    const asmIds = new Set(snap.assemblies.map((a) => a.id));
    for (const [id, group] of assemblyGroups) {
      if (!asmIds.has(id)) {
        root.remove(group);
        assemblyGroups.delete(id);
        overlayGroups.get(id)?.removeFromParent();
        overlayGroups.delete(id);
      }
    }
    for (const asm of snap.assemblies) {
      if (!assemblyGroups.has(asm.id)) {
        const g = new THREE.Group();
        g.userData.target = "assembly";
        g.userData.id = asm.id;
        root.add(g);
        assemblyGroups.set(asm.id, g);
        const overlay = new THREE.Group();
        g.add(overlay);
        overlayGroups.set(asm.id, overlay);
      }
    }

    const partIds = new Set(snap.parts.map((p) => p.id));
    for (const [id, group] of partGroups) {
      if (!partIds.has(id)) {
        group.removeFromParent();
        disposeGroup(group);
        partGroups.delete(id);
        partSig.delete(id);
      }
    }

    for (const part of snap.parts) {
      const tint =
        snap.study.mode === "sforzo" && snap.selectedIds.includes(part.id) ? stressTint(part, snap.study.forceN) : null;
      const sig = `${geoKey(part)}|${appearanceKey(part, snap.selectedIds.includes(part.id), tint)}|${part.visible}`;
      let group = partGroups.get(part.id);
      if (!group || partSig.get(part.id) !== sig) {
        if (group) {
          group.removeFromParent();
          disposeGroup(group);
        }
        group = buildPart(part, snap.selectedIds.includes(part.id), tint);
        group.visible = part.visible;
        group.userData.target = part.assemblyId ? "part" : "part";
        group.userData.id = part.id;
        const parent = part.assemblyId ? assemblyGroups.get(part.assemblyId) ?? root : root;
        parent.add(group);
        partGroups.set(part.id, group);
        partSig.set(part.id, sig);
      }
    }
  }

  function applyPoses(snap: SceneSnap, poses: Record<string, Pose>, overlay: Record<string, OverlaySeg[]>) {
    for (const asm of snap.assemblies) {
      const group = assemblyGroups.get(asm.id);
      if (!group || (dragging && transform.object === group)) continue;
      group.position.set(asm.position.x, asm.position.y, asm.position.z);
      group.rotation.set(
        (asm.rotation.x * Math.PI) / 180,
        (asm.rotation.y * Math.PI) / 180,
        (asm.rotation.z * Math.PI) / 180,
      );
    }

    const byAsm = new Map<string, Part[]>();
    for (const part of snap.parts) {
      if (!part.assemblyId) continue;
      const list = byAsm.get(part.assemblyId) ?? [];
      list.push(part);
      byAsm.set(part.assemblyId, list);
    }

    for (const part of snap.parts) {
      const group = partGroups.get(part.id);
      const pose = poses[part.id];
      if (!group || !pose) continue;
      if (dragging && transform.object === group) continue;
      let ox = 0;
      let oy = 0;
      let oz = 0;
      if (part.assemblyId && snap.explode > 0) {
        const mates = byAsm.get(part.assemblyId) ?? [];
        let cx = 0;
        let cy = 0;
        let cz = 0;
        for (const m of mates) {
          cx += m.position.x;
          cy += m.position.y;
          cz += m.position.z;
        }
        const n = Math.max(1, mates.length);
        ox = (pose.position.x - cx / n) * snap.explode * 0.7;
        oy = (pose.position.y - cy / n) * snap.explode * 0.7;
        oz = (pose.position.z - cz / n) * snap.explode * 0.7;
      }
      group.position.set(pose.position.x + ox, pose.position.y + oy, pose.position.z + oz);
      group.rotation.set(pose.rotation.x, pose.rotation.y, pose.rotation.z);
      group.visible = part.visible;
    }

    const seen = new Set<string>();
    for (const [asmId, segs] of Object.entries(overlay)) {
      const parent = overlayGroups.get(asmId);
      if (!parent) continue;
      parent.visible = snap.explode < 0.2;
      for (const seg of segs) {
        const key = `${asmId}:${seg.id}`;
        seen.add(key);
        let segMesh = segMeshes.get(key);
        if (!segMesh) {
          segMesh = new THREE.Mesh(rodGeo, segMat);
          segMesh.castShadow = true;
          segMesh.raycast = () => undefined;
          parent.add(segMesh);
          segMeshes.set(key, segMesh);
        }
        placeSeg(segMesh, seg);
        segMesh.visible = true;
      }
    }
    for (const [key, segMesh] of segMeshes) {
      if (!seen.has(key)) segMesh.visible = false;
    }
  }

  function syncGizmo(snap: SceneSnap) {
    const want = snap.tool === "sposta" || snap.tool === "ruota";
    const id = snap.selectedIds.length === 1 ? snap.selectedIds[0] : null;
    if (!want || !id || dragging) {
      if (!dragging) transform.detach();
      return;
    }
    const part = snap.parts.find((p) => p.id === id);
    if (!part || part.locked) {
      transform.detach();
      return;
    }
    const obj = part.assemblyId ? assemblyGroups.get(part.assemblyId) : partGroups.get(part.id);
    if (!obj) return;
    if (transform.object !== obj) transform.attach(obj);
    const mode = snap.tool === "ruota" ? "rotate" : "translate";
    if (transform.mode !== mode) transform.setMode(mode);
    const cam = currentCamera;
    if (transform.camera !== cam) transform.camera = cam;
  }

  function setView(view: ViewMode) {
    const target = controls.target.clone();
    if (view === "ortografica") {
      ortho.position.copy(persp.position);
      ortho.lookAt(target);
      ortho.zoom = 1.4;
      ortho.updateProjectionMatrix();
      controls.object = ortho;
      currentCamera = ortho;
    } else {
      controls.object = persp;
      currentCamera = persp;
    }
    transform.camera = currentCamera;
    controls.update();
  }

  let viewApplied: ViewMode | null = null;

  function step(timestamp: number) {
    if (disposed) return;
    timer.update(timestamp);
    const delta = Math.min(timer.getDelta(), 0.05);
    const snap = handlers.getSnap();
    if (viewApplied !== snap.view) {
      viewApplied = snap.view;
      setView(snap.view);
    }
    grid.visible = snap.showGrid;
    axes.visible = snap.showGrid;

    if (snap.playing && !wasPlaying) angle = snap.angle;
    wasPlaying = snap.playing;
    if (snap.seekId !== appliedSeek) {
      appliedSeek = snap.seekId;
      angle = snap.angle;
    }
    if (snap.playing) {
      angle += ((snap.rpm * Math.PI * 2) / 60) * delta;
      publishAcc += delta;
      if (publishAcc > 0.12) {
        publishAcc = 0;
        handlers.onAngle(angle);
      }
    } else {
      angle = snap.angle;
    }

    ensureObjects(snap);
    const frame = mechanismFrame(snap.parts, snap.joints, angle);
    applyPoses(snap, frame.poses, frame.overlay);
    syncGizmo(snap);

    flow.visible = snap.study.mode === "flusso";
    if (flow.visible) {
      const attr = flowGeo.getAttribute("position") as THREE.BufferAttribute;
      const speed = 30 + snap.study.airMs * 1.4;
      for (let i = 0; i < flowCount; i++) {
        let x = attr.getX(i) + speed * delta;
        let y = attr.getY(i);
        let z = attr.getZ(i);
        if (x > 340) x = -60;
        for (const part of snap.parts) {
          if (!part.visible) continue;
          const group = partGroups.get(part.id);
          if (!group) continue;
          const wp = _wp;
          group.getWorldPosition(wp);
          const dx = x - wp.x;
          const dz = z - wp.z;
          const dist = Math.hypot(dx, dz);
          const rad = Math.max(part.size.x, part.size.z) * 0.55;
          if (dist < rad && dist > 0.01) z += (dz / dist) * 40 * delta;
        }
        attr.setXYZ(i, x, y, z);
      }
      attr.needsUpdate = true;
    }

    const showA = snap.measure.a;
    const showB = snap.measure.b;
    measureDots[0]!.visible = !!showA;
    measureDots[1]!.visible = !!showB;
    if (showA) measureDots[0]!.position.set(showA.x, showA.y, showA.z);
    if (showB) measureDots[1]!.position.set(showB.x, showB.y, showB.z);
    measureLine.visible = !!(showA && showB);
    if (showA && showB) {
      measureLine.geometry.setFromPoints([
        new THREE.Vector3(showA.x, showA.y, showA.z),
        new THREE.Vector3(showB.x, showB.y, showB.z),
      ]);
    }

    controls.update();
    renderer.render(scene, currentCamera);
  }

  renderer.setAnimationLoop(step);

  let downX = 0;
  let downY = 0;
  function onPointerDown(event: PointerEvent) {
    downX = event.clientX;
    downY = event.clientY;
  }
  function onPointerUp(event: PointerEvent) {
    if (dragging) return;
    if (Math.hypot(event.clientX - downX, event.clientY - downY) > 6) return;
    const rect = canvas.getBoundingClientRect();
    pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(pointer, currentCamera);
    const hits = raycaster.intersectObjects(root.children, true);
    const snap = handlers.getSnap();
    const hit = hits.find((h) => typeof h.object.userData.pick === "string");
    if (snap.tool === "misura") {
      const point = hit?.point ?? new THREE.Vector3();
      if (!hit) {
        const planeHit = new THREE.Vector3();
        if (!raycaster.ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0, 1, 0), 0), planeHit)) return;
        handlers.onMeasure({ x: planeHit.x, y: planeHit.y, z: planeHit.z });
        return;
      }
      handlers.onMeasure({ x: point.x, y: point.y, z: point.z });
      return;
    }
    if (!hit) {
      handlers.onSelect(null, false);
      return;
    }
    handlers.onSelect(String(hit.object.userData.pick), event.shiftKey || snap.multi);
  }

  canvas.addEventListener("pointerdown", onPointerDown);
  canvas.addEventListener("pointerup", onPointerUp);

  return {
    dispose() {
      disposed = true;
      renderer.setAnimationLoop(null);
      observer.disconnect();
      timer.dispose();
      canvas.removeEventListener("pointerdown", onPointerDown);
      canvas.removeEventListener("pointerup", onPointerUp);
      transform.detach();
      transform.dispose();
      controls.dispose();
      for (const group of partGroups.values()) disposeGroup(group);
      segMat.dispose();
      pinGeo.dispose();
      rodGeo.dispose();
      flowGeo.dispose();
      (flow.material as THREE.Material).dispose();
      renderer.dispose();
    },
  };
}
