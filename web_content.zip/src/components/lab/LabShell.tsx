import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  Box,
  Bot,
  Download,
  Eye,
  Hand,
  Move3d,
  Pause,
  Play,
  Redo2,
  RotateCw,
  Ruler,
  Undo2,
  Upload,
} from "lucide-react";
import { ArchivePanel } from "./ArchivePanel";
import { AssistantPanel } from "./AssistantPanel";
import { CatalogPanel } from "./CatalogPanel";
import { InspectorPanel } from "./InspectorPanel";
import { ProofPanel } from "./ProofPanel";
import { Viewport } from "./Viewport";
import { round } from "@/lib/lab/ids";
import { downloadText } from "@/lib/lab/report";
import { useLab } from "@/lib/lab/store";
import type { ToolId } from "@/lib/lab/types";

type MobileTab = "scena" | "parti" | "banco" | "archivio";
type SideTab = "dettagli" | "prove" | "archivio";

export function LabShell() {
  const hydrated = useLab((s) => s.hydrated);
  const projectName = useLab((s) => s.projectName);
  const tool = useLab((s) => s.tool);
  const view = useLab((s) => s.view);
  const sim = useLab((s) => s.sim);
  const explode = useLab((s) => s.explode);
  const parts = useLab((s) => s.parts);
  const measure = useLab((s) => s.measure);
  const selected = useLab((s) => s.selectedIds);
  const toast = useLab((s) => s.toast);
  const showGrid = useLab((s) => s.showGrid);
  const multi = useLab((s) => s.multi);
  const [mobile, setMobile] = useState<MobileTab>("scena");
  const [side, setSide] = useState<SideTab>("dettagli");
  const [assistant, setAssistant] = useState(false);
  const [manual, setManual] = useState(false);
  const [dialog, setDialog] = useState<null | "delete" | "new">(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const t = setTimeout(() => useLab.getState().markHydrated(), 600);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => useLab.getState().clearToast(), 2600);
    return () => clearTimeout(t);
  }, [toast]);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      const target = event.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT")) return;
      if (event.key === "Delete" || event.key === "Backspace") {
        event.preventDefault();
        if (useLab.getState().selectedIds.length) setDialog("delete");
      }
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "z") {
        event.preventDefault();
        if (event.shiftKey) useLab.getState().redo();
        else useLab.getState().undo();
      }
      if (event.code === "Space") {
        event.preventDefault();
        const playing = useLab.getState().sim.playing;
        useLab.getState().setPlaying(!playing);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  if (!hydrated) {
    return (
      <main className="grid h-dvh place-items-center bg-bg text-muted">
        <p className="font-mono text-sm">Apertura del banco…</p>
      </main>
    );
  }

  const selectedPart = parts.find((p) => p.id === selected[0]);
  const distance =
    measure.a && measure.b
      ? Math.hypot(measure.a.x - measure.b.x, measure.a.y - measure.b.y, measure.a.z - measure.b.z)
      : null;
  const degrees = round(((sim.angle * 180) / Math.PI) % 360, 0);

  function setTool(next: ToolId) {
    useLab.getState().setTool(next);
  }

  return (
    <div className="lab-root relative">
      <header className="lab-header">
        <div className="lab-mark">
          <strong>OFFICINA</strong>
          <span>Laboratorio</span>
        </div>
        <input
          className="lab-name"
          aria-label="Nome del progetto"
          value={projectName}
          onChange={(event) => useLab.getState().setProjectName(event.target.value)}
        />
        <div className="lab-actions">
          <button type="button" className="lab-icon" aria-label="Annulla" onClick={() => useLab.getState().undo()}>
            <Undo2 size={18} />
          </button>
          <button type="button" className="lab-icon" aria-label="Ripeti" onClick={() => useLab.getState().redo()}>
            <Redo2 size={18} />
          </button>
          <button type="button" className="lab-icon" aria-label="Esporta progetto" onClick={() => downloadText(`${projectName || "officina"}.json`, useLab.getState().exportJson())}>
            <Download size={18} />
          </button>
          <button type="button" className="lab-icon" aria-label="Importa progetto" onClick={() => fileRef.current?.click()}>
            <Upload size={18} />
          </button>
          <button type="button" className="lab-icon" aria-label="Assistente" onClick={() => setAssistant(true)}>
            <Bot size={18} />
          </button>
        </div>
      </header>

      <div className="lab-main">
        <aside className="lab-pane" data-active={mobile === "parti"}>
          <CatalogPanel />
        </aside>
        <section className="lab-pane bg-bg" data-active={mobile === "scena"}>
          <div className="lab-viewport min-h-0 flex-1">
            <Viewport />
            <div className="lab-hud">
              <span className="lab-chip">1 unità = 1 mm</span>
              <span className="lab-chip">{degrees}°</span>
              {selectedPart ? <span className="lab-chip">{selectedPart.name}</span> : null}
              {distance !== null ? <span className="lab-chip">{round(distance, 1)} mm</span> : null}
            </div>
            {parts.length === 0 ? (
              <p className="lab-empty">
                Banco vuoto. Aggiungi un pezzo dal catalogo, oppure chiedi all'interprete: aggiungi un motore Stirling Gamma.
              </p>
            ) : null}
          </div>
          <div className="lab-transport">
            <button type="button" className="lab-icon" aria-label={sim.playing ? "Pausa" : "Anima"} onClick={() => useLab.getState().setPlaying(!sim.playing)}>
              {sim.playing ? <Pause size={18} /> : <Play size={18} />}
            </button>
            <label className="min-w-0 flex-1 text-xs text-muted">
              Angolo
              <input
                type="range"
                min={0}
                max={360}
                value={degrees}
                onChange={(event) => useLab.getState().seek((Number(event.target.value) * Math.PI) / 180)}
              />
            </label>
            <label className="w-24 text-xs text-muted">
              Giri
              <input
                type="range"
                min={0}
                max={600}
                value={sim.rpm}
                onChange={(event) => useLab.getState().setRpm(Number(event.target.value))}
              />
            </label>
          </div>
          <div className="lab-transport">
            <Tool icon={<Hand size={16} />} label="Seleziona" on={tool === "seleziona"} click={() => setTool("seleziona")} />
            <Tool icon={<Move3d size={16} />} label="Sposta" on={tool === "sposta"} click={() => setTool("sposta")} />
            <Tool icon={<RotateCw size={16} />} label="Ruota" on={tool === "ruota"} click={() => setTool("ruota")} />
            <Tool icon={<Ruler size={16} />} label="Misura" on={tool === "misura"} click={() => setTool("misura")} />
            <button type="button" className="lab-icon" aria-label="Griglia" onClick={() => useLab.getState().setShowGrid(!showGrid)}>
              <Eye size={16} />
            </button>
            <button
              type="button"
              className="lab-icon"
              aria-label="Prospettiva o ortografica"
              onClick={() => useLab.getState().setView(view === "prospettiva" ? "ortografica" : "prospettiva")}
            >
              <Box size={16} />
            </button>
            <label className="min-w-0 flex-1 text-xs text-muted">
              Esplosa
              <input type="range" min={0} max={100} value={Math.round(explode * 100)} onChange={(event) => useLab.getState().setExplode(Number(event.target.value) / 100)} />
            </label>
            <button type="button" className="lab-btn" onClick={() => useLab.getState().setMulti(!multi)}>
              {multi ? "Multipla" : "Singola"}
            </button>
            <button type="button" className="lab-btn" onClick={() => setDialog("new")}>
              Nuovo
            </button>
            <button type="button" className="lab-btn" onClick={() => setManual(true)}>
              Note
            </button>
          </div>
        </section>
        <aside className="lab-pane" data-active={mobile === "banco" || mobile === "archivio"}>
          <div className="lab-tabs">
            <button type="button" data-on={side === "dettagli" && mobile !== "archivio"} onClick={() => { setSide("dettagli"); setMobile("banco"); }}>
              Dettagli
            </button>
            <button type="button" data-on={side === "prove" && mobile !== "archivio"} onClick={() => { setSide("prove"); setMobile("banco"); }}>
              Prove
            </button>
            <button type="button" data-on={side === "archivio" || mobile === "archivio"} onClick={() => { setSide("archivio"); setMobile("archivio"); }}>
              Archivio
            </button>
          </div>
          {side === "dettagli" && mobile !== "archivio" ? <InspectorPanel /> : null}
          {side === "prove" && mobile !== "archivio" ? <ProofPanel /> : null}
          {side === "archivio" || mobile === "archivio" ? <ArchivePanel /> : null}
        </aside>
      </div>

      <nav className="lab-nav" aria-label="Sezioni">
        <button type="button" data-on={mobile === "scena"} onClick={() => setMobile("scena")}>Banco</button>
        <button type="button" data-on={mobile === "parti"} onClick={() => setMobile("parti")}>Parti</button>
        <button type="button" data-on={mobile === "banco"} onClick={() => { setSide(side === "archivio" ? "dettagli" : side); setMobile("banco"); }}>Scheda</button>
        <button type="button" data-on={mobile === "archivio"} onClick={() => setMobile("archivio")}>Archivio</button>
      </nav>

      {toast ? <div className="lab-toast">{toast}</div> : null}

      {assistant ? (
        <div className="lab-overlay">
          <AssistantPanel onClose={() => setAssistant(false)} />
        </div>
      ) : null}

      {dialog ? (
        <div className="lab-dialog">
          <article>
            <h2 className="text-lg font-semibold">{dialog === "delete" ? "Togliere i pezzi selezionati?" : "Aprire un banco vuoto?"}</h2>
            <p className="lab-note">
              {dialog === "delete"
                ? "Si possono riavere con Annulla. Le idee non si cancellano."
                : "Il banco attuale diventa una versione. Le idee restano."}
            </p>
            <div className="mt-3 flex gap-2">
              <button
                type="button"
                className="lab-btn primary"
                onClick={() => {
                  if (dialog === "delete") useLab.getState().deleteIds(useLab.getState().selectedIds);
                  else useLab.getState().newBench();
                  setDialog(null);
                }}
              >
                Conferma
              </button>
              <button type="button" className="lab-btn" onClick={() => setDialog(null)}>
                Annulla
              </button>
            </div>
          </article>
        </div>
      ) : null}

      {manual ? (
        <div className="lab-dialog">
          <article className="max-h-[80dvh] overflow-auto">
            <h2 className="text-lg font-semibold">Come è fatto il laboratorio</h2>
            <p className="lab-note">
              Un dito ruota la vista, due dita zoomano e scorrono. Sposta e Ruota mostrano il gizmo: su un motore muovono tutto il gruppo.
            </p>
            <p className="lab-note">
              L'animazione è cinematica: l'angolo del banco entra nel manovellismo e negli ingranaggi. Non è un motore che gira perché produce coppia.
            </p>
            <p className="lab-note">
              Le prove usano formule scritte accanto al numero: trazione semplice, F=kx, rapporto tra denti, ½ρv²CdA. Dove manca il solutore, manca il numero.
            </p>
            <p className="lab-note">
              L'interprete locale non è una chat. Grok, se presente, e un endpoint OpenAI-compatibile parlano davvero e propongono azioni da confermare. La chiave dell'endpoint non entra nel file di progetto.
            </p>
            <p className="lab-note">
              Salvataggio automatico su questo dispositivo. Esporta JSON per una copia. Si installa dalla pagina sul telefono, come le altre app di questo ambiente, e il banco si apre anche senza rete.
            </p>
            <button type="button" className="lab-btn mt-3" onClick={() => setManual(false)}>
              Chiudi
            </button>
          </article>
        </div>
      ) : null}

      <input
        ref={fileRef}
        type="file"
        accept="application/json,.json"
        className="hidden"
        onChange={(event) => {
          const file = event.target.files?.[0];
          event.target.value = "";
          if (!file) return;
          void file.text().then((text) => {
            const err = useLab.getState().importJson(text);
            if (err) useLab.setState({ toast: err });
          });
        }}
      />
    </div>
  );
}

function Tool({ icon, label, on, click }: { icon: ReactNode; label: string; on: boolean; click: () => void }) {
  return (
    <button type="button" className="lab-icon" aria-label={label} aria-pressed={on} onClick={click} data-on={on}>
      {icon}
    </button>
  );
}
