import { useMemo } from "react";
import { CartesianGrid, Line, LineChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import {
  dragForceN,
  frontalAreaM2,
  gearKinematics,
  inlineTorqueNm,
  naturalFreqHz,
  safetyFactor,
  sectionMm2,
  springEnergyJ,
  springForceN,
  stressMPa,
  totalMassKg,
  vehicleAccel,
} from "@/lib/lab/calc";
import { round } from "@/lib/lab/ids";
import { pistonSpeedMmS, readTravel } from "@/lib/lab/kinematics";
import { getMaterial, MATERIALS } from "@/lib/lab/materials";
import { useLab } from "@/lib/lab/store";
import type { Study } from "@/lib/lab/types";

function Row({ label, value, tag }: { label: string; value: string; tag?: string }) {
  return (
    <div className="lab-row">
      <span>
        {label} {tag ? <em className="lab-badge">{tag}</em> : null}
      </span>
      <span>{value}</span>
    </div>
  );
}

export function ProofPanel() {
  const parts = useLab((s) => s.parts);
  const assemblies = useLab((s) => s.assemblies);
  const joints = useLab((s) => s.joints);
  const study = useLab((s) => s.study);
  const sim = useLab((s) => s.sim);
  const selected = useLab((s) => s.selectedIds);
  const part = parts.find((p) => p.id === selected[0]);
  const stirling = [...assemblies].reverse().find((a) => a.kind === "stirling-gamma");
  const gears = [...assemblies].reverse().find((a) => a.kind === "ingranaggi");
  const spring = [...parts].reverse().find((p) => p.role === "spring");
  const lever = part?.role === "lever" ? part : parts.find((p) => p.role === "lever");

  const curve = useMemo(() => {
    if (!stirling) return [];
    const rows: { deg: number; pistone: number; displacer: number }[] = [];
    for (let deg = 0; deg <= 360; deg += 6) {
      const travel = readTravel(parts, stirling.id, (deg * Math.PI) / 180);
      if (!travel?.power || travel.dispY === null) continue;
      rows.push({ deg, pistone: round(travel.power.y, 2), displacer: round(travel.dispY, 2) });
    }
    return rows;
  }, [parts, stirling]);

  function setStudy(patch: Partial<Study>) {
    useLab.getState().setStudy(patch);
  }

  const travel = stirling ? readTravel(parts, stirling.id, sim.angle) : null;
  const omega = (sim.rpm * 2 * Math.PI) / 60;
  const speed =
    travel?.power
      ? pistonSpeedMmS(sim.angle, omega, travel.power.radius, travel.power.rod, travel.power.guide, travel.power.phase)
      : null;
  const pistonForce =
    travel?.power ? study.pressureKPa * 1000 * ((Math.PI * (travel.power.bore / 2) ** 2) / 1e6) : null;
  const torque =
    travel?.power && pistonForce !== null
      ? inlineTorqueNm(pistonForce, travel.power.radius, travel.power.rod, sim.angle)
      : null;

  const area = part ? sectionMm2(part) : null;
  const sigma = part && area ? stressMPa(study.forceN, area) : null;
  const fos = part && sigma ? safetyFactor(getMaterial(part.materialId).yieldMPa, sigma) : null;

  const driver = gears ? parts.find((p) => p.assemblyId === gears.id && p.role === "gear-driver") : undefined;
  const driven = gears ? parts.find((p) => p.assemblyId === gears.id && p.role === "gear-driven") : undefined;
  const gJoint = joints.find((j) => j.type === "ingranaggio" && driver && (j.a === driver.id || j.b === driver.id));
  const gear = driver && driven ? gearKinematics(driver.params.teeth ?? 18, driven.params.teeth ?? 36, sim.rpm, study.torqueNm, gJoint?.efficiency ?? 1) : null;

  const k = spring?.params.stiffness ?? 0;
  const x = spring?.params.deflection ?? 0;
  const fn = spring ? naturalFreqHz(k, study.massKg) : null;
  const body = parts.filter((p) => p.module === "carrozzeria" && p.visible);
  const span = body.length ? body : parts.filter((p) => p.visible);
  let minX = Infinity;
  let maxX = -Infinity;
  let minY = Infinity;
  let maxY = -Infinity;
  for (const p of span) {
    minX = Math.min(minX, p.position.x - p.size.x / 2);
    maxX = Math.max(maxX, p.position.x + p.size.x / 2);
    minY = Math.min(minY, p.position.y - p.size.y / 2);
    maxY = Math.max(maxY, p.position.y + p.size.y / 2);
  }
  const width = Number.isFinite(minX) ? Math.max(1, maxX - minX) : 180;
  const height = Number.isFinite(minY) ? Math.max(1, maxY - minY) : 90;
  const areaM2 = frontalAreaM2(width, height);
  const drag = dragForceN(1.225, study.airMs, study.cd, areaM2);
  const mass = Math.max(totalMassKg(parts), 0.001);
  const ride = vehicleAccel({ massKg: mass, driveN: study.driveN, crr: study.crr, gradePct: study.gradePct, dragN: drag });

  return (
    <div className="lab-scroll">
      <p className="lab-note">
        I cartellini distinguono il modello. Nessuna animazione qui è una prova fisica. CFD e FEA non ci sono.
      </p>
      <label className="lab-note block">
        Sovrapposizione sul banco
        <select value={study.mode} onChange={(event) => setStudy({ mode: event.target.value as Study["mode"] })}>
          <option value="nessuno">Nessuna</option>
          <option value="sforzo">Tinta di sforzo sul pezzo selezionato</option>
          <option value="flusso">Flusso illustrativo, non CFD</option>
        </select>
      </label>

      <h2 className="lab-kicker">Cinematica</h2>
      {travel?.power ? (
        <>
          <Row tag="cinematica" label="Quota pistone" value={`${round(travel.power.y, 1)} mm`} />
          <Row tag="cinematica" label="Quota displacer" value={travel.dispY === null ? "—" : `${round(travel.dispY, 1)} mm`} />
          <Row tag="cinematica" label="Escursione pistone" value={travel.powerSpan ? `${round(travel.powerSpan.max - travel.powerSpan.min, 1)} mm` : "—"} />
          <Row tag="cinematica" label="Velocità pistone" value={speed === null ? "—" : `${round(speed, 0)} mm/s`} />
          <Row tag="formula" label="Forza a pressione imposta" value={pistonForce === null ? "—" : `${round(pistonForce, 1)} N`} />
          <Row tag="formula" label="Coppia istantanea in linea" value={torque === null ? "—" : `${round(torque, 2)} N·m`} />
          <p className="lab-note">
            La pressione di {study.pressureKPa} kPa è un numero tuo, tenuto costante. Non è il ciclo Stirling. La coppia usa la formula del manovellismo in linea.
          </p>
          <label className="lab-note">
            Pressione imposta kPa
            <input
              inputMode="decimal"
              defaultValue={study.pressureKPa}
              key={study.pressureKPa}
              onBlur={(event) => setStudy({ pressureKPa: Number(event.target.value.replace(",", ".")) || 0 })}
            />
          </label>
          <div className="mt-2 h-44">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={curve}>
                <CartesianGrid stroke="var(--color-line)" />
                <XAxis dataKey="deg" stroke="var(--color-muted)" fontSize={11} />
                <YAxis stroke="var(--color-muted)" fontSize={11} width={42} />
                <Tooltip />
                <ReferenceLine x={round(((sim.angle * 180) / Math.PI) % 360, 0)} stroke="var(--color-brass)" />
                <Line type="monotone" dataKey="pistone" name="Pistone" dot={false} stroke="var(--color-brass)" strokeWidth={2} />
                <Line type="monotone" dataKey="displacer" name="Displacer" dot={false} stroke="var(--color-muted)" strokeWidth={1.5} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </>
      ) : (
        <p className="lab-note">Aggiungi uno Stirling Gamma per la curva di corsa.</p>
      )}

      <h2 className="lab-kicker">Trasmissione</h2>
      {gear ? (
        <>
          <Row tag="formula" label="Giri condotto" value={`${round(gear.rpmB, 1)} /min`} />
          <Row tag="formula" label="Coppia condotto" value={`${round(gear.torqueB, 2)} N·m`} />
          <Row tag="formula" label="Potenza ingresso" value={`${round(gear.powerA, 1)} W`} />
          <Row tag="formula" label="Potenza uscita" value={`${round(gear.powerB, 1)} W`} />
          <p className="lab-note">η = {gJoint?.efficiency ?? 1} è dichiarato sul giunto, non misurato. I denti sono schematici.</p>
        </>
      ) : (
        <p className="lab-note">Nessuna coppia di ingranaggi.</p>
      )}
      <label className="lab-note">
        Coppia in ingresso N·m
        <input inputMode="decimal" defaultValue={study.torqueNm} key={`t${study.torqueNm}`} onBlur={(event) => setStudy({ torqueNm: Number(event.target.value.replace(",", ".")) || 0 })} />
      </label>

      <h2 className="lab-kicker">Elastico</h2>
      {spring ? (
        <>
          <Row tag="formula" label="Forza F=kx" value={`${round(springForceN(k, x), 2)} N`} />
          <Row tag="formula" label="Energia" value={`${round(springEnergyJ(k, x), 4)} J`} />
          <Row tag="modello 1 GdL" label="Frequenza propria" value={fn ? `${round(fn, 2)} Hz` : "—"} />
          {fn && Math.abs(sim.rpm / 60 - fn) / fn < 0.15 ? (
            <p className="lab-note">I giri del banco sono vicini a quella frequenza. È un avviso del modello a una massa, non una risonanza misurata.</p>
          ) : null}
        </>
      ) : (
        <p className="lab-note">Nessuna molla.</p>
      )}
      <label className="lab-note">
        Massa appesa al modello kg
        <input inputMode="decimal" defaultValue={study.massKg} key={`m${study.massKg}`} onBlur={(event) => setStudy({ massKg: Number(event.target.value.replace(",", ".")) || 0 })} />
      </label>

      <h2 className="lab-kicker">Leva</h2>
      {lever ? (
        <Row
          tag="formula"
          label="F2 = F1·l1/l2"
          value={
            (lever.params.l2 ?? 0) === 0
              ? "—"
              : `${round((study.forceN * (lever.params.l1 ?? 0)) / (lever.params.l2 ?? 1), 1)} N`
          }
        />
      ) : (
        <p className="lab-note">Nessuna leva con bracci dichiarati.</p>
      )}

      <h2 className="lab-kicker">Sforzo</h2>
      <label className="lab-note">
        Forza N sul pezzo selezionato
        <input inputMode="decimal" defaultValue={study.forceN} key={`f${study.forceN}`} onBlur={(event) => setStudy({ forceN: Number(event.target.value.replace(",", ".")) || 0 })} />
      </label>
      {part && sigma !== null && fos !== null ? (
        <>
          <Row tag="trazione semplice" label={`σ su ${part.name}`} value={`${round(sigma, 2)} MPa`} />
          <Row tag="confronto" label="Sy / σ" value={round(fos, 2).toString()} />
          <p className="lab-note">
            {getMaterial(part.materialId).note} Sezione assunta {area ? round(area, 1) : "—"} mm². Non è una FEA: niente flessione, taglio o concentrazione.
          </p>
        </>
      ) : (
        <p className="lab-note">Seleziona un albero, una leva, un telaio o una molla per la sezione.</p>
      )}

      <h2 className="lab-kicker">Aria e veicolo</h2>
      <Row tag="stima" label="Area frontale da ingombri" value={`${round(areaM2, 4)} m²`} />
      <Row tag="stima" label="Resistenza ½ρv²CdA" value={`${round(drag, 1)} N`} />
      <Row tag="stima" label="Massa dei visibili" value={`${round(mass, 3)} kg`} />
      {ride ? <Row tag="stima" label="Accelerazione" value={`${round(ride.accel, 2)} m/s²`} /> : null}
      <p className="lab-note">{ride?.note} Il flusso nel banco è una grafica, non un campo di pressione.</p>
      <div className="lab-grid">
        <label className="lab-note">
          Cd
          <input inputMode="decimal" defaultValue={study.cd} key={`c${study.cd}`} onBlur={(event) => setStudy({ cd: Number(event.target.value.replace(",", ".")) || 0 })} />
        </label>
        <label className="lab-note">
          Vento m/s
          <input inputMode="decimal" defaultValue={study.airMs} key={`a${study.airMs}`} onBlur={(event) => setStudy({ airMs: Number(event.target.value.replace(",", ".")) || 0 })} />
        </label>
        <label className="lab-note">
          Spinta N
          <input inputMode="decimal" defaultValue={study.driveN} key={`d${study.driveN}`} onBlur={(event) => setStudy({ driveN: Number(event.target.value.replace(",", ".")) || 0 })} />
        </label>
        <label className="lab-note">
          Crr
          <input inputMode="decimal" defaultValue={study.crr} key={`r${study.crr}`} onBlur={(event) => setStudy({ crr: Number(event.target.value.replace(",", ".")) || 0 })} />
        </label>
      </div>

      <h2 className="lab-kicker">Materiali a parità di 100 cm³</h2>
      {MATERIALS.map((m) => (
        <div key={m.id} className="lab-row">
          <span>{m.name}</span>
          <span>{round((100_000 * m.density) / 1e6, 1)} g</span>
        </div>
      ))}
      <p className="lab-note">100 cm³ = 100 000 mm³. Massa = volume × densità da manuale.</p>
    </div>
  );
}
