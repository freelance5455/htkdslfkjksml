import React, { useEffect, useMemo, useState } from 'react';
import { ArrowDown, ArrowUp, Edit2, Plus, Search, Settings2, Trash2, X } from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  calculatePurchaseAmounts,
  formatCurrency,
  formatDate,
  formatNumber,
  round2,
  summarizePurchases,
} from '../utils/calculations';
import { generateId, getTodayIso } from '../utils/storage';
import type { ExpenseCategory, PaymentStatus, RateUnit } from '../types';
import { ConfirmModal } from './ConfirmModal';

const PAYMENT_METHODS = ['Cash', 'Bank Transfer', 'JazzCash', 'EasyPaisa', 'Card', 'Other'];

export const HomeModule: React.FC = () => {
  const {
    state,
    activeSubTab,
    focusedRecordId,
    clearFocusedRecord,
    tr,
    themeTokens,
    notify,
    upsertPurchase,
    deletePurchase,
    upsertExpense,
    deleteExpense,
    saveExpenseCategories,
  } = useApp();

  const [tab, setTab] = useState<'purchases' | 'expenses'>(
    activeSubTab === 'expenses' ? 'expenses' : 'purchases'
  );

  useEffect(() => {
    if (activeSubTab === 'expenses' || activeSubTab === 'purchases') {
      setTab(activeSubTab);
    }
  }, [activeSubTab]);

  // Confirm delete modal state
  const [confirmState, setConfirmState] = useState<{
    open: boolean;
    type: 'purchase' | 'expense';
    id: string;
    label: string;
  }>({ open: false, type: 'purchase', id: '', label: '' });

  // ==========================================
  // ATTA / PURCHASE STATE
  // ==========================================
  const [pEditId, setPEditId] = useState<string | null>(null);
  const [pDate, setPDate] = useState(getTodayIso());
  const [pRate, setPRate] = useState('');
  const [pRateUnit, setPRateUnit] = useState<RateUnit>('per_maund');
  const [pQtyMaund, setPQtyMaund] = useState('');
  const [pSupplier, setPSupplier] = useState('');
  const [pStatus, setPStatus] = useState<PaymentStatus>('Paid');
  const [pRemarks, setPRemarks] = useState('');
  const [pError, setPError] = useState('');
  const [pSubmitting, setPSubmitting] = useState(false);

  // Purchase filters
  const [pSearch, setPSearch] = useState('');
  const [pFrom, setPFrom] = useState('');
  const [pTo, setPTo] = useState('');
  const [pSupplierFilter, setPSupplierFilter] = useState('');
  const [pStatusFilter, setPStatusFilter] = useState('');
  const [pSortBy, setPSortBy] = useState<'date_desc' | 'date_asc' | 'amount_desc' | 'qty_desc'>('date_desc');

  const maundToKg = state.settings.maundToKg || 40;
  const cur = state.settings.currencyLabel || 'PKR';
  const dateFmt = state.settings.dateFormat;

  const livePurchaseCalc = useMemo(
    () =>
      calculatePurchaseAmounts(
        parseFloat(pRate) || 0,
        pRateUnit,
        parseFloat(pQtyMaund) || 0,
        maundToKg
      ),
    [pRate, pRateUnit, pQtyMaund, maundToKg]
  );

  const resetPurchaseForm = () => {
    setPEditId(null);
    setPDate(getTodayIso());
    setPRate('');
    setPRateUnit('per_maund');
    setPQtyMaund('');
    setPSupplier('');
    setPStatus('Paid');
    setPRemarks('');
    setPError('');
  };

  const handleSavePurchase = (e: React.FormEvent) => {
    e.preventDefault();
    if (pSubmitting) return;
    setPError('');

    const rateNum = parseFloat(pRate);
    const qtyNum = parseFloat(pQtyMaund);

    if (!pDate) {
      setPError('Purchase date is required.');
      return;
    }
    if (!Number.isFinite(rateNum) || (!state.settings.allowNegativePurchase && rateNum <= 0)) {
      setPError('Please enter a valid positive rate.');
      return;
    }
    if (!Number.isFinite(qtyNum) || (!state.settings.allowNegativePurchase && qtyNum <= 0)) {
      setPError('Please enter a valid quantity in Maund.');
      return;
    }

    setPSubmitting(true);
    const { equivalentKg, totalAmount } = calculatePurchaseAmounts(
      rateNum,
      pRateUnit,
      qtyNum,
      maundToKg
    );

    upsertPurchase(
      {
        date: pDate,
        rate: rateNum,
        rateUnit: pRateUnit,
        quantityMaund: qtyNum,
        equivalentKg,
        totalAmount,
        supplier: pSupplier.trim(),
        paymentStatus: pStatus,
        remarks: pRemarks.trim(),
      },
      pEditId || undefined
    );

    notify(pEditId ? 'Purchase updated.' : 'Purchase saved.');
    resetPurchaseForm();
    setTimeout(() => setPSubmitting(false), 150);
  };

  const startEditPurchase = (id: string) => {
    const rec = state.purchases.find((p) => p.id === id);
    if (!rec) return;
    setPEditId(rec.id);
    setPDate(rec.date);
    setPRate(String(rec.rate));
    setPRateUnit(rec.rateUnit);
    setPQtyMaund(String(rec.quantityMaund));
    setPSupplier(rec.supplier);
    setPStatus(rec.paymentStatus);
    setPRemarks(rec.remarks);
    setPError('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const uniqueSuppliers = useMemo(() => {
    const set = new Set<string>();
    state.purchases.forEach((p) => {
      if (p.supplier) set.add(p.supplier);
    });
    return Array.from(set).sort();
  }, [state.purchases]);

  const filteredPurchases = useMemo(() => {
    const q = pSearch.trim().toLowerCase();
    return state.purchases
      .filter((p) => {
        if (pFrom && p.date < pFrom) return false;
        if (pTo && p.date > pTo) return false;
        if (pSupplierFilter && p.supplier !== pSupplierFilter) return false;
        if (pStatusFilter && p.paymentStatus !== pStatusFilter) return false;
        if (q) {
          const hay = `${p.supplier} ${p.remarks} ${p.paymentStatus} ${p.date}`.toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      })
      .sort((a, b) => {
        if (pSortBy === 'date_asc') return a.date.localeCompare(b.date);
        if (pSortBy === 'amount_desc') return b.totalAmount - a.totalAmount;
        if (pSortBy === 'qty_desc') return b.quantityMaund - a.quantityMaund;
        return b.date.localeCompare(a.date);
      });
  }, [state.purchases, pSearch, pFrom, pTo, pSupplierFilter, pStatusFilter, pSortBy]);

  const purchaseSummary = useMemo(
    () => summarizePurchases(filteredPurchases, maundToKg),
    [filteredPurchases, maundToKg]
  );

  // ==========================================
  // HOUSEHOLD EXPENSES STATE
  // ==========================================
  const activeCategories = useMemo(
    () =>
      state.expenseCategories
        .filter((c) => c.active)
        .sort((a, b) => a.order - b.order),
    [state.expenseCategories]
  );

  const [eEditId, setEEditId] = useState<string | null>(null);
  const [eDate, setEDate] = useState(getTodayIso());
  const [eCategory, setECategory] = useState(activeCategories[0]?.name || 'Grocery');
  const [eDesc, setEDesc] = useState('');
  const [eAmount, setEAmount] = useState('');
  const [eMethod, setEMethod] = useState('Cash');
  const [ePaidTo, setEPaidTo] = useState('');
  const [eRemarks, setERemarks] = useState('');
  const [eError, setEError] = useState('');
  const [eSubmitting, setESubmitting] = useState(false);

  // Expense filters
  const [eSearch, setESearch] = useState('');
  const [eFrom, setEFrom] = useState('');
  const [eTo, setETo] = useState('');
  const [eCatFilter, setECatFilter] = useState('');
  const [eMethodFilter, setEMethodFilter] = useState('');

  // Category manager drawer
  const [showCatManager, setShowCatManager] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [editingCatId, setEditingCatId] = useState<string | null>(null);
  const [editingCatValue, setEditingCatValue] = useState('');

  useEffect(() => {
    if (focusedRecordId) {
      if (state.purchases.some((p) => p.id === focusedRecordId)) {
        setTab('purchases');
        startEditPurchase(focusedRecordId);
        clearFocusedRecord();
      } else if (state.expenses.some((ex) => ex.id === focusedRecordId)) {
        setTab('expenses');
        const rec = state.expenses.find((ex) => ex.id === focusedRecordId);
        if (rec) {
          setEEditId(rec.id);
          setEDate(rec.date);
          setECategory(rec.category);
          setEDesc(rec.description);
          setEAmount(String(rec.amount));
          setEMethod(rec.paymentMethod);
          setEPaidTo(rec.paidTo);
          setERemarks(rec.remarks);
        }
        clearFocusedRecord();
      }
    }
  }, [focusedRecordId, state.purchases, state.expenses, clearFocusedRecord]);

  const resetExpenseForm = () => {
    setEEditId(null);
    setEDate(getTodayIso());
    setECategory(activeCategories[0]?.name || 'Grocery');
    setEDesc('');
    setEAmount('');
    setEMethod('Cash');
    setEPaidTo('');
    setERemarks('');
    setEError('');
  };

  const handleSaveExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (eSubmitting) return;
    setEError('');

    const amt = parseFloat(eAmount);
    if (!eDate) {
      setEError('Date is required.');
      return;
    }
    if (!eCategory) {
      setEError('Category is required.');
      return;
    }
    if (!eDesc.trim()) {
      setEError('Description is required.');
      return;
    }
    if (!Number.isFinite(amt) || amt <= 0) {
      setEError('Please enter a valid positive amount.');
      return;
    }

    setESubmitting(true);
    upsertExpense(
      {
        date: eDate,
        category: eCategory,
        description: eDesc.trim(),
        amount: round2(amt),
        paymentMethod: eMethod,
        paidTo: ePaidTo.trim(),
        remarks: eRemarks.trim(),
      },
      eEditId || undefined
    );
    notify(eEditId ? 'Expense updated.' : 'Expense saved.');
    resetExpenseForm();
    setTimeout(() => setESubmitting(false), 150);
  };

  const startEditExpense = (id: string) => {
    const rec = state.expenses.find((ex) => ex.id === id);
    if (!rec) return;
    setEEditId(rec.id);
    setEDate(rec.date);
    setECategory(rec.category);
    setEDesc(rec.description);
    setEAmount(String(rec.amount));
    setEMethod(rec.paymentMethod);
    setEPaidTo(rec.paidTo);
    setERemarks(rec.remarks);
    setEError('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const filteredExpenses = useMemo(() => {
    const q = eSearch.trim().toLowerCase();
    return state.expenses
      .filter((ex) => {
        if (eFrom && ex.date < eFrom) return false;
        if (eTo && ex.date > eTo) return false;
        if (eCatFilter && ex.category !== eCatFilter) return false;
        if (eMethodFilter && ex.paymentMethod !== eMethodFilter) return false;
        if (q) {
          const hay = `${ex.category} ${ex.description} ${ex.paidTo} ${ex.remarks}`.toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      })
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [state.expenses, eSearch, eFrom, eTo, eCatFilter, eMethodFilter]);

  const expenseTotal = useMemo(
    () => round2(filteredExpenses.reduce((s, e) => s + e.amount, 0)),
    [filteredExpenses]
  );

  const expenseByCategory = useMemo(() => {
    const map = new Map<string, number>();
    filteredExpenses.forEach((ex) => {
      map.set(ex.category, round2((map.get(ex.category) || 0) + ex.amount));
    });
    return Array.from(map.entries()).sort((a, b) => b[1] - a[1]);
  }, [filteredExpenses]);

  // Category CRUD helpers
  const sortedCategories = useMemo(
    () => [...state.expenseCategories].sort((a, b) => a.order - b.order),
    [state.expenseCategories]
  );

  const handleAddCategory = () => {
    const trimmed = newCatName.trim();
    if (!trimmed) return;
    if (state.expenseCategories.some((c) => c.name.toLowerCase() === trimmed.toLowerCase())) {
      notify('Category already exists.', 'error');
      return;
    }
    const next: ExpenseCategory[] = [
      ...sortedCategories,
      { id: generateId('cat'), name: trimmed, active: true, order: sortedCategories.length + 1 },
    ];
    saveExpenseCategories(next, `Added expense category "${trimmed}"`);
    setNewCatName('');
    notify('Category added.');
  };

  const handleRenameCategory = (id: string) => {
    const trimmed = editingCatValue.trim();
    if (!trimmed) return;
    const next = sortedCategories.map((c) => (c.id === id ? { ...c, name: trimmed } : c));
    saveExpenseCategories(next, `Renamed expense category to "${trimmed}"`);
    setEditingCatId(null);
    setEditingCatValue('');
    notify('Category renamed.');
  };

  const handleToggleCategory = (id: string) => {
    const next = sortedCategories.map((c) => (c.id === id ? { ...c, active: !c.active } : c));
    saveExpenseCategories(next, 'Toggled expense category active state');
  };

  const handleMoveCategory = (index: number, dir: -1 | 1) => {
    const target = index + dir;
    if (target < 0 || target >= sortedCategories.length) return;
    const copy = [...sortedCategories];
    [copy[index], copy[target]] = [copy[target], copy[index]];
    const reordered = copy.map((c, idx) => ({ ...c, order: idx + 1 }));
    saveExpenseCategories(reordered, 'Reordered expense categories');
  };

  const handleDeleteCategory = (cat: ExpenseCategory) => {
    const used = state.expenses.some((e) => e.category === cat.name);
    if (used) {
      notify(`Cannot delete "${cat.name}" because existing expenses use it. Deactivate it instead.`, 'error');
      return;
    }
    const next = sortedCategories.filter((c) => c.id !== cat.id);
    saveExpenseCategories(next, `Deleted unused category "${cat.name}"`);
    notify('Category deleted.');
  };

  const triggerDelete = (type: 'purchase' | 'expense', id: string, label: string) => {
    if (!state.settings.confirmBeforeDelete) {
      if (type === 'purchase') deletePurchase(id);
      else deleteExpense(id);
      notify('Moved to Recycle Bin.');
      return;
    }
    setConfirmState({ open: true, type, id, label });
  };

  return (
    <div className="space-y-6">
      {/* Submodule Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="inline-flex rounded-lg bg-slate-200/70 p-1" role="tablist">
          <button
            type="button"
            role="tab"
            aria-selected={tab === 'purchases'}
            onClick={() => setTab('purchases')}
            className={`rounded-md px-4 py-2 text-sm font-medium transition-colors whitespace-nowrap ${
              tab === 'purchases'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tr('home_purchases')}
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={tab === 'expenses'}
            onClick={() => setTab('expenses')}
            className={`rounded-md px-4 py-2 text-sm font-medium transition-colors whitespace-nowrap ${
              tab === 'expenses'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tr('home_expenses')}
          </button>
        </div>

        {tab === 'expenses' && (
          <button
            type="button"
            onClick={() => setShowCatManager((v) => !v)}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
          >
            <Settings2 className="h-4 w-4" />
            <span>{tr('manage_categories')}</span>
          </button>
        )}
      </div>

      {/* ==========================================
          TAB A: ATTA / PURCHASE
         ========================================== */}
      {tab === 'purchases' && (
        <div className="space-y-6">
          {/* Summary Bar */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs text-slate-500">Total Purchased (Maund)</div>
              <div className="mt-1 text-xl font-bold text-slate-900 tabular-nums">
                {formatNumber(purchaseSummary.totalMaund)} Maund
              </div>
              <div className="text-xs text-slate-500 tabular-nums mt-0.5">
                {formatNumber(purchaseSummary.totalKg)} KG (1 Maund = {maundToKg} KG)
              </div>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs text-slate-500">Total Amount</div>
              <div className="mt-1 text-xl font-bold text-emerald-700 tabular-nums">
                {formatCurrency(purchaseSummary.totalAmount, cur)}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">{purchaseSummary.count} records</div>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs text-slate-500">Average Rate / Maund</div>
              <div className="mt-1 text-xl font-bold text-slate-900 tabular-nums">
                {formatCurrency(purchaseSummary.avgRatePerMaund, cur)}
              </div>
              <div className="text-xs text-slate-500 tabular-nums mt-0.5">
                Avg {formatCurrency(purchaseSummary.avgRatePerKg, cur)} / KG
              </div>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs text-slate-500">Pending Payment</div>
              <div className="mt-1 text-xl font-bold text-amber-700 tabular-nums">
                {formatCurrency(
                  round2(
                    filteredPurchases
                      .filter((p) => p.paymentStatus !== 'Paid')
                      .reduce((s, p) => s + p.totalAmount, 0)
                  ),
                  cur
                )}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">
                {filteredPurchases.filter((p) => p.paymentStatus !== 'Paid').length} unpaid/partial
              </div>
            </div>
          </div>

          {/* Purchase Form */}
          <form onSubmit={handleSavePurchase} className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900">
                {pEditId ? tr('edit_purchase') : tr('add_purchase')}
              </h3>
              {pEditId && (
                <button
                  type="button"
                  onClick={resetPurchaseForm}
                  className="text-xs text-slate-500 hover:text-slate-800"
                >
                  {tr('cancel')}
                </button>
              )}
            </div>

            {pError && (
              <div role="alert" className="rounded-lg bg-red-50 border border-red-200 px-3.5 py-2.5 text-xs font-medium text-red-700">
                {pError}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label htmlFor="p-date" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('purchase_date')} *
                </label>
                <input
                  id="p-date"
                  type="date"
                  value={pDate}
                  onChange={(e) => setPDate(e.target.value)}
                  required
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="p-rate-unit" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('rate_unit')} *
                </label>
                <select
                  id="p-rate-unit"
                  value={pRateUnit}
                  onChange={(e) => setPRateUnit(e.target.value as RateUnit)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white focus:border-emerald-600 focus:outline-none"
                >
                  <option value="per_maund">{tr('per_maund')}</option>
                  <option value="per_kg">{tr('per_kg')}</option>
                </select>
              </div>

              <div>
                <label htmlFor="p-rate" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('rate')} ({pRateUnit === 'per_maund' ? tr('per_maund') : tr('per_kg')}) *
                </label>
                <input
                  id="p-rate"
                  type="number"
                  step="any"
                  value={pRate}
                  onChange={(e) => setPRate(e.target.value)}
                  placeholder="e.g. 3200"
                  required
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums focus:border-emerald-600 focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="p-qty" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('qty_maund')} *
                </label>
                <input
                  id="p-qty"
                  type="number"
                  step="any"
                  value={pQtyMaund}
                  onChange={(e) => setPQtyMaund(e.target.value)}
                  placeholder="e.g. 2.5"
                  required
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums focus:border-emerald-600 focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="p-equiv-kg" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('equiv_kg')} (Auto)
                </label>
                <input
                  id="p-equiv-kg"
                  type="text"
                  readOnly
                  value={`${formatNumber(livePurchaseCalc.equivalentKg)} KG`}
                  className="w-full rounded-lg border border-slate-200 bg-slate-100 px-3 py-2 text-sm font-mono tabular-nums text-slate-700"
                />
              </div>

              <div>
                <label htmlFor="p-total" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('total_amount')} (Auto)
                </label>
                <input
                  id="p-total"
                  type="text"
                  readOnly
                  value={formatCurrency(livePurchaseCalc.totalAmount, cur)}
                  className="w-full rounded-lg border border-emerald-200 bg-emerald-50/70 px-3 py-2 text-sm font-semibold tabular-nums text-emerald-900"
                />
              </div>

              <div>
                <label htmlFor="p-supplier" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('supplier')}
                </label>
                <input
                  id="p-supplier"
                  type="text"
                  value={pSupplier}
                  onChange={(e) => setPSupplier(e.target.value)}
                  placeholder="Flour Mill / Trader"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="p-status" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('payment_status')}
                </label>
                <select
                  id="p-status"
                  value={pStatus}
                  onChange={(e) => setPStatus(e.target.value as PaymentStatus)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white focus:border-emerald-600 focus:outline-none"
                >
                  <option value="Paid">Paid</option>
                  <option value="Pending">Pending</option>
                  <option value="Partial">Partial</option>
                </select>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 items-end">
              <div className="flex-1 w-full">
                <label htmlFor="p-remarks" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('remarks')}
                </label>
                <input
                  id="p-remarks"
                  type="text"
                  value={pRemarks}
                  onChange={(e) => setPRemarks(e.target.value)}
                  placeholder="Optional notes, bag count, quality..."
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-none"
                />
              </div>
              <button
                type="submit"
                disabled={pSubmitting}
                className={`inline-flex items-center justify-center gap-2 rounded-lg px-5 py-2 text-sm font-medium text-white whitespace-nowrap shrink-0 ${themeTokens.accentBg} ${themeTokens.accentHover} disabled:opacity-60`}
              >
                <Plus className="h-4 w-4" />
                <span>{pEditId ? tr('update') : tr('save')}</span>
              </button>
            </div>
          </form>

          {/* Purchase Filters & Table */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="p-4 border-b border-slate-200 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-2.5">
              <div className="relative lg:col-span-2">
                <Search className="h-4 w-4 text-slate-400 absolute start-3 top-2.5" />
                <input
                  type="text"
                  value={pSearch}
                  onChange={(e) => setPSearch(e.target.value)}
                  placeholder={`${tr('search')} supplier or remarks...`}
                  aria-label="Search purchases"
                  className="w-full rounded-lg border border-slate-300 ps-9 pe-3 py-2 text-xs focus:border-emerald-600 focus:outline-none"
                />
              </div>
              <input
                type="date"
                value={pFrom}
                onChange={(e) => setPFrom(e.target.value)}
                aria-label="Filter purchases from date"
                className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs"
              />
              <input
                type="date"
                value={pTo}
                onChange={(e) => setPTo(e.target.value)}
                aria-label="Filter purchases to date"
                className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs"
              />
              <select
                value={pSupplierFilter}
                onChange={(e) => setPSupplierFilter(e.target.value)}
                aria-label="Filter by supplier"
                className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs bg-white"
              >
                <option value="">All Suppliers</option>
                {uniqueSuppliers.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
              <div className="flex gap-2">
                <select
                  value={pStatusFilter}
                  onChange={(e) => setPStatusFilter(e.target.value)}
                  aria-label="Filter by payment status"
                  className="flex-1 rounded-lg border border-slate-300 px-2 py-2 text-xs bg-white"
                >
                  <option value="">All Status</option>
                  <option value="Paid">Paid</option>
                  <option value="Pending">Pending</option>
                  <option value="Partial">Partial</option>
                </select>
                <select
                  value={pSortBy}
                  onChange={(e) => setPSortBy(e.target.value as typeof pSortBy)}
                  aria-label="Sort purchases"
                  className="flex-1 rounded-lg border border-slate-300 px-2 py-2 text-xs bg-white"
                >
                  <option value="date_desc">Newest</option>
                  <option value="date_asc">Oldest</option>
                  <option value="amount_desc">Amount</option>
                  <option value="qty_desc">Maund</option>
                </select>
              </div>
            </div>

            {filteredPurchases.length === 0 ? (
              <div className="px-5 py-10 text-center text-sm text-slate-500">{tr('no_records')}</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                    <tr>
                      <th className="px-4 py-3 text-start">{tr('date')}</th>
                      <th className="px-4 py-3 text-start">{tr('supplier')}</th>
                      <th className="px-4 py-3 text-end">Maund</th>
                      <th className="px-4 py-3 text-end">KG</th>
                      <th className="px-4 py-3 text-end">{tr('rate')}</th>
                      <th className="px-4 py-3 text-end">{tr('total_amount')}</th>
                      <th className="px-4 py-3 text-start">{tr('payment_status')}</th>
                      <th className="px-4 py-3 text-end">{tr('actions')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredPurchases.map((p) => (
                      <tr key={p.id} className="hover:bg-slate-50">
                        <td className="px-4 py-3 whitespace-nowrap tabular-nums">
                          {formatDate(p.date, dateFmt)}
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-medium text-slate-900">{p.supplier || '—'}</div>
                          {p.remarks && <div className="text-xs text-slate-500">{p.remarks}</div>}
                        </td>
                        <td className="px-4 py-3 text-end tabular-nums font-medium">
                          {formatNumber(p.quantityMaund)}
                        </td>
                        <td className="px-4 py-3 text-end tabular-nums text-slate-600">
                          {formatNumber(p.equivalentKg)}
                        </td>
                        <td className="px-4 py-3 text-end tabular-nums text-slate-600 whitespace-nowrap">
                          {formatNumber(p.rate)} / {p.rateUnit === 'per_maund' ? 'Maund' : 'KG'}
                        </td>
                        <td className="px-4 py-3 text-end tabular-nums font-semibold text-slate-900 whitespace-nowrap">
                          {formatCurrency(p.totalAmount, cur)}
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <span
                            className={`text-xs font-medium ${
                              p.paymentStatus === 'Paid'
                                ? 'text-emerald-700'
                                : p.paymentStatus === 'Pending'
                                  ? 'text-red-700'
                                  : 'text-amber-700'
                            }`}
                          >
                            {p.paymentStatus}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-end whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => startEditPurchase(p.id)}
                            aria-label={`Edit purchase ${p.supplier || p.date}`}
                            className="p-1.5 text-slate-500 hover:text-emerald-700 rounded"
                          >
                            <Edit2 className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              triggerDelete(
                                'purchase',
                                p.id,
                                `${p.quantityMaund} Maund (${p.supplier || p.date})`
                              )
                            }
                            aria-label={`Delete purchase ${p.supplier || p.date}`}
                            className="p-1.5 text-slate-500 hover:text-red-600 rounded"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ==========================================
          TAB B: HOUSEHOLD EXPENSES
         ========================================== */}
      {tab === 'expenses' && (
        <div className="space-y-6">
          {/* Category Manager Panel */}
          {showCatManager && (
            <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-slate-900">{tr('manage_categories')}</h3>
                <button
                  type="button"
                  onClick={() => setShowCatManager(false)}
                  aria-label="Close category manager"
                  className="p-1 text-slate-400 hover:text-slate-700"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  placeholder="New category name..."
                  aria-label="New category name"
                  className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
                <button
                  type="button"
                  onClick={handleAddCategory}
                  className={`rounded-lg px-4 py-2 text-sm font-medium text-white ${themeTokens.accentBg} ${themeTokens.accentHover}`}
                >
                  Add Category
                </button>
              </div>
              <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg">
                {sortedCategories.map((cat, idx) => (
                  <div key={cat.id} className="flex items-center justify-between gap-2 px-3 py-2 text-sm">
                    {editingCatId === cat.id ? (
                      <div className="flex items-center gap-2 flex-1">
                        <input
                          type="text"
                          value={editingCatValue}
                          onChange={(e) => setEditingCatValue(e.target.value)}
                          className="flex-1 rounded border border-slate-300 px-2 py-1 text-sm"
                        />
                        <button
                          type="button"
                          onClick={() => handleRenameCategory(cat.id)}
                          className="text-xs font-medium text-emerald-700"
                        >
                          Save
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingCatId(null)}
                          className="text-xs text-slate-500"
                        >
                          Cancel
                        </button>
                      </div>
                    ) : (
                      <span className={cat.active ? 'text-slate-900 font-medium' : 'text-slate-400 line-through'}>
                        {cat.name}
                      </span>
                    )}
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleMoveCategory(idx, -1)}
                        disabled={idx === 0}
                        aria-label={`Move ${cat.name} up`}
                        className="p-1 text-slate-500 hover:text-slate-800 disabled:opacity-30"
                      >
                        <ArrowUp className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleMoveCategory(idx, 1)}
                        disabled={idx === sortedCategories.length - 1}
                        aria-label={`Move ${cat.name} down`}
                        className="p-1 text-slate-500 hover:text-slate-800 disabled:opacity-30"
                      >
                        <ArrowDown className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setEditingCatId(cat.id);
                          setEditingCatValue(cat.name);
                        }}
                        className="px-2 py-1 text-xs text-slate-600 hover:text-emerald-700"
                      >
                        Rename
                      </button>
                      <button
                        type="button"
                        onClick={() => handleToggleCategory(cat.id)}
                        className="px-2 py-1 text-xs text-slate-600 hover:text-slate-900"
                      >
                        {cat.active ? 'Deactivate' : 'Activate'}
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteCategory(cat)}
                        aria-label={`Delete category ${cat.name}`}
                        className="p-1 text-slate-400 hover:text-red-600"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Expense Summary */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-3.5">
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs text-slate-500">Filtered Total Expenses</div>
              <div className="mt-1 text-2xl font-bold text-slate-900 tabular-nums">
                {formatCurrency(expenseTotal, cur)}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">{filteredExpenses.length} entries</div>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-4 lg:col-span-2">
              <div className="text-xs text-slate-500 mb-2">Top Categories in Current View</div>
              {expenseByCategory.length === 0 ? (
                <div className="text-xs text-slate-400">No expense totals yet.</div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                  {expenseByCategory.slice(0, 6).map(([cat, amt]) => (
                    <div key={cat} className="flex items-center justify-between gap-2 border-b border-slate-100 pb-1">
                      <span className="text-slate-600 truncate">{cat}</span>
                      <span className="font-semibold text-slate-900 tabular-nums shrink-0">
                        {formatCurrency(amt, cur)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Expense Form */}
          <form onSubmit={handleSaveExpense} className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900">
                {eEditId ? tr('edit_expense') : tr('add_expense')}
              </h3>
              {eEditId && (
                <button
                  type="button"
                  onClick={resetExpenseForm}
                  className="text-xs text-slate-500 hover:text-slate-800"
                >
                  {tr('cancel')}
                </button>
              )}
            </div>

            {eError && (
              <div role="alert" className="rounded-lg bg-red-50 border border-red-200 px-3.5 py-2.5 text-xs font-medium text-red-700">
                {eError}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label htmlFor="e-date" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('date')} *
                </label>
                <input
                  id="e-date"
                  type="date"
                  value={eDate}
                  onChange={(e) => setEDate(e.target.value)}
                  required
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>

              <div>
                <label htmlFor="e-cat" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('category')} *
                </label>
                <select
                  id="e-cat"
                  value={eCategory}
                  onChange={(e) => setECategory(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                >
                  {activeCategories.map((c) => (
                    <option key={c.id} value={c.name}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="e-desc" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('description')} *
                </label>
                <input
                  id="e-desc"
                  type="text"
                  value={eDesc}
                  onChange={(e) => setEDesc(e.target.value)}
                  placeholder="e.g. Monthly Electricity Bill"
                  required
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>

              <div>
                <label htmlFor="e-amount" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('amount')} ({cur}) *
                </label>
                <input
                  id="e-amount"
                  type="number"
                  step="any"
                  value={eAmount}
                  onChange={(e) => setEAmount(e.target.value)}
                  placeholder="0"
                  required
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
                />
              </div>

              <div>
                <label htmlFor="e-method" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('payment_method')}
                </label>
                <select
                  id="e-method"
                  value={eMethod}
                  onChange={(e) => setEMethod(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                >
                  {PAYMENT_METHODS.map((m) => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="e-paidto" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('paid_to')}
                </label>
                <input
                  id="e-paidto"
                  type="text"
                  value={ePaidTo}
                  onChange={(e) => setEPaidTo(e.target.value)}
                  placeholder="Shop / Utility / Person"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>

              <div className="sm:col-span-2 flex gap-3 items-end">
                <div className="flex-1">
                  <label htmlFor="e-remarks" className="block text-xs font-medium text-slate-700 mb-1">
                    {tr('remarks')}
                  </label>
                  <input
                    id="e-remarks"
                    type="text"
                    value={eRemarks}
                    onChange={(e) => setERemarks(e.target.value)}
                    placeholder="Optional notes..."
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>
                <button
                  type="submit"
                  disabled={eSubmitting}
                  className={`inline-flex items-center gap-2 rounded-lg px-5 py-2 text-sm font-medium text-white whitespace-nowrap shrink-0 ${themeTokens.accentBg} ${themeTokens.accentHover}`}
                >
                  <Plus className="h-4 w-4" />
                  <span>{eEditId ? tr('update') : tr('save')}</span>
                </button>
              </div>
            </div>
          </form>

          {/* Expense Filters & Table */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="p-4 border-b border-slate-200 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-2.5">
              <div className="relative lg:col-span-2">
                <Search className="h-4 w-4 text-slate-400 absolute start-3 top-2.5" />
                <input
                  type="text"
                  value={eSearch}
                  onChange={(e) => setESearch(e.target.value)}
                  placeholder={`${tr('search')} expenses...`}
                  aria-label="Search expenses"
                  className="w-full rounded-lg border border-slate-300 ps-9 pe-3 py-2 text-xs"
                />
              </div>
              <input
                type="date"
                value={eFrom}
                onChange={(e) => setEFrom(e.target.value)}
                aria-label="Filter expenses from date"
                className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs"
              />
              <input
                type="date"
                value={eTo}
                onChange={(e) => setETo(e.target.value)}
                aria-label="Filter expenses to date"
                className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs"
              />
              <select
                value={eCatFilter}
                onChange={(e) => setECatFilter(e.target.value)}
                aria-label="Filter by expense category"
                className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs bg-white"
              >
                <option value="">All Categories</option>
                {sortedCategories.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
              <select
                value={eMethodFilter}
                onChange={(e) => setEMethodFilter(e.target.value)}
                aria-label="Filter by payment method"
                className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs bg-white"
              >
                <option value="">All Methods</option>
                {PAYMENT_METHODS.map((m) => (
                  <option key={m} value={m}>
                    {m}
                  </option>
                ))}
              </select>
            </div>

            {filteredExpenses.length === 0 ? (
              <div className="px-5 py-10 text-center text-sm text-slate-500">{tr('no_records')}</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                    <tr>
                      <th className="px-4 py-3 text-start">{tr('date')}</th>
                      <th className="px-4 py-3 text-start">{tr('category')}</th>
                      <th className="px-4 py-3 text-start">{tr('description')}</th>
                      <th className="px-4 py-3 text-start">{tr('payment_method')}</th>
                      <th className="px-4 py-3 text-end">{tr('amount')}</th>
                      <th className="px-4 py-3 text-end">{tr('actions')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredExpenses.map((ex) => (
                      <tr key={ex.id} className="hover:bg-slate-50">
                        <td className="px-4 py-3 whitespace-nowrap tabular-nums">
                          {formatDate(ex.date, dateFmt)}
                        </td>
                        <td className="px-4 py-3 font-medium text-slate-700 whitespace-nowrap">
                          {ex.category}
                        </td>
                        <td className="px-4 py-3">
                          <div className="text-slate-900">{ex.description}</div>
                          {(ex.paidTo || ex.remarks) && (
                            <div className="text-xs text-slate-500">
                              {[ex.paidTo, ex.remarks].filter(Boolean).join(' · ')}
                            </div>
                          )}
                        </td>
                        <td className="px-4 py-3 text-slate-600 whitespace-nowrap">
                          {ex.paymentMethod}
                        </td>
                        <td className="px-4 py-3 text-end tabular-nums font-semibold text-slate-900 whitespace-nowrap">
                          {formatCurrency(ex.amount, cur)}
                        </td>
                        <td className="px-4 py-3 text-end whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => startEditExpense(ex.id)}
                            aria-label={`Edit expense ${ex.description}`}
                            className="p-1.5 text-slate-500 hover:text-emerald-700 rounded"
                          >
                            <Edit2 className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => triggerDelete('expense', ex.id, ex.description)}
                            aria-label={`Delete expense ${ex.description}`}
                            className="p-1.5 text-slate-500 hover:text-red-600 rounded"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      <ConfirmModal
        open={confirmState.open}
        title={tr('confirm_delete_title')}
        message={`${tr('confirm_delete_msg')} (${confirmState.label})`}
        confirmLabel={tr('delete')}
        cancelLabel={tr('cancel')}
        onCancel={() => setConfirmState((s) => ({ ...s, open: false }))}
        onConfirm={() => {
          if (confirmState.type === 'purchase') deletePurchase(confirmState.id);
          else deleteExpense(confirmState.id);
          notify('Moved to Recycle Bin.');
          setConfirmState((s) => ({ ...s, open: false }));
        }}
      />
    </div>
  );
};
