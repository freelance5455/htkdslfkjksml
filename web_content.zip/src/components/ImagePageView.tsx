import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Image as ImageIcon, Download, Share2, Heart, MessageSquare, Bell, DollarSign, Send, Check, Shield, Sparkles, Upload, FileImage, Plus, X, Search, Filter, HardDrive, CheckCircle2, Eye, Maximize2, Tag } from 'lucide-react';
import { offlineCache } from '../lib/offlineCache';
import { tagManagementService } from '../lib/tagManagementService';
import { UploadedMediaItem } from '../types';

interface ImagePageViewProps {
  onOpenSupportModal?: () => void;
}

export const ImagePageView: React.FC<ImagePageViewProps> = ({ onOpenSupportModal }) => {
  const [mediaList, setMediaList] = useState<UploadedMediaItem[]>(
    offlineCache.getUploadedMedia().filter(m => m.type === 'image')
  );

  const [searchQuery, setSearchQuery] = useState('');
  const [commentInputs, setCommentInputs] = useState<{ [key: string]: string }>({});
  const [replyInputs, setReplyInputs] = useState<{ [key: string]: { [commentId: string]: string } }>({});
  const [shareNotice, setShareNotice] = useState<string | null>(null);
  const [showUploadDrawer, setShowUploadDrawer] = useState(false);
  const [lightboxImage, setLightboxImage] = useState<UploadedMediaItem | null>(null);

  // Image Upload Form State
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string | null>(null);
  const [imageTitle, setImageTitle] = useState('');
  const [creatorName, setCreatorName] = useState('Prophet JUHNKRIX SYNVAGORD');
  const [artworkCategory, setArtworkCategory] = useState('Celestial Sanctuary Glory');
  const [scriptureRef, setScriptureRef] = useState('Exodus 25:8');
  const [tagsInput, setTagsInput] = useState('sanctuary, glory, vision, banner');
  const [imageDescription, setImageDescription] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadSuccessToast, setUploadSuccessToast] = useState<string | null>(null);

  useEffect(() => {
    const handleSync = () => {
      setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'image'));
    };
    const unsubscribe = offlineCache.subscribe(handleSync);
    window.addEventListener('juhnkrix-media-updated', handleSync);
    return () => {
      if (typeof unsubscribe === 'function') unsubscribe();
      window.removeEventListener('juhnkrix-media-updated', handleSync);
    };
  }, []);

  const profile = offlineCache.getProfile();
  const userName = profile.name || 'Prophetic Believer';

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const file = files[0];
    setSelectedFile(file);

    const prevUrl = URL.createObjectURL(file);
    setImagePreviewUrl(prevUrl);

    if (!imageTitle) {
      const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[_]/g, ' ');
      setImageTitle(cleanName.charAt(0).toUpperCase() + cleanName.slice(1));
    }
    if (!imageDescription) {
      setImageDescription(`Anointed prophetic Imoge stored directly into the JUHNKRIX MUSIKA sanctuary vault.`);
    }
  };

  const handleDeviceImageUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) {
      alert('Please select an image file from your device first.');
      return;
    }

    setIsUploading(true);
    setUploadProgress(20);

    try {
      const progressTimer = setInterval(() => {
        setUploadProgress((prev) => {
          if (prev >= 90) {
            clearInterval(progressTimer);
            return 90;
          }
          return prev + 25;
        });
      }, 100);

      const titleToSave = imageTitle.trim() || selectedFile.name.replace(/\.[^/.]+$/, '');
      const descToSave = `${imageDescription.trim()} [Category: ${artworkCategory} | Scripture: ${scriptureRef}]`;
      const parsedTags = tagsInput
        .split(',')
        .map((s) => s.trim().toLowerCase().replace(/^#/, ''))
        .filter(Boolean);

      await offlineCache.uploadDeviceMedia(selectedFile, {
        type: 'image',
        title: titleToSave,
        artistOrProphet: creatorName.trim() || 'Prophet JUHNKRIX SYNVAGORD',
        description: descToSave,
        tags: parsedTags.length > 0 ? parsedTags : ['sanctuary', 'glory', 'vision', 'image']
      });

      setUploadProgress(100);
      clearInterval(progressTimer);

      setTimeout(() => {
        setIsUploading(false);
        setUploadProgress(0);
        setSelectedFile(null);
        setImagePreviewUrl(null);
        setImageTitle('');
        setImageDescription('');
        setShowUploadDrawer(false);
        setUploadSuccessToast(`✓ Prophetic Imoge "${titleToSave}" uploaded and stored in JUHNKRIX MUSIKA storage!`);
        setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'image'));
        setTimeout(() => setUploadSuccessToast(null), 5000);
      }, 400);
    } catch (err) {
      console.error('Image upload error:', err);
      setIsUploading(false);
      alert('Failed to process image file. Please try again.');
    }
  };

  const handleLike = (id: string) => {
    offlineCache.toggleLikeMedia(id);
    setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'image'));
  };

  const handleDownload = (item: UploadedMediaItem) => {
    offlineCache.incrementDownloadMedia(item.id);
    setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'image'));
    try {
      const a = document.createElement('a');
      a.href = item.url;
      a.download = `${item.title.replace(/\s+/g, '_')}.jpg`;
      a.target = '_blank';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch {
      window.open(item.url, '_blank');
    }
  };

  const handleShare = (item: UploadedMediaItem) => {
    offlineCache.incrementShareMedia(item.id);
    setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'image'));
    navigator.clipboard?.writeText(window.location.href);
    setShareNotice(`Link copied for "${item.title}"!`);
    setTimeout(() => setShareNotice(null), 3000);
  };

  const handleSubscribe = (id: string) => {
    offlineCache.toggleSubscribeMedia(id);
    setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'image'));
  };

  const handleAddComment = (mediaId: string, e: React.FormEvent) => {
    e.preventDefault();
    const text = commentInputs[mediaId];
    if (!text || !text.trim()) return;
    offlineCache.addCommentMedia(mediaId, text.trim(), userName);
    setCommentInputs({ ...commentInputs, [mediaId]: '' });
    setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'image'));
  };

  const handleAddReply = (mediaId: string, commentId: string, e: React.FormEvent) => {
    e.preventDefault();
    const text = replyInputs[mediaId]?.[commentId];
    if (!text || !text.trim()) return;
    offlineCache.addReplyCommentMedia(mediaId, commentId, text.trim(), userName);
    setReplyInputs({
      ...replyInputs,
      [mediaId]: { ...replyInputs[mediaId], [commentId]: '' }
    });
    setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'image'));
  };

  const filteredMedia = mediaList.filter(item => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      item.title.toLowerCase().includes(q) ||
      item.description.toLowerCase().includes(q) ||
      item.artistOrProphet.toLowerCase().includes(q)
    );
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-8 max-w-5xl mx-auto pb-20 px-4 sm:px-6"
    >
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-950/90 via-slate-900 to-slate-950 border border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-mono">
              <Shield className="w-3.5 h-3.5 text-amber-400" />
              <span>Prophet JUHNKRIX SYNVAGORD • Inbuilt Imoges Gallery Vault</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold font-serif tracking-tight text-amber-100">
              IMAGE & IMOGES GALLERY
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Explore high-definition prophetic Imoges, sanctuary glory banners, and spiritual artwork. Upload images directly from your device storage to store permanently in JUHNKRIX MUSIKA inbuilt storage.
            </p>
          </div>
          
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setShowUploadDrawer(!showUploadDrawer)}
              className="flex items-center space-x-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 text-xs font-black shadow-xl shadow-amber-500/30 hover:scale-105 transition-all border border-amber-300"
            >
              <Upload className="w-4 h-4" />
              <span>{showUploadDrawer ? 'Close Uploader' : '📤 Upload Image from Device'}</span>
            </button>
            <button
              onClick={onOpenSupportModal}
              className="flex items-center space-x-2 px-4 py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 text-amber-300 text-xs font-bold border border-amber-500/30 transition-all"
            >
              <DollarSign className="w-4 h-4 text-amber-400" />
              <span>Support Ministry</span>
            </button>
          </div>
        </div>
      </div>

      {/* Upload Success Toast */}
      {uploadSuccessToast && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-emerald-950/90 border border-emerald-500/50 text-emerald-200 text-xs px-5 py-4 rounded-2xl shadow-xl flex items-center justify-between"
        >
          <div className="flex items-center space-x-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span className="font-bold">{uploadSuccessToast}</span>
          </div>
          <span className="text-[11px] font-mono text-emerald-300/80">Reflected Publicly</span>
        </motion.div>
      )}

      {/* Share Notice Toast */}
      {shareNotice && (
        <div className="bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs px-4 py-3 rounded-2xl shadow-lg flex items-center space-x-2">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{shareNotice}</span>
        </div>
      )}

      {/* Dedicated Inbuilt Image Device Uploader Panel */}
      <AnimatePresence>
        {showUploadDrawer && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="bg-slate-900 border-2 border-amber-500/50 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 relative">
              <div className="flex items-center justify-between border-b border-amber-500/20 pb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                    <FileImage className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-base sm:text-lg font-bold font-serif text-amber-100">
                      Upload Image to Image Page & Inbuilt Storage
                    </h2>
                    <p className="text-xs text-amber-300/80 font-mono">
                      Select image from device storage (.jpg, .png, .webp, .gif) • Stored permanently in IndexedDB
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setShowUploadDrawer(false)}
                  className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white border border-amber-500/20"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleDeviceImageUpload} className="space-y-6">
                {/* File Drop / Select Area */}
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileSelect}
                  accept="image/*,.jpg,.jpeg,.png,.webp,.gif"
                  className="hidden"
                />

                <div
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all ${
                    selectedFile
                      ? 'border-emerald-500/60 bg-emerald-950/20'
                      : 'border-amber-500/40 hover:border-amber-400 bg-slate-950/80'
                  }`}
                >
                  {selectedFile ? (
                    <div className="space-y-2">
                      <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/40">
                        <FileImage className="w-6 h-6" />
                      </div>
                      <p className="text-xs sm:text-sm font-bold text-emerald-200">
                        Selected: {selectedFile.name}
                      </p>
                      <p className="text-[11px] font-mono text-slate-400">
                        Size: {(selectedFile.size / (1024 * 1024)).toFixed(2)} MB • Type: {selectedFile.type || 'image/jpeg'}
                      </p>
                      <span className="inline-block px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-mono border border-emerald-500/30">
                        Click to change image
                      </span>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto border border-amber-500/40">
                        <Upload className="w-6 h-6" />
                      </div>
                      <p className="text-xs sm:text-sm font-bold text-amber-200">
                        Click to Select Image / Imoge Directly from Device Storage
                      </p>
                      <p className="text-[11px] text-slate-400">
                        Supports JPEG, PNG, WebP, GIF high-res formats
                      </p>
                    </div>
                  )}
                </div>

                {/* High-Res Image Preview */}
                {imagePreviewUrl && (
                  <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/30 space-y-2">
                    <p className="text-[11px] font-mono font-bold text-amber-300 flex items-center space-x-2">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      <span>Imoge Preview (Before Storage)</span>
                    </p>
                    <img
                      src={imagePreviewUrl}
                      alt="Preview"
                      className="w-full max-h-64 object-contain rounded-xl bg-black"
                    />
                  </div>
                )}

                {/* Metadata Fields */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[11px] font-bold text-amber-300 block mb-1">
                      Artwork / Imoge Title *
                    </label>
                    <input
                      type="text"
                      required
                      value={imageTitle}
                      onChange={(e) => setImageTitle(e.target.value)}
                      placeholder="e.g. Celestial Glory of the Sanctuary"
                      className="w-full bg-slate-950 text-amber-100 border border-amber-500/30 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-amber-400 font-bold"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-amber-300 block mb-1">
                      Prophet / Minister / Creator
                    </label>
                    <input
                      type="text"
                      value={creatorName}
                      onChange={(e) => setCreatorName(e.target.value)}
                      placeholder="Prophet JUHNKRIX SYNVAGORD"
                      className="w-full bg-slate-950 text-amber-100 border border-amber-500/30 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-amber-300 block mb-1">
                      Spiritual Category
                    </label>
                    <select
                      value={artworkCategory}
                      onChange={(e) => setArtworkCategory(e.target.value)}
                      className="w-full bg-slate-950 text-amber-100 border border-amber-500/30 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-amber-400 font-mono"
                    >
                      <option value="Celestial Sanctuary Glory">Celestial Sanctuary Glory & Light</option>
                      <option value="Prophetic Altar Banners">Prophetic Altar Banners & Emblems</option>
                      <option value="Miracle Testimonial Artwork">Miracle Testimonial Artwork</option>
                      <option value="Angelic Vision Portals">Angelic Vision Portals & Decrees</option>
                      <option value="Soaking Worship Backgrounds">Soaking Worship Backgrounds</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-amber-300 block mb-1">
                      Key Scripture Anchor
                    </label>
                    <input
                      type="text"
                      value={scriptureRef}
                      onChange={(e) => setScriptureRef(e.target.value)}
                      placeholder="e.g. Exodus 25:8, Revelation 4:3"
                      className="w-full bg-slate-950 text-amber-100 border border-amber-500/30 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-amber-400 font-mono"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="text-[11px] font-bold text-amber-300 mb-1 flex items-center space-x-1.5">
                      <Tag className="w-3.5 h-3.5 text-amber-400" />
                      <span>Searchable Tags (Comma-Separated, e.g. sanctuary, glory, banner, vision)</span>
                    </label>
                    <input
                      type="text"
                      value={tagsInput}
                      onChange={(e) => setTagsInput(e.target.value)}
                      placeholder="sanctuary, glory, vision, banner, prophetic"
                      className="w-full bg-slate-950 text-amber-200 border border-amber-500/40 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-amber-400 font-mono font-bold"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-300 block mb-1">
                    Spiritual Description & Anointing Notes
                  </label>
                  <textarea
                    rows={2}
                    value={imageDescription}
                    onChange={(e) => setImageDescription(e.target.value)}
                    placeholder="Enter visual meaning, divine inspiration, or prophetic symbolism..."
                    className="w-full bg-slate-950 text-amber-100 border border-amber-500/30 rounded-xl px-3.5 py-2 text-xs focus:outline-none focus:border-amber-400"
                  />
                </div>

                {/* Upload Progress Bar */}
                {isUploading && (
                  <div className="space-y-1.5 pt-2">
                    <div className="flex justify-between text-[11px] font-mono text-amber-300">
                      <span>Storing Image into JUHNKRIX MUSIKA Inbuilt Storage...</span>
                      <span>{uploadProgress}%</span>
                    </div>
                    <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-amber-500/30">
                      <div
                        className="h-full bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-300 transition-all duration-200"
                        style={{ width: `${uploadProgress}%` }}
                      />
                    </div>
                  </div>
                )}

                {/* Submit Action */}
                <button
                  type="submit"
                  disabled={isUploading || !selectedFile}
                  className={`w-full py-3.5 rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center space-x-2 transition-all shadow-xl ${
                    isUploading || !selectedFile
                      ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                      : 'bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-400 hover:scale-[1.01] text-slate-950 border border-amber-300 shadow-amber-500/20'
                  }`}
                >
                  <Upload className="w-4 h-4" />
                  <span>
                    {isUploading ? 'Writing Image to Storage...' : 'Save & Publish Image to Gallery'}
                  </span>
                </button>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Search & Filter Toolbar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-900/80 border border-amber-500/20 rounded-2xl p-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-amber-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search images, prophets, categories..."
            className="w-full bg-slate-950 border border-amber-500/30 rounded-xl pl-9 pr-3 py-2 text-xs text-amber-100 placeholder-slate-400 focus:outline-none focus:border-amber-400"
          />
        </div>
        <div className="flex items-center space-x-3 text-xs font-mono text-slate-400 w-full sm:w-auto justify-end">
          <HardDrive className="w-4 h-4 text-amber-400" />
          <span>{filteredMedia.length} Imoges Available</span>
        </div>
      </div>

      {/* Image / Imoge Grid */}
      <div className="grid grid-cols-1 gap-8">
        {filteredMedia.length === 0 ? (
          <div className="bg-slate-900/80 border border-amber-500/30 rounded-3xl p-12 text-center space-y-4">
            <div className="w-16 h-16 bg-amber-500/20 text-amber-400 rounded-full flex items-center justify-center mx-auto border border-amber-500/40">
              <ImageIcon className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold font-serif text-amber-100">
              {searchQuery ? 'No Imoges Matched Search' : 'No Images or Imoges Uploaded Yet'}
            </h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              Select images from your device storage using the "Upload Image from Device" button above to store them into JUHNKRIX MUSIKA inbuilt storage and display them here publicly.
            </p>
            <button
              onClick={() => setShowUploadDrawer(true)}
              className="px-5 py-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs hover:bg-amber-400 transition-all shadow-lg"
            >
              + Upload First Prophetic Imoge
            </button>
          </div>
        ) : (
          filteredMedia.map((item) => (
            <div
              key={item.id}
              className="bg-slate-900/90 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 relative overflow-hidden"
            >
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="text-[10px] font-mono bg-amber-500/20 text-amber-300 px-2.5 py-0.5 rounded-full border border-amber-500/30">
                      🖼️ Inbuilt Imoge Vault
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">{item.date}</span>
                  </div>
                  <h3 className="text-lg sm:text-2xl font-bold font-serif text-amber-100">{item.title}</h3>
                  <p className="text-xs text-amber-300/80 font-mono">By {item.artistOrProphet}</p>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setLightboxImage(item)}
                    className="flex items-center space-x-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all bg-slate-950 text-amber-300 border border-amber-500/30 hover:bg-amber-500/20"
                  >
                    <Maximize2 className="w-3.5 h-3.5" />
                    <span>Zoom</span>
                  </button>
                  <button
                    onClick={() => handleSubscribe(item.id)}
                    className={`flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all border ${
                      item.isSubscribed
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                        : 'bg-slate-950 text-slate-300 border-slate-700 hover:border-amber-500/40'
                    }`}
                  >
                    <Bell className={`w-3.5 h-3.5 ${item.isSubscribed ? 'text-amber-400 fill-amber-400' : ''}`} />
                    <span>{item.isSubscribed ? 'Subscribed' : 'Subscribe'}</span>
                  </button>
                </div>
              </div>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">{item.description}</p>
              {item.tags && item.tags.length > 0 && (
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {item.tags.map((tag, tIdx) => (
                    <span
                      key={tIdx}
                      className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-300 text-[10px] font-mono border border-amber-500/30"
                    >
                      <Tag className="w-2.5 h-2.5 text-amber-400" />
                      <span>#{tag}</span>
                    </span>
                  ))}
                </div>
              )}

              {/* Image Preview */}
              <div
                onClick={() => setLightboxImage(item)}
                className="rounded-2xl overflow-hidden border border-amber-500/30 bg-slate-950 shadow-2xl cursor-pointer group relative"
              >
                <img
                  src={item.url}
                  alt={item.title}
                  className="w-full max-h-[520px] object-cover group-hover:scale-102 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-slate-950/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-amber-200">
                  <div className="px-4 py-2 rounded-full bg-slate-950/80 border border-amber-500/40 text-xs font-mono flex items-center space-x-2 shadow-xl">
                    <Eye className="w-4 h-4 text-amber-400" />
                    <span>Click to View Full Size</span>
                  </div>
                </div>
              </div>

              {/* Action Bar */}
              <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-amber-500/20 text-xs">
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => handleLike(item.id)}
                    className={`flex items-center space-x-1.5 px-3.5 py-2 rounded-xl border transition-all ${
                      item.isLiked
                        ? 'bg-red-500/20 text-red-300 border-red-500/40 shadow-lg'
                        : 'bg-slate-950 text-slate-300 border-amber-500/20 hover:border-amber-400'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${item.isLiked ? 'text-red-400 fill-red-400' : ''}`} />
                    <span>{item.likes} Likes</span>
                  </button>

                  <button
                    onClick={() => handleDownload(item)}
                    className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-950 text-amber-300 border border-amber-500/30 hover:bg-amber-500/10 transition-all"
                  >
                    <Download className="w-4 h-4" />
                    <span>{item.downloads} Downloads</span>
                  </button>

                  <button
                    onClick={() => handleShare(item)}
                    className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-950 text-amber-300 border border-amber-500/30 hover:bg-amber-500/10 transition-all"
                  >
                    <Share2 className="w-4 h-4" />
                    <span>{item.shares} Shares</span>
                  </button>
                </div>

                <button
                  onClick={onOpenSupportModal}
                  className="flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 font-bold transition-all"
                >
                  <DollarSign className="w-4 h-4 text-amber-400" />
                  <span>Support Imoge Ministry</span>
                </button>
              </div>

              {/* Comments Section */}
              <div className="space-y-4 pt-4 border-t border-slate-800">
                <div className="flex items-center space-x-2 text-xs font-bold text-amber-200">
                  <MessageSquare className="w-4 h-4 text-amber-400" />
                  <span>Comments & Testimonies ({item.comments.length})</span>
                </div>

                <form onSubmit={(e) => handleAddComment(item.id, e)} className="flex gap-2">
                  <input
                    type="text"
                    value={commentInputs[item.id] || ''}
                    onChange={(e) => setCommentInputs({ ...commentInputs, [item.id]: e.target.value })}
                    placeholder="Leave a comment on this Imoge..."
                    className="flex-1 bg-slate-950 border border-amber-500/30 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center space-x-1.5 shadow-md"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Post</span>
                  </button>
                </form>

                <div className="space-y-3 pt-2">
                  {item.comments.map((cmt) => (
                    <div key={cmt.id} className="bg-slate-950/60 border border-amber-500/20 p-4 rounded-2xl space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-amber-200">{cmt.author}</span>
                        <span className="text-[10px] text-slate-400 font-mono">{cmt.date}</span>
                      </div>
                      <p className="text-xs text-slate-300">{cmt.text}</p>

                      {cmt.replies && cmt.replies.length > 0 && (
                        <div className="pl-4 sm:pl-6 space-y-2 border-l-2 border-amber-500/30 pt-2">
                          {cmt.replies.map((rep) => (
                            <div key={rep.id} className="bg-slate-900/80 p-3 rounded-xl space-y-1">
                              <div className="flex items-center justify-between text-[11px]">
                                <span className="font-bold text-amber-300">{rep.author}</span>
                                <span className="text-[9px] text-slate-400 font-mono">{rep.date}</span>
                              </div>
                              <p className="text-xs text-slate-300">{rep.text}</p>
                            </div>
                          ))}
                        </div>
                      )}

                      <form
                        onSubmit={(e) => {
                          e.preventDefault();
                          handleAddReply(item.id, cmt.id, e);
                        }}
                        className="flex gap-2 pt-1"
                      >
                        <input
                          type="text"
                          value={replyInputs[item.id]?.[cmt.id] || ''}
                          onChange={(e) =>
                            setReplyInputs({
                              ...replyInputs,
                              [item.id]: { ...(replyInputs[item.id] || {}), [cmt.id]: e.target.value }
                            })
                          }
                          placeholder="Reply to comment..."
                          className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-[11px] text-slate-200 focus:outline-none focus:border-amber-400"
                        />
                        <button
                          type="submit"
                          className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 text-[11px] font-bold"
                        >
                          Reply
                        </button>
                      </form>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Lightbox Zoom Modal */}
      {lightboxImage && (
        <div
          onClick={() => setLightboxImage(null)}
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 cursor-zoom-out"
        >
          <div className="relative max-w-4xl max-h-[90vh] flex flex-col items-center">
            <button
              onClick={() => setLightboxImage(null)}
              className="absolute -top-12 right-0 p-2 rounded-full bg-slate-800/80 text-white hover:bg-slate-700 border border-amber-500/30"
            >
              <X className="w-6 h-6" />
            </button>
            <img
              src={lightboxImage.url}
              alt={lightboxImage.title}
              className="max-w-full max-h-[80vh] object-contain rounded-2xl shadow-2xl border border-amber-500/40"
            />
            <div className="mt-3 text-center bg-slate-900/90 px-6 py-2.5 rounded-2xl border border-amber-500/30">
              <h4 className="text-sm font-bold text-amber-200">{lightboxImage.title}</h4>
              <p className="text-xs text-slate-400">By {lightboxImage.artistOrProphet} • Stored in Inbuilt Storage</p>
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
};
