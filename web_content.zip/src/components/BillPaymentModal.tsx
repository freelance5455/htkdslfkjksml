import React from 'react';
import { X, Wallet, CheckCircle2 } from 'lucide-react';
import { Account, SubscriptionRecord } from '../types/finance';
import { formatBDT } from '../utils/money';

interface BillPaymentModalProps {
  open: boolean;
  subscription: SubscriptionRecord | null;
  accounts: Account[];
  useBengaliDigits: boolean;
  onClose: () => void;
  onSelectAccountAndPay: (sub: SubscriptionRecord, account: Account) => void;
}

export const BillPaymentModal: React.FC<BillPaymentModalProps> = ({
  open,
  subscription,
  accounts,
  useBengaliDigits,
  onClose,
  onSelectAccountAndPay,
}) => {
  if (!open || !subscription) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
      <div
        role="dialog"
        aria-modal="true"
        className="w-full max-w-md rounded-t-3xl sm:rounded-2xl bg-white dark:bg-slate-900 border-t sm:border border-slate-200 dark:border-slate-800 p-6 shadow-2xl"
      >
        <div className="w-10 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto mb-3 sm:hidden" />

        <div className="flex items-start justify-between gap-3 pb-4 border-b border-slate-200 dark:border-slate-800">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              কোন মাধ্যমে বিল পরিশোধ করা হয়েছে?
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {subscription.nameBn} ·{' '}
              <span className="font-mono tabular-nums font-semibold text-emerald-700 dark:text-emerald-400">
                {formatBDT(subscription.amountPaisa, { useBengaliDigits })}
              </span>
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="বন্ধ করুন"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="mt-4 text-xs font-medium text-slate-600 dark:text-slate-300">
          নিচের যেকোনো একটি মাধ্যমে চাপ দিন, সাথে সাথে সেই মাধ্যমে বিল পরিশোধ সম্পন্ন হবে:
        </p>

        <div className="mt-3 grid grid-cols-1 gap-2.5">
          {accounts.map((acc) => (
            <button
              key={acc.id}
              type="button"
              onClick={() => onSelectAccountAndPay(subscription, acc)}
              className="w-full min-h-[48px] px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/80 dark:bg-slate-800/70 hover:bg-emerald-600 hover:border-emerald-600 hover:text-white dark:hover:bg-emerald-600 dark:hover:border-emerald-600 text-slate-900 dark:text-slate-100 font-semibold text-sm flex items-center justify-between transition-colors group"
            >
              <span className="flex items-center gap-2.5">
                <Wallet className="w-4 h-4 text-emerald-600 dark:text-emerald-400 group-hover:text-white transition-colors" />
                <span>{acc.nameBn}</span>
              </span>
              <span className="text-xs font-medium text-emerald-700 dark:text-emerald-400 group-hover:text-white flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4" />
                <span>এই মাধ্যমে পরিশোধ</span>
              </span>
            </button>
          ))}
        </div>

        <div className="mt-5 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[40px] px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            বাতিল
          </button>
        </div>
      </div>
    </div>
  );
};
