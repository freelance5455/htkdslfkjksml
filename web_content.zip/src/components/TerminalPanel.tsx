/**
 * GODEX v0.0.1 - Terminal, Logs & Diagnostics Panel
 */

import React, { useState } from 'react';
import { Terminal as TerminalIcon, Play, Trash2, CheckCircle2, AlertTriangle, ShieldCheck } from 'lucide-react';
import { TerminalLog } from '../types';

interface TerminalPanelProps {
  logs: TerminalLog[];
  onExecuteCommand: (cmd: string) => void;
  onClearLogs: () => void;
}

export const TerminalPanel: React.FC<TerminalPanelProps> = ({
  logs,
  onExecuteCommand,
  onClearLogs
}) => {
  const [activeTab, setActiveTab] = useState<'terminal' | 'tests' | 'diagnostics'>('terminal');
  const [commandInput, setCommandInput] = useState('');

  const handleCommandSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commandInput.trim()) return;
    onExecuteCommand(commandInput.trim());
    setCommandInput('');
  };

  const presetCommands = [
    'npm test',
    'npm run lint',
    'npm run build',
    'git diff'
  ];

  return (
    <div className="h-44 border-t border-[#1C2230] bg-[#090B10] flex flex-col shrink-0 select-none font-mono text-xs">
      {/* Terminal Toolbar */}
      <div className="h-8 border-b border-[#1C2230] bg-[#0D1017] px-3 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-1.5">
          {[
            { id: 'terminal', label: 'TERMINAL', icon: TerminalIcon },
            { id: 'tests', label: 'TEST_SUITE', icon: CheckCircle2 },
            { id: 'diagnostics', label: 'DIAGNOSTICS', icon: AlertTriangle }
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-semibold transition-colors ${
                  activeTab === tab.id
                    ? 'bg-[#151D2C] text-cyan-300 border border-[#232F46] shadow-sm'
                    : 'text-neutral-500 hover:text-neutral-300'
                }`}
              >
                <Icon className="w-3 h-3" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-2">
          {/* Preset Command Chips */}
          <div className="hidden sm:flex items-center gap-1">
            {presetCommands.map(cmd => (
              <button
                key={cmd}
                onClick={() => onExecuteCommand(cmd)}
                className="px-2 py-0.2 rounded bg-[#10141E] hover:bg-[#181F2E] border border-[#1E2738] text-[9px] text-neutral-400 hover:text-cyan-300 transition-colors"
              >
                {cmd}
              </button>
            ))}
          </div>

          <button
            onClick={onClearLogs}
            className="p-1 rounded text-neutral-500 hover:text-neutral-300 transition-colors"
            title="Clear output"
          >
            <Trash2 className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Output Stream */}
      <div className="flex-1 overflow-y-auto p-3 space-y-1 bg-[#06080C] text-neutral-300 font-mono text-[11px] leading-relaxed">
        {logs.length === 0 ? (
          <div className="text-neutral-600 italic">
            [SYS_INIT] GODEX sandbox execution terminal ready.
          </div>
        ) : (
          logs.map((log, idx) => {
            let color = 'text-neutral-300';
            if (log.type === 'stderr') color = 'text-rose-400 font-bold';
            if (log.type === 'command') color = 'text-cyan-400 font-bold';
            if (log.type === 'test') color = 'text-emerald-400 font-semibold';
            if (log.type === 'system') color = 'text-indigo-400';

            return (
              <div key={log.id ? `${log.id}-${idx}` : `log-${idx}`} className={`whitespace-pre-wrap ${color}`}>
                {log.type === 'command' && <span className="text-neutral-600">$ </span>}
                {log.text}
              </div>
            );
          })
        )}
      </div>

      {/* Terminal Interactive Input */}
      <form onSubmit={handleCommandSubmit} className="h-7 border-t border-[#1C2230] bg-[#0A0D14] px-3 flex items-center gap-2 shrink-0">
        <span className="text-cyan-400 font-bold text-xs">$</span>
        <input
          type="text"
          value={commandInput}
          onChange={(e) => setCommandInput(e.target.value)}
          placeholder="execute sandbox command (npm test, npm run lint, tsc)..."
          className="flex-1 bg-transparent text-white text-xs placeholder-neutral-600 focus:outline-none font-mono"
        />
      </form>
    </div>
  );
};
