import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Zap,
  DollarSign,
  Building2,
  Calendar,
  Clock,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Sliders,
  Play,
  RotateCw,
  History,
  Lock,
  ArrowUpRight,
  Sparkles,
  ToggleLeft,
  ToggleRight,
  Info
} from 'lucide-react';
import { imsiEngine, ImsiWalletBalances } from '../lib/imsiEngine';
import { currencyConverter } from '../lib/currencyConverter';

export interface AutoPayoutRule {
  enabled: boolean;
  frequency: 'DAILY' | 'WEEKLY' | 'THRESHOLD_INSTANT';
  thresholdType: 'NGN' | 'USD' | 'SATS';
  thresholdAmount: number;
  bankName: string;
  accountNumber: string;
  accountName: string;
  retainBufferAmount: number; // Keep this amount in wallet as reserve
  payoutTimeUtc: string; // e.g. "08:00"
  payoutDayOfWeek: string; // e.g. "Monday"
  lastExecutedAt?: string;
  totalPaidOutNgn: number;
  totalExecutionsCount: number;
}

export interface PayoutHistoryItem {
  id: string;
  timestamp: string;
  amountNgn: number;
  amountUsd: number;
  destinationBank: string;
  accountMasked: string;
  referenceId: string;
  status: 'COMPLETED' | 'PROCESSING' | 'FAILED';
  triggerType: string;
}

const DEFAULT_CONFIG: AutoPayoutRule = {
  enabled: true,
  frequency: 'DAILY',
  thresholdType: 'NGN',
  thresholdAmount: 100000, // ₦100,000
  bankName: 'Guaranty Trust Bank (GTBank)',
  accountNumber: '0459281729',
  accountName: 'JUHNKRIX MUSIKA SOVEREIGN',
  retainBufferAmount: 25000, // Keep ₦25,000 reserve
  payoutTimeUtc: '06:00',
  payoutDayOfWeek: 'Monday',
  lastExecutedAt: 'Today at 06:00 UTC',
  totalPaidOutNgn: 1450000,
  totalExecutionsCount: 14
};

const INITIAL_HISTORY: PayoutHistoryItem[] = [
  {
    id: 'pay-01',
    timestamp: 'Today, 06:00 UTC',
    amountNgn: 115000,
    amountUsd: 74.19,
    destinationBank: 'GTBank',
    accountMasked: '••••1729',
    referenceId: 'NIBSS-AUTOPAY-9921',
    status: 'COMPLETED',
    triggerType: 'Daily Automated Schedule'
  },
  {
    id: 'pay-02',
    timestamp: 'Yesterday, 06:00 UTC',
    amountNgn: 98500,
    amountUsd: 63.54,
    destinationBank: 'GTBank',
    accountMasked: '••••1729',
    referenceId: 'NIBSS-AUTOPAY-9844',
    status: 'COMPLETED',
    triggerType: 'Daily Automated Schedule'
  },
  {
    id: 'pay-03',
    timestamp: '3 days ago',
    amountNgn: 140000,
    amountUsd: 90.32,
    destinationBank: 'GTBank',
    accountMasked: '••••1729',
    referenceId: 'NIBSS-AUTOPAY-9710',
    status: 'COMPLETED',
    triggerType: 'Threshold Trigger (≥₦100k)'
  }
];

const LINKED_BANKS = [
  { name: 'Guaranty Trust Bank (GTBank)', code: '058', defaultAcc: '0459281729' },
  { name: 'Access Bank Plc', code: '044', defaultAcc: '0019284711' },
  { name: 'Zenith Bank International', code: '057', defaultAcc: '2084920194' },
  { name: 'First Bank of Nigeria', code: '011', defaultAcc: '3049281029' },
  { name: 'Kuda Microfinance Bank', code: '50211', defaultAcc: '1102948192' },
  { name: 'Moniepoint MFB', code: '50515', defaultAcc: '8102948102' },
  { name: 'OPay Digital Services', code: '999992', defaultAcc: '9039182910' }
];

interface AutoPayoutConfigModuleProps {
  wallet?: ImsiWalletBalances;
  onShowToast?: (msg: string) => void;
  onOpenBiometricAuth?: () => void;
}

export const AutoPayoutConfigModule: React.FC<AutoPayoutConfigModuleProps> = ({
  wallet,
  onShowToast,
  onOpenBiometricAuth
}) => {
  const [rule, setRule] = useState<AutoPayoutRule>(() => {
    const saved = localStorage.getItem('juhnkrix_autopayout_rule');
    return saved ? JSON.parse(saved) : DEFAULT_CONFIG;
  });

  const [history, setHistory] = useState<PayoutHistoryItem[]>(() => {
    const saved = localStorage.getItem('juhnkrix_autopayout_history');
    return saved ? JSON.parse(saved) : INITIAL_HISTORY;
  });

  const [isExecutingTest, setIsExecutingTest] = useState<boolean>(false);
  const [showConfigModal, setShowConfigModal] = useState<boolean>(false);

  useEffect(() => {
    localStorage.setItem('juhnkrix_autopayout_rule', JSON.stringify(rule));
  }, [rule]);

  useEffect(() => {
    localStorage.setItem('juhnkrix_autopayout_history', JSON.stringify(history));
  }, [history]);

  const handleToggleEnable = () => {
    const next = !rule.enabled;
    setRule((prev) => ({ ...prev, enabled: next }));
    onShowToast?.(
      next
        ? '✓ Automated Payouts ENABLED for linked bank account!'
        : '⚠️ Automated Payouts PAUSED.'
    );
  };

  const handleExecuteManualTest = () => {
    const availableNgn = wallet?.cashNgn || 125000;
    const payoutAmount = Math.max(10000, Math.min(rule.thresholdAmount, availableNgn - rule.retainBufferAmount));

    if (payoutAmount <= 0) {
      onShowToast?.('⚠️ Insufficient cash above the retain reserve buffer to execute payout.');
      return;
    }

    setIsExecutingTest(true);

    setTimeout(() => {
      // Execute actual withdrawal from imsiEngine
      const res = imsiEngine.withdrawCash({
        amountNgn: payoutAmount,
        destination: `${rule.bankName} (${rule.accountNumber})`,
        accountName: rule.accountName,
        bankCode: '058',
        referenceNote: `Automated Payout Engine Settlement (${rule.frequency})`
      });

      const refId = `NIBSS-AUTOPAY-${Math.floor(1000 + Math.random() * 9000)}`;
      const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' UTC';

      const newHistoryItem: PayoutHistoryItem = {
        id: `pay-${Date.now()}`,
        timestamp: `Today at ${nowStr}`,
        amountNgn: payoutAmount,
        amountUsd: +(payoutAmount / 1550).toFixed(2),
        destinationBank: rule.bankName.split(' ')[0],
        accountMasked: `••••${rule.accountNumber.slice(-4)}`,
        referenceId: refId,
        status: 'COMPLETED',
        triggerType: 'Manual Trigger / Test Cycle'
      };

      setHistory((prev) => [newHistoryItem, ...prev]);
      setRule((prev) => ({
        ...prev,
        lastExecutedAt: `Today at ${nowStr}`,
        totalPaidOutNgn: prev.totalPaidOutNgn + payoutAmount,
        totalExecutionsCount: prev.totalExecutionsCount + 1
      }));

      setIsExecutingTest(false);
      onShowToast?.(`✓ Dispatched ₦${payoutAmount.toLocaleString()} to ${rule.bankName}! Ref: ${refId}`);
    }, 1200);
  };

  return (
    <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/50 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 text-slate-100 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-amber-500/20 pb-4 relative z-10">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-black uppercase tracking-wider">
            <Zap className="w-4 h-4 text-amber-400" />
            <span>MINING EARNINGS AUTO-PAYOUT ORCHESTRATION</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold font-serif text-amber-100">
            Scheduled Automated Bank Transfers
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl">
            Configure automated daily or weekly settlement transfers from your mining yields directly into your verified local bank account upon meeting predefined thresholds.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={handleToggleEnable}
            className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center space-x-2 border transition-all cursor-pointer ${
              rule.enabled
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40 shadow-md'
                : 'bg-slate-900 text-slate-400 border-slate-800'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>AUTO-PAYOUT: {rule.enabled ? 'ACTIVE' : 'PAUSED'}</span>
          </button>

          <button
            onClick={handleExecuteManualTest}
            disabled={isExecutingTest}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs flex items-center space-x-1.5 shadow-lg shadow-amber-500/20 transition-all hover:scale-105 disabled:opacity-50 cursor-pointer"
          >
            <Play className={`w-3.5 h-3.5 ${isExecutingTest ? 'animate-spin' : ''}`} />
            <span>{isExecutingTest ? 'EXECUTING...' : 'TRIGGER PAYOUT RUN'}</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Parameters & Destination Card */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Active Configuration Panel */}
        <div className="lg:col-span-7 bg-slate-900/90 border border-amber-500/30 rounded-3xl p-5 sm:p-6 space-y-5 shadow-xl">
          <div className="flex justify-between items-center border-b border-slate-800 pb-3">
            <span className="text-xs font-black uppercase tracking-wider text-amber-300 flex items-center space-x-2">
              <Sliders className="w-4 h-4 text-amber-400" />
              <span>Settlement Parameters & Triggers</span>
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              Last Run: <strong className="text-emerald-400">{rule.lastExecutedAt || 'Pending'}</strong>
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Frequency Selector */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
                <Calendar className="w-3.5 h-3.5 text-amber-400" />
                <span>Execution Schedule:</span>
              </label>
              <select
                value={rule.frequency}
                onChange={(e) => setRule({ ...rule, frequency: e.target.value as any })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-amber-200 font-bold focus:border-amber-400 focus:outline-none"
              >
                <option value="DAILY">Daily at {rule.payoutTimeUtc} UTC</option>
                <option value="WEEKLY">Weekly (Every {rule.payoutDayOfWeek})</option>
                <option value="THRESHOLD_INSTANT">Instant when Threshold Met</option>
              </select>
            </div>

            {/* Threshold Amount */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
                <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                <span>Minimum Payout Threshold:</span>
              </label>
              <div className="relative">
                <input
                  type="number"
                  value={rule.thresholdAmount}
                  onChange={(e) => setRule({ ...rule, thresholdAmount: Math.max(5000, Number(e.target.value)) })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono font-bold text-emerald-300 focus:border-amber-400 focus:outline-none"
                />
                <span className="absolute right-3 top-2 text-[10px] text-slate-500 font-bold">NGN</span>
              </div>
            </div>

            {/* Destination Bank Selector */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
                <Building2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>Linked Bank:</span>
              </label>
              <select
                value={rule.bankName}
                onChange={(e) => {
                  const b = LINKED_BANKS.find((item) => item.name === e.target.value);
                  setRule({
                    ...rule,
                    bankName: e.target.value,
                    accountNumber: b ? b.defaultAcc : rule.accountNumber
                  });
                }}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-slate-200 font-bold focus:border-amber-400 focus:outline-none"
              >
                {LINKED_BANKS.map((b) => (
                  <option key={b.code} value={b.name}>
                    {b.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Retain Buffer Reserve */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                <span>Retain Safety Buffer:</span>
              </label>
              <div className="relative">
                <input
                  type="number"
                  value={rule.retainBufferAmount}
                  onChange={(e) => setRule({ ...rule, retainBufferAmount: Math.max(0, Number(e.target.value)) })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono font-bold text-amber-300 focus:border-amber-400 focus:outline-none"
                />
                <span className="absolute right-3 top-2 text-[10px] text-slate-500 font-bold">NGN</span>
              </div>
            </div>
          </div>

          {/* Quick Threshold Presets */}
          <div className="pt-2 flex flex-wrap items-center gap-2">
            <span className="text-[10px] font-bold text-slate-400">Presets:</span>
            {[50000, 100000, 250000, 500000, 1000000].map((amt) => (
              <button
                key={amt}
                type="button"
                onClick={() => {
                  setRule({ ...rule, thresholdAmount: amt });
                  onShowToast?.(`Updated threshold to ₦${amt.toLocaleString()} NGN`);
                }}
                className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold transition-all ${
                  rule.thresholdAmount === amt
                    ? 'bg-amber-500 text-slate-950'
                    : 'bg-slate-950 text-slate-400 hover:text-amber-200 border border-slate-800'
                }`}
              >
                ₦{(amt / 1000).toFixed(0)}k
              </button>
            ))}
          </div>

          {/* Safety Rule Note */}
          <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 text-xs text-slate-300 flex items-start space-x-2.5">
            <Info className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed">
              When mining yields push your cash balance above <strong>₦{rule.thresholdAmount.toLocaleString()}</strong>, the system will automatically dispatch the excess above <strong>₦{rule.retainBufferAmount.toLocaleString()}</strong> reserve to <strong>{rule.bankName}</strong> via NIBSS Instant Clearing.
            </p>
          </div>
        </div>

        {/* Linked Account Destination Card & Total Metrics */}
        <div className="lg:col-span-5 space-y-4 flex flex-col justify-between">
          {/* Destination Virtual Card */}
          <div className="bg-gradient-to-br from-emerald-950/80 via-slate-900 to-slate-950 border-2 border-emerald-500/40 rounded-3xl p-5 sm:p-6 space-y-4 shadow-xl relative overflow-hidden">
            <div className="flex justify-between items-start">
              <div className="space-y-1">
                <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400 flex items-center space-x-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>VERIFIED SETTLEMENT DESTINATION</span>
                </span>
                <h4 className="text-base font-bold text-slate-100">{rule.bankName}</h4>
              </div>
              <Building2 className="w-6 h-6 text-emerald-400" />
            </div>

            <div className="space-y-2 pt-2 font-mono">
              <div className="text-xs text-slate-400">Account Number:</div>
              <div className="text-xl font-black text-amber-200 tracking-wider">
                {rule.accountNumber.slice(0, 3)} •••• {rule.accountNumber.slice(-4)}
              </div>
              <div className="text-xs text-slate-300 font-sans font-bold pt-1">
                Beneficiary: {rule.accountName}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-between items-center text-[10px] text-slate-400 font-mono">
              <span>Channel: NIBSS NQR / Direct ACH</span>
              <span className="text-emerald-400 font-bold">Status: Active Link</span>
            </div>
          </div>

          {/* Aggregate Stats */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-slate-900/80 p-3.5 rounded-2xl border border-slate-800 space-y-1">
              <span className="text-[10px] text-slate-400 uppercase block font-mono">Total Auto-Paid</span>
              <div className="text-lg font-black text-emerald-300 font-mono">
                ₦{(rule.totalPaidOutNgn / 1000000).toFixed(2)}M
              </div>
              <span className="text-[9px] text-slate-500 font-mono">
                ~${(rule.totalPaidOutNgn / 1550).toFixed(0)} USD
              </span>
            </div>

            <div className="bg-slate-900/80 p-3.5 rounded-2xl border border-slate-800 space-y-1">
              <span className="text-[10px] text-slate-400 uppercase block font-mono">Completed Runs</span>
              <div className="text-lg font-black text-amber-300 font-mono">
                {rule.totalExecutionsCount} Batches
              </div>
              <span className="text-[9px] text-emerald-400 font-mono">100% Success Rate</span>
            </div>
          </div>
        </div>
      </div>

      {/* Auto-Payout Execution History */}
      <div className="space-y-3 pt-2">
        <div className="flex justify-between items-center">
          <span className="text-xs font-black uppercase tracking-wider text-amber-300 flex items-center space-x-2">
            <History className="w-4 h-4 text-amber-400" />
            <span>Recent Automated Transfer Dispatches ({history.length})</span>
          </span>
          <span className="text-[10px] text-slate-400 font-mono">Cryptographically Audited</span>
        </div>

        <div className="space-y-2">
          {history.slice(0, 4).map((item) => (
            <div
              key={item.id}
              className="bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 rounded-2xl p-3 sm:p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 transition-all"
            >
              <div className="flex items-center space-x-3">
                <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  <ArrowUpRight className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-black text-slate-100">
                      ₦{item.amountNgn.toLocaleString()} NGN
                    </span>
                    <span className="text-xs text-slate-400 font-mono">(${item.amountUsd})</span>
                    <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">
                      {item.status}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    {item.destinationBank} ({item.accountMasked}) • Ref: <span className="font-mono text-slate-300">{item.referenceId}</span>
                  </p>
                </div>
              </div>

              <div className="text-right text-[10px] font-mono text-slate-400 self-end sm:self-center">
                <span>{item.timestamp}</span>
                <span className="block text-slate-500 text-[9px]">{item.triggerType}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
