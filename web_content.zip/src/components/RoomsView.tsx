import React, { useState, useEffect } from 'react';
import { Room, RoomMessage, UserProfile, GiftItem } from '../types';
import { 
  db, 
  handleFirestoreError, 
  OperationType 
} from '../firebase';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  query, 
  orderBy, 
  limit, 
  doc, 
  updateDoc, 
  setDoc,
  getDoc,
  increment,
  serverTimestamp 
} from 'firebase/firestore';
import { AVAILABLE_GIFTS } from '../gifts';
import { sendGiftFn, walletErrorMessage } from '../wallet';
import { 
  Mic, 
  MicOff, 
  Users, 
  Plus, 
  Sparkles, 
  MessageSquare, 
  Send, 
  LogOut, 
  Lock, 
  Volume2, 
  Radio, 
  Flame, 
  Heart, 
  Gift, 
  Check, 
  Headphones,
  Music,
  Smile,
  ShieldCheck,
  Crown,
  X,
  VolumeX,
  Play,
  Square,
  Settings,
  Image as ImageIcon,
  UserCheck,
  UserX
} from 'lucide-react';

interface RoomsViewProps {
  currentUser: UserProfile;
  onUpdateUserFlowers: (amount: number) => void;
}

const GIFTS_LIST = AVAILABLE_GIFTS;

export const RoomsView: React.FC<RoomsViewProps> = ({ currentUser, onUpdateUserFlowers }) => {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('الكل');
  const [activeRoom, setActiveRoom] = useState<Room | null>(null);
  const [roomMessages, setRoomMessages] = useState<RoomMessage[]>([]);
  const [messageText, setMessageText] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showGiftDrawer, setShowGiftDrawer] = useState(false);
  const [showMusicDrawer, setShowMusicDrawer] = useState(false);
  const [showRoomSettingsModal, setShowRoomSettingsModal] = useState(false);
  const [isMicOn, setIsMicOn] = useState(false);
  const [giftNotification, setGiftNotification] = useState<string | null>(null);
  const [sendingGift, setSendingGift] = useState(false);
  const [activeAnimatedGift, setActiveAnimatedGift] = useState<{
    icon: string;
    name: string;
    sender: string;
    color?: string;
  } | null>(null);
  const [currentTrack, setCurrentTrack] = useState<string | null>(null);
  const [musicVolume, setMusicVolume] = useState<number>(80);
  const [moderatorInput, setModeratorInput] = useState('');
  const [coverUrlInput, setCoverUrlInput] = useState('');

  // New room form state
  const [newRoomTitle, setNewRoomTitle] = useState('');
  const [newRoomCategory, setNewRoomCategory] = useState('دردشة عامة');
  const [newRoomDesc, setNewRoomDesc] = useState('');

  const categories = ['الكل', 'دردشة عامة', 'شعر وخواطر', 'مقهى', 'مسابقات'];

  // Subscribe to Firestore rooms
  useEffect(() => {
    const roomsCol = collection(db, 'rooms');
    const unsub = onSnapshot(roomsCol, (snapshot) => {
      const loaded: Room[] = [];
      snapshot.forEach((docSnap) => {
        loaded.push({ id: docSnap.id, ...docSnap.data() } as Room);
      });
      setRooms(loaded);
    }, (error) => {
      console.error('Error reading rooms:', error);
      setGiftNotification('تعذر تحميل الغرف، تحقق من اتصالك بالإنترنت');
    });

    return () => unsub();
  }, []);

  // Subscribe to live room messages when a room is active
  useEffect(() => {
    if (!activeRoom) return;

    const messagesCol = collection(db, 'rooms', activeRoom.id, 'messages');
    const q = query(messagesCol, orderBy('createdAt', 'asc'), limit(50));

    let isFirstSnapshot = true;
    const unsub = onSnapshot(q, (snapshot) => {
      const msgs: RoomMessage[] = [];
      snapshot.forEach((docSnap) => {
        msgs.push({ id: docSnap.id, ...docSnap.data() } as RoomMessage);
      });
      const showAnimation = !isFirstSnapshot;
      isFirstSnapshot = false;
      if (showAnimation && msgs.length > 0) {
        const latest = msgs[msgs.length - 1];
        if (latest.type === 'gift') {
          const matched = GIFTS_LIST.find((g) => g.name === latest.giftType);
          setActiveAnimatedGift({
            icon: matched?.icon || '🎁',
            name: latest.giftType || 'هدية فاخرة',
            sender: latest.senderName,
            color: matched?.color
          });
          setTimeout(() => setActiveAnimatedGift(null), 3500);
        }
      }
      setRoomMessages(msgs);
    }, (error) => {
      console.error('Error reading room messages:', error);
    });

    return () => unsub();
  }, [activeRoom]);

  // Add moderator to active room
  const handleAddModerator = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeRoom || !moderatorInput.trim()) return;
    const currentMods = activeRoom.moderators || [];
    if (currentMods.includes(moderatorInput.trim())) return;
    const updatedMods = [...currentMods, moderatorInput.trim()];
    try {
      await updateDoc(doc(db, 'rooms', activeRoom.id), {
        moderators: updatedMods
      });
      setActiveRoom((prev) => prev ? { ...prev, moderators: updatedMods } : null);
      setModeratorInput('');
      setGiftNotification(`تم تعيين (${moderatorInput.trim()}) مشرفاً للغرفة 🛡️`);
      setTimeout(() => setGiftNotification(null), 3000);
    } catch (err) {
      console.error('Error adding moderator:', err);
    }
  };

  // Remove moderator from active room
  const handleRemoveModerator = async (modName: string) => {
    if (!activeRoom) return;
    const updatedMods = (activeRoom.moderators || []).filter((m) => m !== modName);
    try {
      await updateDoc(doc(db, 'rooms', activeRoom.id), {
        moderators: updatedMods
      });
      setActiveRoom((prev) => prev ? { ...prev, moderators: updatedMods } : null);
      setGiftNotification(`تمت إزالة المشرف (${modName})`);
      setTimeout(() => setGiftNotification(null), 3000);
    } catch (err) {
      console.error('Error removing moderator:', err);
    }
  };

  // Update Room Cover photo
  const handleUpdateRoomCover = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeRoom || !coverUrlInput.trim()) return;
    try {
      await updateDoc(doc(db, 'rooms', activeRoom.id), {
        coverUrl: coverUrlInput.trim()
      });
      setActiveRoom((prev) => prev ? { ...prev, coverUrl: coverUrlInput.trim() } : null);
      setCoverUrlInput('');
      setShowRoomSettingsModal(false);
      setGiftNotification('تم تحديث صورة وخلفية الغرفة بنجاح 🖼️');
      setTimeout(() => setGiftNotification(null), 3000);
    } catch (err) {
      console.error('Error updating cover:', err);
    }
  };

  // Handle Send Message in Room
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    const text = messageText.trim();
    if (!text || !activeRoom) return;
    setMessageText('');

    try {
      await addDoc(collection(db, 'rooms', activeRoom.id, 'messages'), {
        roomId: activeRoom.id,
        senderId: currentUser.uid,
        senderName: currentUser.displayName,
        senderAvatar: currentUser.photoURL || '',
        text,
        type: 'text',
        createdAt: new Date().toISOString()
      });
    } catch (err) {
      console.error('Could not send message:', err);
      setMessageText(text);
      setGiftNotification('تعذر إرسال الرسالة، حاول مرة أخرى');
      setTimeout(() => setGiftNotification(null), 3000);
    }
  };

  // Handle Send Gift in Room: the server checks the balance, charges coins,
  // credits the host and posts the gift message. Nothing is shown unless it succeeded.
  const handleSendGift = async (gift: GiftItem) => {
    if (!activeRoom || sendingGift) return;
    const price = gift.costCoins || gift.cost * 5;
    if ((currentUser.coins || 0) < price) {
      setGiftNotification(`رصيد العملات (${currentUser.coins || 0}) غير كافٍ لإرسال ${gift.name} (${price} عملة).`);
      setTimeout(() => setGiftNotification(null), 3500);
      return;
    }
    setSendingGift(true);
    try {
      await sendGiftFn({
        giftId: gift.id,
        currency: 'coins',
        context: { type: 'room', roomId: activeRoom.id, targetUserId: activeRoom.hostId }
      });
      setShowGiftDrawer(false);
      setGiftNotification(`تم إرسال ${gift.icon} ${gift.name} إلى ${activeRoom.hostName}`);
    } catch (err) {
      console.error('sendGift failed:', err);
      setGiftNotification(walletErrorMessage(err));
    } finally {
      setSendingGift(false);
      setTimeout(() => setGiftNotification(null), 3500);
    }
  };

  // Handle Create New Room
  const handleCreateRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoomTitle.trim()) return;

    const newRoom: Omit<Room, 'id'> = {
      title: newRoomTitle.trim(),
      description: newRoomDesc.trim() || 'غرفة جديدة في زهرة شات',
      category: newRoomCategory,
      hostId: currentUser.uid,
      hostName: currentUser.displayName,
      hostAvatar: currentUser.photoURL,
      icon: '🌸',
      bgGradient: 'from-rose-950 via-slate-900 to-fuchsia-950',
      participantsCount: 1,
      isVoiceActive: true,
      isLocked: false,
      createdAt: new Date().toISOString(),
      speakers: [
        {
          id: currentUser.uid,
          name: currentUser.displayName,
          avatar: currentUser.photoURL || '',
          isMuted: false,
          isSpeaking: true
        }
      ]
    };

    try {
      const docRef = await addDoc(collection(db, 'rooms'), newRoom);
      setActiveRoom({ id: docRef.id, ...newRoom });
      setShowCreateModal(false);
      setNewRoomTitle('');
      setNewRoomDesc('');
    } catch (err) {
      console.error('Could not create room:', err);
      setGiftNotification('تعذر إنشاء الغرفة، حاول مرة أخرى');
      setTimeout(() => setGiftNotification(null), 3500);
    }
  };

  const filteredRooms = activeCategory === 'الكل' 
    ? rooms 
    : rooms.filter((r) => r.category === activeCategory);

  return (
    <div className="space-y-6 pb-24">
      {giftNotification && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[60] max-w-[90vw] bg-gradient-to-r from-amber-500 to-rose-500 text-white px-5 py-2.5 rounded-2xl shadow-xl flex items-center gap-2 text-sm font-bold">
          <Sparkles className="w-4 h-4 text-yellow-700 shrink-0" />
          <span>{giftNotification}</span>
        </div>
      )}

      {/* Top Banner & Quick Stats */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-rose-900/40 via-purple-950/40 to-slate-50 p-5 border border-rose-500/20 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/20 text-rose-600 text-xs font-semibold mb-2">
              <Radio className="w-3.5 h-3.5 animate-pulse text-rose-500" />
              <span>الغرف الصوتية المباشرة</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 font-['Cairo']">
              غرف ومجالس زهرة شات 🌸
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              انضم لأرقى الغرف الصوتية، شارك برأيك، واستمتع بأجمل اللحظات مع الأصدقاء
            </p>
          </div>

          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-gradient-to-r from-rose-600 to-fuchsia-600 hover:from-rose-500 hover:to-fuchsia-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-rose-950/50 active:scale-95 transition-all cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>إنشاء غرفة جديدة</span>
          </button>
        </div>
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 cursor-pointer ${
              activeCategory === cat
                ? 'bg-rose-500 text-white shadow-md shadow-rose-900/40'
                : 'bg-slate-50/80 text-slate-500 hover:text-slate-900 border border-slate-200'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Rooms Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredRooms.map((room) => (
          <div
            key={room.id}
            onClick={() => setActiveRoom(room)}
            className="group relative overflow-hidden rounded-3xl bg-slate-50/90 border border-slate-200/80 hover:border-rose-500/40 p-5 shadow-lg hover:shadow-rose-950/30 transition-all duration-300 cursor-pointer flex flex-col justify-between"
          >
            {/* Ambient subtle card glow */}
            <div className="absolute -top-12 -left-12 w-28 h-28 bg-rose-500/10 rounded-full blur-2xl group-hover:bg-rose-500/20 transition-all" />

            <div>
              <div className="flex items-center justify-between gap-2 mb-3">
                <span className="text-2xl">{room.icon}</span>
                <div className="flex items-center gap-2">
                  {room.isVoiceActive && (
                    <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-500/15 border border-rose-500/30 text-rose-600 text-[11px] font-semibold">
                      <Radio className="w-3 h-3 text-rose-500 animate-pulse" />
                      <span>صوتي مباشر</span>
                    </span>
                  )}
                  <span className="flex items-center gap-1 text-slate-500 text-xs bg-white/60 px-2 py-1 rounded-full border border-slate-200">
                    <Users className="w-3.5 h-3.5 text-slate-500" />
                    <span>{room.participantsCount}</span>
                  </span>
                </div>
              </div>

              <h3 className="text-base font-bold text-slate-900 group-hover:text-rose-600 transition-colors line-clamp-1">
                {room.title}
              </h3>
              <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                {room.description}
              </p>
            </div>

            {/* Host info & Enter prompt */}
            <div className="mt-4 pt-3 border-t border-slate-200/60 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <img
                  src={room.hostAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${room.hostId}`}
                  alt={room.hostName}
                  className="w-7 h-7 rounded-full object-cover border border-rose-500/30"
                />
                <span className="text-xs text-slate-600 font-medium">
                  {room.hostName}
                </span>
              </div>
              <span className="text-xs text-rose-500 font-bold group-hover:translate-x-[-4px] transition-transform">
                دخول الغرفة ←
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* ACTIVE ROOM OVERLAY / FULL MODAL */}
      {activeRoom && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="relative w-full max-w-2xl h-[92vh] flex flex-col rounded-3xl bg-white border border-rose-500/30 shadow-2xl overflow-hidden">
            
            {/* Standalone Luminous Animated Virtual Gift Overlay */}
            {activeAnimatedGift && (
              <div className="absolute inset-0 z-50 pointer-events-none flex flex-col items-center justify-center p-4 animate-in zoom-in-75 duration-300">
                <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px]" />
                <div className="relative flex flex-col items-center text-center">
                  <div className="flex gap-4 text-3xl mb-2 animate-bounce">
                    <span>✨</span>
                    <span>🌸</span>
                    <span>💖</span>
                  </div>
                  <div className="relative">
                    <div className="absolute -inset-8 bg-gradient-to-r from-amber-400 via-rose-500 to-fuchsia-600 rounded-full blur-2xl opacity-80 animate-pulse" />
                    <div className="relative w-32 h-32 sm:w-36 sm:h-36 rounded-full bg-slate-50/95 border-2 border-amber-300 flex items-center justify-center shadow-2xl">
                      <span className="text-6xl sm:text-7xl animate-pulse">
                        {activeAnimatedGift.icon}
                      </span>
                    </div>
                  </div>
                  <div className="mt-4 px-6 py-2.5 rounded-full bg-white/95 border border-amber-400 text-slate-900 font-black text-xs sm:text-sm shadow-2xl flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-600 animate-spin" />
                    <span>
                      <strong className="text-amber-700">{activeAnimatedGift.sender}</strong> أهدى {activeAnimatedGift.name} {activeAnimatedGift.icon}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Room Top Header with Cover & Owner Controls */}
            <div className="p-3.5 bg-slate-50/90 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-3">
                {activeRoom.coverUrl ? (
                  <img
                    src={activeRoom.coverUrl}
                    alt={activeRoom.title}
                    className="w-10 h-10 rounded-2xl object-cover border border-rose-500/40"
                  />
                ) : (
                  <span className="text-2xl p-1.5 rounded-2xl bg-slate-100 border border-slate-200">
                    {activeRoom.icon}
                  </span>
                )}
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-slate-900 flex items-center gap-2">
                    {activeRoom.title}
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-600 font-normal">
                      {activeRoom.category}
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                    <span className="flex items-center gap-1">
                      <Crown className="w-3 h-3 text-amber-600" />
                      {activeRoom.hostName}
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1 text-emerald-600">
                      <Users className="w-3 h-3" />
                      {activeRoom.participantsCount} متواجد
                    </span>
                    {activeRoom.moderators && activeRoom.moderators.length > 0 && (
                      <>
                        <span>•</span>
                        <span className="text-[10px] text-purple-600 flex items-center gap-0.5">
                          <ShieldCheck className="w-3 h-3 text-purple-500" />
                          {activeRoom.moderators.length} مشرف
                        </span>
                      </>
                    )}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {/* Host Controls Button */}
                {activeRoom.hostId === currentUser.uid && (
                  <button
                    onClick={() => setShowRoomSettingsModal(true)}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-700 text-[11px] font-semibold border border-amber-500/30 transition-colors cursor-pointer"
                    title="إدارة الغرفة والمشرفين"
                  >
                    <Settings className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">إدارة الغرفة</span>
                  </button>
                )}

                <button
                  onClick={() => setActiveRoom(null)}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 text-xs font-semibold border border-rose-500/20 transition-colors cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>مغادرة</span>
                </button>
              </div>
            </div>

            {/* Current Playing Music Banner */}
            {currentTrack && (
              <div className="px-4 py-1.5 bg-gradient-to-r from-indigo-950 via-purple-950 to-white border-b border-indigo-500/30 flex items-center justify-between text-xs text-indigo-600">
                <span className="flex items-center gap-2 font-medium">
                  <Music className="w-3.5 h-3.5 text-indigo-500 animate-spin" />
                  <span>الموسيقى تعمل: <strong className="text-slate-900">{currentTrack}</strong></span>
                </span>
                <span className="text-[10px] text-indigo-600 font-mono">الصوت: {musicVolume}%</span>
              </div>
            )}

            {/* Speaker Seats / Voice Stage (8 Organized Seats) */}
            <div className="p-3 sm:p-4 bg-gradient-to-b from-slate-50/60 via-white/80 to-white border-b border-slate-200/80">
              <div className="text-[11px] font-semibold text-rose-600 mb-2.5 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Headphones className="w-3.5 h-3.5 text-amber-600" />
                  منصة المقاعد الصوتية (8 مقاعد مجهزة)
                </span>
                <span className="text-slate-500 text-[10px]">
                  اضغط على المايك للتحدث أو أخذ مقعد
                </span>
              </div>

              <div className="grid grid-cols-4 sm:grid-cols-8 gap-2 sm:gap-2.5">
                {/* Seat 1: Room Host */}
                <div className="flex flex-col items-center">
                  <div className="relative">
                    <img
                      src={activeRoom.hostAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${activeRoom.hostId}`}
                      alt={activeRoom.hostName}
                      className="w-11 h-11 sm:w-12 sm:h-12 rounded-full object-cover border-2 border-amber-400 p-0.5 shadow-md shadow-amber-900/30"
                    />
                    <span className="absolute -top-1 -right-1 text-xs">👑</span>
                    <span className="absolute -bottom-1 -left-1 w-4 h-4 rounded-full bg-emerald-500 border border-slate-200 flex items-center justify-center">
                      <Mic className="w-2.5 h-2.5 text-white" />
                    </span>
                  </div>
                  <span className="text-[10px] text-amber-700 font-bold mt-1 truncate max-w-[60px]">
                    {activeRoom.hostName}
                  </span>
                  <span className="text-[9px] text-slate-500">مضيف</span>
                </div>

                {/* Seat 2: Current User */}
                <div className="flex flex-col items-center">
                  <div className="relative">
                    <img
                      src={currentUser.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${currentUser.uid}`}
                      alt={currentUser.displayName}
                      className={`w-11 h-11 sm:w-12 sm:h-12 rounded-full object-cover border-2 ${
                        isMicOn ? 'border-rose-500 ring-2 ring-rose-400/50 animate-pulse' : 'border-slate-200'
                      } p-0.5`}
                    />
                    <button
                      onClick={() => setIsMicOn(!isMicOn)}
                      className={`absolute -bottom-1 -left-1 w-5 h-5 rounded-full border border-slate-200 flex items-center justify-center transition-all cursor-pointer ${
                        isMicOn ? 'bg-rose-500 text-white' : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {isMicOn ? <Mic className="w-3 h-3" /> : <MicOff className="w-3 h-3" />}
                    </button>
                  </div>
                  <span className="text-[10px] text-rose-600 font-bold mt-1 truncate max-w-[60px]">
                    أنت
                  </span>
                  <span className="text-[9px] text-slate-500">متحدث</span>
                </div>

                {/* Seats 3-8: Dynamic speakers or Open seats */}
                {[2, 3, 4, 5, 6, 7].map((seatIdx) => {
                  const speaker = activeRoom.speakers?.[seatIdx - 2];
                  const isModerator = speaker && activeRoom.moderators?.includes(speaker.name);
                  if (speaker) {
                    return (
                      <div key={speaker.id} className="flex flex-col items-center">
                        <div className="relative">
                          <img
                            src={speaker.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${speaker.id}`}
                            alt={speaker.name}
                            className={`w-11 h-11 sm:w-12 sm:h-12 rounded-full object-cover border-2 ${
                              speaker.isSpeaking ? 'border-emerald-500' : 'border-slate-200'
                            } p-0.5`}
                          />
                          {isModerator && (
                            <span className="absolute -top-1 -right-1 text-xs">🛡️</span>
                          )}
                          <span className="absolute -bottom-1 -left-1 w-4 h-4 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center">
                            {speaker.isMuted ? <MicOff className="w-2.5 h-2.5 text-slate-500" /> : <Mic className="w-2.5 h-2.5 text-emerald-600" />}
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-600 font-medium mt-1 truncate max-w-[60px]">
                          {speaker.name}
                        </span>
                        <span className="text-[9px] text-slate-500">
                          {isModerator ? 'مشرف' : `مقعد ${seatIdx + 1}`}
                        </span>
                      </div>
                    );
                  }
                  return (
                    <div
                      key={`seat_${seatIdx}`}
                      onClick={() => setIsMicOn(true)}
                      className="flex flex-col items-center justify-center cursor-pointer group"
                      title="اضغط للصعود إلى المقعد والتحدث"
                    >
                      <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-full border border-dashed border-slate-200 group-hover:border-rose-400/60 bg-slate-50/60 flex items-center justify-center text-slate-500 group-hover:text-rose-500 transition-colors">
                        <Plus className="w-4 h-4" />
                      </div>
                      <span className="text-[9px] text-slate-500 mt-1">
                        مقعد {seatIdx + 1}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Room Live Messages Stream */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {roomMessages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-500 text-xs">
                  <MessageSquare className="w-8 h-8 text-slate-700 mb-2" />
                  <span>لا توجد رسائل بعد، كن أول من يرحب بالحضور!</span>
                </div>
              ) : (
                roomMessages.map((msg) => (
                  <div 
                    key={msg.id} 
                    className={`flex items-start gap-2.5 ${
                      msg.senderId === currentUser.uid ? 'flex-row-reverse' : ''
                    }`}
                  >
                    <img
                      src={msg.senderAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${msg.senderId}`}
                      alt={msg.senderName}
                      className="w-7 h-7 rounded-full object-cover border border-slate-200 shrink-0"
                    />
                    <div className={`max-w-[78%] rounded-2xl px-3.5 py-2 text-xs leading-relaxed ${
                      msg.type === 'gift'
                        ? 'bg-gradient-to-r from-rose-100 via-purple-100 to-amber-50 border border-rose-300 text-rose-700'
                        : msg.senderId === currentUser.uid
                          ? 'bg-rose-600 text-white'
                          : 'bg-slate-50 text-slate-800 border border-slate-200'
                    }`}>
                      <div className="flex items-center justify-between gap-3 text-[10px] text-slate-500 mb-0.5">
                        <span className="font-semibold text-rose-600">
                          {msg.senderName}
                        </span>
                        <span className="text-[9px] opacity-75">
                          {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="break-words">{msg.text}</p>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Room Footer: Input & Gift Button */}
            <div className="p-3 bg-slate-50/90 border-t border-slate-200 flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowGiftDrawer(!showGiftDrawer)}
                className="p-2.5 rounded-2xl bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-400 hover:to-rose-400 text-white font-bold shadow-md shadow-rose-950/40 active:scale-95 transition-all shrink-0 cursor-pointer"
                title="إرسال باقة هدايا"
              >
                <Gift className="w-5 h-5" />
              </button>
              
              <button
                type="button"
                onClick={() => setShowMusicDrawer(!showMusicDrawer)}
                className="p-2.5 rounded-2xl bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white font-bold shadow-md shadow-indigo-950/40 active:scale-95 transition-all shrink-0 cursor-pointer"
                title="مشغل الموسيقى"
              >
                <Music className="w-5 h-5" />
              </button>

              <form onSubmit={handleSendMessage} className="flex-1 flex items-center gap-2">
                <input
                  type="text"
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  placeholder="اكتب رسالة للغرفة..."
                  className="flex-1 bg-white border border-slate-200 focus:border-rose-500 rounded-2xl px-4 py-2.5 text-xs sm:text-sm text-slate-900 placeholder-slate-500 focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={!messageText.trim()}
                  className="p-2.5 rounded-2xl bg-rose-600 hover:bg-rose-500 disabled:opacity-40 text-white active:scale-95 transition-all shrink-0 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>

            {/* Gift Drawer */}
            {showGiftDrawer && (
              <div className="p-4 bg-slate-50 border-t border-rose-500/20 animate-in slide-in-from-bottom duration-200">
                <div className="flex items-center justify-between mb-3 text-xs">
                  <span className="font-bold text-slate-900 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-amber-600" />
                    متجر باقات وهدايا زهرة 🌸
                  </span>
                  <span className="text-rose-600 font-semibold">
                    رصيدك: {currentUser.coins || 0} عملة 🪙
                  </span>
                </div>

                <div className="grid grid-cols-4 sm:grid-cols-6 gap-2 max-h-56 overflow-y-auto p-1 scrollbar-none">
                  {GIFTS_LIST.map((gift) => (
                    <button
                      key={gift.id}
                      onClick={() => handleSendGift(gift)}
                      className="flex flex-col items-center justify-center p-2 rounded-2xl bg-white border border-slate-200 hover:border-rose-500/50 hover:bg-rose-500/10 active:scale-95 transition-all group cursor-pointer"
                    >
                      <span className="text-2xl group-hover:scale-125 transition-transform">
                        {gift.icon}
                      </span>
                      <span className="text-[11px] font-bold text-slate-900 mt-1 text-center line-clamp-1">
                        {gift.name}
                      </span>
                      <span className="text-[10px] text-amber-600 font-semibold">
                        {gift.costCoins || gift.cost * 5} 🪙
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Music Drawer */}
            {showMusicDrawer && (
              <div className="p-4 bg-slate-50 border-t border-indigo-500/20 animate-in slide-in-from-bottom duration-200">
                <div className="flex items-center justify-between mb-3 text-xs">
                  <span className="font-bold text-slate-900 flex items-center gap-1.5">
                    <Music className="w-4 h-4 text-indigo-500" />
                    مشغل الموسيقى والاستوديو - زهرة شات 🎶
                  </span>
                  {currentTrack && (
                    <button
                      onClick={() => setCurrentTrack(null)}
                      className="text-[11px] text-rose-500 hover:text-rose-600 font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <Square className="w-3 h-3 fill-rose-400" />
                      إيقاف الموسيقى
                    </button>
                  )}
                </div>
                <div className="space-y-2.5 max-h-56 overflow-y-auto">
                  {[
                    { id: '1', title: 'طرب أصيل - عود وكمان 🎻', mood: 'طرب كلاسيكي' },
                    { id: '2', title: 'سهرة روقان - عزف هادئ 🌙', mood: 'استرخاء وهدوء' },
                    { id: '3', title: 'أغنية شرقية كلاسيك 🎶', mood: 'أجواء مجلس' },
                    { id: '4', title: 'فيروزيات الصباح والورد 🌸', mood: 'صباحي عذب' },
                    { id: '5', title: 'إيقاع شبابي حماسي 🔥', mood: 'حماس ومسابقات' }
                  ].map(track => {
                    const isSelected = currentTrack === track.title;
                    return (
                      <button
                        key={track.id}
                        onClick={() => {
                          if (isSelected) {
                            setCurrentTrack(null);
                          } else {
                            setCurrentTrack(track.title);
                          }
                        }}
                        className={`w-full flex items-center justify-between p-3 rounded-2xl border transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-gradient-to-r from-indigo-600 to-purple-600 border-indigo-400 shadow-md shadow-indigo-950/50'
                            : 'bg-white border-slate-200 hover:bg-slate-100 hover:border-slate-200'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${isSelected ? 'bg-white/20 text-white' : 'bg-slate-50 text-indigo-500'}`}>
                            {isSelected ? <Play className="w-3.5 h-3.5 fill-white" /> : <Music className="w-3.5 h-3.5" />}
                          </div>
                          <div className="text-right">
                            <span className="text-xs font-bold text-slate-900 block">{track.title}</span>
                            <span className="text-[10px] text-slate-500">{track.mood}</span>
                          </div>
                        </div>
                        {isSelected && <Volume2 className="w-4 h-4 text-white animate-pulse" />}
                      </button>
                    );
                  })}
                  <div className="pt-2 px-1">
                    <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                      <span>مستوى صوت الموسيقى</span>
                      <span className="font-mono text-indigo-600">{musicVolume}%</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={100}
                      value={musicVolume}
                      onChange={(e) => setMusicVolume(parseInt(e.target.value))}
                      className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                    />
                  </div>
                </div>
              </div>
            )}

          </div>
        </div>
      )}

      {/* CREATE ROOM MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-md rounded-3xl bg-slate-50 border border-rose-500/20 p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2 font-['Cairo']">
              <Sparkles className="w-5 h-5 text-rose-500" />
              إنشاء غرفة صوتية أو دردشة جديدة
            </h3>

            <form onSubmit={handleCreateRoom} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  اسم الغرفة
                </label>
                <input
                  type="text"
                  required
                  value={newRoomTitle}
                  onChange={(e) => setNewRoomTitle(e.target.value)}
                  placeholder="مثال: سهرة الخميس وطرب الأصيل 🌸"
                  className="w-full bg-white border border-slate-200 focus:border-rose-500 rounded-xl px-3 py-2.5 text-sm text-slate-900 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  التصنيف
                </label>
                <select
                  value={newRoomCategory}
                  onChange={(e) => setNewRoomCategory(e.target.value)}
                  className="w-full bg-white border border-slate-200 focus:border-rose-500 rounded-xl px-3 py-2.5 text-sm text-slate-900 focus:outline-none"
                >
                  <option value="دردشة عامة">دردشة عامة</option>
                  <option value="شعر وخواطر">شعر وخواطر</option>
                  <option value="مقهى">مقهى وأصدقاء</option>
                  <option value="مسابقات">مسابقات وألعاب</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  نبذة عن الغرفة
                </label>
                <textarea
                  rows={3}
                  value={newRoomDesc}
                  onChange={(e) => setNewRoomDesc(e.target.value)}
                  placeholder="اكتب وصفاً جذاباً يدعو الأصدقاء للانضمام..."
                  className="w-full bg-white border border-slate-200 focus:border-rose-500 rounded-xl px-3 py-2 text-sm text-slate-900 focus:outline-none resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-slate-600 text-xs font-semibold hover:bg-slate-200"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-rose-600 to-fuchsia-600 text-white text-xs font-bold shadow-lg shadow-rose-950/50"
                >
                  إطلاق الغرفة الآن
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ROOM OWNER SETTINGS MODAL */}
      {showRoomSettingsModal && activeRoom && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-md rounded-3xl bg-slate-50 border border-amber-500/30 p-6 shadow-2xl space-y-4">
            <button
              onClick={() => setShowRoomSettingsModal(false)}
              className="absolute top-4 left-4 p-2 text-slate-500 hover:text-slate-900 rounded-full hover:bg-slate-100 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2 font-['Cairo']">
              <Crown className="w-5 h-5 text-amber-600" />
              إدارة الغرفة والمشرفين (صلاحيات المضيف)
            </h3>

            {/* Change Cover / Photo */}
            <form onSubmit={handleUpdateRoomCover} className="space-y-2 p-3 rounded-2xl bg-white border border-slate-200">
              <span className="block text-xs font-bold text-slate-600 flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-rose-500" />
                تغيير صورة / غلاف الغرفة
              </span>
              <div className="flex gap-2">
                <input
                  type="url"
                  value={coverUrlInput}
                  onChange={(e) => setCoverUrlInput(e.target.value)}
                  placeholder="رابط صورة الغلاف (https://...)"
                  className="flex-1 px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 placeholder-slate-500 focus:outline-none focus:border-rose-500"
                />
                <button
                  type="submit"
                  disabled={!coverUrlInput.trim()}
                  className="px-3 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 disabled:opacity-40 text-white font-bold text-xs cursor-pointer transition-colors"
                >
                  حفظ
                </button>
              </div>
            </form>

            {/* Manage Moderators */}
            <div className="space-y-2 p-3 rounded-2xl bg-white border border-slate-200">
              <span className="block text-xs font-bold text-slate-600 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-purple-500" />
                المشرفون المعينون
              </span>

              <form onSubmit={handleAddModerator} className="flex gap-2">
                <input
                  type="text"
                  value={moderatorInput}
                  onChange={(e) => setModeratorInput(e.target.value)}
                  placeholder="اكتب اسم العضو لتعيينه مشرفاً"
                  className="flex-1 px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
                <button
                  type="submit"
                  disabled={!moderatorInput.trim()}
                  className="px-3 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white font-bold text-xs cursor-pointer transition-colors flex items-center gap-1"
                >
                  <UserCheck className="w-3.5 h-3.5" />
                  تعيين
                </button>
              </form>

              {activeRoom.moderators && activeRoom.moderators.length > 0 ? (
                <div className="space-y-1.5 pt-2">
                  {activeRoom.moderators.map((mod) => (
                    <div key={mod} className="flex items-center justify-between p-2 rounded-xl bg-slate-50 text-xs text-slate-800">
                      <span className="flex items-center gap-1.5">
                        <ShieldCheck className="w-3.5 h-3.5 text-purple-500" />
                        {mod}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleRemoveModerator(mod)}
                        className="text-red-500 hover:text-red-600 text-[11px] font-bold cursor-pointer"
                      >
                        إزالة
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-[11px] text-slate-500 text-center py-2">
                  لم يتم تعيين مشرفين إضافيين بعد.
                </p>
              )}
            </div>

            <button
              type="button"
              onClick={() => setShowRoomSettingsModal(false)}
              className="w-full py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-colors cursor-pointer"
            >
              إغلاق النافذة
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
