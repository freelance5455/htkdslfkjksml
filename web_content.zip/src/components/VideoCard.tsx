import React, { useState, useRef } from 'react';
import { VideoItem } from '../types/video';
import { useVideo } from '../context/VideoContext';
import { formatDuration } from '../utils/format';
import {
  Play,
  Plus,
  Check,
  ThumbsUp,
  ChevronDown,
  Trash2,
  Share2,
} from 'lucide-react';

interface VideoCardProps {
  video: VideoItem;
  rank?: number; // For Top 10 rows
  progress?: { currentTime: number; duration: number };
}

export const VideoCard: React.FC<VideoCardProps> = ({ video, rank, progress }) => {
  const {
    setActiveVideo,
    setDetailVideo,
    setYoutubeVideo,
    myList,
    toggleMyList,
    likedVideos,
    reactToVideo,
    deleteVideo,
  } = useVideo();

  const [isHovered, setIsHovered] = useState(false);
  const hoverTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const isInMyList = myList.includes(video.id);
  const isLiked = likedVideos.includes(video.id);

  const handleMouseEnter = () => {
    hoverTimeoutRef.current = setTimeout(() => {
      setIsHovered(true);
    }, 280);
  };

  const handleMouseLeave = () => {
    if (hoverTimeoutRef.current) {
      clearTimeout(hoverTimeoutRef.current);
    }
    setIsHovered(false);
  };

  const progressPercent = progress && progress.duration > 0
    ? Math.min(100, Math.round((progress.currentTime / progress.duration) * 100))
    : 0;

  return (
    <div
      className="relative flex-none w-48 sm:w-56 md:w-64 lg:w-72 select-none group cursor-pointer"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {/* Base Card */}
      <div
        onClick={() => setDetailVideo(video)}
        className="relative aspect-video rounded-md overflow-hidden bg-zinc-800 transition-all duration-300 shadow-md group-hover:shadow-2xl"
      >
        <img
          src={video.thumbnailUrl}
          alt={video.title}
          className="w-full h-full object-cover object-center transform transition-transform duration-300 group-hover:scale-105"
          loading="lazy"
        />

        {/* Gradient dark overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20" />

        {/* Top badges */}
        <div className="absolute top-2 left-2 flex items-center space-x-1">
          {video.isUploaded ? (
            <span className="bg-emerald-600/90 text-white text-[9px] font-bold px-1.5 py-0.5 rounded shadow">
              USER
            </span>
          ) : (
            <span className="bg-[#E50914] text-white text-[9px] font-black px-1.5 py-0.5 rounded shadow tracking-wider">
              TOP
            </span>
          )}
        </div>

        <div className="absolute top-2 right-2">
          <span className="bg-black/60 text-zinc-300 text-[10px] font-semibold px-1.5 py-0.5 rounded border border-white/20">
            {video.quality}
          </span>
        </div>

        {/* Bottom Title & Duration */}
        <div className="absolute bottom-2 left-2 right-2">
          <h4 className="text-white text-xs sm:text-sm font-bold truncate drop-shadow">
            {video.title}
          </h4>
          <div className="flex items-center space-x-2 text-[10px] text-zinc-300 mt-0.5 font-medium">
            <span className="text-emerald-400 font-semibold">{video.matchScore}% Match</span>
            <span>•</span>
            <span>{formatDuration(video.duration)}</span>
            <span>•</span>
            <span className="px-1 border border-zinc-500 rounded text-[9px]">{video.rating}</span>
          </div>
        </div>

        {/* Watch Progress Bar (if watched) */}
        {progressPercent > 0 && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-zinc-700">
            <div
              className="h-full bg-[#E50914]"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        )}
      </div>

      {/* Expanded Hover Pop-out Overlay */}
      {isHovered && (
        <div
          className="absolute -top-12 left-1/2 -translate-x-1/2 w-64 sm:w-72 md:w-80 bg-[#181818] rounded-md shadow-2xl z-50 overflow-hidden transform scale-100 transition-all duration-200 border border-white/10"
          style={{ transformOrigin: 'center bottom' }}
        >
          {/* Card Media Preview */}
          <div
            onClick={() => setActiveVideo(video)}
            className="relative aspect-video w-full bg-black"
          >
            <video
              src={video.trailerUrl || video.videoUrl}
              poster={video.thumbnailUrl}
              autoPlay
              muted
              loop
              playsInline
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#181818] via-transparent to-transparent" />
            <div className="absolute bottom-2 left-3 right-3 flex items-center justify-between">
              <span className="text-white font-bold text-sm truncate drop-shadow-md">
                {video.title}
              </span>
            </div>
          </div>

          {/* Action dock & metadata */}
          <div className="p-3 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                {/* Play Button (Netflix Cinema) */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveVideo(video);
                  }}
                  className="w-8 h-8 rounded-full bg-white hover:bg-zinc-200 flex items-center justify-center text-black shadow-md transition-transform hover:scale-110 active:scale-95 cursor-pointer"
                  title="Play (Cinema Mode)"
                >
                  <Play className="w-4 h-4 fill-black ml-0.5" />
                </button>

                {/* Watch in YouTube View Button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setYoutubeVideo(video);
                  }}
                  className="w-8 h-8 rounded-full border border-red-500/50 hover:border-red-500 bg-[#2a2a2a] flex items-center justify-center text-red-500 hover:text-white hover:bg-[#E50914] transition-all hover:scale-110 active:scale-95 cursor-pointer"
                  title="Watch in YouTube View"
                >
                  <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                </button>

                {/* My List Toggle */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleMyList(video.id);
                  }}
                  className="w-8 h-8 rounded-full border border-zinc-500 hover:border-white bg-[#2a2a2a] flex items-center justify-center text-white transition-transform hover:scale-110 active:scale-95 cursor-pointer"
                  title={isInMyList ? 'Remove from My List' : 'Add to My List'}
                >
                  {isInMyList ? <Check className="w-4 h-4 text-emerald-400" /> : <Plus className="w-4 h-4" />}
                </button>

                {/* Like Button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    reactToVideo(video.id, isLiked ? 'none' : 'like');
                  }}
                  className={`w-8 h-8 rounded-full border border-zinc-500 hover:border-white bg-[#2a2a2a] flex items-center justify-center text-white transition-transform hover:scale-110 active:scale-95 cursor-pointer ${
                    isLiked ? 'text-blue-400 border-blue-400' : ''
                  }`}
                  title="Like"
                >
                  <ThumbsUp className={`w-3.5 h-3.5 ${isLiked ? 'fill-blue-400' : ''}`} />
                </button>

                {/* Delete button if uploaded */}
                {video.isUploaded && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      if (confirm(`Delete "${video.title}"?`)) {
                        deleteVideo(video.id);
                      }
                    }}
                    className="w-8 h-8 rounded-full border border-red-500/50 hover:border-red-500 bg-[#2a2a2a] flex items-center justify-center text-red-400 hover:text-red-300 transition-transform hover:scale-110 active:scale-95 cursor-pointer"
                    title="Delete Uploaded Video"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Expand Details Chevron */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setDetailVideo(video);
                }}
                className="w-8 h-8 rounded-full border border-zinc-500 hover:border-white bg-[#2a2a2a] flex items-center justify-center text-zinc-300 hover:text-white transition-transform hover:scale-110 active:scale-95 cursor-pointer"
                title="Episode & Details Info"
              >
                <ChevronDown className="w-4 h-4" />
              </button>
            </div>

            {/* Badges line */}
            <div className="flex items-center space-x-2 text-xs font-semibold">
              <span className="text-emerald-400">{video.matchScore}% Match</span>
              <span className="text-zinc-400">{video.releaseYear}</span>
              <span className="px-1 border border-zinc-600 text-[10px] text-zinc-300 rounded">
                {video.rating}
              </span>
              <span className="text-zinc-400 text-[11px]">{formatDuration(video.duration)}</span>
              <span className="px-1 bg-zinc-800 text-white rounded text-[10px] font-bold">
                {video.quality}
              </span>
            </div>

            {/* Tags row */}
            <div className="text-[11px] text-zinc-400 truncate">
              {video.tags.slice(0, 3).join(' • ')}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
