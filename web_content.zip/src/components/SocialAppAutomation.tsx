import React, { useState } from 'react';
import { 
  Share2, 
  Send, 
  ThumbsUp, 
  MessageSquare, 
  ExternalLink, 
  Sparkles, 
  Copy, 
  Check, 
  Youtube, 
  Smartphone, 
  Bot, 
  Zap, 
  Radio, 
  CheckCircle2,
  Flame,
  Search
} from 'lucide-react';
import { SupportedLanguage } from '../types/assistant';

interface SocialAppAutomationProps {
  language: SupportedLanguage;
  onExecuteCommand: (command: string) => void;
  onSpeak: (text: string) => void;
}

export const SocialAppAutomation: React.FC<SocialAppAutomationProps> = ({
  language,
  onExecuteCommand,
  onSpeak,
}) => {
  const [selectedApp, setSelectedApp] = useState<'facebook' | 'youtube' | 'tiktok' | 'whatsapp' | 'x'>('facebook');
  const [actionType, setActionType] = useState<'post' | 'comment' | 'search' | 'open'>('post');
  const [postContent, setPostContent] = useState('');
  const [commentContent, setCommentContent] = useState('');
  const [searchTopic, setSearchTopic] = useState('');
  const [targetUrl, setTargetUrl] = useState('');
  const [isAiGenerating, setIsAiGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [actionLogs, setActionLogs] = useState<Array<{ id: string; app: string; action: string; content: string; time: string }>>([
    {
      id: 'log-1',
      app: 'Facebook',
      action: 'Post Prepared',
      content: 'Rubel Boss AI Assistant is now online and active!',
      time: 'Just now',
    },
  ]);

  // AI Content Generator for Post/Comment
  const handleGenerateAiCopy = async (type: 'post' | 'comment') => {
    setIsAiGenerating(true);
    const prompt = type === 'post'
      ? `Write an engaging, high-impact ${selectedApp} post for Rubel Boss about: "${postContent || 'Technology and AI innovation'}". Include catchy emojis and hashtags. Respond in ${language === 'bn' ? 'Bengali' : 'English'}.`
      : `Write a short, smart, respectful, and engaging comment for a ${selectedApp} video/post about: "${commentContent || 'amazing content'}". In ${language === 'bn' ? 'Bengali' : 'English'}.`;

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: prompt,
          userName: 'Rubel Boss',
          language,
        }),
      });
      const data = await res.json();
      const generated = data.reply || '';
      if (type === 'post') {
        setPostContent(generated);
      } else {
        setCommentContent(generated);
      }
    } catch {
      // ignore
    } finally {
      setIsAiGenerating(false);
    }
  };

  // Launch Post Action
  const handlePublishPost = () => {
    if (!postContent.trim()) return;

    // Add to activity log
    const newLog = {
      id: `log-${Date.now()}`,
      app: selectedApp.toUpperCase(),
      action: 'Direct Post Dispatch',
      content: postContent,
      time: new Date().toLocaleTimeString(),
    };
    setActionLogs((prev) => [newLog, ...prev]);

    // Copy to clipboard for instant pasting
    navigator.clipboard.writeText(postContent);

    // Deep link redirect
    if (selectedApp === 'facebook') {
      const fbUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent('https://facebook.com')}&quote=${encodeURIComponent(postContent)}`;
      window.open(fbUrl, '_blank');
    } else if (selectedApp === 'x') {
      const xUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(postContent)}`;
      window.open(xUrl, '_blank');
    } else if (selectedApp === 'whatsapp') {
      const waUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(postContent)}`;
      window.open(waUrl, '_blank');
    } else if (selectedApp === 'youtube') {
      window.open('https://studio.youtube.com', '_blank');
    } else if (selectedApp === 'tiktok') {
      window.open('https://www.tiktok.com/upload', '_blank');
    }

    if (navigator.share) {
      try {
        navigator.share({
          title: 'Rubel Boss Post',
          text: postContent,
        });
      } catch {
        // user cancelled share
      }
    }
  };

  // Launch Comment Action
  const handlePublishComment = () => {
    if (!commentContent.trim()) return;

    navigator.clipboard.writeText(commentContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);

    const newLog = {
      id: `log-${Date.now()}`,
      app: selectedApp.toUpperCase(),
      action: 'Comment Prepared & Copied',
      content: commentContent,
      time: new Date().toLocaleTimeString(),
    };
    setActionLogs((prev) => [newLog, ...prev]);

    if (selectedApp === 'facebook') {
      window.open(targetUrl || 'https://www.facebook.com', '_blank');
    } else if (selectedApp === 'youtube') {
      window.open(targetUrl || 'https://www.youtube.com', '_blank');
    } else if (selectedApp === 'tiktok') {
      window.open(targetUrl || 'https://www.tiktok.com', '_blank');
    }
  };

  // Launch Quick App Navigation
  const handleOpenApp = (app: string, customQuery?: string) => {
    const q = encodeURIComponent(customQuery || searchTopic || '');
    if (app === 'facebook') {
      const url = q ? `https://www.facebook.com/search/top/?q=${q}` : 'https://www.facebook.com';
      window.open(url, '_blank');
    } else if (app === 'youtube') {
      const url = q ? `https://www.youtube.com/results?search_query=${q}` : 'https://www.youtube.com';
      window.open(url, '_blank');
    } else if (app === 'tiktok') {
      const url = q ? `https://www.tiktok.com/search?q=${q}` : 'https://www.tiktok.com';
      window.open(url, '_blank');
    } else if (app === 'whatsapp') {
      window.open('https://web.whatsapp.com', '_blank');
    } else if (app === 'x') {
      const url = q ? `https://twitter.com/search?q=${q}` : 'https://twitter.com';
      window.open(url, '_blank');
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-950 via-[#0a152e] to-[#260e2d] border border-cyan-500/40 p-6 shadow-2xl relative overflow-hidden">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-2 px-3 py-0.5 rounded-full bg-cyan-950 border border-cyan-500/50 text-cyan-300 text-xs font-mono-tech">
            <Radio className="w-3.5 h-3.5 text-cyan-400" />
            <span>APP AUTOMATION & SOCIAL BOT MATRIX</span>
          </div>
          <h2 className="text-2xl font-orbitron font-extrabold tracking-wider bg-gradient-to-r from-white via-cyan-200 to-fuchsia-400 bg-clip-text text-transparent">
            {language === 'bn' ? 'অ্যাপস ও সোশ্যাল মিডিয়া অটোমেশন' : 'APP & SOCIAL AUTOMATION HUB'}
          </h2>
          <p className="text-slate-400 text-xs sm:text-sm">
            {language === 'bn'
              ? 'ফেসবুক, ইউটিউব, টিকটকে স্বয়ংক্রিয়ভাবে পোস্ট তৈরি, কমেন্ট ড্রাফট, লাইক ও ডাইরেক্ট ব্রাউজিং সহকারী।'
              : 'Directly launch, post status updates, compose comments, and engage across Facebook, YouTube, TikTok, and WhatsApp.'}
          </p>
        </div>
      </div>

      {/* Target App Selector Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {[
          { id: 'facebook', name: 'Facebook', color: 'border-blue-500 text-blue-400', bg: 'bg-blue-950/40' },
          { id: 'youtube', name: 'YouTube', color: 'border-red-500 text-red-400', bg: 'bg-red-950/40' },
          { id: 'tiktok', name: 'TikTok', color: 'border-cyan-400 text-cyan-300', bg: 'bg-cyan-950/40' },
          { id: 'whatsapp', name: 'WhatsApp', color: 'border-emerald-500 text-emerald-400', bg: 'bg-emerald-950/40' },
          { id: 'x', name: 'X / Twitter', color: 'border-slate-400 text-slate-200', bg: 'bg-slate-900/60' },
        ].map((app) => {
          const isSelected = selectedApp === app.id;
          return (
            <button
              key={app.id}
              onClick={() => setSelectedApp(app.id as any)}
              className={`p-3.5 rounded-2xl border text-sm font-orbitron font-bold transition-all flex flex-col items-center justify-center gap-1.5 shadow-md ${
                isSelected
                  ? `${app.bg} ${app.color} ring-2 ring-cyan-400 shadow-cyan-500/20 scale-105`
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>{app.name}</span>
              <span className="text-[10px] font-mono-tech text-slate-500">
                {isSelected ? '● CONNECTED' : 'SELECT'}
              </span>
            </button>
          );
        })}
      </div>

      {/* Action Type Tabs */}
      <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-slate-950 border border-cyan-900/40">
        {[
          { id: 'post', labelBn: 'পোস্ট তৈরি ও শেয়ার', labelEn: 'Create & Share Post', icon: <Share2 className="w-4 h-4" /> },
          { id: 'comment', labelBn: 'অটো কমেন্ট ড্রাফট', labelEn: 'Auto Comment Assistant', icon: <MessageSquare className="w-4 h-4" /> },
          { id: 'search', labelBn: 'সার্চ ও ওপেন অ্যাপ', labelEn: 'Search & Launch App', icon: <Search className="w-4 h-4" /> },
        ].map((tab) => {
          const isActive = actionType === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActionType(tab.id as any)}
              className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-orbitron font-bold transition-all flex items-center justify-center gap-2 ${
                isActive
                  ? 'bg-cyan-500/20 border border-cyan-400 text-cyan-300 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab.icon}
              <span>{language === 'bn' ? tab.labelBn : tab.labelEn}</span>
            </button>
          );
        })}
      </div>

      {/* Action Workspace */}
      <div className="rounded-3xl bg-[#090f1f]/95 border border-cyan-500/40 p-5 md:p-6 shadow-xl space-y-4">
        {/* POST CREATOR WORKSPACE */}
        {actionType === 'post' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-cyan-900/40 pb-3">
              <div className="flex items-center gap-2">
                <Share2 className="w-5 h-5 text-cyan-400" />
                <h3 className="font-orbitron font-bold text-sm text-white tracking-wide">
                  PUBLISH POST ON {selectedApp.toUpperCase()}
                </h3>
              </div>
              <button
                onClick={() => handleGenerateAiCopy('post')}
                disabled={isAiGenerating}
                className="px-3 py-1.5 rounded-xl bg-fuchsia-950/70 border border-fuchsia-500/40 text-fuchsia-300 hover:bg-fuchsia-900 text-xs font-mono-tech flex items-center gap-1.5 transition-all"
              >
                <Sparkles className="w-3.5 h-3.5 text-fuchsia-400 animate-spin" />
                <span>{isAiGenerating ? 'AI WRITING...' : 'AI AUTO-GENERATE COPY'}</span>
              </button>
            </div>

            <textarea
              rows={4}
              value={postContent}
              onChange={(e) => setPostContent(e.target.value)}
              placeholder={
                language === 'bn'
                  ? `আপনার ${selectedApp} পোস্টের বিষয়বস্তু লিখুন বা বলুন (যেমন: নতুন টেক আপডেট, ব্যবসার বিজ্ঞাপন, স্ট্যাটাস ইত্যাদি)...`
                  : `Type your ${selectedApp} status/caption or let AI generate it...`
              }
              className="w-full bg-slate-950 text-slate-100 placeholder:text-slate-500 text-sm p-4 rounded-2xl border border-cyan-900/60 focus:outline-none focus:border-cyan-400 font-sans resize-none"
            />

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <div className="flex items-center gap-2 text-xs font-mono-tech text-slate-400">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Auto-copied to clipboard & deep link ready</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(postContent);
                    setCopied(true);
                    setTimeout(() => setCopied(false), 2000);
                  }}
                  className="px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 hover:bg-slate-800 text-slate-300 text-xs font-mono-tech flex items-center gap-1.5"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>

                <button
                  onClick={handlePublishPost}
                  disabled={!postContent.trim()}
                  className={`px-5 py-2.5 rounded-xl font-orbitron font-bold text-xs tracking-wider transition-all flex items-center gap-2 shadow-lg ${
                    postContent.trim()
                      ? 'bg-gradient-to-r from-cyan-500 to-fuchsia-500 hover:from-cyan-400 hover:to-fuchsia-400 text-slate-950 shadow-cyan-500/20'
                      : 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed'
                  }`}
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>DIRECT DISPATCH TO {selectedApp.toUpperCase()}</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* COMMENT ASSISTANT WORKSPACE */}
        {actionType === 'comment' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-cyan-900/40 pb-3">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-fuchsia-400" />
                <h3 className="font-orbitron font-bold text-sm text-white tracking-wide">
                  AUTO COMMENT ON {selectedApp.toUpperCase()}
                </h3>
              </div>
              <button
                onClick={() => handleGenerateAiCopy('comment')}
                disabled={isAiGenerating}
                className="px-3 py-1.5 rounded-xl bg-cyan-950/70 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-900 text-xs font-mono-tech flex items-center gap-1.5 transition-all"
              >
                <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
                <span>{isAiGenerating ? 'AI THINKING...' : 'AI GENERATE SMART COMMENT'}</span>
              </button>
            </div>

            <div>
              <label className="text-xs font-mono-tech text-slate-400">Target Post / Video URL (Optional)</label>
              <input
                type="text"
                value={targetUrl}
                onChange={(e) => setTargetUrl(e.target.value)}
                placeholder="https://facebook.com/... or https://youtube.com/watch?v=..."
                className="w-full mt-1 bg-slate-950 text-slate-100 text-sm px-4 py-2.5 rounded-xl border border-slate-800 focus:outline-none focus:border-cyan-400 font-mono-tech"
              />
            </div>

            <div>
              <label className="text-xs font-mono-tech text-slate-400">Comment Text</label>
              <textarea
                rows={3}
                value={commentContent}
                onChange={(e) => setCommentContent(e.target.value)}
                placeholder="Type or let AI craft an engaging comment..."
                className="w-full mt-1 bg-slate-950 text-slate-100 placeholder:text-slate-500 text-sm p-4 rounded-2xl border border-cyan-900/60 focus:outline-none focus:border-cyan-400 font-sans resize-none"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={handlePublishComment}
                disabled={!commentContent.trim()}
                className={`px-5 py-2.5 rounded-xl font-orbitron font-bold text-xs tracking-wider transition-all flex items-center gap-2 shadow-lg ${
                  commentContent.trim()
                    ? 'bg-fuchsia-500 hover:bg-fuchsia-400 text-slate-950 shadow-fuchsia-500/20'
                    : 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed'
                }`}
              >
                <Send className="w-4 h-4" />
                <span>DISPATCH & INJECT COMMENT</span>
              </button>
            </div>
          </div>
        )}

        {/* SEARCH & LAUNCH WORKSPACE */}
        {actionType === 'search' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-cyan-900/40 pb-3">
              <div className="flex items-center gap-2">
                <Search className="w-5 h-5 text-emerald-400" />
                <h3 className="font-orbitron font-bold text-sm text-white tracking-wide">
                  DIRECT SEARCH & NAVIGATE: {selectedApp.toUpperCase()}
                </h3>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="text"
                value={searchTopic}
                onChange={(e) => setSearchTopic(e.target.value)}
                placeholder={`Search query on ${selectedApp}...`}
                className="flex-1 bg-slate-950 text-slate-100 text-sm px-4 py-3 rounded-2xl border border-slate-800 focus:outline-none focus:border-cyan-400 font-sans"
                onKeyDown={(e) => e.key === 'Enter' && handleOpenApp(selectedApp, searchTopic)}
              />
              <button
                onClick={() => handleOpenApp(selectedApp, searchTopic)}
                className="px-6 py-3 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-orbitron font-bold text-xs tracking-wider transition-all shadow-md shadow-cyan-500/30"
              >
                OPEN & SEARCH
              </button>
            </div>

            {/* Quick Trending Searches */}
            <div className="pt-2 space-y-1.5">
              <span className="text-xs font-mono-tech text-slate-400">Quick Direct Navigations:</span>
              <div className="flex flex-wrap gap-2">
                {[
                  'Trending AI News',
                  'Rubel Boss Creations',
                  'Sci-Fi Tech Updates',
                  'Bangla Viral Videos',
                  'Programming Tutorials',
                ].map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleOpenApp(selectedApp, item)}
                    className="px-3 py-1 rounded-xl bg-slate-950 hover:bg-slate-900 border border-slate-800 text-xs text-slate-300 font-mono-tech"
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Activity Log & Protocol Dossier */}
      <div className="rounded-3xl bg-[#090f1f]/95 border border-cyan-900/40 p-5 space-y-3 shadow-xl">
        <h4 className="font-orbitron font-bold text-xs text-cyan-300 tracking-wider">
          RECENT DISPATCH TELEMETRY LOGS
        </h4>
        <div className="space-y-2">
          {actionLogs.map((log) => (
            <div
              key={log.id}
              className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between text-xs font-mono-tech"
            >
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30 font-bold">
                  {log.app}
                </span>
                <span className="text-slate-300 font-semibold">{log.action}:</span>
                <span className="text-slate-400 truncate max-w-xs">{log.content}</span>
              </div>
              <span className="text-slate-500">{log.time}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
