import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  Monitor, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Send, 
  Sparkles, 
  Bot, 
  CornerDownLeft, 
  ArrowRight,
  Maximize2,
  Minimize2,
  Share2,
  StopCircle,
  Play,
  Layers,
  HelpCircle,
  CheckCircle2,
  ExternalLink
} from 'lucide-react';
import { streamChatResponse, ChatMessage } from '../services/gemini';
import { parseAndExecuteVoiceCommand } from '../utils/voiceCommands';
import { cn } from '../utils/cn';

interface LiveScreenShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveToChat?: (messages: ChatMessage[]) => void;
  userName?: string;
  persona?: 'Male' | 'Female';
  language?: string;
}

interface ScreenExchange {
  id: string;
  userQuestion: string;
  frameUrl: string;
  aiResponse: string;
  timestamp: Date;
}

export function LiveScreenShareModal({
  isOpen,
  onClose,
  onSaveToChat,
  userName = 'Dost',
  persona = 'Female',
  language = 'Hinglish'
}: LiveScreenShareModalProps) {
  const [isSharing, setIsSharing] = useState(false);
  const [shareError, setShareError] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const isThinkingRef = useRef(false);
  const lastRequestTimeRef = useRef<number>(0);
  const [isMuted, setIsMuted] = useState(false);
  const [textInput, setTextInput] = useState('');
  const [transcript, setTranscript] = useState('');
  const [activeVoice, setActiveVoice] = useState<'Female' | 'Male'>(persona);
  const [exchanges, setExchanges] = useState<ScreenExchange[]>([]);
  const [currentAiSpeech, setCurrentAiSpeech] = useState<string>('');
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [capturedFlash, setCapturedFlash] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const recognitionRef = useRef<any>(null);
  const modalContainerRef = useRef<HTMLDivElement>(null);

  const screenPrompts = [
    { label: "Screen par kya hai?", prompt: "Dekho aur batao screen par abhi kya dikh raha hai aur kya chal raha hai." },
    { label: "Error fix karo", prompt: "Screen par jo error ya samasya dikh rahi hai, usko samjhao aur theek karne ka step-by-step solution do." },
    { label: "Code check karo", prompt: "Screen par jo code ya logic dikh raha hai usko analyze karo aur bugs ya improvements batao." },
    { label: "Page summary", prompt: "Screen par jo content, web page ya document open hai uski main summary Hindi mein do." },
    { label: "Next step kya karein?", prompt: "Is screen ko dekh kar batao ki mujhe aage kya karna chahiye ya kahan click karna chahiye." }
  ];

  // Initialize Speech Recognition
  useEffect(() => {
    if (!isOpen) return;

    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRec) {
      const rec = new SpeechRec();
      rec.continuous = false;
      rec.interimResults = true;
      rec.lang = language === 'Hindi' ? 'hi-IN' : 'hi-IN';

      rec.onstart = () => {
        setIsListening(true);
        setTranscript('');
      };

      rec.onresult = (event: any) => {
        let currentText = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          currentText += event.results[i][0].transcript;
        }
        setTranscript(currentText);
      };

      rec.onend = () => {
        setIsListening(false);
        setTranscript((prevText) => {
          const trimmed = prevText.trim();
          if (trimmed.length > 2) {
            handleAskQuestion(trimmed);
          }
          return '';
        });
      };

      rec.onerror = (err: any) => {
        console.warn("Screen share speech recognition error:", err);
        setIsListening(false);
      };

      recognitionRef.current = rec;
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (_) {}
      }
    };
  }, [isOpen, language]);

  // Start Screen Sharing
  const startScreenShare = async () => {
    setShareError(null);
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
        throw new Error("Aapke browser mein direct screen share support nahi hai ya permission restricted hai.");
      }

      // Request screen stream
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          displaySurface: 'monitor',
          cursor: 'always'
        } as any,
        audio: false
      });

      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          videoRef.current?.play().catch(console.warn);
        };
      }

      setIsSharing(true);

      // Listen for user stopping screen share from browser banner
      const videoTrack = stream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.onended = () => {
          stopScreenShare();
        };
      }

      // Initial greeting via TTS
      speakText("Aapki screen connect ho gayi hai! Screen par jo bhi dikhana chahein dikhaiye, ya WhatsApp, YouTube, Google bol kar open karwayein.");
    } catch (err: any) {
      console.warn("Screen share activation state:", err?.name, err?.message);
      if (err?.name === 'NotAllowedError' || err?.name === 'PermissionDeniedError') {
        setShareError("Screen share permission cancel hui ya browser ne block ki. Neeche diye button par click karein.");
      } else {
        setShareError("Screen share ke liye 'Screen Share Kholein' button par click karein.");
      }
      setIsSharing(false);
    }
  };

  const stopScreenShare = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsSharing(false);
  };

  // Close and cancel everything safely
  const handleCancelAndClose = () => {
    stopScreenShare();
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    onClose();
  };

  // Lifecycle
  useEffect(() => {
    if (isOpen) {
      // Try to initiate screen share, but tolerate transient user-gesture requirements
      startScreenShare();
      
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') {
          handleCancelAndClose();
        }
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => {
        window.removeEventListener('keydown', handleKeyDown);
      };
    } else {
      stopScreenShare();
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
      setIsSpeaking(false);
      setIsThinking(false);
      setTranscript('');
      setTextInput('');
    }

    return () => {
      stopScreenShare();
    };
  }, [isOpen]);

  // Voice synthesis
  const speakText = (text: string) => {
    if (isMuted || !window.speechSynthesis) return;

    window.speechSynthesis.cancel();
    const cleanText = text.replace(/[*#`_~[\]()]/g, ' ').replace(/\s+/g, ' ').trim();
    if (!cleanText) return;

    const utterance = new SpeechSynthesisUtterance(cleanText);
    const voices = window.speechSynthesis.getVoices();

    let targetVoice = null;
    if (activeVoice === 'Female') {
      targetVoice = voices.find(v => 
        (v.name.toLowerCase().includes('swara') || 
         v.name.toLowerCase().includes('priya') || 
         v.name.toLowerCase().includes('female') ||
         v.name.toLowerCase().includes('zira') ||
         v.name.toLowerCase().includes('veena')) &&
        (v.lang.startsWith('hi') || v.lang.startsWith('en'))
      );
    } else {
      targetVoice = voices.find(v => 
        (v.name.toLowerCase().includes('hemant') || 
         v.name.toLowerCase().includes('madhav') || 
         v.name.toLowerCase().includes('male') ||
         v.name.toLowerCase().includes('david') ||
         v.name.toLowerCase().includes('mark')) &&
        (v.lang.startsWith('hi') || v.lang.startsWith('en'))
      );
    }

    if (!targetVoice) {
      targetVoice = voices.find(v => v.lang.startsWith('hi')) || voices[0];
    }

    if (targetVoice) utterance.voice = targetVoice;
    utterance.rate = 1.0;
    utterance.pitch = activeVoice === 'Female' ? 1.05 : 0.95;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  // Capture screen frame as JPEG Data URL
  const captureScreenFrame = (): string | null => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas || video.videoWidth === 0 || video.videoHeight === 0) {
      return null;
    }

    // Set canvas dimensions to match stream resolution (scaled for API performance)
    const maxDim = 1280;
    let width = video.videoWidth;
    let height = video.videoHeight;

    if (width > maxDim || height > maxDim) {
      if (width > height) {
        height = Math.round((height * maxDim) / width);
        width = maxDim;
      } else {
        width = Math.round((width * maxDim) / height);
        height = maxDim;
      }
    }

    canvas.width = width;
    canvas.height = height;

    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    ctx.drawImage(video, 0, 0, width, height);

    // Flash effect
    setCapturedFlash(true);
    setTimeout(() => setCapturedFlash(false), 300);

    return canvas.toDataURL('image/jpeg', 0.85);
  };

  // Handle Question with Screen Frame
  const handleAskQuestion = async (question: string) => {
    const trimmed = question.trim();
    const now = Date.now();
    if (!trimmed || isThinkingRef.current || (now - lastRequestTimeRef.current < 1200)) return;
    lastRequestTimeRef.current = now;
    isThinkingRef.current = true;
    setIsThinking(true);

    // Check if user is giving a voice command to open WhatsApp, YouTube, Google, etc.
    const voiceAction = parseAndExecuteVoiceCommand(trimmed);
    if (voiceAction) {
      if (window.speechSynthesis) window.speechSynthesis.cancel();
      const exchangeId = 'action_' + Date.now();
      const actionMsg = `${voiceAction.spokenReply}\n\n👉 [${voiceAction.actionName} Open Karein](${voiceAction.url})`;
      
      const newExchange: ScreenExchange = {
        id: exchangeId,
        userQuestion: trimmed,
        frameUrl: '',
        aiResponse: actionMsg,
        timestamp: new Date()
      };
      setExchanges(prev => [...prev, newExchange]);
      setCurrentAiSpeech(voiceAction.spokenReply);
      setTextInput('');
      speakText(voiceAction.spokenReply);
      isThinkingRef.current = false;
      setIsThinking(false);
      return;
    }

    let frameBase64 = captureScreenFrame();

    // If frame capture wasn't possible because video wasn't ready
    const imagesPayload: string[] = frameBase64 ? [frameBase64] : [];

    setCurrentAiSpeech('');
    if (window.speechSynthesis) window.speechSynthesis.cancel();

    const exchangeId = 'screen_' + Date.now();
    const newExchange: ScreenExchange = {
      id: exchangeId,
      userQuestion: trimmed,
      frameUrl: frameBase64 || '',
      aiResponse: '',
      timestamp: new Date()
    };

    setExchanges(prev => [...prev, newExchange]);
    setTextInput('');

    try {
      const userPrompt = `[LIVE SCREEN SHARE INQUIRY] 
User sawal: "${trimmed}"
Instructions: Aap live screen share dekh rahe hain. Screen par dikh rahe elements, errors, text, layout ya software ko dhyaan se dekhein aur user ko exact, accurate aur seedha jawab dein. Agar koi error ya code hai toh specific line aur solution batao.`;

      // Request stream from backend with gemini-3.1-flash-lite
      const stream = streamChatResponse(
        chatHistory,
        userPrompt,
        imagesPayload,
        'gemini-3.1-flash-lite',
        activeVoice
      );

      let accumulated = '';
      for await (const chunk of stream) {
        if (chunk.error) {
          throw new Error(chunk.error);
        }
        accumulated += chunk.text || '';
        setCurrentAiSpeech(accumulated);
        setExchanges(prev => 
          prev.map(e => e.id === exchangeId ? { ...e, aiResponse: accumulated } : e)
        );
      }

      // Update chat history for continuous context
      const newHistory: ChatMessage[] = [
        ...chatHistory,
        { role: 'user', content: trimmed, images: imagesPayload },
        { role: 'model', content: accumulated }
      ];
      setChatHistory(newHistory);

      // Speak response aloud
      speakText(accumulated);
    } catch (err: any) {
      console.error("Live screen share AI error:", err);
      const isRateLimit = err?.message?.includes('429') || err?.message?.toLowerCase()?.includes('rate') || err?.message?.toLowerCase()?.includes('quota');
      const errorMsg = isRateLimit
        ? "Bohot saare requests aa rahe hain. Kripya 5 second baad dubara prayaas karein."
        : "Maaf kijiye, screen analyze karte samay network samasya aayi. Kripya dubara poochiye.";
      setCurrentAiSpeech(errorMsg);
      speakText(errorMsg);
      setExchanges(prev => 
        prev.map(e => e.id === exchangeId ? { ...e, aiResponse: errorMsg } : e)
      );
    } finally {
      isThinkingRef.current = false;
      setIsThinking(false);
    }
  };

  const toggleMic = () => {
    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
    } else {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.start();
        } catch (e) {
          console.warn("Could not start recognition:", e);
        }
      } else {
        alert("Aapke browser mein voice recognition support nahi mila. Text box se sawal pooch sakte hain.");
      }
    }
  };

  const toggleFullscreen = () => {
    if (!modalContainerRef.current) return;
    if (!document.fullscreenElement) {
      modalContainerRef.current.requestFullscreen?.().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen?.().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  const handleTransferToChat = () => {
    if (onSaveToChat && chatHistory.length > 0) {
      onSaveToChat(chatHistory);
    }
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div 
      ref={modalContainerRef}
      className={cn(
        "fixed inset-0 z-[120] flex flex-col bg-slate-950 text-white animate-fade-in select-none",
        isFullscreen ? "p-0" : "p-2 sm:p-4 md:p-6"
      )}
    >
      {/* Hidden canvas for capturing frame */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Main Container */}
      <div className="flex-1 flex flex-col max-w-6xl w-full mx-auto bg-slate-900 rounded-3xl border border-slate-800 shadow-2xl overflow-hidden relative">
        
        {/* Top Navigation Header */}
        <div className="h-16 px-4 md:px-6 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 flex items-center justify-between z-20">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-tr from-cyan-600 to-blue-500 rounded-xl text-white shadow-lg shadow-cyan-500/20">
              <Monitor size={22} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-bold text-base md:text-lg text-white">Live Screen Share</h2>
                {isSharing ? (
                  <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-green-500/20 text-green-400 border border-green-500/30">
                    <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                    SHARING ACTIVE
                  </span>
                ) : (
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                    PAUSED
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                AI aapki screen dekh kar live help aur explanations dega
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Voice toggle */}
            <button
              onClick={() => {
                const next = activeVoice === 'Female' ? 'Male' : 'Female';
                setActiveVoice(next);
                speakText(next === 'Female' ? "Awaz badal kar Swara ki gayi." : "Awaz badal kar Hemant ki gayi.");
              }}
              className="px-3 py-1.5 rounded-full text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors hidden sm:flex items-center gap-1.5"
              title="Change Voice"
            >
              <Sparkles size={14} className="text-cyan-400" />
              <span>{activeVoice === 'Female' ? 'Voice: Swara' : 'Voice: Hemant'}</span>
            </button>

            {/* Mute toggle */}
            <button
              onClick={() => {
                if (!isMuted && window.speechSynthesis) window.speechSynthesis.cancel();
                setIsMuted(!isMuted);
              }}
              className={cn(
                "p-2.5 rounded-xl border transition-colors",
                isMuted 
                  ? "bg-red-500/10 border-red-500/30 text-red-400" 
                  : "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700"
              )}
              title={isMuted ? "Unmute AI Voice" : "Mute AI Voice"}
            >
              {isMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}
            </button>

            {/* Fullscreen */}
            <button
              onClick={toggleFullscreen}
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors hidden sm:block"
              title="Toggle Fullscreen"
            >
              {isFullscreen ? <Minimize2 size={18} /> : <Maximize2 size={18} />}
            </button>

            {/* Cancel / Hatao Option on the side */}
            <button
              onClick={handleCancelAndClose}
              className="px-3.5 py-2 rounded-xl bg-red-500/20 hover:bg-red-600 text-red-300 hover:text-white border border-red-500/40 text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm"
              title="Screen Share Cancel Karein / Hatao"
            >
              <X size={16} />
              <span>Cancel / Hatao</span>
            </button>
          </div>
        </div>

        {/* Video Screen Viewport */}
        <div className="flex-1 relative bg-black flex items-center justify-center overflow-hidden">
          
          {/* Flash capture animation */}
          {capturedFlash && (
            <div className="absolute inset-0 bg-white/40 z-30 pointer-events-none animate-ping" />
          )}

          {isSharing ? (
            <>
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-contain max-h-full"
              />

              {/* Status HUD Overlays */}
              <div className="absolute top-4 left-4 z-20 flex items-center gap-2">
                <span className="px-3 py-1 bg-black/70 backdrop-blur-md text-xs font-semibold text-cyan-300 rounded-full border border-cyan-500/30 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
                  LIVE STREAM ACTIVE
                </span>
                <button
                  onClick={stopScreenShare}
                  className="px-3 py-1 bg-red-600/80 hover:bg-red-600 text-white text-xs font-bold rounded-full backdrop-blur-md transition-all flex items-center gap-1.5 shadow-lg shadow-red-600/30"
                >
                  <StopCircle size={14} />
                  Stop Share
                </button>
              </div>

              {/* Side Floating Actions: Cancel & Scan */}
              <div className="absolute top-4 right-4 z-20 flex items-center gap-2">
                <button
                  onClick={handleCancelAndClose}
                  className="px-3.5 py-1.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-full shadow-lg shadow-red-600/30 transition-all flex items-center gap-1.5"
                >
                  <X size={14} />
                  Cancel / Hatao
                </button>
                <button
                  onClick={() => handleAskQuestion("Dekho aur screen par kya chal raha hai turant batao.")}
                  disabled={isThinking}
                  className="px-3.5 py-1.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold rounded-full shadow-lg shadow-cyan-600/30 transition-all flex items-center gap-2 disabled:opacity-50"
                >
                  <Sparkles size={14} />
                  Scan Screen Now
                </button>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center p-6 sm:p-8 text-center max-w-md animate-fade-in z-20 overflow-y-auto">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-3xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center text-white mb-4 sm:mb-6 shadow-2xl shadow-cyan-500/30">
                <Monitor size={36} />
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-white mb-2">Screen Share Shuru Karein</h3>
              <p className="text-slate-400 text-xs sm:text-sm mb-5 leading-relaxed">
                Aap browser tab, koi application ya poori screen choose karke AI se connect kar sakte hain. Aap voice se "WhatsApp open", "YouTube open", ya "Google search" bhi bol sakte hain.
              </p>
              
              {shareError && (
                <div className="mb-4 p-3 bg-red-950/60 border border-red-800 rounded-xl text-xs text-red-300">
                  {shareError}
                </div>
              )}

              <div className="flex flex-col gap-2.5 w-full">
                <button
                  onClick={startScreenShare}
                  className="w-full py-3.5 px-6 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-sm sm:text-base rounded-2xl shadow-xl shadow-cyan-600/30 transition-all active:scale-[0.98] flex items-center justify-center gap-2"
                >
                  <Share2 size={18} />
                  Screen Share Kholein
                </button>

                <div className="flex gap-2">
                  <button
                    onClick={() => window.open(window.location.href, '_blank')}
                    className="flex-1 py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-semibold text-xs rounded-xl border border-slate-700 transition-all flex items-center justify-center gap-1.5"
                  >
                    <ExternalLink size={14} />
                    New Tab Mein Kholein
                  </button>
                  <button
                    onClick={handleCancelAndClose}
                    className="py-2.5 px-4 bg-red-500/20 hover:bg-red-600 text-red-300 hover:text-white font-semibold text-xs rounded-xl border border-red-500/40 transition-all flex items-center justify-center gap-1"
                  >
                    <X size={14} />
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* AI Live Status Badge / Thinking Indicator */}
          {isThinking && (
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-30 bg-slate-900/90 border border-cyan-500/40 backdrop-blur-md px-6 py-4 rounded-3xl flex items-center gap-3 shadow-2xl shadow-cyan-500/20">
              <div className="w-6 h-6 border-3 border-cyan-400 border-t-transparent rounded-full animate-spin" />
              <span className="text-sm font-semibold text-cyan-200">
                Screen analyze ho rahi hai...
              </span>
            </div>
          )}

          {/* Active Speaking / AI Subtitle Overlay */}
          {currentAiSpeech && (
            <div className="absolute bottom-20 left-4 right-4 z-20 max-w-3xl mx-auto">
              <div className="bg-slate-950/85 backdrop-blur-md border border-cyan-500/30 p-4 rounded-2xl shadow-2xl animate-fade-in flex items-start gap-3">
                <div className="p-2 bg-cyan-600/20 text-cyan-400 rounded-xl flex-shrink-0 mt-0.5">
                  <Bot size={20} />
                </div>
                <div className="flex-1 overflow-hidden">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                      India GPT Live
                      {isSpeaking && (
                        <span className="flex gap-0.5 items-end h-3">
                          <span className="w-1 bg-cyan-400 h-2 animate-bounce" />
                          <span className="w-1 bg-cyan-400 h-3 animate-bounce [animation-delay:0.2s]" />
                          <span className="w-1 bg-cyan-400 h-1.5 animate-bounce [animation-delay:0.4s]" />
                        </span>
                      )}
                    </span>
                    <button
                      onClick={() => speakText(currentAiSpeech)}
                      className="text-xs text-slate-400 hover:text-white flex items-center gap-1"
                    >
                      <Volume2 size={13} />
                      Dubara sunein
                    </button>
                  </div>
                  <p className="text-sm text-slate-100 leading-relaxed max-h-24 overflow-y-auto whitespace-pre-line">
                    {currentAiSpeech}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Quick Question & Voice Action Chips */}
        <div className="px-4 py-2 bg-slate-900/90 border-t border-slate-800 flex items-center gap-2 overflow-x-auto no-scrollbar z-20">
          <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider flex-shrink-0 flex items-center gap-1">
            <Sparkles size={13} className="text-cyan-400" />
            Quick Command:
          </span>
          <button
            onClick={() => handleAskQuestion("WhatsApp open")}
            className="px-3 py-1.5 bg-green-500/20 hover:bg-green-500/30 text-green-300 text-xs font-semibold rounded-full border border-green-500/40 transition-all flex-shrink-0 flex items-center gap-1"
          >
            💬 WhatsApp Open
          </button>
          <button
            onClick={() => handleAskQuestion("YouTube open")}
            className="px-3 py-1.5 bg-red-500/20 hover:bg-red-500/30 text-red-300 text-xs font-semibold rounded-full border border-red-500/40 transition-all flex-shrink-0 flex items-center gap-1"
          >
            ▶️ YouTube Open
          </button>
          <button
            onClick={() => handleAskQuestion("Google open")}
            className="px-3 py-1.5 bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 text-xs font-semibold rounded-full border border-blue-500/40 transition-all flex-shrink-0 flex items-center gap-1"
          >
            🔍 Google Open
          </button>
          {screenPrompts.map((item, idx) => (
            <button
              key={idx}
              onClick={() => handleAskQuestion(item.prompt)}
              disabled={isThinking || !isSharing}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-medium rounded-full border border-slate-700/80 transition-all flex-shrink-0 disabled:opacity-40"
            >
              {item.label}
            </button>
          ))}
          {chatHistory.length > 0 && (
            <button
              onClick={handleTransferToChat}
              className="ml-auto px-3 py-1.5 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white text-xs font-bold rounded-full transition-all flex items-center gap-1.5 flex-shrink-0 shadow-sm"
            >
              <ArrowRight size={14} />
              Chat Mein Le Jao ({chatHistory.length / 2})
            </button>
          )}
        </div>

        {/* Bottom User Input Bar */}
        <div className="p-3 md:p-4 bg-slate-900 border-t border-slate-800 flex items-center gap-2 z-20">
          {/* Voice Mic Button */}
          <button
            onClick={toggleMic}
            disabled={!isSharing}
            className={cn(
              "w-12 h-12 rounded-2xl flex items-center justify-center transition-all flex-shrink-0 shadow-lg",
              isListening
                ? "bg-red-500 text-white animate-pulse ring-4 ring-red-500/30"
                : "bg-cyan-600 hover:bg-cyan-500 text-white shadow-cyan-600/25 disabled:opacity-40"
            )}
            title={isListening ? "Listening... Tap to stop" : "Speak your question"}
          >
            {isListening ? <MicOff size={22} /> : <Mic size={22} />}
          </button>

          {/* Text Input Area */}
          <div className="flex-1 relative flex items-center">
            <input
              type="text"
              value={textInput}
              onChange={(e) => setTextInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleAskQuestion(textInput);
                }
              }}
              disabled={isThinking || !isSharing}
              placeholder={
                isListening 
                  ? (transcript || "Aap bol rahe hain...") 
                  : (isSharing ? "Screen ke baare mein kuch bhi poochein..." : "Pehle 'Screen Share Kholein' par click karein")
              }
              className="w-full bg-slate-800/90 border border-slate-700/80 rounded-2xl px-4 py-3 text-sm text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 disabled:opacity-50"
            />
            {textInput.trim() && (
              <button
                onClick={() => handleAskQuestion(textInput)}
                disabled={isThinking || !isSharing}
                className="absolute right-2 p-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl transition-all"
              >
                <Send size={16} />
              </button>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
