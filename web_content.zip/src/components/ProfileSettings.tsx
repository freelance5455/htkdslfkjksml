import React, { useState } from 'react';
import { UserProfile } from '../types';
import { StorageService } from '../services/storage';
import { TargetPaceCalculator } from './TargetPaceCalculator';
import {
  User,
  Settings,
  Shield,
  Download,
  Upload,
  Trash2,
  Save,
  CheckCircle,
  Calculator,
  Lock,
} from 'lucide-react';

interface ProfileSettingsProps {
  profile: UserProfile;
  onUpdateProfile: (updated: UserProfile) => void;
  onClearDemoData: () => void;
}

export const ProfileSettings: React.FC<ProfileSettingsProps> = ({
  profile,
  onUpdateProfile,
  onClearDemoData,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'profile' | 'calculator' | 'data'>('profile');
  const [formData, setFormData] = useState<UserProfile>(profile);
  const [showSavedFeedback, setShowSavedFeedback] = useState(false);
  const [gpsConsent, setGpsConsent] = useState(() => StorageService.getGPSConsent());

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    StorageService.saveProfile(formData);
    onUpdateProfile(formData);
    setShowSavedFeedback(true);
    setTimeout(() => setShowSavedFeedback(false), 2500);
  };

  const handleExportData = () => {
    const dataStr = StorageService.exportAllData();
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `jaat-runner-backup-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleImportData = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const success = StorageService.importAllData(content);
        if (success) {
          alert('Data imported successfully! Reloading...');
          window.location.reload();
        } else {
          alert('Failed to import backup file. Invalid format.');
        }
      }
    };
    reader.readAsText(file);
  };

  const handleToggleConsent = (val: boolean) => {
    setGpsConsent(val);
    StorageService.setGPSConsent(val);
  };

  return (
    <div className="space-y-4 pb-24">
      {/* Subtab Switcher */}
      <div className="flex bg-zinc-900 border border-zinc-800 rounded-2xl p-1 gap-1">
        <button
          onClick={() => setActiveSubTab('profile')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition ${
            activeSubTab === 'profile'
              ? 'bg-[#00FF66] text-black shadow-sm'
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          Athlete Profile
        </button>
        <button
          onClick={() => setActiveSubTab('calculator')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition ${
            activeSubTab === 'calculator'
              ? 'bg-[#00FF66] text-black shadow-sm'
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          Pace Calculator
        </button>
        <button
          onClick={() => setActiveSubTab('data')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition ${
            activeSubTab === 'data'
              ? 'bg-[#00FF66] text-black shadow-sm'
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          Data & Privacy
        </button>
      </div>

      {/* Profile Form */}
      {activeSubTab === 'profile' && (
        <form onSubmit={handleSaveProfile} className="space-y-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 shadow-xl space-y-3">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
              <h2 className="font-athletic text-base font-extrabold uppercase text-white">
                Runner Biometrics & Goal
              </h2>
              {showSavedFeedback && (
                <span className="text-xs text-[#00FF66] font-bold flex items-center gap-1">
                  <CheckCircle className="w-3.5 h-3.5" /> Saved!
                </span>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-zinc-400 block mb-1">Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-black border border-zinc-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-[#00FF66]"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-zinc-400 block mb-1">Age</label>
                <input
                  type="number"
                  value={Number.isNaN(formData.age) || formData.age === 0 ? '' : formData.age}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    setFormData({ ...formData, age: Number.isNaN(val) ? 0 : val });
                  }}
                  className="w-full bg-black border border-zinc-700 rounded-xl px-3 py-2 text-sm text-white"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-zinc-400 block mb-1">Height (cm)</label>
                <input
                  type="number"
                  value={Number.isNaN(formData.heightCm) || formData.heightCm === 0 ? '' : formData.heightCm}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    setFormData({ ...formData, heightCm: Number.isNaN(val) ? 0 : val });
                  }}
                  className="w-full bg-black border border-zinc-700 rounded-xl px-3 py-2 text-sm text-white"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-zinc-400 block mb-1">Weight (kg)</label>
                <input
                  type="number"
                  value={Number.isNaN(formData.weightKg) || formData.weightKg === 0 ? '' : formData.weightKg}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    setFormData({ ...formData, weightKg: Number.isNaN(val) ? 0 : val });
                  }}
                  className="w-full bg-black border border-zinc-700 rounded-xl px-3 py-2 text-sm text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <div>
                <label className="text-xs font-medium text-zinc-400 block mb-1">
                  Baseline 1600m PB
                </label>
                <input
                  type="text"
                  value={formData.currentPb1600m}
                  onChange={(e) => setFormData({ ...formData, currentPb1600m: e.target.value })}
                  placeholder="e.g. 5:30"
                  className="w-full bg-black border border-zinc-700 rounded-xl px-3 py-2 text-sm text-white font-mono-numbers"
                />
                <span className="text-[10px] text-amber-400 font-semibold block mt-1">
                  {formData.isBaselineVerified ? '✓ Verified in Time Trial' : '⚠ Baseline Unverified'}
                </span>
              </div>

              <div>
                <label className="text-xs font-medium text-zinc-400 block mb-1">
                  1600m Target Finish
                </label>
                <input
                  type="text"
                  value={formData.target1600m}
                  onChange={(e) => setFormData({ ...formData, target1600m: e.target.value })}
                  className="w-full bg-black border border-[#00FF66]/50 rounded-xl px-3 py-2 text-sm text-[#00FF66] font-mono-numbers font-bold"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <div>
                <label className="text-xs font-medium text-zinc-400 block mb-1">
                  Weekly Volume Target (KM)
                </label>
                <input
                  type="number"
                  value={Number.isNaN(formData.weeklyVolumeKm) || formData.weeklyVolumeKm === 0 ? '' : formData.weeklyVolumeKm}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    setFormData({ ...formData, weeklyVolumeKm: Number.isNaN(val) ? 0 : val });
                  }}
                  className="w-full bg-black border border-zinc-700 rounded-xl px-3 py-2 text-sm text-white"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-zinc-400 block mb-1">
                  Training Days / Week
                </label>
                <select
                  value={formData.trainingDaysPerWeek}
                  onChange={(e) =>
                    setFormData({ ...formData, trainingDaysPerWeek: parseInt(e.target.value) })
                  }
                  className="w-full bg-black border border-zinc-700 rounded-xl px-3 py-2 text-sm text-white"
                >
                  <option value={4}>4 Days</option>
                  <option value={5}>5 Days</option>
                  <option value={6}>6 Days</option>
                  <option value={7}>7 Days (Pro)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <div>
                <label className="text-xs font-medium text-zinc-400 block mb-1">
                  Coach Language
                </label>
                <select
                  value={formData.preferredLanguage}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      preferredLanguage: e.target.value as 'Hinglish' | 'Hindi' | 'English',
                    })
                  }
                  className="w-full bg-black border border-zinc-700 rounded-xl px-3 py-2 text-sm text-white"
                >
                  <option value="Hinglish">Hinglish (Recommended)</option>
                  <option value="Hindi">Hindi (हिन्दी)</option>
                  <option value="English">English</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-medium text-zinc-400 block mb-1">
                  Training Time
                </label>
                <select
                  value={formData.preferredTime}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      preferredTime: e.target.value as 'Morning' | 'Evening',
                    })
                  }
                  className="w-full bg-black border border-zinc-700 rounded-xl px-3 py-2 text-sm text-white"
                >
                  <option value="Morning">Early Morning (05:30 - 07:30)</option>
                  <option value="Evening">Evening (17:00 - 19:00)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-xs font-medium text-zinc-400 block mb-1">
                Current Injuries or Medical Limitations
              </label>
              <input
                type="text"
                value={formData.currentInjuries}
                onChange={(e) => setFormData({ ...formData, currentInjuries: e.target.value })}
                placeholder="e.g. slight right shin tightness, none"
                className="w-full bg-black border border-zinc-700 rounded-xl px-3 py-2 text-sm text-white"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 rounded-xl bg-[#00FF66] text-black font-athletic font-black text-sm uppercase tracking-wide flex items-center justify-center gap-2 hover:bg-[#10B981] transition shadow-md glow-neon-sm"
          >
            <Save className="w-4 h-4" />
            <span>Save Profile Updates</span>
          </button>
        </form>
      )}

      {/* Target Pace Calculator Tab */}
      {activeSubTab === 'calculator' && (
        <TargetPaceCalculator
          initialTarget={formData.target1600m}
          baselinePb={formData.currentPb1600m}
        />
      )}

      {/* Data & Privacy Tab */}
      {activeSubTab === 'data' && (
        <div className="space-y-4">
          {/* GPS Privacy Card */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 shadow-xl space-y-3">
            <div className="flex items-center gap-2 text-white">
              <Shield className="w-5 h-5 text-[#00FF66]" />
              <h2 className="font-athletic text-base font-extrabold uppercase">
                GPS Location & Privacy Consent
              </h2>
            </div>
            <p className="text-xs text-zinc-400 leading-relaxed">
              JAAT RUNNER uses device GPS purely for real-time running telemetry (distance, pace, lap splits, and route rendering). Your location data remains stored locally on your device and is never sold or tracked in background without your active run session.
            </p>
            <label className="flex items-center gap-2.5 text-xs text-zinc-300 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={gpsConsent}
                onChange={(e) => handleToggleConsent(e.target.checked)}
                className="w-4 h-4 accent-[#00FF66] rounded cursor-pointer"
              />
              <span>I consent to device GPS tracking during active running workouts</span>
            </label>
          </div>

          {/* Backup & Export Card */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 shadow-xl space-y-3">
            <h3 className="font-athletic text-sm uppercase tracking-wider font-bold text-white">
              Data Backup & Transfer
            </h3>
            <p className="text-xs text-zinc-400">
              Export your workout logs, 1600m personal records, and coach training history to JSON, or restore on a new device.
            </p>

            <div className="flex gap-2 pt-1">
              <button
                onClick={handleExportData}
                className="flex-1 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs uppercase flex items-center justify-center gap-1.5 transition"
              >
                <Download className="w-4 h-4 text-[#00FF66]" />
                <span>Export JSON</span>
              </button>

              <label className="flex-1 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs uppercase flex items-center justify-center gap-1.5 cursor-pointer transition">
                <Upload className="w-4 h-4 text-cyan-400" />
                <span>Import JSON</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImportData}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {/* Clear Demo Workouts */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 shadow-xl space-y-2">
            <h3 className="font-athletic text-sm uppercase tracking-wider font-bold text-white">
              Manage Demo Data
            </h3>
            <p className="text-xs text-zinc-400">
              Clear the preloaded demonstration workouts once you have logged your own genuine runs.
            </p>
            <button
              onClick={() => {
                if (window.confirm('Remove demo workouts and keep only real recorded runs?')) {
                  onClearDemoData();
                  alert('Demo workouts cleared.');
                }
              }}
              className="py-2.5 px-4 rounded-xl bg-black border border-zinc-700 hover:border-zinc-500 text-zinc-300 text-xs font-semibold transition"
            >
              Clear Demo Workouts
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
