import { useEffect, useMemo, useRef, useState } from "react";
import {
  AudioLines,
  Check,
  CircleAlert,
  ClipboardPaste,
  Download,
  ImageDown,
  LoaderCircle,
  Trash2,
  X,
} from "lucide-react";
import { Toaster, toast } from "sonner";
import { cn } from "@/lib/utils";
import {
  detectPlatform,
  extractYoutubeId,
  looksLikeUrl,
  normalizeUrl,
  PLATFORM_LABEL,
  QUALITIES,
  youtubeThumbnail,
  type Platform,
  type Quality,
} from "@/lib/media/detect";
import { previewMediaFn, prepareMediaFn } from "@/lib/media/functions";
import {
  clearHistory,
  loadHistory,
  pushHistory,
  type HistoryItem,
} from "@/lib/media/history";
import { saveMediaFile } from "@/lib/media/save";

type Status = "idle" | "preview" | "preparing" | "saving" | "success" | "error";

const PLATFORM_HINTS: Platform[] = ["youtube", "tiktok", "instagram"];

function formatTime(at: number): string {
  try {
    return new Intl.DateTimeFormat("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
    }).format(new Date(at));
  } catch {
    return "";
  }
}

export function PuroApp() {
  const [url, setUrl] = useState("");
  const [quality, setQuality] = useState<Quality>("720p");
  const [audioOnly, setAudioOnly] = useState(false);
  const [status, setStatus] = useState<Status>("idle");
  const [message, setMessage] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [title, setTitle] = useState<string | null>(null);
  const [author, setAuthor] = useState<string | null>(null);
  const [thumbnail, setThumbnail] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [pasteHint, setPasteHint] = useState<string | null>(null);
  const [standalone, setStandalone] = useState(false);
  const installPromptRef = useRef<{ prompt: () => Promise<void> } | null>(null);

  const abortRef = useRef<AbortController | null>(null);
  const previewSeq = useRef(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const platform = useMemo(() => detectPlatform(url), [url]);
  const youtubeId = useMemo(
    () => (platform === "youtube" ? extractYoutubeId(url) : null),
    [platform, url],
  );
  const busy = status === "preparing" || status === "saving";

  useEffect(() => {
    setHistory(loadHistory());
    const standaloneMode =
      window.matchMedia("(display-mode: standalone)").matches ||
      Boolean((navigator as Navigator & { standalone?: boolean }).standalone);
    setStandalone(standaloneMode);

    const onInstallPrompt = (event: Event) => {
      event.preventDefault();
      const promptEvent = event as Event & { prompt: () => Promise<void> };
      installPromptRef.current = promptEvent;
    };
    window.addEventListener("beforeinstallprompt", onInstallPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onInstallPrompt);
  }, []);

  useEffect(() => {
    const trimmed = url.trim();
    if (!trimmed) {
      setTitle(null);
      setAuthor(null);
      setThumbnail(null);
      setMessage(null);
      if (status === "preview" || status === "error" || status === "success") {
        setStatus("idle");
      }
      return;
    }

    if (youtubeId) {
      setThumbnail(youtubeThumbnail(youtubeId));
    }

    if (!looksLikeUrl(trimmed) || !platform) {
      if (trimmed.length > 12) {
        setStatus("error");
        setMessage("Cole um link do YouTube, TikTok ou Instagram.");
      }
      return;
    }

    const seq = ++previewSeq.current;
    const handle = window.setTimeout(() => {
      void (async () => {
        try {
          const result = await previewMediaFn({
            data: { url: normalizeUrl(trimmed) },
          });
          if (seq !== previewSeq.current) return;
          if (result.ok) {
            setTitle(result.title);
            setAuthor(result.author ?? null);
            setThumbnail(result.thumbnail ?? (youtubeId ? youtubeThumbnail(youtubeId) : null));
            setMessage(null);
            setStatus((current) => (current === "saving" || current === "preparing" ? current : "preview"));
          } else if (status !== "saving" && status !== "preparing") {
            setMessage(result.message);
          }
        } catch {
          if (seq !== previewSeq.current) return;
        }
      })();
    }, 380);

    return () => window.clearTimeout(handle);
    // preview should re-run when the URL changes; busy status is read at resolve time
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [url, platform, youtubeId]);

  function selectQuality(next: Quality) {
    setQuality(next);
    setAudioOnly(false);
    if (status === "success" || status === "error") {
      setStatus(title ? "preview" : "idle");
      setMessage(null);
    }
  }

  function toggleAudio() {
    setAudioOnly((value) => !value);
    if (status === "success" || status === "error") {
      setStatus(title ? "preview" : "idle");
      setMessage(null);
    }
  }

  async function addChromeShortcut() {
    const promptEvent = installPromptRef.current;
    if (promptEvent) {
      await promptEvent.prompt();
      installPromptRef.current = null;
      toast.success("Atalho pronto no Chrome");
      return;
    }

    const appUrl = `${window.location.origin}/`;
    try {
      await navigator.clipboard.writeText(appUrl);
    } catch {
      // clipboard may be blocked in an iframe
    }

    const opened = window.open(appUrl, "_blank", "noopener,noreferrer");
    toast.message(
      opened
        ? "Abra a aba nova no Chrome → menu ⋮ → Adicionar à tela inicial."
        : "No Chrome: menu ⋮ → Adicionar à tela inicial / Criar atalho.",
    );
  }

  async function handlePaste() {
    try {
      const text = await navigator.clipboard.readText();
      if (!text.trim()) {
        setPasteHint("A área de transferência está vazia.");
        return;
      }
      setUrl(text.trim());
      setPasteHint(null);
      inputRef.current?.focus();
    } catch {
      setPasteHint("Toque no campo e cole o link.");
      inputRef.current?.focus();
    }
  }

  function cancelInFlight() {
    abortRef.current?.abort();
    abortRef.current = null;
    setStatus(title ? "preview" : "idle");
    setProgress(0);
    setMessage(null);
  }

  async function runDownload(mode: "download" | "gallery") {
    const trimmed = url.trim();
    if (!trimmed) {
      setStatus("error");
      setMessage("Cole um link para começar.");
      inputRef.current?.focus();
      return;
    }
    if (!detectPlatform(trimmed)) {
      setStatus("error");
      setMessage("Cole um link do YouTube, TikTok ou Instagram.");
      return;
    }

    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    setStatus("preparing");
    setMessage(
      audioOnly ? "Preparando o MP3…" : "Preparando o vídeo sem marca d'água…",
    );
    setProgress(0);

    try {
      const prepared = await prepareMediaFn({
        data: {
          url: normalizeUrl(trimmed),
          quality,
          audioOnly,
        },
      });

      if (controller.signal.aborted) return;

      if (!prepared.ok) {
        setStatus("error");
        setMessage(prepared.message);
        toast.error(prepared.message);
        return;
      }

      setTitle(prepared.title);
      setAuthor(prepared.author ?? null);
      setThumbnail(prepared.thumbnail ?? null);
      setStatus("saving");
      setMessage(mode === "gallery" ? "Salvando na galeria…" : "Baixando arquivo…");

      const result = await saveMediaFile({
        sourceUrl: prepared.downloadUrl,
        filename: prepared.filename,
        mime: prepared.mime,
        mode,
        signal: controller.signal,
        onProgress: (info) => setProgress(info.ratio),
      });

      if (controller.signal.aborted) return;

      setProgress(1);
      setStatus("success");
      const successText =
        result === "shared"
          ? "Pronto. Escolha Salvar vídeo na folha de compartilhamento."
          : mode === "gallery"
            ? "Arquivo baixado. Abra na galeria para guardar."
            : audioOnly
              ? "MP3 salvo no dispositivo."
              : "Vídeo salvo no dispositivo.";
      setMessage(successText);
      toast.success(audioOnly ? "Áudio pronto" : "Download concluído");

      setHistory((items) =>
        pushHistory(items, {
          url: normalizeUrl(trimmed),
          title: prepared.title,
          platform: prepared.platform,
          thumbnail: prepared.thumbnail,
          filename: prepared.filename,
          audioOnly: prepared.audioOnly,
          quality: prepared.quality,
        }),
      );
    } catch (error) {
      if (controller.signal.aborted) return;
      const failed =
        error instanceof Error && error.name === "AbortError"
          ? "Download cancelado."
          : "Falha ao salvar o arquivo. Tente de novo.";
      setStatus("error");
      setMessage(failed);
      toast.error(failed);
    } finally {
      if (abortRef.current === controller) abortRef.current = null;
    }
  }

  function reuseItem(item: HistoryItem) {
    setUrl(item.url);
    setQuality(item.quality);
    setAudioOnly(item.audioOnly);
    setTitle(item.title);
    setThumbnail(item.thumbnail ?? null);
    setStatus("preview");
    setMessage(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  const showPreview = Boolean(platform && (thumbnail || title));

  return (
    <main className="puro-shell mx-auto flex min-h-dvh w-full max-w-md flex-col">
      <Toaster
        theme="dark"
        position="top-center"
        duration={2800}
        toastOptions={{
          className:
            "!bg-elevated !text-fg !border !border-border !shadow-none !rounded-md",
        }}
      />

      <header className="puro-enter flex items-end justify-between gap-4">
        <div>
          <p className="font-display text-xs font-medium tracking-[0.28em] text-subtle uppercase">
            downloader
          </p>
          <h1 className="mt-1 font-display text-4xl font-semibold tracking-tight text-fg">
            puro
          </h1>
        </div>
        {standalone ? (
          <div className="mb-1 flex size-11 items-center justify-center rounded-lg bg-elevated shadow-[var(--shadow-border)]">
            <span className="relative block size-4 rounded-full border-2 border-fg">
              <span className="absolute inset-[5px] rounded-full bg-fg" />
            </span>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => void addChromeShortcut()}
            aria-label="Adicionar atalho no Chrome"
            title="Adicionar atalho no Chrome"
            className="mb-1 flex size-11 items-center justify-center rounded-lg bg-elevated shadow-[var(--shadow-border)] transition-transform duration-150 active:scale-[0.96]"
          >
            <span className="relative block size-4 rounded-full border-2 border-fg">
              <span className="absolute inset-[5px] rounded-full bg-fg" />
            </span>
          </button>
        )}
      </header>

      <p className="puro-enter puro-enter-delay-1 mt-3 max-w-[34ch] text-sm leading-relaxed text-muted">
        Cole um link do YouTube, TikTok ou Instagram. Vídeo sem marca d'água,
        ou só o áudio em MP3.
      </p>

      <form
        className="mt-6 flex flex-col gap-5"
        onSubmit={(event) => {
          event.preventDefault();
          void runDownload("download");
        }}
      >
        <div className="puro-enter puro-enter-delay-2">
          <label htmlFor="puro-url" className="mb-2 block text-xs font-medium tracking-wide text-subtle">
            Link
          </label>
          <div className="flex gap-2 rounded-xl bg-surface p-2 shadow-[var(--shadow-border)]">
            <input
              ref={inputRef}
              id="puro-url"
              name="url"
              type="url"
              inputMode="url"
              autoCapitalize="off"
              autoCorrect="off"
              autoComplete="off"
              spellCheck={false}
              placeholder="Cole o link aqui"
              value={url}
              onChange={(event) => {
                setUrl(event.target.value);
                setPasteHint(null);
                if (status === "success" || status === "error") {
                  setStatus("idle");
                  setMessage(null);
                }
              }}
              className={cn(
                "min-h-12 min-w-0 flex-1 rounded-md bg-transparent px-3 text-base text-fg",
                "placeholder:text-subtle outline-none",
              )}
            />
            {url ? (
              <button
                type="button"
                aria-label="Limpar link"
                onClick={() => {
                  setUrl("");
                  setPasteHint(null);
                  inputRef.current?.focus();
                }}
                className="flex size-12 shrink-0 items-center justify-center rounded-md text-muted transition-colors duration-150 hover:bg-elevated hover:text-fg active:scale-[0.96]"
              >
                <X className="size-4" strokeWidth={1.75} />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => void handlePaste()}
                className="flex min-h-12 shrink-0 items-center gap-1.5 rounded-md bg-elevated px-3.5 text-sm font-medium text-fg transition-transform duration-150 active:scale-[0.96]"
              >
                <ClipboardPaste className="size-4" strokeWidth={1.75} />
                Colar
              </button>
            )}
          </div>
          {pasteHint ? (
            <p className="mt-2 text-xs text-muted">{pasteHint}</p>
          ) : null}

          <div className="mt-3 flex gap-2">
            {PLATFORM_HINTS.map((item) => {
              const active = platform === item;
              return (
                <span
                  key={item}
                  className={cn(
                    "inline-flex min-h-8 items-center rounded-full px-3 text-xs font-medium transition-colors duration-150",
                    active
                      ? "bg-accent text-accent-fg"
                      : "bg-elevated text-subtle",
                  )}
                >
                  {PLATFORM_LABEL[item]}
                </span>
              );
            })}
          </div>
        </div>

        {showPreview ? (
          <section className="overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]">
            <div className="relative aspect-video bg-elevated">
              {thumbnail ? (
                <img
                  src={thumbnail}
                  alt=""
                  className="size-full object-cover outline outline-1 -outline-offset-1 outline-fg/10"
                />
              ) : (
                <div className="puro-shimmer size-full" />
              )}
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg/90 to-transparent p-4 pt-10">
                <p className="text-[11px] font-medium tracking-wide text-muted uppercase">
                  {platform ? PLATFORM_LABEL[platform] : ""}
                  {audioOnly ? " · MP3" : ` · ${quality}`}
                </p>
                <p className="mt-1 line-clamp-2 text-sm font-medium text-fg">
                  {title || "Prévia do vídeo"}
                </p>
                {author ? (
                  <p className="mt-0.5 truncate text-xs text-subtle">{author}</p>
                ) : null}
              </div>
            </div>
          </section>
        ) : null}

        <fieldset className="puro-enter puro-enter-delay-3 min-w-0">
          <legend className="mb-2 text-xs font-medium tracking-wide text-subtle">
            Qualidade
          </legend>
          <div
            role="radiogroup"
            aria-label="Qualidade do vídeo"
            className="grid grid-cols-3 gap-2"
          >
            {QUALITIES.map((option) => {
              const selected = !audioOnly && quality === option;
              return (
                <button
                  key={option}
                  type="button"
                  role="radio"
                  aria-checked={selected}
                  onClick={() => selectQuality(option)}
                  className={cn(
                    "min-h-12 rounded-md text-sm font-medium select-none",
                    "transition-[background-color,color,transform,opacity] duration-150 ease-out",
                    "active:scale-[0.96] touch-manipulation",
                    selected
                      ? "bg-accent text-accent-fg"
                      : "bg-elevated text-muted",
                    audioOnly && "opacity-50",
                  )}
                >
                  {option}
                </button>
              );
            })}
          </div>
          <p className="mt-2 text-xs leading-relaxed text-subtle">
            Se a qualidade não existir no original, o Puro baixa a melhor disponível.
          </p>
        </fieldset>

        <button
          type="button"
          aria-pressed={audioOnly}
          onClick={toggleAudio}
          className={cn(
            "flex min-h-12 w-full items-center justify-between rounded-xl px-4 text-left select-none",
            "shadow-[var(--shadow-border)] transition-[background-color,transform] duration-150 ease-out",
            "active:scale-[0.98] touch-manipulation",
            audioOnly ? "bg-accent text-accent-fg" : "bg-surface text-fg",
          )}
        >
          <span className="flex items-center gap-3">
            <AudioLines className="size-4" strokeWidth={1.75} />
            <span className="text-sm font-medium">Só áudio (MP3)</span>
          </span>
          <span
            className={cn(
              "relative h-6 w-11 rounded-full transition-colors duration-150",
              audioOnly ? "bg-accent-fg/20" : "bg-elevated",
            )}
          >
            <span
              className={cn(
                "absolute top-0.5 left-0.5 size-5 rounded-full bg-fg transition-transform duration-150 ease-out",
                audioOnly && "translate-x-5 bg-accent-fg",
              )}
            />
          </span>
        </button>

        <div className="flex flex-col gap-2">
          <button
            type="submit"
            disabled={busy}
            className={cn(
              "flex min-h-14 w-full items-center justify-center gap-2 rounded-xl bg-accent px-4",
              "text-sm font-semibold text-accent-fg select-none touch-manipulation",
              "transition-transform duration-150 ease-out active:scale-[0.98]",
              "disabled:opacity-60",
            )}
          >
            {busy && !audioOnly ? (
              <LoaderCircle className="size-4 animate-spin" strokeWidth={1.75} />
            ) : (
              <Download className="size-4" strokeWidth={1.75} />
            )}
            {audioOnly ? "Baixar MP3" : "Baixar vídeo"}
          </button>
          <button
            type="button"
            disabled={busy}
            onClick={() => void runDownload("gallery")}
            className={cn(
              "flex min-h-14 w-full items-center justify-center gap-2 rounded-xl bg-surface px-4",
              "text-sm font-medium text-fg shadow-[var(--shadow-border)] select-none touch-manipulation",
              "transition-transform duration-150 ease-out active:scale-[0.98]",
              "disabled:opacity-60",
            )}
          >
            {busy ? (
              <LoaderCircle className="size-4 animate-spin" strokeWidth={1.75} />
            ) : (
              <ImageDown className="size-4" strokeWidth={1.75} />
            )}
            Salvar na galeria
          </button>
        </div>
      </form>

      {status !== "idle" && message ? (
        <div
          role="status"
          aria-live="polite"
          className={cn(
            "mt-5 rounded-xl px-4 py-3 shadow-[var(--shadow-border)]",
            status === "error" && "bg-surface",
            status === "success" && "bg-surface",
            (status === "preparing" || status === "saving") && "bg-surface",
            status === "preview" && "hidden",
          )}
        >
          <div className="flex items-start gap-3">
            {status === "error" ? (
              <CircleAlert className="mt-0.5 size-4 shrink-0 text-danger" strokeWidth={1.75} />
            ) : status === "success" ? (
              <Check className="mt-0.5 size-4 shrink-0 text-success" strokeWidth={1.75} />
            ) : (
              <LoaderCircle className="mt-0.5 size-4 shrink-0 animate-spin text-muted" strokeWidth={1.75} />
            )}
            <div className="min-w-0 flex-1">
              <p className="text-sm leading-relaxed text-fg">{message}</p>
              {status === "saving" || (status === "preparing" && progress > 0) ? (
                <div className="mt-3 h-1 overflow-hidden rounded-full bg-elevated">
                  <div
                    className="h-full rounded-full bg-accent transition-[width] duration-150 ease-out"
                    style={{ width: `${Math.max(6, Math.round(progress * 100))}%` }}
                  />
                </div>
              ) : null}
            </div>
            {busy ? (
              <button
                type="button"
                onClick={cancelInFlight}
                className="min-h-10 shrink-0 rounded-md px-2 text-xs font-medium text-muted"
              >
                Cancelar
              </button>
            ) : null}
          </div>
        </div>
      ) : null}

      <section className="mt-8 flex-1">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-medium tracking-wide text-subtle uppercase">
            Recentes
          </h2>
          {history.length > 0 ? (
            <button
              type="button"
              onClick={() => setHistory(clearHistory())}
              className="flex min-h-10 items-center gap-1.5 rounded-md px-2 text-xs font-medium text-subtle transition-colors duration-150 hover:text-fg"
            >
              <Trash2 className="size-3.5" strokeWidth={1.75} />
              Limpar
            </button>
          ) : null}
        </div>

        {history.length === 0 ? (
          <p className="mt-3 text-sm text-subtle">
            Seus downloads aparecem aqui, neste aparelho.
          </p>
        ) : (
          <ul className="mt-3 flex flex-col gap-2">
            {history.map((item) => (
              <li key={item.id}>
                <button
                  type="button"
                  onClick={() => reuseItem(item)}
                  className="flex min-h-14 w-full items-center gap-3 rounded-xl bg-surface p-2 pr-3 text-left shadow-[var(--shadow-border)] transition-transform duration-150 active:scale-[0.99]"
                >
                  <span className="relative size-12 shrink-0 overflow-hidden rounded-md bg-elevated">
                    {item.thumbnail ? (
                      <img
                        src={item.thumbnail}
                        alt=""
                        className="size-full object-cover"
                      />
                    ) : (
                      <span className="flex size-full items-center justify-center text-[10px] text-subtle">
                        {PLATFORM_LABEL[item.platform].slice(0, 2)}
                      </span>
                    )}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="line-clamp-1 text-sm font-medium text-fg">
                      {item.title}
                    </span>
                    <span className="mt-0.5 block text-xs text-subtle">
                      {PLATFORM_LABEL[item.platform]}
                      {" · "}
                      {item.audioOnly ? "MP3" : item.quality}
                      {" · "}
                      {formatTime(item.at)}
                    </span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>

      <p className="mt-10 text-center text-[11px] leading-relaxed text-subtle">
        Baixe só o que você tem direito de copiar. O Puro não guarda os arquivos
        na nuvem.
      </p>
    </main>
  );
}
