import { useMemo, useState, type ReactNode } from "react";
import {
  Check,
  Clipboard,
  Clock,
  Download,
  House,
  LoaderCircle,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { resolveMedia } from "@/lib/media/functions";
import { useHistory, type HistoryEntry } from "@/lib/media/history";
import {
  detectPlatform,
  platformLabel,
  unsupportedReason,
} from "@/lib/media/platforms";
import type { DownloadMode, MediaItem, Quality } from "@/lib/media/types";
import { cn } from "@/lib/utils";

type Tab = "home" | "recents";

function mediaSrc(item: MediaItem, download = false) {
  const params = new URLSearchParams({ t: item.token });
  if (download) params.set("dl", "1");
  return `/api/media?${params.toString()}`;
}

function formatDuration(seconds: number | null): string | null {
  if (!seconds || seconds <= 0) return null;
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export function PuroApp() {
  const [tab, setTab] = useState<Tab>("home");
  const [url, setUrl] = useState("");
  const [quality, setQuality] = useState<Quality>("720");
  const [busy, setBusy] = useState(false);
  const [saving, setSaving] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [item, setItem] = useState<MediaItem | null>(null);
  const [extras, setExtras] = useState<MediaItem[]>([]);
  const [saved, setSaved] = useState(false);

  const history = useHistory();
  const detected = url.trim() ? detectPlatform(url) : "unknown";

  async function openLink(source = url, mode: DownloadMode = "video") {
    const trimmed = source.trim();
    if (!trimmed) {
      setError("Cola o link do vídeo.");
      return;
    }
    const blocked = unsupportedReason(trimmed);
    if (blocked) {
      setError(blocked);
      return;
    }
    setBusy(true);
    setError(null);
    setSaved(false);
    setItem(null);
    setExtras([]);
    try {
      const result = await resolveMedia({
        data: { url: trimmed, mode, quality },
      });
      if (!result.ok) {
        setError(result.message);
        return;
      }
      setItem(result.item);
      setExtras(result.extras);
      setUrl(trimmed);
      history.remember({
        url: trimmed,
        title: result.item.title,
        platform: result.item.platform,
        thumbnail: result.item.thumbnail,
      });
    } catch {
      setError("Não deu pra abrir esse link agora. Tenta de novo.");
    } finally {
      setBusy(false);
    }
  }

  async function pasteFromClipboard() {
    try {
      const text = await navigator.clipboard.readText();
      if (!text.trim()) {
        toast("A área de transferência está vazia.");
        return;
      }
      setUrl(text.trim());
      setError(null);
    } catch {
      toast("Permite o acesso à área de transferência pra colar.");
    }
  }

  async function saveToGallery(target: MediaItem) {
    setSaving(true);
    setProgress(0);
    setSaved(false);
    try {
      const res = await fetch(mediaSrc(target, true));
      if (!res.ok) throw new Error("fail");
      const total = Number(res.headers.get("content-length") || 0);
      const reader = res.body?.getReader();
      const chunks: Uint8Array[] = [];
      let loaded = 0;
      if (reader) {
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          if (value) {
            chunks.push(value);
            loaded += value.byteLength;
            if (total) setProgress(loaded / total);
          }
        }
      } else {
        const buf = new Uint8Array(await res.arrayBuffer());
        chunks.push(buf);
        setProgress(1);
      }
      const blob = new Blob(chunks as BlobPart[], {
        type: target.mime || "video/mp4",
      });
      const file = new File([blob], target.filename, {
        type: blob.type || target.mime,
      });
      const nav = navigator as Navigator & {
        canShare?: (data: ShareData) => boolean;
      };
      if (typeof nav.canShare === "function" && nav.canShare({ files: [file] })) {
        await navigator.share({ files: [file], title: target.title });
        setSaved(true);
        return;
      }
      const href = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = href;
      a.download = target.filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(href), 4000);
      setSaved(true);
    } catch {
      toast("Não consegui salvar. Tenta de novo.");
    } finally {
      setSaving(false);
    }
  }

  function reset() {
    setItem(null);
    setExtras([]);
    setError(null);
    setSaved(false);
    setProgress(0);
    setUrl("");
  }

  function openRecent(entry: HistoryEntry) {
    setTab("home");
    setUrl(entry.url);
    void openLink(entry.url);
  }

  return (
    <div className="flex min-h-dvh items-stretch justify-center bg-bg md:items-center md:bg-frame md:p-6">
      <div
        className={cn(
          "relative flex w-full min-h-dvh flex-col overflow-hidden bg-bg",
          "md:h-app md:min-h-0 md:w-app md:rounded-device md:shadow-[var(--shadow-device)]",
        )}
      >
        <header className="flex items-center justify-between px-5 pb-3 pt-[max(1.25rem,env(safe-area-inset-top))]">
          <div>
            <p className="text-lg font-semibold tracking-tight">Puro</p>
            <p className="text-xs text-muted">Sem marca d'água</p>
          </div>
          {item ? (
            <Button variant="ghost" size="md" onClick={reset}>
              Novo
            </Button>
          ) : null}
        </header>

        <main className="flex min-h-0 flex-1 flex-col overflow-y-auto px-5 pb-4">
          {tab === "home" ? (
            <HomePane
              url={url}
              setUrl={setUrl}
              quality={quality}
              setQuality={setQuality}
              detected={detected}
              busy={busy}
              error={error}
              item={item}
              extras={extras}
              saving={saving}
              saved={saved}
              progress={progress}
              onPaste={pasteFromClipboard}
              onOpen={() => void openLink()}
              onAudio={() => void openLink(url, "audio")}
              onSave={(target) => void saveToGallery(target)}
            />
          ) : (
            <RecentsPane
              items={history.items}
              onOpen={openRecent}
              onRemove={history.remove}
              onClear={history.clear}
            />
          )}
        </main>

        <nav
          className={cn(
            "grid grid-cols-2 gap-1 border-t border-border bg-bg px-3 pt-2",
            "pb-[max(0.75rem,env(safe-area-inset-bottom))]",
          )}
        >
          <TabButton
            active={tab === "home"}
            icon={<House className="size-5" strokeWidth={1.75} />}
            label="Início"
            onClick={() => setTab("home")}
          />
          <TabButton
            active={tab === "recents"}
            icon={<Clock className="size-5" strokeWidth={1.75} />}
            label="Recentes"
            onClick={() => setTab("recents")}
          />
        </nav>
      </div>
    </div>
  );
}

function TabButton({
  active,
  icon,
  label,
  onClick,
}: {
  active: boolean;
  icon: ReactNode;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex h-12 flex-col items-center justify-center gap-0.5 rounded-md text-xs font-medium",
        active ? "text-fg" : "text-subtle",
      )}
    >
      {icon}
      {label}
    </button>
  );
}

function HomePane({
  url,
  setUrl,
  quality,
  setQuality,
  detected,
  busy,
  error,
  item,
  extras,
  saving,
  saved,
  progress,
  onPaste,
  onOpen,
  onAudio,
  onSave,
}: {
  url: string;
  setUrl: (value: string) => void;
  quality: Quality;
  setQuality: (value: Quality) => void;
  detected: ReturnType<typeof detectPlatform>;
  busy: boolean;
  error: string | null;
  item: MediaItem | null;
  extras: MediaItem[];
  saving: boolean;
  saved: boolean;
  progress: number;
  onPaste: () => void;
  onOpen: () => void;
  onAudio: () => void;
  onSave: (item: MediaItem) => void;
}) {
  if (item) {
    return (
      <ResultView
        item={item}
        extras={extras}
        saving={saving}
        saved={saved}
        progress={progress}
        onSave={onSave}
        onAudio={item.kind === "video" ? onAudio : undefined}
      />
    );
  }

  return (
    <div className="flex flex-1 flex-col">
      <div className="mt-4 space-y-2">
        <h1 className="text-3xl font-semibold leading-tight tracking-tight">
          Cola o link.
          <br />
          Salva na galeria.
        </h1>
        <p className="max-w-[18rem] text-sm leading-relaxed text-muted">
          YouTube, TikTok e Instagram. O arquivo vai limpo, sem marca da plataforma.
        </p>
      </div>

      <form
        className="mt-8 space-y-3"
        onSubmit={(event) => {
          event.preventDefault();
          onOpen();
        }}
      >
        <div className="relative">
          <Input
            value={url}
            onChange={(event) => setUrl(event.target.value)}
            placeholder="Cola o link do vídeo"
            inputMode="url"
            autoCapitalize="off"
            autoCorrect="off"
            spellCheck={false}
            aria-label="Link do vídeo"
            className="pr-12"
          />
          <button
            type="button"
            onClick={onPaste}
            className="absolute right-1.5 top-1.5 flex size-9 items-center justify-center rounded-md text-muted hover:text-fg"
            aria-label="Colar"
          >
            <Clipboard className="size-4" strokeWidth={1.75} />
          </button>
        </div>

        <div className="flex items-center justify-between gap-3">
          <p className="text-xs text-subtle">
            {detected === "unknown" ? "YouTube · TikTok · Instagram" : platformLabel(detected)}
          </p>
          <div className="flex rounded-md bg-surface-2 p-0.5">
            {(["1080", "720", "480"] as const).map((value) => (
              <button
                key={value}
                type="button"
                onClick={() => setQuality(value)}
                className={cn(
                  "h-8 rounded-sm px-2.5 text-xs font-medium",
                  quality === value ? "bg-surface text-fg" : "text-muted",
                )}
              >
                {value}
              </button>
            ))}
          </div>
        </div>

        {error ? (
          <p className="text-sm leading-relaxed text-danger" role="alert">
            {error}
          </p>
        ) : null}

        <Button type="submit" size="lg" className="w-full" disabled={busy}>
          {busy ? (
            <>
              <LoaderCircle className="size-4 animate-spin" />
              Abrindo
            </>
          ) : (
            "Abrir vídeo"
          )}
        </Button>
      </form>

      {busy ? <BusySkeleton /> : null}

      <ul className="mt-auto space-y-3 pt-10 text-xs leading-relaxed text-subtle">
        <li>O vídeo precisa ser público.</li>
        <li>No iPhone, escolhe Salvar Vídeo na folha que abrir.</li>
        <li>Uso pessoal. Respeita o autor do conteúdo.</li>
      </ul>
    </div>
  );
}

function BusySkeleton() {
  return (
    <div className="mt-6 overflow-hidden rounded-xl bg-surface">
      <div className="aspect-video animate-pulse bg-surface-2" />
      <div className="space-y-2 p-4">
        <div className="h-4 w-3/4 rounded-xs bg-surface-2" />
        <div className="h-3 w-1/3 rounded-xs bg-surface-2" />
      </div>
    </div>
  );
}

function ResultView({
  item,
  extras,
  saving,
  saved,
  progress,
  onSave,
  onAudio,
}: {
  item: MediaItem;
  extras: MediaItem[];
  saving: boolean;
  saved: boolean;
  progress: number;
  onSave: (item: MediaItem) => void;
  onAudio?: () => void;
}) {
  const duration = formatDuration(item.duration);
  const all = useMemo(() => [item, ...extras], [item, extras]);

  return (
    <div className="flex flex-1 flex-col gap-4">
      <div className="overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]">
        {item.kind === "photo" ? (
          <img
            src={item.thumbnail || mediaSrc(item)}
            alt=""
            className="aspect-[3/4] w-full object-cover"
            referrerPolicy="no-referrer"
          />
        ) : item.kind === "audio" ? (
          <div className="flex aspect-video items-center justify-center bg-surface-2 p-6">
            <audio src={mediaSrc(item)} controls className="w-full" />
          </div>
        ) : (
          <video
            src={mediaSrc(item)}
            poster={item.thumbnail ?? undefined}
            controls
            playsInline
            className="aspect-video max-h-80 w-full bg-surface-2 object-contain"
          />
        )}
        <div className="space-y-1 px-4 py-3">
          <p className="text-xs font-medium uppercase tracking-wide text-subtle">
            {platformLabel(item.platform)}
            {duration ? ` · ${duration}` : ""}
          </p>
          <h2 className="text-sm font-medium leading-snug">{item.title}</h2>
          {item.author ? <p className="text-xs text-muted">{item.author}</p> : null}
        </div>
      </div>

      <div className="space-y-2">
        <Button
          size="lg"
          className="w-full"
          onClick={() => onSave(item)}
          disabled={saving}
        >
          {saving ? (
            <>
              <LoaderCircle className="size-4 animate-spin" />
              Salvando {progress > 0 ? `${Math.round(progress * 100)}%` : ""}
            </>
          ) : saved ? (
            <>
              <Check className="size-4" />
              Salvo
            </>
          ) : (
            <>
              <Download className="size-4" />
              Salvar na galeria
            </>
          )}
        </Button>
        {onAudio ? (
          <Button variant="secondary" size="lg" className="w-full" onClick={onAudio}>
            Só o áudio
          </Button>
        ) : null}
        <p className="px-1 text-center text-xs leading-relaxed text-subtle">
          No iPhone e no Android, a folha de compartilhar deixa salvar direto na galeria.
        </p>
      </div>

      {all.length > 1 ? (
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted">Mais arquivos neste post</p>
          <div className="grid grid-cols-3 gap-2">
            {all.map((entry, index) => (
              <button
                key={`${entry.token}-${index}`}
                type="button"
                onClick={() => onSave(entry)}
                className="overflow-hidden rounded-md bg-surface-2"
              >
                {entry.thumbnail ? (
                  <img
                    src={entry.thumbnail}
                    alt=""
                    className="aspect-square w-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="flex aspect-square items-center justify-center text-xs text-muted">
                    {index + 1}
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>
      ) : null}
    </div>
  );
}

function RecentsPane({
  items,
  onOpen,
  onRemove,
  onClear,
}: {
  items: HistoryEntry[];
  onOpen: (entry: HistoryEntry) => void;
  onRemove: (id: string) => void;
  onClear: () => void;
}) {
  if (items.length === 0) {
    return (
      <div className="flex flex-1 flex-col items-start justify-center">
        <p className="text-lg font-medium">Nada ainda</p>
        <p className="mt-1 max-w-[16rem] text-sm leading-relaxed text-muted">
          Os vídeos que você abrir ficam aqui pra reabrir rápido.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">Recentes</h1>
        <Button variant="ghost" size="md" onClick={onClear}>
          Limpar
        </Button>
      </div>
      <ul className="space-y-2">
        {items.map((entry) => (
          <li
            key={entry.id}
            className="flex items-center gap-3 rounded-lg bg-surface p-2 shadow-[var(--shadow-border)]"
          >
            <button
              type="button"
              onClick={() => onOpen(entry)}
              className="flex min-w-0 flex-1 items-center gap-3 text-left"
            >
              <div className="size-12 shrink-0 overflow-hidden rounded-sm bg-surface-2">
                {entry.thumbnail ? (
                  <img
                    src={entry.thumbnail}
                    alt=""
                    className="size-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : null}
              </div>
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">{entry.title}</p>
                <p className="text-xs text-muted">{platformLabel(entry.platform)}</p>
              </div>
            </button>
            <button
              type="button"
              onClick={() => onRemove(entry.id)}
              className="flex size-10 items-center justify-center text-subtle hover:text-fg"
              aria-label="Remover"
            >
              <Trash2 className="size-4" strokeWidth={1.75} />
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
