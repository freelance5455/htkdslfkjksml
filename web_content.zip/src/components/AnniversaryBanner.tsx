import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { Heart, Sparkles, PartyPopper, Cake, Flame, Volume2, Star } from 'lucide-react';
import { LanguageCode } from '../types';
import { TRANSLATIONS } from '../translations';

interface AnniversaryBannerProps {
  language: LanguageCode;
}

export const AnniversaryBanner: React.FC<AnniversaryBannerProps> = ({ language }) => {
  const [celebrated, setCelebrated] = useState(false);
  const [clickCount, setClickCount] = useState(0);
  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const triggerAnniversaryCelebration = () => {
    setCelebrated(true);
    setClickCount(prev => prev + 1);

    // Multi-shot festive confetti & golden fireworks
    const duration = 2.5 * 1000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 9999 };

    function randomInRange(min: number, max: number) {
      return Math.random() * (max - min) + min;
    }

    const interval: any = setInterval(function () {
      const timeLeft = animationEnd - Date.now();
      if (timeLeft <= 0) {
        return clearInterval(interval);
      }
      const particleCount = 50 * (timeLeft / duration);
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 },
        colors: ['#ff007f', '#ffd700', '#00ffff', '#ff5722', '#ffffff', '#e040fb']
      });
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 },
        colors: ['#ff007f', '#ffd700', '#00ffff', '#ff5722', '#ffffff', '#e040fb']
      });
    }, 250);

    // Web Audio celebratory chime chords
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.value = freq;
        gain.gain.setValueAtTime(0.08, ctx.currentTime + idx * 0.12);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.12 + 0.8);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + idx * 0.12);
        osc.stop(ctx.currentTime + idx * 0.12 + 0.85);
      });
    } catch {
      // Audio context might be restricted before user gesture
    }
  };

  return (
    <div className="relative overflow-hidden rounded-2xl border border-pink-500/30 bg-gradient-to-r from-rose-950/40 via-purple-950/40 to-amber-950/40 p-4 shadow-lg mb-4 backdrop-blur-md">
      {/* Decorative RGB top bar */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-pink-500 via-yellow-400 to-cyan-400 animate-pulse" />

      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-pink-500 to-amber-400 flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(255,105,180,0.5)]">
            <Cake className="w-6 h-6 text-white animate-bounce" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-pink-500/20 text-pink-300 border border-pink-500/30">
                <Heart className="w-3 h-3 text-pink-400 fill-pink-400 animate-pulse" /> Special Celebration
              </span>
              {clickCount > 0 && (
                <span className="text-[10px] text-amber-300 font-medium">
                  🎊 {clickCount} Celebrations!
                </span>
              )}
            </div>
            <h3 className="text-sm sm:text-base font-bold text-white tracking-wide mt-0.5 flex items-center gap-1.5">
              <span>{t.anniversaryGreeting}</span>
            </h3>
            <p className="text-xs text-zinc-300/90 mt-0.5 line-clamp-2">
              {t.anniversarySub}
            </p>
          </div>
        </div>

        <div className="shrink-0 flex items-center gap-2 w-full sm:w-auto justify-end">
          <button
            onClick={triggerAnniversaryCelebration}
            className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-pink-500 via-rose-500 to-amber-500 hover:from-pink-400 hover:to-amber-400 text-white font-bold text-xs tracking-wide shadow-[0_0_20px_rgba(255,20,147,0.4)] hover:shadow-[0_0_25px_rgba(255,20,147,0.7)] active:scale-95 transition-all flex items-center justify-center gap-2"
          >
            <PartyPopper className="w-4 h-4" />
            <span>{t.anniversaryBtn}</span>
            <Sparkles className="w-3.5 h-3.5 text-yellow-200 animate-spin" />
          </button>
        </div>
      </div>
    </div>
  );
};
