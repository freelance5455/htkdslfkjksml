import React, { useState } from 'react';
import {
  X,
  Volume2,
  VolumeX,
  Plus,
  Copy,
  Trash2,
  RotateCcw,
  Play,
  Square,
  Circle,
  Sliders,
  LayoutGrid,
  FolderOpen,
} from 'lucide-react';
import type {
  BankId,
  GridArrangement,
  KitPreset,
  PadConfig,
  PadLayoutType,
  SidebarPosition,
  SidebarRotation,
} from '../types/octapad';

interface ProMixDrawerProps {
  isOpen: boolean;
  kit: KitPreset;
  allKits: KitPreset[];
  activeBank: BankId;
  sidebarPosition: SidebarPosition;
  sidebarRotation: SidebarRotation;
  bpm: number;
  metronomeOn: boolean;
  isRecordingLoop: boolean;
  isPlayingLoop: boolean;
  hasRecordedLoop: boolean;
  onClose: () => void;
  onSelectKit: (kitId: string) => void;
  onUpdateKit: (updater: (k: KitPreset) => KitPreset) => void;
  onUpdatePad: (padIndex: number, updater: (p: PadConfig) => PadConfig) => void;
  onChangeSidebarPosition: (pos: SidebarPosition) => void;
  onChangeSidebarRotation: (rot: SidebarRotation) => void;
  onCreateKit: (name: string, duplicateCurrent: boolean) => void;
  onDeleteKit: (kitId: string) => void;
  onResetBuiltInKit: (kitId: string) => void;
  onChangeBpm: (bpm: number) => void;
  onToggleMetronome: () => void;
  onToggleRecordLoop: () => void;
  onTogglePlayLoop: () => void;
  onClearLoop: () => void;
  onStopAllAudio: () => void;
  onAuditionPad: (padIndex: number) => void;
}

export const ProMixDrawer: React.FC<ProMixDrawerProps> = ({
  isOpen,
  kit,
  allKits,
  activeBank,
  sidebarPosition,
  sidebarRotation,
  bpm,
  metronomeOn,
  isRecordingLoop,
  isPlayingLoop,
  hasRecordedLoop,
  onClose,
  onSelectKit,
  onUpdateKit,
  onUpdatePad,
  onChangeSidebarPosition,
  onChangeSidebarRotation,
  onCreateKit,
  onDeleteKit,
  onResetBuiltInKit,
  onChangeBpm,
  onToggleMetronome,
  onToggleRecordLoop,
  onTogglePlayLoop,
  onClearLoop,
  onStopAllAudio,
  onAuditionPad,
}) => {
  const [tab, setTab] = useState<'mixer' | 'deck' | 'kits'>('mixer');
  const [newKitName, setNewKitName] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  if (!isOpen) return null;

  const pads = activeBank === 'A' ? kit.bankA : kit.bankB;

  const handleCreate = (duplicate: boolean) => {
    const trimmed = newKitName.trim() || `${kit.name} Copy`;
    onCreateKit(trimmed, duplicate);
    setNewKitName('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-[#11151C] text-slate-100 border border-slate-800 w-full sm:max-w-3xl max-h-[92vh] sm:rounded-2xl rounded-t-2xl flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between gap-4 px-5 py-4 border-b border-slate-800 shrink-0">
          <div className="min-w-0">
            <h2 className="font-display text-base sm:text-lg font-bold text-white truncate">
              MultiTrack ProMix · {kit.name} (Bank {activeBank})
            </h2>
            <p className="text-xs text-slate-400 mt-0.5 truncate">
              Per-pad mixer, loop transport, deck geometry &amp; kit presets
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={onStopAllAudio}
              className="min-h-[38px] px-3 py-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 text-xs font-semibold cursor-pointer"
            >
              Stop All
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close ProMix"
              className="min-h-[38px] min-w-[38px] rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="px-5 pt-3 flex items-center gap-4 border-b border-slate-800 shrink-0">
          <button
            type="button"
            onClick={() => setTab('mixer')}
            className={`pb-2.5 px-1 text-xs font-semibold border-b-2 flex items-center gap-1.5 cursor-pointer ${
              tab === 'mixer'
                ? 'border-[#10D2F2] text-[#10D2F2]'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Mixer &amp; Transport</span>
          </button>
          <button
            type="button"
            onClick={() => setTab('deck')}
            className={`pb-2.5 px-1 text-xs font-semibold border-b-2 flex items-center gap-1.5 cursor-pointer ${
              tab === 'deck'
                ? 'border-[#10D2F2] text-[#10D2F2]'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span>Deck &amp; Pads</span>
          </button>
          <button
            type="button"
            onClick={() => setTab('kits')}
            className={`pb-2.5 px-1 text-xs font-semibold border-b-2 flex items-center gap-1.5 cursor-pointer ${
              tab === 'kits'
                ? 'border-[#10D2F2] text-[#10D2F2]'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FolderOpen className="w-3.5 h-3.5" />
            <span>Kits ({allKits.length})</span>
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-6">
          {tab === 'mixer' && (
            <>
              {/* Transport & Metronome Bar */}
              <div className="p-4 rounded-xl bg-[#0B0E14] border border-slate-800 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-3 flex-wrap">
                  <button
                    type="button"
                    onClick={onToggleMetronome}
                    className={`min-h-[40px] px-3.5 py-2 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                      metronomeOn
                        ? 'bg-[#10D2F2] text-[#091117]'
                        : 'bg-[#1A1F29] text-slate-200 hover:bg-[#232A38]'
                    }`}
                  >
                    Metronome {metronomeOn ? 'ON' : 'OFF'}
                  </button>

                  <div className="flex items-center gap-2 bg-[#161A22] px-3 py-1.5 rounded-lg border border-slate-800">
                    <span className="text-[11px] text-slate-400">BPM</span>
                    <input
                      type="number"
                      min={50}
                      max={220}
                      value={bpm}
                      onChange={(e) =>
                        onChangeBpm(Math.max(50, Math.min(220, parseInt(e.target.value, 10) || 120)))
                      }
                      className="w-12 bg-transparent font-mono-tabular text-xs font-bold text-white text-center focus:outline-none"
                    />
                  </div>
                </div>

                {/* Live Loop Recorder */}
                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    type="button"
                    onClick={onToggleRecordLoop}
                    className={`min-h-[40px] px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                      isRecordingLoop
                        ? 'bg-rose-500 text-white'
                        : 'bg-[#1A1F29] hover:bg-[#232A38] text-slate-200'
                    }`}
                  >
                    <Circle className="w-3 h-3 fill-current" />
                    <span>{isRecordingLoop ? 'Stop Rec' : 'Record Loop'}</span>
                  </button>

                  <button
                    type="button"
                    disabled={!hasRecordedLoop || isRecordingLoop}
                    onClick={onTogglePlayLoop}
                    className={`min-h-[40px] px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-40 ${
                      isPlayingLoop
                        ? 'bg-emerald-400 text-slate-950'
                        : 'bg-[#1A1F29] hover:bg-[#232A38] text-slate-200'
                    }`}
                  >
                    {isPlayingLoop ? (
                      <Square className="w-3 h-3 fill-current" />
                    ) : (
                      <Play className="w-3 h-3 fill-current" />
                    )}
                    <span>{isPlayingLoop ? 'Stop Loop' : 'Play Loop'}</span>
                  </button>

                  {hasRecordedLoop && (
                    <button
                      type="button"
                      onClick={onClearLoop}
                      className="min-h-[40px] px-2.5 py-2 rounded-lg bg-[#1A1F29] hover:bg-rose-500/20 text-slate-400 hover:text-rose-300 text-xs font-medium cursor-pointer"
                    >
                      Clear
                    </button>
                  )}
                </div>
              </div>

              {/* Master Gain */}
              <div className="p-4 rounded-xl bg-[#161A22] border border-slate-800">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                    Master Output Gain
                  </span>
                  <span className="font-mono-tabular text-xs font-bold text-cyan-300">
                    {Math.round(kit.masterVolume * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1.2}
                  step={0.02}
                  value={kit.masterVolume}
                  onChange={(e) =>
                    onUpdateKit((k) => ({ ...k, masterVolume: parseFloat(e.target.value) }))
                  }
                  className="w-full accent-[#10D2F2]"
                />
              </div>

              {/* 8-Pad Channel Mixer */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {pads.map((pad) => {
                  const zone = pad.zones[0];
                  return (
                    <div
                      key={pad.index}
                      className="p-3 rounded-xl bg-[#161A22] border border-slate-800 flex flex-col gap-2.5"
                    >
                      <div className="flex items-center justify-between gap-1">
                        <button
                          type="button"
                          onClick={() => onAuditionPad(pad.index)}
                          className="font-mono-tabular text-[11px] font-bold px-2 py-0.5 rounded bg-[#0B0E14] text-cyan-300 hover:bg-cyan-400 hover:text-slate-950 transition-colors cursor-pointer"
                        >
                          P{pad.index + 1}
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            onUpdatePad(pad.index, (p) => ({
                              ...p,
                              zones: [
                                { ...p.zones[0], muted: !p.zones[0].muted },
                                p.zones[1],
                              ],
                            }))
                          }
                          aria-label={`Mute Pad ${pad.index + 1}`}
                          className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                            zone.muted
                              ? 'bg-rose-500/20 text-rose-400'
                              : 'bg-[#0B0E14] text-slate-400 hover:text-white'
                          }`}
                        >
                          {zone.muted ? (
                            <VolumeX className="w-3.5 h-3.5" />
                          ) : (
                            <Volume2 className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>

                      <p className="text-xs font-semibold text-white truncate">
                        {zone.label || zone.soundName}
                      </p>

                      <div>
                        <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                          <span>Level</span>
                          <span className="font-mono-tabular text-slate-200">
                            {Math.round(zone.volume * 100)}%
                          </span>
                        </div>
                        <input
                          type="range"
                          min={0}
                          max={1.2}
                          step={0.02}
                          value={zone.volume}
                          onChange={(e) => {
                            const vol = parseFloat(e.target.value);
                            onUpdatePad(pad.index, (p) => ({
                              ...p,
                              zones: [{ ...p.zones[0], volume: vol }, p.zones[1]],
                            }));
                          }}
                          className="w-full accent-[#10D2F2]"
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}

          {tab === 'deck' && (
            <div className="space-y-5">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                  Touch Surface Mode
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {(
                    [
                      {
                        id: 'grid',
                        title: '4×2 Hardware Grid',
                        desc: 'Classic symmetrical Octapad rubber pad matrix',
                      },
                      {
                        id: 'freeform',
                        title: 'Freeform Touch Zones',
                        desc: 'Move & resize each pad anywhere on the deck',
                      },
                    ] as Array<{ id: PadLayoutType; title: string; desc: string }>
                  ).map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => onUpdateKit((k) => ({ ...k, layoutType: opt.id }))}
                      className={`p-3.5 rounded-xl border text-left transition-colors cursor-pointer ${
                        kit.layoutType === opt.id
                          ? 'bg-cyan-400/15 border-cyan-400 text-white'
                          : 'bg-[#161A22] border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <p className="text-xs font-bold">{opt.title}</p>
                      <p className="text-[11px] text-slate-400 mt-1">{opt.desc}</p>
                    </button>
                  ))}
                </div>
              </div>

              {kit.layoutType === 'grid' && (
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                    Grid Arrangement
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {(
                      [
                        { id: 'auto', label: 'Auto (2×4 / 4×2)' },
                        { id: '2x4', label: '2×4 Tall Pads' },
                        { id: '4x2', label: '4×2 Wide Pads' },
                      ] as Array<{ id: GridArrangement; label: string }>
                    ).map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => onUpdateKit((k) => ({ ...k, gridArrangement: opt.id }))}
                        className={`py-2 px-2 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                          (kit.gridArrangement ?? 'auto') === opt.id
                            ? 'bg-[#10D2F2] text-[#091117]'
                            : 'bg-[#161A22] border border-slate-800 text-slate-300 hover:border-slate-700'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-[#161A22] border border-slate-800">
                  <div className="flex justify-between text-xs mb-2">
                    <span className="font-medium text-slate-300">Pad Gap Spacing</span>
                    <span className="font-mono-tabular text-cyan-300">{kit.padGap}px</span>
                  </div>
                  <input
                    type="range"
                    min={2}
                    max={22}
                    step={1}
                    value={kit.padGap}
                    onChange={(e) =>
                      onUpdateKit((k) => ({ ...k, padGap: parseInt(e.target.value, 10) }))
                    }
                    className="w-full accent-[#10D2F2]"
                  />
                </div>

                <div className="p-4 rounded-xl bg-[#161A22] border border-slate-800">
                  <div className="flex justify-between text-xs mb-2">
                    <span className="font-medium text-slate-300">Pad Corner Radius</span>
                    <span className="font-mono-tabular text-cyan-300">{kit.padRadius}px</span>
                  </div>
                  <input
                    type="range"
                    min={4}
                    max={24}
                    step={1}
                    value={kit.padRadius}
                    onChange={(e) =>
                      onUpdateKit((k) => ({ ...k, padRadius: parseInt(e.target.value, 10) }))
                    }
                    className="w-full accent-[#10D2F2]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => onUpdateKit((k) => ({ ...k, showLabels: !k.showLabels }))}
                  className="p-3.5 rounded-xl bg-[#161A22] border border-slate-800 flex items-center justify-between cursor-pointer"
                >
                  <div className="text-left">
                    <p className="text-xs font-bold text-white">Show Sound Labels on Pads</p>
                    <p className="text-[11px] text-slate-400">
                      Turn off for clean unmarked rubber pads
                    </p>
                  </div>
                  <span
                    className={`px-2.5 py-1 rounded text-[11px] font-bold ${
                      kit.showLabels
                        ? 'bg-[#10D2F2] text-[#091117]'
                        : 'bg-[#0B0E14] text-slate-400'
                    }`}
                  >
                    {kit.showLabels ? 'ON' : 'OFF'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => onUpdateKit((k) => ({ ...k, showKeyHints: !k.showKeyHints }))}
                  className="p-3.5 rounded-xl bg-[#161A22] border border-slate-800 flex items-center justify-between cursor-pointer"
                >
                  <div className="text-left">
                    <p className="text-xs font-bold text-white">Show Keyboard Triggers</p>
                    <p className="text-[11px] text-slate-400">
                      Display trigger keys (1–4, Q–R)
                    </p>
                  </div>
                  <span
                    className={`px-2.5 py-1 rounded text-[11px] font-bold ${
                      kit.showKeyHints
                        ? 'bg-[#10D2F2] text-[#091117]'
                        : 'bg-[#0B0E14] text-slate-400'
                    }`}
                  >
                    {kit.showKeyHints ? 'ON' : 'OFF'}
                  </span>
                </button>
              </div>

              {/* Control Sidebar Dock & Angle Rotation */}
              <div className="p-4 rounded-xl bg-[#161A22] border border-slate-800 space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                    Control Sidebar Position
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {(['right', 'bottom', 'left', 'top'] as SidebarPosition[]).map((pos) => (
                      <button
                        key={pos}
                        type="button"
                        onClick={() => onChangeSidebarPosition(pos)}
                        className={`py-2 rounded-lg text-xs font-bold capitalize transition-colors cursor-pointer ${
                          sidebarPosition === pos
                            ? 'bg-[#10D2F2] text-[#091117]'
                            : 'bg-[#0B0E14] text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        {pos}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                    Control Sidebar Rotation
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {(
                      [
                        { value: 0, label: '0° Normal' },
                        { value: 90, label: '90° CW' },
                        { value: -90, label: '90° CCW' },
                        { value: 180, label: '180° Flip' },
                      ] as Array<{ value: SidebarRotation; label: string }>
                    ).map((rot) => (
                      <button
                        key={rot.value}
                        type="button"
                        onClick={() => onChangeSidebarRotation(rot.value)}
                        className={`py-2 px-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer whitespace-nowrap ${
                          sidebarRotation === rot.value
                            ? 'bg-[#10D2F2] text-[#091117]'
                            : 'bg-[#0B0E14] text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        {rot.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {tab === 'kits' && (
            <div className="space-y-5">
              {/* Rename Current Kit */}
              <div className="p-4 rounded-xl bg-[#161A22] border border-slate-800 space-y-3">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                  Active Kit Name
                </label>
                <div className="flex flex-wrap items-center gap-2">
                  <input
                    type="text"
                    value={kit.name}
                    maxLength={28}
                    onChange={(e) =>
                      onUpdateKit((k) => ({ ...k, name: e.target.value.toUpperCase() }))
                    }
                    className="flex-1 min-w-[180px] px-3 py-2 rounded-lg bg-[#0B0E14] border border-slate-800 text-xs font-bold text-white focus:outline-none focus:border-cyan-400"
                  />
                  {kit.isBuiltIn && (
                    <button
                      type="button"
                      onClick={() => onResetBuiltInKit(kit.id)}
                      className="min-h-[38px] px-3 py-2 rounded-lg bg-[#0B0E14] hover:bg-slate-800 border border-slate-700 text-xs font-medium text-slate-300 flex items-center gap-1.5 cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Reset Factory</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Create / Duplicate Kit */}
              <div className="p-4 rounded-xl bg-[#161A22] border border-slate-800 space-y-3">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                  Create New Kit
                </label>
                <div className="flex flex-wrap items-center gap-2">
                  <input
                    type="text"
                    placeholder="e.g. MY GARBA KIT"
                    value={newKitName}
                    maxLength={28}
                    onChange={(e) => setNewKitName(e.target.value)}
                    className="flex-1 min-w-[180px] px-3 py-2 rounded-lg bg-[#0B0E14] border border-slate-800 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                  <button
                    type="button"
                    onClick={() => handleCreate(true)}
                    className="min-h-[38px] px-3.5 py-2 rounded-lg bg-[#10D2F2] hover:bg-cyan-300 text-[#091117] text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>Duplicate Current</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleCreate(false)}
                    className="min-h-[38px] px-3.5 py-2 rounded-lg bg-[#0B0E14] hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-white flex items-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Blank Kit</span>
                  </button>
                </div>
              </div>

              {/* Kit List */}
              <div className="space-y-2">
                {allKits.map((k) => {
                  const isActive = k.id === kit.id;
                  return (
                    <div
                      key={k.id}
                      className={`p-3 rounded-xl border flex items-center justify-between gap-3 ${
                        isActive
                          ? 'bg-cyan-400/10 border-cyan-400/60'
                          : 'bg-[#161A22] border-slate-800'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => onSelectKit(k.id)}
                        className="flex-1 min-w-0 text-left cursor-pointer"
                      >
                        <p className="text-xs font-bold text-white truncate">{k.name}</p>
                        <p className="text-[11px] text-slate-400 truncate">
                          {k.category} · {k.isBuiltIn ? 'Built-In Preset' : 'Custom Kit'}
                        </p>
                      </button>

                      {!k.isBuiltIn && (
                        <div className="shrink-0">
                          {confirmDeleteId === k.id ? (
                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => {
                                  onDeleteKit(k.id);
                                  setConfirmDeleteId(null);
                                }}
                                className="px-2.5 py-1 rounded bg-rose-500 text-white text-[11px] font-bold cursor-pointer"
                              >
                                Confirm
                              </button>
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteId(null)}
                                className="px-2 py-1 rounded bg-slate-800 text-slate-300 text-[11px] cursor-pointer"
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(k.id)}
                              aria-label={`Delete ${k.name}`}
                              className="p-1.5 rounded-md text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
