/**
 * HELENA - Veterinary Anatomical 3D Viewer (Three.js)
 * Clean real-model 3D viewer (GLTF / GLB / DRACO):
 * - Loads authentic 3D files (.glb / .gltf)
 * - Zero fake/procedural mock models: if file is not on disk, provides clear upload/import UI
 * - Multi-touch controls: 1-finger orbit, 2-finger pinch zoom, 2-finger pan, reset button
 * - Retractable anatomical parts drawer (isolated view & opacity dimming)
 * - PBR lighting, contact grounding shadow, and ACESFilmic tone mapping
 */

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { DRACOLoader } from 'three/examples/jsm/loaders/DRACOLoader.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { 
  RotateCcw, 
  Eye, 
  EyeOff, 
  Layers, 
  X, 
  Upload,
  Box,
  Sliders,
  Grid,
  Search,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { VeterinaryModelItem } from '../types';

interface Viewer3DProps {
  modelItem: VeterinaryModelItem;
  modelBlob?: Blob;
  modelUrl?: string;
  onClose: () => void;
}

interface AnatomicalPart {
  id: string;
  name: string;
  mesh: THREE.Mesh;
  visible: boolean;
  initialMaterial: THREE.Material | THREE.Material[];
}

export const Viewer3D: React.FC<Viewer3DProps> = ({
  modelItem,
  modelBlob,
  modelUrl,
  onClose,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [isWaitingFile, setIsWaitingFile] = useState(false);
  const [activeBlob, setActiveBlob] = useState<Blob | undefined>(modelBlob);

  // Anatomical parts state
  const [parts, setParts] = useState<AnatomicalPart[]>([]);
  const [selectedPartId, setSelectedPartId] = useState<string | null>(null);
  const [partSearch, setPartSearch] = useState('');
  const [isPartsDrawerOpen, setIsPartsDrawerOpen] = useState(false);

  // Visual modes
  const [isXRayMode, setIsXRayMode] = useState(false);
  const [isWireframe, setIsWireframe] = useState(false);
  const [showTouchHint, setShowTouchHint] = useState(true);

  // References for scene & controls
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const loadedModelGroupRef = useRef<THREE.Group | null>(null);
  const initialCamPosRef = useRef<THREE.Vector3>(new THREE.Vector3(2.5, 2.0, 3.5));
  const initialTargetRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 0, 0));

  // Fade touch hint after 4s
  useEffect(() => {
    const timer = setTimeout(() => setShowTouchHint(false), 4000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Detect software WebGL for mobile performance pacing
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 1. Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x000000);

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.copy(initialCamPosRef.current);
    cameraRef.current = camera;

    // 3. Renderer with physical tone mapping and adaptive pixel ratio
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: isSoftwareGl ? 'low-power' : 'high-performance',
      alpha: false,
    });
    renderer.setPixelRatio(isSoftwareGl ? 1.0 : Math.min(window.devicePixelRatio || 1, 1.5));
    renderer.setSize(width, height);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    // 4. Lighting & Environment
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    pmremGenerator.compileEquirectangularShader();
    const envTexture = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTexture;
    pmremGenerator.dispose();

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.9);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xfffaed, 2.2);
    dirLight1.position.set(5, 10, 7);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x2FD16F, 0.7);
    dirLight2.position.set(-6, -4, -5);
    scene.add(dirLight2);

    const dirLight3 = new THREE.DirectionalLight(0xb0d8ff, 1.2);
    dirLight3.position.set(-4, 8, -6);
    scene.add(dirLight3);

    // Grounding shadow
    const shadowGeo = new THREE.PlaneGeometry(3.5, 3.5);
    const shadowMat = new THREE.MeshBasicMaterial({
      color: 0x031206,
      transparent: true,
      opacity: 0.6,
      depthWrite: false,
    });
    const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.y = -1.2;
    scene.add(shadowMesh);

    // 5. OrbitControls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.06;
    controls.maxDistance = 15;
    controls.minDistance = 0.6;
    controls.touches = {
      ONE: THREE.TOUCH.ROTATE,
      TWO: THREE.TOUCH.DOLLY_PAN,
    };
    controlsRef.current = controls;

    // Helper: Traverse and extract parts
    const extractPartsFromGroup = (group: THREE.Group) => {
      const collectedParts: AnatomicalPart[] = [];
      let partIndex = 1;

      group.traverse((child) => {
        if ((child as THREE.Mesh).isMesh) {
          const mesh = child as THREE.Mesh;
          if (Array.isArray(mesh.material)) {
            mesh.material = mesh.material.map(m => m.clone());
          } else if (mesh.material) {
            mesh.material = mesh.material.clone();
          }

          const rawName = mesh.name || `Parte_${partIndex}`;
          const formattedName = rawName.replace(/_/g, ' ').replace(/^(Mesh|Node|Group)/i, 'Estrutura').trim();

          collectedParts.push({
            id: `part_${partIndex}`,
            name: formattedName.length > 2 ? formattedName : `Estrutura ${partIndex}`,
            mesh,
            visible: true,
            initialMaterial: mesh.material,
          });
          partIndex++;
        }
      });

      setParts(collectedParts);
      setLoading(false);
      setIsWaitingFile(false);
      setLoadError(null);
    };

    const attachModelToScene = (modelGroup: THREE.Group) => {
      loadedModelGroupRef.current = modelGroup;

      const bbox = new THREE.Box3().setFromObject(modelGroup);
      const center = bbox.getCenter(new THREE.Vector3());
      const size = bbox.getSize(new THREE.Vector3());

      modelGroup.position.sub(center);

      const maxDim = Math.max(size.x, size.y, size.z);
      if (maxDim > 0) {
        const scaleFactor = 2.4 / maxDim;
        modelGroup.scale.set(scaleFactor, scaleFactor, scaleFactor);
      }

      scene.add(modelGroup);
      extractPartsFromGroup(modelGroup);
    };

    // Load actual GLTF / GLB file
    const loader = new GLTFLoader();
    const dracoLoader = new DRACOLoader();
    dracoLoader.setDecoderPath('https://www.gstatic.com/draco/versioned/decoders/1.5.7/');
    loader.setDRACOLoader(dracoLoader);

    let objectUrl: string | null = null;
    let targetSrc = modelUrl || modelItem.arquivo;

    if (activeBlob) {
      objectUrl = URL.createObjectURL(activeBlob);
      targetSrc = objectUrl;
    }

    setLoading(true);
    setIsWaitingFile(false);

    loader.load(
      targetSrc,
      (gltf) => {
        attachModelToScene(gltf.scene);
      },
      undefined,
      (err) => {
        console.warn('Arquivo 3D não encontrado no servidor:', targetSrc, err);
        setLoading(false);
        setIsWaitingFile(true);
        setLoadError(`O arquivo 3D real (${modelItem.arquivo}) ainda não foi enviado para a pasta /public/models/.`);
      }
    );

    // Animation loop
    let animationFrameId: number;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
      dracoLoader.dispose();
      renderer.dispose();
      if (objectUrl) URL.revokeObjectURL(objectUrl);
      if (container && renderer.domElement) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [modelItem, activeBlob, modelUrl]);

  // Handle part highlight / X-ray / wireframe
  useEffect(() => {
    parts.forEach((p) => {
      const mesh = p.mesh;
      const materials = Array.isArray(mesh.material) ? mesh.material : [mesh.material];

      materials.forEach((m) => {
        if (m instanceof THREE.MeshStandardMaterial) {
          m.wireframe = isWireframe;

          if (selectedPartId) {
            if (p.id === selectedPartId) {
              m.transparent = false;
              m.opacity = 1.0;
              m.emissive = new THREE.Color(0x17B35A);
              m.emissiveIntensity = 0.55;
            } else {
              m.transparent = true;
              m.opacity = 0.18;
              m.emissive = new THREE.Color(0x000000);
            }
          } else if (isXRayMode) {
            m.transparent = true;
            m.opacity = 0.35;
            m.emissive = new THREE.Color(0x0E7A3D);
            m.emissiveIntensity = 0.2;
          } else {
            m.transparent = false;
            m.opacity = 1.0;
            m.emissive = new THREE.Color(0x000000);
            m.emissiveIntensity = 0.0;
          }
        }
      });
    });
  }, [selectedPartId, isXRayMode, isWireframe, parts]);

  const togglePartVisibility = (partId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setParts((prev) =>
      prev.map((p) => {
        if (p.id === partId) {
          const nextVis = !p.visible;
          p.mesh.visible = nextVis;
          return { ...p, visible: nextVis };
        }
        return p;
      })
    );
  };

  const handleResetView = () => {
    if (controlsRef.current && cameraRef.current) {
      cameraRef.current.position.copy(initialCamPosRef.current);
      controlsRef.current.target.copy(initialTargetRef.current);
      controlsRef.current.update();
      setSelectedPartId(null);
    }
  };

  const handleSelectLocalFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setActiveBlob(file);
  };

  const filteredParts = parts.filter(p => 
    !partSearch || p.name.toLowerCase().includes(partSearch.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col select-none overflow-hidden animate-fade-in font-sans">
      {/* Top Header Bar */}
      <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between p-3 sm:p-4 bg-gradient-to-b from-black/95 via-black/60 to-transparent pointer-events-none">
        <div className="pointer-events-auto flex items-center gap-2 max-w-[65vw]">
          <button
            onClick={onClose}
            className="p-2.5 rounded-xl bg-black/70 border border-[#14502D] text-[#CDEBD8] hover:text-white hover:bg-[#0E7A3D]/40 transition min-h-[48px] min-w-[48px] flex items-center justify-center backdrop-blur-md shadow-lg cursor-pointer"
            title="Fechar Visualizador"
            aria-label="Fechar"
          >
            <X size={20} />
          </button>
          
          <div className="px-3 py-1.5 rounded-xl bg-black/75 border border-[#14502D] backdrop-blur-md truncate shadow-lg">
            <h1 className="text-xs sm:text-sm font-semibold text-white tracking-wide truncate">
              {modelItem.nome}
            </h1>
            <p className="text-[10px] sm:text-[11px] text-[#2FD16F] capitalize truncate">
              {modelItem.especie} • Sistema {modelItem.sistema}
            </p>
          </div>
        </div>

        {/* Top Right Controls (only active when model is loaded) */}
        {!isWaitingFile && (
          <div className="pointer-events-auto flex items-center gap-1.5 sm:gap-2">
            <button
              onClick={handleResetView}
              className="p-2.5 sm:px-3 sm:py-2 rounded-xl bg-black/70 border border-[#14502D] text-[#CDEBD8] hover:text-white hover:border-[#2FD16F] backdrop-blur-md text-xs font-medium transition min-h-[48px] min-w-[48px] flex items-center justify-center shadow-lg cursor-pointer"
              title="Resetar visão da câmera"
            >
              <RotateCcw size={18} className="text-[#2FD16F]" />
              <span className="hidden md:inline ml-1.5">Resetar</span>
            </button>
            
            <button
              onClick={() => setIsPartsDrawerOpen(!isPartsDrawerOpen)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl border backdrop-blur-md text-xs font-semibold transition min-h-[48px] shadow-lg cursor-pointer ${
                isPartsDrawerOpen 
                  ? 'bg-[#0E7A3D] border-[#2FD16F] text-white shadow-[#0E7A3D]/30' 
                  : 'bg-black/70 border-[#14502D] text-[#CDEBD8] hover:text-white'
              }`}
              title="Lista de Estruturas Anatômicas"
            >
              <Layers size={18} className={isPartsDrawerOpen ? 'text-white' : 'text-[#2FD16F]'} />
              <span>Partes ({parts.length})</span>
            </button>
          </div>
        )}
      </div>

      {/* 3D Canvas Mount */}
      <div 
        ref={mountRef} 
        className="w-full h-full cursor-grab active:cursor-grabbing" 
        style={{ touchAction: 'none' }}
      />

      {/* Hidden File Picker to test real 3D model */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".glb,.gltf"
        onChange={handleSelectLocalFile}
        className="hidden"
      />

      {/* AWAITING REAL 3D MODEL UI (Zero Fake Models) */}
      {isWaitingFile && !loading && (
        <div className="absolute inset-0 z-30 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fade-in">
          <div className="max-w-md w-full bg-[#030d06] border border-[#14502D] rounded-2xl p-6 text-center space-y-4 shadow-2xl text-[#CDEBD8]">
            <div className="w-14 h-14 rounded-2xl bg-[#0E7A3D]/20 border border-[#0E7A3D] flex items-center justify-center text-[#2FD16F] mx-auto">
              <Box size={28} />
            </div>

            <div className="space-y-1.5">
              <h2 className="text-base font-bold text-white tracking-wide">
                Aguardando Arquivo 3D Real (.glb)
              </h2>
              <p className="text-xs text-[#CDEBD8]/80 leading-relaxed">
                Nenhum modelo procedural fictício está ativo. Este espécime requer o arquivo 3D real autêntico.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-black/60 border border-[#14502D]/80 text-left space-y-2 text-xs font-mono">
              <div className="text-[11px] text-[#2FD16F]">
                📁 Arquivo esperado no projeto:
              </div>
              <div className="text-white bg-black/80 p-2 rounded border border-[#14502D] break-all">
                {modelItem.arquivo}
              </div>
              <div className="text-[10px] text-[#CDEBD8]/60">
                Formato ideal: <strong>.GLB</strong> (Binary GLTF com texturas e malha unificadas)
              </div>
            </div>

            <div className="space-y-2 pt-2">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-full py-3 px-4 rounded-xl bg-[#0E7A3D] hover:bg-[#17B35A] text-white font-semibold text-xs shadow-lg shadow-[#0E7A3D]/30 transition flex items-center justify-center gap-2 cursor-pointer min-h-[46px]"
              >
                <Upload size={16} />
                <span>Carregar Arquivo .GLB deste Dispositivo</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className="w-full py-2.5 px-4 rounded-xl bg-black/50 hover:bg-[#14502D]/40 border border-[#14502D] text-xs text-[#CDEBD8] transition cursor-pointer min-h-[44px]"
              >
                Voltar à Biblioteca
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Loading Overlay */}
      {loading && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/85 z-10 pointer-events-none">
          <div className="w-12 h-12 rounded-full border-2 border-[#14502D] border-t-[#2FD16F] animate-spin mb-3" />
          <p className="text-xs text-[#CDEBD8] font-mono">Carregando arquivo 3D real...</p>
        </div>
      )}

      {/* Mobile Touch Gesture Hint */}
      {showTouchHint && !loading && !isWaitingFile && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 z-20 pointer-events-none animate-fade-in px-3 py-1.5 rounded-full bg-black/80 border border-[#14502D] backdrop-blur-md text-center max-w-[90vw]">
          <p className="text-[11px] text-[#CDEBD8] flex items-center justify-center gap-1.5 font-mono">
            <span>👆 1 dedo: girar</span>
            <span className="text-[#14502D]">•</span>
            <span>🤏 2 dedos: zoom</span>
          </p>
        </div>
      )}

      {/* Retractable Anatomical Parts Drawer */}
      {isPartsDrawerOpen && !isWaitingFile && (
        <div className="absolute top-20 right-3 sm:right-4 z-30 w-80 max-w-[88vw] max-h-[65vh] flex flex-col rounded-2xl bg-[#030d06]/95 border border-[#14502D] backdrop-blur-md shadow-2xl overflow-hidden animate-fade-in text-[#CDEBD8]">
          <div className="flex items-center justify-between px-3.5 py-3 border-b border-[#14502D]/60 bg-[#06180c]">
            <span className="text-xs font-semibold text-[#2FD16F] flex items-center gap-1.5">
              <Layers size={14} /> Estruturas do Modelo ({parts.length})
            </span>
            {selectedPartId && (
              <button
                onClick={() => setSelectedPartId(null)}
                className="text-[11px] text-[#2FD16F] hover:underline cursor-pointer"
              >
                Limpar isolamento
              </button>
            )}
          </div>

          {parts.length > 5 && (
            <div className="p-2 border-b border-[#14502D]/40">
              <div className="relative">
                <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#CDEBD8]/40" />
                <input
                  type="text"
                  value={partSearch}
                  onChange={(e) => setPartSearch(e.target.value)}
                  placeholder="Filtrar estruturas..."
                  className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-black/60 border border-[#14502D] text-xs text-[#CDEBD8] placeholder-[#CDEBD8]/40 focus:outline-none focus:border-[#2FD16F]"
                />
              </div>
            </div>
          )}

          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {filteredParts.map((p) => {
              const isSelected = selectedPartId === p.id;
              return (
                <div
                  key={p.id}
                  onClick={() => setSelectedPartId(isSelected ? null : p.id)}
                  className={`flex items-center justify-between px-3 py-2.5 rounded-xl text-xs cursor-pointer transition min-h-[44px] ${
                    isSelected
                      ? 'bg-[#0E7A3D] text-white font-semibold border border-[#2FD16F] shadow-md'
                      : 'hover:bg-[#14502D]/30 text-[#CDEBD8]'
                  }`}
                >
                  <span className="truncate pr-2">{p.name}</span>
                  <button
                    onClick={(e) => togglePartVisibility(p.id, e)}
                    className="p-1.5 rounded-lg text-[#CDEBD8]/60 hover:text-white hover:bg-black/40 transition shrink-0 min-h-[36px] min-w-[36px] flex items-center justify-center cursor-pointer"
                    title={p.visible ? 'Ocultar parte' : 'Exibir parte'}
                    aria-label="Alternar visibilidade"
                  >
                    {p.visible ? <Eye size={16} /> : <EyeOff size={16} className="text-red-400" />}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Bottom Tool Dock */}
      {!isWaitingFile && (
        <div className="absolute bottom-3 sm:bottom-4 left-1/2 -translate-x-1/2 z-20 w-[94vw] max-w-xl flex flex-col items-center gap-2 pointer-events-none">
          <div className="pointer-events-auto flex items-center justify-center gap-1.5 sm:gap-2 px-3 py-2 rounded-2xl bg-black/85 border border-[#14502D] backdrop-blur-md shadow-2xl">
            <button
              onClick={() => setIsXRayMode(!isXRayMode)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium transition min-h-[40px] flex items-center gap-1.5 cursor-pointer ${
                isXRayMode
                  ? 'bg-[#0E7A3D] text-white border border-[#2FD16F]'
                  : 'text-[#CDEBD8]/70 hover:text-white hover:bg-[#14502D]/30'
              }`}
              title="Modo Raio-X"
            >
              <Sliders size={14} className={isXRayMode ? 'text-white' : 'text-[#2FD16F]'} />
              <span>Raio-X</span>
            </button>

            <button
              onClick={() => setIsWireframe(!isWireframe)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium transition min-h-[40px] flex items-center gap-1.5 cursor-pointer ${
                isWireframe
                  ? 'bg-[#0E7A3D] text-white border border-[#2FD16F]'
                  : 'text-[#CDEBD8]/70 hover:text-white hover:bg-[#14502D]/30'
              }`}
              title="Modo Aramado"
            >
              <Grid size={14} className={isWireframe ? 'text-white' : 'text-[#2FD16F]'} />
              <span>Malha</span>
            </button>

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-1.5 rounded-xl text-xs font-medium text-[#CDEBD8]/70 hover:text-white hover:bg-[#14502D]/30 transition min-h-[40px] flex items-center gap-1.5 cursor-pointer"
              title="Substituir arquivo 3D"
            >
              <Upload size={14} className="text-[#2FD16F]" />
              <span>Trocar .GLB</span>
            </button>
          </div>

          <div className="pointer-events-auto px-4 py-2 rounded-xl bg-black/80 border border-[#14502D]/70 backdrop-blur-md text-center text-[11px] text-[#CDEBD8]/90 max-w-lg shadow-lg">
            <p className="line-clamp-2">
              {modelItem.descricao || modelItem.nome}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
