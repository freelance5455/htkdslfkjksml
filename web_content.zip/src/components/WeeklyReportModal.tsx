import React from 'react';
import { X, Printer, FileText, CheckCircle, AlertTriangle, ShieldCheck, Pill, Sparkles, Smile, Meh, Frown } from 'lucide-react';
import { MedicineItem, DoseRecord, ReminderLanguage } from '../types/reminder';
import { TRANSLATIONS } from '../data/reminderData';

interface WeeklyReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  medicines: MedicineItem[];
  doses: DoseRecord[];
  language: ReminderLanguage;
}

export const WeeklyReportModal: React.FC<WeeklyReportModalProps> = ({
  isOpen,
  onClose,
  medicines,
  doses,
  language
}) => {
  if (!isOpen) return null;
  const t = TRANSLATIONS[language];

  // Calculate stats for the last 7 days
  const now = new Date();
  const sevenDaysAgo = new Date(now.getTime() - 7 * 86400000);
  const sevenDaysAgoStr = sevenDaysAgo.toISOString().split('T')[0];

  const weeklyDoses = doses.filter(d => d.scheduledDate >= sevenDaysAgoStr);
  const totalWeekly = weeklyDoses.length;
  const takenWeekly = weeklyDoses.filter(d => d.status === 'taken').length;
  const missedWeekly = weeklyDoses.filter(d => d.status === 'missed').length;
  const skippedWeekly = weeklyDoses.filter(d => d.status === 'skipped').length;
  const adherenceWeekly = totalWeekly > 0 ? Math.round((takenWeekly / totalWeekly) * 100) : 100;

  // Feeling Effects breakdown
  const betterCount = doses.filter(d => d.feelingEffect === 'better').length;
  const noChangeCount = doses.filter(d => d.feelingEffect === 'no_change').length;
  const worseCount = doses.filter(d => d.feelingEffect === 'worse').length;
  const totalFeedback = betterCount + noChangeCount + worseCount;

  const handlePrintPdf = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 my-8">
        
        {/* Printable Header */}
        <div className="bg-gradient-to-r from-teal-700 via-teal-800 to-emerald-800 text-white p-6 relative overflow-hidden print:bg-none print:text-black">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-md border border-white/20 print:border-slate-300">
                <FileText className="w-8 h-8 text-emerald-300 print:text-teal-700" />
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold tracking-widest text-teal-200 bg-white/10 px-2.5 py-0.5 rounded-full print:text-slate-600">
                  Official Health Summary
                </span>
                <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight mt-1">{t.weeklyReport}</h2>
                <p className="text-xs text-teal-100 print:text-slate-600">
                  Generated on {new Date().toLocaleDateString(undefined, { dateStyle: 'full' })}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 print:hidden">
              <button
                onClick={handlePrintPdf}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-extrabold text-xs rounded-xl shadow-md transition-all active:scale-95"
              >
                <Printer className="w-4 h-4 stroke-[2.5]" />
                <span>{t.exportPdf}</span>
              </button>
              <button
                onClick={onClose}
                className="p-2 text-white/80 hover:text-white bg-white/10 hover:bg-white/20 rounded-xl transition-all"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Report Content Body */}
        <div className="p-6 space-y-6 print:p-4 text-slate-800" id="weekly-report-content">
          
          {/* Key Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5 text-center space-y-1">
              <span className="text-[11px] font-bold text-slate-500 uppercase block">Total Doses</span>
              <span className="text-2xl font-extrabold text-slate-900">{totalWeekly}</span>
            </div>

            <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3.5 text-center space-y-1">
              <span className="text-[11px] font-bold text-emerald-700 uppercase block">Taken</span>
              <span className="text-2xl font-extrabold text-emerald-700">{takenWeekly}</span>
            </div>

            <div className="bg-rose-50 border border-rose-200 rounded-2xl p-3.5 text-center space-y-1">
              <span className="text-[11px] font-bold text-rose-700 uppercase block">Missed</span>
              <span className="text-2xl font-extrabold text-rose-700">{missedWeekly}</span>
            </div>

            <div className="bg-teal-50 border border-teal-200 rounded-2xl p-3.5 text-center space-y-1">
              <span className="text-[11px] font-bold text-teal-800 uppercase block">Adherence Rate</span>
              <span className="text-2xl font-extrabold text-teal-700">{adherenceWeekly}%</span>
            </div>
          </div>

          {/* Adherence Tier Card */}
          <div className="bg-gradient-to-r from-teal-50 to-emerald-50 border border-teal-200/80 rounded-2xl p-4 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <ShieldCheck className="w-8 h-8 text-teal-600 shrink-0" />
              <div>
                <h4 className="font-extrabold text-sm text-slate-900">{t.adherenceScore} Status</h4>
                <p className="text-xs text-slate-600">Based on past 7 days dose logs</p>
              </div>
            </div>
            <div className="text-right">
              <span className={`inline-block px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider ${
                adherenceWeekly >= 90 ? 'bg-emerald-600 text-white' :
                adherenceWeekly >= 75 ? 'bg-teal-600 text-white' :
                adherenceWeekly >= 50 ? 'bg-amber-500 text-white' : 'bg-rose-600 text-white'
              }`}>
                {adherenceWeekly >= 90 ? t.tierExcellent :
                 adherenceWeekly >= 75 ? t.tierGood :
                 adherenceWeekly >= 50 ? t.tierAverage : t.tierPoor}
              </span>
            </div>
          </div>

          {/* Remaining Medicines Inventory */}
          <div className="space-y-3">
            <h4 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
              <Pill className="w-4 h-4 text-teal-700" />
              <span>Current Inventory & Remaining Tablets</span>
            </h4>
            
            {medicines.length === 0 ? (
              <p className="text-xs text-slate-500 italic">No active medicines registered.</p>
            ) : (
              <div className="border border-slate-200 rounded-2xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
                    <tr>
                      <th className="p-3">Medicine</th>
                      <th className="p-3">Type / Strength</th>
                      <th className="p-3">Daily Dose</th>
                      <th className="p-3 text-right">Remaining Tablets</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {medicines.map((med) => {
                      const dailyCount = med.times.length * med.dosePerTime;
                      return (
                        <tr key={med.id} className="hover:bg-slate-50/50">
                          <td className="p-3 font-bold text-slate-900">{med.name}</td>
                          <td className="p-3 text-slate-600">{med.type} ({med.strength})</td>
                          <td className="p-3 text-slate-600">{dailyCount} / day</td>
                          <td className="p-3 text-right font-extrabold">
                            <span className={med.remainingQuantity <= 5 ? 'text-rose-600' : 'text-teal-700'}>
                              {med.remainingQuantity} / {med.totalQuantity}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Effect Summary */}
          <div className="space-y-3">
            <h4 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>Patient Effect & Feeling Summary</span>
            </h4>

            <div className="grid grid-cols-3 gap-3">
              <div className="bg-emerald-50/70 border border-emerald-200/60 rounded-2xl p-3 text-center">
                <Smile className="w-6 h-6 text-emerald-600 mx-auto mb-1" />
                <span className="text-[11px] font-bold text-emerald-900 block">{t.better}</span>
                <span className="text-lg font-black text-emerald-700">{betterCount}</span>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 text-center">
                <Meh className="w-6 h-6 text-slate-600 mx-auto mb-1" />
                <span className="text-[11px] font-bold text-slate-800 block">{t.noChange}</span>
                <span className="text-lg font-black text-slate-700">{noChangeCount}</span>
              </div>

              <div className="bg-rose-50/70 border border-rose-200/60 rounded-2xl p-3 text-center">
                <Frown className="w-6 h-6 text-rose-600 mx-auto mb-1" />
                <span className="text-[11px] font-bold text-rose-900 block">{t.worse}</span>
                <span className="text-lg font-black text-rose-700">{worseCount}</span>
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-200 text-center text-[11px] text-slate-400">
            Report generated by SwasthyaSeva Medicine Reminder System • Keep prescribed medicines stored in a cool place.
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex justify-end print:hidden">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs rounded-xl transition-all"
          >
            {t.cancel}
          </button>
        </div>
      </div>
    </div>
  );
};
