import React, { useState, useEffect, useRef } from "react";
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Sparkles,
  Headphones,
} from "lucide-react";
import { Language, UserMemory } from "../types";
import {
  isSpeechRecognitionSupported,
  createSpeechRecognizer,
  speakText,
  stopSpeaking,
  playRanabirGreeting,
} from "../utils/speech";
import { getOfflineAnswer } from "../utils/offlineEngine";

interface VoiceCommandProps {
  language: Language;
  memory: UserMemory;
  isOffline: boolean;
}

export const VoiceCommand: React.FC<VoiceCommandProps> = ({
  language,
  memory,
  isOffline,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [response, setResponse] = useState("");
  const [status, setStatus] = useState<"idle" | "listening" | "processing" | "speaking">("idle");
  const [supported, setSupported] = useState(true);

  const recognizerRef = useRef<any>(null);

  useEffect(() => {
    setSupported(isSpeechRecognitionSupported());

    return () => {
      if (recognizerRef.current) {
        recognizerRef.current.stop();
      }
      stopSpeaking();
    };
  }, []);

  const handlePlayVoiceGreeting = () => {
    setStatus("speaking");
    setResponse("হাই, আমি রণবীর। তো আজকে আমি আপনাকে কি করে সাহায্য করতে পারি?");
    playRanabirGreeting(
      () => setStatus("speaking"),
      () => setStatus("idle")
    );
  };

  const handleProcessVoiceCommand = async (commandText: string) => {
    setStatus("processing");
    stopSpeaking();

    // Clean wake word if present
    const cleanCommand = commandText
      .replace(/hey ranabir/gi, "")
      .replace(/হেই রণবীর/gi, "")
      .replace(/রণবীর/gi, "")
      .trim();

    if (!cleanCommand) {
      handlePlayVoiceGreeting();
      return;
    }

    // Direct match for Ranabir identity / greeting questions
    const lowerCmd = cleanCommand.toLowerCase();
    if (
      lowerCmd.includes("তুমি কে") ||
      lowerCmd.includes("কে তুমি") ||
      lowerCmd.includes("who are you") ||
      lowerCmd.includes("তোমার নাম") ||
      lowerCmd.includes("হ্যালো") ||
      lowerCmd.includes("নমস্কার")
    ) {
      setResponse("হাই, আমি রণবীর। তো আজকে আমি আপনাকে কি করে সাহায্য করতে পারি?");
      handlePlayVoiceGreeting();
      return;
    }

    if (isOffline) {
      const offlineReply = getOfflineAnswer(cleanCommand, memory.addressingMode);
      setResponse(offlineReply);
      setStatus("speaking");
      speakText(
        offlineReply,
        language,
        () => setStatus("speaking"),
        () => setStatus("idle")
      );
      return;
    }

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: cleanCommand,
          memory,
          language,
        }),
      });
      const data = await res.json();
      const reply =
        data.reply ||
        (memory.addressingMode === "apni"
          ? "আমি Ranabir, আপনাকে সাহায্য করার জন্যই তৈরি।"
          : "আমি Ranabir, তোমাকে সাহায্য করার জন্যই তৈরি।");
      setResponse(reply);
      setStatus("speaking");
      speakText(
        reply,
        language,
        () => setStatus("speaking"),
        () => setStatus("idle")
      );
    } catch {
      const fallback = getOfflineAnswer(cleanCommand, memory.addressingMode);
      setResponse(fallback);
      setStatus("speaking");
      speakText(
        fallback,
        language,
        () => setStatus("speaking"),
        () => setStatus("idle")
      );
    }
  };

  const startListening = () => {
    if (!isSpeechRecognitionSupported()) {
      alert("Voice recognition is not supported in this browser. Please use Google Chrome or Chromium.");
      return;
    }

    stopSpeaking();
    setTranscript("");
    setStatus("listening");
    setIsListening(true);

    const rec = createSpeechRecognizer(
      language,
      (text, isFinal) => {
        setTranscript(text);

        if (isFinal) {
          setIsListening(false);
          handleProcessVoiceCommand(text);
        }
      },
      (error) => {
        console.warn("Voice error:", error);
        setStatus("idle");
        setIsListening(false);
      },
      () => {
        setIsListening(false);
        if (status === "listening") {
          setStatus("idle");
        }
      }
    );

    if (rec) {
      recognizerRef.current = rec;
      rec.start();
    }
  };

  const stopListening = () => {
    if (recognizerRef.current) {
      recognizerRef.current.stop();
    }
    setIsListening(false);
    setStatus("idle");
  };

  const triggerSampleCommand = (text: string) => {
    setTranscript(text);
    handleProcessVoiceCommand(text);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-160px)] max-w-2xl mx-auto px-4 py-6 text-center">
      {/* Holographic Glowing Voice Orb */}
      <div className="relative my-6 flex items-center justify-center">
        {/* Ambient glow pulses */}
        <div
          className={`absolute w-64 h-64 rounded-full transition-all duration-700 blur-3xl opacity-40 ${
            status === "listening"
              ? "bg-rose-500 scale-125"
              : status === "speaking"
              ? "bg-cyan-500 scale-110"
              : status === "processing"
              ? "bg-indigo-500 animate-spin"
              : "bg-indigo-600/60 scale-90"
          }`}
        />

        {/* Central interactive sphere */}
        <button
          onClick={isListening ? stopListening : startListening}
          className={`relative z-10 w-36 h-36 sm:w-44 sm:h-44 rounded-full flex flex-col items-center justify-center transition-all duration-300 shadow-2xl ${
            status === "listening"
              ? "bg-gradient-to-tr from-rose-600 to-rose-400 shadow-rose-500/50 scale-105 border-4 border-white/20"
              : status === "speaking"
              ? "bg-gradient-to-tr from-cyan-600 to-indigo-600 shadow-cyan-500/50 scale-105 border-4 border-cyan-400/40"
              : status === "processing"
              ? "bg-gradient-to-tr from-indigo-700 to-purple-600 animate-pulse shadow-indigo-500/50"
              : "bg-gradient-to-tr from-indigo-600 via-indigo-700 to-cyan-700 hover:scale-105 shadow-indigo-600/40 border border-white/20"
          }`}
        >
          {status === "listening" ? (
            <>
              <MicOff className="w-12 h-12 text-white animate-pulse" />
              <span className="text-xs font-bold text-white mt-2">শুনছি...</span>
            </>
          ) : status === "speaking" ? (
            <>
              <Volume2 className="w-12 h-12 text-cyan-200 animate-bounce" />
              <span className="text-xs font-bold text-white mt-2">রণবীর বলছে...</span>
            </>
          ) : status === "processing" ? (
            <>
              <Sparkles className="w-10 h-10 text-white animate-spin" />
              <span className="text-xs font-bold text-white mt-2">প্রসেসিং...</span>
            </>
          ) : (
            <>
              <Mic className="w-12 h-12 text-white" />
              <span className="text-xs font-bold text-slate-200 mt-2">ট্যাপ করুন</span>
            </>
          )}
        </button>
      </div>

      {/* Voice prompt instruction */}
      <div className="mt-2 mb-6">
        <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
          &quot;Hey Ranabir&quot;
        </h2>
        <p className="text-sm text-slate-400 mt-1 max-w-md">
          বলুন &quot;Hey Ranabir&quot; বা বোতামটিতে ট্যাপ করে কথা বলুন। রণবীর সরাসরি ভয়েসে উত্তর প্রদান করবে।
        </p>
      </div>

      {/* Live transcript or response view */}
      <div className="w-full max-w-lg min-h-[100px] glass-panel-elevated rounded-2xl p-4 text-left border border-white/10 shadow-lg">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-2 pb-2 border-b border-white/5">
          <span className="font-semibold uppercase tracking-wider text-[11px] flex items-center gap-1.5">
            {status === "listening" ? (
              <>🎙️ আপনার ভয়েস ইনপুট:</>
            ) : status === "speaking" ? (
              <>
                <Headphones className="w-3.5 h-3.5 text-cyan-400" />
                <span>Ranabir এর ভয়েস উত্তর:</span>
              </>
            ) : (
              <>📝 ভয়েস কনসোল</>
            )}
          </span>
          {status === "speaking" && (
            <button
              onClick={() => {
                stopSpeaking();
                setStatus("idle");
              }}
              className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1"
            >
              <VolumeX className="w-3 h-3" />
              <span>মিউট করুন</span>
            </button>
          )}
        </div>

        {transcript && (
          <p className="text-xs text-indigo-300 mb-2 font-mono">
            &quot;{transcript}&quot;
          </p>
        )}

        <div className="text-sm text-slate-100 leading-relaxed max-h-48 overflow-y-auto font-normal">
          {response ? (
            response
          ) : (
            <span className="text-slate-500 italic">
              কোনো ভয়েস কমান্ড এখনও দেওয়া হয়নি। নিচের সাজেশনে ক্লিক করুন অথবা বোতামটি চেপে কথা বলুন।
            </span>
          )}
        </div>
      </div>

      {/* Quick voice preset chips */}
      <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
        <button
          onClick={() => triggerSampleCommand("Hey Ranabir, তুমি কে এবং তোমাকে কে তৈরি করেছে?")}
          className="text-xs px-3 py-1.5 rounded-xl glass-panel hover:border-indigo-400 text-slate-300 transition-colors"
        >
          &quot;Hey Ranabir, তুমি কে?&quot;
        </button>
        <button
          onClick={() => triggerSampleCommand("Hey Ranabir, আমাকে একটি শিক্ষণীয় গল্প শোনাও।")}
          className="text-xs px-3 py-1.5 rounded-xl glass-panel hover:border-indigo-400 text-slate-300 transition-colors"
        >
          &quot;একটি গল্প শোনাও&quot;
        </button>
        <button
          onClick={() => triggerSampleCommand("Hey Ranabir, কোডিং শেখার সেরা উপায় কী?")}
          className="text-xs px-3 py-1.5 rounded-xl glass-panel hover:border-indigo-400 text-slate-300 transition-colors"
        >
          &quot;কোডিং শেখার উপায়&quot;
        </button>
      </div>
    </div>
  );
};
