import React, { useState, useEffect, useRef } from 'react';
import { Copy, Delete, RotateCcw, Cpu, Sparkles, Check, ChevronDown, ChevronUp } from 'lucide-react';
import { mathEngine, AngleMode } from '../services/mathEngine';
import { audioService } from '../services/audioService';
import { historyStorage } from '../services/historyStorage';
import confetti from 'canvas-confetti';

interface CalculatorViewProps {
  onShowToast: (text: string, type?: 'success' | 'info' | 'error') => void;
  externalInput?: string | null;
  onClearExternalInput?: () => void;
}

export const CalculatorView: React.FC<CalculatorViewProps> = ({
  onShowToast,
  externalInput,
  onClearExternalInput,
}) => {
  const [expression, setExpression] = useState<string>('');
  const [resultDisplay, setResultDisplay] = useState<string>('0');
  const [livePreview, setLivePreview] = useState<string | null>(null);
  const [angleMode, setAngleMode] = useState<AngleMode>('DEG');
  const [hasMemory, setHasMemory] = useState<boolean>(false);
  const [isSecondFunction, setIsSecondFunction] = useState<boolean>(false);
  const [showScientific, setShowScientific] = useState<boolean>(true);
  const [showMemoryDrawer, setShowMemoryDrawer] = useState<boolean>(false);
  const [copiedRecently, setCopiedRecently] = useState<boolean>(false);

  const displayRef = useRef<HTMLDivElement>(null);

  // Synchronize external input (from AI solver, history tape, or formulas)
  useEffect(() => {
    if (externalInput !== undefined && externalInput !== null) {
      setExpression(externalInput);
      const evalRes = mathEngine.evaluate(externalInput);
      if (evalRes.success && evalRes.result !== null) {
        setResultDisplay(evalRes.display);
      }
      onClearExternalInput?.();
    }
  }, [externalInput, onClearExternalInput]);

  // Update memory flag
  const checkMemory = () => {
    setHasMemory(mathEngine.hasMemory());
  };

  // Live evaluation preview as user types
  useEffect(() => {
    if (!expression || expression.trim() === '') {
      setLivePreview(null);
      return;
    }
    // Only evaluate if it contains an operator and does not end with one
    if (/[+\-×÷*/^]/.test(expression) && !/[+\-×÷*/^(]$/.test(expression.trim())) {
      const evalRes = mathEngine.evaluate(expression);
      if (evalRes.success && evalRes.result !== null && evalRes.display !== resultDisplay) {
        setLivePreview(evalRes.display);
      } else {
        setLivePreview(null);
      }
    } else {
      setLivePreview(null);
    }
  }, [expression, resultDisplay, angleMode]);

  // Toggle DEG / RAD
  const toggleAngleMode = () => {
    audioService.playScientificClick();
    const nextMode: AngleMode = angleMode === 'DEG' ? 'RAD' : 'DEG';
    setAngleMode(nextMode);
    mathEngine.setAngleMode(nextMode);
    onShowToast(`Angle Mode: ${nextMode}`, 'info');

    if (expression) {
      const evalRes = mathEngine.evaluate(expression);
      if (evalRes.success) {
        setResultDisplay(evalRes.display);
      }
    }
  };

  // Append token to expression
  const appendToken = (token: string, type: 'number' | 'operator' | 'func' = 'number') => {
    if (type === 'number') {
      audioService.playKeyClick();
    } else if (type === 'operator') {
      audioService.playOperatorClick();
    } else {
      audioService.playScientificClick();
    }

    setExpression((prev) => {
      // If we just got a result and start typing a number, restart expression
      if (prev === '' && resultDisplay !== '0' && type === 'number') {
        return token;
      }
      return prev + token;
    });
  };

  // Backspace single character
  const handleBackspace = () => {
    audioService.playClearSound();
    setExpression((prev) => {
      if (prev.length <= 1) return '';
      // Check for multi-char tokens like 'sin(' or 'log('
      const funcs = ['sin(', 'cos(', 'tan(', 'asin(', 'acos(', 'atan(', 'ln(', 'log(', 'sqrt(', 'abs(', 'Ans'];
      for (const fn of funcs) {
        if (prev.endsWith(fn)) {
          return prev.slice(0, -fn.length);
        }
      }
      return prev.slice(0, -1);
    });
  };

  // All Clear (AC)
  const handleAllClear = () => {
    audioService.playClearSound();
    setExpression('');
    setResultDisplay('0');
    setLivePreview(null);
  };

  // Toggle plus/minus on active number
  const handleToggleSign = () => {
    audioService.playOperatorClick();
    setExpression((prev) => {
      if (!prev) return '-';
      if (prev.startsWith('-')) return prev.substring(1);
      return '-' + prev;
    });
  };

  // Calculate Equals (=)
  const handleEquals = () => {
    if (!expression || expression.trim() === '') return;

    const evalRes = mathEngine.evaluate(expression);
    if (evalRes.success && evalRes.result !== null) {
      audioService.playEqualsChime();

      // Golden celebratory burst if it's a non-trivial computation
      if (expression.length > 5 || /[sin|cos|tan|log|√|^]/.test(expression)) {
        confetti({
          particleCount: 22,
          spread: 45,
          origin: { y: 0.35 },
          colors: ['#fbbf24', '#f59e0b', '#d97706', '#ffffff'],
        });
      }

      setResultDisplay(evalRes.display);
      setLivePreview(null);

      // Save to persistent tape history
      historyStorage.add({
        type: showScientific ? 'scientific' : 'standard',
        expression: expression,
        result: evalRes.display,
        numericResult: evalRes.result,
        title: `${angleMode} Mode Calculation`,
      });

      // Allow chaining: start next expression with Ans
      setExpression('');
    } else {
      audioService.playErrorSound();
      setResultDisplay('Error');
      onShowToast(evalRes.error || 'Calculation error', 'error');
    }
  };

  // One-Tap Copy
  const handleCopyResult = () => {
    audioService.playKeyClick();
    if (navigator?.clipboard) {
      navigator.clipboard.writeText(resultDisplay);
      setCopiedRecently(true);
      onShowToast(`Copied ${resultDisplay} to clipboard!`, 'success');
      setTimeout(() => setCopiedRecently(false), 2000);
    }
  };

  // Memory operations
  const handleMemoryOp = (op: 'MC' | 'MR' | 'M+' | 'M-') => {
    audioService.playKeyClick();
    const currentNum = parseFloat(resultDisplay.replace(/,/g, '')) || 0;

    switch (op) {
      case 'MC':
        mathEngine.memoryClear();
        checkMemory();
        onShowToast('Memory Cleared (MC)', 'info');
        break;
      case 'MR':
        const mem = mathEngine.getMemory();
        appendToken(mem.toString(), 'number');
        onShowToast(`Recalled Memory: ${mem}`, 'info');
        break;
      case 'M+':
        mathEngine.memoryAdd(currentNum);
        checkMemory();
        onShowToast(`Added ${currentNum} to Memory (M+)`, 'success');
        break;
      case 'M-':
        mathEngine.memorySubtract(currentNum);
        checkMemory();
        onShowToast(`Subtracted ${currentNum} from Memory (M-)`, 'info');
        break;
    }
  };

  // Typography auto-scaling based on digit length
  const getResultFontSize = (text: string) => {
    const len = text.length;
    if (len <= 7) return 'text-5xl';
    if (len <= 11) return 'text-4xl';
    if (len <= 15) return 'text-3xl';
    if (len <= 20) return 'text-2xl';
    return 'text-xl';
  };

  return (
    <div className="flex flex-col h-full w-full max-w-md mx-auto select-none">
      {/* 1. OLED Status Indicators */}
      <div className="flex items-center justify-between px-4 py-2 bg-[#090b10] border-b border-amber-500/10 text-[11px] font-mono">
        <div className="flex items-center gap-2">
          {/* DEG / RAD Button */}
          <button
            onClick={toggleAngleMode}
            className="flex items-center gap-1 px-2 py-0.5 rounded bg-zinc-900 border border-amber-500/30 text-amber-300 font-bold hover:bg-zinc-800 transition"
          >
            <span className={angleMode === 'DEG' ? 'text-amber-400 font-black' : 'text-zinc-500'}>DEG</span>
            <span className="text-zinc-600">/</span>
            <span className={angleMode === 'RAD' ? 'text-amber-400 font-black' : 'text-zinc-500'}>RAD</span>
          </button>

          {/* Memory Indicator */}
          <button
            onClick={() => setShowMemoryDrawer(!showMemoryDrawer)}
            className={`px-1.5 py-0.5 rounded border text-[10px] font-bold transition flex items-center gap-0.5 ${
              hasMemory
                ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-[0_0_8px_rgba(245,158,11,0.3)]'
                : 'bg-zinc-900/80 border-zinc-800 text-zinc-600'
            }`}
            title="Memory Status (Click to expand M+, M-, MR, MC)"
          >
            <span>[M]</span>
            {hasMemory && <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />}
          </button>

          {/* 2nd Function Toggle */}
          <button
            onClick={() => {
              audioService.playScientificClick();
              setIsSecondFunction(!isSecondFunction);
            }}
            className={`px-1.5 py-0.5 rounded text-[10px] font-bold border transition ${
              isSecondFunction
                ? 'bg-amber-400 text-black border-amber-300'
                : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200'
            }`}
          >
            2nd
          </button>
        </div>

        {/* OLED Engine Status */}
        <div className="flex items-center gap-1.5 text-zinc-400">
          <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_6px_#10b981]" />
          <span className="text-[10px] tracking-wider text-amber-200/70 uppercase">VIP ENGINE READY</span>
        </div>
      </div>

      {/* Memory Operations Drawer */}
      {showMemoryDrawer && (
        <div className="grid grid-cols-4 gap-1.5 px-3 py-1.5 bg-[#0e1017] border-b border-amber-500/20 text-xs font-mono animate-in slide-in-from-top-1">
          <button
            onClick={() => handleMemoryOp('MC')}
            className="py-1 px-2 rounded bg-zinc-900 hover:bg-zinc-800 text-zinc-400 border border-zinc-800 text-center"
          >
            MC
          </button>
          <button
            onClick={() => handleMemoryOp('MR')}
            className="py-1 px-2 rounded bg-zinc-900 hover:bg-zinc-800 text-amber-300 border border-amber-500/30 text-center font-bold"
          >
            MR ({mathEngine.getMemory()})
          </button>
          <button
            onClick={() => handleMemoryOp('M+')}
            className="py-1 px-2 rounded bg-zinc-900 hover:bg-zinc-800 text-amber-400 border border-zinc-800 text-center"
          >
            M+
          </button>
          <button
            onClick={() => handleMemoryOp('M-')}
            className="py-1 px-2 rounded bg-zinc-900 hover:bg-zinc-800 text-amber-400 border border-zinc-800 text-center"
          >
            M-
          </button>
        </div>
      )}

      {/* 2. Golden LCD Screen Display */}
      <div
        ref={displayRef}
        onClick={handleCopyResult}
        className="relative mx-3 mt-3 p-4 rounded-2xl bg-gradient-to-b from-[#0e111a] via-[#090b10] to-[#06070a] border border-amber-500/25 shadow-[inset_0_2px_12px_rgba(0,0,0,0.8),0_8px_20px_rgba(0,0,0,0.6)] cursor-pointer group transition-all hover:border-amber-400/40"
      >
        {/* Decorative LCD Grid Lines */}
        <div className="absolute inset-0 bg-[radial-gradient(#f59e0b_1px,transparent_1px)] [background-size:16px_16px] opacity-[0.03] pointer-events-none rounded-2xl" />

        {/* Copy Hint Button (Top Right) */}
        <div className="absolute top-2.5 right-3 flex items-center gap-1 text-[10px] text-zinc-500 group-hover:text-amber-300 transition-colors">
          {copiedRecently ? (
            <>
              <Check className="w-3 h-3 text-emerald-400" />
              <span className="text-emerald-400 font-mono">COPIED</span>
            </>
          ) : (
            <>
              <Copy className="w-3 h-3" />
              <span className="font-mono">COPY</span>
            </>
          )}
        </div>

        {/* Dynamic Expression Line */}
        <div className="min-h-[26px] overflow-x-auto scrollbar-none text-right font-mono text-xs sm:text-sm text-amber-200/60 tracking-wider flex items-center justify-end">
          {expression ? (
            <span className="break-all">{expression}</span>
          ) : (
            <span className="text-zinc-600 italic">VIP Formula Input</span>
          )}
        </div>

        {/* Live Calculation Preview */}
        {livePreview && (
          <div className="text-right text-xs font-mono text-zinc-500 tracking-wider">
            ≈ {livePreview}
          </div>
        )}

        {/* Main Auto-Scaling Golden LCD Result */}
        <div className="mt-1 flex items-baseline justify-end overflow-hidden">
          <div
            className={`font-lcd font-bold tracking-tight text-right gold-gradient-text transition-all duration-150 drop-shadow-[0_2px_10px_rgba(245,158,11,0.3)] ${getResultFontSize(
              resultDisplay
            )}`}
          >
            {resultDisplay}
          </div>
        </div>
      </div>

      {/* Scientific Toggle Pill */}
      <div className="flex items-center justify-center my-1.5 px-3">
        <button
          onClick={() => {
            audioService.playKeyClick();
            setShowScientific(!showScientific);
          }}
          className="flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-zinc-900/90 border border-zinc-800 text-[10px] text-zinc-400 hover:text-amber-300 transition"
        >
          <span>{showScientific ? 'Compact Mode' : 'Scientific Keypad'}</span>
          {showScientific ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
        </button>
      </div>

      {/* 3. Scientific Function Grid (Top Row) */}
      {showScientific && (
        <div className="grid grid-cols-5 gap-1.5 px-3 pb-2 text-xs font-mono select-none">
          {/* Row 1 */}
          <button
            onClick={() => appendToken(isSecondFunction ? 'asin(' : 'sin(', 'func')}
            className="py-2 rounded-xl bg-[#121520] hover:bg-[#1a1e2e] active:scale-95 border border-zinc-800/80 text-amber-300 font-medium transition shadow-sm"
          >
            {isSecondFunction ? 'sin⁻¹' : 'sin'}
          </button>
          <button
            onClick={() => appendToken(isSecondFunction ? 'acos(' : 'cos(', 'func')}
            className="py-2 rounded-xl bg-[#121520] hover:bg-[#1a1e2e] active:scale-95 border border-zinc-800/80 text-amber-300 font-medium transition shadow-sm"
          >
            {isSecondFunction ? 'cos⁻¹' : 'cos'}
          </button>
          <button
            onClick={() => appendToken(isSecondFunction ? 'atan(' : 'tan(', 'func')}
            className="py-2 rounded-xl bg-[#121520] hover:bg-[#1a1e2e] active:scale-95 border border-zinc-800/80 text-amber-300 font-medium transition shadow-sm"
          >
            {isSecondFunction ? 'tan⁻¹' : 'tan'}
          </button>
          <button
            onClick={() => appendToken(isSecondFunction ? 'exp(' : 'ln(', 'func')}
            className="py-2 rounded-xl bg-[#121520] hover:bg-[#1a1e2e] active:scale-95 border border-zinc-800/80 text-amber-300 font-medium transition shadow-sm"
          >
            {isSecondFunction ? 'eˣ' : 'ln'}
          </button>
          <button
            onClick={() => appendToken(isSecondFunction ? '10^(' : 'log(', 'func')}
            className="py-2 rounded-xl bg-[#121520] hover:bg-[#1a1e2e] active:scale-95 border border-zinc-800/80 text-amber-300 font-medium transition shadow-sm"
          >
            {isSecondFunction ? '10ˣ' : 'log'}
          </button>

          {/* Row 2 */}
          <button
            onClick={() => appendToken('^', 'func')}
            className="py-2 rounded-xl bg-[#121520] hover:bg-[#1a1e2e] active:scale-95 border border-zinc-800/80 text-amber-200/90 font-medium transition"
          >
            xʸ
          </button>
          <button
            onClick={() => appendToken(isSecondFunction ? 'cbrt(' : 'sqrt(', 'func')}
            className="py-2 rounded-xl bg-[#121520] hover:bg-[#1a1e2e] active:scale-95 border border-zinc-800/80 text-amber-200/90 font-medium transition"
          >
            {isSecondFunction ? '∛x' : '√x'}
          </button>
          <button
            onClick={() => appendToken('^2', 'func')}
            className="py-2 rounded-xl bg-[#121520] hover:bg-[#1a1e2e] active:scale-95 border border-zinc-800/80 text-amber-200/90 font-medium transition"
          >
            x²
          </button>
          <button
            onClick={() => appendToken('^(1/', 'func')}
            className="py-2 rounded-xl bg-[#121520] hover:bg-[#1a1e2e] active:scale-95 border border-zinc-800/80 text-amber-200/90 font-medium transition"
          >
            1/x
          </button>
          <button
            onClick={() => appendToken('!', 'func')}
            className="py-2 rounded-xl bg-[#121520] hover:bg-[#1a1e2e] active:scale-95 border border-zinc-800/80 text-amber-200/90 font-medium transition"
          >
            n!
          </button>

          {/* Row 3 */}
          <button
            onClick={() => appendToken('(', 'func')}
            className="py-1.5 rounded-xl bg-[#10131d] hover:bg-[#181c2b] active:scale-95 border border-zinc-800/70 text-zinc-300 transition"
          >
            (
          </button>
          <button
            onClick={() => appendToken(')', 'func')}
            className="py-1.5 rounded-xl bg-[#10131d] hover:bg-[#181c2b] active:scale-95 border border-zinc-800/70 text-zinc-300 transition"
          >
            )
          </button>
          <button
            onClick={() => appendToken('π', 'func')}
            className="py-1.5 rounded-xl bg-[#10131d] hover:bg-[#181c2b] active:scale-95 border border-zinc-800/70 text-amber-300 font-medium transition"
          >
            π
          </button>
          <button
            onClick={() => appendToken('e', 'func')}
            className="py-1.5 rounded-xl bg-[#10131d] hover:bg-[#181c2b] active:scale-95 border border-zinc-800/70 text-amber-300 font-medium transition"
          >
            e
          </button>
          <button
            onClick={() => appendToken('Ans', 'func')}
            className="py-1.5 rounded-xl bg-[#10131d] hover:bg-[#181c2b] active:scale-95 border border-amber-500/30 text-amber-400 font-bold transition"
          >
            Ans
          </button>
        </div>
      )}

      {/* 4. Operator Palette & High-Contrast Numeric Keypad */}
      <div className="grid grid-cols-4 gap-2 p-3 pt-1 flex-1">
        {/* Row 1: AC, Backspace, %, ÷ */}
        <button
          onClick={handleAllClear}
          className="py-3.5 sm:py-4 rounded-2xl bg-gradient-to-b from-[#261517] to-[#1c0d0f] hover:from-[#351b1f] hover:to-[#261517] border border-rose-500/30 text-rose-300 font-mono text-base font-bold active:scale-95 transition shadow-lg flex items-center justify-center"
        >
          AC
        </button>
        <button
          onClick={handleBackspace}
          className="py-3.5 sm:py-4 rounded-2xl bg-[#151824] hover:bg-[#1d2233] border border-zinc-700/60 text-zinc-300 font-mono text-lg active:scale-95 transition shadow-lg flex items-center justify-center"
          title="Backspace"
        >
          <Delete className="w-5 h-5 text-zinc-300" />
        </button>
        <button
          onClick={() => appendToken('%', 'operator')}
          className="py-3.5 sm:py-4 rounded-2xl bg-[#151824] hover:bg-[#1d2233] border border-cyan-500/25 text-cyan-300 font-mono text-lg font-bold active:scale-95 transition shadow-lg flex items-center justify-center"
        >
          %
        </button>
        <button
          onClick={() => appendToken('÷', 'operator')}
          className="py-3.5 sm:py-4 rounded-2xl bg-gradient-to-b from-[#211a12] to-[#18130a] hover:from-[#2e2316] hover:to-[#211a12] border border-amber-500/40 text-amber-400 font-mono text-xl font-bold active:scale-95 transition shadow-lg flex items-center justify-center"
        >
          ÷
        </button>

        {/* Row 2: 7, 8, 9, × */}
        <button
          onClick={() => appendToken('7', 'number')}
          className="py-3.5 sm:py-4 rounded-2xl bg-gradient-to-b from-[#181b28] to-[#11131d] hover:from-[#222638] hover:to-[#181b28] border border-zinc-700/40 text-zinc-100 font-mono text-xl font-semibold active:scale-95 transition shadow-md"
        >
          7
        </button>
        <button
          onClick={() => appendToken('8', 'number')}
          className="py-3.5 sm:py-4 rounded-2xl bg-gradient-to-b from-[#181b28] to-[#11131d] hover:from-[#222638] hover:to-[#181b28] border border-zinc-700/40 text-zinc-100 font-mono text-xl font-semibold active:scale-95 transition shadow-md"
        >
          8
        </button>
        <button
          onClick={() => appendToken('9', 'number')}
          className="py-3.5 sm:py-4 rounded-2xl bg-gradient-to-b from-[#181b28] to-[#11131d] hover:from-[#222638] hover:to-[#181b28] border border-zinc-700/40 text-zinc-100 font-mono text-xl font-semibold active:scale-95 transition shadow-md"
        >
          9
        </button>
        <button
          onClick={() => appendToken('×', 'operator')}
          className="py-3.5 sm:py-4 rounded-2xl bg-gradient-to-b from-[#211a12] to-[#18130a] hover:from-[#2e2316] hover:to-[#211a12] border border-amber-500/40 text-amber-400 font-mono text-xl font-bold active:scale-95 transition shadow-lg flex items-center justify-center"
        >
          ×
        </button>

        {/* Row 3: 4, 5, 6, − */}
        <button
          onClick={() => appendToken('4', 'number')}
          className="py-3.5 sm:py-4 rounded-2xl bg-gradient-to-b from-[#181b28] to-[#11131d] hover:from-[#222638] hover:to-[#181b28] border border-zinc-700/40 text-zinc-100 font-mono text-xl font-semibold active:scale-95 transition shadow-md"
        >
          4
        </button>
        <button
          onClick={() => appendToken('5', 'number')}
          className="py-3.5 sm:py-4 rounded-2xl bg-gradient-to-b from-[#181b28] to-[#11131d] hover:from-[#222638] hover:to-[#181b28] border border-zinc-700/40 text-zinc-100 font-mono text-xl font-semibold active:scale-95 transition shadow-md"
        >
          5
        </button>
        <button
          onClick={() => appendToken('6', 'number')}
          className="py-3.5 sm:py-4 rounded-2xl bg-gradient-to-b from-[#181b28] to-[#11131d] hover:from-[#222638] hover:to-[#181b28] border border-zinc-700/40 text-zinc-100 font-mono text-xl font-semibold active:scale-95 transition shadow-md"
        >
          6
        </button>
        <button
          onClick={() => appendToken('−', 'operator')}
          className="py-3.5 sm:py-4 rounded-2xl bg-gradient-to-b from-[#211a12] to-[#18130a] hover:from-[#2e2316] hover:to-[#211a12] border border-amber-500/40 text-amber-400 font-mono text-xl font-bold active:scale-95 transition shadow-lg flex items-center justify-center"
        >
          −
        </button>

        {/* Row 4: 1, 2, 3, + */}
        <button
          onClick={() => appendToken('1', 'number')}
          className="py-3.5 sm:py-4 rounded-2xl bg-gradient-to-b from-[#181b28] to-[#11131d] hover:from-[#222638] hover:to-[#181b28] border border-zinc-700/40 text-zinc-100 font-mono text-xl font-semibold active:scale-95 transition shadow-md"
        >
          1
        </button>
        <button
          onClick={() => appendToken('2', 'number')}
          className="py-3.5 sm:py-4 rounded-2xl bg-gradient-to-b from-[#181b28] to-[#11131d] hover:from-[#222638] hover:to-[#181b28] border border-zinc-700/40 text-zinc-100 font-mono text-xl font-semibold active:scale-95 transition shadow-md"
        >
          2
        </button>
        <button
          onClick={() => appendToken('3', 'number')}
          className="py-3.5 sm:py-4 rounded-2xl bg-gradient-to-b from-[#181b28] to-[#11131d] hover:from-[#222638] hover:to-[#181b28] border border-zinc-700/40 text-zinc-100 font-mono text-xl font-semibold active:scale-95 transition shadow-md"
        >
          3
        </button>
        <button
          onClick={() => appendToken('+', 'operator')}
          className="py-3.5 sm:py-4 rounded-2xl bg-gradient-to-b from-[#211a12] to-[#18130a] hover:from-[#2e2316] hover:to-[#211a12] border border-amber-500/40 text-amber-400 font-mono text-xl font-bold active:scale-95 transition shadow-lg flex items-center justify-center"
        >
          +
        </button>

        {/* Row 5: ±, 0, ., = (Glowing Amber VIP Equals) */}
        <button
          onClick={handleToggleSign}
          className="py-3.5 sm:py-4 rounded-2xl bg-[#151824] hover:bg-[#1d2233] border border-zinc-700/40 text-zinc-300 font-mono text-lg active:scale-95 transition shadow-md"
        >
          ±
        </button>
        <button
          onClick={() => appendToken('0', 'number')}
          className="py-3.5 sm:py-4 rounded-2xl bg-gradient-to-b from-[#181b28] to-[#11131d] hover:from-[#222638] hover:to-[#181b28] border border-zinc-700/40 text-zinc-100 font-mono text-xl font-semibold active:scale-95 transition shadow-md"
        >
          0
        </button>
        <button
          onClick={() => appendToken('.', 'number')}
          className="py-3.5 sm:py-4 rounded-2xl bg-[#151824] hover:bg-[#1d2233] border border-zinc-700/40 text-zinc-200 font-mono text-2xl font-bold active:scale-95 transition shadow-md"
        >
          .
        </button>
        <button
          onClick={handleEquals}
          className="py-3.5 sm:py-4 rounded-2xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black font-mono text-2xl font-black active:scale-95 transition shadow-[0_0_24px_rgba(245,158,11,0.5)] border border-amber-300/80 flex items-center justify-center"
          title="Compute Result"
        >
          =
        </button>
      </div>
    </div>
  );
};
