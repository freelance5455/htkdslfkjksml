import React from "react";

interface SkeuomorphicIconProps {
  color?: string;
  size?: number;
  isActive?: boolean;
  className?: string;
}

/**
 * 1. Skeuomorphic Fountain Pen (Dolma Kalem)
 * Realistic nib with silver/gold engravings, breather hole, and dynamic ink slit colored with `color`.
 */
export const SkeuomorphicFountainPen: React.FC<SkeuomorphicIconProps> = ({
  color = "#0284C7",
  size = 28,
  isActive = false,
  className = "",
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`transition-transform duration-200 ${className}`}
    >
      <defs>
        <linearGradient id={`fp-barrel-${color}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#1E293B" />
          <stop offset="50%" stopColor="#334155" />
          <stop offset="100%" stopColor="#0F172A" />
        </linearGradient>
        <linearGradient id={`fp-nib-gold-${color}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#FDE047" />
          <stop offset="40%" stopColor="#EAB308" />
          <stop offset="80%" stopColor="#CA8A04" />
          <stop offset="100%" stopColor="#854D0E" />
        </linearGradient>
        <linearGradient id={`fp-nib-silver`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#E2E8F0" />
          <stop offset="50%" stopColor="#CBD5E1" />
          <stop offset="100%" stopColor="#94A3B8" />
        </linearGradient>
      </defs>

      {/* Pen Upper Body / Barrel */}
      <rect x="13.5" y="2" width="5" height="12" rx="2.5" fill={`url(#fp-barrel-${color})`} />
      {/* Chrome Accent Ring */}
      <rect x="12.5" y="13" width="7" height="1.8" rx="0.9" fill="url(#fp-nib-silver)" />

      {/* Grip Section */}
      <path d="M13 14.8 L19 14.8 L18 19 L14 19 Z" fill="#1E293B" />

      {/* Gold Nib Body */}
      <path
        d="M13.5 19 C13.5 19 11 23 11 25.5 C11 27 15 30 16 31 C17 30 21 27 21 25.5 C21 23 18.5 19 18.5 19 Z"
        fill={`url(#fp-nib-gold-${color})`}
        stroke="#A16207"
        strokeWidth="0.5"
      />

      {/* Chrome Nib Center Plate */}
      <path d="M14 20 L18 20 L17.5 24 L14.5 24 Z" fill="url(#fp-nib-silver)" />

      {/* Breather Hole */}
      <circle cx="16" cy="24" r="0.9" fill="#1E293B" />

      {/* Dynamic Ink Slit & Nib Tip */}
      <line x1="16" y1="24.8" x2="16" y2="31" stroke={color} strokeWidth="1.2" strokeLinecap="round" />
      <polygon points="15.2,30.2 16,31.4 16.8,30.2" fill={color} />

      {/* Active Aura if selected */}
      {isActive && (
        <circle cx="16" cy="31" r="2.5" fill={color} opacity="0.4" className="animate-ping" />
      )}
    </svg>
  );
};

/**
 * 2. Skeuomorphic Pencil (Kurşun Kalem)
 * Classic hexagonal painted wood pencil, metal ferrule, pink eraser cap,
 * sharpened cedar wood cone, and dynamic graphite tip colored with `color`.
 */
export const SkeuomorphicPencil: React.FC<SkeuomorphicIconProps> = ({
  color = "#D97706",
  size = 28,
  isActive = false,
  className = "",
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`transition-transform duration-200 ${className}`}
    >
      <defs>
        <linearGradient id={`penc-body-${color}`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#F59E0B" />
          <stop offset="45%" stopColor="#FBBF24" />
          <stop offset="70%" stopColor="#D97706" />
          <stop offset="100%" stopColor="#B45309" />
        </linearGradient>
        <linearGradient id="penc-eraser" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#FDA4AF" />
          <stop offset="50%" stopColor="#FB7185" />
          <stop offset="100%" stopColor="#F43F5E" />
        </linearGradient>
        <linearGradient id="penc-metal" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#94A3B8" />
          <stop offset="50%" stopColor="#F1F5F9" />
          <stop offset="100%" stopColor="#64748B" />
        </linearGradient>
        <linearGradient id="penc-wood" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#FDE68A" />
          <stop offset="50%" stopColor="#FEF3C7" />
          <stop offset="100%" stopColor="#F59E0B" />
        </linearGradient>
      </defs>

      {/* Pink Rubber Eraser Cap */}
      <rect x="13.5" y="2" width="5" height="3" rx="1.5" fill="url(#penc-eraser)" />

      {/* Metal Ferrule with crimp grooves */}
      <rect x="13" y="4.5" width="6" height="3" rx="0.5" fill="url(#penc-metal)" />
      <line x1="13" y1="5.8" x2="19" y2="5.8" stroke="#475569" strokeWidth="0.5" />
      <line x1="13" y1="6.8" x2="19" y2="6.8" stroke="#475569" strokeWidth="0.5" />

      {/* Yellow Hexagonal Body */}
      <rect x="13.5" y="7.5" width="5" height="13.5" fill={`url(#penc-body-${color})`} />
      <line x1="15.2" y1="7.5" x2="15.2" y2="21" stroke="#FDE68A" strokeWidth="0.4" opacity="0.6" />
      <line x1="16.8" y1="7.5" x2="16.8" y2="21" stroke="#92400E" strokeWidth="0.4" opacity="0.6" />

      {/* Sharpened Cedar Wood Cone */}
      <polygon points="13.5,21 18.5,21 16,28" fill="url(#penc-wood)" stroke="#D97706" strokeWidth="0.3" />

      {/* Dynamic Graphite / Colored Lead Tip */}
      <polygon points="14.8,26.5 17.2,26.5 16,30.5" fill={color} />

      {/* Active Aura if selected */}
      {isActive && (
        <circle cx="16" cy="30.5" r="2.5" fill={color} opacity="0.4" className="animate-ping" />
      )}
    </svg>
  );
};

/**
 * 3. Skeuomorphic Highlighter (Fosforlu Kalem)
 * Translucent fluorescent marker body, wide chisel angled nib dynamically glowing with `color`.
 */
export const SkeuomorphicHighlighter: React.FC<SkeuomorphicIconProps> = ({
  color = "#FACC15",
  size = 28,
  isActive = false,
  className = "",
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`transition-transform duration-200 ${className}`}
    >
      <defs>
        <linearGradient id={`hl-cap-${color}`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#1E293B" />
          <stop offset="50%" stopColor="#475569" />
          <stop offset="100%" stopColor="#0F172A" />
        </linearGradient>
      </defs>

      {/* Flat Marker Cap Top */}
      <rect x="12" y="3" width="8" height="4" rx="2" fill="url(#hl-cap)" />

      {/* Wide Chunky Translucent Body with Fluid Fill */}
      <rect x="11.5" y="6.5" width="9" height="14" rx="2" fill="#334155" />
      <rect x="13" y="8" width="6" height="11" rx="1" fill={color} opacity="0.85" />
      {/* Specular Highlight Streak */}
      <rect x="13.5" y="8.5" width="1.5" height="10" rx="0.75" fill="#FFFFFF" opacity="0.6" />

      {/* Chisel Collar */}
      <path d="M12.5 20.5 L19.5 20.5 L18.5 23 L13.5 23 Z" fill="#1E293B" />

      {/* Slanted Beveled Chisel Nib */}
      <polygon
        points="14,23 18,23 18,29 14,26.5"
        fill={color}
        stroke="#FFFFFF"
        strokeWidth="0.5"
      />

      {/* Fluorescent Light Glow */}
      <path d="M14 26 L18 28.5" stroke="#FFFFFF" strokeWidth="0.8" opacity="0.7" />

      {/* Active Aura if selected */}
      {isActive && (
        <ellipse cx="16" cy="28.5" rx="3.5" ry="1.8" fill={color} opacity="0.5" className="animate-ping" />
      )}
    </svg>
  );
};

/**
 * 4. Skeuomorphic Eraser (Silgi)
 * Realistic angled wedge block eraser with dual-color rubber sleeve.
 */
export const SkeuomorphicEraser: React.FC<SkeuomorphicIconProps> = ({
  size = 28,
  isActive = false,
  className = "",
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`transition-transform duration-200 ${className}`}
    >
      <defs>
        <linearGradient id="er-rubber-top" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="50%" stopColor="#F1F5F9" />
          <stop offset="100%" stopColor="#E2E8F0" />
        </linearGradient>
        <linearGradient id="er-sleeve" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#2563EB" />
          <stop offset="50%" stopColor="#3B82F6" />
          <stop offset="100%" stopColor="#1D4ED8" />
        </linearGradient>
      </defs>

      {/* Cardboard Card Sleeve */}
      <rect x="10.5" y="4" width="11" height="13" rx="1.5" fill="url(#er-sleeve)" />
      {/* Brand Stripe on Sleeve */}
      <rect x="10.5" y="8" width="11" height="3" fill="#FFFFFF" opacity="0.9" />
      <rect x="12" y="9" width="8" height="1" fill="#EF4444" />

      {/* Angled White Rubber Block */}
      <path
        d="M11 17 L21 17 L19 28 L13 28 Z"
        fill="url(#er-rubber-top)"
        stroke="#CBD5E1"
        strokeWidth="0.6"
      />
      {/* Beveled Bottom Edge */}
      <polygon points="13,28 19,28 17.5,30 14.5,30" fill="#94A3B8" />

      {isActive && (
        <circle cx="16" cy="29" r="2.5" fill="#3B82F6" opacity="0.4" className="animate-ping" />
      )}
    </svg>
  );
};

/**
 * 5. Skeuomorphic Lasso (Kement & Makas)
 * Coiled rope loop with realistic metal cutting shears.
 */
export const SkeuomorphicLasso: React.FC<SkeuomorphicIconProps> = ({
  color = "#0D9488",
  size = 28,
  isActive = false,
  className = "",
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`transition-transform duration-200 ${className}`}
    >
      <defs>
        <linearGradient id="lasso-metal" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#F8FAFC" />
          <stop offset="50%" stopColor="#CBD5E1" />
          <stop offset="100%" stopColor="#64748B" />
        </linearGradient>
      </defs>

      {/* Dashed Selection Orbit Loop */}
      <ellipse
        cx="16"
        cy="14"
        rx="9"
        ry="6.5"
        stroke={color}
        strokeWidth="1.8"
        strokeDasharray="3 2"
        fill={color}
        fillOpacity="0.12"
      />

      {/* Shears / Scissors Cut Symbol */}
      <circle cx="13" cy="24" r="2" stroke="url(#lasso-metal)" strokeWidth="1.2" fill="#334155" />
      <circle cx="19" cy="24" r="2" stroke="url(#lasso-metal)" strokeWidth="1.2" fill="#334155" />
      <line x1="14" y1="23" x2="18" y2="17" stroke="url(#lasso-metal)" strokeWidth="1.4" strokeLinecap="round" />
      <line x1="18" y1="23" x2="14" y2="17" stroke="url(#lasso-metal)" strokeWidth="1.4" strokeLinecap="round" />
      <circle cx="16" cy="20" r="0.8" fill="#F8FAFC" />

      {isActive && (
        <circle cx="16" cy="14" r="4" fill={color} opacity="0.3" className="animate-ping" />
      )}
    </svg>
  );
};

/**
 * 6. Skeuomorphic Laser Marker (Lazer İşaretleyici)
 * Anodized black/silver tube with knurled grip, chrome emitter collar, and glowing laser diode.
 */
export const SkeuomorphicLaserMarker: React.FC<SkeuomorphicIconProps> = ({
  color = "#EF4444",
  size = 28,
  isActive = false,
  className = "",
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`transition-transform duration-200 ${className}`}
    >
      <defs>
        <linearGradient id="lz-tube" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#1E293B" />
          <stop offset="50%" stopColor="#475569" />
          <stop offset="100%" stopColor="#0F172A" />
        </linearGradient>
        <radialGradient id={`lz-beam-${color}`} cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="40%" stopColor={color} />
          <stop offset="100%" stopColor="transparent" />
        </radialGradient>
      </defs>

      {/* Laser Pointer Tube Body */}
      <rect x="13.5" y="3" width="5" height="15" rx="2" fill="url(#lz-tube)" />
      {/* Knurled Grip Rings */}
      <line x1="13.5" y1="8" x2="18.5" y2="8" stroke="#94A3B8" strokeWidth="0.6" />
      <line x1="13.5" y1="10" x2="18.5" y2="10" stroke="#94A3B8" strokeWidth="0.6" />
      <line x1="13.5" y1="12" x2="18.5" y2="12" stroke="#94A3B8" strokeWidth="0.6" />

      {/* Button Switch */}
      <circle cx="16" cy="15" r="1" fill="#F8FAFC" />

      {/* Emitter Tip */}
      <path d="M14 18 L18 18 L17 22 L15 22 Z" fill="#64748B" />
      <rect x="15" y="22" width="2" height="2" fill="#E2E8F0" />

      {/* Intense Laser Point Beam */}
      <circle cx="16" cy="27" r="4.5" fill={`url(#lz-beam-${color})`} />
      <circle cx="16" cy="27" r="1.5" fill="#FFFFFF" />

      {isActive && (
        <circle cx="16" cy="27" r="6" fill={color} opacity="0.4" className="animate-ping" />
      )}
    </svg>
  );
};

/**
 * 7. Skeuomorphic Recall Tape (Hafıza Bandı)
 * Textured masking tape strip with serrated cut edge and eye symbol.
 */
export const SkeuomorphicRecallTape: React.FC<SkeuomorphicIconProps> = ({
  color = "#F59E0B",
  size = 28,
  isActive = false,
  className = "",
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`transition-transform duration-200 ${className}`}
    >
      {/* Tape Strip with Zigzag Cut Ends */}
      <path
        d="M7 11 L25 11 L24 21 L6 21 Z"
        fill={color}
        fillOpacity="0.9"
        stroke="#FFFFFF"
        strokeWidth="0.5"
      />
      {/* Tape Subtle Diagonal Texture */}
      <line x1="10" y1="11" x2="8" y2="21" stroke="#FFFFFF" strokeWidth="0.6" opacity="0.3" />
      <line x1="15" y1="11" x2="13" y2="21" stroke="#FFFFFF" strokeWidth="0.6" opacity="0.3" />
      <line x1="20" y1="11" x2="18" y2="21" stroke="#FFFFFF" strokeWidth="0.6" opacity="0.3" />

      {/* Interactive Eye Icon In Center */}
      <ellipse cx="15.5" cy="16" rx="4" ry="2.5" fill="#FFFFFF" fillOpacity="0.95" />
      <circle cx="15.5" cy="16" r="1.4" fill="#0F172A" />

      {isActive && (
        <rect x="7" y="11" width="18" height="10" fill={color} opacity="0.3" className="animate-pulse" />
      )}
    </svg>
  );
};
