import React, { useMemo, useState } from 'react';
import { Shield, Trophy } from 'lucide-react';
import { ClanDashboardState } from '../shared/cocData';
import { formatDateTimeRu } from '../utils/formatters';

interface CwlViewProps {
  state: ClanDashboardState;
  onSelectPlayer: (tag: string) => void;
  embedded?: boolean;
}

const CWL_STATE_RU: Record<string, string> = {
  preparation: 'Подготовка',
  inWar: 'Идёт сезон CWL',
  ended: 'Сезон завершён',
  warEnded: 'Раунд завершён',
};

export const CwlView: React.FC<CwlViewProps> = ({ state, onSelectPlayer, embedded = false }) => {
  const cwl = state.cwl;
  const [selectedRound, setSelectedRound] = useState<number | 'all'>('all');

  const visibleWars = useMemo(() => {
    if (!cwl) return [];
    if (selectedRound === 'all') return cwl.wars;
    return cwl.wars.filter((w) => w.roundIndex === selectedRound);
  }, [cwl, selectedRound]);

  if (!state.clan) {
    return (
      <div className="rounded-lg border border-slate-800 bg-[#121824] p-8 text-center text-sm text-slate-400">
        Подключите клан на вкладке «Обзор», чтобы загрузить данные Лиги Войн Кланов (CWL).
      </div>
    );
  }

  if (!cwl) {
    return (
      <div className="space-y-6">
        {!embedded && (
          <section className="border-b border-slate-800/90 pb-4">
            <h1 className="font-display text-2xl font-bold tracking-tight text-slate-100">
              Лига Войн Кланов (CWL)
            </h1>
            <p className="mt-1 text-sm text-slate-400">
              Текущая группа лиги (<span className="font-mono text-slate-300">GET /clans/{state.clan.tag}/currentwar/leaguegroup</span>) и раунды
            </p>
          </section>
        )}

        <section className="rounded-lg border border-slate-800 bg-[#121824] p-8 text-center space-y-2">
          <Trophy className="mx-auto h-8 w-8 text-amber-400/70" />
          <div className="text-sm font-semibold text-slate-200">
            Активный сезон CWL не найден в Supercell API
          </div>
          <p className="mx-auto max-w-xl text-xs text-slate-400 leading-relaxed">
            Supercell API отдаёт данные CWL только во время проведения сезонной Лиги Войн Кланов (обычно в начале месяца) и сразу после её окончания. Прошлые архивные сезоны CWL официальным API не предоставляются.
          </p>
          <div className="pt-2 text-xs text-slate-300">
            Текущая лига клана: <strong className="text-amber-400">{state.clan.warLeague}</strong>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {!embedded && (
        <section className="flex flex-col gap-3 border-b border-slate-800/90 pb-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="font-display text-2xl font-bold tracking-tight text-slate-100">
              Лига Войн Кланов (CWL) · Сезон {cwl.season || 'Текущий'}
            </h1>
            <p className="mt-1 text-sm text-slate-400">
              {state.clan.warLeague} · {CWL_STATE_RU[cwl.state] ?? cwl.state} · {cwl.clans.length} кланов в группе · {cwl.rounds.length} раундов
            </p>
          </div>
        </section>
      )}

      {/* Group Standings */}
      <section className="rounded-lg border border-slate-800 bg-[#121824]">
        <div className="border-b border-slate-800 px-5 py-4">
          <h2 className="font-display text-base font-semibold text-slate-100">
            Турнирная таблица группы CWL
          </h2>
          <p className="mt-0.5 text-xs text-slate-400">
            Включая бонусные +10★ за победу в каждом завершённом раунде
          </p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-slate-800/80 text-xs font-medium text-slate-400 bg-[#0B0F17]/40">
                <th className="px-4 py-2.5">#</th>
                <th className="px-4 py-2.5">Клан</th>
                <th className="px-3 py-2.5 text-right">Ур.</th>
                <th className="px-3 py-2.5 text-right">Раунды</th>
                <th className="px-3 py-2.5 text-right">В / П / Н</th>
                <th className="px-3 py-2.5 text-right">Звёзды</th>
                <th className="px-4 py-2.5 text-right">Сумм. разруш.</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {cwl.standings.map((c, idx) => {
                const isOurs = c.tag === state.clan?.tag;
                return (
                  <tr
                    key={c.tag}
                    className={isOurs ? 'bg-amber-500/8' : 'hover:bg-slate-800/25'}
                  >
                    <td className="px-4 py-2.5 font-mono tabular-nums text-slate-400">{idx + 1}</td>
                    <td className="px-4 py-2.5 whitespace-nowrap">
                      <div className="flex items-center gap-2.5">
                        {c.badgeUrl ? (
                          <img
                            src={c.badgeUrl}
                            alt={c.name}
                            referrerPolicy="no-referrer"
                            className="h-6 w-6 object-contain"
                          />
                        ) : (
                          <Shield className="h-5 w-5 text-slate-500" />
                        )}
                        <div>
                          <div className={`font-medium ${isOurs ? 'text-amber-400' : 'text-slate-100'}`}>
                            {c.name}
                          </div>
                          <div className="font-mono text-[11px] text-slate-500">{c.tag}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-300">
                      {c.clanLevel}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-300">
                      {c.warsPlayed}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-300">
                      {c.wins} / {c.losses} / {c.ties}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono font-semibold tabular-nums text-amber-400">
                      {c.stars}★
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums text-slate-200">
                      {c.destructionSum.toFixed(1)}%
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      {/* Rounds & Clan Matches */}
      <section className="rounded-lg border border-slate-800 bg-[#121824]">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 px-5 py-4">
          <h2 className="font-display text-base font-semibold text-slate-100">
            Раунды клана {state.clan.name}
          </h2>
          <div className="flex items-center gap-1 overflow-x-auto rounded-md border border-slate-800 bg-[#0B0F17] p-1">
            <button
              type="button"
              onClick={() => setSelectedRound('all')}
              className={`px-2.5 py-1 text-xs rounded whitespace-nowrap ${
                selectedRound === 'all'
                  ? 'bg-amber-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Все раунды
            </button>
            {cwl.wars.map((w) => (
              <button
                key={w.warTag}
                type="button"
                onClick={() => setSelectedRound(w.roundIndex)}
                className={`px-2.5 py-1 text-xs rounded whitespace-nowrap ${
                  selectedRound === w.roundIndex
                    ? 'bg-amber-500 text-slate-950 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Раунд {w.roundIndex}
              </button>
            ))}
          </div>
        </div>

        <div className="divide-y divide-slate-800/70">
          {visibleWars.map((w) => (
            <div key={w.warTag} className="p-5 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="text-sm font-semibold text-slate-100">
                  Раунд {w.roundIndex}: {w.clan.name} vs {w.opponent.name}{' '}
                  <span className="font-mono text-xs text-slate-400">{w.opponent.tag}</span>
                </div>
                <div className="flex items-center gap-3 text-xs font-mono tabular-nums">
                  <span className="text-slate-400">{CWL_STATE_RU[w.state] ?? w.state}</span>
                  {w.endTime && <span className="text-slate-500">{formatDateTimeRu(w.endTime)}</span>}
                </div>
              </div>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3 text-xs font-mono tabular-nums">
                <div className="rounded bg-[#0B0F17] px-3 py-2 border border-slate-800/80">
                  <span className="text-slate-400">Звёзды: </span>
                  <strong className="text-amber-400">{w.clan.stars}</strong> : {w.opponent.stars}
                </div>
                <div className="rounded bg-[#0B0F17] px-3 py-2 border border-slate-800/80">
                  <span className="text-slate-400">Разрушение: </span>
                  <strong className="text-slate-100">{w.clan.destructionPercentage.toFixed(1)}%</strong> :{' '}
                  {w.opponent.destructionPercentage.toFixed(1)}%
                </div>
                <div className="rounded bg-[#0B0F17] px-3 py-2 border border-slate-800/80">
                  <span className="text-slate-400">Атаки: </span>
                  <strong className="text-emerald-400">{w.clan.attacks}/{w.teamSize}</strong> vs{' '}
                  {w.opponent.attacks}/{w.teamSize}
                </div>
              </div>
            </div>
          ))}
          {visibleWars.length === 0 && (
            <div className="p-6 text-center text-xs text-slate-500">
              Матчи выбранного раунда ещё не начались или недоступны.
            </div>
          )}
        </div>
      </section>

      {/* CWL Player Leaderboard */}
      <section className="rounded-lg border border-slate-800 bg-[#121824]">
        <div className="border-b border-slate-800 px-5 py-4">
          <h2 className="font-display text-base font-semibold text-slate-100">
            Рейтинг игроков в CWL ({cwl.playerRatings.length})
          </h2>
          <p className="mt-0.5 text-xs text-slate-400">
            Суммарные звёзды, трёшки и среднее разрушение за все раунды текущего сезона
          </p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-slate-800/80 text-xs font-medium text-slate-400 bg-[#0B0F17]/40">
                <th className="px-4 py-2.5">#</th>
                <th className="px-4 py-2.5">Игрок</th>
                <th className="px-3 py-2.5 text-right">TH</th>
                <th className="px-3 py-2.5 text-right">Войны</th>
                <th className="px-3 py-2.5 text-right">Атаки</th>
                <th className="px-3 py-2.5 text-right">Звёзды</th>
                <th className="px-3 py-2.5 text-right">3★ атаки</th>
                <th className="px-4 py-2.5 text-right">Ср. разрушение</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {cwl.playerRatings.map((pr, idx) => (
                <tr
                  key={pr.tag}
                  onClick={() => onSelectPlayer(pr.tag)}
                  className="cursor-pointer hover:bg-slate-800/35 transition-colors"
                >
                  <td className="px-4 py-2.5 font-mono tabular-nums text-slate-500">{idx + 1}</td>
                  <td className="px-4 py-2.5 whitespace-nowrap">
                    <div className="font-medium text-slate-100">{pr.name}</div>
                    <div className="font-mono text-[11px] text-slate-500">{pr.tag}</div>
                  </td>
                  <td className="px-3 py-2.5 text-right font-mono tabular-nums text-amber-400">
                    {pr.townHallLevel}
                  </td>
                  <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-300">
                    {pr.warsParticipated}
                  </td>
                  <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-300">
                    {pr.attacksUsed}
                  </td>
                  <td className="px-3 py-2.5 text-right font-mono font-semibold tabular-nums text-amber-400">
                    {pr.stars}★
                  </td>
                  <td className="px-3 py-2.5 text-right font-mono tabular-nums text-emerald-400">
                    {pr.threeStars}
                  </td>
                  <td className="px-4 py-2.5 text-right font-mono tabular-nums text-slate-200">
                    {pr.avgDestruction.toFixed(1)}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
