import React, { useState } from 'react';
import { Users, Copy, Check, Share2, MessageCircle, Gift, ShieldCheck } from 'lucide-react';
import confetti from 'canvas-confetti';
import { soundEngine, triggerHaptic } from '../utils/audio';

interface FriendsViewProps {
  referralCode: string;
  totalReferralBonusClaimable: number;
  onClaimReferralBonus: () => void;
}

export const FriendsView: React.FC<FriendsViewProps> = ({
  referralCode,
  totalReferralBonusClaimable,
  onClaimReferralBonus,
}) => {
  const [copied, setCopied] = useState(false);

  const mockFriends = [
    { name: 'Hamza Tariq', phone: '0345***891', date: 'Yesterday', earned: 1500 },
    { name: 'Zohaib Hassan', phone: '0301***442', date: '3 days ago', earned: 3200 },
    { name: 'Sana Malik', phone: '0333***712', date: 'Last week', earned: 850 },
  ];

  const shareText = `Play Tap Tap Cash on mobile! Tap to earn coins and withdraw real cash rewards via Easypaisa & JazzCash. Use my invite code ${referralCode} for a free 2,500 Coin bonus: https://tap-tap-cash.app/join?ref=${referralCode}`;

  const handleCopyCode = () => {
    triggerHaptic('light');
    navigator.clipboard?.writeText(referralCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShareWhatsApp = () => {
    triggerHaptic('light');
    const url = `https://wa.me/?text=${encodeURIComponent(shareText)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="max-w-md mx-auto px-4 py-3 space-y-4 pb-20">
      {/* Referral Hero Banner */}
      <div className="bg-gradient-to-br from-amber-950/60 via-slate-900 to-slate-900 border border-amber-800/40 rounded-2xl p-4 text-center">
        <div className="w-12 h-12 bg-amber-500/10 border border-amber-500/30 rounded-2xl mx-auto mb-2 flex items-center justify-center">
          <Users className="w-6 h-6 text-amber-400" />
        </div>
        <h2 className="text-base font-extrabold text-white font-display">
          Invite Friends & Earn Real Cash
        </h2>
        <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
          Get <strong className="text-amber-400">5,000 Coins (Rs. 50)</strong> for every friend who joins + <strong className="text-emerald-400">10% commission</strong> on all their mining taps forever!
        </p>

        {/* Invite Code Box */}
        <div className="mt-4 flex items-center justify-center gap-2 bg-slate-950 border border-slate-800 rounded-xl p-2 max-w-xs mx-auto">
          <span className="text-xs text-slate-400 font-medium">Your Code:</span>
          <span className="font-mono text-sm font-black text-amber-400 tracking-wider">
            {referralCode}
          </span>
          <button
            onClick={handleCopyCode}
            className="ml-2 p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
            title="Copy Code"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* Share Buttons */}
        <div className="grid grid-cols-2 gap-2 mt-4">
          <button
            onClick={handleShareWhatsApp}
            className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow-md active:scale-95"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Share on WhatsApp</span>
          </button>

          <button
            onClick={handleCopyCode}
            className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center justify-center gap-1.5 transition-all active:scale-95"
          >
            <Share2 className="w-4 h-4" />
            <span>{copied ? 'Link Copied!' : 'Copy Invite Link'}</span>
          </button>
        </div>
      </div>

      {/* Claimable Commission Box */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
        <div>
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
            Referral Commissions
          </span>
          <div className="flex items-baseline gap-1.5 mt-0.5">
            <span className="text-lg font-black text-amber-400 font-mono-num font-display">
              🪙 {totalReferralBonusClaimable.toLocaleString()}
            </span>
            <span className="text-xs text-emerald-400 font-bold font-mono-num">
              (Rs. {(totalReferralBonusClaimable / 100).toFixed(2)})
            </span>
          </div>
        </div>

        <button
          disabled={totalReferralBonusClaimable <= 0}
          onClick={() => {
            triggerHaptic('success');
            soundEngine.playCashRegister();
            confetti({ particleCount: 40, spread: 50 });
            onClaimReferralBonus();
          }}
          className={`py-2 px-3.5 rounded-xl font-bold text-xs transition-transform active:scale-95 ${
            totalReferralBonusClaimable > 0
              ? 'bg-gradient-to-r from-emerald-500 to-green-600 text-slate-950 hover:brightness-105 shadow-md shadow-emerald-500/20'
              : 'bg-slate-800 text-slate-500 cursor-not-allowed'
          }`}
        >
          Claim Commission
        </button>
      </div>

      {/* Friends Team List */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Invited Friends ({mockFriends.length})
          </h3>
          <span className="text-xs text-slate-500">Auto-credited</span>
        </div>

        {mockFriends.map((friend, i) => (
          <div
            key={i}
            className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 flex items-center justify-between text-xs"
          >
            <div>
              <span className="font-bold text-white block">{friend.name}</span>
              <span className="text-[11px] text-slate-500 font-mono">{friend.phone} · {friend.date}</span>
            </div>
            <div className="text-right">
              <span className="text-amber-400 font-mono-num font-bold block">
                +{friend.earned} coins
              </span>
              <span className="text-[10px] text-slate-400 font-medium">10% commission</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
