import React from 'react';
import { Users, MessageSquare } from 'lucide-react';

interface FloatingNavbarProps {
  activeTab: 'players' | 'chat';
  onSelectTab: (tab: 'players' | 'chat') => void;
  playerCount: number;
}

export const FloatingNavbar: React.FC<FloatingNavbarProps> = ({
  activeTab,
  onSelectTab,
  playerCount,
}) => {
  return (
    <nav
      aria-label="Hauptnavigation"
      className="fixed bottom-5 left-1/2 -translate-x-1/2 z-40 p-1.5 rounded-full bg-zinc-900/95 border border-zinc-700/80 shadow-2xl backdrop-blur-md flex items-center gap-1.5 ring-1 ring-white/5"
    >
      {/* Tab 1: Players */}
      <button
        type="button"
        onClick={() => onSelectTab('players')}
        className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold transition-all duration-200 select-none ${
          activeTab === 'players'
            ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950/40'
            : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/80'
        }`}
      >
        <Users className="w-4 h-4" />
        <span>Players</span>
        <span
          className={`inline-flex items-center justify-center px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
            activeTab === 'players'
              ? 'bg-emerald-700 text-emerald-100'
              : 'bg-zinc-800 text-zinc-400'
          }`}
        >
          {playerCount}
        </span>
      </button>

      {/* Tab 2: Chat */}
      <button
        type="button"
        onClick={() => onSelectTab('chat')}
        className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold transition-all duration-200 select-none ${
          activeTab === 'chat'
            ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950/40'
            : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/80'
        }`}
      >
        <MessageSquare className="w-4 h-4" />
        <span>Chat</span>
      </button>
    </nav>
  );
};
