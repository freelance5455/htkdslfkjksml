import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import gsap from 'gsap';
import { Zap, DollarSign, Wallet, ArrowUpRight, ShieldCheck, CheckCircle2, X } from 'lucide-react';
import { financialMessenger, FinancialBalanceUpdateEvent } from '../lib/financialMessenger';

export const FinancialBalanceToast: React.FC = () => {
  const [currentEvent, setCurrentEvent] = useState<FinancialBalanceUpdateEvent | null>(null);
  const [displayNgn, setDisplayNgn] = useState<number>(0);
  const [displaySats, setDisplaySats] = useState<number>(0);

  const ngnRef = useRef<HTMLDivElement>(null);
  const satsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const unsubscribe = financialMessenger.subscribeBalanceUpdates((event) => {
      const prevNgn = displayNgn;
      const prevSats = displaySats;
      setCurrentEvent(event);

      // GSAP-based number ticking animation for premium experience
      if (ngnRef.current) {
        const obj = { val: prevNgn };
        gsap.to(obj, {
          val: event.newCashBalanceNgn,
          duration: 1.5,
          ease: "power2.out",
          onUpdate: () => {
            setDisplayNgn(Math.round(obj.val));
          }
        });
      }

      if (satsRef.current) {
        const objSats = { val: prevSats };
        gsap.to(objSats, {
          val: event.newBtcBalanceSats,
          duration: 1.5,
          ease: "power2.out",
          onUpdate: () => {
            setDisplaySats(Math.round(objSats.val));
          }
        });
      }

      const timer = setTimeout(() => {
        setCurrentEvent(null);
      }, 8000);
      return () => clearTimeout(timer);
    });

    return () => unsubscribe();
  }, [displayNgn, displaySats]);

  if (!currentEvent) return null;

  const isSmsCharge = currentEvent.sourceType === '5_NAIRA_SMS_CHARGE';
  const isAirtime = currentEvent.sourceType === 'AIRTIME_TO_CASH_CONVERTO';
  const isData = currentEvent.sourceType === 'DATA_TO_BITCOIN_CONVERTO';

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 50, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.9 }}
        className="fixed bottom-24 right-4 sm:right-8 z-50 max-w-md w-full bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/90 border-2 border-amber-400/80 rounded-3xl p-5 shadow-2xl shadow-amber-500/40 backdrop-blur-2xl text-slate-100"
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-500 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-amber-500/50 shrink-0 animate-pulse">
              {isData ? '₿' : '₦'}
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-[10px] font-black uppercase tracking-wider">
                  {isSmsCharge ? '₦5 IMSI SMS Charged' : isAirtime ? 'CONVERTO: Airtime → Cash' : isData ? 'CONVERTO: Data → Bitcoin' : 'Stream Payout Settled'}
                </span>
                <span className="text-[10px] text-emerald-400 font-bold flex items-center">
                  <CheckCircle2 className="w-3 h-3 mr-0.5" /> GSAP Ticked
                </span>
              </div>
              <h4 className="text-sm font-extrabold text-amber-100 mt-0.5">
                JUHNKRIX WALLET BALANCE TICKING UPWARD!
              </h4>
            </div>
          </div>

          <button
            onClick={() => setCurrentEvent(null)}
            className="text-slate-400 hover:text-amber-200 p-1 rounded-xl bg-slate-800/60 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="mt-3 pt-3 border-t border-amber-500/20 grid grid-cols-2 gap-2 text-xs">
          <div className="bg-slate-900/80 p-2.5 rounded-2xl border border-amber-500/15" ref={ngnRef}>
            <div className="text-[10px] text-slate-400 uppercase font-bold flex items-center space-x-1">
              <DollarSign className="w-3 h-3 text-amber-400" />
              <span>Cash Balance (₦)</span>
            </div>
            <div className="text-sm font-black text-amber-300 mt-0.5">
              ₦{(displayNgn || currentEvent.newCashBalanceNgn).toLocaleString()}
            </div>
          </div>

          <div className="bg-slate-900/80 p-2.5 rounded-2xl border border-amber-500/15" ref={satsRef}>
            <div className="text-[10px] text-slate-400 uppercase font-bold flex items-center space-x-1">
              <Zap className="w-3 h-3 text-amber-400" />
              <span>Bitcoin Balance</span>
            </div>
            <div className="text-sm font-black text-amber-300 mt-0.5">
              {(displaySats || currentEvent.newBtcBalanceSats).toLocaleString()} <span className="text-[10px] text-slate-400">Sats</span>
            </div>
          </div>
        </div>

        <div className="mt-2.5 flex items-center justify-between text-[10px] text-slate-400 font-mono">
          <span className="truncate max-w-[200px]">Ref: {currentEvent.bankRef}</span>
          <span className="text-amber-400 font-bold">07071918280 / juhnkrixmusika.pages.dev</span>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};
