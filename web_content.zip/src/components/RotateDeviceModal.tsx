import React from 'react';
import { Smartphone, RotateCw, ArrowRight } from 'lucide-react';

interface RotateDeviceModalProps {
  onDismiss: () => void;
}

export const RotateDeviceModal: React.FC<RotateDeviceModalProps> = ({ onDismiss }) => {
  const handleTryAutoRotate = async () => {
    try {
      if (document.documentElement.requestFullscreen) {
        await document.documentElement.requestFullscreen();
      }
      // @ts-ignore - ScreenOrientation lock API
      if (screen.orientation && screen.orientation.lock) {
        // @ts-ignore
        await screen.orientation.lock('landscape');
      }
    } catch {
      // Browsers may block programmatic orientation lock without specific user gesture or on iOS
    }
  };

  return (
    <div
      dir="rtl"
      id="rotate-device-screen"
      className="fixed inset-0 z-50 bg-neutral-950/95 backdrop-blur-md flex items-center justify-center p-4 font-['Tajawal',sans-serif] select-none"
    >
      <div className="relative w-full max-w-sm bg-neutral-900 border-2 border-amber-500 rounded-3xl p-6 text-white shadow-2xl flex flex-col items-center gap-4 text-center">
        {/* Animated Phone Icon with Rotation */}
        <div className="relative w-24 h-24 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full bg-amber-500/20 animate-ping" />
          <div className="relative w-20 h-20 rounded-2xl border-2 border-amber-400 bg-neutral-800 flex items-center justify-center animate-[spin_4s_ease-in-out_infinite]">
            <Smartphone className="w-10 h-10 text-amber-400" />
          </div>
          <div className="absolute -bottom-1 -right-1 bg-amber-500 rounded-full p-1 text-neutral-950 shadow">
            <RotateCw className="w-4 h-4 animate-spin" />
          </div>
        </div>

        {/* Title & Instructions */}
        <div className="flex flex-col gap-1.5">
          <span className="text-[11px] font-mono text-amber-400 tracking-wider font-bold">
            HORIZONTAL MODE RECOMMENDED
          </span>
          <h2 className="text-xl font-black text-amber-300">يرجى تدوير جهازك للوضع الأفقي</h2>
          <p className="text-xs text-neutral-300 leading-relaxed mt-1">
            صُممت لعبة <strong className="text-amber-400">PIXEL SURVIVAL</strong> لتعمل في الوضع العرضي (Landscape). قم بتدوير جهازك لتجربة استكشاف ورؤية كاملة مع أدوات تحكم مريحة.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2 w-full mt-2">
          <button
            id="btn-rotate-fullscreen"
            onClick={handleTryAutoRotate}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 active:scale-95 text-neutral-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg transition cursor-pointer"
          >
            <RotateCw className="w-4 h-4 text-neutral-950" />
            <span>تدوير وملء الشاشة</span>
          </button>

          <button
            id="btn-dismiss-rotate"
            onClick={onDismiss}
            className="w-full py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 active:scale-95 text-neutral-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <span>المتابعة في الوضع الحالي</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
