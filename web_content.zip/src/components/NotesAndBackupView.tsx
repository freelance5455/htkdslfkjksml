import React, { useRef, useState } from 'react';
import { AppState, DailyNote } from '../types';
import { getTodayJalali, toPersianDigits } from '../utils/tajrobiData';
import { downloadStandaloneTajrobiHTML } from '../utils/singleFileDownloader';
import {
  FileText,
  Plus,
  Trash2,
  Star,
  Check,
  Download,
  Upload,
  Database,
  Sparkles,
} from 'lucide-react';

interface NotesAndBackupViewProps {
  state: AppState;
  onAddNote: (note: Omit<DailyNote, 'id'>) => void;
  onToggleNoteDone: (id: string) => void;
  onToggleNoteImportant: (id: string) => void;
  onDeleteNote: (id: string) => void;
  onRestoreState: (newState: AppState) => void;
  onShowToast: (message: string, type: 'success' | 'warning' | 'info') => void;
}

export const NotesAndBackupView: React.FC<NotesAndBackupViewProps> = ({
  state,
  onAddNote,
  onToggleNoteDone,
  onToggleNoteImportant,
  onDeleteNote,
  onRestoreState,
  onShowToast,
}) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [important, setImportant] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmitNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() && !content.trim()) return;

    onAddNote({
      title: title.trim() || 'یادداشت جدید',
      content: content.trim(),
      date: getTodayJalali(),
      important,
      done: false,
    });

    setTitle('');
    setContent('');
    setImportant(false);
    onShowToast('یادداشت روزانه با موفقیت ثبت شد.', 'success');
  };

  // Export JSON
  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(state, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `tajrobi-planner-backup-${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    onShowToast('فایل پشتیبان JSON دانلود شد.', 'success');
  };

  // Import JSON
  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed && Array.isArray(parsed.parts) && Array.isArray(parsed.studyLogs)) {
          onRestoreState(parsed);
          onShowToast('اطلاعات با موفقیت از فایل پشتیبان بازیابی شد!', 'success');
        } else {
          onShowToast('فرمت فایل پشتیبان معتبر نیست.', 'warning');
        }
      } catch {
        onShowToast('خطا در خواندن فایل پشتیبان.', 'warning');
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="space-y-6 animate-fade-slide">
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
        <h2 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
          <FileText className="w-5 h-5 text-teal-600" />
          <span>دفترچه یادداشت‌های مشاوره‌ای و بکاپ اطلاعات</span>
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          ثبت نکات مهم آزمون، تحلیل تست‌های غلط، پشتیبان‌گیری کامل از داده‌ها و دانلود نسخه تک‌فایلی مستقل
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Notes */}
        <div className="lg:col-span-2 space-y-4">
          {/* Add Note Form */}
          <form
            onSubmit={handleSubmitNote}
            className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-3"
          >
            <h3 className="text-sm font-black text-slate-900 dark:text-white">
              افزودن یادداشت یا نکته آزمونی
            </h3>

            <input
              type="text"
              placeholder="عنوان یادداشت (مثلاً: نکته دام تستی زیست دوازدهم)"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
            />

            <textarea
              placeholder="متن یادداشت، فرمول‌های فرار یا درس‌های گرفته‌شده از آزمون..."
              rows={3}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-medium resize-none"
            />

            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-2 text-xs font-bold text-slate-600 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={important}
                  onChange={(e) => setImportant(e.target.checked)}
                  className="rounded text-teal-600"
                />
                <span>علامت‌گذاری به عنوان نکته طلایی / مهم ⭐</span>
              </label>

              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-black flex items-center gap-1.5 transition cursor-pointer shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>ثبت یادداشت</span>
              </button>
            </div>
          </form>

          {/* Notes List */}
          <div className="space-y-3">
            {state.notes.length === 0 ? (
              <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 text-center text-slate-400 text-xs">
                هنوز یادداشتی ثبت نکرده‌اید.
              </div>
            ) : (
              state.notes.map((note) => (
                <div
                  key={note.id}
                  className={`bg-white dark:bg-slate-900 rounded-2xl border p-4 shadow-xs transition flex items-start justify-between gap-3 ${
                    note.important
                      ? 'border-amber-400 dark:border-amber-600 bg-amber-50/20'
                      : 'border-slate-200 dark:border-slate-800'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <button
                      type="button"
                      onClick={() => onToggleNoteDone(note.id)}
                      className={`w-5 h-5 rounded-lg border flex items-center justify-center transition mt-0.5 cursor-pointer shrink-0 ${
                        note.done
                          ? 'bg-emerald-600 border-emerald-600 text-white'
                          : 'border-slate-300 dark:border-slate-600'
                      }`}
                    >
                      {note.done && <Check className="w-3.5 h-3.5" />}
                    </button>

                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h4
                          className={`text-xs font-black ${
                            note.done
                              ? 'line-through text-slate-400'
                              : 'text-slate-900 dark:text-white'
                          }`}
                        >
                          {note.title}
                        </h4>
                        {note.important && (
                          <span className="text-[10px] bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300 px-1.5 py-0.5 rounded font-bold">
                            طلایی
                          </span>
                        )}
                        <span className="text-[10px] text-slate-400">{note.date}</span>
                      </div>

                      {note.content && (
                        <p
                          className={`text-xs leading-relaxed ${
                            note.done
                              ? 'text-slate-400 line-through'
                              : 'text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          {note.content}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => onToggleNoteImportant(note.id)}
                      className={`p-1.5 rounded-lg transition cursor-pointer ${
                        note.important ? 'text-amber-500' : 'text-slate-300 hover:text-amber-400'
                      }`}
                    >
                      <Star className="w-4 h-4 fill-current" />
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteNote(note.id)}
                      className="p-1.5 rounded-lg text-slate-300 hover:text-rose-500 transition cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right Col: Backup & Export */}
        <div className="space-y-4">
          {/* Single-file HTML Download Card */}
          <div className="bg-linear-to-br from-teal-700 to-emerald-800 rounded-3xl text-white p-6 shadow-md space-y-4">
            <div className="flex items-center gap-2 font-black text-sm">
              <Download className="w-5 h-5 text-amber-300" />
              <span>دانلود نسخه تک‌فایلی (HTML)</span>
            </div>
            <p className="text-xs text-teal-100 leading-relaxed font-medium">
              یک فایل مستقل HTML بدون نیاز به اینترنت و سرور، با تمامی امکانات (تایمر معکوس، جدول بلوک‌ها، جبرانی‌ها و اطلاعات شما).
            </p>
            <button
              type="button"
              onClick={() => {
                downloadStandaloneTajrobiHTML(state);
                onShowToast('نسخه تک‌فایلی با موفقیت ذخیره شد!', 'success');
              }}
              className="w-full py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs flex items-center justify-center gap-2 transition cursor-pointer shadow-sm"
            >
              <Download className="w-4 h-4 fill-slate-950" />
              <span>دانلود فایل تک‌فایلی مستقل</span>
            </button>
          </div>

          {/* JSON Backup & Restore Card */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4">
            <h3 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Database className="w-4 h-4 text-teal-600" />
              <span>پشتیبان‌گیری و بازیابی داده‌ها</span>
            </h3>

            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              برای انتقال اطلاعات بین چند دستگاه یا نگهداری نسخه‌های پشتیبان هفتگی:
            </p>

            <div className="space-y-2">
              <button
                type="button"
                onClick={handleExportJSON}
                className="w-full py-2.5 rounded-xl border border-teal-600 text-teal-700 dark:text-teal-400 hover:bg-teal-50 dark:hover:bg-teal-950/40 text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>دانلود فایل پشتیبان (JSON)</span>
              </button>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-full py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>بازیابی اطلاعات از فایل پشتیبان</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".json"
                onChange={handleImportJSON}
                className="hidden"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
