import React, { useMemo } from "react";

interface AnimatedBackgroundProps {
  isSpeaking?: boolean;
  isListening?: boolean;
  isThinking?: boolean;
  audioLevel?: number;
}

export const AnimatedBackground: React.FC<AnimatedBackgroundProps> = ({
  isSpeaking = false,
  isListening = false,
  isThinking = false,
  audioLevel = 0,
}) => {
  // Generate random particles once for smooth performance
  const particles = useMemo(() => {
    return Array.from({ length: 24 }, (_, i) => ({
      id: i,
      x: (i * 17 + 23) % 100,
      y: (i * 29 + 13) % 100,
      size: (i % 3) * 1.5 + 2,
      duration: 12 + (i % 8) * 3,
      delay: -(i * 1.5),
      color:
        i % 4 === 0
          ? "rgba(245, 158, 11, 0.7)"
          : i % 4 === 1
          ? "rgba(251, 191, 36, 0.5)"
          : i % 4 === 2
          ? "rgba(56, 189, 248, 0.5)"
          : "rgba(168, 85, 247, 0.4)",
    }));
  }, []);

  return (
    <div
      className="fixed inset-0 pointer-events-none z-0 overflow-hidden select-none"
      aria-hidden="true"
    >
      {/* Deep Gradient Base */}
      <div className="absolute inset-0 bg-[#070A12] bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(245,158,11,0.08),rgba(7,10,18,0))]" />

      {/* Atmospheric Ambient Glow Orbs */}
      <div
        className={`absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 h-[550px] w-[550px] rounded-full blur-[130px] transition-all duration-1000 ${
          isSpeaking
            ? "bg-amber-500/15 scale-110"
            : isListening
            ? "bg-rose-500/15 scale-105"
            : isThinking
            ? "bg-sky-500/15 scale-100"
            : "bg-amber-600/8 scale-95"
        }`}
      />
      <div className="absolute bottom-10 right-1/4 h-[420px] w-[420px] rounded-full bg-sky-500/6 blur-[110px]" />
      <div className="absolute top-1/2 left-10 h-[380px] w-[380px] rounded-full bg-purple-600/5 blur-[120px]" />

      {/* Ambient Thunder AI Lightning Flash (Gentle atmospheric flashes) */}
      <div className="absolute inset-0 bg-gradient-to-b from-amber-400/5 via-sky-400/3 to-transparent opacity-40 animate-thunder-pulse" />

      {/* Central Animated THUNDER AI Logo Watermark */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center justify-center opacity-25 hover:opacity-35 transition-opacity duration-700">
        <div className="relative flex items-center justify-center">
          {/* Orbital Rotating Rings */}
          <div
            className={`absolute h-72 w-72 sm:h-96 sm:w-96 rounded-full border border-dashed border-amber-500/20 ${
              isThinking
                ? "animate-[spin_8s_linear_infinite]"
                : "animate-[spin_32s_linear_infinite]"
            }`}
          />
          <div
            className={`absolute h-84 w-84 sm:h-[420px] sm:w-[420px] rounded-full border border-sky-400/10 ${
              isSpeaking
                ? "animate-[spin_12s_linear_infinite_reverse]"
                : "animate-[spin_48s_linear_infinite_reverse]"
            }`}
          />

          {/* Electric Aura Rings synced with audioLevel */}
          {isSpeaking && (
            <div
              className="absolute rounded-full border border-amber-400/40 transition-transform duration-75"
              style={{
                width: `${260 + audioLevel * 140}px`,
                height: `${260 + audioLevel * 140}px`,
                opacity: 0.3 + audioLevel * 0.5,
              }}
            />
          )}

          {/* Central Stylized Thunder AI Emblem */}
          <div className="relative z-10 flex flex-col items-center justify-center animate-float">
            <svg
              className="h-28 w-28 sm:h-36 sm:w-36 drop-shadow-[0_0_25px_rgba(245,158,11,0.45)]"
              viewBox="0 0 120 120"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <linearGradient id="thunderGrad" x1="0" y1="0" x2="120" y2="120">
                  <stop offset="0%" stopColor="#FDE68A" />
                  <stop offset="45%" stopColor="#F59E0B" />
                  <stop offset="85%" stopColor="#D97706" />
                  <stop offset="100%" stopColor="#38BDF8" />
                </linearGradient>
                <linearGradient id="shieldGrad" x1="0" y1="0" x2="120" y2="120">
                  <stop offset="0%" stopColor="#1E293B" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="#0F172A" stopOpacity="0.4" />
                </linearGradient>
                <filter id="neonGlow" x="-20%" y="-20%" width="140%" height="140%">
                  <feGaussianBlur stdDeviation="4" result="blur" />
                  <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
              </defs>

              {/* Hexagonal Shield Outline */}
              <polygon
                points="60,6 106,30 106,90 60,114 14,90 14,30"
                fill="url(#shieldGrad)"
                stroke="#F59E0B"
                strokeWidth="1.8"
                strokeOpacity="0.4"
                className="transition-all duration-300"
              />

              {/* Inner Concentric Hexagon */}
              <polygon
                points="60,14 98,34 98,86 60,106 22,86 22,34"
                fill="none"
                stroke="#38BDF8"
                strokeWidth="1"
                strokeOpacity="0.25"
                strokeDasharray="4 4"
              />

              {/* High-voltage Lightning Bolt */}
              <path
                d="M66 18 L34 62 L58 62 L48 102 L86 52 L62 52 Z"
                fill="url(#thunderGrad)"
                filter="url(#neonGlow)"
              />

              {/* Electric spark node accents */}
              <circle cx="66" cy="18" r="2.5" fill="#FEF3C7" />
              <circle cx="48" cy="102" r="2.5" fill="#38BDF8" />
              <circle cx="86" cy="52" r="2" fill="#FDE68A" />
            </svg>

            {/* Futuristic "THUNDER AI" Typography */}
            <div className="mt-2 text-center">
              <span className="font-display text-sm sm:text-base font-extrabold tracking-[0.35em] text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-sky-400 uppercase drop-shadow-[0_2px_12px_rgba(245,158,11,0.5)]">
                THUNDER AI
              </span>
              <p className="mt-0.5 text-[9px] font-mono tracking-[0.45em] text-amber-300/60 uppercase">
                EMPATHIC INTELLIGENCE
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Animated Sparks / Stardust */}
      <div className="absolute inset-0">
        {particles.map((p) => (
          <div
            key={p.id}
            className="absolute rounded-full animate-float-spark"
            style={{
              left: `${p.x}%`,
              top: `${p.y}%`,
              width: `${p.size}px`,
              height: `${p.size}px`,
              backgroundColor: p.color,
              boxShadow: `0 0 8px ${p.color}`,
              animationDuration: `${p.duration}s`,
              animationDelay: `${p.delay}s`,
            }}
          />
        ))}
      </div>

      {/* Subtle Digital Grid Overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1E293B08_1px,transparent_1px),linear-gradient(to_bottom,#1E293B08_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-30" />
    </div>
  );
};
