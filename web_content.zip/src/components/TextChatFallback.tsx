import React, { useState, useRef, useEffect } from 'react';
import { Send, Volume2, Sparkles, ExternalLink, AlertCircle, Loader2 } from 'lucide-react';
import { ChatMessage, VoiceGender } from '../types';

interface TextChatFallbackProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => Promise<void>;
  onPlayTts: (text: string, messageId: string) => Promise<void>;
  isLoading: boolean;
  error?: string | null;
  onClearError?: () => void;
  characterGender: VoiceGender;
}

export const TextChatFallback: React.FC<TextChatFallbackProps> = ({
  messages,
  onSendMessage,
  onPlayTts,
  isLoading,
  error,
  onClearError,
  characterGender,
}) => {
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isLoading) return;
    const text = inputText.trim();
    setInputText('');
    onSendMessage(text);
  };

  return (
    <div className="flex flex-col h-full max-w-2xl mx-auto w-full bg-white">
      {/* Messages list */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-center px-4">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-100 to-indigo-100 flex items-center justify-center text-indigo-600 mb-3 shadow-inner">
              <Sparkles className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-800 text-base">Direct Chat & Call Log</h3>
            <p className="text-xs text-slate-500 max-w-sm mt-1">
              Send messages anytime during or outside a call. Blame automatically understands your language and replies in the same language.
            </p>
          </div>
        ) : (
          messages.map((msg) => {
            const isUser = msg.role === 'user';

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} transition-all`}
              >
                <div className="flex items-center gap-2 mb-1 text-[11px] text-slate-400 px-1">
                  <span className="font-semibold text-slate-600">
                    {isUser ? 'You' : `Blame (${characterGender === 'female' ? 'Female' : 'Male'})`}
                  </span>
                  <span>•</span>
                  <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>

                <div
                  className={`relative max-w-[85%] sm:max-w-[78%] rounded-2xl px-4 py-3 text-sm leading-relaxed shadow-xs ${
                    isUser
                      ? 'bg-emerald-600 text-white rounded-br-xs'
                      : 'bg-slate-50 border border-slate-200/90 text-slate-800 rounded-bl-xs'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.text}</p>

                  {/* Web Sources Grounding if available */}
                  {!isUser && msg.sources && msg.sources.length > 0 && (
                    <div className="mt-3 pt-2.5 border-t border-slate-200/80 text-xs">
                      <div className="flex items-center gap-1 text-slate-500 font-medium mb-1.5">
                        <ExternalLink className="w-3 h-3 text-indigo-500" />
                        <span>Sources & References:</span>
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {msg.sources.map((src, i) => (
                          <a
                            key={i}
                            href={src.uri}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-white border border-slate-200 hover:border-indigo-300 text-[11px] text-slate-600 hover:text-indigo-600 transition-colors"
                          >
                            <span className="truncate max-w-[160px]">{src.title}</span>
                          </a>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Audio Listen button */}
                  {!isUser && (
                    <button
                      onClick={() => onPlayTts(msg.text, msg.id)}
                      disabled={msg.isPlaying}
                      title="Listen to response voice"
                      className="mt-2.5 inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-indigo-600 transition-colors cursor-pointer py-1 px-2 rounded-lg hover:bg-white/80 border border-transparent hover:border-slate-200"
                    >
                      {msg.isPlaying ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin text-red-500" />
                          <span className="text-red-600">Playing voice...</span>
                        </>
                      ) : (
                        <>
                          <Volume2 className="w-3.5 h-3.5 text-slate-500" />
                          <span>Listen</span>
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}

        {isLoading && (
          <div className="flex items-center gap-2 text-slate-500 text-xs py-2 px-3 bg-slate-50 rounded-xl max-w-[220px] border border-slate-200">
            <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-600" />
            <span>Blame is thinking...</span>
          </div>
        )}

        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-800 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="font-medium">{error}</p>
              {onClearError && (
                <button
                  onClick={onClearError}
                  className="mt-1 text-red-700 underline hover:text-red-900 cursor-pointer text-[11px]"
                >
                  Dismiss
                </button>
              )}
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input bar */}
      <form onSubmit={handleSubmit} className="p-3 bg-white border-t border-slate-200/90">
        <div className="flex items-center gap-2 bg-slate-50 border border-slate-200/90 rounded-2xl p-1.5 focus-within:border-emerald-500 focus-within:ring-2 focus-within:ring-emerald-100 transition-all">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Type your message..."
            className="flex-1 px-3 py-2 bg-transparent text-sm text-slate-900 placeholder:text-slate-400 focus:outline-hidden"
          />
          <button
            type="submit"
            disabled={!inputText.trim() || isLoading}
            aria-label="Send message"
            className="w-10 h-10 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shadow-xs"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </form>
    </div>
  );
};
