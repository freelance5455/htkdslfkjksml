import React, { useEffect, useRef, useCallback } from 'react';
import { Player, Platform, Capsule, Station, Hazard, Particle, CharacterGender, SkinId, HazardType } from '../types';
import { QUESTIONS_DATA } from '../data/questions';
import { SKINS_DATA } from '../data/skins';
import { sound } from '../utils/audio';

interface PharmaParkourGameProps {
  score: number;
  setScore: React.Dispatch<React.SetStateAction<number>>;
  answeredCount: number;
  setAnsweredCount: React.Dispatch<React.SetStateAction<number>>;
  collectedCount: number;
  setCollectedCount: React.Dispatch<React.SetStateAction<number>>;
  currentStationIndex: number;
  setCurrentStationIndex: React.Dispatch<React.SetStateAction<number>>;
  gender: CharacterGender;
  equippedSkin: SkinId;
  onReachStation: (stationIndex: number) => void;
  onFinishGame: () => void;
  isPaused: boolean;
  isQuizOpen: boolean;
  resetSignal: number;
}

export const PharmaParkourGame: React.FC<PharmaParkourGameProps> = ({
  score: _score,
  setScore,
  answeredCount,
  setAnsweredCount: _setAnsweredCount,
  collectedCount: _collectedCount,
  setCollectedCount,
  currentStationIndex,
  setCurrentStationIndex: _setCurrentStationIndex,
  gender,
  equippedSkin,
  onReachStation,
  onFinishGame,
  isPaused,
  isQuizOpen,
  resetSignal,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Mutable game state held in refs for smooth 60fps canvas loop
  const playerRef = useRef<Player>({
    x: 65,
    y: 0,
    w: 36,
    h: 56,
    vx: 0,
    vy: 0,
    grounded: false,
    face: 1,
    run: 0,
    invulnerableTime: 0,
  });

  const cameraXRef = useRef<number>(0);
  const checkpointXRef = useRef<number>(65);
  const keysRef = useRef<{ left: boolean; right: boolean }>({ left: false, right: false });
  const platformsRef = useRef<Platform[]>([]);
  const capsulesRef = useRef<Capsule[]>([]);
  const stationsRef = useRef<Station[]>([]);
  const hazardsRef = useRef<Hazard[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const toastRef = useRef<{ text: string; time: number }>({ text: '', time: 0 });
  const animFrameIdRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(0);

  // Station spacing: expanded slightly from 640 to 860 as requested
  const STATION_INTERVAL = 860;
  const worldEndRef = useRef<number>(QUESTIONS_DATA.length * STATION_INTERVAL + 500);

  const clamp = (val: number, min: number, max: number) => Math.max(min, Math.min(max, val));

  const getFloorY = useCallback(() => {
    const h = window.innerHeight;
    return h - Math.max(100, h * 0.16);
  }, []);

  // Build the parkour lab world
  const buildWorld = useCallback(() => {
    const totalQ = QUESTIONS_DATA.length;
    const worldEnd = totalQ * STATION_INTERVAL + 500;
    worldEndRef.current = worldEnd;

    const base = getFloorY();
    const plats: Platform[] = [];
    const caps: Capsule[] = [];
    const stats: Station[] = [];
    const hazs: Hazard[] = [];

    let x = 0;
    let i = 0;
    let capId = 0;

    const hazardCycle: HazardType[] = [
      'acid_puddle',
      'plasma_laser',
      'cryo_spill',
      'steam_vent',
    ];

    while (x < worldEnd) {
      const width = 230 + (i % 4) * 20;
      // Jumps and elevations
      const gap = i % 5 === 3 ? 78 : 24;
      const lift = i % 4 === 2 ? 40 : i % 7 === 5 ? 22 : 0;
      const y = base - lift;

      plats.push({ x, y, w: width, h: 32, type: lift > 0 ? 'high' : 'standard' });

      // Medicine capsules placed across platforms
      if (i % 2 === 1) {
        caps.push({
          id: capId++,
          x: x + width * 0.45,
          y: y - 36,
          taken: false,
          colorType: i % 2,
        });
      }
      if (i % 3 === 2) {
        caps.push({
          id: capId++,
          x: x + width * 0.8,
          y: y - 62,
          taken: false,
          colorType: 1,
        });
      }

      // Diverse chemical hazards
      if (i > 1 && i % 4 === 1) {
        const hazardType = hazardCycle[i % hazardCycle.length];
        const hW = hazardType === 'plasma_laser' ? 22 : hazardType === 'steam_vent' ? 28 : 34;
        const hH = hazardType === 'plasma_laser' ? 36 : 24;

        hazs.push({
          x: x + width * 0.65,
          y: y - hH,
          w: hW,
          h: hH,
          type: hazardType,
        });
      }

      x += width + gap;
      i++;
    }

    // Stations spaced comfortably at STATION_INTERVAL (~860px)
    for (let q = 0; q < totalQ; q++) {
      stats.push({
        index: q,
        x: 340 + q * STATION_INTERVAL,
        done: false,
      });
    }

    platformsRef.current = plats;
    capsulesRef.current = caps;
    stationsRef.current = stats;
    hazardsRef.current = hazs;
  }, [getFloorY]);

  // Jump function
  const triggerJump = useCallback(() => {
    if (isPaused || isQuizOpen) return;
    const player = playerRef.current;
    if (player.grounded) {
      player.vy = -620;
      player.grounded = false;
      sound.play('jump');
    }
  }, [isPaused, isQuizOpen]);

  // Particle emission
  const spawnParticles = (x: number, y: number, color: string, count = 14) => {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 1.2 + Math.random() * 3.8;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 1.2,
        life: 30 + Math.random() * 20,
        maxLife: 50,
        color,
        size: 2.5 + Math.random() * 4,
      });
    }
  };

  const rectHit = (
    r1: { x: number; y: number; w: number; h: number },
    r2: { x: number; y: number; w: number; h: number }
  ) => {
    return (
      r1.x < r2.x + r2.w &&
      r1.x + r1.w > r2.x &&
      r1.y < r2.y + r2.h &&
      r1.y + r1.h > r2.y
    );
  };

  // Reset or initialize player
  const resetGame = useCallback(() => {
    buildWorld();
    const base = getFloorY();
    playerRef.current = {
      x: 65,
      y: base - 56,
      w: 36,
      h: 56,
      vx: 0,
      vy: 0,
      grounded: true,
      face: 1,
      run: 0,
      invulnerableTime: 0,
    };
    cameraXRef.current = 0;
    checkpointXRef.current = 65;
    particlesRef.current = [];
    toastRef.current = { text: '', time: 0 };
  }, [buildWorld, getFloorY]);

  useEffect(() => {
    resetGame();
  }, [resetSignal, resetGame]);

  useEffect(() => {
    if (stationsRef.current.length > 0) {
      stationsRef.current.forEach((st, idx) => {
        st.done = idx < answeredCount;
      });
    }
  }, [answeredCount]);

  // Resize canvas
  useEffect(() => {
    const handleResize = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const w = window.innerWidth;
      const h = window.innerHeight;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['ArrowLeft', 'ArrowRight', 'ArrowUp', ' '].includes(e.key)) {
        e.preventDefault();
      }
      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        keysRef.current.left = true;
      }
      if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        keysRef.current.right = true;
      }
      if (e.key === ' ' || e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
        triggerJump();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        keysRef.current.left = false;
      }
      if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        keysRef.current.right = false;
      }
    };

    const handleBlur = () => {
      keysRef.current.left = false;
      keysRef.current.right = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('blur', handleBlur);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('blur', handleBlur);
    };
  }, [triggerJump]);

  // Main physics update
  const update = useCallback(
    (dt: number) => {
      if (isPaused || isQuizOpen) return;

      const player = playerRef.current;
      const speed = 265;
      const keys = keysRef.current;
      const w = window.innerWidth;
      const h = window.innerHeight;
      const base = getFloorY();

      // Horizontal movement
      player.vx = (keys.right ? speed : 0) - (keys.left ? speed : 0);
      if (player.vx !== 0) {
        player.face = Math.sign(player.vx);
        player.run += Math.abs(player.vx) * dt * 0.038;
      }

      player.x += player.vx * dt;
      player.x = clamp(player.x, 0, worldEndRef.current - player.w);

      // Gravity & vertical movement
      player.vy += 1500 * dt;
      player.vy = Math.min(player.vy, 850);
      const oldBottom = player.y + player.h;
      player.y += player.vy * dt;
      player.grounded = false;

      // Platform collisions
      for (const p of platformsRef.current) {
        if (
          player.x + player.w > p.x &&
          player.x < p.x + p.w &&
          oldBottom <= p.y + 8 &&
          player.y + player.h >= p.y &&
          player.vy >= 0
        ) {
          player.y = p.y - player.h;
          player.vy = 0;
          player.grounded = true;
        }
      }

      // Check fall off screen
      if (player.y > h + 90) {
        player.x = checkpointXRef.current;
        player.y = base - player.h - 45;
        player.vy = 0;
        player.grounded = false;
        toastRef.current = { text: 'عدت لنقطة التفتيش! حاول القفز فوق الفجوة 🧪', time: 2.5 };
        sound.play('hazard');
      }

      // Collect medicine capsules
      for (const c of capsulesRef.current) {
        if (!c.taken) {
          const dx = player.x + player.w / 2 - c.x;
          const dy = player.y + player.h / 2 - c.y;
          if (Math.abs(dx) < 28 && Math.abs(dy) < 42) {
            c.taken = true;
            setCollectedCount((prev) => prev + 1);
            setScore((prev) => prev + 10);
            spawnParticles(c.x - cameraXRef.current, c.y, '#ffe18a', 15);
            sound.play('capsule');
          }
        }
      }

      // Hazards collision with custom messages per hazard type
      if (player.invulnerableTime <= 0) {
        for (const hz of hazardsRef.current) {
          if (rectHit(player, { x: hz.x, y: hz.y, w: hz.w, h: hz.h })) {
            player.x = checkpointXRef.current;
            player.y = base - player.h - 40;
            player.vy = 0;
            player.invulnerableTime = 1.0;

            let warningText = 'انتبه من التسريبات المعملية! اقفز فوقها ⚠️';
            let particleColor = '#ff477f';

            if (hz.type === 'acid_puddle') {
              warningText = 'احذر من تسريب الأحماض الفسفورية السامة! 🧪';
              particleColor = '#39ff14';
            } else if (hz.type === 'plasma_laser') {
              warningText = 'انتبه من حاجز الليزر البلازمي! ⚡';
              particleColor = '#ff2df4';
            } else if (hz.type === 'cryo_spill') {
              warningText = 'تسريب نيتروجين سائل فائق التبريد! ❄️';
              particleColor = '#4cf5ff';
            } else if (hz.type === 'steam_vent') {
              warningText = 'نفاث بخار كيميائي حارق! 🔥';
              particleColor = '#ff9800';
            }

            toastRef.current = { text: warningText, time: 2.2 };
            spawnParticles(hz.x - cameraXRef.current, hz.y, particleColor, 18);
            sound.play('hazard');
            break;
          }
        }
      } else {
        player.invulnerableTime -= dt;
      }

      // Station triggers
      if (currentStationIndex < stationsRef.current.length) {
        const station = stationsRef.current[currentStationIndex];
        if (!station.done && player.x + player.w >= station.x) {
          player.x = station.x - player.w - 4;
          player.vx = 0;
          player.vy = 0;
          checkpointXRef.current = player.x;
          onReachStation(currentStationIndex);
        }
      }

      // Finish world
      if (answeredCount >= QUESTIONS_DATA.length && player.x >= worldEndRef.current - 180) {
        onFinishGame();
      }

      // Smooth camera tracking
      cameraXRef.current = clamp(player.x - w * 0.35, 0, worldEndRef.current - w);

      // Particle physics
      particlesRef.current.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.09;
        p.life -= 1;
      });
      particlesRef.current = particlesRef.current.filter((p) => p.life > 0);

      if (toastRef.current.time > 0) {
        toastRef.current.time -= dt;
      }
    },
    [
      isPaused,
      isQuizOpen,
      getFloorY,
      currentStationIndex,
      answeredCount,
      onReachStation,
      onFinishGame,
      setCollectedCount,
      setScore,
    ]
  );

  // Drawing routines
  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = window.innerWidth;
    const h = window.innerHeight;
    const cameraX = cameraXRef.current;
    const floor = getFloorY();
    const player = playerRef.current;

    // Retrieve active skin colors
    const activeSkin = SKINS_DATA.find((s) => s.id === equippedSkin) || SKINS_DATA[0];

    // Background gradient
    const grad = ctx.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0, '#070b22');
    grad.addColorStop(0.55, '#12173f');
    grad.addColorStop(1, '#051126');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);

    // Stars / floating luminescence
    for (let i = 0; i < 60; i++) {
      const sx = (((i * 163 - cameraX * 0.12) % (w + 60)) + w + 60) % (w + 60);
      const sy = 25 + ((i * 73) % Math.max(80, h * 0.55));
      ctx.fillStyle = i % 3 === 0 ? '#7886ff' : '#4cf5ff';
      ctx.globalAlpha = 0.2 + (i % 4) * 0.14;
      ctx.fillRect(sx, sy, i % 5 === 0 ? 3 : 2, i % 5 === 0 ? 3 : 2);
    }
    ctx.globalAlpha = 1;

    // Distant lab structures
    for (let i = 0; i < 12; i++) {
      const bx = i * 220 - ((cameraX * 0.22) % 220);
      const bw = 110 + (i % 3) * 24;
      const bh = h * 0.28 + (i % 4) * 25;
      const by = h * 0.5 - bh;

      ctx.fillStyle = '#0f1a42';
      ctx.fillRect(bx, by, bw, bh);
      ctx.strokeStyle = '#2b3b78';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(bx + 6, by + 8, bw - 12, bh - 16);

      ctx.fillStyle = '#3beeff';
      ctx.globalAlpha = 0.14;
      ctx.fillRect(bx + 14, by + 20, bw - 28, 6);
      ctx.globalAlpha = 1;

      for (let j = 0; j < 3; j++) {
        ctx.fillStyle = j % 2 ? '#a782ff' : '#42d8ff';
        ctx.globalAlpha = 0.16;
        ctx.fillRect(bx + 16 + j * 26, by + 42, 14, 26);
        ctx.globalAlpha = 1;
      }
    }

    // Floating chemical bubbles
    for (let i = 0; i < 14; i++) {
      const bx = (((i * 137 - cameraX * 0.42) % (w + 90)) + w + 90) % (w + 90);
      const by = h * 0.2 + ((i * 59) % Math.max(100, h * 0.38));
      ctx.strokeStyle = '#4cf5ff33';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(bx, by, 5 + (i % 7), 0, Math.PI * 2);
      ctx.stroke();
    }

    // Platforms
    for (const p of platformsRef.current) {
      const px = p.x - cameraX;
      if (px + p.w < -30 || px > w + 30) continue;

      ctx.save();
      ctx.shadowColor = '#4cf5ff';
      ctx.shadowBlur = 10;
      const pGrad = ctx.createLinearGradient(0, p.y, 0, p.y + p.h);
      pGrad.addColorStop(0, '#2d407d');
      pGrad.addColorStop(1, '#0e183d');
      ctx.fillStyle = pGrad;
      ctx.beginPath();
      ctx.roundRect(px, p.y, p.w, p.h, 6);
      ctx.fill();
      ctx.shadowBlur = 0;

      // Cyan neon top trim
      ctx.fillStyle = '#4cf5ff';
      ctx.fillRect(px, p.y, p.w, 3.5);

      // Lab stripes
      ctx.fillStyle = '#9b6bff';
      for (let xx = px + 14; xx < px + p.w - 10; xx += 32) {
        ctx.fillRect(xx, p.y + 12, 14, 3);
      }
      ctx.restore();
    }

    // Diverse Hazards Drawing
    const now = Date.now();
    for (const hz of hazardsRef.current) {
      const hx = hz.x - cameraX;
      if (hx < -40 || hx > w + 40) continue;

      ctx.save();

      if (hz.type === 'acid_puddle') {
        // Fluorescent green acid puddle with bubbling vapors
        ctx.shadowColor = '#39ff14';
        ctx.shadowBlur = 16;
        ctx.fillStyle = '#2de607';

        // Puddle shape
        ctx.beginPath();
        ctx.ellipse(hx + hz.w / 2, hz.y + hz.h - 4, hz.w / 2 + 4, 8, 0, 0, Math.PI * 2);
        ctx.fill();

        // Acid droplets/bubbles
        const bubbleY = Math.sin(now * 0.007 + hz.x) * 6;
        ctx.fillStyle = '#9eff60';
        ctx.beginPath();
        ctx.arc(hx + hz.w * 0.3, hz.y + hz.h - 10 - Math.abs(bubbleY), 3.5, 0, Math.PI * 2);
        ctx.arc(hx + hz.w * 0.7, hz.y + hz.h - 8 - Math.abs(Math.cos(now * 0.006 + hz.x) * 5), 2.5, 0, Math.PI * 2);
        ctx.fill();

        // Caution biohazard label
        ctx.fillStyle = '#000000';
        ctx.font = 'bold 9px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('☣ ACID', hx + hz.w / 2, hz.y + hz.h - 2);
      } else if (hz.type === 'plasma_laser') {
        // Vertical pulsating plasma laser beam
        ctx.shadowColor = '#ff2df4';
        ctx.shadowBlur = 18;

        // Base emitter diode
        ctx.fillStyle = '#4a0e44';
        ctx.fillRect(hx + 2, hz.y + hz.h - 7, hz.w - 4, 7);
        ctx.fillStyle = '#ff2df4';
        ctx.fillRect(hx + 4, hz.y + hz.h - 4, hz.w - 8, 3);

        // Core laser beam
        const beamPulse = 3 + Math.sin(now * 0.015) * 1.5;
        ctx.fillStyle = '#ff2df4';
        ctx.fillRect(hx + hz.w / 2 - beamPulse / 2, hz.y - 12, beamPulse, hz.h + 10);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(hx + hz.w / 2 - 1, hz.y - 12, 2, hz.h + 10);
      } else if (hz.type === 'cryo_spill') {
        // Freezing liquid nitrogen cryogenic puddle with icy spikes
        ctx.shadowColor = '#4cf5ff';
        ctx.shadowBlur = 15;
        ctx.fillStyle = '#78f4ff';

        // Ice stalagmites
        ctx.beginPath();
        ctx.moveTo(hx, hz.y + hz.h);
        ctx.lineTo(hx + hz.w * 0.25, hz.y + 4);
        ctx.lineTo(hx + hz.w * 0.45, hz.y + hz.h);
        ctx.lineTo(hx + hz.w * 0.65, hz.y);
        ctx.lineTo(hx + hz.w * 0.85, hz.y + hz.h);
        ctx.lineTo(hx + hz.w, hz.y + 6);
        ctx.lineTo(hx + hz.w + 4, hz.y + hz.h);
        ctx.closePath();
        ctx.fill();

        // White frost crystals
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(hx + hz.w * 0.6, hz.y + 3, 2, 7);
      } else if (hz.type === 'steam_vent') {
        // Pressurized high-temperature chemical steam nozzle
        ctx.shadowColor = '#ff9800';
        ctx.shadowBlur = 16;

        // Metal nozzle pipe
        ctx.fillStyle = '#2d3748';
        ctx.fillRect(hx + hz.w / 2 - 5, hz.y + hz.h - 10, 10, 10);
        ctx.fillStyle = '#ff5722';
        ctx.fillRect(hx + hz.w / 2 - 4, hz.y + hz.h - 12, 8, 3);

        // Blasting steam clouds
        const steamSpread = 8 + Math.sin(now * 0.01) * 3;
        const gradSteam = ctx.createLinearGradient(0, hz.y + hz.h, 0, hz.y - 10);
        gradSteam.addColorStop(0, '#ff9800');
        gradSteam.addColorStop(0.5, '#ffc107');
        gradSteam.addColorStop(1, 'rgba(255, 235, 59, 0)');
        ctx.fillStyle = gradSteam;
        ctx.beginPath();
        ctx.moveTo(hx + hz.w / 2 - 4, hz.y + hz.h - 12);
        ctx.lineTo(hx + hz.w / 2 - steamSpread, hz.y - 10);
        ctx.lineTo(hx + hz.w / 2 + steamSpread, hz.y - 10);
        ctx.lineTo(hx + hz.w / 2 + 4, hz.y + hz.h - 12);
        ctx.closePath();
        ctx.fill();
      }

      ctx.restore();
    }

    // Capsules
    for (const c of capsulesRef.current) {
      if (c.taken) continue;
      const cx = c.x - cameraX;
      if (cx < -40 || cx > w + 40) continue;

      ctx.save();
      ctx.translate(cx, c.y);
      ctx.rotate(-0.45 + Math.sin(now * 0.004 + c.id) * 0.15);

      ctx.shadowColor = '#ffe18a';
      ctx.shadowBlur = 14;

      // Gold half
      ctx.fillStyle = '#ffe18a';
      ctx.beginPath();
      ctx.roundRect(-9, -18, 18, 36, 9);
      ctx.fill();
      ctx.shadowBlur = 0;

      // Colored half
      ctx.fillStyle = c.colorType === 1 ? '#4cf5ff' : '#7b68ee';
      ctx.beginPath();
      ctx.arc(0, 0, 9, -Math.PI / 2, Math.PI / 2);
      ctx.lineTo(0, 9);
      ctx.fill();

      // Capsule shine
      ctx.fillStyle = '#ffffff';
      ctx.globalAlpha = 0.6;
      ctx.fillRect(-6, -13, 2, 8);
      ctx.globalAlpha = 1;

      ctx.restore();
    }

    // Stations
    for (const s of stationsRef.current) {
      const sx = s.x - cameraX;
      if (sx < -90 || sx > w + 90) continue;

      ctx.save();
      const isDone = s.done;
      const gateColor = isDone ? '#47ffb7' : '#9b6bff';

      ctx.shadowColor = gateColor;
      ctx.shadowBlur = 16;
      ctx.strokeStyle = gateColor;
      ctx.lineWidth = 3;

      ctx.strokeRect(sx - 24, floor - 130, 48, 76);
      ctx.shadowBlur = 0;

      ctx.fillStyle = '#0a1233';
      ctx.fillRect(sx - 19, floor - 125, 38, 66);

      ctx.fillStyle = gateColor;
      ctx.font = 'bold 24px Arial, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(isDone ? '✓' : '?', sx, floor - 83);

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 11px Arial, sans-serif';
      ctx.fillText(`LAB ${String(s.index + 1).padStart(2, '0')}`, sx, floor - 140);

      ctx.fillStyle = gateColor;
      ctx.fillRect(sx - 28, floor - 54, 56, 4);

      ctx.restore();
    }

    // Draw Scientist Player Character with Gender and Skin Support
    ctx.save();
    const px = player.x - cameraX;
    const py = player.y;
    const isMoving = player.grounded && Math.abs(player.vx) > 0;
    const bob = isMoving ? Math.sin(player.run) * 3 : 0;

    ctx.translate(px + player.w / 2, py + bob);
    if (player.face < 0) {
      ctx.scale(-1, 1);
    }

    if (player.invulnerableTime > 0 && Math.floor(now / 80) % 2 === 0) {
      ctx.globalAlpha = 0.4;
    }

    // Skin Aura Glow if present
    if (activeSkin.auraColor) {
      ctx.save();
      ctx.shadowColor = activeSkin.glowColor;
      ctx.shadowBlur = 20;
      ctx.fillStyle = activeSkin.auraColor;
      ctx.beginPath();
      ctx.ellipse(0, 24, 22, 30, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // Shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
    ctx.beginPath();
    ctx.ellipse(0, player.h + 2, 18, 5, 0, 0, Math.PI * 2);
    ctx.fill();

    // Legs (colored per skin)
    ctx.strokeStyle = activeSkin.pantsColor;
    ctx.lineWidth = 7;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(-6, 38);
    ctx.lineTo(-7 + (player.grounded ? Math.sin(player.run) * 5 : 0), 50);
    ctx.moveTo(6, 38);
    ctx.lineTo(8 - (player.grounded ? Math.sin(player.run) * 5 : 0), 50);
    ctx.stroke();

    // Shoes
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(-8, 50);
    ctx.lineTo(-3, 50);
    ctx.moveTo(7, 50);
    ctx.lineTo(12, 50);
    ctx.stroke();

    // Lab Coat (colored per skin)
    ctx.fillStyle = activeSkin.coatColor;
    ctx.beginPath();
    ctx.moveTo(-13, 19);
    ctx.lineTo(-17, 40);
    ctx.lineTo(-10, 43);
    ctx.lineTo(-5, 33);
    ctx.lineTo(0, 45);
    ctx.lineTo(7, 33);
    ctx.lineTo(12, 43);
    ctx.lineTo(17, 40);
    ctx.lineTo(13, 19);
    ctx.closePath();
    ctx.fill();

    // Coat Trim
    ctx.strokeStyle = activeSkin.coatTrim;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(-17, 40);
    ctx.lineTo(17, 40);
    ctx.stroke();

    // Shirt & Tie / Scarf
    ctx.fillStyle = activeSkin.accentColor;
    ctx.beginPath();
    ctx.moveTo(-5, 18);
    ctx.lineTo(5, 18);
    ctx.lineTo(2, 34);
    ctx.lineTo(-2, 34);
    ctx.fill();

    if (gender === 'boy') {
      // Tie for boy
      ctx.fillStyle = '#7a68e8';
      ctx.beginPath();
      ctx.moveTo(0, 21);
      ctx.lineTo(3, 26);
      ctx.lineTo(0, 33);
      ctx.lineTo(-3, 26);
      ctx.fill();
    } else {
      // Scarf / Ribbon for girl
      ctx.fillStyle = '#ff61b6';
      ctx.beginPath();
      ctx.arc(0, 23, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(-3, 25);
      ctx.lineTo(-6, 31);
      ctx.moveTo(3, 25);
      ctx.lineTo(6, 31);
      ctx.strokeStyle = '#ff61b6';
      ctx.lineWidth = 2.5;
      ctx.stroke();
    }

    // Arms
    ctx.strokeStyle = activeSkin.coatColor;
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(-12, 23);
    ctx.lineTo(-19, 32);
    ctx.moveTo(12, 23);
    ctx.lineTo(19, 30);
    ctx.stroke();

    // Head
    ctx.fillStyle = '#f3be94';
    ctx.beginPath();
    ctx.arc(0, 10, 12, 0, Math.PI * 2);
    ctx.fill();

    // Hair Rendering based on Gender
    if (gender === 'boy') {
      // Short modern boy scientist cut
      ctx.fillStyle = '#222340';
      ctx.beginPath();
      ctx.arc(0, 6, 12, Math.PI, Math.PI * 2);
      ctx.lineTo(11, 10);
      ctx.lineTo(5, 4);
      ctx.lineTo(-3, 7);
      ctx.lineTo(-10, 11);
      ctx.fill();
    } else {
      // Girl doctor: high ponytail + cute hair clip
      ctx.fillStyle = '#4a2511';
      ctx.beginPath();
      ctx.arc(0, 6, 12.5, Math.PI, Math.PI * 2);
      ctx.lineTo(12, 10);
      ctx.lineTo(6, 3);
      ctx.lineTo(-4, 7);
      ctx.lineTo(-11, 12);
      ctx.fill();

      // High ponytail extending back
      ctx.beginPath();
      ctx.arc(-11, 2, 7, 0, Math.PI * 2);
      ctx.fill();
      // Hair tie / bow
      ctx.fillStyle = activeSkin.glowColor;
      ctx.beginPath();
      ctx.arc(-8, 3, 3, 0, Math.PI * 2);
      ctx.fill();
    }

    // Face features
    ctx.fillStyle = '#171a37';
    ctx.beginPath();
    ctx.arc(5, 10, 1.8, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#b36c60';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(3, 15);
    ctx.lineTo(7, 15);
    ctx.stroke();

    // Safety Glasses / Goggles (colored per skin)
    ctx.strokeStyle = activeSkin.gogglesColor;
    ctx.lineWidth = 1.8;
    ctx.strokeRect(1, 6, 8, 7);
    ctx.fillStyle = activeSkin.gogglesLens;
    ctx.fillRect(2, 7, 6, 5);

    // Lab coat chest pocket with pipette
    ctx.strokeStyle = '#9aaecf';
    ctx.lineWidth = 1;
    ctx.strokeRect(4, 25, 7, 8);
    ctx.fillStyle = activeSkin.glowColor;
    ctx.fillRect(7, 24, 2, 6);

    ctx.restore();

    // Particles
    for (const p of particlesRef.current) {
      ctx.globalAlpha = clamp(p.life / 30, 0, 1);
      ctx.fillStyle = p.color;
      ctx.fillRect(p.x, p.y, p.size, p.size);
    }
    ctx.globalAlpha = 1;

    // Atmospheric bottom glow
    const floorGlow = ctx.createLinearGradient(0, h - 90, 0, h);
    floorGlow.addColorStop(0, 'rgba(62, 122, 255, 0)');
    floorGlow.addColorStop(1, 'rgba(83, 46, 255, 0.28)');
    ctx.fillStyle = floorGlow;
    ctx.fillRect(0, h - 90, w, 90);

    // Toast banner
    if (toastRef.current.time > 0) {
      ctx.save();
      ctx.font = 'bold 14px "Cairo", sans-serif';
      ctx.textAlign = 'center';
      const text = toastRef.current.text;
      const tw = ctx.measureText(text).width;
      const toastW = tw + 36;
      const toastH = 40;
      const toastY = h * 0.22;

      ctx.fillStyle = 'rgba(8, 17, 46, 0.94)';
      ctx.strokeStyle = '#4cf5ff';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(w / 2 - toastW / 2, toastY, toastW, toastH, 12);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.fillText(text, w / 2, toastY + 25);
      ctx.restore();
    }
  }, [getFloorY, gender, equippedSkin]);

  // Main animation loop
  useEffect(() => {
    let active = true;

    const gameLoop = (timestamp: number) => {
      if (!active) return;
      if (!lastTimeRef.current) lastTimeRef.current = timestamp;
      const dt = Math.min((timestamp - lastTimeRef.current) / 1000, 0.033);
      lastTimeRef.current = timestamp;

      update(dt);
      draw();

      animFrameIdRef.current = requestAnimationFrame(gameLoop);
    };

    animFrameIdRef.current = requestAnimationFrame(gameLoop);

    return () => {
      active = false;
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
    };
  }, [update, draw]);

  // Mobile touch buttons
  const handleTouchLeftDown = (e: React.PointerEvent) => {
    e.preventDefault();
    keysRef.current.left = true;
  };
  const handleTouchLeftUp = (e: React.PointerEvent) => {
    e.preventDefault();
    keysRef.current.left = false;
  };

  const handleTouchRightDown = (e: React.PointerEvent) => {
    e.preventDefault();
    keysRef.current.right = true;
  };
  const handleTouchRightUp = (e: React.PointerEvent) => {
    e.preventDefault();
    keysRef.current.right = false;
  };

  const handleTouchJump = (e: React.PointerEvent) => {
    e.preventDefault();
    triggerJump();
  };

  // State for swapped arrows layout (swapped by default as requested by user)
  const [swappedArrows, setSwappedArrows] = React.useState<boolean>(() => {
    const saved = localStorage.getItem('pharma_parkour_swapped_arrows');
    return saved !== null ? saved === 'true' : true;
  });

  const toggleSwapArrows = (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setSwappedArrows((prev) => {
      const next = !prev;
      localStorage.setItem('pharma_parkour_swapped_arrows', String(next));
      return next;
    });
  };

  return (
    <div className="relative w-full h-full select-none overflow-hidden">
      <canvas ref={canvasRef} className="block w-full h-full touch-none" />

      {/* On-screen touch controls for tablets and mobile */}
      <div
        dir="ltr"
        className="fixed bottom-4 left-0 right-0 z-20 flex items-end justify-between px-4 pointer-events-none md:hidden"
      >
        <div className="flex flex-col items-start gap-1.5 pointer-events-auto">
          {/* Quick toggle to swap arrows anytime */}
          <button
            onPointerDown={toggleSwapArrows}
            title="تبديل أماكن الأسهم"
            aria-label="تبديل أماكن الأسهم"
            className="text-[10px] font-bold text-slate-300 bg-[#08102be6] border border-[#4cf5ff60] rounded-lg px-2 py-0.5 flex items-center gap-1 shadow-sm active:scale-95 cursor-pointer backdrop-blur-md"
          >
            <span>🔄 تبديل الأسهم</span>
          </button>

          {/* Movement Buttons Cluster */}
          <div dir="ltr" className="flex gap-2.5">
            {swappedArrows ? (
              <>
                <button
                  onPointerDown={handleTouchRightDown}
                  onPointerUp={handleTouchRightUp}
                  onPointerLeave={handleTouchRightUp}
                  onPointerCancel={handleTouchRightUp}
                  aria-label="تحرك لليمين"
                  className="w-14 h-14 rounded-2xl bg-[#0e1a3ee8] border border-[#4cf5ff80] text-white text-2xl font-bold active:translate-y-1 shadow-[0_4px_0_#050818] flex items-center justify-center transition-transform cursor-pointer"
                >
                  ▶
                </button>
                <button
                  onPointerDown={handleTouchLeftDown}
                  onPointerUp={handleTouchLeftUp}
                  onPointerLeave={handleTouchLeftUp}
                  onPointerCancel={handleTouchLeftUp}
                  aria-label="تحرك لليسار"
                  className="w-14 h-14 rounded-2xl bg-[#0e1a3ee8] border border-[#4cf5ff80] text-white text-2xl font-bold active:translate-y-1 shadow-[0_4px_0_#050818] flex items-center justify-center transition-transform cursor-pointer"
                >
                  ◀
                </button>
              </>
            ) : (
              <>
                <button
                  onPointerDown={handleTouchLeftDown}
                  onPointerUp={handleTouchLeftUp}
                  onPointerLeave={handleTouchLeftUp}
                  onPointerCancel={handleTouchLeftUp}
                  aria-label="تحرك لليسار"
                  className="w-14 h-14 rounded-2xl bg-[#0e1a3ee8] border border-[#4cf5ff80] text-white text-2xl font-bold active:translate-y-1 shadow-[0_4px_0_#050818] flex items-center justify-center transition-transform cursor-pointer"
                >
                  ◀
                </button>
                <button
                  onPointerDown={handleTouchRightDown}
                  onPointerUp={handleTouchRightUp}
                  onPointerLeave={handleTouchRightUp}
                  onPointerCancel={handleTouchRightUp}
                  aria-label="تحرك لليمين"
                  className="w-14 h-14 rounded-2xl bg-[#0e1a3ee8] border border-[#4cf5ff80] text-white text-2xl font-bold active:translate-y-1 shadow-[0_4px_0_#050818] flex items-center justify-center transition-transform cursor-pointer"
                >
                  ▶
                </button>
              </>
            )}
          </div>
        </div>

        <button
          onPointerDown={handleTouchJump}
          aria-label="اقفز"
          className="pointer-events-auto px-5 h-14 rounded-2xl bg-gradient-to-r from-[#4cf5ff] to-[#9b6bff] text-[#071026] text-lg font-bold border-2 border-white active:translate-y-1 shadow-[0_4px_0_#050818] flex items-center gap-1.5 transition-transform cursor-pointer"
        >
          <span>⬆</span>
          <span>قفز</span>
        </button>
      </div>
    </div>
  );
};
