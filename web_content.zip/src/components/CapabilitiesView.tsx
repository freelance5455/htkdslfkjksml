import { BookOpen, Code2, Compass, Languages, ListChecks } from 'lucide-react';
import type { AssistantDomain, LanguagePreference } from '../lib/jarvisTypes';

interface CapabilitiesViewProps {
  onLaunchPrompt: (opts: {
    prompt: string;
    domain: AssistantDomain;
    language?: LanguagePreference;
  }) => void;
}

const CAPABILITY_GROUPS: Array<{
  title: string;
  subtitle: string;
  domain: AssistantDomain;
  icon: typeof Compass;
  prompts: Array<{ label: string; prompt: string; language?: LanguagePreference }>;
}> = [
  {
    title: 'Project Planning & Problem Solving',
    subtitle: 'Milestones, architectural decisions, troubleshooting, and step-by-step advice',
    domain: 'planning',
    icon: ListChecks,
    prompts: [
      {
        label: 'Plan a 2-week MVP build with clear milestones',
        prompt: 'Help me map out a realistic 2-week MVP launch plan for a personal productivity app, including risks and daily priorities.',
      },
      {
        label: 'Hinglish: Side project aur study balance kaise karu?',
        prompt: 'College studies aur coding side project dono ko bina burnout ke kaise balance karu? Practical weekly plan batao.',
        language: 'hinglish',
      },
      {
        label: 'Troubleshoot slow web app rendering',
        prompt: 'Give me a systematic troubleshooting checklist to find why a React dashboard feels sluggish on mobile.',
      },
    ],
  },
  {
    title: 'Coding & Technical Support',
    subtitle: 'Clean TypeScript, Python, debugging, and system design trade-offs',
    domain: 'coding',
    icon: Code2,
    prompts: [
      {
        label: 'Debouncing vs Throttling with TypeScript examples',
        prompt: 'Explain debouncing vs throttling in React and show clean TypeScript implementations of both.',
      },
      {
        label: 'Hinglish: Python async/await aur threads mein difference',
        prompt: 'Python mein async/await aur multithreading ke beech kya farq hota hai? Example code ke saath Hinglish mein samjhao.',
        language: 'hinglish',
      },
      {
        label: 'Design a clean REST API error pattern',
        prompt: 'Show a practical TypeScript pattern for handling upstream API timeouts and retries gracefully in Express.',
      },
    ],
  },
  {
    title: 'Education & Research',
    subtitle: 'Deep concepts explained clearly with honest uncertainty when facts vary',
    domain: 'education',
    icon: BookOpen,
    prompts: [
      {
        label: 'Explain transformer attention with a simple analogy',
        prompt: 'Explain how transformer self-attention works using an everyday human analogy before showing the math intuition.',
      },
      {
        label: 'Hindi: ब्लैक होल कैसे काम करते हैं?',
        prompt: 'ब्लैक होल क्या होता है और यह कैसे काम करता है? सरल हिंदी में समझाएं।',
        language: 'hindi',
      },
      {
        label: 'Compare SQLite vs Postgres for personal apps',
        prompt: 'Compare SQLite vs PostgreSQL honestly—when should I stick with SQLite and when is Postgres worth the setup?',
      },
    ],
  },
  {
    title: 'Creative Ideas & Multilingual Wit',
    subtitle: 'Natural human-like conversation in English, Hindi, and Hinglish',
    domain: 'general',
    icon: Languages,
    prompts: [
      {
        label: 'Brainstorm 5 creative weekend micro-projects',
        prompt: 'Pitch me 5 genuinely useful weekend micro-projects an engineer can build and actually use every day.',
      },
      {
        label: 'Hinglish: Light humor ke saath subah ki motivation',
        prompt: 'Monday morning coding shuru karne ke liye thode light humor ke saath ek sharp pep-talk do Hinglish mein.',
        language: 'hinglish',
      },
      {
        label: 'Hindi: बेहतर फोकस के लिए 5 व्यावहारिक आदतें',
        prompt: 'काम करते समय ध्यान भटकने से बचने और गहराई से फोकस करने के 5 आसान व्यावहारिक तरीके बताएं।',
        language: 'hindi',
      },
    ],
  },
];

export function CapabilitiesView({ onLaunchPrompt }: CapabilitiesViewProps) {
  return (
    <div className="mx-auto max-w-4xl px-4 py-7 sm:px-6" data-testid="capabilities-view">
      <div className="mb-8">
        <h1 className="font-display text-2xl font-semibold text-slate-50 sm:text-3xl">
          Assistant Capabilities
        </h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-slate-400">
          Pick a prompt to jump straight into a session, or type naturally in English, Hindi, or Hinglish.
        </p>
      </div>

      <div className="grid gap-5 md:grid-cols-2">
        {CAPABILITY_GROUPS.map((group) => {
          const Icon = group.icon;
          return (
            <section
              key={group.title}
              className="flex flex-col rounded-2xl border border-white/8 bg-[#0B1018] p-5"
            >
              <div className="mb-4 flex items-start gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-sky-500/12 text-sky-300">
                  <Icon className="h-5 w-5" />
                </div>
                <div>
                  <h2 className="font-display text-base font-semibold text-slate-100">
                    {group.title}
                  </h2>
                  <p className="mt-0.5 text-xs text-slate-400">{group.subtitle}</p>
                </div>
              </div>

              <div className="space-y-2">
                {group.prompts.map((item) => (
                  <button
                    key={item.label}
                    type="button"
                    onClick={() =>
                      onLaunchPrompt({
                        prompt: item.prompt,
                        domain: group.domain,
                        language: item.language,
                      })
                    }
                    className="min-h-[44px] w-full rounded-xl border border-white/6 bg-[#05070B] px-3.5 py-2.5 text-left text-sm text-slate-200 transition-colors hover:border-sky-400/40 hover:bg-sky-500/10 hover:text-white"
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}
