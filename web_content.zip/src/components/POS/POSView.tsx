import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Plus, 
  Minus, 
  Trash2, 
  AlertCircle, 
  CheckCircle, 
  ArrowRight, 
  Zap, 
  Sparkles,
  ShoppingBag,
  User,
  Phone,
  Tag,
  CreditCard,
  Banknote,
  Smartphone,
  Edit3
} from 'lucide-react';
import { Product, CartItem, ProductCategory, PaymentMethod, SaleInvoice, UserRole } from '../../types';
import { formatTaka, toBnNum } from '../../utils/formatters';

interface POSViewProps {
  products: Product[];
  cart: CartItem[];
  setCart: React.Dispatch<React.SetStateAction<CartItem[]>>;
  onCompleteSale: (invoiceData: Omit<SaleInvoice, 'id' | 'invoiceNo' | 'createdAt'>) => void;
  onOpenAddProduct: () => void;
  onEditProduct?: (product: Product) => void;
  activeRole: UserRole;
  cashierName: string;
}

const CATEGORIES: ('সব' | ProductCategory)[] = [
  'সব',
  'পেঁয়াজ, আলু ও রসুন',
  'তেল ও ঘি',
  'চাল ও ডাল',
  'স্ন্যাক্স ও নুডলস',
  'চা, চিনি ও বেকারি',
  'মসলা ও লবণ',
  'দুগ্ধ ও ডিম',
  'সাবান ও প্রসাধন',
  'অন্যান্য',
];

export const POSView: React.FC<POSViewProps> = ({
  products,
  cart,
  setCart,
  onCompleteSale,
  onOpenAddProduct,
  onEditProduct,
  activeRole,
  cashierName,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'সব' | ProductCategory>('সব');
  
  // Payment and Customer States
  const [paidAmountInput, setPaidAmountInput] = useState<string>('');
  const [discountInput, setDiscountInput] = useState<string>('0');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('CASH');
  const [notes, setNotes] = useState('');

  // Custom Quick Item Form Modal
  const [showCustomItemModal, setShowCustomItemModal] = useState(false);
  const [customName, setCustomName] = useState('');
  const [customPrice, setCustomPrice] = useState('');
  const [customQty, setCustomQty] = useState('1');
  const [customUnit, setCustomUnit] = useState<'কেজি' | 'লিটার' | 'পিস' | 'প্যাকেট'>('কেজি');

  // Filtered Products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchesCategory = selectedCategory === 'সব' || p.category === selectedCategory;
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch = 
        !q ||
        p.nameBn.toLowerCase().includes(q) ||
        p.nameEn.toLowerCase().includes(q) ||
        (p.barcode && p.barcode.includes(q));
      return matchesCategory && matchesSearch;
    });
  }, [products, selectedCategory, searchQuery]);

  // Cart Calculations
  const subtotal = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.lineTotal, 0);
  }, [cart]);

  const discount = useMemo(() => {
    const val = parseFloat(discountInput) || 0;
    return Math.min(subtotal, Math.max(0, val));
  }, [discountInput, subtotal]);

  const netTotal = useMemo(() => {
    return Math.max(0, subtotal - discount);
  }, [subtotal, discount]);

  // Paid amount number
  const paidAmount = useMemo(() => {
    if (paidAmountInput === '') return 0;
    return parseFloat(paidAmountInput) || 0;
  }, [paidAmountInput]);

  // Change Return to Customer (কাস্টমার ফেরত পাবে)
  const changeAmount = useMemo(() => {
    if (paidAmount > netTotal) {
      return +(paidAmount - netTotal).toFixed(2);
    }
    return 0;
  }, [paidAmount, netTotal]);

  // Due Amount (বাকি টাকা)
  const dueAmount = useMemo(() => {
    if (paidAmount < netTotal) {
      return +(netTotal - paidAmount).toFixed(2);
    }
    return 0;
  }, [paidAmount, netTotal]);

  // Total cost for profit calculation
  const totalCost = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.lineCost, 0);
  }, [cart]);

  const grossProfit = useMemo(() => {
    return +(netTotal - totalCost).toFixed(2);
  }, [netTotal, totalCost]);

  // Add product to cart
  const handleAddToCart = (product: Product, quantityToAdd = 1) => {
    setCart((prevCart) => {
      const existingIndex = prevCart.findIndex((item) => item.productId === product.id);
      if (existingIndex > -1) {
        const updated = [...prevCart];
        const existing = updated[existingIndex];
        const newQty = +(existing.quantity + quantityToAdd).toFixed(2);
        updated[existingIndex] = {
          ...existing,
          quantity: newQty,
          lineTotal: +(newQty * existing.sellPrice).toFixed(2),
          lineCost: +(newQty * existing.purchasePrice).toFixed(2),
        };
        return updated;
      } else {
        const newItem: CartItem = {
          id: 'cart-' + Date.now() + '-' + Math.random().toString(36).substring(2, 5),
          productId: product.id,
          nameBn: product.nameBn,
          nameEn: product.nameEn,
          category: product.category,
          purchasePrice: product.purchasePrice,
          sellPrice: product.sellPrice,
          unit: product.unit,
          quantity: quantityToAdd,
          discount: 0,
          lineTotal: +(product.sellPrice * quantityToAdd).toFixed(2),
          lineCost: +(product.purchasePrice * quantityToAdd).toFixed(2),
        };
        return [...prevCart, newItem];
      }
    });
  };

  // Update item quantity in cart
  const handleUpdateQty = (itemId: string, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveItem(itemId);
      return;
    }
    setCart((prevCart) =>
      prevCart.map((item) => {
        if (item.id === itemId) {
          const qty = +newQty.toFixed(2);
          return {
            ...item,
            quantity: qty,
            lineTotal: +(qty * item.sellPrice).toFixed(2),
            lineCost: +(qty * item.purchasePrice).toFixed(2),
          };
        }
        return item;
      })
    );
  };

  // Remove item
  const handleRemoveItem = (itemId: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.id !== itemId));
  };

  // Quick cash preset buttons
  const setExactCash = () => {
    setPaidAmountInput(String(netTotal));
  };

  const handleQuickCash = (amount: number) => {
    setPaidAmountInput(String(amount));
  };

  // Add custom unlisted item
  const handleAddCustomItem = (e: React.FormEvent) => {
    e.preventDefault();
    const price = parseFloat(customPrice);
    const qty = parseFloat(customQty) || 1;
    if (!customName.trim() || isNaN(price) || price <= 0) return;

    const customCartItem: CartItem = {
      id: 'cart-custom-' + Date.now(),
      productId: 'custom-' + Date.now(),
      nameBn: customName.trim(),
      nameEn: 'Custom Item',
      category: 'অন্যান্য',
      purchasePrice: +(price * 0.85).toFixed(2), // Estimated 15% margin
      sellPrice: price,
      unit: customUnit,
      quantity: qty,
      discount: 0,
      lineTotal: +(price * qty).toFixed(2),
      lineCost: +(price * 0.85 * qty).toFixed(2),
    };

    setCart((prev) => [...prev, customCartItem]);
    setCustomName('');
    setCustomPrice('');
    setCustomQty('1');
    setShowCustomItemModal(false);
  };

  // Complete Sale
  const handleProcessSale = () => {
    if (cart.length === 0) return;

    // If due exists and no customer name provided, alert
    if (dueAmount > 0 && !customerName.trim()) {
      alert('বাকি থাকলে কাস্টমারের নাম এবং মোবাইল নম্বর লেখা আবশ্যক!');
      return;
    }

    const effectivePaid = paidAmountInput === '' ? netTotal : paidAmount;
    const finalChange = effectivePaid > netTotal ? +(effectivePaid - netTotal).toFixed(2) : 0;
    const finalDue = effectivePaid < netTotal ? +(netTotal - effectivePaid).toFixed(2) : 0;

    let status: 'PAID' | 'PARTIAL' | 'DUE' = 'PAID';
    if (finalDue > 0) {
      status = effectivePaid > 0 ? 'PARTIAL' : 'DUE';
    }

    onCompleteSale({
      items: cart,
      subtotal,
      discount,
      netTotal,
      paidAmount: effectivePaid,
      changeAmount: finalChange,
      dueAmount: finalDue,
      paymentMethod: finalDue > 0 && effectivePaid === 0 ? 'DUE' : paymentMethod,
      customerName: customerName.trim() || undefined,
      customerPhone: customerPhone.trim() || undefined,
      cashierName,
      totalCost,
      grossProfit,
      status,
      notes: notes.trim() || undefined,
    });

    // Reset payment states
    setPaidAmountInput('');
    setDiscountInput('0');
    setCustomerName('');
    setCustomerPhone('');
    setNotes('');
  };

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-6">
      
      {/* Top Banner Promotional & Quick Notification */}
      <div className="bg-gradient-to-r from-emerald-800 to-emerald-900 rounded-2xl p-4 sm:p-5 text-white mb-6 shadow-md flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="space-y-1 text-center md:text-left">
          <div className="flex items-center justify-center md:justify-start gap-2 text-xs font-semibold text-emerald-200 uppercase tracking-wider">
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>সুপারশপ স্টাইল দ্রুত মেমো সফটওয়্যার</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight">
            মুদি দোকানের সকল পণ্য নির্বাচন করুন ও ১ ক্লিকে মেমো দিন
          </h2>
          <p className="text-xs sm:text-sm text-emerald-100/90 max-w-xl">
            কাস্টমার যেসব পণ্য চাবে ক্লিক করুন, অটোমেটিক ক্যাশ মেমো ও ফেরত টাকার হিসাব তৈরি হবে।
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            onClick={onOpenAddProduct}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs sm:text-sm font-bold shadow-md transition transform active:scale-95"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>+ নতুন পণ্য যুক্ত করুন</span>
          </button>
          <button
            onClick={() => setShowCustomItemModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold border border-white/20 transition shadow-xs"
          >
            <Plus className="w-4 h-4 text-emerald-300" />
            <span>অনিবন্ধিত পণ্য যোগ</span>
          </button>
        </div>
      </div>

      {/* Main 2-Column Grid: Left Product Catalog, Right POS Cart */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Search, Categories, Products Grid (8 cols) */}
        <div className="lg:col-span-7 xl:col-span-8 space-y-4">
          
          {/* Search Bar & Add Product Quick Button */}
          <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="পণ্যের নাম দিয়ে খুঁজুন (যেমন: পেঁয়াজ, তেল, চাল, ডাল)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-600 focus:bg-white transition"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
                >
                  মুছুন
                </button>
              )}
            </div>
            
            <button
              onClick={onOpenAddProduct}
              className="flex items-center justify-center gap-1.5 px-3.5 py-2 bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shrink-0 shadow-xs transition"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>+ নতুন পণ্য</span>
            </button>

            <div className="text-xs text-slate-500 text-right shrink-0 hidden sm:block">
              মোট <strong>{toBnNum(filteredProducts.length)}</strong> টি পণ্য
            </div>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`whitespace-nowrap px-3 py-1.5 rounded-lg text-xs font-medium transition-all shrink-0 ${
                  selectedCategory === cat
                    ? 'bg-emerald-800 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Product Cards Grid (Tazaj Mart Style) */}
          <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4">
            {filteredProducts.map((product) => {
              const inCart = cart.find((i) => i.productId === product.id);
              const isLowStock = product.stock <= product.lowStockAlert;

              return (
                <div
                  key={product.id}
                  className="group relative bg-white rounded-xl border border-slate-200 hover:border-emerald-500 hover:shadow-md transition-all flex flex-col justify-between overflow-hidden p-3"
                >
                  {/* Low Stock Badge */}
                  {isLowStock && (
                    <div className="absolute top-2 left-2 z-10">
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-amber-100 text-amber-800 border border-amber-200">
                        স্টক কম: {toBnNum(product.stock)} {product.unit}
                      </span>
                    </div>
                  )}

                  {/* Edit Product Button */}
                  {onEditProduct && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onEditProduct(product);
                      }}
                      className="absolute top-2 right-2 z-10 w-7 h-7 rounded-full bg-white/95 hover:bg-white text-slate-500 hover:text-emerald-800 shadow-xs flex items-center justify-center border border-slate-200 transition-all opacity-85 sm:opacity-0 group-hover:opacity-100 hover:scale-105"
                      title="পণ্যের নাম, ছবি, দর ও স্টক এডিট করুন"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                  )}

                  {/* Product Image Area */}
                  <div className="relative aspect-square w-full rounded-lg bg-slate-50 mb-2 overflow-hidden flex items-center justify-center">
                    {product.imageUrl ? (
                      <img
                        src={product.imageUrl}
                        alt={product.nameBn}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-200"
                        onError={(e) => {
                          // Fallback container
                          (e.target as HTMLElement).style.display = 'none';
                        }}
                      />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center p-2 text-slate-400 bg-emerald-50/40">
                        <ShoppingBag className="w-8 h-8 text-emerald-400 stroke-[1.5]" />
                        <span className="text-[10px] text-slate-400 mt-1">{product.unit}</span>
                      </div>
                    )}
                  </div>

                  {/* Title & Info */}
                  <div>
                    <h3 className="font-semibold text-slate-900 text-sm leading-snug line-clamp-2">
                      {product.nameBn}
                    </h3>
                    <p className="text-[11px] text-slate-500 truncate mt-0.5">
                      {product.nameEn || product.category}
                    </p>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      স্টক: <strong className={isLowStock ? 'text-amber-600' : 'text-slate-700'}>{toBnNum(product.stock)} {product.unit}</strong>
                    </div>
                  </div>

                  {/* Price and Add Button */}
                  <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between">
                    <div>
                      <span className="text-xs text-slate-500">প্রতি {product.unit}</span>
                      <div className="font-bold text-base text-emerald-800 font-mono tabular-nums leading-none">
                        ৳{toBnNum(product.sellPrice)}
                      </div>
                    </div>

                    {/* Quick Add Button or Stepper if already in cart */}
                    {inCart ? (
                      <div className="flex items-center gap-1 bg-emerald-50 rounded-lg p-0.5 border border-emerald-300">
                        <button
                          onClick={() => handleUpdateQty(inCart.id, inCart.quantity - 1)}
                          className="w-6 h-6 rounded-md bg-white text-emerald-800 flex items-center justify-center hover:bg-emerald-100 shadow-2xs"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-6 text-center text-xs font-bold text-emerald-900 font-mono tabular-nums">
                          {toBnNum(inCart.quantity)}
                        </span>
                        <button
                          onClick={() => handleUpdateQty(inCart.id, inCart.quantity + 1)}
                          className="w-6 h-6 rounded-md bg-emerald-700 text-white flex items-center justify-center hover:bg-emerald-800 shadow-2xs"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => handleAddToCart(product, 1)}
                        className="w-8 h-8 rounded-full bg-emerald-800 text-white flex items-center justify-center hover:bg-emerald-700 shadow-sm transition-transform active:scale-95"
                        title="কার্টে যোগ করুন"
                      >
                        <Plus className="w-4 h-4 stroke-[2.5]" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-slate-300 p-6">
              <ShoppingBag className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="text-sm font-semibold text-slate-600">কোনো পণ্য খুঁজে পাওয়া যায়নি</p>
              <p className="text-xs text-slate-400 mt-1">
                অন্য নামে খুঁজুন অথবা 'অনিবন্ধিত পণ্য যোগ' বাটন ব্যবহার করুন।
              </p>
            </div>
          )}
        </div>

        {/* Right Column: POS Cart & Checkout Panel (4 cols) */}
        <div className="lg:col-span-5 xl:col-span-4 sticky top-20">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-md overflow-hidden flex flex-col">
            
            {/* Cart Header */}
            <div className="bg-emerald-800 text-white p-3.5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-emerald-300" />
                <h3 className="font-bold text-base">চলতি বিক্রয় তালিকা</h3>
                <span className="text-xs bg-emerald-950 px-2 py-0.5 rounded-full text-emerald-200 font-mono">
                  {toBnNum(cart.length)} আইটেম
                </span>
              </div>
              {cart.length > 0 && (
                <button
                  onClick={() => setCart([])}
                  className="text-xs text-emerald-200 hover:text-white underline flex items-center gap-1"
                >
                  <Trash2 className="w-3 h-3" />
                  খালি করুন
                </button>
              )}
            </div>

            {/* Cart Items List */}
            <div className="p-3 max-h-72 overflow-y-auto divide-y divide-slate-100 bg-slate-50/50">
              {cart.length === 0 ? (
                <div className="text-center py-10 text-slate-400">
                  <ShoppingBag className="w-10 h-10 mx-auto mb-2 text-slate-300" />
                  <p className="text-sm font-medium text-slate-600">কার্ট সম্পূর্ণ খালি</p>
                  <p className="text-xs text-slate-400 mt-1">
                    কাস্টমার যা চাবে বাম পাশের পণ্যগুলো থেকে ক্লিক করে যোগ করুন।
                  </p>
                </div>
              ) : (
                cart.map((item) => (
                  <div key={item.id} className="py-2.5 flex items-center justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-semibold text-slate-800 truncate">
                        {item.nameBn}
                      </h4>
                      <div className="text-[11px] text-slate-500 font-mono tabular-nums">
                        ৳{toBnNum(item.sellPrice)} / {item.unit}
                      </div>
                    </div>

                    {/* Quantity Stepper with fractional support */}
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleUpdateQty(item.id, item.quantity - 0.5)}
                        className="w-6 h-6 rounded bg-slate-200 text-slate-700 flex items-center justify-center hover:bg-slate-300 text-xs"
                      >
                        -
                      </button>
                      <input
                        type="number"
                        step="any"
                        value={item.quantity}
                        onChange={(e) => handleUpdateQty(item.id, parseFloat(e.target.value) || 0)}
                        className="w-12 text-center text-xs font-bold font-mono py-1 border border-slate-200 rounded bg-white"
                      />
                      <button
                        onClick={() => handleUpdateQty(item.id, item.quantity + 0.5)}
                        className="w-6 h-6 rounded bg-slate-200 text-slate-700 flex items-center justify-center hover:bg-slate-300 text-xs"
                      >
                        +
                      </button>
                    </div>

                    {/* Line Total */}
                    <div className="text-right shrink-0 min-w-[55px]">
                      <div className="text-xs font-bold text-slate-900 font-mono tabular-nums">
                        ৳{toBnNum(item.lineTotal)}
                      </div>
                    </div>

                    {/* Delete */}
                    <button
                      onClick={() => handleRemoveItem(item.id)}
                      className="text-slate-400 hover:text-red-600 p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              )}
            </div>

            {/* Calculations & Payment Form */}
            {cart.length > 0 && (
              <div className="p-3.5 border-t border-slate-200 bg-white space-y-3">
                
                {/* Subtotal & Discount row */}
                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between text-slate-600">
                    <span>সর্বমোট (Subtotal):</span>
                    <span className="font-mono tabular-nums font-semibold">৳ {toBnNum(subtotal)}</span>
                  </div>

                  {/* Discount Input */}
                  <div className="flex justify-between items-center text-slate-600">
                    <span className="flex items-center gap-1">
                      <Tag className="w-3 h-3 text-slate-400" />
                      ছাড় / ডিসকাউন্ট (৳):
                    </span>
                    <input
                      type="number"
                      min="0"
                      value={discountInput}
                      onChange={(e) => setDiscountInput(e.target.value)}
                      className="w-20 text-right text-xs py-0.5 px-2 border border-slate-300 rounded font-mono"
                    />
                  </div>

                  {/* Net Payable in big font */}
                  <div className="flex justify-between items-center text-base font-bold text-slate-900 pt-1 border-t border-slate-100">
                    <span>মোট বিল (Net Total):</span>
                    <span className="text-lg font-mono tabular-nums text-emerald-800">
                      ৳ {toBnNum(netTotal)}
                    </span>
                  </div>
                </div>

                {/* Cash Paid Input & Quick Presets */}
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 space-y-2">
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-semibold text-slate-700 flex items-center gap-1">
                      <Banknote className="w-3.5 h-3.5 text-emerald-600" />
                      কাস্টমার কত টাকা দিল (Cash Paid)?
                    </label>
                    <button
                      type="button"
                      onClick={setExactCash}
                      className="text-[11px] text-emerald-700 hover:underline font-medium"
                    >
                      সমান টাকা
                    </button>
                  </div>

                  <input
                    type="number"
                    placeholder={`৳ ${netTotal}`}
                    value={paidAmountInput}
                    onChange={(e) => setPaidAmountInput(e.target.value)}
                    className="w-full py-1.5 px-3 text-base font-bold font-mono text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-600"
                  />

                  {/* Quick Preset Buttons */}
                  <div className="flex items-center gap-1 text-xs">
                    {[100, 200, 500, 1000].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => handleQuickCash(amt)}
                        className="flex-1 py-1 bg-white border border-slate-200 rounded text-slate-700 font-mono hover:bg-slate-100 text-[11px]"
                      >
                        ৳{toBnNum(amt)}
                      </button>
                    ))}
                  </div>

                  {/* AUTOMATIC CHANGE RETURN HIGHLIGHT (কাস্টমার ফেরত পাবে) */}
                  {changeAmount > 0 && (
                    <div className="p-2.5 rounded-lg bg-emerald-100/80 border border-emerald-400 text-emerald-950 flex items-center justify-between">
                      <span className="text-xs font-semibold flex items-center gap-1">
                        <CheckCircle className="w-4 h-4 text-emerald-700" />
                        কাস্টমার ফেরত পাবে:
                      </span>
                      <span className="text-lg font-bold font-mono text-emerald-800 tabular-nums">
                        ৳ {toBnNum(changeAmount)}
                      </span>
                    </div>
                  )}

                  {/* AUTOMATIC DUE ALERT & CUSTOMER NAME PROMPT (বকেয়া / বাকি) */}
                  {dueAmount > 0 && (
                    <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-300 text-amber-900 space-y-2">
                      <div className="flex items-center justify-between text-xs font-semibold">
                        <span className="flex items-center gap-1">
                          <AlertCircle className="w-4 h-4 text-amber-700" />
                          বাকি থাকবে (Due Amount):
                        </span>
                        <span className="text-base font-bold font-mono text-amber-800">
                          ৳ {toBnNum(dueAmount)}
                        </span>
                      </div>

                      <div className="space-y-1.5 pt-1 border-t border-amber-200">
                        <div className="relative">
                          <User className="w-3.5 h-3.5 absolute left-2 top-2 text-amber-700" />
                          <input
                            type="text"
                            placeholder="কাস্টমারের নাম (বাধ্যতামূলক)*"
                            value={customerName}
                            onChange={(e) => setCustomerName(e.target.value)}
                            className="w-full pl-7 pr-2 py-1 text-xs bg-white border border-amber-300 rounded focus:ring-1 focus:ring-amber-500"
                            required
                          />
                        </div>
                        <div className="relative">
                          <Phone className="w-3.5 h-3.5 absolute left-2 top-2 text-amber-700" />
                          <input
                            type="tel"
                            placeholder="মোবাইল নম্বর (যেমন: ০১৭১২...)"
                            value={customerPhone}
                            onChange={(e) => setCustomerPhone(e.target.value)}
                            className="w-full pl-7 pr-2 py-1 text-xs bg-white border border-amber-300 rounded focus:ring-1 focus:ring-amber-500"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Optional Customer Name & Phone for normal paid customers */}
                {dueAmount === 0 && (
                  <details className="text-xs text-slate-600">
                    <summary className="cursor-pointer text-slate-500 hover:text-slate-800 py-0.5">
                      + কাস্টমারের নাম ও মোবাইল যোগ করুন (ঐচ্ছিক)
                    </summary>
                    <div className="pt-2 space-y-1.5">
                      <input
                        type="text"
                        placeholder="কাস্টমারের নাম"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        className="w-full px-2.5 py-1 text-xs border border-slate-300 rounded"
                      />
                      <input
                        type="tel"
                        placeholder="মোবাইল নম্বর"
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        className="w-full px-2.5 py-1 text-xs border border-slate-300 rounded"
                      />
                    </div>
                  </details>
                )}

                {/* Payment Method Selector */}
                <div className="flex items-center gap-1.5 text-xs">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('CASH')}
                    className={`flex-1 py-1.5 rounded-lg border text-center font-medium transition ${
                      paymentMethod === 'CASH'
                        ? 'bg-emerald-800 text-white border-emerald-800'
                        : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    নগদ ক্যাশ
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('BKASH')}
                    className={`flex-1 py-1.5 rounded-lg border text-center font-medium transition ${
                      paymentMethod === 'BKASH'
                        ? 'bg-pink-700 text-white border-pink-700'
                        : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    বিকাশ / নগদ
                  </button>
                </div>

                {/* PRIMARY ACTION BUTTON: মেমো তৈরি ও প্রিন্ট করুন */}
                <button
                  type="button"
                  onClick={handleProcessSale}
                  className="w-full py-3 px-4 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 group"
                >
                  <span>মেমো সম্পন্ন ও প্রিন্ট করুন</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>

              </div>
            )}

          </div>
        </div>

      </div>

      {/* Quick Unlisted Item Modal */}
      {showCustomItemModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex justify-between items-center border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-900 text-sm">তালিকাবহির্ভূত পণ্য যোগ করুন</h3>
              <button
                onClick={() => setShowCustomItemModal(false)}
                className="text-slate-400 hover:text-slate-600 text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddCustomItem} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">পণ্যের নাম</label>
                <input
                  type="text"
                  placeholder="যেমন: কাঁচামরিচ, ধনেপাতা, মিষ্টি পান..."
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">বিক্রয় মূল্য (৳)</label>
                  <input
                    type="number"
                    placeholder="৳ ৫০"
                    value={customPrice}
                    onChange={(e) => setCustomPrice(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">একক (Unit)</label>
                  <select
                    value={customUnit}
                    onChange={(e) => setCustomUnit(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="কেজি">কেজি</option>
                    <option value="গ্রাম">গ্রাম</option>
                    <option value="লিটার">লিটার</option>
                    <option value="পিস">পিস</option>
                    <option value="প্যাকেট">প্যাকেট</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">পরিমাণ (Quantity)</label>
                <input
                  type="number"
                  step="any"
                  value={customQty}
                  onChange={(e) => setCustomQty(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono"
                  required
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowCustomItemModal(false)}
                  className="flex-1 py-2 bg-slate-100 text-slate-700 rounded-lg font-medium"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-emerald-800 text-white rounded-lg font-bold hover:bg-emerald-700"
                >
                  কার্টে যোগ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
