import { useEffect, useMemo, useState } from 'react';
import HighScoreTable from './HighScoreTable';
import { useIsTouch } from './ControlsHint';
import type { GameStats, HighScoreEntry } from '@/game/types';
import { cn } from '@/utils/cn';

interface Props {
  stats: GameStats;
  scores: HighScoreEntry[];
  rank: number;
  isNewBest: boolean;
  onRestart: () => void;
  onMenu: () => void;
}

const VERSES = [
  { text: 'Run in such a way as to get the prize.', ref: '1 Corinthians 9:24' },
  { text: 'I have fought the good fight, I have finished the race, I have kept the faith.', ref: '2 Timothy 4:7' },
  { text: 'Let us run with perseverance the race marked out for us.', ref: 'Hebrews 12:1' },
  { text: 'They will run and not grow weary, they will walk and not be faint.', ref: 'Isaiah 40:31' },
  { text: 'Your word is a lamp for my feet, a light on my path.', ref: 'Psalm 119:105' },
];

function useCountUp(target: number, duration = 1100) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    let raf = 0;
    const t0 = performance.now();
    const tick = (t: number) => {
      const k = Math.min(1, (t - t0) / duration);
      const e = 1 - Math.pow(1 - k, 3);
      setVal(Math.round(target * e));
      if (k < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return val;
}

export default function GameOverScreen({ stats, scores, rank, isNewBest, onRestart, onMenu }: Props) {
  const shown = useCountUp(stats.score);
  const touch = useIsTouch();
  const verse = useMemo(() => VERSES[Math.floor(Math.random() * VERSES.length)], []);
  const accuracy = stats.answered ? Math.round((stats.correct / stats.answered) * 100) : 0;
  const mins = Math.floor(stats.time / 60);
  const secs = Math.floor(stats.time % 60);

  const cells = [
    { label: 'Answers', value: `${stats.correct}/${stats.answered}` },
    { label: 'Accuracy', value: `${accuracy}%` },
    { label: 'Max combo', value: `×${stats.maxCombo}` },
    { label: 'Distance', value: `${stats.distance.toLocaleString('en-US')} m` },
    { label: 'Coins', value: String(stats.coins) },
    { label: 'Time', value: `${mins}:${secs.toString().padStart(2, '0')}` },
  ];

  return (
    <div className="absolute inset-0 z-20 flex flex-col overflow-y-auto bg-gradient-to-b from-night/85 via-plum/60 to-night/90 p-3 animate-fade-in scrollbar-thin sm:p-4">
      <div className="panel mx-auto my-auto w-full max-w-lg rounded-3xl p-5 text-center animate-pop-in sm:p-7">
        <div className="font-display text-xs font-black tracking-[0.35em] text-ink-soft">THE RACE IS FINISHED</div>
        <h2 className="mt-1 font-display text-3xl font-black tracking-[0.12em] text-ink sm:text-4xl">RUN OVER</h2>

        <div className="relative mt-3">
          {isNewBest && (
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 rotate-[-4deg] rounded-full bg-wrong px-3 py-0.5 font-display text-[11px] font-black tracking-[0.2em] text-white shadow-lg animate-wiggle">
              ★ NEW BEST ★
            </div>
          )}
          <div className={cn('rounded-2xl border-2 border-gold-dark/50 px-4 pb-3 pt-5', isNewBest ? 'bg-gold/30' : 'bg-white/40')}>
            <div className="text-[10px] font-black uppercase tracking-[0.3em] text-ink-soft">Final score</div>
            <div className="font-display text-5xl font-black tabular-nums text-ink sm:text-6xl">{shown.toLocaleString('en-US')}</div>
            {rank >= 0 && (
              <div className="mt-1 text-xs font-black uppercase tracking-wider text-ink-soft">
                Ranked <span className="text-ink">#{rank + 1}</span> on the board
              </div>
            )}
          </div>
        </div>

        <div className="mt-3 grid grid-cols-3 gap-2">
          {cells.map((c, i) => (
            <div key={c.label} className="rounded-xl border border-gold-dark/30 bg-white/40 px-2 py-2 animate-slide-up" style={{ animationDelay: `${0.1 + i * 0.05}s` }}>
              <div className="text-[9px] font-black uppercase tracking-[0.2em] text-ink-soft">{c.label}</div>
              <div className="font-display text-base font-black text-ink sm:text-lg">{c.value}</div>
            </div>
          ))}
        </div>

        <div className="mt-4 flex flex-col gap-2.5">
          <button
            type="button"
            autoFocus
            onClick={onRestart}
            className="btn-gold animate-pulse-glow rounded-2xl px-6 py-3.5 font-display text-xl font-black tracking-[0.15em] outline-none focus-visible:ring-4 focus-visible:ring-gold-light/70"
          >
            ↻ RUN AGAIN
          </button>
          <div className="flex items-center justify-between gap-3">
            <span className="text-[11px] font-bold uppercase tracking-[0.2em] text-ink-soft">{touch ? 'Ready for another lap?' : 'Space / Enter to restart'}</span>
            <button type="button" onClick={onMenu} className="rounded-xl border-2 border-gold-dark/60 bg-white/40 px-4 py-2 font-display text-xs font-black tracking-wider text-ink hover:bg-white/70">
              ⌂ MENU
            </button>
          </div>
        </div>

        <div className="mt-5 text-left">
          <h3 className="mb-2 font-display text-xs font-black tracking-[0.25em] text-ink-soft">HALL OF RUNNERS</h3>
          <HighScoreTable scores={scores} highlight={rank} limit={10} />
        </div>

        <p className="mt-4 font-display text-[11px] leading-relaxed tracking-wider text-ink-soft">
          "{verse.text}" <span className="whitespace-nowrap">— {verse.ref}</span>
        </p>
      </div>
    </div>
  );
}
