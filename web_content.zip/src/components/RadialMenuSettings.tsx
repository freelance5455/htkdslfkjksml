import React, { useState } from "react";
import {
  Sparkles,
  Compass,
  Sliders,
  RotateCcw,
  CheckCircle2,
  ZoomIn,
  Move,
  Layers,
  Eye,
  EyeOff,
  Mic,
  Camera,
  Paperclip,
  Network,
  Bold,
  Italic,
  MousePointer,
  Clock
} from "lucide-react";
import { RadialMenuConfig, RadialMenuTheme, RadialActionType } from "../types";
import {
  RADIAL_THEMES,
  CONTEXTUAL_RADIAL_ITEMS,
  DEFAULT_RADIAL_MENU_CONFIG,
  getStoredRadialMenuConfig,
  saveStoredRadialMenuConfig,
  renderRadialIcon,
} from "../utils/radialMenuConfig";
import { RadialMenu } from "./RadialMenu";

interface RadialMenuSettingsProps {
  onNotify?: (msg: string) => void;
  onConfigChange?: (cfg: RadialMenuConfig) => void;
}

export const RadialMenuSettings: React.FC<RadialMenuSettingsProps> = ({
  onNotify,
  onConfigChange,
}) => {
  const [config, setConfig] = useState<RadialMenuConfig>(getStoredRadialMenuConfig);
  const [isPreviewOpen, setIsPreviewOpen] = useState<boolean>(true);

  const updateConfig = (patch: Partial<RadialMenuConfig>) => {
    const updated = { ...config, ...patch };
    setConfig(updated);
    saveStoredRadialMenuConfig(updated);
    if (onConfigChange) onConfigChange(updated);
    if (onNotify) onNotify("✓ Radyal Menü tercihleriniz kaydedildi.");
  };

  const toggleActionVisibility = (actionId: string) => {
    const current = config.visibleActions || DEFAULT_RADIAL_MENU_CONFIG.visibleActions || {};
    const updatedVisible = {
      ...current,
      [actionId]: current[actionId] === false ? true : false,
    };
    updateConfig({ visibleActions: updatedVisible });
  };

  const handleReset = () => {
    setConfig(DEFAULT_RADIAL_MENU_CONFIG);
    saveStoredRadialMenuConfig(DEFAULT_RADIAL_MENU_CONFIG);
    if (onConfigChange) onConfigChange(DEFAULT_RADIAL_MENU_CONFIG);
    if (onNotify) onNotify("Radyal Menü ayarları varsayılana sıfırlandı.");
  };

  const themeKeys: RadialMenuTheme[] = [
    "productivity",
    "media",
    "gaming",
    "photo",
    "smarthome",
    "launcher",
  ];

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-start gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 text-white flex items-center justify-center shrink-0 shadow-md">
            <Compass className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-lg font-black text-slate-900 dark:text-white">
                Radyal Menü & Navigasyon Özelleştirme
              </h2>
              <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                Bağlamsal Editör Tetiği
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Yalnızca yazı yazarken otomatik açılan radyal menünün butonlarını, temasını ve konumlandırma davranışlarını özelleştirin.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleReset}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold transition-all shrink-0 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
          <span>Sıfırla</span>
        </button>
      </div>

      {/* Live Preview Box */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-950 text-white border border-slate-800 shadow-2xl space-y-3 relative overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-black uppercase tracking-wider text-slate-200">
              Canlı Ön İzleme (Contextual Live Radial Wheel)
            </span>
          </div>
          <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
            Ölçek: {Math.round(config.scale * 100)}%
          </span>
        </div>

        <div className="p-6 sm:p-10 rounded-2xl bg-slate-900 border border-slate-800/80 min-h-[260px] flex items-center justify-center relative overflow-hidden">
          <RadialMenu
            isOpen={isPreviewOpen}
            onToggle={() => setIsPreviewOpen(!isPreviewOpen)}
            onClose={() => setIsPreviewOpen(false)}
            config={config}
            onUpdateConfig={updateConfig}
            isPreview={true}
          />
        </div>
      </div>

      {/* Action Buttons Visibility Toggle Section */}
      <div className="space-y-3">
        <h3 className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-wider flex items-center gap-2">
          <Sliders className="w-4 h-4 text-amber-500" />
          <span>1. Radyal Çark Araç Görünürlüğü (Custom Actions)</span>
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {CONTEXTUAL_RADIAL_ITEMS.map((item) => {
            const isVisible = config.visibleActions ? config.visibleActions[item.id] !== false : true;

            return (
              <button
                key={item.id}
                type="button"
                onClick={() => toggleActionVisibility(item.id)}
                className={`p-3 rounded-2xl border transition-all text-left flex items-center justify-between gap-2 cursor-pointer ${
                  isVisible
                    ? "bg-amber-50/80 dark:bg-amber-950/40 border-amber-500/80 text-amber-950 dark:text-amber-100 shadow-2xs"
                    : "bg-slate-100 dark:bg-slate-800/50 border-slate-200 dark:border-slate-800 text-slate-400 opacity-60"
                }`}
              >
                <div className="flex items-center gap-2 truncate">
                  <span className={isVisible ? item.color : "text-slate-400"}>
                    {renderRadialIcon(typeof item.icon === "string" ? item.icon : "Sparkles", "w-4 h-4")}
                  </span>
                  <span className="text-xs font-bold truncate">{item.label}</span>
                </div>
                {isVisible ? (
                  <Eye className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
                ) : (
                  <EyeOff className="w-4 h-4 text-slate-400 shrink-0" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Preset Themes Grid */}
      <div className="space-y-3">
        <h3 className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-wider flex items-center gap-2">
          <Layers className="w-4 h-4 text-amber-500" />
          <span>2. Hazır Radyal Menü Temaları (Presets)</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
          {themeKeys.map((themeKey) => {
            const themeDef = RADIAL_THEMES[themeKey];
            const isSelected = config.activeTheme === themeKey;

            return (
              <div
                key={themeKey}
                onClick={() => updateConfig({ activeTheme: themeKey })}
                className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between space-y-3 relative ${
                  isSelected
                    ? "bg-amber-50/70 dark:bg-amber-950/40 border-amber-500 text-amber-950 dark:text-amber-100 shadow-sm ring-2 ring-amber-500/30"
                    : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-700"
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className={`text-[9px] font-black px-2 py-0.5 rounded-full text-white ${themeDef.badgeColor}`}>
                      {themeDef.badge}
                    </span>
                    <h4 className="text-sm font-black text-slate-900 dark:text-white mt-1.5">
                      {themeDef.title}
                    </h4>
                  </div>
                  {isSelected && (
                    <CheckCircle2 className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0" />
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Advanced Tweak Settings (Idle collapse, scale, legacy toggle) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Scale Slider */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-slate-900 dark:text-white">
            <span className="flex items-center gap-1.5">
              <ZoomIn className="w-4 h-4 text-amber-500" />
              <span>Menü Ölçeği</span>
            </span>
            <span className="font-mono text-amber-600 dark:text-amber-400 font-extrabold">
              {Math.round(config.scale * 100)}%
            </span>
          </div>
          <input
            type="range"
            min="0.5"
            max="2.0"
            step="0.05"
            value={config.scale}
            onChange={(e) => updateConfig({ scale: parseFloat(e.target.value) })}
            className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-500"
          />
        </div>

        {/* Idle Auto-Collapse Toggle */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 flex items-center justify-between gap-3">
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-amber-500" />
              <span>Otomatik Zaman Aşımlı Küçülme</span>
            </h4>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
              3 saniye eylemsizlikte radyal menü hafifçe saydamlaşır.
            </p>
          </div>
          <button
            type="button"
            onClick={() => updateConfig({ idleAutoCollapse: !config.idleAutoCollapse })}
            className={`w-11 h-6 rounded-full transition-colors relative shrink-0 cursor-pointer p-0.5 ${
              config.idleAutoCollapse ? "bg-amber-500" : "bg-slate-300 dark:bg-slate-700"
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white shadow-md transition-transform ${
                config.idleAutoCollapse ? "translate-x-5" : "translate-x-0"
              }`}
            />
          </button>
        </div>

        {/* Legacy Menu Toggle */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 flex items-center justify-between gap-3">
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-white">
              Klasik (Eski) Menü
            </h4>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
              Yeni radyal çark yerine sade klasik tekli butonu çalıştırır.
            </p>
          </div>
          <button
            type="button"
            onClick={() => updateConfig({ useLegacyMenu: !config.useLegacyMenu })}
            className={`w-11 h-6 rounded-full transition-colors relative shrink-0 cursor-pointer p-0.5 ${
              config.useLegacyMenu ? "bg-amber-500" : "bg-slate-300 dark:bg-slate-700"
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white shadow-md transition-transform ${
                config.useLegacyMenu ? "translate-x-5" : "translate-x-0"
              }`}
            />
          </button>
        </div>
      </div>
    </div>
  );
};
