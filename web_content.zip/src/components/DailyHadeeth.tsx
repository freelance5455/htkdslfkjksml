import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  Sparkles, 
  Copy, 
  Share2, 
  RotateCw, 
  Check, 
  ShieldCheck, 
  Quote, 
  Compass,
  Calendar
} from 'lucide-react';
import { HadeethItem, getDailyHadeeth, getRandomHadeeth } from '../data/hadeethData';
import { useApp } from '../context/AppContext';
import { triggerVibration } from '../utils/audioFeedback';

export const DailyHadeeth: React.FC = () => {
  const { showToast } = useApp();
  const [currentHadeeth, setCurrentHadeeth] = useState<HadeethItem>(() => getDailyHadeeth());
  const [isRandomMode, setIsRandomMode] = useState<boolean>(false);
  const [isRotating, setIsRotating] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  // Initialize with today's Hadith
  useEffect(() => {
    const today = getDailyHadeeth();
    setCurrentHadeeth(today);
  }, []);

  const handleFetchRandom = () => {
    setIsRotating(true);
    triggerVibration(true, 'tap');
    
    setTimeout(() => {
      const nextHadeeth = getRandomHadeeth(currentHadeeth.id);
      setCurrentHadeeth(nextHadeeth);
      setIsRandomMode(true);
      setIsRotating(false);
      showToast('تم استحضار حديث نبوي شريف آخر 🌿');
    }, 280);
  };

  const handleResetToDaily = () => {
    triggerVibration(true, 'light');
    const today = getDailyHadeeth();
    setCurrentHadeeth(today);
    setIsRandomMode(false);
    showToast('تمت العودة إلى حديث اليوم المقرر 🗓️');
  };

  const handleCopy = async () => {
    triggerVibration(true, 'light');
    const textToCopy = `«حديث نبوي شريف»\n\n${currentHadeeth.narrator}\n«${currentHadeeth.text}»\n\nالمصدر: ${currentHadeeth.source}\nالتصنيف: ${currentHadeeth.topic}\n\n💡 إشراقة وتدبر: ${currentHadeeth.inspiration}\n\nمنقول من تطبيق حصن المسلم`;

    try {
      await navigator.clipboard.writeText(textToCopy);
      setCopied(true);
      showToast('تم نسخ الحديث النبوي الشريف بنجاح ✨');
      setTimeout(() => setCopied(false), 2200);
    } catch {
      showToast('تعذر النسخ تلقائياً');
    }
  };

  const handleShare = async () => {
    triggerVibration(true, 'tap');
    const shareData = {
      title: 'حديث نبوي شريف - حصن المسلم',
      text: `${currentHadeeth.narrator}\n«${currentHadeeth.text}»\n\nالمصدر: ${currentHadeeth.source}\n\n💡 إشراقة: ${currentHadeeth.inspiration}`,
      url: window.location.href,
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch {
        // User cancelled share
      }
    } else {
      handleCopy();
    }
  };

  return (
    <div 
      className="w-full bg-gradient-to-br from-[#052d1f] via-[#042419] to-[#021811] border border-amber-500/40 hover:border-amber-400/60 rounded-3xl p-4 sm:p-5 shadow-xl text-right relative overflow-hidden transition-all group"
      dir="rtl"
    >
      {/* Decorative Islamic Background Glow & Ornament */}
      <div className="absolute top-0 right-0 w-44 h-44 bg-amber-400/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-36 h-36 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

      {/* Card Header: Title & Badges */}
      <div className="flex items-center justify-between gap-2 pb-3 border-b border-emerald-800/50 relative z-10">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-300 p-0.5 flex items-center justify-center shrink-0 shadow-md">
            <div className="w-full h-full bg-[#042017] rounded-[10px] flex items-center justify-center text-amber-300">
              <BookOpen className="w-4.5 h-4.5" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-extrabold text-amber-300 font-cairo">
                {isRandomMode ? 'اقتباس نبوي ملهم' : 'حديث اليوم النبوي'}
              </h3>
              <span className="text-[10px] bg-amber-500/15 text-amber-200 border border-amber-400/30 px-2 py-0.5 rounded-full font-tajawal font-bold">
                {currentHadeeth.topic}
              </span>
            </div>
            <p className="text-[11px] text-emerald-200/70 font-tajawal flex items-center gap-1 mt-0.5">
              <ShieldCheck className="w-3 h-3 text-emerald-400 shrink-0" />
              <span>{currentHadeeth.source}</span>
            </p>
          </div>
        </div>

        {/* Action badges: Reset to daily or Random indicator */}
        <div className="flex items-center gap-1.5 shrink-0">
          {isRandomMode && (
            <button
              onClick={handleResetToDaily}
              className="px-2 py-1 rounded-lg bg-emerald-900/60 hover:bg-emerald-800/80 text-emerald-300 border border-emerald-700/50 text-[10px] font-bold font-cairo flex items-center gap-1 transition-colors cursor-pointer"
              title="العودة لحديث اليوم الثابت"
            >
              <Calendar className="w-3 h-3 text-amber-300" />
              <span>حديث اليوم</span>
            </button>
          )}

          <button
            onClick={handleFetchRandom}
            disabled={isRotating}
            className="p-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/40 transition-all active:scale-95 cursor-pointer flex items-center justify-center"
            title="اقتباس حديث صحيح آخر عشوائياً"
            aria-label="اقتباس حديث آخر"
          >
            <RotateCw className={`w-4 h-4 ${isRotating ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Narrator intro */}
      <div className="pt-3 relative z-10">
        <p className="text-xs font-semibold text-emerald-300/90 font-cairo leading-relaxed flex items-center gap-1.5">
          <Quote className="w-3.5 h-3.5 text-amber-400/80 rotate-180 shrink-0" />
          <span>{currentHadeeth.narrator}</span>
        </p>
      </div>

      {/* The Prophetic Text (النص النبوي الشريف) */}
      <div className="my-2.5 p-3.5 bg-black/35 rounded-2xl border border-emerald-700/30 relative z-10">
        <p className="text-base sm:text-lg font-amiri font-bold text-[#fcf9f2] leading-[2.1] text-justify select-text drop-shadow-[0_1px_3px_rgba(0,0,0,0.5)]">
          «{currentHadeeth.text}»
        </p>
      </div>

      {/* Daily Spiritual Inspiration Box (إشراقة وتدبر) */}
      <div className="p-3 bg-gradient-to-r from-amber-500/10 via-emerald-950/40 to-amber-500/5 border border-amber-400/25 rounded-2xl relative z-10 space-y-1">
        <div className="flex items-center gap-1.5 text-xs font-extrabold text-amber-300 font-cairo">
          <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span>إشراقة وتدبر:</span>
        </div>
        <p className="text-xs text-emerald-100/90 font-tajawal leading-relaxed">
          {currentHadeeth.inspiration}
        </p>
      </div>

      {/* Card Footer: Quick Action Buttons (Copy, Share, Random) */}
      <div className="mt-3 pt-2.5 border-t border-emerald-800/40 flex items-center justify-between gap-2 relative z-10">
        <div className="flex items-center gap-1.5 text-[11px] text-emerald-300/80 font-tajawal">
          <Compass className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span>هدي نبوي يُلهم يومك</span>
        </div>

        <div className="flex items-center gap-2">
          {/* Copy Button */}
          <button
            onClick={handleCopy}
            className="px-2.5 py-1.5 rounded-xl bg-emerald-900/50 hover:bg-emerald-800/70 border border-emerald-700/50 text-emerald-200 text-xs font-bold font-cairo flex items-center gap-1.5 transition-colors cursor-pointer"
            title="نسخ نص الحديث مع التخريج"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-300">تم النسخ</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-amber-300" />
                <span>نسخ</span>
              </>
            )}
          </button>

          {/* Share Button */}
          <button
            onClick={handleShare}
            className="px-2.5 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/40 text-amber-300 text-xs font-bold font-cairo flex items-center gap-1.5 transition-colors cursor-pointer"
            title="مشاركة الحديث الشريف مع الأهل والأصدقاء"
          >
            <Share2 className="w-3.5 h-3.5 text-amber-300" />
            <span>مشاركة</span>
          </button>
        </div>
      </div>
    </div>
  );
};
