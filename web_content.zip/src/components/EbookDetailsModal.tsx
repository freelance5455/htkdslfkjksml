import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Ebook } from '../types';
import {
  X,
  Star,
  ShoppingCart,
  Heart,
  BookOpen,
  Download,
  Share2,
  FileCheck,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Layers,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  ExternalLink,
  BookMarked
} from 'lucide-react';
import { downloadEbookAsHtml } from '../utils/htmlDownloader';

export const EbookDetailsModal: React.FC = () => {
  const {
    selectedEbook,
    setSelectedEbook,
    addToCart,
    toggleWishlist,
    isWishlisted,
    hasAccessToBook,
    setReaderEbook,
    setCheckoutOpen,
    ebooks,
    showToast
  } = useApp();

  const [activeTab, setActiveTab] = useState<'overview' | 'toc' | 'sample' | 'reviews'>('overview');
  const [expandedChapter, setExpandedChapter] = useState<number | null>(1);

  if (!selectedEbook) return null;

  const isFav = isWishlisted(selectedEbook.id);
  const isOwned = hasAccessToBook(selectedEbook.id);

  // Related ebooks (same category or target exam)
  const relatedEbooks = ebooks
    .filter((b) => b.id !== selectedEbook.id && (b.categoryId === selectedEbook.categoryId || b.targetExam.includes(selectedEbook.targetExam)))
    .slice(0, 3);

  const handleBuyNow = () => {
    if (!isOwned) {
      addToCart(selectedEbook);
    }
    setSelectedEbook(null);
    setCheckoutOpen(true);
  };

  const handleDownload = () => {
    downloadEbookAsHtml(selectedEbook, isOwned);
    showToast(`Downloading offline HTML package for "${selectedEbook.title}"`, 'success');
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(
        `NEXA EXAM BOOKS: ${selectedEbook.title} (${selectedEbook.targetExam}) - ₹${selectedEbook.price}`
      );
      showToast('Book details link copied to clipboard!', 'info');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-950/80 backdrop-blur-md transition-opacity"
        onClick={() => setSelectedEbook(null)}
      />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh] z-10 animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Top Bar */}
        <div className="bg-[#0B192C] text-white px-4 py-3 flex items-center justify-between border-b border-[#1E3E62]">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/20 uppercase tracking-wide">
              {selectedEbook.targetExam}
            </span>
            <span className="text-xs text-slate-300 hidden sm:inline">
              {selectedEbook.edition}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={handleShare}
              className="p-1.5 text-slate-300 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
              title="Share Ebook"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <button
              onClick={() => toggleWishlist(selectedEbook.id)}
              className={`p-1.5 rounded-lg hover:bg-slate-800 transition-colors ${
                isFav ? 'text-rose-400' : 'text-slate-300 hover:text-rose-400'
              }`}
              title="Wishlist"
            >
              <Heart className={`w-4 h-4 ${isFav ? 'fill-rose-400' : ''}`} />
            </button>
            <button
              onClick={() => setSelectedEbook(null)}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors ml-2"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Content Scrollable */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Main Top Grid: Cover + Primary Details */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
            {/* Book 3D Cover Visual */}
            <div className="md:col-span-4 flex flex-col items-center">
              <div className="relative w-44 h-60 sm:w-52 sm:h-72 rounded-r-xl rounded-l-xs bg-gradient-to-tr shadow-2xl p-4 flex flex-col justify-between text-white border-l-[8px] border-l-black/50 overflow-hidden"
                style={{
                  backgroundImage: `linear-gradient(135deg, #0B192C 0%, #1E3E62 100%)`
                }}
              >
                {/* Spine highlight */}
                <div className="absolute left-0 top-0 bottom-0 w-2 bg-gradient-to-r from-white/30 to-transparent" />

                <div className="flex items-center justify-between text-[9px] font-black tracking-wider text-amber-300 uppercase">
                  <span>{selectedEbook.targetExam}</span>
                  <span className="bg-black/50 px-1.5 py-0.5 rounded text-white font-mono">
                    {selectedEbook.format}
                  </span>
                </div>

                <div className="my-auto py-3">
                  <h2 className="text-sm sm:text-base font-extrabold text-white leading-tight">
                    {selectedEbook.title}
                  </h2>
                  <p className="text-[10px] text-amber-200/90 mt-1 line-clamp-2">
                    {selectedEbook.subtitle}
                  </p>
                </div>

                <div className="border-t border-white/20 pt-2 flex items-center justify-between text-[9px]">
                  <span className="text-slate-200 font-medium">{selectedEbook.language}</span>
                  <span className="text-amber-300 font-bold">{selectedEbook.pageCount} Pages</span>
                </div>
              </div>

              {/* Status Notice */}
              <div className="mt-3 w-full max-w-[220px] text-center">
                {selectedEbook.hasPdfUploaded ? (
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> PDF Ready & Downloadable
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full">
                    <Clock className="w-3.5 h-3.5 text-amber-600" /> PDF not uploaded yet
                  </span>
                )}
              </div>
            </div>

            {/* Right Information Column */}
            <div className="md:col-span-8 flex flex-col justify-between h-full space-y-4">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-bold text-amber-900 bg-amber-100 px-2.5 py-0.5 rounded-md">
                    {selectedEbook.subCategory}
                  </span>
                  <span className="text-xs font-semibold text-slate-700 bg-slate-100 px-2.5 py-0.5 rounded-md">
                    Language: <strong className="text-blue-900">{selectedEbook.language}</strong>
                  </span>
                  {selectedEbook.isFree && (
                    <span className="text-xs font-extrabold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-md">
                      100% FREE
                    </span>
                  )}
                </div>

                <h1 className="text-lg sm:text-2xl font-black text-[#0B192C] leading-snug mt-2">
                  {selectedEbook.title}
                </h1>
                <p className="text-xs sm:text-sm text-slate-600 mt-1">
                  {selectedEbook.subtitle}
                </p>

                {/* Author & Publisher */}
                <div className="flex items-center gap-4 text-xs text-slate-500 mt-2">
                  <span>Author: <strong className="text-slate-800">{selectedEbook.author}</strong></span>
                  <span>•</span>
                  <span>Publisher: <strong className="text-slate-800">{selectedEbook.publisher}</strong></span>
                </div>

                {/* Rating & Reviews */}
                <div className="flex items-center gap-3 mt-3">
                  <div className="flex items-center gap-1 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-lg">
                    <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                    <span className="text-sm font-bold text-slate-900">{selectedEbook.rating}</span>
                    <span className="text-xs text-slate-500">
                      ({selectedEbook.ratingCount.toLocaleString('en-IN')} verified students)
                    </span>
                  </div>

                  <span className="text-xs text-slate-400">|</span>

                  <div className="text-xs text-slate-600 flex items-center gap-1 font-medium">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    Last Updated: {selectedEbook.lastUpdated}
                  </div>
                </div>

                {/* Specification Badges */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-4">
                  <div className="bg-slate-50 border border-slate-200 p-2 rounded-xl text-center">
                    <span className="block text-[10px] text-slate-400 uppercase font-semibold">Format</span>
                    <span className="text-xs font-bold text-slate-800">{selectedEbook.format}</span>
                  </div>
                  <div className="bg-slate-50 border border-slate-200 p-2 rounded-xl text-center">
                    <span className="block text-[10px] text-slate-400 uppercase font-semibold">Pages</span>
                    <span className="text-xs font-bold text-slate-800">{selectedEbook.pageCount} Pages</span>
                  </div>
                  <div className="bg-slate-50 border border-slate-200 p-2 rounded-xl text-center">
                    <span className="block text-[10px] text-slate-400 uppercase font-semibold">File Size</span>
                    <span className="text-xs font-bold text-slate-800">{selectedEbook.fileSize}</span>
                  </div>
                  <div className="bg-slate-50 border border-slate-200 p-2 rounded-xl text-center">
                    <span className="block text-[10px] text-slate-400 uppercase font-semibold">Offline Access</span>
                    <span className="text-xs font-bold text-emerald-600">Available</span>
                  </div>
                </div>
              </div>

              {/* Price & Purchase Actions */}
              <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <div className="flex items-baseline gap-2">
                    {selectedEbook.isFree ? (
                      <span className="text-2xl font-black text-emerald-600">FREE</span>
                    ) : (
                      <>
                        <span className="text-2xl sm:text-3xl font-black text-[#0B192C]">
                          ₹{selectedEbook.price}
                        </span>
                        <span className="text-sm text-slate-400 line-through">
                          ₹{selectedEbook.originalPrice}
                        </span>
                        <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                          {selectedEbook.discountPercent}% OFF
                        </span>
                      </>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Includes full lifetime digital access & offline study file
                  </p>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  {isOwned ? (
                    <button
                      onClick={() => {
                        setSelectedEbook(null);
                        setReaderEbook(selectedEbook);
                      }}
                      className="flex-1 sm:flex-initial flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-sm px-6 py-3 rounded-xl transition-colors shadow-md"
                    >
                      <BookOpen className="w-4 h-4" />
                      <span>Read Online Now</span>
                    </button>
                  ) : (
                    <>
                      <button
                        onClick={() => addToCart(selectedEbook)}
                        className="flex-1 sm:flex-initial flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm px-4 py-3 rounded-xl transition-colors"
                      >
                        <ShoppingCart className="w-4 h-4 text-amber-400" />
                        <span>Add to Cart</span>
                      </button>
                      <button
                        onClick={handleBuyNow}
                        className="flex-1 sm:flex-initial flex items-center justify-center gap-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs sm:text-sm px-5 py-3 rounded-xl transition-colors shadow-md"
                      >
                        <span>Buy Now</span>
                      </button>
                    </>
                  )}
                </div>
              </div>

              {/* Offline Download Button */}
              <div className="flex items-center justify-between text-xs text-slate-500 border-t border-slate-100 pt-2">
                <span className="flex items-center gap-1.5 text-slate-600 font-medium">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  Official Exam Syllabus Guaranteed
                </span>
                <button
                  onClick={handleDownload}
                  className="font-bold text-amber-800 hover:text-amber-950 hover:underline flex items-center gap-1"
                >
                  <Download className="w-3.5 h-3.5 text-amber-700" />
                  Download Offline Study HTML
                </button>
              </div>
            </div>
          </div>

          {/* Tab Navigation for Detailed Sections */}
          <div className="border-b border-slate-200">
            <nav className="flex items-center gap-4 sm:gap-8 overflow-x-auto">
              {[
                { id: 'overview', label: 'Overview & Features' },
                { id: 'toc', label: `Table of Contents (${selectedEbook.tableOfContents.length})` },
                { id: 'sample', label: 'Sample Chapter Preview' },
                { id: 'reviews', label: `Student Reviews (${selectedEbook.ratingCount})` },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`py-3 text-xs sm:text-sm font-bold border-b-2 whitespace-nowrap transition-colors ${
                    activeTab === tab.id
                      ? 'border-amber-500 text-amber-700'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>

          {/* Tab 1: Overview & Features */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-bold text-[#0B192C] uppercase tracking-wider mb-2">
                  About this Ebook
                </h3>
                <p className="text-slate-700 text-xs sm:text-sm leading-relaxed">
                  {selectedEbook.description}
                </p>
              </div>

              <div>
                <h3 className="text-sm font-bold text-[#0B192C] uppercase tracking-wider mb-3">
                  What is Included in this Ebook
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {selectedEbook.features.map((feature, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-start gap-2.5"
                    >
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span className="text-xs text-slate-800 font-medium">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              {selectedEbook.officialSourceUrl && (
                <div className="p-3.5 bg-blue-50 border border-blue-200 rounded-xl flex items-start gap-3">
                  <AlertCircle className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  <div className="text-xs text-blue-900">
                    <span className="font-bold">Official Exam Source Link: </span>
                    <span>All syllabus points, eligibility criteria, and past paper benchmarks are sourced from </span>
                    <a
                      href={selectedEbook.officialSourceUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="font-bold underline text-blue-700 inline-flex items-center gap-0.5"
                    >
                      {selectedEbook.officialSourceUrl}
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Tab 2: Table of Contents */}
          {activeTab === 'toc' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                <span>Total Chapters: {selectedEbook.tableOfContents.length}</span>
                <span>Complete Syllabus Structure</span>
              </div>
              <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
                {selectedEbook.tableOfContents.map((ch) => {
                  const isExpanded = expandedChapter === ch.chapterNumber;
                  return (
                    <div key={ch.chapterNumber} className="bg-white">
                      <button
                        onClick={() => setExpandedChapter(isExpanded ? null : ch.chapterNumber)}
                        className="w-full text-left px-4 py-3 flex items-center justify-between hover:bg-slate-50 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <span className="w-7 h-7 rounded-lg bg-amber-100 text-amber-900 font-bold text-xs flex items-center justify-center shrink-0">
                            {ch.chapterNumber}
                          </span>
                          <span className="text-xs sm:text-sm font-semibold text-slate-800">
                            {ch.title}
                          </span>
                          {ch.isSample && (
                            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.2 rounded">
                              Sample Free
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-3 text-xs text-slate-400">
                          <span className="hidden sm:inline">Pages {ch.pages}</span>
                          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                        </div>
                      </button>
                      {isExpanded && (
                        <div className="px-14 pb-3 text-xs text-slate-600 bg-slate-50/50">
                          <p>
                            In-depth coverage including conceptual definitions, past 5 years MCQ trends, memory mnemonics, and practice drills for {selectedEbook.targetExam}.
                          </p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Tab 3: Sample Preview */}
          {activeTab === 'sample' && (
            <div className="space-y-4 bg-slate-50 border border-slate-200 rounded-xl p-4 sm:p-5">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <div>
                  <span className="text-xs font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded">
                    Authorized Sample Preview
                  </span>
                  <h3 className="text-sm sm:text-base font-bold text-[#0B192C] mt-1">
                    {selectedEbook.sampleContent.title}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {selectedEbook.sampleContent.chapterName}
                  </p>
                </div>
                <button
                  onClick={handleDownload}
                  className="hidden sm:flex items-center gap-1 text-xs font-bold text-slate-900 bg-amber-400 hover:bg-amber-300 px-3 py-1.5 rounded-lg transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Sample HTML</span>
                </button>
              </div>

              <div className="prose prose-sm max-w-none text-slate-800 text-xs sm:text-sm leading-relaxed">
                <p>{selectedEbook.sampleContent.text}</p>
              </div>

              {/* Sample Questions */}
              <div className="mt-4 pt-3 border-t border-slate-200">
                <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Sample Practice Questions with Solutions
                </h4>
                <div className="space-y-3">
                  {selectedEbook.sampleContent.sampleQuestions.map((q, idx) => (
                    <div key={idx} className="p-3 bg-white border border-slate-200 rounded-xl">
                      <p className="text-xs font-bold text-[#0B192C]">
                        Q{idx + 1}. {q.q}
                      </p>
                      <div className="mt-1.5 text-xs text-emerald-800 font-semibold bg-emerald-50 p-1.5 rounded">
                        Correct Answer: {q.a}
                      </div>
                      <p className="text-[11px] text-slate-600 mt-1 italic">
                        Explanation: {q.explanation}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Tab 4: Student Reviews */}
          {activeTab === 'reviews' && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-2xl font-black text-slate-900">{selectedEbook.rating}</span>
                    <div className="flex text-amber-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-amber-400" />
                      ))}
                    </div>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Based on {selectedEbook.ratingCount.toLocaleString('en-IN')} verified student ratings
                  </p>
                </div>
                <span className="text-xs font-semibold text-emerald-700 bg-emerald-100 px-3 py-1 rounded-full">
                  100% Genuine Reviews
                </span>
              </div>

              {/* Realistic student testimonials */}
              <div className="space-y-3">
                {[
                  {
                    name: 'Manoj Kalita, Nagaon',
                    rating: 5,
                    date: '12 March 2026',
                    text: 'Very helpful book for Assam Direct Recruitment. The Assam GK part and the previous year solved questions with explanations in Assamese made my preparation very easy.',
                    verified: true
                  },
                  {
                    name: 'Rinku Chetia, Dibrugarh',
                    rating: 5,
                    date: '08 March 2026',
                    text: 'Best guide for SLPRB Police SI. Clear formula charts for reasoning and math. The offline HTML download allows reading anywhere without internet.',
                    verified: true
                  },
                  {
                    name: 'Vikash Sharma, Guwahati',
                    rating: 4,
                    date: '28 February 2026',
                    text: 'Content quality is very good. TCS pattern questions matched exactly with Railway NTPC test shifts. Highly recommended!',
                    verified: true
                  }
                ].map((rev, i) => (
                  <div key={i} className="p-3.5 border border-slate-200 rounded-xl bg-white space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900">{rev.name}</span>
                        {rev.verified && (
                          <span className="text-[10px] text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 py-0.2 rounded font-semibold">
                            Verified Buyer
                          </span>
                        )}
                      </div>
                      <span className="text-slate-400 text-[11px]">{rev.date}</span>
                    </div>
                    <div className="flex text-amber-400">
                      {[...Array(rev.rating)].map((_, idx) => (
                        <Star key={idx} className="w-3 h-3 fill-amber-400" />
                      ))}
                    </div>
                    <p className="text-xs text-slate-600">{rev.text}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Related Ebooks */}
          {relatedEbooks.length > 0 && (
            <div className="pt-4 border-t border-slate-200">
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">
                Students Also Preparing For {selectedEbook.targetExam} Bought:
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {relatedEbooks.map((rel) => (
                  <div
                    key={rel.id}
                    onClick={() => setSelectedEbook(rel)}
                    className="p-3 rounded-xl border border-slate-200 hover:border-amber-400 bg-white hover:bg-amber-50/20 cursor-pointer transition-all flex items-center gap-3"
                  >
                    <div className={`w-10 h-14 rounded bg-gradient-to-br ${rel.coverGradient} flex items-center justify-center text-white text-[7px] font-bold text-center p-1 shrink-0`}>
                      {rel.targetExam}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-bold text-slate-900 truncate">{rel.title}</h4>
                      <p className="text-[11px] text-slate-500">₹{rel.price} • {rel.language}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
