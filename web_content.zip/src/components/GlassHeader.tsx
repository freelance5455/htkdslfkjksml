import React, { useEffect, useState } from 'react';
import { Sparkles, Wifi, BatteryMedium, FolderHeart, LogIn, LogOut, ShieldCheck, Zap } from 'lucide-react';
import { auth, googleProvider, signInWithPopup, signOut } from '../firebase';
import { User, onAuthStateChanged } from 'firebase/auth';

interface GlassHeaderProps {
  onOpenSaved: () => void;
  savedCount: number;
}

export const GlassHeader: React.FC<GlassHeaderProps> = ({ onOpenSaved, savedCount }) => {
  const [user, setUser] = useState<User | null>(null);
  const [currentTime, setCurrentTime] = useState<string>('09:41');
  const [authLoading, setAuthLoading] = useState(false);

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateClock();
    const interval = setInterval(updateClock, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    return () => unsubscribe();
  }, []);

  const handleSignIn = async () => {
    try {
      setAuthLoading(true);
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      console.error('Sign-in error:', err);
    } finally {
      setAuthLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.error('Sign-out error:', err);
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-2xl bg-[#090b14]/75 border-b border-white/[0.08] shadow-[0_4px_30px_rgba(0,0,0,0.5)]">
      {/* Android-style top status bar */}
      <div className="max-w-7xl mx-auto px-4 py-1 flex items-center justify-between text-[11px] text-slate-400/90 font-mono tracking-wider border-b border-white/[0.04]">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-slate-300">{currentTime}</span>
          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-sans">
            5G ULTRA
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[10px] text-cyan-400/90 hidden sm:inline flex items-center gap-1">
            <Zap className="w-3 h-3 text-cyan-400 inline" />
            VEO & GEMINI 3.8 ENGINE
          </span>
          <div className="flex items-center gap-1.5">
            <Wifi className="w-3.5 h-3.5 text-slate-400" />
            <BatteryMedium className="w-4 h-4 text-slate-300" />
            <span>98%</span>
          </div>
        </div>
      </div>

      {/* Main glass navigation bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
        {/* Brand identity */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 via-cyan-500 to-pink-500 p-[1.5px] shadow-[0_0_20px_rgba(99,102,241,0.5)] animate-pulse-glow">
              <div className="w-full h-full rounded-[14px] bg-[#0c0e1a] flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-cyan-300" />
              </div>
            </div>
            <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-[#090b14]" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-extrabold tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
                UGC Ad Studio
              </h1>
              <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-full bg-gradient-to-r from-indigo-500/20 to-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                16s Video
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              Fast-paced e-commerce video ads with Search Grounding & TTS
            </p>
          </div>
        </div>

        {/* Right Action buttons & Firebase Auth */}
        <div className="flex items-center gap-2.5">
          {/* Saved Ads Drawer toggle */}
          <button
            onClick={onOpenSaved}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] border border-white/[0.1] text-xs font-medium text-slate-200 transition-all shadow-sm active:scale-95"
            title="Saved UGC Ads"
          >
            <FolderHeart className="w-4 h-4 text-pink-400" />
            <span className="hidden sm:inline">My Ads</span>
            {savedCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-pink-500/30 text-pink-300 text-[10px] font-bold border border-pink-500/40">
                {savedCount}
              </span>
            )}
          </button>

          {/* Firebase Authentication */}
          {user ? (
            <div className="flex items-center gap-2 pl-1">
              <div className="flex items-center gap-2 px-2.5 py-1 rounded-xl bg-white/[0.05] border border-white/[0.08]">
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.displayName || 'User'}
                    className="w-6 h-6 rounded-full border border-cyan-500/40 object-cover"
                  />
                ) : (
                  <div className="w-6 h-6 rounded-full bg-indigo-600/40 flex items-center justify-center text-[10px] font-bold text-indigo-200">
                    {user.email?.slice(0, 1).toUpperCase()}
                  </div>
                )}
                <span className="text-xs text-slate-300 max-w-[100px] truncate hidden md:inline">
                  {user.displayName || user.email?.split('@')[0]}
                </span>
                <span className="w-2 h-2 rounded-full bg-emerald-400" title="Firestore Connected" />
              </div>
              <button
                onClick={handleSignOut}
                className="p-1.5 rounded-xl bg-white/[0.04] hover:bg-rose-500/20 text-slate-400 hover:text-rose-300 border border-white/[0.08] transition-all"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={handleSignIn}
              disabled={authLoading}
              className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-indigo-500/20 to-cyan-500/20 hover:from-indigo-500/30 hover:to-cyan-500/30 text-cyan-200 text-xs font-semibold border border-cyan-500/40 transition-all active:scale-95 shadow-[0_0_15px_rgba(99,102,241,0.2)]"
            >
              <LogIn className="w-4 h-4 text-cyan-300" />
              <span>{authLoading ? 'Signing in...' : 'Sign In'}</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
