import type { ArenaId, Quality } from "../game/types";
import { ARENAS } from "../game/types";
import { BoltIcon, GearIcon, InfoIcon, KeyboardIcon, PlayIcon, SoundOffIcon, SoundOnIcon, TrophyIcon } from "./icons";

interface MainMenuProps {
  arena: ArenaId;
  quality: Quality;
  muted: boolean;
  volume: number;
  onArena: (a: ArenaId) => void;
  onQuality: (q: Quality) => void;
  onToggleMute: () => void;
  onVolume: (v: number) => void;
  onStart: () => void;
  onGuide: () => void;
  onSettings: () => void;
  onNotes: () => void;
}

const QUALITIES: { id: Quality; label: string; hint: string }[] = [
  { id: "low", label: "LOW", hint: "Best FPS · no shadows" },
  { id: "medium", label: "MED", hint: "Balanced · 1024 shadows" },
  { id: "high", label: "HIGH", hint: "Sharpest · 2048 shadows" },
];

function FighterCard({
  name,
  epithet,
  weapon,
  style,
  color,
  align,
}: {
  name: string;
  epithet: string;
  weapon: string;
  style: string;
  color: string;
  align: "left" | "right";
}) {
  return (
    <div
      className={`panel panel-notch relative flex-1 overflow-hidden px-3 py-2.5 ${align === "right" ? "text-right" : "text-left"}`}
      style={{ borderColor: `${color}44` }}
    >
      <div
        className="pointer-events-none absolute inset-0 opacity-40"
        style={{ background: `radial-gradient(120% 100% at ${align === "left" ? "0%" : "100%"} 0%, ${color}33, transparent 60%)` }}
      />
      <div className={`relative flex items-center gap-2 ${align === "right" ? "flex-row-reverse" : ""}`}>
        <span
          className="grid h-7 w-7 shrink-0 place-items-center rounded-sm border text-[10px] font-black"
          style={{ borderColor: `${color}77`, color, background: `${color}18`, boxShadow: `0 0 14px ${color}33` }}
        >
          {name.slice(0, 1)}
        </span>
        <div className="min-w-0">
          <div className="font-display truncate text-[13px] font-bold tracking-[0.18em]" style={{ color }}>
            {name}
          </div>
          <div className="truncate text-[8px] uppercase tracking-[0.16em] text-white/45">{epithet}</div>
        </div>
      </div>
      <div className={`relative mt-2 flex gap-3 text-[8px] uppercase tracking-[0.12em] ${align === "right" ? "flex-row-reverse" : ""}`}>
        <div>
          <div className="text-white/35">Weapon</div>
          <div className="font-semibold text-white/80">{weapon}</div>
        </div>
        <div className={align === "right" ? "text-left" : "text-right"}>
          <div className="text-white/35">Style</div>
          <div className="font-semibold text-white/80">{style}</div>
        </div>
      </div>
    </div>
  );
}

export function MainMenu({
  arena,
  quality,
  muted,
  volume,
  onArena,
  onQuality,
  onToggleMute,
  onVolume,
  onStart,
  onGuide,
  onSettings,
  onNotes,
}: MainMenuProps) {
  return (
    <div className="absolute inset-0 z-30 overflow-y-auto overflow-x-hidden scroll-thin">
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-[#04060b]/95 via-[#04060b]/70 to-transparent" />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#04060b] via-transparent to-[#04060b]/70" />
      <div className="pointer-events-none absolute inset-y-0 left-0 w-[3px] bg-gradient-to-b from-transparent via-gold/60 to-transparent" />

      <div className="relative mx-auto flex min-h-full w-full max-w-2xl flex-col justify-start px-4 py-5 sm:justify-center sm:px-8 sm:py-8 lg:mr-auto lg:ml-[max(2rem,calc(50vw-36rem))]">
        {/* brand row */}
        <div className="mb-4 flex items-center justify-between gap-3 sm:mb-6">
          <div className="flex items-center gap-2">
            <span className="grid h-7 w-7 place-items-center border border-gold/50 bg-gold/10">
              <TrophyIcon className="h-3.5 w-3.5 text-gold" />
            </span>
            <div className="leading-tight">
              <div className="font-display text-[10px] font-bold tracking-[0.34em] text-gold/90">TITAN ARENA</div>
              <div className="text-[7px] uppercase tracking-[0.28em] text-white/35">Local multiplayer · 2 players</div>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="hidden items-center gap-1 rounded-full border border-emerald-400/30 bg-emerald-400/10 px-2 py-1 text-[7px] font-bold tracking-[0.16em] text-emerald-300 sm:flex">
              <span className="h-1 w-1 rounded-full bg-emerald-400" /> OFFLINE READY
            </span>
            <button
              type="button"
              onClick={onToggleMute}
              aria-label={muted ? "Unmute" : "Mute"}
              className="btn-ghost grid h-8 w-8 place-items-center rounded-sm"
            >
              {muted ? <SoundOffIcon className="h-3.5 w-3.5" /> : <SoundOnIcon className="h-3.5 w-3.5" />}
            </button>
            <button
              type="button"
              onClick={onSettings}
              aria-label="Settings"
              className="btn-ghost grid h-8 w-8 place-items-center rounded-sm"
            >
              <GearIcon className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>

        {/* title */}
        <div className="anim-rise">
          <div className="mb-1 flex items-center gap-2 text-[8px] font-bold uppercase tracking-[0.4em] text-gold/70 sm:text-[10px]">
            <span className="h-px w-6 bg-gold/50" /> A mythic duel <span className="h-px w-6 bg-gold/50" />
          </div>
          <h1 className="font-display gold-text text-[clamp(32px,8vw,64px)] font-black leading-[0.92] tracking-[0.02em]">
            GODS OF WAR
          </h1>
          <div className="mt-1 flex items-center gap-2 sm:gap-3">
            <span className="h-px w-8 bg-gradient-to-r from-transparent to-gold/70 sm:w-16" />
            <h2 className="font-display text-[clamp(13px,3.4vw,24px)] font-bold tracking-[0.42em] text-white/85">
              TITAN ARENA
            </h2>
            <span className="h-px flex-1 bg-gradient-to-r from-gold/70 to-transparent" />
          </div>
          <p className="mt-2 max-w-md text-[10px] leading-relaxed text-white/55 sm:text-xs">
            Two champions. One sacred arena. Aether of the Azure Sky versus Inferno of the Burning Forge —
            a local two-player 3D duel built for touch. First to two rounds claims the arena.
          </p>
        </div>

        {/* actions */}
        <div className="mt-4 flex flex-col gap-2 sm:mt-5 sm:flex-row sm:items-stretch">
          <button
            type="button"
            onClick={onStart}
            className="btn-gold group relative flex items-center justify-center gap-2 overflow-hidden rounded-sm px-5 py-3 text-[12px] font-black tracking-[0.2em] sm:min-w-[260px] sm:text-sm"
          >
            <PlayIcon className="h-4 w-4" />
            ENTER THE ARENA
            <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/50 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
          </button>
          <div className="grid grid-cols-2 gap-2 sm:flex">
            <button
              type="button"
              onClick={onGuide}
              className="btn-ghost flex items-center justify-center gap-1.5 rounded-sm px-3 py-3 text-[10px] font-bold tracking-[0.16em]"
            >
              <KeyboardIcon className="h-3.5 w-3.5" /> HOW TO PLAY
            </button>
            <button
              type="button"
              onClick={onNotes}
              className="btn-ghost flex items-center justify-center gap-1.5 rounded-sm px-3 py-3 text-[10px] font-bold tracking-[0.16em]"
            >
              <InfoIcon className="h-3.5 w-3.5" /> TECH NOTES
            </button>
          </div>
        </div>

        {/* selectors */}
        <div className="mt-4 grid gap-2 sm:mt-5 sm:grid-cols-[1.4fr_1fr]">
          <div className="panel panel-notch p-2.5">
            <div className="mb-1.5 flex items-center justify-between">
              <span className="text-[8px] font-bold tracking-[0.24em] text-gold/80">CHOOSE YOUR ARENA</span>
              <span className="text-[7px] uppercase tracking-[0.16em] text-white/30">2 battlegrounds</span>
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              {(Object.keys(ARENAS) as ArenaId[]).map((id) => {
                const a = ARENAS[id];
                const active = arena === id;
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => onArena(id)}
                    className="group relative overflow-hidden rounded-sm border p-2 text-left transition"
                    style={{
                      borderColor: active ? "#d9b36a" : "rgba(255,255,255,0.12)",
                      background: active
                        ? "linear-gradient(135deg, rgba(217,179,106,0.18), rgba(10,14,20,0.9))"
                        : "rgba(8,11,17,0.7)",
                    }}
                  >
                    <div
                      className="pointer-events-none absolute inset-0 opacity-70"
                      style={{
                        background:
                          id === "olympus"
                            ? "radial-gradient(120% 100% at 20% 0%, rgba(73,216,255,0.22), transparent 60%)"
                            : "radial-gradient(120% 100% at 20% 0%, rgba(255,106,42,0.22), transparent 60%)",
                      }}
                    />
                    <div className="relative flex items-center justify-between gap-1">
                      <span className="font-display truncate text-[9px] font-bold tracking-[0.12em] text-white/90">
                        {a.name}
                      </span>
                      <span
                        className="grid h-3.5 w-3.5 shrink-0 place-items-center rounded-full border text-[7px]"
                        style={{
                          borderColor: active ? "#d9b36a" : "rgba(255,255,255,0.2)",
                          background: active ? "#d9b36a" : "transparent",
                          color: "#1a1206",
                        }}
                      >
                        {active ? "✓" : ""}
                      </span>
                    </div>
                    <div className="relative mt-0.5 truncate text-[7px] uppercase tracking-[0.1em] text-white/40">
                      {a.subtitle}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="panel panel-notch p-2.5">
            <div className="mb-1.5 flex items-center justify-between">
              <span className="text-[8px] font-bold tracking-[0.24em] text-gold/80">GRAPHICS</span>
              <span className="text-[7px] uppercase tracking-[0.16em] text-white/30">Mobile tuned</span>
            </div>
            <div className="grid grid-cols-3 gap-1">
              {QUALITIES.map((q) => (
                <button
                  key={q.id}
                  type="button"
                  onClick={() => onQuality(q.id)}
                  className="rounded-sm border px-1 py-1.5 text-center transition"
                  style={{
                    borderColor: quality === q.id ? "#d9b36a" : "rgba(255,255,255,0.12)",
                    background: quality === q.id ? "rgba(217,179,106,0.16)" : "rgba(255,255,255,0.02)",
                  }}
                >
                  <div className="text-[9px] font-black tracking-[0.1em] text-white/85">{q.label}</div>
                  <div className="mt-0.5 text-[6px] uppercase leading-tight tracking-[0.06em] text-white/35">{q.hint}</div>
                </button>
              ))}
            </div>
            <div className="mt-2 flex items-center gap-2">
              <button
                type="button"
                onClick={onToggleMute}
                className="btn-ghost flex items-center gap-1 rounded-sm px-2 py-1 text-[8px] font-bold tracking-[0.1em]"
              >
                {muted ? <SoundOffIcon className="h-3 w-3" /> : <SoundOnIcon className="h-3 w-3" />}
                {muted ? "MUTED" : "SOUND ON"}
              </button>
              <input
                aria-label="Volume"
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={volume}
                onChange={(e) => onVolume(Number(e.target.value))}
                className="min-w-0 flex-1"
              />
            </div>
          </div>
        </div>

        {/* fighter dossiers */}
        <div className="mt-3 flex items-stretch gap-2">
          <FighterCard
            name="AETHER"
            epithet="Champion of the Azure Sky"
            weapon="Aether Blade"
            style="Swift · Arcane"
            color="#54e2ff"
            align="left"
          />
          <div className="flex shrink-0 flex-col items-center justify-center px-0.5">
            <BoltIcon className="h-4 w-4 text-gold/70" />
            <span className="font-display mt-0.5 text-[8px] font-black tracking-[0.1em] text-gold/80">VS</span>
          </div>
          <FighterCard
            name="INFERNO"
            epithet="Tyrant of the Burning Forge"
            weapon="Twin Cleaver"
            style="Heavy · Brutal"
            color="#ff6a2a"
            align="right"
          />
        </div>

        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-white/10 pt-2 text-[7px] uppercase tracking-[0.16em] text-white/30">
          <span>Best of 3 · 60s rounds · Keyboard fallback on desktop</span>
          <span className="flex items-center gap-2">
            <a
              href="./downloads/titan-arena.zip"
              download
              className="pointer-events-auto text-gold/70 underline-offset-2 hover:underline"
            >
              Download build
            </a>
            <button type="button" onClick={onGuide} className="pointer-events-auto text-gold/70 underline-offset-2 hover:underline">
              Touch controls &amp; rules
            </button>
          </span>
        </div>
      </div>
    </div>
  );
}
