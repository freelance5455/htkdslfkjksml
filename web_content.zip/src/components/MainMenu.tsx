/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Play, Users, Trophy, Settings, Volume2, VolumeX } from 'lucide-react';
import { CharacterDef } from '../types/game';

interface MainMenuProps {
  highScore: number;
  totalCoins: number;
  selectedCharacter: CharacterDef;
  soundEnabled: boolean;
  onStartGame: () => void;
  onOpenCharacters: () => void;
  onOpenMissions: () => void;
  onOpenSettings: () => void;
  onToggleSound: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  highScore,
  totalCoins,
  selectedCharacter,
  soundEnabled,
  onStartGame,
  onOpenCharacters,
  onOpenMissions,
  onOpenSettings,
  onToggleSound,
}) => {
  return (
    <div className="absolute inset-0 select-none flex flex-col justify-between p-6 sm:p-10 pointer-events-auto overflow-hidden">
      {/* Top Header: Stats & Quick Settings */}
      <div className="flex items-center justify-between w-full z-10">
        {/* Total Bank Coins */}
        <div className="flex items-center gap-2.5 bg-slate-900/90 border border-amber-500/40 px-4 py-2 rounded-2xl shadow-xl backdrop-blur-none">
          <div className="w-7 h-7 rounded-full bg-amber-400 border-2 border-yellow-200 flex items-center justify-center font-black text-amber-950 text-sm shadow-inner">
            $
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] uppercase font-bold text-slate-400">Coins</span>
            <span className="font-black text-amber-300 text-lg sm:text-xl tracking-wider tabular-nums font-mono">
              {totalCoins.toLocaleString()}
            </span>
          </div>
        </div>

        {/* High Score Badge */}
        <div className="hidden sm:flex items-center gap-2.5 bg-slate-900/90 border border-indigo-500/40 px-4 py-2 rounded-2xl shadow-xl">
          <Trophy className="w-5 h-5 text-yellow-400" />
          <div className="flex flex-col">
            <span className="text-[10px] uppercase font-bold text-slate-400">Best Score</span>
            <span className="font-black text-white text-lg tracking-wider tabular-nums font-mono">
              {highScore.toLocaleString()}
            </span>
          </div>
        </div>

        {/* Audio Mute & Settings */}
        <div className="flex items-center gap-2">
          <button
            onClick={onToggleSound}
            className="w-11 h-11 bg-slate-900/90 hover:bg-slate-800 border border-slate-700 rounded-xl flex items-center justify-center text-slate-300 shadow-lg cursor-pointer"
            title="Toggle Audio"
          >
            {soundEnabled ? <Volume2 className="w-5 h-5 text-emerald-400" /> : <VolumeX className="w-5 h-5 text-rose-400" />}
          </button>
          <button
            onClick={onOpenSettings}
            className="w-11 h-11 bg-slate-900/90 hover:bg-slate-800 border border-slate-700 rounded-xl flex items-center justify-center text-slate-300 shadow-lg cursor-pointer"
            title="Settings & Tutorial"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Hero Title Lockup (Bespoke inline SVG with 35% negative space) */}
      <div className="flex flex-col items-center justify-center text-center my-auto z-10">
        <div className="max-w-md w-full px-4 mb-2">
          <svg viewBox="0 0 600 160" className="w-full drop-shadow-[0_10px_20px_rgba(0,0,0,0.8)]">
            <defs>
              <linearGradient id="rushGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#fef08a" />
                <stop offset="50%" stopColor="#f97316" />
                <stop offset="100%" stopColor="#ec4899" />
              </linearGradient>
              <linearGradient id="subwayGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#38bdf8" />
                <stop offset="100%" stopColor="#0284c7" />
              </linearGradient>
            </defs>
            {/* Outline 3D shadow */}
            <text
              x="300"
              y="74"
              textAnchor="middle"
              fill="#090d16"
              fontSize="66"
              fontWeight="900"
              fontFamily="system-ui, sans-serif"
              letterSpacing="6"
            >
              SUBWAY
            </text>
            <text
              x="300"
              y="70"
              textAnchor="middle"
              fill="url(#subwayGrad)"
              stroke="#ffffff"
              strokeWidth="2.5"
              fontSize="66"
              fontWeight="900"
              fontFamily="system-ui, sans-serif"
              letterSpacing="6"
            >
              SUBWAY
            </text>

            <text
              x="300"
              y="144"
              textAnchor="middle"
              fill="#090d16"
              fontSize="84"
              fontWeight="900"
              fontStyle="italic"
              fontFamily="Impact, sans-serif"
              letterSpacing="4"
            >
              RUSH 3D
            </text>
            <text
              x="300"
              y="140"
              textAnchor="middle"
              fill="url(#rushGrad)"
              stroke="#ffffff"
              strokeWidth="3"
              fontSize="84"
              fontWeight="900"
              fontStyle="italic"
              fontFamily="Impact, sans-serif"
              letterSpacing="4"
            >
              RUSH 3D
            </text>
          </svg>
        </div>

        {/* Selected Runner Pill */}
        <div
          onClick={onOpenCharacters}
          className="cursor-pointer group flex items-center gap-3 bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 px-4 py-2 rounded-full shadow-lg transition-transform active:scale-95 mb-6"
        >
          <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-600 flex items-center justify-center font-bold text-xs text-white">
            🏃
          </div>
          <div className="text-left">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Selected Runner</span>
            <span className="font-extrabold text-sm text-cyan-400 group-hover:text-cyan-300">
              {selectedCharacter.name}
            </span>
          </div>
          <span className="text-xs text-slate-400 ml-1">Change ›</span>
        </div>

        {/* Primary Start CTA Button */}
        <button
          onClick={onStartGame}
          className="group relative px-10 py-5 bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 active:scale-95 text-white font-black text-2xl tracking-wider rounded-2xl shadow-[0_12px_30px_rgba(16,185,129,0.45)] border-2 border-emerald-300/40 transition-all flex items-center gap-3 cursor-pointer"
        >
          <Play className="w-7 h-7 fill-white group-hover:scale-110 transition-transform" />
          <span>START RUN</span>
        </button>

        {/* Control Hint Line */}
        <p className="text-xs sm:text-sm font-medium text-slate-400 mt-4 tracking-wide">
          WASD / Arrows Move · Space / Up Jump · S / Down Slide · Esc Pause
        </p>
      </div>

      {/* Bottom Menu Navigation Bar */}
      <div className="w-full flex items-center justify-center gap-4 z-10 max-w-md mx-auto">
        <button
          onClick={onOpenCharacters}
          className="flex-1 py-3 px-4 bg-slate-900/90 hover:bg-slate-800 border border-slate-700 rounded-xl flex items-center justify-center gap-2 text-white font-bold text-sm shadow-lg cursor-pointer"
        >
          <Users className="w-4 h-4 text-cyan-400" />
          <span>Runners</span>
        </button>

        <button
          onClick={onOpenMissions}
          className="flex-1 py-3 px-4 bg-slate-900/90 hover:bg-slate-800 border border-slate-700 rounded-xl flex items-center justify-center gap-2 text-white font-bold text-sm shadow-lg cursor-pointer"
        >
          <Trophy className="w-4 h-4 text-amber-400" />
          <span>Missions</span>
        </button>

        <button
          onClick={onOpenSettings}
          className="py-3 px-4 bg-slate-900/90 hover:bg-slate-800 border border-slate-700 rounded-xl flex items-center justify-center gap-2 text-white font-bold text-sm shadow-lg cursor-pointer"
        >
          <Settings className="w-4 h-4 text-slate-400" />
          <span className="hidden sm:inline">Settings</span>
        </button>
      </div>
    </div>
  );
};
