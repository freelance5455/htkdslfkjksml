import React from 'react';
import { sound } from '../audio/SoundEngine';
import { TimeOfDay } from '../game/core/GameEngine';
import {
  Play,
  Users,
  Crosshair,
  Settings as SettingsIcon,
  Sun,
  Moon,
  Sunset,
  Volume2,
  VolumeX,
  LogOut,
} from 'lucide-react';

interface MainMenuProps {
  onPlay: () => void;
  onOpenCharacters: () => void;
  onOpenLoadout: () => void;
  onOpenSettings: () => void;
  timeOfDay: TimeOfDay;
  onToggleTimeOfDay: (tod: TimeOfDay) => void;
  onQuit: () => void;
  characterName: string;
  currentMapName: string;
  menuBackground?: string;
  onSelectMenuBackground?: (bgId: string) => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  onPlay,
  onOpenCharacters,
  onOpenLoadout,
  onOpenSettings,
  timeOfDay,
  onToggleTimeOfDay,
  onQuit,
  characterName,
  currentMapName,
  menuBackground = 'bg_suburban',
  onSelectMenuBackground,
}) => {
  const [isMuted, setIsMuted] = React.useState(false);
  const [showBgDropdown, setShowBgDropdown] = React.useState(false);

  const handleMuteToggle = () => {
    sound.playUIClick();
    const muted = sound.toggleMute();
    setIsMuted(muted);
  };

  const nextTimeOfDay = () => {
    sound.playUIClick();
    if (timeOfDay === 'evening') onToggleTimeOfDay('night');
    else if (timeOfDay === 'night') onToggleTimeOfDay('day');
    else onToggleTimeOfDay('evening');
  };

  const menuBgOptions = [
    { id: 'bg_suburban', label: '1. Suburban Outbreak' },
    { id: 'bg_city', label: '2. City Street Ruins' },
    { id: 'bg_military', label: '3. Military Checkpoint' },
    { id: 'bg_forest', label: '4. Forest Facility' },
    { id: 'bg_hospital', label: '5. Hospital Exterior' },
    { id: 'bg_industrial', label: '6. Industrial Foundry' },
    { id: 'bg_flooded', label: '7. Flooded Street' },
    { id: 'random', label: '🎲 Random' },
  ];

  return (
    <div className="absolute inset-0 pointer-events-none z-30 select-none flex flex-col justify-between p-4 sm:p-6">
      {/* Subtle Atmospheric Overlay: static scanlines & fire glow */}
      <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#ef4444_1px,transparent_1px)] [background-size:28px_28px] pointer-events-none" />
      <div className="absolute inset-0 opacity-10 bg-[linear-gradient(to_bottom,transparent_50%,rgba(0,0,0,0.8)_51%)] [background-size:100%_4px] pointer-events-none" />

      {/* Top Header Banner */}
      <div className="flex justify-between items-start w-full">
        {/* Title branding */}
        <div className="flex flex-col pointer-events-auto">
          <div className="flex items-center gap-2 text-red-500 font-mono-tech text-xs tracking-widest uppercase">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
            BLACKOUT ZOMBIE STUDIOS // {currentMapName.toUpperCase()}
          </div>
          <h1 className="text-5xl sm:text-7xl font-teko uppercase font-extrabold tracking-wider text-white drop-shadow-2xl leading-none">
            BLACKOUT: <span className="text-red-600">DEAD RISING</span>
          </h1>
          <div className="flex items-center gap-3 font-mono-tech text-xs text-zinc-400 mt-1">
            <div>
              <span>OPERATOR: </span>
              <span className="text-cyan-400 font-bold tracking-wider">{characterName.toUpperCase()}</span>
            </div>
            <span>•</span>
            <div>
              <span>ZONE: </span>
              <span className="text-amber-400 font-bold tracking-wider">{currentMapName.toUpperCase()}</span>
            </div>
          </div>
        </div>

        {/* Top-Right Quick Actions */}
        <div className="flex items-center gap-2 pointer-events-auto">
          {/* Menu Background Selector (Requirement 18) */}
          <div className="relative">
            <button
              onClick={() => {
                sound.playUIClick();
                setShowBgDropdown(prev => !prev);
              }}
              className="px-3 py-1.5 rounded-xl bg-zinc-900/80 hover:bg-zinc-800 text-zinc-300 border border-zinc-700/80 flex items-center gap-1.5 font-mono-tech text-xs tracking-wider cursor-pointer shadow-lg"
            >
              <span>BG: {menuBackground.replace('bg_', '').toUpperCase()}</span>
            </button>

            {showBgDropdown && (
              <div className="absolute right-0 mt-1.5 w-48 bg-zinc-950/95 border border-zinc-700 rounded-xl shadow-2xl overflow-hidden z-50 flex flex-col p-1 animate-fade-in backdrop-blur-md">
                {menuBgOptions.map(opt => (
                  <button
                    key={opt.id}
                    onClick={() => {
                      sound.playUIClick();
                      setShowBgDropdown(false);
                      if (onSelectMenuBackground) onSelectMenuBackground(opt.id);
                    }}
                    className={`px-2.5 py-1.5 rounded-lg text-left font-mono-tech text-xs cursor-pointer transition-colors ${
                      menuBackground === opt.id ? 'bg-red-600 text-white font-bold' : 'text-zinc-300 hover:bg-zinc-800'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Time of Day Switcher */}
          <button
            onClick={nextTimeOfDay}
            className="px-3 py-1.5 rounded-xl bg-zinc-900/80 hover:bg-zinc-800 text-zinc-300 border border-zinc-700/80 flex items-center gap-2 font-mono-tech text-xs tracking-wider cursor-pointer shadow-lg"
          >
            {timeOfDay === 'day' ? (
              <>
                <Sun className="w-4 h-4 text-amber-400" />
                <span className="hidden sm:inline">DAY</span>
              </>
            ) : timeOfDay === 'evening' ? (
              <>
                <Sunset className="w-4 h-4 text-orange-400" />
                <span className="hidden sm:inline">EVENING</span>
              </>
            ) : (
              <>
                <Moon className="w-4 h-4 text-blue-400" />
                <span className="hidden sm:inline">NIGHT</span>
              </>
            )}
          </button>

          <button
            onClick={handleMuteToggle}
            className="w-9 h-9 rounded-xl bg-zinc-900/80 hover:bg-zinc-800 text-zinc-300 border border-zinc-700/80 flex items-center justify-center cursor-pointer shadow-lg"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>
        </div>
      </div>

      {/* Compact Tactical Left Menu Navigation (Smaller, less intrusive, modern - Requirements 1 & 2) */}
      <div className="w-full max-w-[240px] flex flex-col gap-1.5 pointer-events-auto">
        {/* Primary Action Button: START (Opens Map Selection -> Settings -> Loadout -> Match) */}
        <button
          onClick={() => {
            sound.playMenuConfirm();
            onPlay();
          }}
          className="group relative w-full py-2.5 px-4 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white rounded-xl font-teko text-2xl tracking-wider uppercase font-bold shadow-xl shadow-red-600/40 border border-red-400/50 flex items-center justify-between transition-all transform hover:translate-x-1 cursor-pointer active:scale-95"
        >
          <div className="flex items-center gap-2.5">
            <Play className="w-5 h-5 fill-white" />
            <span>START</span>
          </div>
          <span className="font-mono-tech text-[10px] text-red-100 tracking-wider bg-red-800/80 px-1.5 py-0.5 rounded">
            THEATER
          </span>
        </button>

        {/* Operators Button */}
        <button
          onClick={() => {
            sound.playMenuSelect();
            onOpenCharacters();
          }}
          className="w-full py-1.5 px-3.5 bg-zinc-900/75 hover:bg-zinc-800 text-zinc-200 hover:text-white rounded-xl font-teko text-xl tracking-wider uppercase font-semibold border border-zinc-700/70 flex items-center justify-between transition-all transform hover:translate-x-1 cursor-pointer backdrop-blur-md"
        >
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-cyan-400" />
            <span>CHARACTERS</span>
          </div>
          <span className="font-mono-tech text-[9px] text-zinc-400">3D VIEW</span>
        </button>

        {/* Loadout / Armory Button */}
        <button
          onClick={() => {
            sound.playMenuSelect();
            onOpenLoadout();
          }}
          className="w-full py-1.5 px-3.5 bg-zinc-900/75 hover:bg-zinc-800 text-zinc-200 hover:text-white rounded-xl font-teko text-xl tracking-wider uppercase font-semibold border border-zinc-700/70 flex items-center justify-between transition-all transform hover:translate-x-1 cursor-pointer backdrop-blur-md"
        >
          <div className="flex items-center gap-2">
            <Crosshair className="w-4 h-4 text-amber-400" />
            <span>LOADOUT & SKINS</span>
          </div>
          <span className="font-mono-tech text-[9px] text-zinc-400">EQUIP</span>
        </button>

        {/* Settings Button */}
        <button
          onClick={() => {
            sound.playMenuSelect();
            onOpenSettings();
          }}
          className="w-full py-1.5 px-3.5 bg-zinc-900/75 hover:bg-zinc-800 text-zinc-200 hover:text-white rounded-xl font-teko text-xl tracking-wider uppercase font-semibold border border-zinc-700/70 flex items-center justify-between transition-all transform hover:translate-x-1 cursor-pointer backdrop-blur-md"
        >
          <div className="flex items-center gap-2">
            <SettingsIcon className="w-4 h-4 text-zinc-400" />
            <span>SETTINGS / HUD</span>
          </div>
          <span className="font-mono-tech text-[9px] text-zinc-400">CONFIG</span>
        </button>

        {/* Intro Screen Return Button */}
        <button
          onClick={() => {
            sound.playMenuBack();
            onQuit();
          }}
          className="w-full py-1.5 px-3.5 bg-zinc-950/60 hover:bg-zinc-900 text-zinc-400 hover:text-zinc-200 rounded-xl font-teko text-lg tracking-wider uppercase font-medium border border-zinc-800/60 flex items-center justify-between transition-all cursor-pointer"
        >
          <div className="flex items-center gap-2">
            <LogOut className="w-3.5 h-3.5" />
            <span>INTRO SCREEN</span>
          </div>
        </button>
      </div>

      {/* Bottom Footer Info */}
      <div className="flex justify-between items-end w-full text-zinc-500 font-mono-tech text-[11px] tracking-wider uppercase">
        <div>CONTROLS: TOUCH JOYSTICK & DRAG-LOOK | TACTICAL SLIDE | MULTI-TOUCH ACTIVE</div>
        <div className="hidden sm:block">BLACKOUT: DEAD RISING // 100+ WAVES EXPANSION</div>
      </div>
    </div>
  );
};
