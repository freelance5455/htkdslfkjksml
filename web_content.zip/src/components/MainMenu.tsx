import React from 'react';
import {
  Play,
  Sliders,
  Move,
  Volume2,
  VolumeX,
  Shield,
  Crosshair,
  Flame,
  Zap,
} from 'lucide-react';

interface MainMenuProps {
  onStartGame: () => void;
  onOpenGraphics: () => void;
  onOpenControls: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  onStartGame,
  onOpenGraphics,
  onOpenControls,
  isMuted,
  onToggleMute,
}) => {
  return (
    <div
      id="main-menu-screen"
      className="relative w-full h-full flex flex-col items-center justify-between p-6 select-none overflow-hidden bg-zinc-950 text-zinc-100"
      style={{
        backgroundImage:
          'radial-gradient(ellipse at center, rgba(239, 68, 68, 0.15) 0%, rgba(9, 9, 11, 0.95) 75%), linear-gradient(to bottom, rgba(0,0,0,0.6), rgba(0,0,0,0.9))',
      }}
    >
      {/* Top Brand Bar */}
      <div className="w-full flex items-center justify-between max-w-5xl z-10">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-red-600/20 border border-red-500/40 text-red-500">
            <Shield className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold uppercase tracking-widest text-zinc-400">
            Post-Apocalyptic Survival & Base Defense
          </span>
        </div>

        {/* Audio Toggle */}
        <button
          id="menu-audio-toggle"
          onClick={onToggleMute}
          className="p-2.5 rounded-xl bg-zinc-900/80 hover:bg-zinc-800 text-zinc-300 border border-zinc-700/80 transition"
        >
          {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-green-400" />}
        </button>
      </div>

      {/* Center Hero Section */}
      <div className="flex flex-col items-center text-center max-w-2xl z-10">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-red-500/10 border border-red-500/30 text-red-400 text-xs font-bold uppercase tracking-wider mb-4">
          <Flame className="w-3.5 h-3.5" />
          Mobil Gorizontal Versiya
        </div>

        <h1 className="text-5xl md:text-6xl font-display font-bold uppercase tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-amber-400 to-red-600 drop-shadow-sm">
          ZOʻMBI HIMOYASI
        </h1>
        <p className="text-lg md:text-xl font-display uppercase tracking-widest text-zinc-300 mt-1">
          Baza Mudofaasi va Omon Qolish
        </p>

        <p className="text-xs md:text-sm text-zinc-400 max-w-lg mt-3 leading-relaxed">
          Bazangizni himoya qiling, har bir toʻlqinda qurollarni yaxshilang, resurslar toʻplang va
          oʻz xohishingizga koʻra tugmalar va grafika panelini moslashtiring!
        </p>

        {/* Primary Start Action */}
        <div className="flex flex-col sm:flex-row items-center gap-4 mt-8 w-full justify-center">
          <button
            id="start-battle-btn"
            onClick={onStartGame}
            className="flex items-center justify-center gap-3 px-10 py-3.5 rounded-xl bg-gradient-to-r from-red-600 via-red-500 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-display text-2xl font-bold uppercase tracking-wider shadow-2xl shadow-red-950/80 transition transform active:scale-95"
          >
            <Play className="w-6 h-6 fill-white" />
            Jangga Kirish
          </button>
        </div>

        {/* Customization Quick Action Buttons */}
        <div className="flex items-center gap-3 mt-5">
          <button
            id="menu-graphics-btn"
            onClick={onOpenGraphics}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-zinc-900/90 hover:bg-zinc-800 text-zinc-200 border border-zinc-700/80 text-xs font-bold uppercase tracking-wider transition shadow"
          >
            <Sliders className="w-4 h-4 text-red-400" />
            Grafika Paneli
          </button>

          <button
            id="menu-controls-btn"
            onClick={onOpenControls}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-zinc-900/90 hover:bg-zinc-800 text-zinc-200 border border-zinc-700/80 text-xs font-bold uppercase tracking-wider transition shadow"
          >
            <Move className="w-4 h-4 text-sky-400" />
            Tugmalarni Moslashtirish
          </button>
        </div>

        {/* 3 Yangi Zombi Turi Kartalari */}
        <div className="grid grid-cols-3 gap-2.5 mt-5 w-full max-w-xl text-left">
          <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/30">
            <div className="flex items-center gap-1.5 text-amber-400 font-bold text-xs">
              <span>⚡</span> Tezkor Zombi
            </div>
            <div className="text-[10px] text-zinc-300 mt-1 leading-snug">
              Tezligi: <span className="text-amber-300 font-semibold">215+</span> (Chaqmoq Dash). Changallari bilan shiddatli hujum qiladi.
            </div>
          </div>

          <div className="p-2 rounded-xl bg-slate-500/10 border border-slate-400/30">
            <div className="flex items-center gap-1.5 text-slate-300 font-bold text-xs">
              <span>🛡️</span> Zirhli Zombi
            </div>
            <div className="text-[10px] text-zinc-300 mt-1 leading-snug">
              HP: <span className="text-slate-200 font-semibold">340</span>. Oʻqlarga -50% chidamlilik, devorlarga 2x zarar beradi.
            </div>
          </div>

          <div className="p-2 rounded-xl bg-orange-500/10 border border-orange-500/30">
            <div className="flex items-center gap-1.5 text-orange-400 font-bold text-xs">
              <span>☢️</span> Portlovchi
            </div>
            <div className="text-[10px] text-zinc-300 mt-1 leading-snug">
              Yaqinlashganda portlaydi va <span className="text-orange-300 font-semibold">zaharli gaz maydoni</span> hosil qiladi.
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Controls Info Card */}
      <div className="w-full max-w-4xl grid grid-cols-2 gap-3 text-xs bg-zinc-950/60 border border-zinc-800/80 p-3.5 rounded-xl backdrop-blur-sm z-10">
        <div className="flex items-start gap-2.5">
          <div className="p-1.5 rounded-lg bg-zinc-900 text-red-400 shrink-0">
            <Crosshair className="w-4 h-4" />
          </div>
          <div>
            <div className="font-bold text-zinc-200 uppercase text-[11px]">Mobil Boshqaruv</div>
            <div className="text-[11px] text-zinc-400 mt-0.5">
              Chapda djoystik (harakat), oʻngda oʻt ochish, qayta oʻqlash, bazani taʼmirlash va minora oʻrnatish tugmalari.
            </div>
          </div>
        </div>

        <div className="flex items-start gap-2.5">
          <div className="p-1.5 rounded-lg bg-zinc-900 text-sky-400 shrink-0">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <div className="font-bold text-zinc-200 uppercase text-[11px]">Kompyuter Boshqaruvi</div>
            <div className="text-[11px] text-zinc-400 mt-0.5">
              [WASD] Yurish, [Sichqoncha] Nishon va otish, [R] Qayta oʻqlash, [E] Taʼmirlash, [Q] Qurol, [Space] Sprint, [T] Minora.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
