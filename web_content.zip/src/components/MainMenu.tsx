import React from 'react';
import { motion } from 'motion/react';
import { 
  Play, 
  ShoppingBag, 
  Settings, 
  Coins, 
  ArrowUp,
  ArrowRight,
  ArrowDown,
  ArrowLeft,
  Video
} from 'lucide-react';
import { PlayerStats, Language } from '../types';
import { getTranslations } from '../services/i18n';
import { BannerAd } from './BannerAd';

interface MainMenuProps {
  stats: PlayerStats;
  language?: Language;
  onPlayShortArrow: () => void;
  onPlayLongArrow: () => void;
  onOpenShop: () => void;
  onOpenSettings: () => void;
  onWatchAdForCoins?: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  stats,
  language = 'en',
  onPlayShortArrow,
  onPlayLongArrow,
  onOpenShop,
  onOpenSettings,
  onWatchAdForCoins,
}) => {
  const t = getTranslations(language);
  const shortLevel = stats.highestShortArrowLevel || 1;
  const longLevel = stats.highestLongArrowLevel || 1;
  const shortCompleted = Object.keys(stats.completedShortLevels || {}).length;
  const longCompleted = Object.keys(stats.completedLongLevels || {}).length;

  return (
    <div className="w-full h-full flex flex-col justify-between select-none relative overflow-hidden bg-gradient-to-b from-sky-50 via-slate-50 to-indigo-50/60 dark:from-slate-900 dark:via-slate-900 dark:to-slate-950">
      {/* Background Decorative Ambient Arrows */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-[0.035] dark:opacity-[0.05] flex items-center justify-center">
        <div className="grid grid-cols-4 gap-12 rotate-12 scale-125">
          <ArrowUp className="w-24 h-24" />
          <ArrowRight className="w-24 h-24" />
          <ArrowDown className="w-24 h-24" />
          <ArrowLeft className="w-24 h-24" />
          <ArrowRight className="w-24 h-24" />
          <ArrowUp className="w-24 h-24" />
          <ArrowLeft className="w-24 h-24" />
          <ArrowDown className="w-24 h-24" />
        </div>
      </div>

      {/* Main Content Area */}
      <div 
        className="flex-1 w-full flex flex-col justify-between px-5 pb-5 overflow-y-auto z-10 max-w-md mx-auto"
        style={{ paddingTop: 'max(1.25rem, env(safe-area-inset-top, 0px))' }}
      >
        {/* Top Header Bar: Coins, Shop, Settings */}
        <div className="w-full flex items-center justify-between">
          {/* Coins Badge with optional Rewarded Ad quick claim */}
          <div className="flex items-center gap-1.5">
            <div 
              id="header-coins"
              className="h-10 px-3.5 rounded-2xl bg-white/95 dark:bg-slate-800/95 border border-amber-300 dark:border-amber-700/80 backdrop-blur shadow-sm flex items-center gap-2"
            >
              <Coins className="w-4 h-4 text-amber-500 fill-amber-400" />
              <span className="text-sm font-black text-amber-950 dark:text-amber-200 tracking-wide">
                {stats.coins}
              </span>
            </div>

            {onWatchAdForCoins && (
              <button
                type="button"
                onClick={onWatchAdForCoins}
                title="Watch Ad for +100 Coins"
                className="h-10 px-2.5 rounded-2xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-400/40 text-amber-700 dark:text-amber-300 font-bold text-xs flex items-center gap-1 active:scale-95 transition"
              >
                <Video className="w-3.5 h-3.5 text-amber-500" />
                <span>+100</span>
              </button>
            )}
          </div>

          {/* Action icons: Shop & Settings */}
          <div className="flex items-center gap-2">
            {/* Shop Button */}
            <button
              id="btn-menu-shop"
              type="button"
              onClick={onOpenShop}
              aria-label={t.shop}
              className="h-10 px-3.5 rounded-2xl bg-white/95 dark:bg-slate-800/95 border border-slate-200 dark:border-slate-700 backdrop-blur shadow-sm flex items-center gap-1.5 text-slate-800 dark:text-slate-100 font-bold text-xs hover:border-purple-400 active:scale-95 transition"
            >
              <ShoppingBag className="w-4 h-4 text-purple-500" />
              <span>{t.shop}</span>
            </button>

            {/* Settings Button */}
            <button
              id="btn-menu-settings"
              type="button"
              onClick={onOpenSettings}
              aria-label={t.settings}
              className="w-10 h-10 rounded-2xl bg-white/95 dark:bg-slate-800/95 border border-slate-200 dark:border-slate-700 backdrop-blur shadow-sm flex items-center justify-center text-slate-700 dark:text-slate-200 hover:text-sky-500 active:scale-95 transition"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Central Brand Title & Logo */}
        <div className="flex flex-col items-center text-center my-auto py-4">
          <motion.div
            animate={{ y: [-4, 4, -4] }}
            transition={{ repeat: Infinity, duration: 4, ease: 'easeInOut' }}
            className="relative mb-2"
          >
            <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-sky-500 via-blue-600 to-indigo-600 shadow-xl shadow-sky-500/30 flex items-center justify-center text-white border-2 border-white/60 dark:border-slate-700">
              <div className="relative w-10 h-10 flex items-center justify-center">
                <ArrowUp className="w-7 h-7 text-white stroke-[2.75] absolute -top-0.5 drop-shadow" />
                <ArrowRight className="w-6 h-6 text-sky-200 stroke-[2.75] absolute -right-0.5 drop-shadow" />
              </div>
            </div>
          </motion.div>

          <h1 className="text-3xl font-black tracking-tight text-slate-800 dark:text-white drop-shadow-sm">
            ARROW<span className="text-sky-500">SCAPE</span>
          </h1>
          <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 mt-0.5 max-w-[280px]">
            {t.gameSubtitle}
          </p>
        </div>

        {/* The Exactly TWO Gameplay Systems */}
        <div className="w-full flex flex-col gap-3.5 max-w-sm mx-auto">
          {/* 1. SHORT ARROW */}
          <button
            id="btn-play-short-arrow"
            type="button"
            onClick={onPlayShortArrow}
            className="w-full h-18 py-3.5 rounded-3xl bg-gradient-to-r from-sky-500 via-blue-600 to-indigo-600 hover:from-sky-600 hover:to-indigo-700 text-white shadow-lg shadow-sky-500/25 flex items-center justify-between px-5 active:scale-98 transition group"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-2xl bg-white/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Play className="w-5 h-5 fill-white text-white translate-x-0.5" />
              </div>
              <div className="flex flex-col text-left">
                <span className="text-base font-black tracking-wide leading-tight">
                  {t.shortArrow}
                </span>
                <span className="text-xs text-sky-100 font-medium mt-0.5">
                  {t.shortArrowSub} • Level {shortLevel}
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs bg-white/20 px-2.5 py-1 rounded-full font-bold">
                {shortCompleted > 0 ? `${shortCompleted} ${t.won}` : t.play}
              </span>
              <ArrowRight className="w-4 h-4 text-white/80 group-hover:translate-x-1 transition-transform" />
            </div>
          </button>

          {/* 2. LONG ARROW */}
          <button
            id="btn-play-long-arrow"
            type="button"
            onClick={onPlayLongArrow}
            className="w-full h-18 py-3.5 rounded-3xl bg-gradient-to-r from-emerald-500 via-teal-600 to-cyan-700 hover:from-emerald-600 hover:to-cyan-800 text-white shadow-lg shadow-emerald-500/25 flex items-center justify-between px-5 active:scale-98 transition group"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-2xl bg-white/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                <div className="flex items-center gap-0.5">
                  <ArrowRight className="w-5 h-5 text-white" />
                  <ArrowDown className="w-4 h-4 text-emerald-200" />
                </div>
              </div>
              <div className="flex flex-col text-left">
                <span className="text-base font-black tracking-wide leading-tight">
                  {t.longArrow}
                </span>
                <span className="text-xs text-teal-100 font-medium mt-0.5">
                  {t.longArrowSub} • Level {longLevel}
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs bg-white/20 px-2.5 py-1 rounded-full font-bold">
                {longCompleted > 0 ? `${longCompleted} ${t.won}` : t.play}
              </span>
              <ArrowRight className="w-4 h-4 text-white/80 group-hover:translate-x-1 transition-transform" />
            </div>
          </button>
        </div>
      </div>

      {/* Real AdMob Horizontal Banner Ad docked at absolute bottom */}
      <BannerAd />
    </div>
  );
};
