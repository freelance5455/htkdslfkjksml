import React, { useState } from 'react';
import { 
  NotebookPen, 
  Plus, 
  Search, 
  Trash2, 
  Copy, 
  Check, 
  Tag, 
  Sparkles,
  FileText
} from 'lucide-react';
import { NoteItem, SupportedLanguage } from '../types/assistant';

interface NotesManagerProps {
  notes: NoteItem[];
  language: SupportedLanguage;
  onAddNote: (title: string, content: string, tag?: string) => void;
  onDeleteNote: (id: string) => void;
  onClearNotes: () => void;
}

export const NotesManager: React.FC<NotesManagerProps> = ({
  notes,
  language,
  onAddNote,
  onDeleteNote,
  onClearNotes,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState<string>('All');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newTag, setNewTag] = useState('General');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const tags = ['All', 'General', 'Work', 'Directives', 'Ideas', 'Urgent'];

  const filteredNotes = notes.filter((note) => {
    const matchesSearch =
      note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTag = selectedTag === 'All' || note.tag === selectedTag;
    return matchesSearch && matchesTag;
  });

  const handleSaveNote = () => {
    if (!newContent.trim()) return;
    onAddNote(
      newTitle.trim() || `Intel Note #${notes.length + 1}`,
      newContent.trim(),
      newTag
    );
    setNewTitle('');
    setNewContent('');
    setShowAddModal(false);
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-950 via-[#0d1629] to-[#1a1128] border border-cyan-500/30 p-6 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-mono-tech mb-1">
            <NotebookPen className="w-3.5 h-3.5 text-cyan-400" />
            <span>ENCRYPTED LOCAL STORAGE</span>
          </div>
          <h2 className="text-2xl font-orbitron font-extrabold tracking-wide text-white">
            BOSS PERSONAL NOTES
          </h2>
          <p className="text-slate-400 text-xs sm:text-sm">
            {notes.length} intel documents and memos stored securely on this device.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-cyan-500 to-cyan-400 hover:from-cyan-400 hover:to-cyan-300 text-slate-950 font-orbitron font-bold text-xs tracking-wider transition-all flex items-center gap-2 shadow-lg shadow-cyan-500/20 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>NEW NOTE</span>
        </button>
      </div>

      {/* Search & Tag Filter Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-cyan-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search notes by keyword or title..."
            className="w-full pl-10 pr-4 py-2.5 bg-slate-950 text-slate-100 placeholder:text-slate-500 text-xs sm:text-sm rounded-xl border border-cyan-900/60 focus:outline-none focus:border-cyan-400 transition-all font-sans"
          />
        </div>

        {/* Tag Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
          {tags.map((t) => (
            <button
              key={t}
              onClick={() => setSelectedTag(t)}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono-tech whitespace-nowrap transition-all ${
                selectedTag === t
                  ? 'bg-cyan-500/20 border border-cyan-400 text-cyan-300 shadow-sm'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Notes Grid */}
      {filteredNotes.length === 0 ? (
        <div className="rounded-3xl bg-slate-950/80 border border-slate-800 p-12 text-center space-y-3">
          <FileText className="w-12 h-12 text-slate-600 mx-auto" />
          <p className="text-slate-300 font-semibold text-sm">
            {searchQuery ? 'No matching notes found.' : 'No notes recorded yet, Boss.'}
          </p>
          <p className="text-slate-500 text-xs max-w-xs mx-auto">
            Click &quot;New Note&quot; or say &quot;নোট সেভ করো ...&quot; in the Assistant chat.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredNotes.map((note) => (
            <div
              key={note.id}
              className="rounded-2xl bg-[#090f1f]/90 border border-cyan-900/40 hover:border-cyan-500/50 p-4 space-y-3 transition-all shadow-md group flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 border-b border-slate-800/80 pb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono-tech px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                      {note.tag || 'General'}
                    </span>
                    <h3 className="font-orbitron font-bold text-sm text-white line-clamp-1">
                      {note.title}
                    </h3>
                  </div>
                  <span className="text-[10px] font-mono-tech text-slate-500">
                    {new Date(note.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                  </span>
                </div>

                <p className="text-slate-300 text-xs leading-relaxed whitespace-pre-wrap mt-2.5 font-sans">
                  {note.content}
                </p>
              </div>

              <div className="flex items-center justify-end gap-1.5 pt-2 border-t border-slate-800/60 text-slate-400">
                <button
                  onClick={() => handleCopy(note.id, `${note.title}\n\n${note.content}`)}
                  title="Copy Note"
                  className="p-1.5 rounded-lg hover:bg-cyan-950/60 hover:text-cyan-300 transition-colors"
                >
                  {copiedId === note.id ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
                <button
                  onClick={() => onDeleteNote(note.id)}
                  title="Delete Note"
                  className="p-1.5 rounded-lg hover:bg-red-950/60 hover:text-red-400 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Note Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-3xl bg-[#090f1f] border border-cyan-500/50 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-cyan-900/40 pb-3">
              <h3 className="font-orbitron font-bold text-sm text-cyan-300 tracking-wide">
                CREATE BOSS INTEL NOTE
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white text-xs font-mono-tech"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-mono-tech text-slate-400">Title</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Project Quantum Roadmap"
                  className="w-full mt-1 bg-slate-950 text-slate-100 text-sm px-3.5 py-2.5 rounded-xl border border-slate-700 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="text-xs font-mono-tech text-slate-400">Category Tag</label>
                <select
                  value={newTag}
                  onChange={(e) => setNewTag(e.target.value)}
                  className="w-full mt-1 bg-slate-950 text-slate-100 text-sm px-3 py-2 rounded-xl border border-slate-700 focus:outline-none focus:border-cyan-400"
                >
                  {tags.filter((t) => t !== 'All').map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-mono-tech text-slate-400">Note Content *</label>
                <textarea
                  rows={4}
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  placeholder="Write note or paste memo details here..."
                  className="w-full mt-1 bg-slate-950 text-slate-100 text-sm p-3.5 rounded-xl border border-slate-700 focus:outline-none focus:border-cyan-400 resize-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-mono-tech text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveNote}
                className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs tracking-wider font-orbitron shadow-md shadow-cyan-500/30"
              >
                SAVE NOTE
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
