/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useNetwork } from '../context/NetworkContext';
import { X, Play, RotateCcw, Zap, CheckCircle2, ShieldCheck, ArrowDown, ArrowUp } from 'lucide-react';

interface SpeedTestModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SpeedTestModal: React.FC<SpeedTestModalProps> = ({ isOpen, onClose }) => {
  const { speedTest, startSpeedTest, stopSpeedTest, metrics } = useNetwork();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-md rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 overflow-hidden">
        {/* Glow effect */}
        <div className="absolute -top-20 left-1/2 -translate-x-1/2 w-64 h-64 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Top Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 relative z-10">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Zap className="w-4 h-4 text-cyan-400" />
              <span>Network Speed & QoS Audit</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Testing ISP {metrics.ispName}
            </p>
          </div>
          <button
            onClick={() => {
              stopSpeedTest();
              onClose();
            }}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Center Test Gauge */}
        <div className="my-6 flex flex-col items-center justify-center relative z-10">
          <div className="relative w-48 h-48 flex items-center justify-center">
            {/* Circular Progress Ring */}
            <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 160 160">
              <circle
                cx="80"
                cy="80"
                r="65"
                fill="none"
                stroke="#1e293b"
                strokeWidth="10"
              />
              <circle
                cx="80"
                cy="80"
                r="65"
                fill="none"
                stroke={speedTest.phase === 'upload' ? '#a855f7' : '#06b6d4'}
                strokeWidth="10"
                strokeDasharray="408"
                strokeDashoffset={408 - (speedTest.progress / 100) * 408}
                strokeLinecap="round"
                className="transition-all duration-200"
              />
            </svg>

            {/* Readout */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              {speedTest.phase === 'idle' ? (
                <div className="text-center px-4">
                  <div className="text-2xl font-extrabold text-white">Ready</div>
                  <div className="text-[11px] text-slate-400 mt-1">Tap start below</div>
                </div>
              ) : speedTest.phase === 'ping' ? (
                <div className="text-center">
                  <div className="text-xs text-amber-400 font-semibold uppercase tracking-wider animate-pulse">Testing Latency</div>
                  <div className="text-3xl font-extrabold text-white font-mono mt-1">{speedTest.resultPing} <span className="text-xs text-slate-400">ms</span></div>
                  <div className="text-[10px] text-slate-400">Jitter: {speedTest.resultJitter}ms</div>
                </div>
              ) : speedTest.phase === 'completed' ? (
                <div className="text-center">
                  <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                  <div className="text-lg font-bold text-white mt-1">Audit Passed</div>
                  <div className="text-[11px] text-cyan-300 font-mono">Bufferbloat A+</div>
                </div>
              ) : (
                <div className="text-center">
                  <div className="text-xs uppercase font-medium tracking-wider text-slate-400">
                    {speedTest.phase === 'download' ? 'Testing Download' : 'Testing Upload'}
                  </div>
                  <div className="text-3xl font-extrabold text-white font-mono mt-0.5">
                    {speedTest.currentSpeedMbps}
                  </div>
                  <div className="text-[11px] text-cyan-400 font-semibold uppercase">Mbps</div>
                </div>
              )}
            </div>
          </div>

          {/* Current Phase description */}
          <div className="mt-2 text-xs text-slate-400">
            {speedTest.isRunning && (
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                Phase: <span className="text-white capitalize">{speedTest.phase}</span> ({speedTest.progress}%)
              </span>
            )}
          </div>
        </div>

        {/* Results Matrix */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-6">
          <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 text-center">
            <div className="flex items-center justify-center gap-1 text-[11px] text-slate-400">
              <ArrowDown className="w-3 h-3 text-cyan-400" />
              <span>Download</span>
            </div>
            <div className="text-base font-bold text-white font-mono mt-1">
              {speedTest.resultDownload > 0 ? `${speedTest.resultDownload} M` : '--'}
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 text-center">
            <div className="flex items-center justify-center gap-1 text-[11px] text-slate-400">
              <ArrowUp className="w-3 h-3 text-purple-400" />
              <span>Upload</span>
            </div>
            <div className="text-base font-bold text-white font-mono mt-1">
              {speedTest.resultUpload > 0 ? `${speedTest.resultUpload} M` : '--'}
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 text-center">
            <div className="text-[11px] text-slate-400">Ping</div>
            <div className="text-base font-bold text-amber-400 font-mono mt-1">
              {speedTest.resultPing > 0 ? `${speedTest.resultPing} ms` : '--'}
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 text-center">
            <div className="text-[11px] text-slate-400">Quality</div>
            <div className="text-base font-bold text-emerald-400 font-mono mt-1 flex items-center justify-center gap-0.5">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{speedTest.resultBufferbloat}</span>
            </div>
          </div>
        </div>

        {/* Primary Action Button */}
        <div className="flex gap-2">
          {!speedTest.isRunning ? (
            <button
              onClick={startSpeedTest}
              className="flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-semibold text-sm shadow-lg shadow-cyan-900/30 transition active:scale-[0.98]"
            >
              {speedTest.phase === 'completed' ? (
                <>
                  <RotateCcw className="w-4 h-4" />
                  <span>Run Test Again</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-white" />
                  <span>Start Speed Test</span>
                </>
              )}
            </button>
          ) : (
            <button
              onClick={stopSpeedTest}
              className="flex-1 py-3 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-semibold text-sm transition"
            >
              Cancel Test
            </button>
          )}

          <button
            onClick={onClose}
            className="px-4 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
