import React, { useState, useEffect } from 'react';
import { Gauge, X, Play, RefreshCw, CheckCircle2, ArrowDown, ArrowUp, Activity } from 'lucide-react';
import { VpnServer } from '../types/vpn';
import { Language, TRANSLATIONS } from '../translations';

interface SpeedTestModalProps {
  isOpen: boolean;
  onClose: () => void;
  server: VpnServer;
  language: Language;
}

export const SpeedTestModal: React.FC<SpeedTestModalProps> = ({
  isOpen,
  onClose,
  server,
  language,
}) => {
  const t = TRANSLATIONS[language];
  const [stage, setStage] = useState<'idle' | 'ping' | 'download' | 'upload' | 'complete'>('idle');
  const [pingVal, setPingVal] = useState(0);
  const [jitterVal, setJitterVal] = useState(0);
  const [downloadVal, setDownloadVal] = useState(0);
  const [uploadVal, setUploadVal] = useState(0);
  const [gaugeProgress, setGaugeProgress] = useState(0);

  // Reset on open
  useEffect(() => {
    if (isOpen) {
      setStage('idle');
      setPingVal(0);
      setJitterVal(0);
      setDownloadVal(0);
      setUploadVal(0);
      setGaugeProgress(0);
    }
  }, [isOpen]);

  const runTest = () => {
    setStage('ping');
    setPingVal(0);
    setJitterVal(0);
    setDownloadVal(0);
    setUploadVal(0);
    setGaugeProgress(10);

    // 1. Measure Ping & Jitter
    setTimeout(() => {
      const simulatedPing = Math.max(12, Math.round(server.ping * (0.9 + Math.random() * 0.2)));
      const simulatedJitter = Math.floor(Math.random() * 4) + 1;
      setPingVal(simulatedPing);
      setJitterVal(simulatedJitter);
      setStage('download');
      setGaugeProgress(30);

      // 2. Measure Download Speed with progressive ticks
      let dVal = 10;
      const targetDown = Math.max(25, Math.round((180 - server.ping * 0.45) * (1 - server.load / 250)));
      const downInterval = setInterval(() => {
        dVal += (targetDown - dVal) * 0.35 + Math.random() * 5;
        if (dVal >= targetDown - 2) {
          clearInterval(downInterval);
          setDownloadVal(targetDown);
          setStage('upload');
          setGaugeProgress(70);

          // 3. Measure Upload Speed with progressive ticks
          let uVal = 5;
          const targetUp = Math.round(targetDown * 0.55);
          const upInterval = setInterval(() => {
            uVal += (targetUp - uVal) * 0.35 + Math.random() * 3;
            if (uVal >= targetUp - 2) {
              clearInterval(upInterval);
              setUploadVal(targetUp);
              setStage('complete');
              setGaugeProgress(100);
            } else {
              setUploadVal(Math.round(uVal));
            }
          }, 120);
        } else {
          setDownloadVal(Math.round(dVal));
        }
      }, 120);

    }, 900);
  };

  if (!isOpen) return null;

  const currentDisplaySpeed = stage === 'download' ? downloadVal : stage === 'upload' ? uploadVal : stage === 'complete' ? downloadVal : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
              <Gauge className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                {t.speedTestTitle}
              </h2>
              <p className="text-xs text-slate-500">
                Target Node: {server.city} {server.flag} ({server.ip})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Speedometer Gauge Visual */}
        <div className="p-8 flex flex-col items-center justify-center relative">
          <div className="relative w-48 h-48 flex items-center justify-center">
            {/* SVG Circular Dial */}
            <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 100 100">
              {/* Background track */}
              <circle
                cx="50"
                cy="50"
                r="42"
                stroke="currentColor"
                strokeWidth="7"
                fill="transparent"
                className="text-slate-100 dark:text-slate-800"
              />
              {/* Animated Progress bar */}
              <circle
                cx="50"
                cy="50"
                r="42"
                stroke="#10B981"
                strokeWidth="7"
                strokeDasharray={264}
                strokeDashoffset={264 - (264 * gaugeProgress) / 100}
                strokeLinecap="round"
                fill="transparent"
                className="transition-all duration-300"
              />
            </svg>

            {/* Inner Content Display */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              {stage === 'idle' ? (
                <button
                  onClick={runTest}
                  className="px-4 py-2 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-sm shadow-lg shadow-emerald-500/25 transition-all active:scale-95 flex items-center gap-1.5"
                >
                  <Play className="w-4 h-4 fill-white" />
                  <span>{t.startSpeedTest}</span>
                </button>
              ) : (
                <>
                  <span className="text-4xl font-black font-mono tracking-tight text-slate-900 dark:text-white tabular-nums">
                    {currentDisplaySpeed}
                  </span>
                  <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                    {t.mbps}
                  </span>
                  <span className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1 font-medium">
                    {stage === 'ping'
                      ? t.testingPing
                      : stage === 'download'
                      ? t.testingDownload
                      : stage === 'upload'
                      ? t.testingUpload
                      : t.testComplete}
                  </span>
                </>
              )}
            </div>
          </div>

          {/* Metric Quad Boxes */}
          <div className="w-full grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-6 text-center">
            {/* Ping */}
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <div className="text-[11px] text-slate-500 dark:text-slate-400 mb-0.5">{t.ping}</div>
              <div className="text-base font-black font-mono text-slate-900 dark:text-white tabular-nums">
                {pingVal > 0 ? `${pingVal}ms` : '--'}
              </div>
            </div>

            {/* Jitter */}
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <div className="text-[11px] text-slate-500 dark:text-slate-400 mb-0.5">{t.jitter}</div>
              <div className="text-base font-black font-mono text-slate-900 dark:text-white tabular-nums">
                {jitterVal > 0 ? `${jitterVal}ms` : '--'}
              </div>
            </div>

            {/* Download */}
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <div className="flex items-center justify-center gap-1 text-[11px] text-emerald-600 dark:text-emerald-400 mb-0.5">
                <ArrowDown className="w-3 h-3" />
                <span>{t.download}</span>
              </div>
              <div className="text-base font-black font-mono text-emerald-600 dark:text-emerald-400 tabular-nums">
                {downloadVal > 0 ? `${downloadVal}` : '--'}
              </div>
            </div>

            {/* Upload */}
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <div className="flex items-center justify-center gap-1 text-[11px] text-indigo-600 dark:text-indigo-400 mb-0.5">
                <ArrowUp className="w-3 h-3" />
                <span>{t.upload}</span>
              </div>
              <div className="text-base font-black font-mono text-indigo-600 dark:text-indigo-400 tabular-nums">
                {uploadVal > 0 ? `${uploadVal}` : '--'}
              </div>
            </div>
          </div>

          {/* Test Conclusion Grade */}
          {stage === 'complete' && (
            <div className="w-full mt-4 p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                <div className="text-left text-xs">
                  <div className="font-bold text-emerald-700 dark:text-emerald-300">
                    {downloadVal > 60 ? t.excellent : downloadVal > 30 ? t.good : t.fair}
                  </div>
                  <div className="text-emerald-600/80 dark:text-emerald-400/80 text-[11px]">
                    Optimized for 4K streaming, low-jitter voice calls and zero packet drop.
                  </div>
                </div>
              </div>
              <button
                onClick={runTest}
                className="p-2 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 transition-colors"
                title="Rerun test"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold transition-colors"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
