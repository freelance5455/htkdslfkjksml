import React from 'react';
import { BlockVisualEffect, PlacedPieceItem, ShapeDefinition } from '../types/game';
import { ShapeMatrix } from './BlockPiece';

interface PieceTrayProps {
  pieces: PlacedPieceItem[];
  canPieceFit: (shape: ShapeDefinition) => boolean;
  onPointerDownPiece: (e: React.PointerEvent, index: number) => void;
  draggingIndex: number | null;
  visualStyle?: BlockVisualEffect;
}

export const PieceTray: React.FC<PieceTrayProps> = ({
  pieces,
  canPieceFit,
  onPointerDownPiece,
  draggingIndex,
  visualStyle = 'crystalline',
}) => {
  return (
    <div className="w-full max-w-[400px] mx-auto px-2 py-0.5 sm:py-1 select-none shrink-0 touch-none">
      <div className="grid grid-cols-3 gap-1.5 sm:gap-2 items-center min-h-[72px] sm:min-h-[84px]">
        {pieces.map((item, index) => {
          if (item.used) {
            return (
              <div
                key={item.id}
                className="h-[70px] sm:h-[80px] rounded-xl border border-dashed border-slate-800/40 bg-slate-900/15 flex items-center justify-center opacity-25"
              />
            );
          }

          const isCurrentlyDragging = draggingIndex === index;
          const fits = canPieceFit(item.shape);

          // Calculate miniature cell size based on shape width & height so it fits the slot comfortably
          const maxDim = Math.max(item.shape.width, item.shape.height);
          const cellSize = maxDim <= 2 ? 20 : maxDim === 3 ? 16 : maxDim === 4 ? 13 : 11;

          return (
            <div
              key={item.id}
              onPointerDown={(e) => onPointerDownPiece(e, index)}
              style={{ touchAction: 'none' }}
              className={`relative h-[70px] sm:h-[80px] rounded-xl border flex items-center justify-center cursor-grab active:cursor-grabbing transition-all duration-100 ${
                isCurrentlyDragging ? 'opacity-0 scale-95 pointer-events-none' : ''
              } ${
                fits
                  ? 'bg-[#0f172a]/90 hover:bg-[#1e293b]/90 border-slate-700/60 shadow-md hover:shadow-cyan-500/10 active:scale-95'
                  : 'bg-[#0b1120]/60 border-slate-800/50 opacity-40 grayscale-40 cursor-not-allowed'
              }`}
            >
              {/* Piece preview */}
              <div className="flex items-center justify-center p-1 pointer-events-none">
                <ShapeMatrix
                  matrix={item.shape.matrix}
                  color={item.shape.color}
                  cellSize={cellSize}
                  visualStyle={visualStyle}
                />
              </div>

              {/* Status helper when piece cannot fit */}
              {!fits && !isCurrentlyDragging && (
                <div className="absolute bottom-0.5 text-[8px] font-semibold tracking-tight text-slate-500 uppercase">
                  No Space
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
