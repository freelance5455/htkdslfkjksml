import React, { useEffect, useRef, useState } from 'react';
import { Track, TabType } from '../types';
import { X, Play, Pause, SkipBack, SkipForward, Sparkles, Sun, Flame, HeartHandshake, Shield, Volume2, Moon, Check, Radio, Music2, BookOpen, ChevronUp, ChevronDown, ChevronLeft, ChevronRight, Compass, Move, Share2 } from 'lucide-react';
import { audioEngine } from '../lib/audioEngine';
import { CircularProgressRing } from './CircularProgressRing';
import { Navbar } from './Navbar';
import { ProfessionalFooter } from './ProfessionalFooter';
import { getSharePrefix, updateSocialMetadata } from '../lib/seoHelper';

interface FullPlayerModalProps {
  currentTrack: Track;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onClose: () => void;
  onNextTrack: () => void;
  onPrevTrack: () => void;
  currentTab?: TabType;
  onTabChange?: (tab: TabType) => void;
  onOpenProphetBio?: () => void;
  onOpenPrayerModal?: () => void;
  onOpenUserProfile?: () => void;
  onOpenSearch?: () => void;
  onOpenDownloadModal?: () => void;
  onOpenUploadModal?: () => void;
  onOpenWebPublishModal?: () => void;
  onOpenSignup?: () => void;
  onHome?: () => void;
  onPrevPage?: () => void;
  onNextPage?: () => void;
  onOpenTextMessages?: () => void;
}

export const FullPlayerModal: React.FC<FullPlayerModalProps> = ({
  currentTrack,
  isPlaying,
  onTogglePlay,
  onClose,
  onNextTrack,
  onPrevTrack,
  currentTab = 'worship',
  onTabChange = (_tab: TabType) => {},
  onOpenProphetBio = () => {},
  onOpenPrayerModal = () => {},
  onOpenUserProfile = () => {},
  onOpenSearch = () => {},
  onOpenDownloadModal = () => {},
  onOpenUploadModal = () => {},
  onOpenWebPublishModal = () => {},
  onOpenSignup = () => {},
  onHome = () => {},
  onPrevPage = () => {},
  onNextPage = () => {},
  onOpenTextMessages = () => {},
}) => {
  const modalContainerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [activeTab, setActiveTab] = useState<'visualizer' | 'lyrics' | 'decrees'>('visualizer');
  const [progress, setProgress] = useState(0);

  // Sleep Timer States
  const [sleepTimerMins, setSleepTimerMins] = useState<number | null>(null);
  const [sleepSecondsLeft, setSleepSecondsLeft] = useState<number | null>(null);
  const [showSleepDropdown, setShowSleepDropdown] = useState(false);

  // Directional Scroll Helpers for Full Player Modal
  const handleScrollUp = () => {
    if (modalContainerRef.current) {
      modalContainerRef.current.scrollBy({ top: -350, behavior: 'smooth' });
    }
  };

  const handleScrollDown = () => {
    if (modalContainerRef.current) {
      modalContainerRef.current.scrollBy({ top: 350, behavior: 'smooth' });
    }
  };

  const handleScrollLeft = () => {
    if (modalContainerRef.current) {
      modalContainerRef.current.scrollBy({ left: -300, behavior: 'smooth' });
    }
  };

  const handleScrollRight = () => {
    if (modalContainerRef.current) {
      modalContainerRef.current.scrollBy({ left: 300, behavior: 'smooth' });
    }
  };

  const handleScrollToTop = () => {
    if (modalContainerRef.current) {
      modalContainerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  useEffect(() => {
    let interval: number;
    if (isPlaying) {
      interval = window.setInterval(() => {
        setProgress((prev) => (prev >= currentTrack.duration ? 0 : prev + 1));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, currentTrack.duration]);

  // Sleep timer countdown
  useEffect(() => {
    let timer: number;
    if (sleepSecondsLeft !== null && sleepSecondsLeft > 0 && isPlaying) {
      timer = window.setInterval(() => {
        setSleepSecondsLeft((prev) => {
          if (prev === null || prev <= 1) {
            // Timer expired! Stop playing
            if (isPlaying) onTogglePlay();
            audioEngine.stopAll();
            alert('Sleep timer completed. Audio stopped in peace. Good night! 🙏');
            return null;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [sleepSecondsLeft, isPlaying, onTogglePlay]);

  const startSleepTimer = (mins: number) => {
    setSleepTimerMins(mins);
    setSleepSecondsLeft(mins * 60);
    setShowSleepDropdown(false);
  };

  const cancelSleepTimer = () => {
    setSleepTimerMins(null);
    setSleepSecondsLeft(null);
    setShowSleepDropdown(false);
  };

  const formatSleepTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const handleTogglePlayHaptic = () => {
    if (navigator.vibrate) navigator.vibrate([15]);
    onTogglePlay();
  };

  const handleNextHaptic = () => {
    if (navigator.vibrate) navigator.vibrate([15]);
    onNextTrack();
  };

  const handlePrevHaptic = () => {
    if (navigator.vibrate) navigator.vibrate([15]);
    onPrevTrack();
  };

  // Spectrum visualizer animation loop
  useEffect(() => {
    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const render = () => {
      animId = requestAnimationFrame(render);
      const analyser = audioEngine.getAnalyser();
      const bufferLength = analyser ? analyser.frequencyBinCount : 32;
      const dataArray = new Uint8Array(bufferLength);

      if (analyser && isPlaying) {
        analyser.getByteFrequencyData(dataArray);
      } else {
        // Soft fallback pulse data
        for (let i = 0; i < bufferLength; i++) {
          dataArray[i] = Math.sin((Date.now() / 400) + i) * 30 + 40;
        }
      }

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const width = canvas.width;
      const height = canvas.height;
      const centerX = width / 2;
      const centerY = height / 2;

      // Draw glowing central orb aura
      const avg = dataArray.reduce((a, b) => a + b, 0) / bufferLength;
      const radius = 70 + (avg / 255) * 45;

      const gradient = ctx.createRadialGradient(centerX, centerY, 10, centerX, centerY, radius + 40);
      gradient.addColorStop(0, 'rgba(251, 191, 36, 0.9)');
      gradient.addColorStop(0.4, 'rgba(217, 119, 6, 0.4)');
      gradient.addColorStop(0.8, 'rgba(147, 51, 234, 0.15)');
      gradient.addColorStop(1, 'rgba(15, 23, 42, 0)');

      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius + 40, 0, Math.PI * 2);
      ctx.fill();

      // Circular spectrum bars
      const numBars = 48;
      const angleStep = (Math.PI * 2) / numBars;

      for (let i = 0; i < numBars; i++) {
        const value = dataArray[i % bufferLength] || 20;
        const barHeight = (value / 255) * 80 + 10;
        const angle = i * angleStep;

        const x1 = centerX + Math.cos(angle) * radius;
        const y1 = centerY + Math.sin(angle) * radius;
        const x2 = centerX + Math.cos(angle) * (radius + barHeight);
        const y2 = centerY + Math.sin(angle) * (radius + barHeight);

        ctx.strokeStyle = `hsl(${(i * 7 + Date.now() / 50) % 360}, 90%, 65%)`;
        ctx.lineWidth = 3;
        ctx.lineCap = 'round';

        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
      }
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [isPlaying]);

  const handleShareTrack = async () => {
    const prefix = getSharePrefix();
    const shareText = `${prefix} "${currentTrack.title}" by ${currentTrack.artist} - Stream on JUHNKRIX MUSIKA App`;
    const url = window.location.href;
    
    updateSocialMetadata(
        currentTrack.title,
        shareText,
        currentTrack.albumArt || 'https://juhnkrixmusika.pages.dev/icon-512.png',
        url
    );

    if (navigator.share) {
      try {
        await navigator.share({
          title: currentTrack.title,
          text: shareText,
          url: url,
        });
      } catch (err) {
        console.log('Share canceled', err);
      }
    } else {
      navigator.clipboard.writeText(`${shareText} (${url})`);
      alert('Track link copied to clipboard!');
    }
  };

  return (
    <div 
      ref={modalContainerRef}
      className="fixed inset-0 z-50 bg-slate-950/98 backdrop-blur-3xl text-amber-100 flex flex-col overflow-y-auto overflow-x-hidden animate-fadeIn scroll-smooth"
    >
      {/* Top Application Header / Navbar */}
      <div className="sticky top-0 z-40 bg-slate-950/95 backdrop-blur-md border-b border-amber-500/20 flex items-center justify-between px-3">
        <Navbar
          currentTab={currentTab}
          onTabChange={(tab) => {
            onTabChange(tab);
          }}
          onOpenProphetBio={onOpenProphetBio}
          onOpenPrayerModal={onOpenPrayerModal}
          onOpenUserProfile={onOpenUserProfile}
          onOpenSearch={onOpenSearch}
          onOpenDownloadModal={onOpenDownloadModal}
          onOpenUploadModal={onOpenUploadModal}
          onOpenWebPublishModal={onOpenWebPublishModal}
          onOpenSignup={onOpenSignup}
          isLiveNow={true}
        />
        <button
          onClick={handleShareTrack}
          className="p-2.5 rounded-full bg-slate-900 hover:bg-slate-800 text-amber-300 hover:text-amber-200 transition-colors border border-amber-500/20 mr-2"
          title="Share Track"
        >
          <Share2 className="w-5 h-5" />
        </button>
      </div>

      {/* Soaking Room Sub-Navigation Bar with Directional Scroll Controls */}
      <div className="p-3 sm:p-5 flex flex-wrap items-center justify-between border-b border-amber-500/10 bg-slate-900/50 gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-400/30">
            <Sun className="w-5 h-5 text-amber-400 animate-spin-slow" />
          </div>
          <div>
            <span className="text-xs font-bold tracking-widest text-amber-400 uppercase">
              JUHNKRIX MUSIKA
            </span>
            <h3 className="text-sm font-semibold text-amber-100">Glory Soaking Sanctuary</h3>
          </div>
        </div>

        {/* Center: Directional Scroll Controls (Up, Down, Left, Right) */}
        <div className="flex items-center space-x-1.5 bg-slate-900/90 px-2.5 py-1.5 rounded-xl border border-amber-500/20 shadow-inner">
          <span className="text-[10px] text-amber-400/90 font-bold uppercase tracking-wider mr-1 flex items-center space-x-1">
            <Move className="w-3 h-3 text-amber-400" />
            <span className="hidden sm:inline">Scroll:</span>
          </span>
          <button
            onClick={handleScrollUp}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-amber-500/20 text-slate-300 hover:text-amber-300 transition-all border border-slate-700 hover:border-amber-400/40 active:scale-95"
            title="Scroll Modal Up"
          >
            <ChevronUp className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleScrollDown}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-amber-500/20 text-slate-300 hover:text-amber-300 transition-all border border-slate-700 hover:border-amber-400/40 active:scale-95"
            title="Scroll Modal Down"
          >
            <ChevronDown className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleScrollLeft}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-amber-500/20 text-slate-300 hover:text-amber-300 transition-all border border-slate-700 hover:border-amber-400/40 active:scale-95"
            title="Scroll Left"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleScrollRight}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-amber-500/20 text-slate-300 hover:text-amber-300 transition-all border border-slate-700 hover:border-amber-400/40 active:scale-95"
            title="Scroll Right"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* View Mode Toggle */}
        <div className="flex items-center space-x-1 bg-slate-900/80 p-1 rounded-xl border border-amber-500/20">
          <button
            onClick={() => setActiveTab('visualizer')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'visualizer'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-400/30 font-bold'
                : 'text-slate-400 hover:text-amber-200'
            }`}
          >
            Aura Visualizer
          </button>
          <button
            onClick={() => setActiveTab('lyrics')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'lyrics'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-400/30 font-bold'
                : 'text-slate-400 hover:text-amber-200'
            }`}
          >
            Anointed Lyrics
          </button>
          <button
            onClick={() => setActiveTab('decrees')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'decrees'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-400/30 font-bold'
                : 'text-slate-400 hover:text-amber-200'
            }`}
          >
            Prophetic Decrees
          </button>
        </div>

        <div className="flex items-center space-x-3">
          {/* Sleep Timer Dropdown / Button */}
          <div className="relative">
            <button
              onClick={() => setShowSleepDropdown(!showSleepDropdown)}
              className={`px-3 py-2 rounded-xl text-xs font-medium flex items-center space-x-1.5 border transition-all ${
                sleepSecondsLeft !== null
                  ? 'bg-amber-500/20 text-amber-300 border-amber-400 animate-pulse'
                  : 'bg-slate-900 text-slate-300 hover:text-amber-300 border-amber-500/20'
              }`}
              title="Sleep Timer"
            >
              <Moon className="w-4 h-4 text-amber-400" />
              <span>
                {sleepSecondsLeft !== null ? formatSleepTime(sleepSecondsLeft) : 'Sleep Timer'}
              </span>
            </button>

            {showSleepDropdown && (
              <div className="absolute right-0 mt-2 w-48 bg-slate-900 border border-amber-500/30 rounded-2xl shadow-2xl p-2 z-50 space-y-1 animate-fadeIn">
                <div className="text-[10px] font-bold text-amber-400 uppercase tracking-wider px-2 py-1">
                  Stop Audio After:
                </div>
                {[15, 30, 45, 60].map((mins) => (
                  <button
                    key={mins}
                    onClick={() => startSleepTimer(mins)}
                    className="w-full text-left px-3 py-1.5 rounded-xl text-xs text-slate-300 hover:bg-amber-500/20 hover:text-amber-200 flex items-center justify-between transition-colors"
                  >
                    <span>{mins} Minutes</span>
                    {sleepTimerMins === mins && <Check className="w-3.5 h-3.5 text-amber-400" />}
                  </button>
                ))}
                {sleepSecondsLeft !== null && (
                  <button
                    onClick={cancelSleepTimer}
                    className="w-full text-left px-3 py-1.5 rounded-xl text-xs text-rose-400 hover:bg-rose-500/10 font-semibold transition-colors border-t border-slate-800 mt-1"
                  >
                    Cancel Timer
                  </button>
                )}
              </div>
            )}
          </div>

          <button
            onClick={onClose}
            className="p-2.5 rounded-full bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-amber-300 transition-colors border border-amber-500/20"
            title="Minimize to Floating Audio Bar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Sanctuary Stage */}
      <div className="flex-1 relative flex items-center justify-center p-6 max-w-5xl mx-auto w-full">
        {activeTab === 'visualizer' && (
          <div className="relative flex flex-col items-center justify-center w-full h-full">
            {/* Visualizer Canvas */}
            <canvas
              ref={canvasRef}
              width={480}
              height={480}
              className="max-w-full max-h-[380px] object-contain drop-shadow-[0_0_50px_rgba(245,158,11,0.3)]"
            />

            {/* Central Track Details Below Canvas */}
            <div className="mt-6 text-center space-y-2 max-w-lg">
              <span className="px-3 py-1 rounded-full text-[11px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-400/30 inline-flex items-center">
                <Sparkles className="w-3.5 h-3.5 mr-1 text-amber-400" />
                {currentTrack.category}
              </span>
              <h2 className="text-2xl sm:text-3xl font-bold font-serif text-amber-100 tracking-wide">
                {currentTrack.title}
              </h2>
              <p className="text-amber-300/80 text-sm">{currentTrack.artist}</p>
              <p className="text-slate-400 text-xs italic bg-slate-900/60 p-3 rounded-2xl border border-amber-500/10">
                &ldquo;{currentTrack.scriptureRef}&rdquo;
              </p>
            </div>
          </div>
        )}

        {activeTab === 'lyrics' && (
          <div className="w-full max-w-2xl bg-slate-900/60 p-8 rounded-3xl border border-amber-500/20 text-center space-y-6 max-h-[70vh] overflow-y-auto">
            <h3 className="text-xs tracking-widest text-amber-400 uppercase font-bold flex items-center justify-center space-x-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Anointed Praise Words & Prayer Chants</span>
            </h3>

            <div className="whitespace-pre-line text-lg sm:text-xl font-serif text-amber-100 leading-relaxed space-y-4">
              {currentTrack.lyrics || (
                <p className="text-slate-400 text-sm italic">
                  Instrumental Soaking Presence... Focus on the glory of God and quiet your heart.
                </p>
              )}
            </div>
          </div>
        )}

        {activeTab === 'decrees' && (
          <div className="w-full max-w-3xl grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-gradient-to-br from-amber-950/40 via-slate-900/80 to-slate-950 p-6 rounded-3xl border border-amber-500/30 space-y-3">
              <div className="flex items-center space-x-2 text-amber-400 text-xs font-bold uppercase">
                <Shield className="w-4 h-4" />
                <span>Decree of Protection</span>
              </div>
              <p className="text-amber-100 font-serif text-sm leading-relaxed">
                &ldquo;No weapon fashioned against my peace, my health, or my family shall prosper. I walk under the shadow of the Almighty.&rdquo;
              </p>
            </div>

            <div className="bg-gradient-to-br from-purple-950/40 via-slate-900/80 to-slate-950 p-6 rounded-3xl border border-purple-500/30 space-y-3">
              <div className="flex items-center space-x-2 text-amber-400 text-xs font-bold uppercase">
                <Flame className="w-4 h-4" />
                <span>Decree of Breakthrough</span>
              </div>
              <p className="text-amber-100 font-serif text-sm leading-relaxed">
                &ldquo;Every closed door opens by the key of David! I step into unprecedented divine momentum and favor!&rdquo;
              </p>
            </div>

            <div className="bg-gradient-to-br from-indigo-950/40 via-slate-900/80 to-slate-950 p-6 rounded-3xl border border-indigo-500/30 space-y-3 md:col-span-2">
              <div className="flex items-center space-x-2 text-amber-400 text-xs font-bold uppercase">
                <HeartHandshake className="w-4 h-4" />
                <span>Decree of Divine Restoration</span>
              </div>
              <p className="text-amber-100 font-serif text-sm leading-relaxed">
                &ldquo;The years that the locusts have eaten are restored sevenfold. Peace, health, and spiritual clarity are my portion in Jesus name.&rdquo;
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Large Playback Bar */}
      <div className="p-8 border-t border-amber-500/10 bg-slate-950/90 flex flex-col items-center justify-center space-y-4">
        <div className="flex items-center space-x-8">
          <button
            onClick={handlePrevHaptic}
            className="p-3 rounded-full bg-slate-900 hover:bg-slate-800 text-amber-300 transition-transform active:scale-95"
          >
            <SkipBack className="w-6 h-6" />
          </button>

          <CircularProgressRing
            progress={progress}
            duration={currentTrack.duration}
            isPlaying={isPlaying}
            size={88}
            strokeWidth={4}
            showTimeText={true}
            onSeek={(newTime) => setProgress(newTime)}
          >
            <button
              onClick={handleTogglePlayHaptic}
              className="w-14 h-14 rounded-full bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-400 text-slate-950 flex items-center justify-center shadow-xl shadow-amber-500/40 hover:scale-105 active:scale-95 transition-all"
            >
              {isPlaying ? (
                <Pause className="w-7 h-7 fill-slate-950 text-slate-950" />
              ) : (
                <Play className="w-7 h-7 fill-slate-950 text-slate-950 ml-0.5" />
              )}
            </button>
          </CircularProgressRing>

          <button
            onClick={handleNextHaptic}
            className="p-3 rounded-full bg-slate-900 hover:bg-slate-800 text-amber-300 transition-transform active:scale-95"
          >
            <SkipForward className="w-6 h-6" />
          </button>
        </div>

        <p className="text-xs text-slate-400 flex items-center space-x-1">
          <Volume2 className="w-3.5 h-3.5 text-amber-400 mr-1" />
          <span>Prophet JUHNKRIX SYNVAGORD • High Quality Divine Soaking Audio</span>
        </p>
      </div>

      {/* Global JUHNKRIX MUSIKA Footer in Full Player */}
      <div className="border-t border-amber-500/20 bg-slate-950/95">
        <ProfessionalFooter
          currentTrack={currentTrack}
          onOpenPrayerModal={onOpenPrayerModal}
          onOpenSignup={onOpenSignup}
          onOpenTextMessages={onOpenTextMessages}
          onHome={onHome}
          onPrevPage={onPrevPage}
          onNextPage={onNextPage}
        />
      </div>
    </div>
  );
};
