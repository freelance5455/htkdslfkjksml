import React, { useState, useEffect } from 'react';
import { Navigation, Compass, MapPin, Gauge, Radio, Shield, Zap, RefreshCw, Satellite } from 'lucide-react';

export const GpsNavigator: React.FC = () => {
  const [position, setPosition] = useState<{ lat: number, lng: number, speed: number, heading: number, altitude: number } | null>(null);
  const [gpsStatus, setGpsStatus] = useState<'searching' | 'locked' | 'error'>('searching');
  const [waypoints, setWaypoints] = useState<Array<{ name: string, lat: number, lng: number, status: string }>>([
    { name: 'Estación Central Sonó', lat: 4.6097, lng: -74.0817, status: 'Activa (Repetidor 1)' },
    { name: 'Torre de Transmisión Norte', lat: 4.7110, lng: -74.0721, status: 'Señal Óptima' },
    { name: 'Búnker Subterráneo Sur', lat: 4.5981, lng: -74.1573, status: 'Modo Emergencia' }
  ]);
  const [navDestination, setNavDestination] = useState('');

  useEffect(() => {
    if ('geolocation' in navigator) {
      const watchId = navigator.geolocation.watchPosition(
        (pos) => {
          setPosition({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            speed: pos.coords.speed ? Math.round(pos.coords.speed * 3.6) : 18, // km/h
            heading: pos.coords.heading || 145,
            altitude: pos.coords.altitude ? Math.round(pos.coords.altitude) : 2640
          });
          setGpsStatus('locked');
        },
        (err) => {
          console.warn('Geolocation warning, using simulation fallback:', err);
          // Fallback simulation coordinates for Bogota / Cyberpunk grid
          setPosition({ lat: 4.6097, lng: -74.0817, speed: 22, heading: 180, altitude: 2600 });
          setGpsStatus('locked');
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
      return () => navigator.geolocation.clearWatch(watchId);
    } else {
      setPosition({ lat: 4.6097, lng: -74.0817, speed: 15, heading: 90, altitude: 2600 });
      setGpsStatus('locked');
    }
  }, []);

  return (
    <div className="space-y-6">
      <div className="bg-[#0b0c16]/90 backdrop-blur-xl border border-[#00ff88]/30 rounded-2xl p-6 shadow-[0_0_30px_rgba(0,255,136,0.15)]">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-[#00ff88]/20 rounded-xl border border-[#00ff88]/50 text-[#00ff88]">
              <Navigation className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white tracking-wider">MAPS GPS NAVEGADOR REAL</h2>
              <p className="text-xs text-gray-400">Telemetría satelital, geolocalización en tiempo real y balizas de radio</p>
            </div>
          </div>
          <div className="flex items-center gap-2 px-3 py-1 bg-black/40 border border-[#00ff88]/40 rounded-full text-xs font-mono text-[#00ff88]">
            <Satellite className="w-3.5 h-3.5 animate-spin" />
            GPS: {gpsStatus === 'locked' ? '🛰️ 12 Satélites Conectados' : 'Buscando Señal...'}
          </div>
        </div>

        {/* Telemetry HUD Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-black/50 border border-[#00ff88]/30 rounded-xl p-4 text-center">
            <div className="text-[10px] text-gray-400 font-mono uppercase mb-1">Velocidad Actual</div>
            <div className="text-2xl font-black text-[#00ff88] font-mono">{position?.speed || 0} <span className="text-xs text-white">KM/H</span></div>
          </div>
          <div className="bg-black/50 border border-[#00ff88]/30 rounded-xl p-4 text-center">
            <div className="text-[10px] text-gray-400 font-mono uppercase mb-1">Rumbo / Orientación</div>
            <div className="text-2xl font-black text-[#00d4ff] font-mono">{position?.heading || 0}° <span className="text-xs text-white">SE</span></div>
          </div>
          <div className="bg-black/50 border border-[#00ff88]/30 rounded-xl p-4 text-center">
            <div className="text-[10px] text-gray-400 font-mono uppercase mb-1">Altitud Barométrica</div>
            <div className="text-2xl font-black text-[#ff0055] font-mono">{position?.altitude || 0} <span className="text-xs text-white">MSNM</span></div>
          </div>
          <div className="bg-black/50 border border-[#00ff88]/30 rounded-xl p-4 text-center">
            <div className="text-[10px] text-gray-400 font-mono uppercase mb-1">Precisión Satelital</div>
            <div className="text-2xl font-black text-yellow-400 font-mono">&lt; 1.5m</div>
          </div>
        </div>

        {/* Interactive Map Visualizer / Canvas Simulator */}
        <div className="relative bg-black border-2 border-[#00ff88]/40 rounded-2xl overflow-hidden h-[380px] mb-6 flex items-center justify-center shadow-[inset_0_0_30px_rgba(0,255,136,0.1)]">
          {/* Simulated Cyberpunk Radar / Map Grid background */}
          <div className="absolute inset-0 bg-[radial-gradient(#00ff88_1px,transparent_1px)] [background-size:24px_24px] opacity-20"></div>
          
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-64 h-64 rounded-full border border-[#00ff88]/20 animate-ping absolute"></div>
            <div className="w-48 h-48 rounded-full border border-[#00ff88]/30 absolute"></div>
            <div className="w-24 h-24 rounded-full border border-[#00ff88]/50 absolute"></div>
          </div>

          <div className="z-10 text-center p-6 bg-black/80 backdrop-blur-md border border-[#00ff88]/40 rounded-2xl max-w-md mx-4 shadow-[0_0_20px_rgba(0,255,136,0.3)]">
            <MapPin className="w-10 h-10 text-[#00ff88] mx-auto mb-3 animate-bounce" />
            <h3 className="text-white font-bold text-lg mb-1">Coordenadas Activas de Navegación</h3>
            <p className="text-xs font-mono text-[#00ff88] mb-3">
              Lat: {position?.lat.toFixed(6) || '4.609700'} | Lng: {position?.lng.toFixed(6) || '-74.081700'}
            </p>
            <p className="text-xs text-gray-300">
              Sistema de Navegador GPS enlazado con la red de radiofrecuencia Sonó. Las coordenadas de transmisión están sincronizadas con los repetidores de la zona.
            </p>
          </div>
        </div>

        {/* Waypoints & Beacons */}
        <h4 className="text-xs font-mono text-gray-400 uppercase tracking-widest mb-3">Balizas y Estaciones de Radio Cercanas</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {waypoints.map((wp, idx) => (
            <div key={idx} className="bg-black/50 border border-[#00ff88]/30 rounded-xl p-4 flex items-center justify-between">
              <div>
                <div className="text-white font-bold text-sm">{wp.name}</div>
                <div className="text-[10px] text-gray-400 font-mono">Lat: {wp.lat}, Lng: {wp.lng}</div>
              </div>
              <span className="px-2.5 py-1 bg-[#00ff88]/20 text-[#00ff88] border border-[#00ff88]/40 text-[10px] font-mono rounded-lg">
                {wp.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
