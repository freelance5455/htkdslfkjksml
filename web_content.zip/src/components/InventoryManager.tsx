import React, { useState } from 'react';
import { 
  Boxes, 
  AlertTriangle, 
  TrendingUp, 
  PlusCircle, 
  Search, 
  ArrowUpRight, 
  ArrowDownRight, 
  History, 
  CheckCircle2, 
  XCircle, 
  Edit3, 
  Package, 
  RefreshCw,
  Plus,
  Minus,
  Sparkles,
  Download
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { Product, ProductCategory } from '../types';

interface InventoryManagerProps {
  onOpenAddProduct: () => void;
  onEditProduct: (p: Product) => void;
}

export const InventoryManager: React.FC<InventoryManagerProps> = ({ 
  onOpenAddProduct, 
  onEditProduct 
}) => {
  const { 
    products, 
    stockMovements, 
    restockProduct, 
    decreaseStock,
    simulateIncomingSale 
  } = useStore();

  const [activeTab, setActiveTab] = useState<'inventory' | 'movements'>('inventory');
  const [filterCategory, setFilterCategory] = useState<ProductCategory>('all');
  const [filterStockStatus, setFilterStockStatus] = useState<'all' | 'low' | 'out' | 'ok'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Quick restock modal state
  const [restockModalItem, setRestockModalItem] = useState<Product | null>(null);
  const [restockAmount, setRestockAmount] = useState<number>(10);
  const [restockReason, setRestockReason] = useState<string>('Reposição de lote semanal');

  // Inventory computations
  const totalUnits = products.reduce((acc, p) => acc + p.stock, 0);
  const totalStockValue = products.reduce((acc, p) => acc + (p.stock * p.price), 0);
  const lowStockItems = products.filter(p => p.stock > 0 && p.stock <= p.minStockAlert);
  const outOfStockItems = products.filter(p => p.stock === 0);
  const totalSalesUnits = products.reduce((acc, p) => acc + p.salesCount, 0);

  const filteredProducts = products.filter(p => {
    const matchesCat = filterCategory === 'all' || p.category === filterCategory;
    const matchesSearch = searchQuery === '' || 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.sku.toLowerCase().includes(searchQuery.toLowerCase());
    
    let matchesStatus = true;
    if (filterStockStatus === 'low') matchesStatus = p.stock > 0 && p.stock <= p.minStockAlert;
    else if (filterStockStatus === 'out') matchesStatus = p.stock === 0;
    else if (filterStockStatus === 'ok') matchesStatus = p.stock > p.minStockAlert;

    return matchesCat && matchesSearch && matchesStatus;
  });

  const handleExecuteRestock = (e: React.FormEvent) => {
    e.preventDefault();
    if (!restockModalItem || restockAmount <= 0) return;
    restockProduct(restockModalItem.id, restockAmount, restockReason);
    setRestockModalItem(null);
    setRestockAmount(10);
  };

  return (
    <div className="space-y-6 pb-16">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-600">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Monitoramento em Tempo Real</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Gestão de Estoque & Inventário
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Baixas automáticas no checkout EscalePay, alertas de reposição e auditoria de movimentações.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={simulateIncomingSale}
            className="px-3.5 py-2 bg-purple-50 hover:bg-purple-100 text-purple-800 text-xs font-semibold rounded-lg border border-purple-200 transition-colors flex items-center gap-1.5 shadow-xs"
            title="Simular compra instantânea de um cliente para ver a baixa em tempo real"
          >
            <RefreshCw className="w-3.5 h-3.5 text-purple-600" />
            <span>Simular Venda Real-time</span>
          </button>

          <button
            onClick={onOpenAddProduct}
            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Adicionar Produto</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Total Units */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-medium">Unidades em Estoque</span>
            <Boxes className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
              {totalUnits}
            </span>
            <span className="text-[11px] text-slate-400 font-mono">
              {products.length} SKUs
            </span>
          </div>
          <div className="text-[11px] text-emerald-600 font-medium flex items-center gap-1">
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>Estoque sincronizado ao vivo</span>
          </div>
        </div>

        {/* Card 2: Total Asset Value */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-medium">Valor Total do Estoque</span>
            <TrendingUp className="w-4 h-4 text-blue-600" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
              {totalStockValue.toLocaleString('pt-MZ')} <span className="text-sm font-normal">MT</span>
            </span>
          </div>
          <div className="text-[11px] text-slate-500">
            Preço de venda projetado
          </div>
        </div>

        {/* Card 3: Low Stock Warnings */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-medium">Alertas de Baixo Estoque</span>
            <AlertTriangle className="w-4 h-4 text-amber-500" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-amber-600 tabular-nums">
              {lowStockItems.length}
            </span>
            <span className="text-[11px] text-amber-700 bg-amber-50 border border-amber-200 px-1.5 py-0.5 rounded font-medium">
              Abaixo de 5 un.
            </span>
          </div>
          <div className="text-[11px] text-slate-500">
            Recomenda-se reposição de lote
          </div>
        </div>

        {/* Card 4: Total Units Sold */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-medium">Vendas Realizadas</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
              {totalSalesUnits}
            </span>
            <span className="text-[11px] text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded font-medium">
              Pedidos pagos
            </span>
          </div>
          <div className="text-[11px] text-slate-500">
            Atualização instantânea via checkout
          </div>
        </div>

      </div>

      {/* Main Tab Controller (Inventory Table vs Movements Audit Log) */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-2">
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl">
          <button
            onClick={() => setActiveTab('inventory')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 ${
              activeTab === 'inventory'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Boxes className="w-3.5 h-3.5" />
            <span>Tabela de Inventário ({products.length})</span>
          </button>
          
          <button
            onClick={() => setActiveTab('movements')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 ${
              activeTab === 'movements'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Histórico de Movimentações ({stockMovements.length})</span>
          </button>
        </div>
      </div>

      {activeTab === 'inventory' ? (
        <div className="space-y-4">
          
          {/* Filters Bar */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3 rounded-xl border border-slate-200">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs text-slate-500 font-medium">Filtrar status:</span>
              <button
                onClick={() => setFilterStockStatus('all')}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-colors ${
                  filterStockStatus === 'all'
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Todos
              </button>
              <button
                onClick={() => setFilterStockStatus('low')}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-colors ${
                  filterStockStatus === 'low'
                    ? 'bg-amber-600 text-white'
                    : 'bg-amber-50 text-amber-700 hover:bg-amber-100'
                }`}
              >
                Baixo Estoque ({lowStockItems.length})
              </button>
              <button
                onClick={() => setFilterStockStatus('out')}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-colors ${
                  filterStockStatus === 'out'
                    ? 'bg-rose-600 text-white'
                    : 'bg-rose-50 text-rose-700 hover:bg-rose-100'
                }`}
              >
                Esgotados ({outOfStockItems.length})
              </button>
            </div>

            <div className="relative sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Buscar por nome ou SKU..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
              />
            </div>
          </div>

          {/* Real-time Table */}
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-600">
                <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-700 uppercase font-semibold text-[11px] tracking-wider">
                  <tr>
                    <th scope="col" className="px-4 py-3">Produto / SKU</th>
                    <th scope="col" className="px-4 py-3">Tipo</th>
                    <th scope="col" className="px-4 py-3 text-right">Preço</th>
                    <th scope="col" className="px-4 py-3 text-center">Estoque Atual</th>
                    <th scope="col" className="px-4 py-3 text-center">Status</th>
                    <th scope="col" className="px-4 py-3 text-center">Vendas</th>
                    <th scope="col" className="px-4 py-3 text-right">Ações Rápidas</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredProducts.map((p) => {
                    const isOut = p.stock === 0;
                    const isLow = p.stock > 0 && p.stock <= p.minStockAlert;

                    return (
                      <tr key={p.id} className="hover:bg-slate-50/60 transition-colors">
                        
                        {/* Name & SKU */}
                        <td className="px-4 py-3.5">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-lg bg-slate-100 overflow-hidden shrink-0 border border-slate-200">
                              <img
                                src={p.image}
                                alt={p.name}
                                referrerPolicy="no-referrer"
                                className="w-full h-full object-cover"
                                onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
                              />
                            </div>
                            <div>
                              <div className="font-semibold text-slate-900 line-clamp-1">{p.name}</div>
                              <div className="font-mono text-[11px] text-slate-400">{p.sku}</div>
                            </div>
                          </div>
                        </td>

                        {/* Type */}
                        <td className="px-4 py-3.5">
                          <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-medium ${
                            p.type === 'digital' 
                              ? 'bg-purple-50 text-purple-700 border border-purple-200' 
                              : 'bg-blue-50 text-blue-700 border border-blue-200'
                          }`}>
                            {p.type === 'digital' ? 'Digital / Infoproduto' : 'Físico'}
                          </span>
                        </td>

                        {/* Price */}
                        <td className="px-4 py-3.5 text-right font-mono font-bold text-slate-900 tabular-nums">
                          {p.price.toLocaleString('pt-MZ')} MT
                        </td>

                        {/* Live Stock with inline +/- steppers */}
                        <td className="px-4 py-3.5">
                          <div className="flex items-center justify-center gap-2">
                            <button
                              onClick={() => decreaseStock(p.id, 1, '#Ajuste_Manual')}
                              disabled={p.stock <= 0}
                              className="p-1 text-slate-400 hover:text-rose-600 disabled:opacity-30 rounded hover:bg-slate-100"
                              title="Decrementar 1 unidade"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="font-mono font-bold text-slate-900 text-sm w-10 text-center tabular-nums">
                              {p.stock}
                            </span>
                            <button
                              onClick={() => restockProduct(p.id, 1, 'Ajuste manual (+1)')}
                              className="p-1 text-slate-400 hover:text-emerald-600 rounded hover:bg-slate-100"
                              title="Incrementar 1 unidade"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>

                        {/* Status */}
                        <td className="px-4 py-3.5 text-center">
                          {isOut ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-rose-50 text-rose-700 border border-rose-200">
                              <XCircle className="w-3 h-3" />
                              <span>Esgotado</span>
                            </span>
                          ) : isLow ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-50 text-amber-700 border border-amber-200">
                              <AlertTriangle className="w-3 h-3" />
                              <span>Baixo ({p.stock})</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                              <CheckCircle2 className="w-3 h-3" />
                              <span>Normal ({p.stock})</span>
                            </span>
                          )}
                        </td>

                        {/* Sales */}
                        <td className="px-4 py-3.5 text-center font-mono text-slate-700 tabular-nums">
                          {p.salesCount} un.
                        </td>

                        {/* Actions */}
                        <td className="px-4 py-3.5 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => {
                                setRestockModalItem(p);
                                setRestockAmount(10);
                              }}
                              className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-[11px] font-semibold rounded border border-emerald-200 transition-colors"
                              title="Reabastecer lote de produtos"
                            >
                              Reabastecer
                            </button>
                            <button
                              onClick={() => onEditProduct(p)}
                              className="p-1.5 text-slate-500 hover:text-slate-800 rounded hover:bg-slate-100 transition-colors"
                              title="Editar Produto"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>

                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        /* Movements Audit Log Tab */
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Auditoria de Movimentações de Estoque
              </h3>
              <p className="text-[11px] text-slate-500">
                Log em tempo real de todas as vendas no checkout e reposições efetuadas.
              </p>
            </div>
            <span className="text-xs font-mono text-slate-500">
              Total de registros: {stockMovements.length}
            </span>
          </div>

          <div className="divide-y divide-slate-100">
            {stockMovements.map((mov) => {
              const isSale = mov.type === 'sale';
              return (
                <div key={mov.id} className="p-3.5 flex items-center justify-between text-xs hover:bg-slate-50/50 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                      isSale 
                        ? 'bg-rose-50 text-rose-600 border border-rose-200' 
                        : 'bg-emerald-50 text-emerald-600 border border-emerald-200'
                    }`}>
                      {isSale ? <ArrowDownRight className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                    </div>
                    <div>
                      <div className="font-semibold text-slate-900">{mov.productName}</div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-2">
                        <span>{mov.reason}</span>
                        <span>·</span>
                        <span className="text-slate-400 font-mono">
                          {new Date(mov.timestamp).toLocaleString('pt-MZ')}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className={`font-mono font-bold tabular-nums text-sm ${
                      mov.quantityChange < 0 ? 'text-rose-600' : 'text-emerald-600'
                    }`}>
                      {mov.quantityChange > 0 ? `+${mov.quantityChange}` : mov.quantityChange} un.
                    </div>
                    <div className="text-[11px] font-mono text-slate-400">
                      Saldo: {mov.stockBefore} → <strong className="text-slate-700">{mov.stockAfter}</strong>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Quick Restock Modal */}
      {restockModalItem && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-900">
                Reabastecer Estoque
              </h3>
              <button 
                onClick={() => setRestockModalItem(null)}
                className="text-slate-400 hover:text-slate-700 text-sm"
              >
                ✕
              </button>
            </div>

            <div className="text-xs text-slate-600">
              Produto: <strong className="text-slate-900">{restockModalItem.name}</strong>
              <div className="text-slate-400 font-mono mt-0.5">
                SKU: {restockModalItem.sku} • Estoque atual: {restockModalItem.stock} un.
              </div>
            </div>

            <form onSubmit={handleExecuteRestock} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Quantidade a Adicionar
                </label>
                <input
                  type="number"
                  min="1"
                  required
                  value={restockAmount}
                  onChange={(e) => setRestockAmount(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Motivo da Reposição / Lote
                </label>
                <input
                  type="text"
                  value={restockReason}
                  onChange={(e) => setRestockReason(e.target.value)}
                  placeholder="Ex: Recebimento de novo lote do fornecedor"
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg text-slate-900"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setRestockModalItem(null)}
                  className="px-3.5 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors"
                >
                  Confirmar Entrada (+{restockAmount} un.)
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
};
