import React, { useState } from 'react';
import { FLUTTER_FILES, FlutterProjectFile } from '../utils/flutterCodeMap';
import { Folder, FileCode, Copy, Check, Download, ExternalLink, Code2 } from 'lucide-react';
import JSZip from 'jszip';

interface FlutterCodeViewerProps {
  onClose: () => void;
}

export const FlutterCodeViewer: React.FC<FlutterCodeViewerProps> = ({ onClose }) => {
  const [selectedFile, setSelectedFile] = useState<FlutterProjectFile>(FLUTTER_FILES[0]);
  const [copied, setCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);

  const categories = Array.from(new Set(FLUTTER_FILES.map((f) => f.category)));

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const zip = new JSZip();
      const folder = zip.folder('safeher_ai');

      FLUTTER_FILES.forEach((file) => {
        folder?.file(file.path, file.content);
      });

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'safeher_ai_flutter_project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Failed to create ZIP', e);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 sm:p-6">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-6xl h-[90vh] rounded-2xl flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 bg-slate-950 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-rose-500/20 text-rose-400 rounded-xl">
              <Code2 className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                SafeHer AI Flutter Source Code Hub
                <span className="text-xs px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-mono">
                  com.example.safeherai
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Complete Flutter & Dart codebase for VS Code, Android Studio, and Viva Demonstration
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleDownloadZip}
              disabled={isZipping}
              className="flex items-center gap-2 px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-sm font-semibold transition shadow-lg shadow-rose-900/30 cursor-pointer disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              {isZipping ? 'Packaging ZIP...' : 'Download Full Flutter Project (ZIP)'}
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-sm font-medium transition cursor-pointer"
            >
              Close Hub
            </button>
          </div>
        </div>

        {/* Workspace body */}
        <div className="flex-1 flex overflow-hidden">
          {/* File Tree Explorer */}
          <div className="w-72 bg-slate-950/70 border-r border-slate-800 flex flex-col overflow-y-auto p-4 space-y-4">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider px-2">
              Project Structure
            </div>

            {categories.map((cat) => (
              <div key={cat} className="space-y-1">
                <div className="flex items-center gap-2 px-2 text-xs font-semibold text-slate-500">
                  <Folder className="w-3.5 h-3.5 text-slate-400" />
                  <span>{cat}</span>
                </div>
                <div className="space-y-0.5 pl-2">
                  {FLUTTER_FILES.filter((f) => f.category === cat).map((file) => (
                    <button
                      key={file.path}
                      onClick={() => setSelectedFile(file)}
                      className={`w-full text-left flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-mono transition cursor-pointer ${
                        selectedFile.path === file.path
                          ? 'bg-rose-600/20 text-rose-300 font-semibold border border-rose-500/30'
                          : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                      }`}
                    >
                      <FileCode className="w-3.5 h-3.5 opacity-70 shrink-0" />
                      <span className="truncate">{file.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Code Viewer Panel */}
          <div className="flex-1 flex flex-col bg-slate-900/90 overflow-hidden">
            {/* File Path Bar */}
            <div className="px-6 py-2.5 bg-slate-950/40 border-b border-slate-800/80 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-mono text-slate-300">
                <span className="text-slate-500">safeher_ai/</span>
                <span className="text-rose-400 font-semibold">{selectedFile.path}</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopy}
                  className="flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium transition cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? 'Copied!' : 'Copy Code'}
                </button>
              </div>
            </div>

            {/* Code content */}
            <div className="flex-1 overflow-auto p-6 font-mono text-xs text-slate-200 leading-relaxed selection:bg-rose-600 selection:text-white">
              <pre className="whitespace-pre">
                <code>{selectedFile.content}</code>
              </pre>
            </div>
          </div>
        </div>

        {/* Footer command helper */}
        <div className="px-6 py-3 bg-slate-950 border-t border-slate-800 text-xs text-slate-400 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-rose-400 font-semibold">How to run in VS Code:</span>
            <code className="bg-slate-800 px-2 py-0.5 rounded text-slate-300 font-mono">
              flutter pub get && flutter run
            </code>
          </div>
          <div className="text-slate-400">
            Build APK: <code className="bg-slate-800 px-2 py-0.5 rounded text-slate-300 font-mono">flutter build apk --release</code>
          </div>
        </div>
      </div>
    </div>
  );
};
