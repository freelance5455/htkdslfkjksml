import React from 'react';
import { INITIAL_LEADERBOARD } from '../utils/mockData';
import { useApp } from '../context/AppContext';
import { 
  Trophy, 
  Calendar, 
  Award, 
  ArrowLeft 
} from 'lucide-react';

const WEEKLY_THEMES = [
  { day: 'Friday', title: 'Funny Friday', tag: '😂 2x Karma', desc: 'Share your most embarrassing campus fail or hostel comedy.', color: 'border-amber-500/40 bg-amber-950/20 text-amber-300' },
  { day: 'Monday', title: 'Love Monday', tag: '❤️ Crush Spotlight', desc: 'Anonymous admiration for that mystery person in your 8 AM lecture.', color: 'border-pink-500/40 bg-pink-950/20 text-pink-300' },
  { day: 'Wednesday', title: 'Exam Vent Wednesday', tag: '⚡ Trauma Release', desc: 'Scream about tough professors, viva exams, and dead GPAs.', color: 'border-cyan-500/40 bg-cyan-950/20 text-cyan-300' },
  { day: 'Midnight', title: 'Midnight Sanctum', tag: '🌙 Deep Whispers', desc: 'Late night philosophies and real confessions between 12 AM - 4 AM.', color: 'border-purple-500/40 bg-purple-950/20 text-purple-300' },
];

export const LeaderboardView: React.FC = () => {
  const { user, setActiveTab } = useApp();

  return (
    <div className="space-y-4 pb-20">
      
      {/* Top Back Navigation Bar */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => setActiveTab('feed')}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-cyan-500/50 text-cyan-300 text-xs font-semibold transition-all group active:scale-95"
        >
          <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform" />
          <span>Back to Feeds</span>
        </button>
      </div>

      {/* Top Banner */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-amber-950/40 via-purple-950/30 to-slate-900 border border-amber-500/30 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-1.5 text-xs text-amber-400 font-semibold mb-1">
            <Trophy className="w-3.5 h-3.5" />
            <span>Anonymous Hall of Fame</span>
          </div>
          <h2 className="font-display font-black text-lg sm:text-xl text-slate-100">
            Leaderboard & Badges
          </h2>
          <p className="text-xs text-slate-400">
            Earn karma through popular confessions and honest votes.
          </p>
        </div>
        <div className="w-12 h-12 rounded-2xl bg-amber-900/40 border border-amber-500/40 flex items-center justify-center text-2xl shadow-lg neon-glow-purple">
          🏆
        </div>
      </div>

      {/* Your Current Rank Card */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-cyan-950/30 via-slate-900 to-indigo-950/30 border border-cyan-500/40 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-full bg-cyan-950 border border-cyan-500/50 flex items-center justify-center text-xl">
            {user.avatarEmoji}
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-semibold text-sm text-slate-100">{user.avatarName} (You)</span>
              <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/80 px-1.5 py-0.5 rounded border border-cyan-500/30">
                {user.secretHashId}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Rank #8 in {user.collegeName ? user.collegeName.split(' ')[0] : 'Campus'}
            </p>
          </div>
        </div>
        <div className="text-right">
          <span className="text-[10px] text-slate-400 block">Total Karma</span>
          <span className="font-mono text-base font-extrabold text-cyan-300 tabular-nums">
            {user.karma}
          </span>
        </div>
      </div>

      {/* Daily & Weekly Themes */}
      <div>
        <h3 className="font-display font-bold text-sm text-slate-200 mb-2.5 flex items-center gap-1.5">
          <Calendar className="w-4 h-4 text-purple-400" />
          <span>Active Daily & Weekly Themes</span>
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {WEEKLY_THEMES.map((theme, i) => (
            <div key={i} className={`p-3.5 rounded-2xl border ${theme.color} space-y-1`}>
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold">{theme.title}</span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded-full bg-black/40 border border-white/10">
                  {theme.tag}
                </span>
              </div>
              <p className="text-[11px] text-slate-300/90 leading-relaxed">
                {theme.desc}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Top Creators Table */}
      <div className="space-y-2">
        <h3 className="font-display font-bold text-sm text-slate-200 flex items-center gap-1.5">
          <Award className="w-4 h-4 text-amber-400" />
          <span>Top Anonymous Whispers (All Colleges)</span>
        </h3>
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl divide-y divide-slate-800/80 overflow-hidden">
          {INITIAL_LEADERBOARD.map(item => (
            <div key={item.rank} className="p-3.5 flex items-center justify-between hover:bg-slate-800/40 transition-colors">
              <div className="flex items-center gap-3">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center font-mono text-xs font-bold ${
                  item.rank === 1 ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/30' :
                  item.rank === 2 ? 'bg-slate-300 text-slate-950' :
                  item.rank === 3 ? 'bg-amber-700 text-white' :
                  'bg-slate-800 text-slate-400'
                }`}>
                  {item.rank}
                </div>
                <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-sm">
                  {item.emoji}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-semibold text-slate-200">{item.name}</span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-purple-950/60 border border-purple-500/30 text-purple-300">
                      {item.badge}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">
                    {item.college}
                  </span>
                </div>
              </div>
              <div className="text-right">
                <span className="font-mono text-xs font-bold text-cyan-400 tabular-nums">
                  {item.karma} karma
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
