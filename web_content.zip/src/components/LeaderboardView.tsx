import React, { useMemo, useState } from 'react';
import {
  Trophy,
  Medal,
  TrendingUp,
  Search,
  Filter,
  Sparkles,
  Award,
  Flame,
  ArrowUpRight,
  PiggyBank,
  CheckCircle2,
} from 'lucide-react';
import { INITIAL_LEADERBOARD } from '../data/mockData';
import { LeaderboardStudent, StudentProfile } from '../types';
import { formatNumber, formatRupiah } from '../utils/formatters';

interface LeaderboardViewProps {
  currentProfile: StudentProfile;
  currentSavings: number;
  onOpenTransferSavings: () => void;
  onOpenTopUp: () => void;
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({
  currentProfile,
  currentSavings,
  onOpenTransferSavings,
  onOpenTopUp,
}) => {
  const [selectedGradeFilter, setSelectedGradeFilter] = useState<string>('all');
  const [selectedPeriod, setSelectedPeriod] = useState<'month' | 'semester' | 'all_time'>('month');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Assemble full student list dynamically with current user
  const combinedStudents: LeaderboardStudent[] = useMemo(() => {
    const currentUserItem: LeaderboardStudent = {
      id: 'current-user-student',
      name: currentProfile.name + ' (Kamu)',
      avatar: currentProfile.avatar,
      grade: currentProfile.grade,
      school: currentProfile.school,
      savingsAmount: currentSavings,
      monthlyGrowth: currentSavings > 0 ? Math.round(currentSavings * 0.25) : 0,
      badge: currentSavings >= 2000000 ? 'Sultan Hemat 🌟' : currentSavings >= 1000000 ? 'Bintang Penabung ⭐' : 'Pejuang Celengan 🌱',
      streakDays: 15,
      isCurrentUser: true,
    };

    const list = [...INITIAL_LEADERBOARD, currentUserItem];

    // Sort descending by savingsAmount
    return list.sort((a, b) => b.savingsAmount - a.savingsAmount);
  }, [currentProfile, currentSavings]);

  // Find current user's actual rank
  const currentUserRank = useMemo(() => {
    const idx = combinedStudents.findIndex((s) => s.isCurrentUser);
    return idx !== -1 ? idx + 1 : 1;
  }, [combinedStudents]);

  // Filter by grade and search query
  const filteredStudents = useMemo(() => {
    return combinedStudents.filter((student) => {
      // Grade filter
      if (selectedGradeFilter !== 'all') {
        if (!student.grade.toLowerCase().includes(selectedGradeFilter.toLowerCase())) {
          return false;
        }
      }
      // Search
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        return (
          student.name.toLowerCase().includes(query) ||
          student.grade.toLowerCase().includes(query)
        );
      }
      return true;
    });
  }, [combinedStudents, selectedGradeFilter, searchQuery]);

  const top3 = combinedStudents.slice(0, 3);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-amber-500 via-orange-600 to-rose-600 p-6 sm:p-8 text-white shadow-lg">
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 -mr-8 -mt-8 w-44 h-44 rounded-full bg-white/10 blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-xl">
            <div className="flex items-center gap-2 text-amber-200 text-xs font-bold uppercase tracking-wider mb-2">
              <Trophy className="w-4 h-4" />
              <span>Kompetisi Tabungan Siswa {currentProfile.school}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Papan Peringkat Penabung Tertinggi
            </h1>
            <p className="text-xs sm:text-sm text-amber-100 mt-2 leading-relaxed">
              Tingkatkan kebiasaan hemat dan persiapkan masa depan! Siswa dengan tabungan tertinggi mendapatkan lencana kehormatan dan beasiswa apresiasi sekolah.
            </p>
          </div>

          {/* Current User Rank Card */}
          <div className="bg-white/15 backdrop-blur-md border border-white/25 rounded-2xl p-4 sm:p-5 flex items-center gap-4 shrink-0 shadow-lg">
            <div className="w-14 h-14 rounded-2xl bg-amber-400 text-slate-900 font-extrabold text-2xl flex items-center justify-center font-mono shadow-md">
              #{currentUserRank}
            </div>
            <div>
              <p className="text-[11px] text-amber-200 font-medium">Peringkat Tabungan Kamu</p>
              <p className="text-base font-bold text-white truncate max-w-[150px]">
                {currentProfile.name}
              </p>
              <p className="text-xs font-mono font-semibold text-amber-300">
                {formatRupiah(currentSavings)}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Podium Top 3 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end pt-4">
        {/* Rank 2 (Silver) */}
        {top3[1] && (
          <div className="order-2 md:order-1 bg-white border border-slate-200 rounded-3xl p-5 text-center shadow-xs relative overflow-hidden transition-all hover:shadow-md">
            <div className="absolute top-3 left-3 bg-slate-100 text-slate-600 font-extrabold text-xs px-2.5 py-1 rounded-full font-mono">
              🥈 #2
            </div>
            {top3[1].isCurrentUser && (
              <span className="absolute top-3 right-3 text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
                Kamu
              </span>
            )}
            <div className="w-16 h-16 mx-auto rounded-2xl border-2 border-slate-300 overflow-hidden shadow-sm mb-3 mt-4 bg-slate-50">
              <img src={top3[1].avatar} alt={top3[1].name} className="w-full h-full object-cover" />
            </div>
            <h4 className="font-bold text-sm text-slate-900 truncate">{top3[1].name}</h4>
            <p className="text-xs text-slate-500">{top3[1].grade}</p>
            <div className="mt-3 py-1.5 px-3 bg-slate-50 rounded-xl">
              <span className="text-[11px] text-slate-400 block">Total Tabungan</span>
              <span className="text-sm font-extrabold text-slate-800 font-mono">
                {formatRupiah(top3[1].savingsAmount)}
              </span>
            </div>
            <div className="mt-2 text-[10px] text-slate-500 flex items-center justify-center gap-1">
              <Flame className="w-3 h-3 text-orange-500" />
              <span>{top3[1].streakDays} hari rajin nabung</span>
            </div>
          </div>
        )}

        {/* Rank 1 (Gold - Winner) */}
        {top3[0] && (
          <div className="order-1 md:order-2 bg-gradient-to-b from-amber-50 to-white border-2 border-amber-400 rounded-3xl p-6 text-center shadow-md relative overflow-hidden transform md:-translate-y-2">
            <div className="absolute top-3 left-3 bg-amber-400 text-slate-950 font-extrabold text-xs px-3 py-1 rounded-full font-mono shadow-sm">
              🥇 #1 JUARA
            </div>
            {top3[0].isCurrentUser && (
              <span className="absolute top-3 right-3 text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
                Kamu
              </span>
            )}
            <div className="w-20 h-20 mx-auto rounded-2xl border-4 border-amber-400 overflow-hidden shadow-lg mb-3 mt-4 bg-amber-100 ring-4 ring-amber-400/20">
              <img src={top3[0].avatar} alt={top3[0].name} className="w-full h-full object-cover" />
            </div>
            <h4 className="font-extrabold text-base text-slate-900 truncate">{top3[0].name}</h4>
            <p className="text-xs text-amber-800 font-medium">{top3[0].grade} • {top3[0].badge}</p>
            <div className="mt-3 py-2 px-4 bg-amber-100/70 rounded-2xl border border-amber-200">
              <span className="text-[11px] text-amber-900 block font-semibold">Total Tabungan Juara</span>
              <span className="text-base font-extrabold text-slate-900 font-mono">
                {formatRupiah(top3[0].savingsAmount)}
              </span>
            </div>
            <div className="mt-2 text-[11px] text-amber-700 flex items-center justify-center gap-1 font-semibold">
              <Flame className="w-3.5 h-3.5 text-orange-500" />
              <span>{top3[0].streakDays} hari streak menabung</span>
            </div>
          </div>
        )}

        {/* Rank 3 (Bronze) */}
        {top3[2] && (
          <div className="order-3 md:order-3 bg-white border border-slate-200 rounded-3xl p-5 text-center shadow-xs relative overflow-hidden transition-all hover:shadow-md">
            <div className="absolute top-3 left-3 bg-amber-100 text-amber-800 font-extrabold text-xs px-2.5 py-1 rounded-full font-mono">
              🥉 #3
            </div>
            {top3[2].isCurrentUser && (
              <span className="absolute top-3 right-3 text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
                Kamu
              </span>
            )}
            <div className="w-16 h-16 mx-auto rounded-2xl border-2 border-amber-300 overflow-hidden shadow-sm mb-3 mt-4 bg-slate-50">
              <img src={top3[2].avatar} alt={top3[2].name} className="w-full h-full object-cover" />
            </div>
            <h4 className="font-bold text-sm text-slate-900 truncate">{top3[2].name}</h4>
            <p className="text-xs text-slate-500">{top3[2].grade}</p>
            <div className="mt-3 py-1.5 px-3 bg-slate-50 rounded-xl">
              <span className="text-[11px] text-slate-400 block">Total Tabungan</span>
              <span className="text-sm font-extrabold text-slate-800 font-mono">
                {formatRupiah(top3[2].savingsAmount)}
              </span>
            </div>
            <div className="mt-2 text-[10px] text-slate-500 flex items-center justify-center gap-1">
              <Flame className="w-3 h-3 text-orange-500" />
              <span>{top3[2].streakDays} hari rajin nabung</span>
            </div>
          </div>
        )}
      </div>

      {/* Boost Savings CTA */}
      <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
            <PiggyBank className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-emerald-950">Ingin Menembus Top 3 Sekolah?</h4>
            <p className="text-[11px] text-emerald-800">
              Tinggal menambah tabungan sedikit lagi untuk naik peringkat di sekolahmu!
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            type="button"
            onClick={onOpenTransferSavings}
            className="flex-1 sm:flex-initial px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-colors shadow-sm"
          >
            Pindah ke Tabungan
          </button>
          <button
            type="button"
            onClick={onOpenTopUp}
            className="flex-1 sm:flex-initial px-4 py-2 bg-white hover:bg-slate-50 text-emerald-800 border border-emerald-300 text-xs font-bold rounded-xl transition-colors"
          >
            Top Up Langsung
          </button>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Grade filter */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
            {[
              { id: 'all', label: 'Semua Tingkat' },
              { id: 'X', label: 'Kelas X' },
              { id: 'XI', label: 'Kelas XI' },
              { id: 'XII', label: 'Kelas XII' },
            ].map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => setSelectedGradeFilter(f.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                  selectedGradeFilter === f.id
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:text-slate-900 hover:bg-slate-200'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Search box */}
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari nama teman sekelas..."
              className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        {/* Leaderboard Table / List */}
        <div className="divide-y divide-slate-100 overflow-hidden">
          {filteredStudents.length === 0 ? (
            <div className="text-center py-8 text-slate-400 text-xs">
              Tidak ada data siswa yang cocok dengan pencarian.
            </div>
          ) : (
            filteredStudents.map((student) => {
              // Real rank in whole school
              const rank = combinedStudents.findIndex((s) => s.id === student.id) + 1;
              const isUser = student.isCurrentUser;

              return (
                <div
                  key={student.id}
                  className={`py-3.5 px-3 flex items-center justify-between gap-3 rounded-2xl transition-colors ${
                    isUser
                      ? 'bg-emerald-50/80 border border-emerald-200 font-semibold'
                      : 'hover:bg-slate-50'
                  }`}
                >
                  {/* Left: Rank & Student Profile */}
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-7 h-7 rounded-xl flex items-center justify-center font-mono text-xs font-extrabold shrink-0 ${
                        rank === 1
                          ? 'bg-amber-400 text-slate-950'
                          : rank === 2
                          ? 'bg-slate-300 text-slate-800'
                          : rank === 3
                          ? 'bg-amber-200 text-amber-900'
                          : isUser
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {rank}
                    </div>

                    <div className="w-10 h-10 rounded-xl border border-slate-200 overflow-hidden shrink-0 bg-slate-100">
                      <img
                        src={student.avatar}
                        alt={student.name}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <p className={`text-xs truncate ${isUser ? 'font-extrabold text-emerald-950' : 'font-bold text-slate-900'}`}>
                          {student.name}
                        </p>
                        {isUser && (
                          <span className="text-[10px] font-bold text-emerald-700 bg-emerald-200/70 px-1.5 py-0.2 rounded">
                            Kamu
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 truncate">
                        {student.grade} • {student.badge}
                      </p>
                    </div>
                  </div>

                  {/* Right: Savings Amount */}
                  <div className="text-right shrink-0">
                    <span className="text-xs sm:text-sm font-extrabold font-mono text-slate-900 block">
                      {formatRupiah(student.savingsAmount)}
                    </span>
                    <span className="text-[10px] text-emerald-600 font-semibold">
                      +{formatRupiah(student.monthlyGrowth)} bln ini
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
