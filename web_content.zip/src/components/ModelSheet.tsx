import { useState } from "react";
import { useStore } from "../lib/store";
import { listModels } from "../lib/provider-client";
import { Button, Icon, Sheet } from "./ui";
import { cn } from "../utils/cn";

export default function ModelSheet({
  open,
  onClose,
  onOpenSettings,
}: {
  open: boolean;
  onClose: () => void;
  onOpenSettings?: () => void;
}) {
  const { s, set, provider, showToast } = useStore();
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const models = provider.models.filter((model) =>
    model.toLowerCase().includes(query.toLowerCase()),
  );
  const choose = (model: string) => {
    if (!model.trim() || model.length > 200) return;
    set((state) => ({
      activeModel: model.trim(),
      providers: {
        ...state.providers,
        [provider.id]: {
          ...state.providers[provider.id],
          selectedModel: model.trim(),
          models: [
            ...new Set([...state.providers[provider.id].models, model.trim()]),
          ],
        },
      },
    }));
    setQuery("");
    onClose();
  };
  return (
    <Sheet
      open={open}
      onClose={onClose}
      title="Choose your model"
      subtitle="Same workspace. Your choice of intelligence."
      footer={
        <div className="flex gap-2">
          <Button
            block
            variant="secondary"
            icon="key"
            onClick={() => {
              onClose();
              onOpenSettings?.();
            }}
          >
            Manage API keys
          </Button>
          <Button
            block
            variant="primary"
            icon={loading ? "loading" : "refresh"}
            disabled={loading || !s.permissions.network}
            onClick={async () => {
              setLoading(true);
              setError("");
              const cfg = { ...provider };
              try {
                const ids = await listModels(cfg);
                set((state) => ({
                  providers: {
                    ...state.providers,
                    [cfg.id]: {
                      ...state.providers[cfg.id],
                      models: [
                        ...new Set([...ids, ...state.providers[cfg.id].models]),
                      ],
                      status: state.providers[cfg.id].status,
                    },
                  },
                }));
                showToast(`${ids.length} model IDs fetched.`);
              } catch (e) {
                setError(
                  e instanceof Error ? e.message : "Could not fetch models.",
                );
              } finally {
                setLoading(false);
              }
            }}
          >
            {loading ? "Fetching..." : "Fetch models"}
          </Button>
        </div>
      }
    >
      <div className="px-4 pb-3">
        <label className="block text-[11px] font-medium text-muted">
          PROVIDER
          <select
            aria-label="Select provider"
            value={s.activeProvider}
            onChange={(e) => {
              const p = s.providers[e.target.value];
              set({
                activeProvider: p.id,
                activeModel: p.selectedModel ?? p.models[0] ?? "",
              });
              setQuery("");
              setError("");
            }}
            className="mt-2 h-11 w-full rounded-xl border border-line bg-surface2 px-3 text-sm text-fg outline-none"
          >
            {s.providerOrder.map(
              (id) =>
                s.providers[id] && (
                  <option key={id} value={id}>
                    {s.providers[id].name}
                    {s.providers[id].apiKey || s.providers[id].allowNoKey
                      ? ""
                      : " / no key"}
                  </option>
                ),
            )}
          </select>
        </label>
        <div className="mt-3 flex items-center gap-2 rounded-xl border border-line bg-surface2 px-3">
          <Icon name="search" className="h-4 w-4 text-muted" />
          <input
            aria-label="Find or add model"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search or enter a model ID..."
            className="h-10 min-w-0 flex-1 bg-transparent text-sm outline-none"
          />
        </div>
        {error && (
          <p
            role="alert"
            className="mt-3 rounded-lg bg-dangersoft p-3 text-xs leading-relaxed text-danger"
          >
            {error}
          </p>
        )}
        {!provider.apiKey && !provider.allowNoKey && (
          <p className="mt-3 text-[11px] leading-relaxed text-muted">
            No key connected for {provider.name}. Add your own API key to use
            this model. The editor and browser preview work without a key.
          </p>
        )}
      </div>
      <div className="max-h-[40dvh] overflow-auto px-2 pb-3">
        {models.map((model) => (
          <button
            key={model}
            onClick={() => choose(model)}
            className={cn(
              "flex w-full items-center gap-3 rounded-lg px-3 py-3 text-left hover:bg-surface2",
              model === s.activeModel && "bg-accentsoft",
            )}
          >
            <Icon
              name="circleDot"
              className={cn(
                "h-4 w-4",
                model === s.activeModel ? "text-accent" : "text-muted",
              )}
            />
            <span className="min-w-0 flex-1 break-all font-mono text-xs">
              {model}
            </span>
            {model === s.activeModel && (
              <Icon name="check" className="h-4 w-4 text-accent" />
            )}
          </button>
        ))}
        {query.trim() && !provider.models.includes(query.trim()) && (
          <button
            onClick={() => choose(query)}
            className="flex w-full items-center gap-3 rounded-lg px-3 py-3 text-left text-xs text-accent hover:bg-surface2"
          >
            <Icon name="plus" className="h-4 w-4" />
            <span className="break-all">Use model ID: {query}</span>
          </button>
        )}
        {!models.length && !query && (
          <p className="px-3 py-6 text-xs text-muted">
            No saved models. Enter an ID above or fetch from your provider.
          </p>
        )}
      </div>
      <p className="px-5 pb-4 text-[10px] leading-relaxed text-muted">
        Preset IDs are starting points, not a guarantee of account access. Your
        provider controls availability, limits and usage fees.
      </p>
    </Sheet>
  );
}
