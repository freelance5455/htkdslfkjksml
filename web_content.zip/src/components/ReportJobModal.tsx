import React, { useState } from 'react';
import { JobPosting, ReportReason } from '../types/job';
import { submitJobReportToFirestore, getUserFriendlyErrorMessage } from '../lib/firebase';
import {
  AlertTriangle,
  X,
  Send,
  CheckCircle2,
  ShieldAlert,
  Loader2
} from 'lucide-react';

interface ReportJobModalProps {
  job: JobPosting | null;
  isOpen: boolean;
  onClose: () => void;
  currentUserEmail?: string;
}

const REPORT_REASONS: ReportReason[] = [
  'Fake job',
  'Wrong information',
  'Expired job',
  'Broken link',
  'Duplicate job',
  'Scam'
];

export const ReportJobModal: React.FC<ReportJobModalProps> = ({
  job,
  isOpen,
  onClose,
  currentUserEmail
}) => {
  const [selectedReason, setSelectedReason] = useState<ReportReason>('Fake job');
  const [details, setDetails] = useState('');
  const [email, setEmail] = useState(currentUserEmail || '');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen || !job) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setErrorMessage('');

    try {
      await submitJobReportToFirestore({
        jobId: job.id,
        jobTitle: job.title,
        organization: job.organization,
        reason: selectedReason,
        details: details.trim() || undefined,
        userEmail: email.trim() || undefined
      });
      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        setDetails('');
        onClose();
      }, 2500);
    } catch (err) {
      console.error('Error submitting report:', err);
      setErrorMessage(getUserFriendlyErrorMessage(err, 'Could not submit report right now. Please try again.'));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div
        id="modal-report-job"
        className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl space-y-4"
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400 shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">Report Job Vacancy</h2>
              <p className="text-xs text-slate-400">Help keep India Job Hub authentic & safe</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {submitted ? (
          <div className="py-8 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">Report Submitted to Admin</h3>
            <p className="text-xs text-slate-400 max-w-xs mx-auto">
              Thank you for reporting. Our verification team will review "{job.title}" against official gazette notifications.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <p className="font-semibold text-white truncate">{job.title}</p>
              <p className="text-[11px] text-slate-400 truncate">{job.organization}</p>
            </div>

            {/* Reason selector */}
            <div>
              <label className="block text-slate-300 font-semibold mb-1.5">
                What is the issue with this job? *
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                {REPORT_REASONS.map((reason) => (
                  <button
                    type="button"
                    key={reason}
                    onClick={() => setSelectedReason(reason)}
                    className={`py-2 px-3 rounded-xl border text-left transition-all ${
                      selectedReason === reason
                        ? 'bg-rose-500/20 border-rose-500/50 text-rose-300 font-bold'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    {selectedReason === reason ? '● ' : '○ '}
                    {reason}
                  </button>
                ))}
              </div>
            </div>

            {/* Details */}
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Additional Details (Optional)
              </label>
              <textarea
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                placeholder="Explain why this listing is invalid, provide official link, or describe broken links..."
                rows={3}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-xs"
              />
            </div>

            {/* Email */}
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Your Email (Optional, for updates)
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your.email@domain.com"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-xs"
              />
            </div>

            {/* Error Message */}
            {errorMessage && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Submit */}
            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white font-bold flex items-center justify-center gap-1.5 shadow-lg shadow-rose-600/30 transition-all active:scale-95"
              >
                {submitting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Submitting...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5" />
                    <span>Submit Report</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
