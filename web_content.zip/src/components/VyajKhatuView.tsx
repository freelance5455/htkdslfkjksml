import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Loan, LoanType } from '../types';
import { t, formatCurrency, formatDateDisplay } from '../utils/translations';
import { calculateLoanDetailed } from '../utils/interestCalculator';
import {
  Plus,
  Search,
  ArrowUpRight,
  ArrowDownLeft,
  Calendar,
  Percent,
  Clock,
  Printer,
  ChevronRight,
  ShieldCheck,
  CheckCircle2,
  Trash2,
  Edit,
  DollarSign,
  Award,
  Sparkles,
  BookOpen
} from 'lucide-react';
import { LoanModal } from './Modals/LoanModal';
import { LoanRepaymentModal } from './Modals/LoanRepaymentModal';
import { LoanDetailStatementModal } from './Modals/LoanDetailStatementModal';

export const VyajKhatuView: React.FC = () => {
  const { language, loans, deleteLoan, settleLoan } = useApp();

  const [activeTab, setActiveTab] = useState<LoanType>('lent');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'settled'>('active');

  // Modals state
  const [isNewLoanOpen, setIsNewLoanOpen] = useState(false);
  const [editingLoan, setEditingLoan] = useState<Loan | null>(null);
  const [repaymentLoan, setRepaymentLoan] = useState<Loan | null>(null);
  const [detailLoan, setDetailLoan] = useState<Loan | null>(null);

  // Filtered loans list
  const filteredLoans = loans.filter((l) => {
    if (l.type !== activeTab) return false;
    if (statusFilter !== 'all' && l.status !== statusFilter) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const matchName = l.partyName.toLowerCase().includes(q);
      const matchPhone = (l.partyPhone || '').toLowerCase().includes(q);
      const matchNotes = (l.notes || '').toLowerCase().includes(q);
      if (!matchName && !matchPhone && !matchNotes) return false;
    }
    return true;
  });

  // Calculate totals for activeTab
  const summary = filteredLoans.reduce(
    (acc, loan) => {
      const calc = calculateLoanDetailed(loan);
      acc.totalInitialPrincipal += loan.initialPrincipal;
      acc.totalCurrentPrincipal += calc.currentPrincipal;
      acc.totalAccruedInterest += calc.currentAccruedInterest;
      acc.totalBalanceRemaining += calc.totalBalanceRemaining;
      acc.totalRepaid += calc.totalRepaid;
      return acc;
    },
    {
      totalInitialPrincipal: 0,
      totalCurrentPrincipal: 0,
      totalAccruedInterest: 0,
      totalBalanceRemaining: 0,
      totalRepaid: 0
    }
  );

  const handleOpenNewLoan = () => {
    setEditingLoan(null);
    setIsNewLoanOpen(true);
  };

  const handleEditLoan = (loan: Loan) => {
    setEditingLoan(loan);
    setIsNewLoanOpen(true);
  };

  const handleDeleteLoan = (id: string) => {
    const confirmMsg =
      language === 'gu'
        ? 'શું તમે આ વ્યાજ ખાતું અને તેની તમામ ચૂકવણીઓ કાઢી નાખવા માંગો છો?'
        : 'Are you sure you want to delete this loan account and all its repayment logs?';
    if (window.confirm(confirmMsg)) {
      deleteLoan(id);
    }
  };

  const handleSettleLoan = (loan: Loan) => {
    const today = new Date().toISOString().split('T')[0];
    const confirmMsg =
      language === 'gu'
        ? `શું "${loan.partyName}" નું ખાતું સંપૂર્ણ ચૂકતે (હિસાબ પૂર્ણ) તરીકે ચિહ્નિત કરવું છે?`
        : `Mark loan account for "${loan.partyName}" as fully settled?`;
    if (window.confirm(confirmMsg)) {
      settleLoan(loan.id, today);
    }
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Type Switcher: Lent (ધીરેલ) vs Borrowed (લીધેલ) */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-2.5 rounded-2xl border border-stone-200 shadow-sm print-hide">
        <div className="grid grid-cols-2 gap-2 p-1 bg-stone-100 rounded-xl flex-1 sm:max-w-md">
          <button
            type="button"
            onClick={() => setActiveTab('lent')}
            className={`flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'lent'
                ? 'bg-emerald-700 text-white shadow-md'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <ArrowUpRight className="w-4 h-4 text-emerald-300" />
            <span>{t('lentLoans', language)}</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('borrowed')}
            className={`flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'borrowed'
                ? 'bg-red-800 text-white shadow-md'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <ArrowDownLeft className="w-4 h-4 text-rose-300" />
            <span>{t('borrowedLoans', language)}</span>
          </button>
        </div>

        <button
          type="button"
          onClick={handleOpenNewLoan}
          className="flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white text-xs font-bold transition-all shadow-md active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>{t('newLoan', language)}</span>
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* Remaining Principal */}
        <div className="rounded-2xl bg-white border border-stone-200 p-3.5 shadow-sm">
          <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider block">
            {t('currentPrincipal', language)}
          </span>
          <p className="text-lg sm:text-xl font-black text-stone-900 mt-1">
            {formatCurrency(summary.totalCurrentPrincipal, language)}
          </p>
          <span className="text-[10px] text-stone-400">
            મૂળ: {formatCurrency(summary.totalInitialPrincipal, language)}
          </span>
        </div>

        {/* Accrued Interest */}
        <div className="rounded-2xl bg-amber-50/80 border border-amber-200 p-3.5 shadow-sm">
          <span className="text-[11px] font-semibold text-amber-900 uppercase tracking-wider block">
            {t('accruedInterest', language)}
          </span>
          <p className="text-lg sm:text-xl font-black text-amber-800 mt-1">
            {formatCurrency(summary.totalAccruedInterest, language)}
          </p>
          <span className="text-[10px] text-amber-700">૧૦૦% લીપ વર્ષ ગણતરી</span>
        </div>

        {/* Total Repaid */}
        <div className="rounded-2xl bg-emerald-50/80 border border-emerald-200 p-3.5 shadow-sm">
          <span className="text-[11px] font-semibold text-emerald-900 uppercase tracking-wider block">
            {t('totalRepaid', language)}
          </span>
          <p className="text-lg sm:text-xl font-black text-emerald-800 mt-1">
            {formatCurrency(summary.totalRepaid, language)}
          </p>
          <span className="text-[10px] text-emerald-700">જમા થયેલ રકમ</span>
        </div>

        {/* Total Outstanding */}
        <div className="rounded-2xl bg-gradient-to-br from-red-950 to-stone-900 text-white p-3.5 shadow-md border border-amber-500/40">
          <span className="text-[11px] font-semibold text-amber-200/90 tracking-wide block">
            {t('totalOutstanding', language)}
          </span>
          <p className="text-xl sm:text-2xl font-black text-amber-300 mt-1">
            {formatCurrency(summary.totalBalanceRemaining, language)}
          </p>
          <span className="text-[10px] text-amber-200/70">
            {filteredLoans.length} {activeTab === 'lent' ? 'લેણદારો' : 'દેણદારો'}
          </span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-2.5 items-stretch sm:items-center justify-between bg-white p-3 rounded-2xl border border-stone-200 shadow-sm print-hide">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-stone-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={language === 'gu' ? 'નામ, ફોન કે વિગત શોધો...' : 'Search party name, phone...'}
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-stone-300 text-xs text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600 bg-stone-50/50"
          />
        </div>

        <div className="flex items-center gap-1 bg-stone-100 p-1 rounded-xl text-xs font-semibold">
          <button
            type="button"
            onClick={() => setStatusFilter('active')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              statusFilter === 'active' ? 'bg-white shadow text-amber-900 font-bold' : 'text-stone-600'
            }`}
          >
            {t('active', language)} ({loans.filter((l) => l.type === activeTab && l.status === 'active').length})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('settled')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              statusFilter === 'settled' ? 'bg-white shadow text-amber-900 font-bold' : 'text-stone-600'
            }`}
          >
            {t('settled', language)} ({loans.filter((l) => l.type === activeTab && l.status === 'settled').length})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              statusFilter === 'all' ? 'bg-white shadow text-amber-900 font-bold' : 'text-stone-600'
            }`}
          >
            {t('all', language)}
          </button>
        </div>
      </div>

      {/* Loan Accounts List */}
      {filteredLoans.length === 0 ? (
        <div className="rounded-2xl bg-white border border-stone-200 p-12 text-center text-stone-500 space-y-3">
          <BookOpen className="w-10 h-10 text-stone-300 mx-auto" />
          <p className="text-sm font-semibold">
            {language === 'gu'
              ? activeTab === 'lent'
                ? 'કોઈ ધીરેલ નાણાંનું ખાતું નથી'
                : 'કોઈ લીધેલ લોનનું ખાતું નથી'
              : 'No loan accounts found'}
          </p>
          <p className="text-xs text-stone-400 max-w-sm mx-auto">
            {language === 'gu'
              ? 'વ્યાજે આપેલ કે લીધેલ રકમનું ચોક્કસ હિસાબ રાખવા "+ નવું વ્યાજ/લોન ખાતું" બટન દબાવો.'
              : 'Click on "+ New Loan / Vyaj Entry" to add an accurate interest ledger.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredLoans.map((loan) => {
            const calc = calculateLoanDetailed(loan);

            return (
              <div
                key={loan.id}
                className={`rounded-2xl border transition-all duration-200 overflow-hidden bg-white shadow-sm hover:shadow-md flex flex-col justify-between ${
                  loan.status === 'settled'
                    ? 'border-stone-200 opacity-80'
                    : activeTab === 'lent'
                    ? 'border-amber-200/80 hover:border-amber-400'
                    : 'border-red-200/80 hover:border-red-400'
                }`}
              >
                {/* Card Top Strip */}
                <div
                  className={`px-4 py-2.5 flex items-center justify-between text-xs font-semibold ${
                    loan.status === 'settled'
                      ? 'bg-stone-100 text-stone-600'
                      : activeTab === 'lent'
                      ? 'bg-emerald-50 text-emerald-900 border-b border-emerald-100'
                      : 'bg-red-50 text-red-900 border-b border-red-100'
                  }`}
                >
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold">|| ૧ ||</span>
                    <span className="font-bold truncate max-w-[200px]">
                      {loan.partyName}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {loan.status === 'settled' ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-stone-200 text-stone-700">
                        {t('settled', language)}
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                        {loan.interestType === 'simple' ? t('simpleInterest', language) : t('compoundInterest', language)}
                      </span>
                    )}
                  </div>
                </div>

                {/* Card Body */}
                <div className="p-4 space-y-3 flex-1">
                  {/* Financial Grid */}
                  <div className="grid grid-cols-3 gap-2 text-center p-2.5 rounded-xl bg-stone-50 border border-stone-200/70">
                    <div>
                      <span className="text-[10px] text-stone-500 block">{t('currentPrincipal', language)}</span>
                      <span className="text-sm font-bold text-stone-900 mt-0.5 block">
                        {formatCurrency(calc.currentPrincipal, language)}
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] text-amber-700 block">{t('accruedInterest', language)}</span>
                      <span className="text-sm font-bold text-amber-800 mt-0.5 block">
                        {formatCurrency(calc.currentAccruedInterest, language)}
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] text-stone-500 block">{t('totalOutstanding', language)}</span>
                      <span
                        className={`text-sm font-black mt-0.5 block ${
                          activeTab === 'lent' ? 'text-emerald-700' : 'text-rose-700'
                        }`}
                      >
                        {formatCurrency(calc.totalBalanceRemaining, language)}
                      </span>
                    </div>
                  </div>

                  {/* Terms info */}
                  <div className="text-xs text-stone-600 space-y-1 bg-amber-50/40 p-2 rounded-lg border border-amber-100">
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1 text-stone-500">
                        <Percent className="w-3.5 h-3.5 text-amber-600" />
                        <span>{t('interestRate', language)}:</span>
                      </span>
                      <span className="font-bold text-stone-800">
                        {loan.interestRate}%{' '}
                        {loan.ratePeriod === 'monthly' ? t('monthlyRate', language) : t('yearlyRate', language)}
                        {loan.interestType === 'compound' && ` (${loan.compoundingFrequency})`}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1 text-stone-500">
                        <Calendar className="w-3.5 h-3.5 text-amber-600" />
                        <span>{t('startDate', language)}:</span>
                      </span>
                      <span className="font-medium text-stone-800">
                        {formatDateDisplay(loan.startDate, language)}
                      </span>
                    </div>

                    {loan.repayments && loan.repayments.length > 0 && (
                      <div className="flex items-center justify-between pt-1 border-t border-amber-200/50">
                        <span className="text-stone-500">{t('totalRepaid', language)}:</span>
                        <span className="font-bold text-emerald-700">
                          {formatCurrency(calc.totalRepaid, language)} ({loan.repayments.length} હપ્તા)
                        </span>
                      </div>
                    )}

                    {loan.notes && (
                      <p className="text-[11px] text-stone-500 truncate pt-1 border-t border-amber-200/40">
                        {loan.notes}
                      </p>
                    )}
                  </div>
                </div>

                {/* Card Actions Footer */}
                <div className="px-4 py-2.5 bg-stone-50 border-t border-stone-100 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => handleEditLoan(loan)}
                      className="p-1.5 rounded-lg text-stone-400 hover:text-amber-700 hover:bg-stone-200 transition-colors"
                      title={t('edit', language)}
                    >
                      <Edit className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteLoan(loan.id)}
                      className="p-1.5 rounded-lg text-stone-400 hover:text-rose-600 hover:bg-stone-200 transition-colors"
                      title={t('delete', language)}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {/* Record Repayment Button */}
                    {loan.status === 'active' && (
                      <button
                        type="button"
                        onClick={() => setRepaymentLoan(loan)}
                        className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>{language === 'gu' ? 'જમા નોંધો' : 'Add Repayment'}</span>
                      </button>
                    )}

                    {/* View Detailed Statement & Annual Report */}
                    <button
                      type="button"
                      onClick={() => setDetailLoan(loan)}
                      className="px-3 py-1.5 rounded-lg bg-stone-900 hover:bg-amber-800 text-amber-100 text-xs font-semibold transition-all shadow-sm flex items-center gap-1"
                    >
                      <span>{language === 'gu' ? 'વાર્ષિક અહેવાલ' : 'Annual Report'}</span>
                      <ChevronRight className="w-3.5 h-3.5 text-amber-400" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* New / Edit Loan Modal */}
      <LoanModal
        isOpen={isNewLoanOpen}
        onClose={() => setIsNewLoanOpen(false)}
        editLoan={editingLoan}
        defaultType={activeTab}
      />

      {/* Record Repayment Modal */}
      {repaymentLoan && (
        <LoanRepaymentModal
          isOpen={Boolean(repaymentLoan)}
          onClose={() => setRepaymentLoan(null)}
          loan={repaymentLoan}
        />
      )}

      {/* Detailed Statement & Annual Interest Report Modal */}
      {detailLoan && (
        <LoanDetailStatementModal
          isOpen={Boolean(detailLoan)}
          onClose={() => setDetailLoan(null)}
          loan={detailLoan}
          onRecordRepayment={() => {
            setRepaymentLoan(detailLoan);
          }}
          onSettleLoan={() => {
            handleSettleLoan(detailLoan);
          }}
        />
      )}
    </div>
  );
};
