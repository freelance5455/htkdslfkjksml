import React from 'react';
import { ScoreFloater } from '../types/game';

interface FloatingTextsProps {
  floaters: ScoreFloater[];
}

export const FloatingTexts: React.FC<FloatingTextsProps> = ({ floaters }) => {
  return (
    <div className="fixed inset-0 pointer-events-none z-40 overflow-hidden select-none">
      {floaters.map((f) => (
        <div
          key={f.id}
          style={{
            left: `${f.x}px`,
            top: `${f.y}px`,
            transform: 'translate(-50%, -50%)',
          }}
          className={`absolute flex flex-col items-center justify-center animate-fade-up-and-out ${
            f.isCombo ? 'scale-110' : 'scale-100'
          }`}
        >
          <div
            className={`font-black tracking-wider uppercase drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)] text-center ${
              f.isCombo
                ? 'text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-orange-400 to-rose-400 text-xl md:text-2xl font-["Outfit"] animate-bounce'
                : 'text-white text-lg md:text-xl font-["Outfit"]'
            }`}
            style={{
              textShadow: f.isCombo
                ? '0 0 20px rgba(251, 146, 60, 0.8), 0 0 10px rgba(245, 158, 11, 0.6)'
                : '0 0 12px rgba(56, 189, 248, 0.7)',
            }}
          >
            {f.text}
          </div>
        </div>
      ))}
    </div>
  );
};
