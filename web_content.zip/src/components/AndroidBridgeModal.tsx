import React from 'react';
import { Smartphone, Zap, Radio, Bell, Shield, X, ExternalLink, Code } from 'lucide-react';

interface AndroidBridgeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidBridgeModal: React.FC<AndroidBridgeModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-950/85 backdrop-blur-md">
      <div className="w-full max-w-lg bg-gray-900 border border-cyan-500/40 rounded-2xl p-5 sm:p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-gray-800">
          <div className="flex items-center gap-2">
            <span className="p-1 rounded-lg bg-cyan-950 text-cyan-400">
              <Smartphone className="w-5 h-5" />
            </span>
            <h3 className="font-orbitron text-base font-bold text-slate-100 uppercase tracking-wider">
              Android OS Integration Protocol
            </h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-4 space-y-4 text-xs font-rajdhani text-slate-300 leading-relaxed">
          {/* Section 1: PWA Standalone */}
          <div className="p-3.5 rounded-xl bg-gray-950 border border-gray-800">
            <h4 className="font-orbitron text-xs font-bold text-cyan-300 uppercase flex items-center gap-1.5 mb-1">
              <Zap className="w-4 h-4 text-cyan-400" />
              1. Standalone Home Screen App
            </h4>
            <p>
              Tap <strong>"Install to Android"</strong> in the top header. Jarvis installs as a standalone Android app with no browser URL bars, complete with an Arc Reactor app icon in your app drawer.
            </p>
          </div>

          {/* Section 2: Real Android Hardware APIs */}
          <div className="p-3.5 rounded-xl bg-gray-950 border border-gray-800">
            <h4 className="font-orbitron text-xs font-bold text-cyan-300 uppercase flex items-center gap-1.5 mb-1">
              <Radio className="w-4 h-4 text-emerald-400" />
              2. Real Android Device Hardware
            </h4>
            <ul className="list-disc list-inside space-y-1 text-slate-400">
              <li><strong className="text-slate-200">Flashlight Torch:</strong> Directly toggles the phone's physical LED camera flash via MediaStream Torch API.</li>
              <li><strong className="text-slate-200">Haptics:</strong> Fires distinct vibration waveforms via Android Vibrate API.</li>
              <li><strong className="text-slate-200">Battery Status:</strong> Reads live battery level and charging status in real time.</li>
              <li><strong className="text-slate-200">Encrypted Comms:</strong> Native <code className="text-cyan-300">tel:</code> and <code className="text-cyan-300">sms:</code> intents automatically dial and send messages through your default Android phone app.</li>
            </ul>
          </div>

          {/* Section 3: Lockscreen and Push Alerts */}
          <div className="p-3.5 rounded-xl bg-gray-950 border border-gray-800">
            <h4 className="font-orbitron text-xs font-bold text-cyan-300 uppercase flex items-center gap-1.5 mb-1">
              <Bell className="w-4 h-4 text-amber-400" />
              3. Lockscreen & Background Alerts
            </h4>
            <p>
              Enable Push Notifications in the Schedule tab. When appointments or reminders approach, Jarvis sends notifications to your Android lock screen and speaks audible briefings.
            </p>
          </div>

          {/* Section 4: Advanced Android Tasker / Termux Bridge */}
          <div className="p-3.5 rounded-xl bg-gray-950 border border-gray-800">
            <h4 className="font-orbitron text-xs font-bold text-cyan-300 uppercase flex items-center gap-1.5 mb-1">
              <Code className="w-4 h-4 text-purple-400" />
              4. Advanced Tasker & Termux Bridge (Optional)
            </h4>
            <p>
              To run system shell commands (e.g. adjust Android system volume, kill apps, or run bash scripts), you can send Jarvis intents to <strong>Tasker</strong> or <strong>Termux:API</strong> using Android intent schemes.
            </p>
          </div>
        </div>

        <div className="mt-5 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-gray-950 font-bold font-orbitron text-xs uppercase tracking-wider transition"
          >
            Acknowledge & Close
          </button>
        </div>
      </div>
    </div>
  );
};
