import React, { useState } from 'react';
import { Smartphone, Download, Copy, Check, Terminal, FileCode, X, Layers, Volume2, ShieldCheck, Play, Key } from 'lucide-react';
import { actionEngine } from '../services/actionEngine';
import { voiceEngine, AUDIO_ASSETS } from '../services/voiceService';

interface AndroidBridgeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidBridgeModal: React.FC<AndroidBridgeModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  const [playingAudio, setPlayingAudio] = useState<string | null>(null);
  const [caps] = useState(() => actionEngine.detectCapabilities());

  if (!isOpen) return null;

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(id);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const handlePlayAudio = (type: 'unlock' | 'welcomeBack' | 'alarm') => {
    setPlayingAudio(type);
    let audio: HTMLAudioElement;
    if (type === 'unlock') {
      audio = voiceEngine.playUnlockAudio(() => setPlayingAudio(null));
    } else if (type === 'welcomeBack') {
      audio = voiceEngine.playWelcomeBackAudio(() => setPlayingAudio(null));
    } else {
      audio = voiceEngine.playAlarmAudio(() => setPlayingAudio(null));
    }
  };

  const capacitorCommands = `# 1. In your local machine or terminal, install Capacitor:
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "JARVIS AI Assistant" "com.jarvis.assistant" --web-dir dist

# 2. Add Android native platform:
npx cap add android

# 3. Build web assets:
npm run build

# 4. Sync assets to Android project:
npx cap sync

# 5. Open in Android Studio & build APK:
npx cap open android`;

  const signingKeyCommands = `# 1. Generate Authorized Android Release Keystore (Valid for 25+ Years):
keytool -genkey -v -keystore jarvis-release.keystore -alias jarvis -keyalg RSA -keysize 2048 -validity 10000

# 2. In android/app/build.gradle, configure signingConfigs:
signingConfigs {
    release {
        storeFile file("jarvis-release.keystore")
        storePassword System.getenv("KEYSTORE_PASSWORD") ?: "stark2026"
        keyAlias "jarvis"
        keyPassword System.getenv("KEY_PASSWORD") ?: "stark2026"
    }
}
buildTypes {
    release {
        signingConfig signingConfigs.release
        minifyEnabled true
        proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
    }
}

# 3. Assemble Authorized Signed Release APK:
./gradlew assembleRelease`;

  const androidManifestSnippet = `<!-- Add these to android/app/src/main/AndroidManifest.xml -->
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <!-- Voice & Microphone -->
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />

    <!-- Vision & Camera -->
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <uses-feature android:name="android.hardware.camera.flash" android:required="false" />

    <!-- Calls & Contacts (Local only) -->
    <uses-permission android:name="android.permission.CALL_PHONE" />
    <uses-permission android:name="android.permission.READ_CONTACTS" />

    <!-- Background Wake Word & Exact Alarms -->
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE" />
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />
    <uses-permission android:name="android.permission.USE_EXACT_ALARM" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

    <!-- Floating Siri HUD Overlay -->
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
</manifest>`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-950/80 backdrop-blur-md">
      <div className="relative w-full max-w-xl bg-gray-900 border border-cyan-500/40 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-gray-950/90 border-b border-cyan-500/30">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-cyan-400" />
            <h3 className="font-tech text-base tracking-wide uppercase text-cyan-100 flex items-center gap-2">
              ANDROID APK ARCHITECTURE & RELEASE BRIDGE
              <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300 font-mono-tech">
                REDMI 12 COMPATIBLE
              </span>
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-cyan-400 hover:bg-cyan-500/20 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 p-5 overflow-y-auto space-y-4 text-xs text-cyan-100">
          {/* Project ZIP Backup & Export Banner */}
          <div className="p-3.5 bg-gradient-to-r from-cyan-950/80 via-blue-950/60 to-gray-950/80 rounded-xl border-2 border-cyan-400/50 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg shadow-cyan-950/40">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-400 flex items-center justify-center shrink-0">
                <Download className="w-5 h-5 text-cyan-300 animate-bounce" />
              </div>
              <div>
                <div className="font-tech font-bold text-xs sm:text-sm text-cyan-200 uppercase tracking-wide">
                  Complete JARVIS Project Backup (ZIP)
                </div>
                <div className="text-[10px] sm:text-[11px] text-cyan-300/70 font-mono-tech">
                  All frontend & backend source, audio assets, Android APK scaffold & build guides.
                </div>
              </div>
            </div>
            <a
              href="/Jarvis_Complete_Project.zip"
              download="Jarvis_Complete_Project.zip"
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-gray-950 font-tech font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-md cursor-pointer transition-all active:scale-95 shrink-0"
            >
              <Download className="w-4 h-4" />
              Download ZIP Archive
            </a>
          </div>

          {/* Audio Assets Tester */}
          <div className="p-4 bg-gray-950/90 rounded-xl border border-cyan-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-tech text-xs uppercase text-cyan-200 font-bold flex items-center gap-1.5">
                <Volume2 className="w-4 h-4 text-cyan-400" />
                Verified JARVIS Audio Assets (3 Uploaded Files)
              </span>
              <span className="text-[10px] text-cyan-400/80 font-mono-tech">
                Permanent British Male Voice
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <button
                onClick={() => handlePlayAudio('unlock')}
                disabled={Boolean(playingAudio)}
                className="p-2.5 rounded-lg bg-gray-900 hover:bg-cyan-950 border border-cyan-500/20 hover:border-cyan-400 text-left transition-all cursor-pointer flex flex-col gap-1 active:scale-95 disabled:opacity-50"
              >
                <div className="flex items-center justify-between">
                  <span className="font-tech font-bold text-cyan-300 uppercase text-[11px]">1. Unlock</span>
                  <Play className={`w-3.5 h-3.5 text-cyan-400 ${playingAudio === 'unlock' ? 'animate-pulse' : ''}`} />
                </div>
                <span className="text-[10px] text-cyan-400/70 font-mono-tech">Jarvis unlock.mp3</span>
              </button>

              <button
                onClick={() => handlePlayAudio('welcomeBack')}
                disabled={Boolean(playingAudio)}
                className="p-2.5 rounded-lg bg-gray-900 hover:bg-cyan-950 border border-cyan-500/20 hover:border-cyan-400 text-left transition-all cursor-pointer flex flex-col gap-1 active:scale-95 disabled:opacity-50"
              >
                <div className="flex items-center justify-between">
                  <span className="font-tech font-bold text-cyan-300 uppercase text-[11px]">2. Welcome</span>
                  <Play className={`w-3.5 h-3.5 text-cyan-400 ${playingAudio === 'welcomeBack' ? 'animate-pulse' : ''}`} />
                </div>
                <span className="text-[10px] text-cyan-400/70 font-mono-tech">welcome back Jarvis.mp3</span>
              </button>

              <button
                onClick={() => handlePlayAudio('alarm')}
                disabled={Boolean(playingAudio)}
                className="p-2.5 rounded-lg bg-gray-900 hover:bg-red-950/60 border border-red-500/30 hover:border-red-400 text-left transition-all cursor-pointer flex flex-col gap-1 active:scale-95 disabled:opacity-50"
              >
                <div className="flex items-center justify-between">
                  <span className="font-tech font-bold text-red-300 uppercase text-[11px]">3. Wake Alarm</span>
                  <Play className={`w-3.5 h-3.5 text-red-400 ${playingAudio === 'alarm' ? 'animate-pulse' : ''}`} />
                </div>
                <span className="text-[10px] text-red-400/70 font-mono-tech">Jarvis alarm.mp3</span>
              </button>
            </div>
          </div>

          {/* Runtime Device Capability Status */}
          <div className="p-3.5 bg-gray-950/80 rounded-xl border border-cyan-500/30 space-y-2">
            <div className="font-tech text-xs text-cyan-200 flex items-center justify-between uppercase">
              <span className="flex items-center gap-1.5 font-bold">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                Live Action Telemetry & Capabilities
              </span>
              <span className="font-mono-tech text-[10px] text-cyan-400">
                {caps.isNativeAPK ? 'NATIVE APK RUNTIME' : 'WEB APP SECURE SANDBOX'}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px] font-mono-tech">
              <div className="p-2 rounded bg-gray-900 border border-cyan-500/20">
                <span className="text-cyan-400/70 block">ALARM ENGINE</span>
                <span className="text-emerald-300 font-bold">ACTIVE (IST)</span>
              </div>
              <div className="p-2 rounded bg-gray-900 border border-cyan-500/20">
                <span className="text-cyan-400/70 block">HARDWARE TORCH</span>
                <span className="text-emerald-300 font-bold">{caps.hasTorch ? 'SUPPORTED' : 'WHITE SCREEN'}</span>
              </div>
              <div className="p-2 rounded bg-gray-900 border border-cyan-500/20">
                <span className="text-cyan-400/70 block">BATTERY METER</span>
                <span className="text-emerald-300 font-bold">{caps.hasBatteryTelemetric ? 'CONNECTED' : 'STANDBY'}</span>
              </div>
              <div className="p-2 rounded bg-gray-900 border border-cyan-500/20">
                <span className="text-cyan-400/70 block">REDMI 12 OPT</span>
                <span className="text-cyan-300 font-bold">4GB RAM PROFILE</span>
              </div>
            </div>
          </div>

          {/* Quick APK Conversion Commands */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="font-tech text-cyan-300 uppercase flex items-center gap-1">
                <Terminal className="w-3.5 h-3.5" /> 1. Generate Android APK via Capacitor
              </span>
              <button
                onClick={() => copyToClipboard(capacitorCommands, 'cap')}
                className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
              >
                {copiedSection === 'cap' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                Copy Commands
              </button>
            </div>
            <pre className="p-3 bg-gray-950 rounded-xl border border-cyan-500/20 text-[11px] font-mono-tech text-cyan-200 overflow-x-auto leading-relaxed">
              {capacitorCommands}
            </pre>
          </div>

          {/* Release Signing Key Instructions */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="font-tech text-cyan-300 uppercase flex items-center gap-1">
                <Key className="w-3.5 h-3.5 text-amber-400" /> 2. Authorized Release Signing Key
              </span>
              <button
                onClick={() => copyToClipboard(signingKeyCommands, 'sign')}
                className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
              >
                {copiedSection === 'sign' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                Copy Signing Config
              </button>
            </div>
            <pre className="p-3 bg-gray-950 rounded-xl border border-cyan-500/20 text-[11px] font-mono-tech text-cyan-200 overflow-x-auto leading-relaxed max-h-40">
              {signingKeyCommands}
            </pre>
          </div>

          {/* Android Manifest Permissions */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="font-tech text-cyan-300 uppercase flex items-center gap-1">
                <FileCode className="w-3.5 h-3.5" /> 3. AndroidManifest.xml (Exact Alarm & Foreground)
              </span>
              <button
                onClick={() => copyToClipboard(androidManifestSnippet, 'manifest')}
                className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
              >
                {copiedSection === 'manifest' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                Copy Manifest
              </button>
            </div>
            <pre className="p-3 bg-gray-950 rounded-xl border border-cyan-500/20 text-[11px] font-mono-tech text-cyan-200 overflow-x-auto leading-relaxed max-h-36">
              {androidManifestSnippet}
            </pre>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-gray-950/90 border-t border-cyan-500/20 text-[11px] text-cyan-300/60 text-center">
          The codebase is fully responsive and lightweight for compilation into a native signed Android APK for Harman Sir.
        </div>
      </div>
    </div>
  );
};
