"use client";

import React, { useState } from "react";
import { Check, Copy, Download, RefreshCw, Sparkles } from "lucide-react";
import type { MasterPromptRecord } from "@/types/xray";

interface MasterPromptPanelProps {
  scanId: string;
  domain: string;
  prompts: MasterPromptRecord[];
  onPromptCreated: (prompt: MasterPromptRecord) => void;
}

export default function MasterPromptPanel({
  scanId,
  domain,
  prompts,
  onPromptCreated,
}: MasterPromptPanelProps) {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [copied, setCopied] = useState(false);
  const [instruction, setInstruction] = useState("");
  const [refining, setRefining] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const activePrompt = prompts[selectedIndex] ?? prompts[0] ?? null;

  const handleCopy = async () => {
    if (!activePrompt) return;
    try {
      await navigator.clipboard.writeText(activePrompt.promptText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setError("Clipboard permission denied. Select the text inside the box and press Ctrl/Cmd+C.");
    }
  };

  const handleDownloadTxt = () => {
    if (!activePrompt) return;
    const blob = new Blob([activePrompt.promptText], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${domain}-master-prompt-v${activePrompt.version}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleRefine = async (e: React.FormEvent) => {
    e.preventDefault();
    setRefining(true);
    setError(null);
    try {
      const res = await fetch(`/api/scans/${scanId}/refine-prompt`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instruction: instruction.trim() || undefined }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to regenerate prompt");
      }
      onPromptCreated(data.prompt);
      setSelectedIndex(0);
      setInstruction("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to refine prompt");
    } finally {
      setRefining(false);
    }
  };

  if (!activePrompt) {
    return (
      <div className="rounded-xl border border-zinc-800 bg-surface-900 p-8 text-center text-sm text-zinc-400">
        Master Prompt will appear here once the scan and AI analysis complete.
      </div>
    );
  }

  const lineCount = activePrompt.promptText.split("\n").length;

  return (
    <div className="space-y-4">
      {/* Header & Action Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-zinc-800 bg-surface-900 p-4">
        <div>
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-indigo-400" />
            <h3 className="text-base font-semibold text-zinc-100">
              Master Prompt Generator
            </h3>
            <span className="rounded-md border border-zinc-700 bg-surface-800 px-2 py-0.5 text-xs font-mono text-zinc-300">
              v{activePrompt.version}
            </span>
          </div>
          <p className="mt-1 text-xs text-zinc-400">
            {activePrompt.characterCount.toLocaleString()} characters · {lineCount.toLocaleString()} lines ·
            Engine: {activePrompt.provider} ({activePrompt.model})
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {prompts.length > 1 && (
            <select
              value={selectedIndex}
              onChange={(e) => setSelectedIndex(Number(e.target.value))}
              aria-label="Prompt version"
              className="rounded-lg border border-zinc-700 bg-surface-850 px-3 py-2 text-xs text-zinc-200 focus:border-indigo-500 focus:outline-none"
            >
              {prompts.map((p, idx) => (
                <option key={p.id} value={idx}>
                  Version {p.version} ({p.characterCount.toLocaleString()} chars)
                </option>
              ))}
            </select>
          )}

          <button
            type="button"
            onClick={handleDownloadTxt}
            className="inline-flex items-center gap-2 rounded-lg border border-zinc-700 bg-surface-850 px-3.5 py-2 text-sm font-medium text-zinc-200 transition hover:bg-surface-800"
          >
            <Download className="h-4 w-4" />
            Download TXT
          </button>

          <button
            type="button"
            onClick={handleCopy}
            className="inline-flex items-center gap-2 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-indigo-500"
          >
            {copied ? (
              <>
                <Check className="h-4 w-4" />
                Copied Full Prompt
              </>
            ) : (
              <>
                <Copy className="h-4 w-4" />
                Copy Full Prompt
              </>
            )}
          </button>
        </div>
      </div>

      {/* Refine & Regenerate Form */}
      <form
        onSubmit={handleRefine}
        className="flex flex-col gap-2 rounded-xl border border-zinc-800 bg-surface-900 p-4 sm:flex-row"
      >
        <input
          type="text"
          value={instruction}
          onChange={(e) => setInstruction(e.target.value)}
          placeholder="Optional refinement instruction (e.g., 'Target Next.js + Tailwind + Prisma' or 'Expand mobile responsive specs')..."
          className="flex-1 rounded-lg border border-zinc-700 bg-surface-950 px-3.5 py-2 text-sm text-zinc-100 placeholder-zinc-500 focus:border-indigo-500 focus:outline-none"
        />
        <button
          type="submit"
          disabled={refining}
          className="inline-flex items-center justify-center gap-2 rounded-lg border border-zinc-700 bg-surface-850 px-4 py-2 text-sm font-medium text-zinc-100 transition hover:bg-surface-800 disabled:opacity-50"
        >
          <RefreshCw className={`h-4 w-4 ${refining ? "animate-spin" : ""}`} />
          {refining ? "Regenerating..." : instruction.trim() ? "Refine Prompt" : "Regenerate Prompt"}
        </button>
      </form>

      {error && (
        <div className="rounded-lg border border-rose-500/30 bg-rose-500/10 px-4 py-2.5 text-sm text-rose-300">
          {error}
        </div>
      )}

      {/* Large Scrollable Non-Truncated Prompt Box */}
      <div className="rounded-xl border border-zinc-800 bg-surface-950">
        <div className="flex items-center justify-between border-b border-zinc-800 px-4 py-2.5 text-xs text-zinc-400">
          <span>Complete Non-Truncated Development Prompt</span>
          {activePrompt.refinementInstruction && (
            <span className="truncate max-w-md text-indigo-300">
              Refinement: {activePrompt.refinementInstruction}
            </span>
          )}
        </div>
        <textarea
          readOnly
          value={activePrompt.promptText}
          aria-label="Complete generated master prompt"
          className="h-[540px] w-full resize-y bg-transparent p-4 font-mono text-xs leading-relaxed text-zinc-200 focus:outline-none"
        />
      </div>
    </div>
  );
}
