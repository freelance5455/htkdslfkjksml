import React, { useState } from 'react';
import { verbBabs } from '../data/conjugationData';
import { useLanguage } from '../context/LanguageContext';
import {
  RotateCcw,
  Sparkles,
  Copy,
  Check,
  BookOpen,
  Filter
} from 'lucide-react';

export const ConjugatorView: React.FC = () => {
  const { language, getText, isRtl } = useLanguage();
  const [selectedBabId, setSelectedBabId] = useState<string>(verbBabs[0].id);
  const [selectedTense, setSelectedTense] = useState<'past' | 'present' | 'amr' | 'nahy'>('past');
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [filterGender, setFilterGender] = useState<string>('all');

  const selectedBab = verbBabs.find((b) => b.id === selectedBabId) || verbBabs[0];

  const currentForms = selectedBab.conjugations[selectedTense] || [];

  const filteredForms = currentForms.filter((f) => {
    if (filterGender === 'all') return true;
    if (filterGender === 'masculine') return f.gender === 'masculine';
    if (filterGender === 'feminine') return f.gender === 'feminine';
    if (filterGender === '1st') return f.person === '1st';
    return true;
  });

  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 1500);
  };

  const getTenseLabel = (t: 'past' | 'present' | 'amr' | 'nahy') => {
    switch (t) {
      case 'past':
        return language === 'pashto' ? 'فعل ماضي (تېر شوی)' : language === 'urdu' ? 'فعلِ ماضی معروف' : 'Past Tense (Maadhi)';
      case 'present':
        return language === 'pashto' ? 'فعل مضارع (اوس او راتلونکی)' : language === 'urdu' ? 'فعلِ مضارع معروف' : 'Present Tense (Mudhari\')';
      case 'amr':
        return language === 'pashto' ? 'فعل أمر (حکم کول)' : language === 'urdu' ? 'فعلِ امر حاضر' : 'Imperative (Amr)';
      case 'nahy':
        return language === 'pashto' ? 'فعل نهي (منع کول)' : language === 'urdu' ? 'فعلِ نہی حاضر' : 'Prohibitive (Nahy)';
    }
  };

  return (
    <div className="space-y-6">
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-stone-900 to-amber-950 text-white p-6 sm:p-8 rounded-3xl border border-amber-500/20 shadow-lg relative overflow-hidden">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 mb-3">
            <RotateCcw className="w-3.5 h-3.5" />
            <span>
              {language === 'pashto'
                ? 'د تصریف او گردانونو بشپړ نظام'
                : language === 'urdu'
                ? 'گردانوں اور تصریف کا تفصیلی نظام'
                : 'Interactive Morphological Conjugation Engine'}
            </span>
          </div>

          <h2 className="font-arabic text-3xl sm:text-4xl font-bold text-amber-200 mb-2">
            مَوْلِّدُ تَصْرِيفِ الأَفْعَالِ وَالْجَدَاوِلِ الصَّرْفِيَّةِ
          </h2>

          <p className="text-stone-300 text-sm sm:text-base leading-relaxed">
            {language === 'pashto'
              ? 'هر باب وټاکئ او په ماضی، مضارع، امر او نهی کې د هغې ټولې ۱۴ صیغې له بشپړ اعراب او په پښتو، اردو او انګلیسي ژباړې سره وڅارئ.'
              : language === 'urdu'
              ? 'کوئی بھی باب منتخب کریں اور ماضی، مضارع، امر اور نہی کی تمام ۱۴ گردانیں مکمل حرکات اور پشتو، اردو اور انگریزی ترجمہ کے ساتھ دیکھیں۔'
              : 'Select any classical verb pattern (Bab) and inspect its 14 standard conjugations across tenses with vocalized Arabic, grammatical segha titles, and multilingual translations.'}
          </p>
        </div>
      </div>

      {/* Control Filters */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
        {/* Step 1: Select Bab */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">
            {language === 'pashto' ? '۱. باب وټاکئ:' : language === 'urdu' ? '۱. باب منتخب کریں:' : '1. Select Verb Category (Bab):'}
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
            {verbBabs.map((bab) => {
              const isSelected = selectedBabId === bab.id;
              return (
                <button
                  key={bab.id}
                  onClick={() => setSelectedBabId(bab.id)}
                  className={`p-3 rounded-xl text-center border transition-all ${
                    isSelected
                      ? 'bg-emerald-800 text-white border-emerald-600 shadow-sm'
                      : 'bg-stone-50 text-stone-800 border-stone-200 hover:bg-stone-100 hover:border-stone-300'
                  }`}
                >
                  <span className="font-arabic text-lg font-bold block text-amber-300">
                    {bab.nameArabic}
                  </span>
                  <span className="text-[11px] block mt-0.5 opacity-80 truncate">
                    {getText(bab.title)}
                  </span>
                  <span className="text-[10px] block opacity-60 mt-0.5">
                    {bab.pattern}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Step 2: Select Tense */}
        <div className="pt-2 border-t border-stone-100 flex flex-wrap items-center justify-between gap-4">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">
              {language === 'pashto' ? '۲. زمانه او صیغه وټاکئ:' : language === 'urdu' ? '۲. زمانہ منتخب کریں:' : '2. Select Tense / Aspect:'}
            </label>
            <div className="flex flex-wrap gap-2">
              {(['past', 'present', 'amr', 'nahy'] as const).map((tense) => {
                const isSelected = selectedTense === tense;
                return (
                  <button
                    key={tense}
                    onClick={() => setSelectedTense(tense)}
                    className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                      isSelected
                        ? 'bg-amber-600 text-white shadow-xs'
                        : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                    }`}
                  >
                    {getTenseLabel(tense)}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Gender / Person Filter */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">
              {language === 'pashto' ? 'فلټر:' : language === 'urdu' ? 'فلٹر:' : 'Filter Persons:'}
            </label>
            <div className="flex items-center bg-stone-100 rounded-xl p-1 text-xs">
              <button
                onClick={() => setFilterGender('all')}
                className={`px-2.5 py-1 rounded-lg ${filterGender === 'all' ? 'bg-white font-bold shadow-xs' : 'text-stone-600'}`}
              >
                {language === 'pashto' ? 'ټول' : language === 'urdu' ? 'تمام' : 'All'}
              </button>
              <button
                onClick={() => setFilterGender('masculine')}
                className={`px-2.5 py-1 rounded-lg ${filterGender === 'masculine' ? 'bg-white font-bold shadow-xs' : 'text-stone-600'}`}
              >
                {language === 'pashto' ? 'مذکر' : language === 'urdu' ? 'مذکر' : 'Masc'}
              </button>
              <button
                onClick={() => setFilterGender('feminine')}
                className={`px-2.5 py-1 rounded-lg ${filterGender === 'feminine' ? 'bg-white font-bold shadow-xs' : 'text-stone-600'}`}
              >
                {language === 'pashto' ? 'مؤنث' : language === 'urdu' ? 'مؤنث' : 'Fem'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Selected Bab Info Card */}
      <div className="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 p-4 rounded-2xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <h4 className="font-arabic text-xl font-bold text-emerald-950">
            {selectedBab.nameArabic} ({selectedBab.pattern})
          </h4>
          <p className="text-xs sm:text-sm text-stone-700 mt-0.5">
            <strong>{language === 'pashto' ? 'ځانګړنه: ' : language === 'urdu' ? 'خصوصیت: ' : 'Property: '}</strong>
            {getText(selectedBab.characteristic)}
          </p>
        </div>
        <div className="flex items-center gap-3 text-xs bg-white px-3 py-2 rounded-xl border border-emerald-100 shadow-xs">
          <span><strong>ماضي:</strong> {selectedBab.past3rdMasc}</span>
          <span>•</span>
          <span><strong>مضارع:</strong> {selectedBab.present3rdMasc}</span>
          <span>•</span>
          <span><strong>أمر:</strong> {selectedBab.amr}</span>
        </div>
      </div>

      {/* Conjugation Grid / Table */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredForms.map((form, idx) => (
          <div
            key={idx}
            className="bg-white rounded-2xl border border-stone-200/90 shadow-xs hover:border-amber-400 hover:shadow-md transition-all p-4 relative group"
          >
            {/* Segha Badge & Copy */}
            <div className="flex items-center justify-between mb-2">
              <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-stone-100 text-stone-700">
                {language === 'pashto' ? form.seghaPashto : language === 'urdu' ? form.seghaUrdu : `${form.person} Person (${form.gender})`}
              </span>

              <button
                onClick={() => handleCopy(form.arabic, idx)}
                title="Copy Arabic word"
                className="p-1 rounded-md text-stone-400 hover:text-emerald-700 hover:bg-stone-100 transition-colors"
              >
                {copiedIndex === idx ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            {/* Arabic Word Display */}
            <div className="text-center py-3 bg-stone-50 rounded-xl border border-stone-100 mb-3 group-hover:bg-amber-50/40 transition-colors">
              <span className="font-arabic text-3xl font-bold text-stone-900 tracking-wide">
                {form.arabic}
              </span>
              <span className="block font-arabic text-xs text-stone-400 mt-1">
                {form.seghaArabic}
              </span>
            </div>

            {/* Multilingual Meanings */}
            <div className="space-y-1.5 text-xs">
              <div className="p-1.5 bg-emerald-50/60 rounded-md text-emerald-950 font-medium dir-rtl">
                <span className="font-bold text-emerald-800 text-[10px] block">پښتو:</span>
                <span className="font-pashto">{form.meaningPashto}</span>
              </div>
              <div className="p-1.5 bg-amber-50/60 rounded-md text-amber-950 font-medium dir-rtl">
                <span className="font-bold text-amber-800 text-[10px] block">اردو:</span>
                <span className="font-urdu">{form.meaningUrdu}</span>
              </div>
              <div className="p-1.5 bg-stone-100 rounded-md text-stone-800 font-medium dir-ltr">
                <span className="font-bold text-stone-600 text-[10px] block">English:</span>
                <span className="font-sans">{form.meaningEnglish}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
