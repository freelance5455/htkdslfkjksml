import { Avatar } from "@/components/avatar";
import { Button } from "@/components/ui/button";
import { SAMPLE_CALLER_LINES } from "@/lib/ai/prompts";
import { formatPhone } from "@/lib/emergency";
import { formatDuration } from "@/lib/format";
import { useLisaSession } from "@/lib/speech/use-lisa-session";
import { useAppStore } from "@/lib/store";
import { AudioLines, Mic, MicOff, PhoneOff, Volume2, VolumeX } from "lucide-react";
import { useEffect, useState } from "react";

function statusLabel(status: string, lisaStatus: string): string {
  if (status === "lisa") {
    if (lisaStatus === "listening") return "Listening…";
    if (lisaStatus === "thinking") return "Thinking…";
    if (lisaStatus === "speaking") return "Speaking…";
    return "Lisa is on the line";
  }
  return "On call";
}

export function ActiveCall() {
  const live = useAppStore((s) => s.live);
  const contacts = useAppStore((s) => s.contacts);
  const endCall = useAppStore((s) => s.endCall);
  const takeOver = useAppStore((s) => s.takeOver);
  const toggleMute = useAppStore((s) => s.toggleMute);
  const toggleSpeaker = useAppStore((s) => s.toggleSpeaker);
  const lisaHandleIncoming = useAppStore((s) => s.lisaHandleIncoming);
  const decideLisaAccess = useAppStore((s) => s.decideLisaAccess);
  const session = useLisaSession();
  const [typed, setTyped] = useState("");
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    if (!live) return;
    const tick = () => {
      const start = live.connectedAt ?? live.startedAt;
      setElapsed(Math.max(0, Math.floor((Date.now() - start) / 1000)));
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [live]);

  if (!live || (live.status !== "active" && live.status !== "lisa")) return null;

  const isLisa = live.status === "lisa";
  const contact = contacts.find((c) => c.id === live.contactId);
  const access = decideLisaAccess({
    number: live.number,
    known: live.known,
    policy: contact?.policy,
  });
  const canHandOff = !isLisa && access.allowed && !live.emergency && live.direction === "incoming";
  const label = statusLabel(live.status, live.lisaStatus);

  async function onEnd() {
    if (isLisa) await session.hangUpLisa();
    else endCall();
  }

  return (
    <div className="absolute inset-0 z-50 flex flex-col bg-background px-5 pt-[max(1.25rem,env(safe-area-inset-top))] pb-[max(1.25rem,env(safe-area-inset-bottom))]">
      <p className="text-center text-[0.7rem] font-medium tracking-[0.22em] text-muted-foreground uppercase">
        {isLisa ? "Lisa is handling your call" : "Lisa Call"}
      </p>

      <div className="mt-5 flex flex-col items-center">
        <Avatar name={live.name} size="lg" />
        <h1 className="mt-4 text-2xl font-medium tracking-tight">{live.name}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{formatPhone(live.number)}</p>
        <p className="mt-3 font-mono text-sm tabular-nums text-subtle">{formatDuration(elapsed)}</p>
        <p
          className={
            isLisa && (live.lisaStatus === "thinking" || live.lisaStatus === "listening")
              ? "lisa-shimmer mt-2 text-sm"
              : "mt-2 text-sm text-accent"
          }
        >
          {label}
        </p>
        {live.emergency ? (
          <p className="mt-2 text-xs text-warn">Emergency call — Lisa will not intervene.</p>
        ) : null}
      </div>

      {isLisa ? (
        <div className="mt-5 min-h-0 flex-1 space-y-2 overflow-y-auto rounded-lg bg-card px-3 py-3">
          {live.turns.map((t, i) => (
            <div key={`${t.at}-${i}`} className={t.role === "lisa" ? "pr-6" : "pl-6 text-right"}>
              <p className="text-[0.65rem] tracking-wide text-subtle uppercase">
                {t.role === "lisa" ? "Lisa" : live.name}
              </p>
              <p className="text-sm leading-snug">{t.text}</p>
            </div>
          ))}
          {live.livePartial ? (
            <p className="pl-6 text-right text-sm text-muted-foreground italic">{live.livePartial}</p>
          ) : null}
        </div>
      ) : (
        <div className="mt-8 flex-1">
          <p className="rounded-lg bg-card px-4 py-3 text-sm leading-relaxed text-muted-foreground">
            This is a local call session. Cellular voice audio is not available in the
            browser — mute and speaker are on-device controls only.
          </p>
        </div>
      )}

      {isLisa ? (
        <div className="mt-3 space-y-2">
          {live.turns.filter((t) => t.role === "caller").length === 0 ? (
            <div className="flex gap-2 overflow-x-auto pb-1">
              {SAMPLE_CALLER_LINES.slice(0, 3).map((line) => (
                <button
                  key={line}
                  type="button"
                  disabled={session.busy}
                  onClick={() => void session.submitCallerText(line)}
                  className="shrink-0 rounded-full border border-border px-3 py-2 text-left text-xs text-muted-foreground"
                >
                  {line}
                </button>
              ))}
            </div>
          ) : null}
          <form
            className="flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              const v = typed.trim();
              if (!v) return;
              setTyped("");
              void session.submitCallerText(v);
            }}
          >
            <input
              value={typed}
              onChange={(e) => setTyped(e.target.value)}
              placeholder={session.micSupported ? "Speak, or type as the caller" : "Type as the caller"}
              className="h-11 flex-1 rounded-md border border-border bg-muted px-3 text-sm outline-none placeholder:text-subtle focus:ring-2 focus:ring-ring/50"
            />
            <Button type="submit" disabled={session.busy || !typed.trim()} size="md">
              Send
            </Button>
          </form>
          {session.micError ? <p className="text-xs text-warn">{session.micError}</p> : null}
        </div>
      ) : null}

      <div className="mt-4 flex items-center justify-center gap-4">
        <button
          type="button"
          onClick={toggleMute}
          className="flex size-14 flex-col items-center justify-center rounded-full bg-muted text-foreground"
          aria-label={live.muted ? "Unmute" : "Mute"}
        >
          {live.muted ? <MicOff className="size-5" /> : <Mic className="size-5" />}
        </button>
        <button
          type="button"
          onClick={toggleSpeaker}
          className="flex size-14 flex-col items-center justify-center rounded-full bg-muted text-foreground"
          aria-label={live.speaker ? "Speaker off" : "Speaker on"}
        >
          {live.speaker ? <Volume2 className="size-5" /> : <VolumeX className="size-5" />}
        </button>
        {isLisa ? (
          <Button variant="muted" className="h-14 rounded-full px-5" onClick={takeOver}>
            Take Over
          </Button>
        ) : canHandOff ? (
          <Button variant="primary" className="h-14 rounded-full px-5" onClick={lisaHandleIncoming}>
            <AudioLines className="size-4" />
            Lisa
          </Button>
        ) : null}
        <Button variant="danger" size="icon" className="size-16" onClick={() => void onEnd()} aria-label="End call">
          <PhoneOff className="size-7" />
        </Button>
      </div>
    </div>
  );
}
