import React from 'react';
import { RotateCcw, Sparkles } from 'lucide-react';

interface CleanMemoryModalProps {
  isOpen: boolean;
  onStartNewConversation: () => void;
}

export const CleanMemoryModal: React.FC<CleanMemoryModalProps> = ({
  isOpen,
  onStartNewConversation,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/80 backdrop-blur-md select-none animate-fade-in">
      <div className="w-full max-w-sm p-6 rounded-3xl glass-panel border border-purple-500/30 text-center flex flex-col items-center shadow-2xl">
        {/* Glowing Reset Icon (Screen 8) */}
        <div className="relative my-4 flex items-center justify-center">
          <div className="absolute w-20 h-20 rounded-full bg-gradient-to-r from-purple-500 to-cyan-400 blur-xl opacity-50 animate-pulse" />
          <div className="relative p-4 rounded-full bg-[#101426] border border-cyan-400/40 text-cyan-300 shadow-lg">
            <RotateCcw className="w-10 h-10 animate-spin-slow text-cyan-300" />
          </div>
        </div>

        {/* Title */}
        <h3 className="text-xl font-bold text-white mt-2 tracking-wide">
          Memory Cleared!
        </h3>

        {/* Message */}
        <p className="text-xs text-slate-300 mt-2 leading-relaxed max-w-[260px]">
          I've forgotten everything from this conversation. Let's start completely fresh!
        </p>

        {/* Safety badge indicating API key is kept */}
        <div className="mt-4 px-3 py-1.5 rounded-full bg-purple-950/40 border border-purple-800/40 text-[10px] text-purple-300 font-medium">
          ✓ Your API Key & Theme settings are preserved
        </div>

        {/* "Start New Conversation" button */}
        <button
          onClick={onStartNewConversation}
          className="w-full mt-6 py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 via-pink-600 to-cyan-500 text-white font-bold text-xs tracking-wider shadow-lg shadow-purple-500/30 hover:scale-[1.02] active:scale-95 transition"
        >
          Start New Conversation
        </button>
      </div>
    </div>
  );
};
