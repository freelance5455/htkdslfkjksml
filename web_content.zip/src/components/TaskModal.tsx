import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Task, ProjectPriority, TaskStatus } from '../types';

interface TaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  taskToEdit?: Task | null;
  defaultProjectId?: string;
}

export const TaskModal: React.FC<TaskModalProps> = ({
  isOpen,
  onClose,
  taskToEdit,
  defaultProjectId
}) => {
  const { projects, users, createTask, updateTask, currentDateStr } = useApp();

  const [projectId, setProjectId] = useState(
    taskToEdit ? taskToEdit.projectId : (defaultProjectId || projects[0]?.id || '')
  );
  const [title, setTitle] = useState(taskToEdit ? taskToEdit.title : '');
  const [description, setDescription] = useState(taskToEdit ? taskToEdit.description : '');
  const [assignedToEmployeeId, setAssignedToEmployeeId] = useState(
    taskToEdit ? taskToEdit.assignedToEmployeeId : (users.find(u => u.role === 'Employee')?.id || '')
  );
  const [deadline, setDeadline] = useState(
    taskToEdit ? taskToEdit.deadline : '2026-10-25'
  );
  const [priority, setPriority] = useState<ProjectPriority>(
    taskToEdit ? taskToEdit.priority : 'High'
  );
  const [status, setStatus] = useState<TaskStatus>(
    taskToEdit ? taskToEdit.status : 'To Do'
  );
  const [remarks, setRemarks] = useState(taskToEdit ? taskToEdit.remarks : '');
  const [visibleToClient, setVisibleToClient] = useState(
    taskToEdit ? taskToEdit.visibleToClient : true
  );

  if (!isOpen) return null;

  const employees = users.filter(u => u.role === 'Employee' || u.role === 'Admin');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const proj = projects.find(p => p.id === projectId);
    const assignee = users.find(u => u.id === assignedToEmployeeId);

    if (!proj || !assignee || !title) return;

    if (taskToEdit) {
      updateTask(taskToEdit.id, {
        projectId,
        projectReference: proj.reference,
        title,
        description,
        assignedToEmployeeId,
        assignedToName: assignee.name,
        deadline,
        priority,
        status,
        remarks,
        visibleToClient
      });
    } else {
      createTask({
        projectId,
        projectReference: proj.reference,
        title,
        description,
        assignedToEmployeeId,
        assignedToName: assignee.name,
        deadline,
        priority,
        remarks,
        visibleToClient
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden flex flex-col max-h-[95vh] sm:max-h-[90vh]">
        <div className="px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
          <div>
            <h3 className="text-sm sm:text-base font-bold text-slate-900">
              {taskToEdit ? 'Edit Task Details' : 'Assign New Engineering Task'}
            </h3>
            <p className="text-[11px] text-slate-500">Configure deliverables, deadline & client visibility</p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center cursor-pointer text-sm font-semibold shrink-0"
            aria-label="Close modal"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 sm:p-6 overflow-y-auto space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Target Project *</label>
            <select
              value={projectId}
              onChange={(e) => setProjectId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer"
            >
              {projects.map(p => (
                <option key={p.id} value={p.id}>
                  {p.reference} — {p.name} ({p.clientCompanyName})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Task Title *</label>
            <input
              type="text"
              required
              placeholder="e.g. Conduct Hydrostatic Pressure Test on Wet Riser Line"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:border-red-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Assigned Engineer *</label>
              <select
                value={assignedToEmployeeId}
                onChange={(e) => setAssignedToEmployeeId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer"
              >
                {employees.map(e => (
                  <option key={e.id} value={e.id}>{e.name} ({e.designation.split(' ')[0]})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Deadline Date *</label>
              <input
                type="date"
                required
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Priority</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer"
              >
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
                <option value="Critical">Critical</option>
              </select>
            </div>

            {taskToEdit && (
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Status</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer"
                >
                  <option value="To Do">To Do</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Completed">Completed</option>
                  <option value="Overdue">Overdue</option>
                </select>
              </div>
            )}
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Description & Inspection Guidelines</label>
            <textarea
              rows={2}
              placeholder="Specific technical parameters, drawings to reference, safety precautions..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Site Remarks / Progress Notes</label>
            <input
              type="text"
              placeholder="Latest status remarks from site..."
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
            />
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between">
            <div>
              <p className="font-semibold text-slate-900">Client Portal Visibility</p>
              <p className="text-[11px] text-slate-500">Allow client to view task milestone in their portal</p>
            </div>
            <input
              type="checkbox"
              checked={visibleToClient}
              onChange={(e) => setVisibleToClient(e.target.checked)}
              className="w-4 h-4 text-red-600 rounded cursor-pointer"
            />
          </div>

          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-600 hover:text-slate-900 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold cursor-pointer shadow-xs transition-colors"
            >
              {taskToEdit ? 'Save Task' : 'Assign Task'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
