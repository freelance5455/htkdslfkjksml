import React from 'react';
import { Loader2, Search, FileSearch, Sparkles, CheckCircle2 } from 'lucide-react';

interface AnalysisStageProps {
  progress: {
    percentage: number;
    currentFile: string;
    filesScanned: number;
    totalFiles: number;
    matchesFound: number;
  };
  packageName: string;
}

export const AnalysisStage: React.FC<AnalysisStageProps> = ({ progress, packageName }) => {
  return (
    <div className="flex flex-col items-center justify-center w-full max-w-xl mx-auto py-8">
      {/* Animated Radar Scanning Graphic */}
      <div className="relative w-28 h-28 mb-6 flex items-center justify-center">
        <div className="absolute inset-0 rounded-full border-2 border-emerald-500/20 animate-ping opacity-75" />
        <div className="absolute inset-2 rounded-full border border-teal-500/30 animate-pulse" />
        <div className="w-20 h-20 rounded-full bg-slate-900 border border-emerald-500/50 flex items-center justify-center shadow-lg shadow-emerald-500/20">
          <Search className="w-8 h-8 text-emerald-400 animate-bounce" />
        </div>
      </div>

      <h2 className="text-xl sm:text-2xl font-extrabold text-white text-center tracking-tight">
        Performing Full Package Analysis
      </h2>
      <p className="text-sm text-slate-400 text-center mt-1.5 max-w-md">
        Examining all files contained within the package to identify specific files and locations where game resource values—such as &quot;coins,&quot; &quot;gems,&quot; or &quot;diamonds&quot;—are defined.
      </p>

      {/* Progress Bar Card */}
      <div className="w-full mt-6 p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
        <div className="flex items-center justify-between text-xs mb-2">
          <span className="font-semibold text-slate-300 flex items-center gap-1.5">
            <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-400" />
            Analyzing Package Structure...
          </span>
          <span className="font-mono text-emerald-400 font-bold">{progress.percentage}%</span>
        </div>

        {/* Progress track */}
        <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden p-0.5 border border-slate-700/60">
          <div
            className="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-400 rounded-full transition-all duration-200"
            style={{ width: `${Math.max(5, progress.percentage)}%` }}
          />
        </div>

        {/* Detailed stats */}
        <div className="grid grid-cols-3 gap-2 mt-4 pt-4 border-t border-slate-800/80 text-center">
          <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/60">
            <span className="block text-[10px] text-slate-400 uppercase font-semibold">Scanned Files</span>
            <span className="text-sm font-bold text-white font-mono">
              {progress.filesScanned} / {progress.totalFiles || '...'}
            </span>
          </div>

          <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/60">
            <span className="block text-[10px] text-slate-400 uppercase font-semibold">Matches Found</span>
            <span className="text-sm font-bold text-emerald-400 font-mono flex items-center justify-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              {progress.matchesFound}
            </span>
          </div>

          <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/60">
            <span className="block text-[10px] text-slate-400 uppercase font-semibold">Package</span>
            <span className="text-xs font-semibold text-slate-300 truncate block">
              {packageName}
            </span>
          </div>
        </div>

        {/* Live File Stream */}
        <div className="mt-4 p-2.5 rounded-lg bg-slate-950/80 border border-slate-800/80 font-mono text-[11px] text-slate-400 flex items-center gap-2 overflow-hidden">
          <FileSearch className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span className="truncate">
            Scanning: <span className="text-slate-200">{progress.currentFile || 'Loading assets...'}</span>
          </span>
        </div>
      </div>

      <div className="mt-6 flex items-center gap-2 text-xs text-slate-400">
        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
        <span>Scanning XML resources, JSON balance tables, Lua scripts &amp; INI configs</span>
      </div>
    </div>
  );
};
