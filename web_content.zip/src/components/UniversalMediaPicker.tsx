import React, { useState, useRef, useEffect } from "react";
import {
  UploadCloud,
  Image as ImageIcon,
  FileVideo,
  Mic,
  Folder,
  Camera,
  X,
  Play,
  Pause,
  FileText,
  AlertCircle,
  CheckCircle2,
  Loader2,
  StopCircle,
} from "lucide-react";
import { SelectedMediaFile } from "../types";
import { uploadMedia } from "../lib/api";

interface UniversalMediaPickerProps {
  label?: string;
  allowedTypes: ("image" | "audio" | "video" | "document")[];
  selectedFile: SelectedMediaFile | null;
  onFileSelect: (media: SelectedMediaFile | null) => void;
  onImageSelected?: (file: File, url: string) => void;
  onAudioSelected?: (file: File, url: string) => void;
  onVideoSelected?: (file: File, url: string) => void;
  onDocumentSelected?: (file: File, url: string) => void;
  maxSizeBytes?: number;
}

export const UniversalMediaPicker: React.FC<UniversalMediaPickerProps> = ({
  label = "Upload from Phone",
  allowedTypes,
  selectedFile,
  onFileSelect,
  onImageSelected,
  onAudioSelected,
  onVideoSelected,
  onDocumentSelected,
  maxSizeBytes = 50 * 1024 * 1024,
}) => {
  const [sheetOpen, setSheetOpen] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<"idle" | "uploading" | "processing" | "completed" | "failed">("idle");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Audio recording states
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);

  // Audio/Video player state in preview
  const [isPlayingPreview, setIsPlayingPreview] = useState(false);
  const previewAudioRef = useRef<HTMLAudioElement | null>(null);

  // File input refs
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const galleryInputRef = useRef<HTMLInputElement | null>(null);
  const cameraInputRef = useRef<HTMLInputElement | null>(null);

  // Clean up audio on unmount
  useEffect(() => {
    return () => {
      if (previewAudioRef.current) {
        previewAudioRef.current.pause();
      }
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  const handleProcessSelectedFile = async (file: File, explicitType?: "image" | "audio" | "video" | "document") => {
    setSheetOpen(false);
    setErrorMessage(null);

    // Validate size
    if (file.size > maxSizeBytes) {
      setErrorMessage(`File is too large (${(file.size / (1024 * 1024)).toFixed(1)}MB). Limit is ${(maxSizeBytes / (1024 * 1024)).toFixed(0)}MB.`);
      setUploadStatus("failed");
      return;
    }

    // Determine type
    let inferredType: "image" | "audio" | "video" | "document" = "document";
    if (file.type.startsWith("image/")) inferredType = "image";
    else if (file.type.startsWith("audio/")) inferredType = "audio";
    else if (file.type.startsWith("video/")) inferredType = "video";
    else inferredType = "document";

    const mediaType = explicitType || inferredType;

    if (!allowedTypes.includes(mediaType)) {
      setErrorMessage(`Unsupported format: ${file.type || "file"}. Expected ${allowedTypes.join(", ")}.`);
      setUploadStatus("failed");
      return;
    }

    setUploadStatus("uploading");
    const localUrl = URL.createObjectURL(file);

    try {
      // Try uploading to backend endpoint
      let serverResponse: any = null;
      if (mediaType === "image" || mediaType === "audio" || mediaType === "video") {
        setUploadStatus("processing");
        serverResponse = await uploadMedia(mediaType, file).catch((err) => {
          console.warn("Backend upload note:", err);
          return null;
        });
      }

      const mediaObj: SelectedMediaFile = {
        file,
        fileId: serverResponse?.fileId,
        url: serverResponse?.url || localUrl,
        name: file.name,
        size: file.size,
        type: mediaType,
        mimeType: file.type || "application/octet-stream",
        thumbnailUrl: mediaType === "image" ? localUrl : undefined,
      };

      onFileSelect(mediaObj);
      if (mediaType === "image" && onImageSelected) onImageSelected(file, mediaObj.url);
      if (mediaType === "audio" && onAudioSelected) onAudioSelected(file, mediaObj.url);
      if (mediaType === "video" && onVideoSelected) onVideoSelected(file, mediaObj.url);
      if (mediaType === "document" && onDocumentSelected) onDocumentSelected(file, mediaObj.url);

      setUploadStatus("completed");
    } catch (err: any) {
      setUploadStatus("failed");
      setErrorMessage(err.message || "Upload failed. Please try again.");
    }
  };

  // Live Audio Recording logic
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: "audio/webm" });
        const recordedFile = new File([audioBlob], `recording-${Date.now()}.webm`, { type: "audio/webm" });
        stream.getTracks().forEach((track) => track.stop());
        handleProcessSelectedFile(recordedFile, "audio");
      };

      mediaRecorder.start(250);
      setIsRecording(true);
      setRecordingSeconds(0);

      timerRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      setErrorMessage("Microphone access denied or unavailable: " + (err.message || ""));
      setSheetOpen(false);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerRef.current) clearInterval(timerRef.current);
    }
  };

  const handleRemove = () => {
    if (previewAudioRef.current) previewAudioRef.current.pause();
    setIsPlayingPreview(false);
    onFileSelect(null);
    setUploadStatus("idle");
    setErrorMessage(null);
  };

  const toggleAudioPreview = () => {
    if (!previewAudioRef.current && selectedFile?.url) {
      previewAudioRef.current = new Audio(selectedFile.url);
      previewAudioRef.current.onended = () => setIsPlayingPreview(false);
    }

    if (previewAudioRef.current) {
      if (isPlayingPreview) {
        previewAudioRef.current.pause();
        setIsPlayingPreview(false);
      } else {
        previewAudioRef.current.play().then(() => setIsPlayingPreview(true)).catch(() => {});
      }
    }
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
  };

  return (
    <div className="w-full space-y-2.5">
      {/* Hidden inputs for native picker handling */}
      <input
        type="file"
        ref={fileInputRef}
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleProcessSelectedFile(file);
          e.target.value = "";
        }}
      />
      <input
        type="file"
        ref={galleryInputRef}
        accept={allowedTypes.includes("video") ? "image/*,video/*" : "image/*"}
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleProcessSelectedFile(file);
          e.target.value = "";
        }}
      />
      <input
        type="file"
        ref={cameraInputRef}
        accept={allowedTypes.includes("video") ? "image/*,video/*" : "image/*"}
        capture="environment"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleProcessSelectedFile(file);
          e.target.value = "";
        }}
      />

      {/* Main Upload Trigger Button (when no file is selected) */}
      {!selectedFile ? (
        <div
          id="universal-upload-dropzone"
          onClick={() => setSheetOpen(true)}
          className="border-2 border-dashed border-slate-700 hover:border-blue-500/80 bg-slate-900/60 hover:bg-slate-800/40 rounded-2xl p-5 text-center transition-all cursor-pointer group flex flex-col items-center justify-center space-y-2 select-none active:scale-[0.99]"
        >
          <div className="w-12 h-12 rounded-xl bg-blue-500/10 group-hover:bg-blue-500/20 text-blue-400 flex items-center justify-center transition-colors">
            <UploadCloud className="w-6 h-6" />
          </div>
          <div>
            <span className="text-sm font-semibold text-white group-hover:text-blue-400 transition-colors">
              {label}
            </span>
            <p className="text-xs text-slate-400 mt-0.5">
              {allowedTypes.map((t) => t.toUpperCase()).join(" • ")}
            </p>
          </div>
          <div className="flex items-center gap-2 pt-1">
            <span className="text-[11px] px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
              Gallery • Files • Camera
            </span>
          </div>
        </div>
      ) : (
        /* Selected Media Preview Card (Section 7) */
        <div
          id="uploaded-media-preview-card"
          className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3.5 flex items-center justify-between shadow-lg relative overflow-hidden"
        >
          {/* Status bar */}
          <div className="flex items-center space-x-3 overflow-hidden flex-1 mr-2">
            {/* Visual Thumbnail / Icon */}
            {selectedFile.type === "image" && (
              <div className="w-14 h-14 rounded-xl overflow-hidden bg-slate-800 flex-shrink-0 border border-slate-700/80">
                <img
                  src={selectedFile.url}
                  alt={selectedFile.name}
                  className="w-full h-full object-cover"
                />
              </div>
            )}

            {selectedFile.type === "audio" && (
              <button
                type="button"
                onClick={toggleAudioPreview}
                className="w-12 h-12 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center flex-shrink-0 hover:bg-indigo-500/30 transition-colors border border-indigo-500/30"
              >
                {isPlayingPreview ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
              </button>
            )}

            {selectedFile.type === "video" && (
              <div className="w-14 h-14 rounded-xl overflow-hidden bg-slate-800 flex-shrink-0 border border-slate-700/80 relative flex items-center justify-center">
                <video src={selectedFile.url} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                  <FileVideo className="w-5 h-5 text-white" />
                </div>
              </div>
            )}

            {selectedFile.type === "document" && (
              <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center flex-shrink-0 border border-emerald-500/30">
                <FileText className="w-5 h-5" />
              </div>
            )}

            {/* File Info */}
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-medium text-slate-100 truncate">{selectedFile.name}</h4>
              <div className="flex items-center space-x-2 text-xs text-slate-400 mt-0.5">
                <span>{formatBytes(selectedFile.size)}</span>
                <span>•</span>
                <span className="uppercase text-[10px] tracking-wider text-slate-400">
                  {selectedFile.type}
                </span>
                {uploadStatus === "completed" && (
                  <span className="text-emerald-400 text-[10px] flex items-center gap-0.5 font-medium">
                    <CheckCircle2 className="w-3 h-3" /> Ready
                  </span>
                )}
                {uploadStatus === "uploading" && (
                  <span className="text-blue-400 text-[10px] flex items-center gap-1 font-medium">
                    <Loader2 className="w-3 h-3 animate-spin" /> Uploading...
                  </span>
                )}
                {uploadStatus === "processing" && (
                  <span className="text-amber-400 text-[10px] flex items-center gap-1 font-medium">
                    <Loader2 className="w-3 h-3 animate-spin" /> Processing...
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Remove Button */}
          <button
            type="button"
            onClick={handleRemove}
            className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors flex-shrink-0"
            title="Remove file"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      )}

      {/* Error display */}
      {errorMessage && (
        <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Bottom Sheet Picker Modal (Sections 4 & 33) */}
      {sheetOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end justify-center animate-fade-in">
          <div className="w-full max-w-md bg-slate-900 border-t border-slate-800 rounded-t-3xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div>
                <h3 className="text-base font-semibold text-white">Choose Source</h3>
                <p className="text-xs text-slate-400">Select how you want to upload media</p>
              </div>
              <button
                onClick={() => setSheetOpen(false)}
                className="p-1.5 rounded-full text-slate-400 hover:text-white bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Recording Audio active banner */}
            {isRecording ? (
              <div className="p-4 rounded-2xl bg-rose-950/40 border border-rose-600/40 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 rounded-full bg-rose-500 animate-ping" />
                  <div>
                    <span className="text-sm font-semibold text-rose-300">Recording Audio...</span>
                    <p className="text-xs text-rose-400 font-mono">
                      {Math.floor(recordingSeconds / 60)}:
                      {String(recordingSeconds % 60).padStart(2, "0")}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={stopRecording}
                  className="px-3 py-1.5 rounded-xl bg-rose-600 text-white text-xs font-semibold flex items-center gap-1.5 shadow-lg shadow-rose-600/20 active:scale-95"
                >
                  <StopCircle className="w-4 h-4" /> Stop & Use
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                {/* 1. Gallery / Photos */}
                {(allowedTypes.includes("image") || allowedTypes.includes("video")) && (
                  <button
                    type="button"
                    onClick={() => galleryInputRef.current?.click()}
                    className="p-4 rounded-2xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 flex flex-col items-center justify-center space-y-2 text-slate-200 transition-all active:scale-95 group"
                  >
                    <div className="w-11 h-11 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center group-hover:bg-blue-500/20 transition-colors">
                      <ImageIcon className="w-6 h-6" />
                    </div>
                    <span className="text-xs font-semibold">Gallery / Photos</span>
                  </button>
                )}

                {/* 2. Files */}
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="p-4 rounded-2xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 flex flex-col items-center justify-center space-y-2 text-slate-200 transition-all active:scale-95 group"
                >
                  <div className="w-11 h-11 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center group-hover:bg-amber-500/20 transition-colors">
                    <Folder className="w-6 h-6" />
                  </div>
                  <span className="text-xs font-semibold">Files / Storage</span>
                </button>

                {/* 3. Camera */}
                {(allowedTypes.includes("image") || allowedTypes.includes("video")) && (
                  <button
                    type="button"
                    onClick={() => cameraInputRef.current?.click()}
                    className="p-4 rounded-2xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 flex flex-col items-center justify-center space-y-2 text-slate-200 transition-all active:scale-95 group"
                  >
                    <div className="w-11 h-11 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center group-hover:bg-emerald-500/20 transition-colors">
                      <Camera className="w-6 h-6" />
                    </div>
                    <span className="text-xs font-semibold">Camera</span>
                  </button>
                )}

                {/* 4. Record Audio */}
                {allowedTypes.includes("audio") && (
                  <button
                    type="button"
                    onClick={startRecording}
                    className="p-4 rounded-2xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 flex flex-col items-center justify-center space-y-2 text-slate-200 transition-all active:scale-95 group"
                  >
                    <div className="w-11 h-11 rounded-xl bg-rose-500/10 text-rose-400 flex items-center justify-center group-hover:bg-rose-500/20 transition-colors">
                      <Mic className="w-6 h-6" />
                    </div>
                    <span className="text-xs font-semibold">Record Audio</span>
                  </button>
                )}
              </div>
            )}

            <button
              type="button"
              onClick={() => setSheetOpen(false)}
              className="w-full py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700 transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
