import React from 'react';
import {
  Wrench,
  Radio,
  Users,
  Plane,
  Clapperboard,
  Cpu,
  CheckCircle,
  Sparkles,
  ArrowUpRight,
} from 'lucide-react';
import { StationUpgrade } from '../types/game';
import { soundFx } from '../utils/audio';

interface StationUpgradesProps {
  upgrades: StationUpgrade[];
  cash: number;
  onBuyUpgrade: (upgradeId: string) => void;
}

export const StationUpgrades: React.FC<StationUpgradesProps> = ({
  upgrades,
  cash,
  onBuyUpgrade,
}) => {
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'antena':
        return <Radio className="w-5 h-5 text-amber-400" />;
      case 'estudio':
        return <Clapperboard className="w-5 h-5 text-rose-400" />;
      case 'jornalismo':
        return <Plane className="w-5 h-5 text-blue-400" />;
      case 'tecnologia':
        return <Cpu className="w-5 h-5 text-emerald-400" />;
      default:
        return <Users className="w-5 h-5 text-amber-400" />;
    }
  };

  return (
    <div className="w-full h-full flex flex-col gap-4 select-none overflow-y-auto pr-1">
      {/* Top Banner */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-xl p-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Wrench className="w-5 h-5 text-amber-400" />
            Infraestrutura, Antenas & Tecnologia
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Amplie o alcance do sinal, modernize os estúdios, construa cidades cenográficas e adquira aeronaves de notícias para disparar na audiência.
          </p>
        </div>

        <div className="text-right">
          <span className="text-[10px] font-mono text-slate-400 block uppercase">
            CAIXA DISPONÍVEL
          </span>
          <span className="text-base font-mono font-bold text-amber-400">
            R$ {cash.toLocaleString('pt-BR')}
          </span>
        </div>
      </div>

      {/* Upgrades Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {upgrades.map((upgrade) => {
          const isMaxLevel = upgrade.level >= upgrade.maxLevel;
          const canAfford = cash >= upgrade.cost && !isMaxLevel;

          return (
            <div
              key={upgrade.id}
              className={`rounded-2xl border p-5 flex flex-col justify-between transition-all shadow-lg ${
                isMaxLevel
                  ? 'bg-slate-900/60 border-emerald-500/30'
                  : 'bg-slate-900/90 border-slate-800'
              }`}
            >
              <div>
                {/* Header */}
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center">
                      {getCategoryIcon(upgrade.category)}
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white">{upgrade.name}</h3>
                      <span className="text-[10px] font-mono text-slate-400 uppercase">
                        Categoria: {upgrade.category}
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xs font-mono font-bold text-amber-400">
                      Nível {upgrade.level} / {upgrade.maxLevel}
                    </span>
                  </div>
                </div>

                {/* Level Progress Pip Bars */}
                <div className="flex items-center gap-1.5 mt-3">
                  {Array.from({ length: upgrade.maxLevel }).map((_, idx) => (
                    <div
                      key={idx}
                      className={`h-2 flex-1 rounded-full transition-all ${
                        idx < upgrade.level
                          ? 'bg-amber-400'
                          : 'bg-slate-800'
                      }`}
                    />
                  ))}
                </div>

                <p className="text-xs text-slate-300 mt-3 leading-relaxed">
                  {upgrade.description}
                </p>

                {/* Bonus effect text */}
                <div className="mt-3 p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-xs font-semibold text-amber-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>{upgrade.bonusText}</span>
                </div>
              </div>

              {/* Action Button */}
              <div className="mt-5 pt-3 border-t border-slate-800">
                {isMaxLevel ? (
                  <div className="w-full py-2 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-emerald-400 font-bold text-xs uppercase flex items-center justify-center gap-1.5">
                    <CheckCircle className="w-4 h-4" />
                    <span>Nível Máximo Atingido</span>
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      if (canAfford) {
                        soundFx.playVictory();
                        onBuyUpgrade(upgrade.id);
                      }
                    }}
                    disabled={!canAfford}
                    className={`w-full min-h-[46px] py-2.5 px-3 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-between transition-all cursor-pointer active:scale-95 ${
                      canAfford
                        ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md shadow-amber-950/50'
                        : 'bg-slate-800 text-slate-500 cursor-not-allowed opacity-75'
                    }`}
                  >
                    <span className="flex items-center gap-1">
                      <ArrowUpRight className="w-4 h-4" />
                      {canAfford ? 'Evoluir Infraestrutura' : 'Caixa Insuficiente'}
                    </span>
                    <span className="font-mono">
                      R$ {upgrade.cost.toLocaleString('pt-BR')}
                    </span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
