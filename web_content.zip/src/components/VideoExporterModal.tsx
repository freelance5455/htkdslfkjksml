import React, { useState, useRef, useEffect } from 'react';
import { X, Video, Download, Loader2, CheckCircle2, Square, Clock, Infinity as InfinityIcon, Sparkles } from 'lucide-react';
import { SlideItem, SlideshowSettings } from '../types';

interface VideoExporterModalProps {
  isOpen: boolean;
  onClose: () => void;
  slides: SlideItem[];
  settings: SlideshowSettings;
}

export const VideoExporterModal: React.FC<VideoExporterModalProps> = ({
  isOpen,
  onClose,
  slides,
  settings,
}) => {
  // Compute exact full slideshow duration (all slides played at user's configured interval)
  const fullSlideshowDuration = Math.max(5, Math.round(slides.length * (settings.interval || 5)));

  const [isRecording, setIsRecording] = useState(false);
  const [recordProgress, setRecordProgress] = useState(0);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [durationSeconds, setDurationSeconds] = useState(fullSlideshowDuration);
  const [isUnlimited, setIsUnlimited] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [currentSlideDisplayIndex, setCurrentSlideDisplayIndex] = useState(1);
  const [currentLoopDisplay, setCurrentLoopDisplay] = useState(1);
  const [frameRate, setFrameRate] = useState<number>(30); // 30 FPS default for rock-solid stutter-free recording
  const [outputExt, setOutputExt] = useState<'mp4' | 'webm'>('webm');

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Sync default duration when modal opens or slides/settings change
  useEffect(() => {
    if (isOpen) {
      setDurationSeconds(fullSlideshowDuration);
      setIsUnlimited(false);
      setVideoUrl(null);
      setIsRecording(false);
      setRecordProgress(0);
      setElapsedSeconds(0);
    }
  }, [isOpen, fullSlideshowDuration]);

  useEffect(() => {
    return () => {
      if (videoUrl) {
        URL.revokeObjectURL(videoUrl);
      }
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [videoUrl]);

  if (!isOpen) return null;

  const formatTime = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = Math.floor(totalSec % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Determine canvas width and height from aspect ratio
  const getCanvasDimensions = () => {
    switch (settings.aspectRatio) {
      case '9:16':
        return { width: 720, height: 1280 };
      case '1:1':
        return { width: 1080, height: 1080 };
      case '4:5':
        return { width: 864, height: 1080 };
      case '16:9':
      default:
        return { width: 1280, height: 720 };
    }
  };

  const stopRecordingNow = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
    }
  };

  const startRenderAndRecord = async () => {
    if (slides.length === 0) return;
    setIsRecording(true);
    setRecordProgress(0);
    setElapsedSeconds(0);
    setVideoUrl(null);

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { width, height } = getCanvasDimensions();
    canvas.width = width;
    canvas.height = height;

    // Preload image elements
    const loadedImages: HTMLImageElement[] = await Promise.all(
      slides.map(
        (s) =>
          new Promise<HTMLImageElement>((resolve) => {
            const img = new Image();
            img.crossOrigin = 'anonymous';
            img.src = s.url;
            img.onload = () => resolve(img);
            img.onerror = () => resolve(img);
          }),
      ),
    );

    // Determine preferred video codec (prioritize hardware-accelerated H.264 MP4 / WebM VP8 over heavy CPU-bound VP9)
    const preferredTypes = [
      'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
      'video/mp4',
      'video/webm;codecs=h264',
      'video/webm;codecs=vp8',
      'video/webm',
      'video/webm;codecs=vp9',
    ];
    let selectedMime = '';
    for (const mime of preferredTypes) {
      if (typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported(mime)) {
        selectedMime = mime;
        break;
      }
    }
    const isMp4 = selectedMime.toLowerCase().includes('mp4');
    setOutputExt(isMp4 ? 'mp4' : 'webm');

    // Setup MediaRecorder with rock-solid frame-rate and optimized bitrate
    const stream = canvas.captureStream(frameRate);
    let recorder: MediaRecorder;
    const targetBps = frameRate === 60 ? 6_000_000 : 4_000_000;

    try {
      recorder = new MediaRecorder(stream, {
        mimeType: selectedMime || undefined,
        videoBitsPerSecond: targetBps,
      });
    } catch {
      try {
        recorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
      } catch {
        recorder = new MediaRecorder(stream);
      }
    }
    mediaRecorderRef.current = recorder;

    const recordedChunks: Blob[] = [];
    recorder.ondataavailable = (e) => {
      if (e.data.size > 0) recordedChunks.push(e.data);
    };

    recorder.onstop = () => {
      const blob = new Blob(recordedChunks, { type: selectedMime || (isMp4 ? 'video/mp4' : 'video/webm') });
      const url = URL.createObjectURL(blob);
      setVideoUrl(url);
      setIsRecording(false);
    };

    // PERFORMANCE OPTIMIZATION 1: Pre-render blurred backgrounds for all slides ONCE.
    // This eliminates heavy real-time Gaussian filter calculations during recording.
    const preRenderedBgs: HTMLCanvasElement[] = loadedImages.map((img) => {
      const bgCanvas = document.createElement('canvas');
      bgCanvas.width = width;
      bgCanvas.height = height;
      const bctx = bgCanvas.getContext('2d');
      if (bctx && img.complete && img.naturalWidth > 0) {
        bctx.imageSmoothingEnabled = true;
        bctx.imageSmoothingQuality = 'high';
        bctx.filter = `blur(${settings.blur}px) brightness(${settings.brightness}) saturate(${settings.saturate})`;
        const imgAspect = img.naturalWidth / img.naturalHeight;
        const canvasAspect = width / height;
        let bgW = width;
        let bgH = height;
        if (imgAspect > canvasAspect) {
          bgH = height;
          bgW = height * imgAspect;
        } else {
          bgW = width;
          bgH = width / imgAspect;
        }
        bctx.drawImage(img, (width - bgW) / 2, (height - bgH) / 2, bgW, bgH);
      }
      return bgCanvas;
    });

    // PERFORMANCE OPTIMIZATION 2: Pre-render vignette gradient ONCE onto an offscreen canvas.
    // Eliminates radial gradient recreation 30-60 times per second!
    const vignetteCanvas = document.createElement('canvas');
    vignetteCanvas.width = width;
    vignetteCanvas.height = height;
    const vctx = vignetteCanvas.getContext('2d');
    if (vctx) {
      const grad = vctx.createRadialGradient(
        width / 2,
        height / 2,
        Math.min(width, height) * 0.25,
        width / 2,
        height / 2,
        Math.max(width, height) * 0.6,
      );
      grad.addColorStop(0, 'rgba(255,255,255,0.06)');
      grad.addColorStop(1, 'rgba(0,0,0,0.35)');
      vctx.fillStyle = grad;
      vctx.fillRect(0, 0, width, height);
    }

    recorder.start(1000); // Deliver slices every 1 second

    const startTime = performance.now();
    const slideDurationMs = Math.max(1000, (settings.interval || 5) * 1000);
    const totalDurationMs = isUnlimited ? Infinity : durationSeconds * 1000;
    let lastUiUpdate = 0;

    // 1. Draw blurred background layer (blazing fast from pre-rendered texture)
    const drawSlideBackground = (slideIdx: number, motionT: number, alpha: number) => {
      const bgCanvas = preRenderedBgs[slideIdx];
      if (!bgCanvas) return;

      ctx.save();
      ctx.globalAlpha = Math.max(0, Math.min(1, alpha));

      let bgShiftX = 0;
      let bgShiftY = 0;
      let bgScale = 1.25;

      if (settings.motionPattern === '4-linear') {
        const motionType = slideIdx % 4;
        if (motionType === 0) {
          bgScale = 1.05 + motionT * 0.13;
        } else if (motionType === 1) {
          bgScale = 1.18 - motionT * 0.13;
        } else if (motionType === 2) {
          bgScale = 1.15;
          bgShiftX = -0.05 + motionT * 0.10;
        } else {
          bgScale = 1.15;
          bgShiftX = 0.05 - motionT * 0.10;
        }
      } else {
        const isEven = slideIdx % 2 === 0;
        const bgShift = isEven ? (1 - motionT) * 0.08 - 0.04 : (motionT - 0.5) * 0.08;
        bgShiftX = bgShift;
        bgShiftY = bgShift;
        bgScale = 1.25 + (isEven ? motionT * 0.05 : (1 - motionT) * 0.05);
      }

      ctx.translate(width / 2 + bgShiftX * width, height / 2 + bgShiftY * height);
      ctx.scale(bgScale, bgScale);
      ctx.drawImage(bgCanvas, -width / 2, -height / 2, width, height);
      ctx.restore();
    };

    // 2. Draw vignette gradient (instant draw from pre-rendered canvas)
    const drawVignette = () => {
      ctx.drawImage(vignetteCanvas, 0, 0);
    };

    // 3. Draw foreground card with sharp border, pre-rendered shadow, and motion
    const drawSlideCard = (slideIdx: number, motionT: number, alpha: number) => {
      const img = loadedImages[slideIdx];
      if (!img || !img.complete || img.naturalWidth <= 0) return;

      ctx.save();
      ctx.globalAlpha = Math.max(0, Math.min(1, alpha));

      let mainShiftX = 0;
      let mainShiftY = 0;
      let mainScale = 1.0;

      if (settings.motionPattern === '4-linear') {
        const motionType = slideIdx % 4;
        const edgeFraction = Math.max(0.10, (1 - settings.foregroundScale / 100) / 2);

        if (motionType === 0) {
          mainScale = 1.0 + motionT * 0.16;
        } else if (motionType === 1) {
          mainScale = 1.16 - motionT * 0.16;
        } else if (motionType === 2) {
          mainScale = 1.0;
          mainShiftX = edgeFraction - motionT * (2 * edgeFraction);
        } else {
          mainScale = 1.0;
          mainShiftX = -edgeFraction + motionT * (2 * edgeFraction);
        }
      } else {
        const isEven = slideIdx % 2 === 0;
        const mainShift = isEven ? (motionT - 0.5) * 0.06 : (1 - motionT) * 0.06 - 0.03;
        mainShiftX = mainShift;
        mainShiftY = -mainShift;
        mainScale = 1.0 + (isEven ? (1 - motionT) * 0.04 : motionT * 0.04);
      }

      const scalePct = settings.foregroundScale / 100;
      const targetW = width * scalePct;
      const targetH = height * scalePct;

      ctx.translate(width / 2 + mainShiftX * width, height / 2 + mainShiftY * height);
      ctx.scale(mainScale, mainScale);

      // Helper function to trace the exact card shape
      const traceCardPath = () => {
        ctx.beginPath();
        if (settings.maskStyle === 'circle') {
          const r = Math.min(targetW, targetH) / 2;
          ctx.arc(0, 0, r, 0, Math.PI * 2);
        } else if (settings.maskStyle === 'rounded') {
          const r = 20;
          ctx.roundRect(-targetW / 2, -targetH / 2, targetW, targetH, r);
        } else if (settings.maskStyle === 'full') {
          ctx.rect(-width / 2, -height / 2, width, height);
        } else {
          // Sharp Square (border-radius: 0px)
          ctx.rect(-targetW / 2, -targetH / 2, targetW, targetH);
        }
        ctx.closePath();
      };

      // 1. Soft Drop Shadow (rendered directly under the exact card path - zero black box artifact)
      if (settings.showShadow && settings.maskStyle !== 'full') {
        ctx.save();
        ctx.shadowColor = 'rgba(0,0,0,0.55)';
        ctx.shadowBlur = 20;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 8;
        ctx.fillStyle = '#000000';
        traceCardPath();
        ctx.fill();
        ctx.restore();
      }

      // 2. Clip and draw image on top of shadow fill
      ctx.save();
      traceCardPath();
      ctx.clip();
      let fgDrawW = targetW;
      let fgDrawH = targetH;
      if (settings.maskStyle === 'full') {
        fgDrawW = width;
        fgDrawH = height;
      }

      const slide = slides[slideIdx];
      const zoom = slide?.zoom ?? 1.0;
      const offX = ((slide?.offsetX ?? 0) / 100) * fgDrawW;
      const offY = ((slide?.offsetY ?? 0) / 100) * fgDrawH;
      const fitMode = slide?.fitMode ?? 'cover';

      const imgAspect = img.naturalWidth / img.naturalHeight;
      let drawW: number;
      let drawH: number;

      if (fitMode === 'contain') {
        if (imgAspect > fgDrawW / fgDrawH) {
          drawW = fgDrawW;
          drawH = drawW / imgAspect;
        } else {
          drawH = fgDrawH;
          drawW = drawH * imgAspect;
        }
      } else {
        // 'cover' mode
        if (imgAspect > fgDrawW / fgDrawH) {
          drawH = fgDrawH;
          drawW = drawH * imgAspect;
        } else {
          drawW = fgDrawW;
          drawH = drawW / imgAspect;
        }
      }

      // Apply zoom and user pan offsets
      drawW *= zoom;
      drawH *= zoom;

      ctx.drawImage(img, -drawW / 2 + offX, -drawH / 2 + offY, drawW, drawH);
      ctx.restore();

      // 3. Sharp Border along exact card path
      if (settings.showBorder && settings.maskStyle !== 'full') {
        traceCardPath();
        ctx.lineWidth = settings.borderWidth * 2;
        ctx.strokeStyle = settings.borderColor;
        ctx.stroke();
      }

      ctx.restore();
    };

    const renderLoop = (now: number) => {
      const elapsed = now - startTime;

      // Throttle React state updates to once every 250ms (prevents UI re-render thrashing & GC lag)
      if (now - lastUiUpdate > 250) {
        lastUiUpdate = now;
        const currentSec = Math.floor(elapsed / 1000);
        setElapsedSeconds(currentSec);

        if (!isUnlimited) {
          const progressRatio = Math.min(elapsed / totalDurationMs, 1);
          setRecordProgress(Math.round(progressRatio * 100));
        }

        const currentSlideIdx = Math.floor(elapsed / slideDurationMs) % slides.length;
        const currentLoop = Math.floor(elapsed / (slideDurationMs * slides.length)) + 1;
        setCurrentSlideDisplayIndex(currentSlideIdx + 1);
        setCurrentLoopDisplay(currentLoop);
      }

      const currentSlideIdx = Math.floor(elapsed / slideDurationMs) % slides.length;
      const elapsedInSlide = elapsed % slideDurationMs;
      const slideProgress = elapsedInSlide / slideDurationMs;

      ctx.clearRect(0, 0, width, height);

      // Render active slide clearly without overlapping another slide
      drawSlideBackground(currentSlideIdx, slideProgress, 1.0);
      drawVignette();
      drawSlideCard(currentSlideIdx, slideProgress, 1.0);

      // Check if finished
      if (!isUnlimited && elapsed >= totalDurationMs) {
        if (recorder.state === 'recording') {
          recorder.stop();
        }
      } else {
        animationFrameRef.current = requestAnimationFrame(renderLoop);
      }
    };

    animationFrameRef.current = requestAnimationFrame(renderLoop);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-2xl flex flex-col gap-4 text-white">
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <Video className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-sm sm:text-base">
              ইনশট ভিডিও এক্সপোর্ট (Export InShot Video)
            </h3>
          </div>
          <button
            onClick={onClose}
            disabled={isRecording}
            className="p-1 rounded-lg hover:bg-neutral-800 text-neutral-400 hover:text-white disabled:opacity-40"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-neutral-400 leading-relaxed">
          আপনার ডুয়েল-লেয়ার স্লাইডশোটি কোনো সময়সীমা (Limit) ছাড়াই সম্পূর্ণ স্লাইডশো অথবা যত খুশি দীর্ঘ সময় ধরে ভিডিও ফরম্যাটে এক্সপোর্ট করতে পারবেন।
        </p>

        {/* Live Hardware Accelerated Canvas (Visibly mounted to ensure zero browser throttling and stutter-free recording) */}
        <div className={isRecording ? "w-full overflow-hidden rounded-xl bg-black border border-neutral-800 flex flex-col items-center justify-center p-2" : "hidden"}>
          <div className="text-[11px] text-neutral-400 font-semibold mb-1.5 flex items-center gap-1.5 self-start px-1">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
            <span>লাইভ হার্ডওয়্যার রেন্ডারিং মনিটর ({frameRate} FPS স্মুথ মোড):</span>
          </div>
          <canvas ref={canvasRef} className="w-full max-h-48 object-contain rounded-lg shadow-inner bg-neutral-950" />
        </div>

        {/* Duration & Quality Select */}
        {!videoUrl && !isRecording && (
          <div className="flex flex-col gap-3 bg-neutral-950/70 border border-neutral-800 p-3.5 rounded-xl">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-neutral-200 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-emerald-400" />
                <span>ভিডিওর মোট দৈর্ঘ্য (Duration):</span>
              </label>
              <span className="text-xs font-mono font-bold text-emerald-400">
                {isUnlimited ? '∞ আনলিমিটেড (লাইভ)' : `${durationSeconds} সেকেন্ড (${formatTime(durationSeconds)})`}
              </span>
            </div>

            {/* Quick Choice Buttons */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
              <button
                type="button"
                onClick={() => {
                  setIsUnlimited(false);
                  setDurationSeconds(fullSlideshowDuration);
                }}
                className={`py-2 px-2 text-xs font-medium rounded-lg border transition-all text-center flex flex-col items-center justify-center gap-0.5 ${
                  !isUnlimited && durationSeconds === fullSlideshowDuration
                    ? 'border-emerald-500 bg-emerald-500/20 text-emerald-300 font-bold'
                    : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:bg-neutral-800'
                }`}
              >
                <span>ফুল স্লাইডশো</span>
                <span className="text-[10px] text-emerald-400 font-mono">{fullSlideshowDuration}s (১টি সাইকেল)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setIsUnlimited(false);
                  setDurationSeconds(fullSlideshowDuration * 2);
                }}
                className={`py-2 px-2 text-xs font-medium rounded-lg border transition-all text-center flex flex-col items-center justify-center gap-0.5 ${
                  !isUnlimited && durationSeconds === fullSlideshowDuration * 2
                    ? 'border-emerald-500 bg-emerald-500/20 text-emerald-300 font-bold'
                    : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:bg-neutral-800'
                }`}
              >
                <span>২ বার লুপ</span>
                <span className="text-[10px] text-neutral-300 font-mono">{fullSlideshowDuration * 2}s (২টি সাইকেল)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setIsUnlimited(false);
                  setDurationSeconds(fullSlideshowDuration * 3);
                }}
                className={`py-2 px-2 text-xs font-medium rounded-lg border transition-all text-center flex flex-col items-center justify-center gap-0.5 ${
                  !isUnlimited && durationSeconds === fullSlideshowDuration * 3
                    ? 'border-emerald-500 bg-emerald-500/20 text-emerald-300 font-bold'
                    : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:bg-neutral-800'
                }`}
              >
                <span>৩ বার লুপ</span>
                <span className="text-[10px] text-neutral-300 font-mono">{fullSlideshowDuration * 3}s (৩টি সাইকেল)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setIsUnlimited(true);
                }}
                className={`py-2 px-2 text-xs font-medium rounded-lg border transition-all text-center flex flex-col items-center justify-center gap-0.5 ${
                  isUnlimited
                    ? 'border-emerald-500 bg-emerald-500/20 text-emerald-300 font-bold'
                    : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:bg-neutral-800'
                }`}
              >
                <span className="flex items-center gap-1">
                  <InfinityIcon className="w-3 h-3 text-emerald-400" />
                  <span>আনলিমিটেড</span>
                </span>
                <span className="text-[10px] text-neutral-300">ম্যানুয়াল স্টপ</span>
              </button>
            </div>

            {/* Custom Duration Input with No Limit */}
            <div className="pt-2 border-t border-neutral-800/80 flex items-center justify-between gap-2">
              <div className="flex flex-col">
                <span className="text-[11px] font-semibold text-neutral-300">কাস্টম মোট সময় (সেকেন্ডে):</span>
                <span className="text-[10px] text-neutral-500">কোনো ঊর্ধ্বসীমা নেই (যত সেকেন্ড খুশি লিখুন)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <input
                  type="number"
                  min="5"
                  step="1"
                  disabled={isUnlimited}
                  value={isUnlimited ? '' : durationSeconds}
                  placeholder={isUnlimited ? '∞ আনলিমিটেড' : ''}
                  onChange={(e) => {
                    const val = Math.max(5, parseInt(e.target.value) || 5);
                    setIsUnlimited(false);
                    setDurationSeconds(val);
                  }}
                  className="w-24 py-1.5 px-2 bg-neutral-900 border border-neutral-700 text-white font-mono font-bold text-xs rounded text-center focus:outline-none focus:border-emerald-500 disabled:opacity-40"
                />
                <span className="text-xs text-neutral-400 font-medium">সেকেন্ড</span>
              </div>
            </div>

            {/* Framerate Selection for Stutter-free Export */}
            <div className="pt-2 border-t border-neutral-800/80 flex items-center justify-between gap-2">
              <div className="flex flex-col">
                <span className="text-[11px] font-semibold text-neutral-300">ফ্রেম রেট (Framerate):</span>
                <span className="text-[10px] text-neutral-500">ল্যাগ ছাড়া স্মুথ ভিডিওর জন্য ৩০ FPS রিকমেন্ডেড</span>
              </div>
              <div className="flex items-center gap-1 bg-neutral-900 p-1 rounded-lg border border-neutral-800">
                <button
                  type="button"
                  onClick={() => setFrameRate(30)}
                  className={`px-2.5 py-1 text-xs rounded font-medium transition-all ${
                    frameRate === 30
                      ? 'bg-emerald-500 text-neutral-950 font-bold shadow'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  30 FPS (স্মুথ)
                </button>
                <button
                  type="button"
                  onClick={() => setFrameRate(60)}
                  className={`px-2.5 py-1 text-xs rounded font-medium transition-all ${
                    frameRate === 60
                      ? 'bg-emerald-500 text-neutral-950 font-bold shadow'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  60 FPS (আল্ট্রা)
                </button>
              </div>
            </div>

            <div className="text-[11px] text-emerald-400/90 flex items-center gap-1.5 bg-emerald-950/30 border border-emerald-800/40 p-2 rounded-lg">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>
                হার্ডওয়্যার-এক্সিলারেটেড এনকোডার দিয়ে রেন্ডার হবে, ফলে ভিডিওটি নামানোর পর কোনো ল্যাগ ছাড়াই পানির মতো স্মুথ চলবে।
              </span>
            </div>
          </div>
        )}

        {/* Recording in progress */}
        {isRecording && (
          <div className="flex flex-col items-center justify-center gap-3.5 py-4 bg-neutral-950 border border-neutral-800 rounded-xl p-4">
            <div className="relative">
              <Loader2 className="w-10 h-10 text-emerald-400 animate-spin" />
              <span className="absolute inset-0 flex items-center justify-center text-[10px] font-mono font-bold text-emerald-300">
                REC
              </span>
            </div>

            <div className="text-center">
              <p className="text-sm font-bold text-white flex items-center justify-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
                <span>ভিডিও তৈরি হচ্ছে...</span>
              </p>
              <p className="text-xs text-neutral-300 font-mono mt-1 font-semibold">
                সময়: {formatTime(elapsedSeconds)} {isUnlimited ? '(আনলিমিটেড চলমান)' : `/ ${formatTime(durationSeconds)} (${recordProgress}%)`}
              </p>
              <p className="text-[11px] text-neutral-400 mt-0.5">
                স্লাইড {currentSlideDisplayIndex}/{slides.length} • লুপ #{currentLoopDisplay}
              </p>
            </div>

            {!isUnlimited && (
              <div className="w-full bg-neutral-800 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full transition-all duration-150"
                  style={{ width: `${recordProgress}%` }}
                />
              </div>
            )}

            {/* Instant Finish / Stop Button */}
            <button
              type="button"
              onClick={stopRecordingNow}
              className="mt-2 w-full py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-lg shadow-red-600/30 active:scale-98"
            >
              <Square className="w-3.5 h-3.5 fill-current" />
              <span>এখনই থামিয়ে ভিডিও সেভ করুন ({formatTime(elapsedSeconds)})</span>
            </button>
          </div>
        )}

        {/* Video Ready */}
        {videoUrl && (
          <div className="flex flex-col gap-3 items-center justify-center py-2">
            <div className="flex items-center gap-2 text-emerald-400 text-xs font-semibold">
              <CheckCircle2 className="w-4 h-4" />
              <span>ভিডিও সফলভাবে রেন্ডার হয়েছে! (দৈর্ঘ্য: {formatTime(elapsedSeconds)})</span>
            </div>

            <video
              src={videoUrl}
              controls
              autoPlay
              loop
              className="w-full max-h-60 rounded-lg bg-black border border-neutral-800 object-contain"
            />

            <div className="flex gap-2 w-full">
              <button
                type="button"
                onClick={() => {
                  setVideoUrl(null);
                  setIsRecording(false);
                }}
                className="flex-1 py-2.5 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-semibold text-xs transition-colors text-center"
              >
                পুনরায় রেকর্ড করুন
              </button>

              <a
                href={videoUrl}
                download={`inshot-slideshow-${Date.now()}.${outputExt}`}
                className="flex-[2] py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs flex items-center justify-center gap-2 transition-colors shadow-lg shadow-emerald-500/20"
              >
                <Download className="w-4 h-4" />
                <span>ভিডিও ডাউনলোড করুন ({outputExt.toUpperCase()})</span>
              </a>
            </div>
          </div>
        )}

        {/* Action Button */}
        {!isRecording && !videoUrl && (
          <button
            onClick={startRenderAndRecord}
            className="w-full py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-sm flex items-center justify-center gap-2 transition-colors shadow-lg shadow-emerald-500/20 active:scale-98"
          >
            <Video className="w-4 h-4" />
            <span>ভিডিও তৈরি শুরু করুন ({isUnlimited ? 'আনলিমিটেড' : `${durationSeconds} সেকেন্ড`})</span>
          </button>
        )}
      </div>
    </div>
  );
};
