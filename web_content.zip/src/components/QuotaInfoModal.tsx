import React from 'react';
import { X, Info, Gauge, DollarSign, ShieldAlert, Zap } from 'lucide-react';
import { QuotaDetails } from '../types';

interface QuotaInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  quotaDetails?: QuotaDetails;
}

export const QuotaInfoModal: React.FC<QuotaInfoModalProps> = ({ isOpen, onClose, quotaDetails }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-lg w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-100 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <Gauge className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-800">API Limits & Usage Transparency</h2>
              <p className="text-xs text-slate-500">Official Google Gemini API quotas & costs</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-slate-200/60 text-slate-400 hover:text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs text-slate-700 leading-relaxed">
          {/* Important Notice Banner */}
          <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-2xl flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-amber-900 mb-0.5">Usage is Not Unlimited</p>
              This application connects to official Google Gemini Live and Gemini Flash APIs. Each voice interaction and search query is subject to Google Cloud rate limits and quotas.
            </div>
          </div>

          {/* Rate limits card */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-2">
            <div className="flex items-center gap-2 font-semibold text-slate-800 text-sm">
              <Zap className="w-4 h-4 text-indigo-600" />
              <span>Standard API Rate Limits</span>
            </div>
            <ul className="list-disc list-inside space-y-1 text-slate-600 pl-1">
              <li>
                <strong>Free Tier Limits:</strong> Typically 15 Requests Per Minute (RPM) and 1,000,000 Tokens Per Minute (TPM).
              </li>
              <li>
                <strong>Gemini Live Voice Audio:</strong> Bidirectional audio streams 16kHz PCM input and 24kHz PCM output. Extended live sessions consume tokens continuously while active.
              </li>
              <li>
                <strong>Text Fallback (Gemini 3.8 Flash):</strong> High efficiency Q&A with Google Search grounding for verified real-time facts.
              </li>
            </ul>
          </div>

          {/* Pricing & Cost card */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-2">
            <div className="flex items-center gap-2 font-semibold text-slate-800 text-sm">
              <DollarSign className="w-4 h-4 text-emerald-600" />
              <span>Cost & Billing Transparency</span>
            </div>
            <p className="text-slate-600">
              When using a billing-enabled Google AI Studio API key, Google Cloud charges based on actual token usage:
            </p>
            <div className="grid grid-cols-2 gap-2 mt-2">
              <div className="p-2.5 bg-white rounded-xl border border-slate-200">
                <span className="font-semibold text-slate-800 block">Gemini 3.8 Flash</span>
                <span className="text-[11px] text-slate-500">~$0.10 per 1M input tokens</span>
              </div>
              <div className="p-2.5 bg-white rounded-xl border border-slate-200">
                <span className="font-semibold text-slate-800 block">Gemini 3.8 Live</span>
                <span className="text-[11px] text-slate-500">Low-latency audio streaming</span>
              </div>
            </div>
          </div>

          {/* What happens on 429 */}
          <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-blue-900">
            <strong>Automatic Recovery:</strong> If the Live voice session encounters a <code>429 Quota Exhausted</code> error, Blame immediately notifies you and allows you to seamlessly continue using the Text Fallback mode until the rate limit window resets.
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold transition-colors cursor-pointer"
          >
            Understood
          </button>
        </div>
      </div>
    </div>
  );
};
