import { useRef, useState, type PointerEvent } from "react";
import { Hand } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useCaliber } from "@/lib/store";

const SAMPLE_MS = 4000;

export function TouchTestView() {
  const { dict, hardware, setTouchHz, setTab } = useCaliber();
  const [hz, setHz] = useState<number | null>(null);
  const [active, setActive] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const stamps = useRef<number[]>([]);
  const start = useRef(0);
  const raf = useRef(0);

  const finish = () => {
    setActive(false);
    const deltas: number[] = [];
    const s = stamps.current;
    for (let i = 1; i < s.length; i++) deltas.push(s[i] - s[i - 1]);
    if (deltas.length < 8) {
      setHz(null);
      return;
    }
    const sorted = [...deltas].sort((a, b) => a - b);
    const cut = sorted.slice(Math.floor(sorted.length * 0.15), Math.ceil(sorted.length * 0.85));
    const median = cut[Math.floor(cut.length / 2)] || sorted[Math.floor(sorted.length / 2)];
    const raw = 1000 / Math.max(median, 2);
    const common = [60, 90, 120, 180, 240, 360, 480, 720];
    let best = common[0];
    for (const c of common) if (Math.abs(c - raw) < Math.abs(best - raw)) best = c;
    setHz(Math.abs(best - raw) < 40 ? best : Math.round(raw));
  };

  const onPointerDown = (e: PointerEvent<HTMLButtonElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    stamps.current = [];
    start.current = performance.now();
    setActive(true);
    setHz(null);
    setElapsed(0);
    const loop = () => {
      setElapsed(performance.now() - start.current);
      raf.current = requestAnimationFrame(loop);
    };
    raf.current = requestAnimationFrame(loop);
  };

  const onPointerMove = (e: PointerEvent<HTMLButtonElement>) => {
    if (!active) return;
    stamps.current.push(performance.now());
    if (performance.now() - start.current >= SAMPLE_MS) {
      cancelAnimationFrame(raf.current);
      finish();
    }
    e.preventDefault();
  };

  const onPointerUp = () => {
    cancelAnimationFrame(raf.current);
    if (active) finish();
  };

  const progress = Math.min(1, elapsed / SAMPLE_MS);

  return (
    <div className="space-y-4">
      <p className="text-sm leading-relaxed text-muted">{dict.touchHint}</p>
      <button
        type="button"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
        className="relative flex h-64 w-full touch-none flex-col items-center justify-center overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)] select-none"
      >
        <div className="absolute inset-x-0 bottom-0 bg-primary/20" style={{ height: `${progress * 100}%` }} />
        <Hand className={`relative size-8 ${active ? "text-primary" : "text-muted"}`} />
        <span className="relative mt-3 font-display text-lg font-semibold">
          {active ? dict.measuring : dict.touchStart}
        </span>
        {hardware ? (
          <span className="relative mt-1 text-[11px] text-subtle">
            {dict.touchRate}: {hardware.touchSamplingHz} Hz
            {hardware.touchSamplingEstimated ? ` (${dict.estimated})` : ""}
          </span>
        ) : null}
      </button>
      {hz !== null ? (
        <Card className="flex flex-col items-start gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="text-xs uppercase tracking-[0.16em] text-subtle">{dict.touchResult}</div>
            <div className="font-display text-3xl font-semibold tabular-nums text-accent">{hz} Hz</div>
          </div>
          <Button
            onClick={() => {
              setTouchHz(hz);
              setTab("settings");
            }}
          >
            {dict.applyTouch}
          </Button>
        </Card>
      ) : null}
    </div>
  );
}
