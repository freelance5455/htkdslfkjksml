import React, { useState } from 'react';
import {
  X,
  Plus,
  Flame,
  Cake,
  Heart,
  Sparkles,
  Download,
  Upload,
  Trash2,
  Edit2,
  Calendar as CalendarIcon,
  Search,
  Users,
  RefreshCw,
} from 'lucide-react';
import { HebrewEvent, LocationPreset, UserSettings } from '../types';
import {
  generateICalFile,
  downloadFile,
} from '../services/syncService';
import {
  getUpcomingHebrewEventOccurrences,
  getHebrewNumberGematriya,
  HEBREW_MONTH_NAMES_LIST,
} from '../services/hebrewCalendarService';
import { getTranslations } from '../services/i18n';

interface EventsManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  events: HebrewEvent[];
  onAddEvent: () => void;
  onEditEvent: (event: HebrewEvent) => void;
  onDeleteEvent: (id: string) => void;
  onImportEvents: (imported: HebrewEvent[]) => void;
  location: LocationPreset;
  settings?: UserSettings;
}

export const EventsManagerModal: React.FC<EventsManagerModalProps> = ({
  isOpen,
  onClose,
  events,
  onAddEvent,
  onEditEvent,
  onDeleteEvent,
  onImportEvents,
  location,
  settings,
}) => {
  const isRtl = settings?.language === 'he';
  const t = getTranslations(settings?.language || 'he');

  const [filterType, setFilterType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen) return null;

  const filtered = events.filter((ev) => {
    if (filterType !== 'all' && ev.type !== filterType) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        ev.title.toLowerCase().includes(q) ||
        (ev.hebrewTitle && ev.hebrewTitle.toLowerCase().includes(q)) ||
        ev.hebrewMonthName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleExportICal = () => {
    const icsContent = generateICalFile(events, location);
    downloadFile(icsContent, 'hebrew_calendar_events.ics', 'text/calendar;charset=utf-8');
  };

  const handleExportJSON = () => {
    const jsonStr = JSON.stringify(events, null, 2);
    downloadFile(jsonStr, 'hebrew_events_backup.json', 'application/json');
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (Array.isArray(parsed)) {
          onImportEvents(parsed);
          alert(isRtl ? `יובאו בהצלחה ${parsed.length} אירועים עבריים!` : `Successfully imported ${parsed.length} Hebrew events!`);
        } else {
          alert(isRtl ? 'מבנה קובץ גיבוי לא תקין' : 'Invalid backup file format');
        }
      } catch (err) {
        alert(isRtl ? 'שגיאה בפענוח קובץ JSON' : 'Could not parse JSON file');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150"
      dir={isRtl ? 'rtl' : 'ltr'}
    >
      <div className="bg-[#121212] rounded-2xl max-w-3xl w-full border border-[#2A2A2A] shadow-2xl overflow-hidden my-8 flex flex-col max-h-[90vh] text-[#D1D1D1]">
        {/* Header */}
        <div className="p-5 border-b border-[#2A2A2A] flex items-center justify-between bg-[#161616]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#252525] border border-[#3A3A3A] text-[#C5A267] flex items-center justify-center text-lg shadow-xs">
              <Flame className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-[#EAEAEA] font-serif-hebrew">
                {t.personalEventsTitle}
              </h3>
              <p className="text-xs text-[#888888]">
                {t.personalEventsDesc}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#888888] hover:text-[#EAEAEA] hover:bg-[#252525] transition-colors cursor-pointer"
            title={t.close}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toolbar */}
        <div className="p-4 border-b border-[#2A2A2A] bg-[#161616]/60 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <div className="relative flex-1 sm:w-56">
              <Search className={`w-3.5 h-3.5 absolute top-1/2 -translate-y-1/2 text-[#666666] ${isRtl ? 'right-3' : 'left-3'}`} />
              <input
                type="text"
                placeholder={t.searchEvents}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className={`w-full py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] placeholder-[#666666] focus:outline-hidden focus:border-[#C5A267] ${isRtl ? 'pr-8 pl-3' : 'pl-8 pr-3'}`}
              />
            </div>

            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] focus:border-[#C5A267] focus:outline-hidden"
            >
              <option value="all">{t.allTypes} ({events.length})</option>
              <option value="birthday">{isRtl ? t.hebrewBirthday : t.birthday}</option>
              <option value="yahrzeit">{isRtl ? t.yahrzeitMemorial : t.yahrzeit}</option>
              <option value="anniversary">{isRtl ? t.hebrewAnniversary : t.anniversary}</option>
              <option value="barmitzvah">{isRtl ? t.barBatMitzvah : t.barmitzvah}</option>
              <option value="custom">{isRtl ? t.customHebrewEvent : t.customEvent}</option>
            </select>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              onClick={handleExportICal}
              className="px-3 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] hover:bg-[#252525] text-xs font-medium text-[#D1D1D1] flex items-center gap-1.5 transition-colors cursor-pointer"
              title={t.exportICal}
            >
              <Download className="w-3.5 h-3.5 text-[#C5A267]" />
              <span>{t.exportICal}</span>
            </button>

            <label className="px-3 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] hover:bg-[#252525] text-xs font-medium text-[#D1D1D1] flex items-center gap-1.5 cursor-pointer transition-colors">
              <Upload className="w-3.5 h-3.5 text-[#C5A267]" />
              <span>{t.importBackup}</span>
              <input type="file" accept=".json" onChange={handleImportJSON} className="hidden" />
            </label>

            <button
              onClick={onAddEvent}
              className="px-3.5 py-1.5 rounded-lg bg-[#C5A267] hover:bg-[#b59257] text-[#0F0F0F] text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer font-serif-hebrew"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{t.addEvent}</span>
            </button>
          </div>
        </div>

        {/* Events List */}
        <div className="divide-y divide-[#2A2A2A] overflow-y-auto p-4 flex-1 space-y-2">
          {filtered.length > 0 ? (
            filtered.map((ev) => {
              const occurrences = getUpcomingHebrewEventOccurrences(ev, 3);
              const nextOccurrence = occurrences[0];

              return (
                <div
                  key={ev.id}
                  className="p-4 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] hover:bg-[#1E1E1E] transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  style={{
                    [isRtl ? 'borderRightColor' : 'borderLeftColor']: ev.color || '#C5A267',
                    [isRtl ? 'borderRightWidth' : 'borderLeftWidth']: 3,
                  }}
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      {ev.type === 'yahrzeit' ? (
                        <Flame className="w-4 h-4 text-blue-400 shrink-0" />
                      ) : ev.type === 'birthday' ? (
                        <Cake className="w-4 h-4 text-[#C5A267] shrink-0" />
                      ) : ev.type === 'anniversary' ? (
                        <Heart className="w-4 h-4 text-rose-400 shrink-0" />
                      ) : (
                        <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
                      )}
                      <h4 className="font-bold text-sm sm:text-base text-[#EAEAEA] font-serif-hebrew">
                        {ev.title}
                      </h4>
                      {ev.hebrewTitle && (
                        <span className="text-xs text-[#888888] font-serif-hebrew" dir="rtl">
                          ({ev.hebrewTitle})
                        </span>
                      )}
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-sm bg-[#252525] text-[#888888] uppercase">
                        {ev.type === 'birthday'
                          ? (isRtl ? t.hebrewBirthday : t.birthday)
                          : ev.type === 'yahrzeit'
                          ? (isRtl ? t.yahrzeitMemorial : t.yahrzeit)
                          : ev.type === 'anniversary'
                          ? (isRtl ? t.hebrewAnniversary : t.anniversary)
                          : ev.type === 'barmitzvah'
                          ? (isRtl ? t.barBatMitzvah : t.barmitzvah)
                          : (isRtl ? t.customHebrewEvent : t.customEvent)}
                      </span>
                      {ev.showCounter && (
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-sm bg-[#C5A267]/15 text-[#C5A267] border border-[#C5A267]/30">
                          {isRtl ? `מונה (בסיס ${ev.startHebrewYear || ev.hebrewYear || '5783'})` : `Counter (Base ${ev.startHebrewYear || ev.hebrewYear || '5783'})`}
                        </span>
                      )}
                      {ev.repeatCount && ev.repeatCount > 0 && (
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-sm bg-[#222222] text-[#888888] border border-[#333333] flex items-center gap-1">
                          <RefreshCw className="w-2.5 h-2.5 text-[#C5A267]" />
                          <span>{ev.repeatCount} {t.times}</span>
                        </span>
                      )}
                    </div>

                    <div className="text-xs text-[#C5A267] font-hebrew mt-1" dir="rtl">
                      {getHebrewNumberGematriya(ev.hebrewDay)} {HEBREW_MONTH_NAMES_LIST.find((m) => m.num === ev.hebrewMonth)?.nameHe || ev.hebrewMonthName}
                      {!isRtl && (
                        <span className="text-[#888888] font-normal font-sans ml-1.5" dir="ltr">
                          ({ev.hebrewDay} {ev.hebrewMonthName})
                        </span>
                      )}
                    </div>

                    {/* Participants preview */}
                    {ev.participants && ev.participants.length > 0 && (
                      <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                        <Users className="w-3 h-3 text-[#888888]" />
                        {ev.participants.slice(0, 3).map((p, pIdx) => (
                          <span
                            key={pIdx}
                            className="text-[10px] px-2 py-0.5 rounded-full bg-[#202020] border border-[#333333] text-[#D1D1D1]"
                          >
                            {p}
                          </span>
                        ))}
                        {ev.participants.length > 3 && (
                          <span className="text-[10px] text-[#888888]">
                            +{ev.participants.length - 3}
                          </span>
                        )}
                      </div>
                    )}

                    {nextOccurrence && (
                      <div className="text-xs text-[#888888] mt-1 flex items-center gap-1.5">
                        <CalendarIcon className="w-3 h-3 text-[#C5A267]" />
                        <span>
                          {isRtl ? 'המועד הבא:' : 'Next:'}{' '}
                          <strong className="text-[#D1D1D1]">
                            {nextOccurrence.gregorianDate.toLocaleDateString(isRtl ? 'he-IL' : 'en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                          </strong>{' '}
                          ({nextOccurrence.daysUntil} {nextOccurrence.daysUntil === 1 ? t.daySingular : t.days})
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onEditEvent(ev)}
                      className="p-1.5 rounded-lg border border-[#2A2A2A] bg-[#161616] text-[#888888] hover:text-[#EAEAEA] hover:bg-[#252525] transition-colors cursor-pointer"
                      title={t.editEvent}
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onDeleteEvent(ev.id)}
                      className="p-1.5 rounded-lg border border-[#2A2A2A] bg-[#161616] text-[#888888] hover:text-rose-400 hover:bg-[#252525] transition-colors cursor-pointer"
                      title={t.deleteEvent}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-12 text-[#555555] text-xs">
              {isRtl ? 'לא נמצאו אירועים עבריים אישיים. לחץ על "+ הוספת אירוע" כדי ליצור אירוע.' : 'No personal Hebrew events found. Click "+ Add Event" to create one.'}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[#2A2A2A] bg-[#161616] flex justify-between items-center">
          <button
            onClick={handleExportJSON}
            className="text-xs text-[#888888] hover:text-[#C5A267] transition-colors flex items-center gap-1 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" /> {t.exportBackup}
          </button>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#C5A267] hover:bg-[#b59257] text-[#0F0F0F] text-xs font-bold transition-colors cursor-pointer"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
