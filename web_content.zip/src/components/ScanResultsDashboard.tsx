"use client";

import React, { useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  Eye,
  FileCode2,
  Globe,
  Layers,
  Monitor,
  MousePointerClick,
  Palette,
  ShieldAlert,
  Smartphone,
  XCircle,
} from "lucide-react";
import MasterPromptPanel from "@/components/MasterPromptPanel";
import type { FullScanDetails, MasterPromptRecord } from "@/types/xray";

interface ScanResultsDashboardProps {
  details: FullScanDetails;
  onPromptCreated: (prompt: MasterPromptRecord) => void;
}

type TabKey = "overview" | "pages" | "interactions" | "design" | "prompt";

export default function ScanResultsDashboard({
  details,
  onPromptCreated,
}: ScanResultsDashboardProps) {
  const [activeTab, setActiveTab] = useState<TabKey>("overview");
  const [selectedPageIdx, setSelectedPageIdx] = useState(0);
  const [viewportMode, setViewportMode] = useState<"desktop" | "mobile">("desktop");
  const [outcomeFilter, setOutcomeFilter] = useState<string>("all");

  const { scan, pages, interactions, report, prompts } = details;
  const activePage = pages[selectedPageIdx] ?? pages[0] ?? null;

  const filteredInteractions =
    outcomeFilter === "all"
      ? interactions
      : interactions.filter((i) => i.outcome === outcomeFilter);

  const tabs: { key: TabKey; label: string; icon: React.ReactNode; badge?: number }[] = [
    { key: "overview", label: "AI Report", icon: <Eye className="h-4 w-4" /> },
    {
      key: "pages",
      label: "Pages & Sitemap",
      icon: <Layers className="h-4 w-4" />,
      badge: pages.length,
    },
    {
      key: "interactions",
      label: "Interactive Tests",
      icon: <MousePointerClick className="h-4 w-4" />,
      badge: interactions.length,
    },
    {
      key: "design",
      label: "Design & Screenshots",
      icon: <Palette className="h-4 w-4" />,
    },
    {
      key: "prompt",
      label: "Master Prompt",
      icon: <FileCode2 className="h-4 w-4" />,
      badge: prompts.length,
    },
  ];

  return (
    <div className="space-y-5">
      {/* Tab Bar */}
      <div className="flex flex-wrap gap-2 border-b border-zinc-800 pb-3">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.key;
          return (
            <button
              key={tab.key}
              type="button"
              onClick={() => setActiveTab(tab.key)}
              className={`inline-flex items-center gap-2 rounded-lg px-3.5 py-2 text-sm font-medium transition ${
                isActive
                  ? "bg-indigo-600 text-white"
                  : "border border-zinc-800 bg-surface-900 text-zinc-300 hover:bg-surface-850"
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
              {tab.badge !== undefined && (
                <span
                  className={`rounded px-1.5 py-0.5 text-xs font-mono ${
                    isActive ? "bg-indigo-500/40 text-white" : "bg-surface-800 text-zinc-400"
                  }`}
                >
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* TAB 1: AI REPORT */}
      {activeTab === "overview" && (
        <div className="space-y-5">
          {!report ? (
            <div className="rounded-xl border border-zinc-800 bg-surface-900 p-6 text-sm text-zinc-400">
              AI report is being generated or waiting for page inspection to finish.
            </div>
          ) : (
            <>
              <div className="rounded-xl border border-zinc-800 bg-surface-900 p-5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h3 className="text-base font-semibold text-zinc-100">Executive Summary</h3>
                  <span className="rounded-md border border-zinc-700 bg-surface-850 px-2.5 py-1 text-xs font-mono text-zinc-300">
                    {report.provider} / {report.model}
                  </span>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-zinc-300">
                  {report.executiveSummary}
                </p>
              </div>

              {/* Three-Column Evidence Separation */}
              <div className="grid gap-4 lg:grid-cols-3">
                <div className="rounded-xl border border-emerald-500/20 bg-surface-900 p-5">
                  <div className="flex items-center gap-2 text-emerald-400">
                    <CheckCircle2 className="h-4 w-4" />
                    <h4 className="text-sm font-semibold">Observed Facts</h4>
                  </div>
                  <ul className="mt-3 space-y-2 text-xs leading-relaxed text-zinc-300">
                    {report.observedFacts.map((fact, idx) => (
                      <li key={idx} className="flex gap-2">
                        <span className="text-emerald-500">•</span>
                        <span>{fact}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="rounded-xl border border-amber-500/20 bg-surface-900 p-5">
                  <div className="flex items-center gap-2 text-amber-400">
                    <AlertTriangle className="h-4 w-4" />
                    <h4 className="text-sm font-semibold">Inferred Behavior</h4>
                  </div>
                  <ul className="mt-3 space-y-2 text-xs leading-relaxed text-zinc-300">
                    {report.inferredBehavior.map((inf, idx) => (
                      <li key={idx} className="flex gap-2">
                        <span className="text-amber-500">•</span>
                        <span>{inf}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="rounded-xl border border-rose-500/20 bg-surface-900 p-5">
                  <div className="flex items-center gap-2 text-rose-400">
                    <ShieldAlert className="h-4 w-4" />
                    <h4 className="text-sm font-semibold">Unverified / Inaccessible</h4>
                  </div>
                  <ul className="mt-3 space-y-2 text-xs leading-relaxed text-zinc-300">
                    {report.unverifiedOrInaccessible.map((item, idx) => (
                      <li key={idx} className="flex gap-2">
                        <span className="text-rose-500">•</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Architecture & Journeys */}
              <div className="grid gap-4 md:grid-cols-2">
                <div className="rounded-xl border border-zinc-800 bg-surface-900 p-5">
                  <h4 className="text-sm font-semibold text-zinc-100">Navigation & User Journeys</h4>
                  <ul className="mt-3 space-y-2 text-xs text-zinc-300">
                    {report.navigationAndJourneys.map((j, idx) => (
                      <li key={idx} className="rounded-lg bg-surface-950 px-3 py-2 border border-zinc-800/80">
                        {j}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="rounded-xl border border-zinc-800 bg-surface-900 p-5 space-y-3">
                  <h4 className="text-sm font-semibold text-zinc-100">
                    Observed Functionality & Backend Evidence
                  </h4>
                  <p className="text-xs leading-relaxed text-zinc-300">
                    {report.observedFunctionalitySummary}
                  </p>
                  <p className="text-xs leading-relaxed text-zinc-400">
                    <strong className="text-zinc-200">Responsive: </strong>
                    {report.responsiveBehaviorSummary}
                  </p>
                  <div className="space-y-1">
                    <span className="text-xs font-medium text-zinc-400">Network / API Endpoints:</span>
                    {report.backendEvidence.map((ep, idx) => (
                      <div
                        key={idx}
                        className="truncate rounded bg-surface-950 px-2.5 py-1 font-mono text-[11px] text-zinc-300 border border-zinc-800"
                      >
                        {ep}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {/* TAB 2: PAGES & SITEMAP */}
      {activeTab === "pages" && (
        <div className="space-y-4">
          {pages.map((page, idx) => (
            <div
              key={page.id}
              className="rounded-xl border border-zinc-800 bg-surface-900 p-5 space-y-3"
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <Globe className="h-4 w-4 text-indigo-400" />
                  <span className="font-mono text-sm font-semibold text-zinc-100">
                    {page.path}
                  </span>
                  <span className="text-xs text-zinc-400">({page.title || "Untitled"})</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-mono">
                  <span
                    className={`rounded px-2 py-0.5 ${
                      page.isBlocked
                        ? "bg-rose-500/15 text-rose-300 border border-rose-500/30"
                        : "bg-emerald-500/15 text-emerald-300 border border-emerald-500/30"
                    }`}
                  >
                    HTTP {page.statusCode ?? "N/A"}
                  </span>
                  <span className="rounded bg-surface-850 px-2 py-0.5 text-zinc-400 border border-zinc-800">
                    {page.loadTimeMs}ms
                  </span>
                  <span className="rounded bg-surface-850 px-2 py-0.5 text-zinc-400 border border-zinc-800">
                    Depth {page.depth}
                  </span>
                </div>
              </div>

              {page.isBlocked && (
                <div className="rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-xs text-rose-300">
                  Access Restricted: {page.blockReason}
                </div>
              )}

              <div className="grid gap-3 md:grid-cols-3 text-xs">
                <div className="rounded-lg border border-zinc-800 bg-surface-950 p-3">
                  <div className="font-medium text-zinc-300 mb-1.5">
                    Sections ({page.sections.length})
                  </div>
                  <div className="space-y-1 max-h-36 overflow-y-auto">
                    {page.sections.slice(0, 10).map((s, sIdx) => (
                      <div key={sIdx} className="truncate text-zinc-400 font-mono text-[11px]">
                        &lt;{s.tag}&gt;{s.id ? `#${s.id}` : ""}{" "}
                        {s.headingText ? `— ${s.headingText}` : ""}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="rounded-lg border border-zinc-800 bg-surface-950 p-3">
                  <div className="font-medium text-zinc-300 mb-1.5">
                    Forms ({page.forms.length}) & Assets
                  </div>
                  <div className="text-zinc-400 space-y-1">
                    <div>Images: {page.images.length} | Inline SVGs: {page.svgCount}</div>
                    <div>Nav links: {page.navigationLinks.length} | Footer links: {page.footerLinks.length}</div>
                    <div>Mobile overflow: {page.responsive.hasHorizontalOverflowMobile ? "Yes" : "No"}</div>
                  </div>
                </div>

                <div className="rounded-lg border border-zinc-800 bg-surface-950 p-3">
                  <div className="font-medium text-zinc-300 mb-1.5">Visible Text Preview</div>
                  <p className="line-clamp-5 text-zinc-400 leading-relaxed">
                    {page.visibleText || "No visible text extracted."}
                  </p>
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedPageIdx(idx);
                    setActiveTab("design");
                  }}
                  className="text-xs font-medium text-indigo-400 hover:text-indigo-300"
                >
                  Inspect Screenshots & Styles →
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 3: INTERACTIVE TESTS */}
      {activeTab === "interactions" && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-zinc-800 bg-surface-900 p-4">
            <div className="flex flex-wrap gap-3 text-xs">
              <span className="text-zinc-300">
                Total Recorded: <strong className="text-white">{interactions.length}</strong>
              </span>
              <span className="text-emerald-400">
                Passed/Observed: <strong>{scan.interactionsPassed}</strong>
              </span>
              <span className="text-rose-400">
                Failed: <strong>{scan.interactionsFailed}</strong>
              </span>
              <span className="text-amber-400">
                Blocked/Untested: <strong>{scan.interactionsBlocked}</strong>
              </span>
            </div>

            <select
              value={outcomeFilter}
              onChange={(e) => setOutcomeFilter(e.target.value)}
              aria-label="Filter interaction outcomes"
              className="rounded-lg border border-zinc-700 bg-surface-850 px-3 py-1.5 text-xs text-zinc-200 focus:border-indigo-500 focus:outline-none"
            >
              <option value="all">All Outcomes</option>
              <option value="navigated">Navigated</option>
              <option value="modal_opened">Modal Opened</option>
              <option value="dropdown_toggled">Dropdown Toggled</option>
              <option value="tab_switched">Tab Switched</option>
              <option value="dom_mutated">DOM Mutated</option>
              <option value="no_visible_change">No Visible Change</option>
              <option value="failed">Failed</option>
              <option value="blocked_security">Blocked (Security/Auth)</option>
              <option value="untested_destructive">Skipped (Destructive)</option>
            </select>
          </div>

          <div className="overflow-x-auto rounded-xl border border-zinc-800 bg-surface-900">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-zinc-800 bg-surface-950 text-zinc-400">
                <tr>
                  <th className="px-4 py-3 font-medium">Type</th>
                  <th className="px-4 py-3 font-medium">Element Label</th>
                  <th className="px-4 py-3 font-medium">Outcome</th>
                  <th className="px-4 py-3 font-medium">Observed Result</th>
                  <th className="px-4 py-3 font-medium">Duration</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/70">
                {filteredInteractions.map((item) => (
                  <tr key={item.id} className="hover:bg-surface-850/50">
                    <td className="px-4 py-3 font-mono uppercase text-[11px] text-zinc-400">
                      {item.elementType}
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-medium text-zinc-200">{item.label}</div>
                      <div className="font-mono text-[11px] text-zinc-500 truncate max-w-[220px]">
                        {item.selector}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex items-center gap-1 rounded px-2 py-0.5 font-mono text-[11px] ${
                          item.outcome === "failed"
                            ? "bg-rose-500/15 text-rose-300"
                            : item.outcome === "blocked_security" ||
                              item.outcome === "untested_destructive"
                            ? "bg-amber-500/15 text-amber-300"
                            : "bg-emerald-500/15 text-emerald-300"
                        }`}
                      >
                        {item.outcome === "failed" && <XCircle className="h-3 w-3" />}
                        {item.outcome}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-zinc-300 max-w-md">{item.details}</td>
                    <td className="px-4 py-3 font-mono text-zinc-400">{item.durationMs}ms</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: DESIGN & SCREENSHOTS */}
      {activeTab === "design" && activePage && (
        <div className="space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-zinc-800 bg-surface-900 p-4">
            <select
              value={selectedPageIdx}
              onChange={(e) => setSelectedPageIdx(Number(e.target.value))}
              aria-label="Select inspected page"
              className="rounded-lg border border-zinc-700 bg-surface-850 px-3 py-2 text-xs text-zinc-200 focus:border-indigo-500 focus:outline-none"
            >
              {pages.map((p, idx) => (
                <option key={p.id} value={idx}>
                  {p.path} — {p.title || "Untitled"}
                </option>
              ))}
            </select>

            <div className="inline-flex rounded-lg border border-zinc-700 bg-surface-950 p-1">
              <button
                type="button"
                onClick={() => setViewportMode("desktop")}
                className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition ${
                  viewportMode === "desktop" ? "bg-indigo-600 text-white" : "text-zinc-400"
                }`}
              >
                <Monitor className="h-3.5 w-3.5" />
                Desktop (1440px)
              </button>
              <button
                type="button"
                onClick={() => setViewportMode("mobile")}
                className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition ${
                  viewportMode === "mobile" ? "bg-indigo-600 text-white" : "text-zinc-400"
                }`}
              >
                <Smartphone className="h-3.5 w-3.5" />
                Mobile (390px)
              </button>
            </div>
          </div>

          <div className="grid gap-5 lg:grid-cols-2">
            {/* Colors & Typography */}
            <div className="space-y-4">
              <div className="rounded-xl border border-zinc-800 bg-surface-900 p-5">
                <h4 className="text-sm font-semibold text-zinc-100 mb-3">Extracted Color Palette</h4>
                <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
                  {activePage.colors.slice(0, 12).map((c, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-2.5 rounded-lg border border-zinc-800 bg-surface-950 p-2"
                    >
                      <span
                        className="h-6 w-6 shrink-0 rounded border border-zinc-700"
                        style={{ backgroundColor: c.hex }}
                      />
                      <div className="min-w-0">
                        <div className="truncate font-mono text-xs text-zinc-200">{c.hex}</div>
                        <div className="text-[10px] text-zinc-500">
                          {c.usage} ({c.count}x)
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-xl border border-zinc-800 bg-surface-900 p-5">
                <h4 className="text-sm font-semibold text-zinc-100 mb-3">Computed Typography</h4>
                <div className="space-y-2 text-xs">
                  {activePage.typography.map((t, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between rounded-lg border border-zinc-800 bg-surface-950 px-3 py-2"
                    >
                      <span className="font-mono text-indigo-300">&lt;{t.sampleTag}&gt;</span>
                      <span className="truncate max-w-[200px] text-zinc-300">{t.fontFamily}</span>
                      <span className="font-mono text-zinc-400">
                        {t.fontSize} / w{t.fontWeight}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Screenshot Viewer */}
            <div className="rounded-xl border border-zinc-800 bg-surface-900 p-5">
              <h4 className="text-sm font-semibold text-zinc-100 mb-3">
                Full-Page Screenshot ({viewportMode})
              </h4>
              <div className="max-h-[520px] overflow-y-auto rounded-lg border border-zinc-800 bg-surface-950 p-2">
                {viewportMode === "desktop" && activePage.desktopScreenshotPath ? (
                  <img
                    src={`/api/screenshots/${activePage.desktopScreenshotPath}`}
                    alt={`Desktop screenshot of ${activePage.path}`}
                    className="w-full rounded"
                  />
                ) : viewportMode === "mobile" && activePage.mobileScreenshotPath ? (
                  <img
                    src={`/api/screenshots/${activePage.mobileScreenshotPath}`}
                    alt={`Mobile screenshot of ${activePage.path}`}
                    className="mx-auto max-w-[360px] rounded"
                  />
                ) : (
                  <div className="py-16 text-center text-xs text-zinc-500">
                    No screenshot captured for this viewport.
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: MASTER PROMPT */}
      {activeTab === "prompt" && (
        <MasterPromptPanel
          scanId={scan.id}
          domain={scan.domain}
          prompts={prompts}
          onPromptCreated={onPromptCreated}
        />
      )}
    </div>
  );
}
