import React, { useState, useEffect } from 'react';
import { MotivationalReminder } from '../types';
import { MOTIVATIONAL_QUOTES } from '../data/initialData';
import {
  Bell,
  Clock,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  Plus,
  Trash2,
  Check,
  Quote,
  Flame,
  Volume2,
} from 'lucide-react';

interface RemindersAndMotivationProps {
  reminders: MotivationalReminder[];
  onAddReminder: (reminder: Omit<MotivationalReminder, 'id'>) => void;
  onToggleReminder: (reminderId: string) => void;
  onDeleteReminder: (reminderId: string) => void;
  totalMasteryAvg: number;
  streakDays: number;
}

export const RemindersAndMotivation: React.FC<RemindersAndMotivationProps> = ({
  reminders,
  onAddReminder,
  onToggleReminder,
  onDeleteReminder,
  totalMasteryAvg,
  streakDays,
}) => {
  // Quote state
  const [currentQuoteIndex, setCurrentQuoteIndex] = useState(0);

  // Custom reminder modal/form state
  const [isAddingReminder, setIsAddingReminder] = useState(false);
  const [reminderTitle, setReminderTitle] = useState('');
  const [reminderMessage, setReminderMessage] = useState('');
  const [reminderTime, setReminderTime] = useState('09:00');
  const [reminderType, setReminderType] = useState<MotivationalReminder['type']>('nudge');

  // Study timer (Pomodoro / Focus sprint)
  const [timerDuration, setTimerDuration] = useState(25 * 60); // 25 mins
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [timerMode, setTimerMode] = useState<'focus' | 'break'>('focus');

  // Notification API permission status
  const [notifPermission, setNotifPermission] = useState<NotificationPermission>(
    typeof window !== 'undefined' && 'Notification' in window ? Notification.permission : 'default'
  );

  // Web Audio chime player
  const playChime = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
      osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.3); // A5
      gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 1.2);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 1.2);
    } catch {
      // AudioContext fallback
    }
  };

  // Timer interval effect
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isTimerRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && isTimerRunning) {
      setIsTimerRunning(false);
      playChime();
      if (timerMode === 'focus') {
        setTimerMode('break');
        setTimeLeft(5 * 60);
      } else {
        setTimerMode('focus');
        setTimeLeft(25 * 60);
      }
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTimerRunning, timeLeft, timerMode]);

  // Request browser notification
  const handleRequestNotification = async () => {
    if ('Notification' in window) {
      const perm = await Notification.requestPermission();
      setNotifPermission(perm);
      if (perm === 'granted') {
        new Notification('RecallCurve Reminders Enabled', {
          body: 'You will receive your custom spaced repetition study prompts.',
          icon: '/favicon.ico',
        });
      }
    }
  };

  const handleCreateReminder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reminderTitle.trim()) return;

    onAddReminder({
      title: reminderTitle.trim(),
      message: reminderMessage.trim() || 'Spaced review milestone is waiting for you.',
      timeOfDay: reminderTime,
      enabled: true,
      frequency: 'daily',
      type: reminderType,
    });

    setReminderTitle('');
    setReminderMessage('');
    setIsAddingReminder(false);
  };

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const activeQuote = MOTIVATIONAL_QUOTES[currentQuoteIndex];

  return (
    <div className="space-y-6">
      {/* Motivational Banner / Quote Card */}
      <div className="bg-gradient-to-br from-indigo-900 to-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-sm relative overflow-hidden">
        <div className="relative z-10 max-w-2xl space-y-3">
          <div className="flex items-center gap-2 text-indigo-300 text-xs font-semibold uppercase tracking-wider">
            <Quote className="w-4 h-4" />
            <span>Science of Retention & Habit</span>
          </div>

          <blockquote className="text-base sm:text-lg font-medium text-slate-100 leading-relaxed italic">
            "{activeQuote.quote}"
          </blockquote>

          <div className="flex items-center justify-between pt-2 text-xs text-indigo-200">
            <div>
              <span className="font-semibold text-white">{activeQuote.author}</span>
              <span className="text-indigo-300/70 ml-1.5">· {activeQuote.role}</span>
            </div>

            <button
              onClick={() => setCurrentQuoteIndex((prev) => (prev + 1) % MOTIVATIONAL_QUOTES.length)}
              className="text-xs text-indigo-300 hover:text-white transition-colors flex items-center gap-1 font-medium underline-offset-4 hover:underline"
            >
              <Sparkles className="w-3.5 h-3.5" /> Next Mantra
            </button>
          </div>
        </div>
      </div>

      {/* Grid: Study Focus Timer & Custom Reminders */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (5 cols): Study Sprint Timer */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm flex flex-col justify-between space-y-6">
          <div>
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                  Spaced Study Sprint
                </h3>
              </div>
              <span
                className={`text-[11px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                  timerMode === 'focus'
                    ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400'
                    : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400'
                }`}
              >
                {timerMode === 'focus' ? 'Deep Recall Focus' : 'Memory Rest & Consolidate'}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Short, high-intensity active retrieval intervals prevent cognitive fatigue.
            </p>
          </div>

          {/* Big Digital Display */}
          <div className="text-center py-4">
            <div className="text-5xl sm:text-6xl font-mono font-bold tracking-tight text-slate-900 dark:text-slate-100 tabular-nums">
              {formatTimer(timeLeft)}
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400 mt-2">
              {isTimerRunning ? 'Sprint in progress... stay focused on retrieval' : 'Ready to start'}
            </div>
          </div>

          {/* Quick presets */}
          <div className="flex items-center justify-center gap-2 text-xs">
            <button
              onClick={() => {
                setIsTimerRunning(false);
                setTimerMode('focus');
                setTimerDuration(15 * 60);
                setTimeLeft(15 * 60);
              }}
              className="px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-mono transition-colors"
            >
              15m Quick
            </button>
            <button
              onClick={() => {
                setIsTimerRunning(false);
                setTimerMode('focus');
                setTimerDuration(25 * 60);
                setTimeLeft(25 * 60);
              }}
              className="px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-mono transition-colors"
            >
              25m Standard
            </button>
            <button
              onClick={() => {
                setIsTimerRunning(false);
                setTimerMode('focus');
                setTimerDuration(50 * 60);
                setTimeLeft(50 * 60);
              }}
              className="px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-mono transition-colors"
            >
              50m Mastery
            </button>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-3 pt-2">
            <button
              onClick={() => setIsTimerRunning((prev) => !prev)}
              className={`px-5 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors shadow-xs ${
                isTimerRunning
                  ? 'bg-amber-600 hover:bg-amber-700 text-white'
                  : 'bg-indigo-600 hover:bg-indigo-700 text-white'
              }`}
            >
              {isTimerRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              {isTimerRunning ? 'Pause Sprint' : 'Start Focus Sprint'}
            </button>

            <button
              onClick={() => {
                setIsTimerRunning(false);
                setTimeLeft(timerDuration);
              }}
              className="p-2.5 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors"
              title="Reset timer"
              aria-label="Reset study timer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Right Column (7 cols): Custom Motivation Reminders */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                  Custom Motivational Reminders
                </h3>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Keep consistent spaced review habits throughout the day.
              </p>
            </div>

            <div className="flex items-center gap-2">
              {notifPermission !== 'granted' && (
                <button
                  onClick={handleRequestNotification}
                  className="px-2.5 py-1.5 text-xs text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 rounded-lg transition-colors font-medium flex items-center gap-1"
                >
                  <Bell className="w-3.5 h-3.5" />
                  Enable Push
                </button>
              )}

              <button
                onClick={() => setIsAddingReminder(true)}
                className="px-3 py-1.5 text-xs font-medium text-white bg-slate-900 dark:bg-indigo-600 hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Reminder
              </button>
            </div>
          </div>

          {/* Add Reminder Modal / Form Inline */}
          {isAddingReminder && (
            <form onSubmit={handleCreateReminder} className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3 animate-in fade-in">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-800 dark:text-slate-200">
                <span>Create Custom Reminder</span>
                <button
                  type="button"
                  onClick={() => setIsAddingReminder(false)}
                  className="text-slate-400 hover:text-slate-600 text-xs font-normal"
                >
                  Cancel
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Reminder Title
                  </label>
                  <input
                    type="text"
                    required
                    value={reminderTitle}
                    onChange={(e) => setReminderTitle(e.target.value)}
                    placeholder="e.g. Morning 10-Minute Retrieval Drill"
                    className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Scheduled Time (24h)
                  </label>
                  <input
                    type="time"
                    required
                    value={reminderTime}
                    onChange={(e) => setReminderTime(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Motivational Message
                </label>
                <input
                  type="text"
                  value={reminderMessage}
                  onChange={(e) => setReminderMessage(e.target.value)}
                  placeholder="e.g. 5 minutes today saves 2 hours of relearning next week."
                  className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddingReminder(false)}
                  className="px-3 py-1 text-xs text-slate-600 dark:text-slate-400 hover:bg-slate-200 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors"
                >
                  Save Reminder
                </button>
              </div>
            </form>
          )}

          {/* Reminders List */}
          <div className="space-y-3">
            {reminders.map((rem) => (
              <div
                key={rem.id}
                className={`p-3.5 rounded-xl border transition-all flex items-start justify-between gap-3 ${
                  rem.enabled
                    ? 'bg-slate-50/70 dark:bg-slate-800/40 border-slate-200/80 dark:border-slate-800'
                    : 'bg-slate-50/30 dark:bg-slate-800/20 border-slate-200/40 dark:border-slate-800/40 opacity-60'
                }`}
              >
                <div className="space-y-1 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-indigo-600 dark:text-indigo-400">
                      {rem.timeOfDay}
                    </span>
                    <span className="text-slate-300 dark:text-slate-700">·</span>
                    <span className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                      {rem.title}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                    {rem.message}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0 pt-0.5">
                  <button
                    type="button"
                    onClick={() => onToggleReminder(rem.id)}
                    className={`w-9 h-5 flex items-center rounded-full p-1 transition-colors duration-200 ${
                      rem.enabled ? 'bg-emerald-600' : 'bg-slate-300 dark:bg-slate-700'
                    }`}
                    aria-label={`Toggle reminder ${rem.title}`}
                  >
                    <div
                      className={`bg-white w-3 h-3 rounded-full shadow-md transform transition-transform duration-200 ${
                        rem.enabled ? 'translate-x-4' : 'translate-x-0'
                      }`}
                    />
                  </button>

                  <button
                    type="button"
                    onClick={() => onDeleteReminder(rem.id)}
                    className="p-1 text-slate-400 hover:text-rose-500 rounded transition-colors"
                    aria-label={`Delete reminder ${rem.title}`}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
