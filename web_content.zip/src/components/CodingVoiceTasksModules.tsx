import React, { useState } from 'react';
import {
  Code2,
  Sparkles,
  Copy,
  Check,
  Volume2,
  Download,
  CheckSquare,
  Plus,
  Trash2,
  Bell,
  AlertCircle,
  ShieldAlert,
} from 'lucide-react';
import type {
  SupportedLanguage,
  TaskCategory,
  TaskPriority,
  UserTask,
  VoiceProfileId,
} from '../types';
import { VOICE_PROFILES, validateTaskInput } from '../utils/rajuEngine';

interface CodingLabProps {
  onEarnXp: (amount: number) => void;
  onRecordTokens: (tokens: number) => void;
}

export const CodingLabModule: React.FC<CodingLabProps> = ({ onEarnXp, onRecordTokens }) => {
  const [taskType, setTaskType] = useState<'generate' | 'explain' | 'debug' | 'architecture' | 'review'>('generate');
  const [progLang, setProgLang] = useState('TypeScript');
  const [instruction, setInstruction] = useState(
    'Build a clean React custom hook useDebounce with TypeScript generics and cancellation support.'
  );
  const [sourceCode, setSourceCode] = useState('');
  const [output, setOutput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleRunCodingAssistant = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!instruction.trim() && !sourceCode.trim()) {
      setErrorMsg('Please provide a coding prompt or paste source code.');
      return;
    }
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/gemini/coding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          taskType,
          language: progLang,
          instruction,
          code: sourceCode,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Coding Lab request failed.');
      setOutput(data.text || '');
      if (data.usage?.totalTokens) onRecordTokens(data.usage.totalTokens);
      onEarnXp(25);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Error in Coding Lab.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Coding Lab & Software Architect</h2>
          <p className="text-sm text-slate-400 mt-1">
            Generate, debug, explain, and review code across Web, Python, and Android with <span className="font-mono text-cyan-300">gemini-4-hydrogen</span>.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs text-emerald-300 bg-emerald-950/40 border border-emerald-500/30 px-3 py-1.5 rounded-xl">
          <ShieldAlert className="w-4 h-4 shrink-0" />
          <span>Zero Untrusted Server Execution Enforced</span>
        </div>
      </div>

      {errorMsg && (
        <div role="alert" className="p-4 rounded-xl bg-rose-950/60 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <form onSubmit={handleRunCodingAssistant} className="lg:col-span-5 p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="coding-mode" className="block text-xs font-medium text-slate-300 mb-1.5">
                Operation Mode
              </label>
              <select
                id="coding-mode"
                value={taskType}
                onChange={(e) => setTaskType(e.target.value as typeof taskType)}
                className="w-full px-3 py-2 rounded-xl bg-[#060919] border border-slate-800 text-xs text-white"
              >
                <option value="generate">Generate Code</option>
                <option value="debug">Debug Errors</option>
                <option value="explain">Explain Logic</option>
                <option value="architecture">Project Architecture</option>
                <option value="review">Security Code Review</option>
              </select>
            </div>

            <div>
              <label htmlFor="coding-lang" className="block text-xs font-medium text-slate-300 mb-1.5">
                Language / Stack
              </label>
              <select
                id="coding-lang"
                value={progLang}
                onChange={(e) => setProgLang(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#060919] border border-slate-800 text-xs text-white"
              >
                <option value="TypeScript">TypeScript / React</option>
                <option value="Python">Python</option>
                <option value="JavaScript">JavaScript (ES2024)</option>
                <option value="Kotlin">Kotlin (Android)</option>
                <option value="HTML/CSS">HTML5 & Tailwind CSS</option>
                <option value="SQL">SQL / Database</option>
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="coding-instruction" className="block text-xs font-medium text-slate-300 mb-1.5">
              Architecture / Coding Prompt
            </label>
            <textarea
              id="coding-instruction"
              rows={3}
              value={instruction}
              onChange={(e) => setInstruction(e.target.value)}
              placeholder="Describe what you want to build, debug, or architect..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#060919] border border-slate-800 text-xs text-white focus:outline-none focus:border-cyan-400"
            />
          </div>

          <div>
            <label htmlFor="coding-source" className="block text-xs font-medium text-slate-300 mb-1.5">
              Source Code Snippet (Optional for Debug / Review)
            </label>
            <textarea
              id="coding-source"
              rows={5}
              value={sourceCode}
              onChange={(e) => setSourceCode(e.target.value)}
              placeholder="Paste code here to debug, optimize, or audit..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#060919] border border-slate-800 font-mono text-xs text-cyan-200 focus:outline-none focus:border-cyan-400"
            />
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-semibold text-sm flex items-center justify-center gap-2 transition disabled:opacity-50"
          >
            <Code2 className="w-4 h-4" />
            {isLoading ? 'Running Gemini 4 Hydrogen Architect...' : 'Run Coding Lab'}
          </button>
        </form>

        <div className="lg:col-span-7 p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 flex flex-col min-h-[380px]">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-base font-bold text-white">Engineering Output</h3>
            {output && (
              <button
                type="button"
                onClick={handleCopy}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-cyan-300 flex items-center gap-1.5"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied' : 'Copy Output'}
              </button>
            )}
          </div>

          {isLoading ? (
            <div className="flex-1 flex flex-col items-center justify-center py-12 space-y-3">
              <Sparkles className="w-8 h-8 text-cyan-400 animate-spin" />
              <p className="text-sm text-slate-300">Synthesizing clean, modular code & security review...</p>
            </div>
          ) : output ? (
            <div className="flex-1 overflow-y-auto p-4 rounded-xl bg-[#060919]/90 border border-slate-800 font-mono text-xs text-slate-200 whitespace-pre-wrap leading-relaxed">
              {output}
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center py-12 text-slate-500">
              <Code2 className="w-10 h-10 mb-2 text-slate-600" />
              <p className="text-sm text-slate-300">Ready to build, debug, or review</p>
              <p className="text-xs text-slate-500 mt-1">
                Click "Run Coding Lab" to generate production code and architectural documentation.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

interface VoiceStudioProps {
  selectedVoice: VoiceProfileId;
  onVoiceChange: (v: VoiceProfileId) => void;
  language: SupportedLanguage;
  onEarnXp: (amount: number) => void;
}

export const VoiceStudioModule: React.FC<VoiceStudioProps> = ({
  selectedVoice,
  onVoiceChange,
  language,
  onEarnXp,
}) => {
  const [scriptText, setScriptText] = useState(
    'Welcome to RAJU AI Voice Studio! Talk, Learn, Create, and Explore with high-definition speech synthesis.'
  );
  const [speed, setSpeed] = useState<'slow' | 'normal' | 'fast'>('normal');
  const [customStyle, setCustomStyle] = useState('Expressive, clear studio narration');
  const [useExpressiveModel, setUseExpressiveModel] = useState(false);
  const [audioBase64, setAudioBase64] = useState<string>('');
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSynthesize = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    if (!scriptText.trim()) {
      setErrorMsg('Please enter text to synthesize.');
      return;
    }
    setIsSynthesizing(true);
    try {
      const res = await fetch('/api/gemini/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: scriptText,
          voiceProfile: selectedVoice,
          speed,
          customStyle,
          useExpressiveModel,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Speech generation failed.');
      }
      setAudioBase64(data.audioBase64 || '');
      onEarnXp(15);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'TTS generation failed.');
    } finally {
      setIsSynthesizing(false);
    }
  };

  const handleDownloadWav = () => {
    if (!audioBase64) return;
    const a = document.createElement('a');
    a.href = `data:audio/wav;base64,${audioBase64}`;
    a.download = `raju_ai_voice_${selectedVoice.toLowerCase().replace(/\s+/g, '_')}.wav`;
    a.click();
  };

  return (
    <div className="space-y-6">
      <div className="pb-4 border-b border-slate-800/80">
        <h2 className="text-2xl font-bold text-white tracking-tight">Voice Studio (Text-to-Speech & Audio Export)</h2>
        <p className="text-sm text-slate-400 mt-1">
          Synthesize studio-grade WAV audio with <span className="font-mono text-cyan-300">gemini-3.8-flash-lite-tts</span> and <span className="font-mono text-cyan-300">gemini-3.8-flash-tts</span>.
        </p>
      </div>

      {errorMsg && (
        <div role="alert" className="p-4 rounded-xl bg-rose-950/60 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <form onSubmit={handleSynthesize} className="lg:col-span-7 p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
          <div>
            <label htmlFor="tts-script" className="block text-xs font-medium text-slate-300 mb-1.5">
              Speech Script ({language} or Multilingual)
            </label>
            <textarea
              id="tts-script"
              rows={4}
              value={scriptText}
              onChange={(e) => setScriptText(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#060919] border border-slate-800 text-sm text-white focus:outline-none focus:border-cyan-400"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="tts-speed" className="block text-xs font-medium text-slate-300 mb-1.5">
                Speaking Speed
              </label>
              <select
                id="tts-speed"
                value={speed}
                onChange={(e) => setSpeed(e.target.value as typeof speed)}
                className="w-full px-3.5 py-2 rounded-xl bg-[#060919] border border-slate-800 text-xs text-white"
              >
                <option value="slow">Slow (Language Learning)</option>
                <option value="normal">Normal (Natural Pace)</option>
                <option value="fast">Fast (Energetic Pace)</option>
              </select>
            </div>

            <div>
              <label htmlFor="tts-style" className="block text-xs font-medium text-slate-300 mb-1.5">
                Speaking Style Direction
              </label>
              <input
                id="tts-style"
                type="text"
                value={customStyle}
                onChange={(e) => setCustomStyle(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-[#060919] border border-slate-800 text-xs text-white"
              />
            </div>
          </div>

          <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
            <input
              type="checkbox"
              checked={useExpressiveModel}
              onChange={(e) => setUseExpressiveModel(e.target.checked)}
              className="rounded border-slate-700 bg-slate-900 text-cyan-500"
            />
            <span>Use flagship expressive Voice Design model (gemini-3.8-flash-tts)</span>
          </label>

          <button
            type="submit"
            disabled={isSynthesizing}
            className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-semibold text-sm flex items-center justify-center gap-2 transition disabled:opacity-50"
          >
            <Volume2 className="w-4 h-4" />
            {isSynthesizing ? 'Synthesizing Studio WAV Audio...' : 'Generate Speech Audio'}
          </button>

          {audioBase64 && (
            <div className="p-4 rounded-xl bg-[#060919] border border-cyan-500/40 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-cyan-300">
                  Generated Audio ({selectedVoice} · 24kHz WAV)
                </span>
                <button
                  type="button"
                  onClick={handleDownloadWav}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold"
                >
                  <Download className="w-3.5 h-3.5" />
                  Export WAV
                </button>
              </div>
              <audio controls src={`data:audio/wav;base64,${audioBase64}`} className="w-full" />
            </div>
          )}
        </form>

        <div className="lg:col-span-5 p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-3">
          <h3 className="text-base font-bold text-white">Select Voice Persona</h3>
          {VOICE_PROFILES.map((vp) => (
            <button
              key={vp.id}
              type="button"
              onClick={() => onVoiceChange(vp.id)}
              className={`w-full p-3.5 rounded-xl border text-left transition ${
                selectedVoice === vp.id
                  ? 'bg-indigo-950/70 border-cyan-400'
                  : 'bg-[#060919]/80 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-white">{vp.name}</span>
                <span className="text-xs font-mono text-cyan-300">{vp.geminiVoice}</span>
              </div>
              <p className="text-xs text-slate-400 mt-1">{vp.styleDescription}</p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

interface TaskManagerProps {
  tasks: UserTask[];
  onAddTask: (task: { title: string; category: TaskCategory; priority: TaskPriority; dueDate: string }) => Promise<void>;
  onToggleTask: (id: string, completed: boolean) => Promise<void>;
  onDeleteTask: (id: string) => Promise<void>;
}

export const TaskManagerModule: React.FC<TaskManagerProps> = ({
  tasks,
  onAddTask,
  onToggleTask,
  onDeleteTask,
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<TaskCategory>('Study');
  const [priority, setPriority] = useState<TaskPriority>('High');
  const [dueDate, setDueDate] = useState(new Date().toISOString().slice(0, 10));
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'completed'>('all');
  const [notifStatus, setNotifStatus] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    const validation = validateTaskInput({ title, category, priority, dueDate });
    if (!validation.valid || !validation.sanitized) {
      setErrorMsg(validation.error || 'Please enter a valid task title.');
      return;
    }
    await onAddTask(validation.sanitized);
    setTitle('');
  };

  const requestNotificationPermission = async () => {
    if (!('Notification' in window)) {
      setNotifStatus('Notifications are not supported in this browser environment.');
      return;
    }
    const perm = await Notification.requestPermission();
    setNotifStatus(
      perm === 'granted'
        ? 'Study reminders & task notifications enabled!'
        : 'Notification permission was not granted.'
    );
  };

  const filteredTasks = tasks.filter((t) => {
    if (filterStatus === 'pending') return !t.completed;
    if (filterStatus === 'completed') return t.completed;
    return true;
  });

  const completedCount = tasks.filter((t) => t.completed).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight">
            Task Manager & Study Schedule
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Organize daily CUET targets, Japanese JLPT practice, and coding milestones. Completed: <span className="font-mono text-cyan-300 tabular-nums">{completedCount}/{tasks.length}</span>
          </p>
        </div>

        <button
          type="button"
          onClick={requestNotificationPermission}
          className="px-3.5 py-2 rounded-xl bg-[#0B102B] border border-slate-700 hover:border-cyan-400 text-xs font-semibold text-cyan-300 flex items-center gap-2 whitespace-nowrap shrink-0"
        >
          <Bell className="w-3.5 h-3.5" />
          Enable Reminders
        </button>
      </div>

      {notifStatus && (
        <div className="p-3 rounded-xl bg-indigo-950/60 border border-indigo-500/40 text-xs text-indigo-200">
          {notifStatus}
        </div>
      )}

      {errorMsg && (
        <div role="alert" className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <form onSubmit={handleCreateTask} className="lg:col-span-5 p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Plus className="w-4 h-4 text-cyan-400" />
            Create New Task
          </h3>

          <div>
            <label htmlFor="task-title" className="block text-xs font-medium text-slate-300 mb-1.5">
              Task Title
            </label>
            <input
              id="task-title"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Revise Molecular Inheritance & 20 Kanji"
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#060919] border border-slate-800 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="task-category" className="block text-xs font-medium text-slate-300 mb-1.5">
                Category
              </label>
              <select
                id="task-category"
                value={category}
                onChange={(e) => setCategory(e.target.value as TaskCategory)}
                className="w-full px-3 py-2 rounded-xl bg-[#060919] border border-slate-800 text-xs text-white"
              >
                <option value="Study">Study</option>
                <option value="Japanese">Japanese</option>
                <option value="Coding">Coding</option>
                <option value="Research">Research</option>
                <option value="Daily">Daily</option>
              </select>
            </div>

            <div>
              <label htmlFor="task-priority" className="block text-xs font-medium text-slate-300 mb-1.5">
                Priority
              </label>
              <select
                id="task-priority"
                value={priority}
                onChange={(e) => setPriority(e.target.value as TaskPriority)}
                className="w-full px-3 py-2 rounded-xl bg-[#060919] border border-slate-800 text-xs text-white"
              >
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="task-due" className="block text-xs font-medium text-slate-300 mb-1.5">
              Target Date
            </label>
            <input
              id="task-due"
              type="date"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-[#060919] border border-slate-800 text-xs text-white font-mono"
            />
          </div>

          <button
            type="submit"
            className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-semibold text-sm transition"
          >
            Add Task to Schedule
          </button>
        </form>

        <div className="lg:col-span-7 p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">Active Schedule</h3>
            <div className="flex items-center gap-1 p-1 rounded-xl bg-[#060919] border border-slate-800">
              {(['all', 'pending', 'completed'] as const).map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setFilterStatus(st)}
                  className={`px-3 py-1 rounded-lg text-xs font-medium capitalize transition ${
                    filterStatus === st ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2.5">
            {filteredTasks.length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                <CheckSquare className="w-8 h-8 mx-auto mb-2 text-slate-600" />
                <p className="text-sm text-slate-300">No tasks in this view</p>
              </div>
            ) : (
              filteredTasks.map((task) => (
                <div
                  key={task.id}
                  className="flex items-center justify-between p-3.5 rounded-xl bg-[#060919]/85 border border-slate-800/90 hover:border-slate-700 transition gap-3"
                >
                  <label className="flex items-start gap-3 cursor-pointer flex-1">
                    <input
                      type="checkbox"
                      checked={task.completed}
                      onChange={(e) => onToggleTask(task.id, e.target.checked)}
                      aria-label={`Mark "${task.title}" as completed`}
                      className="mt-1 w-4 h-4 rounded border-slate-600 bg-slate-900 text-cyan-500"
                    />
                    <div>
                      <p
                        className={`text-sm font-semibold ${
                          task.completed ? 'line-through text-slate-500' : 'text-white'
                        }`}
                      >
                        {task.title}
                      </p>
                      <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                        <span className="text-cyan-300">{task.category}</span>
                        <span aria-hidden="true">·</span>
                        <span
                          className={
                            task.priority === 'High'
                              ? 'text-rose-300'
                              : task.priority === 'Medium'
                                ? 'text-amber-300'
                                : 'text-emerald-300'
                          }
                        >
                          {task.priority} Priority
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono tabular-nums">Due {task.dueDate}</span>
                      </div>
                    </div>
                  </label>

                  <button
                    type="button"
                    onClick={() => onDeleteTask(task.id)}
                    aria-label={`Delete task ${task.title}`}
                    className="p-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900 text-rose-300 transition shrink-0"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
