import { useEffect, useState } from "react";
import { ClockBoard } from "@/components/clock-board";
import { HolidayBoard } from "@/components/holiday-board";
import { WeatherBoard } from "@/components/weather-board";
import { WeekBoard } from "@/components/week-board";
import { DEFAULT_PLACE, readSavedPlace, type Place } from "@/lib/places";
import { BRASILIA, formatShortDate, isoWeek, weekBounds, zonedIso } from "@/lib/time";

export function AgoraApp() {
  const [now, setNow] = useState<Date | null>(null);
  const [place, setPlace] = useState<Place>(DEFAULT_PLACE);
  const [weekOffset, setWeekOffset] = useState(0);

  useEffect(() => {
    const saved = readSavedPlace();
    if (saved) setPlace(saved);
    const tick = () => setNow(new Date());
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, []);

  const todayIso = now ? zonedIso(now, BRASILIA) : null;
  const week = todayIso ? isoWeek(todayIso) : null;
  const bounds = todayIso ? weekBounds(todayIso) : null;

  return (
    <main className="mx-auto min-h-screen max-w-5xl px-4 py-6 sm:px-6 sm:py-10">
      <header className="border-t-4 border-clay">
        <div className="mt-5 flex items-end justify-between gap-4">
          <div>
            <p className="text-xs font-semibold tracking-widest text-clay uppercase">Edição de hoje</p>
            <h1 className="mt-1 text-6xl leading-none text-ink italic sm:text-7xl">Agora</h1>
            <p className="mt-3 max-w-md text-muted">
              A data, os minutos, o ano, o clima e os feriados do Brasil — com uma cor, um animal e um número só desta semana.
            </p>
          </div>
          <p className="hidden text-right text-sm text-muted sm:block">
            {week ? (
              <>
                Semana {week.week}
                <br />
                <span className="tabular-nums">
                  {bounds ? `${formatShortDate(bounds.start)} – ${formatShortDate(bounds.end)}` : ""}
                </span>
              </>
            ) : (
              "Brasil"
            )}
          </p>
        </div>
      </header>

      <div className="mt-8 grid items-stretch gap-4 lg:grid-cols-5">
        <ClockBoard now={now} />
        <WeekBoard todayIso={todayIso} weekOffset={weekOffset} onShift={(delta) => setWeekOffset((value) => value + delta)} />
      </div>

      <div className="mt-4 grid gap-4">
        <WeatherBoard place={place} onPlace={setPlace} now={now} />
        <HolidayBoard todayIso={todayIso} />
      </div>

      <footer className="mt-8 flex flex-wrap items-center justify-between gap-2 pb-4 text-sm text-muted">
        <p>Relógio no fuso de Brasília.</p>
        <p>A carta da semana é a mesma para todo mundo.</p>
      </footer>
    </main>
  );
}
