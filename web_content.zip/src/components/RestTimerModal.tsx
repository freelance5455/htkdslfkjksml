import React from 'react';
import {
  X,
  Play,
  Pause,
  RotateCcw,
  Plus,
  Minus,
  Volume2,
  VolumeX,
  Smartphone,
  Square,
  Minimize2,
  Bell,
  Sparkles
} from 'lucide-react';
import { useWorkout } from '../context/WorkoutContext';
import { TimerChimeStyle, TimerHapticStyle } from '../types';
import { playTimerFinishSound, triggerTimerZeroHaptic } from '../utils/audio';

const CHIME_OPTIONS: { id: TimerChimeStyle; label: string }[] = [
  { id: 'singing-bowl', label: 'Zen Bell' },
  { id: 'double-pulse', label: 'Double Pulse' },
  { id: 'power-chord', label: 'Power Chord' },
  { id: 'crisptick', label: 'Studio Click' },
  { id: 'silent', label: 'Silent' }
];

const HAPTIC_OPTIONS: { id: TimerHapticStyle; label: string }[] = [
  { id: 'subtle-pulse', label: 'Subtle Pulse' },
  { id: 'double-tap', label: 'Double Tap' },
  { id: 'heartbeat', label: 'Heartbeat' },
  { id: 'off', label: 'Off' }
];

export const RestTimerModal: React.FC = () => {
  const {
    isTimerModalOpen,
    setIsTimerModalOpen,
    isTimerRunning,
    isTimerPaused,
    timerSecondsLeft,
    timerTotalDuration,
    timerJustFinished,
    pauseRestTimer,
    resumeRestTimer,
    resetRestTimer,
    adjustRestTimer,
    stopRestTimer,
    startRestTimer,
    user,
    updateUser
  } = useWorkout();

  const activeChime: TimerChimeStyle = user.timerChimeStyle || 'singing-bowl';
  const activeHaptic: TimerHapticStyle = user.timerHapticStyle || 'subtle-pulse';

  const handleTestZeroCue = () => {
    if (user.soundEnabled && activeChime !== 'silent') {
      playTimerFinishSound(activeChime);
    }
    if (user.vibrationEnabled && activeHaptic !== 'off') {
      triggerTimerZeroHaptic(activeHaptic);
    }
  };

  if (!isTimerModalOpen) {
    if (!timerJustFinished) return null;
    return (
      <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 w-full max-w-sm pointer-events-none animate-in fade-in slide-in-from-top duration-200">
        <div className="pointer-events-auto bg-[#12151c] border border-cyan-400/60 rounded-2xl p-3 shadow-xl shadow-cyan-500/20 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-cyan-500 text-neutral-950 flex items-center justify-center shrink-0">
              <Bell className="w-4 h-4 fill-neutral-950" />
            </div>
            <div className="text-left">
              <div className="text-xs font-extrabold text-white">Rest Complete (0:00)</div>
              <div className="text-[11px] text-cyan-400 font-semibold">
                Ready to start your next set!
              </div>
            </div>
          </div>
          <button
            onClick={() => setIsTimerModalOpen(true)}
            className="px-2.5 py-1 rounded-lg bg-neutral-900 border border-neutral-800 text-[11px] font-semibold text-slate-300 hover:text-white"
          >
            Open
          </button>
        </div>
      </div>
    );
  }

  const radius = 92;
  const circumference = 2 * Math.PI * radius;
  const progressRatio = timerTotalDuration > 0 ? timerSecondsLeft / timerTotalDuration : 0;
  const strokeDashoffset = circumference - progressRatio * circumference;

  const minutes = Math.floor(timerSecondsLeft / 60);
  const seconds = timerSecondsLeft % 60;
  const formattedTime = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

  const presets = [30, 45, 60, 90, 120, 180];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto">
      <div className="w-full max-w-sm bg-[#12151c] border border-cyan-500/25 rounded-3xl p-5 shadow-2xl shadow-cyan-950/50 flex flex-col items-center relative text-center my-auto">
        {/* Top Bar with Sound Toggle and Close */}
        <div className="w-full flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <button
              onClick={() => updateUser({ soundEnabled: !user.soundEnabled })}
              className={`p-2 rounded-xl transition-colors ${
                user.soundEnabled
                  ? 'text-cyan-400 bg-cyan-950/40 border border-cyan-500/30'
                  : 'text-slate-500 bg-neutral-900'
              }`}
              title="Toggle Timer Sound"
            >
              {user.soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
            <button
              onClick={() => updateUser({ vibrationEnabled: !user.vibrationEnabled })}
              className={`p-2 rounded-xl transition-colors ${
                user.vibrationEnabled
                  ? 'text-cyan-400 bg-cyan-950/40 border border-cyan-500/30'
                  : 'text-slate-500 bg-neutral-900'
              }`}
              title="Toggle Vibration"
            >
              <Smartphone className="w-4 h-4" />
            </button>
          </div>

          <h3 className="text-sm font-semibold tracking-wide text-slate-300 uppercase">
            Rest Interval
          </h3>

          <button
            onClick={() => setIsTimerModalOpen(false)}
            className="p-2 rounded-xl text-slate-400 hover:text-white bg-neutral-900 hover:bg-neutral-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Circular Countdown Ring */}
        <div className="relative w-56 h-56 my-1 flex items-center justify-center">
          {/* Ambient Glow */}
          <div className="absolute inset-4 rounded-full bg-cyan-500/10 blur-xl pointer-events-none" />

          <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 220 220">
            {/* Background track circle */}
            <circle
              cx="110"
              cy="110"
              r={radius}
              stroke="currentColor"
              strokeWidth="10"
              fill="transparent"
              className="text-neutral-800/80"
            />
            {/* Animated progress circle */}
            <circle
              cx="110"
              cy="110"
              r={radius}
              stroke="url(#cyanGradient)"
              strokeWidth="10"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              fill="transparent"
              className="transition-all duration-500 ease-out"
            />
            <defs>
              <linearGradient id="cyanGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#22d3ee" />
                <stop offset="100%" stopColor="#0891b2" />
              </linearGradient>
            </defs>
          </svg>

          {/* Time Center Text */}
          <div className="absolute flex flex-col items-center justify-center">
            <span className="text-4xl font-extrabold tracking-tight text-white font-mono drop-shadow-md">
              {formattedTime}
            </span>
            <span className="text-[11px] font-bold text-cyan-400 mt-1 uppercase tracking-widest">
              {timerJustFinished
                ? 'START NEXT SET!'
                : isTimerPaused
                ? 'PAUSED'
                : isTimerRunning
                ? 'RECOVERING'
                : 'READY'}
            </span>
          </div>
        </div>

        {/* Adjust Buttons (-15s / +15s) */}
        <div className="flex items-center gap-3 my-2">
          <button
            onClick={() => adjustRestTimer(-15)}
            className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium bg-neutral-900 hover:bg-neutral-800 text-slate-300 border border-neutral-800 rounded-xl active:scale-95 transition-all"
          >
            <Minus className="w-3.5 h-3.5" />
            15s
          </button>
          <button
            onClick={() => adjustRestTimer(15)}
            className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium bg-neutral-900 hover:bg-neutral-800 text-slate-300 border border-neutral-800 rounded-xl active:scale-95 transition-all"
          >
            <Plus className="w-3.5 h-3.5" />
            15s
          </button>
        </div>

        {/* Primary Controls (Reset, Play/Pause, Stop) */}
        <div className="flex items-center justify-center gap-4 my-1.5 w-full">
          <button
            onClick={resetRestTimer}
            className="w-11 h-11 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-center text-slate-400 hover:text-white active:scale-95 transition-all"
            title="Reset Timer"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {isTimerRunning && !isTimerPaused ? (
            <button
              onClick={pauseRestTimer}
              className="w-14 h-14 rounded-2xl bg-cyan-500 text-neutral-950 flex items-center justify-center shadow-lg shadow-cyan-500/30 hover:bg-cyan-400 active:scale-95 transition-all"
              title="Pause"
            >
              <Pause className="w-6 h-6 fill-neutral-950" />
            </button>
          ) : (
            <button
              onClick={resumeRestTimer}
              className="w-14 h-14 rounded-2xl bg-cyan-500 text-neutral-950 flex items-center justify-center shadow-lg shadow-cyan-500/30 hover:bg-cyan-400 active:scale-95 transition-all"
              title="Start / Resume"
            >
              <Play className="w-6 h-6 fill-neutral-950 translate-x-0.5" />
            </button>
          )}

          <button
            onClick={stopRestTimer}
            className="w-11 h-11 rounded-2xl bg-red-950/40 border border-red-500/30 hover:border-red-500/60 flex items-center justify-center text-red-400 hover:text-red-300 active:scale-95 transition-all group"
            title="Stop Timer"
          >
            <Square className="w-4 h-4 fill-red-400/40 group-hover:fill-red-400" />
          </button>
        </div>

        {/* Action Row: Stop Rest vs Minimize */}
        <div className="grid grid-cols-2 gap-2 w-full mt-2.5">
          <button
            onClick={stopRestTimer}
            className="py-2 px-3 bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 hover:border-red-500/50 text-red-400 hover:text-red-300 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 active:scale-95"
          >
            <Square className="w-3.5 h-3.5 fill-red-400/30" />
            <span>Stop & Skip Rest</span>
          </button>

          <button
            onClick={() => setIsTimerModalOpen(false)}
            className="py-2 px-3 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-slate-300 hover:text-white text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-1.5 active:scale-95"
            title="Keep timer running in background"
          >
            <Minimize2 className="w-3.5 h-3.5" />
            <span>Minimize</span>
          </button>
        </div>

        {/* Quick Presets Row */}
        <div className="w-full mt-3 pt-3 border-t border-neutral-800/80">
          <div className="text-[11px] font-medium text-slate-400 mb-1.5">Preset Durations</div>
          <div className="grid grid-cols-6 gap-1.5">
            {presets.map((sec) => (
              <button
                key={sec}
                onClick={() => startRestTimer(sec)}
                className={`py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                  timerTotalDuration === sec
                    ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500/50 shadow-sm'
                    : 'bg-neutral-900 text-slate-300 border-neutral-800 hover:bg-neutral-800'
                }`}
              >
                {sec >= 60 ? `${sec / 60}m` : `${sec}s`}
              </button>
            ))}
          </div>
        </div>

        {/* Hands-Free Zero-Second Audio Chime & Subtle Haptic Feedback Settings */}
        <div className="w-full mt-3 pt-3 border-t border-neutral-800/80 text-left space-y-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-300 uppercase tracking-wider">
              <Bell className="w-3.5 h-3.5 text-cyan-400" />
              <span>0:00 Hands-Free Alert</span>
            </div>
            <button
              type="button"
              onClick={handleTestZeroCue}
              className="px-2.5 py-1 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-[10px] font-bold text-cyan-400 flex items-center gap-1 active:scale-95 transition-all"
              title="Preview audio chime & subtle haptic vibration"
            >
              <Sparkles className="w-3 h-3" />
              <span>Test Cue</span>
            </button>
          </div>

          {/* Audio Chime Selector */}
          <div>
            <div className="text-[10px] text-slate-400 mb-1 flex items-center justify-between">
              <span>Audio Chime When Rest Hits 0:00</span>
              <span className="text-cyan-400 font-semibold">
                {user.soundEnabled ? 'Enabled' : 'Muted'}
              </span>
            </div>
            <div className="flex flex-wrap gap-1">
              {CHIME_OPTIONS.map((opt) => {
                const isSelected = activeChime === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => {
                      updateUser({
                        timerChimeStyle: opt.id,
                        soundEnabled: opt.id !== 'silent'
                      });
                      if (opt.id !== 'silent') {
                        playTimerFinishSound(opt.id);
                      }
                    }}
                    className={`px-2 py-1 rounded-lg text-[10px] font-semibold border transition-all ${
                      isSelected
                        ? 'bg-cyan-500 text-neutral-950 font-bold border-cyan-400'
                        : 'bg-neutral-900 text-slate-300 border-neutral-800 hover:border-cyan-500/40'
                    }`}
                  >
                    {opt.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Subtle Haptic Pattern Selector */}
          <div>
            <div className="text-[10px] text-slate-400 mb-1 flex items-center justify-between">
              <span>Haptic Pulse at 0:00</span>
              <span className="text-cyan-400 font-semibold">
                {user.vibrationEnabled ? 'Active' : 'Off'}
              </span>
            </div>
            <div className="grid grid-cols-4 gap-1">
              {HAPTIC_OPTIONS.map((opt) => {
                const isSelected = activeHaptic === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => {
                      updateUser({
                        timerHapticStyle: opt.id,
                        vibrationEnabled: opt.id !== 'off'
                      });
                      if (opt.id !== 'off') {
                        triggerTimerZeroHaptic(opt.id);
                      }
                    }}
                    className={`py-1 px-1.5 rounded-lg text-[10px] font-semibold border transition-all text-center truncate ${
                      isSelected
                        ? 'bg-cyan-500 text-neutral-950 font-bold border-cyan-400'
                        : 'bg-neutral-900 text-slate-300 border-neutral-800 hover:border-cyan-500/40'
                    }`}
                  >
                    {opt.label}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
