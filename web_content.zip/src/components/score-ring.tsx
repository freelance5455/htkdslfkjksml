import { formatPsl } from "@/lib/psl";
import { cn } from "@/lib/utils";

type Props = {
  value: number;
  size?: "sm" | "md" | "lg";
  caption?: string;
  className?: string;
};

const SIZE = {
  sm: { px: 96, stroke: 7, num: "text-xl", cap: "text-2xs" },
  md: { px: 168, stroke: 9, num: "text-3xl", cap: "text-xs" },
  lg: { px: 200, stroke: 10, num: "text-4xl", cap: "text-xs" },
} as const;

export function ScoreRing({ value, size = "md", caption = "PSL", className }: Props) {
  const cfg = SIZE[size];
  const r = (cfg.px - cfg.stroke) / 2 - 4;
  const c = 2 * Math.PI * r;
  const t = Math.max(0, Math.min(10, value)) / 10;
  const offset = c * (1 - t);

  return (
    <div
      className={cn("relative grid place-items-center", className)}
      style={{ width: cfg.px, height: cfg.px }}
    >
      <svg width={cfg.px} height={cfg.px} viewBox={`0 0 ${cfg.px} ${cfg.px}`} className="score-ring">
        <circle
          cx={cfg.px / 2}
          cy={cfg.px / 2}
          r={r}
          fill="none"
          stroke="var(--color-surface-2)"
          strokeWidth={cfg.stroke}
        />
        <circle
          className="score-ring-progress"
          cx={cfg.px / 2}
          cy={cfg.px / 2}
          r={r}
          fill="none"
          stroke="var(--color-accent)"
          strokeWidth={cfg.stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center">
        <div className="text-center">
          <div className={cn("font-display font-bold tabular-nums leading-none text-fg", cfg.num)}>
            {formatPsl(value)}
          </div>
          <div className={cn("mt-1 tracking-label uppercase text-muted", cfg.cap)}>{caption}</div>
        </div>
      </div>
    </div>
  );
}
