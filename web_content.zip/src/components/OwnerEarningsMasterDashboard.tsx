/**
 * JUHNKRIX MUSIKA - Owner Earnings Master Dashboard Component
 * 
 * Visually displays the sovereign rule:
 * - Prohibits visitor/user earnings entirely ($0 for visitors).
 * - Only Prophet JUHNKRIX SYNVAGORD earns $1 (₦1,500 NGN) from every 5 actions:
 *   5 users, 5 visitors, 5 plays, 5 comments, 5 downloads, 5 shares,
 *   5 likes, 5 replies, 5 views, 5 membership registrations, and 5 WhatsApp chats.
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  ShieldCheck, 
  DollarSign, 
  Zap, 
  Users, 
  Eye, 
  Play, 
  MessageSquare, 
  Download, 
  Share2, 
  Heart, 
  CornerDownRight, 
  UserPlus, 
  MessageCircle, 
  Lock, 
  CheckCircle2, 
  TrendingUp,
  Building2,
  RefreshCw
} from 'lucide-react';
import { ownerEarningsEngine, OwnerMasterWalletState } from '../lib/ownerEarningsEngine';
import { CompilerAppView } from './CompilerAppView';

export const OwnerEarningsMasterDashboard: React.FC = () => {
  const [state, setState] = useState<OwnerMasterWalletState>(() => ownerEarningsEngine.getState());
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = ownerEarningsEngine.subscribe(() => {
      setState(ownerEarningsEngine.getState());
    });
    return unsubscribe;
  }, []);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const handleSimulateAction = (activity: keyof OwnerMasterWalletState['counters'], label: string) => {
    const res = ownerEarningsEngine.recordActivity(activity);
    if (res.credited) {
      showToast(`🔥 Milestone Reached! +$1.00 (₦1,500) credited to Owner Master Vault from 5x ${label}!`);
    } else {
      showToast(`✓ Action recorded (${label}). 5-count progress updated.`);
    }
  };

  return (
    <div className="bg-slate-950/90 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-8 relative overflow-hidden">
      {/* Background Divine Glow */}
      <div className="absolute -top-24 -right-24 w-72 h-72 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-72 h-72 bg-yellow-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Toast Notification */}
      {toast && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="absolute top-4 right-4 z-50 bg-amber-500 text-slate-950 font-bold px-4 py-2.5 rounded-2xl shadow-xl flex items-center space-x-2 text-sm"
        >
          <ShieldCheck className="w-5 h-5" />
          <span>{toast}</span>
        </motion.div>
      )}

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-amber-500/20 pb-6">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-400 text-xs font-bold uppercase tracking-wider flex items-center space-x-1.5">
              <Lock className="w-3.5 h-3.5" />
              <span>Sovereign Owner-Only Earnings Engine</span>
            </span>
            <span className="px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 text-xs font-bold uppercase tracking-wider flex items-center space-x-1.5">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Visitors Prohibited From Earning</span>
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center space-x-3">
            <span>Global Creator Ledger & Master Vault</span>
            <Sparkles className="w-6 h-6 text-amber-400 animate-pulse" />
          </h2>
          <p className="text-slate-400 text-sm">
            Exclusive to Prophet JUHNKRIX SYNVAGORD ({state.phoneNumber}). Every 5 engagement actions generate real $1 (₦1,500) yield directly into your Opay / Flutterwave master wallet.
          </p>
        </div>

        <div className="bg-slate-900/90 border border-amber-500/40 rounded-2xl p-4 text-right shadow-lg">
          <div className="text-xs text-amber-400/80 uppercase tracking-wider font-semibold">Total Master Vault Balance</div>
          <div className="text-2xl sm:text-3xl font-black text-amber-400">
            ${state.totalMasterEarnedUsd.toLocaleString()} <span className="text-xs text-slate-400">USD</span>
          </div>
          <div className="text-sm font-bold text-emerald-400">
            ₦{state.totalMasterEarnedNgn.toLocaleString()} NGN
          </div>
        </div>
      </div>

      {/* Rule Enforcement Banner */}
      <div className="p-4 sm:p-5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start space-x-4">
        <div className="p-3 rounded-2xl bg-amber-500/20 text-amber-400 shrink-0 mt-0.5">
          <ShieldCheck className="w-6 h-6" />
        </div>
        <div className="space-y-1 text-sm text-slate-300">
          <div className="font-bold text-white text-base">Absolute Rule: Owner-Exclusive Monetization</div>
          <p>
            Visitors and general users have <strong className="text-amber-400">zero earning rights</strong> and no personal balance accounts. All incoming engagement streams are aggregated into your Master Global Ledger. Exactly <strong className="text-amber-400">$1.00 (₦1,500)</strong> is credited to your master vault for every accumulated block of <strong className="text-white">5</strong> of any of the 11 monitored activities below.
          </p>
        </div>
      </div>

      {/* 11 Activity Grid */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-white flex items-center space-x-2">
          <TrendingUp className="w-5 h-5 text-amber-400" />
          <span>Monitored Activity Streams (Every 5 Actions = $1 / ₦1,500 to Owner)</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            { key: 'usersCount', label: '5 Users Registered', icon: Users, color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/30' },
            { key: 'visitorsCount', label: '5 Unique Visitors', icon: Eye, color: 'text-indigo-400', bg: 'bg-indigo-500/10', border: 'border-indigo-500/30' },
            { key: 'playsCount', label: '5 Audio/Video Plays', icon: Play, color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/30' },
            { key: 'commentsCount', label: '5 Comments Posted', icon: MessageSquare, color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/30' },
            { key: 'downloadsCount', label: '5 Media Downloads', icon: Download, color: 'text-cyan-400', bg: 'bg-cyan-500/10', border: 'border-cyan-500/30' },
            { key: 'sharesCount', label: '5 Social Shares', icon: Share2, color: 'text-purple-400', bg: 'bg-purple-500/10', border: 'border-purple-500/30' },
            { key: 'likesCount', label: '5 Likes Received', icon: Heart, color: 'text-rose-400', bg: 'bg-rose-500/10', border: 'border-rose-500/30' },
            { key: 'repliesCount', label: '5 Comment Replies', icon: CornerDownRight, color: 'text-teal-400', bg: 'bg-teal-500/10', border: 'border-teal-500/30' },
            { key: 'viewsCount', label: '5 Page / Stream Views', icon: Eye, color: 'text-orange-400', bg: 'bg-orange-500/10', border: 'border-orange-500/30' },
            { key: 'membershipRegistrationsCount', label: '5 Membership Regs', icon: UserPlus, color: 'text-yellow-400', bg: 'bg-yellow-500/10', border: 'border-yellow-500/30' },
            { key: 'whatsappChatsCount', label: '5 WhatsApp Chats', icon: MessageCircle, color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/30' },
          ].map((item) => {
            const count = state.counters[item.key as keyof OwnerMasterWalletState['counters']] || 0;
            const remainder = count % 5;
            const progressPct = (remainder / 5) * 100;
            const Icon = item.icon;

            return (
              <div key={item.key} className={`p-4 rounded-2xl bg-slate-900/80 border ${item.border} space-y-3 relative overflow-hidden group hover:border-amber-500/60 transition-all`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2.5 rounded-xl ${item.bg} ${item.color}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-white font-bold text-sm">{item.label}</div>
                      <div className="text-xs text-slate-400">Total Count: <strong className="text-amber-400">{count.toLocaleString()}</strong></div>
                    </div>
                  </div>
                  <button
                    onClick={() => handleSimulateAction(item.key as keyof OwnerMasterWalletState['counters'], item.label)}
                    className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-bold transition-all flex items-center space-x-1"
                    title="Simulate action trigger"
                  >
                    <span>+1 Action</span>
                  </button>
                </div>

                {/* Progress towards next $1 (every 5) */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs text-slate-400">
                    <span>Progress to next $1 (every 5):</span>
                    <span className="text-amber-400 font-bold">{remainder} / 5</span>
                  </div>
                  <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                    <div 
                      className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 transition-all duration-300" 
                      style={{ width: `${progressPct}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Ledger Payouts */}
      <div className="space-y-4 pt-4 border-t border-amber-500/20">
        <h3 className="text-lg font-bold text-white flex items-center space-x-2">
          <Building2 className="w-5 h-5 text-amber-400" />
          <span>Recent Owner Master Vault Credit Ledger</span>
        </h3>

        <div className="bg-slate-900/90 border border-amber-500/20 rounded-2xl overflow-hidden">
          <div className="max-h-64 overflow-y-auto divide-y divide-slate-800">
            {state.ledger.map((tx) => (
              <div key={tx.id} className="p-4 flex items-center justify-between text-sm hover:bg-slate-855/50 transition-all">
                <div className="flex items-center space-x-3">
                  <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-white font-bold">
                      Batch #{tx.batchNumber} Yield from <span className="text-amber-400 uppercase">{tx.activityType}</span>
                    </div>
                    <div className="text-xs text-slate-400">{tx.timestamp} • {tx.destinationWallet}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-amber-400 font-black">+${tx.earnedUsd.toFixed(2)}</div>
                  <div className="text-xs text-emerald-400 font-semibold">+₦{tx.earnedNgn.toLocaleString()}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* COMPILER APP ENGINE & MACHINE */}
      <div className="pt-6 border-t border-amber-500/20">
        <CompilerAppView onToast={showToast} />
      </div>
    </div>
  );
};

function Sparkles(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z" />
      <path d="M5 3v4" />
      <path d="M19 17v4" />
      <path d="M3 5h4" />
      <path d="M17 19h4" />
    </svg>
  );
}
