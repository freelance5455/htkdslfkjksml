import React, { useRef, useEffect } from 'react';
import {
  Sliders,
  Activity,
  Layers,
  Sparkles,
  Volume2,
  VolumeX,
  Zap,
  Disc,
  Filter
} from 'lucide-react';
import { Project, Track, TrackFx, SynthConfig } from '../types/daw';
import { engine, PlayheadState } from '../audio/engine';
import { Knob } from './Knob';

interface MixerViewProps {
  project: Project;
  playhead: PlayheadState;
  selectedTrackId: string | null;
  onSelectTrack: (trackId: string) => void;
  onUpdateProject: (updater: (prev: Project) => Project) => void;
}

export const MixerView: React.FC<MixerViewProps> = ({
  project,
  playhead,
  selectedTrackId,
  onSelectTrack,
  onUpdateProject,
}) => {
  // Currently inspected track in FX rack
  const selectedTrack = project.tracks.find(t => t.id === selectedTrackId) || project.tracks[0];

  const updateTrackFx = (updater: (prev: TrackFx) => TrackFx) => {
    if (!selectedTrack) return;
    onUpdateProject(p => ({
      ...p,
      tracks: p.tracks.map(t =>
        t.id === selectedTrack.id ? { ...t, fx: updater(t.fx) } : t
      ),
    }));
  };

  const updateTrackSynth = (updater: (prev: SynthConfig) => SynthConfig) => {
    if (!selectedTrack) return;
    onUpdateProject(p => ({
      ...p,
      tracks: p.tracks.map(t =>
        t.id === selectedTrack.id
          ? { ...t, synthConfig: updater(t.synthConfig) }
          : t
      ),
    }));
  };

  // EQ Curve Canvas Visualizer
  const eqCanvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = eqCanvasRef.current;
    if (!canvas || !selectedTrack) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const w = canvas.width;
    const h = canvas.height;
    const midY = h / 2;

    // Draw grid
    ctx.strokeStyle = '#222836';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, midY);
    ctx.lineTo(w, midY);
    ctx.moveTo(w * 0.25, 0);
    ctx.lineTo(w * 0.25, h);
    ctx.moveTo(w * 0.5, 0);
    ctx.lineTo(w * 0.5, h);
    ctx.moveTo(w * 0.75, 0);
    ctx.lineTo(w * 0.75, h);
    ctx.stroke();

    // Draw Parametric Curve
    ctx.beginPath();
    ctx.strokeStyle = selectedTrack.color;
    ctx.lineWidth = 2.5;

    const lowG = selectedTrack.fx.eqLow * 2;
    const midG = selectedTrack.fx.eqMid * 2;
    const highG = selectedTrack.fx.eqHigh * 2;

    ctx.moveTo(0, midY - lowG);
    ctx.bezierCurveTo(
      w * 0.25,
      midY - lowG,
      w * 0.35,
      midY - midG,
      w * 0.5,
      midY - midG
    );
    ctx.bezierCurveTo(
      w * 0.65,
      midY - midG,
      w * 0.75,
      midY - highG,
      w,
      midY - highG
    );
    ctx.stroke();

    // Fill subtle gradient below
    ctx.lineTo(w, h);
    ctx.lineTo(0, h);
    ctx.closePath();
    ctx.fillStyle = `${selectedTrack.color}18`;
    ctx.fill();
  }, [selectedTrack?.fx.eqLow, selectedTrack?.fx.eqMid, selectedTrack?.fx.eqHigh, selectedTrack?.color]);

  return (
    <div className="flex-1 flex flex-col md:flex-row bg-[#11141b] overflow-hidden select-none">
      {/* Left: Multi-Channel Console Strips */}
      <div className="w-full md:w-3/5 lg:w-1/2 bg-[#141720] border-b md:border-b-0 md:border-r border-[#262c38] flex flex-col shrink-0 overflow-hidden">
        {/* Console Header */}
        <div className="h-10 bg-[#181c26] border-b border-[#262c38] px-4 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
            <Sliders className="w-4 h-4 text-[#00e676]" />
            <span>MIXER CONSOLE</span>
          </div>
          <span className="text-[10px] text-slate-400 font-mono">
            {project.tracks.length + 1} CHANNELS
          </span>
        </div>

        {/* Channel Strips Horizontal Carousel */}
        <div className="flex-1 overflow-x-auto overflow-y-hidden p-3 sm:p-4 flex gap-2.5 bg-[#0f1118]">
          {/* 1. MASTER BUS STRIP */}
          <div className="w-24 sm:w-28 bg-[#181c25] border-2 border-[#00e676]/40 rounded-2xl p-2.5 flex flex-col justify-between shrink-0 shadow-lg relative group">
            {/* Master Header */}
            <div className="flex flex-col items-center">
              <span className="text-[10px] uppercase font-bold tracking-wider text-[#00e676]">
                MASTER
              </span>
              <span className="text-[9px] font-mono text-slate-400 tabular-nums">
                {Math.round(project.masterVolume * 100)}%
              </span>
            </div>

            {/* Vertical Meter & Fader */}
            <div className="flex-1 flex justify-center items-center py-2 gap-2">
              {/* Peak VU Meter */}
              <div className="w-2 h-36 bg-[#101319] rounded-full overflow-hidden flex flex-col-reverse p-0.5 border border-[#262c38]">
                <div
                  className="w-full rounded-full transition-all duration-75"
                  style={{
                    height: playhead.isPlaying ? `${Math.min(100, project.masterVolume * 85)}%` : '0%',
                    backgroundColor: '#00e676',
                  }}
                />
              </div>

              {/* Master Volume Fader */}
              <input
                type="range"
                min="0"
                max="1.2"
                step="0.05"
                value={project.masterVolume}
                onChange={e => {
                  const val = Number(e.target.value);
                  onUpdateProject(p => ({ ...p, masterVolume: val }));
                }}
                className="h-36 -rotate-90 my-auto accent-[#00e676] cursor-pointer"
              />
            </div>

            {/* Master Limiter Status */}
            <div className="text-center">
              <span className="text-[9px] font-bold text-slate-400 bg-[#222836] px-2 py-0.5 rounded">
                LIMITER
              </span>
            </div>
          </div>

          {/* 2. INDIVIDUAL TRACK CHANNELS */}
          {project.tracks.map((track, trackIdx) => {
            const isSelected = selectedTrack?.id === track.id;

            return (
              <div
                key={track.id}
                onClick={() => onSelectTrack(track.id)}
                style={{
                  borderColor: isSelected ? track.color : '#252b37',
                  boxShadow: isSelected ? `0 0 15px ${track.color}33` : undefined,
                }}
                className={`w-24 sm:w-28 rounded-2xl p-2.5 flex flex-col justify-between shrink-0 transition-all cursor-pointer border-2 relative ${
                  isSelected ? 'bg-[#1e232e]' : 'bg-[#161a22] hover:bg-[#1a1f29]'
                }`}
              >
                {/* Channel Top: Track # & Name */}
                <div className="flex flex-col items-center">
                  <div className="flex items-center gap-1">
                    <div
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: track.color }}
                    />
                    <span className="text-[10px] font-mono text-slate-400 font-bold">
                      CH {trackIdx + 1}
                    </span>
                  </div>
                  <span className="text-xs font-semibold text-slate-100 truncate w-full text-center mt-0.5">
                    {track.name}
                  </span>
                </div>

                {/* Pan Rotary Knob */}
                <div className="flex justify-center my-1" onClick={e => e.stopPropagation()}>
                  <Knob
                    label="PAN"
                    value={track.pan}
                    min={-1}
                    max={1}
                    step={0.05}
                    defaultValue={0}
                    size={38}
                    color={track.color}
                    onChange={val => {
                      onUpdateProject(p => ({
                        ...p,
                        tracks: p.tracks.map(t =>
                          t.id === track.id ? { ...t, pan: val } : t
                        ),
                      }));
                    }}
                  />
                </div>

                {/* Vertical Fader & Meter */}
                <div
                  className="flex-1 flex justify-center items-center py-1 gap-2"
                  onClick={e => e.stopPropagation()}
                >
                  {/* Track VU peak meter */}
                  <div className="w-1.5 h-28 bg-[#101319] rounded-full overflow-hidden flex flex-col-reverse p-0.5 border border-[#262c38]">
                    <div
                      className="w-full rounded-full transition-all duration-75"
                      style={{
                        height: playhead.isPlaying && !track.muted
                          ? `${Math.min(100, track.volume * 80)}%`
                          : '0%',
                        backgroundColor: track.color,
                      }}
                    />
                  </div>

                  {/* Volume Slider */}
                  <input
                    type="range"
                    min="0"
                    max="1.2"
                    step="0.05"
                    value={track.volume}
                    onChange={e => {
                      const val = Number(e.target.value);
                      onUpdateProject(p => ({
                        ...p,
                        tracks: p.tracks.map(t =>
                          t.id === track.id ? { ...t, volume: val } : t
                        ),
                      }));
                    }}
                    className="h-28 -rotate-90 my-auto accent-[#ff7700] cursor-pointer"
                  />
                </div>

                {/* Mute & Solo Buttons */}
                <div
                  className="flex items-center justify-center gap-1.5 pt-1 border-t border-[#252b37]"
                  onClick={e => e.stopPropagation()}
                >
                  <button
                    onClick={() => {
                      onUpdateProject(p => ({
                        ...p,
                        tracks: p.tracks.map(t =>
                          t.id === track.id ? { ...t, muted: !t.muted } : t
                        ),
                      }));
                    }}
                    className={`w-6 h-5 rounded text-[10px] font-bold transition-colors ${
                      track.muted
                        ? 'bg-red-500 text-white'
                        : 'bg-[#252b38] text-slate-400 hover:text-white'
                    }`}
                  >
                    M
                  </button>

                  <button
                    onClick={() => {
                      onUpdateProject(p => ({
                        ...p,
                        tracks: p.tracks.map(t =>
                          t.id === track.id ? { ...t, soloed: !t.soloed } : t
                        ),
                      }));
                    }}
                    className={`w-6 h-5 rounded text-[10px] font-bold transition-colors ${
                      track.soloed
                        ? 'bg-amber-500 text-black'
                        : 'bg-[#252b38] text-slate-400 hover:text-white'
                    }`}
                  >
                    S
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Right: Selected Channel FX & Synth Parameters Rack */}
      <div className="flex-1 bg-[#12151d] flex flex-col overflow-y-auto">
        {/* FX Rack Header */}
        <div className="h-10 bg-[#161a22] border-b border-[#252b37] px-4 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <div
              className="w-3 h-3 rounded-full"
              style={{ backgroundColor: selectedTrack?.color }}
            />
            <span className="text-xs font-bold text-slate-100">
              FX RACK: {selectedTrack?.name}
            </span>
          </div>
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
            DSP Chain
          </span>
        </div>

        {selectedTrack ? (
          <div className="p-4 flex flex-col gap-4 overflow-y-auto">
            {/* MODULE 1: 3-Band Parametric EQ with Graphic Curve */}
            <div className="bg-[#181c26] border border-[#262c38] rounded-2xl p-4 shadow-md">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-[#00e5ff]" />
                  <span className="text-xs font-bold text-slate-100">
                    Parametric EQ (3-Band)
                  </span>
                </div>
                <span className="text-[10px] font-mono text-slate-400">
                  LOW 250Hz · MID 1.5kHz · HIGH 5.5kHz
                </span>
              </div>

              {/* Visual Curve Canvas */}
              <div className="h-20 bg-[#101319] rounded-xl overflow-hidden border border-[#252b37] mb-4">
                <canvas ref={eqCanvasRef} width={340} height={80} className="w-full h-full" />
              </div>

              {/* EQ Knobs */}
              <div className="flex items-center justify-around">
                <Knob
                  label="LOW GAIN"
                  value={selectedTrack.fx.eqLow}
                  min={-12}
                  max={12}
                  step={0.5}
                  defaultValue={0}
                  unit="dB"
                  color="#00e5ff"
                  onChange={val => updateTrackFx(fx => ({ ...fx, eqLow: val }))}
                />
                <Knob
                  label="MID GAIN"
                  value={selectedTrack.fx.eqMid}
                  min={-12}
                  max={12}
                  step={0.5}
                  defaultValue={0}
                  unit="dB"
                  color="#ffca28"
                  onChange={val => updateTrackFx(fx => ({ ...fx, eqMid: val }))}
                />
                <Knob
                  label="HIGH GAIN"
                  value={selectedTrack.fx.eqHigh}
                  min={-12}
                  max={12}
                  step={0.5}
                  defaultValue={0}
                  unit="dB"
                  color="#ff7700"
                  onChange={val => updateTrackFx(fx => ({ ...fx, eqHigh: val }))}
                />
              </div>
            </div>

            {/* MODULE 2: Delay & Reverb Spatial Section */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Stereo Delay */}
              <div className="bg-[#181c26] border border-[#262c38] rounded-2xl p-4 shadow-md">
                <div className="flex items-center gap-2 mb-3">
                  <Disc className="w-4 h-4 text-[#ff7700]" />
                  <span className="text-xs font-bold text-slate-100">Stereo Delay</span>
                </div>
                <div className="flex items-center justify-around">
                  <Knob
                    label="TIME"
                    value={selectedTrack.fx.delayTime}
                    min={0.05}
                    max={0.8}
                    step={0.01}
                    unit="s"
                    color="#ff7700"
                    onChange={val => updateTrackFx(fx => ({ ...fx, delayTime: val }))}
                  />
                  <Knob
                    label="FEEDBACK"
                    value={Math.round(selectedTrack.fx.delayFeedback * 100)}
                    min={0}
                    max={85}
                    unit="%"
                    color="#ff7700"
                    onChange={val => updateTrackFx(fx => ({ ...fx, delayFeedback: val / 100 }))}
                  />
                  <Knob
                    label="MIX"
                    value={Math.round(selectedTrack.fx.delayMix * 100)}
                    min={0}
                    max={100}
                    unit="%"
                    color="#ff7700"
                    onChange={val => updateTrackFx(fx => ({ ...fx, delayMix: val / 100 }))}
                  />
                </div>
              </div>

              {/* Studio Reverb */}
              <div className="bg-[#181c26] border border-[#262c38] rounded-2xl p-4 shadow-md">
                <div className="flex items-center gap-2 mb-3">
                  <Sparkles className="w-4 h-4 text-[#e040fb]" />
                  <span className="text-xs font-bold text-slate-100">Convolution Reverb</span>
                </div>
                <div className="flex items-center justify-around">
                  <Knob
                    label="DECAY"
                    value={selectedTrack.fx.reverbDecay}
                    min={0.5}
                    max={5.0}
                    step={0.1}
                    unit="s"
                    color="#e040fb"
                    onChange={val => updateTrackFx(fx => ({ ...fx, reverbDecay: val }))}
                  />
                  <Knob
                    label="WET MIX"
                    value={Math.round(selectedTrack.fx.reverbMix * 100)}
                    min={0}
                    max={100}
                    unit="%"
                    color="#e040fb"
                    onChange={val => updateTrackFx(fx => ({ ...fx, reverbMix: val / 100 }))}
                  />
                </div>
              </div>
            </div>

            {/* MODULE 3: Distortion / Overdrive */}
            <div className="bg-[#181c26] border border-[#262c38] rounded-2xl p-4 shadow-md">
              <div className="flex items-center gap-2 mb-3">
                <Zap className="w-4 h-4 text-[#ff1744]" />
                <span className="text-xs font-bold text-slate-100">Tube Overdrive / Crunch</span>
              </div>
              <div className="flex items-center justify-around">
                <Knob
                  label="DRIVE"
                  value={selectedTrack.fx.distortionDrive}
                  min={0}
                  max={8}
                  step={0.2}
                  unit="x"
                  color="#ff1744"
                  onChange={val => updateTrackFx(fx => ({ ...fx, distortionDrive: val }))}
                />
                <Knob
                  label="MIX"
                  value={Math.round(selectedTrack.fx.distortionMix * 100)}
                  min={0}
                  max={100}
                  unit="%"
                  color="#ff1744"
                  onChange={val => updateTrackFx(fx => ({ ...fx, distortionMix: val / 100 }))}
                />
              </div>
            </div>

            {/* MODULE 4: Synthesizer Engine Configuration (when not acoustic drums) */}
            {selectedTrack.type !== 'drums' && (
              <div className="bg-[#181c26] border border-[#262c38] rounded-2xl p-4 shadow-md">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Filter className="w-4 h-4 text-[#00e676]" />
                    <span className="text-xs font-bold text-slate-100">
                      Synth Sound Generator & VCF Filter
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">
                    OSC 1 ({selectedTrack.synthConfig.osc1Type}) + OSC 2 ({selectedTrack.synthConfig.osc2Type})
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-1">
                  <Knob
                    label="CUTOFF"
                    value={selectedTrack.synthConfig.filterCutoff}
                    min={200}
                    max={12000}
                    step={100}
                    unit="Hz"
                    color="#00e676"
                    onChange={val => updateTrackSynth(s => ({ ...s, filterCutoff: val }))}
                  />
                  <Knob
                    label="RESONANCE"
                    value={selectedTrack.synthConfig.filterRes}
                    min={0.5}
                    max={12}
                    step={0.5}
                    unit="Q"
                    color="#00e676"
                    onChange={val => updateTrackSynth(s => ({ ...s, filterRes: val }))}
                  />
                  <Knob
                    label="ATTACK"
                    value={selectedTrack.synthConfig.attack}
                    min={0.005}
                    max={1.5}
                    step={0.01}
                    unit="s"
                    color="#00e5ff"
                    onChange={val => updateTrackSynth(s => ({ ...s, attack: val }))}
                  />
                  <Knob
                    label="RELEASE"
                    value={selectedTrack.synthConfig.release}
                    min={0.05}
                    max={2.5}
                    step={0.05}
                    unit="s"
                    color="#00e5ff"
                    onChange={val => updateTrackSynth(s => ({ ...s, release: val }))}
                  />
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center text-slate-500 text-xs">
            Select a track to inspect FX rack
          </div>
        )}
      </div>
    </div>
  );
};
