import { useEffect, useRef } from "react";
import { drawPortrait } from "../game/art";
import type { Palette } from "../game/types";

export function Portrait({
  palette,
  size = 64,
  crown,
  hood,
  className = "",
}: {
  palette: Palette;
  size?: number;
  crown?: boolean;
  hood?: boolean;
  className?: string;
}) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, c.width, c.height);
    drawPortrait(ctx, palette, c.width, c.height, crown, hood);
  }, [palette, crown, hood, size]);
  return (
    <canvas
      ref={ref}
      width={size}
      height={size}
      className={`image-rendering-pixelated border-2 border-[#4a3a5e] bg-[#120e18] ${className}`}
      style={{ width: size, height: size }}
    />
  );
}
