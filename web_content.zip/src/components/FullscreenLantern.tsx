import React, { useState, useEffect } from 'react';
import { X, Sun, Battery, Clock } from 'lucide-react';
import { LightColorPreset } from '../types/flashlight';
import { soundService } from '../utils/sound';

interface FullscreenLanternProps {
  color: LightColorPreset;
  brightness: number;
  onBrightnessChange: (b: number) => void;
  candleFlicker: boolean;
  onClose: () => void;
}

export const FullscreenLantern: React.FC<FullscreenLanternProps> = ({
  color,
  brightness,
  onBrightnessChange,
  candleFlicker,
  onClose,
}) => {
  const [currentTime, setCurrentTime] = useState('');
  const [flickerOffset, setFlickerOffset] = useState(0);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('cs-CZ', { hour: '2-digit', minute: '2-digit' })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Candle flicker animation loop
  useEffect(() => {
    if (!candleFlicker) {
      setFlickerOffset(0);
      return;
    }

    const interval = setInterval(() => {
      // Natural random flame fluctuation
      const rand = (Math.random() - 0.5) * 15;
      setFlickerOffset(rand);
    }, 120);

    return () => clearInterval(interval);
  }, [candleFlicker]);

  const effectiveBrightness = Math.min(
    100,
    Math.max(10, brightness + flickerOffset)
  );

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col justify-between transition-colors select-none"
      style={{
        backgroundColor: color.hex,
        opacity: effectiveBrightness / 100,
      }}
      onDoubleClick={() => {
        soundService.playTick();
        onClose();
      }}
    >
      {/* Top subtle controls bar */}
      <div className="flex items-center justify-between p-4 sm:p-6 bg-black/15 backdrop-blur-xs">
        <div className="flex items-center gap-2 text-xs font-semibold px-3 py-1.5 rounded-full bg-black/30 backdrop-blur-md text-white/90">
          <span>Dvojitým poklepáním ukončíte</span>
        </div>

        <button
          onClick={() => {
            soundService.playTick();
            onClose();
          }}
          className="p-2.5 rounded-full bg-black/30 text-white hover:bg-black/50 transition-colors cursor-pointer"
          aria-label="Ukončit režim lucerny"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Center ambient indicator */}
      <div className="flex flex-col items-center justify-center p-6 text-center pointer-events-none">
        <span
          className="text-4xl sm:text-6xl font-black tracking-tight"
          style={{ color: color.textColor }}
        >
          {currentTime}
        </span>
        <span
          className="text-xs sm:text-sm font-semibold tracking-wide uppercase mt-1 opacity-70"
          style={{ color: color.textColor }}
        >
          {color.name} {candleFlicker && '· Plamen svíčky'}
        </span>
      </div>

      {/* Bottom Floating Brightness Bar */}
      <div className="p-4 sm:p-6 bg-black/20 backdrop-blur-sm flex flex-col items-center gap-3">
        <div className="w-full max-w-sm flex items-center gap-3">
          <Sun className="w-5 h-5 text-white/80 shrink-0" />
          <input
            type="range"
            min="10"
            max="100"
            value={brightness}
            onChange={(e) => onBrightnessChange(Number(e.target.value))}
            className="w-full h-3 bg-black/30 rounded-lg appearance-none cursor-pointer accent-white"
            aria-label="Jas lucerny"
          />
          <span className="text-xs font-mono font-bold text-white/90 w-10 text-right tabular-nums">
            {brightness}%
          </span>
        </div>
      </div>
    </div>
  );
};
