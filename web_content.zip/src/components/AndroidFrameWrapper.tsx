/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Smartphone, Monitor, Wifi, BatteryMedium, Signal } from 'lucide-react';

interface AndroidFrameWrapperProps {
  children: React.ReactNode;
  isPhoneFrame: boolean;
  onToggleFrame: () => void;
}

export const AndroidFrameWrapper: React.FC<AndroidFrameWrapperProps> = ({
  children,
  isPhoneFrame,
  onToggleFrame,
}) => {
  const [timeStr, setTimeStr] = useState('10:42');

  useEffect(() => {
    const updateTime = () => {
      const d = new Date();
      const h = d.getHours().toString().padStart(2, '0');
      const m = d.getMinutes().toString().padStart(2, '0');
      setTimeStr(`${h}:${m}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  if (!isPhoneFrame) {
    // Full screen / stage view
    return (
      <div className="min-h-screen w-full bg-[#06060a] text-white flex flex-col">
        {children}
      </div>
    );
  }

  // Realistic Android Phone Simulation Frame
  return (
    <div className="min-h-screen w-full bg-[#030305] flex items-center justify-center p-2 sm:p-6 overflow-x-hidden">
      
      {/* Android Device Outer Chassis */}
      <div className="relative w-full max-w-[440px] rounded-[48px] bg-[#12131f] p-3 shadow-[0_0_80px_rgba(0,0,0,0.9),0_0_40px_rgba(0,240,255,0.15)] border-4 border-zinc-800">
        
        {/* Device Bezel & Screen Container */}
        <div className="relative w-full rounded-[40px] bg-[#07070c] overflow-hidden border border-zinc-700/60 flex flex-col min-h-[840px] max-h-[92vh]">
          
          {/* Android Status Bar */}
          <div className="h-9 px-6 bg-black/80 flex items-center justify-between text-xs text-zinc-300 font-mono shrink-0 select-none border-b border-zinc-800/40 z-30">
            {/* Clock */}
            <span className="font-bold text-cyan-300">{timeStr}</span>

            {/* Front Camera Punch-hole Notch */}
            <div className="w-3.5 h-3.5 rounded-full bg-black border border-zinc-700/80 shadow-inner flex items-center justify-center">
              <div className="w-1.5 h-1.5 rounded-full bg-blue-900/50" />
            </div>

            {/* Icons: 5G, Wifi, Battery */}
            <div className="flex items-center gap-1.5 text-zinc-400">
              <span className="text-[10px] font-bold text-zinc-300">5G</span>
              <Signal className="w-3 h-3 text-cyan-400" />
              <Wifi className="w-3 h-3 text-purple-400" />
              <BatteryMedium className="w-4 h-4 text-emerald-400" />
            </div>
          </div>

          {/* Screen Scrollable Content */}
          <div className="flex-1 overflow-y-auto overflow-x-hidden relative flex flex-col">
            {children}
          </div>

          {/* Android Bottom Navigation Bar / Gesture Bar */}
          <div className="h-6 bg-black/90 flex items-center justify-center shrink-0 border-t border-zinc-900/60 z-30">
            <div className="w-32 h-1 rounded-full bg-zinc-500/60" />
          </div>

        </div>

      </div>

    </div>
  );
};
