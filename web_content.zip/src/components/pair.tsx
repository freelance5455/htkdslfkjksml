import { ItText } from "@/components/it-text";
import { RoadSign } from "@/components/road-sign";
import { signById } from "@/data/signs";

export function Pair({ it, ar }: { it: string; ar: string }) {
  return (
    <div className="space-y-2">
      <ItText text={it} />
      <p className="rounded-xl bg-soft px-3 py-3 text-base leading-relaxed">{ar}</p>
    </div>
  );
}

export function SignRow({ ids }: { ids: string[] }) {
  return (
    <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3">
      {ids.map((id) => {
        const info = signById(id);
        return (
          <li key={id} className="rounded-2xl border border-line bg-surface p-3">
            <RoadSign id={id} className="mx-auto h-24 w-24" />
            <p dir="ltr" lang="it" className="mt-2 text-left text-sm font-semibold">
              {info?.nameIt ?? id}
            </p>
            <p className="text-sm text-muted">{info?.nameAr}</p>
          </li>
        );
      })}
    </ul>
  );
}
