import { useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { FolderPlus, Link2, Plus, Upload } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MEDIA_ACCEPT } from "@/lib/constants";
import { collectRelativeFiles } from "@/lib/media-scan";
import { useLibrary } from "@/lib/library-store";
import { usePlayer } from "@/lib/player-store";

export function AddMediaButton({ variant = "default" }: { variant?: "default" | "header" }) {
  const fileRef = useRef<HTMLInputElement>(null);
  const folderRef = useRef<HTMLInputElement>(null);
  const addFiles = useLibrary((s) => s.addFiles);
  const addUrl = useLibrary((s) => s.addUrl);
  const openPlayer = usePlayer((s) => s.open);
  const navigate = useNavigate();
  const [urlOpen, setUrlOpen] = useState(false);
  const [url, setUrl] = useState("");
  const [name, setName] = useState("");

  const ingest = async (list: FileList | File[] | null) => {
    if (!list) return;
    const files = collectRelativeFiles(list);
    if (!files.length) {
      toast.error("No readable media files in that selection.");
      return;
    }
    await addFiles(files);
    toast.success(`Added ${files.length} file${files.length === 1 ? "" : "s"}`);
  };

  const pickFolder = async () => {
    const picker = window as unknown as {
      showDirectoryPicker?: (opts?: { mode?: string }) => Promise<FileSystemDirectoryHandle>;
    };
    if (picker.showDirectoryPicker) {
      try {
        const dir = await picker.showDirectoryPicker({ mode: "read" });
        const files: File[] = [];
        const walk = async (handle: FileSystemDirectoryHandle, prefix: string) => {
          // @ts-expect-error — async iterator of directory handles
          for await (const [childName, child] of handle.entries()) {
            if (child.kind === "file") {
              const file = await (child as FileSystemFileHandle).getFile();
              Object.defineProperty(file, "webkitRelativePath", {
                value: `${prefix}${childName}`,
              });
              files.push(file);
            } else if (child.kind === "directory") {
              await walk(child as FileSystemDirectoryHandle, `${prefix}${childName}/`);
            }
          }
        };
        await walk(dir, `${dir.name}/`);
        await ingest(files);
        return;
      } catch (err) {
        if (err instanceof DOMException && err.name === "AbortError") return;
      }
    }
    folderRef.current?.click();
  };

  const playUrl = () => {
    const trimmed = url.trim();
    if (!trimmed) return;
    try {
      new URL(trimmed);
    } catch {
      toast.error("Enter a valid http(s) URL.");
      return;
    }
    const kind = /\.(mp3|wav|m4a|aac|flac|opus)(\?|$)/i.test(trimmed) ? "audio" : "video";
    const item = addUrl(name.trim() || trimmed, trimmed, kind);
    setUrlOpen(false);
    setUrl("");
    setName("");
    openPlayer(item);
    void navigate({ to: "/player/$id", params: { id: item.id } });
  };

  return (
    <>
      <input
        ref={fileRef}
        type="file"
        accept={MEDIA_ACCEPT}
        multiple
        className="sr-only"
        aria-hidden="true"
        tabIndex={-1}
        onChange={(e) => {
          void ingest(e.target.files);
          e.target.value = "";
        }}
      />
      <input
        ref={folderRef}
        type="file"
        // @ts-expect-error webkitdirectory is non-standard but widely supported
        webkitdirectory=""
        multiple
        className="sr-only"
        aria-hidden="true"
        tabIndex={-1}
        onChange={(e) => {
          void ingest(e.target.files);
          e.target.value = "";
        }}
      />
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button size={variant === "header" ? "sm" : "default"} aria-label="Add media">
            <Plus />
            Add media
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onSelect={() => fileRef.current?.click()}>
            <Upload /> Files
          </DropdownMenuItem>
          <DropdownMenuItem onSelect={() => void pickFolder()}>
            <FolderPlus /> Folder
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onSelect={() => setUrlOpen(true)}>
            <Link2 /> Play URL
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
      <Dialog open={urlOpen} onOpenChange={setUrlOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Play a network URL</DialogTitle>
            <DialogDescription>
              Direct HTTP(S) media only. Pages, DRM, and extracted streams are not supported.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor="media-url">URL</Label>
              <Input
                id="media-url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://example.com/film.mp4"
                autoComplete="off"
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="media-title">Title (optional)</Label>
              <Input
                id="media-title"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Display name"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setUrlOpen(false)}>
              Cancel
            </Button>
            <Button onClick={playUrl}>Play</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
