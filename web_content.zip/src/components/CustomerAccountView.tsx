import React, { useEffect, useState } from 'react';
import {
  User,
  Package,
  Clock,
  LogOut,
  CheckCircle2,
  Truck,
  XCircle,
  Loader2,
  ChevronDown,
  ChevronUp,
  MapPin,
  ArrowLeft,
  Navigation,
} from 'lucide-react';
import { collection, onSnapshot, query, where, getDocs } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { useStoreData } from '../context/StoreDataContext';
import { Order, OrderItem, OrderStatus } from '../types/store';
import { formatCurrency, formatDateTime } from '../lib/formatters';
import { detectBrowserLocation, LOCATION_PRESETS } from '../lib/location';

interface CustomerAccountViewProps {
  onBackToShop: () => void;
  onOpenAdminLogin: () => void;
}

const TRACKING_STEPS: OrderStatus[] = [
  'Pending',
  'Confirmed',
  'Processing',
  'Shipped',
  'Delivered',
];

export function CustomerAccountView({
  onBackToShop,
  onOpenAdminLogin,
}: CustomerAccountViewProps) {
  const {
    user,
    userProfile,
    authLoading,
    signInWithGoogle,
    signInWithEmail,
    registerWithEmail,
    updateCustomerProfile,
    logout,
  } = useAuth();
  const { notify } = useStoreData();

  const [authTab, setAuthTab] = useState<'login' | 'register'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginLocation, setLoginLocation] = useState('');
  const [detectingLoginLoc, setDetectingLoginLoc] = useState(false);
  const [authSubmitting, setAuthSubmitting] = useState(false);
  const [authError, setAuthError] = useState('');

  const [accountTab, setAccountTab] = useState<'orders' | 'history' | 'profile'>('orders');
  const [orders, setOrders] = useState<Order[]>([]);
  const [ordersLoading, setOrdersLoading] = useState(true);
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null);
  const [orderItemsMap, setOrderItemsMap] = useState<Record<string, OrderItem[]>>({});

  // Profile form state
  const [profileName, setProfileName] = useState('');
  const [profilePhone, setProfilePhone] = useState('');
  const [profileLocation, setProfileLocation] = useState('');
  const [detectingProfileLoc, setDetectingProfileLoc] = useState(false);
  const [profileAddress, setProfileAddress] = useState('');
  const [profileCity, setProfileCity] = useState('');
  const [profilePin, setProfilePin] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);

  useEffect(() => {
    if (userProfile) {
      setProfileName(userProfile.displayName || '');
      setProfilePhone(userProfile.phone || '');
      setProfileLocation(userProfile.location || '');
      setProfileAddress(userProfile.address || '');
      setProfileCity(userProfile.city || '');
      setProfilePin(userProfile.pinCode || '');
    }
  }, [userProfile]);

  useEffect(() => {
    if (!user) {
      setOrders([]);
      setOrdersLoading(false);
      return;
    }

    setOrdersLoading(true);
    const q = query(
      collection(db, 'orders'),
      where('userId', '==', user.uid)
    );

    const unsub = onSnapshot(
      q,
      (snap) => {
        const list = snap.docs
          .map((d) => ({ ...d.data(), id: d.id } as Order))
          .sort((a, b) => (b.createdAt?.toMillis() ?? 0) - (a.createdAt?.toMillis() ?? 0));
        setOrders(list);
        setOrdersLoading(false);
      },
      (error) => {
        setOrdersLoading(false);
        handleFirestoreError(error, OperationType.LIST, 'orders');
      }
    );

    return () => unsub();
  }, [user]);

  const toggleOrderDetails = async (orderId: string) => {
    if (expandedOrderId === orderId) {
      setExpandedOrderId(null);
      return;
    }
    setExpandedOrderId(orderId);
    if (!orderItemsMap[orderId] && user) {
      try {
        const snap = await getDocs(
          query(
            collection(db, 'orders', orderId, 'items'),
            where('userId', '==', user.uid)
          )
        );
        const items = snap.docs.map((d) => ({ ...d.data(), id: d.id } as OrderItem));
        setOrderItemsMap((prev) => ({ ...prev, [orderId]: items }));
      } catch (err) {
        handleFirestoreError(err, OperationType.LIST, `orders/${orderId}/items`);
      }
    }
  };

  const handleDetectLocation = async (target: 'login' | 'profile') => {
    if (target === 'login') setDetectingLoginLoc(true);
    else setDetectingProfileLoc(true);
    try {
      const loc = await detectBrowserLocation();
      if (target === 'login') setLoginLocation(loc);
      else setProfileLocation(loc);
      notify('Current location detected.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Unable to detect location.', 'error');
    } finally {
      if (target === 'login') setDetectingLoginLoc(false);
      else setDetectingProfileLoc(false);
    }
  };

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSubmitting(true);
    try {
      if (authTab === 'login') {
        await signInWithEmail(email, password, loginLocation);
        notify('Welcome back to Fashion Hub.', 'success');
      } else {
        await registerWithEmail(name, email, password, loginLocation);
        notify('Account created! Please check your inbox to verify your email.', 'success');
      }
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleGoogleLogin = async () => {
    setAuthError('');
    setAuthSubmitting(true);
    try {
      await signInWithGoogle(loginLocation);
      notify('Signed in with Google.', 'success');
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Google sign-in failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleProfileSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProfile(true);
    try {
      await updateCustomerProfile({
        displayName: profileName,
        phone: profilePhone,
        location: profileLocation,
        address: profileAddress,
        city: profileCity,
        pinCode: profilePin,
      });
      notify('Profile & delivery preferences updated.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Unable to save profile.', 'error');
    } finally {
      setSavingProfile(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-neutral-500" />
      </div>
    );
  }

  if (!user) {
    return (
      <section className="max-w-md mx-auto px-6 py-12 pb-24">
        <button
          type="button"
          onClick={onBackToShop}
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full border border-neutral-300 text-xs font-medium text-neutral-700 hover:text-[#0A0A0A] hover:border-[#0A0A0A] transition-colors cursor-pointer mb-6"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back</span>
        </button>

        <div className="text-center mb-7">
          <p className="text-xs uppercase tracking-[0.2em] text-neutral-500 mb-2">
            Fashion Hub Member Portal
          </p>
          <h1 className="font-display text-3xl font-semibold text-[#0A0A0A]">
            {authTab === 'login' ? 'Sign In' : 'Create Account'}
          </h1>
        </div>

        <div className="grid grid-cols-2 border border-neutral-200 p-1 bg-neutral-50 rounded-lg mb-5">
          <button
            type="button"
            onClick={() => {
              setAuthTab('login');
              setAuthError('');
            }}
            className={`py-2 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
              authTab === 'login' ? 'bg-white text-[#0A0A0A] shadow-xs' : 'text-neutral-500'
            }`}
          >
            Customer Login
          </button>
          <button
            type="button"
            onClick={() => {
              setAuthTab('register');
              setAuthError('');
            }}
            className={`py-2 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
              authTab === 'register' ? 'bg-white text-[#0A0A0A] shadow-xs' : 'text-neutral-500'
            }`}
          >
            Register
          </button>
        </div>

        {/* Customer Location Selection for Login & Registration */}
        <div className="mb-5 p-3.5 border border-neutral-200 bg-neutral-50/70 space-y-2.5">
          <div className="flex items-center justify-between gap-2">
            <label className="text-xs font-semibold text-[#0A0A0A] flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5" />
              <span>Your Location</span>
            </label>
            <button
              type="button"
              disabled={detectingLoginLoc}
              onClick={() => handleDetectLocation('login')}
              className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#0A0A0A] underline hover:opacity-75 cursor-pointer"
            >
              <Navigation className="w-3 h-3" />
              <span>{detectingLoginLoc ? 'Detecting...' : 'Use Current Location'}</span>
            </button>
          </div>
          <input
            type="text"
            maxLength={160}
            value={loginLocation}
            onChange={(e) => setLoginLocation(e.target.value)}
            placeholder="Enter area / town (e.g. Assam Badarpur)"
            className="w-full px-3 py-2 text-xs border border-neutral-300 bg-white focus:border-[#0A0A0A] focus:outline-none"
          />
          <div className="flex flex-wrap gap-1.5">
            {LOCATION_PRESETS.map((loc) => (
              <button
                key={loc}
                type="button"
                onClick={() => setLoginLocation(loc)}
                className={`px-2.5 py-1 rounded-full text-[11px] border transition-colors cursor-pointer ${
                  loginLocation === loc
                    ? 'bg-[#0A0A0A] text-white border-[#0A0A0A]'
                    : 'bg-white text-neutral-700 border-neutral-300 hover:border-[#0A0A0A]'
                }`}
              >
                {loc}
              </button>
            ))}
          </div>
        </div>

        <button
          type="button"
          disabled={authSubmitting}
          onClick={handleGoogleLogin}
          className="w-full py-3 px-5 rounded-full bg-[#0A0A0A] text-white text-xs font-semibold hover:bg-neutral-800 transition-colors cursor-pointer mb-5 flex items-center justify-center gap-2"
        >
          <span>Continue with Google</span>
        </button>

        <div className="relative flex py-3 items-center mb-5">
          <div className="flex-grow border-t border-neutral-200" />
          <span className="shrink mx-4 text-[11px] uppercase tracking-wider text-neutral-400">
            or with email
          </span>
          <div className="flex-grow border-t border-neutral-200" />
        </div>

        <form onSubmit={handleAuthSubmit} className="space-y-3.5">
          {authTab === 'register' && (
            <div>
              <label className="block text-xs font-medium text-neutral-700 mb-1">
                Full Name
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Jordan Taylor"
                className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
              />
            </div>
          )}
          <div>
            <label className="block text-xs font-medium text-neutral-700 mb-1">
              Email Address
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-neutral-700 mb-1">
              Password
            </label>
            <input
              type="password"
              required
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Minimum 6 characters"
              className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
            />
          </div>

          {authError && (
            <div className="p-3 border border-red-200 bg-red-50 text-xs text-red-700">
              {authError}
            </div>
          )}

          <button
            type="submit"
            disabled={authSubmitting}
            className="w-full py-3 px-5 rounded-full border border-[#0A0A0A] text-[#0A0A0A] text-xs font-semibold hover:bg-neutral-100 transition-colors cursor-pointer"
          >
            {authSubmitting
              ? 'Please wait...'
              : authTab === 'login'
              ? 'Sign In with Email'
              : 'Create Account'}
          </button>
        </form>

        <div className="mt-8 pt-6 border-t border-neutral-200 flex items-center justify-between text-xs text-neutral-500">
          <button type="button" onClick={onBackToShop} className="hover:text-[#0A0A0A] cursor-pointer">
            ← Back to Store
          </button>
          <button type="button" onClick={onOpenAdminLogin} className="hover:text-[#0A0A0A] underline cursor-pointer">
            Staff & Admin Login
          </button>
        </div>
      </section>
    );
  }

  const activeOrders = orders.filter((o) => o.status !== 'Delivered' && o.status !== 'Cancelled');
  const historyOrders = orders.filter((o) => o.status === 'Delivered' || o.status === 'Cancelled');

  const displayedOrders = accountTab === 'history' ? historyOrders : orders;

  return (
    <section className="w-full px-4 sm:px-8 lg:px-12 py-10 pb-24">
      <div className="mb-5">
        <button
          type="button"
          onClick={onBackToShop}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full border border-neutral-300 text-xs font-medium text-neutral-700 hover:text-[#0A0A0A] hover:border-[#0A0A0A] transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Store</span>
        </button>
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-8 border-b border-neutral-200">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-neutral-500 mb-1">
            Customer Account
          </p>
          <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#0A0A0A]">
            {userProfile?.displayName || user.displayName || 'Welcome'}
          </h1>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-neutral-500 mt-1">
            <span>{user.email}</span>
            {userProfile?.location && (
              <span className="inline-flex items-center gap-1 text-[#0A0A0A] font-medium">
                <MapPin className="w-3 h-3" />
                {userProfile.location}
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onBackToShop}
            className="px-4 py-2 rounded-full border border-neutral-300 text-xs font-medium hover:bg-neutral-100 transition-colors cursor-pointer"
          >
            Continue Shopping
          </button>
          <button
            type="button"
            onClick={async () => {
              await logout();
              notify('Signed out.', 'info');
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#0A0A0A] text-white text-xs font-medium hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Logout</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 py-6 border-b border-neutral-200 overflow-x-auto">
        <button
          type="button"
          onClick={() => setAccountTab('orders')}
          className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap cursor-pointer ${
            accountTab === 'orders'
              ? 'bg-[#0A0A0A] text-white'
              : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
          }`}
        >
          <Package className="w-3.5 h-3.5" />
          <span>My Orders & Tracking ({orders.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setAccountTab('history')}
          className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap cursor-pointer ${
            accountTab === 'history'
              ? 'bg-[#0A0A0A] text-white'
              : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Order History ({historyOrders.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setAccountTab('profile')}
          className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap cursor-pointer ${
            accountTab === 'profile'
              ? 'bg-[#0A0A0A] text-white'
              : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
          }`}
        >
          <User className="w-3.5 h-3.5" />
          <span>My Profile</span>
        </button>
      </div>

      {/* Content */}
      {accountTab === 'profile' ? (
        <form onSubmit={handleProfileSave} className="max-w-xl pt-8 space-y-4">
          <h2 className="text-base font-semibold text-[#0A0A0A]">
            Profile & Saved Delivery Address
          </h2>
          <div>
            <label className="block text-xs font-medium text-neutral-700 mb-1">
              Full Name
            </label>
            <input
              type="text"
              required
              maxLength={100}
              value={profileName}
              onChange={(e) => setProfileName(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-neutral-700 mb-1">
              Mobile Number
            </label>
            <input
              type="tel"
              maxLength={20}
              value={profilePhone}
              onChange={(e) => setProfilePhone(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
            />
          </div>
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-medium text-neutral-700">
                Location / Area
              </label>
              <button
                type="button"
                disabled={detectingProfileLoc}
                onClick={() => handleDetectLocation('profile')}
                className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#0A0A0A] underline hover:opacity-75 cursor-pointer"
              >
                <Navigation className="w-3 h-3" />
                <span>{detectingProfileLoc ? 'Detecting...' : 'Use Current Location'}</span>
              </button>
            </div>
            <input
              type="text"
              maxLength={160}
              value={profileLocation}
              onChange={(e) => setProfileLocation(e.target.value)}
              placeholder="e.g. Assam Badarpur"
              className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
            />
            <div className="flex flex-wrap gap-1.5 mt-2">
              {LOCATION_PRESETS.map((loc) => (
                <button
                  key={loc}
                  type="button"
                  onClick={() => setProfileLocation(loc)}
                  className={`px-2.5 py-1 rounded-full text-[11px] border transition-colors cursor-pointer ${
                    profileLocation === loc
                      ? 'bg-[#0A0A0A] text-white border-[#0A0A0A]'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:border-[#0A0A0A]'
                  }`}
                >
                  {loc}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-neutral-700 mb-1">
              Delivery Address
            </label>
            <textarea
              rows={2}
              maxLength={300}
              value={profileAddress}
              onChange={(e) => setProfileAddress(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none resize-none"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-neutral-700 mb-1">City</label>
              <input
                type="text"
                maxLength={80}
                value={profileCity}
                onChange={(e) => setProfileCity(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-neutral-700 mb-1">
                PIN / Postal Code
              </label>
              <input
                type="text"
                maxLength={12}
                value={profilePin}
                onChange={(e) => setProfilePin(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
              />
            </div>
          </div>
          <button
            type="submit"
            disabled={savingProfile}
            className="px-6 py-3 rounded-full bg-[#0A0A0A] text-white text-xs font-semibold hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            {savingProfile ? 'Saving...' : 'Save Profile'}
          </button>
        </form>
      ) : (
        <div className="pt-8 space-y-5">
          {accountTab === 'orders' && activeOrders.length > 0 && (
            <p className="text-xs text-neutral-500">
              Showing all orders including {activeOrders.length} active shipment(s).
            </p>
          )}

          {ordersLoading ? (
            <div className="py-12 flex items-center justify-center">
              <Loader2 className="w-5 h-5 animate-spin text-neutral-400" />
            </div>
          ) : displayedOrders.length === 0 ? (
            <div className="py-16 border border-neutral-200 text-center">
              <Package className="w-8 h-8 text-neutral-300 mx-auto mb-3" />
              <p className="font-display text-2xl font-semibold mb-1">
                {accountTab === 'history' ? 'No past completed orders yet' : 'No orders placed yet'}
              </p>
              <p className="text-xs text-neutral-500 mb-5">
                Orders you place will appear here with real-time delivery tracking.
              </p>
              <button
                type="button"
                onClick={onBackToShop}
                className="px-6 py-2.5 rounded-full bg-[#0A0A0A] text-white text-xs font-semibold cursor-pointer"
              >
                Explore Collection
              </button>
            </div>
          ) : (
            displayedOrders.map((order) => {
              const isExpanded = expandedOrderId === order.id;
              const itemsList = orderItemsMap[order.id] || [];
              const stepIdx = TRACKING_STEPS.indexOf(order.status);

              return (
                <div key={order.id} className="border border-neutral-200 bg-white">
                  <div className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <img
                        src={order.primaryProductImage}
                        alt={order.primaryProductName}
                        referrerPolicy="no-referrer"
                        className="w-14 h-18 object-cover bg-neutral-100 shrink-0"
                      />
                      <div>
                        <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-500 mb-1">
                          <span className="font-mono font-semibold text-[#0A0A0A]">
                            {order.orderNumber}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>{formatDateTime(order.createdAt)}</span>
                          <span aria-hidden="true">·</span>
                          <span className="tabular-nums">
                            {order.totalQuantity} item{order.totalQuantity > 1 ? 's' : ''}
                          </span>
                        </div>
                        <h3 className="text-sm font-semibold text-[#0A0A0A]">
                          {order.primaryProductName}
                          {order.itemCount > 1 ? ` + ${order.itemCount - 1} more` : ''}
                        </h3>
                        <p className="text-xs text-neutral-600 mt-1 flex items-center gap-1.5">
                          {order.status === 'Cancelled' ? (
                            <>
                              <XCircle className="w-3.5 h-3.5 text-red-600" />
                              <span className="text-red-700 font-medium">Cancelled</span>
                            </>
                          ) : order.status === 'Delivered' ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                              <span className="text-emerald-800 font-medium">Delivered</span>
                            </>
                          ) : (
                            <>
                              <Truck className="w-3.5 h-3.5 text-[#0A0A0A]" />
                              <span className="font-medium text-[#0A0A0A]">
                                Status: {order.status}
                              </span>
                            </>
                          )}
                          <span aria-hidden="true">·</span>
                          <span>{order.paymentMethod}</span>
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-4">
                      <div className="text-left sm:text-right">
                        <div className="text-xs text-neutral-500">Total</div>
                        <div className="text-base font-semibold tabular-nums">
                          {formatCurrency(order.totalAmount)}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => toggleOrderDetails(order.id)}
                        className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full border border-neutral-300 text-xs font-medium hover:bg-neutral-100 transition-colors cursor-pointer"
                      >
                        <span>{isExpanded ? 'Hide Details' : 'Track & Details'}</span>
                        {isExpanded ? (
                          <ChevronUp className="w-3.5 h-3.5" />
                        ) : (
                          <ChevronDown className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>

                  {isExpanded && (
                    <div className="px-5 pb-6 pt-4 border-t border-neutral-100 bg-neutral-50/50 space-y-5">
                      {/* Order Tracking Progress */}
                      {order.status !== 'Cancelled' && (
                        <div>
                          <p className="text-[11px] uppercase tracking-wider text-neutral-500 mb-3">
                            Live Order Tracking
                          </p>
                          <div className="grid grid-cols-5 gap-2">
                            {TRACKING_STEPS.map((step, idx) => {
                              const reached = stepIdx >= idx;
                              return (
                                <div key={step} className="space-y-1.5">
                                  <div
                                    className={`h-1.5 w-full ${
                                      reached ? 'bg-[#0A0A0A]' : 'bg-neutral-200'
                                    }`}
                                  />
                                  <p
                                    className={`text-[11px] truncate ${
                                      reached
                                        ? 'font-semibold text-[#0A0A0A]'
                                        : 'text-neutral-400'
                                    }`}
                                  >
                                    {step}
                                  </p>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* Shipping Address & Items */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <div className="text-xs space-y-1">
                          <p className="font-semibold text-[#0A0A0A] flex items-center gap-1.5 mb-1">
                            <MapPin className="w-3.5 h-3.5" />
                            <span>Customer & Delivery Details</span>
                          </p>
                          <p className="text-neutral-800 font-medium">Name: {order.customerName}</p>
                          <p className="text-neutral-600">Phone: {order.phone}</p>
                          {order.location && (
                            <p className="text-neutral-700">Location: {order.location}</p>
                          )}
                          <p className="text-neutral-600">Address: {order.address}</p>
                          <p className="text-neutral-600">
                            {order.city}, {order.pinCode}
                          </p>
                        </div>

                        <div className="space-y-2.5">
                          <p className="text-xs font-semibold text-[#0A0A0A]">
                            Purchased Items
                          </p>
                          {itemsList.length === 0 ? (
                            <p className="text-xs text-neutral-400">Loading items...</p>
                          ) : (
                            itemsList.map((item) => (
                              <div
                                key={item.id}
                                className="flex items-center justify-between gap-3 text-xs bg-white p-2.5 border border-neutral-200"
                              >
                                <div className="flex items-center gap-2.5 min-w-0">
                                  <img
                                    src={item.productImage}
                                    alt={item.productName}
                                    referrerPolicy="no-referrer"
                                    className="w-9 h-12 object-cover bg-neutral-100 shrink-0"
                                  />
                                  <div className="min-w-0">
                                    <p className="font-medium text-[#0A0A0A] truncate">
                                      {item.productName}
                                    </p>
                                    <p className="text-neutral-500">
                                      Size {item.selectedSize} · {item.selectedColor} · Qty{' '}
                                      {item.quantity}
                                    </p>
                                  </div>
                                </div>
                                <span className="font-semibold tabular-nums shrink-0">
                                  {formatCurrency(item.lineTotal)}
                                </span>
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}
    </section>
  );
}
