import React, { useState, useEffect } from 'react';
import { 
  X, 
  Trophy, 
  Clock, 
  Calendar, 
  Gift, 
  HelpCircle, 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle, 
  Tv, 
  Bell, 
  Play, 
  Sparkles, 
  Users, 
  Check, 
  Award,
  ChevronRight,
  Flame,
  FileText,
  AlertTriangle
} from 'lucide-react';
import { WeeklyQuiz, WeeklyQuizSubmission, UserProfile } from '../types';
import QuizAdGateModal from './QuizAdGateModal';

interface QuizDetailsModalProps {
  language: string;
  quiz: WeeklyQuiz;
  userProfile?: UserProfile;
  isOpen: boolean;
  onClose: () => void;
  onStartQuiz: (quiz: WeeklyQuiz) => void;
  onJoinedSuccess: (quizId: string) => void;
  onViewLeaderboard: (quiz: WeeklyQuiz) => void;
  onViewResult?: (quiz: WeeklyQuiz, submission: WeeklyQuizSubmission) => void;
}

export default function QuizDetailsModal({
  language,
  quiz,
  userProfile,
  isOpen,
  onClose,
  onStartQuiz,
  onJoinedSuccess,
  onViewLeaderboard,
  onViewResult
}: QuizDetailsModalProps) {
  const [hasJoined, setHasJoined] = useState<boolean>(false);
  const [checkingJoinStatus, setCheckingJoinStatus] = useState<boolean>(true);
  const [showAdGate, setShowAdGate] = useState<boolean>(false);
  const [joiningLoading, setJoiningLoading] = useState<boolean>(false);
  const [notificationEnabled, setNotificationEnabled] = useState<boolean>(true);
  const [countdownString, setCountdownString] = useState<{ hours: string; mins: string; secs: string; label: string }>({
    hours: '00',
    mins: '00',
    secs: '00',
    label: ''
  });
  const [isLiveNow, setIsLiveNow] = useState<boolean>(false);

  const userId = userProfile?.name 
    ? `user-${userProfile.name.toLowerCase().replace(/\s+/g, '-')}`
    : 'user-guest';

  // Check if user has already joined this quiz
  useEffect(() => {
    if (!isOpen || !quiz?.id) return;

    let isMounted = true;
    const checkStatus = async () => {
      try {
        setCheckingJoinStatus(true);
        // Check if quiz.joinedUserIds has user
        if (quiz.joinedUserIds && Array.isArray(quiz.joinedUserIds) && quiz.joinedUserIds.includes(userId)) {
          if (isMounted) setHasJoined(true);
          return;
        }

        const res = await fetch(`/api/weekly-quiz/${quiz.id}/join-status?userId=${userId}`);
        if (res.ok) {
          const data = await res.json();
          if (isMounted) {
            setHasJoined(Boolean(data.hasJoined));
          }
        }
      } catch (e) {
        console.warn('Failed to verify join status:', e);
      } finally {
        if (isMounted) setCheckingJoinStatus(false);
      }
    };

    checkStatus();
    return () => { isMounted = false; };
  }, [isOpen, quiz?.id, userId]);

  // Live countdown calculation
  useEffect(() => {
    if (!quiz) return;

    const updateCountdown = () => {
      const startDateTime = new Date(`${quiz.startDate}T${quiz.startTime || '10:00'}:00`);
      const endDateTime = new Date(`${quiz.endDate}T${quiz.endTime || '22:00'}:00`);
      const now = new Date();

      if (now < startDateTime) {
        setIsLiveNow(false);
        const diffMs = startDateTime.getTime() - now.getTime();
        const totalSecs = Math.max(0, Math.floor(diffMs / 1000));
        const hours = Math.floor(totalSecs / 3600);
        const mins = Math.floor((totalSecs % 3600) / 60);
        const secs = totalSecs % 60;

        setCountdownString({
          hours: String(hours).padStart(2, '0'),
          mins: String(mins).padStart(2, '0'),
          secs: String(secs).padStart(2, '0'),
          label: language === 'bn' ? 'কুইজ শুরু হতে বাকি' : 'Quiz Starts In'
        });
      } else if (now >= startDateTime && now <= endDateTime) {
        setIsLiveNow(true);
        const diffMs = endDateTime.getTime() - now.getTime();
        const totalSecs = Math.max(0, Math.floor(diffMs / 1000));
        const hours = Math.floor(totalSecs / 3600);
        const mins = Math.floor((totalSecs % 3600) / 60);
        const secs = totalSecs % 60;

        setCountdownString({
          hours: String(hours).padStart(2, '0'),
          mins: String(mins).padStart(2, '0'),
          secs: String(secs).padStart(2, '0'),
          label: language === 'bn' ? '🔴 লাইভ চলছে (শেষ হতে বাকি)' : '🔴 LIVE NOW (Ends In)'
        });
      } else {
        setIsLiveNow(false);
        setCountdownString({
          hours: '00',
          mins: '00',
          secs: '00',
          label: language === 'bn' ? 'কুইজ সমাপ্ত হয়েছে' : 'Quiz Ended'
        });
      }
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, [quiz, language]);

  if (!isOpen || !quiz) return null;

  const userAttempt = (quiz as any).userAttempt;
  const isEnded = quiz.status === 'ended';
  const numberOfAds = quiz.numberOfAds ?? (quiz.requireAdsBeforeQuiz !== false ? 2 : 0);

  const handleJoinClick = () => {
    if (numberOfAds > 0) {
      setShowAdGate(true);
    } else {
      executeJoinDirectly();
    }
  };

  const executeJoinDirectly = async () => {
    try {
      setJoiningLoading(true);
      const res = await fetch(`/api/weekly-quiz/${quiz.id}/join`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          displayName: userProfile?.name || 'Learner',
          browserPushEnabled: notificationEnabled
        })
      });

      if (res.ok) {
        setHasJoined(true);
        onJoinedSuccess(quiz.id);
      }
    } catch (e) {
      console.error('Failed to join quiz:', e);
    } finally {
      setJoiningLoading(false);
    }
  };

  const handleAdPassCompleted = async () => {
    setShowAdGate(false);
    await executeJoinDirectly();
  };

  return (
    <>
      <div 
        id="quiz-details-modal-overlay" 
        className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto"
      >
        <div 
          id="quiz-details-modal-container"
          className="relative w-full max-w-3xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col animate-in fade-in zoom-in-95 duration-200"
        >
          {/* Top Header Banner */}
          <div className="relative p-5 sm:p-6 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border-b border-slate-800 flex items-start justify-between gap-4">
            <div className="flex items-start gap-3.5">
              <div className="p-3 bg-gradient-to-tr from-amber-500 to-amber-600 text-slate-950 rounded-2xl shadow-lg shadow-amber-500/20 shrink-0">
                <Trophy className="w-6 h-6 fill-current" />
              </div>
              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-2.5 py-0.5 bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[11px] font-black rounded-lg uppercase tracking-wider">
                    {language === 'bn' ? `সপ্তাহ #${quiz.weekNumber || 1}` : `Week #${quiz.weekNumber || 1}`}
                  </span>
                  {quiz.targetLevel && (
                    <span className="px-2.5 py-0.5 bg-indigo-500/20 border border-indigo-500/40 text-indigo-300 text-[11px] font-bold rounded-lg">
                      {quiz.targetLevel}
                    </span>
                  )}
                  {isLiveNow ? (
                    <span className="px-2.5 py-0.5 bg-red-500/20 border border-red-500/50 text-red-400 text-[11px] font-black rounded-lg uppercase tracking-wider animate-pulse flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-500"></span>
                      {language === 'bn' ? 'লাইভ চলছে' : 'LIVE NOW'}
                    </span>
                  ) : isEnded ? (
                    <span className="px-2.5 py-0.5 bg-slate-800 text-slate-400 text-[11px] font-bold rounded-lg">
                      {language === 'bn' ? 'সমাপ্ত' : 'ENDED'}
                    </span>
                  ) : (
                    <span className="px-2.5 py-0.5 bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[11px] font-bold rounded-lg flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {language === 'bn' ? 'নির্ধারিত কুইজ' : 'SCHEDULED'}
                    </span>
                  )}
                </div>

                <h2 className="text-lg sm:text-xl font-black text-white tracking-tight leading-snug">
                  {quiz.title}
                </h2>
                <p className="text-xs text-indigo-200/90 leading-relaxed max-w-xl">
                  {quiz.shortDescription || quiz.description}
                </p>
              </div>
            </div>

            <button
              id="quiz-details-close-btn"
              type="button"
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white bg-slate-800/80 hover:bg-slate-700 rounded-xl transition-all cursor-pointer shrink-0"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Scrollable Content Body */}
          <div className="p-5 sm:p-6 overflow-y-auto space-y-6 text-slate-200">
            
            {/* COUNTDOWN TIMER DISPLAY */}
            <div className="bg-gradient-to-r from-indigo-950/70 via-slate-900 to-indigo-950/70 border border-indigo-500/30 rounded-2xl p-4 text-center space-y-2 shadow-inner">
              <span className="text-xs font-black text-indigo-300 uppercase tracking-widest block">
                {countdownString.label}
              </span>
              <div className="flex items-center justify-center gap-2 sm:gap-3 text-white font-mono">
                <div className="bg-slate-950/80 border border-indigo-500/40 px-3 py-2 rounded-xl min-w-[54px]">
                  <span className="text-xl sm:text-2xl font-black text-amber-400 block leading-none">{countdownString.hours}</span>
                  <span className="text-[9px] text-slate-400 uppercase font-sans font-bold">{language === 'bn' ? 'ঘণ্টা' : 'Hours'}</span>
                </div>
                <span className="text-xl font-black text-indigo-400">:</span>
                <div className="bg-slate-950/80 border border-indigo-500/40 px-3 py-2 rounded-xl min-w-[54px]">
                  <span className="text-xl sm:text-2xl font-black text-amber-400 block leading-none">{countdownString.mins}</span>
                  <span className="text-[9px] text-slate-400 uppercase font-sans font-bold">{language === 'bn' ? 'মিনিট' : 'Mins'}</span>
                </div>
                <span className="text-xl font-black text-indigo-400">:</span>
                <div className="bg-slate-950/80 border border-indigo-500/40 px-3 py-2 rounded-xl min-w-[54px]">
                  <span className="text-xl sm:text-2xl font-black text-amber-400 block leading-none">{countdownString.secs}</span>
                  <span className="text-[9px] text-slate-400 uppercase font-sans font-bold">{language === 'bn' ? 'সেকেন্ড' : 'Secs'}</span>
                </div>
              </div>
            </div>

            {/* KEY HIGHLIGHTS METRICS (4 GRID) */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
              <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-3 text-center space-y-0.5">
                <span className="text-[10px] font-bold text-slate-400 uppercase block">
                  {language === 'bn' ? 'মোট প্রশ্ন' : 'Questions'}
                </span>
                <span className="text-sm sm:text-base font-black text-white">
                  {quiz.questionCount || quiz.questions?.length || 20} MCQ
                </span>
              </div>

              <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-3 text-center space-y-0.5">
                <span className="text-[10px] font-bold text-slate-400 uppercase block">
                  {language === 'bn' ? 'সময়সীমা' : 'Time Limit'}
                </span>
                <span className="text-sm sm:text-base font-black text-amber-400">
                  {quiz.timeLimit || 20} {language === 'bn' ? 'মিনিট' : 'Mins'}
                </span>
              </div>

              <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-3 text-center space-y-0.5">
                <span className="text-[10px] font-bold text-slate-400 uppercase block">
                  {language === 'bn' ? 'নেগেটিভ মার্ক' : 'Negative Mark'}
                </span>
                <span className="text-sm sm:text-base font-black text-rose-400">
                  {quiz.negativeMarking !== false ? `-${quiz.negativeMarksPerWrong || 0.25}` : '0.00'}
                </span>
              </div>

              <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-3 text-center space-y-0.5">
                <span className="text-[10px] font-bold text-slate-400 uppercase block">
                  {language === 'bn' ? 'অংশগ্রহণকারী' : 'Participants'}
                </span>
                <span className="text-sm sm:text-base font-black text-emerald-400">
                  {quiz.participantsCount || quiz.joinedUserIds?.length || 10}+
                </span>
              </div>
            </div>

            {/* SCHEDULE DATES & TIMES */}
            <div className="bg-slate-950/50 border border-slate-800/80 rounded-2xl p-3.5 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-indigo-400 shrink-0" />
                <div>
                  <span className="text-slate-400 block">{language === 'bn' ? 'আরম্ভ হওয়ার সময়:' : 'Start Date & Time:'}</span>
                  <span className="font-black text-white">{quiz.startDate} at {quiz.startTime || '10:00 AM'}</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                <div>
                  <span className="text-slate-400 block">{language === 'bn' ? 'সমাপ্তির সময়:' : 'End Date & Time:'}</span>
                  <span className="font-black text-white">{quiz.endDate} at {quiz.endTime || '11:59 PM'}</span>
                </div>
              </div>
            </div>

            {/* PRIZE SECTION */}
            <div className="bg-gradient-to-br from-amber-950/30 via-slate-900 to-amber-950/30 border border-amber-500/30 rounded-2xl p-4 sm:p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Gift className="w-4 h-4 text-amber-400" />
                  <span className="text-xs font-black text-amber-400 uppercase tracking-wider">
                    {language === 'bn' ? 'মেগা পুরস্কার বিবরণ' : 'Quiz Prize Details'}
                  </span>
                </div>
                {quiz.prizeValue && (
                  <span className="px-3 py-1 bg-amber-500 text-slate-950 font-black text-xs rounded-xl shadow-md">
                    {quiz.prizeValue}
                  </span>
                )}
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-4 bg-slate-950/60 p-3.5 rounded-xl border border-amber-500/20">
                {quiz.prizeImage ? (
                  <img
                    src={quiz.prizeImage}
                    alt={quiz.prizeName || 'Prize'}
                    referrerPolicy="no-referrer"
                    className="w-20 h-20 sm:w-24 sm:h-24 rounded-xl object-cover border border-amber-500/30 shadow-md shrink-0"
                  />
                ) : (
                  <div className="w-20 h-20 bg-amber-500/10 border border-amber-500/30 rounded-xl flex items-center justify-center text-amber-400 shrink-0">
                    <Trophy className="w-8 h-8" />
                  </div>
                )}

                <div className="space-y-1 text-center sm:text-left">
                  <h4 className="text-sm sm:text-base font-black text-white">
                    {quiz.prizeName || (language === 'bn' ? 'আকর্ষণীয় শিক্ষা পুরষ্কার ও মেডেল' : 'Exclusive Winner Study Gift')}
                  </h4>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {quiz.prizeDescription || (language === 'bn' 
                      ? 'সর্বোচ্চ নম্বর এবং দ্রুততম সময়ে কুইজ সম্পন্নকারী ১ম শিক্ষার্থী এই পুরস্কার পাবেন।' 
                      : 'Awarded to the 1st rank holder who finishes with maximum score and fastest time.')}
                  </p>
                  {quiz.prizeTerms && (
                    <p className="text-[11px] text-amber-300/80 font-medium">
                      ℹ️ {quiz.prizeTerms}
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* SUBJECTS LIST */}
            {quiz.subjects && quiz.subjects.length > 0 && (
              <div className="space-y-2">
                <span className="text-xs font-black text-slate-400 uppercase tracking-wider block">
                  {language === 'bn' ? 'অন্তর্ভুক্ত বিষয়সমূহ:' : 'Included Subjects:'}
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {quiz.subjects.map((sub, i) => (
                    <span key={i} className="px-3 py-1 bg-slate-800/80 border border-slate-700 text-indigo-300 text-xs font-bold rounded-xl">
                      {sub}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* RULES & INSTRUCTIONS */}
            <div className="bg-slate-950/60 border border-slate-800/90 rounded-2xl p-4 space-y-2.5 text-xs">
              <div className="flex items-center gap-2 text-indigo-300 font-black">
                <ShieldCheck className="w-4 h-4 text-indigo-400" />
                <span>{language === 'bn' ? 'কুইজের নিয়মাবলী ও শর্তাবলী' : 'Rules & Guidelines'}</span>
              </div>
              
              <ul className="space-y-1.5 text-slate-300 list-disc list-inside">
                {quiz.rules && quiz.rules.length > 0 ? (
                  quiz.rules.map((rule, idx) => (
                    <li key={idx} className="leading-relaxed">{rule}</li>
                  ))
                ) : (
                  <>
                    <li>{language === 'bn' ? 'প্রত্যেক শিক্ষার্থী শুধুমাত্র ১ বার অংশগ্রহণের সুযোগ পাবে।' : 'Each participant can attempt only once.'}</li>
                    <li>{language === 'bn' ? 'নির্ধারিত সময়ের মধ্যে সব প্রশ্নের উত্তর দিয়ে সাবমিট করতে হবে।' : 'Submit within the allotted time limit.'}</li>
                    <li>{language === 'bn' ? 'সঠিক উত্তরের জন্য ১ নম্বর এবং ভুল উত্তরের জন্য ০.২৫ নেগেটিভ মার্ক কাটা হবে।' : 'Correct: +1 mark, Incorrect: -0.25 penalty.'}</li>
                    <li>{language === 'bn' ? 'সর্বোচ্চ স্কোর ও দ্রুততম সময়ের ভিত্তিতে ১ম স্থান নির্বাচন করা হবে।' : 'Ranks calculated based on highest score and fastest time.'}</li>
                  </>
                )}
              </ul>
            </div>

            {/* ENTRY REQUIREMENTS & STATUS BANNER */}
            <div className="bg-slate-800/60 border border-slate-700/80 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2.5">
                {numberOfAds > 0 ? (
                  <div className="p-2 bg-purple-500/20 border border-purple-500/40 text-purple-300 rounded-xl">
                    <Tv className="w-4 h-4" />
                  </div>
                ) : (
                  <div className="p-2 bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 rounded-xl">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                )}
                <div>
                  <span className="font-black text-white block">
                    {numberOfAds > 0 
                      ? (language === 'bn' ? `এন্ট্রি ফি: ${numberOfAds}টি শর্ট এড (সম্পূর্ণ ফ্রি)` : `Entry: Watch ${numberOfAds} short ads for free pass`)
                      : (language === 'bn' ? 'এন্ট্রি ফি: সম্পূর্ণ ফ্রি' : 'Entry: 100% Free Entry')}
                  </span>
                  <span className="text-slate-400 text-[11px]">
                    {hasJoined 
                      ? (language === 'bn' ? '✓ আপনার এন্ট্রি কনফার্ম করা হয়েছে।' : '✓ Your entry is confirmed and unlocked.')
                      : (language === 'bn' ? 'কুইজে অংশ নিতে জয়েন বাটন চাপুন।' : 'Click Join Quiz below to secure your entry.')}
                  </span>
                </div>
              </div>

              {hasJoined && (
                <div className="px-3 py-1.5 bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold rounded-xl flex items-center gap-1.5 self-start sm:self-auto">
                  <Check className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? 'যুক্ত আছেন (Joined)' : 'Joined & Confirmed'}</span>
                </div>
              )}
            </div>

          </div>

          {/* Action Footer */}
          <div className="p-4 sm:p-5 bg-slate-950 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <button
              type="button"
              onClick={() => onViewLeaderboard(quiz)}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer transition-all"
            >
              <Trophy className="w-4 h-4 text-amber-400" />
              <span>{language === 'bn' ? 'লিডারবোর্ড' : 'Leaderboard'}</span>
            </button>

            <div className="flex items-center gap-2">
              {userAttempt ? (
                <button
                  type="button"
                  onClick={() => onViewResult && onViewResult(quiz, userAttempt)}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs rounded-xl shadow-lg flex items-center gap-1.5 cursor-pointer transition-all"
                >
                  <Award className="w-4 h-4" />
                  <span>{language === 'bn' ? 'ফলাফল দেখুন' : 'View Your Result'}</span>
                </button>
              ) : isEnded ? (
                <button
                  type="button"
                  disabled
                  className="px-5 py-2.5 bg-slate-800 text-slate-500 font-bold text-xs rounded-xl cursor-not-allowed"
                >
                  {language === 'bn' ? 'কুইজ সমাপ্ত' : 'Quiz Closed'}
                </button>
              ) : isLiveNow ? (
                <button
                  type="button"
                  onClick={() => {
                    if (!hasJoined && numberOfAds > 0) {
                      setShowAdGate(true);
                    } else {
                      onClose();
                      onStartQuiz(quiz);
                    }
                  }}
                  className="px-6 py-2.5 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-black text-xs rounded-xl shadow-lg shadow-red-600/30 flex items-center gap-2 cursor-pointer transition-all active:scale-95 animate-pulse"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>{language === 'bn' ? 'লাইভ কুইজ শুরু করুন' : 'Start Live Quiz Now'}</span>
                </button>
              ) : hasJoined ? (
                <div className="flex items-center gap-2">
                  <div className="px-4 py-2 bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-black text-xs rounded-xl flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>{language === 'bn' ? '✓ সফলভাবে যুক্ত হয়েছেন' : '✓ Successfully Joined'}</span>
                  </div>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={handleJoinClick}
                  disabled={joiningLoading}
                  className="px-6 py-2.5 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-amber-500/20 flex items-center gap-2 cursor-pointer transition-all active:scale-95"
                >
                  {numberOfAds > 0 ? <Tv className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
                  <span>
                    {numberOfAds > 0 
                      ? (language === 'bn' ? `${numberOfAds}টি এড দেখে ফ্রি এন্ট্রি নিন` : `Watch ${numberOfAds} Ads to Join`)
                      : (language === 'bn' ? 'কুইজে জয়েন করুন' : 'Join Weekly Quiz')}
                  </span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Ad Gate Modal */}
      {showAdGate && (
        <QuizAdGateModal
          language={language}
          quiz={quiz}
          requiredAdsCount={numberOfAds}
          onCompleted={handleAdPassCompleted}
          onClose={() => setShowAdGate(false)}
        />
      )}
    </>
  );
}
