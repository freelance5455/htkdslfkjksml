import { useMemo, useState } from 'react';
import { Download, Search, Trash2 } from 'lucide-react';
import { HistoryEntry, TransactionFilter } from '../types/fund';
import { formatMoney } from '../utils/fund';

interface TransactionLedgerProps {
  history: HistoryEntry[];
  onExportCSV: () => void;
  onRequestReset: () => void;
  onFocusProfit: () => void;
}

export function TransactionLedger({
  history,
  onExportCSV,
  onRequestReset,
  onFocusProfit,
}: TransactionLedgerProps) {
  const [filter, setFilter] = useState<TransactionFilter>('all');
  const [query, setQuery] = useState('');

  const reversedHistory = useMemo(() => {
    return history
      .map((entry, idx) => ({ ...entry, originalIndex: idx }))
      .reverse();
  }, [history]);

  const filteredHistory = useMemo(() => {
    const q = query.trim().toLowerCase();
    return reversedHistory.filter((item) => {
      const isProfit = item.amount >= 0;
      if (filter === 'profit' && !isProfit) return false;
      if (filter === 'withdrawal' && isProfit) return false;
      if (!q) return true;
      return (
        item.title.toLowerCase().includes(q) ||
        item.detail.toLowerCase().includes(q) ||
        item.date.toLowerCase().includes(q)
      );
    });
  }, [reversedHistory, filter, query]);

  return (
    <section
      id="history"
      aria-labelledby="history-heading"
      className="rounded-2xl border border-[#dfe7e2] bg-white p-5 sm:p-6"
    >
      <div className="flex flex-col gap-4 border-b border-[#e8efeb] pb-5 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h2 id="history-heading" className="text-lg font-bold text-[#16221c]">
            ٹرانزیکشن ہسٹری
          </h2>
          <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-[#64736b]">
            <span>کل اندراجات: {history.length}</span>
            <span aria-hidden="true">·</span>
            <span>نیا ریکارڈ سب سے اوپر</span>
          </div>
        </div>

        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div
            className="inline-flex items-center gap-1 rounded-xl bg-[#f1f5f3] p-1"
            role="tablist"
            aria-label="ٹرانزیکشن فلٹر"
          >
            <button
              type="button"
              role="tab"
              aria-selected={filter === 'all'}
              onClick={() => setFilter('all')}
              className={`min-h-[36px] rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                filter === 'all'
                  ? 'bg-white text-[#123b32] shadow-xs'
                  : 'text-[#5b6a62] hover:text-[#16221c]'
              }`}
            >
              تمام ({history.length})
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={filter === 'profit'}
              onClick={() => setFilter('profit')}
              className={`min-h-[36px] rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                filter === 'profit'
                  ? 'bg-white text-[#123b32] shadow-xs'
                  : 'text-[#5b6a62] hover:text-[#16221c]'
              }`}
            >
              منافع تقسیم
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={filter === 'withdrawal'}
              onClick={() => setFilter('withdrawal')}
              className={`min-h-[36px] rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                filter === 'withdrawal'
                  ? 'bg-white text-[#123b32] shadow-xs'
                  : 'text-[#5b6a62] hover:text-[#16221c]'
              }`}
            >
              رقم نکلوائی
            </button>
          </div>

          <div className="relative min-w-[220px]">
            <Search
              className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#6e7e75]"
              aria-hidden="true"
            />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="پارٹنر یا تفصیل تلاش کریں..."
              aria-label="ٹرانزیکشن تلاش کریں"
              className="min-h-[40px] w-full rounded-xl border border-[#d1ddd6] bg-[#fafcfb] pr-9 pl-3 text-sm text-[#16221c] placeholder:text-[#7a8880] focus:border-[#1d6b52] focus:bg-white focus:outline-none"
            />
          </div>
        </div>
      </div>

      {history.length === 0 ? (
        <div className="py-12 text-center">
          <p className="text-sm font-medium text-[#4a5951]">ابھی کوئی ٹرانزیکشن نہیں۔</p>
          <p className="mt-1 text-xs text-[#73827a]">
            جب آپ منافع تقسیم کریں گے یا رقم نکالیں گے تو مکمل تفصیل یہاں درج ہوگی۔
          </p>
          <button
            type="button"
            onClick={onFocusProfit}
            className="mt-4 inline-flex min-h-[40px] items-center justify-center rounded-xl bg-[#1d6b52] px-5 py-2 text-sm font-semibold text-white transition-colors hover:bg-[#165541] whitespace-nowrap shrink-0"
          >
            پہلا منافع درج کریں
          </button>
        </div>
      ) : filteredHistory.length === 0 ? (
        <div className="py-10 text-center">
          <p className="text-sm font-medium text-[#4a5951]">
            تلاش یا فلٹر کے مطابق کوئی ریکارڈ نہیں ملا۔
          </p>
          <button
            type="button"
            onClick={() => {
              setFilter('all');
              setQuery('');
            }}
            className="mt-3 text-xs font-semibold text-[#1d6b52] underline-offset-4 hover:underline"
          >
            تمام فلٹر صاف کریں
          </button>
        </div>
      ) : (
        <div className="mt-2 overflow-x-auto">
          <table className="w-full border-collapse text-right">
            <thead>
              <tr className="border-b border-[#e8efeb] text-xs font-semibold text-[#64736b]">
                <th scope="col" className="py-3 pl-4 font-semibold">
                  تاریخ و وقت
                </th>
                <th scope="col" className="py-3 px-4 font-semibold">
                  اندراج اور تفصیل
                </th>
                <th scope="col" className="py-3 px-4 font-semibold">
                  نوعیت
                </th>
                <th scope="col" className="py-3 pr-4 text-left font-semibold">
                  رقم (PKR)
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#eef3f0] text-sm">
              {filteredHistory.map((item) => {
                const isProfit = item.amount >= 0;
                return (
                  <tr
                    key={`${item.originalIndex}-${item.date}`}
                    className="transition-colors hover:bg-[#f8fbf9]"
                  >
                    <td className="py-3.5 pl-4 align-top text-xs text-[#64736b] whitespace-nowrap">
                      <span dir="ltr" className="font-num inline-block">
                        {item.date}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 align-top">
                      <div className="font-semibold text-[#16221c]">{item.title}</div>
                      <div className="mt-0.5 text-xs text-[#64736b]">{item.detail}</div>
                    </td>
                    <td className="py-3.5 px-4 align-top text-xs font-medium whitespace-nowrap">
                      <span className={isProfit ? 'text-[#1d6b52]' : 'text-[#b42318]'}>
                        {isProfit ? 'منافع تقسیم' : 'رقم نکلوائی'}
                      </span>
                    </td>
                    <td className="py-3.5 pr-4 text-left align-top whitespace-nowrap">
                      <span
                        dir="ltr"
                        className={`font-num inline-block font-semibold ${
                          isProfit ? 'text-[#123b32]' : 'text-[#b42318]'
                        }`}
                      >
                        {formatMoney(item.amount)}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <div className="mt-6 flex flex-col gap-3 border-t border-[#e8efeb] pt-5 sm:flex-row sm:items-center sm:justify-between">
        <button
          type="button"
          onClick={onExportCSV}
          disabled={history.length === 0}
          className="inline-flex min-h-[42px] items-center justify-center gap-2 rounded-xl bg-[#eaf2ed] px-5 py-2.5 text-sm font-semibold text-[#123b32] transition-colors hover:bg-[#dce9e1] disabled:cursor-not-allowed disabled:opacity-50 whitespace-nowrap shrink-0"
        >
          <Download className="h-4 w-4" aria-hidden="true" />
          <span>ہسٹری CSV میں محفوظ کریں</span>
        </button>

        <button
          type="button"
          onClick={onRequestReset}
          className="inline-flex min-h-[42px] items-center justify-center gap-2 rounded-xl bg-[#fff0ef] px-5 py-2.5 text-sm font-semibold text-[#b42318] transition-colors hover:bg-[#fee2e0] whitespace-nowrap shrink-0"
        >
          <Trash2 className="h-4 w-4" aria-hidden="true" />
          <span>تمام ڈیٹا ری سیٹ کریں</span>
        </button>
      </div>
    </section>
  );
}
