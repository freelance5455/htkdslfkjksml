import React from 'react';

interface MinecraftHungerProps {
  hunger?: number; // 0 to 20
  maxHunger?: number;
}

export const MinecraftHunger: React.FC<MinecraftHungerProps> = ({ hunger = 20, maxHunger = 10 }) => {
  // Each drumstick / shank = 2 hunger points. 20 hunger = 10 hunger shanks.
  const totalShanks = Math.max(maxHunger, Math.ceil(hunger / 2));

  const shanks: ('full' | 'half' | 'empty')[] = [];
  for (let i = 0; i < totalShanks; i++) {
    const hungerLeft = hunger - i * 2;
    if (hungerLeft >= 2) {
      shanks.push('full');
    } else if (hungerLeft >= 1) {
      shanks.push('half');
    } else {
      shanks.push('empty');
    }
  }

  const hungerCountDisplay = (Math.max(0, hunger) / 2).toFixed(hunger % 2 === 0 ? 0 : 1);

  return (
    <div className="flex items-center gap-1.5" title={`Hunger: ${hunger} / 20 (${hungerCountDisplay} Keulen)`}>
      <div className="flex items-center -space-x-0.5">
        {shanks.slice(0, 10).map((type, idx) => (
          <svg
            key={idx}
            viewBox="0 0 9 9"
            className="w-3.5 h-3.5 pixelated drop-shadow-xs shrink-0"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Dark outline of Minecraft shank */}
            <path
              d="M3 1h3v1H3V1zm3 1h2v3H6V2zm-3 3h1v2H3V5zm-2 2h2v1H1V7zm5-1h1v1H6V6zm1-2h1v1H7V4zm-5 1h1v1H2V5z"
              fill="#18181b"
            />
            {/* Empty placeholder background */}
            <path
              d="M3 2h3v1H3V2zm0 1h4v2H3V3zm1 2h2v1H4V5z"
              fill="#271c10"
            />

            {/* Full Hunger Shank */}
            {type === 'full' && (
              <>
                {/* Meat base color */}
                <path
                  d="M3 2h3v1H3V2zm0 1h4v2H3V3zm1 2h2v1H4V5z"
                  fill="#c26a27"
                />
                {/* Highlights */}
                <rect x="4" y="2" width="2" height="1" fill="#ea8d46" />
                <rect x="5" y="3" width="1" height="1" fill="#ea8d46" />
                {/* Dark shading */}
                <path
                  d="M3 4h1v1H3V4zm3 0h1v1H6V4zm-2 1h1v1H4V5z"
                  fill="#8c4015"
                />
                {/* Bone stem at bottom left */}
                <rect x="1" y="7" width="2" height="1" fill="#e2d8c3" />
                <rect x="2" y="6" width="1" height="1" fill="#c4b89e" />
              </>
            )}

            {/* Half Hunger Shank */}
            {type === 'half' && (
              <>
                <path
                  d="M4 2h2v1H4V2zm1 1h2v2H5V3zm0 2h1v1H5V5z"
                  fill="#c26a27"
                />
                <rect x="5" y="2" width="1" height="1" fill="#ea8d46" />
                <rect x="1" y="7" width="2" height="1" fill="#e2d8c3" />
                <rect x="2" y="6" width="1" height="1" fill="#c4b89e" />
              </>
            )}

            {/* Empty shank bone */}
            {type === 'empty' && (
              <>
                <rect x="1" y="7" width="1" height="1" fill="#5c5240" />
              </>
            )}
          </svg>
        ))}
      </div>
      <span className="text-[11px] font-mono font-medium text-amber-300 ml-0.5 leading-none">
        {hungerCountDisplay}
      </span>
    </div>
  );
};
