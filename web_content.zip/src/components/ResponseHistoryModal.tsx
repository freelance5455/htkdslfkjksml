import React, { useState, useEffect } from 'react';
import {
  X,
  History,
  Check,
  Copy,
  Trash2,
  Edit3,
  RotateCcw,
  Plus,
  Bot,
  Sparkles,
  FileText,
  AlertCircle,
} from 'lucide-react';
import { ChatMessage } from '../types/index.ts';
import { MarkdownView } from './MarkdownView.tsx';

interface ResponseHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  message: ChatMessage | null;
  onSelectAlternative: (messageId: string, index: number) => void;
  onDeleteAlternative: (messageId: string, index: number) => void;
  onEditAlternative: (messageId: string, index: number, newContent: string) => void;
  onAddManualAlternative: (messageId: string, content: string) => void;
  onRegenerateNewAlternative: (messageId: string) => void;
  isStreaming?: boolean;
  botName?: string;
  botAvatar?: string;
}

export const ResponseHistoryModal: React.FC<ResponseHistoryModalProps> = ({
  isOpen,
  onClose,
  message,
  onSelectAlternative,
  onDeleteAlternative,
  onEditAlternative,
  onAddManualAlternative,
  onRegenerateNewAlternative,
  isStreaming,
  botName = 'Nexus AI',
  botAvatar,
}) => {
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);
  const [editingIdx, setEditingIdx] = useState<number | null>(null);
  const [editText, setEditText] = useState('');
  const [isAddingManual, setIsAddingManual] = useState(false);
  const [manualText, setManualText] = useState('');

  // Close with Esc key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen || !message) return null;

  // Ensure alternatives list is robustly constructed
  const alternatives =
    message.alternatives && message.alternatives.length > 0
      ? message.alternatives
      : message.content
      ? [message.content]
      : [];

  const activeIndex = message.activeAlternativeIndex ?? Math.max(0, alternatives.length - 1);

  const handleCopy = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 2000);
  };

  const handleStartEdit = (idx: number, currentText: string) => {
    setEditingIdx(idx);
    setEditText(currentText);
    setIsAddingManual(false);
  };

  const handleSaveEdit = (idx: number) => {
    if (editText.trim()) {
      onEditAlternative(message.id, idx, editText.trim());
      setEditingIdx(null);
      setEditText('');
    }
  };

  const handleSaveManual = () => {
    if (manualText.trim()) {
      onAddManualAlternative(message.id, manualText.trim());
      setIsAddingManual(false);
      setManualText('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] sm:max-h-[85vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/90 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <History className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white tracking-tight">
                  Riwayat Respon Bot
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  {alternatives.length} Versi
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Pilih versi aktif, tambahkan respon baru, atau sesuaikan variasi respon layaknya di JanitorAI.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            title="Tutup dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body: Scrollable list of versions */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {alternatives.map((altText, idx) => {
            const isActive = idx === activeIndex;
            const wordCount = altText.split(/\s+/).filter(Boolean).length;
            const charCount = altText.length;
            const isEditingThis = editingIdx === idx;

            return (
              <div
                key={idx}
                className={`rounded-xl border transition-all duration-200 overflow-hidden ${
                  isActive
                    ? 'border-indigo-500/70 bg-slate-950/90 shadow-lg shadow-indigo-500/5 ring-1 ring-indigo-500/30'
                    : 'border-slate-800 bg-slate-950/50 hover:border-slate-700'
                }`}
              >
                {/* Version Card Header */}
                <div
                  className={`px-4 py-2.5 flex items-center justify-between border-b text-xs ${
                    isActive
                      ? 'bg-indigo-950/30 border-indigo-500/30 text-indigo-200'
                      : 'bg-slate-900/50 border-slate-800/80 text-slate-400'
                  }`}
                >
                  <div className="flex items-center gap-2 font-medium">
                    <span className="font-semibold text-slate-200">
                      Versi {idx + 1}
                    </span>
                    {isActive ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        <Check className="w-2.5 h-2.5" />
                        Sedang Aktif di Obrolan
                      </span>
                    ) : (
                      <span className="text-[11px] text-slate-500 font-mono">
                        Variasi Alternatif
                      </span>
                    )}
                    <span className="text-[11px] text-slate-500 hidden sm:inline">
                      • {wordCount} kata ({charCount} karakter)
                    </span>
                  </div>

                  {/* Quick Card Action Buttons */}
                  <div className="flex items-center gap-1.5">
                    {!isActive && (
                      <button
                        onClick={() => onSelectAlternative(message.id, idx)}
                        className="px-2.5 py-1 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-[11px] flex items-center gap-1 transition cursor-pointer shadow-xs"
                        title="Tampilkan versi ini sebagai respon utama"
                      >
                        <Check className="w-3 h-3" />
                        <span>Pilih Versi Ini</span>
                      </button>
                    )}

                    <button
                      onClick={() => handleCopy(altText, idx)}
                      className="p-1.5 rounded-md hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition cursor-pointer"
                      title="Salin teks respon ini"
                    >
                      {copiedIdx === idx ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>

                    <button
                      onClick={() => handleStartEdit(idx, altText)}
                      className="p-1.5 rounded-md hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition cursor-pointer"
                      title="Edit teks versi ini"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>

                    {alternatives.length > 1 && (
                      <button
                        onClick={() => {
                          if (
                            confirm(
                              `Apakah Anda yakin ingin menghapus Versi ${
                                idx + 1
                              }? Tindakan ini tidak dapat dibatalkan.`
                            )
                          ) {
                            onDeleteAlternative(message.id, idx);
                          }
                        }}
                        className="p-1.5 rounded-md hover:bg-slate-800 text-slate-400 hover:text-rose-400 transition cursor-pointer"
                        title="Hapus variasi ini dari riwayat"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Version Content */}
                <div className="p-4 select-text">
                  {isEditingThis ? (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-xs text-slate-400">
                        <span className="font-medium text-indigo-300">
                          Mengedit Versi {idx + 1}
                        </span>
                        <span className="font-mono text-[11px]">
                          {editText.length} karakter
                        </span>
                      </div>
                      <textarea
                        value={editText}
                        onChange={(e) => setEditText(e.target.value)}
                        rows={7}
                        className="w-full bg-slate-950 border border-indigo-500 rounded-xl p-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 leading-relaxed font-sans resize-y"
                        placeholder="Ketik perubahan teks tanggapan bot..."
                      />
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleSaveEdit(idx)}
                          className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-xs font-medium text-white transition cursor-pointer shadow-sm"
                        >
                          Simpan Versi Ini
                        </button>
                        <button
                          onClick={() => setEditingIdx(null)}
                          className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 transition cursor-pointer"
                        >
                          Batal
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="max-h-72 overflow-y-auto pr-1">
                      <MarkdownView content={altText} fontSize="md" />
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {/* Form to Add Manual Alternative */}
          {isAddingManual ? (
            <div className="rounded-xl border border-indigo-500/60 bg-slate-950 p-4 space-y-3 animate-in fade-in duration-150">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-indigo-300 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-indigo-400" />
                  Tambah Respon Alternatif Secara Manual
                </span>
                <span className="text-slate-500 font-mono text-[11px]">
                  {manualText.length} karakter
                </span>
              </div>
              <textarea
                value={manualText}
                onChange={(e) => setManualText(e.target.value)}
                rows={6}
                autoFocus
                placeholder="Tuliskan respon buatan Anda sendiri atau salinan dari roleplay untuk dijadikan salah satu variasi..."
                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 leading-relaxed resize-y"
              />
              <div className="flex items-center gap-2">
                <button
                  onClick={handleSaveManual}
                  disabled={!manualText.trim()}
                  className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-xs font-medium text-white transition cursor-pointer shadow-sm"
                >
                  Simpan sebagai Variasi Baru
                </button>
                <button
                  onClick={() => setIsAddingManual(false)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 transition cursor-pointer"
                >
                  Batal
                </button>
              </div>
            </div>
          ) : null}
        </div>

        {/* Modal Footer Toolbar */}
        <div className="px-5 py-3.5 border-t border-slate-800 bg-slate-900/90 flex flex-wrap items-center justify-between gap-2 shrink-0">
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => {
                onRegenerateNewAlternative(message.id);
                onClose();
              }}
              disabled={isStreaming}
              className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-medium text-xs flex items-center gap-1.5 transition cursor-pointer shadow-sm shadow-indigo-600/20"
              title="Minta AI membuat variasi respon baru untuk pertanyaan ini"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>+ Buat Respon Baru (Generate Swipe)</span>
            </button>

            {!isAddingManual && (
              <button
                onClick={() => setIsAddingManual(true)}
                className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs flex items-center gap-1.5 transition cursor-pointer border border-slate-700"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Tulis Respon Manual</span>
              </button>
            )}
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs transition cursor-pointer"
          >
            Selesai
          </button>
        </div>
      </div>
    </div>
  );
};
