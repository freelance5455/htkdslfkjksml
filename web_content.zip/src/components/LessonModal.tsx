import { useState, useEffect } from 'react';
import { Student, Lesson } from '../types';
import { X, Calendar, Clock, DollarSign, Trash2 } from 'lucide-react';

interface LessonModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: Student[];
  initialLesson?: Lesson | null;
  defaultDate?: string;
  onSaveLesson: (lessonData: Partial<Lesson>) => void;
  onDeleteLesson?: (lessonId: string) => void;
}

export const LessonModal = ({
  isOpen,
  onClose,
  students,
  initialLesson,
  defaultDate,
  onSaveLesson,
  onDeleteLesson,
}: LessonModalProps) => {
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');
  const [date, setDate] = useState<string>('2026-10-07');
  const [time, setTime] = useState<string>('16:00');
  const [durationMinutes, setDurationMinutes] = useState<number>(60);
  const [isPaymentLesson, setIsPaymentLesson] = useState<boolean>(false);
  const [status, setStatus] = useState<'scheduled' | 'completed' | 'cancelled'>('scheduled');
  const [topicNotes, setTopicNotes] = useState<string>('');
  const [homework, setHomework] = useState<string>('');

  const activeStudent = students.find((s) => s.id === selectedStudentId);

  useEffect(() => {
    if (initialLesson) {
      setSelectedStudentId(initialLesson.studentId);
      setDate(initialLesson.date);
      setTime(initialLesson.time);
      setDurationMinutes(initialLesson.durationMinutes || 60);
      setIsPaymentLesson(initialLesson.isPaymentLesson);
      setStatus(initialLesson.status);
      setTopicNotes(initialLesson.topicNotes || '');
      setHomework(initialLesson.homework || '');
    } else {
      const defaultStudent = students[0];
      if (defaultStudent) {
        setSelectedStudentId(defaultStudent.id);
        const willBePayment = defaultStudent.lessonsInCurrentCycle + 1 === defaultStudent.paymentFrequency;
        setIsPaymentLesson(willBePayment);
      }
      setDate(defaultDate || '2026-10-07');
      setTime('16:00');
      setDurationMinutes(60);
      setStatus('scheduled');
      setTopicNotes('');
      setHomework('');
    }
  }, [initialLesson, defaultDate, students, isOpen]);

  const handleStudentSelect = (id: string) => {
    setSelectedStudentId(id);
    const s = students.find((st) => st.id === id);
    if (s && !initialLesson) {
      const willBePayment = s.lessonsInCurrentCycle + 1 === s.paymentFrequency;
      setIsPaymentLesson(willBePayment);
    }
  };

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeStudent) return;

    onSaveLesson({
      studentId: activeStudent.id,
      studentName: activeStudent.name,
      subject: activeStudent.subject,
      date,
      time,
      durationMinutes,
      isPaymentLesson,
      status,
      rate: activeStudent.hourlyRate,
      currency: activeStudent.currency,
      cycleNumber: activeStudent.lessonsInCurrentCycle + (status === 'completed' ? 1 : 0),
      topicNotes: topicNotes.trim(),
      homework: homework.trim(),
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-[#121214] text-stone-100 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-zinc-800">
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-zinc-900 border border-zinc-800 text-stone-200 rounded-xl">
              <Calendar className="w-5 h-5 text-rose-400" />
            </div>
            <div>
              <h3 className="font-bold text-lg font-serif text-white">
                {initialLesson ? 'Ders Detayı ve Düzenle' : 'Yeni Ders Planla'}
              </h3>
              <p className="text-xs text-stone-400">
                Tarih, saat ve ödeme durumu ayarları
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-white bg-zinc-900 rounded-xl transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="py-4 space-y-4">
          <div>
            <label className="block text-xs font-bold text-stone-300 uppercase tracking-wider mb-1">
              Öğrenci *
            </label>
            <select
              value={selectedStudentId}
              onChange={(e) => handleStudentSelect(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm bg-zinc-900 border border-zinc-800 rounded-xl font-semibold text-white"
            >
              {students.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.subject === 'english' ? '🇬🇧 İngilizce' : '🇹🇷 Türkçe'} • {s.hourlyRate} {s.currency})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-stone-300 uppercase tracking-wider mb-1">
                Ders Tarihi
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-zinc-900 border border-zinc-800 rounded-xl font-mono font-medium text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-stone-300 uppercase tracking-wider mb-1">
                Ders Saati
              </label>
              <input
                type="time"
                required
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-zinc-900 border border-zinc-800 rounded-xl font-mono font-bold text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-stone-300 uppercase tracking-wider mb-1">
                Ders Durumu
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-zinc-900 border border-zinc-800 rounded-xl font-semibold text-white"
              >
                <option value="scheduled">Planlandı (Yaklaşan)</option>
                <option value="completed">Tamamlandı</option>
                <option value="cancelled">İptal Edildi</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-300 uppercase tracking-wider mb-1">
                Ders Süresi
              </label>
              <select
                value={durationMinutes}
                onChange={(e) => setDurationMinutes(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs bg-zinc-900 border border-zinc-800 rounded-xl font-semibold text-white"
              >
                <option value={45}>45 Dakika</option>
                <option value={60}>60 Dakika (1 Saat)</option>
                <option value={90}>90 Dakika (1.5 Saat)</option>
                <option value={120}>120 Dakika (2 Saat)</option>
              </select>
            </div>
          </div>

          {/* Ödeme Dersi İşareti */}
          <div
            onClick={() => setIsPaymentLesson(!isPaymentLesson)}
            className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
              isPaymentLesson
                ? 'bg-amber-950/40 border-amber-500/60 ring-2 ring-amber-500/20'
                : 'bg-zinc-900 border-zinc-800 hover:bg-zinc-850'
            }`}
          >
            <div className="flex items-center gap-3">
              <div
                className={`p-2 rounded-xl shrink-0 ${
                  isPaymentLesson ? 'bg-amber-400 text-stone-950 font-bold' : 'bg-zinc-800 text-stone-400'
                }`}
              >
                <DollarSign className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-white">
                  Bu Ders Ödeme Alınacak Ders Mi?
                </div>
                <div className="text-[11px] text-stone-400 mt-0.5">
                  İşaretlendiğinde sistem bu ders öncesi ekstra ödeme bildirimi gönderir.
                </div>
              </div>
            </div>

            <input
              type="checkbox"
              checked={isPaymentLesson}
              onChange={() => {}}
              className="w-4 h-4 text-amber-500 rounded cursor-pointer pointer-events-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-300 uppercase tracking-wider mb-1">
              İşlenen Konu / Hedef
            </label>
            <input
              type="text"
              placeholder="Örn: IELTS Writing Task 2, Present Continuous..."
              value={topicNotes}
              onChange={(e) => setTopicNotes(e.target.value)}
              className="w-full px-3.5 py-2 text-xs bg-zinc-900 border border-zinc-800 rounded-xl text-white placeholder:text-stone-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-300 uppercase tracking-wider mb-1">
              Verilen Ödev / Görev
            </label>
            <input
              type="text"
              placeholder="Örn: 20 kelime ezberi, test çözümü..."
              value={homework}
              onChange={(e) => setHomework(e.target.value)}
              className="w-full px-3.5 py-2 text-xs bg-zinc-900 border border-zinc-800 rounded-xl text-white placeholder:text-stone-500"
            />
          </div>

          <div className="pt-2 flex items-center justify-between gap-2.5">
            {initialLesson && onDeleteLesson ? (
              <button
                type="button"
                onClick={() => {
                  if (window.confirm('Bu dersi takvimden silmek istediğinize emin misiniz?')) {
                    onDeleteLesson(initialLesson.id);
                    onClose();
                  }
                }}
                className="p-2 text-rose-400 hover:bg-rose-950/40 rounded-xl transition-all cursor-pointer flex items-center gap-1 text-xs font-bold"
              >
                <Trash2 className="w-4 h-4" />
                <span>Dersi Sil</span>
              </button>
            ) : <div />}

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 text-xs font-semibold text-stone-400 hover:text-white rounded-xl transition-all cursor-pointer"
              >
                İptal
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white rounded-xl shadow-md shadow-rose-950/40 transition-all cursor-pointer active:scale-95"
              >
                {initialLesson ? 'Güncelle' : 'Dersi Planla'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
