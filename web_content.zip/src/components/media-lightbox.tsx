import { X } from "lucide-react";
import { useCallback, useEffect, useRef, useState, type Touch, type WheelEvent } from "react";
import { createPortal } from "react-dom";

export function MediaLightbox({
  src,
  onClose,
}: {
  src: string;
  onClose: () => void;
}) {
  const [scale, setScale] = useState(1);
  const [x, setX] = useState(0);
  const [y, setY] = useState(0);
  const pinch = useRef({ dist: 0, scale: 1 });
  const drag = useRef({ x: 0, y: 0, ox: 0, oy: 0, on: false });

  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  const onWheel = useCallback((e: WheelEvent) => {
    e.preventDefault();
    const next = scale * (e.deltaY < 0 ? 1.12 : 0.89);
    setScale(Math.min(40, Math.max(0.12, next)));
  }, [scale]);

  const dist = (a: Touch, b: Touch) =>
    Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);

  return createPortal(
    <div
      className="fixed inset-0 z-[80] bg-black touch-none"
      onWheel={onWheel}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <button
        type="button"
        className="absolute right-3 top-3 z-10 flex size-11 items-center justify-center rounded-full bg-black text-white"
        onClick={onClose}
        aria-label="Close"
      >
        <X className="size-5" />
      </button>
      <div
        className="flex size-full items-center justify-center overflow-hidden"
        onTouchStart={(e) => {
          if (e.touches.length === 2 && e.touches[0] && e.touches[1]) {
            pinch.current = { dist: dist(e.touches[0], e.touches[1]), scale };
            drag.current.on = false;
          } else if (e.touches.length === 1 && e.touches[0]) {
            drag.current = {
              x: e.touches[0].clientX,
              y: e.touches[0].clientY,
              ox: x,
              oy: y,
              on: true,
            };
          }
        }}
        onTouchMove={(e) => {
          if (e.touches.length === 2 && e.touches[0] && e.touches[1] && pinch.current.dist) {
            const d = dist(e.touches[0], e.touches[1]);
            setScale(Math.min(40, Math.max(0.12, pinch.current.scale * (d / pinch.current.dist))));
          } else if (drag.current.on && e.touches[0] && scale > 1) {
            setX(drag.current.ox + (e.touches[0].clientX - drag.current.x));
            setY(drag.current.oy + (e.touches[0].clientY - drag.current.y));
          }
        }}
        onTouchEnd={() => {
          drag.current.on = false;
        }}
        onDoubleClick={() => {
          setScale((s) => (s > 1 ? 1 : 2.4));
          setX(0);
          setY(0);
        }}
      >
        <img
          src={src}
          alt=""
          draggable={false}
          className="max-h-none max-w-none select-none"
          style={{
            transform: `translate3d(${x}px, ${y}px, 0) scale(${scale})`,
            transformOrigin: "center center",
          }}
        />
      </div>
    </div>,
    document.body,
  );
}
