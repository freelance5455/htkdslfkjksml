import React, { useRef, useEffect } from 'react';
import { AppItem, LauncherSettings } from '../types/launcher';
import { BrandIcon } from './BrandIcons';
import { Plus, SlidersHorizontal, Check } from 'lucide-react';

interface AppDockProps {
  apps: AppItem[];
  focusedDockIndex: number;
  isDockFocused: boolean;
  isReorderFocused: boolean;
  isReorderMode: boolean;
  settings: LauncherSettings;
  onFocusApp: (index: number) => void;
  onSelectApp: (app: AppItem) => void;
  onOpenAddModal: () => void;
  onToggleReorderMode: () => void;
}

export const AppDock: React.FC<AppDockProps> = ({
  apps,
  focusedDockIndex,
  isDockFocused,
  isReorderFocused,
  isReorderMode,
  settings,
  onFocusApp,
  onSelectApp,
  onOpenAddModal,
  onToggleReorderMode,
}) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Auto-scroll the focused tile to center in view
  useEffect(() => {
    if (isDockFocused) {
      const el =
        focusedDockIndex === apps.length
          ? document.getElementById('dock-add-tile')
          : document.getElementById(`dock-tile-${apps[focusedDockIndex]?.id}`);

      if (el && scrollContainerRef.current) {
        el.scrollIntoView({
          behavior: 'smooth',
          block: 'nearest',
          inline: 'center',
        });
      }
    }
  }, [focusedDockIndex, isDockFocused, apps]);

  const focusedApp = apps[focusedDockIndex] || apps[0];

  return (
    <div className="w-full max-w-7xl mx-auto px-6 md:px-12 flex flex-col items-center justify-center select-none py-10">
      {/* Floating Glassmorphic Dock Container */}
      <div className="relative w-full max-w-5xl flex flex-col items-center">
        {/* Soft Ambient Glow under the Dock reflecting the focused app's brand color */}
        {!settings.performanceMode && focusedApp && (
          <div
            className="absolute -inset-4 rounded-[48px] opacity-25 filter blur-2xl transition-all duration-700 pointer-events-none"
            style={{
              background: `radial-gradient(ellipse at center, ${focusedApp.accentColor || '#0071e3'} 0%, rgba(0,0,0,0) 75%)`,
            }}
          />
        )}

        {/* The Glassmorphic Dock Bar */}
        <div
          className={`relative w-full p-6 md:p-8 rounded-[44px] border border-white/20 bg-white/[0.07] backdrop-blur-3xl shadow-[0_30px_80px_rgba(0,0,0,0.8),inset_0_1px_1px_rgba(255,255,255,0.3)] transition-all duration-300 ${
            isReorderMode ? 'ring-2 ring-amber-400/60' : ''
          }`}
        >
          <div
            ref={scrollContainerRef}
            className="flex items-center justify-start md:justify-center gap-6 md:gap-8 overflow-x-auto py-4 px-4 no-scrollbar scroll-smooth"
          >
            {apps.map((app, index) => {
              const isFocused = isDockFocused && focusedDockIndex === index;

              return (
                <div
                  key={app.id}
                  id={`dock-tile-${app.id}`}
                  onClick={() => onSelectApp(app)}
                  onMouseEnter={() => onFocusApp(index)}
                  className={`relative shrink-0 flex flex-col items-center cursor-pointer transition-all duration-200 ${
                    isReorderMode ? 'tv-wiggle' : ''
                  }`}
                >
                  {/* Apple TV Squircle Tile */}
                  <div
                    className={`w-22 h-22 md:w-28 md:h-28 rounded-[28px] flex items-center justify-center p-4 transition-all duration-200 relative overflow-hidden ${
                      isFocused
                        ? 'tv-focused ring-4 ring-white shadow-[0_25px_50px_rgba(0,0,0,0.9),0_0_35px_rgba(255,255,255,0.35)] scale-115 z-30'
                        : 'hover:scale-105 border border-white/15'
                    }`}
                    style={{
                      background: app.iconBgGradient,
                    }}
                  >
                    {/* Glass sheen reflection overlay */}
                    {!settings.performanceMode && (
                      <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-white/25 pointer-events-none" />
                    )}

                    {/* Specular rim */}
                    <div className="absolute inset-0 rounded-[28px] border border-white/20 pointer-events-none" />

                    {/* Brand Vector Icon */}
                    <BrandIcon
                      brandKey={app.brandKey}
                      size={54}
                      className="w-13 h-13 md:w-16 md:h-16 drop-shadow-xl relative z-10 transition-transform group-hover:scale-110"
                    />

                    {/* Custom badge */}
                    {app.custom && (
                      <div className="absolute top-2 right-2 px-1.5 py-0.5 rounded text-[8px] font-mono font-bold bg-black/60 text-slate-300 border border-white/10">
                        APP
                      </div>
                    )}
                  </div>

                  {/* Soft Tile Reflection below tile */}
                  {!settings.performanceMode && (
                    <div
                      className="w-20 h-3.5 mt-1 rounded-full opacity-15 filter blur-xs transform scale-y-[-1] pointer-events-none transition-opacity"
                      style={{
                        background: app.iconBgGradient,
                        opacity: isFocused ? 0.35 : 0.1,
                      }}
                    />
                  )}

                  {/* App Name directly below the app icon in the dock */}
                  <span
                    className={`text-xs md:text-sm font-semibold mt-2.5 transition-all text-center tracking-tight truncate max-w-[100px] ${
                      isFocused
                        ? 'text-white font-bold drop-shadow-md scale-105'
                        : 'text-slate-400'
                    }`}
                  >
                    {app.title}
                  </span>
                </div>
              );
            })}

            {/* "+ Add Custom App" Tile */}
            <div
              id="dock-add-tile"
              onClick={onOpenAddModal}
              onMouseEnter={() => onFocusApp(apps.length)}
              className="shrink-0 flex flex-col items-center cursor-pointer group"
            >
              <div
                className={`w-22 h-22 md:w-28 md:h-28 rounded-[28px] border border-dashed flex items-center justify-center transition-all duration-200 ${
                  isDockFocused && focusedDockIndex === apps.length
                    ? 'tv-focused ring-4 ring-white shadow-2xl scale-115 z-30 border-white bg-white/15'
                    : 'border-white/25 bg-white/[0.04] hover:bg-white/[0.1] hover:border-white/50 hover:scale-105'
                }`}
              >
                <Plus
                  className={`w-8 h-8 transition-colors ${
                    isDockFocused && focusedDockIndex === apps.length ? 'text-white' : 'text-slate-400'
                  }`}
                />
              </div>
              <span
                className={`text-xs md:text-sm font-semibold mt-2.5 transition-all text-center tracking-tight ${
                  isDockFocused && focusedDockIndex === apps.length ? 'text-white font-bold scale-105' : 'text-slate-500'
                }`}
              >
                Add Tile
              </span>
            </div>
          </div>
        </div>

        {/* Reorder Dock Button (Focusable with TV Remote) */}
        <div className="mt-6 flex items-center gap-2">
          <button
            id="dock-reorder-btn"
            onClick={onToggleReorderMode}
            className={`flex items-center gap-2 px-5 py-2 rounded-full text-xs font-semibold border backdrop-blur-md transition-all cursor-pointer outline-hidden ${
              isReorderFocused
                ? 'bg-white text-slate-950 ring-4 ring-white shadow-2xl scale-105 border-white'
                : isReorderMode
                ? 'bg-amber-500 text-slate-950 font-bold border-amber-400'
                : 'bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white border-white/10'
            }`}
          >
            {isReorderMode ? <Check className="w-3.5 h-3.5 text-slate-950" /> : <SlidersHorizontal className="w-3.5 h-3.5" />}
            <span>{isReorderMode ? 'Done Reordering (Press OK or Back)' : 'Reorder Dock (Press Menu or Down)'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
