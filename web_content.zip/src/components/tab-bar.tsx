import { BookOpen, Lock, Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import { useVault, type AppTab } from "@/lib/vault-store";

const TABS: { id: AppTab; label: string; icon: typeof BookOpen }[] = [
  { id: "shelf", label: "Полка", icon: BookOpen },
  { id: "mine", label: "Мои", icon: Plus },
  { id: "more", label: "Замок", icon: Lock },
];

export function TabBar() {
  const tab = useVault((s) => s.tab);
  const setTab = useVault((s) => s.setTab);
  const setAdding = useVault((s) => s.setAdding);

  return (
    <nav className="absolute inset-x-0 bottom-0 z-30 border-t border-cream/8 bg-ink/95 pb-safe backdrop-blur-md">
      <ul className="grid grid-cols-3">
        {TABS.map((item) => {
          const active = tab === item.id;
          const Icon = item.icon;
          return (
            <li key={item.id}>
              <button
                type="button"
                onClick={() => {
                  if (item.id === "mine") {
                    setTab("mine");
                    return;
                  }
                  setTab(item.id);
                  setAdding(false);
                }}
                className={cn(
                  "flex h-14 w-full flex-col items-center justify-center gap-0.5 text-[0.7rem] tracking-wide transition-colors duration-150",
                  active ? "text-sage" : "text-muted",
                )}
              >
                <Icon className="size-5" strokeWidth={active ? 2.2 : 1.8} />
                {item.label}
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
