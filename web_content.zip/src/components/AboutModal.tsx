/**
 * SPR - SAHIL POWERFUL RUN
 * Official About Modal & Creator Credits Section
 * Created by Sahil Gupta on 15 September 2026
 */

import React from 'react';
import { X, Crown, Sparkles, Shield, User, Calendar, Award, Rocket, Compass, Heart } from 'lucide-react';
import { soundManager } from '../game/audio/SoundManager';

interface Props {
  onClose: () => void;
}

export const AboutModal: React.FC<Props> = ({ onClose }) => {
  const handleClose = () => {
    soundManager.playButtonClick();
    onClose();
  };

  return (
    <div
      id="spr-about-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/90 backdrop-blur-md select-none animate-fadeIn"
    >
      <div className="relative w-full max-w-xl max-h-[90vh] bg-gradient-to-b from-slate-950 via-neutral-950 to-black border-2 border-amber-400/80 rounded-3xl p-5 sm:p-7 shadow-[0_0_50px_rgba(245,158,11,0.3)] flex flex-col gap-5 overflow-hidden text-white">
        
        {/* Subtle decorative background glow */}
        <div className="absolute top-0 right-1/4 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/4 w-64 h-64 bg-yellow-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Header */}
        <div className="relative z-10 flex items-center justify-between border-b border-amber-500/30 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-600 via-yellow-400 to-amber-500 p-0.5 shadow-[0_0_15px_rgba(245,158,11,0.5)]">
              <div className="w-full h-full rounded-[14px] bg-slate-950 flex items-center justify-center">
                <Crown className="w-6 h-6 text-amber-400 fill-amber-400/20" />
              </div>
            </div>
            <div>
              <h2
                id="about-spr-title"
                className="text-xl sm:text-2xl font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-400 uppercase font-display"
              >
                ABOUT SPR
              </h2>
              <p className="text-xs font-bold text-amber-300/80 tracking-wide uppercase font-mono">
                SAHIL POWERFUL RUN
              </p>
            </div>
          </div>

          <button
            id="about-btn-close"
            onClick={handleClose}
            className="w-10 h-10 rounded-full bg-slate-900/90 hover:bg-slate-800 border border-amber-400/40 text-amber-200 hover:text-white flex items-center justify-center transition cursor-pointer active:scale-95 shadow-md"
            title="Close About SPR"
          >
            <X className="w-5 h-5 stroke-[2.5]" />
          </button>
        </div>

        {/* Scrollable Content Container */}
        <div className="relative z-10 flex-1 overflow-y-auto pr-1 space-y-5 custom-scrollbar">

          {/* Prominent Game Branding & Official Creation Statement */}
          <div
            id="about-creation-statement"
            className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-amber-950/60 via-slate-900/90 to-amber-950/60 border border-amber-400/50 shadow-lg text-center"
          >
            <span className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-500/20 border border-amber-400/40 text-[10px] sm:text-xs font-black text-amber-300 uppercase tracking-widest font-mono mb-2">
              <Sparkles className="w-3 h-3 text-amber-300" />
              OFFICIAL CREATION STATEMENT
            </span>
            <h3
              id="about-full-game-title"
              className="text-2xl sm:text-3xl font-black text-white tracking-wide uppercase font-display drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)]"
            >
              SAHIL POWERFUL RUN
            </h3>
            <p className="mt-2 text-sm sm:text-base font-bold text-amber-200 leading-relaxed">
              "SAHIL POWERFUL RUN (SPR) was created by Sahil Gupta on 15 September 2026."
            </p>
          </div>

          {/* Premium Creator Card */}
          <div
            id="about-creator-card"
            className="p-5 rounded-2xl bg-gradient-to-b from-slate-900/95 to-slate-950 border-2 border-amber-400/70 shadow-[0_4px_20px_rgba(0,0,0,0.7)] relative overflow-hidden"
          >
            {/* Crown & Lion SPR emblem watermarks */}
            <div className="absolute -top-6 -right-6 text-7xl opacity-10 pointer-events-none select-none">
              👑
            </div>
            <div className="absolute -bottom-6 -left-6 text-7xl opacity-10 pointer-events-none select-none">
              🦁
            </div>

            <div className="flex items-center gap-2 mb-3">
              <Shield className="w-5 h-5 text-amber-400" />
              <span className="text-xs font-black tracking-widest text-amber-300 uppercase font-mono">
                CREATOR & GAME CREDITS
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div className="p-3 rounded-xl bg-slate-950/90 border border-amber-500/30">
                <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold block mb-0.5">
                  CREATED BY
                </span>
                <span className="text-lg sm:text-xl font-black text-white font-display flex items-center gap-1.5">
                  <User className="w-4 h-4 text-amber-400" />
                  Sahil Gupta
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/90 border border-amber-500/30">
                <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold block mb-0.5">
                  GAME
                </span>
                <span className="text-base sm:text-lg font-black text-amber-300 font-display">
                  SAHIL POWERFUL RUN
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/90 border border-amber-500/30">
                <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold block mb-0.5">
                  SHORT NAME
                </span>
                <span className="text-lg font-black text-white font-display">
                  SPR
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/90 border border-amber-500/30">
                <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold block mb-0.5">
                  CREATED
                </span>
                <span className="text-base sm:text-lg font-black text-amber-300 font-display flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-amber-400" />
                  15 SEPTEMBER 2026
                </span>
              </div>
            </div>
          </div>

          {/* Official Appreciation & About Description */}
          <div
            id="about-description-container"
            className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3.5 text-sm sm:text-base leading-relaxed text-slate-200"
          >
            <div className="flex items-center gap-2 pb-1 border-b border-slate-800">
              <Award className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-black tracking-wider text-amber-300 uppercase font-mono">
                ABOUT THE VISION & JOURNEY
              </span>
            </div>

            <p>
              <strong className="text-white font-black">SAHIL POWERFUL RUN</strong> is an ambitious 3D endless-runner game created by Sahil Gupta with a strong vision to build an exciting, stylish and memorable gaming experience.
            </p>

            <p>
              Sahil Gupta developed SPR with creativity, determination and a passion for technology and game design. The game combines fast-paced running, 3D characters, skateboards, trains, coins, power-ups, rocket flight, diamond revival and an immersive railway environment into one unique experience.
            </p>

            <p>
              SPR represents Sahil Gupta's vision of turning an idea into a real playable game and continuously improving it with new features, visual quality and gameplay systems.
            </p>

            <p className="text-amber-200/90 font-medium italic">
              "The journey behind <strong className="not-italic text-amber-300">SAHIL POWERFUL RUN</strong> is about creativity, learning, hard work and the ambition to build something powerful from an original idea."
            </p>
          </div>

          {/* Key Game Features Summary */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs font-bold text-slate-300">
            <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col items-center gap-1">
              <span className="text-xl">🏃</span>
              <span>12 3D Characters</span>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col items-center gap-1">
              <span className="text-xl">🛹</span>
              <span>Custom Skateboards</span>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col items-center gap-1">
              <span className="text-xl">🚀</span>
              <span>Horizontal Rocket Flight</span>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col items-center gap-1">
              <span className="text-xl">💎</span>
              <span>Diamond Revive (3 Max)</span>
            </div>
          </div>
        </div>

        {/* Bottom Footer Button */}
        <div className="relative z-10 pt-2 border-t border-slate-800/80 flex items-center justify-between">
          <span className="text-[11px] font-mono text-slate-400">
            SPR v2.0 · 100% Offline Single-Player
          </span>
          <button
            id="about-btn-back"
            onClick={handleClose}
            className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-xs uppercase tracking-wider font-display shadow-lg transition cursor-pointer active:scale-95"
          >
            BACK TO HOME
          </button>
        </div>

      </div>
    </div>
  );
};
