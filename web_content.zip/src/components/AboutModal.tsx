import React from 'react';
import { X, Sparkles, Shield, Cpu, Volume2, Mic, Code2, Download } from 'lucide-react';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-3xl bg-[#101522] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-slate-100 flex items-center gap-2">
                <span>About YiuVoice (తెలుగు వాయిస్ స్టూడియో)</span>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  v1.2.0 (APK & PWA Ready)
                </span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Next-Generation Telugu AI Text-to-Speech Platform
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 text-sm text-slate-300 leading-relaxed scrollbar-thin">
          <div>
            <h4 className="font-bold text-slate-100 text-base mb-2">
              పరిచయం (Introduction)
            </h4>
            <p className="text-slate-300">
              <strong>YiuVoice</strong> అనేది తెలుగు భాష కొరకు ప్రత్యేకంగా తీర్చిదిద్దబడిన ప్రొఫెషనల్ AI టెక్స్ట్-టు-స్పీచ్ (TTS) ప్లాట్‌ఫారమ్. కథలు, డాక్యుమెంటరీలు, యూట్యూబ్ వాయిస్‌ఓవర్లు, వార్తలు, మరియు పాడ్‌కాస్ట్‌ల కొరకు సహజసిద్ధమైన తెలుగు ఉచ్చారణతో ఆడియోను రూపొందిస్తుంది.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
              <div className="flex items-center gap-2 text-cyan-400 font-bold mb-1.5">
                <Cpu className="w-4 h-4" />
                <span>Gemini 3.1 Neural Studio</span>
              </div>
              <p className="text-xs text-slate-400 leading-normal">
                స్టూడియో గ్రేడ్ 24,000Hz PCM ఆడియోతో పనిచేసే గూగుల్ జెమిని మల్టీమోడల్ స్పీచ్ సింథసిస్. భావోద్వేగాలు, వాక్య గతులు మరియు సహజమైన తెలుగు యాసలను ఖచ్చితంగా పలికిస్తుంది.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
              <div className="flex items-center gap-2 text-emerald-400 font-bold mb-1.5">
                <Download className="w-4 h-4" />
                <span>నిజమైన MP3 ఎన్‌కోడింగ్ (LameJS)</span>
              </div>
              <p className="text-xs text-slate-400 leading-normal">
                ఫైల్ పొడిగింపును కేవలం పేరు మార్చడం కాకుండా, 24kHz / 192-320kbps వద్ద అసలైన LAME MP3 ఫ్రేమ్‌లుగా ఎన్‌కోడ్ చేస్తుంది.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
              <div className="flex items-center gap-2 text-purple-400 font-bold mb-1.5">
                <Mic className="w-4 h-4" />
                <span>16 వ్యాఖ్యాన రీతులు & వాక్య నియంత్రణ</span>
              </div>
              <p className="text-xs text-slate-400 leading-normal">
                కథలు, సస్పెన్స్, భావోద్వేగం, వార్తలు మరియు సినిమాటిక్ శైలుల్లో వాక్యాల వారీగా విరామాలు మరియు ఒత్తిళ్లను మార్చుకునే వెసులుబాటు.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
              <div className="flex items-center gap-2 text-blue-400 font-bold mb-1.5">
                <Code2 className="w-4 h-4" />
                <span>మాడ్యులర్ ఆర్కిటెక్చర్</span>
              </div>
              <p className="text-xs text-slate-400 leading-normal">
                <code className="text-cyan-300 font-mono">ITTSProvider</code> ఇంటర్‌ఫేస్ ఆధారంగా కొత్త ఇంజిన్‌లు లేదా ప్రైవేట్ తెలుగు APIలను భవిష్యత్తులో సులభంగా అనుసంధానించవచ్చు.
              </p>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-800 text-xs text-slate-400">
            <p>
              Designed with dark glassmorphism aesthetic for professional content creators, podcasters, video editors, and voice artists.
            </p>
          </div>
        </div>

        <div className="p-4 border-t border-slate-800 flex justify-end bg-slate-900/80">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-all cursor-pointer"
          >
            మూసివేయి (Close)
          </button>
        </div>
      </div>
    </div>
  );
};
