import React from "react";
import { X, ShieldCheck, Heart, Sparkles, CheckCircle2 } from "lucide-react";

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg glass-panel-elevated rounded-3xl p-6 border border-white/15 shadow-2xl space-y-5">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Title */}
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 to-cyan-500 text-white font-extrabold text-xl shadow-lg shadow-indigo-600/30">
            R
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Ranabir - AI Assistant</h3>
            <p className="text-xs text-indigo-300 font-semibold">
              সর্বদা সাহায্য করার জন্য প্রস্তুত
            </p>
          </div>
        </div>

        {/* Creator Identity Requirement */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-indigo-950/60 to-purple-950/60 border border-indigo-500/30 space-y-1.5">
          <div className="text-[11px] font-bold text-indigo-300 uppercase tracking-wider">
            About Us &amp; স্বত্বাধিকার
          </div>
          <p className="text-base font-extrabold text-white">
            &quot;Ranabir AI, Ranabir Team দ্বারা তৈরি&quot;
          </p>
          <p className="text-xs text-slate-300 italic">
            &quot;আমি Ranabir, তোমাকে সাহায্য করার জন্যই তৈরি।&quot;
          </p>
        </div>

        {/* Highlights */}
        <div className="space-y-2.5 text-xs text-slate-300">
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>
              <strong>Smart Chat &amp; Voice:</strong> পড়াশোনা, কোডিং, গল্প লেখা ও &quot;Hey Ranabir&quot; ভয়েস কমান্ড।
            </span>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
            <span>
              <strong>Image &amp; Media Studio:</strong> তাৎক্ষণিক ছবি তৈরি, ব্যাকগ্রাউন্ড রিমুভ, ফিল্টার ও Auto Reels ভিডিও এক্সপোর্ট।
            </span>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
            <span>
              <strong>Memory &amp; Privacy:</strong> স্থানীয় এনক্রিপ্ট করা মেমরি ভল্ট। কোনো ডেটা তৃতীয় পক্ষের সাথে শেয়ার করা হয় না।
            </span>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-colors shadow-md shadow-indigo-600/30"
        >
          ঠিক আছে, বুঝতে পেরেছি
        </button>
      </div>
    </div>
  );
};
