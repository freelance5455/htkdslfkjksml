import React from 'react';
import { X, CheckCircle, ShieldCheck, Heart, Sparkles } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { IslamicArchBorder } from './IslamicPattern';
import { AppLogo } from './AppLogo';

export const AboutModal: React.FC = () => {
  const { showAboutModal, setShowAboutModal } = useApp();

  if (!showAboutModal) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-lg max-h-[90vh] overflow-y-auto bg-[#042017] dark:bg-[#031c15] border border-emerald-600/25 dark:border-emerald-700/60 rounded-3xl p-6 shadow-2xl space-y-6 text-right"
        role="dialog"
        aria-modal="true"
      >
        {/* Close Button */}
        <button
          onClick={() => setShowAboutModal(false)}
          className="absolute top-5 left-5 p-2 rounded-full bg-[#eaf5ef] dark:bg-[#062c20] text-[#2b5945] dark:text-[#a7d7c0] hover:text-[#0c2e20] dark:hover:text-emerald-300 transition-colors border border-transparent dark:border-emerald-800 cursor-pointer"
          aria-label="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Branding */}
        <div className="flex flex-col items-center text-center pt-2">
          <AppLogo size={68} withGlow={true} className="mb-3" />
          <h2 className="text-2xl font-black text-amber-600 dark:text-amber-300 font-cairo drop-shadow-[0_1px_6px_rgba(217,119,6,0.25)] dark:drop-shadow-[0_1px_10px_rgba(251,191,36,0.45)]">
            حصن المسلم
          </h2>
          <p className="text-sm font-bold text-emerald-800 dark:text-emerald-300 font-tajawal">
            أذكار المسلم اليومية
          </p>
        </div>

        <IslamicArchBorder className="text-emerald-700/20 dark:text-emerald-400/20" />

        {/* Dedication Card */}
        <div className="bg-gradient-to-br from-[#f0f7f3] via-[#e6f4ed] to-[#edf7f2] dark:from-[#022218] dark:via-[#042d20] dark:to-[#021811] border border-emerald-600/30 dark:border-emerald-700/60 rounded-2xl p-5 space-y-3.5 shadow-sm">
          <div className="flex items-center gap-2 text-emerald-900 dark:text-emerald-200 font-bold text-sm">
            <Heart className="w-4 h-4 text-emerald-700 dark:text-emerald-400 fill-emerald-500/20" />
            <span className="font-cairo">نية العمل والصدقة الجارية</span>
          </div>

          <p className="text-sm leading-relaxed text-[#0c2e20] dark:text-[#e8f5ee] font-tajawal">
            تم إنشاء هذا التطبيق ابتغاء الأجر والثواب من الله تعالى، ونرجو أن يكون صدقةً جاريةً عن{' '}
            <strong className="text-emerald-900 dark:text-white font-bold text-base">الحاجة هدي</strong>.
          </p>

          <p className="text-sm leading-relaxed text-[#0c2e20] dark:text-[#e8f5ee] font-tajawal">
            نسأل الله أن يتقبل هذا العمل وينفع به، وأن يجعل في كل ذكر يُقرأ وكل دعاء يُقال من خلال هذا التطبيق خيرًا ونفعًا.
          </p>

          <div className="pt-2 border-t border-emerald-200/60 dark:border-emerald-800/60 flex items-center gap-2 text-xs font-bold text-emerald-800 dark:text-emerald-200">
            <Sparkles className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
            <span>نسأل الله أن يتقبل وينفع به في ميزان حسناتها.</span>
          </div>
        </div>

        {/* Authenticity and Religious Sources */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-[#0c2e20] dark:text-[#e8f5ee] flex items-center gap-2 font-cairo">
            <CheckCircle className="w-4 h-4 text-emerald-600" />
            <span>مصدر المحتوى الديني</span>
          </h3>
          <p className="text-xs text-[#2b5945] dark:text-[#a7d7c0] leading-relaxed font-tajawal bg-[#062c20] dark:bg-[#062c20] p-3.5 rounded-xl border border-emerald-200/50 dark:border-emerald-800/60">
            تم إدراج جميع أذكار الصباح وأذكار المساء الواردة في الملف المعتمد كاملةً بدون أي تعديل أو اختصار أو زيادة، مع ضبط التشكيل وصيغ الأحاديث والآيات الكريمة وفق المصادر الموثوقة.
          </p>
        </div>

        {/* Offline & Privacy */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-[#0c2e20] dark:text-[#e8f5ee] flex items-center gap-2 font-cairo">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>الخصوصية والاستخدام دون إنترنت</span>
          </h3>
          <p className="text-xs text-[#2b5945] dark:text-[#a7d7c0] leading-relaxed font-tajawal bg-[#062c20] dark:bg-[#062c20] p-3.5 rounded-xl border border-emerald-200/50 dark:border-emerald-800/60">
            هذا التطبيق مجاني بالكامل لوجه الله تعالى، يعمل دون الحاجة إلى اتصال بالإنترنت، ولا يجمع أي بيانات شخصية، ولا يحتوي على أي إعلانات.
          </p>
        </div>

        <button
          onClick={() => setShowAboutModal(false)}
          className="w-full py-3 bg-gradient-to-r from-emerald-700 to-emerald-800 hover:from-emerald-600 hover:to-emerald-700 text-[#f4faf6] font-bold rounded-xl transition-colors cursor-pointer text-sm font-cairo shadow-md shadow-emerald-950/20"
        >
          حفظ وإغلاق
        </button>
      </div>
    </div>
  );
};
