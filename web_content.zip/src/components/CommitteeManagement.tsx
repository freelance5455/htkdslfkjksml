import React, { useState, useMemo } from 'react';
import {
  Users,
  Plus,
  Search,
  Download,
  ShieldCheck,
  TrendingUp,
  TrendingDown,
  Trash2,
  Edit2,
  Calendar,
  Layers,
  ArrowUpRight,
  ArrowDownLeft,
} from 'lucide-react';
import { AppSettings, CommitteeRecord, CommitteeTransactionType } from '../types';
import { translations } from '../utils/translations';
import { calculateCommitteePosition } from '../utils/calculations';
import { StorageService } from '../utils/storage';

interface CommitteeManagementProps {
  records: CommitteeRecord[];
  onUpdateRecords: (records: CommitteeRecord[]) => void;
  settings: AppSettings;
}

export const CommitteeManagement: React.FC<CommitteeManagementProps> = ({
  records,
  onUpdateRecords,
  settings,
}) => {
  const t = translations[settings.language];
  const [search, setSearch] = useState('');
  const [committeeFilter, setCommitteeFilter] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<CommitteeRecord | null>(null);

  // Form State
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [committeeName, setCommitteeName] = useState('');
  const [memberName, setMemberName] = useState('Saif Ullah');
  const [transactionType, setTransactionType] = useState<CommitteeTransactionType>('Installment');
  const [amount, setAmount] = useState<number | ''>('');
  const [paymentMethod, setPaymentMethod] = useState('Cash');
  const [remarks, setRemarks] = useState('');

  // Calculations
  const position = useMemo(() => {
    return calculateCommitteePosition(records);
  }, [records]);

  // Filtered records
  const activeRecords = useMemo(() => {
    return records
      .filter((r) => !r.isDeleted)
      .filter((r) => {
        const matchesSearch =
          search === '' ||
          r.committeeName.toLowerCase().includes(search.toLowerCase()) ||
          r.memberName.toLowerCase().includes(search.toLowerCase()) ||
          (r.remarks && r.remarks.toLowerCase().includes(search.toLowerCase()));
        const matchesCommittee = committeeFilter === '' || r.committeeName === committeeFilter;
        return matchesSearch && matchesCommittee;
      })
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [records, search, committeeFilter]);

  const uniqueCommittees = useMemo(() => {
    const set = new Set<string>();
    records.filter((r) => !r.isDeleted).forEach((r) => set.add(r.committeeName));
    return Array.from(set);
  }, [records]);

  const handleOpenAdd = () => {
    setEditingRecord(null);
    setDate(new Date().toISOString().slice(0, 10));
    setCommitteeName(uniqueCommittees[0] || 'Friends & Family 200K');
    setMemberName('Saif Ullah');
    setTransactionType('Installment');
    setAmount('');
    setPaymentMethod('Cash');
    setRemarks('');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (rec: CommitteeRecord) => {
    setEditingRecord(rec);
    setDate(rec.date);
    setCommitteeName(rec.committeeName);
    setMemberName(rec.memberName);
    setTransactionType(rec.transactionType);
    setAmount(rec.amount);
    setPaymentMethod(rec.paymentMethod);
    setRemarks(rec.remarks || '');
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Number(amount);
    if (!committeeName.trim() || !memberName.trim()) {
      alert('Committee name and Member name are required');
      return;
    }
    if (amt <= 0) {
      alert('Amount must be greater than zero');
      return;
    }

    if (editingRecord) {
      const old = { ...editingRecord };
      const updated: CommitteeRecord = {
        ...editingRecord,
        date,
        committeeName: committeeName.trim(),
        memberName: memberName.trim(),
        transactionType,
        amount: amt,
        paymentMethod,
        remarks: remarks.trim(),
        updatedAt: new Date().toISOString(),
      };
      const updatedList = records.map((r) => (r.id === editingRecord.id ? updated : r));
      onUpdateRecords(updatedList);
      StorageService.saveCommittees(updatedList);
      StorageService.addAuditLog('UPDATE', 'Committees', `Updated ${transactionType} for ${committeeName}`, old, updated);
    } else {
      const newRec: CommitteeRecord = {
        id: `com_${Date.now()}`,
        date,
        committeeName: committeeName.trim(),
        memberName: memberName.trim(),
        transactionType,
        amount: amt,
        paymentMethod,
        remarks: remarks.trim(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      const updatedList = [newRec, ...records];
      onUpdateRecords(updatedList);
      StorageService.saveCommittees(updatedList);
      StorageService.addAuditLog(
        'CREATE',
        'Committees',
        `Added ${transactionType} of Rs. ${amt} in ${committeeName}`,
        null,
        newRec
      );
    }

    setIsModalOpen(false);
  };

  const handleDelete = (rec: CommitteeRecord) => {
    if (window.confirm(t.confirmDelete)) {
      const updated = records.map((r) => (r.id === rec.id ? { ...r, isDeleted: true } : r));
      onUpdateRecords(updated);
      StorageService.saveCommittees(updated);
      StorageService.moveToRecycleBin('Committees', rec.id, `${rec.committeeName} (${rec.transactionType} Rs. ${rec.amount})`, rec);
    }
  };

  const handleExportCSV = () => {
    const rows = activeRecords.map((r) => ({
      Date: r.date,
      'Committee Name': r.committeeName,
      'Member Name': r.memberName,
      'Transaction Type': r.transactionType,
      Amount: r.amount,
      'Payment Method': r.paymentMethod,
      Remarks: r.remarks || '',
    }));
    StorageService.exportToCsv('Committee_Records_Export', rows);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-teal-100 dark:bg-teal-950/60 text-teal-700 dark:text-teal-400 rounded-lg">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              {t.committee}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              BC / Kameti Installments and Lucky Draw Payouts (Isolated from Loans)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 transition"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>{t.exportCsv}</span>
          </button>

          <button
            type="button"
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm transition"
          >
            <Plus className="w-4 h-4" />
            <span>{t.addCommittee}</span>
          </button>
        </div>
      </div>

      {/* Isolation notice */}
      <div className="p-3 bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-900/60 rounded-xl flex items-center gap-2 text-xs text-teal-900 dark:text-teal-200">
        <ShieldCheck className="w-4 h-4 text-teal-600 shrink-0" />
        <span>
          {t.committeeRuleNotice} Committee installments and payouts are maintained in separate ledgers.
        </span>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>{t.totalInstallments}</span>
            <ArrowDownLeft className="w-4 h-4 text-blue-500" />
          </div>
          <div className="mt-2 text-2xl font-bold text-slate-900 dark:text-white">
            {settings.currencySymbol} {position.totalInstallments.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">Total monthly contributions paid</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>{t.totalPayouts}</span>
            <ArrowUpRight className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="mt-2 text-2xl font-bold text-emerald-600 dark:text-emerald-400">
            {settings.currencySymbol} {position.totalPayouts.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">Total committee draw proceeds received</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>{t.netPosition}</span>
            <TrendingUp className="w-4 h-4 text-teal-500" />
          </div>
          <div
            className={`mt-2 text-2xl font-extrabold ${
              position.netPosition >= 0 ? 'text-teal-600 dark:text-teal-400' : 'text-rose-600 dark:text-rose-400'
            }`}
          >
            {settings.currencySymbol} {position.netPosition.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">
            {position.netPosition >= 0 ? 'Net positive liquidity' : 'Net invested balance'}
          </p>
        </div>
      </div>

      {/* Committee-Wise Breakdown Cards */}
      <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
        <h3 className="text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-3 flex items-center gap-1.5">
          <Layers className="w-4 h-4 text-teal-500" />
          Committee-Wise Balance & Ledgers
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {Object.entries(position.committeeWise).map(([commName, data]) => (
            <div
              key={commName}
              className="bg-white dark:bg-slate-900 p-3 rounded-lg border border-slate-200 dark:border-slate-800 text-xs space-y-1.5"
            >
              <div className="flex justify-between items-center font-bold">
                <span className="text-slate-900 dark:text-white truncate">{commName}</span>
                <span className="px-1.5 py-0.5 rounded text-[10px] bg-teal-100 dark:bg-teal-950 text-teal-700">
                  {data.members.size} Member(s)
                </span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Total Installments:</span>
                <span className="font-medium text-slate-800 dark:text-slate-200">
                  {settings.currencySymbol} {data.installments.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Total Payout:</span>
                <span className="font-medium text-emerald-600">
                  {settings.currencySymbol} {data.payouts.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between font-bold border-t border-slate-100 dark:border-slate-800 pt-1 text-slate-900 dark:text-white">
                <span>Net Position:</span>
                <span className={data.net >= 0 ? 'text-teal-600' : 'text-slate-600'}>
                  {settings.currencySymbol} {data.net.toLocaleString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 rtl:left-auto rtl:right-3" />
          <input
            type="text"
            placeholder="Search committee, member or remarks..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 rtl:pl-3 rtl:pr-9 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500 border-0"
          />
        </div>

        <select
          value={committeeFilter}
          onChange={(e) => setCommitteeFilter(e.target.value)}
          className="px-3 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 rounded-lg text-slate-700 dark:text-slate-300 border-0"
        >
          <option value="">All Committees</option>
          {uniqueCommittees.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/70 border-b border-slate-200 dark:border-slate-800 text-slate-500 uppercase tracking-wider font-semibold">
              <tr>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3">{t.committeeName}</th>
                <th className="px-4 py-3">{t.memberName}</th>
                <th className="px-4 py-3">Type</th>
                <th className="px-4 py-3">{t.amount}</th>
                <th className="px-4 py-3">{t.paymentMethod}</th>
                <th className="px-4 py-3">{t.remarks}</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {activeRecords.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-4 py-8 text-center text-slate-400">
                    No committee transactions found.
                  </td>
                </tr>
              ) : (
                activeRecords.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition">
                    <td className="px-4 py-3 font-medium text-slate-900 dark:text-slate-200 whitespace-nowrap">
                      {r.date}
                    </td>
                    <td className="px-4 py-3 font-bold text-slate-900 dark:text-white">
                      {r.committeeName}
                    </td>
                    <td className="px-4 py-3 text-slate-700 dark:text-slate-300">
                      {r.memberName}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                          r.transactionType === 'Payout'
                            ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                            : 'bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300'
                        }`}
                      >
                        {r.transactionType}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-extrabold text-slate-900 dark:text-white whitespace-nowrap">
                      {settings.currencySymbol} {r.amount.toLocaleString()}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {r.paymentMethod}
                    </td>
                    <td className="px-4 py-3 text-slate-500 max-w-xs truncate">
                      {r.remarks || '—'}
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => handleOpenEdit(r)}
                          className="p-1 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                          title="Edit"
                          aria-label={`Edit committee transaction for ${r.committeeName}`}
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(r)}
                          className="p-1 rounded text-rose-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50"
                          title="Delete"
                          aria-label={`Delete committee transaction for ${r.committeeName}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Committee Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-teal-600" />
                {editingRecord ? 'Edit Committee Entry' : t.addCommittee}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="mt-4 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Transaction Type *
                  </label>
                  <select
                    value={transactionType}
                    onChange={(e) => setTransactionType(e.target.value as CommitteeTransactionType)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 font-semibold"
                  >
                    <option value="Installment">Installment (Deposit)</option>
                    <option value="Payout">Payout (Proceeds Received)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Committee Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Friends & Family 200K"
                  value={committeeName}
                  onChange={(e) => setCommitteeName(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Member Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Saif Ullah"
                    value={memberName}
                    onChange={(e) => setMemberName(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Amount ({settings.currencySymbol}) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    required
                    placeholder="20000"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm font-bold text-slate-900 dark:text-white bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Payment Method
                  </label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                  >
                    <option value="Cash">Cash</option>
                    <option value="Bank">Bank Transfer</option>
                    <option value="EasyPaisa">EasyPaisa</option>
                    <option value="JazzCash">JazzCash</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Remarks
                  </label>
                  <input
                    type="text"
                    placeholder="Month # / draw notes"
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-sm transition"
                >
                  {editingRecord ? 'Update' : t.save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
