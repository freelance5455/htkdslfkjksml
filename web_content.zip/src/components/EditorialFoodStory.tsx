import React from "react";
import { ArrowRight, Sparkles, UtensilsCrossed } from "lucide-react";
import { Dish } from "../types";

interface EditorialFoodStoryProps {
  onSelectDish: (dish: Dish) => void;
  onOpenMenu: () => void;
  featuredDishes: Dish[];
}

export const EditorialFoodStory: React.FC<EditorialFoodStoryProps> = ({
  onSelectDish,
  onOpenMenu,
  featuredDishes,
}) => {
  const heroDish = featuredDishes[0];
  const sideDish1 = featuredDishes[1];
  const sideDish2 = featuredDishes[2];

  return (
    <section className="py-20 sm:py-28 px-6 bg-[#F4F0E7] border-b border-[#D8D0C2]/60">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 sm:mb-16 border-b border-[#D8D0C2]/60 pb-8">
          <div>
            <div className="text-xs font-semibold tracking-[0.25em] uppercase text-[#9BAF82] mb-3 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#9BAF82]" />
              <span>EDITORIAL HIGHLIGHTS</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-5xl lg:text-6xl text-[#17201C] leading-[1.1] tracking-tight">
              A LITTLE SOMETHING
              <br />
              <span className="italic font-light">FOR EVERY MOOD.</span>
            </h2>
          </div>

          <div className="max-w-md space-y-4">
            <p className="text-xs sm:text-sm text-[#17201C]/75 font-sans leading-relaxed">
              From crisp coastal field greens to slow-poached Turkish eggs on sourdough, every plate is prepared with honest cold-pressed oils, oats flour, and uncompromised ingredients.
            </p>
            <button
              type="button"
              onClick={onOpenMenu}
              className="group inline-flex items-center gap-2 text-xs font-semibold tracking-[0.2em] uppercase text-[#17201C] hover:text-[#9BAF82] transition-colors cursor-pointer"
            >
              <span>EXPLORE ALL 15 CATEGORIES IN FULL MENU</span>
              <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
            </button>
          </div>
        </div>

        {/* Typographic Editorial Composition (Honest, Image-Free Menu Layout) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-stretch">
          {/* Main Editorial Hero Plate Card */}
          {heroDish && (
            <div
              onClick={() => onSelectDish(heroDish)}
              className="lg:col-span-7 bg-[#FDFBF7] border border-[#D8D0C2] rounded-sm p-6 sm:p-10 flex flex-col justify-between group cursor-pointer hover:border-[#17201C] hover:shadow-lg transition-all duration-300 relative paper-frame"
            >
              <div>
                <div className="flex items-center justify-between gap-4 mb-6">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#9BAF82]" />
                    <span className="text-[10px] uppercase tracking-widest font-semibold text-[#17201C]/60">
                      Featured Kitchen Signature
                    </span>
                  </div>
                  {heroDish.price && (
                    <span className="font-serif text-2xl sm:text-3xl text-[#17201C] group-hover:text-[#B96D52] transition-colors font-medium">
                      {heroDish.price}
                    </span>
                  )}
                </div>

                <h3 className="font-serif text-2xl sm:text-4xl text-[#17201C] group-hover:text-[#B96D52] transition-colors leading-tight mb-4">
                  {heroDish.name}
                </h3>

                <p className="text-sm sm:text-base text-[#17201C]/75 font-sans leading-relaxed mb-8 max-w-xl">
                  {heroDish.description}
                </p>

                {/* Dietary Tags */}
                {heroDish.dietaryLabel && (
                  <div className="flex flex-wrap gap-1.5 mb-6">
                    {heroDish.dietaryLabel.map((tag, i) => (
                      <span
                        key={i}
                        className="px-2.5 py-1 text-[10px] font-sans uppercase tracking-wider rounded-full bg-[#EAE4D7]/70 text-[#17201C]/80 border border-[#D8D0C2]/60"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              <div className="pt-4 border-t border-[#D8D0C2]/60 flex items-center justify-between text-xs text-[#17201C]/70">
                <span className="font-sans font-medium group-hover:text-[#17201C] transition-colors">
                  Tap to view preparation details
                </span>
                <span className="text-sm font-serif text-[#9BAF82] group-hover:translate-x-1 transition-transform">
                  Read Dish Notes →
                </span>
              </div>
            </div>
          )}

          {/* Secondary Stacked Editorial Moments */}
          <div className="lg:col-span-5 flex flex-col justify-between gap-6">
            {sideDish1 && (
              <div
                onClick={() => onSelectDish(sideDish1)}
                className="bg-[#FDFBF7] border border-[#D8D0C2] rounded-sm p-6 flex flex-col justify-between flex-1 group cursor-pointer hover:border-[#17201C] hover:shadow-md transition-all duration-300 paper-frame"
              >
                <div>
                  <div className="flex items-center justify-between gap-3 mb-3">
                    <span className="text-[10px] uppercase tracking-widest font-semibold text-[#9BAF82]">
                      Chef's Selection
                    </span>
                    {sideDish1.price && (
                      <span className="font-serif text-xl text-[#17201C] group-hover:text-[#B96D52] transition-colors font-medium">
                        {sideDish1.price}
                      </span>
                    )}
                  </div>
                  <h4 className="font-serif text-xl sm:text-2xl text-[#17201C] group-hover:text-[#B96D52] transition-colors leading-snug mb-2">
                    {sideDish1.name}
                  </h4>
                  <p className="text-xs sm:text-sm text-[#17201C]/70 font-sans leading-relaxed line-clamp-3 mb-4">
                    {sideDish1.description}
                  </p>
                </div>
                <div className="pt-3 border-t border-[#D8D0C2]/50 flex items-center justify-between text-[11px] text-[#17201C]/60">
                  <span>View Details</span>
                  <span className="text-[#9BAF82] group-hover:translate-x-1 transition-transform">→</span>
                </div>
              </div>
            )}

            {sideDish2 && (
              <div
                onClick={() => onSelectDish(sideDish2)}
                className="bg-[#FDFBF7] border border-[#D8D0C2] rounded-sm p-6 flex flex-col justify-between flex-1 group cursor-pointer hover:border-[#17201C] hover:shadow-md transition-all duration-300 paper-frame"
              >
                <div>
                  <div className="flex items-center justify-between gap-3 mb-3">
                    <span className="text-[10px] uppercase tracking-widest font-semibold text-[#9BAF82]">
                      House Classic
                    </span>
                    {sideDish2.price && (
                      <span className="font-serif text-xl text-[#17201C] group-hover:text-[#B96D52] transition-colors font-medium">
                        {sideDish2.price}
                      </span>
                    )}
                  </div>
                  <h4 className="font-serif text-xl sm:text-2xl text-[#17201C] group-hover:text-[#B96D52] transition-colors leading-snug mb-2">
                    {sideDish2.name}
                  </h4>
                  <p className="text-xs sm:text-sm text-[#17201C]/70 font-sans leading-relaxed line-clamp-3 mb-4">
                    {sideDish2.description}
                  </p>
                </div>
                <div className="pt-3 border-t border-[#D8D0C2]/50 flex items-center justify-between text-[11px] text-[#17201C]/60">
                  <span>View Details</span>
                  <span className="text-[#9BAF82] group-hover:translate-x-1 transition-transform">→</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
