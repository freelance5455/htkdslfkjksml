/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Check, X, Ban, CornerDownRight, Trash2 } from 'lucide-react';
import { TaskStatus, ToDoTask } from '../types.ts';
import {
  BENGALI_MONTHS,
  BENGALI_WEEKDAYS_SHORT,
  formatDateToBengali,
  getTaskStatusOnDate,
  getTodayDateString,
  toBengaliNum,
} from '../utils/dateUtils.ts';

interface CalendarPlanningProps {
  task: ToDoTask;
  onUpdateReport: (dateStr: string, status: TaskStatus | null, postponedTo?: string) => void;
  onBack: () => void;
}

export const CalendarPlanning: React.FC<CalendarPlanningProps> = ({
  task,
  onUpdateReport,
  onBack,
}) => {
  const today = getTodayDateString();
  const todayDate = new Date();
  const [currentYear, setCurrentYear] = useState(todayDate.getFullYear());
  const [currentMonth, setCurrentMonth] = useState(todayDate.getMonth()); // 0-indexed

  // Selected date for editing status
  const [selectedDateModal, setSelectedDateModal] = useState<string | null>(null);
  const [postponeTargetDate, setPostponeTargetDate] = useState<string>('');
  const [postponeError, setPostponeError] = useState<string | null>(null);

  // Month navigation
  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear((y) => y - 1);
    } else {
      setCurrentMonth((m) => m - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear((y) => y + 1);
    } else {
      setCurrentMonth((m) => m + 1);
    }
  };

  // Calendar matrix calculation
  const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay(); // 0 is Sun
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();

  const calendarDays: Array<{
    dateStr: string;
    dayNum: number;
    isCurrentMonth: boolean;
  }> = [];

  // Blank slots for previous month
  for (let i = 0; i < firstDayOfMonth; i++) {
    calendarDays.push({
      dateStr: '',
      dayNum: 0,
      isCurrentMonth: false,
    });
  }

  // Current month days
  for (let d = 1; d <= daysInMonth; d++) {
    const monthStr = String(currentMonth + 1).padStart(2, '0');
    const dayStr = String(d).padStart(2, '0');
    const dateStr = `${currentYear}-${monthStr}-${dayStr}`;
    calendarDays.push({
      dateStr,
      dayNum: d,
      isCurrentMonth: true,
    });
  }

  const handleOpenDayModal = (dateStr: string) => {
    setSelectedDateModal(dateStr);
    setPostponeError(null);
    setPostponeTargetDate('');
  };

  const handleSelectStatus = (status: TaskStatus) => {
    if (!selectedDateModal) return;

    if (status === 'postponed') {
      if (!postponeTargetDate) {
        setPostponeError('অনুগ্রহ করে কোন তারিখে করবেন তা বাছুন।');
        return;
      }
      if (postponeTargetDate <= today) {
        setPostponeError('পরবর্তী তারিখ অবশ্যই আজকের পরের দিন হতে হবে।');
        return;
      }
      onUpdateReport(selectedDateModal, 'postponed', postponeTargetDate);
    } else {
      onUpdateReport(selectedDateModal, status);
    }
    setSelectedDateModal(null);
  };

  const handleClearReport = () => {
    if (!selectedDateModal) return;
    onUpdateReport(selectedDateModal, null);
    setSelectedDateModal(null);
  };

  return (
    <div className="pb-28 max-w-md mx-auto px-4 pt-2">
      {/* Task header banner */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs mb-4 flex items-center justify-between">
        <div>
          <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
            ক্যালেন্ডার ও প্ল্যানিং
          </span>
          <h2 className="text-lg font-bold text-slate-900 mt-1">{task.name}</h2>
          {task.details && <p className="text-xs text-slate-500 mt-0.5">{task.details}</p>}
        </div>
        <button
          type="button"
          onClick={onBack}
          className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold"
        >
          তালিকায় ফিরুন
        </button>
      </div>

      {/* Month Navigator */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs mb-4">
        <div className="flex items-center justify-between mb-4">
          <button
            type="button"
            onClick={handlePrevMonth}
            aria-label="আগের মাস"
            className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 active:scale-95 transition-all"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="text-center">
            <h3 className="text-base font-bold text-slate-900">
              {BENGALI_MONTHS[currentMonth]} {toBengaliNum(currentYear)}
            </h3>
          </div>
          <button
            type="button"
            onClick={handleNextMonth}
            aria-label="পরের মাস"
            className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 active:scale-95 transition-all"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Days of Week Header */}
        <div className="grid grid-cols-7 gap-1 text-center mb-2">
          {BENGALI_WEEKDAYS_SHORT.map((w, idx) => (
            <div
              key={idx}
              className={`text-xs font-bold py-1 ${
                idx === 5 ? 'text-emerald-700' : 'text-slate-500'
              }`}
            >
              {w}
            </div>
          ))}
        </div>

        {/* Calendar Grid */}
        <div className="grid grid-cols-7 gap-1.5">
          {calendarDays.map((cell, idx) => {
            if (!cell.isCurrentMonth) {
              return <div key={`empty-${idx}`} className="h-11 rounded-xl" />;
            }

            const status = getTaskStatusOnDate(task, cell.dateStr, today);
            const isToday = cell.dateStr === today;

            // Indicator icon & colors:
            // ✔ (সবুজ) = করেছি
            // ✖ (লাল) = করিনি
            // ⊘ (কমলা) = করবো না
            // ↪ (নীল) = পরে করবো
            let badge = null;
            let cellBg = 'bg-slate-50/60 hover:bg-slate-100';

            if (status === 'done') {
              badge = <Check className="w-3.5 h-3.5 stroke-[3] text-emerald-600" />;
              cellBg = 'bg-emerald-50/90 border border-emerald-200 text-emerald-950 font-bold';
            } else if (status === 'not_done') {
              badge = <X className="w-3.5 h-3.5 stroke-[3] text-rose-600" />;
              cellBg = 'bg-rose-50/90 border border-rose-200 text-rose-950 font-bold';
            } else if (status === 'wont_do') {
              badge = <Ban className="w-3.5 h-3.5 stroke-[2.5] text-amber-600" />;
              cellBg = 'bg-amber-50/90 border border-amber-200 text-amber-950 font-bold';
            } else if (status === 'postponed') {
              badge = <CornerDownRight className="w-3.5 h-3.5 stroke-[2.5] text-blue-600" />;
              cellBg = 'bg-blue-50/90 border border-blue-200 text-blue-950 font-bold';
            }

            return (
              <button
                key={cell.dateStr}
                type="button"
                onClick={() => handleOpenDayModal(cell.dateStr)}
                className={`h-11 rounded-xl flex flex-col items-center justify-center p-1 transition-all active:scale-95 relative border border-slate-200/50 ${cellBg} ${
                  isToday ? 'ring-2 ring-emerald-500 ring-offset-1' : ''
                }`}
              >
                <span className="text-xs font-semibold leading-none">
                  {toBengaliNum(cell.dayNum)}
                </span>
                <div className="h-4 flex items-center justify-center mt-0.5">
                  {badge}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Legend (সূচক) */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs mb-4">
        <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2.5">
          আইকন ও অবস্থার সূচক
        </h4>
        <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
          <div className="flex items-center gap-2 p-2 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-100">
            <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
              <Check className="w-3 h-3 stroke-[3]" />
            </span>
            <span>✔ সবুজ = করেছি</span>
          </div>
          <div className="flex items-center gap-2 p-2 rounded-xl bg-rose-50 text-rose-800 border border-rose-100">
            <span className="w-5 h-5 rounded-full bg-rose-600 text-white flex items-center justify-center shrink-0">
              <X className="w-3 h-3 stroke-[3]" />
            </span>
            <span>✖ লাল = করিনি</span>
          </div>
          <div className="flex items-center gap-2 p-2 rounded-xl bg-amber-50 text-amber-800 border border-amber-100">
            <span className="w-5 h-5 rounded-full bg-amber-500 text-white flex items-center justify-center shrink-0">
              <Ban className="w-3 h-3 stroke-[2.5]" />
            </span>
            <span>⊘ কমলা = করবো না</span>
          </div>
          <div className="flex items-center gap-2 p-2 rounded-xl bg-blue-50 text-blue-800 border border-blue-100">
            <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0">
              <CornerDownRight className="w-3 h-3 stroke-[2.5]" />
            </span>
            <span>↪ নীল = পরে করবো</span>
          </div>
        </div>
        <p className="text-[11px] text-slate-400 mt-2 text-center">
          যেকোনো তারিখে ট্যাপ করে সেদিনের রিপোর্ট বা অবস্থা ইচ্ছেমতো বদলাতে পারবেন।
        </p>
      </div>

      {/* Day Status Change Modal */}
      {selectedDateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-150">
            <div className="p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-500">তারিখের রিপোর্ট পরিবর্তন</span>
                <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-100">
                  {formatDateDateBengaliHeader(selectedDateModal)}
                </span>
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-1">{task.name}</h3>
              <p className="text-xs text-slate-500 mb-4">
                বর্তমান অবস্থা:{' '}
                <span className="font-semibold text-slate-700">
                  {getStatusBengaliLabel(getTaskStatusOnDate(task, selectedDateModal, today))}
                </span>
              </p>

              {/* Status Action Buttons */}
              <div className="space-y-2">
                <button
                  type="button"
                  onClick={() => handleSelectStatus('done')}
                  className="w-full py-2.5 px-3.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-sm border border-emerald-200 flex items-center gap-2.5 active:scale-98 transition-all"
                >
                  <span className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </span>
                  <span>করেছি (সবুজ)</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSelectStatus('not_done')}
                  className="w-full py-2.5 px-3.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-800 font-bold text-sm border border-rose-200 flex items-center gap-2.5 active:scale-98 transition-all"
                >
                  <span className="w-6 h-6 rounded-full bg-rose-600 text-white flex items-center justify-center">
                    <X className="w-3.5 h-3.5 stroke-[3]" />
                  </span>
                  <span>করিনি (লাল)</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSelectStatus('wont_do')}
                  className="w-full py-2.5 px-3.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 font-bold text-sm border border-amber-200 flex items-center gap-2.5 active:scale-98 transition-all"
                >
                  <span className="w-6 h-6 rounded-full bg-amber-500 text-white flex items-center justify-center">
                    <Ban className="w-3.5 h-3.5 stroke-[2.5]" />
                  </span>
                  <span>করবো না (কমলা)</span>
                </button>

                {/* "পরে করবো" section with target date input */}
                <div className="p-3 rounded-xl bg-blue-50/70 border border-blue-200 space-y-2">
                  <div className="flex items-center gap-2 text-blue-900 font-bold text-sm">
                    <span className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center">
                      <CornerDownRight className="w-3.5 h-3.5 stroke-[2.5]" />
                    </span>
                    <span>পরে করবো (নীল)</span>
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-blue-800 mb-1">
                      কোন তারিখে করবেন বাছুন (আজকের পরের দিন):
                    </label>
                    <input
                      type="date"
                      min={today}
                      value={postponeTargetDate}
                      onChange={(e) => {
                        setPostponeTargetDate(e.target.value);
                        setPostponeError(null);
                      }}
                      className="w-full px-3 py-1.5 rounded-lg border border-blue-300 text-xs bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    {postponeError && (
                      <p className="text-[11px] text-rose-600 font-medium mt-1">
                        {postponeError}
                      </p>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => handleSelectStatus('postponed')}
                    className="w-full py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs active:scale-98 transition-all shadow-xs"
                  >
                    পরে করব হিসেবে নিশ্চিত করুন
                  </button>
                </div>

                {/* Clear Report / Reset to rule */}
                <button
                  type="button"
                  onClick={handleClearReport}
                  className="w-full py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs flex items-center justify-center gap-1.5 transition-all"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>রিপোর্ট মুছুন (স্বয়ংক্রিয় নিয়মে ফিরুন)</span>
                </button>
              </div>
            </div>

            <div className="border-t border-slate-100 bg-slate-50 p-3">
              <button
                type="button"
                onClick={() => setSelectedDateModal(null)}
                className="w-full py-2 px-4 rounded-xl text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 active:scale-98 transition-all"
              >
                বাতিল
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

function formatDateDateBengaliHeader(isoDate: string): string {
  return formatDateToBengali(isoDate, true);
}

function getStatusBengaliLabel(status: TaskStatus | 'pending' | null): string {
  switch (status) {
    case 'done':
      return 'করেছি (✔)';
    case 'not_done':
      return 'করিনি (✖)';
    case 'wont_do':
      return 'করবো না (⊘)';
    case 'postponed':
      return 'পরে করবো (↪)';
    case 'pending':
      return 'আজ বাকি আছে';
    default:
      return 'কোনো রিপোর্ট নেই (খালি)';
  }
}
