import React, { useState, useEffect } from 'react';
import { Sermon, Track } from '../types';
import { SERMONS_ARCHIVE, ASSETS } from '../data/spiritualData';
import { Play, Pause, Radio, Users, Flame, Send, Heart, BookOpen, Clock, ShieldCheck, Bookmark, Share2, FileText, X, CheckCircle2 } from 'lucide-react';

interface LiveSermonsViewProps {
  onSelectSermonTrack: (track: Track) => void;
  currentTrack: Track | null;
  isPlaying: boolean;
  onTogglePlay: () => void;
}

export const LiveSermonsView: React.FC<LiveSermonsViewProps> = ({
  onSelectSermonTrack,
  currentTrack,
  isPlaying,
  onTogglePlay,
}) => {
  const [selectedSermon, setSelectedSermon] = useState<Sermon>(SERMONS_ARCHIVE[0]);
  const [reactions, setReactions] = useState({ amen: 1420, hallelujah: 2890, fire: 3100, peace: 980 });
  const [comments, setComments] = useState<{ id: string; user: string; text: string; time: string }[]>([
    { id: '1', user: 'Sister Miracle O.', text: 'Amen! I receive this prophetic declaration over my household!', time: 'Just now' },
    { id: '2', user: 'Brother David P.', text: 'Glory to God! The anointing is so heavy tonight.', time: '1m ago' },
    { id: '3', user: 'Pastor John S.', text: 'Listening live from Toronto! Hallelujah Prophet JUHNKRIX!', time: '2m ago' },
  ]);
  const [newComment, setNewComment] = useState('');
  const [selectedTag, setSelectedTag] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const tags = ['All', 'Healing', 'Prosperity', 'Deliverance', 'Prophetic Revelation'];

  // Sermon Notes Drawer State
  const [showNotesDrawer, setShowNotesDrawer] = useState<boolean>(false);
  const [noteContent, setNoteContent] = useState<string>('');
  const [savedNotes, setSavedNotes] = useState<{ id: string; sermonTitle: string; date: string; content: string }[]>(() => {
    const saved = localStorage.getItem('juhnkrix_sermon_notes');
    return saved ? JSON.parse(saved) : [];
  });
  const [noteSavedToast, setNoteSavedToast] = useState<boolean>(false);

  const handleSaveNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteContent.trim()) return;
    const newNote = {
      id: `note-${Date.now()}`,
      sermonTitle: selectedSermon.title,
      date: new Date().toLocaleString(),
      content: noteContent,
    };
    const updated = [newNote, ...savedNotes];
    setSavedNotes(updated);
    localStorage.setItem('juhnkrix_sermon_notes', JSON.stringify(updated));
    setNoteContent('');
    setNoteSavedToast(true);
    setTimeout(() => setNoteSavedToast(false), 3000);
  };

  const exportNotesTxt = () => {
    if (savedNotes.length === 0) {
      alert('No saved notes to export.');
      return;
    }
    const text = savedNotes.map(n => `[${n.date}] Sermon: ${n.sermonTitle}\n-----------------------------------------\n${n.content}\n\n`).join('');
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'JUHNKRIX_Sermon_Notes_Backup.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const filteredSermons = SERMONS_ARCHIVE.filter(s => {
    const matchesTag = selectedTag === 'All' || s.category.toLowerCase().includes(selectedTag.toLowerCase()) || s.title.toLowerCase().includes(selectedTag.toLowerCase()) || s.summary.toLowerCase().includes(selectedTag.toLowerCase());
    const query = searchQuery.toLowerCase().trim();
    const matchesSearch = !query || 
      s.title.toLowerCase().includes(query) ||
      s.prophet.toLowerCase().includes(query) ||
      s.date.toLowerCase().includes(query) ||
      s.category.toLowerCase().includes(query) ||
      s.summary.toLowerCase().includes(query);
    return matchesTag && matchesSearch;
  });

  const [bookmarkedSermonIds, setBookmarkedSermonIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('juhnkrix_sermon_bookmarks');
    return saved ? JSON.parse(saved) : [];
  });

  const toggleBookmark = (sermonId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = bookmarkedSermonIds.includes(sermonId)
      ? bookmarkedSermonIds.filter(id => id !== sermonId)
      : [...bookmarkedSermonIds, sermonId];
    setBookmarkedSermonIds(updated);
    localStorage.setItem('juhnkrix_sermon_bookmarks', JSON.stringify(updated));
  };

  const handleShareSermon = async (sermon: Sermon, e: React.MouseEvent) => {
    e.stopPropagation();
    const shareText = `Listen to the sermon "${sermon.title}" by Prophet JUHNKRIX SYNVAGORD on JUHNKRIX MUSIKA.`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: sermon.title,
          text: shareText,
          url: window.location.href,
        });
      } catch (err) {
        console.log('Share canceled', err);
      }
    } else {
      navigator.clipboard.writeText(`${shareText} (${window.location.href})`);
      alert('Sermon link copied to clipboard!');
    }
  };

  // Simulated live chat additions
  useEffect(() => {
    const interval = window.setInterval(() => {
      const names = ['Mary W.', 'Francis K.', 'Dorothy A.', 'Gabriel B.', 'Chidinma N.'];
      const texts = [
        'Amen Prophet JUHNKRIX!',
        'I step into my breakthrough today!',
        'Glory, hallelujah to the Lamb!',
        'No weapon shall prosper against us!',
        'My health is restored in Jesus name!',
      ];
      const randomName = names[Math.floor(Math.random() * names.length)];
      const randomText = texts[Math.floor(Math.random() * texts.length)];

      setComments((prev) => [
        { id: Date.now().toString(), user: randomName, text: randomText, time: 'Just now' },
        ...prev.slice(0, 8),
      ]);
    }, 6000);

    return () => clearInterval(interval);
  }, []);

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    setComments((prev) => [
      { id: Date.now().toString(), user: 'You (Believer)', text: newComment, time: 'Just now' },
      ...prev,
    ]);
    setNewComment('');
  };

  const addReaction = (type: keyof typeof reactions) => {
    setReactions((prev) => ({ ...prev, [type]: prev[type] + 1 }));
  };

  const handlePlaySermon = (sermon: Sermon) => {
    // Convert sermon to audio track format
    const sermonTrack: Track = {
      id: sermon.id,
      title: sermon.title,
      artist: sermon.prophet,
      category: 'Deliverance & Power',
      duration: 3600,
      albumArt: sermon.thumbnail,
      description: sermon.summary,
      scriptureRef: sermon.keyScriptures.join(', '),
      plays: 95000,
      synthPreset: 'warfare',
      lyrics: `[Sermon Transcript Excerpt]\n${sermon.summary}\n\nKey Scriptures:\n${sermon.keyScriptures.map(s => `• ${s}`).join('\n')}`,
    };

    onSelectSermonTrack(sermonTrack);
  };

  const isCurrentSermonPlaying = currentTrack?.id === selectedSermon.id && isPlaying;

  return (
    <div className="space-y-10 pb-16">
      {/* Live Stream Main Player Card */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Stream Video Preview Column */}
        <div className="lg:col-span-2 space-y-4">
          <div className="relative rounded-3xl overflow-hidden border border-amber-500/30 bg-slate-950 shadow-2xl aspect-video group">
            <img
              src={selectedSermon.thumbnail}
              alt={selectedSermon.title}
              className="w-full h-full object-cover opacity-60"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

            {/* Live Indicator */}
            {selectedSermon.isLiveNow && (
              <div className="absolute top-4 left-4 z-10 flex items-center space-x-2 bg-slate-950/80 backdrop-blur-md px-3 py-1.5 rounded-full border border-rose-500/40">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
                <span className="text-xs font-bold text-rose-400 uppercase tracking-wider flex items-center">
                  <Radio className="w-3.5 h-3.5 mr-1 text-rose-500" /> LIVE BROADCAST
                </span>
                <span className="text-[10px] text-slate-300 border-l border-slate-700 pl-2 flex items-center">
                  <Users className="w-3 h-3 mr-1 text-amber-400" />
                  {selectedSermon.viewersCount?.toLocaleString()} watching
                </span>
              </div>
            )}

            {/* Play Button Overlay */}
            <div className="absolute inset-0 flex items-center justify-center">
              <button
                onClick={() => handlePlaySermon(selectedSermon)}
                className="w-20 h-20 rounded-full bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-400 text-slate-950 flex items-center justify-center shadow-2xl shadow-amber-500/50 hover:scale-110 transition-all duration-300"
              >
                {isCurrentSermonPlaying ? (
                  <Pause className="w-10 h-10 fill-slate-950" />
                ) : (
                  <Play className="w-10 h-10 fill-slate-950 ml-1" />
                )}
              </button>
            </div>

            {/* Bottom Stream Bar */}
            <div className="absolute bottom-4 left-4 right-4 z-10 space-y-2">
              <h3 className="text-xl sm:text-2xl font-bold font-serif text-amber-100 drop-shadow">
                {selectedSermon.title}
              </h3>
              <p className="text-xs text-amber-300/80 flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <span>{selectedSermon.prophet}</span>
              </p>
            </div>
          </div>

          {/* Faith Reactions Bar */}
          <div className="bg-slate-900/80 p-4 rounded-2xl border border-amber-500/20 flex items-center justify-around flex-wrap gap-2">
            <button
              onClick={() => addReaction('amen')}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-amber-500/20 text-amber-300 text-xs font-semibold transition-all border border-amber-500/10"
            >
              <span>🙏 AMEN</span>
              <span className="text-[10px] bg-slate-900 px-1.5 py-0.5 rounded-md text-amber-400 font-mono">
                {reactions.amen}
              </span>
            </button>

            <button
              onClick={() => addReaction('hallelujah')}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-amber-500/20 text-amber-300 text-xs font-semibold transition-all border border-amber-500/10"
            >
              <span>🙌 HALLELUJAH</span>
              <span className="text-[10px] bg-slate-900 px-1.5 py-0.5 rounded-md text-amber-400 font-mono">
                {reactions.hallelujah}
              </span>
            </button>

            <button
              onClick={() => addReaction('fire')}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-amber-500/20 text-amber-300 text-xs font-semibold transition-all border border-amber-500/10"
            >
              <span>🔥 HOLY FIRE</span>
              <span className="text-[10px] bg-slate-900 px-1.5 py-0.5 rounded-md text-amber-400 font-mono">
                {reactions.fire}
              </span>
            </button>

            <button
              onClick={() => addReaction('peace')}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-amber-500/20 text-amber-300 text-xs font-semibold transition-all border border-amber-500/10"
            >
              <span>🕊️ PEACE</span>
              <span className="text-[10px] bg-slate-900 px-1.5 py-0.5 rounded-md text-amber-400 font-mono">
                {reactions.peace}
              </span>
            </button>
          </div>
        </div>

        {/* Live Fellowship Chat Box */}
        <div className="bg-slate-900/90 rounded-3xl border border-amber-500/20 p-5 flex flex-col h-[480px]">
          <div className="flex items-center justify-between pb-3 border-b border-amber-500/10">
            <h4 className="text-xs font-bold text-amber-300 uppercase tracking-widest flex items-center space-x-2">
              <Users className="w-4 h-4 text-amber-400" />
              <span>Live Believers Fellowship</span>
            </h4>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          </div>

          <div className="flex-1 overflow-y-auto space-y-3 py-3 pr-2 scrollbar-none text-xs">
            {comments.map((c) => (
              <div key={c.id} className="bg-slate-950/60 p-3 rounded-xl border border-amber-500/10">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-amber-200">{c.user}</span>
                  <span className="text-[10px] text-slate-500">{c.time}</span>
                </div>
                <p className="text-slate-300 leading-normal">{c.text}</p>
              </div>
            ))}
          </div>

          <form onSubmit={handleAddComment} className="pt-3 border-t border-amber-500/10 flex items-center gap-2">
            <input
              type="text"
              placeholder="Type your prayer or Amen..."
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              className="flex-1 bg-slate-950 border border-amber-500/20 rounded-xl px-3 py-2 text-xs text-amber-100 placeholder-slate-500 focus:outline-none focus:border-amber-400"
            />
            <button
              type="submit"
              className="p-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>

      {/* Sermon Replay Archive & Tag Filter */}
      <div className="space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <h3 className="text-lg font-bold text-amber-200 font-serif flex items-center space-x-2">
              <BookOpen className="w-5 h-5 text-amber-400" />
              <span>Prophet JUHNKRIX SYNVAGORD Sermon Library</span>
            </h3>
          </div>

          <button
            onClick={() => setShowNotesDrawer(true)}
            className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center space-x-2 shadow-lg shadow-amber-500/20 transition-all"
          >
            <FileText className="w-4 h-4" />
            <span>Open Sermon Notes ({savedNotes.length})</span>
          </button>
        </div>

        {/* Tag-based Filtering Bar & Search */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 pt-2">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-bold text-slate-400 mr-2">Filter Tags:</span>
            {tags.map((tag) => (
              <button
                key={tag}
                onClick={() => setSelectedTag(tag)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all border ${
                  selectedTag === tag
                    ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md shadow-amber-500/20'
                    : 'bg-slate-900 text-amber-200 border-amber-500/20 hover:border-amber-400/50'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>

          <div className="w-full md:w-72">
            <input
              type="text"
              placeholder="Search by date, topic, or speaker..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-amber-500/30 rounded-2xl px-4 py-2 text-xs text-amber-100 placeholder-slate-400 focus:outline-none focus:border-amber-400"
            />
          </div>
        </div>

        {/* Sermon Notes Drawer / Modal */}
        {showNotesDrawer && (
          <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
            <div className="relative w-full max-w-2xl bg-slate-900 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 max-h-[85vh] overflow-y-auto">
              <div className="flex items-center justify-between pb-4 border-b border-amber-500/20">
                <div className="flex items-center space-x-2">
                  <FileText className="w-5 h-5 text-amber-400" />
                  <h3 className="text-lg font-bold font-serif text-amber-100">Timestamped Personal Sermon Notes</h3>
                </div>
                <button
                  onClick={() => setShowNotesDrawer(false)}
                  className="p-2 rounded-full bg-slate-950 text-slate-300 hover:text-amber-300 border border-amber-500/20"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {noteSavedToast && (
                <div className="p-3 bg-emerald-500/20 border border-emerald-500/40 rounded-xl text-emerald-200 text-xs flex items-center space-x-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Sermon reflection successfully saved to private browser cache!</span>
                </div>
              )}

              <form onSubmit={handleSaveNote} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-amber-400 mb-1">
                    Current Active Sermon
                  </label>
                  <input
                    type="text"
                    disabled
                    value={selectedSermon.title}
                    className="w-full bg-slate-950 border border-amber-500/20 rounded-xl px-3 py-2 text-xs text-amber-200 font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-amber-400 mb-1">
                    Your Personal Reflection & Revelations
                  </label>
                  <textarea
                    rows={4}
                    required
                    placeholder="Type your timestamped notes, insights, and rhema words here..."
                    value={noteContent}
                    onChange={(e) => setNoteContent(e.target.value)}
                    className="w-full bg-slate-950 border border-amber-500/30 rounded-xl px-3 py-2.5 text-xs text-amber-100 focus:outline-none focus:border-amber-400 leading-relaxed"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-xs shadow-lg transition-all"
                >
                  Save Note to Browser Cache
                </button>
              </form>

              {/* Saved Notes List */}
              <div className="space-y-3 pt-4 border-t border-amber-500/20">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-300">Saved Reflections ({savedNotes.length})</h4>
                  {savedNotes.length > 0 && (
                    <button
                      type="button"
                      onClick={exportNotesTxt}
                      className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 text-[10px] font-bold flex items-center space-x-1"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>Export as .txt</span>
                    </button>
                  )}
                </div>
                {savedNotes.length === 0 ? (
                  <p className="text-xs text-slate-400 italic">No notes saved yet. Start typing while listening above.</p>
                ) : (
                  <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
                    {savedNotes.map((note) => (
                      <div key={note.id} className="bg-slate-950 p-3.5 rounded-xl border border-amber-500/20 space-y-1">
                        <div className="flex items-center justify-between text-[10px] text-amber-400 font-mono">
                          <span className="font-bold">{note.sermonTitle}</span>
                          <span>{note.date}</span>
                        </div>
                        <p className="text-xs text-slate-300 whitespace-pre-wrap">{note.content}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredSermons.map((sermon) => {
            const isSelected = selectedSermon.id === sermon.id;
            const isBookmarked = bookmarkedSermonIds.includes(sermon.id);

            return (
              <div
                key={sermon.id}
                onClick={() => setSelectedSermon(sermon)}
                className={`p-5 rounded-2xl border transition-all duration-300 cursor-pointer space-y-3 relative ${
                  isSelected
                    ? 'bg-gradient-to-br from-amber-950/40 via-slate-900 to-slate-950 border-amber-400/50 shadow-xl'
                    : 'bg-slate-900/60 hover:bg-slate-900 border-amber-500/10 hover:border-amber-500/30'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-400/20">
                        {sermon.category}
                      </span>
                      <button
                        onClick={(e) => toggleBookmark(sermon.id, e)}
                        className={`p-1.5 rounded-lg border transition-colors ${
                          isBookmarked
                            ? 'bg-amber-500 text-slate-950 border-amber-400'
                            : 'bg-slate-950/60 text-slate-400 hover:text-amber-300 border-amber-500/20'
                        }`}
                        title={isBookmarked ? 'Bookmarked to Profile' : 'Bookmark Sermon'}
                      >
                        <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-slate-950' : ''}`} />
                      </button>
                      <button
                        onClick={(e) => handleShareSermon(sermon, e)}
                        className="p-1.5 rounded-lg border bg-slate-950/60 text-slate-400 hover:text-amber-300 border-amber-500/20 transition-colors"
                        title="Share Sermon"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <h4 className="text-base font-bold text-amber-100 font-serif">{sermon.title}</h4>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handlePlaySermon(sermon);
                    }}
                    className="p-3 rounded-full bg-amber-500 hover:bg-amber-400 text-slate-950 flex-shrink-0 transition-transform active:scale-95 shadow-md shadow-amber-500/20"
                  >
                    <Play className="w-4 h-4 fill-slate-950" />
                  </button>
                </div>

                <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">{sermon.summary}</p>

                <div className="flex items-center justify-between pt-2 border-t border-amber-500/10 text-[11px] text-slate-400">
                  <div className="flex items-center space-x-3">
                    <span className="flex items-center">
                      <Clock className="w-3 h-3 mr-1 text-amber-400" />
                      {sermon.duration}
                    </span>
                    <span>{sermon.date}</span>
                  </div>

                  <div className="flex items-center space-x-1 text-amber-300">
                    <BookOpen className="w-3 h-3" />
                    <span>{sermon.keyScriptures.length} Scriptures</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
