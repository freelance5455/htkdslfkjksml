"use client";

import { useState } from "react";
import { Check, ChevronDown } from "lucide-react";
import type { Lesson } from "@/data/paths";
import { toArabicDigits } from "@/lib/site";
import { useLocalState } from "@/lib/use-local-state";

/** Completion map for one path, persisted in localStorage. */
export function useLessonProgress(pathSlug: string) {
  return useLocalState<Record<string, boolean>>(`lia:progress:${pathSlug}`, {});
}

type Props = {
  pathSlug: string;
  lessons: Lesson[];
  /** "compact" = titles + summaries (homepage); "full" = expandable lesson bodies. */
  variant?: "compact" | "full";
};

export function LessonList({ pathSlug, lessons, variant = "compact" }: Props) {
  const [completed, setCompleted] = useLessonProgress(pathSlug);
  const [openId, setOpenId] = useState<string | null>(null);

  const doneCount = lessons.filter((l) => completed[l.id]).length;
  const percent = lessons.length ? (doneCount / lessons.length) * 100 : 0;

  const toggle = (id: string) => setCompleted((prev) => ({ ...prev, [id]: !prev[id] }));

  return (
    <div>
      <div className="mb-6 flex items-center justify-between gap-4">
        <p className="font-serif text-xl font-bold text-navy sm:text-2xl">
          دروس المسار
        </p>
        <span className="text-sm text-gold tabular-nums" aria-live="polite">
          {toArabicDigits(doneCount)} / {toArabicDigits(lessons.length)} مكتمل
        </span>
      </div>
      <div className="mb-6 h-1.5 overflow-hidden rounded-full bg-ivory">
        <div
          className="h-full rounded-full bg-gradient-to-l from-gold to-royal transition-all duration-700"
          style={{ width: `${percent}%` }}
        />
      </div>

      <ol className="relative space-y-4 before:absolute before:inset-y-4 before:start-5 before:w-px before:bg-gold/30">
        {lessons.map((lesson, i) => {
          const done = !!completed[lesson.id];
          const isOpen = openId === lesson.id;
          return (
            <li key={lesson.id} className="relative flex gap-4">
              <button
                type="button"
                aria-pressed={done}
                aria-label={`${done ? "إلغاء تحديد" : "تحديد"} ${lesson.title} كمكتمل`}
                onClick={() => toggle(lesson.id)}
                className={`relative z-10 grid size-10 shrink-0 place-items-center rounded-full border-2 transition-all duration-300 ${
                  done ? "border-gold bg-gold text-navy" : "border-gold/40 bg-ivory text-gold hover:border-gold"
                }`}
              >
                {done ? <Check className="size-4" aria-hidden="true" /> : <span className="font-serif">{toArabicDigits(i + 1)}</span>}
              </button>
              <div className="flex-1 rounded-2xl bg-ivory p-4 shadow-sm">
                <p className="font-semibold text-navy">{lesson.title}</p>
                <p className="mt-1 text-sm leading-6 text-navy/60">{lesson.summary}</p>

                {variant === "full" && (
                  <>
                    <button
                      type="button"
                      onClick={() => setOpenId(isOpen ? null : lesson.id)}
                      aria-expanded={isOpen}
                      className="mt-3 inline-flex items-center gap-2 text-sm font-medium text-royal transition-colors hover:text-gold"
                    >
                      {isOpen ? "إخفاء نص الدرس" : "اقرأ نص الدرس"}
                      <ChevronDown className={`size-4 transition-transform ${isOpen ? "rotate-180" : ""}`} aria-hidden="true" />
                    </button>
                    {isOpen && (
                      <div className="mt-4 space-y-3 border-t border-gold/20 pt-4 leading-8 text-navy/80">
                        {lesson.body.map((paragraph, idx) => (
                          <p key={idx} className="font-serif text-lg leading-[2] text-navy/85">
                            {paragraph}
                          </p>
                        ))}
                      </div>
                    )}
                  </>
                )}
              </div>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
