"use client";

import { useState } from "react";
import { getPalette, posterStyle } from "@/lib/palette";
import { posterSrc } from "@/lib/posters";

type PosterImageProps = {
  src?: string | null;
  palette: string;
  alt: string;
  className?: string;
  width?: number;
  eager?: boolean;
  emojiClassName?: string;
};

/**
 * Copertina reale del film con fallback a tema (gradiente + emoji) se
 * l'immagine non è disponibile.
 */
export function PosterImage({
  src,
  palette,
  alt,
  className = "",
  width = 400,
  eager = false,
  emojiClassName = "text-5xl",
}: PosterImageProps) {
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);
  const url = posterSrc(src, width);
  const colors = getPalette(palette);

  return (
    <div className={`relative overflow-hidden ${className}`} style={posterStyle(palette)}>
      <div className="halftone absolute inset-0 opacity-15" />
      {!failed && url ? (
        <img
          src={url}
          alt={alt}
          loading={eager ? "eager" : "lazy"}
          decoding="async"
          onLoad={() => setLoaded(true)}
          onError={() => setFailed(true)}
          className={`h-full w-full object-cover transition-all duration-700 ease-out ${
            loaded ? "scale-100 opacity-100 blur-0" : "scale-105 opacity-0 blur-sm"
          }`}
        />
      ) : (
        <div className="grid h-full w-full place-items-center">
          <span className={`${emojiClassName} opacity-40`}>{colors.emoji}</span>
        </div>
      )}
      {!loaded && !failed ? <div className="poster-shimmer absolute inset-0" /> : null}
    </div>
  );
}
