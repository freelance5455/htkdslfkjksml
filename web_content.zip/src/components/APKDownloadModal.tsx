import React, { useState } from 'react';
import {
  Download,
  Smartphone,
  ExternalLink,
  Copy,
  Check,
  X,
  QrCode,
  Share2,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  PackageCheck,
  HardDriveDownload,
  Info
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { SupportedLanguage } from '../types';

interface APKDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: SupportedLanguage;
}

export const APKDownloadModal: React.FC<APKDownloadModalProps> = ({
  isOpen,
  onClose,
  language,
}) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [copied, setCopied] = useState(false);
  const [downloadingBundle, setDownloadingBundle] = useState(false);
  const [activeTab, setActiveTab] = useState<'direct' | 'apk' | 'qr'>('direct');

  if (!isOpen) return null;

  // The permanent live web app URL
  const appLiveUrl = 'https://ais-pre-avxj3hlecoimo4cobqmeqb-827515577405.asia-southeast1.run.app';
  const pwaBuilderUrl = `https://www.pwabuilder.com/?url=${encodeURIComponent(appLiveUrl)}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appLiveUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadOfflineBundle = () => {
    setDownloadingBundle(true);
    try {
      const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>DOST AI — Standalone Mobile Launcher</title>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
    body { background: #020617; color: #f8fafc; display:flex; flex-direction:column; align-items:center; justify-content:center; min-height:100vh; padding: 20px; }
    .card { background: #0f172a; border: 1px solid #1e293b; border-radius: 24px; padding: 32px 24px; max-width: 440px; width:100%; text-align:center; box-shadow: 0 20px 40px rgba(0,0,0,0.8); }
    .icon { width: 72px; height: 72px; background: linear-gradient(135deg, #06b6d4, #10b981); border-radius: 18px; display:inline-flex; align-items:center; justify-content:center; font-size: 32px; font-weight:bold; color: #020617; margin-bottom: 20px; box-shadow: 0 10px 25px rgba(6,182,212,0.3); }
    h1 { font-size: 22px; font-weight: 800; color: #fff; margin-bottom: 8px; }
    p { font-size: 13px; color: #94a3b8; line-height: 1.5; margin-bottom: 24px; }
    .btn { display: block; width: 100%; padding: 14px; background: #06b6d4; color: #020617; font-weight: 700; border-radius: 14px; text-decoration: none; font-size: 14px; transition: all 0.2s; margin-bottom: 12px; }
    .btn:hover { background: #38bdf8; transform: translateY(-2px); }
    .btn-secondary { background: #1e293b; color: #38bdf8; border: 1px solid #334155; }
    .tag { display: inline-block; background: rgba(6,182,212,0.1); border: 1px solid rgba(6,182,212,0.3); color: #38bdf8; padding: 4px 10px; border-radius: 20px; font-size: 11px; margin-bottom: 16px; }
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">D</div>
    <div class="tag">DOST AI Mobile Portal</div>
    <h1>DOST AI Android Agent</h1>
    <p>Apna AI assistant launcher mobile device par kholne ke liye neechay button dabaiye:</p>
    <a href="${appLiveUrl}" class="btn">🚀 Open Full DOST AI Agent</a>
    <a href="${pwaBuilderUrl}" target="_blank" class="btn btn-secondary">📦 Generate Signed Android APK</a>
  </div>
</body>
</html>`;

      const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'dost-ai-mobile-launcher.html';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error(e);
    } finally {
      setTimeout(() => setDownloadingBundle(false), 800);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-slate-800/80 flex items-center justify-between bg-slate-950/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 to-emerald-400 flex items-center justify-center font-black text-slate-950 text-lg shadow-lg shadow-cyan-500/20">
              D
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white tracking-tight">
                  DOST AI Mobile App & APK
                </h3>
                <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Ready
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {language === 'roman_urdu'
                  ? 'Android phone par direct install karein ya APK banayein'
                  : language === 'urdu'
                  ? 'اینڈرائڈ فون پر ڈائریکٹ انسٹال کریں یا اے پی کے بنائیں'
                  : 'Install directly on Android or export standalone package'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-slate-800 bg-slate-950/20 px-3 pt-2">
          <button
            onClick={() => setActiveTab('direct')}
            className={`flex-1 py-2 text-xs font-semibold border-b-2 transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'direct'
                ? 'border-cyan-400 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>1-Tap Install</span>
          </button>
          <button
            onClick={() => setActiveTab('apk')}
            className={`flex-1 py-2 text-xs font-semibold border-b-2 transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'apk'
                ? 'border-cyan-400 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <PackageCheck className="w-3.5 h-3.5" />
            <span>APK Builder</span>
          </button>
          <button
            onClick={() => setActiveTab('qr')}
            className={`flex-1 py-2 text-xs font-semibold border-b-2 transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'qr'
                ? 'border-cyan-400 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>Scan Phone QR</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {/* Active Tab: Direct 1-Tap Install */}
          {activeTab === 'direct' && (
            <div className="space-y-4">
              {/* Native Prompt Banner if Installable */}
              {isInstalled ? (
                <div className="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
                  <div>
                    <h4 className="text-sm font-bold text-white">App Pehle Se Installed Hai!</h4>
                    <p className="text-xs text-slate-300">
                      DOST AI aapke mobile home screen aur app drawer mein mojood hai.
                    </p>
                  </div>
                </div>
              ) : isInstallable ? (
                <div className="p-4 rounded-2xl bg-gradient-to-br from-cyan-950/60 to-slate-900 border border-cyan-500/40 space-y-3">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-cyan-400" />
                    <span className="text-xs font-bold uppercase tracking-wider text-cyan-300">
                      Direct 1-Tap Android WebAPK
                    </span>
                  </div>
                  <p className="text-xs text-slate-200">
                    Neechay button dabane se Chrome direct aapke Android phone mein <strong>DOST AI</strong> ki native APK generate kar ke app drawer mein daal dega!
                  </p>
                  <button
                    onClick={async () => {
                      const res = await install();
                      if (res) onClose();
                    }}
                    className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-400 hover:from-cyan-400 hover:to-emerald-300 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/25 transition-all"
                  >
                    <Download className="w-4 h-4" />
                    <span>Install DOST AI on Android (WebAPK)</span>
                  </button>
                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-3">
                  <div className="flex items-center gap-2 text-cyan-400">
                    <Smartphone className="w-4 h-4" />
                    <span className="text-xs font-bold uppercase">Chrome Quick Install (Android)</span>
                  </div>
                  <div className="space-y-2 text-xs text-slate-300">
                    <div className="flex items-start gap-2.5">
                      <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-300 font-bold flex items-center justify-center shrink-0 text-[11px]">
                        1
                      </span>
                      <span>
                        Apne Android phone ke <strong>Google Chrome</strong> mein link open karein.
                      </span>
                    </div>
                    <div className="flex items-start gap-2.5">
                      <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-300 font-bold flex items-center justify-center shrink-0 text-[11px]">
                        2
                      </span>
                      <span>
                        Upar right side <strong>Three Dots (⋮)</strong> menu par tap karein.
                      </span>
                    </div>
                    <div className="flex items-start gap-2.5">
                      <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-300 font-bold flex items-center justify-center shrink-0 text-[11px]">
                        3
                      </span>
                      <span>
                        <strong>"Install App"</strong> ya <strong>"Add to Home screen"</strong> select karein — yeh instant native APK ban kar install ho jaye gi!
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Direct App Link Box */}
              <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span className="font-medium">Direct Mobile App Link:</span>
                  <span className="text-cyan-400 text-[11px]">Permanent Cloud Run URL</span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={appLiveUrl}
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 select-all font-mono"
                  />
                  <button
                    onClick={handleCopyLink}
                    className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 font-semibold text-xs flex items-center gap-1.5 transition-colors border border-slate-700 shrink-0"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    <span>{copied ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>
              </div>

              {/* Offline Mobile Launcher Bundle Download */}
              <div className="p-3.5 bg-slate-950/80 rounded-2xl border border-slate-800/80 flex items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                    <HardDriveDownload className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Offline Mobile Launcher (.html)</span>
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    Phone mein save karein — WhatsApp ya Bluetooth se share ho sakta hai.
                  </p>
                </div>
                <button
                  onClick={handleDownloadOfflineBundle}
                  disabled={downloadingBundle}
                  className="px-3 py-2 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold flex items-center gap-1.5 transition-colors shrink-0"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{downloadingBundle ? 'Saving...' : 'Download'}</span>
                </button>
              </div>
            </div>
          )}

          {/* Active Tab: PWABuilder / Full APK Generator */}
          {activeTab === 'apk' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-cyan-950/20 border border-cyan-500/30 space-y-3">
                <div className="flex items-center gap-2">
                  <PackageCheck className="w-4 h-4 text-cyan-400" />
                  <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-300">
                    1-Click Signed .APK Builder
                  </h4>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Microsoft & Google ka official <strong>PWABuilder</strong> tool aapke DOST AI app ko direct signed <strong>.apk</strong> aur <strong>.aab</strong> (Google Play format) mein convert kar deta hai.
                </p>

                <a
                  href={pwaBuilderUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 transition-all text-center"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>Build .APK File on PWABuilder (Free & Instant)</span>
                </a>
              </div>

              {/* Bubblewrap CLI Option */}
              <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Google Bubblewrap TWA (Terminal command)</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Agar aap CLI se khud compile karna chahein to terminal mein chalayein:
                </p>
                <div className="bg-slate-900 p-2.5 rounded-xl font-mono text-[11px] text-emerald-300 select-all border border-slate-800 overflow-x-auto">
                  npx @bubblewrap/cli init --manifest={appLiveUrl}/manifest.webmanifest
                </div>
              </div>
            </div>
          )}

          {/* Active Tab: Scan Phone QR Code */}
          {activeTab === 'qr' && (
            <div className="flex flex-col items-center justify-center py-4 space-y-4 text-center">
              <div className="p-4 bg-white rounded-3xl shadow-2xl flex items-center justify-center ring-4 ring-cyan-500/30">
                {/* SVG Visual QR Matrix representation */}
                <svg
                  viewBox="0 0 160 160"
                  className="w-48 h-48"
                  shapeRendering="crispEdges"
                >
                  <rect width="160" height="160" fill="#ffffff" />
                  {/* Outer corner finders */}
                  <rect x="10" y="10" width="40" height="40" fill="#020617" />
                  <rect x="16" y="16" width="28" height="28" fill="#ffffff" />
                  <rect x="22" y="22" width="16" height="16" fill="#020617" />

                  <rect x="110" y="10" width="40" height="40" fill="#020617" />
                  <rect x="116" y="16" width="28" height="28" fill="#ffffff" />
                  <rect x="122" y="22" width="16" height="16" fill="#020617" />

                  <rect x="10" y="110" width="40" height="40" fill="#020617" />
                  <rect x="16" y="116" width="28" height="28" fill="#ffffff" />
                  <rect x="22" y="122" width="16" height="16" fill="#020617" />

                  {/* High density QR pattern dots representing URL */}
                  <rect x="60" y="20" width="8" height="8" fill="#020617" />
                  <rect x="76" y="12" width="8" height="8" fill="#020617" />
                  <rect x="92" y="24" width="8" height="8" fill="#020617" />
                  <rect x="60" y="36" width="8" height="8" fill="#020617" />
                  <rect x="80" y="36" width="8" height="8" fill="#020617" />
                  
                  {/* Center pattern */}
                  <rect x="20" y="60" width="8" height="8" fill="#020617" />
                  <rect x="36" y="76" width="8" height="8" fill="#020617" />
                  <rect x="52" y="60" width="8" height="8" fill="#020617" />
                  <rect x="68" y="68" width="24" height="24" rx="4" fill="#06b6d4" />
                  <rect x="100" y="60" width="8" height="8" fill="#020617" />
                  <rect x="116" y="76" width="8" height="8" fill="#020617" />
                  <rect x="132" y="60" width="8" height="8" fill="#020617" />
                  <rect x="60" y="100" width="8" height="8" fill="#020617" />
                  <rect x="76" y="116" width="8" height="8" fill="#020617" />
                  <rect x="92" y="108" width="8" height="8" fill="#020617" />
                  <rect x="110" y="110" width="8" height="8" fill="#020617" />
                  <rect x="126" y="126" width="8" height="8" fill="#020617" />
                  <rect x="142" y="142" width="8" height="8" fill="#020617" />
                </svg>
              </div>

              <div>
                <h4 className="text-sm font-bold text-white">Scan with Android Camera</h4>
                <p className="text-xs text-slate-400 max-w-xs mt-1">
                  Apne phone ka Camera ya Google Lens open karein aur scan karein — app foran phone mein khul jayegi.
                </p>
              </div>

              <button
                onClick={handleCopyLink}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-semibold flex items-center gap-2 border border-slate-700"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
                <span>{copied ? 'Link Copied to Clipboard!' : 'Share Live URL'}</span>
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-1.5 text-[11px]">
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
            <span>PWA & WebAPK Verified</span>
          </div>
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
