import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Gamepad2,
  Brain,
  Sparkles,
  Trophy,
  RotateCcw,
  CheckCircle2,
  XCircle,
  HelpCircle,
  ChevronLeft,
  Flame,
  Award,
  Clock,
  Shuffle,
  Lightbulb,
} from 'lucide-react';
import { Student } from '../types';

interface GamesViewProps {
  student: Student;
  onBackToHome: () => void;
}

type GameMode = 'hub' | 'math' | 'memory' | 'word' | 'pattern';

// ----------------------------------------------------
// WORD SCRAMBLE DATA
// ----------------------------------------------------
interface WordPuzzle {
  word: string;
  hint: string;
  category: string;
}

const WORD_PUZZLES: WordPuzzle[] = [
  { word: 'SCHOOL', hint: 'A wonderful place where we learn and play', category: 'Education' },
  { word: 'PENCIL', hint: 'Used for writing notes and drawing pictures', category: 'Stationery' },
  { word: 'PLANET', hint: 'Earth, Mars, and Jupiter are examples', category: 'Science' },
  { word: 'TEACHER', hint: 'The caring guide who educates and inspires us', category: 'People' },
  { word: 'FLOWER', hint: 'Roses, sunflowers, and lotus in the garden', category: 'Nature' },
  { word: 'LIBRARY', hint: 'A quiet room filled with shelves of books', category: 'Education' },
  { word: 'MOUNTAIN', hint: 'High rocky land with tall snowy peaks', category: 'Geography' },
  { word: 'SUNSHINE', hint: 'Warm golden light from the morning sky', category: 'Weather' },
  { word: 'FRIEND', hint: 'Someone you love to play and study with', category: 'Social' },
  { word: 'SCIENCE', hint: 'Discovering how nature and the universe work', category: 'Subjects' },
  { word: 'HOLIDAY', hint: 'A fun day off from school to relax', category: 'Events' },
  { word: 'BUTTERFLY', hint: 'Colorful insect with beautiful wings', category: 'Animals' },
];

// ----------------------------------------------------
// PATTERN PUZZLE DATA
// ----------------------------------------------------
interface PatternQuestion {
  sequence: string;
  options: number[];
  answer: number;
  explanation: string;
}

const PATTERN_QUESTIONS: PatternQuestion[] = [
  {
    sequence: '2, 4, 6, 8, ?',
    options: [9, 10, 12, 14],
    answer: 10,
    explanation: 'Adding +2 each step (Even numbers sequence)',
  },
  {
    sequence: '5, 10, 15, 20, ?',
    options: [22, 25, 30, 35],
    answer: 25,
    explanation: 'Counting by 5s (+5 each time)',
  },
  {
    sequence: '100, 90, 80, 70, ?',
    options: [50, 60, 65, 75],
    answer: 60,
    explanation: 'Subtracting 10 each step (-10)',
  },
  {
    sequence: '3, 6, 9, 12, ?',
    options: [13, 14, 15, 18],
    answer: 15,
    explanation: 'Multiples of 3 (3, 6, 9, 12, 15)',
  },
  {
    sequence: '1, 4, 9, 16, ?',
    options: [20, 24, 25, 36],
    answer: 25,
    explanation: 'Square numbers: 1×1, 2×2, 3×3, 4×4, 5×5 = 25',
  },
  {
    sequence: '2, 4, 8, 16, ?',
    options: [24, 30, 32, 64],
    answer: 32,
    explanation: 'Doubling each number (×2 each step)',
  },
  {
    sequence: '1, 1, 2, 3, 5, ?',
    options: [6, 7, 8, 9],
    answer: 8,
    explanation: 'Fibonacci rule: add the previous two numbers (3 + 5 = 8)',
  },
  {
    sequence: '11, 22, 33, 44, ?',
    options: [45, 50, 55, 66],
    answer: 55,
    explanation: 'Multiples of 11 (+11 each time)',
  },
];

// ----------------------------------------------------
// MEMORY MATCH CARDS (6 Pairs = 12 Cards)
// ----------------------------------------------------
const MEMORY_SYMBOLS = [
  { id: 'book', symbol: '📚', label: 'Book' },
  { id: 'star', symbol: '⭐', label: 'Star' },
  { id: 'rocket', symbol: '🚀', label: 'Rocket' },
  { id: 'apple', symbol: '🍎', label: 'Apple' },
  { id: 'pencil', symbol: '✏️', label: 'Pencil' },
  { id: 'globe', symbol: '🌍', label: 'Globe' },
];

export const GamesView: React.FC<GamesViewProps> = ({ student, onBackToHome }) => {
  const [activeMode, setActiveMode] = useState<GameMode>('hub');
  const [totalStars, setTotalStars] = useState<number>(() => {
    try {
      return Number(localStorage.getItem('kbssn_brain_stars') || 0);
    } catch {
      return 0;
    }
  });

  const addStars = useCallback((count: number) => {
    setTotalStars((prev) => {
      const next = prev + count;
      try {
        localStorage.setItem('kbssn_brain_stars', String(next));
      } catch {
        // ignore
      }
      return next;
    });
  }, []);

  // ----------------------------------------------------------------
  // 1. SPEED MATH GAME STATE
  // ----------------------------------------------------------------
  const [mathLevel, setMathLevel] = useState<'easy' | 'medium' | 'hard'>('easy');
  const [mathScore, setMathScore] = useState(0);
  const [mathStreak, setMathStreak] = useState(0);
  const [mathTimeLeft, setMathTimeLeft] = useState(45);
  const [mathIsPlaying, setMathIsPlaying] = useState(false);
  const [mathProblem, setMathProblem] = useState<{
    num1: number;
    num2: number;
    op: string;
    answer: number;
    options: number[];
  }>({ num1: 2, num2: 3, op: '+', answer: 5, options: [4, 5, 6, 7] });
  const [mathFeedback, setMathFeedback] = useState<'correct' | 'wrong' | null>(null);

  const generateMathProblem = useCallback((level: 'easy' | 'medium' | 'hard') => {
    let n1 = 0;
    let n2 = 0;
    let op = '+';
    let ans = 0;

    if (level === 'easy') {
      op = Math.random() > 0.4 ? '+' : '-';
      if (op === '+') {
        n1 = Math.floor(Math.random() * 9) + 1;
        n2 = Math.floor(Math.random() * 9) + 1;
        ans = n1 + n2;
      } else {
        n1 = Math.floor(Math.random() * 12) + 3;
        n2 = Math.floor(Math.random() * n1) + 1;
        ans = n1 - n2;
      }
    } else if (level === 'medium') {
      const pick = Math.random();
      if (pick < 0.4) {
        op = '+';
        n1 = Math.floor(Math.random() * 40) + 10;
        n2 = Math.floor(Math.random() * 30) + 5;
        ans = n1 + n2;
      } else if (pick < 0.7) {
        op = '-';
        n1 = Math.floor(Math.random() * 50) + 20;
        n2 = Math.floor(Math.random() * 20) + 5;
        ans = n1 - n2;
      } else {
        op = '×';
        n1 = Math.floor(Math.random() * 9) + 2;
        n2 = Math.floor(Math.random() * 9) + 2;
        ans = n1 * n2;
      }
    } else {
      const pick = Math.random();
      if (pick < 0.5) {
        op = '×';
        n1 = Math.floor(Math.random() * 12) + 3;
        n2 = Math.floor(Math.random() * 10) + 2;
        ans = n1 * n2;
      } else {
        op = '÷';
        n2 = Math.floor(Math.random() * 8) + 2;
        ans = Math.floor(Math.random() * 10) + 2;
        n1 = ans * n2;
      }
    }

    // Generate 3 wrong options
    const optionsSet = new Set<number>([ans]);
    while (optionsSet.size < 4) {
      const offset = (Math.floor(Math.random() * 5) + 1) * (Math.random() > 0.5 ? 1 : -1);
      const wrong = Math.max(0, ans + offset);
      optionsSet.add(wrong);
    }
    const options = Array.from(optionsSet).sort(() => Math.random() - 0.5);

    return { num1: n1, num2: n2, op, answer: ans, options };
  }, []);

  const startMathGame = () => {
    setMathScore(0);
    setMathStreak(0);
    setMathTimeLeft(45);
    setMathIsPlaying(true);
    setMathFeedback(null);
    setMathProblem(generateMathProblem(mathLevel));
  };

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (mathIsPlaying && mathTimeLeft > 0) {
      timer = setInterval(() => {
        setMathTimeLeft((t) => t - 1);
      }, 1000);
    } else if (mathTimeLeft === 0 && mathIsPlaying) {
      setMathIsPlaying(false);
      // Award stars based on score
      if (mathScore > 0) {
        const earned = Math.ceil(mathScore / 2);
        addStars(earned);
      }
    }
    return () => clearInterval(timer);
  }, [mathIsPlaying, mathTimeLeft, mathScore, addStars]);

  const handleMathAnswer = (chosen: number) => {
    if (!mathIsPlaying) return;

    if (chosen === mathProblem.answer) {
      setMathScore((s) => s + 1);
      setMathStreak((st) => st + 1);
      setMathFeedback('correct');
      setTimeout(() => {
        setMathFeedback(null);
        setMathProblem(generateMathProblem(mathLevel));
      }, 350);
    } else {
      setMathStreak(0);
      setMathFeedback('wrong');
      setTimeout(() => {
        setMathFeedback(null);
        setMathProblem(generateMathProblem(mathLevel));
      }, 400);
    }
  };

  // ----------------------------------------------------------------
  // 2. MEMORY MATCH STATE
  // ----------------------------------------------------------------
  interface CardItem {
    instanceId: number;
    symbolId: string;
    symbol: string;
    label: string;
  }

  const [memoryCards, setMemoryCards] = useState<CardItem[]>([]);
  const [flippedIndices, setFlippedIndices] = useState<number[]>([]);
  const [matchedIds, setMatchedIds] = useState<string[]>([]);
  const [memoryMoves, setMemoryMoves] = useState(0);
  const [memoryWon, setMemoryWon] = useState(false);

  const initMemoryGame = useCallback(() => {
    const deck: CardItem[] = [];
    MEMORY_SYMBOLS.forEach((item, idx) => {
      deck.push({
        instanceId: idx * 2,
        symbolId: item.id,
        symbol: item.symbol,
        label: item.label,
      });
      deck.push({
        instanceId: idx * 2 + 1,
        symbolId: item.id,
        symbol: item.symbol,
        label: item.label,
      });
    });
    setMemoryCards(deck.sort(() => Math.random() - 0.5));
    setFlippedIndices([]);
    setMatchedIds([]);
    setMemoryMoves(0);
    setMemoryWon(false);
  }, []);

  const handleFlipCard = (index: number) => {
    if (flippedIndices.length >= 2) return;
    if (flippedIndices.includes(index)) return;
    if (matchedIds.includes(memoryCards[index].symbolId)) return;

    const nextFlipped = [...flippedIndices, index];
    setFlippedIndices(nextFlipped);

    if (nextFlipped.length === 2) {
      setMemoryMoves((m) => m + 1);
      const [first, second] = nextFlipped;
      if (memoryCards[first].symbolId === memoryCards[second].symbolId) {
        // Matched!
        const newMatched = [...matchedIds, memoryCards[first].symbolId];
        setMatchedIds(newMatched);
        setFlippedIndices([]);
        if (newMatched.length === MEMORY_SYMBOLS.length) {
          setMemoryWon(true);
          addStars(5);
        }
      } else {
        // Not matched, flip back after brief pause
        setTimeout(() => {
          setFlippedIndices([]);
        }, 850);
      }
    }
  };

  // ----------------------------------------------------------------
  // 3. WORD SCRAMBLE STATE
  // ----------------------------------------------------------------
  const [wordIndex, setWordIndex] = useState(0);
  const [scrambledLetters, setScrambledLetters] = useState<{ letter: string; used: boolean }[]>([]);
  const [userLetters, setUserLetters] = useState<number[]>([]); // indexes of used scrambledLetters
  const [wordFeedback, setWordFeedback] = useState<'correct' | 'wrong' | null>(null);
  const [showWordHint, setShowWordHint] = useState(false);
  const [wordScore, setWordScore] = useState(0);

  const currentWordPuzzle = WORD_PUZZLES[wordIndex % WORD_PUZZLES.length];

  const initWordPuzzle = useCallback((puzzle: WordPuzzle) => {
    const letters = puzzle.word.split('');
    // Ensure it is scrambled and not identical to original
    let shuffled = [...letters].sort(() => Math.random() - 0.5);
    if (shuffled.join('') === puzzle.word && letters.length > 2) {
      shuffled = shuffled.reverse();
    }
    setScrambledLetters(shuffled.map((l) => ({ letter: l, used: false })));
    setUserLetters([]);
    setWordFeedback(null);
    setShowWordHint(false);
  }, []);

  useEffect(() => {
    if (activeMode === 'word') {
      initWordPuzzle(currentWordPuzzle);
    }
  }, [activeMode, wordIndex, currentWordPuzzle, initWordPuzzle]);

  const handlePickLetter = (scrambleIdx: number) => {
    if (scrambledLetters[scrambleIdx].used) return;
    if (wordFeedback === 'correct') return;

    const nextUser = [...userLetters, scrambleIdx];
    setUserLetters(nextUser);

    const updatedScrambled = [...scrambledLetters];
    updatedScrambled[scrambleIdx].used = true;
    setScrambledLetters(updatedScrambled);

    // Check if full word formed
    if (nextUser.length === currentWordPuzzle.word.length) {
      const formedWord = nextUser.map((idx) => scrambledLetters[idx].letter).join('');
      if (formedWord === currentWordPuzzle.word) {
        setWordFeedback('correct');
        setWordScore((s) => s + 1);
        addStars(2);
        setTimeout(() => {
          setWordIndex((i) => i + 1);
        }, 1200);
      } else {
        setWordFeedback('wrong');
      }
    }
  };

  const handleRemoveLetter = () => {
    if (userLetters.length === 0 || wordFeedback === 'correct') return;
    const nextUser = [...userLetters];
    const removedIdx = nextUser.pop()!;
    setUserLetters(nextUser);

    const updatedScrambled = [...scrambledLetters];
    updatedScrambled[removedIdx].used = false;
    setScrambledLetters(updatedScrambled);
    setWordFeedback(null);
  };

  const handleClearWord = () => {
    if (wordFeedback === 'correct') return;
    setUserLetters([]);
    setScrambledLetters(scrambledLetters.map((l) => ({ ...l, used: false })));
    setWordFeedback(null);
  };

  // ----------------------------------------------------------------
  // 4. PATTERN PUZZLE STATE
  // ----------------------------------------------------------------
  const [patternIndex, setPatternIndex] = useState(0);
  const [patternScore, setPatternScore] = useState(0);
  const [patternAnswered, setPatternAnswered] = useState<number | null>(null);

  const currentPattern = PATTERN_QUESTIONS[patternIndex % PATTERN_QUESTIONS.length];

  const handleSelectPatternOption = (opt: number) => {
    if (patternAnswered !== null) return;
    setPatternAnswered(opt);
    if (opt === currentPattern.answer) {
      setPatternScore((s) => s + 1);
      addStars(2);
    }
  };

  const handleNextPattern = () => {
    setPatternAnswered(null);
    setPatternIndex((i) => i + 1);
  };

  // ================================================================
  // RENDER: GAME HUB (MAIN SELECTION)
  // ================================================================
  if (activeMode === 'hub') {
    return (
      <div className="space-y-4 pb-6 animate-fadeIn">
        {/* Header with Student and Stars */}
        <div className="bg-gradient-to-r from-violet-600 via-indigo-600 to-blue-600 rounded-3xl p-5 text-white shadow-md relative overflow-hidden">
          <div className="absolute -right-8 -bottom-8 w-32 h-32 bg-white/10 rounded-full blur-xl pointer-events-none" />
          <div className="flex items-center justify-between relative z-10">
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/20 backdrop-blur-md text-[11px] font-bold">
                <Brain className="w-3.5 h-3.5" />
                <span>KBSSN Mind Gym</span>
              </div>
              <h1 className="text-xl font-black mt-1.5 tracking-tight">
                {student.name}&apos;s Brain Games 🧠
              </h1>
              <p className="text-xs text-indigo-100 font-medium mt-0.5">
                Fun educational puzzles to boost memory, math & thinking!
              </p>
            </div>

            <div className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white/15 backdrop-blur-md border border-white/20 shrink-0 text-center">
              <Trophy className="w-6 h-6 text-amber-300" />
              <span className="text-lg font-black text-white leading-none mt-1">
                {totalStars}
              </span>
              <span className="text-[10px] font-bold text-amber-200 uppercase tracking-tight">
                Brain Stars
              </span>
            </div>
          </div>
        </div>

        {/* 4 Kid-Friendly Games Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Game 1: Speed Math */}
          <button
            onClick={() => {
              setActiveMode('math');
              setMathIsPlaying(false);
            }}
            className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs hover:shadow-md hover:border-blue-400 transition text-left group relative overflow-hidden"
          >
            <div className="flex items-start justify-between">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 border border-blue-200 flex items-center justify-center text-2xl group-hover:scale-105 transition">
                ⚡
              </div>
              <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 text-[10px] font-bold">
                Math Speed
              </span>
            </div>
            <h3 className="text-base font-black text-slate-900 mt-3">Speed Math Sprint</h3>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              Solve fast additions, subtractions & times tables before time runs out!
            </p>
            <div className="mt-3 flex items-center gap-1.5 text-xs font-bold text-blue-600">
              <span>Play Now</span>
              <span>→</span>
            </div>
          </button>

          {/* Game 2: Memory Match */}
          <button
            onClick={() => {
              setActiveMode('memory');
              initMemoryGame();
            }}
            className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs hover:shadow-md hover:border-emerald-400 transition text-left group relative overflow-hidden"
          >
            <div className="flex items-start justify-between">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center justify-center text-2xl group-hover:scale-105 transition">
                🃏
              </div>
              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 text-[10px] font-bold">
                Focus & Memory
              </span>
            </div>
            <h3 className="text-base font-black text-slate-900 mt-3">Memory Card Match</h3>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              Flip and pair matching school & science cards to sharpen your visual memory!
            </p>
            <div className="mt-3 flex items-center gap-1.5 text-xs font-bold text-emerald-600">
              <span>Play Now</span>
              <span>→</span>
            </div>
          </button>

          {/* Game 3: Word Scramble */}
          <button
            onClick={() => {
              setActiveMode('word');
            }}
            className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs hover:shadow-md hover:border-amber-400 transition text-left group relative overflow-hidden"
          >
            <div className="flex items-start justify-between">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 border border-amber-200 flex items-center justify-center text-2xl group-hover:scale-105 transition">
                🔤
              </div>
              <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 text-[10px] font-bold">
                Spelling & Vocab
              </span>
            </div>
            <h3 className="text-base font-black text-slate-900 mt-3">Word Scramble Master</h3>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              Unscramble jumbled letter bubbles to discover school and nature words!
            </p>
            <div className="mt-3 flex items-center gap-1.5 text-xs font-bold text-amber-600">
              <span>Play Now</span>
              <span>→</span>
            </div>
          </button>

          {/* Game 4: Pattern & Sequence */}
          <button
            onClick={() => {
              setActiveMode('pattern');
            }}
            className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs hover:shadow-md hover:border-purple-400 transition text-left group relative overflow-hidden"
          >
            <div className="flex items-start justify-between">
              <div className="w-12 h-12 rounded-2xl bg-purple-50 text-purple-600 border border-purple-200 flex items-center justify-center text-2xl group-hover:scale-105 transition">
                🧩
              </div>
              <span className="px-2 py-0.5 rounded-full bg-purple-100 text-purple-700 text-[10px] font-bold">
                Logic & Thinking
              </span>
            </div>
            <h3 className="text-base font-black text-slate-900 mt-3">Sequence & Logic Quiz</h3>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              Find out what comes next in number patterns and brain teasers!
            </p>
            <div className="mt-3 flex items-center gap-1.5 text-xs font-bold text-purple-600">
              <span>Play Now</span>
              <span>→</span>
            </div>
          </button>
        </div>

        {/* Learning Motivation Card */}
        <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200/90 text-amber-900 text-xs flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-amber-200/60 text-amber-800 flex items-center justify-center shrink-0">
            <Sparkles className="w-5 h-5 text-amber-700" />
          </div>
          <div>
            <span className="font-black text-amber-950">Daily Brain Tip:</span>
            <p className="text-amber-800 mt-0.5 leading-tight">
              Playing 5 minutes of mental math and memory puzzles every day improves concentration in class!
            </p>
          </div>
        </div>
      </div>
    );
  }

  // ================================================================
  // RENDER: SPEED MATH SPRINT
  // ================================================================
  if (activeMode === 'math') {
    return (
      <div className="space-y-4 pb-6 animate-fadeIn">
        {/* Game Top Navigation */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => setActiveMode('hub')}
            className="inline-flex items-center gap-1 text-xs font-bold text-slate-600 hover:text-slate-900 px-2.5 py-1.5 rounded-xl bg-white border border-slate-200 shadow-2xs"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Games Menu</span>
          </button>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-xl bg-amber-50 border border-amber-200 text-amber-700 text-xs font-bold flex items-center gap-1">
              <Trophy className="w-3.5 h-3.5" />
              <span>{totalStars} Stars</span>
            </span>
          </div>
        </div>

        {!mathIsPlaying ? (
          <div className="bg-white rounded-3xl p-6 border border-slate-200 text-center space-y-4 shadow-sm">
            <div className="w-16 h-16 rounded-3xl bg-blue-50 text-blue-600 border border-blue-200 flex items-center justify-center text-3xl mx-auto shadow-inner">
              ⚡
            </div>
            <div>
              <h2 className="text-xl font-black text-slate-900">Speed Math Sprint</h2>
              <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                Answer as many quick mental math equations as you can in 45 seconds!
              </p>
            </div>

            {/* Level Selector */}
            <div className="space-y-1.5 text-left max-w-xs mx-auto">
              <label className="text-xs font-bold text-slate-700">Choose Difficulty:</label>
              <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 rounded-2xl">
                {(['easy', 'medium', 'hard'] as const).map((lvl) => (
                  <button
                    key={lvl}
                    onClick={() => setMathLevel(lvl)}
                    className={`py-1.5 rounded-xl text-xs font-bold uppercase transition ${
                      mathLevel === lvl
                        ? 'bg-blue-600 text-white shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>

            {mathScore > 0 && (
              <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold">
                🎉 Last Round Score: {mathScore} Correct! (+{Math.ceil(mathScore / 2)} Stars Earned)
              </div>
            )}

            <button
              onClick={startMathGame}
              className="w-full max-w-xs py-3.5 px-6 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-black text-sm uppercase tracking-wider shadow-md hover:shadow-lg transition active:scale-95 mx-auto"
            >
              Start Sprint 🚀
            </button>
          </div>
        ) : (
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-4">
            {/* Status bar */}
            <div className="flex items-center justify-between px-1">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-600">
                <Clock className="w-4 h-4 text-blue-600" />
                <span className={`text-base font-black ${mathTimeLeft <= 10 ? 'text-red-600 animate-pulse' : 'text-slate-800'}`}>
                  {mathTimeLeft}s
                </span>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1 text-xs font-bold text-amber-600">
                  <Flame className="w-4 h-4 text-amber-500 fill-amber-400" />
                  <span>Streak: {mathStreak}</span>
                </div>
                <div className="px-2.5 py-1 rounded-xl bg-blue-50 text-blue-700 text-xs font-black border border-blue-200">
                  Score: {mathScore}
                </div>
              </div>
            </div>

            {/* Big Math Equation Box */}
            <div
              className={`p-6 rounded-3xl text-center transition-all ${
                mathFeedback === 'correct'
                  ? 'bg-emerald-50 border-2 border-emerald-400 scale-102'
                  : mathFeedback === 'wrong'
                  ? 'bg-red-50 border-2 border-red-400 shake'
                  : 'bg-slate-50 border border-slate-200'
              }`}
            >
              <div className="text-3xl font-black text-slate-900 tracking-wider">
                {mathProblem.num1} {mathProblem.op} {mathProblem.num2} = ?
              </div>
            </div>

            {/* 4 Option Buttons */}
            <div className="grid grid-cols-2 gap-2.5">
              {mathProblem.options.map((opt, i) => (
                <button
                  key={i}
                  onClick={() => handleMathAnswer(opt)}
                  className="py-4 px-3 rounded-2xl bg-white border-2 border-slate-200 hover:border-blue-500 text-xl font-black text-slate-800 shadow-2xs hover:shadow transition active:scale-95 flex items-center justify-center"
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  // ================================================================
  // RENDER: MEMORY MATCH CARDS
  // ================================================================
  if (activeMode === 'memory') {
    return (
      <div className="space-y-4 pb-6 animate-fadeIn">
        {/* Game Top Navigation */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => setActiveMode('hub')}
            className="inline-flex items-center gap-1 text-xs font-bold text-slate-600 hover:text-slate-900 px-2.5 py-1.5 rounded-xl bg-white border border-slate-200 shadow-2xs"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Games Menu</span>
          </button>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-600">Moves: {memoryMoves}</span>
            <button
              onClick={initMemoryGame}
              className="p-1.5 rounded-xl bg-white border border-slate-200 text-slate-600 hover:text-slate-900 transition"
              title="Restart Game"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Congratulations Banner if completed */}
        {memoryWon && (
          <div className="p-4 rounded-3xl bg-emerald-500 text-white text-center space-y-2 shadow-md animate-bounce">
            <Trophy className="w-8 h-8 text-amber-300 mx-auto" />
            <h2 className="text-lg font-black">Fantastic Job, {student.name}!</h2>
            <p className="text-xs text-emerald-100 font-medium">
              You matched all pairs in {memoryMoves} moves! +5 Stars awarded ⭐
            </p>
            <button
              onClick={initMemoryGame}
              className="mt-2 py-2 px-4 rounded-xl bg-white text-emerald-800 font-bold text-xs shadow-xs hover:bg-emerald-50 transition"
            >
              Play Again 🔁
            </button>
          </div>
        )}

        {/* 4x3 Grid of Cards */}
        <div className="grid grid-cols-4 gap-2.5">
          {memoryCards.map((card, index) => {
            const isFlipped = flippedIndices.includes(index);
            const isMatched = matchedIds.includes(card.symbolId);

            return (
              <button
                key={card.instanceId}
                onClick={() => handleFlipCard(index)}
                disabled={isFlipped || isMatched}
                className={`aspect-square rounded-2xl font-black text-2xl flex items-center justify-center transition-all duration-300 transform active:scale-95 shadow-2xs border ${
                  isMatched
                    ? 'bg-emerald-100 border-emerald-300 text-emerald-700 opacity-80'
                    : isFlipped
                    ? 'bg-white border-blue-400 shadow-sm scale-102'
                    : 'bg-gradient-to-br from-indigo-500 to-blue-600 border-indigo-700 text-white hover:brightness-105'
                }`}
              >
                {isFlipped || isMatched ? card.symbol : '❓'}
              </button>
            );
          })}
        </div>

        <p className="text-[11px] text-center text-slate-500 font-medium">
          Tap two cards to flip them over. Match all 6 pairs!
        </p>
      </div>
    );
  }

  // ================================================================
  // RENDER: WORD SCRAMBLE MASTER
  // ================================================================
  if (activeMode === 'word') {
    const formedWord = userLetters.map((idx) => scrambledLetters[idx].letter).join('');

    return (
      <div className="space-y-4 pb-6 animate-fadeIn">
        {/* Top bar */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => setActiveMode('hub')}
            className="inline-flex items-center gap-1 text-xs font-bold text-slate-600 hover:text-slate-900 px-2.5 py-1.5 rounded-xl bg-white border border-slate-200 shadow-2xs"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Games Menu</span>
          </button>
          <div className="flex items-center gap-2 text-xs font-bold text-amber-700 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-xl">
            <span>Score: {wordScore}</span>
          </div>
        </div>

        {/* Puzzle Card */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4 text-center">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
              Word #{wordIndex + 1} • {currentWordPuzzle.category}
            </span>
            <button
              onClick={() => setShowWordHint((h) => !h)}
              className="inline-flex items-center gap-1 text-xs font-bold text-amber-700 hover:text-amber-800 bg-amber-50 px-2.5 py-1 rounded-xl border border-amber-200 transition"
            >
              <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
              <span>Hint</span>
            </button>
          </div>

          {/* Hint Display */}
          {showWordHint && (
            <div className="p-3 rounded-2xl bg-amber-50/80 border border-amber-200 text-xs text-amber-900 font-semibold animate-fadeIn">
              💡 {currentWordPuzzle.hint}
            </div>
          )}

          {/* Target Word Slots */}
          <div className="py-4">
            <div className="flex items-center justify-center gap-1.5 flex-wrap">
              {Array.from({ length: currentWordPuzzle.word.length }).map((_, i) => {
                const char = formedWord[i];
                return (
                  <div
                    key={i}
                    className={`w-10 h-12 rounded-xl flex items-center justify-center text-xl font-black border-2 transition ${
                      char
                        ? wordFeedback === 'correct'
                          ? 'bg-emerald-50 border-emerald-500 text-emerald-800'
                          : wordFeedback === 'wrong'
                          ? 'bg-red-50 border-red-500 text-red-800'
                          : 'bg-blue-50 border-blue-500 text-blue-900'
                        : 'bg-slate-50 border-dashed border-slate-300 text-slate-400'
                    }`}
                  >
                    {char || ''}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Feedback message */}
          {wordFeedback === 'correct' && (
            <p className="text-xs font-bold text-emerald-700 flex items-center justify-center gap-1">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Correct! +2 Stars earned ⭐</span>
            </p>
          )}
          {wordFeedback === 'wrong' && (
            <p className="text-xs font-bold text-red-600 flex items-center justify-center gap-1">
              <XCircle className="w-4 h-4 text-red-500" />
              <span>Not quite right. Try removing letters or tapping clear!</span>
            </p>
          )}

          {/* Scrambled Available Letters */}
          <div className="space-y-1.5 pt-2">
            <div className="text-[11px] font-bold text-slate-500">Tap letters to place:</div>
            <div className="flex items-center justify-center gap-2 flex-wrap">
              {scrambledLetters.map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => handlePickLetter(idx)}
                  disabled={item.used || wordFeedback === 'correct'}
                  className={`w-11 h-11 rounded-2xl font-black text-lg transition-all shadow-2xs border ${
                    item.used
                      ? 'bg-slate-100 border-slate-200 text-slate-300 scale-95'
                      : 'bg-white border-slate-300 hover:border-amber-400 text-slate-800 active:scale-95'
                  }`}
                >
                  {item.letter}
                </button>
              ))}
            </div>
          </div>

          {/* Controls: Backspace & Clear */}
          <div className="flex items-center justify-center gap-2 pt-2">
            <button
              onClick={handleRemoveLetter}
              disabled={userLetters.length === 0 || wordFeedback === 'correct'}
              className="py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition disabled:opacity-40"
            >
              ⌫ Undo
            </button>
            <button
              onClick={handleClearWord}
              disabled={userLetters.length === 0 || wordFeedback === 'correct'}
              className="py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition disabled:opacity-40"
            >
              Clear All
            </button>
            <button
              onClick={() => {
                setWordIndex((i) => i + 1);
              }}
              className="py-2 px-3 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-800 text-xs font-bold transition"
            >
              Skip ⏭️
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ================================================================
  // RENDER: SEQUENCE & PATTERN LOGIC QUIZ
  // ================================================================
  if (activeMode === 'pattern') {
    return (
      <div className="space-y-4 pb-6 animate-fadeIn">
        {/* Game Top Navigation */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => setActiveMode('hub')}
            className="inline-flex items-center gap-1 text-xs font-bold text-slate-600 hover:text-slate-900 px-2.5 py-1.5 rounded-xl bg-white border border-slate-200 shadow-2xs"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Games Menu</span>
          </button>
          <div className="flex items-center gap-2 text-xs font-bold text-purple-700 bg-purple-50 border border-purple-200 px-2.5 py-1 rounded-xl">
            <span>Score: {patternScore}</span>
          </div>
        </div>

        {/* Puzzle Card */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
              Puzzle #{patternIndex + 1}
            </span>
            <span className="text-xs font-bold text-purple-600">Pattern Quiz</span>
          </div>

          <div className="p-6 rounded-3xl bg-purple-50/60 border border-purple-200 text-center space-y-1">
            <div className="text-xs font-bold text-purple-800 uppercase tracking-wider">
              What comes next?
            </div>
            <div className="text-2xl font-black text-slate-900 tracking-wider">
              {currentPattern.sequence}
            </div>
          </div>

          {/* 4 Options */}
          <div className="grid grid-cols-2 gap-2.5">
            {currentPattern.options.map((opt, i) => {
              const isSelected = patternAnswered === opt;
              const isCorrect = opt === currentPattern.answer;

              let btnClass = 'bg-white border-2 border-slate-200 text-slate-800 hover:border-purple-400';
              if (patternAnswered !== null) {
                if (isCorrect) {
                  btnClass = 'bg-emerald-50 border-2 border-emerald-500 text-emerald-800';
                } else if (isSelected) {
                  btnClass = 'bg-red-50 border-2 border-red-500 text-red-800';
                } else {
                  btnClass = 'bg-slate-50 border border-slate-200 text-slate-400 opacity-60';
                }
              }

              return (
                <button
                  key={i}
                  onClick={() => handleSelectPatternOption(opt)}
                  disabled={patternAnswered !== null}
                  className={`py-3.5 px-3 rounded-2xl text-lg font-black shadow-2xs transition active:scale-95 flex items-center justify-center ${btnClass}`}
                >
                  {opt}
                </button>
              );
            })}
          </div>

          {/* Explanation if answered */}
          {patternAnswered !== null && (
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 animate-fadeIn">
              <div className="flex items-center gap-1.5 text-xs font-bold">
                {patternAnswered === currentPattern.answer ? (
                  <span className="text-emerald-700 flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Spot on! +2 Stars ⭐
                  </span>
                ) : (
                  <span className="text-red-600 flex items-center gap-1">
                    <XCircle className="w-4 h-4 text-red-500" />
                    Correct answer was: {currentPattern.answer}
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-600">
                <span className="font-bold text-slate-800">Rule: </span>
                {currentPattern.explanation}
              </p>
              <button
                onClick={handleNextPattern}
                className="w-full py-2.5 px-4 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold transition shadow-xs"
              >
                Next Pattern →
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  return null;
};
