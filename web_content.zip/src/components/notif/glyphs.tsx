import {
  Bell,
  Calendar,
  Clock,
  CloudSun,
  Download,
  Mail,
  MapPin,
  MessageCircle,
  Music,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/cn";
import type { AppIcon } from "@/lib/notif/model";

export const APP_ICONS: Record<AppIcon, LucideIcon> = {
  message: MessageCircle,
  mail: Mail,
  calendar: Calendar,
  clock: Clock,
  cloud: CloudSun,
  music: Music,
  download: Download,
  map: MapPin,
  bell: Bell,
};

export function AppGlyph({
  icon,
  lively = false,
  className,
}: {
  icon: AppIcon;
  lively?: boolean;
  className?: string;
}) {
  const Icon = APP_ICONS[icon];
  return (
    <span
      className={cn(
        "grid size-10 shrink-0 place-items-center rounded-full",
        lively ? "bg-primary text-primary-fg" : "bg-surface-3 text-primary",
        className,
      )}
    >
      <Icon className="size-5" aria-hidden="true" />
    </span>
  );
}
