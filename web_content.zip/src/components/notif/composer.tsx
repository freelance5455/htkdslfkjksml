import { useEffect, useState } from "react";
import { cn } from "@/lib/cn";
import {
  ICONS,
  IMPORTANCE_HELP,
  IMPORTANCE_LABEL,
  IMPORTANCE_ORDER,
  PRIVACY_LABEL,
  REPEAT_LABEL,
  STYLE_LABEL,
  TEMPLATES,
  blankDraft,
  channelById,
  draftFromSchedule,
  materialize,
  toLocalInput,
  type AppIcon,
  type Draft,
  type Importance,
  type NotifStyle,
  type Privacy,
  type Repeat,
  type ShadeItem,
} from "@/lib/notif/model";
import { useNotifStore } from "@/lib/notif/store";
import { AppGlyph, APP_ICONS } from "@/components/notif/glyphs";
import { NotifCard } from "@/components/notif/card";
import { Button, Field, Panel, Switch, controlClass } from "@/components/notif/ui";

type Timing = "10s" | "30s" | "1m" | "5m" | "1h" | "at";

const TIMING: { id: Timing; label: string; ms?: number }[] = [
  { id: "10s", label: "10 dtk", ms: 10_000 },
  { id: "30s", label: "30 dtk", ms: 30_000 },
  { id: "1m", label: "1 mnt", ms: 60_000 },
  { id: "5m", label: "5 mnt", ms: 300_000 },
  { id: "1h", label: "1 jam", ms: 3_600_000 },
  { id: "at", label: "Jam tertentu" },
];

function fireAtFor(timing: Timing, at: string) {
  const preset = TIMING.find((item) => item.id === timing);
  if (preset?.ms) return Date.now() + preset.ms;
  const parsed = new Date(at).getTime();
  return Number.isFinite(parsed) ? parsed : Date.now() + 60_000;
}

export function Composer() {
  const channels = useNotifStore((state) => state.channels);
  const editNonce = useNotifStore((state) => state.editNonce);
  const editId = useNotifStore((state) => state.editId);
  const present = useNotifStore((state) => state.present);
  const scheduleDraft = useNotifStore((state) => state.scheduleDraft);
  const [draft, setDraft] = useState<Draft>(TEMPLATES[1]?.draft ?? blankDraft());
  const [timing, setTiming] = useState<Timing>("10s");
  const [at, setAt] = useState("");
  const [error, setError] = useState("");
  const [author, setAuthor] = useState("");
  const [line, setLine] = useState("");

  useEffect(() => {
    setAt(toLocalInput(Date.now() + 60 * 60 * 1000));
  }, []);

  useEffect(() => {
    if (!editNonce || !editId) return;
    const schedule = useNotifStore.getState().schedules.find((item) => item.id === editId);
    if (!schedule) return;
    setDraft(draftFromSchedule(schedule));
    setTiming("at");
    setAt(toLocalInput(schedule.fireAt));
    setError("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [editNonce, editId]);

  function patch(partial: Partial<Draft>) {
    setDraft((current) => ({ ...current, ...partial }));
    setError("");
  }

  function applyTemplate(id: string) {
    const template = TEMPLATES.find((item) => item.id === id);
    if (!template) return;
    setDraft({
      ...template.draft,
      actions: template.draft.actions.map((action) => ({ ...action })),
      chat: template.draft.chat.map((entry) => ({ ...entry })),
    });
    setError("");
  }

  const channel = channelById(channels, draft.channelId);
  const payload = materialize(
    draft.title.trim() ? draft : { ...draft, title: draft.title || "Judul notifikasi" },
    channel,
  );
  const preview: ShadeItem = {
    ...payload,
    id: "preview",
    shownAt: 0,
    expanded: true,
    playing: draft.style === "media",
  };

  function showNow() {
    if (!draft.title.trim()) {
      setError("Isi judul notifikasi.");
      return;
    }
    present(draft);
  }

  function schedule(nextTiming: Timing = timing, asNew = false) {
    if (!draft.title.trim()) {
      setError("Isi judul notifikasi.");
      return;
    }
    const message = scheduleDraft(draft, fireAtFor(nextTiming, at), asNew ? null : editId);
    if (message) setError(message);
  }

  return (
    <form
      className="space-y-4"
      onSubmit={(event) => {
        event.preventDefault();
        schedule();
      }}
    >
      <Panel title="Templat">
        <div className="flex gap-2 overflow-x-auto pb-1">
          {TEMPLATES.map((template) => (
            <button
              key={template.id}
              type="button"
              onClick={() => applyTemplate(template.id)}
              className="min-h-11 shrink-0 rounded-full border border-line bg-surface-2 px-4 text-sm text-fg"
            >
              {template.name}
            </button>
          ))}
        </div>
      </Panel>

      <Panel title="Pengirim">
        <div className="grid gap-4">
          <Field label="Nama aplikasi">
            <input
              value={draft.appName}
              onChange={(event) => patch({ appName: event.target.value })}
              className={controlClass}
              maxLength={32}
              required
            />
          </Field>
          <div className="flex flex-wrap gap-2">
            {ICONS.map((icon) => {
              const Icon = APP_ICONS[icon];
              const selected = draft.icon === icon;
              return (
                <button
                  key={icon}
                  type="button"
                  aria-label={icon}
                  aria-pressed={selected}
                  onClick={() => patch({ icon: icon as AppIcon })}
                  className={cn(
                    "grid size-11 place-items-center rounded-full",
                    selected ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg",
                  )}
                >
                  <Icon className="size-5" />
                </button>
              );
            })}
          </div>
        </div>
      </Panel>

      <Panel title="Isi">
        <div className="grid gap-4">
          <Field label="Saluran" hint="Di Android, suara dan prioritas biasanya diatur di saluran, bukan per notifikasi.">
            <select
              value={draft.channelId}
              onChange={(event) => patch({ channelId: event.target.value })}
              className={controlClass}
            >
              {channels.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name} · {IMPORTANCE_LABEL[item.importance]}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Judul">
            <input
              value={draft.title}
              onChange={(event) => patch({ title: event.target.value })}
              className={controlClass}
              maxLength={80}
              placeholder="Misalnya, Minum air"
              required
            />
          </Field>
          <Field label="Pesan">
            <textarea
              value={draft.body}
              onChange={(event) => patch({ body: event.target.value })}
              className={cn(controlClass, "min-h-24 resize-y")}
              maxLength={240}
              placeholder="Teks singkat di kartu"
            />
          </Field>
          <div>
            <p className="mb-2 text-sm font-medium">Gaya</p>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {(Object.keys(STYLE_LABEL) as NotifStyle[]).map((style) => (
                <button
                  key={style}
                  type="button"
                  aria-pressed={draft.style === style}
                  onClick={() => patch({ style })}
                  className={cn(
                    "min-h-11 rounded-md px-2 text-sm",
                    draft.style === style ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg",
                  )}
                >
                  {STYLE_LABEL[style]}
                </button>
              ))}
            </div>
          </div>
          {draft.style === "bigtext" ? (
            <Field label="Teks panjang">
              <textarea
                value={draft.bigText}
                onChange={(event) => patch({ bigText: event.target.value })}
                className={cn(controlClass, "min-h-28 resize-y")}
                maxLength={500}
              />
            </Field>
          ) : null}
          {draft.style === "inbox" ? (
            <Field label="Baris kotak masuk" hint="Satu baris untuk satu item.">
              <textarea
                value={draft.inboxText}
                onChange={(event) => patch({ inboxText: event.target.value })}
                className={cn(controlClass, "min-h-28 resize-y")}
                placeholder={"Andi: catatan rapat\nSari: undangan"}
              />
            </Field>
          ) : null}
          {draft.style === "chat" ? (
            <div className="space-y-2">
              {draft.chat.map((entry) => (
                <div key={entry.id} className="flex items-start justify-between gap-2 rounded-md bg-surface-2 px-3 py-2">
                  <p className="text-sm">
                    <span className="font-semibold">{entry.author}</span> · {entry.text}
                  </p>
                  <button
                    type="button"
                    className="min-h-11 shrink-0 text-xs text-accent"
                    onClick={() => patch({ chat: draft.chat.filter((item) => item.id !== entry.id) })}
                  >
                    Hapus
                  </button>
                </div>
              ))}
              <div className="grid gap-2 sm:grid-cols-[8rem_1fr_auto]">
                <input
                  value={author}
                  onChange={(event) => setAuthor(event.target.value)}
                  placeholder="Nama"
                  aria-label="Nama pengirim"
                  className={controlClass}
                />
                <input
                  value={line}
                  onChange={(event) => setLine(event.target.value)}
                  placeholder="Pesan"
                  aria-label="Isi pesan"
                  className={controlClass}
                />
                <Button
                  variant="secondary"
                  onClick={() => {
                    if (!line.trim()) return;
                    patch({
                      chat: [
                        ...draft.chat,
                        { id: crypto.randomUUID(), author: author.trim() || "Teman", text: line.trim() },
                      ],
                    });
                    setLine("");
                  }}
                >
                  Tambah
                </Button>
              </div>
            </div>
          ) : null}
          {draft.style === "progress" ? (
            <Field label={`Progres ${draft.progress}%`}>
              <input
                type="range"
                min={0}
                max={100}
                value={draft.progress}
                onChange={(event) => patch({ progress: Number(event.target.value) })}
                className="range w-full"
              />
            </Field>
          ) : null}
        </div>
      </Panel>

      <Panel title="Perilaku Android">
        <Switch
          checked={draft.override}
          onChange={(override) => patch({ override })}
          label="Timpa saluran"
          hint={
            draft.override
              ? "Kepentingan, suara, dan privasi diatur di sini."
              : `Mengikuti saluran ${channel?.name ?? ""}: ${channel ? IMPORTANCE_LABEL[channel.importance] : ""}.`
          }
        />
        <div
          className={cn("mt-3 grid gap-3", !draft.override && "opacity-50")}
          inert={!draft.override}
        >
          <div className="grid grid-cols-5 gap-1">
            {IMPORTANCE_ORDER.map((level) => (
              <button
                key={level}
                type="button"
                aria-pressed={draft.importance === level}
                onClick={() =>
                  patch({
                    importance: level as Importance,
                    headsUp: level === "high" || level === "max",
                  })
                }
                className={cn(
                  "min-h-11 rounded-md px-1 text-xs font-semibold",
                  draft.importance === level ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg",
                )}
              >
                {IMPORTANCE_LABEL[level]}
              </button>
            ))}
          </div>
          <p className="text-xs text-muted">{IMPORTANCE_HELP[draft.override ? draft.importance : (channel?.importance ?? "default")]}</p>
          <Switch checked={draft.headsUp} onChange={(headsUp) => patch({ headsUp })} label="Muncul mengambang (heads-up)" />
          <Switch checked={draft.sound} onChange={(sound) => patch({ sound })} label="Suara" />
          <Switch checked={draft.vibrate} onChange={(vibrate) => patch({ vibrate })} label="Getar" />
          <div>
            <p className="mb-2 text-sm font-medium">Layar kunci</p>
            <div className="grid grid-cols-3 gap-2">
              {(Object.keys(PRIVACY_LABEL) as Privacy[]).map((privacy) => (
                <button
                  key={privacy}
                  type="button"
                  aria-pressed={draft.privacy === privacy}
                  onClick={() => patch({ privacy })}
                  className={cn(
                    "min-h-11 rounded-md px-2 text-xs",
                    draft.privacy === privacy ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg",
                  )}
                >
                  {PRIVACY_LABEL[privacy]}
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="mt-2">
          <Switch
            checked={draft.ongoing}
            onChange={(ongoing) => patch({ ongoing })}
            label="Berjalan terus"
            hint="Tidak bisa digeser. Cocok untuk unduhan, navigasi, atau alarm."
          />
        </div>
      </Panel>

      <Panel title="Tombol aksi">
        <div className="grid gap-2">
          {draft.actions.map((action, index) => (
            <input
              key={action.id}
              value={action.label}
              aria-label={`Aksi ${index + 1}`}
              placeholder={index === 0 ? "Balas" : "Tunda"}
              maxLength={24}
              onChange={(event) => {
                const actions = draft.actions.map((item) =>
                  item.id === action.id ? { ...item, label: event.target.value } : item,
                );
                patch({ actions });
              }}
              className={controlClass}
            />
          ))}
          {draft.actions.length < 3 ? (
            <Button
              variant="ghost"
              onClick={() => patch({ actions: [...draft.actions, { id: crypto.randomUUID(), label: "" }] })}
            >
              Tambah aksi
            </Button>
          ) : null}
        </div>
      </Panel>

      <Panel title="Kapan muncul">
        <div className="grid grid-cols-3 gap-2">
          {TIMING.map((item) => (
            <button
              key={item.id}
              type="button"
              aria-pressed={timing === item.id}
              onClick={() => setTiming(item.id)}
              className={cn(
                "min-h-11 rounded-md px-2 text-sm",
                timing === item.id ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg",
              )}
            >
              {item.label}
            </button>
          ))}
        </div>
        {timing === "at" ? (
          <input
            type="datetime-local"
            value={at}
            onChange={(event) => setAt(event.target.value)}
            className={cn(controlClass, "mt-3")}
            aria-label="Waktu kemunculan"
          />
        ) : null}
        <Field label="Ulangi" hint="Pengulangan mengikuti jam pertama kali notifikasi muncul.">
          <select
            value={draft.repeat}
            onChange={(event) => patch({ repeat: event.target.value as Repeat })}
            className={cn(controlClass, "mt-3")}
          >
            {(Object.keys(REPEAT_LABEL) as Repeat[]).map((repeat) => (
              <option key={repeat} value={repeat}>
                {REPEAT_LABEL[repeat]}
              </option>
            ))}
          </select>
        </Field>
      </Panel>

      <Panel title="Pratinjau kartu">
        <NotifCard item={preview} now={0} interactive={false} />
      </Panel>

      {error ? <p className="text-sm text-accent">{error}</p> : null}
      {editId ? <p className="text-sm text-primary">Mengedit jadwal yang sudah ada.</p> : null}

      <div className="grid grid-cols-2 gap-2">
        <Button variant="ghost" className="col-span-2" onClick={() => schedule("10s", true)}>
          Uji dalam 10 detik
        </Button>
        <Button variant="secondary" onClick={showNow}>
          Tampilkan sekarang
        </Button>
        <Button type="submit">{editId ? "Simpan jadwal" : "Jadwalkan"}</Button>
      </div>
    </form>
  );
}
