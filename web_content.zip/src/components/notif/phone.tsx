import { useState } from "react";
import {
  BatteryMedium,
  Flashlight,
  Moon,
  RotateCw,
  Signal,
  VolumeX,
  Vibrate,
  Wifi,
} from "lucide-react";
import { cn } from "@/lib/cn";
import {
  DND_LABEL,
  effectiveDnd,
  formatClock,
  formatDate,
  isSilent,
  type ShadeItem,
} from "@/lib/notif/model";
import { useNotifStore } from "@/lib/notif/store";
import { NotifCard } from "@/components/notif/card";
import { AppGlyph } from "@/components/notif/glyphs";

type Face = "shade" | "lock";

function statusIcons(items: ShadeItem[]) {
  const names: string[] = [];
  for (const item of items) {
    if (isSilent(item.importance)) continue;
    if (!names.includes(item.appName)) names.push(item.appName);
  }
  return names.slice(0, 3);
}

export function Phone() {
  const [face, setFace] = useState<Face>("shade");
  const [light, setLight] = useState(false);
  const [spin, setSpin] = useState(false);
  const [saver, setSaver] = useState(false);
  const now = useNotifStore((state) => state.now);
  const shade = useNotifStore((state) => state.shade);
  const settings = useNotifStore((state) => state.settings);
  const banner = useNotifStore((state) => state.banner);
  const alarmId = useNotifStore((state) => state.alarmId);
  const flash = useNotifStore((state) => state.flash);
  const cycleDnd = useNotifStore((state) => state.cycleDnd);
  const patchSettings = useNotifStore((state) => state.patchSettings);
  const dismiss = useNotifStore((state) => state.dismiss);
  const stopOngoing = useNotifStore((state) => state.stopOngoing);
  const snooze = useNotifStore((state) => state.snooze);
  const toggleExpand = useNotifStore((state) => state.toggleExpand);
  const togglePlay = useNotifStore((state) => state.togglePlay);
  const reply = useNotifStore((state) => state.reply);
  const runAction = useNotifStore((state) => state.runAction);
  const clearShade = useNotifStore((state) => state.clearShade);

  const dnd = effectiveDnd(settings, now);
  const alerting = shade.filter((item) => !isSilent(item.importance));
  const silent = shade.filter((item) => isSilent(item.importance));
  const bannerItem = shade.find((item) => item.id === banner?.id);
  const alarm = shade.find((item) => item.id === alarmId);
  const clock = now > 0 ? formatClock(now) : "––:––";

  function renderCard(item: ShadeItem) {
    return (
      <NotifCard
        key={item.id}
        item={item}
        now={now}
        onToggle={() => toggleExpand(item.id)}
        onDismiss={() => dismiss(item.id)}
        onStop={() => stopOngoing(item.id)}
        onSnooze={(ms, label) => snooze(item.id, ms, label)}
        onAction={(label) => runAction(item.id, label)}
        onReply={(text) => reply(item.id, text)}
        onTogglePlay={() => togglePlay(item.id)}
      />
    );
  }

  return (
    <div className="mx-auto w-phone max-w-full">
      <div className="flex h-phone w-full flex-col rounded-phone border border-line bg-surface-2 p-2 shadow-lg">
        <div className="relative flex min-h-0 flex-1 flex-col overflow-hidden rounded-lg bg-bg">
          <div className="wallpaper absolute inset-0" />
          {light ? <div className="absolute inset-0 bg-fg/80" /> : null}

          <button
            type="button"
            className="relative z-10 flex h-10 w-full items-center justify-between px-4 text-xs text-fg"
            onClick={() => setFace((value) => (value === "shade" ? "lock" : "shade"))}
            aria-label={face === "shade" ? "Tutup panel, buka layar kunci" : "Buka panel notifikasi"}
          >
            <span className="font-medium tabular-nums">{clock}</span>
            <span className="absolute left-1/2 h-1.5 w-14 -translate-x-1/2 rounded-full bg-surface-3" />
            <span className="flex items-center gap-1">
              {statusIcons(shade).map((name) => (
                <span key={name} className="size-1.5 rounded-full bg-primary" title={name} />
              ))}
              {dnd !== "off" ? <Moon className="size-3.5" aria-label="Jangan ganggu" /> : null}
              {settings.mute ? <VolumeX className="size-3.5" aria-label="Senyap" /> : null}
              <Wifi className="size-3.5" aria-hidden="true" />
              <Signal className="size-3.5" aria-hidden="true" />
              <BatteryMedium className="size-4" aria-hidden="true" />
              <span className="tabular-nums">{saver ? settings.battery - 1 : settings.battery}</span>
            </span>
          </button>

          <div className="relative z-10 min-h-0 flex-1">
            {face === "lock" ? (
              <div className="flex h-full flex-col px-4 pb-4 pt-6">
                <p className="text-center font-display text-5xl font-semibold tabular-nums text-fg">{clock}</p>
                <p className="mt-1 text-center text-sm text-muted">{now > 0 ? formatDate(now) : "Selasa"}</p>
                <div className="mt-6 space-y-2 overflow-y-auto">
                  {shade.filter((item) => item.privacy !== "secret").length === 0 ? (
                    <p className="rounded-lg bg-surface/80 px-3 py-4 text-center text-sm text-muted">
                      Tidak ada yang ditampilkan di layar kunci.
                    </p>
                  ) : (
                    shade
                      .filter((item) => item.privacy !== "secret")
                      .map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => setFace("shade")}
                          className="flex w-full items-center gap-3 rounded-lg bg-surface/80 p-3 text-left"
                        >
                          <AppGlyph icon={item.icon} className="size-8" lively={item.importance === "max"} />
                          <span className="min-w-0">
                            <span className="block text-xs text-muted">{item.appName}</span>
                            {item.privacy === "private" ? (
                              <span className="block text-sm text-fg">Konten sensitif disembunyikan</span>
                            ) : (
                              <>
                                <span className="block truncate text-sm font-semibold text-fg">{item.title}</span>
                                <span className="block truncate text-xs text-muted">{item.body}</span>
                              </>
                            )}
                          </span>
                        </button>
                      ))
                  )}
                </div>
              </div>
            ) : (
              <div className="shade-scrim flex h-full flex-col">
                <div className="grid grid-cols-3 gap-2 p-3">
                  <Tile on={dnd !== "off"} icon={Moon} label={DND_LABEL[dnd]} onClick={cycleDnd} />
                  <Tile
                    on={settings.mute}
                    icon={VolumeX}
                    label={settings.mute ? "Senyap" : "Suara"}
                    onClick={() => patchSettings({ mute: !settings.mute })}
                  />
                  <Tile
                    on={settings.vibrateDevice}
                    icon={Vibrate}
                    label="Getar"
                    onClick={() => patchSettings({ vibrateDevice: !settings.vibrateDevice })}
                  />
                  <Tile on={light} icon={Flashlight} label="Senter" onClick={() => setLight((value) => !value)} />
                  <Tile
                    on={spin}
                    icon={RotateCw}
                    label={spin ? "Otomatis" : "Terkunci"}
                    onClick={() => setSpin((value) => !value)}
                  />
                  <Tile on={saver} icon={BatteryMedium} label="Hemat" onClick={() => setSaver((value) => !value)} />
                </div>
                {dnd !== "off" ? (
                  <p className="px-3 pb-2 text-center text-xs text-primary">
                    Jangan ganggu {DND_LABEL[dnd].toLowerCase()}
                    {settings.dnd === "off" && settings.dndScheduleOn ? " · dari jadwal" : ""}
                  </p>
                ) : null}
                <div className="min-h-0 flex-1 space-y-3 overflow-y-auto px-3 pb-3">
                  <div className="flex items-center justify-between">
                    <h2 className="font-display text-sm font-semibold">Notifikasi</h2>
                    <button type="button" onClick={clearShade} className="min-h-11 px-2 text-xs font-semibold text-primary">
                      Bersihkan
                    </button>
                  </div>
                  {alerting.length === 0 && silent.length === 0 ? (
                    <p className="rounded-lg border border-line bg-surface/70 px-3 py-6 text-center text-sm text-muted">
                      Panel kosong. Buat notifikasi di studio, atau uji dalam 10 detik.
                    </p>
                  ) : null}
                  {alerting.length > 0 ? <div className="space-y-2">{alerting.map(renderCard)}</div> : null}
                  {silent.length > 0 ? (
                    <div className="space-y-2">
                      <p className="text-xs font-semibold tracking-wide text-faint">Diam</p>
                      {silent.map(renderCard)}
                    </div>
                  ) : null}
                </div>
              </div>
            )}

            {bannerItem && face === "shade" && alarm?.id !== bannerItem.id ? (
              <div className="drop-in absolute inset-x-2 top-2 z-20">
                <NotifCard
                  item={{ ...bannerItem, expanded: false }}
                  now={now}
                  onToggle={() => toggleExpand(bannerItem.id)}
                  onDismiss={() => dismiss(bannerItem.id)}
                  onStop={() => stopOngoing(bannerItem.id)}
                  onAction={(label) => runAction(bannerItem.id, label)}
                />
              </div>
            ) : null}

            {alarm && face === "shade" ? (
              <div className="absolute inset-0 z-30 flex flex-col justify-end bg-bg/95 p-5">
                <p className="text-sm font-semibold text-accent">Alarm</p>
                <h2 className="mt-2 font-display text-4xl font-semibold text-fg">{alarm.title}</h2>
                <p className="mt-2 text-sm text-muted">{alarm.body}</p>
                <div className="mt-6 grid gap-2">
                  <button
                    type="button"
                    className="min-h-11 rounded-md bg-primary font-semibold text-primary-fg"
                    onClick={() => snooze(alarm.id, 5 * 60 * 1000, "5 menit")}
                  >
                    Tunda 5 menit
                  </button>
                  <button
                    type="button"
                    className="min-h-11 rounded-md bg-surface-3 font-semibold text-fg"
                    onClick={() => stopOngoing(alarm.id)}
                  >
                    Matikan
                  </button>
                </div>
              </div>
            ) : null}

            {flash ? (
              <p className="absolute inset-x-6 bottom-4 z-40 rounded-full bg-fg px-3 py-2 text-center text-xs font-semibold text-primary-fg">
                {flash.text}
              </p>
            ) : null}
          </div>

          <div className="relative z-10 flex h-5 items-center justify-center">
            <span className="h-1 w-24 rounded-full bg-fg/30" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 px-1 pt-2">
          <button
            type="button"
            aria-pressed={face === "shade"}
            onClick={() => setFace("shade")}
            className={cn(
              "min-h-11 rounded-md text-sm font-semibold",
              face === "shade" ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg",
            )}
          >
            Panel
          </button>
          <button
            type="button"
            aria-pressed={face === "lock"}
            onClick={() => setFace("lock")}
            className={cn(
              "min-h-11 rounded-md text-sm font-semibold",
              face === "lock" ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg",
            )}
          >
            Layar kunci
          </button>
        </div>
      </div>
    </div>
  );
}

function Tile({
  on,
  icon: Icon,
  label,
  onClick,
}: {
  on: boolean;
  icon: typeof Moon;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      aria-pressed={on}
      onClick={onClick}
      className={cn(
        "flex min-h-14 flex-col items-center justify-center gap-1 rounded-lg px-1 py-2 text-xs font-medium",
        on ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg",
      )}
    >
      <Icon className="size-4" aria-hidden="true" />
      <span className="max-w-full truncate">{label}</span>
    </button>
  );
}
