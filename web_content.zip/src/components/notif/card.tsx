import { useState } from "react";
import { ChevronDown, Pause, Play, SkipForward, X } from "lucide-react";
import { cn } from "@/lib/cn";
import {
  IMPORTANCE_LABEL,
  ago,
  isSilent,
  type ShadeItem,
} from "@/lib/notif/model";
import { AppGlyph } from "@/components/notif/glyphs";

export function NotifCard({
  item,
  now,
  interactive = true,
  onToggle,
  onDismiss,
  onStop,
  onSnooze,
  onAction,
  onReply,
  onTogglePlay,
}: {
  item: ShadeItem;
  now: number;
  interactive?: boolean;
  onToggle?: () => void;
  onDismiss?: () => void;
  onStop?: () => void;
  onSnooze?: (ms: number, label: string) => void;
  onAction?: (label: string) => void;
  onReply?: (text: string) => void;
  onTogglePlay?: () => void;
}) {
  const [dx, setDx] = useState(0);
  const [origin, setOrigin] = useState<number | null>(null);
  const [reply, setReply] = useState("");
  const [replyOpen, setReplyOpen] = useState(false);
  const lively = item.importance === "high" || item.importance === "max" || item.icon === "message";

  function pointerDown(event: React.PointerEvent<HTMLElement>) {
    if (!interactive || item.ongoing) return;
    setOrigin(event.clientX);
  }

  function pointerMove(event: React.PointerEvent<HTMLElement>) {
    if (origin == null) return;
    setDx(event.clientX - origin);
  }

  function pointerUp() {
    if (origin != null && Math.abs(dx) > 96) onDismiss?.();
    setOrigin(null);
    setDx(0);
  }

  function act(label: string) {
    if (label.toLowerCase() === "balas") {
      setReplyOpen(true);
      if (!item.expanded) onToggle?.();
      return;
    }
    onAction?.(label);
  }

  return (
    <article
      className="overflow-hidden rounded-lg border border-line bg-surface-2 text-fg shadow-sm"
      style={{ transform: dx ? `translateX(${dx}px)` : undefined, opacity: dx ? 1 - Math.min(Math.abs(dx) / 280, 0.45) : 1 }}
      onPointerDown={pointerDown}
      onPointerMove={pointerMove}
      onPointerUp={pointerUp}
      onPointerCancel={pointerUp}
    >
      <div className="flex items-start gap-3 p-3">
        <AppGlyph icon={item.icon} lively={lively} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <p className="truncate text-xs text-muted">{item.appName}</p>
            <span className="ml-auto shrink-0 text-xs text-faint">{ago(item.shownAt, now)}</span>
          </div>
          <h3 className="truncate font-display text-sm font-semibold">{item.title}</h3>
          {item.style !== "chat" || !item.expanded ? (
            <p className={cn("text-sm text-muted", item.expanded ? "" : "line-clamp-2")}>{item.body}</p>
          ) : null}
        </div>
        <div className="flex shrink-0 flex-col items-end gap-1">
          {interactive ? (
            <button
              type="button"
              className="grid size-8 place-items-center rounded-full text-muted"
              aria-label={item.ongoing ? "Hentikan notifikasi berjalan" : "Tutup notifikasi"}
              onClick={() => (item.ongoing ? onStop?.() : onDismiss?.())}
            >
              <X className="size-4" />
            </button>
          ) : null}
          {interactive ? (
            <button
              type="button"
              className="grid size-8 place-items-center rounded-full text-muted"
              aria-expanded={item.expanded}
              aria-label={item.expanded ? "Ciutkan" : "Luaskan"}
              onClick={onToggle}
            >
              <ChevronDown className={cn("size-4 transition-transform", item.expanded && "rotate-180")} />
            </button>
          ) : null}
        </div>
      </div>

      {item.style === "progress" ? (
        <div className="px-3 pb-3">
          <div className="h-1.5 overflow-hidden rounded-full bg-surface-3">
            <div className="h-full rounded-full bg-primary" style={{ width: `${item.progress}%` }} />
          </div>
        </div>
      ) : null}

      {item.style === "media" ? (
        <div className="flex items-center gap-2 px-3 pb-3">
          <button
            type="button"
            className="grid size-11 place-items-center rounded-full bg-primary text-primary-fg"
            aria-label={item.playing ? "Jeda" : "Putar"}
            onClick={onTogglePlay}
          >
            {item.playing ? <Pause className="size-4" /> : <Play className="size-4" />}
          </button>
          <button
            type="button"
            className="grid size-11 place-items-center rounded-full bg-surface-3 text-fg"
            aria-label="Berikutnya"
            onClick={() => onAction?.("Berikutnya")}
          >
            <SkipForward className="size-4" />
          </button>
          <span className="text-xs text-muted">{item.playing ? "Memutar" : "Dijeda"}</span>
        </div>
      ) : null}

      {(item.importance === "high" || item.importance === "max") && !item.expanded ? (
        <p className="px-3 pb-3 text-xs text-accent">{IMPORTANCE_LABEL[item.importance]}</p>
      ) : null}

      {item.expanded ? (
        <div className="space-y-3 border-t border-line px-3 py-3">
          {item.style === "bigtext" ? <p className="text-sm text-fg">{item.bigText}</p> : null}
          {item.style === "inbox" && item.inbox.length > 0 ? (
            <ul className="space-y-1 text-sm text-fg">
              {item.inbox.map((line) => (
                <li key={line} className="truncate">
                  {line}
                </li>
              ))}
            </ul>
          ) : null}
          {item.style === "chat" && item.chat.length > 0 ? (
            <div className="space-y-2">
              {item.chat.map((line) => {
                const mine = line.author === "Saya";
                return (
                  <div key={line.id} className={cn("flex", mine ? "justify-end" : "justify-start")}>
                    <div
                      className={cn(
                        "max-w-[85%] rounded-md px-3 py-2",
                        mine ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg",
                      )}
                    >
                      {!mine ? <p className="text-xs font-semibold">{line.author}</p> : null}
                      <p className="text-sm">{line.text}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : null}

          {item.actions.length > 0 ? (
            <div className="flex flex-wrap gap-2">
              {item.actions.map((action) => (
                <button
                  key={action.id}
                  type="button"
                  className="min-h-11 rounded-md bg-surface-3 px-3 text-sm font-semibold text-primary"
                  onClick={() => act(action.label)}
                >
                  {action.label}
                </button>
              ))}
            </div>
          ) : null}

          {replyOpen ? (
            <form
              className="flex gap-2"
              onSubmit={(event) => {
                event.preventDefault();
                onReply?.(reply);
                setReply("");
                setReplyOpen(false);
              }}
            >
              <input
                value={reply}
                onChange={(event) => setReply(event.target.value)}
                placeholder="Balas"
                aria-label="Balas pesan"
                className="min-h-11 min-w-0 flex-1 rounded-md border border-line bg-bg px-3 text-sm text-fg"
              />
              <button type="submit" className="min-h-11 rounded-md bg-primary px-3 text-sm font-semibold text-primary-fg">
                Kirim
              </button>
            </form>
          ) : null}

          {interactive && onSnooze ? (
            <div className="flex flex-wrap gap-2">
              {[
                [5 * 60 * 1000, "5 mnt"],
                [15 * 60 * 1000, "15 mnt"],
                [60 * 60 * 1000, "1 jam"],
              ].map(([ms, label]) => (
                <button
                  key={label}
                  type="button"
                  className="min-h-11 rounded-md border border-line px-3 text-xs text-muted"
                  onClick={() => onSnooze(Number(ms), String(label))}
                >
                  Tunda {label}
                </button>
              ))}
            </div>
          ) : null}

          <p className="text-xs text-faint">
            {item.ongoing ? "Berjalan terus · tidak bisa digeser" : "Geser untuk menutup"}
            {isSilent(item.importance) ? " · diam" : ""}
          </p>
        </div>
      ) : null}
    </article>
  );
}
