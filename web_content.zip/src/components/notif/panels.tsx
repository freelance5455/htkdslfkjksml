import { useState } from "react";
import { cn } from "@/lib/cn";
import {
  DND_LABEL,
  HISTORY_LABEL,
  IMPORTANCE_LABEL,
  IMPORTANCE_ORDER,
  PRIVACY_LABEL,
  REPEAT_LABEL,
  ago,
  countdown,
  formatWhen,
  type Channel,
  type DndMode,
  type Importance,
  type Privacy,
} from "@/lib/notif/model";
import { useNotifStore } from "@/lib/notif/store";
import { AppGlyph } from "@/components/notif/glyphs";
import { Button, Field, Panel, Switch, controlClass } from "@/components/notif/ui";

export function SchedulePanel() {
  const schedules = useNotifStore((state) => state.schedules);
  const now = useNotifStore((state) => state.now);
  const channels = useNotifStore((state) => state.channels);
  const toggleSchedule = useNotifStore((state) => state.toggleSchedule);
  const removeSchedule = useNotifStore((state) => state.removeSchedule);
  const requestEdit = useNotifStore((state) => state.requestEdit);
  const ordered = [...schedules].sort((a, b) => Number(b.enabled) - Number(a.enabled) || a.fireAt - b.fireAt);

  if (ordered.length === 0) {
    return (
      <Panel title="Jadwal">
        <p className="text-sm text-muted">
          Belum ada jadwal. Di studio, pilih waktu lalu tekan Jadwalkan. Selama pratinjau terbuka, Lonceng akan memunculkannya sendiri.
        </p>
      </Panel>
    );
  }

  return (
    <div className="space-y-3">
      {ordered.map((item) => {
        const channel = channels.find((entry) => entry.id === item.channelId);
        return (
          <article key={item.id} className="rounded-lg border border-line bg-surface p-4">
            <div className="flex items-start gap-3">
              <AppGlyph icon={item.icon} lively={item.importance === "high" || item.importance === "max"} />
              <div className="min-w-0 flex-1">
                <p className="text-xs text-muted">
                  {item.appName}
                  {channel ? ` · ${channel.name}` : ""}
                </p>
                <h3 className="truncate font-display text-base font-semibold">{item.title}</h3>
                <p className="truncate text-sm text-muted">{item.body}</p>
                <p className="mt-1 text-sm text-primary">
                  {item.enabled
                    ? now > 0
                      ? `${countdown(item.fireAt, now)} · ${formatWhen(item.fireAt)}`
                      : "Menghitung…"
                    : "Dimatikan"}
                  {" · "}
                  {REPEAT_LABEL[item.repeat]}
                </p>
              </div>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <Button variant="secondary" onClick={() => requestEdit(item.id)}>
                Ubah
              </Button>
              <Button variant="ghost" onClick={() => toggleSchedule(item.id)}>
                {item.enabled ? "Matikan" : "Aktifkan"}
              </Button>
              <Button variant="ghost" onClick={() => removeSchedule(item.id)}>
                Hapus
              </Button>
            </div>
          </article>
        );
      })}
    </div>
  );
}

export function ChannelPanel() {
  const channels = useNotifStore((state) => state.channels);
  const addChannel = useNotifStore((state) => state.addChannel);
  const updateChannel = useNotifStore((state) => state.updateChannel);
  const removeChannel = useNotifStore((state) => state.removeChannel);
  const [name, setName] = useState("");
  const [importance, setImportance] = useState<Importance>("default");
  const [bypass, setBypass] = useState(false);

  return (
    <div className="space-y-4">
      <Panel title="Saluran baru">
        <div className="grid gap-3">
          <Field label="Nama" hint="Seperti di pengaturan aplikasi Android: tiap saluran punya suara dan kepentingan sendiri.">
            <input value={name} onChange={(event) => setName(event.target.value)} className={controlClass} maxLength={32} />
          </Field>
          <ImportancePicker value={importance} onChange={setImportance} />
          <Switch checked={bypass} onChange={setBypass} label="Tembus jangan ganggu" />
          <Button
            onClick={() => {
              if (!name.trim()) return;
              addChannel({
                name,
                description: "Saluran buatan.",
                importance,
                sound: importance !== "min" && importance !== "low",
                vibrate: importance !== "min" && importance !== "low",
                showBadge: importance !== "min",
                privacy: importance === "min" ? "secret" : "private",
                bypassDnd: bypass,
              });
              setName("");
              setBypass(false);
            }}
          >
            Tambah saluran
          </Button>
        </div>
      </Panel>
      {channels.map((channel) => (
        <ChannelCard
          key={channel.id}
          channel={channel}
          onChange={(patch) => updateChannel(channel.id, patch)}
          onRemove={channel.system ? undefined : () => removeChannel(channel.id)}
        />
      ))}
    </div>
  );
}

function ChannelCard({
  channel,
  onChange,
  onRemove,
}: {
  channel: Channel;
  onChange: (patch: Partial<Channel>) => void;
  onRemove?: () => void;
}) {
  return (
    <article className="rounded-lg border border-line bg-surface p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="font-display text-base font-semibold">{channel.name}</h3>
          <p className="text-sm text-muted">{channel.description}</p>
        </div>
        {onRemove ? (
          <button type="button" onClick={onRemove} className="min-h-11 text-sm text-accent">
            Hapus
          </button>
        ) : (
          <span className="text-xs text-faint">Bawaan</span>
        )}
      </div>
      <div className="mt-3">
        <ImportancePicker value={channel.importance} onChange={(importance) => onChange({ importance })} />
      </div>
      <div className="mt-2">
        <Switch checked={channel.sound} onChange={(sound) => onChange({ sound })} label="Suara" />
        <Switch checked={channel.vibrate} onChange={(vibrate) => onChange({ vibrate })} label="Getar" />
        <Switch checked={channel.showBadge} onChange={(showBadge) => onChange({ showBadge })} label="Lencana ikon" />
        <Switch checked={channel.bypassDnd} onChange={(bypassDnd) => onChange({ bypassDnd })} label="Tembus jangan ganggu" />
      </div>
      <div className="mt-3 grid grid-cols-3 gap-2">
        {(Object.keys(PRIVACY_LABEL) as Privacy[]).map((privacy) => (
          <button
            key={privacy}
            type="button"
            aria-pressed={channel.privacy === privacy}
            onClick={() => onChange({ privacy })}
            className={cn(
              "min-h-11 rounded-md px-1 text-xs",
              channel.privacy === privacy ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg",
            )}
          >
            {PRIVACY_LABEL[privacy]}
          </button>
        ))}
      </div>
    </article>
  );
}

function ImportancePicker({ value, onChange }: { value: Importance; onChange: (value: Importance) => void }) {
  return (
    <div className="grid grid-cols-5 gap-1">
      {IMPORTANCE_ORDER.map((level) => (
        <button
          key={level}
          type="button"
          aria-pressed={value === level}
          onClick={() => onChange(level)}
          className={cn(
            "min-h-11 rounded-md px-1 text-xs font-semibold",
            value === level ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg",
          )}
        >
          {IMPORTANCE_LABEL[level]}
        </button>
      ))}
    </div>
  );
}

export function SettingsPanel() {
  const settings = useNotifStore((state) => state.settings);
  const patchSettings = useNotifStore((state) => state.patchSettings);
  const history = useNotifStore((state) => state.history);
  const now = useNotifStore((state) => state.now);
  const resetAll = useNotifStore((state) => state.resetAll);
  const [armed, setArmed] = useState(false);
  const [perm, setPerm] = useState("");

  async function enableBrowser() {
    try {
      if (typeof Notification === "undefined") {
        setPerm("Peramban ini tidak mendukung notifikasi perangkat.");
        return;
      }
      const result = await Notification.requestPermission();
      if (result === "granted") {
        patchSettings({ browserNotify: true });
        setPerm("Diizinkan. Notifikasi perangkat muncul selagi halaman ini terbuka.");
        return;
      }
      patchSettings({ browserNotify: false });
      setPerm("Izin ditolak. Panel di dalam telepon tetap berjalan.");
    } catch {
      setPerm("Pratinjau tidak mengizinkan notifikasi perangkat. Panel telepon tetap berjalan.");
    }
  }

  return (
    <div className="space-y-4">
      <Panel title="Jangan ganggu">
        <div className="grid grid-cols-2 gap-2">
          {(Object.keys(DND_LABEL) as DndMode[]).map((mode) => (
            <button
              key={mode}
              type="button"
              aria-pressed={settings.dnd === mode}
              onClick={() => patchSettings({ dnd: mode })}
              className={cn(
                "min-h-11 rounded-md px-2 text-sm",
                settings.dnd === mode ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg",
              )}
            >
              {DND_LABEL[mode]}
            </button>
          ))}
        </div>
        <p className="mt-3 text-xs text-muted">
          Prioritas melewatkan yang tinggi dan mendesak. Alarm hanya mendesak. Total menutup semuanya, kecuali saluran alarm yang menembus.
        </p>
        <div className="mt-3">
          <Switch
            checked={settings.dndScheduleOn}
            onChange={(dndScheduleOn) => patchSettings({ dndScheduleOn })}
            label="Jadwal otomatis"
            hint="Di luar mode manual, jendela ini memakai prioritas."
          />
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <Field label="Mulai">
            <input
              type="time"
              value={settings.dndStart}
              onChange={(event) => patchSettings({ dndStart: event.target.value })}
              className={controlClass}
            />
          </Field>
          <Field label="Selesai">
            <input
              type="time"
              value={settings.dndEnd}
              onChange={(event) => patchSettings({ dndEnd: event.target.value })}
              className={controlClass}
            />
          </Field>
        </div>
      </Panel>

      <Panel title="Perangkat">
        <Switch
          checked={settings.mute}
          onChange={(mute) => patchSettings({ mute })}
          label="Mode senyap"
          hint="Mematikan nada di panel. Getar bisa tetap hidup."
        />
        <Switch
          checked={settings.vibrateDevice}
          onChange={(vibrateDevice) => patchSettings({ vibrateDevice })}
          label="Getar perangkat"
        />
        <Switch
          checked={settings.browserNotify}
          onChange={(browserNotify) => {
            if (browserNotify) void enableBrowser();
            else patchSettings({ browserNotify: false });
          }}
          label="Notifikasi perangkat"
          hint="Muncul di sistem saat izin diberikan dan tab ini masih terbuka. Panel Android di samping selalu aktif di dalam aplikasi."
        />
        {perm ? <p className="mt-2 text-xs text-muted">{perm}</p> : null}
      </Panel>

      <Panel title="Riwayat">
        {history.length === 0 ? (
          <p className="text-sm text-muted">Belum ada. Tampilkan atau jadwalkan notifikasi untuk mengisi riwayat.</p>
        ) : (
          <ul className="space-y-2">
            {history.slice(0, 20).map((entry) => (
              <li key={entry.id} className="flex items-start justify-between gap-3 text-sm">
                <span className="min-w-0">
                  <span className="block truncate font-medium">{entry.title}</span>
                  <span className="block truncate text-xs text-muted">
                    {HISTORY_LABEL[entry.result]}
                    {entry.note ? ` · ${entry.note}` : ""} · {entry.appName}
                  </span>
                </span>
                <span className="shrink-0 text-xs text-faint">{ago(entry.at, now)}</span>
              </li>
            ))}
          </ul>
        )}
      </Panel>

      <Panel title="Setel ulang">
        <p className="mb-3 text-sm text-muted">Mengembalikan saluran bawaan, contoh panel, dan menghapus jadwal di perangkat ini.</p>
        <Button
          variant={armed ? "danger" : "ghost"}
          onClick={() => {
            if (!armed) {
              setArmed(true);
              return;
            }
            resetAll();
            setArmed(false);
          }}
        >
          {armed ? "Yakin, setel ulang" : "Setel ulang"}
        </Button>
      </Panel>
    </div>
  );
}
