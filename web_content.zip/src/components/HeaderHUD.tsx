import React from 'react';
import { Pause, Volume2, VolumeX, Trophy, Flame, Clock, ShieldAlert } from 'lucide-react';
import { GameMode } from '../types/game';

interface HeaderHUDProps {
  mode: GameMode;
  score: number;
  highScore: number;
  comboStreak: number;
  timeLeft?: number; // for RUSH mode
  bombsCount?: number; // for BOMB mode
  isMuted: boolean;
  onToggleMute: () => void;
  onPause: () => void;
}

export const HeaderHUD: React.FC<HeaderHUDProps> = ({
  mode,
  score,
  highScore,
  comboStreak,
  timeLeft,
  bombsCount,
  isMuted,
  onToggleMute,
  onPause,
}) => {
  return (
    <header className="w-full max-w-[400px] mx-auto px-2 pt-0.5 pb-0.5 select-none shrink-0">
      {/* Top action row */}
      <div className="flex items-center justify-between gap-1.5 mb-0.5">
        <div className="flex items-center gap-1">
          <button
            onClick={onPause}
            aria-label="Pause Game"
            className="w-8 h-8 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/60 flex items-center justify-center text-slate-300 hover:text-white transition-colors active:scale-95 shadow-sm"
          >
            <Pause className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onToggleMute}
            aria-label={isMuted ? 'Unmute Audio' : 'Mute Audio'}
            className="w-8 h-8 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/60 flex items-center justify-center text-slate-300 hover:text-white transition-colors active:scale-95 shadow-sm"
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5 text-rose-400" /> : <Volume2 className="w-3.5 h-3.5 text-cyan-400" />}
          </button>
        </div>

        {/* Center Mode or Timer Banner */}
        <div className="flex items-center gap-1.5">
          {mode === 'RUSH' && timeLeft !== undefined ? (
            <div
              className={`flex items-center gap-1 px-2.5 py-0.5 rounded-lg border font-bold font-mono-numbers text-xs shadow-sm transition-colors ${
                timeLeft <= 10
                  ? 'bg-rose-950/90 text-rose-300 border-rose-500 animate-pulse'
                  : timeLeft <= 25
                  ? 'bg-amber-950/80 text-amber-300 border-amber-500'
                  : 'bg-cyan-950/80 text-cyan-300 border-cyan-500/40'
              }`}
            >
              <Clock className={`w-3.5 h-3.5 ${timeLeft <= 10 ? 'animate-spin' : ''}`} />
              <span>{Math.floor(timeLeft / 60)}:{String(timeLeft % 60).padStart(2, '0')}</span>
            </div>
          ) : mode === 'BOMB' ? (
            <div className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-rose-950/70 border border-rose-500/40 text-rose-300 text-[11px] font-bold">
              <ShieldAlert className="w-3 h-3 text-rose-400" />
              <span>Bombs: {bombsCount ?? 0}</span>
            </div>
          ) : comboStreak > 1 ? (
            <div className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-rose-500/20 border border-orange-500/40 text-amber-300 animate-pulse shadow-sm">
              <Flame className="w-3.5 h-3.5 text-orange-400 animate-bounce" />
              <span className="text-[11px] font-black tracking-wider uppercase font-display">
                Combo x{comboStreak}
              </span>
            </div>
          ) : (
            <div className="text-[11px] font-semibold tracking-wider text-slate-400 uppercase font-display">
              Classic Blast
            </div>
          )}
        </div>

        {/* Best Score Trophy */}
        <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-900/80 border border-amber-500/30 text-amber-400 shadow-sm">
          <Trophy className="w-3 h-3 text-amber-400 shrink-0" />
          <span className="text-[11px] font-bold font-mono-numbers">{highScore}</span>
        </div>
      </div>

      {/* Main Score Showcase */}
      <div className="flex flex-col items-center justify-center py-0">
        <div className="text-2xl sm:text-4xl font-black font-display tracking-tight text-transparent bg-clip-text bg-gradient-to-b from-white via-slate-100 to-slate-400 drop-shadow-[0_2px_8px_rgba(255,255,255,0.15)] font-mono-numbers leading-tight">
          {score}
        </div>
      </div>
    </header>
  );
};
