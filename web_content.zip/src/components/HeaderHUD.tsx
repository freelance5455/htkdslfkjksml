import React from 'react';
import { ShieldCheck, HelpCircle, Volume2, VolumeX, Sparkles } from 'lucide-react';
import { ApiStatus, AssistantState } from '../types/jarvis';

interface HeaderHUDProps {
  state: AssistantState;
  apiStatus: ApiStatus | null;
  voiceEnabled: boolean;
  onToggleVoice: () => void;
  onOpenGuide: () => void;
  currentLanguage: string;
}

export const HeaderHUD: React.FC<HeaderHUDProps> = ({
  state,
  apiStatus,
  voiceEnabled,
  onToggleVoice,
  onOpenGuide,
  currentLanguage,
}) => {
  return (
    <header className="w-full max-w-xl mx-auto px-4 pt-3 pb-2 z-20 select-none">
      <div className="flex items-center justify-between py-2 px-3 rounded-2xl bg-slate-950/70 border border-cyan-500/25 backdrop-blur-md">
        {/* Left: Brand Identity */}
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <div className="w-8 h-8 rounded-full border border-cyan-400 flex items-center justify-center bg-cyan-950/80 shadow-[0_0_12px_rgba(0,240,255,0.4)]">
              <Sparkles className="w-4 h-4 text-cyan-300 animate-pulse" />
            </div>
            <div className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 border border-slate-950 animate-ping" />
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="font-tech text-sm sm:text-base font-extrabold text-cyan-300 tracking-wider">
                J.A.R.V.I.S.
              </h1>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded border border-cyan-500/40 text-cyan-400 bg-cyan-950/40">
                v4.2
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-mono tracking-widest uppercase">
              AI PERSONAL ASSISTANT
            </p>
          </div>
        </div>

        {/* Center/Right: Current System State Tag */}
        <div className="flex items-center gap-2">
          {/* Dynamic State Badge */}
          <div
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-[10px] font-mono border font-bold uppercase transition-all ${
              state === 'listening'
                ? 'border-cyan-400 bg-cyan-950/80 text-cyan-200 shadow-[0_0_10px_rgba(0,240,255,0.4)]'
                : state === 'speaking'
                ? 'border-blue-400 bg-blue-950/80 text-blue-200'
                : state === 'thinking'
                ? 'border-sky-400 bg-sky-950/80 text-sky-200 animate-pulse'
                : state === 'sleeping'
                ? 'border-slate-800 bg-slate-900/60 text-slate-400'
                : 'border-amber-500/40 bg-amber-950/50 text-amber-300'
            }`}
          >
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                state === 'listening'
                  ? 'bg-cyan-400 animate-ping'
                  : state === 'speaking'
                  ? 'bg-blue-400 animate-pulse'
                  : state === 'thinking'
                  ? 'bg-sky-400 animate-spin'
                  : state === 'sleeping'
                  ? 'bg-slate-500'
                  : 'bg-amber-400'
              }`}
            />
            <span>{state}</span>
          </div>

          {/* Voice Mute / Unmute Toggle */}
          <button
            onClick={onToggleVoice}
            title={voiceEnabled ? 'Mute vocal responses' : 'Enable vocal responses'}
            className={`p-2 rounded-xl border transition-colors cursor-pointer ${
              voiceEnabled
                ? 'border-cyan-500/40 text-cyan-300 bg-cyan-950/40'
                : 'border-slate-800 text-slate-500 bg-slate-900/40'
            }`}
          >
            {voiceEnabled ? (
              <Volume2 className="w-4 h-4" />
            ) : (
              <VolumeX className="w-4 h-4" />
            )}
          </button>

          {/* Quick Help Guide Button */}
          <button
            onClick={onOpenGuide}
            title="Setup instructions & Help"
            className="p-2 rounded-xl border border-cyan-500/30 text-slate-300 hover:text-cyan-300 hover:bg-cyan-950/40 transition-colors cursor-pointer"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
