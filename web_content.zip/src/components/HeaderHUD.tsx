import React, { useEffect, useRef, useState } from 'react';
import {
  ActiveCeremonyBuff,
  BgmTheme,
  ResourceRates,
  Season,
  SectAlignment,
  SectResources,
  SectStability
} from '../types/cultivation';
import { formatLargeNumber } from '../data/realms';
import { formatCalendarDate, formatClockMinutes } from '../utils/dateUtils';
import { SpiritStoneIcon, QiOrbIcon, PillFlaskIcon, MeritScrollIcon, YinYangIcon } from './icons/DaoIcons';
import { BGM_THEME_LABELS } from '../services/audioEngine';
import { Music, Settings, Award, Sparkles, Clock } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';

interface FloatingGain {
  id: number;
  amount: number;
}

function useAnimatedResource(targetValue: number) {
  const [displayValue, setDisplayValue] = useState(targetValue);
  const [gains, setGains] = useState<FloatingGain[]>([]);
  const prevTargetRef = useRef(targetValue);
  const displayRef = useRef(targetValue);
  const gainIdRef = useRef(0);

  useEffect(() => {
    const prev = prevTargetRef.current;
    const delta = targetValue - prev;
    prevTargetRef.current = targetValue;

    if (delta > 0 && delta < 50000000) {
      const id = ++gainIdRef.current;
      setGains(current => [...current.slice(-2), { id, amount: delta }]);
      const timer = setTimeout(() => {
        setGains(current => current.filter(g => g.id !== id));
      }, 1150);

      let rafId = 0;
      const startVal = displayRef.current;
      const startTime = performance.now();
      const duration = 420;

      const step = (now: number) => {
        const progress = Math.min(1, (now - startTime) / duration);
        const eased = 1 - Math.pow(1 - progress, 3);
        const nextVal = Math.round(startVal + (targetValue - startVal) * eased);
        displayRef.current = nextVal;
        setDisplayValue(nextVal);
        if (progress < 1) {
          rafId = requestAnimationFrame(step);
        }
      };
      rafId = requestAnimationFrame(step);

      return () => {
        clearTimeout(timer);
        cancelAnimationFrame(rafId);
      };
    } else {
      displayRef.current = targetValue;
      setDisplayValue(targetValue);
    }
  }, [targetValue]);

  return { displayValue, gains };
}

interface ResourceCardProps {
  label: string;
  value: number;
  rate: number;
  icon: React.ReactNode;
  barColor: string;
  rateColor: string;
  barWidth: string;
  gainColor: string;
}

const AnimatedResourceCard: React.FC<ResourceCardProps> = ({
  label,
  value,
  rate,
  icon,
  barColor,
  rateColor,
  barWidth,
  gainColor
}) => {
  const { displayValue, gains } = useAnimatedResource(value);

  return (
    <div className="bg-[#f9f5ea] text-[#142c23] p-2 sm:p-2.5 rounded-xl border border-[#e8dbc0] shadow-xs relative overflow-visible">
      {/* Subtle Floating Animated +Gain Popups */}
      <div className="pointer-events-none absolute right-2 top-0.5 z-20 flex flex-col items-end">
        <AnimatePresence>
          {gains.map(g => (
            <motion.span
              key={g.id}
              initial={{ opacity: 0, y: 6, scale: 0.9 }}
              animate={{ opacity: [0, 0.95, 0.9, 0], y: -20, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1.05, ease: 'easeOut' }}
              className={`font-mono tabular-nums font-bold text-[10px] sm:text-[11px] drop-shadow-xs whitespace-nowrap ${gainColor}`}
            >
              +{formatLargeNumber(g.amount)}
            </motion.span>
          ))}
        </AnimatePresence>
      </div>

      <div className="flex justify-between items-center text-[10px] sm:text-[11px] font-bold text-[#355246]">
        <div className="flex items-center gap-1.5 min-w-0">
          {icon}
          <span className="truncate">{label}</span>
        </div>
        <span className={`${rateColor} font-mono tabular-nums font-semibold text-[10px] shrink-0`}>
          +{rate}/s
        </span>
      </div>
      <div className="text-sm sm:text-base font-bold font-mono tabular-nums tracking-tight text-[#0f2b20] mt-0.5">
        {formatLargeNumber(displayValue)}
      </div>
      <div className="w-full bg-[#d8cfb9] h-1 rounded-full mt-1 overflow-hidden">
        <div className={`${barColor} h-full rounded-full transition-all duration-300`} style={{ width: barWidth }} />
      </div>
    </div>
  );
};

interface HeaderHUDProps {
  worldName: string;
  year: number;
  season: Season;
  currentDateIso: string;
  clockMinutes: number;
  ceremonyBuff: ActiveCeremonyBuff;
  sectName: string;
  prestige: number;
  stability: SectStability;
  alignment: SectAlignment;
  resources: SectResources;
  rates: ResourceRates;
  isFirstPanel: boolean;
  onOpenSettings: () => void;
  onOpenAwards: () => void;
  isBgmActive: boolean;
  bgmTheme?: BgmTheme;
  onToggleBgm: () => void;
  onCycleBgmTheme?: () => void;
}

export const HeaderHUD: React.FC<HeaderHUDProps> = ({
  worldName,
  year,
  season,
  currentDateIso,
  clockMinutes,
  ceremonyBuff,
  sectName,
  prestige,
  stability,
  alignment,
  resources,
  rates,
  isFirstPanel,
  onOpenSettings,
  onOpenAwards,
  isBgmActive,
  bgmTheme = 'epic',
  onToggleBgm,
  onCycleBgmTheme
}) => {
  const formattedDate = formatCalendarDate(currentDateIso);
  const formattedClock = formatClockMinutes(clockMinutes);

  return (
    <header className="sticky top-0 z-40 bg-[#072018]/95 backdrop-blur-md border-b border-[#e2b054]/30 shadow-xl transition-all duration-300">
      <div className="max-w-2xl mx-auto p-2 sm:p-2.5 space-y-2">
        {/* World Name, Calendar Date (left) & Live Clock + Utilities (right) */}
        <div className="flex justify-between items-center gap-2">
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 sm:gap-2">
              <YinYangIcon className="text-[#e2b054] w-4 h-4 sm:w-5 sm:h-5 animate-spin-slow shrink-0" />
              <h1 className="text-sm sm:text-base font-bold font-dao text-[#fce18b] tracking-wide truncate">
                {worldName}
              </h1>
            </div>
            <div className="text-[10px] sm:text-[11px] text-[#9fc2b2] font-medium pl-5 sm:pl-7 truncate">
              <span className="font-mono tabular-nums text-[#d1e6dc]">{formattedDate}</span>
              <span aria-hidden="true"> · </span>
              <span>Year <span className="font-mono tabular-nums">{year}</span></span>
              <span aria-hidden="true"> · </span>
              <span>{season}</span>
            </div>
          </div>

          <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
            {/* Compact Ticking Sect Clock */}
            <div
              title="Real-time Sect Chronometer"
              className="hidden xs:flex sm:flex items-center gap-1 px-2 py-1 rounded-lg bg-[#0b2820] border border-[#e2b054]/25 text-[#fce18b] font-mono tabular-nums text-[10px] sm:text-[11px] font-semibold whitespace-nowrap"
            >
              <Clock className="w-3 h-3 text-[#e2b054] shrink-0" />
              <span>{formattedClock}</span>
            </div>

            <button
              onClick={onToggleBgm}
              title={isBgmActive ? `BGM Active (${BGM_THEME_LABELS[bgmTheme]?.label || bgmTheme})` : 'Music Off (Tap to Play)'}
              className={`min-h-[36px] px-2 rounded-lg border transition-all text-[11px] font-bold flex items-center gap-1 whitespace-nowrap ${
                isBgmActive
                  ? 'bg-[#184838] border-[#e2b054] text-[#fce18b] shadow-xs'
                  : 'bg-[#0b2820] border-[#1d5543] text-[#7ea091]'
              }`}
            >
              <Music className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">
                {isBgmActive ? (BGM_THEME_LABELS[bgmTheme]?.short || 'BGM') : 'BGM'}
              </span>
            </button>

            {isBgmActive && onCycleBgmTheme && (
              <button
                onClick={onCycleBgmTheme}
                title="Switch BGM Track (5 Themes)"
                className="min-h-[36px] px-2 rounded-lg bg-[#0f3427] hover:bg-[#184838] border border-[#e2b054]/40 text-[#fce18b] text-[10px] font-bold flex items-center gap-1 whitespace-nowrap"
              >
                <Sparkles className="w-3 h-3 text-amber-300" />
                <span className="sm:hidden">{BGM_THEME_LABELS[bgmTheme]?.short || 'Track'}</span>
              </button>
            )}

            <button
              onClick={onOpenAwards}
              title="Sect Honours & Milestones"
              className="min-h-[36px] px-2 sm:px-2.5 rounded-lg bg-gradient-to-r from-[#b4802c] to-[#d49e38] text-[#072018] border border-[#fce18b]/60 text-[11px] font-bold flex items-center gap-1 shadow-sm active:scale-95 transition-transform whitespace-nowrap"
            >
              <Award className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Awards</span>
            </button>

            <button
              onClick={onOpenSettings}
              title="Sect Settings & Archives"
              className="min-h-[36px] min-w-[36px] p-1.5 rounded-lg bg-[#123d30] hover:bg-[#1a4f3f] border border-[#e2b054]/40 text-[#fce18b] text-[11px] font-bold flex items-center justify-center transition-all"
            >
              <Settings className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* 4 Animated Resource Cards (ONLY rendered on the first panel 'sect') */}
        {isFirstPanel && (
          <div className="grid grid-cols-2 gap-1.5 sm:gap-2 pt-0.5">
            <AnimatedResourceCard
              label="Spirit Stones"
              value={resources.spiritStones}
              rate={rates.spiritStonesRate}
              icon={<SpiritStoneIcon className="w-4 h-4 shrink-0" />}
              barColor="bg-[#0284c7]"
              rateColor="text-[#0369a1]"
              gainColor="text-sky-600"
              barWidth="85%"
            />
            <AnimatedResourceCard
              label="Qi"
              value={resources.qi}
              rate={rates.qiRate}
              icon={<QiOrbIcon className="w-4 h-4 shrink-0" />}
              barColor="bg-[#16a34a]"
              rateColor="text-[#15803d]"
              gainColor="text-emerald-600"
              barWidth="70%"
            />
            <AnimatedResourceCard
              label="Pills"
              value={resources.pills}
              rate={rates.pillsRate}
              icon={<PillFlaskIcon className="w-4 h-4 shrink-0" />}
              barColor="bg-[#0d9488]"
              rateColor="text-[#0f766e]"
              gainColor="text-teal-700"
              barWidth="55%"
            />
            <AnimatedResourceCard
              label="Merit (Rep)"
              value={resources.merit}
              rate={rates.meritRate}
              icon={<MeritScrollIcon className="w-4 h-4 shrink-0" />}
              barColor="bg-[#ca8a04]"
              rateColor="text-[#854d0e]"
              gainColor="text-amber-700"
              barWidth="40%"
            />
          </div>
        )}

        {/* Sect Prestige & Alignment Status Bar */}
        <div className="bg-[#0f3427] border border-[#e2b054]/30 rounded-xl px-2.5 py-1 flex justify-between items-center text-[10px] sm:text-[11px] text-[#d1e6dc] shadow-inner font-medium gap-2">
          <div className="flex items-center gap-1.5 text-[#fce18b] font-semibold truncate min-w-0">
            <YinYangIcon className="w-3 h-3 shrink-0" />
            <span className="truncate">{sectName}</span>
            {(ceremonyBuff.strongestMonthsLeft > 0 || ceremonyBuff.contribMonthsLeft > 0) && (
              <span className="text-[10px] text-amber-300 font-mono tabular-nums truncate">
                {ceremonyBuff.strongestMonthsLeft > 0 ? `· 3x Glory (${ceremonyBuff.strongestMonthsLeft}m)` : ''}
                {ceremonyBuff.contribMonthsLeft > 0 ? `· 2x Merit (${ceremonyBuff.contribMonthsLeft}m)` : ''}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <span className="sm:hidden font-mono tabular-nums text-[#fce18b] text-[10px]">
              {formattedClock}
            </span>
            <span className="text-[#fce18b] font-bold font-mono tabular-nums flex items-center gap-0.5">
              <span>⭐</span>
              <span>{formatLargeNumber(prestige)}</span>
            </span>
            <span className="flex items-center gap-0.5 text-[#86efac]">
              <span>☯</span>
              <span>{stability}</span>
            </span>
            <span className="hidden xs:flex sm:flex items-center gap-0.5 text-[#bae6fd] truncate max-w-[100px] sm:max-w-none">
              <span>⚖️</span>
              <span className="truncate">{alignment}</span>
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};
