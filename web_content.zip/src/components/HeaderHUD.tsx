import React from 'react';
import { Volume2, VolumeX, Smartphone, SmartphoneNfc, Pause, Trophy, Flame, Coins, Music } from 'lucide-react';

interface HeaderHUDProps {
  score: number;
  highScore: number;
  coins: number;
  combo: number;
  comboMultiplier: number;
  isFever: boolean;
  isSoundMuted: boolean;
  isMusicMuted: boolean;
  isHapticsEnabled: boolean;
  onToggleSound: () => void;
  onToggleMusic: () => void;
  onToggleHaptics: () => void;
  onPause: () => void;
}

export const HeaderHUD: React.FC<HeaderHUDProps> = ({
  score,
  highScore,
  coins,
  combo,
  comboMultiplier,
  isFever,
  isSoundMuted,
  isMusicMuted,
  isHapticsEnabled,
  onToggleSound,
  onToggleMusic,
  onToggleHaptics,
  onPause,
}) => {
  return (
    <header className="w-full max-w-md px-4 pt-safe flex flex-col gap-1.5 z-10 select-none">
      {/* Top Bar Action Row */}
      <div className="flex items-center justify-between">
        {/* Best Score & Coins */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs text-amber-300 font-semibold tracking-wide">
            <Trophy className="h-4 w-4 fill-amber-400/30 text-amber-400" />
            <span className="text-slate-400">BEST</span>
            <span className="font-mono tabular-nums text-amber-300 text-sm">{highScore}</span>
          </div>

          <div className="flex items-center gap-1 rounded-full bg-slate-900/90 px-2.5 py-0.5 border border-amber-500/30 text-xs font-bold text-amber-400">
            <Coins className="h-3.5 w-3.5 text-amber-400 fill-amber-400/20" />
            <span className="font-mono tabular-nums">{coins}</span>
          </div>
        </div>

        {/* Audio, Haptic & Pause Controls */}
        <div className="flex items-center gap-1">
          <button
            onClick={onToggleMusic}
            className={`flex h-8 w-8 items-center justify-center rounded-full transition-all active:scale-95 ${
              isMusicMuted ? 'bg-slate-800/80 text-slate-500' : 'bg-indigo-900/60 text-indigo-400 border border-indigo-500/40'
            }`}
            aria-label={isMusicMuted ? 'Enable Music' : 'Disable Music'}
          >
            <Music className="h-3.5 w-3.5" />
          </button>

          <button
            onClick={onToggleSound}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800/80 text-slate-300 hover:text-white active:scale-95 transition-all"
            aria-label={isSoundMuted ? 'Unmute Sound' : 'Mute Sound'}
          >
            {isSoundMuted ? <VolumeX className="h-3.5 w-3.5" /> : <Volume2 className="h-3.5 w-3.5" />}
          </button>

          <button
            onClick={onToggleHaptics}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800/80 text-slate-300 hover:text-white active:scale-95 transition-all"
            aria-label={isHapticsEnabled ? 'Disable Haptics' : 'Enable Haptics'}
          >
            {isHapticsEnabled ? (
              <SmartphoneNfc className="h-3.5 w-3.5 text-emerald-400" />
            ) : (
              <Smartphone className="h-3.5 w-3.5 text-slate-500" />
            )}
          </button>

          <button
            onClick={onPause}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800/80 text-slate-300 hover:text-white active:scale-95 transition-all ml-1"
            aria-label="Pause Game"
          >
            <Pause className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Main Score & Combo Status Banner */}
      <div className="flex items-center justify-between px-1">
        {/* Large Score */}
        <div className="flex flex-col">
          <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">
            SCORE
          </span>
          <span className="font-mono text-4xl sm:text-5xl font-black tabular-nums tracking-tight text-white leading-none">
            {score}
          </span>
        </div>

        {/* Combo Multiplier Meter / Fever Mode Tag */}
        <div className="flex flex-col items-end">
          <div className="flex items-center gap-1.5">
            {isFever ? (
              <div className="flex items-center gap-1 text-orange-400 text-xl sm:text-2xl font-black font-mono animate-pulse">
                <Flame className="h-5 w-5 fill-orange-400" />
                <span>FEVER 2x!</span>
              </div>
            ) : (
              <>
                {comboMultiplier > 1 && (
                  <Flame className="h-5 w-5 text-amber-400 fill-amber-400 animate-bounce" />
                )}
                <span
                  className={`text-xl sm:text-2xl font-black font-mono tracking-tight transition-all duration-150 ${
                    comboMultiplier >= 4
                      ? 'text-rose-400 drop-shadow-[0_0_10px_rgba(244,63,94,0.7)]'
                      : comboMultiplier >= 3
                      ? 'text-amber-400 drop-shadow-[0_0_10px_rgba(251,191,36,0.6)]'
                      : comboMultiplier >= 2
                      ? 'text-emerald-400'
                      : 'text-slate-500'
                  }`}
                >
                  {comboMultiplier}x COMBO
                </span>
              </>
            )}
          </div>

          {/* Micro Streak Counter */}
          <span className="text-[11px] font-mono tabular-nums text-slate-400">
            {combo} in a row
          </span>
        </div>
      </div>

      {/* Dynamic Combo Progression Bar */}
      <div className="h-1.5 w-full rounded-full bg-slate-800/80 overflow-hidden">
        <div
          className={`h-full transition-all duration-200 rounded-full ${
            isFever
              ? 'bg-gradient-to-r from-amber-400 via-orange-500 to-rose-500 animate-pulse'
              : comboMultiplier >= 4
              ? 'bg-gradient-to-r from-amber-400 via-rose-500 to-pink-500'
              : comboMultiplier >= 3
              ? 'bg-gradient-to-r from-emerald-400 to-amber-400'
              : comboMultiplier >= 2
              ? 'bg-gradient-to-r from-blue-400 to-emerald-400'
              : 'bg-blue-500'
          }`}
          style={{
            width: isFever
              ? '100%'
              : `${Math.min(100, ((combo % 10) / 10) * 100 || (combo > 0 ? 100 : 0))}%`,
          }}
        />
      </div>
    </header>
  );
};
