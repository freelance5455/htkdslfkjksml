import React, { useState } from 'react';
import { LoanCategory, InstallmentType } from '../types/budget';
import { 
  X, 
  CheckCircle2, 
  ArrowRight,
  Calculator
} from 'lucide-react';

interface CreateLoanModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateLoan: (loan: {
    name: string;
    totalAmount: number;
    durationMonths: number;
    monthlyPayment: number;
    category: LoanCategory;
    dueDate: string;
    installmentType: InstallmentType;
    additionalMonthlyCharge?: number;
    interestPercentage?: number;
    customNotes?: string;
  }) => void;
}

const DEFAULT_TEMPLATES = [1, 3, 6, 12, 18, 24, 36];

const LOAN_CATEGORIES: { id: LoanCategory; label: string }[] = [
  { id: 'PayLater', label: 'PayLater' },
  { id: 'Device Installment', label: 'Device' },
  { id: 'Education', label: 'Education' },
  { id: 'Vehicle', label: 'Vehicle' },
  { id: 'Personal Loan', label: 'Personal Loan' },
  { id: 'Family Debt', label: 'Family Debt' },
  { id: 'Friend Debt', label: 'Friend Debt' },
  { id: 'Subscription Contract', label: 'Subscription' },
  { id: 'Others', label: 'Others' },
];

const QUICK_NAMES = ['SPayLater', 'Shopee PayLater', 'Laptop Loan', 'Phone Installment', 'Education Loan'];

export const CreateLoanModal: React.FC<CreateLoanModalProps> = ({
  isOpen,
  onClose,
  onCreateLoan,
}) => {
  const [loanName, setLoanName] = useState('');
  const [category, setCategory] = useState<LoanCategory>('PayLater');
  const [totalAmountStr, setTotalAmountStr] = useState('');
  const [selectedDuration, setSelectedDuration] = useState<number | 'custom'>(6);
  const [customMonths, setCustomMonths] = useState('8');

  // Installment Details
  const [installmentType, setInstallmentType] = useState<InstallmentType>('0% Interest');
  const [additionalMonthlyFee, setAdditionalMonthlyFee] = useState('');
  const [interestPct, setInterestPct] = useState('');
  const [customNotes, setCustomNotes] = useState('');

  // Flexible Due Date
  const [dueDate, setDueDate] = useState('15th of every month');

  if (!isOpen) return null;

  const totalAmount = parseFloat(totalAmountStr) || 0;
  const effectiveMonths = selectedDuration === 'custom' ? (parseInt(customMonths, 10) || 1) : selectedDuration;
  const extraMonthly = (installmentType !== '0% Interest' && parseFloat(additionalMonthlyFee)) || 0;

  // Monthly Payment = Total Loan Amount ÷ Loan Duration + Manual Additional Charge
  const baseMonthly = effectiveMonths > 0 && totalAmount > 0 ? (totalAmount / effectiveMonths) : 0;
  const finalMonthlyPayment = baseMonthly + extraMonthly;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loanName.trim() || totalAmount <= 0 || effectiveMonths <= 0) return;

    onCreateLoan({
      name: loanName.trim(),
      totalAmount,
      durationMonths: effectiveMonths,
      monthlyPayment: Math.round(finalMonthlyPayment * 100) / 100,
      category,
      dueDate: dueDate.trim() || '15th of every month',
      installmentType,
      additionalMonthlyCharge: extraMonthly > 0 ? extraMonthly : undefined,
      interestPercentage: interestPct ? parseFloat(interestPct) : undefined,
      customNotes: customNotes.trim() || undefined,
    });

    onClose();
    setLoanName('');
    setTotalAmountStr('');
    setAdditionalMonthlyFee('');
    setInterestPct('');
    setCustomNotes('');
    setInstallmentType('0% Interest');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full max-h-[92vh] overflow-y-auto shadow-2xl text-slate-100 flex flex-col my-auto">
        
        {/* Header */}
        <div className="sticky top-0 bg-slate-900/95 backdrop-blur-md px-5 py-3.5 border-b border-slate-800 flex items-center justify-between z-10">
          <div className="flex items-center gap-2">
            <Calculator className="w-4 h-4 text-blue-400" />
            <h3 className="font-bold text-white text-sm">New Loan / Installment</h3>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
          
          {/* STEP 1: NAME & CATEGORY */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="font-semibold text-slate-300 uppercase tracking-wider text-[11px]">
                1. Name & Category
              </label>
              <div className="flex gap-1 overflow-x-auto">
                {QUICK_NAMES.slice(0, 3).map(name => (
                  <button
                    key={name}
                    type="button"
                    onClick={() => setLoanName(name)}
                    className="px-2 py-0.5 rounded bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800 text-[10px]"
                  >
                    {name}
                  </button>
                ))}
              </div>
            </div>

            <input
              type="text"
              placeholder="e.g. SPayLater, Laptop Loan, Phone Installment"
              value={loanName}
              onChange={e => setLoanName(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white font-medium focus:outline-none focus:border-blue-500"
              required
            />

            <div className="grid grid-cols-3 gap-1 pt-1">
              {LOAN_CATEGORIES.map(cat => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setCategory(cat.id)}
                  className={`py-1.5 px-2 rounded-lg border text-center truncate text-[11px] transition-colors ${
                    category === cat.id
                      ? 'bg-blue-600/20 border-blue-500 text-blue-300 font-semibold'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* STEP 2: TOTAL LOAN AMOUNT */}
          <div className="space-y-1.5">
            <label className="font-semibold text-slate-300 uppercase tracking-wider text-[11px] block">
              2. Total Amount (RM)
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-mono font-bold text-sm">
                RM
              </span>
              <input
                type="number"
                step="any"
                min="1"
                placeholder="0.00"
                value={totalAmountStr}
                onChange={e => setTotalAmountStr(e.target.value)}
                className="w-full pl-12 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono text-base font-bold focus:outline-none focus:border-blue-500"
                required
              />
            </div>
          </div>

          {/* STEP 3: DURATION TEMPLATES */}
          <div className="space-y-1.5">
            <label className="font-semibold text-slate-300 uppercase tracking-wider text-[11px] block">
              3. Loan Duration
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
              {DEFAULT_TEMPLATES.map(months => {
                const isSelected = selectedDuration === months;
                const estMonthly = totalAmount > 0 ? (totalAmount / months) : 0;
                return (
                  <button
                    key={months}
                    type="button"
                    onClick={() => setSelectedDuration(months)}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      isSelected
                        ? 'bg-blue-500/15 border-blue-500 shadow-sm'
                        : 'bg-slate-950/70 border-slate-800 hover:border-slate-700 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className={`font-bold text-xs ${isSelected ? 'text-blue-300' : 'text-white'}`}>
                        {months} {months === 1 ? 'Month' : 'Months'}
                      </span>
                      {isSelected && <CheckCircle2 className="w-3 h-3 text-blue-400 shrink-0" />}
                    </div>
                    <div className="text-[10px] font-mono mt-0.5 text-slate-400">
                      {totalAmount > 0 ? `RM ${estMonthly.toFixed(0)}/mo` : 'Template'}
                    </div>
                  </button>
                );
              })}

              {/* Custom Duration */}
              <button
                type="button"
                onClick={() => setSelectedDuration('custom')}
                className={`p-2.5 rounded-xl border text-left transition-all col-span-2 sm:col-span-1 ${
                  selectedDuration === 'custom'
                    ? 'bg-blue-500/15 border-blue-500 shadow-sm'
                    : 'bg-slate-950/70 border-slate-800 hover:border-slate-700 text-slate-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className={`font-bold text-xs ${selectedDuration === 'custom' ? 'text-blue-300' : 'text-white'}`}>
                    Custom
                  </span>
                  {selectedDuration === 'custom' && <CheckCircle2 className="w-3 h-3 text-blue-400 shrink-0" />}
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  {selectedDuration === 'custom' ? `${effectiveMonths} Mo` : 'Enter months'}
                </div>
              </button>
            </div>

            {selectedDuration === 'custom' && (
              <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 flex items-center gap-2 mt-1">
                <span className="text-slate-400 text-xs">Enter Duration:</span>
                <input
                  type="number"
                  min="1"
                  max="120"
                  value={customMonths}
                  onChange={e => setCustomMonths(e.target.value)}
                  className="w-16 px-2 py-1 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-xs text-center"
                />
                <span className="text-slate-400 text-xs">Months</span>
              </div>
            )}
          </div>

          {/* STEP 4: INSTALLMENT TYPE & DETAILS */}
          <div className="space-y-2 pt-1 border-t border-slate-800/80">
            <label className="font-semibold text-slate-300 uppercase tracking-wider text-[11px] block">
              4. Installment Type
            </label>
            <div className="grid grid-cols-3 gap-1.5">
              {(['0% Interest', 'Interest Applied', 'Custom'] as InstallmentType[]).map(type => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setInstallmentType(type)}
                  className={`py-2 px-1 rounded-xl border text-center text-xs font-semibold transition-colors ${
                    installmentType === type
                      ? 'bg-purple-600/20 border-purple-500 text-purple-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>

            {/* Manual Installment Details if Interest Applied or Custom */}
            {installmentType !== '0% Interest' && (
              <div className="p-3 bg-slate-950 rounded-xl border border-purple-500/30 space-y-2.5">
                <span className="text-[11px] font-semibold text-purple-300 block">
                  Manual Installment Details
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-1">Additional Monthly Charge (RM)</label>
                    <input
                      type="number"
                      step="any"
                      placeholder="0.00"
                      value={additionalMonthlyFee}
                      onChange={e => setAdditionalMonthlyFee(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-xs"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-1">Interest Percentage (%)</label>
                    <input
                      type="number"
                      step="any"
                      placeholder="e.g. 1.5"
                      value={interestPct}
                      onChange={e => setInterestPct(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-xs"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-[10px] text-slate-400 block mb-1">Custom Notes</label>
                  <input
                    type="text"
                    placeholder="e.g. 1.5% admin fee applied"
                    value={customNotes}
                    onChange={e => setCustomNotes(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs"
                  />
                </div>
              </div>
            )}
          </div>

          {/* STEP 5: FLEXIBLE USER-DEFINED DUE DATE */}
          <div className="space-y-1.5">
            <label className="font-semibold text-slate-300 uppercase tracking-wider text-[11px] block">
              5. Due Date (Flexible)
            </label>
            <input
              type="text"
              placeholder="e.g. 15th of every month, Every Friday, Last day of month"
              value={dueDate}
              onChange={e => setDueDate(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs focus:outline-none focus:border-blue-500"
              required
            />
          </div>

          {/* PREVIEW SUMMARY */}
          <div className="rounded-2xl bg-slate-950 border border-slate-800 p-3.5 space-y-2">
            <div className="grid grid-cols-3 gap-2 text-center">
              <div>
                <span className="text-[10px] text-slate-500 block">Total</span>
                <span className="font-mono font-bold text-white text-sm">
                  RM {totalAmount.toFixed(0)}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block">Duration</span>
                <span className="font-bold text-blue-300 text-sm">
                  {effectiveMonths} Mo
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block">Monthly</span>
                <span className="font-mono font-extrabold text-emerald-400 text-sm">
                  RM {finalMonthlyPayment.toFixed(2)}
                </span>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="pt-1 flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!loanName.trim() || totalAmount <= 0}
              className={`flex-1 py-2 rounded-xl font-bold transition-all shadow-md flex items-center justify-center gap-1 ${
                !loanName.trim() || totalAmount <= 0
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-blue-500 hover:bg-blue-400 text-white'
              }`}
            >
              <span>Save Loan</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
