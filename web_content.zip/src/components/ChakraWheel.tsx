import React from 'react';
import { SessionState } from '../types';

interface ChakraWheelProps {
  sessionState: SessionState;
  isAudioActive: boolean;
  latestTranscript: string;
  hasApiKey: boolean;
}

export const ChakraWheel: React.FC<ChakraWheelProps> = ({
  sessionState,
  isAudioActive,
  latestTranscript,
  hasApiKey,
}) => {
  const isSpeaking = sessionState === 'SPEAKING' || isAudioActive;
  const isListening = sessionState === 'LISTENING';
  const isConnected = isSpeaking || isListening;

  const displayText = latestTranscript ||
    (!hasApiKey
      ? 'Please configure your Gemini API Key in Settings to start.'
      : sessionState === 'CONNECTING'
      ? 'Connecting live session...'
      : 'Harmonizing sacred palm & planetary energies...');

  return (
    <div className="relative flex flex-col items-center justify-center w-full select-none my-auto">
      {/* Status or Latest Speech Bubble */}
      {displayText && (
        <div className="w-full max-w-xs flex justify-center px-4 mb-3 z-10">
          <div
            className={`px-3.5 py-1.5 rounded-full glass-panel border transition-all duration-300 text-center shadow-lg backdrop-blur-md ${
              isSpeaking
                ? 'border-pink-500/50 bg-pink-950/30 text-pink-100 shadow-[0_0_15px_rgba(236,72,153,0.3)]'
                : isListening
                ? 'border-cyan-500/50 bg-cyan-950/30 text-cyan-100 shadow-[0_0_15px_rgba(6,182,212,0.3)]'
                : 'border-purple-500/30 bg-[#0d1224]/80 text-purple-200'
            }`}
          >
            <p className="text-[11px] sm:text-xs font-medium leading-relaxed truncate max-w-[260px]">
              {displayText}
            </p>
          </div>
        </div>
      )}

      {/* Realistic, Futuristic Rotating Zodiac Chakra Mandala */}
      <div className="relative flex items-center justify-center w-52 h-52 sm:w-60 sm:h-60">
        {/* Outermost Cosmic Ambient Glow Aura */}
        <div
          className={`absolute inset-0 rounded-full transition-all duration-700 blur-2xl ${
            isSpeaking
              ? 'bg-gradient-to-tr from-purple-600/60 via-pink-600/50 to-cyan-400/60 scale-125 opacity-90'
              : isListening
              ? 'bg-gradient-to-tr from-cyan-500/50 via-purple-600/40 to-blue-500/50 scale-115 opacity-80 animate-pulse'
              : 'bg-gradient-to-tr from-purple-700/30 via-indigo-600/20 to-cyan-600/30 scale-100 opacity-60'
          }`}
        />

        {/* Outer Zodiac Orbit Ring (Clockwise Rotation) */}
        <div className="absolute inset-0 rounded-full border border-purple-500/30 animate-spin-slow pointer-events-none flex items-center justify-center">
          {/* Constellation Ticks */}
          <svg className="w-full h-full absolute inset-0" viewBox="0 0 240 240">
            <circle
              cx="120"
              cy="120"
              r="112"
              fill="none"
              stroke="rgba(168, 85, 247, 0.4)"
              strokeWidth="1"
              strokeDasharray="2 6"
            />
            <circle
              cx="120"
              cy="120"
              r="104"
              fill="none"
              stroke="rgba(6, 182, 212, 0.3)"
              strokeWidth="0.75"
            />
          </svg>

          {/* 12 Zodiac Symbols placed symmetrically around the circumference */}
          <span className="absolute top-1 text-[11px] font-bold text-cyan-300 drop-shadow-[0_0_6px_rgba(6,182,212,0.8)]">♈</span>
          <span className="absolute top-[18%] right-[14%] text-[10px] text-purple-300">♉</span>
          <span className="absolute top-[36%] right-[3%] text-[10px] text-pink-300">♊</span>
          <span className="absolute bottom-[36%] right-[3%] text-[10px] text-cyan-300">♋</span>
          <span className="absolute bottom-[18%] right-[14%] text-[10px] text-purple-300">♌</span>
          <span className="absolute bottom-1 text-[11px] font-bold text-pink-300 drop-shadow-[0_0_6px_rgba(236,72,153,0.8)]">♍</span>
          <span className="absolute bottom-[18%] left-[14%] text-[10px] text-cyan-300">♎</span>
          <span className="absolute bottom-[36%] left-[3%] text-[10px] text-purple-300">♏</span>
          <span className="absolute top-[36%] left-[3%] text-[10px] text-pink-300">♐</span>
          <span className="absolute top-[18%] left-[14%] text-[10px] text-cyan-300">♑</span>
          <span className="absolute right-1 text-[10px] text-purple-300">♒</span>
          <span className="absolute left-1 text-[10px] text-cyan-300">♓</span>
        </div>

        {/* Middle Sacred Planetary / Mounts Chakra Ring (Counter-Clockwise Rotation) */}
        <div className="absolute inset-5 rounded-full border border-cyan-400/40 border-dashed animate-spin-reverse-slow pointer-events-none flex items-center justify-center">
          <svg className="w-full h-full absolute inset-0" viewBox="0 0 200 200">
            {/* 8-Point Star Sacred Rays */}
            <polygon
              points="100,10 120,70 190,100 120,130 100,190 80,130 10,100 80,70"
              fill="none"
              stroke="rgba(147, 51, 234, 0.35)"
              strokeWidth="0.8"
            />
            {/* Secondary Golden Ratio Ring */}
            <circle
              cx="100"
              cy="100"
              r="76"
              fill="none"
              stroke="rgba(236, 72, 153, 0.3)"
              strokeWidth="0.75"
              strokeDasharray="4 8"
            />
          </svg>

          {/* Planetary symbols in cardinal positions */}
          <span className="absolute top-2 text-[10px] text-yellow-300/80 font-bold">☉</span>
          <span className="absolute bottom-2 text-[10px] text-slate-200/80 font-bold">☽</span>
          <span className="absolute left-2 text-[10px] text-red-400/80 font-bold">♂</span>
          <span className="absolute right-2 text-[10px] text-emerald-300/80 font-bold">☿</span>
        </div>

        {/* Inner Palm Sacred Geometry Mandala Ring (Clockwise Rotation) */}
        <div className="absolute inset-10 rounded-full border border-purple-400/50 pointer-events-none flex items-center justify-center animate-spin-slow">
          <svg className="w-full h-full" viewBox="0 0 160 160">
            {/* Flower of Life intersecting circles */}
            {[0, 60, 120, 180, 240, 300].map((angle, i) => {
              const rad = (angle * Math.PI) / 180;
              const cx = 80 + 26 * Math.cos(rad);
              const cy = 80 + 26 * Math.sin(rad);
              return (
                <circle
                  key={i}
                  cx={cx}
                  cy={cy}
                  r="26"
                  fill="none"
                  stroke="rgba(6, 182, 212, 0.4)"
                  strokeWidth="0.8"
                />
              );
            })}
            <circle
              cx="80"
              cy="80"
              r="26"
              fill="none"
              stroke="rgba(192, 132, 252, 0.5)"
              strokeWidth="1"
            />
          </svg>
        </div>

        {/* Center Radiant Focal Core (NO PHOTO / NO AVATAR) */}
        <div className="relative w-20 h-20 sm:w-22 sm:h-22 rounded-full flex items-center justify-center z-10">
          {/* Core Pulsing Glow */}
          <div
            className={`absolute inset-0 rounded-full transition-all duration-500 blur-md ${
              isSpeaking
                ? 'bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-400 opacity-90 scale-110'
                : isListening
                ? 'bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 opacity-80 scale-105'
                : 'bg-gradient-to-r from-purple-700 to-indigo-900 opacity-60'
            }`}
          />

          {/* Core Glass Sphere */}
          <div className="relative w-full h-full rounded-full bg-gradient-to-br from-[#131b38] via-[#090d1f] to-[#04060d] border-2 border-purple-400/60 shadow-[inset_0_0_15px_rgba(168,85,247,0.5)] flex items-center justify-center">
            {/* Center Sacred Palm / Energy Emblem */}
            <svg
              className={`w-10 h-10 transition-transform duration-700 ${
                isConnected ? 'scale-110' : 'scale-100'
              }`}
              viewBox="0 0 24 24"
              fill="none"
            >
              {/* Sacred Palm contour lines */}
              <path
                d="M12 2C10.5 2 9.5 3 9.5 4.5V11C9.5 11.5 9 12 8.5 12C8 12 7.5 11.5 7.5 11V6C7.5 4.8 6.5 4 5.5 4C4.5 4 3.5 4.8 3.5 6V13.5C3.5 18 7 21.5 11.5 21.5C16.5 21.5 20.5 17.5 20.5 12.5V8.5C20.5 7.2 19.5 6.5 18.5 6.5C17.5 6.5 16.5 7.2 16.5 8.5V11C16.5 11.5 16 12 15.5 12C15 12 14.5 11.5 14.5 11V3.5C14.5 2.5 13.5 2 12 2Z"
                stroke="url(#palmGrad)"
                strokeWidth="1.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              {/* Heart Line & Life Line glow curves */}
              <path
                d="M6 13C8 15 11 16 14 14"
                stroke="rgba(236, 72, 153, 0.9)"
                strokeWidth="1"
                strokeLinecap="round"
              />
              <path
                d="M7 16C9 18 12 18.5 15 17"
                stroke="rgba(6, 182, 212, 0.9)"
                strokeWidth="1"
                strokeLinecap="round"
              />
              <defs>
                <linearGradient id="palmGrad" x1="3" y1="2" x2="20" y2="21" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#c084fc" />
                  <stop offset="0.5" stopColor="#38bdf8" />
                  <stop offset="1" stopColor="#ec4899" />
                </linearGradient>
              </defs>
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
};
