import { Monitor, RefreshCw, Smartphone, Tablet, Maximize2 } from "lucide-react";
import { useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { RUN_TIMEOUT } from "@/lib/nijo/run";
import { useProjectStore } from "@/lib/nijo/store";
import type { PreviewDevice } from "@/lib/nijo/types";

const DEVICE_CLASS: Record<PreviewDevice, string> = {
  mobile: "max-w-sm",
  tablet: "max-w-3xl",
  desktop: "max-w-none",
};

export function PreviewPanel({ onFullscreen }: { onFullscreen: () => void }) {
  const run = useProjectStore((s) => s.run);
  const device = useProjectStore((s) => s.previewDevice);
  const setDevice = useProjectStore((s) => s.setDevice);
  const appendConsole = useProjectStore((s) => s.appendConsole);
  const setRun = useProjectStore((s) => s.setRun);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    function onMessage(event: MessageEvent) {
      const data = event.data as { source?: string; type?: string; level?: string; text?: string; meta?: string };
      if (!data || data.source !== "nijo-preview") return;
      if (data.type === "console") {
        const level = data.level === "error" || data.level === "warn" || data.level === "info" ? data.level : "log";
        appendConsole({ level, text: data.text ?? "", meta: data.meta });
        if (level === "error") setRun({ ...useProjectStore.getState().run, status: "error" });
      }
      if (data.type === "done" || data.type === "ready") {
        const current = useProjectStore.getState().run;
        if (current.status === "running") setRun({ ...current, status: "ok" });
      }
    }
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, [appendConsole, setRun]);

  useEffect(() => {
    if (run.status !== "running") return;
    const timer = window.setTimeout(() => {
      const current = useProjectStore.getState().run;
      if (current.status === "running" && current.mode !== "console") {
        setRun({ ...current, status: "ok" });
        return;
      }
      if (current.status === "running") {
        setRun({ ...current, status: "timeout", message: "Execution timed out." });
        appendConsole({ level: "error", text: "Execution timed out.", meta: "Stopped for safety" });
        if (iframeRef.current) iframeRef.current.src = "about:blank";
      }
    }, RUN_TIMEOUT);
    return () => window.clearTimeout(timer);
  }, [run.status, run.ranAt, appendConsole, setRun]);

  const devices: { id: PreviewDevice; icon: typeof Smartphone; label: string }[] = [
    { id: "mobile", icon: Smartphone, label: "Mobile" },
    { id: "tablet", icon: Tablet, label: "Tablet" },
    { id: "desktop", icon: Monitor, label: "Desktop" },
  ];
  const visualMode =
    run.mode === "preview" ||
    run.mode === "markdown" ||
    run.mode === "formatted" ||
    run.mode === "svg" ||
    run.mode === "image";

  return (
    <div className="flex h-full min-h-0 flex-col bg-bg">
      <div className="flex items-center gap-1 border-b border-border px-2 py-2">
        {devices.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setDevice(item.id)}
            className={`flex h-10 items-center gap-1.5 rounded-md px-3 text-xs font-medium ${
              device === item.id ? "bg-surface text-fg" : "text-muted"
            }`}
          >
            <item.icon className="size-4" />
            {item.label}
          </button>
        ))}
        <div className="ml-auto flex items-center gap-1">
          <Button
            size="icon"
            variant="ghost"
            aria-label="Refresh preview"
            onClick={() => {
              const html = useProjectStore.getState().run.html;
              if (iframeRef.current && html) {
                iframeRef.current.srcdoc = html;
              }
            }}
          >
            <RefreshCw className="size-4" />
          </Button>
          <Button size="icon" variant="ghost" aria-label="Fullscreen preview" onClick={onFullscreen}>
            <Maximize2 className="size-4" />
          </Button>
        </div>
      </div>

      <div className="flex min-h-0 flex-1 justify-center overflow-auto bg-elevated p-3">
        {run.status === "unavailable" && (
          <div className="mx-auto max-w-sm rounded-xl bg-surface p-5 shadow-nijo">
            <p className="text-sm font-medium">Execution environment unavailable</p>
            <p className="mt-2 text-sm text-muted">{run.message}</p>
            <p className="mt-3 text-xs text-subtle">The editor still works. You can copy, edit, and save this file.</p>
          </div>
        )}
        {run.status === "idle" && !run.html && (
          <div className="grid h-full place-items-center text-center text-sm text-muted">
            Tap Run to preview this file.
          </div>
        )}
        {run.html && run.status !== "unavailable" && visualMode && (
          <div className={`mx-auto h-full overflow-hidden rounded-lg bg-white shadow-nijo ${DEVICE_CLASS[device]}`}>
            <iframe
              ref={iframeRef}
              title="NIJO preview"
              className="h-full w-full bg-white"
              sandbox="allow-scripts allow-forms allow-modals"
              srcDoc={run.html}
            />
          </div>
        )}
        {run.mode === "console" && !run.html && run.status === "running" && (
          <div className="grid h-full place-items-center text-sm text-muted">{run.message ?? "Running…"}</div>
        )}
      </div>
    </div>
  );
}

export function ConsolePanel() {
  const lines = useProjectStore((s) => s.consoleLines);
  const clearConsole = useProjectStore((s) => s.clearConsole);
  const run = useProjectStore((s) => s.run);

  return (
    <div className="flex min-h-40 flex-col border-t border-border bg-elevated">
      <div className="flex h-10 items-center justify-between px-3">
        <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted">Console</p>
        <button type="button" className="text-xs text-muted" onClick={clearConsole}>
          Clear
        </button>
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto px-3 pb-3 font-mono text-xs leading-relaxed">
        {run.status === "ok" && (
          <p className="mb-1 text-success">Execution completed</p>
        )}
        {run.status === "error" && <p className="mb-1 text-danger">Error</p>}
        {run.status === "timeout" && <p className="mb-1 text-warning">Timed out</p>}
        {run.status === "unavailable" && <p className="mb-1 text-warning">Execution environment unavailable</p>}
        {run.status === "running" && (
          <p className="mb-1 text-muted">{run.message ?? "Running…"}</p>
        )}
        {lines.length === 0 && run.status !== "running" && <p className="text-subtle">No output yet.</p>}
        {lines.map((line) => (
          <p
            key={line.id}
            className={
              line.level === "error"
                ? "whitespace-pre-wrap text-danger"
                : line.level === "warn"
                  ? "whitespace-pre-wrap text-warning"
                  : line.level === "success"
                    ? "whitespace-pre-wrap text-success"
                    : "whitespace-pre-wrap text-fg"
            }
          >
            {line.meta ? `${line.meta} · ` : ""}
            {line.text}
          </p>
        ))}
      </div>
    </div>
  );
}
