import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { askNijoAssistant, canCallAssistant, recordAssistantCall, type AiTask } from "@/lib/nijo/ai";
import { AI_MAX_CODE_CHARS } from "@/lib/nijo/limits";
import { getActiveFile, resolvedLanguage } from "@/lib/nijo/store";

const TASKS: { id: AiTask; label: string }[] = [
  { id: "explain", label: "Explain" },
  { id: "fix", label: "Fix" },
  { id: "optimize", label: "Optimize" },
  { id: "convert", label: "Convert" },
  { id: "generate", label: "Generate" },
];

export function AssistantSheet({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const [task, setTask] = useState<AiTask>("explain");
  const [prompt, setPrompt] = useState("");
  const [reply, setReply] = useState("");
  const [busy, setBusy] = useState(false);

  async function run() {
    const gate = canCallAssistant();
    if (!gate.ok) {
      toast.error(gate.error);
      return;
    }
    const file = getActiveFile();
    const code = (file?.content ?? "").slice(0, AI_MAX_CODE_CHARS);
    if (!code && task !== "generate") {
      toast.error("Open a file first.");
      return;
    }
    setBusy(true);
    setReply("");
    try {
      const result = await askNijoAssistant({
        data: {
          task,
          code: code || "// empty",
          language: file ? resolvedLanguage(file) : "javascript",
          prompt: prompt.trim() || undefined,
        },
      });
      if (!result.ok) {
        toast.error(result.error);
        return;
      }
      recordAssistantCall();
      setReply(result.text);
    } catch {
      toast.error("Assistant is not available right now.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent title="AI assistant">
        <div className="flex flex-col gap-3">
          <div className="flex flex-wrap gap-2">
            {TASKS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setTask(item.id)}
                className={`h-10 rounded-full px-3 text-sm ${
                  task === item.id ? "bg-primary text-primary-fg" : "bg-surface text-fg"
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Optional: convert to JavaScript, explain in Arabic…"
            className="min-h-20 w-full rounded-md bg-surface p-3 text-sm text-fg shadow-nijo outline-none placeholder:text-subtle"
          />
          <Button onClick={() => void run()} disabled={busy}>
            {busy ? "Working…" : "Ask assistant"}
          </Button>
          {reply && (
            <pre className="max-h-64 overflow-auto whitespace-pre-wrap rounded-md bg-surface p-3 font-mono text-xs leading-relaxed text-fg">
              {reply}
            </pre>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}
