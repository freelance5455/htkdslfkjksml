import {
  Check,
  CheckSquare,
  ClipboardPaste,
  Copy,
  Eraser,
  Eye,
  FileCode2,
  FolderOpen,
  Maximize2,
  Minimize2,
  MoreHorizontal,
  Play,
  Redo2,
  Scissors,
  Search,
  Settings,
  Sparkles,
  Undo2,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { NijoMark } from "@/components/brand/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { formatCode } from "@/lib/nijo/format";
import { groupedLanguages, languageById, OPEN_ACCEPT } from "@/lib/nijo/languages";
import { prepareRun, runPython } from "@/lib/nijo/run";
import { getActiveFile, resolvedLanguage, useProjectStore } from "@/lib/nijo/store";
import type { LanguageId, WorkspaceTab } from "@/lib/nijo/types";
import { importZip } from "@/lib/nijo/zip";
import { baseName, cn } from "@/lib/utils";
import { AssistantSheet } from "./assistant-sheet";
import { CodeEditor, type EditorHandle } from "./code-editor";
import { FilesPanel } from "./files-panel";
import { ConsolePanel, PreviewPanel } from "./preview-panel";
import { SettingsPanel } from "./settings-panel";

const TOOLBAR_CHARS = ["{", "}", "(", ")", "[", "]", "<", ">", ";", ":", '"', "'", "=", "/", "+", "-", "*", "_", "#"];

const TABS: { id: WorkspaceTab; label: string; icon: typeof FileCode2 }[] = [
  { id: "editor", label: "Editor", icon: FileCode2 },
  { id: "run", label: "Run", icon: Play },
  { id: "preview", label: "Preview", icon: Eye },
  { id: "files", label: "Files", icon: FolderOpen },
  { id: "settings", label: "Settings", icon: Settings },
];

export function WorkspaceApp({ intent }: { intent?: "paste" | "open" }) {
  const hydrate = useProjectStore((s) => s.hydrate);
  const hydrated = useProjectStore((s) => s.hydrated);
  const tab = useProjectStore((s) => s.tab);
  const setTab = useProjectStore((s) => s.setTab);
  const files = useProjectStore((s) => s.files);
  const activeFileId = useProjectStore((s) => s.activeFileId);
  const settings = useProjectStore((s) => s.settings);
  const updateContent = useProjectStore((s) => s.updateContent);
  const setLanguage = useProjectStore((s) => s.setLanguage);
  const autoDetectActive = useProjectStore((s) => s.autoDetectActive);
  const fullscreen = useProjectStore((s) => s.fullscreen);
  const setFullscreen = useProjectStore((s) => s.setFullscreen);
  const findOpen = useProjectStore((s) => s.findOpen);
  const setFindOpen = useProjectStore((s) => s.setFindOpen);
  const openLocalText = useProjectStore((s) => s.openLocalText);
  const replaceProject = useProjectStore((s) => s.replaceProject);
  const appendConsole = useProjectStore((s) => s.appendConsole);
  const clearConsole = useProjectStore((s) => s.clearConsole);
  const setRun = useProjectStore((s) => s.setRun);
  const run = useProjectStore((s) => s.run);

  const file = files.find((f) => f.id === activeFileId);
  const language = file ? resolvedLanguage(file) : "javascript";
  const editorRef = useRef<EditorHandle>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  const [kb, setKb] = useState(0);
  const [moreOpen, setMoreOpen] = useState(false);
  const [langOpen, setLangOpen] = useState(false);
  const [pasteOpen, setPasteOpen] = useState(false);
  const [pasteDraft, setPasteDraft] = useState("");
  const [assistantOpen, setAssistantOpen] = useState(false);
  const [find, setFind] = useState("");
  const [replace, setReplace] = useState("");
  const handledIntent = useRef(false);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    if (!hydrated || handledIntent.current || !intent) return;
    handledIntent.current = true;
    if (intent === "open") fileInput.current?.click();
    if (intent === "paste") void handlePaste();
    void navigate({ to: "/workspace", search: {}, replace: true });
  }, [hydrated, intent, navigate]);

  useEffect(() => {
    const vv = window.visualViewport;
    if (!vv) return;
    const update = () => {
      const inset = Math.max(0, window.innerHeight - vv.height - vv.offsetTop);
      setKb(inset);
      document.documentElement.style.setProperty("--nijo-kb", `${inset}px`);
    };
    vv.addEventListener("resize", update);
    vv.addEventListener("scroll", update);
    update();
    return () => {
      vv.removeEventListener("resize", update);
      vv.removeEventListener("scroll", update);
    };
  }, []);

  async function handlePaste() {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        applyPasted(text);
        return;
      }
    } catch {
      /* iOS often blocks this */
    }
    setPasteDraft("");
    setPasteOpen(true);
  }

  function applyPasted(text: string) {
    const current = getActiveFile();
    if (!current) return;
    useProjectStore.getState().updateContent(current.id, text);
    const detected = autoDetectActive();
    toast.success(`Pasted · ${languageById(detected).label}`);
    setTab("editor");
    setPasteOpen(false);
  }

  async function handleCopy() {
    const text = file?.content ?? "";
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Code copied");
      return;
    } catch {
      /* fall through */
    }
    try {
      const area = document.createElement("textarea");
      area.value = text;
      area.setAttribute("readonly", "true");
      area.style.position = "fixed";
      area.style.left = "-9999px";
      document.body.appendChild(area);
      area.select();
      const ok = document.execCommand("copy");
      area.remove();
      if (ok) toast.success("Code copied");
      else toast.error("Could not copy. Select the code and copy it manually.");
    } catch {
      toast.error("Could not copy. Select the code and copy it manually.");
    }
  }

  async function handleOpen(list: FileList | null) {
    const picked = list?.[0];
    if (!picked) return;
    if (picked.name.toLowerCase().endsWith(".zip")) {
      try {
        const imported = await importZip(picked);
        const error = replaceProject(imported.name, imported.files, imported.folders);
        if (error) toast.error(error);
        else toast.success(`Opened ${imported.name}`);
      } catch (err) {
        toast.error(err instanceof Error ? err.message : "Could not open ZIP.");
      }
      return;
    }
    try {
      const text = await picked.text();
      const error = openLocalText(picked.name, text);
      if (error) toast.error(error);
      else toast.success(`Opened ${picked.name}`);
    } catch {
      toast.error("Could not read that file.");
    }
  }

  async function handleRun() {
    const active = getActiveFile();
    clearConsole();
    appendConsole({ level: "status", text: "Running…" });
    setRun({ mode: "preview", status: "running", message: "Running…" });
    const snapshot = await prepareRun(useProjectStore.getState().files, active);
    setRun(snapshot);
    if (snapshot.status === "unavailable") {
      appendConsole({ level: "error", text: snapshot.message ?? "Execution environment unavailable" });
    } else if (snapshot.status === "error") {
      appendConsole({ level: "error", text: snapshot.message ?? "Run failed" });
    } else if (
      snapshot.mode === "preview" ||
      snapshot.mode === "markdown" ||
      snapshot.mode === "svg" ||
      snapshot.mode === "formatted" ||
      snapshot.mode === "image"
    ) {
      appendConsole({ level: "success", text: "Preview ready" });
    }
    if (snapshot.mode === "console" || snapshot.mode === "unavailable") setTab("run");
    else setTab("preview");

    if (snapshot.mode === "console" && snapshot.message === "Loading Python runtime…") {
      appendConsole({ level: "status", text: "Loading Python runtime…" });
      try {
        const code = getActiveFile()?.content ?? active?.content ?? "";
        await runPython(code, (level, text) => {
          appendConsole({ level: level === "error" ? "error" : "log", text });
        });
        appendConsole({ level: "success", text: "Execution completed" });
        setRun({ mode: "console", status: "ok", ranAt: Date.now() });
      } catch (err) {
        const message = err instanceof Error ? err.message : "Python failed.";
        const unavailable = /load|timed out|timeout/i.test(message);
        appendConsole({ level: "error", text: message });
        setRun({
          mode: "console",
          status: unavailable ? "unavailable" : "error",
          message: unavailable ? "Execution environment unavailable" : message,
          ranAt: Date.now(),
        });
      }
    }
  }

  function findNext(direction: 1 | -1) {
    const view = editorRef.current?.view();
    if (!view || !find) return;
    const doc = view.state.doc.toString();
    const start = view.state.selection.main.to;
    const hay = direction === 1 ? doc.slice(start) + "\n" + doc.slice(0, start) : doc;
    const idx =
      direction === 1
        ? hay.toLowerCase().indexOf(find.toLowerCase())
        : doc.toLowerCase().lastIndexOf(find.toLowerCase(), view.state.selection.main.from - 1);
    if (idx < 0) {
      toast.message("No matches");
      return;
    }
    const from = direction === 1 ? (idx + start) % (doc.length + 1) : idx;
    const to = from + find.length;
    view.dispatch({ selection: { anchor: from, head: to }, scrollIntoView: true });
    view.focus();
  }

  function replaceOne() {
    const view = editorRef.current?.view();
    if (!view || !find) return;
    const selected = editorRef.current?.getSelected() ?? "";
    if (selected.toLowerCase() === find.toLowerCase()) {
      editorRef.current?.replaceSelection(replace);
    }
    findNext(1);
  }

  function replaceEvery() {
    if (!file || !find) return;
    const next = file.content.split(find).join(replace);
    updateContent(file.id, next);
    toast.success("Replaced all");
  }

  const keyboardOpen = kb > 80;
  const navHidden = fullscreen || keyboardOpen;

  const groups = useMemo(() => groupedLanguages(), []);

  if (!hydrated) {
    return (
      <div className="grid h-dvh place-items-center bg-bg text-sm text-muted">
        Loading workspace…
      </div>
    );
  }

  return (
    <div
      className="flex h-dvh flex-col overflow-hidden bg-bg text-fg"
      style={{ paddingBottom: navHidden ? kb : undefined }}
    >
      <header className="flex h-12 shrink-0 items-center gap-2 border-b border-border px-2 nijo-safe-top">
        <Link to="/" className="flex size-11 items-center justify-center" aria-label="Home">
          <NijoMark className="size-8" />
        </Link>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium">{file ? baseName(file.path) : "No file"}</p>
          <button
            type="button"
            className="truncate text-left text-xs text-muted"
            onClick={() => setLangOpen(true)}
          >
            {languageById(language).label}
          </button>
        </div>
        <HeaderIcon label="Paste" onClick={() => void handlePaste()}>
          <ClipboardPaste className="size-4" />
        </HeaderIcon>
        <HeaderIcon label="Copy" onClick={() => void handleCopy()}>
          <Copy className="size-4" />
        </HeaderIcon>
        <HeaderIcon label="More" onClick={() => setMoreOpen(true)}>
          <MoreHorizontal className="size-4" />
        </HeaderIcon>
      </header>

      {findOpen && tab === "editor" && (
        <div className="flex flex-col gap-2 border-b border-border bg-elevated p-2">
          <div className="flex gap-2">
            <Input value={find} onChange={(e) => setFind(e.target.value)} placeholder="Find" className="h-10" />
            <Button size="sm" variant="secondary" onClick={() => findNext(-1)}>
              Prev
            </Button>
            <Button size="sm" variant="secondary" onClick={() => findNext(1)}>
              Next
            </Button>
          </div>
          <div className="flex gap-2">
            <Input value={replace} onChange={(e) => setReplace(e.target.value)} placeholder="Replace" className="h-10" />
            <Button size="sm" variant="secondary" onClick={replaceOne}>
              One
            </Button>
            <Button size="sm" variant="secondary" onClick={replaceEvery}>
              All
            </Button>
            <Button size="sm" variant="ghost" onClick={() => setFindOpen(false)}>
              Close
            </Button>
          </div>
        </div>
      )}

      <main className="relative min-h-0 flex-1">
        <div className={cn("absolute inset-0", tab === "editor" ? "block" : "hidden")}>
          {file?.language === "image" ? (
            <div className="grid h-full place-items-center p-6">
              <img src={file.content} alt={file.path} className="max-h-full max-w-full rounded-lg" />
            </div>
          ) : (
            <CodeEditor
              ref={editorRef}
              value={file?.content ?? ""}
              language={language}
              fontSize={settings.fontSize}
              wrap={settings.wrap}
              tabSize={settings.tabSize}
              theme={settings.theme}
              onChange={(value) => {
                if (file) updateContent(file.id, value);
              }}
            />
          )}
        </div>
        <div className={cn("absolute inset-0 flex flex-col", tab === "run" ? "flex" : "hidden")}>
          <div className="flex items-center justify-between gap-3 border-b border-border px-4 py-3">
            <div>
              <p className="text-sm font-medium">Run</p>
              <p className="text-xs text-muted">{languageById(language).label}</p>
            </div>
            <Button onClick={() => void handleRun()}>
              <Play className="size-4" /> Run
            </Button>
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto p-4">
            <p className="text-sm text-muted">
              Web files preview in a sandboxed frame. Console programs print below. Compilers that need a native SDK stay in the editor.
            </p>
            <Button className="mt-4 w-full" variant="secondary" onClick={() => void handleRun()}>
              Run this file
            </Button>
            {run.html && run.mode === "console" && (
              <iframe
                title="NIJO runner"
                className="hidden"
                sandbox="allow-scripts"
                srcDoc={run.html}
              />
            )}
          </div>
          <ConsolePanel />
        </div>
        <div className={cn("absolute inset-0 flex flex-col", tab === "preview" ? "flex" : "hidden")}>
          <PreviewPanel onFullscreen={() => setFullscreen(!fullscreen)} />
          <ConsolePanel />
        </div>
        <div className={cn("absolute inset-0", tab === "files" ? "block" : "hidden")}>
          <FilesPanel />
        </div>
        <div className={cn("absolute inset-0", tab === "settings" ? "block" : "hidden")}>
          <SettingsPanel onAssistant={() => setAssistantOpen(true)} />
        </div>
      </main>

      {!fullscreen && (
        <div
          className="nijo-toolbar flex shrink-0 gap-1 overflow-x-auto border-t border-border bg-elevated px-2 py-1.5"
          style={{ paddingBottom: keyboardOpen ? 6 : undefined }}
        >
          {TOOLBAR_CHARS.map((char) => (
            <button
              key={char}
              type="button"
              className="flex h-10 min-w-10 shrink-0 items-center justify-center rounded-sm bg-surface font-mono text-sm text-fg"
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => {
                editorRef.current?.insert(char);
              }}
            >
              {char}
            </button>
          ))}
        </div>
      )}

      {!navHidden && (
        <nav
          className="grid shrink-0 grid-cols-5 border-t border-border bg-elevated pb-[env(safe-area-inset-bottom)]"
          style={{ minHeight: "var(--nijo-nav)" }}
        >
          {TABS.map((item) => {
            const Icon = item.icon;
            const active = tab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                className={cn(
                  "flex flex-col items-center justify-center gap-0.5 text-[11px]",
                  active ? "text-primary" : "text-muted",
                )}
                onClick={() => {
                  if (item.id === "run") void handleRun();
                  else setTab(item.id);
                }}
              >
                <Icon className="size-5" />
                {item.label}
              </button>
            );
          })}
        </nav>
      )}

      <input
        ref={fileInput}
        type="file"
        accept={OPEN_ACCEPT}
        className="hidden"
        onChange={(e) => void handleOpen(e.target.files)}
      />

      <Sheet open={moreOpen} onOpenChange={setMoreOpen}>
        <SheetContent title="Editor actions">
          <div className="grid grid-cols-2 gap-2 pt-1">
            <Action
              icon={Scissors}
              label="Cut"
              onClick={async () => {
                const selected = editorRef.current?.getSelected() || file?.content || "";
                try {
                  await navigator.clipboard.writeText(selected);
                  if (editorRef.current?.getSelected()) editorRef.current.replaceSelection("");
                  else if (file) updateContent(file.id, "");
                } catch {
                  toast.error("Cut needs clipboard permission.");
                }
                setMoreOpen(false);
              }}
            />
            <Action icon={Copy} label="Copy all" onClick={() => { void handleCopy(); setMoreOpen(false); }} />
            <Action icon={ClipboardPaste} label="Paste" onClick={() => { setMoreOpen(false); void handlePaste(); }} />
            <Action
              icon={Undo2}
              label="Undo"
              onClick={() => {
                editorRef.current?.undo();
                setMoreOpen(false);
              }}
            />
            <Action
              icon={Redo2}
              label="Redo"
              onClick={() => {
                editorRef.current?.redo();
                setMoreOpen(false);
              }}
            />
            <Action
              icon={Search}
              label="Find"
              onClick={() => {
                setFindOpen(true);
                setTab("editor");
                setMoreOpen(false);
              }}
            />
            <Action
              icon={CheckSquare}
              label="Select all"
              onClick={() => {
                editorRef.current?.selectAll();
                setMoreOpen(false);
              }}
            />
            <Action
              icon={Eraser}
              label="Clear"
              onClick={() => {
                if (file) updateContent(file.id, "");
                setMoreOpen(false);
              }}
            />
            <Action
              icon={FileCode2}
              label="Format"
              onClick={() => {
                if (!file) return;
                updateContent(file.id, formatCode(file.content, language));
                toast.success("Formatted");
                setMoreOpen(false);
              }}
            />
            <Action
              icon={fullscreen ? Minimize2 : Maximize2}
              label="Fullscreen"
              onClick={() => {
                setFullscreen(!fullscreen);
                setMoreOpen(false);
              }}
            />
            <Action
              icon={Sparkles}
              label="Assistant"
              onClick={() => {
                setMoreOpen(false);
                setAssistantOpen(true);
              }}
            />
            <Action
              icon={FolderOpen}
              label="Open file"
              onClick={() => {
                setMoreOpen(false);
                fileInput.current?.click();
              }}
            />
          </div>
        </SheetContent>
      </Sheet>

      <Sheet open={langOpen} onOpenChange={setLangOpen}>
        <SheetContent title="Language">
          <div className="space-y-4">
            {groups.map((group) => (
              <div key={group.group}>
                <p className="mb-2 text-xs font-medium uppercase tracking-[0.14em] text-muted">{group.group}</p>
                <div className="flex flex-col">
                  {group.items.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      className="flex h-11 items-center justify-between text-left text-sm"
                      onClick={() => {
                        if (file) setLanguage(file.id, item.id);
                        if (item.id === "auto") autoDetectActive();
                        setLangOpen(false);
                      }}
                    >
                      <span>{item.label}</span>
                      {file?.language === item.id && <Check className="size-4 text-primary" />}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </SheetContent>
      </Sheet>

      <Sheet open={pasteOpen} onOpenChange={setPasteOpen}>
        <SheetContent title="Paste code">
          <p className="mb-3 text-sm text-muted">Long-press and paste, then tap Insert.</p>
          <textarea
            autoFocus
            value={pasteDraft}
            onChange={(e) => setPasteDraft(e.target.value)}
            className="min-h-40 w-full rounded-md bg-surface p-3 font-mono text-sm text-fg shadow-nijo outline-none"
            placeholder="Paste here"
          />
          <Button className="mt-3 w-full" onClick={() => applyPasted(pasteDraft)} disabled={!pasteDraft.trim()}>
            Insert into editor
          </Button>
        </SheetContent>
      </Sheet>

      <AssistantSheet open={assistantOpen} onOpenChange={setAssistantOpen} />
    </div>
  );
}

function HeaderIcon({
  children,
  label,
  onClick,
}: {
  children: ReactNode;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className="flex size-11 items-center justify-center rounded-md text-fg"
    >
      {children}
    </button>
  );
}

function Action({
  icon: Icon,
  label,
  onClick,
}: {
  icon: typeof Copy;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex h-16 flex-col items-center justify-center gap-1 rounded-md bg-surface text-xs text-fg"
    >
      <Icon className="size-4" />
      {label}
    </button>
  );
}

export function languageLabel(id: LanguageId): string {
  return languageById(id).label;
}
