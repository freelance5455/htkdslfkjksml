import { Minus, Plus, RotateCcw } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { NijoMark } from "@/components/brand/logo";
import { Button } from "@/components/ui/button";
import { useProjectStore } from "@/lib/nijo/store";

export function SettingsPanel({ onAssistant }: { onAssistant: () => void }) {
  const settings = useProjectStore((s) => s.settings);
  const setSettings = useProjectStore((s) => s.setSettings);
  const resetProject = useProjectStore((s) => s.resetProject);
  const [installEvent, setInstallEvent] = useState<BeforeInstallPromptEvent | null>(null);

  useEffect(() => {
    const onPrompt = (event: Event) => {
      event.preventDefault();
      setInstallEvent(event as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  return (
    <div className="h-full overflow-y-auto bg-bg px-4 py-5 pb-24">
      <div className="mx-auto flex max-w-lg flex-col gap-6">
        <section className="rounded-xl bg-elevated p-4 shadow-nijo">
          <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted">Editor</p>
          <div className="mt-4 flex items-center justify-between">
            <span className="text-sm">Font size</span>
            <div className="flex items-center gap-2">
              <Button
                size="icon"
                variant="secondary"
                aria-label="Smaller"
                onClick={() => setSettings({ fontSize: Math.max(12, settings.fontSize - 1) })}
              >
                <Minus className="size-4" />
              </Button>
              <span className="w-8 text-center font-mono text-sm tabular-nums">{settings.fontSize}</span>
              <Button
                size="icon"
                variant="secondary"
                aria-label="Larger"
                onClick={() => setSettings({ fontSize: Math.min(22, settings.fontSize + 1) })}
              >
                <Plus className="size-4" />
              </Button>
            </div>
          </div>
          <Toggle
            label="Light editor"
            checked={settings.theme === "light"}
            onChange={(checked) => setSettings({ theme: checked ? "light" : "dark" })}
          />
          <Toggle label="Word wrap" checked={settings.wrap} onChange={(checked) => setSettings({ wrap: checked })} />
          <Toggle
            label="Tab size 4"
            checked={settings.tabSize === 4}
            onChange={(checked) => setSettings({ tabSize: checked ? 4 : 2 })}
          />
        </section>

        <section className="rounded-xl bg-elevated p-4 shadow-nijo">
          <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted">Install</p>
          <p className="mt-2 text-sm text-muted">
            Add NIJO MOBILE to your home screen and use it like an app, even with a flaky connection.
          </p>
          <Button
            className="mt-4 w-full"
            onClick={async () => {
              if (installEvent) {
                await installEvent.prompt();
                setInstallEvent(null);
                return;
              }
              toast.message("Use your browser menu: Add to Home Screen.");
            }}
          >
            Add to Home Screen
          </Button>
        </section>

        <section className="rounded-xl bg-elevated p-4 shadow-nijo">
          <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted">Assistant</p>
          <p className="mt-2 text-sm text-muted">
            Explain, fix, or convert code. Calls are user-initiated and capped.
          </p>
          <Button className="mt-4 w-full" variant="secondary" onClick={onAssistant}>
            Open assistant
          </Button>
        </section>

        <section className="rounded-xl bg-elevated p-4 shadow-nijo">
          <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted">Project</p>
          <Button
            className="mt-4 w-full"
            variant="outline"
            onClick={() => {
              resetProject();
              toast.success("Restored the sample project.");
            }}
          >
            <RotateCcw className="size-4" /> Reset sample project
          </Button>
        </section>

        <section className="flex items-center gap-3 rounded-xl bg-elevated p-4 shadow-nijo">
          <NijoMark className="size-12" />
          <div>
            <p className="font-medium tracking-tight">NIJO MOBILE</p>
            <p className="text-sm text-muted">Code Anywhere. Build Anywhere.</p>
            <p className="mt-1 text-xs text-subtle">Developed by Bouzidi Softworks</p>
          </div>
        </section>
      </div>
    </div>
  );
}

function Toggle({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}) {
  return (
    <label className="mt-3 flex h-12 items-center justify-between gap-3">
      <span className="text-sm">{label}</span>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={`relative h-7 w-12 rounded-full transition-colors duration-150 ${
          checked ? "bg-primary" : "bg-surface shadow-nijo"
        }`}
      >
        <span
          className={`absolute top-0.5 size-6 rounded-full bg-fg transition-transform duration-150 ${
            checked ? "translate-x-5 bg-primary-fg" : "translate-x-0.5"
          }`}
        />
      </button>
    </label>
  );
}

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
}
