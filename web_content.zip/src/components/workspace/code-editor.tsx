import {
  autocompletion,
  closeBrackets,
  closeBracketsKeymap,
  completionKeymap,
} from "@codemirror/autocomplete";
import {
  defaultKeymap,
  history,
  historyKeymap,
  indentWithTab,
  redo as redoCommand,
  undo as undoCommand,
} from "@codemirror/commands";
import { bracketMatching, foldGutter, indentOnInput } from "@codemirror/language";
import { highlightSelectionMatches, searchKeymap } from "@codemirror/search";
import { EditorState, type Extension } from "@codemirror/state";
import { oneDark } from "@codemirror/theme-one-dark";
import {
  EditorView,
  highlightActiveLine,
  highlightActiveLineGutter,
  keymap,
  lineNumbers,
  placeholder,
} from "@codemirror/view";
import { forwardRef, useEffect, useImperativeHandle, useMemo, useRef, useState } from "react";
import { languageExtension } from "@/lib/nijo/languages";
import type { LanguageId } from "@/lib/nijo/types";
import { cn } from "@/lib/utils";

export interface EditorHandle {
  insert: (text: string) => void;
  undo: () => void;
  redo: () => void;
  selectAll: () => void;
  focus: () => void;
  getSelected: () => string;
  replaceSelection: (text: string) => void;
  view: () => EditorView | null;
}

interface Props {
  value: string;
  language: LanguageId;
  fontSize: number;
  wrap: boolean;
  tabSize: number;
  theme: "dark" | "light";
  onChange: (value: string) => void;
  className?: string;
}

export const CodeEditor = forwardRef<EditorHandle, Props>(function CodeEditor(
  { value, language, fontSize, wrap, tabSize, theme, onChange, className },
  ref,
) {
  const parentRef = useRef<HTMLDivElement>(null);
  const viewRef = useRef<EditorView | null>(null);
  const valueRef = useRef(value);
  const onChangeRef = useRef(onChange);
  const [ready, setReady] = useState(false);
  valueRef.current = value;
  onChangeRef.current = onChange;

  const extensions = useMemo((): Extension[] => {
    const themeExt = EditorView.theme({
      "&": {
        height: "100%",
        fontSize: `${fontSize}px`,
        backgroundColor: "transparent",
      },
      ".cm-scroller": {
        overflow: "auto",
        fontFamily: "var(--font-mono)",
        lineHeight: "1.65",
        paddingBottom: "6rem",
      },
      ".cm-content": { caretColor: theme === "dark" ? "#4d8dff" : "#2f74f0" },
      ".cm-gutters": {
        backgroundColor: "transparent",
        color: theme === "dark" ? "#6b7386" : "#8a93a3",
        border: "none",
      },
      ".cm-activeLineGutter": { backgroundColor: "transparent" },
    });

    const list: Extension[] = [
      lineNumbers(),
      highlightActiveLineGutter(),
      highlightActiveLine(),
      highlightSelectionMatches(),
      history(),
      indentOnInput(),
      bracketMatching(),
      closeBrackets(),
      autocompletion(),
      foldGutter(),
      keymap.of([
        ...closeBracketsKeymap,
        ...defaultKeymap,
        ...historyKeymap,
        ...searchKeymap,
        ...completionKeymap,
        indentWithTab,
      ]),
      EditorState.tabSize.of(tabSize),
      placeholder("Start typing, or paste code from your phone…"),
      ...languageExtension(language),
      themeExt,
      EditorView.updateListener.of((update) => {
        if (update.docChanged) {
          const next = update.state.doc.toString();
          valueRef.current = next;
          onChangeRef.current(next);
        }
      }),
    ];
    if (wrap) list.push(EditorView.lineWrapping);
    if (theme === "dark") list.push(oneDark);
    return list;
  }, [fontSize, language, tabSize, theme, wrap]);

  useEffect(() => {
    const parent = parentRef.current;
    if (!parent) return;
    const view = new EditorView({
      doc: valueRef.current,
      parent,
      extensions,
    });
    viewRef.current = view;
    setReady(true);
    return () => {
      view.destroy();
      viewRef.current = null;
    };
  }, [extensions]);

  useEffect(() => {
    const view = viewRef.current;
    if (!view) return;
    const current = view.state.doc.toString();
    if (current !== value) {
      view.dispatch({
        changes: { from: 0, to: current.length, insert: value },
      });
    }
  }, [value]);

  useImperativeHandle(ref, () => ({
    insert: (text) => {
      const view = viewRef.current;
      if (!view) return;
      const { from, to } = view.state.selection.main;
      view.dispatch({
        changes: { from, to, insert: text },
        selection: { anchor: from + text.length },
      });
      view.focus();
    },
    undo: () => {
      const view = viewRef.current;
      if (view) undoCommand(view);
    },
    redo: () => {
      const view = viewRef.current;
      if (view) redoCommand(view);
    },
    selectAll: () => {
      const view = viewRef.current;
      if (!view) return;
      view.dispatch({ selection: { anchor: 0, head: view.state.doc.length } });
      view.focus();
    },
    focus: () => viewRef.current?.focus(),
    getSelected: () => {
      const view = viewRef.current;
      if (!view) return "";
      const { from, to } = view.state.selection.main;
      return view.state.doc.sliceString(from, to);
    },
    replaceSelection: (text) => {
      const view = viewRef.current;
      if (!view) return;
      view.dispatch(view.state.replaceSelection(text));
      view.focus();
    },
    view: () => viewRef.current,
  }));

  return (
    <div className={cn("relative h-full min-h-0 bg-bg", className)}>
      {!ready && (
        <div className="absolute inset-0 flex items-center justify-center text-sm text-muted">
          Opening editor…
        </div>
      )}
      <div ref={parentRef} className="h-full min-h-0 overflow-hidden" />
    </div>
  );
});
