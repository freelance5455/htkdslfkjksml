import {
  ChevronLeft,
  FileCode2,
  FilePlus,
  Folder,
  FolderOpen,
  FolderPlus,
  ImageIcon,
  MoreHorizontal,
  Pencil,
  Trash2,
  Upload,
} from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { OPEN_ACCEPT } from "@/lib/nijo/languages";
import { useProjectStore } from "@/lib/nijo/store";
import { importZip } from "@/lib/nijo/zip";
import { baseName, parentPath } from "@/lib/utils";

export function FilesPanel() {
  const files = useProjectStore((s) => s.files);
  const folders = useProjectStore((s) => s.folders);
  const currentDir = useProjectStore((s) => s.currentDir);
  const activeFileId = useProjectStore((s) => s.activeFileId);
  const projectName = useProjectStore((s) => s.projectName);
  const setCurrentDir = useProjectStore((s) => s.setCurrentDir);
  const setActiveFile = useProjectStore((s) => s.setActiveFile);
  const createFile = useProjectStore((s) => s.createFile);
  const createFolder = useProjectStore((s) => s.createFolder);
  const renameNode = useProjectStore((s) => s.renameNode);
  const deleteNode = useProjectStore((s) => s.deleteNode);
  const openLocalText = useProjectStore((s) => s.openLocalText);
  const replaceProject = useProjectStore((s) => s.replaceProject);

  const fileInput = useRef<HTMLInputElement>(null);
  const zipInput = useRef<HTMLInputElement>(null);
  const [composer, setComposer] = useState<null | "file" | "folder">(null);
  const [draft, setDraft] = useState("");
  const [menu, setMenu] = useState<null | { path: string; folder: boolean }>(null);
  const [rename, setRename] = useState("");

  const items = useMemo(() => {
    const childFolders = folders
      .filter((folder) => parentPath(folder) === currentDir)
      .sort((a, b) => a.localeCompare(b));
    const childFiles = files
      .filter((file) => parentPath(file.path) === currentDir)
      .sort((a, b) => a.path.localeCompare(b.path));
    return { childFolders, childFiles };
  }, [files, folders, currentDir]);

  async function onPickFile(list: FileList | null) {
    if (!list?.length) return;
    const file = list[0]!;
    if (file.name.toLowerCase().endsWith(".zip")) {
      await onZip(file);
      return;
    }
    try {
      const text = await file.text();
      const error = openLocalText(file.name, text);
      if (error) toast.error(error);
      else toast.success(`Opened ${file.name}`);
    } catch {
      toast.error("Could not read that file.");
    }
  }

  async function onZip(file: File) {
    try {
      toast.message("Opening project…");
      const imported = await importZip(file);
      const error = replaceProject(imported.name, imported.files, imported.folders);
      if (error) toast.error(error);
      else toast.success(`Opened ${imported.name}`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not open ZIP.");
    }
  }

  function submitComposer() {
    const error = composer === "folder" ? createFolder(draft) : createFile(draft);
    if (error) toast.error(error);
    else setComposer(null);
    setDraft("");
  }

  return (
    <div className="flex h-full min-h-0 flex-col bg-bg">
      <div className="flex items-center gap-2 border-b border-border px-3 py-3">
        {currentDir ? (
          <button
            type="button"
            className="flex size-10 items-center justify-center rounded-md text-fg"
            onClick={() => setCurrentDir(parentPath(currentDir))}
            aria-label="Up one folder"
          >
            <ChevronLeft className="size-5" />
          </button>
        ) : (
          <FolderOpen className="size-5 text-primary" />
        )}
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium">{currentDir ? baseName(currentDir) : projectName}</p>
          <p className="truncate text-xs text-muted">{currentDir || "Project root"}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 p-3">
        <Button variant="secondary" onClick={() => { setComposer("file"); setDraft(""); }}>
          <FilePlus className="size-4" /> New file
        </Button>
        <Button variant="secondary" onClick={() => { setComposer("folder"); setDraft(""); }}>
          <FolderPlus className="size-4" /> New folder
        </Button>
        <Button variant="outline" onClick={() => fileInput.current?.click()}>
          <Upload className="size-4" /> Open file
        </Button>
        <Button variant="outline" onClick={() => zipInput.current?.click()}>
          <FolderOpen className="size-4" /> Open ZIP
        </Button>
      </div>

      <input
        ref={fileInput}
        type="file"
        accept={OPEN_ACCEPT}
        className="hidden"
        onChange={(e) => void onPickFile(e.target.files)}
      />
      <input
        ref={zipInput}
        type="file"
        accept=".zip,application/zip"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) void onZip(file);
        }}
      />

      {composer && (
        <div className="flex gap-2 px-3 pb-3">
          <Input
            autoFocus
            value={draft}
            placeholder={composer === "folder" ? "src" : "main.py"}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") submitComposer();
              if (e.key === "Escape") setComposer(null);
            }}
          />
          <Button onClick={submitComposer}>Create</Button>
        </div>
      )}

      <div className="min-h-0 flex-1 overflow-y-auto px-2 pb-6">
        {items.childFolders.length === 0 && items.childFiles.length === 0 && (
          <p className="px-3 py-10 text-center text-sm text-muted">This folder is empty.</p>
        )}
        {items.childFolders.map((folder) => (
          <div key={folder} className="flex items-center gap-1">
            <button
              type="button"
              className="flex h-12 min-w-0 flex-1 items-center gap-3 rounded-md px-3 text-left"
              onClick={() => setCurrentDir(folder)}
            >
              <Folder className="size-5 shrink-0 text-primary" />
              <span className="truncate text-sm">{baseName(folder)}</span>
            </button>
            <button
              type="button"
              className="flex size-11 items-center justify-center text-muted"
              aria-label="Folder actions"
              onClick={() => {
                setMenu({ path: folder, folder: true });
                setRename(baseName(folder));
              }}
            >
              <MoreHorizontal className="size-4" />
            </button>
          </div>
        ))}
        {items.childFiles.map((file) => (
          <div key={file.id} className="flex items-center gap-1">
            <button
              type="button"
              className={`flex h-12 min-w-0 flex-1 items-center gap-3 rounded-md px-3 text-left ${
                file.id === activeFileId ? "bg-surface" : ""
              }`}
              onClick={() => setActiveFile(file.id)}
            >
              {file.language === "image" ? (
                <ImageIcon className="size-5 shrink-0 text-muted" />
              ) : (
                <FileCode2 className="size-5 shrink-0 text-muted" />
              )}
              <span className="truncate text-sm">{baseName(file.path)}</span>
            </button>
            <button
              type="button"
              className="flex size-11 items-center justify-center text-muted"
              aria-label="File actions"
              onClick={() => {
                setMenu({ path: file.path, folder: false });
                setRename(baseName(file.path));
              }}
            >
              <MoreHorizontal className="size-4" />
            </button>
          </div>
        ))}
      </div>

      <Sheet open={!!menu} onOpenChange={(open) => !open && setMenu(null)}>
        <SheetContent title={menu?.folder ? "Folder" : "File"}>
          <div className="space-y-3 pt-1">
            <Input value={rename} onChange={(e) => setRename(e.target.value)} />
            <Button
              className="w-full"
              variant="secondary"
              onClick={() => {
                if (menu) renameNode(menu.path, rename, menu.folder);
                setMenu(null);
              }}
            >
              <Pencil className="size-4" /> Rename
            </Button>
            <Button
              className="w-full"
              variant="danger"
              onClick={() => {
                if (menu) deleteNode(menu.path, menu.folder);
                setMenu(null);
              }}
            >
              <Trash2 className="size-4" /> Delete
            </Button>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
