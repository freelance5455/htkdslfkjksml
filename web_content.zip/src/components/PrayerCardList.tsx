import React from 'react';
import { Volume2, VolumeX, Bell, BellOff, Play, Sunrise as SunriseIcon } from 'lucide-react';
import { DailySchedule, PrayerName, PrayerSettings } from '../types/prayer';
import { formatPrayerTime, calculateAlarmTime } from '../utils/prayerCalculator';

interface PrayerCardListProps {
  schedule: DailySchedule;
  settings: PrayerSettings;
  onToggleAdhan: (name: PrayerName) => void;
  onToggleAlarm: (name: PrayerName) => void;
  onPreviewAdhan: (name: PrayerName) => void;
}

interface PrayerItemConfig {
  key: PrayerName | 'sunrise';
  nameEnglish: string;
  nameArabic: string;
  nameBangla: string;
  time: string;
  isSunrise?: boolean;
}

export const PrayerCardList: React.FC<PrayerCardListProps> = ({
  schedule,
  settings,
  onToggleAdhan,
  onToggleAlarm,
  onPreviewAdhan,
}) => {
  const prayerItems: PrayerItemConfig[] = [
    {
      key: 'fajr',
      nameEnglish: 'Fajr',
      nameArabic: 'الفجر',
      nameBangla: 'ফজর',
      time: schedule.fajr,
    },
    {
      key: 'sunrise',
      nameEnglish: 'Sunrise',
      nameArabic: 'الشروق',
      nameBangla: 'সূর্যোদয়',
      time: schedule.sunrise,
      isSunrise: true,
    },
    {
      key: 'dhuhr',
      nameEnglish: 'Dhuhr',
      nameArabic: 'الظهر',
      nameBangla: 'যোহর',
      time: schedule.dhuhr,
    },
    {
      key: 'asr',
      nameEnglish: 'Asr',
      nameArabic: 'العصر',
      nameBangla: 'আসর',
      time: schedule.asr,
    },
    {
      key: 'maghrib',
      nameEnglish: 'Maghrib',
      nameArabic: 'المغرب',
      nameBangla: 'মাগরিব',
      time: schedule.maghrib,
    },
    {
      key: 'isha',
      nameEnglish: 'Isha',
      nameArabic: 'العشاء',
      nameBangla: 'এশা',
      time: schedule.isha,
    },
  ];

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-white tracking-tight">Today's Prayer Schedule & Controls</h2>
          <p className="text-xs text-slate-400">
            Adhan plays at exact time · Separate Salah alarm rings +{settings.alarmDelayMinutes}m later
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {prayerItems.map(item => {
          if (item.isSunrise) {
            // Sunrise card: purely informational
            return (
              <div
                key="sunrise"
                className="relative rounded-2xl border border-amber-900/40 bg-gradient-to-br from-amber-950/30 to-slate-900/60 p-4 transition-all"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
                      <SunriseIcon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-sm font-semibold text-white flex items-center gap-1.5">
                        {item.nameEnglish}
                        <span className="text-xs font-normal text-slate-400">({item.nameBangla})</span>
                      </h3>
                      <span className="font-arabic text-xs text-amber-300/80">{item.nameArabic}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-mono text-xl font-bold text-amber-300 tabular-nums">
                      {formatPrayerTime(item.time, settings.timeFormat)}
                    </div>
                    <div className="text-[11px] text-amber-400/80 mt-0.5">Informational Only</div>
                  </div>
                </div>
                <div className="mt-3 border-t border-amber-950/60 pt-2 text-[11px] text-slate-400">
                  Prohibited prayer window (Makruh). No Adhan or Salah alarm scheduled.
                </div>
              </div>
            );
          }

          const prayerKey = item.key as PrayerName;
          const isAdhanOn = settings.adhanEnabled[prayerKey];
          const isAlarmOn = settings.alarmEnabled[prayerKey];
          const alarmTime = calculateAlarmTime(item.time, settings.alarmDelayMinutes);

          return (
            <div
              key={prayerKey}
              className={`relative rounded-2xl border transition-all p-4 ${
                isAdhanOn || isAlarmOn
                  ? 'border-emerald-900/80 bg-slate-900/90 hover:border-emerald-700/60'
                  : 'border-slate-800 bg-slate-900/50 opacity-80'
              }`}
            >
              {/* Header: Name and Adhan Time */}
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-1.5">
                    <h3 className="text-base font-bold text-white tracking-tight">{item.nameEnglish}</h3>
                    <span className="text-xs text-slate-400">({item.nameBangla})</span>
                  </div>
                  <div className="font-arabic text-sm text-emerald-400 mt-0.5">{item.nameArabic}</div>
                </div>

                <div className="text-right">
                  <div className="font-mono text-xl font-bold text-white tabular-nums">
                    {formatPrayerTime(item.time, settings.timeFormat)}
                  </div>
                  <div className="text-[10px] uppercase font-semibold text-emerald-400 tracking-wider">
                    Adhan Time
                  </div>
                </div>
              </div>

              {/* Dynamic Salah Alarm Calculation Row */}
              <div className="mt-3.5 flex items-center justify-between rounded-xl bg-slate-950/70 border border-slate-800/80 px-3 py-2">
                <div className="flex items-center gap-2">
                  <Bell className={`w-3.5 h-3.5 ${isAlarmOn ? 'text-amber-400' : 'text-slate-500'}`} />
                  <div>
                    <div className="text-xs font-semibold text-slate-200">
                      Salah Alarm ({settings.alarmDelayMinutes > 0 ? `+${settings.alarmDelayMinutes}m` : 'At Adhan'})
                    </div>
                    <div className="text-[10px] text-slate-400">Reminder to start Salah</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-mono text-sm font-bold text-amber-300 tabular-nums">
                    {formatPrayerTime(alarmTime, settings.timeFormat)}
                  </div>
                </div>
              </div>

              {/* Toggle Controls: Independent Adhan ON/OFF & Alarm ON/OFF */}
              <div className="mt-3.5 flex items-center justify-between border-t border-slate-800/70 pt-3">
                {/* Adhan Toggle */}
                <button
                  type="button"
                  onClick={() => onToggleAdhan(prayerKey)}
                  className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-medium transition cursor-pointer ${
                    isAdhanOn
                      ? 'bg-emerald-950 border border-emerald-800 text-emerald-300 hover:bg-emerald-900/60'
                      : 'bg-slate-800/60 text-slate-400 hover:bg-slate-800'
                  }`}
                  title={`Toggle Adhan for ${item.nameEnglish}`}
                >
                  {isAdhanOn ? <Volume2 className="w-3.5 h-3.5 text-emerald-400" /> : <VolumeX className="w-3.5 h-3.5 text-slate-500" />}
                  <span>Adhan {isAdhanOn ? 'ON' : 'OFF'}</span>
                </button>

                {/* Alarm Toggle */}
                <button
                  type="button"
                  onClick={() => onToggleAlarm(prayerKey)}
                  className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-medium transition cursor-pointer ${
                    isAlarmOn
                      ? 'bg-amber-950 border border-amber-800 text-amber-300 hover:bg-amber-900/60'
                      : 'bg-slate-800/60 text-slate-400 hover:bg-slate-800'
                  }`}
                  title={`Toggle Salah Alarm for ${item.nameEnglish}`}
                >
                  {isAlarmOn ? <Bell className="w-3.5 h-3.5 text-amber-400" /> : <BellOff className="w-3.5 h-3.5 text-slate-500" />}
                  <span>Alarm {isAlarmOn ? 'ON' : 'OFF'}</span>
                </button>

                {/* Preview Adhan Audio */}
                <button
                  type="button"
                  onClick={() => onPreviewAdhan(prayerKey)}
                  className="flex h-7 w-7 items-center justify-center rounded-lg border border-slate-700 bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white transition cursor-pointer"
                  title={`Preview ${item.nameEnglish} Adhan`}
                >
                  <Play className="w-3 h-3 ml-0.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
