import React, { useState, useEffect, useRef } from 'react';
import {
  ShieldAlert,
  Mic,
  Volume2,
  Headphones,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Radio,
  Sliders,
  Cable,
  Laptop,
  Cpu,
  Layers,
  Sparkles,
} from 'lucide-react';

export const MicRoutingGuide: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'verdict' | 'hardware' | 'pc' | 'live_test'>('verdict');

  // Live Mixer Test State
  const [isMicActive, setIsMicActive] = useState(false);
  const [isMonitorOn, setIsMonitorOn] = useState(false);
  const [micVolume, setMicVolume] = useState(1.0);
  const [micLevel, setMicLevel] = useState(0);
  const [micError, setMicError] = useState<string | null>(null);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const micStreamRef = useRef<MediaStream | null>(null);
  const micGainRef = useRef<GainNode | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animFrameRef = useRef<number | null>(null);

  const startMicTest = async () => {
    try {
      setMicError(null);
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      micStreamRef.current = stream;

      const ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      audioCtxRef.current = ctx;

      const source = ctx.createMediaStreamSource(stream);
      const gain = ctx.createGain();
      gain.gain.value = micVolume;
      micGainRef.current = gain;

      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      analyserRef.current = analyser;

      source.connect(gain);
      gain.connect(analyser);

      if (isMonitorOn) {
        analyser.connect(ctx.destination);
      }

      setIsMicActive(true);

      // Meter animation loop
      const buffer = new Uint8Array(analyser.frequencyBinCount);
      const updateMeter = () => {
        if (!analyserRef.current) return;
        analyserRef.current.getByteFrequencyData(buffer);
        let sum = 0;
        for (let i = 0; i < buffer.length; i++) {
          sum += buffer[i];
        }
        const avg = sum / buffer.length;
        setMicLevel(Math.min(100, Math.round((avg / 128) * 100)));
        animFrameRef.current = requestAnimationFrame(updateMeter);
      };
      updateMeter();

    } catch (err: unknown) {
      console.error('Microphone access denied:', err);
      setMicError('মাইক্রোফোন এক্সেস পাওয়া যায়নি। ব্রাউজারে Mic Permission অনুমোদন করুন।');
      setIsMicActive(false);
    }
  };

  const stopMicTest = () => {
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach((t) => t.stop());
      micStreamRef.current = null;
    }
    if (audioCtxRef.current) {
      audioCtxRef.current.close();
      audioCtxRef.current = null;
    }
    setIsMicActive(false);
    setMicLevel(0);
  };

  const toggleMonitor = () => {
    const next = !isMonitorOn;
    setIsMonitorOn(next);
    if (audioCtxRef.current && analyserRef.current) {
      if (next) {
        analyserRef.current.connect(audioCtxRef.current.destination);
      } else {
        try {
          analyserRef.current.disconnect(audioCtxRef.current.destination);
        } catch (ignored) {}
      }
    }
  };

  useEffect(() => {
    if (micGainRef.current) {
      micGainRef.current.gain.value = micVolume;
    }
  }, [micVolume]);

  useEffect(() => {
    return () => {
      stopMicTest();
    };
  }, []);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-2xl border border-red-500/40 bg-gradient-to-r from-[#18090f] via-[#10121d] to-[#0c1626] p-6 shadow-2xl">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-red-600/30 text-red-400 border border-red-500/50">
                CRITICAL INVESTIGATION
              </span>
              <span className="text-xs text-cyan-400 font-mono">Free Fire Voice Routing</span>
            </div>
            <h2 className="font-orbitron text-2xl font-black text-white">
              Free Fire Mic + Soundboard Engineering Analysis
            </h2>
            <p className="text-sm text-slate-300 max-w-2xl mt-1">
              Android OS-এর ভেতরে কীভাবে অডিও প্রসেস হয়, কেন স্পিকার দিয়ে চালালে ফ্রি ফায়ারে কাজ করে না, এবং বাস্তবসম্মত হার্ডওয়্যার সল্যুশন।
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setActiveTab('verdict')}
              className={`px-3 py-2 rounded-xl text-xs font-chakra font-bold transition-all ${
                activeTab === 'verdict'
                  ? 'bg-red-600 text-white shadow-[0_0_15px_rgba(255,30,68,0.5)]'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
              }`}
            >
              1. Technical Verdict
            </button>
            <button
              onClick={() => setActiveTab('hardware')}
              className={`px-3 py-2 rounded-xl text-xs font-chakra font-bold transition-all ${
                activeTab === 'hardware'
                  ? 'bg-cyan-500 text-black shadow-[0_0_15px_rgba(0,229,255,0.5)]'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
              }`}
            >
              2. Mobile Hardware Fix
            </button>
            <button
              onClick={() => setActiveTab('pc')}
              className={`px-3 py-2 rounded-xl text-xs font-chakra font-bold transition-all ${
                activeTab === 'pc'
                  ? 'bg-cyan-500 text-black shadow-[0_0_15px_rgba(0,229,255,0.5)]'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
              }`}
            >
              3. PC Emulator Routing
            </button>
            <button
              onClick={() => setActiveTab('live_test')}
              className={`px-3 py-2 rounded-xl text-xs font-chakra font-bold transition-all ${
                activeTab === 'live_test'
                  ? 'bg-purple-600 text-white shadow-[0_0_15px_rgba(168,85,247,0.5)]'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
              }`}
            >
              ⚡ 4. Live Mic Mixer Simulator
            </button>
          </div>
        </div>
      </div>

      {/* Tab 1: Technical Verdict */}
      {activeTab === 'verdict' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Why Speaker Playback Fails */}
          <div className="rounded-2xl border border-red-500/30 bg-[#0f111a] p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-red-600/20 text-red-400 border border-red-500/30">
                <XCircle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-orbitron font-bold text-lg text-white">
                  স্পিকার দিয়ে ফ্রি ফায়ারে সাউন্ড যাবে না কেন?
                </h3>
                <span className="text-xs text-red-400 font-mono">Acoustic Echo Cancellation (AEC)</span>
              </div>
            </div>

            <p className="text-sm text-slate-300 leading-relaxed">
              অনেকে দাবি করেন ফোন লাউডস্পিকারে রেখে সাউন্ডবোর্ড বাজালে মাইকে সাউন্ড যাবে। <strong>এটি সম্পূর্ণ ভুল এবং বিভ্রান্তিকর!</strong>
            </p>

            <div className="space-y-2.5 text-xs text-slate-300">
              <div className="flex items-start gap-2 p-2.5 rounded-lg bg-red-950/20 border border-red-900/30">
                <span className="font-bold text-red-400 shrink-0">১. হার্ডওয়্যার AEC:</span>
                <span>Free Fire গেম <code className="text-cyan-300">VOICE_COMMUNICATION</code> অডিও স্ট্রীম ব্যবহার করে। অ্যান্ড্রয়েডের DSP চিপ স্পিকারের সাউন্ডকে ইকো (Echo) হিসেবে শনাক্ত করে মাইক ইনপুট থেকে সম্পূর্ণ ফিল্টার/বাতিল করে দেয়।</span>
              </div>
              <div className="flex items-start gap-2 p-2.5 rounded-lg bg-red-950/20 border border-red-900/30">
                <span className="font-bold text-red-400 shrink-0">২. অডিও ডাকিং (Ducking):</span>
                <span>গেমে মাইক অন থাকলে অন্য সব ব্যাকগ্রাউন্ড অ্যাপের মিডিয়া সাউন্ড অ্যান্ড্রয়েড স্বয়ংক্রিয়ভাবে ৭০-৮০% ভলিউম কমিয়ে (Duck) দেয়।</span>
              </div>
              <div className="flex items-start gap-2 p-2.5 rounded-lg bg-red-950/20 border border-red-900/30">
                <span className="font-bold text-red-400 shrink-0">৩. নয়েজ সাপ্রেশন (NS):</span>
                <span>মিউজিক বা গেম সাউন্ডকে গেমের ভয়েস সার্ভার ব্যাকগ্রাউন্ড নয়েজ হিসেবে চেপে ধরে, যার ফলে টিমমেটদের কাছে বিকৃত ও রোবোটিক শব্দ পৌঁছায়।</span>
              </div>
            </div>
          </div>

          {/* Android Security Sandbox Limitation */}
          <div className="rounded-2xl border border-cyan-500/30 bg-[#0f111a] p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-600/20 text-cyan-400 border border-cyan-500/30">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-orbitron font-bold text-lg text-white">
                  অ্যাপ কি সরাসরি Virtual Mic তৈরি করতে পারে?
                </h3>
                <span className="text-xs text-cyan-400 font-mono">SELinux & UID Security Sandbox</span>
              </div>
            </div>

            <p className="text-sm text-slate-300 leading-relaxed">
              অ্যান্ড্রয়েড আর্কিটেকচারে (Android 10 থেকে 15/16) যেকোনো সাধারণ (Unrooted) থার্ড-পার্টি অ্যাপ অন্য কোনো অ্যাপের মাইক্রোফোন ইনপুটে ডিজিটাল অডিও ইনজেক্ট করতে <strong>পারে না</strong>।
            </p>

            <div className="space-y-2.5 text-xs text-slate-300">
              <div className="flex items-start gap-2 p-2.5 rounded-lg bg-cyan-950/20 border border-cyan-900/30">
                <span className="font-bold text-cyan-400 shrink-0">গোপনীয়তা সুরক্ষা:</span>
                <span>যদি যেকোনো অ্যাপ মাইক্রোফোন স্ট্রিম দখল বা পরিবর্তন করতে পারত, তাহলে হ্যাকার অ্যাপ সহজেই ভয়েস কল স্পাইং করতে পারত। তাই গুগল কার্নেল লেভেলে এটি কঠোরভাবে ব্লক করেছে।</span>
              </div>
              <div className="flex items-start gap-2 p-2.5 rounded-lg bg-cyan-950/20 border border-cyan-900/30">
                <span className="font-bold text-cyan-400 shrink-0">বাস্তব সমাধান কী?</span>
                <span>ফোনটিতে ডিজিটাল ইনজেকশন করার বদলে, সিগন্যালটিকে <strong>অ্যানালগ/হার্ডওয়্যার লেভেলে (Audio Mixer / Splitter)</strong> মিক্স করে ফোনের মাইক জ্যাকে ইনপুট করতে হবে। অথবা পিসি এমুলেটরে ভার্চুয়াল অডিও কেবল ব্যবহার করতে হবে।</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Mobile Hardware Fix */}
      {activeTab === 'hardware' && (
        <div className="rounded-2xl border border-slate-800 bg-[#0f111a] p-6 space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
            <div>
              <h3 className="font-orbitron font-bold text-xl text-white flex items-center gap-2">
                <Cable className="w-6 h-6 text-cyan-400" />
                মোবাইলে Free Fire-এ উভয় সাউন্ড পাঠানোর সেরা ৩টি হার্ডওয়্যার সেটআপ
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                প্রফেশনাল গেমিং স্ট্রিমার এবং ইউটিউবাররা মোবাইলে যেভাবে তাদের কণ্ঠ + সাউন্ডবোর্ড টিমমেটদের শোনায়:
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* Option 1: Live Sound Card */}
            <div className="rounded-xl border border-cyan-500/40 bg-[#131625] p-5 flex flex-col justify-between space-y-4">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-500 text-black font-mono">
                  ★ RECOMMENDED
                </span>
                <h4 className="font-chakra font-bold text-lg text-white mt-2">
                  1. Live Streaming Sound Card (V8 / Fifine / K300)
                </h4>
                <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                  একটি ছোট এক্সটার্নাল লাইভ সাউন্ড কার্ড (দাম প্রায় ৫০০-১৫০০ টাকা)। এটিতে আলাদা Mic-In এবং Accompany-In থাকে।
                </p>
                <div className="mt-3 p-3 rounded-lg bg-black/40 text-xs space-y-1.5 font-mono text-cyan-300">
                  <div>1. হেডসেট মাইক ➔ Mic In</div>
                  <div>2. সাউন্ডবোর্ড ফোন ➔ Accompany In</div>
                  <div>3. আউটপুট কেবল ➔ গেমিং ফোনের Type-C/3.5mm</div>
                </div>
              </div>
              <div className="text-xs text-emerald-400 flex items-center gap-1.5 font-bold">
                <CheckCircle2 className="w-4 h-4" /> ১০০% ক্রিস্টাল ক্লিয়ার সাউন্ড টিমমেট শুনবে
              </div>
            </div>

            {/* Option 2: 3.5mm TRRS Splitter */}
            <div className="rounded-xl border border-slate-800 bg-[#131625] p-5 flex flex-col justify-between space-y-4">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-700 text-slate-300 font-mono">
                  BUDGET SETUP
                </span>
                <h4 className="font-chakra font-bold text-lg text-white mt-2">
                  2. Dual 3.5mm TRRS Audio Combiner
                </h4>
                <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                  একটি TRRS Mic/Headphone Splitter + একটি 3.5mm Aux Y-Cable (দাম মাত্র ১৫০-২৫০ টাকা)।
                </p>
                <div className="mt-3 p-3 rounded-lg bg-black/40 text-xs space-y-1.5 font-mono text-slate-300">
                  <div>1. স্প্লিটারের Mic পোর্টে Y- কেবল যুক্ত করুন</div>
                  <div>2. এক লাইনে হেডসেটের কণ্ঠ মাইক</div>
                  <div>3. অন্য লাইনে সাউন্ডবোর্ডের অডিও আউটপুট</div>
                </div>
              </div>
              <div className="text-xs text-cyan-400 flex items-center gap-1.5 font-bold">
                <CheckCircle2 className="w-4 h-4" /> অত্যন্ত কম খরচে কার্যকারী সমাধান
              </div>
            </div>

            {/* Option 3: OTG Dual-Channel USB Card */}
            <div className="rounded-xl border border-slate-800 bg-[#131625] p-5 flex flex-col justify-between space-y-4">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-700 text-slate-300 font-mono">
                  TYPE-C PHONES
                </span>
                <h4 className="font-chakra font-bold text-lg text-white mt-2">
                  3. Plextone / Boya Type-C Gaming Mixer
                </h4>
                <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                  আধুনিক ফোনে হেডফোন জ্যাক না থাকলে USB-C Gaming Audio Adapter ব্যবহার করুন যাতে চার্জিং ও ডুয়াল অডিও ইনপুট একসাথে থাকে।
                </p>
                <div className="mt-3 p-3 rounded-lg bg-black/40 text-xs space-y-1.5 font-mono text-slate-300">
                  <div>1. Type-C OTG ডকে গেমিং হেডসেট</div>
                  <div>2. সেকেন্ডারি ইনপুটে REX Soundboard</div>
                  <div>3. কোনো প্রকার ল্যাটেন্সি বা ইকো নেই</div>
                </div>
              </div>
              <div className="text-xs text-emerald-400 flex items-center gap-1.5 font-bold">
                <CheckCircle2 className="w-4 h-4" /> দ্রুত চার্জিং + গেম ভয়েস সাপোর্ট
              </div>
            </div>
          </div>

          {/* Interactive Hardware Signal Diagram */}
          <div className="rounded-xl border border-cyan-500/30 bg-black/50 p-5">
            <h4 className="font-orbitron text-sm font-bold text-cyan-400 uppercase tracking-wider mb-4 flex items-center gap-2">
              <Layers className="w-4 h-4" /> Hardware Signal Routing Architecture Diagram
            </h4>
            <div className="flex flex-col md:flex-row items-center justify-center gap-4 text-center">
              <div className="w-full md:w-44 p-3 rounded-xl bg-red-950/40 border border-red-500/50">
                <Mic className="w-6 h-6 text-red-400 mx-auto mb-1" />
                <div className="text-xs font-bold text-white">Your Voice</div>
                <div className="text-[10px] text-slate-400">Headset Microphone</div>
              </div>

              <div className="text-cyan-400 font-bold text-lg">＋</div>

              <div className="w-full md:w-44 p-3 rounded-xl bg-blue-950/40 border border-cyan-500/50">
                <Volume2 className="w-6 h-6 text-cyan-400 mx-auto mb-1" />
                <div className="text-xs font-bold text-white">REX Soundboard</div>
                <div className="text-[10px] text-slate-400">SFX / Audio Buttons</div>
              </div>

              <div className="text-cyan-400 font-bold text-lg">➔</div>

              <div className="w-full md:w-48 p-4 rounded-xl bg-purple-950/40 border border-purple-500/60 shadow-[0_0_15px_rgba(168,85,247,0.3)]">
                <Sliders className="w-6 h-6 text-purple-400 mx-auto mb-1" />
                <div className="text-xs font-bold text-white">Hardware Mixer</div>
                <div className="text-[10px] text-purple-300">Unifies into 1 Mic Line</div>
              </div>

              <div className="text-cyan-400 font-bold text-lg">➔</div>

              <div className="w-full md:w-48 p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/50">
                <Radio className="w-6 h-6 text-emerald-400 mx-auto mb-1" />
                <div className="text-xs font-bold text-white">Free Fire Lobby</div>
                <div className="text-[10px] text-emerald-300">Teammates Hear Both!</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: PC Emulator Routing */}
      {activeTab === 'pc' && (
        <div className="rounded-2xl border border-slate-800 bg-[#0f111a] p-6 space-y-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-600/20 text-cyan-400 border border-cyan-500/30">
              <Laptop className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-orbitron font-bold text-lg text-white">
                পিসিতে Free Fire (BlueStacks / LDPlayer) খেললে ১০০% ফ্রি সফটওয়্যার সল্যুশন
              </h3>
              <span className="text-xs text-cyan-400 font-mono">VB-Audio Virtual Cable + VoiceMeeter</span>
            </div>
          </div>

          <p className="text-sm text-slate-300 leading-relaxed">
            যদি আপনি কম্পিউটার বা ল্যাপটপে অ্যান্ড্রয়েড এমুলেটর (BlueStacks, LDPlayer, MSI App Player, Gameloop) দিয়ে ফ্রি ফায়ার খেলেন, তাহলে কোনো হার্ডওয়্যার কেনা লাগবে না! উইন্ডোজ ওএস ভার্চুয়াল অডিও ক্যাবল সমর্থন করে।
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
            <div className="p-4 rounded-xl bg-[#141725] border border-slate-800 space-y-2">
              <span className="text-cyan-400 font-mono font-bold text-xs">ধাপ ১:</span>
              <h5 className="font-chakra font-bold text-white text-sm">VB-Audio Cable ইন্সটল</h5>
              <p className="text-xs text-slate-400">
                বিনামূল্যে <code className="text-cyan-300">VB-Cable</code> ডাউনলোড করে ইন্সটল করুন। এটি উইন্ডোজে একটি ভার্চুয়াল মাইক্রোফোন তৈরি করবে।
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#141725] border border-slate-800 space-y-2">
              <span className="text-cyan-400 font-mono font-bold text-xs">ধাপ ২:</span>
              <h5 className="font-chakra font-bold text-white text-sm">VoiceMeeter দিয়ে মিক্স</h5>
              <p className="text-xs text-slate-400">
                VoiceMeeter Banana চালু করে Hardware Input 1 এ আপনার আসল মাইক দিন, এবং Input 2 এ REX Team সাউন্ডবোর্ড দিন।
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#141725] border border-slate-800 space-y-2">
              <span className="text-cyan-400 font-mono font-bold text-xs">ধাপ ৩:</span>
              <h5 className="font-chakra font-bold text-white text-sm">এমুলেটরে মাইক নির্বাচন</h5>
              <p className="text-xs text-slate-400">
                BlueStacks বা LDPlayer এর Settings &gt; Audio &gt; Microphone এ <code className="text-cyan-300">VoiceMeeter Output</code> সিলেক্ট করুন।
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Live Mic Mixer Simulator */}
      {activeTab === 'live_test' && (
        <div className="rounded-2xl border border-purple-500/40 bg-[#120f1c] p-6 space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-purple-900/40 pb-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-purple-600 text-white">
                  LIVE INTERACTIVE TOOL
                </span>
                <span className="text-xs text-purple-300 font-mono">Real-Time Audio Testing</span>
              </div>
              <h3 className="font-orbitron font-bold text-xl text-white">
                Live Mic + Soundboard Dual Audio Mixer Simulator
              </h3>
              <p className="text-xs text-slate-300 mt-1">
                আপনার ব্রাউজারে রিয়েল মাইক্রোফোন চালু করে সাউন্ডবোর্ডের সাথে কণ্ঠ মিক্স করে টেস্ট করুন!
              </p>
            </div>

            <div>
              {!isMicActive ? (
                <button
                  onClick={startMicTest}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-chakra font-bold text-sm shadow-[0_0_20px_rgba(168,85,247,0.5)] transition-all"
                >
                  <Mic className="w-4 h-4" /> Start Microphone Input
                </button>
              ) : (
                <button
                  onClick={stopMicTest}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-chakra font-bold text-sm shadow-[0_0_15px_rgba(255,30,68,0.5)] transition-all"
                >
                  <Mic className="w-4 h-4 animate-pulse" /> Stop Microphone
                </button>
              )}
            </div>
          </div>

          {micError && (
            <div className="p-3 rounded-xl bg-red-950/40 border border-red-500 text-xs text-red-300">
              {micError}
            </div>
          )}

          {/* Dual VU Meter Console */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Real Mic Level Meter */}
            <div className="p-5 rounded-xl bg-black/50 border border-purple-900/50 space-y-3">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-300 flex items-center gap-1.5 font-bold">
                  <Mic className="w-4 h-4 text-purple-400" /> Real-time Mic Level
                </span>
                <span className="text-purple-400 font-bold">{isMicActive ? `${micLevel}%` : 'OFF'}</span>
              </div>

              {/* Progress VU Bar */}
              <div className="h-4 w-full rounded-full bg-slate-900 border border-slate-800 overflow-hidden p-0.5">
                <div
                  className={`h-full rounded-full transition-all duration-75 ${
                    micLevel > 80 ? 'bg-red-500' : micLevel > 40 ? 'bg-purple-400' : 'bg-cyan-400'
                  }`}
                  style={{ width: `${isMicActive ? micLevel : 0}%` }}
                />
              </div>

              {/* Mic Gain Slider */}
              <div className="flex items-center gap-3 pt-2">
                <span className="text-[11px] font-mono text-slate-400">Mic Gain:</span>
                <input
                  type="range"
                  min="0"
                  max="2"
                  step="0.05"
                  value={micVolume}
                  onChange={(e) => setMicVolume(parseFloat(e.target.value))}
                  disabled={!isMicActive}
                  className="flex-1 h-1.5 bg-slate-800 rounded-lg accent-purple-400 cursor-pointer"
                />
                <span className="text-[11px] font-mono text-purple-300 w-10 text-right">
                  {Math.round(micVolume * 100)}%
                </span>
              </div>
            </div>

            {/* Combined Stream & Headphone Monitor */}
            <div className="p-5 rounded-xl bg-black/50 border border-purple-900/50 flex flex-col justify-between space-y-3">
              <div>
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-300 flex items-center gap-1.5 font-bold">
                    <Headphones className="w-4 h-4 text-cyan-400" /> Headphone Live Monitor
                  </span>
                  <button
                    onClick={toggleMonitor}
                    disabled={!isMicActive}
                    className={`px-2.5 py-1 rounded text-[11px] font-mono font-bold transition-all ${
                      isMonitorOn
                        ? 'bg-cyan-500 text-black shadow-[0_0_10px_rgba(0,229,255,0.5)]'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {isMonitorOn ? 'MONITOR ON' : 'MONITOR OFF'}
                  </button>
                </div>
                <p className="text-[11px] text-slate-400 mt-2">
                  (সতর্কতা: মনিটর অন করার আগে হেডফোন লাগিয়ে নিন যাতে ইকো ফিডব্যাক হুইসেল না দেয়।)
                </p>
              </div>

              <div className="p-3 rounded-lg bg-purple-950/30 border border-purple-800/40 text-xs text-slate-300">
                <span className="text-cyan-400 font-bold">টেস্ট করার নিয়ম:</span> মাইক অন রেখে Soundboard ট্যাবে গিয়ে যেকোনো সাউন্ড চালান। আপনি কথা বললে এবং সাউন্ড বাজালে দুটোই একই সময়ে সমন্বিত হয়ে প্লে হবে!
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
