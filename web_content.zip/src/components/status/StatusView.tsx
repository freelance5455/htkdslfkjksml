import React, { useState, useEffect, useCallback } from 'react';
import { Plus, Clock, Eye, Shield, Sparkles, Image, Type } from 'lucide-react';
import { StatusStory, getStatuses } from '../../services/statusService';
import { useAuth } from '../../contexts/AuthContext';
import { CreateStatusModal } from './CreateStatusModal';
import { StatusViewerModal } from './StatusViewerModal';
import { supabase } from '../../lib/supabase';

export const StatusView: React.FC = () => {
  const { user, profile } = useAuth();
  const [statuses, setStatuses] = useState<StatusStory[]>([]);
  const [loading, setLoading] = useState(false);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [viewerStories, setViewerStories] = useState<StatusStory[]>([]);
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const [viewerInitialIndex, setViewerInitialIndex] = useState(0);

  const loadAllStatuses = useCallback(async () => {
    if (!user) return;
    try {
      const data = await getStatuses();
      setStatuses(data);
    } catch (err) {
      console.error('Failed to load statuses:', err);
    }
  }, [user]);

  useEffect(() => {
    setLoading(true);
    loadAllStatuses().finally(() => setLoading(false));

    // Realtime subscription for status updates
    const channel = supabase
      .channel('nexa-status-channel')
      .on('broadcast', { event: 'status_updated' }, () => {
        loadAllStatuses();
      })
      .subscribe();

    return () => {
      channel.unsubscribe();
    };
  }, [loadAllStatuses]);

  const currentUserId = user?.id || '';

  // Group statuses by user
  const myStories = statuses.filter((s) => s.user_id === currentUserId);
  const friendStories = statuses.filter((s) => s.user_id !== currentUserId);

  // Group friend stories by user
  const friendsMap: Record<string, StatusStory[]> = {};
  friendStories.forEach((s) => {
    if (!friendsMap[s.user_id]) friendsMap[s.user_id] = [];
    friendsMap[s.user_id].push(s);
  });

  const friendUserIds = Object.keys(friendsMap);

  // Split into recent (has unviewed) and viewed (all viewed)
  const recentFriends: { userId: string; stories: StatusStory[] }[] = [];
  const viewedFriends: { userId: string; stories: StatusStory[] }[] = [];

  friendUserIds.forEach((uid) => {
    const list = friendsMap[uid];
    const hasUnviewed = list.some((s) => !s.views?.some((v) => v.user_id === currentUserId));
    if (hasUnviewed) {
      recentFriends.push({ userId: uid, stories: list });
    } else {
      viewedFriends.push({ userId: uid, stories: list });
    }
  });

  const openViewerFor = (storiesList: StatusStory[], startIndex = 0) => {
    setViewerStories(storiesList);
    setViewerInitialIndex(startIndex);
    setIsViewerOpen(true);
  };

  const formatTimeAgo = (dateStr: string) => {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    return `${hours}h ago`;
  };

  return (
    <div id="status-view-container" className="h-full flex flex-col bg-neutral-900 text-white overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-neutral-100 flex items-center space-x-2">
            <span>Updates</span>
            <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              24h
            </span>
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">WhatsApp-style encrypted stories</p>
        </div>

        <button
          onClick={() => setIsCreateOpen(true)}
          className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl flex items-center space-x-1.5 shadow-lg shadow-emerald-950/40 transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Post Status</span>
        </button>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {/* My Status Section */}
        <div>
          <div
            onClick={() => {
              if (myStories.length > 0) {
                openViewerFor(myStories);
              } else {
                setIsCreateOpen(true);
              }
            }}
            className="flex items-center space-x-4 p-3 rounded-2xl hover:bg-neutral-800/50 cursor-pointer transition-colors"
          >
            <div className="relative">
              <div
                className={`w-13 h-13 rounded-full overflow-hidden p-0.5 ${
                  myStories.length > 0
                    ? 'bg-gradient-to-tr from-emerald-500 to-teal-400'
                    : 'bg-neutral-800'
                }`}
              >
                <div className="w-full h-full rounded-full bg-neutral-900 overflow-hidden flex items-center justify-center font-bold text-neutral-300">
                  {profile?.avatar_url ? (
                    <img src={profile.avatar_url} alt="" className="w-full h-full object-cover" />
                  ) : (
                    profile?.display_name?.charAt(0).toUpperCase() || 'Me'
                  )}
                </div>
              </div>

              {myStories.length === 0 && (
                <div className="absolute bottom-0 right-0 w-5 h-5 rounded-full bg-emerald-500 border-2 border-neutral-900 flex items-center justify-center text-white">
                  <Plus className="w-3 h-3" />
                </div>
              )}
            </div>

            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-semibold text-white">My Status</h4>
              <p className="text-xs text-neutral-400 mt-0.5">
                {myStories.length > 0
                  ? `${myStories.length} ${myStories.length === 1 ? 'update' : 'updates'} • Tap to view`
                  : 'Tap to add status update'}
              </p>
            </div>
          </div>
        </div>

        {/* Recent Updates */}
        {recentFriends.length > 0 && (
          <div>
            <h3 className="text-xs font-bold text-emerald-400 uppercase tracking-wider px-3 mb-2">
              Recent Updates ({recentFriends.length})
            </h3>
            <div className="space-y-1">
              {recentFriends.map(({ userId, stories }) => {
                const latest = stories[stories.length - 1];
                const author = latest.user;
                return (
                  <div
                    key={userId}
                    onClick={() => openViewerFor(stories)}
                    className="flex items-center space-x-4 p-3 rounded-2xl hover:bg-neutral-800/50 cursor-pointer transition-colors"
                  >
                    <div className="w-13 h-13 rounded-full p-0.5 bg-gradient-to-tr from-emerald-500 to-cyan-400 shrink-0">
                      <div className="w-full h-full rounded-full bg-neutral-900 overflow-hidden flex items-center justify-center font-bold text-neutral-200">
                        {author.avatar_url ? (
                          <img src={author.avatar_url} alt="" className="w-full h-full object-cover" />
                        ) : (
                          author.display_name?.charAt(0).toUpperCase() || 'U'
                        )}
                      </div>
                    </div>

                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-semibold text-white truncate">
                        {author.display_name}
                      </h4>
                      <p className="text-xs text-neutral-400 mt-0.5 flex items-center space-x-1">
                        <Clock className="w-3 h-3" />
                        <span>{formatTimeAgo(latest.created_at)}</span>
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Viewed Updates */}
        {viewedFriends.length > 0 && (
          <div>
            <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider px-3 mb-2">
              Viewed Updates ({viewedFriends.length})
            </h3>
            <div className="space-y-1">
              {viewedFriends.map(({ userId, stories }) => {
                const latest = stories[stories.length - 1];
                const author = latest.user;
                return (
                  <div
                    key={userId}
                    onClick={() => openViewerFor(stories)}
                    className="flex items-center space-x-4 p-3 rounded-2xl hover:bg-neutral-800/50 cursor-pointer transition-colors opacity-80 hover:opacity-100"
                  >
                    <div className="w-13 h-13 rounded-full p-0.5 bg-neutral-700 shrink-0">
                      <div className="w-full h-full rounded-full bg-neutral-900 overflow-hidden flex items-center justify-center font-bold text-neutral-400">
                        {author.avatar_url ? (
                          <img src={author.avatar_url} alt="" className="w-full h-full object-cover" />
                        ) : (
                          author.display_name?.charAt(0).toUpperCase() || 'U'
                        )}
                      </div>
                    </div>

                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-semibold text-neutral-300 truncate">
                        {author.display_name}
                      </h4>
                      <p className="text-xs text-neutral-500 mt-0.5 flex items-center space-x-1">
                        <Clock className="w-3 h-3" />
                        <span>{formatTimeAgo(latest.created_at)}</span>
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Empty state if no friends have posted */}
        {recentFriends.length === 0 && viewedFriends.length === 0 && myStories.length === 0 && !loading && (
          <div className="p-8 text-center flex flex-col items-center justify-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-neutral-800/80 text-emerald-400 flex items-center justify-center">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-neutral-200">No status updates yet</h3>
              <p className="text-xs text-neutral-500 mt-1 max-w-xs">
                Share what's on your mind with friends. Updates disappear automatically after 24 hours.
              </p>
            </div>
            <button
              onClick={() => setIsCreateOpen(true)}
              className="mt-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-xl flex items-center space-x-1.5 shadow-md shadow-emerald-950/30 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Create Your First Status</span>
            </button>
          </div>
        )}
      </div>

      {/* Modals */}
      <CreateStatusModal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
        onCreated={() => loadAllStatuses()}
      />

      <StatusViewerModal
        isOpen={isViewerOpen}
        stories={viewerStories}
        initialIndex={viewerInitialIndex}
        onClose={() => setIsViewerOpen(false)}
        onStatusDeleted={() => loadAllStatuses()}
      />
    </div>
  );
};
