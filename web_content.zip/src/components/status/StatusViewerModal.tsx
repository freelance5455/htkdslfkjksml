import React, { useState, useEffect, useRef } from 'react';
import { X, ChevronLeft, ChevronRight, Eye, Trash2, Send, Clock, User } from 'lucide-react';
import { StatusStory, recordStatusView, deleteStatus } from '../../services/statusService';
import { sendMessage, getOrCreateDirectConversation } from '../../services/chatService';
import { useAuth } from '../../contexts/AuthContext';

type StatusViewerModalProps = {
  isOpen: boolean;
  stories: StatusStory[];
  initialIndex?: number;
  onClose: () => void;
  onStatusDeleted?: () => void;
};

export const StatusViewerModal: React.FC<StatusViewerModalProps> = ({
  isOpen,
  stories,
  initialIndex = 0,
  onClose,
  onStatusDeleted,
}) => {
  const { user } = useAuth();
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [showViewers, setShowViewers] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [isSendingReply, setIsSendingReply] = useState(false);
  const [replySentSuccess, setReplySentSuccess] = useState(false);

  const currentStory = stories[currentIndex];
  const isMyStory = currentStory && user ? currentStory.user_id === user.id : false;

  const timerRef = useRef<any>(null);

  useEffect(() => {
    setCurrentIndex(initialIndex);
    setProgress(0);
  }, [initialIndex, isOpen]);

  // Record view
  useEffect(() => {
    if (isOpen && currentStory && user && currentStory.user_id !== user.id) {
      recordStatusView(currentStory.id);
    }
  }, [isOpen, currentStory?.id, user?.id]);

  // Story progression timer (5 seconds)
  useEffect(() => {
    if (!isOpen || isPaused || showViewers || !currentStory) return;

    const interval = 50; // ms
    const step = 100 / (5000 / interval);

    timerRef.current = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          if (currentIndex < stories.length - 1) {
            setCurrentIndex((i) => i + 1);
            return 0;
          } else {
            onClose();
            return 100;
          }
        }
        return prev + step;
      });
    }, interval);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isOpen, isPaused, showViewers, currentIndex, stories.length, onClose, currentStory]);

  if (!isOpen || !currentStory) return null;

  const handlePrev = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (currentIndex > 0) {
      setCurrentIndex((i) => i - 1);
      setProgress(0);
    }
  };

  const handleNext = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (currentIndex < stories.length - 1) {
      setCurrentIndex((i) => i + 1);
      setProgress(0);
    } else {
      onClose();
    }
  };

  const handleDelete = async () => {
    if (!confirm('Delete this status update for everyone?')) return;
    try {
      await deleteStatus(currentStory.id);
      if (onStatusDeleted) onStatusDeleted();
      if (stories.length <= 1) {
        onClose();
      } else {
        handleNext();
      }
    } catch (err) {
      console.error('Failed to delete status:', err);
    }
  };

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !replyText.trim() || !currentStory.user_id) return;

    setIsSendingReply(true);
    try {
      const convId = await getOrCreateDirectConversation(currentStory.user_id);
      const content = `Replied to status: "${currentStory.content || 'Photo'}"\n\n${replyText.trim()}`;
      await sendMessage({
        conversationId: convId,
        senderId: user.id,
        content,
      });
      setReplyText('');
      setReplySentSuccess(true);
      setTimeout(() => setReplySentSuccess(false), 2000);
    } catch (err) {
      console.error('Failed to send reply to status:', err);
    } finally {
      setIsSendingReply(false);
    }
  };

  const formatTimeAgo = (dateStr: string) => {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    return `${hours}h ago`;
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 select-none"
      onMouseDown={() => setIsPaused(true)}
      onMouseUp={() => setIsPaused(false)}
      onTouchStart={() => setIsPaused(true)}
      onTouchEnd={() => setIsPaused(false)}
    >
      <div className="relative w-full max-w-md h-full md:h-[90vh] md:rounded-3xl overflow-hidden flex flex-col bg-neutral-950 border border-neutral-800 shadow-2xl">
        {/* Progress Bars */}
        <div className="absolute top-3 inset-x-3 z-30 flex items-center space-x-1.5">
          {stories.map((s, idx) => {
            let width = '0%';
            if (idx < currentIndex) width = '100%';
            else if (idx === currentIndex) width = `${progress}%`;

            return (
              <div
                key={s.id}
                className="flex-1 h-1 bg-white/20 rounded-full overflow-hidden"
              >
                <div
                  className="h-full bg-white transition-all duration-75 ease-linear rounded-full"
                  style={{ width }}
                />
              </div>
            );
          })}
        </div>

        {/* Top bar with User info & actions */}
        <div className="absolute top-7 inset-x-3 z-30 flex items-center justify-between text-white">
          <div className="flex items-center space-x-2.5">
            <div className="w-10 h-10 rounded-full overflow-hidden border border-white/20 bg-neutral-800 flex items-center justify-center font-bold">
              {currentStory.user.avatar_url ? (
                <img
                  src={currentStory.user.avatar_url}
                  alt={currentStory.user.display_name}
                  className="w-full h-full object-cover"
                />
              ) : (
                currentStory.user.display_name?.charAt(0).toUpperCase() || 'U'
              )}
            </div>
            <div>
              <h4 className="text-sm font-bold truncate">
                {isMyStory ? 'My Status' : currentStory.user.display_name}
              </h4>
              <p className="text-[11px] text-white/60 flex items-center space-x-1">
                <Clock className="w-3 h-3" />
                <span>{formatTimeAgo(currentStory.created_at)}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {isMyStory && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleDelete();
                }}
                className="p-2 text-white/70 hover:text-red-400 rounded-full hover:bg-white/10 transition-colors"
                title="Delete Status"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            )}
            <button
              onClick={(e) => {
                e.stopPropagation();
                onClose();
              }}
              className="p-2 text-white/70 hover:text-white rounded-full hover:bg-white/10 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Main Content Card */}
        <div className="flex-1 relative flex items-center justify-center overflow-hidden">
          {currentStory.media_type === 'text' ? (
            <div
              className="w-full h-full flex items-center justify-center p-8 text-center"
              style={{ backgroundColor: currentStory.background_color || '#059669' }}
            >
              <p className="text-white text-2xl md:text-3xl font-bold leading-relaxed whitespace-pre-wrap select-text drop-shadow-md">
                {currentStory.content}
              </p>
            </div>
          ) : (
            <div className="w-full h-full relative flex items-center justify-center bg-black">
              {currentStory.media_url && (
                <img
                  src={currentStory.media_url}
                  alt="Status"
                  className="w-full h-full object-contain"
                />
              )}
              {currentStory.caption && (
                <div className="absolute bottom-20 inset-x-4 p-3 bg-black/60 backdrop-blur-md rounded-2xl text-center text-white text-sm">
                  {currentStory.caption}
                </div>
              )}
            </div>
          )}

          {/* Left/Right click zones */}
          <div
            className="absolute left-0 inset-y-0 w-1/3 z-20 cursor-pointer"
            onClick={handlePrev}
          />
          <div
            className="absolute right-0 inset-y-0 w-1/3 z-20 cursor-pointer"
            onClick={handleNext}
          />
        </div>

        {/* Footer: Reply (for friends) or Viewers count (for me) */}
        <div className="absolute bottom-4 inset-x-4 z-30">
          {isMyStory ? (
            <div className="flex flex-col items-center">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowViewers(!showViewers);
                }}
                className="px-4 py-2 bg-white/20 hover:bg-white/30 backdrop-blur-md rounded-full text-white text-xs font-semibold flex items-center space-x-2 shadow-lg transition-colors cursor-pointer"
              >
                <Eye className="w-4 h-4" />
                <span>
                  {currentStory.views?.length || 0} {currentStory.views?.length === 1 ? 'view' : 'views'}
                </span>
              </button>
            </div>
          ) : (
            <form onSubmit={handleSendReply} className="flex items-center space-x-2">
              <input
                type="text"
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                placeholder="Reply to status..."
                className="flex-1 px-4 py-2.5 bg-black/60 backdrop-blur-md border border-white/20 rounded-full text-xs text-white placeholder-white/50 focus:outline-none focus:border-emerald-400"
              />
              <button
                type="submit"
                disabled={!replyText.trim() || isSendingReply}
                className="p-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white rounded-full transition-colors shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          )}

          {replySentSuccess && (
            <p className="text-center text-xs text-emerald-400 font-semibold mt-2 animate-fade-in">
              Reply sent to chat!
            </p>
          )}
        </div>

        {/* Viewers Sheet (when viewing my own status) */}
        {showViewers && (
          <div
            className="absolute inset-x-0 bottom-0 max-h-[60%] bg-neutral-900 border-t border-neutral-800 rounded-t-3xl z-40 p-5 flex flex-col shadow-2xl animate-in slide-in-from-bottom"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <h5 className="text-sm font-bold text-white flex items-center space-x-2">
                <Eye className="w-4 h-4 text-emerald-400" />
                <span>Viewed by {currentStory.views?.length || 0}</span>
              </h5>
              <button
                onClick={() => setShowViewers(false)}
                className="p-1 text-neutral-400 hover:text-white rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto mt-3 space-y-3 divide-y divide-neutral-800/40">
              {(!currentStory.views || currentStory.views.length === 0) ? (
                <p className="text-xs text-neutral-500 py-6 text-center">
                  No views yet. Friends will appear here when they view your status.
                </p>
              ) : (
                currentStory.views.map((v, i) => (
                  <div key={i} className="pt-2.5 first:pt-0 flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 rounded-full bg-neutral-800 border border-neutral-700 overflow-hidden flex items-center justify-center text-xs font-bold text-neutral-300">
                        {v.user.avatar_url ? (
                          <img src={v.user.avatar_url} alt="" className="w-full h-full object-cover" />
                        ) : (
                          v.user.display_name?.charAt(0).toUpperCase() || 'U'
                        )}
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-white">{v.user.display_name}</p>
                        <p className="text-[10px] text-neutral-500">@{v.user.username}</p>
                      </div>
                    </div>
                    <span className="text-[10px] text-neutral-400">
                      {formatTimeAgo(v.viewed_at)}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
