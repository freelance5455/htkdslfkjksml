import React, { useState, useRef } from 'react';
import { X, Image, Type, Send, Palette, Shield, Check, Loader2 } from 'lucide-react';
import { createStatus } from '../../services/statusService';
import { uploadStatusMedia } from '../../services/storageService';
import { useAuth } from '../../contexts/AuthContext';

type CreateStatusModalProps = {
  isOpen: boolean;
  onClose: () => void;
  onCreated: () => void;
};

const BG_COLORS = [
  '#059669', // Emerald
  '#7c3aed', // Violet
  '#2563eb', // Blue
  '#db2777', // Pink
  '#ea580c', // Orange
  '#0d9488', // Teal
  '#dc2626', // Red
  '#171717', // Dark Obsidian
];

export const CreateStatusModal: React.FC<CreateStatusModalProps> = ({
  isOpen,
  onClose,
  onCreated,
}) => {
  const { user } = useAuth();
  const [mode, setMode] = useState<'text' | 'image'>('text');
  const [textContent, setTextContent] = useState('');
  const [bgColor, setBgColor] = useState(BG_COLORS[0]);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [caption, setCaption] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImageFile(file);
    const reader = new FileReader();
    reader.onload = () => {
      setImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handlePost = async () => {
    if (!user) return;
    setError(null);

    if (mode === 'text' && !textContent.trim()) {
      setError('Please enter status text');
      return;
    }

    if (mode === 'image' && !imageFile && !imagePreview) {
      setError('Please select an image');
      return;
    }

    setLoading(true);
    try {
      if (mode === 'text') {
        await createStatus({
          mediaType: 'text',
          content: textContent.trim(),
          backgroundColor: bgColor,
          privacy: 'friends',
        });
      } else {
        let mediaUrl = imagePreview || '';
        if (imageFile) {
          mediaUrl = await uploadStatusMedia(user.id, imageFile, imageFile.name);
        }
        await createStatus({
          mediaType: 'image',
          mediaUrl,
          caption: caption.trim() || undefined,
          privacy: 'friends',
        });
      }

      onCreated();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to post status');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setMode('text')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-colors ${
                mode === 'text'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950/40'
                  : 'bg-neutral-800 text-neutral-400 hover:text-white'
              }`}
            >
              <Type className="w-3.5 h-3.5" />
              <span>Text Status</span>
            </button>
            <button
              onClick={() => {
                setMode('image');
                if (!imagePreview && fileInputRef.current) {
                  fileInputRef.current.click();
                }
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-colors ${
                mode === 'image'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950/40'
                  : 'bg-neutral-800 text-neutral-400 hover:text-white'
              }`}
            >
              <Image className="w-3.5 h-3.5" />
              <span>Photo Status</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-xl hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Area */}
        <div className="p-4 flex flex-col flex-1 min-h-[300px]">
          {error && (
            <div className="mb-3 p-2.5 bg-red-500/10 border border-red-500/20 rounded-xl text-xs text-red-300">
              {error}
            </div>
          )}

          {mode === 'text' ? (
            <div
              className="flex-1 rounded-2xl p-6 flex flex-col items-center justify-center transition-colors min-h-[260px]"
              style={{ backgroundColor: bgColor }}
            >
              <textarea
                value={textContent}
                onChange={(e) => setTextContent(e.target.value)}
                placeholder="Type a status..."
                maxLength={300}
                rows={4}
                className="w-full bg-transparent border-none text-white text-center text-xl font-bold placeholder-white/60 focus:outline-none resize-none leading-relaxed"
                autoFocus
              />
              <span className="text-[11px] text-white/50 self-end mt-2">
                {textContent.length}/300
              </span>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center min-h-[260px]">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageSelect}
                className="hidden"
              />
              {imagePreview ? (
                <div className="relative w-full h-64 rounded-2xl overflow-hidden bg-black/40 border border-neutral-800 group">
                  <img
                    src={imagePreview}
                    alt="Status Preview"
                    className="w-full h-full object-contain"
                  />
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute top-2 right-2 px-2.5 py-1 bg-black/60 hover:bg-black/80 text-white rounded-lg text-xs backdrop-blur-sm"
                  >
                    Change Photo
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full h-64 border-2 border-dashed border-neutral-700 hover:border-emerald-500 rounded-2xl flex flex-col items-center justify-center space-y-2 text-neutral-400 hover:text-white transition-colors"
                >
                  <Image className="w-8 h-8" />
                  <span className="text-xs font-semibold">Click to select photo</span>
                </button>
              )}

              {imagePreview && (
                <input
                  type="text"
                  value={caption}
                  onChange={(e) => setCaption(e.target.value)}
                  placeholder="Add a caption..."
                  className="w-full mt-3 px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
                />
              )}
            </div>
          )}

          {/* Color palette selector for Text mode */}
          {mode === 'text' && (
            <div className="mt-4 flex items-center justify-between">
              <div className="flex items-center space-x-1.5">
                <Palette className="w-4 h-4 text-neutral-400 mr-1" />
                {BG_COLORS.map((c) => (
                  <button
                    key={c}
                    onClick={() => setBgColor(c)}
                    className="w-6 h-6 rounded-full border border-white/20 transition-transform hover:scale-110 flex items-center justify-center"
                    style={{ backgroundColor: c }}
                  >
                    {bgColor === c && <Check className="w-3.5 h-3.5 text-white" />}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-800 flex items-center justify-between bg-neutral-950/50">
          <div className="flex items-center space-x-1.5 text-xs text-neutral-400">
            <Shield className="w-4 h-4 text-emerald-400" />
            <span>Visible to accepted friends for 24h</span>
          </div>

          <button
            onClick={handlePost}
            disabled={loading}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center space-x-2 shadow-lg shadow-emerald-950/50 transition-all cursor-pointer"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Posting...</span>
              </>
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span>Post Status</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
