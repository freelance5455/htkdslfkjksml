import React, { useState, useEffect } from 'react';
import { Calendar, Clock, CheckCircle2, AlertCircle, Plus, Trash2, X, Play, RotateCcw } from 'lucide-react';

export interface ScheduledTask {
  id: string;
  title: string;
  time: string; // HH:mm
  actionType: 'voice_briefing' | 'battery_check' | 'security_sweep' | 'hydration_ping';
  enabled: boolean;
  repeatDaily: boolean;
}

interface ScheduledTasksModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExecuteNow: (task: ScheduledTask) => void;
}

const DEFAULT_TASKS: ScheduledTask[] = [
  { id: 'task-1', title: 'Morning Briefing & Weather Report', time: '07:30', actionType: 'voice_briefing', enabled: true, repeatDaily: true },
  { id: 'task-2', title: 'Mid-Day Battery & System Check', time: '14:00', actionType: 'battery_check', enabled: true, repeatDaily: true },
  { id: 'task-3', title: 'Night Security & Cache Flush', time: '22:30', actionType: 'security_sweep', enabled: true, repeatDaily: true },
];

export const ScheduledTasksModal: React.FC<ScheduledTasksModalProps> = ({ isOpen, onClose, onExecuteNow }) => {
  const [tasks, setTasks] = useState<ScheduledTask[]>(() => {
    try {
      const saved = localStorage.getItem('jarvis_scheduled_tasks');
      if (saved) return JSON.parse(saved);
    } catch {}
    return DEFAULT_TASKS;
  });

  const [newTitle, setNewTitle] = useState('');
  const [newTime, setNewTime] = useState('08:00');
  const [newType, setNewType] = useState<ScheduledTask['actionType']>('voice_briefing');

  useEffect(() => {
    try {
      localStorage.setItem('jarvis_scheduled_tasks', JSON.stringify(tasks));
    } catch {}
  }, [tasks]);

  if (!isOpen) return null;

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const newTask: ScheduledTask = {
      id: `task-${Date.now()}`,
      title: newTitle.trim(),
      time: newTime,
      actionType: newType,
      enabled: true,
      repeatDaily: true,
    };
    setTasks(prev => [...prev, newTask]);
    setNewTitle('');
  };

  const handleToggle = (id: string) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, enabled: !t.enabled } : t));
  };

  const handleDelete = (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-gray-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-lg bg-gray-900 border border-cyan-500/40 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-gray-950/90 border-b border-cyan-500/30">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-cyan-400" />
            <h3 className="font-tech text-base tracking-wide uppercase text-cyan-100">
              SCHEDULED TASKS & ROUTINES (PARTS 14-15)
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-cyan-400 hover:bg-cyan-500/20">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 p-4 overflow-y-auto space-y-4">
          {/* Add New Task Form */}
          <form onSubmit={handleAddTask} className="p-3 bg-gray-950/80 rounded-xl border border-cyan-500/25 space-y-2">
            <div className="text-xs font-tech text-cyan-300 uppercase">Schedule New Automation</div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <input
                type="text"
                placeholder="Routine title..."
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                className="px-3 py-1.5 bg-gray-900 border border-cyan-500/30 rounded-lg text-xs text-cyan-100 focus:outline-none focus:border-cyan-400 sm:col-span-2"
                required
              />
              <input
                type="time"
                value={newTime}
                onChange={(e) => setNewTime(e.target.value)}
                className="px-3 py-1.5 bg-gray-900 border border-cyan-500/30 rounded-lg text-xs text-cyan-100 focus:outline-none focus:border-cyan-400"
                required
              />
            </div>
            <div className="flex items-center gap-2">
              <select
                value={newType}
                onChange={(e) => setNewType(e.target.value as any)}
                className="flex-1 px-3 py-1.5 bg-gray-900 border border-cyan-500/30 rounded-lg text-xs text-cyan-200 focus:outline-none"
              >
                <option value="voice_briefing">Morning Voice Briefing</option>
                <option value="battery_check">Battery & Diagnostics Sweep</option>
                <option value="security_sweep">Night Memory Clean & Sweep</option>
                <option value="hydration_ping">Hydration Reminder</option>
              </select>
              <button
                type="submit"
                className="px-4 py-1.5 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-200 border border-cyan-500/40 rounded-lg font-tech text-xs uppercase flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> Add
              </button>
            </div>
          </form>

          {/* Routine List */}
          <div className="space-y-2">
            {tasks.map(task => (
              <div
                key={task.id}
                className="p-3 rounded-xl bg-gray-950/60 border border-cyan-500/20 flex items-center justify-between hover:border-cyan-500/40 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => handleToggle(task.id)}
                    className={`p-1.5 rounded-lg border cursor-pointer ${
                      task.enabled
                        ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                        : 'bg-gray-800 border-gray-700 text-gray-500'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                  </button>
                  <div>
                    <div className={`text-sm font-semibold ${task.enabled ? 'text-cyan-100' : 'text-gray-500 line-through'}`}>
                      {task.title}
                    </div>
                    <div className="text-xs font-mono-tech text-cyan-400/80 flex items-center gap-2">
                      <Clock className="w-3 h-3 text-cyan-400" />
                      <span>{task.time}</span>
                      <span className="text-[10px] uppercase px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-400 border border-cyan-500/30">
                        {task.actionType.replace('_', ' ')}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => onExecuteNow(task)}
                    title="Execute Routine Immediately"
                    className="p-2 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/30 transition-colors cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDelete(task.id)}
                    className="p-2 rounded-lg text-red-400 hover:bg-red-500/15 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-gray-950/90 border-t border-cyan-500/20 text-[11px] text-cyan-400/70">
          Scheduled routines execute locally via internal clock evaluations and speak directly to Harman Sir.
        </div>
      </div>
    </div>
  );
};
