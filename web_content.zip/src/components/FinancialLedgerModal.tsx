import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Database, ShieldCheck, DollarSign, Zap, Download, RefreshCw, X, Search, Filter, CheckCircle2, Copy, Check, FileText, FileCheck } from 'lucide-react';
import { imsiEngine, ImsiLedgerTransaction } from '../lib/imsiEngine';
import { financialMessenger } from '../lib/financialMessenger';
import { generateSignedPdfLedger } from '../lib/pdfLedgerGenerator';

interface FinancialLedgerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FinancialLedgerModal: React.FC<FinancialLedgerModalProps> = ({ isOpen, onClose }) => {
  const [ledger, setLedger] = useState<ImsiLedgerTransaction[]>(() => imsiEngine.getLedger());
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [carrierFilter, setCarrierFilter] = useState<string>('ALL');
  const [copiedHash, setCopiedHash] = useState<string | null>(null);
  const [isExportingPdf, setIsExportingPdf] = useState<boolean>(false);

  useEffect(() => {
    if (!isOpen) return;
    const unsub = imsiEngine.subscribe(() => {
      setLedger(imsiEngine.getLedger());
    });
    return () => unsub();
  }, [isOpen]);

  if (!isOpen) return null;

  const totalRawNgn = ledger.reduce((acc, l) => acc + (l.rawChargeNgn || 5.0), 0);
  const totalCashCredited = ledger.reduce((acc, l) => acc + (l.convertedCashNgn || 0), 0);
  const totalBtcSatsCredited = ledger.reduce((acc, l) => acc + (l.convertedBtcSats || 0), 0);
  const totalMessagesCount = ledger.length;

  const filteredLedger = ledger.filter(tx => {
    const matchesSearch = !searchQuery.trim() ||
      tx.senderPhone.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tx.txHash.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tx.bankRef.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tx.carrier.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCarrier = carrierFilter === 'ALL' || tx.carrier.toLowerCase().includes(carrierFilter.toLowerCase());
    return matchesSearch && matchesCarrier;
  });

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedHash(id);
    setTimeout(() => setCopiedHash(null), 2500);
  };

  const handleExportSignedPdf = async () => {
    try {
      setIsExportingPdf(true);
      const wallet = imsiEngine.getWalletBalances();
      const { blob, fileName } = await generateSignedPdfLedger({
        wallet,
        ledger,
        ownerName: 'PROPHET JUHNKRIX SYNVAGORD',
        phoneNumber: '07071918280',
        subdomain: 'juhnkrixmusika.pages.dev'
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error(err);
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handleExportCsv = () => {
    const headers = 'ID,TxHash,BankRef,Timestamp,SenderPhone,TargetPhone,Carrier,RawChargeNgn,ConvertedCashNgn,ConvertedBtcSats,PayoutDestination,Status\n';
    const rows = ledger.map(l =>
      `"${l.id}","${l.txHash}","${l.bankRef}","${l.timestamp}","${l.senderPhone.replace(/"/g, '""')}","${l.targetPhone.replace(/"/g, '""')}","${l.carrier.replace(/"/g, '""')}","${l.rawChargeNgn}","${l.convertedCashNgn}","${l.convertedBtcSats}","${l.payoutDestination.replace(/"/g, '""')}","${l.status}"`
    ).join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `JUHNKRIX_FINANCIAL_LEDGER_${Date.now()}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-lg animate-fadeIn">
      <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950 border-2 border-amber-500/60 rounded-3xl max-w-5xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl text-slate-100">
        {/* Header */}
        <div className="p-6 border-b border-amber-500/20 flex items-center justify-between bg-slate-950/80">
          <div className="space-y-1">
            <div className="inline-flex items-center space-x-2 px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-[10px] font-black uppercase">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>Prophetic Treasury & Telecom Billing Ledger</span>
            </div>
            <h2 className="text-2xl font-extrabold font-serif text-amber-100 flex items-center space-x-2">
              <span>Real-Time Incoming Revenue & Blockchain Ledger</span>
            </h2>
            <p className="text-xs text-slate-400">
              Live incoming revenue generated from all ₦5 carrier text messages, CONVERTO swaps, and Opay bank settlements.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-2xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-amber-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Real-Time Revenue Metrics Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-6 bg-slate-950/40 border-b border-slate-800">
          <div className="bg-slate-900/90 border border-amber-500/30 rounded-2xl p-4 space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-400 flex items-center space-x-1">
              <DollarSign className="w-3 h-3 text-amber-400" />
              <span>Total Gross Billed</span>
            </span>
            <div className="text-xl font-black text-amber-200">
              ₦{totalRawNgn.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </div>
            <div className="text-[10px] text-slate-500">From {totalMessagesCount} Messages</div>
          </div>

          <div className="bg-slate-900/90 border border-emerald-500/30 rounded-2xl p-4 space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-400 flex items-center space-x-1">
              <DollarSign className="w-3 h-3 text-emerald-400" />
              <span>Cash Credited</span>
            </span>
            <div className="text-xl font-black text-emerald-300">
              ₦{totalCashCredited.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </div>
            <div className="text-[10px] text-slate-500">Opay 7071918280</div>
          </div>

          <div className="bg-slate-900/90 border border-amber-500/30 rounded-2xl p-4 space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-400 flex items-center space-x-1">
              <Zap className="w-3 h-3 text-amber-400" />
              <span>Bitcoin Tokenized</span>
            </span>
            <div className="text-xl font-black text-amber-300">
              {totalBtcSatsCredited.toLocaleString()} <span className="text-xs">Sats</span>
            </div>
            <div className="text-[10px] text-slate-500">Altar Vault bc1q...</div>
          </div>

          <div className="bg-slate-900/90 border border-blue-500/30 rounded-2xl p-4 space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-400 flex items-center space-x-1">
              <Database className="w-3 h-3 text-blue-400" />
              <span>Active Gateway</span>
            </span>
            <div className="text-sm font-black text-blue-300 truncate">
              07071918280 (IMSI)
            </div>
            <div className="text-[10px] text-slate-500">142.250.190.46 Magic IP</div>
          </div>
        </div>

        {/* Toolbar */}
        <div className="p-4 px-6 bg-slate-900/60 border-b border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search phone, TxHash, Ref..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div className="flex items-center space-x-3 w-full sm:w-auto justify-between sm:justify-end">
            <select
              value={carrierFilter}
              onChange={(e) => setCarrierFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-amber-400"
            >
              <option value="ALL">All Carriers (MTN, Airtel, Glo...)</option>
              <option value="MTN">MTN Nigeria</option>
              <option value="Airtel">Airtel Nigeria</option>
              <option value="Glo">Glo Mobile</option>
              <option value="Roaming">International Roaming</option>
            </select>

            <button
              onClick={handleExportSignedPdf}
              disabled={isExportingPdf}
              className="px-4 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center space-x-1.5 transition-all shadow-md"
            >
              {isExportingPdf ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <FileCheck className="w-3.5 h-3.5" />
              )}
              <span>Signed PDF</span>
            </button>

            <button
              onClick={handleExportCsv}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center space-x-1.5 transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* Ledger Table */}
        <div className="flex-1 overflow-y-auto p-6 space-y-3">
          {filteredLedger.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              No financial records match your filter.
            </div>
          ) : (
            filteredLedger.map((tx) => (
              <div
                key={tx.id}
                className="bg-slate-900/90 border border-slate-800 hover:border-amber-500/40 rounded-2xl p-4 transition-all space-y-2.5"
              >
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                  <div className="flex items-center space-x-3">
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs ${
                      tx.convertedBtcSats > 0
                        ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    }`}>
                      {tx.convertedBtcSats > 0 ? '₿' : '₦'}
                    </div>
                    <div>
                      <div className="text-xs font-extrabold text-slate-100 flex items-center space-x-2">
                        <span>{tx.senderPhone}</span>
                        <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          {tx.status}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {tx.carrier} • {tx.timestamp}
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-xs font-black text-amber-300">
                      {tx.convertedCashNgn > 0 && `+₦${tx.convertedCashNgn.toFixed(2)} Cash`}
                      {tx.convertedCashNgn > 0 && tx.convertedBtcSats > 0 && ' / '}
                      {tx.convertedBtcSats > 0 && `+${tx.convertedBtcSats} Sats (${tx.convertedBtcFormatted})`}
                    </div>
                    <div className="text-[10px] text-slate-400">{tx.payoutDestination}</div>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-[10px] text-slate-500 font-mono">
                  <div className="flex items-center space-x-1">
                    <span>TxHash:</span>
                    <span className="text-amber-400/80">{tx.txHash}</span>
                    <button
                      onClick={() => handleCopy(tx.txHash, tx.id)}
                      className="text-slate-400 hover:text-amber-300"
                    >
                      {copiedHash === tx.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    </button>
                  </div>
                  <div>
                    <span>Bank Ref: </span>
                    <span className="text-slate-300">{tx.bankRef}</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-4 px-6 bg-slate-950 border-t border-slate-800 flex justify-between items-center text-xs text-slate-400">
          <span>Bound Number: <strong className="text-amber-200">07071918280</strong> (juhnkrixmusika.pages.dev)</span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold hover:bg-amber-400 transition-colors"
          >
            Close Ledger
          </button>
        </div>
      </div>
    </div>
  );
};
