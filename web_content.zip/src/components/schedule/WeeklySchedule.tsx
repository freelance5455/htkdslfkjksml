import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  CalendarDays,
  Clock,
  Plus,
  Trash2,
  Edit2,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  Filter,
  Check,
} from 'lucide-react';
import { ScheduleItem, ScheduleItemType } from '../../types';
import { formatTime24to12 } from '../../utils/prayerCalculator';
import { timeToMinutes, minutesToTime } from '../../utils/smartScheduler';

const DAYS_NAMES_AR = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

export const WeeklySchedule: React.FC = () => {
  const {
    scheduleItems,
    addScheduleItem,
    updateScheduleItem,
    deleteScheduleItem,
    toggleScheduleItemCompleted,
    subjects,
    conflicts,
    redistributeUncompletedAction,
    generateSmartScheduleAction,
  } = useApp();

  const [viewMode, setViewMode] = useState<'week' | 'day' | 'timeline'>('week');
  const [selectedDay, setSelectedDay] = useState<number>(new Date().getDay());
  const [filterType, setFilterType] = useState<string>('all');

  // Modal for add / edit schedule item
  const [showItemModal, setShowItemModal] = useState(false);
  const [editingItem, setEditingItem] = useState<ScheduleItem | null>(null);

  // Form states
  const [title, setTitle] = useState('');
  const [type, setType] = useState<ScheduleItemType>('lecture');
  const [subjectId, setSubjectId] = useState<string>('');
  const [dayOfWeek, setDayOfWeek] = useState<number>(0);
  const [startTime, setStartTime] = useState('09:00');
  const [endTime, setEndTime] = useState('10:30');
  const [locationOrNotes, setLocationOrNotes] = useState('');

  // Conflict resolution action
  const [resolvingConflictMsg, setResolvingConflictMsg] = useState<string | null>(null);

  const handleOpenAddModal = (defaultDay?: number) => {
    setEditingItem(null);
    setTitle('');
    setType('lecture');
    setSubjectId(subjects[0]?.id || '');
    setDayOfWeek(defaultDay !== undefined ? defaultDay : selectedDay);
    setStartTime('09:00');
    setEndTime('10:30');
    setLocationOrNotes('');
    setShowItemModal(true);
  };

  const handleOpenEditModal = (item: ScheduleItem) => {
    setEditingItem(item);
    setTitle(item.title);
    setType(item.type);
    setSubjectId(item.subjectId || '');
    setDayOfWeek(item.dayOfWeek);
    setStartTime(item.startTime);
    setEndTime(item.endTime);
    setLocationOrNotes(item.locationOrNotes || '');
    setShowItemModal(true);
  };

  const handleSaveItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const startM = timeToMinutes(startTime);
    const endM = timeToMinutes(endTime);
    const duration = Math.max(15, endM - startM);

    if (editingItem) {
      updateScheduleItem(editingItem.id, {
        title: title.trim(),
        type,
        subjectId: type === 'personal' || type === 'break' ? undefined : subjectId,
        dayOfWeek,
        startTime,
        endTime,
        durationMinutes: duration,
        locationOrNotes: locationOrNotes.trim(),
      });
    } else {
      addScheduleItem({
        title: title.trim(),
        type,
        subjectId: type === 'personal' || type === 'break' ? undefined : subjectId,
        dayOfWeek,
        startTime,
        endTime,
        durationMinutes: duration,
        locationOrNotes: locationOrNotes.trim(),
        isCompleted: false,
      });
    }

    setShowItemModal(false);
  };

  // Quick shift time forward by 30 mins
  const handleShiftTime = (item: ScheduleItem, shiftMinutes: number) => {
    const sM = timeToMinutes(item.startTime) + shiftMinutes;
    const eM = timeToMinutes(item.endTime) + shiftMinutes;
    updateScheduleItem(item.id, {
      startTime: minutesToTime(sM),
      endTime: minutesToTime(eM),
    });
  };

  // Move item to next or previous day
  const handleMoveDay = (item: ScheduleItem, dayOffset: number) => {
    const newDay = (item.dayOfWeek + dayOffset + 7) % 7;
    updateScheduleItem(item.id, { dayOfWeek: newDay });
  };

  // Filter items
  const filteredItems = useMemo(() => {
    return scheduleItems.filter((i) => {
      if (filterType !== 'all' && i.type !== filterType) return false;
      return true;
    });
  }, [scheduleItems, filterType]);

  // Resolve conflict by moving conflicting item to the next available 1 hour gap
  const handleAutoResolveConflict = (conflictIndex: number) => {
    const conf = conflicts[conflictIndex];
    if (!conf) return;

    // Shift item B to start right after item A
    const endA = timeToMinutes(conf.itemA.endTime) + 15; // 15 min buffer
    const durationB = conf.itemB.durationMinutes;
    const newStart = minutesToTime(endA);
    const newEnd = minutesToTime(endA + durationB);

    updateScheduleItem(conf.itemB.id, {
      startTime: newStart,
      endTime: newEnd,
    });

    setResolvingConflictMsg(`تم تعديل موعد "${conf.itemB.title}" ليبدأ في ${newStart} بعد انتهاء النشاط السابق.`);
    setTimeout(() => setResolvingConflictMsg(null), 4000);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header controls & Views Switcher */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-[#1a0f18] p-5 rounded-2xl border border-rose-100 dark:border-rose-950/60 transition-colors shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <CalendarDays className="w-5 h-5 text-rose-600 dark:text-rose-400" />
            <h2 className="text-xl font-bold text-slate-900 dark:text-rose-100">
              الجدول الأسبوعي واليومي التفاعلي
            </h2>
          </div>
          <p className="text-xs text-slate-500 dark:text-rose-300/60 mt-1">
            متابعة المحاضرات والسكاشن وجلسات المذاكرة واكتشاف التعارضات الزمنية فورياً
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* View mode buttons */}
          <div className="flex items-center p-1 bg-rose-50/60 dark:bg-rose-950/40 border border-rose-200/50 dark:border-rose-900/40 rounded-xl">
            <button
              onClick={() => setViewMode('week')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                viewMode === 'week'
                  ? 'bg-white dark:bg-rose-900/80 text-rose-700 dark:text-rose-100 shadow-xs'
                  : 'text-slate-600 dark:text-rose-300/70 hover:text-rose-900'
              }`}
            >
              عرض الأسبوع
            </button>
            <button
              onClick={() => setViewMode('day')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                viewMode === 'day'
                  ? 'bg-white dark:bg-rose-900/80 text-rose-700 dark:text-rose-100 shadow-xs'
                  : 'text-slate-600 dark:text-rose-300/70 hover:text-rose-900'
              }`}
            >
              عرض اليوم
            </button>
            <button
              onClick={() => setViewMode('timeline')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                viewMode === 'timeline'
                  ? 'bg-white dark:bg-rose-900/80 text-rose-700 dark:text-rose-100 shadow-xs'
                  : 'text-slate-600 dark:text-rose-300/70 hover:text-rose-900'
              }`}
            >
              المخطط الزمني
            </button>
          </div>

          <button
            onClick={() => handleOpenAddModal()}
            className="px-3.5 py-2 text-xs font-semibold rounded-xl bg-rose-600 hover:bg-rose-700 text-white shadow-sm shadow-rose-600/25 flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة نشاط</span>
          </button>
        </div>
      </div>

      {/* Filter strip */}
      <div className="flex items-center justify-between flex-wrap gap-2 text-xs">
        <div className="flex items-center gap-1 overflow-x-auto pb-1">
          <span className="text-slate-400 pl-2">تصفية حسب:</span>
          {[
            { id: 'all', label: 'الكل' },
            { id: 'lecture', label: 'محاضرات' },
            { id: 'section', label: 'سكاشن' },
            { id: 'study', label: 'مذاكرة' },
            { id: 'break', label: 'استراحة' },
            { id: 'personal', label: 'شخصي' },
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => setFilterType(f.id)}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors whitespace-nowrap ${
                filterType === f.id
                  ? 'bg-rose-600 text-white font-semibold'
                  : 'bg-white dark:bg-[#1a0f18] text-slate-600 dark:text-rose-300/80 border border-rose-100 dark:border-rose-950/60 hover:bg-rose-50/50'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        <button
          onClick={() => redistributeUncompletedAction()}
          className="text-xs font-medium text-rose-600 dark:text-rose-400 hover:underline flex items-center gap-1"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>إعادة توزيع المهام غير المنجزة</span>
        </button>
      </div>

      {/* Conflicts Banner Alert */}
      {conflicts.length > 0 && (
        <div className="bg-amber-50 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-800 rounded-2xl p-4 text-amber-900 dark:text-amber-200 text-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 font-bold text-sm">
              <AlertTriangle className="w-5 h-5 text-amber-600 animate-pulse shrink-0" />
              <span>تنبيه: تم اكتشاف {conflicts.length} تعارض زمني في جدولك!</span>
            </div>
            <span className="text-[11px] text-amber-700 dark:text-amber-300">
              يرجى تعديل المواعيد لتفادي التداخل
            </span>
          </div>

          <div className="space-y-2">
            {conflicts.map((conf, idx) => (
              <div
                key={idx}
                className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-2.5 rounded-xl bg-white/70 dark:bg-slate-900/60 border border-amber-200 dark:border-amber-800"
              >
                <span>{conf.reason} ({DAYS_NAMES_AR[conf.itemA.dayOfWeek]})</span>
                <button
                  onClick={() => handleAutoResolveConflict(idx)}
                  className="px-3 py-1 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-semibold shrink-0 text-xs transition-colors self-start sm:self-auto"
                >
                  حل التعارض تلقائياً
                </button>
              </div>
            ))}
          </div>

          {resolvingConflictMsg && (
            <div className="text-emerald-700 dark:text-emerald-300 font-semibold text-xs">
              ✓ {resolvingConflictMsg}
            </div>
          )}
        </div>
      )}

      {/* 1. WEEK GRID VIEW */}
      {viewMode === 'week' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-7 gap-3">
          {DAYS_NAMES_AR.map((dayName, dayIndex) => {
            const dayItems = filteredItems
              .filter((i) => i.dayOfWeek === dayIndex)
              .sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime));

            const isCurrentDay = new Date().getDay() === dayIndex;

            return (
              <div
                key={dayIndex}
                className={`flex flex-col bg-white dark:bg-[#1a0f18] rounded-2xl border transition-colors min-h-[420px] ${
                  isCurrentDay
                    ? 'border-rose-500 shadow-sm ring-1 ring-rose-500/20'
                    : 'border-rose-100 dark:border-rose-950/60'
                }`}
              >
                {/* Day Header */}
                <div
                  className={`p-3 border-b flex items-center justify-between ${
                    isCurrentDay
                      ? 'bg-rose-50/80 dark:bg-rose-950/40 border-rose-200 dark:border-rose-900/60 text-rose-800 dark:text-rose-200'
                      : 'border-rose-100/60 dark:border-rose-950/60 text-slate-800 dark:text-rose-200'
                  }`}
                >
                  <div className="flex items-center gap-1.5 font-bold text-xs">
                    <span>{dayName}</span>
                    {isCurrentDay && (
                      <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-rose-600 text-white">
                        اليوم
                      </span>
                    )}
                  </div>

                  <button
                    onClick={() => handleOpenAddModal(dayIndex)}
                    className="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                    title={`إضافة نشاط ليوم ${dayName}`}
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Day Content */}
                <div className="p-2 space-y-2 flex-1 overflow-y-auto">
                  {dayItems.length === 0 ? (
                    <div className="h-full flex items-center justify-center text-[11px] text-slate-400 p-4 text-center">
                      يوم حر بدون أنشطة
                    </div>
                  ) : (
                    dayItems.map((item) => {
                      const subject = subjects.find((s) => s.id === item.subjectId);

                      return (
                        <div
                          key={item.id}
                          className={`p-2.5 rounded-xl border text-right transition-all group relative ${
                            item.isCompleted
                              ? 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 opacity-60'
                              : item.type === 'lecture'
                              ? 'bg-rose-50/70 dark:bg-rose-950/30 border-rose-200 dark:border-rose-900/60'
                              : item.type === 'section'
                              ? 'bg-pink-50/70 dark:bg-pink-950/30 border-pink-200 dark:border-pink-900/60'
                              : item.type === 'study'
                              ? 'bg-fuchsia-50/70 dark:bg-fuchsia-950/30 border-fuchsia-200 dark:border-fuchsia-900/60'
                              : item.type === 'break'
                              ? 'bg-amber-50/70 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900/60'
                              : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700'
                          }`}
                        >
                          <div className="flex items-start justify-between gap-1 mb-1">
                            <span className="text-[11px] font-mono tabular-nums font-semibold text-slate-600 dark:text-slate-300">
                              {formatTime24to12(item.startTime)}
                            </span>

                            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <button
                                onClick={() => handleOpenEditModal(item)}
                                className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                                title="تعديل"
                              >
                                <Edit2 className="w-3 h-3" />
                              </button>
                              <button
                                onClick={() => deleteScheduleItem(item.id)}
                                className="text-slate-400 hover:text-rose-600"
                                title="حذف"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5 mb-1">
                            <button
                              onClick={() => toggleScheduleItemCompleted(item.id)}
                              className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 transition-colors ${
                                item.isCompleted
                                  ? 'bg-rose-600 border-rose-600 text-white'
                                  : 'border-slate-300 dark:border-slate-600'
                              }`}
                            >
                              {item.isCompleted && <Check className="w-3 h-3" />}
                            </button>
                            <h5
                              className={`text-xs font-bold leading-snug line-clamp-2 ${
                                item.isCompleted
                                  ? 'line-through text-slate-400'
                                  : 'text-slate-900 dark:text-rose-100'
                              }`}
                            >
                              {item.title}
                            </h5>
                          </div>

                          {subject && (
                            <div
                              className="text-[10px] font-medium truncate"
                              style={{ color: subject.color }}
                            >
                              {subject.code}
                            </div>
                          )}

                          {/* Quick Day Shifters */}
                          <div className="flex items-center justify-between pt-1 mt-1 border-t border-slate-200/50 dark:border-slate-700/50 text-[10px] text-slate-400">
                            <span>{item.durationMinutes} د</span>
                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => handleMoveDay(item, -1)}
                                className="hover:text-slate-700 dark:hover:text-slate-200 p-0.5"
                                title="نقل لليوم السابق"
                              >
                                →
                              </button>
                              <button
                                onClick={() => handleMoveDay(item, 1)}
                                className="hover:text-slate-700 dark:hover:text-slate-200 p-0.5"
                                title="نقل لليوم التالي"
                              >
                                ←
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 2. DAY VIEW */}
      {viewMode === 'day' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6">
          {/* Day Selector */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 mb-6">
            <button
              onClick={() => setSelectedDay((selectedDay - 1 + 7) % 7)}
              className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold flex items-center gap-1"
            >
              <ChevronRight className="w-4 h-4" />
              <span>اليوم السابق</span>
            </button>

            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              جدول يوم {DAYS_NAMES_AR[selectedDay]}
            </h3>

            <button
              onClick={() => setSelectedDay((selectedDay + 1) % 7)}
              className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold flex items-center gap-1"
            >
              <span>اليوم التالي</span>
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>

          {/* Items on selected day */}
          <div className="space-y-3">
            {filteredItems.filter((i) => i.dayOfWeek === selectedDay).length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-sm">
                لا توجد التزامات مجدولة لهذا اليوم
              </div>
            ) : (
              filteredItems
                .filter((i) => i.dayOfWeek === selectedDay)
                .sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime))
                .map((item) => {
                  const subject = subjects.find((s) => s.id === item.subjectId);

                  return (
                    <div
                      key={item.id}
                      className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all ${
                        item.isCompleted
                          ? 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 opacity-70'
                          : 'bg-white dark:bg-slate-800/60 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => toggleScheduleItemCompleted(item.id)}
                          className={`w-6 h-6 rounded-lg border flex items-center justify-center transition-colors ${
                            item.isCompleted
                              ? 'bg-emerald-600 border-emerald-600 text-white'
                              : 'border-slate-300 dark:border-slate-600'
                          }`}
                        >
                          {item.isCompleted && <CheckCircle2 className="w-4 h-4" />}
                        </button>

                        <div>
                          <div className="flex items-center gap-2">
                            <span
                              className={`text-sm font-bold ${
                                item.isCompleted
                                  ? 'line-through text-slate-400'
                                  : 'text-slate-900 dark:text-slate-100'
                              }`}
                            >
                              {item.title}
                            </span>
                            <span className="text-xs px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 font-medium">
                              {item.type === 'lecture'
                                ? 'محاضرة'
                                : item.type === 'section'
                                ? 'سكشن'
                                : item.type === 'study'
                                ? 'مذاكرة'
                                : item.type === 'break'
                                ? 'استراحة'
                                : 'شخصي'}
                            </span>
                          </div>

                          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-1">
                            <span className="font-mono tabular-nums font-semibold">
                              {formatTime24to12(item.startTime)} - {formatTime24to12(item.endTime)}
                            </span>
                            <span>·</span>
                            <span>{item.durationMinutes} دقيقة</span>
                            {subject && (
                              <>
                                <span>·</span>
                                <span style={{ color: subject.color }} className="font-semibold">
                                  {subject.name}
                                </span>
                              </>
                            )}
                            {item.locationOrNotes && (
                              <>
                                <span>·</span>
                                <span>{item.locationOrNotes}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Quick controls */}
                      <div className="flex items-center gap-2 self-end sm:self-auto">
                        <button
                          onClick={() => handleShiftTime(item, 30)}
                          className="px-2.5 py-1 text-xs rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300"
                          title="تأخير 30 دقيقة"
                        >
                          +30 دقيقة
                        </button>
                        <button
                          onClick={() => handleOpenEditModal(item)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => deleteScheduleItem(item.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })
            )}
          </div>
        </div>
      )}

      {/* 3. TIMELINE VIEW */}
      {viewMode === 'timeline' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-6">
          <h3 className="font-bold text-base text-slate-900 dark:text-white pb-3 border-b border-slate-100 dark:border-slate-800">
            المخطط الزمني الشامل للأسبوع (Timeline View)
          </h3>

          <div className="space-y-6">
            {DAYS_NAMES_AR.map((dayName, dayIndex) => {
              const dayItems = filteredItems
                .filter((i) => i.dayOfWeek === dayIndex)
                .sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime));

              if (dayItems.length === 0) return null;

              return (
                <div key={dayIndex} className="space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                    <span>{dayName}</span>
                    <span className="text-slate-400 font-normal">({dayItems.length} أنشطة)</span>
                  </div>

                  <div className="border-r-2 border-slate-200 dark:border-slate-800 mr-1 pr-4 space-y-2.5">
                    {dayItems.map((item) => (
                      <div
                        key={item.id}
                        className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 flex items-center justify-between"
                      >
                        <div>
                          <div className="font-semibold text-xs text-slate-900 dark:text-slate-100">
                            {item.title}
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                            {formatTime24to12(item.startTime)} إلى {formatTime24to12(item.endTime)}
                          </div>
                        </div>

                        <span
                          className={`text-xs px-2.5 py-0.5 rounded-full ${
                            item.isCompleted
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-300'
                          }`}
                        >
                          {item.isCompleted ? 'مكتمل' : 'قيد الانتظار'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Add / Edit Schedule Item Modal */}
      {showItemModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 max-h-[90vh] overflow-y-auto">
            <h3 className="font-bold text-base text-slate-900 dark:text-white mb-4">
              {editingItem ? 'تعديل النشاط في الجدول' : 'إضافة نشاط جديد إلى الجدول'}
            </h3>

            <form onSubmit={handleSaveItem} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  عنوان النشاط *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="مثال: محاضرة الذكاء الاصطناعي"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    نوع النشاط
                  </label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as ScheduleItemType)}
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    <option value="lecture">محاضرة جامعية</option>
                    <option value="section">سكشن عملي</option>
                    <option value="study">جلسة مذاكرة</option>
                    <option value="break">استراحة / رياضة</option>
                    <option value="personal">التزام شخصي</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    المادة المرتبطة
                  </label>
                  <select
                    value={subjectId}
                    onChange={(e) => setSubjectId(e.target.value)}
                    disabled={type === 'personal' || type === 'break'}
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white disabled:opacity-50"
                  >
                    <option value="">بدون مادة</option>
                    {subjects.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.code})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  اليوم
                </label>
                <select
                  value={dayOfWeek}
                  onChange={(e) => setDayOfWeek(Number(e.target.value))}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  {DAYS_NAMES_AR.map((name, idx) => (
                    <option key={idx} value={idx}>
                      {name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    وقت البداية
                  </label>
                  <input
                    type="time"
                    required
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    وقت النهاية
                  </label>
                  <input
                    type="time"
                    required
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  المكان أو الملاحظات
                </label>
                <input
                  type="text"
                  value={locationOrNotes}
                  onChange={(e) => setLocationOrNotes(e.target.value)}
                  placeholder="مثال: مدرج 3 - مبنى الهندسة"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowItemModal(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-400"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors"
                >
                  {editingItem ? 'حفظ التعديلات' : 'إضافة للجدول'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
