import React, { useRef, useState, useEffect } from 'react';
import { X, RotateCcw, Check, Sparkles, Volume2, Palette } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sound } from '../utils/sound';

interface TracingCanvasModalProps {
  isOpen: boolean;
  onClose: () => void;
  target: {
    letter: string;
    name: string;
    example: string;
  } | null;
  childName: string;
  onComplete: () => void;
}

export const TracingCanvasModal: React.FC<TracingCanvasModalProps> = ({
  isOpen,
  onClose,
  target,
  childName,
  onComplete,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [brushColor, setBrushColor] = useState('#f59e0b');
  const [brushWidth, setBrushWidth] = useState(14);

  const colors = [
    { label: 'Amber', hex: '#f59e0b' },
    { label: 'Rose', hex: '#f43f5e' },
    { label: 'Sky', hex: '#0284c7' },
    { label: 'Emerald', hex: '#10b981' },
    { label: 'Purple', hex: '#8b5cf6' },
    { label: 'Dark', hex: '#1e293b' },
  ];

  useEffect(() => {
    if (isOpen && canvasRef.current) {
      clearCanvas();
    }
  }, [isOpen, target]);

  if (!isOpen || !target) return null;

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    setIsDrawing(true);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;

    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.strokeStyle = brushColor;
    ctx.lineWidth = brushWidth;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;

    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const handleFinish = () => {
    sound.playSuccessSound();
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });
    onComplete();
    setTimeout(() => {
      onClose();
    }, 1200);
  };

  const handleSpeak = () => {
    sound.speakText(`${target.letter}! ${target.name}! ${target.example}`, 'ur');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg flex flex-col overflow-hidden border-4 border-amber-300">
        {/* Header */}
        <div className="bg-gradient-to-r from-amber-400 via-orange-400 to-amber-500 p-4 text-white flex items-center justify-between">
          <div>
            <h3 className="font-urdu text-lg font-bold flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-yellow-200" />
              <span>لکھائی تختی: {target.name}</span>
            </h3>
            <p className="text-xs text-amber-100">
              پیارے {childName}! انگلی یا ماؤس سے لکیر کے اوپر ٹریس کریں!
            </p>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Tracing Area */}
        <div className="p-4 flex flex-col items-center">
          <div className="relative w-full aspect-square max-w-[340px] rounded-3xl bg-slate-900 shadow-inner overflow-hidden border-4 border-amber-400 flex items-center justify-center select-none touch-none">
            {/* Background Watermark Letter for Tracing */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none">
              <span className="font-urdu text-[160px] sm:text-[180px] font-black text-white/20 select-none">
                {target.letter}
              </span>
            </div>

            {/* Drawing Canvas */}
            <canvas
              ref={canvasRef}
              width={340}
              height={340}
              onMouseDown={startDrawing}
              onMouseMove={draw}
              onMouseUp={stopDrawing}
              onMouseLeave={stopDrawing}
              onTouchStart={startDrawing}
              onTouchMove={draw}
              onTouchEnd={stopDrawing}
              className="absolute inset-0 w-full h-full cursor-crosshair z-10"
            />
          </div>

          {/* Color & Tool Palette */}
          <div className="w-full max-w-[340px] mt-4 flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-2xl">
              {colors.map((c) => (
                <button
                  key={c.hex}
                  onClick={() => setBrushColor(c.hex)}
                  className={`w-7 h-7 rounded-xl transition-all cursor-pointer ${
                    brushColor === c.hex ? 'scale-115 ring-2 ring-amber-500 shadow' : 'hover:scale-105'
                  }`}
                  style={{ backgroundColor: c.hex }}
                  title={c.label}
                />
              ))}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={clearCanvas}
                className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition-all cursor-pointer"
                title="صاف کریں (Clear)"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              <button
                onClick={handleSpeak}
                className="p-2 bg-amber-100 hover:bg-amber-200 text-amber-800 rounded-xl transition-all cursor-pointer"
                title="آواز سنیں (Listen)"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-amber-50/70 border-t border-amber-100 flex items-center justify-between">
          <span className="font-urdu text-xs text-amber-900 font-bold">
            شاباش! لکھنے کے بعد ٹک دبائیں ⭐
          </span>

          <button
            onClick={handleFinish}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold rounded-2xl text-xs sm:text-sm transition-all shadow-md flex items-center gap-2 cursor-pointer"
          >
            <Check className="w-4 h-4 text-emerald-200" />
            <span>مکمل ہوا (Done!)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
