/**
 * GODEX Phase 1 - Left Sidebar Panel with Project Intelligence Views
 * Supports Explorer, Workspace Search, Symbols Navigator, Dependency Inspector, Memory, and Git Snapshots.
 */

import React, { useState, useEffect } from 'react';
import { 
  FolderTree, 
  Search, 
  Layers, 
  Database, 
  GitBranch, 
  ShieldCheck, 
  FileCode, 
  Folder, 
  FolderOpen, 
  Plus, 
  Trash2, 
  Edit3, 
  ChevronRight, 
  ChevronDown, 
  Sparkles,
  FilePlus,
  RefreshCw,
  Clock,
  ShieldAlert,
  ArrowRight,
  Code,
  Package,
  Boxes,
  Compass,
  CheckCircle2,
  FolderArchive,
  Download
} from 'lucide-react';
import { SidebarViewId, VerificationReport, Checkpoint } from '../types';
import { ProjectIntelligence } from '../intelligence/intelligenceEngine';
import { ProjectIntelligenceState, SymbolKind } from '../intelligence/types';

interface GodexSidebarPanelProps {
  activeView: SidebarViewId | null;
  files: Record<string, string>;
  activeFile: string;
  onSelectFile: (path: string) => void;
  onCreateFile: (path: string) => void;
  onDeleteFile: (path: string) => void;
  onRenameFile: (oldPath: string, newPath: string) => void;
  onOpenTemplates: () => void;
  onOpenImportProject?: () => void;
  onOpenExportProject?: () => void;
  verificationReport: VerificationReport | null;
  checkpoints: Checkpoint[];
  onOpenCheckpoints: () => void;
  onOpenMemory: () => void;
  onRunVerification: () => void;
}

export const GodexSidebarPanel: React.FC<GodexSidebarPanelProps> = ({
  activeView,
  files,
  activeFile,
  onSelectFile,
  onCreateFile,
  onDeleteFile,
  onRenameFile,
  onOpenTemplates,
  onOpenImportProject,
  onOpenExportProject,
  verificationReport,
  checkpoints,
  onOpenCheckpoints,
  onOpenMemory,
  onRunVerification
}) => {
  const [intelState, setIntelState] = useState<ProjectIntelligenceState>(ProjectIntelligence.getState());

  useEffect(() => {
    const unsub = ProjectIntelligence.subscribe(state => {
      setIntelState(state);
    });
    return unsub;
  }, []);

  // Explorer search / filter state
  const [filterQuery, setFilterQuery] = useState('');
  const [globalSearchQuery, setGlobalSearchQuery] = useState('');
  const [symbolSearchQuery, setSymbolSearchQuery] = useState('');
  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({
    'src': true,
    'src/components': true,
    'src/services': true,
    'src/intelligence': true,
    'src/templates': true
  });
  const [newFileInputPath, setNewFileInputPath] = useState('');
  const [isCreatingFile, setIsCreatingFile] = useState(false);
  const [editingFile, setEditingFile] = useState<string | null>(null);
  const [renameInputValue, setRenameInputValue] = useState('');

  if (!activeView) return null;

  // Build hierarchical folder tree
  const buildFileTree = () => {
    const root: any = { files: [], dirs: {} };
    const allPaths = Object.keys(files).sort();

    for (const path of allPaths) {
      if (filterQuery && !path.toLowerCase().includes(filterQuery.toLowerCase())) {
        continue;
      }
      const parts = path.split('/');
      let current = root;
      for (let i = 0; i < parts.length - 1; i++) {
        const dirName = parts[i];
        if (!current.dirs[dirName]) {
          current.dirs[dirName] = { name: dirName, path: parts.slice(0, i + 1).join('/'), files: [], dirs: {} };
        }
        current = current.dirs[dirName];
      }
      current.files.push({ name: parts[parts.length - 1], path });
    }
    return root;
  };

  const toggleFolder = (folderPath: string) => {
    setExpandedFolders(prev => ({
      ...prev,
      [folderPath]: !prev[folderPath]
    }));
  };

  const handleStartCreate = () => {
    setIsCreatingFile(true);
    setNewFileInputPath('src/components/NewComponent.tsx');
  };

  const handleConfirmCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (newFileInputPath.trim()) {
      onCreateFile(newFileInputPath.trim());
      setIsCreatingFile(false);
      setNewFileInputPath('');
    }
  };

  const handleStartRename = (path: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingFile(path);
    setRenameInputValue(path);
  };

  const handleConfirmRename = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingFile && renameInputValue.trim() && editingFile !== renameInputValue.trim()) {
      onRenameFile(editingFile, renameInputValue.trim());
    }
    setEditingFile(null);
  };

  // Perform real global content search
  const performSearch = () => {
    if (!globalSearchQuery.trim()) return [];
    const results: Array<{ path: string; line: number; text: string }> = [];
    const q = globalSearchQuery.toLowerCase();

    for (const [path, content] of Object.entries(files)) {
      const lines = ((content as string) || '').split('\n');
      lines.forEach((line, idx) => {
        if (line.toLowerCase().includes(q)) {
          results.push({ path, line: idx + 1, text: line.trim() });
        }
      });
    }
    return results;
  };

  // Filter symbols
  const allSymbols = Object.values(intelState.files).flatMap((f: any) => f.symbols || []);
  const filteredSymbols = symbolSearchQuery.trim()
    ? allSymbols.filter(s => s.name.toLowerCase().includes(symbolSearchQuery.toLowerCase()) || s.filePath.toLowerCase().includes(symbolSearchQuery.toLowerCase()))
    : allSymbols;

  const searchResults = performSearch();

  // Recursive Tree Renderer
  const renderTree = (node: any, currentPath = '') => {
    return (
      <div className="space-y-0.5">
        {/* Directories */}
        {Object.values(node.dirs || {}).map((dir: any) => {
          const isExpanded = expandedFolders[dir.path] ?? true;
          return (
            <div key={dir.path} className="select-none">
              <div
                onClick={() => toggleFolder(dir.path)}
                className="flex items-center gap-1.5 px-2 py-1 rounded hover:bg-[#131824] text-neutral-300 cursor-pointer text-xs font-mono group"
              >
                {isExpanded ? (
                  <ChevronDown className="w-3 h-3 text-neutral-500" />
                ) : (
                  <ChevronRight className="w-3 h-3 text-neutral-500" />
                )}
                {isExpanded ? (
                  <FolderOpen className="w-3.5 h-3.5 text-cyan-400" />
                ) : (
                  <Folder className="w-3.5 h-3.5 text-cyan-500/70" />
                )}
                <span className="truncate font-medium">{dir.name}</span>
              </div>

              {isExpanded && (
                <div className="pl-3 border-l border-[#19202E] ml-2 mt-0.5">
                  {renderTree(dir, dir.path)}
                </div>
              )}
            </div>
          );
        })}

        {/* Files */}
        {node.files?.map((file: any) => {
          const isActive = activeFile === file.path;
          const isRenaming = editingFile === file.path;
          const intelFile = intelState.files[file.path];

          if (isRenaming) {
            return (
              <form key={file.path} onSubmit={handleConfirmRename} className="px-2 py-1">
                <input
                  type="text"
                  autoFocus
                  value={renameInputValue}
                  onChange={e => setRenameInputValue(e.target.value)}
                  onBlur={() => setEditingFile(null)}
                  className="w-full bg-[#151D2C] border border-cyan-500 text-xs font-mono text-cyan-200 px-1.5 py-0.5 rounded outline-none"
                />
              </form>
            );
          }

          return (
            <div
              key={file.path}
              onClick={() => onSelectFile(file.path)}
              className={`flex items-center justify-between px-2 py-1 rounded cursor-pointer text-xs font-mono transition-colors group ${
                isActive
                  ? 'bg-[#151D2C] text-cyan-300 border border-[#233148] font-semibold'
                  : 'text-neutral-300 hover:bg-[#10141F] hover:text-white border border-transparent'
              }`}
            >
              <div className="flex items-center gap-1.5 min-w-0">
                <FileCode className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-cyan-400' : 'text-neutral-400'}`} />
                <span className="truncate">{file.name}</span>
              </div>

              <div className="flex items-center gap-1.5">
                {intelFile && intelFile.symbols.length > 0 && (
                  <span className="text-[9px] px-1 rounded bg-[#131926] text-cyan-400 group-hover:hidden">
                    {intelFile.symbols.length}
                  </span>
                )}
                <div className="hidden group-hover:flex items-center gap-1">
                  <button
                    onClick={(e) => handleStartRename(file.path, e)}
                    className="p-0.5 rounded hover:bg-[#1F293D] text-neutral-400 hover:text-neutral-200"
                    title="Rename"
                  >
                    <Edit3 className="w-3 h-3" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteFile(file.path);
                    }}
                    className="p-0.5 rounded hover:bg-rose-950/70 text-neutral-400 hover:text-rose-400"
                    title="Delete"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  const fileTree = buildFileTree();
  const fileCount = Object.keys(files).length;
  const totalChars = (Object.values(files) as string[]).reduce((acc: number, str: string) => acc + (str ? str.length : 0), 0);

  return (
    <div className="w-64 md:w-72 h-full bg-[#090B10] border-r border-[#1C2230] flex flex-col shrink-0 select-none overflow-hidden font-sans">
      {/* ----------------- EXPLORER VIEW ----------------- */}
      {activeView === 'explorer' && (
        <>
          {/* Header */}
          <div className="h-10 border-b border-[#1C2230] bg-[#0C0F16] px-3 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2">
              <FolderTree className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-200">PROJECT FILES</span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#131824] text-neutral-400 border border-[#1E2536]">
                {fileCount}
              </span>
            </div>

            <div className="flex items-center gap-1">
              {onOpenImportProject && (
                <button
                  onClick={onOpenImportProject}
                  className="p-1 rounded hover:bg-[#161C2A] text-neutral-400 hover:text-cyan-300 transition-colors"
                  title="Import Project (ZIP Archive)"
                >
                  <FolderArchive className="w-3.5 h-3.5" />
                </button>
              )}
              {onOpenExportProject && (
                <button
                  onClick={onOpenExportProject}
                  className="p-1 rounded hover:bg-[#161C2A] text-neutral-400 hover:text-cyan-300 transition-colors"
                  title="Export Project (ZIP Archive)"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
              )}
              <button
                onClick={handleStartCreate}
                className="p-1 rounded hover:bg-[#161C2A] text-neutral-400 hover:text-cyan-300 transition-colors"
                title="New Source File"
              >
                <FilePlus className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={onOpenTemplates}
                className="p-1 rounded hover:bg-[#161C2A] text-neutral-400 hover:text-cyan-300 transition-colors"
                title="Switch Starter Template"
              >
                <Sparkles className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Quick Filter */}
          <div className="p-2 border-b border-[#181E2C] bg-[#0A0D14]">
            <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-[#0E121B] border border-[#1C2333] text-xs font-mono">
              <Search className="w-3 h-3 text-neutral-500 shrink-0" />
              <input
                type="text"
                placeholder="Filter files..."
                value={filterQuery}
                onChange={e => setFilterQuery(e.target.value)}
                className="w-full bg-transparent text-neutral-200 placeholder-neutral-600 focus:outline-none text-xs"
              />
            </div>
          </div>

          {/* New file input form */}
          {isCreatingFile && (
            <form onSubmit={handleConfirmCreate} className="p-2 border-b border-[#1C2436] bg-[#0E1420]">
              <div className="text-[11px] font-mono text-cyan-300 mb-1">Enter path:</div>
              <div className="flex items-center gap-1">
                <input
                  type="text"
                  autoFocus
                  value={newFileInputPath}
                  onChange={e => setNewFileInputPath(e.target.value)}
                  placeholder="e.g. src/components/Header.tsx"
                  className="flex-1 bg-[#131A26] border border-cyan-500 text-xs font-mono text-cyan-100 px-2 py-1 rounded outline-none"
                />
                <button
                  type="submit"
                  className="px-2 py-1 rounded bg-cyan-600 text-white text-xs font-mono hover:bg-cyan-500"
                >
                  Create
                </button>
              </div>
            </form>
          )}

          {/* Tree Scroll Area */}
          <div className="flex-1 overflow-y-auto p-2">
            {renderTree(fileTree)}
          </div>

          {/* Bottom stats summary */}
          <div className="p-2 border-t border-[#181E2C] bg-[#080A0E] text-[10px] font-mono text-neutral-500 flex items-center justify-between">
            <span>{intelState.health.totalSymbols} Indexed Symbols</span>
            <span className="text-cyan-400">Phase 1</span>
          </div>
        </>
      )}

      {/* ----------------- SYMBOLS VIEW ----------------- */}
      {activeView === 'symbols' && (
        <>
          <div className="h-10 border-b border-[#1C2230] bg-[#0C0F16] px-3 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-200">SYMBOLS NAVIGATOR</span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#131824] text-cyan-400 border border-[#1E2536]">
                {allSymbols.length}
              </span>
            </div>
          </div>

          <div className="p-2.5 border-b border-[#181E2C] bg-[#0A0D14]">
            <input
              type="text"
              autoFocus
              placeholder="Search components, hooks, types..."
              value={symbolSearchQuery}
              onChange={e => setSymbolSearchQuery(e.target.value)}
              className="w-full bg-[#0E121B] border border-[#1E2536] focus:border-cyan-500/80 rounded px-2.5 py-1.5 text-xs text-neutral-100 placeholder-neutral-500 outline-none font-mono"
            />
          </div>

          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {filteredSymbols.length === 0 ? (
              <div className="p-4 text-center text-xs text-neutral-500">
                No symbols found matching "{symbolSearchQuery}".
              </div>
            ) : (
              filteredSymbols.map(sym => (
                <div
                  key={sym.id}
                  onClick={() => onSelectFile(sym.filePath)}
                  className="p-2 rounded bg-[#0B0F17] hover:bg-[#121826] border border-[#182030] hover:border-cyan-500/40 cursor-pointer transition-colors group"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white group-hover:text-cyan-300 font-mono truncate">
                      {sym.name}
                    </span>
                    <span className="text-[9px] font-mono uppercase px-1.5 py-0.2 rounded bg-[#162032] text-cyan-400 border border-cyan-800/40">
                      {sym.kind}
                    </span>
                  </div>
                  <div className="text-[10px] font-mono text-neutral-500 truncate mt-0.5">
                    {sym.filePath}:{sym.line}
                  </div>
                </div>
              ))
            )}
          </div>
        </>
      )}

      {/* ----------------- DEPENDENCIES VIEW ----------------- */}
      {activeView === 'dependencies' && (
        <>
          <div className="h-10 border-b border-[#1C2230] bg-[#0C0F16] px-3 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2">
              <Package className="w-4 h-4 text-blue-400" />
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-200">DEPENDENCIES</span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#131824] text-blue-400 border border-[#1E2536]">
                {Object.keys(intelState.dependencies || {}).length}
              </span>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-3 space-y-3 font-sans text-xs">
            <div className="p-3 rounded-lg bg-[#0E131E] border border-[#1F293D] space-y-2 font-mono text-xs">
              <div className="text-neutral-400 uppercase text-[10px] font-bold">Package Overview</div>
              <div className="flex items-center justify-between text-neutral-200">
                <span>Production Packages</span>
                <span className="text-cyan-400 font-bold">{Object.values(intelState.dependencies || {}).filter(d => d.category !== 'dev').length}</span>
              </div>
              <div className="flex items-center justify-between text-neutral-200">
                <span>Dev Dependencies</span>
                <span className="text-purple-400 font-bold">{Object.values(intelState.dependencies || {}).filter(d => d.category === 'dev').length}</span>
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="text-[11px] font-mono text-neutral-400 uppercase font-bold">Installed Modules</div>
              {Object.values(intelState.dependencies || {}).map(dep => (
                <div key={dep.name} className="p-2 rounded bg-[#0C1018] border border-[#1A2333] flex items-center justify-between text-xs font-mono">
                  <div className="space-y-0.5 truncate">
                    <span className="text-neutral-200 font-semibold">{dep.name}</span>
                    <div className="text-[10px] text-neutral-500">{dep.version}</div>
                  </div>
                  {dep.category === 'dev' ? (
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#1C1628] text-purple-300 border border-purple-900/40">DEV</span>
                  ) : (
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#121A28] text-cyan-300 border border-cyan-900/40">PROD</span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {/* ----------------- SEARCH VIEW ----------------- */}
      {activeView === 'search' && (
        <>
          <div className="h-10 border-b border-[#1C2230] bg-[#0C0F16] px-3 flex items-center gap-2 shrink-0">
            <Search className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-200">WORKSPACE SEARCH</span>
          </div>

          <div className="p-2.5 border-b border-[#181E2C] bg-[#0A0D14]">
            <input
              type="text"
              autoFocus
              placeholder="Search across all files..."
              value={globalSearchQuery}
              onChange={e => setGlobalSearchQuery(e.target.value)}
              className="w-full bg-[#0E121B] border border-[#1E2536] focus:border-cyan-500/80 rounded px-2.5 py-1.5 text-xs text-neutral-100 placeholder-neutral-500 outline-none font-mono"
            />
          </div>

          <div className="flex-1 overflow-y-auto p-2 divide-y divide-[#151B28]">
            {!globalSearchQuery ? (
              <div className="p-4 text-center text-xs text-neutral-500">
                Type keywords or identifiers to search across all workspace files in real-time.
              </div>
            ) : searchResults.length === 0 ? (
              <div className="p-4 text-center text-xs text-neutral-500">
                No matching lines found for "{globalSearchQuery}".
              </div>
            ) : (
              searchResults.map((res, i) => (
                <div
                  key={i}
                  onClick={() => onSelectFile(res.path)}
                  className="py-2 px-1 hover:bg-[#121724] rounded cursor-pointer group transition-colors"
                >
                  <div className="flex items-center gap-1.5 text-[11px] font-mono text-cyan-400 font-semibold mb-0.5">
                    <FileCode className="w-3 h-3 text-cyan-400" />
                    <span className="truncate">{res.path}:{res.line}</span>
                  </div>
                  <div className="text-xs font-mono text-neutral-300 truncate bg-[#0E121A] px-1.5 py-0.5 rounded border border-[#1A2230]">
                    {res.text}
                  </div>
                </div>
              ))
            )}
          </div>
        </>
      )}

      {/* ----------------- ARCHITECTURE VIEW ----------------- */}
      {activeView === 'architecture' && (
        <>
          <div className="h-10 border-b border-[#1C2230] bg-[#0C0F16] px-3 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-purple-400" />
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-200">INTELLIGENCE</span>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-3 space-y-4 font-sans text-xs">
            <div className="p-3 rounded-lg bg-[#0E131E] border border-[#1F293D] space-y-2">
              <div className="font-semibold text-neutral-200">Project Structure Overview</div>
              <div className="text-[11px] text-neutral-400 leading-relaxed">
                Autonomous AST graph analysis detects components, services, and reactive state stores.
              </div>
              <div className="grid grid-cols-2 gap-2 pt-1 font-mono text-[11px]">
                <div className="p-2 rounded bg-[#090C12] border border-[#171E2C]">
                  <div className="text-neutral-500">Total Files</div>
                  <div className="text-sm font-bold text-cyan-300">{fileCount}</div>
                </div>
                <div className="p-2 rounded bg-[#090C12] border border-[#171E2C]">
                  <div className="text-neutral-500">Framework</div>
                  <div className="text-sm font-bold text-indigo-300">{intelState.metadata.framework}</div>
                </div>
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="text-[11px] font-mono font-bold text-neutral-400 uppercase">Discovered Layers</div>
              <div className="p-2 rounded bg-[#0C1018] border border-[#1A2333] flex items-center justify-between text-xs">
                <span className="text-neutral-300">UI & Components</span>
                <span className="font-mono text-cyan-400 text-[11px]">{intelState.graph.nodes.filter(n => n.layer === 'ui').length} modules</span>
              </div>
              <div className="p-2 rounded bg-[#0C1018] border border-[#1A2333] flex items-center justify-between text-xs">
                <span className="text-neutral-300">Services & Intelligence</span>
                <span className="font-mono text-purple-400 text-[11px]">{intelState.graph.nodes.filter(n => n.layer === 'services').length} modules</span>
              </div>
              <div className="p-2 rounded bg-[#0C1018] border border-[#1A2333] flex items-center justify-between text-xs">
                <span className="text-neutral-300">Core State & Types</span>
                <span className="font-mono text-emerald-400 text-[11px]">{intelState.graph.nodes.filter(n => n.layer === 'core').length} modules</span>
              </div>
            </div>
          </div>
        </>
      )}

      {/* ----------------- MEMORY VIEW ----------------- */}
      {activeView === 'memory' && (
        <>
          <div className="h-10 border-b border-[#1C2230] bg-[#0C0F16] px-3 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-200">PROJECT MEMORY</span>
            </div>
            <button
              onClick={onOpenMemory}
              className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#171E2C] text-amber-300 hover:bg-[#20293D]"
            >
              Expand
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-3 space-y-3 font-sans text-xs">
            <div className="p-3 rounded-lg bg-[#0E131E] border border-[#1F293D] space-y-1.5">
              <div className="font-semibold text-amber-300 flex items-center gap-1.5">
                <Database className="w-3.5 h-3.5" />
                <span>Architecture Memory</span>
              </div>
              <p className="text-[11px] text-neutral-400 leading-relaxed">
                Stores architecture patterns, persistent design decisions, and coding standards learned across turns.
              </p>
            </div>

            <div className="p-3 rounded-lg bg-[#0E131E] border border-[#1F293D] space-y-1.5">
              <div className="font-semibold text-cyan-300">Live Discovered Stack</div>
              <div className="font-mono text-[11px] text-neutral-300 space-y-1">
                <div>• Framework: {intelState.metadata.framework} ({intelState.metadata.primaryLanguage || (intelState.metadata as any).language || 'typescript'})</div>
                <div>• Runtime: {intelState.metadata.runtime} / {intelState.metadata.buildTool}</div>
                <div>• Health: {intelState.health.score}% ({intelState.health.rating})</div>
                <div>• Total Symbols: {intelState.health.totalSymbols}</div>
              </div>
            </div>
          </div>
        </>
      )}

      {/* ----------------- GIT / CHECKPOINTS VIEW ----------------- */}
      {activeView === 'git' && (
        <>
          <div className="h-10 border-b border-[#1C2230] bg-[#0C0F16] px-3 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2">
              <GitBranch className="w-4 h-4 text-blue-400" />
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-200">SOURCE CONTROL</span>
            </div>
            <button
              onClick={onOpenCheckpoints}
              className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#171E2C] text-blue-300 hover:bg-[#20293D]"
            >
              Snapshots
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-3 space-y-3 font-sans text-xs">
            <div className="p-2.5 rounded-lg bg-[#0E131E] border border-[#1F293D] flex items-center justify-between">
              <div className="flex items-center gap-2 font-mono text-xs">
                <GitBranch className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-neutral-200">main</span>
              </div>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                ACTIVE
              </span>
            </div>

            <div className="space-y-1">
              <div className="text-[11px] font-mono text-neutral-400 uppercase font-bold">Recent Checkpoints ({checkpoints.length})</div>
              {checkpoints.slice(0, 4).map((cp) => (
                <div key={cp.id} className="p-2 rounded bg-[#0B0F17] border border-[#1A2233] space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-neutral-200 truncate">{cp.name}</span>
                    <span className="text-[9px] font-mono text-neutral-500">{new Date(cp.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                  <div className="text-[10px] text-neutral-400 truncate">{cp.description}</div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {/* ----------------- VERIFICATION VIEW ----------------- */}
      {activeView === 'verification' && (
        <>
          <div className="h-10 border-b border-[#1C2230] bg-[#0C0F16] px-3 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-200">VERIFICATION MATRIX</span>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-3 space-y-3 font-sans text-xs">
            <div className="p-3 rounded-lg bg-[#0E131E] border border-[#1F293D] space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-neutral-200">Evidence Status</span>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                  verificationReport?.passed
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    : 'bg-neutral-900 text-neutral-400 border border-neutral-700'
                }`}>
                  {verificationReport ? (verificationReport.passed ? '5/5 PASSED' : 'FAILED') : 'NOT RUN'}
                </span>
              </div>
              <p className="text-[11px] text-neutral-400 leading-relaxed">
                Zero fake verification: validates esbuild AST, React mounting, DOM root assertions, and runtime errors.
              </p>
              <button
                onClick={onRunVerification}
                className="w-full py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-mono text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 shadow-sm"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Run Full Verification</span>
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
