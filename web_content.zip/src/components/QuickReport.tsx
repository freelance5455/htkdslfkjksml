export * from './QuickReportCard';
export { default } from './QuickReportCard';
