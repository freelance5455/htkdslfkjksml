import { useState } from 'react';
import { Building2, Star, MapPin, CheckCircle, Calendar, Users, Sparkles, X } from 'lucide-react';
import { HotelOffer, HotelRoom, Language, Currency } from '../../types';
import { translations } from '../../i18n/translations';
import { formatPrice } from '../../utils/currency';

interface HotelSearchScreenProps {
  hotels: HotelOffer[];
  language: Language;
  currency: Currency;
  onBookHotel: (hotel: HotelOffer, room: HotelRoom) => void;
}

export function HotelSearchScreen({ hotels, language, currency, onBookHotel }: HotelSearchScreenProps) {
  const [destinationFilter, setDestinationFilter] = useState('');
  const [selectedHotel, setSelectedHotel] = useState<HotelOffer | null>(null);
  const [selectedRoom, setSelectedRoom] = useState<HotelRoom | null>(null);
  const [nights, setNights] = useState(7);
  const [bookingSuccess, setBookingSuccess] = useState(false);

  const t = translations[language];

  const filteredHotels = hotels.filter(h =>
    h.city.toLowerCase().includes(destinationFilter.toLowerCase()) ||
    h.country.toLowerCase().includes(destinationFilter.toLowerCase()) ||
    h.name.toLowerCase().includes(destinationFilter.toLowerCase())
  );

  const handleConfirmReservation = () => {
    if (!selectedHotel || !selectedRoom) return;
    onBookHotel(selectedHotel, selectedRoom);
    setBookingSuccess(true);
    setTimeout(() => {
      setBookingSuccess(false);
      setSelectedHotel(null);
      setSelectedRoom(null);
    }, 2000);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div>
        <h1 className="text-xl md:text-2xl font-black text-white">
          {t.hotelSearchTitle}
        </h1>
        <p className="text-xs text-cyan-400 font-mono mt-0.5">
          Tourism By Taki Luxury Partner Hotels & Resorts
        </p>
      </div>

      {/* Filter / Search Bar */}
      <div className="glass-panel rounded-2xl p-4 border border-cyan-500/20 space-y-3">
        <div className="flex items-center gap-2 bg-[#060c20] p-2.5 rounded-xl border border-slate-800">
          <MapPin className="w-4 h-4 text-cyan-400 shrink-0" />
          <input
            type="text"
            value={destinationFilter}
            onChange={e => setDestinationFilter(e.target.value)}
            placeholder={language === 'ar' ? 'ابحث بالمدينة أو اسم الفندق (إسطنبول، دبي، مكة...)' : 'Search city or hotel name...'}
            className="w-full bg-transparent text-xs text-white placeholder-slate-500 outline-none"
          />
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="bg-[#060c20] p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">{language === 'ar' ? 'عدد الليالي:' : 'Nights:'}</span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setNights(Math.max(1, nights - 1))}
                className="w-5 h-5 rounded bg-slate-800 text-slate-300 flex items-center justify-center font-bold"
              >
                -
              </button>
              <span className="font-bold text-white">{nights}</span>
              <button
                onClick={() => setNights(nights + 1)}
                className="w-5 h-5 rounded bg-slate-800 text-slate-300 flex items-center justify-center font-bold"
              >
                +
              </button>
            </div>
          </div>

          <div className="bg-[#060c20] p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">{language === 'ar' ? 'النزلاء:' : 'Guests:'}</span>
            <span className="font-bold text-white">2 بالغين</span>
          </div>
        </div>
      </div>

      {/* Hotels Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredHotels.map(hotel => (
          <div
            key={hotel.id}
            className="glass-panel hover:border-cyan-400/40 rounded-3xl overflow-hidden transition-all text-white flex flex-col justify-between group"
          >
            {/* Image Thumbnail */}
            <div className="relative h-44 w-full overflow-hidden bg-slate-900">
              <img
                src={hotel.imageUrl}
                alt={hotel.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#070e24] via-transparent to-black/30" />
              
              {/* Rating Badge */}
              <div className="absolute top-3 right-3 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-full border border-amber-400/30 flex items-center gap-1 text-xs">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                <span className="font-bold text-white">{hotel.rating}</span>
                <span className="text-[10px] text-slate-300 font-mono">({hotel.reviewCount})</span>
              </div>

              {/* Stars */}
              <div className="absolute bottom-3 right-3 flex items-center gap-0.5 text-amber-400">
                {Array.from({ length: hotel.stars }).map((_, i) => (
                  <Star key={i} className="w-3 h-3 fill-amber-400" />
                ))}
              </div>
            </div>

            {/* Info Body */}
            <div className="p-4 flex-1 flex flex-col justify-between">
              <div>
                <div className="flex items-start justify-between gap-2">
                  <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                    {hotel.name}
                  </h3>
                </div>
                <p className="text-[11px] text-slate-400 flex items-center gap-1 mt-1">
                  <MapPin className="w-3 h-3 text-cyan-400 shrink-0" />
                  <span>{hotel.city}، {hotel.country} · {hotel.distanceToCenter}</span>
                </p>

                {/* Amenities */}
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {hotel.amenities.slice(0, 3).map((amenity, i) => (
                    <span
                      key={i}
                      className="text-[10px] bg-slate-900/90 border border-slate-800 text-slate-300 px-2 py-0.5 rounded-md"
                    >
                      {amenity}
                    </span>
                  ))}
                </div>
              </div>

              {/* Price & CTA */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 block">{t.pricePerNight}</span>
                  <p className="text-base font-black text-cyan-300 font-mono">
                    {formatPrice(hotel.pricePerNightDZD, currency, language)}
                  </p>
                </div>

                <button
                  onClick={() => {
                    setSelectedHotel(hotel);
                    setSelectedRoom(hotel.rooms[0]);
                  }}
                  className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-bold text-xs hover:brightness-110 active:scale-[0.98] transition-all shadow-[0_0_15px_rgba(0,102,255,0.25)]"
                >
                  {language === 'ar' ? 'عرض الغرف والحجز' : 'View & Book'}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Hotel Room Selection Modal */}
      {selectedHotel && selectedRoom && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="glass-panel-elevated rounded-3xl p-6 max-w-md w-full border border-cyan-400/40 text-white space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-white">{selectedHotel.name}</h3>
                <p className="text-xs text-cyan-400">{selectedHotel.city} · {selectedHotel.address}</p>
              </div>
              <button
                onClick={() => setSelectedHotel(null)}
                className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {bookingSuccess ? (
              <div className="py-8 text-center space-y-3">
                <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-400 flex items-center justify-center mx-auto animate-bounce">
                  <CheckCircle className="w-8 h-8" />
                </div>
                <h4 className="text-lg font-bold text-white">
                  {language === 'ar' ? 'تم تأكيد حجز الفندق بنجاح!' : 'Hotel Reservation Confirmed!'}
                </h4>
                <p className="text-xs text-slate-300 max-w-xs mx-auto">
                  {language === 'ar' ? 'تم حفظ قسيمة الفندق (Voucher) في محفظتك الإلكترونية.' : 'Hotel Voucher saved in your Travel Wallet.'}
                </p>
              </div>
            ) : (
              <>
                {/* Rooms options */}
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-slate-300">
                    {language === 'ar' ? 'اختر نوع الغرفة:' : 'Select Room Type:'}
                  </p>
                  {selectedHotel.rooms.map(room => (
                    <div
                      key={room.id}
                      onClick={() => setSelectedRoom(room)}
                      className={`p-3 rounded-2xl border cursor-pointer transition-all ${
                        selectedRoom.id === room.id
                          ? 'bg-blue-600/20 border-cyan-400 shadow-[0_0_15px_rgba(0,240,255,0.2)]'
                          : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <p className="text-xs font-bold text-white">{room.name}</p>
                        <p className="text-xs font-mono font-bold text-cyan-300">
                          {formatPrice(room.pricePerNightDZD, currency, language)} / {language === 'ar' ? 'ليلة' : 'night'}
                        </p>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1">{room.bedType} · أقصى حد {room.maxGuests} نزلاء</p>
                    </div>
                  ))}
                </div>

                {/* Total Price breakdown */}
                <div className="p-3 bg-slate-900/90 rounded-2xl border border-cyan-500/30 flex items-center justify-between text-xs">
                  <div>
                    <span className="text-slate-400 block">{language === 'ar' ? `المجموع لـ ${nights} ليالٍ` : `Total for ${nights} nights`}</span>
                    <span className="text-emerald-400 text-[10px]">شامل الضرائب والإفطار</span>
                  </div>
                  <span className="text-base font-black text-cyan-400 font-mono">
                    {formatPrice(selectedRoom.pricePerNightDZD * nights, currency, language)}
                  </span>
                </div>

                <button
                  onClick={handleConfirmReservation}
                  className="w-full h-12 rounded-xl bg-gradient-to-r from-blue-600 via-cyan-500 to-blue-600 text-white font-bold text-xs shadow-[0_4px_25px_rgba(0,102,255,0.4)] hover:brightness-110 active:scale-[0.98] transition-all"
                >
                  {t.bookRoom}
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
