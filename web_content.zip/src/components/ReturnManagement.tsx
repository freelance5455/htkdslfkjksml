import React, { useState, useEffect } from 'react';
import { Customer, SaleInvoice, ProductReturn, CartItem } from '../types/business';
import { StorageService } from '../db/storage';
import {
  RotateCcw,
  ArrowLeft,
  Search,
  CheckCircle2,
  Calendar,
  AlertCircle,
  Receipt,
  User,
  Package,
} from 'lucide-react';

interface ReturnManagementProps {
  lang: 'bn' | 'en';
  onBack: () => void;
}

export const ReturnManagement: React.FC<ReturnManagementProps> = ({
  lang,
  onBack,
}) => {
  const [activeTab, setActiveTab] = useState<'new_return' | 'return_history'>('new_return');
  const [returns, setReturns] = useState<ProductReturn[]>(StorageService.getReturns());
  const [customers, setCustomers] = useState<Customer[]>(StorageService.getCustomers());
  const [invoices, setInvoices] = useState<SaleInvoice[]>(StorageService.getInvoices());

  // Step 1: Customer Selection
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  // Step 2: Invoice Selection
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string>('');
  // Step 3: Product Item Selection
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  // Step 4: Return Qty
  const [returnQty, setReturnQty] = useState<number | ''>(1);
  // Step 5: Refund Method
  const [refundMethod, setRefundMethod] = useState<'Cash' | 'bKash' | 'Nagad' | 'Bank' | 'Deduct Due'>('Cash');
  const [returnReason, setReturnReason] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // History search
  const [historySearch, setHistorySearch] = useState('');

  const refreshData = () => {
    setReturns(StorageService.getReturns());
    setInvoices(StorageService.getInvoices());
    setCustomers(StorageService.getCustomers());
  };

  // Invoices filtered by selected customer
  const availableInvoices = invoices.filter((i) => {
    if (!selectedCustomerId) return true;
    return i.customerId === selectedCustomerId;
  });

  const currentInvoice = invoices.find((i) => i.id === selectedInvoiceId);

  // Available items in the selected invoice
  const invoiceItems = currentInvoice?.items || [];
  const currentItem = invoiceItems.find((item) => item.productId === selectedProductId);

  // Calculate maximum returnable quantity: purchased qty minus already returned
  const alreadyReturned =
    currentInvoice?.returnedQuantities && selectedProductId
      ? currentInvoice.returnedQuantities[selectedProductId] || 0
      : 0;
  const maxReturnableQty = currentItem ? Math.max(0, currentItem.quantity - alreadyReturned) : 0;

  // Handle return submission
  const handleConfirmReturn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentInvoice || !currentItem) {
      setErrorMsg('অনুগ্রহ করে ইনভয়েস ও পণ্য নির্বাচন করুন');
      return;
    }

    const qty = Number(returnQty);
    if (!qty || qty <= 0) {
      setErrorMsg('সঠিক ফেরতের পরিমাণ লিখুন');
      return;
    }

    if (qty > maxReturnableQty) {
      setErrorMsg(`সর্বোচ্চ ফেরতযোগ্য পরিমাণ: ${maxReturnableQty} পিস`);
      return;
    }

    try {
      StorageService.recordProductReturn({
        customerId: currentInvoice.customerId,
        customerName: currentInvoice.customerName,
        customerPhone: currentInvoice.customerPhone,
        invoiceId: currentInvoice.id,
        invoiceNumber: currentInvoice.invoiceNumber,
        productId: currentItem.productId,
        productName: currentItem.productName,
        brand: currentItem.brand,
        model: currentItem.modelNumber,
        quantity: qty,
        unitPrice: currentItem.unitPrice,
        refundMethod,
        reason: returnReason.trim() || undefined,
      });

      setSuccessMsg(
        `পণ্য সফলভাবে রিটার্ন সম্পন্ন হয়েছে! ${qty} পিস ${currentItem.modelNumber} স্টকে যোগ করা হয়েছে।`
      );
      setErrorMsg('');
      setSelectedInvoiceId('');
      setSelectedProductId('');
      setReturnQty(1);
      setReturnReason('');
      refreshData();

      setTimeout(() => {
        setSuccessMsg('');
      }, 4000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Error processing return');
    }
  };

  const filteredHistory = returns.filter((r) => {
    const q = historySearch.toLowerCase();
    return (
      r.customerName.toLowerCase().includes(q) ||
      r.invoiceNumber.toLowerCase().includes(q) ||
      r.model.toLowerCase().includes(q) ||
      r.brand.toLowerCase().includes(q)
    );
  });

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-24 font-sans">
      {/* Top Header */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-20 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                <RotateCcw className="w-5 h-5 text-rose-600" />
                <span>{lang === 'bn' ? 'পণ্য রিটার্ন ও সমন্বয় (Return Management)' : 'Return Management'}</span>
              </h1>
              <p className="text-xs text-slate-500">
                {lang === 'bn'
                  ? 'পূর্বের বিক্রয় থেকে পণ্য ফেরত, স্টক বৃদ্ধি ও লাভের হিসাব সমন্বয়'
                  : 'Process customer returns & adjust inventory and profit'}
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-2xl">
            <button
              onClick={() => setActiveTab('new_return')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                activeTab === 'new_return'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              নতুন রিটার্ন
            </button>
            <button
              onClick={() => setActiveTab('return_history')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                activeTab === 'return_history'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              রিটার্ন হিস্টোরি ({returns.length})
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6">
        {activeTab === 'new_return' ? (
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
            <div>
              <h2 className="text-base font-extrabold text-slate-900">
                বিক্রয়কৃত পণ্য রিটার্ন ফর্ম
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                শুধুমাত্র যেসব পণ্য ইতোপূর্বে বিক্রি হয়েছে এবং এখনো রিটার্ন করা হয়নি সেগুলোই সিলেক্ট করা যাবে।
              </p>
            </div>

            {successMsg && (
              <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-2xl flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>{successMsg}</span>
              </div>
            )}

            {errorMsg && (
              <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs font-semibold rounded-2xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleConfirmReturn} className="space-y-4">
              {/* 1. Customer Select */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ধাপ ১: কাস্টমার নির্বাচন (ঐচ্ছিক — সব ইনভয়েস দেখতে খালি রাখুন)
                </label>
                <select
                  value={selectedCustomerId}
                  onChange={(e) => {
                    setSelectedCustomerId(e.target.value);
                    setSelectedInvoiceId('');
                    setSelectedProductId('');
                  }}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-xs font-semibold"
                >
                  <option value="">সব কাস্টমার / নগদ ক্রেতার ইনভয়েস</option>
                  {customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.phone})
                    </option>
                  ))}
                </select>
              </div>

              {/* 2. Invoice Select */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ধাপ ২: পূর্বের বিক্রয় চালান / ইনভয়েস নির্বাচন *
                </label>
                <select
                  required
                  value={selectedInvoiceId}
                  onChange={(e) => {
                    setSelectedInvoiceId(e.target.value);
                    setSelectedProductId('');
                  }}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-indigo-700 focus:ring-2 focus:ring-rose-500/20"
                >
                  <option value="">চালান নির্বাচন করুন</option>
                  {availableInvoices.map((inv) => (
                    <option key={inv.id} value={inv.id}>
                      {inv.invoiceNumber} • {inv.customerName} ({inv.date}) • মোট: ৳{inv.finalPayableAmount}
                    </option>
                  ))}
                </select>
              </div>

              {/* 3. Product Item Select from chosen invoice */}
              {currentInvoice && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    ধাপ ৩: উক্ত চালানের কোন পণ্যটি ফেরত আসছে? *
                  </label>
                  <select
                    required
                    value={selectedProductId}
                    onChange={(e) => setSelectedProductId(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-900"
                  >
                    <option value="">পণ্য নির্বাচন করুন</option>
                    {invoiceItems.map((item) => {
                      const returned = currentInvoice.returnedQuantities?.[item.productId] || 0;
                      const returnable = Math.max(0, item.quantity - returned);
                      return (
                        <option
                          key={item.productId}
                          value={item.productId}
                          disabled={returnable <= 0}
                        >
                          {item.brand} {item.modelNumber} ({item.category}) — কেনা ছিল: {item.quantity} পিস, অবশিষ্ট ফেরতযোগ্য: {returnable} পিস (দর: ৳{item.unitPrice})
                        </option>
                      );
                    })}
                  </select>
                </div>
              )}

              {/* 4. Return Quantity & Refund Value */}
              {currentItem && (
                <div className="p-4 bg-rose-50/50 rounded-2xl border border-rose-200 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-900">
                      নির্বাচিত পণ্য: {currentItem.brand} {currentItem.modelNumber}
                    </span>
                    <span className="font-bold text-rose-700">
                      সর্বোচ্চ ফেরতযোগ্য: {maxReturnableQty} পিস
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        ফেরতের পরিমাণ (পিস) *
                      </label>
                      <input
                        type="number"
                        min="1"
                        max={maxReturnableQty}
                        required
                        value={returnQty}
                        onChange={(e) => setReturnQty(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold text-slate-900"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        মোট রিফান্ড টাকার পরিমাণ
                      </label>
                      <input
                        type="text"
                        readOnly
                        value={`৳${((Number(returnQty) || 0) * currentItem.unitPrice).toLocaleString()}`}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-black text-rose-700"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      রিফান্ড সমন্বয় পদ্ধতি
                    </label>
                    <select
                      value={refundMethod}
                      onChange={(e) => setRefundMethod(e.target.value as any)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold"
                    >
                      <option value="Cash">ক্যাশ রিফান্ড (Cash Refund)</option>
                      <option value="bKash">বিকাশ (bKash)</option>
                      <option value="Nagad">নগদ (Nagad)</option>
                      <option value="Bank">ব্যাংক (Bank)</option>
                      <option value="Deduct Due">কাস্টমারের বাকি থেকে কর্তন (Deduct from Due)</option>
                    </select>
                  </div>
                </div>
              )}

              {/* Reason */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ফেরতের কারণ বা মন্তব্য (ঐচ্ছিক)
                </label>
                <input
                  type="text"
                  value={returnReason}
                  onChange={(e) => setReturnReason(e.target.value)}
                  placeholder="যেমন: গ্রাহক ভুল মডেল নিয়ে গিয়েছিলেন / ত্রুটিযুক্ত পার্টস"
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs font-medium"
                />
              </div>

              <button
                type="submit"
                disabled={!currentItem || maxReturnableQty <= 0}
                className="w-full py-3.5 px-4 rounded-2xl bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white font-extrabold text-sm shadow-md shadow-rose-600/20 flex items-center justify-center gap-2 cursor-pointer active:scale-[0.99] transition-all"
              >
                <RotateCcw className="w-4 h-4" />
                <span>রিটার্ন নিশ্চিত করুন (Confirm Return)</span>
              </button>
            </form>
          </div>
        ) : (
          /* RETURN HISTORY TAB */
          <div className="space-y-4">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={historySearch}
                onChange={(e) => setHistorySearch(e.target.value)}
                placeholder="কাস্টমার, চালান, মডেল দিয়ে খুঁজুন..."
                className="w-full pl-9 pr-3 py-2.5 rounded-2xl bg-white border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-rose-500/20"
              />
            </div>

            {filteredHistory.length === 0 ? (
              <div className="bg-white rounded-3xl p-10 text-center border border-slate-200 text-slate-400 text-xs">
                কোন রিটার্ন হিস্টোরি রেকর্ড নেই
              </div>
            ) : (
              <div className="space-y-3">
                {filteredHistory.map((ret) => (
                  <div
                    key={ret.id}
                    className="p-4 rounded-2xl bg-white border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs shadow-2xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-200">
                          {ret.quantity} পিস ফেরত
                        </span>
                        <span className="text-slate-400">
                          চালান: <strong className="text-slate-700">{ret.invoiceNumber}</strong>
                        </span>
                        <span className="text-slate-400">• {ret.date} ({ret.time})</span>
                      </div>
                      <h4 className="font-bold text-slate-900 text-sm mt-1">
                        {ret.brand} {ret.model}
                      </h4>
                      <p className="text-slate-500 text-[11px]">
                        ক্রেতা: {ret.customerName} {ret.reason ? `• কারণ: ${ret.reason}` : ''}
                      </p>
                    </div>

                    <div className="text-right sm:border-l sm:border-slate-100 sm:pl-4">
                      <span className="text-[10px] text-slate-400 block font-medium">রিফান্ড দেওয়া হয়েছে</span>
                      <span className="text-sm font-black text-rose-700">
                        ৳{ret.returnAmount.toLocaleString()}
                      </span>
                      <span className="text-[10px] text-slate-500 block">
                        পদ্ধতি: {ret.refundMethod}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
