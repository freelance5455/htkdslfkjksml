import React, { useState } from 'react';
import { TierLevel, UserProfile } from '../types';
import { TIERS_CONFIG, calculateUserTier } from '../data/tiers';
import { Lock, Unlock, Check, Sparkles, Copy, UserPlus, CreditCard, Crown } from 'lucide-react';
import confetti from 'canvas-confetti';

interface TiersViewProps {
  user: UserProfile;
  onSimulateAddInvite: () => void;
  onSimulateInviteePayment: () => void;
  onToggleUserSubscription: () => void;
  onOpenPaywall: (tier?: TierLevel) => void;
}

export const TiersView: React.FC<TiersViewProps> = ({
  user,
  onSimulateAddInvite,
  onSimulateInviteePayment,
  onToggleUserSubscription,
  onOpenPaywall,
}) => {
  const [copied, setCopied] = useState(false);
  const paidInvitesCount = user.invitees.filter((i) => i.isSubscribed).length;
  const inviteCount = user.invitees.length;

  const { currentTier, canAccessTier, getTierLockReason } = calculateUserTier(
    inviteCount,
    user.isDirectlySubscribed,
    paidInvitesCount
  );

  const handleCopyLink = () => {
    navigator.clipboard.writeText(`https://calai.app/join?ref=${user.inviteCode}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto pb-12">
      {/* Top Banner explaining the new system */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950/40 border border-slate-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-amber-500/10 border border-amber-500/20 text-xs font-bold text-amber-400">
              <Sparkles className="w-3.5 h-3.5" />
              <span>نظام المستويات المتدرجة والاشتراك الإجباري (5 مستويات)</span>
            </div>
            <h1 className="text-2xl font-black text-white">
              نظام المكافآت والمستويات من 1 إلى 5
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              وفقاً لقواعد التطبيق الصارمة: <strong className="text-amber-400">بداية من المستوى 3 وما فوق، الدفع إجباري</strong>. يمكنك فتح الميزات إما عبر اشتراكك الشخصي، أو بمجرد أن يشترك أصدقاؤك الذين دعوتهم!
            </p>
          </div>

          {/* Quick status box */}
          <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-xl space-y-2 shrink-0 min-w-[240px]">
            <div className="text-xs text-slate-400">مستواك الحالي:</div>
            <div className="flex items-center gap-2">
              <span className="text-2xl">{TIERS_CONFIG[currentTier].badge}</span>
              <div>
                <div className="text-sm font-bold text-white">{TIERS_CONFIG[currentTier].nameAr}</div>
                <div className="text-xs text-emerald-400 font-semibold">
                  {user.isDirectlySubscribed ? 'مشترك مباشر (PRO)' : paidInvitesCount >= 2 ? 'مفعل عبر اشتراك المدعوين' : 'مستوى مجاني'}
                </div>
              </div>
            </div>
            <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 flex justify-between">
              <span>الدعوات: <strong className="text-white tabular-nums">{inviteCount}</strong></span>
              <span>المدعوين المشتركين: <strong className="text-amber-400 tabular-nums">{paidInvitesCount}</strong></span>
            </div>
          </div>
        </div>
      </div>

      {/* Simulator Sandbox Controls for Testing */}
      <div className="p-4 bg-slate-950 border border-emerald-500/30 rounded-2xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <h3 className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
              لوحة المحاكاة والتجربة الفورية (Sandbox Demo)
            </h3>
          </div>
          <span className="text-[11px] text-slate-400">جرب تأثير إضافة الدعوات والاشتراكات فوراً:</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
          <button
            onClick={() => {
              confetti({ particleCount: 30, spread: 50 });
              onSimulateAddInvite();
            }}
            className="p-2.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-xs font-bold text-slate-200 flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <UserPlus className="w-4 h-4 text-emerald-400" />
            <span>+ محاكاة انضمام صديق جديد</span>
          </button>

          <button
            onClick={() => {
              confetti({ particleCount: 45, spread: 60 });
              onSimulateInviteePayment();
            }}
            className="p-2.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-xs font-bold text-amber-400 flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <CreditCard className="w-4 h-4 text-amber-400" />
            <span>+ محاكاة اشتراك صديق مدعو</span>
          </button>

          <button
            onClick={() => {
              confetti({ particleCount: 40, spread: 60 });
              onToggleUserSubscription();
            }}
            className={`p-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer border ${
              user.isDirectlySubscribed
                ? 'bg-rose-950/30 border-rose-800 text-rose-300 hover:bg-rose-950/50'
                : 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300 hover:bg-emerald-950/60'
            }`}
          >
            <Crown className="w-4 h-4" />
            <span>{user.isDirectlySubscribed ? 'إلغاء اشتراكي المباشر' : 'تفعيل اشتراكي المباشر (Pro)'}</span>
          </button>
        </div>
      </div>

      {/* Referral Link & Share Section */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-bold text-white">رابط دعوتك الشخصي</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              شاركه مع أصدقائك. عند تسجيلهم واشتراكهم يفتحون لك المستويات تلقائياً!
            </p>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={`https://calai.app/join?ref=${user.inviteCode}`}
              className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-slate-300 dir-ltr min-w-[220px]"
            />
            <button
              onClick={handleCopyLink}
              className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{copied ? 'تم النسخ!' : 'نسخ'}</span>
            </button>
          </div>
        </div>

        {/* Invited friends feed */}
        <div className="pt-2 border-t border-slate-800">
          <div className="flex items-center justify-between mb-3 text-xs">
            <span className="font-bold text-slate-300">سجل الأصدقاء المدعوين ({user.invitees.length}):</span>
            <span className="text-amber-400 font-semibold">{paidInvitesCount} منهم مشتركون</span>
          </div>

          {user.invitees.length === 0 ? (
            <div className="text-center py-6 text-xs text-slate-500">
              لم تقم بدعوة أي شخص بعد. استخدم زر المحاكاة أعلاه لتجربة النظام!
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
              {user.invitees.map((invitee) => (
                <div
                  key={invitee.id}
                  className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 flex items-center justify-between gap-2"
                >
                  <div className="flex items-center gap-2.5 overflow-hidden">
                    <img
                      src={invitee.avatar}
                      alt={invitee.name}
                      className="w-8 h-8 rounded-full object-cover shrink-0"
                    />
                    <div className="truncate">
                      <div className="text-xs font-bold text-white truncate">{invitee.name}</div>
                      <div className="text-[10px] text-slate-500">{invitee.joinedDate}</div>
                    </div>
                  </div>
                  <div>
                    {invitee.isSubscribed ? (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                        مشترك مدفوع
                      </span>
                    ) : (
                      <span className="text-[10px] text-slate-500 px-2 py-0.5 rounded bg-slate-900">
                        مجاني
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* The 5 Tiers List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white">تفاصيل المستويات الخمسة (من 1 إلى 5)</h2>
          <span className="text-xs text-slate-400">بداية من المستوى 3: الدفع إجباري</span>
        </div>

        <div className="space-y-4">
          {([1, 2, 3, 4, 5] as TierLevel[]).map((level) => {
            const config = TIERS_CONFIG[level];
            const isAccessible = canAccessTier(level);
            const isCurrent = currentTier === level;
            const lockReason = getTierLockReason(level);

            return (
              <div
                key={level}
                className={`p-5 rounded-2xl border transition-all ${
                  isCurrent
                    ? 'bg-slate-900/90 border-emerald-500 shadow-lg shadow-emerald-500/5'
                    : isAccessible
                    ? 'bg-slate-900/70 border-slate-800'
                    : 'bg-slate-950/60 border-slate-900 opacity-90'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-slate-800/80">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl p-2 bg-slate-950 rounded-xl border border-slate-800">
                      {config.badge}
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-base font-bold text-white">{config.nameAr}</h3>
                        <span className="text-xs text-slate-400 font-mono">({config.nameEn})</span>
                        {isCurrent && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500 text-slate-950">
                            مستواك الحالي
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">{config.summaryAr}</p>
                    </div>
                  </div>

                  {/* Status Indicator & Action */}
                  <div className="flex items-center gap-3">
                    {isAccessible ? (
                      <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-3 py-1.5 rounded-xl">
                        <Unlock className="w-3.5 h-3.5" />
                        <span>مفتوح ومتاح</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1 text-xs font-semibold text-rose-400 bg-rose-950/40 border border-rose-800/40 px-3 py-1.5 rounded-xl">
                          <Lock className="w-3.5 h-3.5" />
                          <span>مقفل</span>
                        </div>
                        {config.requiresPayment && (
                          <button
                            onClick={() => onOpenPaywall(level)}
                            className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs transition-colors cursor-pointer"
                          >
                            فتح المستوى
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Requirements row */}
                <div className="py-3 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs border-b border-slate-800/60">
                  <div className="flex items-center justify-between p-2.5 bg-slate-950 rounded-xl border border-slate-800/60">
                    <span className="text-slate-400">الدعوات المطلوبة:</span>
                    <span className="font-bold text-white tabular-nums">
                      {inviteCount} / {config.requiredInvites} دعوة
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-2.5 bg-slate-950 rounded-xl border border-slate-800/60">
                    <span className="text-slate-400">شرط الدفع:</span>
                    {config.requiresPayment ? (
                      <span className="font-bold text-amber-400 flex items-center gap-1">
                        <CreditCard className="w-3.5 h-3.5" />
                        إجباري (أنت أو {config.requiredPaidInvites} مدعوين)
                      </span>
                    ) : (
                      <span className="font-bold text-emerald-400">مجاني بالكامل</span>
                    )}
                  </div>

                  <div className="flex items-center justify-between p-2.5 bg-slate-950 rounded-xl border border-slate-800/60">
                    <span className="text-slate-400">حالة الدفع الحالية:</span>
                    {user.isDirectlySubscribed ? (
                      <span className="font-bold text-emerald-400">مشترك شخصياً ✓</span>
                    ) : paidInvitesCount >= config.requiredPaidInvites && config.requiresPayment ? (
                      <span className="font-bold text-emerald-400">مكتمل بالمدعوين ({paidInvitesCount}) ✓</span>
                    ) : config.requiresPayment ? (
                      <span className="font-bold text-rose-400 tabular-nums">
                        غير مكتمل ({paidInvitesCount}/{config.requiredPaidInvites})
                      </span>
                    ) : (
                      <span className="font-bold text-emerald-400">غير مطلوب ✓</span>
                    )}
                  </div>
                </div>

                {/* Lock Reason Warning if applicable */}
                {lockReason && (
                  <div className="my-3 p-3 bg-rose-950/20 border border-rose-900/40 rounded-xl text-xs text-rose-300 leading-relaxed">
                    <strong>سبب القفل:</strong> {lockReason}
                  </div>
                )}

                {/* Features list */}
                <div className="pt-3">
                  <div className="text-xs font-bold text-slate-400 mb-2">ميزات هذا المستوى:</div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {config.featuresAr.map((feat, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-slate-300">
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
