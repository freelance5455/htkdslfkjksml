import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
}

export const SecretGossipLogo: React.FC<LogoProps> = ({ 
  size = 'md', 
  showText = true, 
  className = '' 
}) => {
  const sizeMap = {
    sm: { box: 32, icon: 'w-8 h-8', text: 'text-base', sub: 'text-[9px]' },
    md: { box: 40, icon: 'w-10 h-10', text: 'text-lg', sub: 'text-[10px]' },
    lg: { box: 52, icon: 'w-13 h-13', text: 'text-2xl', sub: 'text-xs' },
    xl: { box: 68, icon: 'w-17 h-17', text: 'text-3xl', sub: 'text-sm' },
  };

  const config = sizeMap[size];

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Iconic Vector Glowing Holographic Sphere */}
      <div className={`relative ${config.icon} flex items-center justify-center shrink-0 group`}>
        
        {/* Ambient Neon Atmosphere Bloom */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-cyan-500/30 via-purple-600/30 to-rose-500/20 blur-md group-hover:blur-lg transition-all duration-500 pointer-events-none" />

        <svg 
          viewBox="0 0 100 100" 
          fill="none" 
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full relative z-10 drop-shadow-[0_0_12px_rgba(6,182,212,0.65)]"
        >
          <defs>
            {/* Core Gradient */}
            <radialGradient id="sphereCoreGrad" cx="38%" cy="32%" r="65%">
              <stop offset="0%" stopColor="#67e8f9" />
              <stop offset="28%" stopColor="#06b6d4" />
              <stop offset="68%" stopColor="#4f46e5" />
              <stop offset="92%" stopColor="#0f172a" />
              <stop offset="100%" stopColor="#05070f" />
            </radialGradient>

            {/* Neon Ring Gradient 1 */}
            <linearGradient id="ringGradCyan" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#22d3ee" />
              <stop offset="50%" stopColor="#a855f7" />
              <stop offset="100%" stopColor="#f43f5e" />
            </linearGradient>

            {/* Neon Ring Gradient 2 */}
            <linearGradient id="ringGradViolet" x1="100%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#c084fc" />
              <stop offset="60%" stopColor="#38bdf8" />
              <stop offset="100%" stopColor="#4f46e5" />
            </linearGradient>

            {/* Whisper Wave Gradient */}
            <linearGradient id="whisperWave" x1="0%" y1="50%" x2="100%" y2="50%">
              <stop offset="0%" stopColor="#a5f3fc" stopOpacity="0.2" />
              <stop offset="50%" stopColor="#ffffff" stopOpacity="0.95" />
              <stop offset="100%" stopColor="#c084fc" stopOpacity="0.2" />
            </linearGradient>

            {/* Glow Filter */}
            <filter id="neonGlowFilter" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Outer Whispering Soundwave Ring 1 */}
          <circle 
            cx="50" 
            cy="50" 
            r="47" 
            stroke="url(#ringGradCyan)" 
            strokeWidth="1.2" 
            strokeDasharray="4 6"
            className="opacity-50 group-hover:opacity-80 transition-opacity"
          />

          {/* Orbital Ellipse 1 (Tilted West-East) */}
          <ellipse 
            cx="50" 
            cy="50" 
            rx="45" 
            ry="20" 
            transform="rotate(-28 50 50)" 
            stroke="url(#ringGradCyan)" 
            strokeWidth="2" 
            strokeLinecap="round"
            className="opacity-80"
          />

          {/* Orbital Ellipse 2 (Counter-tilted) */}
          <ellipse 
            cx="50" 
            cy="50" 
            rx="44" 
            ry="19" 
            transform="rotate(42 50 50)" 
            stroke="url(#ringGradViolet)" 
            strokeWidth="1.5" 
            strokeDasharray="6 4"
            className="opacity-60"
          />

          {/* Solid Holographic Sphere Body */}
          <circle 
            cx="50" 
            cy="50" 
            r="32" 
            fill="url(#sphereCoreGrad)" 
            stroke="#38bdf8" 
            strokeWidth="1.5"
            strokeOpacity="0.8"
          />

          {/* Sphere Specular Highlight (Glass Shine) */}
          <ellipse 
            cx="40" 
            cy="36" 
            rx="12" 
            ry="7" 
            transform="rotate(-30 40 36)" 
            fill="#ffffff" 
            fillOpacity="0.35" 
          />

          {/* Internal Secret Frequency / Whispering Voice Waveform */}
          <path 
            d="M 28 50 Q 34 40, 40 50 T 50 50 T 60 50 T 72 50" 
            stroke="url(#whisperWave)" 
            strokeWidth="2.4" 
            strokeLinecap="round"
            filter="url(#neonGlowFilter)"
          />
          <path 
            d="M 33 50 Q 42 32, 50 50 T 67 50" 
            stroke="#ffffff" 
            strokeWidth="1.5" 
            strokeLinecap="round" 
            fill="none"
            className="opacity-80"
          />

          {/* Orbiting Secret Nodes (Energy spark particles) */}
          <circle cx="82" cy="33" r="3" fill="#22d3ee" className="animate-pulse" />
          <circle cx="20" cy="65" r="2.5" fill="#f43f5e" />
          <circle cx="70" cy="74" r="2" fill="#c084fc" />
          <circle cx="50" cy="50" r="3.5" fill="#ffffff" filter="url(#neonGlowFilter)" />
        </svg>
      </div>

      {/* Brand Wordmark & Tagline */}
      {showText && (
        <div className="flex flex-col justify-center">
          <div className="flex items-center gap-1.5 leading-none">
            <span className={`font-display font-extrabold ${config.text} tracking-tight bg-gradient-to-r from-pink-400 via-purple-300 to-cyan-300 bg-clip-text text-transparent`}>
              Secret Gossip
            </span>
            <span className="text-[9px] font-mono tracking-widest text-pink-400 font-bold bg-pink-950/80 border border-pink-500/40 rounded px-1.5 py-0.2 shadow-sm">
              ANON
            </span>
          </div>
          <span className={`font-medium text-slate-400 tracking-tight leading-tight mt-0.5 ${config.sub}`}>
            Where campus secrets find a voice.
          </span>
        </div>
      )}
    </div>
  );
};

export const SecretSphereLogo = SecretGossipLogo;
