import React, { useState } from 'react';
import { 
  Sparkles, 
  Mic, 
  Baby, 
  Bot, 
  Flame, 
  Wind, 
  Radio, 
  Sliders, 
  Search, 
  Globe2, 
  RotateCcw, 
  Zap, 
  ChevronDown,
  Volume2
} from 'lucide-react';
import { Language, PersonaId, VoicePersona, VoiceSettings, CustomVoice } from '../types/tts';
import { SUPPORTED_LANGUAGES } from '../constants/languages';
import { VOICE_PERSONAS } from '../constants/personas';
import { Plus } from 'lucide-react';

interface VoiceControlsProps {
  selectedLanguage: Language;
  onSelectLanguage: (lang: Language) => void;
  selectedPersona: PersonaId;
  onSelectPersona: (persona: PersonaId) => void;
  settings: VoiceSettings;
  onChangeSettings: (settings: VoiceSettings) => void;
  onResetSettings: () => void;
  customVoices?: CustomVoice[];
  onSelectCustomVoice?: (voice: CustomVoice) => void;
  onOpenCustomVoiceModal?: () => void;
  onCreateNewTTS?: (option: 'soda' | 'blank' | PersonaId) => void;
}

export const VoiceControls: React.FC<VoiceControlsProps> = ({
  selectedLanguage,
  onSelectLanguage,
  selectedPersona,
  onSelectPersona,
  settings,
  onChangeSettings,
  onResetSettings,
  customVoices = [],
  onSelectCustomVoice,
  onOpenCustomVoiceModal,
  onCreateNewTTS,
}) => {
  const [langSearch, setLangSearch] = useState('');
  const [langCategory, setLangCategory] = useState<'all' | 'indic' | 'international'>('all');
  const [isLangDropdownOpen, setIsLangDropdownOpen] = useState(false);
  const [showAdvancedEffects, setShowAdvancedEffects] = useState(false);

  const filteredLanguages = SUPPORTED_LANGUAGES.filter((lang) => {
    const matchesSearch =
      lang.name.toLowerCase().includes(langSearch.toLowerCase()) ||
      lang.nativeName.toLowerCase().includes(langSearch.toLowerCase()) ||
      lang.code.toLowerCase().includes(langSearch.toLowerCase());
    const matchesCat = langCategory === 'all' || lang.category === langCategory;
    return matchesSearch && matchesCat;
  });

  const getPersonaIcon = (id: PersonaId) => {
    switch (id) {
      case 'female':
        return <Sparkles className="w-4 h-4 text-pink-400" />;
      case 'male':
        return <Mic className="w-4 h-4 text-blue-400" />;
      case 'child':
        return <Baby className="w-4 h-4 text-amber-400" />;
      case 'alien':
        return <Bot className="w-4 h-4 text-emerald-400" />;
      case 'monster':
        return <Flame className="w-4 h-4 text-red-400" />;
      case 'whisper':
        return <Wind className="w-4 h-4 text-cyan-400" />;
      case 'host':
        return <Radio className="w-4 h-4 text-violet-400" />;
      case 'soda':
        return <Sparkles className="w-4 h-4 text-amber-400" />;
      default:
        return <Mic className="w-4 h-4 text-zinc-400" />;
    }
  };

  const speedPresets = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0];

  return (
    <div className="space-y-6">
      {/* Language Selector Section */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 flex items-center gap-1.5">
            <Globe2 className="w-3.5 h-3.5 text-violet-500" />
            Target Language &amp; Dialect
          </label>
          <span className="text-xs font-semibold text-violet-600 dark:text-violet-400">
            {selectedLanguage.flag} {selectedLanguage.name} ({selectedLanguage.nativeName})
          </span>
        </div>

        {/* Quick Indic Language Pills */}
        <div className="flex flex-wrap items-center gap-1.5 pb-1">
          {SUPPORTED_LANGUAGES.filter((l) =>
            ['ta-IN', 'te-IN', 'ml-IN', 'kn-IN', 'hi-IN', 'en-US'].includes(l.code)
          ).map((l) => (
            <button
              key={l.code}
              onClick={() => onSelectLanguage(l)}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all flex items-center gap-1 ${
                selectedLanguage.code === l.code
                  ? 'bg-violet-600 text-white shadow-sm shadow-violet-600/30'
                  : 'bg-zinc-100 dark:bg-zinc-900 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-800'
              }`}
            >
              <span>{l.flag}</span>
              <span>{l.nativeName}</span>
              <span className="text-[10px] opacity-75">({l.name})</span>
            </button>
          ))}
          <button
            onClick={() => setIsLangDropdownOpen(!isLangDropdownOpen)}
            className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-300 dark:hover:bg-zinc-700 flex items-center gap-1"
          >
            More Languages ({SUPPORTED_LANGUAGES.length})
            <ChevronDown className={`w-3 h-3 transition-transform ${isLangDropdownOpen ? 'rotate-180' : ''}`} />
          </button>
        </div>

        {/* Expanded Language Search & Dropdown */}
        {isLangDropdownOpen && (
          <div className="mt-2 p-3 bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800 shadow-xl space-y-3 animate-in fade-in zoom-in-95 duration-150">
            {/* Search Input & Category Pills */}
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
                <input
                  type="text"
                  placeholder="Search Tamil, Telugu, English, etc..."
                  value={langSearch}
                  onChange={(e) => setLangSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-lg text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-1 focus:ring-violet-500"
                />
              </div>
              <div className="flex items-center gap-1 text-[11px] font-semibold">
                <button
                  onClick={() => setLangCategory('all')}
                  className={`px-2 py-1 rounded-md ${
                    langCategory === 'all'
                      ? 'bg-zinc-800 text-white dark:bg-zinc-100 dark:text-zinc-900'
                      : 'text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800'
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setLangCategory('indic')}
                  className={`px-2 py-1 rounded-md ${
                    langCategory === 'indic'
                      ? 'bg-zinc-800 text-white dark:bg-zinc-100 dark:text-zinc-900'
                      : 'text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800'
                  }`}
                >
                  Indian (தமிழ், తెలుగు...)
                </button>
                <button
                  onClick={() => setLangCategory('international')}
                  className={`px-2 py-1 rounded-md ${
                    langCategory === 'international'
                      ? 'bg-zinc-800 text-white dark:bg-zinc-100 dark:text-zinc-900'
                      : 'text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800'
                  }`}
                >
                  Global
                </button>
              </div>
            </div>

            {/* Language Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-48 overflow-y-auto pr-1">
              {filteredLanguages.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => {
                    onSelectLanguage(lang);
                    setIsLangDropdownOpen(false);
                  }}
                  className={`p-2 rounded-lg text-left text-xs border transition-all flex items-center justify-between ${
                    selectedLanguage.code === lang.code
                      ? 'border-violet-500 bg-violet-50 dark:bg-violet-950/40 text-violet-900 dark:text-violet-200 font-semibold'
                      : 'border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700 bg-zinc-50/50 dark:bg-zinc-950/50 text-zinc-700 dark:text-zinc-300'
                  }`}
                >
                  <div className="truncate">
                    <div className="font-semibold flex items-center gap-1.5">
                      <span>{lang.flag}</span>
                      <span className="truncate">{lang.name}</span>
                    </div>
                    <div className="text-[10px] text-zinc-500 dark:text-zinc-400">{lang.nativeName}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Custom Voice Creations (if any or creation trigger) */}
      {customVoices && customVoices.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold uppercase tracking-wider text-violet-600 dark:text-violet-400 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              My Custom Voice Creations ({customVoices.length})
            </label>
            {onOpenCustomVoiceModal && (
              <button
                type="button"
                onClick={onOpenCustomVoiceModal}
                className="text-[11px] font-semibold text-violet-500 hover:text-violet-600 flex items-center gap-1"
              >
                <Plus className="w-3 h-3" />
                <span>New Voice</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {customVoices.map((cv) => (
              <button
                key={cv.id}
                type="button"
                onClick={() => onSelectCustomVoice && onSelectCustomVoice(cv)}
                className="p-2.5 rounded-xl border border-violet-500/30 bg-violet-500/5 dark:bg-violet-950/20 hover:border-violet-500 hover:bg-violet-500/10 text-left transition-all"
              >
                <div className="flex items-center justify-between gap-1">
                  <span className="text-xs font-bold text-zinc-900 dark:text-white truncate">
                    {cv.name}
                  </span>
                  <span className="text-[10px] font-mono text-violet-500 font-bold shrink-0">
                    {cv.speed}x · {cv.pitch > 0 ? `+${cv.pitch}` : cv.pitch}st
                  </span>
                </div>
                <p className="text-[10px] text-zinc-500 dark:text-zinc-400 line-clamp-1 mt-0.5">
                  {cv.description}
                </p>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Quick Create New TTS Presets */}
      <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-500/10 via-violet-500/10 to-cyan-500/10 border border-amber-500/20 dark:border-amber-500/30 space-y-2">
        <div className="flex items-center justify-between">
          <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            Quick Option to Create New TTS
          </label>
          <span className="text-[10px] text-amber-600 dark:text-amber-400 font-semibold">1-Click Presets</span>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          {/* Prominent Soda Option for Create New TTS */}
          <button
            type="button"
            onClick={() => {
              if (onCreateNewTTS) {
                onCreateNewTTS('soda');
              } else {
                onSelectPersona('soda');
              }
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm active:scale-95 cursor-pointer ${
              selectedPersona === 'soda'
                ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-amber-500/30 ring-2 ring-amber-400'
                : 'bg-white dark:bg-zinc-800 text-amber-700 dark:text-amber-300 border border-amber-300 dark:border-amber-700/60 hover:bg-amber-50 dark:hover:bg-amber-950/40'
            }`}
          >
            <span className="text-sm">🥤</span>
            <span>Soda Voice (சோடா)</span>
            <span className="text-[9px] bg-amber-400/30 text-amber-900 dark:text-amber-200 px-1.5 py-0.5 rounded-full font-extrabold uppercase">
              Fizzy Pop
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (onCreateNewTTS) {
                onCreateNewTTS('female');
              } else {
                onSelectPersona('female');
              }
            }}
            className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-white dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700 hover:bg-zinc-50 dark:hover:bg-zinc-700 transition-all flex items-center gap-1"
          >
            <span>👩</span>
            <span>Aria Female</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (onCreateNewTTS) {
                onCreateNewTTS('male');
              } else {
                onSelectPersona('male');
              }
            }}
            className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-white dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700 hover:bg-zinc-50 dark:hover:bg-zinc-700 transition-all flex items-center gap-1"
          >
            <span>👨</span>
            <span>Roger Male</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (onCreateNewTTS) {
                onCreateNewTTS('child');
              } else {
                onSelectPersona('child');
              }
            }}
            className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-white dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700 hover:bg-zinc-50 dark:hover:bg-zinc-700 transition-all flex items-center gap-1"
          >
            <span>👶</span>
            <span>Cute Child</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (onCreateNewTTS) {
                onCreateNewTTS('alien');
              } else {
                onSelectPersona('alien');
              }
            }}
            className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-white dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700 hover:bg-zinc-50 dark:hover:bg-zinc-700 transition-all flex items-center gap-1"
          >
            <span>👽</span>
            <span>Alien</span>
          </button>

          {onCreateNewTTS && (
            <button
              type="button"
              onClick={() => onCreateNewTTS('blank')}
              className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-all flex items-center gap-1 ml-auto"
              title="Clear text and start fresh TTS"
            >
              <span>+ Blank TTS</span>
            </button>
          )}
        </div>
      </div>

      {/* Voice Personas Grid */}
      <div className="space-y-2">
        <label className="text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <Mic className="w-3.5 h-3.5 text-violet-500" />
            Voice Persona &amp; Tone
          </span>
          <span className="text-[11px] font-normal text-zinc-400 lowercase">
            Soda, Men, Female, Child, Alien &amp; Monster
          </span>
        </label>

        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {VOICE_PERSONAS.map((persona) => {
            const isSelected = selectedPersona === persona.id;
            const isSoda = persona.id === 'soda';
            return (
              <button
                key={persona.id}
                onClick={() => {
                  if (isSoda && onCreateNewTTS) {
                    onCreateNewTTS('soda');
                  } else {
                    onSelectPersona(persona.id);
                  }
                }}
                className={`p-3 rounded-xl border text-left transition-all relative overflow-hidden group ${
                  isSelected
                    ? isSoda
                      ? 'border-amber-500 bg-gradient-to-br from-amber-500/15 via-orange-500/10 to-transparent dark:from-amber-500/25 dark:via-zinc-900 dark:to-zinc-900 shadow-md ring-2 ring-amber-500/50'
                      : 'border-violet-500 bg-gradient-to-br from-violet-500/10 via-indigo-500/5 to-transparent dark:from-violet-500/20 dark:via-zinc-900 dark:to-zinc-900 shadow-md ring-1 ring-violet-500/40'
                    : isSoda
                    ? 'border-amber-300/80 dark:border-amber-700/50 bg-amber-500/5 dark:bg-amber-950/20 hover:border-amber-400 hover:bg-amber-500/10'
                    : 'border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900/60 hover:border-zinc-300 dark:hover:border-zinc-700 hover:bg-zinc-50 dark:hover:bg-zinc-900'
                }`}
              >
                {isSoda && (
                  <div className="absolute top-1.5 right-1.5 bg-gradient-to-r from-amber-500 to-orange-500 text-white text-[9px] font-extrabold px-1.5 py-0.5 rounded-full shadow-xs uppercase tracking-wide flex items-center gap-0.5">
                    <span>🥤</span> POPULAR
                  </div>
                )}
                <div className="flex items-start justify-between gap-2 mb-1">
                  <div className="flex items-center gap-2">
                    <div className={`p-1.5 rounded-lg ${isSoda ? 'bg-amber-100 dark:bg-amber-900/60 text-amber-600' : 'bg-zinc-100 dark:bg-zinc-800'}`}>
                      {getPersonaIcon(persona.id)}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-zinc-900 dark:text-white leading-tight">
                        {persona.name}
                      </h4>
                      <span className={`text-[10px] uppercase font-bold ${isSoda ? 'text-amber-600 dark:text-amber-400' : 'text-violet-600 dark:text-violet-400'}`}>
                        {isSoda ? 'Fizzy Pop' : persona.gender}
                      </span>
                    </div>
                  </div>
                  {isSelected && (
                    <span className={`w-2 h-2 rounded-full ${isSoda ? 'bg-amber-500 shadow-amber-500' : 'bg-violet-500 shadow-violet-500'} shadow-sm`}></span>
                  )}
                </div>
                <p className="text-[11px] text-zinc-500 dark:text-zinc-400 line-clamp-2 mt-1">
                  {persona.tagline}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Voice Speed & Pitch Controls */}
      <div className="bg-zinc-50 dark:bg-zinc-900/60 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800/80 space-y-4">
        
        {/* Speed Slider */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-zinc-700 dark:text-zinc-300 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-500" />
              Voice Speed (Rate)
            </span>
            <span className="text-xs font-mono font-bold text-violet-600 dark:text-violet-400 bg-violet-500/10 px-2 py-0.5 rounded">
              {settings.speed.toFixed(2)}x
            </span>
          </div>

          <div className="flex items-center gap-3">
            <input
              type="range"
              min="0.25"
              max="3.0"
              step="0.05"
              value={settings.speed}
              onChange={(e) =>
                onChangeSettings({
                  ...settings,
                  speed: parseFloat(e.target.value),
                })
              }
              className="w-full accent-violet-600 cursor-pointer h-1.5 bg-zinc-200 dark:bg-zinc-700 rounded-lg appearance-none"
            />
          </div>

          {/* Quick Speed Preset Pills */}
          <div className="flex items-center justify-between gap-1 pt-1">
            {speedPresets.map((preset) => (
              <button
                key={preset}
                onClick={() => onChangeSettings({ ...settings, speed: preset })}
                className={`text-[10px] font-semibold px-2 py-0.5 rounded-md transition-all ${
                  Math.abs(settings.speed - preset) < 0.03
                    ? 'bg-violet-600 text-white'
                    : 'bg-zinc-200/70 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-300 dark:hover:bg-zinc-700'
                }`}
              >
                {preset}x
              </button>
            ))}
          </div>
        </div>

        {/* Pitch Slider */}
        <div className="space-y-1.5 pt-2 border-t border-zinc-200/70 dark:border-zinc-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-zinc-700 dark:text-zinc-300 flex items-center gap-1.5">
              <Volume2 className="w-3.5 h-3.5 text-cyan-500" />
              Pitch Tuning
            </span>
            <span className="text-xs font-mono font-bold text-zinc-600 dark:text-zinc-400">
              {settings.pitch > 0 ? `+${settings.pitch}` : settings.pitch} st
            </span>
          </div>

          <div className="flex items-center gap-3">
            <input
              type="range"
              min="-12"
              max="12"
              step="1"
              value={settings.pitch}
              onChange={(e) =>
                onChangeSettings({
                  ...settings,
                  pitch: parseInt(e.target.value, 10),
                })
              }
              className="w-full accent-cyan-600 cursor-pointer h-1.5 bg-zinc-200 dark:bg-zinc-700 rounded-lg appearance-none"
            />
          </div>
          <div className="flex justify-between text-[10px] text-zinc-400 font-mono">
            <span>-12 st (Deep Bass)</span>
            <span>0 (Default)</span>
            <span>+12 st (High Pitch)</span>
          </div>
        </div>

        {/* ElevenLabs Style Stability & Clarity */}
        <div className="pt-2 border-t border-zinc-200/70 dark:border-zinc-800 grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <div className="flex justify-between text-[11px] mb-1 font-semibold text-zinc-600 dark:text-zinc-400">
              <span>Voice Stability</span>
              <span>{settings.stability}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={settings.stability}
              onChange={(e) =>
                onChangeSettings({ ...settings, stability: parseInt(e.target.value, 10) })
              }
              className="w-full accent-violet-600 h-1.5 bg-zinc-200 dark:bg-zinc-700 rounded-lg cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-[11px] mb-1 font-semibold text-zinc-600 dark:text-zinc-400">
              <span>Clarity &amp; Presence</span>
              <span>{settings.clarity}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={settings.clarity}
              onChange={(e) =>
                onChangeSettings({ ...settings, clarity: parseInt(e.target.value, 10) })
              }
              className="w-full accent-violet-600 h-1.5 bg-zinc-200 dark:bg-zinc-700 rounded-lg cursor-pointer"
            />
          </div>
        </div>

        {/* Advanced FX Toggle & Reset Button */}
        <div className="flex items-center justify-between pt-2 border-t border-zinc-200/70 dark:border-zinc-800">
          <button
            onClick={() => setShowAdvancedEffects(!showAdvancedEffects)}
            className="text-xs font-semibold text-zinc-600 dark:text-zinc-400 hover:text-violet-600 dark:hover:text-violet-400 flex items-center gap-1.5"
          >
            <Sliders className="w-3.5 h-3.5" />
            {showAdvancedEffects ? 'Hide DSP Audio Effects' : 'Custom DSP FX & Filters'}
          </button>

          <button
            onClick={onResetSettings}
            className="text-xs font-medium text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 flex items-center gap-1"
            title="Reset speed and pitch to default"
          >
            <RotateCcw className="w-3 h-3" />
            Reset Defaults
          </button>
        </div>

        {/* DSP Audio FX Toggles */}
        {showAdvancedEffects && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 animate-in fade-in">
            <button
              onClick={() =>
                onChangeSettings({
                  ...settings,
                  effects: {
                    ...settings.effects,
                    alienModulation: !settings.effects.alienModulation,
                  },
                })
              }
              className={`p-2 rounded-lg text-xs font-medium border text-center transition-all ${
                settings.effects.alienModulation
                  ? 'border-emerald-500 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold'
                  : 'border-zinc-200 dark:border-zinc-800 text-zinc-500'
              }`}
            >
              Alien Ring Mod
            </button>

            <button
              onClick={() =>
                onChangeSettings({
                  ...settings,
                  effects: {
                    ...settings.effects,
                    subBassPunch: !settings.effects.subBassPunch,
                  },
                })
              }
              className={`p-2 rounded-lg text-xs font-medium border text-center transition-all ${
                settings.effects.subBassPunch
                  ? 'border-red-500 bg-red-500/10 text-red-600 dark:text-red-400 font-bold'
                  : 'border-zinc-200 dark:border-zinc-800 text-zinc-500'
              }`}
            >
              Monster Sub-Bass
            </button>

            <button
              onClick={() =>
                onChangeSettings({
                  ...settings,
                  effects: {
                    ...settings.effects,
                    arenaEcho: !settings.effects.arenaEcho,
                  },
                })
              }
              className={`p-2 rounded-lg text-xs font-medium border text-center transition-all ${
                settings.effects.arenaEcho
                  ? 'border-cyan-500 bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 font-bold'
                  : 'border-zinc-200 dark:border-zinc-800 text-zinc-500'
              }`}
            >
              Arena Echo
            </button>

            <button
              onClick={() =>
                onChangeSettings({
                  ...settings,
                  effects: {
                    ...settings.effects,
                    whisperFilter: !settings.effects.whisperFilter,
                  },
                })
              }
              className={`p-2 rounded-lg text-xs font-medium border text-center transition-all ${
                settings.effects.whisperFilter
                  ? 'border-violet-500 bg-violet-500/10 text-violet-600 dark:text-violet-400 font-bold'
                  : 'border-zinc-200 dark:border-zinc-800 text-zinc-500'
              }`}
            >
              Whisper Filter
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
