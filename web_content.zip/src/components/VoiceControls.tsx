import React, { useState } from 'react';
import {
  Gauge,
  Music2,
  Volume2,
  Clock,
  RotateCcw,
  Sparkles,
  Bookmark,
  BookmarkPlus,
  Trash2,
  Check,
  UserCheck,
  Wand2,
  Radio,
} from 'lucide-react';
import { NarrationStyleId, UserPreset, VoiceSettings } from '../types/tts';
import { VOICE_PRESETS, VoicePreset, TELUGU_VOICES, NARRATION_STYLES } from '../data/voicesAndStyles';

interface VoiceControlsProps {
  settings: VoiceSettings;
  onChange: (settings: VoiceSettings) => void;
  onApplyPreset: (preset: VoicePreset) => void;
  activePresetId?: string | null;
  // Personal presets
  currentVoiceId: string;
  currentNarrationStyle: NarrationStyleId;
  userPresets: UserPreset[];
  onApplyUserPreset: (preset: UserPreset) => void;
  onDeleteUserPreset: (presetId: string) => void;
  onOpenSavePresetModal: () => void;
}

export const VoiceControls: React.FC<VoiceControlsProps> = ({
  settings,
  onChange,
  onApplyPreset,
  activePresetId,
  currentVoiceId,
  currentNarrationStyle,
  userPresets,
  onApplyUserPreset,
  onDeleteUserPreset,
  onOpenSavePresetModal,
}) => {
  const [presetTab, setPresetTab] = useState<'system' | 'custom'>('system');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  React.useEffect(() => {
    if (activePresetId && userPresets.some((p) => p.id === activePresetId)) {
      setPresetTab('custom');
    }
  }, [activePresetId, userPresets]);

  const handleReset = () => {
    onChange({
      speed: 1.0,
      pitch: 0,
      volume: 100,
      sentencePause: 0.4,
      paragraphPause: 0.8,
      emphasis: 'moderate',
    });
  };

  const handleDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    onDeleteUserPreset(id);
    setDeletingId(null);
  };

  return (
    <div className="w-full bg-[#101522] border border-slate-800/90 rounded-2xl p-4 sm:p-5 shadow-xl shadow-black/40">
      {/* Header & Reset */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div>
          <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <span>వాయిస్ నియంత్రణలు</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
              Voice Controls
            </span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            వేగం, పిచ్, వాల్యూమ్ మరియు విరామ సమయాన్ని అనుకూలీకరించండి
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Quick Save Preset Button */}
          <button
            id="btn-open-save-preset"
            type="button"
            onClick={onOpenSavePresetModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-cyan-300 hover:text-cyan-200 bg-cyan-950/60 border border-cyan-500/40 hover:bg-cyan-900/50 transition-all cursor-pointer shadow-sm shadow-cyan-950/40"
            title="ప్రస్తుత కాంబినేషన్‌ను మీ వ్యక్తిగత ప్రీసెట్‌గా భద్రపరచుకోండి"
          >
            <BookmarkPlus className="w-3.5 h-3.5 text-cyan-400" />
            <span>ప్రీసెట్ సేవ్ చేయండి (Save As Preset)</span>
          </button>

          {/* Reset button */}
          <button
            type="button"
            onClick={handleReset}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-slate-200 bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer"
            title="Reset to default settings"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>రీసెట్</span>
          </button>
        </div>
      </div>

      {/* Voice Presets Navigation & Tabs */}
      <div className="mb-5">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-xs font-semibold text-slate-300">వాయిస్ ప్రీసెట్‌లు (Presets):</span>
          </div>

          {/* Tab buttons: System vs Custom */}
          <div className="flex items-center bg-slate-900/90 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              id="tab-system-presets"
              type="button"
              onClick={() => setPresetTab('system')}
              className={`px-3 py-1 rounded-lg font-medium transition-all cursor-pointer ${
                presetTab === 'system'
                  ? 'bg-slate-800 text-cyan-300 shadow-sm font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              సిస్టమ్ ప్రీసెట్‌లు ({VOICE_PRESETS.length})
            </button>
            <button
              id="tab-user-presets"
              type="button"
              onClick={() => setPresetTab('custom')}
              className={`px-3 py-1 rounded-lg font-medium transition-all cursor-pointer flex items-center gap-1.5 ${
                presetTab === 'custom'
                  ? 'bg-slate-800 text-cyan-300 shadow-sm font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Bookmark className="w-3 h-3 text-cyan-400" />
              <span>నా ప్రీసెట్‌లు</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                  userPresets.length > 0
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                    : 'bg-slate-800 text-slate-500'
                }`}
              >
                {userPresets.length}
              </span>
            </button>
          </div>
        </div>

        {/* Tab 1: System Presets Grid */}
        {presetTab === 'system' && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 animate-fade-in">
            {VOICE_PRESETS.map((preset) => {
              const isActive = activePresetId === preset.id;
              return (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => onApplyPreset(preset)}
                  className={`flex items-center gap-2 p-2 rounded-xl text-xs font-medium text-left border transition-all cursor-pointer ${
                    isActive
                      ? 'bg-cyan-500/15 border-cyan-500/70 text-cyan-300 shadow-sm ring-1 ring-cyan-500/30'
                      : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-900'
                  }`}
                >
                  <span className="text-base">
                    {preset.name.includes('Cinematic')
                      ? '🎬'
                      : preset.name.includes('Emotional')
                      ? '❤️'
                      : preset.name.includes('Motivational')
                      ? '🔥'
                      : preset.name.includes('News')
                      ? '📰'
                      : preset.name.includes('Podcast')
                      ? '🎙️'
                      : preset.name.includes('Story')
                      ? '📖'
                      : preset.name.includes('Educational')
                      ? '🧠'
                      : preset.name.includes('Devotional')
                      ? '🪔'
                      : preset.name.includes('Poetry')
                      ? '🪶'
                      : preset.name.includes('Dialogue')
                      ? '💬'
                      : preset.name.includes('YouTube')
                      ? '📹'
                      : preset.name.includes('Kids')
                      ? '🌟'
                      : preset.name.includes('Sports')
                      ? '⚡'
                      : preset.name.includes('Whisper')
                      ? '🍃'
                      : '🌙'}
                  </span>
                  <div className="truncate">
                    <div className="font-bold text-slate-100 truncate">{preset.name}</div>
                    <div className="text-[10px] text-slate-400 font-telugu truncate">{preset.teluguName}</div>
                  </div>
                </button>
              );
            })}
          </div>
        )}

        {/* Tab 2: User Personal Custom Presets */}
        {presetTab === 'custom' && (
          <div className="animate-fade-in">
            {userPresets.length === 0 ? (
              <div className="p-4 rounded-xl bg-slate-900/50 border border-dashed border-slate-800 text-center space-y-2">
                <div className="w-8 h-8 rounded-full bg-cyan-500/10 text-cyan-400 mx-auto flex items-center justify-center">
                  <BookmarkPlus className="w-4 h-4" />
                </div>
                <div className="text-xs font-medium text-slate-300">
                  ఇంకా వ్యక్తిగత ప్రీసెట్‌లు ఏవీ సేవ్ చేయలేదు
                </div>
                <p className="text-[11px] text-slate-400 max-w-md mx-auto">
                  మీకిష్టమైన తెలుగు గళం, కథా శైలి మరియు వేగం/పిచ్ సెట్టింగ్‌లను ఒక్కసారి కాన్ఫిగర్ చేసి భవిష్యత్తు అవసరాల కోసం లోకల్ స్టోరేజ్‌లో సేవ్ చేసుకోండి.
                </p>
                <button
                  type="button"
                  onClick={onOpenSavePresetModal}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-all cursor-pointer shadow-md shadow-cyan-500/20 mt-1"
                >
                  <BookmarkPlus className="w-3.5 h-3.5" />
                  <span>ప్రస్తుత సెట్టింగ్‌లను ఇప్పుడే సేవ్ చేయండి (Save Now)</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                {userPresets.map((preset) => {
                  const isActive = activePresetId === preset.id;
                  const matchedVoice = TELUGU_VOICES.find((v) => v.id === preset.voiceId);
                  const matchedStyle = NARRATION_STYLES.find((s) => s.id === preset.narrationStyle);

                  return (
                    <div
                      key={preset.id}
                      onClick={() => onApplyUserPreset(preset)}
                      className={`relative group flex flex-col justify-between p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                        isActive
                          ? 'bg-cyan-950/40 border-cyan-500/70 text-cyan-300 shadow-md shadow-cyan-950/50 ring-1 ring-cyan-500/40'
                          : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 hover:bg-slate-900 text-slate-200'
                      }`}
                    >
                      {/* Top row: Name & Actions */}
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <div className={`p-1.5 rounded-lg ${isActive ? 'bg-cyan-500/20 text-cyan-300' : 'bg-slate-800 text-slate-400'}`}>
                            <Bookmark className="w-3.5 h-3.5" />
                          </div>
                          <div className="min-w-0">
                            <div className="font-bold text-xs text-slate-100 truncate flex items-center gap-1.5">
                              <span>{preset.name}</span>
                              {isActive && (
                                <span className="text-[9px] bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 px-1 py-0.2 rounded font-medium">
                                  యాక్టివ్
                                </span>
                              )}
                            </div>
                            <div className="text-[10px] text-slate-400">
                              {new Date(preset.createdAt).toLocaleDateString()}
                            </div>
                          </div>
                        </div>

                        {/* Delete button */}
                        <button
                          type="button"
                          onClick={(e) => handleDelete(e, preset.id)}
                          className="p-1 rounded-md text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-colors opacity-80 group-hover:opacity-100 cursor-pointer"
                          title="ఈ ప్రీసెట్‌ను తొలగించండి (Delete Preset)"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Details badges */}
                      <div className="mt-2 pt-2 border-t border-slate-800/80 flex flex-wrap items-center gap-1.5 text-[10px]">
                        <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-medium">
                          🎙️ {matchedVoice ? matchedVoice.teluguName : preset.voiceId}
                        </span>
                        <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-medium">
                          ✨ {matchedStyle ? matchedStyle.teluguName : preset.narrationStyle}
                        </span>
                        <span className="px-1.5 py-0.5 rounded bg-cyan-950/80 text-cyan-300 font-mono font-medium border border-cyan-900/60">
                          {preset.settings.speed}x • P:{preset.settings.pitch > 0 ? `+` : ''}{preset.settings.pitch}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Main Sliders Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-3 border-t border-slate-800/80">
        {/* Speed Slider */}
        <div className="bg-slate-900/60 p-3.5 rounded-xl border border-slate-800">
          <div className="flex items-center justify-between text-xs font-semibold mb-2">
            <span className="text-slate-300 flex items-center gap-1.5">
              <Gauge className="w-3.5 h-3.5 text-cyan-400" />
              <span>వేగం (Speed)</span>
            </span>
            <span className="font-mono text-cyan-300 bg-cyan-950/60 px-1.5 py-0.5 rounded border border-cyan-500/30">
              {settings.speed.toFixed(2)}x
            </span>
          </div>
          <input
            id="slider-speed"
            type="range"
            min="0.5"
            max="2.0"
            step="0.05"
            value={settings.speed}
            onChange={(e) => onChange({ ...settings, speed: parseFloat(e.target.value) })}
            className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
          />
          <div className="flex justify-between text-[10px] text-slate-500 mt-1 font-mono">
            <span>0.5x</span>
            <span>1.0x (సాధారణం)</span>
            <span>2.0x</span>
          </div>
        </div>

        {/* Pitch Slider */}
        <div className="bg-slate-900/60 p-3.5 rounded-xl border border-slate-800">
          <div className="flex items-center justify-between text-xs font-semibold mb-2">
            <span className="text-slate-300 flex items-center gap-1.5">
              <Music2 className="w-3.5 h-3.5 text-blue-400" />
              <span>పిచ్ (Pitch)</span>
            </span>
            <span className="font-mono text-blue-300 bg-blue-950/60 px-1.5 py-0.5 rounded border border-blue-500/30">
              {settings.pitch > 0 ? `+${settings.pitch}` : settings.pitch}
            </span>
          </div>
          <input
            id="slider-pitch"
            type="range"
            min="-10"
            max="10"
            step="1"
            value={settings.pitch}
            onChange={(e) => onChange({ ...settings, pitch: parseInt(e.target.value, 10) })}
            className="w-full accent-blue-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
          />
          <div className="flex justify-between text-[10px] text-slate-500 mt-1 font-mono">
            <span>-10 (గంభీరం)</span>
            <span>0</span>
            <span>+10 (తీవ్రం)</span>
          </div>
        </div>

        {/* Volume Slider */}
        <div className="bg-slate-900/60 p-3.5 rounded-xl border border-slate-800">
          <div className="flex items-center justify-between text-xs font-semibold mb-2">
            <span className="text-slate-300 flex items-center gap-1.5">
              <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>ధ్వని పరిమాణం (Volume)</span>
            </span>
            <span className="font-mono text-emerald-300 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-500/30">
              {settings.volume}%
            </span>
          </div>
          <input
            id="slider-volume"
            type="range"
            min="0"
            max="100"
            step="1"
            value={settings.volume}
            onChange={(e) => onChange({ ...settings, volume: parseInt(e.target.value, 10) })}
            className="w-full accent-emerald-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
          />
          <div className="flex justify-between text-[10px] text-slate-500 mt-1 font-mono">
            <span>0%</span>
            <span>50%</span>
            <span>100%</span>
          </div>
        </div>

        {/* Sentence Pause Slider */}
        <div className="bg-slate-900/60 p-3.5 rounded-xl border border-slate-800">
          <div className="flex items-center justify-between text-xs font-semibold mb-2">
            <span className="text-slate-300 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-purple-400" />
              <span>వాక్య విరామం (Pause)</span>
            </span>
            <span className="font-mono text-purple-300 bg-purple-950/60 px-1.5 py-0.5 rounded border border-purple-500/30">
              {settings.sentencePause.toFixed(2)}s
            </span>
          </div>
          <input
            id="slider-pause"
            type="range"
            min="0.1"
            max="2.0"
            step="0.05"
            value={settings.sentencePause}
            onChange={(e) => onChange({ ...settings, sentencePause: parseFloat(e.target.value) })}
            className="w-full accent-purple-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
          />
          <div className="flex justify-between text-[10px] text-slate-500 mt-1 font-mono">
            <span>0.1s</span>
            <span>0.4s (డిఫాల్ట్)</span>
            <span>2.0s</span>
          </div>
        </div>
      </div>

      {/* Advanced Audio DSP & Human Breathing Row */}
      <div className="mt-4 pt-3.5 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* DSP Studio Enhancer Selector */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-slate-400 flex items-center gap-1.5 font-medium">
            <Wand2 className="w-3.5 h-3.5 text-amber-400" />
            <span>ఆడియో ఎన్‌హాన్సర్ (DSP Polish):</span>
          </span>
          <div className="flex items-center bg-slate-900 p-1 rounded-xl border border-slate-800 gap-1">
            {[
              { id: 'none', label: 'సహజం (Raw)' },
              { id: 'studio', label: '📻 స్టూడియో (Broadcast)' },
              { id: 'cinematic-bass', label: '🎬 సినిమా బేస్ (Bass)' },
              { id: 'vocal-warmth', label: '🎙️ వార్మ్‌త్ (Warm)' },
              { id: 'crisp', label: '✨ క్రిస్ప్ (Crisp)' },
            ].map((dsp) => (
              <button
                key={dsp.id}
                type="button"
                onClick={() => onChange({ ...settings, dspEffect: dsp.id as any })}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                  (settings.dspEffect || 'none') === dsp.id
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {dsp.label}
              </button>
            ))}
          </div>
        </div>

        {/* Natural Human Breathing Cadence Switch */}
        <label className="flex items-center gap-2 text-slate-300 cursor-pointer select-none bg-slate-900/80 px-3 py-1.5 rounded-xl border border-slate-800 hover:border-slate-700">
          <input
            type="checkbox"
            checked={settings.humanBreathing !== false}
            onChange={(e) => onChange({ ...settings, humanBreathing: e.target.checked })}
            className="accent-cyan-400 w-3.5 h-3.5 rounded cursor-pointer"
          />
          <span className="text-xs font-medium text-slate-200">
            సహజ మానవ శ్వాస & విరామ లయ (Human Breath Cadence)
          </span>
        </label>
      </div>
    </div>
  );
};
