import React, { useState, useEffect } from 'react';
import { Calendar, MapPin, MessageCircle, User, Sparkles, Copy, Check, Tag } from 'lucide-react';

interface BookingFormProps {
  selectedServiceId?: string;
}

export const BookingForm: React.FC<BookingFormProps> = ({ selectedServiceId }) => {
  const [name, setName] = useState('');
  const [eventOption, setEventOption] = useState('Birthday Party - 120K');
  const [date, setDate] = useState('');
  const [place, setPlace] = useState('Kyebando, Kawempe, Kampala');
  const [copied, setCopied] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  // Sync when selected from outside
  useEffect(() => {
    if (selectedServiceId === 'party') setEventOption('Birthday Party - 120K');
    if (selectedServiceId === 'club') setEventOption('Night Club - 150K');
    if (selectedServiceId === 'kwanjula') setEventOption('Kwanjula & Kuhingira - 200K');
    if (selectedServiceId === 'wedding') setEventOption('Wedding - 300K');
    if (selectedServiceId === 'drops') setEventOption('DJ Drops - 7K');
    if (selectedServiceId === 'crossdj') setEventOption('CrossDJ Pro - 15K');
    if (selectedServiceId === 'djay') setEventOption('Djay App - 10K');
    if (selectedServiceId === 'virtualdj') setEventOption('Virtual DJ - 20K');
    if (selectedServiceId === 'phones') setEventOption('Phone Business');
  }, [selectedServiceId]);

  const generateWhatsAppMessage = () => {
    const n = name.trim() || 'Boss';
    const e = eventOption;
    const d = date || 'To be discussed';
    const p = place.trim() || 'Kyebando, Kawempe, Kampala';

    return `Hello DJ EVAN PRO UG THE CUE KING 👑\n\nI am ${n}\nEvent: ${e}\nDate: ${d}\nLocation: ${p} (Kyebando, Kawempe, Kampala)\n\nI want to buy/book. What is your last price?`;
  };

  const handleBook = (e: React.FormEvent) => {
    e.preventDefault();
    const msg = generateWhatsAppMessage();
    const url = `https://wa.me/256742094651?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
    setSubmitted(true);
  };

  const handleCopy = () => {
    const msg = generateWhatsAppMessage();
    navigator.clipboard.writeText(msg);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <section id="booking" className="py-12 px-4 max-w-3xl mx-auto">
      <div className="bg-[#120a24] p-6 sm:p-8 rounded-3xl border border-purple-600/40 shadow-2xl relative">
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-950 text-purple-300 text-xs font-bold uppercase tracking-wider mb-2 border border-purple-800">
            <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
            Special Kyebando Discount
          </div>
          <h2 className="text-2xl sm:text-3xl font-black uppercase text-white tracking-tight">
            📅 Book Now — Get Discount Today
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Choose your service or app, pick your date, and chat directly with DJ Evan Pro.
          </p>
        </div>

        <form onSubmit={handleBook} className="space-y-3">
          <div>
            <label className="text-xs font-bold text-slate-300 block mb-1">
              Your Name
            </label>
            <input
              id="name"
              type="text"
              required
              placeholder="Your Name (e.g. Ronald, Sarah)"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full p-3 rounded-xl bg-zinc-800 text-white border border-zinc-700 text-sm focus:outline-none focus:border-cyan-400 transition-colors"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1">
                Select Service / Product
              </label>
              <select
                id="event"
                value={eventOption}
                onChange={(e) => setEventOption(e.target.value)}
                className="w-full p-3 rounded-xl bg-zinc-800 text-white border border-zinc-700 text-sm focus:outline-none focus:border-cyan-400 transition-colors"
              >
                <option value="Birthday Party - 120K">Birthday Party - 120K</option>
                <option value="Night Club - 150K">Night Club - 150K</option>
                <option value="Kwanjula & Kuhingira - 200K">Kwanjula & Kuhingira - 200K</option>
                <option value="Wedding - 300K">Wedding - 300K</option>
                <option value="DJ Drops - 7K">DJ Drops - 7K</option>
                <option value="CrossDJ Pro - 15K">CrossDJ Pro - 15K</option>
                <option value="Djay App - 10K">Djay App - 10K</option>
                <option value="Virtual DJ - 20K">Virtual DJ - 20K</option>
                <option value="Phone Business">Phone Business</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1">
                Event / Pickup Date
              </label>
              <input
                id="date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full p-3 rounded-xl bg-zinc-800 text-white border border-zinc-700 text-sm focus:outline-none focus:border-cyan-400 transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-300 block mb-1">
              Location in Kampala / Wakiso / Mukono
            </label>
            <input
              id="place"
              type="text"
              required
              placeholder="Location e.g Kyebando, Kawempe, Kampala"
              value={place}
              onChange={(e) => setPlace(e.target.value)}
              className="w-full p-3 rounded-xl bg-zinc-800 text-white border border-zinc-700 text-sm focus:outline-none focus:border-cyan-400 transition-colors"
            />
          </div>

          {/* Big Action Button */}
          <button
            type="submit"
            className="w-full bg-gradient-to-r from-purple-600 via-fuchsia-600 to-cyan-500 hover:brightness-110 py-4 rounded-full font-black text-base sm:text-xl text-white shadow-[0_0_35px_rgba(168,85,247,0.4)] active:scale-95 transition-all mt-4 flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>BOOK ON WHATSAPP 🚀</span>
          </button>

          <div className="flex items-center justify-between text-xs text-slate-400 pt-2">
            <span>Direct to +256 742 094 651</span>
            <button
              type="button"
              onClick={handleCopy}
              className="text-purple-300 hover:text-white flex items-center gap-1"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied Message!' : 'Copy Pre-filled Text'}</span>
            </button>
          </div>
        </form>

        {submitted && (
          <div className="mt-4 p-3 bg-emerald-950/80 border border-emerald-500 rounded-xl text-emerald-200 text-xs text-center">
            WhatsApp opened! If not, <a href={`https://wa.me/256742094651?text=${encodeURIComponent(generateWhatsAppMessage())}`} target="_blank" className="underline font-bold">click here to send directly</a>.
          </div>
        )}
      </div>
    </section>
  );
};
