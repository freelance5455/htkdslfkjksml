import { useMemo, useRef, useState } from "react";
import JSZip from "jszip";
import { AlertTriangle, CheckCircle2, Download, FileJson, FileUp, Link2, Music2, Upload } from "lucide-react";
import type { MediaMeta } from "@/types";
import { useStudio } from "@/store/StudioContext";
import { downloadBlob, errorMessage, isAudioName, isImageName } from "@/lib/media";
import { newEmptyQuestion } from "@/data/defaults";
import { Button, InlineNotice, Modal, Segmented } from "@/components/ui";

type Role = "question" | "options" | "answer" | "image" | "combined";

interface ParsedQuestion {
  question: string;
  options: string[];
  correct: number;
  thinkSec: number;
  revealHoldMs: number;
  names: Partial<Record<Role, string>>;
  issues: string[];
}

interface MatchedFile {
  file: File;
  name: string;
  role: Role | null;
  questionIndex: number | null;
  explicit: boolean;
}

const ROLE_LABEL: Record<Role, string> = {
  question: "صوت السؤال",
  options: "صوت الخيارات",
  answer: "صوت الإجابة",
  image: "صورة السؤال",
  combined: "صوت موحّد",
};

function dateSuffix() {
  return new Date().toISOString().slice(0, 10);
}

export function ImportQuestionsDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { project, updateProject, addMediaFromBlob, toast } = useStudio();
  const [jsonText, setJsonText] = useState("");
  const [jsonName, setJsonName] = useState("");
  const [parsed, setParsed] = useState<ParsedQuestion[]>([]);
  const [parseError, setParseError] = useState<string | null>(null);
  const [files, setFiles] = useState<File[]>([]);
  const [mode, setMode] = useState<"append" | "replace">("append");
  const [importing, setImporting] = useState(false);
  const [duplicateConfirm, setDuplicateConfirm] = useState(false);
  const [lastResult, setLastResult] = useState<string | null>(null);
  const jsonRef = useRef<HTMLInputElement>(null);
  const mediaRef = useRef<HTMLInputElement>(null);
  const zipRef = useRef<HTMLInputElement>(null);

  const parse = (text: string, sourceName: string) => {
    setParseError(null);
    setLastResult(null);
    try {
      const raw: unknown = JSON.parse(text);
      const extracted = raw && typeof raw === "object" && !Array.isArray(raw) ? (raw as Record<string, unknown>).questions : undefined;
      const list: unknown[] | null = Array.isArray(raw) ? raw : Array.isArray(extracted) ? extracted : null;
      if (!list) throw new Error("الملف يجب أن يحتوي على مصفوفة questions أو مصفوفة أسئلة مباشرة.");
      if (list.length === 0) throw new Error("ملف JSON لا يحتوي على أي سؤال.");
      const next = list.map((item: unknown, index: number) => normalizeQuestion(item, index));
      const valid = next.filter((item) => item.question.trim() || item.options.some((option) => option.trim()));
      if (!valid.length) throw new Error("لم يُعثر على نص سؤال صالح في الملف.");
      setParsed(valid);
      setJsonName(sourceName);
      setJsonText(text);
      toast(`قُرئ ${valid.length} سؤالًا من JSON. ارفع الملفات أو ابدأ المطابقة التلقائية.`, "success");
    } catch (error) {
      setParsed([]);
      setParseError(errorMessage(error, "تعذّر قراءة JSON. تأكد من صحة الصياغة."));
    }
  };

  const loadJsonFile = async (file: File | undefined) => {
    if (!file) return;
    if (!/\.json$/i.test(file.name) && !file.type.includes("json")) {
      setParseError("اختر ملفًا بصيغة JSON.");
      return;
    }
    try {
      parse(await file.text(), file.name);
    } catch (error) {
      setParseError(errorMessage(error, "تعذّرت قراءة الملف."));
    } finally {
      if (jsonRef.current) jsonRef.current.value = "";
    }
  };

  const loadMedia = async (picked: FileList | null) => {
    if (!picked?.length) return;
    const next = [...files];
    for (const file of Array.from(picked)) {
      if (isAudioName(file.name, file.type) || isImageName(file.name, file.type)) {
        if (!next.some((entry) => entry.name.toLowerCase() === file.name.toLowerCase())) next.push(file);
      }
    }
    setFiles(next);
    if (mediaRef.current) mediaRef.current.value = "";
    toast(`${next.length} ملفًا في قائمة المطابقة.`, "info");
  };

  const loadZip = async (file: File | undefined) => {
    if (!file) return;
    try {
      const zip = await JSZip.loadAsync(file);
      const next = [...files];
      let jsonFound = false;
      for (const entry of Object.values(zip.files)) {
        if (entry.dir) continue;
        const base = entry.name.split("/").pop() ?? entry.name;
        if (/\.json$/i.test(base) && !jsonFound) {
          const text = await entry.async("text");
          try {
            parse(text, base);
            jsonFound = true;
            continue;
          } catch {
            /* ملف JSON آخر */
          }
        }
        if (!isAudioName(base) && !isImageName(base)) continue;
        if (next.some((item) => item.name.toLowerCase() === base.toLowerCase())) continue;
        const blob = await entry.async("blob");
        const type = base.endsWith(".mp3") ? "audio/mpeg" : base.endsWith(".wav") ? "audio/wav" : base.endsWith(".m4a") ? "audio/mp4" : base.endsWith(".png") ? "image/png" : base.endsWith(".jpg") || base.endsWith(".jpeg") ? "image/jpeg" : blob.type;
        next.push(new File([blob], base, { type }));
      }
      setFiles(next);
      toast(jsonFound ? "قُرئ المشروع من ZIP مع ملفات الصوت." : "استُخرجت ملفات ZIP. لم يُعثر على JSON بداخلها.", jsonFound ? "success" : "info");
    } catch (error) {
      setParseError(errorMessage(error, "تعذّر فتح ZIP. تأكد أن الملف غير تالف."));
    } finally {
      if (zipRef.current) zipRef.current.value = "";
    }
  };

  const matched = useMemo<MatchedFile[]>(() => {
    const consume = new Set<string>();
    const result: MatchedFile[] = [];
    // أولًا: مطابقة الأسماء المذكورة صراحة داخل JSON
    parsed.forEach((question, questionIndex) => {
      for (const role of Object.keys(question.names) as Role[]) {
        const expected = question.names[role];
        if (!expected) continue;
        const file = files.find((item) => item.name.toLowerCase() === expected.toLowerCase() || item.name.toLowerCase().endsWith(expected.toLowerCase()));
        if (file && !consume.has(file.name)) {
          consume.add(file.name);
          result.push({ file, name: file.name, role, questionIndex, explicit: true });
        }
      }
    });
    for (const file of files) {
      if (consume.has(file.name)) continue;
      const key = filenameKey(file.name);
      if (key && key.questionIndex >= 1 && key.questionIndex <= parsed.length) {
        result.push({ file, name: file.name, role: key.role, questionIndex: key.questionIndex - 1, explicit: false });
        consume.add(file.name);
      } else {
        result.push({ file, name: file.name, role: null, questionIndex: null, explicit: false });
      }
    }
    return result;
  }, [files, parsed]);

  const duplicateNames = useMemo(() => {
    const existing = new Set(Object.values(project.media).map((meta) => meta.name.toLowerCase()));
    return matched.filter((entry) => existing.has(entry.name.toLowerCase()));
  }, [matched, project.media]);

  const unmatched = matched.filter((entry) => !entry.role || entry.questionIndex === null);
  const missingSlots: { label: string; questionIndex: number; role: Role }[] = [];
  parsed.forEach((_question, questionIndex) => {
    (["question", "options"] as Role[]).forEach((role) => {
      const found = matched.some((entry) => entry.role === role && entry.questionIndex === questionIndex);
      if (!found) missingSlots.push({ label: `السؤال ${questionIndex + 1} — ${ROLE_LABEL[role]}`, questionIndex, role });
    });
  });

  const apply = async (confirmedDuplicates = false) => {
    if (!parsed.length) {
      setParseError("لم يتم تحميل أسئلة صالحة بعد.");
      return;
    }
    if (duplicateNames.length && !confirmedDuplicates) {
      setDuplicateConfirm(true);
      return;
    }
    setImporting(true);
    setLastResult(null);
    const createdMeta: MediaMeta[] = [];
    const failed: string[] = [];
    const byKey = new Map<string, string>();
    for (const entry of matched) {
      if (entry.questionIndex === null || !entry.role) continue;
      try {
        const meta = await addMediaFromBlob(entry.file, entry.name, { kind: entry.role === "image" ? "image" : "audio" });
        createdMeta.push(meta);
        byKey.set(`${entry.questionIndex}:${entry.role}`, meta.id);
      } catch (error) {
        failed.push(`${entry.name}: ${errorMessage(error)}`);
      }
    }
    const questions = parsed.map((question, index) => {
      const base = newEmptyQuestion(question.thinkSec);
      return {
        ...base,
        question: question.question,
        options: question.options,
        correct: question.correct,
        thinkSec: question.thinkSec,
        revealHoldMs: question.revealHoldMs,
        questionAudioId: byKey.get(`${index}:question`) ?? null,
        optionsAudioId: byKey.get(`${index}:options`) ?? null,
        combinedAudioId: byKey.get(`${index}:combined`) ?? null,
        answerAudioId: byKey.get(`${index}:answer`) ?? null,
        imageId: byKey.get(`${index}:image`) ?? null,
      };
    });
    try {
      updateProject((current) => ({
        ...current,
        isSample: false,
        questions: mode === "append" ? [...current.questions, ...questions] : questions,
      }));
      const totalLinked = questions.filter(
        (question) => question.questionAudioId || question.optionsAudioId || question.combinedAudioId || question.answerAudioId || question.imageId,
      ).length;
      const message = `استُوردت ${questions.length} أسئلة${mode === "append" ? " إلى المشروع" : " بدلًا من الأسئلة السابقة"}، ورُبطت ملفات ${totalLinked} سؤالًا. ${
        unmatched.length ? `${unmatched.length} ملفًا لم يُطابق.` : ""
      } ${failed.length ? `فشل رفع ${failed.length} ملفًا.` : ""}`;
      setLastResult(message);
      toast(message, failed.length || unmatched.length ? "warning" : "success");
      if (!failed.length) {
        setDuplicateConfirm(false);
        onClose();
      }
      setFiles([]);
      setParsed([]);
      setJsonText("");
      setJsonName("");
    } catch (error) {
      setParseError(errorMessage(error, "تعذّر تحديث المشروع بالأسئلة المستوردة."));
    } finally {
      setImporting(false);
    }
  };

  const downloadTemplate = () => {
    const template = {
      instructions: [
        "أضف الأسئلة بنفس البنية أدناه، ثم ارفع ملفات الصوت من الهاتف.",
        "اسمح للمطابقة التلقائية: q01_question.mp3 وq01_options.mp3 وq01_answer.mp3 وq01.png",
        "correct هو ترتيب الإجابة الصحيحة من 0 إلى 3 (الأول = 0).",
        "يمكن حذف الحقول الاختيارية. استخدم MP3 أو WAV بترميز واضح.",
      ],
      questions: [
        {
          question: "ما هي عاصمة المملكة العربية السعودية؟",
          options: ["الرياض", "جدة", "مكة المكرمة", "الدمام"],
          correct: 0,
          thinkingSec: 8,
          revealHoldMs: 1800,
          question_audio: "q01_question.mp3",
          options_audio: "q01_options.mp3",
          answer_audio: "q01_answer.mp3",
          image: "q01.jpg",
        },
        {
          question: "أي كوكب يُعرف بالكوكب الأحمر؟",
          options: ["المريخ", "الزهرة", "المشتري", "عطارد"],
          correct: 0,
          thinkingSec: 10,
          revealHoldMs: 2000,
          question_audio: "q02_question.mp3",
          options_audio: "q02_options.mp3",
        },
      ],
    };
    downloadBlob(new Blob([JSON.stringify(template, null, 2)], { type: "application/json" }), `quiz-template-${dateSuffix()}.json`);
    toast("نُزّل نموذج JSON. أرفق الملفات بأسماء q01_question.mp3 وq01_options.mp3.", "success");
  };

  const downloadGuide = () => {
    const guide = [
      "Quiz Studio Pro — دليل استيراد الأسئلة والأصوات",
      "",
      "1) بنية JSON",
      '{ "questions": [ { "question": "نص السؤال", "options": ["أ","ب","ج","د"], "correct": 0, "thinkingSec": 8 } ] }',
      "correct: رقم الخيار الصحيح من 0 إلى 3.",
      "",
      "2) تسمية الملفات للمطابقة التلقائية",
      "q01_question.mp3   ← قراءة السؤال الأول",
      "q01_options.mp3    ← قراءة خيارات السؤال الأول",
      "q01_answer.mp3     ← صوت الإجابة الصحيحة (اختياري)",
      "q01.jpg            ← خلفية السؤال الأول (اختياري)",
      "q02_question.mp3 … وهكذا حتى q99.",
      "يمكن استخدام WAV أو M4A. المهم أن يحتوي الاسم على رقم السؤال وكلمة question/options/answer/image.",
      "",
      "3) طريقة الاستيراد",
      "افتح «الأسئلة» ← «استيراد الأسئلة» ← اختر JSON ← ارفع الصوتيات أو ZIP ← راجع المطابقة والمفقود ← استورد.",
      "لن تُستبدل الملفات بنفس الاسم تلقائيًا: يطلب التطبيق تأكيدك.",
      "",
      "4) بعد الاستيراد",
      "راجع الإجابات الصحيحة، ثم اضبط التوقيت من صفحة الصوت، وشاهد المعاينة قبل التصدير.",
    ].join("\n");
    downloadBlob(new Blob([guide], { type: "text/plain;charset=utf-8" }), `quiz-import-guide-${dateSuffix()}.txt`);
    toast("نُزّل دليل التسمية والهيكل.", "success");
  };

  const close = () => {
    if (importing) return;
    onClose();
  };

  return (
    <>
      <Modal
        open={open}
        onClose={close}
        wide
        title="استيراد الأسئلة والأصوات"
        description="استورد JSON منظمًا وملفات صوتية بأسماء q01_question.mp3، أو ZIP يحتوي الاثنين. ستُراجع المطابقة قبل التطبيق."
        footer={
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex gap-1.5">
              <Button variant="quiet" className="!px-2.5 !py-1.5 text-[11px]" onClick={downloadTemplate}>
                <Download size={12} /> نموذج JSON
              </Button>
              <Button variant="quiet" className="!px-2.5 !py-1.5 text-[11px]" onClick={downloadGuide}>
                <Download size={12} /> دليل التسمية
              </Button>
            </div>
            <div className="flex gap-2">
              <Button variant="ghost" onClick={close} disabled={importing}>إغلاق</Button>
              <Button variant="primary" onClick={() => void apply()} loading={importing} disabled={!parsed.length}>
                <FileUp size={14} /> تطبيق الاستيراد ({parsed.length})
              </Button>
            </div>
          </div>
        }
      >
        <div className="space-y-4">
          <div className="grid gap-2.5 sm:grid-cols-3">
            <button type="button" onClick={() => jsonRef.current?.click()} className="flex items-center gap-2.5 rounded-xl border border-white/10 bg-white/[0.02] p-3 text-right transition hover:border-[#d9b65a]/35">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#d9b65a]/10 text-[#e7cf94]"><FileJson size={15} /></span>
              <span><span className="block text-[12px] font-semibold text-white">ملف JSON</span><span className="block text-[10px] text-[#7b7b85]">الأسئلة والإجابات</span></span>
            </button>
            <button type="button" onClick={() => mediaRef.current?.click()} className="flex items-center gap-2.5 rounded-xl border border-white/10 bg-white/[0.02] p-3 text-right transition hover:border-[#57dc96]/35">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#57dc96]/10 text-[#8cebb5]"><Music2 size={15} /></span>
              <span><span className="block text-[12px] font-semibold text-white">ملفات صوت وصور</span><span className="block text-[10px] text-[#7b7b85]">اختيار متعدد من الهاتف</span></span>
            </button>
            <button type="button" onClick={() => zipRef.current?.click()} className="flex items-center gap-2.5 rounded-xl border border-white/10 bg-white/[0.02] p-3 text-right transition hover:border-white/25">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/[0.05] text-[#c9c9d1]"><Upload size={15} /></span>
              <span><span className="block text-[12px] font-semibold text-white">ملف ZIP</span><span className="block text-[10px] text-[#7b7b85]">JSON + ملفات المشروع</span></span>
            </button>
          </div>
          <input ref={jsonRef} type="file" accept=".json,application/json" className="hidden" onChange={(event) => void loadJsonFile(event.target.files?.[0])} />
          <input ref={mediaRef} type="file" accept="audio/*,image/*" multiple className="hidden" onChange={(event) => void loadMedia(event.target.files)} />
          <input ref={zipRef} type="file" accept=".zip,application/zip" className="hidden" onChange={(event) => void loadZip(event.target.files?.[0])} />

          {jsonName ? (
            <div className="flex items-center justify-between gap-2 rounded-lg border border-[#57dc96]/20 bg-[#57dc96]/[0.05] px-3 py-2">
              <span className="flex items-center gap-1.5 text-[11px] text-[#a7ebc4]"><CheckCircle2 size={13} /> {jsonName} · {parsed.length} سؤال</span>
              <span className="text-[10px] text-[#78b795]">{files.length} ملف وسائط</span>
            </div>
          ) : null}
          {parseError ? (
            <div className="flex items-start gap-2 rounded-lg border border-red-400/25 bg-red-400/[0.06] px-3 py-2.5 text-[11px] leading-5 text-red-200">
              <AlertTriangle size={14} className="mt-0.5 shrink-0" /> {parseError}
            </div>
          ) : null}

          {!parsed.length ? (
            <div>
              <p className="label">أو الصق JSON مباشرة</p>
              <textarea
                value={jsonText}
                onChange={(event) => setJsonText(event.target.value)}
                className="field min-h-[120px] font-mono text-[11px] leading-6"
                dir="ltr"
                placeholder={'{\n  "questions": [\n    { "question": "…", "options": ["…","…","…","…"], "correct": 0 }\n  ]\n}'}
              />
              <div className="mt-2 flex items-center justify-between gap-2">
                <p className="text-[10px] leading-5 text-[#74747e]">يُقبل أيضًا JSON يحتوي مصفوفة أسئلة مباشرة أو حقول option1..option4.</p>
                <Button variant="ghost" className="!px-2.5 !py-1.5 text-[11px]" onClick={() => parse(jsonText, "JSON ملصق")} disabled={!jsonText.trim()}>
                  قراءة JSON
                </Button>
              </div>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between gap-2">
                <p className="text-[11px] font-semibold text-[#d8d8de]">مراجعة الملفات والمطابقة</p>
                <span className="chip !py-0.5">{matched.length - unmatched.length} مطابق · {unmatched.length} غير مطابق</span>
              </div>
              <div className="max-h-[220px] space-y-1.5 overflow-y-auto rounded-xl border border-white/[0.07] bg-[#0b0b0e] p-2">
                {matched.length === 0 ? (
                  <p className="px-2 py-6 text-center text-[11px] leading-6 text-[#797983]">
                    لم تُرفع ملفات بعد. المطابقة التلقائية تدعم أمثلة: <span dir="ltr" className="text-[#d9c187]">q01_question.mp3 · q01_options.mp3 · q01_answer.mp3 · q01.png</span>
                  </p>
                ) : null}
                {matched.map((entry) => (
                  <div key={entry.name} className="flex items-center gap-2 rounded-lg border border-white/[0.05] bg-white/[0.02] px-2.5 py-1.5">
                    <Link2 size={12} className={entry.role ? "text-[#7ce1a9]" : "text-[#d9b65a]"} />
                    <span className="min-w-0 flex-1 truncate text-[10px] text-[#c4c4cd]" dir="ltr">{entry.name}</span>
                    {entry.role && entry.questionIndex !== null ? (
                      <span className="shrink-0 rounded-md bg-[#57dc96]/10 px-1.5 py-0.5 text-[9px] text-[#92e9b8]">
                        {ROLE_LABEL[entry.role]} → س {entry.questionIndex + 1}
                      </span>
                    ) : (
                      <span className="shrink-0 rounded-md bg-[#d9b65a]/10 px-1.5 py-0.5 text-[9px] text-[#e7cf94]">اسم غير مطابق</span>
                    )}
                  </div>
                ))}
              </div>

              {missingSlots.length ? (
                <div className="rounded-lg border border-[#d9b65a]/20 bg-[#d9b65a]/[0.05] px-3 py-2.5">
                  <p className="flex items-center gap-1.5 text-[10px] font-semibold text-[#e7cf94]"><AlertTriangle size={12} /> ملفات مفقودة ({missingSlots.length})</p>
                  <p className="mt-1 text-[10px] leading-5 text-[#a8956b]">{missingSlots.slice(0, 4).map((slot) => slot.label).join(" · ")}{missingSlots.length > 4 ? " …" : ""} — يمكنك الاستيراد الآن وإضافتها لاحقًا.</p>
                </div>
              ) : null}
              {duplicateNames.length ? (
                <div className="rounded-lg border border-red-400/25 bg-red-400/[0.06] px-3 py-2 text-[10px] leading-5 text-red-200">
                  <AlertTriangle size={12} className="ml-1 inline" /> يوجد {duplicateNames.length} ملفًا بنفس اسم ملف محفوظ. لن نستبدل القديم بصمت؛ ستظهر نافذة تأكيد قبل الاستيراد.
                </div>
              ) : null}

              <div>
                <p className="label">طريقة الإضافة</p>
                <Segmented value={mode} onChange={setMode} options={[{ value: "append", label: "إضافة إلى الأسئلة الحالية" }, { value: "replace", label: "استبدال كل الأسئلة" }]} />
                {mode === "replace" ? <p className="mt-1.5 text-[10px] leading-5 text-[#d9a97a]">سيُستبدل محتوى الأسئلة الحالية عند التطبيق، لكن ملفات الوسائط السابقة تبقى محفوظة في التخزين.</p> : null}
              </div>
              {lastResult ? <InlineNotice kind="warning" title="نتيجة الاستيراد">{lastResult}</InlineNotice> : null}
            </>
          )}

          <div className="rounded-lg border border-white/[0.07] bg-black/20 p-3 text-[10px] leading-5 text-[#7f7f89]">
            يدعم التطبيق الحقول: <span dir="ltr">question, options, correct, thinkingSec, question_audio, options_audio, answer_audio, image</span>. الحد الأقصى للصوت 250 ميجابايت، وللصورة 30 ميجابايت.
          </div>
        </div>
      </Modal>

      <Modal
        open={duplicateConfirm}
        onClose={() => setDuplicateConfirm(false)}
        title="ملفات بنفس الأسماء"
        description="هذه الملفات موجودة مسبقًا في المشروع. استيرادها سيضيف نسخة جديدة مع رابط جديد، ولن يُستبدل الملف القديم تلقائيًا."
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setDuplicateConfirm(false)}>إلغاء</Button>
            <Button variant="primary" onClick={() => void apply(true)} loading={importing}>
              متابعة كنسخ جديدة
            </Button>
          </div>
        }
      >
        <div className="max-h-52 space-y-1 overflow-y-auto rounded-lg border border-white/10 bg-[#0b0b0e] p-2 text-[11px]">
          {duplicateNames.map((entry) => <p key={entry.name} className="truncate px-1 py-0.5 text-[#d8d8de]" dir="ltr">{entry.name}</p>)}
        </div>
      </Modal>
    </>
  );
}

function filenameKey(name: string): { questionIndex: number; role: Role } | null {
  const lower = decodeURIComponent(name).toLowerCase();
  const match = lower.match(/(?:^|[^0-9])(?:q(?:uestion)?[_\-\s]?)?(\d{1,3})(?:[^0-9]|$)/);
  if (!match) return null;
  const questionIndex = Number(match[1]);
  let role: Role | null = null;
  if (/(image|img|background|bg|صورة)/.test(lower)) role = "image";
  else if (/(answer|correct|reveal|إجابة)/.test(lower)) role = "answer";
  else if (/(option|choice|choices|خيارات)/.test(lower)) role = "options";
  else if (/(question|sawal|سؤال)/.test(lower)) role = "question";
  if (!role) return null;
  return { questionIndex, role };
}

function stringValue(...values: unknown[]): string {
  for (const value of values) if (typeof value === "string" && value.trim()) return value.trim();
  return "";
}

function normalizeQuestion(raw: unknown, _index: number): ParsedQuestion {
  const item = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const optionsArray = Array.isArray(item.options)
    ? item.options
    : Array.isArray(item.choices)
      ? item.choices
      : Array.isArray(item.answers)
        ? item.answers
        : null;
  const options = (optionsArray ? optionsArray.slice(0, 4) : [item.option1, item.option2, item.option3, item.option4]).map((option) =>
    typeof option === "string" ? option.trim() : option && typeof option === "object" ? stringValue((option as Record<string, unknown>).text, (option as Record<string, unknown>).label) : "",
  );
  while (options.length < 4) options.push("");
  let correct = -1;
  const rawCorrect = item.correct ?? item.correctIndex ?? item.answer ?? item.correct_option;
  if (typeof rawCorrect === "number" && rawCorrect >= 0 && rawCorrect < 4) correct = rawCorrect;
  else if (typeof rawCorrect === "string") {
    const trimmed = rawCorrect.trim();
    if (/^[0-3]$/.test(trimmed)) correct = Number(trimmed);
    else if (/^[1-4]$/.test(trimmed)) correct = Number(trimmed) - 1;
    else {
      const latin = "abcd".indexOf(trimmed.toLowerCase());
      const arabic = ["أ", "ب", "ج", "د"].indexOf(trimmed);
      if (latin >= 0) correct = latin;
      else if (arabic >= 0) correct = arabic;
      else correct = options.findIndex((option) => option === trimmed);
    }
  }
  const issues: string[] = [];
  if (!stringValue(item.question, item.text, item.title)) issues.push("نص السؤال مفقود");
  if (options.some((option) => !option)) issues.push("أحد الخيارات فارغ");
  if (correct < 0) issues.push("الإجابة الصحيحة غير محددة");
  const think = Number(item.thinkingSec ?? item.thinkSec ?? item.thinking_time ?? item.think ?? 8);
  const reveal = Number(item.revealHoldMs ?? item.reveal_hold ?? item.revealDuration ?? 1800);
  return {
    question: stringValue(item.question, item.text, item.title),
    options,
    correct,
    thinkSec: Number.isFinite(think) ? Math.max(1, Math.min(120, think)) : 8,
    revealHoldMs: Number.isFinite(reveal) ? Math.max(600, Math.min(10_000, reveal)) : 1800,
    names: {
      question: stringValue(item.question_audio, item.questionAudio, item.audio_question) || undefined,
      options: stringValue(item.options_audio, item.optionsAudio, item.audio_options) || undefined,
      answer: stringValue(item.answer_audio, item.answerAudio, item.correct_audio) || undefined,
      combined: stringValue(item.combined_audio, item.combinedAudio) || undefined,
      image: stringValue(item.image, item.imageName, item.background, item.image_url) || undefined,
    },
    issues,
  };
}
