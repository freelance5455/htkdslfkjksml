import React from 'react';
import { Sparkles, ArrowRight } from 'lucide-react';
import confetti from 'canvas-confetti';
import { triggerHaptic, soundEngine } from '../utils/audio';

interface OfflineModalProps {
  coinsEarned: number;
  secondsAway: number;
  onClaim: (multiplier: number) => void;
}

export const OfflineModal: React.FC<OfflineModalProps> = ({
  coinsEarned,
  secondsAway,
  onClaim,
}) => {
  if (coinsEarned <= 0) return null;

  const minutesAway = Math.round(secondsAway / 60);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-sm bg-slate-900 border border-amber-500/50 rounded-3xl p-5 shadow-2xl text-center space-y-4">
        <div className="w-28 h-28 mx-auto relative rounded-2xl overflow-hidden shadow-lg border border-amber-500/30">
          <img
            src="/src/assets/images/treasure_chest_gold_1791924592727.jpg"
            alt="Treasure Chest"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
        </div>

        <div>
          <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block">
            Welcome Back!
          </span>
          <h2 className="text-lg font-black text-white font-display mt-0.5">
            Your Auto-Miners Were Working!
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            While you were away for {minutesAway} minute{minutesAway === 1 ? '' : 's'}, your bots generated:
          </p>
        </div>

        <div className="py-2.5 bg-slate-950/80 border border-slate-800 rounded-2xl">
          <div className="text-2xl font-black text-amber-400 font-mono-num font-display">
            🪙 +{coinsEarned.toLocaleString()} Coins
          </div>
          <span className="text-xs text-emerald-400 font-bold font-mono-num">
            (Rs. {(coinsEarned / 100).toFixed(2)} Cash Value)
          </span>
        </div>

        <div className="space-y-2 pt-1">
          <button
            onClick={() => {
              triggerHaptic('success');
              soundEngine.playCrit();
              confetti({ particleCount: 50, spread: 70 });
              onClaim(2);
            }}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-slate-950 font-black text-xs hover:brightness-105 transition-all shadow-lg shadow-amber-500/20 flex items-center justify-center gap-1.5 active:scale-95"
          >
            <Sparkles className="w-4 h-4 fill-slate-950" />
            <span>Claim 2x Double Reward (+{(coinsEarned * 2).toLocaleString()})</span>
          </button>

          <button
            onClick={() => {
              triggerHaptic('light');
              soundEngine.playCoin();
              onClaim(1);
            }}
            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors"
          >
            Collect Regular (+{coinsEarned.toLocaleString()})
          </button>
        </div>
      </div>
    </div>
  );
};
