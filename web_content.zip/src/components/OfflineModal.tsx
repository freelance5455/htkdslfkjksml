import { useGame } from '../context/GameContext';
import { formatNumber, formatTime } from '../utils/formatters';
import { Sparkles, Coins, Crown } from 'lucide-react';

export function OfflineModal() {
  const { offlineReport, dismissOfflineReport, numberFormat } = useGame();

  if (!offlineReport) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-12 sm:pt-16 p-4 bg-black/90 animate-in fade-in duration-200">
      <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-amber-600/50 p-6 sm:p-8 shadow-2xl relative text-center">
        {/* Glow halo (GPU-safe radial gradient) */}
        <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-24 h-24 rounded-full bg-[radial-gradient(circle,_rgba(245,158,11,0.25)_0%,_transparent_70%)] pointer-events-none" />

        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500/30 to-amber-950/60 border border-amber-500/50 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-amber-950/50">
          <Crown className="w-8 h-8 text-amber-400" />
        </div>

        <div className="text-xs uppercase font-semibold tracking-wider text-amber-400 mb-1">
          The Sovereign Returns
        </div>
        <h2 className="font-cinzel text-2xl sm:text-3xl font-extrabold text-amber-100">
          Royal Tithes Collected!
        </h2>

        <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
          While you rested for{' '}
          <strong className="text-amber-300 font-semibold">
            {formatTime(offlineReport.secondsOffline)}
          </strong>
          , your commissioned Guildmasters diligently oversaw kingdom production:
        </p>

        <div className="my-6 p-4 rounded-2xl bg-slate-950 border border-amber-900/40 shadow-inner flex items-center justify-center gap-3">
          <Coins className="w-7 h-7 text-amber-400 animate-bounce" />
          <div className="font-cinzel text-2xl sm:text-3xl font-black text-amber-200 tabular-nums">
            +{formatNumber(offlineReport.goldEarned, numberFormat)}
          </div>
          <span className="text-amber-400 font-semibold text-sm">Gold</span>
        </div>

        <button
          onClick={dismissOfflineReport}
          className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-cinzel font-bold text-sm tracking-wide shadow-lg shadow-amber-950/50 transition-all cursor-pointer active:scale-95 flex items-center justify-center gap-2"
        >
          <Sparkles className="w-4 h-4 text-slate-950" />
          <span>Claim Kingdom Tithes</span>
        </button>
      </div>
    </div>
  );
}
