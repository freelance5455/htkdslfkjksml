import React, { useState } from 'react';
import {
  X,
  Crown,
  CheckCircle2,
  Copy,
  Check,
  ShieldCheck,
  CreditCard,
  QrCode,
  Smartphone,
  Sparkles,
  Lock,
  AlertCircle,
  Printer,
  CheckCheck,
  Zap,
  Info,
  Building2,
  ArrowLeft,
  ChevronLeft
} from 'lucide-react';
import { Language, UserProfile, SubscriptionPaymentRecord } from '../types';

interface EduMindProPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  userProfile?: UserProfile;
  setUserProfile?: React.Dispatch<React.SetStateAction<UserProfile>>;
  onPaymentSuccess?: (subscription: any) => void;
}

type PaymentMethodType = 'upi' | 'card' | 'netbanking';
type PlanType = 'monthly' | 'yearly';

export default function EduMindProPaymentModal({
  isOpen,
  onClose,
  language,
  userProfile,
  setUserProfile,
  onPaymentSuccess
}: EduMindProPaymentModalProps) {
  if (!isOpen) return null;

  const isBn = language === 'bn';
  const isHi = language === 'hi';

  // Currency & Prices - Exclusively Indian Rupees (₹ INR)
  const currency = 'INR';
  const currencySymbol = '₹';

  // State
  const [selectedPlan, setSelectedPlan] = useState<PlanType>('monthly');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethodType>('upi');
  const [step, setStep] = useState<'checkout' | 'otp' | 'success'>('checkout');

  // Input states
  const [transactionId, setTransactionId] = useState('');
  const [userPhone, setUserPhone] = useState(userProfile?.phone || '');
  const [selectedBank, setSelectedBank] = useState('SBI');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [cardHolder, setCardHolder] = useState(userProfile?.name || '');
  const [cardOtp, setCardOtp] = useState('');

  // Status & UI
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [showPayoutInfo, setShowPayoutInfo] = useState(false);
  const [verifiedOrder, setVerifiedOrder] = useState<SubscriptionPaymentRecord | null>(null);

  // Price calculations in INR
  const price = selectedPlan === 'monthly' ? 99 : 899;

  // Merchant Indian UPI & Bank Details
  const merchantDetails = {
    upiId: 'studyskill@okaxis',
    upiSecondary: 'studyskill@ybl',
    accountName: 'StudySkill AI Technologies',
    accountNumber: '9182374619283',
    ifscCode: 'SBIN0012345',
    bankName: 'State Bank of India (SBI)'
  };

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  // Submit and verify payment
  const handleVerifyPayment = async () => {
    setErrorMessage('');

    // Verification check based on method
    if (paymentMethod === 'card') {
      if (step === 'checkout') {
        if (cardNumber.replace(/\s/g, '').length < 15 || !cardExpiry || cardCvv.length < 3) {
          setErrorMessage(
            isBn
              ? 'অনুগ্রহ করে সঠিক কার্ড নম্বর, মেয়াদ (MM/YY) এবং সিভিভি দিন।'
              : 'Please enter valid 16-digit Card details, expiry and CVV.'
          );
          return;
        }
        // Move to simulated 3D Secure OTP Step
        setStep('otp');
        return;
      } else if (step === 'otp') {
        if (!cardOtp || cardOtp.length < 4) {
          setErrorMessage(
            isBn
              ? 'অনুগ্রহ করে আপনার ফোনে পাঠানো সঠিক ৪-সংখ্যার ব্যাংক ওটিপি দিন।'
              : 'Please enter valid 4-digit Bank OTP.'
          );
          return;
        }
      }
    } else if (paymentMethod === 'netbanking') {
      const trimmedTrx = transactionId.trim();
      if (!trimmedTrx) {
        setErrorMessage(
          isBn
            ? 'অনুগ্রহ করে আপনার ব্যাংকের UTR / ট্রানজেকশন রেফারেন্স নম্বর প্রদান করুন।'
            : 'Please enter the Net Banking Reference / UTR Number.'
        );
        return;
      }
    } else {
      // UPI (GPay / PhonePe / Paytm)
      const trimmedTrx = transactionId.trim();
      if (!trimmedTrx) {
        setErrorMessage(
          isBn
            ? 'পেমেন্ট সম্পন্ন করার পর প্রাপ্ত ১২-সংখ্যার UPI UTR / Reference No লিখুন।'
            : 'Please enter the 12-digit UPI UTR / Ref No after making payment.'
        );
        return;
      }
      if (trimmedTrx.length < 6) {
        setErrorMessage(
          isBn
            ? 'UTR নম্বর সঠিক নয়। অনুগ্রহ করে সঠিক ১২-সংখ্যার UPI UTR দিন (যেমন: 423891729012)'
            : 'UTR is too short. Please enter a valid 12-digit UPI UTR (e.g. 423891729012)'
        );
        return;
      }
    }

    setIsLoading(true);

    try {
      const finalTrxId = paymentMethod === 'card' 
        ? `CARD-AUTH-${Date.now().toString().slice(-6)}` 
        : transactionId.trim().toUpperCase();

      const response = await fetch('/api/payment/verify-and-activate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: userProfile?.id || `user_${Date.now()}`,
          userName: userProfile?.name || 'Student',
          userPhone: userPhone || userProfile?.phone,
          plan: selectedPlan,
          amount: price,
          currency: 'INR',
          paymentMethod: paymentMethod,
          transactionId: finalTrxId,
          cardLast4: paymentMethod === 'card' ? cardNumber.slice(-4) : undefined
        })
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        setErrorMessage(data.error || (isBn ? 'পেমেন্ট ভেরিফিকেশন ব্যর্থ হয়েছে। সঠিক তথ্য দিন।' : 'Payment verification failed.'));
        setIsLoading(false);
        return;
      }

      // Success!
      const subRecord: SubscriptionPaymentRecord = {
        orderId: data.subscription.proOrderId,
        userName: userProfile?.name || 'Student',
        userPhone: userPhone,
        plan: data.subscription.proPlan,
        amount: data.subscription.proPaidAmount,
        currency: 'INR',
        paymentMethod: data.subscription.proPaymentMethod,
        transactionId: data.subscription.proTransactionId,
        status: 'SUCCESS',
        paidAt: new Date().toISOString(),
        expiresAt: data.subscription.proExpiryDate
      };

      setVerifiedOrder(subRecord);

      // Update local storage & global user profile
      try {
        localStorage.setItem('edumind_is_pro', 'true');
        localStorage.setItem('edumind_pro_expiry', data.subscription.proExpiryDate);
        localStorage.setItem('edumind_last_payment', JSON.stringify(subRecord));
      } catch (e) {}

      if (setUserProfile) {
        setUserProfile(prev => ({
          ...prev,
          isPro: true,
          proPlan: data.subscription.proPlan,
          proExpiryDate: data.subscription.proExpiryDate,
          proOrderId: data.subscription.proOrderId,
          proPaymentMethod: data.subscription.proPaymentMethod,
          proPaidAmount: data.subscription.proPaidAmount,
          proTransactionId: data.subscription.proTransactionId
        }));
      }

      if (onPaymentSuccess) {
        onPaymentSuccess(data.subscription);
      }

      setStep('success');
    } catch (err: any) {
      console.error('Payment Error:', err);
      setErrorMessage(isBn ? 'সার্ভার সংযোগ সমস্যা। পুনরায় চেষ্টা করুন।' : 'Server connection error. Please retry.');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePrintReceipt = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in">
      <div className="relative max-w-xl w-full bg-gradient-to-b from-slate-900 via-[#0b1329] to-slate-950 rounded-3xl border border-amber-500/40 shadow-2xl overflow-hidden my-auto">
        
        {/* Header Ambient Glow */}
        <div className="absolute -top-10 left-1/2 -translate-x-1/2 w-80 h-32 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Top Navigation Bar */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800/80 relative z-10">
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-all cursor-pointer flex items-center gap-1.5 active:scale-95 border border-slate-700/60"
              title={isBn ? 'ফিরে যান' : 'Go back'}
            >
              <ArrowLeft className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold hidden sm:inline">{isBn ? 'ব্যাক' : 'Back'}</span>
            </button>
            <div className="p-2 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 text-slate-950 shadow-md shadow-amber-500/20">
              <Crown className="w-5 h-5 font-black" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-white">StudySkill Pro (India)</h3>
                <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[9px] font-black rounded uppercase">
                  🇮🇳 INR ONLY
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium">
                {isBn ? 'ভারত পেমেন্ট গেটওয়ে • UPI / RuPay / Cards' : 'India Gateway • UPI / RuPay / NetBanking'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-750 text-slate-400 hover:text-white transition-all cursor-pointer border border-slate-700/50"
            title={isBn ? 'বন্ধ করুন' : 'Close'}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* STEP 1: CHECKOUT & GATEWAY SELECTION */}
        {step === 'checkout' && (
          <div className="p-4 sm:p-6 space-y-5 max-h-[82vh] overflow-y-auto">

            {/* Plan Selector Toggle */}
            <div className="space-y-2">
              <label className="text-xs font-black uppercase text-slate-400 tracking-wider">
                {isBn ? '১. প্ল্যান নির্বাচন করুন' : '1. Select Subscription Plan'}
              </label>
              <div className="grid grid-cols-2 gap-2.5">
                {/* Monthly */}
                <button
                  type="button"
                  onClick={() => setSelectedPlan('monthly')}
                  className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer relative overflow-hidden ${
                    selectedPlan === 'monthly'
                      ? 'bg-gradient-to-br from-amber-500/15 via-slate-900 to-slate-900 border-amber-500 shadow-lg shadow-amber-500/10'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-black text-white">{isBn ? 'মাসিক প্ল্যান' : 'Monthly Plan'}</span>
                    {selectedPlan === 'monthly' && (
                      <CheckCircle2 className="w-4 h-4 text-amber-400" />
                    )}
                  </div>
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl font-black text-white font-mono">{currencySymbol}99</span>
                    <span className="text-[10px] text-slate-400 font-bold">{isBn ? '/ ১ মাস' : '/ month'}</span>
                  </div>
                  <p className="text-[10px] text-emerald-400 font-semibold mt-1">
                    {isBn ? 'প্রতিদিন আনলিমিটেড স্ক্যান' : 'Unlimited daily scans'}
                  </p>
                </button>

                {/* Yearly */}
                <button
                  type="button"
                  onClick={() => setSelectedPlan('yearly')}
                  className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer relative overflow-hidden ${
                    selectedPlan === 'yearly'
                      ? 'bg-gradient-to-br from-amber-500/15 via-slate-900 to-slate-900 border-amber-500 shadow-lg shadow-amber-500/10'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-400'
                  }`}
                >
                  <div className="absolute top-2 right-2 bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 text-[8px] font-black px-1.5 py-0.2 rounded-full uppercase">
                    SAVE 25%
                  </div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-black text-white">{isBn ? 'বাৎসরিক প্ল্যান' : 'Annual Plan'}</span>
                    {selectedPlan === 'yearly' && (
                      <CheckCircle2 className="w-4 h-4 text-amber-400" />
                    )}
                  </div>
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl font-black text-white font-mono">{currencySymbol}899</span>
                    <span className="text-[10px] text-slate-400 font-bold">{isBn ? '/ ১ বছর' : '/ year'}</span>
                  </div>
                  <p className="text-[10px] text-amber-400 font-semibold mt-1">
                    {isBn ? '১২ মাস ফুল আনলিমিটেড' : '12 Months Full Pro'}
                  </p>
                </button>
              </div>
            </div>

            {/* Payment Method Selector (UPI / Cards / Net Banking) */}
            <div className="space-y-2">
              <label className="text-xs font-black uppercase text-slate-400 tracking-wider">
                {isBn ? '২. পেমেন্ট মেথড বেছে নিন (ভারত)' : '2. Choose India Payment Method'}
              </label>
              <div className="grid grid-cols-3 gap-2">
                {/* UPI / GPay / PhonePe / Paytm */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod('upi')}
                  className={`p-3 rounded-2xl border flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                    paymentMethod === 'upi'
                      ? 'bg-indigo-500/20 border-indigo-500 text-white shadow-md'
                      : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 text-slate-400'
                  }`}
                >
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white font-black text-xs shadow-md">
                    UPI
                  </div>
                  <span className="text-[11px] font-black">UPI / QR / GPay</span>
                </button>

                {/* RuPay / Debit & Credit Card */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`p-3 rounded-2xl border flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                    paymentMethod === 'card'
                      ? 'bg-cyan-500/20 border-cyan-500 text-white shadow-md'
                      : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 text-slate-400'
                  }`}
                >
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center text-white font-black text-xs shadow-md">
                    <CreditCard className="w-4 h-4" />
                  </div>
                  <span className="text-[11px] font-black">RuPay / Cards</span>
                </button>

                {/* Net Banking */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod('netbanking')}
                  className={`p-3 rounded-2xl border flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                    paymentMethod === 'netbanking'
                      ? 'bg-emerald-500/20 border-emerald-500 text-white shadow-md'
                      : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 text-slate-400'
                  }`}
                >
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-600 flex items-center justify-center text-white font-black text-xs shadow-md">
                    <Building2 className="w-4 h-4" />
                  </div>
                  <span className="text-[11px] font-black">Net Banking</span>
                </button>
              </div>
            </div>

            {/* PAYMENT INSTRUCTIONS & VERIFICATION FORM */}
            <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 space-y-4">
              
              {/* UPI / QR CODE VIEW */}
              {paymentMethod === 'upi' && (
                <div className="space-y-3.5 text-center">
                  
                  {/* Supported UPI Apps Row */}
                  <div className="flex items-center justify-center flex-wrap gap-1.5 pt-1 pb-1">
                    <span className="px-2.5 py-0.5 rounded-lg bg-slate-950 border border-slate-800 text-[10px] font-bold text-slate-300">Google Pay</span>
                    <span className="px-2.5 py-0.5 rounded-lg bg-slate-950 border border-slate-800 text-[10px] font-bold text-slate-300">PhonePe</span>
                    <span className="px-2.5 py-0.5 rounded-lg bg-slate-950 border border-slate-800 text-[10px] font-bold text-slate-300">Paytm</span>
                    <span className="px-2.5 py-0.5 rounded-lg bg-slate-950 border border-slate-800 text-[10px] font-bold text-slate-300">BHIM UPI</span>
                    <span className="px-2.5 py-0.5 rounded-lg bg-slate-950 border border-slate-800 text-[10px] font-bold text-slate-300">Amazon Pay</span>
                  </div>

                  <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 inline-block mx-auto">
                    {/* Simulated Clean Dynamic QR Code */}
                    <div className="w-36 h-36 bg-white p-2 rounded-xl flex flex-col items-center justify-center text-slate-900 border border-slate-300 mx-auto">
                      <QrCode className="w-24 h-24 text-slate-900" />
                      <span className="text-[9px] font-black text-slate-800">Scan & Pay {currencySymbol}{price}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-center gap-2 bg-slate-950 px-3.5 py-2.5 rounded-xl border border-slate-800 max-w-sm mx-auto">
                    <span className="text-xs text-slate-400 font-bold">UPI ID:</span>
                    <span className="text-xs font-black text-amber-300 font-mono">{merchantDetails.upiId}</span>
                    <button
                      type="button"
                      onClick={() => handleCopy(merchantDetails.upiId, 'upi_id')}
                      className="p-1 text-slate-400 hover:text-white cursor-pointer"
                      title="Copy UPI ID"
                    >
                      {copiedKey === 'upi_id' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>

                  {/* Step Instructions */}
                  <div className="bg-indigo-950/30 border border-indigo-500/20 rounded-xl p-3 text-xs space-y-1.5 text-left text-slate-300">
                    <p className="font-bold text-indigo-300 flex items-center gap-1">
                      <Zap className="w-3.5 h-3.5 text-amber-400" />
                      <span>{isBn ? 'UPI পেমেন্ট করার সহজ ধাপসমূহ:' : 'UPI Payment Instructions:'}</span>
                    </p>
                    <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-300">
                      <li>
                        আপনার ফোনের <strong>Google Pay, PhonePe, Paytm, BHIM</strong> বা যেকোনো UPI অ্যাপ ওপেন করুন।
                      </li>
                      <li>
                        উপরে দেওয়া QR কোড স্ক্যান করুন অথবা UPI ID <strong>{merchantDetails.upiId}</strong>-এ <strong>{currencySymbol}{price}</strong> পাঠান।
                      </li>
                      <li>
                        পেমেন্ট সম্পন্ন হওয়ার পর প্রাপ্ত <strong>১২-সংখ্যার UTR / UPI Reference No</strong> নিচে লিখে ভেরিফাই বাটনে ক্লিক করুন।
                      </li>
                    </ol>
                  </div>

                  <div className="space-y-1.5 text-left">
                    <label className="text-xs font-black text-slate-200 flex items-center justify-between">
                      <span>{isBn ? '১২-সংখ্যার UTR / Reference No লিখুন:' : 'Enter 12-Digit UTR / Reference No:'}</span>
                      <span className="text-[10px] text-rose-400 font-bold">* আবশ্যক (Required)</span>
                    </label>
                    <input
                      type="text"
                      value={transactionId}
                      onChange={(e) => setTransactionId(e.target.value)}
                      placeholder="e.g. 423981729012"
                      className="w-full bg-slate-950 border border-slate-700 focus:border-amber-500 text-white font-mono text-sm px-3.5 py-3 rounded-xl outline-none placeholder:text-slate-600"
                    />
                  </div>
                </div>
              )}

              {/* NET BANKING VIEW */}
              {paymentMethod === 'netbanking' && (
                <div className="space-y-3.5">
                  <div className="space-y-1.5">
                    <label className="text-xs font-black text-slate-300 block">
                      {isBn ? 'ব্যাংক নির্বাচন করুন (Select Bank):' : 'Select Bank:'}
                    </label>
                    <select
                      value={selectedBank}
                      onChange={(e) => setSelectedBank(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 text-white text-xs px-3 py-2.5 rounded-xl outline-none focus:border-amber-500 font-bold cursor-pointer"
                    >
                      <option value="SBI">State Bank of India (SBI)</option>
                      <option value="HDFC">HDFC Bank</option>
                      <option value="ICICI">ICICI Bank</option>
                      <option value="AXIS">Axis Bank</option>
                      <option value="PNB">Punjab National Bank (PNB)</option>
                      <option value="KOTAK">Kotak Mahindra Bank</option>
                      <option value="BOB">Bank of Baroda</option>
                    </select>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5 text-xs">
                    <div className="flex justify-between text-slate-400">
                      <span>Account Name:</span>
                      <span className="font-bold text-white">{merchantDetails.accountName}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Account No:</span>
                      <span className="font-mono font-bold text-amber-300">{merchantDetails.accountNumber}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>IFSC Code:</span>
                      <span className="font-mono font-bold text-slate-200">{merchantDetails.ifscCode}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Bank:</span>
                      <span className="font-bold text-slate-300">{merchantDetails.bankName}</span>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-black text-slate-200 flex items-center justify-between">
                      <span>{isBn ? 'ব্যাংক ট্রানজেকশন / UTR নম্বর লিখুন:' : 'Enter Bank Transaction / UTR Number:'}</span>
                      <span className="text-[10px] text-rose-400 font-bold">* Required</span>
                    </label>
                    <input
                      type="text"
                      value={transactionId}
                      onChange={(e) => setTransactionId(e.target.value)}
                      placeholder="e.g. N26120938472"
                      className="w-full bg-slate-950 border border-slate-700 focus:border-amber-500 text-white font-mono text-sm px-3.5 py-3 rounded-xl outline-none placeholder:text-slate-600"
                    />
                  </div>
                </div>
              )}

              {/* CARD PAYMENT FORM */}
              {paymentMethod === 'card' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-black text-slate-300 block">
                      {isBn ? 'কার্ড নম্বর (RuPay, Visa, Mastercard)' : 'Card Number (RuPay, Visa, Mastercard)'}
                    </label>
                    <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                      <span>✓ RuPay & Indian Cards Accepted</span>
                    </span>
                  </div>
                  <div>
                    <div className="relative">
                      <input
                        type="text"
                        maxLength={19}
                        value={cardNumber}
                        onChange={(e) => {
                          const val = e.target.value.replace(/\D/g, '').replace(/(.{4})/g, '$1 ').trim();
                          setCardNumber(val);
                        }}
                        placeholder="4532 8901 2345 6789"
                        className="w-full bg-slate-950 border border-slate-700 text-white font-mono text-sm px-3.5 py-2.5 rounded-xl outline-none focus:border-amber-500 pl-10"
                      />
                      <CreditCard className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[11px] font-black text-slate-300 block mb-1">
                        {isBn ? 'মেয়াদ (MM/YY)' : 'Expiry (MM/YY)'}
                      </label>
                      <input
                        type="text"
                        maxLength={5}
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                        placeholder="12/28"
                        className="w-full bg-slate-950 border border-slate-700 text-white font-mono text-sm px-3.5 py-2.5 rounded-xl outline-none focus:border-amber-500 text-center"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-black text-slate-300 block mb-1">
                        CVV / CVC
                      </label>
                      <input
                        type="password"
                        maxLength={4}
                        value={cardCvv}
                        onChange={(e) => setCardCvv(e.target.value)}
                        placeholder="•••"
                        className="w-full bg-slate-950 border border-slate-700 text-white font-mono text-sm px-3.5 py-2.5 rounded-xl outline-none focus:border-amber-500 text-center"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-black text-slate-300 block mb-1">
                      {isBn ? 'কার্ডধারীর নাম' : 'Cardholder Name'}
                    </label>
                    <input
                      type="text"
                      value={cardHolder}
                      onChange={(e) => setCardHolder(e.target.value)}
                      placeholder="e.g. Rahul Sharma"
                      className="w-full bg-slate-950 border border-slate-700 text-white text-sm px-3.5 py-2 rounded-xl outline-none focus:border-amber-500"
                    />
                  </div>
                </div>
              )}

              {/* Error Message display */}
              {errorMessage && (
                <div className="p-3 bg-rose-500/15 border border-rose-500/30 rounded-xl text-rose-300 text-xs flex items-start gap-2 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Action Buttons */}
              <div className="pt-2 space-y-2">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="py-3.5 px-4 bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white font-bold text-xs rounded-2xl border border-slate-700/80 transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-95 shrink-0"
                  >
                    <ArrowLeft className="w-4 h-4 text-amber-400" />
                    <span>{isBn ? 'ফিরে যান' : 'Back'}</span>
                  </button>

                  <button
                    type="button"
                    disabled={isLoading}
                    onClick={handleVerifyPayment}
                    className="flex-1 py-3.5 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 disabled:opacity-50 text-slate-950 font-black text-sm rounded-2xl shadow-xl shadow-amber-500/25 active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    {isLoading ? (
                      <>
                        <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                        <span>{isBn ? 'পেমেন্ট যাচাই করা হচ্ছে...' : 'Verifying Payment...'}</span>
                      </>
                    ) : (
                      <>
                        <Lock className="w-4 h-4" />
                        <span>
                          {isBn 
                            ? `${currencySymbol}${price} পে করুন ও প্রো সক্রিয় করুন` 
                            : `Pay ${currencySymbol}${price} & Activate Pro`}
                        </span>
                      </>
                    )}
                  </button>
                </div>

                <div className="flex items-center justify-center gap-3 text-[10px] text-slate-500 pt-1">
                  <span className="flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>256-Bit SSL Encrypted</span>
                  </span>
                  <span>•</span>
                  <span>Instant Automatic Activation</span>
                </div>
              </div>

              {/* Educational Payout explanation button */}
              <div className="pt-1 text-center">
                <button
                  type="button"
                  onClick={() => setShowPayoutInfo(!showPayoutInfo)}
                  className="text-[11px] text-amber-400 hover:text-amber-300 font-bold inline-flex items-center gap-1 transition-all cursor-pointer"
                >
                  <Info className="w-3.5 h-3.5" />
                  <span>{isBn ? 'টাকা কীভাবে একাউন্টে জমা হবে? (পেমেন্ট সেটেলমেন্ট গাইড)' : 'How will money reach the bank account?'}</span>
                </button>
              </div>

              {showPayoutInfo && (
                <div className="p-3.5 bg-slate-950 border border-amber-500/30 rounded-2xl text-left text-xs space-y-2 animate-in fade-in">
                  <div className="flex items-center gap-1.5 text-amber-300 font-black">
                    <Zap className="w-4 h-4 text-amber-400" />
                    <span>টাকা সরাসরি আপনার ব্যাংক একাউন্টে জমা হওয়ার নিয়ম:</span>
                  </div>
                  <ul className="list-disc list-inside space-y-1 text-slate-300 text-[11px] leading-relaxed">
                    <li>
                      <strong>UPI / QR পেমেন্ট:</strong> ব্যবহারকারী যখন আপনার দেওয়া UPI ID (যেমন আপনার PhonePe, GPay, Paytm বা Axis Bank VPA)-তে টাকা পাঠায়, তখন টাকা সরাসরি <strong>সেকেন্ডের মধ্যে আপনার লিংক করা ব্যাংক একাউন্টে (T+0 instant settlement)</strong> জমা হয়ে যায়।
                    </li>
                    <li>
                      <strong>Razorpay / Cashfree / Stripe India গেটওয়ে:</strong> আপনি যখন আপনার নিজস্ব Razorpay বা Cashfree একাউন্ট কানেক্ট করবেন, তখন ক্রেডিট কার্ড ও নেট ব্যাংকিংয়ের টাকা ব্যাংকে <strong>T+1 কার্যদিবসে</strong> অটো-ট্রান্সফার হয়ে যাবে।
                    </li>
                  </ul>
                </div>
              )}

            </div>
          </div>
        )}

        {/* STEP 2: 3D SECURE OTP SIMULATION (For Card Payments) */}
        {step === 'otp' && (
          <div className="p-6 space-y-5 text-center">
            <div className="w-14 h-14 bg-indigo-600/20 border border-indigo-500/40 rounded-2xl flex items-center justify-center text-indigo-400 mx-auto">
              <Smartphone className="w-7 h-7 animate-pulse" />
            </div>

            <div className="space-y-1">
              <h4 className="text-lg font-black text-white">3D Secure Bank OTP</h4>
              <p className="text-xs text-slate-300">
                {isBn 
                  ? `আপনার নিবন্ধিত নম্বরে ৪-সংখ্যার ওটিপি পাঠানো হয়েছে। (${currencySymbol}${price} পরিশোধের জন্য)`
                  : `A 4-digit OTP has been sent to your mobile for ${currencySymbol}${price}`}
              </p>
            </div>

            <div className="max-w-xs mx-auto space-y-3">
              <input
                type="text"
                maxLength={6}
                value={cardOtp}
                onChange={(e) => setCardOtp(e.target.value)}
                placeholder="1 2 3 4"
                className="w-full text-center text-2xl tracking-[0.5em] font-mono font-black py-3 bg-slate-950 border border-indigo-500/50 rounded-2xl text-white outline-none focus:border-amber-400"
              />

              <div className="flex items-center justify-between text-[11px] text-slate-400 px-1">
                <span>Resend OTP in 0:28</span>
                <span className="text-amber-400 font-bold">Demo OTP: Any 4 digits</span>
              </div>
            </div>

            {errorMessage && (
              <div className="p-3 bg-rose-500/15 border border-rose-500/30 rounded-xl text-rose-300 text-xs">
                {errorMessage}
              </div>
            )}

            <div className="space-y-2 pt-2">
              <button
                type="button"
                disabled={isLoading}
                onClick={handleVerifyPayment}
                className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-sm rounded-2xl shadow-xl shadow-emerald-500/25 active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                    <span>যাচাই করা হচ্ছে...</span>
                  </>
                ) : (
                  <>
                    <CheckCheck className="w-4 h-4" />
                    <span>কনফার্ম করুন ও প্রো চালু করুন</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => setStep('checkout')}
                className="text-xs text-slate-400 hover:text-slate-300 font-semibold py-1 cursor-pointer"
              >
                পেছনে ফিরে যান (Back)
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: PAYMENT VERIFIED & OFFICIAL DIGITAL INVOICE */}
        {step === 'success' && verifiedOrder && (
          <div className="p-5 sm:p-6 space-y-5 animate-in zoom-in-95 duration-300">
            {/* Header Success Badge */}
            <div className="text-center space-y-2">
              <div className="w-16 h-16 bg-emerald-500/20 border-2 border-emerald-500 text-emerald-400 rounded-3xl flex items-center justify-center mx-auto shadow-xl shadow-emerald-500/20 animate-bounce">
                <CheckCircle2 className="w-9 h-9" />
              </div>
              <h4 className="text-xl font-black text-white">
                {isBn ? '👑 অভিনন্দন! StudySkill Pro সক্রিয় হয়েছে' : '👑 StudySkill Pro Activated!'}
              </h4>
              <p className="text-xs text-emerald-400 font-bold">
                {isBn ? 'আপনার পেমেন্ট সফলভাবে ভেরিফাই ও রেকর্ড করা হয়েছে।' : 'Payment successfully verified and recorded.'}
              </p>
            </div>

            {/* Official Digital Receipt Card */}
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-3 text-xs">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
                <span className="font-black text-white flex items-center gap-1.5">
                  <Crown className="w-4 h-4 text-amber-400" />
                  <span>StudySkill Official Indian Receipt</span>
                </span>
                <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[9px] font-black rounded uppercase">
                  PAID & VERIFIED (INR)
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <span className="text-slate-400 block">Order ID:</span>
                  <span className="font-mono font-bold text-slate-200">{verifiedOrder.orderId}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Transaction ID:</span>
                  <span className="font-mono font-bold text-amber-300">{verifiedOrder.transactionId}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Plan & Amount:</span>
                  <span className="font-bold text-white uppercase">{verifiedOrder.plan} ({currencySymbol}{verifiedOrder.amount})</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Payment Method:</span>
                  <span className="font-bold text-white uppercase">{verifiedOrder.paymentMethod}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Active Date:</span>
                  <span className="font-bold text-slate-300">{new Date(verifiedOrder.paidAt).toLocaleDateString()}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Valid Until:</span>
                  <span className="font-bold text-emerald-400">{new Date(verifiedOrder.expiresAt).toLocaleDateString()}</span>
                </div>
              </div>
            </div>

            {/* Benefit Confirmation */}
            <div className="bg-gradient-to-r from-amber-500/10 via-purple-500/10 to-indigo-500/10 border border-amber-500/20 rounded-xl p-3 text-xs space-y-1">
              <div className="flex items-center gap-2 text-slate-200 font-bold">
                <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
                <span>{isBn ? 'এখন থেকে আপনি আনলিমিটেড স্ক্যান ও অ্যাড-ফ্রি স্টাডি উপভোগ করতে পারবেন।' : 'Enjoy unlimited scans & completely ad-free study!'}</span>
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-2 pt-1">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handlePrintReceipt}
                  className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>{isBn ? 'রিসিপ্ট প্রিন্ট / সেভ' : 'Print Receipt'}</span>
                </button>

                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 py-3 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-amber-500/20 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>{isBn ? 'পড়াশোনা শুরু করুন' : 'Start Learning'}</span>
                </button>
              </div>

              <button
                type="button"
                onClick={() => {
                  // Deactivate Pro
                  fetch('/api/payment/deactivate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                      userId: userProfile?.id,
                      orderId: verifiedOrder?.orderId
                    })
                  }).catch(() => {});

                  try {
                    localStorage.removeItem('edumind_is_pro');
                    localStorage.removeItem('edumind_pro_expiry');
                    localStorage.removeItem('edumind_last_payment');
                  } catch (e) {}

                  if (setUserProfile) {
                    setUserProfile(prev => ({
                      ...prev,
                      isPro: false,
                      proPlan: undefined,
                      proExpiryDate: undefined,
                      proOrderId: undefined,
                      proPaymentMethod: undefined,
                      proPaidAmount: undefined,
                      proTransactionId: undefined
                    }));
                  }
                  onClose();
                }}
                className="w-full py-2 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/25 text-rose-300 font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                <X className="w-3.5 h-3.5" />
                <span>{isBn ? 'সাবস্ক্রিপশন আনঅ্যাক্টিভ / বাতিল করুন' : 'Deactivate / Cancel Subscription'}</span>
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
