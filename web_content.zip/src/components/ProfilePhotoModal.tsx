import React, { useState, useRef } from 'react';
import { 
  Camera, 
  Upload, 
  Trash2, 
  X, 
  Check, 
  Image as ImageIcon, 
  Sparkles, 
  User, 
  RefreshCw,
  Sliders,
  CheckCircle2
} from 'lucide-react';
import { Language } from '../types';

interface ProfilePhotoModalProps {
  language: Language;
  currentPhotoUrl?: string;
  userName: string;
  onSave: (newPhotoUrl: string) => void;
  onRemove: () => void;
  onClose: () => void;
}

// Curated high quality stylized vector & illustrated avatar presets
const PRESET_AVATARS = [
  {
    id: 'avatar-scholar',
    label: 'Scholar / শিক্ষার্থী',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80'
  },
  {
    id: 'avatar-aspirant-male',
    label: 'Aspirant (Male) / অফিসার',
    url: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=300&auto=format&fit=crop&q=80'
  },
  {
    id: 'avatar-aspirant-female',
    label: 'Aspirant (Female) / কৃতি শিক্ষার্থী',
    url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&auto=format&fit=crop&q=80'
  },
  {
    id: 'avatar-focus-male',
    label: 'Focus Mind / গবেষক',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80'
  },
  {
    id: 'avatar-graduate-cap',
    label: 'Future Graduate / গ্র্যাজুয়েট',
    url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300&auto=format&fit=crop&q=80'
  },
  {
    id: 'avatar-civil-candidate',
    label: 'Civil Candidate / সিভিল পরীক্ষার্থী',
    url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80'
  }
];

export default function ProfilePhotoModal({
  language,
  currentPhotoUrl,
  userName,
  onSave,
  onRemove,
  onClose
}: ProfilePhotoModalProps) {
  const [selectedPhoto, setSelectedPhoto] = useState<string>(currentPhotoUrl || '');
  const [activeTab, setActiveTab] = useState<'upload' | 'presets'>('upload');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Compress & resize image using Canvas to ensure efficient localStorage storage
  const processImageFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setErrorMsg(language === 'bn' ? 'অনুগ্রহ করে শুধুমাত্র ছবি ফাইল (JPG, PNG) নির্বাচন করুন।' : 'Please select a valid image file (JPG, PNG).');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      setErrorMsg(language === 'bn' ? 'ছবির সাইজ ১০MB এর চেয়ে কম হতে হবে।' : 'File size should be less than 10MB.');
      return;
    }

    setIsProcessing(true);
    setErrorMsg('');

    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          const maxDim = 400; // 400x400 max dimension
          let width = img.width;
          let height = img.height;

          // Crop to square from center
          const minSide = Math.min(width, height);
          const startX = (width - minSide) / 2;
          const startY = (height - minSide) / 2;

          canvas.width = maxDim;
          canvas.height = maxDim;
          const ctx = canvas.getContext('2d');

          if (ctx) {
            ctx.imageSmoothingQuality = 'high';
            ctx.drawImage(img, startX, startY, minSide, minSide, 0, 0, maxDim, maxDim);
            const compressedBase64 = canvas.toDataURL('image/jpeg', 0.85);
            setSelectedPhoto(compressedBase64);
          }
        } catch (err) {
          console.error('Image compression error:', err);
          setErrorMsg(language === 'bn' ? 'ছবি প্রসেস করতে সমস্যা হয়েছে।' : 'Error processing image.');
        } finally {
          setIsProcessing(false);
        }
      };
      img.onerror = () => {
        setIsProcessing(false);
        setErrorMsg(language === 'bn' ? 'ছবি লোড করা যায়নি।' : 'Failed to load image.');
      };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processImageFile(e.target.files[0]);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processImageFile(e.dataTransfer.files[0]);
    }
  };

  const handleSave = () => {
    if (selectedPhoto) {
      onSave(selectedPhoto);
    } else {
      onRemove();
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-lg p-5 sm:p-7 space-y-6 shadow-2xl animate-in fade-in zoom-in-95 my-6">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3.5">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 rounded-xl">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">
                {language === 'bn' ? 'প্রোফাইল ফটো যোগ বা পরিবর্তন' : 'Profile Photo Manager'}
              </h3>
              <p className="text-xs text-slate-400">
                {language === 'bn' ? 'আপনার নিজস্ব ফটো আপলোড করুন অথবা অ্যাভাটার বেছে নিন' : 'Upload your own photo or choose a preset avatar'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-xl cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live Photo Preview (Circular & Prominent) */}
        <div className="flex flex-col sm:flex-row items-center gap-5 p-4 bg-slate-950/60 rounded-3xl border border-slate-800">
          <div className="relative group shrink-0">
            {/* Ambient Glow ring */}
            <div className="absolute -inset-1.5 bg-gradient-to-tr from-indigo-500 via-purple-500 to-pink-500 rounded-full opacity-70 blur-md group-hover:opacity-100 transition-opacity" />
            
            <div className="relative">
              {selectedPhoto ? (
                <img
                  src={selectedPhoto}
                  alt={userName}
                  className="w-24 h-24 sm:w-28 sm:h-28 rounded-full object-cover border-2 border-white/80 shadow-2xl shadow-indigo-500/30"
                />
              ) : (
                <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 text-white font-black text-3xl flex items-center justify-center border-2 border-white/80 shadow-2xl shadow-purple-500/30">
                  {userName ? userName.charAt(0).toUpperCase() : 'U'}
                </div>
              )}
              
              {selectedPhoto && (
                <button
                  type="button"
                  onClick={() => setSelectedPhoto('')}
                  title={language === 'bn' ? 'ফটো মুছে ফেলুন' : 'Remove Photo'}
                  className="absolute -top-1 -right-1 p-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-full shadow-lg border-2 border-slate-900 cursor-pointer transition-transform hover:scale-110"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          <div className="text-center sm:text-left space-y-1.5 flex-1">
            <h4 className="text-sm font-bold text-white flex items-center justify-center sm:justify-start gap-1.5">
              <span>{userName}</span>
              {selectedPhoto && (
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              )}
            </h4>
            <p className="text-xs text-slate-400">
              {selectedPhoto
                ? (language === 'bn' ? 'ফটো নির্বাচন সম্পন্ন হয়েছে। সেভ করতে নিচের বাটনে চাপুন।' : 'Photo selected. Click Save Photo to apply.')
                : (language === 'bn' ? 'বর্তমানে কোনো ফটো সেট করা নেই।' : 'No photo uploaded yet. Default initial is active.')}
            </p>
            <div className="pt-0.5">
              <span className="text-[10px] bg-slate-800/80 text-indigo-300 border border-slate-700 px-2.5 py-0.5 rounded-full font-mono">
                {language === 'bn' ? 'সার্কুলার অটো ক্রপ (অপটিমাইজড)' : 'Circular Auto Crop (Optimized)'}
              </span>
            </div>
          </div>
        </div>

        {/* Tab Selection */}
        <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800">
          <button
            type="button"
            onClick={() => setActiveTab('upload')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg flex items-center justify-center gap-2 cursor-pointer transition-all ${
              activeTab === 'upload'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'ডিভাইস থেকে আপলোড' : 'Upload from Device'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('presets')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg flex items-center justify-center gap-2 cursor-pointer transition-all ${
              activeTab === 'presets'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'অ্যাভাটার গ্যালারি' : 'Preset Avatars'}</span>
          </button>
        </div>

        {/* Tab Content: Upload File */}
        {activeTab === 'upload' && (
          <div className="space-y-3">
            <input
              type="file"
              ref={fileInputRef}
              accept="image/png, image/jpeg, image/webp"
              onChange={handleFileChange}
              className="hidden"
            />

            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-700 hover:border-indigo-500 bg-slate-950/40 hover:bg-slate-950/80 rounded-2xl p-6 text-center cursor-pointer transition-all group"
            >
              <div className="p-3 bg-indigo-500/10 group-hover:bg-indigo-500/20 text-indigo-400 rounded-full w-12 h-12 mx-auto flex items-center justify-center mb-3 transition-colors">
                <Camera className="w-6 h-6" />
              </div>
              <p className="text-xs font-bold text-white group-hover:text-indigo-300 transition-colors">
                {language === 'bn' ? 'ফাইল বাছাই করতে এখানে ক্লিক করুন অথবা টেনে আনুন' : 'Click to select photo or drag & drop here'}
              </p>
              <p className="text-[11px] text-slate-500 mt-1">
                {language === 'bn' ? 'গ্যালারি বা ক্যামেরা থেকে ছবি নিন (JPG, PNG, WEBP, সর্বোচ্চ 10MB)' : 'Take photo or pick from gallery (JPG, PNG, max 10MB)'}
              </p>
            </div>

            {isProcessing && (
              <div className="flex items-center justify-center gap-2 text-indigo-400 text-xs font-bold py-2">
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>{language === 'bn' ? 'ছবি সাইজ অপটিমাইজ করা হচ্ছে...' : 'Optimizing photo...'}</span>
              </div>
            )}

            {errorMsg && (
              <div className="p-2.5 bg-rose-950/60 border border-rose-500/40 rounded-xl text-rose-300 text-xs font-medium text-center">
                {errorMsg}
              </div>
            )}
          </div>
        )}

        {/* Tab Content: Preset Avatars */}
        {activeTab === 'presets' && (
          <div className="space-y-2.5">
            <p className="text-xs text-slate-400 font-medium">
              {language === 'bn' ? 'আপনার পছন্দের যেকোনো স্টাইলিশ অ্যাভাটার স্পর্শ করে নির্বাচন করুন:' : 'Choose any avatar from the list below:'}
            </p>
            <div className="grid grid-cols-3 gap-3">
              {PRESET_AVATARS.map((av) => {
                const isSelected = selectedPhoto === av.url;
                return (
                  <button
                    key={av.id}
                    type="button"
                    onClick={() => setSelectedPhoto(av.url)}
                    className={`relative p-2 rounded-2xl border flex flex-col items-center gap-2 cursor-pointer transition-all group ${
                      isSelected
                        ? 'bg-indigo-950/60 border-indigo-500 shadow-md ring-2 ring-indigo-500/50'
                        : 'bg-slate-950/50 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <img
                      src={av.url}
                      alt={av.label}
                      className="w-14 h-14 rounded-xl object-cover shadow-sm group-hover:scale-105 transition-transform"
                    />
                    <span className="text-[10px] font-bold text-slate-300 text-center truncate w-full">
                      {av.label}
                    </span>

                    {isSelected && (
                      <div className="absolute top-1.5 right-1.5 bg-indigo-600 text-white rounded-full p-0.5 shadow-md">
                        <Check className="w-3 h-3" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-800 gap-3">
          {selectedPhoto ? (
            <button
              type="button"
              onClick={() => {
                setSelectedPhoto('');
                onRemove();
                onClose();
              }}
              className="px-3.5 py-2 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/60 font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'ফটো সরান' : 'Remove'}</span>
            </button>
          ) : (
            <div />
          )}

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl cursor-pointer transition-colors"
            >
              {language === 'bn' ? 'বাতিল' : 'Cancel'}
            </button>

            <button
              type="button"
              onClick={handleSave}
              className="px-5 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-black text-xs rounded-xl flex items-center gap-1.5 shadow-lg shadow-indigo-600/30 cursor-pointer transition-all active:scale-95"
            >
              <Check className="w-4 h-4" />
              <span>{language === 'bn' ? 'ফটো সেভ করুন' : 'Save Photo'}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
