import React from 'react';
import { GraduationCap, ArrowUpRight, Sparkles, BookOpen, Calculator, Code2, FlaskConical, Landmark, Compass } from 'lucide-react';
import { TUTOR_PERSONAS, TutorPersonaId } from '../utils/tutor-prompts';

interface WelcomeScreenProps {
  currentPersona: TutorPersonaId;
  onSelectPrompt: (promptText: string) => void;
  onSelectPersona: (personaId: TutorPersonaId) => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({
  currentPersona,
  onSelectPrompt,
  onSelectPersona,
}) => {
  const persona = TUTOR_PERSONAS[currentPersona] || TUTOR_PERSONAS.general;

  const quickCategories = [
    { id: 'general' as TutorPersonaId, label: 'General', icon: Compass },
    { id: 'math' as TutorPersonaId, label: 'Math & Formulas', icon: Calculator },
    { id: 'code' as TutorPersonaId, label: 'CS & Algorithms', icon: Code2 },
    { id: 'science' as TutorPersonaId, label: 'Physics & Chem', icon: FlaskConical },
    { id: 'language' as TutorPersonaId, label: 'Writing & Essay', icon: BookOpen },
    { id: 'history' as TutorPersonaId, label: 'History & Civics', icon: Landmark },
  ];

  return (
    <div id="welcome-screen" className="flex flex-col items-center justify-center text-center py-6 sm:py-10 px-4 max-w-2xl mx-auto my-auto animate-fade-in">
      <div className="w-16 h-16 rounded-2xl bg-slate-900 text-white flex items-center justify-center text-2xl mb-4 shadow-sm">
        <GraduationCap className="w-8 h-8 text-indigo-400" />
      </div>

      <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-100 mb-3">
        <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
        <span>MindSparq Learning Engine</span>
      </div>

      <h2 className="text-2xl font-bold text-slate-900 mb-2">
        How can I help you learn today?
      </h2>
      <p className="text-sm text-slate-500 max-w-lg mb-6 leading-relaxed">
        Ask any homework or concept question, get step-by-step problem breakdowns,
        test yourself with practice quizzes, or explore intuitive analogies.
      </p>

      {/* Quick subject buttons */}
      <div className="flex flex-wrap items-center justify-center gap-2 mb-8">
        {quickCategories.map((cat) => {
          const Icon = cat.icon;
          const isCurrent = currentPersona === cat.id;
          return (
            <button
              type="button"
              key={cat.id}
              onClick={() => onSelectPersona(cat.id)}
              aria-label={`Switch tutor persona to ${cat.label}`}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border transition cursor-pointer ${
                isCurrent
                  ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                  : 'bg-white text-slate-700 border-slate-200 hover:border-slate-400 hover:bg-slate-50'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isCurrent ? 'text-indigo-300' : 'text-slate-500'}`} />
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Suggested Prompts Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full text-left">
        {persona.defaultPrompts.map((promptText, idx) => (
          <button
            type="button"
            key={idx}
            onClick={() => onSelectPrompt(promptText)}
            aria-label={`Ask tutor: ${promptText}`}
            className="p-3.5 border border-slate-200 hover:border-indigo-400 hover:bg-indigo-50/20 rounded-xl transition group text-xs bg-white text-left shadow-2xs flex flex-col justify-between cursor-pointer focus:outline-none focus:ring-2 focus:ring-indigo-400"
          >
            <div className="font-semibold text-slate-800 mb-1 flex items-center justify-between">
              <span className="truncate pr-2">
                {idx === 0
                  ? 'Key Concept Breakdown'
                  : idx === 1
                  ? 'Step-by-Step Walkthrough'
                  : idx === 2
                  ? 'Intuitive Analogy & Logic'
                  : 'Practice & Deep Dive'}
              </span>
              <ArrowUpRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all shrink-0" />
            </div>
            <div className="text-slate-600 line-clamp-2 leading-relaxed">
              "{promptText}"
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};
