import React from 'react';
import { useApp } from '../context/AppContext';
import { translations } from '../data/translations';
import { 
  ArrowLeft, 
  ArrowRight, 
  Globe, 
  Send, 
  LayoutDashboard, 
  Activity, 
  ShieldCheck, 
  Sparkles, 
  Building2, 
  Plane,
  HeartPulse,
  Palmtree,
  Crown
} from 'lucide-react';

export const WelcomeScreen: React.FC = () => {
  const { 
    language, 
    toggleLanguage, 
    setCurrentView, 
    openRequestModalForService 
  } = useApp();

  const t = translations[language];
  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  return (
    <div className="min-h-screen bg-black text-zinc-100 flex flex-col justify-between relative overflow-hidden select-none">
      
      {/* Background ambient lighting and subtle radial gold glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[550px] bg-gradient-to-b from-[#D4AF37]/20 via-amber-500/10 to-transparent rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-10 right-10 w-[450px] h-[450px] bg-[#D4AF37]/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute top-10 left-10 w-[350px] h-[350px] bg-amber-600/10 rounded-full blur-3xl pointer-events-none"></div>

      {/* Subtle geometric dot grid pattern in gold */}
      <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#D4AF37_1px,transparent_1px)] [background-size:28px_28px] pointer-events-none"></div>

      {/* Top Bar inside Welcome Screen */}
      <header className="relative z-10 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-5 flex items-center justify-between">
        
        {/* Investor Prototype Badge */}
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 bg-black/80 text-amber-300 border border-[#D4AF37]/40 px-3.5 py-1.5 rounded-full text-xs font-semibold backdrop-blur-md shadow-[0_0_15px_rgba(212,175,55,0.15)]">
            <Crown className="w-3.5 h-3.5 text-[#D4AF37] animate-pulse" />
            <span>{isAr ? 'النموذج الأولي التفاعلي المعتمد' : 'Official Interactive Prototype'}</span>
          </span>
        </div>

        {/* Language Switcher & Quick Admin Jump */}
        <div className="flex items-center gap-3">
          <button
            onClick={toggleLanguage}
            className="flex items-center gap-1.5 bg-zinc-900/80 hover:bg-zinc-800 text-amber-200 border border-[#D4AF37]/30 px-3 py-1.5 rounded-xl text-xs font-semibold backdrop-blur-md transition-colors"
          >
            <Globe className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>{isAr ? 'English' : 'عربي (RTL)'}</span>
          </button>

          <button
            onClick={() => setCurrentView('admin')}
            className="hidden sm:flex items-center gap-1.5 bg-black/80 hover:bg-zinc-900 text-amber-300 border border-[#D4AF37]/40 px-3 py-1.5 rounded-xl text-xs font-semibold backdrop-blur-md transition-colors"
            title={isAr ? 'الدخول المباشر للوحة الإدارة' : 'Direct Admin Access'}
          >
            <LayoutDashboard className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>{isAr ? 'لوحة الإدارة' : 'Admin'}</span>
          </button>
        </div>
      </header>

      {/* Main Welcome Center Stage */}
      <main className="relative z-10 max-w-5xl mx-auto w-full px-4 sm:px-6 py-4 sm:py-8 flex flex-col items-center text-center space-y-6 sm:space-y-8 my-auto">
        
        {/* Official 3D Golden Logo with Background Removed */}
        <div className="relative group cursor-pointer" onClick={() => setCurrentView('home')}>
          {/* Subtle gold backlight glow */}
          <div className="absolute -inset-4 bg-gradient-to-r from-amber-500/25 via-yellow-500/30 to-amber-600/25 rounded-3xl blur-2xl opacity-75 group-hover:opacity-100 transition-opacity duration-700"></div>

          {/* Logo container without any white background */}
          <div className="relative p-2 sm:p-4 rounded-3xl transition-transform duration-500 hover:scale-[1.03]">
            <img 
              src="/assets/aistudio/logo_transparent.png" 
              alt="شعار المواساة الرسمي - AL MOWASAT"
              className="w-72 sm:w-84 md:w-96 max-h-56 sm:max-h-64 object-contain mx-auto drop-shadow-[0_12px_35px_rgba(212,175,55,0.4)]"
            />
          </div>
        </div>

        {/* Slogan Banner */}
        <div className="space-y-3 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500/10 via-[#D4AF37]/20 to-amber-500/10 border border-[#D4AF37]/50 px-4 py-1.5 rounded-full text-xs sm:text-sm text-amber-200 shadow-[0_0_20px_rgba(212,175,55,0.2)]">
            <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span className="font-bold tracking-wide">
              {isAr ? '«المواساة... رعايتك تبدأ من هنا، أينما كنت في العالم»' : '«Al-Mowasat... Your care begins here, wherever you are in the world»'}
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl md:text-4xl font-black bg-gradient-to-r from-amber-100 via-amber-300 to-yellow-500 bg-clip-text text-transparent tracking-tight leading-snug">
            {isAr ? 'المنصة المصرية المتكاملة للرعاية والسياحة العلاجية' : 'Egypt’s Premier Integrated Medical & Tourism Platform'}
          </h1>

          <p className="text-xs sm:text-sm text-zinc-300 max-w-xl mx-auto leading-relaxed">
            {isAr
              ? 'بوابتك الموثوقة لربط المرضى الدوليين بنخبة المستشفيات وأساتذة الجراحة، ومراكز التأهيل والاستشفاء البيئي الطبيعي بمصر، مع تنظيم لوجستي شامل من لحظة الوصول.'
              : 'Your premier gateway connecting global patients with accredited Egyptian hospitals, top surgical faculty, private rehab retreats, and natural healing oases.'}
          </p>
        </div>

        {/* Primary Action Buttons in Gold & Black */}
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4 w-full max-w-md">
          <button
            onClick={() => setCurrentView('home')}
            className="w-full sm:w-auto flex-1 bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black font-black px-8 py-4 rounded-2xl shadow-xl shadow-amber-500/25 hover:scale-[1.03] active:scale-[0.98] transition-all duration-200 flex items-center justify-center gap-3 text-sm sm:text-base border border-amber-300 group"
          >
            <span>{isAr ? 'دخول المنصة الرئيسية' : 'Enter Main Platform'}</span>
            <ArrowIcon className="w-5 h-5 text-black group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform" />
          </button>

          <button
            onClick={() => openRequestModalForService('medical_sector')}
            className="w-full sm:w-auto px-6 py-4 rounded-2xl bg-black/80 hover:bg-zinc-900 text-amber-300 font-bold border border-[#D4AF37]/60 text-xs sm:text-sm transition-all flex items-center justify-center gap-2 hover:border-amber-400"
          >
            <Send className="w-4 h-4 text-[#D4AF37]" />
            <span>{isAr ? 'طلب تنسيق فوري' : 'Direct Request'}</span>
          </button>
        </div>

        {/* 4 Quick Service Pillars Ribbon in Gold & Black */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 w-full max-w-4xl pt-4">
          <div 
            onClick={() => setCurrentView('medical')}
            className="p-4 rounded-2xl bg-zinc-950/90 border border-[#D4AF37]/20 hover:border-[#D4AF37]/70 hover:bg-zinc-900/90 transition-all cursor-pointer group text-start shadow-md"
          >
            <div className="flex items-center gap-2 mb-1.5">
              <HeartPulse className="w-4 h-4 text-[#D4AF37]" />
              <span className="text-xs font-bold text-amber-200 group-hover:text-amber-100">{isAr ? 'القطاع الطبي' : 'Medical Hub'}</span>
            </div>
            <p className="text-[11px] text-zinc-400 line-clamp-2">
              {isAr ? 'مستشفيات معتمدة وكبار الجراحين' : 'Accredited hospitals & surgeons'}
            </p>
          </div>

          <div 
            onClick={() => setCurrentView('rehab')}
            className="p-4 rounded-2xl bg-zinc-950/90 border border-[#D4AF37]/20 hover:border-[#D4AF37]/70 hover:bg-zinc-900/90 transition-all cursor-pointer group text-start shadow-md"
          >
            <div className="flex items-center gap-2 mb-1.5">
              <Building2 className="w-4 h-4 text-[#D4AF37]" />
              <span className="text-xs font-bold text-amber-200 group-hover:text-amber-100">{isAr ? 'علاج الإدمان' : 'Rehab Retreats'}</span>
            </div>
            <p className="text-[11px] text-zinc-400 line-clamp-2">
              {isAr ? 'بيئات آمنة وسرية تامة 100%' : '100% strict confidential detox'}
            </p>
          </div>

          <div 
            onClick={() => setCurrentView('tourism')}
            className="p-4 rounded-2xl bg-zinc-950/90 border border-[#D4AF37]/20 hover:border-[#D4AF37]/70 hover:bg-zinc-900/90 transition-all cursor-pointer group text-start shadow-md"
          >
            <div className="flex items-center gap-2 mb-1.5">
              <Palmtree className="w-4 h-4 text-[#D4AF37]" />
              <span className="text-xs font-bold text-amber-200 group-hover:text-amber-100">{isAr ? 'السياحة العلاجية' : 'Curative Oases'}</span>
            </div>
            <p className="text-[11px] text-zinc-400 line-clamp-2">
              {isAr ? 'سيوة، أسوان، وسفاجا' : 'Siwa, Aswan, & Safaga'}
            </p>
          </div>

          <div 
            onClick={() => setCurrentView('reception')}
            className="p-4 rounded-2xl bg-zinc-950/90 border border-[#D4AF37]/20 hover:border-[#D4AF37]/70 hover:bg-zinc-900/90 transition-all cursor-pointer group text-start shadow-md"
          >
            <div className="flex items-center gap-2 mb-1.5">
              <Plane className="w-4 h-4 text-[#D4AF37]" />
              <span className="text-xs font-bold text-amber-200 group-hover:text-amber-100">{isAr ? 'استقبال VIP' : 'VIP Reception'}</span>
            </div>
            <p className="text-[11px] text-zinc-400 line-clamp-2">
              {isAr ? 'من باب الطائرة وحتى الشفاء' : 'From tarmac to full recovery'}
            </p>
          </div>
        </div>

      </main>

      {/* Footer Strip of Welcome Screen */}
      <footer className="relative z-10 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-4 border-t border-zinc-900 text-[11px] text-zinc-400 flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-[#D4AF37] shrink-0" />
          <span>
            {isAr ? 'منصة تقنية متكاملة لتنسيق الخدمات الطبية واللوجستية بمصر' : 'Integrated Egyptian Healthcare Coordination Platform'}
          </span>
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={() => setCurrentView('tracking')}
            className="hover:text-amber-300 transition-colors flex items-center gap-1"
          >
            <Activity className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>{isAr ? 'متابعة طلب تجريبي' : 'Track Sample'}</span>
          </button>
          <span>•</span>
          <button
            onClick={() => setCurrentView('admin')}
            className="hover:text-amber-300 transition-colors flex items-center gap-1"
          >
            <LayoutDashboard className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>{isAr ? 'لوحة تحكم الإدارة' : 'Admin Dashboard'}</span>
          </button>
        </div>
      </footer>

    </div>
  );
};
