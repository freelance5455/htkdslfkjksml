import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { X, Sparkles, LogIn, UserPlus } from 'lucide-react';

interface WelcomeScreenProps {
  onDismiss: () => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onDismiss }) => {
  const { signInWithGoogle, signInWithEmail, signUpWithEmail } = useAuth();
  const [modalMode, setModalMode] = useState<'none' | 'login' | 'register'>('none');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleGoogleAuth = async () => {
    try {
      setError(null);
      setSubmitting(true);
      await signInWithGoogle();
      onDismiss();
    } catch (err: unknown) {
      console.warn('Google sign in error:', err);
      setError('Não foi possível entrar com Google. Tente com seu e-mail.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      if (modalMode === 'login') {
        await signInWithEmail(email, password);
      } else {
        if (!username || !displayName) {
          throw new Error('Preencha seu nome e @usuário.');
        }
        await signUpWithEmail(email, password, username, displayName);
      }
      onDismiss();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Erro na autenticação. Tente novamente.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col justify-between items-center text-center px-6 py-12 select-none overflow-hidden"
         style={{
           background: 'linear-gradient(155deg, #FF4038 0%, #FF008C 48%, #8500ED 100%)'
         }}>
      {/* Background subtle geometric light orbs */}
      <div className="absolute top-1/4 -left-20 w-80 h-80 rounded-full bg-white/10 blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/3 -right-20 w-80 h-80 rounded-full bg-purple-900/30 blur-3xl pointer-events-none" />

      {/* Top Header Section */}
      <div className="pt-8 z-10 animate-fade-in">
        <h1 className="text-5xl md:text-6xl font-black text-white tracking-tight drop-shadow-md">
          ClipShare
        </h1>
        <p className="mt-3 text-lg md:text-xl font-medium text-white/90 tracking-wide">
          Sua vibe. Seu clipe. Seu mundo.
        </p>
      </div>

      {/* Official Symbol from Reference Image:
          Circular speech bubble with black stroke */}
      <div className="my-auto py-8 z-10 flex flex-col items-center justify-center">
        <div className="relative w-48 h-48 md:w-56 md:h-56 flex items-center justify-center drop-shadow-2xl transition-transform hover:scale-105 duration-300">
          <img
            src="/clipshare-bubble.svg"
            alt="ClipShare Logo"
            className="w-full h-full object-contain filter drop-shadow-[0_15px_25px_rgba(0,0,0,0.3)]"
          />
        </div>
      </div>

      {/* Bottom Action Area */}
      <div className="w-full max-w-sm space-y-3.5 z-10 pb-4">
        {/* Criar conta button */}
        <button
          onClick={() => setModalMode('register')}
          className="w-full py-4 px-6 rounded-full font-bold text-base text-white shadow-xl active:scale-95 transition-all bg-gradient-to-r from-[#FF4038] via-[#FF008C] to-[#9900FF] hover:opacity-95 cursor-pointer border border-white/20"
        >
          Criar conta
        </button>

        {/* Entrar button */}
        <button
          onClick={() => setModalMode('login')}
          className="w-full py-4 px-6 rounded-full font-bold text-base text-white shadow-xl active:scale-95 transition-all bg-[#050505] hover:bg-[#101014] cursor-pointer border border-white/15"
        >
          Entrar
        </button>

        {/* Explorar como visitante */}
        <button
          onClick={onDismiss}
          className="pt-2 text-sm text-white/90 hover:text-white underline decoration-white/40 cursor-pointer block mx-auto"
        >
          Explorar como visitante
        </button>
      </div>

      {/* Auth Modal Overlay */}
      {modalMode !== 'none' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in">
          <div className="w-full max-w-md bg-[#101014] border border-[#272730] rounded-3xl p-6 md:p-8 text-left shadow-2xl relative">
            <button
              onClick={() => { setModalMode('none'); setError(null); }}
              className="absolute top-5 right-5 text-[#A1A1AA] hover:text-white p-1 rounded-full hover:bg-[#19191F]"
            >
              <X size={20} />
            </button>

            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-2xl bg-clipshare-gradient flex items-center justify-center text-white">
                {modalMode === 'login' ? <LogIn size={20} /> : <UserPlus size={20} />}
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">
                  {modalMode === 'login' ? 'Bem-vindo de volta' : 'Crie sua conta ClipShare'}
                </h3>
                <p className="text-xs text-[#A1A1AA]">
                  {modalMode === 'login' ? 'Conecte-se para curtir e publicar clipes' : 'Junte-se à comunidade oficial'}
                </p>
              </div>
            </div>

            {error && (
              <div className="mb-4 p-3 rounded-xl bg-red-500/15 border border-red-500/30 text-red-300 text-xs">
                {error}
              </div>
            )}

            {/* Google Authentication */}
            <button
              type="button"
              onClick={handleGoogleAuth}
              disabled={submitting}
              className="w-full flex items-center justify-center gap-3 py-3 px-4 rounded-full bg-[#19191F] border border-[#272730] hover:bg-[#22222b] text-white text-sm font-semibold transition-all mb-4 cursor-pointer"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"/>
                <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"/>
                <path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 10.02 0 12s.45 3.82 1.25 5.42l4.03-3.15z"/>
                <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"/>
              </svg>
              <span>Continuar com Google</span>
            </button>

            <div className="relative flex items-center justify-center my-4">
              <span className="h-px w-full bg-[#19191F]" />
              <span className="bg-[#101014] px-3 text-[11px] uppercase tracking-wider text-[#A1A1AA] absolute">
                ou com email
              </span>
            </div>

            <form onSubmit={handleEmailAuth} className="space-y-3.5">
              {modalMode === 'register' && (
                <>
                  <div>
                    <label className="block text-xs font-medium text-[#A1A1AA] mb-1">Nome completo</label>
                    <input
                      type="text"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder="Ex: João Vibes"
                      required
                      className="w-full bg-[#19191F] border border-[#272730] rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-[#FF008C]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#A1A1AA] mb-1">Nome de usuário (@)</label>
                    <div className="relative">
                      <span className="absolute left-3.5 top-2.5 text-[#A1A1AA] text-sm">@</span>
                      <input
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        placeholder="joaovibes"
                        required
                        className="w-full bg-[#19191F] border border-[#272730] rounded-xl pl-8 pr-4 py-2.5 text-sm text-white focus:outline-none focus:border-[#FF008C]"
                      />
                    </div>
                  </div>
                </>
              )}

              <div>
                <label className="block text-xs font-medium text-[#A1A1AA] mb-1">Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="seu@email.com"
                  required
                  className="w-full bg-[#19191F] border border-[#272730] rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-[#FF008C]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#A1A1AA] mb-1">Senha</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Mínimo 6 caracteres"
                  required
                  minLength={6}
                  className="w-full bg-[#19191F] border border-[#272730] rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-[#FF008C]"
                />
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3 rounded-full font-bold text-sm text-white bg-clipshare-gradient hover:opacity-95 active:scale-95 transition-all mt-4 cursor-pointer"
              >
                {submitting ? 'Aguarde...' : modalMode === 'login' ? 'Entrar no ClipShare' : 'Cadastrar agora'}
              </button>
            </form>

            <div className="mt-4 text-center">
              {modalMode === 'login' ? (
                <button
                  type="button"
                  onClick={() => setModalMode('register')}
                  className="text-xs text-[#A1A1AA] hover:text-[#FF008C]"
                >
                  Não tem conta? <span className="text-[#FF008C] font-semibold">Criar conta</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setModalMode('login')}
                  className="text-xs text-[#A1A1AA] hover:text-[#FF008C]"
                >
                  Já tem conta? <span className="text-[#FF008C] font-semibold">Fazer login</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
