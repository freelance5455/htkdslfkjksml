import React, { useState, useEffect, useRef } from 'react';
import {
  CloudRain,
  Snowflake,
  Wind,
  Sun,
  CloudSun,
  RefreshCw,
  MapPin,
  Sparkles,
  Droplets,
  Thermometer,
  PlayCircle,
  RotateCcw
} from 'lucide-react';
import { toBengaliNumerals } from '../../utils/prayerTimes';

export type WeatherCondition = 'rain' | 'cold' | 'wind' | 'heat' | 'clear';

interface HabivioWeatherWidgetProps {
  isBn: boolean;
  className?: string;
  onWeatherChange?: (condition: WeatherCondition, tempC: number) => void;
  showTestPills?: boolean;
}

export const HabivioWeatherWidget: React.FC<HabivioWeatherWidgetProps> = ({
  isBn,
  className = '',
  onWeatherChange,
  showTestPills = true,
}) => {
  const [condition, setCondition] = useState<WeatherCondition>('rain'); // Default to rain to demonstrate requested rain animation
  const [tempC, setTempC] = useState<number>(26);
  const [humidity, setHumidity] = useState<number>(84);
  const [windSpeed, setWindSpeed] = useState<number>(18);
  const [locationName, setLocationName] = useState<string>('ঢাকা (বর্তমান অবস্থান)');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // 6-Second Live Dynamic Animation State (User requested: হোম স্ক্রিনে আবহাওয়া অনুযায়ী কিছু সেকেন্ডের এনিমেশন হবে)
  const [isAnimationActive, setIsAnimationActive] = useState<boolean>(true);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(6);
  const timerRef = useRef<number | null>(null);

  const startTimedAnimation = (durationSeconds: number = 6) => {
    if (timerRef.current !== null) {
      clearInterval(timerRef.current);
    }
    setIsAnimationActive(true);
    setSecondsRemaining(durationSeconds);

    timerRef.current = window.setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          if (timerRef.current !== null) {
            clearInterval(timerRef.current);
            timerRef.current = null;
          }
          setIsAnimationActive(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  useEffect(() => {
    startTimedAnimation(6);
    return () => {
      if (timerRef.current !== null) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  // Fetch real live weather from Open-Meteo (free, no api key required)
  const fetchLiveWeather = async () => {
    setIsLoading(true);
    try {
      const res = await fetch(
        'https://api.open-meteo.com/v1/forecast?latitude=23.8103&longitude=90.4125&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&timezone=Asia%2FDhaka'
      );
      if (res.ok) {
        const data = await res.json();
        const current = data.current;
        if (current) {
          const t = Math.round(current.temperature_2m);
          setTempC(t);
          setHumidity(current.relative_humidity_2m || 75);
          setWindSpeed(Math.round(current.wind_speed_10m || 15));

          const code = current.weather_code;
          let newCond: WeatherCondition = 'clear';
          if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) {
            newCond = 'rain';
          } else if (t < 18) {
            newCond = 'cold';
          } else if (current.wind_speed_10m > 25) {
            newCond = 'wind';
          } else if (t >= 32) {
            newCond = 'heat';
          } else {
            newCond = 'clear';
          }
          setCondition(newCond);
          startTimedAnimation(6);
        }
      }
    } catch (e) {
      console.warn('Weather fetch fallback:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchLiveWeather();
  }, []);

  useEffect(() => {
    if (onWeatherChange) {
      onWeatherChange(condition, tempC);
    }
  }, [condition, tempC]);

  const conditionLabels: Record<WeatherCondition, { bn: string; en: string; adviceBn: string; adviceEn: string }> = {
    rain: {
      bn: 'বৃষ্টি হচ্ছে',
      en: 'Rainy Shower',
      adviceBn: '🌧️ বাইরে বৃষ্টি হচ্ছে — মসজিদে গমন বা কাজের জন্য বের হওয়ার সময় ছাতা সাথে রাখুন এবং পিছলে পড়া রোধে সাবধানে চলুন।',
      adviceEn: '🌧️ Rainy weather — keep an umbrella ready for prayers and step carefully.',
    },
    cold: {
      bn: 'শীতল আবহাওয়া',
      en: 'Cold / Frost',
      adviceBn: '❄️ ঠান্ডা আবহাওয়া বিরাজ করছে — ফজরের ওযুতে কুসুম গরম পানি ব্যবহার করুন ও পর্যাপ্ত উষ্ণ পোশাক পরিধান করুন।',
      adviceEn: '❄️ Chilly atmosphere — use lukewarm water for morning ablution and dress warmly.',
    },
    wind: {
      bn: 'ঝড়ো হাওয়া',
      en: 'Strong Wind',
      adviceBn: '💨 তীব্র ঝড়ো বাতাস বইছে — ঘরের জানালা সাবধানে বন্ধ রাখুন এবং বাইরে চলাচলে সর্বোচ্চ সতর্কতা বজায় রাখুন।',
      adviceEn: '💨 Strong wind gusts — secure windows and exercise caution when commuting.',
    },
    heat: {
      bn: 'তীব্র গরম ও রোদ',
      en: 'High Heat / Sunny',
      adviceBn: '☀️ প্রচণ্ড গরম পড়ছে — শরীর আর্দ্র ও কর্মক্ষম রাখতে পর্যাপ্ত বিশুদ্ধ পানি ও ওরাল স্যালাইন গ্রহণ করুন।',
      adviceEn: '☀️ High heat warning — drink ample fluids and stay hydrated throughout the day.',
    },
    clear: {
      bn: 'মনোরম আবহাওয়া',
      en: 'Mild & Clear',
      adviceBn: '✨ মনোরম আবহাওয়া — ইবাদত ও নির্ধারিত কাজ সম্পন্ন করার জন্য অত্যন্ত চমৎকার সময়।',
      adviceEn: '✨ Pleasant mild weather — optimal conditions for your routines and prayers.',
    },
  };

  return (
    <div className={`relative overflow-hidden rounded-3xl border transition-all duration-500 font-bangla-display ${
      condition === 'rain'
        ? 'bg-linear-to-br from-slate-900 via-sky-950 to-slate-900 border-sky-500/40 text-sky-100 shadow-xl shadow-sky-950/40'
        : condition === 'cold'
        ? 'bg-linear-to-br from-slate-900 via-cyan-950 to-slate-900 border-cyan-400/40 text-cyan-100 shadow-xl shadow-cyan-950/40'
        : condition === 'wind'
        ? 'bg-linear-to-br from-slate-900 via-teal-950 to-slate-900 border-teal-400/40 text-teal-100 shadow-xl shadow-teal-950/40'
        : condition === 'heat'
        ? 'bg-linear-to-br from-slate-900 via-amber-950 to-slate-900 border-amber-500/40 text-amber-100 shadow-xl shadow-amber-950/40'
        : 'bg-linear-to-br from-slate-900 via-indigo-950 to-slate-900 border-indigo-500/40 text-indigo-100 shadow-xl shadow-indigo-950/40'
    } ${className}`}>

      {/* Dynamic Animated Weather Background Layers (High Intensity during timed seconds) */}
      {/* 1. Raindrop Falling Animation */}
      {condition === 'rain' && (
        <div className={`absolute inset-0 pointer-events-none overflow-hidden transition-opacity duration-700 ${
          isAnimationActive ? 'opacity-90' : 'opacity-35'
        }`}>
          <div className="absolute top-0 left-[8%] w-0.5 h-8 bg-sky-300 animate-rain-drop-1 rounded-full" />
          <div className="absolute top-0 left-[22%] w-0.5 h-10 bg-sky-200 animate-rain-drop-2 rounded-full" />
          <div className="absolute top-0 left-[38%] w-0.5 h-7 bg-sky-400 animate-rain-drop-3 rounded-full" />
          <div className="absolute top-0 left-[52%] w-0.5 h-9 bg-sky-300 animate-rain-drop-1 rounded-full" />
          <div className="absolute top-0 left-[68%] w-0.5 h-11 bg-sky-200 animate-rain-drop-2 rounded-full" />
          <div className="absolute top-0 left-[82%] w-0.5 h-8 bg-sky-300 animate-rain-drop-3 rounded-full" />
          <div className="absolute top-0 left-[94%] w-0.5 h-10 bg-sky-400 animate-rain-drop-2 rounded-full" />
          {isAnimationActive && (
            <>
              <div className="absolute bottom-2 left-[20%] w-4 h-1.5 border border-sky-400/60 rounded-full animate-ping" />
              <div className="absolute bottom-3 left-[65%] w-5 h-1.5 border border-sky-400/60 rounded-full animate-ping" />
            </>
          )}
        </div>
      )}

      {/* 2. Cold Snowflake Drifting Animation */}
      {condition === 'cold' && (
        <div className={`absolute inset-0 pointer-events-none overflow-hidden transition-opacity duration-700 ${
          isAnimationActive ? 'opacity-95' : 'opacity-40'
        }`}>
          <div className="absolute top-1 left-[12%] text-cyan-200 text-sm animate-snow-fall-1">❄</div>
          <div className="absolute top-2 left-[32%] text-white text-[11px] animate-snow-fall-2">❅</div>
          <div className="absolute top-0 left-[58%] text-cyan-300 text-base animate-snow-fall-3">❄</div>
          <div className="absolute top-2 left-[78%] text-white text-xs animate-snow-fall-1">❅</div>
          <div className="absolute top-1 left-[92%] text-cyan-200 text-xs animate-snow-fall-2">❄</div>
          <div className="absolute -inset-4 bg-cyan-400/10 rounded-full blur-2xl animate-pulse" />
        </div>
      )}

      {/* 3. Strong Wind Gust Lines Animation */}
      {condition === 'wind' && (
        <div className={`absolute inset-0 pointer-events-none overflow-hidden transition-opacity duration-700 ${
          isAnimationActive ? 'opacity-85' : 'opacity-35'
        }`}>
          <div className="absolute top-4 -left-10 w-28 h-0.5 bg-linear-to-r from-transparent via-teal-300 to-transparent animate-wind-sweep-1" />
          <div className="absolute top-10 -left-10 w-44 h-0.5 bg-linear-to-r from-transparent via-emerald-300 to-transparent animate-wind-sweep-2" />
          <div className="absolute top-16 -left-10 w-32 h-0.5 bg-linear-to-r from-transparent via-cyan-300 to-transparent animate-wind-sweep-3" />
        </div>
      )}

      {/* 4. High Heat Solar Flares Animation */}
      {condition === 'heat' && (
        <div className={`absolute inset-0 pointer-events-none overflow-hidden transition-opacity duration-700 ${
          isAnimationActive ? 'opacity-70' : 'opacity-30'
        }`}>
          <div className="absolute -top-12 -right-12 w-40 h-40 rounded-full bg-amber-500/25 blur-xl animate-heat-pulse" />
          <div className="absolute top-2 right-12 text-amber-300 text-3xl animate-spin-slow">☀️</div>
          <div className="absolute inset-x-0 bottom-0 h-9 bg-linear-to-t from-amber-500/20 to-transparent animate-heat-shimmer" />
        </div>
      )}

      {/* Widget Content */}
      <div className="relative z-10 p-4 space-y-3">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-white/10 shrink-0">
              {condition === 'rain' && <CloudRain size={16} className="text-sky-300 animate-bounce" />}
              {condition === 'cold' && <Snowflake size={16} className="text-cyan-300 animate-spin-slow" />}
              {condition === 'wind' && <Wind size={16} className="text-teal-300" />}
              {condition === 'heat' && <Sun size={16} className="text-amber-400 animate-spin-slow" />}
              {condition === 'clear' && <CloudSun size={16} className="text-indigo-300" />}
            </span>
            <div className="flex items-center gap-1.5 text-xs font-bold text-white">
              <MapPin size={12} className="text-slate-400" />
              <span>{isBn ? 'হোম স্ক্রিন আবহাওয়া আপডেট' : 'Live Weather Update'}</span>
            </div>
          </div>

          {/* Animation Duration Countdown & Replay Trigger */}
          <div className="flex items-center gap-1.5">
            {isAnimationActive ? (
              <span className="px-2.5 py-0.5 rounded-full bg-white/20 border border-white/30 text-[10px] font-extrabold text-white flex items-center gap-1 animate-pulse">
                <Sparkles size={11} className="text-amber-300" />
                <span>
                  {isBn
                    ? `অ্যানিমেশন চলছে (${toBengaliNumerals(secondsRemaining)} সে.)`
                    : `Animation Active (${secondsRemaining}s)`}
                </span>
              </span>
            ) : (
              <button
                type="button"
                onClick={() => startTimedAnimation(6)}
                className="px-2.5 py-0.5 rounded-full bg-white/15 hover:bg-white/25 border border-white/20 text-[10px] font-extrabold text-white flex items-center gap-1 transition-all active:scale-95 cursor-pointer"
                title={isBn ? 'অ্যানিমেশন পুনরায় চালান' : 'Replay animation'}
              >
                <RotateCcw size={10} />
                <span>{isBn ? 'পুনরায় দেখুন' : 'Replay'}</span>
              </button>
            )}

            {/* Refresh button */}
            <button
              type="button"
              onClick={fetchLiveWeather}
              disabled={isLoading}
              className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/15 transition-colors cursor-pointer"
              title={isBn ? 'লাইভ রিফ্রেশ' : 'Refresh live'}
            >
              <RefreshCw size={12} className={isLoading ? 'animate-spin' : ''} />
            </button>
          </div>
        </div>

        {/* Temperature in Celsius (°C) & Condition Display */}
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-baseline gap-2">
            <span className="text-3xl sm:text-4xl font-black text-white font-mono tracking-tight">
              {isBn ? `${toBengaliNumerals(tempC)}°` : `${tempC}°`}
            </span>
            <span className="text-sm font-black uppercase tracking-wider text-slate-200">
              {isBn ? 'সে. (°C)' : 'C'}
            </span>
            <div className="ml-2 pl-2 border-l border-white/20">
              <span className="text-xs sm:text-sm font-extrabold text-white block">
                {isBn ? conditionLabels[condition].bn : conditionLabels[condition].en}
              </span>
              <span className="text-[10px] text-slate-300 block">
                {isBn ? 'বর্তমান অবস্থান • ঢাকা' : 'Current Location • Dhaka'}
              </span>
            </div>
          </div>

          {/* Micro weather indicators */}
          <div className="flex items-center gap-3 text-right shrink-0 text-slate-300 text-[10px] font-mono">
            <div title={isBn ? 'বাতাসের আর্দ্রতা' : 'Humidity'}>
              <span className="block text-slate-400">{isBn ? 'আর্দ্রতা' : 'Humid'}</span>
              <span className="font-bold text-white">{isBn ? `${toBengaliNumerals(humidity)}%` : `${humidity}%`}</span>
            </div>
            <div title={isBn ? 'বাতাসের গতি' : 'Wind Speed'}>
              <span className="block text-slate-400">{isBn ? 'বাতাস' : 'Wind'}</span>
              <span className="font-bold text-white">{isBn ? `${toBengaliNumerals(windSpeed)} কিমি/ঘ` : `${windSpeed} km/h`}</span>
            </div>
          </div>
        </div>

        {/* Weather Advisory for routines, prayers, and safety */}
        <div className="p-2.5 rounded-2xl bg-black/30 border border-white/10 text-xs text-white/90 leading-relaxed flex items-start gap-2">
          <Sparkles size={13} className="shrink-0 text-amber-300 mt-0.5" />
          <p>{isBn ? conditionLabels[condition].adviceBn : conditionLabels[condition].adviceEn}</p>
        </div>

        {/* Interactive Condition Switcher Pills (Allows testing rain, cold, wind, heat animations on demand) */}
        {showTestPills && (
          <div className="flex items-center gap-1.5 pt-1 overflow-x-auto no-scrollbar">
            <span className="text-[10px] text-slate-300 font-bold shrink-0">
              {isBn ? 'অ্যানিমেশন টেস্ট:' : 'Test Animation:'}
            </span>
            {(['rain', 'cold', 'wind', 'heat'] as const).map((cond) => {
              const isActive = condition === cond;
              const icons: Record<'rain' | 'cold' | 'wind' | 'heat', string> = { rain: '🌧️', cold: '❄️', wind: '💨', heat: '☀️' };
              const namesBn: Record<'rain' | 'cold' | 'wind' | 'heat', string> = { rain: 'বৃষ্টি', cold: 'ঠান্ডা', wind: 'ঝড়ো হাওয়া', heat: 'তীব্র গরম' };
              const namesEn: Record<'rain' | 'cold' | 'wind' | 'heat', string> = { rain: 'Rain', cold: 'Cold', wind: 'Wind', heat: 'Heat' };
              const tempPresets: Record<'rain' | 'cold' | 'wind' | 'heat', number> = { rain: 26, cold: 14, wind: 24, heat: 36 };

              return (
                <button
                  key={cond}
                  type="button"
                  onClick={() => {
                    setCondition(cond);
                    setTempC(tempPresets[cond]);
                    startTimedAnimation(6);
                  }}
                  className={`px-2.5 py-1 rounded-xl text-[10px] font-extrabold flex items-center gap-1 transition-all active:scale-95 shrink-0 cursor-pointer ${
                    isActive
                      ? 'bg-white text-slate-950 shadow-md font-black scale-105'
                      : 'bg-white/10 hover:bg-white/20 text-slate-200 border border-white/10'
                  }`}
                >
                  <span>{icons[cond]}</span>
                  <span>{isBn ? namesBn[cond] : namesEn[cond]}</span>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
