import React from 'react';
import {
  ArrowRight,
  Check,
  Code2,
  Crown,
  FolderCode,
  Hammer,
  MonitorSmartphone,
  Moon,
  ShieldCheck,
  Smartphone,
  Sun,
  Zap,
} from 'lucide-react';
import type {
  SubscriptionPlan,
  SystemCapabilities,
  ThemeMode,
} from '../types/studio';
import { BrandLogo } from './BrandLogo';

interface LandingViewProps {
  plans: SubscriptionPlan[];
  capabilities: SystemCapabilities | null;
  theme: ThemeMode;
  onToggleTheme: () => void;
  onOpenAuth: (mode: 'login' | 'register') => void;
}

export const LandingView: React.FC<LandingViewProps> = ({
  plans,
  capabilities,
  theme,
  onToggleTheme,
  onOpenAuth,
}) => {
  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const features = [
    {
      Icon: Smartphone,
      title: 'Gerçek APK Oluşturma',
      desc: 'Android SDK build-tools (aapt2, d8, zipalign, apksigner) ile doğrudan imzalı .apk dosyası üretir.',
    },
    {
      Icon: MonitorSmartphone,
      title: 'Canlı HTML Önizleme',
      desc: 'Mobil, tablet ve masaüstü çerçevelerinde WebView uyumluluğunu ve JS hata günlüklerini anlık test edin.',
    },
    {
      Icon: Code2,
      title: 'Özel Uygulama İkonları',
      desc: 'PNG/JPG yükleyin, kare doğrulaması yapın; tüm mipmap yoğunlukları ve Android Adaptive Icon otomatik üretilsin.',
    },
    {
      Icon: ShieldCheck,
      title: 'Güvenli Proje Depolama',
      desc: 'ZIP Slip, Path Traversal, dosya türü denetimi ve kapalı JavaScript Bridge ile izole WebView mimarisi.',
    },
    {
      Icon: Crown,
      title: 'Premium Özellikler',
      desc: 'Öncelikli derleme kuyruğu, genişletilmiş proje depolama, yüksek aylık limitler ve özel ikon paketleri.',
    },
    {
      Icon: Zap,
      title: 'Hızlı Derleme Sistemi',
      desc: 'Gerçek backend aşamalarını ve derleme günlüklerini anlık takip ederek dakikalar içinde indirilebilir çıktı alın.',
    },
  ];

  const steps = [
    {
      num: '01',
      title: 'HTML veya ZIP Yükle',
      desc: 'Tek bir index.html ya da HTML/CSS/JS/SVG varlıklarınızı içeren ZIP arşivinizi güvenle yükleyin.',
    },
    {
      num: '02',
      title: 'APK ve İkonları Yapılandır',
      desc: 'Uygulama adı, paket kimliği (com.firma.uygulama), Adaptive Icon, Splash Screen ve WebView izinlerini ayarlayın.',
    },
    {
      num: '03',
      title: 'İmzalı APK İndir',
      desc: 'Backend derleme hattı WebView iskeletini ve manifesti oluşturup imzalanmış .apk çıktısını teslim eder.',
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-[#0B1020] dark:text-[#F8FAFC] flex flex-col">
      {/* Top Navigation */}
      <header className="sticky top-0 z-30 h-16 bg-white/90 dark:bg-[#0B1020]/90 backdrop-blur border-b border-slate-200 dark:border-white/[0.08]">
        <div className="max-w-7xl mx-auto h-full px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="shrink-0"
          >
            <BrandLogo variant="horizontal" size="md" />
          </button>

          <nav className="hidden lg:flex items-center gap-6 text-xs font-medium text-slate-600 dark:text-[#94A3B8]">
            <button
              type="button"
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="text-slate-900 dark:text-[#F8FAFC] whitespace-nowrap shrink-0"
            >
              Ana Sayfa
            </button>
            <button
              type="button"
              onClick={() => onOpenAuth('login')}
              className="hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0"
            >
              APK Oluştur
            </button>
            <button
              type="button"
              onClick={() => onOpenAuth('login')}
              className="hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0"
            >
              Projelerim
            </button>
            <button
              type="button"
              onClick={() => scrollToSection('pricing')}
              className="hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0"
            >
              Premium
            </button>
            <button
              type="button"
              onClick={() => onOpenAuth('login')}
              className="hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0"
            >
              Hesabım
            </button>
          </nav>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={onToggleTheme}
              aria-label="Tema Değiştir"
              className="p-2 rounded-lg border border-slate-200 dark:border-white/[0.08] bg-slate-100 dark:bg-[#111827] text-slate-700 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white transition-colors"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            <button
              type="button"
              onClick={() => onOpenAuth('login')}
              className="px-3.5 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-white/[0.1] text-slate-700 dark:text-[#F8FAFC] hover:bg-slate-100 dark:hover:bg-[#151D2E] transition-colors whitespace-nowrap shrink-0"
            >
              Giriş Yap
            </button>
            <button
              type="button"
              onClick={() => onOpenAuth('register')}
              className="px-3.5 py-2 text-xs font-semibold rounded-lg bg-[#6366F1] hover:bg-[#5558E3] text-white transition-colors whitespace-nowrap shrink-0"
            >
              Kayıt Ol
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 lg:py-24 px-4 sm:px-6 lg:px-8 border-b border-slate-200 dark:border-white/[0.06]">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 space-y-6">
            <p className="text-xs font-semibold uppercase tracking-wider text-[#6366F1]">
              HTML TO APK STUDIO · Your Website. Your Android App.
            </p>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-slate-900 dark:text-[#F8FAFC] leading-[1.12] [text-wrap:balance]">
              HTML Projelerini Android Uygulamalarına Dönüştür
            </h1>
            <p className="text-base text-slate-600 dark:text-[#94A3B8] leading-relaxed max-w-2xl">
              HTML, CSS ve JavaScript projelerini birkaç adımda gerçek Android APK dosyalarına
              dönüştür. Kotlin WebView iskeleti, Adaptive Icon kaynakları, AndroidManifest
              yapılandırması ve SHA-256 doğrulamalı derleme altyapısı tek platformda.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => onOpenAuth('register')}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#6366F1] hover:bg-[#5558E3] text-white text-sm font-semibold transition-colors whitespace-nowrap"
              >
                <Hammer className="w-4 h-4" />
                <span>APK OLUŞTUR</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => scrollToSection('how-it-works')}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-xl border border-slate-300 dark:border-white/[0.12] bg-white dark:bg-[#151D2E] hover:bg-slate-100 dark:hover:bg-[#1A2438] text-slate-800 dark:text-[#F8FAFC] text-sm font-medium transition-colors whitespace-nowrap"
              >
                <span>Nasıl Çalışır?</span>
              </button>
            </div>

            {capabilities && (
              <p className="text-xs text-slate-500 dark:text-[#94A3B8] pt-1">
                Derleyici Altyapısı:{' '}
                <span className="font-medium text-slate-800 dark:text-[#F8FAFC]">
                  {capabilities.summary}
                </span>
              </p>
            )}
          </div>

          {/* Minimal Product Showcase Frame */}
          <div className="lg:col-span-5">
            <div className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#151D2E] overflow-hidden shadow-sm">
              <div className="px-5 py-3.5 border-b border-slate-200 dark:border-white/[0.08] bg-slate-50 dark:bg-[#111827] flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-800 dark:text-[#F8FAFC]">
                  <FolderCode className="w-4 h-4 text-[#6366F1]" />
                  <span>Android Derleme Hattı</span>
                </div>
                <span className="text-[11px] font-mono text-slate-500 dark:text-[#94A3B8]">
                  API 34 · APK v2/v3
                </span>
              </div>

              <div className="p-5 space-y-3 text-xs">
                <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-white/[0.06]">
                  <span className="text-slate-500 dark:text-[#94A3B8]">Giriş Paketi</span>
                  <span className="font-mono text-slate-900 dark:text-[#F8FAFC]">
                    index.html + assets/
                  </span>
                </div>
                <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-white/[0.06]">
                  <span className="text-slate-500 dark:text-[#94A3B8]">WebView Motoru</span>
                  <span className="font-mono text-slate-900 dark:text-[#F8FAFC]">
                    WebViewAssetLoader (HTTPS)
                  </span>
                </div>
                <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-white/[0.06]">
                  <span className="text-slate-500 dark:text-[#94A3B8]">İkon Kaynakları</span>
                  <span className="font-mono text-slate-900 dark:text-[#F8FAFC]">
                    mdpi → xxxhdpi + Adaptive
                  </span>
                </div>
                <div className="flex items-center justify-between py-2">
                  <span className="text-slate-500 dark:text-[#94A3B8]">Çıktı Doğrulama</span>
                  <span className="font-mono font-semibold text-[#22C55E]">
                    apksigner verify + SHA-256
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6 Core Features */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-2xl mb-10">
            <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-[#F8FAFC]">
              Geliştiriciler İçin Üretilmiş Dönüştürme Platformu
            </h2>
            <p className="mt-2 text-sm text-slate-600 dark:text-[#94A3B8]">
              Web uygulamanızı Android cihazlarda yüksek performanslı yerel uygulamaya çevirmek için
              gereken tüm araçlar.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((feat) => (
              <div
                key={feat.title}
                className="rounded-xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#151D2E] p-6"
              >
                <div className="w-9 h-9 rounded-lg bg-[#6366F1]/10 flex items-center justify-center mb-4">
                  <feat.Icon className="w-4 h-4 text-[#6366F1]" />
                </div>
                <h3 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
                  {feat.title}
                </h3>
                <p className="mt-2 text-xs text-slate-600 dark:text-[#94A3B8] leading-relaxed">
                  {feat.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section
        id="how-it-works"
        className="py-16 px-4 sm:px-6 lg:px-8 bg-white dark:bg-[#111827] border-y border-slate-200 dark:border-white/[0.06]"
      >
        <div className="max-w-7xl mx-auto">
          <div className="max-w-2xl mb-10">
            <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-[#F8FAFC]">
              Nasıl Çalışır?
            </h2>
            <p className="mt-2 text-sm text-slate-600 dark:text-[#94A3B8]">
              Üç adımda web kaynak kodunuzdan kurulumu hazır imzalı Android APK dosyasına ulaşın.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {steps.map((st) => (
              <div
                key={st.num}
                className="rounded-xl border border-slate-200 dark:border-white/[0.08] bg-slate-50 dark:bg-[#151D2E] p-6"
              >
                <div className="text-xs font-mono font-bold text-[#6366F1] mb-3 tabular-nums">
                  ADIM {st.num}
                </div>
                <h3 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
                  {st.title}
                </h3>
                <p className="mt-2 text-xs text-slate-600 dark:text-[#94A3B8] leading-relaxed">
                  {st.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Overview */}
      <section id="pricing" className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-2xl mb-10">
            <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-[#F8FAFC]">
              Şeffaf Premium Paketler
            </h2>
            <p className="mt-2 text-sm text-slate-600 dark:text-[#94A3B8]">
              Ücretsiz planda hemen başlayın veya daha yüksek derleme limitleri ve öncelikli kuyruk
              için Premium’a geçin.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-stretch">
            {plans.map((plan) => {
              const highlighted = Boolean(plan.is_highlighted);
              return (
                <div
                  key={plan.id}
                  className={`rounded-2xl p-6 flex flex-col justify-between border ${
                    highlighted
                      ? 'bg-white dark:bg-[#151D2E] border-[#EAB308] shadow-sm'
                      : 'bg-white dark:bg-[#151D2E] border-slate-200 dark:border-white/[0.08]'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <h3 className="text-base font-bold text-slate-900 dark:text-[#F8FAFC] flex items-center gap-2">
                        <Crown
                          className={`w-4 h-4 ${
                            highlighted ? 'text-[#EAB308]' : 'text-[#6366F1]'
                          }`}
                        />
                        <span>{plan.name}</span>
                      </h3>
                      {highlighted && (
                        <span className="text-[11px] font-semibold text-[#CA8A04] dark:text-[#EAB308]">
                          En Avantajlı
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-600 dark:text-[#94A3B8] min-h-[34px]">
                      {plan.description}
                    </p>
                    <div className="mt-5 pb-5 border-b border-slate-200 dark:border-white/[0.08] flex items-baseline gap-2">
                      <span className="text-3xl font-bold text-slate-900 dark:text-[#F8FAFC] tabular-nums">
                        {plan.price_try.toLocaleString('tr-TR')} TL
                      </span>
                      <span className="text-xs text-slate-500 dark:text-[#94A3B8]">
                        / {plan.is_lifetime ? 'Süresiz' : `${plan.duration_days} gün`}
                      </span>
                    </div>
                    <ul className="mt-5 space-y-2.5 text-xs text-slate-700 dark:text-[#CBD5E1]">
                      {plan.features.map((feat) => (
                        <li key={feat} className="flex items-start gap-2">
                          <Check
                            className={`w-4 h-4 shrink-0 mt-0.5 ${
                              highlighted ? 'text-[#EAB308]' : 'text-[#22C55E]'
                            }`}
                          />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <button
                    type="button"
                    onClick={() => onOpenAuth('register')}
                    className={`mt-7 w-full py-2.5 px-4 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap ${
                      highlighted
                        ? 'bg-[#EAB308] hover:bg-[#CA8A04] text-[#0B1020]'
                        : 'bg-[#6366F1] hover:bg-[#5558E3] text-white'
                    }`}
                  >
                    Hemen Başla
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200 dark:border-white/[0.08] py-6 px-4 sm:px-6 lg:px-8 bg-white dark:bg-[#111827]">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 dark:text-[#94A3B8]">
          <BrandLogo variant="horizontal" size="sm" showSlogan={false} />
          <span>Your Website. Your Android App.</span>
        </div>
      </footer>
    </div>
  );
};
