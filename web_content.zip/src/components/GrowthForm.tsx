import React, { useState } from 'react';
import {
  User,
  Lock,
  Eye,
  EyeOff,
  Sparkles,
  ShieldCheck,
  Zap,
  CheckCircle2,
  TrendingUp,
  Instagram,
  ArrowRight,
  Flame,
} from 'lucide-react';
import { AppSettings } from '../types';

interface GrowthFormProps {
  settings: AppSettings;
  onInitiateAddAccount: (username: string, password: string) => void;
}

export const GrowthForm: React.FC<GrowthFormProps> = ({
  settings,
  onInitiateAddAccount,
}) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const cleanUser = username.trim().replace(/^@+/, '');
    if (!cleanUser) {
      setError('कृपया Instagram username दर्ज करें (Please enter username)');
      return;
    }
    if (!password.trim()) {
      setError('कृपया Instagram password दर्ज करें (Please enter password)');
      return;
    }
    if (password.trim().length < 4) {
      setError('Password कम से कम 4 अक्षरों का होना चाहिए (Password too short)');
      return;
    }

    onInitiateAddAccount(cleanUser, password.trim());
  };

  return (
    <div className="w-full max-w-xl mx-auto">
      {/* Hero Header Section */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gradient-to-r from-purple-500/15 via-pink-500/15 to-purple-500/15 border border-purple-500/30 text-purple-200 text-xs font-medium mb-4 shadow-inner">
          <Flame className="w-3.5 h-3.5 text-pink-400 fill-pink-400 animate-pulse" />
          <span>#1 Instant Instagram Growth Engine</span>
        </div>

        {/* Customizable App Title */}
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight bg-gradient-to-r from-white via-purple-100 to-pink-300 bg-clip-text text-transparent pb-1">
          {settings.app_title || 'Grow Your Instagram'}
        </h1>

        {/* Customizable App Subtitle */}
        <p className="mt-2 text-sm sm:text-base text-slate-300 font-medium">
          {settings.app_subtitle || 'Get real followers instantly ✨'}
        </p>

        {/* Social Proof Stats */}
        <div className="mt-4 flex items-center justify-center gap-4 text-xs text-slate-400">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-emerald-300 font-semibold">12,480+ Orders Delivered</span>
          </div>
          <span>•</span>
          <div className="flex items-center gap-1">
            <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
            <span>Instant Dispatch</span>
          </div>
        </div>
      </div>

      {/* Main Card */}
      <div className="relative rounded-3xl p-6 sm:p-8 bg-slate-900/90 border border-purple-500/30 shadow-2xl shadow-purple-950/70 backdrop-blur-2xl overflow-hidden">
        {/* Decorative Top Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-1 bg-gradient-to-r from-transparent via-pink-500 to-transparent opacity-80" />
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-pink-600/20 rounded-full blur-3xl pointer-events-none" />

        {/* Card Titles (Customizable via settings) */}
        <div className="mb-6 border-b border-purple-500/15 pb-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
                <Instagram className="w-5 h-5 text-pink-400" />
                {settings.form_title || 'Add Instagram Account'}
              </h2>
              <p className="text-xs text-purple-300/80 mt-0.5">
                {settings.form_subtitle || 'अपना Instagram अकाउंट जोड़ें'}
              </p>
            </div>
            <div className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-[11px] font-semibold flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Safe SSL</span>
            </div>
          </div>
        </div>

        {/* Error message */}
        {error && (
          <div className="mb-5 p-3 rounded-xl bg-rose-950/80 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Username Input */}
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
              Instagram Username
            </label>
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 group-focus-within:text-pink-400 transition-colors">
                <span className="font-bold text-sm text-pink-400">@</span>
              </div>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="your_instagram_username"
                autoComplete="off"
                className="w-full pl-9 pr-4 py-3 rounded-xl bg-slate-950/80 border border-purple-500/25 focus:border-pink-500 focus:ring-2 focus:ring-pink-500/20 text-slate-100 placeholder:text-slate-500 text-sm font-medium transition-all outline-none"
              />
            </div>
            {username.trim() && (
              <p className="text-[11px] text-pink-300/90 font-medium flex items-center gap-1 pt-0.5">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                Target profile: <span className="font-mono font-semibold">@{username.replace(/^@+/, '')}</span>
              </p>
            )}
          </div>

          {/* Password Input */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
                Instagram Password
              </label>
              <span className="text-[10px] text-slate-400 flex items-center gap-1">
                <Lock className="w-3 h-3 text-purple-400" />
                End-to-End Encrypted
              </span>
            </div>
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 group-focus-within:text-pink-400 transition-colors">
                <Lock className="w-4 h-4 text-purple-400" />
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                autoComplete="current-password"
                className="w-full pl-10 pr-11 py-3 rounded-xl bg-slate-950/80 border border-purple-500/25 focus:border-pink-500 focus:ring-2 focus:ring-pink-500/20 text-slate-100 placeholder:text-slate-500 text-sm font-medium transition-all outline-none"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-purple-300 focus:outline-none transition-colors"
                title={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? (
                  <EyeOff className="w-4 h-4" />
                ) : (
                  <Eye className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full mt-2 relative group overflow-hidden rounded-xl p-[1px] focus:outline-none focus:ring-2 focus:ring-pink-500/40"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-amber-500 via-rose-500 to-purple-600 rounded-xl transition-all duration-300 group-hover:opacity-90 group-active:scale-95" />
            <div className="relative px-6 py-3.5 rounded-xl bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 flex items-center justify-center gap-2 text-white font-bold text-sm tracking-wide shadow-xl shadow-purple-900/50 group-hover:brightness-110 transition-all">
              <Sparkles className="w-4 h-4 text-amber-300 animate-spin" style={{ animationDuration: '4s' }} />
              <span>Add Account & Select Followers</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </button>
        </form>

        {/* Security badges */}
        <div className="mt-6 pt-5 border-t border-purple-500/15 grid grid-cols-3 gap-2 text-center">
          <div className="p-2 rounded-xl bg-slate-950/50 border border-purple-500/10">
            <ShieldCheck className="w-4 h-4 mx-auto text-emerald-400 mb-1" />
            <p className="text-[10px] font-bold text-slate-200">100% Secure</p>
            <p className="text-[9px] text-slate-400">Zero Ban Risk</p>
          </div>
          <div className="p-2 rounded-xl bg-slate-950/50 border border-purple-500/10">
            <Zap className="w-4 h-4 mx-auto text-amber-400 mb-1" />
            <p className="text-[10px] font-bold text-slate-200">High Speed</p>
            <p className="text-[9px] text-slate-400">24h Delivery</p>
          </div>
          <div className="p-2 rounded-xl bg-slate-950/50 border border-purple-500/10">
            <TrendingUp className="w-4 h-4 mx-auto text-pink-400 mb-1" />
            <p className="text-[10px] font-bold text-slate-200">Real Profiles</p>
            <p className="text-[9px] text-slate-400">High Retention</p>
          </div>
        </div>
      </div>

      {/* Live Activity Marquee / Ticker */}
      <div className="mt-6 p-3 rounded-2xl bg-slate-900/60 border border-purple-500/20 backdrop-blur-md">
        <div className="flex items-center gap-2 text-xs">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping shrink-0" />
          <span className="text-emerald-400 font-bold shrink-0">Live Orders:</span>
          <div className="text-slate-300 truncate">
            <span className="text-pink-300 font-mono font-medium">@rohit_sharma_official</span> just received{' '}
            <span className="text-amber-300 font-bold">+1,000 Real Followers</span> 🚀
          </div>
        </div>
      </div>
    </div>
  );
};
