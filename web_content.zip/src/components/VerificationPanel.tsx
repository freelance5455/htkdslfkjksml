/**
 * GODEX v0.0.1 - 5-Pillar Verification Matrix Panel
 */

import React from 'react';
import { ShieldCheck, CheckCircle2, AlertTriangle, RefreshCw, X, Play } from 'lucide-react';
import { VerificationReport } from '../types';

interface VerificationPanelProps {
  report: VerificationReport | null;
  isOpen: boolean;
  onClose: () => void;
  onRerun: () => void;
  isVerifying: boolean;
}

export const VerificationPanel: React.FC<VerificationPanelProps> = ({
  report,
  isOpen,
  onClose,
  onRerun,
  isVerifying
}) => {
  if (!isOpen || !report) return null;

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4 select-none font-mono">
      <div className="w-full max-w-2xl bg-[#090B10] border border-[#1C2230] rounded-lg shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="h-12 px-5 border-b border-[#1C2230] flex items-center justify-between bg-[#0D1017] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded bg-[#101924] border border-cyan-500/50 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <h2 className="text-xs font-bold text-white flex items-center gap-2">
                VERIFICATION_MATRIX.5_PILLAR
              </h2>
              <p className="text-[10px] text-neutral-400">Strict AST → Runtime → DOM → State → Regression Validation</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded text-neutral-400 hover:text-white hover:bg-[#161C2A] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-[#07080D]">
          {/* Summary Score Card */}
          <div className="p-4 rounded bg-[#0D1018] border border-[#1C2334] flex items-center justify-between">
            <div className="space-y-1">
              <div className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider">Overall Matrix Status</div>
              <div className="text-lg font-bold text-white flex items-center gap-2">
                {report.passed ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-rose-400" />
                )}
                <span className={report.passed ? 'text-emerald-300' : 'text-rose-400'}>
                  {report.passed ? '100% VERIFIED' : 'VERIFICATION FAILED'}
                </span>
              </div>
              <p className="text-[11px] text-neutral-400 max-w-md font-sans">{report.summary}</p>
            </div>

            <div className={`w-14 h-14 rounded border flex flex-col items-center justify-center shrink-0 shadow-lg ${
              report.passed ? 'bg-[#101A28] border-cyan-500/60 shadow-cyan-950/40' : 'bg-[#241014] border-rose-500/60 shadow-rose-950/40'
            }`}>
              <span className={`text-base font-bold ${report.passed ? 'text-cyan-300' : 'text-rose-400'}`}>{report.score}%</span>
              <span className={`text-[8px] uppercase font-mono ${report.passed ? 'text-cyan-400' : 'text-rose-400'}`}>Score</span>
            </div>
          </div>

          {/* Real Project State Evidence Section */}
          {report.evidence && (
            <div className="p-3.5 rounded bg-[#0C101A] border border-[#1C283E] space-y-2">
              <div className="text-[10px] font-bold font-mono text-cyan-400 uppercase tracking-wider flex items-center justify-between">
                <span>REAL_STATE_EVIDENCE (NO SIMULATION)</span>
                <span className={`px-1.5 py-0.2 rounded text-[9px] ${report.evidence.taskCompleted ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-rose-950 text-rose-300 border border-rose-800'}`}>
                  {report.evidence.taskCompleted ? 'AUDITED: PASS' : 'AUDITED: REJECTED'}
                </span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] font-mono">
                <div className="p-2 rounded bg-[#080B12] border border-[#161F30]">
                  <div className="text-neutral-500 text-[9px]">FILES MODIFIED</div>
                  <div className="text-white font-bold">{report.evidence.filesModified}</div>
                </div>
                <div className="p-2 rounded bg-[#080B12] border border-[#161F30]">
                  <div className="text-neutral-500 text-[9px]">FILES CREATED</div>
                  <div className="text-cyan-300 font-bold">{report.evidence.filesCreated}</div>
                </div>
                <div className="p-2 rounded bg-[#080B12] border border-[#161F30]">
                  <div className="text-neutral-500 text-[9px]">LINES DIFF</div>
                  <div className="text-emerald-400 font-bold">+{report.evidence.totalLinesAdded} / -{report.evidence.totalLinesDeleted}</div>
                </div>
                <div className="p-2 rounded bg-[#080B12] border border-[#161F30]">
                  <div className="text-neutral-500 text-[9px]">DOM ASSERTIONS</div>
                  <div className={report.evidence.browserPassed ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                    {report.evidence.browserPassed ? 'PASSED' : 'FAILED'}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Truthful Dossier Section (WHAT I CHANGED / WHAT I TESTED / WHAT PASSED / WHAT FAILED / WHAT I COULD NOT VERIFY) */}
          {report.dossier && (
            <div className="p-3.5 rounded bg-[#0A0D15] border border-[#182335] space-y-3">
              <div className="text-[10px] font-bold font-mono text-indigo-400 uppercase tracking-wider flex items-center justify-between">
                <span>TRUTHFUL_ENGINEERING_DOSSIER</span>
                <span className="text-[9px] text-neutral-500 font-mono">EPISTEMIC SEPARATION</span>
              </div>

              {/* What I Changed */}
              {report.dossier.whatIChanged.length > 0 && (
                <div className="space-y-1">
                  <div className="text-[10px] font-bold text-neutral-300 font-mono flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                    WHAT I CHANGED ({report.dossier.whatIChanged.length})
                  </div>
                  <div className="space-y-1 pl-3 text-[11px] font-mono text-cyan-300/90">
                    {report.dossier.whatIChanged.map((item, idx) => (
                      <div key={idx} className="truncate">• {item}</div>
                    ))}
                  </div>
                </div>
              )}

              {/* What I Tested */}
              {report.dossier.whatITested.length > 0 && (
                <div className="space-y-1">
                  <div className="text-[10px] font-bold text-neutral-300 font-mono flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                    WHAT I TESTED ({report.dossier.whatITested.length})
                  </div>
                  <div className="space-y-1 pl-3 text-[11px] font-mono text-neutral-300">
                    {report.dossier.whatITested.map((item, idx) => (
                      <div key={idx} className="truncate">• {item}</div>
                    ))}
                  </div>
                </div>
              )}

              {/* What Passed */}
              {report.dossier.whatPassed.length > 0 && (
                <div className="space-y-1">
                  <div className="text-[10px] font-bold text-emerald-400 font-mono flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    WHAT PASSED ({report.dossier.whatPassed.length})
                  </div>
                  <div className="space-y-1 pl-3 text-[11px] font-mono text-emerald-300">
                    {report.dossier.whatPassed.map((item, idx) => (
                      <div key={idx} className="truncate">✓ {item}</div>
                    ))}
                  </div>
                </div>
              )}

              {/* What Failed */}
              {report.dossier.whatFailed.length > 0 && (
                <div className="space-y-1">
                  <div className="text-[10px] font-bold text-rose-400 font-mono flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
                    WHAT FAILED ({report.dossier.whatFailed.length})
                  </div>
                  <div className="space-y-1 pl-3 text-[11px] font-mono text-rose-300">
                    {report.dossier.whatFailed.map((item, idx) => (
                      <div key={idx} className="truncate">✗ {item}</div>
                    ))}
                  </div>
                </div>
              )}

              {/* What I Could Not Verify */}
              {report.dossier.whatICouldNotVerify.length > 0 && (
                <div className="space-y-1">
                  <div className="text-[10px] font-bold text-amber-400 font-mono flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                    WHAT I COULD NOT VERIFY ({report.dossier.whatICouldNotVerify.length})
                  </div>
                  <div className="space-y-1 pl-3 text-[11px] font-mono text-amber-300/80">
                    {report.dossier.whatICouldNotVerify.map((item, idx) => (
                      <div key={idx} className="truncate">⚠ {item}</div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* UI/UX Quality & Anti-Slop Audit Section */}
          {report.uiQuality && (
            <div className="p-3.5 rounded bg-[#0D121F] border border-[#20304C] space-y-3">
              <div className="text-[10px] font-bold font-mono text-cyan-400 uppercase tracking-wider flex items-center justify-between">
                <span>UI_UX_DESIGN_INTELLIGENCE (ZERO-SLOP AUDIT)</span>
                <span className="px-2 py-0.5 rounded text-[9px] bg-cyan-950 text-cyan-300 border border-cyan-700 font-mono">
                  SCORE: {report.uiQuality.overallScore}% ({report.uiQuality.rating})
                </span>
              </div>

              {report.uiQuality.passedInvariants.length > 0 && (
                <div className="space-y-1">
                  <div className="text-[10px] font-bold text-emerald-400 font-mono flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    VERIFIED DESIGN INVARIANTS ({report.uiQuality.passedInvariants.length})
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 pl-3 text-[11px] font-mono text-emerald-300">
                    {report.uiQuality.passedInvariants.map((inv, idx) => (
                      <div key={idx} className="truncate">✓ {inv}</div>
                    ))}
                  </div>
                </div>
              )}

              {report.uiQuality.violations.length > 0 && (
                <div className="space-y-1">
                  <div className="text-[10px] font-bold text-rose-400 font-mono flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
                    FLAGGED SLOP VIOLATIONS ({report.uiQuality.violations.length})
                  </div>
                  <div className="space-y-1 pl-3 text-[11px] font-mono text-rose-300">
                    {report.uiQuality.violations.map((v, idx) => (
                      <div key={idx} className="truncate">✗ {v.ruleName}: {v.description}</div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 5-Pillar Checks List */}
          <div className="space-y-1.5">
            <div className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider px-1">
              Checkpoints ({report.passedChecks}/{report.totalChecks})
            </div>

            {report.checks.map(check => (
              <div
                key={check.id}
                className="p-2.5 rounded bg-[#0D1018] border border-[#1B2232] flex items-start justify-between gap-3 text-xs"
              >
                <div className="flex items-start gap-2.5">
                  {check.status === 'passed' ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  )}
                  <div className="space-y-0.5">
                    <div className="font-semibold text-neutral-200 text-xs">{check.name}</div>
                    <div className="text-[10px] text-neutral-400 font-sans">{check.message}</div>
                  </div>
                </div>

                {check.durationMs && (
                  <span className="text-[9px] font-mono text-neutral-500 shrink-0">
                    {check.durationMs}ms
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="h-12 px-5 border-t border-[#1C2230] bg-[#0D1017] flex items-center justify-between shrink-0">
          <span className="text-[10px] text-neutral-500 font-mono">
            LAST_AUDIT: {new Date(report.timestamp).toLocaleTimeString()}
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1 rounded bg-[#151D2C] hover:bg-[#1C263A] border border-[#232F46] text-xs font-semibold text-neutral-200 transition-colors"
            >
              CLOSE
            </button>
            <button
              onClick={onRerun}
              disabled={isVerifying}
              className="flex items-center gap-1.5 px-3 py-1 rounded bg-[#0E2A38] hover:bg-[#133A4E] border border-cyan-500/60 text-xs font-bold text-cyan-300 shadow transition-all disabled:opacity-50"
            >
              {isVerifying ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
              <span>RE-RUN FULL SUITE</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
