import React, { useState, useEffect } from 'react';
import { 
  Cpu, Activity, Play, Pause, XCircle, CheckCircle2, 
  Layers, RefreshCw, X, Shield, Smartphone, Database, 
  Globe, Code, ListChecks, Scan, Zap, AlertCircle 
} from 'lucide-react';
import { 
  multiAgentService, 
  SpecializedAgent, 
  AgentTask 
} from '../services/multiAgentService';

interface MissionControlModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTaskDispatched?: (title: string) => void;
}

export const MissionControlModal: React.FC<MissionControlModalProps> = ({
  isOpen,
  onClose,
  onTaskDispatched,
}) => {
  const [agents, setAgents] = useState<SpecializedAgent[]>([]);
  const [tasks, setTasks] = useState<AgentTask[]>([]);
  const [telemetry, setTelemetry] = useState(() => multiAgentService.getTelemetry());
  const [filterAgent, setFilterAgent] = useState<string>('all');

  useEffect(() => {
    if (isOpen) {
      setAgents(multiAgentService.getAgents());
      setTasks(multiAgentService.getTasks());
      setTelemetry(multiAgentService.getTelemetry());

      const unsubscribe = multiAgentService.subscribe(() => {
        setAgents(multiAgentService.getAgents());
        setTasks(multiAgentService.getTasks());
        setTelemetry(multiAgentService.getTelemetry());
      });

      return () => unsubscribe();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handlePause = (id: string) => {
    multiAgentService.pauseTask(id);
  };

  const handleResume = (id: string) => {
    multiAgentService.resumeTask(id);
  };

  const handleCancel = (id: string) => {
    multiAgentService.cancelTask(id);
  };

  const handleQuickDispatch = (title: string, agentId: string, substeps: string[]) => {
    multiAgentService.dispatchTask(title, agentId, substeps);
    if (onTaskDispatched) {
      onTaskDispatched(title);
    }
  };

  const getAgentIcon = (iconName: string) => {
    switch (iconName) {
      case 'Cpu': return <Cpu className="w-4 h-4 text-cyan-400" />;
      case 'Globe': return <Globe className="w-4 h-4 text-blue-400" />;
      case 'Code': return <Code className="w-4 h-4 text-emerald-400" />;
      case 'Smartphone': return <Smartphone className="w-4 h-4 text-purple-400" />;
      case 'Shield': return <Shield className="w-4 h-4 text-amber-400" />;
      case 'Database': return <Database className="w-4 h-4 text-pink-400" />;
      case 'ListChecks': return <ListChecks className="w-4 h-4 text-indigo-400" />;
      case 'Scan': return <Scan className="w-4 h-4 text-teal-400" />;
      case 'Activity': return <Activity className="w-4 h-4 text-cyan-400" />;
      default: return <RefreshCw className="w-4 h-4 text-green-400" />;
    }
  };

  const filteredTasks = filterAgent === 'all' 
    ? tasks 
    : tasks.filter(t => t.agentId === filterAgent);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-gray-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-4xl bg-gray-900 border border-cyan-500/40 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-gray-950/90 border-b border-cyan-500/30">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-cyan-400" />
            <h3 className="font-tech text-base tracking-wide uppercase text-cyan-100 flex items-center gap-2">
              MISSION CONTROL // MULTI-AGENT INTELLIGENCE (ULTRA 3.0)
              <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300 font-mono-tech">
                10 SPECIALIZED SUB-AGENTS
              </span>
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-cyan-400 hover:bg-cyan-500/20 cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Telemetry Bar */}
        <div className="px-5 py-2.5 bg-cyan-950/40 border-b border-cyan-500/20 flex flex-wrap items-center justify-between gap-3 text-xs font-mono-tech">
          <div className="flex items-center gap-2">
            <span className="text-cyan-400/70">ACTIVE AGENTS:</span>
            <span className="text-cyan-200 font-bold">{telemetry.activeAgents} / 10 ONLINE</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-cyan-400/70">TASKS RUNNING:</span>
            <span className="text-emerald-400 font-bold">{telemetry.runningTasks} ACTIVE</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-cyan-400/70">AVG LATENCY:</span>
            <span className="text-cyan-300 font-bold">{telemetry.avgLatencyMs} ms</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-cyan-400/70">BUDGET:</span>
            <span className="text-amber-300 font-bold">{telemetry.memoryEfficiency}</span>
          </div>
        </div>

        {/* Quick Dispatch Buttons */}
        <div className="px-5 py-3 bg-gray-950/60 border-b border-cyan-500/20 flex items-center gap-2 overflow-x-auto text-xs font-tech uppercase">
          <span className="text-cyan-400/70 shrink-0 font-mono-tech text-[11px]">DISPATCH:</span>
          
          <button
            onClick={() => handleQuickDispatch(
              'Execute Full ARC Reactor Diagnostic Scan',
              'diagnostic',
              ['Sampling system latency', 'Reading Redmi 12 RAM heap', 'Checking thermal buffer']
            )}
            className="px-2.5 py-1 rounded-lg bg-gray-900 hover:bg-cyan-950 border border-cyan-500/30 text-cyan-200 shrink-0 cursor-pointer transition-all active:scale-95 flex items-center gap-1.5"
          >
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
            ARC Diagnostics
          </button>

          <button
            onClick={() => handleQuickDispatch(
              'Run Phishing & Neural Security Verification',
              'security',
              ['Scanning network whitelist', 'Validating passkey credentials', 'Auditing URL integrity']
            )}
            className="px-2.5 py-1 rounded-lg bg-gray-900 hover:bg-cyan-950 border border-cyan-500/30 text-amber-200 shrink-0 cursor-pointer transition-all active:scale-95 flex items-center gap-1.5"
          >
            <Shield className="w-3.5 h-3.5 text-amber-400" />
            Security Audit
          </button>

          <button
            onClick={() => handleQuickDispatch(
              'Synthesize AST Checkpoint & Verify Code Safety',
              'coding',
              ['AST parse with esbuild', 'Check syntactic invariants', 'Generate snapshot checkpoint']
            )}
            className="px-2.5 py-1 rounded-lg bg-gray-900 hover:bg-cyan-950 border border-cyan-500/30 text-emerald-200 shrink-0 cursor-pointer transition-all active:scale-95 flex items-center gap-1.5"
          >
            <Code className="w-3.5 h-3.5 text-emerald-400" />
            AST Sandbox
          </button>

          <button
            onClick={() => handleQuickDispatch(
              'Synchronize Neural Synapse Long-term Vault',
              'memory',
              ['Indexing personal preferences', 'Securing Harman Sir rules', 'Verifying integrity hash']
            )}
            className="px-2.5 py-1 rounded-lg bg-gray-900 hover:bg-cyan-950 border border-cyan-500/30 text-pink-200 shrink-0 cursor-pointer transition-all active:scale-95 flex items-center gap-1.5"
          >
            <Database className="w-3.5 h-3.5 text-pink-400" />
            Sync Memory
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 p-5 overflow-y-auto space-y-6">
          
          {/* 10 Agents Grid */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-tech uppercase text-cyan-200 font-bold tracking-wider">
                Specialized Sub-Agent Fleet
              </h4>
              <span className="text-[11px] font-mono-tech text-cyan-400/70">
                Click an agent to filter active tasks
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
              {agents.map((agent) => (
                <button
                  key={agent.id}
                  onClick={() => setFilterAgent(filterAgent === agent.id ? 'all' : agent.id)}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer relative ${
                    filterAgent === agent.id
                      ? 'bg-cyan-950/80 border-cyan-400 shadow-lg glow-cyan-sm'
                      : 'bg-gray-950/70 border-cyan-500/20 hover:border-cyan-500/40'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="p-1.5 rounded-lg bg-gray-900 border border-gray-800">
                      {getAgentIcon(agent.iconName)}
                    </div>
                    <span className={`text-[9px] px-1.5 py-0.5 rounded font-mono-tech font-bold uppercase ${
                      agent.status === 'ACTIVE' 
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' 
                        : 'bg-gray-800 text-gray-400 border border-gray-700'
                    }`}>
                      {agent.status}
                    </span>
                  </div>

                  <div className="font-tech text-xs font-bold text-cyan-100 truncate">
                    {agent.name}
                  </div>
                  <div className="text-[10px] font-mono-tech text-cyan-400/60 truncate">
                    {agent.codename}
                  </div>
                  
                  <div className="mt-2 pt-1.5 border-t border-cyan-500/10 flex items-center justify-between text-[10px] font-mono-tech text-cyan-300/80">
                    <span>Tasks: {agent.activeTaskCount}</span>
                    <span>{agent.latencyMs} ms</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Active Tasks Queue */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-tech uppercase text-cyan-200 font-bold tracking-wider flex items-center gap-2">
                Live Mission Task Queue
                {filterAgent !== 'all' && (
                  <span className="text-[10px] text-cyan-400 font-mono-tech font-normal">
                    (Filtered by {agents.find(a => a.id === filterAgent)?.name})
                  </span>
                )}
              </h4>
              {filterAgent !== 'all' && (
                <button
                  onClick={() => setFilterAgent('all')}
                  className="text-[11px] text-cyan-400 hover:text-cyan-200 underline font-mono-tech cursor-pointer"
                >
                  Clear Filter
                </button>
              )}
            </div>

            <div className="space-y-2.5">
              {filteredTasks.length === 0 ? (
                <div className="p-6 text-center text-xs text-cyan-400/50 font-mono-tech rounded-xl bg-gray-950/40 border border-cyan-500/10">
                  No active tasks for this agent. Dispatch a new command or speak to JARVIS.
                </div>
              ) : (
                filteredTasks.map((task) => {
                  const agent = agents.find(a => a.id === task.agentId);
                  return (
                    <div
                      key={task.id}
                      className="p-3.5 rounded-xl bg-gray-950/80 border border-cyan-500/30 space-y-2.5"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="space-y-0.5 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-tech text-sm font-bold text-cyan-100 truncate">
                              {task.title}
                            </span>
                            <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono-tech font-bold uppercase ${
                              task.status === 'running' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400' :
                              task.status === 'completed' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' :
                              task.status === 'paused' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' :
                              'bg-red-500/20 text-red-300 border border-red-500/40'
                            }`}>
                              {task.status}
                            </span>
                          </div>
                          <div className="text-[11px] text-cyan-400/70 font-mono-tech flex items-center gap-1.5">
                            <span>Agent: {agent?.name || task.agentId}</span>
                            <span>•</span>
                            <span>Progress: {task.progress}%</span>
                          </div>
                        </div>

                        {/* Task Controls: Pause / Resume / Cancel */}
                        <div className="flex items-center gap-1.5 shrink-0">
                          {task.status === 'running' && (
                            <button
                              onClick={() => handlePause(task.id)}
                              title="Pause Task Execution"
                              className="p-1.5 rounded-lg bg-gray-900 hover:bg-amber-500/20 text-amber-300 border border-gray-800 hover:border-amber-500/40 cursor-pointer"
                            >
                              <Pause className="w-3.5 h-3.5" />
                            </button>
                          )}
                          {task.status === 'paused' && (
                            <button
                              onClick={() => handleResume(task.id)}
                              title="Resume Task Execution"
                              className="p-1.5 rounded-lg bg-gray-900 hover:bg-cyan-500/20 text-cyan-300 border border-gray-800 hover:border-cyan-400 cursor-pointer"
                            >
                              <Play className="w-3.5 h-3.5" />
                            </button>
                          )}
                          {(task.status === 'running' || task.status === 'paused') && (
                            <button
                              onClick={() => handleCancel(task.id)}
                              title="Cancel Task"
                              className="p-1.5 rounded-lg bg-gray-900 hover:bg-red-500/20 text-red-400 border border-gray-800 hover:border-red-500/40 cursor-pointer"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                            </button>
                          )}
                          {task.status === 'completed' && (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                          )}
                        </div>
                      </div>

                      {/* Progress Bar */}
                      <div className="w-full bg-gray-800 rounded-full h-1.5 overflow-hidden">
                        <div
                          className={`h-full transition-all duration-300 ${
                            task.status === 'completed' ? 'bg-emerald-400' :
                            task.status === 'paused' ? 'bg-amber-400' :
                            'bg-cyan-400'
                          }`}
                          style={{ width: `${task.progress}%` }}
                        />
                      </div>

                      {/* Substeps */}
                      {task.substeps && task.substeps.length > 0 && (
                        <div className="flex items-center gap-2 text-[10px] font-mono-tech text-cyan-300/80 overflow-x-auto">
                          {task.substeps.map((step, idx) => (
                            <span 
                              key={idx}
                              className={`px-2 py-0.5 rounded ${
                                idx <= task.currentStepIndex 
                                  ? 'bg-cyan-950 text-cyan-200 border border-cyan-500/30' 
                                  : 'text-gray-500'
                              }`}
                            >
                              {idx + 1}. {step}
                            </span>
                          ))}
                        </div>
                      )}

                      {/* Result */}
                      {task.result && (
                        <div className="text-[11px] text-emerald-300/90 font-mono-tech bg-emerald-950/30 p-2 rounded-lg border border-emerald-500/20">
                          ✓ {task.result}
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
