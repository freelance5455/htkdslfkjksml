import React, { useState, useEffect, useCallback } from 'react';
import {
  Search,
  Bookmark,
  Heart,
  Clock,
  Globe,
  Play,
  ArrowRight,
  ShieldCheck,
  Film,
  Check,
  Share2,
  History,
  Loader2,
  RefreshCw
} from 'lucide-react';
import { motion } from 'motion/react';
import { TopAppBar } from './TopAppBar';
import { VIDEO_CATEGORIES, HEALTH_VIDEO_TOPICS, VideoTopicBlueprint } from '../data/videoData';
import { HealthVideoItem, VideoLanguage, VideoCategory } from '../types/video';
import { HealthVideoPlayer } from './HealthVideoPlayer';
import { searchVerifiedYouTubeVideos, verifyYouTubeVideoEmbeddable } from '../services/youtubeVideoService';

interface HealthVideosViewProps {
  onBack: () => void;
}

export const HealthVideosView: React.FC<HealthVideosViewProps> = ({ onBack }) => {
  const [selectedLanguage, setSelectedLanguage] = useState<VideoLanguage>('English');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedTab, setSelectedTab] = useState<'all' | 'recent' | 'favorites' | 'saved'>('all');
  const [selectedVideo, setSelectedVideo] = useState<HealthVideoItem | null>(null);

  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);
  const [favoriteIds, setFavoriteIds] = useState<string[]>([]);
  const [watchHistoryIds, setWatchHistoryIds] = useState<string[]>([]);
  const [copiedShareId, setCopiedShareId] = useState<string | null>(null);

  const [videosMap, setVideosMap] = useState<Record<string, HealthVideoItem>>({});
  const [isLoadingVideos, setIsLoadingVideos] = useState<boolean>(true);
  const [customSearchResults, setCustomSearchResults] = useState<HealthVideoItem[]>([]);
  const [isSearchingCustom, setIsSearchingCustom] = useState<boolean>(false);

  // Load saved state and cached videos from localStorage
  useEffect(() => {
    try {
      const savedBookmarks = localStorage.getItem('mediguide_bookmarked_videos');
      if (savedBookmarks) setBookmarkedIds(JSON.parse(savedBookmarks));

      const savedFavorites = localStorage.getItem('mediguide_favorite_videos');
      if (savedFavorites) setFavoriteIds(JSON.parse(savedFavorites));

      const savedHistory = localStorage.getItem('mediguide_video_history');
      if (savedHistory) setWatchHistoryIds(JSON.parse(savedHistory));

      const cachedMap = localStorage.getItem('mediguide_yt_verified_cache_v3');
      if (cachedMap) {
        const parsed = JSON.parse(cachedMap);
        if (parsed && Object.keys(parsed).length > 0) {
          setVideosMap(parsed);
          setIsLoadingVideos(false);
        }
      }
    } catch (err) {
      console.warn('Failed to load saved video state:', err);
    }
  }, []);

  // Default seed video IDs tested and verified via official YouTube oEmbed API
  const DEFAULT_SEED_IDS: Record<string, string[]> = {
    'topic-dengue-prevention': ['Ai9VZRIUN94', 'X9ivR4y03DE'],
    'topic-paracetamol-safe-use': ['nVlxsrMKMxg', 'Sk3aBIqQEPU'],
    'topic-diabetes-diet-plan': ['Wmv16iO2KM8', '9tvD2sMl9hI', '3Yl0UuyEw3Q', 'Ek6hnu1zaog'],
    'topic-heart-attack-warning': ['D1bg5NSpRoI', 'mjTMZ_sm0LQ', 'r5XTTeP039Q'],
    'topic-cpr-first-aid': ['ea1RJUOiNfQ', 'hizBdM1Ob68', 'BQNNOh8c8ks', 'M4ACYp75mjU'],
    'topic-anxiety-mental-health': ['bCEC9RUoEnw', 'W3_2w9s-8s8'],
    'topic-asthma-inhaler-use': ['2i9_DelNqs4', '7j_xM3kX-tq'],
    'topic-knee-osteoarthritis': ['9l2FGl1KVCs'],
    'topic-child-immunization': ['vPCnNQckOsE'],
    'topic-balanced-nutrition-plate': ['nLtDc5-DzhE', '2N0cRpuWz5U', '3DM3_ocFy0U'],
    'topic-daily-home-exercise': ['PuiC1hWbbo0'],
    'topic-hypertension-care': ['D1bg5NSpRoI', 'mjTMZ_sm0LQ', 'r5XTTeP039Q'],
    'topic-senior-citizen-health': ['satn4smVBqE'],
    'topic-pregnancy-care': ['0BrxCY89_uQ']
  };

  // Dynamically load videos for all topics using YouTube Data API v3 and dynamic search (checks up to 20 results)
  const loadDynamicTopicVideos = useCallback(async () => {
    setIsLoadingVideos(true);
    const newMap: Record<string, HealthVideoItem> = {};

    await Promise.all(
      HEALTH_VIDEO_TOPICS.map(async (topic) => {
        try {
          const verifiedVideos = await searchVerifiedYouTubeVideos(
            topic.searchQuery,
            topic.category,
            20
          );

          if (verifiedVideos.length > 0) {
            const primaryVideo = verifiedVideos[0];
            const fallbackIds = Array.from(
              new Set([...verifiedVideos.map((v) => v.id), ...(DEFAULT_SEED_IDS[topic.id] || [])])
            );

            newMap[topic.id] = {
              id: topic.id,
              youtubeId: primaryVideo.id,
              fallbackYoutubeIds: fallbackIds,
              thumbnailUrl: primaryVideo.thumbnailUrl,
              duration: primaryVideo.duration,
              category: topic.category,
              categoryEmoji: topic.categoryEmoji,
              lastUpdated: topic.lastUpdated,
              bgGradient: topic.bgGradient,
              content: {
                English: {
                  ...topic.content.English,
                  title: primaryVideo.title || topic.content.English.title,
                  source: primaryVideo.source || topic.content.English.source
                },
                Hindi: {
                  ...topic.content.Hindi,
                  source: primaryVideo.source || topic.content.Hindi.source
                },
                Marathi: {
                  ...topic.content.Marathi,
                  source: primaryVideo.source || topic.content.Marathi.source
                }
              }
            };
          } else {
            const seeds = DEFAULT_SEED_IDS[topic.id] || ['X9ivR4y03DE'];
            newMap[topic.id] = {
              id: topic.id,
              youtubeId: seeds[0],
              fallbackYoutubeIds: seeds,
              thumbnailUrl: `https://img.youtube.com/vi/${seeds[0]}/hqdefault.jpg`,
              duration: '04:30',
              category: topic.category,
              categoryEmoji: topic.categoryEmoji,
              lastUpdated: topic.lastUpdated,
              bgGradient: topic.bgGradient,
              content: topic.content
            };
          }
        } catch (err) {
          console.warn(`Failed to dynamically fetch videos for ${topic.id}:`, err);
          const seeds = DEFAULT_SEED_IDS[topic.id] || ['X9ivR4y03DE'];
          newMap[topic.id] = {
            id: topic.id,
            youtubeId: seeds[0],
            fallbackYoutubeIds: seeds,
            thumbnailUrl: `https://img.youtube.com/vi/${seeds[0]}/hqdefault.jpg`,
            duration: '04:30',
            category: topic.category,
            categoryEmoji: topic.categoryEmoji,
            lastUpdated: topic.lastUpdated,
            bgGradient: topic.bgGradient,
            content: topic.content
          };
        }
      })
    );

    setVideosMap(newMap);
    try {
      localStorage.setItem('mediguide_yt_verified_cache_v3', JSON.stringify(newMap));
    } catch (e) {}
    setIsLoadingVideos(false);
  }, []);

  useEffect(() => {
    loadDynamicTopicVideos();
  }, [loadDynamicTopicVideos]);

  // Execute dynamic custom search on YouTube Data API v3 when search query changes
  useEffect(() => {
    const query = searchQuery.trim();
    if (!query || query.length < 3) {
      setCustomSearchResults([]);
      setIsSearchingCustom(false);
      return;
    }

    const timer = setTimeout(async () => {
      setIsSearchingCustom(true);
      try {
        const searchResults = await searchVerifiedYouTubeVideos(
          query,
          (selectedCategory !== 'All' ? selectedCategory : 'Disease Education') as VideoCategory,
          5
        );

        const items: HealthVideoItem[] = searchResults.map((v, idx) => ({
          id: `custom-search-${v.id}-${idx}`,
          youtubeId: v.id,
          fallbackYoutubeIds: searchResults.filter((other) => other.id !== v.id).map((other) => other.id),
          thumbnailUrl: v.thumbnailUrl,
          duration: v.duration,
          category: (selectedCategory !== 'All' ? selectedCategory : 'Disease Education') as VideoCategory,
          categoryEmoji: '🎥',
          lastUpdated: 'Live Search',
          bgGradient: 'from-rose-600 to-indigo-700',
          content: {
            English: {
              title: v.title,
              description: v.description || `Verified educational video for "${query}".`,
              categoryName: selectedCategory !== 'All' ? selectedCategory : 'Health Search',
              source: v.source,
              keyTakeaways: ['Verified educational video from YouTube Data API', 'Watch for official medical guidance']
            },
            Hindi: {
              title: v.title,
              description: v.description || `"${query}" के लिए सत्यापित स्वास्थ्य वीडियो।`,
              categoryName: selectedCategory !== 'All' ? selectedCategory : 'स्वास्थ्य खोज',
              source: v.source,
              keyTakeaways: ['यूट्यूब डेटा एपीआई से सत्यापित शैक्षिक वीडियो']
            },
            Marathi: {
              title: v.title,
              description: v.description || `"${query}" साठी सत्यापित आरोग्य व्हिडिओ.`,
              categoryName: selectedCategory !== 'All' ? selectedCategory : 'आरोग्य शोध',
              source: v.source,
              keyTakeaways: ['यूट्यूब डेटा एपीआई वरून सत्यापित व्हिडिओ']
            }
          }
        }));

        setCustomSearchResults(items);
      } catch (err) {
        console.warn('Custom search query error:', err);
      } finally {
        setIsSearchingCustom(false);
      }
    }, 600);

    return () => clearTimeout(timer);
  }, [searchQuery, selectedCategory]);

  // Toggle Bookmark
  const toggleBookmark = (id: string) => {
    setBookmarkedIds((prev) => {
      const updated = prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id];
      try {
        localStorage.setItem('mediguide_bookmarked_videos', JSON.stringify(updated));
      } catch (err) {
        console.warn('Failed to save bookmarks:', err);
      }
      return updated;
    });
  };

  // Toggle Favorite
  const toggleFavorite = (id: string) => {
    setFavoriteIds((prev) => {
      const updated = prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id];
      try {
        localStorage.setItem('mediguide_favorite_videos', JSON.stringify(updated));
      } catch (err) {
        console.warn('Failed to save favorites:', err);
      }
      return updated;
    });
  };

  // Share Card
  const handleShare = async (e: React.MouseEvent, video: HealthVideoItem) => {
    e.stopPropagation();
    const content = video.content[selectedLanguage] || video.content.English;
    const text = `🎥 ${content.title}\n${content.description}\n\nWatch on Mediguide AI Health Videos.`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: content.title,
          text,
          url: window.location.href,
        });
        return;
      } catch (err) {
        console.log('Share cancelled:', err);
      }
    }
    try {
      await navigator.clipboard.writeText(text);
      setCopiedShareId(video.id);
      setTimeout(() => setCopiedShareId(null), 2000);
    } catch (err) {
      console.warn('Failed to copy link:', err);
    }
  };

  // Combine loaded topic videos
  const allTopicVideos = HEALTH_VIDEO_TOPICS.map((topic) => videosMap[topic.id]).filter(Boolean);

  // Active dataset to display
  const baseVideos = searchQuery.trim().length >= 3 && customSearchResults.length > 0
    ? [...customSearchResults, ...allTopicVideos]
    : allTopicVideos;

  // Filter video dataset
  const filteredVideos = baseVideos.filter((video) => {
    const content = video.content[selectedLanguage] || video.content.English;
    const query = searchQuery.toLowerCase().trim();

    // Search query check
    const matchesSearch =
      !query ||
      content.title.toLowerCase().includes(query) ||
      content.description.toLowerCase().includes(query) ||
      content.categoryName.toLowerCase().includes(query) ||
      video.category.toLowerCase().includes(query) ||
      content.source.toLowerCase().includes(query) ||
      content.keyTakeaways.some((k) => k.toLowerCase().includes(query));

    // Category filter check
    const matchesCategory = selectedCategory === 'All' || video.category === selectedCategory;

    // Tab filter check
    let matchesTab = true;
    if (selectedTab === 'recent') {
      matchesTab = watchHistoryIds.includes(video.id);
    } else if (selectedTab === 'favorites') {
      matchesTab = favoriteIds.includes(video.id);
    } else if (selectedTab === 'saved') {
      matchesTab = bookmarkedIds.includes(video.id);
    }

    return matchesSearch && matchesCategory && matchesTab;
  });

  // Render Full Player View if a video is selected
  if (selectedVideo) {
    return (
      <HealthVideoPlayer
        video={selectedVideo}
        allVideos={allTopicVideos}
        currentLanguage={selectedLanguage}
        onLanguageChange={(lang) => setSelectedLanguage(lang)}
        isBookmarked={bookmarkedIds.includes(selectedVideo.id)}
        isFavorite={favoriteIds.includes(selectedVideo.id)}
        onToggleBookmark={toggleBookmark}
        onToggleFavorite={toggleFavorite}
        onSelectRelatedVideo={(relVideo) => setSelectedVideo(relVideo)}
        onBack={() => setSelectedVideo(null)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-16">
      <TopAppBar
        title="Health Videos"
        subtitle="YouTube Data API v3 Educational Hub"
        onBack={onBack}
        badge="YouTube API Verified"
        badgeColor="bg-emerald-100 text-emerald-800 border-emerald-200"
      />

      <div className="p-4 max-w-4xl mx-auto w-full space-y-5">
        {/* Banner Header */}
        <div className="bg-gradient-to-r from-red-700 via-rose-700 to-slate-900 text-white p-5 rounded-3xl shadow-lg relative overflow-hidden space-y-3">
          <div className="flex items-start justify-between gap-3 relative z-10">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-white/15 rounded-2xl backdrop-blur-md border border-white/20 text-white shadow-inner">
                <Film className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-black tracking-tight">Health Videos Hub</h1>
                <p className="text-xs text-rose-100 mt-0.5 font-medium">
                  Dynamic YouTube API v3 medical education, disease guides, and verified tutorials.
                </p>
              </div>
            </div>

            <button
              onClick={() => loadDynamicTopicVideos()}
              disabled={isLoadingVideos}
              className="p-2.5 bg-white/10 hover:bg-white/20 border border-white/20 rounded-2xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 shrink-0"
              title="Refresh Verified Videos"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoadingVideos ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">Refresh</span>
            </button>
          </div>

          {/* Language Switcher Bar */}
          <div className="pt-3 border-t border-white/20 flex flex-wrap items-center justify-between gap-2 text-xs relative z-10">
            <div className="flex items-center gap-1.5 font-bold text-rose-100">
              <Globe className="w-4 h-4 text-rose-200" />
              <span>Language: English (हिन्दी / मराठी)</span>
            </div>

            <div className="flex bg-black/30 p-1 rounded-2xl gap-1 border border-white/10">
              {(['English', 'Hindi', 'Marathi'] as VideoLanguage[]).map((lang) => (
                <button
                  key={lang}
                  onClick={() => setSelectedLanguage(lang)}
                  className={`px-3 py-1 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    selectedLanguage === lang
                      ? 'bg-white text-rose-950 shadow-md'
                      : 'text-white/80 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {lang === 'English' ? 'English' : lang === 'Hindi' ? 'हिन्दी' : 'मराठी'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-4 top-3.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search YouTube dynamically (e.g., Diabetes diet, Paracetamol dosage)..."
            className="w-full pl-11 pr-10 py-3 bg-white border border-slate-200 rounded-2xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-rose-500 shadow-xs text-slate-900"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600 text-xs font-bold bg-slate-100 rounded-full w-5 h-5 flex items-center justify-center cursor-pointer"
            >
              ✕
            </button>
          )}
        </div>

        {/* Dynamic Search Loading Indicator */}
        {isSearchingCustom && (
          <div className="flex items-center justify-center gap-2 text-xs text-rose-600 font-bold bg-rose-50 p-3 rounded-2xl border border-rose-200">
            <Loader2 className="w-4 h-4 animate-spin text-rose-600" />
            <span>Searching YouTube Data API v3 for "{searchQuery}"...</span>
          </div>
        )}

        {/* Watch History / Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs no-scrollbar">
          <button
            onClick={() => setSelectedTab('all')}
            className={`px-3.5 py-1.5 rounded-xl font-bold transition-all cursor-pointer whitespace-nowrap ${
              selectedTab === 'all'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
            }`}
          >
            All Videos
          </button>

          <button
            onClick={() => setSelectedTab('recent')}
            className={`px-3.5 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
              selectedTab === 'recent'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
            }`}
          >
            <History className="w-3.5 h-3.5 text-indigo-500" />
            <span>Recently Watched ({watchHistoryIds.length})</span>
          </button>

          <button
            onClick={() => setSelectedTab('favorites')}
            className={`px-3.5 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
              selectedTab === 'favorites'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
            }`}
          >
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
            <span>Favorites ({favoriteIds.length})</span>
          </button>

          <button
            onClick={() => setSelectedTab('saved')}
            className={`px-3.5 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
              selectedTab === 'saved'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
            }`}
          >
            <Bookmark className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
            <span>Saved ({bookmarkedIds.length})</span>
          </button>
        </div>

        {/* Video Categories Cards */}
        <div className="space-y-2">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-xs font-black uppercase tracking-wider text-slate-500">
              {selectedLanguage === 'Hindi'
                ? 'वीडियो श्रेणियां (Video Categories)'
                : selectedLanguage === 'Marathi'
                ? 'व्हिडिओ वर्गवारी (Categories)'
                : 'Video Categories'}
            </h2>
            {selectedCategory !== 'All' && (
              <button
                onClick={() => setSelectedCategory('All')}
                className="text-xs text-rose-600 font-bold hover:underline cursor-pointer"
              >
                Clear Category Filter ({selectedCategory})
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
            {VIDEO_CATEGORIES.map((cat) => {
              const isSelected = selectedCategory === cat.id;
              const title =
                selectedLanguage === 'Hindi'
                  ? cat.nameHi
                  : selectedLanguage === 'Marathi'
                  ? cat.nameMr
                  : cat.nameEn;

              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(isSelected ? 'All' : cat.id)}
                  className={`p-3 rounded-2xl border transition-all text-left flex items-center gap-2.5 cursor-pointer shadow-2xs hover:shadow-md ${
                    isSelected
                      ? 'bg-rose-950 text-white border-rose-950 ring-2 ring-rose-950/20'
                      : 'bg-white text-slate-800 border-slate-200/90 hover:border-rose-300 hover:bg-rose-50/40'
                  }`}
                >
                  <span className="text-xl shrink-0">{cat.emoji}</span>
                  <div className="overflow-hidden">
                    <p className="text-xs font-extrabold truncate leading-tight">{title}</p>
                    <p className={`text-[10px] truncate ${isSelected ? 'text-rose-200' : 'text-slate-400'}`}>
                      {cat.nameEn}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Video Cards Grid */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 px-1 pt-2">
            <span>
              {isLoadingVideos ? (
                <span className="flex items-center gap-1 text-slate-500">
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-rose-600" />
                  <span>Verifying YouTube streams...</span>
                </span>
              ) : selectedLanguage === 'Hindi'
                ? `कुल ${filteredVideos.length} वीडियो उपलब्ध हैं`
                : selectedLanguage === 'Marathi'
                ? `एकूण ${filteredVideos.length} व्हिडिओ उपलब्ध आहेत`
                : `Showing ${filteredVideos.length} verified educational videos`}
            </span>
            <span className="text-[11px] text-rose-800 bg-rose-50 px-2.5 py-0.5 rounded-md border border-rose-200 font-semibold">
              {selectedLanguage === 'English' ? 'English' : selectedLanguage === 'Hindi' ? 'हिन्दी' : 'मराठी'}
            </span>
          </div>

          {filteredVideos.length === 0 && !isLoadingVideos ? (
            <div className="bg-white rounded-3xl p-8 text-center border border-slate-200 space-y-3">
              <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                <Film className="w-6 h-6 text-rose-600" />
              </div>
              <h3 className="font-extrabold text-slate-800 text-sm">
                {selectedLanguage === 'Hindi'
                  ? 'कोई वीडियो नहीं मिला'
                  : selectedLanguage === 'Marathi'
                  ? 'कोणताही व्हिडिओ आढळला नाही'
                  : 'No Verified Health Videos Found'}
              </h3>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                {selectedTab === 'recent'
                  ? 'You have not watched any health videos recently. Click on any video to start learning.'
                  : selectedTab === 'favorites'
                  ? 'You have not marked any videos as favorite yet.'
                  : selectedTab === 'saved'
                  ? 'You have not saved any videos to your bookmarks yet.'
                  : 'Try searching by condition, medicine name, or health topic.'}
              </p>
              {(searchQuery || selectedCategory !== 'All' || selectedTab !== 'all') && (
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('All');
                    setSelectedTab('all');
                  }}
                  className="px-4 py-2 bg-rose-600 text-white font-bold text-xs rounded-xl hover:bg-rose-700 transition-colors cursor-pointer"
                >
                  Reset Search & Filters
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredVideos.map((video) => {
                const content = video.content[selectedLanguage] || video.content.English;
                const isBookmarked = bookmarkedIds.includes(video.id);
                const isFavorite = favoriteIds.includes(video.id);

                return (
                  <motion.div
                    key={video.id}
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                    onClick={() => setSelectedVideo(video)}
                    className="bg-white rounded-3xl border border-slate-200 shadow-xs hover:border-rose-300 hover:shadow-md transition-all overflow-hidden flex flex-col justify-between cursor-pointer group"
                  >
                    <div>
                      {/* Video Thumbnail */}
                      <div className="relative aspect-video bg-slate-900 overflow-hidden">
                        <img
                          src={video.thumbnailUrl}
                          alt={content.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-black/25 group-hover:bg-black/15 transition-colors flex items-center justify-center">
                          <div className="w-12 h-12 rounded-full bg-rose-600/90 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                            <Play className="w-5 h-5 fill-white translate-x-0.5" />
                          </div>
                        </div>

                        {/* Top Category Badge */}
                        <div className="absolute top-3 left-3 bg-black/70 backdrop-blur-md px-2.5 py-1 rounded-xl text-[10px] font-extrabold text-white flex items-center gap-1 border border-white/20">
                          <span>{video.categoryEmoji}</span>
                          <span>{video.category}</span>
                        </div>

                        {/* Duration Badge */}
                        <div className="absolute bottom-3 right-3 bg-black/80 backdrop-blur-md px-2 py-0.5 rounded-lg text-[10px] font-bold text-white flex items-center gap-1">
                          <Clock className="w-3 h-3 text-rose-400" />
                          <span>{video.duration}</span>
                        </div>
                      </div>

                      {/* Content Info */}
                      <div className="p-4 space-y-2">
                        <div className="flex items-start justify-between gap-2">
                          <h3 className="font-extrabold text-sm text-slate-900 leading-snug group-hover:text-rose-700 transition-colors">
                            {content.title}
                          </h3>

                          {/* Quick Action Buttons */}
                          <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                            <button
                              onClick={() => toggleFavorite(video.id)}
                              className={`p-1.5 rounded-xl transition-colors cursor-pointer ${
                                isFavorite
                                  ? 'bg-rose-100 text-rose-600'
                                  : 'bg-slate-100 text-slate-400 hover:text-slate-600'
                              }`}
                              title="Favorite"
                            >
                              <Heart className={`w-3.5 h-3.5 ${isFavorite ? 'fill-rose-600' : ''}`} />
                            </button>

                            <button
                              onClick={() => toggleBookmark(video.id)}
                              className={`p-1.5 rounded-xl transition-colors cursor-pointer ${
                                isBookmarked
                                  ? 'bg-amber-100 text-amber-700'
                                  : 'bg-slate-100 text-slate-400 hover:text-slate-600'
                              }`}
                              title="Bookmark"
                            >
                              <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-amber-600' : ''}`} />
                            </button>

                            <button
                              onClick={(e) => handleShare(e, video)}
                              className="p-1.5 bg-slate-100 text-slate-400 hover:text-slate-600 rounded-xl transition-colors cursor-pointer"
                              title="Share"
                            >
                              {copiedShareId === video.id ? (
                                <Check className="w-3.5 h-3.5 text-emerald-600" />
                              ) : (
                                <Share2 className="w-3.5 h-3.5" />
                              )}
                            </button>
                          </div>
                        </div>

                        <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                          {content.description}
                        </p>

                        <div className="pt-2 flex items-center justify-between text-[11px] text-slate-400 font-medium">
                          <span className="flex items-center gap-1">
                            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                            <strong className="text-slate-700">{content.source}</strong>
                          </span>
                          <span>Updated {video.lastUpdated}</span>
                        </div>
                      </div>
                    </div>

                    {/* Bottom Action Footer */}
                    <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-rose-700">
                      <span className="text-[10px] text-slate-400 font-medium">Verified Educational Video</span>
                      <span className="flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                        {selectedLanguage === 'Hindi'
                          ? 'वीडियो देखें'
                          : selectedLanguage === 'Marathi'
                          ? 'व्हिडिओ पाहा'
                          : 'Watch Video'}
                        <ArrowRight className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
