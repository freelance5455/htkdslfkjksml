import React from 'react';

export const BackgroundCanvas: React.FC = () => {
  return (
    <div
      aria-hidden="true"
      className="fixed inset-0 -z-10 pointer-events-none bg-[#F4F5F8]"
    />
  );
};
