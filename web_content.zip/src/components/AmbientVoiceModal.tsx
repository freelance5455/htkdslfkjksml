import React, { useEffect, useState, useRef } from 'react';
import {
  X,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Sparkles,
  ExternalLink,
  ShieldAlert,
  Sun,
  Flame,
  Radio,
  Clock,
  Compass,
  Music,
  CheckCircle2
} from 'lucide-react';
import {
  playWakeChime,
  playSuccessChime,
  requestScreenWakeLock,
  releaseScreenWakeLock
} from '../utils/audio';

interface AmbientVoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExecuteCommand: (action: string, payload?: string) => void;
  autoSpeak: boolean;
  onToggleAutoSpeak: () => void;
}

interface ActionLogItem {
  id: string;
  phrase: string;
  action: string;
  time: string;
}

export const AmbientVoiceModal: React.FC<AmbientVoiceModalProps> = ({
  isOpen,
  onClose,
  onExecuteCommand,
  autoSpeak,
  onToggleAutoSpeak,
}) => {
  const [isAwake, setIsAwake] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [lastAction, setLastAction] = useState<string | null>(null);
  const [actionLogs, setActionLogs] = useState<ActionLogItem[]>([]);
  const [wakeLockActive, setWakeLockActive] = useState(false);

  // Recognition ref
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const recognitionRef = useRef<any>(null);

  // Initialize Speech Recognition & Screen Wake Lock
  useEffect(() => {
    if (!isOpen) {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {}
      }
      releaseScreenWakeLock();
      setWakeLockActive(false);
      setIsListening(false);
      return;
    }

    // Acquire Wake Lock to keep phone screen on
    requestScreenWakeLock().then((active) => {
      setWakeLockActive(active);
    });

    const SpeechRecognition =
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert('Speech Recognition is not supported in this browser. Please use Google Chrome or Edge.');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'hi-IN, en-US';

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    recognition.onresult = (event: any) => {
      let currentInterim = '';
      let finalSpeech = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalSpeech += event.results[i][0].transcript;
        } else {
          currentInterim += event.results[i][0].transcript;
        }
      }

      const heard = (finalSpeech || currentInterim).toLowerCase().trim();
      setTranscript(heard);

      if (heard) {
        handleVoiceTrigger(heard);
      }
    };

    recognition.onerror = (e: { error: string }) => {
      console.debug('Ambient recognition status:', e.error);
      if (e.error === 'not-allowed') {
        setIsListening(false);
      }
    };

    recognition.onend = () => {
      // Auto-restart if modal is still open
      if (isOpen) {
        try {
          recognition.start();
        } catch {}
      }
    };

    try {
      recognition.start();
      setIsListening(true);
      recognitionRef.current = recognition;
    } catch (e) {
      console.warn('Speech recognition start failed:', e);
    }

    return () => {
      try {
        recognition.stop();
      } catch {}
      releaseScreenWakeLock();
    };
  }, [isOpen]);

  // Voice parsing and action handler
  const handleVoiceTrigger = (text: string) => {
    // 1. YouTube trigger: "open youtube", "hey nova open youtube", "youtube kholo", "open yt"
    if (
      text.includes('open youtube') ||
      text.includes('youtube open') ||
      text.includes('youtube kholo') ||
      text.includes('hey nova open youtube') ||
      text.includes('open yt')
    ) {
      playWakeChime();
      playSuccessChime();
      setLastAction('Opening YouTube 🎬');
      addLog(text, 'Opened YouTube');
      setTimeout(() => {
        window.open('https://www.youtube.com', '_blank');
      }, 350);
      return;
    }

    // 2. Music trigger: "play music", "gaana chalao", "play song"
    if (text.includes('play music') || text.includes('gaana chalao') || text.includes('play song') || text.includes('music play')) {
      playWakeChime();
      playSuccessChime();
      setLastAction('Opening Music & Songs 🎵');
      addLog(text, 'Opened YouTube Music');
      setTimeout(() => {
        window.open('https://music.youtube.com', '_blank');
      }, 350);
      return;
    }

    // 3. Google / Search trigger
    if (text.includes('open google') || text.includes('google kholo') || text.includes('search google')) {
      playWakeChime();
      playSuccessChime();
      setLastAction('Opening Google Search 🌐');
      addLog(text, 'Opened Google');
      setTimeout(() => {
        window.open('https://www.google.com', '_blank');
      }, 350);
      return;
    }

    // 4. Maps trigger: "open maps", "maps kholo"
    if (text.includes('open maps') || text.includes('maps kholo') || text.includes('google maps')) {
      playWakeChime();
      playSuccessChime();
      setLastAction('Opening Google Maps 📍');
      addLog(text, 'Opened Maps');
      setTimeout(() => {
        window.open('https://maps.google.com', '_blank');
      }, 350);
      return;
    }

    // 5. Clear chat: "clear chat", "chat saaf karo"
    if (text.includes('clear chat') || text.includes('chat saaf karo')) {
      playWakeChime();
      setLastAction('Chat Cleared 🧹');
      addLog(text, 'Cleared Chat');
      onExecuteCommand('clear_chat');
      return;
    }

    // 6. Generic "Hey Nova" query: e.g. "hey nova what is the weather" or "hey nova explain react"
    if (text.startsWith('hey nova') || text.startsWith('nova') || text.startsWith('suno nova') || text.startsWith('hello nova')) {
      const query = text.replace(/^(hey nova|nova|suno nova|hello nova)\s*/i, '').trim();
      if (query.length > 2) {
        playWakeChime();
        setLastAction(`Asking Nova: "${query}"`);
        addLog(text, `Sent: "${query}"`);
        onExecuteCommand('send_custom_prompt', query);
      }
    }
  };

  const addLog = (phrase: string, action: string) => {
    const item: ActionLogItem = {
      id: Math.random().toString(),
      phrase,
      action,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    };
    setActionLogs((prev) => [item, ...prev.slice(0, 5)]);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/90 backdrop-blur-xl animate-fade-in">
      <div className="relative w-full max-w-lg bg-gradient-to-b from-slate-900 via-slate-950 to-black rounded-3xl border border-violet-500/40 p-5 sm:p-7 shadow-2xl shadow-violet-950/70 overflow-hidden flex flex-col items-center text-center">
        
        {/* Top Header & Close */}
        <div className="w-full flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-xs font-bold text-violet-300 uppercase tracking-widest">
              Ambient Voice Mode
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onToggleAutoSpeak}
              className={`p-2 rounded-xl border text-xs transition cursor-pointer ${
                autoSpeak
                  ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300'
                  : 'bg-slate-800 border-slate-700 text-slate-400'
              }`}
              title={autoSpeak ? 'Voice Reply Active' : 'Voice Reply Muted'}
            >
              {autoSpeak ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
              title="Close Voice Standby"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Wake-Lock Stay-Awake Status Pill */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-violet-950/60 border border-violet-500/30 text-xs text-violet-200 mb-6 font-mono">
          <Sun className="w-3.5 h-3.5 text-amber-400 animate-spin-slow" />
          <span>Screen Stay-Awake: {wakeLockActive ? 'Active ⚡' : 'Standby Mode'}</span>
        </div>

        {/* Glowing Futuristic Voice Orb */}
        <div className="relative my-4 flex items-center justify-center">
          {/* Animated concentric pulse rings */}
          <div className="absolute w-44 h-44 rounded-full bg-gradient-to-tr from-violet-600/30 via-fuchsia-600/20 to-cyan-500/30 blur-xl animate-pulse" />
          <div className="absolute w-36 h-36 rounded-full border border-violet-500/40 animate-ping opacity-30" />
          
          <div className="relative w-28 h-28 rounded-full bg-gradient-to-tr from-violet-600 via-fuchsia-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-violet-500/50 cursor-pointer hover:scale-105 transition">
            <Mic className="w-12 h-12 text-white animate-pulse" />
          </div>
        </div>

        {/* Listening Status & Live Heard Transcript */}
        <div className="mt-4 mb-2 space-y-1.5 w-full">
          <div className="text-sm font-extrabold text-white flex items-center justify-center gap-2">
            <span>Listening for Wake Words...</span>
          </div>

          <div className="h-10 px-4 flex items-center justify-center">
            {transcript ? (
              <p className="text-sm text-cyan-300 font-medium italic bg-cyan-950/40 px-3 py-1 rounded-xl border border-cyan-500/30 truncate max-w-full">
                &quot;{transcript}&quot;
              </p>
            ) : (
              <p className="text-xs text-slate-400">
                Bolo: <span className="text-violet-300 font-semibold">&quot;Hey Nova, open YouTube&quot;</span> ya <span className="text-cyan-300 font-semibold">&quot;Play Music&quot;</span>
              </p>
            )}
          </div>

          {lastAction && (
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs font-bold animate-bounce-short">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{lastAction}</span>
            </div>
          )}
        </div>

        {/* Quick Voice Command Shortcuts */}
        <div className="w-full mt-4 pt-4 border-t border-slate-800/80">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2.5">
            Voice Triggers Supported:
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
            <button
              onClick={() => handleVoiceTrigger('hey nova open youtube')}
              className="flex items-center justify-center gap-1.5 p-2 rounded-xl bg-red-950/30 hover:bg-red-900/40 border border-red-500/30 text-red-300 transition cursor-pointer hover:scale-[1.02]"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>&quot;Open YouTube&quot;</span>
            </button>

            <button
              onClick={() => handleVoiceTrigger('play music')}
              className="flex items-center justify-center gap-1.5 p-2 rounded-xl bg-violet-950/30 hover:bg-violet-900/40 border border-violet-500/30 text-violet-300 transition cursor-pointer hover:scale-[1.02]"
            >
              <Music className="w-3.5 h-3.5" />
              <span>&quot;Play Music&quot;</span>
            </button>

            <button
              onClick={() => handleVoiceTrigger('open google')}
              className="flex items-center justify-center gap-1.5 p-2 rounded-xl bg-blue-950/30 hover:bg-blue-900/40 border border-blue-500/30 text-blue-300 transition cursor-pointer hover:scale-[1.02]"
            >
              <Compass className="w-3.5 h-3.5" />
              <span>&quot;Open Google&quot;</span>
            </button>
          </div>
        </div>

        {/* Action Logs */}
        {actionLogs.length > 0 && (
          <div className="w-full mt-3 text-left">
            <div className="text-[10px] text-slate-500 font-bold uppercase mb-1">Recent Voice Actions:</div>
            <div className="space-y-1">
              {actionLogs.map((log) => (
                <div key={log.id} className="flex items-center justify-between text-[11px] px-2.5 py-1 rounded bg-slate-900/60 border border-slate-800 text-slate-300">
                  <span className="truncate mr-2">&quot;{log.phrase}&quot; → {log.action}</span>
                  <span className="text-[9px] text-slate-500 font-mono shrink-0">{log.time}</span>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
