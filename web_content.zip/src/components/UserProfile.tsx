import React, { useState } from 'react';
import {
  User,
  Mail,
  Phone,
  MapPin,
  Edit3,
  Check,
  Plus,
  X,
  FileText,
  Bookmark,
  Send,
  Database,
  Printer,
  Sparkles,
  Award,
  Globe,
  Trash2,
  Calendar,
} from 'lucide-react';
import { UserProfileData, Language, SolvedOpportunity, JobApplication, SystemStatus } from '../types';
import { translations } from '../translations/translations';

interface Props {
  profile: UserProfileData;
  onUpdateProfile: (updated: UserProfileData) => void;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  savedOpportunities: SolvedOpportunity[];
  onDeleteOpportunity: (id: string) => void;
  applications: JobApplication[];
  systemStatus: SystemStatus | null;
  onOpenFirebaseStatus: () => void;
}

export const UserProfile: React.FC<Props> = ({
  profile,
  onUpdateProfile,
  language,
  onLanguageChange,
  savedOpportunities,
  onDeleteOpportunity,
  applications,
  systemStatus,
  onOpenFirebaseStatus,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<UserProfileData>(profile);
  const [newSkill, setNewSkill] = useState('');
  const [activeTab, setActiveTab] = useState<'profile' | 'saved' | 'applications'>('profile');
  const [isCvModalOpen, setIsCvModalOpen] = useState(false);

  const t = translations[language].profile;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile(formData);
    setIsEditing(false);
  };

  const handleAddSkill = () => {
    if (!newSkill.trim()) return;
    if (formData.skills.includes(newSkill.trim())) return;
    const updated = {
      ...formData,
      skills: [...formData.skills, newSkill.trim()],
    };
    setFormData(updated);
    onUpdateProfile(updated);
    setNewSkill('');
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    const updated = {
      ...formData,
      skills: formData.skills.filter((s) => s !== skillToRemove),
    };
    setFormData(updated);
    onUpdateProfile(updated);
  };

  const isFbConfigured = systemStatus?.firebase?.configured ?? false;

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-3xl mx-auto">
      {/* Top Profile Card */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-sm relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center space-x-4">
            {/* Avatar */}
            <div className="relative">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-tr from-emerald-700 to-teal-500 text-white font-black text-2xl sm:text-3xl flex items-center justify-center shadow-md">
                {profile.displayName.charAt(0)}
              </div>
              <span className="absolute -bottom-1 -right-1 w-5 h-5 bg-emerald-500 rounded-full border-2 border-white flex items-center justify-center text-white text-[10px]">
                ✓
              </span>
            </div>

            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-lg sm:text-xl font-extrabold text-slate-900">
                  {profile.displayName}
                </h2>
              </div>
              <p className="text-xs sm:text-sm text-emerald-800 font-semibold mt-0.5">
                {profile.title}
              </p>
              <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 mt-1.5">
                <span className="flex items-center">
                  <MapPin className="w-3.5 h-3.5 mr-1 text-slate-400" />
                  {profile.location}
                </span>
                <span className="flex items-center">
                  <Mail className="w-3.5 h-3.5 mr-1 text-slate-400" />
                  {profile.email}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-2 self-start sm:self-center">
            <button
              onClick={() => setIsCvModalOpen(true)}
              className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center space-x-1.5 transition-colors cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5 text-emerald-600" />
              <span>{t.previewCv}</span>
            </button>

            <button
              onClick={() => setIsEditing(!isEditing)}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center space-x-1.5 transition-colors shadow-xs cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>{isEditing ? 'Cancel' : t.editProfile}</span>
            </button>
          </div>
        </div>

        {/* Bio preview */}
        <p className="text-xs text-slate-600 mt-4 pt-3 border-t border-slate-100 leading-relaxed font-normal">
          “{profile.bio}”
        </p>
      </div>

      {/* Tabs: Profile & Skills / Saved Opportunities / Applications */}
      <div className="flex border-b border-slate-200 text-xs font-bold gap-2">
        <button
          onClick={() => setActiveTab('profile')}
          className={`pb-2.5 px-3 border-b-2 transition-colors ${
            activeTab === 'profile'
              ? 'border-emerald-600 text-emerald-800'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          {language === 'am' ? 'መረጃ እና ክህሎቶች' : 'Profile & Skills'}
        </button>
        <button
          onClick={() => setActiveTab('saved')}
          className={`pb-2.5 px-3 border-b-2 transition-colors flex items-center space-x-1 ${
            activeTab === 'saved'
              ? 'border-emerald-600 text-emerald-800'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <span>{t.savedOpportunities}</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-emerald-100 text-emerald-800 font-bold">
            {savedOpportunities.length}
          </span>
        </button>
        <button
          onClick={() => setActiveTab('applications')}
          className={`pb-2.5 px-3 border-b-2 transition-colors flex items-center space-x-1 ${
            activeTab === 'applications'
              ? 'border-emerald-600 text-emerald-800'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <span>{t.myApplications}</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-200 text-slate-700 font-bold">
            {applications.length}
          </span>
        </button>
      </div>

      {/* Tab 1: Profile & Skills */}
      {activeTab === 'profile' && (
        <div className="space-y-6">
          {/* Edit Form */}
          {isEditing && (
            <form onSubmit={handleSave} className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-4 text-xs">
              <h3 className="font-bold text-slate-900 text-sm">{t.editProfile}</h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t.name}</label>
                  <input
                    type="text"
                    value={formData.displayName}
                    onChange={(e) => setFormData({ ...formData, displayName: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t.headline}</label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t.email}</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t.phone}</label>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t.location}</label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">{t.bio}</label>
                <textarea
                  rows={3}
                  value={formData.bio}
                  onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:ring-2 focus:ring-emerald-500 resize-none leading-relaxed"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
                >
                  {t.saveProfile}
                </button>
              </div>
            </form>
          )}

          {/* Skills Management Card */}
          <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-extrabold text-slate-900">{t.skills}</h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Highlight your problem solving and technical capabilities
                </p>
              </div>
            </div>

            {/* Current Skills Chips */}
            <div className="flex flex-wrap gap-2">
              {formData.skills.map((skill) => (
                <span
                  key={skill}
                  className="inline-flex items-center px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-900 text-xs font-semibold border border-emerald-200/60 group"
                >
                  <span>{skill}</span>
                  <button
                    onClick={() => handleRemoveSkill(skill)}
                    className="ml-1.5 text-emerald-500 hover:text-rose-600 transition-colors"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </span>
              ))}
            </div>

            {/* Add Skill Input */}
            <div className="flex items-center space-x-2 pt-2">
              <input
                type="text"
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddSkill())}
                placeholder="e.g. Cold Chain Logistics, Python, Accounting..."
                className="flex-1 p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500"
              />
              <button
                onClick={handleAddSkill}
                className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center space-x-1 shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{t.addSkill}</span>
              </button>
            </div>
          </div>

          {/* Language Preference Card */}
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                <Globe className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-extrabold text-slate-900 text-xs sm:text-sm">{t.languagePref}</h4>
                <p className="text-[11px] text-slate-500">
                  {language === 'am' ? 'የመተግበሪያውን ቋንቋ በአማርኛ ወይም በእንግሊዝኛ ይምረጡ' : 'Select English or Amharic for UI and AI responses'}
                </p>
              </div>
            </div>

            <div className="flex items-center bg-slate-100 rounded-xl p-1 border border-slate-200">
              <button
                onClick={() => onLanguageChange('en')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  language === 'en' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600'
                }`}
              >
                English
              </button>
              <button
                onClick={() => onLanguageChange('am')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  language === 'am' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600'
                }`}
              >
                አማርኛ
              </button>
            </div>
          </div>

          {/* Firebase & Cloud Status Card */}
          <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-3xl p-5 border border-emerald-200/80 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-emerald-950 font-bold text-xs">
                <Database className="w-4 h-4 text-emerald-700" />
                <span>{t.firebaseSectionTitle}</span>
              </div>
              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                isFbConfigured ? 'bg-emerald-200 text-emerald-950' : 'bg-amber-100 text-amber-900'
              }`}>
                {isFbConfigured ? 'Cloud Firestore Active' : 'Local Prototype (Active)'}
              </span>
            </div>

            <p className="text-xs text-emerald-900 leading-relaxed">
              {language === 'am'
                ? 'የPROJECT ZERO ውሂብ በአካባቢው ተቀምጧል። የFirestore ደመና ማመሳሰል እና የGoogle Login ማረጋገጫ ለመመልከት ዝርዝሩን ይጫኑ።'
                : 'Project Zero is functioning in offline-first mode with all data saved locally. Server-side Gemini AI is active. Ready for Cloud Firestore and Auth.'}
            </p>

            <button
              onClick={onOpenFirebaseStatus}
              className="w-full py-2.5 px-4 rounded-xl bg-white hover:bg-emerald-100/60 border border-emerald-200 text-emerald-900 font-bold text-xs transition-colors flex items-center justify-center space-x-1.5"
            >
              <span>{t.firebaseStatus}</span>
            </button>
          </div>
        </div>
      )}

      {/* Tab 2: Saved Opportunities */}
      {activeTab === 'saved' && (
        <div className="space-y-4">
          {savedOpportunities.length === 0 ? (
            <div className="bg-white rounded-3xl p-8 text-center border border-slate-200 text-slate-500 text-xs">
              {t.noSaved}
            </div>
          ) : (
            savedOpportunities.map((opp) => (
              <div
                key={opp.id}
                className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-3 hover:border-emerald-300 transition-all"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-bold uppercase tracking-wider">
                      {opp.category}
                    </span>
                    <h3 className="text-base font-extrabold text-slate-900 mt-1">
                      {opp.opportunityTitle}
                    </h3>
                    <p className="text-xs text-emerald-800 font-medium italic">
                      “{opp.tagline}”
                    </p>
                  </div>

                  <button
                    onClick={() => onDeleteOpportunity(opp.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 transition-colors"
                    title="Remove from saved"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1">
                  <div className="font-bold text-slate-700">Original Problem Addressed:</div>
                  <p className="text-slate-600 leading-relaxed">{opp.originalProblem}</p>
                </div>

                <div className="p-3 rounded-2xl bg-emerald-50/50 border border-emerald-100 text-xs space-y-1">
                  <div className="font-bold text-emerald-950">Proposed Solution:</div>
                  <p className="text-emerald-900 leading-relaxed">{opp.proposedSolution}</p>
                </div>

                <div className="flex flex-wrap items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
                  <span>Startup Capital: <strong className="text-slate-800">{opp.estimatedStartupBudget}</strong></span>
                  <span className="text-[11px]">{new Date(opp.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Tab 3: Applications Tracker */}
      {activeTab === 'applications' && (
        <div className="space-y-4">
          {applications.length === 0 ? (
            <div className="bg-white rounded-3xl p-8 text-center border border-slate-200 text-slate-500 text-xs">
              {t.noApplications}
            </div>
          ) : (
            applications.map((app) => (
              <div
                key={app.id}
                className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200 shadow-sm flex items-center justify-between gap-3 text-xs"
              >
                <div className="space-y-1">
                  <div className="font-extrabold text-slate-900 text-sm">{app.jobTitle}</div>
                  <div className="text-slate-500 font-medium">{app.company}</div>
                  <div className="text-[11px] text-slate-400">
                    Applied on: {new Date(app.appliedAt).toLocaleDateString()}
                  </div>
                </div>

                <span className="px-3 py-1 rounded-full font-bold text-[11px] uppercase tracking-wider bg-emerald-100 text-emerald-800">
                  {app.status}
                </span>
              </div>
            ))
          )}
        </div>
      )}

      {/* Printable / Interactive CV Builder Modal */}
      {isCvModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl w-full max-w-2xl border border-slate-200 shadow-2xl overflow-hidden max-h-[92vh] flex flex-col animate-in fade-in zoom-in-95 duration-200">
            {/* Header */}
            <div className="bg-gradient-to-r from-emerald-800 to-teal-800 p-5 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center space-x-2">
                <FileText className="w-5 h-5 text-emerald-300" />
                <h3 className="font-extrabold text-base">PROJECT ZERO • INNOVATOR CV</h3>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white font-bold text-xs flex items-center space-x-1.5 transition-colors"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>{t.printCv}</span>
                </button>
                <button
                  onClick={() => setIsCvModalOpen(false)}
                  className="p-1.5 rounded-full hover:bg-white/10 text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* CV Sheet Body */}
            <div className="p-6 overflow-y-auto space-y-6 text-slate-800 text-xs sm:text-sm bg-white">
              {/* Header section of CV */}
              <div className="border-b-2 border-emerald-600 pb-4">
                <h1 className="text-2xl font-black text-slate-900 tracking-tight">
                  {profile.displayName}
                </h1>
                <p className="text-sm font-bold text-emerald-800 mt-0.5">
                  {profile.title}
                </p>
                <div className="flex flex-wrap gap-4 text-xs text-slate-500 mt-2">
                  <span>📍 {profile.location}</span>
                  <span>✉️ {profile.email}</span>
                  <span>📞 {profile.phone}</span>
                </div>
              </div>

              {/* Core Mission */}
              <div>
                <h4 className="font-extrabold text-xs uppercase tracking-wider text-emerald-950 mb-1">
                  Executive Summary & Problem-Solving Mission
                </h4>
                <p className="text-slate-700 leading-relaxed bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                  {profile.bio}
                </p>
              </div>

              {/* Skills Matrix */}
              <div>
                <h4 className="font-extrabold text-xs uppercase tracking-wider text-emerald-950 mb-2">
                  Core Skills & Capabilities
                </h4>
                <div className="flex flex-wrap gap-2">
                  {profile.skills.map((s, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1 rounded-lg bg-emerald-50 text-emerald-900 font-semibold text-xs border border-emerald-200"
                    >
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              {/* Solved Problems Portfolio */}
              {savedOpportunities.length > 0 && (
                <div>
                  <h4 className="font-extrabold text-xs uppercase tracking-wider text-emerald-950 mb-2">
                    Venture & Problem-Solving Track Record
                  </h4>
                  <div className="space-y-3">
                    {savedOpportunities.slice(0, 3).map((opp) => (
                      <div key={opp.id} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1">
                        <div className="font-bold text-slate-900 text-xs">
                          {opp.opportunityTitle} ({opp.category})
                        </div>
                        <p className="text-slate-600">
                          <strong>Problem:</strong> {opp.originalProblem}
                        </p>
                        <p className="text-emerald-800 font-medium">
                          <strong>Solution:</strong> {opp.proposedSolution}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Education & Experience */}
              <div>
                <h4 className="font-extrabold text-xs uppercase tracking-wider text-emerald-950 mb-1">
                  Education & Background
                </h4>
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700">
                  {profile.education} • {profile.experienceYears} Years Entrepreneurial Experience
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end shrink-0">
              <button
                onClick={() => setIsCvModalOpen(false)}
                className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
