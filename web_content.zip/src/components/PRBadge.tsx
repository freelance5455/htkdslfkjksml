import React from 'react';
import { Trophy, Sparkles, TrendingUp, Flame, Award } from 'lucide-react';
import { PersonalRecord } from '../types';

interface PRBadgeChipProps {
  type?: 'reps' | 'weight' | 'hold' | 'generic';
  value?: string | number;
  unit?: string;
  size?: 'xs' | 'sm' | 'md';
  animated?: boolean;
}

/**
 * Compact visual 'PR' badge for exercise rows, set rows, and history cards.
 */
export const PRBadgeChip: React.FC<PRBadgeChipProps> = ({
  type = 'generic',
  value,
  unit,
  size = 'sm',
  animated = true
}) => {
  const label =
    type === 'weight'
      ? 'WEIGHT PR'
      : type === 'reps'
      ? 'REPS PR'
      : type === 'hold'
      ? 'HOLD PR'
      : 'NEW PR';

  const sizeClasses =
    size === 'xs'
      ? 'px-1.5 py-0.5 text-[9px] gap-1 rounded-md'
      : size === 'md'
      ? 'px-2.5 py-1 text-xs gap-1.5 rounded-xl'
      : 'px-2 py-0.5 text-[10px] gap-1 rounded-lg';

  return (
    <span
      className={`relative inline-flex items-center font-extrabold uppercase tracking-wider overflow-hidden bg-gradient-to-r from-amber-400/20 via-cyan-400/25 to-amber-400/20 border border-cyan-400/60 text-cyan-200 shadow-[0_0_12px_rgba(34,211,238,0.35)] shrink-0 ${sizeClasses} ${
        animated ? 'animate-badge-pop' : ''
      }`}
    >
      {/* Subtle metallic shine sweep */}
      <span className="pointer-events-none absolute inset-y-0 w-8 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shine-sweep" />
      <Trophy className="w-3 h-3 text-amber-300 fill-amber-300/30 shrink-0" />
      <span className="text-amber-200 font-black">PR</span>
      <span className="text-cyan-300 font-bold">
        {value !== undefined ? `${value}${unit ? ` ${unit}` : ''}` : label}
      </span>
    </span>
  );
};

interface PRSummaryShowcaseProps {
  records: PersonalRecord[];
  onCelebratePR?: (pr: PersonalRecord) => void;
}

/**
 * Visual PR Badge Showcase displayed on the Workout Completion Summary
 * when a user hits a new max rep, hold duration, or weight for an exercise.
 */
export const PRSummaryShowcase: React.FC<PRSummaryShowcaseProps> = ({
  records,
  onCelebratePR
}) => {
  if (!records || records.length === 0) return null;

  const getBadgeCategoryLabel = (pr: PersonalRecord) => {
    if (pr.unit === 'kg' || pr.unit === 'lbs') return 'NEW MAX WEIGHT PR';
    if (pr.unit === 'seconds') return 'NEW MAX HOLD PR';
    return 'NEW MAX REPS PR';
  };

  return (
    <div className="rounded-2xl bg-gradient-to-b from-cyan-950/45 via-[#111823] to-[#12151c] border border-cyan-400/40 p-4 text-left relative overflow-hidden shadow-[0_0_25px_-5px_rgba(34,211,238,0.3)]">
      {/* Ambient Radial Spotlight */}
      <div
        className="pointer-events-none absolute inset-0 opacity-35"
        style={{
          background:
            'radial-gradient(circle at 85% 15%, rgba(251, 191, 36, 0.22), transparent 50%), radial-gradient(circle at 15% 20%, rgba(34, 211, 238, 0.28), transparent 55%)'
        }}
      />

      {/* Header */}
      <div className="relative z-10 flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-amber-400 to-cyan-400 text-neutral-950 flex items-center justify-center shadow-[0_0_12px_rgba(34,211,238,0.5)]">
            <Trophy className="w-4 h-4 fill-neutral-950" />
          </div>
          <div>
            <div className="text-xs font-extrabold text-white uppercase tracking-wider flex items-center gap-1.5">
              <span>Personal Records Unlocked</span>
              <span className="px-1.5 py-0.2 text-[10px] font-mono font-black rounded bg-cyan-400 text-neutral-950">
                +{records.length} PR{records.length > 1 ? 's' : ''}
              </span>
            </div>
            <p className="text-[10px] text-cyan-300/90">
              All-time max performance achieved in this session
            </p>
          </div>
        </div>
        <Sparkles className="w-4 h-4 text-amber-300 animate-pulse shrink-0" />
      </div>

      {/* Visual PR Badges List */}
      <div className="relative z-10 space-y-2.5">
        {records.map((pr, index) => {
          const delta =
            pr.previousValue !== undefined && pr.previousValue > 0
              ? pr.value - pr.previousValue
              : null;

          return (
            <div
              key={pr.id || `${pr.exerciseId}-${index}`}
              onClick={() => onCelebratePR && onCelebratePR(pr)}
              style={{ animationDelay: `${index * 90}ms` }}
              className="group relative overflow-hidden rounded-2xl bg-[#0b0e14]/90 border border-cyan-500/40 hover:border-amber-300/60 p-3 transition-all flex items-center justify-between gap-3 animate-badge-pop cursor-pointer"
            >
              {/* Shimmer sweep */}
              <div className="pointer-events-none absolute inset-y-0 w-16 bg-gradient-to-r from-transparent via-cyan-300/15 to-transparent animate-shine-sweep" />

              {/* Left: Custom SVG Hexagonal PR Crest + Exercise Details */}
              <div className="flex items-center gap-3 min-w-0">
                <div className="relative w-11 h-11 flex items-center justify-center shrink-0">
                  <svg viewBox="0 0 48 48" className="w-11 h-11 drop-shadow-[0_0_8px_rgba(34,211,238,0.45)]">
                    <defs>
                      <linearGradient id={`prHexGrad_${index}`} x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#fde047" />
                        <stop offset="50%" stopColor="#22d3ee" />
                        <stop offset="100%" stopColor="#0891b2" />
                      </linearGradient>
                    </defs>
                    <polygon
                      points="24,2 43,13 43,35 24,46 5,35 5,13"
                      fill="#0f172a"
                      stroke={`url(#prHexGrad_${index})`}
                      strokeWidth="2.5"
                    />
                    <polygon
                      points="24,6 39,15 39,33 24,42 9,33 9,15"
                      fill={`url(#prHexGrad_${index})`}
                      fillOpacity="0.18"
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center leading-none">
                    <Award className="w-3.5 h-3.5 text-amber-300 mb-0.5" />
                    <span className="text-[9px] font-black tracking-tighter text-white">PR</span>
                  </div>
                </div>

                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[9px] font-extrabold uppercase tracking-widest text-amber-300">
                      {getBadgeCategoryLabel(pr)}
                    </span>
                  </div>
                  <div className="text-xs font-extrabold text-white truncate">
                    {pr.exerciseName}
                  </div>
                  <div className="text-[10px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                    {delta !== null ? (
                      <>
                        <span>Prev: {pr.previousValue} {pr.unit}</span>
                        <span className="text-cyan-400 font-bold flex items-center gap-0.5">
                          <TrendingUp className="w-2.5 h-2.5" />
                          +{delta} {pr.unit}
                        </span>
                      </>
                    ) : (
                      <span className="text-cyan-400 font-semibold flex items-center gap-1">
                        <Flame className="w-2.5 h-2.5 text-amber-400" />
                        First All-Time Record Set!
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Right: Big Record Readout */}
              <div className="text-right shrink-0 pl-2">
                <div className="text-lg font-black font-mono text-cyan-300 leading-none">
                  {pr.unit === 'kg' || pr.unit === 'lbs' ? `+${pr.value}` : pr.value}
                </div>
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mt-0.5">
                  {pr.unit}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
