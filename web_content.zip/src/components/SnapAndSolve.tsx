import React, { useState, useRef, useEffect } from 'react';
import { StudentProfile, SnapSolveResult, SavedHistoryItem } from '../types';
import { SAMPLE_PROBLEMS } from '../utils/sampleData';
import {
  Camera,
  Upload,
  Sparkles,
  HelpCircle,
  Lightbulb,
  AlertTriangle,
  RotateCcw,
  CheckCircle2,
  Copy,
  Printer,
  ChevronDown,
  ChevronUp,
  BookOpen,
  ArrowRight,
  Maximize2,
  X,
  Send,
  MessageSquare,
  Layers
} from 'lucide-react';
import { fireCelebration } from '../utils/confetti';

interface SnapAndSolveProps {
  profile: StudentProfile;
  onSaveHistory: (item: Omit<SavedHistoryItem, 'id' | 'timestamp'>) => void;
  onUpdateStats: (key: keyof StudentProfile) => void;
}

export const SnapAndSolve: React.FC<SnapAndSolveProps> = ({
  profile,
  onSaveHistory,
  onUpdateStats,
}) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [subject, setSubject] = useState<string>('Auto-detect');
  const [loading, setLoading] = useState<boolean>(false);
  const [result, setResult] = useState<SnapSolveResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);

  // Camera state
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [cameraFacing, setCameraFacing] = useState<'environment' | 'user'>('environment');
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Follow-up state
  const [followUpText, setFollowUpText] = useState<string>('');
  const [followUpLoading, setFollowUpLoading] = useState<boolean>(false);
  const [followUpHistory, setFollowUpHistory] = useState<{ q: string; a: string }[]>([]);

  // Practice question state
  const [showPracticeHint, setShowPracticeHint] = useState<boolean>(false);
  const [showPracticeAnswer, setShowPracticeAnswer] = useState<boolean>(false);
  const [practiceAnswerInput, setPracticeAnswerInput] = useState<string>('');

  // Drag and drop / Clipboard listener
  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          const blob = items[i].getAsFile();
          if (blob) {
            const reader = new FileReader();
            reader.onload = (event) => {
              if (event.target?.result) {
                setSelectedImage(event.target.result as string);
                setResult(null);
              }
            };
            reader.readAsDataURL(blob);
          }
        }
      }
    };

    window.addEventListener('paste', handlePaste);
    return () => {
      window.removeEventListener('paste', handlePaste);
      stopCamera();
    };
  }, []);

  const startCamera = async () => {
    try {
      setError(null);
      setIsCameraActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: cameraFacing },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err: any) {
      console.warn('Camera access error:', err);
      setIsCameraActive(false);
      setError('Could not access device camera. Please upload an image or choose a sample problem.');
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };

  const capturePhoto = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
      setSelectedImage(dataUrl);
      setResult(null);
      stopCamera();
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setSelectedImage(event.target.result as string);
          setResult(null);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSolve = async (imageToSolve?: string, followUpPrompt?: string) => {
    const targetImage = imageToSolve || selectedImage;
    if (!targetImage) {
      setError('Please take a photo, upload an image, or pick a sample problem first.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/snap-solve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: targetImage,
          subject,
          grade: profile.grade,
          studentName: profile.name,
          followUp: followUpPrompt,
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Failed to solve problem.');
      }

      setResult(data.data);
      onUpdateStats('solvedProblemsCount');
      fireCelebration();

      // Save to study notebook
      onSaveHistory({
        type: 'snap-solve',
        title: data.data.topic || 'Solved Problem',
        data: data.data,
        gradeWhenCreated: profile.grade,
      });
    } catch (err: any) {
      setError(err.message || 'Something went wrong while analyzing the problem. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleFollowUpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!followUpText.trim() || !selectedImage) return;

    const q = followUpText.trim();
    setFollowUpText('');
    setFollowUpLoading(true);

    try {
      const response = await fetch('/api/snap-solve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: selectedImage,
          subject,
          grade: profile.grade,
          studentName: profile.name,
          followUp: q,
        }),
      });
      const data = await response.json();
      if (data.success && data.data) {
        setFollowUpHistory((prev) => [
          ...prev,
          { q, a: data.data.gradeTailoredExplanation || data.data.directAnswer },
        ]);
      }
    } catch (err: any) {
      console.error(err);
    } finally {
      setFollowUpLoading(false);
    }
  };

  const copyToClipboard = () => {
    if (!result) return;
    const text = `Problem: ${result.transcribedProblem}\n\nDirect Answer: ${result.directAnswer}\n\nSteps:\n${result.steps
      .map((s) => `${s.stepNumber}. ${s.title}: ${s.explanation}`)
      .join('\n')}\n\nExplanation for ${profile.grade}:\n${result.gradeTailoredExplanation}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-bold uppercase tracking-wider mb-2">
            <Camera className="w-3.5 h-3.5" />
            Snap & Solve
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Homework Problem Solver
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Snap a photo of any math equation, history document, or science diagram. Step-by-step solutions calibrated for{' '}
            <span className="font-semibold text-blue-600">{profile.grade}</span>.
          </p>
        </div>

        {/* Subject Filter Pills */}
        <div className="flex items-center gap-1.5 flex-wrap bg-slate-100 p-1.5 rounded-2xl border border-slate-200">
          {['Auto-detect', 'Math', 'Science', 'History', 'English'].map((sub) => (
            <button
              key={sub}
              onClick={() => setSubject(sub)}
              className={`px-3 py-1.5 text-xs font-bold rounded-xl transition cursor-pointer ${
                subject === sub
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
              }`}
            >
              {sub}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 text-rose-700 text-sm rounded-2xl flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 shrink-0" />
            <span>{error}</span>
          </div>
          <button onClick={() => setError(null)} className="text-rose-500 hover:text-rose-700">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Snap & Solve Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Image Input Area */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center justify-between">
              <span>Input Problem Photo</span>
              <span className="text-[11px] text-slate-400 font-normal">Supports Camera, Upload & Paste</span>
            </h3>

            {/* Live Camera View */}
            {isCameraActive ? (
              <div className="relative rounded-2xl overflow-hidden bg-slate-950 aspect-4/3 flex items-center justify-center border-2 border-blue-500">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-x-0 bottom-4 flex items-center justify-center gap-4 z-10">
                  <button
                    onClick={capturePhoto}
                    className="w-16 h-16 rounded-full bg-white border-4 border-blue-600 shadow-xl flex items-center justify-center hover:scale-105 active:scale-95 transition cursor-pointer"
                    title="Take Photo"
                  >
                    <div className="w-10 h-10 rounded-full bg-blue-600" />
                  </button>
                  <button
                    onClick={stopCamera}
                    className="p-3 rounded-full bg-slate-900/80 text-white hover:bg-slate-900 transition"
                    title="Cancel camera"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ) : selectedImage ? (
              /* Selected Image Preview */
              <div className="relative rounded-2xl overflow-hidden bg-slate-100 border border-slate-200 group">
                <img
                  src={selectedImage}
                  alt="Problem preview"
                  className="w-full max-h-80 object-contain mx-auto"
                />
                <button
                  onClick={() => {
                    setSelectedImage(null);
                    setResult(null);
                  }}
                  className="absolute top-2 right-2 p-1.5 rounded-full bg-slate-900/70 text-white hover:bg-slate-900 transition"
                  title="Remove image"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              /* Drag & Drop Upload Zone */
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-300 hover:border-blue-500 hover:bg-blue-50/40 rounded-2xl p-8 text-center transition cursor-pointer flex flex-col items-center justify-center gap-3 aspect-4/3"
              >
                <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center shadow-inner">
                  <Camera className="w-7 h-7" />
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-800">
                    Snap or upload homework problem
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    Drag and drop, click to browse, or paste image with <kbd className="px-1.5 py-0.5 bg-slate-200 rounded text-[10px]">Ctrl+V</kbd>
                  </p>
                </div>
              </div>
            )}

            {/* Capture Buttons */}
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={isCameraActive ? capturePhoto : startCamera}
                className="py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Camera className="w-4 h-4 text-blue-600" />
                {isCameraActive ? 'Shutter' : 'Use Camera'}
              </button>
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Upload className="w-4 h-4 text-indigo-600" />
                Upload Photo
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={handleFileUpload}
              />
            </div>

            {/* Solve Action Button */}
            <button
              onClick={() => handleSolve()}
              disabled={loading || !selectedImage}
              className={`w-full py-3.5 px-6 rounded-2xl font-bold text-sm shadow-lg flex items-center justify-center gap-2 transition cursor-pointer ${
                loading || !selectedImage
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'
                  : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-blue-500/25'
              }`}
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Analyzing & Solving for {profile.grade}...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>Instant Snap & Solve</span>
                </>
              )}
            </button>
          </div>

          {/* Quick-test Sample Problems */}
          <div className="bg-slate-50/80 rounded-3xl p-5 border border-slate-200/80 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <Lightbulb className="w-4 h-4 text-amber-500" />
                Try Sample Problems
              </span>
              <span className="text-[11px] text-slate-500">1-click test</span>
            </div>
            <div className="space-y-2">
              {SAMPLE_PROBLEMS.map((sample) => (
                <button
                  key={sample.id}
                  onClick={() => {
                    setSelectedImage(sample.image);
                    setSubject(sample.subject);
                    setResult(null);
                    handleSolve(sample.image);
                  }}
                  className="w-full p-3 rounded-2xl bg-white hover:bg-blue-50/50 border border-slate-200 hover:border-blue-300 transition text-left flex items-center justify-between group cursor-pointer"
                >
                  <div>
                    <span className="text-xs font-bold text-slate-800 group-hover:text-blue-600 transition block">
                      {sample.title}
                    </span>
                    <span className="text-[11px] text-slate-500 block truncate max-w-xs mt-0.5">
                      {sample.previewText}
                    </span>
                  </div>
                  <span className="text-xs font-bold text-blue-600 group-hover:translate-x-1 transition shrink-0 pl-2">
                    Test →
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Interactive Solution Output */}
        <div className="lg:col-span-7 space-y-6">
          {!result && !loading && (
            <div className="bg-white rounded-3xl p-10 border border-slate-200 text-center flex flex-col items-center justify-center min-h-[420px] shadow-xs">
              <div className="w-16 h-16 rounded-3xl bg-blue-50 text-blue-600 flex items-center justify-center mb-4">
                <HelpCircle className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-800">
                Ready to solve your problem
              </h3>
              <p className="text-sm text-slate-500 max-w-md mt-1">
                Upload or snap a photo of any homework question on the left, or click one of the sample problems to test instantly.
              </p>
            </div>
          )}

          {loading && (
            <div className="bg-white rounded-3xl p-12 border border-slate-200 text-center flex flex-col items-center justify-center min-h-[420px] shadow-xs space-y-4">
              <div className="relative w-16 h-16 flex items-center justify-center">
                <div className="w-16 h-16 rounded-full border-4 border-blue-100 border-t-blue-600 animate-spin" />
                <Sparkles className="w-6 h-6 text-amber-500 absolute animate-pulse" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-800">
                  Transcribing & Solving Step-by-Step
                </h3>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  Gemini Vision is inspecting your image, verifying equations, and tailoring the explanation for a {profile.grade} student...
                </p>
              </div>
            </div>
          )}

          {result && (
            <div className="space-y-6 animate-in fade-in duration-300">
              {/* Problem Summary Bar */}
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-full bg-blue-100 text-blue-700 text-xs font-bold uppercase tracking-wide">
                      {result.subjectDetected}
                    </span>
                    <span className="text-xs font-bold text-slate-800">
                      {result.topic}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={copyToClipboard}
                      className="px-3 py-1.5 rounded-xl border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      {copied ? 'Copied!' : 'Copy Solution'}
                    </button>
                    <button
                      onClick={() => window.print()}
                      className="p-1.5 rounded-xl border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition"
                      title="Print solution"
                    >
                      <Printer className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Transcribed text */}
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/60">
                  <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                    Problem Identified
                  </span>
                  <p className="text-sm font-semibold text-slate-800 whitespace-pre-line font-mono">
                    {result.transcribedProblem}
                  </p>
                </div>

                {/* DIRECT FINAL ANSWER BOX */}
                <div className="bg-gradient-to-r from-emerald-50 to-teal-50 border-2 border-emerald-400/80 rounded-2xl p-5 shadow-xs">
                  <div className="flex items-center gap-2 text-emerald-800 font-bold text-xs uppercase tracking-wider mb-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Direct Final Answer
                  </div>
                  <div className="text-xl sm:text-2xl font-black text-emerald-950">
                    {result.directAnswer}
                  </div>
                </div>

                {/* STEP-BY-STEP REASONING */}
                <div className="space-y-3 pt-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-blue-600" />
                    Step-by-Step Solution
                  </h4>
                  <div className="space-y-3">
                    {result.steps?.map((step) => (
                      <div
                        key={step.stepNumber}
                        className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs hover:border-blue-300 transition"
                      >
                        <div className="flex items-start gap-3">
                          <span className="w-6 h-6 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                            {step.stepNumber}
                          </span>
                          <div className="space-y-1.5 flex-1">
                            <h5 className="text-sm font-bold text-slate-900">
                              {step.title}
                            </h5>
                            <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                              {step.explanation}
                            </p>
                            {step.mathOrFormula && (
                              <div className="mt-2 p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs font-semibold text-blue-900">
                                {step.mathOrFormula}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* GRADE-TAILORED EXPLANATION */}
                <div className="bg-blue-50/70 border border-blue-200 rounded-2xl p-5 space-y-2">
                  <span className="text-xs font-bold text-blue-800 uppercase tracking-wider flex items-center gap-1.5">
                    <BookOpen className="w-4 h-4 text-blue-600" />
                    Concept Explained for {profile.grade}
                  </span>
                  <p className="text-xs sm:text-sm text-slate-800 leading-relaxed">
                    {result.gradeTailoredExplanation}
                  </p>
                </div>

                {/* KEY CONCEPTS & COMMON MISTAKES */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                      <Lightbulb className="w-4 h-4 text-amber-500" />
                      Key Principles & Formulas
                    </span>
                    <ul className="space-y-1 text-xs text-slate-700">
                      {result.keyConcepts?.map((c, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="text-blue-500 font-bold">•</span>
                          <span>{c}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="p-4 bg-rose-50/60 rounded-2xl border border-rose-200 space-y-2">
                    <span className="text-xs font-bold text-rose-800 uppercase tracking-wider flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-rose-500" />
                      Common Mistakes to Avoid
                    </span>
                    <ul className="space-y-1 text-xs text-slate-700">
                      {result.commonMistakes?.map((m, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="text-rose-500 font-bold">•</span>
                          <span>{m}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* INTERACTIVE SIMILAR PRACTICE QUESTION */}
                {result.similarPracticeQuestion && (
                  <div className="p-5 rounded-2xl bg-amber-50/60 border border-amber-200 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold uppercase tracking-wider text-amber-900 flex items-center gap-1.5">
                        <Sparkles className="w-4 h-4 text-amber-600" />
                        Test Yourself: Similar Practice Problem
                      </span>
                    </div>
                    <p className="text-sm font-semibold text-slate-800">
                      {result.similarPracticeQuestion.question}
                    </p>

                    <div className="flex items-center gap-3 pt-1">
                      <button
                        onClick={() => setShowPracticeHint(!showPracticeHint)}
                        className="text-xs font-bold text-amber-800 hover:underline cursor-pointer"
                      >
                        {showPracticeHint ? 'Hide Hint' : '💡 Need a hint?'}
                      </button>
                      <button
                        onClick={() => setShowPracticeAnswer(!showPracticeAnswer)}
                        className="text-xs font-bold text-blue-700 hover:underline cursor-pointer"
                      >
                        {showPracticeAnswer ? 'Hide Solution' : 'Check Answer'}
                      </button>
                    </div>

                    {showPracticeHint && (
                      <div className="p-3 bg-white/80 rounded-xl border border-amber-200 text-xs text-slate-700 italic">
                        <strong>Hint:</strong> {result.similarPracticeQuestion.hint}
                      </div>
                    )}

                    {showPracticeAnswer && (
                      <div className="p-3 bg-white rounded-xl border border-emerald-300 text-xs text-slate-800">
                        <strong className="text-emerald-700">Answer:</strong>{' '}
                        {result.similarPracticeQuestion.answer}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Follow-up question box */}
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-blue-600" />
                  Have a question about this step or solution?
                </h4>

                {followUpHistory.length > 0 && (
                  <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
                    {followUpHistory.map((item, idx) => (
                      <div key={idx} className="space-y-1.5 text-xs">
                        <div className="p-2.5 rounded-xl bg-blue-50 text-blue-900 font-semibold">
                          You: {item.q}
                        </div>
                        <div className="p-2.5 rounded-xl bg-slate-50 text-slate-800 border border-slate-200">
                          Tutor: {item.a}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                <form onSubmit={handleFollowUpSubmit} className="flex gap-2">
                  <input
                    type="text"
                    value={followUpText}
                    onChange={(e) => setFollowUpText(e.target.value)}
                    placeholder="e.g. Why did we divide by 2 in step 3? Or can you explain this in simpler words?"
                    className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-600/30"
                  />
                  <button
                    type="submit"
                    disabled={followUpLoading || !followUpText.trim()}
                    className="px-4 py-2.5 rounded-xl bg-blue-600 text-white font-bold text-xs hover:bg-blue-700 disabled:opacity-50 transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    Ask
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
