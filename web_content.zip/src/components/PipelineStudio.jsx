import React,{useState} from "react";
import {Upload,BrainCircuit,Play,LoaderCircle} from "lucide-react";
import {PipelineEngine,STAGES} from "../engine/PipelineEngine";
import {useApp} from "../context/AppContext";
const meta=[
 ["SCRIPT","CUSTOM SCRIPT ENGINE",".txt/.docx"],
 ["IMAGE","CUSTOM IMAGE STUDIO",".png/.jpg"],
 ["AUDIO","PROPRIETARY ACOUSTIC AUDIO",".mp3"],
 ["AVATAR","IN-HOUSE AVATAR ENGINE",".mp4"],
 ["FFMPEG","INTERNAL POST-PROCESSING",".mp4"],
 ["PLAYLIST","PLAYLIST MAPPER","URL"],
 ["PUBLISH","AUTO-PUBLISHER","MEDIA"]
];
export default function PipelineStudio(){
 const {memory,setMemory,outputs,setOutputs}=useApp(); const [stage,setStage]=useState("SCRIPT"); const [mode,setMode]=useState("AI"); const [dialect,setDialect]=useState("Kolhapuri"); const [topic,setTopic]=useState("history"); const [busy,setBusy]=useState(false); const [logs,setLogs]=useState([]);
 async function run(){setBusy(true);setLogs([]);const engine=new PipelineEngine(memory);const result=await engine.runAll({topic,dialect,language:"Marathi"},(s,r)=>setMemory(m=>({...m,engineLogs:[`${s}: READY`,...m.engineLogs].slice(0,30),lastScript:r.text||m.lastScript})),l=>setLogs(x=>[l,...x].slice(0,30)));setOutputs(o=>[{id:Date.now(),...result},...o]);setBusy(false)}
 return <div className="space-y-5">
  <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2">{meta.map(([id,title,ext])=><button key={id} onClick={()=>setStage(id)} className={`glass rounded-xl p-3 text-left ${stage===id?"ring-1 ring-cyan-400":""}`}><div className="text-[10px] text-cyan-300">{id}</div><div className="text-xs font-bold mt-1">{title}</div><div className="text-[10px] text-slate-500 mt-1">{ext}</div></button>)}</div>
  <div className="glass rounded-2xl p-5">
   <div className="flex gap-2 mb-5"><button onClick={()=>setMode("AI")} className={`px-4 py-2 rounded-lg ${mode==="AI"?"bg-cyan-400 text-slate-950":"bg-white/5"}`}><BrainCircuit size={16} className="inline mr-2"/>Mode A — In-House AI</button><button onClick={()=>setMode("MANUAL")} className={`px-4 py-2 rounded-lg ${mode==="MANUAL"?"bg-cyan-400 text-slate-950":"bg-white/5"}`}><Upload size={16} className="inline mr-2"/>Mode B — Manual</button></div>
   {mode==="AI"?<div className="space-y-4">
    {stage==="SCRIPT"&&<><select value={dialect} onChange={e=>setDialect(e.target.value)} className="bg-black/30 border border-white/10 rounded-xl p-3"><option>Kolhapuri</option><option>Satari</option><option>Sanglikar</option><option>Solapuri</option></select><select value={topic} onChange={e=>setTopic(e.target.value)} className="ml-2 bg-black/30 border border-white/10 rounded-xl p-3"><option value="history">History</option><option value="food">Food</option><option value="culture">Culture</option><option value="cities">Cities</option></select></>}
    {stage==="IMAGE"&&<p className="text-sm text-slate-300">Ultra-realistic local scene renderer with Ambient AI Extras.</p>}
    {stage==="AUDIO"&&<p className="text-sm text-slate-300">Non-robotic emotional acoustic synthesis with dialect prosody.</p>}
    {stage==="AVATAR"&&<p className="text-sm text-slate-300">Fixed identity binding, full-body motion, gestures and local phoneme-to-viseme simulation.</p>}
    {stage==="FFMPEG"&&<p className="text-sm text-slate-300">Local timeline simulation for subtitles and BGM.</p>}
    {stage==="PLAYLIST"&&<p className="text-sm text-slate-300">Automatic State + Topic + Language mapping.</p>}
    {stage==="PUBLISH"&&<p className="text-sm text-slate-300">Internal scheduling queue simulation.</p>}
    <button disabled={busy} onClick={run} className="rounded-xl bg-cyan-400 text-slate-950 font-bold px-5 py-3 disabled:opacity-50">{busy?<><LoaderCircle className="spin inline mr-2" size={18}/>Running local engine...</>:<><Play className="inline mr-2" size={18}/>Run In-House Pipeline</>}</button>
   </div>:<div className="border-2 border-dashed border-white/10 rounded-2xl p-12 text-center"><Upload className="mx-auto text-cyan-300"/><p className="font-bold mt-3">Drop {meta.find(x=>x[0]===stage)?.[2]} here</p><p className="text-xs text-slate-500 mt-1">Manual mode stays independent from the local AI engine.</p></div>}
  </div>
  <div className="glass rounded-2xl p-5"><h3 className="font-bold mb-3">Internal Neural Runtime Logs</h3><div className="bg-black/25 rounded-xl p-3 h-44 overflow-auto scrollbar font-mono text-xs text-emerald-300">{logs.length?logs.map((x,i)=><div key={i}>[{String(i+1).padStart(2,"0")}] {x}</div>):"Waiting for a local pipeline run..."}</div></div>
 </div>
}