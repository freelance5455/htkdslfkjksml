import { useEffect, useState } from 'react';
import type { CefrBand, PersistedSettings, WordPhotoData } from '../types';
import { fetchWordPhoto } from '../utils/mediaApi';

interface WordPhotoThumbProps {
  word: string;
  ar?: string;
  band?: CefrBand;
  settings: PersistedSettings;
  size?: 'sm' | 'md';
}

export function WordPhotoThumb({
  word,
  ar,
  band,
  settings,
  size = 'sm',
}: WordPhotoThumbProps) {
  const [photo, setPhoto] = useState<WordPhotoData | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let active = true;
    setLoaded(false);
    setPhoto(null);

    if (!word) return;

    void fetchWordPhoto(
      word,
      1,
      {
        backendUrl: settings.backendUrl,
        pixabayKey: settings.pixabayKey,
        unsplashKey: settings.unsplashKey,
      },
      false,
      { ar, band }
    ).then((res) => {
      if (!active) return;
      if (res.status === 'ready' && res.data?.imageUrl) {
        setPhoto(res.data);
      }
    });

    return () => {
      active = false;
    };
  }, [word, ar, band, settings.backendUrl, settings.pixabayKey, settings.unsplashKey]);

  const boxClass =
    size === 'md'
      ? 'h-32 w-52 sm:h-36 sm:w-60'
      : 'h-24 w-40 sm:h-28 sm:w-48';

  const imgSrc = photo?.thumbUrl || photo?.imageUrl;

  return (
    <div
      className={`relative mx-auto overflow-hidden rounded-xl border border-slate-200 bg-slate-100 shadow-xs dark:border-slate-700/80 dark:bg-slate-800/70 ${boxClass}`}
    >
      {!loaded && (
        <div
          aria-hidden="true"
          className="absolute inset-0 animate-pulse bg-slate-200/80 dark:bg-slate-800"
        />
      )}
      {imgSrc && (
        <img
          src={imgSrc}
          alt={photo?.alt || word}
          loading="eager"
          referrerPolicy="no-referrer"
          onLoad={() => setLoaded(true)}
          className={`h-full w-full object-cover transition-opacity duration-200 ${
            loaded ? 'opacity-100' : 'opacity-0'
          }`}
        />
      )}
    </div>
  );
}
