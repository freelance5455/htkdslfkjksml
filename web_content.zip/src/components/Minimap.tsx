import React from 'react';
import type { GameTelemetry } from '../game/types';

interface MinimapProps {
  telemetry: GameTelemetry;
}

export const Minimap: React.FC<MinimapProps> = ({ telemetry }) => {
  // Map 1000x1000 (-500..+500) onto 108x108 SVG radar
  const toMap = (val: number) => ((val + 500) / 1000) * 108;

  const px = toMap(telemetry.x);
  const pz = toMap(telemetry.z);
  const headingDeg = (-telemetry.heading * 180) / Math.PI;

  const target = telemetry.missionTargetPos
    ? { x: toMap(telemetry.missionTargetPos.x), z: toMap(telemetry.missionTargetPos.z) }
    : null;

  return (
    <div className="bg-neutral-950/90 border border-white/15 rounded-xl p-1.5 shadow-lg pointer-events-auto">
      <div className="flex items-center justify-between px-1 pb-1 text-[10px] font-medium text-neutral-300">
        <span>Mapa 1000×1000</span>
        <span className="font-mono-tabular text-amber-400">
          {Math.round(telemetry.x)}, {Math.round(telemetry.z)}
        </span>
      </div>
      <svg width="108" height="108" viewBox="0 0 108 108" className="rounded-lg bg-neutral-900 border border-white/10">
        {/* Favelas NW & SW */}
        <circle cx={toMap(-245)} cy={toMap(-210)} r="16" fill="#7c2d12" fillOpacity="0.55" />
        <circle cx={toMap(-275)} cy={toMap(245)} r="13" fill="#7c2d12" fillOpacity="0.5" />
        {/* Centro da Cidade */}
        <rect x={toMap(125)} y={toMap(-260)} width="33" height="54" rx="3" fill="#1e3a8a" fillOpacity="0.45" />

        {/* Main Roads */}
        <line x1="6" y1="54" x2="102" y2="54" stroke="#52525b" strokeWidth="2.4" />
        <line x1="54" y1="6" x2="54" y2="102" stroke="#52525b" strokeWidth="2.2" />
        <line x1={toMap(240)} y1="16" x2={toMap(240)} y2="92" stroke="#52525b" strokeWidth="2" />
        <rect x="6" y="6" width="96" height="96" fill="none" stroke="#3f3f46" strokeWidth="1.2" />

        {/* Casa Principal Marker */}
        <rect x={toMap(0) - 3} y={toMap(-26) - 3} width="6" height="6" rx="1" fill="#10b981" />

        {/* Active Mission Target */}
        {target && (
          <g>
            <circle cx={target.x} cy={target.z} r="5.5" fill="none" stroke="#f59e0b" strokeWidth="1.8" />
            <circle cx={target.x} cy={target.z} r="2.2" fill="#f59e0b" />
          </g>
        )}

        {/* Police / Racer Enemy Markers */}
        {telemetry.enemyPositions.map((e, idx) => (
          <circle
            key={idx}
            cx={toMap(e.x)}
            cy={toMap(e.z)}
            r="2.8"
            fill={e.kind === 'police' ? '#3b82f6' : '#f97316'}
          />
        ))}

        {/* Remote Friends in Room */}
        {(telemetry.remotePlayers ?? []).map((rp) => (
          <g key={rp.id}>
            <circle cx={toMap(rp.x)} cy={toMap(rp.z)} r="4" fill="#38bdf8" fillOpacity="0.35" />
            <circle cx={toMap(rp.x)} cy={toMap(rp.z)} r="2.6" fill="#38bdf8" stroke="#082f49" strokeWidth="0.7" />
          </g>
        ))}

        {/* Player Arrow */}
        <g transform={`translate(${px}, ${pz}) rotate(${headingDeg})`}>
          <polygon points="0,-5 3.6,4 0,2.2 -3.6,4" fill="#facc15" stroke="#18181b" strokeWidth="0.7" />
        </g>
      </svg>
    </div>
  );
};
