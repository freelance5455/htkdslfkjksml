import React, { useState } from 'react';
import {
  Compass,
  Maximize2,
  Minimize2,
  Navigation,
  Ship,
  Target,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import { ISLANDS } from '../game/worldData';
import { MinimapData } from '../types/game';

interface MinimapProps {
  data: MinimapData | null;
  className?: string;
}

export const Minimap: React.FC<MinimapProps> = ({ data, className = '' }) => {
  const [zoomLevel, setZoomLevel] = useState<'local' | 'world'>('local');
  const [isCollapsed, setIsCollapsed] = useState(false);

  if (!data) return null;

  const { playerPos, playerYaw, currentIsland, questObjective, enemies, boatPos } = data;

  // Radar scale:
  // 'local' = 140m view radius
  // 'world' = 450m view radius (shows all Grand Sea islands)
  const viewRadius = zoomLevel === 'local' ? 140 : 450;
  const radarSize = 160; // diameter in pixels (scalable on mobile)
  const halfRadar = radarSize / 2;

  // Transform world (x, z) to minimap pixel (cx, cy) relative to player
  const worldToRadar = (wx: number, wz: number) => {
    const dx = wx - playerPos.x;
    const dz = wz - playerPos.z;
    // Map X to +X, Z to +Y
    const px = halfRadar + (dx / viewRadius) * halfRadar;
    const py = halfRadar + (dz / viewRadius) * halfRadar;
    const dist = Math.sqrt(dx * dx + dz * dz);
    return { px, py, dist, dx, dz };
  };

  // Check if quest objective is outside radar
  let objectiveIndicator = null;
  if (questObjective) {
    const { px, py, dist, dx, dz } = worldToRadar(questObjective.x, questObjective.z);
    if (dist > viewRadius * 0.95) {
      // Off-radar edge clamp
      const angle = Math.atan2(dz, dx);
      const edgeRadius = halfRadar - 12;
      const edgeX = halfRadar + Math.cos(angle) * edgeRadius;
      const edgeY = halfRadar + Math.sin(angle) * edgeRadius;
      objectiveIndicator = {
        isEdge: true,
        x: edgeX,
        y: edgeY,
        angle: angle + Math.PI / 2,
        dist: questObjective.distance,
      };
    } else {
      objectiveIndicator = {
        isEdge: false,
        x: px,
        y: py,
        angle: 0,
        dist: questObjective.distance,
      };
    }
  }

  return (
    <div className={`flex flex-col items-end ${className} pointer-events-auto select-none font-sans`}>
      {/* Current Island & Status Banner */}
      <div className="bg-slate-900/95 border border-slate-700/80 rounded-xl px-3 py-1.5 shadow-xl backdrop-blur-md mb-1.5 flex items-center justify-between gap-3 w-[190px] md:w-[210px]">
        <div className="flex items-center gap-1.5 min-w-0">
          <Compass className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <div className="truncate">
            <span className="text-xs font-bold text-white block truncate">
              {currentIsland ? currentIsland.name : 'The Grand Sea'}
            </span>
            <span className="text-[10px] text-amber-300 font-mono block">
              {currentIsland ? currentIsland.levelReq : 'Open Ocean Waters'}
            </span>
          </div>
        </div>

        {/* Collapse toggle */}
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition-colors cursor-pointer shrink-0"
          title={isCollapsed ? 'Expand Minimap' : 'Collapse Minimap'}
        >
          {isCollapsed ? <Maximize2 className="w-3 h-3" /> : <Minimize2 className="w-3 h-3" />}
        </button>
      </div>

      {!isCollapsed && (
        <div className="bg-slate-900/95 border border-slate-700/90 rounded-2xl p-2.5 shadow-2xl backdrop-blur-md relative flex flex-col items-center">
          {/* Radar Screen Container */}
          <div
            className="relative rounded-full overflow-hidden bg-slate-950 border-2 border-slate-700/80 shadow-inner flex items-center justify-center"
            style={{ width: `${radarSize}px`, height: `${radarSize}px` }}
          >
            {/* Ocean Radar Grid Background */}
            <svg
              className="absolute inset-0 w-full h-full pointer-events-none opacity-40"
              viewBox={`0 0 ${radarSize} ${radarSize}`}
            >
              <defs>
                <radialGradient id="oceanRadarGrad" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#0369a1" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#082f49" stopOpacity="0.9" />
                </radialGradient>
              </defs>
              <rect width={radarSize} height={radarSize} fill="url(#oceanRadarGrad)" />
              {/* Concentric distance rings */}
              <circle cx={halfRadar} cy={halfRadar} r={halfRadar * 0.33} fill="none" stroke="#38bdf8" strokeWidth="0.8" strokeDasharray="3 3" />
              <circle cx={halfRadar} cy={halfRadar} r={halfRadar * 0.66} fill="none" stroke="#38bdf8" strokeWidth="0.8" strokeDasharray="3 3" />
              <circle cx={halfRadar} cy={halfRadar} r={halfRadar - 2} fill="none" stroke="#38bdf8" strokeWidth="1" />
              {/* Crosshairs */}
              <line x1={0} y1={halfRadar} x2={radarSize} y2={halfRadar} stroke="#38bdf8" strokeWidth="0.6" strokeOpacity="0.5" />
              <line x1={halfRadar} y1={0} x2={halfRadar} y2={radarSize} stroke="#38bdf8" strokeWidth="0.6" strokeOpacity="0.5" />
            </svg>

            {/* Islands SVG layer */}
            <svg
              className="absolute inset-0 w-full h-full pointer-events-none"
              viewBox={`0 0 ${radarSize} ${radarSize}`}
            >
              {ISLANDS.map((isl) => {
                const { px, py } = worldToRadar(isl.x, isl.z);
                const scaledRadius = (isl.radius / viewRadius) * halfRadar;

                return (
                  <g key={isl.id}>
                    {/* Island Area */}
                    <circle
                      cx={px}
                      cy={py}
                      r={Math.max(4, scaledRadius)}
                      fill={isl.color}
                      fillOpacity="0.65"
                      stroke={isl.color}
                      strokeWidth="1.2"
                    />
                    {/* Island Center Dot */}
                    <circle cx={px} cy={py} r={2} fill="#ffffff" />
                  </g>
                );
              })}
            </svg>

            {/* Enemies & Bosses Blips */}
            <div className="absolute inset-0 pointer-events-none">
              {enemies.map((enemy) => {
                if (enemy.isDead) return null;
                const { px, py, dist } = worldToRadar(enemy.x, enemy.z);
                if (dist > viewRadius) return null;

                return (
                  <div
                    key={enemy.id}
                    className={`absolute rounded-full -translate-x-1/2 -translate-y-1/2 ${
                      enemy.isBoss
                        ? 'w-3 h-3 bg-amber-400 border border-white shadow-lg animate-pulse'
                        : 'w-1.5 h-1.5 bg-rose-500 shadow-sm'
                    }`}
                    style={{ left: `${px}px`, top: `${py}px` }}
                  />
                );
              })}
            </div>

            {/* Moored Boat Blip */}
            {boatPos && (
              <div
                className="absolute -translate-x-1/2 -translate-y-1/2 pointer-events-none"
                style={{
                  left: `${worldToRadar(boatPos.x, boatPos.z).px}px`,
                  top: `${worldToRadar(boatPos.x, boatPos.z).py}px`,
                }}
              >
                <div className="w-4 h-4 rounded-full bg-cyan-900/80 border border-cyan-400 flex items-center justify-center text-cyan-300">
                  <Ship className="w-2.5 h-2.5" />
                </div>
              </div>
            )}

            {/* Active Quest Objective Beacon */}
            {objectiveIndicator && (
              <div
                className={`absolute -translate-x-1/2 -translate-y-1/2 pointer-events-none z-10 flex flex-col items-center ${
                  objectiveIndicator.isEdge ? 'animate-pulse' : ''
                }`}
                style={{ left: `${objectiveIndicator.x}px`, top: `${objectiveIndicator.y}px` }}
              >
                {objectiveIndicator.isEdge ? (
                  <div
                    style={{ transform: `rotate(${objectiveIndicator.angle}rad)` }}
                    className="text-amber-400 drop-shadow-md"
                  >
                    <Navigation className="w-4 h-4 fill-amber-400" />
                  </div>
                ) : (
                  <div className="relative flex items-center justify-center">
                    <div className="w-4 h-4 rounded-full bg-amber-500/40 animate-ping absolute" />
                    <div className="w-3.5 h-3.5 rounded-full bg-amber-500 border border-white flex items-center justify-center text-slate-950 shadow-md">
                      <Target className="w-2.5 h-2.5" />
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Center Player Icon (Arrow pointing with playerYaw) */}
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none z-20">
              <div
                className="transition-transform duration-75"
                style={{
                  transform: `rotate(${playerYaw}rad)`,
                }}
              >
                <div className="w-4 h-4 flex items-center justify-center text-cyan-400 filter drop-shadow">
                  <Navigation className="w-4 h-4 fill-cyan-400" />
                </div>
              </div>
            </div>

            {/* Cardinal points */}
            <div className="absolute top-1 left-1/2 -translate-x-1/2 text-[9px] font-mono font-bold text-slate-400 pointer-events-none">
              N
            </div>
            <div className="absolute bottom-0.5 left-1/2 -translate-x-1/2 text-[9px] font-mono font-bold text-slate-400 pointer-events-none">
              S
            </div>
            <div className="absolute left-1.5 top-1/2 -translate-y-1/2 text-[9px] font-mono font-bold text-slate-400 pointer-events-none">
              W
            </div>
            <div className="absolute right-1.5 top-1/2 -translate-y-1/2 text-[9px] font-mono font-bold text-slate-400 pointer-events-none">
              E
            </div>
          </div>

          {/* Minimap Bottom Toolbar: Zoom Controls & Quest Distance Tracker */}
          <div className="w-full mt-2 flex items-center justify-between text-xs">
            {/* Quest Distance Indicator */}
            {questObjective ? (
              <div className="flex items-center gap-1 text-[11px] font-mono text-amber-400 font-semibold truncate max-w-[120px]">
                <Target className="w-3 h-3 text-amber-400 shrink-0" />
                <span className="truncate">{questObjective.distance}m</span>
              </div>
            ) : (
              <span className="text-[10px] text-slate-500 font-mono">No target</span>
            )}

            {/* Zoom Toggle */}
            <div className="flex items-center gap-1 bg-slate-950/80 rounded-lg p-0.5 border border-slate-800">
              <button
                onClick={() => setZoomLevel('local')}
                className={`px-1.5 py-0.5 rounded text-[10px] font-mono transition-colors cursor-pointer ${
                  zoomLevel === 'local' ? 'bg-sky-600 text-white font-bold' : 'text-slate-400 hover:text-white'
                }`}
                title="Local Radar (140m)"
              >
                Local
              </button>
              <button
                onClick={() => setZoomLevel('world')}
                className={`px-1.5 py-0.5 rounded text-[10px] font-mono transition-colors cursor-pointer ${
                  zoomLevel === 'world' ? 'bg-sky-600 text-white font-bold' : 'text-slate-400 hover:text-white'
                }`}
                title="Grand Sea World Map (450m)"
              >
                World
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
