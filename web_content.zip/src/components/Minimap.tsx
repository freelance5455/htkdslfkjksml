import React, { useEffect, useRef } from 'react';
import { DiscoveredLocation, MapMarker } from '../game/types';
import { BIOMES, getBiomeIdAt, getWorldHeight, WATER_LEVEL } from '../game/world/biomes';
import { CHUNK_SIZE } from '../game/world/chunkManager';

interface MinimapProps {
  seed: number;
  playerX: number;
  playerZ: number;
  playerYaw: number;
  inDungeon: boolean;
  discoveredChunks: string[];
  discoveredLocations: DiscoveredLocation[];
  mapMarkers: MapMarker[];
  onOpenWorldMap: () => void;
}

const SIZE = 112;
const VIEW_RADIUS_METERS = 92;

function locColor(kind: DiscoveredLocation['kind']): string {
  switch (kind) {
    case 'village':
      return '#fbbf24';
    case 'castle':
      return '#a855f7';
    case 'ruin':
      return '#e2e8f0';
    case 'cave':
      return '#38bdf8';
    case 'crypt':
      return '#f43f5e';
    default:
      return '#c084fc';
  }
}

export const Minimap: React.FC<MinimapProps> = ({
  seed,
  playerX,
  playerZ,
  playerYaw,
  inDungeon,
  discoveredChunks,
  discoveredLocations,
  mapMarkers,
  onOpenWorldMap,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, SIZE, SIZE);

    // Clip to circle
    ctx.save();
    ctx.beginPath();
    ctx.arc(SIZE / 2, SIZE / 2, SIZE / 2 - 2, 0, Math.PI * 2);
    ctx.clip();

    // Fog-of-war unexplored base
    ctx.fillStyle = inDungeon ? '#1e1b2e' : '#0b1220';
    ctx.fillRect(0, 0, SIZE, SIZE);

    if (!inDungeon) {
      const discoveredSet = new Set(discoveredChunks);
      const cellPx = 4;
      const half = SIZE / 2;
      const scale = VIEW_RADIUS_METERS / half;

      for (let py = 0; py < SIZE; py += cellPx) {
        for (let px = 0; px < SIZE; px += cellPx) {
          const dx = px + cellPx * 0.5 - half;
          const dz = py + cellPx * 0.5 - half;
          if (dx * dx + dz * dz > half * half) continue;

          const wx = playerX + dx * scale;
          const wz = playerZ + dz * scale;
          const cx = Math.floor(wx / CHUNK_SIZE + 0.5);
          const cz = Math.floor(wz / CHUNK_SIZE + 0.5);
          if (!discoveredSet.has(`${cx},${cz}`)) continue;

          const h = getWorldHeight(wx, wz, seed);
          if (h < WATER_LEVEL) {
            ctx.fillStyle = '#1d6fa3';
          } else {
            const b = BIOMES[getBiomeIdAt(wx, wz, seed)];
            ctx.fillStyle = `#${b.groundHex.toString(16).padStart(6, '0')}`;
          }
          ctx.fillRect(px, py, cellPx, cellPx);
        }
      }

      // Discovered locations inside minimap radius
      for (const loc of discoveredLocations) {
        const mx = half + (loc.x - playerX) / scale;
        const my = half + (loc.z - playerZ) / scale;
        if (Math.hypot(mx - half, my - half) > half - 6) continue;
        ctx.fillStyle = locColor(loc.kind);
        ctx.beginPath();
        ctx.arc(mx, my, loc.kind === 'village' ? 4 : 3.2, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#0f172a';
        ctx.lineWidth = 1;
        ctx.stroke();
      }

      // Custom map markers
      for (const m of mapMarkers) {
        const mx = half + (m.x - playerX) / scale;
        const my = half + (m.z - playerZ) / scale;
        if (Math.hypot(mx - half, my - half) > half - 6) continue;
        ctx.fillStyle = m.colorHex;
        ctx.fillRect(mx - 2.5, my - 2.5, 5, 5);
      }
    }

    // Center Player Direction Arrow
    ctx.save();
    ctx.translate(SIZE / 2, SIZE / 2);
    ctx.rotate(-playerYaw);
    ctx.fillStyle = '#fef08a';
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(0, -7);
    ctx.lineTo(5, 5);
    ctx.lineTo(0, 2.5);
    ctx.lineTo(-5, 5);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();

    ctx.restore();

    // Circular Frame + North indicator
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.arc(SIZE / 2, SIZE / 2, SIZE / 2 - 1.5, 0, Math.PI * 2);
    ctx.stroke();

    ctx.fillStyle = '#fef08a';
    ctx.font = 'bold 9px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('N', SIZE / 2, 11);
  }, [seed, playerX, playerZ, playerYaw, inDungeon, discoveredChunks, discoveredLocations, mapMarkers]);

  return (
    <button
      type="button"
      onClick={onOpenWorldMap}
      className="group relative flex flex-col items-center rounded-full bg-slate-950/90 p-0.5 shadow-xl transition hover:scale-105"
      title="فتح خريطة العالم (M)"
      aria-label="خريطة العالم"
    >
      <canvas ref={canvasRef} width={SIZE} height={SIZE} className="h-[96px] w-[96px] sm:h-[112px] sm:w-[112px]" />
      <span className="mt-0.5 rounded bg-slate-950/90 px-1.5 py-0.2 text-[9px] font-bold text-amber-200">
        {inDungeon ? 'داخل موقع' : 'الخريطة'}
      </span>
    </button>
  );
};
