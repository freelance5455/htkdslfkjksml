const PoliceQuickReference = () => (
  <article className="police-reference-sheet">
    <header className="reference-header">
      <div><span>UK POLICE</span><h1>Frontline Quick Reference</h1></div>
      <p>England & Wales focus · Check local force policy</p>
    </header>

    <div className="reference-grid">
      <section>
        <h2>PACE Caution</h2>
        <blockquote>“You do not have to say anything. But it may harm your defence if you do not mention when questioned something which you later rely on in court. Anything you do say may be given in evidence.”</blockquote>
        <p><strong>Not Miranda rights.</strong> Check understanding and record the reply.</p>
      </section>

      <section>
        <h2>GOWISELY</h2>
        <dl><dt>G</dt><dd>Grounds</dd><dt>O</dt><dd>Object</dd><dt>W</dt><dd>Warrant card</dd><dt>I</dt><dd>Identity</dd><dt>S</dt><dd>Station</dd><dt>E</dt><dd>Entitlement to record</dd><dt>L</dt><dd>Legal power</dd><dt>Y</dt><dd>You are detained</dd></dl>
      </section>

      <section>
        <h2>Arrest Sequence</h2>
        <ol><li>Tell them they are under arrest.</li><li>State offence and factual grounds.</li><li>State specific Code G necessity.</li><li>Give caution and check understanding.</li><li>Record significant words.</li><li>Search only under a lawful power.</li><li>Convey without unnecessary delay.</li></ol>
      </section>

      <section>
        <h2>Code G Necessity</h2>
        <ul><li>Name or address</li><li>Prevent injury</li><li>Prevent property loss/damage</li><li>Public decency</li><li>Protect child/vulnerable person</li><li>Prompt and effective investigation</li><li>Prevent disappearance</li></ul>
      </section>

      <section>
        <h2>National Decision Model</h2>
        <ol><li>Information and intelligence</li><li>Threat and risk</li><li>Powers and policy</li><li>Options and contingencies</li><li>Action and review</li></ol>
        <p>At the centre: <strong>Code of Ethics.</strong></p>
      </section>

      <section>
        <h2>THRIVE</h2>
        <dl><dt>T</dt><dd>Threat</dd><dt>H</dt><dd>Harm</dd><dt>R</dt><dd>Risk</dd><dt>I</dt><dd>Investigation</dd><dt>V</dt><dd>Vulnerability</dd><dt>E</dt><dd>Engagement</dd></dl>
      </section>

      <section>
        <h2>First on Scene</h2>
        <ol><li>Protect life.</li><li>Control threats.</li><li>Request resources.</li><li>Identify suspects.</li><li>Preserve evidence.</li><li>Separate witnesses.</li><li>Start a log.</li><li>Update control.</li></ol>
      </section>

      <section>
        <h2>BWV</h2>
        <ol><li>Activate early.</li><li>Announce recording.</li><li>Record complete context.</li><li>State reason before stopping.</li><li>Upload, label and retain.</li></ol>
        <p>BWV does not replace notes, statements or force records.</p>
      </section>

      <section>
        <h2>State Codes</h2>
        <dl>
          <dt>0</dt><dd>Panic / Emergency Assistance</dd>
          <dt>1</dt><dd>On Duty</dd>
          <dt>2</dt><dd>On Patrol</dd>
          <dt>3</dt><dd>At Station (Available)</dd>
          <dt>4</dt><dd>On Break</dd>
          <dt>5</dt><dd>En Route to Incident</dd>
          <dt>6</dt><dd>At Scene</dd>
          <dt>7</dt><dd>Committed - Deployable</dd>
          <dt>8</dt><dd>Committed - Not Deployable</dd>
          <dt>9</dt><dd>Prisoner Escort Needed</dd>
          <dt>10</dt><dd>At Court</dd>
          <dt>11</dt><dd>Off Duty</dd>
          <dt>12</dt><dd>Confidential Message</dd>
          <dt>13</dt><dd>Non-Urgent Call Back</dd>
          <dt>14</dt><dd>Urgent Call Back</dd>
          <dt>15</dt><dd>Received</dd>
          <dt>16</dt><dd>Repeat</dd>
        </dl>
      </section>

      <section>
        <h2>Call Grades</h2>
        <dl>
          <dt>I</dt><dd>Immediate · 15 min · Sirens & ELS</dd>
          <dt>S</dt><dd>Significant · 60 min · ELS only</dd>
          <dt>E</dt><dd>Extended · 48 hrs · Normal driving</dd>
          <dt>R</dt><dd>Referred · No attendance</dd>
        </dl>
      </section>

      <section>
        <h2>PNC Markers</h2>
        <dl>
          <dt>FI</dt><dd>Firearms</dd>
          <dt>WE</dt><dd>Weapons</dd>
          <dt>VI</dt><dd>Violent</dd>
          <dt>CO</dt><dd>Contagious</dd>
          <dt>ES</dt><dd>Escaper</dd>
          <dt>AG</dt><dd>Alleges</dd>
          <dt>AT</dt><dd>Ailment</dd>
          <dt>MN</dt><dd>Mental</dd>
          <dt>IM</dt><dd>M/Impers</dd>
          <dt>IF</dt><dd>F/Impers</dd>
        </dl>
      </section>

      <section>
        <h2>IC Codes</h2>
        <dl>
          <dt>IC1</dt><dd>White European</dd>
          <dt>IC2</dt><dd>Dark-skinned European</dd>
          <dt>IC3</dt><dd>African-Caribbean</dd>
          <dt>IC4</dt><dd>South Asian</dd>
          <dt>IC5</dt><dd>South/East Asian</dd>
          <dt>IC6</dt><dd>Arabian/North African</dd>
          <dt>IC0/7/9</dt><dd>Unknown</dd>
        </dl>
      </section>

      <section className="reference-wide">
        <h2>Urgent Radio Format</h2>
        <code>“Control, [call sign], urgent assistance, [exact location], [threat/weapon], [suspect description/direction], over.”</code>
      </section>
    </div>

    <footer><strong>Training and roleplay reference.</strong> Use current law, College of Policing guidance and local policy. Scotland and Northern Ireland use different legal frameworks.</footer>
  </article>
);

export default PoliceQuickReference;