import { ChevronLeft, ChevronRight, Hash, PawPrint } from "lucide-react";
import { drawForIso, type WeekDraw } from "@/lib/week-draw";
import { addDaysIso, formatShortDate, weekBounds } from "@/lib/time";

type Props = {
  todayIso: string | null;
  weekOffset: number;
  onShift: (delta: number) => void;
};

export function WeekBoard({ todayIso, weekOffset, onShift }: Props) {
  const iso = todayIso ? addDaysIso(todayIso, weekOffset * 7) : null;
  const draw: WeekDraw | null = iso ? drawForIso(iso) : null;
  const bounds = iso ? weekBounds(iso) : null;
  const current = weekOffset === 0;

  return (
    <section className="flex flex-col rounded-card border border-line bg-card shadow-card lg:col-span-2">
      <div className="flex items-start justify-between gap-3 px-5 pt-5 sm:px-6">
        <div>
          <p className="text-sm font-medium text-muted">Carta da semana</p>
          <h2 className="mt-1 text-3xl leading-none text-ink">
            {draw ? `Semana ${draw.week.week}` : "—"}
          </h2>
          <p className="mt-1 text-sm text-muted">
            {bounds ? `${formatShortDate(bounds.start)} – ${formatShortDate(bounds.end)}` : "Calculando"}
            {draw ? ` · ${draw.week.year}` : ""}
          </p>
        </div>
        <div className="flex gap-1">
          <button
            type="button"
            className="flex size-11 items-center justify-center rounded-full border border-line text-ink transition-colors hover:bg-paper"
            onClick={() => onShift(-1)}
            aria-label="Semana anterior"
          >
            <ChevronLeft className="size-5" />
          </button>
          <button
            type="button"
            className="flex size-11 items-center justify-center rounded-full border border-line text-ink transition-colors hover:bg-paper"
            onClick={() => onShift(1)}
            aria-label="Próxima semana"
          >
            <ChevronRight className="size-5" />
          </button>
        </div>
      </div>

      <div
        className="mx-5 mt-4 h-2 rounded-full sm:mx-6"
        style={{ backgroundColor: draw?.color.hex ?? "transparent" }}
        aria-hidden="true"
      />

      <ul className="flex flex-1 flex-col gap-4 px-5 py-5 sm:px-6">
        <li className="flex items-center gap-3">
          <span
            className="size-12 shrink-0 rounded-2xl border border-line"
            style={{ backgroundColor: draw?.color.hex }}
            aria-hidden="true"
          />
          <div>
            <p className="text-xs font-medium tracking-wide text-muted uppercase">Cor</p>
            <p className="font-display text-xl leading-tight text-ink">{draw?.color.name ?? "—"}</p>
            <p className="text-sm text-muted">{draw?.color.line}</p>
          </div>
        </li>
        <li className="flex items-center gap-3">
          <span className="flex size-12 shrink-0 items-center justify-center rounded-2xl bg-paper text-forest">
            <PawPrint className="size-5" aria-hidden="true" />
          </span>
          <div>
            <p className="text-xs font-medium tracking-wide text-muted uppercase">Animal</p>
            <p className="font-display text-xl leading-tight text-ink">{draw?.animal.name ?? "—"}</p>
            <p className="text-sm text-muted">{draw?.animal.line}</p>
          </div>
        </li>
        <li className="flex items-center gap-3">
          <span className="flex size-12 shrink-0 items-center justify-center rounded-2xl bg-paper text-clay">
            <Hash className="size-5" aria-hidden="true" />
          </span>
          <div>
            <p className="text-xs font-medium tracking-wide text-muted uppercase">Número</p>
            <p className="font-display text-4xl leading-none text-ink tabular-nums">
              {draw ? String(draw.number).padStart(2, "0") : "—"}
            </p>
          </div>
        </li>
      </ul>

      <p className="mt-auto border-t border-line px-5 py-3 text-sm text-muted sm:px-6">
        {current
          ? "O mesmo sorteio para todo o Brasil até domingo. Muda na segunda."
          : "Você está olhando outra semana. Volte para a de agora."}{" "}
        {!current ? (
          <button type="button" className="font-medium text-forest underline-offset-2 hover:underline" onClick={() => onShift(-weekOffset)}>
            Esta semana
          </button>
        ) : null}
      </p>
    </section>
  );
}
