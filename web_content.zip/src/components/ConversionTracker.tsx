import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Zap, 
  DollarSign, 
  Smartphone, 
  CheckCircle2, 
  RefreshCw, 
  Sparkles, 
  ShieldCheck, 
  Cpu, 
  ArrowRight, 
  Server, 
  Radio, 
  Lock, 
  Check, 
  Building2,
  Wallet,
  Activity,
  AlertCircle
} from 'lucide-react';

export interface ConversionTrackerStep {
  id: string;
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  durationMs: number;
}

interface ConversionTrackerProps {
  isOpen: boolean;
  type: 'AIRTIME_TO_CASH' | 'DATA_TO_CRYPTO';
  phoneNumber: string;
  amountText: string;
  carrier: string;
  destinationText: string;
  onComplete: () => void;
  isProcessing: boolean;
}

export const ConversionTracker: React.FC<ConversionTrackerProps> = ({
  isOpen,
  type,
  phoneNumber,
  amountText,
  carrier,
  destinationText,
  onComplete,
  isProcessing
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [progressPercent, setProgressPercent] = useState<number>(0);
  const [logs, setLogs] = useState<string[]>([]);
  const [latencyMs, setLatencyMs] = useState<number>(18);

  const steps: ConversionTrackerStep[] = type === 'AIRTIME_TO_CASH' ? [
    {
      id: 'smpp_handshake',
      title: 'SMPP Gateway v3.4 Handshake',
      subtitle: 'Allocating secure telecommunications port with carrier relay...',
      icon: <Radio className="w-5 h-5 text-amber-400 animate-pulse" />,
      durationMs: 700
    },
    {
      id: 'ss7_billing',
      title: 'SS7 / Diameter Carrier Billing Relay',
      subtitle: `Authenticating SIM line ${phoneNumber} on ${carrier}...`,
      icon: <Server className="w-5 h-5 text-amber-400 animate-pulse" />,
      durationMs: 800
    },
    {
      id: 'airtime_deduct',
      title: 'Airtime Balance Deduction & Verification',
      subtitle: `Deducting ${amountText} Airtime credit from mobile account...`,
      icon: <Smartphone className="w-5 h-5 text-amber-400 animate-pulse" />,
      durationMs: 900
    },
    {
      id: 'converto_transform',
      title: 'CONVERTO 1:1 Rate Engine Transformation',
      subtitle: 'Transforming 1 Naira Airtime to $1.00 USD / ₦ Real Cash Money...',
      icon: <RefreshCw className="w-5 h-5 text-emerald-400 animate-spin" />,
      durationMs: 750
    },
    {
      id: 'bank_routing',
      title: 'Instant Financial Payout Routing',
      subtitle: `Broadcasting funds to ${destinationText}...`,
      icon: <Building2 className="w-5 h-5 text-cyan-400 animate-pulse" />,
      durationMs: 850
    },
    {
      id: 'ledger_settlement',
      title: 'Cryptographic SHA-256 Settlement',
      subtitle: 'Generating immutable bank reference & ledger proof...',
      icon: <ShieldCheck className="w-5 h-5 text-indigo-400 animate-pulse" />,
      durationMs: 700
    },
    {
      id: 'wallet_credit',
      title: 'Settlement Finalized & Credited',
      subtitle: 'Cash Money deposited into JUHNKRIX MUSIKA App Wallet!',
      icon: <CheckCircle2 className="w-5 h-5 text-emerald-400" />,
      durationMs: 500
    }
  ] : [
    {
      id: 'smpp_handshake',
      title: '4G/5G Broadband Gateway Handshake',
      subtitle: 'Initiating high-speed telecommunication data session...',
      icon: <Radio className="w-5 h-5 text-amber-400 animate-pulse" />,
      durationMs: 700
    },
    {
      id: 'data_metering',
      title: 'Diameter Data Metering Session',
      subtitle: `Authenticating SIM line ${phoneNumber} on ${carrier}...`,
      icon: <Server className="w-5 h-5 text-amber-400 animate-pulse" />,
      durationMs: 800
    },
    {
      id: 'mb_deduction',
      title: 'Mobile Data Bundle Deduction',
      subtitle: `Deducting ${amountText} from SIM line data allowance...`,
      icon: <Smartphone className="w-5 h-5 text-amber-400 animate-pulse" />,
      durationMs: 900
    },
    {
      id: 'converto_crypto',
      title: 'CONVERTO Blockchain Tokenization Engine',
      subtitle: 'Tokenizing 1 MB mobile data into 1 Bitcoin (100,000,000 Satoshis)...',
      icon: <RefreshCw className="w-5 h-5 text-amber-400 animate-spin" />,
      durationMs: 750
    },
    {
      id: 'altar_broadcast',
      title: 'Bitcoin Mainnet & Altar Vault Broadcast',
      subtitle: `Routing Satoshis directly to ${destinationText}...`,
      icon: <Zap className="w-5 h-5 text-yellow-400 animate-pulse" />,
      durationMs: 850
    },
    {
      id: 'tx_hash_mint',
      title: 'Cryptographic SHA-256 Block Minting',
      subtitle: 'Generating immutable on-chain transaction hash...',
      icon: <ShieldCheck className="w-5 h-5 text-emerald-400 animate-pulse" />,
      durationMs: 700
    },
    {
      id: 'bitcoin_credited',
      title: 'Bitcoin Deposited & Confirmed',
      subtitle: 'Crypto balance credited to JUHNKRIX MUSIKA Altar Vault!',
      icon: <CheckCircle2 className="w-5 h-5 text-emerald-400" />,
      durationMs: 500
    }
  ];

  useEffect(() => {
    if (!isOpen) {
      setCurrentStepIndex(0);
      setProgressPercent(0);
      setLogs([]);
      return;
    }

    let isMounted = true;
    setCurrentStepIndex(0);
    setProgressPercent(5);
    setLogs([
      `[${new Date().toLocaleTimeString()}] [CONVERTO] Connection initiated with ${carrier} SMPP Gateway v3.4`,
      `[${new Date().toLocaleTimeString()}] [TELCO] Target SIM: ${phoneNumber} | Payload: ${amountText}`
    ]);

    const runPipeline = async () => {
      for (let i = 0; i < steps.length; i++) {
        if (!isMounted) return;
        setCurrentStepIndex(i);
        const percent = Math.round(((i + 1) / steps.length) * 100);
        setProgressPercent(percent);

        // Fluctuate latency slightly for authentic feedback
        setLatencyMs(Math.floor(12 + Math.random() * 16));

        // Add log entry
        setLogs(prev => [
          ...prev.slice(-6),
          `[${new Date().toLocaleTimeString()}] [STAGE ${i + 1}/${steps.length}] ${steps[i].title} - OK`
        ]);

        await new Promise(res => setTimeout(res, steps[i].durationMs));
      }

      if (isMounted) {
        setLogs(prev => [
          ...prev,
          `[${new Date().toLocaleTimeString()}] [SETTLED] All funds disbursed to ${destinationText} with zero fee slippage.`
        ]);
        setTimeout(() => {
          if (isMounted) {
            onComplete();
          }
        }, 1200);
      }
    };

    runPipeline();

    return () => {
      isMounted = false;
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const currentStep = steps[currentStepIndex] || steps[0];
  const isFinished = currentStepIndex === steps.length - 1;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-2xl bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/70 border-2 border-amber-500/50 rounded-3xl p-6 sm:p-8 shadow-2xl overflow-hidden"
        >
          {/* Background Ambient Glow */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-amber-500/20 pb-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
                  <Activity className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h3 className="text-lg font-black font-serif text-amber-100 flex items-center space-x-2">
                    <span>CONVERTO Conversion Tracker</span>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-mono">
                      LIVE RELAY
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Real-time telecom & blockchain settlement visualizer
                  </p>
                </div>
              </div>

              {/* Latency Meter */}
              <div className="flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-[11px] font-mono">
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span className="text-slate-400">Latency:</span>
                <span className="text-emerald-300 font-bold">{latencyMs}ms</span>
              </div>
            </div>

            {/* Reassuring Network Alert Box */}
            <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start space-x-3">
              <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div className="text-xs text-amber-200 leading-relaxed">
                <strong>Zero-Loss Carrier Guarantee Active:</strong> Telecom deduction is synchronized with SS7 Diameter billing. Even in high-latency or fluctuating mobile connectivity, your funds are safely reserved and guaranteed.
              </div>
            </div>

            {/* Live Progress Ring & Bar */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs font-bold font-mono">
                <span className="text-slate-300 flex items-center space-x-1.5">
                  <span>Processing Stage {currentStepIndex + 1} of {steps.length}</span>
                </span>
                <span className="text-amber-400 text-sm">{progressPercent}%</span>
              </div>

              {/* Progress Track */}
              <div className="w-full h-3 bg-slate-950 rounded-full border border-amber-500/30 overflow-hidden relative p-0.5">
                <motion.div
                  className="h-full rounded-full bg-gradient-to-r from-amber-500 via-yellow-400 to-emerald-400 shadow-lg shadow-amber-500/50"
                  initial={{ width: '0%' }}
                  animate={{ width: `${progressPercent}%` }}
                  transition={{ ease: 'easeInOut', duration: 0.3 }}
                />
              </div>
            </div>

            {/* Current Active Step Highlight Card */}
            <div className="p-4 rounded-2xl bg-slate-950/90 border border-amber-500/40 flex items-center space-x-4 shadow-inner">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center shrink-0">
                {currentStep.icon}
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-sm font-extrabold text-amber-200 truncate">
                  {currentStep.title}
                </h4>
                <p className="text-xs text-slate-400 truncate">
                  {currentStep.subtitle}
                </p>
              </div>
              <div className="text-right shrink-0">
                {isFinished ? (
                  <span className="px-3 py-1 rounded-xl bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/40">
                    COMPLETE
                  </span>
                ) : (
                  <span className="px-3 py-1 rounded-xl bg-amber-500/20 text-amber-300 text-xs font-bold border border-amber-500/40 animate-pulse">
                    ACTIVE
                  </span>
                )}
              </div>
            </div>

            {/* Step Pipeline Checklist */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-36 overflow-y-auto pr-1">
              {steps.map((step, idx) => {
                const isPassed = idx < currentStepIndex;
                const isCurrent = idx === currentStepIndex;
                return (
                  <div
                    key={step.id}
                    className={`p-2 rounded-xl flex items-center space-x-2 text-xs transition-all ${
                      isPassed
                        ? 'bg-emerald-950/30 border border-emerald-500/30 text-emerald-300'
                        : isCurrent
                        ? 'bg-amber-950/50 border border-amber-400 text-amber-200 shadow-md font-bold'
                        : 'bg-slate-950/40 border border-slate-900 text-slate-500'
                    }`}
                  >
                    <div className="shrink-0">
                      {isPassed ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : isCurrent ? (
                        <RefreshCw className="w-3.5 h-3.5 text-amber-400 animate-spin" />
                      ) : (
                        <div className="w-3.5 h-3.5 rounded-full border border-slate-700 flex items-center justify-center text-[9px]">
                          {idx + 1}
                        </div>
                      )}
                    </div>
                    <span className="truncate">{step.title}</span>
                  </div>
                );
              })}
            </div>

            {/* Live Terminal Log Viewer */}
            <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800/80 font-mono text-[10px] space-y-1 text-slate-400 max-h-24 overflow-y-auto">
              <div className="text-slate-500 font-bold uppercase tracking-wider text-[9px] border-b border-slate-900 pb-1 flex justify-between">
                <span>Telecom SMPP & Settlement Log:</span>
                <span className="text-emerald-400">ENCRYPTED TLS 1.3</span>
              </div>
              {logs.map((log, i) => (
                <div key={i} className="truncate text-slate-300">
                  {log}
                </div>
              ))}
            </div>

            {/* Footer Status */}
            <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-800">
              <div className="flex items-center space-x-2">
                <Lock className="w-3.5 h-3.5 text-emerald-400" />
                <span>Prophet JUHNKRIX SYNVAGORD Financial Settlement Relay</span>
              </div>
              <div className="text-amber-400 font-mono">
                {phoneNumber} &rarr; {destinationText.split(' ')[0]}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
