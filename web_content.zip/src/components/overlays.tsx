import { Avatar } from "@/components/avatar";
import { UrgencyBadge } from "@/components/ai-calls-view";
import { Sheet } from "@/components/sheet";
import { Button } from "@/components/ui/button";
import { formatPhone } from "@/lib/emergency";
import { formatDuration, formatFullWhen } from "@/lib/format";
import { useAppStore } from "@/lib/store";
import type { LisaPolicy } from "@/lib/types";
import { Phone, Star } from "lucide-react";
import { useState, type ReactNode } from "react";
import { toast } from "sonner";

const POLICY_OPTIONS: { id: LisaPolicy; label: string; hint: string }[] = [
  { id: "always_myself", label: "Always answer myself", hint: "Lisa never picks up" },
  { id: "lisa_may", label: "Lisa may handle", hint: "Follows the known-contact setting" },
  { id: "never_lisa", label: "Never allow Lisa", hint: "Blocked from AI handling" },
];

export function OverlayHost() {
  const overlay = useAppStore((s) => s.overlay);
  const setOverlay = useAppStore((s) => s.setOverlay);
  const close = () => setOverlay({ kind: "none" });

  if (overlay.kind === "none" || overlay.kind === "incoming" || overlay.kind === "active") {
    return null;
  }
  if (overlay.kind === "call-detail") return <CallDetail callId={overlay.callId} onClose={close} />;
  if (overlay.kind === "contact") return <ContactDetail contactId={overlay.contactId} onClose={close} />;
  if (overlay.kind === "new-contact") return <NewContact number={overlay.number} onClose={close} />;
  if (overlay.kind === "demo-ring") return <DemoRing onClose={close} />;
  if (overlay.kind === "capabilities") return <Capabilities onClose={close} />;
  if (overlay.kind === "confirm-delete") return <ConfirmDelete onClose={close} />;
  return null;
}

function CallDetail({ callId, onClose }: { callId: string; onClose: () => void }) {
  const call = useAppStore((s) => s.calls.find((c) => c.id === callId) ?? null);
  const summary = useAppStore((s) => s.summaries.find((x) => x.callId === callId) ?? null);
  const transcript = useAppStore((s) => s.transcripts.find((x) => x.callId === callId) ?? null);
  const allMessages = useAppStore((s) => s.messages);
  const markImportant = useAppStore((s) => s.markImportant);
  const placeOutgoing = useAppStore((s) => s.placeOutgoing);
  const messages = allMessages.filter((m) => m.callId === callId);

  if (!call) return null;

  return (
    <Sheet title="Call" onClose={onClose} wide>
      <div className="flex items-center gap-3 pb-4">
        <Avatar name={call.name} size="lg" />
        <div>
          <p className="text-lg font-medium">{call.name}</p>
          <p className="text-sm text-muted-foreground">{formatPhone(call.number)}</p>
          <p className="mt-1 text-xs text-subtle">{formatFullWhen(call.startedAt)}</p>
        </div>
      </div>
      <div className="mb-4 flex flex-wrap gap-2 text-xs text-muted-foreground">
        <Chip>
          {call.direction} · {formatDuration(call.durationSec)}
        </Chip>
        <Chip>{call.handler === "lisa" ? "Lisa-handled" : "You answered"}</Chip>
        {summary ? <Chip>Summary saved</Chip> : null}
      </div>
      <div className="mb-5 flex gap-2">
        <Button
          variant="success"
          className="flex-1"
          onClick={() => {
            onClose();
            placeOutgoing(call.number);
          }}
        >
          <Phone className="size-4" />
          Call
        </Button>
        <Button variant="muted" onClick={() => markImportant(call.id, !call.important)}>
          <Star className={call.important ? "size-4 fill-current text-warn" : "size-4"} />
        </Button>
      </div>

      {summary ? (
        <div className="mb-5 space-y-3 rounded-lg bg-muted px-4 py-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium tracking-wide uppercase">Call summary</h3>
            <UrgencyBadge urgency={summary.urgency} />
          </div>
          <Field k="Caller" v={summary.caller} />
          <Field k="Duration" v={summary.durationLabel} />
          <Field k="Reason" v={summary.reason} />
          <Field k="Summary" v={summary.summary} />
          <Field k="Important information" v={summary.importantInfo} />
          <Field k="Message" v={summary.message} />
          {summary.people.length ? <Field k="People" v={summary.people.join(", ")} /> : null}
          {summary.dates.length || summary.times.length ? (
            <Field k="When" v={[...summary.dates, ...summary.times].join(" · ")} />
          ) : null}
          {summary.locations.length ? <Field k="Locations" v={summary.locations.join(", ")} /> : null}
        </div>
      ) : call.handler === "lisa" ? (
        <p className="mb-4 text-sm text-muted-foreground">
          No saved summary. Turn on “Save call summaries” in Settings to keep them.
        </p>
      ) : null}

      {messages.map((m) => (
        <div key={m.id} className="mb-3 rounded-md border border-border px-3 py-3">
          <p className="text-xs tracking-wide text-subtle uppercase">Message</p>
          <p className="mt-1 text-sm">{m.text}</p>
        </div>
      ))}

      {transcript ? (
        <div className="mb-2">
          <h3 className="mb-2 text-xs tracking-wide text-subtle uppercase">Transcript</h3>
          {transcript.turns.map((t, i) => (
            <p key={`${t.at}-${i}`} className="mb-2 text-sm">
              <span className="text-subtle">{t.role === "lisa" ? "Lisa" : call.name}: </span>
              {t.text}
            </p>
          ))}
        </div>
      ) : null}
    </Sheet>
  );
}

function Field({ k, v }: { k: string; v: string }) {
  return (
    <div>
      <p className="text-[0.65rem] tracking-wide text-subtle uppercase">{k}</p>
      <p className="text-sm leading-relaxed">{v}</p>
    </div>
  );
}

function Chip({ children }: { children: ReactNode }) {
  return <span className="rounded-full bg-muted px-2.5 py-1">{children}</span>;
}

function ContactDetail({ contactId, onClose }: { contactId: string; onClose: () => void }) {
  const contact = useAppStore((s) => s.contacts.find((c) => c.id === contactId));
  const updateContact = useAppStore((s) => s.updateContact);
  const deleteContact = useAppStore((s) => s.deleteContact);
  const placeOutgoing = useAppStore((s) => s.placeOutgoing);
  const ringIncoming = useAppStore((s) => s.ringIncoming);

  if (!contact) return null;

  return (
    <Sheet title={contact.name} onClose={onClose}>
      <p className="mb-4 text-muted-foreground">{formatPhone(contact.number)}</p>
      <div className="mb-5 grid grid-cols-2 gap-2">
        <Button
          variant="success"
          onClick={() => {
            onClose();
            placeOutgoing(contact.number);
          }}
        >
          Call
        </Button>
        <Button
          variant="muted"
          onClick={() => {
            onClose();
            ringIncoming({ number: contact.number, contactId: contact.id });
          }}
        >
          Demo ring
        </Button>
      </div>
      <p className="mb-2 text-xs tracking-wide text-subtle uppercase">Lisa handling</p>
      <div className="space-y-2">
        {POLICY_OPTIONS.map((p) => (
          <button
            key={p.id}
            type="button"
            onClick={() => updateContact(contact.id, { policy: p.id })}
            className={
              contact.policy === p.id
                ? "w-full rounded-md border border-accent bg-muted px-3 py-3 text-left"
                : "w-full rounded-md border border-border px-3 py-3 text-left"
            }
          >
            <p className="text-sm">{p.label}</p>
            <p className="text-xs text-subtle">{p.hint}</p>
          </button>
        ))}
      </div>
      <div className="mt-4 flex items-center justify-between">
        <p className="text-sm">Favorite</p>
        <Button
          variant={contact.favorite ? "primary" : "muted"}
          size="sm"
          onClick={() => updateContact(contact.id, { favorite: !contact.favorite })}
        >
          {contact.favorite ? "On" : "Off"}
        </Button>
      </div>
      <Button
        variant="outline"
        className="mt-6 w-full text-destructive"
        onClick={() => {
          deleteContact(contact.id);
          onClose();
        }}
      >
        Delete contact
      </Button>
    </Sheet>
  );
}

function NewContact({ number, onClose }: { number?: string; onClose: () => void }) {
  const addContact = useAppStore((s) => s.addContact);
  const updateContact = useAppStore((s) => s.updateContact);
  const contacts = useAppStore((s) => s.contacts);
  const [name, setName] = useState("");
  const [num, setNum] = useState(number ?? "");
  const [policy, setPolicy] = useState<LisaPolicy>("lisa_may");

  return (
    <Sheet title="New contact" onClose={onClose}>
      <label className="mb-3 block text-sm">
        Name
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="mt-1 h-11 w-full rounded-md border border-border bg-muted px-3 outline-none"
        />
      </label>
      <label className="mb-3 block text-sm">
        Number
        <input
          value={num}
          onChange={(e) => setNum(e.target.value)}
          className="mt-1 h-11 w-full rounded-md border border-border bg-muted px-3 outline-none"
        />
      </label>
      <p className="mb-2 text-xs tracking-wide text-subtle uppercase">Lisa handling</p>
      <div className="space-y-2">
        {POLICY_OPTIONS.map((p) => (
          <button
            key={p.id}
            type="button"
            onClick={() => setPolicy(p.id)}
            className={
              policy === p.id
                ? "w-full rounded-md border border-accent bg-muted px-3 py-2 text-left text-sm"
                : "w-full rounded-md border border-border px-3 py-2 text-left text-sm"
            }
          >
            {p.label}
          </button>
        ))}
      </div>
      <Button
        className="mt-5 w-full"
        disabled={!num.trim()}
        onClick={() => {
          const existing = contacts.find((c) => !c.name && c.number.replace(/\D/g, "") === num.replace(/\D/g, ""));
          if (existing) {
            updateContact(existing.id, { name: name || "No name", policy });
          } else {
            addContact({ name: name || "No name", number: num, policy });
          }
          onClose();
        }}
      >
        Save
      </Button>
    </Sheet>
  );
}

function DemoRing({ onClose }: { onClose: () => void }) {
  const contacts = useAppStore((s) => s.contacts);
  const ringIncoming = useAppStore((s) => s.ringIncoming);

  function ring(number: string, name?: string, contactId?: string) {
    onClose();
    ringIncoming({ number, name, contactId });
  }

  return (
    <Sheet title="Simulate incoming call" onClose={onClose}>
      <p className="mb-4 text-sm text-muted-foreground">
        Demo a ring so you can try Answer, Lisa Handles, or Reject. This is not a cellular call.
      </p>
      <button
        type="button"
        onClick={() => ring("+917000011122", "Unknown")}
        className="mb-2 flex w-full items-center gap-3 rounded-md border border-border px-3 py-3 text-left"
      >
        <Avatar name="Unknown" />
        <div>
          <p className="font-medium">Unknown caller</p>
          <p className="text-xs text-muted-foreground">+91 70000 11122</p>
        </div>
      </button>
      {contacts.map((c) => (
        <button
          key={c.id}
          type="button"
          onClick={() => ring(c.number, c.name, c.id)}
          className="mb-2 flex w-full items-center gap-3 rounded-md border border-border px-3 py-3 text-left"
        >
          <Avatar name={c.name} />
          <div>
            <p className="font-medium">{c.name}</p>
            <p className="text-xs text-muted-foreground">{formatPhone(c.number)}</p>
          </div>
        </button>
      ))}
    </Sheet>
  );
}

function Capabilities({ onClose }: { onClose: () => void }) {
  return (
    <Sheet title="Platform limits" onClose={onClose} wide>
      <div className="space-y-4 pb-4 text-sm leading-relaxed text-muted-foreground">
        <p className="text-foreground">
          Lisa Call is built on what Android’s public Telecom APIs actually allow — not on hidden or
          rooted tricks.
        </p>
        <h3 className="text-foreground">What a default dialer can do</h3>
        <p>
          With <span className="text-foreground">ROLE_DIALER</span> and{" "}
          <span className="text-foreground">InCallService</span>, an app can show incoming and
          active call UI, answer, reject, mute, speaker, hold, DTMF, contacts, and the system call
          log.
        </p>
        <h3 className="text-foreground">What it cannot do</h3>
        <p>
          Third-party apps — including the default phone app — do not receive the cellular (GSM/IMS)
          voice stream. There is no public API to inject text-to-speech into the uplink or to
          transcribe the remote caller from that call. The <span className="text-foreground">VOICE_CALL</span>{" "}
          audio source is reserved for privileged system components. Pixel Call Screen uses private
          Play services APIs that other apps cannot use.
        </p>
        <h3 className="text-foreground">Supported architecture for Lisa talking</h3>
        <p>
          1. Self-managed ConnectionService / VoIP, where the app owns the media path.
          <br />
          2. A telephony bridge (Lisa’s number or a CPaaS conference) sitting in the audio path.
          <br />
          3. This app: you (or a VoIP caller) speak; Lisa listens with speech-to-text and replies
          with text-to-speech. That loop is real.
        </p>
        <h3 className="text-foreground">Emergency</h3>
        <p>
          Emergency numbers stay on Android’s emergency-call path. Lisa never auto-handles them.
        </p>
        <p>
          This preview is the product you can use now. A native APK still cannot legally or
          technically put Lisa on a live SIM call without a media-path partner.
        </p>
      </div>
    </Sheet>
  );
}

function ConfirmDelete({ onClose }: { onClose: () => void }) {
  const deleteAllAiData = useAppStore((s) => s.deleteAllAiData);
  return (
    <Sheet title="Delete AI call data" onClose={onClose}>
      <p className="mb-4 text-sm leading-relaxed text-muted-foreground">
        This removes summaries, transcripts, and messages. Call rows stay in Recents without AI
        details. This cannot be undone.
      </p>
      <Button
        variant="danger"
        className="w-full"
        onClick={() => {
          deleteAllAiData();
          toast("AI call data deleted");
          onClose();
        }}
      >
        Delete all AI call data
      </Button>
    </Sheet>
  );
}
