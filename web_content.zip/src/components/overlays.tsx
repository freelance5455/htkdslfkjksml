import { useEffect, useState, type FormEvent } from "react";
import { changelog, docSteps, pages, posts, roles, services } from "@/content";
import type { PageId } from "@/context";
import { useApp } from "@/context";
import { ArrowIcon, Button, CheckIcon, Field, Modal, SelectField, isEmail, useReducedMotion } from "./ui";
import { ShowcaseVisual, showcaseTabs } from "./product";

function Burst() {
  const dots = Array.from({ length: 14 }, (_, index) => {
    const angle = (index / 14) * Math.PI * 2;
    return {
      dx: `${Math.cos(angle) * 78}px`,
      dy: `${Math.sin(angle) * 64}px`,
      color: index % 2 === 0 ? "#e4a15b" : "#7ee0c8",
      delay: `${index * 18}ms`,
    };
  });
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
      {dots.map((dot) => (
        <span
          key={dot.dx + dot.delay}
          className="burst-dot"
          style={{ background: dot.color, ["--dx" as string]: dot.dx, ["--dy" as string]: dot.dy, animationDelay: dot.delay }}
        />
      ))}
    </div>
  );
}

function SuccessMark() {
  return (
    <div className="relative grid place-items-center py-2">
      <Burst />
      <svg width="64" height="64" viewBox="0 0 64 64" aria-hidden="true">
        <circle cx="32" cy="32" r="30" fill="none" stroke="rgba(228,161,91,0.35)" strokeWidth="1.5" />
        <path className="check-path" d="M20 33.5l8 8 16-18" fill="none" stroke="#e4a15b" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </div>
  );
}

export function TrialModal() {
  const { closeOverlay, trialEmail, trialPlan } = useApp();
  const enterprise = trialPlan === "Enterprise";
  const [name, setName] = useState("");
  const [email, setEmail] = useState(trialEmail);
  const [role, setRole] = useState("");
  const [size, setSize] = useState("");
  const [editor, setEditor] = useState("Cursor");
  const [company, setCompany] = useState("");
  const [note, setNote] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [copied, setCopied] = useState(false);

  const slug = (email.split("@")[1]?.split(".")[0] ?? "team").replace(/[^a-z0-9]/gi, "").toLowerCase() || "team";

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    const next: Record<string, string> = {};
    if (name.trim().length < 2) next.name = "Tell us what to call you.";
    if (!isEmail(email)) next.email = "Use a work email so we can provision the workspace.";
    if (!role) next.role = "Pick the role closest to yours.";
    if (!size) next.size = "A rough team size is enough.";
    if (enterprise && company.trim().length < 2) next.company = "Add a company name for the walkthrough.";
    setErrors(next);
    if (Object.keys(next).length) return;
    setBusy(true);
    await new Promise((resolve) => window.setTimeout(resolve, 700));
    setBusy(false);
    setDone(true);
  }

  async function copyLink() {
    const value = `https://app.nexus.ai/${slug}`;
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  }

  return (
    <Modal title={done ? "You're in." : enterprise ? "Talk with us" : "Start your free trial"} onClose={closeOverlay} wide>
      {done ? (
        <div className="relative text-center">
          <SuccessMark />
          <p className="mx-auto mt-2 max-w-md text-mist" role="status">
            {enterprise
              ? `Thanks, ${name.split(" ")[0]}. A human will write to ${email} within one business day — no automated demo loop.`
              : `A magic link is on its way to ${email}. Fourteen days of Team are waiting. No card was taken.`}
          </p>
          {!enterprise ? (
            <div className="mx-auto mt-5 flex max-w-md items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3 text-left">
              <div>
                <p className="text-[11px] uppercase tracking-[0.16em] text-faint">Workspace</p>
                <p className="font-mono text-sm text-paper">app.nexus.ai/{slug}</p>
              </div>
              <button type="button" onClick={copyLink} className="text-sm text-copper">
                {copied ? "Copied" : "Copy"}
              </button>
            </div>
          ) : null}
          <Button className="mt-6" onClick={closeOverlay}>
            Back to Nexus
          </Button>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-[0.85fr_1.15fr]">
          <div className="rounded-2xl border border-white/10 bg-[radial-gradient(circle_at_top,rgba(228,161,91,0.16),transparent_60%)] p-5">
            <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-copper">{trialPlan}</p>
            <p className="mt-2 font-serif text-3xl leading-none tracking-[-0.03em]">
              {enterprise ? "A walkthrough, not a pitch deck." : "14 days of Team."}
            </p>
            <ul className="mt-4 space-y-2 text-sm text-mist">
              {(enterprise
                ? ["VPC or cloud, your call", "Security review with a named architect", "Procurement paperwork included", "No card, no sequence of nags"]
                : ["No credit card", "Shared memory and reviewer routing", "Cancel in one click", "Keep Starter free afterward"]
              ).map((item) => (
                <li key={item} className="flex gap-2">
                  <CheckIcon className="mt-0.5 shrink-0 text-teal" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
          <form className="space-y-3" noValidate onSubmit={onSubmit}>
            <Field label="Full name" autoComplete="name" value={name} onChange={(event) => setName(event.target.value)} error={errors.name} />
            <Field label="Work email" type="email" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} error={errors.email} />
            {enterprise ? (
              <Field label="Company" autoComplete="organization" value={company} onChange={(event) => setCompany(event.target.value)} error={errors.company} />
            ) : null}
            <div className="grid gap-3 sm:grid-cols-2">
              <SelectField label="Role" value={role} onChange={(event) => setRole(event.target.value)} error={errors.role}>
                <option value="">Select</option>
                <option>Software engineer</option>
                <option>Staff / principal</option>
                <option>Engineering manager</option>
                <option>Founder</option>
                <option>Platform / DevEx</option>
              </SelectField>
              <SelectField label="Team size" value={size} onChange={(event) => setSize(event.target.value)} error={errors.size}>
                <option value="">Select</option>
                <option>Just me</option>
                <option>2–10</option>
                <option>11–50</option>
                <option>51–200</option>
                <option>200+</option>
              </SelectField>
            </div>
            {enterprise ? (
              <label className="block space-y-1.5 text-xs font-medium tracking-wide text-mist">
                What should we know?
                <textarea className="input min-h-24 resize-y" value={note} onChange={(event) => setNote(event.target.value)} placeholder="Repos, hosting, the policy question that usually stalls a trial." />
              </label>
            ) : (
              <SelectField label="Primary editor" value={editor} onChange={(event) => setEditor(event.target.value)}>
                <option>Cursor</option>
                <option>VS Code</option>
                <option>JetBrains</option>
                <option>Neovim</option>
                <option>Web studio</option>
              </SelectField>
            )}
            <Button type="submit" className="w-full" disabled={busy}>
              {busy ? "Setting things up…" : enterprise ? "Request a walkthrough" : "Create my workspace"}
              {!busy ? <ArrowIcon /> : null}
            </Button>
            <p className="text-center text-xs text-faint">We’ll only use this to open the trial. No newsletter ambush.</p>
          </form>
        </div>
      )}
    </Modal>
  );
}

export function LoginModal() {
  const { closeOverlay, openTrial } = useApp();
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (!isEmail(email)) {
      setError("Enter the email on your workspace.");
      return;
    }
    setError("");
    setBusy(true);
    await new Promise((resolve) => window.setTimeout(resolve, 500));
    setBusy(false);
    setSent(true);
  }

  return (
    <Modal title={sent ? "Check your inbox" : "Welcome back"} onClose={closeOverlay}>
      {sent ? (
        <div>
          <SuccessMark />
          <p className="text-center text-mist" role="status">
            A magic link is headed to {email}. It expires in 20 minutes.
          </p>
        </div>
      ) : (
        <form className="space-y-4" noValidate onSubmit={onSubmit}>
          <Field label="Work email" type="email" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} error={error} />
          <Button type="submit" className="w-full" disabled={busy}>
            {busy ? "Sending…" : "Email me a magic link"}
          </Button>
          <p className="text-center text-sm text-faint">
            New here?{" "}
            <button type="button" className="text-copper" onClick={() => openTrial()}>
              Start a free trial
            </button>
          </p>
        </form>
      )}
    </Modal>
  );
}

export function DemoModal() {
  const { closeOverlay, openTrial } = useApp();
  const reduce = useReducedMotion();
  const [step, setStep] = useState(0);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    if (paused || reduce) return;
    const id = window.setInterval(() => setStep((value) => (value + 1) % showcaseTabs.length), 4600);
    return () => window.clearInterval(id);
  }, [paused, reduce]);

  const current = showcaseTabs[step];

  return (
    <Modal title="A 90-second tour" onClose={closeOverlay} wide>
      <div onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
        <div className="mb-4 flex items-center justify-between gap-3">
          <div className="flex flex-wrap gap-2" role="tablist" aria-label="Tour steps">
            {showcaseTabs.map((tab, index) => (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={step === index}
                onClick={() => setStep(index)}
                className={`rounded-full px-3 py-1 text-xs ${step === index ? "bg-paper text-ink" : "text-mist hover:text-paper"}`}
              >
                {tab.label}
              </button>
            ))}
          </div>
          <button type="button" className="text-xs text-faint" onClick={() => setPaused((value) => !value)} aria-pressed={paused}>
            {paused ? "Play" : "Pause"}
          </button>
        </div>
        <div className="mb-4 h-0.5 overflow-hidden rounded-full bg-white/10" aria-hidden="true">
          {!paused && !reduce ? <div key={step} className="progress-bar h-full bg-copper" /> : <div className="h-full w-full bg-copper/40" />}
        </div>
        <p className="mb-4 max-w-xl text-sm leading-relaxed text-mist">{current.text}</p>
        <ShowcaseVisual tab={current.id} />
        <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
          <p className="text-xs text-faint">Hover to pause. A human still merges.</p>
          <Button onClick={() => openTrial({ plan: "Team" })}>
            Start free trial <ArrowIcon />
          </Button>
        </div>
      </div>
    </Modal>
  );
}

function GenericPage({ id }: { id: keyof typeof pages }) {
  const page = pages[id];
  return (
    <article>
      <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-copper">{page.kicker}</p>
      <h3 className="mt-2 font-serif text-3xl tracking-[-0.03em]">{page.title}</h3>
      <p className="mt-3 text-mist">{page.lede}</p>
      <div className="mt-6 space-y-4">
        {page.blocks.map((block, index) => {
          if (block.type === "h") return <h4 key={index} className="pt-2 text-sm font-semibold uppercase tracking-[0.16em] text-paper">{block.text}</h4>;
          if (block.type === "list") {
            return (
              <ul key={index} className="space-y-2">
                {block.items.map((item) => (
                  <li key={item} className="flex gap-2 text-sm leading-relaxed text-mist">
                    <span className="mt-2 size-1 shrink-0 rounded-full bg-copper" />
                    {item}
                  </li>
                ))}
              </ul>
            );
          }
          return <p key={index} className="text-sm leading-relaxed text-mist">{block.text}</p>;
        })}
      </div>
    </article>
  );
}

function DocsPage() {
  return (
    <article>
      <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-copper">Docs</p>
      <h3 className="mt-2 font-serif text-3xl tracking-[-0.03em]">From empty workspace to a cited answer.</h3>
      <ol className="mt-6 space-y-4">
        {docSteps.map((step, index) => (
          <li key={step.t} className="grid grid-cols-[auto_1fr] gap-4">
            <span className="font-serif text-2xl text-copper">{String(index + 1).padStart(2, "0")}</span>
            <div>
              <p className="font-medium text-paper">{step.t}</p>
              <p className="mt-1 text-sm leading-relaxed text-mist">{step.d}</p>
            </div>
          </li>
        ))}
      </ol>
    </article>
  );
}

function BlogPage() {
  const [open, setOpen] = useState(0);
  return (
    <article>
      <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-copper">Journal</p>
      <h3 className="mt-2 font-serif text-3xl tracking-[-0.03em]">Notes from the night shift.</h3>
      <div className="mt-6 space-y-3">
        {posts.map((post, index) => {
          const expanded = open === index;
          return (
            <div key={post.title} className="rounded-2xl border border-white/10">
              <button
                type="button"
                className="flex w-full items-start justify-between gap-4 px-4 py-4 text-left"
                aria-expanded={expanded}
                onClick={() => setOpen(expanded ? -1 : index)}
              >
                <span>
                  <span className="text-[11px] uppercase tracking-[0.16em] text-copper">{post.kicker} · {post.date}</span>
                  <span className="mt-1 block font-medium text-paper">{post.title}</span>
                </span>
                <span className="text-faint" aria-hidden="true">{expanded ? "–" : "+"}</span>
              </button>
              {expanded ? <p className="px-4 pb-4 text-sm leading-relaxed text-mist">{post.body}</p> : null}
            </div>
          );
        })}
      </div>
    </article>
  );
}

function StatusPage() {
  return (
    <article>
      <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-teal">All systems operational</p>
      <h3 className="mt-2 font-serif text-3xl tracking-[-0.03em]">Status</h3>
      <p className="mt-2 text-sm text-mist">90 days without a customer-facing incident. Uptime this quarter: 99.98%.</p>
      <ul className="mt-5 divide-y divide-white/10 rounded-2xl border border-white/10">
        {services.map((service) => (
          <li key={service.name} className="flex items-center justify-between px-4 py-3 text-sm">
            <span>{service.name}</span>
            <span className="inline-flex items-center gap-2 text-teal">
              <span className="size-1.5 rounded-full bg-teal" />
              {service.state}
            </span>
          </li>
        ))}
      </ul>
      <div className="mt-6">
        <p className="text-[11px] uppercase tracking-[0.16em] text-faint">Recent changes</p>
        <ul className="mt-2 space-y-2">
          {changelog.map((entry) => (
            <li key={entry.version} className="text-sm text-mist">
              <span className="text-paper">{entry.version}</span> · {entry.title}
            </li>
          ))}
        </ul>
      </div>
    </article>
  );
}

function CareersPage() {
  const { openTrial } = useApp();
  const [role, setRole] = useState(roles[0].title);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [sent, setSent] = useState(false);

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    const next: Record<string, string> = {};
    if (name.trim().length < 2) next.name = "Add your name.";
    if (!isEmail(email)) next.email = "We need a real email to reply.";
    setErrors(next);
    if (Object.keys(next).length) return;
    setSent(true);
  }

  return (
    <article>
      <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-copper">Careers</p>
      <h3 className="mt-2 font-serif text-3xl tracking-[-0.03em]">Come build the teammate you wanted.</h3>
      <p className="mt-3 text-sm leading-relaxed text-mist">
        Remote, async-first, overlap of four hours with someone on the team. We hire for taste and judgment. No puzzle gauntlet.
      </p>
      <ul className="mt-5 space-y-3">
        {roles.map((item) => (
          <li key={item.title} className="rounded-2xl border border-white/10 p-4">
            <p className="font-medium">{item.title}</p>
            <p className="mt-1 text-xs uppercase tracking-[0.14em] text-copper">{item.place}</p>
            <p className="mt-2 text-sm text-mist">{item.summary}</p>
          </li>
        ))}
      </ul>
      {sent ? (
        <p className="mt-5 rounded-2xl border border-teal/30 bg-teal/10 p-4 text-sm text-paper" role="status">
          Received. We’ll reply to {email} about the {role} role — even if the answer is not yet.
        </p>
      ) : (
        <form className="mt-5 space-y-3" noValidate onSubmit={onSubmit}>
          <SelectField label="Role" value={role} onChange={(event) => setRole(event.target.value)}>
            {roles.map((item) => (
              <option key={item.title}>{item.title}</option>
            ))}
          </SelectField>
          <Field label="Name" value={name} onChange={(event) => setName(event.target.value)} error={errors.name} />
          <Field label="Email" type="email" value={email} onChange={(event) => setEmail(event.target.value)} error={errors.email} />
          <Button type="submit">Send application</Button>
        </form>
      )}
      <button type="button" className="mt-4 text-sm text-faint" onClick={() => openTrial()}>
        Or just try the product first.
      </button>
    </article>
  );
}

function isGeneric(id: PageId): id is keyof typeof pages {
  return id !== "docs" && id !== "blog" && id !== "status" && id !== "careers";
}

const pageTitles: Record<PageId, string> = {
  about: "About",
  customers: "Customers",
  careers: "Careers",
  press: "Press",
  docs: "Docs",
  blog: "Journal",
  security: "Security",
  status: "Status",
  changelog: "Changelog",
  privacy: "Privacy",
  terms: "Terms",
  dpa: "DPA",
};

export function PageModal() {
  const { page, closeOverlay } = useApp();
  return (
    <Modal title={pageTitles[page]} onClose={closeOverlay} wide>
      {page === "docs" ? <DocsPage /> : null}
      {page === "blog" ? <BlogPage /> : null}
      {page === "status" ? <StatusPage /> : null}
      {page === "careers" ? <CareersPage /> : null}
      {isGeneric(page) ? <GenericPage id={page} /> : null}
    </Modal>
  );
}
