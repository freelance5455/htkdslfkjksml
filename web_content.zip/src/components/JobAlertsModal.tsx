import React, { useState, useEffect } from 'react';
import { JobPosting, JobCategory, JobAlertPreference } from '../types/job';
import { INDIA_STATES_AND_UTS, getDistrictsByState } from '../data/indiaLocations';
import { saveAlertPreferencesToFirestore } from '../lib/firebase';
import {
  Bell,
  X,
  Check,
  MapPin,
  Briefcase,
  GraduationCap,
  Sparkles,
  CheckCircle2
} from 'lucide-react';

interface JobAlertsModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  userEmail?: string;
  allJobs: JobPosting[];
  onOpenDetail: (job: JobPosting) => void;
}

const ALL_CATEGORIES: JobCategory[] = [
  'Government Jobs',
  'Private Jobs',
  'Latest Jobs',
  'Railway Jobs',
  'Banking Jobs',
  'Defence Jobs',
  'ITI Jobs',
  'Diploma Jobs',
  'Graduate Jobs',
  'Apprenticeship Jobs'
];

const COMMON_QUALIFICATIONS = [
  '10th Pass',
  '12th Pass',
  'ITI',
  'Diploma',
  'Graduate',
  'Post Graduate',
  'Engineering / B.Tech'
];

export const JobAlertsModal: React.FC<JobAlertsModalProps> = ({
  isOpen,
  onClose,
  userId,
  userEmail,
  allJobs,
  onOpenDetail
}) => {
  const [selectedState, setSelectedState] = useState<string>('Delhi (NCT)');
  const [selectedCategories, setSelectedCategories] = useState<JobCategory[]>([
    'Government Jobs',
    'Railway Jobs',
    'Latest Jobs'
  ]);
  const [selectedQualifications, setSelectedQualifications] = useState<string[]>([
    'Graduate'
  ]);
  const [alertsEnabled, setAlertsEnabled] = useState(true);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Load existing preference
  useEffect(() => {
    try {
      const stored = localStorage.getItem(`india_job_hub_alerts_${userId}`);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.states && parsed.states[0]) setSelectedState(parsed.states[0]);
        if (parsed.categories) setSelectedCategories(parsed.categories);
        if (parsed.qualifications) setSelectedQualifications(parsed.qualifications);
        if (typeof parsed.enabled === 'boolean') setAlertsEnabled(parsed.enabled);
      }
    } catch {
      // ignore
    }
  }, [userId]);

  if (!isOpen) return null;

  // Toggle category
  const toggleCategory = (cat: JobCategory) => {
    setSelectedCategories((prev) =>
      prev.includes(cat)
        ? prev.length > 1
          ? prev.filter((c) => c !== cat)
          : prev
        : [...prev, cat]
    );
  };

  // Toggle qualification
  const toggleQual = (q: string) => {
    setSelectedQualifications((prev) =>
      prev.includes(q) ? (prev.length > 1 ? prev.filter((item) => item !== q) : prev) : [...prev, q]
    );
  };

  // Calculate matching jobs currently in the system
  const matchingJobs = allJobs.filter((job) => {
    if (job.status === 'EXPIRED') return false;
    const matchState = !selectedState || job.state.toLowerCase() === selectedState.toLowerCase();
    const matchCat =
      selectedCategories.length === 0 ||
      job.category.some((c) => selectedCategories.includes(c));
    const matchQual =
      selectedQualifications.length === 0 ||
      selectedQualifications.some((q) =>
        job.qualification.toLowerCase().includes(q.toLowerCase())
      );
    return matchState && matchCat && matchQual;
  });

  const handleSavePreferences = async () => {
    const prefs: JobAlertPreference = {
      userId,
      userEmail,
      states: [selectedState],
      districts: [],
      categories: selectedCategories,
      qualifications: selectedQualifications,
      enabled: alertsEnabled,
      updatedAt: new Date().toISOString()
    };

    localStorage.setItem(`india_job_hub_alerts_${userId}`, JSON.stringify(prefs));
    await saveAlertPreferencesToFirestore(prefs);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div
        id="modal-job-alerts"
        className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl space-y-4 max-h-[90vh] flex flex-col"
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <span>Personalized Job Alerts</span>
                <span className="px-2 py-0.5 text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-full">
                  FCM Push Ready
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Receive instant notifications matching your state and qualification
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live Matching Summary Banner */}
        <div className="bg-gradient-to-r from-indigo-950/60 to-slate-900 border border-indigo-800/40 p-3.5 rounded-2xl flex items-center justify-between text-xs">
          <div>
            <span className="text-slate-400 block text-[11px]">Current Live Openings</span>
            <span className="text-base font-extrabold text-white">
              {matchingJobs.length} Vacancies Match Criteria
            </span>
          </div>
          <span className="px-2.5 py-1 bg-indigo-600 text-white font-bold rounded-xl text-xs">
            {selectedState}
          </span>
        </div>

        {/* Scrollable Criteria Setup */}
        <div className="flex-1 overflow-y-auto space-y-4 text-xs pr-1">
          {/* State selector */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-indigo-400" />
              <span>Target State / Union Territory</span>
            </label>
            <select
              value={selectedState}
              onChange={(e) => setSelectedState(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              {INDIA_STATES_AND_UTS.map((s) => (
                <option key={s.code} value={s.name}>
                  {s.name} {s.isUT ? '(UT)' : ''}
                </option>
              ))}
            </select>
          </div>

          {/* Categories */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1.5 flex items-center gap-1.5">
              <Briefcase className="w-3.5 h-3.5 text-amber-400" />
              <span>Job Categories of Interest</span>
            </label>
            <div className="flex flex-wrap gap-1.5">
              {ALL_CATEGORIES.map((cat) => {
                const isSelected = selectedCategories.includes(cat);
                return (
                  <button
                    type="button"
                    key={cat}
                    onClick={() => toggleCategory(cat)}
                    className={`px-2.5 py-1 rounded-xl text-xs font-medium border transition-all ${
                      isSelected
                        ? 'bg-indigo-600 border-indigo-500 text-white'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {isSelected ? '✓ ' : '+ '}
                    {cat}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Qualifications */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1.5 flex items-center gap-1.5">
              <GraduationCap className="w-3.5 h-3.5 text-emerald-400" />
              <span>Educational Qualification</span>
            </label>
            <div className="flex flex-wrap gap-1.5">
              {COMMON_QUALIFICATIONS.map((q) => {
                const isSelected = selectedQualifications.includes(q);
                return (
                  <button
                    type="button"
                    key={q}
                    onClick={() => toggleQual(q)}
                    className={`px-2.5 py-1 rounded-xl text-xs font-medium border transition-all ${
                      isSelected
                        ? 'bg-emerald-600 border-emerald-500 text-white'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {isSelected ? '✓ ' : '+ '}
                    {q}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Notification Toggle */}
          <div className="flex items-center justify-between p-3 bg-slate-950 border border-slate-800 rounded-2xl">
            <div>
              <span className="font-semibold text-white block">Active Notification Delivery</span>
              <span className="text-[11px] text-slate-400">
                Receive browser and in-app alerts when matching jobs publish
              </span>
            </div>
            <button
              type="button"
              onClick={() => setAlertsEnabled(!alertsEnabled)}
              className={`w-11 h-6 rounded-full transition-colors relative ${
                alertsEnabled ? 'bg-indigo-600' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                  alertsEnabled ? 'right-1' : 'left-1'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="border-t border-slate-800 pt-3 flex items-center gap-2">
          {savedSuccess ? (
            <div className="w-full py-2.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded-xl text-center font-bold text-xs flex items-center justify-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Preferences Saved to Cloud Alerts!</span>
            </div>
          ) : (
            <>
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs"
              >
                Close
              </button>
              <button
                type="button"
                onClick={handleSavePreferences}
                className="flex-[2] py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 transition-all active:scale-95"
              >
                Save Alert Settings ({matchingJobs.length} Jobs)
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
