import React, { useMemo } from 'react';
import { ChevronRight } from 'lucide-react';
import { ClanDashboardState, PlayerProfile, ROLE_LABELS_RU } from '../shared/cocData';
import { getStatusTextColor, TH_SERIES_COLORS } from '../utils/formatters';

interface TownHallGroupsViewProps {
  state: ClanDashboardState;
  selectedTh: number | 'all';
  onSelectTh: (th: number | 'all') => void;
  onSelectPlayer: (tag: string) => void;
}

function getItemAvgText(player: PlayerProfile, itemId: string): string {
  const item = player.items.find((i) => i.id === itemId);
  if (!item || item.levels.length === 0) return '—';
  const avg = item.levels.reduce((a, b) => a + b, 0) / item.levels.length;
  const formatted = Number.isInteger(avg) ? String(avg) : avg.toFixed(1);
  return `${formatted}/${item.maxLevelForTh}`;
}

export const TownHallGroupsView: React.FC<TownHallGroupsViewProps> = ({
  state,
  selectedTh,
  onSelectTh,
  onSelectPlayer,
}) => {
  const visibleGroups = useMemo(() => {
    if (selectedTh === 'all') return state.thGroups;
    return state.thGroups.filter((g) => g.townHallLevel === selectedTh);
  }, [state.thGroups, selectedTh]);

  return (
    <div className="space-y-6">
      {/* Header & TH Segmented Selector */}
      <section className="flex flex-col gap-4 border-b border-slate-800/90 pb-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-100">
            Группировка клана по Ратуше
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Сравнение прокачки пушек, ключевой обороны, героев и стен между игроками одного уровня Ратуши
          </p>
        </div>

        <div className="flex items-center gap-1 overflow-x-auto rounded-lg border border-slate-800 bg-[#121824] p-1">
          <button
            type="button"
            onClick={() => onSelectTh('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              selectedTh === 'all'
                ? 'bg-amber-500 text-slate-950 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Все TH ({state.players.length})
          </button>
          {state.thGroups.map((g) => (
            <button
              key={g.townHallLevel}
              type="button"
              onClick={() => onSelectTh(g.townHallLevel)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                selectedTh === g.townHallLevel
                  ? 'bg-amber-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              TH {g.townHallLevel} ({g.playerCount})
            </button>
          ))}
        </div>
      </section>

      {/* Group Sections */}
      <div className="space-y-8">
        {visibleGroups.length === 0 && (
          <div className="rounded-lg border border-slate-800 bg-[#121824] p-8 text-center text-sm text-slate-400">
            Нет данных по группам Ратуши. Подключите клан через официальный Supercell Clash of Clans API на вкладке «Обзор».
          </div>
        )}
        {visibleGroups.map((group) => {
          const accentColor = TH_SERIES_COLORS[group.townHallLevel] ?? '#94A3B8';
          return (
            <section
              key={group.townHallLevel}
              className="rounded-lg border border-slate-800 bg-[#121824] overflow-hidden"
            >
              {/* Group Top Summary */}
              <div className="border-b border-slate-800 px-5 py-4">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <span
                      className="h-3.5 w-3.5 rounded-xs"
                      style={{ backgroundColor: accentColor }}
                    />
                    <div>
                      <h2 className="font-display text-lg font-bold text-slate-100">
                        Группа: Ратуша {group.townHallLevel}
                      </h2>
                      <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-slate-400">
                        <span className="tabular-nums">{group.playerCount} игроков</span>
                        <span aria-hidden="true">·</span>
                        <span className="tabular-nums">Активных строителей: {group.activeBuildersCount}</span>
                        <span aria-hidden="true">·</span>
                        <span className="tabular-nums">Улучшений за 7 дней: +{group.recentUpgradesCount}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-6 text-right">
                    <div>
                      <div className="text-[11px] text-slate-400">Средняя база</div>
                      <div className="font-mono text-xl font-bold tabular-nums text-amber-400">
                        {group.avgOverallPct.toFixed(1)}%
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] text-slate-400">Оборона</div>
                      <div className="font-mono text-base font-semibold tabular-nums text-slate-100">
                        {group.avgDefensesPct.toFixed(1)}%
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] text-slate-400">Герои</div>
                      <div className="font-mono text-base font-semibold tabular-nums text-emerald-400">
                        {group.avgHeroesPct.toFixed(1)}%
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] text-slate-400">Лаб.</div>
                      <div className="font-mono text-base font-semibold tabular-nums text-sky-400">
                        {group.avgLabPct.toFixed(1)}%
                      </div>
                    </div>
                  </div>
                </div>

                {/* Average Levels of Key Buildings in this TH Group */}
                <div className="mt-4 flex flex-wrap items-center gap-x-6 gap-y-2 border-t border-slate-800/70 pt-3 text-xs">
                  <span className="text-slate-400 font-medium">Средние уровни построек в группе:</span>
                  {group.keyBuildingAverages.slice(0, 7).map((kb) => (
                    <span key={kb.id} className="text-slate-300">
                      {kb.nameRu}:{' '}
                      <span className="font-mono font-semibold tabular-nums text-slate-100">
                        {kb.avgLevel}/{kb.maxLevel}
                      </span>
                    </span>
                  ))}
                </div>
              </div>

              {/* Players Comparison Table inside TH Group */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs sm:text-sm">
                  <thead>
                    <tr className="border-b border-slate-800/80 text-xs font-medium text-slate-400 bg-[#0B0F17]/40">
                      <th className="px-5 py-2.5">Игрок</th>
                      <th className="px-3 py-2.5 text-right">База</th>
                      <th className="px-3 py-2.5 text-right">Оборона</th>
                      <th className="px-3 py-2.5 text-right">Герои</th>
                      <th className="px-3 py-2.5 text-right">Пушка</th>
                      <th className="px-3 py-2.5 text-right">Арбалет</th>
                      <th className="px-3 py-2.5 text-right">Адская б.</th>
                      <th className="px-3 py-2.5 text-right">Стены</th>
                      <th className="px-3 py-2.5 text-right">Статус</th>
                      <th className="px-5 py-2.5 text-right">База</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {group.players.map((p) => (
                      <tr
                        key={p.tag}
                        onClick={() => onSelectPlayer(p.tag)}
                        className="cursor-pointer transition-colors hover:bg-slate-800/35"
                      >
                        <td className="px-5 py-3">
                          <div className="font-medium text-slate-100">{p.name}</div>
                          <div className="text-[11px] text-slate-500">
                            <span className="font-mono">{p.tag}</span>
                            <span className="mx-1.5">·</span>
                            <span>{ROLE_LABELS_RU[p.role]}</span>
                            <span className="mx-1.5">·</span>
                            <span className="tabular-nums">{p.activeBuilders.length} строит.</span>
                          </div>
                        </td>
                        <td className="px-3 py-3 text-right font-mono font-semibold tabular-nums text-amber-400">
                          {p.progress.overallPct.toFixed(1)}%
                        </td>
                        <td className="px-3 py-3 text-right font-mono tabular-nums text-slate-200">
                          {p.progress.defensesPct.toFixed(1)}%
                        </td>
                        <td className="px-3 py-3 text-right font-mono tabular-nums text-emerald-400">
                          {p.progress.heroesPct.toFixed(1)}%
                        </td>
                        <td className="px-3 py-3 text-right font-mono tabular-nums text-slate-300">
                          {getItemAvgText(p, 'cannon')}
                        </td>
                        <td className="px-3 py-3 text-right font-mono tabular-nums text-slate-300">
                          {getItemAvgText(p, 'xbow')}
                        </td>
                        <td className="px-3 py-3 text-right font-mono tabular-nums text-slate-300">
                          {getItemAvgText(p, 'inferno_tower')}
                        </td>
                        <td className="px-3 py-3 text-right font-mono tabular-nums text-slate-300">
                          {p.progress.wallsPct.toFixed(0)}%
                        </td>
                        <td className={`px-3 py-3 text-right text-xs font-medium ${getStatusTextColor(p.progress.statusLabel)}`}>
                          {p.progress.statusLabel}
                        </td>
                        <td className="px-5 py-3 text-right">
                          <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-400">
                            Инспектор
                            <ChevronRight className="h-3.5 w-3.5" />
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
};
