"use client";

import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { SquadApp } from "@/components/squad-app";
import { clearToken, getToken } from "@/lib/client-session";
import type { ActivityItem, MemberStats, SquadSnapshot } from "@/lib/types";

type SquadPayload = {
  snapshot: SquadSnapshot;
  me: MemberStats;
  activity: ActivityItem[];
};

export function SquadGate() {
  const router = useRouter();
  const [data, setData] = useState<SquadPayload | null>(null);
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");

  const load = useCallback(async () => {
    const token = getToken();
    try {
      const response = await fetch("/api/squad", {
        headers: token ? { "x-marvel-session": token } : {},
        cache: "no-store",
      });

      if (response.status === 401) {
        clearToken();
        setStatus("error");
        return;
      }

      if (!response.ok) {
        setStatus("error");
        return;
      }

      const payload = (await response.json()) as SquadPayload;
      setData(payload);
      setStatus("ready");
    } catch {
      setStatus((current) => (current === "ready" ? current : "error"));
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    const handler = () => {
      void load();
    };
    window.addEventListener("marvel:refresh", handler);
    return () => window.removeEventListener("marvel:refresh", handler);
  }, [load]);

  if (status === "loading") {
    return (
      <div className="grid min-h-screen place-items-center px-4">
        <div className="flex flex-col items-center gap-4">
          <span className="grid h-14 w-14 animate-pulse place-items-center rounded-2xl bg-mv-red font-display text-2xl text-white">
            M
          </span>
          <p className="font-display text-lg tracking-wide text-white/70">Carico la squadra...</p>
          <div className="h-1 w-40 overflow-hidden rounded-full bg-white/10">
            <div className="h-full w-1/2 animate-pulse rounded-full bg-mv-red" />
          </div>
        </div>
      </div>
    );
  }

  if (status === "error" || !data) {
    return (
      <div className="grid min-h-screen place-items-center px-4">
        <div className="comic-panel relative w-full max-w-md overflow-hidden rounded-3xl p-7 text-center">
          <div className="stripes absolute inset-x-0 top-0 h-1.5 opacity-80" />
          <p className="text-3xl">🦸</p>
          <h1 className="mt-2 font-display text-2xl leading-none text-white">Nessuna sessione attiva</h1>
          <p className="mt-2 text-sm leading-relaxed text-white/55">
            Non trovo il tuo profilo in questo browser. Rientra con il codice della squadra o creane una nuova: ci
            vogliono 5 secondi.
          </p>
          <button
            type="button"
            onClick={() => {
              clearToken();
              router.push("/");
              router.refresh();
            }}
            className="mt-5 w-full cursor-pointer rounded-xl bg-mv-red px-4 py-3 text-xs font-black uppercase tracking-widest text-white transition hover:bg-mv-red-dark active:scale-[0.99]"
          >
            Vai alla pagina iniziale
          </button>
        </div>
      </div>
    );
  }

  return <SquadApp snapshot={data.snapshot} me={data.me} activity={data.activity} />;
}
