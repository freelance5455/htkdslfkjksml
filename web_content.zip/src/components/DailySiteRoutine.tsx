import React, { useEffect, useState } from 'react';
import {
  Camera,
  CheckSquare,
  ClipboardCheck,
  Plus,
  RotateCcw,
  ShieldCheck,
  Square,
  Sun,
  Trash2,
  X,
} from 'lucide-react';
import { LangMode } from '../data/types';
import { BiTextBlock } from './BilingualBlock';
import { SiteCameraModal } from './SiteCameraModal';
import {
  getRoutineStorageKey,
  loadDailyRoutineState,
  RoutineCategory,
  RoutineItem,
  RoutinePhoto,
  saveDailyRoutineState,
} from '../utils/routineStorage';

export type { RoutineCategory };

const DEFAULT_ROUTINE_ITEMS: RoutineItem[] = [
  // Morning Task List
  {
    id: 'm1',
    category: 'morning',
    timeTag: '07:00 AM',
    title: {
      en: 'Check Approved IFC Drawing & FFL Datum Marks',
      hi: 'अप्रूव्ड IFC ड्रॉइंग और FFL फर्श लेवल निशान जांचें',
    },
    detail: {
      en: 'Confirm latest revision sheet and mason Finished Floor Level (+1.00m benchmark) before marking any wall outlets.',
      hi: 'दीवार पर पॉइंट मार्क करने से पहले आज की नई ड्रॉइंग और राजमिस्त्री का FFL लेवल (+1.00m निशान) जरूर मिलाएं।',
    },
  },
  {
    id: 'm2',
    category: 'morning',
    timeTag: '07:15 AM',
    title: {
      en: 'Inspect Tools, PPR Welder (260°C) & Sharp Cutter Blades',
      hi: 'औजार, PPR वेल्डिंग मशीन (260°C) और कटर ब्लेड चेक करें',
    },
    detail: {
      en: 'Clean 20/25/32mm Teflon heating dies with a dry cotton cloth and verify spirit level bubble accuracy.',
      hi: '20/25/32mm हीटर डाई को सूखे कपड़े से साफ करें और स्पिरिट लेवल व कटर ब्लेड की धार जांचें।',
    },
  },
  {
    id: 'm3',
    category: 'morning',
    timeTag: '07:30 AM',
    title: {
      en: 'Verify Zone Materials: PPR Pipes, Brass Elbows & Test Plugs',
      hi: 'जोन मटेरियल: PPR पाइप, ब्रास एल्बो और डमी प्लग गिनें',
    },
    detail: {
      en: 'Ensure enough pipe clamps, Armaflex thermal insulation sleeves, and end caps are at the work bay.',
      hi: 'काम शुरू करने से पहले क्लैंप, इंसुलेशन फोम और पाइप बंद करने के एंड-कैप पास में रख लें।',
    },
  },
  {
    id: 'm4',
    category: 'morning',
    timeTag: '07:45 AM',
    title: {
      en: 'Attend Morning Toolbox Talk & Foreman Work Allocation',
      hi: 'सुबह की टूलबॉक्स मीटिंग (TBT) और फोरमैन निर्देश सुनें',
    },
    detail: {
      en: 'Confirm today’s target apartments/bathrooms, MEP shaft access permit, and concrete coring clearances.',
      hi: 'आज किस फ्लैट या बाथरूम में काम करना है और शाफ्ट/कोरिंग की परमिशन है या नहीं, फोरमैन से कन्फर्म करें।',
    },
  },

  // Progress & Quality Checks
  {
    id: 'p1',
    category: 'progress',
    timeTag: 'First Fix',
    title: {
      en: 'Hot LEFT / Cold RIGHT & 150mm Mixer Centers Checked',
      hi: 'गर्म बाएं (Left) / ठंडा दाएं (Right) और 150mm मिक्सर सेंटर जांच',
    },
    detail: {
      en: 'Confirm concealed brass elbows sit dead-level and match final tile thickness before mortar closing.',
      hi: 'मसाला भरने से पहले स्पिरिट लेवल से दोनों ब्रास एल्बो की सीध और टाइल की मोटाई बराबर जांच लें।',
    },
  },
  {
    id: 'p2',
    category: 'progress',
    timeTag: 'Support & Slope',
    title: {
      en: 'Pipe Clamps Every 1.0m & Drainage Slope 1:50 / 1:100 Verified',
      hi: 'हर 1.0m पर क्लैंप और ड्रेनेज स्लोप (1:50 / 1:100) चेक',
    },
    detail: {
      en: 'Check 50mm waste (2cm/m drop) and 110mm soil (1cm/m drop) with a spirit level plus multi-inlet floor trap seal.',
      hi: '50mm वेस्ट में 2 सेमी/मीटर और 110mm पाइप में 1 सेमी/मीटर ढलान स्पिरिट लेवल से पक्का करें।',
    },
  },
  {
    id: 'p3',
    category: 'progress',
    timeTag: 'IR Testing',
    title: {
      en: '10 Bar Hydrostatic Pressure Test & Consultant IR Photo Logged',
      hi: '10 Bar प्रेशर टेस्ट और इंजीनियर IR इंस्पेक्शन पूरा',
    },
    detail: {
      en: 'Bleed all air pockets, pump to 10 Bar (150 PSI), verify zero drop for 2+ hours, and submit IR before tiling.',
      hi: 'पूरी हवा निकालकर 10 Bar प्रेशर भरें, 2 घंटे तक जीरो ड्रॉप चेक करें और टाइल से पहले IR पास करवाएं।',
    },
  },
  {
    id: 'p4',
    category: 'progress',
    timeTag: 'End of Shift',
    title: {
      en: 'Cap Every Open Pipe & Floor Trap Before Leaving Site',
      hi: 'शाम को सभी खुले पाइप और फ्लोर ट्रैप पर डमी प्लग लगाएं',
    },
    detail: {
      en: 'Protect open drains and supply drops with test plugs/tape so plaster, cement, or tile grout never blocks lines.',
      hi: 'सभी खुले मुंह को प्लग या टेप से बंद करें ताकि सीमेंट व टाइल का मसाला पाइप में न गिरे।',
    },
  },

  // Safety & PPE Checks
  {
    id: 's1',
    category: 'safety',
    timeTag: 'PPE Mandatory',
    title: {
      en: 'Hard Hat, Safety Goggles, Cut Gloves & Steel-Toe Boots Worn',
      hi: 'हेलमेट, सेफ्टी चश्मा, कट-प्रूफ दस्ताने और सेफ्टी शूज पहने हैं',
    },
    detail: {
      en: 'Zero exception inside active UAE/Dubai construction zones; wear ear protection during wall chasing/grinding.',
      hi: 'दुबई साइट पर बिना पूरे PPE के काम मना है; दीवार ग्राइंडर चलाते समय चश्मा व ईयर-प्लग जरूर लगाएं।',
    },
  },
  {
    id: 's2',
    category: 'safety',
    timeTag: 'Thermal Safety',
    title: {
      en: '260°C PPR Welder Placed on Metal Stand Away from Wet Floors',
      hi: '260°C वेल्डिंग मशीन लोहे के स्टैंड पर और सूखी जगह पर रखी है',
    },
    detail: {
      en: 'Keep power cable inspected (no bare joints) and clear of the hot heating plate.',
      hi: 'बिजली के तार में कोई खुला जोड़ न हो और तार गर्म हीटर प्लेट से दूर रहे।',
    },
  },
  {
    id: 's3',
    category: 'safety',
    timeTag: 'Chemical & Fire',
    title: {
      en: 'Ventilation Checked for uPVC Solvent Cement & No Sparks Nearby',
      hi: 'सॉल्वेंट ग्लू लगाते समय हवा का इंतजाम और पास में चिंगारी नहीं है',
    },
    detail: {
      en: 'Close solvent glue cans tightly after use and keep away from grinders or welding sparks.',
      hi: 'इस्तेमाल के तुरंत बाद ग्लू का डिब्बा कसकर बंद करें और ग्राइंडर की चिंगारी से दूर रखें।',
    },
  },
  {
    id: 's4',
    category: 'safety',
    timeTag: 'Height & Shaft',
    title: {
      en: 'A-Frame Ladder / Scaffolding Locked & Shaft Fall Barriers Intact',
      hi: 'सीढ़ी/मचान (Scaffolding) लॉक और डक्ट की सेफ्टी रेलिंग सुरक्षित है',
    },
    detail: {
      en: 'Use 3-point contact on ladders and hook safety harness when working near open MEP shaft edges.',
      hi: 'सीढ़ी पर 3-पॉइंट पकड़ रखें और खुले शाफ्ट या ऊंचाई पर सेफ्टी बेल्ट (Harness) जरूर बांधें।',
    },
  },
];

export const DailySiteRoutine: React.FC<{ lang: LangMode }> = ({ lang }) => {
  const [filter, setFilter] = useState<'all' | RoutineCategory>('all');
  const [initialState] = useState(() => loadDailyRoutineState());
  const [checkedMap, setCheckedMap] = useState<Record<string, boolean>>(initialState.checkedMap);
  const [customItems, setCustomItems] = useState<RoutineItem[]>(initialState.customItems);
  const [photosMap, setPhotosMap] = useState<Record<string, RoutinePhoto[]>>(initialState.photosMap);
  const [lastSavedAt, setLastSavedAt] = useState<string | null>(initialState.lastSavedAt);
  const [storageWarning, setStorageWarning] = useState(false);
  const [cameraTarget, setCameraTarget] = useState<RoutineItem | null>(null);
  const [previewPhoto, setPreviewPhoto] = useState<{ photo: RoutinePhoto; title: string } | null>(null);
  const [newTaskText, setNewTaskText] = useState('');
  const [newTaskCategory, setNewTaskCategory] = useState<RoutineCategory>('morning');

  useEffect(() => {
    const result = saveDailyRoutineState({
      checkedMap,
      customItems,
      photosMap,
      lastSavedAt: new Date().toISOString(),
    });
    setLastSavedAt(result.state.lastSavedAt);
    setStorageWarning(result.quotaExceeded);
  }, [checkedMap, customItems, photosMap]);

  useEffect(() => {
    const storageKey = getRoutineStorageKey();
    const handleStorageSync = (event: StorageEvent) => {
      if (event.key !== storageKey) return;
      const synced = loadDailyRoutineState();
      setCheckedMap(synced.checkedMap);
      setCustomItems(synced.customItems);
      setPhotosMap(synced.photosMap);
      setLastSavedAt(synced.lastSavedAt);
    };
    window.addEventListener('storage', handleStorageSync);
    return () => window.removeEventListener('storage', handleStorageSync);
  }, []);

  const allItems = [...DEFAULT_ROUTINE_ITEMS, ...customItems];

  const toggleItem = (id: string) => {
    setCheckedMap((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleResetAll = () => {
    setCheckedMap({});
  };

  const handleAddCustom = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newTaskText.trim();
    if (!trimmed) return;
    const item: RoutineItem = {
      id: `custom-${Date.now()}`,
      category: newTaskCategory,
      timeTag: 'Site Note',
      title: { en: trimmed, hi: trimmed },
      detail: {
        en: 'Custom daily site routine task added for today’s shift.',
        hi: 'आज की शिफ्ट के लिए जोड़ा गया आपका कस्टम साइट कार्य।',
      },
      isCustom: true,
    };
    setCustomItems((prev) => [...prev, item]);
    setNewTaskText('');
  };

  const removeCustom = (id: string) => {
    setCustomItems((prev) => prev.filter((item) => item.id !== id));
    setCheckedMap((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
    setPhotosMap((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
  };

  const handleAttachPhoto = (itemId: string, dataUrl: string) => {
    const photo: RoutinePhoto = {
      id: `photo-${Date.now()}`,
      dataUrl,
      capturedAt: new Date().toISOString(),
    };
    setPhotosMap((prev) => ({
      ...prev,
      [itemId]: [...(prev[itemId] || []), photo],
    }));
  };

  const handleDeletePhoto = (itemId: string, photoId: string) => {
    setPhotosMap((prev) => {
      const remaining = (prev[itemId] || []).filter((p) => p.id !== photoId);
      const next = { ...prev };
      if (remaining.length === 0) {
        delete next[itemId];
      } else {
        next[itemId] = remaining;
      }
      return next;
    });
  };

  const countByCategory = (cat: RoutineCategory) => {
    const items = allItems.filter((i) => i.category === cat);
    const done = items.filter((i) => checkedMap[i.id]).length;
    return { done, total: items.length };
  };

  const totalDone = allItems.filter((i) => checkedMap[i.id]).length;
  const totalCount = allItems.length;
  const overallPct = totalCount > 0 ? Math.round((totalDone / totalCount) * 100) : 0;

  const morningStats = countByCategory('morning');
  const progressStats = countByCategory('progress');
  const safetyStats = countByCategory('safety');

  const visibleItems = allItems.filter((i) => filter === 'all' || i.category === filter);

  const categoryLabel = (cat: RoutineCategory) => {
    if (cat === 'morning') return lang === 'hi' ? 'सुबह के कार्य' : 'Morning Task';
    if (cat === 'progress') return lang === 'hi' ? 'प्रगति व क्वालिटी' : 'Progress & QC';
    return lang === 'hi' ? 'सेफ्टी व PPE' : 'Safety & PPE';
  };

  return (
    <section className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-6">
      {/* Header & Overall Progress */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div className="space-y-1">
          <div className="text-xs font-semibold text-blue-700">
            {lang === 'hi' ? 'दुबई / UAE डेली साइट रूटीन चेकलिस्ट' : 'Dubai / UAE Daily Site Routine Tracker'}
          </div>
          <h3 className="text-xl font-extrabold text-slate-900">
            {lang === 'hi'
              ? 'सुबह का काम, साइट प्रगति और सेफ्टी चेकलिस्ट'
              : 'Daily Site Routine: Morning Tasks, Progress & Safety Checks'}
          </h3>
          <p className="text-xs sm:text-sm text-slate-600">
            {lang === 'hi'
              ? 'हर काम पूरा होने पर टिक करें — आपका डेटा ब्राउज़र में सुरक्षित रहता है।'
              : 'Tap each checklist item as you complete your shift checks — progress saves automatically.'}
            {lastSavedAt && (
              <span className="ml-1.5 font-mono-num text-xs text-slate-500">
                · {lang === 'hi' ? 'सेव किया गया:' : 'Saved'}{' '}
                {new Date(lastSavedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            )}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="px-4 py-2.5 rounded-xl bg-blue-50 border border-blue-200">
            <div className="text-[11px] font-medium text-blue-800">
              {lang === 'hi' ? 'आज की कुल प्रगति' : 'Shift Completion'}
            </div>
            <div className="text-xl font-extrabold font-mono-num text-blue-950">
              {totalDone} / {totalCount} ({overallPct}%)
            </div>
          </div>

          <button
            onClick={handleResetAll}
            className="h-11 px-4 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <RotateCcw className="w-4 h-4" />
            <span>{lang === 'hi' ? 'चेकलिस्ट रीसेट करें' : 'Reset Shift'}</span>
          </button>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="space-y-2">
        <div className="w-full h-3 rounded-full bg-slate-100 overflow-hidden border border-slate-200">
          <div
            className="h-full bg-blue-700 transition-all duration-300"
            style={{ width: `${overallPct}%` }}
          />
        </div>

        {/* 3-Column Category Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          <button
            onClick={() => setFilter(filter === 'morning' ? 'all' : 'morning')}
            className={`p-3.5 rounded-xl border text-left transition-colors flex items-center justify-between gap-3 min-h-[60px] ${
              filter === 'morning'
                ? 'bg-blue-700 border-blue-800 text-white'
                : 'bg-slate-50 border-slate-200 hover:border-blue-400 text-slate-900'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Sun className={`w-5 h-5 shrink-0 ${filter === 'morning' ? 'text-white' : 'text-blue-700'}`} />
              <div>
                <div className="text-xs font-bold">{lang === 'hi' ? 'सुबह का काम' : 'Morning Task List'}</div>
                <div className={`text-[11px] ${filter === 'morning' ? 'text-blue-100' : 'text-slate-500'}`}>
                  Drawings · Tools · TBT
                </div>
              </div>
            </div>
            <span className="font-mono-num text-sm font-extrabold">
              {morningStats.done}/{morningStats.total}
            </span>
          </button>

          <button
            onClick={() => setFilter(filter === 'progress' ? 'all' : 'progress')}
            className={`p-3.5 rounded-xl border text-left transition-colors flex items-center justify-between gap-3 min-h-[60px] ${
              filter === 'progress'
                ? 'bg-blue-700 border-blue-800 text-white'
                : 'bg-slate-50 border-slate-200 hover:border-blue-400 text-slate-900'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <ClipboardCheck className={`w-5 h-5 shrink-0 ${filter === 'progress' ? 'text-white' : 'text-blue-700'}`} />
              <div>
                <div className="text-xs font-bold">{lang === 'hi' ? 'प्रगति व टेस्टिंग' : 'Site Progress & QC'}</div>
                <div className={`text-[11px] ${filter === 'progress' ? 'text-blue-100' : 'text-slate-500'}`}>
                  Slope · 10 Bar · Capping
                </div>
              </div>
            </div>
            <span className="font-mono-num text-sm font-extrabold">
              {progressStats.done}/{progressStats.total}
            </span>
          </button>

          <button
            onClick={() => setFilter(filter === 'safety' ? 'all' : 'safety')}
            className={`p-3.5 rounded-xl border text-left transition-colors flex items-center justify-between gap-3 min-h-[60px] ${
              filter === 'safety'
                ? 'bg-blue-700 border-blue-800 text-white'
                : 'bg-slate-50 border-slate-200 hover:border-blue-400 text-slate-900'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <ShieldCheck className={`w-5 h-5 shrink-0 ${filter === 'safety' ? 'text-white' : 'text-emerald-700'}`} />
              <div>
                <div className="text-xs font-bold">{lang === 'hi' ? 'सेफ्टी और PPE' : 'Safety & PPE Checks'}</div>
                <div className={`text-[11px] ${filter === 'safety' ? 'text-blue-100' : 'text-slate-500'}`}>
                  PPE · 260°C · Chemical
                </div>
              </div>
            </div>
            <span className="font-mono-num text-sm font-extrabold">
              {safetyStats.done}/{safetyStats.total}
            </span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-1.5 p-1 bg-slate-100 rounded-xl border border-slate-200">
          {(
            [
              { id: 'all', label: lang === 'hi' ? 'सभी (All)' : 'All Checks' },
              { id: 'morning', label: lang === 'hi' ? 'सुबह के कार्य' : 'Morning Tasks' },
              { id: 'progress', label: lang === 'hi' ? 'प्रगति व क्वालिटी' : 'Progress & QC' },
              { id: 'safety', label: lang === 'hi' ? 'सेफ्टी व PPE' : 'Safety Checks' },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 min-h-[38px] ${
                filter === tab.id ? 'bg-blue-700 text-white' : 'text-slate-700 hover:bg-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {storageWarning && (
        <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900">
          {lang === 'hi'
            ? 'ब्राउज़र स्टोरेज भर गया है। नई फोटो सेव करने के लिए कुछ पुरानी साइट फोटो हटाएं।'
            : 'Browser storage limit reached. Delete an older site photo to save additional photos.'}
        </div>
      )}

      {/* Checklist Rows */}
      <div className="divide-y divide-slate-200 border border-slate-200 rounded-2xl overflow-hidden">
        {visibleItems.map((item) => {
          const isChecked = !!checkedMap[item.id];
          const itemPhotos = photosMap[item.id] || [];
          const displayTitle = lang === 'hi' ? item.title.hi : item.title.en;

          return (
            <div
              key={item.id}
              className={`p-4 space-y-3 transition-colors ${
                isChecked ? 'bg-emerald-50/50' : 'bg-white hover:bg-slate-50'
              }`}
            >
              <div className="flex items-start gap-3">
                <button
                  onClick={() => toggleItem(item.id)}
                  className="flex-1 text-left flex items-start gap-3.5 min-h-[44px]"
                  aria-pressed={isChecked}
                >
                  <span className="mt-0.5 shrink-0">
                    {isChecked ? (
                      <CheckSquare className="w-6 h-6 text-emerald-600" />
                    ) : (
                      <Square className="w-6 h-6 text-slate-400" />
                    )}
                  </span>
                  <div className="min-w-0 flex-1 space-y-1">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                      <span className="font-mono-num font-semibold text-blue-700">{item.timeTag}</span>
                      <span aria-hidden="true">·</span>
                      <span>{categoryLabel(item.category)}</span>
                      {itemPhotos.length > 0 && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono-num font-medium text-blue-700">
                            {itemPhotos.length} {itemPhotos.length === 1 ? 'Photo' : 'Photos'}
                          </span>
                        </>
                      )}
                      {isChecked && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-semibold text-emerald-700">
                            {lang === 'hi' ? 'पूरा हुआ' : 'Completed'}
                          </span>
                        </>
                      )}
                    </div>
                    <div
                      className={`font-bold text-sm sm:text-base ${
                        isChecked ? 'line-through text-slate-500' : 'text-slate-900'
                      }`}
                    >
                      {displayTitle}
                    </div>
                    {lang === 'both' && (
                      <div className={`text-xs sm:text-sm font-medium ${isChecked ? 'text-slate-400' : 'text-blue-700'}`}>
                        {item.title.hi}
                      </div>
                    )}
                    <BiTextBlock
                      text={item.detail}
                      lang={lang}
                      className="text-xs sm:text-sm text-slate-600 leading-relaxed"
                      hiClassName="text-xs text-slate-500"
                    />
                  </div>
                </button>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => setCameraTarget(item)}
                    className="h-10 px-3 rounded-xl border border-blue-200 bg-blue-50 hover:bg-blue-700 hover:text-white text-blue-800 text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
                  >
                    <Camera className="w-4 h-4" />
                    <span className="hidden sm:inline">
                      {lang === 'hi' ? 'फोटो लें' : 'Take Site Photo'}
                    </span>
                  </button>

                  {item.isCustom && (
                    <button
                      onClick={() => removeCustom(item.id)}
                      aria-label="Remove custom task"
                      className="w-10 h-10 rounded-xl text-slate-400 hover:text-red-600 hover:bg-red-50 flex items-center justify-center shrink-0"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Attached Site Photos Strip */}
              {itemPhotos.length > 0 && (
                <div className="pl-9 flex flex-wrap gap-2.5">
                  {itemPhotos.map((photo) => (
                    <div
                      key={photo.id}
                      className="relative group rounded-xl border border-slate-200 bg-white overflow-hidden w-24 h-20 shrink-0"
                    >
                      <button
                        type="button"
                        onClick={() => setPreviewPhoto({ photo, title: displayTitle })}
                        className="w-full h-full block"
                        title="View site photo"
                      >
                        <img
                          src={photo.dataUrl}
                          alt={`Site photo for ${displayTitle}`}
                          className="w-full h-full object-cover"
                        />
                        <span className="absolute bottom-0 left-0 right-0 bg-slate-950/70 text-[10px] font-mono-num text-white px-1.5 py-0.5 text-left truncate">
                          {new Date(photo.capturedAt).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeletePhoto(item.id, photo.id)}
                        aria-label="Delete photo"
                        className="absolute top-1 right-1 w-6 h-6 rounded-full bg-slate-950/75 hover:bg-red-600 text-white flex items-center justify-center"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Add Custom Daily Task Form */}
      <form
        onSubmit={handleAddCustom}
        className="bg-slate-50 border border-slate-200 rounded-2xl p-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-3"
      >
        <input
          type="text"
          value={newTaskText}
          onChange={(e) => setNewTaskText(e.target.value)}
          placeholder={
            lang === 'hi'
              ? 'आज का नया साइट काम जोड़ें (जैसे: फ्लोर 4 बाथरूम प्रेशर टेस्ट)...'
              : 'Add today’s custom site task (e.g., Villa 12 Bath 2 — 10 Bar IR check)...'
          }
          className="flex-1 h-11 px-3.5 rounded-xl border border-slate-300 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
        />
        <select
          value={newTaskCategory}
          onChange={(e) => setNewTaskCategory(e.target.value as RoutineCategory)}
          className="h-11 px-3 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-600"
        >
          <option value="morning">{lang === 'hi' ? 'सुबह का काम' : 'Morning Task'}</option>
          <option value="progress">{lang === 'hi' ? 'प्रगति व क्वालिटी' : 'Progress & QC'}</option>
          <option value="safety">{lang === 'hi' ? 'सेफ्टी व PPE' : 'Safety Check'}</option>
        </select>
        <button
          type="submit"
          disabled={!newTaskText.trim()}
          className="h-11 px-4 rounded-xl bg-blue-700 hover:bg-blue-800 disabled:opacity-50 text-white text-xs font-semibold flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>{lang === 'hi' ? 'काम जोड़ें' : 'Add Task'}</span>
        </button>
      </form>

      {/* Camera Capture Modal */}
      {cameraTarget && (
        <SiteCameraModal
          taskTitle={lang === 'hi' ? cameraTarget.title.hi : cameraTarget.title.en}
          lang={lang}
          onSavePhoto={(dataUrl) => handleAttachPhoto(cameraTarget.id, dataUrl)}
          onClose={() => setCameraTarget(null)}
        />
      )}

      {/* Full-size Photo Lightbox */}
      {previewPhoto && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          onClick={() => setPreviewPhoto(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-2xl w-full overflow-hidden border border-slate-200 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="text-xs font-mono-num text-blue-700">
                  {new Date(previewPhoto.photo.capturedAt).toLocaleString()}
                </div>
                <div className="text-sm font-bold text-slate-900 truncate">{previewPhoto.title}</div>
              </div>
              <button
                type="button"
                onClick={() => setPreviewPhoto(null)}
                aria-label="Close photo preview"
                className="w-10 h-10 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-100 flex items-center justify-center shrink-0"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <img
              src={previewPhoto.photo.dataUrl}
              alt={previewPhoto.title}
              className="w-full max-h-[75vh] object-contain bg-slate-950"
            />
          </div>
        </div>
      )}
    </section>
  );
};
