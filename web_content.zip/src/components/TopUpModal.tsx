import React, { useState } from 'react';
import { ArrowDownLeft, X, Wallet, PiggyBank, CreditCard, AlertCircle, ChevronRight } from 'lucide-react';
import { PAYMENT_PROVIDERS } from '../data/mockData';
import { PaymentProvider, Transaction } from '../types';
import { formatNumber, generateRefCode, getCurrentWibTime } from '../utils/formatters';

interface TopUpModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRequestPin: (amount: number, onAuthorize: () => void) => void;
  onSuccessTopUp: (transaction: Transaction) => void;
}

const PRESET_AMOUNTS = [20000, 50000, 100000, 200000, 500000];

export const TopUpModal: React.FC<TopUpModalProps> = ({
  isOpen,
  onClose,
  onRequestPin,
  onSuccessTopUp,
}) => {
  const [selectedProvider, setSelectedProvider] = useState<PaymentProvider>(PAYMENT_PROVIDERS[0]);
  const [accountNumber, setAccountNumber] = useState<string>(PAYMENT_PROVIDERS[0].accountExample);
  const [accountOwnerName, setAccountOwnerName] = useState<string>('Orang Tua Siswa (Bpk. Bambang)');
  const [amount, setAmount] = useState<number>(50000);
  const [customAmountStr, setCustomAmountStr] = useState<string>('50000');
  const [destination, setDestination] = useState<'wallet' | 'savings'>('wallet');
  const [note, setNote] = useState<string>('Top up uang jajan sekolah');
  const [validationError, setValidationError] = useState<string>('');

  if (!isOpen) return null;

  const handleProviderSelect = (provider: PaymentProvider) => {
    setSelectedProvider(provider);
    setAccountNumber(provider.accountExample);
    setValidationError('');
  };

  const handleAmountChipClick = (val: number) => {
    setAmount(val);
    setCustomAmountStr(val.toString());
    setValidationError('');
  };

  const handleCustomAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawVal = e.target.value.replace(/\D/g, '');
    setCustomAmountStr(rawVal);
    const num = Number(rawVal);
    setAmount(num);
    setValidationError('');
  };

  const handleProceed = () => {
    // Validate account number (Required by user prompt: "harus menginput no rekening atau no gopay atau dana")
    if (!accountNumber || accountNumber.trim().length < 8) {
      setValidationError(
        `Wajib mengisi ${selectedProvider.accountTypeLabel} (minimal 8 digit).`
      );
      return;
    }

    if (!amount || amount < 10000) {
      setValidationError('Nominal top up minimal Rp 10.000');
      return;
    }

    if (amount > 10000000) {
      setValidationError('Maksimal top up sekali transaksi adalah Rp 10.000.000');
      return;
    }

    // Trigger PIN authorization
    onRequestPin(amount, () => {
      const newTx: Transaction = {
        id: `TXN-${Date.now().toString().slice(-7)}`,
        type: 'topup',
        title: `Top Up dari ${selectedProvider.name}`,
        category: 'topup',
        amount: amount,
        sourceAccount: `${accountNumber.trim()} (${selectedProvider.name})`,
        paymentMethodName: selectedProvider.name,
        timestamp: getCurrentWibTime(),
        status: 'success',
        referenceCode: generateRefCode(selectedProvider.logoText),
        destination: destination,
        note: note.trim() || `Top up via ${selectedProvider.name}`,
      };

      onSuccessTopUp(newTx);
      onClose();
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-6">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-700 px-6 pt-6 pb-5 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <ArrowDownLeft className="w-5 h-5 text-white" />
              </div>
              <h2 className="text-lg font-bold">Isi Saldo (Top Up)</h2>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-full transition-colors"
              aria-label="Tutup"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <p className="text-xs text-emerald-100 mt-2 leading-relaxed">
            Isi saldo dompet harian atau tabungan sekolah dengan memasukkan nomor rekening bank atau nomor e-wallet GoPay/DANA.
          </p>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {validationError && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs font-semibold text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
              <span>{validationError}</span>
            </div>
          )}

          {/* 1. Pilih Sumber Pembayaran (Bank / E-Wallet) */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-2">
              1. Pilih Metode & Sumber Pembayaran
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {PAYMENT_PROVIDERS.map((provider) => {
                const isSelected = selectedProvider.id === provider.id;
                return (
                  <button
                    key={provider.id}
                    type="button"
                    onClick={() => handleProviderSelect(provider)}
                    className={`p-2.5 rounded-xl border text-left transition-all relative ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50/50 shadow-sm ring-1 ring-emerald-500'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-mono font-bold tracking-wider px-1.5 py-0.5 rounded bg-slate-100 text-slate-700">
                        {provider.logoText}
                      </span>
                      {isSelected && (
                        <span className="w-2 h-2 rounded-full bg-emerald-600" />
                      )}
                    </div>
                    <p className="text-xs font-bold text-slate-900 truncate">{provider.name}</p>
                    <span className="text-[10px] text-slate-500 capitalize">
                      {provider.type === 'ewallet' ? 'E-Wallet' : 'Transfer Bank'}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. Input Nomor Rekening atau Nomor GoPay / DANA */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
            <div className="flex items-center gap-2 text-slate-800">
              <CreditCard className="w-4 h-4 text-emerald-600" />
              <label className="text-xs font-bold">
                2. Input {selectedProvider.accountTypeLabel} <span className="text-rose-500">*</span>
              </label>
            </div>

            <div>
              <input
                type="text"
                required
                value={accountNumber}
                onChange={(e) => {
                  setAccountNumber(e.target.value);
                  setValidationError('');
                }}
                placeholder={selectedProvider.placeholder}
                className="w-full px-3 py-2.5 bg-white border border-slate-300 rounded-xl text-sm font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                Harap masukkan nomor rekening atau nomor HP akun pengirim yang valid untuk verifikasi dana.
              </p>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                Nama Pemilik Rekening / Akun (Opsional)
              </label>
              <input
                type="text"
                value={accountOwnerName}
                onChange={(e) => setAccountOwnerName(e.target.value)}
                placeholder="Contoh: Orang Tua Siswa (Bpk. Bambang)"
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* 3. Tujuan Saldo: Dompet Harian vs Tabungan Siswa */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-2">
              3. Pilih Tujuan Penyimpanan Saldo
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setDestination('wallet')}
                className={`p-3 rounded-2xl border text-left transition-all ${
                  destination === 'wallet'
                    ? 'border-emerald-600 bg-emerald-50/70 shadow-sm ring-1 ring-emerald-500'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
                    <Wallet className="w-4 h-4" />
                  </div>
                  <span className="text-xs font-bold text-slate-900">Dompet Saku</span>
                </div>
                <p className="text-[11px] text-slate-500 leading-tight">
                  Uang saku harian untuk jajan kantin, fotokopi, & kas kelas.
                </p>
              </button>

              <button
                type="button"
                onClick={() => setDestination('savings')}
                className={`p-3 rounded-2xl border text-left transition-all ${
                  destination === 'savings'
                    ? 'border-indigo-600 bg-indigo-50/70 shadow-sm ring-1 ring-indigo-500'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <div className="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center">
                    <PiggyBank className="w-4 h-4" />
                  </div>
                  <span className="text-xs font-bold text-slate-900">Tabungan Siswa</span>
                </div>
                <p className="text-[11px] text-slate-500 leading-tight">
                  Tersimpan di celengan dan langsung menaikkan peringkat Leaderboard!
                </p>
              </button>
            </div>
          </div>

          {/* 4. Nominal Top Up */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-2">
              4. Masukkan Nominal Top Up
            </label>

            <div className="relative mb-3">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500 font-bold text-sm">
                Rp
              </div>
              <input
                type="text"
                value={formatNumber(amount)}
                onChange={handleCustomAmountChange}
                placeholder="0"
                className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-lg font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              />
            </div>

            {/* Quick Chips */}
            <div className="flex flex-wrap gap-2">
              {PRESET_AMOUNTS.map((preset) => (
                <button
                  type="button"
                  key={preset}
                  onClick={() => handleAmountChipClick(preset)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold font-mono transition-colors ${
                    amount === preset
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  +{formatNumber(preset)}
                </button>
              ))}
            </div>
          </div>

          {/* 5. Catatan */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Catatan Transaksi (Opsional)
            </label>
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Contoh: Uang saku dari Ibu / Tabungan bulanan"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        {/* Footer / CTA */}
        <div className="p-6 bg-slate-50 border-t border-slate-100 flex items-center justify-between gap-4">
          <div>
            <span className="text-[11px] text-slate-500 block">Total Pembayaran</span>
            <span className="text-base font-extrabold text-slate-900 font-mono">
              {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(
                amount || 0
              )}
            </span>
          </div>

          <button
            type="button"
            onClick={handleProceed}
            className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs font-bold rounded-2xl shadow-lg shadow-emerald-600/20 transition-all flex items-center gap-1.5"
          >
            <span>Lanjutkan Top Up</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
