"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useCart } from "@/lib/cart-context";
import { formatBDT } from "@/lib/utils";

export default function ProductActions({
  product,
}: {
  product: {
    id: number;
    name: string;
    modelNumber: string;
    price: number;
    image: string;
    colors: string[];
    status: string;
  };
}) {
  const { addToCart } = useCart();
  const router = useRouter();
  const [quantity, setQuantity] = useState(1);
  const [color, setColor] = useState(product.colors[0] || "Midnight Black");
  const [added, setAdded] = useState(false);
  const available = product.status === "available";

  const handleAdd = () => {
    addToCart({
      productId: product.id,
      name: product.name,
      modelNumber: product.modelNumber,
      price: product.price,
      image: product.image,
      quantity,
      color,
    });
    setAdded(true);
    setTimeout(() => setAdded(false), 1600);
  };

  const handleOrderNow = () => {
    addToCart({
      productId: product.id,
      name: product.name,
      modelNumber: product.modelNumber,
      price: product.price,
      image: product.image,
      quantity,
      color,
    });
    router.push("/cart");
  };

  return (
    <div className="space-y-5">
      <div>
        <p className="text-sm font-semibold uppercase tracking-widest text-slate-400">Price</p>
        <p className="mt-1 font-display text-4xl font-black text-white">{formatBDT(product.price)}</p>
        <p className="text-xs text-slate-500">BDT · Inclusive of all taxes · Free delivery in Dhaka</p>
      </div>

      {product.colors.length > 0 && (
        <div>
          <p className="mb-2 text-sm font-semibold text-slate-300">Available Colors</p>
          <div className="flex flex-wrap gap-2">
            {product.colors.map((c) => (
              <button
                key={c}
                onClick={() => setColor(c)}
                className={`rounded-full border px-4 py-1.5 text-sm transition ${
                  color === c
                    ? "border-purple-400 bg-purple-500/20 text-purple-200"
                    : "border-white/10 bg-white/5 text-slate-300 hover:border-white/30"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="flex items-center gap-4">
        <p className="text-sm font-semibold text-slate-300">Quantity</p>
        <div className="flex items-center overflow-hidden rounded-xl border border-white/15">
          <button
            onClick={() => setQuantity((q) => Math.max(1, q - 1))}
            className="px-4 py-2 text-lg text-slate-300 transition hover:bg-white/10"
          >
            −
          </button>
          <span className="w-12 border-x border-white/15 py-2 text-center font-mono font-bold text-white">
            {quantity}
          </span>
          <button
            onClick={() => setQuantity((q) => Math.min(99, q + 1))}
            className="px-4 py-2 text-lg text-slate-300 transition hover:bg-white/10"
          >
            +
          </button>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <button
          onClick={handleAdd}
          disabled={!available}
          className={`rounded-2xl border py-3.5 font-bold transition ${
            available
              ? "border-purple-400/50 bg-white/5 text-purple-200 hover:bg-purple-500/20"
              : "cursor-not-allowed border-white/5 text-slate-600"
          }`}
        >
          {added ? "✓ Added to Cart" : "Add to Cart"}
        </button>
        <button
          onClick={handleOrderNow}
          disabled={!available}
          className={`rounded-2xl py-3.5 font-bold text-white transition ${
            available
              ? "bg-gradient-to-r from-purple-500 to-blue-600 shadow-[0_0_24px_rgba(139,92,246,0.5)] hover:brightness-110"
              : "cursor-not-allowed bg-white/5 text-slate-600"
          }`}
        >
          Order Now
        </button>
      </div>

      {!available && (
        <p className="rounded-xl border border-amber-400/30 bg-amber-500/10 p-3 text-sm text-amber-300">
          This model is currently {product.status === "pre_order" ? "available for pre-order only." : "out of stock."}
        </p>
      )}

      <div className="grid grid-cols-3 gap-2 text-center text-xs text-slate-400">
        <div className="rounded-xl border border-white/5 bg-white/[0.03] p-3">
          <p className="text-lg">🚚</p>
          <p>Fast Delivery</p>
        </div>
        <div className="rounded-xl border border-white/5 bg-white/[0.03] p-3">
          <p className="text-lg">🛡️</p>
          <p>1 Year Warranty</p>
        </div>
        <div className="rounded-xl border border-white/5 bg-white/[0.03] p-3">
          <p className="text-lg">💳</p>
          <p>Cash on Delivery</p>
        </div>
      </div>
    </div>
  );
}