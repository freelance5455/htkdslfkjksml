"use client";

import React, { useState, useEffect, useCallback } from "react";
import {
  CoinTechnicalAnalysis,
  OHLCVCandle,
  formatPriceNumber,
} from "@/services/technicalEngine";
import {
  nvidiaNimService,
  NvidiaNimAnalysisResponse,
} from "@/services/nvidiaNimService";
import {
  Eye,
  Sparkles,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  Target,
  ShieldAlert,
  Cpu,
  CheckCircle2,
} from "lucide-react";

interface NvidiaNimVisionPanelProps {
  coins: CoinTechnicalAnalysis[];
  selectedSymbol: string;
  candles: OHLCVCandle[];
  onSelectSymbol: (symbol: string) => void;
  onExecuteNimDemoTrade: (coin: CoinTechnicalAnalysis) => void;
}

export function NvidiaNimVisionPanel({
  coins,
  selectedSymbol,
  candles,
  onSelectSymbol,
  onExecuteNimDemoTrade,
}: NvidiaNimVisionPanelProps) {
  const safeCoins = Array.isArray(coins) ? coins : [];
  const activeCoin =
    safeCoins.find((c) => c.symbol === selectedSymbol) || safeCoins[0];

  const [nimResult, setNimResult] = useState<NvidiaNimAnalysisResponse | null>(
    null
  );
  const [analyzing, setAnalyzing] = useState<boolean>(false);

  const triggerNimAnalysis = useCallback(async () => {
    if (!activeCoin) return;
    setAnalyzing(true);
    try {
      const result = await nvidiaNimService.analyzeCoinWithNim(
        activeCoin,
        candles
      );
      setNimResult(result);
    } finally {
      setAnalyzing(false);
    }
  }, [activeCoin, candles]);

  useEffect(() => {
    triggerNimAnalysis();
  }, [triggerNimAnalysis]);

  if (!activeCoin) return null;

  const isLong = activeCoin.recommendation === "LONG";
  const isShort = activeCoin.recommendation === "SHORT";

  return (
    <div
      dir="rtl"
      className="rounded-xl border border-[#00E676]/40 bg-gradient-to-b from-[#11161F] to-[#0B0E14] p-5 shadow-xl"
    >
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#222B3A] pb-4">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#00E676]/15 text-[#00E676]">
            <Eye className="h-6 w-6" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-base font-bold text-[#F1F5F9] sm:text-lg">
                מוח מסחר NVIDIA NIM: נימוקי LLM וראיית גרפים ממוחשבת (Chart Vision)
              </h3>
              <span className="rounded-full bg-[#00E676]/20 px-2.5 py-0.5 font-mono text-[11px] font-bold text-[#00E676]">
                llama-nemotron-embed-vl
              </span>
              <span className="rounded-full bg-[#3B82F6]/20 px-2.5 py-0.5 font-mono text-[11px] font-bold text-[#3B82F6]">
                nemotron-graphic-elements
              </span>
            </div>
            <p className="mt-0.5 text-xs text-[#94A3B8]">
              חיבור ל-`https://integrate.api.nvidia.com/v1` לזיהוי תבניות נרות
              (ראש וכתפיים, דגל שורי/דובי, סטיות RSI) ונימוקי עומק בעברית, עם גיבוי
              מתמטי אוטומטי מלא.
            </p>
          </div>
        </div>

        {/* Symbol Switcher & Re-Analyze Trigger */}
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={activeCoin.symbol}
            onChange={(e) => onSelectSymbol(e.target.value)}
            className="rounded-lg border border-[#222B3A] bg-[#0B0E14] px-3 py-2 font-mono text-xs font-bold text-[#F1F5F9] focus:border-[#00E676] focus:outline-none"
          >
            {safeCoins.map((c) => (
              <option key={c.symbol} value={c.symbol}>
                {c.symbol} — ${formatPriceNumber(c.currentPrice)}
              </option>
            ))}
          </select>

          <button
            type="button"
            disabled={analyzing}
            onClick={triggerNimAnalysis}
            className="inline-flex items-center gap-2 rounded-lg bg-[#3B82F6] px-4 py-2 text-xs font-bold text-white transition hover:bg-[#2563EB]"
          >
            <RefreshCw
              className={`h-4 w-4 ${analyzing ? "animate-spin" : ""}`}
            />
            <span>נתח גרף ונימוקי NIM מחדש</span>
          </button>
        </div>
      </div>

      {/* Main Content Split: LLM Reasoning & Trade Advice (7 cols) + Chart Vision Pattern Recognition (5 cols) */}
      <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-12">
        {/* Left/Right Main Reasoning Card (7 cols) */}
        <div className="lg:col-span-7 flex flex-col justify-between rounded-xl border border-[#222B3A] bg-[#11161F] p-4">
          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-[#00E676]" />
                <span className="text-sm font-bold text-[#F1F5F9]">
                  נימוק אסטרטגי ממונע NVIDIA Nemotron-70B:
                </span>
              </div>
              <span className="font-mono text-[11px] text-[#94A3B8]">
                ספק:{" "}
                <strong className="text-[#00E676]">
                  {nimResult?.provider === "NVIDIA_NIM_CLOUD_API"
                    ? "NVIDIA NIM Cloud API"
                    : "NVIDIA NIM Hybrid Engine"}
                </strong>{" "}
                ({nimResult?.latencyMs || 24}ms)
              </span>
            </div>

            {/* AI Reasoning Paragraph */}
            <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3.5 text-xs leading-relaxed text-[#E2E8F0]">
              {nimResult?.nimReasoningHe ||
                "מנתח מבנה נרות ואינדיקטורים טכניים באמצעות מודל NVIDIA NIM..."}
            </div>

            {/* Secondary Market Commentary */}
            <p className="text-xs leading-relaxed text-[#94A3B8]">
              {nimResult?.marketCommentaryHe}
            </p>

            {/* Trade Advice Targets Strip */}
            <div className="grid grid-cols-2 gap-2.5 rounded-lg bg-[#0B0E14] p-3 sm:grid-cols-4 font-mono text-xs">
              <div>
                <span className="block font-sans text-[10px] text-[#64748B]">
                  המלצת NIM AI
                </span>
                <strong
                  className={
                    isLong
                      ? "text-[#00E676]"
                      : isShort
                      ? "text-[#FF3B69]"
                      : "text-[#F59E0B]"
                  }
                >
                  {activeCoin.recommendationLabelHe}
                </strong>
              </div>
              <div>
                <span className="block font-sans text-[10px] text-[#64748B]">
                  מחיר כניסה מדויק
                </span>
                <strong className="text-[#F1F5F9]">
                  ${formatPriceNumber(activeCoin.entryPrice)}
                </strong>
              </div>
              <div>
                <span className="block font-sans text-[10px] text-[#00E676]">
                  יעד רווח (TP1 / TP2)
                </span>
                <strong className="text-[#00E676]">
                  ${formatPriceNumber(activeCoin.takeProfit1)}
                </strong>
              </div>
              <div>
                <span className="block font-sans text-[10px] text-[#FF3B69]">
                  קטיעת הפסד (Stop-Loss)
                </span>
                <strong className="text-[#FF3B69]">
                  ${formatPriceNumber(activeCoin.stopLoss)}
                </strong>
              </div>
            </div>
          </div>

          {/* 1-Click Execute in Demo Button */}
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-[#222B3A] pt-3">
            <div className="text-xs text-[#94A3B8]">
              <strong className="text-[#3B82F6]">בכמה לסחור (Kelly):</strong>{" "}
              {activeCoin.kellySizing.positionPctOfBalance}% מהתיק ($
              {activeCoin.kellySizing.marginSizeUsdt}) במינוף{" "}
              {activeCoin.kellySizing.recommendedLeverage}x
            </div>
            <button
              type="button"
              onClick={() => onExecuteNimDemoTrade(activeCoin)}
              className="inline-flex items-center gap-2 rounded-lg bg-[#00E676] px-5 py-2.5 text-xs font-extrabold text-[#0B0E14] transition hover:brightness-110"
            >
              {isShort ? (
                <TrendingDown className="h-4 w-4" />
              ) : (
                <TrendingUp className="h-4 w-4" />
              )}
              <span>
                בצע בעסקת דמו על {activeCoin.symbol} ($
                {activeCoin.kellySizing.marginSizeUsdt})
              </span>
            </button>
          </div>
        </div>

        {/* Right Card: Multimodal Chart Vision Detected Patterns (5 cols) */}
        <div className="lg:col-span-5 flex flex-col justify-between rounded-xl border border-[#222B3A] bg-[#11161F] p-4">
          <div>
            <div className="mb-3 flex items-center justify-between border-b border-[#222B3A] pb-2.5">
              <div className="flex items-center gap-2">
                <Cpu className="h-4 w-4 text-[#3B82F6]" />
                <span className="text-sm font-bold text-[#F1F5F9]">
                  זיהוי תבניות גרף (`nemotron-graphic-elements`)
                </span>
              </div>
              <span className="font-mono text-[11px] text-[#00E676]">
                סריקת 200 נרות
              </span>
            </div>

            <div className="space-y-2.5">
              {(Array.isArray(nimResult?.detectedPatterns)
                ? nimResult.detectedPatterns
                : []
              ).map((pat, idx) => (
                <div
                  key={pat.patternCode + "-" + idx}
                  className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 font-bold text-[#F1F5F9]">
                      <CheckCircle2
                        className={`h-4 w-4 ${
                          pat.direction === "BULLISH"
                            ? "text-[#00E676]"
                            : "text-[#FF3B69]"
                        }`}
                      />
                      <span>{pat.nameHe}</span>
                    </div>
                    <span className="rounded bg-[#3B82F6]/20 px-2 py-0.5 font-mono text-[11px] font-bold text-[#3B82F6]">
                      ביטחון {pat.confidencePct}%
                    </span>
                  </div>
                  <p className="mt-1.5 text-[11px] leading-relaxed text-[#94A3B8]">
                    {pat.descriptionHe}
                  </p>
                  <div className="mt-2 flex items-center justify-between border-t border-[#222B3A]/60 pt-1.5 font-mono text-[11px]">
                    <span className="flex items-center gap-1 text-[#00E676]">
                      <Target className="h-3 w-3" />
                      יעד תבנית: ${formatPriceNumber(pat.targetPrice)}
                    </span>
                    <span className="flex items-center gap-1 text-[#FF3B69]">
                      <ShieldAlert className="h-3 w-3" />
                      פסילת תבנית: ${formatPriceNumber(pat.invalidationPrice)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
