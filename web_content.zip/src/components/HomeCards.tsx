import React, { useState } from 'react';
import {
  Mic,
  Camera,
  RotateCcw,
  KeyRound,
  ScanLine,
  Sparkles,
  AlertCircle,
} from 'lucide-react';
import { CameraState, SessionState } from '../types';

interface HomeCardsProps {
  sessionState: SessionState;
  cameraState: CameraState;
  hasApiKey: boolean;
  volumeLevel: number;
  onToggleSession: () => void;
  onOpenScanner: () => void;
  onRequestReset: () => void;
  onOpenSettings: () => void;
}

export const HomeCards: React.FC<HomeCardsProps> = ({
  sessionState,
  cameraState,
  hasApiKey,
  volumeLevel,
  onToggleSession,
  onOpenScanner,
  onRequestReset,
  onOpenSettings,
}) => {
  const isConnected = sessionState === 'LISTENING' || sessionState === 'SPEAKING';
  const isSpeaking = sessionState === 'SPEAKING';
  const isListening = sessionState === 'LISTENING';
  const isConnecting = sessionState === 'CONNECTING';
  const isCameraActive = cameraState === 'CAMERA_ACTIVE';

  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);
  const [apiKeyNotice, setApiKeyNotice] = useState<string | null>(null);

  const handleStartClick = () => {
    if (!hasApiKey) {
      setApiKeyNotice('Please add and save your Gemini API key in Settings first.');
      setTimeout(() => {
        setApiKeyNotice(null);
        onOpenSettings();
      }, 1200);
    } else {
      setApiKeyNotice(null);
      onToggleSession();
    }
  };

  const handleResetClick = () => {
    setIsResetConfirmOpen(true);
  };

  const handleConfirmReset = () => {
    setIsResetConfirmOpen(false);
    onRequestReset();
  };

  return (
    <div className="w-full max-w-md mx-auto px-4 pb-4 select-none relative">
      {/* Temporary API Key alert toast if clicked without key */}
      {apiKeyNotice && (
        <div className="absolute -top-10 left-4 right-4 z-40 bg-amber-500/90 text-black font-semibold text-xs py-2 px-3 rounded-xl flex items-center justify-center space-x-2 shadow-xl animate-fade-in">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{apiKeyNotice}</span>
        </div>
      )}

      {/* Cards Row: Sitting / START Card + Camera Card + Small Reset Button */}
      <div className="flex items-stretch space-x-2.5 sm:space-x-3">
        {/* ============================================================== */}
        {/* 1. SITTING / START SECTION                                     */}
        {/* ============================================================== */}
        <button
          onClick={handleStartClick}
          className={`flex-1 relative p-3 sm:p-3.5 rounded-2xl glass-panel text-left flex flex-col justify-between overflow-hidden transition-all duration-300 active:scale-[0.98] group ${
            isConnected
              ? 'border-purple-500/60 shadow-[0_0_25px_rgba(168,85,247,0.3)] bg-[#131733]/90'
              : 'border-purple-500/25 hover:border-purple-500/50 bg-[#0d1226]/85'
          }`}
        >
          {/* Ambient glow */}
          <div className="absolute -top-6 -right-6 w-20 h-20 bg-purple-600/20 rounded-full blur-xl pointer-events-none" />

          {/* Top section: Mic Orb & Status */}
          <div className="flex items-center justify-between w-full mb-2">
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
                isSpeaking
                  ? 'bg-gradient-to-br from-pink-500 to-purple-600 text-white shadow-[0_0_14px_rgba(236,72,153,0.7)] animate-pulse'
                  : isListening
                  ? 'bg-gradient-to-br from-purple-500 to-indigo-600 text-white shadow-[0_0_14px_rgba(139,92,246,0.6)]'
                  : 'bg-purple-900/40 text-purple-300 group-hover:text-white border border-purple-500/30'
              }`}
            >
              {isConnecting ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <Mic className="w-4 h-4" />
              )}
            </div>

            {/* Status dot */}
            <div className="flex items-center space-x-1 px-2 py-0.5 rounded-full bg-black/50 border border-white/5 text-[10px]">
              <span
                className={`w-1.5 h-1.5 rounded-full ${
                  isSpeaking
                    ? 'bg-pink-400 animate-ping'
                    : isListening
                    ? 'bg-cyan-400 animate-pulse'
                    : !hasApiKey
                    ? 'bg-amber-400'
                    : 'bg-slate-400'
                }`}
              />
              <span className="text-slate-300 font-medium">
                {isConnecting
                  ? 'Connecting'
                  : isSpeaking
                  ? 'Speaking'
                  : isListening
                  ? 'Listening'
                  : isConnected
                  ? 'Active'
                  : 'Ready'}
              </span>
            </div>
          </div>

          {/* Dynamic Audio Waves */}
          <div className="flex items-center space-x-1 h-3.5 my-1.5">
            {[0.3, 0.7, 1.0, 0.6, 0.9, 0.4, 0.8].map((h, i) => {
              const activeHeight = isConnected
                ? Math.max(0.2, Math.min(1.0, h * (0.3 + volumeLevel * 2)))
                : 0.2;
              return (
                <span
                  key={i}
                  className={`w-1 rounded-full transition-all duration-75 ${
                    isSpeaking
                      ? 'bg-gradient-to-t from-pink-500 to-purple-400 shadow-[0_0_4px_#ec4899]'
                      : isListening
                      ? 'bg-gradient-to-t from-cyan-400 to-blue-400 shadow-[0_0_4px_#06b6d4]'
                      : 'bg-slate-700'
                  }`}
                  style={{ height: `${Math.round(activeHeight * 14)}px` }}
                />
              );
            })}
          </div>

          {/* Title & Subtext */}
          <div className="mt-1">
            <h3 className="text-xs sm:text-sm font-bold text-white tracking-wide flex items-center space-x-1.5">
              <span>START</span>
              <span className="text-[10px] text-purple-400">• Sitting</span>
            </h3>
            <p className="text-[10px] text-slate-400 font-medium truncate mt-0.5">
              {isConnected ? 'Tap to end session' : 'Live Voice Session'}
            </p>
          </div>
        </button>

        {/* ============================================================== */}
        {/* 2. REALISTIC CAMERA SECTION (NOT A BLACK BOX)                  */}
        {/* ============================================================== */}
        <button
          onClick={onOpenScanner}
          className={`flex-1 relative p-3 sm:p-3.5 rounded-2xl glass-panel text-left flex flex-col justify-between overflow-hidden transition-all duration-300 active:scale-[0.98] group ${
            isCameraActive
              ? 'border-emerald-500/60 bg-[#0b1f24]/90 shadow-[0_0_25px_rgba(16,185,129,0.3)]'
              : 'border-cyan-500/30 hover:border-cyan-500/50 bg-[#081529]/85'
          }`}
        >
          {/* Subtle realistic lens glass gradient & grid reflection */}
          <div className="absolute inset-0 opacity-20 pointer-events-none bg-[radial-gradient(#06b6d4_1px,transparent_1px)] [background-size:8px_8px]" />
          <div className="absolute -bottom-6 -left-6 w-20 h-20 bg-cyan-500/20 rounded-full blur-xl pointer-events-none" />

          {/* Top section: Camera Lens Iris & Status */}
          <div className="flex items-center justify-between w-full mb-2">
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all relative ${
                isCameraActive
                  ? 'bg-gradient-to-br from-emerald-500 to-cyan-600 text-white shadow-[0_0_14px_rgba(16,185,129,0.7)]'
                  : 'bg-cyan-950/60 text-cyan-300 group-hover:text-white border border-cyan-500/40 shadow-[inset_0_0_8px_rgba(6,182,212,0.3)]'
              }`}
            >
              <Camera className="w-4 h-4" />
              {/* Concentric aperture ring */}
              <div className="absolute inset-1 rounded-lg border border-cyan-400/30 pointer-events-none" />
            </div>

            {/* Status dot */}
            <div className="flex items-center space-x-1 px-2 py-0.5 rounded-full bg-black/50 border border-white/5 text-[10px]">
              <span
                className={`w-1.5 h-1.5 rounded-full ${
                  isCameraActive
                    ? 'bg-emerald-400 animate-pulse'
                    : 'bg-cyan-400'
                }`}
              />
              <span className="text-slate-300 font-medium">
                {isCameraActive ? 'Active' : 'Standby'}
              </span>
            </div>
          </div>

          {/* Professional Viewfinder Style Preview Frame */}
          <div className="relative w-full h-5 rounded-lg bg-black/50 border border-cyan-500/30 flex items-center justify-between px-2 my-1 overflow-hidden">
            {/* Viewfinder corner ticks */}
            <span className="text-[9px] text-cyan-400 font-mono font-bold leading-none">[</span>
            <div className="flex items-center space-x-1.5 text-[9px] text-cyan-300 font-mono">
              <ScanLine className="w-3 h-3 text-cyan-400 animate-pulse" />
              <span className="tracking-wider text-[8px] uppercase">
                {isCameraActive ? 'LIVE FEED' : 'TAP TO SCAN'}
              </span>
            </div>
            <span className="text-[9px] text-cyan-400 font-mono font-bold leading-none">]</span>

            {/* Shimmer sweep */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-400/15 to-transparent animate-pulse" />
          </div>

          {/* Title & Subtext */}
          <div className="mt-1">
            <h3 className="text-xs sm:text-sm font-bold text-white tracking-wide flex items-center space-x-1.5">
              <span>Camera</span>
              <span className="text-[10px] text-cyan-400">• Vision</span>
            </h3>
            <p className="text-[10px] text-slate-400 font-medium truncate mt-0.5">
              Palm Scanner Guided
            </p>
          </div>
        </button>

        {/* ============================================================== */}
        {/* 3. SMALL REFRESH / RESET ICON BUTTON (Start Fresh)             */}
        {/* ============================================================== */}
        <div className="flex items-center">
          <button
            onClick={handleResetClick}
            title="Start Fresh (Reset Session)"
            className="h-full px-3 py-2.5 rounded-2xl glass-panel border border-slate-700/60 hover:border-purple-500/50 hover:text-purple-300 text-slate-400 flex flex-col items-center justify-center space-y-1 transition-all duration-200 active:scale-95 group shadow-md"
          >
            <RotateCcw className="w-4 h-4 group-hover:rotate-[-60deg] transition-transform duration-300 text-slate-300 group-hover:text-purple-300" />
            <span className="text-[9px] font-semibold tracking-wider uppercase text-slate-400 group-hover:text-purple-200">
              Fresh
            </span>
          </button>
        </div>
      </div>

      {/* Confirmation Dialog for Reset */}
      {isResetConfirmOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-5 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-xs p-5 rounded-3xl glass-panel border border-purple-500/40 text-center shadow-2xl space-y-3">
            <div className="w-10 h-10 rounded-full bg-purple-900/40 border border-purple-500/50 text-purple-300 flex items-center justify-center mx-auto">
              <RotateCcw className="w-5 h-5" />
            </div>

            <h3 className="text-sm font-bold text-white">Start Fresh?</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Reset current conversation and palm session context.
              <br />
              <span className="text-emerald-400 font-medium text-[11px] block mt-1">
                ✓ Your saved Gemini API key will NOT be deleted.
              </span>
            </p>

            <div className="flex items-center space-x-2 pt-2">
              <button
                onClick={() => setIsResetConfirmOpen(false)}
                className="flex-1 py-2.5 rounded-xl glass-panel text-xs text-slate-300 hover:text-white font-medium transition active:scale-95"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmReset}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold text-xs shadow-lg shadow-purple-500/30 transition active:scale-95"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
