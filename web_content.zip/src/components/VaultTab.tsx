import React from 'react';
import { AlertOctagon, PlayCircle, Trash2, CheckCircle2, ChevronRight } from 'lucide-react';
import { MistakeItem, WordData } from '../types';

interface VaultTabProps {
  mistakes: MistakeItem[];
  words: WordData[];
  onStartDrill: () => void;
  onClearVault: () => void;
  onDismissItem: (word: string) => void;
  onOpenWordDetail: (word: WordData) => void;
}

export const VaultTab: React.FC<VaultTabProps> = ({
  mistakes,
  words,
  onStartDrill,
  onClearVault,
  onDismissItem,
  onOpenWordDetail,
}) => {
  const getWordObj = (wordName: string) => {
    return words.find(w => w.word.toLowerCase() === wordName.toLowerCase());
  };

  return (
    <div className="flex-1 smooth-scroll p-4 space-y-3 pb-28 max-w-md mx-auto w-full">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-rose-700 to-red-800 text-white rounded-3xl p-4 shadow-[0_4px_0_0_#991b1b] space-y-1">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-black flex items-center gap-2">
            <AlertOctagon className="w-5 h-5 text-amber-300" /> Mistakes Vault
          </h2>
          <span className="bg-white/20 text-xs px-2.5 py-0.5 rounded-full font-bold">
            {mistakes.length} Weak Words
          </span>
        </div>
        <p className="text-xs text-rose-100 font-bengali">
          কুইজে বা ফ্ল্যাশকার্ডে যে শব্দগুলো ভুল করেছেন তার তালিকা। পুনরায় অনুশীলন করে দুর্বলতা দূর করুন।
        </p>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center gap-2">
        <button
          onClick={onStartDrill}
          disabled={mistakes.length === 0}
          className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow-[0_3px_0_0_#e11d48] flex items-center justify-center gap-1.5 transition-all active:translate-y-0.5"
        >
          <PlayCircle className="w-4 h-4" /> Drill Weak Words Now
        </button>

        <button
          onClick={onClearVault}
          disabled={mistakes.length === 0}
          className="px-3 py-2.5 border border-slate-300 dark:border-slate-700 disabled:opacity-40 text-slate-500 font-bold text-xs rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-all flex items-center gap-1"
        >
          <Trash2 className="w-3.5 h-3.5" /> Clear
        </button>
      </div>

      {/* Mistakes List */}
      <div className="space-y-2 pt-1">
        {mistakes.length === 0 ? (
          <div className="p-8 text-center text-slate-400 space-y-2 bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 rounded-3xl">
            <CheckCircle2 className="w-10 h-10 mx-auto text-emerald-500" />
            <h4 className="font-bold text-sm text-slate-700 dark:text-slate-200">
              No Weakness Recorded
            </h4>
            <p className="text-xs font-bengali">
              আপনি এখনও কোনো শব্দ ভুল করেননি। কুইজ বা ডিটেক্টিভ গেমে ভুল হলে এখানে জমা হবে।
            </p>
          </div>
        ) : (
          mistakes.map((m) => {
            const wordObj = getWordObj(m.word);

            return (
              <div
                key={m.word}
                className="bg-white dark:bg-[#111827] border-2 border-rose-100 dark:border-rose-950/60 rounded-2xl p-3.5 shadow-sm space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="font-black text-sm text-rose-600 dark:text-rose-400">
                      {m.word}
                    </span>
                    <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-rose-50 dark:bg-rose-950 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
                      {m.category}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {m.timestamp}
                  </span>
                </div>

                <div className="text-xs space-y-1">
                  <div className="text-rose-600 font-medium">
                    &times; আপনার ভুল উত্তর: <strong>{m.wrongAns}</strong>
                  </div>
                  <div className="text-emerald-700 dark:text-emerald-400 font-bold">
                    &check; সঠিক উত্তর: <strong>{m.correctAns}</strong>
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  {wordObj && (
                    <button
                      onClick={() => onOpenWordDetail(wordObj)}
                      className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 text-xs font-bold flex items-center gap-1"
                    >
                      Review Dossier <ChevronRight className="w-3 h-3" />
                    </button>
                  )}

                  <button
                    onClick={() => onDismissItem(m.word)}
                    className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-400 hover:text-emerald-600 dark:hover:text-emerald-400 text-xs font-bold transition-colors"
                  >
                    Mark Resolved
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

    </div>
  );
};
