import React, { useState } from 'react';
import {
  Smartphone,
  Share2,
  Download,
  CheckCircle2,
  Zap,
  Maximize2,
  Check,
  MoreVertical,
  PlusSquare,
  ArrowUpRight,
  Copy,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { useApp } from '../../context/AppContext';
import { triggerCelebration } from '../../utils/confetti';

export const InstallGuideCard: React.FC = () => {
  const { t, language } = useApp();
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [activePlatform, setActivePlatform] = useState<'android' | 'ios'>(isIOS ? 'ios' : 'android');
  const [installedNotice, setInstalledNotice] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const isBn = language === 'bn';

  const handleInstallClick = async () => {
    const success = await install();
    if (success) {
      triggerCelebration(0.6);
      setInstalledNotice(true);
      setTimeout(() => setInstalledNotice(false), 4000);
    }
  };

  const handleCopyLink = () => {
    try {
      const urlToCopy = window.location.href;
      navigator.clipboard.writeText(urlToCopy);
      setCopiedLink(true);
      triggerCelebration(0.7);
      setTimeout(() => setCopiedLink(false), 3000);
    } catch {
      // fallback
    }
  };

  const handleOpenDirect = () => {
    window.open(window.location.href, '_blank');
  };

  return (
    <section className="bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xs transition-colors space-y-5">
      {/* Header with App Logo and Badges */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3.5">
          <img
            src="/icon.svg"
            alt="Habivio App Icon"
            className="w-13 h-13 rounded-2xl shadow-md ring-2 ring-violet-500/20 shrink-0"
          />
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {t.installGuideTitle}
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-violet-100 dark:bg-violet-950/80 text-violet-700 dark:text-violet-300 text-[10px] font-bold">
                PWA Native
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {t.installGuideSubtitle}
            </p>
          </div>
        </div>

        {/* Already installed badge or install button */}
        {isInstalled ? (
          <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 text-xs font-semibold">
            <CheckCircle2 size={15} />
            <span>{isBn ? 'ইনস্টল সম্পন্ন' : 'Installed as App'}</span>
          </div>
        ) : isInstallable ? (
          <button
            onClick={handleInstallClick}
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-xs font-bold shadow-md shadow-violet-500/20 active:scale-95 transition-all shrink-0"
          >
            <Download size={15} />
            <span>{t.installNowButton}</span>
          </button>
        ) : null}
      </div>

      {installedNotice && (
        <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs font-semibold text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
          <Check size={16} />
          <span>
            {isBn
              ? 'অভিনন্দন! হাবিভিও সফলভাবে আপনার ডিভাইসে ইনস্টল হয়েছে।'
              : 'Congratulations! Habivio has been installed to your home screen.'}
          </span>
        </div>
      )}

      {/* Direct Link Action Bar for Mobile Browsers */}
      <div className="p-3.5 rounded-2xl bg-linear-to-r from-violet-500/10 via-indigo-500/10 to-sky-500/10 border border-violet-500/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="min-w-0">
          <span className="text-xs font-bold text-slate-900 dark:text-white block">
            {isBn ? 'মোবাইল Chrome-এ সরাসরি খোলার লিঙ্ক' : 'Direct Link to Open in Mobile Chrome'}
          </span>
          <span className="text-[11px] text-slate-500 dark:text-slate-400 block truncate">
            {isBn ? 'লিঙ্কটি কপি করে ফোনে Chrome ব্রাউজারে খুলুন' : 'Copy link and paste directly into Google Chrome'}
          </span>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto shrink-0">
          <button
            onClick={handleCopyLink}
            className={`flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all active:scale-95 ${
              copiedLink
                ? 'bg-emerald-600 text-white'
                : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:border-violet-400'
            }`}
          >
            {copiedLink ? <Check size={14} /> : <Copy size={14} />}
            <span>{copiedLink ? (isBn ? 'কপি হয়েছে!' : 'Copied!') : (isBn ? 'লিঙ্ক কপি করুন' : 'Copy Link')}</span>
          </button>

          <button
            onClick={handleOpenDirect}
            className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-violet-400 transition-colors"
            title={isBn ? 'নতুন ট্যাবে খুলুন' : 'Open in new tab'}
          >
            <ExternalLink size={14} />
          </button>
        </div>
      </div>

      {/* Benefits pills */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
        <div className="flex items-center gap-2 p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60 text-xs">
          <div className="p-1.5 rounded-lg bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-400 shrink-0">
            <Zap size={14} />
          </div>
          <span className="text-slate-700 dark:text-slate-300 font-medium">
            {t.installBenefitOffline}
          </span>
        </div>

        <div className="flex items-center gap-2 p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60 text-xs">
          <div className="p-1.5 rounded-lg bg-sky-100 dark:bg-sky-950 text-sky-600 dark:text-sky-400 shrink-0">
            <Maximize2 size={14} />
          </div>
          <span className="text-slate-700 dark:text-slate-300 font-medium">
            {t.installBenefitNoUrl}
          </span>
        </div>

        <div className="flex items-center gap-2 p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60 text-xs">
          <div className="p-1.5 rounded-lg bg-violet-100 dark:bg-violet-950 text-violet-600 dark:text-violet-400 shrink-0">
            <Smartphone size={14} />
          </div>
          <span className="text-slate-700 dark:text-slate-300 font-medium">
            {t.installBenefitNotifications}
          </span>
        </div>
      </div>

      {/* Platform Switcher Tabs */}
      <div>
        <div className="flex p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 mb-4 text-xs font-bold">
          <button
            onClick={() => setActivePlatform('android')}
            className={`flex-1 py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-2 ${
              activePlatform === 'android'
                ? 'bg-white dark:bg-slate-700 text-violet-600 dark:text-violet-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Smartphone size={15} />
            <span>{t.installGuideAndroidTab}</span>
          </button>

          <button
            onClick={() => setActivePlatform('ios')}
            className={`flex-1 py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-2 ${
              activePlatform === 'ios'
                ? 'bg-white dark:bg-slate-700 text-violet-600 dark:text-violet-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Share2 size={15} />
            <span>{t.installGuideIOSTab}</span>
          </button>
        </div>

        {/* ANDROID (Chrome) STEP-BY-STEP */}
        {activePlatform === 'android' && (
          <div className="space-y-3">
            {/* Step 1 */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200/70 dark:border-slate-800 flex items-start gap-3.5 transition-all hover:border-violet-300 dark:hover:border-violet-700">
              <div className="w-7 h-7 rounded-full bg-violet-600 text-white font-extrabold text-xs flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                1
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                    {t.installAndroidStep1Title}
                  </h4>
                  <span className="p-1 rounded-md bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200">
                    <MoreVertical size={12} />
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                  {t.installAndroidStep1Desc}
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200/70 dark:border-slate-800 flex items-start gap-3.5 transition-all hover:border-violet-300 dark:hover:border-violet-700">
              <div className="w-7 h-7 rounded-full bg-violet-600 text-white font-extrabold text-xs flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                2
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                    {t.installAndroidStep2Title}
                  </h4>
                  <span className="p-1 rounded-md bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200">
                    <Download size={12} />
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                  {t.installAndroidStep2Desc}
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200/70 dark:border-slate-800 flex items-start gap-3.5 transition-all hover:border-violet-300 dark:hover:border-violet-700">
              <div className="w-7 h-7 rounded-full bg-violet-600 text-white font-extrabold text-xs flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                3
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                    {t.installAndroidStep3Title}
                  </h4>
                  <span className="p-1 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400">
                    <CheckCircle2 size={12} />
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                  {t.installAndroidStep3Desc}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* iOS (Safari) STEP-BY-STEP */}
        {activePlatform === 'ios' && (
          <div className="space-y-3">
            {/* Step 1 */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200/70 dark:border-slate-800 flex items-start gap-3.5 transition-all hover:border-violet-300 dark:hover:border-violet-700">
              <div className="w-7 h-7 rounded-full bg-indigo-600 text-white font-extrabold text-xs flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                1
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                    {t.installIOSStep1Title}
                  </h4>
                  <span className="p-1 rounded-md bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200">
                    <ArrowUpRight size={12} />
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                  {t.installIOSStep1Desc}
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200/70 dark:border-slate-800 flex items-start gap-3.5 transition-all hover:border-violet-300 dark:hover:border-violet-700">
              <div className="w-7 h-7 rounded-full bg-indigo-600 text-white font-extrabold text-xs flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                2
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                    {t.installIOSStep2Title}
                  </h4>
                  <span className="p-1 rounded-md bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200">
                    <PlusSquare size={12} />
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                  {t.installIOSStep2Desc}
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200/70 dark:border-slate-800 flex items-start gap-3.5 transition-all hover:border-violet-300 dark:hover:border-violet-700">
              <div className="w-7 h-7 rounded-full bg-indigo-600 text-white font-extrabold text-xs flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                3
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                    {t.installIOSStep3Title}
                  </h4>
                  <span className="p-1 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400">
                    <CheckCircle2 size={12} />
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                  {t.installIOSStep3Desc}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
