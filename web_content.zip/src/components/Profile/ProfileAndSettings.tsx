import React, { useState, useRef, useEffect } from 'react';
import {
  User,
  Moon,
  Sun,
  Globe,
  Download,
  Upload,
  RotateCcw,
  Trash2,
  Check,
  Target,
  Sparkles,
  ShieldCheck,
  Bell,
  Heart,
  Volume2,
  Square,
  AlertTriangle,
  Camera,
  Image as ImageIcon,
  Plus,
  Minus,
  Edit2,
  Link as LinkIcon,
  ChevronDown,
  ChevronUp,
  Lock,
  Smartphone,
  Play,
  Music,
  CheckCircle2,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ConfirmationModal } from '../ConfirmationModal';
import { InstallGuideCard } from './InstallGuideCard';
import { AndroidAlarmSettingsModal } from '../Alarm/AndroidAlarmSettingsModal';
import { startAlarmSound, stopAlarmSound } from '../../utils/alarmAudio';
import {
  SOUND_LIBRARY,
  getSelectedTone,
  setSelectedTone,
  previewRingtone,
  stopRingtonePreview,
  isRingtonePreviewing,
  stopAllAlarms,
  playTaskCompletionSound,
  isCompletionSoundEnabled,
  setCompletionSoundEnabled,
  getCompletionSoundTone,
  setCompletionSoundTone,
  CompletionToneType,
} from '../../utils/audioManager';

const PRESET_AVATARS = [
  {
    id: 'avatar-1',
    label: 'Executive (Default)',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
  },
  {
    id: 'avatar-2',
    label: 'Professional Male',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
  },
  {
    id: 'avatar-3',
    label: 'Modest / Hijab Portrait',
    url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
  },
  {
    id: 'avatar-4',
    label: 'Executive Professional',
    url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
  },
  {
    id: 'avatar-5',
    label: 'Thoughtful Scholar',
    url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&auto=format&fit=crop&q=80',
  },
  {
    id: 'avatar-6',
    label: 'Minimalist Silhouette',
    url: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80',
  },
  {
    id: 'avatar-7',
    label: 'Modern 3D Aesthetic',
    url: 'https://images.unsplash.com/photo-1628157582853-a796fa650a6a?w=200&auto=format&fit=crop&q=80',
  },
  {
    id: 'avatar-8',
    label: 'Warm Modern Portrait',
    url: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=200&auto=format&fit=crop&q=80',
  },
];

interface ProfileAndSettingsProps {
  onOpenInstallModal?: () => void;
  onTestLockScreenAlarm?: () => void;
}

export const ProfileAndSettings: React.FC<ProfileAndSettingsProps> = ({
  onOpenInstallModal,
  onTestLockScreenAlarm,
}) => {
  const {
    profile,
    updateProfile,
    language,
    setLanguage,
    theme,
    toggleTheme,
    exportData,
    importData,
    clearAllData,
    resetToDefaultData,
    t,
    notificationStatus,
    requestNotificationPermission,
    setActiveTab,
  } = useApp();

  const [name, setName] = useState(profile.name);
  const [avatar, setAvatar] = useState(profile.avatar);
  const [title, setTitle] = useState(profile.title);
  const [dailyTaskTarget, setDailyTaskTarget] = useState(profile.dailyTaskTarget);
  const [dailyHabitTarget, setDailyHabitTarget] = useState(profile.dailyHabitTarget);
  const [dailyQuranPagesTarget, setDailyQuranPagesTarget] = useState(profile.dailyQuranPagesTarget);

  const [isAvatarPickerOpen, setIsAvatarPickerOpen] = useState(false);
  const [customAvatarUrl, setCustomAvatarUrl] = useState('');
  const [avatarTab, setAvatarTab] = useState<'presets' | 'upload' | 'url'>('presets');

  const [isSavedMessage, setIsSavedMessage] = useState(false);
  const [isClearModalOpen, setIsClearModalOpen] = useState(false);
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const [statusFeedback, setStatusFeedback] = useState<string | null>(null);
  const [isTestingAlarm, setIsTestingAlarm] = useState(false);
  const [isAndroidAlarmModalOpen, setIsAndroidAlarmModalOpen] = useState(false);
  const [selectedDefaultTone, setSelectedDefaultTone] = useState<string>(() => getSelectedTone());
  const [activePreviewTone, setActivePreviewTone] = useState<string | null>(null);
  const [completionSoundOn, setCompletionSoundOn] = useState<boolean>(() => isCompletionSoundEnabled());
  const [completionStyle, setCompletionStyle] = useState<CompletionToneType>(() => getCompletionSoundTone());
  const [isTestingCompletion, setIsTestingCompletion] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const avatarUploadInputRef = useRef<HTMLInputElement>(null);

  // Sync state if external profile updates
  useEffect(() => {
    setName(profile.name);
    setAvatar(profile.avatar);
    setTitle(profile.title);
    setDailyTaskTarget(profile.dailyTaskTarget);
    setDailyHabitTarget(profile.dailyHabitTarget);
    setDailyQuranPagesTarget(profile.dailyQuranPagesTarget);
  }, [profile]);

  // Clean up any ongoing preview sounds on unmount and keep UI in sync with audio manager
  useEffect(() => {
    const handlePreviewStopped = () => {
      setActivePreviewTone(null);
    };
    window.addEventListener('habivio:preview-stopped', handlePreviewStopped);
    return () => {
      window.removeEventListener('habivio:preview-stopped', handlePreviewStopped);
      stopRingtonePreview();
      stopAllAlarms();
    };
  }, []);

  const handleToggleAlarmTest = () => {
    if (isTestingAlarm) {
      stopAlarmSound();
      setIsTestingAlarm(false);
    } else {
      startAlarmSound();
      setIsTestingAlarm(true);
      setTimeout(() => {
        stopAlarmSound();
        setIsTestingAlarm(false);
      }, 4000);
    }
  };

  const handlePreviewTone = (toneId: string) => {
    if (activePreviewTone === toneId && isRingtonePreviewing(toneId)) {
      stopRingtonePreview();
      setActivePreviewTone(null);
    } else {
      stopRingtonePreview();
      previewRingtone(toneId);
      setActivePreviewTone(toneId);
    }
  };

  const handleStopAllSoundPreviews = () => {
    stopRingtonePreview();
    stopAllAlarms();
    setActivePreviewTone(null);
    setIsTestingAlarm(false);
  };

  const handleSetDefaultTone = (toneId: string) => {
    setSelectedTone(toneId);
    setSelectedDefaultTone(toneId);
    setStatusFeedback(
      language === 'bn'
        ? 'ডিফল্ট অ্যালার্ম সাউন্ড সেট করা হয়েছে।'
        : 'Default alarm tone updated successfully.'
    );
    setTimeout(() => setStatusFeedback(null), 3000);
  };

  const handleToggleCompletionSound = (enabled: boolean) => {
    setCompletionSoundOn(enabled);
    setCompletionSoundEnabled(enabled);
    if (enabled) {
      playTaskCompletionSound(completionStyle);
    }
  };

  const handleChangeCompletionStyle = (style: CompletionToneType) => {
    setCompletionStyle(style);
    setCompletionSoundTone(style);
    playTaskCompletionSound(style);
  };

  const handleTestCompletion = (style: CompletionToneType) => {
    setIsTestingCompletion(style);
    playTaskCompletionSound(style);
    setTimeout(() => setIsTestingCompletion(null), 1200);
  };

  const handleAvatarFileSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new window.Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxDim = 256;
        let width = img.width;
        let height = img.height;
        if (width > height) {
          if (width > maxDim) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          }
        } else {
          if (height > maxDim) {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.85);
          setAvatar(compressedDataUrl);
        } else {
          setAvatar(event.target?.result as string);
        }
        setStatusFeedback(language === 'bn' ? 'ছবি নির্বাচন করা হয়েছে!' : 'Photo selected!');
        setTimeout(() => setStatusFeedback(null), 2500);
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
    if (avatarUploadInputRef.current) {
      avatarUploadInputRef.current.value = '';
    }
  };

  const handleApplyCustomUrl = () => {
    if (customAvatarUrl.trim()) {
      setAvatar(customAvatarUrl.trim());
      setCustomAvatarUrl('');
      setStatusFeedback(language === 'bn' ? 'ছবির লিংক যুক্ত করা হয়েছে!' : 'Avatar link applied!');
      setTimeout(() => setStatusFeedback(null), 2500);
    }
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      name: name.trim() || profile.name,
      avatar: avatar.trim() || profile.avatar,
      title: title.trim() || profile.title,
      dailyTaskTarget: Math.max(1, Number(dailyTaskTarget) || 4),
      dailyHabitTarget: Math.max(1, Number(dailyHabitTarget) || 3),
      dailyQuranPagesTarget: Math.max(1, Number(dailyQuranPagesTarget) || 4),
    });
    setIsSavedMessage(true);
    setStatusFeedback(t.profileUpdated);
    setTimeout(() => {
      setIsSavedMessage(false);
      setStatusFeedback(null);
    }, 3000);
  };

  const handleExport = () => {
    const jsonStr = exportData();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `habivio-backup-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
    setStatusFeedback('Backup downloaded successfully!');
    setTimeout(() => setStatusFeedback(null), 3000);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const success = importData(content);
      if (success) {
        setStatusFeedback(t.importSuccess);
      } else {
        setStatusFeedback(t.importError);
      }
      setTimeout(() => setStatusFeedback(null), 3500);
    };
    reader.readAsText(file);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Title */}
      <div>
        <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
          {t.profileTitle}
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          {language === 'bn' 
            ? 'আপনার নাম, ছবি, পরিচয় এবং দৈনিক লক্ষ্যমাত্রা ব্যক্তিগতকরণ করুন' 
            : 'Personalize Habivio, manage profile photo, theme, language, and targets'}
        </p>
      </div>

      {statusFeedback && (
        <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs font-semibold text-emerald-800 dark:text-emerald-300 flex items-center gap-2 animate-in fade-in">
          <Check size={16} />
          <span>{statusFeedback}</span>
        </div>
      )}

      {/* Hidden file input for custom device photo upload */}
      <input
        ref={avatarUploadInputRef}
        type="file"
        accept="image/*"
        onChange={handleAvatarFileSelected}
        className="hidden"
      />

      {/* 1. Profile Information & Customization Card */}
      <section className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xs transition-colors">
        {/* Profile Header & Avatar Selector Trigger */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100 dark:border-slate-800/80">
          <div className="flex items-center gap-4">
            <div className="relative group">
              <img
                src={avatar || profile.avatar}
                alt={name || profile.name}
                className="w-18 h-18 sm:w-20 sm:h-20 rounded-3xl object-cover ring-3 ring-violet-500/30 group-hover:ring-violet-500 transition-all shadow-md bg-slate-100 dark:bg-slate-800"
              />
              <button
                type="button"
                onClick={() => setIsAvatarPickerOpen(!isAvatarPickerOpen)}
                className="absolute -bottom-1 -right-1 p-2 rounded-2xl bg-violet-600 hover:bg-violet-700 text-white shadow-md active:scale-90 transition-all border-2 border-white dark:border-slate-900"
                title={t.changeAvatar}
                aria-label={t.changeAvatar}
              >
                <Camera size={14} />
              </button>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">
                  {name || profile.name}
                </h3>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-medium">
                {title || profile.title}
              </p>
              <button
                type="button"
                onClick={() => setIsAvatarPickerOpen(!isAvatarPickerOpen)}
                className="mt-2 text-xs font-semibold text-violet-600 dark:text-violet-400 hover:text-violet-700 flex items-center gap-1 transition-colors"
              >
                <Camera size={13} />
                <span>{t.changeAvatar}</span>
                {isAvatarPickerOpen ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => avatarUploadInputRef.current?.click()}
              className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-violet-400 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-all active:scale-95 bg-slate-50/60 dark:bg-slate-800/60"
            >
              <Upload size={13} className="text-violet-500" />
              <span>{language === 'bn' ? 'ছবি আপলোড' : 'Upload Photo'}</span>
            </button>
          </div>
        </div>

        {/* Expandable Avatar Selection Box */}
        {isAvatarPickerOpen && (
          <div className="mt-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 space-y-3 animate-in fade-in">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                <ImageIcon size={14} className="text-violet-500" />
                <span>{t.changeAvatar}</span>
              </span>

              {/* Tabs */}
              <div className="flex items-center gap-1 bg-white dark:bg-slate-700 p-0.5 rounded-xl border border-slate-200 dark:border-slate-600">
                <button
                  type="button"
                  onClick={() => setAvatarTab('presets')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all ${
                    avatarTab === 'presets'
                      ? 'bg-violet-600 text-white'
                      : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {t.presetAvatars}
                </button>
                <button
                  type="button"
                  onClick={() => setAvatarTab('upload')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all ${
                    avatarTab === 'upload'
                      ? 'bg-violet-600 text-white'
                      : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {language === 'bn' ? 'আপলোড' : 'Upload'}
                </button>
                <button
                  type="button"
                  onClick={() => setAvatarTab('url')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all ${
                    avatarTab === 'url'
                      ? 'bg-violet-600 text-white'
                      : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {language === 'bn' ? 'লিংক' : 'URL'}
                </button>
              </div>
            </div>

            {/* Presets Grid */}
            {avatarTab === 'presets' && (
              <div className="grid grid-cols-4 sm:grid-cols-8 gap-2.5 pt-1">
                {PRESET_AVATARS.map((item) => {
                  const isSelected = avatar === item.url;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        setAvatar(item.url);
                        setStatusFeedback(language === 'bn' ? 'অবতার নির্বাচন করা হয়েছে!' : 'Avatar selected!');
                        setTimeout(() => setStatusFeedback(null), 2000);
                      }}
                      className={`relative rounded-2xl overflow-hidden aspect-square border-2 transition-all group focus:outline-hidden ${
                        isSelected
                          ? 'border-violet-600 ring-2 ring-violet-500/40 scale-105'
                          : 'border-transparent hover:border-slate-300 dark:hover:border-slate-600 opacity-80 hover:opacity-100'
                      }`}
                      title={item.label}
                    >
                      <img
                        src={item.url}
                        alt={item.label}
                        className="w-full h-full object-cover"
                      />
                      {isSelected && (
                        <div className="absolute inset-0 bg-violet-600/30 flex items-center justify-center">
                          <div className="w-5 h-5 rounded-full bg-violet-600 text-white flex items-center justify-center shadow-xs">
                            <Check size={12} strokeWidth={3} />
                          </div>
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            )}

            {/* Upload Option */}
            {avatarTab === 'upload' && (
              <div className="p-4 rounded-xl border border-dashed border-slate-300 dark:border-slate-600 bg-white/70 dark:bg-slate-900/40 text-center space-y-2">
                <Upload size={24} className="mx-auto text-violet-500" />
                <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                  {language === 'bn' 
                    ? 'আপনার ডিভাইস বা গ্যালারি থেকে ছবি নির্বাচন করুন' 
                    : 'Select a photo from your phone gallery or desktop'}
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  JPG, PNG, WebP (অটো কম্প্রেস হয়ে অফলাইনে সেভ থাকবে)
                </p>
                <button
                  type="button"
                  onClick={() => avatarUploadInputRef.current?.click()}
                  className="px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-xs font-bold transition-all shadow-xs active:scale-95 inline-flex items-center gap-1.5"
                >
                  <Upload size={14} />
                  <span>{t.uploadPhoto}</span>
                </button>
              </div>
            )}

            {/* Custom URL Option */}
            {avatarTab === 'url' && (
              <div className="space-y-2 pt-1">
                <div className="flex gap-2">
                  <input
                    type="url"
                    placeholder="https://example.com/my-photo.jpg"
                    value={customAvatarUrl}
                    onChange={(e) => setCustomAvatarUrl(e.target.value)}
                    className="flex-1 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-violet-500"
                  />
                  <button
                    type="button"
                    onClick={handleApplyCustomUrl}
                    className="px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-xs font-bold transition-all active:scale-95"
                  >
                    {language === 'bn' ? 'প্রয়োগ' : 'Apply'}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Profile Edit Form */}
        <form onSubmit={handleSaveProfile} className="space-y-4.5 mt-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
                {t.userName}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <User size={15} />
                </div>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={language === 'bn' ? 'আপনার নাম লিখুন' : 'Enter your name'}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-medium focus:outline-hidden focus:ring-2 focus:ring-violet-500 transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
                {t.userBio}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <Edit2 size={15} />
                </div>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder={language === 'bn' ? 'যেমন: সফটওয়্যার ইঞ্জিনিয়ার / শিক্ষার্থী' : 'e.g. Focused Professional'}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-medium focus:outline-hidden focus:ring-2 focus:ring-violet-500 transition-colors"
                />
              </div>
            </div>
          </div>

          {/* Daily Targets Preferences with Stepper Buttons */}
          <div className="pt-2">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
              <Target size={14} className="text-violet-500" />
              <span>{t.dailyTargets}</span>
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Tasks Target */}
              <div className="p-3 rounded-2xl bg-slate-50/80 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60">
                <span className="text-[11px] font-bold text-slate-600 dark:text-slate-400 block mb-2">
                  {t.targetTasks}
                </span>
                <div className="flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => setDailyTaskTarget((prev) => Math.max(1, prev - 1))}
                    className="w-8 h-8 rounded-lg bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 flex items-center justify-center text-slate-700 dark:text-slate-200 hover:border-violet-500 active:scale-90 transition-all"
                  >
                    <Minus size={13} />
                  </button>
                  <span className="text-base font-extrabold text-slate-900 dark:text-white font-mono">
                    {dailyTaskTarget}
                  </span>
                  <button
                    type="button"
                    onClick={() => setDailyTaskTarget((prev) => Math.min(25, prev + 1))}
                    className="w-8 h-8 rounded-lg bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 flex items-center justify-center text-slate-700 dark:text-slate-200 hover:border-violet-500 active:scale-90 transition-all"
                  >
                    <Plus size={13} />
                  </button>
                </div>
              </div>

              {/* Habits Target */}
              <div className="p-3 rounded-2xl bg-slate-50/80 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60">
                <span className="text-[11px] font-bold text-slate-600 dark:text-slate-400 block mb-2">
                  {t.targetHabits}
                </span>
                <div className="flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => setDailyHabitTarget((prev) => Math.max(1, prev - 1))}
                    className="w-8 h-8 rounded-lg bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 flex items-center justify-center text-slate-700 dark:text-slate-200 hover:border-violet-500 active:scale-90 transition-all"
                  >
                    <Minus size={13} />
                  </button>
                  <span className="text-base font-extrabold text-slate-900 dark:text-white font-mono">
                    {dailyHabitTarget}
                  </span>
                  <button
                    type="button"
                    onClick={() => setDailyHabitTarget((prev) => Math.min(25, prev + 1))}
                    className="w-8 h-8 rounded-lg bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 flex items-center justify-center text-slate-700 dark:text-slate-200 hover:border-violet-500 active:scale-90 transition-all"
                  >
                    <Plus size={13} />
                  </button>
                </div>
              </div>

              {/* Quran Pages Target */}
              <div className="p-3 rounded-2xl bg-slate-50/80 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60">
                <span className="text-[11px] font-bold text-slate-600 dark:text-slate-400 block mb-2">
                  {t.targetQuranPages}
                </span>
                <div className="flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => setDailyQuranPagesTarget((prev) => Math.max(1, prev - 1))}
                    className="w-8 h-8 rounded-lg bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 flex items-center justify-center text-slate-700 dark:text-slate-200 hover:border-violet-500 active:scale-90 transition-all"
                  >
                    <Minus size={13} />
                  </button>
                  <span className="text-base font-extrabold text-slate-900 dark:text-white font-mono">
                    {dailyQuranPagesTarget}
                  </span>
                  <button
                    type="button"
                    onClick={() => setDailyQuranPagesTarget((prev) => Math.min(60, prev + 1))}
                    className="w-8 h-8 rounded-lg bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 flex items-center justify-center text-slate-700 dark:text-slate-200 hover:border-violet-500 active:scale-90 transition-all"
                  >
                    <Plus size={13} />
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
            {isSavedMessage ? (
              <span className="text-xs text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1.5 animate-in fade-in">
                <Check size={15} />
                <span>{t.profileUpdated}</span>
              </span>
            ) : (
              <span className="text-[11px] text-slate-400">
                {language === 'bn' ? 'সব পরিবর্তন ডিভাইসে সংরক্ষিত থাকবে' : 'Changes are saved locally on this device'}
              </span>
            )}

            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-xs font-bold shadow-md hover:shadow-violet-500/20 active:scale-95 transition-all flex items-center gap-2"
            >
              <Check size={14} />
              <span>{t.saveChanges}</span>
            </button>
          </div>
        </form>
      </section>

      {/* 2. Language & Theme Settings */}
      <section className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-5 shadow-xs transition-colors space-y-4">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white">
          Preferences & Interface
        </h3>

        {/* Language Options */}
        <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-violet-100 dark:bg-violet-950/60 text-violet-600 dark:text-violet-400">
              <Globe size={18} />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                {t.languageSelect}
              </span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                {language === 'en' ? 'English (Current)' : 'বাংলা (বর্তমান)'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5 bg-white dark:bg-slate-700 p-1 rounded-xl border border-slate-200 dark:border-slate-600">
            <button
              onClick={() => setLanguage('en')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                language === 'en'
                  ? 'bg-violet-600 text-white'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              English
            </button>
            <button
              onClick={() => setLanguage('bn')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                language === 'bn'
                  ? 'bg-violet-600 text-white'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              বাংলা
            </button>
          </div>
        </div>

        {/* Theme Options */}
        <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400">
              {theme === 'dark' ? <Moon size={18} /> : <Sun size={18} />}
            </div>
            <div>
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                {t.themeSelect}
              </span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                {theme === 'dark' ? t.darkMode : t.lightMode}
              </span>
            </div>
          </div>

          <button
            onClick={toggleTheme}
            className="px-3.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2"
          >
            {theme === 'dark' ? <Sun size={14} className="text-amber-400" /> : <Moon size={14} className="text-violet-600" />}
            <span>{theme === 'dark' ? 'Light Mode' : 'Dark Mode'}</span>
          </button>
        </div>

        {/* Browser Notifications Permission */}
        <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-sky-100 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400">
              <Bell size={18} />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                Browser Notifications
              </span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                Status: {notificationStatus}
              </span>
            </div>
          </div>

          {notificationStatus !== 'granted' ? (
            <button
              onClick={requestNotificationPermission}
              className="px-3 py-1.5 rounded-xl bg-violet-600 text-white text-xs font-bold active:scale-95 transition-all"
            >
              Enable
            </button>
          ) : (
            <span className="text-xs text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
              <Check size={14} /> Active
            </span>
          )}
        </div>

        {/* Android Smart Alarm System (Redmi / Xiaomi, Exact Alarms, Hardware Buttons) */}
        <div className="p-4 rounded-3xl bg-linear-to-r from-indigo-950/70 via-slate-900 to-slate-900 border border-indigo-500/40 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                <Smartphone size={18} />
              </div>
              <div>
                <h4 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                  <span>{language === 'bn' ? 'অ্যান্ড্রয়েড স্মার্ট অ্যালার্ম ও রেডমি অপটিমাইজেশন' : 'Android Smart Alarm & Redmi System'}</span>
                  <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-500/20 text-emerald-300">
                    NATIVE
                  </span>
                </h4>
                <p className="text-[11px] text-slate-400">
                  {language === 'bn'
                    ? 'লক স্ক্রিন অ্যালার্ম, Exact Alarm পারমিশন, Autostart ও ভলিউম বাটন দিয়ে মিউট'
                    : 'Lock-screen alerts, AlarmManager, Autostart & Volume button silence'}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsAndroidAlarmModalOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-xs active:scale-95 transition-all cursor-pointer"
            >
              {language === 'bn' ? 'কনফিগার' : 'Configure'}
            </button>
          </div>
        </div>

        {/* Comprehensive Sound & Ringtone Management Studio */}
        <div className="p-4 rounded-3xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200/90 dark:border-slate-700/80 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-violet-100 dark:bg-violet-950/70 text-violet-600 dark:text-violet-400">
                <Volume2 size={18} />
              </div>
              <div>
                <h4 className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-wider">
                  {language === 'bn' ? 'রিংটোন ও সাউন্ড স্টুডিও' : 'Ringtones & Sound Studio'}
                </h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  {language === 'bn'
                    ? 'আলাদা আলাদা মিষ্টি সুর, পাখির গান, পানির শব্দ ও টাস্ক কমপ্লিট সাউন্ড'
                    : 'Independent nature sounds, birdsong, water streams & task chimes'}
                </p>
              </div>
            </div>

            {(activePreviewTone || isTestingAlarm) && (
              <button
                type="button"
                onClick={handleStopAllSoundPreviews}
                className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-1.5 animate-pulse shadow-xs active:scale-95 transition-all"
              >
                <Square size={12} className="fill-current" />
                <span>{language === 'bn' ? 'সব সাউন্ড বন্ধ' : 'Stop All'}</span>
              </button>
            )}
          </div>

          {/* Nature & Alarm Sounds List with Independent Previews */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-[11px] font-bold text-slate-600 dark:text-slate-300">
              <span>{language === 'bn' ? 'অ্যালার্মের সুরসমূহ (আলাদা আলাদা শুনুন ও বন্ধ করুন):' : 'Alarm Tones (Audition & Stop Individually):'}</span>
              <span className="text-violet-600 dark:text-violet-400">
                {language === 'bn' ? 'ডিফল্ট: ' : 'Default: '}
                {SOUND_LIBRARY.find((s) => s.id === selectedDefaultTone)?.nameBn || selectedDefaultTone}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-72 overflow-y-auto pr-1">
              {SOUND_LIBRARY.filter((s) => s.id !== 'silent' && s.id !== 'custom_audio').map((sound) => {
                const isPlayingThis = activePreviewTone === sound.id && isRingtonePreviewing(sound.id);
                const isDefault = selectedDefaultTone === sound.id;

                return (
                  <div
                    key={sound.id}
                    className={`p-3 rounded-2xl border transition-all flex items-center justify-between gap-2.5 ${
                      isPlayingThis
                        ? 'bg-violet-50 dark:bg-violet-950/60 border-violet-400 ring-2 ring-violet-400/30'
                        : isDefault
                        ? 'bg-white dark:bg-slate-800 border-violet-300 dark:border-violet-700 shadow-xs'
                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="text-base">{sound.icon}</span>
                        <span className="text-xs font-bold text-slate-800 dark:text-slate-100 truncate">
                          {language === 'bn' ? sound.nameBn : sound.nameEn}
                        </span>
                        {isDefault && (
                          <span className="px-1.5 py-0.2 rounded text-[9px] font-extrabold bg-violet-600 text-white shrink-0">
                            {language === 'bn' ? 'ডিফল্ট' : 'Default'}
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                        {language === 'bn' ? sound.descriptionBn : sound.descriptionEn}
                      </p>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {/* Play / Stop Button for this specific tone */}
                      <button
                        type="button"
                        onClick={() => handlePreviewTone(sound.id)}
                        className={`w-7 h-7 rounded-lg flex items-center justify-center transition-all active:scale-90 ${
                          isPlayingThis
                            ? 'bg-rose-600 text-white animate-pulse shadow-xs'
                            : 'bg-violet-100 dark:bg-slate-700 text-violet-700 dark:text-violet-300 hover:bg-violet-200'
                        }`}
                        title={isPlayingThis ? (language === 'bn' ? 'থামান' : 'Stop') : (language === 'bn' ? 'শুনুন' : 'Play')}
                      >
                        {isPlayingThis ? <Square size={11} className="fill-current" /> : <Play size={11} className="fill-current ml-0.5" />}
                      </button>

                      {/* Set as Default Button */}
                      {!isDefault && (
                        <button
                          type="button"
                          onClick={() => handleSetDefaultTone(sound.id)}
                          className="px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-700/80 hover:bg-violet-600 hover:text-white text-slate-600 dark:text-slate-300 text-[10px] font-bold transition-all"
                        >
                          {language === 'bn' ? 'বাছুন' : 'Set'}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Task Completion Sound Section */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-700 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Music size={15} className="text-emerald-500" />
                <div>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                    {language === 'bn' ? 'কাজ সম্পূর্ণ হওয়ার সাউন্ড' : 'Task Completion Audio Chime'}
                  </span>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 block">
                    {language === 'bn' ? 'কোনো কাজ টিক দিলে মিষ্টি একটি সুর বাজবে' : 'Pleasing audio feedback when completing tasks'}
                  </span>
                </div>
              </div>

              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={completionSoundOn}
                  onChange={(e) => handleToggleCompletionSound(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-slate-300 peer-focus:outline-hidden rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
              </label>
            </div>

            {completionSoundOn && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1 animate-in fade-in">
                {[
                  {
                    id: 'subtle_chime' as CompletionToneType,
                    nameBn: '✨ সুমধুর হারমোনিক কাইম (528Hz)',
                    nameEn: '✨ Harmonic Chime (528Hz)',
                  },
                  {
                    id: 'soft_bell' as CompletionToneType,
                    nameBn: '🔔 শান্ত অ্যাকোস্টিক বেল',
                    nameEn: '🔔 Soft Acoustic Bell',
                  },
                  {
                    id: 'positive_tone' as CompletionToneType,
                    nameBn: '🎵 ট্রিপল সাকসেস মেলোডি',
                    nameEn: '🎵 Triple Success Tone',
                  },
                ].map((item) => {
                  const isSelected = completionStyle === item.id;
                  const isTesting = isTestingCompletion === item.id;

                  return (
                    <div
                      key={item.id}
                      className={`p-2.5 rounded-xl border flex items-center justify-between gap-1.5 transition-all ${
                        isSelected
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-400 dark:border-emerald-600 text-emerald-950 dark:text-emerald-200'
                          : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => handleChangeCompletionStyle(item.id)}
                        className="flex-1 text-left text-[11px] font-bold truncate flex items-center gap-1"
                      >
                        {isSelected && <CheckCircle2 size={12} className="text-emerald-500 shrink-0" />}
                        <span className="truncate">{language === 'bn' ? item.nameBn : item.nameEn}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleTestCompletion(item.id)}
                        className={`px-2 py-0.5 rounded text-[10px] font-extrabold transition-all active:scale-90 ${
                          isTesting
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-100 dark:bg-slate-700 hover:bg-emerald-500 hover:text-white'
                        }`}
                      >
                        {language === 'bn' ? 'টেস্ট' : 'Play'}
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Dedicated Mobile Lock Screen Alarm Engine & 5-Second Test */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-950/40 via-slate-900/90 to-violet-950/40 border border-indigo-500/30 dark:border-indigo-500/40 space-y-3">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-indigo-600 text-white shadow-sm shrink-0">
                <Lock size={18} />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h4 className="text-xs font-extrabold text-white">
                    {language === 'bn' ? 'ফোন লক স্ক্রিন অ্যালার্ম সুরক্ষা' : 'Mobile Lock-Screen Alarm Protection'}
                  </h4>
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                    {language === 'bn' ? 'সক্রিয় ও প্রস্তুত' : 'Active & Ready'}
                  </span>
                </div>
                <p className="text-[11px] text-slate-300 mt-0.5">
                  {language === 'bn'
                    ? 'মোবাইল ফোন লক ও স্ক্রিন বন্ধ থাকলেও সাইরেন রিংটোন এবং ভাইব্রেশন অবিরাম বাজবে।'
                    : 'Plays high-decibel siren and continuous vibration even when the screen is locked.'}
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <div className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700/60 flex items-center gap-2">
              <Check size={14} className="text-emerald-400 shrink-0" />
              <div>
                <span className="font-bold text-white block">
                  {language === 'bn' ? 'এইচটিএমএল৫ সাইরেন' : 'Siren Audio'}
                </span>
                <span className="text-[10px] text-slate-400">
                  {language === 'bn' ? 'লক স্ক্রিন রেজিলিয়েন্ট' : 'Lock-proof stream'}
                </span>
              </div>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700/60 flex items-center gap-2">
              <Check size={14} className="text-emerald-400 shrink-0" />
              <div>
                <span className="font-bold text-white block">
                  {language === 'bn' ? 'মিডিয়া কন্ট্রোলার' : 'Media Widget'}
                </span>
                <span className="text-[10px] text-slate-400">
                  {language === 'bn' ? 'লক স্ক্রিনে বোতাম' : 'Lock-screen controls'}
                </span>
              </div>
            </div>
          </div>

          {onTestLockScreenAlarm && (
            <div className="pt-2 border-t border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <span className="text-[11px] text-slate-300">
                {language === 'bn'
                  ? 'আপনার নিজের ফোনে ৫ সেকেন্ডে টেস্ট করে দেখুন:'
                  : 'Test directly on your locked phone in 5 seconds:'}
              </span>
              <button
                type="button"
                onClick={onTestLockScreenAlarm}
                className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-indigo-600/30 active:scale-95 transition-all"
              >
                <Smartphone size={14} />
                <span>{language === 'bn' ? 'টেস্ট: ৫ সেকেন্ডে লক অ্যালার্ম' : 'Test Lock Alarm (5s)'}</span>
              </button>
            </div>
          )}
        </div>

        {/* Install as Mobile App */}
        {onOpenInstallModal && (
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-violet-50/70 dark:bg-violet-950/40 border border-violet-200/80 dark:border-violet-800/60">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-violet-600 text-white shadow-xs">
                <Download size={18} />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                  {language === 'bn' ? 'মোবাইলে অ্যাপ ইনস্টল করুন' : 'Install Habivio App'}
                </span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                  {language === 'bn' ? 'হোম স্ক্রিন শর্টকাট ও অফলাইন সুবিধা' : 'Add to Home Screen & offline use'}
                </span>
              </div>
            </div>

            <button
              onClick={onOpenInstallModal}
              className="px-3.5 py-1.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-xs font-bold shadow-xs active:scale-95 transition-all"
            >
              {language === 'bn' ? 'ইনস্টল গাইড' : 'Install'}
            </button>
          </div>
        )}
      </section>

      {/* 3. Dedicated Add to Home Screen Step-by-Step Installation Guide */}
      <InstallGuideCard />

      {/* 4. Data Backup, Restore & Reset */}
      <section className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-5 shadow-xs transition-colors space-y-4">
        <div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            {t.backupRestore}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Export and import all your records safely in JSON format
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <button
            onClick={handleExport}
            className="flex items-center justify-center gap-2 p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-750 text-slate-800 dark:text-slate-200 text-xs font-bold transition-all active:scale-95"
          >
            <Download size={16} className="text-violet-600" />
            <span>{t.exportData}</span>
          </button>

          <label className="flex items-center justify-center gap-2 p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-750 text-slate-800 dark:text-slate-200 text-xs font-bold transition-all cursor-pointer active:scale-95">
            <Upload size={16} className="text-indigo-600" />
            <span>{t.importData}</span>
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={handleFileChange}
              className="hidden"
            />
          </label>
        </div>

        {/* Danger zone actions with confirmation modal */}
        <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            onClick={() => setIsResetModalOpen(true)}
            className="w-full sm:w-auto px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center gap-1.5 transition-colors"
          >
            <RotateCcw size={14} />
            <span>{t.resetDefaultData}</span>
          </button>

          <button
            onClick={() => setIsClearModalOpen(true)}
            className="w-full sm:w-auto px-4 py-2 rounded-xl text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 flex items-center justify-center gap-1.5 transition-colors"
          >
            <Trash2 size={14} />
            <span>{t.clearAllData}</span>
          </button>
        </div>
      </section>

      {/* 4. Link to AI Assistant Preview */}
      <section 
        onClick={() => setActiveTab('ai')}
        className="p-5 rounded-3xl bg-linear-to-r from-violet-600/10 via-purple-600/10 to-indigo-600/10 border border-violet-500/20 cursor-pointer hover:border-violet-500/40 transition-all flex items-center justify-between gap-3 group"
      >
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-violet-600 text-white shadow-xs group-hover:scale-105 transition-transform">
            <Sparkles size={20} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                {t.aiTitle}
              </h4>
              <span className="px-2 py-0.5 rounded-full bg-violet-100 dark:bg-violet-900/60 text-violet-700 dark:text-violet-300 text-[10px] font-bold">
                {t.aiBadge}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Explore roadmap & upcoming AI productivity capabilities
            </p>
          </div>
        </div>
      </section>

      {/* Clear Confirmation Modal */}
      <ConfirmationModal
        isOpen={isClearModalOpen}
        title={t.clearConfirmTitle}
        message={t.clearConfirmMessage}
        confirmLabel={t.delete}
        cancelLabel={t.cancel}
        isDestructive={true}
        onConfirm={() => {
          clearAllData();
          setIsClearModalOpen(false);
          setStatusFeedback('All application data cleared.');
          setTimeout(() => setStatusFeedback(null), 3000);
        }}
        onClose={() => setIsClearModalOpen(false)}
      />

      {/* Reset Confirmation Modal */}
      <ConfirmationModal
        isOpen={isResetModalOpen}
        title={t.resetConfirmTitle}
        message={t.resetConfirmMessage}
        confirmLabel={t.confirm}
        cancelLabel={t.cancel}
        isDestructive={false}
        onConfirm={() => {
          resetToDefaultData();
          setIsResetModalOpen(false);
          setStatusFeedback('Sample data restored.');
          setTimeout(() => setStatusFeedback(null), 3000);
        }}
        onClose={() => setIsResetModalOpen(false)}
      />

      {/* Android & Redmi Smart Alarm Settings Modal */}
      <AndroidAlarmSettingsModal
        isOpen={isAndroidAlarmModalOpen}
        onClose={() => setIsAndroidAlarmModalOpen(false)}
        onTestScreenOffAlarm={() => handleToggleAlarmTest()}
      />
    </div>
  );
};
