import React, { useState } from 'react';
import { CreditCard, QrCode, School, Sparkles, X, RotateCw, CheckCircle, ShieldCheck } from 'lucide-react';
import { StudentProfile, WalletBalance } from '../types';
import { formatRupiah } from '../utils/formatters';

interface StudentCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: StudentProfile;
  balances: WalletBalance;
}

export const StudentCardModal: React.FC<StudentCardModalProps> = ({
  isOpen,
  onClose,
  profile,
  balances,
}) => {
  const [isFlipped, setIsFlipped] = useState(false);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-6">
        {/* Header */}
        <div className="px-6 pt-6 pb-3 flex items-center justify-between border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <CreditCard className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Kartu Pelajar Digital</h2>
              <p className="text-[11px] text-slate-500">ID Resmi & Kartu Dompet SakuSiswa</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-full transition-colors"
            aria-label="Tutup"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Card Canvas */}
        <div className="p-6">
          <div
            className="relative w-full aspect-[1.586] rounded-2xl overflow-hidden shadow-xl text-white transition-transform duration-500 transform cursor-pointer border border-slate-700/50"
            onClick={() => setIsFlipped(!isFlipped)}
          >
            {/* Visual Background image with fallback */}
            <div className="absolute inset-0 bg-slate-900">
              <img
                src="/src/assets/images/student_card_mesh_1794268821451.jpg"
                alt="Background Kartu Pelajar"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover opacity-90 mix-blend-screen"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-slate-950 via-slate-900/80 to-emerald-950/40" />
            </div>

            {!isFlipped ? (
              /* FRONT OF CARD */
              <div className="relative z-10 h-full p-5 flex flex-col justify-between select-none">
                {/* School & Brand row */}
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center">
                      <School className="w-4 h-4 text-emerald-300" />
                    </div>
                    <div>
                      <p className="text-[10px] uppercase font-mono tracking-wider text-emerald-300 font-bold">
                        {profile.school}
                      </p>
                      <p className="text-[12px] font-extrabold tracking-tight">KARTU TANDA PELAJAR</p>
                    </div>
                  </div>

                  <span className="text-[10px] font-mono tracking-widest px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                    SAKUSISWA
                  </span>
                </div>

                {/* Center Chip & Avatar */}
                <div className="flex items-center justify-between my-1">
                  {/* EMV Smart Chip */}
                  <div className="w-10 h-7 rounded-md bg-gradient-to-tr from-amber-300 via-yellow-200 to-amber-400 border border-amber-500/60 shadow-sm relative overflow-hidden flex items-center justify-center">
                    <div className="w-7 h-5 border border-amber-600/40 rounded-sm grid grid-cols-2 gap-0.5">
                      <div className="border-r border-amber-600/30" />
                      <div className="border-l border-amber-600/30" />
                    </div>
                  </div>

                  {/* Student Photo */}
                  <div className="w-14 h-14 rounded-xl border-2 border-emerald-400/80 shadow-md overflow-hidden bg-slate-800">
                    <img
                      src={profile.avatar}
                      alt={profile.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>

                {/* Bottom Student Info */}
                <div>
                  <p className="text-base font-extrabold tracking-wide text-white truncate drop-shadow-sm">
                    {profile.name}
                  </p>
                  <div className="flex items-center justify-between text-[11px] text-slate-300 font-mono mt-0.5">
                    <span>NISN: {profile.nisn}</span>
                    <span>{profile.grade} • {profile.age} Th</span>
                  </div>
                </div>
              </div>
            ) : (
              /* BACK OF CARD */
              <div className="relative z-10 h-full p-4 flex flex-col justify-between select-none">
                {/* Magnetic Stripe */}
                <div className="-mx-4 -mt-4 h-9 bg-slate-950 border-b border-slate-800" />

                <div className="px-2 space-y-2">
                  <div className="flex items-center justify-between text-[10px] text-slate-300">
                    <span>Saldo Dompet:</span>
                    <span className="font-mono font-bold text-emerald-400">
                      {formatRupiah(balances.wallet)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-slate-300">
                    <span>Tabungan Siswa:</span>
                    <span className="font-mono font-bold text-indigo-300">
                      {formatRupiah(balances.savings)}
                    </span>
                  </div>

                  {/* Barcode line */}
                  <div className="bg-white p-2 rounded-lg text-center">
                    <div className="h-6 flex justify-center items-center gap-[2px]">
                      {[4, 2, 6, 2, 3, 5, 2, 4, 3, 2, 5, 2, 4, 6, 2, 3, 4, 2, 5, 2].map(
                        (h, i) => (
                          <div
                            key={i}
                            className={`bg-slate-900 w-[2px]`}
                            style={{ height: `${h * 4}px` }}
                          />
                        )
                      )}
                    </div>
                    <span className="text-[9px] font-mono text-slate-600 block mt-0.5">
                      *{profile.nisn}*
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[9px] text-slate-400 border-t border-white/10 pt-1">
                  <span>Kartu Sah Pelajar Aktif</span>
                  <span className="text-emerald-400">Verifikasi QRIS Valid</span>
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center justify-center gap-2 mt-3 text-xs text-slate-500">
            <RotateCw className="w-3.5 h-3.5" />
            <span>Klik kartu untuk membalik (Depan / Belakang)</span>
          </div>

          {/* Quick info list */}
          <div className="mt-4 p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-500">Status Keanggotaan</span>
              <span className="font-semibold text-emerald-600 flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" />
                Siswa Aktif
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500">Nomor Induk Siswa Nasional</span>
              <span className="font-mono font-semibold text-slate-900">{profile.nisn}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500">Otorisasi Pembayaran</span>
              <span className="font-semibold text-slate-900 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                PIN Terproteksi
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-full mt-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition-colors"
          >
            Tutup Kartu
          </button>
        </div>
      </div>
    </div>
  );
};
