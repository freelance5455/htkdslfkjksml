import React from 'react';
import { Language, Mission } from '../types/game';
import { MISSIONS_DATA } from '../data/missionsData';

interface PauseModalProps {
  currentMission: Mission;
  unlockedLevel: number;
  language: Language;
  soundEnabled: boolean;
  musicEnabled: boolean;
  onResume: () => void;
  onRestartLevel: () => void;
  onSelectLevel: (level: number) => void;
  onReturnTitle: () => void;
  onToggleSound: () => void;
  onToggleMusic: () => void;
  onToggleLanguage: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  currentMission,
  unlockedLevel,
  language,
  soundEnabled,
  musicEnabled,
  onResume,
  onRestartLevel,
  onSelectLevel,
  onReturnTitle,
  onToggleSound,
  onToggleMusic,
  onToggleLanguage,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 pointer-events-auto">
      <div className="w-full max-w-md bg-slate-900 border-2 border-amber-500/50 rounded-3xl p-6 shadow-2xl text-white">
        {/* Header */}
        <div className="text-center mb-5">
          <div className="text-2xl font-black text-amber-400">
            {language === 'hinglish' ? '⏸ Khel Ruka Hua Hai (Paused)' : '⏸ Game Paused'}
          </div>
          <div className="text-xs text-slate-300 mt-1">
            {currentMission.title[language]}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2.5 mb-5">
          <button
            onClick={onResume}
            className="w-full py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-black shadow-lg transition-transform text-sm"
          >
            {language === 'hinglish' ? '▶ Khel Jaari Rakhein (Resume)' : '▶ Resume Game'}
          </button>

          <button
            onClick={onRestartLevel}
            className="w-full py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-amber-200 border border-slate-700 font-bold text-xs transition-transform"
          >
            {language === 'hinglish' ? '🔄 Mission Restart Karein' : '🔄 Restart Level'}
          </button>

          <button
            onClick={onReturnTitle}
            className="w-full py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-amber-200 border border-slate-700 font-bold text-xs transition-transform"
          >
            {language === 'hinglish' ? '🏠 Main Menu' : '🏠 Main Menu'}
          </button>
        </div>

        {/* Quick Settings Bar */}
        <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950/70 border border-slate-800 mb-5 text-xs font-semibold">
          <div className="text-slate-400">Settings:</div>
          <div className="flex items-center gap-2">
            <button
              onClick={onToggleLanguage}
              className="px-2.5 py-1 rounded-xl bg-slate-800 text-amber-300 border border-slate-700 text-xs"
            >
              {language === 'hinglish' ? '🇮🇳 Hinglish' : '🇬🇧 English'}
            </button>
            <button
              onClick={onToggleMusic}
              className={`w-8 h-8 rounded-xl border flex items-center justify-center text-xs ${
                musicEnabled ? 'bg-amber-500/20 text-amber-300 border-amber-400/40' : 'bg-red-950 text-red-300 border-red-500/40'
              }`}
            >
              {musicEnabled ? '🎵' : '🔇'}
            </button>
            <button
              onClick={onToggleSound}
              className={`w-8 h-8 rounded-xl border flex items-center justify-center text-xs ${
                soundEnabled ? 'bg-amber-500/20 text-amber-300 border-amber-400/40' : 'bg-red-950 text-red-300 border-red-500/40'
              }`}
            >
              {soundEnabled ? '🔊' : '🔈'}
            </button>
          </div>
        </div>

        {/* Mission Jump Bar */}
        <div>
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
            {language === 'hinglish' ? 'Mission Chunein:' : 'Jump to Level:'}
          </div>
          <div className="grid grid-cols-5 gap-1.5">
            {MISSIONS_DATA.map((m) => {
              const isUnlocked = m.id <= unlockedLevel;
              const isCurrent = m.id === currentMission.id;
              return (
                <button
                  key={m.id}
                  disabled={!isUnlocked}
                  onClick={() => onSelectLevel(m.id)}
                  className={`py-2 rounded-xl text-center text-xs font-bold border transition-all ${
                    isCurrent
                      ? 'bg-amber-400 text-slate-950 border-white'
                      : isUnlocked
                      ? 'bg-slate-800 hover:bg-slate-700 text-amber-200 border-slate-700'
                      : 'bg-slate-950/40 text-slate-600 border-slate-900 cursor-not-allowed opacity-40'
                  }`}
                >
                  Lvl {m.id}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
