/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { soundManager } from '../audio/SoundManager';
import { Play, RotateCcw, Volume2, VolumeX, Home } from 'lucide-react';

interface PauseModalProps {
  onResume: () => void;
  onRestart: () => void;
  onQuitToTitle: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  onResume,
  onRestart,
  onQuitToTitle,
}) => {
  const [muted, setMuted] = React.useState(soundManager.getMuted());

  const toggleMute = () => {
    const next = !muted;
    setMuted(next);
    soundManager.setMuted(next);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 select-none">
      <div className="bg-[#0b0f17] border border-slate-700/80 rounded-2xl max-w-sm w-full p-6 text-slate-100 shadow-2xl">
        <div className="text-center mb-6">
          <div className="text-xs font-mono text-red-500 font-bold uppercase tracking-widest mb-1">
            MISSION SUSPENDED
          </div>
          <h2 className="text-2xl font-black tracking-tight text-white uppercase">
            GAME PAUSED
          </h2>
          <div className="mt-1 text-[11px] font-mono text-slate-400">
            DEADZONE: OUTBREAK · <span className="text-yellow-400">MADE BY REHANX</span>
          </div>
        </div>

        <div className="space-y-3">
          <button
            onClick={onResume}
            className="w-full py-3.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold tracking-wider uppercase transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-red-900/30"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>RESUME MISSION</span>
          </button>

          <button
            onClick={toggleMute}
            className="w-full py-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 font-semibold tracking-wide transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            {muted ? (
              <>
                <VolumeX className="w-4 h-4 text-red-400" />
                <span>SOUND: MUTED</span>
              </>
            ) : (
              <>
                <Volume2 className="w-4 h-4 text-emerald-400" />
                <span>SOUND: ENABLED</span>
              </>
            )}
          </button>

          <button
            onClick={onRestart}
            className="w-full py-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 font-semibold tracking-wide transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4 text-amber-400" />
            <span>RESTART LEVEL</span>
          </button>

          <button
            onClick={onQuitToTitle}
            className="w-full py-3 rounded-xl bg-slate-950 hover:bg-slate-900 border border-slate-800 text-slate-400 hover:text-white font-semibold tracking-wide transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <Home className="w-4 h-4" />
            <span>QUIT TO MAIN MENU</span>
          </button>
        </div>
      </div>
    </div>
  );
};
