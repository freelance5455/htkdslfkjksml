import React from 'react';
import { Play, RotateCcw, Home, Volume2, VolumeX, Music, Eye } from 'lucide-react';
import { soundEngine } from '../utils/audio';

interface PauseModalProps {
  soundEnabled: boolean;
  musicEnabled: boolean;
  colorblindMode: boolean;
  onResume: () => void;
  onRestart: () => void;
  onToggleSound: () => void;
  onToggleMusic: () => void;
  onToggleColorblind: () => void;
  onHome: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  soundEnabled,
  musicEnabled,
  colorblindMode,
  onResume,
  onRestart,
  onToggleSound,
  onToggleMusic,
  onToggleColorblind,
  onHome
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md select-none animate-in fade-in duration-150">
      <div className="relative w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl flex flex-col items-center text-center">
        <h2 className="text-xl sm:text-2xl font-extrabold text-white mb-6 tracking-wide">
          GAME PAUSED
        </h2>

        {/* Quick Toggles */}
        <div className="w-full grid grid-cols-3 gap-2.5 mb-6">
          <button
            onClick={() => {
              soundEngine.playNodeSelect(0);
              onToggleSound();
            }}
            className={`p-3 rounded-2xl border flex flex-col items-center gap-1.5 transition-all ${
              soundEnabled
                ? 'bg-cyan-500/10 border-cyan-500/40 text-cyan-300'
                : 'bg-slate-950 border-slate-800 text-slate-500'
            }`}
          >
            {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
            <span className="text-[10px] font-bold">Sound</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playNodeSelect(1);
              onToggleMusic();
            }}
            className={`p-3 rounded-2xl border flex flex-col items-center gap-1.5 transition-all ${
              musicEnabled
                ? 'bg-purple-500/10 border-purple-500/40 text-purple-300'
                : 'bg-slate-950 border-slate-800 text-slate-500'
            }`}
          >
            <Music className="w-5 h-5" />
            <span className="text-[10px] font-bold">Ambience</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playNodeSelect(2);
              onToggleColorblind();
            }}
            className={`p-3 rounded-2xl border flex flex-col items-center gap-1.5 transition-all ${
              colorblindMode
                ? 'bg-amber-500/10 border-amber-500/40 text-amber-300'
                : 'bg-slate-950 border-slate-800 text-slate-500'
            }`}
          >
            <Eye className="w-5 h-5" />
            <span className="text-[10px] font-bold">Symbols</span>
          </button>
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2.5">
          <button
            onClick={() => {
              soundEngine.playNodeSelect(3);
              onResume();
            }}
            className="w-full h-12 flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-sm tracking-wide shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all hover:scale-102 active:scale-98"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>RESUME</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playNodeSelect(1);
              onRestart();
            }}
            className="w-full h-11 flex items-center justify-center gap-2 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            <span>RESTART PUZZLE</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playNodeSelect(0);
              onHome();
            }}
            className="w-full h-11 flex items-center justify-center gap-2 rounded-2xl bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-slate-200 font-semibold text-xs border border-slate-800 transition-colors"
          >
            <Home className="w-4 h-4" />
            <span>MAIN MENU</span>
          </button>
        </div>
      </div>
    </div>
  );
};
