interface PauseModalProps {
  onResume: () => void;
  onRestart: () => void;
  onTitle: () => void;
}

export function PauseModal({ onResume, onRestart, onTitle }: PauseModalProps) {
  return (
    <div
      className="absolute inset-0 z-20 flex items-center justify-center bg-[#09130c]/70 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="pause-title"
    >
      <div className="pixel-panel w-full max-w-xs p-6 text-center">
        <h2
          id="pause-title"
          className="font-pixel-display text-2xl font-bold text-[#facc15] drop-shadow-[0_2px_0_#09130c]"
        >
          PAUSED
        </h2>
        <p className="mt-1.5 text-sm text-[#c6dec9]">Take a breather off the tracks.</p>

        <div className="mt-5 flex flex-col gap-3">
          <button
            type="button"
            onClick={onResume}
            className="pixel-btn min-h-[44px] w-full bg-[#2d6a4f] px-4 py-2.5 font-pixel-display text-sm font-bold text-[#f4f7ec] whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#facc15]"
          >
            Resume
          </button>

          <button
            type="button"
            onClick={onRestart}
            className="pixel-btn min-h-[44px] w-full bg-[#374151] px-4 py-2.5 font-pixel-display text-sm font-bold text-[#f4f7ec] whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#facc15]"
          >
            Restart
          </button>

          <button
            type="button"
            onClick={onTitle}
            className="pixel-btn min-h-[44px] w-full bg-[#1f2937] px-4 py-2.5 font-pixel-display text-sm font-bold text-[#c6dec9] whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#facc15]"
          >
            Title Screen
          </button>
        </div>
      </div>
    </div>
  );
}
