import React from 'react';
import { Play, RotateCcw, Volume2, VolumeX, X } from 'lucide-react';
import { sound } from '../game/sound';

interface PauseModalProps {
  cash: number;
  unlockedCitiesCount: number;
  totalEarnings: number;
  soundEnabled: boolean;
  onResume: () => void;
  onToggleSound: () => void;
  onResetSave: () => void;
  onTitleMenu: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  cash,
  unlockedCitiesCount,
  totalEarnings,
  soundEnabled,
  onResume,
  onToggleSound,
  onResetSave,
  onTitleMenu
}) => {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-none p-4 select-none"
      data-testid="pause-modal"
    >
      <div className="bg-[#0e0f14] border border-[#27272a] rounded-2xl max-w-sm w-full p-6 text-white text-center shadow-2xl">
        <h2 className="text-xl font-mono font-bold tracking-tight mb-1">
          OPERATIONS PAUSED
        </h2>
        <p className="text-xs text-[#71717a] font-mono mb-6">
          Air traffic simulation frozen
        </p>

        {/* Stats tiles */}
        <div className="grid grid-cols-2 gap-2 mb-6 text-left">
          <div className="bg-[#14151e] p-3 rounded-lg border border-[#23242e]">
            <span className="text-[10px] font-mono text-[#71717a] block">LIQUID CAPITAL</span>
            <span className="text-base font-mono font-bold text-white tabular-nums">
              ${cash.toLocaleString()}
            </span>
          </div>
          <div className="bg-[#14151e] p-3 rounded-lg border border-[#23242e]">
            <span className="text-[10px] font-mono text-[#71717a] block">AIRPORT HUBS</span>
            <span className="text-base font-mono font-bold text-white tabular-nums">
              {unlockedCitiesCount} Cities
            </span>
          </div>
        </div>

        {/* Action buttons */}
        <div className="space-y-2">
          <button
            onClick={() => {
              onResume();
              sound.playClick();
            }}
            className="w-full py-3 bg-white text-black hover:bg-[#e4e4e7] font-mono font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Play size={14} />
            <span>RESUME OPERATIONS</span>
          </button>

          <button
            onClick={() => {
              onToggleSound();
              sound.playClick();
            }}
            className="w-full py-2.5 bg-[#161720] hover:bg-[#20212d] text-white border border-[#27272a] font-mono text-xs rounded-xl transition-all flex items-center justify-center gap-2"
          >
            {soundEnabled ? <Volume2 size={14} /> : <VolumeX size={14} />}
            <span>{soundEnabled ? 'MUTE SOUND [M]' : 'UNMUTE SOUND [M]'}</span>
          </button>

          <button
            onClick={() => {
              onTitleMenu();
              sound.playClick();
            }}
            className="w-full py-2.5 bg-[#161720] hover:bg-[#20212d] text-white border border-[#27272a] font-mono text-xs rounded-xl transition-all"
          >
            RETURN TO TITLE MENU
          </button>

          <button
            onClick={() => {
              if (window.confirm('Are you sure you want to reset your airline save data? All progress will restart.')) {
                onResetSave();
              }
            }}
            className="w-full py-2 text-[#71717a] hover:text-red-400 font-mono text-[11px] transition-colors"
          >
            Reset Progress
          </button>
        </div>
      </div>
    </div>
  );
};
