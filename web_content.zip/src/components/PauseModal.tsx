import React from 'react';
import { Play, RotateCcw, Home } from 'lucide-react';

interface PauseModalProps {
  score: number;
  onResume: () => void;
  onRestart: () => void;
  onQuit: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  score,
  onResume,
  onRestart,
  onQuit,
}) => {
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm px-6 py-6 animate-in fade-in duration-150">
      <div className="flex w-full max-w-xs flex-col items-center rounded-3xl bg-slate-900 border border-slate-800 p-6 text-center shadow-2xl">
        <h2 className="text-2xl font-black text-white">GAME PAUSED</h2>

        <div className="my-4 flex flex-col items-center">
          <span className="text-xs font-semibold text-slate-400">CURRENT SCORE</span>
          <span className="font-mono text-4xl font-black text-amber-300 tabular-nums">
            {score}
          </span>
        </div>

        <div className="flex flex-col gap-2.5 w-full mt-2">
          <button
            onClick={onResume}
            className="flex h-12 w-full cursor-pointer items-center justify-center gap-2 rounded-xl bg-emerald-500 font-bold text-white shadow-lg shadow-emerald-500/20 active:scale-95 hover:bg-emerald-400 transition-all"
          >
            <Play className="h-4 w-4 fill-white" />
            <span>RESUME</span>
          </button>

          <button
            onClick={onRestart}
            className="flex h-11 w-full cursor-pointer items-center justify-center gap-2 rounded-xl bg-slate-800 font-semibold text-slate-200 active:scale-95 hover:bg-slate-700 transition-all"
          >
            <RotateCcw className="h-4 w-4" />
            <span>RESTART</span>
          </button>

          <button
            onClick={onQuit}
            className="flex h-11 w-full cursor-pointer items-center justify-center gap-2 rounded-xl bg-transparent text-slate-400 hover:text-white transition-all text-xs font-semibold"
          >
            <Home className="h-4 w-4" />
            <span>EXIT TO TITLE</span>
          </button>
        </div>
      </div>
    </div>
  );
};
