import React, { useState } from 'react';
import { Play, Volume2, VolumeX, RotateCcw, HelpCircle, X, Tv } from 'lucide-react';
import { soundFx } from '../utils/audio';

interface PauseModalProps {
  isOpen: boolean;
  onResume: () => void;
  onRestart: () => void;
  isMuted: boolean;
  onToggleSound: () => void;
  stationName: string;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  isOpen,
  onResume,
  onRestart,
  isMuted,
  onToggleSound,
  stationName,
}) => {
  const [confirmRestart, setConfirmRestart] = useState(false);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl p-5 shadow-2xl flex flex-col gap-4">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400">
              <Tv className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white font-display">Jogo Pausado</h2>
              <div className="text-xs text-amber-400 font-semibold">{stationName}</div>
            </div>
          </div>

          <button
            onClick={onResume}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center text-slate-400 hover:text-white rounded-xl transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Menu Buttons */}
        <div className="space-y-2.5">
          <button
            onClick={() => {
              soundFx.playClick();
              onResume();
            }}
            className="w-full min-h-[48px] py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm tracking-wide uppercase transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-amber-950/40 active:scale-95"
          >
            <Play className="w-4 h-4 fill-slate-950" />
            <span>Retomar Transmissão</span>
          </button>

          <button
            onClick={() => {
              onToggleSound();
            }}
            className="w-full min-h-[46px] py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
            <span>{isMuted ? 'Ativar Efeitos Sonoros' : 'Mutar Efeitos Sonoros'}</span>
          </button>

          {confirmRestart ? (
            <div className="p-3 bg-red-950/60 border border-red-500/50 rounded-xl flex flex-col gap-2">
              <p className="text-xs text-red-200 text-center font-bold">
                Deseja apagar o progresso e reiniciar?
              </p>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    soundFx.playClick();
                    onRestart();
                  }}
                  className="flex-1 min-h-[44px] py-2 px-3 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase cursor-pointer active:scale-95"
                >
                  Confirmar Reinício
                </button>
                <button
                  onClick={() => setConfirmRestart(false)}
                  className="flex-1 min-h-[44px] py-2 px-3 rounded-lg bg-slate-800 text-slate-300 font-semibold text-xs cursor-pointer active:scale-95"
                >
                  Voltar
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setConfirmRestart(true)}
              className="w-full min-h-[44px] py-2.5 px-4 rounded-xl bg-slate-950 hover:bg-red-950/40 border border-slate-800 hover:border-red-800 text-slate-400 hover:text-red-400 font-semibold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Fundar Nova Emissora (Reiniciar)</span>
            </button>
          )}
        </div>

        {/* How to Play Quick Guide */}
        <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 space-y-2 text-xs text-slate-300">
          <div className="font-bold text-white flex items-center gap-1.5 text-xs">
            <HelpCircle className="w-4 h-4 text-amber-400" />
            Manual do Diretor de TV:
          </div>
          <ul className="space-y-1 list-disc pl-4 text-slate-400 text-[11px] leading-relaxed">
            <li><strong className="text-slate-200">Faixas Horárias:</strong> Manhã (Desenhos e Notícias), Tarde (Fofoca e Auditório), Horário Nobre (Novela e Jornalismo), Madrugada (Filmes).</li>
            <li><strong className="text-slate-200">Patrocínio:</strong> Cada bloco gera receita com comerciais. Se o IBOPE cair abaixo da meta do cliente, você paga multas!</li>
            <li><strong className="text-slate-200">Plantão Urgente:</strong> Dá um pico massivo de audiência contra os concorrentes no Switcher NO AR.</li>
            <li><strong className="text-slate-200">Atalhos de Teclado:</strong> Teclas 1 a 5 para navegar abas; Espaço no ar para rodar comercial; Esc para pausar.</li>
          </ul>
        </div>
      </div>
    </div>
  );
};
