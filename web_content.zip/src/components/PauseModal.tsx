import React from 'react';
import { Play, RotateCcw, Home, Settings, Volume2, VolumeX } from 'lucide-react';
import { soundSystem } from '../game/soundSystem';

interface PauseModalProps {
  onResume: () => void;
  onRestart: () => void;
  onHome: () => void;
  onOpenSettings: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  onResume,
  onRestart,
  onHome,
  onOpenSettings
}) => {
  const [muted, setMuted] = React.useState(() => soundSystem.isMuted());

  const handleToggleMute = () => {
    const isNowMuted = soundSystem.toggleMute();
    setMuted(isNowMuted);
  };

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-4 bg-slate-950/80">
      <div className="bg-slate-900 border-2 border-slate-700 rounded-3xl p-6 max-w-sm w-full shadow-2xl flex flex-col items-center text-center">
        <h2 className="text-2xl font-black text-amber-400 mb-4">اللعبة متوقفة مؤقتاً</h2>

        <div className="flex flex-col gap-3 w-full">
          <button
            onClick={onResume}
            className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-lg shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Play className="w-5 h-5 fill-slate-950" />
            <span>استئناف الهروب</span>
          </button>

          <button
            onClick={onRestart}
            className="w-full py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold active:scale-95 transition-all flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-4 h-4 text-amber-400" />
            <span>إعادة من البداية</span>
          </button>

          <div className="grid grid-cols-2 gap-2.5 w-full">
            <button
              onClick={handleToggleMute}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold text-sm active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              {muted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
              <span>{muted ? 'كتم الصوت' : 'الصوت مفعل'}</span>
            </button>

            <button
              onClick={onOpenSettings}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold text-sm active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              <Settings className="w-4 h-4 text-cyan-400" />
              <span>التحكم</span>
            </button>
          </div>

          <button
            onClick={onHome}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-slate-400 hover:text-white font-bold text-sm active:scale-95 transition-all flex items-center justify-center gap-2 mt-1"
          >
            <Home className="w-4 h-4" />
            <span>الخروج للقائمة الرئيسية</span>
          </button>
        </div>
      </div>
    </div>
  );
};
