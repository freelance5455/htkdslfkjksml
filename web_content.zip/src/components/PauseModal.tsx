/**
 * SPR - Sahil Powerful Run
 * Pause Modal
 */

import React, { useState } from 'react';
import { Play, RotateCcw, Home, Music, Volume2, VolumeX } from 'lucide-react';
import { soundManager } from '../game/audio/SoundManager';

interface Props {
  onResume: () => void;
  onRestart: () => void;
  onHome: () => void;
}

export const PauseModal: React.FC<Props> = ({ onResume, onRestart, onHome }) => {
  const currentSettings = soundManager.getSettings();
  const [musicEnabled, setMusicEnabled] = useState<boolean>(currentSettings.musicEnabled);
  const [sfxEnabled, setSfxEnabled] = useState<boolean>(currentSettings.sfxEnabled);

  const handleToggleMusic = () => {
    soundManager.playButtonClick();
    const next = soundManager.toggleMusic();
    setMusicEnabled(next);
  };

  const handleToggleSfx = () => {
    soundManager.playButtonClick();
    const next = soundManager.toggleSfx();
    setSfxEnabled(next);
  };

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm select-none">
      <div className="w-full max-w-sm bg-gradient-to-b from-slate-900 via-slate-950 to-black border border-slate-700 rounded-3xl p-6 shadow-2xl flex flex-col gap-4 text-center">
        <h2 className="text-2xl font-black text-white uppercase tracking-wider font-heading">
          GAME PAUSED
        </h2>
        <p className="text-xs text-slate-400">Take a breath, Sahil! The jungle awaits.</p>

        {/* Quick Audio Controls */}
        <div className="grid grid-cols-2 gap-2 bg-slate-950/80 p-2.5 rounded-2xl border border-slate-800">
          <button
            id="pause-toggle-music"
            onClick={handleToggleMusic}
            className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl font-bold text-xs transition cursor-pointer ${
              musicEnabled
                ? 'bg-orange-600/90 text-white border border-orange-400/50 shadow-[0_0_12px_rgba(234,88,12,0.4)]'
                : 'bg-slate-900 text-slate-400 border border-slate-700'
            }`}
          >
            <Music className="w-3.5 h-3.5" />
            <span>{musicEnabled ? 'MUSIC ON' : 'MUSIC OFF'}</span>
          </button>

          <button
            id="pause-toggle-sfx"
            onClick={handleToggleSfx}
            className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl font-bold text-xs transition cursor-pointer ${
              sfxEnabled
                ? 'bg-cyan-600/90 text-white border border-cyan-400/50 shadow-[0_0_12px_rgba(6,182,212,0.4)]'
                : 'bg-slate-900 text-slate-400 border border-slate-700'
            }`}
          >
            {sfxEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
            <span>{sfxEnabled ? 'SFX ON' : 'SFX OFF'}</span>
          </button>
        </div>

        <div className="flex flex-col gap-2.5 mt-1">
          <button
            id="pause-btn-resume"
            onClick={() => {
              soundManager.playButtonClick();
              onResume();
            }}
            className="w-full py-3.5 bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-500 hover:to-amber-400 text-slate-950 font-black text-base uppercase tracking-widest rounded-xl transition shadow-lg active:scale-98 flex items-center justify-center gap-2 cursor-pointer font-display"
          >
            <Play className="w-5 h-5 fill-current stroke-none" />
            RESUME RUN
          </button>

          <button
            id="pause-btn-restart"
            onClick={() => {
              soundManager.playButtonClick();
              onRestart();
            }}
            className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-white font-bold text-sm uppercase tracking-wider rounded-xl transition active:scale-98 flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            RESTART
          </button>

          <button
            id="pause-btn-home"
            onClick={() => {
              soundManager.playButtonClick();
              onHome();
            }}
            className="w-full py-3 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 font-bold text-sm uppercase tracking-wider rounded-xl transition active:scale-98 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Home className="w-4 h-4" />
            MAIN MENU
          </button>
        </div>
      </div>
    </div>
  );
};
