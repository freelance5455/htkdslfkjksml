/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Play, RotateCcw, Home, Volume2, VolumeX, Music } from 'lucide-react';

interface PauseModalProps {
  soundEnabled: boolean;
  musicEnabled: boolean;
  onResume: () => void;
  onRestart: () => void;
  onHome: () => void;
  onToggleSound: () => void;
  onToggleMusic: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  soundEnabled,
  musicEnabled,
  onResume,
  onRestart,
  onHome,
  onToggleSound,
  onToggleMusic,
}) => {
  return (
    <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-none flex items-center justify-center p-4 z-50 pointer-events-auto">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl max-w-xs w-full p-6 text-center shadow-2xl flex flex-col items-center">
        <h2 className="text-3xl font-black text-white italic tracking-wider text-shadow-arcade mb-5">
          GAME PAUSED
        </h2>

        {/* Audio Toggles */}
        <div className="w-full flex items-center justify-around bg-slate-950/70 border border-slate-800 rounded-2xl p-3 mb-5">
          <button
            onClick={onToggleSound}
            className={`flex flex-col items-center gap-1 text-xs font-semibold p-2 rounded-xl transition-colors cursor-pointer ${
              soundEnabled ? 'text-emerald-400 bg-slate-800' : 'text-slate-500 hover:text-slate-400'
            }`}
          >
            {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
            <span>SFX</span>
          </button>

          <button
            onClick={onToggleMusic}
            className={`flex flex-col items-center gap-1 text-xs font-semibold p-2 rounded-xl transition-colors cursor-pointer ${
              musicEnabled ? 'text-cyan-400 bg-slate-800' : 'text-slate-500 hover:text-slate-400'
            }`}
          >
            <Music className="w-5 h-5" />
            <span>Music</span>
          </button>
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2.5">
          <button
            onClick={onResume}
            className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 active:scale-95 text-white font-black text-base tracking-wider rounded-xl shadow-lg border border-emerald-400/40 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Play className="w-5 h-5 fill-current" />
            <span>RESUME</span>
          </button>

          <button
            onClick={onRestart}
            className="w-full py-3 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-300 hover:text-white font-bold text-sm rounded-xl border border-slate-700 flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>RESTART</span>
          </button>

          <button
            onClick={onHome}
            className="w-full py-3 bg-slate-800/80 hover:bg-slate-700 active:scale-95 text-slate-400 hover:text-white font-bold text-sm rounded-xl border border-slate-800 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Home className="w-4 h-4" />
            <span>QUIT TO MENU</span>
          </button>
        </div>
      </div>
    </div>
  );
};
