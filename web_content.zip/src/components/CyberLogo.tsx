import { Shield, Terminal, Zap, Cpu, Sparkles } from 'lucide-react';

interface Props {
  customLogoUrl?: string | null;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
}

export default function CyberLogo({ customLogoUrl, size = 'md', showText = true }: Props) {
  const sizeMap = {
    sm: 'w-10 h-10',
    md: 'w-16 h-16',
    lg: 'w-24 h-24',
    xl: 'w-32 h-32',
  };

  const iconSizeMap = {
    sm: 20,
    md: 32,
    lg: 48,
    xl: 64,
  };

  return (
    <div className="flex items-center gap-4">
      {/* Animated Cyber Hologram Container */}
      <div className={`relative ${sizeMap[size]} flex items-center justify-center group select-none`}>
        {/* Outer Rotating Hex/Ring */}
        <div className="absolute inset-0 rounded-2xl border border-emerald-500/40 animate-pulse bg-emerald-950/20 backdrop-blur-md" />
        <div className="absolute -inset-1 rounded-2xl border border-cyan-400/30 border-dashed animate-[spin_12s_linear_infinite]" />
        
        {/* Glow halo */}
        <div className="absolute inset-0 rounded-2xl bg-gradient-to-tr from-emerald-500/20 via-cyan-500/10 to-transparent blur-md group-hover:blur-lg transition-all" />

        {/* Center Emblem or User Image */}
        <div className="relative z-10 w-full h-full flex items-center justify-center p-2 overflow-hidden rounded-xl bg-black/80 border border-emerald-500/60 shadow-[0_0_20px_rgba(0,255,136,0.3)]">
          {customLogoUrl ? (
            <img
              src={customLogoUrl}
              alt="GX Team Mehedi Vai Logo"
              referrerPolicy="no-referrer"
              className="w-full h-full object-contain filter drop-shadow-[0_0_8px_rgba(0,255,136,0.8)]"
            />
          ) : (
            <div className="relative flex items-center justify-center w-full h-full">
              {/* Cyber Shield Icon with Microchip overlay */}
              <Shield className="text-emerald-400 drop-shadow-[0_0_12px_#00ff88]" size={iconSizeMap[size]} />
              <div className="absolute inset-0 flex items-center justify-center">
                <Cpu className="text-cyan-300 w-1/2 h-1/2 animate-pulse" />
              </div>
              <Zap className="absolute -top-1 -right-1 text-amber-400 w-3 h-3 animate-bounce" />
            </div>
          )}
        </div>

        {/* Corner Cyber Brackets */}
        <span className="absolute -top-1 -left-1 w-2 h-2 border-t-2 border-l-2 border-emerald-400" />
        <span className="absolute -top-1 -right-1 w-2 h-2 border-t-2 border-r-2 border-cyan-400" />
        <span className="absolute -bottom-1 -left-1 w-2 h-2 border-b-2 border-l-2 border-cyan-400" />
        <span className="absolute -bottom-1 -right-1 w-2 h-2 border-b-2 border-r-2 border-emerald-400" />
      </div>

      {/* Typography Branding */}
      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            <span className="font-cyber text-lg md:text-xl font-black tracking-widest text-emerald-400 neon-glow-green">
              GX TEAM
            </span>
            <span className="px-2 py-0.5 text-[10px] uppercase font-bold tracking-wider rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              v4.5 CYBER
            </span>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-cyan-300/90 font-mono-cyber">
            <Sparkles className="w-3 h-3 text-cyan-400" />
            <span className="tracking-wide">MEHEDI VAI EDITION</span>
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
          </div>
        </div>
      )}
    </div>
  );
}
