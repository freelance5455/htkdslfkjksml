import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'motion/react';
import { ColorId, Tube } from '../types/game';
import { LIQUID_COLORS } from '../utils/colors';
import { TubeTheme, LiquidTheme } from '../utils/shopData';
import { Lock, Sparkles, HelpCircle } from 'lucide-react';

interface TubeViewProps {
  tube: Tube;
  index: number;
  isSelected: boolean;
  isHintSource: boolean;
  isHintDest: boolean;
  isInvalid: boolean;
  isCompleted: boolean;
  isPouringSource: boolean;
  isPouringDest: boolean;
  pouringProgress?: number;
  tiltAngle?: number;
  tubeTheme: TubeTheme;
  liquidTheme: LiquidTheme;
  showColorblindSymbols: boolean;
  onSelect: (index: number) => void;
  scale?: number;
}

export const TubeView: React.FC<TubeViewProps> = ({
  tube,
  index,
  isSelected,
  isHintSource,
  isHintDest,
  isInvalid,
  isCompleted,
  isPouringSource,
  isPouringDest,
  tiltAngle = 0,
  tubeTheme,
  liquidTheme,
  showColorblindSymbols,
  onSelect,
  scale = 1,
}) => {
  const { layers, isLocked, hiddenCount = 0 } = tube;
  const isFullAndUniform = layers.length === 4 && layers.every((c) => c === layers[0]);

  // Scaled dimensions
  const tubeWidth = Math.round(52 * scale);
  const tubeHeight = Math.round(180 * scale);
  const layerHeight = Math.round((tubeHeight - 16) / 4); // 4 layers fit with 16px headspace rim

  // Natural spout pivot origin
  const rotateOrigin = tiltAngle > 0 ? 'top right' : tiltAngle < 0 ? 'top left' : 'center top';

  // Settling state after receiving liquid or after pouring into this tube concludes
  const [isSettling, setIsSettling] = useState(false);
  const prevPouringDest = useRef(isPouringDest);
  const prevLayerCount = useRef(layers.length);

  useEffect(() => {
    if (
      (prevPouringDest.current && !isPouringDest) ||
      layers.length > prevLayerCount.current
    ) {
      setIsSettling(true);
      const timer = setTimeout(() => setIsSettling(false), 750);
      return () => clearTimeout(timer);
    }
    prevPouringDest.current = isPouringDest;
    prevLayerCount.current = layers.length;
  }, [isPouringDest, layers.length]);

  // Build layers ordered from TOP (surface) to BOTTOM (base)
  // layers[0] is at the bottom of the tube; layers[layers.length - 1] is at the top surface
  const layersFromTopToBottom = layers
    .map((colorId, originalIdx) => ({ colorId, originalIdx }))
    .reverse();

  // Bottom layer color for realistic pedestal caustics
  const bottomColorId = layers.length > 0 ? layers[0] : null;
  const bottomColorInfo = bottomColorId ? LIQUID_COLORS[bottomColorId] : null;

  return (
    <div
      className={`relative flex flex-col items-center select-none touch-manipulation cursor-pointer group ${
        isPouringSource ? 'z-50' : isSelected ? 'z-30' : 'z-10'
      }`}
      onClick={() => onSelect(index)}
      style={{
        width: `${tubeWidth + 10}px`,
        height: `${tubeHeight + 28}px`,
      }}
    >
      {/* Hint Indicator Arrow */}
      {isHintSource && (
        <motion.div
          initial={{ y: -6, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ repeat: Infinity, repeatType: 'reverse', duration: 0.5, ease: 'easeInOut' }}
          className="absolute -top-7 text-yellow-300 z-40 flex flex-col items-center drop-shadow-[0_0_10px_rgba(253,224,71,0.9)]"
        >
          <span className="text-[10px] font-black uppercase tracking-wider bg-gradient-to-r from-yellow-300 to-amber-400 text-slate-950 px-2.5 py-0.5 rounded-full shadow-lg border border-yellow-100">
            Pour
          </span>
          <span className="text-xs font-black -mt-0.5 text-yellow-300">▼</span>
        </motion.div>
      )}

      {isHintDest && (
        <motion.div
          initial={{ y: -6, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ repeat: Infinity, repeatType: 'reverse', duration: 0.5, ease: 'easeInOut' }}
          className="absolute -top-7 text-emerald-300 z-40 flex flex-col items-center drop-shadow-[0_0_10px_rgba(52,211,153,0.9)]"
        >
          <span className="text-[10px] font-black uppercase tracking-wider bg-gradient-to-r from-emerald-300 to-teal-400 text-slate-950 px-2.5 py-0.5 rounded-full shadow-lg border border-emerald-100">
            Here
          </span>
          <span className="text-xs font-black -mt-0.5 text-emerald-300">▼</span>
        </motion.div>
      )}

      {/* Main 3D Thick Glossy Cyan Glass Test Tube Vessel */}
      <motion.div
        id={`tube-${index}`}
        animate={{
          y: isPouringSource ? -44 : isSelected ? -20 : isPouringDest ? [0, 3, -1, 0] : 0,
          x: isPouringSource ? (tiltAngle > 0 ? 18 : -18) : isInvalid ? [-6, 6, -5, 5, -2, 2, 0] : 0,
          rotate: tiltAngle,
          scale: isPouringSource ? 1.06 : isSelected ? 1.04 : 1,
        }}
        transition={{
          y: isPouringDest
            ? { duration: 0.35, ease: 'easeOut' }
            : { type: 'spring', stiffness: 380, damping: 25 },
          x: isPouringSource
            ? { type: 'spring', stiffness: 350, damping: 26 }
            : { duration: 0.35, ease: 'easeInOut' },
          rotate: { type: 'spring', stiffness: 320, damping: 24 },
          scale: { duration: 0.18 },
        }}
        style={{
          transformOrigin: rotateOrigin,
          width: `${tubeWidth}px`,
          height: `${tubeHeight}px`,
          willChange: 'transform',
        }}
        className={`relative flex flex-col justify-end items-center rounded-b-[28px] rounded-t-[6px] transform-gpu transition-shadow duration-200 ${
          isSelected
            ? 'shadow-[0_0_32px_rgba(6,182,212,0.95)] ring-2 ring-cyan-300 ring-offset-2 ring-offset-slate-950/90'
            : isHintSource
            ? 'shadow-[0_0_26px_rgba(250,204,21,0.85)] ring-2 ring-yellow-400'
            : isHintDest
            ? 'shadow-[0_0_26px_rgba(52,211,153,0.85)] ring-2 ring-emerald-400'
            : isFullAndUniform
            ? 'shadow-[0_0_24px_rgba(6,182,212,0.85)] ring-1 ring-cyan-300/80'
            : 'shadow-[0_10px_28px_rgba(0,0,0,0.55)]'
        }`}
      >
        {/* Precise Coordinate Markers for PourStream Attachment */}
        <div id={`tube-spout-left-${index}`} className="absolute -top-1 left-0 w-2 h-2 pointer-events-none opacity-0" />
        <div id={`tube-spout-right-${index}`} className="absolute -top-1 right-0 w-2 h-2 pointer-events-none opacity-0" />
        <div id={`tube-mouth-${index}`} className="absolute -top-1 left-1/2 -translate-x-1/2 w-4 h-2 pointer-events-none opacity-0" />

        {/* Top Rim Flared 3D Polished Glass Oval Lip */}
        <div
          className="absolute -top-2.5 left-1/2 -translate-x-1/2 rounded-full z-30 pointer-events-none"
          style={{
            width: `${tubeWidth + 6}px`,
            height: '10px',
            background: 'linear-gradient(180deg, rgba(255,255,255,0.95) 0%, rgba(186,230,253,0.7) 45%, rgba(6,182,212,0.45) 100%)',
            border: '1.5px solid rgba(255, 255, 255, 0.95)',
            boxShadow: '0 2px 10px rgba(6, 182, 212, 0.4), inset 0 1px 2px rgba(255,255,255,0.9)',
          }}
        >
          <div className="w-full h-full rounded-full border border-white/80 bg-gradient-to-b from-white/70 to-transparent flex items-center justify-center">
            {/* Dark inner aperture looking down into the tube cavity */}
            <div className="w-[84%] h-[56%] rounded-full bg-slate-950/60 border border-cyan-300/40 shadow-inner" />
          </div>
          {/* Rim Specular Glint */}
          <div className="absolute top-0.5 left-2 w-3 h-1 rounded-full bg-white opacity-90 filter blur-[0.3px]" />
        </div>

        {/* Outer Cylinder: Thick Glossy Cyan Glass Wall & Specular Highlights */}
        <div
          className="absolute inset-0 rounded-b-[28px] rounded-t-[6px] border-[2.5px] border-cyan-200/80 pointer-events-none z-20 overflow-hidden backdrop-blur-[2px]"
          style={{
            background: 'linear-gradient(135deg, rgba(6,182,212,0.18) 0%, rgba(14,165,233,0.05) 35%, rgba(56,189,248,0.10) 70%, rgba(6,182,212,0.22) 100%)',
            boxShadow: 'inset 0 0 10px rgba(6,182,212,0.35), inset 2px 0 4px rgba(255,255,255,0.65), inset -2px 0 4px rgba(0,40,90,0.35)',
          }}
        >
          {/* Primary Razor-Sharp Crystal Specular Streak (Left) */}
          <div className="absolute left-1 top-2.5 bottom-6 w-1.5 rounded-full bg-gradient-to-b from-white via-white/85 to-white/15 pointer-events-none shadow-[0_0_7px_rgba(255,255,255,0.95)]" />

          {/* Secondary Inner Refraction Pin-Line (Left) */}
          <div className="absolute left-3.5 top-3.5 bottom-9 w-0.5 rounded-full bg-gradient-to-b from-cyan-100/60 via-white/30 to-transparent pointer-events-none" />

          {/* Secondary Ambient Glass Reflection (Right Edge) */}
          <div className="absolute right-1 top-2.5 bottom-7 w-1 rounded-full bg-gradient-to-b from-white/70 via-cyan-200/35 to-transparent pointer-events-none" />

          {/* Polished Diagonal Glass Light Sheen */}
          <div
            className="absolute inset-0 pointer-events-none opacity-70"
            style={{
              background: 'linear-gradient(125deg, transparent 35%, rgba(255,255,255,0.18) 46%, rgba(255,255,255,0.32) 50%, transparent 60%)',
            }}
          />

          {/* Thick Solid Glass Bottom Bulb U-Curve Lens Refraction */}
          <div className="absolute bottom-0 inset-x-0 h-4 rounded-b-[26px] border-b-[3px] border-white/95 pointer-events-none bg-gradient-to-t from-cyan-300/35 via-white/15 to-transparent shadow-[inset_0_-2px_6px_rgba(6,182,212,0.45)]" />
        </div>

        {/* Interior Fluid Chamber Mask (Padded inside for visible 3.5px thick glass walls) */}
        <div className="relative w-full h-full rounded-b-[25px] overflow-hidden flex flex-col justify-end px-[3.5px] pb-[6px] pt-[2px] z-10">
          {/* Render Liquid Layers from TOP to BOTTOM */}
          {layersFromTopToBottom.map(({ colorId, originalIdx }) => {
            const colorInfo = LIQUID_COLORS[colorId] || LIQUID_COLORS.blue;
            const isTopLayer = originalIdx === layers.length - 1; // Top surface of fluid column
            const isBottomLayer = originalIdx === 0; // Resting on curved tube bottom
            const isHidden = hiddenCount > originalIdx;

            // Check if layer directly BELOW this one has the same color (merge smoothly)
            const belowColor = originalIdx > 0 ? layers[originalIdx - 1] : null;
            const isSameAsBelow = belowColor === colorId && !isHidden;

            // Fluid theme subtle brightness/contrast enhancement without modifying color hue
            let themeGlow = '';
            if (liquidTheme.effect === 'gloss') {
              themeGlow = 'brightness-105';
            } else if (liquidTheme.effect === 'neon') {
              themeGlow = 'brightness-115 contrast-110';
            } else if (liquidTheme.effect === 'candy') {
              themeGlow = 'brightness-105';
            }

            // Dynamic wave duration & animation style
            const waveDuration = isPouringDest ? 0.28 : isSettling ? 0.8 : 2.0;

            return (
              <div
                key={`${originalIdx}-${colorId}`}
                className={`relative w-full overflow-hidden transition-[height,opacity] duration-250 ease-out ${
                  isBottomLayer ? 'rounded-b-[21px]' : ''
                } ${themeGlow}`}
                style={{
                  height: `${layerHeight}px`,
                  backgroundColor: isHidden ? '#334155' : colorInfo.baseHex,
                  backgroundImage: isHidden
                    ? 'linear-gradient(135deg, #1e293b 0%, #334155 50%, #475569 100%)'
                    : `linear-gradient(180deg, ${colorInfo.topHighlight} 0%, ${colorInfo.baseHex} 42%, ${colorInfo.bottomShadow} 100%)`,
                }}
              >
                {/* Wavy Animated Meniscus at top of top liquid layer */}
                {isTopLayer && !isHidden && (
                  <div
                    className="tube-liquid-surface absolute -top-3 left-0 w-full h-6 z-10 pointer-events-none overflow-visible"
                    style={{ animationDuration: `${waveDuration}s` }}
                  >
                    <svg
                      className="w-full h-full overflow-visible"
                      viewBox="0 0 100 24"
                      preserveAspectRatio="none"
                    >
                      <defs>
                        <linearGradient id={`surfaceShine-${index}-${originalIdx}`} x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.95" />
                          <stop offset="30%" stopColor="#ffffff" stopOpacity="0.8" />
                          <stop offset="65%" stopColor="#cffafe" stopOpacity="0.5" />
                          <stop offset="100%" stopColor="#0891b2" stopOpacity="0.25" />
                        </linearGradient>
                      </defs>

                      {/* Primary Wavy Liquid Body with Dynamic Fluid Physics */}
                      <motion.path
                        animate={{
                          d: isPouringDest
                            ? [
                                'M 0 12 Q 25 3, 50 12 T 100 12 L 100 24 L 0 24 Z',
                                'M 0 12 Q 25 21, 50 12 T 100 12 L 100 24 L 0 24 Z',
                                'M 0 12 Q 25 3, 50 12 T 100 12 L 100 24 L 0 24 Z',
                              ]
                            : isSettling
                            ? [
                                'M 0 12 Q 25 5, 50 12 T 100 12 L 100 24 L 0 24 Z',
                                'M 0 12 Q 25 18, 50 12 T 100 12 L 100 24 L 0 24 Z',
                                'M 0 12 Q 25 8, 50 12 T 100 12 L 100 24 L 0 24 Z',
                                'M 0 12 Q 25 15, 50 12 T 100 12 L 100 24 L 0 24 Z',
                                'M 0 12 Q 25 12, 50 12 T 100 12 L 100 24 L 0 24 Z',
                              ]
                            : isPouringSource && tiltAngle !== 0
                            ? tiltAngle > 0
                              ? 'M 0 18 Q 50 14, 100 6 L 100 24 L 0 24 Z'
                              : 'M 0 6 Q 50 14, 100 18 L 100 24 L 0 24 Z'
                            : [
                                'M 0 12 Q 30 7, 50 12 T 100 12 L 100 24 L 0 24 Z',
                                'M 0 12 Q 30 17, 50 12 T 100 12 L 100 24 L 0 24 Z',
                                'M 0 12 Q 30 7, 50 12 T 100 12 L 100 24 L 0 24 Z',
                              ],
                        }}
                        transition={{
                          repeat: isSettling || (isPouringSource && tiltAngle !== 0) ? 0 : Infinity,
                          duration: waveDuration,
                          ease: isSettling ? 'easeOut' : 'easeInOut',
                        }}
                        fill={colorInfo.topHighlight}
                        opacity={0.98}
                      />

                      {/* Specular Wave Crest Meniscus Line */}
                      <motion.path
                        animate={{
                          d: isPouringDest
                            ? [
                                'M 0 12 Q 25 3, 50 12 T 100 12',
                                'M 0 12 Q 25 21, 50 12 T 100 12',
                                'M 0 12 Q 25 3, 50 12 T 100 12',
                              ]
                            : isSettling
                            ? [
                                'M 0 12 Q 25 5, 50 12 T 100 12',
                                'M 0 12 Q 25 18, 50 12 T 100 12',
                                'M 0 12 Q 25 8, 50 12 T 100 12',
                                'M 0 12 Q 25 15, 50 12 T 100 12',
                                'M 0 12 Q 25 12, 50 12 T 100 12',
                              ]
                            : isPouringSource && tiltAngle !== 0
                            ? tiltAngle > 0
                              ? 'M 0 18 Q 50 14, 100 6'
                              : 'M 0 6 Q 50 14, 100 18'
                            : [
                                'M 0 12 Q 30 7, 50 12 T 100 12',
                                'M 0 12 Q 30 17, 50 12 T 100 12',
                                'M 0 12 Q 30 7, 50 12 T 100 12',
                              ],
                        }}
                        transition={{
                          repeat: isSettling || (isPouringSource && tiltAngle !== 0) ? 0 : Infinity,
                          duration: waveDuration,
                          ease: isSettling ? 'easeOut' : 'easeInOut',
                        }}
                        fill="none"
                        stroke={`url(#surfaceShine-${index}-${originalIdx})`}
                        strokeWidth="2.5"
                        strokeLinecap="round"
                        opacity={0.95}
                      />
                    </svg>
                  </div>
                )}

                {/* 3D Cylindrical Volumetric Light & Curvature Depth Gradient */}
                <div
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    background: `linear-gradient(90deg, rgba(255,255,255,0.45) 0%, rgba(255,255,255,0.6) 12%, rgba(255,255,255,0.15) 26%, transparent 48%, rgba(0,0,0,0.06) 72%, rgba(0,0,0,0.25) 100%)`,
                  }}
                />

                {/* Diagonal Glossy Fluid Sheen */}
                <div
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    background: 'linear-gradient(135deg, rgba(255,255,255,0.25) 0%, transparent 40%, rgba(255,255,255,0.1) 100%)',
                  }}
                />

                {/* Vertical Ambient Depth Falloff */}
                <div
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    background: `linear-gradient(180deg, rgba(255,255,255,0.16) 0%, transparent 40%, rgba(0,0,0,0.22) 100%)`,
                  }}
                />

                {/* Bottom Layer Bulb Base Curved Shadow & Highlight */}
                {isBottomLayer && (
                  <div className="absolute bottom-0 inset-x-1 h-3.5 rounded-b-full pointer-events-none border-b border-white/40 bg-gradient-to-t from-black/30 to-transparent" />
                )}

                {/* Stardust / Micro-Bubbles for Galaxy & Fantasy themes */}
                {(liquidTheme.effect === 'galaxy' || liquidTheme.effect === 'fantasy') && !isHidden && (
                  <div className="absolute inset-0 pointer-events-none overflow-hidden">
                    <div className="absolute w-1 h-1 bg-white rounded-full top-2 left-3 animate-ping opacity-80" />
                    <div className="absolute w-1 h-1 bg-yellow-200 rounded-full bottom-2 right-4 opacity-85" />
                    <div className="absolute w-1.5 h-1.5 bg-cyan-200 rounded-full top-3 right-2 opacity-70" />
                  </div>
                )}

                {/* Hidden Mystery Layer Icon */}
                {isHidden && (
                  <div className="absolute inset-0 flex items-center justify-center text-slate-400">
                    <HelpCircle className="w-4 h-4 animate-pulse" />
                  </div>
                )}

                {/* Colorblind Accessible Symbol */}
                {showColorblindSymbols && !isHidden && (
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none">
                    <span className="text-[11px] font-black text-white drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)] bg-black/40 border border-white/20 rounded px-1">
                      {colorInfo.symbol}
                    </span>
                  </div>
                )}

                {/* Layer Separator Line at BOTTOM of layer (Only if DIFFERENT color from layer below) */}
                {!isBottomLayer && !isSameAsBelow && (
                  <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-slate-950/40 border-b border-white/30 z-10 pointer-events-none shadow-[0_1px_2px_rgba(0,0,0,0.4)]" />
                )}
              </div>
            );
          })}

          {/* Empty Tube subtle interior placeholder */}
          {layers.length === 0 && (
            <div className="w-full h-full flex items-center justify-center opacity-30">
              <div className="w-1.5 h-1.5 rounded-full bg-cyan-200/40" />
            </div>
          )}
        </div>

        {/* Dynamic Water Splash Particles when liquid drops in */}
        {isPouringDest && (
          <div className="absolute top-[12%] left-1/2 -translate-x-1/2 w-10 h-8 pointer-events-none z-30 flex justify-center items-center">
            {/* Impact Center Flare */}
            <motion.div
              initial={{ scale: 0.6, opacity: 0.9 }}
              animate={{ scale: [0.8, 1.4, 0.9], opacity: [0.9, 1, 0.3] }}
              transition={{ repeat: Infinity, duration: 0.28, ease: 'easeOut' }}
              className="w-3 h-3 rounded-full bg-white shadow-[0_0_10px_#fff]"
            />
            {/* Splash Droplets jumping up */}
            <motion.div
              animate={{ y: [-4, -14, -2], x: [-6, -10, -12], opacity: [1, 0.8, 0] }}
              transition={{ repeat: Infinity, duration: 0.3, ease: 'easeOut' }}
              className="absolute w-1.5 h-1.5 rounded-full bg-cyan-100 shadow-[0_0_4px_#cffafe]"
            />
            <motion.div
              animate={{ y: [-4, -16, -2], x: [4, 8, 10], opacity: [1, 0.8, 0] }}
              transition={{ repeat: Infinity, duration: 0.26, ease: 'easeOut', delay: 0.05 }}
              className="absolute w-1.5 h-1.5 rounded-full bg-white shadow-[0_0_4px_#fff]"
            />
          </div>
        )}

        {/* Settling Ripples after Pour Finishes */}
        {isSettling && !isPouringDest && (
          <motion.div
            initial={{ opacity: 0.8, scale: 0.8 }}
            animate={{ opacity: 0, scale: 1.3 }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
            className="absolute top-[20%] left-1/2 -translate-x-1/2 w-6 h-2 rounded-full border border-white/60 pointer-events-none z-30"
          />
        )}

        {/* Tube Complete Sparkle Ring */}
        {isFullAndUniform && isCompleted && (
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: [1, 1.2, 1], opacity: [0.85, 1, 0.85] }}
            transition={{ repeat: Infinity, duration: 2, ease: 'easeInOut' }}
            className="absolute -top-3.5 -right-2.5 text-yellow-300 pointer-events-none z-30"
          >
            <Sparkles className="w-5 h-5 drop-shadow-[0_0_8px_rgba(253,224,71,0.95)] fill-yellow-400" />
          </motion.div>
        )}

        {/* Locked Tube Lock Overlay */}
        {isLocked && (
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-[2px] rounded-b-[30px] rounded-t-[8px] z-30 flex flex-col items-center justify-center p-2 text-center border border-amber-500/50 shadow-inner">
            <Lock className="w-6 h-6 text-amber-400 mb-1 animate-bounce drop-shadow-[0_0_6px_rgba(251,191,36,0.6)]" />
            <span className="text-[10px] font-black text-amber-200 leading-tight uppercase tracking-wider">
              Locked
            </span>
          </div>
        )}
      </motion.div>

      {/* Tube Base Pedestal Shadow with Cyan Glass & Liquid Caustic Tint */}
      <div
        className="mt-1 rounded-full blur-[2px] transition-all duration-300"
        style={{
          width: `${tubeWidth * (isSelected ? 0.75 : isPouringSource ? 0.65 : 0.92)}px`,
          height: '6px',
          backgroundColor: bottomColorInfo ? bottomColorInfo.glowHex : 'rgba(6, 182, 212, 0.5)',
          opacity: isPouringSource ? 0.15 : isSelected ? 0.25 : bottomColorInfo ? 0.55 : 0.45,
          boxShadow: bottomColorInfo
            ? `0 0 10px ${bottomColorInfo.glowHex}`
            : '0 0 8px rgba(6, 182, 212, 0.4)',
        }}
      />
    </div>
  );
};
