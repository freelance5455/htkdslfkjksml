import React from 'react';
import { AssetData, ThemeMode } from '../types/market';
import { 
  TrendingUp, 
  TrendingDown, 
  BellPlus, 
  Sparkles, 
  Volume2, 
  Star,
  Coins,
  DollarSign,
  Flame,
  Layers
} from 'lucide-react';

interface AssetCardProps {
  asset: AssetData;
  onOpenAlertModal: (asset: AssetData) => void;
  onOpenDetailModal: (asset: AssetData) => void;
  onQuickVoiceAnnounce: (asset: AssetData) => void;
  hasActiveAlerts?: boolean;
  isFavorite?: boolean;
  onToggleFavorite?: (assetId: string) => void;
  theme?: ThemeMode;
}

export const AssetCard: React.FC<AssetCardProps> = ({
  asset,
  onOpenAlertModal,
  onOpenDetailModal,
  onQuickVoiceAnnounce,
  hasActiveAlerts = false,
  isFavorite = false,
  onToggleFavorite,
  theme = 'dark',
}) => {
  const isLight = theme === 'light';
  const isPositive = asset.change24h >= 0;

  // Compute sparkline path
  const sparklineData = asset.sparkline && asset.sparkline.length > 1 ? asset.sparkline : [asset.low24h, asset.price, asset.high24h];
  const min = Math.min(...sparklineData);
  const max = Math.max(...sparklineData);
  const range = max - min || 1;
  const width = 120;
  const height = 40;

  const points = sparklineData
    .map((val, idx) => {
      const x = (idx / (sparklineData.length - 1)) * width;
      const y = height - ((val - min) / range) * (height - 8) - 4;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ');

  const getCategoryIcon = () => {
    switch (asset.category) {
      case 'crypto':
        return <Coins className="w-3.5 h-3.5 text-amber-500" />;
      case 'forex':
        return <DollarSign className="w-3.5 h-3.5 text-emerald-500" />;
      case 'commodity':
        return <Flame className="w-3.5 h-3.5 text-orange-500" />;
      case 'stock':
        return <Layers className="w-3.5 h-3.5 text-blue-500" />;
    }
  };

  const rangeSpan = asset.high24h - asset.low24h || 1;
  const currentPosPct = Math.min(100, Math.max(0, ((asset.price - asset.low24h) / rangeSpan) * 100));

  return (
    <div className={`group relative rounded-2xl border transition-all duration-300 flex flex-col justify-between overflow-hidden ${
      isLight
        ? 'bg-white border-slate-200/90 hover:border-slate-300 shadow-sm hover:shadow-md'
        : 'bg-slate-900/80 border-slate-800/90 hover:border-slate-700/80 hover:shadow-xl hover:shadow-black/40'
    }`}>
      
      {/* Top ambient highlight on tick */}
      <div className={`absolute top-0 left-0 right-0 h-[2px] transition-all duration-500 ${
        asset.tickDirection === 'up'
          ? 'bg-gradient-to-r from-emerald-500/0 via-emerald-400 to-emerald-500/0 opacity-100'
          : asset.tickDirection === 'down'
          ? 'bg-gradient-to-r from-rose-500/0 via-rose-400 to-rose-500/0 opacity-100'
          : 'opacity-0'
      }`} />

      {/* Card Header */}
      <div className="p-4 sm:p-5">
        <div className="flex items-start justify-between gap-2 mb-3">
          <div className="flex items-center gap-2.5">
            <div className={`w-9 h-9 rounded-xl border flex items-center justify-center font-bold text-xs font-mono shadow-inner ${
              isLight 
                ? 'bg-slate-100 border-slate-200 text-slate-800' 
                : 'bg-slate-800/80 border-slate-700/50 text-white'
            }`}>
              {asset.symbol.slice(0, 4)}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className={`font-bold text-sm transition-colors ${
                  isLight 
                    ? 'text-slate-900 group-hover:text-amber-600' 
                    : 'text-slate-100 group-hover:text-amber-400'
                }`}>
                  {asset.symbol}
                </span>
                {hasActiveAlerts && (
                  <span className="flex h-2 w-2 rounded-full bg-amber-400 animate-pulse" title="Alerte vocale armée" />
                )}
              </div>
              <span className={`text-xs block truncate max-w-[120px] sm:max-w-[150px] ${
                isLight ? 'text-slate-500' : 'text-slate-400'
              }`}>
                {asset.name}
              </span>
            </div>
          </div>

          {/* Favorite star & category pill & audio quick announcement */}
          <div className="flex items-center gap-1">
            {onToggleFavorite && (
              <button
                onClick={() => onToggleFavorite(asset.id)}
                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                  isFavorite
                    ? 'text-amber-400 hover:text-amber-500'
                    : isLight
                    ? 'text-slate-300 hover:text-slate-500'
                    : 'text-slate-600 hover:text-slate-300'
                }`}
                title={isFavorite ? 'Retirer de la watchlist' : 'Ajouter à la watchlist'}
              >
                <Star className={`w-4 h-4 ${isFavorite ? 'fill-amber-400' : ''}`} />
              </button>
            )}

            <button
              onClick={() => onQuickVoiceAnnounce(asset)}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                isLight 
                  ? 'hover:bg-amber-50 text-slate-400 hover:text-amber-600' 
                  : 'bg-slate-800/50 hover:bg-amber-500/20 text-slate-400 hover:text-amber-300'
              }`}
              title="Annoncer vocalement le prix actuel"
            >
              <Volume2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Price & 24h Change */}
        <div className="flex items-baseline justify-between mb-4">
          <div>
            <div className={`font-mono text-xl sm:text-2xl font-bold tracking-tight transition-all duration-300 ${
              asset.tickDirection === 'up'
                ? 'text-emerald-500 scale-[1.02]'
                : asset.tickDirection === 'down'
                ? 'text-rose-500 scale-[1.02]'
                : isLight
                ? 'text-slate-900'
                : 'text-white'
            }`}>
              ${asset.price.toLocaleString(undefined, {
                minimumFractionDigits: asset.price < 1 ? 4 : 2,
                maximumFractionDigits: asset.price < 1 ? 4 : 2,
              })}
            </div>
            <div className={`text-[11px] font-mono ${isLight ? 'text-slate-400' : 'text-slate-500'}`}>
              Vol: {asset.volume24h}
            </div>
          </div>

          {/* Change Badge */}
          <div className={`flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-mono font-bold border ${
            isPositive
              ? isLight
                ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
              : isLight
              ? 'bg-rose-50 border-rose-200 text-rose-700'
              : 'bg-rose-500/10 border-rose-500/20 text-rose-400'
          }`}>
            {isPositive ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
            <span>{isPositive ? '+' : ''}{asset.change24h}%</span>
          </div>
        </div>

        {/* Mini Sparkline Chart */}
        <div className="h-10 w-full mb-3 flex items-center justify-center">
          <svg className="w-full h-full overflow-visible" viewBox={`0 0 ${width} ${height}`}>
            <defs>
              <linearGradient id={`gradient-${asset.id}-${theme}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={isPositive ? '#10b981' : '#f43f5e'} stopOpacity={isLight ? 0.2 : 0.4} />
                <stop offset="100%" stopColor={isPositive ? '#10b981' : '#f43f5e'} stopOpacity="0.0" />
              </linearGradient>
            </defs>
            <polygon
              points={`0,${height} ${points} ${width},${height}`}
              fill={`url(#gradient-${asset.id}-${theme})`}
            />
            <polyline
              fill="none"
              stroke={isPositive ? '#10b981' : '#f43f5e'}
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              points={points}
            />
          </svg>
        </div>

        {/* 24h Range Bar */}
        <div className="space-y-1 mb-2">
          <div className={`flex justify-between text-[10px] font-mono ${
            isLight ? 'text-slate-500' : 'text-slate-400'
          }`}>
            <span>B: ${asset.low24h.toLocaleString(undefined, { maximumFractionDigits: asset.low24h < 1 ? 4 : 2 })}</span>
            <span className={isLight ? 'text-slate-400' : 'text-slate-500'}>24H RANGE</span>
            <span>H: ${asset.high24h.toLocaleString(undefined, { maximumFractionDigits: asset.high24h < 1 ? 4 : 2 })}</span>
          </div>
          <div className={`relative w-full h-1.5 rounded-full overflow-hidden ${
            isLight ? 'bg-slate-100' : 'bg-slate-800'
          }`}>
            <div
              className={`absolute top-0 bottom-0 rounded-full transition-all duration-300 ${
                isPositive ? 'bg-emerald-500' : 'bg-rose-500'
              }`}
              style={{ left: '0%', width: `${currentPosPct}%` }}
            />
          </div>
        </div>
      </div>

      {/* Card Footer Actions */}
      <div className={`grid grid-cols-2 gap-2 p-3 border-t ${
        isLight ? 'bg-slate-50/70 border-slate-100' : 'bg-slate-950/60 border-slate-800/80'
      }`}>
        <button
          onClick={() => onOpenAlertModal(asset)}
          className={`flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer shadow-sm ${
            isLight
              ? 'bg-amber-50 hover:bg-amber-100 border-amber-200 text-amber-800'
              : 'bg-amber-500/10 hover:bg-amber-500/20 border-amber-500/30 text-amber-300'
          }`}
        >
          <BellPlus className="w-3.5 h-3.5 text-amber-500" />
          <span>Alerte Vocale</span>
        </button>

        <button
          onClick={() => onOpenDetailModal(asset)}
          className={`flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
            isLight
              ? 'bg-white hover:bg-slate-100 border-slate-200 text-slate-700 hover:text-slate-900'
              : 'bg-slate-800/70 hover:bg-slate-800 border border-slate-700/80 text-slate-200 hover:text-white'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-purple-500" />
          <span>Graph & IA</span>
        </button>
      </div>
    </div>
  );
};
