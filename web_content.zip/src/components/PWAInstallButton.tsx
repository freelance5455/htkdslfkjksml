import React, { useState } from 'react';
import { Check, Copy, ExternalLink, Smartphone, X } from 'lucide-react';
import { UILanguage } from '../types/pdf';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  lang: UILanguage;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ lang }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);
  const [copied, setCopied] = useState(false);

  if (isInstalled) {
    return null;
  }

  const installUrl =
    typeof window !== 'undefined' ? window.location.origin : '';
  const isInIframe =
    typeof window !== 'undefined' && window.self !== window.top;

  const handleClick = async () => {
    if (isInstallable && !isInIframe) {
      const accepted = await install();
      if (!accepted) {
        setShowGuide(true);
      }
      return;
    }
    setShowGuide(true);
  };

  const handleCopyLink = async () => {
    if (!installUrl) return;
    try {
      await navigator.clipboard.writeText(installUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback ignored if clipboard blocked
    }
  };

  const label = lang === 'bn' ? 'অ্যাপ ইনস্টল' : 'Install App';

  return (
    <>
      <button
        type="button"
        onClick={handleClick}
        data-tooltip={
          lang === 'bn'
            ? 'মোবাইল বা কম্পিউটারে অ্যাপ ইনস্টল করুন'
            : 'Install LipiPDF as an app'
        }
        className="inline-flex items-center gap-1.5 px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg text-xs font-semibold text-blue-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
      >
        <Smartphone className="w-3.5 h-3.5 text-blue-700 shrink-0" />
        <span>{label}</span>
      </button>

      {showGuide && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-[1px] p-4"
          onClick={() => setShowGuide(false)}
        >
          <div
            className="w-full max-w-md bg-white border border-slate-200 rounded-2xl shadow-xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-blue-700 text-white flex items-center justify-center shrink-0">
                  <Smartphone className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    {lang === 'bn'
                      ? 'LipiPDF অ্যাপ ইনস্টল করুন'
                      : 'Install LipiPDF App'}
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    {lang === 'bn'
                      ? 'অফলাইনে ও দ্রুত ব্যবহারের জন্য ডিভাইসে ইনস্টল করুন'
                      : 'Add to your home screen or desktop for offline access'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              {isInstallable && !isInIframe && (
                <button
                  type="button"
                  onClick={async () => {
                    const ok = await install();
                    if (ok) setShowGuide(false);
                  }}
                  className="w-full py-2.5 px-4 bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                >
                  {lang === 'bn'
                    ? 'এখনই সরাসরি ইনস্টল করুন'
                    : 'Install Directly Now'}
                </button>
              )}

              {isInIframe && installUrl && (
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 space-y-2">
                  <p className="text-[11px] text-amber-900 leading-relaxed font-medium">
                    {lang === 'bn'
                      ? 'প্রিভিউ উইন্ডোর ভেতর থেকে ব্রাউজার অ্যাপ ইনস্টল করতে দেয় না। নিচের বাটনে চাপ দিয়ে সরাসরি নতুন ট্যাবে খুলুন, তারপর ইনস্টল করুন:'
                      : 'Browsers block app installation inside an embedded preview frame. Open the app directly in a new tab to install:'}
                  </p>
                  <a
                    href={installUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full inline-flex items-center justify-center gap-1.5 py-2 px-3 bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold rounded-lg transition-colors"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>
                      {lang === 'bn'
                        ? 'নতুন ট্যাবে খুলে ইনস্টল করুন'
                        : 'Open in New Tab to Install'}
                    </span>
                  </a>
                </div>
              )}

              <div>
                <div className="text-[11px] font-semibold text-slate-500 mb-1.5">
                  {lang === 'bn'
                    ? 'অ্যাপ ইনস্টল করার ডাইরেক্ট লিংক'
                    : 'Direct App Install Link'}
                </div>
                <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2">
                  <span className="text-xs font-mono text-slate-700 truncate flex-1 select-all">
                    {installUrl}
                  </span>
                  <button
                    type="button"
                    onClick={handleCopyLink}
                    className="inline-flex items-center gap-1 px-2.5 py-1 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-[11px] font-semibold text-slate-700 shrink-0 cursor-pointer"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-600" />
                        <span>{lang === 'bn' ? 'কপি হয়েছে' : 'Copied'}</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>{lang === 'bn' ? 'কপি' : 'Copy'}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2.5 text-xs text-slate-700 leading-relaxed">
                {isIOS ? (
                  <>
                    <div className="font-semibold text-slate-900">
                      iPhone / iPad (Safari):
                    </div>
                    <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-600">
                      <li>
                        {lang === 'bn'
                          ? 'উপরের লিংকটি Safari ব্রাউজারে খুলুন।'
                          : 'Open the link above in Safari.'}
                      </li>
                      <li>
                        {lang === 'bn'
                          ? 'নিচের Share বাটনে ট্যাপ করুন।'
                          : 'Tap the Share button in the Safari toolbar.'}
                      </li>
                      <li>
                        {lang === 'bn'
                          ? '"Add to Home Screen" সিলেক্ট করে Add চাপুন।'
                          : 'Scroll down and tap "Add to Home Screen".'}
                      </li>
                    </ol>
                  </>
                ) : (
                  <>
                    <div className="font-semibold text-slate-900">
                      {lang === 'bn'
                        ? 'Android (Chrome) / কম্পিউটার:'
                        : 'Android (Chrome) / Desktop:'}
                    </div>
                    <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-600">
                      <li>
                        {lang === 'bn'
                          ? 'নতুন ট্যাবে Chrome দিয়ে সরাসরি অ্যাপটি খুলুন।'
                          : 'Open the app directly in Chrome or Edge in a new tab.'}
                      </li>
                      <li>
                        {lang === 'bn'
                          ? 'Chrome-এ "অ্যাপ ইনস্টল" বাটন বা উপরের ডানদিকের ⋮ মেনু চাপুন।'
                          : 'Tap "Install App" or the ⋮ menu on Android (or the Install icon in the desktop address bar).'}
                      </li>
                      <li>
                        {lang === 'bn'
                          ? '"Install app" / "Add to Home screen" সিলেক্ট করুন।'
                          : 'Select "Install app" or "Add to Home screen".'}
                      </li>
                    </ol>
                  </>
                )}
              </div>
            </div>

            <div className="px-5 py-3 bg-slate-50 border-t border-slate-100 flex justify-end">
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                className="px-4 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 cursor-pointer"
              >
                {lang === 'bn' ? 'বন্ধ করুন' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
