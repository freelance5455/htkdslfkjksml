import React, { useState } from 'react';
import { Download, Share, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import type { Language } from '../types/study';

interface PWAInstallButtonProps {
  lang?: Language;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ lang = 'bn' }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={install}
        className="inline-flex min-h-[40px] items-center gap-2 rounded-xl bg-sky-500/90 px-4 py-2 text-xs font-semibold text-slate-950 shadow-sm transition hover:bg-sky-400 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-300 whitespace-nowrap shrink-0"
      >
        <Download className="h-4 w-4" aria-hidden="true" />
        <span>{lang === 'bn' ? 'অ্যাপ ইনস্টল' : 'Install App'}</span>
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowIOSGuide(true)}
          className="inline-flex min-h-[40px] items-center gap-2 rounded-xl border border-white/25 bg-white/10 px-3.5 py-2 text-xs font-medium text-white transition hover:bg-white/20 whitespace-nowrap shrink-0"
        >
          <Share className="h-3.5 w-3.5" aria-hidden="true" />
          <span>{lang === 'bn' ? 'iOS-এ ইনস্টল' : 'Install on iOS'}</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 p-4 backdrop-blur-sm">
            <div className="liquid-glass-elevated w-full max-w-sm rounded-2xl p-6 text-slate-100">
              <div className="flex items-center justify-between gap-4">
                <h3 className="text-base font-semibold text-white">
                  {lang === 'bn' ? 'iPhone / iPad ইনস্টল' : 'Install on iPhone / iPad'}
                </h3>
                <button
                  type="button"
                  onClick={() => setShowIOSGuide(false)}
                  aria-label={lang === 'bn' ? 'বন্ধ করুন' : 'Close'}
                  className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-300 hover:bg-white/10 hover:text-white"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <ol className="mt-4 space-y-2.5 text-sm leading-relaxed text-slate-200">
                {lang === 'bn' ? (
                  <>
                    <li>১. Share বাটনে ট্যাপ করুন।</li>
                    <li>২. Add to Home Screen নির্বাচন করুন।</li>
                    <li>৩. Add-এ ট্যাপ করুন।</li>
                  </>
                ) : (
                  <>
                    <li>1. Tap Share in Safari.</li>
                    <li>2. Select Add to Home Screen.</li>
                    <li>3. Tap Add.</li>
                  </>
                )}
              </ol>
              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="mt-5 w-full min-h-[44px] rounded-xl bg-white/15 py-2.5 text-sm font-medium text-white transition hover:bg-white/25"
              >
                {lang === 'bn' ? 'ঠিক আছে' : 'Done'}
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
