import React, { useState } from 'react';
import { usePWAInstall } from './usePWAInstall';
import { Smartphone, Download, Check, X, Sparkles, Layers } from 'lucide-react';

interface Props {
  onOpenWidgetSim?: () => void;
}

export const PWAInstallButton: React.FC<Props> = ({ onOpenWidgetSim }) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [showInfoModal, setShowInfoModal] = useState(false);

  return (
    <>
      <div className="flex items-center gap-2">
        {onOpenWidgetSim && (
          <button
            onClick={onOpenWidgetSim}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/60 rounded-lg transition-colors whitespace-nowrap shrink-0"
            title="Ver simulación de Widgets Android"
          >
            <Layers className="w-3.5 h-3.5 text-indigo-400" />
            <span>Widgets APK</span>
          </button>
        )}

        {isInstalled ? (
          <div className="flex items-center gap-1.5 px-2.5 py-1 text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded-lg whitespace-nowrap shrink-0">
            <Check className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Instalado como APK</span>
          </div>
        ) : isInstallable ? (
          <button
            onClick={install}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 rounded-lg shadow-sm shadow-indigo-500/20 active:scale-[0.98] transition whitespace-nowrap shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Instalar APK</span>
          </button>
        ) : (
          <button
            onClick={() => setShowInfoModal(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/60 hover:bg-slate-800 border border-slate-700/50 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <Smartphone className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden sm:inline">Modo APK</span>
          </button>
        )}
      </div>

      {showInfoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl relative text-left">
            <button
              onClick={() => setShowInfoModal(false)}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-pink-500 flex items-center justify-center text-white font-bold shadow-lg shadow-indigo-500/20">
                AS
              </div>
              <div>
                <h3 className="text-base font-semibold text-white">AuraSound APK & PWA</h3>
                <p className="text-xs text-slate-400">Reproductor Audiophile Nativo</p>
              </div>
            </div>

            <div className="space-y-3 text-xs text-slate-300 mb-5">
              <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/50">
                <p className="font-medium text-indigo-300 mb-1 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  {isAndroid ? 'Instalación en Android (APK Web)' : isIOS ? 'Instalación en iOS / Safari' : 'Instalación en Escritorio / Móvil'}
                </p>
                {isAndroid ? (
                  <p className="leading-relaxed">
                    Toca los tres puntos del navegador Chrome (⋮) y selecciona <strong>"Instalar aplicación"</strong> o <strong>"Añadir a la pantalla de inicio"</strong> para generar el paquete APK con soporte para widgets y controles de bloqueo.
                  </p>
                ) : isIOS ? (
                  <p className="leading-relaxed">
                    Pulsa el botón <strong>Compartir</strong> en Safari y selecciona <strong>"Añadir a la pantalla de inicio"</strong> para disfrutar de reproducción a pantalla completa sin barras.
                  </p>
                ) : (
                  <p className="leading-relaxed">
                    Haz clic en el icono de instalación en la barra de direcciones de tu navegador para ejecutar AuraSound como aplicación nativa independiente sin marcos.
                  </p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400">
                <div className="p-2.5 rounded-lg bg-slate-800/40 border border-slate-800">
                  <span className="text-white block font-medium">Formatos Hi-Fi</span>
                  MP3, OGG, WAV, FLAC 24/32-bit
                </div>
                <div className="p-2.5 rounded-lg bg-slate-800/40 border border-slate-800">
                  <span className="text-white block font-medium">DSP Avanzado</span>
                  10 Bandas + Reverb + Sub-punch
                </div>
                <div className="p-2.5 rounded-lg bg-slate-800/40 border border-slate-800">
                  <span className="text-white block font-medium">Controles Remotos</span>
                  Notificaciones, Pantalla Bloqueo
                </div>
                <div className="p-2.5 rounded-lg bg-slate-800/40 border border-slate-800">
                  <span className="text-white block font-medium">Widgets</span>
                  Widgets interactivos en inicio
                </div>
              </div>
            </div>

            <button
              onClick={() => setShowInfoModal(false)}
              className="w-full py-2.5 px-4 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-xl transition"
            >
              Cerrar
            </button>
          </div>
        </div>
      )}
    </>
  );
};
