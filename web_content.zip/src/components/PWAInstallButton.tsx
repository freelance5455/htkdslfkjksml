import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

interface PWAInstallButtonProps {
  onOpenAPKStudio?: () => void;
  compact?: boolean;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  onOpenAPKStudio,
  compact = false,
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  const handleClick = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (!accepted && onOpenAPKStudio) {
        onOpenAPKStudio();
      }
    } else if (isIOS) {
      setShowIOSGuide(true);
    } else if (onOpenAPKStudio) {
      onOpenAPKStudio();
    }
  };

  if (isInstalled && !onOpenAPKStudio) {
    return null;
  }

  return (
    <>
      <button
        onClick={handleClick}
        className={`flex items-center gap-1.5 rounded-lg bg-[#1e2028] hover:bg-[#262932] border border-[#ff2a2a]/40 text-white font-headline uppercase tracking-wider transition-all whitespace-nowrap shrink-0 cursor-pointer ${
          compact ? 'h-9 px-3 text-xs' : 'h-10 px-3.5 text-xs font-semibold'
        }`}
        title="Install Android WebAPK or Open APK Build Studio"
      >
        <span className="material-symbols-outlined text-[18px] text-[#ff2a2a]">android</span>
        <span>{isInstalled ? 'APK Studio' : isInstallable ? 'Install APK / App' : 'Create APK'}</span>
      </button>

      {showIOSGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-xl bg-[#16181f] border border-[#4a3836]/50 p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#4a3836]/30">
              <h3 className="font-headline text-lg font-bold uppercase text-white tracking-wide">
                Install DCA Ops on iOS / Mobile
              </h3>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="text-[#8e8281] hover:text-white"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>
            <div className="mt-4 space-y-3 text-sm text-[#c9bfc0]">
              <p>
                1. Tap the <strong className="text-white">Share</strong> icon in your browser toolbar.
              </p>
              <p>
                2. Scroll down and select <strong className="text-white">Add to Home Screen</strong>.
              </p>
              <p>
                3. Or open the <strong className="text-[#ff2a2a]">Android APK Build Studio</strong> to export the TWA / Capacitor Android package.
              </p>
            </div>
            <div className="mt-5 flex gap-2">
              {onOpenAPKStudio && (
                <button
                  onClick={() => {
                    setShowIOSGuide(false);
                    onOpenAPKStudio();
                  }}
                  className="flex-1 rounded-lg bg-[#ff2a2a] py-2.5 font-headline text-xs font-bold uppercase tracking-wider text-white hover:bg-red-600 transition-colors"
                >
                  Open APK Studio
                </button>
              )}
              <button
                onClick={() => setShowIOSGuide(false)}
                className="flex-1 rounded-lg bg-[#262932] py-2.5 font-headline text-xs font-bold uppercase tracking-wider text-white hover:bg-[#31343f] transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2.5 rounded-lg bg-[#1e2028] border border-[#ff6b4a] px-3.5 py-2 text-xs font-medium text-white shadow-xl">
      <span className="h-2 w-2 rounded-full bg-[#ff6b4a] animate-pulse" />
      <span>Offline Mode Active · Using local cached DCA roster &amp; biometric ledger</span>
    </div>
  );
};
