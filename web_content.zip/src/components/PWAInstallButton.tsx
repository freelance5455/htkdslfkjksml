import React, { useState } from 'react';
import { Download, Smartphone, WifiOff } from 'lucide-react';
import { useOnlineStatus, usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  compact?: boolean;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ compact = false }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={install}
        className={
          compact
            ? 'w-full py-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-sm flex items-center justify-center gap-2 cursor-pointer transition-colors'
            : 'inline-flex items-center gap-2 px-5 py-3.5 rounded-lg bg-sky-600 hover:bg-sky-500 border border-sky-400/50 text-white font-bold text-sm tracking-wide cursor-pointer transition-colors shadow-lg'
        }
      >
        <Download className="w-4 h-4" />
        INSTALL APP
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowIOSGuide(true)}
          className={
            compact
              ? 'w-full py-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-sm flex items-center justify-center gap-2 cursor-pointer transition-colors'
              : 'inline-flex items-center gap-2 px-5 py-3.5 rounded-lg bg-slate-900/95 hover:bg-slate-800 border border-sky-400/50 text-sky-300 font-bold text-sm tracking-wide cursor-pointer transition-colors'
          }
        >
          <Smartphone className="w-4 h-4" />
          INSTALL ON IOS
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4">
            <div className="w-full max-w-sm rounded-2xl bg-slate-950 border-2 border-sky-500/60 p-6 shadow-2xl text-left">
              <h3 className="text-lg font-black text-white">Install GKC 1 on iPhone / iPad</h3>
              <p className="mt-3 text-sm text-slate-300 leading-relaxed">
                1. Tap the <strong className="text-amber-400">Share</strong> icon in Safari toolbar.
                <br />
                2. Scroll down and tap <strong className="text-amber-400">Add to Home Screen</strong>.
              </p>
              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="mt-5 w-full rounded-xl bg-amber-400 hover:bg-amber-300 py-2.5 text-sm font-black text-slate-950 cursor-pointer"
              >
                GOT IT
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2 rounded-lg bg-amber-600 border border-amber-300/60 px-3 py-1.5 text-xs font-bold text-slate-950 shadow-lg pointer-events-none">
      <WifiOff className="w-3.5 h-3.5" />
      Offline Mode — Cached game data active
    </div>
  );
};
