import React, { useState, useEffect } from 'react';
import { Download, Smartphone, X, Check, Copy, ExternalLink, Sparkles } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export const PWAInstallButton: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    // Detect standalone mode
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    setIsInstalled(isStandalone);

    // Detect iOS devices
    const userAgent = window.navigator.userAgent.toLowerCase();
    const isIOSDevice = /iphone|ipad|ipod/.test(userAgent);
    setIsIOS(isIOSDevice);

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setIsInstalled(true);
        setDeferredPrompt(null);
        return;
      }
    }
    setShowModal(true);
  };

  const copyAppUrl = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  // If already running standalone on Android
  if (isInstalled) {
    return (
      <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 text-xs font-mono-code">
        <Check className="w-3.5 h-3.5" />
        Installed Standalone
      </div>
    );
  }

  return (
    <>
      <button
        onClick={handleInstallClick}
        aria-label="Install Jarvis on Android phone"
        className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 px-3.5 py-1.5 text-xs font-bold font-orbitron text-gray-950 uppercase tracking-wider shadow-lg shadow-cyan-500/30 hover:brightness-110 active:scale-95 transition"
      >
        <Smartphone className="w-3.5 h-3.5" />
        <span>Install App</span>
      </button>

      {/* Comprehensive Android Installation Guide Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-950/85 backdrop-blur-md p-4 overflow-y-auto">
          <div className="w-full max-w-md rounded-2xl bg-gray-900 border border-cyan-500/40 p-5 sm:p-6 shadow-2xl relative my-auto">
            <div className="flex items-center justify-between pb-3 border-b border-gray-800">
              <div className="flex items-center gap-2">
                <span className="p-1 rounded-lg bg-cyan-950 text-cyan-400">
                  <Smartphone className="w-5 h-5" />
                </span>
                <h3 className="text-sm font-orbitron font-bold text-slate-100 uppercase tracking-wider">
                  Android Phone Par Install Ka Tariqa
                </h3>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-4 text-xs font-rajdhani text-slate-200">
              {/* Method 1: Google Chrome Direct Install (Easiest) */}
              <div className="p-3.5 rounded-xl bg-gray-950 border border-cyan-500/30">
                <span className="text-[10px] uppercase font-mono-code text-cyan-400 font-bold block mb-1">
                  Tareeqa 1: Google Chrome se 1-Tap Direct Install (Recommended)
                </span>
                <ol className="list-decimal list-inside space-y-1.5 text-slate-300">
                  <li>
                    Apne Android phone me <strong>Google Chrome</strong> kholen aur is app ka link open karein.
                  </li>
                  <li>
                    Chrome ke top right corner me <strong>3 dots (⋮)</strong> par tap karein.
                  </li>
                  <li>
                    Menu me se <strong>"Install app"</strong> ya <strong>"Add to Home screen"</strong> par tap karein.
                  </li>
                  <li>
                    <strong>Install</strong> par confirm karein.
                  </li>
                </ol>
                <div className="mt-2.5 p-2 rounded-lg bg-cyan-950/40 border border-cyan-500/30 text-[11px] text-cyan-300">
                  ⚡ Yeh app aapke Android mobile ke app drawer me real app (Arc Reactor icon) ban kar save ho jayegi aur bina kisi browser bar ke fullscreen chalegi!
                </div>
              </div>

              {/* Copy URL Section */}
              <div className="p-3 rounded-xl bg-gray-950 border border-gray-800 flex items-center justify-between gap-2">
                <div className="truncate">
                  <span className="text-[10px] font-mono-code text-slate-400 block">App Link:</span>
                  <span className="text-xs font-mono-code text-cyan-300 truncate block">
                    {typeof window !== 'undefined' ? window.location.href : ''}
                  </span>
                </div>
                <button
                  onClick={copyAppUrl}
                  className="px-3 py-1.5 rounded-lg bg-gray-900 border border-cyan-500/40 hover:bg-cyan-950 text-cyan-300 text-xs font-mono-code flex items-center gap-1 shrink-0 transition"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied!' : 'Copy Link'}</span>
                </button>
              </div>

              {/* Method 2: Convert to Standalone APK File */}
              <div className="p-3.5 rounded-xl bg-gray-950 border border-gray-800">
                <span className="text-[10px] uppercase font-mono-code text-amber-400 font-bold block mb-1">
                  Tareeqa 2: Agar Direct .APK File Banani Ho
                </span>
                <p className="text-slate-400 leading-relaxed">
                  Agar aapko iski direct installable <strong>.apk</strong> file chahiye:
                  <br />
                  1. <strong>PWABuilder.com</strong> (Microsoft ka tool) par jayein.
                  <br />
                  2. Is app ka URL paste karein aur <strong>"Generate Android APK"</strong> par click karein.
                  <br />
                  3. Aapko 1 minute me ready-to-install Android APK file mil jayegi jo kisi bhi phone par install ho sakti hai.
                </p>
              </div>
            </div>

            <div className="mt-5 flex justify-end">
              <button
                onClick={() => setShowModal(false)}
                className="w-full sm:w-auto px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-gray-950 font-bold font-orbitron text-xs uppercase tracking-wider transition"
              >
                Samajh Gaya (Close)
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
