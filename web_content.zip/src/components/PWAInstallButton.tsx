import React, { useState } from 'react';
import {
  Download,
  X,
  Copy,
  Check,
  Sparkles,
  FileArchive,
  FileCode,
  Image as ImageIcon,
  Smartphone,
  Share,
  PlusSquare,
} from 'lucide-react';
import { usePWAInstall } from './usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, install } = usePWAInstall();
  const [showModal, setShowModal] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [activePlatform, setActivePlatform] = useState<'ios' | 'android'>('ios');

  const PUBLIC_SHARED_URL = 'https://meshmesh-sync.surge.sh';

  const handleCopyLink = async (urlToCopy: string = PUBLIC_SHARED_URL) => {
    try {
      await navigator.clipboard.writeText(urlToCopy);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      // fallback
    }
  };

  const handleTriggerInstall = async () => {
    if (isInstallable) {
      const res = await install();
      if (res) {
        setShowModal(false);
      }
    } else {
      setShowModal(true);
    }
  };

  return (
    <>
      <button
        onClick={() => setShowModal(true)}
        className="inline-flex items-center gap-1 whitespace-nowrap rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 px-2 sm:px-3 py-1.5 text-[11px] sm:text-xs font-black text-slate-950 shadow-sm hover:from-amber-400 hover:to-amber-500 active:scale-95 transition shrink-0"
        title="تثبيت التطبيق على الآيفون أو تحميل APK للأندرويد"
      >
        <Download className="h-3.5 w-3.5 shrink-0" />
        <span className="sm:hidden">تثبيت</span>
        <span className="hidden sm:inline">تثبيت للآيفون / APK</span>
      </button>

      {/* Comprehensive iOS & Android APK Installer Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-3 sm:p-4 backdrop-blur-xs animate-fadeIn">
          <div className="relative w-full max-w-lg max-h-[92vh] overflow-y-auto rounded-3xl bg-white p-4 sm:p-6 shadow-2xl text-right">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <img
                  src="/assets/aistudio/meshmesh_512x512_63b0ffb6.png"
                  alt="التمشمش"
                  className="h-11 w-11 rounded-2xl object-cover border-2 border-amber-400 shadow-xs"
                />
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    تنصيب تطبيق &quot;التمشمش&quot; على الموبايل
                  </h3>
                  <p className="text-xs text-slate-500">
                    اختر نوع جهازك لتنصيب التطبيق مباشرة بأيقونته الرسمية
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className="rounded-full p-2 text-slate-400 hover:bg-slate-100 transition"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Platform Switcher Tabs (iPhone vs Android) */}
            <div className="mt-3 grid grid-cols-2 gap-2 rounded-2xl bg-slate-100 p-1.5">
              <button
                type="button"
                onClick={() => setActivePlatform('ios')}
                className={`flex items-center justify-center gap-2 rounded-xl py-2.5 text-xs sm:text-sm font-black transition ${
                  activePlatform === 'ios'
                    ? 'bg-slate-900 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Smartphone className="h-4 w-4" />
                <span>تثبيت على الآيفون (iOS)</span>
              </button>
              <button
                type="button"
                onClick={() => setActivePlatform('android')}
                className={`flex items-center justify-center gap-2 rounded-xl py-2.5 text-xs sm:text-sm font-black transition ${
                  activePlatform === 'android'
                    ? 'bg-teal-900 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <FileArchive className="h-4 w-4" />
                <span>أندرويد (ملف APK / ZIP)</span>
              </button>
            </div>

            <div className="mt-4 space-y-4 text-xs sm:text-sm">
              {activePlatform === 'ios' ? (
                <>
                  {/* Method 1 for iPhone: Direct iOS Configuration Profile (.mobileconfig) */}
                  <div className="rounded-2xl bg-gradient-to-br from-slate-900 via-slate-800 to-slate-950 text-white p-4 space-y-3 shadow-md border border-slate-700">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-amber-300 font-black text-sm">
                        <Sparkles className="h-4 w-4 shrink-0" />
                        <span>الطريقة 1: حزمة التثبيت المباشر للآيفون (iOS Profile)</span>
                      </div>
                      <span className="rounded-lg bg-amber-400/20 border border-amber-400/40 px-2 py-0.5 text-[10px] font-bold text-amber-300">
                        بضغطة زر
                      </span>
                    </div>

                    <p className="text-xs text-slate-200 leading-relaxed">
                      جهزنا لك <strong>ملف تعريف تطبيق رسمي للآيفون (iOS WebClip Installer)</strong> يقوم بتثبيت أيقونة وتطبيق <strong>&quot;التمشمش&quot;</strong> بكامل الشاشة مباشرة على جهازك الآيفون:
                    </p>

                    <a
                      href="/meshmesh-ios.mobileconfig"
                      download="meshmesh-ios.mobileconfig"
                      className="flex items-center justify-center gap-2 rounded-xl bg-amber-400 hover:bg-amber-300 px-4 py-3.5 text-xs sm:text-sm font-black text-slate-950 shadow-md transition active:scale-95 w-full"
                    >
                      <Download className="h-4 w-4 shrink-0" />
                      <span>تنزيل حزمة تثبيت الآيفون (meshmesh-ios.mobileconfig)</span>
                    </a>

                    <div className="rounded-xl bg-slate-800/90 border border-slate-700 p-3 space-y-1.5 text-[11px] text-slate-200">
                      <div className="font-black text-amber-300">خطوات التفعيل بعد الضغط على الزر أعلاه في الآيفون:</div>
                      <ol className="list-decimal list-inside space-y-1 pr-1">
                        <li>ستظهر لك رسالة في الآيفون: <strong>&quot;يرغب هذا الموقع في تنزيل ملف تعريف تكوين&quot;</strong> — اضغط <strong>السماح (Allow)</strong>.</li>
                        <li>افتح <strong>إعدادات الآيفون (Settings)</strong> ستجد في الأعلى خيار <strong>&quot;تم تنزيل ملف التعريف&quot; (Profile Downloaded)</strong>.</li>
                        <li>اضغط عليه ثم اضغط <strong>تثبيت (Install)</strong> في أعلى الشاشة، وسينزل تطبيق <strong>التمشمش</strong> فوراً على شاشة الآيفون!</li>
                      </ol>
                    </div>
                  </div>

                  {/* Method 2 for iPhone: Safari Add to Home Screen (Standard Apple PWA) */}
                  <div className="rounded-2xl bg-amber-50/90 border-2 border-amber-200 p-4 space-y-3 text-slate-900">
                    <div className="font-black text-slate-900 flex items-center gap-2 text-sm">
                      <span className="flex h-6 px-2 items-center justify-center rounded-lg bg-slate-900 text-amber-300 text-xs font-black">
                        الطريقة 2
                      </span>
                      <span>التنصيب الفوري من متصفح Safari (بدون إعدادات)</span>
                    </div>

                    <ol className="list-decimal list-inside space-y-2 text-slate-700 pr-1 text-xs leading-relaxed">
                      <li className="flex items-start gap-2">
                        <span className="font-black text-slate-900 shrink-0">1.</span>
                        <span>
                          افتح رابط التطبيق في متصفح <strong>Safari (سفاري)</strong> على الآيفون.
                        </span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="font-black text-slate-900 shrink-0">2.</span>
                        <span className="inline-flex flex-wrap items-center gap-1">
                          اضغط على أيقونة <strong>المشاركة (Share)</strong>
                          <span className="inline-flex items-center rounded bg-slate-200 px-1.5 py-0.5 text-slate-800">
                            <Share className="h-3.5 w-3.5" />
                          </span>
                          في شريط سفاري الأسفل.
                        </span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="font-black text-slate-900 shrink-0">3.</span>
                        <span className="inline-flex flex-wrap items-center gap-1">
                          اختر <strong>&quot;إضافة إلى الشاشة الرئيسية&quot; (Add to Home Screen)</strong>
                          <span className="inline-flex items-center rounded bg-slate-200 px-1.5 py-0.5 text-slate-800">
                            <PlusSquare className="h-3.5 w-3.5" />
                          </span>
                          ثم اضغط <strong>إضافة (Add)</strong>.
                        </span>
                      </li>
                    </ol>
                  </div>

                  {/* Method 3 for iPhone: Standalone HTML File for iPhone Files / Offline */}
                  <div className="rounded-2xl bg-emerald-50 border border-emerald-200 p-3.5 space-y-2">
                    <div className="font-black text-emerald-950 text-xs">
                      الطريقة 3: تحميل ملف التطبيق المستقل للآيفون (يعمل من تطبيق الملفات Files):
                    </div>
                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      يمكنك أيضاً تحميل ملف <strong>التمشمش.html</strong> وحفظه في تطبيق <strong>الملفات (Files)</strong> أو تطبيق <strong>Documents</strong> على الآيفون ليفتح معك التطبيق بالكامل مباشرة:
                    </p>
                    <a
                      href="/meshmesh-standalone.html"
                      download="التمشمش.html"
                      className="flex items-center justify-center gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 px-3.5 py-2.5 text-xs font-black text-white shadow-xs transition active:scale-95"
                    >
                      <FileCode className="h-4 w-4 shrink-0" />
                      <span>تحميل ملف تطبيق الآيفون المستقل (التمشمش.html)</span>
                    </a>
                  </div>
                </>
              ) : (
                <>
                  {/* Cloud Sync Confirmation Banner for Android APK */}
                  <div className="rounded-2xl bg-emerald-950 text-white p-3.5 border border-emerald-700 flex items-start gap-2.5 shadow-xs">
                    <div className="h-2.5 w-2.5 rounded-full bg-emerald-400 animate-pulse mt-1.5 shrink-0" />
                    <div className="text-xs leading-relaxed">
                      <div className="font-black text-emerald-300">
                        مربوط تلقائياً بنفس السحابة الموحدة (100% Live Cloud Sync)
                      </div>
                      <p className="text-[11px] text-emerald-100/90 mt-0.5">
                        نسخة الأندرويد (سواء ثبتّها مباشرة أو حولتها إلى ملف <strong>.APK</strong>) تحتوي بداخلها على مفاتيح قاعدة البيانات السحابية الخاصة بك (<code>meshmesh_main</code>) وتتزامن لحظياً مع الآيفون والحاسبة بدون الحاجة لتسجيل دخول معقد.
                      </p>
                    </div>
                  </div>

                  {/* Direct Browser Installation Button (If browser supports BeforeInstallPrompt) */}
                  {isInstallable && (
                    <div className="rounded-2xl bg-emerald-50 border-2 border-emerald-500 p-4 text-center space-y-2">
                      <span className="inline-block rounded-full bg-emerald-200 text-emerald-900 text-xs font-bold px-3 py-1">
                        الطريقة الأسرع: تثبيت مباشر كبرنامج أندرويد بنقرة واحدة!
                      </span>
                      <button
                        onClick={handleTriggerInstall}
                        className="w-full flex items-center justify-center gap-2 rounded-xl bg-emerald-600 py-3 text-sm font-black text-white shadow-md hover:bg-emerald-700 active:scale-98 transition"
                      >
                        <Download className="h-5 w-5" />
                        اضغط هنا لتثبيت تطبيق التمشمش على الأندرويد الآن
                      </button>
                    </div>
                  )}

                  {/* Direct File Downloads Box (Solves URL blocking issues completely) */}
                  <div className="rounded-2xl bg-gradient-to-br from-teal-950 via-teal-900 to-emerald-950 text-white p-4 space-y-3 shadow-md border border-teal-700">
                    <div className="flex items-center gap-2 text-amber-300 font-black text-sm">
                      <Sparkles className="h-4 w-4 shrink-0" />
                      <span>حزمة تحويل التطبيق إلى ملف أندرويد (APK) مربوط بالسحابة:</span>
                    </div>
                    <p className="text-xs text-teal-100/90 leading-relaxed">
                      يحتوي ملف الـ ZIP على الكود الكامل مع إعدادات السحابة (<code>firebase-applet-config.json</code>) وصلاحيات الكاميرا والإنترنت للباركود (<code>CAMERA</code> &amp; <code>INTERNET</code>) جاهز للتحويل الفوري إلى <strong>APK</strong>:
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                      <a
                        href="/meshmesh-apk.zip"
                        download="meshmesh-apk.zip"
                        className="flex items-center justify-center gap-2 rounded-xl bg-amber-400 hover:bg-amber-300 px-3.5 py-3 text-xs font-black text-slate-950 shadow-sm transition active:scale-95"
                      >
                        <FileArchive className="h-4 w-4 shrink-0" />
                        <span>تحميل حزمة APK الكاملة (ZIP)</span>
                      </a>

                      <a
                        href="/meshmesh-standalone.html"
                        download="التمشمش.html"
                        className="flex items-center justify-center gap-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 px-3.5 py-3 text-xs font-black text-slate-950 shadow-sm transition active:scale-95"
                      >
                        <FileCode className="h-4 w-4 shrink-0" />
                        <span>تحميل ملف (التمشمش.html)</span>
                      </a>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-teal-800/80">
                      <span className="text-[11px] text-teal-200">
                        صورة أيقونة &quot;التمشمش&quot; الأصلية (512×512):
                      </span>
                      <a
                        href="/assets/aistudio/meshmesh_512x512_63b0ffb6.png"
                        download="meshmesh_icon.png"
                        className="inline-flex items-center gap-1 rounded-lg bg-teal-800 hover:bg-teal-700 px-2.5 py-1.5 text-[11px] font-bold text-amber-200 border border-teal-600 transition shrink-0"
                      >
                        <ImageIcon className="h-3.5 w-3.5" />
                        تحميل الأيقونة
                      </a>
                    </div>
                  </div>

                  {/* How to convert the downloaded ZIP/HTML to APK with 100% Camera support */}
                  <div className="rounded-2xl bg-emerald-50/90 border-2 border-emerald-200 p-4 space-y-3 text-emerald-950">
                    <div className="font-black text-emerald-950 flex items-center gap-2 text-sm">
                      <span className="flex h-6 px-2 items-center justify-center rounded-lg bg-emerald-700 text-white text-xs font-black">
                        مهم للكاميرا
                      </span>
                      <span>أفضل طرق تثبيت الأندرويد مع عمل الكاميرا المباشرة 100%:</span>
                    </div>

                    <ol className="list-decimal list-inside space-y-2 text-xs text-slate-700 pr-1 leading-relaxed">
                      <li>
                        <strong>الطريقة 1 (الأفضل للكاميرا والباركود المباشر - WebAPK):</strong> افتح الرابط <code className="font-mono text-teal-800">https://meshmesh-sync.surge.sh</code> في متصفح <strong>Chrome</strong> على هاتف الأندرويد، واضغط القائمة <strong>(⋮)</strong> في الأعلى ثم اختر <strong>&quot;تثبيت التطبيق&quot; (Install App)</strong>. سيقوم أندرويد بتثبيت حزمة رسمية تعمل فيها الكاميرا المباشرة والفلاش 100% بدون أي قيود!
                      </li>
                      <li>
                        <strong>الطريقة 2 (استخراج ملف .APK يدعم الكاميرا المباشرة):</strong> إذا أردت ملف <strong>.apk</strong> لإرساله بالواتساب أو التليغرام وتعمل فيه الكاميرا الحية، افتح موقع <strong className="font-mono text-teal-800">pwabuilder.com</strong> وضع الرابط <code className="font-mono text-teal-800">https://meshmesh-sync.surge.sh</code> واضغط <strong>Package for stores &rarr; Android</strong>، أو ارفع <strong>حزمة APK المحدثة (ZIP)</strong> أعلاه التي تحول المسار تلقائياً إلى <strong>HTTPS</strong> لتشغيل الكاميرا!
                      </li>
                    </ol>
                  </div>
                </>
              )}

              {/* Copy Link Box */}
              <div className="rounded-2xl bg-slate-50 border border-slate-200 p-3.5 space-y-2">
                <div className="font-black text-slate-800 text-xs">
                  رابط التطبيق المباشر (لفتحه في Safari على الآيفون أو Chrome على الأندرويد):
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={PUBLIC_SHARED_URL}
                    dir="ltr"
                    className="flex-1 rounded-xl border border-slate-300 bg-white px-3 py-1.5 text-xs font-mono text-slate-700 select-all"
                  />
                  <button
                    onClick={() => handleCopyLink(PUBLIC_SHARED_URL)}
                    className="flex items-center gap-1 rounded-xl bg-slate-800 px-3 py-1.5 text-xs font-bold text-white hover:bg-slate-700 transition shrink-0"
                  >
                    {copiedLink ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                    {copiedLink ? 'تم النسخ' : 'نسخ'}
                  </button>
                </div>
              </div>
            </div>

            {/* Close Button */}
            <button
              onClick={() => setShowModal(false)}
              className="mt-5 w-full rounded-2xl bg-slate-900 py-3 text-xs sm:text-sm font-bold text-white hover:bg-slate-800 transition"
            >
              إغلاق النافذة
            </button>
          </div>
        </div>
      )}
    </>
  );
};
