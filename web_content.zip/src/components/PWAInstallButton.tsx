import React, { useState } from 'react';
import { Download, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  compact?: boolean;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ compact = false }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  const handleAction = async () => {
    if (isInstallable) {
      await install();
      return;
    }
    setShowGuide(true);
  };

  return (
    <>
      <button
        type="button"
        onClick={handleAction}
        className={`inline-flex items-center justify-center gap-2 rounded-xl border border-cyan-400/30 bg-cyan-500/10 text-cyan-200 hover:bg-cyan-500/20 transition-colors min-h-[44px] whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 ${
          compact ? 'px-3 py-2 text-xs font-medium' : 'w-full px-4 py-2.5 text-sm font-semibold'
        }`}
      >
        <Download className="h-4 w-4 shrink-0" />
        <span>{isInstallable ? 'Install App' : 'Install Guide'}</span>
      </button>

      {showGuide && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="pwa-guide-title"
        >
          <div className="w-full max-w-md rounded-2xl border border-sky-400/25 bg-[#091224] p-5 text-slate-100 shadow-2xl">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <Smartphone className="h-5 w-5 text-cyan-300" />
                <h3 id="pwa-guide-title" className="font-display text-base font-semibold">
                  Install on Your Phone
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                aria-label="Close install guide"
                className="flex h-11 w-11 items-center justify-center rounded-xl text-slate-400 hover:bg-slate-800/70 hover:text-slate-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {isIOS ? (
              <ol className="mt-4 space-y-2.5 text-sm text-slate-300 leading-relaxed list-decimal list-inside">
                <li>Open this page in Safari on your iPhone or iPad.</li>
                <li>Tap the Share icon in the browser toolbar.</li>
                <li>Scroll down and tap Add to Home Screen.</li>
              </ol>
            ) : (
              <ol className="mt-4 space-y-2.5 text-sm text-slate-300 leading-relaxed list-decimal list-inside">
                <li>Open this app in Google Chrome on your Android phone.</li>
                <li>Tap the three-dot menu (⋮) in the top-right corner of Chrome.</li>
                <li>Tap Add to Home screen (or Install app) and confirm.</li>
              </ol>
            )}

            <p className="mt-4 text-xs text-slate-400">
              Once installed, JARVIS opens in standalone full-screen mode from your app drawer.
            </p>

            <button
              type="button"
              onClick={() => setShowGuide(false)}
              className="mt-5 w-full min-h-[44px] rounded-xl bg-cyan-500 px-4 py-2.5 text-sm font-semibold text-[#040812] hover:bg-cyan-400 transition-colors"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </>
  );
};
