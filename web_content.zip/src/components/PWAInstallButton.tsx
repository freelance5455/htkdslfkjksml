import React, { useState } from 'react';
import { Download, Smartphone, X, CheckCircle2 } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [installSuccess, setInstallSuccess] = useState(false);

  // If already running as standalone app, show a subtle active badge or hide
  if (isInstalled) {
    return (
      <div className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-700 text-xs font-semibold border border-emerald-300">
        <CheckCircle2 className="w-3.5 h-3.5" />
        <span>ऐप इंस्टॉल्ड</span>
      </div>
    );
  }

  const handleInstallClick = async () => {
    const ok = await install();
    if (ok) {
      setInstallSuccess(true);
      setTimeout(() => setInstallSuccess(false), 3000);
    }
  };

  if (isInstallable) {
    return (
      <button
        onClick={handleInstallClick}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/20 hover:bg-white/30 text-white font-medium text-xs sm:text-sm backdrop-blur-xs transition border border-white/30 shadow-xs cursor-pointer active:scale-95"
        title="फ़ोन पर ऐप की तरह इंस्टॉल करें"
      >
        <Download className="w-4 h-4 animate-bounce" />
        <span>{installSuccess ? 'इंस्टॉल हो गया!' : 'ऐप इंस्टॉल करें'}</span>
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/20 hover:bg-white/30 text-white font-medium text-xs sm:text-sm backdrop-blur-xs transition border border-white/30 cursor-pointer"
        >
          <Smartphone className="w-4 h-4" />
          <span>होम स्क्रीन पर जोड़ें</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
            <div className="w-full max-w-sm rounded-2xl bg-white p-5 shadow-2xl text-slate-800">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-orange-600" />
                  iPhone / iPad पर इंस्टॉल करें
                </h3>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="p-1 rounded-full text-slate-400 hover:text-slate-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="mt-4 space-y-3 text-sm text-slate-600">
                <div className="flex items-start gap-2.5">
                  <span className="flex items-center justify-center w-6 h-6 rounded-full bg-orange-100 text-orange-700 font-bold text-xs shrink-0">1</span>
                  <span>Safari ब्राउज़र के नीचे स्थित <strong>शेयर (Share)</strong> बटन दबाएं।</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="flex items-center justify-center w-6 h-6 rounded-full bg-orange-100 text-orange-700 font-bold text-xs shrink-0">2</span>
                  <span>सूची में नीचे स्क्रॉल करके <strong>'होम स्क्रीन में जोड़ें' (Add to Home Screen)</strong> चुनें।</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="flex items-center justify-center w-6 h-6 rounded-full bg-orange-100 text-orange-700 font-bold text-xs shrink-0">3</span>
                  <span>ऊपर दाएं कोने में <strong>'जोड़ें' (Add)</strong> पर टैप करें।</span>
                </div>
              </div>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="mt-5 w-full rounded-xl bg-orange-600 py-2.5 text-sm font-semibold text-white hover:bg-orange-700 transition"
              >
                समझ गया / बंद करें
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
