import { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Smartphone, Download, Check, X, Share2, PlusSquare, ShieldCheck, Sparkles } from 'lucide-react';

export const PWAInstallButton = () => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [showModal, setShowModal] = useState(false);
  const [justInstalled, setJustInstalled] = useState(false);

  const handleInstallClick = async () => {
    if (isInstallable) {
      const success = await install();
      if (success) {
        setJustInstalled(true);
        setTimeout(() => setJustInstalled(false), 4000);
      }
    } else {
      setShowModal(true);
    }
  };

  if (isInstalled) {
    return (
      <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-emerald-950/80 border border-emerald-500/30 text-[11px] font-semibold text-emerald-300">
        <Check className="w-3.5 h-3.5 text-emerald-400" />
        <span className="hidden sm:inline">Uygulama Yüklü</span>
      </div>
    );
  }

  return (
    <>
      <button
        onClick={handleInstallClick}
        className="flex items-center gap-1.5 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-rose-600 via-rose-500 to-amber-500 hover:from-rose-500 hover:to-amber-400 text-white shadow-lg shadow-rose-950/40 border border-rose-400/30 transition-all cursor-pointer active:scale-95 shrink-0"
        title="Telefona APK / Uygulama olarak indir ve kur"
      >
        <Smartphone className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white animate-pulse" />
        <span className="whitespace-nowrap">Telefona Yükle</span>
      </button>

      {/* Mobile Install & APK Guide Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className="bg-[#121214] text-stone-100 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-zinc-800 relative">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-4 right-4 p-1.5 text-stone-400 hover:text-white rounded-xl bg-zinc-800/60 transition-all cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            {/* App Header Badge */}
            <div className="flex items-center gap-3 mb-5">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-zinc-800 to-black border-2 border-rose-500/40 flex items-center justify-center text-rose-400 font-serif font-extrabold text-2xl shadow-xl shadow-rose-950/50">
                Z
              </div>
              <div>
                <h3 className="font-bold text-base font-serif text-white flex items-center gap-1.5">
                  <span>Zeynep'in Günlüğü</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-sans font-bold border border-rose-500/30">
                    Mobil APK
                  </span>
                </h3>
                <p className="text-xs text-stone-400">
                  Android & iPhone için tam ekran telefon uygulaması
                </p>
              </div>
            </div>

            {/* Platform instructions */}
            <div className="space-y-3.5 text-xs">
              {/* Android Guide */}
              <div className="p-3.5 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-2">
                <div className="flex items-center justify-between font-bold text-stone-200">
                  <span className="flex items-center gap-1.5 text-amber-400">
                    <Download className="w-4 h-4" />
                    Android (Doğrudan APK / WebAPK Kurulumu)
                  </span>
                </div>
                <p className="text-stone-400 leading-relaxed text-[11px]">
                  Google Chrome veya Samsung Internet tarayıcısında sağ üstteki <strong>üç nokta (⋮)</strong> menüsüne tıklayın ve <strong>"Uygulamayı Yükle"</strong> ya da <strong>"Ana Ekrana Ekle"</strong> seçeneğini seçin. Telefonunuza bağımsız APK olarak yüklenir, Play Store gerekmez.
                </p>
              </div>

              {/* iOS Guide */}
              <div className="p-3.5 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-2">
                <div className="flex items-center justify-between font-bold text-stone-200">
                  <span className="flex items-center gap-1.5 text-sky-400">
                    <Share2 className="w-4 h-4" />
                    iPhone / iPad (iOS Safari)
                  </span>
                </div>
                <ol className="text-stone-400 space-y-1 list-decimal list-inside text-[11px]">
                  <li>Safari alt barındaki <strong>Paylaş</strong> simgesine dokunun.</li>
                  <li>Aşağı kaydırıp <strong>"Ana Ekrana Ekle"</strong> butonuna basın.</li>
                  <li>Sağ üstten <strong>"Ekle"</strong>ye dokunun.</li>
                </ol>
              </div>

              {/* Native Mobile Features */}
              <div className="p-3 bg-zinc-900/60 rounded-xl border border-zinc-800/80 text-[11px] text-stone-400 space-y-1">
                <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Mobil Uygulama Avantajları</span>
                </div>
                <p>
                  • Tarayıcı çubuğu olmadan tam ekran mobil deneyim<br />
                  • İnternet olmadan da anında açılma (Çevrimdışı PWA)<br />
                  • Telefon ana ekranında doğrudan Zeynep'in Günlüğü ikonu
                </p>
              </div>
            </div>

            {/* Action */}
            <div className="mt-5 flex items-center justify-end gap-2">
              <button
                onClick={() => setShowModal(false)}
                className="w-full py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-bold text-xs transition-all cursor-pointer"
              >
                Anladım
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
