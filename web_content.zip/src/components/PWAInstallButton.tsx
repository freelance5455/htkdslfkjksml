import React, { useState } from 'react';
import { Download, Smartphone, Check, Copy, X, WifiOff } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, isOnline, install } = usePWAInstall();
  const [showModal, setShowModal] = useState(false);
  const [copiedStep, setCopiedStep] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text).catch(() => {});
    setCopiedStep(id);
    window.setTimeout(() => setCopiedStep(null), 2000);
  };

  const capacitorCommands = `npm install
npm run build
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap add android
npx cap sync
cd android && ./gradlew assembleDebug`;

  return (
    <>
      {/* Non-intrusive Offline Indicator */}
      {!isOnline && (
        <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2 rounded-lg bg-amber-500/95 px-3 py-1.5 text-xs font-semibold text-[#1F1E1B] shadow-lg">
          <WifiOff className="w-3.5 h-3.5" />
          Offline Mode Ready
        </div>
      )}

      {/* Header Action Button */}
      <button
        type="button"
        onClick={async () => {
          if (isInstallable) {
            const installed = await install();
            if (!installed) setShowModal(true);
          } else {
            setShowModal(true);
          }
        }}
        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#81B64C] hover:bg-[#8ec455] text-[#1F1E1B] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        title="Install App or Export Android APK"
      >
        <Download className="w-3.5 h-3.5" />
        {isInstalled ? 'APK Guide' : 'Install / APK'}
      </button>

      {/* Install & APK Export Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#262522] border border-white/15 rounded-2xl p-6 shadow-2xl max-w-lg w-full text-left max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#81B64C]/20 border border-[#81B64C]/40 flex items-center justify-center text-[#A3D160]">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-white">
                    Install App & Export Android APK
                  </h2>
                  <p className="text-xs text-stone-400">
                    PWA Manifest, Service Worker, and Capacitor config are pre-configured
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="p-1.5 rounded-lg text-stone-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              {/* Direct PWA Install */}
              {isInstallable && (
                <div className="p-3.5 rounded-xl bg-[#81B64C]/15 border border-[#81B64C]/40 flex items-center justify-between gap-3">
                  <div>
                    <h3 className="font-bold text-white text-sm">
                      One-Click Device Install
                    </h3>
                    <p className="text-stone-300 mt-0.5">
                      Install directly to your home screen as an offline standalone app.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={install}
                    className="px-3.5 py-2 rounded-lg bg-[#81B64C] hover:bg-[#8ec455] text-[#1F1E1B] font-bold whitespace-nowrap cursor-pointer"
                  >
                    Install Now
                  </button>
                </div>
              )}

              {/* iOS Safari Instructions */}
              {isIOS && !isInstalled && (
                <div className="p-3.5 rounded-xl bg-[#1F1E1B] border border-white/10">
                  <h3 className="font-bold text-white text-sm mb-1">
                    Install on iPhone / iPad
                  </h3>
                  <p className="text-stone-300 leading-relaxed">
                    1. Tap the <strong>Share</strong> button in Safari&apos;s toolbar.<br />
                    2. Scroll down and tap <strong>Add to Home Screen</strong>.
                  </p>
                </div>
              )}

              {/* Option 1: PWABuilder Cloud APK */}
              <div className="p-4 rounded-xl bg-[#1F1E1B] border border-white/10 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-[#A3D160]">
                    Method 1: Instant APK via PWABuilder (No Code)
                  </span>
                  <span className="text-[11px] text-stone-400">Fastest · ~1 min</span>
                </div>
                <ol className="list-decimal list-inside space-y-1 text-stone-300 leading-relaxed">
                  <li>Copy your live Shared App URL below.</li>
                  <li>
                    Open <strong>pwabuilder.com</strong>, paste the URL, and click{' '}
                    <strong>Package for Stores → Android → Download Package</strong>.
                  </li>
                  <li>
                    Unzip the download to get your ready-to-install <code>.apk</code> file.
                  </li>
                </ol>
                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="text"
                    readOnly
                    value={window.location.origin}
                    className="flex-1 bg-[#262522] border border-white/10 rounded-lg px-3 py-1.5 font-mono text-xs text-stone-200 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => handleCopy(window.location.origin, 'url')}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#302E2B] hover:bg-[#3B3834] text-white font-semibold cursor-pointer"
                  >
                    {copiedStep === 'url' ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-[#A3D160]" />
                        Copied
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        Copy URL
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Option 2: Native Offline APK via Capacitor */}
              <div className="p-4 rounded-xl bg-[#1F1E1B] border border-white/10 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-white">
                    Method 2: Build 100% Offline APK with Capacitor
                  </span>
                  <button
                    type="button"
                    onClick={() => handleCopy(capacitorCommands, 'cap')}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-[#302E2B] hover:bg-[#3B3834] text-stone-200 font-semibold cursor-pointer"
                  >
                    {copiedStep === 'cap' ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-[#A3D160]" />
                        Copied
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        Copy Commands
                      </>
                    )}
                  </button>
                </div>
                <p className="text-stone-400">
                  <code>capacitor.config.json</code> is already included in this project. Download the project and run:
                </p>
                <pre className="p-3 rounded-lg bg-[#141311] border border-white/8 font-mono text-[11px] text-[#A3D160] overflow-x-auto leading-relaxed">
                  {capacitorCommands}
                </pre>
                <p className="text-[11px] text-stone-400">
                  Output APK location: <code>android/app/build/outputs/apk/debug/app-debug.apk</code>
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowModal(false)}
              className="mt-5 w-full py-2.5 rounded-xl bg-[#302E2B] hover:bg-[#3B3834] text-white font-semibold text-sm transition-colors cursor-pointer"
            >
              Done
            </button>
          </div>
        </div>
      )}
    </>
  );
};
