import React, { useState } from 'react';
import { Download, X } from 'lucide-react';
import { usePWAInstall } from '../utils/usePWAInstall';

interface PWAInstallButtonProps {
  variant?: 'header' | 'settings';
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ variant = 'header' }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuideModal, setShowGuideModal] = useState(false);

  if (isInstalled) {
    if (variant === 'settings') {
      return (
        <span className="px-3 py-1.5 rounded-lg bg-sky-500/15 border border-sky-500/30 text-xs font-semibold text-sky-300">
          App installiert
        </span>
      );
    }
    return null;
  }

  const handleClick = async () => {
    if (isInstallable) {
      await install();
      return;
    }
    setShowGuideModal(true);
  };

  return (
    <>
      {variant === 'header' ? (
        <button
          type="button"
          onClick={handleClick}
          title="App installieren / Chrome-Verknüpfung erstellen"
          aria-label="App installieren"
          className="px-2.5 py-1.5 rounded-md bg-sky-500/15 hover:bg-sky-500/25 border border-sky-500/35 text-xs font-semibold text-sky-300 transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Download className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">App installieren</span>
        </button>
      ) : (
        <button
          type="button"
          onClick={handleClick}
          className="px-4 py-2 rounded-lg bg-sky-400 hover:bg-sky-300 text-xs sm:text-sm font-bold text-black transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span>App installieren / Verknüpfung</span>
        </button>
      )}

      {showGuideModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="pwa-install-dialog-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
        >
          <div className="w-full max-w-md cine-card rounded-2xl p-6 border border-white/15 shadow-2xl flex flex-col gap-4">
            <div className="flex items-center justify-between gap-2 border-b border-white/10 pb-3">
              <h3 id="pwa-install-dialog-title" className="text-base font-bold text-white">
                {isIOS
                  ? 'Auf iPhone / iPad installieren'
                  : 'In Chrome installieren / Verknüpfung erstellen'}
              </h3>
              <button
                type="button"
                aria-label="Schließen"
                onClick={() => setShowGuideModal(false)}
                className="p-1.5 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] text-neutral-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {isIOS ? (
              <ol className="text-xs sm:text-sm text-neutral-300 space-y-2 list-decimal list-inside leading-relaxed">
                <li>
                  Tippe unten in Safari auf das <strong>Teilen-Symbol</strong>.
                </li>
                <li>
                  Wähle <strong>Zum Home-Bildschirm</strong>, um die App als eigenständige Vollbild-App zu speichern.
                </li>
              </ol>
            ) : (
              <div className="flex flex-col gap-3 text-xs sm:text-sm text-neutral-300 leading-relaxed">
                <p>
                  So installierst du <strong>YtY SRS</strong> als eigenständige Desktop- oder Mobil-App in Google Chrome:
                </p>
                <ol className="space-y-2 list-decimal list-inside bg-black/50 border border-white/10 rounded-xl p-3.5">
                  <li>
                    Öffne die veröffentlichte App-URL direkt in einem normalen Chrome-Tab (nicht in der Vorschau).
                  </li>
                  <li>
                    Klicke rechts in der Adressleiste auf das <strong>Installieren-Symbol</strong> oder öffne das Chrome-Menü (<strong>⋮</strong>) oben rechts.
                  </li>
                  <li>
                    Wähle <strong>„Streamen, speichern und teilen“ → „Seite als App installieren...“</strong> bzw. <strong>„Verknüpfung erstellen...“</strong> (mit Haken bei <em>„In neuem Fenster öffnen“</em>).
                  </li>
                </ol>
              </div>
            )}

            <div className="flex justify-end pt-1">
              <button
                type="button"
                onClick={() => setShowGuideModal(false)}
                className="px-4 py-2 rounded-lg bg-white hover:bg-neutral-200 text-xs font-bold text-black transition-colors cursor-pointer"
              >
                Verstanden
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
