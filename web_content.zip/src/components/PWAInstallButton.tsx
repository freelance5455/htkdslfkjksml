import React, { useState } from 'react';
import {
  Download,
  X,
  Copy,
  Check,
  Sparkles,
  FileArchive,
  FileCode,
  Image as ImageIcon,
} from 'lucide-react';
import { usePWAInstall } from './usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, install } = usePWAInstall();
  const [showModal, setShowModal] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const PUBLIC_SHARED_URL = 'https://ais-pre-roqgnunsvfaphpd2kbajsp-698262634193.europe-west1.run.app';

  const handleCopyLink = async (urlToCopy: string = PUBLIC_SHARED_URL) => {
    try {
      await navigator.clipboard.writeText(urlToCopy);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      // fallback
    }
  };

  const handleTriggerInstall = async () => {
    if (isInstallable) {
      const res = await install();
      if (res) {
        setShowModal(false);
      }
    } else {
      setShowModal(true);
    }
  };

  return (
    <>
      <button
        onClick={() => setShowModal(true)}
        className="inline-flex items-center gap-1.5 whitespace-nowrap rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 px-2.5 sm:px-3 py-1.5 text-[11px] sm:text-xs font-black text-slate-950 shadow-sm hover:from-amber-400 hover:to-amber-500 active:scale-95 transition shrink-0"
        title="تحميل ملف التطبيق أو استخراج APK"
      >
        <Download className="h-3.5 w-3.5 shrink-0" />
        <span className="sm:hidden">APK / تثبيت</span>
        <span className="hidden sm:inline">تحميل APK / تثبيت</span>
      </button>

      {/* Comprehensive APK & Offline File Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-3 sm:p-4 backdrop-blur-xs animate-fadeIn">
          <div className="relative w-full max-w-lg max-h-[92vh] overflow-y-auto rounded-3xl bg-white p-4 sm:p-6 shadow-2xl text-right">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <img
                  src="/assets/aistudio/meshmesh_512x512_63b0ffb6.png"
                  alt="التمشمش"
                  className="h-11 w-11 rounded-2xl object-cover border-2 border-amber-400 shadow-xs"
                />
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    تحميل تطبيق &quot;التمشمش&quot; وتحويله إلى APK
                  </h3>
                  <p className="text-xs text-slate-500">
                    ملفات التطبيق الجاهزة للعمل المباشر أو التحويل الفوري إلى APK بدون أخطاء الروابط
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className="rounded-full p-2 text-slate-400 hover:bg-slate-100 transition"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-4 space-y-4 text-xs sm:text-sm">
              {/* Direct Browser Installation Button (If browser supports BeforeInstallPrompt) */}
              {isInstallable && (
                <div className="rounded-2xl bg-emerald-50 border-2 border-emerald-500 p-4 text-center space-y-2">
                  <span className="inline-block rounded-full bg-emerald-200 text-emerald-900 text-xs font-bold px-3 py-1">
                    متصفحك يدعم التثبيت المباشر كبرنامج بنقرة واحدة!
                  </span>
                  <button
                    onClick={handleTriggerInstall}
                    className="w-full flex items-center justify-center gap-2 rounded-xl bg-emerald-600 py-3 text-sm font-black text-white shadow-md hover:bg-emerald-700 active:scale-98 transition"
                  >
                    <Download className="h-5 w-5" />
                    اضغط هنا لتثبيت تطبيق التمشمش الآن
                  </button>
                </div>
              )}

              {/* Direct File Downloads Box (Solves URL blocking issues completely) */}
              <div className="rounded-2xl bg-gradient-to-br from-teal-950 via-teal-900 to-emerald-950 text-white p-4 space-y-3 shadow-md border border-teal-700">
                <div className="flex items-center gap-2 text-amber-300 font-black text-sm">
                  <Sparkles className="h-4 w-4 shrink-0" />
                  <span>الحل الجذري (بدون رابط): حمّل ملف التطبيق جاهزاً!</span>
                </div>
                <p className="text-xs text-teal-100/90 leading-relaxed">
                  بعض مواقع تحويل الروابط تفشل لأن الرابط محمي بحساب كوكل. لذلك جهزنا لك <strong>ملف التطبيق الكامل المدمج</strong> لتحميله بضغطة زر واحدة:
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                  <a
                    href="/meshmesh-apk.zip"
                    download="meshmesh-apk.zip"
                    className="flex items-center justify-center gap-2 rounded-xl bg-amber-400 hover:bg-amber-300 px-3.5 py-3 text-xs font-black text-slate-950 shadow-sm transition active:scale-95"
                  >
                    <FileArchive className="h-4 w-4 shrink-0" />
                    <span>تحميل حزمة APK (ملف ZIP)</span>
                  </a>

                  <a
                    href="/meshmesh-standalone.html"
                    download="التمشمش.html"
                    className="flex items-center justify-center gap-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 px-3.5 py-3 text-xs font-black text-slate-950 shadow-sm transition active:scale-95"
                  >
                    <FileCode className="h-4 w-4 shrink-0" />
                    <span>تحميل ملف (التمشمش.html)</span>
                  </a>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-teal-800/80">
                  <span className="text-[11px] text-teal-200">
                    صورة أيقونة &quot;التمشمش&quot; الأصلية (512×512):
                  </span>
                  <a
                    href="/assets/aistudio/meshmesh_512x512_63b0ffb6.png"
                    download="meshmesh_icon.png"
                    className="inline-flex items-center gap-1 rounded-lg bg-teal-800 hover:bg-teal-700 px-2.5 py-1.5 text-[11px] font-bold text-amber-200 border border-teal-600 transition shrink-0"
                  >
                    <ImageIcon className="h-3.5 w-3.5" />
                    تحميل الأيقونة
                  </a>
                </div>
              </div>

              {/* How to convert the downloaded ZIP/HTML to APK (100% working) */}
              <div className="rounded-2xl bg-emerald-50/90 border-2 border-emerald-200 p-4 space-y-3 text-emerald-950">
                <div className="font-black text-emerald-950 flex items-center gap-2 text-sm">
                  <span className="flex h-6 px-2 items-center justify-center rounded-lg bg-emerald-700 text-white text-xs font-black">
                    مضمونة 100%
                  </span>
                  <span>شلون تحول الملف المحمّل إلى APK خلال 30 ثانية؟</span>
                </div>

                <div className="space-y-2.5 text-xs text-slate-700 leading-relaxed">
                  <div className="rounded-xl bg-white p-3 border border-emerald-200 space-y-1.5">
                    <div className="font-black text-teal-900">
                      الطريقة أ: تحويل ملف הـ ZIP إلى APK (بدل الرابط):
                    </div>
                    <ol className="list-decimal list-inside space-y-1 pr-1">
                      <li>اضغط زر <strong>&quot;تحميل حزمة APK (ملف ZIP)&quot;</strong> باللون الأصفر أعلاه.</li>
                      <li>
                        افتح موقع <strong className="font-mono text-teal-800">webintoapp.com</strong>، ولكن <strong>لا تختر Online URL!</strong> بل اضغط على خيار <strong>HTML / Local Files</strong> (أو علامة المجلد بجانب الرابط).
                      </li>
                      <li>ارفع ملف <strong>meshmesh-apk.zip</strong> الذي حمّلته، واختر الأيقونة واضغط <strong>Make App</strong>.</li>
                      <li>راح يشتغل وياك فوراً 100% بدون أي مشكلة لأن كل الكود بداخل الملف!</li>
                    </ol>
                  </div>

                  <div className="rounded-xl bg-white p-3 border border-emerald-200 space-y-1.5">
                    <div className="font-black text-indigo-900">
                      الطريقة ب: عبر تطبيق موبايل من سوق بلي (بدون مواقع نهائياً):
                    </div>
                    <ol className="list-decimal list-inside space-y-1 pr-1">
                      <li>اضغط زر <strong>&quot;تحميل ملف (التمشمش.html)&quot;</strong> باللون الأخضر أعلاه.</li>
                      <li>
                        تقدر تفتح ملف <strong>التمشمش.html</strong> مباشرة على موبايلك وراح يشتغل التطبيق كامل!
                      </li>
                      <li>
                        أو نزّل من متجر كوكل بلي تطبيق اسمه <strong>HTML to APK</strong> (أو <strong>Website 2 APK</strong>) واختار ملف <strong>التمشمش.html</strong> من جهازك ليحوله إلى ملف <strong>.apk</strong> فوراً.
                      </li>
                    </ol>
                  </div>
                </div>
              </div>

              {/* Copy Link Box */}
              <div className="rounded-2xl bg-slate-50 border border-slate-200 p-3.5 space-y-2">
                <div className="font-black text-slate-800 text-xs">
                  أو للتثبيت المباشر عبر متصفح Chrome على الأندرويد (بدون APK):
                </div>
                <p className="text-[11px] text-slate-600">
                  افتح هذا الرابط في متصفح <strong>Google Chrome</strong> ثم اضغط النقاط الثلاث <strong>(⋮)</strong> أعلى الشاشة واختر <strong>&quot;تثبيت التطبيق / Install App&quot;</strong>:
                </p>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={PUBLIC_SHARED_URL}
                    dir="ltr"
                    className="flex-1 rounded-xl border border-slate-300 bg-white px-3 py-1.5 text-xs font-mono text-slate-700 select-all"
                  />
                  <button
                    onClick={() => handleCopyLink(PUBLIC_SHARED_URL)}
                    className="flex items-center gap-1 rounded-xl bg-slate-800 px-3 py-1.5 text-xs font-bold text-white hover:bg-slate-700 transition shrink-0"
                  >
                    {copiedLink ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                    {copiedLink ? 'تم النسخ' : 'نسخ'}
                  </button>
                </div>
              </div>
            </div>

            {/* Close Button */}
            <button
              onClick={() => setShowModal(false)}
              className="mt-5 w-full rounded-2xl bg-slate-900 py-3 text-xs sm:text-sm font-bold text-white hover:bg-slate-800 transition"
            >
              إغلاق النافذة
            </button>
          </div>
        </div>
      )}
    </>
  );
};
