import React, { useState } from 'react';
import { Download, Share2, PlusSquare, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  return (
    <>
      {isInstallable ? (
        <button
          onClick={install}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 rounded-xl text-xs font-bold shadow-md shadow-amber-500/20 active:scale-95 transition"
        >
          <Download className="w-3.5 h-3.5" />
          <span>تثبيت التطبيق على الهاتف</span>
        </button>
      ) : (
        <button
          onClick={() => setShowIOSGuide(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-amber-400 border border-amber-500/30 rounded-xl text-xs font-bold active:scale-95 transition"
        >
          <Download className="w-3.5 h-3.5" />
          <span>تثبيت التطبيق (Android / iOS)</span>
        </button>
      )}

      {showIOSGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-2xl text-right">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Download className="w-4 h-4 text-amber-400" />
                تثبيت التطبيق على الهاتف (Android / iOS)
              </h3>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="mt-4 space-y-3 text-xs text-slate-300 leading-relaxed">
              <div className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700 space-y-1">
                <span className="font-bold text-amber-400 block text-xs">📱 لهواتف أندرويد (Google Chrome):</span>
                <span>1. افتح الرابط في متصفح Chrome.</span>
                <span className="block">2. اضغط على القائمة (الثلاث نقاط <strong>⋮</strong> بالأعلى).</span>
                <span className="block">3. اختر <strong>"تثبيت التطبيق" (Install App)</strong> أو "إضافة إلى الشاشة الرئيسية".</span>
                <span className="text-[10px] text-emerald-400 block mt-1">✔ سيقوم أندرويد بإنشاء WebAPK أصيل وتثبيته فوراً كأيقونة على هاتفك.</span>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700 space-y-1">
                <span className="font-bold text-sky-400 block text-xs">🍏 لهواتف آيفون (Safari):</span>
                <span>1. افتح الرابط في متصفح Safari.</span>
                <span className="block">2. اضغط على زر <strong>المشاركة (Share)</strong> بالأسفل.</span>
                <span className="block">3. مرر واختر <strong>"إضافة إلى الشاشة الرئيسية" (Add to Home Screen)</strong>.</span>
              </div>

              <div className="pt-1">
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText('https://ais-pre-oxwvwsbk3bzhrnlrwlrm6e-591247979635.europe-west3.run.app');
                    alert('تم نسخ رابط التطبيق بنجاح!');
                  }}
                  className="w-full py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold active:scale-95 transition"
                >
                  نسخ رابط التطبيق المباشر
                </button>
              </div>
            </div>
            <button
              onClick={() => setShowIOSGuide(false)}
              className="mt-4 w-full rounded-xl bg-amber-500 py-2.5 text-xs font-bold text-slate-950 active:scale-95 transition"
            >
              تم الفهم
            </button>
          </div>
        </div>
      )}
    </>
  );
};
