import React, { useState } from 'react';
import { Check, Copy, Download, Smartphone, WifiOff, X } from 'lucide-react';
import { useOnlineStatus, usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);
  const [copied, setCopied] = useState(false);

  if (isInstalled) {
    return null;
  }

  const appUrl =
    typeof window !== 'undefined'
      ? window.location.origin
      : 'https://ais-dev-mnvej3a46w5r6skjsfsukg-58558070101.europe-west3.run.app';

  const handleAction = async () => {
    if (isInstallable) {
      await install();
      return;
    }
    setShowGuide(true);
  };

  const handleCopyUrl = async () => {
    try {
      await navigator.clipboard.writeText(appUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard fallback ignored if blocked by iframe permissions
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={handleAction}
        className={
          compact
            ? 'flex h-10 items-center justify-center gap-2 border border-cyan-500/60 bg-cyan-500/15 px-3 text-xs font-medium text-cyan-200 transition-colors hover:bg-cyan-500/25 whitespace-nowrap shrink-0'
            : 'flex h-11 items-center gap-2 border border-cyan-500/60 bg-cyan-500/15 px-3.5 text-xs font-medium text-cyan-200 transition-colors hover:bg-cyan-500/25 md:h-12 md:px-4 md:text-sm whitespace-nowrap shrink-0'
        }
      >
        <Download className="h-4 w-4" />
        <span>{isInstallable ? 'Install App' : 'Install / Play Anytime'}</span>
      </button>

      {showGuide && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-black/85 p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Install HOLLOWWIRE App"
        >
          <div className="my-auto w-full max-w-md border border-slate-700 bg-[#090d18] p-5 md:p-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-cyan-300">
                <Smartphone className="h-5 w-5" />
                <h3 className="font-display text-lg font-bold">
                  {isIOS ? 'Install on iPhone / iPad' : 'Install as Phone & Web App'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                aria-label="Close install guide"
                className="flex h-9 w-9 items-center justify-center border border-slate-700 text-slate-300 hover:border-cyan-400 hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs leading-relaxed text-slate-300 md:text-sm">
              <p>
                HOLLOWWIRE is an installable offline web app (PWA). Open this game link directly in your phone browser to play anytime or install it straight to your home screen:
              </p>

              <div className="flex items-center gap-2 border border-slate-800 bg-[#05070d] p-2.5">
                <span className="min-w-0 flex-1 truncate font-mono text-[11px] text-cyan-300">
                  {appUrl}
                </span>
                <button
                  type="button"
                  onClick={handleCopyUrl}
                  className="flex h-8 shrink-0 items-center gap-1.5 border border-slate-700 bg-slate-900 px-2.5 text-xs font-medium text-slate-200 hover:border-cyan-400 hover:text-white"
                >
                  {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              {isIOS ? (
                <ol className="list-decimal space-y-1.5 pl-4 text-slate-300">
                  <li>Open the link above in <strong className="text-white">Safari</strong>.</li>
                  <li>Tap the <strong className="text-white">Share</strong> button in Safari&apos;s bar.</li>
                  <li>Tap <strong className="text-white">Add to Home Screen</strong> to launch fullscreen anytime.</li>
                </ol>
              ) : (
                <ol className="list-decimal space-y-1.5 pl-4 text-slate-300">
                  <li>Open the link above directly in <strong className="text-white">Chrome</strong> (outside preview frames).</li>
                  <li>Tap the browser menu (<strong className="text-white">⋮</strong>) and choose <strong className="text-white">Install app</strong> or <strong className="text-white">Add to Home screen</strong>.</li>
                  <li>Launch <strong className="text-white">HOLLOWWIRE</strong> from your app drawer — offline play is cached automatically.</li>
                </ol>
              )}
            </div>

            <button
              type="button"
              onClick={() => setShowGuide(false)}
              className="mt-5 flex h-10 w-full items-center justify-center bg-cyan-400 text-sm font-semibold text-slate-950 transition-colors hover:bg-cyan-300"
            >
              Got It
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="pointer-events-none fixed bottom-3 left-3 z-50 flex items-center gap-2 border border-amber-400/60 bg-[#090d18]/95 px-3 py-1.5 text-xs font-medium text-amber-200 shadow-lg">
      <WifiOff className="h-3.5 w-3.5 text-amber-400" />
      <span>Offline Mode · Game cached for play</span>
    </div>
  );
};
