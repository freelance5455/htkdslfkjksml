import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, Share2, X, CheckCircle2 } from 'lucide-react';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // If already running as an installed PWA, hide the button
  if (isInstalled) {
    return null;
  }

  // Chromium / Android / Desktop flow
  if (isInstallable) {
    return (
      <button
        onClick={install}
        className="flex items-center gap-1.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 px-3 py-1.5 text-xs font-semibold text-emerald-400 hover:bg-emerald-500/25 active:scale-95 transition-all"
        title="تثبيت التطبيق على جهازك"
      >
        <Download className="w-3.5 h-3.5" />
        <span>تثبيت PWA</span>
      </button>
    );
  }

  // iOS Safari flow
  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className="flex items-center gap-1.5 rounded-full bg-zinc-800/80 border border-zinc-700/60 px-3 py-1.5 text-xs font-semibold text-zinc-300 hover:bg-zinc-700/80 active:scale-95 transition-all"
        >
          <Download className="w-3.5 h-3.5" />
          <span>تثبيت</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-in fade-in duration-200">
            <div className="w-full max-w-sm rounded-3xl bg-[#16171c] border border-zinc-800 p-6 shadow-2xl text-right">
              <div className="flex items-center justify-between pb-3 border-b border-zinc-800/80 mb-4">
                <span className="font-bold text-white text-base">تثبيت التطبيق على آيفون</span>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="p-1 rounded-full text-zinc-400 hover:text-white hover:bg-zinc-800"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-3 text-sm text-zinc-300">
                <div className="flex items-start gap-3">
                  <div className="w-7 h-7 rounded-full bg-zinc-800 flex items-center justify-center shrink-0 text-emerald-400 font-bold text-xs">
                    1
                  </div>
                  <p>
                    اضغط على زر المشاركة <Share2 className="w-4 h-4 inline mx-1 text-emerald-400" /> في شريط متصفح سفاري السفلي.
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-7 h-7 rounded-full bg-zinc-800 flex items-center justify-center shrink-0 text-emerald-400 font-bold text-xs">
                    2
                  </div>
                  <p>
                    مرر لأسفل واختر <strong>إضافة إلى الشاشة الرئيسية</strong> (Add to Home Screen).
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-7 h-7 rounded-full bg-zinc-800 flex items-center justify-center shrink-0 text-emerald-400 font-bold text-xs">
                    3
                  </div>
                  <p>
                    اضغط على <strong>إضافة</strong> أعلى اليمين ليصبح متاحاً بدون إنترنت كأي تطبيق أصلي!
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowIOSGuide(false)}
                className="mt-6 w-full rounded-2xl bg-emerald-500 py-3 text-sm font-bold text-black hover:bg-emerald-400 transition"
              >
                فهمت ذلك
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
