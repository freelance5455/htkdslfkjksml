import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, Smartphone, X, CheckCircle2, Share, PlusSquare } from 'lucide-react';

export const PWAInstallButton: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [justInstalled, setJustInstalled] = useState(false);

  // If already running as an installed PWA
  if (isInstalled && !justInstalled) {
    return (
      <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-medium">
        <CheckCircle2 className="w-3.5 h-3.5" />
        <span>Installed App</span>
      </div>
    );
  }

  // Chromium / Android / Desktop flow
  if (isInstallable) {
    return (
      <button
        onClick={async () => {
          const success = await install();
          if (success) setJustInstalled(true);
        }}
        title="Install YT Music on your device for background playback & offline access"
        className={`flex items-center gap-2 rounded-full font-medium transition cursor-pointer active:scale-95 shadow-md ${
          compact
            ? 'bg-[#ff0000] hover:bg-[#cc0000] text-white px-3 py-1.5 text-xs'
            : 'bg-[#ff0000] hover:bg-[#cc0000] text-white px-4 py-2 text-sm'
        }`}
      >
        <Smartphone className="w-4 h-4" />
        <span>Install App</span>
      </button>
    );
  }

  // iOS Safari flow (WebKit beforeinstallprompt alternate guide)
  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className={`flex items-center gap-1.5 rounded-full border border-white/20 hover:border-white/40 bg-white/10 hover:bg-white/15 px-3 py-1.5 text-xs font-medium text-white transition active:scale-95 cursor-pointer`}
        >
          <Smartphone className="w-3.5 h-3.5 text-[#ff0000]" />
          <span>Install on iOS</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
            <div className="w-full max-w-sm rounded-2xl bg-[#181818] border border-white/10 p-6 shadow-2xl text-white">
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-[#ff0000] flex items-center justify-center text-white font-bold text-sm">
                    YT
                  </div>
                  <h3 className="font-semibold text-base">Install on iPhone / iPad</h3>
                </div>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="p-1 rounded-full text-white/60 hover:text-white hover:bg-white/10"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="mt-4 space-y-3.5 text-sm text-neutral-300">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-neutral-800 text-neutral-200">
                    <Share className="w-4 h-4 text-sky-400" />
                  </div>
                  <div>
                    <p className="font-medium text-white">1. Tap the Share button</p>
                    <p className="text-xs text-neutral-400">At the bottom of Safari browser toolbar.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-neutral-800 text-neutral-200">
                    <PlusSquare className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div>
                    <p className="font-medium text-white">2. Select &apos;Add to Home Screen&apos;</p>
                    <p className="text-xs text-neutral-400">Scroll down the menu list and tap Add.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-neutral-800 text-neutral-200">
                    <CheckCircle2 className="w-4 h-4 text-red-500" />
                  </div>
                  <div>
                    <p className="font-medium text-white">3. Enjoy Background Playback</p>
                    <p className="text-xs text-neutral-400">Launches full screen with lockscreen controls!</p>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setShowIOSGuide(false)}
                className="mt-6 w-full rounded-xl bg-white/10 hover:bg-white/20 py-2.5 text-sm font-semibold text-white transition"
              >
                Got It
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  // Fallback for desktop browser or standard install prompt
  return (
    <button
      onClick={() => {
        alert("To install YT Music:\n• On Chrome/Edge: Click the install icon (⊕) in the browser address bar.\n• On Android: Open browser menu (⋮) -> 'Install app'.\n• On iOS: Tap Share -> 'Add to Home Screen'.");
      }}
      className="hidden sm:flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 hover:bg-white/10 px-3 py-1.5 text-xs font-medium text-neutral-300 hover:text-white transition cursor-pointer"
    >
      <Download className="w-3.5 h-3.5 text-neutral-400" />
      <span>Install App</span>
    </button>
  );
};
