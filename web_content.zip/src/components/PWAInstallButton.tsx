import React, { useState, useEffect } from 'react';
import { Download, Smartphone, X, Check } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export const PWAInstallButton: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  useEffect(() => {
    // Detect standalone mode
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    setIsInstalled(isStandalone);

    // Detect iOS devices
    const userAgent = window.navigator.userAgent.toLowerCase();
    const isIOSDevice = /iphone|ipad|ipod/.test(userAgent);
    setIsIOS(isIOSDevice);

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setIsInstalled(true);
      setDeferredPrompt(null);
    }
  };

  // If already running standalone on Android
  if (isInstalled) {
    return (
      <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 text-xs font-mono-code">
        <Check className="w-3.5 h-3.5" />
        Installed Standalone
      </div>
    );
  }

  // Android / Chromium direct install
  if (deferredPrompt) {
    return (
      <button
        onClick={handleInstallClick}
        className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 px-3.5 py-1.5 text-xs font-bold font-orbitron text-gray-950 uppercase tracking-wider shadow-lg shadow-cyan-500/30 hover:brightness-110 active:scale-95 transition"
      >
        <Smartphone className="w-4 h-4" />
        Install to Android
      </button>
    );
  }

  // iOS Safari fallback
  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className="flex items-center gap-1.5 rounded-xl border border-cyan-500/40 bg-gray-900 px-3 py-1.5 text-xs font-mono-code text-cyan-300 hover:bg-cyan-950/60 transition"
        >
          <Smartphone className="w-3.5 h-3.5" />
          Add to Home Screen
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-950/80 backdrop-blur-sm p-4">
            <div className="w-full max-w-sm rounded-2xl bg-gray-900 border border-cyan-500/40 p-5 shadow-2xl">
              <div className="flex items-center justify-between pb-2 border-b border-gray-800">
                <h3 className="text-sm font-orbitron font-bold text-cyan-300">Install Jarvis on Mobile</h3>
                <button onClick={() => setShowIOSGuide(false)} className="text-slate-400 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <p className="mt-3 text-xs text-slate-300 font-rajdhani leading-relaxed">
                1. Tap the <strong className="text-cyan-400">Share</strong> button in Safari's bottom toolbar.<br />
                2. Scroll down and tap <strong className="text-cyan-400">Add to Home Screen</strong>.<br />
                3. Launch Jarvis directly from your app drawer with fullscreen immersion!
              </p>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="mt-4 w-full rounded-xl bg-cyan-600 py-2 text-xs font-bold font-orbitron uppercase tracking-wider text-gray-950 hover:bg-cyan-500"
              >
                Understood, Sir
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  // Default button for Android users where prompt event hasn't fired yet
  return (
    <button
      onClick={() => {
        alert('To install Jarvis on your Android phone:\n1. Tap the 3 dots (⋮) in Chrome menu\n2. Tap "Install App" or "Add to Home screen"');
      }}
      className="flex items-center gap-1.5 rounded-xl border border-cyan-500/40 bg-gray-900 px-3 py-1.5 text-xs font-mono-code text-cyan-300 hover:bg-cyan-950/60 transition"
    >
      <Smartphone className="w-3.5 h-3.5" />
      Install App
    </button>
  );
};
