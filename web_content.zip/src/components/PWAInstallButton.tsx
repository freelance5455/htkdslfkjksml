import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall.ts';
import { Download, Share, X, Check } from 'lucide-react';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [installedSuccess, setInstalledSuccess] = useState(false);

  // If already running as an installed PWA, hide completely
  if (isInstalled) {
    return null;
  }

  // Chromium / Android / Desktop flow (supports native install prompt)
  if (isInstallable) {
    return (
      <div className="w-full flex justify-center py-1">
        <button
          onClick={async () => {
            const ok = await install();
            if (ok) setInstalledSuccess(true);
          }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-950/80 hover:bg-emerald-900/90 text-emerald-300 border border-emerald-500/30 text-xs font-medium shadow-sm transition-all hover:scale-[1.02] active:scale-95"
        >
          {installedSuccess ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span>App installiert!</span>
            </>
          ) : (
            <>
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span>Als App installieren</span>
            </>
          )}
        </button>
      </div>
    );
  }

  // iOS Safari flow (WebKit doesn't trigger beforeinstallprompt, needs Share -> Add to Home Screen)
  if (isIOS) {
    return (
      <>
        <div className="w-full flex justify-center py-1">
          <button
            onClick={() => setShowIOSGuide(true)}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-700 text-xs font-medium transition-all"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>Zum Home-Bildschirm hinzufügen</span>
          </button>
        </div>

        {showIOSGuide && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs animate-in fade-in"
            onClick={() => setShowIOSGuide(false)}
          >
            <div
              className="relative w-full max-w-sm rounded-2xl bg-zinc-900 border border-zinc-800 p-5 shadow-2xl space-y-4"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
                <h4 className="text-sm font-bold text-white">Auf iPhone / iPad installieren</h4>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="p-1 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <ol className="text-xs text-zinc-300 space-y-2.5 list-decimal list-inside leading-relaxed">
                <li className="flex items-start gap-2">
                  <span className="font-semibold text-emerald-400">1.</span>
                  <span>Tippe unten in Safari auf das <Share className="inline w-3.5 h-3.5 mx-1 text-emerald-400" /> <strong>Teilen</strong>-Symbol.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-semibold text-emerald-400">2.</span>
                  <span>Scrolle nach unten und wähle <strong>&quot;Zum Home-Bildschirm&quot;</strong>.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-semibold text-emerald-400">3.</span>
                  <span>Tippe oben rechts auf <strong>Hinzufügen</strong>.</span>
                </li>
              </ol>

              <button
                onClick={() => setShowIOSGuide(false)}
                className="w-full py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-white transition-colors"
              >
                Verstanden
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
