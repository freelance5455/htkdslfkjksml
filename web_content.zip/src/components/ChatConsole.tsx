import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Archive,
  ArrowUp,
  Brain,
  Check,
  CheckCircle,
  Clock,
  Code,
  Compass,
  Copy,
  Cpu,
  Download,
  Edit2,
  FileText,
  Folder,
  Layers,
  Menu,
  MessageSquare,
  Mic,
  MicOff,
  MoreVertical,
  Plus,
  Radio,
  RotateCcw,
  Search,
  Send,
  ShieldAlert,
  Sparkles,
  Terminal,
  Trash2,
  TrendingUp,
  Volume2,
  Wrench,
  X,
} from 'lucide-react';
import { api } from '../services/api.ts';
import type {
  ChatMessage,
  ConversationItem,
  CoreLoopStage,
  ProjectItem,
  TaskItem,
} from '../types.ts';
import { ChatInputBox, type ChatInputBoxHandle } from './ChatInputBox.tsx';
import { ProjectWorkspaceModal } from './ProjectWorkspaceModal.tsx';
import { TrashArchiveModal } from './TrashArchiveModal.tsx';
import { ArtifactCard, type ArtifactData } from './ArtifactCard.tsx';

interface ChatConsoleProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  isExecuting: boolean;
  activeTask: TaskItem | null;
  currentStage: CoreLoopStage | null;
  onSelectTask: (taskId: string) => void;
  conversations?: ConversationItem[];
  currentConversationId?: string;
  onSelectConversation?: (id: string) => void;
  onCreateConversation?: (title?: string, topic?: string, projectId?: string) => void;
  onRenameConversation?: (id: string, newTitle: string) => void;
  onDeleteConversation?: (id: string) => void;
  projects?: ProjectItem[];
  selectedProjectId?: string | null;
  onSelectProject?: (projectId: string | null) => void;
  onCreateProject?: (name: string, description: string, contextBrief: string) => Promise<void>;
  onUpdateProject?: (id: string, updates: Partial<ProjectItem>) => Promise<void>;
  onDeleteProject?: (id: string, permanent?: boolean) => Promise<void>;
  onRefreshData?: () => void;
}

const SAMPLE_MISSIONS = [
  {
    icon: <Brain className="w-3.5 h-3.5 text-purple-600" />,
    label: 'Founder & Developer identity',
    prompt: 'Who is your founder and developer?',
  },
  {
    icon: <Sparkles className="w-3.5 h-3.5 text-sky-600" />,
    label: 'Hinglish: Quantum gravity',
    prompt: 'Quantum gravity detail mein samjhao, with analogies and core physics distinction.',
  },
  {
    icon: <Code className="w-3.5 h-3.5 text-emerald-600" />,
    label: 'Direct arithmetic: 12 × 12',
    prompt: '12 × 12',
  },
  {
    icon: <Search className="w-3.5 h-3.5 text-indigo-600" />,
    label: 'Free developer resources',
    prompt: 'Find me legitimate free developer tools and free hosting services with zero credit cards required.',
  },
  {
    icon: <Cpu className="w-3.5 h-3.5 text-amber-600" />,
    label: 'Run system diagnostics',
    prompt: 'Run full system diagnostics across memory, tools, and sub-agent subsystem states.',
  },
];

function extractArtifactsFromContent(
  content: string,
  messageId: string
): { displayText: string; artifacts: ArtifactData[] } {
  if (!content) return { displayText: '', artifacts: [] };

  const artifacts: ArtifactData[] = [];
  let counter = 1;

  // 1. Check for document download URLs (/api/documents/xxx/download)
  const docDownloadMatches = content.match(/\/api\/documents\/([a-zA-Z0-9_-]+)\/download/g);
  if (docDownloadMatches) {
    for (const link of docDownloadMatches) {
      artifacts.push({
        id: `${messageId}-doc-${counter++}`,
        type: 'document',
        title: 'Generated Official Document (PDF/Doc)',
        content: `Official document ready for export.\nDirect link: ${link}`,
        downloadUrl: link,
        summary: 'Downloadable PDF-1.4 spec document produced by JARVIS Document Engine',
      });
    }
  }

  // 2. Check for sandboxed file download URLs (/api/files/xxx/download)
  const fileDownloadMatches = content.match(/\/api\/files\/([a-zA-Z0-9_-]+)\/download/g);
  if (fileDownloadMatches) {
    for (const link of fileDownloadMatches) {
      artifacts.push({
        id: `${messageId}-file-${counter++}`,
        type: 'data',
        title: 'Attached Sandboxed File',
        content: `Sandboxed workspace file.\nDirect link: ${link}`,
        downloadUrl: link,
        summary: 'Sandboxed storage file',
      });
    }
  }

  // 3. Check for website project preview/download URLs (/api/websites/xxx)
  const websiteMatches = content.match(/\/api\/websites\/([a-zA-Z0-9_-]+)/g);
  if (websiteMatches) {
    const rawIds = websiteMatches.map((m) => m.split('/')[3]).filter(Boolean);
    const uniqueIds = Array.from(new Set(rawIds));
    for (const siteId of uniqueIds) {
      artifacts.push({
        id: `${messageId}-web-${counter++}`,
        type: 'website',
        title: 'Production Web Project (Multi-File Package)',
        content: `Production-ready responsive website project synthesized by JARVIS.\nPreview: /api/websites/${siteId}/preview\nDownload: /api/websites/${siteId}/download`,
        previewUrl: `/api/websites/${siteId}/preview`,
        downloadUrl: `/api/websites/${siteId}/download`,
        summary: 'Multi-file web project with responsive UI, cart, and .zip package download',
      });
    }
  }

  // 4. Check for fenced code blocks ```lang ... ```
  const codeBlockRegex = /```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g;
  let match: RegExpExecArray | null;
  while ((match = codeBlockRegex.exec(content)) !== null) {
    const lang = (match[1] || 'code').toLowerCase();
    const codeContent = match[2];

    let artType: ArtifactData['type'] = 'code';
    let artTitle = `Code Snippet (${lang})`;

    if (lang === 'html' || codeContent.includes('<!DOCTYPE html>') || codeContent.includes('<html')) {
      artType = 'website';
      artTitle = 'Generated Website (index.html)';
    } else if (lang === 'json') {
      artType = 'data';
      artTitle = 'Structured Dataset (data.json)';
    } else if (lang === 'python' || lang === 'py') {
      artType = 'code';
      artTitle = 'Python Script (main.py)';
    } else if (lang === 'typescript' || lang === 'ts' || lang === 'tsx') {
      artType = 'code';
      artTitle = 'TypeScript Module (App.tsx)';
    } else if (lang === 'javascript' || lang === 'js') {
      artType = 'code';
      artTitle = 'JavaScript Module (index.js)';
    } else if (lang === 'markdown' || lang === 'md') {
      artType = 'document';
      artTitle = 'Markdown Document (README.md)';
    }

    artifacts.push({
      id: `${messageId}-code-${counter++}`,
      type: artType,
      title: artTitle,
      language: lang,
      content: codeContent,
      summary: `${codeContent.split('\n').length} lines of ${lang}`,
    });
  }

  return { displayText: content, artifacts };
}

export const ChatConsole: React.FC<ChatConsoleProps> = ({
  messages,
  onSendMessage,
  isExecuting,
  activeTask,
  currentStage,
  onSelectTask,
  conversations = [],
  currentConversationId = 'conv_default',
  onSelectConversation,
  onCreateConversation,
  onRenameConversation,
  onDeleteConversation,
  projects = [],
  selectedProjectId = null,
  onSelectProject,
  onCreateProject,
  onUpdateProject,
  onDeleteProject,
  onRefreshData,
}) => {
  // Voice states
  const [isListening, setIsListening] = useState(false);
  const [isContinuousVoice, setIsContinuousVoice] = useState(false);
  const [interimTranscript, setInterimTranscript] = useState('');
  const [voiceNotice, setVoiceNotice] = useState<string | null>(null);
  const [voiceSessionStatus, setVoiceSessionStatus] = useState<
    'IDLE' | 'LISTENING' | 'INTERIM_DETECTED' | 'SEGMENTING' | 'COMMITTED'
  >('IDLE');

  // Sidebar & Modals state
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [conversationSearch, setConversationSearch] = useState('');
  const [editingConvId, setEditingConvId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newTopic, setNewTopic] = useState('General');
  const [assignConvId, setAssignConvId] = useState<string | null>(null);
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const [attachedFiles, setAttachedFiles] = useState<any[]>([]);
  const [isExportingDoc, setIsExportingDoc] = useState(false);
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);

  // Modals
  const [isWorkspaceModalOpen, setIsWorkspaceModalOpen] = useState(false);
  const [isTrashModalOpen, setIsTrashModalOpen] = useState(false);

  // Refs
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatInputRef = useRef<ChatInputBoxHandle>(null);
  const recognitionRef = useRef<any>(null);
  const silenceTimerRef = useRef<any>(null);

  // Load attached files for active conversation
  useEffect(() => {
    if (currentConversationId) {
      api.getFiles({ conversationId: currentConversationId })
        .then((res) => {
          if (res.success && Array.isArray(res.files)) {
            setAttachedFiles(res.files);
          }
        })
        .catch((err) => {
          console.warn('Could not load attached files for conversation:', err);
        });
    } else {
      setAttachedFiles([]);
    }
  }, [currentConversationId]);

  // Upload file handler
  const handleUploadFile = async (file: File) => {
    return new Promise<void>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const base64Data = reader.result as string;
          const res = await api.uploadFile({
            originalName: file.name,
            mimeType: file.type || 'application/octet-stream',
            base64Data,
            conversationId: currentConversationId,
            projectId: selectedProjectId || undefined,
          });
          if (res.success && res.file) {
            setAttachedFiles((prev) => [res.file, ...prev]);
          }
          resolve();
        } catch (err) {
          console.error('File upload failed:', err);
          reject(err);
        }
      };
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsDataURL(file);
    });
  };

  // Remove attachment handler
  const handleRemoveAttachment = async (id: string) => {
    try {
      await api.deleteFile(id);
      setAttachedFiles((prev) => prev.filter((f) => f.id !== id));
    } catch (err) {
      console.error('Failed to remove attachment:', err);
    }
  };

  // Export current conversation history as document
  const handleExportChat = async (format: 'md' | 'pdf') => {
    if (messages.length === 0 || isExportingDoc) return;
    setIsExportingDoc(true);
    try {
      const docTitle = `JARVIS_Chat_${activeConv?.title || 'Session'}_${new Date().toISOString().split('T')[0]}`;
      const docBody = messages
        .map((m) => `### ${m.role === 'user' ? 'User' : 'JARVIS 5.1'} (${new Date(m.timestamp).toLocaleTimeString()})\n\n${m.content}`)
        .join('\n\n---\n\n');

      const res = await api.generateDocument({
        title: docTitle,
        format,
        content: docBody,
        conversationId: currentConversationId,
        projectId: selectedProjectId || undefined,
      });

      if (res.success && res.document?.downloadUrl) {
        const a = document.createElement('a');
        a.href = res.document.downloadUrl;
        a.download = res.document.filename || `${docTitle}.${format}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      }
    } catch (err) {
      console.error('Failed to export document:', err);
    } finally {
      setIsExportingDoc(false);
    }
  };

  // Text-To-Speech (SpeechSynthesis API)
  const handleToggleSpeak = useCallback((msgId: string, text: string) => {
    if (typeof window === 'undefined' || !window.speechSynthesis) {
      setVoiceNotice('Speech synthesis is not supported in this browser environment.');
      setTimeout(() => setVoiceNotice(null), 4000);
      return;
    }

    if (speakingMsgId === msgId) {
      window.speechSynthesis.cancel();
      setSpeakingMsgId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const cleanText = text.replace(/[*#`_\[\]]/g, '').slice(0, 2000);
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.onend = () => setSpeakingMsgId(null);
    utterance.onerror = () => setSpeakingMsgId(null);
    setSpeakingMsgId(msgId);
    window.speechSynthesis.speak(utterance);
  }, [speakingMsgId]);

  // Clean up speech synthesis on unmount
  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const [isInterrupted, setIsInterrupted] = useState(false);
  const [isVoiceStopped, setIsVoiceStopped] = useState(false);

  const voiceState: 'LISTENING' | 'THINKING' | 'SPEAKING' | 'INTERRUPTED' | 'OFF' | 'UNAVAILABLE' =
    typeof window !== 'undefined' && !((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition)
      ? 'UNAVAILABLE'
      : isInterrupted
      ? 'INTERRUPTED'
      : isListening
      ? 'LISTENING'
      : isExecuting
      ? 'THINKING'
      : speakingMsgId
      ? 'SPEAKING'
      : 'OFF';

  // 6-state Voice Chat state for dedicated Voice Chat control
  const voiceChatState: 'idle' | 'listening' | 'processing' | 'speaking' | 'interrupted' | 'stopped' =
    isInterrupted
      ? 'interrupted'
      : isListening
      ? 'listening'
      : isExecuting
      ? 'processing'
      : speakingMsgId
      ? 'speaking'
      : isVoiceStopped
      ? 'stopped'
      : 'idle';

  // Auto-scroll messages on update
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isExecuting, activeTask?.logs]);

  // Maintain input focus after send or task completion
  useEffect(() => {
    if (!isExecuting) {
      chatInputRef.current?.focus();
    }
  }, [isExecuting]);

  // Web Speech API Initialization with Continuous Mode Support
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
        setVoiceSessionStatus('LISTENING');
      };

      recognition.onresult = (event: any) => {
        let currentInterim = '';
        let currentFinal = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const transcriptChunk = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            currentFinal += transcriptChunk;
          } else {
            currentInterim += transcriptChunk;
          }
        }

        if (currentInterim) {
          setInterimTranscript(currentInterim);
          setVoiceSessionStatus('INTERIM_DETECTED');
        }

        if (currentFinal) {
          const finalizedText = currentFinal.trim();
          if (finalizedText) {
            chatInputRef.current?.appendValue(finalizedText);
            setInterimTranscript('');
            setVoiceSessionStatus('COMMITTED');

            if (isContinuousVoice) {
              clearTimeout(silenceTimerRef.current);
              silenceTimerRef.current = setTimeout(() => {
                setVoiceSessionStatus('SEGMENTING');
              }, 2000);
            }
          }
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error event:', event.error);
        setIsListening(false);
        setVoiceSessionStatus('IDLE');
        setInterimTranscript('');
        if (event.error === 'not-allowed') {
          setVoiceNotice('Microphone access was denied. Please allow microphone permissions.');
        } else if (event.error !== 'no-speech') {
          setVoiceNotice(`Speech recognition status: ${event.error}`);
        }
        setTimeout(() => setVoiceNotice(null), 5000);
      };

      recognition.onend = () => {
        if (isContinuousVoice && isListening) {
          try {
            recognition.start();
            return;
          } catch {
            setIsListening(false);
            setVoiceSessionStatus('IDLE');
          }
        } else {
          setIsListening(false);
          setVoiceSessionStatus('IDLE');
        }
      };

      recognitionRef.current = recognition;
    }

    return () => {
      try {
        recognitionRef.current?.stop();
      } catch {}
      clearTimeout(silenceTimerRef.current);
    };
  }, [isContinuousVoice, isListening]);

  const handleToggleMic = useCallback(() => {
    if (!recognitionRef.current) {
      setVoiceNotice('Web Speech API is not supported in this browser.');
      setTimeout(() => setVoiceNotice(null), 4000);
      return;
    }

    if (isListening) {
      try {
        recognitionRef.current.stop();
      } catch {}
      setIsListening(false);
      setVoiceSessionStatus('IDLE');
      setInterimTranscript('');
    } else {
      try {
        recognitionRef.current.start();
        setIsListening(true);
        setVoiceSessionStatus('LISTENING');
      } catch (err) {
        console.warn('Recognition start failed:', err);
      }
    }
  }, [isListening]);

  const handleToggleContinuous = useCallback(() => {
    setIsContinuousVoice((prev) => !prev);
  }, []);

  const handleToggleVoiceChat = useCallback(() => {
    // 1. If speaking, interrupt speech immediately
    if (speakingMsgId) {
      if (typeof window !== 'undefined' && window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
      setSpeakingMsgId(null);
      setIsInterrupted(true);
      setTimeout(() => setIsInterrupted(false), 2500);
      return;
    }

    // 2. If listening, stop listening and show stopped state
    if (isListening) {
      try {
        recognitionRef.current?.stop();
      } catch {}
      setIsListening(false);
      setIsVoiceStopped(true);
      setTimeout(() => setIsVoiceStopped(false), 2500);
      return;
    }

    // 3. If idle or stopped, start voice chat session
    setIsInterrupted(false);
    setIsVoiceStopped(false);
    handleToggleMic();
  }, [speakingMsgId, isListening, handleToggleMic]);

  const handleQuickPrompt = useCallback(
    (prompt: string) => {
      if (isExecuting) return;
      onSendMessage(prompt);
      chatInputRef.current?.focus();
    },
    [isExecuting, onSendMessage]
  );

  // Conversation Management Handlers
  const handleSaveRename = (id: string) => {
    if (editTitle.trim() && onRenameConversation) {
      onRenameConversation(id, editTitle.trim());
    }
    setEditingConvId(null);
    setEditTitle('');
  };

  const handleCreateNewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onCreateConversation) {
      onCreateConversation(
        newTitle.trim() || 'New Session',
        newTopic.trim() || 'General',
        selectedProjectId || undefined
      );
    }
    setIsCreatingNew(false);
    setNewTitle('');
    setNewTopic('General');
  };

  const handleMoveToProject = async (convId: string, projectId: string | null) => {
    try {
      await api.updateConversation(convId, { projectId });
      setAssignConvId(null);
      if (onRefreshData) onRefreshData();
    } catch (err) {
      console.error('Failed to move conversation to project:', err);
    }
  };

  const handleSoftDelete = async (convId: string) => {
    if (onDeleteConversation) {
      onDeleteConversation(convId);
    }
  };

  const handleArchiveChat = async (convId: string, isArchived: boolean) => {
    try {
      await api.updateConversation(convId, { isArchived });
      if (onRefreshData) onRefreshData();
    } catch (err) {
      console.error('Failed to update archive status:', err);
    }
  };

  const handleCopyMessage = (id: string, text: string) => {
    try {
      navigator.clipboard.writeText(text);
      setCopiedMsgId(id);
      setTimeout(() => setCopiedMsgId(null), 2000);
    } catch (err) {
      console.warn('Clipboard copy failed:', err);
    }
  };

  const handleRegenerate = (msgIndex: number) => {
    if (isExecuting) return;
    for (let i = msgIndex; i >= 0; i--) {
      if (messages[i].role === 'user') {
        onSendMessage(messages[i].content);
        return;
      }
    }
  };

  // Filter conversations
  const filteredConversations = conversations.filter((c) => {
    // Soft delete / trash filter
    if (c.isTrash) return false;
    // Project filter if selected
    if (selectedProjectId && c.projectId !== selectedProjectId) return false;
    // Search query
    if (conversationSearch.trim()) {
      const q = conversationSearch.toLowerCase();
      return (
        c.title.toLowerCase().includes(q) ||
        (c.topic || '').toLowerCase().includes(q) ||
        (c.lastMessageSnippet || '').toLowerCase().includes(q)
      );
    }
    // Normal active chat list hides archived sessions (accessible via TrashArchiveModal)
    return !c.isArchived;
  });

  const activeConv = conversations.find((c) => c.id === currentConversationId);
  const activeProject = projects.find((p) => p.id === selectedProjectId);

  return (
    <div
      id="chat-console-container"
      className="relative flex h-[calc(100vh-230px)] min-h-[540px] bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs transition-colors"
    >
      {/* 1. Multi-Chat & Project Workspace Drawer / Sidebar */}
      {isSidebarOpen && (
        <aside
          id="chat-conversations-sidebar"
          className="absolute md:relative inset-y-0 left-0 w-72 sm:w-80 border-r border-slate-200 bg-slate-50 md:bg-slate-50/70 flex flex-col shrink-0 z-30 shadow-lg md:shadow-none"
        >
          {/* Workspace & Project Selector Header */}
          <div className="p-3 border-b border-slate-200 bg-slate-100/60 flex items-center justify-between">
            <button
              onClick={() => setIsWorkspaceModalOpen(true)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white border border-slate-200 hover:border-sky-300 text-slate-800 text-xs font-semibold shadow-2xs transition-all max-w-[150px] truncate"
              title="Open Project Workspace Manager"
            >
              <Folder className="w-3.5 h-3.5 text-sky-600 shrink-0" />
              <span className="truncate">
                {activeProject ? activeProject.name : 'All Workspaces'}
              </span>
            </button>

            <div className="flex items-center gap-1">
              <button
                onClick={() => setIsTrashModalOpen(true)}
                className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-200/60 transition-colors"
                title="View Archived & Trash Chats"
              >
                <Archive className="w-3.5 h-3.5" />
              </button>

              <button
                id="new-chat-btn"
                onClick={() => setIsCreatingNew(true)}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold shadow-2xs transition-all"
                title="Start a new isolated chat conversation"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New</span>
              </button>

              <button
                onClick={() => setIsSidebarOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
                title="Hide All Chats sidebar (focus Active Chat)"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Active Project Filter Pill if active */}
          {activeProject && (
            <div className="px-3 py-1.5 bg-sky-50 border-b border-sky-200 flex items-center justify-between text-[11px] text-sky-900">
              <span className="truncate font-mono">
                FILTER: <strong>{activeProject.name}</strong>
              </span>
              <button
                onClick={() => onSelectProject && onSelectProject(null)}
                className="text-sky-600 hover:text-sky-900 p-0.5 rounded"
                title="Clear project filter"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* New Chat Form Drawer */}
          {isCreatingNew && (
            <form onSubmit={handleCreateNewSubmit} className="p-3 bg-white border-b border-slate-200 space-y-2">
              <span className="text-[11px] font-mono font-bold text-slate-700 block">
                CREATE NEW CONVERSATION
              </span>
              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="Session title e.g. Quantum Research"
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-sky-500"
                autoFocus
              />
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newTopic}
                  onChange={(e) => setNewTopic(e.target.value)}
                  placeholder="Topic e.g. Physics"
                  className="flex-1 px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-sky-500"
                />
                <button
                  type="submit"
                  className="px-3 py-1 bg-sky-600 hover:bg-sky-700 text-white rounded-lg text-xs font-semibold"
                >
                  Create
                </button>
                <button
                  type="button"
                  onClick={() => setIsCreatingNew(false)}
                  className="p-1 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </form>
          )}

          {/* Search Filter */}
          <div className="p-2.5 border-b border-slate-200/80">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={conversationSearch}
                onChange={(e) => setConversationSearch(e.target.value)}
                placeholder="Filter chats by title, topic, text..."
                className="w-full pl-8 pr-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-sky-400 font-sans"
              />
              {conversationSearch && (
                <button
                  onClick={() => setConversationSearch('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>

          {/* Conversations Scroll List */}
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {filteredConversations.map((conv) => {
              const isActive = conv.id === currentConversationId;
              const isEditing = editingConvId === conv.id;
              const isAssigning = assignConvId === conv.id;
              const convProject = projects.find((p) => p.id === conv.projectId);

              return (
                <div
                  key={conv.id}
                  onClick={() => {
                    if (!isEditing && onSelectConversation) {
                      onSelectConversation(conv.id);
                      if (typeof window !== 'undefined' && window.innerWidth < 768) {
                        setIsSidebarOpen(false);
                      }
                    }
                  }}
                  className={`group relative p-2.5 rounded-xl border transition-all cursor-pointer ${
                    isActive
                      ? 'bg-white border-sky-300 text-slate-900 shadow-xs'
                      : 'bg-transparent border-transparent hover:bg-white/80 hover:border-slate-200 text-slate-700'
                  }`}
                >
                  {isEditing ? (
                    <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                      <input
                        type="text"
                        value={editTitle}
                        onChange={(e) => setEditTitle(e.target.value)}
                        className="flex-1 px-2 py-1 text-xs border border-sky-400 rounded bg-white"
                        autoFocus
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleSaveRename(conv.id);
                          if (e.key === 'Escape') setEditingConvId(null);
                        }}
                      />
                      <button
                        onClick={() => handleSaveRename(conv.id)}
                        className="px-2 py-1 bg-sky-600 text-white rounded text-[11px] font-bold"
                      >
                        Save
                      </button>
                    </div>
                  ) : isAssigning ? (
                    <div
                      className="p-2 bg-white rounded-lg border border-slate-300 space-y-1 text-xs"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <span className="font-bold text-[10px] font-mono text-slate-600 block">
                        ASSIGN TO PROJECT:
                      </span>
                      <button
                        onClick={() => handleMoveToProject(conv.id, null)}
                        className="w-full text-left px-2 py-1 rounded hover:bg-slate-100 text-[11px] text-slate-600"
                      >
                        • No Project (Unassigned)
                      </button>
                      {projects.map((p) => (
                        <button
                          key={p.id}
                          onClick={() => handleMoveToProject(conv.id, p.id)}
                          className="w-full text-left px-2 py-1 rounded hover:bg-sky-50 text-[11px] font-semibold text-slate-800 truncate"
                        >
                          📁 {p.name}
                        </button>
                      ))}
                      <button
                        onClick={() => setAssignConvId(null)}
                        className="w-full text-center text-[10px] text-slate-400 hover:text-slate-600 pt-1"
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <div>
                      <div className="flex items-start justify-between gap-1.5">
                        <span className="font-semibold text-xs text-slate-900 truncate leading-snug">
                          {conv.title}
                        </span>
                        <div className="flex items-center gap-1 shrink-0">
                          {convProject && (
                            <span className="text-[9px] font-mono px-1 py-0.2 rounded bg-sky-50 text-sky-700 border border-sky-200">
                              {convProject.name.slice(0, 10)}
                            </span>
                          )}
                          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-100 text-slate-600 border border-slate-200">
                            {conv.topic || 'General'}
                          </span>
                        </div>
                      </div>

                      {conv.lastMessageSnippet && (
                        <p className="text-[11px] text-slate-500 truncate mt-1">
                          {conv.lastMessageSnippet}
                        </p>
                      )}

                      <div className="mt-1.5 flex items-center justify-between text-[10px] font-mono text-slate-400">
                        <span>{conv.messageCount ?? 0} messages</span>
                        <span>{new Date(conv.updatedAt).toLocaleDateString()}</span>
                      </div>

                      {/* Hover action buttons */}
                      <div className="absolute right-2 top-2 hidden group-hover:flex items-center gap-1 bg-white/95 p-0.5 rounded-lg border border-slate-200 shadow-2xs">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setAssignConvId(conv.id);
                          }}
                          className="p-1 hover:text-sky-600 text-slate-400"
                          title="Assign to Project"
                        >
                          <Folder className="w-3 h-3" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleArchiveChat(conv.id, !conv.isArchived);
                          }}
                          className={`p-1 hover:text-amber-600 ${conv.isArchived ? 'text-amber-600' : 'text-slate-400'}`}
                          title={conv.isArchived ? 'Unarchive chat' : 'Archive chat'}
                        >
                          <Archive className="w-3 h-3" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setEditingConvId(conv.id);
                            setEditTitle(conv.title);
                          }}
                          className="p-1 hover:text-sky-600 text-slate-400"
                          title="Rename chat"
                        >
                          <Edit2 className="w-3 h-3" />
                        </button>
                        {conversations.length > 1 && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleSoftDelete(conv.id);
                            }}
                            className="p-1 hover:text-rose-600 text-slate-400"
                            title="Move to Trash"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}

            {filteredConversations.length === 0 && (
              <div className="text-center py-6 text-xs text-slate-400 font-mono">
                {conversationSearch ? 'No matching chats found.' : 'No conversations in this view.'}
              </div>
            )}
          </div>
        </aside>
      )}

      {/* 2. Main Chat Console Area */}
      <main className="flex-1 flex flex-col min-w-0 bg-white">
        {/* Console Top Header Bar */}
        <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <button
              id="toggle-all-chats-btn"
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold shadow-2xs transition-all"
              title={isSidebarOpen ? 'Hide All Chats (focus Active Chat)' : 'Show All Chats list'}
            >
              <MessageSquare className="w-3.5 h-3.5 text-sky-600" />
              <span className="hidden sm:inline">{isSidebarOpen ? 'Active Chat Focus' : 'All Chats'}</span>
            </button>

            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold tracking-wide text-slate-800 uppercase">
                {activeConv?.title || 'JARVIS 5.1 OPERATIONAL WORKSPACE'}
              </span>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-white text-slate-600 border border-slate-200">
                TOPIC: {activeConv?.topic || 'GENERAL'}
              </span>
              {activeProject && (
                <span className="hidden sm:inline-flex text-[11px] font-mono px-2 py-0.5 rounded bg-sky-50 text-sky-700 border border-sky-200">
                  PROJECT: {activeProject.name}
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center gap-3 text-[11px] font-mono text-slate-500">
            {messages.length > 0 && (
              <div className="flex items-center gap-1.5">
                <button
                  id="export-pdf-doc-btn"
                  onClick={() => handleExportChat('pdf')}
                  disabled={isExportingDoc}
                  className="flex items-center gap-1 px-2 py-1 rounded bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-[10px] font-semibold transition-all disabled:opacity-50"
                  title="Export current session as PDF document"
                >
                  <Download className="w-3 h-3 text-sky-600" />
                  <span>{isExportingDoc ? 'Exporting...' : 'Export PDF'}</span>
                </button>
              </div>
            )}
            {/* Voice Status Indicator Pill */}
            <div
              className={`hidden sm:flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-mono font-bold border transition-colors ${
                voiceState === 'LISTENING'
                  ? 'bg-rose-50 border-rose-300 text-rose-700 animate-pulse'
                  : voiceState === 'SPEAKING'
                  ? 'bg-sky-50 border-sky-300 text-sky-700 animate-pulse'
                  : voiceState === 'THINKING'
                  ? 'bg-amber-50 border-amber-300 text-amber-700 animate-pulse'
                  : voiceState === 'UNAVAILABLE'
                  ? 'bg-slate-100 border-slate-200 text-slate-400'
                  : 'bg-slate-50 border-slate-200 text-slate-600'
              }`}
            >
              <span
                className={`w-1.5 h-1.5 rounded-full ${
                  voiceState === 'LISTENING'
                    ? 'bg-rose-500'
                    : voiceState === 'SPEAKING'
                    ? 'bg-sky-500'
                    : voiceState === 'THINKING'
                    ? 'bg-amber-500'
                    : 'bg-slate-400'
                }`}
              />
              <span>VOICE: {voiceState}</span>
            </div>
            {isContinuousVoice && (
              <span className="hidden sm:flex items-center gap-1 text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                <Radio className="w-3 h-3 text-emerald-600 animate-pulse" />
                CONTINUOUS MIC
              </span>
            )}
            <span className="hidden sm:inline">IDENTITY:</span>
            <span className="text-emerald-700 font-semibold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              JARVIS 5.1
            </span>
          </div>
        </div>

        {/* Voice Error Notice */}
        {voiceNotice && (
          <div className="px-4 py-2 bg-amber-50 border-b border-amber-200 text-xs text-amber-800 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
            <span>{voiceNotice}</span>
          </div>
        )}

        {/* Live Audio Status Overlay when Voice is Active */}
        {isListening && (
          <div className="px-4 py-2 bg-sky-50 border-b border-sky-200 text-xs font-mono flex items-center justify-between text-sky-900">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
              <span className="font-bold">
                {voiceSessionStatus === 'INTERIM_DETECTED'
                  ? 'VOICE DETECTED'
                  : voiceSessionStatus === 'SEGMENTING'
                  ? 'PROCESSING SEGMENT'
                  : 'LISTENING...'}
              </span>
              {interimTranscript && (
                <span className="text-slate-600 italic font-sans max-w-md truncate">
                  &quot;{interimTranscript}&quot;
                </span>
              )}
            </div>
            <span className="text-[10px] text-sky-700">
              {isContinuousVoice ? 'CONTINUOUS SESSION' : 'PUSH-TO-TALK'}
            </span>
          </div>
        )}

        {/* Messages Scroll Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 font-sans text-sm bg-slate-50/40">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';
            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} max-w-3xl ${
                  isUser ? 'ml-auto' : 'mr-auto'
                }`}
              >
                <div className="flex items-center gap-1.5 mb-1 text-[11px] font-mono text-slate-500">
                  <span className="font-bold text-slate-700">
                    {isUser ? 'OPERATOR (FOUNDER)' : 'JARVIS 5.1'}
                  </span>
                  <span className="text-slate-300">•</span>
                  <span>
                    {new Date(msg.timestamp).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                  {msg.coreStage && (
                    <span className="px-1.5 py-0.2 rounded bg-sky-50 text-sky-800 border border-sky-200 text-[10px] font-medium">
                      {msg.coreStage}
                    </span>
                  )}
                </div>

                <div
                  className={`relative group p-4 rounded-2xl leading-relaxed text-sm ${
                    isUser
                      ? 'bg-sky-50 text-slate-900 border border-sky-200 rounded-tr-xs shadow-xs'
                      : 'bg-white text-slate-850 border border-slate-200 rounded-tl-xs shadow-xs'
                  }`}
                >
                  <div className="whitespace-pre-wrap text-slate-800 select-text leading-relaxed">
                    {msg.content}
                  </div>

                  {/* Render Interactive Artifact Cards if message contains code, sites, data, or documents */}
                  {!isUser && (() => {
                    const { artifacts } = extractArtifactsFromContent(msg.content, msg.id);
                    if (artifacts.length === 0) return null;
                    return (
                      <div className="mt-3 space-y-2">
                        {artifacts.map((art) => (
                          <ArtifactCard key={art.id} artifact={art} />
                        ))}
                      </div>
                    );
                  })()}

                  {/* Message Action Bar (Copy & Regenerate) */}
                  <div className="mt-2.5 pt-2 border-t border-slate-100/80 flex flex-wrap items-center justify-between gap-2 text-[11px]">
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleCopyMessage(msg.id, msg.content)}
                        className="flex items-center gap-1 px-2 py-0.5 rounded text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors text-[10px] font-mono cursor-pointer"
                        title="Copy message text to clipboard"
                      >
                        {copiedMsgId === msg.id ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-600" />
                            <span className="text-emerald-700 font-semibold">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Copy</span>
                          </>
                        )}
                      </button>

                      {!isUser && (
                        <>
                          <button
                            onClick={() => handleToggleSpeak(msg.id, msg.content)}
                            className={`flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono transition-colors cursor-pointer ${
                              speakingMsgId === msg.id
                                ? 'bg-sky-100 text-sky-800 font-bold animate-pulse'
                                : 'text-slate-500 hover:text-sky-700 hover:bg-sky-50'
                            }`}
                            title={speakingMsgId === msg.id ? 'Stop speaking' : 'Read aloud with voice'}
                            aria-label="Read aloud"
                          >
                            <Volume2 className="w-3 h-3" />
                            <span>{speakingMsgId === msg.id ? 'Speaking' : 'Speak'}</span>
                          </button>

                          <button
                            onClick={() => handleRegenerate(messages.indexOf(msg))}
                            disabled={isExecuting}
                            className="flex items-center gap-1 px-2 py-0.5 rounded text-slate-500 hover:text-sky-700 hover:bg-sky-50 transition-colors text-[10px] font-mono disabled:opacity-40 cursor-pointer"
                            title="Regenerate response from previous prompt"
                          >
                            <RotateCcw className="w-3 h-3" />
                            <span>Regenerate</span>
                          </button>
                        </>
                      )}
                    </div>

                    {/* Metadata Badge Bar for Assistant Messages */}
                    {!isUser && (
                      <div className="flex flex-wrap items-center gap-2 text-[11px] font-mono text-slate-600">
                        {msg.metadata?.modelUsed && (
                          <span className="flex items-center gap-1.5 bg-slate-50 px-2 py-0.5 rounded border border-slate-200 text-slate-700">
                            <Cpu className="w-3.5 h-3.5 text-sky-600" />
                            {msg.metadata.modelUsed}
                            {msg.metadata.modelProviderSource === 'LOCAL_HEURISTIC' && (
                              <span className="text-amber-700 font-semibold">[OFFLINE EDGE]</span>
                            )}
                          </span>
                        )}

                        {msg.metadata?.epistemicStatus && (
                          <span className="bg-slate-50 px-2 py-0.5 rounded border border-slate-200 text-slate-600">
                            {msg.metadata.epistemicStatus}
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          {/* Live Execution Logs Banner when active */}
          {isExecuting && activeTask && (
            <div className="bg-white border border-sky-300 rounded-xl p-3.5 max-w-3xl mr-auto font-mono text-xs shadow-xs">
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 text-sky-900">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-sky-600 animate-ping" />
                  <span className="font-bold">CORE LOOP EXECUTING: {currentStage}</span>
                </div>
                <span className="text-slate-500 font-mono">
                  Task ID: {activeTask.id.slice(0, 10)}
                </span>
              </div>
              <div className="space-y-1 max-h-36 overflow-y-auto text-slate-700">
                {activeTask.logs.slice(-5).map((log, index) => (
                  <div key={index} className="flex items-start gap-1.5">
                    <span className="text-sky-600 font-bold">&gt;</span>
                    <span>{log}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Quick Missions */}
        <div className="px-4 py-2 bg-slate-50 border-t border-slate-200 overflow-x-auto scrollbar-thin">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono text-slate-600 flex items-center gap-1.5 whitespace-nowrap font-bold">
              <Sparkles className="w-3.5 h-3.5 text-sky-600" />
              SUGGESTIONS:
            </span>
            {SAMPLE_MISSIONS.map((item, idx) => (
              <button
                key={idx}
                onClick={() => handleQuickPrompt(item.prompt)}
                disabled={isExecuting}
                className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-white border border-slate-200 text-slate-700 hover:border-sky-300 hover:text-sky-900 hover:bg-sky-50/60 text-xs whitespace-nowrap transition-all disabled:opacity-50 shadow-xs"
              >
                {item.icon}
                <span className="font-medium">{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* High-Speed Isolated Input Box (Zero Re-render Lag) */}
        <ChatInputBox
          ref={chatInputRef}
          onSendMessage={onSendMessage}
          isExecuting={isExecuting}
          isListening={isListening}
          isContinuousVoice={isContinuousVoice}
          voiceState={voiceState}
          voiceChatState={voiceChatState}
          interimTranscript={interimTranscript}
          onToggleMic={handleToggleMic}
          onToggleContinuous={handleToggleContinuous}
          onToggleVoiceChat={handleToggleVoiceChat}
          onUploadFile={handleUploadFile}
          attachedFiles={attachedFiles}
          onRemoveAttachment={handleRemoveAttachment}
        />
      </main>

      {/* Project Workspace Modal */}
      <ProjectWorkspaceModal
        isOpen={isWorkspaceModalOpen}
        onClose={() => setIsWorkspaceModalOpen(false)}
        projects={projects}
        conversations={conversations}
        selectedProjectId={selectedProjectId}
        onSelectProject={(pId) => {
          if (onSelectProject) onSelectProject(pId);
        }}
        onCreateProject={async (n, d, cb) => {
          if (onCreateProject) await onCreateProject(n, d, cb);
        }}
        onUpdateProject={async (id, up) => {
          if (onUpdateProject) await onUpdateProject(id, up);
        }}
        onDeleteProject={async (id, perm) => {
          if (onDeleteProject) await onDeleteProject(id, perm);
        }}
        onSelectConversation={(cId) => {
          if (onSelectConversation) onSelectConversation(cId);
        }}
        onCreateConversationInProject={(pId, t) => {
          if (onCreateConversation) onCreateConversation(t, 'Project', pId);
        }}
      />

      {/* Trash & Archive Modal */}
      <TrashArchiveModal
        isOpen={isTrashModalOpen}
        onClose={() => setIsTrashModalOpen(false)}
        onRestored={() => {
          if (onRefreshData) onRefreshData();
        }}
      />
    </div>
  );
};
