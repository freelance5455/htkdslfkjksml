import React, { useState } from 'react';
import { ShieldAlert, KeyRound, ArrowRight, X, AlertTriangle } from 'lucide-react';
import { api } from '../services/api.ts';

interface AdminLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (token: string) => void;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [adminKey, setAdminKey] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminKey.trim()) {
      setError('Please enter Admin Key');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await api.verifyAdminKey(adminKey.trim());
      if (res.success && res.adminToken) {
        localStorage.setItem('ug_admin_token', res.adminToken);
        setAdminKey('');
        onSuccess(res.adminToken);
        onClose();
      } else {
        setError(res.error || 'Invalid Admin Key');
      }
    } catch {
      setError('Server connection error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-150">
      <div className="relative w-full max-w-sm rounded-2xl bg-[#0a0f18] border border-cyan-500/40 p-6 shadow-[0_0_40px_rgba(0,210,255,0.25)] text-slate-100">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-100 transition-colors rounded-lg hover:bg-slate-800"
          aria-label="Close"
        >
          <X size={18} />
        </button>

        <div className="flex flex-col items-center text-center mb-5">
          <div className="w-14 h-14 rounded-2xl bg-cyan-950/60 border border-cyan-500/50 flex items-center justify-center text-cyan-400 mb-3 shadow-[0_0_20px_rgba(0,210,255,0.3)]">
            <ShieldAlert size={28} />
          </div>
          <h3 className="text-lg font-bold text-white tracking-tight">Admin Terminal</h3>
          <p className="text-xs text-slate-400 mt-1">
            Enter Secret Admin Key to access command panel
          </p>
        </div>

        {error && (
          <div className="mb-4 flex items-center gap-2 p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-300 text-xs">
            <AlertTriangle size={16} className="shrink-0 text-red-400" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center gap-1.5">
              <KeyRound size={14} className="text-cyan-400" />
              <span>Admin Key</span>
            </label>
            <input
              type="password"
              value={adminKey}
              onChange={(e) => setAdminKey(e.target.value)}
              placeholder="Enter secret key..."
              autoFocus
              className="w-full px-4 py-2.5 rounded-xl bg-[#0e1626] border border-slate-700 focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 text-white placeholder-slate-500 text-sm outline-none transition-all"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl font-semibold text-sm bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 shadow-lg shadow-cyan-500/25 active:scale-[0.98] transition-all cursor-pointer disabled:opacity-60"
            >
              <span>{loading ? 'Authenticating...' : 'Authorize Admin'}</span>
              <ArrowRight size={16} />
            </button>
          </div>
        </form>

        <div className="mt-4 pt-3 border-t border-slate-800/80 text-center">
          <span className="text-[11px] text-slate-500 font-mono">
            Initial setup key: Abu bakr
          </span>
        </div>
      </div>
    </div>
  );
};
