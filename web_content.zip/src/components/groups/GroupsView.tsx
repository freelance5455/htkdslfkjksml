import React, { useState, useEffect } from 'react';
import { GroupCommunity } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { Users, Plus, Shield, Lock, Globe, Check, UserPlus } from 'lucide-react';
import { CreateGroupModal } from './CreateGroupModal';

interface GroupsViewProps {
  onOpenGroupChat?: (groupId: string) => void;
}

export const GroupsView: React.FC<GroupsViewProps> = () => {
  const { currentUser } = useAuth();
  const [groups, setGroups] = useState<GroupCommunity[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedGroup, setSelectedGroup] = useState<GroupCommunity | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const loadGroups = async () => {
    try {
      setIsLoading(true);
      const res = await api.getGroups({ userId: currentUser?.id });
      setGroups(res.groups || []);
    } catch (err) {
      console.error('Erro ao carregar grupos:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadGroups();
  }, [currentUser?.id]);

  const handleJoinToggle = async (group: GroupCommunity) => {
    if (!currentUser) return;
    try {
      await api.toggleGroupJoin(group.id, currentUser.id);
      loadGroups();
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white font-display flex items-center gap-2">
            <Users className="w-6 h-6 text-blue-400" />
            <span>Grupos & Comunidades Angolanas</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Espaços dedicados à tecnologia, cultura, música, empreendedorismo e debate nacional.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 shadow-lg shadow-blue-600/20 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>Criar Nova Comunidade</span>
        </button>
      </div>

      {/* Grid */}
      {isLoading ? (
        <div className="p-12 text-center text-slate-500 text-xs">A carregar grupos...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {groups.map((grp) => {
            const isMember = grp.isMember;
            const isAdmin = grp.isAdmin;

            return (
              <div
                key={grp.id}
                className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl overflow-hidden shadow-sm flex flex-col justify-between transition-all"
              >
                <div>
                  {/* Cover */}
                  <div className="relative h-32 w-full bg-slate-950 overflow-hidden">
                    <img
                      src={grp.coverImage || '/src/assets/images/luanda_skyline_banner_1793388059121.jpg'}
                      alt={grp.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent" />
                    <span className="absolute top-3 left-3 px-2 py-0.5 bg-slate-950/80 backdrop-blur-md rounded-md text-[10px] font-semibold text-slate-300 flex items-center gap-1 border border-white/10">
                      {grp.isPrivate ? <Lock className="w-3 h-3 text-amber-400" /> : <Globe className="w-3 h-3 text-emerald-400" />}
                      <span>{grp.isPrivate ? 'Grupo Privado' : 'Comunidade Pública'}</span>
                    </span>
                  </div>

                  {/* Body */}
                  <div className="p-5 pt-0 relative">
                    <div className="flex items-end justify-between -mt-6 mb-3">
                      <img
                        src={grp.avatar || '/src/assets/images/angola_user_manuel_1793388060300.jpg'}
                        alt={grp.name}
                        className="w-14 h-14 rounded-2xl object-cover ring-4 ring-slate-900 bg-slate-800"
                      />
                      <span className="text-[11px] font-semibold text-amber-400">
                        {grp.membersCount} {grp.membersCount === 1 ? 'membro' : 'membros'}
                      </span>
                    </div>

                    <h3 className="font-bold text-base text-white font-display mb-1">{grp.name}</h3>
                    <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">{grp.description}</p>

                    {/* Rules snippet */}
                    {grp.rules && grp.rules.length > 0 && (
                      <div className="mt-3 p-2 bg-slate-950/60 rounded-xl border border-slate-800/80 text-[11px] text-slate-400">
                        <span className="font-semibold text-slate-300 block mb-0.5">Regras:</span>
                        <p className="truncate">1. {grp.rules[0]}</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Footer Actions */}
                <div className="p-5 pt-0">
                  <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-3">
                    {isAdmin && (
                      <span className="text-[10px] text-amber-400 font-semibold flex items-center gap-1">
                        <Shield className="w-3 h-3" />
                        Admin
                      </span>
                    )}

                    <button
                      onClick={() => handleJoinToggle(grp)}
                      className={`flex-1 py-2 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                        isMember
                          ? 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                          : 'bg-blue-600 hover:bg-blue-500 text-white shadow-md'
                      }`}
                    >
                      {isMember ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Membro</span>
                        </>
                      ) : (
                        <>
                          <UserPlus className="w-3.5 h-3.5" />
                          <span>Aderir ao Grupo</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Create Modal */}
      <CreateGroupModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onCreated={loadGroups}
      />

    </div>
  );
};
