import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api, ANGOLA_PROVINCES } from '../../services/api';
import { X, Users, RefreshCw, Lock, Globe } from 'lucide-react';

interface CreateGroupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreated: () => void;
}

export const CreateGroupModal: React.FC<CreateGroupModalProps> = ({
  isOpen,
  onClose,
  onCreated
}) => {
  const { currentUser } = useAuth();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Tecnologia');
  const [province, setProvince] = useState(currentUser?.province || 'Luanda');
  const [isPrivate, setIsPrivate] = useState(false);
  const [rules, setRules] = useState('Respeito mútuo entre todos os membros.\nSem conteúdo ofensivo ou spam.');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen || !currentUser) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    try {
      setIsSubmitting(true);
      setErrorMsg(null);
      await api.createGroup({
        name: name.trim(),
        description: description.trim(),
        category,
        province,
        isPrivate,
        creatorId: currentUser.id,
        rules: rules.split('\n').filter(r => r.trim().length > 0)
      });

      onCreated();
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 text-slate-100 max-h-[90vh] overflow-y-auto animate-in zoom-in-95">

        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <h3 className="font-bold text-base text-white font-display flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-400" />
            <span>Criar Comunidade ou Grupo</span>
          </h3>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-3.5">
          {errorMsg && (
            <p className="text-xs text-red-400 bg-red-950/40 p-2.5 rounded-xl border border-red-800/60">{errorMsg}</p>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Nome do Grupo</label>
            <input
              type="text"
              placeholder="Ex: Startups & Inovação Luanda"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Descrição</label>
            <textarea
              rows={2}
              placeholder="Descreva o propósito da comunidade..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-blue-500 resize-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Categoria</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
              >
                <option value="Tecnologia">Tecnologia</option>
                <option value="Arte & Cultura">Arte & Cultura</option>
                <option value="Negócios">Negócios</option>
                <option value="Educação">Educação</option>
                <option value="Desporto">Desporto</option>
                <option value="Geral">Geral</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Província Sede</label>
              <select
                value={province}
                onChange={(e) => setProvince(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
              >
                {ANGOLA_PROVINCES.filter(p => p !== 'Todas').map((p) => (
                  <option key={p} value={p}>{p}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Privacidade</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setIsPrivate(false)}
                className={`p-3 rounded-xl border flex items-center gap-2 text-left text-xs transition-colors ${!isPrivate ? 'bg-blue-600/10 border-blue-500 text-blue-400 font-semibold' : 'bg-slate-950 border-slate-800 text-slate-400'}`}
              >
                <Globe className="w-4 h-4 shrink-0" />
                <div>
                  <p className="text-white">Público</p>
                  <p className="text-[10px] text-slate-500">Qualquer utilizador pode aderir</p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setIsPrivate(true)}
                className={`p-3 rounded-xl border flex items-center gap-2 text-left text-xs transition-colors ${isPrivate ? 'bg-blue-600/10 border-blue-500 text-blue-400 font-semibold' : 'bg-slate-950 border-slate-800 text-slate-400'}`}
              >
                <Lock className="w-4 h-4 shrink-0" />
                <div>
                  <p className="text-white">Privado</p>
                  <p className="text-[10px] text-slate-500">Requer aprovação do admin</p>
                </div>
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Regras da Comunidade (uma por linha)</label>
            <textarea
              rows={2}
              value={rules}
              onChange={(e) => setRules(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-blue-500 font-mono"
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full h-11 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20 transition-all active:scale-[0.98] mt-2"
          >
            {isSubmitting ? (
              <RefreshCw className="w-4 h-4 animate-spin text-white" />
            ) : (
              <span>Criar Comunidade 🇦🇴</span>
            )}
          </button>
        </form>

      </div>
    </div>
  );
};
