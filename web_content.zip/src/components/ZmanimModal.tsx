import React from 'react';
import { X, Sun } from 'lucide-react';
import { CalendarDay, LocationPreset, UserSettings } from '../types';
import { ZmanimPanel } from './ZmanimPanel';

interface ZmanimModalProps {
  isOpen: boolean;
  onClose: () => void;
  date: Date;
  location: LocationPreset;
  settings: UserSettings;
  onUpdateSettings: (newSettings: Partial<UserSettings>) => void;
  day: CalendarDay;
}

export const ZmanimModal: React.FC<ZmanimModalProps> = ({
  isOpen,
  onClose,
  date,
  location,
  settings,
  onUpdateSettings,
  day,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-[#121212] rounded-2xl max-w-2xl w-full border border-[#2A2A2A] shadow-2xl overflow-hidden my-8 flex flex-col text-[#D1D1D1]">
        {/* Header */}
        <div className="p-5 border-b border-[#2A2A2A] flex items-center justify-between bg-[#161616]">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-base text-[#EAEAEA] flex items-center gap-2 font-serif-hebrew">
                <Sun className="w-5 h-5 text-[#C5A267]" />
                <span>זמני היום • Halachic Prayer Times</span>
              </h3>
            </div>
            <p className="text-xs text-[#C5A267] font-medium mt-0.5">
              {day.hebrewDateStrHe} ({day.hebrewDateStr}) • {location.name}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#888888] hover:text-[#EAEAEA] hover:bg-[#252525] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          <ZmanimPanel
            date={date}
            location={location}
            settings={settings}
            onUpdateSettings={onUpdateSettings}
          />
        </div>

        <div className="p-4 border-t border-[#2A2A2A] bg-[#161616] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#C5A267] hover:bg-[#b59257] text-[#0F0F0F] text-xs font-bold transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
