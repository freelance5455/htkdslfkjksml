/**
 * GODEX Phase 1 - Safe Project Import & ZIP Workspace Modal
 * 
 * Features:
 * - Drag-and-drop & file selection for ZIP project archives
 * - Path traversal validation & sanitization
 * - Deep project structure & framework detection
 * - Intelligent conflict detection with existing workspace files
 * - Non-destructive conflict resolution options (Replace, Merge Overwrite, Merge Keep, Subfolder)
 * - File tree preview with byte size and language tags
 * - Live status tracking: Inspecting -> Preview -> Importing -> Imported
 */

import React, { useState, useRef } from 'react';
import { 
  FolderArchive, 
  UploadCloud, 
  FileCode, 
  FileCheck2, 
  AlertTriangle, 
  CheckCircle2, 
  X, 
  Layers, 
  Sparkles, 
  ArrowRight, 
  RefreshCw, 
  FolderPlus, 
  ShieldCheck, 
  FileText, 
  Package, 
  Code2, 
  Search,
  ExternalLink,
  HardDrive
} from 'lucide-react';
import { ZipImportService, ZipValidationResult, ConflictStrategy } from '../services/zipImportService';

interface ImportProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportComplete?: (metadata: any) => void;
  initialFile?: File | Blob | null;
}

export const ImportProjectModal: React.FC<ImportProjectModalProps> = ({
  isOpen,
  onClose,
  onImportComplete,
  initialFile
}) => {
  const [dragActive, setDragActive] = useState(false);
  const [selectedFileName, setSelectedFileName] = useState<string>('');
  const [inspectStatus, setInspectStatus] = useState<'idle' | 'inspecting' | 'preview' | 'importing' | 'imported' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [validationResult, setValidationResult] = useState<ZipValidationResult | null>(null);
  const [strategy, setStrategy] = useState<ConflictStrategy>('replace');
  const [subfolderName, setSubfolderName] = useState<string>('imported-project');
  const [fileFilter, setFileFilter] = useState<string>('');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  // If initialFile is passed, automatically inspect it
  React.useEffect(() => {
    if (isOpen && initialFile) {
      handleFileSelected(initialFile as File);
    }
  }, [isOpen, initialFile]);

  if (!isOpen) return null;

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelected(e.dataTransfer.files[0]);
    }
  };

  const handleFileSelected = async (file: File | Blob) => {
    const name = (file as File).name || 'project.zip';
    setSelectedFileName(name);
    setInspectStatus('inspecting');
    setErrorMessage('');

    try {
      const result = await ZipImportService.inspectZip(file);
      if (!result.valid) {
        setInspectStatus('error');
        setErrorMessage(result.error || 'Failed to inspect ZIP archive');
        setValidationResult(result);
        return;
      }

      setValidationResult(result);
      setStrategy(result.conflicts.length > 0 ? 'replace' : 'replace');
      setInspectStatus('preview');
    } catch (err: any) {
      setInspectStatus('error');
      setErrorMessage(err.message || 'An unexpected error occurred while reading the ZIP file');
    }
  };

  const handleExecuteImport = async () => {
    if (!validationResult || !validationResult.valid) return;

    setInspectStatus('importing');
    try {
      const result = await ZipImportService.importToWorkspace(
        validationResult.extractedFiles,
        strategy,
        strategy === 'subfolder' ? subfolderName : undefined
      );

      if (result.success) {
        setInspectStatus('imported');
        if (onImportComplete) {
          onImportComplete(result.metadata);
        }
      } else {
        setInspectStatus('error');
        setErrorMessage(result.error || 'Failed to write imported files to workspace');
      }
    } catch (err: any) {
      setInspectStatus('error');
      setErrorMessage(err.message || 'Failed to import project files');
    }
  };

  const resetModal = () => {
    setInspectStatus('idle');
    setValidationResult(null);
    setErrorMessage('');
    setSelectedFileName('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const filteredPaths = validationResult
    ? Object.keys(validationResult.extractedFiles).filter(p => 
        p.toLowerCase().includes(fileFilter.toLowerCase())
      )
    : [];

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4 select-none font-mono">
      <div className="w-full max-w-2xl bg-[#090C12] border border-[#1C2538] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="h-14 px-5 border-b border-[#1C2538] flex items-center justify-between bg-[#0D121D] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-950 to-indigo-950 border border-cyan-500/50 flex items-center justify-center text-cyan-400 shadow-md">
              <FolderArchive className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                SAFE PROJECT IMPORT
              </h2>
              <p className="text-[11px] text-neutral-400">
                Extract & inspect ZIP archive into GODEX workspace
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-[#162032] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* 1. IDLE: Drag and Drop Upload */}
          {inspectStatus === 'idle' && (
            <div
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-all ${
                dragActive
                  ? 'border-cyan-400 bg-cyan-950/20'
                  : 'border-[#1E293F] bg-[#0C101A] hover:border-cyan-500/50 hover:bg-[#0E1422]'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".zip,application/zip,application/x-zip-compressed"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleFileSelected(e.target.files[0]);
                  }
                }}
                className="hidden"
              />

              <div className="w-14 h-14 rounded-2xl bg-[#141C2C] border border-[#23324E] flex items-center justify-center text-cyan-400 mb-4 shadow-lg">
                <UploadCloud className="w-7 h-7" />
              </div>

              <h3 className="text-sm font-bold text-white mb-1">
                Choose a ZIP project or drag & drop here
              </h3>
              <p className="text-xs text-neutral-400 max-w-sm mb-4">
                Accepts React, Vite, Next.js, Node, TypeScript, static HTML/CSS/JS, or any standard web project archive.
              </p>

              <div className="flex items-center gap-2">
                <span className="px-3 py-1.5 rounded-lg bg-cyan-950/80 border border-cyan-800 text-cyan-300 text-xs font-semibold hover:bg-cyan-900 transition-colors">
                  Browse ZIP File
                </span>
              </div>

              <div className="mt-6 pt-4 border-t border-[#182236] w-full flex items-center justify-center gap-4 text-[11px] text-neutral-500">
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  Path-traversal protected
                </span>
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  Auto-framework detection
                </span>
              </div>
            </div>
          )}

          {/* 2. INSPECTING: Loading State */}
          {inspectStatus === 'inspecting' && (
            <div className="py-12 flex flex-col items-center justify-center text-center space-y-4">
              <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin" />
              <div>
                <h3 className="text-sm font-bold text-white mb-1">
                  Inspecting & Validating Archive...
                </h3>
                <p className="text-xs text-neutral-400">
                  Verifying entry paths, sanitizing tree, and analyzing project framework.
                </p>
              </div>
            </div>
          )}

          {/* 3. ERROR State */}
          {inspectStatus === 'error' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-rose-950/40 border border-rose-800/80 flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                <div className="space-y-1 text-xs">
                  <div className="font-bold text-rose-300">Import Validation Failed</div>
                  <div className="text-neutral-300">{errorMessage}</div>
                </div>
              </div>

              {validationResult?.rejectedPaths && validationResult.rejectedPaths.length > 0 && (
                <div className="p-3 rounded-xl bg-[#0C101A] border border-[#1E293F] space-y-2">
                  <div className="text-xs font-bold text-neutral-300">Rejected Entry Paths:</div>
                  <div className="max-h-32 overflow-y-auto space-y-1 text-[11px] font-mono text-rose-400">
                    {validationResult.rejectedPaths.map((rej, i) => (
                      <div key={i} className="flex items-center justify-between">
                        <span>{rej.path}</span>
                        <span className="text-neutral-500">[{rej.reason}]</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={resetModal}
                  className="px-3 py-1.5 rounded-lg bg-[#141C2C] hover:bg-[#1E293F] text-neutral-300 text-xs font-semibold"
                >
                  Try Another Archive
                </button>
              </div>
            </div>
          )}

          {/* 4. PREVIEW: Inspection Summary & Strategy Selection */}
          {inspectStatus === 'preview' && validationResult && (
            <div className="space-y-4">
              {/* Detected Project Card */}
              <div className="p-4 rounded-xl bg-[#0D121D] border border-[#1E293F] space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white uppercase tracking-wider">
                      Detected Project
                    </span>
                    <span className="px-2 py-0.5 rounded-md bg-cyan-950 text-cyan-300 border border-cyan-800 text-[10px] font-bold uppercase">
                      {validationResult.metadata.framework}
                    </span>
                  </div>
                  <span className="text-[11px] text-neutral-400 font-mono">
                    {selectedFileName}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                  <div className="p-2.5 rounded-lg bg-[#070A0F] border border-[#162032]">
                    <div className="text-[10px] text-neutral-500 uppercase">Language</div>
                    <div className="font-bold text-neutral-200 uppercase">{validationResult.metadata.primaryLanguage}</div>
                  </div>
                  <div className="p-2.5 rounded-lg bg-[#070A0F] border border-[#162032]">
                    <div className="text-[10px] text-neutral-500 uppercase">Runtime</div>
                    <div className="font-bold text-neutral-200 uppercase">{validationResult.metadata.runtime}</div>
                  </div>
                  <div className="p-2.5 rounded-lg bg-[#070A0F] border border-[#162032]">
                    <div className="text-[10px] text-neutral-500 uppercase">Files Count</div>
                    <div className="font-bold text-cyan-300">{validationResult.totalEntries} files</div>
                  </div>
                  <div className="p-2.5 rounded-lg bg-[#070A0F] border border-[#162032]">
                    <div className="text-[10px] text-neutral-500 uppercase">Total Size</div>
                    <div className="font-bold text-neutral-200">
                      {(validationResult.metadata.totalBytes / 1024).toFixed(1)} KB
                    </div>
                  </div>
                </div>

                {validationResult.metadata.entryPoints.browser && (
                  <div className="flex items-center gap-1.5 text-[11px] text-neutral-400">
                    <Code2 className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Entry Point: <strong className="text-neutral-200">{validationResult.metadata.entryPoints.browser}</strong></span>
                  </div>
                )}
              </div>

              {/* Conflict Strategy Selector */}
              <div className="p-4 rounded-xl bg-[#0D121D] border border-[#1E293F] space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-neutral-200">
                    Workspace Conflict Strategy
                  </span>
                  {validationResult.conflicts.length > 0 && (
                    <span className="text-[10px] text-amber-400 font-mono px-2 py-0.5 rounded bg-amber-950/60 border border-amber-800/80">
                      {validationResult.conflicts.length} overlapping files
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <label 
                    onClick={() => setStrategy('replace')}
                    className={`p-3 rounded-xl border flex items-start gap-2.5 cursor-pointer transition-all ${
                      strategy === 'replace' 
                        ? 'border-cyan-500 bg-cyan-950/30 text-white' 
                        : 'border-[#1A2336] bg-[#080B10] text-neutral-400 hover:border-[#283650]'
                    }`}
                  >
                    <input type="radio" name="strategy" checked={strategy === 'replace'} onChange={() => setStrategy('replace')} className="mt-0.5" />
                    <div>
                      <div className="font-bold text-neutral-200">Replace Workspace</div>
                      <div className="text-[11px] text-neutral-400">Clean slate: Replace current workspace with imported project.</div>
                    </div>
                  </label>

                  <label 
                    onClick={() => setStrategy('merge_overwrite')}
                    className={`p-3 rounded-xl border flex items-start gap-2.5 cursor-pointer transition-all ${
                      strategy === 'merge_overwrite' 
                        ? 'border-cyan-500 bg-cyan-950/30 text-white' 
                        : 'border-[#1A2336] bg-[#080B10] text-neutral-400 hover:border-[#283650]'
                    }`}
                  >
                    <input type="radio" name="strategy" checked={strategy === 'merge_overwrite'} onChange={() => setStrategy('merge_overwrite')} className="mt-0.5" />
                    <div>
                      <div className="font-bold text-neutral-200">Merge (Overwrite)</div>
                      <div className="text-[11px] text-neutral-400">Add all files, overwriting overlapping paths in workspace.</div>
                    </div>
                  </label>

                  <label 
                    onClick={() => setStrategy('merge_keep')}
                    className={`p-3 rounded-xl border flex items-start gap-2.5 cursor-pointer transition-all ${
                      strategy === 'merge_keep' 
                        ? 'border-cyan-500 bg-cyan-950/30 text-white' 
                        : 'border-[#1A2336] bg-[#080B10] text-neutral-400 hover:border-[#283650]'
                    }`}
                  >
                    <input type="radio" name="strategy" checked={strategy === 'merge_keep'} onChange={() => setStrategy('merge_keep')} className="mt-0.5" />
                    <div>
                      <div className="font-bold text-neutral-200">Merge (Keep Existing)</div>
                      <div className="text-[11px] text-neutral-400">Only add non-conflicting new files into workspace.</div>
                    </div>
                  </label>

                  <label 
                    onClick={() => setStrategy('subfolder')}
                    className={`p-3 rounded-xl border flex items-start gap-2.5 cursor-pointer transition-all ${
                      strategy === 'subfolder' 
                        ? 'border-cyan-500 bg-cyan-950/30 text-white' 
                        : 'border-[#1A2336] bg-[#080B10] text-neutral-400 hover:border-[#283650]'
                    }`}
                  >
                    <input type="radio" name="strategy" checked={strategy === 'subfolder'} onChange={() => setStrategy('subfolder')} className="mt-0.5" />
                    <div>
                      <div className="font-bold text-neutral-200">Import to Subfolder</div>
                      <div className="text-[11px] text-neutral-400">Isolate project under a designated directory.</div>
                    </div>
                  </label>
                </div>

                {strategy === 'subfolder' && (
                  <div className="pt-2 flex items-center gap-2">
                    <span className="text-[11px] text-neutral-400">Subfolder path:</span>
                    <input
                      type="text"
                      value={subfolderName}
                      onChange={(e) => setSubfolderName(e.target.value)}
                      placeholder="e.g. imported-project"
                      className="flex-1 bg-[#06080E] border border-cyan-500/60 rounded-lg px-2.5 py-1 text-xs text-white focus:outline-none"
                    />
                  </div>
                )}
              </div>

              {/* File List Preview */}
              <div className="p-4 rounded-xl bg-[#0D121D] border border-[#1E293F] space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-neutral-200">
                    Extracted Files ({filteredPaths.length})
                  </span>
                  <div className="relative w-44">
                    <Search className="w-3 h-3 text-neutral-500 absolute left-2 top-2 pointer-events-none" />
                    <input
                      type="text"
                      value={fileFilter}
                      onChange={e => setFileFilter(e.target.value)}
                      placeholder="Filter files..."
                      className="w-full h-7 pl-6 pr-2 bg-[#070A0F] border border-[#1C2538] rounded-md text-[11px] text-neutral-200 placeholder-neutral-600 focus:outline-none focus:border-cyan-500/50"
                    />
                  </div>
                </div>

                <div className="max-h-40 overflow-y-auto space-y-1 pr-1 font-mono text-[11px]">
                  {filteredPaths.map(path => {
                    const content = validationResult.extractedFiles[path];
                    const isBinary = content.startsWith('data:');
                    const isConflict = validationResult.conflicts.some(c => c.path === path);
                    return (
                      <div
                        key={path}
                        className="flex items-center justify-between px-2 py-1 rounded bg-[#07090F] border border-[#162032]"
                      >
                        <div className="flex items-center gap-2 truncate">
                          <FileCode className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                          <span className="truncate text-neutral-300">{path}</span>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          {isConflict && (
                            <span className="px-1.5 py-0.2 rounded bg-amber-950/80 text-amber-300 text-[9px] border border-amber-800">
                              OVERLAP
                            </span>
                          )}
                          <span className="text-[10px] text-neutral-500">
                            {isBinary ? 'BINARY' : `${(content.length / 1024).toFixed(1)}k`}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* 5. IMPORTING */}
          {inspectStatus === 'importing' && (
            <div className="py-12 flex flex-col items-center justify-center text-center space-y-4">
              <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin" />
              <div>
                <h3 className="text-sm font-bold text-white mb-1">
                  Importing Project to Workspace...
                </h3>
                <p className="text-xs text-neutral-400">
                  Authoritatively writing files, scanning AST symbols, and updating live preview runtime.
                </p>
              </div>
            </div>
          )}

          {/* 6. IMPORTED: Success State */}
          {inspectStatus === 'imported' && (
            <div className="py-8 flex flex-col items-center justify-center text-center space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-emerald-950 border border-emerald-500/60 flex items-center justify-center text-emerald-400 shadow-xl">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h3 className="text-base font-bold text-white">
                  Project Successfully Imported!
                </h3>
                <p className="text-xs text-neutral-400 max-w-md">
                  All {validationResult?.totalEntries} files are now live in the GODEX Workspace. Editor, Live Preview, Terminal, and AI Agents are ready to operate on this project.
                </p>
              </div>

              <div className="pt-4 flex items-center gap-3">
                <button
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg shadow-cyan-950/50 flex items-center gap-2"
                >
                  <span>Open in Studio</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        {inspectStatus === 'preview' && (
          <div className="h-14 px-5 border-t border-[#1C2538] bg-[#0B0E16] flex items-center justify-between shrink-0">
            <button
              onClick={resetModal}
              className="px-3 py-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-[#162032] text-xs font-semibold transition-colors"
            >
              Choose Different File
            </button>

            <div className="flex items-center gap-2">
              <button
                onClick={onClose}
                className="px-3 py-1.5 rounded-lg bg-[#141C2C] hover:bg-[#1E293F] text-neutral-300 text-xs font-semibold transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleExecuteImport}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg shadow-cyan-950/50 flex items-center gap-1.5 transition-all active:scale-95"
              >
                <span>Import to Workspace</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
