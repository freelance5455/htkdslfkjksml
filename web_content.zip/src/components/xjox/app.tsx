import { House, LayoutGrid, Settings, Shield, Star } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { APP_NAME } from "@/lib/xjox/catalog";
import { usePrefs, useTimer } from "@/lib/xjox/store";
import { HomeTab } from "./home";
import { FavoritesTab, ToolsTab } from "./lists";
import { NavProvider, type NavApi, type Overlay, type TabId } from "./nav";
import { DocScreen, SettingsTab } from "./settings";
import { ToolScreen } from "./tools/host";
import { ringTimer } from "./tools/time";
import { Button, Logo, ToastProvider } from "./ui";

const TABS: { id: TabId; label: string; icon: typeof House }[] = [
  { id: "home", label: "Beranda", icon: House },
  { id: "tools", label: "Alat", icon: LayoutGrid },
  { id: "fav", label: "Favorit", icon: Star },
  { id: "settings", label: "Pengaturan", icon: Settings },
];

export function XjoxApp() {
  return (
    <ToastProvider>
      <XjoxRoot />
    </ToastProvider>
  );
}

function XjoxRoot() {
  const [minDone, setMinDone] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const onboarded = usePrefs((state) => state.onboarded);
  const finishOnboarding = usePrefs((state) => state.finishOnboarding);
  useThemeBinder();

  useEffect(() => {
    const timer = window.setTimeout(() => setMinDone(true), 700);
    const unsub = usePrefs.persist.onFinishHydration(() => setHydrated(true));
    if (usePrefs.persist.hasHydrated()) setHydrated(true);
    return () => {
      window.clearTimeout(timer);
      unsub();
    };
  }, []);

  if (!minDone || !hydrated) return <Splash />;
  if (!onboarded) return <Onboarding onDone={finishOnboarding} />;
  return <Shell />;
}

function useThemeBinder() {
  const theme = usePrefs((state) => state.theme);
  useEffect(() => {
    const apply = () => {
      const mode = usePrefs.getState().theme;
      const dark = mode === "dark" || (mode === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
      const root = document.documentElement;
      root.classList.toggle("dark", dark);
      root.style.colorScheme = dark ? "dark" : "light";
      const meta = document.querySelector('meta[name="theme-color"]');
      const canvas = getComputedStyle(root).getPropertyValue("--color-canvas").trim();
      if (meta && canvas) meta.setAttribute("content", canvas);
    };
    apply();
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    media.addEventListener("change", apply);
    return () => media.removeEventListener("change", apply);
  }, [theme]);
}

function Splash() {
  return (
    <div className="grid h-dvh place-items-center bg-canvas px-6 text-ink">
      <div className="flex flex-col items-center gap-5">
        <Logo className="size-16" />
        <div className="text-center">
          <p className="text-3xl font-extrabold tracking-tight">XJOX</p>
          <p className="text-sm font-medium text-mute">Tools</p>
        </div>
        <div className="h-1 w-24 overflow-hidden rounded-full bg-sunken" aria-hidden="true">
          <div className="splash-bar h-full rounded-full bg-accent" />
        </div>
      </div>
    </div>
  );
}

const STEPS = [
  {
    icon: LayoutGrid,
    title: "Alat harian, satu tempat",
    body: "Teks, sandi, satuan, jam, QR, dan berkas. Tidak perlu akun.",
  },
  {
    icon: Shield,
    title: "Tetap di perangkat Anda",
    body: "Hitungan dan riwayat disimpan lokal. Kamera hanya dipakai saat memindai.",
  },
  {
    icon: Star,
    title: "Sematkan yang sering dipakai",
    body: "Tandai favorit supaya alat penting menunggu di beranda.",
  },
];

function Onboarding({ onDone }: { onDone: () => void }) {
  const [step, setStep] = useState(0);
  const current = STEPS[step] ?? STEPS[0];
  const Icon = current.icon;
  const last = step === STEPS.length - 1;
  return (
    <div className="mx-auto flex h-dvh w-full max-w-md flex-col bg-canvas px-5 py-6 text-ink">
      <button type="button" className="h-11 self-end px-2 text-sm font-semibold text-mute" onClick={onDone}>
        Lewati
      </button>
      <div className="flex flex-1 flex-col justify-center">
        <span className="grid size-14 place-items-center rounded-card bg-sunken text-ink">
          <Icon className="size-7" strokeWidth={1.75} aria-hidden="true" />
        </span>
        <h1 className="mt-6 text-3xl font-extrabold tracking-tight">{current.title}</h1>
        <p className="mt-3 text-base leading-relaxed text-mute">{current.body}</p>
      </div>
      <div className="mb-4 flex gap-2" aria-hidden="true">
        {STEPS.map((item, index) => (
          <span key={item.title} className={`h-1.5 flex-1 rounded-full ${index === step ? "bg-accent" : "bg-sunken"}`} />
        ))}
      </div>
      <Button
        onClick={() => {
          if (last) onDone();
          else setStep((value) => value + 1);
        }}
      >
        {last ? "Mulai" : "Lanjut"}
      </Button>
    </div>
  );
}

function Shell() {
  const [tab, setTabState] = useState<TabId>("home");
  const [overlay, setOverlay] = useState<Overlay | null>(null);
  const touch = usePrefs((state) => state.touch);
  const fired = useTimer((state) => state.fired);
  const acknowledge = useTimer((state) => state.acknowledge);
  const scroller = useRef<HTMLDivElement>(null);

  const nav = useMemo<NavApi>(
    () => ({
      tab,
      overlay,
      setTab: (next) => {
        setTabState(next);
        setOverlay(null);
      },
      openTool: (id) => {
        touch(id);
        setOverlay({ kind: "tool", id });
      },
      openDoc: (id) => setOverlay({ kind: "doc", id }),
      back: () => setOverlay(null),
    }),
    [overlay, tab, touch],
  );

  useEffect(() => {
    scroller.current?.scrollTo(0, 0);
  }, [tab, overlay]);

  return (
    <NavProvider value={nav}>
      <TimerWatcher />
      <div className="h-dvh overflow-hidden bg-canvas text-ink">
        <a href="#isi" className="sr-only focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-50 focus:rounded-control focus:bg-card focus:px-3 focus:py-2">
          Loncat ke isi
        </a>
        <div className="mx-auto flex h-full max-w-6xl">
          <aside className="hidden w-64 shrink-0 flex-col border-r border-line px-4 py-5 md:flex">
            <div className="mb-6 flex items-center gap-3 px-2">
              <Logo className="size-10" />
              <div>
                <div className="font-extrabold tracking-tight">{APP_NAME}</div>
                <div className="text-xs text-mute">Data tetap di perangkat</div>
              </div>
            </div>
            <nav className="flex flex-1 flex-col gap-1" aria-label="Utama">
              {TABS.map((item) => (
                <NavButton key={item.id} item={item} active={tab === item.id && !overlay} onClick={() => nav.setTab(item.id)} wide />
              ))}
            </nav>
          </aside>
          <div className="flex min-w-0 flex-1 flex-col">
            {fired ? (
              <div className="flex items-center justify-between gap-3 bg-accent px-4 py-3 text-accent-ink">
                <p className="text-sm font-semibold">Timer selesai.</p>
                <button type="button" className="h-11 rounded-control bg-card px-3 text-sm font-semibold text-ink" onClick={acknowledge}>
                  Tutup
                </button>
              </div>
            ) : null}
            <main id="isi" ref={scroller} className="min-h-0 flex-1 overflow-y-auto">
              {overlay?.kind === "tool" ? (
                <ToolScreen id={overlay.id} />
              ) : overlay?.kind === "doc" ? (
                <DocScreen id={overlay.id} />
              ) : tab === "home" ? (
                <HomeTab />
              ) : tab === "tools" ? (
                <ToolsTab />
              ) : tab === "fav" ? (
                <FavoritesTab />
              ) : (
                <SettingsTab />
              )}
            </main>
            <nav className="grid grid-cols-4 border-t border-line bg-card pb-safe md:hidden" aria-label="Utama">
              {TABS.map((item) => (
                <NavButton key={item.id} item={item} active={tab === item.id && !overlay} onClick={() => nav.setTab(item.id)} />
              ))}
            </nav>
          </div>
        </div>
      </div>
    </NavProvider>
  );
}

function NavButton({
  item,
  active,
  onClick,
  wide = false,
}: {
  item: (typeof TABS)[number];
  active: boolean;
  onClick: () => void;
  wide?: boolean;
}) {
  const Icon = item.icon;
  return (
    <button
      type="button"
      onClick={onClick}
      aria-current={active ? "page" : undefined}
      className={
        wide
          ? `flex h-12 items-center gap-3 rounded-control px-3 text-sm font-semibold ${active ? "bg-sunken text-ink" : "text-mute"}`
          : `flex min-h-14 flex-col items-center justify-center gap-1 text-xs font-semibold ${active ? "text-accent" : "text-mute"}`
      }
    >
      <Icon className="size-5" strokeWidth={1.75} aria-hidden="true" />
      {item.label}
    </button>
  );
}

function TimerWatcher() {
  const running = useTimer((state) => state.running);
  const endAt = useTimer((state) => state.endAt);
  useEffect(() => {
    if (!running || endAt == null) return;
    const delay = Math.max(0, endAt - Date.now());
    const id = window.setTimeout(() => {
      const state = useTimer.getState();
      if (!state.running || state.endAt !== endAt) return;
      useTimer.setState({ running: false, fired: true });
      ringTimer();
      if (typeof Notification !== "undefined" && Notification.permission === "granted") {
        try {
          new Notification(APP_NAME, { body: "Timer selesai." });
        } catch {
          /* notifikasi opsional */
        }
      }
    }, delay);
    return () => window.clearTimeout(id);
  }, [endAt, running]);
  return null;
}
