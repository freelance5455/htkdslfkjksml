import { useMemo, useState } from "react";
import { CATEGORIES, DEFAULT_QUICK, getTool, searchTools, TOOLS, type CategoryId } from "@/lib/xjox/catalog";
import { usePrefs } from "@/lib/xjox/store";
import { idsToTools, ToolList, ToolRow } from "./lists";
import { useNav } from "./nav";
import { IconButton, SearchField, Stat } from "./ui";
import { Settings } from "lucide-react";

function greet(date: Date, name: string) {
  const hour = date.getHours();
  const hello = hour < 11 ? "Selamat pagi" : hour < 15 ? "Selamat siang" : hour < 18 ? "Selamat sore" : "Selamat malam";
  return name ? `${hello}, ${name}` : hello;
}

export function HomeTab() {
  const nav = useNav();
  const name = usePrefs((state) => state.displayName.trim());
  const favorites = usePrefs((state) => state.favorites);
  const recents = usePrefs((state) => state.recents);
  const usage = usePrefs((state) => state.usage);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<CategoryId | "all">("all");
  const [now] = useState(() => new Date());
  const filtering = query.trim().length > 0 || category !== "all";
  const results = useMemo(() => searchTools(query, category), [query, category]);
  const quick = useMemo(() => {
    const ranked = [...TOOLS].filter((tool) => (usage[tool.id] ?? 0) > 0).sort((a, b) => (usage[b.id] ?? 0) - (usage[a.id] ?? 0));
    return (ranked.length > 0 ? ranked.slice(0, 4) : idsToTools(DEFAULT_QUICK)).slice(0, 4);
  }, [usage]);
  const favoriteTools = idsToTools(favorites).slice(0, 4);
  const recentTools = recents.map((item) => getTool(item.id)).filter((tool) => Boolean(tool));
  const last = recentTools[0];

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-5 px-4 pt-4 pb-8">
      <header className="flex items-start justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-mute capitalize">
            {now.toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long" })}
          </p>
          <h1 className="mt-1 text-2xl font-extrabold tracking-tight">{greet(now, name)}</h1>
        </div>
        <IconButton label="Pengaturan" onClick={() => nav.setTab("settings")}>
          <Settings />
        </IconButton>
      </header>
      <SearchField value={query} onChange={setQuery} />
      <div className="grid grid-cols-3 gap-2">
        <Stat label="Alat" value={String(TOOLS.length)} />
        <Stat label="Favorit" value={String(favorites.length)} />
        <Stat label="Terakhir" value={last?.name ?? "—"} />
      </div>
      <div className="flex gap-2 overflow-x-auto pb-1">
        <FilterChip active={category === "all"} onClick={() => setCategory("all")}>
          Semua
        </FilterChip>
        {CATEGORIES.map((item) => (
          <FilterChip key={item.id} active={category === item.id} onClick={() => setCategory(item.id)}>
            {item.name}
          </FilterChip>
        ))}
      </div>
      {filtering ? (
        <ToolList tools={results} emptyTitle="Tidak ketemu" emptyBody="Coba nama lain, misalnya sandi, suhu, atau QR." />
      ) : (
        <>
          <section className="space-y-2">
            <h2 className="text-sm font-bold">Akses cepat</h2>
            <div className="grid grid-cols-2 gap-2">
              {quick.map((tool) => (
                <button key={tool.id} type="button" onClick={() => nav.openTool(tool.id)} className="min-h-16 rounded-card border border-line bg-card px-3 py-3 text-left">
                  <span className="block font-semibold">{tool.name}</span>
                  <span className="mt-0.5 block text-sm text-mute">{CATEGORIES.find((item) => item.id === tool.category)?.name}</span>
                </button>
              ))}
            </div>
          </section>
          <section className="space-y-2">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold">Favorit</h2>
              {favorites.length > 0 ? (
                <button type="button" className="h-11 px-2 text-sm font-semibold text-accent" onClick={() => nav.setTab("fav")}>
                  Semua
                </button>
              ) : null}
            </div>
            {favoriteTools.length === 0 ? (
              <p className="rounded-card border border-dashed border-line px-3 py-4 text-sm text-mute">Belum ada. Bintangi alat yang sering dipakai.</p>
            ) : (
              <ul className="space-y-2">
                {favoriteTools.map((tool) => (
                  <li key={tool.id}>
                    <ToolRow tool={tool} />
                  </li>
                ))}
              </ul>
            )}
          </section>
          <section className="space-y-2">
            <h2 className="text-sm font-bold">Baru dipakai</h2>
            {recentTools.length === 0 ? (
              <p className="text-sm text-mute">Alat yang dibuka akan tercatat di sini.</p>
            ) : (
              <ul className="space-y-2">
                {recentTools.slice(0, 4).map((tool) =>
                  tool ? (
                    <li key={tool.id}>
                      <ToolRow tool={tool} />
                    </li>
                  ) : null,
                )}
              </ul>
            )}
          </section>
        </>
      )}
    </div>
  );
}

function FilterChip({ active, onClick, children }: { active: boolean; onClick: () => void; children: string }) {
  return (
    <button type="button" onClick={onClick} className={`h-11 shrink-0 rounded-full px-4 text-sm font-semibold ${active ? "bg-accent text-accent-ink" : "border border-line bg-card text-ink"}`}>
      {children}
    </button>
  );
}
