import * as AlertDialog from "@radix-ui/react-alert-dialog";
import { clsx, type ClassValue } from "clsx";
import { Copy, Search, Share2 } from "lucide-react";
import { createContext, useCallback, useContext, useRef, useState, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes } from "react";
import { twMerge } from "tailwind-merge";
import { APP_NAME } from "@/lib/xjox/catalog";
import { copyText, shareText } from "./clipboard";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const ToastContext = createContext<(message: string) => void>(() => {});

export function useToast() {
  return useContext(ToastContext);
}

export function ToastProvider({ children }: { children: ReactNode }) {
  const [message, setMessage] = useState<string | null>(null);
  const timer = useRef(0);
  const push = useCallback((next: string) => {
    setMessage(next);
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setMessage(null), 2400);
  }, []);
  return (
    <ToastContext.Provider value={push}>
      {children}
      {message ? (
        <div className="pointer-events-none fixed inset-x-0 bottom-24 z-50 flex justify-center px-4 md:bottom-8">
          <p role="status" className="rounded-control bg-ink px-4 py-3 text-sm font-medium text-canvas">
            {message}
          </p>
        </div>
      ) : null}
    </ToastContext.Provider>
  );
}

const buttonStyles = {
  primary: "bg-accent text-accent-ink",
  secondary: "bg-sunken text-ink",
  ghost: "bg-transparent text-ink",
  danger: "bg-danger text-danger-ink",
} as const;

export function Button({
  variant = "primary",
  className,
  children,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: keyof typeof buttonStyles }) {
  return (
    <button
      type="button"
      {...props}
      className={cn(
        "inline-flex h-12 items-center justify-center gap-2 rounded-control px-4 text-sm font-semibold disabled:opacity-45 [&_svg]:size-4",
        buttonStyles[variant],
        className,
      )}
    >
      {children}
    </button>
  );
}

export function IconButton({
  label,
  pressed,
  className,
  children,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { label: string; pressed?: boolean }) {
  return (
    <button
      type="button"
      aria-label={label}
      aria-pressed={pressed}
      {...props}
      className={cn(
        "grid size-11 shrink-0 place-items-center rounded-control text-ink hover:bg-sunken disabled:opacity-40 [&_svg]:size-5",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function Logo({ className }: { className?: string }) {
  return (
    <span className={cn("grid place-items-center rounded-control bg-accent text-accent-ink", className)} aria-hidden="true">
      <svg viewBox="0 0 32 32" className="size-[54%]">
        <path d="M8 8.5L24 23.5M24 8.5L8 23.5" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
      </svg>
    </span>
  );
}

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return <section className={cn("rounded-card border border-line bg-card p-4", className)}>{children}</section>;
}

export function Field({
  label,
  hint,
  error,
  children,
}: {
  label: string;
  hint?: string;
  error?: string | null;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-semibold text-ink">{label}</span>
      {children}
      {error ? <span className="mt-1.5 block text-sm text-danger">{error}</span> : null}
      {!error && hint ? <span className="mt-1.5 block text-sm text-mute">{hint}</span> : null}
    </label>
  );
}

const controlClass =
  "h-12 w-full rounded-control border border-line bg-card px-3 text-base text-ink outline-none focus-visible:border-accent";

export function TextInput(props: InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={cn(controlClass, props.className)} />;
}

export function TextArea(props: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={cn(
        "min-h-36 w-full resize-y rounded-control border border-line bg-card p-3 text-base leading-relaxed text-ink outline-none focus-visible:border-accent",
        props.className,
      )}
    />
  );
}

export function SelectInput(props: SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={cn(controlClass, props.className)} />;
}

export function SearchField({
  value,
  onChange,
  label = "Cari alat",
}: {
  value: string;
  onChange: (value: string) => void;
  label?: string;
}) {
  return (
    <label className="relative block">
      <span className="sr-only">{label}</span>
      <Search className="pointer-events-none absolute top-1/2 left-3 size-5 -translate-y-1/2 text-mute" aria-hidden="true" />
      <input
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder="Cari alat…"
        className={cn(controlClass, "pl-11")}
        type="search"
        enterKeyHint="search"
      />
    </label>
  );
}

export function Segmented<T extends string>({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: T;
  onChange: (value: T) => void;
  options: { id: T; label: string }[];
}) {
  return (
    <div>
      <div id={`${label}-seg`} className="mb-1.5 text-sm font-semibold text-ink">
        {label}
      </div>
      <div role="radiogroup" aria-labelledby={`${label}-seg`} className="flex gap-1 rounded-control bg-sunken p-1">
        {options.map((option) => {
          const active = option.id === value;
          return (
            <button
              key={option.id}
              type="button"
              role="radio"
              aria-checked={active}
              onClick={() => onChange(option.id)}
              className={cn(
                "h-11 min-w-0 flex-1 rounded-control px-2 text-sm font-semibold",
                active ? "bg-card text-ink" : "text-mute",
              )}
            >
              {option.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export function CheckRow({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}) {
  return (
    <label className="flex min-h-12 items-center gap-3 rounded-control border border-line bg-card px-3">
      <input
        type="checkbox"
        checked={checked}
        onChange={(event) => onChange(event.target.checked)}
        className="size-5 accent-accent"
      />
      <span className="text-sm font-medium">{label}</span>
    </label>
  );
}

export function EmptyState({ title, body, action }: { title: string; body: string; action?: ReactNode }) {
  return (
    <div className="rounded-card border border-dashed border-line px-4 py-8 text-center">
      <h2 className="text-base font-bold">{title}</h2>
      <p className="mx-auto mt-1 max-w-sm text-sm text-mute">{body}</p>
      {action ? <div className="mt-4">{action}</div> : null}
    </div>
  );
}

export function Output({ text, placeholder }: { text: string; placeholder: string }) {
  if (!text) {
    return <p className="rounded-control border border-dashed border-line px-3 py-4 text-sm text-mute">{placeholder}</p>;
  }
  return <pre className="max-h-80 overflow-auto whitespace-pre-wrap break-words rounded-control bg-sunken p-3 font-mono text-sm leading-relaxed text-ink">{text}</pre>;
}

export function ActionRow({ text, title = APP_NAME }: { text: string; title?: string }) {
  const toast = useToast();
  const disabled = text.trim().length === 0;
  return (
    <div className="grid grid-cols-2 gap-2">
      <Button
        disabled={disabled}
        onClick={() => {
          void copyText(text).then((ok) => toast(ok ? "Disalin ke papan klip." : "Gagal menyalin."));
        }}
      >
        <Copy /> Salin
      </Button>
      <Button
        variant="secondary"
        disabled={disabled}
        onClick={() => {
          void shareText(title, text).then((result) => {
            if (result === "shared") toast("Dibagikan.");
            else if (result === "copied") toast("Berbagi tidak tersedia. Teks disalin.");
            else if (result === "failed") toast("Gagal membagikan.");
          });
        }}
      >
        <Share2 /> Bagikan
      </Button>
    </div>
  );
}

export function ConfirmButton({
  title,
  body,
  confirmLabel,
  onConfirm,
  children,
  danger = true,
}: {
  title: string;
  body: string;
  confirmLabel: string;
  onConfirm: () => void;
  children: ReactNode;
  danger?: boolean;
}) {
  return (
    <AlertDialog.Root>
      <AlertDialog.Trigger asChild>{children}</AlertDialog.Trigger>
      <AlertDialog.Portal>
        <AlertDialog.Overlay className="fixed inset-0 z-50 bg-ink/40" />
        <AlertDialog.Content className="fixed top-1/2 left-1/2 z-50 w-[min(100%-2rem,24rem)] -translate-x-1/2 -translate-y-1/2 rounded-card border border-line bg-card p-5 text-ink">
          <AlertDialog.Title className="text-lg font-bold">{title}</AlertDialog.Title>
          <AlertDialog.Description className="mt-2 text-sm text-mute">{body}</AlertDialog.Description>
          <div className="mt-5 grid grid-cols-2 gap-2">
            <AlertDialog.Cancel asChild>
              <Button variant="secondary">Batal</Button>
            </AlertDialog.Cancel>
            <AlertDialog.Action asChild>
              <Button variant={danger ? "danger" : "primary"} onClick={onConfirm}>
                {confirmLabel}
              </Button>
            </AlertDialog.Action>
          </div>
        </AlertDialog.Content>
      </AlertDialog.Portal>
    </AlertDialog.Root>
  );
}

export function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0 rounded-card border border-line bg-card px-3 py-3">
      <div className="truncate text-xs font-medium text-mute">{label}</div>
      <div className="truncate text-lg font-bold tabular-nums">{value}</div>
    </div>
  );
}

export function Notice({ children, tone = "muted" }: { children: ReactNode; tone?: "muted" | "danger" }) {
  return (
    <p className={cn("text-sm", tone === "danger" ? "text-danger" : "text-mute")} role={tone === "danger" ? "alert" : undefined}>
      {children}
    </p>
  );
}
