import { ChevronLeft, ChevronRight } from "lucide-react";
import { APP_NAME, APP_VERSION, getTool } from "@/lib/xjox/catalog";
import { formatWhen } from "@/lib/xjox/format";
import { usePrefs, type ThemeMode } from "@/lib/xjox/store";
import type { DocId } from "./nav";
import { useNav } from "./nav";
import { Button, Card, ConfirmButton, IconButton, Notice, Segmented, TextInput } from "./ui";

export function SettingsTab() {
  const nav = useNav();
  const theme = usePrefs((state) => state.theme);
  const setTheme = usePrefs((state) => state.setTheme);
  const name = usePrefs((state) => state.displayName);
  const setDisplayName = usePrefs((state) => state.setDisplayName);
  const favorites = usePrefs((state) => state.favorites);
  const toggleFavorite = usePrefs((state) => state.toggleFavorite);
  const recents = usePrefs((state) => state.recents);
  const clearUsage = usePrefs((state) => state.clearUsage);
  const clearCalcHistory = usePrefs((state) => state.clearCalcHistory);
  const clearRecentFiles = usePrefs((state) => state.clearRecentFiles);
  const calcCount = usePrefs((state) => state.calcHistory.length);
  const fileCount = usePrefs((state) => state.recentFiles.length);

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-4 px-4 pt-4 pb-8">
      <header>
        <h1 className="text-2xl font-extrabold tracking-tight">Pengaturan</h1>
        <p className="text-sm text-mute">Profil, tampilan, dan data lokal.</p>
      </header>
      <Card className="space-y-3">
        <h2 className="text-sm font-bold">Profil lokal</h2>
        <label className="block">
          <span className="mb-1.5 block text-sm font-semibold">Nama</span>
          <TextInput value={name} maxLength={40} placeholder="Nama panggilan" onChange={(event) => setDisplayName(event.target.value)} />
        </label>
        <Notice>Nama hanya untuk sapaan di beranda. Tidak dikirim ke server.</Notice>
      </Card>
      <Card>
        <Segmented
          label="Tampilan"
          value={theme}
          onChange={(value) => setTheme(value as ThemeMode)}
          options={[
            { id: "system" as ThemeMode, label: "Sistem" },
            { id: "light" as ThemeMode, label: "Terang" },
            { id: "dark" as ThemeMode, label: "Gelap" },
          ]}
        />
      </Card>
      <Card className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-sm font-bold">Bahasa</h2>
          <p className="text-sm text-mute">Indonesia. Bahasa lain belum tersedia.</p>
        </div>
      </Card>
      <Card className="space-y-2">
        <h2 className="text-sm font-bold">Favorit ({favorites.length})</h2>
        {favorites.length === 0 ? (
          <Notice>Belum ada alat yang disematkan.</Notice>
        ) : (
          <ul>
            {favorites.map((id) => {
              const tool = getTool(id);
              if (!tool) return null;
              return (
                <li key={id} className="flex items-center justify-between gap-3 py-1">
                  <button type="button" className="min-h-11 truncate text-left text-sm font-semibold" onClick={() => nav.openTool(id)}>
                    {tool.name}
                  </button>
                  <Button variant="ghost" className="h-11 px-3" onClick={() => toggleFavorite(id)}>
                    Lepas
                  </Button>
                </li>
              );
            })}
          </ul>
        )}
      </Card>
      <div className="overflow-hidden rounded-card border border-line bg-card">
        <LinkRow label="Riwayat penggunaan" detail={recents.length ? `${recents.length} alat` : "Kosong"} onClick={() => nav.openDoc("history")} />
        <LinkRow label="Bantuan" onClick={() => nav.openDoc("help")} />
        <LinkRow label="Kebijakan privasi" onClick={() => nav.openDoc("privacy")} />
        <LinkRow label="Tentang" detail={`Versi ${APP_VERSION}`} onClick={() => nav.openDoc("about")} />
      </div>
      <ConfirmButton title="Hapus riwayat penggunaan?" body="Daftar alat yang baru dipakai dan jumlah pemakaian dihapus. Favorit tetap ada." confirmLabel="Hapus" onConfirm={clearUsage}>
        <Button variant="secondary">Hapus riwayat penggunaan</Button>
      </ConfirmButton>
      <ConfirmButton title="Hapus riwayat perhitungan?" body={`${calcCount} perhitungan lokal akan dihapus.`} confirmLabel="Hapus" onConfirm={clearCalcHistory}>
        <Button variant="secondary">Hapus riwayat perhitungan</Button>
      </ConfirmButton>
      <ConfirmButton title="Hapus daftar berkas?" body={`${fileCount} entri nama berkas akan dihapus. Berkas asli tidak diubah.`} confirmLabel="Hapus" onConfirm={clearRecentFiles}>
        <Button variant="secondary">Hapus daftar berkas</Button>
      </ConfirmButton>
    </div>
  );
}

function LinkRow({ label, detail, onClick }: { label: string; detail?: string; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="flex min-h-14 w-full items-center gap-3 border-b border-line px-4 text-left last:border-b-0">
      <span className="flex-1 font-semibold">{label}</span>
      {detail ? <span className="text-sm text-mute">{detail}</span> : null}
      <ChevronRight className="size-4 text-mute" aria-hidden="true" />
    </button>
  );
}

export function DocScreen({ id }: { id: DocId }) {
  const back = useNav().back;
  const title = id === "privacy" ? "Kebijakan privasi" : id === "help" ? "Bantuan" : id === "about" ? "Tentang" : "Riwayat penggunaan";
  return (
    <div className="rise mx-auto w-full max-w-3xl px-4 pt-2 pb-8">
      <header className="mb-4 flex items-center gap-1">
        <IconButton label="Kembali" onClick={back}>
          <ChevronLeft />
        </IconButton>
        <h1 className="text-xl font-extrabold tracking-tight">{title}</h1>
      </header>
      {id === "history" ? <HistoryBody /> : null}
      {id === "privacy" ? <PrivacyBody /> : null}
      {id === "help" ? <HelpBody /> : null}
      {id === "about" ? <AboutBody /> : null}
    </div>
  );
}

function HistoryBody() {
  const recents = usePrefs((state) => state.recents);
  const openTool = useNav().openTool;
  if (recents.length === 0) return <Notice>Belum ada alat yang dibuka.</Notice>;
  return (
    <ul className="space-y-2">
      {recents.map((item) => {
        const tool = getTool(item.id);
        if (!tool) return null;
        return (
          <li key={`${item.id}-${item.at}`}>
            <button type="button" onClick={() => openTool(item.id)} className="flex min-h-14 w-full items-center justify-between gap-3 rounded-card border border-line bg-card px-3 text-left">
              <span className="font-semibold">{tool.name}</span>
              <span className="text-sm text-mute">{formatWhen(item.at)}</span>
            </button>
          </li>
        );
      })}
    </ul>
  );
}

function PrivacyBody() {
  return (
    <div className="space-y-3 text-sm leading-relaxed text-ink">
      <p>{APP_NAME} memproses data di perangkat Anda. Tidak ada akun, dan tidak ada isi alat yang dikirim ke server.</p>
      <p>Yang tersimpan secara lokal: nama panggilan, tema, favorit, riwayat alat yang dibuka, riwayat perhitungan, serta nama, jenis, dan ukuran berkas yang dipilih. Isi berkas dan kata sandi yang dibuat tidak disimpan.</p>
      <p>Kamera hanya diminta saat Anda menekan Pindai, dan gambarnya tidak diunggah. Notifikasi hanya diminta saat timer dimulai. Papan klip hanya ditulis ketika Anda menekan Salin. Tautan hanya dibuka jika Anda menekan tombolnya.</p>
      <p>Menghapus data situs di browser akan menghapus riwayat lokal. Anda juga bisa menghapusnya dari Pengaturan.</p>
    </div>
  );
}

function HelpBody() {
  return (
    <div className="space-y-4 text-sm leading-relaxed">
      <p>Pilih alat dari Beranda atau tab Alat. Bintang menyimpannya sebagai favorit. Salin dan Bagikan memakai kemampuan perangkat.</p>
      <p>Teks, generator, kalkulator, konversi, dan tanggal bekerja tanpa jaringan. Kata sandi memakai acak kriptografis dan tidak masuk riwayat.</p>
      <p>QR dibuat di perangkat. Pemindai meminta kamera; jika izin ditolak, alat lain tetap bisa dipakai. Tautan hasil pindai tidak dibuka sendiri.</p>
      <p>Timer bisa menampilkan notifikasi jika diizinkan, dan tetap berbunyi di dalam aplikasi. Menutup tab menghentikan timer. Info berkas memakai pemilih berkas sistem; aplikasi tidak menghapus atau mengubah berkas.</p>
      <p>Tombol % pada kalkulator berarti bagi 100. Diskon dan kenaikan ada di alat Persentase. Konversi penyimpanan membedakan dasar 1024 dan 1000 supaya angkanya tidak menyesatkan.</p>
    </div>
  );
}

function AboutBody() {
  return (
    <div className="space-y-3 text-sm leading-relaxed">
      <p className="text-lg font-extrabold">{APP_NAME}</p>
      <p>Versi {APP_VERSION}</p>
      <p>Alat harian yang ringkas: teks, generator, hitung, waktu, QR, dan berkas. Semua berjalan di perangkat ini.</p>
    </div>
  );
}
