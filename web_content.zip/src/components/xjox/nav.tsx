import { createContext, useContext, type ReactNode } from "react";
import type { ToolId } from "@/lib/xjox/catalog";

export type TabId = "home" | "tools" | "fav" | "settings";
export type DocId = "privacy" | "help" | "about" | "history";
export type Overlay = { kind: "tool"; id: ToolId } | { kind: "doc"; id: DocId };

export type NavApi = {
  tab: TabId;
  overlay: Overlay | null;
  setTab: (tab: TabId) => void;
  openTool: (id: ToolId) => void;
  openDoc: (id: DocId) => void;
  back: () => void;
};

const NavContext = createContext<NavApi | null>(null);

export function NavProvider({ value, children }: { value: NavApi; children: ReactNode }) {
  return <NavContext.Provider value={value}>{children}</NavContext.Provider>;
}

export function useNav() {
  const nav = useContext(NavContext);
  if (!nav) throw new Error("Navigasi belum siap.");
  return nav;
}
