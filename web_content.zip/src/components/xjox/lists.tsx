import { ChevronRight, Star } from "lucide-react";
import { CATEGORIES, getTool, searchTools, TOOLS, type CategoryId, type Tool, type ToolId } from "@/lib/xjox/catalog";
import { usePrefs } from "@/lib/xjox/store";
import { ToolIcon } from "./icons";
import { useNav } from "./nav";
import { Button, EmptyState, IconButton, SearchField } from "./ui";
import { useMemo, useState } from "react";

export function ToolRow({ tool }: { tool: Tool }) {
  const openTool = useNav().openTool;
  const favorite = usePrefs((state) => state.favorites.includes(tool.id));
  const toggleFavorite = usePrefs((state) => state.toggleFavorite);
  return (
    <div className="flex items-center gap-1 rounded-card border border-line bg-card pr-1">
      <button type="button" onClick={() => openTool(tool.id)} className="flex min-h-16 min-w-0 flex-1 items-center gap-3 px-3 py-2 text-left">
        <span className="grid size-11 shrink-0 place-items-center rounded-control bg-sunken text-ink">
          <ToolIcon name={tool.icon} className="size-5" />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate font-semibold">{tool.name}</span>
          <span className="block truncate text-sm text-mute">{tool.blurb}</span>
        </span>
        <ChevronRight className="size-4 shrink-0 text-mute" aria-hidden="true" />
      </button>
      <IconButton label={favorite ? `Hapus ${tool.name} dari favorit` : `Jadikan ${tool.name} favorit`} pressed={favorite} onClick={() => toggleFavorite(tool.id)}>
        <Star className={favorite ? "fill-accent text-accent" : "text-mute"} />
      </IconButton>
    </div>
  );
}

export function ToolList({ tools, emptyTitle, emptyBody }: { tools: Tool[]; emptyTitle: string; emptyBody: string }) {
  if (tools.length === 0) return <EmptyState title={emptyTitle} body={emptyBody} />;
  return (
    <ul className="space-y-2">
      {tools.map((tool) => (
        <li key={tool.id}>
          <ToolRow tool={tool} />
        </li>
      ))}
    </ul>
  );
}

export function ToolsTab() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<CategoryId | "all">("all");
  const tools = useMemo(() => searchTools(query, category), [query, category]);
  const grouped = !query.trim() && category === "all";
  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-4 px-4 pt-4 pb-8">
      <header>
        <h1 className="text-2xl font-extrabold tracking-tight">Alat</h1>
        <p className="text-sm text-mute">{TOOLS.length} alat, semuanya berjalan di perangkat ini.</p>
      </header>
      <SearchField value={query} onChange={setQuery} />
      <div className="flex gap-2 overflow-x-auto pb-1">
        <Chip active={category === "all"} onClick={() => setCategory("all")}>
          Semua
        </Chip>
        {CATEGORIES.map((item) => (
          <Chip key={item.id} active={category === item.id} onClick={() => setCategory(item.id)}>
            {item.name}
          </Chip>
        ))}
      </div>
      {grouped ? (
        CATEGORIES.map((item) => (
          <section key={item.id} className="space-y-2">
            <h2 className="text-sm font-bold">{item.name}</h2>
            <ToolList tools={TOOLS.filter((tool) => tool.category === item.id)} emptyTitle="" emptyBody="" />
          </section>
        ))
      ) : (
        <ToolList tools={tools} emptyTitle="Tidak ada alat" emptyBody={`Tidak ada yang cocok dengan “${query.trim() || "filter ini"}”.`} />
      )}
    </div>
  );
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`h-11 shrink-0 rounded-full px-4 text-sm font-semibold ${active ? "bg-accent text-accent-ink" : "border border-line bg-card text-ink"}`}
    >
      {children}
    </button>
  );
}

export function FavoritesTab() {
  const favorites = usePrefs((state) => state.favorites);
  const setTab = useNav().setTab;
  const tools = favorites.map((id) => getTool(id)).filter((tool): tool is Tool => Boolean(tool));
  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-4 px-4 pt-4 pb-8">
      <header>
        <h1 className="text-2xl font-extrabold tracking-tight">Favorit</h1>
        <p className="text-sm text-mute">Alat yang Anda sematkan.</p>
      </header>
      {tools.length === 0 ? (
        <EmptyState title="Belum ada favorit" body="Bintang pada sebuah alat supaya muncul di sini dan di beranda." action={<Button onClick={() => setTab("tools")}>Lihat alat</Button>} />
      ) : (
        <ToolList tools={tools} emptyTitle="" emptyBody="" />
      )}
    </div>
  );
}

export function idsToTools(ids: ToolId[]) {
  return ids.map((id) => getTool(id)).filter((tool): tool is Tool => Boolean(tool));
}
