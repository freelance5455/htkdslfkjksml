import { Download } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { inspectUrl } from "@/lib/xjox/url";
import { copyText, shareText } from "../clipboard";
import { ActionRow, Button, Card, Field, Notice, TextArea, TextInput, useToast } from "../ui";

function cssColor(name: string, fallback: string) {
  const value = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return value || fallback;
}

export function QrMake() {
  const toast = useToast();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [text, setText] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const report = text.trim() ? inspectUrl(text) : null;

  useEffect(() => {
    const canvas = canvasRef.current;
    const value = text.trim();
    if (!canvas) return;
    if (!value) {
      setReady(false);
      setError(null);
      const ctx = canvas.getContext("2d");
      ctx?.clearRect(0, 0, canvas.width, canvas.height);
      return;
    }
    if (value.length > 800) {
      setReady(false);
      setError("Teks terlalu panjang untuk satu QR. Maksimum 800 karakter.");
      return;
    }
    let cancel = false;
    setError(null);
    void (async () => {
      try {
        const mod = (await import("qrcode")) as {
          toCanvas?: (canvas: HTMLCanvasElement, text: string, options?: object) => Promise<void>;
          default?: { toCanvas?: (canvas: HTMLCanvasElement, text: string, options?: object) => Promise<void> };
        };
        const toCanvas = mod.toCanvas ?? mod.default?.toCanvas;
        if (!toCanvas) throw new Error("Pembuat QR tidak tersedia.");
        await toCanvas(canvas, value, {
          margin: 1,
          width: 280,
          errorCorrectionLevel: "M",
          color: { dark: cssColor("--color-ink", "#1a1916"), light: cssColor("--color-card", "#fffcf8") },
        });
        if (!cancel) setReady(true);
      } catch {
        if (!cancel) {
          setReady(false);
          setError("QR tidak bisa dibuat dari teks ini.");
        }
      }
    })();
    return () => {
      cancel = true;
    };
  }, [text]);

  async function pngBlob() {
    const canvas = canvasRef.current;
    if (!canvas || !ready) return null;
    return new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/png"));
  }

  return (
    <>
      <Field label="Teks atau URL" error={error}>
        <TextArea value={text} onChange={(event) => setText(event.target.value)} placeholder="https:// atau teks apa pun" className="min-h-24" />
      </Field>
      <Card className="grid place-items-center">
        <canvas ref={canvasRef} width={280} height={280} className={`max-w-full ${ready ? "" : "hidden"}`} aria-label="Kode QR" />
        {!ready ? <p className="py-16 text-sm text-mute">{error ? "QR tidak ditampilkan." : "QR muncul setelah ada teks."}</p> : null}
      </Card>
      <Notice>Tautan di dalam QR tidak dibuka otomatis.</Notice>
      {report?.ok ? (
        <Card className="space-y-3">
          <p className="text-sm">
            Terdeteksi tautan {report.secure ? "aman" : "http"} ke <span className="font-semibold">{report.host}</span>.
          </p>
          {report.warnings.map((warning) => (
            <Notice key={warning}>{warning}</Notice>
          ))}
          <a href={report.href} target="_blank" rel="noopener noreferrer" className="inline-flex h-12 items-center justify-center rounded-control bg-sunken px-4 text-sm font-semibold">
            Buka tautan
          </a>
        </Card>
      ) : null}
      <ActionRow text={text.trim()} title="Teks QR" />
      <div className="grid grid-cols-2 gap-2">
        <Button
          variant="secondary"
          disabled={!ready}
          onClick={() => {
            void (async () => {
              const blob = await pngBlob();
              if (!blob) return toast("Gambar QR belum siap.");
              try {
                if (navigator.clipboard && "write" in navigator.clipboard && typeof ClipboardItem !== "undefined") {
                  await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
                  toast("Gambar disalin.");
                  return;
                }
              } catch {
                /* fall through */
              }
              const copied = await copyText(text.trim());
              toast(copied ? "Gambar tidak bisa disalin. Teksnya disalin." : "Gagal menyalin gambar.");
            })();
          }}
        >
          Salin gambar
        </Button>
        <Button
          variant="secondary"
          disabled={!ready}
          onClick={() => {
            void (async () => {
              const blob = await pngBlob();
              if (!blob) return toast("Gambar QR belum siap.");
              const url = URL.createObjectURL(blob);
              const link = document.createElement("a");
              link.href = url;
              link.download = "xjox-qr.png";
              link.click();
              URL.revokeObjectURL(url);
              toast("Gambar diunduh. Pilih folder lewat dialog unduhan bila muncul.");
            })();
          }}
        >
          <Download /> Simpan PNG
        </Button>
      </div>
      <Button
        variant="secondary"
        disabled={!ready}
        onClick={() => {
          void (async () => {
            const blob = await pngBlob();
            if (!blob) return;
            const file = new File([blob], "xjox-qr.png", { type: "image/png" });
            if (navigator.share && navigator.canShare?.({ files: [file] })) {
              try {
                await navigator.share({ files: [file], title: "QR XJOX", text: text.trim() });
                toast("Dibagikan.");
                return;
              } catch (error) {
                if (error instanceof DOMException && error.name === "AbortError") return;
              }
            }
            const result = await shareText("QR XJOX", text.trim());
            if (result === "shared") toast("Dibagikan.");
            else if (result === "copied") toast("Berbagi gambar tidak tersedia. Teks disalin.");
            else if (result === "failed") toast("Gagal membagikan.");
          })();
        }}
      >
        Bagikan gambar
      </Button>
    </>
  );
}

export function QrScan() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [phase, setPhase] = useState<"idle" | "starting" | "scanning">("idle");
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState("");
  const streamRef = useRef<MediaStream | null>(null);
  const alive = useRef(false);

  function stop() {
    alive.current = false;
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    setPhase("idle");
  }

  useEffect(() => () => stop(), []);

  async function start() {
    setError(null);
    setResult("");
    setPhase("starting");
    if (!navigator.mediaDevices?.getUserMedia) {
      setPhase("idle");
      setError("Browser ini tidak bisa membuka kamera.");
      return;
    }
    const attempts: MediaStreamConstraints[] = [{ video: { facingMode: "environment" } }, { video: true }];
    let stream: MediaStream | null = null;
    let last: unknown;
    for (const constraints of attempts) {
      try {
        stream = await navigator.mediaDevices.getUserMedia(constraints);
        break;
      } catch (cause) {
        last = cause;
        if (cause instanceof DOMException && (cause.name === "NotAllowedError" || cause.name === "PermissionDeniedError")) break;
      }
    }
    if (!stream || !videoRef.current) {
      setPhase("idle");
      if (last instanceof DOMException && (last.name === "NotAllowedError" || last.name === "PermissionDeniedError")) {
        setError("Izin kamera ditolak. Izinkan kamera di browser, lalu coba lagi. Tidak ada gambar yang dikirim ke server.");
      } else if (last instanceof DOMException && last.name === "NotFoundError") {
        setError("Kamera tidak ditemukan.");
      } else {
        setError("Kamera tidak bisa dibuka.");
      }
      return;
    }
    streamRef.current = stream;
    videoRef.current.srcObject = stream;
    await videoRef.current.play();
    setPhase("scanning");
    const { default: jsQR } = await import("jsqr");
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    alive.current = true;
    const tick = () => {
      if (!alive.current || !videoRef.current || !ctx) return;
      const video = videoRef.current;
      if (video.readyState >= 2 && video.videoWidth > 0) {
        const scale = Math.min(1, 640 / video.videoWidth);
        const width = Math.max(1, Math.floor(video.videoWidth * scale));
        const height = Math.max(1, Math.floor(video.videoHeight * scale));
        canvas.width = width;
        canvas.height = height;
        ctx.drawImage(video, 0, 0, width, height);
        const image = ctx.getImageData(0, 0, width, height);
        const code = jsQR(image.data, width, height, { inversionAttempts: "attemptBoth" });
        if (code?.data) {
          setResult(code.data);
          stop();
          return;
        }
      }
      window.setTimeout(tick, 150);
    };
    tick();
  }

  const report = result ? inspectUrl(result) : null;
  return (
    <>
      <Notice>Kamera hanya menyala setelah Anda menekan tombol. Gambar tidak dikirim ke mana pun.</Notice>
      <div className="overflow-hidden rounded-card border border-line bg-sunken">
        <video ref={videoRef} className={`aspect-[3/4] w-full object-cover ${phase === "scanning" ? "" : "hidden"}`} playsInline muted />
        {phase !== "scanning" ? (
          <div className="grid aspect-[3/4] place-items-center px-6 text-center text-sm text-mute">
            {phase === "starting" ? "Menyalakan kamera…" : "Pratinjau kamera muncul di sini."}
          </div>
        ) : null}
      </div>
      {error ? <Notice tone="danger">{error}</Notice> : null}
      <div className="grid grid-cols-2 gap-2">
        <Button onClick={() => void start()} disabled={phase !== "idle"}>
          {phase === "starting" ? "Menyiapkan…" : "Pindai"}
        </Button>
        <Button variant="secondary" onClick={stop} disabled={phase === "idle"}>
          Berhenti
        </Button>
      </div>
      <Card>
        <p className="text-xs font-medium text-mute">Hasil</p>
        <p className="mt-1 font-mono text-sm break-all">{result || "Belum ada kode."}</p>
      </Card>
      {report?.ok ? (
        <Card className="space-y-2">
          <p className="text-sm">Tautan ke {report.host}. Tidak dibuka otomatis.</p>
          {report.warnings.map((warning) => (
            <Notice key={warning}>{warning}</Notice>
          ))}
          <a href={report.href} target="_blank" rel="noopener noreferrer" className="inline-flex h-12 items-center justify-center rounded-control bg-accent px-4 text-sm font-semibold text-accent-ink">
            Buka tautan
          </a>
        </Card>
      ) : null}
      <ActionRow text={result} title="Hasil pindai QR" />
    </>
  );
}

export function UrlCheck() {
  const [raw, setRaw] = useState("");
  const report = raw.trim() ? inspectUrl(raw) : null;
  return (
    <>
      <Field label="URL" error={report && !report.ok ? report.error : null}>
        <TextInput value={raw} onChange={(event) => setRaw(event.target.value)} placeholder="https://contoh.id" inputMode="url" autoCapitalize="none" autoCorrect="off" />
      </Field>
      {!raw.trim() ? <Notice>Tempel tautan untuk diperiksa. Tidak ada yang dibuka sebelum Anda menekan tombol.</Notice> : null}
      {report?.ok ? (
        <Card className="space-y-3">
          <p className="text-sm font-semibold">{report.secure ? "HTTPS" : "HTTP"} · {report.host}</p>
          <p className="font-mono text-sm break-all text-mute">{report.href}</p>
          {report.warnings.length === 0 ? <Notice>Tidak ada peringatan dasar.</Notice> : report.warnings.map((warning) => <Notice key={warning}>{warning}</Notice>)}
          <a href={report.href} target="_blank" rel="noopener noreferrer" className="inline-flex h-12 items-center justify-center rounded-control bg-accent px-4 text-sm font-semibold text-accent-ink">
            Buka tautan
          </a>
        </Card>
      ) : null}
      <ActionRow text={report?.ok ? report.href : ""} title="URL" />
    </>
  );
}
