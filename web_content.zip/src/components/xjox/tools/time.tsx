import { create } from "zustand";
import { useEffect, useState } from "react";
import { countdownTo, diffDates } from "@/lib/xjox/dates";
import { formatClock, formatDurationHms } from "@/lib/xjox/format";
import { useTimer } from "@/lib/xjox/store";
import { Button, Card, Field, Notice, TextInput } from "../ui";

function zoneName(date: Date) {
  const zone = Intl.DateTimeFormat().resolvedOptions().timeZone || "lokal";
  const offsetMin = -date.getTimezoneOffset();
  const sign = offsetMin >= 0 ? "+" : "−";
  const abs = Math.abs(offsetMin);
  const hh = String(Math.floor(abs / 60)).padStart(2, "0");
  const mm = String(abs % 60).padStart(2, "0");
  return `${zone} (UTC${sign}${hh}:${mm})`;
}

export function TimeClock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 250);
    return () => window.clearInterval(id);
  }, []);
  return (
    <Card className="py-8 text-center">
      <p className="font-mono text-5xl font-medium tabular-nums">
        {now.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23" })}
      </p>
      <p className="mt-3 text-base font-semibold capitalize">
        {now.toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
      </p>
      <p className="mt-2 text-sm text-mute">{zoneName(now)}</p>
    </Card>
  );
}

type StopState = {
  running: boolean;
  startedAt: number;
  accumulated: number;
  laps: number[];
  start: () => void;
  pause: () => void;
  reset: () => void;
  lap: () => void;
  elapsed: () => number;
};

const useStopwatch = create<StopState>((set, get) => ({
  running: false,
  startedAt: 0,
  accumulated: 0,
  laps: [],
  start: () => {
    if (get().running) return;
    set({ running: true, startedAt: performance.now() });
  },
  pause: () => {
    const state = get();
    if (!state.running) return;
    set({ running: false, accumulated: state.accumulated + performance.now() - state.startedAt });
  },
  reset: () => set({ running: false, accumulated: 0, startedAt: 0, laps: [] }),
  lap: () => {
    const elapsed = get().elapsed();
    set({ laps: [elapsed, ...get().laps].slice(0, 40) });
  },
  elapsed: () => {
    const state = get();
    return state.running ? state.accumulated + performance.now() - state.startedAt : state.accumulated;
  },
}));

export function TimeStopwatch() {
  const running = useStopwatch((state) => state.running);
  const laps = useStopwatch((state) => state.laps);
  const start = useStopwatch((state) => state.start);
  const pause = useStopwatch((state) => state.pause);
  const reset = useStopwatch((state) => state.reset);
  const lap = useStopwatch((state) => state.lap);
  const [elapsed, setElapsed] = useState(0);
  useEffect(() => {
    let frame = 0;
    const tick = () => {
      setElapsed(useStopwatch.getState().elapsed());
      frame = window.requestAnimationFrame(tick);
    };
    frame = window.requestAnimationFrame(tick);
    return () => window.cancelAnimationFrame(frame);
  }, []);
  return (
    <>
      <Card className="py-8 text-center">
        <p className="font-mono text-5xl font-medium tabular-nums">{formatClock(elapsed)}</p>
      </Card>
      <div className="grid grid-cols-3 gap-2">
        <Button variant="secondary" onClick={reset}>
          Atur ulang
        </Button>
        <Button variant="secondary" onClick={lap} disabled={elapsed === 0}>
          Putaran
        </Button>
        <Button onClick={running ? pause : start}>{running ? "Jeda" : "Mulai"}</Button>
      </div>
      {laps.length === 0 ? (
        <Notice>Putaran muncul di sini. Stopwatch tetap jalan saat Anda pindah alat.</Notice>
      ) : (
        <ol className="space-y-2">
          {laps.map((value, index) => (
            <li key={`${value}-${index}`} className="flex justify-between rounded-control bg-card px-3 py-3 font-mono text-sm tabular-nums">
              <span className="text-mute">Putaran {laps.length - index}</span>
              <span>{formatClock(value)}</span>
            </li>
          ))}
        </ol>
      )}
    </>
  );
}

let audioCtx: AudioContext | null = null;

function primeAudio() {
  const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return;
  if (!audioCtx) audioCtx = new Ctx();
  if (audioCtx.state === "suspended") void audioCtx.resume();
}

export function ringTimer() {
  if (!audioCtx) return;
  const now = audioCtx.currentTime;
  for (let i = 0; i < 3; i += 1) {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = "sine";
    osc.frequency.value = 880;
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    const start = now + i * 0.42;
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.exponentialRampToValueAtTime(0.12, start + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.32);
    osc.start(start);
    osc.stop(start + 0.34);
  }
}

export function TimeTimer() {
  const [hours, setHours] = useState("0");
  const [minutes, setMinutes] = useState("1");
  const [seconds, setSeconds] = useState("0");
  const [error, setError] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);
  const [left, setLeft] = useState(0);
  const running = useTimer((state) => state.running);
  const endAt = useTimer((state) => state.endAt);
  const totalMs = useTimer((state) => state.totalMs);
  const fired = useTimer((state) => state.fired);
  const start = useTimer((state) => state.start);
  const stop = useTimer((state) => state.stop);

  useEffect(() => {
    const id = window.setInterval(() => {
      const state = useTimer.getState();
      if (state.running && state.endAt) setLeft(Math.max(0, state.endAt - Date.now()));
      else if (state.fired) setLeft(0);
    }, 200);
    return () => window.clearInterval(id);
  }, []);

  const progress = totalMs > 0 ? Math.max(0, Math.min(100, (left / totalMs) * 100)) : 0;
  return (
    <>
      <Card className="py-8 text-center">
        <p className="font-mono text-5xl font-medium tabular-nums">{formatDurationHms(left / 1000)}</p>
        <div className="mx-auto mt-4 h-2 max-w-xs overflow-hidden rounded-full bg-sunken">
          <div className="h-full bg-accent" style={{ width: `${running || fired ? progress : 0}%` }} />
        </div>
        {fired ? <p className="mt-3 text-sm font-semibold text-accent">Waktu habis.</p> : null}
      </Card>
      <div className="grid grid-cols-3 gap-2">
        <Field label="Jam">
          <TextInput inputMode="numeric" value={hours} onChange={(event) => setHours(event.target.value)} disabled={running} />
        </Field>
        <Field label="Menit">
          <TextInput inputMode="numeric" value={minutes} onChange={(event) => setMinutes(event.target.value)} disabled={running} />
        </Field>
        <Field label="Detik">
          <TextInput inputMode="numeric" value={seconds} onChange={(event) => setSeconds(event.target.value)} disabled={running} />
        </Field>
      </div>
      {error ? <Notice tone="danger">{error}</Notice> : null}
      {note ? <Notice>{note}</Notice> : <Notice>Alarm berbunyi di aplikasi. Notifikasi hanya jika izin diberikan. Menutup tab menghentikan timer.</Notice>}
      <div className="grid grid-cols-2 gap-2">
        <Button variant="secondary" onClick={stop}>
          Berhenti
        </Button>
        <Button
          disabled={running}
          onClick={() => {
            const h = Number(hours);
            const m = Number(minutes);
            const s = Number(seconds);
            if (![h, m, s].every((n) => Number.isInteger(n) && n >= 0)) {
              setError("Isi jam, menit, dan detik dengan bilangan bulat.");
              return;
            }
            if (h > 48 || m > 59 || s > 59) {
              setError("Maksimum 48 jam, dan menit serta detik di bawah 60.");
              return;
            }
            const total = (h * 3600 + m * 60 + s) * 1000;
            if (total <= 0) {
              setError("Durasi harus lebih dari nol.");
              return;
            }
            setError(null);
            primeAudio();
            if (typeof Notification !== "undefined" && Notification.permission === "default") {
              void Notification.requestPermission().then((permission) => {
                setNote(permission === "granted" ? "Notifikasi diizinkan." : "Notifikasi ditolak. Alarm tetap berbunyi di dalam aplikasi.");
              });
            } else if (typeof Notification !== "undefined" && Notification.permission === "denied") {
              setNote("Notifikasi diblokir browser. Alarm tetap berbunyi di dalam aplikasi selama tab terbuka.");
            } else if (typeof Notification === "undefined") {
              setNote("Browser ini tidak punya notifikasi. Alarm tetap berbunyi di dalam aplikasi.");
            }
            start(total);
            setLeft(total);
          }}
        >
          Mulai
        </Button>
      </div>
      {endAt && running ? <Notice>Selesai sekitar {new Date(endAt).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })}.</Notice> : null}
    </>
  );
}

export function TimeDiff() {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const result = from && to ? diffDates(from, to) : null;
  return (
    <>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Tanggal awal">
          <TextInput type="date" value={from} onChange={(event) => setFrom(event.target.value)} />
        </Field>
        <Field label="Tanggal akhir">
          <TextInput type="date" value={to} onChange={(event) => setTo(event.target.value)} />
        </Field>
      </div>
      {!from || !to ? <Notice>Pilih kedua tanggal. Perhitungan memakai tanggal kalender, bukan jam.</Notice> : null}
      {result && !result.ok ? <Notice tone="danger">{result.error}</Notice> : null}
      {result?.ok ? (
        <Card className="space-y-2">
          <p className="text-sm text-mute">{result.days === 0 ? "Kedua tanggal sama." : result.days > 0 ? "Tanggal akhir lebih kemudian." : "Tanggal akhir lebih dahulu."}</p>
          <p className="font-mono text-4xl font-medium tabular-nums">{result.absDays.toLocaleString("id-ID")}</p>
          <p className="text-sm font-semibold">hari kalender</p>
          <p className="text-sm text-mute">
            {result.years} tahun, {result.months} bulan, {result.daysPart} hari
            {result.absDays >= 7 ? ` · ${(result.absDays / 7).toLocaleString("id-ID", { maximumFractionDigits: 2 })} minggu` : ""}
          </p>
        </Card>
      ) : null}
    </>
  );
}

export function TimeUntil() {
  const [date, setDate] = useState("");
  const [time, setTime] = useState("00:00");
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 250);
    return () => window.clearInterval(id);
  }, []);
  const result = date ? countdownTo(date, time, now) : null;
  return (
    <>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Tanggal">
          <TextInput type="date" value={date} onChange={(event) => setDate(event.target.value)} />
        </Field>
        <Field label="Jam">
          <TextInput type="time" value={time} onChange={(event) => setTime(event.target.value)} />
        </Field>
      </div>
      <Notice>Zona waktu perangkat: {zoneName(now)}. Tautan atau tanggal tidak dibuka otomatis.</Notice>
      {!date ? <Notice>Pilih tanggal tujuan.</Notice> : null}
      {result && !result.ok ? <Notice tone="danger">{result.error}</Notice> : null}
      {result?.ok ? (
        <Card>
          <p className="text-sm font-semibold">{result.past ? "Waktu itu sudah lewat" : "Sisa waktu"}</p>
          <div className="mt-3 grid grid-cols-4 gap-2 text-center">
            {[
              ["Hari", result.days],
              ["Jam", result.hours],
              ["Menit", result.minutes],
              ["Detik", result.seconds],
            ].map(([label, value]) => (
              <div key={String(label)}>
                <div className="font-mono text-2xl font-medium tabular-nums">{Number(value).toLocaleString("id-ID")}</div>
                <div className="text-xs text-mute">{label}</div>
              </div>
            ))}
          </div>
        </Card>
      ) : null}
    </>
  );
}
