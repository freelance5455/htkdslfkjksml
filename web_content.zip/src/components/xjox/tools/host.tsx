import { ChevronLeft, Star } from "lucide-react";
import type { ReactNode } from "react";
import { getTool, type ToolId } from "@/lib/xjox/catalog";
import { usePrefs } from "@/lib/xjox/store";
import { useNav } from "../nav";
import { IconButton } from "../ui";
import { CalcBasic, CalcLength, CalcPercent, CalcStorage, CalcTemp, CalcVolume, CalcWeight } from "./calc";
import { QrMake, QrScan, UrlCheck } from "./code";
import { FileInfo } from "./files";
import { GenColor, GenLorem, GenNumber, GenPassword, GenUuid } from "./generate";
import { TextBlank, TextCase, TextCount, TextDedupe, TextReverse, TextShuffle, TextSpace } from "./text";
import { TimeClock, TimeDiff, TimeStopwatch, TimeTimer, TimeUntil } from "./time";

export function ToolFrame({ id, children }: { id: ToolId; children: ReactNode }) {
  const tool = getTool(id);
  const nav = useNav();
  const favorite = usePrefs((state) => state.favorites.includes(id));
  const toggleFavorite = usePrefs((state) => state.toggleFavorite);
  if (!tool) return null;
  return (
    <div className="rise mx-auto flex w-full max-w-3xl flex-col gap-4 px-4 pt-2 pb-8">
      <header className="flex items-center gap-1">
        <IconButton label="Kembali" onClick={nav.back}>
          <ChevronLeft />
        </IconButton>
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-xl font-extrabold tracking-tight">{tool.name}</h1>
          <p className="truncate text-sm text-mute">{tool.blurb}</p>
        </div>
        <IconButton label={favorite ? "Hapus dari favorit" : "Jadikan favorit"} pressed={favorite} onClick={() => toggleFavorite(id)}>
          <Star className={favorite ? "fill-accent text-accent" : "text-mute"} />
        </IconButton>
      </header>
      {children}
    </div>
  );
}

export function ToolScreen({ id }: { id: ToolId }) {
  const body = screenFor(id);
  return <ToolFrame id={id}>{body}</ToolFrame>;
}

function screenFor(id: ToolId): ReactNode {
  switch (id) {
    case "text-count":
      return <TextCount />;
    case "text-case":
      return <TextCase />;
    case "text-space":
      return <TextSpace />;
    case "text-blank":
      return <TextBlank />;
    case "text-shuffle":
      return <TextShuffle />;
    case "text-reverse":
      return <TextReverse />;
    case "text-dedupe":
      return <TextDedupe />;
    case "gen-uuid":
      return <GenUuid />;
    case "gen-password":
      return <GenPassword />;
    case "gen-number":
      return <GenNumber />;
    case "gen-color":
      return <GenColor />;
    case "gen-lorem":
      return <GenLorem />;
    case "calc-basic":
      return <CalcBasic />;
    case "calc-length":
      return <CalcLength />;
    case "calc-weight":
      return <CalcWeight />;
    case "calc-temp":
      return <CalcTemp />;
    case "calc-volume":
      return <CalcVolume />;
    case "calc-storage":
      return <CalcStorage />;
    case "calc-percent":
      return <CalcPercent />;
    case "time-clock":
      return <TimeClock />;
    case "time-stopwatch":
      return <TimeStopwatch />;
    case "time-timer":
      return <TimeTimer />;
    case "time-diff":
      return <TimeDiff />;
    case "time-until":
      return <TimeUntil />;
    case "qr-make":
      return <QrMake />;
    case "qr-scan":
      return <QrScan />;
    case "url-check":
      return <UrlCheck />;
    case "file-info":
      return <FileInfo />;
  }
}
