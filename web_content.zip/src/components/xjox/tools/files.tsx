import { useState } from "react";
import { formatBytes, formatWhen } from "@/lib/xjox/format";
import { recallFile, rememberFile, usePrefs } from "@/lib/xjox/store";
import { copyText } from "../clipboard";
import { Button, Card, ConfirmButton, EmptyState, Notice, useToast } from "../ui";

const PREVIEW_LIMIT = 200_000;

function looksText(file: File) {
  if (file.type.startsWith("text/")) return true;
  if (file.type === "application/json" || file.type === "application/xml" || file.type === "image/svg+xml") return true;
  return /\.(txt|md|csv|json|xml|svg|log|css|html)$/i.test(file.name);
}

function describe(file: { name: string; size: number; type: string; lastModified: number }) {
  return [
    `Nama: ${file.name}`,
    `Ukuran: ${formatBytes(file.size)} (${file.size.toLocaleString("id-ID")} byte)`,
    `Jenis: ${file.type || "tidak diketahui"}`,
    `Diubah: ${new Date(file.lastModified).toLocaleString("id-ID")}`,
  ].join("\n");
}

export function FileInfo() {
  const toast = useToast();
  const recent = usePrefs((state) => state.recentFiles);
  const addRecentFile = usePrefs((state) => state.addRecentFile);
  const clearRecentFiles = usePrefs((state) => state.clearRecentFiles);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [reading, setReading] = useState(false);
  const active = activeId ? recallFile(activeId) : undefined;

  function take(file: File) {
    const id = crypto.randomUUID();
    rememberFile(id, file);
    addRecentFile({
      id,
      name: file.name,
      size: file.size,
      type: file.type,
      lastModified: file.lastModified,
      openedAt: Date.now(),
    });
    setActiveId(id);
    setPreview(null);
    setError(null);
  }

  return (
    <>
      <Notice>Berkas tidak diunggah. Daftar terbaru hanya menyimpan nama, jenis, dan ukuran di perangkat ini.</Notice>
      <label className="flex h-12 cursor-pointer items-center justify-center rounded-control bg-accent px-4 text-sm font-semibold text-accent-ink">
        Pilih berkas
        <input
          type="file"
          className="sr-only"
          onChange={(event) => {
            const file = event.target.files?.[0];
            event.target.value = "";
            if (file) take(file);
          }}
        />
      </label>
      {active ? (
        <Card className="space-y-2">
          <h2 className="text-base font-bold break-all">{active.name}</h2>
          <p className="text-sm text-mute">Ukuran {formatBytes(active.size)} · {active.size.toLocaleString("id-ID")} byte</p>
          <p className="text-sm text-mute">Jenis {active.type || "tidak diketahui"}</p>
          <p className="text-sm text-mute">Diubah {new Date(active.lastModified).toLocaleString("id-ID")}</p>
          <div className="grid grid-cols-2 gap-2 pt-2">
            <Button
              variant="secondary"
              onClick={() => {
                void copyText(describe(active)).then((ok) => toast(ok ? "Info disalin." : "Gagal menyalin."));
              }}
            >
              Salin info
            </Button>
            <Button
              variant="secondary"
              onClick={() => {
                void (async () => {
                  if (navigator.share && navigator.canShare?.({ files: [active] })) {
                    try {
                      await navigator.share({ files: [active], title: active.name });
                      toast("Berkas dibagikan.");
                      return;
                    } catch (cause) {
                      if (cause instanceof DOMException && cause.name === "AbortError") return;
                    }
                  }
                  toast("Browser ini tidak mendukung berbagi berkas.");
                })();
              }}
            >
              Bagikan
            </Button>
          </div>
          <Button
            variant="ghost"
            disabled={reading}
            onClick={() => {
              if (!looksText(active)) {
                setPreview(null);
                setError("Cuplikan hanya untuk berkas teks.");
                return;
              }
              if (active.size > PREVIEW_LIMIT) {
                setPreview(null);
                setError("Cuplikan hanya untuk berkas di bawah 200 KB.");
                return;
              }
              setReading(true);
              setError(null);
              void active
                .text()
                .then((value) => setPreview(value))
                .catch(() => setError("Isi berkas tidak bisa dibaca."))
                .finally(() => setReading(false));
            }}
          >
            {reading ? "Membaca…" : "Tampilkan cuplikan teks"}
          </Button>
          {error ? <Notice tone="danger">{error}</Notice> : null}
          {preview !== null ? <pre className="max-h-60 overflow-auto whitespace-pre-wrap break-words rounded-control bg-sunken p-3 font-mono text-xs">{preview}</pre> : null}
        </Card>
      ) : (
        <EmptyState title="Belum ada berkas" body="Pilih berkas lewat pemilih sistem. Isinya tidak diubah dan tidak dihapus." />
      )}
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-bold">Baru dibuka</h2>
        {recent.length > 0 ? (
          <ConfirmButton
            title="Hapus daftar berkas?"
            body="Hanya daftar nama di aplikasi yang dihapus. Berkas asli tidak tersentuh."
            confirmLabel="Hapus"
            onConfirm={() => {
              clearRecentFiles();
              setActiveId(null);
              setPreview(null);
            }}
          >
            <Button variant="ghost" className="h-11 px-3">
              Hapus daftar
            </Button>
          </ConfirmButton>
        ) : null}
      </div>
      {recent.length === 0 ? (
        <Notice>Daftar masih kosong.</Notice>
      ) : (
        <ul className="space-y-2">
          {recent.map((item) => {
            const file = recallFile(item.id);
            return (
              <li key={item.id} className="rounded-card border border-line bg-card px-3 py-3">
                <p className="font-semibold break-all">{item.name}</p>
                <p className="text-sm text-mute">
                  {formatBytes(item.size)} · {formatWhen(item.openedAt)}
                </p>
                <p className="mt-1 text-xs text-mute">{file ? "Masih bisa dibagikan pada sesi ini." : "Pilih ulang berkas jika ingin membagikannya lagi."}</p>
              </li>
            );
          })}
        </ul>
      )}
    </>
  );
}
