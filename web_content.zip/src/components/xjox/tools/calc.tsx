import { ArrowLeftRight, Delete } from "lucide-react";
import { useEffect, useState } from "react";
import {
  LENGTH_UNITS,
  STORAGE_UNITS,
  VOLUME_UNITS,
  WEIGHT_UNITS,
  convertStorage,
  convertTemp,
  convertUnit,
  type StorageBase,
  type StorageId,
  type TempUnit,
  type Unit,
} from "@/lib/xjox/convert";
import { formatNumber, prettifyExpr } from "@/lib/xjox/format";
import { applyCalcKey, evaluateMath, parseUserNumber, percentChange, percentOf, whatPercent, type CalcKey } from "@/lib/xjox/math";
import { usePrefs } from "@/lib/xjox/store";
import { Button, Card, ConfirmButton, Field, Notice, Segmented, SelectInput, TextInput } from "../ui";

const KEYS: { id: CalcKey; label: string; op?: boolean }[][] = [
  [
    { id: "clear", label: "C" },
    { id: "(", label: "(" },
    { id: ")", label: ")" },
    { id: "back", label: "⌫" },
  ],
  [
    { id: "7", label: "7" },
    { id: "8", label: "8" },
    { id: "9", label: "9" },
    { id: "/", label: "÷", op: true },
  ],
  [
    { id: "4", label: "4" },
    { id: "5", label: "5" },
    { id: "6", label: "6" },
    { id: "*", label: "×", op: true },
  ],
  [
    { id: "1", label: "1" },
    { id: "2", label: "2" },
    { id: "3", label: "3" },
    { id: "-", label: "−", op: true },
  ],
  [
    { id: "neg", label: "±" },
    { id: "0", label: "0" },
    { id: ".", label: "," },
    { id: "+", label: "+", op: true },
  ],
];

export function CalcBasic() {
  const [expr, setExpr] = useState("");
  const [just, setJust] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const addCalcHistory = usePrefs((state) => state.addCalcHistory);
  const history = usePrefs((state) => state.calcHistory);
  const clearCalcHistory = usePrefs((state) => state.clearCalcHistory);

  function press(key: CalcKey) {
    const next = applyCalcKey(expr, key, just);
    setExpr(next.expr);
    setJust(next.justEval);
    setError(next.error ?? null);
    if (next.history) {
      addCalcHistory({
        id: crypto.randomUUID(),
        expr: next.history.expr,
        result: formatNumber(next.history.value),
        at: Date.now(),
      });
    }
  }

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target;
      if (target instanceof HTMLElement && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable)) {
        return;
      }
      const map: Record<string, CalcKey | undefined> = {
        Enter: "eq",
        "=": "eq",
        Backspace: "back",
        Escape: "clear",
        ",": ".",
        ".": ".",
        "%": "%",
        "+": "+",
        "-": "-",
        "*": "*",
        "/": "/",
        x: "*",
        X: "*",
        "(": "(",
        ")": ")",
      };
      const key = /^[0-9]$/.test(event.key) ? (event.key as CalcKey) : map[event.key];
      if (!key) return;
      event.preventDefault();
      press(key);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const live = !just && expr ? evaluateMath(expr) : null;
  return (
    <>
      <Card>
        <p className="min-h-10 text-right font-mono text-3xl break-all tabular-nums">{expr ? prettifyExpr(expr) : "0"}</p>
        <p className="mt-2 min-h-6 text-right font-mono text-sm text-mute tabular-nums">{live?.ok ? `= ${formatNumber(live.value)}` : ""}</p>
        {error ? <p className="mt-2 text-right text-sm text-danger">{error}</p> : null}
      </Card>
      <div className="grid grid-cols-4 gap-2">
        {KEYS.flat().map((key) => (
          <button
            key={key.id}
            type="button"
            onClick={() => press(key.id)}
            className={`h-14 rounded-control text-lg font-semibold tabular-nums ${key.op ? "bg-sunken text-accent" : "bg-card text-ink border border-line"}`}
          >
            {key.id === "back" ? <Delete className="mx-auto size-5" aria-hidden="true" /> : key.label}
            {key.id === "back" ? <span className="sr-only">Hapus</span> : null}
          </button>
        ))}
      </div>
      <div className="grid grid-cols-4 gap-2">
        <button type="button" onClick={() => press("%")} className="h-14 rounded-control border border-line bg-card text-lg font-semibold text-accent">
          %
        </button>
        <button type="button" onClick={() => press("eq")} className="col-span-3 h-14 rounded-control bg-accent text-lg font-bold text-accent-ink">
          =
        </button>
      </div>
      <Notice>Tombol % membagi angka dengan 100. Untuk diskon atau kenaikan, pakai alat Persentase.</Notice>
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-sm font-bold">Riwayat</h2>
        {history.length > 0 ? (
          <ConfirmButton title="Hapus riwayat hitung?" body="Semua perhitungan tersimpan di perangkat ini akan dihapus." confirmLabel="Hapus" onConfirm={clearCalcHistory}>
            <Button variant="ghost" className="h-11 px-3">
              Hapus
            </Button>
          </ConfirmButton>
        ) : null}
      </div>
      {history.length === 0 ? (
        <Notice>Belum ada perhitungan.</Notice>
      ) : (
        <ul className="space-y-2">
          {history.map((item) => (
            <li key={item.id}>
              <button
                type="button"
                onClick={() => {
                  setExpr(item.expr);
                  setJust(false);
                  setError(null);
                }}
                className="w-full rounded-card border border-line bg-card px-3 py-3 text-left"
              >
                <span className="block truncate font-mono text-sm text-mute">{prettifyExpr(item.expr)}</span>
                <span className="block font-mono text-lg tabular-nums">{item.result}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

function UnitPanel({ units, note }: { units: Unit[]; note: string }) {
  const [raw, setRaw] = useState("1");
  const [from, setFrom] = useState(units[0]?.id ?? "");
  const [to, setTo] = useState(units[1]?.id ?? units[0]?.id ?? "");
  const parsed = parseUserNumber(raw);
  const rows = parsed.ok
    ? units.map((unit) => ({ unit, result: convertUnit(parsed.value, units, from, unit.id) }))
    : [];
  const chosen = rows.find((row) => row.unit.id === to);
  return (
    <>
      <Field label="Nilai" error={raw.trim() && !parsed.ok ? parsed.ok ? null : parsed.error : null}>
        <TextInput inputMode="decimal" value={raw} onChange={(event) => setRaw(event.target.value)} />
      </Field>
      <div className="grid grid-cols-[1fr_auto_1fr] items-end gap-2">
        <Field label="Dari">
          <SelectInput value={from} onChange={(event) => setFrom(event.target.value)}>
            {units.map((unit) => (
              <option key={unit.id} value={unit.id}>
                {unit.label}
              </option>
            ))}
          </SelectInput>
        </Field>
        <button
          type="button"
          aria-label="Tukar satuan"
          className="mb-0 grid size-12 place-items-center rounded-control bg-sunken"
          onClick={() => {
            setFrom(to);
            setTo(from);
          }}
        >
          <ArrowLeftRight className="size-5" />
        </button>
        <Field label="Ke">
          <SelectInput value={to} onChange={(event) => setTo(event.target.value)}>
            {units.map((unit) => (
              <option key={unit.id} value={unit.id}>
                {unit.label}
              </option>
            ))}
          </SelectInput>
        </Field>
      </div>
      <Card>
        <p className="text-xs font-medium text-mute">Hasil</p>
        <p className="font-mono text-3xl font-medium break-all tabular-nums">
          {chosen?.result.ok ? formatNumber(chosen.result.value) : "—"}
        </p>
        <p className="mt-1 text-sm text-mute">{units.find((unit) => unit.id === to)?.label}</p>
      </Card>
      <Notice>{note}</Notice>
      {parsed.ok ? (
        <ul className="space-y-1">
          {rows.map((row) => (
            <li key={row.unit.id} className="flex items-center justify-between gap-3 rounded-control px-1 py-2 text-sm">
              <span className="text-mute">{row.unit.label}</span>
              <span className="font-mono tabular-nums">{row.result.ok ? formatNumber(row.result.value) : "—"}</span>
            </li>
          ))}
        </ul>
      ) : null}
    </>
  );
}

export function CalcLength() {
  return <UnitPanel units={LENGTH_UNITS} note="Faktor tetap: 1 inci = 2,54 cm, 1 mil = 1.609,344 m." />;
}

export function CalcWeight() {
  return <UnitPanel units={WEIGHT_UNITS} note="Ons dan pon adalah avoirdupois (1 pon = 453,59237 g), bukan ons metrik." />;
}

export function CalcVolume() {
  return (
    <UnitPanel
      units={VOLUME_UNITS}
      note="Sendok, cangkir AS, ons cair, dan galon memakai ukuran Amerika Serikat. Cangkir metrik = 250 ml."
    />
  );
}

const TEMPS: { id: TempUnit; label: string }[] = [
  { id: "C", label: "Celsius" },
  { id: "F", label: "Fahrenheit" },
  { id: "K", label: "Kelvin" },
];

export function CalcTemp() {
  const [raw, setRaw] = useState("0");
  const [from, setFrom] = useState<TempUnit>("C");
  const [to, setTo] = useState<TempUnit>("F");
  const parsed = parseUserNumber(raw);
  const converted = parsed.ok ? convertTemp(parsed.value, from, to) : null;
  const rows = parsed.ok ? TEMPS.map((unit) => ({ unit, result: convertTemp(parsed.value, from, unit.id) })) : [];
  return (
    <>
      <Field label="Nilai" error={parsed.ok || !raw.trim() ? null : parsed.error}>
        <TextInput inputMode="decimal" value={raw} onChange={(event) => setRaw(event.target.value)} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Dari">
          <SelectInput value={from} onChange={(event) => setFrom(event.target.value as TempUnit)}>
            {TEMPS.map((unit) => (
              <option key={unit.id} value={unit.id}>
                {unit.label}
              </option>
            ))}
          </SelectInput>
        </Field>
        <Field label="Ke">
          <SelectInput value={to} onChange={(event) => setTo(event.target.value as TempUnit)}>
            {TEMPS.map((unit) => (
              <option key={unit.id} value={unit.id}>
                {unit.label}
              </option>
            ))}
          </SelectInput>
        </Field>
      </div>
      <Card>
        <p className="text-xs font-medium text-mute">Hasil</p>
        <p className="font-mono text-3xl font-medium tabular-nums">{converted?.ok ? formatNumber(converted.value) : "—"}</p>
        {converted && !converted.ok ? <p className="mt-2 text-sm text-danger">{converted.error}</p> : null}
      </Card>
      <Notice>Nol mutlak ditolak: 0 K, −273,15 °C, atau −459,67 °F.</Notice>
      <ul className="space-y-1">
        {rows.map((row) => (
          <li key={row.unit.id} className="flex justify-between gap-3 px-1 py-2 text-sm">
            <span className="text-mute">{row.unit.label}</span>
            <span className="font-mono tabular-nums">{row.result.ok ? formatNumber(row.result.value) : row.result.error}</span>
          </li>
        ))}
      </ul>
    </>
  );
}

export function CalcStorage() {
  const [raw, setRaw] = useState("1");
  const [base, setBase] = useState<StorageBase>(1024);
  const [from, setFrom] = useState<StorageId>("M");
  const [to, setTo] = useState<StorageId>("K");
  const parsed = parseUserNumber(raw);
  const label = (id: StorageId) => {
    const unit = STORAGE_UNITS.find((item) => item.id === id);
    return base === 1024 ? unit?.labelIec : unit?.labelSi;
  };
  const converted = parsed.ok ? convertStorage(parsed.value, from, to, base) : null;
  const rows = parsed.ok
    ? STORAGE_UNITS.map((unit) => ({ unit, result: convertStorage(parsed.value, from, unit.id, base) }))
    : [];
  return (
    <>
      <Segmented
        label="Dasar hitung"
        value={String(base)}
        onChange={(value) => setBase(value === "1000" ? 1000 : 1024)}
        options={[
          { id: "1024", label: "Biner 1024" },
          { id: "1000", label: "Desimal 1000" },
        ]}
      />
      <Field label="Nilai" error={!parsed.ok && raw.trim() ? parsed.error : converted && !converted.ok ? converted.error : null}>
        <TextInput inputMode="decimal" value={raw} onChange={(event) => setRaw(event.target.value)} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Dari">
          <SelectInput value={from} onChange={(event) => setFrom(event.target.value as StorageId)}>
            {STORAGE_UNITS.map((unit) => (
              <option key={unit.id} value={unit.id}>
                {base === 1024 ? unit.labelIec : unit.labelSi}
              </option>
            ))}
          </SelectInput>
        </Field>
        <Field label="Ke">
          <SelectInput value={to} onChange={(event) => setTo(event.target.value as StorageId)}>
            {STORAGE_UNITS.map((unit) => (
              <option key={unit.id} value={unit.id}>
                {base === 1024 ? unit.labelIec : unit.labelSi}
              </option>
            ))}
          </SelectInput>
        </Field>
      </div>
      <Card>
        <p className="text-xs font-medium text-mute">Hasil</p>
        <p className="font-mono text-3xl font-medium break-all tabular-nums">{converted?.ok ? formatNumber(converted.value) : "—"}</p>
        <p className="mt-1 text-sm text-mute">{label(to)}</p>
      </Card>
      <Notice>
        {base === 1024
          ? "Biner: 1 KiB = 1.024 B. Ini yang biasa dipakai sistem berkas."
          : "Desimal: 1 kB = 1.000 B. Ini yang sering dipakai produsen penyimpanan."}
      </Notice>
      <ul className="space-y-1">
        {rows.map((row) => (
          <li key={row.unit.id} className="flex justify-between gap-3 px-1 py-2 text-sm">
            <span className="text-mute">{base === 1024 ? row.unit.labelIec : row.unit.labelSi}</span>
            <span className="font-mono tabular-nums">{row.result.ok ? formatNumber(row.result.value) : "—"}</span>
          </li>
        ))}
      </ul>
    </>
  );
}

type PercentMode = "of" | "what" | "change";

export function CalcPercent() {
  const [mode, setMode] = useState<PercentMode>("of");
  const [a, setA] = useState("10");
  const [b, setB] = useState("200");
  const left = parseUserNumber(a);
  const right = parseUserNumber(b);
  let result: { ok: true; value: number } | { ok: false; error: string } | null = null;
  if (left.ok && right.ok) {
    if (mode === "of") result = percentOf(left.value, right.value);
    if (mode === "what") result = whatPercent(left.value, right.value);
    if (mode === "change") result = percentChange(left.value, right.value);
  }
  const labels =
    mode === "of"
      ? ["Persen", "Nilai dasar", "Hasil"]
      : mode === "what"
        ? ["Bagian", "Keseluruhan", "Persen"]
        : ["Nilai awal", "Nilai akhir", "Perubahan"];
  return (
    <>
      <Segmented
        label="Jenis"
        value={mode}
        onChange={setMode}
        options={[
          { id: "of", label: "X% dari Y" },
          { id: "what", label: "Porsi" },
          { id: "change", label: "Perubahan" },
        ]}
      />
      <div className="grid grid-cols-2 gap-3">
        <Field label={labels[0] ?? ""} error={a.trim() && !left.ok ? left.error : null}>
          <TextInput inputMode="decimal" value={a} onChange={(event) => setA(event.target.value)} />
        </Field>
        <Field label={labels[1] ?? ""} error={b.trim() && !right.ok ? right.error : null}>
          <TextInput inputMode="decimal" value={b} onChange={(event) => setB(event.target.value)} />
        </Field>
      </div>
      <Card>
        <p className="text-xs font-medium text-mute">{labels[2]}</p>
        <p className="font-mono text-3xl font-medium tabular-nums">
          {result?.ok ? `${formatNumber(result.value)}${mode === "of" ? "" : "%"}` : "—"}
        </p>
        {result && !result.ok ? <p className="mt-2 text-sm text-danger">{result.error}</p> : null}
      </Card>
      <Notice>
        {mode === "change"
          ? "Perubahan = (akhir − awal) / awal × 100. Nilai awal nol tidak dihitung."
          : mode === "what"
            ? "Porsi = bagian / keseluruhan × 100. Keseluruhan nol tidak dihitung."
            : "Contoh: 10% dari 200 = 20."}
      </Notice>
    </>
  );
}
