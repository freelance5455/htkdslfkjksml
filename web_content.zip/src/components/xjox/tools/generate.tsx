import { Eye, EyeOff, RefreshCw } from "lucide-react";
import { useState } from "react";
import {
  generateNumbers,
  generatePassword,
  generateUuids,
  inkForColor,
  makePlaceholder,
  randomColor,
  strengthLabel,
  type PasswordOptions,
} from "@/lib/xjox/generate";
import { formatNumber } from "@/lib/xjox/format";
import { parseUserNumber } from "@/lib/xjox/math";
import { ActionRow, Button, Card, CheckRow, Field, Notice, Output, Segmented, TextInput } from "../ui";

const PASSWORD_DEFAULT: PasswordOptions = {
  length: 16,
  lower: true,
  upper: true,
  digit: true,
  symbol: true,
  avoidAmbiguous: true,
};

export function GenUuid() {
  const [count, setCount] = useState(1);
  const [made, setMade] = useState(() => generateUuids(1));
  const text = made.ok ? made.ids.join("\n") : "";
  return (
    <>
      <Field label="Jumlah" hint="1 sampai 20." error={made.ok ? null : made.error}>
        <TextInput
          inputMode="numeric"
          value={String(count)}
          onChange={(event) => {
            const next = Number(event.target.value);
            setCount(Number.isFinite(next) ? next : 0);
          }}
        />
      </Field>
      <Button
        onClick={() => {
          const amount = Number(count);
          setMade(generateUuids(amount));
        }}
      >
        <RefreshCw /> Buat ulang
      </Button>
      <Output text={text} placeholder="UUID muncul di sini." />
      <ActionRow text={text} title="UUID" />
    </>
  );
}

export function GenPassword() {
  const [opts, setOpts] = useState(PASSWORD_DEFAULT);
  const [made, setMade] = useState(() => generatePassword(PASSWORD_DEFAULT));
  const [visible, setVisible] = useState(false);
  const patch = (partial: Partial<PasswordOptions>) => setOpts((current) => ({ ...current, ...partial }));
  const password = made.ok ? made.password : "";
  return (
    <>
      <Notice>Sandi dibuat di perangkat dan tidak disimpan, termasuk tidak masuk riwayat.</Notice>
      <Field label="Panjang" hint="4–64. Tiap jenis yang dipilih pasti muncul." error={made.ok ? null : made.error}>
        <TextInput
          inputMode="numeric"
          value={String(opts.length)}
          onChange={(event) => patch({ length: Number(event.target.value) })}
        />
      </Field>
      <div className="grid gap-2">
        <CheckRow label="Huruf kecil" checked={opts.lower} onChange={(lower) => patch({ lower })} />
        <CheckRow label="Huruf besar" checked={opts.upper} onChange={(upper) => patch({ upper })} />
        <CheckRow label="Angka" checked={opts.digit} onChange={(digit) => patch({ digit })} />
        <CheckRow label="Simbol" checked={opts.symbol} onChange={(symbol) => patch({ symbol })} />
        <CheckRow label="Hindari karakter mirip (0, O, 1, l)" checked={opts.avoidAmbiguous} onChange={(avoidAmbiguous) => patch({ avoidAmbiguous })} />
      </div>
      <Button
        onClick={() => {
          const next = { ...opts, length: Number(opts.length) };
          setOpts(next);
          setMade(generatePassword(next));
        }}
      >
        <RefreshCw /> Buat ulang
      </Button>
      {made.ok ? (
        <Card>
          <div className="flex items-start justify-between gap-3">
            <p className={cnVisible(visible)}>{visible ? made.password : "•".repeat(made.password.length)}</p>
            <Button variant="ghost" className="h-11 shrink-0 px-3" onClick={() => setVisible((value) => !value)} aria-pressed={visible}>
              {visible ? <EyeOff /> : <Eye />}
              {visible ? "Sembunyi" : "Lihat"}
            </Button>
          </div>
          <p className="mt-3 text-sm text-mute">
            {strengthLabel(made.bits)} · sekitar {Math.round(made.bits)} bit dari {made.charset} karakter.
          </p>
          <div className="mt-2 h-2 overflow-hidden rounded-full bg-sunken">
            <div className="h-full bg-accent" style={{ width: `${Math.max(8, Math.min(100, made.bits))}%` }} />
          </div>
        </Card>
      ) : null}
      <ActionRow text={password} title="Kata sandi" />
    </>
  );
}

function cnVisible(visible: boolean) {
  return visible
    ? "min-w-0 flex-1 font-mono text-lg break-all text-ink"
    : "min-w-0 flex-1 font-mono text-lg break-all tracking-widest text-ink";
}

export function GenNumber() {
  const [minRaw, setMinRaw] = useState("1");
  const [maxRaw, setMaxRaw] = useState("100");
  const [count, setCount] = useState("5");
  const [integer, setInteger] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [values, setValues] = useState<number[]>(() => {
    const made = generateNumbers({ min: 1, max: 100, count: 5, integer: true });
    return made.ok ? made.values : [];
  });
  const text = values.map((value) => (integer ? String(value) : formatNumber(value))).join("\n");
  return (
    <>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Minimum">
          <TextInput inputMode="decimal" value={minRaw} onChange={(event) => setMinRaw(event.target.value)} />
        </Field>
        <Field label="Maksimum">
          <TextInput inputMode="decimal" value={maxRaw} onChange={(event) => setMaxRaw(event.target.value)} />
        </Field>
      </div>
      <Field label="Jumlah" hint="1–20. Batas ikut dalam hasil bilangan bulat.">
        <TextInput inputMode="numeric" value={count} onChange={(event) => setCount(event.target.value)} />
      </Field>
      <CheckRow label="Bilangan bulat" checked={integer} onChange={setInteger} />
      {error ? <Notice tone="danger">{error}</Notice> : null}
      <Button
        onClick={() => {
          const min = parseUserNumber(minRaw);
          const max = parseUserNumber(maxRaw);
          const amount = Number(count);
          if (!min.ok) return setError(min.error);
          if (!max.ok) return setError(max.error);
          if (!Number.isInteger(amount)) return setError("Jumlah harus bilangan bulat.");
          const made = generateNumbers({ min: min.value, max: max.value, count: amount, integer });
          if (!made.ok) {
            setValues([]);
            setError(made.error);
            return;
          }
          setError(null);
          setValues(made.values);
        }}
      >
        <RefreshCw /> Buat angka
      </Button>
      <Output text={text} placeholder="Angka acak muncul di sini." />
      <ActionRow text={text} title="Angka acak" />
    </>
  );
}

export function GenColor() {
  const [color, setColor] = useState(() => randomColor());
  const rgb = `rgb(${color.r}, ${color.g}, ${color.b})`;
  return (
    <>
      <div
        className="grid h-40 place-items-center rounded-card border border-line font-mono text-lg font-medium"
        style={{ backgroundColor: color.hex, color: inkForColor(color.r, color.g, color.b) }}
      >
        {color.hex}
      </div>
      <Card>
        <p className="font-mono text-sm">HEX {color.hex}</p>
        <p className="mt-1 font-mono text-sm">
          RGB {color.r}, {color.g}, {color.b}
        </p>
      </Card>
      <Button onClick={() => setColor(randomColor())}>
        <RefreshCw /> Buat ulang
      </Button>
      <div className="grid gap-2 sm:grid-cols-2">
        <ActionRow text={color.hex} title="Warna HEX" />
        <ActionRow text={rgb} title="Warna RGB" />
      </div>
    </>
  );
}

export function GenLorem() {
  const [mode, setMode] = useState<"id" | "lorem">("id");
  const [paragraphs, setParagraphs] = useState("2");
  const [sentences, setSentences] = useState("3");
  const [error, setError] = useState<string | null>(null);
  const [text, setText] = useState(() => {
    const made = makePlaceholder({ mode: "id", paragraphs: 2, sentences: 3 });
    return made.ok ? made.text : "";
  });
  return (
    <>
      <Notice>Ini teks pengisi untuk tata letak, bukan konten bermakna.</Notice>
      <Segmented
        label="Bahasa pengisi"
        value={mode}
        onChange={setMode}
        options={[
          { id: "id", label: "Indonesia" },
          { id: "lorem", label: "Lorem" },
        ]}
      />
      <div className="grid grid-cols-2 gap-3">
        <Field label="Paragraf" hint="1–8">
          <TextInput inputMode="numeric" value={paragraphs} onChange={(event) => setParagraphs(event.target.value)} />
        </Field>
        <Field label="Kalimat" hint="1–8 tiap paragraf">
          <TextInput inputMode="numeric" value={sentences} onChange={(event) => setSentences(event.target.value)} />
        </Field>
      </div>
      {error ? <Notice tone="danger">{error}</Notice> : null}
      <Button
        onClick={() => {
          const made = makePlaceholder({
            mode,
            paragraphs: Number(paragraphs),
            sentences: Number(sentences),
          });
          if (!made.ok) {
            setText("");
            setError(made.error);
            return;
          }
          setError(null);
          setText(made.text);
        }}
      >
        <RefreshCw /> Buat ulang
      </Button>
      <Output text={text} placeholder="Teks pengisi muncul di sini." />
      <ActionRow text={text} title="Teks pengisi" />
    </>
  );
}
