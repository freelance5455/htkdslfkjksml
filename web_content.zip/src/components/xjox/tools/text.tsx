import { useState, type ReactNode } from "react";
import {
  changeCase,
  dedupeLines,
  removeBlankLines,
  removeExtraSpaces,
  reverseText,
  shuffleText,
  statsSummary,
  textLimitMessage,
  textStats,
  type CaseMode,
} from "@/lib/xjox/text";
import type { ToolId } from "@/lib/xjox/catalog";
import { ActionRow, Button, Card, Notice, Output, Segmented, TextArea } from "../ui";

const SAMPLE = "  XJOX   Tools membantu\n\npekerjaan   harian.\nXJOX Tools\nXJOX Tools";

function useTextDraft() {
  const [input, setInput] = useState("");
  return { input, setInput, blocked: textLimitMessage(input) };
}

function Draft({
  input,
  setInput,
  blocked,
}: {
  input: string;
  setInput: (value: string) => void;
  blocked: string | null;
}) {
  return (
    <Card className="space-y-3">
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-sm font-semibold">Teks sumber</h2>
        <Button variant="ghost" className="h-11 px-3" onClick={() => setInput(SAMPLE)}>
          Isi contoh
        </Button>
      </div>
      <TextArea value={input} onChange={(event) => setInput(event.target.value)} placeholder="Ketik atau tempel teks…" spellCheck />
      {blocked ? <Notice tone="danger">{blocked}</Notice> : null}
    </Card>
  );
}

export function TextCount() {
  const draft = useTextDraft();
  const stats = draft.blocked ? null : textStats(draft.input);
  const summary = stats ? statsSummary(stats) : "";
  const items = stats
    ? [
        ["Karakter", stats.chars],
        ["Tanpa spasi", stats.charsNoSpace],
        ["Kata", stats.words],
        ["Kalimat", stats.sentences],
        ["Paragraf", stats.paragraphs],
        ["Baris", stats.lines],
      ]
    : [];
  return (
    <>
      <Draft {...draft} />
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        {items.map(([label, value]) => (
          <Card key={String(label)} className="px-3 py-3">
            <div className="text-xs font-medium text-mute">{label}</div>
            <div className="font-mono text-2xl font-medium tabular-nums">{Number(value).toLocaleString("id-ID")}</div>
          </Card>
        ))}
      </div>
      <ActionRow text={summary} title="Penghitung teks" />
    </>
  );
}

export function TextCase() {
  const draft = useTextDraft();
  const [mode, setMode] = useState<CaseMode>("upper");
  const output = draft.blocked ? "" : changeCase(draft.input, mode);
  return (
    <>
      <Segmented
        label="Bentuk huruf"
        value={mode}
        onChange={setMode}
        options={[
          { id: "upper", label: "BESAR" },
          { id: "lower", label: "kecil" },
          { id: "title", label: "Judul" },
          { id: "sentence", label: "Kalimat" },
          { id: "toggle", label: "Tukar" },
        ]}
      />
      <Draft {...draft} />
      <Output text={output} placeholder="Hasil ubah huruf muncul di sini." />
      <ActionRow text={output} title="Ubah huruf" />
    </>
  );
}

export function TextSpace() {
  const draft = useTextDraft();
  const result = draft.blocked ? null : removeExtraSpaces(draft.input);
  return (
    <>
      <Draft {...draft} />
      <Notice>{result ? (result.removed > 0 ? `${result.removed} karakter spasi dihapus.` : "Tidak ada spasi berlebih.") : null}</Notice>
      <Output text={result?.text ?? ""} placeholder="Teks yang sudah dirapikan muncul di sini." />
      <ActionRow text={result?.text ?? ""} title="Rapikan spasi" />
    </>
  );
}

export function TextBlank() {
  const draft = useTextDraft();
  const result = draft.blocked ? null : removeBlankLines(draft.input);
  return (
    <>
      <Draft {...draft} />
      <Notice>{result ? (result.removed > 0 ? `${result.removed} baris kosong dihapus.` : "Tidak ada baris kosong.") : null}</Notice>
      <Output text={result?.text ?? ""} placeholder="Teks tanpa baris kosong muncul di sini." />
      <ActionRow text={result?.text ?? ""} title="Hapus baris kosong" />
    </>
  );
}

export function TextShuffle() {
  const draft = useTextDraft();
  const [mode, setMode] = useState<"words" | "lines">("words");
  const [output, setOutput] = useState("");
  const [error, setError] = useState<string | null>(null);
  return (
    <>
      <Segmented
        label="Yang diacak"
        value={mode}
        onChange={(next) => {
          setMode(next);
          setOutput("");
          setError(null);
        }}
        options={[
          { id: "words", label: "Kata" },
          { id: "lines", label: "Baris" },
        ]}
      />
      <Draft
        input={draft.input}
        blocked={draft.blocked}
        setInput={(value) => {
          draft.setInput(value);
          setOutput("");
          setError(null);
        }}
      />
      <Button
        disabled={Boolean(draft.blocked)}
        onClick={() => {
          const made = shuffleText(draft.input, mode);
          if (!made.ok) {
            setOutput("");
            setError(made.error);
            return;
          }
          setError(null);
          setOutput(made.text);
        }}
      >
        Acak
      </Button>
      {error ? <Notice tone="danger">{error}</Notice> : <Notice>Urutan kata menggabungkan spasi menjadi satu. Acak memakai sumber kriptografis.</Notice>}
      <Output text={output} placeholder="Tekan Acak untuk melihat hasil." />
      <ActionRow text={output} title="Acak teks" />
    </>
  );
}

export function TextReverse() {
  const draft = useTextDraft();
  const [mode, setMode] = useState<"chars" | "words" | "lines">("chars");
  const output = draft.blocked ? "" : reverseText(draft.input, mode);
  return (
    <>
      <Segmented
        label="Balik berdasarkan"
        value={mode}
        onChange={setMode}
        options={[
          { id: "chars", label: "Karakter" },
          { id: "words", label: "Kata" },
          { id: "lines", label: "Baris" },
        ]}
      />
      <Draft {...draft} />
      <Output text={output} placeholder="Teks terbalik muncul di sini." />
      <ActionRow text={output} title="Balik teks" />
    </>
  );
}

export function TextDedupe() {
  const draft = useTextDraft();
  const [ignoreCase, setIgnoreCase] = useState(false);
  const [trim, setTrim] = useState(true);
  const result = draft.blocked ? null : dedupeLines(draft.input, { ignoreCase, trim });
  return (
    <>
      <div className="grid gap-2">
        <label className="flex min-h-12 items-center gap-3 rounded-control border border-line bg-card px-3 text-sm font-medium">
          <input type="checkbox" className="size-5 accent-accent" checked={ignoreCase} onChange={(event) => setIgnoreCase(event.target.checked)} />
          Abaikan huruf besar/kecil
        </label>
        <label className="flex min-h-12 items-center gap-3 rounded-control border border-line bg-card px-3 text-sm font-medium">
          <input type="checkbox" className="size-5 accent-accent" checked={trim} onChange={(event) => setTrim(event.target.checked)} />
          Rapikan spasi di tepi baris
        </label>
      </div>
      <Draft {...draft} />
      <Notice>{result ? `${result.removed} baris ganda dihapus.` : null}</Notice>
      <Output text={result?.text ?? ""} placeholder="Baris unik muncul di sini." />
      <ActionRow text={result?.text ?? ""} title="Hapus baris ganda" />
    </>
  );
}

export const TEXT_TOOLS: Partial<Record<ToolId, () => ReactNode>> = {
  "text-count": TextCount,
  "text-case": TextCase,
  "text-space": TextSpace,
  "text-blank": TextBlank,
  "text-shuffle": TextShuffle,
  "text-reverse": TextReverse,
  "text-dedupe": TextDedupe,
};
