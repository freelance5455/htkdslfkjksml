import { useEffect, useState } from "react";
import type { SelfTestResult, Settings, Tab } from "../types";
import { buildTests, runSelfTests } from "../lib/selftest";
import { storageInfo } from "../lib/modelManager";
import { Btn, Card, Chip, Icon, SectionTitle, useToast } from "./ui";
import { cn } from "../utils/cn";

interface Props {
  settings: Settings;
  onGoTo: (t: Tab) => void;
}

export default function TestTab({ settings, onGoTo }: Props) {
  const toast = useToast();
  const [results, setResults] = useState<SelfTestResult[]>([]);
  const [running, setRunning] = useState(false);
  const [store, setStore] = useState({ usage: 0, quota: 0 });
  const tests = buildTests(settings);

  const mem = (navigator as any).deviceMemory as number | undefined;
  const cores = navigator.hardwareConcurrency || 0;

  useEffect(() => {
    void storageInfo().then(setStore);
  }, [results.length]);

  const upsert = (r: SelfTestResult) =>
    setResults((prev) => {
      const i = prev.findIndex((x) => x.id === r.id);
      if (i < 0) return [...prev, r];
      const next = [...prev];
      next[i] = r;
      return next;
    });

  const runAll = async () => {
    setRunning(true);
    setResults(tests.map((t) => ({ id: t.id, name: t.name, status: "run", detail: "queued" })));
    try {
      await runSelfTests(settings, upsert);
      toast("Self-test finished — see results", "ok");
    } finally {
      setRunning(false);
    }
  };

  const runOne = async (id: string) => {
    const t = tests.find((x) => x.id === id);
    if (!t) return;
    upsert({ id, name: t.name, status: "run", detail: "running…" });
    try {
      const res = await t.run();
      upsert({ id, name: t.name, status: res.status, detail: res.detail, at: Date.now() });
    } catch (e: any) {
      upsert({ id, name: t.name, status: "fail", detail: String(e?.message || e), at: Date.now() });
    }
  };

  return (
    <div className="space-y-5">
      <Card className="space-y-3 p-4">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-sm font-semibold text-mist-100">
            Device self-test
          </h2>
          <Chip tone={navigator.onLine ? "jade" : "rust"}>
            <Icon name={navigator.onLine ? "wifi" : "wifioff"} className="h-3 w-3" />
            {navigator.onLine ? "online" : "offline"}
          </Chip>
        </div>
        <p className="text-[11px] leading-relaxed text-mist-400">
          These tests execute real operations on <b>this device</b> (WASM, Cache API, audio decode,
          offline model inference with a network-request spy, RTL rendering, SRT round-trip) and
          report what actually happened — nothing is simulated. For a true offline run, switch the
          phone to airplane mode, re-run, and confirm 0 external requests.
        </p>
        <Btn size="lg" className="w-full" onClick={() => void runAll()} disabled={running}>
          <Icon name="flask" className="h-5 w-5" />
          {running ? "Running…" : "Run all tests"}
        </Btn>
      </Card>

      <Card className="p-4">
        <SectionTitle>Environment</SectionTitle>
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="rounded-lg bg-ink-850 p-2.5">
            <p className="text-mist-500">Memory / threads</p>
            <p className="font-display font-semibold text-mist-100">
              {mem ? `${mem} GB` : "unknown"} / {cores || "?"}
            </p>
          </div>
          <div className="rounded-lg bg-ink-850 p-2.5">
            <p className="text-mist-500">Storage</p>
            <p className="font-display font-semibold text-mist-100">
              {store.quota ? `${Math.round(store.usage / 1048576)} MB used` : "—"}
            </p>
          </div>
          <div className="col-span-2 rounded-lg bg-ink-850 p-2.5">
            <p className="text-mist-500">Browser</p>
            <p className="truncate text-mist-300" dir="ltr">
              {navigator.userAgent.replace(/\b[\w.]+\/[\w.]+\b/g, (m) => m).slice(0, 90)}…
            </p>
          </div>
        </div>
      </Card>

      <div>
        <SectionTitle>
          Results{" "}
          {results.length > 0 && (
            <span className="ml-2 font-body text-[10px] font-bold text-mist-500">
              {results.filter((r) => r.status === "pass").length} passed ·{" "}
              {results.filter((r) => r.status === "fail").length} failed ·{" "}
              {results.filter((r) => r.status === "skip").length} skipped
            </span>
          )}
        </SectionTitle>
        <div className="space-y-2">
          {tests.map((t) => {
            const r = results.find((x) => x.id === t.id);
            return (
              <Card key={t.id} className="p-3">
                <div className="flex items-center gap-2.5">
                  <span
                    className={cn(
                      "flex h-7 w-7 shrink-0 items-center justify-center rounded-full",
                      r?.status === "pass" && "bg-moss-500/15 text-moss-400",
                      r?.status === "fail" && "bg-rust-500/15 text-rust-400",
                      r?.status === "skip" && "bg-ink-700 text-mist-400",
                      r?.status === "run" && "bar-active bg-brass-500/20 text-brass-400",
                      !r && "bg-ink-700 text-mist-500"
                    )}
                  >
                    <Icon
                      name={
                        r?.status === "pass"
                          ? "check"
                          : r?.status === "fail"
                            ? "x"
                            : r?.status === "run"
                              ? "refresh"
                              : r?.status === "skip"
                                ? "clock"
                                : "flask"
                      }
                      className="h-3.5 w-3.5"
                    />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="font-display text-xs font-semibold text-mist-100">{t.name}</p>
                    <p className="mt-0.5 text-[11px] leading-relaxed text-mist-500">
                      {r?.detail ?? "not run yet"}
                    </p>
                  </div>
                  {r && r.at && (
                    <span className="shrink-0 text-[10px] tabular-nums text-mist-600">
                      {new Date(r.at).toLocaleTimeString()}
                    </span>
                  )}
                  <Btn size="sm" variant="ghost" onClick={() => void runOne(t.id)}>
                    {r && r.status !== "run" ? "re-run" : "run"}
                  </Btn>
                </div>
              </Card>
            );
          })}
        </div>
      </div>

      <Card className="p-4">
        <SectionTitle>Acceptance checklist (18 points)</SectionTitle>
        <p className="text-[11px] leading-relaxed text-mist-400">
          The full 18-step device acceptance checklist — airplane mode, real English + second
          language video, sync & RTL verification, offline reopen, long-video limits, persistence —
          is documented in <button className="text-brass-400 underline" onClick={() => onGoTo("docs")}>Docs → Testing offline</button>.
          This tab covers the technical half; the video-dependent half needs your device and files.
        </p>
      </Card>
    </div>
  );
}
