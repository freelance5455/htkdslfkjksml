import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, Key, Lock, CheckCircle2, AlertTriangle, FileSignature, RefreshCw, Copy, Check, ExternalLink, ShieldAlert, FileText, ArrowRight } from 'lucide-react';
import {
  signAdministrativeUpdate,
  verifyAdministrativeSignature,
  SignedAdminPackage,
  PROPHET_CERTIFIED_EMAIL,
  PROPHET_DERIVED_PUBLIC_KEY,
  PROPHET_AUTHORITY
} from '../lib/sovereignCertificateVerifier';

interface SovereignCertificateVerifierProps {
  onUpdateSigned?: (signedPackage: SignedAdminPackage) => void;
}

export const SovereignCertificateVerifier: React.FC<SovereignCertificateVerifierProps> = ({
  onUpdateSigned
}) => {
  const [updateType, setUpdateType] = useState<string>('CONTENT_CATALOG_UPDATE');
  const [updateTitle, setUpdateTitle] = useState<string>('Prophetic Worship & Soaking Track Master Release v5.4.1');
  const [updateDescription, setUpdateDescription] = useState<string>('Official release of 528Hz celestial frequencies and daily prophetic liturgy signed by Prophet JUHNKRIX SYNVAGORD.');
  const [isSigning, setIsSigning] = useState<boolean>(false);
  const [lastSignedPackage, setLastSignedPackage] = useState<SignedAdminPackage | null>(null);
  const [verificationResult, setVerificationResult] = useState<{
    isValid: boolean;
    message: string;
    authority: string;
    signerEmail: string;
    signedAt: string;
  } | null>(null);

  const [copiedSig, setCopiedSig] = useState<boolean>(false);
  const [recentSignedUpdates, setRecentSignedUpdates] = useState<SignedAdminPackage[]>([
    {
      signatureId: 'JM-SIG-V54-INITIAL-777',
      signature: 'SIG-ED25519-777-98e3b2110c4f887612d93e11-genesis-777a888b',
      payloadDigest: '98e3b2110c4f887612d93e11005a76bc3451299ef871b8492048572910481729',
      publicKey: PROPHET_DERIVED_PUBLIC_KEY,
      signerEmail: PROPHET_CERTIFIED_EMAIL,
      authority: PROPHET_AUTHORITY,
      signedAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
      validThrough: '2050-12-31T23:59:59.000Z',
      algorithm: 'Ed25519-SHA256-Sovereign-Master',
      payload: {
        actionType: 'GENESIS_SANCTUARY_BOOT',
        title: 'Initial Decentralized Sovereign Mesh Boot & Key Derivation',
        description: 'Hardcoded public key binding to juhnkrix.musika@gmail.com initialized.'
      }
    }
  ]);

  const handleSignUpdate = async () => {
    if (!updateTitle.trim()) return;
    setIsSigning(true);
    setVerificationResult(null);

    try {
      // 1. Sign update payload using Prophet's sovereign credential
      const signed = await signAdministrativeUpdate({
        actionType: updateType,
        title: updateTitle.trim(),
        description: updateDescription.trim(),
        timestamp: Date.now()
      });

      // 2. Immediately verify signature against hardcoded public key derived from juhnkrix.musika@gmail.com
      const verification = await verifyAdministrativeSignature(signed);

      setLastSignedPackage(signed);
      setVerificationResult({
        isValid: verification.isValid,
        message: verification.message,
        authority: verification.authority,
        signerEmail: verification.signerEmail,
        signedAt: verification.signedAt
      });

      setRecentSignedUpdates(prev => [signed, ...prev.slice(0, 9)]);
      if (onUpdateSigned) onUpdateSigned(signed);
    } catch (err: any) {
      setVerificationResult({
        isValid: false,
        message: `Signing failed: ${err?.message || 'Cryptographic engine error'}`,
        authority: PROPHET_AUTHORITY,
        signerEmail: PROPHET_CERTIFIED_EMAIL,
        signedAt: new Date().toISOString()
      });
    } finally {
      setIsSigning(false);
    }
  };

  const handleTestTamperedSignature = async () => {
    setIsSigning(true);
    // Simulate an unauthorized attacker attempting to forge an update
    const forgedPackage: SignedAdminPackage = {
      signatureId: 'FORGED-SIG-HACKER-ATTEMPT-000',
      signature: 'SIG-ED25519-777-FORGED-TAMPERED-BYTE-STRING',
      payloadDigest: 'forged_fake_digest_1234567890abcdef',
      publicKey: 'FORGED_PUBLIC_KEY_NOT_MATCHING_PROPHET',
      signerEmail: 'intruder@unauthorized-cloner.com',
      authority: 'ROGUE_SIGNING_AUTHORITY',
      signedAt: new Date().toISOString(),
      validThrough: '2026-12-31T23:59:59.000Z',
      algorithm: 'Unsigned-Raw',
      payload: {
        actionType: 'MALICIOUS_INJECTION',
        title: 'Tampered App Store Redirect',
        description: 'Attempted to push malicious binary without Prophet authorization.'
      }
    };

    const verification = await verifyAdministrativeSignature(forgedPackage);
    setLastSignedPackage(forgedPackage);
    setVerificationResult({
      isValid: verification.isValid,
      message: verification.message,
      authority: verification.authority,
      signerEmail: verification.signerEmail,
      signedAt: verification.signedAt
    });
    setIsSigning(false);
  };

  const copySignature = (sig: string) => {
    navigator.clipboard.writeText(sig);
    setCopiedSig(true);
    setTimeout(() => setCopiedSig(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Security Constitution */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-950 to-slate-900 border border-amber-500/30 shadow-xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-400 shadow-lg shadow-amber-500/20">
              <FileSignature className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  SOVEREIGN SIGNATURE ENGINE
                </span>
                <span className="text-xs text-emerald-400 font-mono font-bold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Hardcoded Public Key Active
                </span>
              </div>
              <h2 className="text-lg font-bold text-white mt-0.5">
                Prophet Administrative Digital Signature Verifier
              </h2>
              <p className="text-xs text-slate-300 font-mono">
                Ensures only <strong>{PROPHET_CERTIFIED_EMAIL}</strong> can push content or configuration updates to the network.
              </p>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/90 border border-slate-800 text-right font-mono text-[11px] space-y-0.5">
            <span className="text-slate-400 block">Authority Public Key:</span>
            <span className="text-cyan-300 font-bold block max-w-[260px] truncate select-all">
              {PROPHET_DERIVED_PUBLIC_KEY}
            </span>
          </div>
        </div>
      </div>

      {/* Main Signing & Verification Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Sign Administrative Update Form */}
        <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Lock className="w-4 h-4 text-amber-400" />
              Digitally Sign Administrative Update
            </h3>
            <span className="text-[11px] font-mono text-slate-400">Ed25519 SHA-256</span>
          </div>

          <div className="space-y-3 text-xs font-mono">
            <div>
              <label className="text-slate-300 block mb-1.5 font-bold">Update Category / Action Type:</label>
              <select
                value={updateType}
                onChange={(e) => setUpdateType(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl px-3.5 py-2 text-slate-100 focus:outline-none"
              >
                <option value="CONTENT_CATALOG_UPDATE">Content Catalog Update (Audio, Video, Images)</option>
                <option value="VERSION_RELEASE_DEPLOYMENT">App Version Release & APK Deployment</option>
                <option value="PROPHETIC_LITURGY_PUSH">Prophetic Word & Liturgy Push Notification</option>
                <option value="MAGIC_IP_NETWORK_CONFIG">Magic Fixed IP Network Configuration</option>
                <option value="DATABASE_SCHEMA_MIGRATION">phpMyAdmin / MySQL Database Migration</option>
                <option value="SECURITY_POLICY_UPDATE">Security Policy & Threat Whitelist Amendment</option>
              </select>
            </div>

            <div>
              <label className="text-slate-300 block mb-1.5 font-bold">Update Title / Release Label:</label>
              <input
                type="text"
                value={updateTitle}
                onChange={(e) => setUpdateTitle(e.target.value)}
                placeholder="e.g. Anointed Worship Track Master Release v5.4.1..."
                className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl px-3.5 py-2 text-white focus:outline-none"
              />
            </div>

            <div>
              <label className="text-slate-300 block mb-1.5 font-bold">Administrative Details / Changelog:</label>
              <textarea
                value={updateDescription}
                onChange={(e) => setUpdateDescription(e.target.value)}
                rows={3}
                placeholder="Describe the update details, changelog, or broadcast instructions..."
                className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl px-3.5 py-2 text-white focus:outline-none resize-none"
              />
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] space-y-1">
              <div className="flex items-center justify-between text-slate-400">
                <span>Signer Identity:</span>
                <span className="text-amber-300 font-bold">{PROPHET_CERTIFIED_EMAIL}</span>
              </div>
              <div className="flex items-center justify-between text-slate-400">
                <span>Cryptographic Digest:</span>
                <span className="text-emerald-400">SHA-256 (Deterministic WebCrypto)</span>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={handleSignUpdate}
                disabled={isSigning}
                className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black uppercase text-xs tracking-wider cursor-pointer shadow-lg hover:shadow-amber-500/20 transition-all"
              >
                {isSigning ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Signing & Verifying...</span>
                  </>
                ) : (
                  <>
                    <FileSignature className="w-4 h-4" />
                    <span>Digitally Sign & Verify Update</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={handleTestTamperedSignature}
                disabled={isSigning}
                className="px-3 py-2.5 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 border border-rose-500/40 text-rose-300 text-xs font-bold cursor-pointer transition-all"
                title="Simulates a forged signature from an unauthorized party to verify rejection"
              >
                Test Tamper
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Signature Verification Result & Public Key Audit */}
        <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Sovereign Verification Status
            </h3>
            <span className="text-[11px] font-mono text-emerald-400">Public Key Verified</span>
          </div>

          {verificationResult ? (
            <div className="space-y-3 font-mono text-xs">
              <div
                className={`p-3.5 rounded-xl border flex items-start gap-3 ${
                  verificationResult.isValid
                    ? 'bg-emerald-950/70 border-emerald-500/50 text-emerald-200'
                    : 'bg-rose-950/70 border-rose-500/50 text-rose-200'
                }`}
              >
                {verificationResult.isValid ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                ) : (
                  <ShieldAlert className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
                )}
                <div className="space-y-1">
                  <div className="font-bold uppercase tracking-wide">
                    {verificationResult.isValid ? 'SIGNATURE VERIFIED AUTHENTIC' : 'VERIFICATION REJECTED: FORGERY'}
                  </div>
                  <p className="text-[11px] leading-relaxed opacity-90">
                    {verificationResult.message}
                  </p>
                </div>
              </div>

              {lastSignedPackage && (
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-[11px]">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Signature ID:</span>
                    <span className="text-white font-bold">{lastSignedPackage.signatureId}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Signer Identity:</span>
                    <span className={lastSignedPackage.signerEmail === PROPHET_CERTIFIED_EMAIL ? 'text-amber-300 font-bold' : 'text-rose-400 font-bold'}>
                      {lastSignedPackage.signerEmail}
                    </span>
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-slate-400">
                      <span>Digital Signature:</span>
                      <button
                        type="button"
                        onClick={() => copySignature(lastSignedPackage.signature)}
                        className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
                      >
                        {copiedSig ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedSig ? 'Copied' : 'Copy'}</span>
                      </button>
                    </div>
                    <span className="text-[10px] text-slate-300 break-all select-all block bg-slate-900 p-1.5 rounded border border-slate-800">
                      {lastSignedPackage.signature}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Payload Digest:</span>
                    <span className="text-emerald-400 truncate max-w-[200px]">{lastSignedPackage.payloadDigest}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Timestamp:</span>
                    <span className="text-slate-300">{new Date(lastSignedPackage.signedAt).toLocaleTimeString()}</span>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="p-8 text-center text-slate-500 font-mono text-xs border border-dashed border-slate-800 rounded-xl space-y-2">
              <Key className="w-8 h-8 text-slate-600 mx-auto" />
              <p>Ready to sign administrative updates.</p>
              <p className="text-[11px] text-slate-600">
                Signatures will be validated against Prophet public key derived from {PROPHET_CERTIFIED_EMAIL}.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Recent Signed Admin Updates History */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <FileText className="w-4 h-4 text-cyan-400" />
            Authenticated Sovereign Update Audit Trail
          </h3>
          <span className="text-[11px] font-mono text-slate-400">
            {recentSignedUpdates.length} Verified Signatures
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3">Action Type</th>
                <th className="py-2.5 px-3">Update Title</th>
                <th className="py-2.5 px-3">Signer</th>
                <th className="py-2.5 px-3">Signature ID</th>
                <th className="py-2.5 px-3">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {recentSignedUpdates.map((item) => (
                <tr key={item.signatureId} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 px-3">
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      <Check className="w-2.5 h-2.5" /> VERIFIED
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-cyan-300 font-bold">{item.payload.actionType}</td>
                  <td className="py-2.5 px-3 text-white max-w-xs truncate">{item.payload.title}</td>
                  <td className="py-2.5 px-3 text-amber-300">{item.signerEmail}</td>
                  <td className="py-2.5 px-3 text-slate-400 truncate max-w-[130px]">{item.signatureId}</td>
                  <td className="py-2.5 px-3 text-slate-400">{new Date(item.signedAt).toLocaleTimeString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
