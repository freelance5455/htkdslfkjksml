import React, { useEffect, useMemo, useState } from 'react';
import {
  Check,
  Code2,
  Copy,
  Download,
  FileArchive,
  FileCode2,
  FolderCode,
  Search,
  Shield,
  Smartphone,
} from 'lucide-react';
import {
  apiRequest,
  downloadAppSourceArchive,
  downloadSingleSourceFile,
  downloadStudioSingleHtml,
  downloadWithAuth,
  formatBytes,
  formatDateTr,
} from '../lib/api';
import { SyntaxCodeBlock } from './SyntaxCodeBlock';

interface ExplorerBuildItem {
  id: string;
  project_id: string;
  project_name: string;
  app_name: string;
  package_name: string;
  version_name: string;
  version_code: number;
  status: string;
  build_mode: string;
  artifact_filename: string | null;
  artifact_size_bytes: number;
  sha256: string | null;
  owner_email: string;
  owner_username: string;
  created_at: string;
  completed_at: string | null;
}

interface ExplorerProjectItem {
  id: string;
  name: string;
  entry_file: string;
  package_name: string;
  version_name: string;
  owner_email: string;
  owner_username: string;
  updated_at: string;
  files: Array<{ path: string; size: number; isBinary: boolean }>;
}

interface ExplorerTreeResponse {
  builds: ExplorerBuildItem[];
  projects: ExplorerProjectItem[];
  platformFiles: Array<{ path: string; size: number; isBinary: boolean }>;
}

export const AdminCodeExplorer: React.FC = () => {
  const [tree, setTree] = useState<ExplorerTreeResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<'apks' | 'projects' | 'platform'>('apks');

  // Project & Android inspector state
  const [selectedProjectId, setSelectedProjectId] = useState<string>('');
  const [projectLayer, setProjectLayer] = useState<'web' | 'android'>('web');
  const [androidFiles, setAndroidFiles] = useState<
    Array<{ path: string; size: number; content: string }>
  >([]);
  const [loadingAndroid, setLoadingAndroid] = useState(false);

  // Code viewer state
  const [activeFilePath, setActiveFilePath] = useState('');
  const [activeContent, setActiveContent] = useState('');
  const [loadingFile, setLoadingFile] = useState(false);
  const [fileFilter, setFileFilter] = useState('');
  const [codeSearch, setCodeSearch] = useState('');
  const [copied, setCopied] = useState(false);
  const [downloadingZip, setDownloadingZip] = useState(false);

  const loadTree = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiRequest<ExplorerTreeResponse>('/api/admin/code-explorer/tree');
      setTree(res);
      if (res.projects.length > 0 && !selectedProjectId) {
        setSelectedProjectId(res.projects[0].id);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Kaynak ağacı yüklenemedi.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadTree();
  }, []);

  const selectedProject = useMemo(
    () => tree?.projects.find((p) => p.id === selectedProjectId) || null,
    [tree, selectedProjectId]
  );

  // Load Android generated files when switching to android layer or changing project
  useEffect(() => {
    if (tab !== 'projects' || !selectedProjectId) return;
    if (projectLayer === 'android') {
      void loadAndroidFiles(selectedProjectId);
    } else if (selectedProject && selectedProject.files.length > 0) {
      const first =
        selectedProject.files.find((f) => f.path === selectedProject.entry_file) ||
        selectedProject.files.find((f) => !f.isBinary) ||
        selectedProject.files[0];
      if (first) {
        void loadProjectFile(selectedProject.id, first.path);
      }
    }
  }, [tab, selectedProjectId, projectLayer]);

  // Load initial platform file when switching to platform tab
  useEffect(() => {
    if (tab !== 'platform' || !tree || tree.platformFiles.length === 0) return;
    const preferred =
      tree.platformFiles.find((f) => f.path === 'server/routes.ts') ||
      tree.platformFiles.find((f) => f.path === 'src/App.tsx') ||
      tree.platformFiles[0];
    if (preferred) {
      void loadPlatformFile(preferred.path);
    }
  }, [tab, tree]);

  const loadProjectFile = async (projectId: string, relPath: string) => {
    setActiveFilePath(relPath);
    setLoadingFile(true);
    setCopied(false);
    try {
      const res = await apiRequest<{ path: string; content: string }>(
        `/api/admin/code-explorer/project-file?projectId=${encodeURIComponent(
          projectId
        )}&path=${encodeURIComponent(relPath)}`
      );
      setActiveContent(res.content);
    } catch (err) {
      setActiveContent(err instanceof Error ? err.message : 'Dosya okunamadı.');
    } finally {
      setLoadingFile(false);
    }
  };

  const loadAndroidFiles = async (projectId: string) => {
    setLoadingAndroid(true);
    try {
      const res = await apiRequest<{
        files: Array<{ path: string; size: number; content: string }>;
      }>(`/api/admin/code-explorer/android-files?projectId=${encodeURIComponent(projectId)}`);
      setAndroidFiles(res.files);
      const first =
        res.files.find((f) => f.path.endsWith('MainActivity.kt')) ||
        res.files.find((f) => f.path.endsWith('AndroidManifest.xml')) ||
        res.files[0];
      if (first) {
        setActiveFilePath(first.path);
        setActiveContent(first.content);
      } else {
        setActiveFilePath('');
        setActiveContent('');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Android kaynak kodları yüklenemedi.');
    } finally {
      setLoadingAndroid(false);
    }
  };

  const loadPlatformFile = async (relPath: string) => {
    setActiveFilePath(relPath);
    setLoadingFile(true);
    setCopied(false);
    try {
      const res = await apiRequest<{ path: string; content: string }>(
        `/api/system/source-file?path=${encodeURIComponent(relPath)}`
      );
      setActiveContent(res.content);
    } catch (err) {
      setActiveContent(err instanceof Error ? err.message : 'Platform dosyası okunamadı.');
    } finally {
      setLoadingFile(false);
    }
  };

  const handleCopyCode = async () => {
    if (!activeContent) return;
    await navigator.clipboard.writeText(activeContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const handleDownloadActiveFile = async () => {
    if (!activeFilePath) return;
    try {
      if (tab === 'platform') {
        await downloadSingleSourceFile(activeFilePath);
      } else if (tab === 'projects' && selectedProjectId) {
        if (projectLayer === 'web') {
          await downloadWithAuth(
            `/api/admin/code-explorer/project-file?projectId=${encodeURIComponent(
              selectedProjectId
            )}&path=${encodeURIComponent(activeFilePath)}&download=1`,
            activeFilePath.split('/').pop() || 'file.txt'
          );
        } else {
          const blob = new Blob([activeContent], { type: 'text/plain;charset=utf-8' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = activeFilePath.split('/').pop() || 'android-source.txt';
          document.body.appendChild(a);
          a.click();
          a.remove();
          URL.revokeObjectURL(url);
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Dosya indirilemedi.');
    }
  };

  const handleDownloadZip = async () => {
    setDownloadingZip(true);
    setError(null);
    try {
      if (tab === 'projects' && selectedProjectId) {
        await downloadWithAuth(
          `/api/admin/code-explorer/project-zip?projectId=${encodeURIComponent(
            selectedProjectId
          )}`,
          `${selectedProject?.package_name || selectedProjectId}-android-source.zip`
        );
      } else {
        await downloadAppSourceArchive();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'ZIP arşivi indirilemedi.');
    } finally {
      setDownloadingZip(false);
    }
  };

  const filteredProjectFiles = useMemo(() => {
    const q = fileFilter.trim().toLowerCase();
    if (projectLayer === 'web') {
      const list = selectedProject?.files || [];
      return q ? list.filter((f) => f.path.toLowerCase().includes(q)) : list;
    }
    return q ? androidFiles.filter((f) => f.path.toLowerCase().includes(q)) : androidFiles;
  }, [selectedProject, androidFiles, projectLayer, fileFilter]);

  const filteredPlatformFiles = useMemo(() => {
    const list = tree?.platformFiles || [];
    const q = fileFilter.trim().toLowerCase();
    return q ? list.filter((f) => f.path.toLowerCase().includes(q)) : list;
  }, [tree, fileFilter]);

  return (
    <section className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl overflow-hidden">
      {/* Header */}
      <div className="px-6 py-5 border-b border-slate-200 dark:border-white/[0.08] flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#6366F1]/15 border border-[#6366F1]/30 flex items-center justify-center shrink-0">
            <Shield className="w-5 h-5 text-[#6366F1]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-900 dark:text-[#F8FAFC]">
                Kaynak Kodları ve Oluşturulan Dosyalar
              </h2>
              <span className="text-[11px] font-semibold text-[#CA8A04] dark:text-[#EAB308]">
                Yalnızca Yönetici
              </span>
            </div>
            <p className="mt-1 text-xs text-slate-600 dark:text-[#94A3B8]">
              Üretilen tüm APK dosyalarını, sürümlerini, kullanıcı projelerinin HTML/CSS/JS
              kaynaklarını, üretilen Kotlin/Manifest/Gradle kodlarını ve platform kaynaklarını
              yetkili olarak inceleyin.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            disabled={downloadingZip}
            onClick={() => void handleDownloadZip()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl bg-[#6366F1] hover:bg-[#5558E3] disabled:opacity-50 text-white transition-colors whitespace-nowrap shrink-0"
          >
            <FileArchive className="w-3.5 h-3.5" />
            <span>
              {downloadingZip
                ? 'Hazırlanıyor...'
                : tab === 'projects'
                ? 'Proje Android ZIP İndir'
                : 'Platform Kaynak ZIP İndir'}
            </span>
          </button>
          <button
            type="button"
            onClick={() => void downloadStudioSingleHtml()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-xl border border-slate-200 dark:border-white/[0.1] bg-slate-50 dark:bg-[#111827] hover:bg-slate-100 dark:hover:bg-white/[0.06] text-slate-700 dark:text-[#F8FAFC] transition-colors whitespace-nowrap shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Tek Dosya .HTML</span>
          </button>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="px-6 py-3 border-b border-slate-200 dark:border-white/[0.08] bg-slate-50 dark:bg-[#111827] flex flex-wrap items-center justify-between gap-3">
        <div className="inline-flex p-1 rounded-xl bg-white dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.08]">
          <button
            type="button"
            onClick={() => setTab('apks')}
            className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              tab === 'apks'
                ? 'bg-[#6366F1] text-white'
                : 'text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Oluşturulan APK Dosyaları ({tree?.builds.length || 0})</span>
          </button>
          <button
            type="button"
            onClick={() => setTab('projects')}
            className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              tab === 'projects'
                ? 'bg-[#6366F1] text-white'
                : 'text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <FolderCode className="w-3.5 h-3.5" />
            <span>Proje & Android Kaynakları ({tree?.projects.length || 0})</span>
          </button>
          <button
            type="button"
            onClick={() => setTab('platform')}
            className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              tab === 'platform'
                ? 'bg-[#6366F1] text-white'
                : 'text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>Platform Kaynak Kodları ({tree?.platformFiles.length || 0})</span>
          </button>
        </div>

        {tab === 'projects' && tree && tree.projects.length > 0 && (
          <div className="flex flex-wrap items-center gap-2">
            <select
              value={selectedProjectId}
              onChange={(e) => setSelectedProjectId(e.target.value)}
              className="bg-white dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-[#F8FAFC]"
            >
              {tree.projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.owner_email})
                </option>
              ))}
            </select>

            <div className="inline-flex p-0.5 rounded-lg bg-white dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.08]">
              <button
                type="button"
                onClick={() => setProjectLayer('web')}
                className={`px-2.5 py-1 text-[11px] font-medium rounded-md whitespace-nowrap ${
                  projectLayer === 'web'
                    ? 'bg-[#3B82F6] text-white'
                    : 'text-slate-600 dark:text-[#94A3B8]'
                }`}
              >
                HTML / CSS / JS
              </button>
              <button
                type="button"
                onClick={() => setProjectLayer('android')}
                className={`px-2.5 py-1 text-[11px] font-medium rounded-md whitespace-nowrap ${
                  projectLayer === 'android'
                    ? 'bg-[#3B82F6] text-white'
                    : 'text-slate-600 dark:text-[#94A3B8]'
                }`}
              >
                Kotlin / Manifest / Gradle
              </button>
            </div>
          </div>
        )}
      </div>

      {error && (
        <div className="px-6 py-3 bg-red-500/10 border-b border-red-500/20 text-xs text-red-600 dark:text-red-300">
          {error}
        </div>
      )}

      {loading ? (
        <div className="p-8 text-xs text-slate-500 dark:text-[#94A3B8]">
          Yönetici kaynak ağacı yükleniyor...
        </div>
      ) : tab === 'apks' ? (
        <div className="overflow-x-auto">
          {!tree || tree.builds.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500 dark:text-[#94A3B8]">
              Henüz oluşturulmuş APK veya derleme çıktısı yok.
            </div>
          ) : (
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-white/[0.08] text-slate-500 dark:text-[#94A3B8]">
                  <th className="py-3 px-6">Uygulama / Paket</th>
                  <th className="py-3 px-4">Sahip</th>
                  <th className="py-3 px-4">Sürüm</th>
                  <th className="py-3 px-4">Durum</th>
                  <th className="py-3 px-4">SHA-256</th>
                  <th className="py-3 px-4 text-right">Boyut</th>
                  <th className="py-3 px-4 text-right">Tarih</th>
                  <th className="py-3 px-6 text-right">İndir</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-white/[0.06]">
                {tree.builds.map((b) => {
                  const hasArtifact =
                    Boolean(b.artifact_filename) &&
                    (b.status === 'completed_apk' || b.status === 'completed_bundle');
                  return (
                    <tr
                      key={b.id}
                      className="hover:bg-slate-50 dark:hover:bg-white/[0.02] transition-colors"
                    >
                      <td className="py-3.5 px-6">
                        <div className="font-semibold text-slate-900 dark:text-[#F8FAFC]">
                          {b.app_name || b.project_name}
                        </div>
                        <div className="font-mono text-[11px] text-slate-500 dark:text-[#94A3B8]">
                          {b.package_name}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-slate-700 dark:text-[#CBD5E1]">
                        <div>{b.owner_username}</div>
                        <div className="text-[11px] text-slate-500 dark:text-[#94A3B8]">
                          {b.owner_email}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 font-mono tabular-nums text-slate-700 dark:text-[#CBD5E1]">
                        v{b.version_name} ({b.version_code})
                      </td>
                      <td className="py-3.5 px-4">
                        <span
                          className={`font-medium ${
                            b.status === 'completed_apk'
                              ? 'text-[#22C55E]'
                              : b.status === 'completed_bundle'
                              ? 'text-[#3B82F6]'
                              : b.status === 'failed'
                              ? 'text-[#EF4444]'
                              : 'text-amber-500'
                          }`}
                        >
                          {b.status === 'completed_apk'
                            ? 'İmzalı APK'
                            : b.status === 'completed_bundle'
                            ? 'Gradle Paketi'
                            : b.status === 'failed'
                            ? 'Başarısız'
                            : b.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 font-mono text-[11px] text-slate-500 dark:text-[#94A3B8]">
                        {b.sha256 ? `${b.sha256.slice(0, 14)}…` : '—'}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono tabular-nums text-slate-700 dark:text-[#CBD5E1]">
                        {b.artifact_size_bytes ? formatBytes(b.artifact_size_bytes) : '—'}
                      </td>
                      <td className="py-3.5 px-4 text-right tabular-nums text-slate-500 dark:text-[#94A3B8] whitespace-nowrap">
                        {formatDateTr(b.completed_at || b.created_at)}
                      </td>
                      <td className="py-3.5 px-6 text-right">
                        {hasArtifact ? (
                          <button
                            type="button"
                            onClick={() =>
                              void downloadWithAuth(
                                `/api/admin/builds/${b.id}/download`,
                                b.artifact_filename || `${b.id}.apk`
                              )
                            }
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#6366F1] hover:bg-[#5558E3] text-white text-[11px] font-semibold whitespace-nowrap"
                          >
                            <Download className="w-3 h-3" />
                            <span>İndir</span>
                          </button>
                        ) : (
                          <span className="text-slate-400 dark:text-slate-600">—</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-12 min-h-[500px]">
          {/* Left File Tree */}
          <div className="md:col-span-4 border-b md:border-b-0 md:border-r border-slate-200 dark:border-white/[0.08] bg-slate-50 dark:bg-[#111827] flex flex-col">
            <div className="p-3 border-b border-slate-200 dark:border-white/[0.08]">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={fileFilter}
                  onChange={(e) => setFileFilter(e.target.value)}
                  placeholder="Dosya ağacında ara..."
                  className="w-full bg-white dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-900 dark:text-[#F8FAFC] placeholder:text-slate-400 focus:outline-none focus:border-[#6366F1]"
                />
              </div>
            </div>

            <div className="flex-1 max-h-[460px] overflow-y-auto p-2.5 space-y-1">
              {tab === 'projects' && loadingAndroid && projectLayer === 'android' ? (
                <div className="p-3 text-xs text-slate-500 dark:text-[#94A3B8]">
                  Kotlin & Gradle dosyaları üretiliyor...
                </div>
              ) : tab === 'projects' ? (
                filteredProjectFiles.map((f) => {
                  const isActive = activeFilePath === f.path;
                  return (
                    <button
                      key={f.path}
                      type="button"
                      onClick={() => {
                        if (projectLayer === 'web' && selectedProjectId) {
                          void loadProjectFile(selectedProjectId, f.path);
                        } else if ('content' in f) {
                          setActiveFilePath(f.path);
                          setActiveContent(f.content);
                          setCopied(false);
                        }
                      }}
                      className={`w-full flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-lg text-xs text-left transition-colors ${
                        isActive
                          ? 'bg-[#6366F1] text-white'
                          : 'text-slate-700 dark:text-[#CBD5E1] hover:bg-slate-200/70 dark:hover:bg-white/[0.04]'
                      }`}
                    >
                      <span className="inline-flex items-center gap-2 truncate font-mono">
                        <FileCode2 className="w-3.5 h-3.5 shrink-0 opacity-75" />
                        <span className="truncate">{f.path}</span>
                      </span>
                      <span className="text-[10px] opacity-75 tabular-nums shrink-0">
                        {formatBytes(f.size)}
                      </span>
                    </button>
                  );
                })
              ) : (
                filteredPlatformFiles.map((f) => {
                  const isActive = activeFilePath === f.path;
                  return (
                    <button
                      key={f.path}
                      type="button"
                      onClick={() => void loadPlatformFile(f.path)}
                      className={`w-full flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-lg text-xs text-left transition-colors ${
                        isActive
                          ? 'bg-[#6366F1] text-white'
                          : 'text-slate-700 dark:text-[#CBD5E1] hover:bg-slate-200/70 dark:hover:bg-white/[0.04]'
                      }`}
                    >
                      <span className="inline-flex items-center gap-2 truncate font-mono">
                        <FileCode2 className="w-3.5 h-3.5 shrink-0 opacity-75" />
                        <span className="truncate">{f.path}</span>
                      </span>
                      <span className="text-[10px] opacity-75 tabular-nums shrink-0">
                        {formatBytes(f.size)}
                      </span>
                    </button>
                  );
                })
              )}
            </div>
          </div>

          {/* Right Code Viewer with Syntax Highlighting & Search */}
          <div className="md:col-span-8 flex flex-col bg-white dark:bg-[#0B1020]">
            <div className="px-4 py-2.5 border-b border-slate-200 dark:border-white/[0.08] bg-slate-50 dark:bg-[#111827] flex flex-wrap items-center justify-between gap-3">
              <span className="text-xs font-mono text-slate-700 dark:text-[#F8FAFC] truncate">
                {activeFilePath || 'Dosya seçilmedi'}
              </span>

              <div className="flex flex-wrap items-center gap-2">
                <div className="relative">
                  <Search className="w-3 h-3 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={codeSearch}
                    onChange={(e) => setCodeSearch(e.target.value)}
                    placeholder="Kod içinde bul..."
                    className="w-40 bg-white dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-lg pl-7 pr-2.5 py-1 text-xs text-slate-900 dark:text-[#F8FAFC] focus:outline-none focus:border-[#6366F1]"
                  />
                </div>
                <button
                  type="button"
                  disabled={!activeContent}
                  onClick={() => void handleCopyCode()}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-lg border border-slate-200 dark:border-white/[0.1] bg-white dark:bg-[#151D2E] text-slate-700 dark:text-[#F8FAFC] hover:bg-slate-100 dark:hover:bg-white/[0.08] whitespace-nowrap"
                >
                  {copied ? (
                    <Check className="w-3.5 h-3.5 text-[#22C55E]" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  <span>{copied ? 'Kopyalandı' : 'Kopyala'}</span>
                </button>
                <button
                  type="button"
                  disabled={!activeFilePath}
                  onClick={() => void handleDownloadActiveFile()}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-lg bg-[#6366F1] hover:bg-[#5558E3] disabled:opacity-50 text-white whitespace-nowrap"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>İndir</span>
                </button>
              </div>
            </div>

            <div className="flex-1 max-h-[460px] overflow-auto py-3">
              {loadingFile ? (
                <div className="p-6 text-xs text-slate-500 dark:text-[#94A3B8]">
                  Dosya yükleniyor...
                </div>
              ) : activeContent ? (
                <SyntaxCodeBlock
                  code={activeContent}
                  filePath={activeFilePath}
                  searchQuery={codeSearch}
                />
              ) : (
                <div className="p-8 text-center text-xs text-slate-500 dark:text-[#94A3B8]">
                  İncelemek için sol ağaçtan bir dosya seçin.
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
