import React, { useState, useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { 
  Globe2, 
  Flame, 
  Sparkles, 
  HeartHandshake, 
  Users, 
  Clock, 
  Radio, 
  RefreshCw, 
  Activity,
  Layers,
  CheckCircle2,
  Share2
} from 'lucide-react';
import { GlobalPrayerTimezoneNode } from '../types';

interface GlobalPrayerHeatmapProps {
  onShowToast?: (msg: string) => void;
  onJoinPrayerCircle?: () => void;
}

const GLOBAL_PRAYER_NODES: GlobalPrayerTimezoneNode[] = [
  {
    id: 'node-lagos',
    city: 'Lagos',
    country: 'Nigeria',
    timezone: 'WAT (UTC+1)',
    utcOffset: 1,
    latitude: 6.5244,
    longitude: 3.3792,
    activeIntercessors: 4280,
    prayerIntensity: 98,
    prayerFocus: 'Breakthrough',
    localTimeFormatted: '19:49 WAT',
    activeWave: 'Prophetic Fire'
  },
  {
    id: 'node-london',
    city: 'London',
    country: 'United Kingdom',
    timezone: 'GMT (UTC+0)',
    utcOffset: 0,
    latitude: 51.5074,
    longitude: -0.1278,
    activeIntercessors: 1890,
    prayerIntensity: 85,
    prayerFocus: 'Sovereign Peace',
    localTimeFormatted: '18:49 GMT',
    activeWave: 'Twilight Watch'
  },
  {
    id: 'node-newyork',
    city: 'New York',
    country: 'United States',
    timezone: 'EDT (UTC-4)',
    utcOffset: -4,
    latitude: 40.7128,
    longitude: -74.006,
    activeIntercessors: 2650,
    prayerIntensity: 92,
    prayerFocus: 'Healing',
    localTimeFormatted: '14:49 EDT',
    activeWave: 'Noon Altar'
  },
  {
    id: 'node-losangeles',
    city: 'Los Angeles',
    country: 'United States',
    timezone: 'PDT (UTC-7)',
    utcOffset: -7,
    latitude: 34.0522,
    longitude: -118.2437,
    activeIntercessors: 1420,
    prayerIntensity: 80,
    prayerFocus: 'Family Restoration',
    localTimeFormatted: '11:49 PDT',
    activeWave: 'Dawn Glory'
  },
  {
    id: 'node-johannesburg',
    city: 'Johannesburg',
    country: 'South Africa',
    timezone: 'SAST (UTC+2)',
    utcOffset: 2,
    latitude: -26.2041,
    longitude: 28.0473,
    activeIntercessors: 2150,
    prayerIntensity: 88,
    prayerFocus: 'Global Revival',
    localTimeFormatted: '20:49 SAST',
    activeWave: 'Midnight Soaking'
  },
  {
    id: 'node-nairobi',
    city: 'Nairobi',
    country: 'Kenya',
    timezone: 'EAT (UTC+3)',
    utcOffset: 3,
    latitude: -1.2921,
    longitude: 36.8219,
    activeIntercessors: 1980,
    prayerIntensity: 91,
    prayerFocus: 'Breakthrough',
    localTimeFormatted: '21:49 EAT',
    activeWave: 'Prophetic Fire'
  },
  {
    id: 'node-dubai',
    city: 'Dubai',
    country: 'United Arab Emirates',
    timezone: 'GST (UTC+4)',
    utcOffset: 4,
    latitude: 25.2048,
    longitude: 55.2708,
    activeIntercessors: 870,
    prayerIntensity: 75,
    prayerFocus: 'Sovereign Peace',
    localTimeFormatted: '22:49 GST',
    activeWave: 'Midnight Soaking'
  },
  {
    id: 'node-singapore',
    city: 'Singapore',
    country: 'Singapore',
    timezone: 'SGT (UTC+8)',
    utcOffset: 8,
    latitude: 1.3521,
    longitude: 103.8198,
    activeIntercessors: 1140,
    prayerIntensity: 79,
    prayerFocus: 'Global Revival',
    localTimeFormatted: '02:49 SGT (+1)',
    activeWave: 'Midnight Soaking'
  },
  {
    id: 'node-tokyo',
    city: 'Tokyo',
    country: 'Japan',
    timezone: 'JST (UTC+9)',
    utcOffset: 9,
    latitude: 35.6762,
    longitude: 139.6503,
    activeIntercessors: 760,
    prayerIntensity: 72,
    prayerFocus: 'Healing',
    localTimeFormatted: '03:49 JST (+1)',
    activeWave: 'Midnight Soaking'
  },
  {
    id: 'node-sydney',
    city: 'Sydney',
    country: 'Australia',
    timezone: 'AEST (UTC+10)',
    utcOffset: 10,
    latitude: -33.8688,
    longitude: 151.2093,
    activeIntercessors: 940,
    prayerIntensity: 78,
    prayerFocus: 'Global Revival',
    localTimeFormatted: '04:49 AEST (+1)',
    activeWave: 'Dawn Glory'
  },
  {
    id: 'node-saopaulo',
    city: 'São Paulo',
    country: 'Brazil',
    timezone: 'BRT (UTC-3)',
    utcOffset: -3,
    latitude: -23.5505,
    longitude: -46.6333,
    activeIntercessors: 1620,
    prayerIntensity: 86,
    prayerFocus: 'Deliverance',
    localTimeFormatted: '15:49 BRT',
    activeWave: 'Noon Altar'
  },
  {
    id: 'node-jerusalem',
    city: 'Jerusalem',
    country: 'Israel',
    timezone: 'IDT (UTC+3)',
    utcOffset: 3,
    latitude: 31.7683,
    longitude: 35.2137,
    activeIntercessors: 3100,
    prayerIntensity: 96,
    prayerFocus: 'Sovereign Peace',
    localTimeFormatted: '21:49 IDT',
    activeWave: 'Prophetic Fire'
  }
];

export const GlobalPrayerHeatmap: React.FC<GlobalPrayerHeatmapProps> = ({ onShowToast, onJoinPrayerCircle }) => {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  
  const [nodes, setNodes] = useState<GlobalPrayerTimezoneNode[]>(GLOBAL_PRAYER_NODES);
  const [selectedNode, setSelectedNode] = useState<GlobalPrayerTimezoneNode | null>(GLOBAL_PRAYER_NODES[0]);
  const [hasBroadcasted, setHasBroadcasted] = useState<boolean>(false);
  const [filterWave, setFilterWave] = useState<string>('ALL');

  const totalIntercessors = nodes.reduce((sum, n) => sum + n.activeIntercessors, 0);
  const averageIntensity = (nodes.reduce((sum, n) => sum + n.prayerIntensity, 0) / nodes.length).toFixed(1);

  // User joins live prayer pulse
  const handleBroadcastPulse = () => {
    setHasBroadcasted(true);
    setNodes(prev => prev.map(n => {
      if (n.city === 'Lagos' || n.city === 'London' || n.city === 'Jerusalem') {
        return {
          ...n,
          activeIntercessors: n.activeIntercessors + 12,
          prayerIntensity: Math.min(100, n.prayerIntensity + 2)
        };
      }
      return {
        ...n,
        activeIntercessors: n.activeIntercessors + 1
      };
    }));

    if (onShowToast) {
      onShowToast('🕊️ Your Prayer Pulse broadcasted to the Global Altar! Spiritual alignment synced.');
    }
    if (onJoinPrayerCircle) {
      onJoinPrayerCircle();
    }
  };

  // D3 Visualization Render
  useEffect(() => {
    if (!svgRef.current || !containerRef.current) return;

    const containerWidth = containerRef.current.clientWidth || 800;
    const width = containerWidth;
    const height = 400;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    svg.attr('viewBox', `0 0 ${width} ${height}`);

    // Create defs for gradients and glow filters
    const defs = svg.append('defs');

    // Glow filter
    const filter = defs.append('filter')
      .attr('id', 'prayer-glow')
      .attr('x', '-50%')
      .attr('y', '-50%')
      .attr('width', '200%')
      .attr('height', '200%');

    filter.append('feGaussianBlur')
      .attr('stdDeviation', '6')
      .attr('result', 'coloredBlur');

    const feMerge = filter.append('feMerge');
    feMerge.append('feMergeNode').attr('in', 'coloredBlur');
    feMerge.append('feMergeNode').attr('in', 'SourceGraphic');

    // Background Map Graticule / Grid
    const g = svg.append('g').attr('class', 'map-g');

    // Equirectangular / Cylindrical Projection Setup
    const xScale = d3.scaleLinear()
      .domain([-180, 180])
      .range([40, width - 40]);

    const yScale = d3.scaleLinear()
      .domain([-60, 75])
      .range([height - 40, 40]);

    // Draw Longitude Grid lines (Timezone Meridians)
    const longitudes = [-120, -90, -60, -30, 0, 30, 60, 90, 120, 150];
    g.selectAll('.meridian')
      .data(longitudes)
      .enter()
      .append('line')
      .attr('class', 'meridian')
      .attr('x1', d => xScale(d))
      .attr('y1', 30)
      .attr('x2', d => xScale(d))
      .attr('y2', height - 30)
      .attr('stroke', '#3b82f6')
      .attr('stroke-opacity', 0.12)
      .attr('stroke-dasharray', '3,4');

    // Draw Latitude parallels (Equator, Tropics)
    const latitudes = [-30, 0, 30, 60];
    g.selectAll('.parallel')
      .data(latitudes)
      .enter()
      .append('line')
      .attr('class', 'parallel')
      .attr('x1', 30)
      .attr('y1', d => yScale(d))
      .attr('x2', width - 30)
      .attr('y2', d => yScale(d))
      .attr('stroke', '#f59e0b')
      .attr('stroke-opacity', d => d === 0 ? 0.25 : 0.08)
      .attr('stroke-width', d => d === 0 ? 1.5 : 1);

    // Draw Connecting Spiritual Wave Arcs between Nodes
    const connectionPairs = [
      ['Lagos', 'London'],
      ['Lagos', 'Jerusalem'],
      ['Lagos', 'Johannesburg'],
      ['London', 'New York'],
      ['New York', 'Los Angeles'],
      ['New York', 'São Paulo'],
      ['Jerusalem', 'Dubai'],
      ['Dubai', 'Singapore'],
      ['Singapore', 'Tokyo'],
      ['Tokyo', 'Sydney'],
      ['Nairobi', 'Lagos']
    ];

    connectionPairs.forEach(([city1, city2]) => {
      const node1 = nodes.find(n => n.city === city1);
      const node2 = nodes.find(n => n.city === city2);
      if (node1 && node2) {
        const x1 = xScale(node1.longitude);
        const y1 = yScale(node1.latitude);
        const x2 = xScale(node2.longitude);
        const y2 = yScale(node2.latitude);

        const dx = x2 - x1;
        const dy = y2 - y1;
        const dr = Math.sqrt(dx * dx + dy * dy) * 1.2;

        g.append('path')
          .attr('d', `M${x1},${y1}A${dr},${dr} 0 0,1 ${x2},${y2}`)
          .attr('fill', 'none')
          .attr('stroke', 'url(#arc-gradient)')
          .attr('stroke', '#f59e0b')
          .attr('stroke-opacity', 0.28)
          .attr('stroke-width', 1.2)
          .attr('stroke-dasharray', '4,4');
      }
    });

    // Draw Heatmap Nodes
    const nodeGroups = g.selectAll<SVGGElement, GlobalPrayerTimezoneNode>('.prayer-node')
      .data(nodes)
      .enter()
      .append('g')
      .attr('class', 'prayer-node')
      .attr('transform', (d: GlobalPrayerTimezoneNode) => `translate(${xScale(d.longitude)}, ${yScale(d.latitude)})`)
      .style('cursor', 'pointer')
      .on('click', (_, d: GlobalPrayerTimezoneNode) => {
        setSelectedNode(d);
      });

    // Pulsing Outer Ripple Animation Ring
    nodeGroups.append('circle')
      .attr('r', (d: GlobalPrayerTimezoneNode) => (d.prayerIntensity / 100) * 18 + 4)
      .attr('fill', (d: GlobalPrayerTimezoneNode) => d.prayerIntensity > 90 ? '#f59e0b' : '#38bdf8')
      .attr('fill-opacity', 0.15)
      .attr('filter', 'url(#prayer-glow)')
      .append('animate')
      .attr('attributeName', 'r')
      .attr('values', (d: GlobalPrayerTimezoneNode) => `${(d.prayerIntensity / 100) * 10};${(d.prayerIntensity / 100) * 26};${(d.prayerIntensity / 100) * 10}`)
      .attr('dur', (d: GlobalPrayerTimezoneNode) => `${3 - (d.prayerIntensity / 100)}s`)
      .attr('repeatCount', 'indefinite');

    // Inner Glowing Core Circle
    nodeGroups.append('circle')
      .attr('r', (d: GlobalPrayerTimezoneNode) => (d.prayerIntensity / 100) * 8 + 3)
      .attr('fill', (d: GlobalPrayerTimezoneNode) => d.prayerIntensity > 90 ? '#fbbf24' : '#0ea5e9')
      .attr('stroke', '#ffffff')
      .attr('stroke-width', 1.5)
      .attr('filter', 'url(#prayer-glow)');

    // City Label
    nodeGroups.append('text')
      .attr('y', -12)
      .attr('text-anchor', 'middle')
      .attr('fill', '#fde68a')
      .attr('font-size', '10px')
      .attr('font-weight', 'bold')
      .attr('font-family', 'sans-serif')
      .text((d: GlobalPrayerTimezoneNode) => d.city);

    // Active Intercessors Count Sub-Label
    nodeGroups.append('text')
      .attr('y', 18)
      .attr('text-anchor', 'middle')
      .attr('fill', '#93c5fd')
      .attr('font-size', '9px')
      .attr('font-family', 'monospace')
      .text((d: GlobalPrayerTimezoneNode) => `${d.activeIntercessors.toLocaleString()} 🙏`);

  }, [nodes]);

  return (
    <div className="bg-slate-900/90 border-2 border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 text-slate-100 relative overflow-hidden">
      {/* Ambience Background */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-amber-500/20 pb-6">
        <div className="space-y-1.5">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-black uppercase tracking-wider">
            <Globe2 className="w-4 h-4 text-amber-400" />
            <span>D3.JS GLOBAL PRAYER PARTICIPATION HEATMAP</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold font-serif text-amber-100">
            Worldwide Intercessory Alignment & Prayer Timezones
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
            Real-time visualization of believers standing in agreement across 12 global time zones. Experience synchronized prayer harmony and corporate prophetic breakthrough.
          </p>
        </div>

        {/* Global Stats Matrix */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="px-4 py-3 rounded-2xl bg-slate-950/80 border border-amber-500/30 flex items-center space-x-3 shadow-lg">
            <div className="text-right">
              <div className="text-[10px] text-amber-400/80 uppercase font-mono font-bold">TOTAL INTERCESSORS</div>
              <div className="text-2xl font-black text-amber-300 font-mono">
                {totalIntercessors.toLocaleString()}
              </div>
            </div>
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 flex items-center justify-center text-amber-400">
              <Users className="w-6 h-6" />
            </div>
          </div>

          <button
            onClick={handleBroadcastPulse}
            className={`px-5 py-3.5 rounded-2xl font-black text-xs flex items-center space-x-2 shadow-xl transition-all hover:scale-105 ${
              hasBroadcasted
                ? 'bg-emerald-500 text-slate-950 shadow-emerald-500/30'
                : 'bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-500 text-slate-950 shadow-amber-500/20'
            }`}
          >
            <Sparkles className="w-4 h-4 text-slate-950 animate-spin-slow" />
            <span>{hasBroadcasted ? '✓ PRAYER PULSE ACTIVE' : 'BROADCAST MY PRAYER PULSE'}</span>
          </button>
        </div>
      </div>

      {/* D3 Heatmap Stage */}
      <div ref={containerRef} className="bg-slate-950/90 border-2 border-amber-500/20 rounded-3xl p-4 shadow-inner relative">
        <div className="flex items-center justify-between px-3 py-1.5 text-xs text-slate-400 border-b border-slate-800">
          <div className="flex items-center space-x-2 font-mono">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-emerald-400 font-bold">LIVE TELEMETRY STREAM</span>
            <span>• 99.8% Global Coherence Index</span>
          </div>
          <span className="text-[11px] font-mono text-amber-300/80 hidden sm:inline">
            Click any pulsating node to inspect time zone intercession
          </span>
        </div>

        <svg ref={svgRef} className="w-full h-80 sm:h-96" />
      </div>

      {/* Selected Timezone Node Detail Bar & Prayer Wave Pills */}
      {selectedNode && (
        <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-amber-950/50 border border-amber-500/40 p-5 rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 animate-fadeIn">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className="text-sm font-bold text-amber-300 font-serif">
                📍 {selectedNode.city}, {selectedNode.country}
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono font-bold">
                {selectedNode.timezone}
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-mono font-bold">
                🌊 {selectedNode.activeWave}
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Active Intercessory Focus: <strong className="text-amber-200">{selectedNode.prayerFocus}</strong> • Local Time: <span className="font-mono text-amber-300">{selectedNode.localTimeFormatted}</span>
            </p>
          </div>

          <div className="flex items-center space-x-4">
            <div className="text-right">
              <div className="text-[10px] text-slate-400 uppercase font-mono">Prayer Intensity</div>
              <div className="text-lg font-black text-amber-400 font-mono">{selectedNode.prayerIntensity}% Intensity</div>
            </div>

            <button
              onClick={() => {
                if (onShowToast) onShowToast(`Joined intercessory circle in ${selectedNode.city}! Standing in agreement for ${selectedNode.prayerFocus}.`);
              }}
              className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition-all flex items-center space-x-1.5"
            >
              <HeartHandshake className="w-4 h-4" />
              <span>Stand in Agreement</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
