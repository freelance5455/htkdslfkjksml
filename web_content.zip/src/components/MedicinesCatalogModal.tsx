import React, { useState, useEffect, useRef } from 'react';
import {
  Barcode,
  Plus,
  Search,
  Camera,
  Check,
  X,
  Edit3,
  Package,
  Sparkles,
  Layers,
  AlertTriangle,
  Wand2,
  CheckCircle2,
} from 'lucide-react';
import type { MedicineItem, MedicineStock, PurchaseItem, SaleItem } from '../types/pharmacy.ts';
import { formatIQD } from '../utils/calculations.ts';
import { parseAndNormalizeBarcode, findMatchingBarcodeKey } from '../utils/barcodeUtils.ts';

interface MedicinesCatalogModalProps {
  isOpen: boolean;
  onClose: () => void;
  medicines: MedicineItem[];
  stocks: Record<string, MedicineStock>;
  purchases: PurchaseItem[];
  sales: SaleItem[];
  onSaveMedicine: (med: {
    barcode: string;
    name: string;
    scientificName?: string;
    unit: string;
    minStockAlert: number;
  }) => void;
  onOpenScanner: (cb: (code: string) => void) => void;
  initialBarcode?: string | null;
  onClearInitialBarcode?: () => void;
}

const UNITS = ['باكيت', 'علبة', 'شريط', 'قارورة', 'كرتونة', 'قطعة', 'أمبولة', 'فيال'];

export const MedicinesCatalogModal: React.FC<MedicinesCatalogModalProps> = ({
  isOpen,
  onClose,
  medicines,
  stocks,
  purchases,
  sales,
  onSaveMedicine,
  onOpenScanner,
  initialBarcode,
  onClearInitialBarcode,
}) => {
  const [barcode, setBarcode] = useState('');
  const [name, setName] = useState('');
  const [scientificName, setScientificName] = useState('');
  const [unit, setUnit] = useState('باكيت');
  const [minStockAlert, setMinStockAlert] = useState('15');
  const [searchQuery, setSearchQuery] = useState('');
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [isEditingExisting, setIsEditingExisting] = useState(false);

  const nameInputRef = useRef<HTMLInputElement>(null);
  const barcodeInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!isOpen) return;
    if (initialBarcode) {
      handleBarcodeLookup(initialBarcode);
      if (onClearInitialBarcode) onClearInitialBarcode();
      setTimeout(() => {
        nameInputRef.current?.focus();
      }, 120);
    }
  }, [isOpen, initialBarcode]);

  // Whenever barcode changes, check if it already exists in medicines or stocks
  const handleBarcodeLookup = (code: string) => {
    const parsed = parseAndNormalizeBarcode(code);
    const normalized = parsed.normalizedBarcode || code.trim();
    setBarcode(normalized);
    if (!normalized) {
      setIsEditingExisting(false);
      return;
    }
    const matchedKey = findMatchingBarcodeKey(normalized, medicines, stocks);
    const existing = medicines.find((m) => m.barcode === (matchedKey || normalized));
    const stockItem = stocks[matchedKey || normalized];
    if (existing) {
      setBarcode(existing.barcode);
      setName(existing.name);
      setScientificName(existing.scientificName || '');
      setUnit(existing.unit || 'باكيت');
      setMinStockAlert(String(existing.minStockAlert ?? 15));
      setIsEditingExisting(true);
    } else if (stockItem) {
      setBarcode(stockItem.barcode);
      setName(stockItem.name);
      setUnit(stockItem.unit || 'باكيت');
      setMinStockAlert(String(stockItem.minStockAlert ?? 15));
      setIsEditingExisting(true);
    } else {
      setName('');
      setScientificName('');
      setIsEditingExisting(false);
    }
  };

  const handleGenerateBarcode = () => {
    const randomCode = `629${Math.floor(1000000000 + Math.random() * 9000000000)}`;
    handleBarcodeLookup(randomCode);
    setTimeout(() => {
      nameInputRef.current?.focus();
    }, 50);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseAndNormalizeBarcode(barcode);
    const finalBarcode =
      parsed.normalizedBarcode || `629${Math.floor(1000000000 + Math.random() * 9000000000)}`;
    if (!name.trim()) return;

    onSaveMedicine({
      barcode: finalBarcode,
      name: name.trim(),
      scientificName: scientificName.trim() || undefined,
      unit: unit || 'باكيت',
      minStockAlert: Math.max(0, parseInt(minStockAlert, 10) || 10),
    });

    setToastMsg(
      isEditingExisting
        ? `تم تحديث بيانات "${name.trim()}" بنجاح!`
        : `تم حفظ "${name.trim()}" في النظام! يمكنك الآن مسح باركوده مباشرة بأي فاتورة.`
    );
    setTimeout(() => setToastMsg(null), 3200);

    // Clear form for next rapid entry
    setBarcode('');
    setName('');
    setScientificName('');
    setUnit('باكيت');
    setMinStockAlert('15');
    setIsEditingExisting(false);
    barcodeInputRef.current?.focus();
  };

  // Merge medicines catalog + any items in stocks
  const allCatalogItems = React.useMemo(() => {
    const map = new Map<
      string,
      {
        barcode: string;
        name: string;
        scientificName?: string;
        unit: string;
        minStockAlert: number;
        remaining: number;
        lastPurchasePrice: number;
        lastSalePrice: number;
      }
    >();

    for (const m of medicines) {
      const st = stocks[m.barcode];
      const lastP = purchases.find((p) => p.barcode === m.barcode);
      const lastS = sales.find((s) => s.barcode === m.barcode);
      map.set(m.barcode, {
        barcode: m.barcode,
        name: m.name,
        scientificName: m.scientificName,
        unit: m.unit || 'باكيت',
        minStockAlert: m.minStockAlert ?? 10,
        remaining: st?.remaining ?? 0,
        lastPurchasePrice: lastP?.unitPrice ?? st?.averageCost ?? 0,
        lastSalePrice: lastS?.unitPrice ?? 0,
      });
    }

    for (const st of Object.values(stocks)) {
      if (!map.has(st.barcode)) {
        const lastP = purchases.find((p) => p.barcode === st.barcode);
        const lastS = sales.find((s) => s.barcode === st.barcode);
        map.set(st.barcode, {
          barcode: st.barcode,
          name: st.name,
          unit: st.unit || 'باكيت',
          minStockAlert: st.minStockAlert ?? 10,
          remaining: st.remaining,
          lastPurchasePrice: lastP?.unitPrice ?? st.averageCost ?? 0,
          lastSalePrice: lastS?.unitPrice ?? 0,
        });
      }
    }

    return Array.from(map.values()).filter((item) => {
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      return (
        item.name.toLowerCase().includes(q) ||
        item.barcode.toLowerCase().includes(q) ||
        (item.scientificName && item.scientificName.toLowerCase().includes(q))
      );
    });
  }, [medicines, stocks, purchases, sales, searchQuery]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/65 backdrop-blur-xs p-0 sm:p-4 animate-fadeIn">
      <div className="bg-white w-full sm:max-w-3xl rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-l from-teal-950 via-teal-900 to-emerald-900 text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-11 w-11 rounded-2xl bg-amber-400/20 border border-amber-300/40 flex items-center justify-center">
              <Barcode className="h-6 w-6 text-amber-300" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black">
                قائمة تعريف المواد الجديدة (دليل الباركود)
              </h2>
              <p className="text-xs text-teal-100/85">
                سجّل باركود المادة واسمها مرة واحدة فقط ليقرأها النظام تلقائياً في فواتير الشراء والبيع
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-xl bg-white/10 hover:bg-white/20 p-2 text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 flex-1">
          {/* Quick Registration Form */}
          <form
            onSubmit={handleSubmit}
            className="rounded-2xl bg-teal-50/60 border-2 border-teal-200/80 p-4 space-y-3.5"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-teal-950 flex items-center gap-1.5">
                <Plus className="h-4 w-4 text-teal-700" />
                {isEditingExisting
                  ? 'تحديث بيانات مادة مسجلة مسبقاً بالنظام'
                  : 'تعريف مادة جديدة بالنظام (تُحفظ للأبد)'}
              </span>
              {isEditingExisting && (
                <span className="text-[11px] font-bold bg-amber-100 text-amber-800 px-2.5 py-0.5 rounded-full">
                  هذا الباركود معرف مسبقاً - يمكنك تعديل الاسم
                </span>
              )}
            </div>

            {toastMsg && (
              <div className="rounded-xl bg-emerald-600 text-white px-3.5 py-2.5 text-xs font-black flex items-center gap-2 shadow-xs">
                <CheckCircle2 className="h-4 w-4 shrink-0" />
                <span>{toastMsg}</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
              {/* Barcode Input + Camera Scan + Auto Generate */}
              <div className="sm:col-span-5">
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  الباركود (امسح بالكاميرا أو الجهاز أو اكتبه) *
                </label>
                <div className="flex gap-1.5">
                  <div className="relative flex-1">
                    <Barcode className="absolute right-3 top-2.5 h-4 w-4 text-slate-400" />
                    <input
                      ref={barcodeInputRef}
                      type="text"
                      value={barcode}
                      onChange={(e) => handleBarcodeLookup(e.target.value)}
                      placeholder="امسح أو اكتب الباركود..."
                      className="w-full rounded-xl border border-slate-300 bg-white py-2 pr-9 pl-2 text-xs font-mono font-bold text-slate-900 focus:border-teal-600 focus:outline-hidden"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      onOpenScanner((code) => {
                        handleBarcodeLookup(code);
                        setTimeout(() => nameInputRef.current?.focus(), 100);
                      })
                    }
                    className="rounded-xl bg-teal-700 hover:bg-teal-800 text-white px-3 py-2 text-xs font-bold flex items-center gap-1 shrink-0 transition"
                    title="مسح الباركود بالكاميرا"
                  >
                    <Camera className="h-4 w-4" />
                    <span>كاميرا</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleGenerateBarcode}
                    className="rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 px-2.5 py-2 text-xs font-bold shrink-0 transition"
                    title="توليد باركود تلقائي لمادة بدون باركود"
                  >
                    <Wand2 className="h-4 w-4" />
                  </button>
                </div>
              </div>

              {/* Medicine Trade Name */}
              <div className="sm:col-span-7">
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  اسم المادة / الدواء التجاري والعيار *
                </label>
                <input
                  ref={nameInputRef}
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="مثال: Panadol Extra 500mg (24 Tab) أو Augmentin 1g"
                  className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-900 focus:border-teal-600 focus:outline-hidden"
                />
              </div>

              {/* Scientific Name / Manufacturer */}
              <div className="sm:col-span-5">
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  الاسم العلمي أو الشركة (اختياري)
                </label>
                <input
                  type="text"
                  value={scientificName}
                  onChange={(e) => setScientificName(e.target.value)}
                  placeholder="مثال: Paracetamol / شركة سامراء أو جلفار"
                  className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs text-slate-800 focus:border-teal-600 focus:outline-hidden"
                />
              </div>

              {/* Unit */}
              <div className="sm:col-span-3">
                <label className="block text-xs font-bold text-slate-700 mb-1">الوحدة</label>
                <select
                  value={unit}
                  onChange={(e) => setUnit(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-800 focus:border-teal-600 focus:outline-hidden"
                >
                  {UNITS.map((u) => (
                    <option key={u} value={u}>
                      {u}
                    </option>
                  ))}
                </select>
              </div>

              {/* Min Stock Alert */}
              <div className="sm:col-span-4">
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  حد التنبيه لنقص المخزون
                </label>
                <input
                  type="number"
                  min="0"
                  value={minStockAlert}
                  onChange={(e) => setMinStockAlert(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-800 focus:border-teal-600 focus:outline-hidden"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-1">
              {(barcode || name) && (
                <button
                  type="button"
                  onClick={() => {
                    setBarcode('');
                    setName('');
                    setScientificName('');
                    setIsEditingExisting(false);
                  }}
                  className="rounded-xl bg-white border border-slate-300 px-3 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100"
                >
                  تفريغ الحقول
                </button>
              )}
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white px-5 py-2.5 text-xs font-black shadow-sm transition active:scale-95"
              >
                <Check className="h-4 w-4" />
                {isEditingExisting
                  ? 'حفظ تعديل المادة'
                  : 'حفظ المادة بالنظام وإضافة غيرها +'}
              </button>
            </div>
          </form>

          {/* Registered Medicines Directory */}
          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
                <Package className="h-4 w-4 text-teal-700" />
                المواد المعرّفة في النظام ({allCatalogItems.length} مادة)
              </h3>

              <div className="relative sm:w-72">
                <Search className="absolute right-3 top-2.5 h-4 w-4 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="ابحث بالاسم أو الباركود..."
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2 pr-9 pl-3 text-xs focus:border-teal-600 focus:bg-white focus:outline-hidden"
                />
              </div>
            </div>

            <div className="divide-y divide-slate-100 rounded-2xl border border-slate-200 bg-white overflow-hidden">
              {allCatalogItems.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-400">
                  لا توجد مواد مطابقة للبحث
                </div>
              ) : (
                allCatalogItems.map((item) => (
                  <div
                    key={item.barcode}
                    className="p-3 sm:px-4 flex items-center justify-between gap-3 hover:bg-slate-50 transition"
                  >
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="font-mono text-[11px] font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md border border-slate-200">
                          {item.barcode}
                        </span>
                        <span className="text-[11px] font-bold bg-teal-50 text-teal-800 px-2 py-0.5 rounded-md">
                          {item.unit}
                        </span>
                        <span className="text-[11px] font-bold text-slate-500">
                          المتوفر: <strong className="text-slate-900">{item.remaining}</strong>
                        </span>
                      </div>
                      <p className="text-xs sm:text-sm font-black text-slate-900 mt-1 truncate">
                        {item.name}
                      </p>
                      <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-500 mt-0.5">
                        {item.scientificName && <span>{item.scientificName}</span>}
                        {item.lastPurchasePrice > 0 && (
                          <span>آخر شراء: {formatIQD(item.lastPurchasePrice)}</span>
                        )}
                        {item.lastSalePrice > 0 && (
                          <span>آخر بيع: {formatIQD(item.lastSalePrice)}</span>
                        )}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        handleBarcodeLookup(item.barcode);
                        barcodeInputRef.current?.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="inline-flex items-center gap-1 rounded-xl bg-slate-100 hover:bg-teal-100 hover:text-teal-900 text-slate-700 px-3 py-1.5 text-xs font-bold shrink-0 transition"
                    >
                      <Edit3 className="h-3.5 w-3.5" />
                      <span>تعديل</span>
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
