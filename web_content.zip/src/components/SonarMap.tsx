import React, { useEffect, useRef, useState } from 'react';
import { setOptions, importLibrary } from '@googlemaps/js-api-loader';
import { Radar, MapPin, Navigation, AlertCircle } from 'lucide-react';

interface SonarMapProps {
  myLocation: { lat: number; lng: number } | null;
  targets: { username: string; distance: number; lat: number; lng: number }[];
  onScan: () => void;
  isScanning: boolean;
}

export const SonarMap: React.FC<SonarMapProps> = ({ myLocation, targets, onScan, isScanning }) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const [mapInstance, setMapInstance] = useState<google.maps.Map | null>(null);
  const [apiKey, setApiKey] = useState<string>(
    localStorage.getItem('gmp_api_key') || import.meta.env.VITE_GOOGLE_MAPS_API_KEY || ''
  );
  const [isLoaded, setIsLoaded] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const markersRef = useRef<google.maps.marker.AdvancedMarkerElement[]>([]);

  const saveApiKey = (key: string) => {
    setApiKey(key);
    localStorage.setItem('gmp_api_key', key);
  };

  useEffect(() => {
    if (!apiKey) return;

    setOptions({
      key: apiKey,
      v: 'weekly',
      libraries: ['marker', 'maps']
    });

    importLibrary('maps')
      .then(async () => {
        await importLibrary('marker');
        if (!mapRef.current) return;
        const { Map } = (await google.maps.importLibrary('maps')) as google.maps.MapsLibrary;
        
        const center = myLocation ? { lat: myLocation.lat, lng: myLocation.lng } : { lat: 19.4326, lng: -99.1332 }; // Default CDMX

        const map = new Map(mapRef.current, {
          center,
          zoom: 13,
          mapId: 'DEMO_MAP_ID', // Mandatory for AdvancedMarkerElement
          disableDefaultUI: false,
          backgroundColor: '#0A0015',
        });

        setMapInstance(map);
        setIsLoaded(true);
        setLoadError(null);
      })
      .catch((err) => {
        console.error('Error loading Google Maps:', err);
        setLoadError('Error cargando Google Maps. Verifica tu API Key.');
      });
  }, [apiKey]);

  const [closeTargets, setCloseTargets] = useState<{username: string, distance: number}[]>([]);

  // Update markers and check for close targets (< 500m)
  useEffect(() => {
    if (!mapInstance || !isLoaded) return;

    const close: {username: string, distance: number}[] = [];

    // Clear old markers
    markersRef.current.forEach(m => {
      if (m.map) m.map = null;
    });
    markersRef.current = [];

    // Add my location marker
    if (myLocation) {
      const myPos = new google.maps.LatLng(myLocation.lat, myLocation.lng);
      mapInstance.setCenter(myPos);

      const myEl = document.createElement('div');
      myEl.className = 'bg-[#00ff88] text-black px-2 py-1 rounded-full text-[10px] font-black uppercase shadow-[0_0_15px_#00ff88] flex items-center gap-1 border border-white';
      myEl.innerHTML = `<span class="w-2 h-2 rounded-full bg-black animate-ping"></span> TÚ (SONÓ)`;

      const myMarker = new google.maps.marker.AdvancedMarkerElement({
        map: mapInstance,
        position: myPos,
        title: 'Tu ubicación',
        content: myEl
      });
      markersRef.current.push(myMarker);
    }

    // Add target markers
    targets.forEach(target => {
      if (!target.lat || !target.lng) return;
      const pos = new google.maps.LatLng(target.lat, target.lng);

      if (target.distance <= 0.5) {
        close.push({ username: target.username, distance: target.distance });
      }

      const isVeryClose = target.distance <= 0.5;
      const targetEl = document.createElement('div');
      targetEl.className = `${isVeryClose ? 'bg-red-600 animate-bounce' : 'bg-[#FF0044]'} text-white px-2.5 py-1 rounded-xl text-[10px] font-black uppercase shadow-[0_0_15px_${isVeryClose ? '#ef4444' : '#FF0044'}] flex items-center gap-1 border border-white`;
      targetEl.innerHTML = `<span class="w-2 h-2 rounded-full bg-white animate-pulse"></span> ${target.username} (${(target.distance < 1 ? (target.distance * 1000).toFixed(0) + 'm' : target.distance.toFixed(1) + 'km')})`;

      const marker = new google.maps.marker.AdvancedMarkerElement({
        map: mapInstance,
        position: pos,
        title: target.username,
        content: targetEl
      });
      markersRef.current.push(marker);
    });

    setCloseTargets(close);
    if (close.length > 0) {
      if ('vibrate' in navigator) {
        navigator.vibrate([300, 150, 300, 150, 500]);
      }
    }
  }, [mapInstance, isLoaded, myLocation, targets]);

  if (!apiKey) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-6 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-[#00ff88]/10 border border-[#00ff88] flex items-center justify-center text-[#00ff88]">
          <Radar className="w-8 h-8 animate-pulse" />
        </div>
        <h3 className="text-white font-black text-sm tracking-widest uppercase">Google Maps API Key Requerida</h3>
        <p className="text-xs text-gray-400 max-w-sm">
          Para ver los dispositivos Sonó en un mapa real de Google Maps, ingresa tu API Key de Google Maps Platform (puedes obtener una clave demo gratuita en <a href="https://mapsplatform.google.com/maps-demo-key" target="_blank" rel="noreferrer" className="text-[#00ff88] underline">Maps Demo Key</a>).
        </p>
        <div className="w-full max-w-sm space-y-2">
          <input
            type="text"
            placeholder="Pega tu API Key de Google Maps..."
            className="w-full bg-black/50 border border-gray-700 rounded-xl px-4 py-3 text-xs text-white font-mono outline-none focus:border-[#00ff88]"
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                saveApiKey((e.target as HTMLInputElement).value);
              }
            }}
            id="gmp-key-input"
          />
          <button
            onClick={() => {
              const input = document.getElementById('gmp-key-input') as HTMLInputElement;
              if (input && input.value) saveApiKey(input.value);
            }}
            className="w-full bg-[#00ff88]/20 text-[#00ff88] border border-[#00ff88]/50 rounded-xl py-3 text-xs font-black uppercase tracking-widest hover:bg-[#00ff88] hover:text-black transition-all"
          >
            Guardar y Cargar Mapa
          </button>
        </div>
        <p className="text-[10px] text-gray-500 uppercase tracking-widest mt-2">
          Nota: Uso sujeto a los Términos de Google Maps Platform.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full relative">
      <div className="absolute top-4 left-4 right-4 z-10 flex flex-col gap-2">
        <div className="flex items-center justify-between bg-black/80 backdrop-blur-md border border-[#00ff88]/50 rounded-2xl p-3 shadow-[0_0_20px_rgba(0,255,136,0.2)]">
          <div className="flex items-center gap-2">
            <Radar className="w-5 h-5 text-[#00ff88] animate-spin" style={{ animationDuration: '4s' }} />
            <span className="text-white text-xs font-black tracking-widest uppercase">SONAR GPS (GOOGLE MAPS)</span>
          </div>
          <button
            onClick={onScan}
            disabled={isScanning}
            className="bg-[#00ff88]/20 border border-[#00ff88] text-[#00ff88] px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-[#00ff88] hover:text-black transition-all shadow-[0_0_10px_#00ff88]"
          >
            {isScanning ? 'Escaneando...' : 'Escanear Área'}
          </button>
        </div>

        {closeTargets.length > 0 && (
          <div className="bg-red-600/90 border-2 border-white rounded-2xl p-3 flex items-center gap-3 animate-pulse shadow-[0_0_25px_rgba(239,68,68,0.7)] text-white">
            <AlertCircle className="w-6 h-6 animate-bounce shrink-0" />
            <div className="flex-1">
              <p className="text-[10px] font-black tracking-widest uppercase">¡ALERTA DE PROXIMIDAD (&lt; 500M) !</p>
              <p className="text-xs font-bold">{closeTargets.map(t => `${t.username} (${(t.distance * 1000).toFixed(0)}m)`).join(', ')}</p>
            </div>
          </div>
        )}
      </div>

      <div ref={mapRef} className="w-full flex-1 rounded-3xl overflow-hidden border border-[#00ff88]/30 min-h-[350px]"></div>

      {loadError && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-[#110022] border border-red-500 rounded-2xl p-6 text-center max-w-sm space-y-3">
            <AlertCircle className="w-8 h-8 text-red-500 mx-auto" />
            <p className="text-white text-xs font-bold uppercase">{loadError}</p>
            <button
              onClick={() => { localStorage.removeItem('gmp_api_key'); setApiKey(''); }}
              className="bg-red-500/20 text-red-400 border border-red-500/50 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-red-500 hover:text-white transition-all"
            >
              Cambiar API Key
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
