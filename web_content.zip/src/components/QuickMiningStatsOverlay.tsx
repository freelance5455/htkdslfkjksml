import React, { useState, useEffect } from 'react';
import { Cpu, Zap, Coins, Activity, ArrowUpRight, X, ShieldCheck } from 'lucide-react';

interface QuickMiningStatsOverlayProps {
  isMining: boolean;
  onToggleMining: () => void;
  onOpenCryptoPage: () => void;
}

export const QuickMiningStatsOverlay: React.FC<QuickMiningStatsOverlayProps> = ({
  isMining,
  onToggleMining,
  onOpenCryptoPage,
}) => {
  const [minedJmc, setMinedJmc] = useState<number>(() => {
    const saved = localStorage.getItem('jm_crypto_mined_unclaimed_v2');
    return saved ? parseFloat(saved) : 0.0450;
  });
  const [hashRate, setHashRate] = useState<number>(100000);
  const [isMinimized, setIsMinimized] = useState<boolean>(false);

  useEffect(() => {
    const interval = setInterval(() => {
      if (isMining) {
        setMinedJmc(prev => {
          const next = prev + 0.0001;
          localStorage.setItem('jm_crypto_mined_unclaimed_v2', next.toFixed(4));
          return next;
        });
        // Slight fluctuation in hash rate for realism
        setHashRate(100000 + Math.floor(Math.random() * 1500) - 750);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [isMining]);

  if (isMinimized) {
    return (
      <button
        onClick={() => setIsMinimized(false)}
        className="fixed bottom-20 right-4 z-50 bg-slate-950/90 border border-amber-500/50 hover:border-amber-400 text-amber-300 px-3 py-2 rounded-2xl shadow-2xl backdrop-blur-xl flex items-center space-x-2 text-xs font-mono font-bold transition-all hover:scale-105 animate-pulse"
        title="Open Quick Mining Stats"
      >
        <Cpu className="w-4 h-4 text-amber-400 animate-spin-slow" />
        <span>JM-MINING: {hashRate.toLocaleString()} H/s</span>
      </button>
    );
  }

  return (
    <div className="fixed bottom-20 right-4 z-50 max-w-xs w-[90%] bg-slate-950/90 border border-amber-500/50 rounded-3xl p-4 shadow-2xl backdrop-blur-2xl text-left space-y-3 animate-fadeIn text-amber-100">
      <div className="flex items-center justify-between border-b border-amber-500/20 pb-2">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400 shadow-inner">
            <Coins className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-amber-300 font-mono uppercase tracking-wider">
              Quick Mining Stats
            </h4>
            <span className="text-[10px] text-slate-400">JUHNKRIX Hardware Core</span>
          </div>
        </div>
        <div className="flex items-center space-x-1">
          <button
            onClick={() => setIsMinimized(true)}
            className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors text-xs font-mono"
            title="Minimize"
          >
            _
          </button>
          <button
            onClick={() => setIsMinimized(true)}
            className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-rose-400 transition-colors"
            title="Close"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
        <div className="bg-slate-900/90 border border-amber-500/20 p-2.5 rounded-2xl">
          <span className="text-slate-400 text-[10px] block">Hash Rate</span>
          <span className="text-amber-300 font-bold flex items-center space-x-1 mt-0.5">
            <Activity className="w-3 h-3 text-emerald-400 animate-pulse" />
            <span>{hashRate.toLocaleString()} H/s</span>
          </span>
        </div>
        <div className="bg-slate-900/90 border border-amber-500/20 p-2.5 rounded-2xl">
          <span className="text-slate-400 text-[10px] block">Total Mined JMC</span>
          <span className="text-amber-200 font-bold flex items-center space-x-1 mt-0.5">
            <Coins className="w-3 h-3 text-amber-400" />
            <span>{minedJmc.toFixed(4)} JMC</span>
          </span>
        </div>
      </div>

      <div className="flex items-center justify-between pt-1">
        <button
          onClick={onToggleMining}
          className={`flex-1 mr-2 py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-1.5 transition-all shadow-md ${
            isMining
              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30'
              : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950'
          }`}
        >
          <Zap className="w-3.5 h-3.5" />
          <span>{isMining ? 'Stop Mining' : 'Start Mining'}</span>
        </button>

        <button
          onClick={onOpenCryptoPage}
          className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 transition-all flex items-center justify-center"
          title="Open JM-Crypto Mining Dashboard"
        >
          <ArrowUpRight className="w-4 h-4" />
        </button>
      </div>

      <div className="text-[9px] text-center text-slate-400 font-mono border-t border-slate-800/80 pt-1.5">
        ⚡ 50/50 Device Share Rule Active (Hardware Secured)
      </div>
    </div>
  );
};
