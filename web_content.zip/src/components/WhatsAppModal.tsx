import React, { useState } from 'react';
import { MessageSquare, Phone, Copy, Check, ExternalLink, ShieldCheck, X } from 'lucide-react';
import { WHATSAPP_SERVICE_NUMBER, WHATSAPP_SERVICE_URL } from '../constants.ts';

interface WhatsAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WhatsAppModal: React.FC<WhatsAppModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(WHATSAPP_SERVICE_NUMBER);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenWhatsApp = () => {
    window.open(WHATSAPP_SERVICE_URL, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-md rounded-2xl bg-[#0d131f] border border-cyan-500/30 p-6 shadow-[0_0_30px_rgba(0,210,255,0.2)] text-slate-100">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-100 transition-colors rounded-lg hover:bg-slate-800"
          aria-label="Close"
        >
          <X size={20} />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-white shadow-lg shadow-emerald-500/20">
            <MessageSquare size={24} />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
              WhatsApp Service
              <span className="text-[10px] font-semibold uppercase tracking-wider text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                Active 24/7
              </span>
            </h3>
            <p className="text-xs text-slate-400">Official Unknown Gamer Support & Verification</p>
          </div>
        </div>

        <div className="space-y-4 my-5">
          <div className="p-4 rounded-xl bg-[#090d15] border border-slate-800/80">
            <span className="text-xs text-slate-400 block mb-1">Official WhatsApp Support Number:</span>
            <div className="flex items-center justify-between">
              <span className="text-xl font-mono font-bold text-cyan-300 tracking-wider">
                {WHATSAPP_SERVICE_NUMBER}
              </span>
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 transition-colors"
              >
                {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                {copied ? 'Copied' : 'Copy'}
              </button>
            </div>
          </div>

          <div className="space-y-2 text-xs text-slate-300">
            <div className="flex items-start gap-2">
              <ShieldCheck size={16} className="text-cyan-400 shrink-0 mt-0.5" />
              <span>Contact Admin for new account registration, password resets, and ban appeals.</span>
            </div>
            <div className="flex items-start gap-2">
              <Phone size={16} className="text-emerald-400 shrink-0 mt-0.5" />
              <span>Register for official tournaments, scrims, and esports prize pools.</span>
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-2.5 pt-2">
          <button
            onClick={handleOpenWhatsApp}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-semibold text-sm bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 shadow-lg shadow-emerald-500/25 active:scale-[0.98] transition-all cursor-pointer"
          >
            <MessageSquare size={18} />
            <span>Open WhatsApp Chat Directly</span>
            <ExternalLink size={16} />
          </button>
          <a
            href={WHATSAPP_SERVICE_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="text-center text-xs text-slate-400 hover:text-cyan-400 transition-colors py-1"
          >
            Or click to open web link: wa.me/923260715961
          </a>
        </div>
      </div>
    </div>
  );
};
