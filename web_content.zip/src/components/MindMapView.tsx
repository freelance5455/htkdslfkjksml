import React, { useState, useEffect, useRef, useMemo } from "react";
import {
  Network,
  Sparkles,
  ZoomIn,
  ZoomOut,
  Maximize2,
  RefreshCw,
  Search,
  Filter,
  Download,
  FolderKanban,
  FileText,
  Tag,
  ExternalLink,
  Plus,
  HelpCircle,
  Eye
} from "lucide-react";
import { Note, SectionItem, MindMapData, MindMapNode, MindMapEdge, UserProfile } from "../types";

interface MindMapViewProps {
  notes: Note[];
  sections: SectionItem[];
  onOpenNote: (note: Note) => void;
  onOpenInfographic?: (note: Note) => void;
  selectedSection?: string;
  onSelectSection?: (section: string) => void;
  profile?: UserProfile;
  onOpenProfile?: () => void;
}

export const MindMapView: React.FC<MindMapViewProps> = ({
  notes,
  sections,
  onOpenNote,
  onOpenInfographic,
  selectedSection = "Tümü",
  onSelectSection,
  profile,
  onOpenProfile,
}) => {
  const [activeSection, setActiveSection] = useState<string>(selectedSection);
  const [searchQuery, setSearchQuery] = useState("");
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [selectedNode, setSelectedNode] = useState<MindMapNode | null>(null);
  const [isAiGenerating, setIsAiGenerating] = useState(false);
  const [customAiMap, setCustomAiMap] = useState<MindMapData | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  // Sync activeSection with prop if changed externally
  useEffect(() => {
    setActiveSection(selectedSection);
  }, [selectedSection]);

  // Filter notes by active section
  const currentNotes = useMemo(() => {
    if (activeSection === "Tümü") return notes;
    return notes.filter((n) => n.category === activeSection);
  }, [notes, activeSection]);

  // Generate dynamic Mind Map data from current notes
  const graphData = useMemo<MindMapData>(() => {
    if (customAiMap) {
      return customAiMap;
    }

    const nodes: MindMapNode[] = [];
    const edges: MindMapEdge[] = [];

    // Central Root Node
    const rootId = "root-workspace";
    nodes.push({
      id: rootId,
      label: activeSection === "Tümü" ? "Bilgi Ekosistemi" : `${activeSection} Haritası`,
      type: "root",
      color: "teal",
      details: `${currentNotes.length} adet not ve alt kavram ağı`,
      x: 0,
      y: 0,
    });

    // Group notes by Category / Section
    const categories = Array.from(new Set(currentNotes.map((n) => n.category || "Genel")));

    // If viewing "Tümü", create section nodes branching out
    if (activeSection === "Tümü") {
      categories.forEach((cat, catIdx) => {
        const catId = `cat-${catIdx}`;
        const catAngle = (catIdx / categories.length) * 2 * Math.PI;
        const catRadius = 220;
        const catX = Math.cos(catAngle) * catRadius;
        const catY = Math.sin(catAngle) * catRadius;

        nodes.push({
          id: catId,
          label: cat,
          type: "category",
          color: "blue",
          details: `${cat} kategorisindeki notlar`,
          x: catX,
          y: catY,
        });

        edges.push({
          id: `edge-root-${catId}`,
          source: rootId,
          target: catId,
          label: "kategori",
        });

        // Add notes belonging to this category
        const catNotes = currentNotes.filter((n) => (n.category || "Genel") === cat);
        catNotes.slice(0, 5).forEach((note, noteIdx) => {
          const noteAngle = catAngle - 0.4 + (noteIdx * 0.8) / Math.max(1, catNotes.length - 1);
          const noteRadius = 380;
          const noteX = Math.cos(noteAngle) * noteRadius;
          const noteY = Math.sin(noteAngle) * noteRadius;

          const noteNodeId = `node-note-${note.id}`;
          nodes.push({
            id: noteNodeId,
            label: note.title || "Başlıksız Not",
            type: "note",
            noteId: note.id,
            color: note.pinned ? "amber" : "emerald",
            details: (note.content || "").slice(0, 160),
            x: noteX,
            y: noteY,
          });

          edges.push({
            id: `edge-${catId}-${noteNodeId}`,
            source: catId,
            target: noteNodeId,
            label: "not",
          });

          // If note has tags or tasks, connect small concept chips
          if (note.tags && note.tags.length > 0) {
            const firstTag = note.tags[0];
            const tagNodeId = `tag-${note.id}-${firstTag}`;
            const tagX = noteX + 90;
            const tagY = noteY + 50;

            nodes.push({
              id: tagNodeId,
              label: firstTag,
              type: "concept",
              color: "purple",
              details: `Etiket: ${firstTag}`,
              x: tagX,
              y: tagY,
            });

            edges.push({
              id: `edge-${noteNodeId}-${tagNodeId}`,
              source: noteNodeId,
              target: tagNodeId,
              label: "etiket",
            });
          }
        });
      });
    } else {
      // Direct Radial View for Selected Section
      currentNotes.forEach((note, nIdx) => {
        const angle = (nIdx / Math.max(1, currentNotes.length)) * 2 * Math.PI;
        const radius = 260;
        const nX = Math.cos(angle) * radius;
        const nY = Math.sin(angle) * radius;

        const noteNodeId = `node-note-${note.id}`;
        nodes.push({
          id: noteNodeId,
          label: note.title || "Başlıksız Not",
          type: "note",
          noteId: note.id,
          color: note.pinned ? "amber" : "blue",
          details: (note.content || "").slice(0, 160),
          x: nX,
          y: nY,
        });

        edges.push({
          id: `edge-root-${noteNodeId}`,
          source: rootId,
          target: noteNodeId,
          label: "içerir",
        });

        // Connect concepts / tasks
        if (note.tasks && note.tasks.length > 0) {
          const task = note.tasks[0];
          const taskNodeId = `task-${note.id}-${task.id}`;
          nodes.push({
            id: taskNodeId,
            label: `✓ ${task.text.slice(0, 22)}...`,
            type: "action",
            color: "emerald",
            details: task.text,
            x: nX * 1.35,
            y: nY * 1.35,
          });

          edges.push({
            id: `edge-${noteNodeId}-${taskNodeId}`,
            source: noteNodeId,
            target: taskNodeId,
            label: "aksiyon",
          });
        }
      });
    }

    return {
      title: `${activeSection} Bilgi Haritası`,
      rootLabel: "Merkez",
      nodes,
      edges,
    };
  }, [currentNotes, activeSection, customAiMap]);

  // AI Generation of Deep Mind Map
  const handleGenerateAiMap = async () => {
    if (profile && (!profile.isLoggedIn || !profile.aiModeEnabled)) {
      const confirmLogin = window.confirm(
        "🤖 NoteFlow Yapay Zeka Haritasını Kullanmak İçin Giriş Yapın\n\nGmail veya E-posta adresiniz ile giriş yaparak notlarınız arasındaki derin semantik bağlantıları görselleştirebilirsiniz.\n\nProfile giderek giriş yapmak ister misiniz?"
      );
      if (confirmLogin && onOpenProfile) {
        onOpenProfile();
      }
      return;
    }

    setIsAiGenerating(true);
    try {
      const res = await fetch("/api/gemini/mindmap", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: `${activeSection} Odaklı Bilgi Ağı`,
          notesList: currentNotes.slice(0, 8),
        }),
      });

      let data: any = null;
      if (res.ok) {
        data = await res.json();
      }

      if (!data || !Array.isArray(data.nodes) || data.nodes.length === 0) {
        // Fallback local synthesis
        const rootId = "node-center";
        const rootNode: MindMapNode = {
          id: rootId,
          label: `${activeSection} Bilgi Ağı`,
          type: "root",
          color: "teal",
          details: "Tüm notların ve bölümlerin merkezi bağlantı odağı",
          x: 0,
          y: 0,
        };
        const nodes: MindMapNode[] = [rootNode];
        const edges: MindMapEdge[] = [];

        currentNotes.forEach((n, idx) => {
          const angle = (idx / Math.max(currentNotes.length, 1)) * 2 * Math.PI;
          const radius = 240;
          const nodeId = `node-client-${n.id}`;
          nodes.push({
            id: nodeId,
            label: n.title.slice(0, 24),
            type: "concept",
            color: idx % 2 === 0 ? "blue" : "purple",
            details: n.content ? n.content.replace(/<[^>]+>/g, "").slice(0, 80) : "Not detayı",
            x: Math.cos(angle) * radius,
            y: Math.sin(angle) * radius,
          });
          edges.push({
            id: `edge-${rootId}-${nodeId}`,
            source: rootId,
            target: nodeId,
            label: n.category || "içerir",
          });
        });

        setCustomAiMap({
          title: `${activeSection} Bilgi Haritası`,
          rootLabel: "Merkez",
          nodes,
          edges,
        });
      } else {
        // Compute circular radial layout positions for nodes
        const rootNode = data.nodes.find((n: any) => n.type === "root") || data.nodes[0];
        const otherNodes = data.nodes.filter((n: any) => n.id !== rootNode.id);

        const positionedNodes: MindMapNode[] = [
          { ...rootNode, x: 0, y: 0, type: "root", color: "teal" },
        ];

        otherNodes.forEach((node: any, idx: number) => {
          const angle = (idx / Math.max(otherNodes.length, 1)) * 2 * Math.PI;
          const radius = node.type === "category" ? 220 : 340;
          positionedNodes.push({
            ...node,
            x: Math.cos(angle) * radius,
            y: Math.sin(angle) * radius,
          });
        });

        setCustomAiMap({
          title: data.title || "AI Bilgi Haritası",
          rootLabel: data.rootLabel || "Merkez",
          nodes: positionedNodes,
          edges: data.edges || [],
        });
      }
    } catch (err) {
      console.warn("Generating local fallback AI mind map:", err);
      // Construct fallback map smoothly
      const rootId = "node-center";
      const nodes: MindMapNode[] = [
        {
          id: rootId,
          label: `${activeSection} Bilgi Ağı`,
          type: "root",
          color: "teal",
          details: "Merkezi bilgi ve ilişki ağı",
          x: 0,
          y: 0,
        },
      ];
      const edges: MindMapEdge[] = [];
      currentNotes.forEach((n, idx) => {
        const angle = (idx / Math.max(currentNotes.length, 1)) * 2 * Math.PI;
        const nodeId = `node-f-${n.id}`;
        nodes.push({
          id: nodeId,
          label: n.title.slice(0, 24),
          type: "concept",
          color: "emerald",
          details: "Not içeriği",
          x: Math.cos(angle) * 240,
          y: Math.sin(angle) * 240,
        });
        edges.push({
          id: `edge-${rootId}-${nodeId}`,
          source: rootId,
          target: nodeId,
          label: n.category || "bağlantı",
        });
      });
      setCustomAiMap({
        title: `${activeSection} Bilgi Haritası`,
        rootLabel: "Merkez",
        nodes,
        edges,
      });
    } finally {
      setIsAiGenerating(false);
    }
  };

  // Mouse & Touch drag handlers for canvas panning and pinch-to-zoom
  const touchStartDistRef = useRef<number | null>(null);
  const touchStartZoomRef = useRef<number>(1);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPan({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      const touch = e.touches[0];
      setIsDragging(true);
      setDragStart({ x: touch.clientX - pan.x, y: touch.clientY - pan.y });
    } else if (e.touches.length === 2) {
      setIsDragging(false);
      const t1 = e.touches[0];
      const t2 = e.touches[1];
      const dist = Math.hypot(t1.clientX - t2.clientX, t1.clientY - t2.clientY);
      touchStartDistRef.current = dist;
      touchStartZoomRef.current = zoom;
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 1 && isDragging) {
      const touch = e.touches[0];
      setPan({
        x: touch.clientX - dragStart.x,
        y: touch.clientY - dragStart.y,
      });
    } else if (e.touches.length === 2 && touchStartDistRef.current) {
      const t1 = e.touches[0];
      const t2 = e.touches[1];
      const currentDist = Math.hypot(t1.clientX - t2.clientX, t1.clientY - t2.clientY);
      const scale = currentDist / touchStartDistRef.current;
      const newZoom = Math.max(0.4, Math.min(2.5, touchStartZoomRef.current * scale));
      setZoom(newZoom);
    }
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
    touchStartDistRef.current = null;
  };

  const handleResetView = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
    setSelectedNode(null);
  };

  // Export SVG visual map
  const handleExportSvg = () => {
    if (!svgRef.current) return;
    const svgData = new XMLSerializer().serializeToString(svgRef.current);
    const svgBlob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
    const svgUrl = URL.createObjectURL(svgBlob);
    const downloadLink = document.createElement("a");
    downloadLink.href = svgUrl;
    downloadLink.download = `noteflow-bilgi-haritasi-${Date.now()}.svg`;
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
    URL.revokeObjectURL(svgUrl);
  };

  // Node color helper
  const getNodeColorClass = (color?: string, type?: string) => {
    if (type === "root") return "fill-teal-600 text-white stroke-teal-400";
    if (type === "category") return "fill-blue-600 text-white stroke-blue-300";
    if (type === "action") return "fill-emerald-600 text-white stroke-emerald-300";
    if (type === "concept") return "fill-purple-600 text-white stroke-purple-300";

    switch (color) {
      case "amber":
        return "fill-amber-500 text-white stroke-amber-200";
      case "rose":
        return "fill-rose-500 text-white stroke-rose-200";
      case "emerald":
        return "fill-emerald-600 text-white stroke-emerald-200";
      default:
        return "fill-slate-700 text-white stroke-slate-400";
    }
  };

  // Find linked note for a selected node
  const linkedNote = useMemo(() => {
    if (!selectedNode?.noteId) return null;
    return notes.find((n) => n.id === selectedNode.noteId) || null;
  }, [selectedNode, notes]);

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] min-h-[550px] bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden relative">
      {/* Top Header & Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/80 backdrop-blur-md z-20">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-2xl bg-teal-500/10 text-teal-600 dark:text-teal-400 flex items-center justify-center">
            <Network className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span>Bilgi Haritası ve İlişki Ağı</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300 font-semibold">
                İnteraktif Zihin Haritası
              </span>
            </h2>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Notlarınız arasındaki tematik bağları ve kavramları keşfedin
            </p>
          </div>
        </div>

        {/* Section Selector Pills */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-200/60 dark:bg-slate-800 rounded-xl overflow-x-auto max-w-full">
          <button
            onClick={() => {
              setActiveSection("Tümü");
              setCustomAiMap(null);
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeSection === "Tümü"
                ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-300 shadow-xs font-bold"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
            }`}
          >
            Tümü
          </button>
          {sections.map((sec) => (
            <button
              key={sec.id}
              onClick={() => {
                setActiveSection(sec.name);
                setCustomAiMap(null);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                activeSection === sec.name
                  ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-300 shadow-xs font-bold"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
              }`}
            >
              {sec.name}
            </button>
          ))}
        </div>

        {/* Canvas Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleGenerateAiMap}
            disabled={isAiGenerating}
            title="Yapay zeka ile derin kavram haritası üret"
            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white text-xs font-bold shadow-xs flex items-center gap-1.5 transition-all disabled:opacity-50"
          >
            <Sparkles className={`w-3.5 h-3.5 ${isAiGenerating ? "animate-spin" : ""}`} />
            <span className="hidden sm:inline">AI ile Harita Üret</span>
          </button>

          <div className="flex items-center bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-0.5">
            <button
              onClick={() => setZoom((z) => Math.min(2, z + 0.15))}
              className="p-1.5 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg"
              title="Yakınlaştır"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              onClick={() => setZoom((z) => Math.max(0.4, z - 0.15))}
              className="p-1.5 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg"
              title="Uzaklaştır"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <button
              onClick={handleResetView}
              className="p-1.5 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg text-[10px] font-bold"
              title="Görünümü Sıfırla"
            >
              100%
            </button>
          </div>

          <button
            onClick={handleExportSvg}
            title="Haritayı SVG Olarak İndir"
            className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* SVG Interactive Canvas */}
      <div
        ref={containerRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onTouchCancel={handleTouchEnd}
        className="flex-1 w-full h-full relative cursor-grab active:cursor-grabbing overflow-hidden select-none touch-none modal-overscroll-contain bg-[radial-gradient(#cbd5e1_1px,transparent_1px)] dark:bg-[radial-gradient(#334155_1px,transparent_1px)] [background-size:24px_24px]"
      >
        <svg
          ref={svgRef}
          className="w-full h-full"
          viewBox="-600 -400 1200 800"
          style={{
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
            transformOrigin: "center center",
            transition: isDragging ? "none" : "transform 0.1s ease-out",
          }}
        >
          <defs>
            <marker
              id="arrow"
              viewBox="0 0 10 10"
              refX="18"
              refY="5"
              markerWidth="6"
              markerHeight="6"
              orient="auto-start-reverse"
            >
              <path d="M 0 0 L 10 5 L 0 10 z" fill="#94a3b8" />
            </marker>
          </defs>

          {/* Render Connections / Edges */}
          {graphData.edges.map((edge) => {
            const sourceNode = graphData.nodes.find((n) => n.id === edge.source);
            const targetNode = graphData.nodes.find((n) => n.id === edge.target);
            if (!sourceNode || !targetNode) return null;

            const sx = sourceNode.x || 0;
            const sy = sourceNode.y || 0;
            const tx = targetNode.x || 0;
            const ty = targetNode.y || 0;

            // Bezier curve midpoint
            const mx = (sx + tx) / 2;
            const my = (sy + ty) / 2;

            return (
              <g key={edge.id}>
                <path
                  d={`M ${sx} ${sy} Q ${mx} ${my} ${tx} ${ty}`}
                  fill="none"
                  stroke="#94a3b8"
                  strokeWidth={1.5}
                  strokeDasharray={edge.label === "etiket" ? "4 4" : "none"}
                  className="opacity-60 dark:opacity-40 hover:opacity-100 hover:stroke-teal-500 transition-all"
                />
                {edge.label && (
                  <text
                    x={mx}
                    y={my - 6}
                    textAnchor="middle"
                    className="text-[9px] fill-slate-400 dark:fill-slate-500 font-medium"
                  >
                    {edge.label}
                  </text>
                )}
              </g>
            );
          })}

          {/* Render Interactive Nodes */}
          {graphData.nodes.map((node) => {
            const isSelected = selectedNode?.id === node.id;
            const isRoot = node.type === "root";
            const isNote = node.type === "note";
            const radius = isRoot ? 48 : isNote ? 34 : 26;

            return (
              <g
                key={node.id}
                transform={`translate(${node.x || 0}, ${node.y || 0})`}
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedNode(node);
                }}
                className="cursor-pointer group"
              >
                {/* Pulse ring for selected node */}
                {isSelected && (
                  <circle
                    r={radius + 8}
                    fill="none"
                    stroke="#0d9488"
                    strokeWidth={3}
                    className="animate-pulse opacity-70"
                  />
                )}

                {/* Node circle */}
                <circle
                  r={radius}
                  className={`${getNodeColorClass(node.color, node.type)} shadow-lg transition-transform group-hover:scale-105 stroke-2`}
                />

                {/* Node text / icon */}
                <text
                  textAnchor="middle"
                  dy={isRoot ? "0.3em" : "0.35em"}
                  className={`font-bold select-none pointer-events-none fill-white ${
                    isRoot ? "text-xs" : "text-[11px]"
                  }`}
                >
                  {node.label.length > (isRoot ? 16 : 12)
                    ? node.label.slice(0, isRoot ? 14 : 10) + "…"
                    : node.label}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Selected Node Details Drawer / Popover */}
        {selectedNode && (
          <div className="absolute bottom-5 right-5 max-w-sm w-full bg-white/95 dark:bg-slate-900/95 backdrop-blur-md rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xl animate-in slide-in-from-bottom-4 duration-200 z-30">
            <div className="flex items-start justify-between gap-2">
              <div>
                <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300">
                  {selectedNode.type === "root"
                    ? "Merkez Odak"
                    : selectedNode.type === "category"
                    ? "Bölüm / Kategori"
                    : selectedNode.type === "note"
                    ? "Not Kartı"
                    : "Kavram / Aksiyon"}
                </span>
                <h4 className="text-base font-bold text-slate-900 dark:text-white mt-1">
                  {selectedNode.label}
                </h4>
              </div>
              <button
                onClick={() => setSelectedNode(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                ✕
              </button>
            </div>

            {selectedNode.details && (
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 line-clamp-3 leading-relaxed">
                {selectedNode.details}
              </p>
            )}

            {/* Note Quick Actions */}
            {linkedNote && (
              <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2">
                <button
                  onClick={() => onOpenNote(linkedNote)}
                  className="flex-1 px-3 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition-colors"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Notu Düzenle</span>
                </button>
                {onOpenInfographic && (
                  <button
                    onClick={() => onOpenInfographic(linkedNote)}
                    title="Bu notun infografiğini aç"
                    className="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    <span>İnfografik</span>
                  </button>
                )}
              </div>
            )}
          </div>
        )}

        {/* Floating Canvas Quick Tips */}
        <div className="absolute bottom-5 left-5 hidden sm:flex items-center gap-2 px-3.5 py-2 bg-white/90 dark:bg-slate-800/90 backdrop-blur-md rounded-2xl border border-slate-200 dark:border-slate-700 text-[11px] text-slate-500 dark:text-slate-400 shadow-sm pointer-events-none">
          <HelpCircle className="w-3.5 h-3.5 text-teal-500" />
          <span>Sürükleyerek gezinin, yakınlaştırın, detaylar için düğümlere dokunun.</span>
        </div>
      </div>
    </div>
  );
};
