import React from 'react';
import { CheckCircle2, Loader2, ShieldCheck, Terminal, PackageCheck } from 'lucide-react';
import { RecompilationStep } from '../types';

interface RecompilationStageProps {
  steps: RecompilationStep[];
  packageName: string;
}

export const RecompilationStage: React.FC<RecompilationStageProps> = ({ steps, packageName }) => {
  return (
    <div className="flex flex-col items-center justify-center w-full max-w-2xl mx-auto py-4">
      {/* SUCCESS NOTIFICATION REQUIRED BY USER PROMPT */}
      <div className="w-full mb-6 p-4 sm:p-5 rounded-2xl bg-emerald-500/10 border-2 border-emerald-500/40 flex items-center gap-3.5 shadow-lg shadow-emerald-500/10 animate-fadeIn">
        <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 flex-shrink-0">
          <CheckCircle2 className="w-6 h-6 text-emerald-400" />
        </div>
        <div>
          <h3 className="text-sm sm:text-base font-bold text-white">
            Process Successful!
          </h3>
          <p className="text-xs sm:text-sm text-emerald-300/90 mt-0.5">
            All identified files and values have been successfully modified!
          </p>
        </div>
      </div>

      {/* Recompilation Process Card */}
      <div className="w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <PackageCheck className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white">
                Automatic Recompilation &amp; Digital Signing
              </h2>
              <p className="text-xs text-slate-400">
                Package: <span className="font-mono text-slate-300">{packageName}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-800 text-[11px] font-mono text-emerald-400 border border-slate-700">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>RSA-2048</span>
          </div>
        </div>

        <p className="text-xs text-slate-400 mt-4 leading-relaxed">
          Recompiling the modified files—along with all other existing package files—into a single, downloadable package, and applying a new cryptographic digital signature...
        </p>

        {/* Step-by-Step Pipeline */}
        <div className="space-y-3.5 mt-6">
          {steps.map((step, idx) => {
            const isCompleted = step.status === 'completed';
            const isInProgress = step.status === 'in_progress';

            return (
              <div
                key={step.id}
                className={`p-3.5 rounded-xl border transition-all ${
                  isCompleted
                    ? 'bg-slate-950/80 border-emerald-500/40'
                    : isInProgress
                    ? 'bg-emerald-950/20 border-emerald-500/50 shadow-md shadow-emerald-500/10'
                    : 'bg-slate-950/40 border-slate-800/80 opacity-60'
                }`}
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="flex-shrink-0">
                      {isCompleted ? (
                        <div className="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400">
                          <CheckCircle2 className="w-4 h-4" />
                        </div>
                      ) : isInProgress ? (
                        <div className="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400">
                          <Loader2 className="w-4 h-4 animate-spin" />
                        </div>
                      ) : (
                        <div className="w-6 h-6 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 text-[11px] font-mono">
                          {idx + 1}
                        </div>
                      )}
                    </div>

                    <div className="min-w-0">
                      <span
                        className={`text-xs sm:text-sm font-semibold truncate block ${
                          isCompleted
                            ? 'text-slate-200'
                            : isInProgress
                            ? 'text-emerald-300 font-bold'
                            : 'text-slate-400'
                        }`}
                      >
                        {step.label}
                      </span>
                      {step.detail && (
                        <span className="text-[11px] text-slate-400 block font-mono mt-0.5">
                          {step.detail}
                        </span>
                      )}
                    </div>
                  </div>

                  <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded flex-shrink-0 text-slate-400">
                    {step.status === 'completed'
                      ? 'Done'
                      : step.status === 'in_progress'
                      ? 'Running'
                      : 'Queued'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Live Terminal Log Preview */}
        <div className="mt-6 p-3 rounded-xl bg-slate-950 border border-slate-800/90 font-mono text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5 text-[10px] text-slate-400 mb-1.5 uppercase tracking-wider">
            <Terminal className="w-3 h-3 text-emerald-400" />
            <span>Recompiler Tool Console</span>
          </div>
          <div className="space-y-0.5 text-slate-400">
            <div>&gt; [BUILD] Packaging target tree into aligned archive stream...</div>
            <div>&gt; [SIGN] Injected META-INF/MANIFEST.MF, CERT.SF &amp; CERT.RSA</div>
            <div>&gt; [SIGN] Android APK Signature Scheme v2 digest injected successfully</div>
          </div>
        </div>
      </div>
    </div>
  );
};
