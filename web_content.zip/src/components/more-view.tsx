import { useState } from "react";
import { Button } from "@/components/ui/button";
import { PinDots, PinPad } from "@/components/pin-pad";
import { useVault } from "@/lib/vault-store";

type PinStep = "idle" | "old" | "next" | "confirm";

export function MoreView() {
  const lock = useVault((s) => s.lock);
  const changePassword = useVault((s) => s.changePassword);
  const resetVault = useVault((s) => s.resetVault);

  const [step, setStep] = useState<PinStep>("idle");
  const [pin, setPin] = useState("");
  const [oldPin, setOldPin] = useState("");
  const [nextPin, setNextPin] = useState("");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [wipe, setWipe] = useState(false);
  const [shake, setShake] = useState(false);

  function fail(text: string) {
    setError(text);
    setShake(true);
    window.setTimeout(() => setShake(false), 400);
    setPin("");
  }

  function resetFlow() {
    setStep("idle");
    setPin("");
    setOldPin("");
    setNextPin("");
    setError("");
  }

  async function onComplete(value: string) {
    if (busy) return;
    setError("");
    if (step === "old") {
      setOldPin(value);
      setPin("");
      setStep("next");
      return;
    }
    if (step === "next") {
      setNextPin(value);
      setPin("");
      setStep("confirm");
      return;
    }
    if (step === "confirm") {
      if (value !== nextPin) {
        setStep("next");
        setNextPin("");
        fail("Новые коды не совпали.");
        return;
      }
      setBusy(true);
      const ok = await changePassword(oldPin, value);
      setBusy(false);
      if (!ok) {
        setStep("old");
        setOldPin("");
        setNextPin("");
        fail("Старый код неверный.");
        return;
      }
      resetFlow();
      setMessage("Код заменён.");
    }
  }

  const captions: Record<Exclude<PinStep, "idle">, string> = {
    old: "Старый код",
    next: "Новый код",
    confirm: "Повторите новый код",
  };

  return (
    <div className="px-5 pt-safe">
      <h2 className="font-display text-3xl tracking-tight">Замок</h2>
      <p className="mt-1 font-reading text-sm text-muted">Код, блокировка и этот телефон.</p>

      <div className="mt-6 space-y-3">
        <Button variant="sage" size="lg" className="w-full" onClick={lock}>
          Заблокировать
        </Button>
        {step === "idle" ? (
          <Button
            variant="outline"
            size="lg"
            className="w-full"
            onClick={() => {
              setMessage("");
              setStep("old");
            }}
          >
            Сменить код
          </Button>
        ) : (
          <div className="rounded-2xl bg-ink-2 px-4 py-5 shadow-border">
            <p className="text-center text-sm text-muted">{captions[step]}</p>
            <div className="mt-4">
              <PinDots value={pin} shake={shake} />
            </div>
            <p className="mt-3 h-5 text-center text-sm text-danger" role="alert">
              {error}
            </p>
            <PinPad value={pin} onChange={setPin} onComplete={onComplete} disabled={busy} />
            <button
              type="button"
              onClick={resetFlow}
              className="mt-2 w-full py-2 text-center text-sm text-muted"
            >
              Отмена
            </button>
          </div>
        )}
      </div>

      {message && <p className="mt-4 text-center text-sm text-sage">{message}</p>}

      <div className="mt-10 border-t border-cream/10 pt-6">
        {!wipe ? (
          <button
            type="button"
            onClick={() => setWipe(true)}
            className="text-sm text-faint underline-offset-4 hover:text-danger hover:underline"
          >
            Стереть сейф
          </button>
        ) : (
          <div className="space-y-3">
            <p className="font-reading text-sm leading-relaxed text-cream-2">
              Код, свои тексты и закладки будут удалены с этого телефона.
            </p>
            <div className="flex gap-2">
              <Button
                variant="danger"
                size="sm"
                onClick={() => {
                  resetVault();
                  lock();
                }}
              >
                Стереть
              </Button>
              <Button variant="ghost" size="sm" onClick={() => setWipe(false)}>
                Отмена
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
