import React, { useState, useEffect } from 'react';
import { AppItem } from '../types/launcher';
import { BrandIcon } from './BrandIcons';
import {
  X,
  Play,
  Terminal,
  Copy,
  Check,
  Smartphone,
  ExternalLink,
  Tv
} from 'lucide-react';

interface DeepLinkModalProps {
  app: AppItem | null;
  onClose: () => void;
  onLaunchIntent: (uri: string, fallback: string) => void;
}

export const DeepLinkModal: React.FC<DeepLinkModalProps> = ({
  app,
  onClose,
  onLaunchIntent,
}) => {
  const [copied, setCopied] = useState<boolean>(false);
  const [focusIndex, setFocusIndex] = useState<number>(0);

  // Targets:
  // 0: "Launch on Device" (Primary)
  // 1: "Open Web Service"
  // 2: "Copy ADB Command"
  // 3: "Close" button
  const totalTargets = 4;

  useEffect(() => {
    if (app) setFocusIndex(0);
  }, [app]);

  if (!app) return null;

  const adbCommand = `adb shell am start -a android.intent.action.VIEW -d "${app.deepLinkUri}" ${app.packageName}`;

  const handleCopyAdb = () => {
    navigator.clipboard.writeText(adbCommand).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const handleLaunchDirect = () => {
    onLaunchIntent(app.deepLinkUri, app.webFallbackUrl);
  };

  // Keyboard and remote navigation inside modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.keyCode === 22) {
        e.preventDefault();
        setFocusIndex((prev) => (prev < totalTargets - 1 ? prev + 1 : 0));
      } else if (e.key === 'ArrowLeft' || e.keyCode === 21) {
        e.preventDefault();
        setFocusIndex((prev) => (prev > 0 ? prev - 1 : totalTargets - 1));
      } else if (e.key === 'ArrowDown' || e.keyCode === 20) {
        e.preventDefault();
        setFocusIndex((prev) => (prev < totalTargets - 1 ? prev + 1 : 0));
      } else if (e.key === 'ArrowUp' || e.keyCode === 19) {
        e.preventDefault();
        setFocusIndex((prev) => (prev > 0 ? prev - 1 : totalTargets - 1));
      } else if (e.key === 'Enter' || e.key === ' ' || e.keyCode === 23 || e.keyCode === 66) {
        e.preventDefault();
        if (focusIndex === 0) {
          handleLaunchDirect();
        } else if (focusIndex === 1) {
          window.open(app.webFallbackUrl, '_blank');
        } else if (focusIndex === 2) {
          handleCopyAdb();
        } else if (focusIndex === 3) {
          onClose();
        }
      } else if (e.key === 'Escape' || e.key === 'Backspace' || e.keyCode === 4 || e.keyCode === 111) {
        e.preventDefault();
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [focusIndex, totalTargets, app, onClose]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in select-none"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-xl bg-gradient-to-b from-[#181b22] to-[#0f1116] border border-white/20 rounded-3xl shadow-2xl p-6 md:p-8 text-white overflow-hidden animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Ambient Top Glow */}
        <div
          className="absolute -top-20 left-1/2 -translate-x-1/2 w-96 h-40 rounded-full opacity-25 pointer-events-none"
          style={{ background: `radial-gradient(circle, ${app.accentColor} 0%, rgba(0,0,0,0) 70%)` }}
        />

        {/* Header Bar */}
        <div className="flex items-start justify-between relative z-10 mb-6">
          <div className="flex items-center gap-4">
            <div
              className="w-16 h-16 rounded-2xl flex items-center justify-center shadow-lg border border-white/15 shrink-0"
              style={{ background: app.iconBgGradient }}
            >
              <BrandIcon brandKey={app.brandKey} size={36} className="w-9 h-9" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-2xl font-bold tracking-tight text-white">{app.title}</h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono tracking-wider bg-white/10 text-slate-300 border border-white/10">
                  Android TV
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">{app.subtitle}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className={`p-2 rounded-full transition-all cursor-pointer outline-hidden ${
              focusIndex === 3 ? 'bg-white text-slate-950 ring-2 ring-white' : 'bg-white/10 text-slate-300 hover:text-white'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Deep Linking & Android Intent Details */}
        <div className="space-y-3 mb-6 text-xs">
          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Smartphone className="w-4 h-4 text-emerald-400 shrink-0" />
              <div>
                <p className="text-[10px] uppercase font-mono tracking-wider text-slate-400">Package Identifier</p>
                <p className="font-mono text-slate-200 mt-0.5 text-xs">{app.packageName}</p>
              </div>
            </div>
            <span className="text-[11px] text-slate-400 font-medium">Android Package</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Tv className="w-4 h-4 text-sky-400 shrink-0" />
              <div>
                <p className="text-[10px] uppercase font-mono tracking-wider text-slate-400">Deep Link URI Scheme</p>
                <p className="font-mono text-slate-200 mt-0.5 truncate max-w-sm text-xs">{app.deepLinkUri}</p>
              </div>
            </div>
            <span className="text-[11px] text-slate-400 font-medium">Protocol</span>
          </div>

          {/* ADB Command Box (Item 2) */}
          <div
            className={`p-3.5 rounded-2xl border transition-all ${
              focusIndex === 2 ? 'bg-black/80 border-white ring-4 ring-white' : 'bg-black/50 border-white/10'
            }`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <span className="flex items-center gap-1.5 text-[10px] font-semibold font-mono uppercase tracking-wider text-amber-400">
                <Terminal className="w-3.5 h-3.5" />
                ADB Shell Intent
              </span>
              <button
                onClick={handleCopyAdb}
                className={`flex items-center gap-1 text-[11px] px-2 py-0.5 rounded transition-all cursor-pointer ${
                  focusIndex === 2 ? 'bg-amber-400 text-slate-950 font-bold' : 'bg-white/10 text-slate-300 hover:text-white'
                }`}
              >
                {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <p className="font-mono text-[11px] text-slate-300 break-all select-all">{adbCommand}</p>
          </div>
        </div>

        {/* Action Buttons (Items 0, 1, 3) */}
        <div className="flex items-center justify-end gap-3 pt-2 border-t border-white/10 text-xs">
          <button
            onClick={onClose}
            className={`px-5 py-2.5 rounded-xl font-medium transition-all cursor-pointer outline-hidden ${
              focusIndex === 3 ? 'bg-white text-slate-950 ring-4 ring-white font-bold' : 'bg-white/10 text-slate-300 hover:text-white'
            }`}
          >
            Close
          </button>

          <a
            href={app.webFallbackUrl}
            target="_blank"
            rel="noopener noreferrer"
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl border transition-all cursor-pointer outline-hidden ${
              focusIndex === 1
                ? 'bg-white text-slate-950 ring-4 ring-white font-bold border-white'
                : 'bg-white/10 hover:bg-white/20 text-white border-white/15'
            }`}
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Open Web Service</span>
          </a>

          <button
            onClick={handleLaunchDirect}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold shadow-xl transition-all cursor-pointer outline-hidden ${
              focusIndex === 0
                ? 'bg-white text-slate-950 ring-4 ring-white scale-105'
                : 'bg-white/80 hover:bg-white text-slate-950'
            }`}
          >
            <Play className="w-3.5 h-3.5 fill-slate-950" />
            <span>Launch on Device</span>
          </button>
        </div>
      </div>
    </div>
  );
};
