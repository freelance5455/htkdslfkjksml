import React from 'react';
import avatarImg from '../assets/images/avatar_partner_1790441294858.jpg';
import { SessionState } from '../types';

interface AvatarDisplayProps {
  sessionState: SessionState;
  latestTranscript: string;
  isAudioActive: boolean;
}

export const AvatarDisplay: React.FC<AvatarDisplayProps> = ({
  sessionState,
  latestTranscript,
  isAudioActive,
}) => {
  const isSpeaking = sessionState === 'SPEAKING' || isAudioActive;
  const isListening = sessionState === 'LISTENING';

  // Fallback greeting or latest companion message
  const speechText =
    latestTranscript ||
    (sessionState === 'CONNECTING'
      ? 'Connecting with you...'
      : 'Hey... kya haal hai? Aaj ka mood kaisa hai? 😉');

  return (
    <div className="relative flex flex-col items-center justify-center w-full max-w-sm mx-auto my-2 select-none">
      {/* Speech Bubble (Top Right) */}
      <div className="relative z-10 w-full flex justify-end px-4 mb-2 min-h-[56px]">
        <div className="relative max-w-[240px] px-3.5 py-2.5 rounded-2xl glass-panel border border-purple-500/30 text-xs sm:text-sm text-purple-100 shadow-xl backdrop-blur-xl animate-fade-in">
          <p className="leading-relaxed font-medium line-clamp-3">{speechText}</p>
          {/* Bubble tail */}
          <div className="absolute -bottom-1.5 right-6 w-3 h-3 bg-[#0d1224] border-r border-b border-purple-500/30 transform rotate-45" />
        </div>
      </div>

      {/* Avatar Container with Astrology Chakra Mandala Behind */}
      <div className="relative flex items-center justify-center w-64 h-64 sm:w-72 sm:h-72">
        {/* Outermost Neon Glow Aura */}
        <div
          className={`absolute inset-0 rounded-full bg-gradient-to-tr from-purple-600/40 via-pink-600/30 to-cyan-500/40 blur-2xl transition-all duration-700 ${
            isSpeaking
              ? 'scale-125 opacity-100'
              : isListening
              ? 'scale-110 opacity-75 animate-pulse'
              : 'scale-95 opacity-50'
          }`}
        />

        {/* Astrological Chakra / Mandala Rotating Ring 1 */}
        <div className="absolute inset-2 rounded-full border border-purple-500/40 border-dashed animate-spin-slow pointer-events-none" />

        {/* Astrological Mandala Ring 2 with Zodiac runes / glyphs */}
        <div className="absolute inset-5 rounded-full border border-cyan-400/30 border-dotted animate-spin-reverse-slow pointer-events-none flex items-center justify-center">
          <div className="absolute top-1 text-[10px] text-cyan-300/70">♈</div>
          <div className="absolute bottom-1 text-[10px] text-purple-300/70">♎</div>
          <div className="absolute left-1 text-[10px] text-pink-300/70">♋</div>
          <div className="absolute right-1 text-[10px] text-cyan-300/70">♑</div>
        </div>

        {/* Pulsing Neon Inner Ring */}
        <div
          className={`absolute inset-7 rounded-full border-2 transition-all duration-300 pointer-events-none ${
            isSpeaking
              ? 'border-purple-400 shadow-[0_0_25px_rgba(168,85,247,0.7)]'
              : isListening
              ? 'border-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.5)]'
              : 'border-purple-500/30'
          }`}
        />

        {/* Companion Avatar Image Circle */}
        <div className="relative w-48 h-48 sm:w-56 sm:h-56 rounded-full overflow-hidden border-2 border-purple-400/50 shadow-2xl z-0 transition-transform duration-500">
          <img
            src={avatarImg}
            alt="AI Partner"
            className={`w-full h-full object-cover object-top transition-transform duration-700 ${
              isSpeaking ? 'scale-105' : 'scale-100'
            }`}
          />
          {/* Subtle gradient vignette at bottom of image */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#070913]/60 via-transparent to-transparent pointer-events-none" />
        </div>
      </div>

      {/* Companion Title & Subtitle */}
      <div className="text-center mt-3 z-10">
        <h2 className="text-lg font-bold text-white tracking-wide">Your AI Companion</h2>
        <p className="text-xs text-slate-400 font-medium tracking-wider mt-0.5">
          Smart • Playful • Always Here
        </p>
      </div>
    </div>
  );
};
