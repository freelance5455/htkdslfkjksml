import React from 'react';
import { Book, ReadingStatus } from '../../types';
import {
  BookOpen,
  Info,
  CheckCircle,
  FolderPlus,
  Heart,
  Edit3,
  Trash2,
  X,
} from 'lucide-react';

interface LibraryContextMenuProps {
  book: Book;
  isOpen: boolean;
  onClose: () => void;
  onContinueReading: (book: Book) => void;
  onViewDetails: (book: Book) => void;
  onChangeStatus: (book: Book, status: ReadingStatus) => void;
  onAddToCollection: (book: Book) => void;
  onToggleFavorite: (book: Book) => void;
  onEdit: (book: Book) => void;
  onDelete: (book: Book) => void;
}

export const LibraryContextMenu: React.FC<LibraryContextMenuProps> = ({
  book,
  isOpen,
  onClose,
  onContinueReading,
  onViewDetails,
  onChangeStatus,
  onAddToCollection,
  onToggleFavorite,
  onEdit,
  onDelete,
}) => {
  if (!isOpen) return null;

  const nextStatusMap: Record<ReadingStatus, ReadingStatus> = {
    'POR LEER': 'LEYENDO',
    'LEYENDO': 'TERMINADO',
    'TERMINADO': 'POR LEER',
    'ABANDONADO': 'POR LEER',
    'RELECTURA': 'TERMINADO',
  };

  const nextStatusLabel: Record<ReadingStatus, string> = {
    'POR LEER': 'Pasar a "Leyendo"',
    'LEYENDO': 'Marcar como "Terminado"',
    'TERMINADO': 'Reabrir a "Por leer"',
    'ABANDONADO': 'Reanudar lectura',
    'RELECTURA': 'Completar relectura',
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-3 bg-black/60 backdrop-blur-sm animate-fadeIn"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm glass-panel rounded-2xl p-4 border border-white/15 shadow-2xl space-y-1.5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-2">
          <div className="min-w-0 pr-2">
            <h4 className="text-sm font-bold text-white truncate">{book.title}</h4>
            <p className="text-xs text-zinc-400 truncate">{book.author}</p>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-lg bg-white/[0.05] hover:bg-white/10 flex items-center justify-center text-zinc-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 1. Continuar leyendo */}
        <button
          onClick={() => {
            onClose();
            onContinueReading(book);
          }}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 active:bg-white/20 text-sm text-white font-semibold transition-colors"
        >
          <BookOpen className="w-4 h-4 text-white" />
          <span>Continuar leyendo</span>
        </button>

        {/* 2. Ver detalles */}
        <button
          onClick={() => {
            onClose();
            onViewDetails(book);
          }}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/[0.08] active:bg-white/[0.12] text-sm text-zinc-200 transition-colors"
        >
          <Info className="w-4 h-4 text-zinc-300" />
          <span>Ver detalles</span>
        </button>

        {/* 3. Cambiar estado */}
        <button
          onClick={() => {
            onClose();
            onChangeStatus(book, nextStatusMap[book.status]);
          }}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/[0.08] active:bg-white/[0.12] text-sm text-zinc-200 transition-colors"
        >
          <CheckCircle className="w-4 h-4 text-zinc-300" />
          <span>{nextStatusLabel[book.status]}</span>
        </button>

        {/* 4. Añadir a colección */}
        <button
          onClick={() => {
            onClose();
            onAddToCollection(book);
          }}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/[0.08] active:bg-white/[0.12] text-sm text-zinc-200 transition-colors"
        >
          <FolderPlus className="w-4 h-4 text-zinc-300" />
          <span>Añadir a colección</span>
        </button>

        {/* 5. Favorito */}
        <button
          onClick={() => {
            onClose();
            onToggleFavorite(book);
          }}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/[0.08] active:bg-white/[0.12] text-sm text-zinc-200 transition-colors"
        >
          <Heart className={`w-4 h-4 ${book.favorite ? 'text-white fill-white' : 'text-zinc-400'}`} />
          <span>{book.favorite ? 'Quitar de favoritos' : 'Marcar como favorito'}</span>
        </button>

        {/* 6. Editar */}
        <button
          onClick={() => {
            onClose();
            onEdit(book);
          }}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/[0.08] active:bg-white/[0.12] text-sm text-zinc-200 transition-colors"
        >
          <Edit3 className="w-4 h-4 text-zinc-300" />
          <span>Editar libro</span>
        </button>

        {/* 7. Eliminar */}
        <button
          onClick={() => {
            onClose();
            onDelete(book);
          }}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/[0.08] active:bg-white/[0.12] text-sm text-zinc-300 font-medium transition-colors"
        >
          <Trash2 className="w-4 h-4 text-zinc-400" />
          <span>Eliminar definitivamente</span>
        </button>
      </div>
    </div>
  );
};
