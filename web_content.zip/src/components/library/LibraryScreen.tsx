import React, { useState, useMemo } from 'react';
import { useMusic } from '../../context/MusicContext';
import { LibraryTab } from '../../types/music';
import { SongCard } from '../cards/SongCard';
import { MusicListItem } from '../cards/MusicListItem';
import { PlaylistCard } from '../cards/PlaylistCard';
import { ArtistCard } from '../cards/ArtistCard';
import { AlbumCard } from '../cards/AlbumCard';
import { CreatePlaylistModal } from '../modals/CreatePlaylistModal';
import {
  ListMusic,
  Heart,
  Disc3,
  User,
  Clock,
  Plus,
  ArrowUpDown,
  Grid,
  List,
  Play
} from 'lucide-react';

type SortOption = 'recently_added' | 'recently_played' | 'az';

export const LibraryScreen: React.FC = () => {
  const {
    playlists,
    songs,
    artists,
    albums,
    likedSongIds,
    listeningHistory,
    playSong,
    setSelectedPlaylistId
  } = useMusic();

  const [activeTab, setActiveTab] = useState<LibraryTab>('playlists');
  const [sortOption, setSortOption] = useState<SortOption>('recently_added');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showCreateModal, setShowCreateModal] = useState(false);

  // Liked songs list
  const likedSongs = useMemo(() => {
    return songs.filter((s) => likedSongIds.includes(s.id));
  }, [songs, likedSongIds]);

  // Sort function helper
  const sortItems = <T extends { title?: string; name?: string }>(items: T[]): T[] => {
    if (sortOption === 'az') {
      return [...items].sort((a, b) =>
        (a.title || a.name || '').localeCompare(b.title || b.name || '')
      );
    }
    return items;
  };

  const tabs: { id: LibraryTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'playlists', label: 'Playlists', icon: ListMusic },
    { id: 'liked', label: 'Liked Songs', icon: Heart },
    { id: 'albums', label: 'Albums', icon: Disc3 },
    { id: 'artists', label: 'Artists', icon: User },
    { id: 'recent', label: 'Recent', icon: Clock }
  ];

  return (
    <div className="space-y-5 pb-24 pt-2 max-w-4xl mx-auto px-1">
      {/* Top Header Row with Create Playlist & View Options */}
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="font-display font-extrabold text-2xl text-white tracking-tight">
            Your Library
          </h2>
          <p className="text-xs text-slate-400">Manage all your collections in one place</p>
        </div>

        <div className="flex items-center gap-2">
          {/* Create Playlist Button */}
          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 active:scale-95 text-white font-semibold text-xs shadow-md transition-all"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">New Playlist</span>
          </button>
        </div>
      </div>

      {/* Tabs list */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold shrink-0 transition-all ${
                isActive
                  ? 'bg-white text-black shadow-md'
                  : 'bg-white/[0.04] text-slate-400 hover:text-white hover:bg-white/[0.08] border border-white/[0.05]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Filter and View Toggles Bar */}
      <div className="flex items-center justify-between pb-2 border-b border-white/[0.08] text-xs">
        {/* Sort Select */}
        <div className="flex items-center gap-2">
          <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
          <select
            value={sortOption}
            onChange={(e) => setSortOption(e.target.value as SortOption)}
            className="bg-transparent text-slate-300 font-medium focus:outline-none cursor-pointer"
          >
            <option value="recently_added" className="bg-[#141622] text-white">Recently Added</option>
            <option value="recently_played" className="bg-[#141622] text-white">Recently Played</option>
            <option value="az" className="bg-[#141622] text-white">A–Z Alphabetical</option>
          </select>
        </div>

        {/* View Toggle */}
        <div className="flex items-center gap-1 bg-white/[0.04] p-1 rounded-xl border border-white/[0.06]">
          <button
            onClick={() => setViewMode('grid')}
            title="Grid view"
            className={`p-1 rounded-lg transition-colors ${
              viewMode === 'grid' ? 'bg-white/10 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Grid className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setViewMode('list')}
            title="List view"
            className={`p-1 rounded-lg transition-colors ${
              viewMode === 'list' ? 'bg-white/10 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            <List className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Tab Content Panels */}
      {activeTab === 'playlists' && (
        <div className="space-y-4">
          {playlists.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-xs">
              No playlists found. Create one now!
            </div>
          ) : viewMode === 'grid' ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {sortItems(playlists).map((playlist) => (
                <PlaylistCard
                  key={playlist.id}
                  playlist={playlist}
                  onClick={() => setSelectedPlaylistId(playlist.id)}
                />
              ))}
            </div>
          ) : (
            <div className="space-y-2">
              {sortItems(playlists).map((playlist) => (
                <div
                  key={playlist.id}
                  onClick={() => setSelectedPlaylistId(playlist.id)}
                  className="flex items-center justify-between p-3 rounded-2xl bg-white/[0.03] hover:bg-white/[0.06] border border-white/[0.05] cursor-pointer transition-all"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-purple-600/30 flex items-center justify-center font-bold text-white text-xs">
                      {playlist.title[0]}
                    </div>
                    <div>
                      <p className="font-semibold text-sm text-white">{playlist.title}</p>
                      <p className="text-xs text-slate-400">{playlist.songIds.length} tracks · By {playlist.creator}</p>
                    </div>
                  </div>
                  <Play className="w-4 h-4 text-slate-400" />
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {activeTab === 'liked' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400">{likedSongs.length} liked songs</span>
            {likedSongs.length > 0 && (
              <button
                onClick={() => playSong(likedSongs[0], likedSongs)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-purple-600 text-white text-xs font-semibold hover:bg-purple-500 shadow-md"
              >
                <Play className="w-3.5 h-3.5 fill-white" />
                <span>Play All</span>
              </button>
            )}
          </div>

          {likedSongs.length === 0 ? (
            <div className="text-center py-16 px-4">
              <Heart className="w-10 h-10 text-pink-500/40 mx-auto mb-3" />
              <p className="text-sm font-semibold text-slate-200">No liked songs yet</p>
              <p className="text-xs text-slate-400 mt-1">
                Tap the heart on any song while listening to build your favorites collection.
              </p>
            </div>
          ) : viewMode === 'grid' ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {sortItems(likedSongs).map((song) => (
                <SongCard key={song.id} song={song} contextQueue={likedSongs} />
              ))}
            </div>
          ) : (
            <div className="space-y-1.5 bg-white/[0.02] p-2 rounded-2xl border border-white/[0.04]">
              {sortItems(likedSongs).map((song) => (
                <MusicListItem key={song.id} song={song} contextQueue={likedSongs} />
              ))}
            </div>
          )}
        </div>
      )}

      {activeTab === 'albums' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {sortItems(albums).map((album) => (
            <AlbumCard key={album.id} album={album} />
          ))}
        </div>
      )}

      {activeTab === 'artists' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {sortItems(artists).map((artist) => (
            <ArtistCard key={artist.id} artist={artist} />
          ))}
        </div>
      )}

      {activeTab === 'recent' && (
        <div className="space-y-2 bg-white/[0.02] p-2 rounded-2xl border border-white/[0.04]">
          {listeningHistory.map((song, i) => (
            <MusicListItem
              key={`${song.id}-${i}`}
              song={song}
              contextQueue={listeningHistory}
            />
          ))}
        </div>
      )}

      {/* Create Playlist Modal */}
      <CreatePlaylistModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
      />
    </div>
  );
};
