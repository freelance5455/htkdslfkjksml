import React, { useState, useMemo } from 'react';
import {
  Book,
  ReadingStatus,
  ShelfViewMode,
  SortOption,
  LedSettings,
  Collection,
  ShelfBookSize,
} from '../../types';
import { CoverImage } from '../common/CoverImage';
import { EmptyState } from '../common/EmptyState';
import { StarRating } from '../common/StarRating';
import { LibraryContextMenu } from './LibraryContextMenu';
import { ShelfDecorationsManagerModal, ShelfDecorationItem } from './ShelfDecorationsManagerModal';
import {
  BookOpen,
  LayoutGrid,
  List,
  SlidersHorizontal,
  Heart,
  X,
  MoreVertical,
  Layers,
  ZoomIn,
  Upload,
  Sparkles,
  Trash2,
  Plus,
} from 'lucide-react';

interface LibraryViewProps {
  books: Book[];
  collections: Collection[];
  viewMode: ShelfViewMode;
  sortOption: SortOption;
  bookSize: ShelfBookSize;
  ledSettings: LedSettings;
  onViewModeChange: (mode: ShelfViewMode) => void;
  onSortChange: (sort: SortOption) => void;
  onBookSizeChange: (size: ShelfBookSize) => void;
  onLedChange: (led: LedSettings) => void;
  onOpenBookDetail: (book: Book) => void;
  onOpenReader: (book: Book) => void;
  onOpenAddBook: () => void;
  onOpenImportBook?: () => void;
  onEditBook: (book: Book) => void;
  onDeleteBook: (book: Book) => void;
  onToggleFavorite: (book: Book) => void;
  onChangeStatus: (book: Book, status: ReadingStatus) => void;
  onAddToCollection: (book: Book) => void;
}

export const LibraryView: React.FC<LibraryViewProps> = ({
  books,
  collections,
  viewMode,
  sortOption,
  bookSize,
  ledSettings,
  onViewModeChange,
  onSortChange,
  onBookSizeChange,
  onLedChange,
  onOpenBookDetail,
  onOpenReader,
  onOpenAddBook,
  onOpenImportBook,
  onEditBook,
  onDeleteBook,
  onToggleFavorite,
  onChangeStatus,
  onAddToCollection,
}) => {
  // Filters State
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [favoriteOnly, setFavoriteOnly] = useState(false);
  const [selectedGenre, setSelectedGenre] = useState<string>('ALL');
  const [selectedCollection, setSelectedCollection] = useState<string>('ALL');
  const [selectedSaga, setSelectedSaga] = useState<string>('ALL');
  const [selectedTag, setSelectedTag] = useState<string>('ALL');
  const [showFiltersPanel, setShowFiltersPanel] = useState(false);

  // Context Menu State
  const [activeMenuBook, setActiveMenuBook] = useState<Book | null>(null);

  // Requirement 7: Decoraciones PNG en la Estantería (Persistidas en localStorage)
  const [shelfDecorations, setShelfDecorations] = useState<ShelfDecorationItem[]>(() => {
    try {
      const saved = localStorage.getItem('mi_biblioteca_shelf_decorations_v1');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [isDecorationsModalOpen, setIsDecorationsModalOpen] = useState(false);
  const [selectedDecorationId, setSelectedDecorationId] = useState<string | null>(null);

  const saveDecorations = (newList: ShelfDecorationItem[]) => {
    setShelfDecorations(newList);
    try {
      localStorage.setItem('mi_biblioteca_shelf_decorations_v1', JSON.stringify(newList));
    } catch (e) {
      console.warn('Failed saving shelf decorations to localStorage', e);
    }
  };

  const handleAddDecorationToShelf = (dec: ShelfDecorationItem) => {
    const updated = [...shelfDecorations, dec];
    saveDecorations(updated);
  };

  const handleRemoveDecoration = (id: string) => {
    const updated = shelfDecorations.filter((d) => d.id !== id);
    saveDecorations(updated);
    if (selectedDecorationId === id) setSelectedDecorationId(null);
  };

  const handleMoveDecoration = (id: string, deltaXPercent: number) => {
    const updated = shelfDecorations.map((d) => {
      if (d.id === id) {
        const nextX = Math.max(5, Math.min(92, d.xPercent + deltaXPercent));
        return { ...d, xPercent: nextX };
      }
      return d;
    });
    saveDecorations(updated);
  };

  const handleMoveShelf = (id: string, deltaShelf: number) => {
    const updated = shelfDecorations.map((d) => {
      if (d.id === id) {
        const nextShelf = Math.max(0, d.shelfIndex + deltaShelf);
        return { ...d, shelfIndex: nextShelf };
      }
      return d;
    });
    saveDecorations(updated);
  };

  const handleResizeDecoration = (id: string, deltaSize: number) => {
    const updated = shelfDecorations.map((d) => {
      if (d.id === id) {
        const nextSize = Math.max(40, Math.min(140, d.size + deltaSize));
        return { ...d, size: nextSize };
      }
      return d;
    });
    saveDecorations(updated);
  };

  // Collect available options for filters
  const allGenres = useMemo(() => {
    const set = new Set<string>();
    books.forEach((b) => b.genres?.forEach((g) => set.add(g)));
    return Array.from(set).sort();
  }, [books]);

  const allSagas = useMemo(() => {
    const set = new Set<string>();
    books.forEach((b) => {
      if (b.saga) set.add(b.saga);
    });
    return Array.from(set).sort();
  }, [books]);

  const allTags = useMemo(() => {
    const set = new Set<string>();
    books.forEach((b) => b.tags?.forEach((t) => set.add(t)));
    return Array.from(set).sort();
  }, [books]);

  // Filtered & Sorted books
  const filteredBooks = useMemo(() => {
    return books
      .filter((b) => {
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchTitle = b.title.toLowerCase().includes(q);
          const matchAuthor = b.author.toLowerCase().includes(q);
          const matchSaga = b.saga?.toLowerCase().includes(q) || false;
          const matchGenre = b.genres?.some((g) => g.toLowerCase().includes(q)) || false;
          const matchTag = b.tags?.some((t) => t.toLowerCase().includes(q)) || false;
          if (!matchTitle && !matchAuthor && !matchSaga && !matchGenre && !matchTag) {
            return false;
          }
        }

        if (statusFilter !== 'ALL' && b.status !== statusFilter) return false;
        if (favoriteOnly && !b.favorite) return false;
        if (selectedGenre !== 'ALL' && !b.genres?.includes(selectedGenre)) return false;
        if (selectedCollection !== 'ALL' && !b.collections?.includes(selectedCollection)) return false;
        if (selectedSaga !== 'ALL' && b.saga !== selectedSaga) return false;
        if (selectedTag !== 'ALL' && !b.tags?.includes(selectedTag)) return false;

        return true;
      })
      .sort((a, b) => {
        switch (sortOption) {
          case 'title':
            return a.title.localeCompare(b.title);
          case 'author':
            return a.author.localeCompare(b.author);
          case 'dateAdded':
            return new Date(b.dateAdded).getTime() - new Date(a.dateAdded).getTime();
          case 'progress':
            return b.progress - a.progress;
          case 'rating':
            return b.rating - a.rating;
          case 'status':
            return a.status.localeCompare(b.status);
          default:
            return 0;
        }
      });
  }, [
    books,
    searchQuery,
    statusFilter,
    favoriteOnly,
    selectedGenre,
    selectedCollection,
    selectedSaga,
    selectedTag,
    sortOption,
  ]);

  const hasActiveFilters =
    statusFilter !== 'ALL' ||
    favoriteOnly ||
    selectedGenre !== 'ALL' ||
    selectedCollection !== 'ALL' ||
    selectedSaga !== 'ALL' ||
    selectedTag !== 'ALL' ||
    searchQuery.trim().length > 0;

  const clearAllFilters = () => {
    setStatusFilter('ALL');
    setFavoriteOnly(false);
    setSelectedGenre('ALL');
    setSelectedCollection('ALL');
    setSelectedSaga('ALL');
    setSelectedTag('ALL');
    setSearchQuery('');
  };

  const statusBadge = (status: ReadingStatus) => {
    switch (status) {
      case 'LEYENDO':
        return <span className="text-[11px] font-semibold text-zinc-200">Leyendo</span>;
      case 'TERMINADO':
        return <span className="text-[11px] font-semibold text-zinc-300">Terminado</span>;
      case 'POR LEER':
        return <span className="text-[11px] font-semibold text-zinc-400">Por leer</span>;
      case 'ABANDONADO':
        return <span className="text-[11px] font-semibold text-zinc-500">Abandonado</span>;
    }
  };

  // Size styling maps for Shelf and Grid
  const shelfSizeMap = {
    small: {
      cols: 'grid-cols-4 sm:grid-cols-5 md:grid-cols-6',
      maxW: 'max-w-[95px] sm:max-w-[110px]',
      chunk: 6,
    },
    medium: {
      cols: 'grid-cols-3 sm:grid-cols-4 md:grid-cols-5',
      maxW: 'max-w-[125px] sm:max-w-[145px]',
      chunk: 4,
    },
    large: {
      cols: 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4',
      maxW: 'max-w-[155px] sm:max-w-[180px]',
      chunk: 3,
    },
  };

  const gridSizeMap = {
    small: 'grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7 gap-2.5',
    medium: 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5',
    large: 'grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-5',
  };

  const listCoverSizeMap = {
    small: 'w-10 sm:w-12',
    medium: 'w-14 sm:w-16',
    large: 'w-20 sm:w-24',
  };

  return (
    <div className="space-y-6 pb-16 animate-fadeIn">
      {/* Top Header / View Controls Row */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-['Syne']">
            Mi Biblioteca
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            {filteredBooks.length} {filteredBooks.length === 1 ? 'libro' : 'libros'} en total
          </p>
        </div>

        {/* View mode toggle, Size selector, and Actions */}
        <div className="flex items-center gap-2 self-end sm:self-auto flex-wrap">

          {/* Book Size Selector (Section 11) */}
          {(viewMode === 'shelf' || viewMode === 'grid') && (
            <div className="flex items-center p-1 bg-white/[0.04] border border-white/10 rounded-xl text-[11px]">
              {(['small', 'medium', 'large'] as const).map((sz) => (
                <button
                  key={sz}
                  onClick={() => onBookSizeChange(sz)}
                  style={
                    bookSize === sz
                      ? {
                          backgroundColor: 'var(--system-accent-muted, rgba(255,255,255,0.15))',
                          color: 'var(--system-accent, #ffffff)',
                        }
                      : undefined
                  }
                  className={`px-2 py-1 rounded-lg font-medium transition-all ${
                    bookSize === sz ? 'font-semibold' : 'text-zinc-400 hover:text-white'
                  }`}
                  title={`Tamaño ${sz === 'small' ? 'pequeño' : sz === 'medium' ? 'mediano' : 'grande'}`}
                >
                  {sz === 'small' ? 'P' : sz === 'medium' ? 'M' : 'G'}
                </button>
              ))}
            </div>
          )}

          {/* Adornos PNG Button for Shelf View (Requirement 7) */}
          {viewMode === 'shelf' && (
            <button
              onClick={() => setIsDecorationsModalOpen(true)}
              className="h-9 px-3 rounded-xl bg-white/[0.04] hover:bg-white/10 active:scale-95 border border-white/10 text-cyan-300 hover:text-white flex items-center gap-1.5 text-xs font-semibold shadow-sm transition-all"
              title="Añadir o gestionar adornos PNG en la estantería"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>Adornos PNG</span>
            </button>
          )}

          {/* Filter Bar Trigger */}
          <button
            onClick={() => setShowFiltersPanel(!showFiltersPanel)}
            className={`h-9 px-3 rounded-xl border flex items-center gap-1.5 text-xs font-semibold transition-all ${
              hasActiveFilters
                ? 'bg-white/15 border-white/30 text-white'
                : 'bg-white/[0.03] border-white/10 text-zinc-400 hover:text-white'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Filtros</span>
            {hasActiveFilters && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
          </button>

          {/* View Mode Segmented Switch (Exact 3 views: Estantería | Cuadrícula | Lista) */}
          <div className="flex items-center p-1 bg-white/[0.04] border border-white/10 rounded-xl">
            <button
              onClick={() => onViewModeChange('shelf')}
              title="Vista Estantería"
              style={
                viewMode === 'shelf'
                  ? {
                      backgroundColor: 'var(--system-accent-muted, rgba(255,255,255,0.15))',
                      color: 'var(--system-accent, #ffffff)',
                    }
                  : undefined
              }
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'shelf'
                  ? 'shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <Layers className="w-4 h-4" />
            </button>
            <button
              onClick={() => onViewModeChange('grid')}
              title="Vista Cuadrícula"
              style={
                viewMode === 'grid'
                  ? {
                      backgroundColor: 'var(--system-accent-muted, rgba(255,255,255,0.15))',
                      color: 'var(--system-accent, #ffffff)',
                    }
                  : undefined
              }
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'grid'
                  ? 'shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => onViewModeChange('list')}
              title="Vista Lista"
              style={
                viewMode === 'list'
                  ? {
                      backgroundColor: 'var(--system-accent-muted, rgba(255,255,255,0.15))',
                      color: 'var(--system-accent, #ffffff)',
                    }
                  : undefined
              }
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'list'
                  ? 'shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>

          {/* Quick Import Book Button */}
          <button
            onClick={onOpenImportBook || onOpenAddBook}
            className="h-9 px-3 rounded-xl bg-white/[0.05] hover:bg-white/10 active:scale-95 border border-white/10 text-zinc-200 hover:text-white flex items-center gap-1.5 text-xs font-semibold shadow-sm transition-all"
            title="Importar libro (.epub, .pdf, .txt, .json)"
          >
            <Upload className="w-3.5 h-3.5 text-zinc-300" />
            <span className="hidden sm:inline">Importar</span>
          </button>
        </div>
      </div>



      {/* Filters & Sorting Panel */}
      {showFiltersPanel && (
        <div className="glass-panel rounded-2xl p-4 sm:p-5 border border-white/15 shadow-xl space-y-4 animate-fadeIn">
          <div className="flex items-center justify-between pb-2 border-b border-white/10">
            <span className="text-xs font-semibold uppercase tracking-wider text-white/70">
              Filtros & Ordenamiento
            </span>
            {hasActiveFilters && (
              <button
                onClick={clearAllFilters}
                className="text-xs text-zinc-400 hover:text-white font-medium flex items-center gap-1"
              >
                <X className="w-3 h-3" /> Limpiar filtros
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
            {/* Status Filter */}
            <div>
              <label className="text-[11px] text-zinc-400 block mb-1 font-medium">Estado</label>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full bg-zinc-900 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/40"
              >
                <option value="ALL">Todos los estados</option>
                <option value="LEYENDO">Leyendo</option>
                <option value="POR LEER">Por leer</option>
                <option value="TERMINADO">Terminado</option>
                <option value="ABANDONADO">Abandonado</option>
              </select>
            </div>

            {/* Sort Option */}
            <div>
              <label className="text-[11px] text-zinc-400 block mb-1 font-medium">Ordenar por</label>
              <select
                value={sortOption}
                onChange={(e) => onSortChange(e.target.value as SortOption)}
                className="w-full bg-zinc-900 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/40"
              >
                <option value="title">Título (A-Z)</option>
                <option value="author">Autor (A-Z)</option>
                <option value="dateAdded">Fecha añadida</option>
                <option value="progress">Progreso de lectura</option>
                <option value="rating">Valoración</option>
                <option value="status">Estado</option>
              </select>
            </div>

            {/* Genre Filter */}
            {allGenres.length > 0 && (
              <div>
                <label className="text-[11px] text-zinc-400 block mb-1 font-medium">Género</label>
                <select
                  value={selectedGenre}
                  onChange={(e) => setSelectedGenre(e.target.value)}
                  className="w-full bg-zinc-900 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/40"
                >
                  <option value="ALL">Todos los géneros</option>
                  {allGenres.map((g) => (
                    <option key={g} value={g}>
                      {g}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Collection Filter */}
            {collections.length > 0 && (
              <div>
                <label className="text-[11px] text-zinc-400 block mb-1 font-medium">Colección</label>
                <select
                  value={selectedCollection}
                  onChange={(e) => setSelectedCollection(e.target.value)}
                  className="w-full bg-zinc-900 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/40"
                >
                  <option value="ALL">Todas las colecciones</option>
                  {collections.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Saga Filter */}
            {allSagas.length > 0 && (
              <div>
                <label className="text-[11px] text-zinc-400 block mb-1 font-medium">Saga</label>
                <select
                  value={selectedSaga}
                  onChange={(e) => setSelectedSaga(e.target.value)}
                  className="w-full bg-zinc-900 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/40"
                >
                  <option value="ALL">Todas las sagas</option>
                  {allSagas.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Tag Filter */}
            {allTags.length > 0 && (
              <div>
                <label className="text-[11px] text-zinc-400 block mb-1 font-medium">Etiqueta</label>
                <select
                  value={selectedTag}
                  onChange={(e) => setSelectedTag(e.target.value)}
                  className="w-full bg-zinc-900 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/40"
                >
                  <option value="ALL">Todas las etiquetas</option>
                  {allTags.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Favorite toggle button */}
            <div className="flex items-end">
              <button
                type="button"
                onClick={() => setFavoriteOnly(!favoriteOnly)}
                className={`w-full py-2 px-3 rounded-xl border flex items-center justify-center gap-2 transition-all ${
                  favoriteOnly
                    ? 'bg-white/15 border-white/30 text-white'
                    : 'bg-white/[0.04] border-white/10 text-zinc-400 hover:text-white'
                }`}
              >
                <Heart className={`w-3.5 h-3.5 ${favoriteOnly ? 'fill-white text-white' : ''}`} />
                <span>Solo favoritos</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* EMPTY STATE */}
      {filteredBooks.length === 0 ? (
        <EmptyState
          icon={BookOpen}
          title={books.length === 0 ? 'Tu biblioteca está vacía' : 'No hay libros que coincidan'}
          description={
            books.length === 0
              ? 'Comienza agregando tu primer libro a la colección.'
              : 'Prueba cambiando o limpiando los filtros seleccionados.'
          }
          actionLabel={books.length === 0 ? 'Agregar libro' : 'Limpiar filtros'}
          onAction={books.length === 0 ? onOpenAddBook : clearAllFilters}
        />
      ) : (
        <>
          {/* 1. MODO ESTANTERÍA REALISTA (Sections 7, 8, 9, 71) */}
          {viewMode === 'shelf' && (
            <div className="shelf-bookcase rounded-3xl p-4 sm:p-8 space-y-16 border border-white/[0.06] shadow-2xl relative">
              {(() => {
                const config = shelfSizeMap[bookSize];
                const shelves: Book[][] = [];
                for (let i = 0; i < filteredBooks.length; i += config.chunk) {
                  shelves.push(filteredBooks.slice(i, i + config.chunk));
                }

                return shelves.map((shelfBooks, shelfIdx) => (
                  <div key={shelfIdx} className="relative pt-8 pb-4">
                    {/* Books & User PNG Decorations physically resting directly on the wood shelf */}
                    <div className="relative z-10 flex items-end justify-between px-3 sm:px-6">
                      <div className={`grid ${config.cols} gap-4 sm:gap-8 flex-1 items-end`}>
                        {shelfBooks.map((book) => (
                          <div
                            key={book.id}
                            className="book-shelf-item group cursor-pointer transition-transform duration-300 hover:-translate-y-2 flex flex-col items-center justify-end relative"
                            onClick={() => onOpenBookDetail(book)}
                            onContextMenu={(e) => {
                              e.preventDefault();
                              setActiveMenuBook(book);
                            }}
                          >
                            {/* Physical Book Cover sitting directly on the shelf */}
                            <div className={`w-full ${config.maxW} relative transition-all duration-300 group-hover:drop-shadow-[0_14px_24px_rgba(0,0,0,0.7)]`}>
                              {/* 3D Book depth: realistic spine shadow, page edges, cover */}
                              <div className="relative overflow-hidden rounded-t-sm rounded-b-[1px] shadow-[2px_6px_16px_rgba(0,0,0,0.55),-1px_2px_8px_rgba(0,0,0,0.4)] border-l border-white/20">
                                <CoverImage
                                  url={book.coverUrl}
                                  title={book.title}
                                  author={book.author}
                                  className="w-full h-auto aspect-[2/3] object-cover block rounded-t-sm rounded-b-[1px]"
                                />

                                {/* Realistic spine bevel shadow */}
                                <div className="absolute inset-y-0 left-0 w-2 bg-gradient-to-r from-black/50 via-white/10 to-transparent pointer-events-none" />
                                {/* Paper edge side reflection */}
                                <div className="absolute inset-y-0 right-0 w-1 bg-gradient-to-l from-black/35 to-transparent pointer-events-none" />
                                {/* Top page edge highlight */}
                                <div className="absolute inset-x-0 top-0 h-1 bg-white/20 pointer-events-none" />
                              </div>

                              {/* Favorite marker (discreet top corner badge) */}
                              {book.favorite && (
                                <div className="absolute top-1.5 right-1.5 bg-black/70 backdrop-blur-sm p-1 rounded-full text-white pointer-events-none shadow-md">
                                  <Heart className="w-3 h-3 fill-white" />
                                </div>
                              )}

                              {/* Quick Read overlay button on hover */}
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onOpenReader(book);
                                }}
                                className="absolute bottom-2.5 right-2.5 px-2.5 py-1 rounded-xl bg-white text-zinc-950 font-bold text-[10px] shadow-lg opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 active:scale-95 z-20"
                                title="Leer este libro"
                              >
                                <BookOpen className="w-3 h-3" />
                                <span>Leer</span>
                              </button>

                              {/* More options button on hover */}
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setActiveMenuBook(book);
                                }}
                                className="absolute top-1.5 left-1.5 w-6 h-6 rounded-full bg-black/70 hover:bg-black text-white/90 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-md shadow-md z-20"
                                aria-label="Opciones del libro"
                              >
                                <MoreVertical className="w-3.5 h-3.5" />
                              </button>

                              {/* Contact shadow connecting the book bottom to the shelf plank */}
                              <div className="w-[94%] mx-auto h-2 -mt-1 bg-black/80 blur-[2px] rounded-full transform scale-x-95 pointer-events-none" />
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* User-imported PNG Shelf Decorations resting physically on the shelf plank (Section 5) */}
                      {shelfDecorations
                        .filter((dec) => dec.shelfIndex === shelfIdx)
                        .map((dec) => {
                          const isSelected = selectedDecorationId === dec.id;
                          return (
                            <div
                              key={dec.id}
                              className="absolute bottom-1 z-30 flex flex-col items-center select-none"
                              style={{
                                left: `${dec.xPercent}%`,
                                transform: 'translateX(-50%)',
                              }}
                            >
                              {/* Floating inline control toolbar when clicked */}
                              {isSelected && (
                                <div
                                  className="absolute -top-14 bg-zinc-950/95 border border-white/25 rounded-2xl p-1.5 flex items-center gap-1 shadow-2xl z-40 animate-fadeIn text-xs"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  <button
                                    type="button"
                                    onClick={() => handleMoveDecoration(dec.id, -6)}
                                    className="w-7 h-7 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center font-bold"
                                    title="Mover a la izquierda"
                                  >
                                    ←
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleMoveDecoration(dec.id, 6)}
                                    className="w-7 h-7 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center font-bold"
                                    title="Mover a la derecha"
                                  >
                                    →
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleMoveShelf(dec.id, -1)}
                                    disabled={dec.shelfIndex === 0}
                                    className="w-7 h-7 rounded-xl bg-white/10 hover:bg-white/20 disabled:opacity-30 text-white flex items-center justify-center font-bold"
                                    title="Subir de estante"
                                  >
                                    ↑
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleMoveShelf(dec.id, 1)}
                                    className="w-7 h-7 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center font-bold"
                                    title="Bajar de estante"
                                  >
                                    ↓
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleResizeDecoration(dec.id, -10)}
                                    className="w-7 h-7 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center font-bold"
                                    title="Reducir tamaño"
                                  >
                                    -
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleResizeDecoration(dec.id, 10)}
                                    className="w-7 h-7 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center font-bold"
                                    title="Aumentar tamaño"
                                  >
                                    +
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleRemoveDecoration(dec.id)}
                                    className="w-7 h-7 rounded-xl bg-red-500/20 hover:bg-red-500 text-red-300 hover:text-white flex items-center justify-center"
                                    title="Eliminar adorno"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              )}

                              {/* PNG image resting on the shelf with shadow */}
                              <img
                                src={dec.dataUrl}
                                alt={dec.name}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedDecorationId(isSelected ? null : dec.id);
                                }}
                                style={{
                                  height: `${dec.size}px`,
                                  maxHeight: `${dec.size}px`,
                                }}
                                className={`object-contain cursor-pointer transition-all hover:scale-105 drop-shadow-[0_10px_16px_rgba(0,0,0,0.95)] ${
                                  isSelected ? 'ring-2 ring-cyan-400 rounded-xl p-0.5' : ''
                                }`}
                                title={`${dec.name} (Toca para mover, escalar o eliminar)`}
                              />
                            </div>
                          );
                        })}
                    </div>

                    {/* Realistic Light Wood Shelf Plank (Natural wood grain, bevel, ambient shadow, NO LEDs) */}
                    <div className="relative -mt-1 z-20 pointer-events-none">
                      {/* Top physical depth surface of the light wood shelf */}
                      <div className="shelf-wood-surface w-full rounded-sm" />
                      {/* Front edge bevel of the light wood shelf */}
                      <div className="shelf-wood-front w-full rounded-b-md" />
                    </div>
                  </div>
                ));
              })()}
            </div>
          )}

          {/* 2. MODO CUADRÍCULA (CON ILUMINACIÓN ADAPTADA - Section 10) */}
          {viewMode === 'grid' && (
            <div className={`ambient-lighting-grid grid ${gridSizeMap[bookSize]}`}>
              {filteredBooks.map((book) => (
                <div
                  key={book.id}
                  onClick={() => onOpenBookDetail(book)}
                  onContextMenu={(e) => {
                    e.preventDefault();
                    setActiveMenuBook(book);
                  }}
                  className="glass-panel-interactive rounded-2xl p-3 flex flex-col justify-between group cursor-pointer border border-white/[0.08]"
                >
                  <div className="relative">
                    <CoverImage
                      url={book.coverUrl}
                      title={book.title}
                      author={book.author}
                      className="rounded-xl shadow-lg group-hover:scale-[1.02] transition-transform duration-300"
                    />
                    {book.favorite && (
                      <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-sm p-1 rounded-full text-white">
                        <Heart className="w-3 h-3 fill-white" />
                      </div>
                    )}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveMenuBook(book);
                      }}
                      className="absolute bottom-2 right-2 w-7 h-7 rounded-full bg-black/70 hover:bg-black text-white/80 hover:text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-md shadow-md"
                      aria-label="Opciones del libro"
                    >
                      <MoreVertical className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="mt-2.5 space-y-1">
                    <div className="flex items-center justify-between gap-1">
                      {statusBadge(book.status)}
                      {book.status === 'LEYENDO' && (
                        <span className="text-[10px] font-mono text-zinc-300 tabular-nums">
                          {book.progress}%
                        </span>
                      )}
                    </div>

                    <h3 className="text-xs sm:text-sm font-semibold text-white/95 line-clamp-1 group-hover:text-white transition-colors">
                      {book.title}
                    </h3>
                    <p className="text-[11px] text-zinc-400 line-clamp-1">{book.author}</p>

                    {/* Half-Star Rating (Section 18, 19) */}
                    {book.rating > 0 && (
                      <div className="pt-0.5">
                        <StarRating rating={book.rating} size="xs" showNumber />
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* 3. MODO LISTA (CON ILUMINACIÓN ADAPTADA - Section 10) */}
          {viewMode === 'list' && (
            <div className="ambient-lighting-grid glass-panel rounded-2xl border border-white/[0.08] divide-y divide-white/[0.05] overflow-hidden">
              {filteredBooks.map((book) => (
                <div
                  key={book.id}
                  onClick={() => onOpenBookDetail(book)}
                  onContextMenu={(e) => {
                    e.preventDefault();
                    setActiveMenuBook(book);
                  }}
                  className="p-3 sm:p-4 flex items-center gap-3.5 hover:bg-white/[0.02] transition-colors cursor-pointer group"
                >
                  <div className={`${listCoverSizeMap[bookSize]} shrink-0 transition-all duration-300`}>
                    <CoverImage
                      url={book.coverUrl}
                      title={book.title}
                      author={book.author}
                      className="rounded-md shadow-md"
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm sm:text-base font-semibold text-white/95 truncate group-hover:text-white transition-colors">
                        {book.title}
                      </h3>
                      {book.favorite && <Heart className="w-3.5 h-3.5 text-white fill-white shrink-0" />}
                    </div>
                    <p className="text-xs text-zinc-400 truncate">{book.author}</p>

                    <div className="flex items-center gap-3 mt-1 text-[11px] text-zinc-400 flex-wrap">
                      <span>{statusBadge(book.status)}</span>
                      {book.totalPages > 0 && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="tabular-nums">
                            {book.pagesRead} / {book.totalPages} págs
                          </span>
                        </>
                      )}
                      {book.rating > 0 && (
                        <>
                          <span aria-hidden="true">·</span>
                          <StarRating rating={book.rating} size="xs" showNumber />
                        </>
                      )}
                      {book.saga && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-zinc-400">{book.saga}</span>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Actions & Progress */}
                  <div className="flex items-center gap-3 shrink-0">
                    {book.status === 'LEYENDO' && (
                      <div className="hidden sm:block text-right">
                        <span className="text-xs font-mono font-semibold text-zinc-200 block tabular-nums">
                          {book.progress}%
                        </span>
                        <div className="w-16 h-1 rounded-full bg-white/10 overflow-hidden mt-1">
                          <div
                            className="h-full bg-zinc-200 rounded-full"
                            style={{ width: `${book.progress}%` }}
                          />
                        </div>
                      </div>
                    )}

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveMenuBook(book);
                      }}
                      className="w-8 h-8 rounded-lg bg-white/[0.05] hover:bg-white/10 flex items-center justify-center text-zinc-300 hover:text-white transition-colors"
                      aria-label="Menú del libro"
                    >
                      <MoreVertical className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {/* Bottom Floating Book Size Selector (Screens 5, 6, 7 in IMG_0575) */}
      <div className="sticky bottom-16 md:bottom-4 z-20 mx-auto max-w-sm w-full pt-3">
        <div className="glass-panel rounded-2xl p-2.5 px-4 border border-white/10 shadow-2xl flex items-center justify-between gap-3 backdrop-blur-xl">
          <span className="text-xs font-semibold text-zinc-300 whitespace-nowrap">
            Tamaño de libros
          </span>
          <div className="flex items-center p-1 bg-white/[0.05] border border-white/10 rounded-xl text-xs">
            {(['small', 'medium', 'large'] as const).map((sz) => (
              <button
                key={sz}
                onClick={() => onBookSizeChange(sz)}
                className={`px-3 py-1 rounded-lg font-medium transition-all ${
                  bookSize === sz
                    ? 'bg-white/20 text-white font-semibold shadow'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                {sz === 'small' ? 'Pequeño' : sz === 'medium' ? 'Mediano' : 'Grande'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Context Menu Modal */}
      {activeMenuBook && (
        <LibraryContextMenu
          book={activeMenuBook}
          isOpen={Boolean(activeMenuBook)}
          onClose={() => setActiveMenuBook(null)}
          onContinueReading={onOpenReader}
          onViewDetails={onOpenBookDetail}
          onChangeStatus={onChangeStatus}
          onAddToCollection={onAddToCollection}
          onToggleFavorite={onToggleFavorite}
          onEdit={onEditBook}
          onDelete={onDeleteBook}
        />
      )}

      {/* Requirement 7: Modal de Gestión de Adornos PNG para la Estantería */}
      <ShelfDecorationsManagerModal
        isOpen={isDecorationsModalOpen}
        onClose={() => setIsDecorationsModalOpen(false)}
        shelvesCount={Math.max(1, Math.ceil(filteredBooks.length / shelfSizeMap[bookSize].chunk))}
        decorations={shelfDecorations}
        onAddDecorationToShelf={handleAddDecorationToShelf}
        onRemoveDecoration={handleRemoveDecoration}
      />
    </div>
  );
};
