import React from 'react';

interface MiniShelfCandleProps {
  className?: string;
}

export const MiniShelfCandle: React.FC<MiniShelfCandleProps> = ({ className = '' }) => {
  return (
    <div
      className={`relative flex flex-col items-center select-none pointer-events-none ${className}`}
      title="Vela aromática de biblioteca"
      aria-hidden="true"
    >
      {/* Candle Flame with realistic soft warm flicker */}
      <div className="relative flex items-center justify-center -mb-0.5 z-10">
        {/* Ambient warm aura glow */}
        <div className="absolute w-8 h-8 rounded-full bg-amber-400/20 blur-md pointer-events-none animate-pulse" />
        
        {/* Teardrop flame body */}
        <div className="w-2.5 h-4 bg-gradient-to-t from-amber-500 via-yellow-300 to-white rounded-full shadow-[0_0_12px_rgba(251,191,36,0.85)]" />
        
        {/* Inner blue base */}
        <div className="absolute bottom-0 w-1.5 h-1.5 bg-blue-400/60 rounded-full blur-[0.5px]" />
        
        {/* Wick */}
        <div className="w-0.5 h-1.5 bg-zinc-800 -mb-1" />
      </div>

      {/* Wax Pillar Cylinder with glass holder */}
      <div className="w-7 h-9 rounded-t-sm rounded-b-md bg-gradient-to-r from-[#1c1511] via-[#2d221b] to-[#18120e] border border-amber-900/30 shadow-[0_4px_12px_rgba(0,0,0,0.8)] relative overflow-hidden flex flex-col justify-end p-0.5">
        {/* Warm light pooling inside top wax pool */}
        <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-b from-amber-400/40 to-transparent rounded-t-sm" />
        
        {/* Candle glass rim highlight */}
        <div className="absolute inset-0 bg-gradient-to-tr from-white/[0.05] via-transparent to-white/[0.1] rounded-b-md pointer-events-none" />
      </div>

      {/* Contact shadow on wood surface */}
      <div className="w-8 h-1.5 -mt-0.5 bg-black/80 rounded-full blur-[1.5px]" />
    </div>
  );
};
