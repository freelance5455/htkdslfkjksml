import React, { useState } from 'react';
import { X, Upload, Sparkles, Image as ImageIcon, Plus, Trash2, Check } from 'lucide-react';

export interface ShelfDecorationItem {
  id: string;
  shelfIndex: number; // 0-based
  xPercent: number; // 0 to 90%
  size: number; // 45 to 130px
  dataUrl: string;
  name: string;
}

interface ShelfDecorationsManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  shelvesCount: number;
  decorations: ShelfDecorationItem[];
  onAddDecorationToShelf: (decoration: ShelfDecorationItem) => void;
  onRemoveDecoration: (id: string) => void;
}

export const ShelfDecorationsManagerModal: React.FC<ShelfDecorationsManagerModalProps> = ({
  isOpen,
  onClose,
  shelvesCount,
  decorations,
  onAddDecorationToShelf,
  onRemoveDecoration,
}) => {
  if (!isOpen) return null;

  const [previewUrl, setPreviewUrl] = useState('');
  const [adornoName, setAdornoName] = useState('');
  const [selectedShelf, setSelectedShelf] = useState(0);
  const [selectedSize, setSelectedSize] = useState(70);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!adornoName) {
        setAdornoName(file.name.replace(/\.[^/.]+$/, ''));
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCreateAndPlace = (e: React.FormEvent) => {
    e.preventDefault();
    if (!previewUrl) return;

    const newAdorno: ShelfDecorationItem = {
      id: 'adorno-' + Date.now(),
      shelfIndex: selectedShelf,
      xPercent: 75, // Default position near the right edge
      size: selectedSize,
      dataUrl: previewUrl,
      name: adornoName.trim() || `Adorno #${decorations.length + 1}`,
    };

    onAddDecorationToShelf(newAdorno);
    setPreviewUrl('');
    setAdornoName('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-xl animate-fadeIn">
      <div className="w-full max-w-lg glass-panel rounded-3xl p-5 sm:p-6 border border-white/15 shadow-2xl flex flex-col justify-between max-h-[92vh] overflow-y-auto space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <h3 className="text-base font-bold text-white tracking-tight font-['Syne']">
              Adornos PNG para tu Estantería
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-lg bg-white/[0.05] hover:bg-white/10 flex items-center justify-center text-zinc-400 hover:text-white"
            title="Cerrar"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Upload Form (Strictly user's own PNGs as requested) */}
        <form onSubmit={handleCreateAndPlace} className="glass-panel-subtle rounded-2xl p-4 border border-white/[0.08] space-y-4 text-xs">
          <div>
            <label className="text-zinc-200 font-semibold block mb-1">
              Importar archivo PNG desde tu dispositivo
            </label>
            <p className="text-[11px] text-zinc-400">
              Sube tus figuras, plantas, velas, portarretratos o adornos en formato PNG transparente para colocarlos en los estantes.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {previewUrl ? (
              <div className="w-16 h-16 rounded-xl border border-white/20 overflow-hidden bg-black/40 shrink-0 flex items-center justify-center p-1 relative shadow-inner">
                <img src={previewUrl} alt="Preview" className="max-w-full max-h-full object-contain" />
              </div>
            ) : (
              <div className="w-16 h-16 rounded-xl border border-dashed border-white/20 bg-white/[0.02] shrink-0 flex items-center justify-center text-zinc-500">
                <ImageIcon className="w-6 h-6" />
              </div>
            )}

            <div className="flex-1 space-y-2">
              <input
                type="text"
                value={adornoName}
                onChange={(e) => setAdornoName(e.target.value)}
                placeholder="Nombre del adorno (ej. Planta, Trofeo, Vela...)"
                className="w-full bg-zinc-900/90 border border-white/15 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400"
              />
              <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.08] hover:bg-white/15 text-white font-medium cursor-pointer border border-white/10 transition-all text-xs">
                <Upload className="w-3.5 h-3.5 text-cyan-400" />
                <span>Elegir archivo PNG</span>
                <input
                  type="file"
                  accept="image/png,image/webp,image/*"
                  onChange={handleFileChange}
                  className="sr-only"
                />
              </label>
            </div>
          </div>

          {previewUrl && (
            <div className="grid grid-cols-2 gap-3 pt-2 border-t border-white/10">
              <div>
                <label className="text-[11px] font-semibold text-zinc-300 block mb-1">
                  Estante de destino
                </label>
                <select
                  value={selectedShelf}
                  onChange={(e) => setSelectedShelf(Number(e.target.value))}
                  className="w-full bg-zinc-900 border border-white/15 rounded-xl px-2.5 py-1.5 text-xs text-white"
                >
                  {Array.from({ length: Math.max(1, shelvesCount) }, (_, idx) => (
                    <option key={idx} value={idx}>
                      Estante {idx + 1}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-zinc-300 block mb-1">
                  Tamaño ({selectedSize}px)
                </label>
                <input
                  type="range"
                  min="45"
                  max="130"
                  value={selectedSize}
                  onChange={(e) => setSelectedSize(Number(e.target.value))}
                  className="w-full mt-2 accent-cyan-400"
                />
              </div>

              <div className="col-span-2 pt-1">
                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-white text-zinc-950 font-bold text-xs hover:bg-zinc-200 transition-all flex items-center justify-center gap-2 shadow-md active:scale-98"
                >
                  <Plus className="w-4 h-4" />
                  <span>Colocar adorno en la estantería</span>
                </button>
              </div>
            </div>
          )}
        </form>

        {/* Existing placed decorations */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white uppercase tracking-wider">
              Adornos colocados ({decorations.length})
            </span>
          </div>

          {decorations.length === 0 ? (
            <p className="text-xs text-zinc-400 italic text-center py-4 glass-panel-subtle rounded-2xl">
              No tienes adornos colocados aún. Puedes importar cualquier imagen PNG transparente y ubicarla libremente sobre los estantes.
            </p>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-48 overflow-y-auto p-1">
              {decorations.map((item) => (
                <div
                  key={item.id}
                  className="p-2.5 rounded-xl bg-white/[0.04] border border-white/10 flex flex-col items-center text-center gap-2 relative group"
                >
                  <button
                    onClick={() => onRemoveDecoration(item.id)}
                    className="absolute top-1 right-1 w-6 h-6 rounded-lg bg-red-500/20 text-red-300 hover:bg-red-500 hover:text-white flex items-center justify-center transition-all opacity-0 group-hover:opacity-100"
                    title="Eliminar de la estantería"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                  <div className="w-12 h-12 flex items-center justify-center p-1">
                    <img src={item.dataUrl} alt={item.name} className="max-w-full max-h-full object-contain drop-shadow" />
                  </div>
                  <div className="min-w-0 w-full">
                    <p className="text-[11px] font-semibold text-white truncate">{item.name}</p>
                    <span className="text-[10px] text-zinc-400 block font-mono">
                      Estante {item.shelfIndex + 1}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer tip */}
        <div className="pt-3 border-t border-white/10 flex items-center justify-between text-[11px] text-zinc-400">
          <span>Consejo: Toca cualquier adorno en la estantería para moverlo, cambiar su tamaño o eliminarlo.</span>
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded-xl bg-white/[0.08] hover:bg-white/15 text-white font-medium transition-all"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
