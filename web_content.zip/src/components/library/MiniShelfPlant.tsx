import React from 'react';

interface MiniShelfPlantProps {
  variant?: 0 | 1 | 2;
  className?: string;
}

export const MiniShelfPlant: React.FC<MiniShelfPlantProps> = ({ variant = 0, className = '' }) => {
  return (
    <div
      className={`relative flex flex-col items-center select-none pointer-events-none ${className}`}
      title="Planta decorativa de estantería"
    >
      {/* Plant variant 0: Miniature Succulent */}
      {variant === 0 && (
        <svg
          viewBox="0 0 60 70"
          className="w-10 h-14 sm:w-12 sm:h-16 drop-shadow-[0_8px_12px_rgba(0,0,0,0.8)]"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Leaves */}
          <path
            d="M30 10 C24 16 22 28 30 36 C38 28 36 16 30 10Z"
            fill="url(#succulentGrad1)"
          />
          <path
            d="M18 20 C14 26 18 34 26 36 C28 28 24 22 18 20Z"
            fill="url(#succulentGrad2)"
          />
          <path
            d="M42 20 C46 26 42 34 34 36 C32 28 36 22 42 20Z"
            fill="url(#succulentGrad3)"
          />
          <path
            d="M12 28 C8 34 14 40 24 40 C26 34 20 29 12 28Z"
            fill="url(#succulentGrad2)"
          />
          <path
            d="M48 28 C52 34 46 40 36 40 C34 34 40 29 48 28Z"
            fill="url(#succulentGrad3)"
          />
          <circle cx="30" cy="34" r="5" fill="#4ade80" />

          {/* Minimalist Matte Dark Ceramic Pot */}
          <path
            d="M16 40 L44 40 L40 64 L20 64 Z"
            fill="url(#potGrad)"
            stroke="#3f3f46"
            strokeWidth="1"
          />
          {/* Pot Rim Highlight */}
          <ellipse cx="30" cy="40" rx="14" ry="2" fill="#52525b" />
          <ellipse cx="30" cy="40" rx="13" ry="1.5" fill="#27272a" />

          {/* Pot Sheen */}
          <path
            d="M22 42 L25 62"
            stroke="rgba(255,255,255,0.15)"
            strokeWidth="1.5"
            strokeLinecap="round"
          />

          <defs>
            <linearGradient id="succulentGrad1" x1="30" y1="10" x2="30" y2="36" gradientUnits="userSpaceOnUse">
              <stop stopColor="#86efac" />
              <stop offset="0.6" stopColor="#22c55e" />
              <stop offset="1" stopColor="#15803d" />
            </linearGradient>
            <linearGradient id="succulentGrad2" x1="14" y1="20" x2="26" y2="36" gradientUnits="userSpaceOnUse">
              <stop stopColor="#a7f3d0" />
              <stop offset="0.7" stopColor="#10b981" />
              <stop offset="1" stopColor="#047857" />
            </linearGradient>
            <linearGradient id="succulentGrad3" x1="46" y1="20" x2="34" y2="36" gradientUnits="userSpaceOnUse">
              <stop stopColor="#6ee7b7" />
              <stop offset="0.7" stopColor="#059669" />
              <stop offset="1" stopColor="#065f46" />
            </linearGradient>
            <linearGradient id="potGrad" x1="16" y1="40" x2="44" y2="64" gradientUnits="userSpaceOnUse">
              <stop stopColor="#2d3139" />
              <stop offset="0.5" stopColor="#1f232b" />
              <stop offset="1" stopColor="#14171d" />
            </linearGradient>
          </defs>
        </svg>
      )}

      {/* Plant variant 1: Mini Trailing Vine Pot */}
      {variant === 1 && (
        <svg
          viewBox="0 0 60 76"
          className="w-10 h-14 sm:w-12 sm:h-16 drop-shadow-[0_8px_12px_rgba(0,0,0,0.8)]"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Stems & Leaves */}
          <path d="M26 36 C22 28 18 16 26 12 C34 16 30 26 28 36" stroke="#16a34a" strokeWidth="2" strokeLinecap="round" />
          <path d="M32 36 C38 26 44 18 38 12 C32 16 34 26 32 36" stroke="#22c55e" strokeWidth="1.8" strokeLinecap="round" />
          
          {/* Trailing Vine over the side */}
          <path d="M18 42 C14 48 10 56 14 66 C16 70 14 74 12 76" stroke="#15803d" strokeWidth="1.5" strokeLinecap="round" />
          <circle cx="13" cy="50" r="3" fill="#4ade80" />
          <circle cx="15" cy="62" r="3.5" fill="#22c55e" />
          <circle cx="13" cy="72" r="2.5" fill="#86efac" />

          {/* Top Leaf Cluster */}
          <circle cx="26" cy="12" r="4.5" fill="#4ade80" />
          <circle cx="38" cy="12" r="4" fill="#86efac" />
          <circle cx="22" cy="20" r="3.5" fill="#22c55e" />
          <circle cx="38" cy="22" r="4" fill="#16a34a" />

          {/* Dark Charcoal Ceramic Pot */}
          <path
            d="M17 38 L43 38 L39 60 L21 60 Z"
            fill="url(#potGradDark)"
            stroke="#3f3f46"
            strokeWidth="1"
          />
          <ellipse cx="30" cy="38" rx="13" ry="2" fill="#52525b" />
          <ellipse cx="30" cy="38" rx="12" ry="1.5" fill="#18181b" />

          <defs>
            <linearGradient id="potGradDark" x1="17" y1="38" x2="43" y2="60" gradientUnits="userSpaceOnUse">
              <stop stopColor="#332d29" />
              <stop offset="0.5" stopColor="#201b17" />
              <stop offset="1" stopColor="#14110e" />
            </linearGradient>
          </defs>
        </svg>
      )}

      {/* Plant variant 2: Compact Mini Bonsai / Jade */}
      {variant === 2 && (
        <svg
          viewBox="0 0 60 70"
          className="w-10 h-14 sm:w-12 sm:h-16 drop-shadow-[0_8px_12px_rgba(0,0,0,0.8)]"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Bonsai Trunk */}
          <path
            d="M30 42 C28 34 22 26 26 20 C28 16 32 18 31 14 C30 10 33 8 36 9 C38 14 34 22 36 30 C37 36 34 40 32 42 Z"
            fill="#5c4433"
          />
          {/* Foliage Clouds */}
          <circle cx="24" cy="18" r="8" fill="#15803d" />
          <circle cx="26" cy="16" r="6.5" fill="#22c55e" opacity="0.9" />
          <circle cx="36" cy="12" r="9" fill="#166534" />
          <circle cx="38" cy="11" r="7" fill="#4ade80" opacity="0.95" />
          <circle cx="44" cy="18" r="7" fill="#15803d" />
          <circle cx="43" cy="17" r="5.5" fill="#22c55e" opacity="0.9" />

          {/* Low Round Bonsai Planter */}
          <path
            d="M14 42 C14 42 16 58 20 60 L40 60 C44 58 46 42 46 42 Z"
            fill="url(#bonsaiPotGrad)"
            stroke="#52525b"
            strokeWidth="1"
          />
          <ellipse cx="30" cy="42" rx="16" ry="2.5" fill="#3f3f46" />
          <ellipse cx="30" cy="42" rx="15" ry="2" fill="#1c1917" />

          <defs>
            <linearGradient id="bonsaiPotGrad" x1="14" y1="42" x2="46" y2="60" gradientUnits="userSpaceOnUse">
              <stop stopColor="#3b332b" />
              <stop offset="0.6" stopColor="#251f1a" />
              <stop offset="1" stopColor="#171310" />
            </linearGradient>
          </defs>
        </svg>
      )}

      {/* Realistic contact shadow on top of the wood shelf plank */}
      <div className="w-10 sm:w-12 h-2.5 -mt-1 bg-black/90 rounded-full blur-[2px] opacity-80" />
    </div>
  );
};
