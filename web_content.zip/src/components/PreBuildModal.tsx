import React, { useEffect, useState } from 'react';
import {
  Check,
  Crown,
  Hammer,
  ImagePlus,
  Layers,
  Loader2,
  Lock,
  Smartphone,
  Sparkles,
  X,
} from 'lucide-react';
import {
  ApiError,
  apiRequest,
  appendIconAssetsToFormData,
  ICON_PRESETS,
  processIconUploadAssets,
  resolveProjectIconSrc,
  type ProcessedIconAssets,
} from '../lib/api';
import type { ApkConfig, MembershipInfo, ProjectSummary } from '../types/studio';

interface PreBuildModalProps {
  project: ProjectSummary;
  membership: MembershipInfo;
  onClose: () => void;
  onRequireUpgrade: (message: string) => void;
  onConfigSaved: () => Promise<void>;
  onConfirmBuild: (projectId: string) => Promise<void>;
}

const PACKAGE_REGEX = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/;

export const PreBuildModal: React.FC<PreBuildModalProps> = ({
  project,
  membership,
  onClose,
  onRequireUpgrade,
  onConfigSaved,
  onConfirmBuild,
}) => {
  const [config, setConfig] = useState<ApkConfig>({
    adaptiveIconEnabled: true,
    adaptiveBgColor: '#0B1020',
    offlineEnabled: true,
    ...project.config,
  });
  const [stagedAssets, setStagedAssets] = useState<ProcessedIconAssets | null>(null);
  const [stagedLogoPreviewUrl, setStagedLogoPreviewUrl] = useState<string | null>(null);
  const [launcherShape, setLauncherShape] = useState<'squircle' | 'circle' | 'rounded'>('squircle');
  const [processingLogo, setProcessingLogo] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    setConfig({
      adaptiveIconEnabled: true,
      adaptiveBgColor: '#0B1020',
      offlineEnabled: true,
      ...project.config,
    });
    setStagedAssets(null);
    setStagedLogoPreviewUrl(null);
    setErrorMsg(null);
  }, [project.id]);

  useEffect(() => {
    return () => {
      if (stagedLogoPreviewUrl) {
        URL.revokeObjectURL(stagedLogoPreviewUrl);
      }
    };
  }, [stagedLogoPreviewUrl]);

  const packageValid = PACKAGE_REGEX.test(config.packageName.trim());

  const activeIconSrc =
    stagedLogoPreviewUrl ||
    resolveProjectIconSrc(project.id, config.iconPreset, config.customIconPath, project.updated_at);

  const shapeClass =
    launcherShape === 'circle'
      ? 'rounded-full'
      : launcherShape === 'squircle'
      ? 'rounded-[22px]'
      : 'rounded-xl';

  const handleSelectCustomLogo = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawFile = e.target.files?.[0];
    if (!rawFile) return;
    setProcessingLogo(true);
    setErrorMsg(null);
    try {
      const assets = await processIconUploadAssets(rawFile);
      if (stagedLogoPreviewUrl) {
        URL.revokeObjectURL(stagedLogoPreviewUrl);
      }
      const previewUrl = URL.createObjectURL(assets.mainFile);
      setStagedAssets(assets);
      setStagedLogoPreviewUrl(previewUrl);
      setConfig((prev) => ({
        ...prev,
        iconPreset: 'custom',
      }));
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Logo dosyası işlenemedi.');
    } finally {
      setProcessingLogo(false);
      e.target.value = '';
    }
  };

  const handleSubmitAndBuild = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!packageValid) {
      setErrorMsg('Lütfen geçerli bir Android paket adı girin (ör. com.firma.uygulama).');
      return;
    }

    setSubmitting(true);
    setErrorMsg(null);

    try {
      let finalConfig: ApkConfig = { ...config };

      if (stagedAssets) {
        const form = new FormData();
        appendIconAssetsToFormData(form, stagedAssets);
        form.append('adaptiveIconEnabled', String(finalConfig.adaptiveIconEnabled ?? true));
        form.append('adaptiveBgColor', finalConfig.adaptiveBgColor || '#0B1020');

        const iconRes = await apiRequest<{ config: ApkConfig }>(
          `/api/projects/${project.id}/icon`,
          {
            method: 'POST',
            body: form,
          }
        );
        finalConfig = {
          ...finalConfig,
          iconPreset: 'custom',
          customIconPath: iconRes.config.customIconPath,
          customForegroundPath: iconRes.config.customForegroundPath,
        };
      }

      await apiRequest(`/api/projects/${project.id}/config`, {
        method: 'PUT',
        body: JSON.stringify(finalConfig),
      });

      await onConfigSaved();
      await onConfirmBuild(project.id);
    } catch (err) {
      if (err instanceof ApiError && err.upgradeRequired) {
        onClose();
        onRequireUpgrade(err.message);
        return;
      }
      setErrorMsg(
        err instanceof Error ? err.message : 'Ayarlar kaydedilemedi veya derleme başlatılamadı.'
      );
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-4xl bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.1] rounded-2xl overflow-hidden max-h-[92vh] flex flex-col shadow-2xl">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-white/[0.08] flex items-center justify-between gap-4">
          <div className="min-w-0">
            <h2 className="text-base font-semibold text-slate-900 dark:text-[#F8FAFC] truncate">
              APK Oluşturmadan Önce İkon & Kimlik Doğrulama
            </h2>
            <p className="mt-0.5 text-xs text-slate-600 dark:text-[#94A3B8] truncate">
              Proje: <span className="text-slate-900 dark:text-white font-medium">{project.name}</span>{' '}
              · Giriş: <span className="font-mono">{project.entry_file}</span>
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            disabled={submitting}
            className="p-1.5 rounded-lg text-slate-500 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white transition-colors"
            aria-label="Kapat"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmitAndBuild} className="overflow-y-auto flex-1 p-6 space-y-6">
          {errorMsg && (
            <div className="px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/25 text-xs text-red-600 dark:text-red-300">
              {errorMsg}
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Column: Live Launcher Preview + Adaptive Icon Upload */}
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-slate-900 dark:text-[#F8FAFC] flex items-center gap-1.5">
                    <Smartphone className="w-3.5 h-3.5 text-[#6366F1]" />
                    <span>Launcher Önizleme</span>
                  </span>
                  <div className="inline-flex p-0.5 rounded-lg bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] text-[10px]">
                    {(
                      [
                        { id: 'circle', label: 'Yuvarlak' },
                        { id: 'squircle', label: 'Squircle' },
                        { id: 'rounded', label: 'Kare' },
                      ] as const
                    ).map((sh) => (
                      <button
                        key={sh.id}
                        type="button"
                        onClick={() => setLauncherShape(sh.id)}
                        className={`px-2 py-0.5 rounded ${
                          launcherShape === sh.id
                            ? 'bg-[#6366F1] text-white'
                            : 'text-slate-500 dark:text-[#94A3B8]'
                        }`}
                      >
                        {sh.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Simulated Launcher Tile */}
                <div className="rounded-xl bg-slate-200/70 dark:bg-[#111827] border border-slate-200 dark:border-white/[0.06] p-6 flex flex-col items-center justify-center">
                  <div
                    className={`w-20 h-20 ${shapeClass} overflow-hidden border border-slate-300 dark:border-white/[0.14] shadow-md flex items-center justify-center`}
                    style={{
                      backgroundColor:
                        config.adaptiveIconEnabled !== false
                          ? config.adaptiveBgColor || '#0B1020'
                          : '#0B1020',
                    }}
                  >
                    <img
                      src={activeIconSrc}
                      alt={config.appName}
                      referrerPolicy="no-referrer"
                      className={`w-full h-full object-cover ${
                        config.adaptiveIconEnabled !== false ? 'p-2 rounded-full' : ''
                      }`}
                    />
                  </div>
                  <p className="mt-2.5 text-xs font-medium text-slate-900 dark:text-[#F8FAFC] text-center max-w-[140px] truncate">
                    {config.appName || 'Uygulama'}
                  </p>
                  <p className="mt-0.5 text-[10px] font-mono text-slate-500 dark:text-[#94A3B8] truncate max-w-[180px]">
                    {config.packageName}
                  </p>
                </div>

                {/* Custom Logo Upload Box */}
                <label className="flex items-center justify-between gap-3 px-4 py-3 rounded-xl bg-white dark:bg-[#151D2E] hover:border-[#6366F1] border border-dashed border-slate-300 dark:border-[#6366F1]/50 cursor-pointer transition-colors">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-9 h-9 rounded-lg bg-[#6366F1]/15 flex items-center justify-center shrink-0">
                      <ImagePlus className="w-4 h-4 text-[#6366F1]" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-slate-900 dark:text-[#F8FAFC] truncate">
                        {processingLogo
                          ? 'Mipmap çözünürlükleri üretiliyor...'
                          : stagedAssets
                          ? `Hazır: ${stagedAssets.sourceWidth}×${stagedAssets.sourceHeight} → 5 mipmap`
                          : 'Kendi Logonuzu Yükleyin'}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-[#94A3B8] truncate">
                        PNG, JPG, WEBP veya SVG · Kare doğrulaması + Adaptive
                      </div>
                    </div>
                  </div>
                  <span className="px-3 py-1.5 rounded-lg bg-[#6366F1] text-white text-[11px] font-semibold shrink-0">
                    Seç
                  </span>
                  <input
                    type="file"
                    accept=".png,.jpg,.jpeg,.webp,.svg"
                    disabled={processingLogo || submitting}
                    onChange={handleSelectCustomLogo}
                    className="hidden"
                  />
                </label>

                <div className="space-y-2 pt-1">
                  <label className="flex items-center justify-between cursor-pointer text-xs text-slate-700 dark:text-[#CBD5E1]">
                    <span className="inline-flex items-center gap-1.5">
                      <Layers className="w-3.5 h-3.5 text-[#6366F1]" />
                      <span>Adaptive Icon (Ön/Arka Katman)</span>
                    </span>
                    <input
                      type="checkbox"
                      checked={config.adaptiveIconEnabled ?? true}
                      onChange={(e) =>
                        setConfig({ ...config, adaptiveIconEnabled: e.target.checked })
                      }
                      className="accent-[#6366F1] w-4 h-4"
                    />
                  </label>
                  {(config.adaptiveIconEnabled ?? true) && (
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={config.adaptiveBgColor || '#0B1020'}
                        onChange={(e) => setConfig({ ...config, adaptiveBgColor: e.target.value })}
                        className="w-8 h-7 rounded bg-transparent border border-slate-200 dark:border-white/[0.1]"
                      />
                      <input
                        type="text"
                        value={config.adaptiveBgColor || '#0B1020'}
                        onChange={(e) => setConfig({ ...config, adaptiveBgColor: e.target.value })}
                        className="flex-1 bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.1] rounded-lg px-2 py-1 text-xs font-mono text-slate-900 dark:text-[#F8FAFC]"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Splash Mini Preview */}
              <div className="bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-900 dark:text-[#F8FAFC] flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-[#3B82F6]" />
                    <span>Splash Ekranı</span>
                  </span>
                  <input
                    type="checkbox"
                    checked={config.splashEnabled}
                    onChange={(e) => setConfig({ ...config, splashEnabled: e.target.checked })}
                    className="accent-[#6366F1] w-4 h-4 cursor-pointer"
                  />
                </div>
                {config.splashEnabled && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] text-slate-500 dark:text-[#94A3B8] mb-1">
                        Açılış Başlığı
                      </label>
                      <input
                        type="text"
                        value={config.splashTitle}
                        onChange={(e) => setConfig({ ...config, splashTitle: e.target.value })}
                        className="w-full bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.1] rounded-lg px-2.5 py-1.5 text-xs text-slate-900 dark:text-[#F8FAFC]"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-500 dark:text-[#94A3B8] mb-1">
                        Arka Plan Rengi
                      </label>
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={config.splashBgColor}
                          onChange={(e) => setConfig({ ...config, splashBgColor: e.target.value })}
                          className="w-8 h-8 rounded bg-transparent border border-slate-200 dark:border-white/[0.1] cursor-pointer"
                        />
                        <input
                          type="text"
                          value={config.splashBgColor}
                          onChange={(e) => setConfig({ ...config, splashBgColor: e.target.value })}
                          className="w-full bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.1] rounded-lg px-2 py-1.5 text-xs font-mono text-slate-900 dark:text-[#F8FAFC]"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Right Column: Icon Gallery + App Identity */}
            <div className="lg:col-span-7 space-y-5">
              <div className="bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-5 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-xs font-semibold text-slate-900 dark:text-[#F8FAFC]">
                    Uygulama Simgesi Galerisi
                  </h3>
                  <span className="text-[11px] text-slate-500 dark:text-[#94A3B8]">
                    mdpi–xxxhdpi mipmap klasörlerine eklenir
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2.5">
                  {ICON_PRESETS.map((preset) => {
                    const locked = preset.premiumOnly && !membership.limits.premiumIcons;
                    const active = !stagedAssets && config.iconPreset === preset.id;
                    return (
                      <button
                        key={preset.id}
                        type="button"
                        onClick={() => {
                          if (locked) {
                            onClose();
                            onRequireUpgrade(`"${preset.name}" ikonu Premium üyelik gerektirir.`);
                            return;
                          }
                          if (stagedLogoPreviewUrl) {
                            URL.revokeObjectURL(stagedLogoPreviewUrl);
                          }
                          setStagedAssets(null);
                          setStagedLogoPreviewUrl(null);
                          setConfig((prev) => ({
                            ...prev,
                            iconPreset: preset.id,
                            customIconPath: null,
                          }));
                        }}
                        className={`rounded-xl border p-2 text-left transition-colors ${
                          active
                            ? 'border-[#6366F1] bg-[#6366F1]/10'
                            : 'border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#151D2E] hover:border-slate-300 dark:hover:border-white/[0.2]'
                        }`}
                      >
                        <img
                          src={preset.src}
                          alt={preset.name}
                          referrerPolicy="no-referrer"
                          className="w-full aspect-square object-cover rounded-lg mb-1.5"
                        />
                        <div className="flex items-center justify-between gap-1">
                          <span className="text-[11px] font-medium text-slate-900 dark:text-[#F8FAFC] truncate">
                            {preset.name}
                          </span>
                          {locked ? (
                            <Lock className="w-3 h-3 text-[#EAB308] shrink-0" />
                          ) : active ? (
                            <Check className="w-3 h-3 text-[#6366F1] shrink-0" />
                          ) : preset.premiumOnly ? (
                            <Crown className="w-3 h-3 text-[#EAB308] shrink-0" />
                          ) : null}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-5 space-y-4">
                <h3 className="text-xs font-semibold text-slate-900 dark:text-[#F8FAFC]">
                  Uygulama Kimliği ve Sürüm
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block text-[11px] text-slate-500 dark:text-[#94A3B8] mb-1">
                      Uygulama Adı
                    </label>
                    <input
                      type="text"
                      required
                      value={config.appName}
                      onChange={(e) => setConfig({ ...config, appName: e.target.value })}
                      className="w-full bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-[#F8FAFC] focus:outline-none focus:border-[#6366F1]"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-500 dark:text-[#94A3B8] mb-1">
                      Paket Adı (Application ID)
                    </label>
                    <input
                      type="text"
                      required
                      value={config.packageName}
                      onChange={(e) => setConfig({ ...config, packageName: e.target.value })}
                      className={`w-full bg-white dark:bg-[#151D2E] border rounded-xl px-3 py-2 text-xs font-mono text-slate-900 dark:text-[#F8FAFC] focus:outline-none ${
                        packageValid
                          ? 'border-slate-200 dark:border-white/[0.1] focus:border-[#6366F1]'
                          : 'border-[#EF4444]'
                      }`}
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-500 dark:text-[#94A3B8] mb-1">
                      Sürüm Adı
                    </label>
                    <input
                      type="text"
                      required
                      value={config.versionName}
                      onChange={(e) => setConfig({ ...config, versionName: e.target.value })}
                      className="w-full bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3 py-2 text-xs font-mono text-slate-900 dark:text-[#F8FAFC]"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-500 dark:text-[#94A3B8] mb-1">
                      Ekran Yönü
                    </label>
                    <select
                      value={config.orientation}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          orientation: e.target.value as ApkConfig['orientation'],
                        })
                      }
                      className="w-full bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-[#F8FAFC]"
                    >
                      <option value="unspecified">Otomatik (Sensör)</option>
                      <option value="portrait">Dikey (Portrait)</option>
                      <option value="landscape">Yatay (Landscape)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
                  <label className="flex items-center justify-between p-2.5 rounded-xl bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.06] cursor-pointer">
                    <span className="text-xs text-slate-700 dark:text-[#CBD5E1]">Tam Ekran</span>
                    <input
                      type="checkbox"
                      checked={config.fullscreen}
                      onChange={(e) => setConfig({ ...config, fullscreen: e.target.checked })}
                      className="accent-[#6366F1] w-4 h-4"
                    />
                  </label>
                  <label className="flex items-center justify-between p-2.5 rounded-xl bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.06] cursor-pointer">
                    <span className="text-xs text-slate-700 dark:text-[#CBD5E1]">İnternet İzni</span>
                    <input
                      type="checkbox"
                      checked={config.internetPermission}
                      onChange={(e) =>
                        setConfig({ ...config, internetPermission: e.target.checked })
                      }
                      className="accent-[#6366F1] w-4 h-4"
                    />
                  </label>
                  <label className="flex items-center justify-between p-2.5 rounded-xl bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.06] cursor-pointer">
                    <span className="text-xs text-slate-700 dark:text-[#CBD5E1]">Offline Destek</span>
                    <input
                      type="checkbox"
                      checked={config.offlineEnabled ?? true}
                      onChange={(e) =>
                        setConfig({ ...config, offlineEnabled: e.target.checked })
                      }
                      className="accent-[#6366F1] w-4 h-4"
                    />
                  </label>
                </div>
              </div>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="pt-4 border-t border-slate-200 dark:border-white/[0.08] flex flex-col-reverse sm:flex-row sm:items-center justify-between gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="px-4 py-2.5 text-xs font-medium rounded-xl border border-slate-200 dark:border-white/[0.1] text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white transition-colors"
            >
              Vazgeç
            </button>
            <button
              type="submit"
              disabled={submitting || processingLogo || !packageValid}
              className="inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl bg-[#6366F1] hover:bg-[#5558E3] disabled:opacity-50 text-white text-xs font-semibold transition-colors whitespace-nowrap"
            >
              {submitting ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Hammer className="w-4 h-4" />
              )}
              <span>
                {submitting ? 'Kaydediliyor ve Başlatılıyor...' : 'Ayarları Kaydet ve APK Oluştur'}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
