import React, { useState } from 'react';
import { ArrowLeft, Download, FileText, Printer } from 'lucide-react';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { ReportPayload, SalesStatementPayload, StoreSettings } from '../types';
import { fmtDateTime, fmtInt, fmtMoney } from '../utils';

export type SheetPreviewTarget =
  | { kind: 'statement'; statement: SalesStatementPayload }
  | { kind: 'report'; report: ReportPayload };

interface SheetContentProps {
  target: SheetPreviewTarget;
  settings: StoreSettings;
}

const escHtml = (val: string | number) =>
  String(val)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');

const MiniTrendSvg: React.FC<{ rows: SalesStatementPayload['rows'] }> = ({ rows }) => {
  if (rows.length === 0) return null;
  const pts = rows.slice(-10);
  const maxVal = Math.max(1, ...pts.map((r) => Math.max(r.grandTotal, r.profit)));
  const w = 310;
  const h = 115;
  const padL = 38;
  const padR = 12;
  const padT = 12;
  const padB = 22;
  const plotW = w - padL - padR;
  const plotH = h - padT - padB;

  const toXY = (val: number, idx: number) => {
    const x = pts.length === 1 ? padL + plotW / 2 : padL + (idx / (pts.length - 1)) * plotW;
    const y = padT + plotH - (Math.max(0, val) / maxVal) * plotH;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  };

  const revLine = pts.map((r, i) => toXY(r.grandTotal, i)).join(' ');
  const profLine = pts.map((r, i) => toXY(r.profit, i)).join(' ');

  return (
    <div className="border border-slate-200 bg-white p-2.5">
      <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-28 overflow-visible" aria-hidden="true">
        {[0, 0.5, 1].map((frac) => {
          const y = padT + plotH * (1 - frac);
          const labelVal = Math.round(maxVal * frac);
          return (
            <g key={frac}>
              <line x1={padL} y1={y} x2={w - padR} y2={y} stroke="#e2e8f0" strokeWidth="1" />
              <text x={padL - 5} y={y + 3} textAnchor="end" fontSize="8" fill="#64748b">
                {labelVal}
              </text>
            </g>
          );
        })}
        {pts.length > 1 ? (
          <>
            <polyline fill="none" stroke="#d97706" strokeWidth="2" points={revLine} />
            <polyline fill="none" stroke="#2a7d78" strokeWidth="2" points={profLine} />
          </>
        ) : null}
        {pts.map((r, i) => {
          const [rx, ry] = toXY(r.grandTotal, i).split(',');
          const [px, py] = toXY(r.profit, i).split(',');
          return (
            <g key={r.invoiceNo + i}>
              <circle cx={rx} cy={ry} r="2.5" fill="#d97706" />
              <circle cx={px} cy={py} r="2.5" fill="#2a7d78" />
              <text x={rx} y={h - 6} textAnchor="middle" fontSize="7.5" fill="#64748b">
                {i + 1}
              </text>
            </g>
          );
        })}
      </svg>
      <div className="flex items-center justify-center gap-4 text-[10px] text-slate-600 mt-1">
        <span className="inline-flex items-center gap-1">
          <span className="w-3 h-0.5 bg-amber-600 inline-block" /> Sales Total
        </span>
        <span className="inline-flex items-center gap-1">
          <span className="w-3 h-0.5 bg-[#2a7d78] inline-block" /> Profit
        </span>
      </div>
    </div>
  );
};

export const SheetContent: React.FC<SheetContentProps> = ({ target, settings }) => {
  const storeName = settings.storeName || 'My Store';

  if (target.kind === 'statement') {
    const st = target.statement;
    const isCompleteShop = !!(st.categorySummary || st.stockRows);

    return (
      <div className="bg-white text-slate-900 space-y-4">
        {/* Clean Excel Template Title */}
        <div className="text-center border-b border-slate-200 pb-3 space-y-1">
          <div className="flex items-center justify-center gap-3">
            {settings.storeLogo && (
              <img src={settings.storeLogo} alt="Store logo" className="h-9 w-9 object-contain border border-slate-200 p-0.5 bg-white" />
            )}
            <h1 className="text-xl sm:text-2xl font-extrabold tracking-wide uppercase text-[#1f6f6a]">
              {storeName} — {isCompleteShop ? 'SHOP & STOCK STATEMENT SHEET' : 'SALES STATEMENT SHEET'}
            </h1>
          </div>
          <p className="text-xs text-slate-600 font-medium">
            {settings.storePhone ? `${settings.storePhone} · ` : ''}
            Period: <span className="font-bold text-slate-800">{st.periodLabel}</span> · Generated: {st.generatedAt}
          </p>
        </div>

        {/* Distinctive Teal Banner matching template */}
        <div className="bg-[#2a7d78] text-white text-center font-semibold py-2 px-4 text-xs sm:text-sm tracking-wide">
          {isCompleteShop
            ? 'Store Statement Table (including category & product summary slip)'
            : 'Sales Statement Table (including calculated summary slip)'}
        </div>

        {/* Category-Wise Summary if included */}
        {st.categorySummary && st.categorySummary.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-slate-300 text-[11px] tabular-nums">
              <thead>
                <tr className="bg-slate-50 text-slate-800 font-bold border-b border-slate-300">
                  <th colSpan={2} className="border border-slate-300 px-2 py-1 text-center bg-teal-50/60">
                    Category Information
                  </th>
                  <th colSpan={2} className="border border-slate-300 px-2 py-1 text-center bg-slate-100/80">
                    Stock Count
                  </th>
                  <th colSpan={3} className="border border-slate-300 px-2 py-1 text-center bg-teal-50/60">
                    Valuation & Profit
                  </th>
                </tr>
                <tr className="bg-white text-slate-700 font-semibold">
                  <th className="border border-slate-300 px-2 py-1.5 text-center w-10">SL</th>
                  <th className="border border-slate-300 px-2 py-1.5 text-left">Category Name</th>
                  <th className="border border-slate-300 px-2 py-1.5 text-right">Products</th>
                  <th className="border border-slate-300 px-2 py-1.5 text-right">Units in Stock</th>
                  <th className="border border-slate-300 px-2 py-1.5 text-right">Cost Value</th>
                  <th className="border border-slate-300 px-2 py-1.5 text-right">Retail Value</th>
                  <th className="border border-slate-300 px-2 py-1.5 text-right">Potential Profit</th>
                </tr>
              </thead>
              <tbody>
                {st.categorySummary.map((c, idx) => (
                  <tr key={c.category} className="bg-white">
                    <td className="border border-slate-300 px-2 py-1 text-center text-slate-500">{idx + 1}</td>
                    <td className="border border-slate-300 px-2 py-1 font-semibold text-slate-900">{c.category}</td>
                    <td className="border border-slate-300 px-2 py-1 text-right">{c.productCount}</td>
                    <td className="border border-slate-300 px-2 py-1 text-right font-bold">{c.totalUnits}</td>
                    <td className="border border-slate-300 px-2 py-1 text-right">{c.costValue.toFixed(2)}</td>
                    <td className="border border-slate-300 px-2 py-1 text-right">{c.retailValue.toFixed(2)}</td>
                    <td className="border border-slate-300 px-2 py-1 text-right font-semibold">{c.potentialProfit.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Product Stock Register if included */}
        {st.stockRows && st.stockRows.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-slate-300 text-[11px] tabular-nums">
              <thead>
                <tr className="bg-slate-50 text-slate-800 font-bold">
                  <th colSpan={4} className="border border-slate-300 px-2 py-1 text-center bg-teal-50/60">
                    Available Product Details
                  </th>
                  <th colSpan={3} className="border border-slate-300 px-2 py-1 text-center bg-slate-100/80">
                    Qty & Unit Prices
                  </th>
                  <th colSpan={2} className="border border-slate-300 px-2 py-1 text-center bg-teal-50/60">
                    Stock Valuation
                  </th>
                </tr>
                <tr className="bg-white text-slate-700 font-semibold">
                  <th className="border border-slate-300 px-2 py-1.5 text-center w-10">SL</th>
                  <th className="border border-slate-300 px-2 py-1.5 text-left">Product Name</th>
                  <th className="border border-slate-300 px-2 py-1.5 text-left">Barcode / SKU</th>
                  <th className="border border-slate-300 px-2 py-1.5 text-left">Category</th>
                  <th className="border border-slate-300 px-2 py-1.5 text-right">Qty</th>
                  <th className="border border-slate-300 px-2 py-1.5 text-right">Cost</th>
                  <th className="border border-slate-300 px-2 py-1.5 text-right">Price</th>
                  <th className="border border-slate-300 px-2 py-1.5 text-right">Stock Value</th>
                  <th className="border border-slate-300 px-2 py-1.5 text-left">Status</th>
                </tr>
              </thead>
              <tbody>
                {st.stockRows.map((p) => (
                  <tr key={p.sl + p.code} className="bg-white">
                    <td className="border border-slate-300 px-2 py-1 text-center text-slate-500">{p.sl}</td>
                    <td className="border border-slate-300 px-2 py-1 font-medium">{p.name}</td>
                    <td className="border border-slate-300 px-2 py-1 font-mono text-[10px]">{p.code}</td>
                    <td className="border border-slate-300 px-2 py-1">{p.category}</td>
                    <td className="border border-slate-300 px-2 py-1 text-right font-bold">{p.quantity}</td>
                    <td className="border border-slate-300 px-2 py-1 text-right">{p.purchasePrice.toFixed(2)}</td>
                    <td className="border border-slate-300 px-2 py-1 text-right">{p.sellingPrice.toFixed(2)}</td>
                    <td className="border border-slate-300 px-2 py-1 text-right font-semibold">{p.costValue.toFixed(2)}</td>
                    <td className="border border-slate-300 px-2 py-1">{p.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Sales Invoices Table (grouped super-headers matching template) */}
        <div className="overflow-x-auto">
          <table className="w-full border-collapse border border-slate-300 text-[11px] tabular-nums">
            <thead>
              <tr className="bg-slate-50 text-slate-800 font-bold">
                <th colSpan={6} className="border border-slate-300 px-2 py-1 text-center bg-teal-50/60">
                  Invoice & Customer Details
                </th>
                <th colSpan={3} className="border border-slate-300 px-2 py-1 text-center bg-slate-100/80">
                  Payable Sales
                </th>
                <th colSpan={3} className="border border-slate-300 px-2 py-1 text-center bg-teal-50/60">
                  Collection & Profit Balance
                </th>
              </tr>
              <tr className="bg-white text-slate-700 font-semibold">
                <th className="border border-slate-300 px-2 py-1.5 text-center w-9">SL</th>
                <th className="border border-slate-300 px-2 py-1.5 text-left">Date</th>
                <th className="border border-slate-300 px-2 py-1.5 text-left">Invoice #</th>
                <th className="border border-slate-300 px-2 py-1.5 text-left">Customer</th>
                <th className="border border-slate-300 px-2 py-1.5 text-right">Qty</th>
                <th className="border border-slate-300 px-2 py-1.5 text-left">Method</th>
                <th className="border border-slate-300 px-2 py-1.5 text-right">Subtotal</th>
                <th className="border border-slate-300 px-2 py-1.5 text-right">Discount</th>
                <th className="border border-slate-300 px-2 py-1.5 text-right">Net Sales</th>
                <th className="border border-slate-300 px-2 py-1.5 text-right">Paid</th>
                <th className="border border-slate-300 px-2 py-1.5 text-right">Due</th>
                <th className="border border-slate-300 px-2 py-1.5 text-right">Profit</th>
              </tr>
            </thead>
            <tbody>
              {st.rows.length === 0 ? (
                <tr>
                  <td colSpan={12} className="border border-slate-300 py-6 text-center text-slate-400">
                    No sales recorded for {st.periodLabel}.
                  </td>
                </tr>
              ) : (
                st.rows.map((r) => (
                  <tr key={r.invoiceNo + r.sl} className="bg-white">
                    <td className="border border-slate-300 px-2 py-1 text-center text-slate-500">{r.sl}</td>
                    <td className="border border-slate-300 px-2 py-1 whitespace-nowrap">{r.date}</td>
                    <td className="border border-slate-300 px-2 py-1 font-mono font-semibold">{r.invoiceNo}</td>
                    <td className="border border-slate-300 px-2 py-1">{r.customerName}</td>
                    <td className="border border-slate-300 px-2 py-1 text-right">{r.itemsCount}</td>
                    <td className="border border-slate-300 px-2 py-1">{r.paymentMethod}</td>
                    <td className="border border-slate-300 px-2 py-1 text-right">{r.subtotal.toFixed(2)}</td>
                    <td className="border border-slate-300 px-2 py-1 text-right">{r.discount.toFixed(2)}</td>
                    <td className="border border-slate-300 px-2 py-1 text-right font-bold">{r.grandTotal.toFixed(2)}</td>
                    <td className="border border-slate-300 px-2 py-1 text-right">{r.paidAmount.toFixed(2)}</td>
                    <td className="border border-slate-300 px-2 py-1 text-right">{r.dueAmount > 0 ? r.dueAmount.toFixed(2) : '0.00'}</td>
                    <td className="border border-slate-300 px-2 py-1 text-right font-bold">{r.profit.toFixed(2)}</td>
                  </tr>
                ))
              )}
            </tbody>
            <tfoot>
              <tr className="bg-slate-50 font-bold text-slate-900">
                <td colSpan={4} className="border border-slate-300 px-2 py-1.5">
                  Grand Total ({st.summary.ordersCount} Invoices)
                </td>
                <td className="border border-slate-300 px-2 py-1.5 text-right">{st.summary.itemsCount}</td>
                <td className="border border-slate-300 px-2 py-1.5">-</td>
                <td className="border border-slate-300 px-2 py-1.5 text-right">{st.summary.subtotal.toFixed(2)}</td>
                <td className="border border-slate-300 px-2 py-1.5 text-right">{st.summary.discount.toFixed(2)}</td>
                <td className="border border-slate-300 px-2 py-1.5 text-right">{st.summary.grandTotal.toFixed(2)}</td>
                <td className="border border-slate-300 px-2 py-1.5 text-right">{st.summary.paid.toFixed(2)}</td>
                <td className="border border-slate-300 px-2 py-1.5 text-right">{st.summary.due.toFixed(2)}</td>
                <td className="border border-slate-300 px-2 py-1.5 text-right">{st.summary.grossProfit.toFixed(2)}</td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* Bottom Formula Slip + Mini Trend matching attached template */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end pt-1">
          {st.rows.length > 0 && (
            <div className="md:col-span-4">
              <MiniTrendSvg rows={st.rows} />
            </div>
          )}
          <div className={st.rows.length > 0 ? 'md:col-span-8' : 'md:col-span-12'}>
            <div className="text-center text-xs font-bold text-slate-700 py-1.5 border border-b-0 border-slate-300 bg-slate-50">
              statement summary slip (automatically calculated)
            </div>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-slate-300 text-[11px] tabular-nums">
                <thead>
                  <tr className="bg-white text-slate-700 font-semibold">
                    <th className="border border-slate-300 px-2 py-1.5 text-center">Invoices</th>
                    <th className="border border-slate-300 px-2 py-1.5 text-center">Items</th>
                    <th className="border border-slate-300 px-2 py-1.5 text-right">Net Sales</th>
                    <th className="border border-slate-300 px-2 py-1.5 text-right">Paid</th>
                    <th className="border border-slate-300 px-2 py-1.5 text-right">Due</th>
                    <th className="border border-slate-300 px-2 py-1.5 text-right">Gross Profit</th>
                    <th className="border border-slate-300 px-2 py-1.5 text-right">Expenses</th>
                    <th className="border border-slate-300 px-2 py-1.5 text-right">Net Balance</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="bg-white font-bold text-slate-900">
                    <td className="border border-slate-300 px-2 py-2 text-center">{fmtInt(st.summary.ordersCount)}</td>
                    <td className="border border-slate-300 px-2 py-2 text-center">{fmtInt(st.summary.itemsCount)}</td>
                    <td className="border border-slate-300 px-2 py-2 text-right">{fmtMoney(st.summary.grandTotal)}</td>
                    <td className="border border-slate-300 px-2 py-2 text-right">{fmtMoney(st.summary.paid)}</td>
                    <td className="border border-slate-300 px-2 py-2 text-right">{fmtMoney(st.summary.due)}</td>
                    <td className="border border-slate-300 px-2 py-2 text-right">{fmtMoney(st.summary.grossProfit)}</td>
                    <td className="border border-slate-300 px-2 py-2 text-right">{fmtMoney(st.summary.expenses)}</td>
                    <td className="border border-slate-300 px-2 py-2 text-right text-[#1f6f6a]">{fmtMoney(st.summary.netProfit)}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Clean Signature Line */}
        <div className="pt-8 flex items-end justify-between text-xs text-slate-700">
          <div className="w-44 border-t border-slate-400 pt-1 text-center font-semibold">Prepared By</div>
          <div className="w-44 border-t border-slate-400 pt-1 text-center font-semibold">Verified / Store Owner</div>
        </div>
      </div>
    );
  }

  // Generic / Inventory / Category / Category Product List / Profit / Expense / Movement Sheet
  const rep = target.report;
  return (
    <div className="bg-white text-slate-900 space-y-4">
      <div className="text-center border-b border-slate-200 pb-3 space-y-1">
        <div className="flex items-center justify-center gap-3">
          {settings.storeLogo && (
            <img src={settings.storeLogo} alt="Store logo" className="h-9 w-9 object-contain border border-slate-200 p-0.5 bg-white" />
          )}
          <h1 className="text-xl sm:text-2xl font-extrabold tracking-wide uppercase text-[#1f6f6a]">
            {storeName} — {rep.title}
          </h1>
        </div>
        <p className="text-xs text-slate-600 font-medium">
          {settings.storePhone ? `${settings.storePhone} · ` : ''}
          {rep.subtitle ? `${rep.subtitle} · ` : ''}
          Printed: {fmtDateTime(new Date().toISOString())}
        </p>
      </div>

      <div className="bg-[#2a7d78] text-white text-center font-semibold py-2 px-4 text-xs sm:text-sm tracking-wide">
        {rep.sheetBanner || `${rep.title} (including automatically calculated summary slip)`}
      </div>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse border border-slate-300 text-[11px] tabular-nums">
          <thead>
            <tr className="bg-slate-50 text-slate-800 font-bold">
              {rep.headers.map((h, i) => (
                <th key={i} className="border border-slate-300 px-2.5 py-2 text-left whitespace-nowrap">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rep.rows.length === 0 ? (
              <tr>
                <td colSpan={rep.headers.length} className="border border-slate-300 py-8 text-center text-slate-400">
                  No records found.
                </td>
              </tr>
            ) : (
              rep.rows.map((r, i) => (
                <tr key={i} className="bg-white">
                  {r.map((cell, j) => (
                    <td key={j} className="border border-slate-300 px-2.5 py-1.5 whitespace-nowrap">
                      {cell}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
          {rep.totalsRow && rep.rows.length > 0 && (
            <tfoot>
              <tr className="bg-slate-50 font-bold text-slate-900">
                {rep.totalsRow.map((cell, j) => (
                  <td key={j} className="border border-slate-300 px-2.5 py-2 whitespace-nowrap">
                    {cell}
                  </td>
                ))}
              </tr>
            </tfoot>
          )}
        </table>
      </div>

      {rep.summaryCards && rep.summaryCards.length > 0 && (
        <div>
          <div className="text-center text-xs font-bold text-slate-700 py-1.5 border border-b-0 border-slate-300 bg-slate-50">
            summary slip (automatically calculated)
          </div>
          <table className="w-full border-collapse border border-slate-300 text-xs tabular-nums">
            <thead>
              <tr className="bg-white text-slate-600 font-semibold">
                {rep.summaryCards.map((c) => (
                  <th key={c.label} className="border border-slate-300 px-3 py-1.5 text-center">
                    {c.label}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr className="bg-white font-extrabold text-slate-900">
                {rep.summaryCards.map((c) => (
                  <td key={c.label} className="border border-slate-300 px-3 py-2 text-center">
                    {c.value}
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      )}

      <div className="pt-8 flex items-end justify-between text-xs text-slate-700">
        <div className="w-44 border-t border-slate-400 pt-1 text-center font-semibold">Prepared By</div>
        <div className="w-44 border-t border-slate-400 pt-1 text-center font-semibold">Verified / Store Owner</div>
      </div>
    </div>
  );
};

export const downloadSheetHtmlFile = (target: SheetPreviewTarget, settings: StoreSettings) => {
  const storeName = escHtml(settings.storeName || 'My Store');
  const storePhone = escHtml(settings.storePhone || '');
  const nowStr = escHtml(fmtDateTime(new Date().toISOString()));

  let title = '';
  let banner = '';
  let sections = '';

  if (target.kind === 'statement') {
    const st = target.statement;
    title = escHtml(st.title);
    const isComplete = !!(st.categorySummary || st.stockRows);
    banner = isComplete
      ? 'Store Statement Table (including category & product summary slip)'
      : 'Sales Statement Table (including calculated summary slip)';

    sections = `
      ${
        st.categorySummary && st.categorySummary.length > 0
          ? `<table>
              <thead>
                <tr><th colspan="7" class="grp">Category-Wise Stock Summary</th></tr>
                <tr><th>SL</th><th>Category</th><th class="r">Products</th><th class="r">Units</th><th class="r">Cost Value</th><th class="r">Retail Value</th><th class="r">Potential Profit</th></tr>
              </thead>
              <tbody>
                ${st.categorySummary
                  .map(
                    (c, i) =>
                      `<tr><td class="c">${i + 1}</td><td><b>${escHtml(c.category)}</b></td><td class="r">${c.productCount}</td><td class="r"><b>${c.totalUnits}</b></td><td class="r">${c.costValue.toFixed(2)}</td><td class="r">${c.retailValue.toFixed(2)}</td><td class="r">${c.potentialProfit.toFixed(2)}</td></tr>`
                  )
                  .join('')}
              </tbody>
            </table>`
          : ''
      }
      ${
        st.stockRows && st.stockRows.length > 0
          ? `<table>
              <thead>
                <tr><th colspan="9" class="grp">Available Product Stock Sheet</th></tr>
                <tr><th>SL</th><th>Product Name</th><th>Barcode / SKU</th><th>Category</th><th class="r">Qty</th><th class="r">Cost</th><th class="r">Price</th><th class="r">Stock Value</th><th>Status</th></tr>
              </thead>
              <tbody>
                ${st.stockRows
                  .map(
                    (p) =>
                      `<tr><td class="c">${p.sl}</td><td>${escHtml(p.name)}</td><td class="m">${escHtml(p.code)}</td><td>${escHtml(p.category)}</td><td class="r"><b>${p.quantity}</b></td><td class="r">${p.purchasePrice.toFixed(2)}</td><td class="r">${p.sellingPrice.toFixed(2)}</td><td class="r">${p.costValue.toFixed(2)}</td><td>${escHtml(p.status)}</td></tr>`
                  )
                  .join('')}
              </tbody>
            </table>`
          : ''
      }
      <table>
        <thead>
          <tr><th colspan="6" class="grp">Invoice & Customer Details</th><th colspan="3" class="grp">Payable Sales</th><th colspan="3" class="grp">Collection & Profit</th></tr>
          <tr><th>SL</th><th>Date</th><th>Invoice #</th><th>Customer</th><th class="r">Qty</th><th>Method</th><th class="r">Subtotal</th><th class="r">Discount</th><th class="r">Net Sales</th><th class="r">Paid</th><th class="r">Due</th><th class="r">Profit</th></tr>
        </thead>
        <tbody>
          ${
            st.rows.length === 0
              ? '<tr><td colspan="12" class="c">No sales recorded in this period.</td></tr>'
              : st.rows
                  .map(
                    (r) =>
                      `<tr><td class="c">${r.sl}</td><td>${escHtml(r.date)}</td><td class="m">${escHtml(r.invoiceNo)}</td><td>${escHtml(r.customerName)}</td><td class="r">${r.itemsCount}</td><td>${escHtml(r.paymentMethod)}</td><td class="r">${r.subtotal.toFixed(2)}</td><td class="r">${r.discount.toFixed(2)}</td><td class="r"><b>${r.grandTotal.toFixed(2)}</b></td><td class="r">${r.paidAmount.toFixed(2)}</td><td class="r">${r.dueAmount.toFixed(2)}</td><td class="r"><b>${r.profit.toFixed(2)}</b></td></tr>`
                  )
                  .join('')
          }
        </tbody>
        <tfoot>
          <tr><td colspan="4">Grand Total (${st.summary.ordersCount} Invoices)</td><td class="r">${st.summary.itemsCount}</td><td>-</td><td class="r">${st.summary.subtotal.toFixed(2)}</td><td class="r">${st.summary.discount.toFixed(2)}</td><td class="r">${st.summary.grandTotal.toFixed(2)}</td><td class="r">${st.summary.paid.toFixed(2)}</td><td class="r">${st.summary.due.toFixed(2)}</td><td class="r">${st.summary.grossProfit.toFixed(2)}</td></tr>
        </tfoot>
      </table>
      <div class="slip-title">statement summary slip (automatically calculated)</div>
      <table>
        <thead><tr><th>Invoices</th><th>Items</th><th class="r">Net Sales</th><th class="r">Paid</th><th class="r">Due</th><th class="r">Gross Profit</th><th class="r">Expenses</th><th class="r">Net Balance</th></tr></thead>
        <tbody><tr><td class="c"><b>${fmtInt(st.summary.ordersCount)}</b></td><td class="c"><b>${fmtInt(st.summary.itemsCount)}</b></td><td class="r"><b>${escHtml(fmtMoney(st.summary.grandTotal))}</b></td><td class="r"><b>${escHtml(fmtMoney(st.summary.paid))}</b></td><td class="r"><b>${escHtml(fmtMoney(st.summary.due))}</b></td><td class="r"><b>${escHtml(fmtMoney(st.summary.grossProfit))}</b></td><td class="r"><b>${escHtml(fmtMoney(st.summary.expenses))}</b></td><td class="r"><b>${escHtml(fmtMoney(st.summary.netProfit))}</b></td></tr></tbody>
      </table>`;
  } else {
    const rep = target.report;
    title = escHtml(rep.title);
    banner = escHtml(rep.sheetBanner || `${rep.title} (including automatically calculated summary slip)`);
    sections = `
      <table>
        <thead><tr>${rep.headers.map((h) => `<th>${escHtml(h)}</th>`).join('')}</tr></thead>
        <tbody>
          ${
            rep.rows.length === 0
              ? `<tr><td colspan="${rep.headers.length}" class="c">No records found.</td></tr>`
              : rep.rows.map((r) => `<tr>${r.map((cell) => `<td>${escHtml(cell)}</td>`).join('')}</tr>`).join('')
          }
        </tbody>
        ${
          rep.totalsRow && rep.rows.length > 0
            ? `<tfoot><tr>${rep.totalsRow.map((cell) => `<td>${escHtml(cell)}</td>`).join('')}</tr></tfoot>`
            : ''
        }
      </table>
      ${
        rep.summaryCards
          ? `<div class="slip-title">summary slip (automatically calculated)</div>
             <table>
               <thead><tr>${rep.summaryCards.map((c) => `<th class="c">${escHtml(c.label)}</th>`).join('')}</tr></thead>
               <tbody><tr>${rep.summaryCards.map((c) => `<td class="c"><b>${escHtml(c.value)}</b></td>`).join('')}</tr></tbody>
             </table>`
          : ''
      }`;
  }

  const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>${title} - ${storeName}</title>
<style>
  @page { size: A4; margin: 10mm; }
  body { font-family: Arial, Helvetica, sans-serif; color: #0f172a; background: #fff; margin: 20px; font-size: 12px; }
  .top-title { text-align: center; border-bottom: 1px solid #cbd5e1; padding-bottom: 10px; margin-bottom: 12px; }
  .top-title h1 { margin: 0; font-size: 20px; color: #1f6f6a; text-transform: uppercase; letter-spacing: 0.04em; }
  .top-title p { margin: 4px 0 0; font-size: 11px; color: #475569; }
  .banner { background: #2a7d78; color: #fff; text-align: center; padding: 8px 12px; font-weight: 700; font-size: 13px; margin-bottom: 10px; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 12px; font-size: 11px; background: #fff; }
  th, td { border: 1px solid #cbd5e1; padding: 5px 7px; text-align: left; }
  th.grp { background: #f0fdfa; text-align: center; font-weight: 700; }
  thead th { background: #ffffff; color: #0f172a; font-weight: 700; }
  tfoot td { background: #f8fafc; font-weight: 700; }
  .slip-title { text-align: center; font-weight: 700; font-size: 11px; padding: 5px; border: 1px solid #cbd5e1; border-bottom: 0; background: #f8fafc; }
  .r { text-align: right; font-variant-numeric: tabular-nums; }
  .c { text-align: center; }
  .m { font-family: monospace; font-weight: 700; }
  .sigs { display: flex; justify-content: space-between; margin-top: 36px; font-size: 11px; }
  .sig { width: 170px; border-top: 1px solid #94a3b8; text-align: center; padding-top: 4px; font-weight: 700; }
  @media print { body { margin: 0; } }
</style>
</head>
<body>
  <div class="top-title">
    <h1>${storeName} — ${title}</h1>
    <p>${storePhone ? `${storePhone} · ` : ''}Generated: ${nowStr}</p>
  </div>
  <div class="banner">${banner}</div>
  ${sections}
  <div class="sigs">
    <div class="sig">Prepared By</div>
    <div class="sig">Verified / Store Owner</div>
  </div>
</body>
</html>`;

  const blob = new Blob([html], { type: 'text/html;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.html`;
  a.click();
  URL.revokeObjectURL(url);
};

const fmtPdfMoney = (n: number | string | undefined | null) =>
  `Tk ${Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

const sanitizePdfCell = (val: string | number): string =>
  String(val).replace(/৳/g, 'Tk ');

export const downloadSheetPdfFile = (target: SheetPreviewTarget, settings: StoreSettings) => {
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const storeName = settings.storeName || 'My Store';
  const pageWidth = doc.internal.pageSize.getWidth();
  const teal: [number, number, number] = [42, 125, 120];
  const tealLight: [number, number, number] = [240, 253, 250];
  const nowStr = fmtDateTime(new Date().toISOString());

  let docTitle = '';
  let subLine = '';
  let bannerText = '';

  if (target.kind === 'statement') {
    const st = target.statement;
    const isComplete = !!(st.categorySummary || st.stockRows);
    docTitle = `${storeName} - ${isComplete ? 'SHOP & STOCK STATEMENT SHEET' : 'SALES STATEMENT SHEET'}`;
    subLine = `${settings.storePhone ? `${settings.storePhone} | ` : ''}Period: ${st.periodLabel} | Generated: ${st.generatedAt}`;
    bannerText = isComplete
      ? 'Store Statement Table (including category & product summary slip)'
      : 'Sales Statement Table (including calculated summary slip)';
  } else {
    const rep = target.report;
    docTitle = `${storeName} - ${rep.title}`;
    subLine = `${settings.storePhone ? `${settings.storePhone} | ` : ''}${rep.subtitle ? `${rep.subtitle} | ` : ''}Printed: ${nowStr}`;
    bannerText = rep.sheetBanner || `${rep.title} (including automatically calculated summary slip)`;
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(31, 111, 106);
  doc.text(sanitizePdfCell(docTitle).toUpperCase(), pageWidth / 2, 14, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  doc.text(sanitizePdfCell(subLine), pageWidth / 2, 19.5, { align: 'center' });

  doc.setFillColor(...teal);
  doc.rect(12, 23, pageWidth - 24, 7.5, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(255, 255, 255);
  doc.text(sanitizePdfCell(bannerText), pageWidth / 2, 28, { align: 'center' });

  let cursorY = 33;

  if (target.kind === 'statement') {
    const st = target.statement;
    if (st.categorySummary && st.categorySummary.length > 0) {
      autoTable(doc, {
        startY: cursorY,
        margin: { left: 12, right: 12 },
        theme: 'grid',
        headStyles: { fillColor: tealLight, textColor: [15, 23, 42], fontStyle: 'bold', fontSize: 8 },
        bodyStyles: { fontSize: 8, textColor: [15, 23, 42] },
        head: [['SL', 'Category', 'Products', 'Units', 'Cost Value', 'Retail Value', 'Potential Profit']],
        body: st.categorySummary.map((c, i) => [
          i + 1,
          c.category,
          c.productCount,
          c.totalUnits,
          c.costValue.toFixed(2),
          c.retailValue.toFixed(2),
          c.potentialProfit.toFixed(2),
        ]),
      });
      cursorY = (doc as unknown as { lastAutoTable?: { finalY: number } }).lastAutoTable?.finalY || cursorY;
      cursorY += 4;
    }

    if (st.stockRows && st.stockRows.length > 0) {
      autoTable(doc, {
        startY: cursorY,
        margin: { left: 12, right: 12 },
        theme: 'grid',
        headStyles: { fillColor: tealLight, textColor: [15, 23, 42], fontStyle: 'bold', fontSize: 7.5 },
        bodyStyles: { fontSize: 7.5, textColor: [15, 23, 42] },
        head: [['SL', 'Product Name', 'Barcode/SKU', 'Category', 'Qty', 'Cost', 'Price', 'Stock Val', 'Status']],
        body: st.stockRows.map((p) => [
          p.sl,
          p.name,
          p.code,
          p.category,
          p.quantity,
          p.purchasePrice.toFixed(2),
          p.sellingPrice.toFixed(2),
          p.costValue.toFixed(2),
          p.status,
        ]),
      });
      cursorY = (doc as unknown as { lastAutoTable?: { finalY: number } }).lastAutoTable?.finalY || cursorY;
      cursorY += 4;
    }

    autoTable(doc, {
      startY: cursorY,
      margin: { left: 12, right: 12 },
      theme: 'grid',
      headStyles: { fillColor: tealLight, textColor: [15, 23, 42], fontStyle: 'bold', fontSize: 7.5 },
      bodyStyles: { fontSize: 7.5, textColor: [15, 23, 42] },
      footStyles: { fillColor: [248, 250, 252], textColor: [15, 23, 42], fontStyle: 'bold', fontSize: 7.5 },
      head: [['SL', 'Date', 'Invoice #', 'Customer', 'Qty', 'Method', 'Subtotal', 'Disc.', 'Net Sales', 'Paid', 'Due', 'Profit']],
      body:
        st.rows.length === 0
          ? [['-', `No sales recorded for ${st.periodLabel}`, '', '', '', '', '', '', '', '', '', '']]
          : st.rows.map((r) => [
              r.sl,
              r.date,
              r.invoiceNo,
              r.customerName,
              r.itemsCount,
              r.paymentMethod,
              r.subtotal.toFixed(2),
              r.discount.toFixed(2),
              r.grandTotal.toFixed(2),
              r.paidAmount.toFixed(2),
              r.dueAmount.toFixed(2),
              r.profit.toFixed(2),
            ]),
      foot: [
        [
          '',
          `Grand Total (${st.summary.ordersCount} Invoices)`,
          '',
          '',
          st.summary.itemsCount,
          '-',
          st.summary.subtotal.toFixed(2),
          st.summary.discount.toFixed(2),
          st.summary.grandTotal.toFixed(2),
          st.summary.paid.toFixed(2),
          st.summary.due.toFixed(2),
          st.summary.grossProfit.toFixed(2),
        ],
      ],
    });
    cursorY = (doc as unknown as { lastAutoTable?: { finalY: number } }).lastAutoTable?.finalY || cursorY;
    cursorY += 4;

    autoTable(doc, {
      startY: cursorY,
      margin: { left: 12, right: 12 },
      theme: 'grid',
      headStyles: { fillColor: [248, 250, 252], textColor: [15, 23, 42], fontStyle: 'bold', fontSize: 8 },
      bodyStyles: { fontStyle: 'bold', fontSize: 8.5, textColor: [15, 23, 42] },
      head: [['Invoices', 'Items', 'Net Sales', 'Paid', 'Due', 'Gross Profit', 'Expenses', 'Net Balance']],
      body: [
        [
          fmtInt(st.summary.ordersCount),
          fmtInt(st.summary.itemsCount),
          fmtPdfMoney(st.summary.grandTotal),
          fmtPdfMoney(st.summary.paid),
          fmtPdfMoney(st.summary.due),
          fmtPdfMoney(st.summary.grossProfit),
          fmtPdfMoney(st.summary.expenses),
          fmtPdfMoney(st.summary.netProfit),
        ],
      ],
    });
    cursorY = (doc as unknown as { lastAutoTable?: { finalY: number } }).lastAutoTable?.finalY || cursorY;
  } else {
    const rep = target.report;
    autoTable(doc, {
      startY: cursorY,
      margin: { left: 12, right: 12 },
      theme: 'grid',
      headStyles: { fillColor: tealLight, textColor: [15, 23, 42], fontStyle: 'bold', fontSize: 8 },
      bodyStyles: { fontSize: 8, textColor: [15, 23, 42] },
      footStyles: { fillColor: [248, 250, 252], textColor: [15, 23, 42], fontStyle: 'bold', fontSize: 8 },
      head: [rep.headers.map(sanitizePdfCell)],
      body:
        rep.rows.length === 0
          ? [[`No records found.`]]
          : rep.rows.map((r) => r.map(sanitizePdfCell)),
      ...(rep.totalsRow && rep.rows.length > 0 ? { foot: [rep.totalsRow.map(sanitizePdfCell)] } : {}),
    });
    cursorY = (doc as unknown as { lastAutoTable?: { finalY: number } }).lastAutoTable?.finalY || cursorY;
    if (rep.summaryCards && rep.summaryCards.length > 0) {
      cursorY += 4;
      autoTable(doc, {
        startY: cursorY,
        margin: { left: 12, right: 12 },
        theme: 'grid',
        headStyles: { fillColor: [248, 250, 252], textColor: [15, 23, 42], fontStyle: 'bold', fontSize: 8 },
        bodyStyles: { fontStyle: 'bold', fontSize: 8.5, textColor: [15, 23, 42] },
        head: [rep.summaryCards.map((c) => sanitizePdfCell(c.label))],
        body: [rep.summaryCards.map((c) => sanitizePdfCell(c.value))],
      });
      cursorY = (doc as unknown as { lastAutoTable?: { finalY: number } }).lastAutoTable?.finalY || cursorY;
    }
  }

  const sigY = Math.min(doc.internal.pageSize.getHeight() - 12, cursorY + 14);
  doc.setDrawColor(148, 163, 184);
  doc.line(14, sigY, 64, sigY);
  doc.line(pageWidth - 64, sigY, pageWidth - 14, sigY);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(51, 65, 85);
  doc.text('Prepared By', 39, sigY + 4, { align: 'center' });
  doc.text('Verified / Store Owner', pageWidth - 39, sigY + 4, { align: 'center' });

  const safeSlug = sanitizePdfCell(docTitle).toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 60);
  doc.save(`${safeSlug || 'statement'}.pdf`);
};

interface SheetPrintPreviewModalProps {
  target: SheetPreviewTarget | null;
  settings: StoreSettings;
  onClose: () => void;
  onTriggerNativePrint: (target: SheetPreviewTarget) => void;
}

export const SheetPrintPreviewModal: React.FC<SheetPrintPreviewModalProps> = ({
  target,
  settings,
  onClose,
  onTriggerNativePrint,
}) => {
  const [iframePrintTip, setIframePrintTip] = useState(false);

  if (!target) return null;

  const isInIframe = typeof window !== 'undefined' && window.self !== window.top;

  const handlePrintClick = () => {
    onTriggerNativePrint(target);
    if (isInIframe) {
      setIframePrintTip(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-white overflow-y-auto">
      {/* Minimalist Top Bar (hidden when printing) */}
      <div className="no-print sticky top-0 z-10 bg-white/95 backdrop-blur-sm border-b border-slate-200 px-4 py-3 space-y-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <button type="button" onClick={onClose} className="btn-secondary px-3.5 py-2 text-xs">
            <ArrowLeft className="w-4 h-4" />
            <span>Back</span>
          </button>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => downloadSheetPdfFile(target, settings)}
              className="btn-emerald px-3.5 py-2 text-xs"
            >
              <FileText className="w-4 h-4" />
              <span>Download PDF</span>
            </button>
            <button
              type="button"
              onClick={() => downloadSheetHtmlFile(target, settings)}
              className="btn-secondary px-3 py-2 text-xs"
            >
              <Download className="w-4 h-4 text-[#1f6f6a]" />
              <span>Save HTML</span>
            </button>
            <button
              type="button"
              onClick={handlePrintClick}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#2a7d78] hover:bg-[#226662] text-white text-xs font-bold whitespace-nowrap"
            >
              <Printer className="w-4 h-4" />
              <span>Print Now</span>
            </button>
          </div>
        </div>

        {(iframePrintTip || isInIframe) && (
          <div className="px-3 py-2 rounded-xl bg-amber-50 border border-amber-200 text-[11px] text-amber-900 flex flex-wrap items-center justify-between gap-2">
            <span>
              Inside the AI Studio preview frame on mobile Chrome, direct browser Print dialogs may be blocked by iframe security.
              Use <strong>Download PDF</strong> above to open &amp; print directly on your phone, or open the Shared App URL in Chrome.
            </span>
          </div>
        )}
      </div>

      {/* Pure White Excel/Salary-Sheet Paper Canvas */}
      <div className="max-w-[1120px] mx-auto bg-white p-4 sm:p-8">
        <SheetContent target={target} settings={settings} />
      </div>
    </div>
  );
};
