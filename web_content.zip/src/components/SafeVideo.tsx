import React, { useState, forwardRef, useRef, useImperativeHandle } from 'react';
import { Play, Film } from 'lucide-react';

export const RELIABLE_FALLBACK_VIDEO = 'https://vjs.zencdn.net/v/oceans.mp4';
export const SECONDARY_FALLBACK_VIDEO = 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4';

interface SafeVideoProps extends React.VideoHTMLAttributes<HTMLVideoElement> {
  src?: string;
  fallbackSrc?: string;
  className?: string;
  showFallbackThumbnail?: boolean;
}

export const SafeVideo = forwardRef<HTMLVideoElement, SafeVideoProps>(({
  src,
  fallbackSrc = RELIABLE_FALLBACK_VIDEO,
  className = '',
  showFallbackThumbnail = true,
  autoPlay = false,
  muted = true,
  loop = true,
  playsInline = true,
  ...props
}, ref) => {
  const innerRef = useRef<HTMLVideoElement>(null);
  useImperativeHandle(ref, () => innerRef.current as HTMLVideoElement);

  const [hasError, setHasError] = useState(false);
  const [triedFallback, setTriedFallback] = useState(false);
  const [activeSrc, setActiveSrc] = useState<string | undefined>(src);

  // If src changes externally, reset state
  React.useEffect(() => {
    setHasError(false);
    setTriedFallback(false);
    setActiveSrc(src);
  }, [src]);

  const handleError = () => {
    if (!triedFallback && fallbackSrc && activeSrc !== fallbackSrc) {
      setTriedFallback(true);
      setActiveSrc(fallbackSrc);
    } else {
      setHasError(true);
    }
  };

  if (hasError && showFallbackThumbnail) {
    return (
      <div 
        className={`relative bg-linear-to-br from-slate-900 via-indigo-950 to-slate-900 flex flex-col items-center justify-center text-white p-4 select-none ${className}`}
        onClick={props.onClick ? (e) => (props.onClick as any)(e) : undefined}
      >
        <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white mb-2 shadow-lg">
          <Play className="w-6 h-6 translate-x-0.5 fill-white" />
        </div>
        <div className="flex items-center gap-1.5 text-xs text-slate-300 font-medium">
          <Film className="w-3.5 h-3.5 text-rose-400" />
          <span>Video Clip Preview</span>
        </div>
      </div>
    );
  }

  return (
    <video
      ref={innerRef}
      src={activeSrc}
      className={className}
      autoPlay={autoPlay}
      muted={muted}
      loop={loop}
      playsInline={playsInline}
      preload="metadata"
      onError={handleError}
      {...props}
    >
      {activeSrc && <source src={activeSrc} type="video/mp4" onError={handleError} />}
      {fallbackSrc && activeSrc !== fallbackSrc && (
        <source src={fallbackSrc} type="video/mp4" onError={handleError} />
      )}
    </video>
  );
});

SafeVideo.displayName = 'SafeVideo';
