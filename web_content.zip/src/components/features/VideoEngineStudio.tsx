import { useState, useEffect, useRef } from "react";
import {
  VIDEO_ENGINES,
  CAMERA_MOTIONS,
  CAMERA_ANGLES,
  VISUAL_STYLES,
} from "@/constants/videoEngines";
import type {
  VideoEngineId,
  CameraMotionType,
  CameraAngle,
  VisualLightingStyle,
  VideoGenerationResult,
} from "@/types/video";
import type { Project, StoryboardScene } from "@/types";
import { optimizeVideoPrompt, generateVideoWithEngine, generateBatchStoryboardVideos } from "@/lib/videoEngine";
import { cn } from "@/lib/utils";
import {
  Sparkles, Video, Film, Play, Pause, RotateCcw, Download,
  Layers, CheckCircle2, Sliders, Eye, RefreshCw, Volume2,
  VolumeX, Maximize2, Zap, ArrowRight
} from "lucide-react";
import { UniversalMediaModal } from "@/components/common/UniversalMediaModal";

interface VideoEngineStudioProps {
  project?: Project;
  onProjectUpdate?: (updated: Project) => void;
  initialScene?: StoryboardScene;
}

export default function VideoEngineStudio({
  project,
  onProjectUpdate,
  initialScene,
}: VideoEngineStudioProps) {
  // Engine Selection
  const [selectedEngineId, setSelectedEngineId] = useState<VideoEngineId>("veo-2");
  const selectedEngine = VIDEO_ENGINES.find((e) => e.id === selectedEngineId) || VIDEO_ENGINES[0];

  // Generation Parameters
  const [rawPrompt, setRawPrompt] = useState(
    initialScene?.videoPrompt || initialScene?.visualDescription || "Astronauta caminhando em uma floresta bioluminescente alienígena ao entardecer com luz suave e partículas brilhantes flutuando."
  );
  const [negativePrompt, setNegativePrompt] = useState("distorted, blurry, deformed limbs, flickering, low quality, artifacts, watermark");
  const [cameraMotion, setCameraMotion] = useState<CameraMotionType>("PAN_RIGHT");
  const [cameraAngle, setCameraAngle] = useState<CameraAngle>("WIDE");
  const [visualStyle, setVisualStyle] = useState<VisualLightingStyle>("CINEMATIC");
  const [motionStrength, setMotionStrength] = useState<number>(7);
  const [duration, setDuration] = useState<number>(selectedEngine.defaultDuration);
  const [aspectRatio, setAspectRatio] = useState<"16:9" | "9:16" | "1:1">("16:9");
  const [resolution, setResolution] = useState<"720p" | "1080p" | "4K">("1080p");
  const [fps, setFps] = useState<number>(30);
  const [selectedSceneId, setSelectedSceneId] = useState<string>(initialScene?.id || (project?.storyboard?.scenes[0]?.id ?? ""));

  // AI Prompt Optimization State
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [optimizedDetails, setOptimizedDetails] = useState<{
    prompt?: string;
    cameraDirectives?: string;
    lightingSetup?: string;
  } | null>(null);

  // Video Generation & Player State
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [currentVideo, setCurrentVideo] = useState<VideoGenerationResult | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [videoProgress, setVideoProgress] = useState(0);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Batch Generation State
  const [isBatchGenerating, setIsBatchGenerating] = useState(false);
  const [batchStatus, setBatchStatus] = useState<{ current: number; total: number; sceneNumber: number } | null>(null);

  // Recent History in current session
  const [recentVideos, setRecentVideos] = useState<VideoGenerationResult[]>([]);

  // Universal Media Modal State
  const [modalMedia, setModalMedia] = useState<{
    isOpen: boolean;
    url: string;
    type: "VIDEO" | "IMAGE";
    title: string;
    prompt?: string;
    duration?: number;
  }>({
    isOpen: false,
    url: "",
    type: "VIDEO",
    title: "",
  });

  // Sincronizar cena selecionada caso o usuário altere o seletor de cena
  useEffect(() => {
    if (selectedSceneId && project?.storyboard?.scenes) {
      const found = project.storyboard.scenes.find((s) => s.id === selectedSceneId);
      if (found) {
        if (found.videoPrompt || found.visualDescription) {
          setRawPrompt(found.videoPrompt || found.visualDescription);
        }
        if (found.duration) {
          setDuration(Math.min(found.duration, selectedEngine.maxDuration));
        }
      }
    }
  }, [selectedSceneId, project, selectedEngine]);

  // Handler: Otimizar Prompt com Gemini 3.7 Flash
  const handleOptimizePrompt = async () => {
    if (!rawPrompt.trim()) return;
    setIsOptimizing(true);
    try {
      const result = await optimizeVideoPrompt({
        rawPrompt,
        engine: selectedEngineId,
        cameraMotion,
        cameraAngle,
        style: visualStyle,
      });

      setRawPrompt(result.prompt);
      if (result.negativePrompt) setNegativePrompt(result.negativePrompt);
      setOptimizedDetails({
        prompt: result.prompt,
        cameraDirectives: result.cameraDirectives,
        lightingSetup: result.lightingSetup,
      });
    } finally {
      setIsOptimizing(false);
    }
  };

  // Handler: Gerar Vídeo
  const handleGenerateVideo = async () => {
    if (!rawPrompt.trim()) return;
    setIsGenerating(true);
    setGenerationProgress(10);

    const interval = setInterval(() => {
      setGenerationProgress((prev) => (prev < 90 ? prev + Math.floor(Math.random() * 15) + 5 : prev));
    }, 400);

    try {
      const result = await generateVideoWithEngine({
        engine: selectedEngineId,
        prompt: rawPrompt,
        negativePrompt,
        cameraMotion,
        cameraAngle,
        style: visualStyle,
        motionStrength,
        duration,
        aspectRatio,
        resolution,
        fps,
        sceneId: selectedSceneId || undefined,
        projectId: project?.id,
        projectTitle: project?.title,
      });

      clearInterval(interval);
      setGenerationProgress(100);
      setCurrentVideo(result);
      setRecentVideos((prev) => [result, ...prev.filter((v) => v.id !== result.id)]);

      if (project && onProjectUpdate) {
        // Atualizar cena no projeto local
        const updatedScenes = project.storyboard?.scenes.map((s) => {
          if (s.id === selectedSceneId) {
            return { ...s, videoUrl: result.videoUrl, status: "COMPLETED" as const };
          }
          return s;
        });

        onProjectUpdate({
          ...project,
          storyboard: project.storyboard
            ? { ...project.storyboard, scenes: updatedScenes || [] }
            : undefined,
        });
      }
    } catch (error) {
      console.error("Falha ao gerar vídeo:", error);
    } finally {
      clearInterval(interval);
      setTimeout(() => {
        setIsGenerating(false);
        setGenerationProgress(0);
      }, 500);
    }
  };

  // Handler: Gerar Todas as Cenas em Lote
  const handleBatchGenerate = async () => {
    if (!project || !project.storyboard?.scenes.length) return;
    setIsBatchGenerating(true);
    try {
      const updated = await generateBatchStoryboardVideos(
        project,
        selectedEngineId,
        (current, total, sceneNumber) => {
          setBatchStatus({ current, total, sceneNumber });
        }
      );
      if (onProjectUpdate) onProjectUpdate(updated);
    } finally {
      setIsBatchGenerating(false);
      setBatchStatus(null);
    }
  };

  // Video Controls
  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  const handleTimeUpdate = () => {
    if (!videoRef.current) return;
    const progress = (videoRef.current.currentTime / videoRef.current.duration) * 100;
    setVideoProgress(isNaN(progress) ? 0 : progress);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header do Estúdio */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 studio-card border-studio-blue/30 bg-gradient-to-r from-studio-surface via-studio-panel to-studio-surface">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-studio-purple to-studio-blue flex items-center justify-center shadow-lg shadow-studio-blue/15">
            <Video className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-studio-text font-display">Estúdio de Motores de Vídeo AI</h2>
              <span className="task-badge text-[10px] bg-studio-blue/20 text-studio-blue border-studio-blue/30">
                CORE 2 Engine
              </span>
            </div>
            <p className="text-xs text-studio-text-muted">
              Geração de takes cinematográficos multimodais com Veo 2, Runway Gen-3, Luma Ray e Sora
            </p>
          </div>
        </div>

        {project?.storyboard && project.storyboard.scenes.length > 0 && (
          <button
            onClick={handleBatchGenerate}
            disabled={isBatchGenerating}
            className="btn-gold text-xs py-2 px-3.5 flex items-center gap-2 shrink-0 self-start sm:self-auto"
          >
            {isBatchGenerating ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Renderizando ({batchStatus?.current}/{batchStatus?.total})...</span>
              </>
            ) : (
              <>
                <Layers className="w-3.5 h-3.5" />
                <span>Renderizar Storyboard Completo ({project.storyboard.scenes.length} Cenas)</span>
              </>
            )}
          </button>
        )}
      </div>

      {/* Grid Principal: Seletor de Motores & Configurações de Câmera */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Painel Esquerdo / Parâmetros (7 Colunas) */}
        <div className="lg:col-span-7 space-y-5">
          
          {/* Seletor de Motor de Vídeo */}
          <div className="studio-card p-4 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-studio-text uppercase tracking-wider flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-studio-blue" />
                Motor de Geração de Vídeo
              </label>
              <span className="text-[11px] text-studio-text-muted">
                {selectedEngine.qualityTier} Quality · Max {selectedEngine.maxDuration}s
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {VIDEO_ENGINES.map((engine) => {
                const isSelected = engine.id === selectedEngineId;
                return (
                  <button
                    key={engine.id}
                    onClick={() => {
                      setSelectedEngineId(engine.id);
                      setDuration(Math.min(duration, engine.maxDuration));
                    }}
                    className={cn(
                      "p-3 rounded-xl border text-left transition-all relative overflow-hidden flex flex-col justify-between",
                      isSelected
                        ? "bg-studio-panel border-studio-blue shadow-md shadow-studio-blue/10 ring-1 ring-studio-blue/50"
                        : "bg-studio-surface border-studio-border hover:border-studio-border-hover hover:bg-studio-panel/50"
                    )}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-bold text-studio-text">{engine.name}</span>
                        {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-studio-blue shrink-0" />}
                      </div>
                      <p className="text-[10px] text-studio-text-muted mb-2 line-clamp-1">{engine.provider}</p>
                    </div>
                    <div className="flex items-center justify-between pt-1 border-t border-studio-border/50 text-[10px]">
                      <span className="text-studio-text-dim">{engine.badge}</span>
                      <span className="font-semibold text-studio-blue">
                        {engine.resolutions[0]}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Descrição do Motor Ativo */}
            <div className="p-2.5 rounded-lg bg-studio-panel/60 border border-studio-border text-xs text-studio-text-dim flex items-start gap-2">
              <Film className="w-4 h-4 text-studio-blue shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-studio-text">{selectedEngine.name}: </span>
                <span>{selectedEngine.description} </span>
                <span className="text-[11px] text-studio-gold font-medium block mt-0.5">
                  ★ {selectedEngine.highlight}
                </span>
              </div>
            </div>
          </div>

          {/* Vínculo de Cena (caso exista Storyboard) */}
          {project?.storyboard?.scenes && project.storyboard.scenes.length > 0 && (
            <div className="studio-card p-4 space-y-2.5">
              <label className="text-xs font-bold text-studio-text uppercase tracking-wider flex items-center gap-1.5">
                <Film className="w-3.5 h-3.5 text-studio-purple" />
                Vincular à Cena do Storyboard
              </label>
              <div className="flex gap-2 overflow-x-auto pb-1">
                {project.storyboard.scenes.map((scene) => {
                  const isSelected = scene.id === selectedSceneId;
                  const hasVideo = !!scene.videoUrl;
                  return (
                    <button
                      key={scene.id}
                      onClick={() => setSelectedSceneId(scene.id)}
                      className={cn(
                        "px-3 py-2 rounded-lg border text-xs font-medium shrink-0 flex items-center gap-1.5 transition-all",
                        isSelected
                          ? "bg-studio-blue/15 border-studio-blue text-studio-blue shadow-xs"
                          : "bg-studio-panel border-studio-border text-studio-text-muted hover:text-studio-text"
                      )}
                    >
                      <span>Cena {scene.sceneNumber}</span>
                      {hasVideo && (
                        <span className="w-2 h-2 rounded-full bg-studio-green inline-block" title="Vídeo gerado" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Editor de Prompt & Assistente Gemini */}
          <div className="studio-card p-4 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-studio-text uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-studio-gold" />
                Prompt de Vídeo Cinematográfico
              </label>
              <button
                onClick={handleOptimizePrompt}
                disabled={isOptimizing || !rawPrompt.trim()}
                className="text-xs font-semibold text-studio-gold hover:text-studio-gold/80 flex items-center gap-1.5 bg-studio-gold/10 px-2.5 py-1 rounded-lg border border-studio-gold/20 hover:bg-studio-gold/20 transition-all disabled:opacity-50"
              >
                <Sparkles className={cn("w-3 h-3", isOptimizing && "animate-spin")} />
                {isOptimizing ? "Otimizando com Gemini 3.7..." : "Otimizar com Gemini"}
              </button>
            </div>

            <textarea
              value={rawPrompt}
              onChange={(e) => setRawPrompt(e.target.value)}
              rows={4}
              placeholder="Descreva a ação da cena, movimentos, ambiente, iluminação e enquadramento..."
              className="w-full bg-studio-panel border border-studio-border rounded-xl p-3 text-xs text-studio-text leading-relaxed focus:outline-hidden focus:border-studio-blue focus:ring-1 focus:ring-studio-blue transition-all"
            />

            {/* Negative Prompt */}
            <div>
              <label className="text-[11px] font-semibold text-studio-text-muted mb-1 block">
                Negative Prompt (O que evitar na geração):
              </label>
              <input
                type="text"
                value={negativePrompt}
                onChange={(e) => setNegativePrompt(e.target.value)}
                className="w-full bg-studio-panel border border-studio-border rounded-lg px-3 py-1.5 text-xs text-studio-text-dim focus:outline-hidden focus:border-studio-blue"
              />
            </div>

            {/* Detalhes da Otimização do Gemini */}
            {optimizedDetails?.cameraDirectives && (
              <div className="p-2.5 rounded-lg bg-studio-blue/5 border border-studio-blue/20 text-xs space-y-1">
                <p className="text-[11px] font-semibold text-studio-blue">Diretiva de Câmera da IA:</p>
                <p className="text-studio-text-dim text-[11px]">{optimizedDetails.cameraDirectives}</p>
                {optimizedDetails.lightingSetup && (
                  <p className="text-studio-text-muted text-[11px]">
                    <strong className="text-studio-text-dim">Iluminação:</strong> {optimizedDetails.lightingSetup}
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Cinemática & Parâmetros de Câmera */}
          <div className="studio-card p-4 space-y-4">
            <h3 className="text-xs font-bold text-studio-text uppercase tracking-wider flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-studio-blue" />
              Direção de Fotografia & Parâmetros
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Movimento de Câmera */}
              <div>
                <label className="text-[11px] font-semibold text-studio-text-dim mb-1.5 block">
                  Movimento de Câmera
                </label>
                <select
                  value={cameraMotion}
                  onChange={(e) => setCameraMotion(e.target.value as CameraMotionType)}
                  className="w-full bg-studio-panel border border-studio-border rounded-lg px-3 py-2 text-xs text-studio-text focus:outline-hidden focus:border-studio-blue"
                >
                  {CAMERA_MOTIONS.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Ângulo & Enquadramento */}
              <div>
                <label className="text-[11px] font-semibold text-studio-text-dim mb-1.5 block">
                  Enquadramento / Ângulo
                </label>
                <select
                  value={cameraAngle}
                  onChange={(e) => setCameraAngle(e.target.value as CameraAngle)}
                  className="w-full bg-studio-panel border border-studio-border rounded-lg px-3 py-2 text-xs text-studio-text focus:outline-hidden focus:border-studio-blue"
                >
                  {CAMERA_ANGLES.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Estilo Visual & Iluminação */}
              <div>
                <label className="text-[11px] font-semibold text-studio-text-dim mb-1.5 block">
                  Estilo Visual & Iluminação
                </label>
                <select
                  value={visualStyle}
                  onChange={(e) => setVisualStyle(e.target.value as VisualLightingStyle)}
                  className="w-full bg-studio-panel border border-studio-border rounded-lg px-3 py-2 text-xs text-studio-text focus:outline-hidden focus:border-studio-blue"
                >
                  {VISUAL_STYLES.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Proporção de Tela */}
              <div>
                <label className="text-[11px] font-semibold text-studio-text-dim mb-1.5 block">
                  Proporção (Aspect Ratio)
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {(["16:9", "9:16", "1:1"] as const).map((ratio) => (
                    <button
                      key={ratio}
                      type="button"
                      onClick={() => setAspectRatio(ratio)}
                      className={cn(
                        "py-1.5 rounded-md border text-xs font-semibold transition-all",
                        aspectRatio === ratio
                          ? "bg-studio-blue/15 border-studio-blue text-studio-blue"
                          : "bg-studio-panel border-studio-border text-studio-text-muted hover:text-studio-text"
                      )}
                    >
                      {ratio} {ratio === "9:16" ? "(Reels)" : ratio === "16:9" ? "(YouTube)" : "(Feed)"}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Sliders: Duração, Motion Strength, Resolução, FPS */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 border-t border-studio-border">
              <div>
                <div className="flex justify-between text-[11px] text-studio-text-muted mb-1">
                  <span>Duração</span>
                  <span className="font-bold text-studio-text">{duration}s</span>
                </div>
                <input
                  type="range"
                  min={3}
                  max={selectedEngine.maxDuration}
                  step={1}
                  value={duration}
                  onChange={(e) => setDuration(Number(e.target.value))}
                  className="w-full accent-studio-blue h-1.5 bg-studio-panel rounded-lg"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px] text-studio-text-muted mb-1">
                  <span>Movimento</span>
                  <span className="font-bold text-studio-text">{motionStrength}/10</span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={10}
                  step={1}
                  value={motionStrength}
                  onChange={(e) => setMotionStrength(Number(e.target.value))}
                  className="w-full accent-studio-purple h-1.5 bg-studio-panel rounded-lg"
                />
              </div>

              <div>
                <label className="text-[11px] text-studio-text-muted block mb-1">Resolução</label>
                <select
                  value={resolution}
                  onChange={(e) => setResolution(e.target.value as "720p" | "1080p" | "4K")}
                  className="w-full bg-studio-panel border border-studio-border rounded-md px-2 py-1 text-xs text-studio-text focus:outline-hidden"
                >
                  {selectedEngine.resolutions.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[11px] text-studio-text-muted block mb-1">Taxa de Quadros</label>
                <select
                  value={fps}
                  onChange={(e) => setFps(Number(e.target.value))}
                  className="w-full bg-studio-panel border border-studio-border rounded-md px-2 py-1 text-xs text-studio-text focus:outline-hidden"
                >
                  {selectedEngine.fpsOptions.map((f) => (
                    <option key={f} value={f}>
                      {f} FPS
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Botão de Geração Principal */}
            <div className="pt-2">
              <button
                onClick={handleGenerateVideo}
                disabled={isGenerating || !rawPrompt.trim()}
                className="btn-primary w-full py-3 text-sm font-semibold flex items-center justify-center gap-2 shadow-lg shadow-studio-blue/20"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Renderizando com {selectedEngine.name} ({generationProgress}%)...</span>
                  </>
                ) : (
                  <>
                    <Video className="w-4 h-4" />
                    <span>Gerar Take de Vídeo com {selectedEngine.name}</span>
                    <ArrowRight className="w-4 h-4 ml-1" />
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Painel Direito / Player & Renders (5 Colunas) */}
        <div className="lg:col-span-5 space-y-5">
          
          {/* Player de Vídeo em Tempo Real */}
          <div className="studio-card p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-studio-text uppercase tracking-wider flex items-center gap-1.5">
                <Eye className="w-3.5 h-3.5 text-studio-green" />
                Monitor de Renderização
              </h3>
              {currentVideo && (
                <span className="task-badge text-[10px] bg-studio-green/15 text-studio-green border-studio-green/30">
                  {currentVideo.engineName}
                </span>
              )}
            </div>

            {/* Video Container */}
            <div
              className={cn(
                "w-full rounded-xl bg-black/90 border border-studio-border relative overflow-hidden flex items-center justify-center",
                aspectRatio === "9:16" ? "aspect-9/16 max-h-[460px] mx-auto" : "aspect-video"
              )}
            >
              {isGenerating ? (
                <div className="flex flex-col items-center justify-center p-6 text-center space-y-3">
                  <div className="w-12 h-12 rounded-full border-2 border-studio-blue/30 border-t-studio-blue animate-spin" />
                  <p className="text-xs font-semibold text-studio-text">Renderizando frame a frame...</p>
                  <p className="text-[11px] text-studio-text-muted">
                    Aplicando física de movimento e iluminação {visualStyle.toLowerCase()}
                  </p>
                  <div className="w-48 bg-studio-panel rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-studio-blue h-full transition-all duration-300"
                      style={{ width: `${generationProgress}%` }}
                    />
                  </div>
                </div>
              ) : currentVideo ? (
                <div className="w-full h-full relative group">
                  <video
                    ref={videoRef}
                    src={currentVideo.videoUrl}
                    poster={currentVideo.thumbnailUrl}
                    loop
                    muted={isMuted}
                    onTimeUpdate={handleTimeUpdate}
                    onEnded={() => setIsPlaying(false)}
                    className="w-full h-full object-cover"
                  />

                  {/* Overlay Controls */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-between p-3">
                    <div className="flex justify-between items-center text-xs text-white">
                      <span className="font-semibold">{currentVideo.engineName}</span>
                      <span className="bg-black/50 px-2 py-0.5 rounded text-[10px]">
                        {currentVideo.resolution} · {currentVideo.fps}fps
                      </span>
                    </div>

                    <div className="space-y-2">
                      {/* Timeline Bar */}
                      <div className="w-full bg-white/20 h-1 rounded-full overflow-hidden">
                        <div
                          className="bg-studio-blue h-full transition-all"
                          style={{ width: `${videoProgress}%` }}
                        />
                      </div>

                      {/* Controls Buttons */}
                      <div className="flex items-center justify-between text-white">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={togglePlay}
                            className="p-1.5 rounded-lg bg-white/20 hover:bg-white/30 transition-all"
                          >
                            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                          </button>
                          <button
                            onClick={() => setIsMuted(!isMuted)}
                            className="p-1.5 rounded-lg bg-white/20 hover:bg-white/30 transition-all"
                          >
                            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                          </button>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              if (currentVideo) {
                                setModalMedia({
                                  isOpen: true,
                                  url: currentVideo.videoUrl,
                                  type: "VIDEO",
                                  title: `${currentVideo.engineName} — Take Gerado`,
                                  prompt: currentVideo.prompt,
                                  duration: currentVideo.duration,
                                });
                              }
                            }}
                            className="p-1.5 rounded-lg bg-white/20 hover:bg-white/30 transition-all"
                            title="Assistir em Tela Cheia / Player Universal"
                          >
                            <Maximize2 className="w-4 h-4" />
                          </button>
                          <a
                            href={currentVideo.videoUrl}
                            download="take-ia.mp4"
                            target="_blank"
                            rel="noreferrer"
                            className="p-1.5 rounded-lg bg-white/20 hover:bg-white/30 transition-all"
                            title="Baixar MP4"
                          >
                            <Download className="w-4 h-4" />
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Play Central Button if paused */}
                  {!isPlaying && (
                    <button
                      onClick={togglePlay}
                      className="absolute inset-0 m-auto w-12 h-12 rounded-full bg-studio-blue/90 text-white flex items-center justify-center shadow-lg hover:scale-105 transition-transform"
                    >
                      <Play className="w-5 h-5 ml-0.5" />
                    </button>
                  )}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center p-6 text-center space-y-2 text-studio-text-muted">
                  <Film className="w-10 h-10 text-studio-border mb-1" />
                  <p className="text-xs font-semibold text-studio-text-dim">Nenhum take renderizado ainda</p>
                  <p className="text-[11px] max-w-[220px]">
                    Configure o prompt e clique em <strong>Gerar Take de Vídeo</strong> para iniciar.
                  </p>
                </div>
              )}
            </div>

            {/* Metadados Técnicos do Vídeo Atual */}
            {currentVideo && (
              <div className="p-3 rounded-lg bg-studio-panel border border-studio-border space-y-2 text-xs">
                <div className="flex items-center justify-between text-studio-text-dim border-b border-studio-border pb-1.5">
                  <span className="font-semibold text-studio-text">Take Gerado com Sucesso</span>
                  <span className="text-[10px] text-studio-green font-medium">✓ Sincronizado</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[11px] text-studio-text-muted">
                  <div>
                    <span className="text-studio-text-dim">Motor:</span> {currentVideo.engineName}
                  </div>
                  <div>
                    <span className="text-studio-text-dim">Duração:</span> {currentVideo.duration}s
                  </div>
                  <div>
                    <span className="text-studio-text-dim">Câmera:</span> {currentVideo.cameraMotion}
                  </div>
                  <div>
                    <span className="text-studio-text-dim">Formato:</span> {currentVideo.aspectRatio} ({currentVideo.resolution})
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Histórico Recente de Renders */}
          {recentVideos.length > 0 && (
            <div className="studio-card p-4 space-y-3">
              <h3 className="text-xs font-bold text-studio-text uppercase tracking-wider flex items-center gap-1.5">
                <RotateCcw className="w-3.5 h-3.5 text-studio-purple" />
                Takes Recentes na Sessão ({recentVideos.length})
              </h3>
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {recentVideos.map((video) => (
                  <div
                    key={video.id}
                    onClick={() => setCurrentVideo(video)}
                    className={cn(
                      "p-2 rounded-lg border flex items-center gap-3 cursor-pointer transition-all",
                      currentVideo?.id === video.id
                        ? "bg-studio-blue/10 border-studio-blue/40"
                        : "bg-studio-panel border-studio-border hover:border-studio-border-hover"
                    )}
                  >
                    <div className="w-12 h-8 rounded bg-black overflow-hidden relative shrink-0">
                      <img src={video.thumbnailUrl} alt="Thumbnail" className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                        <Play className="w-3 h-3 text-white" />
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-studio-text truncate">{video.engineName}</p>
                      <p className="text-[10px] text-studio-text-muted truncate">{video.prompt}</p>
                    </div>
                    <span className="text-[10px] text-studio-text-dim shrink-0">{video.duration}s</span>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

      </div>

      {/* Universal Media Watch / Fullscreen Modal */}
      <UniversalMediaModal
        isOpen={modalMedia.isOpen}
        onClose={() => setModalMedia((prev) => ({ ...prev, isOpen: false }))}
        mediaUrl={modalMedia.url}
        mediaType={modalMedia.type}
        title={modalMedia.title}
        prompt={modalMedia.prompt}
        durationSeconds={modalMedia.duration}
      />
    </div>
  );
}
