// ============================================================
// AI CREATOR STUDIO — CORE 2.0 PUBLISHING QUEUE & AUDIT LOGS
// ============================================================

import React, { useState, useEffect } from "react";
import type { PublishingJob, PublishingLogEntry, PublishingJobStatus } from "@/types";
import {
  Clock,
  CheckCircle2,
  AlertCircle,
  RotateCw,
  Trash2,
  ExternalLink,
  ShieldCheck,
  Filter,
  FileText,
  Layers,
  Youtube,
  Sparkles,
  Instagram,
  Facebook,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import {
  getPublishingJobs,
  deletePublishingJob,
  retryPublishingJob,
  getAuditLogs,
} from "@/lib/publishingScheduler";

export const PublishingQueueView: React.FC = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<"QUEUE" | "LOGS">("QUEUE");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [jobs, setJobs] = useState<PublishingJob[]>([]);
  const [logs, setLogs] = useState<PublishingLogEntry[]>([]);
  const [retryingId, setRetryingId] = useState<string | null>(null);

  const loadData = () => {
    setJobs(getPublishingJobs());
    setLogs(getAuditLogs());
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleRetry = async (jobId: string) => {
    setRetryingId(jobId);
    try {
      await retryPublishingJob(jobId);
      loadData();
      toast({ title: "Reenvio Concluído", description: "A publicação foi reenviada ao canal de destino." });
    } catch (err) {
      toast({ title: "Erro no Reenvio", description: "Não foi possível reenviar.", variant: "destructive" });
    } finally {
      setRetryingId(null);
    }
  };

  const handleCancel = (jobId: string) => {
    deletePublishingJob(jobId);
    loadData();
    toast({ title: "Publicação Cancelada", description: "O item foi removido da fila de publicação." });
  };

  const filteredJobs = jobs.filter((j) => {
    if (statusFilter === "ALL") return true;
    return j.status === statusFilter;
  });

  const getStatusBadge = (status: PublishingJobStatus) => {
    switch (status) {
      case "PUBLISHED":
        return (
          <span className="px-2.5 py-0.5 text-xs font-bold rounded-full bg-emerald-100 text-emerald-700 border border-emerald-200 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" /> Publicado
          </span>
        );
      case "SCHEDULED":
        return (
          <span className="px-2.5 py-0.5 text-xs font-bold rounded-full bg-blue-100 text-studio-blue border border-blue-200 flex items-center gap-1">
            <Clock className="w-3 h-3" /> Agendado
          </span>
        );
      case "PROCESSING":
        return (
          <span className="px-2.5 py-0.5 text-xs font-bold rounded-full bg-sky-100 text-sky-700 border border-sky-200 flex items-center gap-1 animate-pulse">
            <RotateCw className="w-3 h-3 animate-spin" /> Processando
          </span>
        );
      case "FAILED":
        return (
          <span className="px-2.5 py-0.5 text-xs font-bold rounded-full bg-red-100 text-red-700 border border-red-200 flex items-center gap-1">
            <AlertCircle className="w-3 h-3" /> Falhou
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-0.5 text-xs font-bold rounded-full bg-studio-panel text-studio-text-dim border border-studio-border">
            {status}
          </span>
        );
    }
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case "YOUTUBE":
        return <Youtube className="w-4 h-4 text-red-400" />;
      case "TIKTOK":
        return <Sparkles className="w-4 h-4 text-cyan-400" />;
      case "INSTAGRAM":
        return <Instagram className="w-4 h-4 text-pink-400" />;
      case "FACEBOOK":
        return <Facebook className="w-4 h-4 text-blue-400" />;
      default:
        return <Layers className="w-4 h-4 text-zinc-400" />;
    }
  };

  return (
    <div className="space-y-6" id="publishing-queue-view">
      {/* Header & Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-xl bg-studio-surface border border-studio-border shadow-xs">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 text-xs font-bold rounded bg-studio-blue/10 text-studio-blue border border-studio-blue/20">
              CORE 2.0
            </span>
            <h2 className="text-xl font-bold text-studio-text flex items-center gap-2">
              <Layers className="w-5 h-5 text-studio-blue" />
              Fila de Publicação & Logs de Auditoria
            </h2>
          </div>
          <p className="text-sm text-studio-text-muted">
            Acompanhe o status de envio em tempo real, gerencie agendamentos e consulte o histórico de auditoria.
          </p>
        </div>

        {/* Tab Selector */}
        <div className="flex rounded-lg bg-studio-panel border border-studio-border p-1">
          <button
            onClick={() => setActiveTab("QUEUE")}
            className={`px-4 py-1.5 text-xs rounded-md font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === "QUEUE" ? "bg-white text-studio-blue shadow-xs font-bold" : "text-studio-text-muted hover:text-studio-text"
            }`}
          >
            <Layers className="w-3.5 h-3.5" /> Fila de Publicações ({jobs.length})
          </button>
          <button
            onClick={() => setActiveTab("LOGS")}
            className={`px-4 py-1.5 text-xs rounded-md font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === "LOGS" ? "bg-white text-studio-blue shadow-xs font-bold" : "text-studio-text-muted hover:text-studio-text"
            }`}
          >
            <FileText className="w-3.5 h-3.5" /> Log de Auditoria ({logs.length})
          </button>
        </div>
      </div>

      {activeTab === "QUEUE" ? (
        /* Queue View */
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            <span className="text-xs text-studio-text-muted flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Filtrar:
            </span>
            {["ALL", "SCHEDULED", "PUBLISHED", "PROCESSING", "FAILED"].map((s) => (
              <button
                key={s}
                onClick={() => setStatusFilter(s)}
                className={`px-3 py-1 text-xs rounded-lg font-medium transition-all ${
                  statusFilter === s
                    ? "bg-studio-blue text-white shadow-xs"
                    : "bg-studio-panel border border-studio-border text-studio-text-muted hover:text-studio-text"
                }`}
              >
                {s === "ALL" ? "Todos" : s === "SCHEDULED" ? "Agendados" : s === "PUBLISHED" ? "Publicados" : s === "PROCESSING" ? "Em Processo" : "Falhas"}
              </button>
            ))}
          </div>

          {/* Job List */}
          {filteredJobs.length === 0 ? (
            <div className="p-12 text-center rounded-xl bg-studio-surface border border-studio-border text-studio-text-muted shadow-xs">
              <Layers className="w-10 h-10 mx-auto mb-2 opacity-40 text-studio-blue" />
              <p className="text-sm">Nenhuma publicação encontrada para o filtro selecionado.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredJobs.map((job) => (
                <div
                  key={job.id}
                  id={`queue-card-${job.id}`}
                  className="p-5 rounded-xl bg-studio-surface border border-studio-border hover:border-studio-blue/40 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xs"
                >
                  {/* Left: Thumbnail & Info */}
                  <div className="flex items-start gap-4">
                    <div className="relative w-24 h-16 rounded-lg overflow-hidden bg-studio-panel border border-studio-border flex-shrink-0">
                      <img
                        src={job.metadata.thumbnailUrl || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80"}
                        alt="Thumbnail"
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute bottom-1 right-1 px-1 py-0.2 bg-black/70 text-[8px] text-white rounded font-mono">
                        {job.metadata.aspectRatio}
                      </span>
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        {getPlatformIcon(job.platform)}
                        <span className="text-xs font-semibold text-studio-text-dim">{job.channelName}</span>
                        {getStatusBadge(job.status)}
                        {job.isMadeForKids && (
                          <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-amber-100 text-amber-800 border border-amber-200">
                            COPPA Kids
                          </span>
                        )}
                      </div>

                      <h4 className="text-sm font-bold text-studio-text line-clamp-1">
                        {job.metadata.title}
                      </h4>

                      <div className="flex items-center gap-3 text-xs text-studio-text-muted">
                        {job.scheduledAt && (
                          <span>Agendado para: <strong className="text-studio-blue">{new Date(job.scheduledAt).toLocaleString("pt-BR")}</strong></span>
                        )}
                        {job.publishedAt && (
                          <span>Publicado em: <strong className="text-emerald-600">{new Date(job.publishedAt).toLocaleString("pt-BR")}</strong></span>
                        )}
                        {job.error && (
                          <span className="text-red-500">Erro: {job.error}</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Right Actions */}
                  <div className="flex items-center gap-2 self-end md:self-center">
                    {job.platformPostUrl && (
                      <a
                        href={job.platformPostUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="p-2 rounded-lg bg-studio-panel hover:bg-studio-border text-studio-text text-xs flex items-center gap-1.5 border border-studio-border shadow-xs"
                      >
                        <ExternalLink className="w-3.5 h-3.5" /> Ver Post
                      </a>
                    )}

                    {job.status === "FAILED" && (
                      <Button
                        size="sm"
                        onClick={() => handleRetry(job.id)}
                        disabled={retryingId === job.id}
                        className="bg-red-600 hover:bg-red-700 text-white text-xs gap-1.5 h-8 shadow-xs"
                      >
                        <RotateCw className={`w-3.5 h-3.5 ${retryingId === job.id ? "animate-spin" : ""}`} />
                        Reenviar
                      </Button>
                    )}

                    {job.status === "SCHEDULED" && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleCancel(job.id)}
                        className="text-studio-text-muted hover:text-red-500 text-xs gap-1 h-8"
                      >
                        <Trash2 className="w-3.5 h-3.5" /> Cancelar
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        /* Audit Logs View */
        <div className="p-5 rounded-xl bg-studio-surface border border-studio-border shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-studio-text flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              Histórico Completo de Auditoria de Ações
            </h3>
            <span className="text-xs text-studio-text-muted">Últimos {logs.length} registros</span>
          </div>

          <div className="space-y-2">
            {logs.map((log) => (
              <div
                key={log.id}
                className="p-3 rounded-lg bg-studio-panel border border-studio-border flex items-start justify-between gap-3 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-studio-text-muted text-[11px]">
                      {new Date(log.timestamp).toLocaleString("pt-BR")}
                    </span>
                    <span className={`px-2 py-0.5 text-[10px] font-bold rounded ${
                      log.action === "PUBLISH" ? "bg-emerald-100 text-emerald-700 border border-emerald-200" :
                      log.action === "SCHEDULE" ? "bg-blue-100 text-studio-blue border border-blue-200" :
                      log.action === "CONNECT" ? "bg-indigo-100 text-indigo-700 border border-indigo-200" :
                      "bg-slate-100 text-slate-700 border border-slate-200"
                    }`}>
                      {log.action}
                    </span>
                    <span className="text-studio-text-dim font-semibold">{log.platform}</span>
                  </div>
                  <p className="text-studio-text">{log.details}</p>
                </div>

                <span className={`px-2 py-0.5 text-[10px] font-bold rounded ${
                  log.status === "SUCCESS" ? "text-emerald-700 bg-emerald-100 border border-emerald-200" :
                  log.status === "FAILED" ? "text-red-700 bg-red-100 border border-red-200" :
                  "text-studio-blue bg-blue-100 border border-blue-200"
                }`}>
                  {log.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
