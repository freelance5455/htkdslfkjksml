import { useState } from "react";
import type { Storyboard, StoryboardScene } from "@/types";
import { cn, formatDuration, getStatusColor, getStatusLabel } from "@/lib/utils";
import { Image, Video, Music, Mic, Sparkles, Play, Pause, Film, CheckCircle2, Zap, Loader2, Maximize2 } from "lucide-react";
import { UniversalMediaModal } from "@/components/common/UniversalMediaModal";

interface StoryboardViewProps {
  storyboard: Storyboard;
  onGenerateVideo?: (scene: StoryboardScene) => void;
  onGenerateImage?: (scene: StoryboardScene) => void;
  onGenerateAudio?: (scene: StoryboardScene) => void;
  onOpenVideoStudio?: () => void;
  onOpenImageStudio?: () => void;
  onOpenAudioStudio?: () => void;
  onGenerateAllMediaFast?: () => void;
  isGeneratingAll?: boolean;
  fastProgress?: { stage: string; percent: number };
}

export default function StoryboardView({
  storyboard,
  onGenerateVideo,
  onGenerateImage,
  onGenerateAudio,
  onOpenVideoStudio,
  onOpenImageStudio,
  onOpenAudioStudio,
  onGenerateAllMediaFast,
  isGeneratingAll,
  fastProgress,
}: StoryboardViewProps) {
  const completedVideos = storyboard.scenes.filter((s) => !!s.videoUrl).length;
  const completedImages = storyboard.scenes.filter((s) => !!s.imageUrl).length;

  const [activeModalMedia, setActiveModalMedia] = useState<{
    isOpen: boolean;
    url: string;
    type: "VIDEO" | "IMAGE";
    title: string;
    description?: string;
    prompt?: string;
    duration?: number;
  }>({
    isOpen: false,
    url: "",
    type: "VIDEO",
    title: "",
  });

  const handleOpenMedia = (scene: StoryboardScene) => {
    if (scene.videoUrl) {
      setActiveModalMedia({
        isOpen: true,
        url: scene.videoUrl,
        type: "VIDEO",
        title: `Cena #${scene.sceneNumber} — Vídeo AI`,
        description: scene.visualDescription,
        prompt: scene.videoPrompt || scene.imagePrompt,
        duration: scene.duration,
      });
    } else if (scene.imageUrl) {
      setActiveModalMedia({
        isOpen: true,
        url: scene.imageUrl,
        type: "IMAGE",
        title: `Cena #${scene.sceneNumber} — Imagem de Conceito`,
        description: scene.visualDescription,
        prompt: scene.imagePrompt,
      });
    }
  };

  return (
    <div className="animate-fade-in space-y-4">
      {/* Fast Parallel Progress HUD */}
      {isGeneratingAll && fastProgress && (
        <div className="p-3.5 rounded-xl bg-studio-panel border border-studio-gold/40 space-y-2 shadow-lg shadow-studio-gold/5 animate-fade-in">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin text-studio-gold" />
              <span className="font-bold text-studio-text">{fastProgress.stage}</span>
            </div>
            <span className="font-mono font-bold text-studio-gold">{fastProgress.percent}%</span>
          </div>
          <div className="w-full h-1.5 rounded-full bg-studio-surface overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-amber-500 via-studio-gold to-emerald-400 transition-all duration-300 rounded-full"
              style={{ width: `${fastProgress.percent}%` }}
            />
          </div>
        </div>
      )}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-studio-border">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-base font-bold text-studio-text font-display">
              Storyboard — {storyboard.totalScenes} cenas
            </h3>
            {completedVideos > 0 && (
              <span className="task-badge text-[11px] bg-studio-green/15 text-studio-green border-studio-green/30">
                {completedVideos}/{storyboard.totalScenes} Vídeos
              </span>
            )}
            {completedImages > 0 && (
              <span className="task-badge text-[11px] bg-studio-blue/15 text-studio-blue border-studio-blue/30">
                {completedImages}/{storyboard.totalScenes} Imagens
              </span>
            )}
          </div>
          <span className="text-xs text-studio-text-muted">{formatDuration(storyboard.totalDuration)} de duração total estimada</span>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {onGenerateAllMediaFast && (
            <button
              onClick={onGenerateAllMediaFast}
              disabled={isGeneratingAll}
              className="btn-gold text-xs py-1.5 px-3 flex items-center gap-1.5 shadow-md shadow-studio-gold/10"
            >
              {isGeneratingAll ? (
                <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Gerando Tudo em Paralelo...</>
              ) : (
                <><Zap className="w-3.5 h-3.5 text-black" /> Gerar Todas as Mídias Rápido</>
              )}
            </button>
          )}

          {onOpenImageStudio && (
            <button
              onClick={onOpenImageStudio}
              className="btn-secondary text-xs py-1.5 px-3 flex items-center gap-1.5"
            >
              <Image className="w-3.5 h-3.5 text-studio-blue" />
              <span>Estúdio de Imagens</span>
            </button>
          )}

          {onOpenAudioStudio && (
            <button
              onClick={onOpenAudioStudio}
              className="btn-secondary text-xs py-1.5 px-3 flex items-center gap-1.5"
            >
              <Mic className="w-3.5 h-3.5 text-studio-green" />
              <span>Estúdio de Voz & Áudio</span>
            </button>
          )}

          {onOpenVideoStudio && (
            <button
              onClick={onOpenVideoStudio}
              className="btn-primary text-xs py-1.5 px-3 flex items-center gap-1.5"
            >
              <Video className="w-3.5 h-3.5" />
              <span>Estúdio de Vídeo</span>
            </button>
          )}
        </div>
      </div>

      <div className="space-y-3">
        {storyboard.scenes.map((scene) => (
          <SceneCard
            key={scene.id}
            scene={scene}
            onWatchMedia={() => handleOpenMedia(scene)}
            onGenerateVideo={onGenerateVideo ? () => onGenerateVideo(scene) : undefined}
            onGenerateImage={onGenerateImage ? () => onGenerateImage(scene) : undefined}
            onGenerateAudio={onGenerateAudio ? () => onGenerateAudio(scene) : undefined}
          />
        ))}
      </div>

      {/* Universal Media Watch Modal */}
      <UniversalMediaModal
        isOpen={activeModalMedia.isOpen}
        onClose={() => setActiveModalMedia((prev) => ({ ...prev, isOpen: false }))}
        mediaUrl={activeModalMedia.url}
        mediaType={activeModalMedia.type}
        title={activeModalMedia.title}
        description={activeModalMedia.description}
        prompt={activeModalMedia.prompt}
        durationSeconds={activeModalMedia.duration}
      />
    </div>
  );
}

function SceneCard({
  scene,
  onWatchMedia,
  onGenerateVideo,
  onGenerateImage,
  onGenerateAudio,
}: {
  scene: StoryboardScene;
  onWatchMedia?: () => void;
  onGenerateVideo?: () => void;
  onGenerateImage?: () => void;
  onGenerateAudio?: () => void;
}) {
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <div className="studio-card p-4 animate-fade-in space-y-3">
      <div className="flex flex-col sm:flex-row gap-4">
        {/* Scene Media (Image or Video preview with click-to-watch) */}
        <div
          onClick={() => {
            if (scene.videoUrl || scene.imageUrl) {
              onWatchMedia?.();
            }
          }}
          className="w-full sm:w-44 aspect-video rounded-lg bg-studio-panel border border-studio-border flex items-center justify-center shrink-0 overflow-hidden relative group cursor-pointer"
          title={scene.videoUrl ? "Clique para assistir ao vídeo em tela cheia" : scene.imageUrl ? "Clique para ampliar a imagem" : undefined}
        >
          {scene.videoUrl ? (
            <div className="w-full h-full relative">
              <video
                src={scene.videoUrl}
                poster={scene.imageUrl}
                loop
                playsInline
                muted
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center group-hover:bg-black/20 transition-all">
                <div className="w-9 h-9 rounded-full bg-studio-gold text-black flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                  <Play className="w-4 h-4 ml-0.5 fill-black" />
                </div>
                <span className="text-[10px] text-white font-bold mt-1 bg-black/60 px-2 py-0.5 rounded-full">
                  Assistir Vídeo
                </span>
              </div>
            </div>
          ) : scene.imageUrl ? (
            <div className="w-full h-full relative">
              <img
                src={scene.imageUrl}
                alt={`Cena ${scene.sceneNumber}`}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                <div className="p-1.5 rounded-lg bg-black/60 text-white flex items-center gap-1 text-[10px] font-bold">
                  <Maximize2 className="w-3.5 h-3.5" />
                  <span>Ver Imagem</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-1 text-studio-text-muted">
              <Film className="w-6 h-6 text-studio-text-muted" />
              <span className="text-[11px] font-medium">Cena #{scene.sceneNumber}</span>
            </div>
          )}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 mb-1.5">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-studio-blue uppercase">CENA {scene.sceneNumber}</span>
              <span className="text-xs text-studio-text-muted">· {formatDuration(scene.duration)}</span>
              {scene.videoUrl && (
                <span className="flex items-center gap-1 text-[10px] text-studio-green font-semibold bg-studio-green/10 px-1.5 py-0.5 rounded">
                  <CheckCircle2 className="w-3 h-3" /> Vídeo Pronto
                </span>
              )}
            </div>
            <span className={cn("task-badge text-xs shrink-0", getStatusColor(scene.status))}>
              {getStatusLabel(scene.status)}
            </span>
          </div>

          <p className="text-xs sm:text-sm text-studio-text leading-relaxed mb-2 line-clamp-2">
            {scene.visualDescription}
          </p>

          {scene.narration && (
            <p className="text-xs text-studio-text-muted italic mb-2 line-clamp-1">
              "{scene.narration}"
            </p>
          )}

          {/* Media badges and actions */}
          <div className="flex items-center justify-between gap-2 pt-1 flex-wrap">
            <div className="flex gap-1.5 flex-wrap">
              <ResourceBadge icon={<Image className="w-3 h-3" />} label="Imagem" color="blue" />
              {scene.videoPrompt && <ResourceBadge icon={<Video className="w-3 h-3" />} label="Vídeo AI" color="purple" />}
              {scene.narration && <ResourceBadge icon={<Mic className="w-3 h-3" />} label="Voz" color="green" />}
              {scene.music && <ResourceBadge icon={<Music className="w-3 h-3" />} label="Música" color="gold" />}
            </div>

            <div className="flex items-center gap-1.5 flex-wrap">
              {onGenerateImage && (
                <button
                  onClick={onGenerateImage}
                  className="text-xs font-medium text-studio-text hover:text-studio-blue flex items-center gap-1 bg-studio-panel px-2 py-1 rounded-lg border border-studio-border hover:border-studio-blue/40 transition-all"
                >
                  <Image className="w-3 h-3 text-studio-blue" />
                  <span>Gerar Imagem</span>
                </button>
              )}

              {onGenerateAudio && (
                <button
                  onClick={onGenerateAudio}
                  className="text-xs font-medium text-studio-text hover:text-studio-green flex items-center gap-1 bg-studio-panel px-2 py-1 rounded-lg border border-studio-border hover:border-studio-green/40 transition-all"
                >
                  <Mic className="w-3 h-3 text-studio-green" />
                  <span>Voz / TTS</span>
                </button>
              )}

              {onGenerateVideo && (
                <button
                  onClick={onGenerateVideo}
                  className="text-xs font-semibold text-studio-blue hover:text-studio-blue/80 flex items-center gap-1 bg-studio-blue/10 px-2.5 py-1 rounded-lg border border-studio-blue/20 hover:bg-studio-blue/20 transition-all"
                >
                  <Video className="w-3 h-3" />
                  <span>{scene.videoUrl ? "Regenerar Vídeo" : "Gerar Vídeo"}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Prompt preview */}
      <div className="pt-2.5 border-t border-studio-border/70 flex items-start gap-2">
        <Sparkles className="w-3.5 h-3.5 text-studio-purple shrink-0 mt-0.5" />
        <p className="text-[11px] text-studio-text-muted leading-relaxed line-clamp-1">
          <strong className="text-studio-text-dim font-medium">Prompt de Vídeo:</strong> {scene.videoPrompt || scene.imagePrompt}
        </p>
      </div>
    </div>
  );
}

function ResourceBadge({ icon, label, color }: { icon: React.ReactNode; label: string; color: string }) {
  const colorMap: Record<string, string> = {
    blue: "bg-studio-blue/10 text-studio-blue border-studio-blue/20",
    purple: "bg-studio-purple/10 text-studio-purple border-studio-purple/20",
    green: "bg-studio-green/10 text-studio-green border-studio-green/20",
    gold: "bg-studio-gold/10 text-studio-gold border-studio-gold/20",
  };
  return (
    <span className={cn("task-badge text-xs border", colorMap[color])}>
      {icon}
      {label}
    </span>
  );
}
