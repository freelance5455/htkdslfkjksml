// ============================================================
// AI CREATOR STUDIO — CORE 2.0 PRE-PUBLISH APPROVAL SYSTEM
// ============================================================

import React, { useState, useEffect } from "react";
import type { Project, Platform, PublishingMetadata, SocialChannel, ContentSafetyReport } from "@/types";
import { CheckCircle2, AlertTriangle, ShieldCheck, Calendar, Send, X, Clock, Play, Sparkles, Youtube, Instagram, Facebook } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { getSocialChannels, createAndApprovePublishingJob } from "@/lib/publishingScheduler";
import { runContentSafetyCheck } from "@/lib/contentSafety";

interface Props {
  isOpen: boolean;
  onClose: () => void;
  project: Project;
  defaultPlatform?: Platform;
  customMetadata?: Partial<PublishingMetadata>;
  onSuccess?: () => void;
}

export const PrePublishApprovalModal: React.FC<Props> = ({
  isOpen,
  onClose,
  project,
  defaultPlatform = "YOUTUBE",
  customMetadata,
  onSuccess,
}) => {
  const { toast } = useToast();
  const [channels, setChannels] = useState<SocialChannel[]>([]);
  const [selectedPlatform, setSelectedPlatform] = useState<Platform>(defaultPlatform);
  const [selectedChannelId, setSelectedChannelId] = useState<string>("");
  const [publishMode, setPublishMode] = useState<"NOW" | "SCHEDULE">("NOW");
  const [scheduleDateTime, setScheduleDateTime] = useState<string>(() => {
    const d = new Date(Date.now() + 86400000);
    return d.toISOString().slice(0, 16);
  });

  const [title, setTitle] = useState<string>(customMetadata?.title || project.seoPackage?.primaryTitle || project.title);
  const [description, setDescription] = useState<string>(() => {
    if (customMetadata?.description) return customMetadata.description;
    if (project.seoPackage?.description?.fullFormatted) return project.seoPackage.description.fullFormatted;
    return `Conteúdo exclusivo: ${project.title}\n\n#criadores #conteudo #viral`;
  });

  const [isMadeForKids, setIsMadeForKids] = useState<boolean>(() => {
    return project.contentType === "CHILDREN_VIDEO" || project.title.toLowerCase().includes("infantil");
  });

  const [safetyReport, setSafetyReport] = useState<ContentSafetyReport | null>(null);
  const [checkingSafety, setCheckingSafety] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      const chs = getSocialChannels();
      setChannels(chs);
      const match = chs.find((c) => c.platform === selectedPlatform) || chs[0];
      if (match) setSelectedChannelId(match.id);

      // Run safety check
      setCheckingSafety(true);
      runContentSafetyCheck(project)
        .then((report) => setSafetyReport(report))
        .finally(() => setCheckingSafety(false));
    }
  }, [isOpen, project, selectedPlatform]);

  if (!isOpen) return null;

  const handlePlatformChange = (p: Platform) => {
    setSelectedPlatform(p);
    const match = channels.find((c) => c.platform === p);
    if (match) setSelectedChannelId(match.id);
  };

  const handleApproveAndPublish = async () => {
    setSubmitting(true);
    try {
      const metadata: PublishingMetadata = {
        title,
        description,
        tags: project.seoPackage?.tags || ["criador", "studio"],
        hashtags: project.seoPackage?.hashtags || ["#viral"],
        visibility: "PUBLIC",
        aspectRatio: (customMetadata?.aspectRatio as "16:9" | "9:16") || (project.platform === "TIKTOK" || project.contentType === "SHORT" || project.contentType === "REEL" ? "9:16" : "16:9"),
        thumbnailUrl: project.thumbnail || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80",
        videoUrl: project.assets.find((a) => a.type === "VIDEO")?.url || "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
        isMadeForKids,
      };

      const scheduledAt = publishMode === "SCHEDULE" ? new Date(scheduleDateTime).toISOString() : undefined;

      const job = await createAndApprovePublishingJob({
        project,
        platform: selectedPlatform,
        channelId: selectedChannelId,
        metadata,
        scheduledAt,
        isMadeForKids,
      });

      toast({
        title: publishMode === "NOW" ? "Publicação Realizada!" : "Publicação Agendada!",
        description: publishMode === "NOW"
          ? `Publicado com sucesso no canal selecionado (${selectedPlatform}).`
          : `Agendado com sucesso para ${new Date(scheduleDateTime).toLocaleString("pt-BR")}.`,
      });

      if (onSuccess) onSuccess();
      onClose();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Erro ao publicar";
      toast({ title: "Falha na Publicação", description: msg, variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4 overflow-y-auto" id="pre-publish-approval-modal">
      <div className="relative w-full max-w-4xl bg-studio-surface border border-studio-border rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-studio-border bg-blue-50/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-studio-blue/10 border border-studio-blue/20 flex items-center justify-center text-studio-blue">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-studio-blue/10 text-studio-blue border border-studio-blue/20">
                  APROVAÇÃO OBRIGATÓRIA DO CRIADOR
                </span>
                <h3 className="text-lg font-bold text-studio-text">
                  Revisão Pré-Publicação & Agendamento
                </h3>
              </div>
              <p className="text-xs text-studio-text-muted">
                Nenhum conteúdo é publicado automaticamente sem a sua autorização explícita.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-studio-text-muted hover:text-studio-text hover:bg-studio-panel transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 grid grid-cols-1 md:grid-cols-12 gap-6 max-h-[75vh] overflow-y-auto">
          {/* Left Column: Visual Preview & Target Platform (5 Cols) */}
          <div className="md:col-span-5 space-y-4">
            {/* Video / Thumbnail Card */}
            <div className="space-y-2">
              <span className="text-xs font-semibold text-studio-text">Preview do Conteúdo</span>
              <div className="relative aspect-video rounded-xl overflow-hidden bg-studio-panel border border-studio-border">
                <img
                  src={project.thumbnail || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80"}
                  alt="Preview"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/25 flex items-center justify-center">
                  <div className="w-10 h-10 rounded-full bg-studio-blue text-white flex items-center justify-center shadow-lg">
                    <Play className="w-5 h-5 ml-0.5" />
                  </div>
                </div>
              </div>
            </div>

            {/* Platform Selector */}
            <div className="space-y-2">
              <span className="text-xs font-semibold text-studio-text">Plataforma de Destino</span>
              <div className="grid grid-cols-2 gap-2">
                {(["YOUTUBE", "TIKTOK", "INSTAGRAM", "FACEBOOK"] as Platform[]).map((p) => {
                  const isSelected = selectedPlatform === p;
                  return (
                    <button
                      key={p}
                      onClick={() => handlePlatformChange(p)}
                      className={`p-2.5 rounded-lg border text-xs font-semibold flex items-center gap-2 transition-all ${
                        isSelected
                          ? "bg-blue-50 border-studio-blue text-studio-blue shadow-xs font-bold"
                          : "bg-white border-studio-border text-studio-text-muted hover:text-studio-text hover:bg-studio-panel"
                      }`}
                    >
                      {p === "YOUTUBE" && <Youtube className="w-4 h-4 text-red-500" />}
                      {p === "TIKTOK" && <Sparkles className="w-4 h-4 text-cyan-500" />}
                      {p === "INSTAGRAM" && <Instagram className="w-4 h-4 text-pink-500" />}
                      {p === "FACEBOOK" && <Facebook className="w-4 h-4 text-blue-600" />}
                      <span>{p}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Channel Selector */}
            <div className="space-y-1.5">
              <span className="text-xs font-semibold text-studio-text">Canal Conectado</span>
              <select
                value={selectedChannelId}
                onChange={(e) => setSelectedChannelId(e.target.value)}
                className="w-full p-2.5 rounded-lg bg-white border border-studio-border text-xs text-studio-text focus:outline-none focus:border-studio-blue shadow-xs"
              >
                {channels
                  .filter((c) => c.platform === selectedPlatform)
                  .map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.handle || c.channelId})
                    </option>
                  ))}
              </select>
            </div>

            {/* Safety & Compliance Badge */}
            <div className="p-3.5 rounded-xl bg-studio-panel border border-studio-border space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-studio-text flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  Auditoria de Segurança
                </span>
                <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-emerald-100 text-emerald-700 border border-emerald-200">
                  {checkingSafety ? "Auditando..." : safetyReport?.status || "READY"}
                </span>
              </div>
              <p className="text-[11px] text-studio-text-muted leading-relaxed">
                {safetyReport?.overallAssessment || "Verificação de direitos autorais e diretrizes concluída sem restrições."}
              </p>
            </div>
          </div>

          {/* Right Column: Metadata, COPPA, Timing (7 Cols) */}
          <div className="md:col-span-7 space-y-4">
            {/* Title */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-studio-text">Título Final da Publicação</label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="bg-white border-studio-border text-xs text-studio-text"
                placeholder="Título magnético..."
              />
            </div>

            {/* Description */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-studio-text">Descrição & Metadados</label>
              <Textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={5}
                className="bg-white border-studio-border text-xs text-studio-text font-mono resize-none"
                placeholder="Descrição completa..."
              />
            </div>

            {/* COPPA & Child Content Declaration */}
            <div className="p-3.5 rounded-xl bg-studio-panel border border-studio-border space-y-2">
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isMadeForKids}
                  onChange={(e) => setIsMadeForKids(e.target.checked)}
                  className="mt-0.5 w-4 h-4 rounded text-studio-blue border-studio-border focus:ring-0"
                />
                <div className="space-y-0.5">
                  <span className="text-xs font-bold text-studio-text">
                    Conteúdo Destinado a Crianças (COPPA / Made for Kids)
                  </span>
                  <p className="text-[11px] text-studio-text-muted leading-relaxed">
                    Obrigatório para canções infantis, desenhos e vídeos para bebês/crianças. (O YouTube desativa comentários e anúncios personalizados para proteção de menores).
                  </p>
                </div>
              </label>
            </div>

            {/* Timing: Publish Now vs Schedule */}
            <div className="p-3.5 rounded-xl bg-studio-panel border border-studio-border space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-studio-text flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-studio-blue" />
                  Momento do Lançamento
                </span>
                <div className="flex rounded-lg bg-white border border-studio-border p-0.5 shadow-xs">
                  <button
                    onClick={() => setPublishMode("NOW")}
                    className={`px-3 py-1 text-xs rounded-md transition-all ${
                      publishMode === "NOW" ? "bg-studio-blue text-white font-semibold shadow-xs" : "text-studio-text-muted hover:text-studio-text"
                    }`}
                  >
                    Publicar Agora
                  </button>
                  <button
                    onClick={() => setPublishMode("SCHEDULE")}
                    className={`px-3 py-1 text-xs rounded-md transition-all ${
                      publishMode === "SCHEDULE" ? "bg-studio-blue text-white font-semibold shadow-xs" : "text-studio-text-muted hover:text-studio-text"
                    }`}
                  >
                    Agendar Horário
                  </button>
                </div>
              </div>

              {publishMode === "SCHEDULE" && (
                <div className="space-y-1.5 pt-1">
                  <label className="text-[11px] text-studio-text-muted">Data e Horário Planejados (Seu Fuso Horário)</label>
                  <Input
                    type="datetime-local"
                    value={scheduleDateTime}
                    onChange={(e) => setScheduleDateTime(e.target.value)}
                    className="bg-white border-studio-border text-xs text-studio-text shadow-xs"
                  />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-5 border-t border-studio-border bg-slate-50 flex flex-col sm:flex-row items-center justify-between gap-3">
          <span className="text-xs text-studio-text-muted">
            Status da Autorização: <strong className="text-emerald-600">Pronto para Envio</strong>
          </span>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <Button
              variant="outline"
              onClick={onClose}
              className="border-studio-border text-studio-text hover:bg-studio-panel text-xs flex-1 sm:flex-initial"
            >
              Cancelar
            </Button>
            <Button
              id="btn-confirm-approve-publish"
              onClick={handleApproveAndPublish}
              disabled={submitting}
              className="text-xs font-bold text-white gap-2 flex-1 sm:flex-initial shadow-sm shadow-blue-500/25 bg-studio-blue hover:bg-studio-blue-dim"
            >
              {publishMode === "NOW" ? (
                <>
                  <Send className="w-4 h-4" />
                  {submitting ? "Publicando..." : "APROVAR & PUBLICAR AGORA"}
                </>
              ) : (
                <>
                  <Calendar className="w-4 h-4" />
                  {submitting ? "Agendando..." : "APROVAR & AGENDAR"}
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
