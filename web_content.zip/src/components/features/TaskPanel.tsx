import { cn, getStatusColor, getStatusLabel } from "@/lib/utils";
import type { AITask } from "@/types";
import { Loader2, CheckCircle2, XCircle, Clock, Circle } from "lucide-react";

interface TaskPanelProps {
  tasks: AITask[];
}

function TaskIcon({ status }: { status: string }) {
  if (status === "COMPLETED") return <CheckCircle2 className="w-4 h-4 text-studio-green" />;
  if (status === "FAILED") return <XCircle className="w-4 h-4 text-studio-red" />;
  if (status === "PROCESSING") return <Loader2 className="w-4 h-4 text-yellow-400 animate-spin" />;
  if (status === "QUEUED") return <Clock className="w-4 h-4 text-studio-blue" />;
  return <Circle className="w-4 h-4 text-studio-text-muted" />;
}

export default function TaskPanel({ tasks }: TaskPanelProps) {
  const completed = tasks.filter((t) => t.status === "COMPLETED").length;

  return (
    <div className="studio-panel p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-studio-text font-display">Tarefas AI</h3>
        <span className="text-xs text-studio-text-muted">{completed}/{tasks.length}</span>
      </div>
      <div className="w-full h-1 bg-studio-border rounded-full mb-4">
        <div
          className="h-1 bg-gradient-to-r from-studio-blue to-studio-purple rounded-full transition-all"
          style={{ width: `${tasks.length > 0 ? (completed / tasks.length) * 100 : 0}%` }}
        />
      </div>
      <div className="space-y-2 max-h-72 overflow-y-auto">
        {tasks.map((task) => (
          <div
            key={task.id}
            className={cn("flex items-center gap-3 p-2.5 rounded-lg border", getStatusBorder(task.status))}
          >
            <TaskIcon status={task.status} />
            <div className="flex-1 min-w-0">
              <p className={cn("text-xs font-medium truncate", getTaskTextColor(task.status))}>
                {task.title}
              </p>
              {task.progress !== undefined && task.progress > 0 && task.progress < 100 && (
                <div className="w-full h-0.5 bg-studio-border rounded mt-1">
                  <div className="h-0.5 bg-yellow-400 rounded" style={{ width: `${task.progress}%` }} />
                </div>
              )}
            </div>
            <span className={cn("task-badge text-xs shrink-0", getStatusColor(task.status))}>
              {getStatusLabel(task.status)}
            </span>
          </div>
        ))}
        {tasks.length === 0 && (
          <p className="text-xs text-studio-text-muted text-center py-4">Nenhuma tarefa ainda</p>
        )}
      </div>
    </div>
  );
}

function getStatusBorder(status: string): string {
  const map: Record<string, string> = {
    COMPLETED: "border-studio-green/20",
    FAILED: "border-studio-red/20",
    PROCESSING: "border-yellow-400/20",
    QUEUED: "border-studio-blue/20",
    PENDING: "border-transparent",
  };
  return map[status] ?? "border-transparent";
}

function getTaskTextColor(status: string): string {
  const map: Record<string, string> = {
    COMPLETED: "text-studio-green",
    FAILED: "text-studio-red",
    PROCESSING: "text-yellow-400",
    QUEUED: "text-studio-blue",
    PENDING: "text-studio-text-muted",
  };
  return map[status] ?? "text-studio-text-dim";
}
