import type { AnalyzedRequest } from "@/types";
import { cn, getStatusColor } from "@/lib/utils";
import { CONTENT_TYPE_LABELS } from "@/constants";
import { ShieldCheck, ShieldAlert, ShieldOff } from "lucide-react";

interface AnalyzerResultProps {
  result: AnalyzedRequest;
}

export default function AnalyzerResult({ result }: AnalyzerResultProps) {
  const fields = [
    { label: "Intenção", value: result.intent },
    { label: "Tipo de Conteúdo", value: CONTENT_TYPE_LABELS[result.contentType] ?? result.contentType },
    { label: "Tópico", value: result.topic },
    { label: "Público", value: result.audience.label },
    { label: "Plataforma", value: result.platform },
    { label: "Idioma", value: result.language },
    { label: "Tom", value: result.tone },
    { label: "Estilo", value: result.style ?? "—" },
    { label: "Formato", value: result.format ?? "—" },
    result.duration ? { label: "Duração", value: `${Math.floor(result.duration / 60)}min${result.duration % 60 > 0 ? ` ${result.duration % 60}s` : ""}` } : null,
  ].filter(Boolean) as Array<{ label: string; value: string }>;

  const SafetyIcon = result.safetyStatus === "SAFE"
    ? ShieldCheck
    : result.safetyStatus === "NEEDS_REVIEW"
    ? ShieldAlert
    : ShieldOff;

  return (
    <div className="studio-card p-4 animate-fade-in">
      <div className="flex items-center justify-between mb-4">
        <h4 className="text-sm font-bold text-studio-text font-display">Análise do Pedido</h4>
        <div className={cn("task-badge text-xs gap-1", getStatusColor(result.safetyStatus))}>
          <SafetyIcon className="w-3 h-3" />
          {result.safetyStatus === "SAFE" ? "Seguro" : result.safetyStatus === "NEEDS_REVIEW" ? "Revisar" : "Bloqueado"}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2">
        {fields.map((f) => (
          <div key={f.label} className="bg-studio-panel rounded-lg p-2.5">
            <p className="text-xs text-studio-text-muted mb-0.5">{f.label}</p>
            <p className="text-xs font-semibold text-studio-text truncate">{f.value}</p>
          </div>
        ))}
      </div>

      {result.requirements.length > 0 && (
        <div className="mt-3 pt-3 border-t border-studio-border">
          <p className="text-xs text-studio-text-muted mb-2">Requisitos detectados</p>
          <div className="flex flex-wrap gap-1.5">
            {result.requirements.map((req) => (
              <span key={req} className="task-badge text-xs bg-studio-purple/10 text-studio-purple border border-studio-purple/20">
                {req}
              </span>
            ))}
          </div>
        </div>
      )}

      {result.safetyNotes && (
        <div className="mt-3 p-3 bg-yellow-400/5 border border-yellow-400/20 rounded-lg">
          <p className="text-xs text-yellow-400">{result.safetyNotes}</p>
        </div>
      )}
    </div>
  );
}
