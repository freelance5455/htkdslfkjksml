import React, { useState, useEffect, useRef } from "react";
import { useProjects } from "@/hooks/useProjects";
import { useToast } from "@/hooks/use-toast";
import type { Project, Platform, PublishingJob, PublishingMetadata, SocialChannel } from "@/types";
import {
  Film,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize2,
  Share2,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Download,
  Calendar,
  Sparkles,
  Smartphone,
  Monitor,
  ShieldCheck,
  Tag,
  FileText,
  Eye,
  ThumbsUp,
  MessageSquare,
  Bookmark,
  Disc3,
  Copy,
  Check,
  ExternalLink,
  ChevronRight,
  RefreshCw,
  Search,
  Filter,
  Send,
  Radio,
  Layers,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { PrePublishApprovalModal } from "@/components/features/PrePublishApprovalModal";
import {
  getSocialChannels,
  getPublishingJobs,
  createAndApprovePublishingJob,
} from "@/lib/publishingScheduler";
import { getSavedShorts } from "@/lib/youtubeFactory/shortsFactory";
import { getMasterScripts } from "@/lib/youtubeFactory/scriptEngine";
import { getYouTubeChannels } from "@/lib/youtubeFactory/channelStore";

export interface UnifiedVideoItem {
  id: string;
  title: string;
  description: string;
  videoUrl: string;
  thumbnailUrl: string;
  durationSeconds: number;
  aspectRatio: "16:9" | "9:16";
  formatType: "LONG_FORM" | "SHORT" | "REEL";
  platform: Platform;
  status: "READY" | "SCHEDULED" | "PUBLISHED" | "NEEDS_REVIEW";
  publishedAt?: string;
  scheduledAt?: string;
  channelName: string;
  channelHandle: string;
  channelAvatar: string;
  tags: string[];
  hashtags: string[];
  complianceScore: number;
  copyrightStatus: "CLEAN" | "VERIFYING" | "ALERT";
  isMadeForKids: boolean;
  scriptSnippet?: string;
  estimatedViews?: string;
  sourceProjectId?: string;
}

// Built-in Seed Videos for Instant Preview & Testing
const DEFAULT_PREVIEW_VIDEOS: UnifiedVideoItem[] = [
  {
    id: "vid_preview_1",
    title: "O Futuro da Inteligência Artificial em 2026: Agentes Autônomos e Riqueza",
    description: "Neste vídeo aprofundado, analisamos a revolução dos agentes autônomos e como modelos multimodais estão transformando a economia digital.\n\n📌 Tópicos abordados:\n00:00 - Introdução aos Novos Modelos\n03:15 - Agentes de IA na Produção de Mídia\n07:40 - Oportunidades Financeiras em 2026\n11:20 - Conclusão e Próximos Passos\n\n#ia #inteligenciaartificial #futuro #tecnologia #dinheiro",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    thumbnailUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80",
    durationSeconds: 742,
    aspectRatio: "16:9",
    formatType: "LONG_FORM",
    platform: "YOUTUBE",
    status: "READY",
    channelName: "Sadraque Ngola Studio",
    channelHandle: "@sadraquengola",
    channelAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80",
    tags: ["inteligencia artificial", "agentes ia", "futuro tecnologia", "dinheiro online", "automacao"],
    hashtags: ["#ia", "#futuro", "#tecnologia"],
    complianceScore: 99,
    copyrightStatus: "CLEAN",
    isMadeForKids: false,
    scriptSnippet: "Hook: A maioria das pessoas ainda não percebeu, mas a forma como geramos valor mudou para sempre nos últimos 12 meses...",
    estimatedViews: "45k - 90k",
  },
  {
    id: "vid_preview_2",
    title: "Top 3 Ferramentas de IA Secretas Para Criar Vídeos Sem Aparecer ⚡",
    description: "Descubra 3 IAs secretas que você pode usar hoje mesmo para montar um canal dark lucrativo no YouTube Shorts e TikTok! #shorts #tecnologia #ia #produtividade",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    thumbnailUrl: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=600&auto=format&fit=crop&q=80",
    durationSeconds: 58,
    aspectRatio: "9:16",
    formatType: "SHORT",
    platform: "YOUTUBE",
    status: "READY",
    channelName: "Sadraque Creator",
    channelHandle: "@sadraque.ai",
    channelAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80",
    tags: ["shorts", "ia", "ferramentas ia", "canaldark", "rendaextra"],
    hashtags: ["#shorts", "#ia", "#criadores"],
    complianceScore: 97,
    copyrightStatus: "CLEAN",
    isMadeForKids: false,
    scriptSnippet: "Pare de perder horas editando vídeos! Estas três ferramentas fazem tudo em menos de 60 segundos com apenas um clique.",
    estimatedViews: "120k - 250k",
  },
  {
    id: "vid_preview_3",
    title: "Como os Algoritmos Financeiros Movimentam Trilhões Diariamente",
    description: "Mini-documentário investigativo explicando a matemática e os modelos neurais que tomam 85% das decisões na bolsa de Nova York e nos mercados globais.\n\n#financas #algoritmos #dinheiro #wallstreet #investimentos",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    thumbnailUrl: "https://images.unsplash.com/photo-1642543492481-44e81e3914a7?w=800&auto=format&fit=crop&q=80",
    durationSeconds: 615,
    aspectRatio: "16:9",
    formatType: "LONG_FORM",
    platform: "YOUTUBE",
    status: "SCHEDULED",
    scheduledAt: "Amanhã às 18:30 (Horário Nobre)",
    channelName: "Sadraque Ngola Studio",
    channelHandle: "@sadraquengola",
    channelAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80",
    tags: ["financas", "mercado financeiro", "algoritmos", "ia investimentos", "wall street"],
    hashtags: ["#financas", "#dinheiro", "#mercado"],
    complianceScore: 98,
    copyrightStatus: "CLEAN",
    isMadeForKids: false,
    scriptSnippet: "Você sabia que 8 em cada 10 transações no mercado financeiro global não são feitas por humanos, mas sim por algoritmos em microssegundos?",
    estimatedViews: "30k - 65k",
  },
];

type FilterType = "ALL" | "LONG" | "SHORT" | "READY" | "PUBLISHED";
type DetailTabKey = "METADATA" | "SIMULATOR" | "COMPLIANCE" | "SCRIPT";

export default function MyVideosPrePublishView() {
  const { toast } = useToast();
  const { projects } = useProjects();

  const [videos, setVideos] = useState<UnifiedVideoItem[]>(DEFAULT_PREVIEW_VIDEOS);
  const [selectedVideo, setSelectedVideo] = useState<UnifiedVideoItem>(DEFAULT_PREVIEW_VIDEOS[0]);
  const [filterType, setFilterType] = useState<FilterType>("ALL");
  const [searchQuery, setSearchQuery] = useState("");
  const [playerMode, setPlayerMode] = useState<"CINEMA" | "SMARTPHONE">("CINEMA");
  const [activeTab, setActiveTab] = useState<DetailTabKey>("METADATA");

  // Video HTML5 state
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  // Publishing & Scheduling
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [scheduleDateTime, setScheduleDateTime] = useState(() => {
    const d = new Date(Date.now() + 86400000);
    d.setHours(18, 30, 0, 0);
    return d.toISOString().slice(0, 16);
  });
  const [isPublishing, setIsPublishing] = useState(false);
  const [approvalModalProject, setApprovalModalProject] = useState<Project | null>(null);

  // Auto detect player mode when video aspect changes
  useEffect(() => {
    if (!selectedVideo) return;
    if (selectedVideo.aspectRatio === "9:16") {
      setPlayerMode("SMARTPHONE");
    } else {
      setPlayerMode("CINEMA");
    }
    setIsPlaying(false);
  }, [selectedVideo]);

  // Aggregate videos from projects, shorts, and storage
  useEffect(() => {
    const aggregated: UnifiedVideoItem[] = [...DEFAULT_PREVIEW_VIDEOS];

    // 1. Check projects with video assets or completed status
    if (Array.isArray(projects)) {
      projects.forEach((proj) => {
        if (!proj) return;
        const vidAsset = proj.assets?.find((a) => a && (a.type === "VIDEO" || a.type === "RENDER"));
        if (vidAsset && vidAsset.url) {
          const isShort =
            proj.contentType === "SHORT" ||
            proj.contentType === "REEL" ||
            proj.contentType === "TIKTOK_VIDEO" ||
            proj.platform === "TIKTOK";

          let scriptSnippet = "Roteiro estruturado disponível.";
          if (proj.script?.sections && proj.script.sections.length > 0) {
            scriptSnippet = proj.script.sections[0]?.content || proj.script.sections[0]?.narration || scriptSnippet;
          } else if ((proj.script as unknown as { scenes?: Array<{ narration?: string; visual?: string }> })?.scenes?.length) {
            const firstScene = (proj.script as unknown as { scenes: Array<{ narration?: string; visual?: string }> }).scenes[0];
            scriptSnippet = firstScene?.narration || firstScene?.visual || scriptSnippet;
          }

          const item: UnifiedVideoItem = {
            id: `proj_vid_${proj.id}`,
            title: proj.seoPackage?.primaryTitle || proj.title || "Vídeo sem título",
            description:
              proj.seoPackage?.description?.fullFormatted ||
              proj.description ||
              `Vídeo gerado via AI Creator Studio para ${proj.title || "Projeto"}`,
            videoUrl: vidAsset.url,
            thumbnailUrl:
              proj.thumbnail ||
              vidAsset.thumbnailUrl ||
              "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80",
            durationSeconds: vidAsset.duration || proj.timeline?.totalDuration || 60,
            aspectRatio: isShort ? "9:16" : "16:9",
            formatType: isShort ? "SHORT" : "LONG_FORM",
            platform: proj.platform || "YOUTUBE",
            status: proj.status === "COMPLETED" ? "READY" : "NEEDS_REVIEW",
            channelName: "Sadraque Ngola Studio",
            channelHandle: "@sadraquengola",
            channelAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80",
            tags: proj.seoPackage?.tags || ["ai", "creator", "studio"],
            hashtags: proj.seoPackage?.hashtags || ["#shorts", "#youtube"],
            complianceScore: 96,
            copyrightStatus: "CLEAN",
            isMadeForKids: proj.contentType === "CHILDREN_VIDEO",
            scriptSnippet,
            sourceProjectId: proj.id,
          };

          // Avoid duplicate ids
          if (!aggregated.some((v) => v.id === item.id)) {
            aggregated.unshift(item);
          }
        }
      });
    }

    // 2. Add saved shorts
    const savedShorts = getSavedShorts();
    if (Array.isArray(savedShorts)) {
      savedShorts.forEach((sh, idx) => {
        if (!sh) return;
        const shortItem: UnifiedVideoItem = {
          id: `short_${sh.id || idx}`,
          title: sh.title || `Short #${idx + 1}`,
          description: `${sh.title || "Vídeo Curto"}\n\nAssista até o final! #shorts #viral #conteudo`,
          videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
          thumbnailUrl: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=600&auto=format&fit=crop&q=80",
          durationSeconds: sh.durationSeconds || 55,
          aspectRatio: "9:16",
          formatType: "SHORT",
          platform: "YOUTUBE",
          status: "READY",
          channelName: "Sadraque Creator",
          channelHandle: "@sadraque.ai",
          channelAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80",
          tags: ["shorts", "viral", "youtube shorts"],
          hashtags: ["#shorts", "#viral"],
          complianceScore: sh.viralHookScore || 98,
          copyrightStatus: "CLEAN",
          isMadeForKids: false,
          scriptSnippet: sh.hookText || "Hook do Short para alta retenção...",
        };
        if (!aggregated.some((v) => v.id === shortItem.id)) {
          aggregated.push(shortItem);
        }
      });
    }

    setVideos(aggregated);
  }, [projects]);

  // Video playback controls
  const handleTogglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
      setDuration(videoRef.current.duration || selectedVideo.durationSeconds);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    if (videoRef.current) {
      videoRef.current.currentTime = val;
      setCurrentTime(val);
    }
  };

  const handleToggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const formatSeconds = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${s < 10 ? "0" : ""}${s}`;
  };

  // Copy helper
  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(label);
    toast({ title: "Copiado para Área de Transferência", description: label });
    setTimeout(() => setCopiedField(null), 2000);
  };

  // Direct Publish Handler
  const handlePublishNow = async () => {
    setIsPublishing(true);
    try {
      // Find matching project or build synthetic project
      const matchedProj = projects.find((p) => p.id === selectedVideo.sourceProjectId) || {
        id: selectedVideo.id,
        title: selectedVideo.title,
        status: "COMPLETED" as const,
        contentType: selectedVideo.formatType === "SHORT" ? "SHORT" : ("VIDEO" as const),
        platform: selectedVideo.platform,
        outputFormats: ["YOUTUBE_1080p" as const],
        thumbnail: selectedVideo.thumbnailUrl,
        assets: [{ id: "asset_v", type: "VIDEO" as const, name: selectedVideo.title, url: selectedVideo.videoUrl, status: "COMPLETED" as const, createdAt: new Date().toISOString() }],
        characters: [],
        tasks: [],
        versions: [],
        conversation: [],
      };

      const channels = getSocialChannels();
      const targetChannel = channels?.find((c) => c.platform === selectedVideo.platform) || channels?.[0];

      const metadata: PublishingMetadata = {
        title: selectedVideo.title,
        description: selectedVideo.description,
        tags: selectedVideo.tags,
        hashtags: selectedVideo.hashtags,
        visibility: "PUBLIC",
        aspectRatio: selectedVideo.aspectRatio,
        thumbnailUrl: selectedVideo.thumbnailUrl,
        videoUrl: selectedVideo.videoUrl,
        isMadeForKids: selectedVideo.isMadeForKids,
      };

      await createAndApprovePublishingJob({
        project: matchedProj,
        platform: selectedVideo.platform,
        channelId: targetChannel?.id || "chan_yt_1",
        metadata,
        publishMode: "NOW",
      });

      // Update state
      setVideos((prev) =>
        prev.map((v) =>
          v.id === selectedVideo.id
            ? { ...v, status: "PUBLISHED", publishedAt: "Publicado agora com sucesso" }
            : v
        )
      );
      setSelectedVideo((prev) => ({
        ...prev,
        status: "PUBLISHED",
        publishedAt: "Publicado agora com sucesso",
      }));

      toast({
        title: "🎉 Vídeo Publicado com Sucesso!",
        description: `O vídeo "${selectedVideo.title}" foi enviado para o canal ${targetChannel?.name || "YouTube"}.`,
      });
    } catch (err) {
      console.error(err);
      toast({
        title: "Erro na Publicação",
        description: "Não foi possível conectar à API de publicação.",
        variant: "destructive",
      });
    } finally {
      setIsPublishing(false);
    }
  };

  // Schedule Handler
  const handleConfirmSchedule = async () => {
    setShowScheduleModal(false);
    try {
      const matchedProj = projects.find((p) => p.id === selectedVideo.sourceProjectId) || {
        id: selectedVideo.id,
        title: selectedVideo.title,
        status: "COMPLETED" as const,
        contentType: selectedVideo.formatType === "SHORT" ? "SHORT" : ("VIDEO" as const),
        platform: selectedVideo.platform,
        outputFormats: ["YOUTUBE_1080p" as const],
        thumbnail: selectedVideo.thumbnailUrl,
        assets: [{ id: "asset_v", type: "VIDEO" as const, name: selectedVideo.title, url: selectedVideo.videoUrl, status: "COMPLETED" as const, createdAt: new Date().toISOString() }],
        characters: [],
        tasks: [],
        versions: [],
        conversation: [],
      };

      const channels = getSocialChannels();
      const targetChannel = channels?.find((c) => c.platform === selectedVideo.platform) || channels?.[0];

      await createAndApprovePublishingJob({
        project: matchedProj,
        platform: selectedVideo.platform,
        channelId: targetChannel?.id || "chan_yt_1",
        metadata: {
          title: selectedVideo.title,
          description: selectedVideo.description,
          tags: selectedVideo.tags,
          hashtags: selectedVideo.hashtags,
          visibility: "PUBLIC",
          aspectRatio: selectedVideo.aspectRatio,
          thumbnailUrl: selectedVideo.thumbnailUrl,
          videoUrl: selectedVideo.videoUrl,
          isMadeForKids: selectedVideo.isMadeForKids,
        },
        publishMode: "SCHEDULE",
        scheduledAt: new Date(scheduleDateTime).toISOString(),
      });

      const formatted = new Date(scheduleDateTime).toLocaleString("pt-BR", {
        day: "2-digit",
        month: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      });

      setVideos((prev) =>
        prev.map((v) =>
          v.id === selectedVideo.id
            ? { ...v, status: "SCHEDULED", scheduledAt: `Agendado para ${formatted}` }
            : v
        )
      );
      setSelectedVideo((prev) => ({
        ...prev,
        status: "SCHEDULED",
        scheduledAt: `Agendado para ${formatted}`,
      }));

      toast({
        title: "📅 Publicação Agendada!",
        description: `Vídeo agendado para ir ao ar em ${formatted}.`,
      });
    } catch (err) {
      console.error(err);
      toast({
        title: "Erro ao agendar",
        description: "Não foi possível agendar na fila de publicação.",
        variant: "destructive",
      });
    }
  };

  // Filter list
  const filteredVideos = videos.filter((v) => {
    if (filterType === "LONG" && v.aspectRatio !== "16:9") return false;
    if (filterType === "SHORT" && v.aspectRatio !== "9:16") return false;
    if (filterType === "READY" && v.status !== "READY") return false;
    if (filterType === "PUBLISHED" && v.status !== "PUBLISHED") return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        v.title.toLowerCase().includes(q) ||
        v.tags.some((t) => t.toLowerCase().includes(q)) ||
        v.description.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="studio-card p-6 border border-studio-border bg-gradient-to-r from-studio-surface via-studio-panel to-studio-surface">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-studio-panel border border-studio-border flex items-center justify-center text-studio-gold shadow-sm">
              <Film className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[10px] uppercase font-mono tracking-widest text-studio-gold font-bold">
                  Estúdio de Pré-Publicação
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  Range HTTP 206 Ativo
                </span>
              </div>
              <h2 className="text-xl font-bold text-studio-text font-display mt-0.5">
                Meus Vídeos · Visualização Antes de Publicar
              </h2>
              <p className="text-xs text-studio-text-muted mt-0.5">
                Inspeção de quadro a quadro, simulação de feed no YouTube, checklist de conformidade e publicação direta.
              </p>
            </div>
          </div>

          {/* Quick Publish CTA for Current Selection */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowScheduleModal(true)}
              className="btn text-xs py-2 px-3 border border-studio-border hover:border-studio-gold/40 flex items-center gap-1.5 text-studio-text"
              title="Agendar horário de publicação"
            >
              <Calendar className="w-3.5 h-3.5 text-studio-gold" />
              <span>Agendar</span>
            </button>

            <button
              onClick={handlePublishNow}
              disabled={isPublishing || selectedVideo.status === "PUBLISHED"}
              className={cn(
                "text-xs py-2 px-4 rounded-xl font-bold flex items-center gap-2 transition-all shadow-md",
                selectedVideo.status === "PUBLISHED"
                  ? "bg-emerald-600 text-white cursor-default"
                  : "bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white"
              )}
            >
              {isPublishing ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  Publicando...
                </>
              ) : selectedVideo.status === "PUBLISHED" ? (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Já Publicado
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  Publicar no YouTube
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Layout: Left Video List + Center/Right Master Player & Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* LEFT COLUMN: Video Selector List (4 cols) */}
        <div className="lg:col-span-4 space-y-3">
          <div className="studio-card p-4 border border-studio-border bg-studio-surface space-y-3">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-studio-text-muted" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Buscar vídeos por título ou tag..."
                className="w-full pl-8 pr-3 py-2 rounded-lg bg-studio-panel border border-studio-border text-xs text-studio-text focus:outline-none focus:border-studio-gold placeholder:text-studio-text-muted/60"
              />
            </div>

            {/* Filter Tabs */}
            <div className="flex items-center gap-1 overflow-x-auto pb-1">
              {(
                [
                  { id: "ALL", label: "Todos" },
                  { id: "LONG", label: "16:9 Longos" },
                  { id: "SHORT", label: "9:16 Shorts" },
                  { id: "READY", label: "Prontos" },
                  { id: "PUBLISHED", label: "Publicados" },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setFilterType(tab.id)}
                  className={cn(
                    "px-2.5 py-1 rounded-md text-[11px] font-medium whitespace-nowrap transition-all",
                    filterType === tab.id
                      ? "bg-studio-gold text-black font-bold"
                      : "bg-studio-panel text-studio-text-muted hover:text-studio-text"
                  )}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Video Cards List */}
          <div className="space-y-2.5 max-h-[720px] overflow-y-auto pr-1">
            {filteredVideos.map((vid) => {
              const isSelected = selectedVideo.id === vid.id;
              const isShort = vid.aspectRatio === "9:16";

              return (
                <div
                  key={vid.id}
                  onClick={() => setSelectedVideo(vid)}
                  className={cn(
                    "p-3 rounded-xl border transition-all cursor-pointer flex gap-3 group relative overflow-hidden",
                    isSelected
                      ? "bg-studio-panel border-studio-gold shadow-md"
                      : "bg-studio-surface border-studio-border hover:border-studio-border/80 hover:bg-studio-panel/60"
                  )}
                >
                  {/* Thumbnail */}
                  <div
                    className={cn(
                      "rounded-lg overflow-hidden bg-black shrink-0 relative flex items-center justify-center",
                      isShort ? "w-14 aspect-[9/16]" : "w-24 aspect-video"
                    )}
                  >
                    <img
                      src={vid.thumbnailUrl}
                      alt={vid.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <span className="absolute bottom-1 right-1 px-1 py-0.2 bg-black/80 rounded text-[9px] font-mono font-bold text-white">
                      {formatSeconds(vid.durationSeconds)}
                    </span>
                    {isSelected && (
                      <div className="absolute inset-0 bg-studio-gold/20 flex items-center justify-center">
                        <Play className="w-4 h-4 text-studio-gold fill-studio-gold" />
                      </div>
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0 flex flex-col justify-between">
                    <div>
                      <h4
                        className={cn(
                          "text-xs font-bold line-clamp-2 leading-snug",
                          isSelected ? "text-studio-gold" : "text-studio-text"
                        )}
                      >
                        {vid.title}
                      </h4>
                      <div className="flex items-center gap-1.5 mt-1">
                        <span className="text-[10px] text-studio-text-muted font-medium">
                          {isShort ? "Shorts (9:16)" : "YouTube (16:9)"}
                        </span>
                        <span className="text-studio-text-muted/40">·</span>
                        <span className="text-[10px] text-studio-blue font-mono font-semibold">
                          Score {vid.complianceScore}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between mt-2 pt-1 border-t border-studio-border/60">
                      <span
                        className={cn(
                          "text-[9px] font-bold px-1.5 py-0.2 rounded-full",
                          vid.status === "PUBLISHED"
                            ? "bg-emerald-500/15 text-emerald-400"
                            : vid.status === "SCHEDULED"
                            ? "bg-blue-500/15 text-blue-400"
                            : "bg-amber-500/15 text-amber-400"
                        )}
                      >
                        {vid.status === "PUBLISHED"
                          ? "PUBLICADO"
                          : vid.status === "SCHEDULED"
                          ? "AGENDADO"
                          : "PRONTO P/ REVISÃO"}
                      </span>

                      <ChevronRight
                        className={cn(
                          "w-3.5 h-3.5 transition-transform",
                          isSelected ? "text-studio-gold translate-x-0.5" : "text-studio-text-muted"
                        )}
                      />
                    </div>
                  </div>
                </div>
              );
            })}

            {filteredVideos.length === 0 && (
              <div className="p-8 text-center text-studio-text-muted text-xs bg-studio-surface rounded-xl border border-studio-border">
                Nenhum vídeo encontrado com os filtros atuais.
              </div>
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: Master Video Player & Pre-Publish Inspection (8 cols) */}
        <div className="lg:col-span-8 space-y-5">
          {/* PLAYER CONTAINER */}
          <div className="studio-card p-5 border border-studio-border bg-studio-surface relative">
            {/* Top Bar inside Player Card: Mode Selector + Resolution badge */}
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-studio-border">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-studio-text">Modo de Visualização:</span>
                <div className="flex items-center gap-1 p-1 bg-studio-panel rounded-lg border border-studio-border text-xs">
                  <button
                    onClick={() => setPlayerMode("CINEMA")}
                    className={cn(
                      "px-2.5 py-1 rounded flex items-center gap-1.5 font-medium transition-all text-xs",
                      playerMode === "CINEMA"
                        ? "bg-studio-blue text-white font-bold"
                        : "text-studio-text-muted hover:text-studio-text"
                    )}
                  >
                    <Monitor className="w-3.5 h-3.5" />
                    Cinema / Desktop (16:9)
                  </button>
                  <button
                    onClick={() => setPlayerMode("SMARTPHONE")}
                    className={cn(
                      "px-2.5 py-1 rounded flex items-center gap-1.5 font-medium transition-all text-xs",
                      playerMode === "SMARTPHONE"
                        ? "bg-studio-purple text-white font-bold"
                        : "text-studio-text-muted hover:text-studio-text"
                    )}
                  >
                    <Smartphone className="w-3.5 h-3.5" />
                    Smartphone / Shorts (9:16)
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2 text-xs">
                <span className="px-2 py-0.5 rounded bg-studio-panel border border-studio-border text-[10px] font-mono text-studio-gold font-bold">
                  4K 60FPS
                </span>
                <a
                  href={selectedVideo.videoUrl}
                  download={selectedVideo.title}
                  target="_blank"
                  rel="noreferrer"
                  className="p-1.5 rounded-lg border border-studio-border text-studio-text-muted hover:text-studio-text hover:bg-studio-panel transition-colors"
                  title="Baixar arquivo de vídeo MP4"
                >
                  <Download className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>

            {/* PLAYER: CINEMA MODE (16:9 YouTube Desktop) */}
            {playerMode === "CINEMA" && (
              <div className="space-y-4">
                <div className="w-full aspect-video rounded-xl bg-black overflow-hidden relative group shadow-2xl border border-studio-border/60">
                  <video
                    ref={videoRef}
                    src={selectedVideo.videoUrl}
                    poster={selectedVideo.thumbnailUrl}
                    onTimeUpdate={handleTimeUpdate}
                    onEnded={() => setIsPlaying(false)}
                    className="w-full h-full object-contain"
                    playsInline
                  />

                  {/* Play Overlay Button */}
                  {!isPlaying && (
                    <div
                      onClick={handleTogglePlay}
                      className="absolute inset-0 bg-black/40 flex items-center justify-center cursor-pointer transition-colors hover:bg-black/30"
                    >
                      <div className="w-16 h-16 rounded-full bg-red-600 text-white flex items-center justify-center shadow-2xl hover:scale-110 transition-transform">
                        <Play className="w-7 h-7 ml-1 fill-white" />
                      </div>
                    </div>
                  )}

                  {/* Custom Player Controls Bar */}
                  <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent p-3 pt-6 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col gap-2">
                    {/* Scrub bar */}
                    <input
                      type="range"
                      min={0}
                      max={duration || selectedVideo.durationSeconds}
                      value={currentTime}
                      onChange={handleSeek}
                      className="w-full h-1 bg-white/30 rounded-lg appearance-none cursor-pointer accent-red-600"
                    />

                    {/* Buttons row */}
                    <div className="flex items-center justify-between text-white text-xs">
                      <div className="flex items-center gap-3">
                        <button onClick={handleTogglePlay} className="hover:text-red-400">
                          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                        </button>

                        <button onClick={handleToggleMute} className="hover:text-red-400">
                          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                        </button>

                        <span className="font-mono text-[11px] text-white/80">
                          {formatSeconds(currentTime)} / {formatSeconds(duration || selectedVideo.durationSeconds)}
                        </span>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className="text-[10px] font-mono uppercase tracking-wider text-white/60">
                          Streaming HTTP 206
                        </span>
                        <button
                          onClick={() => {
                            if (videoRef.current) {
                              if (document.fullscreenElement) {
                                document.exitFullscreen();
                              } else {
                                videoRef.current.requestFullscreen();
                              }
                            }
                          }}
                          className="hover:text-red-400"
                        >
                          <Maximize2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Simulated YouTube Video Details Header (Watch Page Feel) */}
                <div className="p-4 rounded-xl bg-studio-panel/50 border border-studio-border space-y-3">
                  <h1 className="text-base sm:text-lg font-black text-studio-text leading-snug">
                    {selectedVideo.title}
                  </h1>

                  <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                    {/* Channel info */}
                    <div className="flex items-center gap-3">
                      <img
                        src={selectedVideo.channelAvatar}
                        alt={selectedVideo.channelName}
                        className="w-10 h-10 rounded-full object-cover border border-studio-border"
                      />
                      <div>
                        <span className="font-bold text-xs text-studio-text block">
                          {selectedVideo.channelName}
                        </span>
                        <span className="text-[11px] text-studio-text-muted">
                          {selectedVideo.channelHandle} · 148 mil inscritos
                        </span>
                      </div>
                      <button className="ml-2 px-3 py-1.5 rounded-full bg-white text-black font-bold text-xs hover:bg-neutral-200">
                        Inscrever-se
                      </button>
                    </div>

                    {/* Simulated YouTube action buttons */}
                    <div className="flex items-center gap-1.5 text-xs">
                      <div className="flex items-center rounded-full bg-studio-panel border border-studio-border overflow-hidden">
                        <button className="px-3 py-1.5 flex items-center gap-1.5 hover:bg-studio-surface font-semibold text-studio-text">
                          <ThumbsUp className="w-3.5 h-3.5" />
                          <span>4.2 mil</span>
                        </button>
                      </div>
                      <button className="px-3 py-1.5 rounded-full bg-studio-panel border border-studio-border flex items-center gap-1.5 hover:bg-studio-surface font-semibold text-studio-text">
                        <Share2 className="w-3.5 h-3.5" />
                        <span>Compartilhar</span>
                      </button>
                      <button
                        onClick={() => handleCopy(selectedVideo.videoUrl, "Link do Vídeo")}
                        className="px-3 py-1.5 rounded-full bg-studio-panel border border-studio-border flex items-center gap-1.5 hover:bg-studio-surface font-semibold text-studio-text"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copiar Link</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* PLAYER: SMARTPHONE MODE (9:16 Vertical Shorts / Reels / TikTok) */}
            {playerMode === "SMARTPHONE" && (
              <div className="flex flex-col items-center justify-center py-4">
                <div className="w-[310px] aspect-[9/16] rounded-[36px] bg-black p-3.5 shadow-2xl border-4 border-neutral-700 relative overflow-hidden flex flex-col justify-between group">
                  {/* Smartphone Top Notch & Status Bar */}
                  <div className="absolute top-2 inset-x-0 flex items-center justify-between px-6 z-20 text-[10px] font-mono text-white/90">
                    <span>18:30</span>
                    <div className="w-16 h-3 bg-black rounded-full border border-white/10" />
                    <span>5G 100%</span>
                  </div>

                  {/* Video Element */}
                  <video
                    ref={videoRef}
                    src={selectedVideo.videoUrl}
                    poster={selectedVideo.thumbnailUrl}
                    onTimeUpdate={handleTimeUpdate}
                    onEnded={() => setIsPlaying(false)}
                    loop
                    className="absolute inset-0 w-full h-full object-cover z-0"
                    playsInline
                  />

                  {/* Play/Pause Click Surface */}
                  <div
                    onClick={handleTogglePlay}
                    className="absolute inset-0 z-10 flex items-center justify-center cursor-pointer"
                  >
                    {!isPlaying && (
                      <div className="w-14 h-14 rounded-full bg-black/60 text-white flex items-center justify-center backdrop-blur-xs">
                        <Play className="w-6 h-6 ml-0.5 fill-white" />
                      </div>
                    )}
                  </div>

                  {/* Vertical In-Video Overlay (Right Sidebar Icons: Like, Comment, Share) */}
                  <div className="relative z-20 flex-1 flex flex-col justify-end items-end pb-12 pr-2 gap-4">
                    <div className="flex flex-col items-center text-white">
                      <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-xs flex items-center justify-center">
                        <ThumbsUp className="w-5 h-5 text-white" />
                      </div>
                      <span className="text-[10px] font-bold mt-0.5">38.4k</span>
                    </div>

                    <div className="flex flex-col items-center text-white">
                      <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-xs flex items-center justify-center">
                        <MessageSquare className="w-5 h-5 text-white" />
                      </div>
                      <span className="text-[10px] font-bold mt-0.5">1.2k</span>
                    </div>

                    <div className="flex flex-col items-center text-white">
                      <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-xs flex items-center justify-center">
                        <Bookmark className="w-5 h-5 text-white" />
                      </div>
                      <span className="text-[10px] font-bold mt-0.5">Salvar</span>
                    </div>

                    <div className="flex flex-col items-center text-white">
                      <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-xs flex items-center justify-center">
                        <Share2 className="w-5 h-5 text-white" />
                      </div>
                      <span className="text-[10px] font-bold mt-0.5">Enviar</span>
                    </div>

                    <div className="w-9 h-9 rounded-full border-2 border-white/60 overflow-hidden animate-spin-slow">
                      <img
                        src={selectedVideo.channelAvatar}
                        alt="Disc"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>

                  {/* Bottom Text & Channel Overlay */}
                  <div className="relative z-20 p-2 text-white space-y-1 drop-shadow-md">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs text-white drop-shadow">
                        {selectedVideo.channelHandle}
                      </span>
                      <button className="px-2 py-0.5 rounded-full bg-red-600 text-[10px] font-bold text-white">
                        Seguir
                      </button>
                    </div>
                    <p className="text-[11px] text-white/95 line-clamp-2 leading-tight">
                      {selectedVideo.title}
                    </p>
                    <div className="flex items-center gap-1.5 text-[10px] text-white/80 font-mono">
                      <Disc3 className="w-3 h-3 text-studio-gold animate-spin" />
                      <span className="truncate max-w-[200px]">Trilha Sonora Original · AI Music Engine</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* PRE-PUBLISH INSPECTION TABS */}
          <div className="studio-card p-5 border border-studio-border bg-studio-surface space-y-4">
            {/* Tabs header */}
            <div className="flex items-center justify-between border-b border-studio-border pb-2">
              <div className="flex items-center gap-2 overflow-x-auto">
                {(
                  [
                    { id: "METADATA", label: "🏷️ Metadados & SEO", icon: Tag },
                    { id: "SIMULATOR", label: "🖼️ Simulador de Feed", icon: Eye },
                    { id: "COMPLIANCE", label: "🛡️ Auditoria & Segurança", icon: ShieldCheck },
                    { id: "SCRIPT", label: "✍️ Roteiro & Legendas", icon: FileText },
                  ] as const
                ).map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={cn(
                      "px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap",
                      activeTab === tab.id
                        ? "bg-studio-gold text-black shadow-sm font-bold"
                        : "text-studio-text-muted hover:text-studio-text hover:bg-studio-panel"
                    )}
                  >
                    <span>{tab.label}</span>
                  </button>
                ))}
              </div>

              <span className="text-[11px] font-mono text-studio-text-muted hidden sm:inline-block">
                Score de Otimização:{" "}
                <strong className="text-emerald-400 font-bold">{selectedVideo.complianceScore}/100</strong>
              </span>
            </div>

            {/* TAB 1: METADATA & SEO */}
            {activeTab === "METADATA" && (
              <div className="space-y-4 text-xs">
                {/* Title */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="font-bold text-studio-text-muted uppercase text-[10px] tracking-wider">
                      Título Oficial de Publicação
                    </label>
                    <button
                      onClick={() => handleCopy(selectedVideo.title, "Título")}
                      className="text-[11px] text-studio-gold hover:underline flex items-center gap-1"
                    >
                      <Copy className="w-3 h-3" /> Copiar
                    </button>
                  </div>
                  <input
                    type="text"
                    value={selectedVideo.title}
                    onChange={(e) =>
                      setSelectedVideo((prev) => ({ ...prev, title: e.target.value }))
                    }
                    className="w-full p-2.5 rounded-lg bg-studio-panel border border-studio-border text-xs text-studio-text font-semibold focus:outline-none focus:border-studio-gold"
                  />
                </div>

                {/* Description */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="font-bold text-studio-text-muted uppercase text-[10px] tracking-wider">
                      Descrição Otimizada (Com Timestamps & Hashtags)
                    </label>
                    <button
                      onClick={() => handleCopy(selectedVideo.description, "Descrição")}
                      className="text-[11px] text-studio-gold hover:underline flex items-center gap-1"
                    >
                      <Copy className="w-3 h-3" /> Copiar
                    </button>
                  </div>
                  <textarea
                    rows={5}
                    value={selectedVideo.description}
                    onChange={(e) =>
                      setSelectedVideo((prev) => ({ ...prev, description: e.target.value }))
                    }
                    className="w-full p-2.5 rounded-lg bg-studio-panel border border-studio-border text-xs text-studio-text font-mono leading-relaxed focus:outline-none focus:border-studio-gold"
                  />
                </div>

                {/* Tags */}
                <div className="space-y-1.5">
                  <label className="font-bold text-studio-text-muted uppercase text-[10px] tracking-wider block">
                    Tags de Busca YouTube (SEO)
                  </label>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedVideo.tags.map((tag, i) => (
                      <span
                        key={i}
                        className="px-2.5 py-1 rounded-md bg-studio-panel border border-studio-border text-[11px] text-studio-text font-medium"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: FEED SIMULATOR */}
            {activeTab === "SIMULATOR" && (
              <div className="space-y-4">
                <div className="p-3 rounded-lg bg-studio-panel border border-studio-border text-xs text-studio-text-muted">
                  Veja exatamente como este vídeo aparecerá nos resultados de busca e na página inicial do YouTube
                  para os usuários:
                </div>

                {/* Simulated YouTube Search Result Card */}
                <div className="p-4 rounded-xl bg-black border border-neutral-800 flex flex-col sm:flex-row gap-4">
                  <div className="w-full sm:w-60 aspect-video rounded-xl overflow-hidden relative shrink-0 bg-neutral-900">
                    <img
                      src={selectedVideo.thumbnailUrl}
                      alt="Thumbnail Preview"
                      className="w-full h-full object-cover"
                    />
                    <span className="absolute bottom-1.5 right-1.5 px-1.5 py-0.5 rounded bg-black/90 font-mono text-[10px] font-bold text-white">
                      {formatSeconds(selectedVideo.durationSeconds)}
                    </span>
                  </div>

                  <div className="flex-1 space-y-1.5">
                    <h3 className="text-sm font-bold text-white leading-snug line-clamp-2">
                      {selectedVideo.title}
                    </h3>
                    <div className="flex items-center gap-1.5 text-neutral-400 text-xs">
                      <span>{selectedVideo.channelName}</span>
                      <span>·</span>
                      <span>12 mil visualizações</span>
                      <span>·</span>
                      <span>há 2 horas</span>
                    </div>

                    <div className="flex items-center gap-2 pt-1">
                      <img
                        src={selectedVideo.channelAvatar}
                        alt="Channel"
                        className="w-6 h-6 rounded-full object-cover"
                      />
                      <span className="text-xs text-neutral-300 font-medium">{selectedVideo.channelHandle}</span>
                    </div>

                    <p className="text-xs text-neutral-400 line-clamp-2 mt-1">
                      {selectedVideo.description}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 3: COMPLIANCE & QUALITY GATE */}
            {activeTab === "COMPLIANCE" && (
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 space-y-1">
                    <div className="flex items-center gap-1.5 text-emerald-400 font-bold text-xs">
                      <ShieldCheck className="w-4 h-4" />
                      <span>Direitos Autorais (Content ID)</span>
                    </div>
                    <p className="text-[11px] text-emerald-300/80">
                      100% Limpo. Trilha sonora e efeitos de voz gerados sem royalties detectados.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-blue-500/10 border border-blue-500/30 space-y-1">
                    <div className="flex items-center gap-1.5 text-blue-400 font-bold text-xs">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Anti-Clickbait & Retenção</span>
                    </div>
                    <p className="text-[11px] text-blue-300/80">
                      Promessa do título alinhada 100% ao roteiro analisado pelo modelo.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-purple-500/10 border border-purple-500/30 space-y-1">
                    <div className="flex items-center gap-1.5 text-purple-400 font-bold text-xs">
                      <Sparkles className="w-4 h-4" />
                      <span>Classificação COPPA</span>
                    </div>
                    <p className="text-[11px] text-purple-300/80">
                      {selectedVideo.isMadeForKids
                        ? "Conteúdo Feito para Crianças (COPPA ativo)."
                        : "Conteúdo Geral para todos os públicos."}
                    </p>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-studio-panel border border-studio-border flex items-center justify-between text-xs">
                  <span className="text-studio-text">Status de Pré-Aprovação Humana:</span>
                  <span className="font-bold text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Aprovado para Publicação Automática
                  </span>
                </div>
              </div>
            )}

            {/* TAB 4: SCRIPT & SUBTITLES */}
            {activeTab === "SCRIPT" && (
              <div className="space-y-3">
                <div className="p-3.5 rounded-xl bg-studio-panel border border-studio-border space-y-1.5">
                  <span className="text-[10px] uppercase font-bold text-studio-gold font-mono tracking-wider">
                    Fragmento do Roteiro (Hook de Retenção)
                  </span>
                  <p className="text-xs text-studio-text leading-relaxed font-serif italic">
                    "{selectedVideo.scriptSnippet}"
                  </p>
                </div>

                <div className="flex items-center justify-between p-3 rounded-lg bg-studio-panel border border-studio-border text-xs">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-studio-blue" />
                    <span className="font-semibold text-studio-text">Legendas Sincronizadas (SRT / VTT)</span>
                  </div>
                  <button
                    onClick={() => handleCopy("1\n00:00:01,000 --> 00:00:04,500\n" + selectedVideo.title, "Legendas")}
                    className="text-xs text-studio-gold hover:underline flex items-center gap-1"
                  >
                    <Download className="w-3 h-3" /> Baixar Legendas (.srt)
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* SCHEDULING MODAL */}
      {showScheduleModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="studio-card p-6 max-w-md w-full border border-studio-border bg-studio-surface shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-studio-border pb-3">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-studio-gold" />
                <h3 className="text-base font-bold text-studio-text">Agendar Publicação</h3>
              </div>
              <button
                onClick={() => setShowScheduleModal(false)}
                className="text-studio-text-muted hover:text-studio-text"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-studio-text-muted">
              Selecione o horário ideal para colocar o vídeo <strong>"{selectedVideo.title}"</strong> no ar:
            </p>

            <div className="space-y-2">
              <label className="text-[11px] font-bold text-studio-text-muted uppercase">
                Data e Horário
              </label>
              <input
                type="datetime-local"
                value={scheduleDateTime}
                onChange={(e) => setScheduleDateTime(e.target.value)}
                className="w-full p-2.5 rounded-lg bg-studio-panel border border-studio-border text-xs text-studio-text focus:outline-none focus:border-studio-gold font-mono"
              />
            </div>

            <div className="p-3 rounded-lg bg-studio-panel/70 border border-studio-border text-xs text-studio-gold space-y-1">
              <span className="font-bold block">💡 Dica de Inteligência Artificial:</span>
              <p className="text-studio-text-muted">
                O pico de engajamento do seu público no nicho é às <strong>18:30 (Segunda a Quinta)</strong>.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-studio-border">
              <button
                type="button"
                onClick={() => setShowScheduleModal(false)}
                className="btn text-xs py-2 px-3 border border-studio-border text-studio-text-muted"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmSchedule}
                className="btn-gold text-xs py-2 px-4 font-bold flex items-center gap-1.5"
              >
                <Calendar className="w-3.5 h-3.5" />
                Confirmar Agendamento
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
