import React, { useState, useEffect } from "react";
import {
  Plus,
  Tv,
  Youtube,
  Sparkles,
  Instagram,
  Facebook,
  Share2,
  CheckCircle2,
  Trash2,
  Settings,
  Users,
  Film,
  Zap,
  Bot,
  ExternalLink,
  Sliders,
  Globe,
  DollarSign,
  Flame,
  ShieldCheck,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import type { Platform, SocialChannel } from "@/types";
import {
  getSocialChannels,
  connectSocialChannel,
  disconnectSocialChannel,
} from "@/lib/publishingScheduler";
import {
  getYouTubeChannels,
  createYouTubeChannelFromPreset,
  setActiveYouTubeChannelId,
  getActiveYouTubeChannel,
  deleteYouTubeChannel,
} from "@/lib/youtubeFactory/channelStore";
import type { YouTubeChannelProject, YouTubeNichePreset } from "@/types/youtubeFactory";

const AVATAR_PRESETS = [
  { label: "Futurista Tech", url: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400&auto=format&fit=crop&q=80" },
  { label: "Finanças Executivo", url: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=400&auto=format&fit=crop&q=80" },
  { label: "Criadora Criativa", url: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80" },
  { label: "Studio Dark Gold", url: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80" },
];

export const AddChannelsTab: React.FC = () => {
  const { toast } = useToast();
  const [socialChannels, setSocialChannels] = useState<SocialChannel[]>([]);
  const [ytChannels, setYtChannels] = useState<YouTubeChannelProject[]>([]);
  const [activeYtChannel, setActiveYtChannel] = useState<YouTubeChannelProject | null>(null);

  // Form State
  const [isCreating, setIsCreating] = useState(false);
  const [selectedPlatform, setSelectedPlatform] = useState<Platform>("YOUTUBE");
  const [channelName, setChannelName] = useState("");
  const [channelHandle, setChannelHandle] = useState("");
  const [channelNiche, setChannelNiche] = useState("Inteligência Artificial & Futuro");
  const [channelLang, setChannelLang] = useState("PT");
  const [selectedAvatar, setSelectedAvatar] = useState(AVATAR_PRESETS[0].url);
  const [customAvatar, setCustomAvatar] = useState("");
  const [automationLevel, setAutomationLevel] = useState<"AUTONOMO" | "SEMI_AUTOMATICO" | "MANUAL">("SEMI_AUTOMATICO");
  const [targetSubs, setTargetSubs] = useState("100000");

  const refreshChannels = () => {
    setSocialChannels(getSocialChannels());
    const yts = getYouTubeChannels();
    setYtChannels(yts);
    setActiveYtChannel(getActiveYouTubeChannel());
  };

  useEffect(() => {
    refreshChannels();
  }, []);

  const handleCreateChannel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!channelName.trim()) {
      toast({ title: "Nome obrigatório", description: "Informe o nome do canal.", variant: "destructive" });
      return;
    }

    const finalAvatar = customAvatar.trim() || selectedAvatar;
    const finalHandle = channelHandle.startsWith("@") ? channelHandle : `@${channelHandle || channelName.toLowerCase().replace(/\s+/g, "")}`;

    if (selectedPlatform === "YOUTUBE") {
      const newYt = createYouTubeChannelFromPreset("AI_FUTURO", {
        name: channelName,
        handle: finalHandle,
        niche: channelNiche,
        language: channelLang,
        logoUrl: finalAvatar,
        automationLevel,
        goals: {
          primaryGoal: "ADSENSE_REVENUE",
          targetSubscribers: parseInt(targetSubs) || 100000,
          targetMonthlyViews: 500000,
        },
      });
      setActiveYouTubeChannelId(newYt.id);
    }

    // Also register in social channels store for multi-platform scheduler
    const newSocial: SocialChannel = {
      id: `chan_${selectedPlatform.toLowerCase()}_${Date.now()}`,
      platform: selectedPlatform,
      name: channelName,
      handle: finalHandle,
      channelId: `id_${selectedPlatform.toLowerCase()}_${Math.random().toString(36).substring(2, 8)}`,
      avatarUrl: finalAvatar,
      status: "CONNECTED",
      lastSyncAt: new Date().toISOString(),
      subscriberCount: 0,
      totalViews: 0,
      totalVideos: 0,
      isDefault: false,
    };
    connectSocialChannel(newSocial);

    toast({
      title: "Canal Criado com Sucesso!",
      description: `O canal "${channelName}" foi adicionado em ${selectedPlatform}.`,
    });

    // Reset Form
    setChannelName("");
    setChannelHandle("");
    setIsCreating(false);
    refreshChannels();
  };

  const handleCreateFromPreset = (presetKey: YouTubeNichePreset, title: string) => {
    const created = createYouTubeChannelFromPreset(presetKey);
    setActiveYouTubeChannelId(created.id);
    refreshChannels();
    toast({
      title: "Canal Criado via Preset!",
      description: `O canal pronto "${created.name}" foi ativado com todas as configurações de nicho e voz.`,
    });
  };

  const handleSetActive = (ch: YouTubeChannelProject) => {
    setActiveYouTubeChannelId(ch.id);
    setActiveYtChannel(ch);
    toast({
      title: "Canal Ativo Atualizado",
      description: `Você está gerenciando "${ch.name}" agora.`,
    });
  };

  const handleDeleteYt = (id: string, name: string) => {
    if (ytChannels.length <= 1) {
      toast({
        title: "Operação não permitida",
        description: "Você precisa manter pelo menos 1 canal cadastrado no sistema.",
        variant: "destructive",
      });
      return;
    }
    deleteYouTubeChannel(id);
    refreshChannels();
    toast({ title: "Canal Removido", description: `Canal ${name} foi removido com sucesso.` });
  };

  const handleDeleteSocial = (id: string, name: string) => {
    disconnectSocialChannel(id);
    refreshChannels();
    toast({ title: "Canal Social Desconectado", description: `${name} foi desconectado.` });
  };

  return (
    <div className="space-y-8 animate-fadeIn" id="tab-adicionar-canais">
      {/* Top Banner & Call to Action */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-studio-panel via-studio-surface to-studio-panel border border-studio-border flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-sm">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-studio-gold/15 text-studio-gold border border-studio-gold/30">
              HUB DE CANAIS
            </span>
            <span className="text-xs text-studio-text-muted">Multi-Plataforma IA</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-studio-text font-display flex items-center gap-2.5">
            <Tv className="w-6 h-6 text-studio-gold" />
            Adicionar Canais
          </h2>
          <p className="text-sm text-studio-text-muted max-w-2xl leading-relaxed">
            Cadastre canais do YouTube, TikTok, Instagram e Facebook. Cada canal possui sua própria identidade visual, voz com IA, frequência de postagem e presets de monetização.
          </p>
        </div>

        <button
          onClick={() => setIsCreating(!isCreating)}
          className="btn-gold text-sm py-2.5 px-5 flex items-center gap-2 shrink-0 shadow-md shadow-studio-gold/15"
        >
          <Plus className="w-4 h-4 text-black" />
          <span>{isCreating ? "Fechar Formulário" : "Novo Canal Customizado"}</span>
        </button>
      </div>

      {/* 1-Click Quick Presets for YouTube Factory */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-studio-text flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-studio-gold" />
            Criar em 1 Clique com Presets Especializados (Alta Rentabilidade RPM)
          </h3>
          <span className="text-xs text-studio-text-muted">Pronto com nicho, identidade e voz</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            {
              preset: "AI_FUTURO" as YouTubeNichePreset,
              title: "🤖 Inteligência Artificial & Futuro",
              niche: "Modelos IA, AGI & Robótica",
              desc: "Voz confiável de tecnologia, identidade Cyber Tech e tags de alto RPM.",
              color: "border-sky-500/30 hover:border-sky-500 bg-sky-950/10",
            },
            {
              preset: "DINHEIRO_NEGOCIOS" as YouTubeNichePreset,
              title: "💰 Dinheiro & Negócios Digitais",
              niche: "Finanças, SaaS & Empreendedorismo",
              desc: "Formato Faceless com transições rápidas e foco em faturamento.",
              color: "border-emerald-500/30 hover:border-emerald-500 bg-emerald-950/10",
            },
            {
              preset: "CURIOSIDADES_MISTERIOS" as YouTubeNichePreset,
              title: "🌌 Curiosidades & Mistérios",
              niche: "Ciência, Universo & Fatos Ocultos",
              desc: "Tom dramático com ganchos hipnóticos para máxima retenção de público.",
              color: "border-purple-500/30 hover:border-purple-500 bg-purple-950/10",
            },
            {
              preset: "FILOSOFIA_ESTOICISMO" as YouTubeNichePreset,
              title: "🏛️ Filosofia & Produtividade",
              niche: "Estoicismo, Hábitos & Mentalidade",
              desc: "Voz profunda clássica, estética Dark Cinema e trilha sonora imersiva.",
              color: "border-amber-500/30 hover:border-amber-500 bg-amber-950/10",
            },
          ].map((item) => (
            <div
              key={item.preset}
              className={cn(
                "studio-card p-4 flex flex-col justify-between transition-all border group",
                item.color
              )}
            >
              <div className="space-y-2 mb-4">
                <h4 className="text-sm font-bold text-studio-text group-hover:text-studio-gold transition-colors">
                  {item.title}
                </h4>
                <span className="inline-block px-2 py-0.5 rounded text-[10px] font-semibold bg-studio-surface border border-studio-border text-studio-text-muted">
                  {item.niche}
                </span>
                <p className="text-xs text-studio-text-muted leading-relaxed">
                  {item.desc}
                </p>
              </div>

              <button
                onClick={() => handleCreateFromPreset(item.preset, item.title)}
                className="w-full py-2 px-3 rounded-xl bg-studio-surface hover:bg-studio-panel border border-studio-border text-xs font-bold text-studio-text flex items-center justify-center gap-1.5 transition-all"
              >
                <Plus className="w-3.5 h-3.5 text-studio-gold" />
                <span>Ativar Preset</span>
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Create Custom Channel Modal / Accordion */}
      {isCreating && (
        <form
          onSubmit={handleCreateChannel}
          className="p-6 rounded-2xl bg-studio-panel border border-studio-gold/40 shadow-xl space-y-6 animate-scaleIn"
        >
          <div className="flex items-center justify-between border-b border-studio-border pb-3">
            <div>
              <h3 className="text-base font-bold text-studio-text flex items-center gap-2">
                <Sliders className="w-4 h-4 text-studio-gold" />
                Configurar Novo Canal
              </h3>
              <p className="text-xs text-studio-text-muted">
                Preencha os dados de identificação e automação do canal.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setIsCreating(false)}
              className="text-xs text-studio-text-muted hover:text-studio-text"
            >
              Cancelar
            </button>
          </div>

          {/* Platform Selector */}
          <div>
            <label className="block text-xs font-bold text-studio-text mb-2">
              Selecione a Plataforma Principal:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {[
                { id: "YOUTUBE", label: "YouTube", icon: Youtube, color: "text-red-500" },
                { id: "TIKTOK", label: "TikTok", icon: Sparkles, color: "text-cyan-400" },
                { id: "INSTAGRAM", label: "Instagram", icon: Instagram, color: "text-pink-500" },
                { id: "FACEBOOK", label: "Facebook", icon: Facebook, color: "text-blue-500" },
              ].map((p) => (
                <button
                  type="button"
                  key={p.id}
                  onClick={() => setSelectedPlatform(p.id as Platform)}
                  className={cn(
                    "p-3 rounded-xl border flex items-center gap-2.5 transition-all text-left",
                    selectedPlatform === p.id
                      ? "bg-studio-surface border-studio-gold text-studio-text shadow-sm"
                      : "bg-studio-surface/50 border-studio-border text-studio-text-muted hover:text-studio-text"
                  )}
                >
                  <p.icon className={cn("w-4 h-4", p.color)} />
                  <span className="text-xs font-bold">{p.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Fields */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-studio-text mb-1.5">
                Nome Oficial do Canal:
              </label>
              <input
                type="text"
                required
                value={channelName}
                onChange={(e) => setChannelName(e.target.value)}
                placeholder="Ex: Radar de Inteligência Artificial"
                className="w-full px-3.5 py-2.5 rounded-xl bg-studio-surface border border-studio-border text-sm text-studio-text focus:outline-hidden focus:border-studio-gold"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-studio-text mb-1.5">
                @Handle / Identificador:
              </label>
              <input
                type="text"
                value={channelHandle}
                onChange={(e) => setChannelHandle(e.target.value)}
                placeholder="Ex: @radaria_oficial"
                className="w-full px-3.5 py-2.5 rounded-xl bg-studio-surface border border-studio-border text-sm text-studio-text focus:outline-hidden focus:border-studio-gold font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-studio-text mb-1.5">
                Nicho / Categoria Principal:
              </label>
              <select
                value={channelNiche}
                onChange={(e) => setChannelNiche(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-studio-surface border border-studio-border text-sm text-studio-text focus:outline-hidden focus:border-studio-gold"
              >
                <option value="Inteligência Artificial & Futuro">Inteligência Artificial & Futuro (Alto RPM)</option>
                <option value="Dinheiro & Negócios">Dinheiro, Finanças & Negócios</option>
                <option value="Curiosidades & Mistérios">Curiosidades, Fatos & Ciência</option>
                <option value="Filosofia & Mentalidade">Filosofia, Estoicismo & Hábitos</option>
                <option value="Tecnologia & Gadgets">Tecnologia, Análises & Notícias</option>
                <option value="Saúde & Bem-Estar">Saúde, Longevidade & Nutrição</option>
                <option value="Shorts Virais Diversos">Shorts Virais de Entretenimento</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-studio-text mb-1.5">
                Idioma Principal:
              </label>
              <select
                value={channelLang}
                onChange={(e) => setChannelLang(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-studio-surface border border-studio-border text-sm text-studio-text focus:outline-hidden focus:border-studio-gold"
              >
                <option value="PT">Português (Brasil / Portugal / Angola)</option>
                <option value="EN">Inglês (Global / EUA - RPM Máximo)</option>
                <option value="ES">Espanhol (América Latina & Espanha)</option>
                <option value="FR">Francês (França & Internacional)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-studio-text mb-1.5">
                Nível de Automação com IA:
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: "SEMI_AUTOMATICO", label: "Semi-Auto", desc: "Aprovação humana" },
                  { id: "AUTONOMO", label: "100% Autônomo", desc: "IA posta na hora" },
                  { id: "MANUAL", label: "Manual", desc: "Você controla tudo" },
                ].map((lvl) => (
                  <button
                    type="button"
                    key={lvl.id}
                    onClick={() => setAutomationLevel(lvl.id as "AUTONOMO" | "SEMI_AUTOMATICO" | "MANUAL")}
                    className={cn(
                      "p-2.5 rounded-xl border text-center transition-all",
                      automationLevel === lvl.id
                        ? "bg-studio-surface border-studio-gold text-studio-text font-bold"
                        : "bg-studio-surface/40 border-studio-border text-studio-text-muted hover:text-studio-text"
                    )}
                  >
                    <span className="block text-xs">{lvl.label}</span>
                    <span className="text-[10px] text-studio-text-muted block">{lvl.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-studio-text mb-1.5">
                Meta de Inscritos / Seguidores:
              </label>
              <input
                type="number"
                value={targetSubs}
                onChange={(e) => setTargetSubs(e.target.value)}
                placeholder="100000"
                className="w-full px-3.5 py-2.5 rounded-xl bg-studio-surface border border-studio-border text-sm text-studio-text focus:outline-hidden focus:border-studio-gold"
              />
            </div>
          </div>

          {/* Avatar Selector */}
          <div>
            <label className="block text-xs font-bold text-studio-text mb-2">
              Foto de Perfil / Avatar do Canal:
            </label>
            <div className="flex items-center gap-3 overflow-x-auto pb-2">
              {AVATAR_PRESETS.map((av, idx) => (
                <div
                  key={idx}
                  onClick={() => {
                    setSelectedAvatar(av.url);
                    setCustomAvatar("");
                  }}
                  className={cn(
                    "cursor-pointer p-1 rounded-2xl border-2 transition-all flex flex-col items-center gap-1 shrink-0",
                    selectedAvatar === av.url && !customAvatar
                      ? "border-studio-gold bg-studio-gold/10"
                      : "border-studio-border hover:border-studio-text-muted"
                  )}
                >
                  <img
                    src={av.url}
                    alt={av.label}
                    className="w-12 h-12 rounded-xl object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <span className="text-[10px] text-studio-text-muted font-medium">{av.label}</span>
                </div>
              ))}
            </div>

            <div className="mt-2">
              <input
                type="url"
                value={customAvatar}
                onChange={(e) => setCustomAvatar(e.target.value)}
                placeholder="Ou cole uma URL personalizada de imagem para a foto do canal..."
                className="w-full px-3.5 py-2 rounded-xl bg-studio-surface border border-studio-border text-xs text-studio-text focus:outline-hidden focus:border-studio-gold"
              />
            </div>
          </div>

          {/* Submit */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-studio-border">
            <button
              type="button"
              onClick={() => setIsCreating(false)}
              className="px-4 py-2 rounded-xl text-xs font-bold text-studio-text-muted hover:text-studio-text hover:bg-studio-surface"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="btn-gold text-xs py-2.5 px-6 font-bold flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4 text-black" />
              <span>Salvar e Ativar Canal</span>
            </button>
          </div>
        </form>
      )}

      {/* Channels List: YouTube Projects */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b border-studio-border pb-2">
          <div>
            <h3 className="text-base font-bold text-studio-text flex items-center gap-2 font-display">
              <Youtube className="w-5 h-5 text-red-500" />
              Canais YouTube Cadastrados ({ytChannels.length})
            </h3>
            <p className="text-xs text-studio-text-muted">
              Canais com pipelines automatizados de roteiro, thumbnail, SEO e qualidade.
            </p>
          </div>
          <span className="text-xs text-studio-gold font-bold">
            Canal Ativo: {activeYtChannel?.name || "Nenhum"}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {ytChannels.map((ch) => {
            const isActive = activeYtChannel?.id === ch.id;
            return (
              <div
                key={ch.id}
                className={cn(
                  "studio-card p-5 rounded-2xl border transition-all space-y-4 relative",
                  isActive
                    ? "border-studio-gold/60 bg-studio-panel/90 shadow-md shadow-studio-gold/5"
                    : "border-studio-border hover:border-studio-border/80"
                )}
              >
                {isActive && (
                  <span className="absolute top-4 right-4 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-studio-gold text-black uppercase tracking-wider">
                    CANAL ATIVO
                  </span>
                )}

                <div className="flex items-start gap-3.5">
                  <img
                    src={ch.logoUrl || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&auto=format&fit=crop&q=80"}
                    alt={ch.name}
                    className="w-14 h-14 rounded-2xl object-cover border-2 border-studio-border shrink-0 shadow-sm"
                    referrerPolicy="no-referrer"
                  />
                  <div className="flex-1 min-w-0 pr-16">
                    <h4 className="text-base font-bold text-studio-text truncate">{ch.name}</h4>
                    <p className="text-xs text-studio-blue font-mono">{ch.handle}</p>
                    <span className="inline-block mt-1 px-2 py-0.5 rounded-md text-[10px] font-semibold bg-studio-surface border border-studio-border text-studio-text-muted">
                      {ch.niche}
                    </span>
                  </div>
                </div>

                <p className="text-xs text-studio-text-muted line-clamp-2 leading-relaxed">
                  {ch.description || "Canal configurado com inteligência artificial para produção de conteúdo contínuo."}
                </p>

                {/* Metrics */}
                <div className="grid grid-cols-3 gap-2 pt-2 border-t border-studio-border text-xs">
                  <div className="p-2 rounded-xl bg-studio-surface border border-studio-border text-center">
                    <span className="text-[10px] text-studio-text-muted block">Idioma</span>
                    <span className="font-bold text-studio-text">{ch.language}</span>
                  </div>
                  <div className="p-2 rounded-xl bg-studio-surface border border-studio-border text-center">
                    <span className="text-[10px] text-studio-text-muted block">Meta Inscritos</span>
                    <span className="font-bold text-studio-gold">
                      {ch.goals?.targetSubscribers ? (ch.goals.targetSubscribers / 1000).toFixed(0) + "k" : "100k"}
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-studio-surface border border-studio-border text-center">
                    <span className="text-[10px] text-studio-text-muted block">Automação</span>
                    <span className="font-bold text-studio-green">
                      {ch.automationLevel === "AUTONOMO" ? "Autônomo" : "Semi-Auto"}
                    </span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center justify-between gap-2 pt-1">
                  {!isActive ? (
                    <button
                      onClick={() => handleSetActive(ch)}
                      className="px-3 py-1.5 rounded-xl bg-studio-gold/15 text-studio-gold hover:bg-studio-gold hover:text-black font-bold text-xs transition-all flex items-center gap-1"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Tornar Canal Ativo</span>
                    </button>
                  ) : (
                    <span className="text-xs font-semibold text-studio-green flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Canal Conectado ao Studio
                    </span>
                  )}

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleDeleteYt(ch.id, ch.name)}
                      className="p-1.5 rounded-lg text-studio-text-muted hover:text-studio-red hover:bg-studio-red/10 transition-all"
                      title="Excluir Canal"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Channels List: Other Social Channels (TikTok, Instagram, Facebook) */}
      <div className="space-y-4 pt-4 border-t border-studio-border">
        <div className="flex items-center justify-between border-b border-studio-border pb-2">
          <div>
            <h3 className="text-base font-bold text-studio-text flex items-center gap-2 font-display">
              <Share2 className="w-5 h-5 text-studio-purple" />
              Canais & Redes Sociais Conectadas ({socialChannels.length})
            </h3>
            <p className="text-xs text-studio-text-muted">
              Plataformas sincronizadas para agendamento e publicação multi-rede.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {socialChannels.map((sc) => (
            <div
              key={sc.id}
              className="studio-card p-4 rounded-2xl border border-studio-border space-y-3 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-studio-surface border border-studio-border flex items-center gap-1 text-studio-text">
                    {sc.platform === "YOUTUBE" && <Youtube className="w-3 h-3 text-red-500" />}
                    {sc.platform === "TIKTOK" && <Sparkles className="w-3 h-3 text-cyan-400" />}
                    {sc.platform === "INSTAGRAM" && <Instagram className="w-3 h-3 text-pink-500" />}
                    {sc.platform === "FACEBOOK" && <Facebook className="w-3 h-3 text-blue-500" />}
                    <span>{sc.platform}</span>
                  </span>

                  <span className="flex items-center gap-1 text-[11px] text-studio-green font-semibold">
                    <span className="w-2 h-2 rounded-full bg-studio-green animate-pulse" />
                    Conectado
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <img
                    src={sc.avatarUrl || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80"}
                    alt={sc.name}
                    className="w-10 h-10 rounded-xl object-cover border border-studio-border shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <div className="min-w-0">
                    <h5 className="text-sm font-bold text-studio-text truncate">{sc.name}</h5>
                    <p className="text-xs text-studio-text-muted font-mono truncate">{sc.handle}</p>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-studio-border text-xs">
                <span className="text-studio-text-muted">
                  {sc.subscriberCount ? `${sc.subscriberCount.toLocaleString()} seguidores` : "Sincronizado"}
                </span>

                <button
                  onClick={() => handleDeleteSocial(sc.id, sc.name)}
                  className="p-1 rounded text-studio-text-muted hover:text-studio-red transition-all"
                  title="Desconectar rede"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
