import { useState } from "react";
import type { Script, ScriptSection } from "@/types";
import { cn, formatDuration } from "@/lib/utils";
import { Edit3, ChevronDown, ChevronRight, Clock } from "lucide-react";

interface ScriptEditorProps {
  script: Script;
  onUpdate: (script: Script) => void;
}

const SECTION_TYPE_COLORS: Record<string, string> = {
  HOOK: "text-studio-gold border-studio-gold/30 bg-studio-gold/5",
  INTRO: "text-studio-blue border-studio-blue/30 bg-studio-blue/5",
  MAIN: "text-studio-text border-studio-border bg-studio-panel",
  TRANSITION: "text-studio-purple border-studio-purple/30 bg-studio-purple/5",
  CTA: "text-studio-green border-studio-green/30 bg-studio-green/5",
  OUTRO: "text-studio-text-dim border-studio-border bg-studio-panel",
};

export default function ScriptEditor({ script, onUpdate }: ScriptEditorProps) {
  const [expanded, setExpanded] = useState<string | null>(script.sections[0]?.id ?? null);
  const [editing, setEditing] = useState<string | null>(null);
  const [editContent, setEditContent] = useState("");

  const startEdit = (section: ScriptSection) => {
    setEditing(section.id);
    setEditContent(section.content);
    setExpanded(section.id);
  };

  const saveEdit = (sectionId: string) => {
    const updated: Script = {
      ...script,
      sections: script.sections.map((s) =>
        s.id === sectionId ? { ...s, content: editContent } : s
      ),
      updatedAt: new Date().toISOString(),
    };
    onUpdate(updated);
    setEditing(null);
  };

  return (
    <div className="space-y-3 animate-fade-in">
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-base font-bold text-studio-text font-display">{script.title}</h3>
        <div className="flex items-center gap-2">
          <Clock className="w-3.5 h-3.5 text-studio-text-muted" />
          <span className="text-sm text-studio-text-muted">{formatDuration(script.totalDuration)}</span>
          <span className="task-badge text-xs bg-studio-blue/10 text-studio-blue border border-studio-blue/20">
            v{script.version}
          </span>
        </div>
      </div>

      {script.sections.map((section) => (
        <div
          key={section.id}
          className={cn("rounded-xl border transition-all", SECTION_TYPE_COLORS[section.type])}
        >
          <button
            onClick={() => setExpanded(expanded === section.id ? null : section.id)}
            className="w-full flex items-center gap-3 px-4 py-3 text-left"
          >
            <span className="text-xs font-bold uppercase tracking-wider w-16 shrink-0">
              {section.type}
            </span>
            <span className="flex-1 text-sm font-semibold text-studio-text">{section.title}</span>
            <span className="text-xs text-studio-text-muted">{formatDuration(section.duration)}</span>
            {expanded === section.id
              ? <ChevronDown className="w-4 h-4 shrink-0" />
              : <ChevronRight className="w-4 h-4 shrink-0" />
            }
          </button>

          {expanded === section.id && (
            <div className="px-4 pb-4 border-t border-current/10 pt-3 space-y-3">
              {editing === section.id ? (
                <div>
                  <textarea
                    value={editContent}
                    onChange={(e) => setEditContent(e.target.value)}
                    className="studio-input text-sm resize-none h-32"
                    autoFocus
                  />
                  <div className="flex gap-2 mt-2">
                    <button onClick={() => saveEdit(section.id)} className="btn-primary text-xs py-1.5 px-3">Salvar</button>
                    <button onClick={() => setEditing(null)} className="btn-secondary text-xs py-1.5 px-3">Cancelar</button>
                  </div>
                </div>
              ) : (
                <div>
                  <p className="text-sm text-studio-text-dim leading-relaxed">{section.content}</p>
                  <button
                    onClick={() => startEdit(section)}
                    className="mt-2 flex items-center gap-1.5 text-xs text-studio-text-muted hover:text-studio-blue transition-colors"
                  >
                    <Edit3 className="w-3 h-3" /> Editar
                  </button>
                </div>
              )}

              {section.narration && (
                <div className="bg-black/20 rounded-lg p-3">
                  <p className="text-xs text-studio-text-muted mb-1 uppercase tracking-wide">Narração</p>
                  <p className="text-sm text-studio-text-dim italic">"{section.narration}"</p>
                </div>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
