// ============================================================
// AI CREATOR STUDIO — CORE 2.0 PERFORMANCE COMPARISON MODAL
// Compare Video A vs Video B vs Video C
// ============================================================

import React, { useState } from "react";
import type { VideoAnalytics } from "@/types";
import { BarChart3, X, Check, ArrowUpRight, TrendingUp, Eye, ThumbsUp, Share2, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Props {
  isOpen: boolean;
  onClose: () => void;
  allVideos: VideoAnalytics[];
}

export const PerformanceComparisonModal: React.FC<Props> = ({ isOpen, onClose, allVideos }) => {
  const [selectedIds, setSelectedIds] = useState<string[]>(() => {
    return allVideos.slice(0, 2).map((v) => v.projectId);
  });

  if (!isOpen) return null;

  const toggleSelect = (id: string) => {
    if (selectedIds.includes(id)) {
      if (selectedIds.length > 1) {
        setSelectedIds(selectedIds.filter((x) => x !== id));
      }
    } else {
      if (selectedIds.length < 3) {
        setSelectedIds([...selectedIds, id]);
      }
    }
  };

  const selectedVideos = allVideos.filter((v) => selectedIds.includes(v.projectId));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto" id="performance-comparison-modal">
      <div className="relative w-full max-w-5xl bg-zinc-950 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-zinc-800 bg-zinc-900/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-blue-600/30 text-blue-400 border border-blue-500/30">
                  CORE 2.0
                </span>
                <h3 className="text-lg font-bold text-white">
                  Comparador de Desempenho (Vídeo A vs B vs C)
                </h3>
              </div>
              <p className="text-xs text-zinc-400">
                Selecione até 3 vídeos para comparar retenção, CTR, visualizações e compartilhamentos lado a lado.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Selector Row */}
        <div className="p-4 border-b border-zinc-800 bg-zinc-900/30 flex flex-wrap items-center gap-2">
          <span className="text-xs text-zinc-400 font-semibold mr-2">Selecione até 3 vídeos:</span>
          {allVideos.map((vid) => {
            const isSelected = selectedIds.includes(vid.projectId);
            return (
              <button
                key={vid.projectId}
                onClick={() => toggleSelect(vid.projectId)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  isSelected
                    ? "bg-blue-600 text-white shadow-sm"
                    : "bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-zinc-200"
                }`}
              >
                {isSelected && <Check className="w-3.5 h-3.5" />}
                <span className="max-w-[160px] truncate">{vid.projectTitle}</span>
              </button>
            );
          })}
        </div>

        {/* Comparative Columns */}
        <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-5">
          {selectedVideos.map((video, idx) => {
            const letter = String.fromCharCode(65 + idx);
            return (
              <div
                key={video.projectId}
                className="p-5 rounded-xl bg-zinc-900/90 border border-zinc-800 space-y-4"
              >
                {/* Header */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-bold">
                      {letter}
                    </span>
                    <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-zinc-800 text-zinc-300">
                      {video.platform}
                    </span>
                  </div>

                  <div className="relative aspect-video rounded-lg overflow-hidden bg-zinc-950 border border-zinc-800">
                    <img
                      src={video.thumbnailUrl || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80"}
                      alt="Thumbnail"
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <h4 className="text-sm font-bold text-white line-clamp-2 min-h-[40px]">
                    {video.projectTitle}
                  </h4>
                </div>

                {/* Metrics List */}
                <div className="space-y-2 text-xs divide-y divide-zinc-800/60">
                  <div className="pt-2 flex items-center justify-between">
                    <span className="text-zinc-400 flex items-center gap-1.5">
                      <Eye className="w-3.5 h-3.5 text-blue-400" /> Visualizações:
                    </span>
                    <strong className="text-white font-mono">{video.views.toLocaleString()}</strong>
                  </div>

                  <div className="pt-2 flex items-center justify-between">
                    <span className="text-zinc-400 flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-purple-400" /> Tempo de Exibição:
                    </span>
                    <strong className="text-white font-mono">{video.watchTimeHours.toLocaleString()}h</strong>
                  </div>

                  <div className="pt-2 flex items-center justify-between">
                    <span className="text-zinc-400 flex items-center gap-1.5">
                      <TrendingUp className="w-3.5 h-3.5 text-emerald-400" /> CTR (Taxa de Clique):
                    </span>
                    <strong className="text-emerald-400 font-mono">{video.ctr}%</strong>
                  </div>

                  <div className="pt-2 flex items-center justify-between">
                    <span className="text-zinc-400 flex items-center gap-1.5">
                      <ThumbsUp className="w-3.5 h-3.5 text-amber-400" /> Retenção Média:
                    </span>
                    <strong className="text-amber-400 font-mono">{video.avgViewPercentage}%</strong>
                  </div>

                  <div className="pt-2 flex items-center justify-between">
                    <span className="text-zinc-400 flex items-center gap-1.5">
                      <Share2 className="w-3.5 h-3.5 text-pink-400" /> Compartilhamentos:
                    </span>
                    <strong className="text-white font-mono">{video.shares.toLocaleString()}</strong>
                  </div>
                </div>

                {/* Mini Retention Bar */}
                <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800/80 space-y-1.5">
                  <span className="text-[10px] text-zinc-500 font-semibold uppercase">
                    Curva de Retenção
                  </span>
                  <div className="flex items-end gap-1 h-8">
                    {video.retentionCurve.map((pt, pIdx) => (
                      <div
                        key={pIdx}
                        className="flex-1 bg-blue-500/80 rounded-t hover:bg-blue-400 transition-colors"
                        style={{ height: `${pt.percentRemaining}%` }}
                        title={`${pt.timestampSec}s: ${pt.percentRemaining}%`}
                      />
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-zinc-800 bg-zinc-900/40 flex justify-end">
          <Button onClick={onClose} className="bg-zinc-800 hover:bg-zinc-700 text-white text-xs">
            Fechar Comparador
          </Button>
        </div>
      </div>
    </div>
  );
};
