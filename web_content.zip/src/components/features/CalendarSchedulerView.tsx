// ============================================================
// AI CREATOR STUDIO — CORE 2.0 CALENDAR SCHEDULER VIEW
// ============================================================

import React, { useState, useEffect } from "react";
import type { PublishingJob, Project } from "@/types";
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Clock,
  Plus,
  Play,
  CheckCircle2,
  Trash2,
  ExternalLink,
  Filter,
  Layers,
  Sparkles,
  Youtube,
  Instagram,
  Facebook,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { getPublishingJobs, deletePublishingJob } from "@/lib/publishingScheduler";
import { getProjects } from "@/lib/storage";
import { PrePublishApprovalModal } from "@/components/features/PrePublishApprovalModal";

export const CalendarSchedulerView: React.FC = () => {
  const { toast } = useToast();
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [jobs, setJobs] = useState<PublishingJob[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedJob, setSelectedJob] = useState<PublishingJob | null>(null);

  // New Schedule Modal State
  const [approvalModalOpen, setApprovalModalOpen] = useState(false);
  const [selectedProjectToSchedule, setSelectedProjectToSchedule] = useState<Project | null>(null);

  const loadData = () => {
    setJobs(getPublishingJobs());
    setProjects(getProjects());
  };

  useEffect(() => {
    loadData();
  }, []);

  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
  const firstDayIndex = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();

  const monthNames = [
    "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
  ];

  const handleOpenNewSchedule = () => {
    if (projects.length > 0) {
      setSelectedProjectToSchedule(projects[0]);
      setApprovalModalOpen(true);
    } else {
      toast({ title: "Nenhum Projeto", description: "Crie um projeto primeiro no Core 1.0." });
    }
  };

  const handleDeleteJob = (id: string) => {
    deletePublishingJob(id);
    loadData();
    setSelectedJob(null);
    toast({ title: "Agendamento Cancelado", description: "O item foi removido do calendário." });
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case "YOUTUBE":
        return <Youtube className="w-3.5 h-3.5 text-red-400" />;
      case "TIKTOK":
        return <Sparkles className="w-3.5 h-3.5 text-cyan-400" />;
      case "INSTAGRAM":
        return <Instagram className="w-3.5 h-3.5 text-pink-400" />;
      case "FACEBOOK":
        return <Facebook className="w-3.5 h-3.5 text-blue-400" />;
      default:
        return <Layers className="w-3.5 h-3.5 text-zinc-400" />;
    }
  };

  return (
    <div className="space-y-6" id="calendar-scheduler-view">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-xl bg-studio-surface border border-studio-border shadow-xs">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 text-xs font-bold rounded bg-studio-blue/10 text-studio-blue border border-studio-blue/20">
              CORE 2.0
            </span>
            <h2 className="text-xl font-bold text-studio-text flex items-center gap-2">
              <CalendarIcon className="w-5 h-5 text-studio-blue" />
              Content Calendar & Multi-Platform Scheduler
            </h2>
          </div>
          <p className="text-sm text-studio-text-muted">
            Planejamento visual de lançamentos, horários de pico e distribuição multicanal.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-studio-panel border border-studio-border rounded-lg p-1">
            <Button size="sm" variant="ghost" onClick={handlePrevMonth} className="h-7 w-7 p-0 text-studio-text-muted hover:text-studio-text">
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <span className="text-xs font-bold text-studio-text px-2 font-display">
              {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
            </span>
            <Button size="sm" variant="ghost" onClick={handleNextMonth} className="h-7 w-7 p-0 text-studio-text-muted hover:text-studio-text">
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>

          <Button
            id="btn-schedule-new-content"
            onClick={handleOpenNewSchedule}
            className="bg-studio-blue hover:bg-studio-blue-dim text-white text-xs font-semibold gap-1.5 shadow-sm shadow-blue-500/20"
          >
            <Plus className="w-4 h-4" />
            Agendar Novo Conteúdo
          </Button>
        </div>
      </div>

      {/* Calendar Grid */}
      <div className="p-5 rounded-xl bg-studio-surface border border-studio-border shadow-xs space-y-4">
        {/* Days of Week */}
        <div className="grid grid-cols-7 gap-2 text-center text-xs font-semibold text-studio-text-muted pb-2 border-b border-studio-border">
          <div>Dom</div>
          <div>Seg</div>
          <div>Ter</div>
          <div>Qua</div>
          <div>Qui</div>
          <div>Sex</div>
          <div>Sáb</div>
        </div>

        {/* Days Cells */}
        <div className="grid grid-cols-7 gap-2">
          {/* Empty cells before month start */}
          {Array.from({ length: firstDayIndex }).map((_, i) => (
            <div key={`empty-${i}`} className="min-h-[100px] rounded-lg bg-studio-panel/40 border border-studio-border/50 p-1.5 opacity-40" />
          ))}

          {/* Days */}
          {Array.from({ length: daysInMonth }).map((_, i) => {
            const dayNum = i + 1;
            const dateStr = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, "0")}-${String(dayNum).padStart(2, "0")}`;
            const dayJobs = jobs.filter((j) => {
              const targetDate = (j.scheduledAt || j.publishedAt || j.createdAt).slice(0, 10);
              return targetDate === dateStr;
            });

            const isToday =
              new Date().toISOString().slice(0, 10) === dateStr;

            return (
              <div
                key={dayNum}
                className={`min-h-[110px] rounded-xl border p-2 flex flex-col justify-between transition-all ${
                  isToday
                    ? "bg-blue-50/60 border-studio-blue shadow-xs"
                    : "bg-studio-panel/60 border-studio-border hover:border-studio-blue/40"
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span
                    className={`text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center ${
                      isToday ? "bg-studio-blue text-white" : "text-studio-text-dim"
                    }`}
                  >
                    {dayNum}
                  </span>
                  {dayJobs.length > 0 && (
                    <span className="text-[10px] text-studio-blue font-bold">
                      {dayJobs.length} post{dayJobs.length > 1 ? "s" : ""}
                    </span>
                  )}
                </div>

                {/* Day Jobs List */}
                <div className="space-y-1.5 overflow-y-auto max-h-[80px]">
                  {dayJobs.map((job) => (
                    <button
                      key={job.id}
                      onClick={() => setSelectedJob(job)}
                      className="w-full p-1.5 rounded bg-white border border-studio-border text-left hover:border-studio-blue/50 transition-colors flex items-center gap-1.5 shadow-xs"
                    >
                      {getPlatformIcon(job.platform)}
                      <span className="text-[10px] text-studio-text font-medium truncate flex-1">
                        {job.metadata.title}
                      </span>
                      <span className={`w-1.5 h-1.5 rounded-full ${
                        job.status === "PUBLISHED" ? "bg-emerald-500" :
                        job.status === "SCHEDULED" ? "bg-studio-blue" : "bg-slate-400"
                      }`} />
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Job Details Modal / Drawer */}
      {selectedJob && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
          <div className="w-full max-w-md bg-studio-surface border border-studio-border rounded-2xl p-5 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-studio-border pb-3">
              <div className="flex items-center gap-2">
                {getPlatformIcon(selectedJob.platform)}
                <span className="text-xs font-bold text-studio-text uppercase">{selectedJob.platform}</span>
                <span className={`px-2 py-0.5 text-[10px] font-bold rounded ${
                  selectedJob.status === "PUBLISHED" ? "bg-emerald-100 text-emerald-700" : "bg-blue-100 text-studio-blue"
                }`}>
                  {selectedJob.status}
                </span>
              </div>
              <button
                onClick={() => setSelectedJob(null)}
                className="text-studio-text-muted hover:text-studio-text text-xs"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div className="relative aspect-video rounded-lg overflow-hidden bg-studio-panel border border-studio-border">
                <img
                  src={selectedJob.metadata.thumbnailUrl}
                  alt="Thumbnail"
                  className="w-full h-full object-cover"
                />
              </div>

              <h4 className="text-sm font-bold text-studio-text">{selectedJob.metadata.title}</h4>
              <p className="text-xs text-studio-text-muted line-clamp-3 leading-relaxed">{selectedJob.metadata.description}</p>

              <div className="p-2.5 rounded-lg bg-studio-panel text-xs text-studio-text space-y-1 border border-studio-border">
                <div className="flex justify-between">
                  <span className="text-studio-text-muted">Canal:</span>
                  <strong className="text-studio-text">{selectedJob.channelName}</strong>
                </div>
                {selectedJob.scheduledAt && (
                  <div className="flex justify-between">
                    <span className="text-studio-text-muted">Agendado para:</span>
                    <strong className="text-studio-blue">{new Date(selectedJob.scheduledAt).toLocaleString("pt-BR")}</strong>
                  </div>
                )}
                {selectedJob.publishedAt && (
                  <div className="flex justify-between">
                    <span className="text-studio-text-muted">Publicado em:</span>
                    <strong className="text-emerald-600">{new Date(selectedJob.publishedAt).toLocaleString("pt-BR")}</strong>
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-studio-border">
              <Button
                size="sm"
                variant="ghost"
                onClick={() => handleDeleteJob(selectedJob.id)}
                className="text-red-500 hover:text-red-600 hover:bg-red-50 text-xs gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" /> Cancelar Post
              </Button>

              <Button
                size="sm"
                onClick={() => setSelectedJob(null)}
                className="bg-studio-blue hover:bg-studio-blue-dim text-white text-xs"
              >
                Fechar
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Pre-Publish Modal for Scheduling */}
      {selectedProjectToSchedule && (
        <PrePublishApprovalModal
          isOpen={approvalModalOpen}
          onClose={() => {
            setApprovalModalOpen(false);
            setSelectedProjectToSchedule(null);
            loadData();
          }}
          project={selectedProjectToSchedule}
          onSuccess={loadData}
        />
      )}
    </div>
  );
};
