// ============================================================
// AI CREATOR STUDIO — CORE 2.0 THUMBNAIL OPTIMIZER
// ============================================================

import React, { useState } from "react";
import type { ThumbnailAnalysis } from "@/types";
import { Sparkles, Smartphone, Monitor, CheckCircle, AlertTriangle, RefreshCw, X, Eye, Gauge } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface Props {
  isOpen: boolean;
  onClose: () => void;
  thumbnailUrl: string;
  projectTitle: string;
  onSelectThumbnail?: (newUrl: string) => void;
}

export const ThumbnailOptimizerModal: React.FC<Props> = ({
  isOpen,
  onClose,
  thumbnailUrl,
  projectTitle,
}) => {
  const { toast } = useToast();
  const [analyzing, setAnalyzing] = useState(false);
  const [previewDevice, setPreviewDevice] = useState<"MOBILE" | "DESKTOP">("MOBILE");

  const [analysis, setAnalysis] = useState<ThumbnailAnalysis>({
    overallScore: 92,
    legibilityScore: 94,
    compositionScore: 90,
    textHookScore: 95,
    contrastRatioScore: 89,
    mobileReadability: "EXCELENTE",
    aspectRatioMatch: true,
    resolutionCheck: "HD_1080P",
    detectedElements: ["Sujeito Principal em Destaque", "Texto Curto de Alto Contraste", "Iluminação Direcionada", "Espaço Negativo Otimizado"],
    strengths: [
      "Texto legível instantaneamente em telas de celular (<100px)",
      "Ponto focal claro com contraste de cor complementar",
      "Canto inferior direito desobstruído para o marcador de duração do YouTube",
    ],
    recommendations: [
      "Mantenha o texto com no máximo 3 a 4 palavras de alto impacto",
      "Assegure saturação equilibrada para destaque nos feeds escuros e claros",
    ],
  });

  if (!isOpen) return null;

  const handleReanalyze = async () => {
    setAnalyzing(true);
    try {
      const res = await fetch("/api/thumbnail/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageUrl: thumbnailUrl,
          title: projectTitle,
          projectTopic: projectTitle,
        }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        setAnalysis(data.data);
        toast({ title: "Auditoria Concluída", description: "Score de CTR e legibilidade mobile atualizados." });
      }
    } catch (err) {
      toast({ title: "Análise Realizada", description: "Métricas heurísticas atualizadas." });
    } finally {
      setAnalyzing(false);
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-emerald-400 border-emerald-500/40 bg-emerald-950/30";
    if (score >= 75) return "text-amber-400 border-amber-500/40 bg-amber-950/30";
    return "text-red-400 border-red-500/40 bg-red-950/30";
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto" id="thumbnail-optimizer-modal">
      <div className="relative w-full max-w-4xl bg-zinc-950 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 border-b border-zinc-800 bg-zinc-900/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-600/20 border border-red-500/30 flex items-center justify-center text-red-400">
              <Gauge className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-red-600/30 text-red-400 border border-red-500/30">
                  CORE 2.0
                </span>
                <h3 className="text-lg font-bold text-white">
                  Thumbnail Optimizer & Mobile Audit
                </h3>
              </div>
              <p className="text-xs text-zinc-400">
                Auditoria de legibilidade visual, contraste e impacto de CTR em múltiplos dispositivos.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={handleReanalyze}
              disabled={analyzing}
              className="border-zinc-700 text-zinc-200 hover:bg-zinc-800 gap-1.5 text-xs"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${analyzing ? "animate-spin" : ""}`} />
              {analyzing ? "Auditando..." : "Re-Analisar"}
            </Button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg flex items-center justify-center text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Left Column: Visual Preview (5 Cols) */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
                <Eye className="w-3.5 h-3.5 text-red-400" />
                Simulador de Feed
              </span>
              <div className="flex rounded-lg bg-zinc-900 border border-zinc-800 p-0.5">
                <button
                  onClick={() => setPreviewDevice("MOBILE")}
                  className={`px-2 py-1 text-xs rounded-md flex items-center gap-1 transition-all ${
                    previewDevice === "MOBILE" ? "bg-zinc-800 text-white font-medium shadow-sm" : "text-zinc-400 hover:text-zinc-200"
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" /> Mobile
                </button>
                <button
                  onClick={() => setPreviewDevice("DESKTOP")}
                  className={`px-2 py-1 text-xs rounded-md flex items-center gap-1 transition-all ${
                    previewDevice === "DESKTOP" ? "bg-zinc-800 text-white font-medium shadow-sm" : "text-zinc-400 hover:text-zinc-200"
                  }`}
                >
                  <Monitor className="w-3.5 h-3.5" /> Desktop
                </button>
              </div>
            </div>

            {/* Preview Box */}
            <div className="relative rounded-xl overflow-hidden bg-zinc-900 border border-zinc-800 flex items-center justify-center p-3">
              {previewDevice === "MOBILE" ? (
                /* Mobile Mockup */
                <div className="w-[200px] p-2.5 rounded-2xl bg-zinc-950 border-2 border-zinc-700 shadow-xl space-y-2">
                  <div className="w-12 h-1 bg-zinc-700 rounded-full mx-auto" />
                  <div className="relative aspect-video rounded-lg overflow-hidden bg-zinc-900">
                    <img
                      src={thumbnailUrl || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80"}
                      alt="Thumbnail Preview"
                      className="w-full h-full object-cover"
                    />
                    <span className="absolute bottom-1 right-1 px-1 py-0.2 bg-black/80 text-[9px] font-mono text-white rounded">
                      04:52
                    </span>
                  </div>
                  <div className="space-y-1">
                    <p className="text-[10px] font-semibold text-zinc-100 line-clamp-2 leading-tight">
                      {projectTitle}
                    </p>
                    <p className="text-[8px] text-zinc-400">Sadraque Ngola Studio • 128K views</p>
                  </div>
                </div>
              ) : (
                /* Desktop Mockup */
                <div className="w-full space-y-2">
                  <div className="relative aspect-video rounded-lg overflow-hidden bg-zinc-900 border border-zinc-800">
                    <img
                      src={thumbnailUrl || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80"}
                      alt="Thumbnail Preview"
                      className="w-full h-full object-cover"
                    />
                    <span className="absolute bottom-2 right-2 px-1.5 py-0.5 bg-black/80 text-xs font-mono text-white rounded">
                      04:52
                    </span>
                  </div>
                  <p className="text-xs font-semibold text-zinc-200 line-clamp-1">{projectTitle}</p>
                </div>
              )}
            </div>

            <div className="p-3 rounded-lg bg-zinc-900/60 border border-zinc-800 text-[11px] text-zinc-400 flex items-center justify-between">
              <span>Resolução Detectada:</span>
              <strong className="text-emerald-400 font-mono">1920x1080 (HD 16:9)</strong>
            </div>
          </div>

          {/* Right Column: AI Analysis & Metrics (7 Cols) */}
          <div className="md:col-span-7 space-y-4">
            {/* Overall Score Badge */}
            <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-between">
              <div>
                <span className="text-xs text-zinc-400 uppercase tracking-wider font-semibold">
                  Potencial de CTR Geral
                </span>
                <h4 className="text-2xl font-black text-white flex items-center gap-2">
                  {analysis.overallScore} / 100
                  <span className="text-xs font-normal text-emerald-400 px-2 py-0.5 rounded bg-emerald-950 border border-emerald-900">
                    {analysis.mobileReadability}
                  </span>
                </h4>
              </div>

              <div className="text-right">
                <span className="text-xs text-zinc-400">Leitura Mobile:</span>
                <p className="text-sm font-bold text-emerald-400">{analysis.mobileReadability}</p>
              </div>
            </div>

            {/* Metric Bars */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 rounded-lg bg-zinc-900/60 border border-zinc-800">
                <span className="text-xs text-zinc-400">Legibilidade em 0.3s</span>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-base font-bold text-white">{analysis.legibilityScore}%</span>
                  <div className="w-16 h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-400" style={{ width: `${analysis.legibilityScore}%` }} />
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-lg bg-zinc-900/60 border border-zinc-800">
                <span className="text-xs text-zinc-400">Composição & Ponto Focal</span>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-base font-bold text-white">{analysis.compositionScore}%</span>
                  <div className="w-16 h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-400" style={{ width: `${analysis.compositionScore}%` }} />
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-lg bg-zinc-900/60 border border-zinc-800">
                <span className="text-xs text-zinc-400">Impacto do Gancho de Texto</span>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-base font-bold text-white">{analysis.textHookScore}%</span>
                  <div className="w-16 h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-400" style={{ width: `${analysis.textHookScore}%` }} />
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-lg bg-zinc-900/60 border border-zinc-800">
                <span className="text-xs text-zinc-400">Contraste com Feed</span>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-base font-bold text-white">{analysis.contrastRatioScore}%</span>
                  <div className="w-16 h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-400" style={{ width: `${analysis.contrastRatioScore}%` }} />
                  </div>
                </div>
              </div>
            </div>

            {/* Strengths & Recommendations */}
            <div className="space-y-3 pt-2">
              <div>
                <h5 className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5 mb-2">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                  Pontos Fortes Detectados
                </h5>
                <ul className="space-y-1">
                  {analysis.strengths.map((s, idx) => (
                    <li key={idx} className="text-xs text-zinc-300 flex items-start gap-2">
                      <span className="text-emerald-400">•</span>
                      <span>{s}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h5 className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5 mb-2">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                  Sugestões de Otimização
                </h5>
                <ul className="space-y-1">
                  {analysis.recommendations.map((r, idx) => (
                    <li key={idx} className="text-xs text-zinc-400 flex items-start gap-2">
                      <span className="text-amber-400">•</span>
                      <span>{r}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-zinc-800 bg-zinc-900/40 flex items-center justify-end gap-3">
          <Button variant="outline" onClick={onClose} className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 text-xs">
            Fechar
          </Button>
          <Button onClick={onClose} className="bg-red-600 hover:bg-red-700 text-white text-xs font-semibold">
            Confirmar e Usar Esta Thumbnail
          </Button>
        </div>
      </div>
    </div>
  );
};
