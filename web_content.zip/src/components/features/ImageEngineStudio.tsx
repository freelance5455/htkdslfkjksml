import { useState, useEffect } from "react";
import {
  IMAGE_ENGINES,
  IMAGE_VISUAL_STYLES,
  IMAGE_LENSES,
  IMAGE_LIGHTING_SETUPS,
  IMAGE_ASPECT_RATIOS,
} from "@/constants/imageEngines";
import type {
  ImageEngineId,
  ImageAspectRatio,
  ImageResolution,
  ImageCameraLens,
  ImageLightingSetup,
  ImageVisualStyle,
  ImageGenerationResult,
} from "@/types/image";
import type { Project, StoryboardScene } from "@/types";
import { optimizeImagePrompt, generateImageWithEngine, generateBatchStoryboardImages } from "@/lib/imageEngine";
import { cn } from "@/lib/utils";
import {
  Sparkles, Image as ImageIcon, Camera, Sliders, CheckCircle2,
  Download, Eye, RefreshCw, Layers, ZoomIn, ArrowRight,
  Sun, Aperture, Palette, LayoutGrid, Maximize2
} from "lucide-react";
import { UniversalMediaModal } from "@/components/common/UniversalMediaModal";

interface ImageEngineStudioProps {
  project?: Project;
  onProjectUpdate?: (updated: Project) => void;
  initialScene?: StoryboardScene;
  onSelectImageForScene?: (sceneId: string, imageUrl: string) => void;
}

export default function ImageEngineStudio({
  project,
  onProjectUpdate,
  initialScene,
  onSelectImageForScene,
}: ImageEngineStudioProps) {
  // Engine Selection
  const [selectedEngineId, setSelectedEngineId] = useState<ImageEngineId>("imagen-3");
  const selectedEngine = IMAGE_ENGINES.find((e) => e.id === selectedEngineId) || IMAGE_ENGINES[0];

  // Parameters
  const [rawPrompt, setRawPrompt] = useState(
    initialScene?.imagePrompt || initialScene?.visualDescription || "Um criador de conteúdo moderno no estúdio com iluminação neon ciano e roxa, gravando um vídeo com câmera profissional."
  );
  const [negativePrompt, setNegativePrompt] = useState("blurry, low quality, distorted anatomy, extra limbs, bad lighting, watermark, grainy, text artifacts");
  const [visualStyle, setVisualStyle] = useState<ImageVisualStyle>("CINEMATIC");
  const [lens, setLens] = useState<ImageCameraLens>("35MM_CINEMA");
  const [lighting, setLighting] = useState<ImageLightingSetup>("GOLDEN_HOUR");
  const [aspectRatio, setAspectRatio] = useState<ImageAspectRatio>(selectedEngine.defaultAspectRatio);
  const [resolution, setResolution] = useState<ImageResolution>("1080p");
  const [guidanceScale, setGuidanceScale] = useState<number>(7.5);
  const [samplingSteps, setSamplingSteps] = useState<number>(30);
  const [selectedSceneId, setSelectedSceneId] = useState<string>(initialScene?.id || (project?.storyboard?.scenes[0]?.id ?? ""));
  const [isThumbnailMode, setIsThumbnailMode] = useState(false);

  // AI Prompt Optimization State
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [optimizedDetails, setOptimizedDetails] = useState<{
    prompt?: string;
    negativePrompt?: string;
    photographyDirectives?: string;
    lightingSetup?: string;
    engineSpecificKeywords?: string[];
  } | null>(null);

  // Image Generation State
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentImage, setCurrentImage] = useState<ImageGenerationResult | null>(null);
  const [recentImages, setRecentImages] = useState<ImageGenerationResult[]>([]);

  // Batch Generation State
  const [isBatchGenerating, setIsBatchGenerating] = useState(false);
  const [batchStatus, setBatchStatus] = useState<{ current: number; total: number; sceneNumber: number } | null>(null);
  const [copiedNotification, setCopiedNotification] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Sync selected scene prompt
  useEffect(() => {
    if (selectedSceneId && project?.storyboard?.scenes) {
      const found = project.storyboard.scenes.find((s) => s.id === selectedSceneId);
      if (found) {
        if (found.imagePrompt || found.visualDescription) {
          setRawPrompt(found.imagePrompt || found.visualDescription);
        }
      }
    }
  }, [selectedSceneId, project]);

  // Handler: Optimize Prompt with AI
  const handleOptimizePrompt = async () => {
    if (!rawPrompt.trim()) return;
    setIsOptimizing(true);
    try {
      const result = await optimizeImagePrompt({
        rawPrompt,
        engine: selectedEngineId,
        style: visualStyle,
        lens,
        lighting,
        aspectRatio,
      });
      setOptimizedDetails(result);
      if (result.negativePrompt) {
        setNegativePrompt(result.negativePrompt);
      }
    } catch (err) {
      console.error("Falha ao otimizar prompt de imagem:", err);
    } finally {
      setIsOptimizing(false);
    }
  };

  // Handler: Generate Single Image
  const handleGenerateImage = async () => {
    if (!rawPrompt.trim()) return;
    setIsGenerating(true);
    try {
      const finalPrompt = optimizedDetails?.prompt || rawPrompt;
      const result = await generateImageWithEngine({
        prompt: rawPrompt,
        optimizedPrompt: finalPrompt,
        negativePrompt,
        engine: selectedEngineId,
        aspectRatio,
        resolution,
        style: visualStyle,
        lens,
        lighting,
        guidanceScale,
        samplingSteps,
        sceneId: selectedSceneId || undefined,
        projectId: project?.id,
        projectTitle: project?.title,
        isThumbnail: isThumbnailMode,
      });

      setCurrentImage(result);
      setRecentImages((prev) => [result, ...prev.slice(0, 7)]);

      // Auto update storyboard scene if scene selected
      if (selectedSceneId && project && onProjectUpdate) {
        const updatedScenes = project.storyboard?.scenes.map((sc) =>
          sc.id === selectedSceneId ? { ...sc, imageUrl: result.imageUrl } : sc
        );
        if (updatedScenes && project.storyboard) {
          onProjectUpdate({
            ...project,
            storyboard: {
              ...project.storyboard,
              scenes: updatedScenes,
            },
          });
        }
        if (onSelectImageForScene) {
          onSelectImageForScene(selectedSceneId, result.imageUrl);
        }
      }
    } catch (err) {
      console.error("Erro na geração de imagem:", err);
    } finally {
      setIsGenerating(false);
    }
  };

  // Handler: Batch Generate All Storyboard Scenes
  const handleBatchGenerate = async () => {
    if (!project?.storyboard?.scenes || project.storyboard.scenes.length === 0) return;
    setIsBatchGenerating(true);
    try {
      const results = await generateBatchStoryboardImages(
        project.storyboard.scenes,
        {
          engine: selectedEngineId,
          aspectRatio,
          resolution,
          style: visualStyle,
          lens,
          lighting,
          projectId: project.id,
          projectTitle: project.title,
        },
        (current, total, sceneNumber) => {
          setBatchStatus({ current, total, sceneNumber });
        }
      );

      if (onProjectUpdate && project.storyboard) {
        const sceneMap = new Map(results.map((r) => [r.sceneId, r.imageUrl]));
        const updatedScenes = project.storyboard.scenes.map((sc) => ({
          ...sc,
          imageUrl: sceneMap.get(sc.id) || sc.imageUrl,
        }));
        onProjectUpdate({
          ...project,
          storyboard: {
            ...project.storyboard,
            scenes: updatedScenes,
          },
        });
      }
      if (results[0]) {
        setCurrentImage(results[0]);
      }
    } catch (err) {
      console.error("Erro na geração em lote:", err);
    } finally {
      setIsBatchGenerating(false);
      setBatchStatus(null);
    }
  };

  const handleApplyToScene = (sceneId: string, imgUrl: string) => {
    if (project && project.storyboard && onProjectUpdate) {
      const updatedScenes = project.storyboard.scenes.map((sc) =>
        sc.id === sceneId ? { ...sc, imageUrl: imgUrl } : sc
      );
      onProjectUpdate({
        ...project,
        storyboard: {
          ...project.storyboard,
          scenes: updatedScenes,
        },
      });
      setCopiedNotification(`Imagem atribuída à Cena #${project.storyboard.scenes.find(s => s.id === sceneId)?.sceneNumber}`);
      setTimeout(() => setCopiedNotification(null), 3000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner: Notification */}
      {copiedNotification && (
        <div className="bg-studio-green/10 border border-studio-green/30 text-studio-green px-4 py-2.5 rounded-lg flex items-center gap-2 text-xs animate-in fade-in">
          <CheckCircle2 className="w-4 h-4" />
          <span>{copiedNotification}</span>
        </div>
      )}

      {/* Header Info */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-studio-surface border border-studio-border p-4 rounded-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-studio-blue/10 border border-studio-blue/20 flex items-center justify-center text-studio-blue">
            <ImageIcon className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-semibold text-studio-text flex items-center gap-2">
              Motor de Geração de Imagem & Conceito Visual
              <span className="text-xs px-2 py-0.5 rounded-full bg-studio-blue/10 text-studio-blue border border-studio-blue/20 font-normal">
                {selectedEngine.name}
              </span>
            </h2>
            <p className="text-xs text-studio-text-muted">
              Crie capas, thumbnails e artes conceituais para cada cena do seu projeto com controle fotográfico de lente e iluminação.
            </p>
          </div>
        </div>

        {/* Batch Storyboard Action */}
        {project?.storyboard?.scenes && project.storyboard.scenes.length > 0 && (
          <button
            onClick={handleBatchGenerate}
            disabled={isBatchGenerating || isGenerating}
            className="btn-secondary text-xs py-2 px-3 gap-1.5 shrink-0 border-studio-border hover:border-studio-blue/50 text-studio-text"
          >
            {isBatchGenerating ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-studio-blue" />
                <span>Gerando ({batchStatus?.current}/{batchStatus?.total})...</span>
              </>
            ) : (
              <>
                <Layers className="w-3.5 h-3.5 text-studio-blue" />
                <span>Gerar Todas as {project.storyboard.scenes.length} Cenas em Lote</span>
              </>
            )}
          </button>
        )}
      </div>

      {/* Engine Selector Cards */}
      <div>
        <label className="text-xs font-semibold text-studio-text-muted uppercase tracking-wider block mb-2">
          Selecione o Motor de Imagem
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
          {IMAGE_ENGINES.map((engine) => {
            const isSelected = selectedEngineId === engine.id;
            return (
              <button
                key={engine.id}
                onClick={() => {
                  setSelectedEngineId(engine.id);
                  if (!engine.aspectRatios.includes(aspectRatio)) {
                    setAspectRatio(engine.defaultAspectRatio);
                  }
                }}
                className={cn(
                  "p-3 rounded-xl border text-left transition-all relative flex flex-col justify-between h-28",
                  isSelected
                    ? "bg-studio-surface border-studio-blue shadow-sm ring-1 ring-studio-blue"
                    : "bg-studio-surface/60 border-studio-border hover:border-studio-border-hover hover:bg-studio-surface"
                )}
              >
                <div>
                  <div className="flex items-center justify-between gap-1 mb-1">
                    <span className="text-xs font-semibold text-studio-text truncate">{engine.name}</span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-studio-panel border border-studio-border text-studio-text-muted">
                      {engine.qualityTier}
                    </span>
                  </div>
                  <span className="text-[10px] text-studio-text-dim block leading-tight">{engine.provider}</span>
                </div>

                <div className="mt-2">
                  <span
                    className="text-[10px] font-medium px-1.5 py-0.5 rounded block truncate"
                    style={{ backgroundColor: `${engine.color}15`, color: engine.color }}
                  >
                    {engine.badge}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Studio Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Prompt & Controls */}
        <div className="lg:col-span-6 space-y-4">
          {/* Scene selector & Thumbnail switch */}
          <div className="flex items-center justify-between gap-2 bg-studio-surface border border-studio-border p-2.5 rounded-lg">
            <div className="flex items-center gap-2 flex-1 min-w-0">
              <span className="text-xs text-studio-text-muted shrink-0">Alvo:</span>
              <select
                value={selectedSceneId}
                onChange={(e) => setSelectedSceneId(e.target.value)}
                className="bg-studio-panel border border-studio-border rounded-md px-2 py-1 text-xs text-studio-text focus:outline-none focus:border-studio-blue flex-1 truncate"
              >
                <option value="">Geração Livre / Thumbnail</option>
                {project?.storyboard?.scenes?.map((sc) => (
                  <option key={sc.id} value={sc.id}>
                    Cena #{sc.sceneNumber}: {sc.visualDescription.substring(0, 35)}...
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={() => setIsThumbnailMode(!isThumbnailMode)}
              className={cn(
                "text-xs px-2.5 py-1 rounded-md transition-all font-medium",
                isThumbnailMode
                  ? "bg-studio-blue text-white"
                  : "bg-studio-panel text-studio-text-muted hover:text-studio-text"
              )}
            >
              Modo Thumbnail
            </button>
          </div>

          {/* Prompt Box */}
          <div className="bg-studio-surface border border-studio-border rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-studio-text flex items-center gap-1.5">
                <Camera className="w-3.5 h-3.5 text-studio-blue" />
                Prompt Visual
              </label>
              <button
                onClick={handleOptimizePrompt}
                disabled={isOptimizing || !rawPrompt.trim()}
                className="text-xs flex items-center gap-1 text-studio-blue hover:text-studio-blue/80 transition-colors font-medium"
              >
                <Sparkles className={cn("w-3 h-3", isOptimizing && "animate-spin")} />
                {isOptimizing ? "Otimizando com IA..." : "Otimizar Prompt (Gemini)"}
              </button>
            </div>

            <textarea
              value={rawPrompt}
              onChange={(e) => setRawPrompt(e.target.value)}
              rows={3}
              placeholder="Descreva detalhadamente o sujeito, cenário, materiais, cores e ambiente..."
              className="w-full bg-studio-panel border border-studio-border rounded-lg p-3 text-xs text-studio-text focus:outline-none focus:border-studio-blue resize-none placeholder:text-studio-text-dim"
            />

            {/* AI Optimized Preview */}
            {optimizedDetails && (
              <div className="p-3 rounded-lg bg-studio-panel/70 border border-studio-blue/20 text-xs space-y-1.5 animate-in fade-in">
                <div className="flex items-center justify-between text-studio-blue font-semibold">
                  <span className="flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> Prompt Expandido Fotográfico
                  </span>
                  <button
                    onClick={() => setRawPrompt(optimizedDetails.prompt || rawPrompt)}
                    className="text-[10px] underline hover:text-studio-blue/80"
                  >
                    Usar no campo
                  </button>
                </div>
                <p className="text-studio-text-muted text-[11px] leading-relaxed italic">
                  "{optimizedDetails.prompt}"
                </p>
                {optimizedDetails.photographyDirectives && (
                  <div className="text-[10px] text-studio-text-dim border-t border-studio-border pt-1">
                    <strong>Fotografia:</strong> {optimizedDetails.photographyDirectives}
                  </div>
                )}
              </div>
            )}

            {/* Negative Prompt */}
            {selectedEngine.supportsNegativePrompt && (
              <div>
                <label className="text-[11px] font-medium text-studio-text-muted block mb-1">
                  Prompt Negativo (O que evitar)
                </label>
                <input
                  type="text"
                  value={negativePrompt}
                  onChange={(e) => setNegativePrompt(e.target.value)}
                  className="w-full bg-studio-panel border border-studio-border rounded-lg px-3 py-1.5 text-xs text-studio-text focus:outline-none focus:border-studio-blue placeholder:text-studio-text-dim"
                />
              </div>
            )}
          </div>

          {/* Visual Style & Camera Lens */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Visual Style */}
            <div className="bg-studio-surface border border-studio-border rounded-xl p-3 space-y-1.5">
              <label className="text-xs font-semibold text-studio-text flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5 text-studio-purple" />
                Estilo Visual
              </label>
              <select
                value={visualStyle}
                onChange={(e) => setVisualStyle(e.target.value as ImageVisualStyle)}
                className="w-full bg-studio-panel border border-studio-border rounded-lg px-2.5 py-1.5 text-xs text-studio-text focus:outline-none focus:border-studio-blue"
              >
                {IMAGE_VISUAL_STYLES.map((st) => (
                  <option key={st.id} value={st.id}>
                    {st.label}
                  </option>
                ))}
              </select>
              <p className="text-[10px] text-studio-text-dim truncate">
                {IMAGE_VISUAL_STYLES.find((s) => s.id === visualStyle)?.description}
              </p>
            </div>

            {/* Camera Lens */}
            <div className="bg-studio-surface border border-studio-border rounded-xl p-3 space-y-1.5">
              <label className="text-xs font-semibold text-studio-text flex items-center gap-1.5">
                <Aperture className="w-3.5 h-3.5 text-studio-green" />
                Lente & Distância Focal
              </label>
              <select
                value={lens}
                onChange={(e) => setLens(e.target.value as ImageCameraLens)}
                className="w-full bg-studio-panel border border-studio-border rounded-lg px-2.5 py-1.5 text-xs text-studio-text focus:outline-none focus:border-studio-blue"
              >
                {IMAGE_LENSES.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.label}
                  </option>
                ))}
              </select>
              <p className="text-[10px] text-studio-text-dim truncate">
                {IMAGE_LENSES.find((l) => l.id === lens)?.bestFor}
              </p>
            </div>
          </div>

          {/* Lighting & Aspect Ratio */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Lighting */}
            <div className="bg-studio-surface border border-studio-border rounded-xl p-3 space-y-1.5">
              <label className="text-xs font-semibold text-studio-text flex items-center gap-1.5">
                <Sun className="w-3.5 h-3.5 text-studio-amber" />
                Iluminação
              </label>
              <select
                value={lighting}
                onChange={(e) => setLighting(e.target.value as ImageLightingSetup)}
                className="w-full bg-studio-panel border border-studio-border rounded-lg px-2.5 py-1.5 text-xs text-studio-text focus:outline-none focus:border-studio-blue"
              >
                {IMAGE_LIGHTING_SETUPS.map((li) => (
                  <option key={li.id} value={li.id}>
                    {li.label}
                  </option>
                ))}
              </select>
              <p className="text-[10px] text-studio-text-dim truncate">
                {IMAGE_LIGHTING_SETUPS.find((li) => li.id === lighting)?.desc}
              </p>
            </div>

            {/* Aspect Ratio */}
            <div className="bg-studio-surface border border-studio-border rounded-xl p-3 space-y-1.5">
              <label className="text-xs font-semibold text-studio-text flex items-center gap-1.5">
                <LayoutGrid className="w-3.5 h-3.5 text-studio-blue" />
                Formato / Proporção
              </label>
              <select
                value={aspectRatio}
                onChange={(e) => setAspectRatio(e.target.value as ImageAspectRatio)}
                className="w-full bg-studio-panel border border-studio-border rounded-lg px-2.5 py-1.5 text-xs text-studio-text focus:outline-none focus:border-studio-blue"
              >
                {IMAGE_ASPECT_RATIOS.filter((ar) => selectedEngine.aspectRatios.includes(ar.id)).map((ar) => (
                  <option key={ar.id} value={ar.id}>
                    {ar.label} ({ar.useCase})
                  </option>
                ))}
              </select>
              <div className="flex gap-2">
                {(["1080p", "2K", "4K"] as ImageResolution[]).map((res) => (
                  <button
                    key={res}
                    onClick={() => setResolution(res)}
                    className={cn(
                      "text-[10px] px-2 py-0.5 rounded border transition-all flex-1 text-center font-medium",
                      resolution === res
                        ? "bg-studio-blue/15 border-studio-blue text-studio-blue"
                        : "bg-studio-panel border-studio-border text-studio-text-muted hover:text-studio-text"
                    )}
                  >
                    {res}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Advanced Sliders */}
          <div className="bg-studio-surface border border-studio-border rounded-xl p-3.5 space-y-3">
            <div className="flex items-center justify-between text-xs font-semibold text-studio-text">
              <span className="flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-studio-text-muted" />
                Parâmetros Avançados
              </span>
              <span className="text-[10px] text-studio-text-dim font-normal">
                CFG: {guidanceScale} · Steps: {samplingSteps}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="flex justify-between text-[11px] text-studio-text-muted mb-1">
                  <span>Guidance Scale (CFG)</span>
                  <span>{guidanceScale}</span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={20}
                  step={0.5}
                  value={guidanceScale}
                  onChange={(e) => setGuidanceScale(parseFloat(e.target.value))}
                  className="w-full accent-studio-blue h-1.5 bg-studio-panel rounded-lg appearance-none cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px] text-studio-text-muted mb-1">
                  <span>Sampling Steps</span>
                  <span>{samplingSteps}</span>
                </div>
                <input
                  type="range"
                  min={15}
                  max={60}
                  step={1}
                  value={samplingSteps}
                  onChange={(e) => setSamplingSteps(parseInt(e.target.value))}
                  className="w-full accent-studio-blue h-1.5 bg-studio-panel rounded-lg appearance-none cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Generate Button */}
          <button
            onClick={handleGenerateImage}
            disabled={isGenerating || !rawPrompt.trim()}
            className="btn-primary w-full py-3 text-sm font-semibold justify-center gap-2 shadow-lg shadow-studio-blue/10"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Renderizando com {selectedEngine.name}...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Gerar Imagem ({selectedEngine.name})</span>
              </>
            )}
          </button>
        </div>

        {/* Right Column: Canvas & Gallery */}
        <div className="lg:col-span-6 space-y-4">
          {/* Main Visual Canvas */}
          <div className="bg-studio-surface border border-studio-border rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-studio-text flex items-center gap-1.5">
                <Eye className="w-3.5 h-3.5 text-studio-blue" />
                Canvas de Pré-visualização HD
              </span>
              {currentImage && (
                <span className="text-[10px] px-2 py-0.5 rounded bg-studio-green/10 text-studio-green border border-studio-green/20 font-medium">
                  ✓ {currentImage.resolution} · {currentImage.aspectRatio}
                </span>
              )}
            </div>

            <div className="relative aspect-video w-full bg-studio-panel rounded-lg overflow-hidden border border-studio-border flex items-center justify-center group">
              {currentImage ? (
                <>
                  <img
                    src={currentImage.imageUrl}
                    alt={currentImage.prompt}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20 opacity-0 group-hover:opacity-100 transition-opacity p-4 flex flex-col justify-between">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] bg-black/60 backdrop-blur-sm text-white px-2 py-0.5 rounded">
                        {currentImage.engineName}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => setIsModalOpen(true)}
                          className="p-1.5 bg-black/60 backdrop-blur-sm rounded text-white hover:bg-studio-blue transition-colors"
                          title="Ampliar Imagem em Alta Resolução"
                        >
                          <ZoomIn className="w-4 h-4" />
                        </button>
                        <a
                          href={currentImage.imageUrl}
                          download={`studio_${currentImage.id}.jpg`}
                          target="_blank"
                          rel="noreferrer"
                          className="p-1.5 bg-black/60 backdrop-blur-sm rounded text-white hover:bg-studio-blue transition-colors"
                          title="Baixar JPG"
                        >
                          <Download className="w-4 h-4" />
                        </a>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <p className="text-xs text-white font-medium line-clamp-2">{currentImage.prompt}</p>
                      <div className="flex gap-2">
                        {project?.storyboard?.scenes && (
                          <select
                            onChange={(e) => {
                              if (e.target.value) {
                                handleApplyToScene(e.target.value, currentImage.imageUrl);
                              }
                            }}
                            className="bg-black/80 border border-white/20 text-white rounded text-[10px] px-2 py-1"
                            defaultValue=""
                          >
                            <option value="" disabled>
                              Atribuir à Cena...
                            </option>
                            {project.storyboard.scenes.map((sc) => (
                              <option key={sc.id} value={sc.id}>
                                Cena #{sc.sceneNumber}
                              </option>
                            ))}
                          </select>
                        )}
                      </div>
                    </div>
                  </div>
                </>
              ) : (
                <div className="text-center p-6 space-y-2">
                  <div className="w-12 h-12 rounded-full bg-studio-panel border border-studio-border flex items-center justify-center mx-auto text-studio-text-dim">
                    <ImageIcon className="w-6 h-6" />
                  </div>
                  <p className="text-xs text-studio-text-muted">
                    Nenhuma imagem gerada nesta sessão.
                  </p>
                  <p className="text-[11px] text-studio-text-dim max-w-xs mx-auto">
                    Ajuste os parâmetros à esquerda e clique em <strong>Gerar Imagem</strong> para renderizar.
                  </p>
                </div>
              )}
            </div>

            {/* Metadata tags */}
            {currentImage?.metadata && (
              <div className="flex flex-wrap items-center gap-1.5 pt-1 text-[10px] text-studio-text-dim">
                <span className="px-2 py-0.5 bg-studio-panel rounded border border-studio-border">
                  Motor: {currentImage.metadata.renderEngine}
                </span>
                <span className="px-2 py-0.5 bg-studio-panel rounded border border-studio-border">
                  Render: {currentImage.metadata.renderTimeSec}s
                </span>
                <span className="px-2 py-0.5 bg-studio-panel rounded border border-studio-border">
                  Seed: {currentImage.metadata.seed}
                </span>
              </div>
            )}
          </div>

            {/* Gallery of Recent Generations */}
          {recentImages.length > 0 && (
            <div className="bg-studio-surface border border-studio-border rounded-xl p-4 space-y-3">
              <span className="text-xs font-semibold text-studio-text flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-studio-purple" />
                Histórico Recente da Sessão ({recentImages.length})
              </span>

              <div className="grid grid-cols-4 gap-2">
                {recentImages.map((img) => (
                  <button
                    key={img.id}
                    onClick={() => setCurrentImage(img)}
                    className={cn(
                      "aspect-video rounded-lg overflow-hidden border relative group",
                      currentImage?.id === img.id
                        ? "border-studio-blue ring-2 ring-studio-blue/40"
                        : "border-studio-border hover:border-studio-border-hover"
                    )}
                  >
                    <img
                      src={img.imageUrl}
                      alt={img.prompt}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                      <ZoomIn className="w-4 h-4" />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Universal Media Modal */}
      {currentImage && (
        <UniversalMediaModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          mediaUrl={currentImage.imageUrl}
          mediaType="IMAGE"
          title={`${currentImage.engineName} — Imagem Gerada`}
          prompt={currentImage.prompt}
        />
      )}
    </div>
  );
}
