// ============================================================
// AI CREATOR STUDIO — CORE 3.0 SERIES MANAGER VIEW
// Multi-episode arcs, character consistency, next-episode scheduling
// ============================================================

import { useState } from "react";
import {
  Film, Sparkles, Plus, Play, Calendar, CheckCircle2,
  Clock, ArrowRight, ChevronRight, Users, Heart
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { ContentSeries } from "@/types/core3";
import { getStoredSeries, createNextEpisodeWorkflow } from "@/lib/core3/seriesManager";

interface SeriesManagerViewProps {
  onProduceEpisode?: (seriesId: string) => void;
}

export default function SeriesManagerView({ onProduceEpisode }: SeriesManagerViewProps) {
  const [seriesList] = useState<ContentSeries[]>(getStoredSeries());
  const [selectedSeries, setSelectedSeries] = useState<ContentSeries>(seriesList[0] || getStoredSeries()[0]);

  const handleProduceNext = (series: ContentSeries) => {
    createNextEpisodeWorkflow(series.id);
    if (onProduceEpisode) {
      onProduceEpisode(series.id);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="studio-card p-6 border border-studio-border bg-gradient-to-r from-studio-surface to-studio-panel">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <span className="text-[10px] uppercase font-mono tracking-widest text-studio-purple font-bold">
              Gestão de Séries Narrativas
            </span>
            <h2 className="text-xl font-bold text-studio-text font-display mt-1">
              Séries & Arcos Multi-Episódio
            </h2>
            <p className="text-xs text-studio-text-muted mt-0.5">
              Consistência de personagens, universo visual coeso e ganchos narrativos entre episódios.
            </p>
          </div>
        </div>
      </div>

      {/* Series Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Series List */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-studio-text uppercase tracking-wider">
            Séries Ativas ({seriesList.length})
          </h3>
          {seriesList.map((series) => {
            const isSelected = selectedSeries?.id === series.id;
            return (
              <div
                key={series.id}
                onClick={() => setSelectedSeries(series)}
                className={cn(
                  "p-4 rounded-xl cursor-pointer transition-all border",
                  isSelected
                    ? "bg-studio-panel border-studio-purple/50 shadow-md shadow-studio-purple/5"
                    : "bg-studio-surface border-studio-border hover:border-studio-border/80"
                )}
              >
                <div className="flex items-center justify-between mb-1">
                  <h4 className="text-sm font-bold text-studio-text">{series.title}</h4>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-studio-purple/20 text-studio-purple font-bold">
                    {series.episodeCount} EPs
                  </span>
                </div>
                <p className="text-xs text-studio-text-muted line-clamp-2 mb-3">{series.description}</p>
                <div className="flex items-center justify-between text-xs text-studio-text-dim">
                  <span>{series.publishedEpisodesCount} publicados</span>
                  <span className="text-studio-green font-semibold">94% coerência</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right: Selected Series Details & Episodes Timeline */}
        {selectedSeries && (
          <div className="lg:col-span-2 studio-card p-5 space-y-6">
            {/* Top Details */}
            <div className="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-studio-border">
              <div>
                <span className="text-[10px] uppercase font-bold text-studio-purple">
                  Público: {selectedSeries.targetAudience}
                </span>
                <h3 className="text-lg font-bold text-studio-text font-display">{selectedSeries.title}</h3>
                <p className="text-xs text-studio-text-muted mt-1">{selectedSeries.description}</p>
              </div>

              <button
                onClick={() => handleProduceNext(selectedSeries)}
                className="btn-gold text-xs py-2 px-4 gap-1.5 shrink-0"
              >
                <Plus className="w-4 h-4" />
                Produzir Próximo Episódio
              </button>
            </div>

            {/* Recurring Characters & Universe Rules */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-3.5 rounded-xl bg-studio-panel border border-studio-border space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-studio-text">
                  <Users className="w-3.5 h-3.5 text-studio-blue" />
                  <span>Personagens Recorrentes</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {selectedSeries.characters.map((char) => (
                    <span key={char.id} className="text-xs px-2.5 py-1 rounded-lg bg-studio-bg border border-studio-border text-studio-text font-medium">
                      🐾 {char.name} ({char.role})
                    </span>
                  ))}
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-studio-panel border border-studio-border space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-studio-text">
                  <Heart className="w-3.5 h-3.5 text-studio-gold" />
                  <span>Estilo Visual & Tom</span>
                </div>
                <p className="text-xs text-studio-text-muted">
                  {selectedSeries.visualStyleGuide}
                </p>
              </div>
            </div>

            {/* Episodes List */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-studio-text uppercase tracking-wider">
                Episódios Planejados & Publicados
              </h4>

              <div className="space-y-2">
                {selectedSeries.episodes.map((ep) => (
                  <div
                    key={ep.episodeNumber}
                    className="p-3.5 rounded-xl bg-studio-panel border border-studio-border flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-studio-bg border border-studio-border flex items-center justify-center font-bold font-mono text-xs text-studio-purple shrink-0">
                        #{ep.episodeNumber}
                      </div>
                      <div>
                        <p className="text-xs font-bold text-studio-text">{ep.title}</p>
                        <p className="text-[11px] text-studio-text-muted">{ep.synopsis}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <span className={cn(
                        "text-[10px] px-2 py-0.5 rounded-full font-semibold",
                        ep.status === "PUBLISHED" ? "bg-studio-green/20 text-studio-green" : "bg-studio-blue/20 text-studio-blue"
                      )}>
                        {ep.status === "PUBLISHED" ? "Publicado" : "Planejado"}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
