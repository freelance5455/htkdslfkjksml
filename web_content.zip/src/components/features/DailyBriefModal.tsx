// ============================================================
// AI CREATOR STUDIO — CORE 3.0 DAILY BRIEF & WEEKLY REPORT MODAL
// ============================================================

import { useState } from "react";
import {
  Calendar, CheckCircle2, Clock, Sparkles, TrendingUp, AlertCircle,
  Award, ArrowUpRight, BarChart2, Target, X, ChevronRight, Zap
} from "lucide-react";
import { cn } from "@/lib/utils";
import { generateDailyBrief, generateWeeklyReport } from "@/lib/core3/dailyBriefEngine";

interface DailyBriefModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectAction?: (actionText: string) => void;
}

export default function DailyBriefModal({
  isOpen,
  onClose,
  onSelectAction,
}: DailyBriefModalProps) {
  const [tab, setTab] = useState<"DAILY" | "WEEKLY">("DAILY");

  if (!isOpen) return null;

  const brief = generateDailyBrief();
  const report = generateWeeklyReport();

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="studio-card w-full max-w-3xl max-h-[90vh] flex flex-col border border-studio-border shadow-2xl overflow-hidden animate-fadeIn">
        {/* Header */}
        <div className="p-5 border-b border-studio-border flex items-center justify-between bg-studio-panel shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-studio-blue to-studio-purple flex items-center justify-center text-white shadow-md">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-studio-text font-display">
                {tab === "DAILY" ? "Daily Strategic Brief" : "Relatório Executivo Semanal"}
              </h2>
              <p className="text-xs text-studio-text-muted">{brief.date}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center bg-studio-bg border border-studio-border rounded-lg p-1">
              <button
                onClick={() => setTab("DAILY")}
                className={cn(
                  "px-3 py-1 text-xs font-semibold rounded-md transition-all",
                  tab === "DAILY" ? "bg-studio-blue text-white" : "text-studio-text-muted hover:text-studio-text"
                )}
              >
                Brief de Hoje
              </button>
              <button
                onClick={() => setTab("WEEKLY")}
                className={cn(
                  "px-3 py-1 text-xs font-semibold rounded-md transition-all",
                  tab === "WEEKLY" ? "bg-studio-blue text-white" : "text-studio-text-muted hover:text-studio-text"
                )}
              >
                Semanal
              </button>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-studio-text-muted hover:text-studio-text hover:bg-studio-border transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {tab === "DAILY" ? (
            <>
              {/* Greeting & AI Advice */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-studio-blue/10 to-studio-purple/10 border border-studio-blue/20 space-y-2">
                <p className="text-sm font-semibold text-studio-text">{brief.greeting}</p>
                <div className="flex items-start gap-2 pt-1">
                  <Zap className="w-4 h-4 text-studio-gold shrink-0 mt-0.5" />
                  <p className="text-xs text-studio-text-dim leading-relaxed">
                    <strong className="text-studio-text">Conselho Estratégico de Hoje:</strong> {brief.aiAdvice}
                  </p>
                </div>
              </div>

              {/* Priorities Checklist */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-studio-text font-display uppercase tracking-wider flex items-center gap-2">
                  <Target className="w-4 h-4 text-studio-blue" />
                  Top 3 Prioridades do Dia
                </h3>
                <div className="space-y-2">
                  {brief.priorities.map((prio, idx) => (
                    <div
                      key={prio.id}
                      className="p-3 rounded-xl bg-studio-panel border border-studio-border flex items-center justify-between gap-3 hover:border-studio-blue/30 transition-all"
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-5 h-5 rounded-full bg-studio-blue/20 text-studio-blue font-bold text-xs flex items-center justify-center shrink-0">
                          {idx + 1}
                        </span>
                        <p className="text-xs text-studio-text font-medium">{prio.text}</p>
                      </div>
                      <button
                        onClick={() => {
                          onClose();
                          if (onSelectAction) onSelectAction(prio.text);
                        }}
                        className="btn-primary text-xs py-1.5 px-3 shrink-0"
                      >
                        Executar
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Scheduled drops & Top Idea */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Scheduled today */}
                <div className="p-4 rounded-xl bg-studio-panel border border-studio-border space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-studio-text flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-studio-green" />
                      Lançamentos de Hoje
                    </h4>
                    <span className="text-[10px] text-studio-text-muted font-mono">{brief.scheduledToday.length} agendados</span>
                  </div>
                  {brief.scheduledToday.length === 0 ? (
                    <p className="text-xs text-studio-text-muted py-2">Nenhum post agendado para hoje. Aproveite para planejar os próximos slots.</p>
                  ) : (
                    <div className="space-y-1.5">
                      {brief.scheduledToday.map((s) => (
                        <div key={s.id} className="text-xs p-2 rounded-lg bg-studio-bg border border-studio-border/60 flex items-center justify-between">
                          <span className="font-medium text-studio-text truncate">{s.title}</span>
                          <span className="text-studio-blue font-mono font-bold shrink-0 ml-2">{s.time}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Top Idea of the day */}
                <div className="p-4 rounded-xl bg-studio-panel border border-studio-border space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-studio-text flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-studio-purple" />
                      Ideia Recomendada
                    </h4>
                    <span className="text-[10px] uppercase font-bold text-studio-purple">Score: {brief.topIdeaForToday?.impactScore || 95}/100</span>
                  </div>
                  <p className="text-xs font-semibold text-studio-text">{brief.topIdeaForToday?.title}</p>
                  <p className="text-[11px] text-studio-text-muted line-clamp-2">{brief.topIdeaForToday?.concept}</p>
                </div>
              </div>
            </>
          ) : (
            <>
              {/* Weekly Overview */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="p-3 rounded-xl bg-studio-panel border border-studio-border text-center">
                  <p className="text-xl font-bold text-studio-text font-display">{report.totalViewsGenerated.toLocaleString()}</p>
                  <p className="text-[11px] text-studio-text-muted">Views Totais</p>
                </div>
                <div className="p-3 rounded-xl bg-studio-panel border border-studio-border text-center">
                  <p className="text-xl font-bold text-studio-blue font-display">{report.averageRetentionPercent}%</p>
                  <p className="text-[11px] text-studio-text-muted">Retenção Média</p>
                </div>
                <div className="p-3 rounded-xl bg-studio-panel border border-studio-border text-center">
                  <p className="text-xl font-bold text-studio-green font-display">{report.averageCtrPercent}%</p>
                  <p className="text-[11px] text-studio-text-muted">CTR Médio</p>
                </div>
                <div className="p-3 rounded-xl bg-studio-panel border border-studio-border text-center">
                  <p className="text-xl font-bold text-studio-purple font-display">{report.totalProducedCount}</p>
                  <p className="text-[11px] text-studio-text-muted">Vídeos Produzidos</p>
                </div>
              </div>

              {/* Best vs Worst Performance */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {report.bestPerformingPost && (
                  <div className="p-4 rounded-xl bg-studio-green/10 border border-studio-green/30 space-y-1.5">
                    <span className="text-[10px] font-bold text-studio-green uppercase flex items-center gap-1">
                      <Award className="w-3.5 h-3.5" /> Melhor Desempenho
                    </span>
                    <p className="text-xs font-bold text-studio-text">{report.bestPerformingPost.title}</p>
                    <p className="text-[11px] text-studio-text-muted">
                      {report.bestPerformingPost.views.toLocaleString()} views · CTR: {report.bestPerformingPost.ctr}%
                    </p>
                  </div>
                )}

                {report.worstPerformingPost && (
                  <div className="p-4 rounded-xl bg-studio-red/10 border border-studio-red/30 space-y-1.5">
                    <span className="text-[10px] font-bold text-studio-red uppercase flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" /> Ponto de Otimização
                    </span>
                    <p className="text-xs font-bold text-studio-text">{report.worstPerformingPost.title}</p>
                    <p className="text-[11px] text-studio-text-muted">
                      Motivo de queda: {report.worstPerformingPost.dropoffReason}
                    </p>
                  </div>
                )}
              </div>

              {/* Key Learnings & Strategic Actions */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-studio-text font-display uppercase tracking-wider">
                  Aprendizados Principais
                </h4>
                <div className="space-y-2">
                  {report.keyLearnings.map((learning, i) => (
                    <div key={i} className="text-xs p-3 rounded-lg bg-studio-panel border border-studio-border flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-studio-blue shrink-0 mt-0.5" />
                      <span className="text-studio-text-dim">{learning}</span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-studio-border bg-studio-panel flex items-center justify-between shrink-0">
          <p className="text-xs text-studio-text-muted">
            Inteligência gerada automaticamente pelo AI Autopilot CORE 3.0.
          </p>
          <button onClick={onClose} className="btn-secondary text-xs py-2 px-4">
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
}
