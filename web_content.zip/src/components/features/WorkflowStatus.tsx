import { cn } from "@/lib/utils";
import { WORKFLOW_STEPS } from "@/constants";
import type { ProjectStatus } from "@/types";

interface WorkflowStatusProps {
  status: ProjectStatus;
  compact?: boolean;
}

const STATUS_ORDER = [
  "IDEA", "BRIEFING", "SCRIPTING", "STORYBOARDING",
  "MEDIA_PLANNING", "GENERATING", "EDITING", "REVIEW", "RENDERING", "COMPLETED",
];

export default function WorkflowStatus({ status, compact }: WorkflowStatusProps) {
  const currentIdx = STATUS_ORDER.indexOf(status);

  if (compact) {
    return (
      <div className="flex items-center gap-1">
        {WORKFLOW_STEPS.map((step, i) => {
          const stepIdx = STATUS_ORDER.indexOf(step.key);
          const done = stepIdx < currentIdx;
          const active = stepIdx === currentIdx;
          return (
            <div
              key={step.key}
              className={cn(
                "h-1 rounded-full transition-all",
                compact ? "w-6" : "flex-1",
                done ? "bg-studio-blue" : active ? "bg-studio-gold" : "bg-studio-border"
              )}
            />
          );
        })}
      </div>
    );
  }

  return (
    <div className="studio-panel p-4">
      <h3 className="text-sm font-semibold text-studio-text mb-4 font-display">Pipeline de Produção</h3>
      <div className="space-y-1.5">
        {WORKFLOW_STEPS.map((step) => {
          const stepIdx = STATUS_ORDER.indexOf(step.key);
          const done = stepIdx < currentIdx;
          const active = step.key === status;
          const pending = stepIdx > currentIdx;

          return (
            <div
              key={step.key}
              className={cn(
                "workflow-step text-sm",
                done && "border-studio-green/20 bg-studio-green/5",
                active && "border-studio-gold/30 bg-studio-gold/5",
                pending && "border-transparent"
              )}
            >
              <span className="text-base w-6 text-center">{step.icon}</span>
              <span className={cn(
                "flex-1",
                done && "text-studio-green",
                active && "text-studio-gold font-semibold",
                pending && "text-studio-text-muted",
              )}>
                {step.label}
              </span>
              {done && <span className="text-studio-green text-xs">✓</span>}
              {active && <span className="text-studio-gold text-xs animate-pulse">●</span>}
            </div>
          );
        })}
      </div>
    </div>
  );
}
