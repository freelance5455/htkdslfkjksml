import type { ContentBrief } from "@/types";
import { cn, formatDuration, getStatusColor, getStatusLabel } from "@/lib/utils";
import { CheckCircle2, RefreshCw, Edit3, Clock, Globe, Users } from "lucide-react";

interface ContentBriefViewProps {
  brief: ContentBrief;
  onApprove: () => void;
  onRegenerate: () => void;
  onEdit: (field: string, value: string) => void;
}

export default function ContentBriefView({ brief, onApprove, onRegenerate }: ContentBriefViewProps) {
  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-base font-bold text-studio-text font-display">{brief.title}</h3>
          <span className={cn("task-badge text-xs mt-1", getStatusColor(brief.status))}>
            {getStatusLabel(brief.status)}
          </span>
        </div>
        <div className="flex gap-2">
          <button onClick={onRegenerate} className="btn-secondary text-sm py-2 px-3 gap-1.5">
            <RefreshCw className="w-3.5 h-3.5" />
            Regenerar
          </button>
          <button onClick={onApprove} className="btn-primary text-sm py-2 px-3 gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Aprovar
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="studio-card p-3 flex items-center gap-2">
          <Clock className="w-4 h-4 text-studio-blue shrink-0" />
          <div>
            <p className="text-xs text-studio-text-muted">Duração</p>
            <p className="text-sm font-semibold text-studio-text">{formatDuration(brief.duration)}</p>
          </div>
        </div>
        <div className="studio-card p-3 flex items-center gap-2">
          <Users className="w-4 h-4 text-studio-purple shrink-0" />
          <div>
            <p className="text-xs text-studio-text-muted">Público</p>
            <p className="text-sm font-semibold text-studio-text truncate">{brief.audience.label}</p>
          </div>
        </div>
        <div className="studio-card p-3 flex items-center gap-2">
          <Globe className="w-4 h-4 text-studio-gold shrink-0" />
          <div>
            <p className="text-xs text-studio-text-muted">Plataforma</p>
            <p className="text-sm font-semibold text-studio-text">{brief.platform}</p>
          </div>
        </div>
      </div>

      <div className="studio-card p-4">
        <p className="text-xs text-studio-text-muted mb-2 font-medium uppercase tracking-wide">Objetivo</p>
        <p className="text-sm text-studio-text leading-relaxed">{brief.objective}</p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="studio-card p-4">
          <p className="text-xs text-studio-text-muted mb-3 font-medium uppercase tracking-wide">Estrutura</p>
          <ol className="space-y-1.5">
            {brief.structure.map((step, i) => (
              <li key={i} className="flex items-start gap-2 text-sm">
                <span className="text-studio-blue font-bold shrink-0 w-5">{i + 1}.</span>
                <span className="text-studio-text-dim">{step}</span>
              </li>
            ))}
          </ol>
        </div>
        <div className="studio-card p-4">
          <p className="text-xs text-studio-text-muted mb-3 font-medium uppercase tracking-wide">Elementos Necessários</p>
          <ul className="space-y-1.5">
            {brief.requiredElements.map((el, i) => (
              <li key={i} className="flex items-center gap-2 text-sm text-studio-text-dim">
                <span className="text-studio-green">✓</span>
                {el}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="studio-card p-4">
        <p className="text-xs text-studio-text-muted mb-3 font-medium uppercase tracking-wide">Tom & Estilo</p>
        <div className="flex gap-2 flex-wrap">
          {[brief.tone, brief.style, brief.format].filter(Boolean).map((tag) => (
            <span key={tag} className="task-badge text-xs bg-studio-blue/10 text-studio-blue border border-studio-blue/20">
              {tag}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
