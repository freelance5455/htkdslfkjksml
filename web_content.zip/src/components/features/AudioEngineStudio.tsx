import { useState, useRef, useEffect } from "react";
import {
  AUDIO_ENGINES,
  VOICE_PRESETS,
  VOICE_TONES,
  ACOUSTIC_ENVIRONMENTS,
  MUSIC_GENRES,
  SOUND_EFFECTS_LIST,
} from "@/constants/audioEngines";
import type {
  AudioEngineId,
  AudioVoiceId,
  VoiceTone,
  AcousticEnvironment,
  MusicGenre,
  SoundEffectType,
  AudioGenerationResult,
} from "@/types/audio";
import type { Project, StoryboardScene } from "@/types";
import {
  generateTTSAudio,
  generateMusicAudio,
  generateSoundEffectAudio,
  optimizeVoiceScript,
  playLocalSpeechPreview,
  stopLocalSpeechPreview,
} from "@/lib/audioEngine";
import { cn } from "@/lib/utils";
import {
  Volume2, VolumeX, Play, Pause, RotateCcw, Download,
  Sparkles, Mic, Music, Zap, CheckCircle2, RefreshCw,
  Layers, Sliders, Radio, Music2, FileText, ChevronRight
} from "lucide-react";

interface AudioEngineStudioProps {
  project?: Project;
  onProjectUpdate?: (updated: Project) => void;
  initialScene?: StoryboardScene;
}

type AudioSubTab = "tts" | "music" | "sfx" | "script_reader";

export default function AudioEngineStudio({
  project,
  onProjectUpdate,
  initialScene,
}: AudioEngineStudioProps) {
  const [subTab, setSubTab] = useState<AudioSubTab>("tts");

  // TTS States
  const [selectedEngineId, setSelectedEngineId] = useState<AudioEngineId>("gemini-tts");
  const [selectedVoiceId, setSelectedVoiceId] = useState<AudioVoiceId>("kore");
  const [tone, setTone] = useState<VoiceTone>("DOCUMENTARY_NARRATOR");
  const [acousticEnv, setAcousticEnv] = useState<AcousticEnvironment>("DRY_STUDIO");
  const [speechRate, setSpeechRate] = useState<number>(1.0);
  const [pitch, setPitch] = useState<number>(0);
  const [stability, setStability] = useState<number>(0.75);
  const [rawText, setRawText] = useState(
    initialScene?.narration || "Bem-vindo ao futuro da criação de conteúdo com inteligência artificial de alta performance."
  );
  const [selectedSceneId, setSelectedSceneId] = useState<string>(initialScene?.id || (project?.storyboard?.scenes[0]?.id ?? ""));

  // Music States
  const [selectedGenre, setSelectedGenre] = useState<MusicGenre>("CINEMATIC_ORCHESTRAL");
  const [musicDuration, setMusicDuration] = useState<number>(project?.brief?.duration || 30);

  // SFX States
  const [selectedSfx, setSelectedSfx] = useState<SoundEffectType>("WHOOSH_TRANSITION");

  // AI Script Optimizer
  const [isOptimizing, setIsOptimizing] = useState(false);

  // Generation & Audio Player State
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentAudio, setCurrentAudio] = useState<AudioGenerationResult | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [playbackDuration, setPlaybackDuration] = useState(0);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Local speech preview state
  const [isPreviewingLocal, setIsPreviewingLocal] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);
  const [recentAudios, setRecentAudios] = useState<AudioGenerationResult[]>([]);

  // Sync selected scene narration
  useEffect(() => {
    if (selectedSceneId && project?.storyboard?.scenes) {
      const found = project.storyboard.scenes.find((s) => s.id === selectedSceneId);
      if (found && found.narration) {
        setRawText(found.narration);
      }
    }
  }, [selectedSceneId, project]);

  // Audio element event listeners
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const onTimeUpdate = () => setCurrentTime(audio.currentTime);
    const onLoadedMetadata = () => setPlaybackDuration(audio.duration || currentAudio?.duration || 0);
    const onEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
    };

    audio.addEventListener("timeupdate", onTimeUpdate);
    audio.addEventListener("loadedmetadata", onLoadedMetadata);
    audio.addEventListener("ended", onEnded);

    return () => {
      audio.removeEventListener("timeupdate", onTimeUpdate);
      audio.removeEventListener("loadedmetadata", onLoadedMetadata);
      audio.removeEventListener("ended", onEnded);
    };
  }, [currentAudio]);

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
    }
  };

  const handleSeek = (time: number) => {
    if (!audioRef.current) return;
    audioRef.current.currentTime = time;
    setCurrentTime(time);
  };

  // Handler: Optimize Voice Text with Gemini
  const handleOptimizeScript = async () => {
    if (!rawText.trim()) return;
    setIsOptimizing(true);
    try {
      const optimized = await optimizeVoiceScript(rawText, tone);
      setRawText(optimized);
      setNotification("Texto otimizado com pausas e ritmo natural!");
      setTimeout(() => setNotification(null), 3000);
    } catch (err) {
      console.error("Falha ao otimizar script:", err);
    } finally {
      setIsOptimizing(false);
    }
  };

  // Handler: Local speech instant preview
  const handleToggleLocalPreview = () => {
    if (isPreviewingLocal) {
      stopLocalSpeechPreview();
      setIsPreviewingLocal(false);
    } else {
      playLocalSpeechPreview(rawText, selectedVoiceId, speechRate);
      setIsPreviewingLocal(true);
      setTimeout(() => setIsPreviewingLocal(false), Math.max(3000, rawText.length * 70));
    }
  };

  // Handler: Generate TTS
  const handleGenerateTTS = async () => {
    if (!rawText.trim()) return;
    setIsGenerating(true);
    try {
      const result = await generateTTSAudio({
        text: rawText,
        engine: selectedEngineId,
        voiceId: selectedVoiceId,
        tone,
        language: "pt-BR",
        speechRate,
        pitch,
        stability,
        acousticEnvironment: acousticEnv,
        sceneId: selectedSceneId || undefined,
        projectId: project?.id,
        projectTitle: project?.title,
      });

      setCurrentAudio(result);
      setRecentAudios((prev) => [result, ...prev.slice(0, 5)]);

      if (audioRef.current) {
        audioRef.current.src = result.audioUrl;
        audioRef.current.load();
        audioRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
      }
    } catch (err) {
      console.error("Erro na geração de TTS:", err);
    } finally {
      setIsGenerating(false);
    }
  };

  // Handler: Generate Music
  const handleGenerateMusic = async () => {
    setIsGenerating(true);
    try {
      const result = await generateMusicAudio({
        genre: selectedGenre,
        duration: musicDuration,
        projectId: project?.id,
        sceneId: selectedSceneId || undefined,
      });

      setCurrentAudio(result);
      setRecentAudios((prev) => [result, ...prev.slice(0, 5)]);

      if (audioRef.current) {
        audioRef.current.src = result.audioUrl;
        audioRef.current.load();
        audioRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
      }
    } catch (err) {
      console.error("Erro na geração de música:", err);
    } finally {
      setIsGenerating(false);
    }
  };

  // Handler: Generate SFX
  const handleGenerateSfx = async () => {
    setIsGenerating(true);
    try {
      const result = await generateSoundEffectAudio({
        type: selectedSfx,
        sceneId: selectedSceneId || undefined,
      });

      setCurrentAudio(result);
      setRecentAudios((prev) => [result, ...prev.slice(0, 5)]);

      if (audioRef.current) {
        audioRef.current.src = result.audioUrl;
        audioRef.current.load();
        audioRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
      }
    } catch (err) {
      console.error("Erro na geração de SFX:", err);
    } finally {
      setIsGenerating(false);
    }
  };

  // Handler: Dub full project script section by section
  const handleDubScriptSection = (sectionText: string, sectionTitle: string, sceneNum?: number) => {
    setRawText(sectionText);
    if (sceneNum && project?.storyboard?.scenes) {
      const sc = project.storyboard.scenes.find((s) => s.sceneNumber === sceneNum);
      if (sc) setSelectedSceneId(sc.id);
    }
    setSubTab("tts");
    setNotification(`Carregado texto da seção: ${sectionTitle}`);
    setTimeout(() => setNotification(null), 3000);
  };

  const selectedVoice = VOICE_PRESETS.find((v) => v.id === selectedVoiceId) || VOICE_PRESETS[0];

  return (
    <div className="space-y-6">
      {/* Hidden Audio Element */}
      <audio ref={audioRef} preload="auto" />

      {/* Top Banner: Notification */}
      {notification && (
        <div className="bg-studio-green/10 border border-studio-green/30 text-studio-green px-4 py-2.5 rounded-lg flex items-center gap-2 text-xs animate-in fade-in">
          <CheckCircle2 className="w-4 h-4" />
          <span>{notification}</span>
        </div>
      )}

      {/* Header Info */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-studio-surface border border-studio-border p-4 rounded-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-studio-green/10 border border-studio-green/20 flex items-center justify-center text-studio-green">
            <Mic className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-semibold text-studio-text flex items-center gap-2">
              Motor de Voz Neural & Áudio Studio (TTS / Music / SFX)
              <span className="text-xs px-2 py-0.5 rounded-full bg-studio-green/10 text-studio-green border border-studio-green/20 font-normal">
                {AUDIO_ENGINES.find((e) => e.id === selectedEngineId)?.name}
              </span>
            </h2>
            <p className="text-xs text-studio-text-muted">
              Síntese de voz com entonação humana, geração de trilhas musicais adaptativas e efeitos sonoros para o seu vídeo.
            </p>
          </div>
        </div>

        {/* Sub-tab Navigation */}
        <div className="flex items-center gap-1 bg-studio-panel p-1 rounded-lg border border-studio-border shrink-0">
          <button
            onClick={() => setSubTab("tts")}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all",
              subTab === "tts"
                ? "bg-studio-surface text-studio-green shadow-sm border border-studio-green/20"
                : "text-studio-text-muted hover:text-studio-text"
            )}
          >
            <Mic className="w-3.5 h-3.5" />
            Voz / Narração
          </button>

          <button
            onClick={() => setSubTab("music")}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all",
              subTab === "music"
                ? "bg-studio-surface text-studio-purple shadow-sm border border-studio-purple/20"
                : "text-studio-text-muted hover:text-studio-text"
            )}
          >
            <Music className="w-3.5 h-3.5" />
            Trilhas Musicais
          </button>

          <button
            onClick={() => setSubTab("sfx")}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all",
              subTab === "sfx"
                ? "bg-studio-surface text-studio-amber shadow-sm border border-studio-amber/20"
                : "text-studio-text-muted hover:text-studio-text"
            )}
          >
            <Zap className="w-3.5 h-3.5" />
            Efeitos Sonoros
          </button>

          {project?.script && (
            <button
              onClick={() => setSubTab("script_reader")}
              className={cn(
                "flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all",
                subTab === "script_reader"
                  ? "bg-studio-surface text-studio-blue shadow-sm border border-studio-blue/20"
                  : "text-studio-text-muted hover:text-studio-text"
              )}
            >
              <FileText className="w-3.5 h-3.5" />
              Dublador de Roteiro
            </button>
          )}
        </div>
      </div>

      {/* SUBTAB 1: TTS / VOICE GENERATOR */}
      {subTab === "tts" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Controls & Text Input */}
          <div className="lg:col-span-7 space-y-4">
            {/* Engine selector */}
            <div>
              <label className="text-xs font-semibold text-studio-text-muted uppercase tracking-wider block mb-2">
                Motor Neural de TTS
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {AUDIO_ENGINES.filter((e) => e.type === "TTS").map((eng) => {
                  const isSelected = selectedEngineId === eng.id;
                  return (
                    <button
                      key={eng.id}
                      onClick={() => setSelectedEngineId(eng.id)}
                      className={cn(
                        "p-2.5 rounded-lg border text-left transition-all",
                        isSelected
                          ? "bg-studio-surface border-studio-green ring-1 ring-studio-green"
                          : "bg-studio-surface/60 border-studio-border hover:border-studio-border-hover"
                      )}
                    >
                      <span className="text-xs font-semibold text-studio-text block truncate">{eng.name}</span>
                      <span className="text-[10px] text-studio-text-dim block truncate">{eng.badge}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Voice Cards */}
            <div>
              <label className="text-xs font-semibold text-studio-text-muted uppercase tracking-wider block mb-2">
                Selecione a Voz do Narrador
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-56 overflow-y-auto pr-1">
                {VOICE_PRESETS.map((v) => {
                  const isSelected = selectedVoiceId === v.id;
                  return (
                    <button
                      key={v.id}
                      onClick={() => setSelectedVoiceId(v.id)}
                      className={cn(
                        "p-3 rounded-xl border text-left transition-all flex flex-col justify-between gap-1",
                        isSelected
                          ? "bg-studio-surface border-studio-green ring-1 ring-studio-green shadow-sm"
                          : "bg-studio-surface/50 border-studio-border hover:border-studio-border-hover hover:bg-studio-surface"
                      )}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold text-studio-text">{v.name.split("(")[0]}</span>
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-studio-panel border border-studio-border text-studio-text-dim">
                          {v.gender === "FEMALE" ? "Feminino" : v.gender === "MALE" ? "Masculino" : "Neutro"}
                        </span>
                      </div>
                      <p className="text-[10px] text-studio-text-muted line-clamp-2 leading-relaxed">{v.description}</p>
                      <span className="text-[9px] text-studio-green font-medium mt-1">
                        🎯 {v.recommendedFor}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Text Input Box */}
            <div className="bg-studio-surface border border-studio-border rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-studio-text flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-studio-green" />
                  Texto da Narração
                </label>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleToggleLocalPreview}
                    className="text-xs flex items-center gap-1 text-studio-text-muted hover:text-studio-text font-medium"
                  >
                    <Volume2 className="w-3 h-3 text-studio-green" />
                    {isPreviewingLocal ? "Ouvindo..." : "Pré-escuta"}
                  </button>
                  <button
                    onClick={handleOptimizeScript}
                    disabled={isOptimizing || !rawText.trim()}
                    className="text-xs flex items-center gap-1 text-studio-green hover:text-studio-green/80 font-medium"
                  >
                    <Sparkles className={cn("w-3 h-3", isOptimizing && "animate-spin")} />
                    {isOptimizing ? "Otimizando..." : "Otimizar Ritmo (Gemini)"}
                  </button>
                </div>
              </div>

              <textarea
                value={rawText}
                onChange={(e) => setRawText(e.target.value)}
                rows={4}
                placeholder="Insira o texto que será falado com entonação neural..."
                className="w-full bg-studio-panel border border-studio-border rounded-lg p-3 text-xs text-studio-text focus:outline-none focus:border-studio-green resize-none"
              />

              <div className="flex items-center justify-between text-[10px] text-studio-text-dim">
                <span>{rawText.length} caracteres · ~{Math.round(rawText.trim().split(/\s+/).length / 2.5)}s estimados</span>
                {project?.storyboard?.scenes && (
                  <select
                    value={selectedSceneId}
                    onChange={(e) => setSelectedSceneId(e.target.value)}
                    className="bg-studio-panel border border-studio-border rounded px-2 py-0.5 text-[10px] text-studio-text"
                  >
                    <option value="">Atribuir a Cena do Storyboard...</option>
                    {project.storyboard.scenes.map((s) => (
                      <option key={s.id} value={s.id}>
                        Cena #{s.sceneNumber}: {s.visualDescription.substring(0, 25)}...
                      </option>
                    ))}
                  </select>
                )}
              </div>
            </div>

            {/* Tone & Acoustic Environment */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="bg-studio-surface border border-studio-border rounded-xl p-3 space-y-1.5">
                <label className="text-xs font-semibold text-studio-text">Tom Emocional</label>
                <select
                  value={tone}
                  onChange={(e) => setTone(e.target.value as VoiceTone)}
                  className="w-full bg-studio-panel border border-studio-border rounded-lg px-2.5 py-1.5 text-xs text-studio-text focus:outline-none focus:border-studio-green"
                >
                  {VOICE_TONES.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.label}
                    </option>
                  ))}
                </select>
                <p className="text-[10px] text-studio-text-dim truncate">
                  {VOICE_TONES.find((t) => t.id === tone)?.desc}
                </p>
              </div>

              <div className="bg-studio-surface border border-studio-border rounded-xl p-3 space-y-1.5">
                <label className="text-xs font-semibold text-studio-text">Ambiente Acústico</label>
                <select
                  value={acousticEnv}
                  onChange={(e) => setAcousticEnv(e.target.value as AcousticEnvironment)}
                  className="w-full bg-studio-panel border border-studio-border rounded-lg px-2.5 py-1.5 text-xs text-studio-text focus:outline-none focus:border-studio-green"
                >
                  {ACOUSTIC_ENVIRONMENTS.map((env) => (
                    <option key={env.id} value={env.id}>
                      {env.label}
                    </option>
                  ))}
                </select>
                <p className="text-[10px] text-studio-text-dim truncate">
                  {ACOUSTIC_ENVIRONMENTS.find((e) => e.id === acousticEnv)?.desc}
                </p>
              </div>
            </div>

            {/* Sliders: Rate & Stability */}
            <div className="bg-studio-surface border border-studio-border rounded-xl p-3.5 space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="flex justify-between text-[11px] text-studio-text-muted mb-1">
                    <span>Velocidade de Fala</span>
                    <span>{speechRate}x</span>
                  </div>
                  <input
                    type="range"
                    min={0.6}
                    max={1.8}
                    step={0.05}
                    value={speechRate}
                    onChange={(e) => setSpeechRate(parseFloat(e.target.value))}
                    className="w-full accent-studio-green h-1.5 bg-studio-panel rounded-lg appearance-none cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-studio-text-muted mb-1">
                    <span>Estabilidade / Clareza</span>
                    <span>{Math.round(stability * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0.1}
                    max={1.0}
                    step={0.05}
                    value={stability}
                    onChange={(e) => setStability(parseFloat(e.target.value))}
                    className="w-full accent-studio-green h-1.5 bg-studio-panel rounded-lg appearance-none cursor-pointer"
                  />
                </div>
              </div>
            </div>

            {/* Generate Button */}
            <button
              onClick={handleGenerateTTS}
              disabled={isGenerating || !rawText.trim()}
              className="btn-primary w-full py-3 text-sm font-semibold justify-center gap-2 bg-studio-green hover:bg-studio-green/90 shadow-lg shadow-studio-green/10"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Sintetizando Voz Neural ({selectedVoice.name.split("(")[0]})...</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-4 h-4" />
                  <span>Sintetizar Narração ({selectedVoice.name.split("(")[0]})</span>
                </>
              )}
            </button>
          </div>

          {/* Right: Audio Waveform Player & Details */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-studio-surface border border-studio-border rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-studio-text flex items-center gap-1.5">
                  <Radio className="w-3.5 h-3.5 text-studio-green" />
                  Player & Visualizador Acústico
                </span>
                {currentAudio && (
                  <span className="text-[10px] px-2 py-0.5 rounded bg-studio-green/10 text-studio-green border border-studio-green/20 font-medium">
                    ✓ {currentAudio.duration}s · 24kHz WAV
                  </span>
                )}
              </div>

              {/* Animated Waveform Visualizer */}
              <div className="bg-studio-panel rounded-xl p-5 border border-studio-border flex flex-col items-center justify-center space-y-3">
                <div className="flex items-center justify-center gap-1 h-16 w-full">
                  {Array.from({ length: 28 }).map((_, idx) => {
                    const activeHeight = isPlaying ? Math.max(15, Math.sin(idx + currentTime * 4) * 80 + 30) : 20;
                    return (
                      <div
                        key={idx}
                        style={{ height: `${activeHeight}%` }}
                        className={cn(
                          "w-1.5 rounded-full transition-all duration-100",
                          isPlaying ? "bg-studio-green" : "bg-studio-border"
                        )}
                      />
                    );
                  })}
                </div>

                <div className="w-full flex justify-between text-[11px] font-mono text-studio-text-dim">
                  <span>{Math.floor(currentTime)}s</span>
                  <span>{Math.floor(playbackDuration || currentAudio?.duration || 0)}s</span>
                </div>

                {/* Progress scrubber */}
                <input
                  type="range"
                  min={0}
                  max={playbackDuration || currentAudio?.duration || 10}
                  step={0.1}
                  value={currentTime}
                  onChange={(e) => handleSeek(parseFloat(e.target.value))}
                  className="w-full accent-studio-green h-1.5 bg-studio-surface rounded-lg appearance-none cursor-pointer"
                />

                {/* Playback Controls */}
                <div className="flex items-center justify-between w-full pt-2">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={togglePlay}
                      disabled={!currentAudio}
                      className={cn(
                        "w-10 h-10 rounded-full flex items-center justify-center transition-all",
                        currentAudio
                          ? "bg-studio-green text-white hover:bg-studio-green/90 shadow-md shadow-studio-green/20"
                          : "bg-studio-border text-studio-text-dim cursor-not-allowed"
                      )}
                    >
                      {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                    </button>
                    <button
                      onClick={() => handleSeek(0)}
                      disabled={!currentAudio}
                      className="p-2 rounded-lg text-studio-text-muted hover:text-studio-text transition-colors"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {currentAudio && (
                    <div className="flex items-center gap-2">
                      <a
                        href={currentAudio.audioUrl}
                        download={`audio_${currentAudio.id}.wav`}
                        target="_blank"
                        rel="noreferrer"
                        className="btn-secondary text-xs py-1.5 px-2.5 gap-1"
                      >
                        <Download className="w-3.5 h-3.5" />
                        Download
                      </a>
                    </div>
                  )}
                </div>
              </div>

              {/* Current Track Details */}
              {currentAudio ? (
                <div className="space-y-2 text-xs">
                  <div className="p-3 bg-studio-panel/60 rounded-lg border border-studio-border">
                    <div className="font-semibold text-studio-text mb-1">{currentAudio.title}</div>
                    <p className="text-studio-text-muted text-[11px] leading-relaxed italic">
                      "{currentAudio.text}"
                    </p>
                  </div>

                  {project?.storyboard?.scenes && (
                    <div className="flex items-center justify-between pt-2 border-t border-studio-border">
                      <span className="text-[11px] text-studio-text-muted">Vincular a Cena:</span>
                      <button
                        onClick={() => {
                          if (selectedSceneId && project && onProjectUpdate && project.storyboard) {
                            const updated = project.storyboard.scenes.map((s) =>
                              s.id === selectedSceneId ? { ...s, narration: currentAudio.text || s.narration } : s
                            );
                            onProjectUpdate({
                              ...project,
                              storyboard: { ...project.storyboard, scenes: updated },
                            });
                            setNotification(`Narração vinculada à Cena selecionada!`);
                            setTimeout(() => setNotification(null), 3000);
                          }
                        }}
                        className="btn-secondary text-[10px] py-1 px-2 gap-1 text-studio-green border-studio-green/30"
                      >
                        <CheckCircle2 className="w-3 h-3" />
                        Salvar na Cena
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-4 text-xs text-studio-text-muted">
                  Nenhum áudio gerado nesta sessão.
                </div>
              )}
            </div>

            {/* Recent History */}
            {recentAudios.length > 0 && (
              <div className="bg-studio-surface border border-studio-border rounded-xl p-4 space-y-2.5">
                <span className="text-xs font-semibold text-studio-text">Histórico Recente ({recentAudios.length})</span>
                <div className="space-y-1.5">
                  {recentAudios.map((aud) => (
                    <button
                      key={aud.id}
                      onClick={() => {
                        setCurrentAudio(aud);
                        if (audioRef.current) {
                          audioRef.current.src = aud.audioUrl;
                          audioRef.current.load();
                          audioRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
                        }
                      }}
                      className={cn(
                        "w-full p-2 rounded-lg border text-left text-xs flex items-center justify-between transition-all",
                        currentAudio?.id === aud.id
                          ? "bg-studio-green/10 border-studio-green text-studio-text font-medium"
                          : "bg-studio-panel border-studio-border text-studio-text-muted hover:text-studio-text"
                      )}
                    >
                      <span className="truncate flex-1 mr-2">{aud.title}</span>
                      <span className="text-[10px] font-mono shrink-0">{aud.duration}s</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUBTAB 2: MUSIC GENERATOR */}
      {subTab === "music" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 space-y-4">
            <div>
              <label className="text-xs font-semibold text-studio-text-muted uppercase tracking-wider block mb-2">
                Gênero Musical & Estilo da Trilha
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {MUSIC_GENRES.map((g) => {
                  const isSelected = selectedGenre === g.id;
                  return (
                    <button
                      key={g.id}
                      onClick={() => setSelectedGenre(g.id)}
                      className={cn(
                        "p-3 rounded-xl border text-left transition-all flex flex-col justify-between gap-1",
                        isSelected
                          ? "bg-studio-surface border-studio-purple ring-1 ring-studio-purple shadow-sm"
                          : "bg-studio-surface/50 border-studio-border hover:border-studio-border-hover hover:bg-studio-surface"
                      )}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold text-studio-text">{g.label}</span>
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-studio-panel border border-studio-border text-studio-purple font-mono">
                          {g.bpm}
                        </span>
                      </div>
                      <p className="text-[10px] text-studio-text-muted line-clamp-2">{g.desc}</p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Music Duration */}
            <div className="bg-studio-surface border border-studio-border rounded-xl p-4 space-y-3">
              <div className="flex justify-between text-xs font-semibold text-studio-text">
                <span>Duração da Trilha Sonora</span>
                <span className="text-studio-purple font-mono">{musicDuration} segundos</span>
              </div>
              <input
                type="range"
                min={10}
                max={180}
                step={5}
                value={musicDuration}
                onChange={(e) => setMusicDuration(parseInt(e.target.value))}
                className="w-full accent-studio-purple h-1.5 bg-studio-panel rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-studio-text-dim">
                <span>10s (Curto)</span>
                <span>60s (Médio)</span>
                <span>180s (Completo)</span>
              </div>
            </div>

            {/* Generate Music Button */}
            <button
              onClick={handleGenerateMusic}
              disabled={isGenerating}
              className="btn-primary w-full py-3 text-sm font-semibold justify-center gap-2 bg-studio-purple hover:bg-studio-purple/90 shadow-lg shadow-studio-purple/10"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Compondo Trilha Sonora com Google Lyria...</span>
                </>
              ) : (
                <>
                  <Music2 className="w-4 h-4" />
                  <span>Gerar Trilha Sonora ({musicDuration}s)</span>
                </>
              )}
            </button>
          </div>

          <div className="lg:col-span-5 space-y-4">
            <div className="bg-studio-surface border border-studio-border rounded-xl p-5 space-y-4">
              <span className="text-xs font-semibold text-studio-text flex items-center gap-1.5">
                <Music className="w-3.5 h-3.5 text-studio-purple" />
                Player de Trilha Sonora
              </span>

              {currentAudio && currentAudio.type === "MUSIC" ? (
                <div className="bg-studio-panel rounded-xl p-5 border border-studio-border space-y-3 text-center">
                  <div className="w-12 h-12 rounded-full bg-studio-purple/20 text-studio-purple flex items-center justify-center mx-auto">
                    <Music className="w-6 h-6" />
                  </div>
                  <h4 className="text-sm font-semibold text-studio-text">{currentAudio.title}</h4>
                  <div className="flex justify-center gap-3">
                    <button
                      onClick={togglePlay}
                      className="w-10 h-10 rounded-full bg-studio-purple text-white flex items-center justify-center shadow-md"
                    >
                      {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-xs text-studio-text-muted">
                  Selecione um estilo e clique em <strong>Gerar Trilha Sonora</strong>.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 3: SFX GENERATOR */}
      {subTab === "sfx" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 space-y-4">
            <label className="text-xs font-semibold text-studio-text-muted uppercase tracking-wider block">
              Biblioteca de Efeitos Sonoros (SFX)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {SOUND_EFFECTS_LIST.map((sfx) => {
                const isSelected = selectedSfx === sfx.id;
                return (
                  <button
                    key={sfx.id}
                    onClick={() => setSelectedSfx(sfx.id)}
                    className={cn(
                      "p-3 rounded-xl border text-left transition-all flex flex-col justify-between gap-1",
                      isSelected
                        ? "bg-studio-surface border-studio-amber ring-1 ring-studio-amber shadow-sm"
                        : "bg-studio-surface/50 border-studio-border hover:border-studio-border-hover hover:bg-studio-surface"
                    )}
                  >
                    <span className="text-xs font-semibold text-studio-text">{sfx.label}</span>
                    <p className="text-[10px] text-studio-text-muted line-clamp-2">{sfx.desc}</p>
                  </button>
                );
              })}
            </div>

            <button
              onClick={handleGenerateSfx}
              disabled={isGenerating}
              className="btn-primary w-full py-3 text-sm font-semibold justify-center gap-2 bg-studio-amber hover:bg-studio-amber/90 text-black shadow-lg shadow-studio-amber/10"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-black" />
                  <span>Sintetizando Efeito Sonoro...</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 text-black" />
                  <span>Gerar Efeito Sonoro</span>
                </>
              )}
            </button>
          </div>

          <div className="lg:col-span-5 space-y-4">
            <div className="bg-studio-surface border border-studio-border rounded-xl p-5 space-y-4">
              <span className="text-xs font-semibold text-studio-text flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-studio-amber" />
                Player de Efeito Sonoro
              </span>

              {currentAudio && currentAudio.type === "SFX" ? (
                <div className="bg-studio-panel rounded-xl p-5 border border-studio-border space-y-3 text-center">
                  <div className="w-12 h-12 rounded-full bg-studio-amber/20 text-studio-amber flex items-center justify-center mx-auto">
                    <Zap className="w-6 h-6" />
                  </div>
                  <h4 className="text-sm font-semibold text-studio-text">{currentAudio.title}</h4>
                  <button
                    onClick={togglePlay}
                    className="w-10 h-10 rounded-full bg-studio-amber text-black flex items-center justify-center mx-auto shadow-md"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                  </button>
                </div>
              ) : (
                <div className="text-center py-8 text-xs text-studio-text-muted">
                  Selecione um efeito e clique em <strong>Gerar Efeito Sonoro</strong>.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 4: SCRIPT DUBBER (LEITOR DE ROTEIRO) */}
      {subTab === "script_reader" && project?.script && (
        <div className="space-y-4">
          <div className="bg-studio-surface border border-studio-border rounded-xl p-4">
            <h3 className="text-sm font-semibold text-studio-text mb-1">
              Roteiro Completo do Projeto: {project.script.title}
            </h3>
            <p className="text-xs text-studio-text-muted">
              Selecione qualquer bloco do roteiro para transferir o texto e sintetizar a narração instantaneamente.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {project.script.sections.map((section, idx) => (
              <div
                key={section.id}
                className="bg-studio-surface border border-studio-border rounded-xl p-4 space-y-2 hover:border-studio-blue/40 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-studio-text">
                    #{idx + 1} · {section.title}
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-studio-panel border border-studio-border text-studio-text-dim">
                    {section.duration}s
                  </span>
                </div>

                <p className="text-xs text-studio-text-muted leading-relaxed line-clamp-3">
                  "{section.narration}"
                </p>

                <button
                  onClick={() => handleDubScriptSection(section.narration, section.title, idx + 1)}
                  className="btn-secondary w-full text-xs py-1.5 justify-center gap-1 text-studio-green border-studio-green/30 hover:bg-studio-green/10"
                >
                  <Mic className="w-3.5 h-3.5" />
                  Carregar & Sintetizar Voz
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
