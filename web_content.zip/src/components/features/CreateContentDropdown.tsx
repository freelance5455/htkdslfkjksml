import { useState, useRef, useEffect, useMemo } from "react";
import { createPortal } from "react-dom";
import { useNavigate } from "react-router-dom";
import {
  Plus,
  ChevronDown,
  Cpu,
  Sparkles,
  ArrowRight,
  Settings,
  Zap,
  CheckCircle2,
  X,
  Search,
  Sliders,
  Filter,
} from "lucide-react";
import { cn } from "@/lib/utils";
import {
  AI_PROVIDERS,
  type AIProviderOption,
  type AIProviderCategoryId,
} from "@/constants/aiProviders";

export type { AIProviderOption };

interface CreateContentDropdownProps {
  id?: string;
  variant?: "header" | "hero" | "compact";
  buttonText?: string;
  className?: string;
  onSelect?: (provider: AIProviderOption) => void;
}

type CategoryFilter = "ALL" | AIProviderCategoryId;

const CATEGORY_TABS: { id: CategoryFilter; label: string; count?: number }[] = [
  { id: "ALL", label: "Todos os Motores" },
  { id: "ORCHESTRATOR", label: "Auto Orquestrador" },
  { id: "TEXT", label: "Roteiro & Texto" },
  { id: "VIDEO", label: "Vídeo Cinemático" },
  { id: "IMAGE", label: "Imagens 4K" },
  { id: "VOICE", label: "Voz Neural" },
  { id: "AVATAR", label: "Avatar & Host" },
  { id: "RENDER", label: "Render & FFmpeg" },
];

export default function CreateContentDropdown({
  id = "btn-criar-conteudo",
  variant = "header",
  buttonText,
  className,
  onSelect,
}: CreateContentDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<CategoryFilter>("ALL");
  const searchInputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  // Manage body scrolling when modal is open
  useEffect(() => {
    if (isOpen) {
      const prevOverflow = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      // Auto-focus search input after short transition
      const timer = setTimeout(() => {
        searchInputRef.current?.focus();
      }, 100);
      return () => {
        document.body.style.overflow = prevOverflow;
        clearTimeout(timer);
      };
    }
  }, [isOpen]);

  // Close on Escape key
  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape" && isOpen) {
        setIsOpen(false);
      }
    }
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen]);

  const handleSelectProvider = (provider: AIProviderOption) => {
    setIsOpen(false);
    if (onSelect) {
      onSelect(provider);
      return;
    }
    const params = new URLSearchParams({
      provider: provider.id,
      model: provider.model,
    });
    if (provider.defaultVideoEngine) {
      params.set("videoEngine", provider.defaultVideoEngine);
    }
    if (provider.defaultImageEngine) {
      params.set("imageEngine", provider.defaultImageEngine);
    }
    navigate(`/creator?${params.toString()}`);
  };

  const handleOpenFreeCreator = () => {
    setIsOpen(false);
    navigate("/creator");
  };

  const handleOpenSettings = () => {
    setIsOpen(false);
    navigate("/settings");
  };

  // Filtered providers based on search query and category tab
  const filteredProviders = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    return AI_PROVIDERS.filter((provider) => {
      // Category filter
      if (selectedCategory !== "ALL" && provider.category !== selectedCategory) {
        return false;
      }
      // Text search
      if (!q) return true;
      return (
        provider.name.toLowerCase().includes(q) ||
        provider.providerCompany.toLowerCase().includes(q) ||
        provider.subtitle.toLowerCase().includes(q) ||
        provider.categoryLabel.toLowerCase().includes(q) ||
        provider.tag.toLowerCase().includes(q) ||
        provider.model.toLowerCase().includes(q)
      );
    });
  }, [searchQuery, selectedCategory]);

  const isHero = variant === "hero";
  const isHeader = variant === "header";

  return (
    <>
      {/* Trigger Button */}
      <button
        id={id}
        type="button"
        onClick={() => setIsOpen(true)}
        aria-expanded={isOpen}
        aria-haspopup="dialog"
        className={cn(
          "inline-flex items-center justify-center font-semibold transition-all select-none cursor-pointer",
          isHero &&
            "btn-gold text-sm py-2.5 px-5 sm:px-6 gap-2 glow-gold shadow-lg shadow-studio-gold/20 w-full sm:w-auto",
          isHeader &&
            "btn-gold text-xs sm:text-sm py-2 px-3 sm:px-4 gap-1.5 shadow-md shadow-studio-gold/15",
          variant === "compact" &&
            "btn-gold text-xs py-2 px-3.5 gap-1.5 shadow-sm",
          className
        )}
      >
        <Plus className={cn("shrink-0", isHero ? "w-4 h-4" : "w-3.5 h-3.5")} />
        <span>
          {buttonText || (
            <>
              <span className="hidden sm:inline">Criar Conteúdo</span>
              <span className="sm:hidden">Criar</span>
            </>
          )}
        </span>
        <ChevronDown
          className={cn(
            "shrink-0 transition-transform duration-200 opacity-80",
            isHero ? "w-4 h-4 ml-1" : "w-3.5 h-3.5 ml-0.5",
            isOpen ? "rotate-180" : "rotate-0"
          )}
        />
      </button>

      {/* AI Providers Modal Overlay (Rendered into document.body to prevent clipping) */}
      {isOpen &&
        typeof document !== "undefined" &&
        createPortal(
          <div
            className="fixed inset-0 z-[9999] flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md animate-in fade-in-0 duration-200"
            role="dialog"
            aria-modal="true"
            aria-labelledby="ai-providers-modal-title"
            onClick={(e) => {
              if (e.target === e.currentTarget) setIsOpen(false);
            }}
          >
            {/* Modal Container */}
            <div
              className="w-full max-w-3xl max-h-[92vh] sm:max-h-[88vh] rounded-2xl bg-studio-surface border border-studio-border/90 shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-200"
              style={{
                backgroundColor: "rgba(16, 20, 26, 0.98)",
                boxShadow:
                  "0 25px 60px -15px rgba(0, 0, 0, 0.95), 0 0 35px rgba(229, 169, 60, 0.18)",
              }}
            >
              {/* Header */}
              <div className="p-4 sm:p-5 border-b border-studio-border/80 bg-studio-panel/50 shrink-0">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-studio-gold/15 border border-studio-gold/40 flex items-center justify-center text-studio-gold shrink-0 mt-0.5 shadow-sm">
                      <Cpu className="w-5 h-5 animate-pulse" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h2
                          id="ai-providers-modal-title"
                          className="text-base sm:text-lg font-bold font-display text-studio-text"
                        >
                          Provedores de Inteligência Artificial
                        </h2>
                        <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-[10px] font-mono font-bold">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping inline-block" />
                          <span>8 Motores Operacionais</span>
                        </span>
                      </div>
                      <p className="text-xs text-studio-text-muted mt-1 leading-snug">
                        Selecione a IA ideal para orquestrar o seu novo projeto, roteirizar, gerar vídeos cinematográficos, imagens 4K ou narração.
                      </p>
                    </div>
                  </div>

                  {/* Close Button */}
                  <button
                    type="button"
                    onClick={() => setIsOpen(false)}
                    className="p-2 rounded-xl text-studio-text-muted hover:text-studio-text hover:bg-studio-panel border border-transparent hover:border-studio-border transition-all shrink-0 cursor-pointer"
                    aria-label="Fechar janela"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Search & Filter Controls */}
                <div className="mt-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-studio-text-muted absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      ref={searchInputRef}
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Buscar por IA (ex: Gemini, PixVerse, Runway, ElevenLabs, Imagens 4K)..."
                      className="studio-input text-xs pl-9 pr-8 py-2 w-full bg-studio-surface/90"
                    />
                    {searchQuery && (
                      <button
                        type="button"
                        onClick={() => setSearchQuery("")}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-studio-text-muted hover:text-studio-text p-0.5"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Category Pills Bar */}
                <div className="mt-3 flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                  {CATEGORY_TABS.map((tab) => {
                    const isSelected = selectedCategory === tab.id;
                    return (
                      <button
                        key={tab.id}
                        type="button"
                        onClick={() => setSelectedCategory(tab.id)}
                        className={cn(
                          "px-2.5 py-1 rounded-lg text-xs font-mono whitespace-nowrap transition-all cursor-pointer shrink-0 border",
                          isSelected
                            ? "bg-studio-gold text-black border-studio-gold font-bold shadow-sm shadow-studio-gold/20"
                            : "bg-studio-surface text-studio-text-muted hover:text-studio-text hover:bg-studio-panel border-studio-border/70"
                        )}
                      >
                        {tab.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Modal Body / Providers Grid */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3.5 custom-scrollbar">
                {/* Featured Multimodal Hero Card (Shown when searching includes all or category is ALL/ORCHESTRATOR) */}
                {(selectedCategory === "ALL" || selectedCategory === "ORCHESTRATOR") &&
                  !searchQuery && (
                    <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-studio-gold/20 via-amber-500/10 to-transparent border border-studio-gold/60 shadow-lg shadow-studio-gold/10 relative overflow-hidden group">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div className="flex items-start gap-3.5 min-w-0">
                          <div className="w-12 h-12 rounded-2xl bg-studio-gold/25 border border-studio-gold/60 flex items-center justify-center shrink-0 text-studio-gold shadow-md">
                            <Sparkles className="w-6 h-6 animate-pulse" />
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-base font-bold text-studio-text group-hover:text-studio-gold transition-colors font-display">
                                Orquestrador Multimodal (Auto IA)
                              </span>
                              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-studio-gold/25 text-studio-gold border border-studio-gold/50">
                                RECOMENDADO
                              </span>
                            </div>
                            <p className="text-xs text-studio-text-dim mt-1 max-w-xl leading-relaxed">
                              Combina automaticamente as melhores IAs: <strong>Google Gemini 3.7</strong> para roteiros inteligentes, <strong>PixVerse V3.5</strong> para vídeo 1080p, <strong>Imagens 4K</strong>, <strong>Voz Neural</strong> e montagem <strong>FFmpeg</strong>.
                            </p>
                            <div className="mt-2 flex items-center gap-2 flex-wrap text-[11px] font-mono text-studio-gold/90">
                              <span className="flex items-center gap-1">
                                <Zap className="w-3.5 h-3.5" /> Pipeline de Alta Velocidade
                              </span>
                              <span>•</span>
                              <span>16:9, 9:16 ou 1:1</span>
                              <span>•</span>
                              <span>Todas as Redes</span>
                            </div>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleSelectProvider(AI_PROVIDERS[0])}
                          className="btn-gold text-xs sm:text-sm py-2.5 px-4 sm:px-5 gap-2 shrink-0 self-stretch sm:self-center shadow-md shadow-studio-gold/20"
                        >
                          <span>Iniciar Criação Completa</span>
                          <ArrowRight className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  )}

                {/* Section Title */}
                <div className="flex items-center justify-between pt-1">
                  <span className="text-xs font-bold font-mono uppercase tracking-wider text-studio-text-muted flex items-center gap-1.5">
                    <Filter className="w-3.5 h-3.5 text-studio-gold" />
                    <span>
                      {selectedCategory === "ALL"
                        ? `Todos os Provedores Disponíveis (${filteredProviders.length})`
                        : `Provedores em ${CATEGORY_TABS.find((t) => t.id === selectedCategory)?.label} (${filteredProviders.length})`}
                    </span>
                  </span>
                  {searchQuery && (
                    <span className="text-xs font-mono text-studio-gold">
                      Filtro: &quot;{searchQuery}&quot;
                    </span>
                  )}
                </div>

                {/* Grid of Providers */}
                {filteredProviders.length === 0 ? (
                  <div className="text-center py-12 px-4 rounded-xl border border-studio-border bg-studio-panel/50 space-y-2">
                    <Cpu className="w-10 h-10 text-studio-text-muted mx-auto opacity-50" />
                    <h3 className="text-sm font-semibold text-studio-text">
                      Nenhum provedor de IA encontrado
                    </h3>
                    <p className="text-xs text-studio-text-muted max-w-sm mx-auto">
                      Não encontramos provedores compatíveis com &quot;{searchQuery}&quot;. Tente outro termo ou limpe os filtros.
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        setSearchQuery("");
                        setSelectedCategory("ALL");
                      }}
                      className="mt-3 px-3 py-1.5 rounded-lg bg-studio-panel border border-studio-border text-xs text-studio-gold hover:underline cursor-pointer"
                    >
                      Limpar Filtros de Busca
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {filteredProviders.map((provider) => {
                      const Icon = provider.icon;
                      return (
                        <div
                          key={provider.id}
                          onClick={() => handleSelectProvider(provider)}
                          role="button"
                          tabIndex={0}
                          onKeyDown={(e) => {
                            if (e.key === "Enter" || e.key === " ") {
                              e.preventDefault();
                              handleSelectProvider(provider);
                            }
                          }}
                          className={cn(
                            "p-3.5 sm:p-4 rounded-xl bg-studio-panel/90 hover:bg-studio-panel border transition-all text-left group flex flex-col justify-between cursor-pointer relative overflow-hidden shadow-sm hover:shadow-md",
                            provider.borderColor
                          )}
                        >
                          <div>
                            {/* Top row: Icon + Category + Status */}
                            <div className="flex items-start justify-between gap-2 mb-2.5">
                              <div className="flex items-center gap-2.5">
                                <div
                                  className={cn(
                                    "w-9 h-9 rounded-xl flex items-center justify-center shrink-0 transition-transform group-hover:scale-105 shadow-sm",
                                    provider.bgLight
                                  )}
                                >
                                  <Icon className={cn("w-4 h-4", provider.color)} />
                                </div>
                                <div>
                                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-studio-surface border border-studio-border text-studio-text-muted">
                                    {provider.categoryLabel}
                                  </span>
                                  <span className="text-[10px] font-mono text-studio-text-muted block mt-0.5">
                                    {provider.providerCompany}
                                  </span>
                                </div>
                              </div>

                              <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center gap-1 shrink-0">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block" />
                                {provider.badge}
                              </span>
                            </div>

                            {/* Name & Subtitle */}
                            <h3 className="text-sm font-bold text-studio-text group-hover:text-studio-gold transition-colors">
                              {provider.name}
                            </h3>
                            <p className="text-xs text-studio-text-dim mt-1 leading-relaxed line-clamp-2">
                              {provider.subtitle}
                            </p>
                          </div>

                          {/* Card bottom: tag & action arrow */}
                          <div className="mt-3 pt-2.5 border-t border-studio-border/60 flex items-center justify-between text-xs">
                            <span className="text-[10px] font-mono text-studio-text-muted truncate max-w-[190px]">
                              {provider.tag}
                            </span>
                            <span className="text-xs font-semibold text-studio-gold flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                              <span>Selecionar</span>
                              <ArrowRight className="w-3.5 h-3.5" />
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Modal Footer */}
              <div className="p-3.5 sm:p-4 border-t border-studio-border/80 bg-studio-panel/70 shrink-0 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
                <div className="flex items-center gap-3 flex-wrap">
                  <button
                    type="button"
                    onClick={handleOpenFreeCreator}
                    className="text-xs text-studio-text-muted hover:text-studio-gold flex items-center gap-1.5 transition-colors cursor-pointer py-1"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-studio-gold" />
                    <span>Abrir Criador Livre (Prompt Direto)</span>
                  </button>
                  <span className="hidden sm:inline text-studio-border">|</span>
                  <button
                    type="button"
                    onClick={handleOpenSettings}
                    className="text-xs text-studio-blue hover:underline flex items-center gap-1.5 transition-colors cursor-pointer py-1"
                  >
                    <Settings className="w-3.5 h-3.5" />
                    <span>Gerenciar Chaves de IA</span>
                  </button>
                </div>

                <div className="flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsOpen(false)}
                    className="px-4 py-2 rounded-xl text-xs font-semibold bg-studio-surface border border-studio-border text-studio-text-muted hover:text-studio-text hover:bg-studio-panel transition-all cursor-pointer"
                  >
                    Fechar
                  </button>
                </div>
              </div>
            </div>
          </div>,
          document.body
        )}
    </>
  );
}
