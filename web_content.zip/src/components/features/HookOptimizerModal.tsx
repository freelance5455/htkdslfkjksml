// ============================================================
// AI CREATOR STUDIO — CORE 3.0 HOOK OPTIMIZER MODAL
// Multi-formula high-retention opening generator with 1-click apply
// ============================================================

import { useState, useEffect } from "react";
import {
  Zap, Sparkles, CheckCircle2, Eye, HelpCircle,
  TrendingUp, X, Check, RefreshCw
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { HookVariant } from "@/types/core3";
import type { Project } from "@/types/index";
import { generateHookVariants } from "@/lib/core3/hookOptimizer";
import { saveProject } from "@/lib/storage";

interface HookOptimizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: Project;
  onHookApplied?: (newHook: string) => void;
}

export default function HookOptimizerModal({
  isOpen,
  onClose,
  project,
  onHookApplied,
}: HookOptimizerModalProps) {
  const [variants, setVariants] = useState<HookVariant[]>([]);
  const [loading, setLoading] = useState(true);
  const [appliedId, setAppliedId] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    if (isOpen && project) {
      setLoading(true);
      generateHookVariants(project)
        .then((list) => {
          if (isMounted) setVariants(list);
        })
        .catch((err) => {
          console.error("Erro ao gerar variações de hook:", err);
        })
        .finally(() => {
          if (isMounted) setLoading(false);
        });
    }
    return () => {
      isMounted = false;
    };
  }, [isOpen, project]);

  if (!isOpen || !project) return null;

  const handleApplyHook = (variant: HookVariant) => {
    setAppliedId(variant.id);
    if (project.script && project.script.sections && project.script.sections.length > 0) {
      project.script.sections[0].narration = variant.hookText;
      project.script.sections[0].visualPrompt = variant.visualDirection;
      saveProject(project);
    }
    if (onHookApplied) {
      onHookApplied(variant.hookText);
    }
    setTimeout(() => {
      onClose();
    }, 800);
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="studio-card w-full max-w-3xl max-h-[90vh] flex flex-col border border-studio-border shadow-2xl overflow-hidden animate-fadeIn">
        {/* Header */}
        <div className="p-5 border-b border-studio-border flex items-center justify-between bg-studio-panel shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-studio-purple to-studio-blue flex items-center justify-center text-white shadow-md">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-studio-text font-display">
                Otimizador de Ganchos (Hook Optimizer)
              </h2>
              <p className="text-xs text-studio-text-muted">
                5 fórmulas testadas para maximizar a retenção nos primeiros 5 segundos
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-studio-text-muted hover:text-studio-text hover:bg-studio-border transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          {loading ? (
            <div className="py-16 text-center space-y-3">
              <RefreshCw className="w-8 h-8 text-studio-blue animate-spin mx-auto" />
              <p className="text-xs text-studio-text-muted">
                Gerando aberturas de alto impacto com IA psicológica...
              </p>
            </div>
          ) : (
            variants.map((v) => (
              <div
                key={v.id}
                className={cn(
                  "p-4 rounded-xl border transition-all space-y-3",
                  appliedId === v.id
                    ? "bg-studio-green/10 border-studio-green/50"
                    : "bg-studio-panel border-studio-border hover:border-studio-blue/40"
                )}
              >
                {/* Formula Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-studio-purple">
                      {v.formulaLabel}
                    </span>
                  </div>

                  <span className="text-xs font-bold font-mono text-studio-green bg-studio-green/10 px-2 py-0.5 rounded-full">
                    Retenção Est.: {v.estimatedRetentionScore}%
                  </span>
                </div>

                {/* Hook Speech */}
                <div className="p-3 rounded-lg bg-studio-bg border border-studio-border/60">
                  <p className="text-xs font-semibold text-studio-text leading-relaxed">
                    "{v.hookText}"
                  </p>
                </div>

                {/* Visual Direction */}
                <div className="text-[11px] text-studio-text-muted flex items-start gap-1.5">
                  <Eye className="w-3.5 h-3.5 text-studio-blue shrink-0 mt-0.5" />
                  <span><strong>Direção Visual:</strong> {v.visualDirection}</span>
                </div>

                {/* Apply Button */}
                <div className="pt-2 flex items-center justify-between border-t border-studio-border/40">
                  <span className="text-[10px] text-studio-text-muted">
                    {v.targetAudienceAppeal}
                  </span>

                  <button
                    onClick={() => handleApplyHook(v)}
                    disabled={appliedId === v.id}
                    className={cn(
                      "btn-primary text-xs py-1.5 px-3 gap-1",
                      appliedId === v.id && "bg-studio-green text-white"
                    )}
                  >
                    {appliedId === v.id ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        Gancho Aplicado!
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3.5 h-3.5" />
                        Aplicar ao Roteiro
                      </>
                    )}
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-studio-border bg-studio-panel flex items-center justify-between shrink-0">
          <button
            onClick={loadHooks}
            disabled={loading}
            className="btn-secondary text-xs py-2 px-3 gap-1.5"
          >
            <RefreshCw className={cn("w-3.5 h-3.5", loading && "animate-spin")} />
            Regenerar Variações
          </button>

          <button onClick={onClose} className="btn-secondary text-xs py-2 px-4">
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
}
