import { useState } from "react";
import type { Project, Platform } from "@/types";
import type {
  ContentPackage,
  PlatformMetadata,
  BuildPackageOptions,
} from "@/types/contentPackage";
import {
  ContentPackageBuilder,
  PLATFORM_CATEGORIES,
} from "@/lib/contentPackageBuilder";
import { cn } from "@/lib/utils";
import {
  PackageCheck, Sparkles, Copy, Check, Share2, Globe,
  Youtube, Tag, FileText, Layers, CheckCircle2,
  RefreshCw, Download, Hash, Bookmark,
  Sliders, MessageSquare, Video
} from "lucide-react";

interface ContentPackageBuilderViewProps {
  project: Project;
  onProjectUpdate?: (updated: Project) => void;
}

export default function ContentPackageBuilderView({
  project,
  onProjectUpdate,
}: ContentPackageBuilderViewProps) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedPlatform, setSelectedPlatform] = useState<Platform>(
    project.platform || "YOUTUBE"
  );
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [packageData, setPackageData] = useState<ContentPackage | null>(
    project.contentPackage || null
  );

  // Form states for manual overrides
  const [customTitle] = useState("");
  const [customDesc] = useState("");
  const [customTagInput] = useState("");
  const [selectedCategory] = useState("");

  const handleBuildPackage = async () => {
    setIsGenerating(true);
    try {
      const options: BuildPackageOptions = {
        customTitle: customTitle || undefined,
        customDescription: customDesc || undefined,
        additionalTags: customTagInput
          ? customTagInput.split(",").map((s) => s.trim()).filter(Boolean)
          : undefined,
        selectedCategory: selectedCategory || undefined,
      };

      const result = await ContentPackageBuilder.buildPackage(project, options);
      setPackageData(result);

      const updated = ContentPackageBuilder.savePackageToProject(project.id, result);
      if (updated && onProjectUpdate) {
        onProjectUpdate(updated);
      }
    } catch (error) {
      console.error("Erro ao gerar pacote de conteúdo:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const activeMeta: PlatformMetadata | undefined = packageData?.packages?.[selectedPlatform];

  const handleUpdateActiveMeta = <K extends keyof PlatformMetadata>(
    field: K,
    val: PlatformMetadata[K]
  ) => {
    if (!packageData || !activeMeta) return;
    const updatedMeta: PlatformMetadata = { ...activeMeta, [field]: val };
    const updatedPkg: ContentPackage = {
      ...packageData,
      packages: {
        ...packageData.packages,
        [selectedPlatform]: updatedMeta,
      },
      updatedAt: new Date().toISOString(),
    };
    setPackageData(updatedPkg);
    const updated = ContentPackageBuilder.savePackageToProject(project.id, updatedPkg);
    if (updated && onProjectUpdate) {
      onProjectUpdate(updated);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Banner */}
      <div className="studio-card p-5 sm:p-6 bg-gradient-to-r from-studio-surface via-studio-surface to-studio-panel border-studio-border">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-studio-blue/15 text-studio-blue flex items-center justify-center">
                <PackageCheck className="w-4 h-4" />
              </div>
              <h2 className="text-lg font-bold text-studio-text font-display">
                Content Package Builder
              </h2>
              <span className="task-badge text-[11px] bg-studio-blue/15 text-studio-blue border-studio-blue/30">
                Multiplataforma SEO
              </span>
            </div>
            <p className="text-xs text-studio-text-muted max-w-2xl">
              Transforme o projeto finalizado em um pacote de publicação pronto para lançamento contendo títulos otimizados para CTR, descrições ricas, tags para algoritmos e categorização precisa.
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              onClick={handleBuildPackage}
              disabled={isGenerating}
              className="btn-primary text-xs py-2.5 px-4 flex items-center gap-2 shadow-lg shadow-studio-blue/10"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Construindo Pacote...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{packageData ? "Regenerar Metadados AI" : "Gerar Pacote de Publicação"}</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Readiness Checklist bar */}
        {packageData && (
          <div className="mt-5 pt-4 border-t border-studio-border/70 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="p-2.5 rounded-lg bg-studio-panel border border-studio-border flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-studio-green/15 text-studio-green flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[10px] text-studio-text-muted block">Prontidão para Lançamento</span>
                <span className="font-bold text-studio-text">{packageData.readinessScore}% Otimizado</span>
              </div>
            </div>

            <div className="p-2.5 rounded-lg bg-studio-panel border border-studio-border flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-studio-purple/15 text-studio-purple flex items-center justify-center shrink-0">
                <Tag className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[10px] text-studio-text-muted block">Tags & Palavras-Chave</span>
                <span className="font-bold text-studio-text">{packageData.keywords.length} Indexadas</span>
              </div>
            </div>

            <div className="p-2.5 rounded-lg bg-studio-panel border border-studio-border flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-studio-gold/15 text-studio-gold flex items-center justify-center shrink-0">
                <Layers className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[10px] text-studio-text-muted block">Headline de Thumbnail</span>
                <span className="font-bold text-studio-text truncate block max-w-[120px]">
                  {packageData.thumbnailHeadline || "Definida"}
                </span>
              </div>
            </div>

            <div className="p-2.5 rounded-lg bg-studio-panel border border-studio-border flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-studio-blue/15 text-studio-blue flex items-center justify-center shrink-0">
                <Share2 className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[10px] text-studio-text-muted block">Plataformas Prontas</span>
                <span className="font-bold text-studio-text">5 Formatos Ativos</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Platform Selector Tabs */}
      <div className="flex items-center gap-2 border-b border-studio-border pb-1 overflow-x-auto">
        {(["YOUTUBE", "TIKTOK", "INSTAGRAM", "FACEBOOK", "GENERAL"] as Platform[]).map((plat) => {
          const isActive = selectedPlatform === plat;
          return (
            <button
              key={plat}
              onClick={() => setSelectedPlatform(plat)}
              className={cn(
                "py-2 px-3.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all whitespace-nowrap",
                isActive
                  ? "bg-studio-surface text-studio-blue border border-studio-blue/40 shadow-xs"
                  : "text-studio-text-muted hover:text-studio-text hover:bg-studio-panel"
              )}
            >
              {plat === "YOUTUBE" && <Youtube className="w-3.5 h-3.5 text-red-500" />}
              {plat === "TIKTOK" && <Video className="w-3.5 h-3.5 text-cyan-400" />}
              {plat === "INSTAGRAM" && <Share2 className="w-3.5 h-3.5 text-pink-500" />}
              {plat === "FACEBOOK" && <Globe className="w-3.5 h-3.5 text-blue-500" />}
              {plat === "GENERAL" && <Layers className="w-3.5 h-3.5 text-studio-text-muted" />}
              <span>{plat}</span>
              {packageData?.packages?.[plat] && (
                <span className="w-1.5 h-1.5 rounded-full bg-studio-green"></span>
              )}
            </button>
          );
        })}
      </div>

      {/* Main Content: Metadata Details for Selected Platform */}
      {packageData && activeMeta ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left / Center: Interactive Metadata Fields */}
          <div className="lg:col-span-2 space-y-5">
            {/* Title Section */}
            <div className="studio-card p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-studio-blue" />
                  <label className="text-xs font-bold text-studio-text uppercase tracking-wider">
                    Título de Publicação ({selectedPlatform})
                  </label>
                </div>
                <div className="flex items-center gap-2">
                  <span className={cn(
                    "text-[10px] font-mono",
                    activeMeta.title.length > activeMeta.characterCounts.titleMax
                      ? "text-red-400 font-bold"
                      : "text-studio-text-muted"
                  )}>
                    {activeMeta.title.length}/{activeMeta.characterCounts.titleMax} carac.
                  </span>
                  <button
                    onClick={() => copyToClipboard(activeMeta.title, "title")}
                    className="p-1 rounded text-studio-text-muted hover:text-studio-text hover:bg-studio-panel"
                    title="Copiar Título"
                  >
                    {copiedKey === "title" ? <Check className="w-3.5 h-3.5 text-studio-green" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <input
                type="text"
                value={activeMeta.title}
                onChange={(e) => handleUpdateActiveMeta("title", e.target.value)}
                className="input-field text-sm font-semibold w-full bg-studio-panel/60"
                placeholder="Insira o título otimizado..."
              />
            </div>

            {/* Category & Strategy Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="studio-card p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-studio-text uppercase tracking-wider flex items-center gap-1.5">
                    <Sliders className="w-3.5 h-3.5 text-studio-purple" />
                    Categoria da Plataforma
                  </label>
                  <button
                    onClick={() => copyToClipboard(activeMeta.category, "category")}
                    className="p-1 rounded text-studio-text-muted hover:text-studio-text"
                  >
                    {copiedKey === "category" ? <Check className="w-3.5 h-3.5 text-studio-green" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <select
                  value={activeMeta.category}
                  onChange={(e) => handleUpdateActiveMeta("category", e.target.value)}
                  className="input-field text-xs w-full bg-studio-panel"
                >
                  {(PLATFORM_CATEGORIES[selectedPlatform] || PLATFORM_CATEGORIES.GENERAL).map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div className="studio-card p-4 space-y-2">
                <label className="text-xs font-bold text-studio-text uppercase tracking-wider flex items-center gap-1.5">
                  <Bookmark className="w-3.5 h-3.5 text-studio-gold" />
                  Playlist Sugerida / Série
                </label>
                <input
                  type="text"
                  value={activeMeta.suggestedPlaylist || ""}
                  onChange={(e) => handleUpdateActiveMeta("suggestedPlaylist", e.target.value)}
                  className="input-field text-xs w-full bg-studio-panel"
                  placeholder="Nome da Playlist..."
                />
              </div>
            </div>

            {/* Tags & Keywords */}
            <div className="studio-card p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Tag className="w-4 h-4 text-studio-blue" />
                  <label className="text-xs font-bold text-studio-text uppercase tracking-wider">
                    Tags & Termos de Busca ({activeMeta.tags.length})
                  </label>
                </div>
                <button
                  onClick={() => copyToClipboard(activeMeta.tags.join(", "), "tags")}
                  className="text-xs text-studio-blue hover:underline flex items-center gap-1"
                >
                  {copiedKey === "tags" ? <Check className="w-3.5 h-3.5 text-studio-green" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>Copiar Todas as Tags</span>
                </button>
              </div>

              <div className="flex flex-wrap gap-1.5">
                {activeMeta.tags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-studio-panel border border-studio-border text-xs text-studio-text"
                  >
                    <Hash className="w-3 h-3 text-studio-text-muted" />
                    <span>{tag}</span>
                  </span>
                ))}
              </div>

              {/* Hashtags display */}
              {activeMeta.hashtags && activeMeta.hashtags.length > 0 && (
                <div className="pt-2 border-t border-studio-border/60 flex items-center justify-between text-xs">
                  <span className="text-studio-text-muted font-medium">Hashtags recomendadas:</span>
                  <div className="flex gap-1.5 flex-wrap">
                    {activeMeta.hashtags.map((h, i) => (
                      <span key={i} className="text-studio-blue font-mono text-[11px]">
                        {h.startsWith("#") ? h : `#${h}`}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Full Description Section */}
            <div className="studio-card p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-studio-purple" />
                  <label className="text-xs font-bold text-studio-text uppercase tracking-wider">
                    Descrição Completa Otimizada
                  </label>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono text-studio-text-muted">
                    {activeMeta.description.length}/{activeMeta.characterCounts.descriptionMax} carac.
                  </span>
                  <button
                    onClick={() => copyToClipboard(activeMeta.description, "desc")}
                    className="btn-secondary text-[11px] py-1 px-2.5 flex items-center gap-1"
                  >
                    {copiedKey === "desc" ? <Check className="w-3 h-3 text-studio-green" /> : <Copy className="w-3 h-3" />}
                    <span>Copiar Descrição</span>
                  </button>
                </div>
              </div>

              <textarea
                rows={8}
                value={activeMeta.description}
                onChange={(e) => handleUpdateActiveMeta("description", e.target.value)}
                className="input-field text-xs leading-relaxed w-full bg-studio-panel font-mono"
                placeholder="Insira a descrição completa..."
              />
            </div>

            {/* Pinned Comment & CTA */}
            {activeMeta.pinnedComment && (
              <div className="studio-card p-4 space-y-2 bg-studio-panel/40">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-studio-text uppercase tracking-wider flex items-center gap-1.5">
                    <MessageSquare className="w-3.5 h-3.5 text-studio-gold" />
                    Comentário Fixado Sugerido (Para Engajamento)
                  </span>
                  <button
                    onClick={() => copyToClipboard(activeMeta.pinnedComment || "", "pinned")}
                    className="p-1 rounded text-studio-text-muted hover:text-studio-text"
                  >
                    {copiedKey === "pinned" ? <Check className="w-3.5 h-3.5 text-studio-green" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <p className="text-xs text-studio-text-dim italic bg-studio-surface p-2.5 rounded-lg border border-studio-border">
                  "{activeMeta.pinnedComment}"
                </p>
              </div>
            )}
          </div>

          {/* Right Sidebar: Packaging Quick-Actions & Multi-Platform Exporter */}
          <div className="space-y-5">
            {/* Thumbnail Text Hook */}
            <div className="studio-card p-4 space-y-3 border-studio-gold/30 bg-studio-gold/5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-studio-gold uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  Texto de Capa / Thumbnail
                </span>
              </div>
              <div className="p-3 bg-studio-surface rounded-xl border border-studio-border text-center space-y-1">
                <span className="text-sm font-black text-studio-text tracking-wide uppercase font-display block">
                  {packageData.thumbnailHeadline}
                </span>
                {packageData.thumbnailSubheadline && (
                  <span className="text-xs text-studio-gold font-medium block">
                    {packageData.thumbnailSubheadline}
                  </span>
                )}
              </div>
              <p className="text-[11px] text-studio-text-muted leading-tight">
                Frase de alto impacto visual recomendada para inserir na imagem da miniatura.
              </p>
            </div>

            {/* Publishing Advice & Optimal Timing */}
            <div className="studio-card p-4 space-y-3">
              <span className="text-xs font-bold text-studio-text uppercase tracking-wider block">
                Diretrizes de Publicação
              </span>

              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between p-2 rounded bg-studio-panel border border-studio-border">
                  <span className="text-studio-text-muted">Proporção Ideal:</span>
                  <span className="font-semibold text-studio-text">{activeMeta.aspectRatio}</span>
                </div>
                <div className="flex items-center justify-between p-2 rounded bg-studio-panel border border-studio-border">
                  <span className="text-studio-text-muted">Classificação:</span>
                  <span className="font-semibold text-studio-green">Livre para Todos</span>
                </div>
                <div className="flex items-center justify-between p-2 rounded bg-studio-panel border border-studio-border">
                  <span className="text-studio-text-muted">Visibilidade:</span>
                  <span className="font-semibold text-studio-blue">Público</span>
                </div>
                {activeMeta.optimalPostingTimes && (
                  <div className="p-2 rounded bg-studio-panel border border-studio-border space-y-1">
                    <span className="text-studio-text-muted block text-[10px]">Melhores Horários de Postagem:</span>
                    <div className="flex gap-1.5">
                      {activeMeta.optimalPostingTimes.map((t, i) => (
                        <span key={i} className="px-1.5 py-0.5 rounded bg-studio-surface text-studio-text font-mono text-[10px] font-bold">
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Master Export Kit */}
            <div className="studio-card p-4 space-y-3">
              <span className="text-xs font-bold text-studio-text uppercase tracking-wider block">
                Exportar para Publicação
              </span>
              <p className="text-xs text-studio-text-muted leading-relaxed">
                Copie o pacote estruturado completo para colar diretamente no painel do YouTube Studio, TikTok Creator Hub ou Meta Business Suite.
              </p>

              <button
                onClick={() =>
                  copyToClipboard(
                    ContentPackageBuilder.formatForClipboard(packageData, selectedPlatform),
                    "master_export"
                  )
                }
                className="w-full btn-secondary text-xs py-2.5 flex items-center justify-center gap-2"
              >
                {copiedKey === "master_export" ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-studio-green" />
                    <span>Copiado com Sucesso!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copiar Kit Completo ({selectedPlatform})</span>
                  </>
                )}
              </button>

              <button
                onClick={() => {
                  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(packageData, null, 2));
                  const downloadAnchor = document.createElement("a");
                  downloadAnchor.setAttribute("href", dataStr);
                  downloadAnchor.setAttribute("download", `content_package_${project.id}.json`);
                  document.body.appendChild(downloadAnchor);
                  downloadAnchor.click();
                  downloadAnchor.remove();
                }}
                className="w-full text-xs text-studio-text-muted hover:text-studio-text py-1.5 flex items-center justify-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Baixar Pacote JSON Completo</span>
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Empty State / Initial Trigger */
        <div className="studio-card p-12 text-center space-y-4 max-w-xl mx-auto">
          <div className="w-14 h-14 rounded-2xl bg-studio-blue/10 text-studio-blue flex items-center justify-center mx-auto">
            <PackageCheck className="w-7 h-7" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold text-studio-text">
              Nenhum Pacote de Publicação Gerado Ainda
            </h3>
            <p className="text-xs text-studio-text-muted leading-relaxed">
              Clique no botão abaixo para o <strong>ContentPackageBuilder</strong> analisar o roteiro, público-alvo e mídias do projeto para criar títulos magnéticos, descrições completas e tags em 5 formatos.
            </p>
          </div>
          <button
            onClick={handleBuildPackage}
            disabled={isGenerating}
            className="btn-primary text-xs py-2.5 px-6 mx-auto flex items-center gap-2"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Processando Metadados com IA...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5" />
                <span>Gerar Pacote de Conteúdo Agora</span>
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
}
