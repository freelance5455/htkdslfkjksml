// ============================================================
// AI CREATOR STUDIO — CORE 3.0 QUALITY SCORER MODAL
// Multi-metric Content Quality Scorer (Narrative, Hook, Audio, Visual, Pacing, Thumbnail, SEO, Brand)
// ============================================================

import { useState } from "react";
import {
  Award, CheckCircle2, AlertTriangle, ShieldCheck, Sparkles,
  ArrowRight, X, BarChart2, Zap
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { ContentQualityScore } from "@/types/core3";
import type { Project } from "@/types/index";
import { evaluateContentQuality } from "@/lib/core3/qualityScorer";

interface QualityScorerModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: Project;
  onOptimizeHook?: () => void;
}

export default function QualityScorerModal({
  isOpen,
  onClose,
  project,
  onOptimizeHook,
}: QualityScorerModalProps) {
  if (!isOpen || !project) return null;

  const score: ContentQualityScore = evaluateContentQuality(project);

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="studio-card w-full max-w-2xl max-h-[90vh] flex flex-col border border-studio-border shadow-2xl overflow-hidden animate-fadeIn">
        {/* Header */}
        <div className="p-5 border-b border-studio-border flex items-center justify-between bg-studio-panel shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-studio-gold to-studio-orange flex items-center justify-center text-black font-bold shadow-md">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-studio-text font-display">
                Auditoria de Qualidade do Conteúdo
              </h2>
              <p className="text-xs text-studio-text-muted">{project.title}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-studio-text-muted hover:text-studio-text hover:bg-studio-border transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* Overall Score */}
          <div className="p-5 rounded-2xl bg-studio-panel border border-studio-border flex items-center justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold text-studio-text-muted">
                Score Geral Ponderado (Qualidade Criativa & Técnica)
              </span>
              <p className="text-3xl font-bold text-studio-text font-display mt-0.5">
                {score.overallScore}<span className="text-base text-studio-text-muted">/100</span>
              </p>
              <p className="text-xs text-studio-green font-medium mt-1 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                {score.overallScore >= 75 ? "Aprovado para produção e publicação" : "Necessita otimizações antes de publicar"}
              </p>
            </div>

            <div className="text-right">
              <span className={cn(
                "px-3 py-1.5 rounded-xl text-xs font-bold font-mono",
                score.overallScore >= 90
                  ? "bg-studio-green/20 text-studio-green border border-studio-green/30"
                  : score.overallScore >= 75
                  ? "bg-studio-blue/20 text-studio-blue border border-studio-blue/30"
                  : "bg-yellow-500/20 text-yellow-400 border border-yellow-500/30"
              )}>
                {score.overallScore >= 90 ? "GRAU A+ (EXCELENTE)" : score.overallScore >= 75 ? "GRAU B (BOM)" : "GRAU C (POLIR)"}
              </span>
            </div>
          </div>

          {/* Breakdown by Dimensions */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-studio-text font-display uppercase tracking-wider">
              Detalhamento por Dimensões (9 Critérios)
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {Object.entries(score.dimensions).map(([key, dim]) => (
                <div key={key} className="p-3 rounded-xl bg-studio-panel border border-studio-border space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-studio-text">{dim.name}</span>
                    <span className="font-mono font-bold text-studio-gold">{dim.score.toFixed(1)}/10</span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-studio-bg overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-studio-blue to-studio-gold" style={{ width: `${(dim.score / 10) * 100}%` }} />
                  </div>
                  <p className="text-[11px] text-studio-text-muted line-clamp-1">{dim.feedback}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Actionable Recommendations */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-studio-text font-display uppercase tracking-wider">
              Sugestões de Polimento do Diretor Criativo
            </h3>

            <div className="space-y-2">
              {score.criticalFixes.map((fix, i) => (
                <div key={`fix-${i}`} className="p-3 rounded-xl bg-studio-red/10 border border-studio-red/30 flex items-start gap-2.5">
                  <AlertTriangle className="w-4 h-4 text-studio-red shrink-0 mt-0.5" />
                  <p className="text-xs text-studio-red leading-relaxed font-medium">{fix}</p>
                </div>
              ))}

              {score.polishSuggestions.map((rec, i) => (
                <div key={`rec-${i}`} className="p-3 rounded-xl bg-studio-panel border border-studio-border flex items-start gap-2.5">
                  <Sparkles className="w-4 h-4 text-studio-blue shrink-0 mt-0.5" />
                  <p className="text-xs text-studio-text-dim leading-relaxed">{rec}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-studio-border bg-studio-panel flex items-center justify-between shrink-0">
          {onOptimizeHook ? (
            <button
              onClick={() => {
                onClose();
                onOptimizeHook();
              }}
              className="btn-gold text-xs py-2 px-4 gap-1.5"
            >
              <Zap className="w-4 h-4" />
              Otimizar Gancho (Hook Optimizer)
            </button>
          ) : (
            <div />
          )}

          <button onClick={onClose} className="btn-secondary text-xs py-2 px-4">
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
}
