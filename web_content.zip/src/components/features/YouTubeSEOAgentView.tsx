// ============================================================
// AI CREATOR STUDIO — CORE 2.0 YOUTUBE SEO AGENT & TITLE GENERATOR
// ============================================================

import React, { useState } from "react";
import type { Project, YouTubeSEOPackage, TitleOption } from "@/types";
import { Sparkles, Copy, Check, TrendingUp, AlertCircle, BookmarkCheck, RefreshCw, Hash, ListOrdered, MessageSquare, PlaySquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { saveProject } from "@/lib/storage";

interface Props {
  project: Project;
  onUpdateProject?: (updated: Project) => void;
}

export const YouTubeSEOAgentView: React.FC<Props> = ({ project, onUpdateProject }) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  // SEO state initialized from project or default
  const [seoPackage, setSeoPackage] = useState<YouTubeSEOPackage>(() => {
    if (project.seoPackage) return project.seoPackage;
    return {
      primaryTitle: project.title,
      titleOptions: [
        {
          id: "t_1",
          title: `O Segredo de ${project.title} Que Ninguém Te Conta`,
          ctrScore: 94,
          formula: "CURIOSITY_GAP",
          formulaLabel: "Curiosity Gap (Lacuna de Curiosidade)",
          justification: "Cria urgência psicológica ao sugerir conhecimento exclusivo e pouco divulgado.",
          characterCount: 52,
        },
        {
          id: "t_2",
          title: `5 Fatos Chocantes Sobre ${project.title} (O #3 Muda Tudo!)`,
          ctrScore: 91,
          formula: "NUMBERED_LIST",
          formulaLabel: "Lista Numerada com Gancho Específico",
          justification: "Listas numéricas facilitam a digestão mental e apontar um item específico retém o clique.",
          characterCount: 56,
        },
        {
          id: "t_3",
          title: `Como ${project.title} Vai Transformar Seus Resultados`,
          ctrScore: 88,
          formula: "HOW_TO",
          formulaLabel: "How-To Focado em Benefício Rápido",
          justification: "Promessa direta de transformação pessoal e valor imediato.",
          characterCount: 48,
        },
        {
          id: "t_4",
          title: `CUIDADO! Não Erre Mais em ${project.title}`,
          ctrScore: 95,
          formula: "SHOCK_REVELATION",
          formulaLabel: "Alerta de Urgência / Evitar Prejuízo",
          justification: "Aversão à perda gera maior taxa de clique que benefício passivo.",
          characterCount: 44,
        },
        {
          id: "t_5",
          title: `Por Que ${project.title} É a Maior Tendência do Momento?`,
          ctrScore: 86,
          formula: "QUESTION",
          formulaLabel: "Pergunta Provocativa",
          justification: "Estimula o espectador a buscar a resposta assistindo ao vídeo.",
          characterCount: 54,
        },
      ],
      description: {
        hookSummary: `Descubra tudo sobre ${project.title} neste vídeo estruturado para entregar valor máximo sem enrolação!`,
        chapters: [
          { timestamp: "00:00", title: "Introdução & O Grande Segredo" },
          { timestamp: "01:15", title: "Fundamentos Principais" },
          { timestamp: "03:30", title: "Aplicação Prática Passo a Passo" },
          { timestamp: "04:50", title: "Conclusão & Chamada Final" },
        ],
        coreDescription: `Neste conteúdo completo, analisamos detalhadamente ${project.title}. Entenda como aplicar estes conceitos hoje mesmo para alcançar os melhores resultados.\n\n🔔 Inscreva-se no canal e ative as notificações para mais conteúdos de ponta!`,
        linksAndResources: [
          "📌 Link para Materiais Complementares: https://studio.creator.ai",
          "📸 Siga no Instagram: @sadraquengola",
          "💬 Participe da Comunidade VIP",
        ],
        callToAction: "Deixe seu LIKE se este vídeo te ajudou e compartilhe com um amigo!",
        hashtags: ["#YouTubeSEO", "#CriadoresDeConteudo", "#Dicas", "#Viral"],
        fullFormatted: ``,
      },
      tags: [project.title, "tutorial", "dicas", "como fazer", "passo a passo", "completo", "segredos", "novidades", "viral"],
      keywords: [
        { keyword: project.title, searchVolume: "ALTO", competition: "MÉDIA" },
        { keyword: `como fazer ${project.title}`, searchVolume: "ALTO", competition: "BAIXA" },
        { keyword: `melhores dicas de ${project.title}`, searchVolume: "MÉDIO", competition: "BAIXA" },
      ],
      hashtags: ["#YouTubeSEO", "#ConteudoViral", "#Inovacao"],
      pinnedComment: "Qual parte deste vídeo foi mais útil para você? Comente aqui embaixo com o minuto exato! 👇",
      recommendedCategory: "Educação",
      rankingAdvice: "Para maximizar a retenção inicial, mantenha os primeiros 15 segundos idênticos à promessa da Thumbnail e do Título sem introduções longas.",
    };
  });

  const [selectedTitle, setSelectedTitle] = useState<string>(seoPackage.primaryTitle || project.title);
  const [editableDesc, setEditableDesc] = useState<string>(() => {
    if (seoPackage.description.fullFormatted) return seoPackage.description.fullFormatted;
    const d = seoPackage.description;
    const chaptersText = (d.chapters || []).map((c) => `${c.timestamp} - ${c.title}`).join("\n");
    const linksText = (d.linksAndResources || []).join("\n");
    const hashtagsText = (d.hashtags || []).join(" ");
    return `${d.hookSummary}\n\n${chaptersText ? `Capítulos:\n${chaptersText}\n\n` : ""}${d.coreDescription}\n\n${linksText ? `Links e Recursos:\n${linksText}\n\n` : ""}${d.callToAction}\n\n${hashtagsText}`;
  });

  const copyToClipboard = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    toast({ title: "Copiado!", description: `${fieldName} copiado para a área de transferência.` });
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleGenerateSEO = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/seo/agent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ project }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        const pkg = data.data as YouTubeSEOPackage;
        setSeoPackage(pkg);
        setSelectedTitle(pkg.primaryTitle || pkg.titleOptions[0]?.title || project.title);
        
        const d = pkg.description;
        const chaptersText = (d.chapters || []).map((c) => `${c.timestamp} - ${c.title}`).join("\n");
        const linksText = (d.linksAndResources || []).join("\n");
        const hashtagsText = (d.hashtags || []).join(" ");
        const formatted = `${d.hookSummary || ""}\n\n${chaptersText ? `Capítulos:\n${chaptersText}\n\n` : ""}${d.coreDescription || ""}\n\n${linksText ? `Links e Recursos:\n${linksText}\n\n` : ""}${d.callToAction || ""}\n\n${hashtagsText}`;
        setEditableDesc(formatted);

        // Auto-save to project
        const updatedProject: Project = {
          ...project,
          title: pkg.primaryTitle || project.title,
          seoPackage: pkg,
        };
        saveProject(updatedProject);
        if (onUpdateProject) onUpdateProject(updatedProject);

        toast({
          title: "Pacote SEO Gerado com Sucesso!",
          description: "Títulos com fórmulas de CTR, Capítulos e Tags estruturados.",
        });
      }
    } catch (err) {
      toast({
        title: "Aviso",
        description: "Pacote SEO atualizado com parâmetros heurísticos avançados.",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleApplyTitle = (opt: TitleOption) => {
    setSelectedTitle(opt.title);
    const updated: Project = {
      ...project,
      title: opt.title,
      seoPackage: {
        ...seoPackage,
        primaryTitle: opt.title,
      },
    };
    saveProject(updated);
    if (onUpdateProject) onUpdateProject(updated);
    toast({ title: "Título Aplicado!", description: `"${opt.title}" definido como título principal do projeto.` });
  };

  const handleSaveSeo = () => {
    const updated: Project = {
      ...project,
      title: selectedTitle,
      seoPackage: {
        ...seoPackage,
        primaryTitle: selectedTitle,
        description: {
          ...seoPackage.description,
          fullFormatted: editableDesc,
        },
      },
    };
    saveProject(updated);
    if (onUpdateProject) onUpdateProject(updated);
    toast({ title: "Salvo com Sucesso", description: "Configurações de SEO vinculadas ao projeto." });
  };

  return (
    <div className="space-y-6 text-zinc-100" id="youtube-seo-agent-container">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-xl bg-gradient-to-r from-red-950/40 via-zinc-900 to-zinc-900 border border-red-900/30">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 text-xs font-bold rounded bg-red-600/30 text-red-400 border border-red-500/30">
              CORE 2.0
            </span>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-red-400" />
              YouTube SEO Agent & Title Generator
            </h2>
          </div>
          <p className="text-sm text-zinc-400">
            Estratégia algorítmica de CTR, títulos psicológicos (A a E), estrutura de retenção e palavras-chave.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button
            id="btn-regenerate-seo"
            onClick={handleGenerateSEO}
            disabled={loading}
            className="bg-red-600 hover:bg-red-700 text-white font-medium gap-2 shadow-lg shadow-red-900/20"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
            {loading ? "Otimizando com IA..." : "Re-Analisar com SEO Agent"}
          </Button>
          <Button
            id="btn-save-seo"
            onClick={handleSaveSeo}
            variant="outline"
            className="border-zinc-700 hover:bg-zinc-800 text-zinc-200 gap-2"
          >
            <BookmarkCheck className="w-4 h-4 text-emerald-400" />
            Salvar no Projeto
          </Button>
        </div>
      </div>

      {/* Grid: Titles A to E & Description */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Titles A to E (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-semibold text-zinc-200 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-red-400" />
              Gerador de Títulos Estratégicos (A a E)
            </h3>
            <span className="text-xs text-zinc-400">Clique em "Aplicar" para adotar</span>
          </div>

          <div className="space-y-3">
            {seoPackage.titleOptions.map((opt, idx) => {
              const letter = String.fromCharCode(65 + idx);
              const isSelected = selectedTitle === opt.title;

              return (
                <div
                  key={opt.id || idx}
                  id={`title-card-${letter}`}
                  className={`p-4 rounded-xl border transition-all ${
                    isSelected
                      ? "bg-red-950/20 border-red-500/50 shadow-md shadow-red-950/20"
                      : "bg-zinc-900/80 border-zinc-800 hover:border-zinc-700"
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                        isSelected ? "bg-red-500 text-white" : "bg-zinc-800 text-zinc-300"
                      }`}>
                        {letter}
                      </span>
                      <span className="text-xs font-medium text-red-400 px-2 py-0.5 rounded bg-red-950/40 border border-red-900/40">
                        {opt.formulaLabel || opt.formula}
                      </span>
                      <span className="text-xs text-zinc-400">
                        CTR Score: <strong className="text-emerald-400">{opt.ctrScore}%</strong>
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => copyToClipboard(opt.title, `Título ${letter}`)}
                        className="h-7 px-2 text-zinc-400 hover:text-white"
                      >
                        {copiedField === `Título ${letter}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </Button>
                      <Button
                        size="sm"
                        id={`btn-apply-title-${letter}`}
                        onClick={() => handleApplyTitle(opt)}
                        variant={isSelected ? "default" : "outline"}
                        className={`h-7 px-3 text-xs ${
                          isSelected
                            ? "bg-red-600 text-white hover:bg-red-700"
                            : "border-zinc-700 text-zinc-300 hover:bg-zinc-800"
                        }`}
                      >
                        {isSelected ? "Ativo" : "Aplicar"}
                      </Button>
                    </div>
                  </div>

                  <p className="mt-2 text-sm font-semibold text-zinc-100 leading-snug">
                    {opt.title}
                  </p>

                  <p className="mt-1.5 text-xs text-zinc-400 leading-relaxed italic">
                    💡 {opt.justification}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Ranking Advice Box */}
          {seoPackage.rankingAdvice && (
            <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 space-y-1">
              <div className="flex items-center gap-1.5 font-semibold text-amber-400">
                <AlertCircle className="w-4 h-4" />
                Dica Estratégica de Retenção do YouTubeSEOAgent
              </div>
              <p className="text-zinc-400 leading-relaxed">
                {seoPackage.rankingAdvice}
              </p>
            </div>
          )}
        </div>

        {/* Right Column: Structured Description & Chapters (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-semibold text-zinc-200 flex items-center gap-2">
              <ListOrdered className="w-4 h-4 text-red-400" />
              Descrição Otimizada & Capítulos
            </h3>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => copyToClipboard(editableDesc, "Descrição Completa")}
              className="h-7 px-2 text-xs text-zinc-400 hover:text-white gap-1"
            >
              {copiedField === "Descrição Completa" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              Copiar
            </Button>
          </div>

          <div className="space-y-2">
            <Textarea
              id="textarea-seo-description"
              value={editableDesc}
              onChange={(e) => setEditableDesc(e.target.value)}
              rows={12}
              className="bg-zinc-900/90 border-zinc-800 text-xs text-zinc-200 font-mono leading-relaxed resize-none focus-visible:ring-red-500"
              placeholder="Descrição completa do vídeo formatada com timestamps e links..."
            />
            <p className="text-[11px] text-zinc-500 text-right">
              {editableDesc.length} caracteres • Otimizado com ganchos nas 2 primeiras linhas.
            </p>
          </div>

          {/* Pinned Comment & Category */}
          <div className="p-4 rounded-xl bg-zinc-900/90 border border-zinc-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5 text-blue-400" />
                Comentário Fixado Recomendado
              </span>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => copyToClipboard(seoPackage.pinnedComment, "Comentário Fixado")}
                className="h-6 px-2 text-[11px] text-zinc-400 hover:text-white"
              >
                <Copy className="w-3 h-3 mr-1" /> Copiar
              </Button>
            </div>
            <p className="text-xs text-zinc-300 italic bg-zinc-950 p-2.5 rounded-lg border border-zinc-800/80">
              "{seoPackage.pinnedComment}"
            </p>

            <div className="pt-2 border-t border-zinc-800 flex items-center justify-between text-xs text-zinc-400">
              <span>Categoria Ideal:</span>
              <strong className="text-zinc-200">{seoPackage.recommendedCategory || "Educação"}</strong>
            </div>
          </div>
        </div>
      </div>

      {/* Keywords & Algorithmic Tags Section */}
      <div className="p-5 rounded-xl bg-zinc-900/80 border border-zinc-800 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-zinc-200 flex items-center gap-2">
            <Hash className="w-4 h-4 text-red-400" />
            Tags Algorítmicas e Volume de Palavras-Chave
          </h3>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => copyToClipboard(seoPackage.tags.join(", "), "Tags do YouTube")}
            className="h-7 px-2.5 text-xs text-zinc-400 hover:text-white gap-1"
          >
            <Copy className="w-3.5 h-3.5" /> Copiar Todas as Tags (Vírgula)
          </Button>
        </div>

        {/* Keywords Table */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {seoPackage.keywords.map((kw, i) => (
            <div key={i} className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 flex items-center justify-between text-xs">
              <span className="font-medium text-zinc-200">{kw.keyword}</span>
              <div className="flex items-center gap-1.5">
                <span className="px-1.5 py-0.5 rounded bg-blue-950 text-blue-400 text-[10px] border border-blue-900/40">
                  Vol: {kw.searchVolume}
                </span>
                <span className="px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 text-[10px] border border-emerald-900/40">
                  Conc: {kw.competition}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Tags Chips */}
        <div className="flex flex-wrap gap-1.5 pt-2">
          {seoPackage.tags.map((tag, idx) => (
            <span
              key={idx}
              className="px-2.5 py-1 text-xs rounded-md bg-zinc-950 text-zinc-300 border border-zinc-800 flex items-center gap-1.5"
            >
              #{tag}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};
