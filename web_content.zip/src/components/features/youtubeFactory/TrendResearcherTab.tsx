// ============================================================
// AI CREATOR STUDIO — YOUTUBE FACTORY: TREND RESEARCHER TAB
// Live topic radar with 8 scoring metrics, verified sources, and instant idea conversion
// ============================================================

import React, { useState } from "react";
import type { TrendTopic, TrendRanking, YouTubeChannelProject } from "@/types/youtubeFactory";
import {
  Flame,
  TrendingUp,
  Lightbulb,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  Sparkles,
  Search,
  ShieldCheck,
  Zap,
  ArrowRight,
  Filter,
  RefreshCw,
  Award,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface TrendResearcherTabProps {
  trends: TrendTopic[];
  channel: YouTubeChannelProject;
  onSelectTrendAsIdea: (trend: TrendTopic) => void;
  onRefreshTrends: () => void;
  isRefreshing: boolean;
}

export const TrendResearcherTab: React.FC<TrendResearcherTabProps> = ({
  trends,
  channel,
  onSelectTrendAsIdea,
  onRefreshTrends,
  isRefreshing,
}) => {
  const { toast } = useToast();
  const [selectedCategory, setSelectedCategory] = useState<string>("ALL");
  const [selectedRanking, setSelectedRanking] = useState<string>("ALL");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedTrendDetail, setSelectedTrendDetail] = useState<TrendTopic | null>(trends[0] || null);

  const categories = ["ALL", ...Array.from(new Set(trends.map((t) => t.nicheCategory)))];

  const filteredTrends = trends.filter((t) => {
    const matchCat = selectedCategory === "ALL" || t.nicheCategory === selectedCategory;
    const matchRank = selectedRanking === "ALL" || t.ranking === selectedRanking;
    const matchSearch =
      searchQuery.trim() === "" ||
      t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchCat && matchRank && matchSearch;
  });

  const getRankingBadge = (ranking: TrendRanking) => {
    switch (ranking) {
      case "HOT":
        return {
          icon: Flame,
          label: "🔥 HOT",
          className: "bg-red-500/20 text-red-400 border-red-500/30",
        };
      case "CRESCENTE":
        return {
          icon: TrendingUp,
          label: "📈 CRESCENTE",
          className: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
        };
      case "OPORTUNIDADE":
        return {
          icon: Lightbulb,
          label: "💡 OPORTUNIDADE",
          className: "bg-amber-500/20 text-amber-300 border-amber-500/30",
        };
      case "EVERGREEN":
        return {
          icon: CheckCircle2,
          label: "🟢 EVERGREEN",
          className: "bg-blue-500/20 text-blue-300 border-blue-500/30",
        };
      case "ALTO_RISCO":
        return {
          icon: AlertTriangle,
          label: "⚠️ ALTO RISCO",
          className: "bg-orange-500/20 text-orange-400 border-orange-500/30",
        };
      default:
        return {
          icon: Sparkles,
          label: ranking,
          className: "bg-studio-panel text-studio-text",
        };
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner with Instructions and Live AI Researcher */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-studio-blue/15 via-studio-purple/10 to-transparent border border-studio-blue/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-studio-blue/20 text-studio-blue border border-studio-blue/30">
              AI Trend Researcher · Live Radar
            </span>
            <span className="text-xs text-studio-text-muted">Nicho: {channel.niche}</span>
          </div>
          <h2 className="text-lg font-bold text-studio-text font-display">
            Descoberta de Assuntos Quentes & Verificados
          </h2>
          <p className="text-xs text-studio-text-dim max-w-2xl mt-0.5">
            Monitoramento de papers técnicos, relatórios de mercado e notícias tecnológicas com pontuação de 8 dimensões e checagem de fontes primárias.
          </p>
        </div>

        <button
          onClick={onRefreshTrends}
          disabled={isRefreshing}
          className="btn-gold text-xs py-2 px-4 gap-2 shrink-0 self-start md:self-auto"
        >
          <RefreshCw className={cn("w-4 h-4", isRefreshing && "animate-spin")} />
          {isRefreshing ? "Pesquisando Papers & Web..." : "Atualizar Radar de IA"}
        </button>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-xl bg-studio-panel border border-studio-border">
        <div className="flex items-center gap-2 flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-studio-text-muted shrink-0" />
          <input
            type="text"
            placeholder="Filtrar por tema, ferramenta, tag ou palavra-chave..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-transparent text-xs text-studio-text placeholder-studio-text-muted focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1 text-[11px] text-studio-text-muted">
            <Filter className="w-3.5 h-3.5" />
            <span>Ranking:</span>
          </div>
          {(["ALL", "HOT", "CRESCENTE", "OPORTUNIDADE", "EVERGREEN"] as const).map((r) => (
            <button
              key={r}
              onClick={() => setSelectedRanking(r)}
              className={cn(
                "px-2.5 py-1 rounded-lg text-xs font-semibold transition-all",
                selectedRanking === r
                  ? "bg-studio-blue text-white"
                  : "bg-studio-bg text-studio-text-dim hover:text-studio-text border border-studio-border"
              )}
            >
              {r === "ALL" ? "Todos" : r}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Trends List & Detail Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Trend Cards */}
        <div className="lg:col-span-7 space-y-3 max-h-[750px] overflow-y-auto pr-1">
          {filteredTrends.length === 0 ? (
            <div className="p-8 text-center rounded-2xl bg-studio-panel border border-studio-border text-studio-text-muted text-xs">
              Nenhuma tendência encontrada com os filtros selecionados.
            </div>
          ) : (
            filteredTrends.map((trend) => {
              const badge = getRankingBadge(trend.ranking);
              const isSelected = selectedTrendDetail?.id === trend.id;

              return (
                <div
                  key={trend.id}
                  onClick={() => setSelectedTrendDetail(trend)}
                  className={cn(
                    "p-4 rounded-xl border transition-all cursor-pointer text-left space-y-3",
                    isSelected
                      ? "bg-studio-panel border-studio-blue ring-1 ring-studio-blue/50 shadow-md"
                      : "bg-studio-panel/60 border-studio-border hover:border-studio-border-hover hover:bg-studio-panel"
                  )}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span
                        className={cn(
                          "px-2.5 py-0.5 rounded-full text-[11px] font-bold border flex items-center gap-1",
                          badge.className
                        )}
                      >
                        {badge.label}
                      </span>
                      <span className="text-[11px] text-studio-text-muted font-medium">
                        {trend.nicheCategory}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <div className="text-right">
                        <span className="text-[10px] text-studio-text-muted block">Score de Oportunidade</span>
                        <span className="text-sm font-bold text-studio-gold font-mono">
                          {trend.overallOpportunityScore}/100
                        </span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-sm font-bold text-studio-text font-display leading-snug">
                      {trend.title}
                    </h3>
                    <p className="text-xs text-studio-text-dim line-clamp-2 mt-1">
                      {trend.summary}
                    </p>
                  </div>

                  {/* 4 Key Metrics Bar */}
                  <div className="grid grid-cols-4 gap-2 pt-2 border-t border-studio-border/60 text-center">
                    <div className="p-1.5 rounded-lg bg-studio-bg/60">
                      <span className="text-[9px] uppercase text-studio-text-muted block">Viralidade</span>
                      <span className="text-xs font-bold text-studio-text font-mono">
                        {trend.scores.viralScore}%
                      </span>
                    </div>
                    <div className="p-1.5 rounded-lg bg-studio-bg/60">
                      <span className="text-[9px] uppercase text-studio-text-muted block">Procura</span>
                      <span className="text-xs font-bold text-studio-text font-mono">
                        {trend.scores.searchVolumeScore}%
                      </span>
                    </div>
                    <div className="p-1.5 rounded-lg bg-studio-bg/60">
                      <span className="text-[9px] uppercase text-studio-text-muted block">Retenção</span>
                      <span className="text-xs font-bold text-studio-text font-mono">
                        {trend.scores.retentionPotential}%
                      </span>
                    </div>
                    <div className="p-1.5 rounded-lg bg-studio-bg/60">
                      <span className="text-[9px] uppercase text-studio-text-muted block">Monetização</span>
                      <span className="text-xs font-bold text-studio-green font-mono">
                        {trend.scores.monetizationScore}%
                      </span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Right Column: Detailed Trend Inspector */}
        <div className="lg:col-span-5">
          {selectedTrendDetail ? (
            <div className="studio-card p-5 border border-studio-border space-y-5 sticky top-4">
              <div className="flex items-center justify-between pb-3 border-b border-studio-border">
                <div>
                  <span className="text-[10px] uppercase font-bold text-studio-text-muted">
                    Inspetor de Tendência & Fontes
                  </span>
                  <h4 className="text-sm font-bold text-studio-text font-display">
                    {selectedTrendDetail.title}
                  </h4>
                </div>

                <span className="px-2 py-1 rounded-lg text-xs font-bold font-mono bg-studio-gold/15 text-studio-gold border border-studio-gold/30">
                  {selectedTrendDetail.overallOpportunityScore}/100
                </span>
              </div>

              {/* 8-Criteria Radar Breakdown */}
              <div className="space-y-2">
                <h5 className="text-[11px] font-bold uppercase text-studio-text-muted flex items-center justify-between">
                  <span>Pontuação por Dimensão</span>
                  <span className="text-studio-blue">8 Critérios Auditados</span>
                </h5>

                <div className="space-y-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-studio-text-dim">Viralidade</span>
                    <span className="font-mono font-bold text-studio-text">{selectedTrendDetail.scores.viralScore}/100</span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-studio-bg overflow-hidden">
                    <div className="h-full bg-studio-blue" style={{ width: `${selectedTrendDetail.scores.viralScore}%` }} />
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-studio-text-dim">Procura de Busca (Search Volume)</span>
                    <span className="font-mono font-bold text-studio-text">{selectedTrendDetail.scores.searchVolumeScore}/100</span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-studio-bg overflow-hidden">
                    <div className="h-full bg-studio-purple" style={{ width: `${selectedTrendDetail.scores.searchVolumeScore}%` }} />
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-studio-text-dim">Potencial de Retenção</span>
                    <span className="font-mono font-bold text-studio-text">{selectedTrendDetail.scores.retentionPotential}/100</span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-studio-bg overflow-hidden">
                    <div className="h-full bg-studio-cyan" style={{ width: `${selectedTrendDetail.scores.retentionPotential}%` }} />
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-studio-text-dim">Potencial de Monetização (RPM)</span>
                    <span className="font-mono font-bold text-studio-green">{selectedTrendDetail.scores.monetizationScore}/100</span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-studio-bg overflow-hidden">
                    <div className="h-full bg-studio-green" style={{ width: `${selectedTrendDetail.scores.monetizationScore}%` }} />
                  </div>
                </div>
              </div>

              {/* Verified Sources List */}
              <div className="space-y-2 pt-2 border-t border-studio-border">
                <h5 className="text-[11px] font-bold uppercase text-studio-text-muted flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-studio-green" />
                  Fontes Primárias Verificadas ({selectedTrendDetail.verifiedSources.length})
                </h5>

                <div className="space-y-2">
                  {selectedTrendDetail.verifiedSources.map((source, idx) => (
                    <div key={idx} className="p-2.5 rounded-xl bg-studio-panel border border-studio-border text-xs space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-studio-text truncate">{source.name}</span>
                        <span className="text-[10px] text-studio-green font-mono font-bold shrink-0">
                          {source.credibilityScore}% Confiável
                        </span>
                      </div>
                      <p className="text-[11px] text-studio-text-muted italic">"{source.snippet}"</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Suggested Angles */}
              <div className="space-y-2 pt-2 border-t border-studio-border">
                <h5 className="text-[11px] font-bold uppercase text-studio-text-muted">
                  Ângulos Editoriais Recomendados
                </h5>
                <ul className="space-y-1.5">
                  {selectedTrendDetail.suggestedAngles.map((angle, idx) => (
                    <li key={idx} className="text-xs text-studio-text flex items-start gap-2">
                      <span className="text-studio-blue font-bold">›</span>
                      <span>{angle}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Action Button: Convert to Idea */}
              <button
                onClick={() => {
                  onSelectTrendAsIdea(selectedTrendDetail);
                  toast({
                    title: "Tendência Transformada em Ideia",
                    description: `A tendência "${selectedTrendDetail.title}" foi enviada para o Idea Generator com fontes e ângulos verificados.`,
                  });
                }}
                className="w-full btn-gold text-xs py-3 px-4 gap-2 justify-center shadow-lg"
              >
                <Sparkles className="w-4 h-4" />
                Transformar em Ideia de Vídeo Completa
              </button>
            </div>
          ) : (
            <div className="p-8 text-center rounded-2xl bg-studio-panel border border-studio-border text-studio-text-muted text-xs">
              Selecione uma tendência para inspecionar métricas e fontes.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
