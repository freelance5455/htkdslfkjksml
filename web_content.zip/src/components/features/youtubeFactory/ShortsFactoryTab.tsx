// ============================================================
// AI CREATOR STUDIO — YOUTUBE FACTORY: SHORTS FACTORY TAB
// Batch extraction of 3, 5, 8, or 10 standalone 9:16 vertical Shorts with individual narrative units
// ============================================================

import React, { useState } from "react";
import type {
  ExtractedShortClip,
  YouTubeMasterScript,
  YouTubeChannelProject,
} from "@/types/youtubeFactory";
import {
  Scissors,
  Smartphone,
  Sparkles,
  Zap,
  CheckCircle2,
  Calendar,
  Layers,
  Copy,
  Clock,
  Award,
  Video,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { extractShortsFromScript } from "@/lib/youtubeFactory/shortsFactory";

interface ShortsFactoryTabProps {
  script: YouTubeMasterScript | null;
  channel: YouTubeChannelProject;
  shorts: ExtractedShortClip[];
  onSetShorts: (shorts: ExtractedShortClip[]) => void;
}

export const ShortsFactoryTab: React.FC<ShortsFactoryTabProps> = ({
  script,
  channel,
  shorts,
  onSetShorts,
}) => {
  const { toast } = useToast();
  const [selectedCount, setSelectedCount] = useState<3 | 5 | 8 | 10>(5);
  const [selectedShort, setSelectedShort] = useState<ExtractedShortClip | null>(shorts[0] || null);

  const handleExtract = () => {
    if (!script) {
      toast({
        title: "Nenhum Roteiro Selecionado",
        description: "Carregue ou crie um roteiro master antes de extrair Shorts.",
        variant: "destructive",
      });
      return;
    }

    const generated = extractShortsFromScript(script, selectedCount);
    onSetShorts(generated);
    setSelectedShort(generated[0]);

    toast({
      title: `${selectedCount} Shorts Extraídos com Sucesso!`,
      description: "Cada Short possui gancho próprio, desenvolvimento e fechamento completo em 9:16.",
    });
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-studio-panel border border-studio-border flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-rose-500/20 text-rose-400 border border-rose-500/30">
              Shorts Factory (9:16 Vertical Engine)
            </span>
            <span className="text-xs text-studio-text-muted font-medium">
              {shorts.length} Shorts Gerados
            </span>
          </div>
          <h2 className="text-lg font-bold text-studio-text font-display">
            Extração de Cortes Estratégicos com Unidade Narrativa Própria
          </h2>
          <p className="text-xs text-studio-text-dim max-w-2xl mt-0.5">
            Não são cortes aleatórios: cada Short possui Gancho Psicológico, Contexto, Resolução e Chamada para Ação para viralizar no Shorts Feed e converter inscritos.
          </p>
        </div>

        {/* Extraction Selector Controls */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1 bg-studio-bg p-1 rounded-xl border border-studio-border">
            {([3, 5, 8, 10] as const).map((count) => (
              <button
                key={count}
                onClick={() => setSelectedCount(count)}
                className={cn(
                  "px-3 py-1.5 rounded-lg text-xs font-bold font-mono transition-all",
                  selectedCount === count
                    ? "bg-studio-gold text-black shadow-md"
                    : "text-studio-text-dim hover:text-studio-text"
                )}
              >
                {count} Shorts
              </button>
            ))}
          </div>

          <button
            onClick={handleExtract}
            className="btn-gold text-xs py-2.5 px-4 gap-2 shadow-lg"
          >
            <Scissors className="w-4 h-4" />
            Extrair Agora
          </button>
        </div>
      </div>

      {shorts.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-studio-panel border border-studio-border space-y-4">
          <Smartphone className="w-12 h-12 text-studio-text-muted mx-auto" />
          <div>
            <h3 className="text-base font-bold text-studio-text font-display">
              Nenhum Short Extraído Ainda
            </h3>
            <p className="text-xs text-studio-text-muted mt-1 max-w-md mx-auto">
              Clique em "Extrair Agora" acima para gerar 3, 5, 8 ou 10 Shorts independentes a partir do roteiro principal.
            </p>
          </div>
          <button onClick={handleExtract} className="btn-gold text-xs py-2 px-4 gap-2 mx-auto">
            <Zap className="w-4 h-4" />
            Gerar {selectedCount} Shorts Automatizados
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Shorts List */}
          <div className="lg:col-span-6 space-y-3 max-h-[750px] overflow-y-auto pr-1">
            {shorts.map((short) => {
              const isSelected = selectedShort?.id === short.id;

              return (
                <div
                  key={short.id}
                  onClick={() => setSelectedShort(short)}
                  className={cn(
                    "p-4 rounded-xl border transition-all cursor-pointer text-left space-y-2.5",
                    isSelected
                      ? "bg-studio-panel border-rose-500 ring-1 ring-rose-500/50 shadow-md"
                      : "bg-studio-panel/60 border-studio-border hover:border-studio-border-hover hover:bg-studio-panel"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-md bg-rose-500/20 text-rose-400 font-bold font-mono text-xs flex items-center justify-center border border-rose-500/30">
                        #{short.shortNumber}
                      </span>
                      <span className="text-xs font-bold text-studio-text truncate max-w-[200px]">
                        {short.title}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-studio-text-muted font-mono flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {short.durationSeconds}s
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold font-mono bg-studio-green/15 text-studio-green">
                        {short.viralHookScore}% Hook
                      </span>
                    </div>
                  </div>

                  <p className="text-xs text-studio-text-dim line-clamp-2">
                    <strong className="text-studio-gold">Hook:</strong> "{short.hookText}"
                  </p>

                  <div className="flex items-center justify-between text-[11px] text-studio-text-muted pt-2 border-t border-studio-border/50">
                    <span>Preset: {short.subtitlesPreset}</span>
                    <span className="text-rose-400 font-medium">9:16 Vertical Full HD</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Right: Selected Short Mobile Preview & Script breakdown */}
          <div className="lg:col-span-6">
            {selectedShort && (
              <div className="studio-card p-5 border border-studio-border space-y-5 sticky top-4">
                <div className="flex items-center justify-between pb-3 border-b border-studio-border">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-5 h-5 text-rose-400" />
                    <div>
                      <h4 className="text-sm font-bold text-studio-text font-display">
                        Short #{selectedShort.shortNumber} · Prévia e Roteiro
                      </h4>
                      <span className="text-[10px] text-studio-text-muted">
                        Duração: {selectedShort.durationSeconds}s · Proporção 9:16
                      </span>
                    </div>
                  </div>

                  <span className="px-2 py-1 rounded-lg text-xs font-bold font-mono bg-studio-gold/15 text-studio-gold border border-studio-gold/30">
                    Score: {selectedShort.standaloneQualityScore}/100
                  </span>
                </div>

                {/* 4-Step Narrative Unit Breakdown */}
                <div className="space-y-2.5 text-xs">
                  <div className="p-3 rounded-xl bg-studio-panel border border-studio-border space-y-1">
                    <span className="font-bold text-studio-gold text-[10px] uppercase block">
                      1. Gancho Inicial (0-3s)
                    </span>
                    <p className="text-studio-text font-medium leading-relaxed">
                      "{selectedShort.hookText}"
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-studio-panel border border-studio-border space-y-1">
                    <span className="font-bold text-studio-blue text-[10px] uppercase block">
                      2. Contexto & Conexão (3-15s)
                    </span>
                    <p className="text-studio-text-dim leading-relaxed">
                      {selectedShort.contextText}
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-studio-panel border border-studio-border space-y-1">
                    <span className="font-bold text-studio-purple text-[10px] uppercase block">
                      3. Revelação Central (15-40s)
                    </span>
                    <p className="text-studio-text-dim leading-relaxed">
                      {selectedShort.developmentText}
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-studio-panel border border-studio-border space-y-1">
                    <span className="font-bold text-studio-green text-[10px] uppercase block">
                      4. CTA & Encaminhamento para Vídeo Longo (40-50s)
                    </span>
                    <p className="text-studio-text font-medium leading-relaxed">
                      "{selectedShort.ctaText}"
                    </p>
                  </div>
                </div>

                {/* Visual Storyboard Timeline */}
                <div className="space-y-2 pt-2 border-t border-studio-border">
                  <span className="font-bold text-studio-text-muted block text-[11px] uppercase">
                    Timeline Visual de Cenas
                  </span>
                  <div className="space-y-1.5">
                    {selectedShort.visualCues.map((cue, idx) => (
                      <div key={idx} className="p-2 rounded-lg bg-studio-bg border border-studio-border text-[11px] text-studio-text-dim">
                        {cue}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-2 border-t border-studio-border flex items-center gap-2">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(
                        `${selectedShort.hookText}\n\n${selectedShort.contextText}\n\n${selectedShort.developmentText}\n\n${selectedShort.ctaText}`
                      );
                      toast({
                        title: "Roteiro Copiado!",
                        description: "O texto completo do Short foi copiado para a área de transferência.",
                      });
                    }}
                    className="flex-1 btn-secondary text-xs py-2 px-3 gap-1.5 justify-center"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    Copiar Roteiro
                  </button>
                  <button
                    onClick={() => {
                      toast({
                        title: "Short Agendado!",
                        description: `O Short #${selectedShort.shortNumber} foi adicionado ao Calendário de Conteúdo da IA.`,
                      });
                    }}
                    className="flex-1 btn-gold text-xs py-2 px-3 gap-1.5 justify-center"
                  >
                    <Calendar className="w-3.5 h-3.5" />
                    Agendar Publicação
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
