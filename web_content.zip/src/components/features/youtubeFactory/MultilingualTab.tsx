// ============================================================
// AI CREATOR STUDIO — YOUTUBE FACTORY: MULTILINGUAL TAB
// Internationalization: PT, EN, ES, FR with cultural adaptation
// ============================================================

import React, { useState } from "react";
import type {
  MultilingualAdaptation,
  TargetLanguage,
  YouTubeMasterScript,
  YouTubeChannelProject,
} from "@/types/youtubeFactory";
import {
  Globe,
  Languages,
  Sparkles,
  CheckCircle2,
  Copy,
  Volume2,
  Layers,
  ArrowRight,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { adaptScriptToMultilingual } from "@/lib/youtubeFactory/multilingualEngine";

interface MultilingualTabProps {
  script: YouTubeMasterScript | null;
  channel: YouTubeChannelProject;
  multilingualData: MultilingualAdaptation | null;
  onSetMultilingualData: (data: MultilingualAdaptation) => void;
}

export const MultilingualTab: React.FC<MultilingualTabProps> = ({
  script,
  channel,
  multilingualData,
  onSetMultilingualData,
}) => {
  const { toast } = useToast();
  const [selectedLang, setSelectedLang] = useState<TargetLanguage>("EN");

  const handleGenerateAdaptation = () => {
    if (!script) {
      toast({
        title: "Nenhum Roteiro Carregado",
        description: "Carregue ou crie um roteiro master antes de traduzir.",
        variant: "destructive",
      });
      return;
    }

    const result = adaptScriptToMultilingual(script);
    onSetMultilingualData(result);

    toast({
      title: "Adaptação Multilíngue Concluída!",
      description: "Conteúdo adaptado culturalmente para PT, EN, ES e FR com perfis de voz nativos.",
    });
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: `${label} Copiado!`,
      description: "Pronto para utilização na faixa de áudio internacional.",
    });
  };

  const langNames: Record<TargetLanguage, { name: string; flag: string; audience: string }> = {
    PT: { name: "Português", flag: "🇧🇷 / 🇵🇹", audience: "Brasil, Portugal, Angola" },
    EN: { name: "English (Global)", flag: "🇺🇸 / 🇬🇧", audience: "USA, UK, Canada, Australia & Global" },
    ES: { name: "Español", flag: "🇪🇸 / 🇲🇽", audience: "España, México, Colombia, Argentina" },
    FR: { name: "Français", flag: "🇫🇷 / 🇨🇦", audience: "France, Canada, Belgique, Suisse" },
  };

  const currentLangData = multilingualData?.languages.find((l) => l.lang === selectedLang);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-studio-panel border border-studio-border flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-studio-purple/20 text-studio-purple border border-studio-purple/30">
              Multilingual Cultural Adaptation Engine
            </span>
            <span className="text-xs text-studio-text-muted">4 Idiomas Globais</span>
          </div>
          <h2 className="text-lg font-bold text-studio-text font-display">
            Expansão Internacional & Multi-Áudio no YouTube
          </h2>
          <p className="text-xs text-studio-text-dim max-w-2xl mt-0.5">
            Não é uma tradução literal mecânica: adaptação de ganchos, moedas, estudos de caso e nuances culturais para maximizar o alcance global do canal.
          </p>
        </div>

        <button
          onClick={handleGenerateAdaptation}
          className="btn-gold text-xs py-2.5 px-4 gap-2 shrink-0 self-start md:self-auto shadow-lg"
        >
          <Sparkles className="w-4 h-4" />
          Adaptar Para Todos os Idiomas
        </button>
      </div>

      {!multilingualData ? (
        <div className="p-12 text-center rounded-2xl bg-studio-panel border border-studio-border space-y-4">
          <Globe className="w-12 h-12 text-studio-text-muted mx-auto" />
          <div>
            <h3 className="text-base font-bold text-studio-text font-display">
              Nenhuma Adaptação Multilíngue Gerada
            </h3>
            <p className="text-xs text-studio-text-muted mt-1 max-w-md mx-auto">
              Clique em "Adaptar Para Todos os Idiomas" para gerar títulos, ganchos e descrições localizadas para EN, ES e FR.
            </p>
          </div>
          <button onClick={handleGenerateAdaptation} className="btn-gold text-xs py-2 px-4 gap-2 mx-auto">
            <Sparkles className="w-4 h-4" />
            Gerar Adaptações Internacionais
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Language Selector Tabs */}
          <div className="flex items-center gap-2 p-2 rounded-xl bg-studio-panel border border-studio-border overflow-x-auto">
            {(["PT", "EN", "ES", "FR"] as TargetLanguage[]).map((lang) => {
              const info = langNames[lang];
              const isSelected = selectedLang === lang;

              return (
                <button
                  key={lang}
                  onClick={() => setSelectedLang(lang)}
                  className={cn(
                    "px-4 py-2 rounded-lg text-xs font-bold transition-all shrink-0 flex items-center gap-2",
                    isSelected
                      ? "bg-studio-purple text-white shadow-md"
                      : "bg-studio-bg text-studio-text-dim hover:text-studio-text border border-studio-border"
                  )}
                >
                  <span>{info.flag}</span>
                  <span>{info.name}</span>
                  <span className="text-[10px] opacity-75">({lang})</span>
                </button>
              );
            })}
          </div>

          {currentLangData && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left: Localized Content */}
              <div className="lg:col-span-8 studio-card p-5 border border-studio-border space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-studio-border">
                  <div className="flex items-center gap-2">
                    <span className="text-base">{langNames[selectedLang].flag}</span>
                    <h3 className="text-sm font-bold text-studio-text font-display">
                      Versão Localizada: {langNames[selectedLang].name}
                    </h3>
                  </div>

                  <span className="px-2.5 py-0.5 rounded text-[10px] font-bold font-mono bg-studio-green/15 text-studio-green">
                    {currentLangData.status}
                  </span>
                </div>

                {/* Localized Title */}
                <div className="space-y-1">
                  <label className="block text-[11px] font-bold uppercase text-studio-text-muted">
                    Título Traduzido & Otimizado
                  </label>
                  <div className="p-3 rounded-xl bg-studio-bg border border-studio-border text-xs font-bold text-studio-text flex items-center justify-between">
                    <span>{currentLangData.localizedTitle}</span>
                    <button
                      onClick={() => copyToClipboard(currentLangData.localizedTitle, "Título")}
                      className="text-studio-blue hover:underline text-[11px] shrink-0 ml-2"
                    >
                      Copiar
                    </button>
                  </div>
                </div>

                {/* Localized Hook */}
                <div className="space-y-1">
                  <label className="block text-[11px] font-bold uppercase text-studio-text-muted">
                    Gancho de Retenção Adaptado (Hook)
                  </label>
                  <div className="p-3 rounded-xl bg-studio-bg border border-studio-border text-xs text-studio-text leading-relaxed">
                    "{currentLangData.localizedHook}"
                  </div>
                </div>

                {/* Localized Description */}
                <div className="space-y-1">
                  <label className="block text-[11px] font-bold uppercase text-studio-text-muted">
                    Descrição do Vídeo
                  </label>
                  <textarea
                    rows={4}
                    readOnly
                    value={currentLangData.localizedDescription}
                    className="w-full p-3 rounded-xl bg-studio-bg border border-studio-border text-xs text-studio-text-dim leading-relaxed focus:outline-none"
                  />
                </div>
              </div>

              {/* Right: Cultural Adjustments & Voice Profile */}
              <div className="lg:col-span-4 space-y-4">
                <div className="studio-card p-5 border border-studio-border space-y-3">
                  <span className="text-xs font-bold uppercase text-studio-text tracking-wider flex items-center gap-1.5 pb-2 border-b border-studio-border">
                    <Globe className="w-4 h-4 text-studio-purple" />
                    Ajustes de Contexto Cultural
                  </span>

                  <p className="text-xs text-studio-text-dim leading-relaxed">
                    {currentLangData.culturalContextAdjustments}
                  </p>
                </div>

                <div className="studio-card p-5 border border-studio-border space-y-3">
                  <span className="text-xs font-bold uppercase text-studio-text tracking-wider flex items-center gap-1.5 pb-2 border-b border-studio-border">
                    <Volume2 className="w-4 h-4 text-studio-cyan" />
                    Perfil de Voz Nativo ElevenLabs
                  </span>

                  <div className="p-3 rounded-xl bg-studio-panel border border-studio-border space-y-1">
                    <span className="text-xs font-bold text-studio-text block">
                      {currentLangData.localizedVoiceName}
                    </span>
                    <span className="text-[11px] text-studio-text-muted block">
                      Neural TTS com modulação de sotaque autêntico
                    </span>
                  </div>

                  <button
                    onClick={() => {
                      toast({
                        title: "Áudio Multilíngue Sintetizado!",
                        description: `A faixa em ${langNames[selectedLang].name} foi adicionada às faixas de áudio do vídeo longo.`,
                      });
                    }}
                    className="w-full btn-secondary text-xs py-2 px-3 gap-1.5 justify-center"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    Sintetizar Faixa Multi-Áudio
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
