// ============================================================
// AI CREATOR STUDIO — YOUTUBE FACTORY: SCRIPT MASTER TAB
// 7-Phase Structural Script Editor with Fact Check & Money Safety Guard
// ============================================================

import React, { useState } from "react";
import type {
  YouTubeMasterScript,
  ScriptScenePhase,
  YouTubeChannelProject,
  AvatarMode,
} from "@/types/youtubeFactory";
import {
  ShieldCheck,
  AlertTriangle,
  Sparkles,
  CheckCircle2,
  Lock,
  Layers,
  Zap,
  DollarSign,
  Scissors,
  FileText,
  Volume2,
  Video,
  Eye,
  Sliders,
  ChevronDown,
  ChevronUp,
  Award,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface ScriptMasterTabProps {
  script: YouTubeMasterScript | null;
  channel: YouTubeChannelProject;
  onUpdateScript: (updated: YouTubeMasterScript) => void;
  onNavigateToTab: (tabKey: string) => void;
}

export const ScriptMasterTab: React.FC<ScriptMasterTabProps> = ({
  script,
  channel,
  onUpdateScript,
  onNavigateToTab,
}) => {
  const { toast } = useToast();
  const [activePhaseIndex, setActivePhaseIndex] = useState<number>(0);
  const [showFactCheckModal, setShowFactCheckModal] = useState<boolean>(false);
  const [showMoneyAuditModal, setShowMoneyAuditModal] = useState<boolean>(false);

  if (!script) {
    return (
      <div className="p-12 text-center rounded-2xl bg-studio-panel border border-studio-border space-y-4">
        <FileText className="w-12 h-12 text-studio-text-muted mx-auto" />
        <div>
          <h3 className="text-base font-bold text-studio-text font-display">Nenhum Roteiro Carregado</h3>
          <p className="text-xs text-studio-text-muted mt-1">
            Selecione uma ideia no laboratório de ideias ou crie um novo roteiro a partir das tendências.
          </p>
        </div>
        <button
          onClick={() => onNavigateToTab("ideas")}
          className="btn-gold text-xs py-2 px-4 gap-2 mx-auto"
        >
          <Sparkles className="w-4 h-4" />
          Ir para Ideias & Roteiros
        </button>
      </div>
    );
  }

  const handleNarrationChange = (phaseIndex: number, newText: string) => {
    const updatedPhases = [...script.phases];
    updatedPhases[phaseIndex] = {
      ...updatedPhases[phaseIndex],
      narrationText: newText,
    };
    onUpdateScript({
      ...script,
      phases: updatedPhases,
      updatedAt: new Date().toISOString(),
    });
  };

  const handleAvatarModeChange = (mode: AvatarMode) => {
    onUpdateScript({
      ...script,
      avatarMode: mode,
      updatedAt: new Date().toISOString(),
    });
    toast({
      title: "Modo de Avatar Atualizado",
      description: `O roteiro agora utilizará a configuração: ${(mode || "").replace(/_/g, " ")}`,
    });
  };

  const phaseColors: Record<string, string> = {
    HOOK: "border-studio-gold text-studio-gold bg-studio-gold/10",
    CONTEXTO: "border-studio-blue text-studio-blue bg-studio-blue/10",
    DESENVOLVIMENTO: "border-studio-purple text-studio-purple bg-studio-purple/10",
    EXEMPLOS: "border-studio-green text-studio-green bg-studio-green/10",
    ANALISE: "border-studio-cyan text-studio-cyan bg-studio-cyan/10",
    CONCLUSAO: "border-amber-400 text-amber-400 bg-amber-400/10",
    CTA: "border-rose-400 text-rose-400 bg-rose-400/10",
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner: Script Meta & Tri-Audit Badges */}
      <div className="p-5 rounded-2xl bg-studio-panel border border-studio-border space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-studio-blue/20 text-studio-blue border border-studio-blue/30">
                Roteiro Master Estruturado (7 Fases)
              </span>
              <span className="text-xs text-studio-text-muted font-medium">
                {script.formatType === "LONG_VIDEO"
                  ? "Vídeo Longo (8-15 min)"
                  : script.formatType === "DOCUMENTARY"
                  ? "Documentário (15-30+ min)"
                  : script.formatType === "SHORT"
                  ? "Short (30-60 seg)"
                  : "Vídeo Rápido"}
              </span>
              <span className="text-xs text-studio-gold font-mono font-bold">
                ~{Math.round(script.totalDurationSeconds / 60)} min ({script.phases.length} Cenas)
              </span>
            </div>
            <h2 className="text-base font-bold text-studio-text font-display">
              {script.title}
            </h2>
          </div>

          {/* Avatar Mode Dropdown */}
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-[11px] text-studio-text-muted font-bold uppercase">Modo Visual:</span>
            <select
              value={script.avatarMode}
              onChange={(e) => handleAvatarModeChange(e.target.value as AvatarMode)}
              className="px-3 py-1.5 rounded-lg bg-studio-bg border border-studio-border text-xs text-studio-text focus:outline-none focus:border-studio-blue font-medium"
            >
              <option value="AVATAR_B_ROLL">Avatar + B-Roll Alternado</option>
              <option value="AVATAR_SCREEN_RECORDING">Avatar + Captura de Tela</option>
              <option value="AVATAR">Avatar em Tela Cheia</option>
              <option value="FACELESS">Faceless (B-Roll & Gráficos)</option>
              <option value="VOICE_ONLY">Voice Only (Apenas Narração)</option>
            </select>
          </div>
        </div>

        {/* 3 Protection Engine Status Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-3 border-t border-studio-border">
          {/* Fact Check Engine */}
          <div
            onClick={() => setShowFactCheckModal(true)}
            className="p-3 rounded-xl bg-studio-bg/70 border border-studio-border hover:border-studio-blue transition-all cursor-pointer flex items-center justify-between"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-studio-green/15 text-studio-green flex items-center justify-center font-bold shrink-0">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-studio-text-muted block">
                  Fact Check Engine
                </span>
                <span className="text-xs font-bold text-studio-green">
                  {script.factCheck.overallStatus} ({script.factCheck.confirmedCount} Confirmadas)
                </span>
              </div>
            </div>
            <span className="text-[10px] text-studio-blue font-bold underline">Detalhes</span>
          </div>

          {/* Money Content Safety */}
          <div
            onClick={() => setShowMoneyAuditModal(true)}
            className="p-3 rounded-xl bg-studio-bg/70 border border-studio-border hover:border-studio-gold transition-all cursor-pointer flex items-center justify-between"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-studio-gold/15 text-studio-gold flex items-center justify-center font-bold shrink-0">
                <DollarSign className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-studio-text-muted block">
                  Money Safety Guard
                </span>
                <span className="text-xs font-bold text-studio-text">
                  {script.moneySafety.safetyStatus === "SEGURO_EDUCATIVO"
                    ? "Linguagem Educativa (100%)"
                    : "Requer Ajuste de Risco"}
                </span>
              </div>
            </div>
            <span className="text-[10px] text-studio-gold font-bold underline">Auditar</span>
          </div>

          {/* Originality & Content Protection */}
          <div className="p-3 rounded-xl bg-studio-bg/70 border border-studio-border flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-studio-purple/15 text-studio-purple flex items-center justify-center font-bold shrink-0">
                <Award className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-studio-text-muted block">
                  Originality Engine
                </span>
                <span className="text-xs font-bold text-studio-text">
                  {script.originality.uniqueValueScore}% Valor Único (Sem Repetição)
                </span>
              </div>
            </div>
            <span className="text-[10px] text-studio-green font-mono font-bold">Aprovado</span>
          </div>
        </div>
      </div>

      {/* 7-Phase Script Workflow Stepper */}
      <div className="flex items-center gap-1.5 p-2 rounded-xl bg-studio-panel border border-studio-border overflow-x-auto">
        {script.phases.map((phase, idx) => {
          const isActive = activePhaseIndex === idx;
          const badgeClass = phaseColors[phase.phase] || "border-studio-border text-studio-text";

          return (
            <button
              key={phase.id}
              onClick={() => setActivePhaseIndex(idx)}
              className={cn(
                "px-3 py-2 rounded-lg text-xs font-bold uppercase transition-all shrink-0 flex items-center gap-1.5 border",
                isActive
                  ? "bg-studio-blue text-white border-studio-blue shadow-md"
                  : cn("bg-studio-bg/80 border-studio-border hover:border-studio-border-hover", badgeClass)
              )}
            >
              <span className="w-4 h-4 rounded-full bg-black/30 flex items-center justify-center text-[9px] font-mono">
                {idx + 1}
              </span>
              <span>{phase.phase}</span>
              <span className="text-[10px] opacity-75 font-mono lowercase">({phase.durationSeconds}s)</span>
            </button>
          );
        })}
      </div>

      {/* Active Phase Editor & Storyboard Synchronizer */}
      {script.phases[activePhaseIndex] && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Narration & On-screen Text Editor */}
          <div className="lg:col-span-7 studio-card p-5 border border-studio-border space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-studio-border">
              <div className="flex items-center gap-2">
                <span className={cn("px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase border", phaseColors[script.phases[activePhaseIndex].phase])}>
                  Fase {activePhaseIndex + 1}: {script.phases[activePhaseIndex].phase}
                </span>
                <span className="text-xs font-bold text-studio-text font-display">
                  {script.phases[activePhaseIndex].title}
                </span>
              </div>

              <span className="text-xs text-studio-text-muted font-mono">
                Duração Estimada: {script.phases[activePhaseIndex].durationSeconds} segundos
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold text-studio-text-muted mb-1 uppercase flex items-center justify-between">
                <span>Texto da Narração (Voz: {channel.defaultVoice.name})</span>
                <span className="text-studio-text-muted text-[10px] lowercase">
                  {script.phases[activePhaseIndex].narrationText.length} caracteres
                </span>
              </label>
              <textarea
                rows={6}
                value={script.phases[activePhaseIndex].narrationText}
                onChange={(e) => handleNarrationChange(activePhaseIndex, e.target.value)}
                className="w-full p-3.5 rounded-xl bg-studio-bg border border-studio-border text-studio-text text-xs leading-relaxed focus:outline-none focus:border-studio-blue font-sans"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-studio-text-muted mb-1 uppercase">
                Texto em Destaque na Tela (Overlay Tipográfico)
              </label>
              <input
                type="text"
                value={script.phases[activePhaseIndex].onScreenText}
                onChange={(e) => {
                  const updatedPhases = [...script.phases];
                  updatedPhases[activePhaseIndex].onScreenText = e.target.value;
                  onUpdateScript({ ...script, phases: updatedPhases });
                }}
                className="w-full px-3 py-2 rounded-lg bg-studio-bg border border-studio-border text-xs text-studio-gold font-bold focus:outline-none focus:border-studio-blue"
              />
            </div>
          </div>

          {/* Right: Visual Prompt, Transition & Audio Cues */}
          <div className="lg:col-span-5 studio-card p-5 border border-studio-border space-y-4">
            <h4 className="text-xs font-bold text-studio-text font-display uppercase tracking-wider flex items-center gap-1.5 pb-2 border-b border-studio-border">
              <Video className="w-4 h-4 text-studio-blue" />
              Sincronização Visual & Áudio da Cena
            </h4>

            {/* Visual Type */}
            <div className="space-y-1 text-xs">
              <span className="font-bold text-studio-text-muted block text-[10px] uppercase">
                Elemento Visual Predominante
              </span>
              <div className="p-2.5 rounded-lg bg-studio-panel border border-studio-border flex items-center justify-between">
                <span className="font-bold text-studio-text font-mono">
                  {script.phases[activePhaseIndex].visualType}
                </span>
                <span className="text-[11px] text-studio-blue font-medium">
                  {script.phases[activePhaseIndex].avatarAction || "STANDBY"}
                </span>
              </div>
            </div>

            {/* Visual Prompt */}
            <div className="space-y-1 text-xs">
              <span className="font-bold text-studio-text-muted block text-[10px] uppercase">
                Prompt do Gerador de Imagem/Vídeo (Imagen 3 / Stable Diffusion)
              </span>
              <p className="p-2.5 rounded-lg bg-studio-bg border border-studio-border text-[11px] text-studio-text-dim leading-relaxed">
                {script.phases[activePhaseIndex].visualPrompt}
              </p>
            </div>

            {/* Transition & Audio */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-lg bg-studio-panel border border-studio-border">
                <span className="text-[9px] uppercase font-bold text-studio-text-muted block">Transição</span>
                <span className="text-[11px] font-bold text-studio-text truncate block mt-0.5">
                  {script.phases[activePhaseIndex].transition}
                </span>
              </div>

              <div className="p-2.5 rounded-lg bg-studio-panel border border-studio-border">
                <span className="text-[9px] uppercase font-bold text-studio-text-muted block">Trilha Sonora</span>
                <span className="text-[11px] font-bold text-studio-gold truncate block mt-0.5">
                  {script.phases[activePhaseIndex].backgroundMusicCue}
                </span>
              </div>
            </div>

            {/* Sound FX Cue */}
            {script.phases[activePhaseIndex].soundEffectCue && (
              <div className="p-2 rounded-lg bg-studio-panel border border-studio-border text-xs flex items-center gap-2">
                <Volume2 className="w-3.5 h-3.5 text-studio-cyan shrink-0" />
                <span className="text-[11px] text-studio-text-dim">
                  SFX: <strong className="text-studio-text">{script.phases[activePhaseIndex].soundEffectCue}</strong>
                </span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Action Footer: Pipeline Jumper */}
      <div className="p-4 rounded-xl bg-studio-panel border border-studio-border flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActivePhaseIndex((prev) => Math.max(0, prev - 1))}
            disabled={activePhaseIndex === 0}
            className="btn-secondary text-xs py-2 px-3 disabled:opacity-40"
          >
            ← Cena Anterior
          </button>
          <button
            onClick={() => setActivePhaseIndex((prev) => Math.min(script.phases.length - 1, prev + 1))}
            disabled={activePhaseIndex === script.phases.length - 1}
            className="btn-secondary text-xs py-2 px-3 disabled:opacity-40"
          >
            Próxima Cena →
          </button>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => onNavigateToTab("shorts")}
            className="btn-secondary text-xs py-2 px-3 gap-1.5"
          >
            <Scissors className="w-3.5 h-3.5 text-studio-gold" />
            Extrair Shorts
          </button>
          <button
            onClick={() => onNavigateToTab("thumbnails")}
            className="btn-secondary text-xs py-2 px-3 gap-1.5"
          >
            <Eye className="w-3.5 h-3.5 text-studio-blue" />
            Criar Thumbnails
          </button>
          <button
            onClick={() => onNavigateToTab("compliance")}
            className="btn-gold text-xs py-2 px-4 gap-1.5 shadow-md"
          >
            <ShieldCheck className="w-4 h-4" />
            Auditoria de Compliance & Publicação
          </button>
        </div>
      </div>

      {/* Fact Check Details Modal */}
      {showFactCheckModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="studio-card w-full max-w-2xl max-h-[85vh] flex flex-col border border-studio-border shadow-2xl overflow-hidden animate-fadeIn">
            <div className="p-4 border-b border-studio-border flex items-center justify-between bg-studio-panel">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-studio-green" />
                <h3 className="text-sm font-bold text-studio-text font-display">
                  Auditoria do Fact Check Engine ({script.factCheck.totalClaimsChecked} Afirmações)
                </h3>
              </div>
              <button onClick={() => setShowFactCheckModal(false)} className="text-studio-text-muted hover:text-studio-text">
                ✕
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-3 flex-1 text-xs">
              {script.factCheck.claims.map((claim) => (
                <div key={claim.id} className="p-3 rounded-xl bg-studio-panel border border-studio-border space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold font-mono bg-studio-bg border border-studio-border text-studio-text">
                      {claim.category}
                    </span>
                    <span className={cn(
                      "px-2 py-0.5 rounded text-[10px] font-bold font-mono",
                      claim.status === "CONFIRMADA"
                        ? "bg-studio-green/15 text-studio-green"
                        : claim.status === "PRECISA_VERIFICACAO"
                        ? "bg-amber-500/15 text-amber-400"
                        : "bg-studio-red/15 text-studio-red"
                    )}>
                      {claim.status}
                    </span>
                  </div>
                  <p className="text-xs text-studio-text font-medium">"{claim.claimText}"</p>
                  <p className="text-[11px] text-studio-text-muted">{claim.evidenceExplanation}</p>
                </div>
              ))}
            </div>

            <div className="p-3 border-t border-studio-border bg-studio-panel text-right">
              <button onClick={() => setShowFactCheckModal(false)} className="btn-secondary text-xs py-1.5 px-4">
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Money Safety Audit Modal */}
      {showMoneyAuditModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="studio-card w-full max-w-xl p-6 border border-studio-border shadow-2xl space-y-4 animate-fadeIn">
            <div className="flex items-center justify-between pb-3 border-b border-studio-border">
              <div className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-studio-gold" />
                <h3 className="text-sm font-bold text-studio-text font-display">
                  Auditoria de Proteção Financeira (Money Content Safety)
                </h3>
              </div>
              <button onClick={() => setShowMoneyAuditModal(false)} className="text-studio-text-muted hover:text-studio-text">
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3.5 rounded-xl bg-studio-panel border border-studio-border space-y-1">
                <span className="font-bold text-studio-text block">Status de Segurança Financeira</span>
                <p className="text-studio-green font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  {script.moneySafety.safetyStatus}
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-studio-panel border border-studio-border space-y-1">
                <span className="font-bold text-studio-text block text-[11px] uppercase text-studio-text-muted">
                  Disclaimer Legal Obrigatório Injetado
                </span>
                <p className="text-[11px] text-studio-text-dim italic leading-relaxed">
                  "{script.moneySafety.disclaimerText}"
                </p>
              </div>
            </div>

            <div className="pt-2 border-t border-studio-border text-right">
              <button onClick={() => setShowMoneyAuditModal(false)} className="btn-secondary text-xs py-1.5 px-4">
                Entendido
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
