// ============================================================
// AI CREATOR STUDIO — YOUTUBE FACTORY: TITLE & SEO TAB
// 5 Non-misleading title variants with predicted CTR, chapters, tags, and pinned comment
// ============================================================

import React, { useState } from "react";
import type {
  TitleOptimizationResult,
  YouTubeMasterScript,
  YouTubeChannelProject,
} from "@/types/youtubeFactory";
import {
  Tag,
  Copy,
  CheckCircle2,
  Sparkles,
  TrendingUp,
  Clock,
  MessageSquare,
  ListOrdered,
  Layers,
  ShieldCheck,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { optimizeTitlesAndSeo } from "@/lib/youtubeFactory/titleAndSeoEngine";

interface TitleAndSeoTabProps {
  script: YouTubeMasterScript | null;
  channel: YouTubeChannelProject;
  seoData: TitleOptimizationResult | null;
  onSetSeoData: (data: TitleOptimizationResult) => void;
}

export const TitleAndSeoTab: React.FC<TitleAndSeoTabProps> = ({
  script,
  channel,
  seoData,
  onSetSeoData,
}) => {
  const { toast } = useToast();
  const [selectedTitleId, setSelectedTitleId] = useState<string | null>(null);

  const handleGenerateSeo = () => {
    if (!script) {
      toast({
        title: "Nenhum Roteiro Selecionado",
        description: "Carregue ou crie um roteiro master antes de otimizar SEO.",
        variant: "destructive",
      });
      return;
    }

    const result = optimizeTitlesAndSeo(script, channel);
    onSetSeoData(result);
    setSelectedTitleId(result.variants[0].id);

    toast({
      title: "Pacote de SEO & Títulos Gerado!",
      description: "5 variações de título com CTR predito, timestamps e metadados completos.",
    });
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: `${label} Copiado!`,
      description: "Conteúdo pronto para colar diretamente no YouTube Studio.",
    });
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-studio-panel border border-studio-border flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-studio-blue/20 text-studio-blue border border-studio-blue/30">
              Title Optimizer & SEO Engine
            </span>
            <span className="text-xs text-studio-green font-medium flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              100% Anti-Clickbait Falso
            </span>
          </div>
          <h2 className="text-lg font-bold text-studio-text font-display">
            Otimização de Descoberta Orgânica & CTR no YouTube
          </h2>
          <p className="text-xs text-studio-text-dim max-w-2xl mt-0.5">
            Geração de títulos de alta atração com estimativa de CTR, timestamps automáticos a partir do roteiro, hashtags e comentário fixado estratégico.
          </p>
        </div>

        <button
          onClick={handleGenerateSeo}
          className="btn-gold text-xs py-2.5 px-4 gap-2 shrink-0 self-start md:self-auto shadow-lg"
        >
          <Sparkles className="w-4 h-4" />
          Gerar Pacote de SEO Completo
        </button>
      </div>

      {!seoData ? (
        <div className="p-12 text-center rounded-2xl bg-studio-panel border border-studio-border space-y-4">
          <Tag className="w-12 h-12 text-studio-text-muted mx-auto" />
          <div>
            <h3 className="text-base font-bold text-studio-text font-display">
              Nenhum Pacote de SEO Gerado
            </h3>
            <p className="text-xs text-studio-text-muted mt-1 max-w-md mx-auto">
              Clique em "Gerar Pacote de SEO Completo" para gerar 5 títulos para teste A/B, capítulos cronometrados e tags.
            </p>
          </div>
          <button onClick={handleGenerateSeo} className="btn-gold text-xs py-2 px-4 gap-2 mx-auto">
            <Sparkles className="w-4 h-4" />
            Otimizar Título & Metadados
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {/* 5 Title Variants */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-studio-text uppercase tracking-wider flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-studio-blue" />
              5 Variações de Título com Previsão de Desempenho
            </h3>

            <div className="grid grid-cols-1 gap-3">
              {seoData.variants.map((variant) => {
                const isSelected = selectedTitleId === variant.id;

                return (
                  <div
                    key={variant.id}
                    onClick={() => setSelectedTitleId(variant.id)}
                    className={cn(
                      "p-4 rounded-xl border transition-all cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-3",
                      isSelected
                        ? "bg-studio-panel border-studio-blue ring-1 ring-studio-blue/50"
                        : "bg-studio-panel/60 border-studio-border hover:bg-studio-panel"
                    )}
                  >
                    <div className="flex items-start gap-3">
                      <span className="w-7 h-7 rounded-lg bg-studio-blue/20 text-studio-blue font-bold font-mono text-xs flex items-center justify-center border border-studio-blue/30 shrink-0">
                        {variant.abTestBucket}
                      </span>
                      <div>
                        <h4 className="text-sm font-bold text-studio-text">
                          {variant.title}
                        </h4>
                        <div className="flex items-center gap-3 text-[11px] text-studio-text-muted mt-1">
                          <span>SEO Score: <strong className="text-studio-text font-mono">{variant.seoScore}%</strong></span>
                          <span>Curiosidade: <strong className="text-studio-text font-mono">{variant.curiosityScore}%</strong></span>
                          <span>Clareza: <strong className="text-studio-text font-mono">{variant.clarityScore}%</strong></span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0 self-end md:self-auto">
                      <div className="text-right">
                        <span className="text-[10px] text-studio-text-muted block">CTR Estimado</span>
                        <span className="text-sm font-bold text-studio-green font-mono">
                          {variant.predictedCtrPercent}%
                        </span>
                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          copyToClipboard(variant.title, "Título");
                        }}
                        className="btn-secondary text-xs py-1.5 px-2.5 gap-1"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        Copiar
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Description, Chapters & Metadata Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Description & Timestamps */}
            <div className="lg:col-span-7 studio-card p-5 border border-studio-border space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-studio-border">
                <h4 className="text-xs font-bold text-studio-text uppercase tracking-wider flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-studio-gold" />
                  Descrição Completa & Capítulos Automáticos
                </h4>

                <button
                  onClick={() => copyToClipboard(seoData.seoMetadata.description, "Descrição")}
                  className="btn-secondary text-xs py-1 px-2.5 gap-1"
                >
                  <Copy className="w-3.5 h-3.5" />
                  Copiar Descrição
                </button>
              </div>

              <textarea
                rows={12}
                readOnly
                value={seoData.seoMetadata.description}
                className="w-full p-3.5 rounded-xl bg-studio-bg border border-studio-border text-studio-text text-xs leading-relaxed font-mono focus:outline-none"
              />
            </div>

            {/* Right: Tags, Hashtags & Pinned Comment */}
            <div className="lg:col-span-5 space-y-4">
              {/* Pinned Comment Box */}
              <div className="studio-card p-4 border border-studio-border space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase text-studio-text-muted flex items-center gap-1">
                    <MessageSquare className="w-3.5 h-3.5 text-studio-blue" />
                    Comentário Fixado Estratégico
                  </span>
                  <button
                    onClick={() => copyToClipboard(seoData.seoMetadata.pinnedComment, "Comentário Fixado")}
                    className="text-[10px] text-studio-blue font-bold hover:underline"
                  >
                    Copiar
                  </button>
                </div>
                <p className="p-2.5 rounded-lg bg-studio-panel border border-studio-border text-xs text-studio-text">
                  {seoData.seoMetadata.pinnedComment}
                </p>
              </div>

              {/* Hashtags */}
              <div className="studio-card p-4 border border-studio-border space-y-2">
                <span className="text-[11px] font-bold uppercase text-studio-text-muted block">
                  Hashtags Principais
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {seoData.seoMetadata.hashtags.map((h, idx) => (
                    <span key={idx} className="px-2 py-0.5 rounded-md bg-studio-blue/15 text-studio-blue text-xs font-mono font-bold">
                      {h}
                    </span>
                  ))}
                </div>
              </div>

              {/* YouTube Tags */}
              <div className="studio-card p-4 border border-studio-border space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase text-studio-text-muted">
                    Tags do YouTube Studio ({seoData.seoMetadata.tags.length})
                  </span>
                  <button
                    onClick={() => copyToClipboard(seoData.seoMetadata.tags.join(", "), "Tags")}
                    className="text-[10px] text-studio-blue font-bold hover:underline"
                  >
                    Copiar Todas
                  </button>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {seoData.seoMetadata.tags.map((t, idx) => (
                    <span key={idx} className="px-2 py-0.5 rounded-md bg-studio-panel border border-studio-border text-xs text-studio-text-dim">
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
