// ============================================================
// AI CREATOR STUDIO — YOUTUBE FACTORY: CALENDAR SCHEDULE TAB
// Content Calendar AI: Long Videos + Shorts rhythm & peak posting hours
// ============================================================

import React, { useState } from "react";
import type { YouTubeChannelProject } from "@/types/youtubeFactory";
import {
  Calendar as CalendarIcon,
  Clock,
  Video,
  Smartphone,
  Sparkles,
  Plus,
  CheckCircle2,
  ChevronRight,
  TrendingUp,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface CalendarScheduleTabProps {
  channel: YouTubeChannelProject;
}

interface CalendarItem {
  id: string;
  day: string;
  date: string;
  time: string;
  title: string;
  type: "LONG_VIDEO" | "SHORT";
  status: "SCHEDULED" | "READY" | "PUBLISHED";
  topic: string;
}

export const CalendarScheduleTab: React.FC<CalendarScheduleTabProps> = ({ channel }) => {
  const { toast } = useToast();

  const [scheduleItems, setScheduleItems] = useState<CalendarItem[]>([
    {
      id: "cal-1",
      day: "Segunda-feira",
      date: "Hoje",
      time: "18:30 (Pico)",
      title: "Como 1 Desenvolvedor Entrega Trabalho de 10 Usando Agentes de IA",
      type: "LONG_VIDEO",
      status: "READY",
      topic: "Agentes Autônomos",
    },
    {
      id: "cal-2",
      day: "Terça-feira",
      date: "Amanhã",
      time: "12:15",
      title: "Pare de fazer isso se você usa IA no trabalho!",
      type: "SHORT",
      status: "SCHEDULED",
      topic: "Produtividade",
    },
    {
      id: "cal-3",
      day: "Quarta-feira",
      date: "Em 2 dias",
      time: "19:00",
      title: "Tesla Optimus vs Figure 02: A Batalha dos Robôs Humanoides",
      type: "LONG_VIDEO",
      status: "SCHEDULED",
      topic: "Robótica",
    },
    {
      id: "cal-4",
      day: "Quinta-feira",
      date: "Em 3 dias",
      time: "12:15",
      title: "O maior erro ao tentar monetizar ferramentas de IA",
      type: "SHORT",
      status: "SCHEDULED",
      topic: "Dinheiro & Negócios",
    },
    {
      id: "cal-5",
      day: "Sexta-feira",
      date: "Em 4 dias",
      time: "18:30 (Pico)",
      title: "7 Micro-SaaS de IA Que Faturam Mais de R$ 10k/mês Sem Funcionários",
      type: "LONG_VIDEO",
      status: "SCHEDULED",
      topic: "Fintech & SaaS",
    },
  ]);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-studio-panel border border-studio-border flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-studio-blue/20 text-studio-blue border border-studio-blue/30">
              Content Calendar AI
            </span>
            <span className="text-xs text-studio-text-muted font-medium">
              Meta do Canal: {channel.publishingSchedule.frequencyLongPerWeek} Longos + {channel.publishingSchedule.frequencyShortsPerWeek} Shorts / semana
            </span>
          </div>
          <h2 className="text-lg font-bold text-studio-text font-display">
            Planejador Editorial & Horários Nobres de Audiência
          </h2>
          <p className="text-xs text-studio-text-dim max-w-2xl mt-0.5">
            Distribuição balanceada entre vídeos aprofundados e Shorts de descoberta rápida, sincronizados com o algoritmo de recomendação do YouTube.
          </p>
        </div>

        <button
          onClick={() => {
            toast({
              title: "Calendário Automático de 30 Dias Gerado!",
              description: "Cronograma balanceado com 8 vídeos longos e 20 Shorts preparado para produção.",
            });
          }}
          className="btn-gold text-xs py-2 px-4 gap-2 shrink-0 self-start md:self-auto shadow-lg"
        >
          <Sparkles className="w-4 h-4" />
          Gerar Grade de 30 Dias
        </button>
      </div>

      {/* Recommended Strategy Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
        <div className="p-3.5 rounded-xl bg-studio-panel border border-studio-border space-y-1">
          <span className="font-bold text-studio-gold text-[10px] uppercase block">
            Melhor Horário Para Vídeos Longos
          </span>
          <span className="text-sm font-bold text-studio-text font-mono">18:00 – 19:30 (Seg, Qua, Sex)</span>
          <p className="text-[11px] text-studio-text-muted">Pico de retenção e tempo de tela para tecnologia e negócios.</p>
        </div>

        <div className="p-3.5 rounded-xl bg-studio-panel border border-studio-border space-y-1">
          <span className="font-bold text-studio-blue text-[10px] uppercase block">
            Melhor Horário Para Shorts
          </span>
          <span className="text-sm font-bold text-studio-text font-mono">11:30 – 13:00 / 20:00 – 21:30</span>
          <p className="text-[11px] text-studio-text-muted">Janela de almoço e relaxamento noturno com alta rotação no Feed.</p>
        </div>

        <div className="p-3.5 rounded-xl bg-studio-panel border border-studio-border space-y-1">
          <span className="font-bold text-studio-green text-[10px] uppercase block">
            Ritmo de Consistência
          </span>
          <span className="text-sm font-bold text-studio-green font-mono">5 Publicações Ativas</span>
          <p className="text-[11px] text-studio-text-muted">Ritmo ideal para acelerar o crescimento sem saturação de qualidade.</p>
        </div>
      </div>

      {/* Calendar List */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold text-studio-text uppercase tracking-wider flex items-center gap-2">
          <CalendarIcon className="w-4 h-4 text-studio-blue" />
          Próximas Publicações Programadas
        </h3>

        <div className="space-y-2.5">
          {scheduleItems.map((item) => (
            <div
              key={item.id}
              className="p-4 rounded-xl bg-studio-panel border border-studio-border hover:border-studio-border-hover flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs"
            >
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-studio-bg border border-studio-border flex flex-col items-center justify-center shrink-0">
                  <span className="text-[9px] uppercase text-studio-text-muted font-bold">
                    {item.day.slice(0, 3)}
                  </span>
                  <span className="text-[11px] font-bold text-studio-text">
                    {item.date === "Hoje" ? "HOJE" : item.day.slice(0, 3)}
                  </span>
                </div>

                <div>
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span
                      className={cn(
                        "px-2 py-0.5 rounded text-[10px] font-bold uppercase",
                        item.type === "LONG_VIDEO"
                          ? "bg-studio-blue/15 text-studio-blue"
                          : "bg-rose-500/15 text-rose-400"
                      )}
                    >
                      {item.type === "LONG_VIDEO" ? "Vídeo Longo" : "Short (9:16)"}
                    </span>
                    <span className="text-[11px] text-studio-text-muted flex items-center gap-1 font-mono">
                      <Clock className="w-3 h-3" />
                      {item.time}
                    </span>
                    <span className="text-[11px] text-studio-text-muted">· {item.topic}</span>
                  </div>

                  <h4 className="text-xs font-bold text-studio-text">{item.title}</h4>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end md:self-auto shrink-0">
                <span className="px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase font-mono bg-studio-green/15 text-studio-green">
                  {item.status === "READY" ? "Pronto p/ Envio" : "Agendado"}
                </span>

                <button
                  onClick={() => {
                    toast({
                      title: "Publicação Disparada Manualmente",
                      description: `O item "${item.title.slice(0, 30)}..." foi iniciado com sucesso.`,
                    });
                  }}
                  className="btn-secondary text-[11px] py-1 px-2.5"
                >
                  Disparar Agora
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
