// ============================================================
// AI CREATOR STUDIO — YOUTUBE FACTORY: ANALYTICS & LEARNING TAB
// Continuous Learning Loop: Research → Create → Publish → Measure → Learn → Improve
// ============================================================

import React from "react";
import type { YouTubeChannelProject } from "@/types/youtubeFactory";
import {
  TrendingUp,
  Eye,
  Clock,
  Users,
  DollarSign,
  Award,
  Sparkles,
  BarChart2,
  ArrowUpRight,
  Lightbulb,
  Layers,
  Repeat,
  Compass,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { getChannelAnalytics } from "@/lib/youtubeFactory/analyticsAndLearningEngine";

interface AnalyticsLearningTabProps {
  channel: YouTubeChannelProject;
  onNavigateToTab: (tabKey: string) => void;
}

export const AnalyticsLearningTab: React.FC<AnalyticsLearningTabProps> = ({
  channel,
  onNavigateToTab,
}) => {
  const { toast } = useToast();
  const analytics = getChannelAnalytics(channel);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner: Learning Loop Cycle */}
      <div className="p-5 rounded-2xl bg-studio-panel border border-studio-border space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-studio-green/20 text-studio-green border border-studio-green/30">
                YouTube AI Analytics & Continuous Learning Loop
              </span>
              <span className="text-xs text-studio-text-muted">Período: Últimos 28 Dias</span>
            </div>
            <h2 className="text-lg font-bold text-studio-text font-display">
              Diagnóstico Estratégico & Ciclo de Aprendizado Contínuo
            </h2>
            <p className="text-xs text-studio-text-dim max-w-2xl mt-0.5">
              O algoritmo analisa o comportamento real do público e traduz dados brutos em orientações acionáveis para os próximos vídeos.
            </p>
          </div>

          <button
            onClick={() => {
              toast({
                title: "Recomendações Injetadas no Idea Generator!",
                description: "Novos tópicos foram priorizados com base no aprendizado de retenção deste mês.",
              });
              onNavigateToTab("ideas");
            }}
            className="btn-gold text-xs py-2 px-4 gap-2 shrink-0 self-start lg:self-auto shadow-lg"
          >
            <Sparkles className="w-4 h-4" />
            Aplicar Recomendações nas Ideias
          </button>
        </div>

        {/* Visual Learning Loop Ribbon */}
        <div className="p-3 rounded-xl bg-studio-bg/80 border border-studio-border flex items-center justify-between gap-1 text-[11px] font-mono font-bold overflow-x-auto">
          <span className="text-studio-blue shrink-0">1. PESQUISAR</span>
          <span className="text-studio-text-muted">→</span>
          <span className="text-studio-purple shrink-0">2. CRIAR</span>
          <span className="text-studio-text-muted">→</span>
          <span className="text-studio-gold shrink-0">3. PUBLICAR</span>
          <span className="text-studio-text-muted">→</span>
          <span className="text-studio-green shrink-0">4. MEDIR</span>
          <span className="text-studio-text-muted">→</span>
          <span className="text-studio-cyan shrink-0">5. APRENDER</span>
          <span className="text-studio-text-muted">→</span>
          <span className="text-amber-400 shrink-0">6. MELHORAR</span>
        </div>
      </div>

      {/* 6 Key Channel KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-4 rounded-xl bg-studio-panel border border-studio-border space-y-1">
          <span className="text-[10px] uppercase font-bold text-studio-text-muted flex items-center justify-between">
            <span>Visualizações</span>
            <Eye className="w-3.5 h-3.5 text-studio-blue" />
          </span>
          <span className="text-lg font-bold text-studio-text font-mono block">
            {analytics.metrics.totalViews.toLocaleString()}
          </span>
          <span className="text-[10px] text-studio-green font-bold flex items-center gap-0.5">
            <ArrowUpRight className="w-3 h-3" /> +{analytics.metrics.viewsGrowthPct}%
          </span>
        </div>

        <div className="p-4 rounded-xl bg-studio-panel border border-studio-border space-y-1">
          <span className="text-[10px] uppercase font-bold text-studio-text-muted flex items-center justify-between">
            <span>Tempo de Exibição</span>
            <Clock className="w-3.5 h-3.5 text-studio-gold" />
          </span>
          <span className="text-lg font-bold text-studio-text font-mono block">
            {analytics.metrics.watchTimeHours.toLocaleString()}h
          </span>
          <span className="text-[10px] text-studio-text-dim">Monetização Ativa</span>
        </div>

        <div className="p-4 rounded-xl bg-studio-panel border border-studio-border space-y-1">
          <span className="text-[10px] uppercase font-bold text-studio-text-muted flex items-center justify-between">
            <span>Novos Inscritos</span>
            <Users className="w-3.5 h-3.5 text-studio-purple" />
          </span>
          <span className="text-lg font-bold text-studio-text font-mono block">
            +{analytics.metrics.subscribersGained.toLocaleString()}
          </span>
          <span className="text-[10px] text-studio-green font-bold">+28% vs mês anterior</span>
        </div>

        <div className="p-4 rounded-xl bg-studio-panel border border-studio-border space-y-1">
          <span className="text-[10px] uppercase font-bold text-studio-text-muted flex items-center justify-between">
            <span>CTR Médio</span>
            <BarChart2 className="w-3.5 h-3.5 text-studio-cyan" />
          </span>
          <span className="text-lg font-bold text-studio-text font-mono block">
            {analytics.metrics.avgCtrPercent}%
          </span>
          <span className="text-[10px] text-studio-green font-bold">Acima da Média</span>
        </div>

        <div className="p-4 rounded-xl bg-studio-panel border border-studio-border space-y-1">
          <span className="text-[10px] uppercase font-bold text-studio-text-muted flex items-center justify-between">
            <span>Views em Shorts</span>
            <TrendingUp className="w-3.5 h-3.5 text-rose-400" />
          </span>
          <span className="text-lg font-bold text-studio-text font-mono block">
            {analytics.metrics.shortsViews.toLocaleString()}
          </span>
          <span className="text-[10px] text-studio-text-dim">Feed de Descoberta</span>
        </div>

        <div className="p-4 rounded-xl bg-studio-panel border border-studio-border space-y-1">
          <span className="text-[10px] uppercase font-bold text-studio-text-muted flex items-center justify-between">
            <span>Receita Estimada</span>
            <DollarSign className="w-3.5 h-3.5 text-studio-green" />
          </span>
          <span className="text-lg font-bold text-studio-green font-mono block">
            ${analytics.metrics.estimatedRevenueUsd.toLocaleString()}
          </span>
          <span className="text-[10px] text-studio-text-dim">RPM Médio Saudável</span>
        </div>
      </div>

      {/* Top Performing Highlights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Top Video */}
        <div className="studio-card p-5 border border-studio-border space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-studio-border">
            <span className="text-[10px] font-bold uppercase text-studio-gold flex items-center gap-1.5">
              <Award className="w-4 h-4" />
              Melhor Vídeo Longo do Período
            </span>
            <span className="text-xs font-mono font-bold text-studio-green">
              {analytics.topPerformingVideo.views.toLocaleString()} views
            </span>
          </div>

          <div>
            <h4 className="text-sm font-bold text-studio-text font-display">
              {analytics.topPerformingVideo.title}
            </h4>
            <div className="flex items-center gap-3 text-xs text-studio-text-muted mt-2">
              <span>CTR: <strong className="text-studio-text font-mono">{analytics.topPerformingVideo.ctr}%</strong></span>
              <span>Duração: <strong className="text-studio-text font-mono">{analytics.topPerformingVideo.duration}</strong></span>
              <span>Nicho: <strong className="text-studio-blue">{analytics.topPerformingVideo.topic}</strong></span>
            </div>
          </div>
        </div>

        {/* Top Short */}
        <div className="studio-card p-5 border border-studio-border space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-studio-border">
            <span className="text-[10px] font-bold uppercase text-rose-400 flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4" />
              Melhor Short do Período
            </span>
            <span className="text-xs font-mono font-bold text-studio-green">
              {analytics.topPerformingShort.views.toLocaleString()} views
            </span>
          </div>

          <div>
            <h4 className="text-sm font-bold text-studio-text font-display">
              {analytics.topPerformingShort.title}
            </h4>
            <div className="flex items-center gap-3 text-xs text-studio-text-muted mt-2">
              <span>Retenção Média: <strong className="text-studio-text font-mono">{analytics.topPerformingShort.retentionPct}%</strong></span>
              <span>Tópico: <strong className="text-rose-400">{analytics.topPerformingShort.topic}</strong></span>
            </div>
          </div>
        </div>
      </div>

      {/* Topic Retention Comparison Table */}
      <div className="studio-card p-5 border border-studio-border space-y-3">
        <h3 className="text-xs font-bold text-studio-text uppercase tracking-wider flex items-center gap-2">
          <BarChart2 className="w-4 h-4 text-studio-blue" />
          Comparativo de Retenção & Engajamento por Linha Editorial
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b border-studio-border text-studio-text-muted text-[10px] uppercase font-bold">
                <th className="pb-2">Tópico Editorial</th>
                <th className="pb-2 text-center">Retenção Média</th>
                <th className="pb-2 text-center">CTR Médio</th>
                <th className="pb-2 text-center">Amostragem</th>
                <th className="pb-2 text-right">Diagnóstico da IA</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-studio-border/60">
              {analytics.topicRetentionComparison.map((row, idx) => (
                <tr key={idx} className="hover:bg-studio-panel/50">
                  <td className="py-2.5 font-bold text-studio-text">{row.topic}</td>
                  <td className="py-2.5 text-center font-mono font-bold text-studio-green">
                    {row.avgRetentionPct}%
                  </td>
                  <td className="py-2.5 text-center font-mono font-bold text-studio-text">
                    {row.avgCtr}%
                  </td>
                  <td className="py-2.5 text-center text-studio-text-muted font-mono">
                    {row.sampleSize} vídeos
                  </td>
                  <td className="py-2.5 text-right">
                    <span
                      className={cn(
                        "px-2 py-0.5 rounded text-[10px] font-bold uppercase",
                        row.avgRetentionPct > 65
                          ? "bg-studio-green/15 text-studio-green"
                          : "bg-amber-500/15 text-amber-300"
                      )}
                    >
                      {row.avgRetentionPct > 65 ? "🔥 Alta Performance" : "⚡ Otimizar Ângulo"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* AI Conversational Explanations & Strategic Recommendations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Explanations */}
        <div className="studio-card p-5 border border-studio-border space-y-3">
          <span className="text-xs font-bold uppercase text-studio-text tracking-wider flex items-center gap-1.5">
            <Compass className="w-4 h-4 text-studio-blue" />
            Diagnósticos da IA em Linguagem Natural
          </span>

          <div className="space-y-2 text-xs">
            {analytics.aiExplanations.map((exp, idx) => (
              <div key={idx} className="p-3 rounded-xl bg-studio-panel border border-studio-border flex items-start gap-2.5">
                <span className="text-studio-blue font-bold">›</span>
                <p className="text-studio-text leading-relaxed">{exp}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Strategic Recommendations */}
        <div className="studio-card p-5 border border-studio-border space-y-3">
          <span className="text-xs font-bold uppercase text-studio-gold tracking-wider flex items-center gap-1.5">
            <Lightbulb className="w-4 h-4" />
            Recomendações Estratégicas Para a Próxima Produção
          </span>

          <div className="space-y-2 text-xs">
            {analytics.aiStrategicRecommendations.map((rec, idx) => (
              <div key={idx} className="p-3 rounded-xl bg-studio-panel border border-studio-border flex items-start gap-2.5">
                <span className="text-studio-gold font-bold">✓</span>
                <p className="text-studio-text leading-relaxed font-medium">{rec}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
