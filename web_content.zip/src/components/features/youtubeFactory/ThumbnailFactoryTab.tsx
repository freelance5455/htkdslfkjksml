// ============================================================
// AI CREATOR STUDIO — YOUTUBE FACTORY: THUMBNAIL FACTORY TAB
// 5 High-CTR variations with 7-criteria audit & mobile readability score
// ============================================================

import React, { useState } from "react";
import type {
  ThumbnailConcept,
  YouTubeMasterScript,
  YouTubeChannelProject,
} from "@/types/youtubeFactory";
import {
  Eye,
  Sparkles,
  Award,
  Layers,
  Smartphone,
  CheckCircle2,
  Sliders,
  Maximize2,
  Zap,
  Download,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { generateThumbnailConcepts } from "@/lib/youtubeFactory/thumbnailFactory";

interface ThumbnailFactoryTabProps {
  script: YouTubeMasterScript | null;
  channel: YouTubeChannelProject;
  thumbnails: ThumbnailConcept[];
  onSetThumbnails: (thumbs: ThumbnailConcept[]) => void;
}

export const ThumbnailFactoryTab: React.FC<ThumbnailFactoryTabProps> = ({
  script,
  channel,
  thumbnails,
  onSetThumbnails,
}) => {
  const { toast } = useToast();
  const [selectedThumb, setSelectedThumb] = useState<ThumbnailConcept | null>(thumbnails[0] || null);

  const handleGenerate = () => {
    const title = script ? script.title : "Como a IA Está Revolucionando os Negócios em 2026";
    const generated = generateThumbnailConcepts(title, channel, 5);
    onSetThumbnails(generated);
    setSelectedThumb(generated[0]);

    toast({
      title: "5 Variações de Thumbnails Geradas!",
      description: "Conceitos auditados para alto CTR, contraste móvel e alinhamento com a identidade do canal.",
    });
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-studio-panel border border-studio-border flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-studio-gold/20 text-studio-gold border border-studio-gold/30">
              Thumbnail Factory & Score
            </span>
            <span className="text-xs text-studio-text-muted font-medium">
              5 Conceitos por Vídeo · A/B Test Ready
            </span>
          </div>
          <h2 className="text-lg font-bold text-studio-text font-display">
            Gerador de Miniaturas de Alto Clique (Sem Decepção)
          </h2>
          <p className="text-xs text-studio-text-dim max-w-2xl mt-0.5">
            Cada miniatura é testada por algoritmo contra 7 fatores críticos de retenção visual e legibilidade em telas de smartphones.
          </p>
        </div>

        <button
          onClick={handleGenerate}
          className="btn-gold text-xs py-2.5 px-4 gap-2 shrink-0 self-start md:self-auto shadow-lg"
        >
          <Sparkles className="w-4 h-4" />
          Gerar 5 Variações
        </button>
      </div>

      {thumbnails.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-studio-panel border border-studio-border space-y-4">
          <Eye className="w-12 h-12 text-studio-text-muted mx-auto" />
          <div>
            <h3 className="text-base font-bold text-studio-text font-display">
              Nenhuma Thumbnail Gerada Ainda
            </h3>
            <p className="text-xs text-studio-text-muted mt-1 max-w-md mx-auto">
              Clique em "Gerar 5 Variações" para produzir opções visuais cinematográficas com score de CTR auditado.
            </p>
          </div>
          <button onClick={handleGenerate} className="btn-gold text-xs py-2 px-4 gap-2 mx-auto">
            <Sparkles className="w-4 h-4" />
            Gerar Thumbnails do Vídeo
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: 5 Thumbnails Visual Grid */}
          <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {thumbnails.map((thumb) => {
              const isSelected = selectedThumb?.id === thumb.id;

              return (
                <div
                  key={thumb.id}
                  onClick={() => setSelectedThumb(thumb)}
                  className={cn(
                    "rounded-2xl border overflow-hidden transition-all cursor-pointer group flex flex-col justify-between bg-studio-panel",
                    isSelected
                      ? "border-studio-gold ring-2 ring-studio-gold/50 shadow-xl"
                      : "border-studio-border hover:border-studio-border-hover"
                  )}
                >
                  {/* Visual Preview Box (16:9) */}
                  <div className="relative aspect-video w-full overflow-hidden bg-black/80 flex items-center justify-center">
                    <img
                      src={thumb.imageUrl}
                      alt={thumb.conceptTitle}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-80"
                      referrerPolicy="no-referrer"
                    />

                    {/* Gradient Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />

                    {/* Big Bold Text Overlay on Thumbnail */}
                    <div className="absolute bottom-3 left-3 right-3">
                      <span
                        className="text-base sm:text-lg font-black tracking-tight uppercase drop-shadow-[0_4px_4px_rgba(0,0,0,0.9)] line-clamp-1"
                        style={{ color: thumb.textColor }}
                      >
                        {thumb.bigTextOverlay}
                      </span>
                    </div>

                    {/* Badges on Top */}
                    <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold font-mono bg-black/70 text-white backdrop-blur-xs border border-white/20">
                        Var #{thumb.variantNumber}
                      </span>
                      {thumb.abTestRecommended && (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-studio-gold text-black">
                          A/B Recomendado
                        </span>
                      )}
                    </div>

                    <div className="absolute top-2.5 right-2.5">
                      <span className="px-2 py-0.5 rounded-lg text-xs font-black font-mono bg-studio-green text-black shadow-md">
                        {thumb.overallScore}/100
                      </span>
                    </div>
                  </div>

                  {/* Card Bottom Meta */}
                  <div className="p-3.5 space-y-1.5">
                    <h4 className="text-xs font-bold text-studio-text truncate">
                      {thumb.conceptTitle}
                    </h4>
                    <p className="text-[11px] text-studio-text-muted line-clamp-1">
                      {thumb.visualDescription}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Right: Selected Thumbnail Deep Audit Inspector */}
          <div className="lg:col-span-4">
            {selectedThumb && (
              <div className="studio-card p-5 border border-studio-border space-y-5 sticky top-4">
                <div className="flex items-center justify-between pb-3 border-b border-studio-border">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-studio-text-muted">
                      Auditoria da Variação #{selectedThumb.variantNumber}
                    </span>
                    <h4 className="text-sm font-bold text-studio-text font-display">
                      Score Geral: {selectedThumb.overallScore}/100
                    </h4>
                  </div>

                  <span className="px-2 py-1 rounded-lg text-xs font-bold font-mono bg-studio-green/15 text-studio-green border border-studio-green/30">
                    Alto Potencial
                  </span>
                </div>

                {/* 7 Scoring Dimensions */}
                <div className="space-y-2 text-xs">
                  <span className="font-bold text-studio-text-muted block text-[10px] uppercase">
                    Critérios de Avaliação Visual
                  </span>

                  <div className="space-y-1.5">
                    <div className="flex justify-between text-[11px]">
                      <span className="text-studio-text-dim">Legibilidade em Mobile (Smartphones)</span>
                      <span className="font-mono font-bold text-studio-text">{selectedThumb.scores.readabilityMobile}%</span>
                    </div>
                    <div className="w-full h-1 rounded-full bg-studio-bg overflow-hidden">
                      <div className="h-full bg-studio-gold" style={{ width: `${selectedThumb.scores.readabilityMobile}%` }} />
                    </div>

                    <div className="flex justify-between text-[11px] pt-1">
                      <span className="text-studio-text-dim">Contraste & Destaque no Feed</span>
                      <span className="font-mono font-bold text-studio-text">{selectedThumb.scores.contrast}%</span>
                    </div>
                    <div className="w-full h-1 rounded-full bg-studio-bg overflow-hidden">
                      <div className="h-full bg-studio-blue" style={{ width: `${selectedThumb.scores.contrast}%` }} />
                    </div>

                    <div className="flex justify-between text-[11px] pt-1">
                      <span className="text-studio-text-dim">Gatilho de Curiosidade</span>
                      <span className="font-mono font-bold text-studio-text">{selectedThumb.scores.curiosity}%</span>
                    </div>
                    <div className="w-full h-1 rounded-full bg-studio-bg overflow-hidden">
                      <div className="h-full bg-studio-purple" style={{ width: `${selectedThumb.scores.curiosity}%` }} />
                    </div>

                    <div className="flex justify-between text-[11px] pt-1">
                      <span className="text-studio-text-dim">Identidade Visual do Canal</span>
                      <span className="font-mono font-bold text-studio-green">{selectedThumb.scores.brandIdentityCohesion}%</span>
                    </div>
                    <div className="w-full h-1 rounded-full bg-studio-bg overflow-hidden">
                      <div className="h-full bg-studio-green" style={{ width: `${selectedThumb.scores.brandIdentityCohesion}%` }} />
                    </div>
                  </div>
                </div>

                {/* Prompt Details */}
                <div className="p-3 rounded-xl bg-studio-panel border border-studio-border text-xs space-y-1.5">
                  <span className="font-bold text-studio-text-muted block text-[10px] uppercase">
                    Elemento em Destaque
                  </span>
                  <p className="text-studio-text text-[11px] leading-relaxed">
                    {selectedThumb.foregroundSubject}
                  </p>
                </div>

                {/* Actions */}
                <button
                  onClick={() => {
                    toast({
                      title: "Thumbnail Selecionada como Principal",
                      description: `A Variação #${selectedThumb.variantNumber} foi definida como a capa oficial para o YouTube Studio.`,
                    });
                  }}
                  className="w-full btn-gold text-xs py-3 px-4 gap-2 justify-center shadow-lg"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Definir como Thumbnail Principal
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
