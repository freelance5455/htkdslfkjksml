// ============================================================
// AI CREATOR STUDIO — YOUTUBE FACTORY DASHBOARD (MASTER COMPONENT)
// YouTube AI, Dinheiro & Futuro — Complete Autonomous & Semi-Autonomous Engine
// ============================================================

import React, { useState, useEffect } from "react";
import type {
  YouTubeChannelProject,
  TrendTopic,
  YouTubeVideoIdea,
  YouTubeMasterScript,
  ExtractedShortClip,
  ThumbnailConcept,
  TitleOptimizationResult,
  YouTubeComplianceReport,
  CopyrightResourceCheck,
  ChannelPresetType,
  MultilingualAdaptation,
} from "@/types/youtubeFactory";
import {
  Flame,
  Lightbulb,
  FileText,
  Smartphone,
  Eye,
  Tag,
  ShieldCheck,
  Calendar as CalendarIcon,
  BarChart2,
  Globe,
  Settings,
  Tv,
  Sparkles,
  ChevronDown,
  Zap,
  TrendingUp,
  AlertTriangle,
  Award,
  Layers,
  RefreshCw,
  Film,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

// Stores & Engines
import {
  getYouTubeChannels,
  saveYouTubeChannels,
  createYouTubeChannelFromPreset,
  updateYouTubeChannel,
} from "@/lib/youtubeFactory/channelStore";
import { getTrendTopics, fetchLiveTrendsFromAI } from "@/lib/youtubeFactory/trendResearcher";
import {
  getYouTubeIdeas,
  saveYouTubeIdeas,
  createIdeaFromTrend,
  deleteYouTubeIdea,
} from "@/lib/youtubeFactory/ideaGenerator";
import {
  getMasterScripts,
  generateMasterScript,
  saveMasterScripts,
} from "@/lib/youtubeFactory/scriptEngine";
import { auditYouTubeCompliance } from "@/lib/youtubeFactory/complianceEngine";
import { getSavedShorts } from "@/lib/youtubeFactory/shortsFactory";

// Sub Tabs
import { TrendResearcherTab } from "./TrendResearcherTab";
import { IdeaGeneratorTab } from "./IdeaGeneratorTab";
import { ScriptMasterTab } from "./ScriptMasterTab";
import { ShortsFactoryTab } from "./ShortsFactoryTab";
import { ThumbnailFactoryTab } from "./ThumbnailFactoryTab";
import { TitleAndSeoTab } from "./TitleAndSeoTab";
import { ComplianceAuditTab } from "./ComplianceAuditTab";
import { CalendarScheduleTab } from "./CalendarScheduleTab";
import { AnalyticsLearningTab } from "./AnalyticsLearningTab";
import { MultilingualTab } from "./MultilingualTab";
import { ChannelSettingsTab } from "./ChannelSettingsTab";
import MyVideosPrePublishView from "@/components/features/MyVideosPrePublishView";
import { AddChannelsTab } from "@/components/features/AddChannelsTab";
import { SyncPlatformsTab } from "@/components/features/SyncPlatformsTab";

type YouTubeTabKey =
  | "add-channels"
  | "sync-platforms"
  | "trends"
  | "ideas"
  | "scripts"
  | "shorts"
  | "thumbnails"
  | "seo"
  | "compliance"
  | "my-videos"
  | "calendar"
  | "analytics"
  | "multilingual"
  | "channels";

export const YouTubeFactoryDashboard: React.FC = () => {
  const { toast } = useToast();

  // Channel State
  const [channels, setChannels] = useState<YouTubeChannelProject[]>([]);
  const [activeChannel, setActiveChannel] = useState<YouTubeChannelProject | null>(null);

  // Tab Navigation
  const [activeTab, setActiveTab] = useState<YouTubeTabKey>("trends");

  // Factory Data State
  const [trends, setTrends] = useState<TrendTopic[]>([]);
  const [ideas, setIdeas] = useState<YouTubeVideoIdea[]>([]);
  const [currentScript, setCurrentScript] = useState<YouTubeMasterScript | null>(null);
  const [shorts, setShorts] = useState<ExtractedShortClip[]>([]);
  const [thumbnails, setThumbnails] = useState<ThumbnailConcept[]>([]);
  const [seoData, setSeoData] = useState<TitleOptimizationResult | null>(null);
  const [complianceReport, setComplianceReport] = useState<YouTubeComplianceReport | null>(null);
  const [copyrightChecks, setCopyrightChecks] = useState<CopyrightResourceCheck[]>([]);
  const [multilingualData, setMultilingualData] = useState<MultilingualAdaptation | null>(null);

  const [isRefreshingTrends, setIsRefreshingTrends] = useState(false);

  // Initial Load
  useEffect(() => {
    const loadedChannels = getYouTubeChannels();
    setChannels(loadedChannels);
    if (loadedChannels.length > 0) {
      setActiveChannel(loadedChannels[0]);
    }

    const loadedTrends = getTrendTopics();
    setTrends(loadedTrends);

    const loadedIdeas = getYouTubeIdeas();
    setIdeas(loadedIdeas);

    const loadedScripts = getMasterScripts();
    if (loadedScripts.length > 0) {
      setCurrentScript(loadedScripts[0]);
    }

    const loadedShorts = getSavedShorts();
    setShorts(loadedShorts);
  }, []);

  if (!activeChannel) {
    return (
      <div className="p-12 text-center text-studio-text-muted">
        <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2" />
        Carregando YouTube Channel Factory...
      </div>
    );
  }

  // Action Handlers
  const handleSelectTrendAsIdea = (trend: TrendTopic) => {
    const newIdea = createIdeaFromTrend(trend, activeChannel.id);
    setIdeas(getYouTubeIdeas());
    setActiveTab("ideas");
  };

  const handleCreateScriptFromIdea = (idea: YouTubeVideoIdea) => {
    const script = generateMasterScript(
      idea.provisionalTitle,
      idea.videoType,
      activeChannel,
      "AVATAR_B_ROLL",
      "PT",
      idea.hook
    );
    setCurrentScript(script);

    // Run initial compliance audit
    const { report, copyrightChecks: checks } = auditYouTubeCompliance(script, activeChannel);
    setComplianceReport(report);
    setCopyrightChecks(checks);

    setActiveTab("scripts");

    toast({
      title: "Roteiro Master Estruturado Gerado!",
      description: `Roteiro em 7 fases criado com Fact Check aprovado e proteção financeira ativada.`,
    });
  };

  const handleRefreshTrends = async () => {
    setIsRefreshingTrends(true);
    try {
      const refreshed = await fetchLiveTrendsFromAI(activeChannel.niche);
      setTrends(refreshed);
      toast({
        title: "Radar de Tendências Atualizado",
        description: `${refreshed.length} tópicos analisados com fontes verificadas.`,
      });
    } catch (err) {
      console.error(err);
    } finally {
      setIsRefreshingTrends(false);
    }
  };

  const handleCreateChannelPreset = (presetKey: ChannelPresetType, name?: string, handle?: string) => {
    const newCh = createYouTubeChannelFromPreset(presetKey, name, handle);
    const list = getYouTubeChannels();
    setChannels(list);
    setActiveChannel(newCh);
    toast({
      title: "Novo Canal Criado!",
      description: `O canal "${newCh.name}" foi inicializado com sucesso.`,
    });
  };

  const handleUpdateChannel = (updated: YouTubeChannelProject) => {
    updateYouTubeChannel(updated);
    const list = getYouTubeChannels();
    setChannels(list);
    setActiveChannel(updated);
  };

  const navigationTabs: { key: YouTubeTabKey; label: string; icon: React.ElementType; badge?: string }[] = [
    { key: "add-channels", label: "➕ Adicionar Canais", icon: Tv, badge: "Novo" },
    { key: "sync-platforms", label: "🔄 Adicionar Plataformas e Sincronizar", icon: RefreshCw, badge: "Sync" },
    { key: "trends", label: "🔥 Tendências & Radar", icon: Flame, badge: "8 Dimensões" },
    { key: "ideas", label: "💡 Ideias & RPM", icon: Lightbulb, badge: `${ideas.length}` },
    { key: "scripts", label: "✍️ Roteiros (7 Fases)", icon: FileText, badge: "Fact Check" },
    { key: "shorts", label: "📱 Shorts Factory", icon: Smartphone, badge: "9:16 Vertical" },
    { key: "thumbnails", label: "🖼️ Thumbnails", icon: Eye, badge: "Score 94" },
    { key: "seo", label: "🏷️ Títulos & SEO", icon: Tag },
    { key: "compliance", label: "🛡️ Compliance & Gate", icon: ShieldCheck, badge: "Segurança" },
    { key: "my-videos", label: "🎬 Meus Vídeos", icon: Film, badge: "Pré-Publicação" },
    { key: "calendar", label: "📅 Calendário AI", icon: CalendarIcon },
    { key: "analytics", label: "📊 Analytics & Loop", icon: BarChart2 },
    { key: "multilingual", label: "🌐 Multilíngue", icon: Globe, badge: "PT/EN/ES/FR" },
    { key: "channels", label: "⚙️ Canais & Presets", icon: Settings },
  ];

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Master Top Bar: Channel Switcher & Automation Ribbon */}
      <div className="p-4 sm:p-5 rounded-2xl bg-studio-panel border border-studio-border flex flex-col lg:flex-row lg:items-center justify-between gap-4 shadow-sm">
        {/* Left: Active Channel Info */}
        <div className="flex items-center gap-3.5">
          <img
            src={activeChannel.logoUrl || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&auto=format&fit=crop&q=80"}
            alt={activeChannel.name || "Canal YouTube"}
            className="w-12 h-12 rounded-2xl object-cover border-2 border-studio-gold/40 shrink-0 shadow-md"
            referrerPolicy="no-referrer"
          />

          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-base sm:text-lg font-black text-studio-text font-display">
                {activeChannel.name || "Canal YouTube"}
              </h1>
              <span className="text-xs text-studio-gold font-mono font-bold">{activeChannel.handle || "@canal"}</span>
              <span className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase bg-studio-blue/15 text-studio-blue border border-studio-blue/30">
                {activeChannel.niche || "Conteúdo"}
              </span>
            </div>

            <p className="text-xs text-studio-text-dim mt-0.5 line-clamp-1 max-w-xl">
              {activeChannel.description || "Canal do YouTube gerenciado por IA."}
            </p>
          </div>
        </div>

        {/* Right: Channel Switcher Dropdown & Automation Badge */}
        <div className="flex items-center gap-2.5 shrink-0 self-end lg:self-auto">
          {(() => {
            const mode = activeChannel.automationLevel || activeChannel.automationMode || "SEMI_AUTOMATICO";
            return (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-studio-bg border border-studio-border text-xs font-medium">
                <span className="text-studio-text-muted text-[10px] uppercase font-bold">Modo:</span>
                <span
                  className={cn(
                    "font-bold uppercase text-[11px]",
                    mode === "AUTOMATICO"
                      ? "text-studio-green"
                      : mode === "SEMI_AUTOMATICO"
                      ? "text-studio-gold"
                      : "text-studio-blue"
                  )}
                >
                  {String(mode).replace(/_/g, " ")}
                </span>
              </div>
            );
          })()}

          <select
            value={activeChannel.id}
            onChange={(e) => {
              const ch = channels.find((c) => c.id === e.target.value);
              if (ch) {
                setActiveChannel(ch);
                toast({
                  title: `Canal Alternado: ${ch.name}`,
                  description: `Projeto ativo alterado para ${ch.niche}.`,
                });
              }
            }}
            className="px-3 py-2 rounded-xl bg-studio-bg border border-studio-border text-xs text-studio-text font-bold focus:outline-none focus:border-studio-blue cursor-pointer"
          >
            {channels.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} ({c.niche.slice(0, 20)}...)
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Quick Status KPI Overview Ribbon */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
        <div className="p-3 rounded-xl bg-studio-panel/80 border border-studio-border space-y-0.5">
          <span className="text-[9px] uppercase font-bold text-studio-text-muted block">Próximo Vídeo</span>
          <span className="text-xs font-bold text-studio-text truncate block">
            {currentScript ? currentScript.title : "Nenhum agendado"}
          </span>
          <span className="text-[10px] text-studio-blue font-mono font-medium">Segunda 18:30</span>
        </div>

        <div className="p-3 rounded-xl bg-studio-panel/80 border border-studio-border space-y-0.5">
          <span className="text-[9px] uppercase font-bold text-studio-text-muted block">Próximo Short</span>
          <span className="text-xs font-bold text-rose-400 truncate block">
            {shorts.length > 0 ? shorts[0].title : "3 em fila"}
          </span>
          <span className="text-[10px] text-studio-text-dim font-mono">Terça 12:15</span>
        </div>

        <div className="p-3 rounded-xl bg-studio-panel/80 border border-studio-border space-y-0.5">
          <span className="text-[9px] uppercase font-bold text-studio-text-muted block">Top Performance</span>
          <span className="text-xs font-bold text-studio-green truncate block">
            94.2k Views (CTR 10.4%)
          </span>
          <span className="text-[10px] text-studio-text-dim">Vídeo de Automação</span>
        </div>

        <div className="p-3 rounded-xl bg-studio-panel/80 border border-studio-border space-y-0.5">
          <span className="text-[9px] uppercase font-bold text-studio-text-muted block">Tendência Mais Quente</span>
          <span className="text-xs font-bold text-studio-gold truncate block">
            {trends[0]?.title.slice(0, 22) || "Agentes IA"}...
          </span>
          <span className="text-[10px] text-studio-green font-mono font-bold">Score 94/100</span>
        </div>

        <div className="p-3 rounded-xl bg-studio-panel/80 border border-studio-border space-y-0.5">
          <span className="text-[9px] uppercase font-bold text-studio-text-muted block">Risco Monetização</span>
          <span className="text-xs font-bold text-studio-green flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            🟢 BAIXO (100% Seguro)
          </span>
          <span className="text-[10px] text-studio-text-dim">Anti-Clickbait Ativo</span>
        </div>

        <div className="p-3 rounded-xl bg-studio-panel/80 border border-studio-border space-y-0.5">
          <span className="text-[9px] uppercase font-bold text-studio-text-muted block">Originalidade Média</span>
          <span className="text-xs font-bold text-studio-purple font-mono">
            94% Valor Único
          </span>
          <span className="text-[10px] text-studio-green font-medium">Sem Repetições</span>
        </div>
      </div>

      {/* Navigation Sub-Tabs Navigation Bar */}
      <div className="flex items-center gap-1.5 p-1.5 rounded-2xl bg-studio-panel border border-studio-border overflow-x-auto">
        {navigationTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.key;

          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                "px-3.5 py-2 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-2 border",
                isActive
                  ? "bg-studio-blue text-white border-studio-blue shadow-md"
                  : "bg-studio-bg/60 border-studio-border text-studio-text-dim hover:text-studio-text hover:bg-studio-bg"
              )}
            >
              <Icon className={cn("w-3.5 h-3.5", isActive ? "text-white" : "text-studio-text-muted")} />
              <span>{tab.label}</span>
              {tab.badge && (
                <span
                  className={cn(
                    "px-1.5 py-0.2 rounded text-[9px] font-mono font-bold",
                    isActive ? "bg-white/20 text-white" : "bg-studio-panel text-studio-text-muted"
                  )}
                >
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Active Tab Sub-view Content */}
      <div className="mt-4">
        {activeTab === "add-channels" && <AddChannelsTab />}

        {activeTab === "sync-platforms" && <SyncPlatformsTab />}

        {activeTab === "trends" && (
          <TrendResearcherTab
            trends={trends}
            channel={activeChannel}
            onSelectTrendAsIdea={handleSelectTrendAsIdea}
            onRefreshTrends={handleRefreshTrends}
            isRefreshing={isRefreshingTrends}
          />
        )}

        {activeTab === "ideas" && (
          <IdeaGeneratorTab
            ideas={ideas}
            channel={activeChannel}
            onCreateMasterScriptFromIdea={handleCreateScriptFromIdea}
            onAddNewIdea={(newIdea) => {
              const updated = [
                { ...newIdea, id: `idea-${Date.now()}`, createdAt: new Date().toISOString() },
                ...ideas,
              ];
              setIdeas(updated);
              saveYouTubeIdeas(updated);
            }}
            onDeleteIdea={(id) => {
              deleteYouTubeIdea(id);
              setIdeas(getYouTubeIdeas());
            }}
          />
        )}

        {activeTab === "scripts" && (
          <ScriptMasterTab
            script={currentScript}
            channel={activeChannel}
            onUpdateScript={(updated) => {
              setCurrentScript(updated);
              saveMasterScripts([updated]);
            }}
            onNavigateToTab={(tab) => setActiveTab(tab as YouTubeTabKey)}
          />
        )}

        {activeTab === "shorts" && (
          <ShortsFactoryTab
            script={currentScript}
            channel={activeChannel}
            shorts={shorts}
            onSetShorts={setShorts}
          />
        )}

        {activeTab === "thumbnails" && (
          <ThumbnailFactoryTab
            script={currentScript}
            channel={activeChannel}
            thumbnails={thumbnails}
            onSetThumbnails={setThumbnails}
          />
        )}

        {activeTab === "seo" && (
          <TitleAndSeoTab
            script={currentScript}
            channel={activeChannel}
            seoData={seoData}
            onSetSeoData={setSeoData}
          />
        )}

        {activeTab === "compliance" && (
          <ComplianceAuditTab
            script={currentScript}
            channel={activeChannel}
            complianceReport={complianceReport}
            copyrightChecks={copyrightChecks}
            onSetComplianceData={({ report, copyrightChecks: checks }) => {
              setComplianceReport(report);
              setCopyrightChecks(checks);
            }}
            onNavigateToTab={(tab) => setActiveTab(tab as YouTubeTabKey)}
          />
        )}

        {activeTab === "my-videos" && <MyVideosPrePublishView />}

        {activeTab === "calendar" && <CalendarScheduleTab channel={activeChannel} />}

        {activeTab === "analytics" && (
          <AnalyticsLearningTab
            channel={activeChannel}
            onNavigateToTab={(tab) => setActiveTab(tab as YouTubeTabKey)}
          />
        )}

        {activeTab === "multilingual" && (
          <MultilingualTab
            script={currentScript}
            channel={activeChannel}
            multilingualData={multilingualData}
            onSetMultilingualData={setMultilingualData}
          />
        )}

        {activeTab === "channels" && (
          <ChannelSettingsTab
            channels={channels}
            activeChannel={activeChannel}
            onSelectChannel={setActiveChannel}
            onCreateFromPreset={handleCreateChannelPreset}
            onUpdateChannel={handleUpdateChannel}
          />
        )}
      </div>
    </div>
  );
};
