// ============================================================
// AI CREATOR STUDIO — YOUTUBE FACTORY: IDEA GENERATOR TAB
// High-retention video concept laboratory without misleading clickbait
// ============================================================

import React, { useState } from "react";
import type { YouTubeVideoIdea, YouTubeChannelProject, VideoFormatType } from "@/types/youtubeFactory";
import {
  Lightbulb,
  Plus,
  Sparkles,
  ArrowRight,
  Clock,
  Scissors,
  CheckCircle2,
  Trash2,
  Sliders,
  DollarSign,
  TrendingUp,
  ShieldCheck,
  Zap,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface IdeaGeneratorTabProps {
  ideas: YouTubeVideoIdea[];
  channel: YouTubeChannelProject;
  onCreateMasterScriptFromIdea: (idea: YouTubeVideoIdea) => void;
  onAddNewIdea: (idea: Omit<YouTubeVideoIdea, "id" | "createdAt">) => void;
  onDeleteIdea: (ideaId: string) => void;
}

export const IdeaGeneratorTab: React.FC<IdeaGeneratorTabProps> = ({
  ideas,
  channel,
  onCreateMasterScriptFromIdea,
  onAddNewIdea,
  onDeleteIdea,
}) => {
  const { toast } = useToast();
  const [selectedFormat, setSelectedFormat] = useState<string>("ALL");
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newAngle, setNewAngle] = useState("");
  const [newHook, setNewHook] = useState("");
  const [newSummary, setNewSummary] = useState("");
  const [newFormat, setNewFormat] = useState<VideoFormatType>("LONG_VIDEO");
  const [selectedIdeaDetail, setSelectedIdeaDetail] = useState<YouTubeVideoIdea | null>(ideas[0] || null);

  const filteredIdeas = ideas.filter((idea) => {
    if (selectedFormat === "ALL") return true;
    return idea.videoType === selectedFormat;
  });

  const getFormatBadge = (format: VideoFormatType) => {
    switch (format) {
      case "SHORT":
        return { label: "SHORT (30-60s)", className: "bg-red-500/15 text-red-400 border-red-500/30" };
      case "QUICK_VIDEO":
        return { label: "VÍDEO RÁPIDO (3-5m)", className: "bg-cyan-500/15 text-cyan-300 border-cyan-500/30" };
      case "LONG_VIDEO":
        return { label: "VÍDEO LONGO (8-15m)", className: "bg-blue-500/15 text-blue-300 border-blue-500/30" };
      case "DOCUMENTARY":
        return { label: "DOCUMENTÁRIO (15-30m+)", className: "bg-amber-500/15 text-amber-300 border-amber-500/30" };
    }
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    onAddNewIdea({
      channelId: channel.id,
      provisionalTitle: newTitle,
      alternativeTitles: [
        `Como ${newTitle} Vai Transformar o Mercado`,
        `O Guia Definitivo de ${newTitle}`,
        `${newTitle} (Estudo de Caso Auditado)`,
      ],
      editorialAngle: newAngle || "Abordagem educativa e prática baseada em dados e valor real.",
      targetAudience: channel.targetAudience,
      hook: newHook || "Você já percebeu o que está acontecendo agora neste mercado?",
      summary: newSummary || "Análise aprofundada com foco em utilidade e transparência.",
      videoType: newFormat,
      recommendedDurationMinutes: newFormat === "DOCUMENTARY" ? 20 : newFormat === "SHORT" ? 1 : 10,
      shortsExtractionPotential: newFormat === "DOCUMENTARY" ? 8 : 5,
      suggestedSources: ["Relatórios Oficiais de Mercado", "Estudos de Caso Auditados"],
      searchPotential: 90,
      monetizationPotential: 92,
      nonClickbaitAssurance: true,
    });

    setNewTitle("");
    setNewAngle("");
    setNewHook("");
    setNewSummary("");
    setShowCreateModal(false);

    toast({
      title: "Nova Ideia Adicionada",
      description: "A ideia foi registrada no laboratório e está pronta para roteirização.",
    });
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-studio-panel border border-studio-border flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-studio-gold/20 text-studio-gold border border-studio-gold/30">
              Idea Generator & Brainstorm
            </span>
            <span className="text-xs text-studio-text-muted">Total: {ideas.length} Conceitos</span>
          </div>
          <h2 className="text-lg font-bold text-studio-text font-display">
            Laboratório de Ideias Estratégicas de Alto RPM
          </h2>
          <p className="text-xs text-studio-text-dim max-w-2xl mt-0.5">
            Cada ideia é formulada com ângulo editorial autêntico, gancho psicológico ético e estimativa de monetização sem clickbait.
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="btn-gold text-xs py-2 px-4 gap-2 shrink-0 self-start md:self-auto"
        >
          <Plus className="w-4 h-4" />
          + Criar Nova Ideia
        </button>
      </div>

      {/* Format Filter Bar */}
      <div className="flex items-center gap-2 p-3 rounded-xl bg-studio-panel border border-studio-border overflow-x-auto">
        <span className="text-xs text-studio-text-muted font-medium shrink-0">Filtrar Formato:</span>
        {(["ALL", "LONG_VIDEO", "SHORT", "QUICK_VIDEO", "DOCUMENTARY"] as const).map((fmt) => (
          <button
            key={fmt}
            onClick={() => setSelectedFormat(fmt)}
            className={cn(
              "px-3 py-1 rounded-lg text-xs font-semibold shrink-0 transition-all",
              selectedFormat === fmt
                ? "bg-studio-blue text-white"
                : "bg-studio-bg text-studio-text-dim hover:text-studio-text border border-studio-border"
            )}
          >
            {fmt === "ALL"
              ? "Todos os Formatos"
              : fmt === "LONG_VIDEO"
              ? "Vídeos Longos (8-15m)"
              : fmt === "SHORT"
              ? "Shorts (30-60s)"
              : fmt === "QUICK_VIDEO"
              ? "Vídeos Rápidos (3-5m)"
              : "Documentários (15-30m+)"}
          </button>
        ))}
      </div>

      {/* Grid: Ideas List and Detail Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Ideas List */}
        <div className="lg:col-span-7 space-y-3 max-h-[750px] overflow-y-auto pr-1">
          {filteredIdeas.map((idea) => {
            const badge = getFormatBadge(idea.videoType);
            const isSelected = selectedIdeaDetail?.id === idea.id;

            return (
              <div
                key={idea.id}
                onClick={() => setSelectedIdeaDetail(idea)}
                className={cn(
                  "p-4 rounded-xl border transition-all cursor-pointer text-left space-y-3",
                  isSelected
                    ? "bg-studio-panel border-studio-gold ring-1 ring-studio-gold/50 shadow-md"
                    : "bg-studio-panel/60 border-studio-border hover:border-studio-border-hover hover:bg-studio-panel"
                )}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className={cn("px-2.5 py-0.5 rounded-full text-[10px] font-bold border", badge.className)}>
                      {badge.label}
                    </span>
                    <span className="text-[11px] text-studio-text-muted flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {idea.recommendedDurationMinutes} min
                    </span>
                    <span className="text-[11px] text-studio-text-muted flex items-center gap-1">
                      <Scissors className="w-3 h-3 text-studio-gold" />
                      {idea.shortsExtractionPotential} Shorts
                    </span>
                  </div>

                  <span className="text-xs font-mono font-bold text-studio-green flex items-center gap-0.5">
                    <DollarSign className="w-3.5 h-3.5" />
                    RPM: {idea.monetizationPotential}%
                  </span>
                </div>

                <div>
                  <h3 className="text-sm font-bold text-studio-text font-display leading-snug">
                    {idea.provisionalTitle}
                  </h3>
                  <p className="text-xs text-studio-text-dim line-clamp-2 mt-1">
                    {idea.summary}
                  </p>
                </div>

                <div className="pt-2 border-t border-studio-border/60 flex items-center justify-between text-xs">
                  <span className="text-[11px] text-studio-text-muted italic truncate max-w-[280px]">
                    Hook: "{idea.hook.slice(0, 45)}..."
                  </span>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onCreateMasterScriptFromIdea(idea);
                    }}
                    className="btn-gold text-[11px] py-1 px-2.5 gap-1 shrink-0"
                  >
                    <Zap className="w-3.5 h-3.5" />
                    Produzir Roteiro
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Column: Selected Idea Inspector */}
        <div className="lg:col-span-5">
          {selectedIdeaDetail ? (
            <div className="studio-card p-5 border border-studio-border space-y-5 sticky top-4">
              <div className="flex items-center justify-between pb-3 border-b border-studio-border">
                <div>
                  <span className="text-[10px] uppercase font-bold text-studio-text-muted">
                    Conceito & Ângulo Editorial
                  </span>
                  <h4 className="text-sm font-bold text-studio-text font-display">
                    {selectedIdeaDetail.provisionalTitle}
                  </h4>
                </div>

                <button
                  onClick={() => onDeleteIdea(selectedIdeaDetail.id)}
                  className="p-1.5 rounded-lg text-studio-text-muted hover:text-studio-red hover:bg-studio-red/10 transition-all"
                  title="Excluir ideia"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              {/* Hook Analysis */}
              <div className="p-3.5 rounded-xl bg-studio-panel border border-studio-border space-y-1.5">
                <span className="text-[10px] font-bold uppercase text-studio-gold flex items-center gap-1">
                  <Zap className="w-3.5 h-3.5" />
                  Hook Psicológico Inicial (0-5 segundos)
                </span>
                <p className="text-xs text-studio-text font-medium leading-relaxed">
                  "{selectedIdeaDetail.hook}"
                </p>
              </div>

              {/* Editorial Angle & Value Add */}
              <div className="space-y-2 text-xs">
                <div>
                  <span className="font-bold text-studio-text-muted block text-[11px] uppercase">
                    Ângulo Editorial
                  </span>
                  <p className="text-studio-text-dim mt-0.5">{selectedIdeaDetail.editorialAngle}</p>
                </div>

                <div className="pt-2 border-t border-studio-border">
                  <span className="font-bold text-studio-text-muted block text-[11px] uppercase">
                    Público-Alvo Específico
                  </span>
                  <p className="text-studio-text-dim mt-0.5">{selectedIdeaDetail.targetAudience}</p>
                </div>
              </div>

              {/* Title Alternatives (Non-clickbait) */}
              <div className="space-y-2 pt-2 border-t border-studio-border">
                <span className="font-bold text-studio-text-muted block text-[11px] uppercase flex items-center justify-between">
                  <span>Alternativas de Título Éticas</span>
                  <span className="text-studio-green flex items-center gap-1 text-[10px]">
                    <ShieldCheck className="w-3 h-3" />
                    Sem Clickbait Falso
                  </span>
                </span>
                <ul className="space-y-1.5">
                  {selectedIdeaDetail.alternativeTitles.map((alt, idx) => (
                    <li key={idx} className="text-xs text-studio-text flex items-start gap-2">
                      <span className="text-studio-gold font-bold">›</span>
                      <span>{alt}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Sources */}
              <div className="space-y-1.5 pt-2 border-t border-studio-border text-xs">
                <span className="font-bold text-studio-text-muted block text-[11px] uppercase">
                  Fontes Sugeridas
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {selectedIdeaDetail.suggestedSources.map((s, idx) => (
                    <span key={idx} className="px-2 py-0.5 rounded-md bg-studio-panel border border-studio-border text-[11px] text-studio-text-dim">
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action Button */}
              <button
                onClick={() => onCreateMasterScriptFromIdea(selectedIdeaDetail)}
                className="w-full btn-gold text-xs py-3 px-4 gap-2 justify-center shadow-lg"
              >
                <Sparkles className="w-4 h-4" />
                Gerar Roteiro Estruturado em 7 Fases + Fact Check
              </button>
            </div>
          ) : (
            <div className="p-8 text-center rounded-2xl bg-studio-panel border border-studio-border text-studio-text-muted text-xs">
              Selecione uma ideia para visualizar os detalhes completos.
            </div>
          )}
        </div>
      </div>

      {/* Modal to Add Custom Idea */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="studio-card w-full max-w-lg p-6 border border-studio-border shadow-2xl space-y-4 animate-fadeIn">
            <div className="flex items-center justify-between pb-3 border-b border-studio-border">
              <h3 className="text-base font-bold text-studio-text font-display">
                Criar Nova Ideia de Vídeo
              </h3>
              <button onClick={() => setShowCreateModal(false)} className="text-studio-text-muted hover:text-studio-text">
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-studio-text-muted mb-1 font-bold">Título Provisório</label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Como Criar um Micro-SaaS com IA em 30 Dias"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-studio-bg border border-studio-border text-studio-text focus:outline-none focus:border-studio-blue"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-studio-text-muted mb-1 font-bold">Formato do Vídeo</label>
                  <select
                    value={newFormat}
                    onChange={(e) => setNewFormat(e.target.value as VideoFormatType)}
                    className="w-full px-3 py-2 rounded-lg bg-studio-bg border border-studio-border text-studio-text focus:outline-none focus:border-studio-blue"
                  >
                    <option value="LONG_VIDEO">Vídeo Longo (8-15 min)</option>
                    <option value="SHORT">Short (30-60 seg)</option>
                    <option value="QUICK_VIDEO">Vídeo Rápido (3-5 min)</option>
                    <option value="DOCUMENTARY">Documentário (15-30+ min)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-studio-text-muted mb-1 font-bold">Gancho Inicial (0-5s)</label>
                  <input
                    type="text"
                    placeholder="Frase de alto impacto"
                    value={newHook}
                    onChange={(e) => setNewHook(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-studio-bg border border-studio-border text-studio-text focus:outline-none focus:border-studio-blue"
                  />
                </div>
              </div>

              <div>
                <label className="block text-studio-text-muted mb-1 font-bold">Ângulo Editorial</label>
                <input
                  type="text"
                  placeholder="Ex: Estudo prático de ROI para pequenas empresas"
                  value={newAngle}
                  onChange={(e) => setNewAngle(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-studio-bg border border-studio-border text-studio-text focus:outline-none focus:border-studio-blue"
                />
              </div>

              <div>
                <label className="block text-studio-text-muted mb-1 font-bold">Resumo do Conteúdo</label>
                <textarea
                  rows={3}
                  placeholder="Principais pontos a serem abordados..."
                  value={newSummary}
                  onChange={(e) => setNewSummary(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-studio-bg border border-studio-border text-studio-text focus:outline-none focus:border-studio-blue"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-studio-border">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="btn-secondary text-xs py-2 px-4"
                >
                  Cancelar
                </button>
                <button type="submit" className="btn-gold text-xs py-2 px-4">
                  Salvar Ideia
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
