// ============================================================
// AI CREATOR STUDIO — YOUTUBE FACTORY: COMPLIANCE AUDIT TAB
// Pre-publish quality gate, Copyright Guard & YouTube AI Disclosure Audit
// ============================================================

import React from "react";
import type {
  YouTubeComplianceReport,
  CopyrightResourceCheck,
  YouTubeMasterScript,
  YouTubeChannelProject,
} from "@/types/youtubeFactory";
import {
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  Lock,
  FileCheck,
  Award,
  Layers,
  Sparkles,
  Info,
  DollarSign,
  Send,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { auditYouTubeCompliance } from "@/lib/youtubeFactory/complianceEngine";

interface ComplianceAuditTabProps {
  script: YouTubeMasterScript | null;
  channel: YouTubeChannelProject;
  complianceReport: YouTubeComplianceReport | null;
  copyrightChecks: CopyrightResourceCheck[];
  onSetComplianceData: (data: { report: YouTubeComplianceReport; copyrightChecks: CopyrightResourceCheck[] }) => void;
  onNavigateToTab: (tabKey: string) => void;
}

export const ComplianceAuditTab: React.FC<ComplianceAuditTabProps> = ({
  script,
  channel,
  complianceReport,
  copyrightChecks,
  onSetComplianceData,
  onNavigateToTab,
}) => {
  const { toast } = useToast();

  const handleRunAudit = () => {
    if (!script) {
      toast({
        title: "Nenhum Roteiro Carregado",
        description: "Carregue ou gere um roteiro master antes de auditar compliance.",
        variant: "destructive",
      });
      return;
    }

    const { report, copyrightChecks: checks } = auditYouTubeCompliance(script, channel);
    onSetComplianceData({ report, copyrightChecks: checks });

    toast({
      title: "Auditoria de Compliance Concluída!",
      description: `Status do Quality Gate: ${(report?.qualityGateStatus || "APROVADO").replace(/_/g, " ")}`,
    });
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-studio-panel border border-studio-border flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-studio-green/20 text-studio-green border border-studio-green/30">
              YouTube Compliance Guard & Quality Gate
            </span>
            <span className="text-xs text-studio-text-muted font-medium">
              Auditoria Pré-Publicação
            </span>
          </div>
          <h2 className="text-lg font-bold text-studio-text font-display">
            Portão de Qualidade & Proteção de Monetização
          </h2>
          <p className="text-xs text-studio-text-dim max-w-2xl mt-0.5">
            Bloqueio preventivo contra conteúdo repetitivo, desinformação, promessas financeiras e violações de direitos autorais antes da publicação no YouTube.
          </p>
        </div>

        <button
          onClick={handleRunAudit}
          className="btn-gold text-xs py-2.5 px-4 gap-2 shrink-0 self-start md:self-auto shadow-lg"
        >
          <ShieldCheck className="w-4 h-4" />
          Reauditar Conteúdo Agora
        </button>
      </div>

      {!complianceReport ? (
        <div className="p-12 text-center rounded-2xl bg-studio-panel border border-studio-border space-y-4">
          <ShieldCheck className="w-12 h-12 text-studio-text-muted mx-auto" />
          <div>
            <h3 className="text-base font-bold text-studio-text font-display">
              Nenhuma Auditoria Realizada
            </h3>
            <p className="text-xs text-studio-text-muted mt-1 max-w-md mx-auto">
              Clique em "Reauditar Conteúdo Agora" para rodar o scanner de 7 critérios de conformidade do YouTube.
            </p>
          </div>
          <button onClick={handleRunAudit} className="btn-gold text-xs py-2 px-4 gap-2 mx-auto">
            <ShieldCheck className="w-4 h-4" />
            Executar Quality Gate
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Quality Gate Status Big Card */}
          <div
            className={cn(
              "p-6 rounded-2xl border flex flex-col md:flex-row md:items-center justify-between gap-4",
              complianceReport.qualityGateStatus === "APROVADO_PARA_PUBLICACAO"
                ? "bg-studio-green/10 border-studio-green/30"
                : "bg-amber-500/10 border-amber-500/30"
            )}
          >
            <div className="flex items-start gap-3.5">
              <div
                className={cn(
                  "w-10 h-10 rounded-xl flex items-center justify-center font-bold shrink-0",
                  complianceReport.qualityGateStatus === "APROVADO_PARA_PUBLICACAO"
                    ? "bg-studio-green text-black"
                    : "bg-amber-500 text-black"
                )}
              >
                {complianceReport.qualityGateStatus === "APROVADO_PARA_PUBLICACAO" ? (
                  <CheckCircle2 className="w-6 h-6" />
                ) : (
                  <AlertTriangle className="w-6 h-6" />
                )}
              </div>

              <div>
                <span className="text-[10px] uppercase font-black tracking-wider text-studio-text-muted block">
                  Quality Gate Status
                </span>
                <h3 className="text-base font-bold text-studio-text font-display">
                  {complianceReport.qualityGateStatus === "APROVADO_PARA_PUBLICACAO"
                    ? "🟢 APROVADO PARA PUBLICAÇÃO NO YOUTUBE"
                    : "⚠️ HUMAN REVIEW REQUIRED (Revisão Humana Obrigatória)"}
                </h3>
                <p className="text-xs text-studio-text-dim mt-1">
                  {complianceReport.qualityGateStatus === "APROVADO_PARA_PUBLICACAO"
                    ? "Todos os critérios de originalidade, segurança financeira, fact check e direitos autorais foram atendidos com excelência."
                    : `Bloqueio preventivo ativado: ${complianceReport.gateReasons.join(" · ")}`}
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                toast({
                  title: "Vídeo Enviado para Publicação / Agendamento!",
                  description: "O conteúdo aprovado pelo Quality Gate foi encaminhado para a fila de publicação do YouTube.",
                });
              }}
              disabled={complianceReport.qualityGateStatus !== "APROVADO_PARA_PUBLICACAO"}
              className="btn-gold text-xs py-3 px-5 gap-2 shrink-0 self-start md:self-auto shadow-lg disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Send className="w-4 h-4" />
              Publicar / Agendar no Canal
            </button>
          </div>

          {/* 6 Key Compliance Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="p-3.5 rounded-xl bg-studio-panel border border-studio-border text-center space-y-1">
              <span className="text-[10px] uppercase font-bold text-studio-text-muted block">Originalidade</span>
              <span className="text-base font-bold text-studio-green font-mono">
                {complianceReport.originalityScore}%
              </span>
            </div>

            <div className="p-3.5 rounded-xl bg-studio-panel border border-studio-border text-center space-y-1">
              <span className="text-[10px] uppercase font-bold text-studio-text-muted block">Valor ao Espectador</span>
              <span className="text-base font-bold text-studio-gold font-mono">
                {complianceReport.viewerValueScore}%
              </span>
            </div>

            <div className="p-3.5 rounded-xl bg-studio-panel border border-studio-border text-center space-y-1">
              <span className="text-[10px] uppercase font-bold text-studio-text-muted block">Repetitividade</span>
              <span className="text-base font-bold text-studio-text font-mono">
                {complianceReport.repetitivenessScore}% (Baixo)
              </span>
            </div>

            <div className="p-3.5 rounded-xl bg-studio-panel border border-studio-border text-center space-y-1">
              <span className="text-[10px] uppercase font-bold text-studio-text-muted block">Risco Copyright</span>
              <span className="text-base font-bold text-studio-green font-mono">
                {complianceReport.copyrightRisk}
              </span>
            </div>

            <div className="p-3.5 rounded-xl bg-studio-panel border border-studio-border text-center space-y-1">
              <span className="text-[10px] uppercase font-bold text-studio-text-muted block">AI Disclosure</span>
              <span className="text-xs font-bold text-studio-blue block mt-1">
                {complianceReport.aiDisclosureStatus}
              </span>
            </div>

            <div className="p-3.5 rounded-xl bg-studio-panel border border-studio-border text-center space-y-1">
              <span className="text-[10px] uppercase font-bold text-studio-text-muted block">Risco Monetização</span>
              <span className="text-base font-bold text-studio-green font-mono">
                {complianceReport.monetizationRisk}
              </span>
            </div>
          </div>

          {/* Copyright Guard Resource Checklist */}
          <div className="studio-card p-5 border border-studio-border space-y-4">
            <h3 className="text-xs font-bold text-studio-text uppercase tracking-wider flex items-center gap-2 pb-2 border-b border-studio-border">
              <Lock className="w-4 h-4 text-studio-gold" />
              Copyright Guard · Inventário de Mídias Licenciadas
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              {copyrightChecks.map((item) => (
                <div key={item.id} className="p-3 rounded-xl bg-studio-panel border border-studio-border space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold font-mono bg-studio-bg border border-studio-border text-studio-text">
                      {item.resourceType}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold font-mono bg-studio-green/15 text-studio-green">
                      {(item.status || "USO_AUTORIZADO").replace(/_/g, " ")}
                    </span>
                  </div>

                  <h4 className="font-bold text-studio-text">{item.resourceName}</h4>
                  <p className="text-[11px] text-studio-text-muted">Fonte: {item.licenseSource}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Legal Disclaimer Box */}
          <div className="p-4 rounded-xl bg-studio-bg/60 border border-studio-border text-xs text-studio-text-muted flex items-start gap-2.5">
            <Info className="w-4 h-4 text-studio-blue shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              <strong>Aviso Legal & Termos de Uso:</strong> {complianceReport.complianceDisclaimer}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
