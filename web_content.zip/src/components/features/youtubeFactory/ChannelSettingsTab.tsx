// ============================================================
// AI CREATOR STUDIO — YOUTUBE FACTORY: CHANNEL SETTINGS TAB
// Manage YouTube channels as independent projects with custom presets & automation levels
// ============================================================

import React, { useState } from "react";
import type {
  YouTubeChannelProject,
  ChannelPresetType,
  AutomationMode,
  VideoPacing,
  SubtitleStylePreset,
} from "@/types/youtubeFactory";
import {
  Settings,
  Tv,
  Plus,
  Sparkles,
  Sliders,
  Palette,
  Volume2,
  CheckCircle2,
  Trash2,
  Layers,
  Zap,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { CHANNEL_PRESETS } from "@/lib/youtubeFactory/channelStore";

interface ChannelSettingsTabProps {
  channels: YouTubeChannelProject[];
  activeChannel: YouTubeChannelProject;
  onSelectChannel: (channel: YouTubeChannelProject) => void;
  onCreateFromPreset: (presetKey: ChannelPresetType, name?: string, handle?: string) => void;
  onUpdateChannel: (channel: YouTubeChannelProject) => void;
}

export const ChannelSettingsTab: React.FC<ChannelSettingsTabProps> = ({
  channels,
  activeChannel,
  onSelectChannel,
  onCreateFromPreset,
  onUpdateChannel,
}) => {
  const { toast } = useToast();
  const [showNewPresetModal, setShowNewPresetModal] = useState(false);
  const [selectedPresetToCreate, setSelectedPresetToCreate] = useState<ChannelPresetType>("AI_FUTURO");
  const [customName, setCustomName] = useState("");
  const [customHandle, setCustomHandle] = useState("");

  const [formData, setFormData] = useState<YouTubeChannelProject>(activeChannel);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateChannel(formData);
    toast({
      title: "Configurações do Canal Salvas!",
      description: `O projeto do canal "${formData.name}" foi atualizado com sucesso.`,
    });
  };

  const handlePresetCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCreateFromPreset(selectedPresetToCreate, customName, customHandle);
    setCustomName("");
    setCustomHandle("");
    setShowNewPresetModal(false);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-studio-panel border border-studio-border flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-studio-blue/20 text-studio-blue border border-studio-blue/30">
              YouTube Channel Factory
            </span>
            <span className="text-xs text-studio-text-muted font-medium">
              {channels.length} Canais Criados
            </span>
          </div>
          <h2 className="text-lg font-bold text-studio-text font-display">
            Gerenciamento de Canais como Projetos Independentes
          </h2>
          <p className="text-xs text-studio-text-dim max-w-2xl mt-0.5">
            Cada canal possui sua própria identidade visual, perfis de voz, estilo de edição, nicho, persona de avatar e regras de automação.
          </p>
        </div>

        <button
          onClick={() => setShowNewPresetModal(true)}
          className="btn-gold text-xs py-2 px-4 gap-2 shrink-0 self-start md:self-auto shadow-lg"
        >
          <Plus className="w-4 h-4" />
          + Novo Canal a Partir de Preset
        </button>
      </div>

      {/* Channel Switcher List */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {channels.map((ch) => {
          const isActive = ch.id === activeChannel.id;

          return (
            <div
              key={ch.id}
              onClick={() => {
                onSelectChannel(ch);
                setFormData(ch);
              }}
              className={cn(
                "p-4 rounded-xl border transition-all cursor-pointer text-left space-y-3",
                isActive
                  ? "bg-studio-panel border-studio-gold ring-1 ring-studio-gold/50 shadow-md"
                  : "bg-studio-panel/60 border-studio-border hover:bg-studio-panel"
              )}
            >
              <div className="flex items-center gap-3">
                <img
                  src={ch.logoUrl}
                  alt={ch.name}
                  className="w-10 h-10 rounded-full object-cover border border-studio-border shrink-0"
                  referrerPolicy="no-referrer"
                />
                <div className="overflow-hidden">
                  <h3 className="text-xs font-bold text-studio-text truncate">{ch.name}</h3>
                  <span className="text-[11px] text-studio-text-muted block truncate font-mono">
                    {ch.handle}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between text-[11px] pt-2 border-t border-studio-border/60">
                <span className="text-studio-blue font-medium truncate max-w-[150px]">
                  {ch.niche}
                </span>
                {(() => {
                  const mode = ch.automationLevel || ch.automationMode || "SEMI_AUTOMATICO";
                  return (
                    <span
                      className={cn(
                        "px-2 py-0.5 rounded text-[9px] font-bold uppercase",
                        mode === "AUTOMATICO"
                          ? "bg-studio-green/15 text-studio-green"
                          : mode === "SEMI_AUTOMATICO"
                          ? "bg-studio-gold/15 text-studio-gold"
                          : "bg-studio-blue/15 text-studio-blue"
                      )}
                    >
                      {String(mode).replace(/_/g, " ")}
                    </span>
                  );
                })()}
              </div>
            </div>
          );
        })}
      </div>

      {/* Active Channel Settings Form */}
      <form onSubmit={handleSave} className="studio-card p-6 border border-studio-border space-y-6">
        <div className="flex items-center justify-between pb-3 border-b border-studio-border">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-studio-gold" />
            <div>
              <h3 className="text-sm font-bold text-studio-text font-display">
                Configurações do Projeto: {formData.name}
              </h3>
              <span className="text-[11px] text-studio-text-muted">
                Identidade, Voz, Estilo de Edição e Automação
              </span>
            </div>
          </div>

          <button type="submit" className="btn-gold text-xs py-2 px-4 gap-2">
            <CheckCircle2 className="w-4 h-4" />
            Salvar Alterações
          </button>
        </div>

        {/* Basic Meta */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div>
            <label className="block text-studio-text-muted font-bold mb-1 uppercase text-[10px]">
              Nome do Canal
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-3 py-2 rounded-lg bg-studio-bg border border-studio-border text-studio-text focus:outline-none focus:border-studio-blue"
            />
          </div>

          <div>
            <label className="block text-studio-text-muted font-bold mb-1 uppercase text-[10px]">
              @Handle Oficial
            </label>
            <input
              type="text"
              required
              value={formData.handle}
              onChange={(e) => setFormData({ ...formData, handle: e.target.value })}
              className="w-full px-3 py-2 rounded-lg bg-studio-bg border border-studio-border text-studio-text focus:outline-none focus:border-studio-blue font-mono"
            />
          </div>

          <div>
            <label className="block text-studio-text-muted font-bold mb-1 uppercase text-[10px]">
              Modo de Automação
            </label>
            <select
              value={formData.automationLevel || formData.automationMode || "SEMI_AUTOMATICO"}
              onChange={(e) => {
                const val = e.target.value as AutomationMode;
                setFormData({ ...formData, automationLevel: val, automationMode: val });
              }}
              className="w-full px-3 py-2 rounded-lg bg-studio-bg border border-studio-border text-studio-text focus:outline-none focus:border-studio-blue font-medium"
            >
              <option value="MANUAL">Manual (Aprovação Passo a Passo)</option>
              <option value="SEMI_AUTOMATICO">Semi-Automático (Revisão Prévia)</option>
              <option value="AUTOMATICO">Automático (Pipeline Supervisionado)</option>
            </select>
          </div>
        </div>

        {/* Description & Target Audience */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="block text-studio-text-muted font-bold mb-1 uppercase text-[10px]">
              Descrição / Bio do Canal
            </label>
            <textarea
              rows={3}
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-3 py-2 rounded-lg bg-studio-bg border border-studio-border text-studio-text focus:outline-none focus:border-studio-blue"
            />
          </div>

          <div>
            <label className="block text-studio-text-muted font-bold mb-1 uppercase text-[10px]">
              Público-Alvo Definido
            </label>
            <textarea
              rows={3}
              value={formData.targetAudience}
              onChange={(e) => setFormData({ ...formData, targetAudience: e.target.value })}
              className="w-full px-3 py-2 rounded-lg bg-studio-bg border border-studio-border text-studio-text focus:outline-none focus:border-studio-blue"
            />
          </div>
        </div>

        {/* Visual Identity & Voice */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs pt-3 border-t border-studio-border">
          <div>
            <label className="block text-studio-text-muted font-bold mb-1 uppercase text-[10px]">
              Cor Primária da Identidade
            </label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={formData.visualIdentity.primaryColor}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    visualIdentity: { ...formData.visualIdentity, primaryColor: e.target.value },
                  })
                }
                className="w-9 h-9 rounded-lg bg-transparent cursor-pointer border border-studio-border"
              />
              <span className="font-mono text-xs text-studio-text">{formData.visualIdentity.primaryColor}</span>
            </div>
          </div>

          <div>
            <label className="block text-studio-text-muted font-bold mb-1 uppercase text-[10px]">
              Ritmo de Edição (Pacing)
            </label>
            <select
              value={formData.editingStyle.pacing}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  editingStyle: { ...formData.editingStyle, pacing: e.target.value as VideoPacing },
                })
              }
              className="w-full px-3 py-2 rounded-lg bg-studio-bg border border-studio-border text-studio-text focus:outline-none"
            >
              <option value="FAST_PACED">Rápido / Dinâmico (Cortes a cada 2-4s)</option>
              <option value="BALANCED">Equilibrado (Cortes a cada 5-8s)</option>
              <option value="CINEMATIC_SLOW">Cinematográfico / Imersivo (Cortes a cada 8-12s)</option>
            </select>
          </div>

          <div>
            <label className="block text-studio-text-muted font-bold mb-1 uppercase text-[10px]">
              Estilo de Legendas Dinâmicas
            </label>
            <select
              value={formData.editingStyle.subtitleStyle}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  editingStyle: {
                    ...formData.editingStyle,
                    subtitleStyle: e.target.value as SubtitleStylePreset,
                  },
                })
              }
              className="w-full px-3 py-2 rounded-lg bg-studio-bg border border-studio-border text-studio-text focus:outline-none"
            >
              <option value="KINETIC_BOUNCE_YELLOW">Kinetic Bounce Amarelo (Alto Impacto)</option>
              <option value="HORMOZI_BOLD">Hormozi Bold (Palavra por Palavra)</option>
              <option value="MINIMAL_WHITE">Minimalista Branco & Cinza</option>
              <option value="NEON_GLOW_CYAN">Neon Glow Cyan Futurista</option>
            </select>
          </div>
        </div>
      </form>

      {/* Preset Creator Modal */}
      {showNewPresetModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="studio-card w-full max-w-lg p-6 border border-studio-border shadow-2xl space-y-4 animate-fadeIn">
            <div className="flex items-center justify-between pb-3 border-b border-studio-border">
              <h3 className="text-base font-bold text-studio-text font-display">
                Criar Canal a Partir de Preset Oficial
              </h3>
              <button onClick={() => setShowNewPresetModal(false)} className="text-studio-text-muted hover:text-studio-text">
                ✕
              </button>
            </div>

            <form onSubmit={handlePresetCreateSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-studio-text-muted mb-1 font-bold">Selecione o Nicho Especializado</label>
                <div className="space-y-2">
                  {Object.entries(CHANNEL_PRESETS).map(([key, p]) => (
                    <div
                      key={key}
                      onClick={() => setSelectedPresetToCreate(key as ChannelPresetType)}
                      className={cn(
                        "p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between",
                        selectedPresetToCreate === key
                          ? "bg-studio-blue/15 border-studio-blue text-studio-text font-bold"
                          : "bg-studio-panel border-studio-border text-studio-text-muted hover:text-studio-text"
                      )}
                    >
                      <div>
                        <span className="block text-xs text-studio-text">{p.name}</span>
                        <span className="text-[10px] text-studio-text-muted">{p.niche}</span>
                      </div>
                      <span className="text-[10px] uppercase font-mono font-bold text-studio-blue">
                        {key.replace("_", " ")}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-studio-text-muted mb-1 font-bold">Nome Personalizado (Opcional)</label>
                <input
                  type="text"
                  placeholder="Deixe em branco para usar o nome padrão do preset"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-studio-bg border border-studio-border text-studio-text focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-studio-border">
                <button
                  type="button"
                  onClick={() => setShowNewPresetModal(false)}
                  className="btn-secondary text-xs py-2 px-4"
                >
                  Cancelar
                </button>
                <button type="submit" className="btn-gold text-xs py-2 px-4">
                  Criar Canal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
