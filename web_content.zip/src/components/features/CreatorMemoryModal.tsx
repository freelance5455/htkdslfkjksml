// ============================================================
// AI CREATOR STUDIO — CORE 3.0 CREATOR MEMORY MODAL
// Stores preferences, forbidden words, tone rules, and audience quirks
// ============================================================

import { useState } from "react";
import {
  Brain, Plus, Trash2, CheckCircle2, Sparkles, X,
  ShieldAlert, Volume2, Palette, Users
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { MemoryEntry, MemoryCategory } from "@/types/core3";
import { getMemoryEntries, saveMemoryEntry, deleteMemoryEntry } from "@/lib/core3/creatorMemoryStore";

interface CreatorMemoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CreatorMemoryModal({ isOpen, onClose }: CreatorMemoryModalProps) {
  const [entries, setEntries] = useState<MemoryEntry[]>(getMemoryEntries());
  const [newTitle, setNewTitle] = useState("");
  const [newValue, setNewValue] = useState("");
  const [newCat, setNewCat] = useState<MemoryCategory>("BRAND");

  if (!isOpen) return null;

  const handleAdd = () => {
    if (!newTitle.trim() || !newValue.trim()) return;
    saveMemoryEntry({
      category: newCat,
      key: newTitle.toLowerCase().replace(/\s+/g, "_"),
      title: newTitle.trim(),
      value: newValue.trim(),
      tags: [newCat.toLowerCase()],
      confidence: 100,
      source: "USER_INPUT",
    });
    setEntries(getMemoryEntries());
    setNewTitle("");
    setNewValue("");
  };

  const handleDelete = (id: string) => {
    deleteMemoryEntry(id);
    setEntries(getMemoryEntries());
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="studio-card w-full max-w-2xl max-h-[90vh] flex flex-col border border-studio-border shadow-2xl overflow-hidden animate-fadeIn">
        {/* Header */}
        <div className="p-5 border-b border-studio-border flex items-center justify-between bg-studio-panel shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-studio-purple to-pink-600 flex items-center justify-center text-white font-bold shadow-md">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-studio-text font-display">
                Memória do Criador (Creator Memory)
              </h2>
              <p className="text-xs text-studio-text-muted">
                Diretrizes que o AI Autopilot nunca esquece ao gerar roteiros e ativos
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-studio-text-muted hover:text-studio-text hover:bg-studio-border transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {/* Add New Rule */}
          <div className="p-4 rounded-xl bg-studio-panel border border-studio-border space-y-3">
            <h3 className="text-xs font-bold text-studio-text font-display uppercase tracking-wider">
              Adicionar Nova Diretriz à Memória
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <select
                value={newCat}
                onChange={(e) => setNewCat(e.target.value as MemoryCategory)}
                className="input text-xs"
              >
                <option value="CREATOR">Identidade do Criador</option>
                <option value="BRAND">Marca & Tom</option>
                <option value="CONTENT">Regras de Conteúdo</option>
                <option value="PROJECT">Projetos & Séries</option>
                <option value="PERFORMANCE">Padrões de Desempenho</option>
                <option value="PREFERENCE">Formatos Preferidos</option>
              </select>

              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="Título da Diretriz"
                className="input text-xs"
              />

              <input
                type="text"
                value={newValue}
                onChange={(e) => setNewValue(e.target.value)}
                placeholder="Descrição / Regra estrita"
                className="input text-xs"
              />
            </div>

            <div className="flex justify-end">
              <button
                onClick={handleAdd}
                disabled={!newTitle.trim() || !newValue.trim()}
                className="btn-primary text-xs py-1.5 px-3 gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                Salvar na Memória
              </button>
            </div>
          </div>

          {/* Active Rules List */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-studio-text font-display uppercase tracking-wider">
              Memórias Ativas ({entries.length})
            </h3>

            <div className="space-y-2">
              {entries.map((entry) => (
                <div
                  key={entry.id}
                  className="p-3.5 rounded-xl bg-studio-panel border border-studio-border flex items-center justify-between gap-3 hover:border-studio-purple/30 transition-all"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] px-2 py-0.5 rounded font-mono font-bold bg-studio-purple/15 text-studio-purple">
                        {entry.category}
                      </span>
                      <p className="text-xs font-bold text-studio-text">{entry.title}</p>
                    </div>
                    <p className="text-xs text-studio-text-muted">{entry.value}</p>
                  </div>

                  <button
                    onClick={() => handleDelete(entry.id)}
                    className="p-1.5 rounded-lg text-studio-text-muted hover:text-studio-red hover:bg-studio-red/10 transition-all"
                    title="Excluir regra"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-studio-border bg-studio-panel flex items-center justify-between shrink-0">
          <p className="text-[11px] text-studio-text-muted">
            Todas as regras são injetadas no contexto dos prompts do GEMINI, IMAGEN e ELEVENLABS.
          </p>
          <button onClick={onClose} className="btn-secondary text-xs py-2 px-4">
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
}
