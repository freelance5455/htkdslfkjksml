// ============================================================
// AI CREATOR STUDIO — CORE 3.0 NOTIFICATION CENTER MODAL
// Alerts for publishing approval, budget limits, generation completions
// ============================================================

import { useState, useEffect } from "react";
import {
  Bell, CheckCircle2, AlertTriangle, AlertCircle, Sparkles,
  DollarSign, X, Check, ArrowRight
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { StudioNotification } from "@/types/core3";
import {
  getNotifications,
  markNotificationAsRead,
  markAllNotificationsAsRead,
} from "@/lib/core3/notificationStore";

interface NotificationCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate?: (url: string) => void;
}

export default function NotificationCenterModal({
  isOpen,
  onClose,
  onNavigate,
}: NotificationCenterModalProps) {
  const [notifications, setNotifications] = useState<StudioNotification[]>(getNotifications());

  useEffect(() => {
    if (isOpen) {
      setNotifications(getNotifications());
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleMarkAllRead = () => {
    markAllNotificationsAsRead();
    setNotifications(getNotifications());
  };

  const handleItemClick = (n: StudioNotification) => {
    markNotificationAsRead(n.id);
    setNotifications(getNotifications());
    if (n.linkUrl && onNavigate) {
      onClose();
      onNavigate(n.linkUrl);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="studio-card w-full max-w-lg max-h-[85vh] flex flex-col border border-studio-border shadow-2xl overflow-hidden animate-fadeIn">
        {/* Header */}
        <div className="p-4 border-b border-studio-border flex items-center justify-between bg-studio-panel shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-studio-blue/20 flex items-center justify-center text-studio-blue">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-studio-text font-display">
                Notificações & Alertas
              </h2>
              <p className="text-[11px] text-studio-text-muted">Central de eventos do Autopilot</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleMarkAllRead}
              className="text-[11px] text-studio-blue hover:underline"
            >
              Marcar lidas
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-md text-studio-text-muted hover:text-studio-text hover:bg-studio-border"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Notifications List */}
        <div className="p-4 overflow-y-auto space-y-2 flex-1">
          {notifications.length === 0 ? (
            <p className="text-xs text-studio-text-muted text-center py-12">
              Nenhuma notificação no momento.
            </p>
          ) : (
            notifications.map((n) => {
              const isUnread = !n.read;
              return (
                <div
                  key={n.id}
                  onClick={() => handleItemClick(n)}
                  className={cn(
                    "p-3.5 rounded-xl border transition-all cursor-pointer space-y-1.5",
                    isUnread
                      ? "bg-studio-panel border-studio-blue/40 shadow-xs"
                      : "bg-studio-surface border-studio-border/60 hover:border-studio-border"
                  )}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      {n.severity === "CRITICAL" ? (
                        <AlertTriangle className="w-4 h-4 text-studio-red shrink-0" />
                      ) : n.severity === "WARNING" ? (
                        <AlertCircle className="w-4 h-4 text-yellow-400 shrink-0" />
                      ) : n.severity === "SUCCESS" ? (
                        <CheckCircle2 className="w-4 h-4 text-studio-green shrink-0" />
                      ) : (
                        <Sparkles className="w-4 h-4 text-studio-blue shrink-0" />
                      )}
                      <h4 className="text-xs font-bold text-studio-text">{n.title}</h4>
                    </div>

                    {isUnread && (
                      <span className="w-2 h-2 rounded-full bg-studio-blue shrink-0 mt-1" />
                    )}
                  </div>

                  <p className="text-xs text-studio-text-muted leading-relaxed pl-6">
                    {n.message}
                  </p>

                  {n.actionLabel && (
                    <div className="pl-6 pt-1">
                      <span className="text-[11px] font-bold text-studio-blue hover:underline flex items-center gap-1">
                        {n.actionLabel}
                        <ArrowRight className="w-3 h-3" />
                      </span>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
