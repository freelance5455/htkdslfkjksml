// ============================================================
// AI CREATOR STUDIO — CORE 3.0 AI AUTOPILOT COMMAND CENTER
// Natural language command processing, Mode Selector, Emergency Stop,
// Human-in-the-loop Approval & Pipeline Orchestration
// ============================================================

import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Sparkles, Zap, ShieldAlert, CheckCircle2, Play, Pause, AlertTriangle,
  ArrowRight, RefreshCw, Send, Lock, ChevronRight, Layers, Clock,
  Cpu, Flame, Sliders, Check, HelpCircle
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { AutopilotConfig, AutopilotMode, NLPCommandResult, WorkflowJob } from "@/types/core3";
import {
  getAutopilotConfig,
  saveAutopilotConfig,
  setAutopilotMode,
  triggerEmergencyStop,
  resumeAutopilot,
  processNaturalLanguageCommand,
} from "@/lib/core3/autopilotCoordinator";
import { getWorkflowJobs, executeWorkflowStep } from "@/lib/core3/workflowEngine";

interface AIAutopilotCommandCenterProps {
  onOpenDailyBrief?: () => void;
  onOpenBudget?: () => void;
  onOpenMemory?: () => void;
  onOpenStrategy?: () => void;
}

export default function AIAutopilotCommandCenter({
  onOpenDailyBrief,
  onOpenBudget,
  onOpenMemory,
  onOpenStrategy,
}: AIAutopilotCommandCenterProps) {
  const navigate = useNavigate();
  const [config, setConfig] = useState<AutopilotConfig>(getAutopilotConfig());
  const [inputPrompt, setInputPrompt] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [commandResult, setCommandResult] = useState<NLPCommandResult | null>(null);
  const [activeJobs, setActiveJobs] = useState<WorkflowJob[]>([]);
  const [showModeModal, setShowModeModal] = useState(false);

  useEffect(() => {
    refreshData();
    const interval = setInterval(refreshData, 3000);
    return () => clearInterval(interval);
  }, []);

  const refreshData = () => {
    setConfig(getAutopilotConfig());
    setActiveJobs(getWorkflowJobs());
  };

  const handleModeChange = (mode: AutopilotMode) => {
    const updated = setAutopilotMode(mode);
    setConfig(updated);
    setShowModeModal(false);
  };

  const handleEmergencyStopToggle = () => {
    if (config.emergencyStop) {
      const updated = resumeAutopilot();
      setConfig(updated);
    } else {
      const updated = triggerEmergencyStop();
      setConfig(updated);
    }
    refreshData();
  };

  const handleRunCommand = async (promptToRun?: string) => {
    const text = promptToRun || inputPrompt;
    if (!text.trim() || isProcessing) return;

    setIsProcessing(true);
    try {
      const res = await processNaturalLanguageCommand(text, config.mode);
      setCommandResult(res);
      setInputPrompt("");
      refreshData();
    } catch (err) {
      console.error("Erro ao processar comando do Autopilot:", err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleApproveJobPublish = async (jobId: string) => {
    const jobs = getWorkflowJobs();
    const job = jobs.find((j) => j.id === jobId);
    if (!job) return;

    // Approve the current waiting step
    const current = job.steps[job.currentStepIndex];
    if (current && current.requiresApproval) {
      current.approved = true;
      current.status = "PENDING";
      job.status = "RUNNING";
    }

    try {
      await executeWorkflowStep(job.id);
      refreshData();
    } catch (err) {
      console.error("Erro ao aprovar workflow:", err);
    }
  };

  const pendingApprovalJobs = activeJobs.filter(
    (j) => j.status === "WAITING_APPROVAL" || j.steps.some((s) => s.status === "WAITING_APPROVAL")
  );

  const runningWorkflows = activeJobs.filter(
    (j) => j.status === "RUNNING" || j.status === "PENDING"
  );

  return (
    <div className="space-y-6">
      {/* Top Banner: Status, Mode, Emergency Switch */}
      <div className="studio-card p-5 border border-studio-blue/30 relative overflow-hidden bg-gradient-to-br from-studio-surface via-studio-surface to-studio-blue/5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          {/* Status badge & mode */}
          <div className="flex items-center gap-3">
            <div className={cn(
              "w-10 h-10 rounded-xl flex items-center justify-center font-bold text-white shadow-md",
              config.emergencyStop
                ? "bg-studio-red animate-pulse"
                : config.mode === "AUTOPILOT"
                ? "bg-gradient-to-br from-studio-purple to-studio-blue"
                : config.mode === "ASSISTED"
                ? "bg-gradient-to-br from-studio-blue to-teal-500"
                : "bg-studio-panel border border-studio-border text-studio-text"
            )}>
              {config.emergencyStop ? (
                <ShieldAlert className="w-5 h-5" />
              ) : (
                <Cpu className="w-5 h-5" />
              )}
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-studio-text font-display flex items-center gap-2">
                  AI Autopilot Controller
                  <span className="text-[10px] uppercase px-2 py-0.5 rounded-full font-mono bg-studio-blue/20 text-studio-blue border border-studio-blue/30">
                    CORE 3.0
                  </span>
                </h2>
              </div>
              <p className="text-xs text-studio-text-muted">
                {config.emergencyStop ? (
                  <span className="text-studio-red font-semibold flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3" /> SISTEMA EM EMERGENCY STOP — Todas as execuções automáticas suspensas
                  </span>
                ) : (
                  <span>
                    Modo: <strong className="text-studio-text">{config.mode}</strong> · Aprovação Humana de Publicação: <strong className="text-studio-green">PROTEGIDA</strong>
                  </span>
                )}
              </p>
            </div>
          </div>

          {/* Mode Switcher & Emergency Stop Button */}
          <div className="flex items-center gap-2">
            {/* Mode selector button */}
            <div className="flex items-center bg-studio-panel border border-studio-border rounded-xl p-1">
              {(["MANUAL", "ASSISTED", "AUTOPILOT"] as AutopilotMode[]).map((m) => (
                <button
                  key={m}
                  onClick={() => handleModeChange(m)}
                  className={cn(
                    "px-3 py-1.5 rounded-lg text-xs font-semibold transition-all",
                    config.mode === m
                      ? m === "AUTOPILOT"
                        ? "bg-studio-purple text-white shadow-xs"
                        : m === "ASSISTED"
                        ? "bg-studio-blue text-white shadow-xs"
                        : "bg-studio-border text-studio-text shadow-xs"
                      : "text-studio-text-muted hover:text-studio-text"
                  )}
                >
                  {m}
                </button>
              ))}
            </div>

            {/* Emergency STOP Button */}
            <button
              onClick={handleEmergencyStopToggle}
              className={cn(
                "px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 border shadow-sm",
                config.emergencyStop
                  ? "bg-studio-green/15 text-studio-green border-studio-green/40 hover:bg-studio-green/25"
                  : "bg-studio-red/15 text-studio-red border-studio-red/40 hover:bg-studio-red hover:text-white"
              )}
            >
              {config.emergencyStop ? (
                <>
                  <Play className="w-4 h-4" />
                  Reativar Autopilot
                </>
              ) : (
                <>
                  <ShieldAlert className="w-4 h-4" />
                  EMERGENCY STOP
                </>
              )}
            </button>
          </div>
        </div>

        {/* Quick auxiliary trigger bar */}
        <div className="mt-4 pt-3 border-t border-studio-border/60 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-studio-text-muted">
            <Lock className="w-3.5 h-3.5 text-studio-green" />
            <span>Human-in-the-loop: Nenhuma mídia é publicada em canais reais sem sua autorização expressa.</span>
          </div>

          <div className="flex items-center gap-2">
            {onOpenDailyBrief && (
              <button
                onClick={onOpenDailyBrief}
                className="px-2.5 py-1 rounded-lg bg-studio-panel border border-studio-border hover:border-studio-blue/30 text-studio-text hover:text-studio-blue transition-all"
              >
                📋 Daily Brief
              </button>
            )}
            {onOpenStrategy && (
              <button
                onClick={onOpenStrategy}
                className="px-2.5 py-1 rounded-lg bg-studio-panel border border-studio-border hover:border-studio-blue/30 text-studio-text hover:text-studio-blue transition-all"
              >
                🎯 Estratégia
              </button>
            )}
            {onOpenBudget && (
              <button
                onClick={onOpenBudget}
                className="px-2.5 py-1 rounded-lg bg-studio-panel border border-studio-border hover:border-studio-blue/30 text-studio-text hover:text-studio-blue transition-all"
              >
                💰 Orçamento Seguro
              </button>
            )}
            {onOpenMemory && (
              <button
                onClick={onOpenMemory}
                className="px-2.5 py-1 rounded-lg bg-studio-panel border border-studio-border hover:border-studio-blue/30 text-studio-text hover:text-studio-blue transition-all"
              >
                🧠 Memória do Criador
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Natural Language Command Bar */}
      <div className="studio-card p-5 border border-studio-border relative shadow-lg">
        <div className="flex items-center gap-2 mb-3">
          <Sparkles className="w-4 h-4 text-studio-blue" />
          <h3 className="text-sm font-bold text-studio-text font-display">
            Natural Language Command Center
          </h3>
          <span className="text-[11px] text-studio-text-muted">
            (Fale naturalmente com o AI Autopilot)
          </span>
        </div>

        {/* Input box */}
        <div className="relative flex items-center">
          <input
            type="text"
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleRunCommand();
              }
            }}
            placeholder="Ex: 'Quero crescer meu canal infantil', 'Planeja minha semana', 'Cria 5 ideias', 'Produz as duas melhores'..."
            disabled={isProcessing || config.emergencyStop}
            className="w-full bg-studio-panel border border-studio-border rounded-xl pl-4 pr-24 py-3 text-sm text-studio-text placeholder-studio-text-muted focus:outline-hidden focus:border-studio-blue transition-all disabled:opacity-50"
          />

          <button
            onClick={() => handleRunCommand()}
            disabled={!inputPrompt.trim() || isProcessing || config.emergencyStop}
            className="absolute right-2 btn-primary text-xs py-2 px-3.5 gap-1.5"
          >
            {isProcessing ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                Processando...
              </>
            ) : (
              <>
                <Send className="w-3.5 h-3.5" />
                Executar
              </>
            )}
          </button>
        </div>

        {/* Quick prompt suggestions */}
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <span className="text-[11px] text-studio-text-muted flex items-center gap-1">
            <Zap className="w-3 h-3 text-studio-gold" />
            Comandos Rápidos:
          </span>
          {[
            "Quero crescer meu canal infantil",
            "Planeja minha semana",
            "Cria 5 ideias virais",
            "Produz as duas melhores",
            "Analisa meus resultados",
            "Transforma o último vídeo em Shorts",
          ].map((prompt) => (
            <button
              key={prompt}
              onClick={() => handleRunCommand(prompt)}
              disabled={isProcessing || config.emergencyStop}
              className="text-xs px-2.5 py-1 rounded-lg bg-studio-panel hover:bg-studio-border border border-studio-border/60 hover:border-studio-blue/40 text-studio-text-dim hover:text-studio-text transition-all disabled:opacity-50"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Command Output Result */}
        {commandResult && (
          <div className="mt-4 p-4 rounded-xl bg-studio-panel border border-studio-blue/30 space-y-3 animate-fadeIn">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-md bg-studio-blue/20 flex items-center justify-center text-studio-blue">
                  <Check className="w-3.5 h-3.5" />
                </div>
                <div>
                  <p className="text-xs font-bold text-studio-text font-display">
                    {commandResult.understoodIntent}
                  </p>
                  <p className="text-[10px] text-studio-text-muted uppercase">
                    Ação: {commandResult.actionTaken} · Modo: {commandResult.mode}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setCommandResult(null)}
                className="text-xs text-studio-text-muted hover:text-studio-text"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-studio-text leading-relaxed bg-studio-bg/60 p-3 rounded-lg border border-studio-border">
              {commandResult.summary}
            </p>

            {/* Follow up action triggers */}
            {commandResult.suggestedFollowUps && commandResult.suggestedFollowUps.length > 0 && (
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <span className="text-[11px] text-studio-text-muted font-medium">Próximos passos sugeridos:</span>
                {commandResult.suggestedFollowUps.map((actionText) => (
                  <button
                    key={actionText}
                    onClick={() => {
                      if (actionText.includes("Calendário")) navigate("/calendar");
                      else if (actionText.includes("Shorts") || actionText.includes("Cortes")) navigate("/analytics");
                      else if (actionText.includes("Analytics")) navigate("/analytics");
                      else if (actionText.includes("Produzir") || actionText.includes("Fila")) navigate("/projects");
                      else handleRunCommand(actionText);
                    }}
                    className="text-xs px-2.5 py-1 rounded-md bg-studio-blue/15 hover:bg-studio-blue text-studio-blue hover:text-white transition-all font-medium flex items-center gap-1"
                  >
                    <span>{actionText}</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Human-in-the-loop Approval Queue (CRITICAL SAFETY GATE) */}
      {pendingApprovalJobs.length > 0 && (
        <div className="studio-card p-5 border-2 border-yellow-500/40 bg-yellow-500/5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-yellow-400" />
              <div>
                <h3 className="text-sm font-bold text-studio-text font-display">
                  Fila de Aprovação Humana (Human-in-the-Loop)
                </h3>
                <p className="text-xs text-studio-text-muted">
                  O Autopilot completou a produção e renderização. A publicação externa requer sua autorização.
                </p>
              </div>
            </div>
            <span className="text-xs font-mono px-2.5 py-1 rounded-full bg-yellow-400/20 text-yellow-300 font-bold">
              {pendingApprovalJobs.length} aguardando
            </span>
          </div>

          <div className="space-y-3">
            {pendingApprovalJobs.map((job) => (
              <div
                key={job.id}
                className="p-4 rounded-xl bg-studio-surface border border-studio-border flex flex-wrap items-center justify-between gap-3 shadow-sm"
              >
                <div className="space-y-1">
                  <p className="text-sm font-bold text-studio-text">{job.title}</p>
                  <p className="text-xs text-studio-text-muted">
                    Etapa: <span className="text-yellow-400 font-medium">{job.steps[job.currentStepIndex]?.label}</span> · Formato: YouTube (16:9) & TikTok (9:16)
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => navigate(`/projects/${job.projectId}`)}
                    className="btn-secondary text-xs py-2 px-3"
                  >
                    Revisar Mídia
                  </button>
                  <button
                    onClick={() => handleApproveJobPublish(job.id)}
                    className="btn-gold text-xs py-2 px-4 gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Autorizar Publicação
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Active Workflows Monitor (Pipelines) */}
      {runningWorkflows.length > 0 && (
        <div className="studio-card p-5 border border-studio-border space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-studio-blue animate-spin" />
              <h3 className="text-sm font-bold text-studio-text font-display">
                Pipelines em Andamento (CORE 1.0 + 2.0)
              </h3>
            </div>
            <span className="text-xs text-studio-text-muted">
              {runningWorkflows.length} em processamento
            </span>
          </div>

          <div className="space-y-3">
            {runningWorkflows.map((job) => {
              const currentStep = job.steps[job.currentStepIndex];
              const progressPct = Math.round(((job.currentStepIndex) / job.steps.length) * 100);

              return (
                <div key={job.id} className="p-4 rounded-xl bg-studio-panel border border-studio-border space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-studio-text truncate">{job.title}</span>
                    <span className="text-studio-blue font-mono font-bold">{progressPct}%</span>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full h-2 rounded-full bg-studio-bg overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-studio-blue to-studio-purple transition-all duration-500"
                      style={{ width: `${progressPct}%` }}
                    />
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-studio-text-muted">
                    <span>Etapa: {currentStep?.label}</span>
                    <span className="capitalize">{job.status.toLowerCase()}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
