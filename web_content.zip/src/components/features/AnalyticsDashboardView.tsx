// ============================================================
// AI CREATOR STUDIO — CORE 2.0 ANALYTICS DASHBOARD & AI ASSISTANT
// ============================================================

import React, { useState, useEffect } from "react";
import type { AggregatedAnalytics, VideoAnalytics, AIAnalyticsQueryResponse } from "@/types";
import {
  BarChart2,
  TrendingUp,
  Eye,
  Clock,
  ThumbsUp,
  MessageSquare,
  Share2,
  Users,
  Sparkles,
  Send,
  Scale,
  Play,
  CheckCircle2,
  HelpCircle,
  RefreshCw,
  Youtube,
  Instagram,
  Facebook,
} from "lucide-react";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { analyticsEngine } from "@/lib/analyticsEngine";
import { PerformanceComparisonModal } from "@/components/features/PerformanceComparisonModal";

export const AnalyticsDashboardView: React.FC = () => {
  const { toast } = useToast();
  const [period, setPeriod] = useState<"7D" | "30D" | "90D" | "ALL">("30D");
  const [data, setData] = useState<AggregatedAnalytics | null>(null);
  const [allVideos, setAllVideos] = useState<VideoAnalytics[]>([]);
  const [comparisonOpen, setComparisonOpen] = useState(false);

  // AI Assistant State
  const [aiQuestion, setAiQuestion] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResponse, setAiResponse] = useState<AIAnalyticsQueryResponse | null>(null);

  useEffect(() => {
    const agg = analyticsEngine.getAggregatedData(period);
    const vids = analyticsEngine.getAllVideoMetrics();
    setData(agg);
    setAllVideos(vids);
  }, [period]);

  const handleAskAI = async (queryText?: string) => {
    const textToAsk = queryText || aiQuestion;
    if (!textToAsk.trim()) return;

    setAiLoading(true);
    setAiQuestion(textToAsk);
    try {
      const response = await analyticsEngine.askAI(textToAsk);
      setAiResponse(response);
      toast({ title: "Análise Gerada", description: "Insights calculados com base nas métricas reais." });
    } catch (err) {
      toast({ title: "Erro na Análise", description: "Não foi possível processar a consulta.", variant: "destructive" });
    } finally {
      setAiLoading(false);
    }
  };

  if (!data) return null;

  const platformChartData = [
    { name: "YouTube", views: data.platformBreakdown.YOUTUBE?.views || 0, likes: data.platformBreakdown.YOUTUBE?.likes || 0 },
    { name: "TikTok", views: data.platformBreakdown.TIKTOK?.views || 0, likes: data.platformBreakdown.TIKTOK?.likes || 0 },
    { name: "Instagram", views: data.platformBreakdown.INSTAGRAM?.views || 0, likes: data.platformBreakdown.INSTAGRAM?.likes || 0 },
    { name: "Facebook", views: data.platformBreakdown.FACEBOOK?.views || 0, likes: data.platformBreakdown.FACEBOOK?.likes || 0 },
  ];

  return (
    <div className="space-y-8" id="analytics-dashboard-view">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-xl bg-zinc-900/80 border border-zinc-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 text-xs font-bold rounded bg-emerald-600/30 text-emerald-400 border border-emerald-500/30">
              CORE 2.0
            </span>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <BarChart2 className="w-5 h-5 text-emerald-400" />
              Analytics Engine & AI Growth Intelligence
            </h2>
          </div>
          <p className="text-sm text-zinc-400">
            Painel unificado de métricas de visualizações, CTR, tempo de exibição e inteligência preditiva.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Period Selector */}
          <div className="flex rounded-lg bg-zinc-950 border border-zinc-800 p-0.5">
            {(["7D", "30D", "90D", "ALL"] as const).map((p) => (
              <button
                key={p}
                onClick={() => setPeriod(p)}
                className={`px-3 py-1 text-xs rounded-md font-semibold transition-all ${
                  period === p ? "bg-zinc-800 text-white shadow-sm" : "text-zinc-400 hover:text-zinc-200"
                }`}
              >
                {p === "ALL" ? "Total" : p}
              </button>
            ))}
          </div>

          <Button
            onClick={() => setComparisonOpen(true)}
            variant="outline"
            className="border-zinc-700 text-zinc-200 hover:bg-zinc-800 text-xs gap-1.5"
          >
            <Scale className="w-3.5 h-3.5 text-blue-400" />
            Comparar Vídeos
          </Button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-zinc-900/90 border border-zinc-800 space-y-1">
          <div className="flex items-center justify-between text-zinc-400 text-xs">
            <span>Visualizações Totais</span>
            <Eye className="w-4 h-4 text-blue-400" />
          </div>
          <h3 className="text-2xl font-black text-white font-mono">
            {data.totalViews.toLocaleString()}
          </h3>
          <span className="text-[11px] text-emerald-400 font-medium">+24.5% vs período anterior</span>
        </div>

        <div className="p-4 rounded-xl bg-zinc-900/90 border border-zinc-800 space-y-1">
          <div className="flex items-center justify-between text-zinc-400 text-xs">
            <span>Tempo de Exibição</span>
            <Clock className="w-4 h-4 text-purple-400" />
          </div>
          <h3 className="text-2xl font-black text-white font-mono">
            {data.totalWatchTimeHours.toLocaleString()}h
          </h3>
          <span className="text-[11px] text-emerald-400 font-medium">Média {data.avgViewDurationSec}s por vídeo</span>
        </div>

        <div className="p-4 rounded-xl bg-zinc-900/90 border border-zinc-800 space-y-1">
          <div className="flex items-center justify-between text-zinc-400 text-xs">
            <span>CTR Médio (Taxa de Clique)</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <h3 className="text-2xl font-black text-white font-mono">
            {data.avgCTR}%
          </h3>
          <span className="text-[11px] text-emerald-400 font-medium">Acima do benchmark (6-8%)</span>
        </div>

        <div className="p-4 rounded-xl bg-zinc-900/90 border border-zinc-800 space-y-1">
          <div className="flex items-center justify-between text-zinc-400 text-xs">
            <span>Engajamento & Inscritos</span>
            <Users className="w-4 h-4 text-pink-400" />
          </div>
          <h3 className="text-2xl font-black text-white font-mono">
            +{data.subscribersGained.toLocaleString()}
          </h3>
          <span className="text-[11px] text-pink-400 font-medium">Taxa geral {data.overallEngagementRate}%</span>
        </div>
      </div>

      {/* AI Analytics Section */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-950/30 via-zinc-900 to-zinc-900 border border-emerald-900/40 space-y-4" id="ai-analytics-chat">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-emerald-400" />
            <h3 className="text-base font-bold text-white">
              AnalyticsAI — Assistente Inteligente de Crescimento
            </h3>
          </div>
          <span className="text-xs text-zinc-400">Respostas fundamentadas exclusivamente em dados reais</span>
        </div>

        {/* Input Bar */}
        <div className="flex items-center gap-2">
          <Input
            id="input-ai-analytics-question"
            value={aiQuestion}
            onChange={(e) => setAiQuestion(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleAskAI()}
            placeholder="Pergunte: Qual foi meu melhor vídeo? Qual teve maior retenção? O que devo produzir a seguir?"
            className="bg-zinc-950 border-zinc-800 text-xs text-white h-10"
          />
          <Button
            id="btn-ask-ai-analytics"
            onClick={() => handleAskAI()}
            disabled={aiLoading || !aiQuestion.trim()}
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs h-10 px-4 gap-1.5 flex-shrink-0"
          >
            <Send className={`w-3.5 h-3.5 ${aiLoading ? "animate-spin" : ""}`} />
            {aiLoading ? "Analisando..." : "Perguntar"}
          </Button>
        </div>

        {/* Quick Question Chips */}
        <div className="flex flex-wrap items-center gap-2 pt-1">
          <span className="text-[11px] text-zinc-500 font-medium">Sugestões rápidas:</span>
          {[
            "Qual foi meu melhor vídeo em retenção?",
            "Quais temas geram mais compartilhamentos?",
            "Qual formato devo priorizar no próximo mês?",
            "Qual a comparação de CTR entre vídeos longos e Shorts?",
          ].map((chip, idx) => (
            <button
              key={idx}
              onClick={() => handleAskAI(chip)}
              className="px-2.5 py-1 text-[11px] rounded-lg bg-zinc-950/80 border border-zinc-800 text-zinc-300 hover:text-white hover:border-zinc-700 transition-colors"
            >
              {chip}
            </button>
          ))}
        </div>

        {/* AI Answer Box */}
        {aiResponse && (
          <div className="p-4 rounded-xl bg-zinc-950 border border-emerald-900/60 space-y-3 mt-3 animate-in fade-in">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                Resposta Fundamentada em Métricas do Estúdio
              </span>
              <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                Confiança: {aiResponse.dataConfidence}
              </span>
            </div>

            <p className="text-xs text-zinc-200 leading-relaxed">
              {aiResponse.answer}
            </p>

            {/* Highlight Metric Card */}
            {aiResponse.highlightMetric && (
              <div className="p-3 rounded-lg bg-zinc-900 border border-zinc-800 flex items-center justify-between text-xs">
                <span className="text-zinc-400">{aiResponse.highlightMetric.label}:</span>
                <div className="flex items-center gap-2">
                  <strong className="text-white font-bold">{aiResponse.highlightMetric.value}</strong>
                  {aiResponse.highlightMetric.trend && (
                    <span className="text-emerald-400 font-mono text-[11px]">
                      ({aiResponse.highlightMetric.trend})
                    </span>
                  )}
                </div>
              </div>
            )}

            {/* Recommended Actions */}
            {aiResponse.recommendedActions && aiResponse.recommendedActions.length > 0 && (
              <div className="space-y-1.5 pt-1">
                <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">
                  Ações Recomendadas para os Próximos Conteúdos:
                </span>
                <ul className="space-y-1">
                  {aiResponse.recommendedActions.map((act, aIdx) => (
                    <li key={aIdx} className="text-xs text-zinc-300 flex items-start gap-2">
                      <span className="text-emerald-400">→</span>
                      <span>{act}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Visual Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Time Series Area Chart (7 Cols) */}
        <div className="lg:col-span-7 p-5 rounded-xl bg-zinc-900/90 border border-zinc-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-zinc-200 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              Evolução de Visualizações & Tempo de Exibição
            </h3>
            <span className="text-xs text-zinc-400">Consolidado ({period})</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.timeSeries}>
                <defs>
                  <linearGradient id="viewsGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                <XAxis dataKey="date" stroke="#71717a" fontSize={11} />
                <YAxis stroke="#71717a" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#09090b", borderColor: "#27272a", borderRadius: "8px", fontSize: "12px" }}
                />
                <Area type="monotone" dataKey="views" name="Visualizações" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#viewsGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Platform Breakdown Bar Chart (5 Cols) */}
        <div className="lg:col-span-5 p-5 rounded-xl bg-zinc-900/90 border border-zinc-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-zinc-200 flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-blue-400" />
              Desempenho por Plataforma
            </h3>
            <span className="text-xs text-zinc-400">Total Views</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={platformChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                <XAxis dataKey="name" stroke="#71717a" fontSize={11} />
                <YAxis stroke="#71717a" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#09090b", borderColor: "#27272a", borderRadius: "8px", fontSize: "12px" }}
                />
                <Bar dataKey="views" name="Views" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Top Videos Table */}
      <div className="p-5 rounded-xl bg-zinc-900/90 border border-zinc-800 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-zinc-200 flex items-center gap-2">
            <Play className="w-4 h-4 text-red-400" />
            Ranking de Conteúdos por Engajamento e Retenção
          </h3>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => setComparisonOpen(true)}
            className="text-xs text-blue-400 hover:text-blue-300"
          >
            Abrir Comparação Completa →
          </Button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-zinc-800 text-zinc-400 font-semibold">
                <th className="pb-3 font-medium">Vídeo / Projeto</th>
                <th className="pb-3 font-medium">Plataforma</th>
                <th className="pb-3 font-medium text-right">Views</th>
                <th className="pb-3 font-medium text-right">Watch Time</th>
                <th className="pb-3 font-medium text-right">CTR</th>
                <th className="pb-3 font-medium text-right">Retenção</th>
                <th className="pb-3 font-medium text-right">Shares</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60">
              {allVideos.map((video) => (
                <tr key={video.projectId} className="hover:bg-zinc-800/40 transition-colors">
                  <td className="py-3 pr-4 flex items-center gap-3">
                    <img
                      src={video.thumbnailUrl || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80"}
                      alt="Thumbnail"
                      className="w-12 h-8 rounded object-cover flex-shrink-0 bg-zinc-950"
                    />
                    <span className="font-semibold text-zinc-200 line-clamp-1 max-w-[240px]">
                      {video.projectTitle}
                    </span>
                  </td>
                  <td className="py-3 text-zinc-400 font-medium">{video.platform}</td>
                  <td className="py-3 text-right font-mono text-white">{video.views.toLocaleString()}</td>
                  <td className="py-3 text-right font-mono text-zinc-300">{video.watchTimeHours}h</td>
                  <td className="py-3 text-right font-mono text-emerald-400">{video.ctr}%</td>
                  <td className="py-3 text-right font-mono text-amber-400">{video.avgViewPercentage}%</td>
                  <td className="py-3 text-right font-mono text-zinc-300">{video.shares.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Comparison Modal */}
      <PerformanceComparisonModal
        isOpen={comparisonOpen}
        onClose={() => setComparisonOpen(false)}
        allVideos={allVideos}
      />
    </div>
  );
};
