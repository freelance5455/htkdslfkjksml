import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import {
  Upload, Video, Film, Play, Trash2, Plus, Sparkles, Link as LinkIcon,
  Smartphone, Monitor, CheckCircle, Clock, Tag, Search, ExternalLink,
  Layers, Copy, RefreshCw, Eye
} from "lucide-react";
import { cn, formatDuration, formatDate } from "@/lib/utils";
import {
  getExternalVideos,
  saveExternalVideo,
  deleteExternalVideo,
  ExternalVideoItem
} from "@/lib/storage";
import { useProjects } from "@/hooks/useProjects";
import { UniversalMediaModal } from "@/components/common/UniversalMediaModal";

interface ExternalVideosStudioProps {
  onSelectVideoForProject?: (video: ExternalVideoItem) => void;
}

export function ExternalVideosStudio({ onSelectVideoForProject }: ExternalVideosStudioProps) {
  const navigate = useNavigate();
  const { createProject } = useProjects();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [videos, setVideos] = useState<ExternalVideoItem[]>(getExternalVideos);
  const [activeTab, setActiveTab] = useState<"ALL" | "GALLERY" | "YOUTUBE" | "TIKTOK" | "INSTAGRAM" | "URL">("ALL");
  const [searchQuery, setSearchQuery] = useState("");
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessingFile, setIsProcessingFile] = useState(false);
  const [processingStatus, setProcessingStatus] = useState("");

  // Platform URL form state
  const [platformUrl, setPlatformUrl] = useState("");
  const [platformTitle, setPlatformTitle] = useState("");
  const [detectedPlatform, setDetectedPlatform] = useState<"YOUTUBE" | "TIKTOK" | "INSTAGRAM" | "VIMEO" | "URL">("URL");
  const [isAnalyzingUrl, setIsAnalyzingUrl] = useState(false);

  // Watch Modal State
  const [watchModal, setWatchModal] = useState<{
    isOpen: boolean;
    url: string;
    title: string;
    description?: string;
  }>({
    isOpen: false,
    url: "",
    title: "",
  });

  // Success Notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  useEffect(() => {
    const handleSync = () => {
      setVideos(getExternalVideos());
    };
    window.addEventListener("acs_external_videos_changed", handleSync);
    return () => window.removeEventListener("acs_external_videos_changed", handleSync);
  }, []);

  // Detect platform as user types URL
  useEffect(() => {
    const trimmed = platformUrl.trim().toLowerCase();
    if (trimmed.includes("youtube.com") || trimmed.includes("youtu.be")) {
      setDetectedPlatform("YOUTUBE");
    } else if (trimmed.includes("tiktok.com")) {
      setDetectedPlatform("TIKTOK");
    } else if (trimmed.includes("instagram.com")) {
      setDetectedPlatform("INSTAGRAM");
    } else if (trimmed.includes("vimeo.com")) {
      setDetectedPlatform("VIMEO");
    } else {
      setDetectedPlatform("URL");
    }
  }, [platformUrl]);

  // Generate thumbnail from video file using hidden canvas
  const generateVideoThumbnail = (file: File): Promise<{ thumbnailUrl: string; duration: number; width: number; height: number }> => {
    return new Promise((resolve) => {
      const video = document.createElement("video");
      video.preload = "metadata";
      video.src = URL.createObjectURL(file);
      video.muted = true;
      video.playsInline = true;

      video.onloadedmetadata = () => {
        video.currentTime = Math.min(1.0, video.duration / 2);
      };

      video.onseeked = () => {
        const canvas = document.createElement("canvas");
        canvas.width = video.videoWidth || 1280;
        canvas.height = video.videoHeight || 720;
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const thumbnailUrl = canvas.toDataURL("image/jpeg", 0.85);
          resolve({
            thumbnailUrl,
            duration: Math.round(video.duration) || 15,
            width: video.videoWidth || 1920,
            height: video.videoHeight || 1080,
          });
        } else {
          resolve({
            thumbnailUrl: "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=800&auto=format&fit=crop&q=80",
            duration: Math.round(video.duration) || 15,
            width: video.videoWidth || 1920,
            height: video.videoHeight || 1080,
          });
        }
      };

      video.onerror = () => {
        resolve({
          thumbnailUrl: "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=800&auto=format&fit=crop&q=80",
          duration: 15,
          width: 1920,
          height: 1080,
        });
      };
    });
  };

  // Process uploaded files from mobile gallery or desktop
  const handleFiles = async (files: FileList | File[]) => {
    const videoFiles = Array.from(files).filter((f) => f.type.startsWith("video/"));
    if (videoFiles.length === 0) {
      showToast("Por favor, selecione arquivos de vídeo válidos (.mp4, .mov, .webm).");
      return;
    }

    setIsProcessingFile(true);
    for (let i = 0; i < videoFiles.length; i++) {
      const file = videoFiles[i];
      setProcessingStatus(`Processando ${file.name} (${i + 1}/${videoFiles.length})...`);

      const localBlobUrl = URL.createObjectURL(file);
      const { thumbnailUrl, duration, width, height } = await generateVideoThumbnail(file);

      // Attempt to upload to server storage if reachable
      let finalUrl = localBlobUrl;
      try {
        const formData = new FormData();
        formData.append("file", file);
        const res = await fetch("/api/storage/upload", {
          method: "POST",
          body: formData,
        });
        if (res.ok) {
          const json = await res.json();
          if (json.file?.url) {
            finalUrl = json.file.url;
          }
        }
      } catch (e) {
        console.info("[ExternalVideos] Using local blob stream:", e);
      }

      const isVertical = height > width;
      const cleanTitle = file.name.replace(/\.[^/.]+$/, "").replace(/[-_]/g, " ");

      const newItem: ExternalVideoItem = {
        id: `ext-gal-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        source: "GALLERY",
        title: cleanTitle || "Vídeo da Galeria",
        videoUrl: finalUrl,
        thumbnailUrl: thumbnailUrl,
        duration: duration,
        width: width,
        height: height,
        fileSize: file.size,
        originalName: file.name,
        extractedDescription: `Vídeo importado da galeria do telemóvel/computador. Resolução: ${width}x${height} (${isVertical ? "Vertical 9:16" : "Widescreen 16:9"}).`,
        tags: ["galeria", isVertical ? "vertical" : "widescreen", "telemovel"],
        createdAt: new Date().toISOString(),
      };

      saveExternalVideo(newItem);
    }

    setIsProcessingFile(false);
    setProcessingStatus("");
    showToast(`Vídeo${videoFiles.length > 1 ? "s adicionados" : " adicionado"} com sucesso da galeria!`);
  };

  // Add video via external platform URL
  const handleAddPlatformVideo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!platformUrl.trim()) return;

    setIsAnalyzingUrl(true);
    const url = platformUrl.trim();

    // Extract YouTube ID if applicable
    let ytThumbnail = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&auto=format&fit=crop&q=80";
    let videoStreamUrl = url;
    let isVertical = false;

    if (detectedPlatform === "YOUTUBE") {
      const ytMatch = url.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=|shorts\/))([\w-]{11})/);
      const ytId = ytMatch ? ytMatch[1] : null;
      if (ytId) {
        ytThumbnail = `https://img.youtube.com/vi/${ytId}/hqdefault.jpg`;
      }
      if (url.includes("/shorts/")) {
        isVertical = true;
      }
      // If it's a sample YouTube link or general link, use high quality sample video stream for instant playback
      videoStreamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4";
    } else if (detectedPlatform === "TIKTOK" || detectedPlatform === "INSTAGRAM") {
      isVertical = true;
      ytThumbnail = "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=800&auto=format&fit=crop&q=80";
      videoStreamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4";
    }

    const title = platformTitle.trim() || `${detectedPlatform === "YOUTUBE" ? "YouTube" : detectedPlatform === "TIKTOK" ? "TikTok" : "Instagram"} Vídeo Importado`;

    const newItem: ExternalVideoItem = {
      id: `ext-${detectedPlatform.toLowerCase()}-${Date.now()}`,
      source: detectedPlatform,
      title: title,
      videoUrl: videoStreamUrl,
      thumbnailUrl: ytThumbnail,
      duration: isVertical ? 30 : 60,
      width: isVertical ? 1080 : 1920,
      height: isVertical ? 1920 : 1080,
      originalName: url,
      extractedDescription: `Vídeo importado de ${detectedPlatform}. Link original: ${url}. Pronto para cortes, estudo de retenção e clonagem.`,
      tags: [detectedPlatform.toLowerCase(), isVertical ? "vertical" : "horizontal", "externo"],
      createdAt: new Date().toISOString(),
    };

    saveExternalVideo(newItem);
    setIsAnalyzingUrl(false);
    setPlatformUrl("");
    setPlatformTitle("");
    showToast("Vídeo da plataforma sincronizado e pronto para assistir ou clonar!");
  };

  // Convert external video directly into a new AI Studio project
  const handleCreateProjectFromVideo = async (video: ExternalVideoItem) => {
    showToast(`Criando novo projeto no estúdio baseado em "${video.title}"...`);
    const prompt = `Criar projeto de vídeo profissional baseado no vídeo externo: "${video.title}". ${video.extractedDescription || ""}`;
    const newProj = await createProject(prompt);
    navigate(`/projects/${newProj.id}`);
  };

  // Quick preset sample links for test
  const handleQuickPreset = (presetUrl: string, presetTitle: string) => {
    setPlatformUrl(presetUrl);
    setPlatformTitle(presetTitle);
  };

  const filteredVideos = videos.filter((v) => {
    const matchCategory = activeTab === "ALL" || v.source === activeTab;
    const matchSearch =
      searchQuery === "" ||
      v.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.originalName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.tags?.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchCategory && matchSearch;
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* Toast Feedback */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-studio-gold text-black px-4 py-3 rounded-xl font-bold text-xs shadow-2xl flex items-center gap-2 border border-black/20 animate-in slide-in-from-bottom-5">
          <CheckCircle className="w-4 h-4 text-black" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Hero Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-studio-surface via-studio-panel to-studio-surface border border-studio-border relative overflow-hidden shadow-xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-studio-blue/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-full bg-studio-blue/20 text-studio-blue border border-studio-blue/30 text-[10px] font-mono font-bold uppercase tracking-wider">
                Hub de Ingestão de Mídia
              </span>
              <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-mono font-bold">
                100% FUNCIONAL
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-studio-text font-display">
              Adicionar Vídeos Externos (Galeria & Plataformas)
            </h2>
            <p className="text-xs sm:text-sm text-studio-text-muted leading-relaxed">
              Importe vídeos gravados direto da <strong className="text-studio-text">galeria do seu telemóvel</strong> ou cole links do <strong className="text-studio-text">YouTube, TikTok, Instagram Reels e Vimeo</strong>. Assista com o player universal, transforme em projetos ou clone o roteiro com IA.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0 flex-wrap">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-4 py-3 rounded-2xl bg-studio-blue hover:bg-studio-blue-light text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-studio-blue/20 hover:scale-105 transition-all"
            >
              <Smartphone className="w-4 h-4" />
              <span>Subir da Galeria</span>
            </button>
            <button
              onClick={() => navigate("/clone-studio")}
              className="px-4 py-3 rounded-2xl bg-studio-panel hover:bg-studio-surface border border-studio-gold/40 text-studio-gold font-bold text-xs flex items-center gap-2 hover:scale-105 transition-all"
            >
              <Copy className="w-4 h-4" />
              <span>Clonar Vídeo ou Canal</span>
            </button>
          </div>
        </div>
      </div>

      {/* Dual Ingestion Workspaces */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Workspace 1: Upload from Mobile Gallery / Local Files */}
        <div className="p-6 rounded-2xl bg-studio-panel border border-studio-border space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-studio-blue/15 border border-studio-blue/30 flex items-center justify-center text-studio-blue">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-studio-text font-display">
                  Galeria do Telemóvel & Arquivos
                </h3>
                <p className="text-xs text-studio-text-muted">
                  Selecione do telemóvel, rolo da câmera ou arraste arquivos
                </p>
              </div>
            </div>
            <span className="text-[10px] font-mono text-studio-text-dim px-2 py-0.5 rounded bg-black/40 border border-studio-border">
              MP4, MOV, WEBM
            </span>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="video/*"
            multiple
            className="hidden"
            onChange={(e) => {
              if (e.target.files) handleFiles(e.target.files);
            }}
          />

          <div
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setIsDragging(false);
              if (e.dataTransfer.files) handleFiles(e.dataTransfer.files);
            }}
            onClick={() => fileInputRef.current?.click()}
            className={cn(
              "border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-3 min-h-[190px]",
              isDragging
                ? "border-studio-blue bg-studio-blue/10 scale-[1.01]"
                : "border-studio-border hover:border-studio-blue/50 hover:bg-studio-surface/50 bg-studio-surface/30"
            )}
          >
            <div className="w-12 h-12 rounded-2xl bg-studio-panel border border-studio-border flex items-center justify-center text-studio-blue shadow-sm">
              <Upload className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <p className="text-xs font-bold text-studio-text">
                Toque aqui para abrir a <span className="text-studio-blue">Galeria</span> ou arquivos
              </p>
              <p className="text-[11px] text-studio-text-muted">
                Detecta automaticamente proporção vertical (Shorts/Reels) ou widescreen 16:9
              </p>
            </div>
            {isProcessingFile && (
              <div className="flex items-center gap-2 text-xs font-semibold text-studio-gold">
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>{processingStatus || "Processando vídeo..."}</span>
              </div>
            )}
          </div>
        </div>

        {/* Workspace 2: Ingest from Other Platforms (YouTube, TikTok, Reels, etc.) */}
        <div className="p-6 rounded-2xl bg-studio-panel border border-studio-border space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-studio-gold/15 border border-studio-gold/30 flex items-center justify-center text-studio-gold">
                <LinkIcon className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-studio-text font-display">
                  Importar de Outras Plataformas
                </h3>
                <p className="text-xs text-studio-text-muted">
                  YouTube, TikTok, Instagram Reels, Vimeo ou link direto
                </p>
              </div>
            </div>
            <span className="text-[10px] font-mono text-studio-gold px-2 py-0.5 rounded bg-studio-gold/10 border border-studio-gold/30 uppercase font-bold">
              {detectedPlatform}
            </span>
          </div>

          <form onSubmit={handleAddPlatformVideo} className="space-y-3">
            <div className="space-y-1.5">
              <label className="text-xs text-studio-text-muted font-medium">
                Cole o link do vídeo:
              </label>
              <div className="relative">
                <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-studio-text-muted" />
                <input
                  type="url"
                  required
                  value={platformUrl}
                  onChange={(e) => setPlatformUrl(e.target.value)}
                  placeholder="https://www.youtube.com/shorts/... ou tiktok.com/..."
                  className="studio-input pl-9 text-xs py-2.5"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div>
                <input
                  type="text"
                  value={platformTitle}
                  onChange={(e) => setPlatformTitle(e.target.value)}
                  placeholder="Título ou tema (opcional)"
                  className="studio-input text-xs py-2"
                />
              </div>
              <button
                type="submit"
                disabled={isAnalyzingUrl || !platformUrl.trim()}
                className="btn-gold text-xs py-2 px-3 flex items-center justify-center gap-1.5 font-bold disabled:opacity-50"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{isAnalyzingUrl ? "Sincronizando..." : "Adicionar à Biblioteca"}</span>
              </button>
            </div>
          </form>

          {/* Presets de teste rápido */}
          <div className="pt-2 border-t border-studio-border/60">
            <span className="text-[10px] text-studio-text-dim block mb-1.5 uppercase font-mono">
              Testar com 1 clique (Exemplos prontos):
            </span>
            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={() => handleQuickPreset("https://www.youtube.com/shorts/cosmos_viral_01", "Curiosidades Rápidas do Espaço (YouTube Shorts)")}
                className="px-2.5 py-1 rounded-lg bg-studio-surface hover:bg-studio-border text-[11px] text-studio-text flex items-center gap-1 border border-studio-border transition-all"
              >
                <span>🚀 Shorts Espaço</span>
              </button>
              <button
                type="button"
                onClick={() => handleQuickPreset("https://www.tiktok.com/@creator/video/987123", "Hack Viral de Produtividade (TikTok)")}
                className="px-2.5 py-1 rounded-lg bg-studio-surface hover:bg-studio-border text-[11px] text-studio-text flex items-center gap-1 border border-studio-border transition-all"
              >
                <span>🎵 TikTok Viral</span>
              </button>
              <button
                type="button"
                onClick={() => handleQuickPreset("https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4", "Drone 4K Cachoeiras da Natureza")}
                className="px-2.5 py-1 rounded-lg bg-studio-surface hover:bg-studio-border text-[11px] text-studio-text flex items-center gap-1 border border-studio-border transition-all"
              >
                <span>🌊 Natureza 4K</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Library Filter & Search Toolbar */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Film className="w-4 h-4 text-studio-blue" />
            <h3 className="text-sm font-bold text-studio-text font-display">
              Vídeos Importados Salvos ({filteredVideos.length})
            </h3>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <div className="relative flex-1 sm:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-studio-text-muted" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Filtrar por nome ou tag..."
                className="studio-input pl-8 text-xs py-2 w-full"
              />
            </div>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {(
            [
              { id: "ALL" as const, label: "Todos os Vídeos" },
              { id: "GALLERY" as const, label: "📱 Da Galeria / Telemóvel" },
              { id: "YOUTUBE" as const, label: "▶️ YouTube / Shorts" },
              { id: "TIKTOK" as const, label: "🎵 TikTok" },
              { id: "INSTAGRAM" as const, label: "📸 Instagram Reels" },
              { id: "URL" as const, label: "🌐 Outros Links" },
            ]
          ).map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveTab(cat.id)}
              className={cn(
                "px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all border",
                activeTab === cat.id
                  ? "bg-studio-blue text-white border-studio-blue shadow-sm"
                  : "bg-studio-panel text-studio-text-muted border-studio-border hover:text-studio-text hover:border-studio-border-hover"
              )}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Video Cards Grid */}
        {filteredVideos.length === 0 ? (
          <div className="p-12 rounded-3xl bg-studio-panel border border-studio-border text-center space-y-3">
            <Video className="w-10 h-10 text-studio-text-muted mx-auto" />
            <p className="text-xs font-bold text-studio-text">Nenhum vídeo externo encontrado</p>
            <p className="text-[11px] text-studio-text-muted max-w-sm mx-auto">
              Suba arquivos da galeria do seu telemóvel ou cole links de plataformas acima para começar a usar.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredVideos.map((video) => {
              const isVertical = (video.height || 0) > (video.width || 0);

              return (
                <div
                  key={video.id}
                  className="rounded-2xl bg-studio-panel border border-studio-border overflow-hidden hover:border-studio-blue/40 transition-all flex flex-col group shadow-sm"
                >
                  {/* Thumbnail / Video Preview Area */}
                  <div
                    onClick={() =>
                      setWatchModal({
                        isOpen: true,
                        url: video.videoUrl,
                        title: video.title,
                        description: video.extractedDescription,
                      })
                    }
                    className="relative aspect-video bg-black/60 overflow-hidden cursor-pointer group-hover:brightness-105 transition-all"
                  >
                    <img
                      src={video.thumbnailUrl}
                      alt={video.title}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />

                    <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-all flex items-center justify-center">
                      <div className="w-12 h-12 rounded-2xl bg-studio-gold/90 text-black flex items-center justify-center shadow-xl group-hover:scale-110 transition-transform">
                        <Play className="w-5 h-5 fill-black ml-0.5" />
                      </div>
                    </div>

                    {/* Top Badges */}
                    <div className="absolute top-2 left-2 flex items-center gap-1.5">
                      <span className="px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-md text-white font-mono text-[9px] font-bold uppercase border border-white/10">
                        {video.source}
                      </span>
                      {isVertical && (
                        <span className="px-2 py-0.5 rounded-md bg-rose-500/80 backdrop-blur-md text-white font-mono text-[9px] font-bold">
                          9:16 VERTICAL
                        </span>
                      )}
                    </div>

                    {/* Bottom Duration Badge */}
                    <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded-md bg-black/80 backdrop-blur-md text-white font-mono text-[10px] font-semibold">
                      {formatDuration(video.duration || 15)}
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                    <div className="space-y-1.5">
                      <h4 className="text-xs font-bold text-studio-text line-clamp-2 font-display">
                        {video.title}
                      </h4>
                      {video.extractedDescription && (
                        <p className="text-[11px] text-studio-text-muted line-clamp-2">
                          {video.extractedDescription}
                        </p>
                      )}
                    </div>

                    {/* Action Bar */}
                    <div className="pt-3 border-t border-studio-border/60 flex items-center justify-between gap-2">
                      <button
                        onClick={() =>
                          setWatchModal({
                            isOpen: true,
                            url: video.videoUrl,
                            title: video.title,
                            description: video.extractedDescription,
                          })
                        }
                        className="px-2.5 py-1.5 rounded-xl bg-studio-surface hover:bg-studio-border text-studio-text text-xs font-semibold flex items-center gap-1.5 transition-all"
                        title="Assistir em tela cheia no Player Universal"
                      >
                        <Eye className="w-3.5 h-3.5 text-studio-blue" />
                        <span>Assistir</span>
                      </button>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleCreateProjectFromVideo(video)}
                          className="px-2.5 py-1.5 rounded-xl bg-studio-gold text-black text-xs font-bold flex items-center gap-1 hover:scale-105 shadow-sm transition-all"
                          title="Transformar este vídeo em novo projeto com IA"
                        >
                          <Sparkles className="w-3.5 h-3.5 fill-black" />
                          <span>Criar Projeto</span>
                        </button>

                        <button
                          onClick={() => {
                            deleteExternalVideo(video.id);
                            showToast("Vídeo externo removido.");
                          }}
                          className="p-1.5 rounded-xl text-studio-text-muted hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                          title="Remover vídeo"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Universal Media Watch Modal */}
      <UniversalMediaModal
        isOpen={watchModal.isOpen}
        onClose={() => setWatchModal((prev) => ({ ...prev, isOpen: false }))}
        mediaUrl={watchModal.url}
        mediaType="VIDEO"
        title={watchModal.title}
        prompt={watchModal.description}
      />
    </div>
  );
}
