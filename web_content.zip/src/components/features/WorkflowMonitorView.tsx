// ============================================================
// AI CREATOR STUDIO — CORE 3.0 WORKFLOW MONITOR VIEW
// Visual pipelines, step progress, human approval gates
// ============================================================

import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Layers, CheckCircle2, Clock, AlertTriangle, Play,
  RefreshCw, Check, ArrowRight, ShieldAlert, Sparkles, Plus
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { WorkflowJob, WorkflowStepType } from "@/types/core3";
import { getWorkflowJobs, createAutomatedWorkflow, executeWorkflowStep } from "@/lib/core3/workflowEngine";

export default function WorkflowMonitorView() {
  const navigate = useNavigate();
  const [jobs, setJobs] = useState<WorkflowJob[]>(getWorkflowJobs());
  const [newTitle, setNewTitle] = useState("");
  const [showCreate, setShowCreate] = useState(false);

  useEffect(() => {
    refreshJobs();
    const interval = setInterval(refreshJobs, 3000);
    return () => clearInterval(interval);
  }, []);

  const refreshJobs = () => {
    setJobs(getWorkflowJobs());
  };

  const handleCreateNewWorkflow = () => {
    if (!newTitle.trim()) return;
    const job = createAutomatedWorkflow(newTitle.trim(), newTitle.trim(), {
      contentType: "CHILDREN_VIDEO",
      platform: "YOUTUBE",
      requirePublishApproval: true,
      initiatedBy: "USER",
    });
    setNewTitle("");
    setShowCreate(false);
    refreshJobs();
    // Start step execution
    executeWorkflowStep(job.id).then(refreshJobs).catch(console.error);
  };

  const handleRunNextStep = async (jobId: string) => {
    try {
      await executeWorkflowStep(jobId);
      refreshJobs();
    } catch (err) {
      console.error("Erro ao executar etapa:", err);
    }
  };

  const handleApprovePublish = async (jobId: string) => {
    const job = jobs.find((j) => j.id === jobId);
    if (!job) return;
    const current = job.steps[job.currentStepIndex];
    if (current) {
      current.approved = true;
      current.status = "PENDING";
      job.status = "RUNNING";
    }
    await executeWorkflowStep(job.id);
    refreshJobs();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="studio-card p-6 border border-studio-border bg-gradient-to-r from-studio-surface to-studio-panel">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <span className="text-[10px] uppercase font-mono tracking-widest text-studio-blue font-bold">
              Orquestração de Ponta a Ponta
            </span>
            <h2 className="text-xl font-bold text-studio-text font-display mt-1">
              Fila de Workflows Automatizados
            </h2>
            <p className="text-xs text-studio-text-muted mt-0.5">
              Ideia → Roteiro → Storyboard → Mídia 3D → Montagem → Render → Publicação com Portão Humano.
            </p>
          </div>

          <button
            onClick={() => setShowCreate(!showCreate)}
            className="btn-gold text-xs py-2 px-4 gap-1.5"
          >
            <Plus className="w-4 h-4" />
            Novo Pipeline Automatizado
          </button>
        </div>

        {showCreate && (
          <div className="mt-4 pt-4 border-t border-studio-border flex items-center gap-2">
            <input
              type="text"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="Título ou tema do pipeline (ex: 'A Vaca Mimosa no Jardim das Borboletas')..."
              className="input text-xs flex-1"
            />
            <button onClick={handleCreateNewWorkflow} className="btn-primary text-xs py-2 px-4">
              Iniciar Pipeline
            </button>
          </div>
        )}
      </div>

      {/* Workflow Jobs List */}
      <div className="space-y-4">
        {jobs.length === 0 ? (
          <div className="studio-card p-12 text-center space-y-3">
            <Layers className="w-10 h-10 text-studio-text-muted mx-auto" />
            <p className="text-sm font-semibold text-studio-text">Nenhum pipeline ativo no momento</p>
            <p className="text-xs text-studio-text-muted">
              Inicie um novo pipeline automatizado ou solicite ao AI Autopilot pelo Command Center.
            </p>
          </div>
        ) : (
          jobs.map((job) => {
            const currentStep = job.steps[job.currentStepIndex];
            const isWaitingApproval = job.status === "WAITING_APPROVAL";

            return (
              <div
                key={job.id}
                className={cn(
                  "studio-card p-5 border transition-all space-y-4",
                  isWaitingApproval
                    ? "border-yellow-500/50 bg-yellow-500/5 shadow-md shadow-yellow-500/5"
                    : "border-studio-border bg-studio-panel"
                )}
              >
                {/* Job Header */}
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-studio-text font-display">
                        {job.title}
                      </h3>
                      <span className={cn(
                        "text-[10px] px-2 py-0.5 rounded-full font-bold uppercase",
                        job.status === "COMPLETED"
                          ? "bg-studio-green/20 text-studio-green"
                          : isWaitingApproval
                          ? "bg-yellow-500/20 text-yellow-300 animate-pulse"
                          : "bg-studio-blue/20 text-studio-blue"
                      )}>
                        {job.status}
                      </span>
                    </div>
                    <p className="text-xs text-studio-text-muted mt-0.5">
                      Iniciado por: <strong className="text-studio-text">{job.initiatedBy}</strong> · Etapa {job.currentStepIndex + 1} de {job.steps.length}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    {job.projectId && (
                      <button
                        onClick={() => navigate(`/projects/${job.projectId}`)}
                        className="btn-secondary text-xs py-1.5 px-3"
                      >
                        Ver Projeto
                      </button>
                    )}

                    {isWaitingApproval && (
                      <button
                        onClick={() => handleApprovePublish(job.id)}
                        className="btn-gold text-xs py-1.5 px-4 gap-1.5"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        Aprovar Publicação
                      </button>
                    )}

                    {job.status === "PENDING" && (
                      <button
                        onClick={() => handleRunNextStep(job.id)}
                        className="btn-primary text-xs py-1.5 px-3 gap-1"
                      >
                        <Play className="w-3.5 h-3.5" />
                        Executar Próxima Etapa
                      </button>
                    )}
                  </div>
                </div>

                {/* Steps Visual Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
                  {job.steps.map((step, idx) => {
                    const isDone = step.status === "COMPLETED";
                    const isRunning = step.status === "RUNNING";
                    const isWaiting = step.status === "WAITING_APPROVAL";
                    const isCurrent = idx === job.currentStepIndex;

                    return (
                      <div
                        key={step.step}
                        className={cn(
                          "p-2.5 rounded-xl border text-center space-y-1 transition-all",
                          isDone
                            ? "bg-studio-green/10 border-studio-green/30"
                            : isRunning
                            ? "bg-studio-blue/15 border-studio-blue/50"
                            : isWaiting
                            ? "bg-yellow-500/20 border-yellow-400/60"
                            : "bg-studio-bg border-studio-border/60 opacity-60"
                        )}
                      >
                        <div className="flex items-center justify-center">
                          {isDone ? (
                            <CheckCircle2 className="w-4 h-4 text-studio-green" />
                          ) : isRunning ? (
                            <RefreshCw className="w-4 h-4 text-studio-blue animate-spin" />
                          ) : isWaiting ? (
                            <AlertTriangle className="w-4 h-4 text-yellow-400" />
                          ) : (
                            <Clock className="w-4 h-4 text-studio-text-muted" />
                          )}
                        </div>
                        <p className="text-[11px] font-bold text-studio-text truncate">{step.label.split(" ")[0]}</p>
                        <p className="text-[9px] text-studio-text-muted truncate">{step.status}</p>
                      </div>
                    );
                  })}
                </div>

                {/* Output Summary */}
                {currentStep?.outputSummary && (
                  <p className="text-xs text-studio-text-dim bg-studio-bg/60 p-2.5 rounded-lg border border-studio-border/60">
                    <strong className="text-studio-text">Status Atual:</strong> {currentStep.outputSummary}
                  </p>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
