// ============================================================
// AI CREATOR STUDIO — CORE 3.0 PERFORMANCE LEARNING ENGINE VIEW
// Statistical insights from real CORE 2.0 analytics without hallucinations
// Explicitly separates correlation from causality
// ============================================================

import { useState } from "react";
import {
  BrainCircuit, TrendingUp, CheckCircle2, AlertCircle,
  Clock, Sparkles, Filter, Info, ShieldCheck, ArrowRight
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { LearnedInsight, PerformancePattern } from "@/types/core3";
import { extractPerformanceLearnings } from "@/lib/core3/performanceLearner";

interface PerformanceLearningsViewProps {
  onApplyInsight?: (action: string) => void;
}

export default function PerformanceLearningsView({ onApplyInsight }: PerformanceLearningsViewProps) {
  const { insights, pattern } = extractPerformanceLearnings();
  const [selectedCategory, setSelectedCategory] = useState<string>("ALL");

  const filteredInsights = selectedCategory === "ALL"
    ? insights
    : insights.filter((i) => i.category === selectedCategory);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="studio-card p-6 border border-studio-border bg-gradient-to-r from-studio-surface to-studio-panel">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <span className="text-[10px] uppercase font-mono tracking-widest text-teal-400 font-bold">
              Aprendizado Contínuo com Dados Reais
            </span>
            <h2 className="text-xl font-bold text-studio-text font-display mt-1 flex items-center gap-2">
              <BrainCircuit className="w-5 h-5 text-teal-400" />
              Performance Learning Engine
            </h2>
            <p className="text-xs text-studio-text-muted mt-0.5">
              Análise empírica baseada nas métricas do CORE 2.0. Distingue correlação estatística de causalidade comprovada.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs px-3 py-1.5 rounded-lg bg-teal-400/10 text-teal-400 border border-teal-400/20 font-bold">
              4 Padrões Identificados
            </span>
          </div>
        </div>
      </div>

      {/* Synthesis Pattern Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl bg-studio-panel border border-studio-border">
          <span className="text-[10px] uppercase font-bold text-studio-text-muted">Duração Ideal</span>
          <p className="text-xl font-bold text-studio-blue font-display mt-1">{pattern.bestPerformingDurationSec}s (3 min)</p>
          <p className="text-[11px] text-studio-text-muted">Ponto ótimo de retenção infantil</p>
        </div>

        <div className="p-4 rounded-xl bg-studio-panel border border-studio-border">
          <span className="text-[10px] uppercase font-bold text-studio-text-muted">Melhor Dia de Drop</span>
          <p className="text-xl font-bold text-studio-green font-display mt-1">{pattern.bestDayOfWeek}s</p>
          <p className="text-[11px] text-studio-text-muted">Pico às {pattern.bestTimeSlot}</p>
        </div>

        <div className="p-4 rounded-xl bg-studio-panel border border-studio-border">
          <span className="text-[10px] uppercase font-bold text-studio-text-muted">Tópico Top 1</span>
          <p className="text-xl font-bold text-studio-purple font-display mt-1">Animais Cantando</p>
          <p className="text-[11px] text-studio-text-muted">+31% acima da média</p>
        </div>

        <div className="p-4 rounded-xl bg-studio-panel border border-studio-border">
          <span className="text-[10px] uppercase font-bold text-studio-text-muted">Padrão de Gancho</span>
          <p className="text-sm font-bold text-studio-gold font-display mt-1">Vocal &lt;3s</p>
          <p className="text-[11px] text-studio-text-muted">Corte sem silêncio inicial</p>
        </div>
      </div>

      {/* Detailed Insights List with Statistical rigor */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-studio-text font-display">
            Descobertas Estatísticas Auditadas
          </h3>

          {/* Filter pills */}
          <div className="flex items-center gap-1.5 text-xs">
            {["ALL", "DURATION", "HOOK", "FORMAT", "POSTING_TIME"].map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={cn(
                  "px-2.5 py-1 rounded-lg transition-all",
                  selectedCategory === cat
                    ? "bg-studio-blue text-white font-bold"
                    : "bg-studio-panel text-studio-text-muted hover:text-studio-text"
                )}
              >
                {cat === "ALL" ? "Todos" : cat}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          {filteredInsights.map((insight) => (
            <div
              key={insight.id}
              className="p-5 rounded-2xl bg-studio-panel border border-studio-border space-y-3 hover:border-studio-blue/30 transition-all"
            >
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-studio-blue">
                    Categoria: {insight.category}
                  </span>
                  <h4 className="text-sm font-bold text-studio-text mt-0.5">{insight.title}</h4>
                </div>

                <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-full bg-teal-500/10 text-teal-400 border border-teal-500/20">
                  Confiança: {insight.confidencePercent}%
                </span>
              </div>

              {/* Finding */}
              <p className="text-xs text-studio-text-dim leading-relaxed">
                {insight.finding}
              </p>

              {/* Data basis */}
              <div className="text-[11px] text-studio-text-muted bg-studio-bg/60 p-2.5 rounded-lg border border-studio-border/60">
                <span className="font-semibold text-studio-text">Base Amostral:</span> {insight.supportingData}
              </div>

              {/* Causality vs Correlation analysis */}
              <div className="p-3 rounded-lg bg-studio-surface border border-studio-border flex items-start gap-2 text-xs">
                <Info className="w-4 h-4 text-studio-gold shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-studio-text">Rigor de Interpretação: </span>
                  <span className="text-studio-text-muted">{insight.causalityVsCorrelationNote}</span>
                </div>
              </div>

              {/* Action */}
              <div className="pt-2 flex items-center justify-between border-t border-studio-border/60">
                <p className="text-xs font-medium text-studio-text">
                  <strong className="text-studio-blue">Ação Recomendada:</strong> {insight.suggestedAction}
                </p>

                {onApplyInsight && (
                  <button
                    onClick={() => onApplyInsight(insight.suggestedAction)}
                    className="btn-primary text-xs py-1.5 px-3 gap-1 shrink-0 ml-3"
                  >
                    <span>Aplicar</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
