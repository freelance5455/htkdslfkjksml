import { useState, useRef, useEffect } from "react";
import type { Project, ChatMessage } from "@/types";
import { generateChatResponseAsync } from "@/lib/orchestrator";
import { generateId } from "@/lib/utils";
import { saveProject } from "@/lib/storage";
import { Send, Bot, User, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

interface ProjectChatProps {
  project: Project;
  onUpdate: (project: Project) => void;
}

export default function ProjectChat({ project, onUpdate }: ProjectChatProps) {
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [project.conversation]);

  const sendMessage = async () => {
    if (!input.trim() || thinking) return;
    const userMsg: ChatMessage = {
      id: generateId(),
      role: "user",
      content: input.trim(),
      createdAt: new Date().toISOString(),
    };

    const updatedWithUser: Project = {
      ...project,
      conversation: [...project.conversation, userMsg],
    };
    onUpdate(updatedWithUser);
    saveProject(updatedWithUser);
    setInput("");
    setThinking(true);

    const historyForAi = updatedWithUser.conversation.map((c) => ({
      role: c.role,
      content: c.content,
    }));

    const response = await generateChatResponseAsync(userMsg.content, project, historyForAi);
    const assistantMsg: ChatMessage = {
      id: generateId(),
      role: "assistant",
      content: response,
      createdAt: new Date().toISOString(),
    };

    const finalProject: Project = {
      ...updatedWithUser,
      conversation: [...updatedWithUser.conversation, assistantMsg],
    };
    onUpdate(finalProject);
    saveProject(finalProject);
    setThinking(false);
  };

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {project.conversation.map((msg) => (
          <div
            key={msg.id}
            className={cn("flex gap-2.5 max-w-full", msg.role === "user" && "flex-row-reverse")}
          >
            <div className={cn(
              "w-7 h-7 rounded-full flex items-center justify-center shrink-0 mt-0.5",
              msg.role === "assistant" ? "bg-studio-blue/20" : "bg-studio-gold/20"
            )}>
              {msg.role === "assistant"
                ? <Bot className="w-4 h-4 text-studio-blue" />
                : <User className="w-4 h-4 text-studio-gold" />
              }
            </div>
            <div className={cn(
              "max-w-[85%] rounded-xl px-3 py-2.5 text-sm leading-relaxed",
              msg.role === "assistant"
                ? "bg-studio-panel border border-studio-border text-studio-text"
                : "bg-studio-blue/10 border border-studio-blue/20 text-studio-text"
            )}>
              {msg.content.split("\n").map((line, i) => (
                <span key={i}>
                  {line.replace(/\*\*(.*?)\*\*/g, "$1")}
                  {i < msg.content.split("\n").length - 1 && <br />}
                </span>
              ))}
            </div>
          </div>
        ))}
        {thinking && (
          <div className="flex gap-2.5">
            <div className="w-7 h-7 rounded-full bg-studio-blue/20 flex items-center justify-center">
              <Bot className="w-4 h-4 text-studio-blue" />
            </div>
            <div className="bg-studio-panel border border-studio-border rounded-xl px-3 py-2.5">
              <div className="flex gap-1">
                {[0, 150, 300].map((d) => (
                  <div
                    key={d}
                    className="w-1.5 h-1.5 bg-studio-blue rounded-full animate-bounce"
                    style={{ animationDelay: `${d}ms` }}
                  />
                ))}
              </div>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>
      <div className="p-3 border-t border-studio-border">
        <div className="flex gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKey}
            placeholder="Diga o que deseja modificar..."
            className="studio-input flex-1 text-sm py-2.5"
            disabled={thinking}
          />
          <button
            onClick={sendMessage}
            disabled={!input.trim() || thinking}
            className="btn-primary py-2.5 px-3"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
