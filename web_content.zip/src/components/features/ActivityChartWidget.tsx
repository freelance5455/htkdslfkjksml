import { useState, useMemo } from "react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";
import type { Project } from "@/types";
import {
  TrendingUp,
  BarChart2,
  Activity,
  Calendar,
  Layers,
  CheckCircle2,
  Zap,
  Sparkles,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface ActivityChartWidgetProps {
  projects: Project[];
  className?: string;
}

type Timeframe = "7D" | "30D" | "12W" | "6M";
type ChartType = "area" | "bar";

interface DataPoint {
  dateKey: string;
  label: string;
  fullDate: string;
  creations: number;
  completed: number;
  assets: number;
}

export default function ActivityChartWidget({ projects, className }: ActivityChartWidgetProps) {
  const [timeframe, setTimeframe] = useState<Timeframe>("7D");
  const [chartType, setChartType] = useState<ChartType>("area");
  const [activeMetric, setActiveMetric] = useState<"all" | "creations" | "completed">("all");

  // Generate bucket data based on real projects + timeframes
  const { chartData, summary } = useMemo(() => {
    const now = new Date();
    const dataPoints: DataPoint[] = [];

    // Helper to get normalized start of day
    const getStartOfDay = (d: Date) => {
      const copy = new Date(d);
      copy.setHours(0, 0, 0, 0);
      return copy;
    };

    if (timeframe === "7D") {
      // 7 days (Daily)
      for (let i = 6; i >= 0; i--) {
        const d = new Date(now);
        d.setDate(d.getDate() - i);
        const dayStart = getStartOfDay(d);
        const nextDay = new Date(dayStart);
        nextDay.setDate(nextDay.getDate() + 1);

        const dayName = d.toLocaleDateString("pt-BR", { weekday: "short" });
        const dayNum = d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" });

        // Count projects matching this day
        const dayProjects = projects.filter((p) => {
          const pDate = new Date(p.createdAt || Date.now());
          return pDate >= dayStart && pDate < nextDay;
        });

        const completedCount = dayProjects.filter((p) => p.status === "COMPLETED").length;
        const assetsCount = dayProjects.reduce((acc, p) => acc + (p.assets?.length || (p.storyboard?.scenes?.length ?? 1)), 0);

        dataPoints.push({
          dateKey: dayStart.toISOString().split("T")[0],
          label: `${dayName.charAt(0).toUpperCase() + dayName.slice(1, 3)} ${dayNum}`,
          fullDate: d.toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long" }),
          creations: dayProjects.length,
          completed: completedCount,
          assets: assetsCount,
        });
      }
    } else if (timeframe === "30D") {
      // 30 days grouped in 5-day intervals or daily
      for (let i = 29; i >= 0; i -= 3) {
        const d = new Date(now);
        d.setDate(d.getDate() - i);
        const start = getStartOfDay(d);
        const end = new Date(start);
        end.setDate(end.getDate() + 3);

        const label = d.toLocaleDateString("pt-BR", { day: "2-digit", month: "short" });

        const rangeProjects = projects.filter((p) => {
          const pDate = new Date(p.createdAt || Date.now());
          return pDate >= start && pDate < end;
        });

        const completedCount = rangeProjects.filter((p) => p.status === "COMPLETED").length;
        const assetsCount = rangeProjects.reduce((acc, p) => acc + (p.assets?.length || (p.storyboard?.scenes?.length ?? 1)), 0);

        dataPoints.push({
          dateKey: start.toISOString().split("T")[0],
          label,
          fullDate: `Período de ${d.toLocaleDateString("pt-BR", { day: "numeric", month: "short" })}`,
          creations: rangeProjects.length,
          completed: completedCount,
          assets: assetsCount,
        });
      }
    } else if (timeframe === "12W") {
      // 12 Weeks (Weekly)
      for (let i = 11; i >= 0; i--) {
        const startOfWeek = new Date(now);
        startOfWeek.setDate(startOfWeek.getDate() - i * 7);
        startOfWeek.setHours(0, 0, 0, 0);

        const endOfWeek = new Date(startOfWeek);
        endOfWeek.setDate(endOfWeek.getDate() + 7);

        const weekLabel = `Sem ${12 - i}`;
        const weekProjects = projects.filter((p) => {
          const pDate = new Date(p.createdAt || Date.now());
          return pDate >= startOfWeek && pDate < endOfWeek;
        });

        const completedCount = weekProjects.filter((p) => p.status === "COMPLETED").length;
        const assetsCount = weekProjects.reduce((acc, p) => acc + (p.assets?.length || (p.storyboard?.scenes?.length ?? 1)), 0);

        dataPoints.push({
          dateKey: startOfWeek.toISOString().split("T")[0],
          label: weekLabel,
          fullDate: `Semana ${12 - i} (${startOfWeek.toLocaleDateString("pt-BR", { day: "2-digit", month: "short" })})`,
          creations: weekProjects.length,
          completed: completedCount,
          assets: assetsCount,
        });
      }
    } else {
      // 6 Months (Monthly)
      for (let i = 5; i >= 0; i--) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const nextMonth = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);

        const monthLabel = d.toLocaleDateString("pt-BR", { month: "short" });
        const monthProjects = projects.filter((p) => {
          const pDate = new Date(p.createdAt || Date.now());
          return pDate >= d && pDate < nextMonth;
        });

        const completedCount = monthProjects.filter((p) => p.status === "COMPLETED").length;
        const assetsCount = monthProjects.reduce((acc, p) => acc + (p.assets?.length || (p.storyboard?.scenes?.length ?? 1)), 0);

        dataPoints.push({
          dateKey: `${d.getFullYear()}-${d.getMonth() + 1}`,
          label: monthLabel.charAt(0).toUpperCase() + monthLabel.slice(1),
          fullDate: d.toLocaleDateString("pt-BR", { month: "long", year: "numeric" }),
          creations: monthProjects.length,
          completed: completedCount,
          assets: assetsCount,
        });
      }
    }

    // Summary calculations
    const totalCreations = dataPoints.reduce((sum, p) => sum + p.creations, 0);
    const totalCompleted = dataPoints.reduce((sum, p) => sum + p.completed, 0);
    const totalAssets = dataPoints.reduce((sum, p) => sum + p.assets, 0);
    const peakPoint = dataPoints.reduce((max, p) => (p.creations > max.creations ? p : max), dataPoints[0] || { label: "N/A", creations: 0 });
    const avgPerPeriod = (totalCreations / (dataPoints.length || 1)).toFixed(1);
    const completionRate = totalCreations > 0 ? Math.round((totalCompleted / totalCreations) * 100) : 100;

    return {
      chartData: dataPoints,
      summary: {
        totalCreations,
        totalCompleted,
        totalAssets,
        peakLabel: peakPoint?.label || "Hoje",
        peakValue: peakPoint?.creations || 0,
        avgPerPeriod,
        completionRate,
      },
    };
  }, [projects, timeframe]);

  // Custom Chart Tooltip
  interface CustomTooltipProps {
    active?: boolean;
    payload?: Array<{ payload: DataPoint; value: number; name: string }>;
    label?: string;
  }

  const CustomTooltip = ({ active, payload, label }: CustomTooltipProps) => {
    if (active && payload && payload.length) {
      const data: DataPoint = payload[0]?.payload;
      return (
        <div className="bg-studio-surface border border-studio-border shadow-xl rounded-xl p-3.5 min-w-[200px] text-xs backdrop-blur-md">
          <p className="font-semibold text-studio-text mb-2 pb-1.5 border-b border-studio-border/60">
            {data?.fullDate || label}
          </p>
          <div className="space-y-1.5">
            <div className="flex items-center justify-between gap-4">
              <span className="flex items-center gap-1.5 text-studio-blue">
                <span className="w-2 h-2 rounded-full bg-studio-blue" />
                Novas Criações:
              </span>
              <span className="font-bold text-studio-text">{data?.creations ?? 0}</span>
            </div>
            <div className="flex items-center justify-between gap-4">
              <span className="flex items-center gap-1.5 text-studio-green">
                <span className="w-2 h-2 rounded-full bg-studio-green" />
                Concluídos:
              </span>
              <span className="font-bold text-studio-text">{data?.completed ?? 0}</span>
            </div>
            <div className="flex items-center justify-between gap-4">
              <span className="flex items-center gap-1.5 text-studio-purple">
                <span className="w-2 h-2 rounded-full bg-studio-purple" />
                Ativos Gerados:
              </span>
              <span className="font-bold text-studio-text">{data?.assets ?? 0}</span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className={cn("studio-card p-5 space-y-4", className)}>
      {/* Header with Title & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-studio-blue/15 flex items-center justify-center text-studio-blue">
            <Activity className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-studio-text font-display flex items-center gap-2">
              Atividade de Produção & Criação
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-studio-blue/10 text-studio-blue border border-studio-blue/20">
                <Sparkles className="w-2.5 h-2.5" /> Recharts
              </span>
            </h3>
            <p className="text-xs text-studio-text-muted">
              Volume de projetos criados, renderizados e assets produzidos
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Timeframe selector */}
          <div className="flex items-center bg-studio-panel p-1 rounded-xl border border-studio-border text-xs">
            {(["7D", "30D", "12W", "6M"] as Timeframe[]).map((t) => (
              <button
                key={t}
                onClick={() => setTimeframe(t)}
                className={cn(
                  "px-2.5 py-1 rounded-lg font-medium transition-all",
                  timeframe === t
                    ? "bg-studio-blue text-white shadow-sm font-semibold"
                    : "text-studio-text-muted hover:text-studio-text"
                )}
              >
                {t === "7D" ? "7 Dias" : t === "30D" ? "30 Dias" : t === "12W" ? "12 Semanas" : "6 Meses"}
              </button>
            ))}
          </div>

          {/* Chart Type Toggle */}
          <div className="flex items-center bg-studio-panel p-1 rounded-xl border border-studio-border">
            <button
              onClick={() => setChartType("area")}
              title="Gráfico em Área (Fluxo)"
              className={cn(
                "p-1.5 rounded-lg text-xs transition-all",
                chartType === "area"
                  ? "bg-studio-blue/20 text-studio-blue"
                  : "text-studio-text-muted hover:text-studio-text"
              )}
            >
              <TrendingUp className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setChartType("bar")}
              title="Gráfico em Barras"
              className={cn(
                "p-1.5 rounded-lg text-xs transition-all",
                chartType === "bar"
                  ? "bg-studio-blue/20 text-studio-blue"
                  : "text-studio-text-muted hover:text-studio-text"
              )}
            >
              <BarChart2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Mini Stats Highlight Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
        <div className="p-3 rounded-xl bg-studio-panel/70 border border-studio-border">
          <p className="text-[11px] text-studio-text-muted flex items-center gap-1.5">
            <Layers className="w-3 h-3 text-studio-blue" />
            Total Criado
          </p>
          <p className="text-lg font-bold text-studio-text font-display mt-0.5">
            {summary.totalCreations}{" "}
            <span className="text-xs font-normal text-studio-text-muted">projetos</span>
          </p>
        </div>

        <div className="p-3 rounded-xl bg-studio-panel/70 border border-studio-border">
          <p className="text-[11px] text-studio-text-muted flex items-center gap-1.5">
            <CheckCircle2 className="w-3 h-3 text-studio-green" />
            Taxa de Conclusão
          </p>
          <p className="text-lg font-bold text-studio-green font-display mt-0.5">
            {summary.completionRate}%
          </p>
        </div>

        <div className="p-3 rounded-xl bg-studio-panel/70 border border-studio-border">
          <p className="text-[11px] text-studio-text-muted flex items-center gap-1.5">
            <Zap className="w-3 h-3 text-yellow-400" />
            Pico de Atividade
          </p>
          <p className="text-lg font-bold text-studio-text font-display mt-0.5 truncate">
            {summary.peakLabel}
          </p>
        </div>

        <div className="p-3 rounded-xl bg-studio-panel/70 border border-studio-border">
          <p className="text-[11px] text-studio-text-muted flex items-center gap-1.5">
            <Calendar className="w-3 h-3 text-studio-purple" />
            Média por Período
          </p>
          <p className="text-lg font-bold text-studio-purple font-display mt-0.5">
            {summary.avgPerPeriod}{" "}
            <span className="text-xs font-normal text-studio-text-muted">/unidade</span>
          </p>
        </div>
      </div>

      {/* Main Recharts Area / Bar Container */}
      <div className="w-full h-64 pt-2">
        <ResponsiveContainer width="100%" height="100%">
          {chartType === "area" ? (
            <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorCreations" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.45} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="colorCompleted" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="colorAssets" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
              <XAxis
                dataKey="label"
                stroke="#64748b"
                tickLine={false}
                axisLine={{ stroke: "#e2e8f0" }}
                tick={{ fontSize: 11, fill: "#64748b" }}
              />
              <YAxis
                stroke="#64748b"
                tickLine={false}
                axisLine={false}
                allowDecimals={false}
                tick={{ fontSize: 11, fill: "#64748b" }}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend
                verticalAlign="top"
                align="right"
                height={30}
                iconType="circle"
                wrapperStyle={{ fontSize: "11px", color: "#64748b" }}
              />
              {(activeMetric === "all" || activeMetric === "creations") && (
                <Area
                  type="monotone"
                  dataKey="creations"
                  name="Criações Iniciadas"
                  stroke="#2563eb"
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#colorCreations)"
                  activeDot={{ r: 5, fill: "#2563eb", stroke: "#ffffff", strokeWidth: 2 }}
                />
              )}
              {(activeMetric === "all" || activeMetric === "completed") && (
                <Area
                  type="monotone"
                  dataKey="completed"
                  name="Concluídos"
                  stroke="#10b981"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorCompleted)"
                  activeDot={{ r: 5, fill: "#10b981", stroke: "#ffffff", strokeWidth: 2 }}
                />
              )}
              {activeMetric === "all" && (
                <Area
                  type="monotone"
                  dataKey="assets"
                  name="Ativos / Cenas"
                  stroke="#8b5cf6"
                  strokeWidth={1.5}
                  strokeDasharray="4 4"
                  fillOpacity={1}
                  fill="url(#colorAssets)"
                />
              )}
            </AreaChart>
          ) : (
            <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
              <XAxis
                dataKey="label"
                stroke="#64748b"
                tickLine={false}
                axisLine={{ stroke: "#e2e8f0" }}
                tick={{ fontSize: 11, fill: "#64748b" }}
              />
              <YAxis
                stroke="#64748b"
                tickLine={false}
                axisLine={false}
                allowDecimals={false}
                tick={{ fontSize: 11, fill: "#64748b" }}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend
                verticalAlign="top"
                align="right"
                height={30}
                iconType="circle"
                wrapperStyle={{ fontSize: "11px", color: "#94a3b8" }}
              />
              <Bar dataKey="creations" name="Criações" fill="#3b82f6" radius={[4, 4, 0, 0]} maxBarSize={32} />
              <Bar dataKey="completed" name="Concluídos" fill="#10b981" radius={[4, 4, 0, 0]} maxBarSize={32} />
            </BarChart>
          )}
        </ResponsiveContainer>
      </div>

      {/* Footer info and Filter Metrics Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-studio-border/60 text-xs">
        <div className="flex items-center gap-2">
          <span className="text-studio-text-muted">Filtrar linhas:</span>
          <button
            onClick={() => setActiveMetric("all")}
            className={cn(
              "px-2 py-0.5 rounded text-[11px] font-medium transition-colors",
              activeMetric === "all" ? "bg-studio-border text-studio-text font-semibold" : "text-studio-text-muted hover:text-studio-text"
            )}
          >
            Todas as Métricas
          </button>
          <button
            onClick={() => setActiveMetric("creations")}
            className={cn(
              "px-2 py-0.5 rounded text-[11px] font-medium transition-colors",
              activeMetric === "creations" ? "bg-studio-blue/20 text-studio-blue font-semibold" : "text-studio-text-muted hover:text-studio-text"
            )}
          >
            Apenas Criações
          </button>
          <button
            onClick={() => setActiveMetric("completed")}
            className={cn(
              "px-2 py-0.5 rounded text-[11px] font-medium transition-colors",
              activeMetric === "completed" ? "bg-studio-green/20 text-studio-green font-semibold" : "text-studio-text-muted hover:text-studio-text"
            )}
          >
            Apenas Concluídos
          </button>
        </div>

        <span className="text-studio-text-muted text-[11px]">
          Atualização em tempo real conforme novos projetos são gerados
        </span>
      </div>
    </div>
  );
}
