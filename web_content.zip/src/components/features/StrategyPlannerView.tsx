// ============================================================
// AI CREATOR STUDIO — CORE 3.0 STRATEGY PLANNER & GOAL TRACKER
// ============================================================

import { useState, useEffect } from "react";
import {
  Target, TrendingUp, PieChart, Sparkles, Plus, CheckCircle2,
  Calendar, Award, ChevronRight, BarChart2, Layers
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { ContentStrategy, CreatorGoal } from "@/types/core3";
import { getContentStrategy, saveContentStrategy } from "@/lib/core3/strategyEngine";
import { getCreatorGoals, saveCreatorGoal, updateGoalProgress } from "@/lib/core3/goalsStore";

export default function StrategyPlannerView() {
  const [strategy, setStrategy] = useState<ContentStrategy>(getContentStrategy());
  const [goals, setGoals] = useState<CreatorGoal[]>(getCreatorGoals());
  const [isEditingNiche, setIsEditingNiche] = useState(false);
  const [nicheInput, setNicheInput] = useState(strategy.niche);

  const handleSaveNiche = () => {
    const updated = saveContentStrategy({ niche: nicheInput });
    setStrategy(updated);
    setIsEditingNiche(false);
  };

  return (
    <div className="space-y-6">
      {/* Overview & Content Strategy Header */}
      <div className="studio-card p-6 border border-studio-border bg-gradient-to-r from-studio-surface to-studio-panel">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <span className="text-[10px] uppercase font-mono tracking-widest text-studio-blue font-bold">
              Diretrizes do Canal
            </span>
            <div className="flex items-center gap-2 mt-1">
              <h2 className="text-xl font-bold text-studio-text font-display">
                Estratégia de Crescimento & Pilares
              </h2>
            </div>
            <p className="text-xs text-studio-text-muted mt-0.5">
              Nicho: <strong className="text-studio-text">{strategy.niche}</strong> · Frequência: <strong className="text-studio-blue">{strategy.frequency.postsPerWeek} posts/semana</strong>
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsEditingNiche(!isEditingNiche)}
              className="btn-secondary text-xs py-2 px-3"
            >
              Editar Nicho
            </button>
          </div>
        </div>

        {isEditingNiche && (
          <div className="mt-4 pt-4 border-t border-studio-border flex items-center gap-2">
            <input
              type="text"
              value={nicheInput}
              onChange={(e) => setNicheInput(e.target.value)}
              className="input text-xs flex-1"
              placeholder="Digite o nicho do seu canal..."
            />
            <button onClick={handleSaveNiche} className="btn-primary text-xs py-2 px-4">
              Salvar
            </button>
          </div>
        )}
      </div>

      {/* Content Pillars & Content Mix (70 / 20 / 10 Framework) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Content Pillars */}
        <div className="lg:col-span-2 studio-card p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-studio-text font-display flex items-center gap-2">
              <Layers className="w-4 h-4 text-studio-blue" />
              Pilares de Conteúdo Estruturados
            </h3>
            <span className="text-xs text-studio-text-muted">{strategy.pillars.length} pilares</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {strategy.pillars.map((pillar) => (
              <div
                key={pillar.id}
                className="p-4 rounded-xl bg-studio-panel border border-studio-border space-y-2 hover:border-studio-blue/30 transition-all"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-studio-text">{pillar.name}</span>
                  <span className="text-xs font-mono font-bold text-studio-blue">{pillar.targetRatioPercent}%</span>
                </div>
                <p className="text-[11px] text-studio-text-muted leading-relaxed line-clamp-3">
                  {pillar.description}
                </p>
                <div className="pt-1 flex flex-wrap gap-1">
                  {pillar.keywords.map((kw) => (
                    <span key={kw} className="text-[9px] px-1.5 py-0.5 rounded bg-studio-bg text-studio-text-dim border border-studio-border/60">
                      {kw}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 70/20/10 Content Mix */}
        <div className="studio-card p-5 space-y-4">
          <h3 className="text-sm font-bold text-studio-text font-display flex items-center gap-2">
            <PieChart className="w-4 h-4 text-studio-purple" />
            Distribuição 70/20/10
          </h3>

          <div className="space-y-3">
            <div className="p-3 rounded-xl bg-studio-panel border border-studio-border space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-studio-blue">70% · Conteúdo Base (Core)</span>
                <span className="font-mono text-studio-text-muted">Consistência</span>
              </div>
              <p className="text-[11px] text-studio-text-muted">Vídeos musicais de animais em animação 3D que fidelizam inscritos.</p>
            </div>

            <div className="p-3 rounded-xl bg-studio-panel border border-studio-border space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-studio-green">20% · Crescimento (Growth)</span>
                <span className="font-mono text-studio-text-muted">Alcance</span>
              </div>
              <p className="text-[11px] text-studio-text-muted">Shorts virais, tendências infantis e ganchos rápidos para atração de novos públicos.</p>
            </div>

            <div className="p-3 rounded-xl bg-studio-panel border border-studio-border space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-studio-purple">10% · Experimental</span>
                <span className="font-mono text-studio-text-muted">Inovação</span>
              </div>
              <p className="text-[11px] text-studio-text-muted">Formatos interativos, desafios cantados e novas técnicas visuais.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Creator Goals Tracker */}
      <div className="studio-card p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-studio-text font-display flex items-center gap-2">
              <Target className="w-4 h-4 text-studio-gold" />
              Metas do Criador & Progresso
            </h3>
            <p className="text-xs text-studio-text-muted">
              O Autopilot alinha automaticamente a geração de ideias e cronogramas a estas metas.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {goals.map((goal) => {
            const pct = Math.min(100, Math.round((goal.currentMetric / goal.targetMetric) * 100));

            return (
              <div key={goal.id} className="p-4 rounded-xl bg-studio-panel border border-studio-border space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-studio-gold">
                      {goal.type === "GROW_AUDIENCE" ? "Audiência" : goal.type === "RETENTION" ? "Retenção" : "Consistência"}
                    </span>
                    <h4 className="text-xs font-bold text-studio-text">{goal.title}</h4>
                  </div>
                  <span className="text-xs font-bold font-mono text-studio-blue">{pct}%</span>
                </div>

                {/* Progress bar */}
                <div className="w-full h-2 rounded-full bg-studio-bg overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-studio-gold to-studio-blue transition-all"
                    style={{ width: `${pct}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-[11px] text-studio-text-muted">
                  <span>Atual: <strong className="text-studio-text">{goal.currentMetric.toLocaleString()} {goal.unit}</strong></span>
                  <span>Alvo: <strong className="text-studio-text">{goal.targetMetric.toLocaleString()} {goal.unit}</strong></span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
