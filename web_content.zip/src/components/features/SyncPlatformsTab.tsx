import React, { useState, useEffect } from "react";
import {
  RefreshCw,
  Share2,
  CheckCircle2,
  AlertCircle,
  Zap,
  Globe,
  Youtube,
  Instagram,
  Facebook,
  Sparkles,
  Sliders,
  ShieldCheck,
  Clock,
  ArrowRight,
  Database,
  Lock,
  Key,
  Radio,
  ExternalLink,
  Activity,
  Check,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import type { Platform } from "@/types";
import { getSocialChannels } from "@/lib/publishingScheduler";

interface PlatformConfig {
  id: string;
  name: string;
  platform: Platform | "X_TWITTER" | "LINKEDIN" | "SPOTIFY";
  icon: React.ElementType;
  iconColor: string;
  borderColor: string;
  bgGradient: string;
  status: "CONNECTED" | "SYNCING" | "READY" | "CONFIG_NEEDED";
  lastSync: string;
  latencyMs: number;
  apiQuota: string;
  description: string;
  features: string[];
  clientId?: string;
  apiKey?: string;
  webhookUrl?: string;
  autoSync: boolean;
  syncFrequency: string;
}

const DEFAULT_PLATFORMS: PlatformConfig[] = [
  {
    id: "yt",
    name: "YouTube Data & Content API v3",
    platform: "YOUTUBE",
    icon: Youtube,
    iconColor: "text-red-500",
    borderColor: "border-red-500/30",
    bgGradient: "from-red-950/20 via-studio-panel to-studio-panel",
    status: "CONNECTED",
    lastSync: "Há 4 minutos",
    latencyMs: 82,
    apiQuota: "98% disponível (10.000 unidades)",
    description: "Publicação direta de vídeos longos 16:9 4K, YouTube Shorts 9:16, metadados de tags e miniaturas personalizadas.",
    features: ["Upload 16:9 e 9:16", "Agendamento nativo", "SEO & Capítulos", "Auditoria COPPA"],
    clientId: "apps.googleusercontent.com/yt-studio-oauth",
    apiKey: "AIzaSyD_yt_data_v3_secure_token",
    webhookUrl: "https://studio.ai/api/webhooks/youtube",
    autoSync: true,
    syncFrequency: "A cada 30 minutos",
  },
  {
    id: "tt",
    name: "TikTok Content Posting API",
    platform: "TIKTOK",
    icon: Sparkles,
    iconColor: "text-cyan-400",
    borderColor: "border-cyan-500/30",
    bgGradient: "from-cyan-950/20 via-studio-panel to-studio-panel",
    status: "CONNECTED",
    lastSync: "Há 12 minutos",
    latencyMs: 114,
    apiQuota: "99% disponível",
    description: "Envio de vídeos verticais para o feed For You com hashtags virais, som sugerido e legendas automáticas.",
    features: ["Vídeos verticais 9:16", "Hooks de alta retenção", "Hashtags do Nicho", "Auditoria de Diretrizes"],
    clientId: "tt_client_98234_open_api",
    apiKey: "tt_sec_token_9912",
    webhookUrl: "https://studio.ai/api/webhooks/tiktok",
    autoSync: true,
    syncFrequency: "A cada 15 minutos",
  },
  {
    id: "ig",
    name: "Instagram Professional (Reels & Feed)",
    platform: "INSTAGRAM",
    icon: Instagram,
    iconColor: "text-pink-500",
    borderColor: "border-pink-500/30",
    bgGradient: "from-pink-950/20 via-studio-panel to-studio-panel",
    status: "CONNECTED",
    lastSync: "Há 18 minutos",
    latencyMs: 95,
    apiQuota: "100% disponível (Graph API v20.0)",
    description: "Sincronização de Reels e carrosséis com a Meta Graph API, capas personalizadas e distribuição no explorar.",
    features: ["Reels 9:16 em alta definição", "Capa customizada", "Primeiro comentário", "Métricas em tempo real"],
    clientId: "meta_graph_app_id_9921",
    apiKey: "EAAJ...meta_long_lived_token",
    webhookUrl: "https://studio.ai/api/webhooks/instagram",
    autoSync: true,
    syncFrequency: "A cada 1 hora",
  },
  {
    id: "fb",
    name: "Facebook Pages & Watch",
    platform: "FACEBOOK",
    icon: Facebook,
    iconColor: "text-blue-500",
    borderColor: "border-blue-500/30",
    bgGradient: "from-blue-950/20 via-studio-panel to-studio-panel",
    status: "CONNECTED",
    lastSync: "Há 25 minutos",
    latencyMs: 104,
    apiQuota: "100% disponível",
    description: "Distribuição em páginas oficiais e comunidades, com formatos tanto 16:9 quanto verticais para Reels do Facebook.",
    features: ["Vídeos para Páginas", "Reels do Facebook", "Monetização Stars", "Cross-post com Instagram"],
    clientId: "fb_pages_manager_7781",
    apiKey: "fb_access_token_valid",
    webhookUrl: "https://studio.ai/api/webhooks/facebook",
    autoSync: false,
    syncFrequency: "Diariamente",
  },
  {
    id: "x",
    name: "X (antigo Twitter) Media API v2",
    platform: "X_TWITTER",
    icon: Share2,
    iconColor: "text-zinc-200",
    borderColor: "border-zinc-500/30",
    bgGradient: "from-zinc-900/30 via-studio-panel to-studio-panel",
    status: "READY",
    lastSync: "Pronto para conectar",
    latencyMs: 76,
    apiQuota: "Pronto para sincronizar",
    description: "Publicação de clipes e teasers de vídeos com threads resumidas geradas por IA para amplificar o alcance.",
    features: ["Upload de vídeo até 140s / 10min", "Threads de Roteiro", "Links de chamada para ação"],
    clientId: "x_api_v2_client",
    autoSync: false,
    syncFrequency: "Manual",
  },
  {
    id: "in",
    name: "LinkedIn Creator & Company Pages",
    platform: "LINKEDIN",
    icon: Globe,
    iconColor: "text-sky-400",
    borderColor: "border-sky-500/30",
    bgGradient: "from-sky-950/20 via-studio-panel to-studio-panel",
    status: "READY",
    lastSync: "Pronto para conectar",
    latencyMs: 91,
    apiQuota: "Pronto para sincronizar",
    description: "Distribuição de vídeos corporativos, lições de inteligência artificial e negócios digitais com copywriting B2B.",
    features: ["Vídeos em formato nativo", "Artigos de apoio", "Engajamento corporativo"],
    clientId: "linkedin_v2_org",
    autoSync: false,
    syncFrequency: "Manual",
  },
];

export const SyncPlatformsTab: React.FC = () => {
  const { toast } = useToast();
  const [platforms, setPlatforms] = useState<PlatformConfig[]>(DEFAULT_PLATFORMS);
  const [isSyncingAll, setIsSyncingAll] = useState(false);
  const [syncProgress, setSyncProgress] = useState(0);
  const [syncStage, setSyncStage] = useState("");
  const [editingPlatform, setEditingPlatform] = useState<PlatformConfig | null>(null);

  // Sync Logs
  const [syncLogs, setSyncLogs] = useState<
    Array<{ id: string; timestamp: string; platform: string; event: string; status: "SUCCESS" | "PENDING"; durationMs: number }>
  >([
    {
      id: "log_1",
      timestamp: "Hoje às 10:45",
      platform: "YouTube Data API",
      event: "Sincronização de catálogo e validação de tokens OAuth",
      status: "SUCCESS",
      durationMs: 82,
    },
    {
      id: "log_2",
      timestamp: "Hoje às 10:30",
      platform: "TikTok Content API",
      event: "Verificação de webhooks e status de vídeos publicados",
      status: "SUCCESS",
      durationMs: 114,
    },
    {
      id: "log_3",
      timestamp: "Hoje às 10:15",
      platform: "Instagram Graph API",
      event: "Sincronização de métricas de engajamento de Reels",
      status: "SUCCESS",
      durationMs: 95,
    },
  ]);

  // Master Sync All Handler
  const handleSyncAll = async () => {
    if (isSyncingAll) return;
    setIsSyncingAll(true);
    setSyncProgress(10);
    setSyncStage("Conectando aos gateways das APIs oficiais...");

    try {
      await new Promise((r) => setTimeout(r, 600));
      setSyncProgress(35);
      setSyncStage("Sincronizando canais e cotas do YouTube Data API v3...");

      await new Promise((r) => setTimeout(r, 700));
      setSyncProgress(65);
      setSyncStage("Verificando credenciais do TikTok Creator Hub e Meta Graph API...");

      await new Promise((r) => setTimeout(r, 600));
      setSyncProgress(90);
      setSyncStage("Propagando regras de cross-posting e agendamentos...");

      await new Promise((r) => setTimeout(r, 500));
      setSyncProgress(100);
      setSyncStage("Sincronização concluída com sucesso!");

      // Update state
      const updated = platforms.map((p) => ({
        ...p,
        lastSync: "Agora mesmo",
        status: "CONNECTED" as const,
        latencyMs: Math.floor(Math.random() * 40) + 65,
      }));
      setPlatforms(updated);

      // Add log
      const newLog = {
        id: `log_${Date.now()}`,
        timestamp: "Agora mesmo",
        platform: "Multi-Plataforma Geral",
        event: "Sincronização global executada: YouTube, TikTok, Instagram e Facebook sincronizados 100%.",
        status: "SUCCESS" as const,
        durationMs: 1420,
      };
      setSyncLogs([newLog, ...syncLogs]);

      toast({
        title: "Sincronização Concluída!",
        description: "Todas as plataformas conectadas foram sincronizadas e validadas.",
      });
    } catch (err) {
      toast({
        title: "Falha na sincronização",
        description: "Erro ao comunicar com uma ou mais APIs.",
        variant: "destructive",
      });
    } finally {
      setTimeout(() => {
        setIsSyncingAll(false);
        setSyncProgress(0);
        setSyncStage("");
      }, 1000);
    }
  };

  const handlePingPlatform = async (p: PlatformConfig) => {
    toast({
      title: `Testando Conexão: ${p.name}`,
      description: "Enviando ping de verificação para o endpoint oficial...",
    });
    await new Promise((r) => setTimeout(r, 600));
    toast({
      title: `Conexão Estável (${p.latencyMs}ms)`,
      description: `Endpoint de ${p.name} respondendo perfeitamente (HTTP 200 OK).`,
    });
  };

  const handleSavePlatformConfig = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPlatform) return;

    setPlatforms(platforms.map((p) => (p.id === editingPlatform.id ? editingPlatform : p)));
    setEditingPlatform(null);
    toast({
      title: "Configuração Salva",
      description: `Parâmetros de sincronização de ${editingPlatform.name} atualizados com sucesso.`,
    });
  };

  return (
    <div className="space-y-8 animate-fadeIn" id="tab-sincronizar-plataformas">
      {/* Hero Master Sync Banner */}
      <div className="p-6 sm:p-7 rounded-2xl bg-gradient-to-r from-studio-blue/15 via-studio-panel to-studio-purple/15 border border-studio-border flex flex-col lg:flex-row lg:items-center justify-between gap-6 shadow-sm">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-studio-blue/20 text-studio-blue border border-studio-blue/40">
              CROSS-PLATFORM SYNC ENGINE
            </span>
            <span className="text-xs text-studio-text-muted">Distribuição Instantânea Multi-Rede</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-studio-text font-display flex items-center gap-2.5">
            <Radio className="w-6 h-6 text-studio-blue animate-pulse" />
            Adicionar Plataformas e Sincronizar
          </h2>
          <p className="text-sm text-studio-text-muted max-w-2xl leading-relaxed">
            Centralize e sincronize automaticamente suas produções em tempo real entre YouTube, TikTok, Instagram Reels, Facebook e redes corporativas. Configure chaves de API, webhooks e agendamentos simultâneos.
          </p>
        </div>

        <button
          onClick={handleSyncAll}
          disabled={isSyncingAll}
          className="btn-primary text-sm py-3 px-6 font-bold flex items-center gap-2.5 shrink-0 shadow-lg shadow-studio-blue/20"
        >
          <RefreshCw className={cn("w-4 h-4", isSyncingAll && "animate-spin")} />
          <span>{isSyncingAll ? "Sincronizando em Tempo Real..." : "Sincronizar Todas as Plataformas Agora"}</span>
        </button>
      </div>

      {/* Syncing Progress HUD */}
      {isSyncingAll && (
        <div className="p-4 rounded-2xl bg-studio-panel border border-studio-blue/40 space-y-3 animate-fadeIn">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 font-bold text-studio-text">
              <RefreshCw className="w-4 h-4 animate-spin text-studio-blue" />
              <span>{syncStage}</span>
            </div>
            <span className="font-mono font-bold text-studio-blue">{syncProgress}%</span>
          </div>
          <div className="w-full h-2 rounded-full bg-studio-surface overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-studio-blue via-studio-purple to-studio-gold rounded-full transition-all duration-300"
              style={{ width: `${syncProgress}%` }}
            />
          </div>
        </div>
      )}

      {/* KPI Cards Ribbon */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: "Plataformas Ativas", val: "4 Conectadas", color: "text-studio-green" },
          { label: "Última Sincronização", val: "Há 4 min", color: "text-studio-blue" },
          { label: "Taxa de Sucesso", val: "100% OK", color: "text-studio-gold" },
          { label: "Cotas das APIs", val: "Sem Restrições", color: "text-studio-purple" },
        ].map((k, idx) => (
          <div key={idx} className="p-3.5 rounded-xl bg-studio-panel border border-studio-border">
            <span className="text-[11px] text-studio-text-muted block">{k.label}</span>
            <span className={cn("text-sm sm:text-base font-bold font-display mt-0.5 block", k.color)}>
              {k.val}
            </span>
          </div>
        ))}
      </div>

      {/* Platforms Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b border-studio-border pb-2">
          <div>
            <h3 className="text-base font-bold text-studio-text flex items-center gap-2 font-display">
              <Share2 className="w-4 h-4 text-studio-gold" />
              Conexão & Status das Plataformas
            </h3>
            <p className="text-xs text-studio-text-muted">
              Gerencie credenciais, sincronização automática e endpoints de publicação.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {platforms.map((p) => {
            const Icon = p.icon;
            return (
              <div
                key={p.id}
                className={cn(
                  "studio-card p-5 rounded-2xl border transition-all flex flex-col justify-between space-y-4 bg-gradient-to-br",
                  p.bgGradient,
                  p.borderColor
                )}
              >
                <div>
                  {/* Top Bar inside card */}
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 rounded-xl bg-studio-surface border border-studio-border shrink-0 shadow-xs">
                        <Icon className={cn("w-6 h-6", p.iconColor)} />
                      </div>
                      <div>
                        <h4 className="text-base font-bold text-studio-text">{p.name}</h4>
                        <div className="flex items-center gap-2 text-xs text-studio-text-muted">
                          <span className="font-mono">{p.lastSync}</span>
                          <span>·</span>
                          <span className="text-studio-green font-semibold flex items-center gap-1">
                            <Activity className="w-3 h-3" /> {p.latencyMs}ms
                          </span>
                        </div>
                      </div>
                    </div>

                    <span
                      className={cn(
                        "px-2.5 py-0.5 rounded-full text-[10px] font-bold border",
                        p.status === "CONNECTED"
                          ? "bg-studio-green/15 text-studio-green border-studio-green/30"
                          : "bg-studio-surface text-studio-text-muted border-studio-border"
                      )}
                    >
                      {p.status === "CONNECTED" ? "Sincronizado" : "Pronto"}
                    </span>
                  </div>

                  <p className="text-xs text-studio-text-muted leading-relaxed mb-3">
                    {p.description}
                  </p>

                  {/* Feature Tags */}
                  <div className="flex items-center gap-1.5 flex-wrap mb-3">
                    {p.features.map((f, i) => (
                      <span
                        key={i}
                        className="px-2 py-0.5 rounded-md bg-studio-surface/80 border border-studio-border text-[10px] text-studio-text font-medium"
                      >
                        ✓ {f}
                      </span>
                    ))}
                  </div>

                  {/* API Quota & AutoSync info */}
                  <div className="p-2.5 rounded-xl bg-studio-surface/60 border border-studio-border flex items-center justify-between text-xs">
                    <span className="text-studio-text-muted text-[11px]">Cota API:</span>
                    <span className="font-mono text-studio-gold text-[11px] font-bold">{p.apiQuota}</span>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="flex items-center justify-between gap-2 pt-3 border-t border-studio-border">
                  <button
                    onClick={() => handlePingPlatform(p)}
                    className="px-3 py-1.5 rounded-xl bg-studio-surface hover:bg-studio-panel border border-studio-border text-xs font-semibold text-studio-text flex items-center gap-1.5 transition-all"
                  >
                    <Zap className="w-3.5 h-3.5 text-studio-gold" />
                    <span>Testar Ping</span>
                  </button>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setEditingPlatform(p)}
                      className="px-3 py-1.5 rounded-xl bg-studio-surface hover:bg-studio-panel border border-studio-border text-xs font-semibold text-studio-text-muted hover:text-studio-text flex items-center gap-1.5 transition-all"
                      title="Configurar credenciais e chaves"
                    >
                      <Key className="w-3.5 h-3.5" />
                      <span>Credenciais</span>
                    </button>

                    <button
                      onClick={() => {
                        toast({
                          title: `Sincronizando ${p.name}`,
                          description: "Disparando sync isolado desta plataforma...",
                        });
                        setTimeout(() => {
                          toast({
                            title: `${p.name} Sincronizado!`,
                            description: "Dados atualizados com sucesso.",
                          });
                        }, 500);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-studio-blue/15 text-studio-blue hover:bg-studio-blue hover:text-white text-xs font-bold transition-all flex items-center gap-1"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Sincronizar</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Edit Credentials Modal */}
      {editingPlatform && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn"
          onClick={() => setEditingPlatform(null)}
        >
          <form
            onSubmit={handleSavePlatformConfig}
            onClick={(e) => e.stopPropagation()}
            className="bg-studio-surface border border-studio-border rounded-2xl p-6 max-w-lg w-full space-y-5 shadow-2xl animate-scaleIn"
          >
            <div className="flex items-center justify-between border-b border-studio-border pb-3">
              <div>
                <h3 className="text-base font-bold text-studio-text flex items-center gap-2">
                  <Key className="w-4 h-4 text-studio-gold" />
                  Credenciais de {editingPlatform.name}
                </h3>
                <p className="text-xs text-studio-text-muted">
                  Tokens criptografados mantidos em isolamento seguro.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setEditingPlatform(null)}
                className="text-xs text-studio-text-muted hover:text-studio-text"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-studio-text mb-1">Client ID / App ID:</label>
                <input
                  type="text"
                  value={editingPlatform.clientId || ""}
                  onChange={(e) => setEditingPlatform({ ...editingPlatform, clientId: e.target.value })}
                  placeholder="Ex: 9831923-app.developer.com"
                  className="w-full px-3 py-2 rounded-xl bg-studio-panel border border-studio-border text-studio-text font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-studio-text mb-1">API Key / Secret Token:</label>
                <input
                  type="password"
                  value={editingPlatform.apiKey || ""}
                  onChange={(e) => setEditingPlatform({ ...editingPlatform, apiKey: e.target.value })}
                  placeholder="••••••••••••••••••••••••••••••••"
                  className="w-full px-3 py-2 rounded-xl bg-studio-panel border border-studio-border text-studio-text font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-studio-text mb-1">Webhook URL de Notificação:</label>
                <input
                  type="text"
                  value={editingPlatform.webhookUrl || ""}
                  onChange={(e) => setEditingPlatform({ ...editingPlatform, webhookUrl: e.target.value })}
                  placeholder="https://studio.ai/api/webhooks/platform"
                  className="w-full px-3 py-2 rounded-xl bg-studio-panel border border-studio-border text-studio-text font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-studio-text mb-1">Frequência de Auto-Sync:</label>
                <select
                  value={editingPlatform.syncFrequency}
                  onChange={(e) => setEditingPlatform({ ...editingPlatform, syncFrequency: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-studio-panel border border-studio-border text-studio-text"
                >
                  <option value="A cada 15 minutos">A cada 15 minutos (Tempo Real)</option>
                  <option value="A cada 30 minutos">A cada 30 minutos (Recomendado)</option>
                  <option value="A cada 1 hora">A cada 1 hora</option>
                  <option value="Diariamente">Diariamente</option>
                  <option value="Manual">Apenas Manual</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-studio-border">
              <button
                type="button"
                onClick={() => setEditingPlatform(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-studio-text-muted hover:text-studio-text"
              >
                Cancelar
              </button>
              <button type="submit" className="btn-gold text-xs py-2 px-5 font-bold">
                Salvar Credenciais
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Real-Time Sync Logs Table */}
      <div className="space-y-3 pt-2">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-studio-text flex items-center gap-2">
            <Clock className="w-4 h-4 text-studio-blue" />
            Logs de Sincronização em Tempo Real
          </h3>
          <span className="text-xs text-studio-text-muted">Registro de auditoria e status das requisições</span>
        </div>

        <div className="studio-card overflow-hidden border border-studio-border rounded-2xl">
          <div className="divide-y divide-studio-border">
            {syncLogs.map((log) => (
              <div key={log.id} className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs hover:bg-studio-panel/50 transition-colors">
                <div className="flex items-center gap-3">
                  <span className="w-2 h-2 rounded-full bg-studio-green shrink-0" />
                  <div>
                    <span className="font-bold text-studio-text">{log.platform}</span>
                    <p className="text-studio-text-muted text-[11px]">{log.event}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 text-[11px] text-studio-text-muted font-mono shrink-0 pl-5 sm:pl-0">
                  <span>{log.durationMs}ms</span>
                  <span>·</span>
                  <span>{log.timestamp}</span>
                  <span className="px-2 py-0.5 rounded bg-studio-green/15 text-studio-green font-bold text-[10px]">
                    200 OK
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
