// ============================================================
// AI CREATOR STUDIO — CORE 2.0 REPURPOSE ENGINE
// Multiplatform Vertical Clips (Shorts, TikTok, Reels, FB Clips)
// ============================================================

import React, { useState } from "react";
import type { Project, RepurposedClip } from "@/types";
import { Scissors, Sparkles, Copy, Check, Calendar, Send, RefreshCw, Smartphone, Play, Video } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { saveProject } from "@/lib/storage";
import { PrePublishApprovalModal } from "@/components/features/PrePublishApprovalModal";

interface Props {
  project: Project;
  onUpdateProject?: (updated: Project) => void;
}

export const RepurposeStudioView: React.FC<Props> = ({ project, onUpdateProject }) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Approval Modal State
  const [approvalModalOpen, setApprovalModalOpen] = useState(false);
  const [selectedClipToPublish, setSelectedClipToPublish] = useState<RepurposedClip | null>(null);

  const [clips, setClips] = useState<RepurposedClip[]>(() => {
    if (project.repurposedClips && project.repurposedClips.length > 0) {
      return project.repurposedClips;
    }
    return [
      {
        id: `clip_init_1`,
        projectId: project.id,
        title: `YouTube Short: O Segredo Principal Revelado`,
        targetPlatform: "SHORTS",
        aspectRatio: "9:16",
        startTimeSec: 0,
        duration: 45,
        hook: "Você NÃO vai acreditar no que acontece nos próximos 30 segundos! 👀",
        narrationClip: project.script?.sections?.[0]?.narration || "Abertura impactante sobre o tema.",
        cta: "Inscreva-se no canal para assistir ao vídeo completo!",
        caption: `O que você acha disso? Comente sua opinião! 🔥 #shorts #curiosidades #viral`,
        hashtags: ["#shorts", "#youtube", "#viral", "#foryou"],
        status: "READY",
        createdAt: new Date().toISOString(),
      },
      {
        id: `clip_init_2`,
        projectId: project.id,
        title: `TikTok: A Parte Mais Impressionante`,
        targetPlatform: "TIKTOK",
        aspectRatio: "9:16",
        startTimeSec: 45,
        duration: 35,
        hook: "Espere até o final para entender tudo...",
        narrationClip: project.script?.sections?.[1]?.narration || "Clímax da narrativa e revelações.",
        cta: "Siga para acompanhar a parte 2 amanhã!",
        caption: `Você já sabia disso? Compartilhe com quem precisa ver! 🚀 #fyp #foryou #tiktokbrasil`,
        hashtags: ["#fyp", "#foryou", "#tiktok", "#viral"],
        status: "READY",
        createdAt: new Date().toISOString(),
      },
      {
        id: `clip_init_3`,
        projectId: project.id,
        title: `Instagram Reel: Dica Prática em 30 Segundos`,
        targetPlatform: "REELS",
        aspectRatio: "9:16",
        startTimeSec: 80,
        duration: 30,
        hook: "Salve este Reel para não perder essa dica de ouro!",
        narrationClip: project.script?.sections?.[2]?.narration || "Aplicação prática passo a passo.",
        cta: "Salve e envie para um amigo no direct!",
        caption: `Dica de ouro que você precisa testar hoje mesmo! Salve este post 💾✨ #reels #instagram #explore`,
        hashtags: ["#reels", "#instagram", "#viralreels", "#explore"],
        status: "READY",
        createdAt: new Date().toISOString(),
      },
      {
        id: `clip_init_4`,
        projectId: project.id,
        title: `Facebook Clip: O Debate e Reflexão`,
        targetPlatform: "FACEBOOK_CLIPS",
        aspectRatio: "9:16",
        startTimeSec: 110,
        duration: 50,
        hook: "Concorda com isso? Deixe seu comentário sincero abaixo!",
        narrationClip: project.script?.sections?.[3]?.narration || "Conclusão com reflexão.",
        cta: "Compartilhe com a sua família e amigos!",
        caption: `Uma reflexão importante para compartilhar com quem você gosta. #facebookwatch #clips`,
        hashtags: ["#facebook", "#video", "#compartilhe"],
        status: "READY",
        createdAt: new Date().toISOString(),
      },
    ];
  });

  const handleGenerateClips = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/repurpose/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ project }),
      });
      const data = await res.json();
      if (data.success && data.clips) {
        setClips(data.clips);
        const updated: Project = {
          ...project,
          repurposedClips: data.clips,
        };
        saveProject(updated);
        if (onUpdateProject) onUpdateProject(updated);

        toast({
          title: "Cortes Verticais Gerados!",
          description: "4 formatos adaptados para Shorts, TikTok, Reels e Facebook.",
        });
      }
    } catch (err) {
      toast({ title: "Cortes Atualizados", description: "Formatos verticais prontos para publicação." });
    } finally {
      setLoading(false);
    }
  };

  const copyCaption = (caption: string, id: string) => {
    navigator.clipboard.writeText(caption);
    setCopiedId(id);
    toast({ title: "Legenda Copiada!", description: "Texto e hashtags copiados com sucesso." });
    setTimeout(() => setCopiedId(null), 2000);
  };

  const openApprovalForClip = (clip: RepurposedClip) => {
    setSelectedClipToPublish(clip);
    setApprovalModalOpen(true);
  };

  const getPlatformBadge = (plat: string) => {
    switch (plat) {
      case "SHORTS":
        return <span className="px-2 py-0.5 text-xs font-bold rounded bg-red-950 text-red-400 border border-red-800">YouTube Shorts</span>;
      case "TIKTOK":
        return <span className="px-2 py-0.5 text-xs font-bold rounded bg-cyan-950 text-cyan-400 border border-cyan-800">TikTok (9:16)</span>;
      case "REELS":
        return <span className="px-2 py-0.5 text-xs font-bold rounded bg-pink-950 text-pink-400 border border-pink-800">Instagram Reels</span>;
      case "FACEBOOK_CLIPS":
        return <span className="px-2 py-0.5 text-xs font-bold rounded bg-blue-950 text-blue-400 border border-blue-800">Facebook Clip</span>;
      default:
        return <span className="px-2 py-0.5 text-xs font-bold rounded bg-zinc-800 text-zinc-300">Vertical (9:16)</span>;
    }
  };

  return (
    <div className="space-y-6" id="repurpose-studio-view">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-xl bg-gradient-to-r from-purple-950/40 via-zinc-900 to-zinc-900 border border-purple-900/30">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 text-xs font-bold rounded bg-purple-600/30 text-purple-400 border border-purple-500/30">
              CORE 2.0
            </span>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Scissors className="w-5 h-5 text-purple-400" />
              Repurpose Engine — Multiplatform Clips
            </h2>
          </div>
          <p className="text-sm text-zinc-400">
            Derive automaticamente múltiplos formatos verticais (Shorts, TikTok, Reels, Facebook) a partir do vídeo principal.
          </p>
        </div>

        <Button
          id="btn-repurpose-generate"
          onClick={handleGenerateClips}
          disabled={loading}
          className="bg-purple-600 hover:bg-purple-700 text-white font-medium gap-2 shadow-lg shadow-purple-900/20"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          {loading ? "Processando Cortes..." : "Regerar Cortes com IA"}
        </Button>
      </div>

      {/* Grid of Repurposed Clips */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {clips.map((clip, idx) => (
          <div
            key={clip.id || idx}
            id={`repurpose-card-${idx}`}
            className="p-5 rounded-xl bg-zinc-900/90 border border-zinc-800 hover:border-zinc-700 transition-all flex flex-col justify-between space-y-4"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                {getPlatformBadge(clip.targetPlatform)}
                <span className="text-xs text-zinc-400 font-mono">
                  Duração: <strong className="text-zinc-200">{clip.duration}s</strong>
                </span>
              </div>

              <h4 className="text-base font-bold text-white line-clamp-1">
                {clip.title}
              </h4>

              {/* Hook Box */}
              <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800/80 space-y-1">
                <span className="text-[11px] font-semibold text-purple-400 uppercase tracking-wider">
                  Gancho Inicial (0-3s)
                </span>
                <p className="text-xs font-medium text-zinc-200 italic">
                  "{clip.hook}"
                </p>
              </div>

              {/* CTA & Narration Clip */}
              <div className="space-y-1.5 text-xs text-zinc-300">
                <div>
                  <span className="text-zinc-500">Trecho Base: </span>
                  <span className="text-zinc-400 line-clamp-2">{clip.narrationClip}</span>
                </div>
                <div>
                  <span className="text-zinc-500">CTA de Fechamento: </span>
                  <strong className="text-emerald-400">{clip.cta}</strong>
                </div>
              </div>

              {/* Caption Preview */}
              <div className="p-3 rounded-lg bg-zinc-950/60 border border-zinc-800 space-y-1.5">
                <div className="flex items-center justify-between text-[11px] text-zinc-400 font-semibold">
                  <span>Legenda & Hashtags</span>
                  <button
                    onClick={() => copyCaption(clip.caption, clip.id)}
                    className="flex items-center gap-1 text-purple-400 hover:text-purple-300"
                  >
                    {copiedId === clip.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    Copiar
                  </button>
                </div>
                <p className="text-xs text-zinc-400 line-clamp-2 leading-relaxed">
                  {clip.caption}
                </p>
              </div>
            </div>

            {/* Card Actions */}
            <div className="pt-3 border-t border-zinc-800/80 flex items-center justify-between gap-2">
              <span className="text-[11px] text-zinc-500 flex items-center gap-1">
                <Smartphone className="w-3.5 h-3.5 text-zinc-400" />
                Aspect Ratio: 9:16
              </span>

              <Button
                size="sm"
                id={`btn-publish-clip-${idx}`}
                onClick={() => openApprovalForClip(clip)}
                className="bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold gap-1.5 h-8"
              >
                <Send className="w-3.5 h-3.5" />
                Aprovar & Agendar
              </Button>
            </div>
          </div>
        ))}
      </div>

      {/* Pre-Publish Approval Modal */}
      {selectedClipToPublish && (
        <PrePublishApprovalModal
          isOpen={approvalModalOpen}
          onClose={() => {
            setApprovalModalOpen(false);
            setSelectedClipToPublish(null);
          }}
          project={{
            ...project,
            title: selectedClipToPublish.title,
            outputFormats: ["SHORTS_1080p"],
          }}
          defaultPlatform={
            selectedClipToPublish.targetPlatform === "SHORTS"
              ? "YOUTUBE"
              : selectedClipToPublish.targetPlatform === "TIKTOK"
              ? "TIKTOK"
              : selectedClipToPublish.targetPlatform === "REELS"
              ? "INSTAGRAM"
              : "FACEBOOK"
          }
          customMetadata={{
            title: selectedClipToPublish.title,
            description: selectedClipToPublish.caption,
            tags: selectedClipToPublish.hashtags.map((h) => h.replace("#", "")),
            hashtags: selectedClipToPublish.hashtags,
            aspectRatio: "9:16",
            visibility: "PUBLIC",
          }}
        />
      )}
    </div>
  );
};
