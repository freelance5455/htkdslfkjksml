import { useState } from "react";
import type { Timeline, TimelineTrack, TrackType } from "@/types";
import { cn, formatTime } from "@/lib/utils";
import { Volume2, VolumeX, Play, Pause } from "lucide-react";

interface TimelineEditorProps {
  timeline?: Timeline;
  totalDuration?: number;
}

const TRACK_COLORS: Record<TrackType, string> = {
  VIDEO: "bg-studio-blue",
  IMAGE: "bg-studio-purple",
  VOICE: "bg-studio-green",
  MUSIC: "bg-studio-gold",
  SFX: "bg-studio-orange",
  TEXT: "bg-white/40",
  SUBTITLE: "bg-studio-pink",
};

const MOCK_TRACKS: Array<{ type: TrackType; name: string; clips: Array<{ start: number; duration: number; label: string }> }> = [
  {
    type: "VIDEO", name: "Vídeo / Imagens",
    clips: [
      { start: 0, duration: 30, label: "Cena 1 — Abertura" },
      { start: 32, duration: 60, label: "Cena 2 — Desenvolvimento" },
      { start: 94, duration: 30, label: "Cena 3 — Conclusão" },
    ],
  },
  {
    type: "VOICE", name: "Narração",
    clips: [
      { start: 2, duration: 25, label: "Narração 1" },
      { start: 35, duration: 55, label: "Narração 2" },
      { start: 96, duration: 25, label: "CTA Final" },
    ],
  },
  {
    type: "MUSIC", name: "Música de Fundo",
    clips: [{ start: 0, duration: 124, label: "Trilha Principal" }],
  },
  {
    type: "SFX", name: "Efeitos Sonoros",
    clips: [
      { start: 0, duration: 3, label: "Intro SFX" },
      { start: 30, duration: 2, label: "Transição" },
      { start: 93, duration: 2, label: "Outro SFX" },
    ],
  },
  {
    type: "SUBTITLE", name: "Legendas",
    clips: [
      { start: 2, duration: 25, label: "Legenda 1" },
      { start: 35, duration: 55, label: "Legenda 2" },
    ],
  },
];

export default function TimelineEditor({ totalDuration = 124 }: TimelineEditorProps) {
  const [playing, setPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [mutedTracks, setMutedTracks] = useState<Set<string>>(new Set());

  const toggleMute = (trackName: string) => {
    setMutedTracks((prev) => {
      const next = new Set(prev);
      if (next.has(trackName)) next.delete(trackName);
      else next.add(trackName);
      return next;
    });
  };

  const tickCount = Math.floor(totalDuration / 10);

  return (
    <div className="studio-panel overflow-hidden animate-fade-in">
      {/* Transport controls */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-studio-border">
        <button
          onClick={() => setPlaying(!playing)}
          className="w-8 h-8 rounded-full bg-studio-blue flex items-center justify-center hover:bg-studio-blue-dim transition-colors"
        >
          {playing ? <Pause className="w-3.5 h-3.5 text-white" /> : <Play className="w-3.5 h-3.5 text-white ml-0.5" />}
        </button>
        <span className="text-sm font-mono text-studio-blue">{formatTime(currentTime)}</span>
        <span className="text-sm text-studio-text-muted">/</span>
        <span className="text-sm font-mono text-studio-text-muted">{formatTime(totalDuration)}</span>
        <div className="flex-1 h-1 bg-studio-border rounded-full mx-2">
          <div
            className="h-1 bg-studio-blue rounded-full transition-all"
            style={{ width: `${(currentTime / totalDuration) * 100}%` }}
          />
        </div>
        <span className="text-xs text-studio-text-muted">Timeline Editor</span>
      </div>

      {/* Timeline ruler */}
      <div className="flex ml-32 pl-2 border-b border-studio-border overflow-hidden">
        <div className="flex-1 flex">
          {Array.from({ length: tickCount + 1 }).map((_, i) => (
            <div
              key={i}
              className="shrink-0 text-xs text-studio-text-muted border-l border-studio-border/40 pl-0.5"
              style={{ width: `${100 / tickCount}%` }}
            >
              {formatTime(i * 10)}
            </div>
          ))}
        </div>
      </div>

      {/* Tracks */}
      <div className="overflow-x-auto">
        {MOCK_TRACKS.map((track) => {
          const muted = mutedTracks.has(track.name);
          return (
            <div key={track.name} className="flex items-center timeline-track min-h-[44px]">
              {/* Track header */}
              <div className="w-32 shrink-0 flex items-center justify-between px-2 pr-3 border-r border-studio-border">
                <span className={cn("text-xs font-medium truncate", muted ? "text-studio-text-muted" : "text-studio-text-dim")}>
                  {track.name}
                </span>
                <button
                  onClick={() => toggleMute(track.name)}
                  className="p-1 rounded transition-colors hover:bg-studio-panel shrink-0"
                >
                  {muted
                    ? <VolumeX className="w-3 h-3 text-studio-text-muted" />
                    : <Volume2 className={cn("w-3 h-3", TRACK_COLORS[track.type].replace("bg-", "text-"))} />
                  }
                </button>
              </div>

              {/* Clips area */}
              <div className="flex-1 relative h-10 px-1 py-1">
                {track.clips.map((clip, i) => (
                  <div
                    key={i}
                    className={cn(
                      "absolute top-1 bottom-1 rounded flex items-center px-2 cursor-pointer hover:brightness-110 transition-all overflow-hidden",
                      muted ? "bg-studio-border" : TRACK_COLORS[track.type],
                      muted ? "opacity-40" : "opacity-80"
                    )}
                    style={{
                      left: `${(clip.start / totalDuration) * 100}%`,
                      width: `${(clip.duration / totalDuration) * 100}%`,
                    }}
                    title={clip.label}
                  >
                    <span className="text-xs text-white font-medium truncate whitespace-nowrap">
                      {clip.label}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
