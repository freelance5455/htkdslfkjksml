// ============================================================
// AI CREATOR STUDIO — CORE 3.0 BUDGET & SAFETY MODAL
// Spend tracker, cost breakdown, and financial circuit breakers
// ============================================================

import { useState } from "react";
import {
  DollarSign, ShieldAlert, CheckCircle2, AlertTriangle,
  CreditCard, RefreshCw, X, Sliders, TrendingDown, Layers
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { BudgetStatus } from "@/types/core3";
import { getBudgetStatus, getBudgetLogs, saveBudgetConfig, getBudgetConfig } from "@/lib/core3/budgetStore";

interface BudgetSafetyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function BudgetSafetyModal({ isOpen, onClose }: BudgetSafetyModalProps) {
  const [budget, setBudget] = useState<BudgetStatus>(getBudgetStatus());
  const [logs] = useState(getBudgetLogs());
  const [dailyLimit, setDailyLimit] = useState(budget.dailyLimitUsd);

  if (!isOpen) return null;

  const handleUpdateLimit = () => {
    const currentCfg = getBudgetConfig();
    saveBudgetConfig({ ...currentCfg, dailyLimitUsd: dailyLimit });
    setBudget(getBudgetStatus());
  };

  const dailyPct = Math.min(100, Math.round((budget.dailyUsedUsd / budget.dailyLimitUsd) * 100));

  // Provider breakdown calculations
  const breakdownByProvider: Record<string, number> = {};
  for (const log of logs) {
    const p = log.provider || "OUTRO";
    const cost = log.actualCostUsd || log.estimatedCostUsd;
    breakdownByProvider[p] = (breakdownByProvider[p] || 0) + cost;
  }

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="studio-card w-full max-w-2xl max-h-[90vh] flex flex-col border border-studio-border shadow-2xl overflow-hidden animate-fadeIn">
        {/* Header */}
        <div className="p-5 border-b border-studio-border flex items-center justify-between bg-studio-panel shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-studio-green to-teal-600 flex items-center justify-center text-white font-bold shadow-md">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-studio-text font-display">
                Orçamento Seguro & Gastos de IA
              </h2>
              <p className="text-xs text-studio-text-muted">
                Controle de custos em tempo real com auto-pause financeiro
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-studio-text-muted hover:text-studio-text hover:bg-studio-border transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* Main Budget Status Card */}
          <div className="p-5 rounded-2xl bg-studio-panel border border-studio-border space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase text-studio-text-muted">
                  Gasto Diário Atual
                </span>
                <p className="text-2xl font-bold text-studio-text font-display mt-0.5">
                  ${budget.dailyUsedUsd.toFixed(2)}{" "}
                  <span className="text-sm font-normal text-studio-text-muted">
                    / ${budget.dailyLimitUsd.toFixed(2)} USD
                  </span>
                </p>
              </div>

              <span className={cn(
                "px-3 py-1 rounded-full text-xs font-mono font-bold",
                budget.isLimitReached
                  ? "bg-studio-red/20 text-studio-red"
                  : "bg-studio-green/20 text-studio-green"
              )}>
                {budget.isLimitReached ? "LIMITE ATINGIDO (PAUSADO)" : "ORÇAMENTO SEGURO"}
              </span>
            </div>

            {/* Daily Bar */}
            <div className="space-y-1">
              <div className="w-full h-2 rounded-full bg-studio-bg overflow-hidden">
                <div
                  className={cn(
                    "h-full transition-all",
                    dailyPct > 80 ? "bg-studio-red" : "bg-gradient-to-r from-studio-green to-studio-blue"
                  )}
                  style={{ width: `${dailyPct}%` }}
                />
              </div>
              <div className="flex justify-between text-[10px] text-studio-text-muted font-mono">
                <span>0%</span>
                <span>{dailyPct}% consumido</span>
                <span>100%</span>
              </div>
            </div>
          </div>

          {/* Breakdown by Provider */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-studio-text font-display uppercase tracking-wider">
              Distribuição por Provedores
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {Object.entries(breakdownByProvider).map(([provider, spent]) => (
                <div key={provider} className="p-3 rounded-xl bg-studio-panel border border-studio-border text-center">
                  <span className="text-[10px] font-bold uppercase text-studio-text-muted">{provider}</span>
                  <p className="text-sm font-bold text-studio-text font-mono mt-1">${spent.toFixed(2)}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Limit Configurator */}
          <div className="p-4 rounded-xl bg-studio-surface border border-studio-border space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-studio-text flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-studio-blue" />
                Ajustar Limite Diário de Segurança (USD)
              </span>
              <span className="text-xs font-bold font-mono text-studio-blue">${dailyLimit}</span>
            </div>

            <input
              type="range"
              min={5}
              max={100}
              step={5}
              value={dailyLimit}
              onChange={(e) => setDailyLimit(Number(e.target.value))}
              className="w-full accent-studio-blue cursor-pointer"
            />

            <div className="flex justify-end">
              <button onClick={handleUpdateLimit} className="btn-primary text-xs py-1.5 px-3">
                Salvar Limite
              </button>
            </div>
          </div>

          {/* Ledger logs */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-studio-text font-display uppercase tracking-wider">
              Extrato de Operações Recentes
            </h3>

            <div className="space-y-1.5 max-h-36 overflow-y-auto">
              {logs.slice(0, 5).map((entry) => (
                <div key={entry.id} className="text-xs p-2.5 rounded-lg bg-studio-panel border border-studio-border flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-studio-text">{entry.action}</p>
                    <p className="text-[10px] text-studio-text-muted font-mono">{entry.model} · {entry.provider}</p>
                  </div>
                  <span className="font-mono font-bold text-studio-green">${entry.actualCostUsd.toFixed(3)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-studio-border bg-studio-panel flex items-center justify-between shrink-0">
          <p className="text-[11px] text-studio-text-muted">
            Circuit breaker ativo: suspende automaticamente novos renders se o limite for atingido.
          </p>
          <button onClick={onClose} className="btn-secondary text-xs py-2 px-4">
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
}
