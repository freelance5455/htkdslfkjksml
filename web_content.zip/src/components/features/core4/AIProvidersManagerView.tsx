import { useState, useEffect } from "react";
import {
  Activity,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  HelpCircle,
  RefreshCw,
  Key,
  ShieldCheck,
  Zap,
  Sliders,
  Server,
  Play,
  Cpu,
  Layers,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface SystemHealthData {
  gemini: "OPERATIONAL" | "DEGRADED" | "OFFLINE" | "UNCONFIGURED";
  imageEngine: "OPERATIONAL" | "DEGRADED" | "OFFLINE" | "UNCONFIGURED";
  videoEngine: "OPERATIONAL" | "DEGRADED" | "OFFLINE" | "UNCONFIGURED";
  voiceEngine: "OPERATIONAL" | "DEGRADED" | "OFFLINE" | "UNCONFIGURED";
  musicEngine: "OPERATIONAL" | "DEGRADED" | "OFFLINE" | "UNCONFIGURED";
  avatarEngine: "OPERATIONAL" | "DEGRADED" | "OFFLINE" | "UNCONFIGURED";
  storage: "OPERATIONAL" | "DEGRADED" | "OFFLINE" | "UNCONFIGURED";
  database: "OPERATIONAL" | "DEGRADED" | "OFFLINE" | "UNCONFIGURED";
  renderEngine: "OPERATIONAL" | "DEGRADED" | "OFFLINE" | "UNCONFIGURED";
  lastChecked: string;
  details: Record<
    string,
    {
      status: string;
      provider: string;
      details: string;
      latencyMs?: number;
    }
  >;
}

interface ProviderConfig {
  id: string;
  name: string;
  category: string;
  model: string;
  apiEndpoint?: string;
  hasKey: boolean;
  maskedKey: string;
  status: string;
  priority: number;
  rateLimitPerMin?: number;
  isFallback: boolean;
  capabilities: string[];
  lastTestedAt?: string;
  latencyMs?: number;
  notes?: string;
}

export default function AIProvidersManagerView() {
  const [health, setHealth] = useState<SystemHealthData | null>(null);
  const [providers, setProviders] = useState<ProviderConfig[]>([]);
  const [loading, setLoading] = useState(true);
  const [testingId, setTestingId] = useState<string | null>(null);
  const [testResults, setTestResults] = useState<Record<string, { valid: boolean; message: string; latencyMs?: number }>>({});
  const [editingProvider, setEditingProvider] = useState<ProviderConfig | null>(null);
  const [apiKeyInput, setApiKeyInput] = useState("");
  const [saving, setSaving] = useState(false);

  const fetchHealthAndProviders = async () => {
    setLoading(true);
    try {
      const [hRes, pRes] = await Promise.all([
        fetch("/api/ai/health"),
        fetch("/api/ai/providers"),
      ]);

      if (hRes.ok) {
        const hData = await hRes.json();
        if (hData.success) setHealth(hData.health);
      }

      if (pRes.ok) {
        const pData = await pRes.json();
        if (pData.success) setProviders(pData.providers);
      }
    } catch (err) {
      console.error("Erro ao carregar dados de IA:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHealthAndProviders();
  }, []);

  const handleTestConnection = async (id: string) => {
    setTestingId(id);
    try {
      const res = await fetch(`/api/ai/providers/${id}/test`, { method: "POST" });
      const data = await res.json();
      setTestResults((prev) => ({
        ...prev,
        [id]: {
          valid: data.result?.valid ?? false,
          message: data.result?.message || "Sem resposta do provedor",
          latencyMs: data.result?.latencyMs,
        },
      }));
      await fetchHealthAndProviders();
    } catch (err) {
      setTestResults((prev) => ({
        ...prev,
        [id]: {
          valid: false,
          message: err instanceof Error ? err.message : "Erro ao testar conexão",
        },
      }));
    } finally {
      setTestingId(null);
    }
  };

  const handleSaveConfig = async () => {
    if (!editingProvider) return;
    setSaving(true);
    try {
      const body: Record<string, unknown> = {
        model: editingProvider.model,
        priority: editingProvider.priority,
      };
      if (apiKeyInput.trim()) {
        body.apiKey = apiKeyInput.trim();
      }

      const res = await fetch(`/api/ai/providers/${editingProvider.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (res.ok) {
        setEditingProvider(null);
        setApiKeyInput("");
        await fetchHealthAndProviders();
      }
    } catch (err) {
      console.error("Erro ao salvar configuração do provedor:", err);
    } finally {
      setSaving(false);
    }
  };

  const renderStatusBadge = (status: string) => {
    switch (status) {
      case "OPERATIONAL":
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            🟢 Operacional
          </span>
        );
      case "DEGRADED":
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
            <span className="w-2 h-2 rounded-full bg-amber-500" />
            🟡 Limitado
          </span>
        );
      case "OFFLINE":
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
            <span className="w-2 h-2 rounded-full bg-rose-500" />
            🔴 Offline
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 border border-slate-200">
            ⚪ Não configurado
          </span>
        );
    }
  };

  const subsystemList = [
    { key: "gemini", label: "Google Gemini 3.7 Flash", icon: Zap, cat: "Texto & Roteiro" },
    { key: "imageEngine", label: "AI Studio Image Engine", icon: Layers, cat: "Imagens 4K" },
    { key: "videoEngine", label: "AI Studio Video Engine", icon: Play, cat: "Vídeo 1080p MP4" },
    { key: "voiceEngine", label: "AI Studio Voice Engine", icon: Activity, cat: "Voz Neural TTS" },
    { key: "musicEngine", label: "AI Studio Music Engine", icon: Cpu, cat: "Trilhas & Soundscapes" },
    { key: "avatarEngine", label: "AI Studio Avatar Engine", icon: ShieldCheck, cat: "Apresentador & Lip-Sync" },
    { key: "storage", label: "Cloud & Local Storage", icon: Server, cat: "Armazenamento Persistente" },
    { key: "database", label: "Database Engine", icon: Server, cat: "Banco de Dados Atômico" },
    { key: "renderEngine", label: "FFmpeg Render Engine", icon: Sliders, cat: "Renderizador Final" },
  ];

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-white rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">AI System Health & Provedores</h2>
              <p className="text-xs text-slate-500">
                Monitoramento em tempo real dos 9 motores de IA e orquestrador multimodal
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={fetchHealthAndProviders}
          disabled={loading}
          className="inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-xl transition-colors disabled:opacity-50"
        >
          <RefreshCw className={cn("w-3.5 h-3.5", loading && "animate-spin")} />
          Atualizar Diagnóstico
        </button>
      </div>

      {/* 9 Subsystems Matrix (Section 27) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Server className="w-4 h-4 text-blue-600" />
            Painel Geral de Saúde dos Subsistemas (9 Motores)
          </h3>
          <span className="text-xs text-slate-500 font-mono">
            Última verificação: {health?.lastChecked ? new Date(health.lastChecked).toLocaleTimeString() : "--"}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {subsystemList.map((sub) => {
            const statusKey = sub.key as keyof SystemHealthData;
            const status = (health && typeof health[statusKey] === "string" ? health[statusKey] : "UNCONFIGURED") as string;
            const details = health?.details?.[sub.key];
            const Icon = sub.icon;

            return (
              <div
                key={sub.key}
                className="p-3.5 rounded-xl border border-slate-100 bg-slate-50/50 hover:bg-slate-50 transition-colors flex flex-col justify-between space-y-2"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-blue-100/50 text-blue-600 flex items-center justify-center shrink-0">
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-800">{sub.label}</h4>
                      <p className="text-[11px] text-slate-500">{sub.cat}</p>
                    </div>
                  </div>
                  {renderStatusBadge(status)}
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                  <span className="truncate max-w-[180px]" title={details?.details || ""}>
                    {details?.details || "Status verificado"}
                  </span>
                  {details?.latencyMs !== undefined && (
                    <span className="font-mono text-[10px] text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded">
                      {details.latencyMs}ms
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* AI Providers Config & Management (Section 4 & 5) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-blue-600" />
              Provedores de Inteligência Artificial Conectados
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Gerencie modelos, chaves de API com mascaramento seguro e teste latências em tempo real
            </p>
          </div>
        </div>

        <div className="space-y-3">
          {providers.map((p) => {
            const test = testResults[p.id];
            const isTesting = testingId === p.id;

            return (
              <div
                key={p.id}
                className="p-4 rounded-xl border border-slate-200 bg-white hover:border-blue-200 transition-all space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-xs">
                      {p.priority}º
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-slate-900">{p.name}</h4>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                          {p.category}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 font-mono mt-0.5">
                        Modelo: <span className="text-blue-600 font-semibold">{p.model}</span>
                        {p.maskedKey && (
                          <span className="ml-3 text-slate-400">
                            Chave: <span className="font-mono text-slate-700">{p.maskedKey}</span>
                          </span>
                        )}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {renderStatusBadge(p.status)}

                    <button
                      onClick={() => handleTestConnection(p.id)}
                      disabled={isTesting}
                      className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5 disabled:opacity-50"
                    >
                      <RefreshCw className={cn("w-3 h-3", isTesting && "animate-spin")} />
                      {isTesting ? "Testando..." : "Testar Conexão"}
                    </button>

                    <button
                      onClick={() => {
                        setEditingProvider(p);
                        setApiKeyInput("");
                      }}
                      className="px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors flex items-center gap-1.5"
                    >
                      <Key className="w-3 h-3" />
                      Configurar
                    </button>
                  </div>
                </div>

                {/* Capabilities Chips */}
                <div className="flex flex-wrap gap-1.5">
                  {p.capabilities.map((cap, i) => (
                    <span
                      key={i}
                      className="text-[10px] px-2 py-0.5 rounded bg-slate-50 text-slate-600 border border-slate-100"
                    >
                      {cap}
                    </span>
                  ))}
                </div>

                {/* Connection Test Result Feedback */}
                {test && (
                  <div
                    className={cn(
                      "p-3 rounded-lg text-xs flex items-center justify-between gap-2 border",
                      test.valid
                        ? "bg-emerald-50 text-emerald-800 border-emerald-200"
                        : "bg-rose-50 text-rose-800 border-rose-200"
                    )}
                  >
                    <div className="flex items-center gap-2">
                      {test.valid ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      ) : (
                        <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                      )}
                      <span>{test.message}</span>
                    </div>
                    {test.latencyMs !== undefined && (
                      <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-white border border-slate-200 shrink-0">
                        {test.latencyMs} ms
                      </span>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Edit Provider Modal */}
      {editingProvider && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-900">
                Configurar {editingProvider.name}
              </h3>
              <button
                onClick={() => setEditingProvider(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Modelo de IA
                </label>
                <input
                  type="text"
                  value={editingProvider.model}
                  onChange={(e) =>
                    setEditingProvider({ ...editingProvider, model: e.target.value })
                  }
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Prioridade na Cadeia de Fallback (1 = Primeira opção)
                </label>
                <input
                  type="number"
                  min="1"
                  max="10"
                  value={editingProvider.priority}
                  onChange={(e) =>
                    setEditingProvider({
                      ...editingProvider,
                      priority: parseInt(e.target.value) || 1,
                    })
                  }
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nova Chave de API (Secret Key)
                </label>
                <input
                  type="password"
                  value={apiKeyInput}
                  onChange={(e) => setApiKeyInput(e.target.value)}
                  placeholder={editingProvider.hasKey ? "•••••••••••• (Inalterada)" : "Insira a chave da API..."}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500 font-mono"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  As chaves são gravadas estritamente no backend seguro e nunca são expostas ao cliente.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                onClick={() => setEditingProvider(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleSaveConfig}
                disabled={saving}
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors disabled:opacity-50"
              >
                {saving ? "Salvando..." : "Salvar Configuração"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
