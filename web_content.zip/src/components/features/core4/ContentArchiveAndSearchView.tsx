import { useState } from "react";
import type { ContentArchiveRecord, AISearchResult } from "@/types/core4";
import { searchContentArchive } from "@/lib/core4/contentArchiveEngine";
import { cn } from "@/lib/utils";
import {
  Search, Archive, Sparkles, Filter, Eye, TrendingUp,
  Share2, Tag, Calendar, Globe2, BookOpen
} from "lucide-react";

export default function ContentArchiveAndSearchView() {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResult, setSearchResult] = useState<AISearchResult>(searchContentArchive(""));
  const [activeFilterTag, setActiveFilterTag] = useState<string>("ALL");

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    const result = searchContentArchive(query);
    setSearchResult(result);
  };

  const handleQuickTagClick = (tag: string) => {
    setActiveFilterTag(tag);
    handleSearch(tag === "ALL" ? "" : tag);
  };

  return (
    <div className="space-y-6">
      {/* Header & AI Search Input */}
      <div className="bg-studio-surface p-6 rounded-2xl border border-studio-border space-y-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-studio-gold/10 text-studio-gold border border-studio-gold/30 uppercase">
              CORE 4.0 · ACERVO & BUSCA IA
            </span>
          </div>
          <h2 className="text-xl font-bold text-studio-text font-display">
            Acervo Inteligente de Conteúdos
          </h2>
          <p className="text-xs text-studio-text-muted mt-1">
            Busca semântica em linguagem natural por personagens, temas, formatos, fórmulas e métricas históricas.
          </p>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="w-5 h-5 text-studio-text-muted absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => handleSearch(e.target.value)}
            placeholder="Ex: 'Vídeos com o Pipoca sobre vogais', 'Conteúdos com mais de 75% de retenção', 'Robôs'..."
            className="input-studio text-sm pl-11 py-3"
          />
        </div>

        {/* Quick Filter Chips */}
        <div className="flex flex-wrap gap-2 pt-1">
          {["ALL", "Pipoca", "Luna", "Alfabetização", "Vogais", "Natureza", "IA", "Robótica"].map((tag) => (
            <button
              key={tag}
              onClick={() => handleQuickTagClick(tag)}
              className={cn(
                "text-xs px-3 py-1 rounded-full border transition-colors",
                activeFilterTag === tag
                  ? "bg-studio-gold text-black font-semibold border-studio-gold"
                  : "bg-studio-panel border-studio-border text-studio-text-muted hover:text-studio-text hover:border-studio-border-light"
              )}
            >
              {tag === "ALL" ? "Todos os Conteúdos" : `#${tag}`}
            </button>
          ))}
        </div>
      </div>

      {/* AI Intent & Insights Summary */}
      {searchResult.insightsFound.length > 0 && (
        <div className="p-4 rounded-xl bg-studio-panel border border-studio-border space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-studio-gold">
            <Sparkles className="w-4 h-4" />
            Interpretação da IA: {searchResult.interpretedIntent}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs text-studio-text-muted">
            {searchResult.insightsFound.map((ins, idx) => (
              <div key={idx} className="flex items-center gap-2 bg-studio-surface/60 p-2 rounded-lg border border-studio-border/60">
                <span className="w-1.5 h-1.5 rounded-full bg-studio-gold shrink-0" />
                <span>{ins}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Records Catalog */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {searchResult.matchingRecords.map((rec) => (
          <div
            key={rec.id}
            className="studio-card p-4 space-y-3 flex flex-col justify-between hover:border-studio-gold/50 transition-all group shadow-sm"
          >
            <div className="space-y-3">
              <div className="relative rounded-xl overflow-hidden aspect-video bg-black/40 border border-studio-border/60">
                <img
                  src={rec.thumbnailUrl}
                  alt={rec.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/80 backdrop-blur-xs text-[10px] font-mono text-studio-gold border border-studio-gold/30">
                  {rec.format}
                </div>
              </div>

              <div>
                <span className="text-[10px] font-mono text-studio-gold font-bold uppercase">
                  {rec.universeName || "Universo Geral"}
                </span>
                <h3 className="text-sm font-bold text-studio-text group-hover:text-studio-gold transition-colors leading-snug">
                  {rec.title}
                </h3>
              </div>

              <p className="text-xs text-studio-text-muted line-clamp-2 leading-relaxed">
                {rec.summary}
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-1">
                {rec.tags.map((t, idx) => (
                  <span key={idx} className="text-[10px] px-1.5 py-0.5 rounded-xs bg-studio-surface text-studio-text-dim border border-studio-border/60">
                    #{t}
                  </span>
                ))}
              </div>
            </div>

            {/* Metrics Footer */}
            <div className="pt-3 border-t border-studio-border/60 flex items-center justify-between text-xs font-mono">
              <span className="flex items-center gap-1 text-emerald-400 font-bold">
                <Eye className="w-3.5 h-3.5" />
                {(rec.views / 1000).toFixed(1)}k views
              </span>
              <span className="text-cyan-400 font-bold">
                {rec.retentionPercent}% Retenção
              </span>
              <span className="text-studio-gold font-bold">
                {rec.ctr}% CTR
              </span>
            </div>
          </div>
        ))}
      </div>

      {searchResult.matchingRecords.length === 0 && (
        <div className="p-12 text-center border border-dashed border-studio-border rounded-2xl bg-studio-surface/40">
          <Archive className="w-8 h-8 text-studio-text-muted mx-auto mb-2 opacity-50" />
          <p className="text-sm font-semibold text-studio-text">Nenhum conteúdo encontrado para esta busca</p>
          <p className="text-xs text-studio-text-muted mt-1">Tente pesquisar por termos como "Pipoca", "Letrinhas" ou "Robôs".</p>
        </div>
      )}
    </div>
  );
}
