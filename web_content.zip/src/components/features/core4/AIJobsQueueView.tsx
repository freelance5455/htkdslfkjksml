import { useState, useEffect, useRef } from "react";
import {
  Layers,
  Play,
  RotateCcw,
  XCircle,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Radio,
  Sparkles,
  RefreshCw,
  Image as ImageIcon,
  Video as VideoIcon,
  Mic,
  Music as MusicIcon,
  User,
  Film,
  FileText,
  ExternalLink,
  Plus,
} from "lucide-react";
import { cn } from "@/lib/utils";

export interface AIJob {
  id: string;
  type: "TEXT" | "IMAGE" | "VIDEO" | "VOICE" | "MUSIC" | "AVATAR" | "RENDER";
  status: "PENDING" | "RUNNING" | "COMPLETED" | "FAILED" | "CANCELLED";
  progress: number;
  stepLabel?: string;
  input: Record<string, unknown>;
  output?: {
    url?: string;
    assetId?: string;
    text?: string;
    metadata?: Record<string, unknown>;
    [key: string]: unknown;
  };
  error?: string;
  createdAt: string;
  startedAt?: string;
  completedAt?: string;
  projectId?: string;
  model?: string;
  providerId?: string;
  retryCount?: number;
}

export default function AIJobsQueueView() {
  const [jobs, setJobs] = useState<AIJob[]>([]);
  const [loading, setLoading] = useState(true);
  const [sseConnected, setSseConnected] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [typeFilter, setTypeFilter] = useState<string>("ALL");
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  // Quick dispatch modal state
  const [showDispatchModal, setShowDispatchModal] = useState(false);
  const [dispatchType, setDispatchType] = useState<AIJob["type"]>("IMAGE");
  const [dispatchPrompt, setDispatchPrompt] = useState("Paisagem cyberpunk cinematográfica com luz neon");
  const [dispatching, setDispatching] = useState(false);

  const eventSourceRef = useRef<EventSource | null>(null);

  // Fetch jobs
  const fetchJobs = async () => {
    try {
      const res = await fetch("/api/ai/jobs");
      const data = await res.json();
      if (data.success && Array.isArray(data.jobs)) {
        setJobs(data.jobs);
      }
    } catch (err) {
      console.error("[AIJobsQueue] Error fetching jobs:", err);
    } finally {
      setLoading(false);
    }
  };

  // SSE real-time connection
  useEffect(() => {
    fetchJobs();

    const connectSSE = () => {
      try {
        const es = new EventSource("/api/ai/jobs/events");
        eventSourceRef.current = es;

        es.onopen = () => {
          setSseConnected(true);
        };

        es.onmessage = (e) => {
          try {
            const payload = JSON.parse(e.data);
            if (!payload || !payload.event) return;

            if (payload.event === "job:created" && payload.job) {
              setJobs((prev) => {
                const exists = prev.some((j) => j.id === payload.job.id);
                if (exists) return prev.map((j) => (j.id === payload.job.id ? payload.job : j));
                return [payload.job, ...prev];
              });
            } else if (
              (payload.event === "job:progress" ||
                payload.event === "job:completed" ||
                payload.event === "job:failed" ||
                payload.event === "job:cancelled") &&
              payload.job
            ) {
              setJobs((prev) =>
                prev.map((j) => (j.id === payload.job.id ? payload.job : j))
              );
            } else if (payload.event === "job:deleted" && payload.payload?.id) {
              setJobs((prev) => prev.filter((j) => j.id !== payload.payload.id));
            }
          } catch (parseErr) {
            console.warn("[AIJobsQueue] SSE parse error:", parseErr);
          }
        };

        es.onerror = () => {
          setSseConnected(false);
          es.close();
          // Retry SSE in 5s
          setTimeout(connectSSE, 5000);
        };
      } catch (err) {
        console.warn("[AIJobsQueue] EventSource error:", err);
        setSseConnected(false);
      }
    };

    connectSSE();

    // Fallback polling interval every 4s to ensure synchronization
    const fallbackPoll = setInterval(fetchJobs, 4000);

    return () => {
      clearInterval(fallbackPoll);
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
    };
  }, []);

  // Cancel Job
  const handleCancel = async (id: string) => {
    setActionLoading(id);
    try {
      const res = await fetch(`/api/ai/jobs/${id}/cancel`, { method: "POST" });
      const data = await res.json();
      if (data.success) {
        await fetchJobs();
      }
    } catch (err) {
      console.error("Erro ao cancelar job:", err);
    } finally {
      setActionLoading(null);
    }
  };

  // Retry Job
  const handleRetry = async (id: string) => {
    setActionLoading(id);
    try {
      const res = await fetch(`/api/ai/jobs/${id}/retry`, { method: "POST" });
      const data = await res.json();
      if (data.success) {
        await fetchJobs();
      }
    } catch (err) {
      console.error("Erro ao reiniciar job:", err);
    } finally {
      setActionLoading(null);
    }
  };

  // Delete Job
  const handleDelete = async (id: string) => {
    setActionLoading(id);
    try {
      const res = await fetch(`/api/ai/jobs/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        setJobs((prev) => prev.filter((j) => j.id !== id));
      }
    } catch (err) {
      console.error("Erro ao excluir job:", err);
    } finally {
      setActionLoading(null);
    }
  };

  // Enqueue New Job
  const handleEnqueueNew = async () => {
    if (!dispatchPrompt.trim()) return;
    setDispatching(true);
    try {
      const res = await fetch("/api/ai/jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: dispatchType,
          input: {
            prompt: dispatchPrompt.trim(),
            text: dispatchPrompt.trim(),
            style: "CINEMATIC",
            aspectRatio: "16:9",
            duration: 6,
          },
        }),
      });
      const data = await res.json();
      if (data.success) {
        setShowDispatchModal(false);
        await fetchJobs();
      }
    } catch (err) {
      console.error("Erro ao enfileirar job:", err);
    } finally {
      setDispatching(false);
    }
  };

  // Filter jobs
  const filteredJobs = jobs.filter((job) => {
    if (statusFilter !== "ALL" && job.status !== statusFilter) return false;
    if (typeFilter !== "ALL" && job.type !== typeFilter) return false;
    return true;
  });

  const getJobIcon = (type: AIJob["type"]) => {
    switch (type) {
      case "IMAGE":
        return <ImageIcon className="w-4 h-4 text-emerald-400" />;
      case "VIDEO":
        return <VideoIcon className="w-4 h-4 text-purple-400" />;
      case "VOICE":
        return <Mic className="w-4 h-4 text-cyan-400" />;
      case "MUSIC":
        return <MusicIcon className="w-4 h-4 text-amber-400" />;
      case "AVATAR":
        return <User className="w-4 h-4 text-pink-400" />;
      case "RENDER":
        return <Film className="w-4 h-4 text-blue-400" />;
      default:
        return <FileText className="w-4 h-4 text-studio-gold" />;
    }
  };

  const getStatusBadge = (status: AIJob["status"]) => {
    switch (status) {
      case "RUNNING":
        return (
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-blue-500/20 text-blue-400 border border-blue-500/30">
            <RefreshCw className="w-3 h-3 animate-spin" />
            Processando
          </span>
        );
      case "PENDING":
        return (
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <Clock className="w-3 h-3" />
            Na Fila
          </span>
        );
      case "COMPLETED":
        return (
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            <CheckCircle2 className="w-3 h-3" />
            Concluído
          </span>
        );
      case "FAILED":
        return (
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-red-500/20 text-red-400 border border-red-500/30">
            <AlertTriangle className="w-3 h-3" />
            Falhou
          </span>
        );
      case "CANCELLED":
        return (
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-neutral-500/20 text-neutral-400 border border-neutral-500/30">
            <XCircle className="w-3 h-3" />
            Cancelado
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner with Real-Time SSE Indicator */}
      <div className="studio-card p-6 border border-studio-border bg-gradient-to-r from-studio-surface via-studio-panel to-studio-surface">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="text-[10px] uppercase font-mono tracking-widest text-studio-gold font-bold">
                Fase 4 · Orquestrador Multimodal
              </span>
              <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-studio-panel border border-studio-border text-[11px]">
                <Radio
                  className={cn(
                    "w-3 h-3",
                    sseConnected ? "text-emerald-400 animate-pulse" : "text-amber-400"
                  )}
                />
                <span className="text-studio-text-muted font-medium">
                  {sseConnected ? "SSE Stream em Tempo Real" : "Sincronização Polling"}
                </span>
              </div>
            </div>
            <h2 className="text-xl font-bold text-studio-text font-display mt-1.5">
              Fila Assíncrona de Motores de IA
            </h2>
            <p className="text-xs text-studio-text-muted mt-0.5">
              Execução paralela, streaming de eventos, progresso incremental e persistência atômica.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={fetchJobs}
              className="btn text-xs py-2 px-3 border border-studio-border hover:border-studio-gold/40 flex items-center gap-1.5 text-studio-text-muted hover:text-studio-text"
              title="Atualizar lista"
            >
              <RefreshCw className={cn("w-3.5 h-3.5", loading && "animate-spin")} />
              Atualizar
            </button>
            <button
              onClick={() => setShowDispatchModal(true)}
              className="btn-gold text-xs py-2 px-4 flex items-center gap-1.5 font-bold"
            >
              <Plus className="w-4 h-4" />
              Disparar Job
            </button>
          </div>
        </div>

        {/* Quick Stats Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-5 pt-5 border-t border-studio-border/60">
          <div className="p-2.5 rounded-lg bg-studio-panel border border-studio-border">
            <span className="text-[10px] text-studio-text-muted uppercase tracking-wider block">Total</span>
            <span className="text-lg font-bold text-studio-text">{jobs.length}</span>
          </div>
          <div className="p-2.5 rounded-lg bg-blue-500/10 border border-blue-500/20">
            <span className="text-[10px] text-blue-400 uppercase tracking-wider block">Em Execução</span>
            <span className="text-lg font-bold text-blue-400">
              {jobs.filter((j) => j.status === "RUNNING").length}
            </span>
          </div>
          <div className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/20">
            <span className="text-[10px] text-amber-400 uppercase tracking-wider block">Na Fila</span>
            <span className="text-lg font-bold text-amber-400">
              {jobs.filter((j) => j.status === "PENDING").length}
            </span>
          </div>
          <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
            <span className="text-[10px] text-emerald-400 uppercase tracking-wider block">Concluídos</span>
            <span className="text-lg font-bold text-emerald-400">
              {jobs.filter((j) => j.status === "COMPLETED").length}
            </span>
          </div>
          <div className="p-2.5 rounded-lg bg-red-500/10 border border-red-500/20">
            <span className="text-[10px] text-red-400 uppercase tracking-wider block">Falhas</span>
            <span className="text-lg font-bold text-red-400">
              {jobs.filter((j) => j.status === "FAILED").length}
            </span>
          </div>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Status tabs */}
        <div className="flex items-center gap-1 overflow-x-auto p-1 rounded-xl bg-studio-panel border border-studio-border">
          {["ALL", "RUNNING", "PENDING", "COMPLETED", "FAILED", "CANCELLED"].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={cn(
                "px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all",
                statusFilter === st
                  ? "bg-studio-gold text-black font-bold shadow-sm"
                  : "text-studio-text-muted hover:text-studio-text hover:bg-studio-surface"
              )}
            >
              {st === "ALL"
                ? "Todos"
                : st === "RUNNING"
                ? "Em Execução"
                : st === "PENDING"
                ? "Na Fila"
                : st === "COMPLETED"
                ? "Concluídos"
                : st === "FAILED"
                ? "Falhas"
                : "Cancelados"}
            </button>
          ))}
        </div>

        {/* Engine Type dropdown/chips */}
        <div className="flex items-center gap-1 text-xs">
          <span className="text-studio-text-muted mr-1 font-medium">Motor:</span>
          {["ALL", "IMAGE", "VIDEO", "VOICE", "MUSIC", "AVATAR", "RENDER"].map((t) => (
            <button
              key={t}
              onClick={() => setTypeFilter(t)}
              className={cn(
                "px-2.5 py-1 rounded-md text-[11px] font-medium border transition-all",
                typeFilter === t
                  ? "bg-studio-surface text-studio-gold border-studio-gold/50"
                  : "bg-transparent text-studio-text-muted border-studio-border hover:text-studio-text"
              )}
            >
              {t === "ALL" ? "Todos" : t}
            </button>
          ))}
        </div>
      </div>

      {/* Jobs List */}
      {filteredJobs.length === 0 ? (
        <div className="studio-card p-12 text-center border border-studio-border">
          <Layers className="w-10 h-10 text-studio-text-muted mx-auto mb-3 opacity-60" />
          <h3 className="text-sm font-bold text-studio-text mb-1">Nenhum job encontrado</h3>
          <p className="text-xs text-studio-text-muted max-w-sm mx-auto mb-4">
            {jobs.length === 0
              ? "A fila de processamento está vazia. Dispare um novo job para ver o streaming em tempo real."
              : "Nenhum job corresponde aos filtros selecionados."}
          </p>
          <button
            onClick={() => setShowDispatchModal(true)}
            className="btn-gold text-xs py-2 px-4 inline-flex items-center gap-1.5 font-bold"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Disparar Primeiro Job
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredJobs.map((job) => {
            const isProcessing = job.status === "RUNNING";
            const isPending = job.status === "PENDING";
            const isActionBusy = actionLoading === job.id;

            return (
              <div
                key={job.id}
                className={cn(
                  "studio-card p-4 border transition-all relative overflow-hidden",
                  isProcessing
                    ? "border-blue-500/40 bg-blue-500/[0.02]"
                    : "border-studio-border bg-studio-surface hover:border-studio-border/80"
                )}
              >
                {/* Header */}
                <div className="flex flex-wrap items-center justify-between gap-2.5 mb-2.5">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-studio-panel border border-studio-border flex items-center justify-center">
                      {getJobIcon(job.type)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-studio-text">
                          {job.type} · {job.id}
                        </span>
                        {job.model && (
                          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-studio-panel text-studio-text-muted border border-studio-border">
                            {job.model}
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-studio-text-muted block">
                        Criado: {new Date(job.createdAt).toLocaleTimeString()}
                        {job.completedAt && ` · Concluído: ${new Date(job.completedAt).toLocaleTimeString()}`}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {getStatusBadge(job.status)}

                    {/* Actions */}
                    {(isProcessing || isPending) && (
                      <button
                        onClick={() => handleCancel(job.id)}
                        disabled={isActionBusy}
                        className="btn text-[11px] py-1 px-2.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 font-medium"
                        title="Cancelar Job"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        Cancelar
                      </button>
                    )}

                    {(job.status === "FAILED" || job.status === "CANCELLED") && (
                      <button
                        onClick={() => handleRetry(job.id)}
                        disabled={isActionBusy}
                        className="btn text-[11px] py-1 px-2.5 bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/30 font-medium"
                        title="Reiniciar Job"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        Reprocessar
                      </button>
                    )}

                    <button
                      onClick={() => handleDelete(job.id)}
                      disabled={isActionBusy}
                      className="p-1.5 rounded text-studio-text-muted hover:text-red-400 hover:bg-studio-panel transition-colors"
                      title="Excluir Registro"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Progress Bar */}
                {(isProcessing || isPending) && (
                  <div className="my-3 space-y-1">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-studio-blue font-medium animate-pulse">
                        {job.stepLabel || (isPending ? "Aguardando vaga na fila..." : "Processando...")}
                      </span>
                      <span className="font-mono text-studio-text font-bold">{job.progress}%</span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-studio-panel overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-blue-500 to-studio-blue transition-all duration-300 rounded-full"
                        style={{ width: `${job.progress}%` }}
                      />
                    </div>
                  </div>
                )}

                {/* Input Details */}
                <div className="mt-2 text-xs bg-studio-panel/50 p-2.5 rounded-lg border border-studio-border/60">
                  <span className="text-[10px] font-mono text-studio-text-muted uppercase tracking-wider block mb-1">
                    Parâmetros de Entrada
                  </span>
                  <p className="text-studio-text line-clamp-2">
                    {String(
                      job.input.prompt ||
                        job.input.text ||
                        job.input.visualDescription ||
                        JSON.stringify(job.input)
                    )}
                  </p>
                </div>

                {/* Output Preview */}
                {job.status === "COMPLETED" && job.output && (
                  <div className="mt-2.5 p-3 rounded-lg bg-emerald-500/[0.04] border border-emerald-500/20">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-wider font-bold">
                        Saída Renderizada (Storage)
                      </span>
                      {job.output.url && (
                        <a
                          href={job.output.url}
                          target="_blank"
                          rel="noreferrer"
                          className="text-[11px] text-emerald-400 hover:underline flex items-center gap-1 font-medium"
                        >
                          Abrir URL <ExternalLink className="w-3 h-3" />
                        </a>
                      )}
                    </div>

                    {/* Media renderers */}
                    {job.type === "IMAGE" && job.output.url && (
                      <div className="w-48 aspect-video rounded overflow-hidden border border-emerald-500/30 bg-black/40">
                        <img
                          src={job.output.url}
                          alt="Output"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}

                    {(job.type === "VOICE" || job.type === "MUSIC") && job.output.url && (
                      <div className="w-full max-w-md">
                        <audio
                          controls
                          src={job.output.url}
                          className="w-full h-8"
                          preload="metadata"
                        />
                      </div>
                    )}

                    {job.type === "VIDEO" && job.output.url && (
                      <div className="w-64 aspect-video rounded overflow-hidden border border-emerald-500/30 bg-black">
                        <video
                          controls
                          src={job.output.url}
                          className="w-full h-full object-cover"
                          preload="metadata"
                        />
                      </div>
                    )}
                  </div>
                )}

                {/* Error Banner */}
                {job.status === "FAILED" && job.error && (
                  <div className="mt-2.5 p-2.5 rounded-lg bg-red-500/10 border border-red-500/30 text-red-300 text-xs">
                    <span className="font-bold block mb-0.5">Erro na Execução:</span>
                    <span className="font-mono text-[11px]">{job.error}</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Modal: Enfileirar Novo Job de Teste */}
      {showDispatchModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="studio-card p-6 max-w-lg w-full border border-studio-border bg-studio-surface shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-studio-border mb-4">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-studio-gold" />
                <h3 className="text-base font-bold text-studio-text">Disparar Job Assíncrono</h3>
              </div>
              <button
                onClick={() => setShowDispatchModal(false)}
                className="p-1 text-studio-text-muted hover:text-studio-text"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-studio-text-muted block mb-1.5">
                  Motor de IA
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(["IMAGE", "VIDEO", "VOICE", "MUSIC", "AVATAR", "RENDER"] as AIJob["type"][]).map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setDispatchType(t)}
                      className={cn(
                        "p-2.5 rounded-lg border text-xs font-semibold flex items-center justify-center gap-2 transition-all",
                        dispatchType === t
                          ? "bg-studio-gold/15 text-studio-gold border-studio-gold"
                          : "bg-studio-panel text-studio-text-muted border-studio-border hover:border-studio-border/80"
                      )}
                    >
                      {getJobIcon(t)}
                      <span>{t}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-studio-text-muted block mb-1.5">
                  Prompt / Texto de Entrada
                </label>
                <textarea
                  rows={3}
                  value={dispatchPrompt}
                  onChange={(e) => setDispatchPrompt(e.target.value)}
                  className="w-full p-3 rounded-lg bg-studio-panel border border-studio-border text-xs text-studio-text focus:border-studio-gold outline-none"
                  placeholder="Descreva o que o motor de IA deve sintetizar..."
                />
              </div>

              <div className="p-3 rounded-lg bg-studio-panel/70 border border-studio-border text-xs text-studio-text-muted">
                O job será enviado para <code className="text-studio-gold">POST /api/ai/jobs</code> e
                processado em segundo plano com acompanhamento em tempo real via SSE.
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-studio-border">
                <button
                  type="button"
                  onClick={() => setShowDispatchModal(false)}
                  className="btn text-xs py-2 px-4 border border-studio-border text-studio-text-muted"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleEnqueueNew}
                  disabled={dispatching || !dispatchPrompt.trim()}
                  className="btn-gold text-xs py-2 px-5 font-bold flex items-center gap-1.5"
                >
                  {dispatching ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      Enfileirando...
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5" />
                      Enfileirar na Fila
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
