import { useState } from "react";
import type { ContentExperiment, ExperimentType } from "@/types/core4";
import { getExperiments, saveExperiments } from "@/lib/core4/contentFactoryStore";
import { createExperiment, simulateExperimentTelemetry } from "@/lib/core4/experimentManager";
import { cn } from "@/lib/utils";
import {
  FlaskConical, Sparkles, Play, Plus, CheckCircle2, Trophy,
  TrendingUp, Eye, MousePointer, ShieldCheck, RefreshCw
} from "lucide-react";

export default function ExperimentManagerView() {
  const [experiments, setExperiments] = useState<ContentExperiment[]>(() => {
    const existing = getExperiments();
    if (existing.length === 0) {
      // Seed an initial experiment
      const seeded = createExperiment(
        "Teste A/B/C: Ganchos de Abertura para 'O Dia em Que o Rio Cantou'",
        "HOOK_AB",
        "fact-1",
        [
          { key: "A", label: "Gancho Sensorial", content: "Escutem! As pedras do rio estão cantando a letra A!" },
          { key: "B", label: "Gancho de Perda", content: "Pipoca perdeu as letrinhas mágicas no riacho!" },
          { key: "C", label: "Gancho de Pergunta", content: "Você sabe qual é a primeira letra da amizade?" },
        ]
      );
      return [seeded];
    }
    return existing;
  });

  const [selectedExpId, setSelectedExpId] = useState<string>(experiments[0]?.id || "");
  const [isSimulating, setIsSimulating] = useState(false);
  const [showNewModal, setShowNewModal] = useState(false);

  // New Experiment Form
  const [newTitle, setNewTitle] = useState("");
  const [newType, setNewType] = useState<ExperimentType>("TITLE_ABC");
  const [varA, setVarA] = useState("");
  const [varB, setVarB] = useState("");
  const [varC, setVarC] = useState("");

  const activeExp = experiments.find((e) => e.id === selectedExpId) || experiments[0];

  const handleSimulate = (expId: string) => {
    setIsSimulating(true);
    setTimeout(() => {
      simulateExperimentTelemetry(expId);
      setExperiments(getExperiments());
      setIsSimulating(false);
    }, 600);
  };

  const handleCreate = () => {
    if (!newTitle.trim() || !varA.trim() || !varB.trim()) return;

    const variants = [
      { key: "A" as const, label: "Variante A", content: varA },
      { key: "B" as const, label: "Variante B", content: varB },
    ];
    if (varC.trim()) {
      variants.push({ key: "C" as const, label: "Variante C", content: varC });
    }

    const exp = createExperiment(newTitle, newType, `item-${Date.now()}`, variants);
    setExperiments(getExperiments());
    setSelectedExpId(exp.id);
    setShowNewModal(false);
    setNewTitle("");
    setVarA("");
    setVarB("");
    setVarC("");
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-studio-surface p-6 rounded-2xl border border-studio-border flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-studio-gold/10 text-studio-gold border border-studio-gold/30 uppercase">
              CORE 4.0 · EXPERIMENT MANAGER
            </span>
          </div>
          <h2 className="text-xl font-bold text-studio-text font-display">
            Laboratório de Testes A/B/C
          </h2>
          <p className="text-xs text-studio-text-muted mt-1 max-w-2xl">
            Validação estatística contínua de ganchos, títulos, thumbnails e formatos para maximizar CTR e Retenção.
          </p>
        </div>

        <button
          onClick={() => setShowNewModal(true)}
          className="btn-gold text-xs py-2 px-4 gap-1.5 shrink-0"
        >
          <Plus className="w-4 h-4" />
          Novo Teste A/B/C
        </button>
      </div>

      {/* Main Grid: Experiments List & Active Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Col: List of Experiments */}
        <div className="studio-card p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-studio-text uppercase tracking-wider">
              Experimentos Ativos ({experiments.length})
            </h3>
          </div>

          <div className="space-y-2.5">
            {experiments.map((exp) => (
              <div
                key={exp.id}
                onClick={() => setSelectedExpId(exp.id)}
                className={cn(
                  "p-3.5 rounded-xl border cursor-pointer transition-all space-y-1.5",
                  selectedExpId === exp.id
                    ? "bg-studio-panel border-studio-gold ring-1 ring-studio-gold/40 shadow-xs"
                    : "bg-studio-panel/50 border-studio-border hover:border-studio-border-light"
                )}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono text-studio-gold font-bold">
                    {exp.type}
                  </span>
                  <span className={cn(
                    "text-[10px] px-2 py-0.5 rounded-full font-mono font-bold",
                    exp.status === "CONCLUDED"
                      ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/30"
                      : "bg-amber-500/15 text-amber-400 border border-amber-500/30"
                  )}>
                    {exp.status === "CONCLUDED" ? "Concluído ✓" : "Coletando Dados..."}
                  </span>
                </div>
                <h4 className="text-xs font-semibold text-studio-text line-clamp-2">
                  {exp.title}
                </h4>
              </div>
            ))}
          </div>
        </div>

        {/* Right 2 Cols: Active Experiment Telemetry & Variants */}
        <div className="lg:col-span-2 studio-card p-6 space-y-6">
          {activeExp ? (
            <>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-studio-border">
                <div>
                  <span className="text-[10px] font-mono text-studio-gold uppercase font-bold">
                    {activeExp.type} · {activeExp.variants.length} Variantes
                  </span>
                  <h3 className="text-base font-bold text-studio-text font-display mt-0.5">
                    {activeExp.title}
                  </h3>
                </div>

                <div className="flex items-center gap-2">
                  {activeExp.status === "RUNNING" && (
                    <button
                      onClick={() => handleSimulate(activeExp.id)}
                      disabled={isSimulating}
                      className="btn-gold text-xs py-1.5 px-3 gap-1.5"
                    >
                      {isSimulating ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
                      Simular Coleta de Telemetria
                    </button>
                  )}
                </div>
              </div>

              {/* Conclusion Banner if Completed */}
              {activeExp.status === "CONCLUDED" && activeExp.conclusionSummary && (
                <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-3 text-xs text-emerald-400">
                  <Trophy className="w-5 h-5 shrink-0 text-studio-gold" />
                  <div>
                    <strong className="block font-bold text-studio-text">Veredito Estatístico:</strong>
                    <span>{activeExp.conclusionSummary} (Confiança: {activeExp.confidenceScorePercent}%)</span>
                  </div>
                </div>
              )}

              {/* Variants Breakdown Matrix */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {activeExp.variants.map((v) => (
                  <div
                    key={v.key}
                    className={cn(
                      "p-4 rounded-xl border space-y-3 relative flex flex-col justify-between",
                      v.isWinner
                        ? "bg-studio-gold/10 border-studio-gold ring-1 ring-studio-gold/50 shadow-md"
                        : "bg-studio-panel border-studio-border"
                    )}
                  >
                    {v.isWinner && (
                      <div className="absolute -top-2.5 right-3 px-2 py-0.5 rounded-full bg-studio-gold text-black text-[9px] font-bold font-mono uppercase flex items-center gap-1 shadow-xs">
                        <Trophy className="w-3 h-3" />
                        Vencedor
                      </div>
                    )}

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-bold font-mono text-studio-gold">
                          Variante [{v.key}]
                        </span>
                        <span className="text-[10px] text-studio-text-muted">
                          {v.label}
                        </span>
                      </div>

                      <p className="text-xs text-studio-text font-medium bg-studio-surface p-2.5 rounded-lg border border-studio-border/60">
                        "{v.content}"
                      </p>
                    </div>

                    {/* Metrics */}
                    <div className="pt-2 border-t border-studio-border/60 space-y-1.5 text-xs font-mono">
                      <div className="flex justify-between">
                        <span className="text-studio-text-muted">Impressões:</span>
                        <span className="text-studio-text font-semibold">{v.sampleImpressions.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-studio-text-muted">Taxa CTR:</span>
                        <span className={cn("font-bold", v.isWinner ? "text-emerald-400 text-sm" : "text-studio-text")}>
                          {v.ctr}%
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-studio-text-muted">Retenção Média:</span>
                        <span className="text-studio-blue font-semibold">{v.retentionPercent}%</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="p-8 text-center text-studio-text-muted text-xs">
              Nenhum experimento selecionado.
            </div>
          )}
        </div>
      </div>

      {/* New Experiment Modal */}
      {showNewModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-studio-surface border border-studio-border max-w-lg w-full rounded-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-studio-text font-display">
              Criar Novo Teste A/B/C
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-studio-text-muted mb-1">Título do Experimento</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="Ex: Teste de Título para o Vídeo de Biologia"
                  className="input-studio"
                />
              </div>

              <div>
                <label className="block text-studio-text-muted mb-1">Tipo de Teste</label>
                <select
                  value={newType}
                  onChange={(e) => setNewType(e.target.value as ExperimentType)}
                  className="input-studio"
                >
                  <option value="HOOK_AB">Ganchos Iniciais (0s-3s)</option>
                  <option value="TITLE_ABC">Títulos (A/B/C)</option>
                  <option value="THUMBNAIL_ABC">Thumbnails</option>
                  <option value="FORMAT_COMPARISON">Comparação de Formatos</option>
                </select>
              </div>

              <div>
                <label className="block text-studio-text-muted mb-1">Variante A (Padrão)</label>
                <input
                  type="text"
                  value={varA}
                  onChange={(e) => setVarA(e.target.value)}
                  placeholder="Texto ou descrição da variante A..."
                  className="input-studio"
                />
              </div>

              <div>
                <label className="block text-studio-text-muted mb-1">Variante B (Alternativa)</label>
                <input
                  type="text"
                  value={varB}
                  onChange={(e) => setVarB(e.target.value)}
                  placeholder="Texto ou descrição da variante B..."
                  className="input-studio"
                />
              </div>

              <div>
                <label className="block text-studio-text-muted mb-1">Variante C (Opcional)</label>
                <input
                  type="text"
                  value={varC}
                  onChange={(e) => setVarC(e.target.value)}
                  placeholder="Texto ou descrição da variante C..."
                  className="input-studio"
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setShowNewModal(false)}
                className="btn-secondary text-xs py-2 px-4"
              >
                Cancelar
              </button>
              <button
                onClick={handleCreate}
                className="btn-gold text-xs py-2 px-5"
              >
                Iniciar Teste
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
