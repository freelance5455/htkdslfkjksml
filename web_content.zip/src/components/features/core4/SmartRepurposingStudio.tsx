import { useState } from "react";
import type { ContentFactoryItem, SmartRepurposingPlan } from "@/types/core4";
import { getFactoryItems } from "@/lib/core4/contentFactoryStore";
import { generateSmartRepurposingPlan } from "@/lib/core4/smartRepurposingEngine";
import { cn } from "@/lib/utils";
import {
  Share2, Sparkles, Film, Copy, Check, ArrowRight,
  Play, Download, ExternalLink, Scissors, Smartphone
} from "lucide-react";

export default function SmartRepurposingStudio() {
  const items = getFactoryItems();
  const [selectedItemId, setSelectedItemId] = useState<string>(items[0]?.id || "");
  const [activePlan, setActivePlan] = useState<SmartRepurposingPlan | null>(null);
  const [copiedClipId, setCopiedClipId] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const selectedItem = items.find((i) => i.id === selectedItemId) || items[0];

  const handleGeneratePlan = () => {
    if (!selectedItem) return;
    setIsGenerating(true);

    setTimeout(() => {
      const plan = generateSmartRepurposingPlan(selectedItem);
      setActivePlan(plan);
      setIsGenerating(false);
    }, 600);
  };

  const handleCopyCaption = (clipId: string, captionText: string) => {
    navigator.clipboard.writeText(captionText);
    setCopiedClipId(clipId);
    setTimeout(() => setCopiedClipId(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-studio-surface p-6 rounded-2xl border border-studio-border flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-studio-gold/10 text-studio-gold border border-studio-gold/30 uppercase">
              CORE 4.0 · REPURPOSING
            </span>
          </div>
          <h2 className="text-xl font-bold text-studio-text font-display">
            Smart Multi-Platform Repurposing
          </h2>
          <p className="text-xs text-studio-text-muted mt-1 max-w-2xl">
            Transforme automaticamente 1 vídeo longo de alto impacto em Shorts, TikTok, Instagram Reels,
            Facebook Reels, Quote Cards e Teasers com cortes inteligentes nos momentos de pico de retenção.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <select
            value={selectedItemId}
            onChange={(e) => {
              setSelectedItemId(e.target.value);
              setActivePlan(null);
            }}
            className="input-studio text-xs py-2"
          >
            {items.map((it) => (
              <option key={it.id} value={it.id}>
                {it.title} ({it.stage})
              </option>
            ))}
          </select>

          <button
            onClick={handleGeneratePlan}
            disabled={isGenerating}
            className="btn-gold text-xs py-2 px-4 gap-1.5 shrink-0"
          >
            <Sparkles className="w-4 h-4" />
            {isGenerating ? "Gerando Cortes..." : "Repurposar 1→7"}
          </button>
        </div>
      </div>

      {/* Generated Clips Grid */}
      {activePlan && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-studio-text font-display flex items-center gap-2">
              <Film className="w-4 h-4 text-studio-gold" />
              {activePlan.clips.length} Formatos Otimizados Gerados a partir de "{activePlan.sourceTitle}"
            </h3>
            <span className="text-xs font-mono text-emerald-400 font-bold">
              100% Sincronizado
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {activePlan.clips.map((clip) => (
              <div
                key={clip.id}
                className="p-4 rounded-xl bg-studio-panel border border-studio-border space-y-3 flex flex-col justify-between hover:border-studio-gold/40 transition-all shadow-xs"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-studio-gold/10 text-studio-gold font-bold border border-studio-gold/30">
                      {(clip.targetFormat || "").replace(/_/g, " ")}
                    </span>
                    <span className="text-[11px] font-mono text-studio-text-muted">
                      {clip.aspectRatio} · {clip.durationSec}s
                    </span>
                  </div>

                  <h4 className="text-xs font-bold text-studio-text">
                    {clip.title}
                  </h4>

                  {/* Hook Display */}
                  <div className="p-2.5 rounded-lg bg-studio-surface border border-studio-border/60 text-xs">
                    <span className="text-[10px] text-studio-text-muted block font-semibold mb-0.5">
                      Gancho Inicial (0s - 3s):
                    </span>
                    <span className="text-studio-gold italic">"{clip.hook}"</span>
                  </div>

                  {/* Caption & Hashtags */}
                  <div className="p-2.5 rounded-lg bg-studio-surface/50 border border-studio-border/40 text-[11px] space-y-1">
                    <p className="text-studio-text-dim line-clamp-3">
                      {clip.caption}
                    </p>
                    <div className="flex flex-wrap gap-1 text-studio-blue text-[10px]">
                      {clip.hashtags.map((h, i) => (
                        <span key={i}>{h}</span>
                      ))}
                    </div>
                  </div>

                  {/* Timestamp Source */}
                  <div className="text-[10px] text-studio-text-muted font-mono flex items-center justify-between pt-1">
                    <span>Segmento da Fonte:</span>
                    <span>{clip.startSecondInSource}s - {clip.endSecondInSource}s</span>
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-2 border-t border-studio-border/60 flex items-center justify-between gap-2">
                  <button
                    onClick={() => handleCopyCaption(clip.id, `${clip.caption}\n\n${clip.hashtags.join(" ")}`)}
                    className="btn-secondary text-[11px] py-1.5 px-3 gap-1 flex-1 justify-center"
                  >
                    {copiedClipId === clip.id ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        Copiado!
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        Copiar Legenda
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => alert(`Corte "${clip.title}" enviado para a fila de renderização de shorts!`)}
                    className="btn-gold text-[11px] py-1.5 px-3 gap-1"
                  >
                    <Scissors className="w-3.5 h-3.5" />
                    Renderizar
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {!activePlan && (
        <div className="p-12 text-center border border-dashed border-studio-border rounded-2xl bg-studio-surface/40 space-y-3">
          <Smartphone className="w-8 h-8 text-studio-gold mx-auto opacity-70" />
          <h3 className="text-sm font-bold text-studio-text">Nenhum plano de repurposing gerado ainda</h3>
          <p className="text-xs text-studio-text-muted max-w-md mx-auto">
            Selecione um projeto acima e clique em "Repurposar 1→7" para que a IA extraia automaticamente
            os melhores ganchos e momentos para YouTube Shorts, Reels e TikTok.
          </p>
        </div>
      )}
    </div>
  );
}
