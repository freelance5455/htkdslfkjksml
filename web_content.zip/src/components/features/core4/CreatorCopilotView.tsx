import { useState, useRef, useEffect } from "react";
import type { CreatorCopilotMessage, CreativeMemoryItem } from "@/types/core4";
import { processCopilotQuery } from "@/lib/core4/creatorCopilotEngine";
import { getCreativeMemory } from "@/lib/core4/contentFactoryStore";
import { cn } from "@/lib/utils";
import {
  Cpu, Send, Sparkles, Lightbulb, Bookmark, Star, ArrowRight,
  TrendingUp, Clock, AlertCircle, Play, Layers
} from "lucide-react";

const QUICK_PROMPTS = [
  { label: "🎯 O que devo criar hoje?", query: "O que devo criar hoje?" },
  { label: "⚠️ Qual projeto está atrasado?", query: "Qual projeto está atrasado?" },
  { label: "🏆 O que funcionou esta semana?", query: "O que funcionou esta semana?" },
  { label: "💡 O que devo melhorar?", query: "O que devo melhorar no canal?" },
  { label: "📦 Produzir em Lote", query: "Quais conteúdos devo produzir em lote?" },
  { label: "🪄 Semana Infantil Completa (17 Etapas)", query: "Cria uma semana inteira de conteúdo para o meu canal infantil" },
];

export default function CreatorCopilotView({
  onRunScenario,
  onNavigateBatch,
  onNavigateFactory,
}: {
  onRunScenario?: () => void;
  onNavigateBatch?: () => void;
  onNavigateFactory?: () => void;
}) {
  const [messages, setMessages] = useState<CreatorCopilotMessage[]>([
    {
      id: "msg-welcome",
      sender: "COPILOT",
      text: `Olá, **Sadraque Ngola**! Sou o seu **Creator Copilot (CORE 4.0)**. 
Analiso em tempo real seus 11 estágios da Content Factory, a consistência de marca dos seus universos, dados de retenção e experimentos A/B.

Como posso acelerar sua produção hoje? Escolha uma das sugestões rápidas ou digite seu comando.`,
      suggestedActions: [
        { label: "🪄 Executar Cenário da Semana Infantil (17 Etapas)", actionType: "RUN_SCENARIO" },
        { label: "📦 Abrir Fábrica de Produção em Lote", actionType: "OPEN_BATCH" },
      ],
      timestamp: new Date().toISOString(),
    },
  ]);
  const [inputQuery, setInputQuery] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [creativeMemory] = useState<CreativeMemoryItem[]>(getCreativeMemory());
  const chatBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = (textToSend?: string) => {
    const text = textToSend || inputQuery;
    if (!text.trim()) return;

    const userMsg: CreatorCopilotMessage = {
      id: `usr-${Date.now()}`,
      sender: "USER",
      text: text.trim(),
      timestamp: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputQuery("");
    setIsTyping(true);

    setTimeout(() => {
      const response = processCopilotQuery(text);
      setMessages((prev) => [...prev, response]);
      setIsTyping(false);
    }, 600);
  };

  const handleActionClick = (action: { label: string; actionType: string; payload?: Record<string, unknown> }) => {
    if (action.actionType === "RUN_17_STEP_SCENARIO" || action.actionType === "RUN_SCENARIO") {
      if (onRunScenario) onRunScenario();
    } else if (action.actionType === "OPEN_BATCH_STUDIO" || action.actionType === "START_BATCH_JOB" || action.actionType === "OPEN_BATCH") {
      if (onNavigateBatch) onNavigateBatch();
    } else if (action.actionType === "NAVIGATE_FACTORY_PIPELINE") {
      if (onNavigateFactory) onNavigateFactory();
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Left 2 Cols: Copilot Chat */}
      <div className="lg:col-span-2 studio-card flex flex-col h-[680px] p-0 overflow-hidden">
        {/* Chat Header */}
        <div className="p-4 border-b border-studio-border bg-studio-surface flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-studio-blue/10 border border-studio-blue/30 flex items-center justify-center text-studio-blue">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-studio-text font-display">Creator Copilot</h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-studio-blue/20 text-studio-blue font-mono font-bold">
                  SADRAQUE NGOLA · PRIVADO
                </span>
              </div>
              <p className="text-[11px] text-studio-text-muted">
                Inteligência Estratégica conectada aos dados reais do seu estúdio
              </p>
            </div>
          </div>

          <span className="flex items-center gap-1.5 text-xs text-emerald-400 font-mono">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            Online
          </span>
        </div>

        {/* Quick Suggestion Chips */}
        <div className="p-3 border-b border-studio-border/60 bg-studio-panel/40 flex items-center gap-2 overflow-x-auto custom-scrollbar">
          {QUICK_PROMPTS.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => {
                if (prompt.query.includes("17 Etapas") && onRunScenario) {
                  onRunScenario();
                } else {
                  handleSend(prompt.query);
                }
              }}
              className="text-xs px-3 py-1.5 rounded-full bg-studio-surface border border-studio-border hover:border-studio-gold hover:text-studio-gold text-studio-text-dim whitespace-nowrap transition-colors shrink-0 shadow-xs"
            >
              {prompt.label}
            </button>
          ))}
        </div>

        {/* Messages Feed */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4 custom-scrollbar bg-studio-bg/50">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={cn(
                "flex flex-col max-w-[88%] space-y-2",
                msg.sender === "USER" ? "ml-auto items-end" : "mr-auto items-start"
              )}
            >
              <div
                className={cn(
                  "p-4 rounded-2xl text-xs leading-relaxed",
                  msg.sender === "USER"
                    ? "bg-studio-gold text-black font-medium rounded-br-xs shadow-md"
                    : "bg-studio-surface border border-studio-border text-studio-text rounded-bl-xs shadow-sm"
                )}
              >
                <div className="whitespace-pre-line">{msg.text}</div>
              </div>

              {/* Action Buttons if available */}
              {msg.suggestedActions && msg.suggestedActions.length > 0 && (
                <div className="flex flex-wrap gap-2 pt-1">
                  {msg.suggestedActions.map((action, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleActionClick(action)}
                      className="btn-gold text-[11px] py-1.5 px-3 gap-1.5 shadow-sm"
                    >
                      <Sparkles className="w-3 h-3" />
                      {action.label}
                    </button>
                  ))}
                </div>
              )}

              <span className="text-[9px] font-mono text-studio-text-muted/60 px-1">
                {new Date(msg.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
              </span>
            </div>
          ))}

          {isTyping && (
            <div className="flex items-center gap-2 p-3 bg-studio-surface rounded-2xl border border-studio-border w-24">
              <span className="w-2 h-2 rounded-full bg-studio-gold animate-bounce" />
              <span className="w-2 h-2 rounded-full bg-studio-gold animate-bounce [animation-delay:0.2s]" />
              <span className="w-2 h-2 rounded-full bg-studio-gold animate-bounce [animation-delay:0.4s]" />
            </div>
          )}
          <div ref={chatBottomRef} />
        </div>

        {/* Input Bar */}
        <div className="p-3 border-t border-studio-border bg-studio-surface flex items-center gap-2">
          <input
            type="text"
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            placeholder="Pergunte ao Copilot sobre ideias, prazos, gargalos ou comandos em lote..."
            className="input-studio text-xs py-2.5"
          />
          <button
            onClick={() => handleSend()}
            disabled={!inputQuery.trim()}
            className="btn-gold p-2.5 shrink-0 rounded-xl"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Right Column: Creative Memory Drawer */}
      <div className="studio-card p-5 space-y-4 flex flex-col h-[680px] overflow-hidden">
        <div className="flex items-center justify-between pb-3 border-b border-studio-border">
          <div className="flex items-center gap-2">
            <Bookmark className="w-4 h-4 text-studio-gold" />
            <h3 className="text-sm font-bold text-studio-text font-display">Memória Criativa</h3>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-studio-panel border border-studio-border text-studio-text-muted">
            {creativeMemory.length} Padrões
          </span>
        </div>

        <p className="text-[11px] text-studio-text-muted">
          Padrões vencedores de ganchos, títulos e formatos extraídos dos seus conteúdos com maior retenção e conversão.
        </p>

        <div className="flex-1 overflow-y-auto space-y-3 custom-scrollbar pr-1">
          {creativeMemory.map((mem) => (
            <div
              key={mem.id}
              className="p-3.5 rounded-xl bg-studio-panel border border-studio-border space-y-2 text-xs hover:border-studio-gold/40 transition-colors"
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono text-studio-gold font-bold uppercase">
                  {(mem.category || "").replace("SUCCESSFUL_", "")}
                </span>
                <span className="text-[10px] font-mono text-emerald-400 font-bold px-1.5 py-0.5 rounded-xs bg-emerald-500/10">
                  {mem.performanceScore} pts
                </span>
              </div>

              <h4 className="font-semibold text-studio-text">
                {mem.title}
              </h4>

              <div className="p-2 rounded-md bg-studio-surface border border-studio-border/60 text-studio-gold font-mono text-[11px] italic">
                "{mem.textSnippet}"
              </div>

              <p className="text-[11px] text-studio-text-muted leading-relaxed">
                <strong>Por que funcionou:</strong> {mem.whyItWorked}
              </p>

              <div className="text-[10px] text-studio-text-dim pt-1 border-t border-studio-border/60 flex items-center justify-between">
                <span>{mem.topic}</span>
                {mem.realMetrics.views && (
                  <span className="font-mono text-emerald-400">
                    {(mem.realMetrics.views / 1000).toFixed(1)}k views
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
