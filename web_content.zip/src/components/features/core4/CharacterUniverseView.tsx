import { useState } from "react";
import type { WorldBuildingUniverse, CharacterProfile } from "@/types/core4";
import { getUniverses, saveUniverses } from "@/lib/core4/contentFactoryStore";
import { addCharacterToUniverse, createUniverse } from "@/lib/core4/characterUniverseEngine";
import { cn } from "@/lib/utils";
import {
  Globe2, Sparkles, User, Mic2, Palette, Music, BookOpen,
  Plus, CheckCircle, ShieldCheck, Image, MessageSquare, Star
} from "lucide-react";

export default function CharacterUniverseView() {
  const [universes, setUniverses] = useState<WorldBuildingUniverse[]>(getUniverses());
  const [selectedUniverseId, setSelectedUniverseId] = useState<string>(universes[0]?.id || "");
  const [selectedCharacter, setSelectedCharacter] = useState<CharacterProfile | null>(null);
  const [showNewCharModal, setShowNewCharModal] = useState(false);
  const [showNewUniverseModal, setShowNewUniverseModal] = useState(false);

  // Form States
  const [newCharName, setNewCharName] = useState("");
  const [newCharRole, setNewCharRole] = useState<CharacterProfile["role"]>("PROTAGONIST");
  const [newCharProfile, setNewCharProfile] = useState("");
  const [newCharVoiceName, setNewCharVoiceName] = useState("Voz Infantil ElevenLabs");
  const [newCharCatchphrase, setNewCharCatchphrase] = useState("");

  const activeUniverse = universes.find((u) => u.id === selectedUniverseId) || universes[0];

  const handleAddCharacter = () => {
    if (!newCharName.trim() || !activeUniverse) return;

    addCharacterToUniverse(activeUniverse.id, {
      name: newCharName,
      role: newCharRole,
      profile: newCharProfile || "Personagem recorrente do universo.",
      appearance: {
        description: "Personagem 3D estilizado no padrão de arte do universo.",
        clothing: "Padrão",
        distinctiveFeatures: ["Expressivo", "Amigável"],
        colorPalette: ["#FF7A00", "#3B82F6"],
        artStyle: activeUniverse.visualStyle.artEngine,
      },
      voice: {
        provider: "ELEVENLABS",
        voiceId: `voice-${newCharName.toLowerCase().replace(/\s+/g, "-")}`,
        voiceName: newCharVoiceName,
        accent: "Português Neutro",
        speechPattern: "Cadência natural",
      },
      personality: {
        traits: ["Carismático", "Prestativo"],
        catchphrases: newCharCatchphrase ? [newCharCatchphrase] : ["Vamos lá!"],
        fears: [],
        goals: ["Fazer a diferença no universo"],
      },
      relationships: [],
      referenceImages: ["https://images.unsplash.com/photo-1511497584788-87676104235f?w=600"],
      history: ["Criado no Core 4.0."],
    });

    setUniverses(getUniverses());
    setShowNewCharModal(false);
    setNewCharName("");
    setNewCharProfile("");
    setNewCharCatchphrase("");
  };

  return (
    <div className="space-y-6">
      {/* Universes Top Selector & Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-studio-surface p-4 rounded-xl border border-studio-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
            <Globe2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-studio-text font-display">Universos & World Building</h3>
            <p className="text-xs text-studio-text-muted">
              Gestão de personagens recorrentes, regras de lore, estilos visuais e vozes imutáveis
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex gap-1.5 p-1 rounded-lg bg-studio-panel border border-studio-border">
            {universes.map((u) => (
              <button
                key={u.id}
                onClick={() => setSelectedUniverseId(u.id)}
                className={cn(
                  "px-3 py-1.5 rounded-md text-xs font-semibold transition-all",
                  selectedUniverseId === u.id
                    ? "bg-studio-gold text-black shadow-xs"
                    : "text-studio-text-muted hover:text-studio-text"
                )}
              >
                {u.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Active Universe Overview Card */}
      {activeUniverse && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Universe Details */}
          <div className="lg:col-span-1 studio-card p-5 space-y-4">
            <div>
              <span className="text-[10px] font-mono text-studio-gold uppercase font-bold tracking-wider">
                {activeUniverse.genre} · {activeUniverse.targetAgeGroup}
              </span>
              <h3 className="text-lg font-bold text-studio-text font-display mt-0.5">
                {activeUniverse.name}
              </h3>
              <p className="text-xs text-studio-text-muted mt-1 leading-relaxed">
                {activeUniverse.description}
              </p>
            </div>

            {/* Lore Rules */}
            <div className="space-y-2 pt-2 border-t border-studio-border">
              <h4 className="text-xs font-bold text-studio-text uppercase tracking-wider flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-studio-gold" />
                Regras Fundamentais de Lore
              </h4>
              <ul className="space-y-1.5 text-xs text-studio-text-dim">
                {activeUniverse.rules.map((rule, idx) => (
                  <li key={idx} className="flex items-start gap-2 bg-studio-panel/70 p-2 rounded-lg border border-studio-border/60">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{rule}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Style Engines */}
            <div className="space-y-2 pt-2 border-t border-studio-border text-xs">
              <div className="flex items-center gap-2 text-studio-text-dim">
                <Palette className="w-3.5 h-3.5 text-pink-400 shrink-0" />
                <span className="font-semibold text-studio-text">Visual:</span> {activeUniverse.visualStyle.artEngine}
              </div>
              <div className="flex items-center gap-2 text-studio-text-dim">
                <Music className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span className="font-semibold text-studio-text">Música:</span> {activeUniverse.musicStyle.genre} ({activeUniverse.musicStyle.tempoBpm} BPM)
              </div>
            </div>
          </div>

          {/* Characters Section */}
          <div className="lg:col-span-2 studio-card p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-studio-gold" />
                <h3 className="text-sm font-bold text-studio-text font-display">
                  Personagens do Elenco ({activeUniverse.characters.length})
                </h3>
              </div>
              <button
                onClick={() => setShowNewCharModal(true)}
                className="btn-gold text-xs py-1.5 px-3 gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                Novo Personagem
              </button>
            </div>

            {/* Characters Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {activeUniverse.characters.map((char) => (
                <div
                  key={char.id}
                  onClick={() => setSelectedCharacter(char)}
                  className="p-4 rounded-xl bg-studio-panel border border-studio-border hover:border-studio-gold/50 cursor-pointer transition-all duration-200 space-y-3 group"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-14 h-14 rounded-xl overflow-hidden bg-black/40 border border-studio-border shrink-0">
                      {char.referenceImages[0] ? (
                        <img
                          src={char.referenceImages[0]}
                          alt={char.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-studio-text-muted">
                          <User className="w-6 h-6" />
                        </div>
                      )}
                    </div>
                    <div>
                      <span className="text-[10px] font-mono text-studio-gold font-bold uppercase">
                        {char.role}
                      </span>
                      <h4 className="text-sm font-bold text-studio-text group-hover:text-studio-gold transition-colors">
                        {char.name}
                      </h4>
                      <p className="text-[11px] text-studio-text-muted line-clamp-2 mt-0.5">
                        {char.profile}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-studio-text-dim pt-2 border-t border-studio-border/60">
                    <span className="flex items-center gap-1 text-cyan-400">
                      <Mic2 className="w-3 h-3" />
                      {char.voice.voiceName.split("(")[0]}
                    </span>
                    <span className="font-mono text-studio-text-muted">
                      {char.episodeAppearancesCount} episódios
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Character Profile Modal */}
      {selectedCharacter && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-studio-surface border border-studio-border max-w-xl w-full rounded-2xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl overflow-hidden bg-black/40 border border-studio-border shrink-0">
                  <img
                    src={selectedCharacter.referenceImages[0]}
                    alt=""
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div>
                  <span className="text-[10px] font-mono text-studio-gold uppercase font-bold">
                    {selectedCharacter.role}
                  </span>
                  <h3 className="text-base font-bold text-studio-text font-display">
                    {selectedCharacter.name}
                  </h3>
                </div>
              </div>
              <button
                onClick={() => setSelectedCharacter(null)}
                className="text-studio-text-muted hover:text-studio-text text-sm p-1"
              >
                ✕ Fechar
              </button>
            </div>

            <div className="p-3 rounded-xl bg-studio-panel border border-studio-border text-xs space-y-2">
              <p className="text-studio-text">{selectedCharacter.profile}</p>
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-studio-border text-[11px]">
                <div>
                  <span className="text-studio-text-muted block">Voz Homologada:</span>
                  <span className="font-semibold text-cyan-400">{selectedCharacter.voice.voiceName} ({selectedCharacter.voice.provider})</span>
                </div>
                <div>
                  <span className="text-studio-text-muted block">Frase Marcante:</span>
                  <span className="font-semibold text-studio-gold italic">"{selectedCharacter.personality.catchphrases[0] || "N/A"}"</span>
                </div>
              </div>
            </div>

            <div className="space-y-1.5">
              <span className="text-xs font-bold text-studio-text block">Traços de Personalidade:</span>
              <div className="flex flex-wrap gap-1.5">
                {selectedCharacter.personality.traits.map((t, idx) => (
                  <span key={idx} className="text-[11px] px-2 py-0.5 rounded-full bg-studio-panel border border-studio-border text-studio-text">
                    {t}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setSelectedCharacter(null)}
                className="btn-gold text-xs py-2 px-5"
              >
                Concluído
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add New Character Modal */}
      {showNewCharModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-studio-surface border border-studio-border max-w-md w-full rounded-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-studio-text font-display">
              Criar Novo Personagem
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-studio-text-muted mb-1">Nome do Personagem</label>
                <input
                  type="text"
                  value={newCharName}
                  onChange={(e) => setNewCharName(e.target.value)}
                  placeholder="Ex: Bartô, o Castor Engenheiro"
                  className="input-studio"
                />
              </div>

              <div>
                <label className="block text-studio-text-muted mb-1">Papel na História</label>
                <select
                  value={newCharRole}
                  onChange={(e) => setNewCharRole(e.target.value as CharacterProfile["role"])}
                  className="input-studio"
                >
                  <option value="PROTAGONIST">Protagonista</option>
                  <option value="SIDEKICK">Companheiro / Sidekick</option>
                  <option value="MENTOR">Mentor / Professor</option>
                  <option value="NARRATOR">Narrador</option>
                </select>
              </div>

              <div>
                <label className="block text-studio-text-muted mb-1">Descrição / Biografia Curta</label>
                <textarea
                  rows={2}
                  value={newCharProfile}
                  onChange={(e) => setNewCharProfile(e.target.value)}
                  placeholder="Personalidade, gostos e como interage com a turma..."
                  className="input-studio resize-none"
                />
              </div>

              <div>
                <label className="block text-studio-text-muted mb-1">Bordão / Frase de Efeito</label>
                <input
                  type="text"
                  value={newCharCatchphrase}
                  onChange={(e) => setNewCharCatchphrase(e.target.value)}
                  placeholder="Ex: Nozes saltitantes!"
                  className="input-studio"
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowNewCharModal(false)}
                className="btn-secondary text-xs py-2 px-4"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleAddCharacter}
                className="btn-gold text-xs py-2 px-5"
              >
                Salvar Personagem
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
