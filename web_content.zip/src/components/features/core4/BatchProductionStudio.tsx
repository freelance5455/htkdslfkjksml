import { useState } from "react";
import type { BatchSize, BatchProductionJob } from "@/types/core4";
import {
  estimateBatchCost,
  createBatchProductionJob,
  generateSampleForBatch,
  executeFullBatch,
} from "@/lib/core4/batchProductionEngine";
import { getUniverses } from "@/lib/core4/contentFactoryStore";
import { cn } from "@/lib/utils";
import {
  Layers, Sparkles, ShieldCheck, DollarSign, CheckCircle2,
  AlertTriangle, Play, RefreshCw, Cpu, Star, Check, ArrowRight
} from "lucide-react";

export default function BatchProductionStudio({
  onBatchCompleted,
}: {
  onBatchCompleted?: () => void;
}) {
  const universes = getUniverses();
  const [selectedUniverseId, setSelectedUniverseId] = useState<string>(universes[0]?.id || "univ-kids-forest");
  const [batchSize, setBatchSize] = useState<BatchSize>(5);
  const [batchTitle, setBatchTitle] = useState<string>("Semana Educativa da Floresta");
  const [activeJob, setActiveJob] = useState<BatchProductionJob | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  const costEstimate = estimateBatchCost(batchSize);

  const handleStartBatch = () => {
    setShowConfirmModal(true);
  };

  const handleConfirmBudgetAndStart = async () => {
    setShowConfirmModal(false);
    setIsProcessing(true);

    try {
      // Step 1: Create Job
      const job = createBatchProductionJob(batchTitle, batchSize, selectedUniverseId);
      setActiveJob(job);

      // Step 2: Generate Sample 1
      const jobWithSample = await generateSampleForBatch(job.id);
      setActiveJob({ ...jobWithSample });
    } catch (err) {
      console.error("Batch error:", err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleApproveSampleAndRollout = async () => {
    if (!activeJob) return;
    setIsProcessing(true);

    try {
      const completedJob = await executeFullBatch(activeJob.id);
      setActiveJob({ ...completedJob });
      if (onBatchCompleted) {
        onBatchCompleted();
      }
    } catch (err) {
      console.error("Rollout error:", err);
    } finally {
      setIsProcessing(false);
    }
  };

  const selectedUniverse = universes.find((u) => u.id === selectedUniverseId);

  return (
    <div className="space-y-6">
      {/* Studio Header */}
      <div className="bg-studio-surface p-6 rounded-2xl border border-studio-border relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-studio-gold/5 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-studio-gold/10 text-studio-gold border border-studio-gold/30 uppercase">
                CORE 4.0 · BATCH ENGINE
              </span>
              <span className="text-[10px] font-mono text-studio-text-muted">
                Controle Humano & Escala Segura
              </span>
            </div>
            <h2 className="text-xl font-bold text-studio-text font-display">
              Fábrica de Produção em Lote
            </h2>
            <p className="text-xs text-studio-text-muted max-w-2xl mt-1">
              Produza volumes estratégicos de conteúdo (5, 10, 20 ou 50 itens) preservando DNA de marca,
              regras de lore, consistência de personagens e aprovação prévia de amostra pelo Quality Gate.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <div className="p-3 rounded-xl bg-studio-panel border border-studio-border text-right">
              <span className="text-[10px] text-studio-text-muted block">Orçamento Estimado</span>
              <span className="text-lg font-bold text-studio-gold font-mono">
                ${costEstimate.estimatedCostUsd} USD
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Batch Setup Form */}
      {!activeJob && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 studio-card p-6 space-y-5">
            <h3 className="text-sm font-bold text-studio-text font-display flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-studio-gold" />
              Configuração do Lote de Produção
            </h3>

            <div className="space-y-4">
              {/* Batch Title */}
              <div>
                <label className="block text-xs font-semibold text-studio-text-dim mb-1.5">
                  Título do Lote / Tema Geral
                </label>
                <input
                  type="text"
                  value={batchTitle}
                  onChange={(e) => setBatchTitle(e.target.value)}
                  placeholder="Ex: Semana Educativa da Floresta, Série Robôs 2025..."
                  className="input-studio text-sm"
                />
              </div>

              {/* Universe Selector */}
              <div>
                <label className="block text-xs font-semibold text-studio-text-dim mb-1.5">
                  Universo & World Building Vinculado
                </label>
                <select
                  value={selectedUniverseId}
                  onChange={(e) => setSelectedUniverseId(e.target.value)}
                  className="input-studio text-sm"
                >
                  {universes.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.name} ({u.targetAgeGroup} · {u.genre})
                    </option>
                  ))}
                </select>
              </div>

              {/* Batch Size Selector */}
              <div>
                <label className="block text-xs font-semibold text-studio-text-dim mb-2">
                  Volume de Produção (Batch Size)
                </label>
                <div className="grid grid-cols-4 gap-3">
                  {([5, 10, 20, 50] as BatchSize[]).map((size) => (
                    <button
                      key={size}
                      type="button"
                      onClick={() => setBatchSize(size)}
                      className={cn(
                        "p-4 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all duration-200",
                        batchSize === size
                          ? "bg-studio-gold/15 border-studio-gold text-studio-gold ring-1 ring-studio-gold/50 shadow-md"
                          : "bg-studio-panel border-studio-border text-studio-text-muted hover:border-studio-border-light hover:text-studio-text"
                      )}
                    >
                      <span className="text-xl font-bold font-mono">{size}</span>
                      <span className="text-[10px] uppercase font-semibold">Conteúdos</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Launch Button */}
            <div className="pt-2">
              <button
                type="button"
                onClick={handleStartBatch}
                className="btn-gold w-full py-3 gap-2 text-sm justify-center shadow-lg"
              >
                <Play className="w-4 h-4 fill-current" />
                Iniciar Lote com Amostra e Quality Gate ({batchSize} Itens)
              </button>
            </div>
          </div>

          {/* Right Resource Breakdown Sidebar */}
          <div className="studio-card p-6 space-y-4 flex flex-col justify-between">
            <div>
              <h4 className="text-xs font-bold text-studio-text uppercase tracking-wider mb-3">
                Previsão de Recursos & Custos
              </h4>
              <div className="space-y-3 text-xs">
                <div className="flex justify-between p-2.5 rounded-lg bg-studio-panel border border-studio-border">
                  <span className="text-studio-text-muted">Custo Total Previsto:</span>
                  <span className="font-bold text-studio-gold font-mono">${costEstimate.estimatedCostUsd} USD</span>
                </div>
                <div className="flex justify-between p-2.5 rounded-lg bg-studio-panel border border-studio-border">
                  <span className="text-studio-text-muted">Tokens LLM (Gemini):</span>
                  <span className="font-bold text-studio-text font-mono">~{costEstimate.tokenCount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between p-2.5 rounded-lg bg-studio-panel border border-studio-border">
                  <span className="text-studio-text-muted">Minutos de Voz (ElevenLabs):</span>
                  <span className="font-bold text-studio-text font-mono">{costEstimate.audioMinutes} min</span>
                </div>
                <div className="flex justify-between p-2.5 rounded-lg bg-studio-panel border border-studio-border">
                  <span className="text-studio-text-muted">Renders de Imagem (Imagen 3):</span>
                  <span className="font-bold text-studio-text font-mono">{costEstimate.imageRendersCount} quadros</span>
                </div>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5" />
              <span>
                <strong>Quality Gate Ativo</strong>: O lote completo só será gerado após você avaliar e aprovar a Amostra 1.
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Active Job Progress & Quality Gate Evaluation */}
      {activeJob && (
        <div className="studio-card p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-studio-border">
            <div>
              <span className="text-[10px] font-mono text-studio-gold uppercase font-bold">
                Lote em Execução · {activeJob.batchSize} Conteúdos
              </span>
              <h3 className="text-lg font-bold text-studio-text font-display">
                {activeJob.title}
              </h3>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono px-2.5 py-1 rounded-full bg-studio-panel border border-studio-border text-studio-text">
                Status: <strong>{activeJob.status}</strong>
              </span>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs text-studio-text-muted font-mono">
              <span>{activeJob.currentStepDescription}</span>
              <span>{activeJob.progressPercent}%</span>
            </div>
            <div className="h-2 rounded-full bg-studio-panel overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-studio-blue via-studio-gold to-emerald-400 transition-all duration-500"
                style={{ width: `${activeJob.progressPercent}%` }}
              />
            </div>
          </div>

          {/* Sample 1 Card & Quality Gate Review */}
          {activeJob.items.length > 0 && activeJob.items[0] && (
            <div className="p-5 rounded-xl bg-studio-panel border border-studio-border space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-studio-gold/20 text-studio-gold flex items-center justify-center font-bold text-xs font-mono">
                    #1
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-studio-text">
                      {activeJob.items[0].title}
                    </h4>
                    <span className="text-[10px] text-studio-text-muted">
                      Amostra Piloto para Validação de Tom, Pacing e Retenção
                    </span>
                  </div>
                </div>
                {activeJob.items[0].sampleQualityGate && (
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-emerald-400 px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      Quality Gate: {activeJob.items[0].sampleQualityGate.overallScore}/100
                    </span>
                  </div>
                )}
              </div>

              {/* Gate Dimensions Breakdown */}
              {activeJob.items[0].sampleQualityGate && (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
                  {Object.entries(activeJob.items[0].sampleQualityGate.dimensions).map(([key, val]) => (
                    <div key={key} className="p-2.5 rounded-lg bg-studio-surface border border-studio-border/60 text-center">
                      <span className="text-[10px] text-studio-text-muted block capitalize truncate">
                        {key.replace(/([A-Z])/g, " $1")}
                      </span>
                      <span className="text-sm font-bold font-mono text-studio-gold">{val}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Sample Actions */}
              {activeJob.status === "SAMPLE_EVALUATION" && (
                <div className="flex flex-col sm:flex-row items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setActiveJob(null)}
                    className="btn-secondary text-xs py-2 px-4 w-full sm:w-auto"
                  >
                    Descartar e Ajustar Parâmetros
                  </button>
                  <button
                    type="button"
                    disabled={isProcessing}
                    onClick={handleApproveSampleAndRollout}
                    className="btn-gold text-xs py-2 px-5 gap-2 w-full sm:w-auto"
                  >
                    {isProcessing ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <Check className="w-4 h-4" />
                    )}
                    Aprovar Amostra e Produzir Restante do Lote ({activeJob.batchSize - 1} Itens)
                  </button>
                </div>
              )}

              {activeJob.status === "COMPLETED" && (
                <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4" />
                    Lote de {activeJob.batchSize} conteúdos produzido e injetado com sucesso no Pipeline da Content Factory!
                  </span>
                  <button
                    type="button"
                    onClick={() => setActiveJob(null)}
                    className="btn-secondary text-[11px] py-1.5 px-3"
                  >
                    + Criar Novo Lote
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Safety Confirmation Modal */}
      {showConfirmModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-studio-surface border border-studio-border max-w-md w-full rounded-2xl p-6 space-y-4">
            <div className="flex items-center gap-3 text-studio-gold">
              <div className="w-10 h-10 rounded-xl bg-studio-gold/10 border border-studio-gold/30 flex items-center justify-center">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-studio-text font-display">
                  Confirmação de Produção em Lote
                </h3>
                <span className="text-xs text-studio-text-muted">
                  Autorização do Criador Sadraque Ngola
                </span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-studio-panel border border-studio-border space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-studio-text-muted">Quantidade de Conteúdos:</span>
                <span className="font-bold text-studio-text">{batchSize} itens</span>
              </div>
              <div className="flex justify-between">
                <span className="text-studio-text-muted">Universo:</span>
                <span className="font-bold text-studio-text">{selectedUniverse?.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-studio-text-muted">Orçamento Estimado:</span>
                <span className="font-bold text-studio-gold font-mono">${costEstimate.estimatedCostUsd} USD</span>
              </div>
              <div className="flex justify-between">
                <span className="text-studio-text-muted">Garantia:</span>
                <span className="text-emerald-400 font-semibold">Quality Gate Amostra 1</span>
              </div>
            </div>

            <p className="text-[11px] text-studio-text-muted leading-relaxed">
              O sistema gerará inicialmente a Amostra 1 para sua aprovação. Somente após seu sinal verde, o restante dos {batchSize - 1} conteúdos será produzido em lote.
            </p>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                className="btn-secondary text-xs py-2 px-4"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmBudgetAndStart}
                className="btn-gold text-xs py-2 px-5 gap-1.5"
              >
                Confirmar & Iniciar
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
