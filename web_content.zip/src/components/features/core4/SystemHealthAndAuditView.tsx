import { useState } from "react";
import type {
  SystemHealthOverview,
  AutonomyLevel,
  GlobalActivityLogEntry,
  EmergencyStopState,
} from "@/types/core4";
import {
  getSystemHealth,
  AUTONOMY_LEVELS_META,
  triggerEmergencyStop,
  resumeFromEmergencyStop,
} from "@/lib/core4/systemHealthEngine";
import {
  getActivityLogs,
  getEmergencyStopState,
  getAutonomyLevel,
  setAutonomyLevel,
} from "@/lib/core4/contentFactoryStore";
import { getAllCostRecommendations, getFallbackHistory } from "@/lib/core4/costOptimizationEngine";
import { cn } from "@/lib/utils";
import {
  Activity, ShieldAlert, Cpu, DollarSign, RefreshCw, CheckCircle2,
  AlertTriangle, ShieldCheck, Zap, Lock, Unlock, Server, History
} from "lucide-react";

export default function SystemHealthAndAuditView() {
  const [health] = useState<SystemHealthOverview>(getSystemHealth());
  const [autonomy, setAutonomy] = useState<AutonomyLevel>(getAutonomyLevel());
  const [emergencyState, setEmergencyState] = useState<EmergencyStopState>(getEmergencyStopState());
  const [logs, setLogs] = useState<GlobalActivityLogEntry[]>(getActivityLogs());
  const [costRecommendations] = useState(getAllCostRecommendations());
  const [fallbackEvents] = useState(getFallbackHistory());
  const [authModalLevel, setAuthModalLevel] = useState<AutonomyLevel | null>(null);

  const handleToggleEmergencyStop = () => {
    if (emergencyState.isActive) {
      const state = resumeFromEmergencyStop();
      setEmergencyState(state);
      setLogs(getActivityLogs());
    } else {
      const state = triggerEmergencyStop();
      setEmergencyState(state);
      setLogs(getActivityLogs());
    }
  };

  const handleSelectAutonomy = (level: AutonomyLevel) => {
    const meta = AUTONOMY_LEVELS_META[level];
    if (meta.requiresExplicitAuthorization) {
      setAuthModalLevel(level);
    } else {
      setAutonomyLevel(level);
      setAutonomy(level);
      setLogs(getActivityLogs());
    }
  };

  const handleConfirmAutonomyLevel = () => {
    if (authModalLevel !== null) {
      setAutonomyLevel(authModalLevel);
      setAutonomy(authModalLevel);
      setLogs(getActivityLogs());
      setAuthModalLevel(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Emergency Stop Banner */}
      <div className={cn(
        "p-6 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4",
        emergencyState.isActive
          ? "bg-red-500/15 border-red-500/50 shadow-lg shadow-red-500/10"
          : "bg-studio-surface border-studio-border"
      )}>
        <div className="flex items-center gap-3">
          <div className={cn(
            "w-12 h-12 rounded-xl flex items-center justify-center text-xl shrink-0 font-bold",
            emergencyState.isActive ? "bg-red-500 text-white animate-pulse" : "bg-studio-panel text-studio-gold border border-studio-border"
          )}>
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-studio-text font-display">
                {emergencyState.isActive ? "🚨 PARADA DE EMERGÊNCIA ATIVADA" : "Controle Global de Operações"}
              </h3>
              <span className={cn(
                "text-[10px] px-2 py-0.5 rounded-full font-mono font-bold",
                emergencyState.isActive ? "bg-red-500/20 text-red-400" : "bg-emerald-500/20 text-emerald-400"
              )}>
                {emergencyState.isActive ? "OPERAÇÕES CONGELADAS" : "OPERACIONAL"}
              </span>
            </div>
            <p className="text-xs text-studio-text-muted mt-0.5">
              {emergencyState.isActive
                ? `Todas as operações de geração, edição e publicação foram pausadas por ${emergencyState.triggeredBy}. Projetos preservados: ${emergencyState.preservedProjectsCount}.`
                : "Sistema pronto para produção autônoma e assistida. Todos os projetos e custos permanecem sob controle do proprietário."}
            </p>
          </div>
        </div>

        <button
          onClick={handleToggleEmergencyStop}
          className={cn(
            "btn text-xs py-2.5 px-5 font-bold shrink-0 transition-all",
            emergencyState.isActive
              ? "bg-emerald-500 hover:bg-emerald-600 text-black shadow-md"
              : "bg-red-500/20 hover:bg-red-500 text-red-300 hover:text-white border border-red-500/40"
          )}
        >
          {emergencyState.isActive ? "Restabelecer Operações" : "Ativar Parada de Emergência"}
        </button>
      </div>

      {/* Grid: Autonomy Levels & System Services Health */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Autonomy Level Control (0 to 5) */}
        <div className="studio-card p-6 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-studio-border">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-studio-gold" />
              <h3 className="text-sm font-bold text-studio-text font-display">Níveis de Autonomia</h3>
            </div>
            <span className="text-xs font-mono font-bold text-studio-gold">
              LEVEL {autonomy} ATIVO
            </span>
          </div>

          <div className="space-y-2">
            {([0, 1, 2, 3, 4, 5] as AutonomyLevel[]).map((lvl) => {
              const meta = AUTONOMY_LEVELS_META[lvl];
              const isSelected = autonomy === lvl;

              return (
                <div
                  key={lvl}
                  onClick={() => handleSelectAutonomy(lvl)}
                  className={cn(
                    "p-3 rounded-xl border cursor-pointer transition-all space-y-1",
                    isSelected
                      ? "bg-studio-gold/15 border-studio-gold text-studio-text ring-1 ring-studio-gold/50 shadow-xs"
                      : "bg-studio-panel/60 border-studio-border text-studio-text-muted hover:border-studio-border-light hover:text-studio-text"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold font-mono">
                      {meta.name}
                    </span>
                    {meta.requiresExplicitAuthorization ? (
                      <Lock className="w-3.5 h-3.5 text-amber-400" />
                    ) : (
                      <Unlock className="w-3.5 h-3.5 text-studio-text-muted" />
                    )}
                  </div>
                  <p className="text-[11px] text-studio-text-dim leading-snug">
                    {meta.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Services & Providers Health Matrix */}
        <div className="lg:col-span-2 studio-card p-6 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-studio-border">
            <div className="flex items-center gap-2">
              <Server className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-bold text-studio-text font-display">
                Saúde dos Provedores & Serviços ({health.services.length})
              </h3>
            </div>
            <span className="text-xs font-mono text-emerald-400 font-bold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              Status Geral: ONLINE
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {health.services.map((srv, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-xl bg-studio-panel border border-studio-border space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-studio-text">{srv.name}</h4>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 font-mono font-bold">
                    {srv.status}
                  </span>
                </div>
                <p className="text-[11px] text-studio-text-muted">
                  {srv.details}
                </p>
                <div className="text-[10px] font-mono text-studio-text-dim flex justify-between pt-1 border-t border-studio-border/50">
                  <span>Latência: {srv.latencyMs}ms</span>
                  <span>{srv.serviceCategory}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Cost Optimization & Activity Log Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Cost Optimization Recommendations */}
        <div className="studio-card p-6 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-studio-border">
            <div className="flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-studio-gold" />
              <h3 className="text-sm font-bold text-studio-text font-display">
                Otimizador de Custos por Provedor
              </h3>
            </div>
            <span className="text-xs font-mono text-studio-gold font-bold">
              Economia Prevista: ~30%
            </span>
          </div>

          <div className="space-y-3">
            {costRecommendations.map((rec, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-xl bg-studio-panel border border-studio-border space-y-2 text-xs"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-studio-gold font-bold uppercase text-[10px]">
                    {rec.taskType}
                  </span>
                  <span className="text-[10px] font-mono text-emerald-400 font-bold">
                    -{rec.estimatedSavingsPercent}% Custo
                  </span>
                </div>
                <div className="flex items-center justify-between font-semibold text-studio-text">
                  <span>Recomendado: {rec.suggestedProvider}</span>
                </div>
                <p className="text-[11px] text-studio-text-muted">
                  {rec.reason}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Global Activity Audit Log */}
        <div className="studio-card p-6 space-y-4 flex flex-col h-[480px]">
          <div className="flex items-center justify-between pb-2 border-b border-studio-border">
            <div className="flex items-center gap-2">
              <History className="w-4 h-4 text-studio-blue" />
              <h3 className="text-sm font-bold text-studio-text font-display">
                Registro Global de Atividades (Auditoria)
              </h3>
            </div>
            <span className="text-xs font-mono text-studio-text-muted">
              {logs.length} Eventos
            </span>
          </div>

          <div className="flex-1 overflow-y-auto space-y-2.5 custom-scrollbar pr-1">
            {logs.map((log) => (
              <div
                key={log.id}
                className="p-3 rounded-lg bg-studio-panel border border-studio-border/70 text-xs space-y-1"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono text-studio-gold font-bold uppercase">
                    [{log.category}] · {log.actor}
                  </span>
                  <span className="text-[9px] font-mono text-studio-text-muted">
                    {new Date(log.timestamp).toLocaleTimeString()}
                  </span>
                </div>
                <p className="text-studio-text-dim text-[11px] leading-relaxed">
                  {log.message}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Autonomy Level Confirmation Modal */}
      {authModalLevel !== null && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-studio-surface border border-studio-border max-w-md w-full rounded-2xl p-6 space-y-4">
            <div className="flex items-center gap-3 text-studio-gold">
              <Lock className="w-6 h-6" />
              <h3 className="text-base font-bold text-studio-text font-display">
                Autorização do Proprietário
              </h3>
            </div>

            <p className="text-xs text-studio-text-dim leading-relaxed">
              Você está elevando a autonomia do estúdio para <strong>Level {authModalLevel}</strong> ({AUTONOMY_LEVELS_META[authModalLevel].name}).
              Isso autoriza a IA a realizar etapas avançadas de produção em lote com controle por Quality Gate.
            </p>

            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setAuthModalLevel(null)}
                className="btn-secondary text-xs py-2 px-4"
              >
                Cancelar
              </button>
              <button
                onClick={handleConfirmAutonomyLevel}
                className="btn-gold text-xs py-2 px-5"
              >
                Autorizar Level {authModalLevel}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
