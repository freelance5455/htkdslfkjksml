import { useState } from "react";
import type { CreatorKnowledgeGraphData, KnowledgeGraphNode } from "@/types/core4";
import { buildCreatorKnowledgeGraph } from "@/lib/core4/creatorKnowledgeGraph";
import { cn } from "@/lib/utils";
import {
  Share2, Globe2, User, Film, Tv2, Tag, Info, Filter,
  Sparkles, Layers
} from "lucide-react";

export default function KnowledgeGraphView() {
  const [graphData] = useState<CreatorKnowledgeGraphData>(buildCreatorKnowledgeGraph());
  const [selectedNode, setSelectedNode] = useState<KnowledgeGraphNode | null>(graphData.nodes[0] || null);
  const [filterType, setFilterType] = useState<string>("ALL");

  const filteredNodes = filterType === "ALL"
    ? graphData.nodes
    : graphData.nodes.filter((n) => n.type === filterType);

  const relatedEdges = selectedNode
    ? graphData.edges.filter((e) => e.source === selectedNode.id || e.target === selectedNode.id)
    : [];

  const getNodeIcon = (type: KnowledgeGraphNode["type"]) => {
    switch (type) {
      case "UNIVERSE": return Globe2;
      case "CHARACTER": return User;
      case "PROJECT": return Film;
      case "PLATFORM": return Tv2;
      case "TOPIC": return Tag;
      default: return Layers;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-studio-surface p-6 rounded-2xl border border-studio-border flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-studio-gold/10 text-studio-gold border border-studio-gold/30 uppercase">
              CORE 4.0 · KNOWLEDGE GRAPH
            </span>
          </div>
          <h2 className="text-xl font-bold text-studio-text font-display">
            Grafo de Conhecimento do Criador
          </h2>
          <p className="text-xs text-studio-text-muted mt-1">
            Mapeamento relacional conectando Universos, Personagens, Projetos, Plataformas e Tópicos de Alto Engajamento.
          </p>
        </div>

        {/* Filter Chips */}
        <div className="flex items-center gap-1.5 p-1 rounded-lg bg-studio-panel border border-studio-border overflow-x-auto">
          {["ALL", "UNIVERSE", "CHARACTER", "PROJECT", "PLATFORM", "TOPIC"].map((t) => (
            <button
              key={t}
              onClick={() => setFilterType(t)}
              className={cn(
                "text-[11px] font-semibold px-2.5 py-1 rounded-md transition-all whitespace-nowrap",
                filterType === t
                  ? "bg-studio-gold text-black shadow-xs"
                  : "text-studio-text-muted hover:text-studio-text"
              )}
            >
              {t === "ALL" ? "Todos os Nós" : t}
            </button>
          ))}
        </div>
      </div>

      {/* Main Graph Grid & Node Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Nodes Visual Matrix */}
        <div className="lg:col-span-2 studio-card p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-studio-text font-display flex items-center gap-2">
              <Share2 className="w-4 h-4 text-studio-gold" />
              Nós Mapeados ({filteredNodes.length} de {graphData.nodes.length})
            </h3>
            <span className="text-xs font-mono text-studio-text-muted">
              {graphData.edges.length} Relações Ativas
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {filteredNodes.map((node) => {
              const Icon = getNodeIcon(node.type);
              const isSelected = selectedNode?.id === node.id;

              return (
                <div
                  key={node.id}
                  onClick={() => setSelectedNode(node)}
                  className={cn(
                    "p-3.5 rounded-xl border cursor-pointer transition-all duration-200 space-y-2 flex flex-col justify-between group",
                    isSelected
                      ? "bg-studio-panel border-studio-gold ring-1 ring-studio-gold/50 shadow-md"
                      : "bg-studio-panel/60 border-studio-border/80 hover:border-studio-gold/40 hover:bg-studio-panel"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <div
                      className="w-7 h-7 rounded-lg flex items-center justify-center text-xs"
                      style={{ backgroundColor: `${node.color || "#FFB800"}20`, color: node.color || "#FFB800" }}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded-xs bg-studio-surface border border-studio-border/60 text-studio-text-muted">
                      {node.type}
                    </span>
                  </div>

                  <div>
                    <h4 className="text-xs font-bold text-studio-text line-clamp-2 group-hover:text-studio-gold transition-colors">
                      {node.label}
                    </h4>
                    {node.metric && (
                      <span className="text-[10px] font-mono text-emerald-400 block mt-1">
                        {node.metric}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Node Details & Relationship Inspector */}
        <div className="studio-card p-6 space-y-5">
          {selectedNode ? (
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center text-black font-bold"
                  style={{ backgroundColor: selectedNode.color || "#FFB800" }}
                >
                  {selectedNode.label[0]}
                </div>
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-widest text-studio-gold font-bold">
                    {selectedNode.type}
                  </span>
                  <h3 className="text-base font-bold text-studio-text font-display">
                    {selectedNode.label}
                  </h3>
                </div>
              </div>

              {selectedNode.metric && (
                <div className="p-3 rounded-xl bg-studio-panel border border-studio-border text-xs">
                  <span className="text-studio-text-muted block text-[10px]">Métrica / Status:</span>
                  <span className="text-emerald-400 font-mono font-bold text-sm">{selectedNode.metric}</span>
                </div>
              )}

              {/* Connected Relationships */}
              <div className="space-y-2 pt-2 border-t border-studio-border">
                <h4 className="text-xs font-bold text-studio-text uppercase tracking-wider">
                  Relações no Grafo ({relatedEdges.length})
                </h4>

                <div className="space-y-2 max-h-72 overflow-y-auto custom-scrollbar pr-1">
                  {relatedEdges.map((edge) => {
                    const isSource = edge.source === selectedNode.id;
                    const otherNodeId = isSource ? edge.target : edge.source;
                    const otherNode = graphData.nodes.find((n) => n.id === otherNodeId);

                    return (
                      <div
                        key={edge.id}
                        onClick={() => otherNode && setSelectedNode(otherNode)}
                        className="p-2.5 rounded-lg bg-studio-panel border border-studio-border/60 text-xs flex items-center justify-between cursor-pointer hover:border-studio-gold/40 transition-colors"
                      >
                        <div className="space-y-0.5">
                          <span className="text-[9px] font-mono text-studio-gold uppercase font-bold block">
                            {(edge.relation || "").replace(/_/g, " ")}
                          </span>
                          <span className="font-semibold text-studio-text">
                            {otherNode?.label || otherNodeId}
                          </span>
                        </div>
                        <span className="text-[10px] text-studio-text-muted font-mono">
                          {otherNode?.type} →
                        </span>
                      </div>
                    );
                  })}

                  {relatedEdges.length === 0 && (
                    <p className="text-xs text-studio-text-muted">Nenhuma relação direta conectada a este nó.</p>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="p-8 text-center text-studio-text-muted text-xs">
              Selecione um nó ao lado para inspecionar suas conexões e relações.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
