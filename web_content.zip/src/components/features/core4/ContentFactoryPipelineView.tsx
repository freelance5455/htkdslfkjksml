import { useState } from "react";
import type { ElementType } from "react";
import type { ContentFactoryItem, ContentFactoryStage } from "@/types/core4";
import { getFactoryItems, updateFactoryItemStage } from "@/lib/core4/contentFactoryStore";
import { cn } from "@/lib/utils";
import {
  Lightbulb, Calendar, FileText, Clapperboard, Sparkles,
  Scissors, CheckSquare, CheckCircle, Clock, Share2, BarChart2,
  ChevronRight, ArrowRight, ShieldCheck, Star, Layers, Eye
} from "lucide-react";

const STAGES: { key: ContentFactoryStage; label: string; icon: ElementType; color: string }[] = [
  { key: "IDEAS", label: "Ideias", icon: Lightbulb, color: "text-amber-400 border-amber-500/30" },
  { key: "PLANNED", label: "Planejado", icon: Calendar, color: "text-blue-400 border-blue-500/30" },
  { key: "SCRIPT", label: "Roteiro", icon: FileText, color: "text-indigo-400 border-indigo-500/30" },
  { key: "STORYBOARD", label: "Storyboard", icon: Clapperboard, color: "text-purple-400 border-purple-500/30" },
  { key: "PRODUCTION", label: "Produção", icon: Sparkles, color: "text-yellow-400 border-yellow-500/30" },
  { key: "EDITING", label: "Edição IA", icon: Scissors, color: "text-pink-400 border-pink-500/30" },
  { key: "REVIEW", label: "Revisão / Gate", icon: CheckSquare, color: "text-orange-400 border-orange-500/30" },
  { key: "READY", label: "Pronto", icon: CheckCircle, color: "text-emerald-400 border-emerald-500/30" },
  { key: "SCHEDULED", label: "Agendado", icon: Clock, color: "text-cyan-400 border-cyan-500/30" },
  { key: "PUBLISHED", label: "Publicado", icon: Share2, color: "text-green-400 border-green-500/30" },
  { key: "ANALYTICS", label: "Learning & Dados", icon: BarChart2, color: "text-violet-400 border-violet-500/30" },
];

export default function ContentFactoryPipelineView({
  onSelectProject,
}: {
  onSelectProject?: (item: ContentFactoryItem) => void;
}) {
  const [items, setItems] = useState<ContentFactoryItem[]>(getFactoryItems());
  const [selectedItem, setSelectedItem] = useState<ContentFactoryItem | null>(null);
  const [filterUniverse, setFilterUniverse] = useState<string>("ALL");

  const handleAdvanceStage = (item: ContentFactoryItem) => {
    const currentIdx = STAGES.findIndex((s) => s.key === item.stage);
    if (currentIdx < STAGES.length - 1) {
      const nextStage = STAGES[currentIdx + 1].key;
      updateFactoryItemStage(item.id, nextStage);
      setItems(getFactoryItems());
    }
  };

  const filteredItems = filterUniverse === "ALL"
    ? items
    : items.filter((i) => i.universeId === filterUniverse);

  return (
    <div className="space-y-6">
      {/* Header & Filter Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-studio-surface/80 p-4 rounded-xl border border-studio-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-studio-gold/10 border border-studio-gold/30 flex items-center justify-center text-studio-gold">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-studio-text font-display">Pipeline da Content Factory</h3>
            <p className="text-xs text-studio-text-muted">
              Fluxo contínuo em 11 etapas: Ideias → Produção → Quality Gate → Publicação → Analytics
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-studio-text-muted">Universo:</span>
          <select
            value={filterUniverse}
            onChange={(e) => setFilterUniverse(e.target.value)}
            className="bg-studio-panel border border-studio-border text-studio-text text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:border-studio-gold"
          >
            <option value="ALL">Todos os Universos ({items.length})</option>
            <option value="univ-kids-forest">A Floresta dos Animais Mágicos</option>
            <option value="univ-future-tech">Cyber Horizon: IA & Futuro</option>
          </select>
        </div>
      </div>

      {/* 11-Stage Kanban Pipeline Grid */}
      <div className="overflow-x-auto pb-4 custom-scrollbar">
        <div className="flex gap-3 min-w-[1400px]">
          {STAGES.map((stage, idx) => {
            const stageItems = filteredItems.filter((i) => i.stage === stage.key);
            const Icon = stage.icon;

            return (
              <div
                key={stage.key}
                className="flex-1 min-w-[180px] bg-studio-surface/60 rounded-xl border border-studio-border flex flex-col h-[560px]"
              >
                {/* Column Header */}
                <div className="p-3 border-b border-studio-border/60 flex items-center justify-between bg-studio-panel/40 rounded-t-xl">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] font-mono text-studio-text-muted font-bold">
                      {(idx + 1).toString().padStart(2, "0")}
                    </span>
                    <Icon className={cn("w-3.5 h-3.5", stage.color.split(" ")[0])} />
                    <span className="text-xs font-semibold text-studio-text">{stage.label}</span>
                  </div>
                  <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-studio-surface font-mono text-studio-text-muted border border-studio-border">
                    {stageItems.length}
                  </span>
                </div>

                {/* Cards Container */}
                <div className="p-2 space-y-2 flex-1 overflow-y-auto custom-scrollbar">
                  {stageItems.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => setSelectedItem(item)}
                      className={cn(
                        "p-3 rounded-lg bg-studio-panel/90 border border-studio-border/80 hover:border-studio-gold/50 cursor-pointer transition-all duration-200 shadow-xs hover:shadow-md space-y-2 group",
                        selectedItem?.id === item.id && "border-studio-gold ring-1 ring-studio-gold/40"
                      )}
                    >
                      {item.thumbnailUrl && (
                        <div className="relative rounded-md overflow-hidden aspect-video bg-black/40">
                          <img
                            src={item.thumbnailUrl}
                            alt=""
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute top-1 right-1 px-1.5 py-0.5 rounded-xs bg-black/80 backdrop-blur-xs text-[9px] font-mono text-studio-gold border border-studio-gold/30">
                            {item.targetPlatform}
                          </div>
                        </div>
                      )}

                      <h4 className="text-xs font-semibold text-studio-text line-clamp-2 leading-snug">
                        {item.title}
                      </h4>

                      <div className="flex items-center justify-between text-[10px] text-studio-text-muted pt-1 border-t border-studio-border/40">
                        <span className="flex items-center gap-1 text-emerald-400">
                          <ShieldCheck className="w-3 h-3" />
                          {item.brandConsistencyScore}% Marca
                        </span>

                        {idx < STAGES.length - 1 && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleAdvanceStage(item);
                            }}
                            title="Avançar para o próximo estágio"
                            className="p-1 rounded-sm bg-studio-gold/10 text-studio-gold hover:bg-studio-gold hover:text-black transition-colors"
                          >
                            <ChevronRight className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}

                  {stageItems.length === 0 && (
                    <div className="h-28 flex flex-col items-center justify-center text-center p-3 text-studio-text-muted/50 border border-dashed border-studio-border/40 rounded-lg">
                      <span className="text-[11px]">Nenhum item</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Item Drawer / Detail Modal */}
      {selectedItem && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-studio-surface border border-studio-border max-w-2xl w-full rounded-2xl p-6 space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] uppercase font-mono tracking-widest text-studio-gold">
                  Estágio Atual: {selectedItem.stage}
                </span>
                <h3 className="text-lg font-bold text-studio-text font-display mt-0.5">
                  {selectedItem.title}
                </h3>
              </div>
              <button
                onClick={() => setSelectedItem(null)}
                className="text-studio-text-muted hover:text-studio-text text-sm p-1"
              >
                ✕ Fechar
              </button>
            </div>

            {/* DNA Breakdown */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 bg-studio-panel p-4 rounded-xl border border-studio-border text-xs">
              <div>
                <span className="text-studio-text-muted block text-[10px]">Tópico / Tema</span>
                <span className="text-studio-text font-semibold">{selectedItem.dna.topic}</span>
              </div>
              <div>
                <span className="text-studio-text-muted block text-[10px]">Tom & Voz</span>
                <span className="text-studio-text font-semibold">{selectedItem.dna.tone} · {selectedItem.dna.voiceProfile.voiceName}</span>
              </div>
              <div>
                <span className="text-studio-text-muted block text-[10px]">Formato & Ritmo</span>
                <span className="text-studio-text font-semibold">{selectedItem.dna.format} · {selectedItem.dna.pacing}</span>
              </div>
              <div>
                <span className="text-studio-text-muted block text-[10px]">Paleta de Cores</span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: selectedItem.dna.branding.primaryColor }} />
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: selectedItem.dna.branding.secondaryColor }} />
                  <span className="text-studio-text">{selectedItem.dna.branding.primaryColor}</span>
                </div>
              </div>
              <div>
                <span className="text-studio-text-muted block text-[10px]">Score de Marca</span>
                <span className="text-emerald-400 font-bold">{selectedItem.brandConsistencyScore}/100</span>
              </div>
              <div>
                <span className="text-studio-text-muted block text-[10px]">Continuidade de História</span>
                <span className="text-studio-blue font-bold">{selectedItem.continuityChecked ? "Verificada ✓" : "Pendente"}</span>
              </div>
            </div>

            {/* Variations Generated */}
            {selectedItem.variations.titles.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-studio-text uppercase tracking-wider flex items-center gap-1.5">
                  <Star className="w-3.5 h-3.5 text-studio-gold" />
                  Variantes de Título & CTR Previsto (A/B/C)
                </h4>
                <div className="space-y-1.5">
                  {selectedItem.variations.titles.map((vt) => (
                    <div
                      key={vt.id}
                      className={cn(
                        "p-2.5 rounded-lg border text-xs flex items-center justify-between",
                        vt.isWinningVariant
                          ? "bg-studio-gold/10 border-studio-gold/40 text-studio-text"
                          : "bg-studio-panel border-studio-border text-studio-text-muted"
                      )}
                    >
                      <span className="flex items-center gap-2">
                        <span className="font-mono font-bold text-studio-gold">[{vt.variantKey}]</span>
                        {vt.content}
                      </span>
                      {vt.predictedCtrScore && (
                        <span className="text-[11px] font-mono text-emerald-400 font-bold shrink-0">
                          {vt.predictedCtrScore}% CTR
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Quality Gate Sample Evaluation */}
            {selectedItem.sampleQualityGate && (
              <div className="p-4 rounded-xl bg-studio-gold/5 border border-studio-gold/30 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-studio-gold flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4" />
                    Quality Gate IA — Score Geral: {selectedItem.sampleQualityGate.overallScore}/100
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold">
                    {selectedItem.sampleQualityGate.status}
                  </span>
                </div>
                <p className="text-xs text-studio-text-dim">
                  {selectedItem.sampleQualityGate.evaluationSummary}
                </p>
              </div>
            )}

            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setSelectedItem(null)}
                className="btn-secondary text-xs py-2 px-4"
              >
                Fechar
              </button>
              <button
                onClick={() => {
                  handleAdvanceStage(selectedItem);
                  setSelectedItem(null);
                }}
                className="btn-gold text-xs py-2 px-4 gap-1.5"
              >
                Avançar Estágio
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
