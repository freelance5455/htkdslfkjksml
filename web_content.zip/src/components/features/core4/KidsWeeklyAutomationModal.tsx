import { useState } from "react";
import { runKidsWeeklyScenario, KIDS_SCENARIO_STEPS, ScenarioStepProgress } from "@/lib/core4/kidsChannelScenarioRunner";
import { cn } from "@/lib/utils";
import {
  Sparkles, CheckCircle2, RefreshCw, Layers, ShieldCheck,
  Film, Calendar, ArrowRight, X, Play
} from "lucide-react";

export default function KidsWeeklyAutomationModal({
  isOpen,
  onClose,
  onFinished,
}: {
  isOpen: boolean;
  onClose: () => void;
  onFinished?: () => void;
}) {
  const [isRunning, setIsRunning] = useState(false);
  const [currentStep, setCurrentStep] = useState<ScenarioStepProgress | null>(null);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const [isCompleted, setIsCompleted] = useState(false);

  if (!isOpen) return null;

  const handleStartScenario = async () => {
    setIsRunning(true);
    setCompletedSteps([]);
    setIsCompleted(false);

    await runKidsWeeklyScenario((progress) => {
      setCurrentStep({ ...progress });
      if (progress.status === "COMPLETED") {
        setCompletedSteps((prev) => [...prev, progress.stepNumber]);
      }
    });

    setIsRunning(false);
    setIsCompleted(true);
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-studio-surface border border-studio-border max-w-2xl w-full rounded-2xl p-6 space-y-5 max-h-[90vh] flex flex-col shadow-2xl">
        {/* Modal Header */}
        <div className="flex items-start justify-between pb-3 border-b border-studio-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-studio-gold/15 border border-studio-gold/30 flex items-center justify-center text-studio-gold">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-mono text-studio-gold font-bold uppercase">
                CORE 4.0 · CENÁRIO AUTOMATIZADO (17 ETAPAS)
              </span>
              <h3 className="text-base font-bold text-studio-text font-display">
                Semana Completa para o Canal Infantil
              </h3>
            </div>
          </div>

          {!isRunning && (
            <button
              onClick={onClose}
              className="text-studio-text-muted hover:text-studio-text p-1"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Initial Prompt Banner */}
        {!isRunning && !isCompleted && (
          <div className="p-4 rounded-xl bg-studio-panel border border-studio-border space-y-3 text-xs">
            <p className="text-studio-text font-medium leading-relaxed">
              Comando Solicitado: <strong>"Cria uma semana inteira de conteúdo para o meu canal infantil"</strong>
            </p>
            <p className="text-studio-text-muted leading-relaxed">
              O sistema acionará automaticamente a interpretação do Copilot, o Universo <strong>"A Floresta dos Animais Mágicos"</strong>, os personagens <strong>Pipoca e Luna</strong>, o planejamento de 5 episódios longos + 7 Shorts, avaliação pelo <strong>Quality Gate</strong>, auditorias de continuidade e agendamento editorial.
            </p>
            <div className="pt-2">
              <button
                onClick={handleStartScenario}
                className="btn-gold w-full py-3 gap-2 text-sm justify-center shadow-lg"
              >
                <Play className="w-4 h-4 fill-current" />
                Executar Cenário Completo de 17 Etapas
              </button>
            </div>
          </div>
        )}

        {/* Live Progress Bar & Steps Feed */}
        {(isRunning || isCompleted) && (
          <div className="flex-1 overflow-hidden flex flex-col space-y-4">
            {/* Progress Header */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-mono text-studio-text-muted">
                <span>
                  {isCompleted
                    ? "Todas as 17 Etapas Concluídas com Sucesso!"
                    : currentStep?.title || "Processando..."}
                </span>
                <span className="text-studio-gold font-bold">
                  {completedSteps.length} / 17
                </span>
              </div>
              <div className="h-2 rounded-full bg-studio-panel overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-studio-blue via-studio-gold to-emerald-400 transition-all duration-300"
                  style={{ width: `${(completedSteps.length / 17) * 100}%` }}
                />
              </div>
            </div>

            {/* Steps Checklist Feed */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1 custom-scrollbar max-h-72">
              {KIDS_SCENARIO_STEPS.map((step) => {
                const isStepCompleted = completedSteps.includes(step.stepNumber);
                const isStepActive = currentStep?.stepNumber === step.stepNumber && !isStepCompleted;

                return (
                  <div
                    key={step.stepNumber}
                    className={cn(
                      "p-2.5 rounded-lg border text-xs flex items-center justify-between transition-all",
                      isStepCompleted
                        ? "bg-emerald-500/10 border-emerald-500/30 text-studio-text"
                        : isStepActive
                        ? "bg-studio-gold/10 border-studio-gold/50 text-studio-gold"
                        : "bg-studio-panel/50 border-studio-border/50 text-studio-text-muted"
                    )}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="font-mono text-[10px] font-bold w-5">
                        #{step.stepNumber.toString().padStart(2, "0")}
                      </span>
                      <div>
                        <span className="font-semibold block">{step.title}</span>
                        <span className="text-[10px] text-studio-text-muted">{step.description}</span>
                      </div>
                    </div>

                    <div className="shrink-0">
                      {isStepCompleted ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : isStepActive ? (
                        <RefreshCw className="w-4 h-4 animate-spin text-studio-gold" />
                      ) : (
                        <span className="w-2 h-2 rounded-full bg-studio-border inline-block" />
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Success Summary Footer */}
            {isCompleted && (
              <div className="p-4 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs space-y-2">
                <div className="flex items-center justify-between font-bold">
                  <span>✓ 5 Vídeos Longos (Segunda a Sexta) Gerados & Agendados</span>
                  <span>✓ 7 Shorts Derivados</span>
                </div>
                <p className="text-studio-text-dim text-[11px]">
                  Todos os conteúdos foram inseridos com sucesso na <strong>Content Factory</strong> e no <strong>Calendário Editorial</strong>.
                </p>
                <div className="flex justify-end pt-1">
                  <button
                    onClick={() => {
                      if (onFinished) onFinished();
                      onClose();
                    }}
                    className="btn-gold text-xs py-2 px-5 gap-1.5"
                  >
                    Ver Pipeline da Content Factory
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
