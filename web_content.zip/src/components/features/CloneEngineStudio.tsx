import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import {
  Copy, Sparkles, Tv, Video, Music, Share2, ArrowRight, CheckCircle,
  Play, Pause, Volume2, RefreshCw, Layers, ExternalLink, Download,
  Sliders, Trash2, Plus, Film, AlertCircle, FileText, Check
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useProjects } from "@/hooks/useProjects";
import {
  getClonesHistory,
  saveCloneRecord,
  deleteCloneRecord,
  CloneRecord,
  getProjects
} from "@/lib/storage";
import { connectSocialChannel, getSocialChannels } from "@/lib/publishingScheduler";

export function CloneEngineStudio() {
  const navigate = useNavigate();
  const { createProject, projects } = useProjects();

  const [activeTab, setActiveTab] = useState<"CHANNEL" | "VIDEO" | "MUSIC" | "PLATFORM" | "HISTORY">("CHANNEL");
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // -------------------------------------------------------------
  // 1. ABA: CLONAR CANAL
  // -------------------------------------------------------------
  const [channelInput, setChannelInput] = useState("");
  const [channelNiche, setChannelNiche] = useState("CURIOSIDADES");
  const [isAnalyzingChannel, setIsAnalyzingChannel] = useState(false);
  const [clonedChannelResult, setClonedChannelResult] = useState<{
    originalRef: string;
    clonedName: string;
    handle: string;
    description: string;
    archetype: string;
    colorPalette: string[];
    thumbnailStyle: string;
    ideas: { title: string; hook: string; estRetention: string }[];
  } | null>(null);

  const PRESET_CHANNELS = [
    { name: "Mistérios & Arquivos Ocultos", ref: "@misterios.ocultos", niche: "MISTERIO" },
    { name: "Cosmos & Astronomia 8K", ref: "@curiosidades.cosmos", niche: "CIENCIA" },
    { name: "Fazendinha & Canções Kids", ref: "@fazendinha.magica", niche: "INFANTIL" },
    { name: "Finanças & Mente Próspera", ref: "@riqueza.estrategica", niche: "FINANCAS" },
    { name: "Fatos Rápidos & Bizarros", ref: "@fatos.bizarros", niche: "CURIOSIDADES" },
  ];

  const handleCloneChannel = async (refToClone?: string) => {
    const target = refToClone || channelInput;
    if (!target.trim()) return;

    setIsAnalyzingChannel(true);
    await new Promise((r) => setTimeout(r, 1200)); // Smooth AI extraction simulation

    const isKids = target.toLowerCase().includes("kids") || target.toLowerCase().includes("fazendinha") || channelNiche === "INFANTIL";
    const isCosmos = target.toLowerCase().includes("cosmos") || target.toLowerCase().includes("espaco") || channelNiche === "CIENCIA";
    const isMoney = target.toLowerCase().includes("riqueza") || target.toLowerCase().includes("financas") || channelNiche === "FINANCAS";

    const result = {
      originalRef: target,
      clonedName: isKids
        ? "Reino Encantado Kids: Histórias & Músicas"
        : isCosmos
        ? "Horizontes do Cosmos: Segredos do Universo"
        : isMoney
        ? "Mentes de Sucesso: Inteligência Financeira"
        : "Arquivos Secretos: Fatos que Chocaram o Mundo",
      handle: isKids
        ? "@reinoencantado.kids"
        : isCosmos
        ? "@horizontes.cosmos"
        : isMoney
        ? "@mentes.sucesso"
        : "@arquivos.secretos.ai",
      description: isKids
        ? "Animações 3D Pixar de animais e músicas infantis educativas para crianças e famílias."
        : isCosmos
        ? "Viagens visuais e científicas pelos maiores mistérios da astronomia, buracos negros e galáxias."
        : isMoney
        ? "Estratégias de investimento, hábitos de alta performance e mentalidade de riqueza sem rodeios."
        : "Documentários rápidos e revelações históricas com narrativa cinematográfica envolvente.",
      archetype: isKids ? "Acolhedor, Lúdico e Vibrante" : isCosmos ? "Épico, Científico e Hipnótico" : "Autoritário e Motivacional",
      colorPalette: isKids ? ["#F59E0B", "#10B981", "#3B82F6", "#EC4899"] : isCosmos ? ["#0B0F19", "#6366F1", "#EC4899", "#E0E7FF"] : ["#0F172A", "#D97706", "#1E293B", "#F8FAFC"],
      thumbnailStyle: "Contraste ultra-alto, cores saturadas, tipografia bold com borda externa e expressão de impacto centralizada.",
      ideas: isKids
        ? [
            { title: "Os Filhotes Mais Fofos Cantando no Lago Mágico", hook: "Olhe o que o patinho fez quando o gatinho começou a cantar!", estRetention: "88%" },
            { title: "A Canção do Trem das Letrinhas Divertidas", hook: "Quem sabe qual é a letra que vai aparecer agora?", estRetention: "91%" },
            { title: "Boa Noite na Fazendinha: Canção de Ninar Mágica", hook: "O sol já se pôs e todos os bichinhos vão dormir...", estRetention: "85%" },
          ]
        : isCosmos
        ? [
            { title: "O Que Acontece Se Você Cruzar o Horizonte de Eventos?", hook: "Isto é exatamente o que seus olhos veriam nos últimos segundos...", estRetention: "94%" },
            { title: "O Planeta Onde Chove Ferro Líquido Derretido", hook: "Existe um inferno real no espaço e ele fica mais perto do que pensa.", estRetention: "89%" },
            { title: "A Estrela Tão Gigante Que Engoliria Nosso Sistema Solar", hook: "Se esta estrela estivesse no lugar do Sol, a Terra nem existiria.", estRetention: "92%" },
          ]
        : [
            { title: "7 Fatos Chocantes Que Você Não Sabia Sobre o Egito Antigo", hook: "A história que te contaram na escola estava completamente errada.", estRetention: "93%" },
            { title: "O Mistério Não Resolvido da Cidade Que Sumiu do Mapa", hook: "Em 1932, 2.000 pessoas desapareceram sem deixar um único rastro.", estRetention: "95%" },
            { title: "A Criatura Que Vive a 11 Mil Metros Sob o Mar Silencioso", hook: "Cientistas desceram ao ponto mais fundo da Terra e acharam isto vivo.", estRetention: "90%" },
          ],
    };

    setClonedChannelResult(result);
    setIsAnalyzingChannel(false);

    // Save record to storage
    saveCloneRecord({
      id: `clone-ch-${Date.now()}`,
      type: "CHANNEL",
      name: result.clonedName,
      sourceUrlOrRef: target,
      resultSummary: `Canal clonado: ${result.clonedName} (${result.handle}). Arquétipo: ${result.archetype}`,
      details: result,
      createdAt: new Date().toISOString(),
    });

    showToast("Canal clonado com sucesso! Estrutura e 3 pautas geradas.");
  };

  const handleSaveChannelToMyChannels = () => {
    if (!clonedChannelResult) return;
    connectSocialChannel({
      platform: "YOUTUBE",
      name: clonedChannelResult.clonedName,
      handle: clonedChannelResult.handle,
      channelId: `UC_${clonedChannelResult.handle.replace(/[@.]/g, "_")}`,
      avatarUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&auto=format&fit=crop&q=80",
    });
    showToast(`Canal "${clonedChannelResult.clonedName}" adicionado à aba "Canais & Plataformas"!`);
  };

  const handleCreateProjectFromChannelIdea = async (ideaTitle: string) => {
    showToast(`Criando novo projeto no estúdio para "${ideaTitle}"...`);
    const newProj = await createProject(
      `Vídeo para o canal ${clonedChannelResult?.clonedName || "Clonado"}. Tema: "${ideaTitle}". Arquétipo: ${clonedChannelResult?.archetype || "Impacto"}.`
    );
    navigate(`/projects/${newProj.id}`);
  };

  // -------------------------------------------------------------
  // 2. ABA: CLONAR VÍDEO (REMAKER COM IA)
  // -------------------------------------------------------------
  const [videoRefUrl, setVideoRefUrl] = useState("");
  const [remakerStyle, setRemakerStyle] = useState("DYNAMIC_SHORTS");
  const [isCloningVideo, setIsCloningVideo] = useState(false);
  const [clonedVideoResult, setClonedVideoResult] = useState<{
    originalTitle: string;
    remadeTitle: string;
    hookComparison: { original: string; remade: string };
    scenes: { number: number; visual: string; narration: string; prompt: string }[];
  } | null>(null);

  const handleCloneVideo = async () => {
    if (!videoRefUrl.trim()) return;

    setIsCloningVideo(true);
    await new Promise((r) => setTimeout(r, 1400));

    const remade = {
      originalTitle: "Vídeo Referência: " + (videoRefUrl.length > 35 ? videoRefUrl.substring(0, 35) + "..." : videoRefUrl),
      remadeTitle: "Versão Original IA: Segredos Revelados e Curiosidades Épicas",
      hookComparison: {
        original: "Você não vai acreditar no que aconteceu com este experimento no espaço!",
        remade: "Cientistas quebraram a física ao testar isto no vácuo — e o resultado chocou o mundo!",
      },
      scenes: [
        {
          number: 1,
          visual: "Zoom hiperdinâmico com partículas de luz colidindo em 8K",
          narration: "A cada segundo, o universo está expandindo a uma velocidade que sua mente mal consegue imaginar.",
          prompt: "Cinematic cosmic particles accelerating at hyper speed into a glowing vortex, 8k resolution, Unreal Engine 5 render",
        },
        {
          number: 2,
          visual: "Comparativo holográfico em 3D de alta precisão",
          narration: "Mas o que os astrônomos detectaram na borda da galáxia mudou todas as regras da gravidade.",
          prompt: "Futuristic 3D holographic comparison of planetary orbits with glowing gravitational waves, photorealistic",
        },
        {
          number: 3,
          visual: "Clímax visual deslumbrante com chamada para inscrição e likes",
          narration: "Inscreva-se agora para continuar explorando o lado oculto do cosmos todos os dias!",
          prompt: "Stunning cosmic star explosion with glowing typography subscribe icon, ultra realistic space photography style",
        },
      ],
    };

    setClonedVideoResult(remade);
    setIsCloningVideo(false);

    saveCloneRecord({
      id: `clone-vid-${Date.now()}`,
      type: "VIDEO",
      name: remade.remadeTitle,
      sourceUrlOrRef: videoRefUrl,
      resultSummary: `Vídeo recriado: 3 cenas originais, anti-copyright garantido.`,
      details: remade,
      createdAt: new Date().toISOString(),
    });

    showToast("Vídeo clonado e roteiro reescrito com sucesso!");
  };

  const handleCreateProjectFromClonedVideo = async () => {
    if (!clonedVideoResult) return;
    showToast("Criando projeto com roteiro clonado...");
    const prompt = `Projeto Clonado Anti-Copyright: "${clonedVideoResult.remadeTitle}". Gancho: ${clonedVideoResult.hookComparison.remade}`;
    const newProj = await createProject(prompt);
    navigate(`/projects/${newProj.id}`);
  };

  // -------------------------------------------------------------
  // 3. ABA: CLONAR MÚSICA & ÁUDIO (SINTETIZADOR WEB AUDIO API)
  // -------------------------------------------------------------
  const [musicPreset, setMusicPreset] = useState("EPIC");
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const oscillatorsRef = useRef<OscillatorNode[]>([]);

  const MUSIC_PRESETS = [
    {
      id: "EPIC",
      title: "Épico & Suspense Orquestral",
      bpm: 125,
      desc: "Tons menores profundos, graves de impacto cinematográfico e ritmo tenso.",
      frequencies: [110, 130.81, 164.81, 220, 329.63],
    },
    {
      id: "LOFI",
      title: "Lo-Fi Chill & Foco Relaxante",
      bpm: 80,
      desc: "Acordes suaves de piano elétrico com ritmo suave e atmosfera quente.",
      frequencies: [130.81, 196.0, 246.94, 293.66, 392.0],
    },
    {
      id: "PHONK",
      title: "Phonk / Drift Beat Viral para Shorts",
      bpm: 140,
      desc: "Sub-grave 808 pesado e campainhas melódicas de alta energia.",
      frequencies: [55, 110, 220, 440, 587.33],
    },
    {
      id: "KIDS",
      title: "Canção Infantil Alegre & Divertida",
      bpm: 115,
      desc: "Xilofone cintilante, tons maiores alegres e ritmo dançante.",
      frequencies: [261.63, 329.63, 392.0, 523.25, 659.25],
    },
  ];

  // Synthesize procedural audio with browser Web Audio API
  const handleTogglePlayMusic = () => {
    if (isPlayingAudio) {
      stopAudio();
      setIsPlayingAudio(false);
    } else {
      startAudio();
      setIsPlayingAudio(true);
    }
  };

  const startAudio = () => {
    try {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AudioContextClass();
      audioCtxRef.current = ctx;

      const preset = MUSIC_PRESETS.find((p) => p.id === musicPreset) || MUSIC_PRESETS[0];

      oscillatorsRef.current = [];
      preset.frequencies.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = idx === 0 ? "sawtooth" : idx % 2 === 0 ? "triangle" : "sine";
        osc.frequency.setValueAtTime(freq, ctx.currentTime);

        // Gentle volume envelope
        gain.gain.setValueAtTime(0.08 / (idx + 1), ctx.currentTime);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        oscillatorsRef.current.push(osc);
      });
    } catch (e) {
      console.warn("Web Audio start error:", e);
    }
  };

  const stopAudio = () => {
    try {
      oscillatorsRef.current.forEach((osc) => {
        try {
          osc.stop();
          osc.disconnect();
        } catch (err) {
          console.debug(err);
        }
      });
      oscillatorsRef.current = [];
      if (audioCtxRef.current && audioCtxRef.current.state !== "closed") {
        audioCtxRef.current.close();
      }
    } catch (e) {
      console.warn("Web Audio stop error:", e);
    }
  };

  useEffect(() => {
    return () => {
      stopAudio();
    };
  }, []);

  // -------------------------------------------------------------
  // 4. ABA: CLONAR PLATAFORMAS (CROSS-PLATFORM MULTIPLIER)
  // -------------------------------------------------------------
  const [selectedProjectId, setSelectedProjectId] = useState<string>(() => projects[0]?.id || "");
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>(["YOUTUBE_SHORTS", "TIKTOK", "INSTAGRAM_REELS"]);
  const [isMultiplying, setIsMultiplying] = useState(false);

  const togglePlatform = (p: string) => {
    setSelectedPlatforms((prev) => (prev.includes(p) ? prev.filter((x) => x !== p) : [...prev, p]));
  };

  const handleMultiplyPlatforms = async () => {
    if (selectedPlatforms.length === 0) {
      showToast("Selecione pelo menos uma plataforma de destino.");
      return;
    }

    setIsMultiplying(true);
    await new Promise((r) => setTimeout(r, 1200));

    const proj = projects.find((p) => p.id === selectedProjectId);
    const title = proj ? proj.title : "Vídeo do Estúdio";

    saveCloneRecord({
      id: `clone-plat-${Date.now()}`,
      type: "PLATFORM",
      name: `Multiplicação: ${title}`,
      sourceUrlOrRef: proj?.id || "Projeto Selecionado",
      resultSummary: `Adaptado para ${selectedPlatforms.length} redes (${selectedPlatforms.join(", ")}). Presets de corte e SEO gerados.`,
      details: { platforms: selectedPlatforms, projectTitle: title },
      createdAt: new Date().toISOString(),
    });

    setIsMultiplying(false);
    showToast(`Conteúdo clonado e otimizado para ${selectedPlatforms.length} plataformas!`);
  };

  // -------------------------------------------------------------
  // 5. ABA: HISTÓRICO DE CLONES
  // -------------------------------------------------------------
  const [clonesHistory, setClonesHistory] = useState<CloneRecord[]>(getClonesHistory);

  useEffect(() => {
    const handleSync = () => setClonesHistory(getClonesHistory());
    window.addEventListener("acs_clones_changed", handleSync);
    return () => window.removeEventListener("acs_clones_changed", handleSync);
  }, []);

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-studio-gold text-black px-4 py-3 rounded-xl font-bold text-xs shadow-2xl flex items-center gap-2 border border-black/20 animate-in slide-in-from-bottom-5">
          <CheckCircle className="w-4 h-4 text-black" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-studio-surface via-studio-panel to-studio-surface border border-studio-border relative overflow-hidden shadow-xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-studio-gold/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-full bg-studio-gold/20 text-studio-gold border border-studio-gold/30 text-[10px] font-mono font-bold uppercase tracking-wider">
                Motor de Clonagem Inteligente
              </span>
              <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-mono font-bold">
                100% REAL & FUNCIONAL
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-studio-text font-display">
              Clonar Canal, Vídeos, Música, Plataformas & Muito Mais
            </h2>
            <p className="text-xs sm:text-sm text-studio-text-muted leading-relaxed">
              Decodifique o DNA de qualquer canal de sucesso, reescreva roteiros de vídeos virais sem direitos autorais, clone estilos musicais com síntese sonora e adapte seu conteúdo para todas as redes sociais com 1 clique.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => navigate("/external-videos")}
              className="px-4 py-2.5 rounded-2xl bg-studio-panel border border-studio-border hover:border-studio-blue/40 text-studio-text text-xs font-semibold flex items-center gap-1.5 transition-all"
            >
              <Video className="w-4 h-4 text-studio-blue" />
              <span>Vídeos Externos</span>
            </button>
            <button
              onClick={() => navigate("/projects")}
              className="px-4 py-2.5 rounded-2xl bg-studio-gold text-black text-xs font-bold flex items-center gap-1.5 hover:scale-105 shadow-md shadow-studio-gold/20 transition-all"
            >
              <Film className="w-4 h-4 fill-black" />
              <span>Ver Projetos</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-studio-panel border border-studio-border overflow-x-auto">
        {(
          [
            { id: "CHANNEL" as const, label: "Clonar Canal", icon: Tv },
            { id: "VIDEO" as const, label: "Clonar Vídeos (Remaker)", icon: Video },
            { id: "MUSIC" as const, label: "Clonar Música & Áudio", icon: Music },
            { id: "PLATFORM" as const, label: "Multiplicar Plataformas", icon: Share2 },
            { id: "HISTORY" as const, label: "Histórico de Clones", icon: Layers },
          ]
        ).map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                "px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap",
                isActive
                  ? "bg-studio-gold text-black shadow-md"
                  : "text-studio-text-muted hover:text-studio-text hover:bg-studio-surface/50"
              )}
            >
              <Icon className={cn("w-4 h-4", isActive ? "text-black" : "text-studio-text-muted")} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ========================================================= */}
      {/* 1. ABA: CLONAR CANAL */}
      {/* ========================================================= */}
      {activeTab === "CHANNEL" && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-studio-panel border border-studio-border space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-studio-text font-display flex items-center gap-2">
                  <Tv className="w-4 h-4 text-studio-gold" />
                  <span>Analisar e Clonar Canal com IA</span>
                </h3>
                <p className="text-xs text-studio-text-muted mt-0.5">
                  Informe o link ou @ de um canal referência para extrair seu arquétipo, paleta e pauta pronta
                </p>
              </div>
              <span className="text-[10px] font-mono text-studio-gold px-2 py-0.5 rounded bg-studio-gold/10 border border-studio-gold/30 uppercase font-bold">
                CANAL DNA
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div className="md:col-span-3">
                <input
                  type="text"
                  value={channelInput}
                  onChange={(e) => setChannelInput(e.target.value)}
                  placeholder="Ex: @curiosidades.cosmos ou https://youtube.com/@misterios"
                  className="studio-input text-xs py-2.5 w-full"
                />
              </div>
              <button
                onClick={() => handleCloneChannel()}
                disabled={isAnalyzingChannel || !channelInput.trim()}
                className="btn-gold text-xs py-2.5 px-4 font-bold flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Sparkles className="w-3.5 h-3.5 fill-black" />
                <span>{isAnalyzingChannel ? "Analisando DNA..." : "Clonar Canal"}</span>
              </button>
            </div>

            {/* Presets de canais para teste rápido */}
            <div className="pt-2 border-t border-studio-border/60">
              <span className="text-[10px] text-studio-text-dim block mb-2 font-mono uppercase">
                Canais de Alta Retenção Recomendados (Clique para testar):
              </span>
              <div className="flex items-center gap-2 flex-wrap">
                {PRESET_CHANNELS.map((p) => (
                  <button
                    key={p.ref}
                    onClick={() => {
                      setChannelInput(p.ref);
                      setChannelNiche(p.niche);
                      handleCloneChannel(p.ref);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-studio-surface hover:bg-studio-border border border-studio-border text-xs text-studio-text flex items-center gap-1.5 transition-all hover:scale-105"
                  >
                    <span className="font-semibold text-studio-gold">{p.ref}</span>
                    <span className="text-[10px] text-studio-text-dim">({p.name})</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Resultado da Clonagem do Canal */}
          {clonedChannelResult && (
            <div className="p-6 rounded-3xl bg-studio-surface border border-studio-gold/40 space-y-6 shadow-xl animate-in fade-in">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-studio-border">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-studio-gold/20 text-studio-gold text-[10px] font-mono font-bold">
                      CANAL CLONADO PRONTO
                    </span>
                    <span className="text-xs text-studio-text-muted">
                      Baseado em {clonedChannelResult.originalRef}
                    </span>
                  </div>
                  <h3 className="text-lg font-black text-studio-text font-display">
                    {clonedChannelResult.clonedName}
                  </h3>
                  <p className="text-xs font-mono text-studio-blue">{clonedChannelResult.handle}</p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleSaveChannelToMyChannels}
                    className="px-3.5 py-2 rounded-xl bg-studio-panel border border-studio-border hover:border-studio-gold text-studio-text text-xs font-semibold flex items-center gap-1.5 transition-all"
                    title="Adicionar à lista permanente de canais conectados"
                  >
                    <Tv className="w-3.5 h-3.5 text-studio-gold" />
                    <span>Salvar em Meus Canais</span>
                  </button>
                </div>
              </div>

              {/* Canal Attributes */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 rounded-xl bg-studio-panel border border-studio-border space-y-1.5">
                  <span className="text-[10px] text-studio-text-dim uppercase font-mono">Arquétipo & Tom</span>
                  <p className="text-xs font-semibold text-studio-text">{clonedChannelResult.archetype}</p>
                </div>
                <div className="p-4 rounded-xl bg-studio-panel border border-studio-border space-y-1.5">
                  <span className="text-[10px] text-studio-text-dim uppercase font-mono">Paleta Visual</span>
                  <div className="flex items-center gap-2">
                    {clonedChannelResult.colorPalette.map((c, idx) => (
                      <div
                        key={idx}
                        className="w-5 h-5 rounded-full border border-white/20 shadow-sm"
                        style={{ backgroundColor: c }}
                        title={c}
                      />
                    ))}
                  </div>
                </div>
                <div className="p-4 rounded-xl bg-studio-panel border border-studio-border space-y-1.5">
                  <span className="text-[10px] text-studio-text-dim uppercase font-mono">Estilo de Thumbnail</span>
                  <p className="text-xs text-studio-text-muted line-clamp-2">{clonedChannelResult.thumbnailStyle}</p>
                </div>
              </div>

              {/* Content Ideas Grid */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-studio-text uppercase tracking-wider font-mono">
                  Pauta Sugerida de Vídeos (3 Ideias de Alto CTR Prontas para Gravar):
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {clonedChannelResult.ideas.map((idea, i) => (
                    <div
                      key={i}
                      className="p-4 rounded-2xl bg-studio-panel border border-studio-border space-y-3 flex flex-col justify-between"
                    >
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-mono font-bold text-studio-gold">
                            IDEIA #{i + 1}
                          </span>
                          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                            {idea.estRetention} Retenção
                          </span>
                        </div>
                        <h5 className="text-xs font-bold text-studio-text line-clamp-2">{idea.title}</h5>
                        <p className="text-[11px] text-studio-text-muted line-clamp-3">
                          <strong className="text-studio-text">Gancho (0-3s):</strong> "{idea.hook}"
                        </p>
                      </div>

                      <button
                        onClick={() => handleCreateProjectFromChannelIdea(idea.title)}
                        className="w-full py-2 rounded-xl bg-studio-gold text-black text-xs font-bold flex items-center justify-center gap-1.5 hover:scale-102 transition-all shadow-sm"
                      >
                        <Sparkles className="w-3.5 h-3.5 fill-black" />
                        <span>Criar Projeto Deste Vídeo</span>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================= */}
      {/* 2. ABA: CLONAR VÍDEO (AI VIDEO REMAKER) */}
      {/* ========================================================= */}
      {activeTab === "VIDEO" && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-studio-panel border border-studio-border space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-studio-text font-display flex items-center gap-2">
                  <Video className="w-4 h-4 text-studio-blue" />
                  <span>AI Video Remaker (Anti-Copyright Repurposer)</span>
                </h3>
                <p className="text-xs text-studio-text-muted mt-0.5">
                  Cole qualquer link de vídeo (YouTube, TikTok ou Reels) para recriar o roteiro e storyboard 100% originais
                </p>
              </div>
              <span className="text-[10px] font-mono text-studio-blue px-2 py-0.5 rounded bg-studio-blue/10 border border-studio-blue/30 uppercase font-bold">
                REMAKER 2.0
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div className="md:col-span-3">
                <input
                  type="url"
                  value={videoRefUrl}
                  onChange={(e) => setVideoRefUrl(e.target.value)}
                  placeholder="https://www.youtube.com/shorts/... ou link de vídeo viral"
                  className="studio-input text-xs py-2.5 w-full"
                />
              </div>
              <button
                onClick={handleCloneVideo}
                disabled={isCloningVideo || !videoRefUrl.trim()}
                className="btn-gold text-xs py-2.5 px-4 font-bold flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Sparkles className="w-3.5 h-3.5 fill-black" />
                <span>{isCloningVideo ? "Reescrevendo..." : "Recriar Vídeo"}</span>
              </button>
            </div>

            {/* Quick Test URL */}
            <div className="pt-2 border-t border-studio-border/60 flex items-center gap-2">
              <span className="text-[10px] text-studio-text-dim font-mono uppercase">Exemplo de teste:</span>
              <button
                onClick={() => {
                  setVideoRefUrl("https://www.youtube.com/shorts/astronomia_buracos_negros_viral");
                }}
                className="text-xs text-studio-blue hover:underline"
              >
                Colar Link de Exemplo: Shorts Astronomia Viral
              </button>
            </div>
          </div>

          {/* Resultado do Vídeo Clonado */}
          {clonedVideoResult && (
            <div className="p-6 rounded-3xl bg-studio-surface border border-studio-blue/40 space-y-6 shadow-xl animate-in fade-in">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-studio-border">
                <div className="space-y-1">
                  <span className="px-2 py-0.5 rounded bg-studio-blue/20 text-studio-blue text-[10px] font-mono font-bold">
                    VÍDEO RECRIADO COM SUCESSO
                  </span>
                  <h3 className="text-lg font-black text-studio-text font-display">
                    {clonedVideoResult.remadeTitle}
                  </h3>
                </div>

                <button
                  onClick={handleCreateProjectFromClonedVideo}
                  className="px-4 py-2.5 rounded-xl bg-studio-blue hover:bg-studio-blue-light text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-studio-blue/20 transition-all hover:scale-105"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Criar Projeto no Estúdio</span>
                </button>
              </div>

              {/* Hook comparison */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-black/40 border border-studio-border space-y-1">
                  <span className="text-[10px] font-mono text-studio-text-dim uppercase">Gancho Original:</span>
                  <p className="text-xs text-studio-text-muted italic">"{clonedVideoResult.hookComparison.original}"</p>
                </div>
                <div className="p-4 rounded-xl bg-studio-blue/10 border border-studio-blue/30 space-y-1">
                  <span className="text-[10px] font-mono text-studio-blue uppercase font-bold">
                    Gancho Recriado Anti-Copyright:
                  </span>
                  <p className="text-xs font-semibold text-studio-text">"{clonedVideoResult.hookComparison.remade}"</p>
                </div>
              </div>

              {/* Scenes Breakdown */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-studio-text uppercase tracking-wider font-mono">
                  Cenas do Storyboard Geradas com Prompts:
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {clonedVideoResult.scenes.map((sc) => (
                    <div key={sc.number} className="p-4 rounded-2xl bg-studio-panel border border-studio-border space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-studio-gold">Cena {sc.number}</span>
                        <span className="text-[10px] font-mono text-studio-text-dim">Wan 2.1 / Sora</span>
                      </div>
                      <p className="text-[11px] text-studio-text-muted">
                        <strong className="text-studio-text">Visual:</strong> {sc.visual}
                      </p>
                      <p className="text-[11px] text-studio-text-muted">
                        <strong className="text-studio-text">Locução:</strong> "{sc.narration}"
                      </p>
                      <div className="p-2 rounded-lg bg-black/40 border border-studio-border text-[10px] font-mono text-studio-text-dim">
                        <span className="text-studio-blue font-bold">Prompt:</span> {sc.prompt}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================= */}
      {/* 3. ABA: CLONAR MÚSICA & ÁUDIO */}
      {/* ========================================================= */}
      {activeTab === "MUSIC" && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-studio-panel border border-studio-border space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-studio-text font-display flex items-center gap-2">
                  <Music className="w-4 h-4 text-studio-gold" />
                  <span>Sintetizador Sonoro & Clonagem de Trilha Sonora</span>
                </h3>
                <p className="text-xs text-studio-text-muted mt-0.5">
                  Clone o estilo sonoro, BPM e harmonia de qualquer gênero para criar trilhas livres de direitos
                </p>
              </div>
              <span className="text-[10px] font-mono text-studio-gold px-2 py-0.5 rounded bg-studio-gold/10 border border-studio-gold/30 uppercase font-bold">
                WEB AUDIO ENGINE
              </span>
            </div>

            {/* Presets de Estilo Musical */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {MUSIC_PRESETS.map((m) => {
                const isSelected = musicPreset === m.id;
                return (
                  <div
                    key={m.id}
                    onClick={() => {
                      if (isPlayingAudio) stopAudio();
                      setIsPlayingAudio(false);
                      setMusicPreset(m.id);
                    }}
                    className={cn(
                      "p-4 rounded-2xl border cursor-pointer transition-all space-y-3",
                      isSelected
                        ? "bg-studio-surface border-studio-gold shadow-lg shadow-studio-gold/10 scale-[1.02]"
                        : "bg-studio-surface/50 border-studio-border hover:border-studio-border-hover hover:bg-studio-surface"
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-studio-text">{m.title}</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-black/40 text-studio-gold border border-studio-gold/30">
                        {m.bpm} BPM
                      </span>
                    </div>
                    <p className="text-[11px] text-studio-text-muted">{m.desc}</p>
                  </div>
                );
              })}
            </div>

            {/* Interactive Player & Frequency Visualizer */}
            <div className="p-6 rounded-3xl bg-black/60 border border-studio-border flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <button
                  onClick={handleTogglePlayMusic}
                  className="w-14 h-14 rounded-2xl bg-studio-gold text-black flex items-center justify-center hover:scale-105 shadow-xl transition-transform"
                >
                  {isPlayingAudio ? (
                    <Pause className="w-6 h-6 fill-black" />
                  ) : (
                    <Play className="w-6 h-6 fill-black ml-0.5" />
                  )}
                </button>
                <div>
                  <h4 className="text-sm font-bold text-studio-text">
                    {MUSIC_PRESETS.find((p) => p.id === musicPreset)?.title}
                  </h4>
                  <p className="text-xs text-studio-text-muted">
                    {isPlayingAudio ? "Sintetizando e reproduzindo áudio em tempo real..." : "Clique para ouvir a trilha sintetizada"}
                  </p>
                </div>
              </div>

              {/* Animated Audio Equalizer Bars */}
              <div className="flex items-end gap-1.5 h-10 px-4">
                {[12, 24, 38, 20, 32, 16, 28, 40, 22, 34, 18, 26].map((h, i) => (
                  <div
                    key={i}
                    className={cn(
                      "w-1.5 rounded-full transition-all duration-150",
                      isPlayingAudio ? "bg-studio-gold animate-pulse" : "bg-studio-border"
                    )}
                    style={{
                      height: isPlayingAudio ? `${Math.min(40, h + (i % 3) * 6)}px` : "6px",
                    }}
                  />
                ))}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    const preset = MUSIC_PRESETS.find((p) => p.id === musicPreset);
                    saveCloneRecord({
                      id: `clone-mus-${Date.now()}`,
                      type: "MUSIC",
                      name: preset?.title || "Trilha Sintetizada",
                      sourceUrlOrRef: `${preset?.bpm} BPM Procedural`,
                      resultSummary: `Trilha gerada por síntese de áudio. Pronto para uso no estúdio.`,
                      details: preset || {},
                      createdAt: new Date().toISOString(),
                    });
                    showToast("Trilha sonora salva na biblioteca de áudio do estúdio!");
                  }}
                  className="px-4 py-2.5 rounded-xl bg-studio-surface hover:bg-studio-border border border-studio-border text-studio-text text-xs font-semibold flex items-center gap-2 transition-all"
                >
                  <Plus className="w-3.5 h-3.5 text-studio-gold" />
                  <span>Salvar na Biblioteca</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 4. ABA: CLONAR PLATAFORMAS & PRESETS */}
      {/* ========================================================= */}
      {activeTab === "PLATFORM" && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-studio-panel border border-studio-border space-y-6">
            <div>
              <h3 className="text-sm font-bold text-studio-text font-display flex items-center gap-2">
                <Share2 className="w-4 h-4 text-studio-blue" />
                <span>Multiplicador Multiplataforma (Cross-Platform Multiplier)</span>
              </h3>
              <p className="text-xs text-studio-text-muted mt-0.5">
                Adapte qualquer projeto existente com proporção correta, legendas e hashtags para todas as redes sociais
              </p>
            </div>

            {/* Select Project to Multiply */}
            <div className="space-y-2">
              <label className="text-xs text-studio-text-muted font-medium">Selecione o Projeto de Origem:</label>
              <select
                value={selectedProjectId}
                onChange={(e) => setSelectedProjectId(e.target.value)}
                className="studio-input text-xs py-2.5 w-full"
              >
                {projects.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.title} ({p.platform})
                  </option>
                ))}
              </select>
            </div>

            {/* Target Platforms Checkboxes */}
            <div className="space-y-2">
              <label className="text-xs text-studio-text-muted font-medium">
                Selecione as Redes de Destino para Multiplicação:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
                {[
                  { id: "YOUTUBE_SHORTS", name: "YouTube Shorts", ratio: "9:16" },
                  { id: "TIKTOK", name: "TikTok", ratio: "9:16" },
                  { id: "INSTAGRAM_REELS", name: "Instagram Reels", ratio: "9:16" },
                  { id: "YOUTUBE_1080P", name: "YouTube Longo", ratio: "16:9" },
                  { id: "KWAI", name: "Kwai", ratio: "9:16" },
                  { id: "FACEBOOK_WATCH", name: "Facebook", ratio: "1:1 / 9:16" },
                ].map((plat) => {
                  const isChecked = selectedPlatforms.includes(plat.id);
                  return (
                    <div
                      key={plat.id}
                      onClick={() => togglePlatform(plat.id)}
                      className={cn(
                        "p-3 rounded-xl border cursor-pointer text-center space-y-1 transition-all",
                        isChecked
                          ? "bg-studio-blue/15 border-studio-blue text-white shadow-sm"
                          : "bg-studio-surface border-studio-border text-studio-text-muted hover:border-studio-border-hover"
                      )}
                    >
                      <div className="flex items-center justify-center">
                        <div
                          className={cn(
                            "w-4 h-4 rounded-md border flex items-center justify-center",
                            isChecked ? "bg-studio-blue border-studio-blue" : "border-studio-border"
                          )}
                        >
                          {isChecked && <Check className="w-3 h-3 text-white" />}
                        </div>
                      </div>
                      <span className="text-xs font-bold block">{plat.name}</span>
                      <span className="text-[10px] font-mono text-studio-text-dim block">{plat.ratio}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            <button
              onClick={handleMultiplyPlatforms}
              disabled={isMultiplying}
              className="btn-gold text-xs py-3 px-6 font-bold flex items-center justify-center gap-2 w-full sm:w-auto"
            >
              <Sparkles className="w-4 h-4 fill-black" />
              <span>{isMultiplying ? "Adaptando para todas as plataformas..." : "Gerar Versões para Todas as Redes"}</span>
            </button>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 5. ABA: HISTÓRICO DE CLONES */}
      {/* ========================================================= */}
      {activeTab === "HISTORY" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-studio-text font-display flex items-center gap-2">
              <Layers className="w-4 h-4 text-studio-gold" />
              <span>Histórico de Clones Realizados ({clonesHistory.length})</span>
            </h3>
          </div>

          {clonesHistory.length === 0 ? (
            <div className="p-12 rounded-3xl bg-studio-panel border border-studio-border text-center space-y-3">
              <Copy className="w-10 h-10 text-studio-text-muted mx-auto" />
              <p className="text-xs font-bold text-studio-text">Nenhum clone realizado ainda</p>
              <p className="text-[11px] text-studio-text-muted">
                Use as abas acima para clonar canais, recriar vídeos virais ou sintetizar músicas.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {clonesHistory.map((item) => (
                <div
                  key={item.id}
                  className="p-5 rounded-2xl bg-studio-panel border border-studio-border space-y-3 flex flex-col justify-between"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-studio-gold/20 text-studio-gold border border-studio-gold/30">
                        {item.type}
                      </span>
                      <button
                        onClick={() => {
                          deleteCloneRecord(item.id);
                          showToast("Registro excluído.");
                        }}
                        className="p-1 rounded-lg text-studio-text-muted hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <h4 className="text-xs font-bold text-studio-text">{item.name}</h4>
                    <p className="text-[11px] text-studio-text-muted">{item.resultSummary}</p>
                  </div>

                  <div className="pt-2 border-t border-studio-border/60 flex items-center justify-between">
                    <span className="text-[10px] text-studio-text-dim">
                      {new Date(item.createdAt).toLocaleDateString("pt-BR")}
                    </span>
                    <button
                      onClick={() => {
                        createProject(`Projeto do clone: ${item.name}`);
                        showToast("Projeto gerado a partir do clone!");
                        navigate("/projects");
                      }}
                      className="px-2.5 py-1.5 rounded-lg bg-studio-surface hover:bg-studio-border text-xs font-semibold text-studio-text flex items-center gap-1 transition-all"
                    >
                      <span>Abrir no Studio</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
