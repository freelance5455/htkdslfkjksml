import React, { useState } from 'react';
import { Terminal, X, Copy, Trash2, Download, Check, Shield } from 'lucide-react';
import { LogEntry, VpnServer, VpnSettings } from '../types/vpn';
import { Language, TRANSLATIONS } from '../translations';

interface LogsModalProps {
  isOpen: boolean;
  onClose: () => void;
  logs: LogEntry[];
  onClearLogs: () => void;
  server: VpnServer;
  settings: VpnSettings;
  language: Language;
}

export const LogsModal: React.FC<LogsModalProps> = ({
  isOpen,
  onClose,
  logs,
  onClearLogs,
  server,
  settings,
  language,
}) => {
  const t = TRANSLATIONS[language];
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    const text = logs.map(l => `[${l.timestamp}] [${l.level.toUpperCase()}] ${l.message}`).join('\n');
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExportConfig = () => {
    const confContent = `[Interface]
PrivateKey = yAnZ9...EXAMPLE_CLIENT_KEY=
Address = 10.66.66.2/32, fd42:42:42::2/128
DNS = 1.1.1.1, 1.0.0.1

[Peer]
PublicKey = ${server.id}_PUBLIC_KEY_BASE64==
Endpoint = ${server.ip}:51820
AllowedIPs = 0.0.0.0/0, ::/0
PersistentKeepalive = 25
`;

    const blob = new Blob([confContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `shieldvpn_${server.countryCode.toLowerCase()}_${server.city.toLowerCase()}.conf`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-2xl max-h-[85vh] shadow-2xl overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-700 dark:text-slate-300">
              <Terminal className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                {t.logsTitle}
              </h2>
              <p className="text-xs text-slate-500 font-mono">
                wg0 · {settings.protocol.toUpperCase()}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 flex items-center gap-1 transition-colors"
              title="Copy all logs"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? t.copied : t.copyLogs}</span>
            </button>

            <button
              onClick={onClearLogs}
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors"
              title={t.clearLogs}
            >
              <Trash2 className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Terminal logs content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-950 font-mono text-xs text-slate-300 space-y-1.5 select-text">
          {logs.length === 0 ? (
            <div className="py-12 text-center text-slate-600">
              <Terminal className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p>{t.emptyLogs}</p>
            </div>
          ) : (
            logs.map((log) => {
              const color =
                log.level === 'success'
                  ? 'text-emerald-400'
                  : log.level === 'warn'
                  ? 'text-amber-400'
                  : log.level === 'error'
                  ? 'text-rose-400'
                  : 'text-slate-300';

              return (
                <div key={log.id} className="leading-relaxed flex items-start gap-2">
                  <span className="text-slate-600 select-none shrink-0 font-medium">
                    [{log.timestamp}]
                  </span>
                  <span className={`select-none font-bold shrink-0 uppercase text-[10px] px-1 py-0.2 rounded ${
                    log.level === 'success'
                      ? 'bg-emerald-500/10 text-emerald-400'
                      : log.level === 'warn'
                      ? 'bg-amber-500/10 text-amber-400'
                      : log.level === 'error'
                      ? 'bg-rose-500/10 text-rose-400'
                      : 'bg-slate-800 text-slate-400'
                  }`}>
                    {log.level}
                  </span>
                  <span className={`${color} break-all`}>
                    {log.message}
                  </span>
                </div>
              );
            })
          )}
        </div>

        {/* Footer with Config Export */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <span className="text-slate-500">
            Current Server: <strong>{server.city}</strong> ({server.ip})
          </span>
          <button
            onClick={handleExportConfig}
            className="w-full sm:w-auto px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-sm"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{t.exportConfig}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
