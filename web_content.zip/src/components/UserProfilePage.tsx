import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import {
  Mail,
  MapPin,
  Smartphone,
  Calendar,
  LogOut,
  Edit3,
  X,
  Check,
  Bell,
  Ticket,
  ShieldCheck,
  Trash2,
  ChevronRight,
  Upload,
  HelpCircle,
  Sparkles,
} from 'lucide-react';
import {
  SUPPORTED_COUNTRIES,
  normalizePhoneToE164,
  formatPhoneForDisplay,
  isValidPhoneNumber,
} from '../utils/phoneUtils';

export const UserProfilePage: React.FC = () => {
  const {
    user,
    logout,
    updateUserProfile,
    tickets,
    events,
    setCurrentPage,
    formatKsh,
    showToast,
    deleteUserAccount,
    setActiveVirtualTicket,
  } = useApp();

  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(user?.name || 'Maya Lin');
  const [city, setCity] = useState(user?.city || 'Nairobi, Kenya');
  const [bio, setBio] = useState(user?.bio || 'Live experience enthusiast & frequent passholder on Eventra.');
  const [countryCode, setCountryCode] = useState(user?.countryCode || '+254');
  const [phone, setPhone] = useState(user?.phone || user?.mpesaNumber || '0712 345 678');
  const [paypalEmail, setPaypalEmail] = useState(user?.paypalEmail || 'maya.lin@gmail.com');
  const [avatar, setAvatar] = useState(user?.avatar || '/src/assets/images/user_avatar_minimal_1793028389682.jpg');
  const [isSaving, setIsSaving] = useState(false);

  // Modals
  const [showSupportModal, setShowSupportModal] = useState(false);
  const [showDeleteAccountModal, setShowDeleteAccountModal] = useState(false);
  const [confirmDeleteText, setConfirmDeleteText] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!user) return null;

  const hostedEventsCount = events.filter((e) => e.isUserCreated || e.hostName?.toLowerCase() === user.name.toLowerCase()).length;

  const handleCustomAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 3 * 1024 * 1024) {
        showToast('Image size should be under 3MB');
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setAvatar(reader.result);
          showToast('Custom profile photo loaded');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      showToast('Please enter your full name');
      return;
    }
    if (!isValidPhoneNumber(phone)) {
      showToast('Please enter a valid phone number');
      return;
    }

    setIsSaving(true);
    const e164 = normalizePhoneToE164(phone, countryCode);
    await updateUserProfile({
      name: name.trim(),
      city: city.trim(),
      bio: bio.trim(),
      countryCode,
      phone: phone.trim(),
      e164Phone: e164,
      mpesaNumber: phone.trim(),
      paypalEmail: paypalEmail.trim(),
      avatar,
    });
    setIsSaving(false);
    setIsEditing(false);
    showToast('Profile information updated successfully');
  };

  const handleDeleteAccount = async () => {
    if (confirmDeleteText !== 'DELETE') {
      showToast('Please type DELETE to confirm');
      return;
    }
    await deleteUserAccount();
  };

  return (
    <div className="min-h-screen bg-[#090a0d] text-[#f4f4f6] pt-24 pb-28">
      <div className="max-w-4xl mx-auto px-6 space-y-6">
        {/* Apple HIG Clean Profile Card (Strict Dark Mode) */}
        <div className="p-6 sm:p-8 rounded-[32px] bg-[#111317] border border-[#1f2229] shadow-xl flex flex-col sm:flex-row items-center sm:items-start gap-6">
          <div className="relative group">
            <img
              src={user.avatar}
              alt={user.name}
              className="w-24 h-24 rounded-full object-cover border-2 border-[#1f2229] shadow-md"
            />
            <button
              onClick={() => setIsEditing(true)}
              className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 rounded-full flex items-center justify-center transition-opacity text-white text-xs font-semibold cursor-pointer"
              title="Change photo"
            >
              <Edit3 className="w-4 h-4" />
            </button>
            <span className="absolute bottom-0 right-0 w-6 h-6 rounded-full bg-emerald-500 border-2 border-[#111317] flex items-center justify-center shadow-xs">
              <Check className="w-3.5 h-3.5 text-white stroke-[3]" />
            </span>
          </div>

          <div className="flex-1 text-center sm:text-left space-y-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h1 className="text-2xl font-black tracking-tight text-[#f4f4f6]">
                  {user.name}
                </h1>
                <p className="text-xs text-[#9496a1] flex items-center justify-center sm:justify-start gap-1.5 mt-0.5">
                  <MapPin className="w-3.5 h-3.5 text-emerald-500" />
                  <span>{user.city}</span>
                  <span>·</span>
                  <span>Member since {user.memberSince}</span>
                </p>
              </div>

              <button
                onClick={() => setIsEditing(true)}
                className="px-4 py-2 rounded-full border border-[#232733] bg-[#16181f] hover:bg-[#1f222b] text-xs font-semibold text-[#f4f4f6] transition-colors inline-flex items-center justify-center gap-1.5 cursor-pointer self-center sm:self-auto shadow-xs active:scale-95"
              >
                <Edit3 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Edit Profile</span>
              </button>
            </div>

            <p className="text-xs text-[#9496a1] max-w-xl leading-relaxed">
              {user.bio || 'Live experience enthusiast & frequent passholder on Eventra.'}
            </p>

            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-1">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Verified Account</span>
              </span>

              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-medium bg-[#16181f] text-[#c2c4cf] border border-[#232733]">
                <Mail className="w-3.5 h-3.5 text-blue-400" />
                <span>{user.email}</span>
              </span>

              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-mono text-[#c2c4cf] bg-[#16181f] border border-[#232733]">
                <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                <span>{formatPhoneForDisplay(user.e164Phone || user.phone)}</span>
              </span>
            </div>
          </div>
        </div>

        {/* Saved Tickets Wallet & Active Hosting Status */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Saved Tickets Wallet Quick-View */}
          <div className="p-6 rounded-[28px] bg-[#111317] border border-[#1f2229] shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#1f2229]">
              <div className="flex items-center gap-2">
                <Ticket className="w-4 h-4 text-emerald-400" />
                <h2 className="text-xs font-bold uppercase tracking-wider text-[#f4f4f6]">
                  Passbook & Wallet
                </h2>
              </div>
              <button
                onClick={() => setCurrentPage('tickets')}
                className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 cursor-pointer"
              >
                <span>View All ({tickets.length})</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {tickets.length === 0 ? (
              <div className="py-6 text-center text-xs text-[#646875]">
                No tickets purchased yet. Discover live events and book your passes!
              </div>
            ) : (
              <div className="space-y-2">
                {tickets.slice(0, 2).map((tkt) => (
                  <div
                    key={tkt.ticketId}
                    onClick={() => setActiveVirtualTicket(tkt)}
                    className="p-3.5 rounded-2xl bg-[#16181f] border border-[#232733] flex items-center justify-between gap-3 cursor-pointer hover:border-emerald-500/50 transition-colors"
                  >
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-bold text-[#f4f4f6] truncate">
                        {tkt.eventTitle}
                      </h4>
                      <p className="text-[11px] text-[#9496a1] truncate mt-0.5">
                        {tkt.venue} · {tkt.date.split(',')[1] || tkt.date}
                      </p>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="font-mono text-xs font-bold text-emerald-400 block">
                        {tkt.ticketCode}
                      </span>
                      <span className="text-[10px] text-[#646875] capitalize">
                        {tkt.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Active Hosting Status */}
          <div className="p-6 rounded-[28px] bg-[#111317] border border-[#1f2229] shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#1f2229]">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <h2 className="text-xs font-bold uppercase tracking-wider text-[#f4f4f6]">
                  Active Hosting Status
                </h2>
              </div>
              <button
                onClick={() => setCurrentPage('dashboard')}
                className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 cursor-pointer"
              >
                <span>Host Studio</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3.5 rounded-2xl bg-[#16181f] border border-[#232733]">
                <span className="text-[10px] uppercase font-bold text-[#646875] block">
                  Hosted Events
                </span>
                <span className="text-xl font-black text-[#f4f4f6] mt-1 block">
                  {hostedEventsCount} Active
                </span>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#16181f] border border-[#232733]">
                <span className="text-[10px] uppercase font-bold text-[#646875] block">
                  Payout Rail
                </span>
                <span className="text-xs font-mono font-bold text-emerald-400 mt-2 block truncate">
                  {formatPhoneForDisplay(user.mpesaNumber || user.phone)}
                </span>
              </div>
            </div>

            <button
              onClick={() => setCurrentPage('create')}
              className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-sm active:scale-98"
            >
              <span>Publish New Event Worldwide</span>
            </button>
          </div>
        </div>

        {/* Clean Preferences & Security */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Preferences Card */}
          <div className="p-6 rounded-[28px] bg-[#111317] border border-[#1f2229] shadow-sm space-y-4">
            <h2 className="text-xs font-bold uppercase tracking-wider text-[#9496a1]">
              App Preferences
            </h2>

            {/* Notifications */}
            <div className="flex items-center justify-between py-2 border-b border-[#1f2229]">
              <div className="flex items-center gap-2.5">
                <Bell className="w-4 h-4 text-emerald-400" />
                <div>
                  <span className="text-xs font-semibold text-[#f4f4f6] block">
                    Gate & Booking Alerts
                  </span>
                  <span className="text-[11px] text-[#646875]">
                    Turnstile admission & dispatch updates
                  </span>
                </div>
              </div>
              <button
                onClick={() => updateUserProfile({ smsNotifications: !user.smsNotifications })}
                className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors ${
                  user.smsNotifications ? 'bg-emerald-500' : 'bg-[#262934]'
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-xs transform transition-transform ${
                    user.smsNotifications ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Calendar Sync */}
            <div className="flex items-center justify-between py-2">
              <div className="flex items-center gap-2.5">
                <Calendar className="w-4 h-4 text-emerald-400" />
                <div>
                  <span className="text-xs font-semibold text-[#f4f4f6] block">
                    Calendar Auto-Sync
                  </span>
                  <span className="text-[11px] text-[#646875]">
                    Sync pass dates with in-app calendar
                  </span>
                </div>
              </div>
              <button
                onClick={() => updateUserProfile({ appCalendarSync: !user.appCalendarSync })}
                className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors ${
                  user.appCalendarSync ? 'bg-emerald-500' : 'bg-[#262934]'
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-xs transform transition-transform ${
                    user.appCalendarSync ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Concierge & Support */}
          <div className="p-6 rounded-[28px] bg-[#111317] border border-[#1f2229] shadow-sm space-y-4">
            <h2 className="text-xs font-bold uppercase tracking-wider text-[#9496a1]">
              Support & Concierge
            </h2>

            <div className="p-3.5 rounded-2xl bg-[#16181f] border border-[#232733] space-y-1">
              <span className="text-xs font-bold text-[#f4f4f6] block">
                24/7 Gate & Ticketing Concierge
              </span>
              <p className="text-[11px] text-[#9496a1] leading-relaxed">
                Need immediate help at turnstiles or assistance with M-Pesa/PayPal checkout? Our team is live around the clock.
              </p>
            </div>

            <div className="flex items-center justify-between pt-1">
              <div className="flex items-center gap-2.5">
                <HelpCircle className="w-4 h-4 text-emerald-400" />
                <div>
                  <span className="text-xs font-semibold text-[#f4f4f6] block">
                    Help Desk & FAQ
                  </span>
                  <span className="text-[11px] text-[#646875]">
                    concierge@eventra.com
                  </span>
                </div>
              </div>
              <button
                onClick={() => setShowSupportModal(true)}
                className="px-3.5 py-1.5 rounded-full border border-[#232733] bg-[#16181f] hover:bg-[#1f222b] text-xs font-semibold text-[#f4f4f6] transition-colors cursor-pointer shadow-xs"
              >
                Get Help
              </button>
            </div>
          </div>
        </div>

        {/* Sign Out & Account Deletion */}
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={logout}
            className="px-6 py-2.5 rounded-full border border-[#232733] bg-[#111317] hover:bg-[#16181f] text-xs font-semibold text-[#f4f4f6] transition-colors flex items-center gap-2 cursor-pointer shadow-xs"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out of Eventra</span>
          </button>

          <button
            onClick={() => setShowDeleteAccountModal(true)}
            className="px-6 py-2.5 rounded-full border border-red-500/25 bg-red-500/10 hover:bg-red-500/20 text-xs font-semibold text-red-400 transition-colors flex items-center gap-2 cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Delete Account & Data</span>
          </button>
        </div>
      </div>

      {/* Edit Profile Modal (Strict Dark Mode) */}
      {isEditing && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-150 overflow-y-auto"
          onClick={() => setIsEditing(false)}
        >
          <div
            className="relative w-full max-w-lg my-8 bg-[#111317] rounded-[32px] p-6 sm:p-7 shadow-2xl border border-[#1f2229] space-y-4 text-[#f4f4f6]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-[#1f2229]">
              <h3 className="text-base font-bold text-[#f4f4f6]">
                Customize Profile
              </h3>
              <button
                onClick={() => setIsEditing(false)}
                className="w-8 h-8 rounded-full hover:bg-[#1f2229] flex items-center justify-center text-[#9496a1] hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-[#b8b9c2] block">
                  Profile Photo
                </label>
                <div className="flex items-center gap-3">
                  <img
                    src={avatar}
                    alt="Preview"
                    className="w-14 h-14 rounded-full object-cover border border-[#262934]"
                  />
                  <div className="flex-1 space-y-2">
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleCustomAvatarUpload}
                      accept="image/*"
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full h-11 px-4 rounded-xl border border-dashed border-[#262934] hover:border-emerald-500 bg-[#16181f] text-xs font-semibold text-[#f4f4f6] flex items-center justify-center gap-2 cursor-pointer transition-colors"
                    >
                      <Upload className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Upload Custom Photo</span>
                    </button>
                  </div>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  Full Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full h-12 px-4 text-sm rounded-xl border border-[#262934] bg-[#16181f] text-[#f4f4f6] font-medium focus:border-emerald-500 focus:outline-none"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  Bio
                </label>
                <textarea
                  rows={2}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  placeholder="Tell others what events you love..."
                  className="w-full p-3.5 text-xs rounded-xl border border-[#262934] bg-[#16181f] text-[#f4f4f6] placeholder:text-[#5d606f] focus:border-emerald-500 focus:outline-none resize-none leading-relaxed"
                  maxLength={160}
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  City / Location
                </label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full h-12 px-4 text-sm rounded-xl border border-[#262934] bg-[#16181f] text-[#f4f4f6] font-medium focus:border-emerald-500 focus:outline-none"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  Primary Mobile Number (M-Pesa)
                </label>
                <div className="grid grid-cols-12 gap-2">
                  <select
                    value={countryCode}
                    onChange={(e) => setCountryCode(e.target.value)}
                    className="col-span-4 h-12 px-3 text-xs rounded-xl border border-[#262934] bg-[#16181f] text-[#f4f4f6] focus:outline-none"
                  >
                    {SUPPORTED_COUNTRIES.map((c) => (
                      <option key={c.code} value={c.dialCode} className="bg-[#16181f] text-white">
                        {c.flag} {c.dialCode}
                      </option>
                    ))}
                  </select>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="0712 345 678"
                    className="col-span-8 h-12 px-4 text-sm font-mono rounded-xl border border-[#262934] bg-[#16181f] text-[#f4f4f6] focus:border-emerald-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  PayPal Email
                </label>
                <input
                  type="email"
                  value={paypalEmail}
                  onChange={(e) => setPaypalEmail(e.target.value)}
                  className="w-full h-12 px-4 text-sm rounded-xl border border-[#262934] bg-[#16181f] text-[#f4f4f6] font-medium focus:border-emerald-500 focus:outline-none"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isSaving}
                className="w-full h-12 mt-2 rounded-full bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-white text-xs font-bold transition-all cursor-pointer shadow-md active:scale-98"
              >
                {isSaving ? 'Saving Changes...' : 'Save Profile Changes'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Help & Concierge Modal */}
      {showSupportModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-150"
          onClick={() => setShowSupportModal(false)}
        >
          <div
            className="w-full max-w-md bg-[#111317] rounded-[32px] p-6 shadow-2xl border border-[#1f2229] space-y-4 text-[#f4f4f6]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-[#1f2229]">
              <div className="flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-emerald-400" />
                <h3 className="text-base font-bold text-[#f4f4f6]">
                  Eventra Concierge & Help
                </h3>
              </div>
              <button
                onClick={() => setShowSupportModal(false)}
                className="w-8 h-8 rounded-full hover:bg-[#1f2229] flex items-center justify-center text-[#9496a1] hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-[#9496a1]">
              <div className="p-3.5 rounded-2xl bg-[#16181f] border border-[#232733] space-y-1">
                <h4 className="font-bold text-[#f4f4f6]">How do digital passes work at the gate?</h4>
                <p>Present your pass code or QR code from the "My Passes" section. The turnstile steward scans it once to admit your party.</p>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#16181f] border border-[#232733] space-y-1">
                <h4 className="font-bold text-[#f4f4f6]">Automated Cancellation Refunds</h4>
                <p>If an event is canceled by its host, all ticket purchase transactions are automatically refunded back to your original payment method (M-Pesa / PayPal).</p>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#16181f] border border-[#232733] space-y-1">
                <h4 className="font-bold text-[#f4f4f6]">Direct Concierge Assistance</h4>
                <p className="font-mono text-emerald-400">concierge@eventra.com · Nairobi, Kenya</p>
              </div>
            </div>

            <button
              onClick={() => setShowSupportModal(false)}
              className="w-full py-2.5 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold transition-colors cursor-pointer"
            >
              Close Help
            </button>
          </div>
        </div>
      )}

      {/* Delete User Account Procedure Dialog */}
      {showDeleteAccountModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-150"
          onClick={() => setShowDeleteAccountModal(false)}
        >
          <div
            className="w-full max-w-md bg-[#111317] rounded-[32px] p-6 shadow-2xl border border-red-500/30 space-y-4 text-[#f4f4f6]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-12 h-12 rounded-full bg-red-950/60 text-red-400 flex items-center justify-center mx-auto border border-red-500/20">
              <Trash2 className="w-6 h-6 stroke-[2]" />
            </div>
            <div className="text-center space-y-1.5">
              <h3 className="text-base font-bold text-white">
                Delete Eventra Account & Cloud Data
              </h3>
              <p className="text-xs text-[#9496a1]">
                This will permanently remove your account, saved bookings, and cloud profile. To proceed, type <strong className="text-red-400 font-bold">DELETE</strong> below.
              </p>
            </div>

            <div className="space-y-2">
              <input
                type="text"
                value={confirmDeleteText}
                onChange={(e) => setConfirmDeleteText(e.target.value)}
                placeholder="Type DELETE to confirm"
                className="w-full h-12 px-4 text-xs font-bold text-center tracking-wider text-red-400 rounded-xl border border-red-500/30 bg-[#16181f] focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={handleDeleteAccount}
                disabled={confirmDeleteText !== 'DELETE'}
                className="py-2.5 rounded-xl bg-red-600 hover:bg-red-700 disabled:opacity-40 text-white text-xs font-bold cursor-pointer transition-colors"
              >
                Permanently Delete
              </button>
              <button
                onClick={() => {
                  setShowDeleteAccountModal(false);
                  setConfirmDeleteText('');
                }}
                className="py-2.5 rounded-xl border border-[#232733] text-[#9496a1] text-xs font-medium cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
