import React, { useState } from 'react';
import {
  Trophy,
  Medal,
  Calendar,
  Info,
  HelpCircle,
  TrendingUp,
  Award,
  Flame,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import type { Player, Category, WeeklyResult, Season } from '../types/index.ts';

interface WeeklyRankingViewProps {
  categories: Category[];
  selectedCategoryId: string;
  onSelectCategory: (id: string) => void;
  players: Player[];
  rankingResults: WeeklyResult[];
  season: Season;
  onOpenPlayerProfile: (playerId: string) => void;
}

export const WeeklyRankingView: React.FC<WeeklyRankingViewProps> = ({
  categories,
  selectedCategoryId,
  onSelectCategory,
  players,
  rankingResults,
  season,
  onOpenPlayerProfile,
}) => {
  const [showRules, setShowRules] = useState(false);

  const activeCategories = categories.filter((c) => c.status === 'active');
  const selectedCat = categories.find((c) => c.id === selectedCategoryId) || activeCategories[0];

  const getPlayer = (id: string): Player | undefined => {
    return players.find((p) => p.id === id);
  };

  const getRankBadge = (rank: number, isChampion: boolean) => {
    if (rank === 1 || isChampion) {
      return (
        <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center font-extrabold text-xs">
          <Trophy className="w-4 h-4 text-amber-400" />
        </div>
      );
    }
    if (rank === 2) {
      return (
        <div className="w-8 h-8 rounded-lg bg-neutral-400/20 border border-neutral-400/40 text-neutral-300 flex items-center justify-center font-extrabold text-xs">
          2º
        </div>
      );
    }
    if (rank === 3) {
      return (
        <div className="w-8 h-8 rounded-lg bg-amber-800/20 border border-amber-800/40 text-amber-600 flex items-center justify-center font-extrabold text-xs">
          3º
        </div>
      );
    }
    return (
      <div className="w-8 h-8 rounded-lg bg-neutral-800 border border-neutral-700 text-neutral-400 flex items-center justify-center font-bold text-xs">
        {rank}º
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Category selector tabs */}
      <div className="flex items-center gap-1 p-1 bg-neutral-900 border border-neutral-800 rounded-xl overflow-x-auto">
        {activeCategories.map((cat) => {
          const isSelected = cat.id === selectedCategoryId;
          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`flex-1 min-w-[120px] py-2.5 px-4 rounded-lg font-bold text-xs transition-all flex items-center justify-center gap-2 ${
                isSelected
                  ? 'bg-neutral-800 text-white shadow-sm border border-neutral-700'
                  : 'text-neutral-400 hover:text-white hover:bg-neutral-800/50'
              }`}
            >
              <span>{cat.name.split(' ')[0]} {cat.name.split(' ')[1]}</span>
              <span className="text-[10px] text-neutral-500 font-mono-numbers">
                ({cat.weightGrams}g)
              </span>
            </button>
          );
        })}
      </div>

      {/* Season Card Header */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
              {season.status === 'active' ? 'Temporada em Andamento' : 'Temporada Oficial Encerrada'}
            </span>
            <span
              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                season.status === 'active'
                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-800 animate-pulse'
                  : 'bg-neutral-800 text-neutral-400 border border-neutral-700'
              }`}
            >
              {season.status === 'active' ? 'Provisório' : 'Congelado'}
            </span>
          </div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <Calendar className="w-5 h-5 text-neutral-400" />
            <span>{season.name}</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            Categoria: <strong className="text-white">{selectedCat?.name}</strong> · Fuso São Paulo (Segunda 00:00 a Domingo 23:59)
          </p>
        </div>

        <button
          onClick={() => setShowRules(!showRules)}
          className="text-xs text-neutral-400 hover:text-white flex items-center gap-1.5 py-1.5 px-3 rounded-lg bg-neutral-800/60 border border-neutral-700/60 transition-colors"
        >
          <Info className="w-4 h-4 text-emerald-400" />
          <span>Regra de Cálculo</span>
          {showRules ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
        </button>
      </div>

      {/* Collapsible Rules Explanation */}
      {showRules && (
        <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-4 text-xs text-neutral-300 space-y-2.5">
          <h4 className="font-bold text-white flex items-center gap-1.5">
            <HelpCircle className="w-4 h-4 text-emerald-400" />
            Cálculo Oficial da Média Semanal
          </h4>
          <p className="leading-relaxed">
            Para cada jogador na categoria, somam-se as <strong>melhores sequências de cada dia treinado</strong> na semana e divide-se pela <strong>quantidade de dias registrados</strong>.
          </p>
          <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800 font-mono-numbers text-[11px] text-emerald-300">
            Exemplo: Nycollas registrou Segunda (10), Quarta (7) e Sexta (6).<br />
            Soma: 10 + 7 + 6 = 23 | Dias: 3<br />
            Média oficial: 23 ÷ 3 = 7,67 (calculada com precisão contínua sem arredondar para desempate).
          </div>
          <p className="text-[11px] text-neutral-400">
            * Dias sem treino não entram na conta. Treino registrado com 0 acertos entra como zero na soma e divide pela quantidade de dias.
          </p>
          <p className="text-[11px] text-neutral-400">
            * Critérios de desempate: (1) maior sequência individual da semana; (2) maior número de dias treinados; (3) empate técnico declarado.
          </p>
        </div>
      )}

      {/* Ranking Table / Cards */}
      <div className="space-y-3">
        {rankingResults.length === 0 ? (
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-8 text-center">
            <Trophy className="w-10 h-10 text-neutral-600 mx-auto mb-2" />
            <h3 className="text-sm font-bold text-neutral-300">Nenhum treino registrado nesta categoria ainda</h3>
            <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
              Seja o primeiro do grupo a registrar uma sequência na categoria de {selectedCat?.weightGrams}g!
            </p>
          </div>
        ) : (
          rankingResults.map((item) => {
            const player = getPlayer(item.playerId);
            if (!player) return null;

            return (
              <div
                key={item.playerId}
                onClick={() => onOpenPlayerProfile(item.playerId)}
                className={`flex items-center justify-between p-4 rounded-2xl border transition-all cursor-pointer ${
                  item.isChampion
                    ? 'bg-gradient-to-r from-amber-950/30 via-neutral-900 to-neutral-900 border-amber-500/40 shadow-lg shadow-amber-950/20'
                    : 'bg-neutral-900 border-neutral-800 hover:border-neutral-700'
                }`}
                role="button"
                tabIndex={0}
                aria-label={`Ver perfil de ${player.name}`}
              >
                {/* Left: Position & Player Info */}
                <div className="flex items-center gap-3">
                  {getRankBadge(item.rank, item.isChampion)}

                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm text-white shadow"
                      style={{ backgroundColor: player.color || '#10b981' }}
                    >
                      {player.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-sm">
                          {player.name}
                        </span>
                        {item.isChampion && (
                          <span className="text-[10px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/40">
                            {season.status === 'active' ? 'Líder' : 'Campeão'}
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-neutral-400 flex items-center gap-2 mt-0.5">
                        <span>{item.daysTrained} {item.daysTrained === 1 ? 'dia' : 'dias'}</span>
                        <span aria-hidden="true">·</span>
                        <span>Melhor: {item.maxStreak}</span>
                        {item.tieBreakReason && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="text-amber-400/80 text-[11px]">{item.tieBreakReason}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Right: Average Score display */}
                <div className="text-right">
                  <div className="text-xs text-neutral-500 uppercase tracking-wider font-semibold">
                    Média Semanal
                  </div>
                  <div className="text-2xl font-extrabold text-white font-mono-numbers">
                    {item.formattedAverage}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
