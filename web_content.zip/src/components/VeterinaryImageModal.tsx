/**
 * HELENA - Veterinary Field Image Analysis Modal
 * Camera capture (capture="environment") or gallery (up to 4 photos).
 * Resizes on client to max 1280px @ 80% JPEG (strips EXIF/GPS automatically).
 * Dual brain vision analysis (Gemini + Groq vision) with structured clinical output.
 */

import React, { useState, useRef } from 'react';
import { 
  Camera, 
  Image as ImageIcon, 
  X, 
  Sparkles, 
  Volume2, 
  Copy, 
  Check, 
  AlertCircle, 
  Loader2, 
  ShieldAlert,
  Stethoscope,
  Info
} from 'lucide-react';
import { AppSettings } from '../types';
import { analyzeVeterinaryFieldImages } from '../services/brains';
import { addHistoryItem } from '../services/storage';

interface VeterinaryImageModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSpeak: (text: string) => void;
}

export const VeterinaryImageModal: React.FC<VeterinaryImageModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSpeak,
}) => {
  const [images, setImages] = useState<string[]>([]);
  const [clinicalContext, setClinicalContext] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [reportResult, setReportResult] = useState<{
    reportText: string;
    geminiReport?: string;
    groqReport?: string;
    isSingleBrain?: boolean;
  } | null>(null);
  const [copied, setCopied] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  // Process & resize image to max 1280px at 80% quality (strips EXIF/GPS)
  const processImageFile = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const maxDim = 1280;
          let w = img.width;
          let h = img.height;

          if (w > maxDim || h > maxDim) {
            if (w > h) {
              h = Math.round((h * maxDim) / w);
              w = maxDim;
            } else {
              w = Math.round((w * maxDim) / h);
              h = maxDim;
            }
          }

          const canvas = document.createElement('canvas');
          canvas.width = w;
          canvas.height = h;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            reject(new Error('Canvas context unavailable'));
            return;
          }

          ctx.drawImage(img, 0, 0, w, h);
          // Exporting as image/jpeg automatically strips metadata (GPS/EXIF)
          const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
          resolve(dataUrl);
        };
        img.onerror = () => reject(new Error('Falha ao carregar imagem'));
        img.src = e.target?.result as string;
      };
      reader.onerror = () => reject(new Error('Falha ao ler arquivo'));
      reader.readAsDataURL(file);
    });
  };

  const handleFilesSelected = async (files: FileList | null) => {
    if (!files) return;
    setErrorMsg('');
    const availableSlots = 4 - images.length;
    if (availableSlots <= 0) {
      setErrorMsg('Máximo de 4 fotos atingido.');
      return;
    }

    const filesToProcess = Array.from(files).slice(0, availableSlots);
    const newImages: string[] = [];

    for (const f of filesToProcess) {
      try {
        const b64 = await processImageFile(f);
        newImages.push(b64);
      } catch (err) {
        console.error('Erro ao processar foto:', err);
      }
    }

    setImages((prev) => [...prev, ...newImages]);
  };

  const handleRemoveImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index));
  };

  const handleRunAnalysis = async () => {
    if (images.length === 0) {
      setErrorMsg('Selecione ou capture ao menos 1 foto.');
      return;
    }

    setAnalyzing(true);
    setErrorMsg('');
    setReportResult(null);

    try {
      const res = await analyzeVeterinaryFieldImages(images, clinicalContext, settings);
      setReportResult(res);

      // Save to history with thumbnail of the first image
      addHistoryItem({
        id: `hist_img_${Date.now()}`,
        timestamp: new Date().toISOString(),
        query: `[Análise de Campo Veterinário - ${images.length} fotos] ${clinicalContext || 'Sem contexto adicional'}`,
        response: res.reportText,
        consensusCount: res.isSingleBrain ? 1 : 2,
        totalBrains: 2,
        thumbnail: images[0],
        details: {
          gemini: res.geminiReport,
          groq: res.groqReport,
        },
      });
    } catch (err: any) {
      console.error('Erro na análise veterinária:', err);
      setErrorMsg(err.message || 'Erro ao processar fotos com os cérebros.');
    } finally {
      setAnalyzing(false);
    }
  };

  const handleCopyReport = () => {
    if (!reportResult) return;
    const fullText = `${reportResult.reportText}\n\n---\nAVISO: Esta análise é uma ferramenta de apoio à decisão clínica e não substitui a avaliação presencial do Médico Veterinário. CRMV obrigatório para prescrição.`;
    navigator.clipboard.writeText(fullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleSpeakReport = () => {
    if (!reportResult) return;
    // Extract concise speech summary
    const cleanSpeech = reportResult.geminiReport || reportResult.reportText.slice(0, 400);
    onSpeak(cleanSpeech);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-md animate-fade-in">
      <div 
        className="w-full max-w-2xl max-h-[92vh] flex flex-col rounded-2xl bg-[#030d06] border border-[#14502D] text-[#CDEBD8] shadow-2xl overflow-hidden"
        style={{ borderColor: 'var(--cor-borda)' }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#14502D]/60 bg-[#06180c]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#0E7A3D]/20 border border-[#0E7A3D] flex items-center justify-center text-[#2FD16F]">
              <Stethoscope size={22} />
            </div>
            <div>
              <h2 className="text-base font-semibold tracking-wide text-white flex items-center gap-2">
                Análise de Fotos de Campo
                {reportResult?.isSingleBrain && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    1 cérebro
                  </span>
                )}
              </h2>
              <p className="text-xs text-[#CDEBD8]/70">
                Avaliação veterinária multimodal com Gemini + Groq
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-lg text-[#CDEBD8]/70 hover:text-white hover:bg-[#14502D]/40 transition min-h-[44px] min-w-[44px] flex items-center justify-center"
            aria-label="Fechar"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Photos picker area */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-[#2FD16F] uppercase tracking-wider">
                Fotos do Paciente / Lesão ({images.length}/4)
              </label>
              <span className="text-[11px] text-[#CDEBD8]/60">
                Redimensionamento automático a 1280px (sem GPS)
              </span>
            </div>

            {/* Hidden Inputs */}
            <input 
              ref={cameraInputRef}
              type="file" 
              accept="image/*" 
              capture="environment"
              className="hidden" 
              onChange={(e) => handleFilesSelected(e.target.files)}
            />
            <input 
              ref={fileInputRef}
              type="file" 
              accept="image/*" 
              multiple 
              className="hidden" 
              onChange={(e) => handleFilesSelected(e.target.files)}
            />

            {/* Thumbnails grid */}
            <div className="grid grid-cols-4 gap-2 mb-3">
              {images.map((img, idx) => (
                <div key={idx} className="relative aspect-square rounded-xl overflow-hidden border border-[#14502D] group bg-black">
                  <img src={img} alt={`Foto ${idx + 1}`} className="w-full h-full object-cover" />
                  <button
                    onClick={() => handleRemoveImage(idx)}
                    className="absolute top-1 right-1 p-1 rounded-full bg-black/70 text-red-400 hover:text-white hover:bg-red-600 transition"
                    title="Remover foto"
                  >
                    <X size={14} />
                  </button>
                  <span className="absolute bottom-1 left-1 px-1.5 py-0.5 rounded text-[10px] bg-black/60 text-white font-mono">
                    #{idx + 1}
                  </span>
                </div>
              ))}

              {/* Add buttons if slot available */}
              {images.length < 4 && (
                <div className="aspect-square flex flex-col items-center justify-center gap-1 rounded-xl border border-dashed border-[#14502D] hover:border-[#2FD16F] bg-[#0E7A3D]/5 transition p-1">
                  <div className="flex gap-1">
                    <button
                      type="button"
                      onClick={() => cameraInputRef.current?.click()}
                      className="p-2 rounded-lg bg-[#0E7A3D]/30 hover:bg-[#0E7A3D]/60 text-[#2FD16F] transition"
                      title="Tirar foto com câmera"
                    >
                      <Camera size={18} />
                    </button>
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="p-2 rounded-lg bg-[#0E7A3D]/30 hover:bg-[#0E7A3D]/60 text-[#2FD16F] transition"
                      title="Escolher da galeria"
                    >
                      <ImageIcon size={18} />
                    </button>
                  </div>
                  <span className="text-[10px] text-center text-[#CDEBD8]/70">Adicionar</span>
                </div>
              )}
            </div>

            {/* Quick action buttons for mobile */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => cameraInputRef.current?.click()}
                disabled={images.length >= 4 || analyzing}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl border border-[#14502D] bg-[#061c0e] hover:bg-[#0E7A3D]/30 text-white font-medium text-xs transition disabled:opacity-50 min-h-[48px]"
              >
                <Camera size={18} className="text-[#2FD16F]" />
                <span>Câmera de Campo</span>
              </button>
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={images.length >= 4 || analyzing}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl border border-[#14502D] bg-[#061c0e] hover:bg-[#0E7A3D]/30 text-white font-medium text-xs transition disabled:opacity-50 min-h-[48px]"
              >
                <ImageIcon size={18} className="text-[#2FD16F]" />
                <span>Galeria ({images.length}/4)</span>
              </button>
            </div>
          </div>

          {/* Clinical Context input */}
          <div>
            <label className="block text-xs font-semibold text-[#2FD16F] uppercase tracking-wider mb-1.5">
              Contexto Clínico (Opcional)
            </label>
            <textarea
              value={clinicalContext}
              onChange={(e) => setClinicalContext(e.target.value)}
              placeholder="Ex: Cão Labrador, 5 anos, lesão alopécica prurítica em região dorsal há 2 semanas. Sem febre..."
              rows={2}
              className="w-full px-3 py-2.5 rounded-xl bg-black/60 border border-[#14502D] text-[#CDEBD8] placeholder-[#CDEBD8]/40 text-sm focus:outline-none focus:border-[#2FD16F] transition resize-none"
            />
          </div>

          {/* Action button */}
          <button
            onClick={handleRunAnalysis}
            disabled={images.length === 0 || analyzing}
            className="w-full py-3.5 px-4 rounded-xl bg-[#0E7A3D] hover:bg-[#17B35A] text-white font-semibold text-sm shadow-lg shadow-[#0E7A3D]/25 transition flex items-center justify-center gap-2 disabled:opacity-50 min-h-[48px]"
          >
            {analyzing ? (
              <>
                <Loader2 size={18} className="animate-spin text-white" />
                <span>HELENA analisando fotos com 2 cérebros...</span>
              </>
            ) : (
              <>
                <Sparkles size={18} />
                <span>Analisar com 2 Cérebros Visuais</span>
              </>
            )}
          </button>

          {errorMsg && (
            <div className="p-3 rounded-xl bg-red-950/40 border border-red-800 text-red-200 text-xs flex items-center gap-2">
              <AlertCircle size={16} className="shrink-0 text-red-400" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Report Result Display */}
          {reportResult && (
            <div className="space-y-4 pt-2 border-t border-[#14502D]/60 animate-fade-in">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-[#2FD16F] uppercase tracking-wider flex items-center gap-1.5">
                  <Stethoscope size={14} /> Relatório Clínico Estruturado
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleSpeakReport}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#0E7A3D]/30 border border-[#0E7A3D] text-xs font-medium text-white hover:bg-[#0E7A3D]/50 transition min-h-[40px]"
                  >
                    <Volume2 size={14} className="text-[#2FD16F]" />
                    <span>Falar</span>
                  </button>
                  <button
                    onClick={handleCopyReport}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#0E7A3D]/30 border border-[#0E7A3D] text-xs font-medium text-white hover:bg-[#0E7A3D]/50 transition min-h-[40px]"
                  >
                    {copied ? <Check size={14} className="text-green-300" /> : <Copy size={14} />}
                    <span>{copied ? 'Copiado!' : 'Copiar'}</span>
                  </button>
                </div>
              </div>

              {/* Formatted Markdown Output */}
              <div className="p-4 rounded-xl bg-black/70 border border-[#14502D] text-sm text-[#CDEBD8] space-y-3 whitespace-pre-line leading-relaxed font-sans">
                {reportResult.reportText}
              </div>

              {/* Medical Disclaimer */}
              <div className="p-3.5 rounded-xl bg-amber-950/30 border border-amber-600/40 text-amber-200/90 text-xs flex items-start gap-2.5">
                <ShieldAlert size={18} className="shrink-0 text-amber-400 mt-0.5" />
                <p className="leading-snug">
                  <strong>Aviso Veterinário Obrigatório:</strong> Esta análise é uma ferramenta de apoio à decisão clínica e não substitui a avaliação presencial do Médico Veterinário. CRMV obrigatório para prescrição medicamentosa.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
