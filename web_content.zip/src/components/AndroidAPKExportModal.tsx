/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Smartphone,
  X,
  Copy,
  Check,
  Download,
  Terminal,
  Code2,
  FileCode,
  ShieldCheck,
  Layers,
} from 'lucide-react';

interface AndroidAPKExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidAPKExportModal: React.FC<AndroidAPKExportModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'capacitor' | 'kotlin_compose' | 'manifest'>('capacitor');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyText = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const capacitorCommands = `# 1. Build the high-performance production web bundle
npm run build

# 2. Install Capacitor core and Android bridge
npm install @capacitor/core @capacitor/cli @capacitor/android

# 3. Initialize the DJ SUNNY MUSIC Capacitor project
npx cap init "DJ SUNNY MUSIC" "com.djsunny.music" --web-dir dist

# 4. Add the Android native platform
npx cap add android

# 5. Sync the web assets into the Android native project
npx cap sync android

# 6. Open in Android Studio to build the signed APK or Run on Device
npx cap open android

# In Android Studio:
# Click: Build -> Build Bundle(s) / APK(s) -> Build APK(s)
# Your APK will be located at:
# android/app/build/outputs/apk/debug/app-debug.apk`;

  const kotlinComposeCode = `package com.djsunny.music

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize Media3 / ExoPlayer
        player = ExoPlayer.Builder(this).build()

        setContent {
            DJSunnyMusicTheme {
                DJSunnyApp(player)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        player.release()
    }
}

@Composable
fun DJSunnyApp(player: ExoPlayer) {
    var isPlaying by remember { mutableStateOf(false) }
    var rotationAngle by remember { mutableStateOf(0f) }

    // Neon Colors
    val neonCyan = Color(0xFF00F0FF)
    val neonPurple = Color(0xFFB026FF)
    val neonRed = Color(0xFFFF0055)
    val bgDark = Color(0xFF07080F)

    // Turntable continuous rotation animation
    val infiniteTransition = rememberInfiniteTransition(label = "turntable_spin")
    val autoRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spin_angle"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(bgDark)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // App Header
        Text(
            text = "DJ SUNNY MUSIC",
            color = neonCyan,
            fontSize = 24.sp,
            modifier = Modifier.padding(vertical = 12.dp)
        )

        // 1. Live Real-Time Waveform Canvas (Jetpack Compose)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .background(Color(0xFF0D0E18), RoundedCornerShape(16.dp))
                .padding(8.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val centerY = size.height / 2
                val step = size.width / 48
                for (i in 0 until 48) {
                    val amp = if (isPlaying) (Math.sin(i * 0.4 + autoRotation * 0.1).toFloat() * 40f) else 5f
                    drawLine(
                        brush = Brush.verticalGradient(listOf(neonCyan, neonPurple, neonRed)),
                        start = Offset(i * step, centerY - amp),
                        end = Offset(i * step, centerY + amp),
                        strokeWidth = 6f,
                        cap = StrokeCap.Round
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 2. Rotating DJ Vinyl Turntable with Touch Scratch Gesture
        Box(
            modifier = Modifier
                .size(260.dp)
                .shadow(24.dp, CircleShape, spotColor = neonCyan)
                .background(Color(0xFF14151F), CircleShape)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        rotationAngle += (dragAmount.x - dragAmount.y) * 0.5f
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            // Vinyl Platter
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .rotate(if (isPlaying) autoRotation + rotationAngle else rotationAngle)
                    .background(Color(0xFF080808), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                // Vinyl grooves rings
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCircle(color = Color(0xFF1A1A1A), radius = size.minDimension / 2.2f)
                    drawCircle(color = Color(0xFF111111), radius = size.minDimension / 2.6f)
                    drawCircle(color = Color(0xFF222222), radius = size.minDimension / 3.2f)
                }

                // Center Label
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .background(Brush.radialGradient(listOf(neonCyan, neonPurple)), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "DJ SUNNY", color = Color.White, fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 3. Play / Pause & Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = {
                    isPlaying = !isPlaying
                    if (isPlaying) player.play() else player.pause()
                },
                colors = ButtonDefaults.buttonColors(containerColor = neonCyan),
                shape = CircleShape,
                modifier = Modifier.size(64.dp)
            ) {
                Text(if (isPlaying) "❚❚" else "▶", color = Color.Black, fontSize = 20.sp)
            }
        }
    }
}`;

  const manifestCode = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.djsunny.music">

    <!-- Audio Playback & Real-Time Waveform Visualizer Permissions -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="DJ SUNNY MUSIC"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.DJSunnyMusic"
        android:hardwareAccelerated="true">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|screenLayout|keyboardHidden"
            android:theme="@style/Theme.DJSunnyMusic">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-3xl max-h-[92vh] overflow-y-auto rounded-3xl bg-[#0c0d18] border border-cyan-500/40 p-6 shadow-[0_0_60px_rgba(0,240,255,0.25)]">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl bg-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-700 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="p-2.5 rounded-2xl bg-gradient-to-tr from-cyan-400 to-purple-600 shadow-[0_0_15px_#00f0ff]">
            <Smartphone className="w-6 h-6 text-black" />
          </div>
          <div>
            <h3 className="text-xl font-extrabold text-white font-dj tracking-wider">
              EXPORT AS ANDROID APK
            </h3>
            <p className="text-xs text-cyan-300">
              DJ SUNNY MUSIC • Capacitor APK Workflow &amp; Native Jetpack Compose Code
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 mb-5 p-1 rounded-2xl bg-zinc-900 border border-zinc-800">
          <button
            onClick={() => setActiveTab('capacitor')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold font-dj uppercase transition-all ${
              activeTab === 'capacitor'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-black shadow-[0_0_12px_#00f0ff]'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>1-CLICK CAPACITOR APK</span>
          </button>

          <button
            onClick={() => setActiveTab('kotlin_compose')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold font-dj uppercase transition-all ${
              activeTab === 'kotlin_compose'
                ? 'bg-gradient-to-r from-purple-500 to-pink-600 text-white shadow-[0_0_12px_#b026ff]'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Code2 className="w-4 h-4" />
            <span>KOTLIN + JETPACK COMPOSE</span>
          </button>

          <button
            onClick={() => setActiveTab('manifest')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold font-dj uppercase transition-all ${
              activeTab === 'manifest'
                ? 'bg-gradient-to-r from-red-500 to-orange-500 text-white shadow-[0_0_12px_#ff0055]'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            <FileCode className="w-4 h-4" />
            <span>MANIFEST &amp; EXOPLAYER</span>
          </button>
        </div>

        {/* Tab 1: Capacitor APK Build Instructions */}
        {activeTab === 'capacitor' && (
          <div className="space-y-4 animate-fade-in">
            <div className="p-4 rounded-2xl bg-cyan-950/20 border border-cyan-500/30 flex items-start gap-3">
              <ShieldCheck className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
              <div>
                <h5 className="text-xs font-bold text-cyan-300 font-dj uppercase mb-1">
                  RECOMMENDED FASTEST METHOD TO GET AN APK
                </h5>
                <p className="text-xs text-zinc-300 leading-relaxed">
                  This compiles the live React + Web Audio applet into a native Android Studio project using Capacitor. You get an installable <code>.apk</code> with hardware acceleration, audio background playback, and all 60fps waveform animations preserved.
                </p>
              </div>
            </div>

            <div className="relative rounded-2xl bg-black/80 border border-zinc-800 p-4 font-mono text-xs text-cyan-300 overflow-x-auto">
              <button
                onClick={() => copyText(capacitorCommands, 'capacitor')}
                className="absolute top-3 right-3 flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[11px] font-sans font-bold transition-all"
              >
                {copiedKey === 'capacitor' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'capacitor' ? 'COPIED!' : 'COPY COMMANDS'}</span>
              </button>
              <pre className="pr-24">{capacitorCommands}</pre>
            </div>
          </div>
        )}

        {/* Tab 2: Native Kotlin + Jetpack Compose */}
        {activeTab === 'kotlin_compose' && (
          <div className="space-y-4 animate-fade-in">
            <div className="p-4 rounded-2xl bg-purple-950/20 border border-purple-500/30 flex items-start gap-3">
              <Layers className="w-5 h-5 text-purple-400 shrink-0 mt-0.5" />
              <div>
                <h5 className="text-xs font-bold text-purple-300 font-dj uppercase mb-1">
                  100% NATIVE JETPACK COMPOSE &amp; EXOPLAYER / MEDIA3
                </h5>
                <p className="text-xs text-zinc-300 leading-relaxed">
                  Complete native source code for Android Studio. Includes custom Compose <code>Canvas</code> waveform rendering, ExoPlayer playback, touch drag vinyl scratch gestures, and neon theme gradients.
                </p>
              </div>
            </div>

            <div className="relative rounded-2xl bg-black/80 border border-zinc-800 p-4 font-mono text-xs text-purple-300 overflow-x-auto max-h-[380px]">
              <button
                onClick={() => copyText(kotlinComposeCode, 'kotlin')}
                className="absolute top-3 right-3 flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[11px] font-sans font-bold transition-all z-10"
              >
                {copiedKey === 'kotlin' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'kotlin' ? 'COPIED!' : 'COPY KOTLIN CODE'}</span>
              </button>
              <pre>{kotlinComposeCode}</pre>
            </div>
          </div>
        )}

        {/* Tab 3: AndroidManifest.xml */}
        {activeTab === 'manifest' && (
          <div className="space-y-4 animate-fade-in">
            <div className="p-4 rounded-2xl bg-red-950/20 border border-red-500/30 flex items-start gap-3">
              <FileCode className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
              <div>
                <h5 className="text-xs font-bold text-red-300 font-dj uppercase mb-1">
                  ANDROID MANIFEST &amp; AUDIO PERMISSIONS
                </h5>
                <p className="text-xs text-zinc-300 leading-relaxed">
                  Requires <code>MODIFY_AUDIO_SETTINGS</code> and <code>RECORD_AUDIO</code> for the Android audio visualizer session, along with foreground service permissions for background DJ playback.
                </p>
              </div>
            </div>

            <div className="relative rounded-2xl bg-black/80 border border-zinc-800 p-4 font-mono text-xs text-red-300 overflow-x-auto">
              <button
                onClick={() => copyText(manifestCode, 'manifest')}
                className="absolute top-3 right-3 flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[11px] font-sans font-bold transition-all"
              >
                {copiedKey === 'manifest' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'manifest' ? 'COPIED!' : 'COPY MANIFEST'}</span>
              </button>
              <pre>{manifestCode}</pre>
            </div>
          </div>
        )}

        {/* Footer Actions */}
        <div className="mt-6 pt-4 border-t border-zinc-800 flex items-center justify-between">
          <span className="text-xs text-zinc-500 font-mono">
            Package: com.djsunny.music • Android 8.0+ (API 26+)
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold font-dj uppercase transition-all"
          >
            CLOSE
          </button>
        </div>

      </div>
    </div>
  );
};
