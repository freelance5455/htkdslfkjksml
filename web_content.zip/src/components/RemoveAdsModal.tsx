/**
 * SPR - Sahil Powerful Run
 * Remove Ads / VIP Pass Modal
 */

import React from 'react';
import { X, ShieldCheck, Check, Crown, Zap, WifiOff } from 'lucide-react';
import { soundManager } from '../game/audio/SoundManager';

interface Props {
  onClose: () => void;
}

export const RemoveAdsModal: React.FC<Props> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-sm bg-gradient-to-b from-slate-900 via-red-950/40 to-black border-2 border-red-500/50 rounded-3xl p-6 shadow-[0_0_50px_rgba(239,68,68,0.4)] flex flex-col items-center text-center">
        <button
          onClick={() => {
            soundManager.playButtonClick();
            onClose();
          }}
          className="absolute top-4 right-4 w-9 h-9 rounded-full bg-slate-800/80 border border-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-red-600 to-amber-500 flex items-center justify-center shadow-[0_0_25px_rgba(239,68,68,0.6)] mb-3">
          <ShieldCheck className="w-8 h-8 text-white" />
        </div>

        <h2 className="text-2xl font-black text-white uppercase tracking-wider font-heading">
          VIP AD-FREE PASS
        </h2>
        <p className="text-xs text-red-200 mt-1">
          Enjoy clean, uninterrupted 60 FPS runner gameplay
        </p>

        <div className="my-4 space-y-2 w-full text-left">
          <div className="p-2.5 bg-slate-800/80 border border-emerald-500/30 rounded-xl flex items-center gap-2.5">
            <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="text-xs text-slate-200 font-semibold">100% Ad-Free Guarantee (Zero popups)</span>
          </div>
          <div className="p-2.5 bg-slate-800/80 border border-cyan-500/30 rounded-xl flex items-center gap-2.5">
            <WifiOff className="w-4 h-4 text-cyan-400 shrink-0" />
            <span className="text-xs text-slate-200 font-semibold">100% Offline Capable (No Internet Needed)</span>
          </div>
          <div className="p-2.5 bg-slate-800/80 border border-amber-500/30 rounded-xl flex items-center gap-2.5">
            <Crown className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="text-xs text-slate-200 font-semibold">Crown VIP Gold Profile Badge Included</span>
          </div>
        </div>

        <div className="w-full py-3 bg-emerald-500/20 border border-emerald-500/50 rounded-2xl text-center text-emerald-300 font-bold text-sm">
          ✓ LIFETIME AD-FREE ACTIVATED
        </div>

        <button
          onClick={() => {
            soundManager.playButtonClick();
            onClose();
          }}
          className="mt-4 w-full py-3 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs uppercase rounded-xl transition cursor-pointer"
        >
          BACK TO GAME
        </button>
      </div>
    </div>
  );
};
