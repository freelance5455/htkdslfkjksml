import React from 'react';
import { 
  Home,
  Layout,
  Users,
  Sparkles,
  GitBranch,
  Eye,
  FileCode,
  Database,
  ShieldCheck,
  Layers,
  RotateCcw,
  Settings,
  ChevronLeft,
  ChevronRight,
  Activity,
  ArrowRight,
  Film,
  Video,
  Wand2
} from 'lucide-react';
import { WorkspaceViewMode, SidebarViewId, AICenterTab } from '../types';
import { GodexLogo } from './GodexLogo';

export interface NavRailItem {
  id: WorkspaceViewMode;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
}

interface GodexNavRailProps {
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  activeWorkspaceView: WorkspaceViewMode;
  activeSidebarView: SidebarViewId | null;
  activeAiTab?: AICenterTab;
  onSelectWorkspaceView: (view: WorkspaceViewMode) => void;
  onSelectSidebarView: (view: SidebarViewId | null) => void;
  onSelectAiTab?: (tab: AICenterTab) => void;
  onOpenSettings: () => void;
  onOpenTemplates: () => void;
  taskState?: string;
}

export const GodexNavRail: React.FC<GodexNavRailProps> = ({
  isCollapsed,
  onToggleCollapse,
  activeWorkspaceView,
  activeSidebarView,
  activeAiTab = 'chat',
  onSelectWorkspaceView,
  onSelectSidebarView,
  onSelectAiTab,
  onOpenSettings,
  onOpenTemplates,
  taskState
}) => {
  const navItems: NavRailItem[] = [
    { id: 'creative-studio', label: 'Creative Studio', icon: Film, badge: 'P3.2' },
    { id: 'mission-control', label: 'Mission Control', icon: Activity, badge: taskState && taskState !== 'IDLE' ? taskState : undefined },
    { id: 'studio', label: 'AI Agent Studio', icon: Layout },
    { id: 'editor', label: 'Codebase', icon: FileCode },
    { id: 'preview', label: 'Live Preview', icon: Eye },
    { id: 'agents', label: 'Agent Matrix', icon: Users },
    { id: 'intelligence', label: 'Intelligence', icon: Sparkles },
    { id: 'task-graph', label: 'Task Graph', icon: GitBranch },
    { id: 'memory', label: 'Knowledge Hub', icon: Database },
    { id: 'verifications', label: 'Verifications', icon: ShieldCheck },
    { id: 'dossier', label: 'Dossier', icon: Layers },
    { id: 'replay', label: 'Replay Center', icon: RotateCcw },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  const handleNavClick = (view: WorkspaceViewMode) => {
    if (view === 'settings') {
      onOpenSettings();
      return;
    }
    onSelectWorkspaceView(view);
  };

  // Check if item is active
  const isItemActive = (id: WorkspaceViewMode) => {
    if (id === 'creative-studio' && (activeWorkspaceView === 'creative-studio' || activeWorkspaceView === 'home' || activeWorkspaceView === 'media-studio')) return true;
    return activeWorkspaceView === id;
  };

  return (
    <aside 
      id="godex-navigation-rail"
      className={`h-full bg-[#080D1A] border-r border-[#18233C] flex flex-col justify-between shrink-0 select-none transition-all duration-200 z-20 font-sans ${
        isCollapsed ? 'w-16' : 'w-56'
      }`}
    >
      {/* Top Header / GODEX Logo */}
      <div className="h-14 px-3.5 border-b border-[#18233C] flex items-center justify-between bg-[#0A0F1C]">
        {!isCollapsed ? (
          <div 
            onClick={() => onSelectWorkspaceView('home')}
            className="flex items-center gap-2 cursor-pointer group"
          >
            <GodexLogo size={28} showText={true} showTagline={false} />
          </div>
        ) : (
          <div 
            onClick={() => onSelectWorkspaceView('home')}
            className="w-full flex items-center justify-center cursor-pointer"
          >
            <GodexLogo size={28} showText={false} />
          </div>
        )}

        <button
          onClick={onToggleCollapse}
          className="p-1 rounded-md text-neutral-400 hover:text-white hover:bg-[#141E33] transition-colors"
          title={isCollapsed ? 'Expand Navigation' : 'Collapse Navigation'}
        >
          {isCollapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
        </button>
      </div>

      {/* Main Navigation Items */}
      <div className="flex-1 overflow-y-auto py-3 px-2 space-y-1 no-scrollbar">
        {navItems.map((item) => {
          const active = isItemActive(item.id);
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs transition-all duration-150 relative group ${
                active
                  ? 'bg-gradient-to-r from-purple-950/60 to-indigo-950/40 text-white font-semibold border border-purple-500/40 shadow-[0_0_16px_rgba(124,58,237,0.15)]'
                  : 'text-neutral-400 hover:text-white hover:bg-[#0E1528] border border-transparent'
              }`}
              title={isCollapsed ? item.label : undefined}
            >
              <div className={`shrink-0 ${active ? 'text-purple-400' : 'text-neutral-400 group-hover:text-neutral-200'}`}>
                <Icon className="w-4 h-4" />
              </div>

              {!isCollapsed && (
                <div className="flex-1 flex items-center justify-between min-w-0">
                  <span className="truncate text-[12px] font-medium tracking-wide">{item.label}</span>
                  {active && (
                    <ArrowRight className="w-3 h-3 text-purple-400 opacity-80" />
                  )}
                </div>
              )}
            </button>
          );
        })}
      </div>

      {/* Bottom System Status Widget (Exact from reference) */}
      {!isCollapsed ? (
        <div className="p-3 m-2 rounded-xl bg-[#0B101E] border border-[#1C2844] space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[9px] font-mono font-bold text-neutral-400 uppercase tracking-wider">SYSTEM STATUS</span>
          </div>

          {/* Operational Heartbeat line */}
          <div className="flex items-center justify-between py-1 px-1.5 rounded-lg bg-[#0E162B] border border-emerald-500/30">
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-[10px] font-mono font-bold text-emerald-400 tracking-wider">OPERATIONAL</span>
            </div>
            {/* Mini Heartbeat waveform */}
            <svg className="w-8 h-3 text-emerald-400" viewBox="0 0 32 12" fill="none">
              <path d="M0,6 L8,6 L11,1 L14,11 L17,4 L20,8 L23,6 L32,6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>

          {/* Compact Telemetry Table */}
          <div className="space-y-1 text-[10px] font-mono pt-1">
            <div className="flex items-center justify-between text-neutral-400">
              <span>Agents Online</span>
              <span className="text-emerald-400 font-bold">24/24</span>
            </div>
            <div className="flex items-center justify-between text-neutral-400">
              <span>Tasks Running</span>
              <span className="text-cyan-400 font-bold">7</span>
            </div>
            <div className="flex items-center justify-between text-neutral-400">
              <span>Success Rate</span>
              <span className="text-emerald-400 font-bold">99.71%</span>
            </div>
            <div className="flex items-center justify-between text-neutral-400">
              <span>System Health</span>
              <span className="text-emerald-400 font-bold">100%</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-2 border-t border-[#18233C] flex flex-col items-center gap-1">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" title="System Operational (100% Health)" />
        </div>
      )}
    </aside>
  );
};
