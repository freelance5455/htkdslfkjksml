import React, { useEffect } from 'react';
import {
  Download,
  CheckCircle,
  ShieldCheck,
  FileCode2,
  Copy,
  Check,
  RotateCcw,
  Sparkles,
  ExternalLink
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { RecompileResult } from '../utils/apkSigner';
import { PackageMetadata, IdentifiedResource } from '../types';

interface CompletedStageProps {
  result: RecompileResult;
  metadata: PackageMetadata;
  resources: IdentifiedResource[];
  onReset: () => void;
}

export const CompletedStage: React.FC<CompletedStageProps> = ({
  result,
  metadata,
  resources,
  onReset
}) => {
  const [copiedSha, setCopiedSha] = React.useState(false);

  useEffect(() => {
    // Fire confetti when reaching completed stage
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {
      // ignore
    }
  }, []);

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = result.downloadUrl;
    link.download = result.outputFileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    // Minor celebration on download click
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 }
      });
    } catch {
      // ignore
    }
  };

  const copySha = () => {
    navigator.clipboard.writeText(result.sha256Digest);
    setCopiedSha(true);
    setTimeout(() => setCopiedSha(false), 2000);
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  // Group modified files
  const uniqueFiles = Array.from(new Set(resources.map((r) => r.filePath)));

  return (
    <div className="flex flex-col items-center justify-center w-full max-w-2xl mx-auto py-4">
      {/* Success Badge */}
      <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-3xl bg-emerald-500/20 border-2 border-emerald-500/40 flex items-center justify-center text-emerald-400 mb-4 shadow-xl shadow-emerald-500/20 animate-bounce">
        <CheckCircle className="w-8 h-8 sm:w-10 sm:h-10 text-emerald-400" />
      </div>

      <div className="text-center mb-6">
        <span className="text-xs font-semibold text-emerald-400 uppercase tracking-widest font-mono">
          Ready for Installation
        </span>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mt-1">
          Package Recompiled &amp; Digitally Signed!
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-md mx-auto">
          All modified currency values have been saved into the package with new SHA-256 digests and Android v2 signature schemes applied.
        </p>
      </div>

      {/* EXACT REQUIRED BUTTON: "Download the newly generated APK or XAPK file here" */}
      <div className="w-full mb-6">
        <button
          onClick={handleDownload}
          className="w-full py-5 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-500 hover:from-emerald-400 hover:via-teal-300 hover:to-emerald-400 text-slate-950 font-extrabold text-base sm:text-lg shadow-2xl shadow-emerald-500/30 hover:shadow-emerald-500/50 transform active:scale-[0.99] transition-all flex items-center justify-center gap-3 cursor-pointer group"
        >
          <Download className="w-6 h-6 group-hover:-translate-y-0.5 transition-transform stroke-[2.5]" />
          <span>Download the newly generated APK or XAPK file here</span>
        </button>
      </div>

      {/* Recompiled Package Details Card */}
      <div className="w-full bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
            <FileCode2 className="w-4 h-4 text-emerald-400" />
            Generated Package Specs
          </span>
          <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
            {metadata.fileType.toUpperCase()} • Signed
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
            <span className="text-slate-400 block text-[10px] uppercase font-semibold">
              File Name
            </span>
            <span className="font-mono text-white font-bold truncate block mt-0.5">
              {result.outputFileName}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
            <span className="text-slate-400 block text-[10px] uppercase font-semibold">
              Package Size
            </span>
            <span className="font-mono text-emerald-400 font-bold block mt-0.5">
              {formatFileSize(result.fileSize)}
            </span>
          </div>
        </div>

        {/* Digital Signature Information */}
        <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Applied Digital Signature:
            </span>
            <span className="text-[10px] font-mono text-emerald-400">VERIFIED</span>
          </div>
          <p className="text-[11px] text-slate-400">
            Scheme: <span className="text-slate-200 font-mono">{result.signatureScheme}</span>
          </p>
          <div className="flex items-center justify-between gap-2 bg-slate-900 px-2.5 py-1.5 rounded-lg border border-slate-800 text-[10px] font-mono text-slate-400">
            <span className="truncate">SHA-256: {result.sha256Digest}</span>
            <button
              onClick={copySha}
              className="p-1 hover:text-white transition flex-shrink-0"
              title="Copy SHA-256 Digest"
            >
              {copiedSha ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Modified Files Included */}
        <div>
          <span className="text-xs font-semibold text-slate-400 block mb-2">
            Modified Files Repackaged ({uniqueFiles.length}):
          </span>
          <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
            {uniqueFiles.map((file, i) => (
              <div
                key={i}
                className="px-3 py-1.5 rounded-lg bg-slate-950/60 border border-slate-800/80 font-mono text-[11px] text-slate-300 flex items-center justify-between"
              >
                <span className="truncate max-w-[280px] sm:max-w-md">{file}</span>
                <span className="text-[10px] text-emerald-400 font-sans font-semibold">
                  Patched
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Installation Tip for Android users */}
        <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300/90 flex items-start gap-2">
          <Sparkles className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
          <span>
            <strong>Android Installation Note:</strong> When installing recompiled APKs on Android, ensure &quot;Install Unknown Apps&quot; is enabled in your device settings. For XAPK files, you can use any XAPK installer or unzip to access the base APK.
          </span>
        </div>
      </div>

      {/* Start Over Button */}
      <div className="mt-6 flex items-center gap-3">
        <button
          onClick={onReset}
          className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 hover:text-white border border-slate-700 transition flex items-center gap-2 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Analyze Another Package</span>
        </button>
      </div>
    </div>
  );
};
