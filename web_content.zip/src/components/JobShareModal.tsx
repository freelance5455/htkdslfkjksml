import React, { useState } from 'react';
import { JobPosting } from '../types/job';
import { X, Copy, Check, Share2, ExternalLink } from 'lucide-react';
import { incrementJobShareCount } from '../lib/firebase';

interface JobShareModalProps {
  job: JobPosting | null;
  isOpen: boolean;
  onClose: () => void;
  onShareTracked?: (jobId: string) => void;
}

export const JobShareModal: React.FC<JobShareModalProps> = ({
  job,
  isOpen,
  onClose,
  onShareTracked
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen || !job) return null;

  // Generate deep link that targets this specific job
  const shareUrl = `${window.location.origin}${window.location.pathname}?job=${job.id}`;
  const shareText = `🚨 New Job Alert: ${job.title} at ${job.organization}\n📍 ${job.district}, ${job.state} | 👥 ${job.vacancies} Posts\n⏳ Deadline: ${job.closingDate || job.lastDate}\nCheck eligibility & apply:`;

  const trackShare = () => {
    incrementJobShareCount(job.id).catch(() => {});
    if (onShareTracked) onShareTracked(job.id);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    trackShare();
    setTimeout(() => setCopied(false), 2500);
  };

  const handleWhatsApp = () => {
    trackShare();
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText + '\n' + shareUrl)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleTelegram = () => {
    trackShare();
    const url = `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleFacebook = () => {
    trackShare();
    const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm p-0 sm:p-4">
      <div
        id="modal-job-share"
        className="w-full max-w-md bg-slate-900 border-t sm:border border-slate-800 rounded-t-3xl sm:rounded-2xl p-5 shadow-2xl space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-200"
      >
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Share2 className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">Share Vacancy</h2>
              <p className="text-[11px] text-slate-400">Send verified alert to friends & study groups</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Job summary card */}
        <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60 text-xs space-y-1">
          <span className="font-bold text-white block line-clamp-1">{job.title}</span>
          <p className="text-slate-300 text-[11px]">{job.organization} • {job.state}</p>
          <div className="flex items-center gap-2 pt-1 text-[10px] text-slate-400">
            <span>{job.vacancies} Posts</span>
            <span>•</span>
            <span className="text-amber-400 font-semibold">Deadline: {job.closingDate || job.lastDate}</span>
          </div>
        </div>

        {/* Share buttons grid */}
        <div className="grid grid-cols-2 gap-2.5">
          {/* WhatsApp */}
          <button
            id="btn-share-whatsapp"
            onClick={handleWhatsApp}
            className="flex items-center gap-2.5 p-3 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/30 text-emerald-300 hover:text-emerald-200 transition-all font-semibold text-xs text-left"
          >
            <span className="text-lg">💬</span>
            <div>
              <span className="block font-bold">WhatsApp</span>
              <span className="text-[10px] text-emerald-400/80 font-normal">Direct message or group</span>
            </div>
          </button>

          {/* Telegram */}
          <button
            id="btn-share-telegram"
            onClick={handleTelegram}
            className="flex items-center gap-2.5 p-3 rounded-xl bg-sky-600/20 hover:bg-sky-600/30 border border-sky-500/30 text-sky-300 hover:text-sky-200 transition-all font-semibold text-xs text-left"
          >
            <span className="text-lg">✈️</span>
            <div>
              <span className="block font-bold">Telegram</span>
              <span className="text-[10px] text-sky-400/80 font-normal">Channels & chats</span>
            </div>
          </button>

          {/* Facebook */}
          <button
            id="btn-share-facebook"
            onClick={handleFacebook}
            className="flex items-center gap-2.5 p-3 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/30 text-blue-300 hover:text-blue-200 transition-all font-semibold text-xs text-left"
          >
            <span className="text-lg">📘</span>
            <div>
              <span className="block font-bold">Facebook</span>
              <span className="text-[10px] text-blue-400/80 font-normal">Share to feed</span>
            </div>
          </button>

          {/* Copy Link */}
          <button
            id="btn-share-copy-link"
            onClick={handleCopyLink}
            className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 hover:text-white transition-all font-semibold text-xs text-left"
          >
            <div className="w-6 h-6 rounded-lg bg-slate-700 flex items-center justify-center shrink-0">
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </div>
            <div>
              <span className="block font-bold">{copied ? 'Copied!' : 'Copy Link'}</span>
              <span className="text-[10px] text-slate-400 font-normal">Deep link to this job</span>
            </div>
          </button>
        </div>

        {/* Shareable Link Box */}
        <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between gap-2 text-xs">
          <input
            type="text"
            readOnly
            value={shareUrl}
            className="bg-transparent text-slate-400 text-[11px] font-mono outline-none flex-1 truncate"
          />
          <button
            onClick={handleCopyLink}
            className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-bold text-[10px] shrink-0"
          >
            {copied ? 'Copied' : 'Copy'}
          </button>
        </div>
      </div>
    </div>
  );
};
