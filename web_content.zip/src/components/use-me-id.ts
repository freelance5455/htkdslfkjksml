import { useCurrentUserState } from "@/lib/auth/use-current-user";

export function useMeId() {
  const { user } = useCurrentUserState();
  return user?.id ?? null;
}
