import React, { useState } from 'react';
import { useKhata } from '../../context/KhataContext';
import { formatRupee } from '../../i18n/translations';
import { Users, Plus, X, User, Check } from 'lucide-react';

const AVATAR_COLORS = [
  '#15803d', '#0284c7', '#d97706', '#7c3aed', '#db2777', '#0d9488', '#ea580c'
];

export const FamilyManagementModal: React.FC = () => {
  const {
    activeModal,
    setActiveModal,
    familyMembers,
    addFamilyMember,
    currentMonthTransactions,
    language,
    t
  } = useKhata();

  const [showAddMember, setShowAddMember] = useState(false);
  const [name, setName] = useState('');
  const [relationHi, setRelationHi] = useState('स्वयं');
  const [relationEn, setRelationEn] = useState('Self');
  const [color, setColor] = useState('#15803d');

  if (activeModal !== 'family-modal') return null;

  // Calculate member-wise expenses
  const memberExpenses = React.useMemo(() => {
    const map: Record<string, number> = {};
    currentMonthTransactions
      .filter(tx => tx.type === 'expense')
      .forEach(tx => {
        const mId = tx.familyMemberId || 'self';
        map[mId] = (map[mId] || 0) + tx.amount;
      });
    return map;
  }, [currentMonthTransactions]);

  const totalExpense = Object.values(memberExpenses).reduce((s, v) => s + v, 0);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    addFamilyMember({
      name: name.trim(),
      relationHi: relationHi || name.trim(),
      relationEn: relationEn || name.trim(),
      avatarColor: color
    });

    setShowAddMember(false);
    setName('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
      <div className="w-full max-w-md rounded-t-3xl sm:rounded-2xl bg-white shadow-2xl border border-slate-200 max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-xs z-10">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-emerald-700" />
            <h3 className="text-base font-bold text-slate-900">{t.familyAccountTitle}</h3>
          </div>
          <button
            onClick={() => setActiveModal(null)}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-xs text-slate-500">
              {language === 'hi'
                ? 'परिवार के सदस्यों का खर्च ट्रैक करें:'
                : 'Track expenses per household member:'}
            </p>
            <button
              onClick={() => setShowAddMember(true)}
              className="flex items-center gap-1 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{t.addFamilyMember}</span>
            </button>
          </div>

          {/* Member Spending Breakdown Cards */}
          <div className="space-y-2.5">
            {familyMembers.map(m => {
              const spent = memberExpenses[m.id] || 0;
              const percent = totalExpense > 0 ? Math.round((spent / totalExpense) * 100) : 0;

              return (
                <div
                  key={m.id}
                  className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div
                        className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm shadow-xs"
                        style={{ backgroundColor: m.avatarColor }}
                      >
                        {m.name.charAt(0)}
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-slate-900">{m.name}</h4>
                        <span className="text-[11px] text-slate-400">
                          {language === 'hi' ? m.relationHi : m.relationEn}
                        </span>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-sm font-bold text-slate-900 tabular-nums">
                        {formatRupee(spent)}
                      </div>
                      <div className="text-[11px] text-slate-400 font-medium">
                        {percent}% खर्च का हिस्सा
                      </div>
                    </div>
                  </div>

                  {/* Progress proportion */}
                  <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-300"
                      style={{
                        width: `${percent}%`,
                        backgroundColor: m.avatarColor
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {/* ADD MEMBER SUB FORM */}
          {showAddMember && (
            <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-emerald-900">{t.addFamilyMember}</h4>
                <button onClick={() => setShowAddMember(false)} className="text-slate-400">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleAddSubmit} className="space-y-3">
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="सदस्य का नाम (उदा. रीता, रोहन...)"
                  className="w-full px-3 py-2 text-xs border rounded-xl bg-white"
                  autoFocus
                />
                <input
                  type="text"
                  value={relationHi}
                  onChange={e => setRelationHi(e.target.value)}
                  placeholder="रिश्ता (उदा. बेटी, भाई, दादी...)"
                  className="w-full px-3 py-2 text-xs border rounded-xl bg-white"
                />

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    अवतार रंग (Color)
                  </label>
                  <div className="flex gap-2">
                    {AVATAR_COLORS.map(c => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => setColor(c)}
                        className={`w-6 h-6 rounded-full transition ${
                          color === c ? 'scale-125 ring-2 ring-slate-900' : ''
                        }`}
                        style={{ backgroundColor: c }}
                      />
                    ))}
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl"
                >
                  {t.save}
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
