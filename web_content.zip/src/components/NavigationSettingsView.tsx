import React, { useState } from "react";
import {
  SlidersHorizontal,
  Compass,
  Check,
  RotateCcw,
  Sparkles,
  Layout,
  Maximize2,
  Layers,
  Eye,
  CheckCircle2,
  Tv,
  Smartphone,
  Tablet,
  Sliders,
  AlignJustify,
  Sun,
  ShieldCheck,
} from "lucide-react";
import { useGlobalState } from "../context/GlobalContext";
import {
  NAVBAR_POSITIONS,
  ACTIVE_INDICATOR_OPTIONS,
  LABEL_MODE_OPTIONS,
  DEFAULT_NAVBAR_CONFIG,
} from "../utils/navBarConfig";
import { NavBarPosition, NavBarActiveIndicatorStyle, NavBarLabelMode } from "../types";

interface NavigationSettingsViewProps {
  onNotify?: (msg: string) => void;
}

export const NavigationSettingsView: React.FC<NavigationSettingsViewProps> = ({ onNotify }) => {
  const { state, updateNavBarConfig, resetNavBarConfig } = useGlobalState();
  const config = state.navBarConfig;

  const [previewActiveTab, setPreviewActiveTab] = useState<string>("home");

  const notify = (msg: string) => {
    if (onNotify) onNotify(msg);
  };

  return (
    <div className="w-full space-y-6 animate-in fade-in duration-200">
      {/* Top Header Card */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-start gap-3">
          <div className="w-11 h-11 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800 flex items-center justify-center shrink-0 shadow-xs">
            <Compass className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-base font-black text-slate-900 dark:text-white">
                Dinamik Navigasyon Çubuğu & Dok Ayarları
              </h3>
              <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                Safe Area Entegre
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-2xl leading-relaxed">
              Navigasyon çubuğunun ekran konumunu (Alt Yapışık, Yüzen Dok, Üst Çubuk, Kenar Menü), kalınlığını, saydamlığını ve aktif sekme vurgu biçimlerini dilediğiniz gibi özelleştirin.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => {
            resetNavBarConfig();
            notify("✓ Navigasyon çubuğu fabrika ayarlarına sıfırlandı.");
          }}
          className="px-3.5 py-2 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center gap-1.5 transition-colors cursor-pointer self-start sm:self-auto shrink-0 shadow-2xs"
          title="Varsayılan Navigasyon Düzene Dön"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Varsayılana Sıfırla</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* 1. CANLI DİNAMİK NAVİGASYON ÖNİZLEME KARTI (LIVE PREVIEW ARENA)           */}
      {/* ========================================================================= */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-100/80 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-3">
        <div className="flex items-center justify-between text-xs font-bold text-slate-600 dark:text-slate-300">
          <span className="flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-indigo-500" />
            <span>Canlı Navigasyon Önizlemesi:</span>
          </span>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
            {config.position} • {config.height}px • %{config.widthPercent}
          </span>
        </div>

        {/* Mock Screen Arena */}
        <div className="relative w-full h-44 rounded-2xl bg-gradient-to-br from-slate-200 via-slate-100 to-slate-200 dark:from-slate-900 dark:via-slate-800/80 dark:to-slate-900 border border-slate-300 dark:border-slate-700 overflow-hidden flex items-center justify-center p-3 select-none">
          <div className="text-center space-y-1 opacity-60 pointer-events-none">
            <h4 className="text-xs font-black text-slate-800 dark:text-white">NoteFlow Çalışma Alanı</h4>
            <p className="text-[10px] text-slate-500">Notlar, zihin haritaları ve çizim tuvali...</p>
          </div>

          {/* Mini Mock Nav Bar */}
          <div
            className={`transition-all duration-300 flex items-center justify-around border shadow-xl ${
              config.position === "bottom_fixed"
                ? "absolute bottom-0 left-0 right-0 w-full rounded-none border-t"
                : config.position === "floating_dock"
                ? "absolute bottom-2 left-1/2 -translate-x-1/2 border"
                : config.position === "top_bar"
                ? "absolute top-0 left-0 right-0 w-full rounded-none border-b"
                : config.position === "sidebar_left"
                ? "absolute left-2 top-2 bottom-2 h-auto flex-col border"
                : "absolute right-2 top-2 bottom-2 h-auto flex-col border"
            }`}
            style={{
              height:
                config.position === "sidebar_left" || config.position === "sidebar_right"
                  ? "calc(100% - 16px)"
                  : `${Math.round(config.height * 0.75)}px`,
              width:
                config.position === "sidebar_left" || config.position === "sidebar_right"
                  ? "54px"
                  : config.position === "bottom_fixed" || config.position === "top_bar"
                  ? "100%"
                  : `${config.widthPercent}%`,
              maxWidth: config.position === "floating_dock" ? "420px" : undefined,
              borderRadius:
                config.position === "bottom_fixed" || config.position === "top_bar"
                  ? "0px"
                  : `${Math.round(config.borderRadius * 0.75)}px`,
              backgroundColor: state.darkMode
                ? `rgba(15, 23, 42, ${(config.opacity ?? 95) / 100})`
                : `rgba(255, 255, 255, ${(config.opacity ?? 95) / 100})`,
              backdropFilter: config.glassmorphism ? `blur(${config.blur}px)` : undefined,
              borderColor: state.darkMode ? "rgba(51, 65, 85, 0.8)" : "rgba(203, 213, 225, 0.9)",
            }}
          >
            {[
              { id: "home", label: "Notlar" },
              { id: "docs", label: "Belge" },
              { id: "plus", label: "＋" },
              { id: "vault", label: "Kasa" },
              { id: "profile", label: "Profil" },
            ].map((tab) => {
              const isSel = previewActiveTab === tab.id;
              const isPlus = tab.id === "plus";

              if (isPlus) {
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setPreviewActiveTab(tab.id)}
                    className="w-7 h-7 rounded-full bg-teal-600 text-white flex items-center justify-center font-bold text-xs shadow-md active:scale-90 transition-transform cursor-pointer shrink-0"
                  >
                    ＋
                  </button>
                );
              }

              let activeStyles = "";
              if (isSel) {
                if (config.activeIndicatorStyle === "pill") activeStyles = "bg-teal-500/20 text-teal-600 dark:text-teal-300 font-extrabold shadow-2xs";
                else if (config.activeIndicatorStyle === "underline") activeStyles = "text-teal-600 dark:text-teal-300 font-extrabold border-b-2 border-teal-500 rounded-none";
                else if (config.activeIndicatorStyle === "glow") activeStyles = "text-teal-600 dark:text-teal-300 font-extrabold ring-1 ring-teal-400 shadow-md";
                else activeStyles = "text-teal-600 dark:text-teal-300 font-extrabold scale-110";
              } else {
                activeStyles = "text-slate-400 hover:text-slate-600";
              }

              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setPreviewActiveTab(tab.id)}
                  className={`px-1.5 py-1 rounded-xl text-[10px] transition-all cursor-pointer flex flex-col items-center justify-center ${activeStyles}`}
                  style={{
                    transform: isSel && config.activeIndicatorStyle === "scale_icon" ? "scale(1.15)" : undefined,
                  }}
                >
                  <span className="font-mono text-xs">●</span>
                  {config.labelMode !== "hidden" && (config.labelMode === "always" || isSel) && (
                    <span className="text-[8px] truncate leading-none mt-0.5">{tab.label}</span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. KONUM SEÇENEKLERİ (POSITIONING SELECTOR)                                */}
      {/* ========================================================================= */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
            <Layout className="w-4 h-4 text-teal-600 dark:text-teal-400" />
            <span>1. Navigasyon Çubuğu Konumu</span>
          </h4>
          <span className="text-xs font-bold text-teal-600 dark:text-teal-400">
            {NAVBAR_POSITIONS.find((p) => p.id === config.position)?.name.split("(")[0]}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {NAVBAR_POSITIONS.map((pos) => {
            const isSelected = config.position === pos.id;
            return (
              <div
                key={pos.id}
                onClick={() => {
                  updateNavBarConfig({ position: pos.id });
                  notify(`✓ Konum: '${pos.name.split("(")[0]}' olarak ayarlandı.`);
                }}
                className={`p-3.5 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between gap-2 shadow-xs ${
                  isSelected
                    ? "border-teal-500 bg-teal-50/50 dark:bg-teal-950/30 ring-2 ring-teal-500/20 shadow-md"
                    : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-900"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                    {pos.name.split("(")[0]}
                  </span>
                  <span
                    className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                      isSelected ? "bg-teal-600 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-500"
                    }`}
                  >
                    {pos.badge}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed">
                  {pos.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. BOYUT, GEÇİŞ VE GEOMETRİ AYARLARI (SLIDERS)                             */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        {/* Height Slider */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
            <span>Çubuk Kalınlığı / Yüksekliği:</span>
            <span className="font-mono text-indigo-600 dark:text-indigo-400">{config.height}dp ({config.height <= 52 ? "Kompakt" : config.height >= 72 ? "Geniş" : "Standart"})</span>
          </div>
          <input
            type="range"
            min="48"
            max="80"
            step="2"
            value={config.height}
            onChange={(e) => updateNavBarConfig({ height: Number(e.target.value) })}
            className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer accent-indigo-600"
          />
          <div className="flex justify-between text-[10px] text-slate-400">
            <span>48dp (Compact)</span>
            <span>64dp (Normal)</span>
            <span>80dp (Geniş)</span>
          </div>
        </div>

        {/* Width Slider (For Floating mode) */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
            <span>Genişlik & Darlık Oranı:</span>
            <span className="font-mono text-indigo-600 dark:text-indigo-400">%{config.widthPercent} ({config.widthPercent === 100 ? "Tam Genişlik" : "Ortalanmış Kapsül"})</span>
          </div>
          <input
            type="range"
            min="70"
            max="100"
            step="2"
            value={config.widthPercent}
            onChange={(e) => updateNavBarConfig({ widthPercent: Number(e.target.value) })}
            className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer accent-indigo-600"
          />
          <div className="flex justify-between text-[10px] text-slate-400">
            <span>%70 (Dar Kapsül)</span>
            <span>%92 (Dengeli Dok)</span>
            <span>%100 (Tam Ekran)</span>
          </div>
        </div>

        {/* Icon & Label Scaling Multiplier */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
            <span>İkon & Yazı Ölçeği:</span>
            <span className="font-mono text-indigo-600 dark:text-indigo-400">{(config.iconLabelScale || 1.0).toFixed(2)}x</span>
          </div>
          <input
            type="range"
            min="0.80"
            max="1.40"
            step="0.05"
            value={config.iconLabelScale || 1.0}
            onChange={(e) => updateNavBarConfig({ iconLabelScale: Number(e.target.value) })}
            className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer accent-indigo-600"
          />
        </div>

        {/* Border Radius Slider */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
            <span>Köşe Yuvarlatma (Border Radius):</span>
            <span className="font-mono text-indigo-600 dark:text-indigo-400">{config.borderRadius}px ({config.borderRadius === 0 ? "Dikdörtgen" : config.borderRadius >= 30 ? "Tam Kapsül" : "Yuvarlak"})</span>
          </div>
          <input
            type="range"
            min="0"
            max="40"
            step="2"
            value={config.borderRadius}
            onChange={(e) => updateNavBarConfig({ borderRadius: Number(e.target.value) })}
            className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer accent-indigo-600"
          />
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 4. GÖRSEL BİÇİM, CAM EFEKTİ & AKTİF SEKME VURGUSU                           */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        {/* Active Indicator Style */}
        <div className="space-y-2.5">
          <label className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-wider block">
            Aktif Sekme Vurgu Stili
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {ACTIVE_INDICATOR_OPTIONS.map((opt) => {
              const isSel = config.activeIndicatorStyle === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => updateNavBarConfig({ activeIndicatorStyle: opt.id })}
                  className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                    isSel
                      ? "border-teal-500 bg-teal-50/70 dark:bg-teal-950/40 text-teal-950 dark:text-teal-100 font-bold ring-1 ring-teal-500/30"
                      : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold">{opt.name.split("(")[0]}</span>
                    {isSel && <Check className="w-3.5 h-3.5 text-teal-600" />}
                  </div>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-1">
                    {opt.desc}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Label Mode Options */}
        <div className="space-y-2.5">
          <label className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-wider block">
            Sekme Metinleri (Etiket Modu)
          </label>
          <div className="space-y-2">
            {LABEL_MODE_OPTIONS.map((opt) => {
              const isSel = config.labelMode === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => updateNavBarConfig({ labelMode: opt.id })}
                  className={`w-full p-2.5 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                    isSel
                      ? "border-teal-500 bg-teal-50/70 dark:bg-teal-950/40 text-teal-950 dark:text-teal-100 font-bold ring-1 ring-teal-500/30"
                      : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs"
                  }`}
                >
                  <div className="text-left">
                    <span className="text-xs font-bold block">{opt.name}</span>
                    <span className="text-[10px] text-slate-500">{opt.desc}</span>
                  </div>
                  {isSel && <Check className="w-4 h-4 text-teal-600" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Glassmorphism, Blur & Opacity */}
        <div className="md:col-span-2 grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
          <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
            <div>
              <span className="text-xs font-bold text-slate-800 dark:text-white block">
                Cam Efekti (Glassmorphism)
              </span>
              <span className="text-[10px] text-slate-500">Buzlu cam & arkaplan bulanıklığı</span>
            </div>
            <input
              type="checkbox"
              checked={config.glassmorphism}
              onChange={(e) => updateNavBarConfig({ glassmorphism: e.target.checked })}
              className="w-4 h-4 rounded text-teal-600 focus:ring-teal-500 cursor-pointer accent-teal-600"
            />
          </div>

          <div className="space-y-1.5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
            <div className="flex justify-between text-xs font-bold">
              <span>Opaklık (Saydamlık):</span>
              <span className="font-mono text-teal-600">%{config.opacity}</span>
            </div>
            <input
              type="range"
              min="50"
              max="100"
              value={config.opacity}
              onChange={(e) => updateNavBarConfig({ opacity: Number(e.target.value) })}
              className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer accent-teal-600"
            />
          </div>

          <div className="space-y-1.5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
            <div className="flex justify-between text-xs font-bold">
              <span>Bulanıklık (Blur):</span>
              <span className="font-mono text-teal-600">{config.blur}px</span>
            </div>
            <input
              type="range"
              min="0"
              max="30"
              value={config.blur}
              onChange={(e) => updateNavBarConfig({ blur: Number(e.target.value) })}
              className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer accent-teal-600"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
