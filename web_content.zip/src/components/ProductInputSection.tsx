import React, { useState } from 'react';
import { PRODUCT_PRESETS } from '../data/presets';
import { ProductPreset, ImageModel, ImageSize, AspectRatio } from '../types';
import {
  Sparkles,
  Globe,
  FileText,
  Wand2,
  Layers,
  ArrowRight,
  ShieldCheck,
  Zap,
  Sliders,
  Maximize2,
  Image as ImageIcon,
} from 'lucide-react';

interface ProductInputSectionProps {
  onGenerate: (params: {
    productUrl: string;
    productDescription: string;
    brandName: string;
    targetTone: string;
    model: ImageModel;
    imageSize: ImageSize;
    aspectRatio: AspectRatio;
    sampleFallbackImage?: string;
  }) => Promise<void>;
  isLoading: boolean;
  loadingStep: string;
}

export const ProductInputSection: React.FC<ProductInputSectionProps> = ({
  onGenerate,
  isLoading,
  loadingStep,
}) => {
  const [productUrl, setProductUrl] = useState('');
  const [productDescription, setProductDescription] = useState('');
  const [brandName, setBrandName] = useState('');
  const [targetTone, setTargetTone] = useState('High-converting, Premium, Bold');

  // Affordances
  const [selectedModel, setSelectedModel] = useState<ImageModel>('gemini-3-pro-image-preview');
  const [selectedSize, setSelectedSize] = useState<ImageSize>('2K');
  const [selectedAspect, setSelectedAspect] = useState<AspectRatio>('1:1');
  const [selectedPresetId, setSelectedPresetId] = useState<string | null>(null);

  const handleSelectPreset = (preset: ProductPreset) => {
    setSelectedPresetId(preset.id);
    setProductUrl(preset.url);
    setProductDescription(preset.description);
    setBrandName(preset.brand);
    setTargetTone(preset.tone);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!productDescription.trim() && !productUrl.trim()) return;

    const currentPreset = PRODUCT_PRESETS.find((p) => p.id === selectedPresetId);

    onGenerate({
      productUrl: productUrl.trim(),
      productDescription: productDescription.trim(),
      brandName: brandName.trim(),
      targetTone: targetTone.trim(),
      model: selectedModel,
      imageSize: selectedSize,
      aspectRatio: selectedAspect,
      sampleFallbackImage: currentPreset?.sampleImage,
    });
  };

  return (
    <div className="w-full bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl space-y-6">
      <div className="space-y-2 text-center max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20 text-xs font-semibold">
          <Sparkles className="w-3.5 h-3.5" />
          AI Studio Banner Generator
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Turn Any Product Into High-Converting Banner Ads
        </h1>
        <p className="text-sm text-slate-400">
          Enter a product URL and description. Gemini generates studio-quality hero imagery and instantly
          assembles all standard IAB and social banner ad sizes.
        </p>
      </div>

      {/* 1-Click Sample Presets */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            Instant Presets (Click to Auto-Fill)
          </span>
          <span className="text-xs text-slate-500">Or enter your own product below</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {PRODUCT_PRESETS.map((preset) => {
            const isSelected = selectedPresetId === preset.id;
            return (
              <button
                key={preset.id}
                type="button"
                id={`preset-${preset.id}`}
                onClick={() => handleSelectPreset(preset)}
                className={`text-left p-3 rounded-xl border transition-all flex flex-col justify-between ${
                  isSelected
                    ? 'bg-blue-950/40 border-blue-500 shadow-md ring-1 ring-blue-500'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-950'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-1 mb-1">
                    <span className="text-xs font-bold text-slate-200 truncate">{preset.brand}</span>
                    <span
                      style={{ backgroundColor: preset.primaryColor }}
                      className="w-2 h-2 rounded-full flex-shrink-0"
                    />
                  </div>
                  <p className="text-[11px] text-slate-400 font-medium line-clamp-1">{preset.title}</p>
                </div>
                <div className="mt-2 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-500">
                  <span>{preset.theme}</span>
                  <span className="text-blue-400 font-medium">Use →</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Input Form */}
      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Product URL */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-blue-400" />
              Product or Landing Page URL
            </label>
            <input
              id="input-product-url"
              type="url"
              value={productUrl}
              onChange={(e) => setProductUrl(e.target.value)}
              placeholder="https://yourbrand.com/products/example"
              className="w-full bg-slate-950 border border-slate-800 focus:border-blue-500 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono"
            />
          </div>

          {/* Brand Name */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
              Brand / Company Name
            </label>
            <input
              id="input-brand-name"
              type="text"
              value={brandName}
              onChange={(e) => setBrandName(e.target.value)}
              placeholder="e.g. Lumina Skin Lab"
              className="w-full bg-slate-950 border border-slate-800 focus:border-blue-500 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Product Description */}
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5 flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-emerald-400" />
            Product Description & Key Selling Points
          </label>
          <textarea
            id="input-product-description"
            rows={3}
            value={productDescription}
            onChange={(e) => setProductDescription(e.target.value)}
            placeholder="Describe what the product does, key ingredients/materials, unique selling proposition, who it's for, and any active discounts or offers..."
            className="w-full bg-slate-950 border border-slate-800 focus:border-blue-500 rounded-xl p-3 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-blue-500 resize-none"
          />
        </div>

        {/* Studio Image Generation Settings & Affordances */}
        <div className="bg-slate-950/80 border border-slate-800/90 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-blue-400" />
              Gemini Image Generation Configuration
            </span>
            <span className="text-[11px] text-slate-400">Configurable Quality & Ratio</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Model Affordance */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">Model Choice</label>
              <select
                id="select-gen-model"
                value={selectedModel}
                onChange={(e) => setSelectedModel(e.target.value as ImageModel)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
              >
                <option value="gemini-3-pro-image-preview">gemini-3-pro-image-preview (Studio Quality)</option>
                <option value="gemini-3.1-flash-image-preview">gemini-3.1-flash-image-preview (Fast Iteration)</option>
              </select>
            </div>

            {/* Resolution (Size) Affordance: 1K, 2K, 4K */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1 flex items-center gap-1">
                <ImageIcon className="w-3 h-3 text-indigo-400" />
                Image Resolution (Size)
              </label>
              <div className="grid grid-cols-3 gap-1">
                {(['1K', '2K', '4K'] as ImageSize[]).map((size) => (
                  <button
                    key={size}
                    type="button"
                    id={`init-size-${size}`}
                    onClick={() => setSelectedSize(size)}
                    className={`py-1.5 rounded text-xs font-semibold transition-all ${
                      selectedSize === size
                        ? 'bg-indigo-600 text-white shadow-sm'
                        : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Aspect Ratio Affordance */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1 flex items-center gap-1">
                <Maximize2 className="w-3 h-3 text-amber-400" />
                Aspect Ratio
              </label>
              <select
                id="select-init-aspect"
                value={selectedAspect}
                onChange={(e) => setSelectedAspect(e.target.value as AspectRatio)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-200 focus:outline-none focus:border-blue-500 font-mono"
              >
                <option value="1:1">1:1 (Square Standard)</option>
                <option value="16:9">16:9 (Landscape Feed)</option>
                <option value="9:16">9:16 (Vertical Full Story)</option>
                <option value="4:3">4:3 (Desktop Card)</option>
                <option value="3:4">3:4 (Portrait)</option>
                <option value="3:2">3:2 (Classic Frame)</option>
                <option value="2:3">2:3 (Tall Frame)</option>
                <option value="21:9">21:9 (Ultrawide Banner)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Submit & Progress */}
        <div className="pt-2">
          {isLoading ? (
            <div className="bg-slate-950 border border-blue-500/30 rounded-xl p-4 text-center space-y-2">
              <div className="inline-flex items-center gap-2 text-blue-400 font-semibold text-sm animate-pulse">
                <Wand2 className="w-4 h-4 animate-spin" />
                <span>{loadingStep || 'Generating banner suite...'}</span>
              </div>
              <p className="text-xs text-slate-400">
                Using {selectedModel} with {selectedSize} resolution to synthesize high-converting banner ads.
              </p>
            </div>
          ) : (
            <button
              id="btn-generate-banners"
              type="submit"
              disabled={!productDescription.trim() && !productUrl.trim()}
              className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-sm sm:text-base shadow-xl shadow-blue-500/25 flex items-center justify-center gap-2 transition-all active:scale-98 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Sparkles className="w-4 h-4" />
              <span>Generate All Standard Banner Sizes</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </form>
    </div>
  );
};
