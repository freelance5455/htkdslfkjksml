import React, { useMemo } from 'react';
import { ClockTheme, ClockSettings } from '../types/clock';
import { SegmentDigit } from './SegmentDigit';

interface DigitalClockDisplayProps {
  currentTime: Date;
  theme: ClockTheme;
  settings: ClockSettings;
  isBlinkingColonDim: boolean;
}

export const DigitalClockDisplay: React.FC<DigitalClockDisplayProps> = ({
  currentTime,
  theme,
  settings,
  isBlinkingColonDim,
}) => {
  // Format based on timezone
  const timeData = useMemo(() => {
    let dateObj = currentTime;
    let tzName = '';

    if (settings.timezone && settings.timezone !== 'local') {
      try {
        const str = currentTime.toLocaleString('en-US', { timeZone: settings.timezone });
        dateObj = new Date(str);
        tzName = settings.timezone.split('/').pop()?.replace(/_/g, ' ') || settings.timezone;
      } catch {
        dateObj = currentTime;
        tzName = 'Local';
      }
    } else {
      tzName = Intl.DateTimeFormat().resolvedOptions().timeZone.split('/').pop()?.replace(/_/g, ' ') || 'Local';
    }

    let hours = dateObj.getHours();
    const minutes = dateObj.getMinutes();
    const seconds = dateObj.getSeconds();
    const millis = Math.floor(dateObj.getMilliseconds() / 10); // 00-99
    let ampm = '';

    if (settings.hour12) {
      ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12;
      hours = hours ? hours : 12; // 0 becomes 12
    }

    const hoursStr = hours.toString().padStart(2, '0');
    const minutesStr = minutes.toString().padStart(2, '0');
    const secondsStr = seconds.toString().padStart(2, '0');
    const millisStr = millis.toString().padStart(2, '0');

    // Date formatting
    const weekday = dateObj.toLocaleDateString('en-US', { weekday: 'long' });
    const fullDate = dateObj.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    
    // Day of year and week number
    const startOfYear = new Date(dateObj.getFullYear(), 0, 1);
    const dayOfYear = Math.floor((dateObj.getTime() - startOfYear.getTime()) / (1000 * 60 * 60 * 24)) + 1;
    const weekNumber = Math.ceil(dayOfYear / 7);

    // Second progress (0 to 1)
    const secondProgress = (seconds * 1000 + dateObj.getMilliseconds()) / 60000;

    return {
      hoursStr,
      minutesStr,
      secondsStr,
      millisStr,
      ampm,
      weekday,
      fullDate,
      dayOfYear,
      weekNumber,
      secondProgress,
      tzName,
    };
  }, [currentTime, settings.timezone, settings.hour12]);

  // Determine font family CSS class
  const getFontClass = () => {
    switch (theme.fontStyle) {
      case 'orbitron':
        return 'font-digital-orbitron';
      case 'jakarta':
        return 'font-digital-sans';
      case 'bebas':
        return 'font-digital-bebas';
      case 'vt323':
        return 'font-digital-vt323';
      case 'segment':
        return '';
      case 'jetbrains':
      default:
        return 'font-digital-mono';
    }
  };

  const fontClass = getFontClass();
  const textGlow = theme.displayGlow && theme.glowColor !== 'transparent'
    ? `drop-shadow(0 0 20px ${theme.glowColor}) drop-shadow(0 0 45px ${theme.glowColor})`
    : undefined;

  const colonBlink = settings.blinkColons && isBlinkingColonDim;

  return (
    <div className="flex flex-col items-center justify-center w-full px-4 sm:px-8 py-6 select-none transition-all duration-300">
      {/* Date & Timezone Header */}
      {settings.showDate && (
        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-4 mb-4 sm:mb-8 text-xs sm:text-sm md:text-base font-medium tracking-wider uppercase text-center"
          style={{ color: theme.textSecondary }}
        >
          <span className="font-semibold" style={{ color: theme.textPrimary }}>
            {timeData.weekday}
          </span>
          <span aria-hidden="true">·</span>
          <span>{timeData.fullDate}</span>
          {settings.showTimezone && (
            <>
              <span aria-hidden="true">·</span>
              <span className="opacity-80">TZ: {timeData.tzName}</span>
            </>
          )}
          <span aria-hidden="true">·</span>
          <span className="tabular-nums">Wk {timeData.weekNumber}</span>
        </div>
      )}

      {/* Main Massive Clock Display */}
      {theme.fontStyle === 'segment' ? (
        // Authentic 7-Segment SVG Mode
        <div className="flex items-center justify-center gap-1 sm:gap-3 md:gap-4">
          {/* Hours */}
          <div className="flex gap-1 sm:gap-2">
            <SegmentDigit
              char={timeData.hoursStr[0]}
              color={theme.textPrimary}
              unlitColor={theme.segmentUnlit}
              glowColor={theme.displayGlow ? theme.glowColor : undefined}
            />
            <SegmentDigit
              char={timeData.hoursStr[1]}
              color={theme.textPrimary}
              unlitColor={theme.segmentUnlit}
              glowColor={theme.displayGlow ? theme.glowColor : undefined}
            />
          </div>

          {/* Colon */}
          <SegmentDigit
            char=":"
            color={theme.textPrimary}
            unlitColor={theme.segmentUnlit}
            glowColor={theme.displayGlow ? theme.glowColor : undefined}
            blinking={colonBlink}
          />

          {/* Minutes */}
          <div className="flex gap-1 sm:gap-2">
            <SegmentDigit
              char={timeData.minutesStr[0]}
              color={theme.textPrimary}
              unlitColor={theme.segmentUnlit}
              glowColor={theme.displayGlow ? theme.glowColor : undefined}
            />
            <SegmentDigit
              char={timeData.minutesStr[1]}
              color={theme.textPrimary}
              unlitColor={theme.segmentUnlit}
              glowColor={theme.displayGlow ? theme.glowColor : undefined}
            />
          </div>

          {/* Seconds & AM/PM Column */}
          {(settings.showSeconds || settings.hour12) && (
            <div className="flex flex-col justify-between items-start pl-1 sm:pl-3 h-28 sm:h-44 md:h-56 py-2">
              {settings.hour12 && (
                <div
                  className="text-xs sm:text-base md:text-lg font-bold tracking-widest px-2 py-0.5 rounded"
                  style={{
                    color: theme.textAccent,
                    backgroundColor: theme.surfaceBg,
                    border: `1px solid ${theme.border}`,
                  }}
                >
                  {timeData.ampm}
                </div>
              )}

              {settings.showSeconds && (
                <div className="flex items-center gap-1">
                  <SegmentDigit
                    char=":"
                    color={theme.textSecondary}
                    unlitColor={theme.segmentUnlit}
                    className="w-3 h-14 sm:w-5 sm:h-20 md:w-6 md:h-28"
                    blinking={colonBlink}
                  />
                  <SegmentDigit
                    char={timeData.secondsStr[0]}
                    color={theme.textSecondary}
                    unlitColor={theme.segmentUnlit}
                    className="w-8 h-14 sm:w-12 sm:h-20 md:w-16 md:h-28"
                  />
                  <SegmentDigit
                    char={timeData.secondsStr[1]}
                    color={theme.textSecondary}
                    unlitColor={theme.segmentUnlit}
                    className="w-8 h-14 sm:w-12 sm:h-20 md:w-16 md:h-28"
                  />
                </div>
              )}
            </div>
          )}
        </div>
      ) : (
        // Modern Typographic Mode
        <div
          className={`flex items-baseline justify-center tracking-tight leading-none ${fontClass}`}
          style={{
            filter: textGlow,
            color: theme.textPrimary,
          }}
        >
          {/* Main Time: HH:MM */}
          <span className="text-6xl sm:text-8xl md:text-9xl lg:text-[13rem] font-bold tabular-nums">
            {timeData.hoursStr}
          </span>

          <span
            className={`text-6xl sm:text-8xl md:text-9xl lg:text-[13rem] font-medium px-1 sm:px-3 transition-opacity duration-200 ${
              colonBlink ? 'opacity-20' : 'opacity-100'
            }`}
          >
            :
          </span>

          <span className="text-6xl sm:text-8xl md:text-9xl lg:text-[13rem] font-bold tabular-nums">
            {timeData.minutesStr}
          </span>

          {/* Seconds & Millis & AM/PM Block */}
          {(settings.showSeconds || settings.hour12 || settings.showMilliseconds) && (
            <div className="flex flex-col justify-end ml-2 sm:ml-4 self-center sm:self-auto mb-2 sm:mb-6">
              {settings.hour12 && (
                <span
                  className="text-sm sm:text-xl md:text-2xl font-bold tracking-widest uppercase mb-1 sm:mb-2"
                  style={{ color: theme.textAccent }}
                >
                  {timeData.ampm}
                </span>
              )}

              {settings.showSeconds && (
                <div className="flex items-baseline">
                  <span
                    className={`text-2xl sm:text-4xl md:text-6xl lg:text-7xl font-semibold tabular-nums`}
                    style={{ color: theme.textSecondary }}
                  >
                    :{timeData.secondsStr}
                  </span>
                  {settings.showMilliseconds && (
                    <span
                      className="text-xs sm:text-base md:text-xl font-mono tabular-nums ml-1 opacity-75"
                      style={{ color: theme.textAccent }}
                    >
                      .{timeData.millisStr}
                    </span>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Second Progress Visualizer (Subtle 60-second linear gauge) */}
      {settings.showSeconds && (
        <div className="w-full max-w-xl sm:max-w-2xl mt-6 sm:mt-10 px-4">
          <div
            className="w-full h-1 sm:h-1.5 rounded-full overflow-hidden transition-all"
            style={{ backgroundColor: theme.surfaceBg }}
          >
            <div
              className="h-full rounded-full transition-all duration-100 ease-linear"
              style={{
                width: `${timeData.secondProgress * 100}%`,
                backgroundColor: theme.textAccent,
                boxShadow: theme.displayGlow ? `0 0 8px ${theme.textAccent}` : undefined,
              }}
            />
          </div>
          <div className="flex justify-between items-center text-[10px] sm:text-xs font-mono mt-1 text-slate-500">
            <span>00s</span>
            <span className="tabular-nums">{timeData.secondsStr}s / 60s</span>
            <span>60s</span>
          </div>
        </div>
      )}
    </div>
  );
};
