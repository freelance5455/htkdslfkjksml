import React, { useState } from 'react';
import { 
  GraduationCap, 
  Sparkles, 
  BookOpen, 
  ToggleLeft, 
  ToggleRight, 
  Clock, 
  Lightbulb, 
  FileText, 
  Network, 
  AlertCircle, 
  RefreshCw, 
  Layers, 
  Smile, 
  Zap, 
  Bookmark,
  TrendingUp,
  Volume2
} from 'lucide-react';
import { Subject, TeacherLevel, SummaryDuration, MindMap } from '../types';
import { SUBJECT_METADATA } from '../presets';

interface ClassroomProps {
  language: string;
  onIncrementQuestion: () => void;
  onReadAloud: (text: string) => void;
  activeVoiceTeacher: boolean;
}

export default function Classroom({ 
  language, 
  onIncrementQuestion, 
  onReadAloud, 
  activeVoiceTeacher 
}: ClassroomProps) {
  const [topic, setTopic] = useState<string>('');
  const [subject, setSubject] = useState<Subject>('Science');
  const [level, setLevel] = useState<TeacherLevel>('madhyamik');
  const [isStoryMode, setIsStoryMode] = useState<boolean>(true);
  
  // Loading & states
  const [loading, setLoading] = useState<boolean>(false);
  const [tutorResult, setTutorResult] = useState<any | null>(null);
  const [error, setError] = useState<string>('');

  // Summarize Sub-mode
  const [summaryLoading, setSummaryLoading] = useState<boolean>(false);
  const [summaryResult, setSummaryResult] = useState<any | null>(null);
  const [activeDuration, setActiveDuration] = useState<SummaryDuration>('5m');

  // Highlights Sub-mode
  const [hlLoading, setHlLoading] = useState<boolean>(false);
  const [hlResult, setHlResult] = useState<any | null>(null);

  // Mindmap Sub-mode
  const [mmLoading, setMmLoading] = useState<boolean>(false);
  const [mmResult, setMmResult] = useState<MindMap | null>(null);
  const [selectedNode, setSelectedNode] = useState<any | null>(null);

  const translations: Record<string, Record<string, string>> = {
    en: {
      classroom: 'Smart AI Classroom',
      classroomSub: 'Learn any topic in any subject effortlessly through stories or structured academic explanations.',
      topicLabel: 'What topic or chapter do you want to learn?',
      topicPlaceholder: 'E.g., How does photosynthesis work? or Reasons for Battle of Plassey.',
      subjectLabel: 'Choose Subject:',
      levelLabel: 'Explain Like Teacher (Level):',
      storyMode: 'Story Mode Activated',
      storyModeSub: 'Convert lessons into engaging stories!',
      startTeach: 'Start AI Lesson',
      analogies: 'Real-Life Analogies:',
      takeaways: 'Key takeaways / Summary points:',
      readAloud: 'Read Aloud (Voice Tutor)',
      durationTab: 'Chapter Summary',
      highlightTab: 'Highlight Detector',
      mindmapTab: 'AI Concept Map',
      duration1: '1 Minute Revise',
      duration5: '5 Minute Summary',
      duration10: '10 Minute Detail',
      levelKids: '8yo Kid Level',
      levelMadhyamik: 'Secondary (10th)',
      levelHS: 'Higher Sec (12th)',
      levelCollege: 'College Level',
      summaryPoints: 'Critical Revision Points:',
      criticalTerms: 'Crucial Definitions:',
      revisionTips: 'Exam Quick Tips:',
      hlDates: 'Crucial Years & Dates',
      hlNames: 'Key Personalities',
      hlDefinitions: 'Formulas & Definitions',
      hlEvents: 'Major Milestones',
      mmExplain: 'Click on mind map nodes to explore conceptual connections:',
      nodeDesc: 'Node Description:'
    },
    bn: {
      classroom: 'স্মার্ট ক্লাসরুম (AI Smart Classroom)',
      classroomSub: 'পছন্দের বিষয় ও গল্পের আকারে যেকোনো অধ্যায় একদম সহজ ভাষায় বুঝে নাও।',
      topicLabel: 'যে অধ্যায় বা বিষয় শিখতে চাও:',
      topicPlaceholder: 'যেমন: সূর্যগ্রহণ কীভাবে ঘটে? বা পলাশীর যুদ্ধ কীভাবে হয়েছিল?',
      subjectLabel: 'বিষয় নির্বাচন করো:',
      levelLabel: 'শিক্ষক বোঝানোর ধরণ (Teacher Level):',
      storyMode: 'গল্প মোড সক্রিয় (Story Mode)',
      storyModeSub: 'Turn chapter into an exciting story!',
      startTeach: 'ক্লাস শুরু করুন (Start AI Lesson)',
      analogies: 'বাস্তব জীবনের উদাহরণ ও তুলনা:',
      takeaways: 'মূল শিক্ষণীয় তথ্য:',
      readAloud: 'পড়ে শুনুন (AI Voice Read)',
      durationTab: 'রিভিশন সামারি',
      highlightTab: 'হাইলাইট ডিটেক্টর',
      mindmapTab: 'AI মাইন্ড ম্যাপ',
      duration1: '১ মিনিট',
      duration5: '৫ মিনিট',
      duration10: '১০ মিনিট',
      levelKids: '৮ বছর বাচ্চার স্তর',
      levelMadhyamik: 'মাধ্যমিক (১০ম)',
      levelHS: 'উচ্চমাধ্যমিক (১২থ)',
      levelCollege: 'কলেজ / অনার্স',
      summaryPoints: 'গুরুত্বपूर्ण রিভিশন পয়েন্ট:',
      criticalTerms: 'সংজ্ঞা ও মূল টার্মস:',
      revisionTips: 'শেষ মুহূর্তের পরীক্ষার টিপস:',
      hlDates: 'গুরুত্বপূর্ণ সাল ও তারিখ',
      hlNames: 'প্রধান ব্যক্তিত্ব ও নাম',
      hlDefinitions: 'সংজ্ঞা ও গাণিতিক সূত্র',
      hlEvents: 'প্রধান প্রধান ঘটনা সমূহ',
      mmExplain: 'মাইন্ড ম্যাপের নোডগুলোতে ক্লিক করে বিস্তারিত সম্পর্ক বুঝে নিন:',
      nodeDesc: 'নোডের বিবরণ:'
    },
    hi: {
      classroom: 'स्मार्ट एआई क्लासरूम',
      classroomSub: 'कहानियों या संरचित स्पष्टीकरणों के माध्यम से किसी भी विषय को आसानी से सीखें।',
      topicLabel: 'आप कौन सा विषय या अध्याय सीखना चाहते हैं?',
      topicPlaceholder: 'जैसे: प्रकाश संश्लेषण कैसे काम करता है? या प्लासी के युद्ध के कारण।',
      subjectLabel: 'विषय चुनें:',
      levelLabel: 'टीचर समझाने का स्तर (Level):',
      storyMode: 'कहानी मोड सक्रिय (Story Mode)',
      storyModeSub: 'पाठों को मनोरंजक कहानियों में बदलें!',
      startTeach: 'एआई पाठ शुरू करें',
      analogies: 'वास्तविक जीवन के उदाहरण:',
      takeaways: 'मुख्य निष्कर्ष:',
      readAloud: 'बोलकर सुनें (Voice Read)',
      durationTab: 'अध्याय सारांश',
      highlightTab: 'हाइलाइट डिटेक्टर',
      mindmapTab: 'एआई माइंड मैप',
      duration1: '1 मिनट संशोधन',
      duration5: '5 मिनट सारांश',
      duration10: '10 मिनट विस्तृत',
      levelKids: '8 वर्ष के बच्चे का स्तर',
      levelMadhyamik: 'माध्यमिक (10वीं)',
      levelHS: 'उच्च माध्यमिक (12वीं)',
      levelCollege: 'कॉलेज स्तर',
      summaryPoints: 'महत्वपूर्ण संशोधन बिंदु:',
      criticalTerms: 'महत्वपूर्ण परिभाषाएँ:',
      revisionTips: 'परीक्षा त्वरित टिप्स:',
      hlDates: 'महत्वपूर्ण वर्ष और तारीखें',
      hlNames: 'प्रमुख व्यक्तित्व',
      hlDefinitions: 'सूत्र और परिभाषाएँ',
      hlEvents: 'प्रमुख घटनाएं',
      mmExplain: 'वैचारिक संबंधों का पता लगाने के लिए नोड्स पर क्लिक करें:',
      nodeDesc: 'नोड विवरण:'
    },
    es: {
      classroom: 'Aula de Clases Inteligente IA',
      classroomSub: 'Aprende cualquier tema en cualquier materia sin esfuerzo a través de historias o explicaciones académicas.',
      topicLabel: '¿Qué tema o capítulo deseas aprender?',
      topicPlaceholder: 'Ej. ¿Cómo funciona la fotosíntesis? o Razones de la Batalla de Plassey.',
      subjectLabel: 'Elige la Materia:',
      levelLabel: 'Nivel del Tutor AI:',
      storyMode: 'Modo Historia Activado',
      storyModeSub: '¡Convierte las lecciones en historias emocionantes!',
      startTeach: 'Comenzar Lección IA',
      analogies: 'Analogías de la Vida Real:',
      takeaways: 'Puntos Clave / Resumen:',
      readAloud: 'Escuchar Lección (Voz AI)',
      durationTab: 'Resumen del Capítulo',
      highlightTab: 'Detector de Aspectos Clave',
      mindmapTab: 'Mapa de Conceptos IA',
      duration1: 'Repaso de 1 Minuto',
      duration5: 'Resumen de 5 Minutos',
      duration10: 'Detalle de 10 Minutos',
      levelKids: 'Nivel Niño (8 años)',
      levelMadhyamik: 'Secundaria (10°)',
      levelHS: 'Preparatoria (12°)',
      levelCollege: 'Nivel Universitario',
      summaryPoints: 'Puntos de Repaso Críticos:',
      criticalTerms: 'Definiciones Cruciales:',
      revisionTips: 'Consejos Rápidos para Exámenes:',
      hlDates: 'Fechas y Años Cruciales',
      hlNames: 'Personalidades Clave',
      hlDefinitions: 'Fórmulas y Definiciones',
      hlEvents: 'Hitos Importantes',
      mmExplain: 'Haz clic en los nodos para explorar conexiones conceptuales:',
      nodeDesc: 'Descripción del Nodo:'
    },
    fr: {
      classroom: 'Classe Virtuelle IA',
      classroomSub: 'Apprenez n\'importe quel sujet sans effort grâce à des histoires captivantes ou des explications académiques structurées.',
      topicLabel: 'Quel sujet ou chapitre veux-tu apprendre ?',
      topicPlaceholder: 'Ex. Comment fonctionne la photosynthèse ? ou Les causes de la Révolution française.',
      subjectLabel: 'Choisissez la matière :',
      levelLabel: 'Niveau d\'explication du tuteur IA :',
      storyMode: 'Mode Histoire Activé',
      storyModeSub: 'Transformez vos leçons en histoires passionnantes !',
      startTeach: 'Démarrer le Cours IA',
      analogies: 'Analogies de la vie réelle :',
      takeaways: 'Points clés à retenir :',
      readAloud: 'Lire à voix haute (Tuteur Vocal)',
      durationTab: 'Résumé du Chapitre',
      highlightTab: 'Détecteur de Points Clés',
      mindmapTab: 'Carte Mentale IA',
      duration1: 'Révision 1 Minute',
      duration5: 'Résumé 5 Minutes',
      duration10: 'Détail 10 Minutes',
      levelKids: 'Niveau Enfant (8 ans)',
      levelMadhyamik: 'Collège (10e)',
      levelHS: 'Lycée (12e)',
      levelCollege: 'Niveau Supérieur',
      summaryPoints: 'Points de Révision Importants :',
      criticalTerms: 'Définitions Essentielles :',
      revisionTips: 'Conseis Express Examen :',
      hlDates: 'Dates & Années Clés',
      hlNames: 'Personnalités Claves',
      hlDefinitions: 'Formules et Définitions',
      hlEvents: 'Événements Majeurs',
      mmExplain: 'Cliquez sur les nœuds pour explorer les connexions conceptuelles :',
      nodeDesc: 'Description du nœud :'
    },
    ar: {
      classroom: 'الفصل الدراسي الذكي بالذكاء الاصطناعي',
      classroomSub: 'تعلم أي درس في أي مادة بكل سهولة من خلال القصص التفاعلية أو الشروحات الأكاديمية المبسطة.',
      topicLabel: 'ما الدرس أو الفصل الذي تود تعلمه اليوم؟',
      topicPlaceholder: 'مثال: كيف تحدث عملية البناء الضوئي؟ أو أسباب معركة بلاسي.',
      subjectLabel: 'اختر المادة الدراسية:',
      levelLabel: 'مستوى شرح المعلم الاصطناعي:',
      storyMode: 'وضع القصص نشط',
      storyModeSub: 'تحويل الدروس الأكاديمية إلى قصص شيقة وممتعة!',
      startTeach: 'بدء درس الذكاء الاصطناعي',
      analogies: 'تشبيهات وأمثلة من واقع الحياة:',
      takeaways: 'أهم النقاط المستفادة والملخص:',
      readAloud: 'قراءة الدرس بصوت المعلم',
      durationTab: 'ملخص الفصل السريع',
      highlightTab: 'مستكشف النقاط الهامة',
      mindmapTab: 'خريطة المفاهيم الذهنية',
      duration1: 'مراجعة دقيقة واحدة',
      duration5: 'ملخص 5 دقائق',
      duration10: 'تفصيل 10 دقائق',
      levelKids: 'مستوى طفل 8 سنوات',
      levelMadhyamik: 'المرحلة الإعدادية',
      levelHS: 'المرحلة الثانوية',
      levelCollege: 'المستوى الجامعي',
      summaryPoints: 'نقاط المراجعة الهامة والحرجة:',
      criticalTerms: 'التعريفات والمصطلحات الأساسية:',
      revisionTips: 'نصائح الاختبار السريعة:',
      hlDates: 'التواريخ والسنوات الحاسمة',
      hlNames: 'الشخصيات والأسماء الرئيسية',
      hlDefinitions: 'المصطلحات والقوانين الهامة',
      hlEvents: 'الأحداث والمعالم الرئيسية',
      mmExplain: 'اضغط على نقاط خريطة المفاهيم لاستكشاف الروابط المعرفية:',
      nodeDesc: 'وصف النقطة المحددة:'
    }
  };

  const t = translations[language] || translations['en'];

  const handleStartLesson = async () => {
    if (!topic.trim()) {
      setError('Please type a topic or chapter to start.');
      return;
    }

    setLoading(true);
    setError('');
    setTutorResult(null);
    setSummaryResult(null);
    setHlResult(null);
    setMmResult(null);
    setSelectedNode(null);

    try {
      const response = await fetch('/api/gemini/tutor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic,
          subject,
          level,
          isStoryMode,
          language
        })
      });

      if (!response.ok) {
        throw new Error('Failed to fetch explanation from tutor.');
      }

      const data = await response.json();
      setTutorResult(data);
      onIncrementQuestion(); // Update state tracker in App
    } catch (err: any) {
      setError(err.message || 'An error occurred.');
    } finally {
      setLoading(false);
    }
  };

  // Chapter Summarizer helper
  const handleFetchSummary = async (duration: SummaryDuration) => {
    if (!tutorResult) return;
    setSummaryLoading(true);
    setActiveDuration(duration);
    try {
      const contentText = `${tutorResult.title}. ${tutorResult.explanation}`;
      const response = await fetch('/api/gemini/summarize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: contentText,
          duration,
          language
        })
      });
      const data = await response.json();
      setSummaryResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setSummaryLoading(false);
    }
  };

  // Highlight Detector helper
  const handleFetchHighlights = async () => {
    if (!tutorResult) return;
    setHlLoading(true);
    try {
      const contentText = `${tutorResult.title}. ${tutorResult.explanation}`;
      const response = await fetch('/api/gemini/highlights', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: contentText,
          language
        })
      });
      const data = await response.json();
      setHlResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setHlLoading(false);
    }
  };

  // AI Mind Map helper
  const handleFetchMindmap = async () => {
    if (!tutorResult) return;
    setMmLoading(true);
    setSelectedNode(null);
    try {
      const response = await fetch('/api/gemini/mindmap', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: tutorResult.title,
          subject,
          language
        })
      });
      const data = await response.json();
      setMmResult(data);
      if (data.nodes && data.nodes.length > 0) {
        setSelectedNode(data.nodes[0]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setMmLoading(false);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto bg-slate-50 p-6 md:p-10 space-y-8">
      {/* Banner */}
      <div>
        <h1 className="text-2xl md:text-3xl font-extrabold text-slate-800 font-display tracking-tight flex items-center gap-2">
          <GraduationCap className="w-7 h-7 text-indigo-500" /> {t.classroom}
        </h1>
        <p className="text-sm text-slate-500 mt-1">{t.classroomSub}</p>
      </div>

      {/* Classroom Control Form */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-sm space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Topic Entry */}
          <div className="space-y-2 md:col-span-2">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">{t.topicLabel}</label>
            <div className="relative">
              <input
                type="text"
                placeholder={t.topicPlaceholder}
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                className="w-full border border-slate-200 rounded-xl py-3 pl-4 pr-12 text-sm font-semibold text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
              />
              <Sparkles className="absolute right-4 top-3.5 w-5 h-5 text-indigo-400" />
            </div>
          </div>

          {/* Subject Dropdown */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">{t.subjectLabel}</label>
            <select
              value={subject}
              onChange={(e) => setSubject(e.target.value as Subject)}
              className="w-full border border-slate-200 rounded-xl py-3 px-4 text-sm font-semibold text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
            >
              {SUBJECT_METADATA.map((meta) => (
                <option key={meta.subject} value={meta.subject}>{meta.subject}</option>
              ))}
            </select>
          </div>

          {/* Explanation difficulty Level */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">{t.levelLabel}</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setLevel('kids')}
                className={`py-2 text-xs font-bold rounded-lg border transition-all ${
                  level === 'kids'
                    ? 'bg-amber-600 border-amber-600 text-white shadow-sm'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                👶 {t.levelKids}
              </button>
              <button
                type="button"
                onClick={() => setLevel('madhyamik')}
                className={`py-2 text-xs font-bold rounded-lg border transition-all ${
                  level === 'madhyamik'
                    ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                🏫 {t.levelMadhyamik}
              </button>
              <button
                type="button"
                onClick={() => setLevel('hs')}
                className={`py-2 text-xs font-bold rounded-lg border transition-all ${
                  level === 'hs'
                    ? 'bg-violet-600 border-violet-600 text-white shadow-sm'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                🎓 {t.levelHS}
              </button>
              <button
                type="button"
                onClick={() => setLevel('college')}
                className={`py-2 text-xs font-bold rounded-lg border transition-all ${
                  level === 'college'
                    ? 'bg-slate-800 border-slate-800 text-white shadow-sm'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                🏛️ {t.levelCollege}
              </button>
            </div>
          </div>
        </div>

        {/* Story Mode toggle bar */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 p-4 bg-indigo-50/60 border border-indigo-100/80 rounded-2xl">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-100 text-indigo-600 rounded-xl">
              <Smile className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-800">{t.storyMode}</h4>
              <p className="text-xs text-slate-500 mt-0.5">{t.storyModeSub}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setIsStoryMode(!isStoryMode)}
            className="text-indigo-600 hover:scale-105 transition-transform shrink-0"
          >
            {isStoryMode ? (
              <ToggleRight className="w-12 h-12 stroke-[1.5]" />
            ) : (
              <ToggleLeft className="w-12 h-12 stroke-[1.5] text-slate-400" />
            )}
          </button>
        </div>

        {/* Trigger Lessons */}
        <button
          onClick={handleStartLesson}
          disabled={loading}
          className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white font-bold rounded-xl shadow-md shadow-indigo-600/10 flex items-center justify-center gap-2 transition-all text-sm uppercase tracking-wider"
        >
          {loading ? (
            <>
              <RefreshCw className="w-5 h-5 animate-spin" />
              AI শিক্ষক বোর্ডে লিখছেন ও প্রস্তুত হচ্ছেন...
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5" />
              {t.startTeach}
            </>
          )}
        </button>
      </div>

      {/* ERROR HANDLER */}
      {error && (
        <div className="bg-rose-50 border border-rose-100 text-rose-800 p-5 rounded-2xl flex items-start gap-3">
          <AlertCircle className="w-5 h-5 shrink-0 text-rose-500 mt-0.5" />
          <div>
            <h4 className="font-bold text-sm">ক্লাস শুরু করতে ত্রুটি হয়েছে</h4>
            <p className="text-xs text-rose-600 mt-1">{error}</p>
          </div>
        </div>
      )}

      {/* TUTOR RESPONSE SCREEN */}
      {tutorResult && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-fade-in">
          
          {/* Main classroom lecture board */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-slate-900 rounded-3xl border border-slate-800 p-6 md:p-8 text-slate-100 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500" />
              <div className="absolute top-4 right-4 flex items-center gap-2 z-10">
                <button
                  onClick={() => onReadAloud(tutorResult.explanation)}
                  className={`p-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                    activeVoiceTeacher
                      ? 'bg-rose-600 text-white animate-pulse'
                      : 'bg-slate-800 hover:bg-slate-700 text-indigo-400'
                  }`}
                  title="ভয়েসে শুনুন"
                >
                  <Volume2 className="w-4 h-4 text-rose-500" />
                  {activeVoiceTeacher ? 'পড়া হচ্ছে...' : t.readAloud}
                </button>
              </div>

              <div className="space-y-4">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800 text-slate-400 text-[10px] font-mono tracking-widest uppercase">
                  <Bookmark className="w-3.5 h-3.5 text-indigo-400" /> {subject} Lesson
                </div>
                
                <h2 className="text-2xl md:text-3xl font-extrabold font-display text-white border-b border-slate-800 pb-3 leading-tight">
                  {tutorResult.title}
                </h2>

                <p className="text-base font-medium italic text-indigo-200 bg-indigo-950/40 p-4 rounded-xl border border-indigo-900/30">
                  {tutorResult.introduction}
                </p>

                {/* Main Explanation paragraph body */}
                <div className="text-slate-300 leading-relaxed text-sm whitespace-pre-wrap font-sans pt-2 space-y-4">
                  {tutorResult.explanation}
                </div>
              </div>
            </div>

            {/* Analogies & Key takeaways */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
                <h4 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                  <Smile className="w-5 h-5 text-indigo-500" /> {t.analogies}
                </h4>
                <ul className="space-y-2.5">
                  {tutorResult.realLifeAnalogies?.map((analogy: string, idx: number) => (
                    <li key={idx} className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-xs font-medium text-slate-700 flex gap-2">
                      <span className="text-indigo-500 font-bold">💡</span>
                      <span>{analogy}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
                <h4 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                  <Zap className="w-5 h-5 text-amber-500" /> {t.takeaways}
                </h4>
                <ul className="space-y-2.5">
                  {tutorResult.keyTakeaways?.map((takeaway: string, idx: number) => (
                    <li key={idx} className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-xs font-medium text-slate-700 flex gap-2">
                      <span className="text-emerald-500 font-bold">✓</span>
                      <span>{takeaway}</span>
                    </li>
                  ))}
                </ul>
              </div>

            </div>
          </div>

          {/* Sidebar Tools: Summaries, Highlights, Mind Maps */}
          <div className="space-y-6">
            
            {/* Quick Summary revision panel */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
              <h4 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                <Clock className="w-4 h-4 text-indigo-500" /> {t.durationTab}
              </h4>
              
              <div className="grid grid-cols-3 gap-1 bg-slate-100 p-1 rounded-xl">
                <button
                  onClick={() => handleFetchSummary('1m')}
                  className={`py-1.5 text-xs font-bold rounded-lg transition-all ${
                    activeDuration === '1m' && summaryResult
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  {t.duration1}
                </button>
                <button
                  onClick={() => handleFetchSummary('5m')}
                  className={`py-1.5 text-xs font-bold rounded-lg transition-all ${
                    activeDuration === '5m' && summaryResult
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  {t.duration5}
                </button>
                <button
                  onClick={() => handleFetchSummary('10m')}
                  className={`py-1.5 text-xs font-bold rounded-lg transition-all ${
                    activeDuration === '10m' && summaryResult
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  {t.duration10}
                </button>
              </div>

              {!summaryResult && !summaryLoading && (
                <button
                  onClick={() => handleFetchSummary('5m')}
                  className="w-full text-center py-2 border border-dashed border-slate-200 rounded-xl text-xs font-semibold text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 transition-all"
                >
                  সারসংক্ষেপ কাস্টমাইজ করুন
                </button>
              )}

              {summaryLoading && (
                <div className="py-4 text-center space-y-2">
                  <RefreshCw className="w-5 h-5 text-indigo-500 animate-spin mx-auto" />
                  <span className="text-xs text-slate-500 block">AI সামারি রিভিশন তৈরি করছে...</span>
                </div>
              )}

              {summaryResult && !summaryLoading && (
                <div className="space-y-4 animate-fade-in text-xs">
                  <div className="space-y-1.5">
                    <span className="font-extrabold text-indigo-700 block uppercase tracking-wider">{t.summaryPoints}</span>
                    <ul className="space-y-1 list-disc pl-4 text-slate-600">
                      {summaryResult.summaryPoints?.map((p: string, i: number) => (
                        <li key={i}>{p}</li>
                      ))}
                    </ul>
                  </div>

                  {summaryResult.criticalTerms && summaryResult.criticalTerms.length > 0 && (
                    <div className="space-y-2">
                      <span className="font-extrabold text-amber-700 block uppercase tracking-wider">{t.criticalTerms}</span>
                      <div className="space-y-1.5">
                        {summaryResult.criticalTerms.map((term: any, i: number) => (
                          <div key={i} className="bg-amber-50/50 p-2 rounded-lg border border-amber-100">
                            <span className="font-bold text-amber-900">{term.term}:</span>{' '}
                            <span className="text-slate-600">{term.meaning}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {summaryResult.revisionTips && (
                    <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-100">
                      <span className="font-bold text-emerald-800 block mb-1">{t.revisionTips}</span>
                      <ul className="space-y-0.5 list-disc pl-4 text-emerald-950 font-medium">
                        {summaryResult.revisionTips.map((tip: string, i: number) => (
                          <li key={i}>{tip}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Highlights panel */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
              <h4 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                <FileText className="w-4 h-4 text-indigo-500" /> {t.highlightTab}
              </h4>

              {!hlResult && !hlLoading && (
                <button
                  onClick={handleFetchHighlights}
                  className="w-full text-center py-2.5 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition-all"
                >
                  সাল, সূত্র ও ঐতিহাসিক তারিখগুলো বের করুন
                </button>
              )}

              {hlLoading && (
                <div className="py-4 text-center space-y-2">
                  <RefreshCw className="w-5 h-5 text-indigo-500 animate-spin mx-auto" />
                  <span className="text-xs text-slate-500 block">হাইলাইটসমূহ ডিটেক্ট করা হচ্ছে...</span>
                </div>
              )}

              {hlResult && !hlLoading && (
                <div className="space-y-3 animate-fade-in text-[11px] font-medium text-slate-600">
                  {hlResult.dates && hlResult.dates.length > 0 && (
                    <div>
                      <span className="font-bold text-indigo-600 block mb-1">{t.hlDates}</span>
                      <div className="space-y-1">
                        {hlResult.dates.map((d: any, i: number) => (
                          <div key={i} className="flex justify-between p-1.5 bg-slate-50 border border-slate-100 rounded-lg">
                            <span className="font-extrabold text-indigo-800 font-display">{d.date}</span>
                            <span>{d.event}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {hlResult.names && hlResult.names.length > 0 && (
                    <div className="pt-2">
                      <span className="font-bold text-rose-600 block mb-1">{t.hlNames}</span>
                      <div className="space-y-1">
                        {hlResult.names.map((n: any, i: number) => (
                          <div key={i} className="p-1.5 bg-slate-50 border border-slate-100 rounded-lg">
                            <span className="font-bold text-rose-800">{n.name}</span> - {n.role}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {hlResult.definitions && hlResult.definitions.length > 0 && (
                    <div className="pt-2">
                      <span className="font-bold text-emerald-600 block mb-1">{t.hlDefinitions}</span>
                      <div className="space-y-1">
                        {hlResult.definitions.map((def: any, i: number) => (
                          <div key={i} className="p-2 bg-emerald-50/50 border border-emerald-100 rounded-lg">
                            <span className="font-bold text-emerald-950">{def.term}</span>: {def.explanation}
                            {def.formula && <span className="block font-mono text-[9px] font-bold text-emerald-800 mt-1">Symptom formula: {def.formula}</span>}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Mind Map panel */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
              <h4 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                <Network className="w-4 h-4 text-indigo-500" /> {t.mindmapTab}
              </h4>

              {!mmResult && !mmLoading && (
                <button
                  onClick={handleFetchMindmap}
                  className="w-full text-center py-2.5 bg-indigo-50 text-indigo-600 border border-indigo-200 rounded-xl text-xs font-bold hover:bg-indigo-100 transition-all"
                >
                  AI সংযোগ ডায়াগ্রাম (Mind Map) দেখুন
                </button>
              )}

              {mmLoading && (
                <div className="py-4 text-center space-y-2">
                  <RefreshCw className="w-5 h-5 text-indigo-500 animate-spin mx-auto" />
                  <span className="text-xs text-slate-500 block">মাইন্ড ম্যাপ সংযোগসমূহ সাজানো হচ্ছে...</span>
                </div>
              )}

              {mmResult && !mmLoading && (
                <div className="space-y-4 animate-fade-in text-xs">
                  <p className="text-[10px] text-slate-500 font-medium italic">{t.mmExplain}</p>
                  
                  {/* Bubble Map list */}
                  <div className="flex flex-wrap gap-2 pt-1 max-h-48 overflow-y-auto p-1 bg-slate-50 border border-slate-100 rounded-xl">
                    {mmResult.nodes?.map((node: any) => (
                      <button
                        key={node.id}
                        onClick={() => setSelectedNode(node)}
                        className={`px-3 py-1.5 rounded-full border text-[11px] font-semibold transition-all ${
                          selectedNode?.id === node.id
                            ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                            : node.type === 'root'
                            ? 'bg-amber-100 text-amber-900 border-amber-300'
                            : node.type === 'main'
                            ? 'bg-indigo-50 text-indigo-900 border-indigo-100'
                            : 'bg-white text-slate-700 border-slate-200 hover:border-indigo-400'
                        }`}
                      >
                        {node.label}
                      </button>
                    ))}
                  </div>

                  {selectedNode && (
                    <div className="p-3.5 bg-indigo-50 border border-indigo-100 rounded-xl space-y-1 animate-fade-in">
                      <span className="text-[10px] text-indigo-700 uppercase font-extrabold tracking-wider">{t.nodeDesc}</span>
                      <h5 className="font-bold text-slate-800 text-xs">{selectedNode.label}</h5>
                      <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                        {selectedNode.description}
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>

          </div>

        </div>
      )}

    </div>
  );
}
