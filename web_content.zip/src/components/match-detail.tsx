import { cn } from "@/lib/cn";
import type { LiveItem, OuLine } from "@/lib/engine/types";
import { Badge } from "@/components/ui/badge";
import { TeamCrest } from "@/components/team-crest";

function tier(v: number | null | undefined) {
  if (v == null) return "cool";
  if (v >= 70) return "hot";
  if (v >= 50) return "warm";
  return "cool";
}

function Tile({
  label,
  value,
  done,
  missed,
  unknown,
}: {
  label: string;
  value?: number | null;
  done?: boolean;
  missed?: boolean;
  unknown?: boolean;
}) {
  const t = done ? "hot" : missed || unknown ? "cool" : tier(value);
  const text = unknown || value == null ? "—" : done ? "Já" : missed ? "Não" : `${Math.round(value)}%`;
  return (
    <div
      className={cn(
        "rounded-lg bg-bg px-3 py-2.5 text-center shadow-[var(--shadow-border)]",
        t === "hot" && "bg-hot/12 shadow-[0_0_0_1px_rgb(61_154_122/0.22)]",
      )}
    >
      <div className="text-[10px] font-medium text-muted">{label}</div>
      <div
        className={cn(
          "mt-1 font-mono text-lg font-bold tabular-nums",
          t === "hot" && "text-hot",
          t === "warm" && "text-warm",
          t === "cool" && "text-muted",
        )}
      >
        {text}
      </div>
    </div>
  );
}

function findLine(lines: OuLine[] | undefined, n: number) {
  return lines?.find((x) => x.line === n);
}

function PressureMeter({ item }: { item: LiveItem }) {
  const p = item.pred.pressure;
  const total = p.home + p.away || 1;
  const homeW = (p.home / total) * 100;
  const pts = item.pred.momentumPoints;
  const W = 280;
  const H = 34;
  const MID = H / 2;
  let spark: string | null = null;
  if (pts && pts.length >= 2) {
    const vals = pts.map((pt) => Math.max(-1, Math.min(1, (pt.value || 0) / 100)));
    const step = W / (vals.length - 1);
    spark = vals.map((v, i) => `${(i * step).toFixed(1)},${(MID - v * (MID - 3)).toFixed(1)}`).join(" ");
  }
  return (
    <div className="rounded-xl bg-bg p-3 shadow-[var(--shadow-border)]">
      <div className="mb-2 flex items-center justify-between text-[11px] font-medium text-muted">
        <span className="text-fg">{item.match.homeTeam.name}</span>
        <span>{p.source === "api" ? "Momentum live" : "Pressão estimada"}</span>
        <span>{item.match.awayTeam.name}</span>
      </div>
      <div className="relative flex h-5 overflow-hidden rounded-full bg-elevated">
        <div className="h-full bg-hot/80 transition-[width] duration-500" style={{ width: `${homeW}%` }} />
        <div className="h-full flex-1 bg-muted/25" />
        <div className="absolute inset-y-0 left-1/2 w-px bg-fg/25" />
      </div>
      <div className="mt-2 flex justify-between font-mono text-[11px] tabular-nums text-muted">
        <span className="text-hot">{p.home.toFixed(0)}%</span>
        <span>{p.dominant || "Equilíbrio"}</span>
        <span>{p.away.toFixed(0)}%</span>
      </div>
      {spark ? (
        <svg viewBox={`0 0 ${W} ${H}`} className="mt-2 h-8 w-full" preserveAspectRatio="none" aria-hidden>
          <line x1="0" y1={MID} x2={W} y2={MID} stroke="currentColor" className="text-border-strong" />
          <polyline points={spark} fill="none" stroke="currentColor" className="text-hot" strokeWidth="2" />
        </svg>
      ) : null}
    </div>
  );
}

export function MatchDetail({ item }: { item: LiveItem | null }) {
  if (!item) {
    return (
      <div className="flex h-full min-h-64 flex-col items-center justify-center rounded-2xl bg-surface px-6 text-center shadow-[var(--shadow-border)]">
        <p className="text-sm text-muted">Seleciona um jogo para ver mercados, pressão e a leitura do motor.</p>
      </div>
    );
  }
  const { match, pred } = item;
  const v = pred.verdict;
  const o15 = findLine(pred.ouLines, 1.5);
  const o25 = findLine(pred.ouLines, 2.5);
  const ht05 = findLine(pred.ouLinesHT, 0.5);
  const ht15 = findLine(pred.ouLinesHT, 1.5);
  const h205 = findLine(pred.ouLines2H, 0.5);
  const h215 = findLine(pred.ouLines2H, 1.5);
  const hero = pred.analyst?.market && pred.analyst.market !== "SEM SINAL"
    ? { label: pred.analyst.market, value: pred.analyst.probability }
    : { label: "O0.5 · golo restante", value: pred.pAny };
  const pair = (a: number, b: number, dec?: boolean) =>
    dec ? `${a.toFixed(2)} – ${b.toFixed(2)}` : `${Math.round(a)} – ${Math.round(b)}`;

  return (
    <div className="space-y-3">
      <div className="rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]">
        <div className="mb-3 flex items-center justify-between gap-2 text-[11px] text-muted">
          <span className="truncate font-medium uppercase tracking-wide">{match.league}</span>
          <Badge tone={match.source === "demo" ? "warn" : "live"}>
            {match.source === "demo" ? "Exemplo" : "Ao vivo"}
          </Badge>
        </div>
        <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-3">
          <div className="flex min-w-0 items-center gap-2">
            <TeamCrest name={match.homeTeam.name} src={match.homeTeam.logo} size="md" />
            <span className="truncate text-sm font-semibold">{match.homeTeam.name}</span>
          </div>
          <div className="rounded-[10px] bg-bg px-3 py-1.5 text-center font-mono text-xl font-bold tabular-nums shadow-[var(--shadow-border)]">
            {match.score.fullTime.home}–{match.score.fullTime.away}
          </div>
          <div className="flex min-w-0 items-center justify-end gap-2">
            <span className="truncate text-right text-sm font-semibold">{match.awayTeam.name}</span>
            <TeamCrest name={match.awayTeam.name} src={match.awayTeam.logo} size="md" />
          </div>
        </div>
        <div className="mt-3 flex items-center justify-center gap-2 text-xs text-muted">
          <span className="font-mono font-semibold text-live tabular-nums">
            {match.period === "ht" ? "Intervalo" : `${match.minuteDisplay}'`}
          </span>
          {pred.reliability ? <span>· fiabilidade {pred.reliability}%</span> : null}
        </div>
      </div>

      {pred.has ? (
        <>
          <div className="flex items-center justify-between rounded-2xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]">
            <div>
              <div className="text-[11px] font-medium uppercase tracking-wide text-muted">Leitura</div>
              <div className="mt-0.5 text-sm font-semibold">{hero.label}</div>
            </div>
            <div className="font-mono text-3xl font-bold tabular-nums text-accent">
              {Number.isFinite(hero.value) ? `${Math.round(hero.value)}%` : "—"}
            </div>
          </div>

          {v ? (
            <div
              className={cn(
                "rounded-2xl bg-surface px-4 py-3 text-sm shadow-[var(--shadow-border)]",
                v.key === "alta" && "bg-hot/10 shadow-[0_0_0_1px_rgb(61_154_122/0.22)]",
              )}
            >
              <div className="font-semibold">
                {v.label} — {Math.round(v.p * 100)}%
                <span className="ml-1 font-normal text-muted">
                  (normal nesta liga: {Math.round(v.base * 100)}%)
                </span>
              </div>
              <div className="mt-1 text-muted">{v.nextText}</div>
              {v.fewData ? (
                <div className="mt-1 text-xs text-warm">Ainda poucos dados — leitura menos fiável.</div>
              ) : null}
            </div>
          ) : null}

          <div className="grid grid-cols-2 gap-2">
            <div className="rounded-xl bg-surface p-3 shadow-[var(--shadow-border)]">
              <div className="text-[10px] font-medium text-muted">Perigo</div>
              <div className="font-mono text-xl font-bold tabular-nums">{pred.danger.toFixed(0)}%</div>
              <div className="mt-2 h-1 overflow-hidden rounded-full bg-elevated">
                <div className="h-full bg-live" style={{ width: `${Math.min(100, pred.danger)}%` }} />
              </div>
            </div>
            <div className="rounded-xl bg-surface p-3 shadow-[var(--shadow-border)]">
              <div className="text-[10px] font-medium text-muted">Confiança</div>
              <div className="font-mono text-xl font-bold tabular-nums">{pred.conf.toFixed(0)}%</div>
              <div className="mt-2 h-1 overflow-hidden rounded-full bg-elevated">
                <div className="h-full bg-hot" style={{ width: `${Math.min(100, pred.conf)}%` }} />
              </div>
            </div>
          </div>

          <PressureMeter item={item} />

          {pred.summary ? (
            <p className="px-1 text-xs leading-relaxed text-muted">{pred.summary}</p>
          ) : null}

          <section>
            <h3 className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-subtle">1.ª parte</h3>
            <div className="grid grid-cols-2 gap-2">
              <Tile label="O0.5" value={ht05?.over} done={ht05?.done} missed={ht05?.missed} unknown={ht05?.unknown} />
              <Tile label="O1.5" value={ht15?.over} done={ht15?.done} missed={ht15?.missed} unknown={ht15?.unknown} />
            </div>
          </section>
          <section>
            <h3 className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-subtle">2.ª parte</h3>
            <div className="grid grid-cols-2 gap-2">
              <Tile label="O0.5" value={h205?.over} done={h205?.done} missed={h205?.missed} unknown={h205?.unknown} />
              <Tile label="O1.5" value={h215?.over} done={h215?.done} missed={h215?.missed} unknown={h215?.unknown} />
            </div>
          </section>
          <section>
            <h3 className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-subtle">Jogo</h3>
            <div className="grid grid-cols-2 gap-2">
              <Tile label="O0.5 resto" value={pred.pAny} />
              <Tile label="O1.5" value={o15?.over} done={o15?.done} />
              <Tile label="O2.5" value={o25?.over} done={o25?.done} />
              <Tile label="BTTS" value={pred.bttsYes} done={pred.bttsDone} />
            </div>
          </section>
          {pred.timeWindows.length ? (
            <section>
              <h3 className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-subtle">Janela de golo</h3>
              <div className="grid grid-cols-5 gap-1.5">
                {pred.timeWindows.map((w) => (
                  <Tile key={w.mins} label={`${w.mins}'`} value={w.prob} />
                ))}
              </div>
            </section>
          ) : null}

          <details className="rounded-2xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]">
            <summary className="cursor-pointer text-xs font-semibold text-muted">Estatísticas</summary>
            <div className="mt-3 grid grid-cols-3 gap-2">
              {[
                ["xG", pair(pred.xgH, pred.xgA, true)],
                ["À baliza", pair(pred.sotH, pred.sotA)],
                ["Remates", pair(pred.shotsH, pred.shotsA)],
                ["Big chances", pair(pred.bcH, pred.bcA)],
                ["Cantos", pair(pred.corH, pred.corA)],
                ["Posse", `${Math.round(pred.possH)} – ${Math.round(pred.possA)}`],
              ].map(([lab, val]) => (
                <div key={lab} className="rounded-lg bg-bg px-2 py-2 text-center shadow-[var(--shadow-border)]">
                  <div className="text-[9px] uppercase tracking-wide text-muted">{lab}</div>
                  <div className="mt-0.5 font-mono text-xs font-semibold tabular-nums">{val}</div>
                </div>
              ))}
            </div>
            <p className="mt-3 text-[10px] leading-relaxed text-subtle">
              {pred.model} · prior da liga {pred.leagueAvgGoals.toFixed(2)} golos/jogo. Estimativa estatística, não garantia.
            </p>
          </details>
        </>
      ) : (
        <div className="rounded-2xl bg-surface px-4 py-8 text-center text-sm text-muted shadow-[var(--shadow-border)]">
          Ainda sem estatísticas suficientes para este jogo.
        </div>
      )}
    </div>
  );
}
