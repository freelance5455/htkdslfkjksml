/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState } from 'react';
import { BackupData, Book, ReadingSession, BookQuote, Collection, ReadingGoal, AppSettings, CustomSticker } from '../../types';
import { syncService, SyncStatus } from '../../services/syncService';
import {
  X,
  Download,
  Upload,
  RefreshCw,
  Cloud,
  CheckCircle2,
  AlertTriangle,
  FileText,
  ShieldCheck,
  Smartphone,
  Layers,
} from 'lucide-react';

interface DataBackupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExportBackup: () => Promise<void>;
  onImportBackup: (jsonContent: string, mode: 'merge' | 'replace') => Promise<boolean>;
  onSyncCompleted?: () => Promise<void>;
}

export const DataBackupModal: React.FC<DataBackupModalProps> = ({
  isOpen,
  onClose,
  onExportBackup,
  onImportBackup,
  onSyncCompleted,
}) => {
  if (!isOpen) return null;

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedBackupContent, setSelectedBackupContent] = useState<string | null>(null);
  const [parsedBackupSummary, setParsedBackupSummary] = useState<{
    date: string;
    booksCount: number;
    sessionsCount: number;
    quotesCount: number;
    stickersCount: number;
    collectionsCount: number;
  } | null>(null);

  const [isProcessing, setIsProcessing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<SyncStatus>(syncService.getSyncStatus());
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'backup' | 'sync'>('backup');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Handle file selected for import
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setErrorMessage(null);
    setSuccessMessage(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      try {
        const parsed = JSON.parse(text);
        if (!parsed.books || !Array.isArray(parsed.books)) {
          setErrorMessage('El archivo no contiene un formato de respaldo válido de Mi Biblioteca.');
          return;
        }

        setSelectedBackupContent(text);
        setParsedBackupSummary({
          date: parsed.exportedAt || new Date().toISOString(),
          booksCount: parsed.books.length,
          sessionsCount: parsed.sessions?.length || 0,
          quotesCount: parsed.quotes?.length || 0,
          stickersCount: parsed.stickers?.length || 0,
          collectionsCount: parsed.collections?.length || 0,
        });
      } catch (err) {
        setErrorMessage('No se pudo leer el archivo JSON seleccionado.');
      }
    };
    reader.readAsText(file);
    // Reset file input so user can re-select the same file if needed
    e.target.value = '';
  };

  const handleConfirmImport = async (mode: 'merge' | 'replace') => {
    if (!selectedBackupContent) return;
    setIsProcessing(true);
    setErrorMessage(null);
    setSuccessMessage(null);
    try {
      const success = await onImportBackup(selectedBackupContent, mode);
      if (success) {
        setSelectedBackupContent(null);
        setParsedBackupSummary(null);
        setSuccessMessage(
          mode === 'merge'
            ? 'Copia de seguridad fusionada correctamente con tu biblioteca existente.'
            : 'Biblioteca restaurada con éxito.'
        );
        setTimeout(() => {
          onClose();
        }, 1500);
      } else {
        setErrorMessage('Hubo un error al procesar el respaldo.');
      }
    } catch {
      setErrorMessage('Error inesperado durante la importación.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePerformSync = async () => {
    setIsProcessing(true);
    setSyncFeedback('Preparando sincronización entre dispositivos...');
    try {
      const res = await syncService.performSync(syncStatus.accountEmail);
      setSyncStatus(syncService.getSyncStatus());
      setSyncFeedback(res.message);
      if (onSyncCompleted) {
        await onSyncCompleted();
      }
      setTimeout(() => setSyncFeedback(null), 4000);
    } catch (err: any) {
      setSyncFeedback('Error al sincronizar: ' + (err.message || ''));
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-2xl animate-fadeIn">
      <div className="w-full max-w-xl glass-panel rounded-3xl p-5 sm:p-7 border border-white/15 shadow-2xl flex flex-col justify-between max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <Layers className="w-4 h-4 text-zinc-200" />
            <h2 className="text-base sm:text-lg font-bold text-white font-['Syne']">
              Datos & Sincronización
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-white/[0.05] hover:bg-white/10 flex items-center justify-center text-zinc-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Toggle: Respaldo (Exportar/Importar) | Sincronización entre Dispositivos */}
        <div className="py-4 space-y-4 text-xs">
          <div className="flex items-center bg-white/[0.04] p-1 rounded-2xl border border-white/10">
            <button
              onClick={() => {
                setActiveTab('backup');
                setSelectedBackupContent(null);
              }}
              className={`flex-1 py-1.5 rounded-xl font-bold transition-all text-xs ${
                activeTab === 'backup'
                  ? 'bg-white/20 text-white shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Exportar e Importar
            </button>
            <button
              onClick={() => {
                setActiveTab('sync');
                setSelectedBackupContent(null);
              }}
              className={`flex-1 py-1.5 rounded-xl font-bold transition-all text-xs ${
                activeTab === 'sync'
                  ? 'bg-white/20 text-white shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Sincronización en la Nube
            </button>
          </div>

          {errorMessage && (
            <div className="p-3 rounded-2xl bg-red-500/15 border border-red-500/30 text-red-200 text-xs flex items-center justify-between gap-2 animate-fadeIn">
              <span>{errorMessage}</span>
              <button onClick={() => setErrorMessage(null)} className="text-red-300 hover:text-white p-0.5">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
          {successMessage && (
            <div className="p-3 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-200 text-xs flex items-center justify-between gap-2 animate-fadeIn">
              <span className="flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />{successMessage}</span>
              <button onClick={() => setSuccessMessage(null)} className="text-emerald-300 hover:text-white p-0.5">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* TAB 1: EXPORTAR E IMPORTAR DATOS (Requirement 6) */}
          {activeTab === 'backup' && (
            <div className="space-y-4 animate-fadeIn">
              {/* If user hasn't selected a file yet, show the options */}
              {!selectedBackupContent ? (
                <>
                  <p className="text-zinc-400 leading-relaxed">
                    Crea copias de seguridad portables de toda tu biblioteca: libros, progreso, posición de lectura, subrayados, notas, frases, reacciones, stickers asociados, colecciones, sesiones y configuración.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    {/* Export button */}
                    <div className="glass-panel-subtle rounded-2xl p-4 border border-white/[0.08] flex flex-col justify-between space-y-3">
                      <div>
                        <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center text-white mb-2">
                          <Download className="w-4 h-4" />
                        </div>
                        <h4 className="font-bold text-white text-xs">Exportar datos</h4>
                        <p className="text-[11px] text-zinc-400 mt-1 leading-normal">
                          Genera un archivo JSON descargable con todos tus datos estructurados.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={onExportBackup}
                        className="w-full py-2 px-3 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-xs shadow-md transition-all active:scale-[0.98] flex items-center justify-center gap-1.5"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Descargar respaldo</span>
                      </button>
                    </div>

                    {/* Import button */}
                    <div className="glass-panel-subtle rounded-2xl p-4 border border-white/[0.08] flex flex-col justify-between space-y-3">
                      <div>
                        <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center text-white mb-2">
                          <Upload className="w-4 h-4" />
                        </div>
                        <h4 className="font-bold text-white text-xs">Importar datos</h4>
                        <p className="text-[11px] text-zinc-400 mt-1 leading-normal">
                          Recupera un respaldo anterior con confirmación segura antes de aplicar.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="w-full py-2 px-3 rounded-xl bg-white/[0.08] hover:bg-white/20 border border-white/15 text-white font-bold text-xs transition-all active:scale-[0.98] flex items-center justify-center gap-1.5"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>Seleccionar archivo</span>
                      </button>
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept=".json,application/json"
                        onChange={handleFileChange}
                        className="sr-only"
                      />
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.06] text-[11px] text-zinc-400 flex items-start gap-2">
                    <ShieldCheck className="w-4 h-4 text-zinc-300 shrink-0 mt-0.5" />
                    <span>
                      Tus archivos de respaldo son privados y 100% compatibles con cualquier otro dispositivo.
                    </span>
                  </div>
                </>
              ) : (
                /* CONFIRMATION SCREEN BEFORE REPLACING / IMPORTING (Requirement 6) */
                <div className="space-y-4 p-4 rounded-2xl glass-panel border border-white/20 animate-fadeIn">
                  <div className="flex items-center gap-2 text-white">
                    <AlertTriangle className="w-5 h-5 text-amber-400" />
                    <h3 className="font-bold text-sm">Confirmar importación de respaldo</h3>
                  </div>

                  <p className="text-zinc-300 text-xs">
                    Se leyó correctamente el archivo de copia de seguridad. Revisa el contenido detectado:
                  </p>

                  {/* Summary of incoming data */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 py-2">
                    <div className="p-2.5 rounded-xl bg-white/[0.04] border border-white/10">
                      <span className="text-[10px] text-zinc-400 block">Libros</span>
                      <span className="text-sm font-bold text-white font-mono">
                        {parsedBackupSummary?.booksCount}
                      </span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-white/[0.04] border border-white/10">
                      <span className="text-[10px] text-zinc-400 block">Sesiones de lectura</span>
                      <span className="text-sm font-bold text-white font-mono">
                        {parsedBackupSummary?.sessionsCount}
                      </span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-white/[0.04] border border-white/10">
                      <span className="text-[10px] text-zinc-400 block">Frases y notas</span>
                      <span className="text-sm font-bold text-white font-mono">
                        {parsedBackupSummary?.quotesCount}
                      </span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-white/[0.04] border border-white/10">
                      <span className="text-[10px] text-zinc-400 block">Stickers</span>
                      <span className="text-sm font-bold text-white font-mono">
                        {parsedBackupSummary?.stickersCount}
                      </span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-white/[0.04] border border-white/10">
                      <span className="text-[10px] text-zinc-400 block">Colecciones</span>
                      <span className="text-sm font-bold text-white font-mono">
                        {parsedBackupSummary?.collectionsCount}
                      </span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-white/[0.04] border border-white/10">
                      <span className="text-[10px] text-zinc-400 block">Fecha respaldo</span>
                      <span className="text-xs font-semibold text-white truncate block mt-0.5">
                        {parsedBackupSummary?.date
                          ? new Date(parsedBackupSummary.date).toLocaleDateString('es-ES')
                          : 'Reciente'}
                      </span>
                    </div>
                  </div>

                  {/* Clear action choices */}
                  <div className="space-y-2 pt-2">
                    <span className="text-[11px] text-zinc-400 font-semibold block">
                      Selecciona cómo deseas aplicar este respaldo:
                    </span>

                    {/* Option 1: Fusionar (No destructivo) */}
                    <button
                      type="button"
                      disabled={isProcessing}
                      onClick={() => handleConfirmImport('merge')}
                      className="w-full p-3 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 text-left transition-all font-semibold flex items-center justify-between shadow-md"
                    >
                      <div>
                        <span className="font-bold text-xs block">
                          1. Fusionar con mi biblioteca actual (Recomendado)
                        </span>
                        <span className="text-[10.5px] text-zinc-800 font-normal">
                          Conserva tus libros existentes y añade los del respaldo sin borrar nada.
                        </span>
                      </div>
                      <CheckCircle2 className="w-4 h-4 text-zinc-950 shrink-0 ml-2" />
                    </button>

                    {/* Option 2: Reemplazar completamente */}
                    <button
                      type="button"
                      disabled={isProcessing}
                      onClick={() => {
                        if (
                          window.confirm(
                            '¿Estás seguro de que deseas REEMPLAZAR todos tus datos actuales por los del archivo de respaldo? Esta acción no se puede deshacer.'
                          )
                        ) {
                          handleConfirmImport('replace');
                        }
                      }}
                      className="w-full p-3 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/15 text-white text-left transition-all font-semibold"
                    >
                      <span className="font-bold text-xs block text-zinc-200">
                        2. Reemplazar biblioteca completa
                      </span>
                      <span className="text-[10.5px] text-zinc-400 font-normal">
                        Sobrescribe los datos actuales con los del archivo.
                      </span>
                    </button>

                    {/* Option 3: Cancelar */}
                    <button
                      type="button"
                      disabled={isProcessing}
                      onClick={() => {
                        setSelectedBackupContent(null);
                        setParsedBackupSummary(null);
                      }}
                      className="w-full py-2 text-center text-zinc-400 hover:text-white text-xs underline font-medium mt-1"
                    >
                      Cancelar importación
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: SINCRONIZACIÓN ENTRE DISPOSITIVOS (Requirement 5) */}
          {activeTab === 'sync' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="glass-panel-subtle rounded-2xl p-4 border border-white/[0.08] space-y-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center text-white">
                    <Cloud className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-xs">
                      Sincronización multi-dispositivo
                    </h4>
                    <span className="text-[10.5px] text-zinc-400">
                      Cuenta: {syncStatus.accountEmail}
                    </span>
                  </div>
                </div>

                <p className="text-zinc-300 text-xs leading-relaxed">
                  Toda tu biblioteca (libros, información, estados, progreso, posición de lectura, subrayados, notas, frases, reacciones, stickers asociados, etiquetas, colecciones, marcadores, sesiones de lectura y objetivos) está preparada para sincronizarse entre tus dispositivos sin borrar datos locales.
                </p>

                {/* Status card */}
                <div className="p-3 rounded-xl bg-white/[0.03] border border-white/[0.06] space-y-1.5">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-zinc-400">Estado:</span>
                    <span className="font-semibold text-white flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      <span>{syncStatus.lastSyncTime ? 'Sincronizado' : 'Listo para sincronizar'}</span>
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-zinc-400">Última sincronización:</span>
                    <span className="font-mono text-zinc-300">
                      {syncStatus.lastSyncTime
                        ? new Date(syncStatus.lastSyncTime).toLocaleDateString('es-ES', {
                            day: 'numeric',
                            month: 'short',
                            hour: '2-digit',
                            minute: '2-digit',
                          })
                        : 'Nunca'}
                    </span>
                  </div>
                </div>

                {syncFeedback && (
                  <div className="p-2.5 rounded-xl bg-white/10 border border-white/20 text-white text-xs flex items-center gap-2 animate-fadeIn">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{syncFeedback}</span>
                  </div>
                )}

                <button
                  type="button"
                  disabled={isProcessing}
                  onClick={handlePerformSync}
                  className="w-full py-2.5 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-xs shadow-md transition-all active:scale-[0.98] flex items-center justify-center gap-2"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isProcessing ? 'animate-spin' : ''}`} />
                  <span>{isProcessing ? 'Sincronizando...' : 'Sincronizar ahora'}</span>
                </button>
              </div>

              <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.06] text-[10.5px] text-zinc-400 space-y-1">
                <span className="font-semibold text-zinc-300 block">
                  ¿Cómo funciona la sincronización?
                </span>
                <p>
                  Al sincronizar en otro dispositivo con la misma cuenta, la aplicación une automáticamente tus libros y sesiones sin sobrescribir ni eliminar los datos que ya tengas registrados localmente.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-white/[0.06] hover:bg-white/15 text-white font-semibold text-xs transition-all"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
