import React, { useState, useMemo } from 'react';
import { 
  Sun, 
  Moon, 
  ChevronLeft, 
  ChevronRight, 
  Sparkles, 
  CheckCircle2, 
  Check, 
  RotateCcw, 
  Play, 
  Volume2, 
  VolumeX, 
  Heart, 
  Copy, 
  BookOpen, 
  Layers, 
  Filter, 
  ArrowLeft, 
  SlidersHorizontal,
  Flame,
  Clock,
  Share2,
  CheckCheck
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { MORNING_ADHKAR, EVENING_ADHKAR } from '../data/adhkarData';
import { DhikrItem } from '../types';
import { DhikrExplanationModal } from './DhikrExplanationModal';
import { recitationEngine } from '../utils/recitationService';

export const MorningEveningSpecializedView: React.FC = () => {
  const { 
    selectedCategory, 
    setSelectedCategory, 
    openDhikr, 
    progress, 
    incrementProgress, 
    decrementProgress, 
    resetDhikrProgress,
    resetCategoryProgress,
    isFavorite, 
    toggleFavorite, 
    getProgressFor, 
    settings, 
    showToast,
    setActiveTab,
    solarTimes
  } = useApp();

  // Active set: default to 'morning' or 'evening' (fallback to morning if 'all')
  const activeSet: 'morning' | 'evening' = selectedCategory === 'evening' ? 'evening' : 'morning';

  const [viewMode, setViewMode] = useState<'cards' | 'compact'>('cards');
  const [filterType, setFilterType] = useState<'all' | 'remaining' | 'completed' | 'favorites' | 'quran'>('all');
  const [selectedDhikrForExplanation, setSelectedDhikrForExplanation] = useState<DhikrItem | null>(null);
  const [showResetConfirmModal, setShowResetConfirmModal] = useState(false);
  const [playingDhikrId, setPlayingDhikrId] = useState<string | null>(null);

  // Determine smart suggestion based on current local hour
  const currentHour = new Date().getHours();
  const isMorningSuggested = currentHour >= 3 && currentHour < 15;
  const suggestedSet: 'morning' | 'evening' = isMorningSuggested ? 'morning' : 'evening';

  // Current list
  const currentList = activeSet === 'morning' ? MORNING_ADHKAR : EVENING_ADHKAR;

  // Counts & Progress calculations
  const morningCompleted = MORNING_ADHKAR.filter(d => (progress[d.id] || 0) >= d.count).length;
  const eveningCompleted = EVENING_ADHKAR.filter(d => (progress[d.id] || 0) >= d.count).length;

  const activeCompleted = activeSet === 'morning' ? morningCompleted : eveningCompleted;
  const activeTotal = currentList.length;
  const activePercent = Math.round((activeCompleted / activeTotal) * 100);
  const isSetFinished = activeCompleted === activeTotal;

  // Filtered items
  const filteredList = useMemo(() => {
    return currentList.filter(d => {
      const current = progress[d.id] || 0;
      const isDone = current >= d.count;
      const fav = isFavorite(d.id);

      if (filterType === 'remaining') return !isDone;
      if (filterType === 'completed') return isDone;
      if (filterType === 'favorites') return fav;
      if (filterType === 'quran') return d.isQuran === true;
      return true;
    });
  }, [currentList, filterType, progress, isFavorite]);

  // Handle switching set
  const handleSwitchSet = (target: 'morning' | 'evening') => {
    setSelectedCategory(target);
    recitationEngine.stop();
    setPlayingDhikrId(null);
  };

  // Start sequential recitation: find first uncompleted or first item
  const handleStartSequential = () => {
    const uncompleted = currentList.find(d => (progress[d.id] || 0) < d.count);
    openDhikr(uncompleted || currentList[0]);
  };

  // Toggle audio recitation for a card
  const handleToggleAudio = (dhikr: DhikrItem) => {
    if (playingDhikrId === dhikr.id) {
      recitationEngine.stop();
      setPlayingDhikrId(null);
    } else {
      setPlayingDhikrId(dhikr.id);
      recitationEngine.setOnStateChange(() => {
        if (!recitationEngine.isPlaying()) {
          setPlayingDhikrId(null);
        }
      });
      recitationEngine.playDhikr(dhikr);
      showToast(`بدء تلاوة: ${dhikr.title}`);
    }
  };

  const handleCopyText = (dhikr: DhikrItem) => {
    const fullText = `«${dhikr.title}»\n\n${dhikr.text}\n\n(التكرار: ${dhikr.count} مرة) - من تطبيق حصن المسلم`;
    navigator.clipboard?.writeText(fullText)
      .then(() => showToast('تم نسخ الذكر المبارك بنجاح ✓'))
      .catch(() => showToast('تعذر النسخ'));
  };

  // Font class helper based on settings
  const getArabicFontFamilyClass = () => {
    switch (settings.arabicFont) {
      case 'tajawal': return 'font-tajawal';
      case 'amiri': return 'font-amiri';
      case 'uthmani': return 'font-amiri';
      case 'cairo':
      default: return 'font-cairo';
    }
  };

  const getArabicFontSizeClass = () => {
    switch (settings.fontSize) {
      case 'sm': return 'text-sm leading-relaxed';
      case 'md': return 'text-base leading-relaxed';
      case 'xl': return 'text-xl leading-loose';
      case 'lg':
      default: return 'text-lg leading-loose';
    }
  };

  return (
    <div className="space-y-4 pb-28 pt-1 text-right animate-in fade-in duration-300">
      {/* Top Header Bar */}
      <header className="flex items-center justify-between gap-2 border-b border-emerald-800/40 pb-3">
        <button
          onClick={() => setActiveTab('home')}
          className="p-2 rounded-xl bg-[#042017] hover:bg-[#062c20] text-emerald-300 border border-emerald-700/60 transition-colors flex items-center gap-1.5 text-xs font-bold font-cairo cursor-pointer"
          title="العودة للرئيسية"
        >
          <ArrowLeft className="w-4 h-4 rotate-180" />
          <span>الرئيسية</span>
        </button>

        <div className="text-center">
          <h1 className="text-xl font-extrabold text-amber-300 font-cairo flex items-center justify-center gap-1.5">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>أذكار الصباح والمساء</span>
          </h1>
          <p className="text-[11px] text-emerald-400 font-tajawal">
            العرض المتخصص للتنقل السلس والذكر المستمر
          </p>
        </div>

        {/* View mode toggle (Cards vs Compact) */}
        <div className="flex items-center gap-1 bg-[#042017] p-1 rounded-xl border border-emerald-700/60">
          <button
            onClick={() => setViewMode('cards')}
            className={`px-2 py-1 rounded-lg text-xs font-bold transition-all ${
              viewMode === 'cards'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-emerald-400 hover:text-emerald-200'
            }`}
            title="عرض البطاقات المفصلة"
          >
            بطاقات
          </button>
          <button
            onClick={() => setViewMode('compact')}
            className={`px-2 py-1 rounded-lg text-xs font-bold transition-all ${
              viewMode === 'compact'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-emerald-400 hover:text-emerald-200'
            }`}
            title="عرض القائمة السريعة المدمجة"
          >
            موجز
          </button>
        </div>
      </header>

      {/* ===================================================================== */}
      {/* DUAL SET TOGGLE SWITCHER (أذكار الصباح ☀️ vs أذكار المساء 🌙) */}
      {/* ===================================================================== */}
      <div className="relative p-1.5 bg-[#031d14] rounded-3xl border border-emerald-700/60 shadow-lg">
        <div className="grid grid-cols-2 gap-2">
          {/* Morning Tab */}
          <button
            onClick={() => handleSwitchSet('morning')}
            className={`relative p-3.5 rounded-2xl flex flex-col items-center justify-center transition-all cursor-pointer ${
              activeSet === 'morning'
                ? 'bg-gradient-to-b from-[#854d0e] via-[#713f12] to-[#451a03] text-amber-100 shadow-md border border-amber-400/50 ring-2 ring-amber-400/30'
                : 'bg-[#042017]/80 hover:bg-[#072a1e] text-emerald-300 border border-emerald-800/60'
            }`}
          >
            <div className="flex items-center gap-2 mb-1">
              <div className={`p-2 rounded-xl ${activeSet === 'morning' ? 'bg-amber-500/30 text-amber-300' : 'bg-emerald-900/60 text-amber-400'}`}>
                <Sun className="w-5 h-5 drop-shadow-[0_0_8px_rgba(251,191,36,0.8)]" />
              </div>
              <div className="text-right">
                <div className="font-extrabold text-sm font-cairo flex items-center gap-1.5">
                  <span>أذكار الصباح</span>
                  {morningCompleted === 24 && (
                    <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  )}
                </div>
                <div className="text-[10px] text-amber-200/80 font-tajawal">
                  من الفجر حتى الضحى
                </div>
              </div>
            </div>

            {/* Morning completion progress mini pill */}
            <div className="w-full mt-2 flex items-center justify-between text-[11px] font-bold px-2 py-0.5 rounded-lg bg-black/25">
              <span>{morningCompleted} من ٢٤ مكتمل</span>
              <span className={morningCompleted === 24 ? 'text-emerald-400' : 'text-amber-300'}>
                {Math.round((morningCompleted / 24) * 100)}%
              </span>
            </div>

            {/* Time recommendation indicator */}
            {suggestedSet === 'morning' && (
              <span className="absolute -top-2 -right-1 text-[9px] font-bold bg-amber-400 text-[#0c2e20] px-2 py-0.5 rounded-full shadow-xs animate-pulse">
                الوقت المستحب الآن ☀️
              </span>
            )}
          </button>

          {/* Evening Tab */}
          <button
            onClick={() => handleSwitchSet('evening')}
            className={`relative p-3.5 rounded-2xl flex flex-col items-center justify-center transition-all cursor-pointer ${
              activeSet === 'evening'
                ? 'bg-gradient-to-b from-[#064e3b] via-[#043e2e] to-[#022c22] text-emerald-100 shadow-md border border-emerald-400/50 ring-2 ring-emerald-400/30'
                : 'bg-[#042017]/80 hover:bg-[#072a1e] text-emerald-300 border border-emerald-800/60'
            }`}
          >
            <div className="flex items-center gap-2 mb-1">
              <div className={`p-2 rounded-xl ${activeSet === 'evening' ? 'bg-emerald-500/30 text-amber-200' : 'bg-emerald-900/60 text-amber-300'}`}>
                <Moon className="w-5 h-5 fill-amber-200/25 drop-shadow-[0_0_8px_rgba(253,230,138,0.7)]" />
              </div>
              <div className="text-right">
                <div className="font-extrabold text-sm font-cairo flex items-center gap-1.5">
                  <span>أذكار المساء</span>
                  {eveningCompleted === 22 && (
                    <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  )}
                </div>
                <div className="text-[10px] text-emerald-300/80 font-tajawal">
                  من العصر حتى الليل
                </div>
              </div>
            </div>

            {/* Evening completion progress mini pill */}
            <div className="w-full mt-2 flex items-center justify-between text-[11px] font-bold px-2 py-0.5 rounded-lg bg-black/25">
              <span>{eveningCompleted} من ٢٢ مكتمل</span>
              <span className={eveningCompleted === 22 ? 'text-emerald-400' : 'text-emerald-300'}>
                {Math.round((eveningCompleted / 22) * 100)}%
              </span>
            </div>

            {/* Time recommendation indicator */}
            {suggestedSet === 'evening' && (
              <span className="absolute -top-2 -left-1 text-[9px] font-bold bg-emerald-400 text-[#0c2e20] px-2 py-0.5 rounded-full shadow-xs animate-pulse">
                الوقت المستحب الآن 🌙
              </span>
            )}
          </button>
        </div>
      </div>

      {/* ===================================================================== */}
      {/* ACTIVE SET CONTROL CARD & QUICK LAUNCH */}
      {/* ===================================================================== */}
      <div className={`p-4 rounded-3xl border transition-all ${
        activeSet === 'morning' 
          ? 'bg-gradient-to-br from-[#1a1309] to-[#042017] border-amber-600/40 shadow-sm'
          : 'bg-gradient-to-br from-[#021f17] to-[#042017] border-emerald-600/40 shadow-sm'
      }`}>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="text-sm font-extrabold font-cairo text-amber-300">
              {activeSet === 'morning' ? 'ورد الصباح المبارك' : 'ورد المساء المبارك'}
            </span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-900/60 text-emerald-300 border border-emerald-700/60 font-bold font-tajawal">
              {activeCompleted} من {activeTotal}
            </span>
          </div>

          <span className="text-sm font-black font-cairo text-emerald-400">
            {activePercent}%
          </span>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-[#02140e] h-3 rounded-full overflow-hidden p-0.5 border border-emerald-700/50 mb-3.5">
          <div 
            className={`h-full rounded-full transition-all duration-500 ${
              activeSet === 'morning'
                ? 'bg-gradient-to-r from-amber-500 via-amber-400 to-emerald-400'
                : 'bg-gradient-to-r from-emerald-600 via-emerald-500 to-amber-300'
            }`}
            style={{ width: `${activePercent}%` }}
          />
        </div>

        {/* Primary Action Buttons */}
        <div className="flex items-center gap-2">
          {/* Start / Continue recitation in DhikrDetailView */}
          <button
            onClick={handleStartSequential}
            className="flex-1 py-2.5 px-4 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-[#0c2e20] font-extrabold font-cairo text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer transition-transform active:scale-[0.98]"
          >
            <Play className="w-3.5 h-3.5 fill-[#0c2e20]" />
            <span>{activeCompleted > 0 ? 'متابعة القراءة المتتابعة' : 'ابدأ القراءة المتتابعة الآن'}</span>
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>

          {/* Reset Set Button */}
          <button
            onClick={() => setShowResetConfirmModal(true)}
            className="p-2.5 rounded-2xl bg-[#042017] hover:bg-[#062c20] text-emerald-300 border border-emerald-700/60 transition-colors cursor-pointer"
            title={`إعادة ضبط أذكار ${activeSet === 'morning' ? 'الصباح' : 'المساء'}`}
            aria-label="إعادة ضبط الورد"
          >
            <RotateCcw className="w-4 h-4 text-emerald-300" />
          </button>
        </div>
      </div>

      {/* ===================================================================== */}
      {/* FILTER PILLS */}
      {/* ===================================================================== */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs scrollbar-none select-none">
        {[
          { id: 'all', label: `الكل (${activeTotal})` },
          { id: 'remaining', label: `المتبقي (${activeTotal - activeCompleted})` },
          { id: 'completed', label: `المكتمل (${activeCompleted})` },
          { id: 'favorites', label: 'المفضلة' },
          { id: 'quran', label: 'الآيات والسور 📖' },
        ].map(pill => (
          <button
            key={pill.id}
            onClick={() => setFilterType(pill.id as any)}
            className={`px-3 py-1.5 rounded-xl font-bold font-cairo whitespace-nowrap transition-all border cursor-pointer ${
              filterType === pill.id
                ? 'bg-emerald-700 text-white border-emerald-500 shadow-xs'
                : 'bg-[#042017] text-emerald-300 border-emerald-800/80 hover:border-emerald-600'
            }`}
          >
            {pill.label}
          </button>
        ))}
      </div>

      {/* ===================================================================== */}
      {/* DHIKR LIST (CARDS OR COMPACT) */}
      {/* ===================================================================== */}
      <div className="space-y-3">
        {filteredList.length === 0 ? (
          <div className="p-8 text-center bg-[#042017] rounded-3xl border border-emerald-800/60 text-emerald-300 space-y-2">
            <CheckCheck className="w-8 h-8 text-emerald-400 mx-auto" />
            <p className="font-bold font-cairo">لا توجد أذكار في هذا التصنيف</p>
            <button
              onClick={() => setFilterType('all')}
              className="text-xs text-amber-300 font-bold underline cursor-pointer"
            >
              عرض جميع الأذكار
            </button>
          </div>
        ) : (
          filteredList.map((dhikr) => {
            const currentCount = getProgressFor(dhikr.id);
            const isDone = currentCount >= dhikr.count;
            const favorited = isFavorite(dhikr.id);
            const isPlaying = playingDhikrId === dhikr.id;

            const repetitionBadge = 
              dhikr.count === 1 ? 'مرة واحدة' :
              dhikr.count === 3 ? '٣ مرات' :
              dhikr.count === 4 ? '٤ مرات' :
              dhikr.count === 7 ? '٧ مرات' :
              dhikr.count === 10 ? '١٠ مرات' :
              dhikr.count === 100 ? '١٠٠ مرة' : `${dhikr.count} مرات`;

            if (viewMode === 'compact') {
              // Compact Row Mode
              return (
                <div
                  key={dhikr.id}
                  className={`p-3 rounded-2xl border transition-all flex items-center justify-between gap-2.5 ${
                    isDone
                      ? 'bg-emerald-950/40 border-emerald-600/40'
                      : 'bg-[#042017] border-emerald-800/60 hover:border-emerald-700'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0 flex-1">
                    <span className="w-7 h-7 rounded-lg bg-emerald-900/60 border border-emerald-700/60 text-amber-300 font-bold text-xs flex items-center justify-center shrink-0 font-cairo">
                      {dhikr.orderNumber}
                    </span>
                    <div className="truncate">
                      <div className="font-extrabold text-xs text-[#e8f5ee] font-cairo truncate">
                        {dhikr.title}
                      </div>
                      <div className="text-[10px] text-emerald-400 font-tajawal">
                        {repetitionBadge} {isDone ? '• مكتمل ✓' : `• (${currentCount}/${dhikr.count})`}
                      </div>
                    </div>
                  </div>

                  {/* Inline Counter Buttons */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => openDhikr(dhikr)}
                      className="p-1.5 rounded-lg bg-[#062c20] text-emerald-300 hover:text-white border border-emerald-700/50 cursor-pointer"
                      title="فتح التفاصيل الكاملة"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => incrementProgress(dhikr.id)}
                      className={`px-3 py-1.5 rounded-xl font-bold font-cairo text-xs transition-all flex items-center gap-1 cursor-pointer ${
                        isDone
                          ? 'bg-emerald-700/60 text-emerald-200 border border-emerald-500/40'
                          : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-xs'
                      }`}
                    >
                      {isDone ? <Check className="w-3.5 h-3.5" /> : null}
                      <span>{currentCount}/{dhikr.count}</span>
                    </button>
                  </div>
                </div>
              );
            }

            // Full Rich Card Mode
            return (
              <div
                key={dhikr.id}
                className={`p-4 rounded-3xl border transition-all space-y-3 relative overflow-hidden group ${
                  isDone
                    ? 'bg-gradient-to-br from-[#03231a] to-[#042017] border-emerald-500/50 shadow-xs'
                    : 'bg-[#042017] border-emerald-800/70 hover:border-emerald-600/80 shadow-xs'
                }`}
              >
                {/* Header row */}
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="w-8 h-8 rounded-xl bg-gradient-to-br from-emerald-800 to-emerald-950 text-amber-300 border border-emerald-600/40 flex items-center justify-center font-bold text-xs shrink-0 font-cairo shadow-2xs">
                      {dhikr.orderNumber}
                    </span>
                    <div>
                      <h3 className="text-sm font-extrabold text-[#e8f5ee] font-cairo flex items-center gap-1.5">
                        <span>{dhikr.title}</span>
                        {dhikr.isQuran && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-amber-950/70 text-amber-300 border border-amber-600/40 font-tajawal">
                            قرآن كريم
                          </span>
                        )}
                      </h3>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    {/* Repetition target pill */}
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-800/40 border border-emerald-600/40 text-emerald-300 text-[11px] font-bold font-cairo">
                      {repetitionBadge}
                    </span>

                    {/* Favorite Button */}
                    <button
                      onClick={() => toggleFavorite(dhikr.id)}
                      className={`p-1.5 rounded-xl border transition-colors cursor-pointer ${
                        favorited
                          ? 'bg-rose-950/40 border-rose-700/50 text-rose-400'
                          : 'bg-[#062c20] border-emerald-700/40 text-emerald-400 hover:text-rose-300'
                      }`}
                      title={favorited ? 'إزالة من المفضلة' : 'إضافة للمفضلة'}
                    >
                      <Heart className={`w-3.5 h-3.5 ${favorited ? 'fill-rose-400' : ''}`} />
                    </button>
                  </div>
                </div>

                {/* Main Arabic Text Body */}
                <div 
                  onClick={() => openDhikr(dhikr)}
                  className={`p-3.5 rounded-2xl bg-[#021811] border border-emerald-800/40 text-[#f0fdf4] font-bold text-right cursor-pointer hover:border-emerald-600/60 transition-colors select-none ${getArabicFontFamilyClass()} ${getArabicFontSizeClass()}`}
                >
                  {dhikr.text}
                </div>

                {/* Virtue or Note if available */}
                {dhikr.note && (
                  <p className="text-xs text-amber-200/90 font-tajawal bg-amber-950/30 p-2 rounded-xl border border-amber-800/30">
                    💡 {dhikr.note}
                  </p>
                )}

                {/* Card Action & Counting Toolbar */}
                <div className="flex items-center justify-between pt-1 border-t border-emerald-800/40 text-xs">
                  {/* Left utility buttons: audio, explanation, copy, open detail */}
                  <div className="flex items-center gap-1.5">
                    {/* Explanation Button */}
                    <button
                      onClick={() => setSelectedDhikrForExplanation(dhikr)}
                      className="p-2 rounded-xl bg-[#062c20] hover:bg-[#093a2b] text-amber-300 border border-amber-600/30 transition-colors flex items-center gap-1 text-[11px] font-bold font-cairo cursor-pointer"
                      title="فضل وتفسير هذا الذكر"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>الفضل</span>
                    </button>

                    {/* Audio recitation button */}
                    <button
                      onClick={() => handleToggleAudio(dhikr)}
                      className={`p-2 rounded-xl border transition-colors flex items-center gap-1 text-[11px] font-bold font-cairo cursor-pointer ${
                        isPlaying
                          ? 'bg-amber-500 text-[#0c2e20] border-amber-300 animate-pulse'
                          : 'bg-[#062c20] hover:bg-[#093a2b] text-emerald-300 border-emerald-700/50'
                      }`}
                      title="الاستماع لتلاوة الذكر"
                    >
                      {isPlaying ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                    </button>

                    {/* Copy button */}
                    <button
                      onClick={() => handleCopyText(dhikr)}
                      className="p-2 rounded-xl bg-[#062c20] hover:bg-[#093a2b] text-emerald-400 border border-emerald-700/50 transition-colors cursor-pointer"
                      title="نسخ نص الذكر"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>

                    {/* Open full digital misbaha */}
                    <button
                      onClick={() => openDhikr(dhikr)}
                      className="p-2 rounded-xl bg-[#062c20] hover:bg-[#093a2b] text-emerald-300 border border-emerald-700/50 transition-colors cursor-pointer text-[11px] font-bold font-cairo flex items-center gap-1"
                      title="فتح شاشة المسبحة الإلكترونية الكبيرة"
                    >
                      <span>المسبحة</span>
                      <ChevronLeft className="w-3 h-3" />
                    </button>
                  </div>

                  {/* Right side: Inline Digital Counter Button */}
                  <div className="flex items-center gap-1.5">
                    {currentCount > 0 && (
                      <button
                        onClick={() => decrementProgress(dhikr.id)}
                        className="w-8 h-8 rounded-xl bg-[#062c20] hover:bg-[#093a2b] text-emerald-400 border border-emerald-700/50 flex items-center justify-center font-bold text-xs cursor-pointer"
                        title="إنقاص (-1)"
                      >
                        -1
                      </button>
                    )}

                    {/* Main Tally Tap Button */}
                    <button
                      onClick={() => incrementProgress(dhikr.id)}
                      className={`px-4 py-2 rounded-2xl font-black font-cairo text-sm transition-all flex items-center gap-1.5 cursor-pointer shadow-md active:scale-95 ${
                        isDone
                          ? 'bg-emerald-700 text-white border border-emerald-400/50'
                          : 'bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white'
                      }`}
                    >
                      {isDone ? (
                        <>
                          <Check className="w-4 h-4 stroke-[3]" />
                          <span>أُنجز ({dhikr.count})</span>
                        </>
                      ) : (
                        <>
                          <span>تسبيح ({currentCount}/{dhikr.count})</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* ===================================================================== */}
      {/* FLOATING QUICK SWITCHER PILL (الانتقال السريع للورد الآخر) */}
      {/* ===================================================================== */}
      <div className="fixed bottom-20 left-4 right-4 z-20 max-w-md mx-auto pointer-events-none flex justify-center">
        <button
          onClick={() => handleSwitchSet(activeSet === 'morning' ? 'evening' : 'morning')}
          className="pointer-events-auto px-5 py-2.5 rounded-full bg-gradient-to-r from-[#03261b] via-[#053828] to-[#03261b] text-amber-300 font-extrabold font-cairo text-xs border border-amber-400/40 shadow-xl flex items-center gap-2 hover:border-amber-300 hover:scale-102 transition-all cursor-pointer backdrop-blur-md"
        >
          {activeSet === 'morning' ? (
            <>
              <Moon className="w-4 h-4 text-amber-300 fill-amber-300/30" />
              <span>الانتقال إلى أذكار المساء 🌙 (٢٢ ذكراً)</span>
            </>
          ) : (
            <>
              <Sun className="w-4 h-4 text-amber-400" />
              <span>الانتقال إلى أذكار الصباح ☀️ (٢٤ ذكراً)</span>
            </>
          )}
          <ChevronLeft className="w-3.5 h-3.5 text-amber-400" />
        </button>
      </div>

      {/* Explanation Modal */}
      {selectedDhikrForExplanation && (
        <DhikrExplanationModal
          dhikr={selectedDhikrForExplanation}
          isOpen={true}
          onClose={() => setSelectedDhikrForExplanation(null)}
          showToast={showToast}
        />
      )}

      {/* Reset Confirmation Modal */}
      {showResetConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in">
          <div className="bg-[#031d14] border border-emerald-700/80 rounded-3xl p-5 max-w-xs w-full text-center space-y-4 shadow-2xl">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/40 text-amber-300 flex items-center justify-center mx-auto">
              <RotateCcw className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-[#e8f5ee] font-cairo">
                إعادة ضبط أذكار {activeSet === 'morning' ? 'الصباح' : 'المساء'}؟
              </h3>
              <p className="text-xs text-emerald-300 font-tajawal mt-1">
                سيتم تصفير عدادات جميع أذكار هذا الورد فقط للبدء من جديد.
              </p>
            </div>
            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={() => {
                  resetCategoryProgress(activeSet);
                  setShowResetConfirmModal(false);
                }}
                className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-[#0c2e20] font-extrabold font-cairo text-xs transition-colors cursor-pointer"
              >
                تأكيد التصفير
              </button>
              <button
                onClick={() => setShowResetConfirmModal(false)}
                className="flex-1 py-2.5 rounded-xl bg-[#062c20] text-emerald-300 border border-emerald-700/60 font-bold font-cairo text-xs transition-colors cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
