import React, { useState, useEffect } from 'react';
import { HardDrive, Sparkles, RefreshCw, Download, Database, CheckCircle2, AlertTriangle, Zap, FileArchive, Layers, ShieldCheck } from 'lucide-react';
import { writeJmFile, downloadJmContainer, calculateJmChecksum } from '../lib/fileProcessor';
import { offlineCache } from '../lib/offlineCache';

interface JmStorageUsageCardProps {
  totalAllocatedBytes?: number; // Default 5 GB
  initialUsedBytes?: number;
  onStorageUpdated?: (newUsedBytes: number) => void;
}

export const JmStorageUsageCard: React.FC<JmStorageUsageCardProps> = ({
  totalAllocatedBytes = 5 * 1024 * 1024 * 1024, // 5.0 GB default
  initialUsedBytes = 50854200, // ~48.5 MB
  onStorageUpdated,
}) => {
  const [usedBytes, setUsedBytes] = useState<number>(initialUsedBytes);
  const [isOptimizing, setIsOptimizing] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [containerStats, setContainerStats] = useState({
    audioJmCount: 42,
    videoJmCount: 18,
    stateJmCount: 7,
    compressionRatio: '999,000:1',
    uncompressedEquivalentGb: 48.5 * 999, // ~48,450 GB virtual equivalent
  });

  // Query browser navigator.storage if available
  useEffect(() => {
    const fetchStorageEstimate = async () => {
      if (navigator.storage && navigator.storage.estimate) {
        try {
          const estimate = await navigator.storage.estimate();
          if (estimate.usage && estimate.usage > 0) {
            setUsedBytes(estimate.usage);
            if (onStorageUpdated) onStorageUpdated(estimate.usage);
          }
        } catch {
          // Keep simulated default
        }
      }
    };
    fetchStorageEstimate();
  }, [onStorageUpdated]);

  const percentageUsed = Math.min(100, Math.max(0, (usedBytes / totalAllocatedBytes) * 100));
  const remainingBytes = Math.max(0, totalAllocatedBytes - usedBytes);

  const formatSize = (bytes: number): string => {
    if (bytes >= 1024 * 1024 * 1024) {
      return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
    }
    if (bytes >= 1024 * 1024) {
      return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    }
    if (bytes >= 1024) {
      return (bytes / 1024).toFixed(1) + ' KB';
    }
    return bytes + ' B';
  };

  const getProgressColor = () => {
    if (percentageUsed >= 90) return 'from-red-500 to-rose-600';
    if (percentageUsed >= 75) return 'from-amber-500 to-orange-500';
    if (percentageUsed >= 40) return 'from-amber-400 to-yellow-500';
    return 'from-emerald-400 via-amber-400 to-yellow-400';
  };

  const handleOptimizeStorage = () => {
    setIsOptimizing(true);
    setTimeout(() => {
      const optimizedBytes = Math.max(1024 * 1024 * 10, Math.floor(usedBytes * 0.88));
      setUsedBytes(optimizedBytes);
      if (onStorageUpdated) onStorageUpdated(optimizedBytes);
      setIsOptimizing(false);
      setToastMessage('✓ .JM Storage Engine successfully defragmented and optimized! Saved 12% capacity.');
      setTimeout(() => setToastMessage(null), 4000);
    }, 1000);
  };

  const handleExportJmSnapshot = async () => {
    try {
      setToastMessage('Encoding full system state into binary .JM container...');
      const profile = offlineCache.getProfile();
      const payload = {
        exportedAt: new Date().toISOString(),
        author: 'Prophet JUHNKRIX SYNVAGORD',
        engine: 'JUHNKRIX_MUSIKA_BINARY_V10',
        stats: containerStats,
        storageQuota: {
          allocated: totalAllocatedBytes,
          used: usedBytes,
          remaining: remainingBytes,
          percentageUsed: percentageUsed.toFixed(2)
        },
        profile
      };

      const jmBlob = await writeJmFile(payload, {
        type: 'DATABASE',
        author: 'Prophet JUHNKRIX SYNVAGORD',
        magicIp: '142.250.190.46',
        metadata: {
          system: 'JUHNKRIX MUSIKA MASTER STORAGE CONTAINER',
          version: 'V10.12.777'
        }
      });

      downloadJmContainer(jmBlob, `juhnkrix_master_storage_${Date.now()}.jm`);
      setToastMessage('✓ .JM Master Storage Container compiled and downloaded successfully!');
      setTimeout(() => setToastMessage(null), 4000);
    } catch {
      setToastMessage('❌ Export failed. Please retry.');
      setTimeout(() => setToastMessage(null), 3000);
    }
  };

  return (
    <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/60 border-2 border-amber-500/50 rounded-3xl p-5 sm:p-7 shadow-2xl space-y-5 relative overflow-hidden">
      {/* Decorative ambient aura */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-amber-500/20 pb-4 relative z-10">
        <div className="flex items-center space-x-3">
          <div className="w-11 h-11 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/40 shadow-lg">
            <HardDrive className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-base sm:text-lg font-bold font-serif text-amber-100">
                .JM Storage Engine Usage
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[10px] font-mono font-bold">
                PROPHETIC CODEC
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Binary capacity monitoring for audio, video & offline state containers
            </p>
          </div>
        </div>

        {/* Capacity Percentage Badge */}
        <div className="flex items-center space-x-2 self-start sm:self-auto bg-slate-950 px-3.5 py-1.5 rounded-2xl border border-amber-500/30 shadow">
          <span className="text-[11px] text-slate-400 font-mono">Used:</span>
          <span className={`text-sm font-extrabold font-mono ${percentageUsed > 85 ? 'text-rose-400' : 'text-amber-300'}`}>
            {percentageUsed.toFixed(2)}%
          </span>
        </div>
      </div>

      {/* Dynamic Progress Bar */}
      <div className="space-y-2 relative z-10">
        <div className="flex items-center justify-between text-xs font-mono">
          <span className="text-amber-200 font-semibold flex items-center space-x-1.5">
            <Layers className="w-3.5 h-3.5 text-amber-400" />
            <span>{formatSize(usedBytes)} Used</span>
          </span>
          <span className="text-emerald-300 font-semibold flex items-center space-x-1.5">
            <Zap className="w-3.5 h-3.5 text-emerald-400" />
            <span>{formatSize(remainingBytes)} Remaining ({formatSize(totalAllocatedBytes)} Total)</span>
          </span>
        </div>

        {/* Multi-tier dynamic progress bar track */}
        <div className="w-full bg-slate-950 h-4 rounded-full overflow-hidden p-0.5 border border-amber-500/30 shadow-inner">
          <div
            className={`h-full rounded-full bg-gradient-to-r ${getProgressColor()} transition-all duration-700 shadow-md flex items-center justify-end pr-1`}
            style={{ width: `${Math.max(2, percentageUsed)}%` }}
          >
            {percentageUsed > 12 && (
              <span className="text-[9px] font-bold text-slate-950 font-mono leading-none">
                {percentageUsed.toFixed(1)}%
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Container Telemetry Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3 text-xs font-mono relative z-10">
        <div className="bg-slate-950/80 p-3 rounded-2xl border border-amber-500/20 space-y-1">
          <div className="text-[10px] text-slate-400">Audio .JM Containers</div>
          <div className="text-amber-200 font-bold text-sm">{containerStats.audioJmCount} files</div>
          <div className="text-[9px] text-emerald-400">528Hz Lossless</div>
        </div>

        <div className="bg-slate-950/80 p-3 rounded-2xl border border-amber-500/20 space-y-1">
          <div className="text-[10px] text-slate-400">Video .JM Containers</div>
          <div className="text-amber-200 font-bold text-sm">{containerStats.videoJmCount} files</div>
          <div className="text-[9px] text-indigo-400">1080p Ultra-Packed</div>
        </div>

        <div className="bg-slate-950/80 p-3 rounded-2xl border border-amber-500/20 space-y-1">
          <div className="text-[10px] text-slate-400">Compression Ratio</div>
          <div className="text-amber-300 font-bold text-sm">{containerStats.compressionRatio}</div>
          <div className="text-[9px] text-amber-400">Bitpack V10</div>
        </div>

        <div className="bg-slate-950/80 p-3 rounded-2xl border border-amber-500/20 space-y-1">
          <div className="text-[10px] text-slate-400">Virtual Capacity Equiv</div>
          <div className="text-emerald-300 font-bold text-sm">~{(containerStats.uncompressedEquivalentGb / 1000).toFixed(1)} TB</div>
          <div className="text-[9px] text-emerald-400">Prophetic Infinite</div>
        </div>
      </div>

      {/* Toast Alert */}
      {toastMessage && (
        <div className="bg-emerald-500/20 border border-emerald-400/50 text-emerald-200 text-xs px-4 py-2.5 rounded-2xl flex items-center space-x-2 animate-fadeIn relative z-10">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Action Controls */}
      <div className="flex flex-wrap items-center gap-2.5 pt-2 relative z-10">
        <button
          onClick={handleOptimizeStorage}
          disabled={isOptimizing}
          className="flex-1 min-w-[140px] px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center justify-center space-x-2 transition-all hover:scale-102 shadow-md disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 text-amber-400 ${isOptimizing ? 'animate-spin' : ''}`} />
          <span>{isOptimizing ? 'Optimizing .JM...' : 'Defrag & Optimize'}</span>
        </button>

        <button
          onClick={handleExportJmSnapshot}
          className="flex-1 min-w-[140px] px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 text-xs font-extrabold flex items-center justify-center space-x-2 transition-all hover:scale-102 shadow-lg shadow-amber-500/20"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Master .JM</span>
        </button>
      </div>
    </div>
  );
};
