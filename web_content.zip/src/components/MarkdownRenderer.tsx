import React, { useMemo, useState } from 'react';
import { marked } from 'marked';
import { Check, Copy } from 'lucide-react';

interface MarkdownRendererProps {
  content: string;
  isLight?: boolean;
}

// Configure marked with GFM and line breaks
const customRenderer = new marked.Renderer();

// Open links safely in new tab
customRenderer.link = ({ href, text }) => {
  return `<a href="${href}" target="_blank" rel="noopener noreferrer">${text}</a>`;
};

// Prevent any italics from markdown *text* or _text_ to keep fonts 100% upright
customRenderer.em = ({ text }) => {
  return `<span style="font-style: normal !important;">${text}</span>`;
};

// Wrap tables in responsive container
customRenderer.table = (token) => {
  const headerHtml = token.header.map(cell => `<th>${cell.text}</th>`).join('');
  const rowsHtml = token.rows.map(row => {
    const cellsHtml = row.map(cell => `<td>${cell.text}</td>`).join('');
    return `<tr>${cellsHtml}</tr>`;
  }).join('');

  return `
    <div class="table-wrapper">
      <table>
        <thead><tr>${headerHtml}</tr></thead>
        <tbody>${rowsHtml}</tbody>
      </table>
    </div>
  `;
};

marked.setOptions({
  gfm: true,
  breaks: true,
  renderer: customRenderer,
});

/**
 * Interactive Code Block Component with Copy action
 */
const CodeBlock: React.FC<{ code: string; language: string; isLight?: boolean }> = ({
  code,
  language,
  isLight,
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className={`my-3.5 rounded-xl overflow-hidden border ${
        isLight ? 'border-[#e5e5e5] bg-[#F7F7F8] shadow-2xs' : 'border-[#333333] bg-[#1e1e1e] shadow-sm'
      } font-mono text-xs`}
    >
      <div
        className={`flex items-center justify-between px-4 py-2 ${
          isLight ? 'bg-[#ececed] text-neutral-700' : 'bg-[#282828] text-neutral-300'
        }`}
      >
        <span className={`text-[11px] font-medium tracking-wide lowercase ${isLight ? 'text-neutral-700' : 'text-neutral-300'}`}>
          {language || 'code'}
        </span>
        <button
          onClick={handleCopy}
          className={`flex items-center gap-1.5 px-2 py-1 rounded-md text-[11px] font-medium transition-colors ${
            copied
              ? 'text-emerald-600'
              : isLight
              ? 'hover:text-neutral-900 hover:bg-neutral-300/50 text-neutral-600'
              : 'hover:text-white hover:bg-neutral-700/50 text-neutral-400'
          }`}
          title="نسخ الكود"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5" />
              <span>تم النسخ</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>نسخ الكود</span>
            </>
          )}
        </button>
      </div>
      <pre
        className={`p-4 overflow-x-auto ${
          isLight ? 'text-[#202123] bg-[#F7F7F8]' : 'text-[#ececec] bg-[#1e1e1e]'
        } text-left font-mono leading-relaxed text-[12.5px]`}
        dir="ltr"
      >
        <code>{code}</code>
      </pre>
    </div>
  );
};

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content, isLight }) => {
  // Parse content separating completed code blocks
  const parts = useMemo(() => {
    if (!content) return [];

    // Match code fences ```lang\ncode``` or streaming open code fences ```lang\ncode
    const regex = /(```[\s\S]*?```|```[\s\S]*$)/g;
    const tokens: Array<{ type: 'markdown' | 'code'; text: string; lang?: string }> = [];
    let lastIndex = 0;
    let match: RegExpExecArray | null;

    while ((match = regex.exec(content)) !== null) {
      if (match.index > lastIndex) {
        tokens.push({
          type: 'markdown',
          text: content.slice(lastIndex, match.index),
        });
      }

      const rawBlock = match[0];
      const isClosed = rawBlock.endsWith('```') && rawBlock.length >= 6;
      const inner = isClosed ? rawBlock.slice(3, -3) : rawBlock.slice(3);
      const firstNewline = inner.indexOf('\n');

      let lang = 'code';
      let code = inner;

      if (firstNewline !== -1) {
        lang = inner.slice(0, firstNewline).trim();
        code = inner.slice(firstNewline + 1);
      } else {
        lang = inner.trim();
        code = '';
      }

      tokens.push({
        type: 'code',
        text: code,
        lang: lang || 'code',
      });

      lastIndex = regex.lastIndex;
    }

    if (lastIndex < content.length) {
      tokens.push({
        type: 'markdown',
        text: content.slice(lastIndex),
      });
    }

    return tokens;
  }, [content]);

  return (
    <div className={`chat-markdown w-full ${isLight ? 'text-[#202123]' : 'text-[#ececec]'}`}>
      {parts.map((part, index) => {
        if (part.type === 'code') {
          return (
            <CodeBlock
              key={`code-${index}`}
              code={part.text}
              language={part.lang || 'code'}
              isLight={isLight}
            />
          );
        }

        // Render Markdown portion
        const html = marked.parse(part.text) as string;
        return (
          <div
            key={`md-${index}`}
            dangerouslySetInnerHTML={{ __html: html }}
          />
        );
      })}
    </div>
  );
};
