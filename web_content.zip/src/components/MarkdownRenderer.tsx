import React, { useState } from 'react';
import { Check, Copy } from 'lucide-react';

interface MarkdownRendererProps {
  content: string;
}

function CodeBlock({ language, code }: { language: string; code: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard?.writeText(code).then(() => {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    });
  };

  return (
    <div className="my-3 overflow-hidden rounded-xl border border-slate-200 bg-slate-900 text-slate-100 dark:border-[#293449] dark:bg-[#090d15]">
      <div className="flex items-center justify-between border-b border-slate-800 bg-slate-950/60 px-3.5 py-2 text-xs text-slate-400">
        <span className="font-mono">{language || 'code'}</span>
        <button
          type="button"
          onClick={handleCopy}
          className="inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-xs font-medium text-slate-300 transition-colors hover:bg-slate-800 hover:text-white whitespace-nowrap shrink-0"
        >
          {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
          <span>{copied ? 'Copied' : 'Copy code'}</span>
        </button>
      </div>
      <pre className="overflow-x-auto p-3.5 text-[13px] leading-relaxed font-mono text-indigo-100">
        <code>{code}</code>
      </pre>
    </div>
  );
}

function renderInline(text: string): React.ReactNode[] {
  // Tokenize inline code, bold, italic, and safe http(s) links
  const pattern = /(`[^`]+`|\*\*[^*]+\*\*|\*[^*]+\*|\[([^\]]+)\]\((https?:\/\/[^\s)]+)\))/g;
  const nodes: React.ReactNode[] = [];
  let lastIndex = 0;
  let match: RegExpExecArray | null;
  let keyIdx = 0;

  while ((match = pattern.exec(text)) !== null) {
    if (match.index > lastIndex) {
      nodes.push(text.slice(lastIndex, match.index));
    }

    const token = match[0];
    if (token.startsWith('`') && token.endsWith('`')) {
      nodes.push(
        <code
          key={`c-${keyIdx++}`}
          className="rounded-md bg-slate-200/80 px-1.5 py-0.5 font-mono text-[0.875em] text-indigo-700 dark:bg-[#090d15] dark:text-[#b8c8ff]"
        >
          {token.slice(1, -1)}
        </code>
      );
    } else if (token.startsWith('**') && token.endsWith('**')) {
      nodes.push(
        <strong key={`b-${keyIdx++}`} className="font-semibold text-slate-950 dark:text-white">
          {token.slice(2, -2)}
        </strong>
      );
    } else if (token.startsWith('*') && token.endsWith('*')) {
      nodes.push(
        <em key={`i-${keyIdx++}`} className="italic">
          {token.slice(1, -1)}
        </em>
      );
    } else if (match[2] && match[3]) {
      nodes.push(
        <a
          key={`l-${keyIdx++}`}
          href={match[3]}
          target="_blank"
          rel="noopener noreferrer"
          className="font-medium text-[#5367dd] underline decoration-[#5367dd]/40 underline-offset-2 hover:decoration-[#5367dd] dark:text-[#8ea0ff]"
        >
          {match[2]}
        </a>
      );
    }

    lastIndex = pattern.lastIndex;
  }

  if (lastIndex < text.length) {
    nodes.push(text.slice(lastIndex));
  }

  return nodes;
}

function renderTextSegment(segment: string, keyPrefix: string): React.ReactNode[] {
  const lines = segment.split('\n');
  const elements: React.ReactNode[] = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];
    const trimmed = line.trim();

    if (!trimmed) {
      i++;
      continue;
    }

    // Headings
    const headingMatch = /^(#{1,3})\s+(.+)$/.exec(trimmed);
    if (headingMatch) {
      const level = headingMatch[1].length;
      const content = renderInline(headingMatch[2]);
      if (level === 1) {
        elements.push(
          <h3 key={`${keyPrefix}-h-${i}`} className="mt-3 mb-1.5 font-display text-lg font-bold text-slate-950 dark:text-white first:mt-0">
            {content}
          </h3>
        );
      } else {
        elements.push(
          <h4 key={`${keyPrefix}-h-${i}`} className="mt-2.5 mb-1 font-display text-base font-semibold text-slate-900 dark:text-slate-100 first:mt-0">
            {content}
          </h4>
        );
      }
      i++;
      continue;
    }

    // Unordered list
    if (/^[-*•]\s+/.test(trimmed)) {
      const items: string[] = [];
      while (i < lines.length && /^[-*•]\s+/.test(lines[i].trim())) {
        items.push(lines[i].trim().replace(/^[-*•]\s+/, ''));
        i++;
      }
      elements.push(
        <ul key={`${keyPrefix}-ul-${i}`} className="my-2 list-disc space-y-1.5 pl-5">
          {items.map((item, idx) => (
            <li key={idx} className="leading-relaxed">
              {renderInline(item)}
            </li>
          ))}
        </ul>
      );
      continue;
    }

    // Ordered list
    if (/^\d+\.\s+/.test(trimmed)) {
      const items: string[] = [];
      while (i < lines.length && /^\d+\.\s+/.test(lines[i].trim())) {
        items.push(lines[i].trim().replace(/^\d+\.\s+/, ''));
        i++;
      }
      elements.push(
        <ol key={`${keyPrefix}-ol-${i}`} className="my-2 list-decimal space-y-1.5 pl-5">
          {items.map((item, idx) => (
            <li key={idx} className="leading-relaxed">
              {renderInline(item)}
            </li>
          ))}
        </ol>
      );
      continue;
    }

    // Blockquote (clean surface styling without thick left accent bar)
    if (/^>\s*/.test(trimmed)) {
      const quoteLines: string[] = [];
      while (i < lines.length && /^>\s*/.test(lines[i].trim())) {
        quoteLines.push(lines[i].trim().replace(/^>\s*/, ''));
        i++;
      }
      elements.push(
        <blockquote
          key={`${keyPrefix}-q-${i}`}
          className="my-2.5 rounded-xl border border-slate-200 bg-slate-100/80 px-3.5 py-2.5 text-slate-700 dark:border-[#293449] dark:bg-[#0f1522] dark:text-slate-300"
        >
          {renderInline(quoteLines.join(' '))}
        </blockquote>
      );
      continue;
    }

    // Paragraph block
    const paraLines: string[] = [];
    while (
      i < lines.length &&
      lines[i].trim() !== '' &&
      !/^(#{1,3}\s+|[-*•]\s+|\d+\.\s+|>\s*)/.test(lines[i].trim())
    ) {
      paraLines.push(lines[i]);
      i++;
    }

    elements.push(
      <p key={`${keyPrefix}-p-${i}`} className="mb-2.5 leading-relaxed last:mb-0">
        {paraLines.map((pLine, idx) => (
          <React.Fragment key={idx}>
            {idx > 0 && <br />}
            {renderInline(pLine)}
          </React.Fragment>
        ))}
      </p>
    );
  }

  return elements;
}

export function MarkdownRenderer({ content }: MarkdownRendererProps) {
  const parts: Array<{ type: 'text' | 'code'; content: string; language?: string }> = [];
  const codeBlockRegex = /```([a-zA-Z0-9_-]*)\n?([\s\S]*?)```/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = codeBlockRegex.exec(content)) !== null) {
    if (match.index > lastIndex) {
      parts.push({ type: 'text', content: content.slice(lastIndex, match.index) });
    }
    parts.push({
      type: 'code',
      language: match[1] || '',
      content: match[2].replace(/\n$/, ''),
    });
    lastIndex = codeBlockRegex.lastIndex;
  }

  if (lastIndex < content.length) {
    parts.push({ type: 'text', content: content.slice(lastIndex) });
  }

  if (parts.length === 0) {
    return <p className="leading-relaxed">{content}</p>;
  }

  return (
    <div className="text-[15px] leading-relaxed">
      {parts.map((part, idx) =>
        part.type === 'code' ? (
          <CodeBlock key={`cb-${idx}`} language={part.language || ''} code={part.content} />
        ) : (
          <React.Fragment key={`tx-${idx}`}>{renderTextSegment(part.content, `seg-${idx}`)}</React.Fragment>
        )
      )}
    </div>
  );
}
