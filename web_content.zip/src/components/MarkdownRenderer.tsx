import React, { useState } from 'react';
import { Check, Copy } from 'lucide-react';

interface MarkdownRendererProps {
  content: string;
}

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  const [copiedCodeIndex, setCopiedCodeIndex] = useState<number | null>(null);

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedCodeIndex(index);
    setTimeout(() => {
      setCopiedCodeIndex(null);
    }, 2000);
  };

  // Parse markdown into structured segments: code blocks vs regular text
  const parseBlocks = (markdown: string) => {
    const blocks: Array<{ type: 'code' | 'text'; content: string; language?: string }> = [];
    const codeBlockRegex = /```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g;

    let lastIndex = 0;
    let match;

    while ((match = codeBlockRegex.exec(markdown)) !== null) {
      if (match.index > lastIndex) {
        blocks.push({
          type: 'text',
          content: markdown.substring(lastIndex, match.index),
        });
      }
      blocks.push({
        type: 'code',
        language: match[1] || 'code',
        content: match[2].trimEnd(),
      });
      lastIndex = match.index + match[0].length;
    }

    if (lastIndex < markdown.length) {
      blocks.push({
        type: 'text',
        content: markdown.substring(lastIndex),
      });
    }

    return blocks;
  };

  // Helper to render inline formatting (bold, italic, code, links)
  const renderInline = (text: string) => {
    const tokens: React.ReactNode[] = [];
    let remaining = text;
    let keyIdx = 0;

    const inlineRegex = /(`([^`]+)`)|(\*\*([^*]+)\*\*)|(\*([^*]+)\*)|(\[([^\]]+)\]\(([^)]+)\))/;

    while (remaining) {
      const match = remaining.match(inlineRegex);
      if (!match || match.index === undefined) {
        tokens.push(remaining);
        break;
      }

      if (match.index > 0) {
        tokens.push(remaining.substring(0, match.index));
      }

      const [full, , inlineCode, , boldText, , italicText, , linkText, linkUrl] = match;

      if (inlineCode !== undefined) {
        tokens.push(
          <code
            key={`inline-code-${keyIdx++}`}
            className="px-1.5 py-0.5 mx-0.5 text-xs font-mono rounded-md bg-[var(--bg-surface)] text-[var(--accent-terracotta)] border border-[var(--border-subtle)]"
          >
            {inlineCode}
          </code>
        );
      } else if (boldText !== undefined) {
        tokens.push(
          <strong key={`bold-${keyIdx++}`} className="font-semibold text-[var(--text-primary)]">
            {boldText}
          </strong>
        );
      } else if (italicText !== undefined) {
        tokens.push(
          <em key={`italic-${keyIdx++}`} className="italic text-[var(--text-secondary)]">
            {italicText}
          </em>
        );
      } else if (linkText !== undefined && linkUrl !== undefined) {
        tokens.push(
          <a
            key={`link-${keyIdx++}`}
            href={linkUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-[var(--accent-terracotta)] underline hover:opacity-80 transition-opacity"
          >
            {linkText}
          </a>
        );
      }

      remaining = remaining.substring(match.index + full.length);
    }

    return tokens;
  };

  const renderTextParagraphs = (rawText: string, blockIndex: number) => {
    const lines = rawText.split('\n');
    const elements: React.ReactNode[] = [];
    let listBuffer: { type: 'ul' | 'ol'; items: string[] } | null = null;
    let tableBuffer: string[] = [];

    const flushList = (key: string) => {
      if (!listBuffer) return;
      if (listBuffer.type === 'ul') {
        elements.push(
          <ul key={key} className="my-2 space-y-1.5 pl-5 list-disc text-[var(--text-primary)]">
            {listBuffer.items.map((it, i) => (
              <li key={i}>{renderInline(it)}</li>
            ))}
          </ul>
        );
      } else {
        elements.push(
          <ol key={key} className="my-2 space-y-1.5 pl-5 list-decimal text-[var(--text-primary)]">
            {listBuffer.items.map((it, i) => (
              <li key={i}>{renderInline(it)}</li>
            ))}
          </ol>
        );
      }
      listBuffer = null;
    };

    const flushTable = (key: string) => {
      if (tableBuffer.length === 0) return;
      const rows = tableBuffer.map((line) =>
        line
          .split('|')
          .filter((_, idx, arr) => idx > 0 && idx < arr.length - 1)
          .map((c) => c.trim())
      );

      const isHeader = rows.length > 1 && rows[1].every((c) => c.startsWith('-'));
      const headerRow = isHeader ? rows[0] : null;
      const dataRows = isHeader ? rows.slice(2) : rows;

      elements.push(
        <div key={key} className="my-3 overflow-x-auto rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface)]">
          <table className="w-full text-left text-xs border-collapse">
            {headerRow && (
              <thead className="bg-[var(--bg-card)] border-b border-[var(--border-subtle)] text-[var(--text-secondary)] font-semibold">
                <tr>
                  {headerRow.map((cell, idx) => (
                    <th key={idx} className="p-3">
                      {renderInline(cell)}
                    </th>
                  ))}
                </tr>
              </thead>
            )}
            <tbody className="divide-y divide-[var(--border-subtle)]">
              {dataRows.map((r, rIdx) => (
                <tr key={rIdx} className="hover:bg-[var(--bg-card)]/50">
                  {r.map((cell, cIdx) => (
                    <td key={cIdx} className="p-3 text-[var(--text-primary)]">
                      {renderInline(cell)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
      tableBuffer = [];
    };

    lines.forEach((line, lineIdx) => {
      const trimmed = line.trim();

      // Check for table row
      if (trimmed.startsWith('|') && trimmed.endsWith('|')) {
        if (listBuffer) flushList(`list-before-table-${blockIndex}-${lineIdx}`);
        tableBuffer.push(trimmed);
        return;
      } else if (tableBuffer.length > 0) {
        flushTable(`table-${blockIndex}-${lineIdx}`);
      }

      // Check for bullet list item
      const ulMatch = trimmed.match(/^[-*•]\s+(.*)/);
      if (ulMatch) {
        if (!listBuffer || listBuffer.type !== 'ul') {
          flushList(`flush-${blockIndex}-${lineIdx}`);
          listBuffer = { type: 'ul', items: [] };
        }
        listBuffer.items.push(ulMatch[1]);
        return;
      }

      // Check for ordered list item
      const olMatch = trimmed.match(/^(\d+)\.\s+(.*)/);
      if (olMatch) {
        if (!listBuffer || listBuffer.type !== 'ol') {
          flushList(`flush-${blockIndex}-${lineIdx}`);
          listBuffer = { type: 'ol', items: [] };
        }
        listBuffer.items.push(olMatch[2]);
        return;
      }

      // If line isn't a list item, flush any pending list
      if (listBuffer) {
        flushList(`list-${blockIndex}-${lineIdx}`);
      }

      // Blockquotes (Claude signature terracotta bar)
      if (trimmed.startsWith('>')) {
        const quoteContent = trimmed.replace(/^>\s*/, '');
        elements.push(
          <blockquote
            key={`quote-${blockIndex}-${lineIdx}`}
            className="my-3 border-l-3 border-[var(--accent-terracotta)] pl-4 py-1 text-[var(--text-secondary)] italic rounded-r bg-[var(--accent-bg)]"
          >
            {renderInline(quoteContent)}
          </blockquote>
        );
        return;
      }

      // Headings (Claude editorial serif)
      if (trimmed.startsWith('### ')) {
        elements.push(
          <h3
            key={`h3-${blockIndex}-${lineIdx}`}
            className="text-base font-claude-serif font-semibold text-[var(--text-primary)] mt-4 mb-2 flex items-center gap-2"
          >
            {renderInline(trimmed.replace(/^###\s+/, ''))}
          </h3>
        );
        return;
      }

      if (trimmed.startsWith('## ')) {
        elements.push(
          <h2
            key={`h2-${blockIndex}-${lineIdx}`}
            className="text-lg font-claude-serif font-bold text-[var(--text-primary)] mt-5 mb-2 pb-1 border-b border-[var(--border-subtle)]"
          >
            {renderInline(trimmed.replace(/^##\s+/, ''))}
          </h2>
        );
        return;
      }

      if (trimmed.startsWith('# ')) {
        elements.push(
          <h1
            key={`h1-${blockIndex}-${lineIdx}`}
            className="text-xl font-claude-serif font-extrabold text-[var(--accent-terracotta)] mt-6 mb-3"
          >
            {renderInline(trimmed.replace(/^#\s+/, ''))}
          </h1>
        );
        return;
      }

      // Empty line
      if (trimmed === '') {
        elements.push(<div key={`spacer-${blockIndex}-${lineIdx}`} className="h-2.5" />);
        return;
      }

      // Standard paragraph
      elements.push(
        <p key={`p-${blockIndex}-${lineIdx}`} className="my-2 leading-relaxed text-[var(--text-primary)]">
          {renderInline(line)}
        </p>
      );
    });

    if (listBuffer) {
      flushList(`list-final-${blockIndex}`);
    }
    if (tableBuffer.length > 0) {
      flushTable(`table-final-${blockIndex}`);
    }

    return elements;
  };

  const blocks = parseBlocks(content);

  return (
    <div className="text-sm md:text-[15px] leading-relaxed break-words space-y-2">
      {blocks.map((block, idx) => {
        if (block.type === 'code') {
          return (
            <div
              key={`code-${idx}`}
              className="my-3.5 rounded-2xl border border-[var(--border-subtle)] bg-[#18181b] overflow-hidden shadow-md text-neutral-100"
            >
              <div className="flex items-center justify-between px-4 py-2 bg-[#121215] border-b border-neutral-800 text-xs text-neutral-400 font-mono">
                <span className="flex items-center gap-2 text-[var(--accent-terracotta)] font-medium">
                  <span className="w-2 h-2 rounded-full bg-[var(--accent-terracotta)] inline-block"></span>
                  {block.language || 'code'}
                </span>
                <button
                  onClick={() => copyToClipboard(block.content, idx)}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-colors cursor-pointer text-xs"
                  title="Копировать код"
                >
                  {copiedCodeIndex === idx ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Скопировано</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Копировать</span>
                    </>
                  )}
                </button>
              </div>
              <pre className="p-4 overflow-x-auto text-xs md:text-sm font-mono text-neutral-200 leading-normal selection:bg-neutral-800">
                <code>{block.content}</code>
              </pre>
            </div>
          );
        }

        return <div key={`text-block-${idx}`}>{renderTextParagraphs(block.content, idx)}</div>;
      })}
    </div>
  );
};
