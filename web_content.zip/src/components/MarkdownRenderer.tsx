import React, { useState } from 'react';
import { Copy, Check, Terminal } from 'lucide-react';

interface MarkdownRendererProps {
  content: string;
}

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  const [copiedCodeIndex, setCopiedCodeIndex] = useState<number | null>(null);

  const handleCopyCode = (code: string, index: number) => {
    navigator.clipboard.writeText(code);
    setCopiedCodeIndex(index);
    setTimeout(() => {
      setCopiedCodeIndex(null);
    }, 2000);
  };

  // Split content into code blocks and normal markdown segments
  const parts: React.ReactNode[] = [];
  const codeBlockRegex = /```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;
  let blockIndex = 0;

  while ((match = codeBlockRegex.exec(content)) !== null) {
    const textBefore = content.substring(lastIndex, match.index);
    if (textBefore) {
      parts.push(
        <div key={`text-${lastIndex}`} className="space-y-2">
          {renderMarkdownText(textBefore)}
        </div>
      );
    }

    const language = match[1] || 'code';
    const codeBody = match[2];
    const currentBlockIdx = blockIndex++;

    parts.push(
      <div
        key={`code-${match.index}`}
        className="my-3 overflow-hidden rounded-xl border border-cyan-500/20 bg-[#090d16] shadow-xl"
      >
        <div className="flex items-center justify-between border-b border-cyan-500/15 bg-slate-900/80 px-4 py-2 text-xs">
          <div className="flex items-center gap-2 text-cyan-400 font-mono">
            <Terminal className="w-3.5 h-3.5 text-cyan-400" />
            <span className="uppercase tracking-wider font-semibold">{language}</span>
          </div>
          <button
            onClick={() => handleCopyCode(codeBody, currentBlockIdx)}
            className="flex items-center gap-1.5 rounded-md px-2.5 py-1 text-slate-300 hover:text-white bg-slate-800/80 hover:bg-cyan-500/20 border border-slate-700/60 transition-colors"
            title="Copier le code"
          >
            {copiedCodeIndex === currentBlockIdx ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400 font-medium">Copié !</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copier</span>
              </>
            )}
          </button>
        </div>
        <div className="overflow-x-auto p-4 text-xs sm:text-sm font-mono text-cyan-100/90 leading-relaxed bg-[#0b101d]">
          <pre>
            <code>{codeBody}</code>
          </pre>
        </div>
      </div>
    );

    lastIndex = match.index + match[0].length;
  }

  const remainingText = content.substring(lastIndex);
  if (remainingText) {
    parts.push(
      <div key={`text-end`} className="space-y-2">
        {renderMarkdownText(remainingText)}
      </div>
    );
  }

  return <div className="markdown-body space-y-2 leading-relaxed">{parts}</div>;
};

// Helper for non-code markdown parsing
function renderMarkdownText(text: string): React.ReactNode[] {
  const lines = text.split('\n');
  const elements: React.ReactNode[] = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // Empty line
    if (!line.trim()) {
      elements.push(<div key={`empty-${i}`} className="h-2" />);
      continue;
    }

    // Headings
    if (line.startsWith('### ')) {
      elements.push(
        <h3 key={`h3-${i}`} className="text-base sm:text-lg font-bold text-cyan-300 pt-2 pb-1 flex items-center gap-2">
          <span className="w-1.5 h-4 bg-cyan-400 rounded-full inline-block"></span>
          {parseInlineFormatting(line.substring(4))}
        </h3>
      );
      continue;
    }
    if (line.startsWith('## ')) {
      elements.push(
        <h2 key={`h2-${i}`} className="text-lg sm:text-xl font-extrabold text-cyan-200 pt-3 pb-1 border-b border-cyan-500/20">
          {parseInlineFormatting(line.substring(3))}
        </h2>
      );
      continue;
    }
    if (line.startsWith('# ')) {
      elements.push(
        <h1 key={`h1-${i}`} className="text-xl sm:text-2xl font-black text-cyan-100 pt-3 pb-1">
          {parseInlineFormatting(line.substring(2))}
        </h1>
      );
      continue;
    }

    // Blockquote
    if (line.startsWith('> ')) {
      elements.push(
        <blockquote
          key={`quote-${i}`}
          className="border-l-4 border-cyan-500/60 bg-cyan-950/20 pl-3 py-1.5 italic text-slate-300 rounded-r-lg my-1.5"
        >
          {parseInlineFormatting(line.substring(2))}
        </blockquote>
      );
      continue;
    }

    // Unordered List (- or *)
    if (line.startsWith('- ') || line.startsWith('* ')) {
      elements.push(
        <li key={`li-${i}`} className="ml-5 list-disc text-slate-200 my-0.5 marker:text-cyan-400">
          {parseInlineFormatting(line.substring(2))}
        </li>
      );
      continue;
    }

    // Numbered List (1. )
    const numberedMatch = line.match(/^(\d+)\.\s+(.*)/);
    if (numberedMatch) {
      elements.push(
        <li key={`num-${i}`} className="ml-5 list-decimal text-slate-200 my-0.5 marker:text-cyan-400 marker:font-semibold">
          {parseInlineFormatting(numberedMatch[2])}
        </li>
      );
      continue;
    }

    // Regular paragraph
    elements.push(
      <p key={`p-${i}`} className="text-slate-200 text-sm sm:text-base">
        {parseInlineFormatting(line)}
      </p>
    );
  }

  return elements;
}

// Inline formatting (bold, italic, inline code)
function parseInlineFormatting(str: string): React.ReactNode {
  // Regex to match inline code, bold, italic
  const parts: React.ReactNode[] = [];
  let remaining = str;
  let keyIdx = 0;

  while (remaining.length > 0) {
    // Inline code `...`
    const codeMatch = remaining.match(/^(.*?)`([^`]+)`([\s\S]*)$/);
    // Bold **...**
    const boldMatch = remaining.match(/^(.*?)\*\*([^*]+)\*\*([\s\S]*)$/);
    // Italic *...*
    const italicMatch = remaining.match(/^(.*?)\*([^*]+)\*([\s\S]*)$/);

    // Pick whichever match comes first
    type Candidate = { type: 'code' | 'bold' | 'italic'; index: number; before: string; inner: string; after: string };
    const candidates: Candidate[] = [];

    if (codeMatch) candidates.push({ type: 'code', index: codeMatch[1].length, before: codeMatch[1], inner: codeMatch[2], after: codeMatch[3] });
    if (boldMatch) candidates.push({ type: 'bold', index: boldMatch[1].length, before: boldMatch[1], inner: boldMatch[2], after: boldMatch[3] });
    if (italicMatch && (!boldMatch || italicMatch[1].length < boldMatch[1].length)) {
      candidates.push({ type: 'italic', index: italicMatch[1].length, before: italicMatch[1], inner: italicMatch[2], after: italicMatch[3] });
    }

    if (candidates.length === 0) {
      parts.push(remaining);
      break;
    }

    candidates.sort((a, b) => a.index - b.index);
    const first = candidates[0];

    if (first.before) {
      parts.push(first.before);
    }

    if (first.type === 'code') {
      parts.push(
        <code
          key={`code-inline-${keyIdx++}`}
          className="rounded-md bg-cyan-950/60 border border-cyan-500/30 px-1.5 py-0.5 font-mono text-xs text-cyan-300"
        >
          {first.inner}
        </code>
      );
    } else if (first.type === 'bold') {
      parts.push(
        <strong key={`bold-${keyIdx++}`} className="font-semibold text-white">
          {first.inner}
        </strong>
      );
    } else if (first.type === 'italic') {
      parts.push(
        <em key={`italic-${keyIdx++}`} className="italic text-slate-300">
          {first.inner}
        </em>
      );
    }

    remaining = first.after;
  }

  return <>{parts}</>;
}
