import React, { useState } from 'react';
import { Copy, Check, Terminal } from 'lucide-react';

interface MarkdownRendererProps {
  content: string;
}

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const handleCopyCode = async (code: string, index: number) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedIndex(index);
      setTimeout(() => setCopiedIndex(null), 2000);
    } catch (e) {
      console.error('Failed to copy', e);
    }
  };

  // Split content by code blocks ```...```
  const parseBlocks = () => {
    const blocks: Array<{ type: 'code' | 'text' | 'table'; content: string; language?: string }> = [];
    const codeBlockRegex = /```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g;
    let lastIndex = 0;
    let match;

    while ((match = codeBlockRegex.exec(content)) !== null) {
      if (match.index > lastIndex) {
        const textChunk = content.substring(lastIndex, match.index);
        blocks.push(...splitTextAndTables(textChunk));
      }
      blocks.push({
        type: 'code',
        language: match[1] || 'code',
        content: match[2].trimEnd(),
      });
      lastIndex = match.index + match[0].length;
    }

    if (lastIndex < content.length) {
      const remaining = content.substring(lastIndex);
      blocks.push(...splitTextAndTables(remaining));
    }

    return blocks;
  };

  const splitTextAndTables = (rawText: string) => {
    const lines = rawText.split('\n');
    const result: Array<{ type: 'text' | 'table'; content: string }> = [];
    let tableBuffer: string[] = [];
    let textBuffer: string[] = [];

    const flushText = () => {
      if (textBuffer.length > 0) {
        result.push({ type: 'text', content: textBuffer.join('\n') });
        textBuffer = [];
      }
    };

    const flushTable = () => {
      if (tableBuffer.length > 0) {
        result.push({ type: 'table', content: tableBuffer.join('\n') });
        tableBuffer = [];
      }
    };

    for (const line of lines) {
      if (line.trim().startsWith('|') && line.trim().endsWith('|')) {
        flushText();
        tableBuffer.push(line);
      } else {
        if (tableBuffer.length > 0) {
          flushTable();
        }
        textBuffer.push(line);
      }
    }

    flushText();
    flushTable();
    return result;
  };

  const renderInline = (text: string) => {
    // Regex for bold, italic, inline code, and links
    const parts: React.ReactNode[] = [];
    let current = text;
    let key = 0;

    // Process inline code `...`
    const inlineTokens = current.split(/(`[^`]+`)/g);

    return inlineTokens.map((token, idx) => {
      if (token.startsWith('`') && token.endsWith('`') && token.length > 1) {
        return (
          <code
            key={idx}
            className="px-1.5 py-0.5 mx-0.5 rounded text-xs font-mono bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20"
          >
            {token.slice(1, -1)}
          </code>
        );
      }

      // Process bold **...**
      const boldTokens = token.split(/(\*\*[^*]+\*\*)/g);
      return boldTokens.map((bToken, bIdx) => {
        if (bToken.startsWith('**') && bToken.endsWith('**') && bToken.length > 3) {
          const inner = bToken.slice(2, -2);
          return (
            <strong key={`${idx}-${bIdx}`} className="font-bold text-slate-900 dark:text-slate-100">
              {inner}
            </strong>
          );
        }

        // Process italic *...*
        const italicTokens = bToken.split(/(\*[^*]+\*)/g);
        return italicTokens.map((iToken, iIdx) => {
          if (iToken.startsWith('*') && iToken.endsWith('*') && iToken.length > 2) {
            return (
              <em key={`${idx}-${bIdx}-${iIdx}`} className="italic text-slate-800 dark:text-slate-200">
                {iToken.slice(1, -1)}
              </em>
            );
          }
          return <span key={`${idx}-${bIdx}-${iIdx}`}>{iToken}</span>;
        });
      });
    });
  };

  const renderTextBlock = (text: string, blockIndex: number) => {
    const lines = text.split('\n');
    const elements: React.ReactNode[] = [];

    lines.forEach((line, index) => {
      const trimmed = line.trim();

      if (!trimmed) {
        elements.push(<div key={`empty-${blockIndex}-${index}`} className="h-2" />);
        return;
      }

      // Headings
      if (trimmed.startsWith('#### ')) {
        elements.push(
          <h4
            key={`h4-${blockIndex}-${index}`}
            className="text-sm font-semibold text-emerald-600 dark:text-emerald-400 mt-3 mb-1"
          >
            {renderInline(trimmed.replace('#### ', ''))}
          </h4>
        );
      } else if (trimmed.startsWith('### ')) {
        elements.push(
          <h3
            key={`h3-${blockIndex}-${index}`}
            className="text-base font-bold text-slate-900 dark:text-white mt-4 mb-1.5 flex items-center gap-2"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            {renderInline(trimmed.replace('### ', ''))}
          </h3>
        );
      } else if (trimmed.startsWith('## ')) {
        elements.push(
          <h2
            key={`h2-${blockIndex}-${index}`}
            className="text-lg font-bold text-slate-900 dark:text-white mt-5 mb-2 border-b border-slate-200 dark:border-slate-800 pb-1"
          >
            {renderInline(trimmed.replace('## ', ''))}
          </h2>
        );
      } else if (trimmed.startsWith('# ')) {
        elements.push(
          <h1
            key={`h1-${blockIndex}-${index}`}
            className="text-xl font-extrabold text-slate-900 dark:text-white mt-6 mb-2"
          >
            {renderInline(trimmed.replace('# ', ''))}
          </h1>
        );
      } else if (trimmed.startsWith('> ')) {
        elements.push(
          <blockquote
            key={`quote-${blockIndex}-${index}`}
            className="border-l-4 border-emerald-500/60 pl-3 my-2 italic text-slate-700 dark:text-slate-300 bg-emerald-500/5 py-1 rounded-r"
          >
            {renderInline(trimmed.replace('> ', ''))}
          </blockquote>
        );
      } else if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
        elements.push(
          <div
            key={`list-${blockIndex}-${index}`}
            className="flex items-start gap-2 my-1 text-slate-700 dark:text-slate-200"
          >
            <span className="text-emerald-500 mt-1 text-xs select-none">●</span>
            <div className="flex-1">{renderInline(trimmed.replace(/^[-*]\s+/, ''))}</div>
          </div>
        );
      } else if (/^\d+\.\s/.test(trimmed)) {
        const numMatch = trimmed.match(/^(\d+)\.\s(.*)$/);
        elements.push(
          <div
            key={`numlist-${blockIndex}-${index}`}
            className="flex items-start gap-2.5 my-1 text-slate-700 dark:text-slate-200"
          >
            <span className="text-emerald-600 dark:text-emerald-400 font-semibold text-xs min-w-4 mt-0.5">
              {numMatch ? numMatch[1] : '•'}.
            </span>
            <div className="flex-1">{renderInline(numMatch ? numMatch[2] : trimmed)}</div>
          </div>
        );
      } else {
        elements.push(
          <p key={`p-${blockIndex}-${index}`} className="my-1.5 leading-relaxed text-slate-700 dark:text-slate-200">
            {renderInline(line)}
          </p>
        );
      }
    });

    return <div key={`block-${blockIndex}`}>{elements}</div>;
  };

  const renderTable = (rawTable: string, blockIndex: number) => {
    const rows = rawTable
      .split('\n')
      .map((r) => r.trim())
      .filter((r) => r.startsWith('|') && r.endsWith('|'));

    if (rows.length < 2) return null;

    // Filter out separator row e.g. |---|---|
    const headerRow = rows[0]
      .slice(1, -1)
      .split('|')
      .map((c) => c.trim());
    const bodyRows = rows.slice(1).filter((r) => !/^[|\s-:]+$/.test(r));

    return (
      <div key={`table-${blockIndex}`} className="my-3 overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-slate-100 dark:bg-slate-800/80 text-slate-700 dark:text-slate-200 font-semibold">
            <tr>
              {headerRow.map((cell, cIdx) => (
                <th key={cIdx} className="p-2.5 border-b border-slate-200 dark:border-slate-800">
                  {renderInline(cell)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800/50">
            {bodyRows.map((rowStr, rIdx) => {
              const cells = rowStr
                .slice(1, -1)
                .split('|')
                .map((c) => c.trim());
              return (
                <tr key={rIdx} className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                  {cells.map((cell, cIdx) => (
                    <td key={cIdx} className="p-2.5 text-slate-700 dark:text-slate-300">
                      {renderInline(cell)}
                    </td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  };

  const blocks = parseBlocks();

  return (
    <div className="space-y-2 text-sm leading-relaxed break-words">
      {blocks.map((block, idx) => {
        if (block.type === 'code') {
          const isCopied = copiedIndex === idx;
          return (
            <div
              key={`code-${idx}`}
              className="my-3 rounded-xl overflow-hidden border border-slate-800 bg-slate-950 text-slate-100 shadow-lg"
            >
              <div className="flex items-center justify-between px-3 py-2 bg-slate-900 border-b border-slate-800/80 text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="font-mono text-emerald-400/90 font-medium">
                    {block.language || 'code'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopyCode(block.content, idx)}
                  className="flex items-center gap-1.5 px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-all text-xs"
                  title="Нусхабардорӣ"
                >
                  {isCopied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Нусхабардорӣ шуд</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Нусха бардоштан</span>
                    </>
                  )}
                </button>
              </div>
              <div className="p-3.5 overflow-x-auto text-xs font-mono leading-relaxed bg-slate-950 text-slate-200">
                <pre>
                  <code>{block.content}</code>
                </pre>
              </div>
            </div>
          );
        }

        if (block.type === 'table') {
          return renderTable(block.content, idx);
        }

        return renderTextBlock(block.content, idx);
      })}
    </div>
  );
};
