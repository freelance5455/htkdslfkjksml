import React, { useState } from 'react';
import { Copy, Check } from 'lucide-react';

interface MarkdownRendererProps {
  content: string;
}

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const handleCopy = (codeText: string, index: number) => {
    navigator.clipboard.writeText(codeText);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  // Split content by code blocks: ```lang ... ```
  const codeBlockRegex = /```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g;
  const parts: Array<{ type: 'text' | 'code'; content: string; language?: string }> = [];
  let lastIndex = 0;
  let match;

  while ((match = codeBlockRegex.exec(content)) !== null) {
    if (match.index > lastIndex) {
      parts.push({
        type: 'text',
        content: content.slice(lastIndex, match.index),
      });
    }
    parts.push({
      type: 'code',
      language: match[1] || 'plaintext',
      content: match[2],
    });
    lastIndex = match.index + match[0].length;
  }

  if (lastIndex < content.length) {
    parts.push({
      type: 'text',
      content: content.slice(lastIndex),
    });
  }

  // Helper for rendering regular text with inline markdown
  const renderInlineMarkdown = (text: string) => {
    const lines = text.split('\n');

    return lines.map((line, lineIdx) => {
      const trimmed = line.trim();

      // Heading 1
      if (trimmed.startsWith('# ')) {
        return (
          <h1 key={lineIdx} className="text-xl sm:text-2xl font-bold text-white mt-4 mb-2 tracking-tight">
            {formatInline(trimmed.replace(/^#\s+/, ''))}
          </h1>
        );
      }
      // Heading 2
      if (trimmed.startsWith('## ')) {
        return (
          <h2 key={lineIdx} className="text-lg sm:text-xl font-bold text-cyan-300 mt-3 mb-2 tracking-tight">
            {formatInline(trimmed.replace(/^##\s+/, ''))}
          </h2>
        );
      }
      // Heading 3
      if (trimmed.startsWith('### ')) {
        return (
          <h3 key={lineIdx} className="text-base sm:text-lg font-semibold text-violet-300 mt-2 mb-1">
            {formatInline(trimmed.replace(/^###\s+/, ''))}
          </h3>
        );
      }
      // Bullet list item
      if (trimmed.startsWith('* ') || trimmed.startsWith('- ')) {
        return (
          <li key={lineIdx} className="ml-5 list-disc text-slate-200 my-0.5 leading-relaxed">
            {formatInline(trimmed.replace(/^(\*|-)\s+/, ''))}
          </li>
        );
      }
      // Numbered list item
      const numMatch = trimmed.match(/^(\d+)\.\s+(.*)/);
      if (numMatch) {
        return (
          <div key={lineIdx} className="ml-2 flex items-start gap-2 text-slate-200 my-1 leading-relaxed">
            <span className="font-semibold text-cyan-400 select-none min-w-[1.2rem]">{numMatch[1]}.</span>
            <span>{formatInline(numMatch[2])}</span>
          </div>
        );
      }
      // Blockquote
      if (trimmed.startsWith('> ')) {
        return (
          <blockquote key={lineIdx} className="border-l-2 border-cyan-500/60 pl-3 my-2 text-slate-300 italic bg-cyan-950/20 py-1 rounded-r">
            {formatInline(trimmed.replace(/^>\s+/, ''))}
          </blockquote>
        );
      }
      // Empty line
      if (trimmed === '') {
        return <div key={lineIdx} className="h-2" />;
      }

      return (
        <p key={lineIdx} className="my-1 text-slate-100 leading-relaxed break-words">
          {formatInline(line)}
        </p>
      );
    });
  };

  // Inline formatting: **bold**, *italic*, `code`
  const formatInline = (str: string): React.ReactNode => {
    // Regex for bold **text**, inline `code`, and *italic*
    const tokens: React.ReactNode[] = [];
    const inlineRegex = /(\*\*([^*]+)\*\*)|(`([^`]+)`)|(\*([^*]+)\*)/g;
    let lastPos = 0;
    let m;

    while ((m = inlineRegex.exec(str)) !== null) {
      if (m.index > lastPos) {
        tokens.push(str.slice(lastPos, m.index));
      }
      if (m[2]) {
        // Bold
        tokens.push(
          <strong key={m.index} className="font-semibold text-white">
            {m[2]}
          </strong>
        );
      } else if (m[4]) {
        // Inline code
        tokens.push(
          <code
            key={m.index}
            className="px-1.5 py-0.5 rounded bg-slate-800/80 text-cyan-300 font-mono text-xs border border-slate-700/50"
          >
            {m[4]}
          </code>
        );
      } else if (m[6]) {
        // Italic
        tokens.push(
          <em key={m.index} className="italic text-slate-300">
            {m[6]}
          </em>
        );
      }
      lastPos = m.index + m[0].length;
    }

    if (lastPos < str.length) {
      tokens.push(str.slice(lastPos));
    }

    return tokens.length > 0 ? tokens : str;
  };

  return (
    <div className="space-y-1 text-sm sm:text-base">
      {parts.map((part, idx) => {
        if (part.type === 'code') {
          const isCopied = copiedIndex === idx;
          return (
            <div
              key={idx}
              className="my-3 rounded-xl overflow-hidden border border-slate-700/60 bg-slate-900/90 shadow-xl"
            >
              <div className="flex items-center justify-between px-3.5 py-1.5 bg-slate-800/80 border-b border-slate-700/50 text-xs font-mono text-slate-400">
                <span className="uppercase font-semibold tracking-wider text-cyan-400">
                  {part.language || 'code'}
                </span>
                <button
                  onClick={() => handleCopy(part.content, idx)}
                  className="flex items-center gap-1.5 px-2 py-1 rounded bg-slate-700/50 hover:bg-slate-700 text-slate-200 hover:text-white transition cursor-pointer text-xs"
                  title="Copy code"
                >
                  {isCopied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400 font-sans">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span className="font-sans">Copy</span>
                    </>
                  )}
                </button>
              </div>
              <pre className="p-3.5 text-xs sm:text-sm font-mono overflow-x-auto text-emerald-300 leading-relaxed selection:bg-cyan-500/30">
                <code>{part.content.trim()}</code>
              </pre>
            </div>
          );
        }

        return <div key={idx}>{renderInlineMarkdown(part.content)}</div>;
      })}
    </div>
  );
};
