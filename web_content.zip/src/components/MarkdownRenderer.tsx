import React, { useState } from 'react';
import katex from 'katex';
import { Copy, Check } from 'lucide-react';

interface MarkdownRendererProps {
  content: string;
}

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  // Render LaTeX safely
  const renderLatex = (text: string): string => {
    // Replace block math $$...$$
    let formatted = text.replace(/\$\$([\s\S]*?)\$\$/g, (_, equation) => {
      try {
        return `<div class="my-2.5 overflow-x-auto py-1 text-center font-serif">${katex.renderToString(
          equation.trim(),
          { displayMode: true, throwOnError: false }
        )}</div>`;
      } catch (e) {
        return `<div class="text-rose-500 font-mono text-xs my-1">${equation}</div>`;
      }
    });

    // Replace inline math $...$
    // Ensure we don't accidentally match currency e.g. $50 or $$
    formatted = formatted.replace(/(?<!\$)\$(?!\$)(\S(?:.*?\S)?)\$(?!\$)/g, (_, equation) => {
      try {
        return `<span class="inline-latex font-serif px-0.5">${katex.renderToString(
          equation.trim(),
          { displayMode: false, throwOnError: false }
        )}</span>`;
      } catch (e) {
        return `<span class="text-rose-500 font-mono text-xs">${equation}</span>`;
      }
    });

    return formatted;
  };

  // Split content into code blocks and normal markdown segments
  const parseBlocks = (raw: string) => {
    const parts: Array<{ type: 'code' | 'text'; content: string; language?: string }> = [];
    const codeBlockRegex = /```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g;
    let lastIndex = 0;
    let match;

    while ((match = codeBlockRegex.exec(raw)) !== null) {
      if (match.index > lastIndex) {
        parts.push({
          type: 'text',
          content: raw.substring(lastIndex, match.index),
        });
      }
      parts.push({
        type: 'code',
        language: match[1] || 'text',
        content: match[2],
      });
      lastIndex = match.index + match[0].length;
    }

    if (lastIndex < raw.length) {
      parts.push({
        type: 'text',
        content: raw.substring(lastIndex),
      });
    }

    return parts;
  };

  const blocks = parseBlocks(content);

  return (
    <div className="markdown-content text-slate-800 leading-relaxed text-[15px] space-y-3">
      {blocks.map((block, idx) => {
        if (block.type === 'code') {
          return <CodeBlock key={idx} language={block.language || 'text'} code={block.content} />;
        }

        return <TextSegment key={idx} text={renderLatex(block.content)} />;
      })}
    </div>
  );
};

const CodeBlock: React.FC<{ language: string; code: string }> = ({ language, code }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="relative my-3 rounded-xl border border-slate-200 bg-slate-900 text-slate-100 overflow-hidden text-xs shadow-sm">
      <div className="flex items-center justify-between px-3.5 py-1.5 bg-slate-800/80 border-b border-slate-700/60 text-slate-400 font-mono">
        <span className="text-[11px] font-medium uppercase tracking-wider text-slate-300">
          {language}
        </span>
        <button
          onClick={handleCopy}
          aria-label="Copy code block"
          className="flex items-center space-x-1.5 px-2 py-0.5 rounded hover:bg-slate-700 text-slate-300 transition"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-[11px] text-emerald-400">Copied</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span className="text-[11px]">Copy</span>
            </>
          )}
        </button>
      </div>
      <pre className="p-3.5 overflow-x-auto font-mono text-[13px] leading-relaxed selection:bg-slate-700">
        <code>{code.trimEnd()}</code>
      </pre>
    </div>
  );
};

const TextSegment: React.FC<{ text: string }> = ({ text }) => {
  // Parse simple markdown headings, lists, bold, italics, blockquotes
  const lines = text.split('\n');
  const elements: React.ReactNode[] = [];

  let currentList: string[] = [];
  let isNumberedList = false;

  const flushList = () => {
    if (currentList.length > 0) {
      if (isNumberedList) {
        elements.push(
          <ol key={`ol-${elements.length}`} className="list-decimal list-outside ml-5 space-y-1 my-2 text-slate-700">
            {currentList.map((item, i) => (
              <li key={i} dangerouslySetInnerHTML={{ __html: item }} />
            ))}
          </ol>
        );
      } else {
        elements.push(
          <ul key={`ul-${elements.length}`} className="list-disc list-outside ml-5 space-y-1 my-2 text-slate-700">
            {currentList.map((item, i) => (
              <li key={i} dangerouslySetInnerHTML={{ __html: item }} />
            ))}
          </ul>
        );
      }
      currentList = [];
    }
  };

  const formatInline = (str: string): string => {
    return str
      // Bold
      .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-slate-900">$1</strong>')
      // Italic
      .replace(/\*(.*?)\*/g, '<em class="italic text-slate-800">$1</em>')
      // Inline backtick code
      .replace(/`([^`]+)`/g, '<code class="px-1.5 py-0.5 rounded bg-slate-100 border border-slate-200 font-mono text-xs text-indigo-700">$1</code>');
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();

    if (!trimmed) {
      flushList();
      continue;
    }

    // Headings
    if (trimmed.startsWith('### ')) {
      flushList();
      elements.push(
        <h4 key={`h4-${i}`} className="text-base font-semibold text-slate-900 mt-3 mb-1" dangerouslySetInnerHTML={{ __html: formatInline(trimmed.substring(4)) }} />
      );
      continue;
    }
    if (trimmed.startsWith('## ')) {
      flushList();
      elements.push(
        <h3 key={`h3-${i}`} className="text-lg font-bold text-slate-900 mt-4 mb-1.5 pb-1 border-b border-slate-100" dangerouslySetInnerHTML={{ __html: formatInline(trimmed.substring(3)) }} />
      );
      continue;
    }
    if (trimmed.startsWith('# ')) {
      flushList();
      elements.push(
        <h2 key={`h2-${i}`} className="text-xl font-bold text-slate-900 mt-4 mb-2" dangerouslySetInnerHTML={{ __html: formatInline(trimmed.substring(2)) }} />
      );
      continue;
    }

    // Blockquote
    if (trimmed.startsWith('> ')) {
      flushList();
      elements.push(
        <blockquote key={`bq-${i}`} className="border-l-4 border-indigo-400 bg-indigo-50/40 pl-3.5 py-1.5 my-2 text-slate-700 italic rounded-r" dangerouslySetInnerHTML={{ __html: formatInline(trimmed.substring(2)) }} />
      );
      continue;
    }

    // Bullet lists
    const bulletMatch = trimmed.match(/^[-*]\s+(.*)$/);
    if (bulletMatch) {
      if (isNumberedList) flushList();
      isNumberedList = false;
      currentList.push(formatInline(bulletMatch[1]));
      continue;
    }

    // Numbered lists
    const numberMatch = trimmed.match(/^(\d+)\.\s+(.*)$/);
    if (numberMatch) {
      if (!isNumberedList) flushList();
      isNumberedList = true;
      currentList.push(formatInline(numberMatch[2]));
      continue;
    }

    // Regular paragraph
    flushList();
    elements.push(
      <p key={`p-${i}`} className="my-1.5 leading-relaxed text-slate-700" dangerouslySetInnerHTML={{ __html: formatInline(line) }} />
    );
  }

  flushList();

  return <>{elements}</>;
};
