"use client";

/* eslint-disable @next/next/no-img-element */
import Link from "next/link";
import type { Attraction } from "@/db/schema";
import { CATEGORIES, COUNTRIES } from "@/lib/data";
import { useLang } from "@/lib/i18n";

export default function AttractionCard({ a }: { a: Attraction }) {
  const { lang, t } = useLang();
  const country = COUNTRIES[a.countryCode];
  const cat = CATEGORIES[a.category];
  return (
    <Link
      href={`/attraction/${a.slug}`}
      className="group flex flex-col overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-200 transition hover:-translate-y-1 hover:shadow-xl"
    >
      <div className="relative aspect-[16/10] overflow-hidden bg-slate-200">
        <img
          src={a.image}
          alt={lang === "ar" ? a.nameAr : a.nameEn}
          loading="lazy"
          className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
        />
        <span className="absolute start-3 top-3 rounded-full bg-white/90 px-3 py-1 text-xs font-semibold text-slate-800 shadow">
          {cat?.icon} {cat?.[lang]}
        </span>
        <span className="absolute end-3 top-3 rounded-full bg-slate-900/80 px-2.5 py-1 text-xs font-semibold text-amber-300">
          ★ {a.rating.toFixed(1)}
        </span>
      </div>
      <div className="flex flex-1 flex-col gap-2 p-4">
        <div className="text-xs font-medium text-indigo-600">
          {country?.flag} {lang === "ar" ? a.cityAr : a.cityEn} · {country?.[lang]}
        </div>
        <h3 className="line-clamp-2 min-h-[2.8rem] text-base font-bold leading-snug text-slate-900">
          {lang === "ar" ? a.nameAr : a.nameEn}
        </h3>
        <div className="text-xs text-slate-500">
          ⏱ {a.durationMin} {t("minutes")} · {a.reviews.toLocaleString(lang === "ar" ? "ar-EG" : "en-US")} {t("reviews")}
        </div>
        <div className="mt-auto flex items-end justify-between pt-2">
          <span className="text-xs text-emerald-600">✓ {t("instant")}</span>
          <div className="text-end">
            <div className="text-[11px] text-slate-500">{t("from")}</div>
            <div className="text-xl font-extrabold text-slate-900">€{a.price}</div>
          </div>
        </div>
      </div>
    </Link>
  );
}
