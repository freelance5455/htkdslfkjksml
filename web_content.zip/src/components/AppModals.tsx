import React, { useState } from 'react';
import {
  X,
  Droplet,
  Bell,
  Share2,
  Star,
  CheckCircle2,
  Copy,
  Sparkles,
  BookOpen,
  PenTool,
  Download,
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { ChapterData, ALL_19_CHAPTER_TITLES, BIOLOGY_CHAPTERS } from '../data/biologyData';

// THEME MODAL
export const ThemeModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  currentTheme: 'teal' | 'sepia' | 'dark';
  onSelectTheme: (t: 'teal' | 'sepia' | 'dark') => void;
}> = ({ isOpen, onClose, currentTheme, onSelectTheme }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <Droplet className="w-5 h-5 text-teal-600 fill-teal-100" />
            <h3 className="text-base font-bold text-slate-900 font-devanagari">
              रीडिंग मोड एवं थीम
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-2.5 font-devanagari">
          <button
            onClick={() => {
              onSelectTheme('teal');
              onClose();
            }}
            className={`w-full p-3 rounded-xl border flex items-center justify-between transition-colors ${
              currentTheme === 'teal'
                ? 'bg-teal-50 border-teal-500 text-teal-950 font-bold'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-3">
              <span className="w-6 h-6 rounded-full bg-[#00838f] inline-block shadow-xs" />
              <div className="text-left">
                <p className="text-xs font-bold">क्लासिक टील (Teal Daylight)</p>
                <p className="text-[11px] text-slate-500">ऐप की मूल और स्पष्ट थीम</p>
              </div>
            </div>
            {currentTheme === 'teal' && <CheckCircle2 className="w-4 h-4 text-teal-600" />}
          </button>

          <button
            onClick={() => {
              onSelectTheme('sepia');
              onClose();
            }}
            className={`w-full p-3 rounded-xl border flex items-center justify-between transition-colors ${
              currentTheme === 'sepia'
                ? 'bg-amber-50 border-amber-500 text-amber-950 font-bold'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-3">
              <span className="w-6 h-6 rounded-full bg-[#f4ebd9] border border-amber-300 inline-block shadow-xs" />
              <div className="text-left">
                <p className="text-xs font-bold">आई-केयर सेपिया (Warm Sepia)</p>
                <p className="text-[11px] text-slate-500">आँखों के आराम के लिए पीला कागज़ मोड</p>
              </div>
            </div>
            {currentTheme === 'sepia' && <CheckCircle2 className="w-4 h-4 text-amber-600" />}
          </button>

          <button
            onClick={() => {
              onSelectTheme('dark');
              onClose();
            }}
            className={`w-full p-3 rounded-xl border flex items-center justify-between transition-colors ${
              currentTheme === 'dark'
                ? 'bg-slate-800 border-slate-600 text-white font-bold'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-3">
              <span className="w-6 h-6 rounded-full bg-slate-900 border border-slate-700 inline-block shadow-xs" />
              <div className="text-left">
                <p className="text-xs font-bold">डार्क नाइट मोड (Night Reading)</p>
                <p className="text-[11px] text-slate-500">रात में पढ़ाई के लिए उत्तम</p>
              </div>
            </div>
            {currentTheme === 'dark' && <CheckCircle2 className="w-4 h-4 text-sky-400" />}
          </button>
        </div>
      </div>
    </div>
  );
};

// NOTIFICATION MODAL
export const NotificationModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
}> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const notifications = [
    {
      id: 1,
      title: 'NCERT 2026-27 नवीनतम पाठ्यक्रम अपडेट',
      desc: 'कक्षा 11 जीव विज्ञान के सभी 19 अध्यायों के हिंदी नोट्स एवं MCQs अद्यतन किए गए हैं।',
      time: 'आज, सुबह 10:00 बजे',
      unread: true
    },
    {
      id: 2,
      title: 'हस्तलिखित नोट्स PDF अनलॉक हुए',
      desc: 'टॉपर्स की हस्तलिखित सचित्र नोटबुक अब सभी अध्यायों में पढ़ने हेतु तैयार है।',
      time: 'कल',
      unread: false
    },
    {
      id: 3,
      title: 'NEET 2026 बायोलॉजी टेस्ट सीरीज',
      desc: 'अध्यायवार MCQs क्विज देकर अपनी तैयारी की जांच करें।',
      time: '2 दिन पहले',
      unread: false
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-teal-600" />
            <h3 className="text-base font-bold text-slate-900 font-devanagari">
              सूचनाएँ एवं अलर्ट
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-2.5 max-h-80 overflow-y-auto font-devanagari">
          {notifications.map((n) => (
            <div key={n.id} className="p-3 rounded-xl border border-slate-200 bg-slate-50/60 space-y-1">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-900">{n.title}</h4>
                {n.unread && <span className="w-2 h-2 rounded-full bg-teal-500" />}
              </div>
              <p className="text-[11px] text-slate-600 leading-relaxed">{n.desc}</p>
              <span className="text-[10px] text-slate-400 block pt-0.5">{n.time}</span>
            </div>
          ))}
        </div>

        <button
          onClick={onClose}
          className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold font-devanagari"
        >
          बंद करें
        </button>
      </div>
    </div>
  );
};

// SHARE MODAL
export const ShareModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
}> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  if (!isOpen) return null;

  const appUrl = window.location.href;
  const shareText = "कक्षा 11 जीव विज्ञान के संपूर्ण हिंदी नोट्स, NCERT समाधान एवं MCQs इस ऐप से मुफ्त में पढ़ें!";

  const handleCopy = () => {
    navigator.clipboard.writeText(`${shareText}\n${appUrl}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const shareWhatsapp = () => {
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(`${shareText}\n${appUrl}`)}`, '_blank');
  };

  const shareTelegram = () => {
    window.open(`https://t.me/share/url?url=${encodeURIComponent(appUrl)}&text=${encodeURIComponent(shareText)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <Share2 className="w-5 h-5 text-teal-600" />
            <h3 className="text-base font-bold text-slate-900 font-devanagari">
              दोस्तों के साथ शेयर करें
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-slate-600 font-devanagari leading-relaxed">
          अपने सहपाठियों को यह ऐप भेजें ताकि वे भी हिंदी माध्यम में जीव विज्ञान की उत्तम तैयारी कर सकें।
        </p>

        <div className="grid grid-cols-2 gap-2.5 font-devanagari">
          <button
            onClick={shareWhatsapp}
            className="p-3 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <span>💬 WhatsApp</span>
          </button>

          <button
            onClick={shareTelegram}
            className="p-3 rounded-xl bg-sky-50 hover:bg-sky-100 border border-sky-200 text-sky-800 font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <span>✈️ Telegram</span>
          </button>
        </div>

        <div className="pt-2">
          <button
            onClick={handleCopy}
            className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors font-devanagari cursor-pointer"
          >
            <Copy className="w-4 h-4 text-slate-600" />
            <span>{copied ? '✅ लिंक कॉपी हो गया!' : 'ऐप लिंक कॉपी करें'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

// PREMIUM PASS MODAL
export const PremiumModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  isPremium: boolean;
  onTogglePremium: () => void;
}> = ({ isOpen, onClose, isPremium, onTogglePremium }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl space-y-4 text-center relative overflow-hidden">
        {/* Top Gold Gradient Glow */}
        <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-48 h-24 bg-amber-300/40 blur-2xl rounded-full pointer-events-none" />

        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1 rounded-full text-slate-400 hover:text-slate-600"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-600 flex items-center justify-center mx-auto shadow-inner">
          <Star className="w-7 h-7 fill-amber-500" />
        </div>

        <div>
          <h3 className="text-lg font-bold text-slate-900 font-devanagari">
            प्रीमियम जीव विज्ञान पास
          </h3>
          <p className="text-xs text-amber-700 font-semibold mt-0.5 font-devanagari">
            Remove Ads + Get Premium Content
          </p>
        </div>

        <div className="text-left space-y-2 text-xs font-devanagari text-slate-700 bg-amber-50/60 p-4 rounded-2xl border border-amber-200">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>100% विज्ञापन मुक्त (Ad-Free) अनुभव</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>सभी 19 अध्यायों के हस्तलिखित नोट्स PDF</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>NEET 15 वर्ष हल प्रश्न संग्रह</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>ऑफलाइन स्टडी मोड एवं प्रिंट सुविधा</span>
          </div>
        </div>

        <button
          onClick={() => {
            onTogglePremium();
            onClose();
          }}
          className="w-full py-3 bg-[#f9a825] hover:bg-[#f57f17] text-white font-bold rounded-xl text-sm transition-colors shadow-md font-devanagari cursor-pointer active:scale-95"
        >
          {isPremium ? 'प्रीमियम डी-एक्टिवेट करें' : '⭐ मुफ्त में एक्टिवेट करें (Demo Unlock)'}
        </button>

        <p className="text-[11px] text-slate-400">
          डेमो वर्जन में कोई शुल्क नहीं है। एक क्लिक में अनलॉक करें।
        </p>
      </div>
    </div>
  );
};

// CATEGORY CHAPTER SELECTOR MODAL
export const CategoryBrowserModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  category: 'premium_notes' | 'handwritten_notes' | 'ncert_book' | 'ncert_solutions' | 'video_classes' | 'mcq_pdf' | 'important_questions' | 'mind_maps' | null;
  onSelectChapterWithTab: (ch: ChapterData, subTab: any) => void;
  selectedClass: '11' | '12';
}> = ({ isOpen, onClose, category, onSelectChapterWithTab, selectedClass }) => {
  if (!isOpen || !category) return null;

  const categoryTitles = {
    premium_notes: { title: 'प्रीमियम नोट्स', subTab: 'premium', icon: '📝' },
    handwritten_notes: { title: 'हस्तलिखित नोट्स', subTab: 'handwritten', icon: '✍️' },
    ncert_book: { title: 'NCERT बुक (पाठ्यपुस्तक)', subTab: 'premium', icon: '📚' },
    ncert_solutions: { title: 'NCERT समाधान (अभ्यास प्रश्नोत्तर)', subTab: 'solutions', icon: '💡' },
    video_classes: { title: 'वीडियो कक्षाएँ', subTab: 'premium', icon: '🖥️' },
    mcq_pdf: { title: 'MCQs टेस्ट एवं पीडीएफ़', subTab: 'mcq', icon: '💬' },
    important_questions: { title: 'महत्वपूर्ण प्रश्नोत्तर', subTab: 'important', icon: '📋' },
    mind_maps: { title: 'माइंड मैप्स', subTab: 'mindmap', icon: '🧠' },
  }[category];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl max-w-md w-full p-5 shadow-2xl space-y-4 max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <span className="text-xl">{categoryTitles.icon}</span>
            <div>
              <h3 className="text-base font-bold text-slate-900 font-devanagari">
                {categoryTitles.title}
              </h3>
              <p className="text-[11px] text-slate-500">
                कक्षा {selectedClass} के सभी अध्याय चुनें
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Chapters list to open that resource */}
        <div className="flex-1 overflow-y-auto space-y-2 pr-1 font-devanagari">
          {ALL_19_CHAPTER_TITLES.map((ch) => {
            const richChapter =
              BIOLOGY_CHAPTERS.find((c) => c.chapterNumber === ch.no) || {
                ...BIOLOGY_CHAPTERS[0],
                id: ch.no,
                chapterNumber: ch.no,
                title: ch.title,
                englishTitle: ch.eng,
                unit: ch.unit,
              };

            return (
              <button
                key={ch.no}
                onClick={() => {
                  onSelectChapterWithTab(richChapter, categoryTitles.subTab);
                  onClose();
                }}
                className="w-full p-3 rounded-xl border border-slate-200 bg-white hover:bg-teal-50/60 hover:border-teal-300 text-left transition-colors flex items-center justify-between group cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <span className="w-7 h-7 rounded-lg bg-teal-50 text-[#00838f] font-bold flex items-center justify-center text-xs shrink-0">
                    {ch.no}
                  </span>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 group-hover:text-teal-800 transition-colors">
                      {ch.title}
                    </h4>
                    <span className="text-[10px] text-slate-500">{ch.eng}</span>
                  </div>
                </div>

                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-teal-600" />
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
