import React, { useState } from 'react';
import { ShieldCheck, Lock, KeyRound, ArrowRight, X, ShieldAlert, Sparkles, Crown, Eye, EyeOff } from 'lucide-react';

interface LogoOwnerAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUnlocked: () => void;
}

export const LogoOwnerAuthModal: React.FC<LogoOwnerAuthModalProps> = ({
  isOpen,
  onClose,
  onUnlocked,
}) => {
  const [addressInput, setAddressInput] = useState<string>('');
  const [showAddress, setShowAddress] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleProceed = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    const authorizedAddress = 'https://12JM#12JM@JM-12';
    const input = addressInput.trim();

    if (input === authorizedAddress || input.toLowerCase() === authorizedAddress.toLowerCase()) {
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        navigator.vibrate([40, 60, 40]);
      }
      onUnlocked();
      onClose();
    } else {
      // Log unauthorized access attempt in secure local storage
      try {
        const attempt = {
          id: `ATTEMPT-${Date.now()}`,
          timestamp: new Date().toISOString(),
          gate: 'Prophet Logo Portal Gate',
          details: `Unauthorized attempt with invalid address input (${input.slice(0, 12)}...)`,
          ipNode: '127.0.0.1:3000',
          userAgent: typeof navigator !== 'undefined' ? navigator.userAgent.slice(0, 50) : 'Unknown',
          status: 'BLOCKED'
        };
        const logs = JSON.parse(localStorage.getItem('jm_owner_unauthorized_attempts_log') || '[]');
        logs.unshift(attempt);
        localStorage.setItem('jm_owner_unauthorized_attempts_log', JSON.stringify(logs.slice(0, 50)));
        window.dispatchEvent(new CustomEvent('jm_security_audit_updated'));
      } catch (err) {}

      setErrorMsg('Unauthorized Address: Invalid or unrecognized address. Access is strictly restricted to Prophet JUHNKRIX SYNVAGORD.');
    }
  };

  return (
    <div className="fixed inset-0 z-[300] bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-4 animate-fadeIn">
      <div className="max-w-md w-full bg-slate-950 border-2 border-amber-500/60 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-amber-500/20 text-left space-y-6 relative overflow-hidden">
        {/* Glow */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center justify-between border-b border-amber-500/20 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-slate-950 shadow-lg shadow-amber-500/30">
              <Crown className="w-6 h-6 text-slate-950" />
            </div>
            <div>
              <h3 className="text-base font-bold text-amber-100 font-serif">
                Prophet Sanctuary Portal
              </h3>
              <span className="text-[10px] text-amber-400 font-mono">Owner Authorization Gate</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-slate-900 text-slate-400 hover:text-white transition-colors"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs sm:text-sm text-slate-300 leading-relaxed">
          <p className="font-serif text-amber-200/90 bg-amber-500/10 p-4 rounded-2xl border border-amber-500/30">
            &ldquo;Only Prophet JUHNKRIX SYNVAGORD the owner of the JUHNKRIX MUSIKA APP is authorized to access this page, please provide the PROPHET JUHNKRIX AUTHORIZED address in the address box below and click on the &apos;proceed&apos; icon button.&rdquo;
          </p>

          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-950/80 border border-rose-500/50 text-rose-200 text-xs flex items-start space-x-2">
              <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          <form onSubmit={handleProceed} className="space-y-4 pt-2">
            <div>
              <label className="block text-[11px] font-mono text-amber-300 uppercase tracking-widest mb-1.5">
                Authorized Address
              </label>
              <div className="relative">
                <KeyRound className="absolute left-3.5 top-3.5 w-4 h-4 text-amber-400" />
                <input
                  type={showAddress ? 'text' : 'password'}
                  value={addressInput}
                  onChange={(e) => setAddressInput(e.target.value)}
                  placeholder="fill in or type in the Authorized Address"
                  className="w-full bg-slate-900 border border-amber-500/40 rounded-2xl py-3 pl-10 pr-11 text-amber-100 text-xs font-mono focus:outline-none focus:border-amber-400 shadow-inner"
                  required
                  autoComplete="off"
                  spellCheck="false"
                />
                <button
                  type="button"
                  onClick={() => setShowAddress(!showAddress)}
                  className="absolute right-3 top-3 text-slate-400 hover:text-amber-300 p-0.5 transition-colors"
                  title={showAddress ? 'Hide address' : 'Show address'}
                >
                  {showAddress ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs sm:text-sm flex items-center justify-center space-x-2 shadow-lg shadow-amber-500/30 transition-all hover:scale-[1.02]"
            >
              <span>Proceed to Owner Vault</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        </div>

        <div className="text-[10px] text-center text-slate-500 font-mono border-t border-slate-900 pt-3">
          🔒 Secured by JUHNKRIX End-to-End Cryptographic Protocol
        </div>
      </div>
    </div>
  );
};
