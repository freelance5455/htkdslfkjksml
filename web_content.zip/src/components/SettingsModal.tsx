/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { X, Volume2, Globe, Gauge, History, Trash2, Smartphone, ShieldCheck, Cpu, RefreshCw, Zap, CheckCircle2, AlertTriangle } from 'lucide-react';
import { AppSettings, LanguageCode, ServerStatusResponse } from '../types/assistant';
import { AIService, ConnectionTestResult } from '../services/aiService';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  onClearHistory: () => void;
  onOpenAndroidRoadmap: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onClearHistory,
  onOpenAndroidRoadmap,
}) => {
  const [serverStatus, setServerStatus] = useState<ServerStatusResponse | null>(null);
  const [isCheckingStatus, setIsCheckingStatus] = useState(false);
  const [clearedConfirm, setClearedConfirm] = useState(false);

  // Live Connection Test State
  const [isTestingConnection, setIsTestingConnection] = useState(false);
  const [testResult, setTestResult] = useState<ConnectionTestResult | null>(null);

  useEffect(() => {
    if (isOpen) {
      checkServer();
    }
  }, [isOpen]);

  const checkServer = async () => {
    setIsCheckingStatus(true);
    try {
      const res = await AIService.checkStatus();
      setServerStatus(res);
    } catch {
      setServerStatus({
        ok: false,
        geminiConfigured: false,
        model: 'gemini-3.8-flash',
        serverTime: new Date().toISOString(),
      });
    } finally {
      setIsCheckingStatus(false);
    }
  };

  const handleTestConnection = async () => {
    setIsTestingConnection(true);
    setTestResult(null);
    try {
      const result = await AIService.testConnection();
      setTestResult(result);
      if (result.ok) {
        checkServer();
      }
    } catch {
      setTestResult({
        ok: false,
        latencyMs: 0,
        model: 'gemini-3.8-flash',
        error: 'Unable to reach backend connection test service.',
      });
    } finally {
      setIsTestingConnection(false);
    }
  };

  const handleClearHistory = () => {
    onClearHistory();
    setClearedConfirm(true);
    setTimeout(() => setClearedConfirm(false), 2500);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border border-cyan-500/35 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-2 h-2 rounded-full bg-cyan-400" />
            <h2 className="text-sm sm:text-base font-orbitron font-bold text-slate-100 tracking-wider">
              ELYSIA SYSTEM CONFIG
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
            aria-label="Close settings"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5 text-xs text-slate-300 font-sans">
          {/* 1. Neural Link / AI Status & Live Test */}
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-orbitron text-xs text-cyan-400 font-semibold flex items-center gap-1.5">
                <Cpu className="w-4 h-4" />
                Gemini Neural Engine
              </span>
              <button
                onClick={checkServer}
                disabled={isCheckingStatus}
                className="text-slate-400 hover:text-cyan-400 transition-colors p-1"
                title="Refresh Status"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isCheckingStatus ? 'animate-spin text-cyan-400' : ''}`} />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400">
              <div className="p-2 rounded-xl bg-slate-900 border border-slate-800/80">
                <span className="text-slate-500 block">Link Status:</span>
                <span className={serverStatus?.geminiConfigured ? 'text-emerald-400 font-semibold' : 'text-amber-400 font-semibold'}>
                  {serverStatus?.geminiConfigured ? '● ACTIVE & READY' : '● KEY NEEDED'}
                </span>
              </div>
              <div className="p-2 rounded-xl bg-slate-900 border border-slate-800/80">
                <span className="text-slate-500 block">Active Model:</span>
                <span className="text-cyan-300 font-mono font-semibold">
                  {serverStatus?.model || 'gemini-3.8-flash'}
                </span>
              </div>
            </div>

            {/* Live Connection Test Button */}
            <div className="pt-1">
              <button
                type="button"
                onClick={handleTestConnection}
                disabled={isTestingConnection}
                className="w-full py-2 px-3 rounded-xl bg-cyan-950/40 hover:bg-cyan-900/50 border border-cyan-500/30 text-cyan-300 font-rajdhani font-semibold tracking-wider flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
              >
                <Zap className={`w-3.5 h-3.5 text-cyan-400 ${isTestingConnection ? 'animate-bounce' : ''}`} />
                {isTestingConnection ? 'Testing Gemini Round-Trip...' : 'Test AI Connection (Live Ping)'}
              </button>

              {testResult && (
                <div
                  className={`mt-2 p-2.5 rounded-xl border text-[11px] flex items-start gap-2 ${
                    testResult.ok
                      ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-200'
                      : 'bg-amber-950/30 border-amber-500/40 text-amber-200'
                  }`}
                >
                  {testResult.ok ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                  )}
                  <div className="space-y-0.5">
                    <div className="font-semibold">
                      {testResult.ok
                        ? `Connection Verified (${testResult.latencyMs}ms latency)`
                        : 'Connection Test Failed'}
                    </div>
                    {testResult.error && (
                      <p className="text-[10px] text-amber-300/90 leading-relaxed">
                        {testResult.error}
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>

            <p className="text-[10px] text-slate-500 pt-1 leading-relaxed">
              AI requests are routed via server endpoints. API keys are strictly stored on the server environment.
            </p>
          </div>

          {/* 2. Language Selection */}
          <div className="space-y-1.5">
            <label className="text-slate-300 font-semibold flex items-center gap-1.5 text-xs">
              <Globe className="w-4 h-4 text-cyan-400" />
              Assistant Primary Language
            </label>
            <div className="grid grid-cols-2 gap-2 pt-1">
              {[
                { code: 'en-US' as LanguageCode, label: 'English (US)' },
                { code: 'en-GB' as LanguageCode, label: 'English (UK)' },
                { code: 'bn-BD' as LanguageCode, label: 'Bengali (বাংলা)' },
                { code: 'hi-IN' as LanguageCode, label: 'Hindi (हिंदी)' },
              ].map((lang) => (
                <button
                  key={lang.code}
                  type="button"
                  onClick={() => onUpdateSettings({ preferredLanguage: lang.code })}
                  className={`p-2.5 rounded-xl text-left border transition-all text-xs ${
                    settings.preferredLanguage === lang.code
                      ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200 font-semibold'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {lang.label}
                </button>
              ))}
            </div>
          </div>

          {/* 3. Voice Output & Speed */}
          <div className="space-y-3 p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <div className="flex items-center justify-between">
              <label className="text-slate-300 font-semibold flex items-center gap-1.5 text-xs">
                <Volume2 className="w-4 h-4 text-cyan-400" />
                Speech Synthesis Output
              </label>
              <input
                type="checkbox"
                checked={settings.voiceOutputEnabled}
                onChange={(e) => onUpdateSettings({ voiceOutputEnabled: e.target.checked })}
                className="w-4 h-4 accent-cyan-400 cursor-pointer"
              />
            </div>

            {settings.voiceOutputEnabled && (
              <div className="space-y-1.5 pt-1 border-t border-slate-800/80">
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span className="flex items-center gap-1">
                    <Gauge className="w-3.5 h-3.5" />
                    Speech Rate
                  </span>
                  <span className="font-mono text-cyan-300">{settings.speechRate.toFixed(2)}x</span>
                </div>
                <input
                  type="range"
                  min="0.75"
                  max="1.5"
                  step="0.05"
                  value={settings.speechRate}
                  onChange={(e) => onUpdateSettings({ speechRate: parseFloat(e.target.value) })}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>
            )}
          </div>

          {/* 4. Conversation History & Privacy */}
          <div className="space-y-3 p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <div className="flex items-center justify-between">
              <label className="text-slate-300 font-semibold flex items-center gap-1.5 text-xs">
                <History className="w-4 h-4 text-cyan-400" />
                Local Conversation Memory
              </label>
              <input
                type="checkbox"
                checked={settings.historyEnabled}
                onChange={(e) => onUpdateSettings({ historyEnabled: e.target.checked })}
                className="w-4 h-4 accent-cyan-400 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between pt-1">
              <span className="text-[11px] text-slate-400">Clear stored session history</span>
              <button
                type="button"
                onClick={handleClearHistory}
                className="px-3 py-1.5 rounded-lg bg-red-950/40 hover:bg-red-900/50 text-red-300 border border-red-800/50 text-[11px] font-semibold flex items-center gap-1 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                {clearedConfirm ? 'Cleared!' : 'Clear Now'}
              </button>
            </div>

            <p className="text-[10px] text-slate-500 pt-1 border-t border-slate-800/80 leading-relaxed">
              🔒 Privacy Note: Conversation records are kept strictly inside your local browser memory. No sensitive credentials or cross-device profiling are stored.
            </p>
          </div>

          {/* 5. Android APK Packaging Guide Trigger */}
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenAndroidRoadmap();
            }}
            className="w-full p-3 rounded-2xl bg-cyan-950/30 hover:bg-cyan-950/50 border border-cyan-500/40 text-cyan-300 text-xs font-semibold flex items-center justify-between transition-colors active:scale-98"
          >
            <span className="flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-cyan-400" />
              Android APK Roadmap & Packaging Guide
            </span>
            <span className="text-[11px] text-cyan-400 font-orbitron">VIEW &rarr;</span>
          </button>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between text-[11px] text-slate-500">
          <span className="flex items-center gap-1 font-orbitron">
            <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
            ELYSIA v1.0.0
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
