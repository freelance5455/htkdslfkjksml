import React, { useState } from 'react';
import { AssistantSettings, ApiStatus } from '../types/jarvis';
import {
  X,
  Volume2,
  Mic,
  Key,
  Smartphone,
  Sliders,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Play,
  RotateCcw,
} from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AssistantSettings;
  onUpdateSettings: (newSettings: Partial<AssistantSettings>) => void;
  apiStatus: ApiStatus | null;
  availableVoices: SpeechSynthesisVoice[];
  onTestVoice: () => void;
  onCheckPermissions: () => void;
  micPermissionStatus: 'prompt' | 'granted' | 'denied' | 'unsupported';
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  apiStatus,
  availableVoices,
  onTestVoice,
  onCheckPermissions,
  micPermissionStatus,
}) => {
  const [activeTab, setActiveTab] = useState<'voice' | 'language' | 'system' | 'guide'>('voice');

  if (!isOpen) return null;

  const languages = [
    { code: 'auto', name: 'Auto-detect (Matches your speech)' },
    { code: 'en', name: 'English (Refined British / US)' },
    { code: 'bn', name: 'Bengali / বাংলা (বাংলাদেশ ও ভারত)' },
    { code: 'hi', name: 'Hindi / हिन्दी' },
    { code: 'es', name: 'Spanish / Español' },
    { code: 'fr', name: 'French / Français' },
    { code: 'ar', name: 'Arabic / العربية' },
    { code: 'de', name: 'German / Deutsch' },
    { code: 'ja', name: 'Japanese / 日本語' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-fade-in select-none">
      <div className="bg-slate-950 border border-cyan-500/40 rounded-3xl w-full max-w-lg max-h-[90vh] flex flex-col shadow-2xl shadow-cyan-950/60 overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 border-b border-cyan-500/20 bg-slate-900/60 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-cyan-400" />
            <h3 className="text-base font-bold font-tech text-cyan-300 tracking-wider">
              JARVIS PROTOCOLS & CONFIG
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-cyan-950/40 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-cyan-500/15 bg-slate-900/30 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('voice')}
            className={`flex-1 py-2.5 px-3 text-xs font-mono font-medium transition-colors border-b-2 flex items-center justify-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'voice'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-950/30'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span>VOICE & TTS</span>
          </button>

          <button
            onClick={() => setActiveTab('language')}
            className={`flex-1 py-2.5 px-3 text-xs font-mono font-medium transition-colors border-b-2 flex items-center justify-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'language'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-950/30'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>LANGUAGE</span>
          </button>

          <button
            onClick={() => setActiveTab('system')}
            className={`flex-1 py-2.5 px-3 text-xs font-mono font-medium transition-colors border-b-2 flex items-center justify-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'system'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-950/30'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Key className="w-3.5 h-3.5" />
            <span>API & MIC</span>
          </button>

          <button
            onClick={() => setActiveTab('guide')}
            className={`flex-1 py-2.5 px-3 text-xs font-mono font-medium transition-colors border-b-2 flex items-center justify-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'guide'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-950/30'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>SETUP GUIDE</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5 text-sm">
          {/* TAB 1: VOICE & TTS */}
          {activeTab === 'voice' && (
            <div className="space-y-4">
              {/* Voice Output Toggle */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-900/60 border border-cyan-500/20">
                <div>
                  <p className="font-semibold text-slate-200 text-sm">Vocal Response (TTS)</p>
                  <p className="text-xs text-slate-400">Speak JARVIS replies aloud</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.voiceEnabled}
                    onChange={(e) => onUpdateSettings({ voiceEnabled: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500"></div>
                </label>
              </div>

              {/* Auto Speak Toggle */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-900/60 border border-cyan-500/20">
                <div>
                  <p className="font-semibold text-slate-200 text-sm">Auto-Speak on Response</p>
                  <p className="text-xs text-slate-400">Immediately vocalize once reply arrives</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.autoSpeak}
                    onChange={(e) => onUpdateSettings({ autoSpeak: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500"></div>
                </label>
              </div>

              {/* Voice Barge-In Toggle */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-900/60 border border-cyan-500/20">
                <div>
                  <p className="font-semibold text-slate-200 text-sm">Interrupt with Voice (Barge-In)</p>
                  <p className="text-xs text-slate-400">Speak or say "Stop" / "Jarvis" to interrupt speaking</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.voiceBargeIn}
                    onChange={(e) => onUpdateSettings({ voiceBargeIn: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500"></div>
                </label>
              </div>

              {/* Voice Selector */}
              <div className="space-y-1.5">
                <label className="text-xs font-mono text-cyan-300 uppercase">
                  Synthesized Voice Selection (Female preferred)
                </label>
                <div className="flex gap-2">
                  <select
                    value={settings.selectedVoiceURI}
                    onChange={(e) => onUpdateSettings({ selectedVoiceURI: e.target.value })}
                    className="flex-1 bg-slate-900 border border-cyan-500/30 rounded-xl px-3 py-2 text-xs text-cyan-100 focus:outline-none focus:border-cyan-400"
                  >
                    <option value="">Default Recommended (Auto Natural Female)</option>
                    {availableVoices.map((voice) => (
                      <option key={voice.voiceURI} value={voice.voiceURI}>
                        {voice.name} ({voice.lang})
                      </option>
                    ))}
                  </select>
                  <button
                    onClick={onTestVoice}
                    title="Test Voice"
                    className="px-3 py-2 rounded-xl bg-cyan-900/50 hover:bg-cyan-800/60 text-cyan-200 border border-cyan-500/30 text-xs flex items-center gap-1 shrink-0 transition-colors cursor-pointer"
                  >
                    <Play className="w-3 h-3 fill-current" />
                    <span>Test</span>
                  </button>
                </div>
              </div>

              {/* Speed Rate Slider */}
              <div className="space-y-1.5 p-3 rounded-2xl bg-slate-900/40 border border-cyan-500/15">
                <div className="flex justify-between text-xs">
                  <span className="font-mono text-cyan-300">Speech Rate</span>
                  <span className="font-mono text-slate-300">{settings.speechRate.toFixed(2)}x</span>
                </div>
                <input
                  type="range"
                  min="0.75"
                  max="1.5"
                  step="0.05"
                  value={settings.speechRate}
                  onChange={(e) =>
                    onUpdateSettings({ speechRate: parseFloat(e.target.value) })
                  }
                  className="w-full accent-cyan-400"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                  <span>Slow</span>
                  <span>Normal</span>
                  <span>Fast</span>
                </div>
              </div>

              {/* Pitch Slider */}
              <div className="space-y-1.5 p-3 rounded-2xl bg-slate-900/40 border border-cyan-500/15">
                <div className="flex justify-between text-xs">
                  <span className="font-mono text-cyan-300">Speech Pitch</span>
                  <span className="font-mono text-slate-300">{settings.speechPitch.toFixed(2)}x</span>
                </div>
                <input
                  type="range"
                  min="0.8"
                  max="1.3"
                  step="0.05"
                  value={settings.speechPitch}
                  onChange={(e) =>
                    onUpdateSettings({ speechPitch: parseFloat(e.target.value) })
                  }
                  className="w-full accent-cyan-400"
                />
              </div>

              {/* Reset to defaults */}
              <button
                onClick={() =>
                  onUpdateSettings({
                    speechRate: 1.05,
                    speechPitch: 1.0,
                    selectedVoiceURI: '',
                  })
                }
                className="text-xs text-slate-400 hover:text-cyan-300 flex items-center gap-1 font-mono transition-colors"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset Speech Parameters</span>
              </button>
            </div>
          )}

          {/* TAB 2: LANGUAGE */}
          {activeTab === 'language' && (
            <div className="space-y-4">
              <div className="p-3 rounded-2xl bg-cyan-950/30 border border-cyan-500/30 text-xs text-cyan-200">
                JARVIS speaks and understands multilingual speech including authentic
                Bengali (বাংলা) and English. Choose a preset or keep Auto-detect.
              </div>

              <div className="space-y-2">
                <label className="text-xs font-mono text-cyan-300 uppercase">
                  Assistant Language Mode
                </label>
                <div className="grid grid-cols-1 gap-2">
                  {languages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => onUpdateSettings({ language: lang.code })}
                      className={`p-3 rounded-2xl border text-left transition-all flex items-center justify-between cursor-pointer ${
                        settings.language === lang.code
                          ? 'border-cyan-400 bg-cyan-950/60 text-cyan-100 shadow-md shadow-cyan-950/50'
                          : 'border-slate-800 bg-slate-900/40 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <span className="font-medium text-xs sm:text-sm">{lang.name}</span>
                      {settings.language === lang.code && (
                        <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* User Salutation */}
              <div className="pt-2 space-y-1.5">
                <label className="text-xs font-mono text-cyan-300 uppercase">
                  How should JARVIS address you?
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {['Sir', 'Boss', 'Commander'].map((title) => (
                    <button
                      key={title}
                      onClick={() => onUpdateSettings({ userTitle: title })}
                      className={`py-2 rounded-xl text-xs font-mono border transition-colors cursor-pointer ${
                        settings.userTitle === title
                          ? 'border-cyan-400 bg-cyan-950/60 text-cyan-200'
                          : 'border-slate-800 bg-slate-900/40 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {title}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: API & HARDWARE STATUS */}
          {activeTab === 'system' && (
            <div className="space-y-4">
              {/* API Key Status Card */}
              <div
                className={`p-4 rounded-2xl border ${
                  apiStatus?.configured
                    ? 'border-emerald-500/40 bg-emerald-950/20'
                    : 'border-amber-500/40 bg-amber-950/20'
                }`}
              >
                <div className="flex items-start gap-3">
                  {apiStatus?.configured ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  )}
                  <div>
                    <h4 className="text-sm font-bold text-slate-100">
                      {apiStatus?.configured
                        ? 'Gemini Intelligence Online'
                        : 'Gemini API Key Required'}
                    </h4>
                    <p className="text-xs text-slate-300 mt-1">
                      {apiStatus?.configured
                        ? `Operational on ${apiStatus.model} via secure server-side endpoint.`
                        : 'Please configure GEMINI_API_KEY in your AI Studio Secrets or environment.'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Microphone Permission Card */}
              <div className="p-4 rounded-2xl border border-cyan-500/30 bg-slate-900/40">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <Mic className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-bold text-slate-100">
                        Speech Recognition Sensor
                      </h4>
                      <p className="text-xs text-slate-400 mt-1">
                        Status:{' '}
                        <span className="font-mono text-cyan-300 uppercase">
                          {micPermissionStatus}
                        </span>
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={onCheckPermissions}
                    className="px-3 py-1.5 rounded-xl bg-cyan-900/50 hover:bg-cyan-800/60 text-cyan-200 border border-cyan-500/30 text-xs font-mono transition-colors cursor-pointer"
                  >
                    Test Sensor
                  </button>
                </div>
              </div>

              {/* Audio Effects & Haptics Toggles */}
              <div className="space-y-2 pt-1">
                <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-900/60 border border-cyan-500/20">
                  <div>
                    <p className="font-semibold text-slate-200 text-sm">Futuristic Sound Effects</p>
                    <p className="text-xs text-slate-400">Tactical HUD chime on speech and boot</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.soundEffects}
                      onChange={(e) => onUpdateSettings({ soundEffects: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-900/60 border border-cyan-500/20">
                  <div>
                    <p className="font-semibold text-slate-200 text-sm">Haptic Feedback</p>
                    <p className="text-xs text-slate-400">Vibrate on microphone activation (Android)</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.hapticFeedback}
                      onChange={(e) => onUpdateSettings({ hapticFeedback: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500"></div>
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: SETUP GUIDE */}
          {activeTab === 'guide' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-cyan-950/40 border border-cyan-500/40">
                <h4 className="font-tech text-cyan-300 font-bold mb-1.5 flex items-center gap-1.5 text-sm">
                  <Volume2 className="w-4 h-4 text-cyan-400" />
                  1. HANDS-FREE WAKE WORD, BARGE-IN & CONVERSATION
                </h4>
                <ul className="list-disc list-inside space-y-1.5 text-slate-300 ml-1">
                  <li>
                    <strong>Wake Word:</strong> Say <span className="text-cyan-300 font-mono">"Jarvis"</span>, <span className="text-cyan-300 font-mono">"Hey Jarvis"</span>, or in Bangla <span className="text-cyan-300 font-mono">"জার্ভিস"</span> to wake the assistant. Listening opens immediately without delays.
                  </li>
                  <li>
                    <strong>Instant Command:</strong> You can wake up and give orders in one breath (e.g. <em>"Jarvis, what is today's date?"</em> or <em>"জার্ভিস, আজকের তারিখ কত?"</em>).
                  </li>
                  <li>
                    <strong>Interrupt While Speaking (Barge-In):</strong> If JARVIS is speaking aloud, you can interrupt at any moment by speaking (e.g. saying <em>"Stop"</em>, <em>"Stop now"</em>, <em>"Jarvis"</em>, or in Bangla <em>"এখন থামো"</em>, <em>"থামো"</em>, <em>"শোনো"</em>) or by tapping the Arc Reactor. Vocalization stops instantly and JARVIS listens to your new command.
                  </li>
                  <li>
                    <strong>Echo Cancellation:</strong> Built-in echo detection prevents the assistant from mistaking its own speaker audio for your commands, allowing seamless speech interruption.
                  </li>
                  <li>
                    <strong>Continuous Listening:</strong> Speak naturally with pauses between sentences. JARVIS does not cut you off after 3 seconds.
                  </li>
                  <li>
                    <strong>Stop / Sleep:</strong> Say <span className="text-amber-300 font-mono">"Stop now"</span>, <span className="text-amber-300 font-mono">"Go to sleep"</span>, <span className="text-amber-300 font-mono">"Jarvis sleep"</span>, or in Bangla <span className="text-amber-300 font-mono">"এখন থামো"</span> / <span className="text-amber-300 font-mono">"ঘুমাও"</span> to enter sleeping standby.
                  </li>
                </ul>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-cyan-500/30">
                <h4 className="font-tech text-cyan-300 font-bold mb-1.5 flex items-center gap-1.5 text-sm">
                  <Smartphone className="w-4 h-4 text-cyan-400" />
                  2. ANDROID CHROME PERMISSIONS & HONEST LIMITATIONS
                </h4>
                <ul className="list-disc list-inside space-y-1.5 text-slate-300 ml-1">
                  <li>
                    <strong>In-App Navigation:</strong> Navigating inside JARVIS (opening Settings, viewing logs, or expanding text input) keeps speech recognition active without interruption.
                  </li>
                  <li>
                    <strong>Tab Switching / App Minimizing:</strong> When you switch tabs or minimize Chrome, the browser automatically pauses recognition to preserve battery and privacy. Returning to the tab automatically resumes listening without requiring you to refresh.
                  </li>
                  <li>
                    <strong>Screen Locked Limitation:</strong> Standard web applications running in Chrome cannot access the microphone when the phone screen is locked or while another app is in the foreground. True 24/7 locked-screen wake word listening requires a native Android app (APK) using a persistent Android Foreground Service.
                  </li>
                  <li>
                    <strong>Microphone Permission:</strong> If Chrome blocks access, tap the <strong>lock/tune icon</strong> beside the URL bar &gt; <strong>Permissions</strong> &gt; set <strong>Microphone</strong> to <strong>Allow</strong>.
                  </li>
                </ul>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-cyan-500/30">
                <h4 className="font-tech text-cyan-300 font-bold mb-1.5 flex items-center gap-1.5 text-sm">
                  <Key className="w-4 h-4 text-cyan-400" />
                  3. GEMINI API KEY & REAL AI BACKEND
                </h4>
                <p className="mb-2">
                  All AI reasoning takes place securely on the backend server using Gemini models:
                </p>
                <ul className="list-disc list-inside space-y-1 text-slate-300 ml-1">
                  <li>Open the AI Studio side panel &gt; <strong>Secrets</strong>.</li>
                  <li>
                    Ensure <code className="text-cyan-300 font-mono">GEMINI_API_KEY</code> is configured.
                  </li>
                  <li>
                    The backend queries <strong className="text-cyan-200">gemini-3.1-flash-lite</strong> with automatic resilience and dynamic Asia/Dhaka runtime clock injection.
                  </li>
                </ul>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3.5 border-t border-cyan-500/20 bg-slate-950 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-tech font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
          >
            DISMISS CONFIG
          </button>
        </div>
      </div>
    </div>
  );
};
