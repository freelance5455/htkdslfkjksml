import React, { useState } from "react";
import { UiCustomizationSettings } from "../types";
import { sound } from "../audio";
import {
  X,
  Settings,
  Sliders,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  Sparkles,
  MapPin,
  BookOpen,
  HelpCircle,
  Smartphone,
  Eye,
  Check,
  Zap,
  ArrowBigUp,
  RotateCcw,
} from "lucide-react";

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: UiCustomizationSettings;
  onUpdateSettings: React.Dispatch<React.SetStateAction<UiCustomizationSettings>>;
  isLandscape: boolean;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenLand: () => void;
  onOpenScience: () => void;
  onOpenHelp: () => void;
  onOpenAwards: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  isLandscape,
  isFullscreen,
  onToggleFullscreen,
  isMuted,
  onToggleMute,
  onOpenLand,
  onOpenScience,
  onOpenHelp,
  onOpenAwards,
}) => {
  const [activeTab, setActiveTab] = useState<"ui" | "audio" | "features" | "controls">("ui");

  if (!isOpen) return null;

  const updateSetting = <K extends keyof UiCustomizationSettings>(
    key: K,
    value: UiCustomizationSettings[K]
  ) => {
    sound.playCoin();
    onUpdateSettings((prev) => ({ ...prev, [key]: value }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-3 select-none">
      <div className="relative w-full max-w-2xl bg-stone-900 border-2 border-stone-600 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-stone-950 via-stone-900 to-stone-950 p-3 sm:p-4 border-b border-stone-700/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-stone-800 border border-stone-600 flex items-center justify-center text-amber-400 shadow">
              <Settings className="w-5 h-5 animate-spin-slow" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-stone-100 font-['Hind_Siliguri']">
                গেম সেটিংস ও কন্ট্রোল (Game Settings)
              </h2>
              <p className="text-[11px] text-stone-400">
                Configure UI scaling, landscape layout, audio &amp; shortcuts
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-stone-800 text-stone-400 hover:text-white hover:bg-stone-700 cursor-pointer transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center bg-stone-950 border-b border-stone-800 text-xs font-bold">
          <button
            onClick={() => setActiveTab("ui")}
            className={`flex-1 py-2.5 flex items-center justify-center gap-1.5 cursor-pointer transition border-b-2 ${
              activeTab === "ui"
                ? "border-amber-400 text-amber-300 bg-stone-900/80"
                : "border-transparent text-stone-400 hover:text-stone-200"
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>UI ও ল্যান্ডস্কেপ</span>
          </button>
          <button
            onClick={() => setActiveTab("audio")}
            className={`flex-1 py-2.5 flex items-center justify-center gap-1.5 cursor-pointer transition border-b-2 ${
              activeTab === "audio"
                ? "border-amber-400 text-amber-300 bg-stone-900/80"
                : "border-transparent text-stone-400 hover:text-stone-200"
            }`}
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span>শব্দ ও ডিসপ্লে</span>
          </button>
          <button
            onClick={() => setActiveTab("features")}
            className={`flex-1 py-2.5 flex items-center justify-center gap-1.5 cursor-pointer transition border-b-2 ${
              activeTab === "features"
                ? "border-amber-400 text-amber-300 bg-stone-900/80"
                : "border-transparent text-stone-400 hover:text-stone-200"
            }`}
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>গ্রাম ও বৈজ্ঞানিক জার্নাল</span>
          </button>
          <button
            onClick={() => setActiveTab("controls")}
            className={`flex-1 py-2.5 flex items-center justify-center gap-1.5 cursor-pointer transition border-b-2 ${
              activeTab === "controls"
                ? "border-amber-400 text-amber-300 bg-stone-900/80"
                : "border-transparent text-stone-400 hover:text-stone-200"
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>কিবোর্ড গাইড</span>
          </button>
        </div>

        {/* Tab 1: UI & Landscape Settings */}
        {activeTab === "ui" && (
          <div className="p-4 overflow-y-auto space-y-4 text-xs flex-1">
            {/* Auto Landscape small */}
            <div className="p-3 bg-stone-950/70 rounded-xl border border-stone-800 flex items-center justify-between">
              <div>
                <span className="font-bold text-stone-200 block text-sm font-['Hind_Siliguri']">
                  ল্যান্ডস্কেপে স্বয়ংক্রিয় স্লিম UI (Auto-shrink in Landscape)
                </span>
                <p className="text-stone-400 text-[11px] mt-0.5">
                  ল্যান্ডস্কেপ মোডে গেলে কন্ট্রোলার ও হটবার নিজে থেকেই কম্প্যাক্ট হয়ে পূর্ণ স্ক্রিন উন্মুক্ত রাখবে।
                </p>
              </div>
              <button
                onClick={() =>
                  updateSetting("autoLandscapeSmall", !settings.autoLandscapeSmall)
                }
                className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                  settings.autoLandscapeSmall ? "bg-emerald-600" : "bg-stone-700"
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform absolute top-0.5 ${
                    settings.autoLandscapeSmall ? "right-0.5" : "left-0.5"
                  }`}
                />
              </button>
            </div>

            {/* Controller Size */}
            <div className="space-y-1.5">
              <label className="font-bold text-stone-300 block text-xs">
                ভার্চুয়াল টাচ কন্ট্রোলার সাইজ (Virtual Controller Size):
              </label>
              <div className="grid grid-cols-4 gap-2">
                {(["extra_small", "small", "medium", "large"] as const).map((size) => (
                  <button
                    key={size}
                    onClick={() => updateSetting("controllerSize", size)}
                    className={`py-2 rounded-xl font-bold transition flex items-center justify-center gap-1 cursor-pointer border ${
                      settings.controllerSize === size
                        ? "bg-amber-600 text-white border-amber-400 shadow"
                        : "bg-stone-800 text-stone-300 border-stone-700 hover:border-stone-500"
                    }`}
                  >
                    {size === "extra_small"
                      ? "অতি ক্ষুদ্র"
                      : size === "small"
                      ? "ছোট (Landscape)"
                      : size === "medium"
                      ? "মাঝারি"
                      : "বড়"}
                  </button>
                ))}
              </div>
            </div>

            {/* Hotbar Scale */}
            <div className="space-y-1.5">
              <label className="font-bold text-stone-300 block text-xs">
                নিচের হটবার সাইজ (Hotbar Scale):
              </label>
              <div className="grid grid-cols-2 gap-2">
                {(["compact", "normal"] as const).map((hScale) => (
                  <button
                    key={hScale}
                    onClick={() => updateSetting("hotbarScale", hScale)}
                    className={`py-2 rounded-xl font-bold transition flex items-center justify-center gap-1 cursor-pointer border ${
                      settings.hotbarScale === hScale
                        ? "bg-amber-600 text-white border-amber-400 shadow"
                        : "bg-stone-800 text-stone-300 border-stone-700 hover:border-stone-500"
                    }`}
                  >
                    {hScale === "compact"
                      ? "কম্প্যাক্ট স্লিম (সুপারিশকৃত)"
                      : "স্ট্যান্ডার্ড স্বাভাবিক"}
                  </button>
                ))}
              </div>
            </div>

            {/* Touch Buttons Toggles */}
            <div className="p-3 bg-stone-950/70 rounded-xl border border-stone-800 space-y-2.5">
              <span className="font-bold text-stone-300 block text-xs">
                টাচ স্ক্রিন বাটন সেটিংস (Touch Screen Buttons):
              </span>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {/* D-Pad Toggle */}
                <button
                  onClick={() => updateSetting("showDpad", !settings.showDpad)}
                  className={`p-2 rounded-xl border font-bold flex flex-col items-center justify-center gap-1 cursor-pointer transition ${
                    settings.showDpad
                      ? "bg-stone-800 border-emerald-500 text-emerald-300"
                      : "bg-stone-900 border-stone-800 text-stone-500"
                  }`}
                >
                  <Smartphone className="w-4 h-4" />
                  <span>D-Pad {settings.showDpad ? "চালু" : "বন্ধ"}</span>
                </button>

                {/* Hand Button Toggle */}
                <button
                  onClick={() =>
                    updateSetting("showHandButton", !settings.showHandButton)
                  }
                  className={`p-2 rounded-xl border font-bold flex flex-col items-center justify-center gap-1 cursor-pointer transition ${
                    settings.showHandButton
                      ? "bg-stone-800 border-amber-500 text-amber-300"
                      : "bg-stone-900 border-stone-800 text-stone-500"
                  }`}
                >
                  <span className="text-base">✋</span>
                  <span>হাত বাটন {settings.showHandButton ? "চালু" : "বন্ধ"}</span>
                </button>

                {/* Sprint Button Toggle */}
                <button
                  onClick={() =>
                    updateSetting("showSprintButton", !settings.showSprintButton)
                  }
                  className={`p-2 rounded-xl border font-bold flex flex-col items-center justify-center gap-1 cursor-pointer transition ${
                    settings.showSprintButton
                      ? "bg-stone-800 border-amber-500 text-amber-300"
                      : "bg-stone-900 border-stone-800 text-stone-500"
                  }`}
                >
                  <Zap className="w-4 h-4" />
                  <span>দৌড় বাটন {settings.showSprintButton ? "চালু" : "বন্ধ"}</span>
                </button>

                {/* Jump Button Toggle */}
                <button
                  onClick={() =>
                    updateSetting("showJumpButton", !settings.showJumpButton)
                  }
                  className={`p-2 rounded-xl border font-bold flex flex-col items-center justify-center gap-1 cursor-pointer transition ${
                    settings.showJumpButton
                      ? "bg-stone-800 border-amber-500 text-amber-300"
                      : "bg-stone-900 border-stone-800 text-stone-500"
                  }`}
                >
                  <ArrowBigUp className="w-4 h-4" />
                  <span>লাফ বাটন {settings.showJumpButton ? "চালু" : "বন্ধ"}</span>
                </button>
              </div>
            </div>

            {/* Controller Opacity Slider */}
            <div className="p-3 bg-stone-950/70 rounded-xl border border-stone-800 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-stone-300 text-xs">
                  কন্ট্রোলার স্বচ্ছতা (Opacity):
                </span>
                <span className="font-mono text-amber-400 font-bold">
                  {Math.round(settings.controllerOpacity * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0.3"
                max="1.0"
                step="0.05"
                value={settings.controllerOpacity}
                onChange={(e) =>
                  updateSetting("controllerOpacity", parseFloat(e.target.value))
                }
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>
          </div>
        )}

        {/* Tab 2: Audio & Fullscreen */}
        {activeTab === "audio" && (
          <div className="p-4 overflow-y-auto space-y-3.5 text-xs flex-1">
            <div className="p-3 bg-stone-950/70 rounded-xl border border-stone-800 flex items-center justify-between">
              <div>
                <span className="font-bold text-stone-200 block text-sm font-['Hind_Siliguri']">
                  গেমের অডিও ও সাউন্ড এফেক্ট (Sound Effects)
                </span>
                <p className="text-stone-400 text-[11px] mt-0.5">
                  গাছ কাটার শব্দ, কুকুরের মিষ্টি ঘেউ ঘেউ এবং নদীর পানির আবহ সংগীত।
                </p>
              </div>
              <button
                onClick={onToggleMute}
                className={`px-4 py-2 rounded-xl font-bold flex items-center gap-2 cursor-pointer transition ${
                  isMuted
                    ? "bg-red-950 text-red-300 border border-red-700"
                    : "bg-emerald-950 text-emerald-300 border border-emerald-700"
                }`}
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                <span>{isMuted ? "শব্দ বন্ধ আছে" : "শব্দ চালু আছে"}</span>
              </button>
            </div>

            <div className="p-3 bg-stone-950/70 rounded-xl border border-stone-800 flex items-center justify-between">
              <div>
                <span className="font-bold text-stone-200 block text-sm font-['Hind_Siliguri']">
                  ফুলস্ক্রিন মোড (Fullscreen Mode)
                </span>
                <p className="text-stone-400 text-[11px] mt-0.5">
                  ব্রাউজারের বারগুলো লুকিয় সম্পূর্ণ স্ক্রিন জুড়ে ল্যান্ডস্কেপ মোড উপভোগ করুন।
                </p>
              </div>
              <button
                onClick={onToggleFullscreen}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl font-bold flex items-center gap-2 cursor-pointer transition shadow"
              >
                {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                <span>{isFullscreen ? "ফুলস্ক্রিন বন্ধ [F]" : "ফুলস্ক্রিন চালু [F]"}</span>
              </button>
            </div>

            <div className="p-3 bg-stone-950/70 rounded-xl border border-stone-800 flex items-center justify-between">
              <div>
                <span className="font-bold text-stone-200 block text-sm font-['Hind_Siliguri']">
                  মিনিমালিস্ট মোড (Minimalist Mode [M])
                </span>
                <p className="text-stone-400 text-[11px] mt-0.5">
                  পর্দা থেকে অতিরিক্ত সব বাটন সরিয়ে কেবল প্রয়োজনীয় তথ্য রাখা হয়।
                </p>
              </div>
              <button
                onClick={() =>
                  updateSetting("isMinimalMode", !settings.isMinimalMode)
                }
                className={`px-4 py-2 rounded-xl font-bold flex items-center gap-2 cursor-pointer transition ${
                  settings.isMinimalMode
                    ? "bg-amber-600 text-white"
                    : "bg-stone-800 text-stone-300 border border-stone-700"
                }`}
              >
                <Sparkles className="w-4 h-4" />
                <span>{settings.isMinimalMode ? "মিনিমাল চালু" : "স্বাভাবিক মোড"}</span>
              </button>
            </div>
          </div>
        )}

        {/* Tab 3: Village & Extra Menus */}
        {activeTab === "features" && (
          <div className="p-4 overflow-y-auto space-y-3 text-xs flex-1">
            <p className="text-stone-400 text-[11px]">
              মূল খেলার পর্দা পরিষ্কার রাখতে এই মেনুগুলো সেটিংসের ভেতরে সাজানো হয়েছে:
            </p>

            <button
              onClick={() => {
                onClose();
                onOpenLand();
              }}
              className="w-full p-3 bg-stone-950 hover:bg-stone-800 rounded-xl border border-stone-800 hover:border-amber-500/60 flex items-center justify-between cursor-pointer transition text-left"
            >
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-amber-950/70 text-amber-400 rounded-lg border border-amber-600/40">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-stone-200 text-sm font-['Hind_Siliguri']">
                    গ্রামের নতুন জমি ক্রয় (Land Territories &amp; Borders)
                  </h4>
                  <p className="text-stone-400 text-[11px]">
                    উত্তরের জলাভূমি ও পূর্বের চরের বেড়া উন্মোচন করুন [L]।
                  </p>
                </div>
              </div>
              <span className="text-amber-400 font-bold">খুলুন &rarr;</span>
            </button>

            <button
              onClick={() => {
                onClose();
                onOpenScience();
              }}
              className="w-full p-3 bg-stone-950 hover:bg-stone-800 rounded-xl border border-stone-800 hover:border-teal-500/60 flex items-center justify-between cursor-pointer transition text-left"
            >
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-teal-950/70 text-teal-400 rounded-lg border border-teal-600/40">
                  <BookOpen className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-stone-200 text-sm font-['Hind_Siliguri']">
                    বায়োসায়েন্স জার্নাল ও উদ্ভিদের বিজ্ঞান (Science Journal)
                  </h4>
                  <p className="text-stone-400 text-[11px]">
                    কচুর বৈজ্ঞানিক গুণাগুণ, ক্যালসিয়াম অক্সালেট ও জাত পরিচিতি।
                  </p>
                </div>
              </div>
              <span className="text-teal-400 font-bold">খুলুন &rarr;</span>
            </button>

            <button
              onClick={() => {
                onClose();
                onOpenAwards();
              }}
              className="w-full p-3 bg-stone-950 hover:bg-stone-800 rounded-xl border border-stone-800 hover:border-yellow-500/60 flex items-center justify-between cursor-pointer transition text-left"
            >
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-yellow-950/70 text-yellow-400 rounded-lg border border-yellow-600/40">
                  <span className="text-xl">🏆</span>
                </div>
                <div>
                  <h4 className="font-bold text-stone-200 text-sm font-['Hind_Siliguri']">
                    রোডম্যাপ ও অর্জন (Roadmap &amp; Milestones)
                  </h4>
                  <p className="text-stone-400 text-[11px]">
                    ওয়াইল্ড লাইফ থেকে গভীর কচুবনের অগ্রযাত্রা ও ১০০ গাছ কাটার পুরস্কার।
                  </p>
                </div>
              </div>
              <span className="text-yellow-400 font-bold">খুলুন &rarr;</span>
            </button>
          </div>
        )}

        {/* Tab 4: Controls Guide */}
        {activeTab === "controls" && (
          <div className="p-4 overflow-y-auto space-y-2.5 text-xs flex-1">
            <div className="grid grid-cols-2 gap-2 font-mono">
              <div className="p-2.5 bg-stone-950 rounded-xl border border-stone-800">
                <span className="text-amber-400 font-bold block">W / A / S / D বা তীর চিহ্ন</span>
                <span className="text-stone-300 text-[11px]">তোজোর ৪-মুখী চলাচল</span>
              </div>
              <div className="p-2.5 bg-stone-950 rounded-xl border border-stone-800">
                <span className="text-amber-400 font-bold block">Space / স্পেসবার</span>
                <span className="text-stone-300 text-[11px]">হাতিয়ার কাজ / ফসল তোলা / আদর</span>
              </div>
              <div className="p-2.5 bg-stone-950 rounded-xl border border-stone-800">
                <span className="text-amber-400 font-bold block">Shift / শিফট</span>
                <span className="text-stone-300 text-[11px]">দ্রুত গতিতে দৌড় (Sprint)</span>
              </div>
              <div className="p-2.5 bg-stone-950 rounded-xl border border-stone-800">
                <span className="text-amber-400 font-bold block">J / লাফ বাটন</span>
                <span className="text-stone-300 text-[11px]">খাল ও বেড়ার ওপর দিয়ে লাফ (Jump)</span>
              </div>
              <div className="p-2.5 bg-stone-950 rounded-xl border border-stone-800">
                <span className="text-amber-400 font-bold block">১ - ৭ (Keys 1-7)</span>
                <span className="text-stone-300 text-[11px]">হটবার স্লট নির্বাচন</span>
              </div>
              <div className="p-2.5 bg-stone-950 rounded-xl border border-stone-800">
                <span className="text-amber-400 font-bold block">B / ব্যাগ</span>
                <span className="text-stone-300 text-[11px]">ব্যাকপ্যাক ইনভেন্টরি খোলা</span>
              </div>
              <div className="p-2.5 bg-stone-950 rounded-xl border border-stone-800">
                <span className="text-amber-400 font-bold block">C / ক্রাফট</span>
                <span className="text-stone-300 text-[11px]">ক্রাফটিং মেনু খোলা</span>
              </div>
              <div className="p-2.5 bg-stone-950 rounded-xl border border-stone-800">
                <span className="text-amber-400 font-bold block">F / ফুলস্ক্রিন</span>
                <span className="text-stone-300 text-[11px]">ফুলস্ক্রিন টগল</span>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="p-3 bg-stone-950 border-t border-stone-800 text-[11px] text-stone-400 flex items-center justify-between">
          <span>সেটিংস স্বয়ংক্রিয়ভাবে সংরক্ষিত হয়।</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-lg font-bold text-xs cursor-pointer"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
