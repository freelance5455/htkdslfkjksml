/**
 * SPR - Sahil Powerful Run
 * Settings & Audio Configuration Modal
 */

import React, { useState } from 'react';
import { X, Volume2, VolumeX, Music, Sliders, Upload, Monitor, RotateCcw, Smartphone, Home, Gamepad2 } from 'lucide-react';
import { soundManager } from '../game/audio/SoundManager';
import { saveManager } from '../game/storage/SaveManager';

interface Props {
  onClose: () => void;
  onOpenAndroidApp?: () => void;
  onOpenAbout?: () => void;
  gameIconButtons?: boolean;
  onToggleGameIconButtons?: (enabled: boolean) => void;
}

export const SettingsModal: React.FC<Props> = ({
  onClose,
  onOpenAndroidApp,
  onOpenAbout,
  gameIconButtons: initialGameIconButtons,
  onToggleGameIconButtons,
}) => {
  const currentSettings = soundManager.getSettings();
  const [musicEnabled, setMusicEnabled] = useState(currentSettings.musicEnabled);
  const [sfxEnabled, setSfxEnabled] = useState(currentSettings.sfxEnabled);
  const [musicVolume, setMusicVolume] = useState(currentSettings.musicVolume);
  const [sfxVolume, setSfxVolume] = useState(currentSettings.sfxVolume);
  const [gameIconButtons, setGameIconButtonsState] = useState<boolean>(
    initialGameIconButtons ?? saveManager.getGameIconButtons()
  );
  const [customTrackName, setCustomTrackName] = useState<string | null>(
    currentSettings.isCustomTrack ? currentSettings.trackName : null
  );

  const handleToggleGameIconButtons = () => {
    soundManager.playButtonClick();
    const next = !gameIconButtons;
    setGameIconButtonsState(next);
    saveManager.setGameIconButtons(next);
    if (onToggleGameIconButtons) {
      onToggleGameIconButtons(next);
    }
  };

  const handleToggleMusic = () => {
    soundManager.playButtonClick();
    const next = !musicEnabled;
    setMusicEnabled(next);
    soundManager.setMusicEnabled(next);
    saveManager.updateSettings({ musicEnabled: next });
  };

  const handleToggleSfx = () => {
    soundManager.playButtonClick();
    const next = !sfxEnabled;
    setSfxEnabled(next);
    soundManager.setSfxEnabled(next);
    saveManager.updateSettings({ sfxEnabled: next });
  };

  const handleMusicVolume = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setMusicVolume(val);
    soundManager.setMusicVolume(val);
    saveManager.updateSettings({ musicVolume: val });
  };

  const handleSfxVolume = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setSfxVolume(val);
    soundManager.setSfxVolume(val);
    saveManager.updateSettings({ sfxVolume: val });
  };

  const handleCustomAudioUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const blobUrl = URL.createObjectURL(file);
      soundManager.loadCustomMusic(blobUrl, file.name);
      setCustomTrackName(file.name);
      soundManager.playPowerupSound();
    }
  };

  const handleResetDefaultMusic = () => {
    soundManager.playButtonClick();
    soundManager.resetToDefaultMusic();
    setCustomTrackName(null);
  };

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md select-none">
      <div className="relative w-full max-w-lg bg-gradient-to-b from-slate-900 via-slate-950 to-black border border-slate-700/80 rounded-3xl shadow-2xl p-5 sm:p-6 flex flex-col gap-4 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-slate-300">
              <Sliders className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-black tracking-wider text-white uppercase font-display">
                GAME SETTINGS
              </h2>
              <p className="text-xs text-slate-400">Audio, Graphics & Music Preferences</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="settings-btn-home"
              onClick={() => {
                soundManager.playButtonClick();
                onClose();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs sm:text-sm uppercase font-display shadow-md transition cursor-pointer active:scale-95"
              title="Return to SPR Main Menu"
            >
              <Home className="w-4 h-4" />
              <span>HOME</span>
            </button>

            <button
              id="settings-btn-close"
              onClick={() => {
                soundManager.playButtonClick();
                onClose();
              }}
              className="w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Audio Toggles */}
        <div className="flex flex-col gap-3">
          {/* Music Control */}
          <div className="bg-slate-950/70 p-3.5 rounded-2xl border border-slate-800/80 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <Music className="w-4 h-4 text-orange-400" />
                <span>BACKGROUND MUSIC</span>
              </div>
              <button
                id="settings-toggle-music"
                onClick={handleToggleMusic}
                className={`px-3 py-1 text-xs font-bold rounded-full transition ${
                  musicEnabled
                    ? 'bg-orange-600 text-white'
                    : 'bg-slate-800 text-slate-400'
                }`}
              >
                {musicEnabled ? 'MUSIC ON' : 'MUSIC OFF'}
              </button>
            </div>
            {musicEnabled && (
              <div className="flex items-center gap-3 mt-1">
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={musicVolume}
                  onChange={handleMusicVolume}
                  className="w-full accent-orange-500 cursor-pointer"
                />
                <span className="text-xs text-slate-400 w-8 text-right font-mono">
                  {Math.round(musicVolume * 100)}%
                </span>
              </div>
            )}
          </div>

          {/* SFX Control */}
          <div className="bg-slate-950/70 p-3.5 rounded-2xl border border-slate-800/80 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <Volume2 className="w-4 h-4 text-cyan-400" />
                <span>SOUND EFFECTS (SFX)</span>
              </div>
              <button
                id="settings-toggle-sfx"
                onClick={handleToggleSfx}
                className={`px-3 py-1 text-xs font-bold rounded-full transition ${
                  sfxEnabled
                    ? 'bg-cyan-600 text-white'
                    : 'bg-slate-800 text-slate-400'
                }`}
              >
                {sfxEnabled ? 'SFX ON' : 'SFX OFF'}
              </button>
            </div>
            {sfxEnabled && (
              <div className="flex items-center gap-3 mt-1">
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={sfxVolume}
                  onChange={handleSfxVolume}
                  className="w-full accent-cyan-500 cursor-pointer"
                />
                <span className="text-xs text-slate-400 w-8 text-right font-mono">
                  {Math.round(sfxVolume * 100)}%
                </span>
              </div>
            )}
          </div>

          {/* Game Icon Buttons (On-Screen Controls) Toggle (Default: OFF) */}
          <div className="bg-slate-950/70 p-3.5 rounded-2xl border border-slate-800/80 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <Gamepad2 className="w-4 h-4 text-emerald-400" />
                <span className="font-display tracking-wider">GAME ICON BUTTONS</span>
              </div>
              <button
                id="settings-toggle-game-icon-buttons"
                onClick={handleToggleGameIconButtons}
                className={`px-4 py-1.5 text-xs font-black rounded-full uppercase tracking-wider transition cursor-pointer font-display shadow-md active:scale-95 ${
                  gameIconButtons
                    ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-[0_0_12px_rgba(16,185,129,0.5)]'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-400 border border-slate-700'
                }`}
              >
                {gameIconButtons ? 'ON' : 'OFF'}
              </button>
            </div>
            <p className="text-[11px] text-slate-400 leading-tight">
              {gameIconButtons
                ? 'On-screen Left, Right, Jump, Slide & Skateboard buttons are VISIBLE.'
                : 'On-screen buttons HIDDEN (Default). Swipe gestures & keyboard controls remain 100% active!'}
            </p>
          </div>

          {/* Background Music Track Info & Custom Audio Upload */}
          <div className="bg-slate-950/70 p-3.5 rounded-2xl border border-slate-800/80 flex flex-col gap-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <Music className="w-4 h-4 text-orange-400" />
                <span>ACTIVE SOUNDTRACK</span>
              </div>
              <span className="px-2 py-0.5 bg-orange-950/80 border border-orange-500/40 text-orange-300 text-[10px] font-bold rounded-full">
                138 BPM LOOP
              </span>
            </div>

            <div className="flex items-center justify-between p-2.5 bg-slate-900/90 rounded-xl border border-slate-800 text-xs">
              <div className="flex flex-col gap-0.5 truncate mr-2">
                <span className="text-[10px] text-slate-500 uppercase font-mono">Current Track:</span>
                <span className="text-slate-200 font-semibold truncate">
                  {customTrackName || 'SPR Jungle Runner 138 BPM Theme'}
                </span>
              </div>
              {customTrackName && (
                <button
                  id="settings-reset-music"
                  onClick={handleResetDefaultMusic}
                  className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg text-[11px] font-bold transition whitespace-nowrap cursor-pointer"
                  title="Reset to default game music"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>RESET</span>
                </button>
              )}
            </div>

            <label className="flex items-center justify-center gap-2 py-2 px-4 bg-slate-900 hover:bg-slate-850 border border-slate-700 hover:border-orange-500 rounded-xl text-xs font-bold text-slate-200 cursor-pointer transition">
              <Upload className="w-3.5 h-3.5" />
              <span>{customTrackName ? 'CHANGE CUSTOM AUDIO FILE' : 'UPLOAD CUSTOM MUSIC (.MP3 / .WAV)'}</span>
              <input
                type="file"
                accept="audio/*"
                onChange={handleCustomAudioUpload}
                className="hidden"
              />
            </label>
          </div>

          {/* About SPR & Creator Information */}
          {onOpenAbout && (
            <button
              id="settings-btn-about"
              onClick={() => {
                soundManager.playButtonClick();
                onClose();
                onOpenAbout();
              }}
              className="w-full py-2.5 px-4 bg-gradient-to-r from-amber-600 via-yellow-500 to-amber-600 hover:brightness-110 active:scale-98 rounded-xl text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition cursor-pointer font-display"
            >
              <span>👑</span>
              <span>ABOUT SPR (SAHIL POWERFUL RUN)</span>
            </button>
          )}

          {/* Android App & APK Export Options */}
          {onOpenAndroidApp && (
            <button
              id="settings-btn-android-app"
              onClick={() => {
                soundManager.playButtonClick();
                onOpenAndroidApp();
              }}
              className="w-full py-2.5 px-4 bg-gradient-to-r from-orange-600 via-amber-500 to-orange-600 hover:brightness-110 active:scale-98 rounded-xl text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition cursor-pointer font-display"
            >
              <Smartphone className="w-4 h-4" />
              <span>Install SPR Android App / APK Options</span>
            </button>
          )}

          {/* Performance & Target Android Mode */}
          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800 flex items-center justify-between text-xs text-slate-300">
            <div className="flex items-center gap-2">
              <Monitor className="w-4 h-4 text-amber-400" />
              <span>Target: Android Landscape (60 FPS)</span>
            </div>
            <span className="px-2 py-0.5 bg-emerald-950 border border-emerald-500/50 text-emerald-400 text-[10px] font-bold rounded">
              OPTIMIZED
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
