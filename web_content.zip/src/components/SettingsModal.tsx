import React, { useState } from 'react';
import { ThemeMode, LanguageCode } from '../types';
import { TRANSLATIONS } from '../translations';
import { 
  VOICE_PERSONAS, 
  getStoredVoiceConfig, 
  saveVoiceConfig, 
  applyVoiceToUtterance,
  UserVoiceConfig 
} from '../utils/voiceSettings';
import { 
  Settings, 
  X, 
  Moon, 
  Sun, 
  Smartphone, 
  ShieldCheck, 
  Key, 
  Globe, 
  Sparkles, 
  Check, 
  Download, 
  AlertCircle,
  Volume2,
  Square,
  Sliders,
  AudioLines,
  Heart
} from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme: ThemeMode;
  onThemeChange: (theme: ThemeMode) => void;
  language: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
  passcode: string;
  onPasscodeChange: (newPin: string) => void;
  isLockEnabled: boolean;
  onToggleLock: (enabled: boolean) => void;
  isMobileFrame: boolean;
  onToggleMobileFrame: (isMobile: boolean) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  theme,
  onThemeChange,
  language,
  onLanguageChange,
  passcode,
  onPasscodeChange,
  isLockEnabled,
  onToggleLock,
  isMobileFrame,
  onToggleMobileFrame,
}) => {
  const [newPin, setNewPin] = useState(passcode);
  const [pinSaved, setPinSaved] = useState(false);
  const [voiceConfig, setVoiceConfig] = useState<UserVoiceConfig>(() => getStoredVoiceConfig());
  const [isTestingVoice, setIsTestingVoice] = useState(false);

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  if (!isOpen) return null;

  const handleSelectPersona = (personaId: string) => {
    const persona = VOICE_PERSONAS.find(p => p.id === personaId) || VOICE_PERSONAS[0];
    const updated: UserVoiceConfig = {
      personaId,
      customPitch: persona.pitch,
      customRate: persona.rate,
    };
    setVoiceConfig(updated);
    saveVoiceConfig(updated);
  };

  const handlePitchChange = (pitch: number) => {
    const updated: UserVoiceConfig = { ...voiceConfig, customPitch: pitch };
    setVoiceConfig(updated);
    saveVoiceConfig(updated);
  };

  const handleRateChange = (rate: number) => {
    const updated: UserVoiceConfig = { ...voiceConfig, customRate: rate };
    setVoiceConfig(updated);
    saveVoiceConfig(updated);
  };

  const handleTestVoice = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      alert('Your browser does not support audio speech output.');
      return;
    }

    if (isTestingVoice) {
      window.speechSynthesis.cancel();
      setIsTestingVoice(false);
      return;
    }

    window.speechSynthesis.cancel();

    const sampleText = language === 'hi'
      ? 'नमस्ते! मैं आपका एआई साथी हूँ। यह मेरी आवाज़ है, आप चैट में मुझसे इसी अंदाज़ में बात सुन सकते हैं।'
      : language === 'bn'
      ? 'হ্যালো! আমি আপনার এআই ভয়েস সহকারী। এটি আমার কণ্ঠস্বর, আপনি এটি সেভ করতে পারেন।'
      : language === 'hinglish'
      ? 'Namaste creator! Main hoon aapka AI assistant. Yeh meri selected voice hai, batayein kaisi lagi?'
      : 'Hello Creator! I am your AI assistant. This is my voice sample, ready for viral YouTube conversations.';

    const utterance = new SpeechSynthesisUtterance(sampleText);
    applyVoiceToUtterance(utterance, language, voiceConfig);

    utterance.onstart = () => setIsTestingVoice(true);
    utterance.onend = () => setIsTestingVoice(false);
    utterance.onerror = () => setIsTestingVoice(false);

    window.speechSynthesis.speak(utterance);
  };

  const handleSavePin = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPin.trim()) {
      onPasscodeChange(newPin.trim());
      setPinSaved(true);
      setTimeout(() => setPinSaved(false), 2000);
    }
  };

  const THEMES: { id: ThemeMode; label: string; desc: string }[] = [
    { id: 'cyber-rgb', label: 'Cyber RGB Neon', desc: 'Glowing animated RGB borders & vibrant cyberpunk accents' },
    { id: 'black-white', label: 'Black & White (Monochrome)', desc: 'High-contrast pure monochrome minimalist design' },
    { id: 'midnight-dark', label: 'Midnight Dark', desc: 'Deep sleek slate dark mode for creator night work' },
    { id: 'clean-light', label: 'Clean Light', desc: 'Crisp bright modern aesthetic' },
  ];

  const LANGUAGES: { id: LanguageCode; label: string; native: string }[] = [
    { id: 'en', label: 'English', native: 'English (US/UK)' },
    { id: 'hi', label: 'Hindi', native: 'हिन्दी (India)' },
    { id: 'bn', label: 'Bangla', native: 'বাংলা (Bengali)' },
    { id: 'hinglish', label: 'Hinglish', native: 'Hinglish (Casual Desi)' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fadeIn">
      <div className="w-full max-w-lg rounded-3xl border border-white/10 bg-zinc-950 shadow-2xl p-6 relative overflow-hidden flex flex-col max-h-[85vh]">
        {/* Top RGB glowing stripe */}
        <div className="absolute top-0 left-0 right-0 h-1 rgb-gradient-border" />

        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-500/30">
              <Settings className="w-5 h-5 animate-spin-slow" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {t.tabSettings} &amp; Preferences
              </h3>
              <p className="text-xs text-zinc-400">
                Themes, Languages, Passcode Lock &amp; APK View
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-white/10 text-zinc-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body scroll area */}
        <div className="flex-1 overflow-y-auto space-y-6 pr-1">
          {/* 1. Theme Selection */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-300 mb-2.5">
              {t.themeMode}
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {THEMES.map(th => (
                <button
                  key={th.id}
                  onClick={() => onThemeChange(th.id)}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    theme === th.id
                      ? 'border-cyan-500 bg-cyan-950/30 shadow-[0_0_15px_rgba(0,255,255,0.2)]'
                      : 'border-white/5 bg-zinc-900/60 hover:bg-zinc-900'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-white">
                      {th.label}
                    </span>
                    {theme === th.id && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                  </div>
                  <p className="text-[11px] text-zinc-400 line-clamp-2">
                    {th.desc}
                  </p>
                </button>
              ))}
            </div>
          </div>

          {/* 2. Language Selection */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-300 mb-2.5">
              <span className="flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-cyan-400" />
                <span>{t.language}</span>
              </span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              {LANGUAGES.map(lang => (
                <button
                  key={lang.id}
                  onClick={() => onLanguageChange(lang.id)}
                  className={`p-2.5 rounded-xl border text-left transition-all flex items-center justify-between ${
                    language === lang.id
                      ? 'border-cyan-500 bg-cyan-950/40'
                      : 'border-white/5 bg-zinc-900/60 hover:bg-zinc-900'
                  }`}
                >
                  <div>
                    <div className="text-xs font-bold text-white">{lang.native}</div>
                    <div className="text-[10px] text-zinc-400">{lang.label}</div>
                  </div>
                  {language === lang.id && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                </button>
              ))}
            </div>
          </div>

          {/* 3. Voice Persona & Speech Settings (आवाज़ चयन) */}
          <div className="p-4 rounded-2xl bg-zinc-900/60 border border-white/5 space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-1.5">
                <Volume2 className="w-4 h-4 text-pink-400" />
                <span>AI Voice Personas (आवाज़ चुनें)</span>
              </label>
              <button
                type="button"
                onClick={handleTestVoice}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-md active:scale-95 ${
                  isTestingVoice
                    ? 'bg-amber-500 text-black animate-pulse shadow-amber-500/30'
                    : 'bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-400 hover:to-rose-500 text-white shadow-pink-500/20'
                }`}
              >
                {isTestingVoice ? (
                  <>
                    <Square className="w-3.5 h-3.5 fill-black" />
                    <span>Stop Test</span>
                    <span className="flex items-center gap-0.5 ml-0.5">
                      <span className="w-1 h-2.5 bg-black rounded-full animate-bounce" />
                      <span className="w-1 h-3.5 bg-black rounded-full animate-bounce [animation-delay:0.15s]" />
                      <span className="w-1 h-2 bg-black rounded-full animate-bounce [animation-delay:0.3s]" />
                    </span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>Test Voice 🔊</span>
                  </>
                )}
              </button>
            </div>

            {/* Voice Cards Grid */}
            <div className="space-y-2">
              {VOICE_PERSONAS.map(p => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => handleSelectPersona(p.id)}
                  className={`w-full p-2.5 rounded-xl border text-left transition-all flex items-center justify-between ${
                    voiceConfig.personaId === p.id
                      ? 'border-pink-500 bg-pink-950/40 shadow-sm'
                      : 'border-white/5 bg-zinc-950/60 hover:bg-zinc-900'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-xl">{p.avatar}</span>
                    <div>
                      <div className="text-xs font-bold text-white flex items-center gap-2">
                        <span>{p.name}</span>
                        {p.gender === 'female' && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30">
                            FEMALE
                          </span>
                        )}
                        {p.gender === 'male' && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
                            MALE
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-zinc-400">{p.tone}</div>
                    </div>
                  </div>
                  {voiceConfig.personaId === p.id && (
                    <Check className="w-4 h-4 text-pink-400 shrink-0" />
                  )}
                </button>
              ))}
            </div>

            {/* Pitch & Speed Fine-Tuning */}
            <div className="pt-2 border-t border-white/5 grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <div className="flex items-center justify-between text-[11px] text-zinc-400 mb-1">
                  <span>Pitch (पिच - Heavy / High):</span>
                  <span className="font-mono text-cyan-400 font-bold">{voiceConfig.customPitch.toFixed(2)}x</span>
                </div>
                <input
                  type="range"
                  min="0.6"
                  max="1.5"
                  step="0.05"
                  value={voiceConfig.customPitch}
                  onChange={e => handlePitchChange(parseFloat(e.target.value))}
                  className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-pink-500"
                />
              </div>

              <div>
                <div className="flex items-center justify-between text-[11px] text-zinc-400 mb-1">
                  <span>Speed (बोलने की गति):</span>
                  <span className="font-mono text-cyan-400 font-bold">{voiceConfig.customRate.toFixed(2)}x</span>
                </div>
                <input
                  type="range"
                  min="0.75"
                  max="1.4"
                  step="0.05"
                  value={voiceConfig.customRate}
                  onChange={e => handleRateChange(parseFloat(e.target.value))}
                  className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-pink-500"
                />
              </div>
            </div>
          </div>

          {/* 4. Passcode & Lock Security */}
          <div className="p-4 rounded-2xl bg-zinc-900/60 border border-white/5 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold text-white">
                  {t.screenLock}
                </span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={isLockEnabled}
                  onChange={e => onToggleLock(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-zinc-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-cyan-500"></div>
              </label>
            </div>

            <form onSubmit={handleSavePin} className="space-y-2 pt-1">
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Key className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-3" />
                  <input
                    type="password"
                    value={newPin}
                    onChange={e => setNewPin(e.target.value)}
                    placeholder="Enter new secret Passcode"
                    maxLength={10}
                    className="w-full pl-8 pr-3 py-2 rounded-xl bg-zinc-950 border border-white/10 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-500 font-mono tracking-widest"
                  />
                </div>
                <button
                  type="submit"
                  className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs text-white font-semibold flex items-center gap-1 transition-all"
                >
                  {pinSaved ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : null}
                  <span>{pinSaved ? 'Saved!' : t.save}</span>
                </button>
              </div>
              <p className="text-[10px] text-zinc-400 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                <span>Passcode is encrypted and kept private on this device.</span>
              </p>
            </form>
          </div>

          {/* 4. APK View Mode Toggle */}
          <div className="p-4 rounded-2xl bg-zinc-900/60 border border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Smartphone className="w-4 h-4 text-cyan-400" />
              <div>
                <span className="text-xs font-bold text-white">
                  Mobile APK Smartphone Frame
                </span>
                <p className="text-[10px] text-zinc-400">
                  Switch between Mobile Device Chassis &amp; Full Screen
                </p>
              </div>
            </div>
            <button
              onClick={() => onToggleMobileFrame(!isMobileFrame)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                isMobileFrame
                  ? 'bg-cyan-500 text-black shadow-md shadow-cyan-500/20'
                  : 'bg-white/10 text-zinc-300 hover:bg-white/15'
              }`}
            >
              {isMobileFrame ? t.mobileView : t.fullView}
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-bold transition-all"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
