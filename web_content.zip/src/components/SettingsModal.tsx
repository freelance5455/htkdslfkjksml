import React from 'react';
import {
  X,
  User,
  Shield,
  Download,
  LogOut,
  Bell,
  Smartphone,
  ExternalLink,
  Info,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenCertificate: (id: string) => void;
  onSignOut?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  onOpenCertificate,
  onSignOut,
}) => {
  const { userProfile, signOut, signInWithGoogle } = useAuth();
  const { isInstallable, install, isInstalled } = usePWAInstall();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in select-none">
      <div className="w-full max-w-md bg-[#101014] border border-[#272730] rounded-3xl p-6 shadow-2xl relative text-left max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#19191F]">
          <h2 className="text-base font-bold text-white">Configurações & Conta</h2>
          <button
            onClick={onClose}
            className="p-1.5 text-[#A1A1AA] hover:text-white rounded-full hover:bg-[#19191F]"
          >
            <X size={18} />
          </button>
        </div>

        {/* User Card */}
        <div className="flex items-center gap-3 p-3.5 my-4 rounded-2xl bg-[#19191F] border border-[#272730]">
          <img
            src={userProfile?.photoURL || '/icon.svg'}
            alt="Avatar"
            className="w-12 h-12 rounded-full object-cover border border-[#272730]"
          />
          <div className="truncate">
            <h3 className="text-sm font-bold text-white truncate">
              {userProfile?.displayName || 'João Vibes'}
            </h3>
            <span className="text-xs text-[#A1A1AA] block truncate">
              @{userProfile?.username || 'joaovibes'}
            </span>
            <span className="text-[10px] text-[#20E060] font-semibold mt-0.5 inline-block">
              ● Conta Ativa & Sincronizada
            </span>
          </div>
        </div>

        {/* Section: Aplicativo & PWA */}
        <div className="space-y-2 mb-4">
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#A1A1AA] block px-1">
            Aplicativo
          </span>

          {isInstallable && (
            <button
              onClick={install}
              className="w-full flex items-center justify-between p-3 rounded-2xl bg-clipshare-gradient text-white text-xs font-bold hover:opacity-95 transition-all shadow-md cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <Download size={16} />
                <span>Instalar ClipShare no dispositivo (PWA)</span>
              </div>
              <span>Grátis</span>
            </button>
          )}

          {isInstalled && (
            <div className="p-3 rounded-2xl bg-[#19191F] border border-[#272730] text-xs text-[#20E060] flex items-center gap-2">
              <Smartphone size={16} />
              <span>ClipShare já instalado como aplicativo!</span>
            </div>
          )}

          <div
            onClick={() => onOpenCertificate(userProfile?.certificateId || 'cert-joaovibes-10k')}
            className="flex items-center justify-between p-3 rounded-2xl bg-[#19191F] hover:bg-[#22222b] cursor-pointer border border-[#272730] transition-colors"
          >
            <div className="flex items-center gap-2.5 text-xs font-semibold text-white">
              <Shield size={16} className="text-amber-400" />
              <span>Certificado de Influenciador</span>
            </div>
            <span className="text-[11px] text-amber-400 font-bold">10+ seguidores</span>
          </div>
        </div>

        {/* Section: Privacidade & Moderação */}
        <div className="space-y-2 mb-4">
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#A1A1AA] block px-1">
            Segurança & Proteção
          </span>

          <div className="p-3 rounded-2xl bg-[#19191F] border border-[#272730] text-xs text-[#A1A1AA] space-y-1.5">
            <div className="flex items-center gap-2 text-white font-semibold">
              <Shield size={14} className="text-[#20E060]" />
              <span>Diretrizes da Comunidade ClipShare</span>
            </div>
            <p className="text-[11px] leading-relaxed">
              O ClipShare promove um ambiente seguro com moderação de conteúdo, proteção etária para menores e ferramentas ativas contra spam.
            </p>
          </div>
        </div>

        {/* Section: Sessão */}
        <div className="pt-2 border-t border-[#19191F] space-y-2">
          <button
            onClick={() => {
              if (onSignOut) {
                onSignOut();
              } else {
                signOut();
              }
              onClose();
            }}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-full bg-red-500/15 border border-red-500/30 text-red-400 text-xs font-bold hover:bg-red-500/25 transition-colors cursor-pointer"
          >
            <LogOut size={16} />
            <span>Sair da conta</span>
          </button>
        </div>
      </div>
    </div>
  );
};
